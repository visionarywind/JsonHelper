/* 
 * Copyright 2010 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

/******************************************************************************
*
*   Module: cuda_internal_vdpau.h
*
*   Description:
*       Internal header file for compute VDPAU interop interface.
*
******************************************************************************/

#ifndef __cuda_internal_vdpau_h__
#define __cuda_internal_vdpau_h__

#include <vdpau/vdpau.h>

#include "interop.h"

#ifdef __cplusplus
extern "C" {
#endif

CUresult cuiVDPAUGetDevice(CUdevice *pDevice, VdpDevice vdpDevice, VdpGetProcAddress *vdpGetProcAddress);

CUresult cuiVDPAUCtxInit(CUIgraphicsClient *client, VdpDevice vdpDevice, VdpGetProcAddress *vdpGetProcAddress);
CUresult cuiVDPAUCtxDestroy(CUIgraphicsClient *client);

CUresult cuiVDPAURegisterResource(CUgraphicsResource cudaResource, CUIgraphicsResourceRegisterParams *params);
CUresult cuiVDPAUUnregisterResource(CUIgraphicsClient *client, CUgraphicsResource resource);
CUresult cuiVDPAUMapResources(CUIgraphicsClient *client, NvU32 count, CUgraphicsResource *resources, CUIstream *hStream, NvBool sync);
CUresult cuiVDPAUUnmapResources(CUIgraphicsClient *client, NvU32 count, CUgraphicsResource *resources, CUIstream *hStream, NvBool sync);
CUresult cuiVDPAUGetMappedMipmappedArray(CUIgraphicsClient *client, CUmipmappedArray *pMipmap, CUgraphicsResource resource);
CUresult cuiVDPAUGetMappedArray(CUIgraphicsClient *client, CUarray *pArray, CUgraphicsResource resource, NvU32 slice, NvU32 level);
CUresult cuiVDPAUGetMappedBuffer(CUIgraphicsClient *client, CUmemobj **outMemobj, NvU64 *outOffset, NvU64 *outSize, CUgraphicsResource resource);
CUresult cuiVDPAUGetMappedLinearArray(CUIgraphicsClient *client, CUIinteropLinearArray **outLinearArray, CUgraphicsResource resource, NvU32 slice, NvU32 level);
NvBool cuiVDPAUValidateResourceSetMapFlags_v1(CUgraphicsResource resource);
CUresult cuiVDPAUResourceSetMapFlags(CUIgraphicsClient *client, CUgraphicsResource resource, CUgraphicsMapResourceFlags flags);
void cuiVDPAUResourceGetView(CUIgraphicsClient *client, CUIgraphicsResourceView *outView, NvU32 *outSliceCount, NvU32 *outMipBase, NvU32 *outMipCount, CUgraphicsResource resource);
CUresult cuiVDPAUGetSubResourceDimensions(CUIgraphicsClient *client, NvU64 *outWidth, NvU64 *outHeight, NvU64 *outDepth, CUgraphicsResource resource, NvU32 arrayIndex, NvU32 mipLevel);
CUresult cuiVDPAUGetMappedEglFrame(CUIgraphicsClient *client, CUIeglFrame* eglFrame, CUgraphicsResource resource, unsigned int index, unsigned int mipLevel);

#ifdef __cplusplus
}
#endif

#endif
