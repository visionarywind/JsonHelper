//
// syscall_device_shared.cu
//
// A repository for all syscalls.  In order to keep all the constants for
// the various syscalls from stomping on each other, they must all be
// compiled at the same time.

#include <stdio.h>

#if defined(__CUDA_ARCH__)

#include "../syscalls/cnp/helpers.cu"
// Inline PTX to return index of first "1" (MSB-first) in a uint32
static __device__ __forceinline__ unsigned int __flo(unsigned int word) { unsigned int ret; asm volatile("bfind.u32 %0, %1;" : "=r"(ret) : "r"(word)); return ret; }
// UNUSED static __device__ __forceinline__ unsigned int __flo(unsigned long long dword) { unsigned long long ret; asm volatile("bfind.u64 %0, %1;" : "=r"(ret) : "r"(dword)); return ret; }
#define __masterlane()      __flo(__activemask())
#define __masterthread()    (__masterlane() == __laneid())

#endif

// the real version of printf
#include "../syscalls/printf/printf.cu"

// the real version of malloc/free
#define USE_MINI_MALLOC  1

#if USE_HMA_MALLOC
#include "../syscalls/hma-malloc/CudaMalloc.cu"
#elif USE_MINI_MALLOC
// Wrapper which returns TRUE to be used in a macronized statement
static __device__ __forceinline__ NvBool __warpsync(NvU32 mask) { __warpSync(mask); return NV_TRUE; }
#define __masterthread_sync(mask)    (__warpsync(mask), __masterlane() == __laneid())
#include "../syscalls/minimalloc/CudaMalloc.cu"
#else
#include "../syscalls/malloc/malloc.cu"
#endif

#include "../syscalls/assert/assert.cu"
#include "../syscalls/profile/profile.cu"

#if defined(__CUDA_ARCH__)
#include "../syscalls/cnp/cnp.cu"
#include "../syscalls/debugger/kilp.cu"
#include "../syscalls/ocldse/ocldse_stubs.cu"
#include "../syscalls/cgs/cgs.cu"
#endif

#include "../syscalls/graphs/graphs.cu"
