/*
 * Copyright (c) 2011 NVIDIA Corporation.  All rights reserved.
 *
 * NVIDIA Corporation and its licensors retain all intellectual property and proprietary
 * rights in and to this software, related documentation and any modifications thereto.
 * Any use, reproduction, disclosure or distribution of this software and related
 * documentation without an express license agreement from NVIDIA Corporation is strictly
 * prohibited.
 *
 * TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THIS SOFTWARE IS PROVIDED *AS IS*
 * AND NVIDIA AND ITS SUPPLIERS DISCLAIM ALL WARRANTIES, EITHER EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE.  IN NO EVENT SHALL NVIDIA OR ITS SUPPLIERS BE LIABLE FOR ANY
 * SPECIAL, INCIDENTAL, INDIRECT, OR CONSEQUENTIAL DAMAGES WHATSOEVER (INCLUDING, WITHOUT
 * LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF
 * BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS) ARISING OUT OF THE USE OF OR
 * INABILITY TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGES
 */

#include "gf100_kernel_consts.h"

// this function is used for maximum bandwidth for aligned case by
// copying 32 * 16 bytes in parallel in a warp
// dst : is the destination pointer for memcpy
// src : is the source pointer for memcpy
extern "C"
__global__ void memcpy128(unsigned int* dst, unsigned int* src)
{
    size_t sid = MEMCPY_GETTID128;

    dst[sid] = src[sid];
    sid += CUI_MEMCPY_STEP_SIZE;
    dst[sid] = src[sid];
    sid += CUI_MEMCPY_STEP_SIZE;
    dst[sid] = src[sid];
    sid += CUI_MEMCPY_STEP_SIZE;
    dst[sid] = src[sid];
}

// higher bytes first
// read a 4bytes from unaligned pointer, otherwise there is error.
extern "C"
__device__ __inline__ unsigned int _read_unaligned(unsigned char* src)
{
    __shared__ unsigned int buffer[CUI_MEMCPY_STEP_SIZE];
    unsigned char* pBuffer = (unsigned char*)buffer + threadIdx.x; 
    unsigned int ret;

    *pBuffer = *src;
    pBuffer += CUI_MEMCPY_STEP_SIZE;
    src += CUI_MEMCPY_STEP_SIZE;
    *pBuffer = *src;
    pBuffer += CUI_MEMCPY_STEP_SIZE;
    src += CUI_MEMCPY_STEP_SIZE;
    *pBuffer = *src;
    pBuffer += CUI_MEMCPY_STEP_SIZE;
    src += CUI_MEMCPY_STEP_SIZE;
    *pBuffer = *src;

    __syncthreads();
    ret = buffer[threadIdx.x];
    __syncthreads();
    return ret;
}

// this function is used for maximum bandwidth for misaligned case
// read is byte by byte and write is aligned
// dst is aligned to 128
// src is not aligned
extern "C"
__global__ void memcpy128_unaligned(unsigned int* dst, unsigned int* src)
{
    size_t sid = ((CUI_MEMCPY_STEP_SIZE * (blockIdx.y*gridDim.x + blockIdx.x)) << 2);
    unsigned char* pSrc = (unsigned char*)(src + sid) + threadIdx.x;
    dst += sid + threadIdx.x;
    *dst = _read_unaligned(pSrc);
    dst += CUI_MEMCPY_STEP_SIZE; pSrc += CUI_MEMCPY_STEP_SIZE <<2;
    *dst = _read_unaligned(pSrc);
    dst += CUI_MEMCPY_STEP_SIZE; pSrc += CUI_MEMCPY_STEP_SIZE <<2;
    *dst = _read_unaligned(pSrc);
    dst += CUI_MEMCPY_STEP_SIZE; pSrc += CUI_MEMCPY_STEP_SIZE <<2;
    *dst = _read_unaligned(pSrc);
}

// Copy the left part of the data which memcpy128 have not finished.
// It reads and writes a byte at a time.
extern "C"
__global__ void memcpy_post(unsigned char* dst, unsigned char* src, size_t size)
{
    size_t tid = MEMCPY_GETTID_FAST;

    if  (tid < size)
    {
        dst[tid] = src[tid];
    }
}



// this function is slower. It copy data byte by byte,
// which is used for finishing the task which memcpy128 have not finished including the misaligned data
// dst : is the destination pointer
// src : is the source pointer
// size_misaligned : how many bytes it misaligned to 128. for example, if the pointer is 0x0001, then size_misaligned = 128 - 1 = 7
// size_middle     : the number of bytes which the maximum bandwidth will copy.
// totalleft       : total size - size_middle
extern "C"
__global__ void memcpy_pre_post(unsigned char* dst, unsigned char* src, size_t size_misaligned, size_t size_middle, size_t size_totalleft)
{
    size_t tid = MEMCPY_GETTID_FAST;

    if  (tid < size_misaligned)
    {
        dst[tid] = src[tid];
    }
    else if (tid < size_totalleft)
    {
        dst[size_middle + tid] = src[size_middle + tid];
    }
}

// Copy the left part of the data which memcpy128 have not finished.
// It reads and writes a word at a time.
extern "C"
__global__ void memcpy32_post(unsigned int* dst, unsigned int* src, size_t size)
{
    size_t tid = MEMCPY_GETTID_FAST;

    if  (tid < size)
    {
        dst[tid] = src[tid];
    }
}

// dst, src is the pointer after been aligned
// left_bytes is how many bytes in the left chunk of the memory need to be filled
// right_bytes is how many bytes in the right chunk of the memory need to be filled
extern "C" __global__ void
memcpy_post_faster( unsigned int* dst, unsigned int* src, size_t left_bytes, size_t size_middle, size_t right_bytes)
{
    size_t tid = MEMCPY_GETTID_FAST;

    if ( tid < size_middle ) // fill the middle chunk
    {
        dst[tid] = src[tid];
    }
    else if (tid == size_middle ) // fill the left chunk
    {
        for (int i = 1; i <= left_bytes; ++i)
        {
            *((unsigned char*)dst - i) = *((unsigned char*)src - i);
        }
    }
    else if (tid == size_middle + 1) // fill the right chunk
    {
        for (int i = 0; i < right_bytes; ++i)
        {
            *((unsigned char*)dst + size_middle * sizeof(int) + i) = *((unsigned char*)src + size_middle * sizeof(int) + i);
        }
    }
}
