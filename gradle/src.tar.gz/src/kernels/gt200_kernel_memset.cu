#ifdef __GNUC__
#include <stdint.h>
#elif _WIN32
#include <stddef.h>
#endif // _WIN32
#include "gt200_kernel_consts.h"

#define INT_SIZE    sizeof(int)

// ------------------------------------------------------------------------------------------------
// Helper:      computeMisalignment( ptr, alignment )
//
// Desc:        Return the misalignment of address `ptr` with reference to required `alignment`.
// ------------------------------------------------------------------------------------------------
template <typename T>
__device__ static unsigned
computeMisalignment(T *ptr, unsigned alignment)
{
    return (alignment - uintptr_t(ptr) % alignment) % alignment;
}

// ------------------------------------------------------------------------------------------------
// Kernel:      memset8( pOut, val32, width, pitch )
//
// Desc:        Set every byte in the memory region defined by `pOut`, `width, `pitch`, and height
//              (through gridDim.y) to value `val32`.
//
// Requires:    `width` and `pitch` is in multiple of bytes.
//              `val32` contains replicated `byte` or `short` values to write as complete `int`s.
//                  - 4 replicated bytes if the element size is 1 byte
//                  - 2 replicated shorts if the element size is 2 bytes
//              Block shape is 1D (x,1,1).
//              Grid shape is 2D (x,height,1).
//
// Note:        Although this kernel can handle any 1D/2D workload, it should only be used for
//              cases when the element size is not 4 bytes.
// ------------------------------------------------------------------------------------------------
extern "C" __global__ void
memset8( char *pOut, unsigned int val32, size_t width, size_t pitch )
{
    size_t idx = threadIdx.x + (size_t)blockIdx.x * blockDim.x;
    const size_t idy = blockIdx.y;
    const size_t warpId = idx >> 5;

    // Compute current row address
    char* pOutRow = pOut + pitch*idy;

    // Compute misalignment, in `byte`s, for the first cache line
    unsigned int misalign = computeMisalignment(pOutRow, MEMORY_ALIGNMENT);
    misalign = ((size_t)misalign < width) ? misalign : (unsigned int)width;

    // ----------------------------------------------------------------------------------
    /*         First warp writes the misaligned bytes in the first cache line          */
    // ----------------------------------------------------------------------------------

    // If we're the first warp and there are misaligned bytes to be set
    if (warpId == 0 && misalign) {
        // Grab the right byte based on index
        char val8 = val32;
        if (idx & 1) {
            val8 = val32 >> 8;
        }

        // FAST PATH : At most only warpSize bytes need to be set. Simply use a thread for
        // every `byte` that needs to be set.
        // 
        if (misalign <= warpSize) {
            if (idx < misalign) {
                pOutRow[ idx ] = val8;
            }
        }
        else {
            // (Slightly) SLOWER PATH : Set the misaligned bytes in two passes
            // 
            // 1st pass - Update those bytes which are not aligned to `int` boundaries 
            const unsigned int misalignedPre = computeMisalignment(pOutRow, INT_SIZE);
            const unsigned int misalignedAft = (misalign - misalignedPre) % INT_SIZE;

            // Mark those bytes which need to be set
            int byteToSet = -1;
            if (idx < misalignedPre) {                     // Bytes prior to the first `int` boundary
                byteToSet = idx;
            }
            if (idx >= (warpSize - misalignedAft)) {       // Bytes after the last `int` boundary
                byteToSet = misalign - warpSize + idx;
            }

            // Actually write those bytes (coalesced)
            if (byteToSet != -1) {
                pOutRow[ byteToSet ] = val8;
            }

            // 2nd pass - Write those bytes which are completely aligned to `int` boundaries
            unsigned int intsToSet = (misalign - misalignedPre) / INT_SIZE;
            if (idx < intsToSet) {
                ((unsigned int*)(pOutRow + misalignedPre))[ idx ] = val32;
            }
        }
    }

    // ----------------------------------------------------------------------------------
    /*                    Every warp writes to a unique cache line                     */
    // ----------------------------------------------------------------------------------
    
    // Change the pointer by number of misaligned bytes (that the first warp has updated)
    pOutRow += misalign;
    width -= misalign;

    // Write as much `int`s as we can
    const size_t stride = (size_t)blockDim.x * gridDim.x;
    const size_t widthInInts = width / INT_SIZE;
    while ( idx < widthInInts ) {
        ((unsigned int*)pOutRow)[ idx ] = val32;
        idx += stride;
    }

    // ----------------------------------------------------------------------------------
    /*           Last warp writes the unaligned bytes in the last cache line           */
    // ----------------------------------------------------------------------------------

    // If we're the last block
    if (blockIdx.x == gridDim.x - 1) {
        misalign = (unsigned int)((uintptr_t)(pOutRow+width) % INT_SIZE);
        // Last warp writes the remaining bytes after the last `int` boundary
        // (width % INT_SIZE) necessary to prevent oversetting bytes
        if ( (width % INT_SIZE) && (threadIdx.x >= blockDim.x - misalign) ) {
            // Grab the right byte based on index
            char val8 = val32;
            if (idx & 1) {
                val8 = val32 >> 8;
            }

            unsigned int i = blockDim.x - threadIdx.x;
            pOutRow[ width - i ] = val8;
        }
    }
}

// ------------------------------------------------------------------------------------------------
// Kernel:      memset32( pOut, val32, width, pitch )
//
// Desc:        Set every `int` in the memory region defined by `pOut`, `width, `pitch`, and height
//              (through gridDim.y) to value `val32`.
//
// Requires:    `pOut` and `pitch` are aligned to `int`.
//              `width` is in multiple of `int`s.
//              `pitch` is in bytes.
//              `val32` represents value to be written as a complete `int`.
//                  - 4 replicated bytes if the element size is 1 byte
//                  - 2 replicated shorts if the element size is 2 bytes
//                  - 1 int if the element size is 4 bytes 
//              Block shape is be 1D (n,1,1).
//              Grid shape is 2D (n,height,1).
//
// Note:        This kernel is slightly faster than memset8 for certain aligned workloads.
// ------------------------------------------------------------------------------------------------
extern "C" __global__ void
memset32( int *pOut, unsigned int val32, size_t width, size_t pitch )
{
    size_t idx = threadIdx.x + (size_t)blockIdx.x * blockDim.x;
    size_t idy = blockIdx.y;

    // Compute current row address
    int* pOutRow = (int*)((char*)pOut + pitch*idy);

    // Compute misalignment, in `byte`s, for the first cache line
    unsigned int misalign = computeMisalignment(pOutRow, MEMORY_ALIGNMENT) / INT_SIZE;
    misalign = ((size_t)misalign < width) ? misalign : (unsigned int)width;

    // ----------------------------------------------------------------------------------
    /*         First warp writes the misaligned bytes in the first cache line          */
    // ----------------------------------------------------------------------------------

    // At most only warpSize * 4 bytes need to be set. Simply use a thread for
    // every `int` that needs to be set. Only the first warp will have `idx < misalign`.
    if (idx < misalign) {
        pOutRow[ idx ] = val32;
    }

    // ----------------------------------------------------------------------------------
    /*                    Every warp writes to a unique cache line                     */
    // ----------------------------------------------------------------------------------

    // Ajust index so that each warp writes to unique cache lines
    idx += misalign;

    // Write as much `int`s as we can
    size_t stride = (size_t)blockDim.x * gridDim.x;
    while (idx < width) {
         pOutRow[ idx ] = val32;
         idx += stride;
    }
}
