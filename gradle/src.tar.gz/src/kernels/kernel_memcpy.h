/*
 * Copyright 2005-2011 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

#ifndef __memcpy_kernel_h__
#define __memcpy_kernel_h__
#include "cuda_types.h"

/**
 * GT200 Optimized memcpy kernels
 */
typedef struct CUkernelMemcpyGT200_st {
    CUmod *mod; 
    CUfunc *memcpyDtoD2D_aligned;
    CUfunc *memcpyDtoD2D_aligned_smallsamepitch;
    CUfunc *memcpyDtoD2D_aligned_smallsamepitch64;
    CUfunc *memcpyDtoD2D_aligned_smalldiffpitch;
    CUfunc *memcpyDtoD2D_aligned_smalldiffpitch64;
    CUfunc *memcpyDtoD2D_unalignedSmallHeight;
    CUfunc *memcpyDtoD2D_unalignedSmallHeight64;
    CUfunc *memcpyDtoD2D_alignedSrcDst;

    CUfunc *memcpyDtoD_aligned;
    CUfunc *memcpyDtoD_aligned64;
    CUfunc *memcpyDtoD_alignedSrcDst;
    CUfunc *memcpyDtoD_alignedSrcDst64;

    CUfunc *memcpyDtoD3D_aligned;
    CUfunc *memcpyDtoD3D_alignedSrcDst;

    // Array-Device, Device-Array, Array-Array copy functions.
    CUfunc *IntAligned_AtoD1D_surf;
    CUfunc *IntAligned_AtoD2D_surf;
    CUfunc *IntAligned_AtoD3D_surf;
    CUfunc *IntAligned_AtoD1DLayered_surf;
    CUfunc *IntAligned_AtoD2DLayered_surf;
    CUfunc *IntAligned_DtoA1D_surf;
    CUfunc *IntAligned_DtoA2D_surf;
    CUfunc *IntAligned_DtoA3D_surf;
    CUfunc *IntAligned_DtoA1DLayered_surf;
    CUfunc *IntAligned_DtoA2DLayered_surf;
    CUfunc *IntAligned_AtoA_surf;

    CUfunc *ShortAligned_AtoD1D_surf;
    CUfunc *ShortAligned_AtoD2D_surf;
    CUfunc *ShortAligned_AtoD3D_surf;
    CUfunc *ShortAligned_AtoD1DLayered_surf;
    CUfunc *ShortAligned_AtoD2DLayered_surf;
    CUfunc *ShortAligned_DtoA1D_surf;
    CUfunc *ShortAligned_DtoA2D_surf;
    CUfunc *ShortAligned_DtoA3D_surf;
    CUfunc *ShortAligned_DtoA1DLayered_surf;
    CUfunc *ShortAligned_DtoA2DLayered_surf;
    CUfunc *ShortAligned_AtoA_surf;

    CUfunc *CharAligned_AtoD1D_surf;
    CUfunc *CharAligned_AtoD2D_surf;
    CUfunc *CharAligned_AtoD3D_surf;
    CUfunc *CharAligned_AtoD1DLayered_surf;
    CUfunc *CharAligned_AtoD2DLayered_surf;
    CUfunc *CharAligned_DtoA1D_surf;
    CUfunc *CharAligned_DtoA2D_surf;
    CUfunc *CharAligned_DtoA3D_surf;
    CUfunc *CharAligned_DtoA1DLayered_surf;
    CUfunc *CharAligned_DtoA2DLayered_surf;
    CUfunc *CharAligned_AtoA_surf;

    // Surfaces and textures for array, device copies.
    CUsurfref isurfref1D;
    CUsurfref osurfref1D;
    CUsurfref isurfref2D;
    CUsurfref osurfref2D;
    CUsurfref isurfref3D;
    CUsurfref osurfref3D;
    CUsurfref isurfref1DLayered;
    CUsurfref osurfref1DLayered;
    CUsurfref isurfref2DLayered;
    CUsurfref osurfref2DLayered;
} CUkernelMemcpyGT200;

CUresult 
gt200KernelMemcpy3DDtoD(
    CUctx *ctx, 
    const CUImemcpyDesc *copyDesc, 
    CUIstream *stream, 
    CUImemcpyCbInfo *copyCbInfo);

CUresult 
gt200KernelMemcpyAtoD(
    CUctx *ctx,
    const CUImemcpyDesc *copyDesc,
    CUIstream *stream, 
    CUImemcpyCbInfo *copyCbInfo);

CUresult 
gt200KernelMemcpyAtoA(
    CUctx *ctx,
    const CUImemcpyDesc *copyDesc,
    CUIstream *stream, 
    CUImemcpyCbInfo *copyCbInfo);

CUresult gt200KernelMemcpyInit(CUctx *ctx);
void     gt200KernelMemcpyDestroy(CUctx *ctx);

/**
 * GF100 optimized 1D memcpy kernels
 */
typedef struct CUkernelMemcpyGF100_st
{
    CUmod *mod;
    // An optimized 1D memcpy kernel to read/write 128bits at a time when
    // both src and dst are 128bit aligned.
    CUfunc *memcpy128;
    // When dst is 128bit aligned but src has no alignment guarantee, an
    // optimized 1D memcpy kernel to read 16*8bits at a time and write
    // 128bits at a time.
    CUfunc *memcpy128_unaligned;
    // Specialized clean-up kernel to write 8bit "fringe" data that
    // occurs after what memcpy128 can set.  This kernel cannot write
    // "fringe" data that exists before what memcpy128 can set.
    CUfunc *memcpy_post;
    // Specialized clean-up kernel to write 8bit "fringe" data that
    // occurs before and after what memcpy128 can set.  This is more
    // general than the memcpy_post kernel, but also slower.
    CUfunc *memcpy_pre_post;
    CUfunc *memcpy32_post;
    CUfunc *memcpy_post_faster;
} CUkernelMemcpyGF100;

CUresult gf100KernelMemcpy1DDtoD(
    CUctx *ctx, 
    const CUImemcpyDesc *copyDesc, 
    CUIstream *stream, 
    CUImemcpyCbInfo *copyCbInfo);

CUresult gf100KernelMemcpy1DInit(CUctx *ctx);
void     gf100KernelMemcpy1DDestroy(CUctx *ctx);

CUresult gk10xKernelMemcpyInit(CUctx *ctx);
void     gk10xKernelMemcpyDestroy(CUctx *ctx);


/**
 * GM10x optimized memcpy kernels
 */
typedef struct CUkernelMemcpyGM10x_st CUkernelMemcpyGM10x;


CUresult gm10xKernelMemcpyInit(CUctx *ctx);
void     gm10xKernelMemcpyDestroy(CUctx *ctx);

NvBool gm10xMemcpyKernelIsSupported(const CUImemcpyDesc *copyDesc);

CUresult gm10xMemcpyKernel(
     CUctx *ctx,
     const CUImemcpyDesc *copyDesc,
     CUIstream *stream,
     CUImemcpyCbInfo *copyCbInfo );

/** 
 * Kernel memcpy handles
 */
typedef struct CUkernelmemcpy_st {
    CUkernelMemcpyGT200 *tesla;
    CUkernelMemcpyGF100 *fermi;
    CUkernelMemcpyGM10x *maxwell;
    
} CUkernelmemcpy;

#endif 
