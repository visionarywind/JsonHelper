/*
 * Copyright 1993-2018 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

#include <nvtypes.h>
#include <cuda_runtime_api.h>
#include <cuda_runtime.h>
#include <cuda.h>
#include "kernel_graph_scheduler.h"

static __device__ void
kernelPCAS(CUpcasPacket pcasPacket, NvU64 pcasAddr)
{
    NvU64 pcasPacketU64 = *(NvU64 *)&(pcasPacket.data);
    // Make sure it uses the 'global memory' version
    // Also make clear that we are trying to use a reduction
    // (red.global.add.u64 is exactly what we want for PCAS)
    asm volatile("red.global.add.u64 [%0],%1;" : : "l"(pcasAddr) , "l"(pcasPacketU64));
}


extern "C" __global__ void
graphScheduler(NvU32 initialCurIndicesOffset, NvU32 initialCurIndicesLen, CUIgraphDeviceNode *nodes, NvU32 *indices, NvU64 pcasAddr)
{
    // This kernel is executed by a single warp.
    //
    // The scheduler maintains a linked list shared by the warp, indicating nodes that need to
    // be processed (meaning it needs to evaluate their successors). The general algorithm is:
    //
    //     list starts with node whose completion triggered the scheduler
    //     while (list not empty) {
    //         single lane {
    //             pop node from list
    //             if (node is conditional and control bit set) {
    //                 select body roots as evaluation set
    //                 reset control bit
    //                 set node's dependency counter to number of body end nodes
    //             }
    //             else {
    //                 select successors as evaluation set
    //                 if (node is conditional)
    //                     release conditional end semaphore
    //             }
    //         }
    //         parallel for (node : evaluation set) {
    //             decrement depedency counter
    //             if (counter is zero) {
    //                 reset counter to predecessor count
    //                 if (node is kernel)
    //                     PCAS
    //                 else {
    //                     sequential {
    //                         push node onto list
    //                     }
    //                 }
    //             }
    //         }
    //     }
    //
    // As an optimization, the kernel is passed not the first node in the list, but rather its
    // list of successors to avoid an extra lookup in the common case (fork/join with no
    // conditional node). So essentially the top-level "single lane" and "parallel" blocks shown
    // here are swapped in the actual code.

    // Linked list of nodes that need to be traversed beyond.
    __shared__ NvU32 pendingTraversalHead;
    // Current index-array slice to be processed.
    __shared__ NvU32 curIndicesOffset;
    __shared__ NvU32 curIndicesLen;

    pendingTraversalHead = cuiGraphDeviceNodeIndexInvalid;
    curIndicesOffset = initialCurIndicesOffset;
    curIndicesLen = initialCurIndicesLen;
    __syncwarp();

    while (true) {
        // "Processing" phase
        for (NvU32 i = threadIdx.x; i < curIndicesLen; i += blockDim.x) {
            NvU32 nodeIdx = indices[curIndicesOffset + i];
            // Prefetch the entire node into cache. Otherwise, since the node spans multiple cache
            // lines and each read is conditional on the previous (atom(nPreds) -> type -> pcas),
            // we will incur non-pipelined fetches of multiple lines.
            CUIgraphDeviceNode nodeCopy = nodes[nodeIdx];

            bool nodeReady = (atomicSub(&nodes[nodeIdx].nPredsRemain, 1u) == 1);
            // If this lane's node has reached a remaining dependency count of zero, process it.
            if (nodeReady) {
                nodes[nodeIdx].nPredsRemain = nodes[nodeIdx].nPreds;
                if (nodeCopy.type == CUI_GRAPH_DEVICE_NODE_TYPE_KERNEL) {
                    // For kernel nodes, processing just means doing the PCAS.
                    kernelPCAS(nodeCopy.data.kernel.pcasPacket, pcasAddr);
                }
                else {
                    // For conditional or empty nodes, put them in the linked list for traversal.
                    // Note: this loop as written cannot be parallelized as the read of
                    // pendingTraversalHead (which is shared memory) needs to see the write from
                    // the previous iteration. Possibly this could be rearchitected and optimized.
                    // However, an excessive amount of lane mask tracking to correctly use the
                    // warp-synchronous intrinsics also has a performance penalty, and the
                    // performance penalty of the loop is unknown and may be small.
                    for (NvU32 lane = 0; lane < blockDim.x; lane++) {
                        if (lane == threadIdx.x) {
                            nodes[nodeIdx].pendingTraversalNext = pendingTraversalHead;
                            pendingTraversalHead = nodeIdx;
                        }
                    }
                }
            }
        }
        __syncwarp();

        // Traversal phase
        NvU32 nodeIdx = pendingTraversalHead;
        if (nodeIdx == cuiGraphDeviceNodeIndexInvalid) {
            break;
        }
        if (threadIdx.x == 0) {
            // Remove the node from the list.
            pendingTraversalHead = nodes[nodeIdx].pendingTraversalNext;
            nodes[nodeIdx].pendingTraversalNext = cuiGraphDeviceNodeIndexInvalid;
            bool haveSelectedIndexSlice = false;
            if (nodes[nodeIdx].type == CUI_GRAPH_DEVICE_NODE_TYPE_CONDITIONAL) {
                if (nodes[nodeIdx].data.conditional.execBody) {
                    // If a conditional node is executing the body, select the body
                    // roots for the processing phase.
                    curIndicesOffset = nodes[nodeIdx].data.conditional.rootsOffset;
                    curIndicesLen = nodes[nodeIdx].data.conditional.nRoots;
                    haveSelectedIndexSlice = true;
                    nodes[nodeIdx].nPredsRemain = nodes[nodeIdx].data.conditional.nBodyEndNodes;
                    nodes[nodeIdx].data.conditional.execBody = 0;
                }
                else if (nodes[nodeIdx].data.conditional.endSemaphore != NULL) {
                    // If a conditional node is not executing the body and has a
                    // semaphore, increment it here.
                    atomicAdd(nodes[nodeIdx].data.conditional.endSemaphore, 1u);
                }
            }
            if (!haveSelectedIndexSlice) {
                // If the node was not a conditional that is executing the body,
                // select the successors for the processing phase.
                curIndicesOffset = nodes[nodeIdx].succsOffset;
                curIndicesLen = nodes[nodeIdx].nSuccs;
            }
        }
        __syncwarp();
    }
}
