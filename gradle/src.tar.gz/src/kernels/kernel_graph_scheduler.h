#ifndef KERNEL_GRAPH_SCHEDULER_H
#define KERNEL_GRAPH_SCHEDULER_H

#include "cuda_types.h"
#include "cuda_etbl/cuda_graphs.h"

struct CUkernelGraphScheduler_st
{
    CUmod  *mod;
    CUfunc *graphScheduler;
};

typedef enum CUIgraphDeviceNodeType_enum {
    CUI_GRAPH_DEVICE_NODE_TYPE_KERNEL = CU_GRAPH_NODE_TYPE_KERNEL,
    // Unused for now but supported by the scheduler kernel
    CUI_GRAPH_DEVICE_NODE_TYPE_EMPTY = CU_GRAPH_NODE_TYPE_EMPTY,
    CUI_GRAPH_DEVICE_NODE_TYPE_CONDITIONAL = CU_GRAPH_NODE_TYPE_EX_CONDITIONAL,
} CUIgraphDeviceNodeType;

static const NvU32 cuiGraphDeviceNodeIndexInvalid = (NvU32)(NvS32)-1;

//
// The device copy of a graph consists of an array of node objects and
// an array of NvU32 indices into the node array, composed as described
// in the field documentation below. These do not have direct links to
// one another; rather, 32 bit indices are used to save space, and
// the base pointers for both arrays are supplied as kernel arguments.
// (The index array must contain only valid indices, i.e. an edge
// cannot be removed by setting a node index to an invalid value.)
//
// The device graph does not necessarily contain all nodes in the
// context. It requires at least 1) scheduler launched kernels, 2)
// nodes that will trigger scheduler launched kernels (directly or
// indirectly), and 3) nodes inbetween these (such as conditionals)
// that the scheduler needs to traverse to get from (2) to (1).
//
// The device graph has some other topological changes from the host
// graph, related to implementation of conditional nodes. Both the
// actual predecessors of a conditional, as well as the terminal nodes
// of the conditional body, are treated as predecessors of the
// conditional in the device graph and wired up with a dependency edge.
// Manipulation of nPreds controls behavior of the conditional. It is
// initially set to the number of actual predecessors. When nPreds
// reaches 0 and the conditional is evaluated, if the body is to be
// executed, nPreds is reset to the number of terminal body nodes.
// Otherwise it is reset to the number of actual predecessors. This
// way, the normal dependency count logic works for the conditional
// node as well without special casing (until it is time to reset the
// dependency count).
//
struct CUIgraphDeviceNode_st {
    CUIgraphDeviceNodeType type;
    // A slice of the index array containing this node's successors.
    NvU32 nSuccs;
    NvU32 succsOffset;
    // The number of predecessors of this node.
    NvU32 nPreds;
    // The number of predecessors which have not yet completed. When
    // this reaches zero, the scheduler processes this node and resets
    // the counter.
    NvU32 nPredsRemain;
    NvU32 pendingTraversalNext;
    // Type-specific data.
    union {
        struct {
            CUpcasPacket pcasPacket;
        } kernel;
        struct {
            // A slice of the index array containing the root nodes
            // of the conditional body.
            NvU32 nRoots;
            NvU32 rootsOffset;
            // The number of sink (terminal) nodes in the conditional
            // body.
            NvU32 nBodyEndNodes;
            // If this is nonzero when the scheduler processes the
            // conditional node, the scheduler will launch the body.
            // Otherwise it will launch the nodes downstream of the
            // conditional node. The scheduler resets the value to
            // zero when the conditional is processed. It can be set
            // again to nonzero value anywhere inside the conditional
            // body to implement a loop.
            NvU32 execBody;
            NvU32 *endSemaphore;
        } conditional;
    } data;
};

// Initialize/destroy scheduler kernels
CUresult kernelGraphSchedulerInit(CUctx *ctx);
void kernelGraphSchedulerDestroy(CUctx *ctx);

#endif // KERNEL_GRAPH_SCHEDULER_H
