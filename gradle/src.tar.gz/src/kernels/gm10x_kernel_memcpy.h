#ifndef GM10X_KERNEL_MEMCPY_H
#define GM10X_KERNEL_MEMCPY_H

#include "cuda_types.h"

// File:    gm10x_kernel_memcpy.h 
//
// Desc:    This file defines macros and constants which are used by 
//          gm10x_kernel_memcpy.c and gm10x_kernel_memcpy.cu.
//
//          ********************************************************************
//          *** If you change any of the values here, you need to regenerate ***
//          *** the precompiled kernel "gm10x_kernel_memcpy.cubins.c"!       ***
//          ********************************************************************
//
// Notes:   The gm10x memcpy kernels subdivide each row to be copied into 3 sections: fore, mid, aft.
//
//          The 'mid' section is nicely aligned, and is copied using unsigned ints (4-bytes at a time)
//          ("Nicely aligned" means the address falls on a GM10X_MISALIGNED_MEMCPY_MID_SECTION_ALIGNMENT_MODULUS
//          boundary, defined below)
//
//          The 'fore' and 'aft' sections of each row is whatever is not included in the 'mid' section,
//          and these are copied as single byte-at-a-time.
//
//
// Example: For the purpose of this example, assume "nicely aligned" means 16-byte aligned.
//
//          Imagine a random memory buffer.  This buffer does not start on a 16-byte aligned address,  
//          but rather is 2 bytes off that.
//
//      byte alignment: |               |               |               |               |
//                      0123456789ABCDEF0123456789ABCDEF0123456789ABCDEF0123456789ABCDEF0123456789ABCDEF
//      buffer            ************************************************************************
//                        |             |                                                      | |
//      speed             |             |<--------------- fast-------------------------------->| |
//                        |<--slow----->|                                                      |-| slow
//      zone                    fore                            middle                          aft
//
//
//          * The 'fore' zone is 14 bytes long, and is slow to write, b/c it is non-aligned
//          * The 'middle' zone is the 'sweet spot', where we can write at max speed
//          * The 'aft' zone is 3 bytes long, and is slow to write, b/c it's non-aligned
//
//          If the buffer is sufficiently large, copying the buffer 'by zones' will dramatically 
//          increase performance.
//

// Macro:   GM10X_MISALIGNED_MEMCPY_MID_SECTION_ALIGNMENT_MODULUS
//
// Desc:    Defines the byte-aligmnent of the 'mid' section of each row.
//          The 'mid' section of each row will be aligned on this boundary.
//
//          Must be a power of 2
//          Must be >= sizeof(int)
//
// Notes:   There is a tradeoff to this value: the larger the
//          value, the faster the aligned copy will go, but you can also
//          have more "misaligned" bytes per row,
//          and those values will be copied as single byte-at-a-time.
// 
#define GM10X_MISALIGNED_MEMCPY_MID_SECTION_ALIGNMENT_MODULUS       (16)

// Macro:   GM10X_MISALIGNED_MEMCPY_MID_SECTION_ELEMENT_TYPE
//
// Desc:    This is the numeric type of the 'mid' section of each row.
//          The mid section will be copied using operations which work on
//          this element type.  (e.g. if you want to change the algorithm to
//          copy using 64-bit unsigned integers, change this type)
#define GM10X_MISALIGNED_MEMCPY_MID_SECTION_ELEMENT_TYPE            unsigned int


// Macro:   GM10X_MISALIGNED_MEMCPY_MID_SECTION_ELEMENT_SIZE 
//
// Desc:    This is the quantum of copying of the 'mid' section of each row.
#define GM10X_MISALIGNED_MEMCPY_MID_SECTION_ELEMENT_SIZE            (sizeof(GM10X_MISALIGNED_MEMCPY_MID_SECTION_ELEMENT_TYPE))

// Macro:   GM10X_MISALIGNED_MEMCPY_AFT_SECTION_ALIGNMENT_MODULUS
//
// Desc:    Defines the byte-aligment of the 'aft' section.
//          The 'aft' section always begins on the same alignment
//          as an element of the 'mid' section.
#define GM10X_MISALIGNED_MEMCPY_AFT_SECTION_ALIGNMENT_MODULUS       GM10X_MISALIGNED_MEMCPY_MID_SECTION_ELEMENT_SIZE

// Macro:   GM10X_MISALIGNED_MEMCPY_MAX_FORE_SIZE
//
// Desc:    This is the maximum # of bytes in the 'fore' section of a row.
#define GM10X_MISALIGNED_MEMCPY_MAX_FORE_SIZE                       (GM10X_MISALIGNED_MEMCPY_MID_SECTION_ALIGNMENT_MODULUS-1)

// Macro:   GM10X_MISALIGNED_MEMCPY_MAX_AFT_SIZE
//
// Desc:    This is the maximum # of bytes in the 'aft' section of a row
//          The max length of the 'aft' section is two 'mid' section elements
//          minus one byte. 
//
#define GM10X_MISALIGNED_MEMCPY_MAX_AFT_SIZE                        ((2*GM10X_MISALIGNED_MEMCPY_MID_SECTION_ELEMENT_SIZE)-1)

// Macro:   GM10X_MISALIGNED_MEMCPY_MAX_MISALIGNED_BYTES_PER_ROW
//
// Desc:    This is the maximum # of bytes per row that can fall outside of the
//          'mid' section.
//  
#define GM10X_MISALIGNED_MEMCPY_MAX_MISALIGNED_BYTES_PER_ROW        (GM10X_MISALIGNED_MEMCPY_MAX_FORE_SIZE+GM10X_MISALIGNED_MEMCPY_MAX_AFT_SIZE)


struct CUkernelMemcpyGM10x_st
{
    CUmod  *mod;
    // D-to-D kernels
    CUfunc *memcpyDtoD3DAligned;    // <- src and dst are both aligned
    CUfunc *memcpyDtoD3DMisaligned; // <- src or dst can be misaligned

    // D-to-A kernels
    CUfunc *memcpyD3DtoA2D;
    CUfunc *memcpyD3DtoA3D;

    // A-to-D kernels        
    CUfunc *memcpyA2DtoD3D;
    CUfunc *memcpyA3DtoD3D;
    
    // A-to-A kernels
    CUfunc *memcpyA2DtoA2D;
    CUfunc *memcpyA2DtoA3D;
    CUfunc *memcpyA3DtoA2D;
    CUfunc *memcpyA3DtoA3D;

    // Surfaces    
    CUsurfref isurfref2D;
    CUsurfref osurfref2D;
    CUsurfref isurfref3D;
    CUsurfref osurfref3D;
};

// GM10X_KERNEL_MODE_* values
//
// These #defines correspond to the value of  globals.enableMaxwellKernelMemcpy
//
//  MODE_DISABLED means don't use the gm10x kernels.
//  MODE_NORMAL means use the gm10x kernels only when they are faster than the gt200 kernels
//  MODE_FORCE means use the gm10x kernels always, even when they are slower than gt200 kernels
//
#define GM10X_MEMCPY_KERNEL_MODE_DISABLED     0
#define GM10X_MEMCPY_KERNEL_MODE_NORMAL       1
#define GM10X_MEMCPY_KERNEL_MODE_FORCE        2

#endif // GM10X_KERNEL_MEMCPY_H

