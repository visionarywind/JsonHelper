/*
 * Copyright 2005-2016 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */


#include <limits.h>


#include "kernel_internal.h"
#include "kernel_memcpy_internal.h"
#include "kernel_memcpy.h"
#include "bikernels.h"
#include "cuimemcpy.h"
#include "cuiarray.h"
#include "cuda_globals.h"
#include "gm10x_kernel_memcpy.h"

typedef enum MemcpyAlignmentType_enum
{
    MISALIGNED,     // not aligned on a useful boundary
    ALIGNED_4B,     // aligned on a 4-byte boundary
    ALIGNED_16B,    // aligned on a 16-byte boundary

    MEMCPY_ALIGNMENT_TYPE_NUM_ENUMS // always last
} MemcpyAlignmentType;

typedef enum MemcpyKind_enum
{
    MEMCPY_KIND_A_TO_A, // copy Array-to-Array
    MEMCPY_KIND_A_TO_D, // copy Array-to-DevicePtr
    MEMCPY_KIND_D_TO_A, // copy DevicePtr-to-Array
    MEMCPY_KIND_D_TO_D, // copy DevicePtr-to-DevicePtr
    MEMCPY_KIND_NUM_EMUMS // always last!
} MemcpyKind;

typedef enum MemcpyQuality_enum
{
    UNSUPPORTED,  // This type of memcpy is not supported by this implementation
    WORSE,        // generally not as fast as base implementation
    EQUAL,        // generally approx the same speed as base implementation
    BETTER        // generally faster than base implementation
} MemcpyQuality;


typedef struct MemcpyRect_st
{
    CUImemcpyPoint  origin;
    CUImemcpyExtent size;
} MemcpyRect;


// Information about one Memcpy surface (either source or destination)
typedef struct MemcpyBufferInfo_st
{
    NvU64               pitch;
    NvU64               height;
    MemcpyAlignmentType alignment;
} MemcpyBufferInfo;

// information about the memcpy operation
typedef struct MemcpyInfo_st
{
    MemcpyKind          kind;
    MemcpyQuality       quality;
    NvU32               numDimensions; // 1, 2, or 3
    NvU64               width, height, depth; // sanitized values, height & depth never zero.
    MemcpyAlignmentType alignment;
    MemcpyBufferInfo    src;
    MemcpyBufferInfo    dst;
} MemcpyInfo;

// This struct controls the grid and block widths for a kernel.
//
// If ptr-to-func 'tune' is defined, that func will be called to set the
// grid and block widths.
//
// If ptr-to-func 'tune' is NULL, the grid and block
// widths will be set to the supplied values of fields
// 'gridWidth' and 'blockWidth'.
//
// See func configureGridAndBlockWidth() for more details.
//
typedef struct CUkernelMemcpyGM10xTuningParams_st
{
    NvU32   gridWidth;
    NvU32   blockWidth;
    void    (*tune)( NvU32 numEltsX, NvU32* gridWidth /*out*/, NvU32* blockWidth /*out*/ );
} CUkernelMemcpyGM10xTuningParams;

// A collection of all the parameters we pass to misc functions
typedef struct MemcpyCommonParams_st
{
    CUctx *ctx;
    const CUImemcpyDesc *copyDesc;
    CUIstream *stream;
    CUImemcpyCbInfo *copyCbInfo;
    MemcpyInfo copyInfo;
    const CUkernelMemcpyGM10xTuningParams *tuning;
} MemcpyCommonParams;

//
// These kernels are not particularly sensitive to grid/block size.
//
//   *  1D copies are especially sensitive to grid/block size, but for 1D we don't
//      use these kernels, we use the fermi and gt200 kernels.
//
//   *  2D and 3D copies are not very sensitive to grid/block size.
//      I tried all kinds of variations, and for any non-trivially-sized
//      copy, they all profile about the same.
//
// Profiling has shown these values to be generally 'good'.
//
#define OPTIMUM_BLOCKSIZE_X (1024)
#define OPTIMUM_GRIDSIZE_X (8)

static const CUkernelMemcpyGM10xTuningParams g_defaultTuningParams ={ OPTIMUM_GRIDSIZE_X, OPTIMUM_BLOCKSIZE_X, NULL };

//typedef enum CUImemcpyDataType_enum {
//    CUI_MEMCPY_DATA_TYPE_ARRAY,
//    CUI_MEMCPY_DATA_TYPE_MEMOBJ,
//    CUI_MEMCPY_DATA_TYPE_VA,
//    CUI_MEMCPY_DATA_TYPE_PAGEABLE,
//} CUImemcpyDataType;

static const MemcpyKind g_memcpyKindTable[ 3 /*src*/ ][3 /*dst*/ ] =
{
   { MEMCPY_KIND_A_TO_A, MEMCPY_KIND_A_TO_D, MEMCPY_KIND_A_TO_D  },
   { MEMCPY_KIND_D_TO_A, MEMCPY_KIND_D_TO_D, MEMCPY_KIND_D_TO_D  },
   { MEMCPY_KIND_D_TO_A, MEMCPY_KIND_D_TO_D, MEMCPY_KIND_D_TO_D  },
};

// ----------------------------------------------------------------------------------------
// Func:    getMemcpyKind( copyDesc )
//
// Desc:    returns the appropiate MemcpyKind enum for the given copy request.
// ----------------------------------------------------------------------------------------
static MemcpyKind
getMemcpyKind( const CUImemcpyDesc *copyDesc )
{
    MemcpyKind kind;
    CU_ASSERT( copyDesc );
    CU_ASSERT( copyDesc->src.type < CUI_MEMCPY_DATA_TYPE_PAGEABLE );
    CU_ASSERT( copyDesc->dst.type < CUI_MEMCPY_DATA_TYPE_PAGEABLE );
    kind = g_memcpyKindTable[ copyDesc->src.type ][ copyDesc->dst.type ];
    return kind;
}

// ----------------------------------------------------------------------------------------
// Func:    initMemcpyBufferInfo( bufferInfo, operand, width )
//
// Desc:    Initialize a 'MemcpyBufferInfo' struct.
//
//          The MemcpyBufferInfo struct holds all the relevent information about
//          one of the buffers used in the memcpy (source or destination)
//
//          Most of this information is already in the CUImemcpyDesc struct,
//          but it's not convenient to get at, b/c CUIMemcpyOperand is a variant
//          record, so attributes like 'pitch' and 'height' are in different
//          fields depending on what type of memory is being used.
// ----------------------------------------------------------------------------------------
static void
initMemcpyBufferInfo( MemcpyBufferInfo *bufferInfo, const CUImemcpyOperand *op, NvU64 width )
{
    NvU32 baseAlignment, pitchAlignment;
    CU_ASSERT( bufferInfo );
    CU_ASSERT( op );

    memset( bufferInfo, 0, sizeof(MemcpyBufferInfo) );

    switch( op->type ) {
        case CUI_MEMCPY_DATA_TYPE_MEMOBJ:
            bufferInfo->pitch      = (op->memobj.pitch) ? op->memobj.pitch : width;
            bufferInfo->height     = MAX(op->memobj.height, 1 );
            baseAlignment          = (NvU32) cuiMemcpyOperandGetOriginAddr( op );
            pitchAlignment         = (NvU32) bufferInfo->pitch;
            break;

        case CUI_MEMCPY_DATA_TYPE_ARRAY:
            bufferInfo->pitch      = (op->array.array->desc.Width);
            bufferInfo->height     = (op->array.array->desc.Height);
            baseAlignment          = (NvU32) (op->origin.xInBytes);
            pitchAlignment         = 0; // for cudaArrays, the pitch is always aligned
            break;

        case CUI_MEMCPY_DATA_TYPE_VA:
            bufferInfo->pitch      = (op->va.pitch) ? op->va.pitch : width;
            bufferInfo->height     = MAX(op->va.height, 1 );
            baseAlignment          = (NvU32) cuiMemcpyOperandGetOriginAddr( op );
            pitchAlignment         = (NvU32) bufferInfo->pitch;
            break;

        case CUI_MEMCPY_DATA_TYPE_PAGEABLE:
            // This should never happen. Host-Pageable mem is copied to Host-Pinned
            // mem, and then kernel-mempcy is performed on the Host-Pinned memory
            // (which looks to us like a MEMOBJ).
            CU_ASSERT( 0 && "Pageable memory should never reach memcpy kernels");
            break;
        default:
            CU_ASSERT( 0 && "Unrecognized CUImemcpyOperand.type value.");
    }


    // compute the 'alignment' of the buffer
    // Note: we should ignore 'pitch' if this is a 1D buffer.
    if ((baseAlignment%16 == 0) && (pitchAlignment %16 == 0)) {
        bufferInfo->alignment = ALIGNED_16B;
    }
    else if ((baseAlignment%4 == 0) && (pitchAlignment%4 == 0)) {
        bufferInfo->alignment = ALIGNED_4B;
    }
    else {
        bufferInfo->alignment = MISALIGNED;
    }
}


// ----------------------------------------------------------------------------------------
// Func:    getOffsetIntoMemcpyBuffertMemcpyInfo( memcpyInfo, xyz )
//
// Desc:    Returns the offset (in bytes) of pixel (x,y,z) from the base of the memcpy buffer.
// ---------------------------------------------------------------------------------------
static size_t
getOffsetIntoMemcpyBuffer( const MemcpyBufferInfo *info, const CUImemcpyPoint *xyz )
{
    NvU64 xyzOffset = CUDA_3DOFFSET( xyz->xInBytes, xyz->y, xyz->z, info->pitch, info->height );
    return (size_t) xyzOffset;
}

// Var:     g_memcpyQualityTable[ kind ][ dimensions ][ aligmnent ][ pitch ];
//
// Desc:    This table defines how well the gm10x memcpy kernels perform versus the
//          standard gt200 kernels.  If the gm10x kernel isn't faster than the
//          equivelent gt200 kernel, then we just use the gt200 kernel.
//
//          The values in this table were generated by timing the same memcpy tests
//          using the gt200 kernels and the gm10x kernels on a gm204 card.
//
// Idea:    For future improvement, replace the 'quality' value with a 'size' threshold.
//          i.e. the 'widthInBytes' at which it's faster to use the gm10x kernel vs
//          the gt200 kernel.   The gm10x memcpy kernels have more overhead than the
//          gt200 kernels, so for small copies, it may be faster to use the GT200
//          kernels, even for cases where the gm10x kernel is faster for larger copies.
//
static const MemcpyQuality g_memcpyQualityTable[/*kind*/MEMCPY_KIND_NUM_EMUMS][/*dimensions*/3][/*alignment*/3][/*copywidth*/2] =
{
// Kind                     Dims    Row Alignment   CopyWidth       Quality
// -------------------      ----    --------------  -------------   ----------------
/* MEMCPY_KIND_A_TO_A       1D      MISALIGNED      MISALIGNED */   WORSE,
/* MEMCPY_KIND_A_TO_A       1D      MISALIGNED      ALIGNED_4B */   BETTER,
/* MEMCPY_KIND_A_TO_A       1D      ALIGNED_4B      MISALIGNED */   WORSE,
/* MEMCPY_KIND_A_TO_A       1D      ALIGNED_4B      ALIGNED_4B */   BETTER,
/* MEMCPY_KIND_A_TO_A       1D      ALIGNED_16B     MISALIGNED */   BETTER,
/* MEMCPY_KIND_A_TO_A       1D      ALIGNED_16B     ALIGNED_4B */   BETTER,

/* MEMCPY_KIND_A_TO_A       2D      MISALIGNED      MISALIGNED */   BETTER,
/* MEMCPY_KIND_A_TO_A       2D      MISALIGNED      ALIGNED_4B */   BETTER,
/* MEMCPY_KIND_A_TO_A       2D      ALIGNED_4B      MISALIGNED */   BETTER,
/* MEMCPY_KIND_A_TO_A       2D      ALIGNED_4B      ALIGNED_4B */   WORSE,
/* MEMCPY_KIND_A_TO_A       2D      ALIGNED_16B     MISALIGNED */   BETTER,
/* MEMCPY_KIND_A_TO_A       2D      ALIGNED_16B     ALIGNED_4B */   WORSE,


/* MEMCPY_KIND_A_TO_A       3D      MISALIGNED      MISALIGNED */   BETTER,
/* MEMCPY_KIND_A_TO_A       3D      MISALIGNED      ALIGNED_4B */   BETTER,
/* MEMCPY_KIND_A_TO_A       3D      ALIGNED_4B      MISALIGNED */   BETTER,
/* MEMCPY_KIND_A_TO_A       3D      ALIGNED_4B      ALIGNED_4B */   BETTER,
/* MEMCPY_KIND_A_TO_A       3D      ALIGNED_16B     MISALIGNED */   BETTER,
/* MEMCPY_KIND_A_TO_A       3D      ALIGNED_16B     ALIGNED_4B */   BETTER,
// ===================================================================================
/* MEMCPY_KIND_A_TO_D       1D      MISALIGNED      MISALIGNED */   BETTER,
/* MEMCPY_KIND_A_TO_D       1D      MISALIGNED      ALIGNED_4B */   WORSE,
/* MEMCPY_KIND_A_TO_D       1D      ALIGNED_4B      MISALIGNED */   BETTER,
/* MEMCPY_KIND_A_TO_D       1D      ALIGNED_4B      ALIGNED_4B */   BETTER,
/* MEMCPY_KIND_A_TO_D       1D      ALIGNED_16B     MISALIGNED */   BETTER,
/* MEMCPY_KIND_A_TO_D       1D      ALIGNED_16B     ALIGNED_4B */   WORSE,

/* MEMCPY_KIND_A_TO_D       2D      MISALIGNED      MISALIGNED */   BETTER,
/* MEMCPY_KIND_A_TO_D       2D      MISALIGNED      ALIGNED_4B */   BETTER,
/* MEMCPY_KIND_A_TO_D       2D      ALIGNED_4B      MISALIGNED */   BETTER,
/* MEMCPY_KIND_A_TO_D       2D      ALIGNED_4B      ALIGNED_4B */   BETTER,
/* MEMCPY_KIND_A_TO_D       2D      ALIGNED_16B     MISALIGNED */   BETTER,
/* MEMCPY_KIND_A_TO_D       2D      ALIGNED_16B     ALIGNED_4B */   WORSE,

/* MEMCPY_KIND_A_TO_D       3D      MISALIGNED      MISALIGNED */   BETTER,
/* MEMCPY_KIND_A_TO_D       3D      MISALIGNED      ALIGNED_4B */   BETTER,
/* MEMCPY_KIND_A_TO_D       3D      ALIGNED_4B      MISALIGNED */   BETTER,
/* MEMCPY_KIND_A_TO_D       3D      ALIGNED_4B      ALIGNED_4B */   WORSE,
/* MEMCPY_KIND_A_TO_D       3D      ALIGNED_16B     MISALIGNED */   BETTER,
/* MEMCPY_KIND_A_TO_D       3D      ALIGNED_16B     ALIGNED_4B */   WORSE,

// ===================================================================================
/* MEMCPY_KIND_D_TO_A       1D      MISALIGNED      MISALIGNED */   BETTER,
/* MEMCPY_KIND_D_TO_A       1D      MISALIGNED      ALIGNED_4B */   BETTER,
/* MEMCPY_KIND_D_TO_A       1D      ALIGNED_4B      MISALIGNED */   WORSE,
/* MEMCPY_KIND_D_TO_A       1D      ALIGNED_4B      ALIGNED_4B */   BETTER,
/* MEMCPY_KIND_D_TO_A       1D      ALIGNED_16B     MISALIGNED */   BETTER,
/* MEMCPY_KIND_D_TO_A       1D      ALIGNED_16B     ALIGNED_4B */   WORSE,

/* MEMCPY_KIND_D_TO_A       2D      MISALIGNED      MISALIGNED */   BETTER,
/* MEMCPY_KIND_D_TO_A       2D      MISALIGNED      ALIGNED_4B */   BETTER,
/* MEMCPY_KIND_D_TO_A       2D      ALIGNED_4B      MISALIGNED */   BETTER,
/* MEMCPY_KIND_D_TO_A       2D      ALIGNED_4B      ALIGNED_4B */   WORSE,
/* MEMCPY_KIND_D_TO_A       2D      ALIGNED_16B     MISALIGNED */   BETTER,
/* MEMCPY_KIND_D_TO_A       2D      ALIGNED_16B     ALIGNED_4B */   WORSE,

/* MEMCPY_KIND_D_TO_A       3D      MISALIGNED      MISALIGNED */   BETTER,
/* MEMCPY_KIND_D_TO_A       3D      MISALIGNED      ALIGNED_4B */   BETTER,
/* MEMCPY_KIND_D_TO_A       3D      ALIGNED_4B      MISALIGNED */   BETTER,
/* MEMCPY_KIND_D_TO_A       3D      ALIGNED_4B      ALIGNED_4B */   BETTER,
/* MEMCPY_KIND_D_TO_A       3D      ALIGNED_16B     MISALIGNED */   BETTER,
/* MEMCPY_KIND_D_TO_A       3D      ALIGNED_16B     ALIGNED_4B */   WORSE,
// ===================================================================================
/* MEMCPY_KIND_D_TO_D       1D      MISALIGNED      MISALIGNED */   EQUAL,
/* MEMCPY_KIND_D_TO_D       1D      MISALIGNED      ALIGNED_4B */   EQUAL,
/* MEMCPY_KIND_D_TO_D       1D      ALIGNED_4B      MISALIGNED */   EQUAL,
/* MEMCPY_KIND_D_TO_D       1D      ALIGNED_4B      ALIGNED_4B */   EQUAL,
/* MEMCPY_KIND_D_TO_D       1D      ALIGNED_16B     MISALIGNED */   EQUAL,
/* MEMCPY_KIND_D_TO_D       1D      ALIGNED_16B     ALIGNED_4B */   EQUAL,

/* MEMCPY_KIND_D_TO_D       2D      MISALIGNED      MISALIGNED */   BETTER,
/* MEMCPY_KIND_D_TO_D       2D      MISALIGNED      ALIGNED_4B */   BETTER,
/* MEMCPY_KIND_D_TO_D       2D      ALIGNED_4B      MISALIGNED */   BETTER,
/* MEMCPY_KIND_D_TO_D       2D      ALIGNED_4B      ALIGNED_4B */   WORSE,
/* MEMCPY_KIND_D_TO_D       2D      ALIGNED_16B     MISALIGNED */   BETTER,
/* MEMCPY_KIND_D_TO_D       2D      ALIGNED_16B     ALIGNED_4B */   WORSE,

/* MEMCPY_KIND_D_TO_D       3D      MISALIGNED      MISALIGNED */   BETTER,
/* MEMCPY_KIND_D_TO_D       3D      MISALIGNED      ALIGNED_4B */   BETTER,
/* MEMCPY_KIND_D_TO_D       3D      ALIGNED_4B      MISALIGNED */   BETTER,
/* MEMCPY_KIND_D_TO_D       3D      ALIGNED_4B      ALIGNED_4B */   BETTER,
/* MEMCPY_KIND_D_TO_D       3D      ALIGNED_16B     MISALIGNED */   BETTER,
/* MEMCPY_KIND_D_TO_D       3D      ALIGNED_16B     ALIGNED_4B */   BETTER,

// ===================================================================================
};


// ----------------------------------------------------------------------------------------
// Func:    evalMemcpyQuality( memcpyInfo )
//
// Desc:    Evaluate the 'quality' (goodness) of the gm10x memcpy kernel for the
//          requested memcpy operation, versus the existing gt200 kernels.
//
//          The gm10x kernels are faster in some cases, but not all.  If the
//          gm10x kernels are not faster, we don't use them.
// ----------------------------------------------------------------------------------------
static MemcpyQuality
evalMemcpyQuality( const MemcpyInfo *memcpyInfo )
{
    MemcpyQuality quality = UNSUPPORTED;
    NvBool pitchIs4ByteAligned;

    CU_ASSERT( memcpyInfo );
    CU_ASSERT( memcpyInfo->kind < MEMCPY_KIND_NUM_EMUMS );
    CU_ASSERT( memcpyInfo->alignment < MEMCPY_ALIGNMENT_TYPE_NUM_ENUMS );
    CU_ASSERT( memcpyInfo->numDimensions > 0 && memcpyInfo->numDimensions <= 3 );

    pitchIs4ByteAligned = (memcpyInfo->width%4 == 0);

    quality = g_memcpyQualityTable[memcpyInfo->kind][ memcpyInfo->numDimensions-1 ][ memcpyInfo->alignment ][ pitchIs4ByteAligned ];

    return quality;
}

static NvU32 getMemcpyOperandArrayDimensions( const CUImemcpyOperand *op  );

// ----------------------------------------------------------------------------------------
// Func:    memcpyOperandIsSupportedByMaxwellMemcpyKernel( memcpyOperand )
//
// Desc:    Returns TRUE if the requested memcpy operand-type is supported
//          by custom Maxwell kernels.
// ----------------------------------------------------------------------------------------
static NvBool
memcpyOperandIsSupportedByMaxwellMemcpyKernel( const CUImemcpyOperand *op )
{
    NvBool supported = NV_FALSE;

    switch( op->type ) {
        case CUI_MEMCPY_DATA_TYPE_VA:
        case CUI_MEMCPY_DATA_TYPE_MEMOBJ:
            supported = NV_TRUE;
            break;

        case CUI_MEMCPY_DATA_TYPE_ARRAY:
            switch (op->array.array->type) {
                case CUI_ARRAY_TYPE_1D:
                case CUI_ARRAY_TYPE_2D:
                case CUI_ARRAY_TYPE_3D:
                    supported = NV_TRUE;
                    break;

                case CUI_ARRAY_TYPE_1D_LAYERED:
                case CUI_ARRAY_TYPE_2D_LAYERED:
                case CUI_ARRAY_TYPE_CUBEMAP:
                case CUI_ARRAY_TYPE_CUBEMAP_LAYERED:
                case CUI_ARRAY_TYPE_INVALID:
                    supported = NV_FALSE;
                    break;
                default:
                    CU_ASSERT( 0 && "Unrecognized CUIarrayType value");
            }
            break;
        case CUI_MEMCPY_DATA_TYPE_PAGEABLE:
            supported = NV_FALSE;
            break;

        default:
            CU_ASSERT( 0 && "Unrecognized CUImemcpyOperand.type value.");
    }
    return supported;
}

// ----------------------------------------------------------------------------------------
// Func:    isSupportedByMaxwellMemcpyKernels( copyDesc )
//
// Desc:    Returns TRUE if the requested memcpy operation can be handled by the
//          maxwell kernels.
// ----------------------------------------------------------------------------------------
static NvBool
isSupportedByMaxwellMemcpyKernels( const CUImemcpyDesc *copyDesc )
{
    NvBool maxwellKernelsEnabled = (globals.enableMaxwellKernelMemcpy > GM10X_MEMCPY_KERNEL_MODE_DISABLED);
    NvBool memOperandsAreSupported = (
        memcpyOperandIsSupportedByMaxwellMemcpyKernel( &copyDesc->src ) &&
        memcpyOperandIsSupportedByMaxwellMemcpyKernel( &copyDesc->dst ) );
    NvBool isSupported;

    isSupported = (maxwellKernelsEnabled && memOperandsAreSupported);

    return isSupported;
}

// ----------------------------------------------------------------------------------------
// Func:    getMemcpyOperandArrayDimensions( memcpyOperand )
//
// Desc:    Given a 'CUImemcpyOperand' struct which is an array,
//          returns the # of dimensions of that array.
//
//          If the operand is not an array, returns zero.
// ----------------------------------------------------------------------------------------
static NvU32
getMemcpyOperandArrayDimensions( const CUImemcpyOperand *op  )
{
    NvU32 numDimensions = 0;

    if ( op->type == CUI_MEMCPY_DATA_TYPE_ARRAY) {
        switch (op->array.array->type) {
            case CUI_ARRAY_TYPE_1D:
            case CUI_ARRAY_TYPE_1D_LAYERED:
                numDimensions = 1;
                break;

            case CUI_ARRAY_TYPE_2D:
            case CUI_ARRAY_TYPE_2D_LAYERED:
            case CUI_ARRAY_TYPE_CUBEMAP:
            case CUI_ARRAY_TYPE_CUBEMAP_LAYERED:
                numDimensions = 2;
                break;

            case CUI_ARRAY_TYPE_3D:
                numDimensions = 3;
                break;

            default:
                numDimensions = 0;
        }
    }
    return numDimensions;
}

// ----------------------------------------------------------------------------------------
// Func:    evalMemcpyDimensions( memcpyInfo, copyDesc )
//
// Desc:    Evaluate the # of dimensions (1,2,3) of the requested memcpy.
//          If either of the memcpy operands is an array, then the
//          # of dimensions specified in the array is the # of
//          dimensions in the copy.
//
//          If neither operand is an array, then the # of dimensions
//          is inferred by the # of dimensions requested to be copied.
// ----------------------------------------------------------------------------------------
static NvU32
evalMemcpyDimensions( const MemcpyInfo *memcpyInfo,  const CUImemcpyDesc *copyDesc )
{
    NvU32 numDimensions = 0; // final result
    NvU32 copyRectDimensions = (memcpyInfo->depth>1) ? 3 : (memcpyInfo->height>1) ? 2 : 1;     
    NvBool srcIsArray = (copyDesc->src.type == CUI_MEMCPY_DATA_TYPE_ARRAY);
    NvBool dstIsArray = (copyDesc->dst.type == CUI_MEMCPY_DATA_TYPE_ARRAY);

    if (srcIsArray && dstIsArray) {
        NvU32 srcDimensions = getMemcpyOperandArrayDimensions( &copyDesc->src );   
        NvU32 dstDimensions = getMemcpyOperandArrayDimensions( &copyDesc->dst ); 
        numDimensions = MIN( srcDimensions, dstDimensions );        
    }
    else if (srcIsArray) {
        numDimensions = getMemcpyOperandArrayDimensions( &copyDesc->src );
    }
    else if (dstIsArray) {
        numDimensions = getMemcpyOperandArrayDimensions( &copyDesc->dst );        
    }
    else {
        // infer # of dimensions from copy size
        numDimensions = copyRectDimensions;      
    }
    
    CU_ASSERT( (numDimensions >= copyRectDimensions) && "requested copy size has more dimensions than surface");
    return numDimensions;
}

// ----------------------------------------------------------------------------------------
// Func:    initMemcpyInfo( memcpyInfo, copyDesc )
//
// Desc:    Initialize a 'MemcpyInfo' struct.
// ----------------------------------------------------------------------------------------
static void
initMemcpyInfo( MemcpyInfo *memcpyInfo,  const CUImemcpyDesc *copyDesc )
{
    CU_ASSERT( memcpyInfo );
    CU_ASSERT( copyDesc );

    memset( memcpyInfo, 0, sizeof(MemcpyInfo) ); 

    memcpyInfo->kind    = getMemcpyKind( copyDesc );
    memcpyInfo->width   = copyDesc->extent.widthInBytes;
    memcpyInfo->height  = MAX( 1, copyDesc->extent.height );
    memcpyInfo->depth   = MAX( 1, copyDesc->extent.depth );
    memcpyInfo->quality = UNSUPPORTED;

    initMemcpyBufferInfo( &memcpyInfo->src, &copyDesc->src, memcpyInfo->width );
    initMemcpyBufferInfo( &memcpyInfo->dst, &copyDesc->dst, memcpyInfo->width );

    if (memcpyInfo->src.alignment == ALIGNED_16B && memcpyInfo->dst.alignment == ALIGNED_16B) {
        memcpyInfo->alignment = ALIGNED_16B;
    }
    else if (memcpyInfo->src.alignment >= ALIGNED_4B && memcpyInfo->dst.alignment >= ALIGNED_4B) {
        memcpyInfo->alignment = ALIGNED_4B;
    }
    else {
        memcpyInfo->alignment = MISALIGNED;
    }
    
    if (isSupportedByMaxwellMemcpyKernels( copyDesc )) {
        memcpyInfo->numDimensions = evalMemcpyDimensions( memcpyInfo, copyDesc );
        memcpyInfo->quality = evalMemcpyQuality( memcpyInfo );
    }
}

// ----------------------------------------------------------------------------------------
// Func:    initMemcpyParams( params, ctx, copyDesc, stream, copyCbInfo, tuning )
//
// Desc:    Initialize a 'MemcpyCommonParams' struct.
//
//          The MemcpyCommonParams struct is a container that holds all various
//          arguments that need to be passed around to the memcpy functions.
// ----------------------------------------------------------------------------------------
static void
initMemcpyParams(
    MemcpyCommonParams *params, /*out*/
    CUctx *ctx,
    const CUImemcpyDesc *copyDesc,
    CUIstream *stream,
    CUImemcpyCbInfo *copyCbInfo,
    const CUkernelMemcpyGM10xTuningParams* tuning )
{
    CU_ASSERT( params );
    CU_ASSERT( copyDesc );

    params->ctx        = ctx;
    params->copyDesc   = copyDesc;
    params->stream     = stream;
    params->copyCbInfo = copyCbInfo;
    params->tuning     = (tuning) ? tuning : &g_defaultTuningParams;

    initMemcpyInfo( &params->copyInfo, copyDesc );
}

// --------------------------------------------------------------------------------------
// Func:    configureGridAndBlockWidth( numElts, gridWidth, blockWidth, tuner )
//
// Desc:    Given a memcpy surface with 'numElts' # of elements in the X direction,
//          Configure the # of blocks and grids we want to use along the X axis.
//
// Notes:   numElts is in units of 'array elements', i.e. whatever typesize that
//          is going to be used to copy the memory. i.e.
//
//          * if you are using kernel memcpyDtoD_3d_u8, then numElts is in bytes (u8).
//          * If you are using kernel memcpyDtoD3DAligned, then numElts is in integers (u32).
// --------------------------------------------------------------------------------------
static void
configureGridAndBlockWidth(
    NvU32 numElts, NvU32 *gridWidth, NvU32 *blockWidth, const CUkernelMemcpyGM10xTuningParams *tuner )
{
    CU_ASSERT(gridWidth);
    CU_ASSERT(blockWidth);
    CU_ASSERT(tuner);

    if (tuner->tune) {
        // If user supplied a tuner func, use that
        (*tuner->tune)( numElts, gridWidth, blockWidth );
    }
    else { // else just use fixed sizes that were supplied
        NvU32 numBlocks;
        *blockWidth = MIN( numElts, tuner->blockWidth );

        numBlocks = (numElts + (*blockWidth) - 1) / *blockWidth;
        *gridWidth = MIN( numBlocks, tuner->gridWidth );
    }
}


// ----------------------------------------------------------------------------
// Func:    setMemcpyDtoDKernelParams()
//
// Desc:    Set the parameter list for a memcpy DtoD kernel.
//
//          All the gm10x memcpy DtoD kernels have the same argument signature
//          (same arg-types in the same order)
// ----------------------------------------------------------------------------
static CUresult
setMemcpyDtoDKernelParams(
    CUfunction  kernel,
    CUdeviceptr dstBuf,
    NvU64       dstPitch,   // in bytes
    NvU32       dstHeight,
    CUdeviceptr srcBuf,
    NvU64       srcPitch,   // in bytes
    NvU32       srcHeight,
    NvU32       count       /* in units */ )
{
    CUresult status;
    unsigned int paramOffset = 0;

    // construct the kernel's parameter list
    SETPARAMVF(kernel, dstBuf,    status, paramOffset, 0);
    SETPARAMVF(kernel, dstPitch,  status, paramOffset, 1);
    SETPARAMVF(kernel, dstHeight, status, paramOffset, 2);
    SETPARAMVF(kernel, srcBuf,    status, paramOffset, 3);
    SETPARAMVF(kernel, srcPitch,  status, paramOffset, 4);
    SETPARAMVF(kernel, srcHeight, status, paramOffset, 5);
    SETPARAMVF(kernel, count,     status, paramOffset, 6);

    status = cuiParamSetSize( kernel, paramOffset );
    if ( status != CUDA_SUCCESS ) {
        CU_ERROR_PRINT(("Failed to set parameter size.\n"));
    }
    return status;
}


// ----------------------------------------------------------------------------
// Func:    setMemcpyDtoAKernelParams()
//
// Desc:    Set the parameter list for a memcpy DtoA kernel.
//
//          All the gm10x memcpy DtoA kernels have the same argument signature
//          (same arg-types in the same order)
// ----------------------------------------------------------------------------
static CUresult
setMemcpyDtoAKernelParams(
    CUfunction  kernel,
    // dst surface
    CUsurfref   dstSurf,
    CUarray     dstArray,
    NvU32       dstOriginX, // bytes
    NvU32       dstOriginY, // rows
    NvU32       dstOriginZ, //
    // src buffer
    CUdeviceptr srcBuf,
    NvU64       srcPitch,   // bytes
    NvU32       srcHeight,
    // copy size
    NvU32       copyWidth )   // bytes
{
    CUresult status;
    unsigned int paramOffset = 0;

    // bind destination surface
    cuiSurfRefSetArray( dstSurf, dstArray, 0);

    // construct the kernel's parameter list
    SETPARAMVF(kernel, dstOriginX, status, paramOffset, 0);
    SETPARAMVF(kernel, dstOriginY, status, paramOffset, 1);
    SETPARAMVF(kernel, dstOriginZ, status, paramOffset, 2);
    SETPARAMVF(kernel, srcBuf,     status, paramOffset, 3);
    SETPARAMVF(kernel, srcPitch,   status, paramOffset, 4);
    SETPARAMVF(kernel, srcHeight,  status, paramOffset, 5);
    SETPARAMVF(kernel, copyWidth,  status, paramOffset, 6);

    status = cuiParamSetSize( kernel, paramOffset );
    if ( status != CUDA_SUCCESS ) {
        CU_ERROR_PRINT(("Failed to set parameter size.\n"));
    }
    return status;
}


// ----------------------------------------------------------------------------
// Func:    setMemcpyAtoDKernelParams()
//
// Desc:    Set the parameter list for a memcpy AtoD kernel.
//
//          All the gm10x memcpy AtoD kernels have the same argument signature
//          (same arg-types in the same order)
// ----------------------------------------------------------------------------
static CUresult
setMemcpyAtoDKernelParams(
    CUfunction  kernel,
    // dst buffer
    CUdeviceptr dstBuf,
    NvU64       dstPitch,   // bytes
    NvU32       dstHeight,
    // src surface
    CUsurfref   srcSurf,
    CUarray     srcArray,
    NvU32       srcOriginX,
    NvU32       srcOriginY,
    NvU32       srcOriginZ,
    // copy size
    NvU32       copyWidth ) // bytes
{
    CUresult status;
    unsigned int paramOffset = 0;

    // bind source surface
    cuiSurfRefSetArray( srcSurf, srcArray, 0);

    // construct the kernel's parameter list
    SETPARAMVF(kernel, dstBuf,     status, paramOffset, 0);
    SETPARAMVF(kernel, dstPitch,   status, paramOffset, 1);
    SETPARAMVF(kernel, dstHeight,  status, paramOffset, 2);
    SETPARAMVF(kernel, srcOriginX, status, paramOffset, 3);
    SETPARAMVF(kernel, srcOriginY, status, paramOffset, 4);
    SETPARAMVF(kernel, srcOriginZ, status, paramOffset, 5);
    SETPARAMVF(kernel, copyWidth,  status, paramOffset, 6);

    status = cuiParamSetSize( kernel, paramOffset );
    if ( status != CUDA_SUCCESS ) {
        CU_ERROR_PRINT(("Failed to set parameter size.\n"));
    }
    return status;
}

// ----------------------------------------------------------------------------
// Func:    setMemcpyAtoAKernelParams()
//
// Desc:    Set the parameter list for a memcpy AtoA kernel.
//
//          All the gm10x memcpy AtoA kernels have the same argument signature
//          (same arg-types in the same order)
// ----------------------------------------------------------------------------
static CUresult
setMemcpyAtoAKernelParams(
    CUfunction  kernel,
    // dst surface
    CUsurfref   dstSurf,
    CUarray     dstArray,
    NvU32       dstOriginX, // bytes
    NvU32       dstOriginY, // rows
    NvU32       dstOriginZ, //
    // src surface
    CUsurfref   srcSurf,
    CUarray     srcArray,
    NvU32       srcOriginX,
    NvU32       srcOriginY,
    NvU32       srcOriginZ,
    // copy size
    NvU32       copyWidth ) // bytes
{
    CUresult status;
    unsigned int paramOffset = 0;

    // bind source and destination surfaceS
    cuiSurfRefSetArray( srcSurf, srcArray, 0);
    cuiSurfRefSetArray( dstSurf, dstArray, 0);

    // construct the kernel's parameter list
    SETPARAMVF(kernel, dstOriginX, status, paramOffset, 0);
    SETPARAMVF(kernel, dstOriginY, status, paramOffset, 1);
    SETPARAMVF(kernel, dstOriginZ, status, paramOffset, 2);
    SETPARAMVF(kernel, srcOriginX, status, paramOffset, 3);
    SETPARAMVF(kernel, srcOriginY, status, paramOffset, 4);
    SETPARAMVF(kernel, srcOriginZ, status, paramOffset, 5);
    SETPARAMVF(kernel, copyWidth,  status, paramOffset, 6);

    status = cuiParamSetSize( kernel, paramOffset );
    if ( status != CUDA_SUCCESS ) {
        CU_ERROR_PRINT(("Failed to set parameter size.\n"));
    }
    return status;
}


// ----------------------------------------------------------------------------
// Func:    launchMemcpyKernel( params, kernel, grid )
//
// Desc:    Launch a memcpy kernel function.
//          The 'kernel' *must* already have it's parameter list setup.
// ----------------------------------------------------------------------------
static CUresult
launchMemcpyKernel(
    MemcpyCommonParams *params,
    CUfunction          kernel,
    const CUdim3       *gridDim)
{
    CUresult status;

    if (cuiApiIs_OCL(kernel->mod->api)) {
        // If this is OpenCL, then enabled OCL 'tracking' on the src or dst memobj.
        switch( params->copyInfo.kind) {
            case MEMCPY_KIND_A_TO_A:
                // Neither src nor dst is a 'memobj'.
                break;

            case MEMCPY_KIND_A_TO_D:
                // Track the destination memobj
                cuiFuncTrackMemobj(kernel, params->copyDesc->dst.memobj.memobj, NV_FALSE);
                break;

            case MEMCPY_KIND_D_TO_A:
                // Track the source memobj
                cuiFuncTrackMemobj(kernel, params->copyDesc->src.memobj.memobj, NV_FALSE);
                break;

            case MEMCPY_KIND_D_TO_D:
                // Track both source and destination memobjs
                kernelMemcpyTrackMemobj(params->ctx, kernel, params->copyDesc );
                break;

            default:
                break;
        } // end switch (kind
    } // end if OpenCL

    status = cuiLaunchGrid(kernel, *gridDim, params->stream, NULL, 0);
    return status;
}

// ----------------------------------------------------------------------------------------
// Func:    getMaxElementsVisitedPerRow( NvU32 copyWidthInBytes )
//
// Desc:    Returns the number of unique 'elements' per memcpy row.
//          The memcpy kernels will write as many elements as possible as
//          uints, and the rest as bytes.
// ----------------------------------------------------------------------------------------
static NvU32
getMaxElementsVisitedPerRow( NvU32 copyWidthInBytes )
{
    NvU32 maxEltsWrittenAsBytes = MIN( copyWidthInBytes,  GM10X_MISALIGNED_MEMCPY_MAX_MISALIGNED_BYTES_PER_ROW );
    NvU32 maxEltsWrittenAsUInts = copyWidthInBytes / sizeof(NvU32);
    NvU32 numElts = MAX( maxEltsWrittenAsUInts, maxEltsWrittenAsBytes );

    return numElts;
}

// ----------------------------------------------------------------------------------------
// Func:    memcpyDtoD( params, copyRect )
//
// Desc:    Copy rectangle 'copyRect' from the source to the destination.
//          Both source and destination are MemObjects.
//
//          This function selects the appropriate kernel for the requested
//          memcpy operation (based on the alignment of addresses, pitch, etc)
//          and launches that kernel.
//
// Args:    params            Everything we know about the copy operation.
//
//          copyRect          Requested copy origin and size.
// ----------------------------------------------------------------------------------------
static CUresult
memcpyDtoD( MemcpyCommonParams *params, const MemcpyRect* copyRect )
{
    CUresult status = CUDA_ERROR_NOT_SUPPORTED;
    CUfunction kernel;
    CUdim3 gridDim, blockDim;
    CUdeviceptr dstPtr, srcPtr;
    NvU64 dstPitch, srcPitch, dstHeight, srcHeight;
    NvU32 copyWidth, numEltsPerRow;

    CU_ASSERT( params );
    CU_ASSERT( params->copyInfo.kind == MEMCPY_KIND_D_TO_D );

    srcPtr = (CUdeviceptr) cuiMemcpyOperandGetOriginAddr( &params->copyDesc->src )
            + getOffsetIntoMemcpyBuffer( &params->copyInfo.src, &copyRect->origin );
    dstPtr = (CUdeviceptr) cuiMemcpyOperandGetOriginAddr( &params->copyDesc->dst )
            + getOffsetIntoMemcpyBuffer( &params->copyInfo.dst, &copyRect->origin );

    copyWidth = (NvU32) copyRect->size.widthInBytes;
    srcPitch  = params->copyInfo.src.pitch;
    srcHeight = params->copyInfo.src.height;
    dstPitch  = params->copyInfo.dst.pitch;
    dstHeight = params->copyInfo.dst.height;

    if ((params->copyInfo.alignment == ALIGNED_16B) && (copyWidth%4==0)) {
        // Everything is nicely aligned. (hurray!)
        // Copy everything as uints
        kernel = params->ctx->kernelmemcpy.maxwell->memcpyDtoD3DAligned;
        numEltsPerRow = copyWidth / sizeof(NvU32);
    }
    else {
        // Not everything is nicely aligned, use the 'misaligned' kernel
        kernel = params->ctx->kernelmemcpy.maxwell->memcpyDtoD3DMisaligned;
        numEltsPerRow = getMaxElementsVisitedPerRow( copyWidth );
    }


    CU_ASSERT( kernel );

    // configure grid and block shape
    configureGridAndBlockWidth( numEltsPerRow, &gridDim.x, &blockDim.x, params->tuning );

    blockDim.y = 1;
    blockDim.z  = 1;

    gridDim.y  = (NvU32) copyRect->size.height;
    gridDim.z   = (NvU32) copyRect->size.depth;

    status = cuiFuncSetBlockShape( kernel, blockDim.x, blockDim.y, blockDim.z );

    if (status != CUDA_SUCCESS) {
        return status;
    }

    // construct the kernel's parameter list
    status = setMemcpyDtoDKernelParams( kernel,
                dstPtr, dstPitch, (NvU32) dstHeight,
                srcPtr, srcPitch, (NvU32) srcHeight,
                copyWidth );

    if (status != CUDA_SUCCESS) {
        return status;
    }

    // launch kernel
    status = launchMemcpyKernel( params, kernel, &gridDim );

    return status;
}


// ----------------------------------------------------------------------------------------
// Func:    memcpyDtoA( params, copyRect )
//
// Desc:    Perform a 1D, 2D, or 3D memcpy when the source is a memobj and the
//          destination is a cudaArray.
// ----------------------------------------------------------------------------------------
static CUresult
memcpyDtoA( MemcpyCommonParams *params, const MemcpyRect* copyRect )
{
    CUresult status = CUDA_ERROR_NOT_SUPPORTED;
    CUfunction kernel = NULL;
    CUdim3 gridDim, blockDim;
    CUdeviceptr srcPtr;
    CUarray   dstArray;
    CUsurfref dstSurface;
    NvU64 srcPitch, srcHeight;
    NvU32 dstX, dstY, dstZ; // offset into destination surface
    NvU32 copyWidth, numEltsPerRow;

    CU_ASSERT( params );
    CU_ASSERT( params->copyInfo.kind == MEMCPY_KIND_D_TO_A );

    srcPtr    = (CUdeviceptr) cuiMemcpyOperandGetOriginAddr( &params->copyDesc->src )
              + getOffsetIntoMemcpyBuffer( &params->copyInfo.src, &copyRect->origin );

    dstArray  = params->copyDesc->dst.array.array;

    dstX      = (NvU32) (copyRect->origin.xInBytes + params->copyDesc->dst.origin.xInBytes);
    dstY      = (NvU32) (copyRect->origin.y        + params->copyDesc->dst.origin.y);
    dstZ      = (NvU32) (copyRect->origin.z        + params->copyDesc->dst.origin.z);

    srcPitch  = params->copyInfo.src.pitch;
    srcHeight = params->copyInfo.src.height;

    // select kernel and destnation surface
    switch ( params->copyInfo.numDimensions ) {
        case 1: // 1D copy
        case 2: // 2D copy
            kernel     = params->ctx->kernelmemcpy.maxwell->memcpyD3DtoA2D;
            dstSurface = params->ctx->kernelmemcpy.maxwell->osurfref2D;
            break;
        case 3: // 3D copy
            kernel     = params->ctx->kernelmemcpy.maxwell->memcpyD3DtoA3D;
            dstSurface = params->ctx->kernelmemcpy.maxwell->osurfref3D;
            break;
        default:
            CU_ASSERT( 0 && "Unexpected number of dimensions." );
    }


    if (kernel == NULL) {
        return CUDA_ERROR_NOT_SUPPORTED;
    }

    // configure grid and block shape
    copyWidth     = (NvU32) copyRect->size.widthInBytes;     // # of bytes copied per row
    numEltsPerRow = getMaxElementsVisitedPerRow( copyWidth );
    configureGridAndBlockWidth( numEltsPerRow, &gridDim.x, &blockDim.x, params->tuning );

    blockDim.y = 1;
    blockDim.z  = 1;

    gridDim.y  = (NvU32) copyRect->size.height;
    gridDim.z   = (NvU32) copyRect->size.depth;

    status = cuiFuncSetBlockShape( kernel, blockDim.x, blockDim.y, blockDim.z );

    if (status != CUDA_SUCCESS) {
        return status;
    }

    // construct the kernel's parameter list
    status = setMemcpyDtoAKernelParams( kernel,
                /* destination memory => */ dstSurface, dstArray,
                /* destination origin => */ dstX, dstY, dstZ,
                /* source dimensions  => */ srcPtr, srcPitch, (NvU32) srcHeight,
                /* copy size          => */ copyWidth );

    if (status != CUDA_SUCCESS) {
        return status;
    }

    // launch kernel
    status = launchMemcpyKernel( params, kernel, &gridDim );

    return status;
}


// ----------------------------------------------------------------------------------------
// Func:    memcpyAtoD( params, copyRect )
//
// Desc:    Perform a 1D, 2D, or 3D memcpy when the source is a cudaArray and the
//          destination is a memobj (device ptr).
// ----------------------------------------------------------------------------------------
static CUresult
memcpyAtoD( MemcpyCommonParams *params, const MemcpyRect* copyRect )
{
    CUresult status = CUDA_ERROR_NOT_SUPPORTED;
    CUfunction kernel = NULL;
    CUdim3 gridDim, blockDim;
    CUdeviceptr dstPtr;
    CUarray   srcArray;
    CUsurfref srcSurface;
    NvU64 dstPitch, dstHeight;
    NvU32 srcX, srcY, srcZ;
    NvU32 copyWidth, numEltsPerRow;

    CU_ASSERT( params );
    CU_ASSERT( params->copyInfo.kind == MEMCPY_KIND_A_TO_D );

    dstPtr    = (CUdeviceptr) cuiMemcpyOperandGetOriginAddr( &params->copyDesc->dst )
                + getOffsetIntoMemcpyBuffer( &params->copyInfo.dst, &copyRect->origin );

    srcArray  = params->copyDesc->src.array.array;

    srcX      = (NvU32) (copyRect->origin.xInBytes + params->copyDesc->src.origin.xInBytes);
    srcY      = (NvU32) (copyRect->origin.y        + params->copyDesc->src.origin.y);
    srcZ      = (NvU32) (copyRect->origin.z        + params->copyDesc->src.origin.z);

    dstPitch  = params->copyInfo.dst.pitch;
    dstHeight = params->copyInfo.dst.height;

    // select kernel and source surface
    switch (params->copyInfo.numDimensions) {
        case 1:     // 1D copy
        case 2:     // 2D copy
            kernel     = params->ctx->kernelmemcpy.maxwell->memcpyA2DtoD3D;
            srcSurface = params->ctx->kernelmemcpy.maxwell->isurfref2D;
            break;
        case 3:     // 3D copy
            kernel     = params->ctx->kernelmemcpy.maxwell->memcpyA3DtoD3D;
            srcSurface = params->ctx->kernelmemcpy.maxwell->isurfref3D;
            break;
        default:
            CU_ASSERT( 0 && "Unexpected number of dimensions");
    } // end switch(numDimensions)


    if (kernel == NULL) {
        return CUDA_ERROR_NOT_SUPPORTED;
    }

    // configure grid and block shape
    copyWidth     = (NvU32) copyRect->size.widthInBytes;
    numEltsPerRow = getMaxElementsVisitedPerRow( copyWidth );
    configureGridAndBlockWidth( numEltsPerRow, &gridDim.x, &blockDim.x, params->tuning );

    blockDim.y = 1;
    blockDim.z  = 1;

    gridDim.y  = (NvU32) copyRect->size.height;
    gridDim.z   = (NvU32) copyRect->size.depth;

    status = cuiFuncSetBlockShape( kernel, blockDim.x, blockDim.y, blockDim.z );

    if (status != CUDA_SUCCESS) {
        return status;
    }

    // construct the kernel's parameter list
    status = setMemcpyAtoDKernelParams( kernel,
                /* destination   => */ dstPtr, dstPitch, (NvU32) dstHeight,
                /* source memory => */ srcSurface, srcArray,
                /* source origin => */ srcX, srcY, srcZ,
                /* copy width    => */ copyWidth );

    if (status != CUDA_SUCCESS) {
        return status;
    }

    // launch kernel
    status = launchMemcpyKernel( params, kernel, &gridDim );

    return status;
}

// ----------------------------------------------------------------------------------------
// Func:    memcpyAtoA( params, copyRect )
//
// Desc:    Perform a 1D, 2D, or 3D memcpy when both the source and destination
//          are cudaArrays.
// ----------------------------------------------------------------------------------------
static CUresult
memcpyAtoA( MemcpyCommonParams *params, const MemcpyRect* copyRect )
{
    CUresult status = CUDA_ERROR_NOT_SUPPORTED;
    CUfunction kernel = NULL;
    CUdim3 gridDim, blockDim;
    CUarray   srcArray, dstArray;
    CUsurfref srcSurface, dstSurface;
    NvU32 dstX, dstY, dstZ; // offset into destination surface
    NvU32 srcX, srcY, srcZ; // offset into source surface
    NvU32 srcDimensions, dstDimensions;
    NvU32 copyWidth, numEltsPerRow;


    CU_ASSERT( params );
    CU_ASSERT( params->copyInfo.kind == MEMCPY_KIND_A_TO_A );

    dstArray  = params->copyDesc->dst.array.array;

    dstX      = (NvU32) (copyRect->origin.xInBytes + params->copyDesc->dst.origin.xInBytes);
    dstY      = (NvU32) (copyRect->origin.y        + params->copyDesc->dst.origin.y);
    dstZ      = (NvU32) (copyRect->origin.z        + params->copyDesc->dst.origin.z);

    srcArray  = params->copyDesc->src.array.array;

    srcX      = (NvU32) (copyRect->origin.xInBytes + params->copyDesc->src.origin.xInBytes);
    srcY      = (NvU32) (copyRect->origin.y        + params->copyDesc->src.origin.y);
    srcZ      = (NvU32) (copyRect->origin.z        + params->copyDesc->src.origin.z);

    srcDimensions = getMemcpyOperandArrayDimensions( &params->copyDesc->src );
    dstDimensions = getMemcpyOperandArrayDimensions( &params->copyDesc->dst );

    srcSurface = (srcDimensions == 3) ? params->ctx->kernelmemcpy.maxwell->isurfref3D : params->ctx->kernelmemcpy.maxwell->isurfref2D;
    dstSurface = (dstDimensions == 3) ? params->ctx->kernelmemcpy.maxwell->osurfref3D : params->ctx->kernelmemcpy.maxwell->osurfref2D;

    if (srcDimensions == 3) {
        if (dstDimensions == 3) {
            kernel = params->ctx->kernelmemcpy.maxwell->memcpyA3DtoA3D;
        }
        else {
            kernel = params->ctx->kernelmemcpy.maxwell->memcpyA3DtoA2D;
        }
    }
    else { // src surface is 1D or 2D
        if (dstDimensions == 3) {
            kernel = params->ctx->kernelmemcpy.maxwell->memcpyA2DtoA3D;
        }
        else {
            kernel = params->ctx->kernelmemcpy.maxwell->memcpyA2DtoA2D;
        }
    }

    if (kernel == NULL) {
        return CUDA_ERROR_NOT_SUPPORTED;
    }

    // configure grid and block shape
    copyWidth     = (NvU32) copyRect->size.widthInBytes;
    numEltsPerRow = getMaxElementsVisitedPerRow( copyWidth );
    configureGridAndBlockWidth( numEltsPerRow, &gridDim.x, &blockDim.x, params->tuning );

    blockDim.y = 1;
    blockDim.z  = 1;

    gridDim.y  = (NvU32) copyRect->size.height;
    gridDim.z   = (NvU32) copyRect->size.depth;

    status = cuiFuncSetBlockShape( kernel, blockDim.x, blockDim.y, blockDim.z );

    if (status != CUDA_SUCCESS) {
        return status;
    }

    // construct the kernel's parameter list
    status = setMemcpyAtoAKernelParams( kernel,
                /* destination memory => */ dstSurface, dstArray,
                /* destination origin => */ dstX, dstY, dstZ,
                /* source memory      => */ srcSurface, srcArray,
                /* source origin      => */ srcX, srcY, srcZ,
                /* copy width         => */ copyWidth );

    if (status != CUDA_SUCCESS) {
        return status;
    }

    // launch kernel
    status = launchMemcpyKernel( params, kernel, &gridDim );

    return status;
}


// ----------------------------------------------------------------------------------------
// Func:    memcpyRectExtent( params, copyRect )
//
// Desc:    Perform a memcpy operation limited to the requested rectangle.
// ---------------------------------------------------------------------------------------
static CUresult
memcpyRectExtent( MemcpyCommonParams *params, const MemcpyRect* copyRect )
{
    CUresult status = CUDA_ERROR_NOT_SUPPORTED;

    CU_ASSERT( params );

    // dispatch to appropriate memcpy kernel
    switch( params->copyInfo.kind) {
        case MEMCPY_KIND_A_TO_A:
            status = memcpyAtoA( params, copyRect );
            break;

        case MEMCPY_KIND_A_TO_D:
            status = memcpyAtoD( params, copyRect );
            break;

        case MEMCPY_KIND_D_TO_A:
            status = memcpyDtoA( params, copyRect );
            break;

        case MEMCPY_KIND_D_TO_D:
            status = memcpyDtoD( params, copyRect );
            break;

         default:
            break;
    }
    return status;
}

// ----------------------------------------------------------------------------------------
// Func:    memcpyFullExtent( params )
//
// Desc:    Perform a memcpy operation on a (potentially) large extent.
//
//          The "FullExtent" in the name is there to indicate that the extent
//          of the requested memcpy can be larger than the max
//          grid size, in which case we will iterate over subsections of the
//          extent, launching multiple kernels.
// ----------------------------------------------------------------------------------------
static CUresult
memcpyFullExtent( MemcpyCommonParams *params )
{
    CUresult status = CUDA_SUCCESS;
    MemcpyRect copyRect;
    NvU64 width, height, depth;

    width  = params->copyInfo.width;
    height = params->copyInfo.height;
    depth  = params->copyInfo.depth;

    copyRect.origin.xInBytes = 0;
    copyRect.origin.y = 0;
    copyRect.origin.z = 0;

    while ( copyRect.origin.z < depth ) {
        copyRect.size.depth  = MIN( depth-copyRect.origin.z, params->ctx->device->state.limits.maxCtaGridDepth );
        copyRect.origin.y    = 0;

        while( copyRect.origin.y < height ) {
            copyRect.size.height = MIN( height-copyRect.origin.y, params->ctx->device->state.limits.maxCtaGridHeight );
            copyRect.origin.xInBytes = 0;

            while( copyRect.origin.xInBytes < width ) {
                copyRect.size.widthInBytes = MIN( width-copyRect.origin.xInBytes, params->ctx->device->state.limits.maxCtaGridWidth );

                status = memcpyRectExtent( params, &copyRect );
                if (status != CUDA_SUCCESS) {
                    return status;
                }
                // advance x
                copyRect.origin.xInBytes += copyRect.size.widthInBytes;
            } // end while(x...)
            // advance y
            copyRect.origin.y += copyRect.size.height;
        } // end while(y...)
        // advance z
        copyRect.origin.z += copyRect.size.depth;
    } // end while(z...)
    return status;
}



////////////////////////////////////////////////////////////////////////////////////////////
//
// Section: Main Entry Point from HAL
//
// Desc:    These are the functions that the HAL layer calls.
//
////////////////////////////////////////////////////////////////////////////////////////////

static NvBool
isSupportedByFermiMemcpyKernels( const MemcpyInfo *memcpyInfo )
{
    return ((memcpyInfo->kind   == MEMCPY_KIND_D_TO_D) &&
            (memcpyInfo->height == 1) &&
            (memcpyInfo->depth  == 1));
}


// ----------------------------------------------------------------------------------------
// Func:    gm10xMemcpyKernelIsSupported(copyDesc)
//
// Desc:    Returns TRUE if the requested memcpy operation is supported
//          by custom Maxwell kernels.
// ----------------------------------------------------------------------------------------
NvBool gm10xMemcpyKernelIsSupported(const CUImemcpyDesc *copyDesc)
{
    MemcpyInfo memcpyInfo;
    NvBool isSupportedByFermiKernels;
    NvBool isSupportedByMaxwellKernels;
    NvBool isFasterUnderMaxwell;
    NvBool isSupported;

    CU_TRACE_FUNCTION();
    CU_ASSERT(copyDesc);

    initMemcpyInfo( &memcpyInfo, copyDesc );

    isSupportedByFermiKernels   = isSupportedByFermiMemcpyKernels(&memcpyInfo);
    isSupportedByMaxwellKernels = isSupportedByMaxwellMemcpyKernels(copyDesc);

    isFasterUnderMaxwell = (memcpyInfo.quality == BETTER);
    isSupported          = (isSupportedByFermiKernels || (isSupportedByMaxwellKernels && isFasterUnderMaxwell));

    return isSupported;
}

// ----------------------------------------------------------------------------------------
// Func:    gm10xMemcpyKernel( ctx, copyDesc, stream, copyCbInf )
//
// Desc:    Maxwell custom kernel memcpy operations.
//          This is the main entry point for Maxwell memcpy operations.
// ----------------------------------------------------------------------------------------
CUresult gm10xMemcpyKernel(
    CUctx *ctx,
    const CUImemcpyDesc *copyDesc,
    CUIstream *stream,
    CUImemcpyCbInfo *copyCbInfo )
{
    CUresult status = CUDA_ERROR_NOT_SUPPORTED;
    MemcpyCommonParams params;
    NvBool fermiKernelIsSupported, fermiKernelIsFaster, fermiKernelIsAllowed, useFermiKernels;

    CU_TRACE_FUNCTION();
    CU_ASSERT(ctx && copyDesc && stream && copyCbInfo);

    // Group all our arguments into a convenient struct 'MemcpyCommonParams'
    initMemcpyParams( &params, ctx, copyDesc, stream, copyCbInfo, &g_defaultTuningParams );

    // If the fermi kernel is better for this type of memcpy, use it instead

    fermiKernelIsSupported = isSupportedByFermiMemcpyKernels(&params.copyInfo);
    fermiKernelIsFaster    = (params.copyInfo.quality < BETTER);
    fermiKernelIsAllowed   = (globals.enableMaxwellKernelMemcpy < GM10X_MEMCPY_KERNEL_MODE_FORCE);

    useFermiKernels = (fermiKernelIsSupported && fermiKernelIsAllowed && fermiKernelIsFaster);

    if (useFermiKernels) {
        status = gf100KernelMemcpy1DDtoD(ctx, copyDesc, stream, copyCbInfo);
    }
    else {
        // Perform the memcpy using maxwell kernels
        status = memcpyFullExtent( &params );
    }

    return status;
}


////////////////////////////////////////////////////////////////////////////////////////////
//
// Section: Kernel Module Load/Unload
//
// Desc:    The following code loads the precompiled kernels from their associated cubins.
//
////////////////////////////////////////////////////////////////////////////////////////////


// ----------------------------------------------------------------------------------------
// Func:    gm10xKernelMemcpyFree()
//
// Desc:    Destructor for struct CUkernelMemcpyGM10x.
// ----------------------------------------------------------------------------------------
static void
gm10xKernelMemcpyFree( CUkernelMemcpyGM10x* gm10x )
{
    if (gm10x) {
        if (gm10x->mod) {
            cuiModuleUnload(gm10x->mod);
        }
        free( gm10x );
    }
}

// ----------------------------------------------------------------------------------------
// Func:    gm10xKernelMemcpyNew()
//
// Desc:    Constructor for struct CUkernelMemcpyGM10x.
//
//          Allocates and initializes a CUkernelMemcpyGM10x struct,
//          including loading the assoicated cubin module and
//          the various precompiled kernel function ptrs.
// ----------------------------------------------------------------------------------------
static CUresult
CUkernelMemcpyGM10xNew( CUkernelMemcpyGM10x** ppGm10x /*out*/, CUctx* ctx )
{
    CUresult status;
    CUkernelMemcpyGM10x* gm10x = (CUkernelMemcpyGM10x*) malloc(sizeof(CUkernelMemcpyGM10x));

    *ppGm10x = NULL;

    if (!gm10x) {
        CU_ERROR_PRINT(("Failed to allocate memory\n"));
        status = CUDA_ERROR_OUT_OF_MEMORY;
        goto Error;
    }

    memset( gm10x, 0, sizeof(CUkernelMemcpyGM10x));

    // load internal maxwell Memcpy cubin
    {
        CUjitCompileData compileData;

        cuiSetDefaultCompilerOptions(&compileData);

        status = cuiModuleLoadData(ctx, &gm10x->mod,
                                   cuiGetBIKCubin(allCubins_gm10x_kernel_memcpy,
                                                  ctx->device->state.major,
                                                  ctx->device->state.minor),
                                   NULL, &compileData, ctx->api);

        if (CUDA_SUCCESS != status) {
            CU_ERROR_PRINT(("Failed to load Maxwell memcpy cubin.\n"));
            return status;
        }
    }

    // get kernel function handles
    LOAD_FUNCTION(status, gm10x, memcpyDtoD3DAligned );
    LOAD_FUNCTION(status, gm10x, memcpyDtoD3DMisaligned );
    // NvEnc test die loading any of the following kernels.
    // (all these kernels use C++ templates, the above kernels do not)
    LOAD_FUNCTION(status, gm10x, memcpyD3DtoA2D );
    LOAD_FUNCTION(status, gm10x, memcpyD3DtoA3D );
    LOAD_FUNCTION(status, gm10x, memcpyA2DtoD3D );
    LOAD_FUNCTION(status, gm10x, memcpyA3DtoD3D );
    LOAD_FUNCTION(status, gm10x, memcpyA2DtoA2D );
    LOAD_FUNCTION(status, gm10x, memcpyA2DtoA3D );
    LOAD_FUNCTION(status, gm10x, memcpyA3DtoA2D );
    LOAD_FUNCTION(status, gm10x, memcpyA3DtoA3D );

#define LOAD_SURFACE( _status, _gm10x, _surfName ) \
    _status = cuiModuleGetSurfRefByName( _gm10x->mod, #_surfName, &_gm10x->_surfName ); \
    if (CUDA_SUCCESS != _status) { \
        CU_DEBUG_PRINT(("Failed to load surface "  #_surfName  ".\n")); \
        goto Error; \
    }

    LOAD_SURFACE( status, gm10x, isurfref2D );
    LOAD_SURFACE( status, gm10x, osurfref2D );
    LOAD_SURFACE( status, gm10x, isurfref3D );
    LOAD_SURFACE( status, gm10x, osurfref3D );

    // The 2D surfaces need to be able to treat 1D arrays as 2D arrays on Maxwell+, so
    // that we can do larger kernel memcopies for 1D surfaces, since the
    // 1D surface limits are so low
    gm10x->isurfref2D->treat1dArraysAs2d = NV_TRUE;
    gm10x->osurfref2D->treat1dArraysAs2d = NV_TRUE;

#undef LOAD_SURFACE

    // only set destination ptr if we succeed
    *ppGm10x = gm10x;

    return CUDA_SUCCESS;

Error:
    gm10xKernelMemcpyFree(gm10x);
    return status;
}

// ---------------------------------------------------------------------------------------------
// Func:    gm10xKernelMemcpyInit( ctx )
//
// Desc:    Allocate and initialize a CUkernelMemcpyGM10x struct,
//          and attach it to the given context.
//
//          Sets-up the function pointers to the various Memcpy implementations
// ----------------------------------------------------------------------------------------------
CUresult
gm10xKernelMemcpyInit(CUctx *ctx)
{
    CUresult status;

    CU_TRACE_FUNCTION();
    CU_ASSERT(ctx);

    status = CUkernelMemcpyGM10xNew( &ctx->kernelmemcpy.maxwell, ctx );

    return status;
}


// ----------------------------------------------------------------------------
// Func:    gm10xKernelMemcpyDestroy( ctx )
//
// Desc:    Cleanup and free the CUkernelMemcpyGM10x struct
//          attached to the supplied context.
//
//          Resets the ctx's data pointer to NULL.
// ----------------------------------------------------------------------------
void
gm10xKernelMemcpyDestroy(CUctx *ctx)
{
    CU_TRACE_FUNCTION();
    CU_ASSERT(ctx);

    gm10xKernelMemcpyFree( ctx->kernelmemcpy.maxwell );
    ctx->kernelmemcpy.maxwell = NULL;
}

