/* 
 * Copyright 1993-2009 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

/******************************************************************************
*
*   Module: memcpyDevice_kernels.cu
*
*   Description:
*       Kernels for device-device 1D, 2D, and 3D linear memory copies.
*
******************************************************************************/

#ifdef __GNUC__
#include <stdint.h>
#elif _WIN32
#include <stddef.h>

// Define 'ssize_t', which is not a built-in type on Windows.
// (On Unix, 'ssize_t' is a signed version of 'size_t')
#ifdef _WIN64
typedef long long ssize_t; 
#else // 32-bit abi
typedef int ssize_t; 
#endif
#endif // _WIN32

// Surfaces
surface< void, 1 > isurfref1D;
surface< void, 1 > osurfref1D;
surface< void, 2 > isurfref2D;
surface< void, 2 > osurfref2D;
surface< void, 3 > isurfref3D;
surface< void, 3 > osurfref3D;
surface< void, 0xF1 > isurfref1DLayered;
surface< void, 0xF1 > osurfref1DLayered;
surface< void, 0xF2 > isurfref2DLayered;
surface< void, 0xF2 > osurfref2DLayered;


// Compute the number of bytes to the left of the nearest integer alignment
//  of the given pointer, i.e., how many bytes need to be copied before an
//  aligned copy can be done.
#define LEFT_BYTE_MISALIGN( ptr ) ((0x4-((uintptr_t)(ptr)&0x3))&0x3)

// Compute the width aligned to the number of integers to be copied.
//  Get the left byte misalignment of the pointer to know how many bytes
//  aren't copied by the main part of the kernel. Shift right by 2 to
//  get aligned integer width to copy.
#define GET_ALIGNED_WIDTH( w, ptr ) ((w) - (LEFT_BYTE_MISALIGN(ptr))>>2)

// ARRAY->LINEAR
extern "C" __global__ void IntAligned_AtoD1D_surf(unsigned int* dst,
                    unsigned int arrSrcXInBytes, unsigned int width)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idxSurf = idx<<2;
    unsigned int idata;

    if (idxSurf < width) {
        surf1Dread(&idata, isurfref1D, idxSurf + arrSrcXInBytes);
        dst[idx] = idata;
    }
}

extern "C" __global__ void IntAligned_AtoD1DLayered_surf(unsigned int* dst,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcZ, unsigned int numLayers)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idz = threadIdx.z + blockIdx.z * blockDim.z;
    unsigned int idxSurf = idx<<2;
    unsigned int idata;

    if ((idxSurf < width) && (idz < numLayers)) {
        surf1DLayeredread(&idata, isurfref1DLayered, idxSurf + arrSrcXInBytes, idz + arrSrcZ);
        dst[idz*(pitch>>2) + idx] = idata;
    }
}

extern "C" __global__ void IntAligned_AtoD2D_surf(unsigned int* dst,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcY, unsigned int height)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idy = threadIdx.y + blockIdx.y * blockDim.y;
    unsigned int idxSurf = idx<<2;
    unsigned int idata;

    if ((idxSurf < width) && (idy < height)) {
        surf2Dread(&idata, isurfref2D, idxSurf + arrSrcXInBytes, idy + arrSrcY);
        dst[idy*(pitch>>2) + idx] = idata;
    }
}

extern "C" __global__ void IntAligned_AtoD2DLayered_surf(unsigned int* dst,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcY, unsigned int height,
                    unsigned int arrSrcZ, unsigned int numLayers, size_t dstHeight)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idy = threadIdx.y + blockIdx.y * blockDim.y;
    unsigned int idz = threadIdx.z + blockIdx.z * blockDim.z;
    unsigned int idxSurf = idx<<2;
    unsigned int idata;

    if ((idxSurf < width) && (idy < height) && (idz < numLayers)) {
        surf2DLayeredread(&idata, isurfref2DLayered, idxSurf + arrSrcXInBytes,
                          idy + arrSrcY, idz + arrSrcZ);
        dst[idz*(pitch>>2)*dstHeight + idy*(pitch>>2) + idx] = idata;
    }
}

extern "C" __global__ void IntAligned_AtoD3D_surf(unsigned int* dst,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcY, unsigned int height,
                    unsigned int arrSrcZ, unsigned int depth, size_t dstHeight)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idy = threadIdx.y + blockIdx.y * blockDim.y;
    unsigned int idz = threadIdx.z + blockIdx.z * blockDim.z;
    unsigned int idxSurf = idx<<2;
    unsigned int idata;

    if ((idxSurf < width) && (idy < height) && (idz < depth)) {
        surf3Dread(&idata, isurfref3D, idxSurf + arrSrcXInBytes, idy + arrSrcY,
                   idz + arrSrcZ);
        dst[idz*(pitch>>2)*dstHeight + idy*(pitch>>2) + idx] = idata;
    }
}

extern "C" __global__ void ShortAligned_AtoD1D_surf(unsigned short* dst,
                    unsigned int arrSrcXInBytes, unsigned int width)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idxSurf = idx<<1;
    unsigned short idata;

    if (idxSurf < width) {
        surf1Dread(&idata, isurfref1D, idxSurf + arrSrcXInBytes);
        dst[idx] = idata;
    }
}

extern "C" __global__ void ShortAligned_AtoD1DLayered_surf(unsigned short* dst,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcZ, unsigned int numLayers)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idz = threadIdx.z + blockIdx.z * blockDim.z;
    unsigned int idxSurf = idx<<1;
    unsigned short idata;

    if ((idxSurf < width) && (idz < numLayers)) {
        surf1DLayeredread(&idata, isurfref1DLayered, idxSurf + arrSrcXInBytes, idz + arrSrcZ);
        dst[idz*(pitch>>1) + idx] = idata;
    }
}

extern "C" __global__ void ShortAligned_AtoD2D_surf(unsigned short* dst,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcY, unsigned int height)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idy = threadIdx.y + blockIdx.y * blockDim.y;
    unsigned int idxSurf = idx<<1;
    unsigned short idata;

    if ((idxSurf < width) && (idy < height)) {
        surf2Dread(&idata, isurfref2D, idxSurf + arrSrcXInBytes, idy + arrSrcY);
        dst[idy*(pitch>>1) + idx] = idata;
    }
}

extern "C" __global__ void ShortAligned_AtoD2DLayered_surf(unsigned short* dst,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcY, unsigned int height,
                    unsigned int arrSrcZ, unsigned int numLayers, size_t dstHeight)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idy = threadIdx.y + blockIdx.y * blockDim.y;
    unsigned int idz = threadIdx.z + blockIdx.z * blockDim.z;
    unsigned int idxSurf = idx<<1;
    unsigned short idata;

    if ((idxSurf < width) && (idy < height) && (idz < numLayers)) {
        surf2DLayeredread(&idata, isurfref2DLayered, idxSurf + arrSrcXInBytes,
                          idy + arrSrcY, idz + arrSrcZ);
        dst[idz*(pitch>>1)*dstHeight + idy*(pitch>>1) + idx] = idata;
    }
}

extern "C" __global__ void ShortAligned_AtoD3D_surf(unsigned short* dst,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcY, unsigned int height,
                    unsigned int arrSrcZ, unsigned int depth, size_t dstHeight)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idy = threadIdx.y + blockIdx.y * blockDim.y;
    unsigned int idz = threadIdx.z + blockIdx.z * blockDim.z;
    unsigned int idxSurf = idx<<1;
    unsigned short idata;

    if ((idxSurf < width) && (idy < height) && (idz < depth)) {
        surf3Dread(&idata, isurfref3D, idxSurf + arrSrcXInBytes, idy + arrSrcY,
                   idz + arrSrcZ);
        dst[idz*(pitch>>1)*dstHeight + idy*(pitch>>1) + idx] = idata;
    }
}

extern "C" __global__ void CharAligned_AtoD1D_surf(unsigned char* dst,
                    unsigned int arrSrcXInBytes, unsigned int width)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned char idata;

    if (idx < width) {
        surf1Dread(&idata, isurfref1D, idx + arrSrcXInBytes);
        dst[idx] = idata;
    }
}

extern "C" __global__ void CharAligned_AtoD1DLayered_surf(unsigned char* dst,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcZ, unsigned int numLayers)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idz = threadIdx.z + blockIdx.z * blockDim.z;
    unsigned char idata;

    if ((idx < width) && (idz < numLayers)) {
        surf1DLayeredread(&idata, isurfref1DLayered, idx + arrSrcXInBytes, idz + arrSrcZ);
        dst[idz*pitch + idx] = idata;
    }
}

extern "C" __global__ void CharAligned_AtoD2D_surf(unsigned char* dst,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcY, unsigned int height)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idy = threadIdx.y + blockIdx.y * blockDim.y;
    unsigned char idata;

    if ((idx < width) && (idy < height)) {
        surf2Dread(&idata, isurfref2D, idx + arrSrcXInBytes, idy + arrSrcY);
        dst[idy*pitch + idx] = idata;
    }
}

extern "C" __global__ void CharAligned_AtoD2DLayered_surf(unsigned char* dst,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcY, unsigned int height,
                    unsigned int arrSrcZ, unsigned int numLayers, size_t dstHeight)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idy = threadIdx.y + blockIdx.y * blockDim.y;
    unsigned int idz = threadIdx.z + blockIdx.z * blockDim.z;
    unsigned char idata;

    if ((idx < width) && (idy < height) && (idz < numLayers)) {
        surf2DLayeredread(&idata, isurfref2DLayered, idx + arrSrcXInBytes,
                          idy + arrSrcY, idz + arrSrcZ);
        dst[idz*pitch*dstHeight + idy*pitch + idx] = idata;
    }
}

extern "C" __global__ void CharAligned_AtoD3D_surf(unsigned char* dst,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcY, unsigned int height,
                    unsigned int arrSrcZ, unsigned int depth, size_t dstHeight)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idy = threadIdx.y + blockIdx.y * blockDim.y;
    unsigned int idz = threadIdx.z + blockIdx.z * blockDim.z;
    unsigned char idata;

    if ((idx < width) && (idy < height) && (idz < depth)) {
        surf3Dread(&idata, isurfref3D, idx + arrSrcXInBytes, idy + arrSrcY,
                   idz + arrSrcZ);
        dst[idz*pitch*dstHeight + idy*pitch + idx] = idata;
    }
}

// LINEAR->ARRAY
extern "C" __global__ void IntAligned_DtoA1D_surf(unsigned int* src,
                    unsigned int arrSrcXInBytes, unsigned int width)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idxSurf = idx<<2;

    if (idxSurf < width) {
        unsigned int odata = src[idx];
        surf1Dwrite(odata, osurfref1D, idxSurf + arrSrcXInBytes);
    }
}

extern "C" __global__ void IntAligned_DtoA1DLayered_surf(unsigned int* src,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcZ, unsigned int numLayers)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idz = threadIdx.z + blockIdx.z * blockDim.z;
    unsigned int idxSurf = idx<<2;

    if ((idxSurf < width) && (idz < numLayers)) {
        unsigned int odata = src[idz*(pitch>>2) + idx];
        surf1DLayeredwrite(odata, osurfref1DLayered, idxSurf + arrSrcXInBytes, idz + arrSrcZ);
    }
}

extern "C" __global__ void IntAligned_DtoA2D_surf(unsigned int* src,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcY, unsigned int height)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idy = threadIdx.y + blockIdx.y * blockDim.y;
    unsigned int idxSurf = idx<<2;

    if ((idxSurf < width) && (idy < height)) {
        unsigned int odata = src[idy*(pitch>>2) + idx];
        surf2Dwrite(odata, osurfref2D, idxSurf + arrSrcXInBytes, idy + arrSrcY);
    }
}

extern "C" __global__ void IntAligned_DtoA2DLayered_surf(unsigned int* src,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcY, unsigned int height,
                    unsigned int arrSrcZ, unsigned int numLayers, size_t srcHeight)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idy = threadIdx.y + blockIdx.y * blockDim.y;
    unsigned int idz = threadIdx.z + blockIdx.z * blockDim.z;
    unsigned int idxSurf = idx<<2;

    if ((idxSurf < width) && (idy < height) && (idz < numLayers)) {
        unsigned int odata = src[idz*(pitch>>2)*srcHeight + idy*(pitch>>2) + idx];
        surf2DLayeredwrite(odata, osurfref2DLayered, idxSurf + arrSrcXInBytes,
                           idy + arrSrcY, idz + arrSrcZ);
    }
}

extern "C" __global__ void IntAligned_DtoA3D_surf(unsigned int* src,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcY, unsigned int height,
                    unsigned int arrSrcZ, unsigned int depth, size_t srcHeight)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idy = threadIdx.y + blockIdx.y * blockDim.y;
    unsigned int idz = threadIdx.z + blockIdx.z * blockDim.z;
    unsigned int idxSurf = idx<<2;

    if ((idxSurf < width) && (idy < height) && (idz < depth)) {
        unsigned int odata = src[idz*(pitch>>2)*srcHeight + idy*(pitch>>2) + idx];
        surf3Dwrite(odata, osurfref3D, idxSurf + arrSrcXInBytes, idy + arrSrcY,
                    idz + arrSrcZ);
    }
}

extern "C" __global__ void ShortAligned_DtoA1D_surf(unsigned short* src,
                    unsigned int arrSrcXInBytes, unsigned int width)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idxSurf = idx<<1;

    if (idxSurf < width) {
        unsigned short odata = src[idx];
        surf1Dwrite(odata, osurfref1D, idxSurf + arrSrcXInBytes);
    }
}

extern "C" __global__ void ShortAligned_DtoA1DLayered_surf(unsigned short* src,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcZ, unsigned int numLayers)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idz = threadIdx.z + blockIdx.z * blockDim.z;
    unsigned int idxSurf = idx<<1;

    if ((idxSurf < width) && (idz < numLayers)) {
        unsigned short odata = src[idz*(pitch>>1) + idx];
        surf1DLayeredwrite(odata, osurfref1DLayered, idxSurf + arrSrcXInBytes, idz + arrSrcZ);
    }
}

extern "C" __global__ void ShortAligned_DtoA2D_surf(unsigned short* src,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcY, unsigned int height)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idy = threadIdx.y + blockIdx.y * blockDim.y;
    unsigned int idxSurf = idx<<1;

    if ((idxSurf < width) && (idy < height)) {
        unsigned short odata = src[idy*(pitch>>1) + idx];
        surf2Dwrite(odata, osurfref2D, idxSurf + arrSrcXInBytes, idy + arrSrcY);
    }
}

extern "C" __global__ void ShortAligned_DtoA2DLayered_surf(unsigned short* src,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcY, unsigned int height,
                    unsigned int arrSrcZ, unsigned int numLayers, size_t srcHeight)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idy = threadIdx.y + blockIdx.y * blockDim.y;
    unsigned int idz = threadIdx.z + blockIdx.z * blockDim.z;
    unsigned int idxSurf = idx<<1;

    if ((idxSurf < width) && (idy < height) && (idz < numLayers)) {
        unsigned short odata = src[idz*(pitch>>1)*srcHeight + idy*(pitch>>1) + idx];
        surf2DLayeredwrite(odata, osurfref2DLayered, idxSurf + arrSrcXInBytes,
                           idy + arrSrcY, idz + arrSrcZ);
    }
}

extern "C" __global__ void ShortAligned_DtoA3D_surf(unsigned short* src,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcY, unsigned int height,
                    unsigned int arrSrcZ, unsigned int depth, size_t srcHeight)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idy = threadIdx.y + blockIdx.y * blockDim.y;
    unsigned int idz = threadIdx.z + blockIdx.z * blockDim.z;
    unsigned int idxSurf = idx<<1;

    if ((idxSurf < width) && (idy < height) && (idz < depth)) {
        unsigned short odata = src[idz*(pitch>>1)*srcHeight + idy*(pitch>>1) + idx];
        surf3Dwrite(odata, osurfref3D, idxSurf + arrSrcXInBytes, idy + arrSrcY,
                    idz + arrSrcZ);
    }
}

extern "C" __global__ void CharAligned_DtoA1D_surf(unsigned char* src,
                    unsigned int arrSrcXInBytes, unsigned int width)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;

    if (idx < width) {
        unsigned char odata = src[idx];
        surf1Dwrite(odata, osurfref1D, idx + arrSrcXInBytes);
    }
}

extern "C" __global__ void CharAligned_DtoA1DLayered_surf(unsigned char* src,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcZ, unsigned int numLayers)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idz = threadIdx.z + blockIdx.z * blockDim.z;

    if ((idx < width) && (idz < numLayers)) {
        unsigned char odata = src[idz*pitch + idx];
        surf1DLayeredwrite(odata, osurfref1DLayered, idx + arrSrcXInBytes, idz + arrSrcZ);
    }
}

extern "C" __global__ void CharAligned_DtoA2D_surf(unsigned char* src,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcY, unsigned int height)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idy = threadIdx.y + blockIdx.y * blockDim.y;

    if ((idx < width) && (idy < height)) {
        unsigned char odata = src[idy*pitch + idx];
        surf2Dwrite(odata, osurfref2D, idx + arrSrcXInBytes, idy + arrSrcY);
    }
}

extern "C" __global__ void CharAligned_DtoA2DLayered_surf(unsigned char* src,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcY, unsigned int height,
                    unsigned int arrSrcZ, unsigned int numLayers, size_t srcHeight)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idy = threadIdx.y + blockIdx.y * blockDim.y;
    unsigned int idz = threadIdx.z + blockIdx.z * blockDim.z;

    if ((idx < width) && (idy < height) && (idz < numLayers)) {
        unsigned char odata = src[idz*pitch*srcHeight + idy*pitch + idx];
        surf2DLayeredwrite(odata, osurfref2DLayered, idx + arrSrcXInBytes,
                           idy + arrSrcY, idz + arrSrcZ);
    }
}

extern "C" __global__ void CharAligned_DtoA3D_surf(unsigned char* src,
                    unsigned int arrSrcXInBytes, unsigned int width,
                    size_t pitch, unsigned int arrSrcY, unsigned int height,
                    unsigned int arrSrcZ, unsigned int depth, size_t srcHeight)
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idy = threadIdx.y + blockIdx.y * blockDim.y;
    unsigned int idz = threadIdx.z + blockIdx.z * blockDim.z;

    if ((idx < width) && (idy < height) && (idz < depth)) {
        unsigned char odata = src[idz*pitch*srcHeight + idy*pitch + idx];
        surf3Dwrite(odata, osurfref3D, idx + arrSrcXInBytes, idy + arrSrcY,
                    idz + arrSrcZ);
    }
}

// ARRAY->ARRAY
extern "C" __global__ void IntAligned_AtoA_surf(
                    unsigned int Width, unsigned int Height,
                    unsigned int arrSrcXInBytes, unsigned int arrSrcY,
                    unsigned int arrDstXInBytes, unsigned int arrDstY )
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idy = threadIdx.y + blockIdx.y * blockDim.y;
    unsigned int idxSurf = idx<<2;

    if( (idxSurf < Width) && (idy < Height) )
    {
        unsigned int data;

        surf2Dread( &data, isurfref2D, idxSurf + arrSrcXInBytes, idy + arrSrcY);
        surf2Dwrite( data, osurfref2D, idxSurf + arrDstXInBytes, idy + arrDstY);
    }
}

extern "C" __global__ void ShortAligned_AtoA_surf(
                    unsigned int Width, unsigned int Height,
                    unsigned int arrSrcXInBytes, unsigned int arrSrcY,
                    unsigned int arrDstXInBytes, unsigned int arrDstY )
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idy = threadIdx.y + blockIdx.y * blockDim.y;
    unsigned int idxSurf = idx<<1;

    if( (idxSurf < Width) && (idy < Height) )
    {
        unsigned short data;

        surf2Dread( &data, isurfref2D, idxSurf + arrSrcXInBytes, idy + arrSrcY);
        surf2Dwrite( data, osurfref2D, idxSurf + arrDstXInBytes, idy + arrDstY);
    }
}

extern "C" __global__ void CharAligned_AtoA_surf(
                    unsigned int Width, unsigned int Height,
                    unsigned int arrSrcXInBytes, unsigned int arrSrcY,
                    unsigned int arrDstXInBytes, unsigned int arrDstY )
{
    unsigned int idx = threadIdx.x + blockIdx.x * blockDim.x;
    unsigned int idy = threadIdx.y + blockIdx.y * blockDim.y;

    if( (idx < Width) && (idy < Height) )
    {
        unsigned char data;

        surf2Dread( &data, isurfref2D, idx + arrSrcXInBytes, idy + arrSrcY);
        surf2Dwrite( data, osurfref2D, idx + arrDstXInBytes, idy + arrDstY);
    }

}

// Helper function to copy an integer. Width must be aligned, byte width.
// idx must be byte index; i.e., int_idx<<=2;
extern "C" __device__ void
copyinteger( unsigned char* dst, unsigned char* src, ssize_t idx,
            ssize_t Width )
{
    unsigned int* srcAlignedRow = (unsigned int*)(uintptr_t)(src + idx);
    unsigned int* dstAlignedRow = (unsigned int*)(uintptr_t)(dst + idx);

    // idy < height checked before hand. idx already indexing integers.
    if((idx >= 0) && (idx < Width))
        *dstAlignedRow = *srcAlignedRow;
}



// --- Aligned 2D Copies ---

// Nicely aligned, but tall 2D copy. Call this kernel when height is greater
//  than 2^16, otherwise, 'smallsamepitch' or 'smalldiffpitch' is faster.

// Launch Configuration:
//  Width Blocks: (Width>>2 + OffDstX - 1 + (Width&3)?1:0)/threadsX + 1
//      *Loop width on host if width blocks > max grid width.
//  Height Blocks: MIN( Height/3 + 1, max grid height )
//  OffDstX: (dst&63)>>2
//  Note: Only call when src%4 == dst%4 == 0, and Width%4 == 0
extern "C" __global__ void
memcpyDtoD2D_aligned( unsigned char* dst, unsigned char* src,
                size_t Width, size_t Height, size_t PitchDst, size_t PitchSrc,
                ssize_t OffDstX )
{
    // OffDstX should be integer value to line up to a 64 byte boundary.
    ssize_t idx = (ssize_t)(threadIdx.x + blockIdx.x * blockDim.x) - OffDstX;
    size_t idy = blockIdx.y;

    // Integer index.
    idx <<= 2;

    // Compute initial row to copy on.
    src += idy*PitchSrc;
    dst += idy*PitchDst;

    // Dist to stride down with each loop iteration; stride down 1 grid height.
    size_t stridesrc = PitchSrc*gridDim.y;
    size_t stridedst = PitchDst*gridDim.y;

    // Hit as many rows as necessary to fill full image.
    while( idy < Height ) {
        // Copy integer
        copyinteger( dst, src, idx, Width );

        // Stride to next row.
        src += stridesrc;
        dst += stridedst;

        // Counter to know when done striding.
        idy += gridDim.y;
    }
}

// Nicely aligned 2D copy. Call this kernel when height is greater than 2^16
// and srcpitch = dstpitch. This is the fastest kernel for 2D.
//  
// Launch Configuration:
//  Width Blocks: (Width>>2 + OffDstX - 1 + (Width&3)?1:0)/threadsX + 1
//      *Loop width on host if width blocks > max grid width.
//  Height Blocks: Height
//  OffDstX: (dst&63)>>2
//  
template <typename T>
__forceinline__ __device__ void
memcpyDtoD2D_aligned_smallsamepitch_internal(
    unsigned char* dst, unsigned char* src, size_t Width, size_t Height,
    size_t PitchDst, size_t PitchSrc, ssize_t OffDstX)
{
    // OffDstX should be integer value to line up to a 64 byte boundary.
    ssize_t idx = (ssize_t)(threadIdx.x + blockIdx.x * blockDim.x) - OffDstX;
    
    // Integer index
    idx <<= 2;

    // Compute offset to row to set.
    T pitchprod = blockIdx.y * (T)PitchDst;
    dst += pitchprod;
    src += pitchprod;

    // And copy the integer.
    copyinteger( dst, src, idx, Width );
}

// Works only for 32-bit indices
extern "C" __global__ void
memcpyDtoD2D_aligned_smallsamepitch(
    unsigned char* dst, unsigned char* src, size_t Width, size_t Height,
    size_t PitchDst, size_t PitchSrc, ssize_t OffDstX)
{
    memcpyDtoD2D_aligned_smallsamepitch_internal<unsigned int>(dst, src, Width, Height,
                                                               PitchDst, PitchSrc, OffDstX);
}

// Works for 64-bit indices
extern "C" __global__ void
memcpyDtoD2D_aligned_smallsamepitch64(
    unsigned char* dst, unsigned char* src, size_t Width, size_t Height,
    size_t PitchDst, size_t PitchSrc, ssize_t OffDstX)
{
    memcpyDtoD2D_aligned_smallsamepitch_internal<size_t>(dst, src, Width, Height,
                                                         PitchDst, PitchSrc, OffDstX);
}

// Nicely aligned 2D copy. Call this kernel when height is greater than 2^16
// but srcpitch != dstpitch. This is second fastest kernel for 2D.
// 
// Launch Configuration:
//  Width Blocks: (Width>>2 + OffDstX - 1 + (Width&3)?1:0)/threadsX + 1
//      *Loop width on host if width blocks > max grid width.
//  Height Blocks: Height
//  OffDstX: (dst&63)>>2
//  
template <typename T>
__forceinline__ __device__ void
memcpyDtoD2D_aligned_smalldiffpitch_internal(
    unsigned char* dst, unsigned char* src, size_t Width, size_t Height,
    size_t PitchDst, size_t PitchSrc, ssize_t OffDstX)
{
    // OffDstX should be integer value to line up to a 64 byte boundary.
    ssize_t idx = (ssize_t)(threadIdx.x + blockIdx.x * blockDim.x) - OffDstX;
    // Integer index
    idx <<= 2;

    // Compute row to copy on.
    src += blockIdx.y * (T)PitchSrc;
    dst += blockIdx.y * (T)PitchDst;

    // And copy the integer.
    copyinteger( dst, src, idx, Width );
}

// Works only for 32-bit indices
extern "C" __global__ void
memcpyDtoD2D_aligned_smalldiffpitch(
    unsigned char* dst, unsigned char* src, size_t Width, size_t Height,
    size_t PitchDst, size_t PitchSrc, ssize_t OffDstX)
{
    memcpyDtoD2D_aligned_smalldiffpitch_internal<unsigned int>(dst, src, Width, Height,
                                                               PitchDst, PitchSrc, OffDstX);
}

// Works for 64-bit indices
extern "C" __global__ void
memcpyDtoD2D_aligned_smalldiffpitch64(
    unsigned char* dst, unsigned char* src, size_t Width, size_t Height,
    size_t PitchDst, size_t PitchSrc, ssize_t OffDstX)
{
    memcpyDtoD2D_aligned_smalldiffpitch_internal<size_t>(dst, src, Width, Height,
                                                         PitchDst, PitchSrc, OffDstX);
}

// --- Misaligned 2D Copies ---

// Poorly aligned 2D copy. This is the most general 2D copy for height < 2^16,
// which performs a byte-by-byte copy. Although this kernel is slow for large
// copies, it is fairly fast for small copies.
//  
// Launch Configuration:
//  Width Blocks: (Width + OffDstX - 1 + (Width&3)?1:0)/threadsX + 1
//      *Loop width on host if width blocks > max grid width.
//  Height Blocks: Height
//  OffDstX: dst&63
//  
template <typename T>
__forceinline__ __device__ void
memcpyDtoD2D_unalignedSmallHeight_internal(
    unsigned char* dst, unsigned char* src, size_t Width, size_t Height,
    size_t PitchDst, size_t PitchSrc, ssize_t OffDstX)
{
    // OffDst should be number of bytes to line up to a 64 byte boundary.
    ssize_t idx = (ssize_t)(threadIdx.x + blockIdx.x * blockDim.x) - OffDstX;
    size_t idy = blockIdx.y;

    T dstindex = blockIdx.y * (T)PitchDst + idx;
    T srcindex = blockIdx.y * (T)PitchSrc + idx;

    // If in bounds, copy. Use umul24 because this is only for small copies.
    if( (idx >= 0) && (idx < Width) && (idy < Height) )
        dst[ dstindex ] = src[ srcindex ];
}

// Works only for 32-bit indices
extern "C" __global__ void
memcpyDtoD2D_unalignedSmallHeight(
    unsigned char* dst, unsigned char* src, size_t Width, size_t Height,
    size_t PitchDst, size_t PitchSrc, ssize_t OffDstX)
{
    memcpyDtoD2D_unalignedSmallHeight_internal<int>(dst, src, Width, Height,
                                                    PitchDst, PitchSrc, OffDstX);
}

// Works for 64-bit indices
extern "C" __global__ void
memcpyDtoD2D_unalignedSmallHeight64(
    unsigned char* dst, unsigned char* src, size_t Width, size_t Height,
    size_t PitchDst, size_t PitchSrc, ssize_t OffDstX)
{
    memcpyDtoD2D_unalignedSmallHeight_internal<ssize_t>(dst, src, Width, Height,
                                                        PitchDst, PitchSrc, OffDstX);
}

// Somewhat poorly aligned 2D copy. This kernel is for 2D copies where
//  alignof( dst ) == alignof( src ), but Width % 4 != 0, so a few extra bytes
//  at the end must be copied.

// Launch Configuration:
//  Width Blocks: (Width>>2 + OffDstX - 1 + (Width&3)?1:0)/threadsX + 1 + 1
//      *Loop width on host if width blocks > max grid width.
//  Height Blocks: MIN( Height/3 + 1, max grid height )
//  OffDstX: (dst&63)>>2
//  Note: There must be 1 buffer block in X launched, thus the extra +1
extern "C" __global__ void
memcpyDtoD2D_alignedSrcDst( unsigned char* dst, unsigned char* src,
                size_t Width, size_t Height, size_t PitchDst, size_t PitchSrc,
                ssize_t OffDstX )
{
    // OffDst should be number of ints to line up to a 64 byte boundary.
    ssize_t idx = (ssize_t)(threadIdx.x + blockIdx.x * blockDim.x) - OffDstX;
    size_t idy = blockIdx.y;

    // Compute initial row to work on.
    src += idy*PitchSrc;
    dst += idy*PitchDst;

    // Compute the width aligned to the number of integers to be copied.
    ssize_t alignedWidth = GET_ALIGNED_WIDTH( Width, dst );

    // Compute stride to step down rows.
    size_t stridesrc = PitchSrc*gridDim.y;
    size_t stridedst = PitchDst*gridDim.y;

    // If it's in range of the main threads.
    if( (idx >= 0) && (idx < alignedWidth) && (Width > 3) ) {
        // Step down all the rows to copy.
        while( idy < Height ) {
            // Compute misalignment from integer boundary to the right of dst.
            unsigned int misalign = LEFT_BYTE_MISALIGN( dst );
            // Align the row pointer.
            unsigned char* srcrow = src + misalign;
            unsigned char* dstrow = dst + misalign;

            // Align to integer.
            unsigned int* srcAlignedRow = (unsigned int*)(uintptr_t)(srcrow);
            unsigned int* dstAlignedRow = (unsigned int*)(uintptr_t)(dstrow);

            // Copy..
            dstAlignedRow[ idx ] = srcAlignedRow[ idx ];

            // Update pointers and counters to stride down region.
            src += stridesrc;
            dst += stridedst;
            idy += gridDim.y;
        }
    }
    // Use the buffer block to copy the misaligned bytes at start and end.
    // Make sure threadIdx.x < Width to ensure too much isn't copied.
    else if( (blockIdx.x == gridDim.x-1) && (threadIdx.x < Width) ) {   
        // Still have to stride down the height.
        while( idy < Height ) {
            // Get number of misaligned bytes to copy.
            unsigned int misalign = LEFT_BYTE_MISALIGN( dst );

            // And copy them with seperate threads.
            if(threadIdx.x < misalign)
                dst[threadIdx.x] = src[threadIdx.x];

            // Get the right misaligned bytes
            misalign = (unsigned int)((uintptr_t)(dst + Width )&0x3);

            // And copy them with seperate threads again.
            if(threadIdx.x < misalign)
                dst[ Width-threadIdx.x-1 ] = src[ Width-threadIdx.x-1 ];

            // Update pointers and counter to stride down region.
            src += stridesrc;
            dst += stridedst;
            idy += gridDim.y;
        }
    }
}


// --- Aligned 1D Copy ---

// TODO: We can delete all the Aligned 1D copy kernels once we've
//       determined that the kernels in memcpy1D.cu have been
//       adequately tested.  The kernels that can be removed are:
//
//           memcpyDtoD_aligned
//           memcpyDtoD_aligned64

// Nicely aligned 1D copy.
// 
// Launch Configuration:
//  Width Blocks Initial: (Width>>2 + OffDstX - 1 + (Width&3)?1:0)/threadsX + 1
//  Height Blocks Initial: 1
//  OffDstX: (dst&63)>>2
//  Note: The width block count must be cut in half, and moved to height blocks
//      until width block count < max blocks width.
//      Do this with:
//      while( grid.width > maxBlocksX ) {
//          grid.width = 1 + (grid.width/2); grid.height *= 2;
//      }
//      
template <typename T>
__forceinline__ __device__ void
memcpyDtoD_aligned_internal(unsigned char* dst, unsigned char* src, T Width, int OffDstX)
{
    // How many words were copied before this block.
    T prev_words =(T)(blockDim.x * (gridDim.x*blockIdx.y+blockIdx.x));
    // T prev_words =blockDim.x * ((T)gridDim.x * blockIdx.y + blockIdx.x);
    // Modified by offset to align read/write.
    prev_words -= OffDstX;
    // Word index considering other threads in block.
    T cur_word = prev_words + threadIdx.x;
    // Byte index for word to copy.
    cur_word <<= 2;

    // Aligned src and dst pointers to the int to copy.
    unsigned int* srcAligned = (unsigned int*) ((uintptr_t)src + cur_word);
    unsigned int* dstAligned = (unsigned int*) ((uintptr_t)dst + cur_word);

    // If it's in bounds, copy the integer.
    if( (cur_word >= 0) && (cur_word < Width) )
        *dstAligned = *srcAligned;
}

// Works only for 32-bit indices
extern "C" __global__ void
memcpyDtoD_aligned(unsigned char* dst, unsigned char* src, int Width, int OffDstX)
{
    memcpyDtoD_aligned_internal<int>(dst, src, Width, OffDstX);
}

// Works for 64-bit indices
extern "C" __global__ void
memcpyDtoD_aligned64(unsigned char* dst, unsigned char* src, ssize_t Width, int OffDstX)
{
    memcpyDtoD_aligned_internal<ssize_t>(dst, src, Width, OffDstX);
}

// --- Misaligned 1D copies ---

// TODO: We can delete all the Misaligned 1D copy kernels once we've
//       determined that the kernels in memcpy1D.cu have been
//       adequately tested.  The kernels that can be removed are:
//
//           memcpyDtoD_alignedSrcDst
//           memcpyDtoD_alignedSrcDst64

// 1D copy where alignof( dst ) == alignof( src ), 32bit only.

// Launch Configuration:
//  Width Blocks Initial: (Width>>2 + OffDstX - 1 + (Width&3)?1:0)/threadsX + 1
//  Height Blocks Initial: 1
//  OffDstX: (64 - (dst&63))&63
//  Note: The width block count must be cut in half, and moved to height blocks
//      until width block count < max blocks width.
//      Do this with:
//      while( grid.width > maxBlocksX ) {
//          grid.width = 1 + (grid.width/2); grid.height *= 2;
//      }
//      
template <typename T>
__forceinline__ __device__ void
memcpyDtoD_alignedSrcDst_internal(unsigned char* dst, unsigned char* src, T Width, int OffDstX)
{
    T count = Width;
    T unalignment = OffDstX;
    T excessBytes = (count - unalignment)&(0x3);
    T alignedWidth = count-unalignment-excessBytes;

    // Copy initial misalignment bytes.
    // threadIdx.y == 0 necessarily, but is left in for perf reasons.
    // See bug 584574
    if( (blockIdx.x == 0) && (blockIdx.y == 0) && (threadIdx.x < unalignment) &&
        (threadIdx.y == 0) ) {
        dst[threadIdx.x] = src[threadIdx.x];
    }

    // Copy end misalignment bytes. Same bug 584574
    if( (blockIdx.x == 0) && (blockIdx.y == 0) && (threadIdx.x < excessBytes) &&
        (threadIdx.y == 0) ) {
        T index = count - excessBytes + threadIdx.x;
        dst[ index ] = src[ index ];
    }

    //# words computed before this block
    T prev_words = blockDim.x * (blockIdx.y*gridDim.x + blockIdx.x);
    T cur_word = prev_words + threadIdx.x;
    cur_word <<= 2;

    //Now src, dst, and count are aligned and will coalesce 
    unsigned int* srcAligned = (unsigned int*)((char*)src+unalignment+cur_word);
    unsigned int* dstAligned = (unsigned int*)((char*)dst+unalignment+cur_word);

    if( cur_word < alignedWidth )
        *dstAligned = *srcAligned;
}

// Works only for 32-bit indices
extern "C" __global__ void
memcpyDtoD_alignedSrcDst(unsigned char* dst, unsigned char* src, unsigned int Width, int OffDstX)
{
    memcpyDtoD_alignedSrcDst_internal<unsigned int>(dst, src, Width, OffDstX);
}

// Works for 64-bit indice
extern "C" __global__ void
memcpyDtoD_alignedSrcDst64(unsigned char* dst, unsigned char* src, size_t Width, int OffDstX)
{
    memcpyDtoD_alignedSrcDst_internal<size_t>(dst, src, Width, OffDstX);
}


// --- Aligned 3D copies ---

// Nicely aligned 3D memcpy with height < 2^16.

// Launch Configuration:
//  Width Blocks: (Width>>2 + OffDstX - 1 + (Width&3)?1:0)/threadsX + 1
//      *Loop width on host if width blocks > max grid width.
//  Height Blocks: Height
//  OffDstX: (dst&63)>>2
//  Note: This kernel will not work for height >= 2^16. Launch 2D slices
//          to cover that height case; nested while loops was too slow.
extern "C" __global__ void
memcpyDtoD3D_aligned( unsigned char* dst, unsigned char* src,
                    size_t Width, size_t Height, size_t Depth,
                    size_t PitchDst, size_t PitchSrc,
                    size_t StrideDepthDst, size_t StrideDepthSrc,
                    ssize_t OffDstX )
{
    // Get 64 byte aligned index.
    ssize_t idx =(ssize_t)(threadIdx.x + blockIdx.x * blockDim.x) - OffDstX;
    idx <<= 2;

    // Get row to copy.
    dst += blockIdx.y * PitchDst;
    src += blockIdx.y * PitchSrc;

    // Stride down depth doing copies of row.
    unsigned int idz = 0;
    while( idz < Depth ) {
        copyinteger( dst, src, idx, Width );

        dst += StrideDepthDst;
        src += StrideDepthSrc;
        idz++;
    }
}

// --- Misaligned 3D copies ---

// 3D memcpy with height < 2^16, and alignof( dst ) == alignof( src )

// Launch Configuration:
//  Width Blocks: (Width>>2 + OffDstX - 1 + (Width&3)?1:0)/threadsX + 1 + 1
//      *Loop width on host if width blocks > max grid width.
//  Height Blocks: Height
//  OffDstX: (dst&63)>>2
//  Note: This kernel will not work for height >= 2^16. Launch 2D slices
//          to cover that height case; nested while loops was too slow.
//        This must have a buffer block in X to copy misalign bytes, this is
//          the cause of the extra + 1 in width blocks calculation.
extern "C" __global__ void
memcpyDtoD3D_alignedSrcDst( unsigned char* dst, unsigned char* src,
                    size_t Width, size_t Height, size_t Depth,
                    size_t PitchDst, size_t PitchSrc,
                    size_t StrideDepthDst, size_t StrideDepthSrc,
                    ssize_t OffDstX )
{
    // Get 64 byte aligned index.
    ssize_t idx = (ssize_t)(threadIdx.x + blockIdx.x * blockDim.x) - OffDstX;

    // Compute row to copy.
    dst += blockIdx.y * PitchDst;
    src += blockIdx.y * PitchSrc;
    
    unsigned int idz = 0;

    // Compute the left misalignment
    unsigned int misalign = LEFT_BYTE_MISALIGN( dst );
    unsigned int alignedWidth = (Width - misalign)>>2;

    // If in range, and width is large enough to copy an int, copy.
    if((idx >= 0) && (idx < alignedWidth) && (Width > 3)) {
        // Stride down depth, copying rows.
        while( idz < Depth ) {

            // Get int aligned src and dst rows.
            unsigned char* srcrow = src + misalign;
            unsigned char* dstrow = dst + misalign;

            // Get the int pointers for those rows.
            unsigned int* srcAlignedRow = (unsigned int*)(uintptr_t)(srcrow);
            unsigned int* dstAlignedRow = (unsigned int*)(uintptr_t)(dstrow);

            dstAlignedRow[ idx ] = srcAlignedRow[ idx ];

            // Update counters and pointers to stride down depth.
            misalign = LEFT_BYTE_MISALIGN( dst );
            dst += StrideDepthDst;
            src += StrideDepthSrc;
            idz++;
        }
    }
    // If in the padding block, and won't copy too many elements ( < Width)
    else if( (blockIdx.x == gridDim.x-1) && (threadIdx.x < Width) ) {   
        while( idz < Depth ) {

            // Copy the bytes before the integer alignment
            if(threadIdx.x < misalign)
                dst[threadIdx.x] = src[threadIdx.x];

            // And copy the last misaligned bytes.
            misalign = (unsigned int)((uintptr_t)(dst + Width )&0x3);
            if(threadIdx.x < misalign)
                dst[ Width-threadIdx.x-1 ] = src[ Width-threadIdx.x-1 ];

            // Update counters and pointers to stride down depth.
            misalign = LEFT_BYTE_MISALIGN( dst );
            dst += StrideDepthDst;
            src += StrideDepthSrc;
            idz++;
        }
    }
}

