/*
 * Copyright 1993-2011 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

#include "kernel_memcpy.h"
#include "kernel_memcpy_internal.h"
#include "kernel_internal.h"
#include "bikernels.h"
#include "cuiarray.h"
#include <math.h>

// Boundary at which minimal kernels can be faster, so launch them instead.
#define SMALL_COPY_WIDTH 64
#define SMALL_COPY_HEIGHT 64
#define SMALL_COPY_BOUNDARY (SMALL_COPY_WIDTH*SMALL_COPY_HEIGHT)

// Flags to help say which kernel launch to use.
#define USE_1D 0
#define USE_2D 1
#define USE_3D 2

#define ATOD 0
#define DTOA 1

// Max num slices for a 3D copy to be done with 2D sliced copies.
#define MAX_NUM_SLICES 15 

// Return true if 32 bits are enough to represent indices.
#define CAN_USE_32BIT_KERNEL(height, pitchSrc, pitchDst) ((height * pitchSrc < INT_MAX) && \
                                                          (height * pitchDst < INT_MAX))

// The cost of using 64-bit kernels can be in excess of 15% over 32-bit counterparts
// on Kepler, with the gap closing in on newer archs. Thus, use the 64-bit kernel
// only when it is actually necessary.
#define SELECT_32_OR_64_BIT_KERNEL(height, pitchSrc, pitchDst, kernel32, kernel64) \
            CAN_USE_32BIT_KERNEL(Height, PitchSrc, PitchDst) ? kernel32 : kernel64;

// Launch array to device, device to array memcopy kernels.
static CUresult 
gt200ArrayDeviceMemcpy(CUctx* ctx, CUfunc *func, CUIstream *stream,
                       unsigned int threadsX, unsigned int threadsY,
                       unsigned int threadsZ, void *dptr,
                       unsigned int WidthInBytes, unsigned int Height,
                       unsigned int Depth, size_t Pitch, size_t dptrHeight,
                       unsigned int arrSrcXInBytes, unsigned int arrSrcY,
                       unsigned int arrSrcZ, unsigned int BytesPerElem,
                       CUIarrayType arrType)
{
    CUresult status = CUDA_SUCCESS;

    unsigned int cBlocksX = (WidthInBytes > BytesPerElem*threadsX) ?
                            ((((WidthInBytes/BytesPerElem)-1)/threadsX)+1) : 1;

    unsigned int cBlocksY = (Height > threadsY) ? ((Height-1)/threadsY + 1) : 1;

    unsigned int cBlocksZ = (Depth > threadsZ) ? ((Depth-1)/threadsZ + 1) : 1;

    CUdim3 gridDim = { (NvU32)cBlocksX, (NvU32)cBlocksY, (NvU32)cBlocksZ };

    // Offset for setting parameters.
    unsigned int offset = 0;

    // Set block shape.
    status = cuiFuncSetBlockShape( func, threadsX, threadsY, threadsZ );
    if( status != CUDA_SUCCESS ) {
        CU_ERROR_PRINT(("Couldn't set block shape.\n"));
        return status;
    }

    SETPARAMV( dptr,            status, offset, 1 );
    SETPARAMV( arrSrcXInBytes,  status, offset, 2 );
    SETPARAMV( WidthInBytes,    status, offset, 3 );
    if (cuiDeviceArchIsMaxwellPlus(ctx->device) ||
        (arrType != CUI_ARRAY_TYPE_1D)) {
        SETPARAMV( Pitch,           status, offset, 4 );
        if (arrType == CUI_ARRAY_TYPE_1D_LAYERED) {
            SETPARAMV( arrSrcZ,         status, offset, 5 );
            SETPARAMV( Depth,          status, offset, 6 );
        }
        else {
            SETPARAMV( arrSrcY,         status, offset, 5 );
            SETPARAMV( Height,          status, offset, 6 );
            if ((arrType != CUI_ARRAY_TYPE_1D) && (arrType != CUI_ARRAY_TYPE_2D)) {
                SETPARAMV( arrSrcZ,         status, offset, 7 );
                SETPARAMV( Depth,           status, offset, 8 );
                SETPARAMV( dptrHeight,      status, offset, 9 );
            }
        }
    }

    status = cuiParamSetSize( func, offset );
    if( status != CUDA_SUCCESS ) {
        CU_ERROR_PRINT(("Couldn't set param size.\n"));
        return status;
    }

    status = cuiLaunchGrid( func, gridDim, stream, NULL, 0 );
    if( status != CUDA_SUCCESS ) {
        CU_ERROR_PRINT(("Launch failure.\n"));
        return status;
    }

    return status;
}


// Launch array to array memcopy kernels.
static CUresult
gt200ArrayArrayMemcpy(CUctx* ctx, CUfunc* func, CUIstream *stream,
                      unsigned int maxBlocksX, unsigned int maxBlocksY,
                      unsigned int threadsX, unsigned int threadsY,
                      unsigned int WidthInBytes, unsigned int Height,
                      unsigned int arrSrcXInBytes, unsigned int arrSrcY,
                      unsigned int arrDstXInBytes, unsigned int arrDstY,
                      unsigned int BytesPerElem)
{
    CUresult status = CUDA_SUCCESS;

    unsigned int cBlocksX = (WidthInBytes >= BytesPerElem) ?
                            (((WidthInBytes/BytesPerElem)-1)/(threadsX)+1) : 1;

    unsigned int cBlocksY = (Height > 0) ? ((Height-1)/threadsY + 1) : 1;

    CUdim3 gridDim = { (NvU32)cBlocksX, (NvU32)cBlocksY, 1 };

    // Offset for setting parameters.
    unsigned int offset = 0;

    // Set block shape.
    status = cuiFuncSetBlockShape( func, threadsX, threadsY, 1 );
    if( status != CUDA_SUCCESS ) {
        CU_ERROR_PRINT(("Couldn't set block shape.\n"));
        return status;
    }

    SETPARAMV( WidthInBytes,    status, offset, 1 );
    SETPARAMV( Height,          status, offset, 2 );
    SETPARAMV( arrSrcXInBytes,  status, offset, 3 );
    SETPARAMV( arrSrcY,         status, offset, 4 );
    SETPARAMV( arrDstXInBytes,  status, offset, 5 );
    SETPARAMV( arrDstY,         status, offset, 6 );

    status = cuiParamSetSize( func, offset );
    if( status != CUDA_SUCCESS ) {
        CU_ERROR_PRINT(("Couldn't set param size.\n"));
        return status;
    }

    status = cuiLaunchGrid( func, gridDim, stream, NULL, 0 );
    if( status != CUDA_SUCCESS ) {
        CU_ERROR_PRINT(("Launch failure.\n"));
        return status;
    }

    return status;
}


// Kernel launch function for several 1D memcopies.
static CUresult
gt200Memcpy1D(CUctx* ctx, CUfunc *func, CUIstream *stream,
              unsigned int maxBlocksX, unsigned int maxBlocksY,
              unsigned int threadsX, unsigned int threadsY,
              const CUImemcpyDesc *copyDesc,
              unsigned char *dst, unsigned char *src,
              size_t WidthInBytes, size_t OffDstX)
{
    CUresult status = CUDA_SUCCESS;

    int off = (int)OffDstX;
    int IntWidth = (int)WidthInBytes;

    // If this is very wide, we need to use the 64 bit kernels.
    int use_64bit = ( ( WidthInBytes >= INT_MAX ) ? 1 : 0 );


    // Might need an extra block if the width%4 != 0
    unsigned int bufferX = ( WidthInBytes&3 ) ? 1 : 0;

    // Compute number of blocks, taking into account the offset from
    // 64 byte aligned, the width misalignment, and the curW in ints.
    size_t cBlocksX =
            (size_t)( ((WidthInBytes>>2)+OffDstX-1+bufferX)/(threadsX) + 1);

    // Initially 1 Y block.
    unsigned int cBlocksY = 1;

    // Set after computing numYBlocks needed.
    CUdim3 gridDim;

    // Offset for setting parameters.
    unsigned int offset = 0;

    // Different cBlocksX calculation for alignedSrcDst.
    if( func == ctx->kernelmemcpy.tesla->memcpyDtoD_alignedSrcDst ||
        func == ctx->kernelmemcpy.tesla->memcpyDtoD_alignedSrcDst64 ) {
        cBlocksX =
            (((WidthInBytes>>2)+((64-OffDstX)&63)-1+bufferX)/(threadsX) + 1);
    }

    // Modify grid shape until grid fits on device.
    while( cBlocksX > (size_t)maxBlocksX ) {
        cBlocksX = 1 + (cBlocksX / 2);
        cBlocksY *= 2;
    }

    // cBlocksX now fits in 32bits.
    gridDim.x = (unsigned int)cBlocksX;
    // For 40 bit addresses, cBlocksY has to be < 2^16 ( = maxBlocksY).
    gridDim.y = (unsigned int)cBlocksY;
    gridDim.z = 1;

    // Set block shape.
    status = cuiFuncSetBlockShape( func, threadsX, 1, 1 );
    if( status != CUDA_SUCCESS ) {
        CU_ERROR_PRINT(("Couldn't set block shape.\n"));
        return status;
    }

    // Set various parameters (this macro also checks errors).
    SETPARAMV( dst,     status, offset, 1 );
    SETPARAMV( src,     status, offset, 2 );

    // 64bit kernel takes size_t WidthInBytes, 32 takes unsigned int.
    if( use_64bit ) {
        SETPARAMV( WidthInBytes,    status, offset, 3 );
    }
    else {
        SETPARAMV( IntWidth,    status, offset, 3 );
    }

    SETPARAMV( off,     status, offset, 4 );

    status = cuiParamSetSize( func, offset );
    if( status != CUDA_SUCCESS ) {
        CU_ERROR_PRINT(("Couldn't set param size.\n"));
        return status;
    }

    // track memobjs required for opencl
    kernelMemcpyTrackMemobj(ctx, func, copyDesc);

    status = cuiLaunchGrid( func, gridDim, stream, NULL, 0 );
    if( status != CUDA_SUCCESS ) {
        CU_ERROR_PRINT(("Launch failure.\n"));
        return status;
    }

    return status;
}

// Kernel launch function for 2D memcopies, several 1D copies, and thin 3D copy
static CUresult
gt200Memcpy2D(CUctx* ctx, CUfunc *func, CUIstream *stream,
              unsigned int maxBlocksX,unsigned int maxBlocksY,
              unsigned int threadsX, unsigned int threadsY,
              const CUImemcpyDesc *copyDesc,
              unsigned char *dst, unsigned char *src,
              size_t WidthInBytes, size_t Height,
              size_t PitchDst, size_t PitchSrc,
              size_t OffDstX)
{
    CUresult status = CUDA_SUCCESS;

    // Max num elements that can be copied with one grid in each dim.
    const size_t maxWidth = (size_t)threadsX * (size_t)maxBlocksX;
    size_t baseX = 0;

    // Stride along width in host, while the numBlocksX doesn't fit on grid.
    while( baseX < WidthInBytes ) {
        // Get current width along stride.
        size_t curW = MIN( (WidthInBytes - baseX), maxWidth );

        // And offset pointers.
        char* tmpDst = (char*)((intptr_t)dst + (intptr_t)baseX);
        char* tmpSrc = (char*)((intptr_t)src + (intptr_t)baseX);

        // Compute numBlocksX, including OffDstX, and possible width misalign.
        unsigned int bufferX = ( curW&3 ) ? 1 : 0;
        unsigned int cBlocksX =
                (unsigned int)( ((curW>>2)+OffDstX-1+bufferX)/(threadsX) + 1);

        // Compute numBlocksY; height/3 generally a good height to launch,
        // if it fits on the device. Otherwise, just launch height.
        unsigned int cBlocksY = MIN( (unsigned int)(Height)/3 + 1, maxBlocksY );

        // Set the region grid.
        CUdim3 gridDim = { (NvU32)cBlocksX, (NvU32)cBlocksY, 1 };

        // Set block shape, parameters.
        unsigned int offset = 0;

        // Special cases for functions that need modified grid shapes.

        // AlignedSrcDst needs a buffer block.
        if( func == ctx->kernelmemcpy.tesla->memcpyDtoD2D_alignedSrcDst ) {
            gridDim.x++;
        }

        // smallsamepitch and smalldiffpitch need 1 blockY per row.
        else if( func == ctx->kernelmemcpy.tesla->memcpyDtoD2D_aligned_smallsamepitch ||
                 func == ctx->kernelmemcpy.tesla->memcpyDtoD2D_aligned_smallsamepitch64 ||
                 func==ctx->kernelmemcpy.tesla->memcpyDtoD2D_aligned_smalldiffpitch ||
                 func==ctx->kernelmemcpy.tesla->memcpyDtoD2D_aligned_smalldiffpitch64 ){
            gridDim.y = (NvU32)Height;
        }

        // unalignedsmall needs a threadX per byte, and 1 block per Y.
        else if( func == ctx->kernelmemcpy.tesla->memcpyDtoD2D_unalignedSmallHeight ||
                 func == ctx->kernelmemcpy.tesla->memcpyDtoD2D_unalignedSmallHeight64 ) {
            gridDim.x = (NvU32)((curW + OffDstX - 1)/(threadsX) + 1);
            gridDim.y = (NvU32)Height;
        }


        // Set block shape.
        status = cuiFuncSetBlockShape( func, threadsX, threadsY, 1 );
        if( status != CUDA_SUCCESS ) {
            CU_ERROR_PRINT(("Couldn't set block shape.\n"));
            return status;
        }

        // Set parameters
        SETPARAMV( tmpDst,   status, offset, 1 );
        SETPARAMV( tmpSrc,   status, offset, 2 );
        SETPARAMV( curW,     status, offset, 3 );
        SETPARAMV( Height,   status, offset, 4 );
        SETPARAMV( PitchDst, status, offset, 5 );
        SETPARAMV( PitchSrc, status, offset, 6 );
        SETPARAMV( OffDstX,  status, offset, 7 );

        status = cuiParamSetSize( func, offset );
        if( status != CUDA_SUCCESS ) {
            CU_ERROR_PRINT(("Couldn't set param size.\n"));
            return status;
        }

        // track memobjs required for opencl
        kernelMemcpyTrackMemobj(ctx, func, copyDesc);

        status = cuiLaunchGrid( func, gridDim, stream, NULL, 0 );
        if( status != CUDA_SUCCESS ) {
            CU_ERROR_PRINT(("Launch failure.\n"));
            return status;
        }

        // Stride along width.
        baseX += maxWidth;
    }
    return CUDA_SUCCESS;
}


// Kernel launch for 3D memcopies, with height < maxBlocksY, and depth > slices 
static CUresult
gt200Memcpy3D(CUctx* ctx, CUfunc *func, CUIstream *stream,
              unsigned int maxBlocksX,unsigned int maxBlocksY,
              unsigned int threadsX, unsigned int threadsY,
              const CUImemcpyDesc *copyDesc,
              unsigned char *dst, unsigned char *src,
              size_t WidthInBytes, size_t Height,
              size_t PitchDst, size_t PitchSrc,
              size_t HeightDst, size_t HeightSrc,
              size_t Depth, size_t OffDstX)
{
    CUresult status = CUDA_SUCCESS;

    // Max num elements that can be copied with one grid in each dim.
    const size_t maxWidth = (size_t)threadsX * (size_t)maxBlocksX;
    const size_t maxHeight = (size_t)threadsY * (size_t)maxBlocksY;

    // Precompute stride for depth.
    size_t StrideDepthDst = PitchDst*HeightDst;
    size_t StrideDepthSrc = PitchSrc*HeightSrc;

    size_t baseX = 0;
    size_t baseY = 0;

    // Stride along height in host, while numBlocksY doesn't fit on grid.
    while( baseY < Height ) {
        size_t curH = MIN( (Height-baseY), maxHeight );

        // Stride along width in host, while the numBlocksX doesn't fit on grid.
        while( baseX < WidthInBytes ) {
            // Get current width along stride.
            size_t curW = MIN( (WidthInBytes - baseX), maxWidth );

            // And offset pointers.
            char* tmpDst = (char*)((intptr_t)dst +
                            (intptr_t)( baseY*PitchDst + baseX));
            char* tmpSrc = (char*)((intptr_t)src +
                            (intptr_t)( baseY*PitchSrc + baseX) );

            // Compute numBlocksX, including OffDstX, and width misalign.
            unsigned int bufferX = ( curW&3 ) ? 1 : 0;
            unsigned int cBlocksX =
                    (unsigned int)( ((curW>>2)+OffDstX-1+bufferX)/(threadsX)+1);

            // 3D kernels don't support striding in Y dimension.
            unsigned int cBlocksY = (NvU32)Height;

            // Set the region grid.
            CUdim3 gridDim = { (NvU32)cBlocksX, (NvU32)cBlocksY, 1 };

            // Set block shape, parameters.
            unsigned int offset = 0;

            // Special cases for functions that need modified grid shapes.

            // AlignedSrcDst needs a buffer block.
            if( func == ctx->kernelmemcpy.tesla->memcpyDtoD3D_alignedSrcDst ) {
                gridDim.x++;
            }


            // Set block shape.
            status = cuiFuncSetBlockShape( func, threadsX, threadsY, 1 );
            if( status != CUDA_SUCCESS ) {
                CU_ERROR_PRINT(("Couldn't set block shape.\n"));
                return status;
            }

            // Set parameters.
            SETPARAMV( tmpDst,          status, offset, 1  );
            SETPARAMV( tmpSrc,          status, offset, 2  );
            SETPARAMV( curW,            status, offset, 3  );
            SETPARAMV( curH,            status, offset, 4  );
            SETPARAMV( Depth,           status, offset, 5  );
            SETPARAMV( PitchDst,        status, offset, 6  );
            SETPARAMV( PitchSrc,        status, offset, 7  );
            SETPARAMV( StrideDepthDst,  status, offset, 8  );
            SETPARAMV( StrideDepthSrc,  status, offset, 9  );
            SETPARAMV( OffDstX,         status, offset, 10 );

            status = cuiParamSetSize( func, offset );
            if( status != CUDA_SUCCESS ) {
                CU_ERROR_PRINT(("Couldn't set param size.\n"));
                return status;
            }

            // track memobjs required for opencl
            kernelMemcpyTrackMemobj(ctx, func, copyDesc);

            status = cuiLaunchGrid( func, gridDim, stream, NULL, 0 );
            if( status != CUDA_SUCCESS ) {
                CU_ERROR_PRINT(("Launch failure.\n"));
                return status;
            }

            // Stride along width.
            baseX += maxWidth;
        }

        // Step to next height-slice.
        baseY += maxHeight;
    }
    return status;
}

CUresult
gt200KernelMemcpy3DDtoD(CUctx *ctx, 
                        const CUImemcpyDesc *copyDesc, 
                        CUIstream *stream, 
                        CUImemcpyCbInfo *copyCbInfo)
{
    CUresult status = CUDA_SUCCESS;
    size_t PitchDst, PitchSrc, HeightDst, HeightSrc;
    size_t WidthInBytes, Height, Depth;
    unsigned char *dst;
    unsigned char *src;
    unsigned int threadsX = 128;    // Pretty universally the best from testing.
    unsigned int threadsY = 1;      // No kernels use threadsY > 1.
    unsigned int dstAlignment;
    unsigned int dstByteAlignment;
    unsigned int dstPitchAlignment;
    unsigned int srcByteAlignment;
    unsigned int srcPitchAlignment;
    unsigned int widthByteAlignment;

    CUfunc *func = NULL;
    size_t OffDstX = 0;
    unsigned int maxBlocksX;
    unsigned int maxBlocksY;
    unsigned int useLauncher;


    CU_TRACE_FUNCTION();
    CU_ASSERT(ctx && copyDesc && stream && copyCbInfo);
    CU_ASSERT( copyDesc->src.type == CUI_MEMCPY_DATA_TYPE_MEMOBJ );
    CU_ASSERT( copyDesc->dst.type == CUI_MEMCPY_DATA_TYPE_MEMOBJ );

    // set up copy extent
    Height = (size_t)( (copyDesc->extent.height == 0) ? 1 : copyDesc->extent.height );
    Depth  = (size_t)( (copyDesc->extent.depth  == 0) ? 1 : copyDesc->extent.depth );
    WidthInBytes = (size_t) copyDesc->extent.widthInBytes;

    // set up pitch and height
    PitchDst  = (size_t)( copyDesc->dst.memobj.pitch  ? copyDesc->dst.memobj.pitch  : WidthInBytes );
    PitchSrc  = (size_t)( copyDesc->src.memobj.pitch  ? copyDesc->src.memobj.pitch  : WidthInBytes );
    HeightDst = (size_t)( copyDesc->dst.memobj.height ? copyDesc->dst.memobj.height : 1 );
    HeightSrc = (size_t)( copyDesc->src.memobj.height ? copyDesc->src.memobj.height : 1 );

    // get origin of src/dst
    dst = (unsigned char *)(uintptr_t) cuiMemcpyOperandGetOriginAddr(&copyDesc->dst);
    src = (unsigned char *)(uintptr_t) cuiMemcpyOperandGetOriginAddr(&copyDesc->src);

    // Compute various alignments to help determine which kernel to use.
    dstAlignment = (unsigned int)( (size_t)dst & MEMCPY_ALIGNMENT_64 );
    dstByteAlignment  = (unsigned int)( (size_t)dst & MEMCPY_ALIGNMENT_4 );
    srcByteAlignment  = (unsigned int)( (size_t)src & MEMCPY_ALIGNMENT_4 );
    dstPitchAlignment = (unsigned int)( (size_t)PitchDst & MEMCPY_ALIGNMENT_4 );
    srcPitchAlignment = (unsigned int)( (size_t)PitchSrc & MEMCPY_ALIGNMENT_4 );    
    widthByteAlignment =(unsigned int)( (size_t)WidthInBytes & MEMCPY_ALIGNMENT_4 );

    // Most standard OffDstX value.
    OffDstX = dstAlignment >> 2;
    if( dstByteAlignment ) {
        OffDstX++;
    }

    maxBlocksX = ctx->device->state.limits.maxCtaGridWidth - 8;
    maxBlocksY = ctx->device->state.limits.maxCtaGridHeight - 8;

    // Mess to select the kernel and launch parameters, based on alignments,
    // sizes, and dimensions.

    // --- 1D Copies --- //
    if( (Depth == 1) && (Height == 1) ) { // 1D copy.
        if( (dstByteAlignment == 0) && (srcByteAlignment == 0 )
            && (widthByteAlignment == 0) ) { // Nice
            if( WidthInBytes >= INT_MAX ) {
                // Should test this further when larger FB available
                func = ctx->kernelmemcpy.tesla->memcpyDtoD_aligned64;
            } else {
                func = ctx->kernelmemcpy.tesla->memcpyDtoD_aligned;
            }
            useLauncher = USE_1D;
        }
        else if( ( WidthInBytes < SMALL_COPY_BOUNDARY ) ) { // If bad but small
            func = ctx->kernelmemcpy.tesla->memcpyDtoD2D_unalignedSmallHeight;
            OffDstX = dstAlignment;
            useLauncher = USE_2D;
        }
        else if( dstByteAlignment == srcByteAlignment ) { // Less nice align
            if( WidthInBytes >= INT_MAX ) {
                // Should test this further when larger FB available
                func = ctx->kernelmemcpy.tesla->memcpyDtoD_alignedSrcDst64;
            } else {
                func = ctx->kernelmemcpy.tesla->memcpyDtoD_alignedSrcDst;
            }
            OffDstX = (64-dstAlignment)&63;
            useLauncher = USE_1D;
        }
        else {
            // Cannot handle fully unaligned copies
            return CUDA_ERROR_INVALID_VALUE;
        }
    }


    // --- 2D Copies, and 3D copies done as slices with 2D copies --- //
    // Can't do 3D copies on copies with large height.
    else if( (Depth <= MAX_NUM_SLICES) || (Height >= maxBlocksY) ) {
        // All of these have 2D launches.
        useLauncher = USE_2D;

        if( (dstPitchAlignment != 0) || (srcPitchAlignment != 0) ) {
            if (Height < maxBlocksY) {
                // Only kernel strategy to handle misaligned pitches, slow
                func = SELECT_32_OR_64_BIT_KERNEL(
                            Height, PitchSrc, PitchDst,
                            ctx->kernelmemcpy.tesla->memcpyDtoD2D_unalignedSmallHeight,
                            ctx->kernelmemcpy.tesla->memcpyDtoD2D_unalignedSmallHeight64);
                OffDstX = dstAlignment;
            }
            else {
                // No kernel can handle this copy correctly (yet)
                return CUDA_ERROR_INVALID_VALUE;
            }
        }
        else {
            if( (dstByteAlignment == 0) && (srcByteAlignment == 0) &&
                (widthByteAlignment == 0) ) { // Nice
                if( (Height < maxBlocksY) && // Small enough to use a special kernel
                    (PitchDst < (1<<24)) && (PitchSrc < (1 << 24)) ) {
                    if( PitchSrc == PitchDst ) {
                        func = SELECT_32_OR_64_BIT_KERNEL(
                                    Height, PitchSrc, PitchDst,
                                    ctx->kernelmemcpy.tesla->memcpyDtoD2D_aligned_smallsamepitch,
                                    ctx->kernelmemcpy.tesla->memcpyDtoD2D_aligned_smallsamepitch64);
                    }
                    else {
                        func = SELECT_32_OR_64_BIT_KERNEL(
                                    Height, PitchSrc, PitchDst,
                                    ctx->kernelmemcpy.tesla->memcpyDtoD2D_aligned_smalldiffpitch,
                                    ctx->kernelmemcpy.tesla->memcpyDtoD2D_aligned_smalldiffpitch64);
                    }
                }
                else {
                    func = ctx->kernelmemcpy.tesla->memcpyDtoD2D_aligned;
                }
            }
            else if( (WidthInBytes < SMALL_COPY_WIDTH) &&
                     (Height < SMALL_COPY_HEIGHT) ) { // Bad, but small
                func = SELECT_32_OR_64_BIT_KERNEL(
                            Height, PitchSrc, PitchDst,
                            ctx->kernelmemcpy.tesla->memcpyDtoD2D_unalignedSmallHeight,
                            ctx->kernelmemcpy.tesla->memcpyDtoD2D_unalignedSmallHeight64);
                OffDstX = dstAlignment;
            }
            else if( dstByteAlignment == srcByteAlignment ) { // Less nice align
                func = ctx->kernelmemcpy.tesla->memcpyDtoD2D_alignedSrcDst;
            }
            else {
                // Cannot handle fully unaligned copies
                return CUDA_ERROR_INVALID_VALUE;
            }
        }
    }

    // --- 3D Copies --- //
    else { // Depth > MAX_NUM_SLICES; kernels done with 3D launches.

        // All of these have 3D launches.
        useLauncher = USE_3D;

        if( (dstByteAlignment == 0) && (srcByteAlignment == 0) &&
            (dstPitchAlignment == 0) && (srcPitchAlignment == 0) &&
            (widthByteAlignment == 0) ) { // Nice
            func = ctx->kernelmemcpy.tesla->memcpyDtoD3D_aligned;
        }
        else if( dstByteAlignment == srcByteAlignment &&
                 (dstPitchAlignment == 0) && (srcPitchAlignment == 0) ) { // Less nice.
            func = ctx->kernelmemcpy.tesla->memcpyDtoD3D_alignedSrcDst;
        }
        else {
            // Cannot handle fully unaligned copies
            return CUDA_ERROR_INVALID_VALUE;
        }
    }

    cuiToolsNotifyMemcpyKernelBegin(copyCbInfo, copyDesc);

    // Launch kernels, based on needed launch configuration, determined above.
    switch (useLauncher) {
        case USE_1D:
        {
            status = gt200Memcpy1D(ctx, func, stream, maxBlocksX, maxBlocksY,
                                   threadsX, threadsY, copyDesc, dst, src, WidthInBytes,
                                   OffDstX );
            break;
        }
        case USE_2D:
        {
            // For copying 3D as several 2D slices, loop through slices.
            size_t i;
            for (i = 0; i < Depth; ++i) {
                status = gt200Memcpy2D(ctx,func,stream, maxBlocksX, maxBlocksY,
                            threadsX, threadsY, copyDesc, dst+i*PitchDst*HeightDst,
                            src+i*PitchSrc*HeightSrc, WidthInBytes,
                            Height, PitchDst, PitchSrc, OffDstX );
                if (status != CUDA_SUCCESS) {
                    break;
                }
            }
            break;
        }
        case USE_3D: 
        {
            status = gt200Memcpy3D( ctx, func, stream, maxBlocksX, maxBlocksY,
                            threadsX, threadsY, copyDesc, dst, src, WidthInBytes,
                            Height, PitchDst, PitchSrc, HeightDst, HeightSrc,
                            Depth, OffDstX );
            break;
        }
        default: 
            CU_ASSERT(0);
            status = CUDA_ERROR_INVALID_VALUE;
    }

    cuiToolsNotifyMemcpyKernelEnd(copyCbInfo);

    return status;
}

// Array to device, device to array 1d, 2d memcopies.
CUresult
gt200KernelMemcpyAtoD(CUctx *ctx,
                      const CUImemcpyDesc *copyDesc,
                      CUIstream *stream, 
                      CUImemcpyCbInfo *copyCbInfo)
{
    CUresult status = CUDA_SUCCESS;

    unsigned int WidthInBytes;
    unsigned int Height;
    unsigned int Depth;
    unsigned char *dptr;
    size_t dptrPitch;
    size_t dptrHeight;
    unsigned int arrSrcXInBytes = 0;
    unsigned int arrSrcY = 0;
    unsigned int arrSrcZ = 0;

    unsigned int arrWordAlign;
    unsigned int dptrWordAlign;
    unsigned int widthWordAlign;
    unsigned int pitchWordAlign;

    unsigned int BytesPerElem;
    unsigned int CopyDir;

    unsigned int threadsX;
    unsigned int threadsY;
    unsigned int threadsZ;

    CUfunc *func = NULL;

    CUarray arr;
    CUarr* cuarr;
    CUsurfref surfref = 0;

    const CUImemcpyOperand *dptrOperand, *arrayOperand;

    CU_TRACE_FUNCTION();
    CU_ASSERT(ctx && copyDesc && stream && copyCbInfo);
    CU_ASSERT(ctx->kernelmemcpy.tesla);

    // get direction of the copy and figure out
    // array/dptr operands
    if (copyDesc->src.type == CUI_MEMCPY_DATA_TYPE_MEMOBJ &&
        copyDesc->dst.type == CUI_MEMCPY_DATA_TYPE_ARRAY) {
        CopyDir = DTOA;
        dptrOperand = &copyDesc->src;
        arrayOperand = &copyDesc->dst;
    }
    else {
        CopyDir = ATOD;
        dptrOperand = &copyDesc->dst;
        arrayOperand = &copyDesc->src;
    }

    // compute origin/pitch/height of dptr operand
    dptr = (unsigned char *)(uintptr_t) cuiMemcpyOperandGetOriginAddr(dptrOperand);
    dptrPitch  = (size_t) dptrOperand->memobj.pitch;
    dptrHeight = (size_t) dptrOperand->memobj.height;

    // get array operand x,y,z offsets
    arr            = arrayOperand->array.array;
    arrSrcXInBytes = (unsigned int) arrayOperand->origin.xInBytes;
    arrSrcY        = (unsigned int) arrayOperand->origin.y;
    arrSrcZ        = (unsigned int) arrayOperand->origin.z;

    // set up copy extent
    Height = (copyDesc->extent.height == 0) ? 1 : (unsigned int) copyDesc->extent.height;
    Depth  = (copyDesc->extent.depth  == 0) ? 1 : (unsigned int) copyDesc->extent.depth;
    WidthInBytes = (unsigned int) copyDesc->extent.widthInBytes;

    cuarr = (CUarr*)arr;

    // Compute alignments to determine which kernel we have to use.
    arrWordAlign = arrSrcXInBytes & 3;
    dptrWordAlign = (unsigned int)(((uintptr_t)dptr) & 3);
    widthWordAlign = WidthInBytes & 3;
    pitchWordAlign = (unsigned int)(dptrPitch & 3);

    // Cannot treat the array as a surface if it is too large
    switch ( arr->type ) {
        case CUI_ARRAY_TYPE_1D:
            if ((cuarr->desc.Width > ctx->device->state.limits.surface1dMaxWidth) &&
                (!cuiDeviceArchIsMaxwellPlus(ctx->device) ||
                 (cuarr->desc.Width > ctx->device->state.limits.surface2dMaxWidth))) {
                CU_DEBUG_PRINT(("Array too large to be treated as a surface.\n"));
                return CUDA_ERROR_INVALID_VALUE;
            }
            break;
        case CUI_ARRAY_TYPE_2D:
            if ((cuarr->desc.Width > ctx->device->state.limits.surface2dMaxWidth) ||
                (cuarr->desc.Height > ctx->device->state.limits.surface2dMaxHeight)) {
                CU_DEBUG_PRINT(("Array too large to be treated as a surface.\n"));
                return CUDA_ERROR_INVALID_VALUE;
            }
            break;
        case CUI_ARRAY_TYPE_3D:
            if (((cuarr->desc.Width > ctx->device->state.limits.surface3dMaxWidth) ||
                 (cuarr->desc.Height > ctx->device->state.limits.surface3dMaxHeight) ||
                 (cuarr->desc.Depth > ctx->device->state.limits.surface3dMaxDepth)) &&
                (!cuiDeviceArchIsMaxwellPlus(ctx->device) ||
                 (cuarr->desc.Width > ctx->device->state.limits.texture3dAlternateMaxWidth) ||
                 (cuarr->desc.Height > ctx->device->state.limits.texture3dAlternateMaxHeight) ||
                 (cuarr->desc.Depth > ctx->device->state.limits.texture3dAlternateMaxDepth))) {
                CU_DEBUG_PRINT(("Array too large to be treated as a surface.\n"));
                return CUDA_ERROR_INVALID_VALUE;
            }
            break;
        case CUI_ARRAY_TYPE_1D_LAYERED:
            if ((cuarr->desc.Width > ctx->device->state.limits.surface1dLayeredMaxWidth) ||
                (cuarr->desc.Depth > ctx->device->state.limits.surface1dLayeredMaxLayers)) {
                CU_DEBUG_PRINT(("Array too large to be treated as a surface.\n"));
                return CUDA_ERROR_INVALID_VALUE;
            }
            break;
        case CUI_ARRAY_TYPE_2D_LAYERED:
        case CUI_ARRAY_TYPE_CUBEMAP:
        case CUI_ARRAY_TYPE_CUBEMAP_LAYERED:
            if ((cuarr->desc.Width > ctx->device->state.limits.surface2dLayeredMaxWidth) ||
                (cuarr->desc.Height > ctx->device->state.limits.surface2dLayeredMaxHeight) ||
                (cuarr->desc.Depth > ctx->device->state.limits.surface2dLayeredMaxLayers)) {
                CU_DEBUG_PRINT(("Array too large to be treated as a surface.\n"));
                return CUDA_ERROR_INVALID_VALUE;
            }
            break;
        default:
            CU_ASSERT(0);
            break;
    }

    // Grab kernel based on alignments.
    // Byte aligned.
    if( (arrWordAlign&1) || (dptrWordAlign&1) || (widthWordAlign&1) || (pitchWordAlign&1) ) {

        if( CopyDir == ATOD ) {
            switch ( arr->type ) {
                case CUI_ARRAY_TYPE_1D:
                    // Treat a 1D copy as a 2D copy with height 1 on Maxwell+
                    if (!cuiDeviceArchIsMaxwellPlus(ctx->device)) {
                        func = ctx->kernelmemcpy.tesla->CharAligned_AtoD1D_surf;
                        break;
                    }
                    // fall through
                case CUI_ARRAY_TYPE_2D:
                    func = ctx->kernelmemcpy.tesla->CharAligned_AtoD2D_surf;
                    break;
                case CUI_ARRAY_TYPE_3D:
                    func = ctx->kernelmemcpy.tesla->CharAligned_AtoD3D_surf;
                    break;
                case CUI_ARRAY_TYPE_1D_LAYERED:
                    func = ctx->kernelmemcpy.tesla->CharAligned_AtoD1DLayered_surf;
                    break;
                case CUI_ARRAY_TYPE_2D_LAYERED:
                case CUI_ARRAY_TYPE_CUBEMAP:
                case CUI_ARRAY_TYPE_CUBEMAP_LAYERED:
                    func = ctx->kernelmemcpy.tesla->CharAligned_AtoD2DLayered_surf;
                    break;
                default:
                    CU_ASSERT(0);
                    break;
            }
        }
        else if( CopyDir == DTOA ) {
            switch ( arr->type ) {
                case CUI_ARRAY_TYPE_1D:
                    // Treat a 1D copy as a 2D copy with height 1 on Maxwell+
                    if (!cuiDeviceArchIsMaxwellPlus(ctx->device)) {
                        func = ctx->kernelmemcpy.tesla->CharAligned_DtoA1D_surf;
                        break;
                    }
                    // fall through
                case CUI_ARRAY_TYPE_2D:
                    func = ctx->kernelmemcpy.tesla->CharAligned_DtoA2D_surf;
                    break;
                case CUI_ARRAY_TYPE_3D:
                    func = ctx->kernelmemcpy.tesla->CharAligned_DtoA3D_surf;
                    break;
                case CUI_ARRAY_TYPE_1D_LAYERED:
                    func = ctx->kernelmemcpy.tesla->CharAligned_DtoA1DLayered_surf;
                    break;
                case CUI_ARRAY_TYPE_2D_LAYERED:
                case CUI_ARRAY_TYPE_CUBEMAP:
                case CUI_ARRAY_TYPE_CUBEMAP_LAYERED:
                    func = ctx->kernelmemcpy.tesla->CharAligned_DtoA2DLayered_surf;
                    break;
                default:
                    CU_ASSERT(0);
                    break;
            }
        }

        BytesPerElem = 1;
    }
    // short aligned.
    else if( (arrWordAlign == 2)||(dptrWordAlign == 2)||(widthWordAlign == 2)||(pitchWordAlign == 2) ){

        if( CopyDir == ATOD ) {
            switch ( arr->type ) {
                case CUI_ARRAY_TYPE_1D:
                    // Treat a 1D copy as a 2D copy with height 1 on Maxwell+
                    if (!cuiDeviceArchIsMaxwellPlus(ctx->device)) {
                        func = ctx->kernelmemcpy.tesla->ShortAligned_AtoD1D_surf;
                        break;
                    }
                    // fall through
                case CUI_ARRAY_TYPE_2D:
                    func = ctx->kernelmemcpy.tesla->ShortAligned_AtoD2D_surf;
                    break;
                case CUI_ARRAY_TYPE_3D:
                    func = ctx->kernelmemcpy.tesla->ShortAligned_AtoD3D_surf;
                    break;
                case CUI_ARRAY_TYPE_1D_LAYERED:
                    func = ctx->kernelmemcpy.tesla->ShortAligned_AtoD1DLayered_surf;
                    break;
                case CUI_ARRAY_TYPE_2D_LAYERED:
                case CUI_ARRAY_TYPE_CUBEMAP:
                case CUI_ARRAY_TYPE_CUBEMAP_LAYERED:
                    func = ctx->kernelmemcpy.tesla->ShortAligned_AtoD2DLayered_surf;
                    break;
                default:
                    CU_ASSERT(0);
                    break;
            }
        }
        else if( CopyDir == DTOA ) {
            switch ( arr->type ) {
                case CUI_ARRAY_TYPE_1D:
                    // Treat a 1D copy as a 2D copy with height 1 on Maxwell+
                    if (!cuiDeviceArchIsMaxwellPlus(ctx->device)) {
                        func = ctx->kernelmemcpy.tesla->ShortAligned_DtoA1D_surf;
                        break;
                    }
                    // fall through
                case CUI_ARRAY_TYPE_2D:
                    func = ctx->kernelmemcpy.tesla->ShortAligned_DtoA2D_surf;
                    break;
                case CUI_ARRAY_TYPE_3D:
                    func = ctx->kernelmemcpy.tesla->ShortAligned_DtoA3D_surf;
                    break;
                case CUI_ARRAY_TYPE_1D_LAYERED:
                    func = ctx->kernelmemcpy.tesla->ShortAligned_DtoA1DLayered_surf;
                    break;
                case CUI_ARRAY_TYPE_2D_LAYERED:
                case CUI_ARRAY_TYPE_CUBEMAP:
                case CUI_ARRAY_TYPE_CUBEMAP_LAYERED:
                    func = ctx->kernelmemcpy.tesla->ShortAligned_DtoA2DLayered_surf;
                    break;
                default:
                    CU_ASSERT(0);
                    break;
            }
        }

        BytesPerElem = 2;
    }
    else { // int aligned.

        /* BUG 709014 removed tex read version of this copy. */

        if( CopyDir == ATOD ) {
            switch ( arr->type ) {
                case CUI_ARRAY_TYPE_1D:
                    // Treat a 1D copy as a 2D copy with height 1 on Maxwell+
                    if (!cuiDeviceArchIsMaxwellPlus(ctx->device)) {
                        func = ctx->kernelmemcpy.tesla->IntAligned_AtoD1D_surf;
                        break;
                    }
                    // fall through
                case CUI_ARRAY_TYPE_2D:
                    func = ctx->kernelmemcpy.tesla->IntAligned_AtoD2D_surf;
                    break;
                case CUI_ARRAY_TYPE_3D:
                    func = ctx->kernelmemcpy.tesla->IntAligned_AtoD3D_surf;
                    break;
                case CUI_ARRAY_TYPE_1D_LAYERED:
                    func = ctx->kernelmemcpy.tesla->IntAligned_AtoD1DLayered_surf;
                    break;
                case CUI_ARRAY_TYPE_2D_LAYERED:
                case CUI_ARRAY_TYPE_CUBEMAP:
                case CUI_ARRAY_TYPE_CUBEMAP_LAYERED:
                    func = ctx->kernelmemcpy.tesla->IntAligned_AtoD2DLayered_surf;
                    break;
                default:
                    CU_ASSERT(0);
                    break;
            }
        }
        else { // CopyDir == DTOA
            switch ( arr->type ) {
                case CUI_ARRAY_TYPE_1D:
                    // Treat a 1D copy as a 2D copy with height 1 on Maxwell+
                    if (!cuiDeviceArchIsMaxwellPlus(ctx->device)) {
                        func = ctx->kernelmemcpy.tesla->IntAligned_DtoA1D_surf;
                        break;
                    }
                    // fall through
                case CUI_ARRAY_TYPE_2D:
                    func = ctx->kernelmemcpy.tesla->IntAligned_DtoA2D_surf;
                    break;
                case CUI_ARRAY_TYPE_3D:
                    func = ctx->kernelmemcpy.tesla->IntAligned_DtoA3D_surf;
                    break;
                case CUI_ARRAY_TYPE_1D_LAYERED:
                    func = ctx->kernelmemcpy.tesla->IntAligned_DtoA1DLayered_surf;
                    break;
                case CUI_ARRAY_TYPE_2D_LAYERED:
                case CUI_ARRAY_TYPE_CUBEMAP:
                case CUI_ARRAY_TYPE_CUBEMAP_LAYERED:
                    func = ctx->kernelmemcpy.tesla->IntAligned_DtoA2DLayered_surf;
                    break;
                default:
                    CU_ASSERT(0);
                    break;
            }
        }

        BytesPerElem = 4;
    }

    // Surface setup.
    if( CopyDir == ATOD ) {
        switch ( arr->type ) {
            case CUI_ARRAY_TYPE_1D:
                // Treat a 1D copy as a 2D copy with height 1 on Maxwell+
                if (!cuiDeviceArchIsMaxwellPlus(ctx->device)) {
                    surfref = ctx->kernelmemcpy.tesla->isurfref1D;
                    break;
                }
                // fall through
            case CUI_ARRAY_TYPE_2D:
                surfref = ctx->kernelmemcpy.tesla->isurfref2D;
                break;
            case CUI_ARRAY_TYPE_3D:
                surfref = ctx->kernelmemcpy.tesla->isurfref3D;
                break;
            case CUI_ARRAY_TYPE_1D_LAYERED:
                surfref = ctx->kernelmemcpy.tesla->isurfref1DLayered;
                break;
            case CUI_ARRAY_TYPE_2D_LAYERED:
            case CUI_ARRAY_TYPE_CUBEMAP:
            case CUI_ARRAY_TYPE_CUBEMAP_LAYERED:
                surfref = ctx->kernelmemcpy.tesla->isurfref2DLayered;
                break;
            default:
                CU_ASSERT(0);
                break;
        }
    }
    else if( CopyDir == DTOA ) {
        switch ( arr->type ) {
            case CUI_ARRAY_TYPE_1D:
                // Treat a 1D copy as a 2D copy with height 1 on Maxwell+
                if (!cuiDeviceArchIsMaxwellPlus(ctx->device)) {
                    surfref = ctx->kernelmemcpy.tesla->osurfref1D;
                    break;
                }
                // fall through
            case CUI_ARRAY_TYPE_2D:
                surfref = ctx->kernelmemcpy.tesla->osurfref2D;
                break;
            case CUI_ARRAY_TYPE_3D:
                surfref = ctx->kernelmemcpy.tesla->osurfref3D;
                break;
            case CUI_ARRAY_TYPE_1D_LAYERED:
                surfref = ctx->kernelmemcpy.tesla->osurfref1DLayered;
                break;
            case CUI_ARRAY_TYPE_2D_LAYERED:
            case CUI_ARRAY_TYPE_CUBEMAP:
            case CUI_ARRAY_TYPE_CUBEMAP_LAYERED:
                surfref = ctx->kernelmemcpy.tesla->osurfref2DLayered;
                break;
            default:
                CU_ASSERT(0);
                break;
        }
    }
    cuiSurfRefSetArray(surfref, arr, 0);

    // Default to block dims of 8 in each dimension, unless the copy extent for a
    // given dimension is less than 8
    threadsX = (WidthInBytes/BytesPerElem < 8) ? WidthInBytes/BytesPerElem : 8;
    threadsY = (Height < 8) ? Height : 8;
    threadsZ = (Depth < 8) ? Depth : 8;

    if (cuiApiIs_OCL(func->mod->api)) {
        cuiFuncTrackMemobj(func, dptrOperand->memobj.memobj, NV_FALSE);
    }

    cuiToolsNotifyMemcpyKernelBegin(copyCbInfo, copyDesc);

    status = gt200ArrayDeviceMemcpy(ctx, func, stream,
                                    threadsX, threadsY, threadsZ,
                                    dptr, WidthInBytes, Height, Depth, dptrPitch,
                                    dptrHeight, arrSrcXInBytes, arrSrcY, arrSrcZ,
                                    BytesPerElem, arr->type);

    cuiToolsNotifyMemcpyKernelEnd(copyCbInfo);

    return status;
}



// Array to array 1d, 2d memcopies.
CUresult
gt200KernelMemcpyAtoA(CUctx *ctx,
                      const CUImemcpyDesc *copyDesc,
                      CUIstream *stream, 
                      CUImemcpyCbInfo *copyCbInfo)
{
    CUresult status = CUDA_SUCCESS;

    unsigned int WidthInBytes;
    unsigned int Height;
    unsigned int Depth;
    unsigned int sliceCounter;  // Counter for 2d slice of 3d array.

    unsigned int arrSrcXInBytes;
    unsigned int arrSrcY;
    unsigned int arrSrcZ;
    unsigned int arrDstXInBytes;
    unsigned int arrDstY;
    unsigned int arrDstZ;

    unsigned int srcWordAlign;
    unsigned int dstWordAlign;
    unsigned int widthWordAlign;

    unsigned int BytesPerElem;

    unsigned int threadsX = 8;
    unsigned int threadsY = 8;

    CUfunc *func = NULL;

    unsigned int maxBlocksX;
    unsigned int maxBlocksY;
    NvU64 srcOrigOffset; // Original intrablockoffset for src array.
    NvU64 dstOrigOffset; // Original intrablockoffset for dst array.

    CUarray arrSrc;
    CUarray arrDst;
    CUarr* cuarrSrc;
    CUarr* cuarrDst;

    CU_TRACE_FUNCTION();
    CU_ASSERT(ctx && copyDesc && stream && copyCbInfo);
    CU_ASSERT( copyDesc->src.type == CUI_MEMCPY_DATA_TYPE_ARRAY );
    CU_ASSERT( copyDesc->dst.type == CUI_MEMCPY_DATA_TYPE_ARRAY );

    // src array offsets
    arrSrc         = copyDesc->src.array.array;
    arrSrcXInBytes = (unsigned int) copyDesc->src.origin.xInBytes;
    arrSrcY        = (unsigned int) copyDesc->src.origin.y;
    arrSrcZ        = (unsigned int) copyDesc->src.origin.z;
    cuarrSrc       = (CUarr*)arrSrc;

    // dst array offsets
    arrDst         = copyDesc->dst.array.array;
    arrDstXInBytes = (unsigned int) copyDesc->dst.origin.xInBytes;
    arrDstY        = (unsigned int) copyDesc->dst.origin.y;
    arrDstZ        = (unsigned int) copyDesc->dst.origin.z;
    cuarrDst       = (CUarr*)arrDst;

    if( (arrSrc->Dimension == 1) ||
        (arrDst->Dimension == 1) ){
        // BUG: 820791, 1D memcpy with arrays isn't implemented.
        // Will hit fallback path and be handled by CE.
        return CUDA_ERROR_INVALID_VALUE;
    }

    if (cuiArrayIsLayeredMipmap(cuarrSrc) || cuiArrayIsLayeredMipmap(cuarrDst)) {
        // Don't use kernel memcpy when working with layered mipmaps.
        // RFE filed : bug 1425165 to extend AtoA kernels when working with layered mipmaps.
        return CUDA_ERROR_INVALID_VALUE;
    }

    // Return if it's not set up as an array of 2d slices.
    if(    (cuarrSrc->blInfo.log2GobsPerBlock.z > 0)
        || (cuarrDst->blInfo.log2GobsPerBlock.z > 0)
        || ( ctx->device->state.limits.gobDepth > 1) ) {
        return CUDA_ERROR_INVALID_VALUE;
    }
    // Cannot treat the array as a surface if it is out of bounds
    if (cuarrSrc->desc.Width > ctx->device->state.limits.surface2dMaxWidth ||
        cuarrDst->desc.Width > ctx->device->state.limits.surface2dMaxWidth ||
        cuarrSrc->desc.Height > ctx->device->state.limits.surface2dMaxHeight ||
        cuarrDst->desc.Height > ctx->device->state.limits.surface2dMaxHeight) {
        return CUDA_ERROR_INVALID_VALUE;
    }

    // set up copy extent
    Height = (copyDesc->extent.height == 0) ? 1 : (unsigned int) copyDesc->extent.height;
    Depth  = (copyDesc->extent.depth  == 0) ? 1 : (unsigned int) copyDesc->extent.depth;
    WidthInBytes = (unsigned int) copyDesc->extent.widthInBytes;

    // Compute alignments to determine which kernel we have to use.
    srcWordAlign = arrSrcXInBytes&3;
    dstWordAlign = arrDstXInBytes&3;
    widthWordAlign = WidthInBytes&3;

    // Grab kernel based on alignments.
    if( (srcWordAlign&1) || (dstWordAlign&1) || (widthWordAlign&1) ) {

        func = ctx->kernelmemcpy.tesla->CharAligned_AtoA_surf;
        threadsX *= 4;
        BytesPerElem = 1;
    }
    else if( (srcWordAlign == 2)||(dstWordAlign == 2)||(widthWordAlign == 2) ){

        func = ctx->kernelmemcpy.tesla->ShortAligned_AtoA_surf;
        threadsX *= 2;
        BytesPerElem = 2;
    }
    else { // int aligned.
        func = ctx->kernelmemcpy.tesla->IntAligned_AtoA_surf;
        BytesPerElem = 4;
    }
    
    // Bind surfrefs
    cuiSurfRefSetArray( ctx->kernelmemcpy.tesla->isurfref2D, arrSrc, 0);
    cuiSurfRefSetArray( ctx->kernelmemcpy.tesla->osurfref2D, arrDst, 0);

    maxBlocksX = ctx->device->state.limits.maxCtaGridWidth - 8;
    maxBlocksY = ctx->device->state.limits.maxCtaGridHeight - 8;

    // Save original offset into block.
    srcOrigOffset = cuarrSrc->memobjOffset;
    dstOrigOffset = cuarrDst->memobjOffset;

    // Loop over 2d slices, because 3d surfaces aren't supported yet.
    cuiToolsNotifyMemcpyKernelBegin(copyCbInfo, copyDesc);
    for( sliceCounter = 0; sliceCounter < Depth; ++sliceCounter ) {

        // Stride calculation to stride along 2d slices of a 3d array.
        unsigned int srcstride = 
                            ( cuarrSrc->blInfo.xBlocks * 
                            ( 1 << cuarrSrc->blInfo.log2GobsPerBlock.x ) *
                            ( ctx->device->state.limits.gobWidthBytes) *
                            cuarrSrc->blInfo.yBlocks *
                            ( 1 << cuarrSrc->blInfo.log2GobsPerBlock.y ) *
                            ( ctx->device->state.limits.gobHeight ) );

        unsigned int dststride = 
                            ( cuarrDst->blInfo.xBlocks * 
                            ( 1 << cuarrDst->blInfo.log2GobsPerBlock.x ) *
                            ( ctx->device->state.limits.gobWidthBytes) *
                            cuarrDst->blInfo.yBlocks *
                            ( 1 << cuarrDst->blInfo.log2GobsPerBlock.y ) *
                            ( ctx->device->state.limits.gobHeight ) );

        // Update offsets within 3d array.
        cuarrSrc->memobjOffset = srcstride * ( sliceCounter + arrSrcZ ) + srcOrigOffset;
        cuarrDst->memobjOffset = dststride * ( sliceCounter + arrDstZ ) + dstOrigOffset;

        // __TEMP_WAR__
        // See bug 776846.  We shouldn't modify the array internal memobj once it created.
        // This code path only applies to Kepler+, which supports 3D surface read/write.
        // So we should be able to switch to 3D access instead of slicing it into 2D arrays.
        // Mark surfref as dirty since we have changed the array it binds to.
        ctx->kernelmemcpy.tesla->isurfref2D->dirty = 1;
        ctx->kernelmemcpy.tesla->osurfref2D->dirty = 1;

        // Copy 2d slice.
        status = gt200ArrayArrayMemcpy(ctx, func, stream, 
                                       maxBlocksX, maxBlocksY, threadsX, threadsY,
                                       WidthInBytes, Height,
                                       arrSrcXInBytes, arrSrcY,
                                       arrDstXInBytes, arrDstY, BytesPerElem);
        if (status != CUDA_SUCCESS) {
            break;
        }
    }
    cuiToolsNotifyMemcpyKernelEnd(copyCbInfo);

    // Restore original offsets.
    cuarrSrc->memobjOffset = srcOrigOffset;
    cuarrDst->memobjOffset = dstOrigOffset;
    ctx->kernelmemcpy.tesla->isurfref2D->dirty = 1;
    ctx->kernelmemcpy.tesla->osurfref2D->dirty = 1;

    return status;
}

CUresult gt200KernelMemcpyInit(CUctx *ctx)
{
    CUresult status;
    CUkernelMemcpyGT200 *kernelHandles;
    CUjitCompileData compileData;
    const unsigned long long *cubin;

    CU_TRACE_FUNCTION();
    CU_ASSERT(ctx);

    // If already initialized, bail out
    if (ctx->kernelmemcpy.tesla) {
        return CUDA_SUCCESS;
    }    

    // Allocate memory to store kernel handles
    kernelHandles = (CUkernelMemcpyGT200*)malloc(sizeof(CUkernelMemcpyGT200));
    if (!kernelHandles) {
        status = CUDA_ERROR_OUT_OF_MEMORY;
        goto Error;
    }
    memset(kernelHandles, 0, sizeof(CUkernelMemcpyGT200));
    ctx->kernelmemcpy.tesla = kernelHandles;

    // Load built-in module
    cuiSetDefaultCompilerOptions(&compileData);
    cubin = cuiGetBIKCubin(
        allCubins_gt200_kernel_memcpy,
        ctx->device->state.major,
        ctx->device->state.minor);
    CU_ASSERT(cubin);

    status = cuiModuleLoadData(
        ctx, 
        &kernelHandles->mod,
        cubin,
        NULL, 
        &compileData,
        ctx->api);
    if (CUDA_SUCCESS != status) {
        CU_DEBUG_PRINT(("Failed to load memcpy cubin.\n"));
        goto Error;
    }

    // Device-Device
    LOAD_FUNCTION(status, kernelHandles, memcpyDtoD3D_aligned);
    LOAD_FUNCTION(status, kernelHandles, memcpyDtoD3D_alignedSrcDst);
    LOAD_FUNCTION(status, kernelHandles, memcpyDtoD2D_aligned);
    LOAD_FUNCTION(status, kernelHandles, memcpyDtoD2D_aligned_smallsamepitch);
    LOAD_FUNCTION(status, kernelHandles, memcpyDtoD2D_aligned_smallsamepitch64);
    LOAD_FUNCTION(status, kernelHandles, memcpyDtoD2D_aligned_smalldiffpitch);
    LOAD_FUNCTION(status, kernelHandles, memcpyDtoD2D_aligned_smalldiffpitch64);
    LOAD_FUNCTION(status, kernelHandles, memcpyDtoD2D_unalignedSmallHeight);
    LOAD_FUNCTION(status, kernelHandles, memcpyDtoD2D_unalignedSmallHeight64);
    LOAD_FUNCTION(status, kernelHandles, memcpyDtoD2D_alignedSrcDst);
    LOAD_FUNCTION(status, kernelHandles, memcpyDtoD_aligned);
    LOAD_FUNCTION(status, kernelHandles, memcpyDtoD_aligned64);
    LOAD_FUNCTION(status, kernelHandles, memcpyDtoD_alignedSrcDst);
    LOAD_FUNCTION(status, kernelHandles, memcpyDtoD_alignedSrcDst64);

    // Array-Device
    LOAD_FUNCTION(status, kernelHandles, IntAligned_AtoD1D_surf);
    LOAD_FUNCTION(status, kernelHandles, IntAligned_AtoD2D_surf);
    LOAD_FUNCTION(status, kernelHandles, IntAligned_AtoD3D_surf);
    LOAD_FUNCTION(status, kernelHandles, IntAligned_AtoD1DLayered_surf);
    LOAD_FUNCTION(status, kernelHandles, IntAligned_AtoD2DLayered_surf);
    LOAD_FUNCTION(status, kernelHandles, IntAligned_DtoA1D_surf);
    LOAD_FUNCTION(status, kernelHandles, IntAligned_DtoA2D_surf);
    LOAD_FUNCTION(status, kernelHandles, IntAligned_DtoA3D_surf);
    LOAD_FUNCTION(status, kernelHandles, IntAligned_DtoA1DLayered_surf);
    LOAD_FUNCTION(status, kernelHandles, IntAligned_DtoA2DLayered_surf);
    LOAD_FUNCTION(status, kernelHandles, ShortAligned_AtoD1D_surf);
    LOAD_FUNCTION(status, kernelHandles, ShortAligned_AtoD2D_surf);
    LOAD_FUNCTION(status, kernelHandles, ShortAligned_AtoD3D_surf);
    LOAD_FUNCTION(status, kernelHandles, ShortAligned_AtoD1DLayered_surf);
    LOAD_FUNCTION(status, kernelHandles, ShortAligned_AtoD2DLayered_surf);
    LOAD_FUNCTION(status, kernelHandles, ShortAligned_DtoA1D_surf);
    LOAD_FUNCTION(status, kernelHandles, ShortAligned_DtoA2D_surf);
    LOAD_FUNCTION(status, kernelHandles, ShortAligned_DtoA3D_surf);
    LOAD_FUNCTION(status, kernelHandles, ShortAligned_DtoA1DLayered_surf);
    LOAD_FUNCTION(status, kernelHandles, ShortAligned_DtoA2DLayered_surf);
    LOAD_FUNCTION(status, kernelHandles, CharAligned_AtoD1D_surf);
    LOAD_FUNCTION(status, kernelHandles, CharAligned_AtoD2D_surf);
    LOAD_FUNCTION(status, kernelHandles, CharAligned_AtoD3D_surf);
    LOAD_FUNCTION(status, kernelHandles, CharAligned_AtoD1DLayered_surf);
    LOAD_FUNCTION(status, kernelHandles, CharAligned_AtoD2DLayered_surf);
    LOAD_FUNCTION(status, kernelHandles, CharAligned_DtoA1D_surf);
    LOAD_FUNCTION(status, kernelHandles, CharAligned_DtoA2D_surf);
    LOAD_FUNCTION(status, kernelHandles, CharAligned_DtoA3D_surf);
    LOAD_FUNCTION(status, kernelHandles, CharAligned_DtoA1DLayered_surf);
    LOAD_FUNCTION(status, kernelHandles, CharAligned_DtoA2DLayered_surf);

    // Array-Array
    LOAD_FUNCTION(status, kernelHandles, IntAligned_AtoA_surf);
    LOAD_FUNCTION(status, kernelHandles, ShortAligned_AtoA_surf);
    LOAD_FUNCTION(status, kernelHandles, CharAligned_AtoA_surf);
    
    // Get surface references
    status = cuiModuleGetSurfRefByName(kernelHandles->mod, "isurfref1D", &kernelHandles->isurfref1D);
    if (CUDA_SUCCESS != status) {
        CU_DEBUG_PRINT(("Failed to load isurfref1D.\n"));
        goto Error;
    }

    status = cuiModuleGetSurfRefByName(kernelHandles->mod, "osurfref1D", &kernelHandles->osurfref1D);
    if (CUDA_SUCCESS != status) {
        CU_DEBUG_PRINT(("Failed to load osurfref1D.\n"));
        goto Error;
    }

    status = cuiModuleGetSurfRefByName(kernelHandles->mod, "isurfref2D", &kernelHandles->isurfref2D);
    if (CUDA_SUCCESS != status) {
        CU_DEBUG_PRINT(("Failed to load isurfref2D.\n"));
        goto Error;
    }

    status = cuiModuleGetSurfRefByName(kernelHandles->mod, "osurfref2D", &kernelHandles->osurfref2D);
    if (CUDA_SUCCESS != status) {
        CU_DEBUG_PRINT(("Failed to load osurfref2D.\n"));
        goto Error;
    }

    status = cuiModuleGetSurfRefByName(kernelHandles->mod, "isurfref3D", &kernelHandles->isurfref3D);
    if (CUDA_SUCCESS != status) {
        CU_DEBUG_PRINT(("Failed to load isurfref3D.\n"));
        goto Error;
    }

    status = cuiModuleGetSurfRefByName(kernelHandles->mod, "osurfref3D", &kernelHandles->osurfref3D);
    if (CUDA_SUCCESS != status) {
        CU_DEBUG_PRINT(("Failed to load osurfref3D.\n"));
        goto Error;
    }

    status = cuiModuleGetSurfRefByName(kernelHandles->mod, "isurfref1DLayered", &kernelHandles->isurfref1DLayered);
    if (CUDA_SUCCESS != status) {
        CU_DEBUG_PRINT(("Failed to load isurfref1DLayered.\n"));
        goto Error;
    }

    status = cuiModuleGetSurfRefByName(kernelHandles->mod, "osurfref1DLayered", &kernelHandles->osurfref1DLayered);
    if (CUDA_SUCCESS != status) {
        CU_DEBUG_PRINT(("Failed to load osurfref1DLayered.\n"));
        goto Error;
    }

    status = cuiModuleGetSurfRefByName(kernelHandles->mod, "isurfref2DLayered", &kernelHandles->isurfref2DLayered);
    if (CUDA_SUCCESS != status) {
        CU_DEBUG_PRINT(("Failed to load isurfref2DLayered.\n"));
        goto Error;
    }

    status = cuiModuleGetSurfRefByName(kernelHandles->mod, "osurfref2DLayered", &kernelHandles->osurfref2DLayered);
    if (CUDA_SUCCESS != status) {
        CU_DEBUG_PRINT(("Failed to load osurfref2DLayered.\n"));
        goto Error;
    }

    // The 2D surfaces need to be able to treat 1D arrays as 2D arrays on Maxwell+, so
    // that we can do larger kernel memcopies for 1D surfaces, since the
    // 1D surface limits are so low
    if (cuiDeviceArchIsMaxwellPlus(ctx->device)) {
        kernelHandles->isurfref2D->treat1dArraysAs2d = NV_TRUE;
        kernelHandles->osurfref2D->treat1dArraysAs2d = NV_TRUE;
    }

    return status;

Error:
    gt200KernelMemcpyDestroy(ctx);
    return status;
}

void gt200KernelMemcpyDestroy(CUctx *ctx)
{
    CUkernelMemcpyGT200 *kernelHandles;

    CU_TRACE_FUNCTION();
    CU_ASSERT(ctx);

    kernelHandles = ctx->kernelmemcpy.tesla;
    if (kernelHandles) {
        if (kernelHandles->mod) {
            cuiModuleUnload(kernelHandles->mod);
            kernelHandles->mod = NULL;
        }
        free(kernelHandles); 
        ctx->kernelmemcpy.tesla = NULL;
    }
}
