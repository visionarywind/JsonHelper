//Memcheck kernels
//In an upcoming change this will include the combined memcheck kernels
// The builtin kernels must be compiled with :
// ./buildkernel.pl memcheck_kernels.cu -n memcheck -abiminregs -sepcomp -nocbank  -cross -nop4 -verbose -nourf
// This will force the device code to be built for separate compilation, and
// ensures that the generated SASS uses only 16 registers

#include "../devtools/memcheck/device_code/check_device_code.cu"
