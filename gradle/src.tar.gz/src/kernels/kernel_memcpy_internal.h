/*
 * Copyright 2005-2011 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

#ifndef __memcpy_kernel_internal_h__
#define __memcpy_kernel_internal_h__
#include "cuos_debug.h"
#include "cuda_internal.h"

NV_INLINE static void 
kernelMemcpyTrackMemobj(
    CUctx *ctx, 
    CUfunc *func, 
    const CUImemcpyDesc *copyDesc)
{
    CU_TRACE_FUNCTION();
    CU_ASSERT(ctx && func && copyDesc);
    if (cuiCtxApiIs_OCL(func->mod->ctx)) {
        cuiFuncTrackMemobj(func, copyDesc->dst.memobj.memobj, NV_FALSE);
        cuiFuncTrackMemobj(func, copyDesc->src.memobj.memobj, NV_TRUE);
    }
}

#define MEMCPY_ALIGNMENT_64 0x3f
#define MEMCPY_ALIGNMENT_4  0x3

#endif


