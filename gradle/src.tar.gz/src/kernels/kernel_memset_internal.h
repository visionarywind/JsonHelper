/*
 * Copyright 2005-2012 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

#ifndef __memset_kernel_internal_h__
#define __memset_kernel_internal_h__
#include "cuos_debug.h"
#include "cuda_internal.h"

NV_INLINE static void 
kernelMemsetTrackMemobj(
    CUfunc *func,
    CUmemobj *memobj)
{
    CU_TRACE_FUNCTION();
    CU_ASSERT(func && memobj);
    if (cuiCtxApiIs_OCL(func->mod->ctx)) {
        cuiFuncTrackMemobj(func, memobj, NV_FALSE);
    }
}

#endif
