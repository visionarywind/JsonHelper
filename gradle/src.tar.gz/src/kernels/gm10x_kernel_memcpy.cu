/*
 * Copyright (c) 2011 NVIDIA Corporation.  All rights reserved.
 *
 * NVIDIA Corporation and its licensors retain all intellectual property and proprietary
 * rights in and to this software, related documentation and any modifications thereto.
 * Any use, reproduction, disclosure or distribution of this software and related
 * documentation without an express license agreement from NVIDIA Corporation is strictly
 * prohibited.
 *
 * TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THIS SOFTWARE IS PROVIDED *AS IS*
 * AND NVIDIA AND ITS SUPPLIERS DISCLAIM ALL WARRANTIES, EITHER EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE.  IN NO EVENT SHALL NVIDIA OR ITS SUPPLIERS BE LIABLE FOR ANY
 * SPECIAL, INCIDENTAL, INDIRECT, OR CONSEQUENTIAL DAMAGES WHATSOEVER (INCLUDING, WITHOUT
 * LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF
 * BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS) ARISING OUT OF THE USE OF OR
 * INABILITY TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGES
 */

// ===============================================================================================
// File:    gm10x_kernel_memcpy.cu
//
// Desc:    This file holds custom memcpy kernels for Maxwell and later chips.
//
//          These kernels are designed to be faster than the standard GT200 memcpy kernels
//          for specific cases.   Primarily, these kernels are focused on handling
//          "misaligned" memcpy cases, i.e. memcpys where some aspect of the copy
//          (address, pitch, width, origin) is not aligned on a 4-byte boundary.
//
//          We focus on these cases b/c for other (aligned) cases, the GT200 kernels
//          do an adequate job, but for the misaligned cases, the GT200 kernels
//          either resort to copying a byte at a time, which is really slow,
//          or launching multiple kernels on the same buffer, which is also
//          slow.
//
//          MISALIGNED COPY KERNELS
//
//          All the various memcpy*Misaligned() kernels use the same algorithm:
//
//          Each row is divided into 3 sections:  fore, mid, aft.
//
//              The 'mid' section starts on a 16-byte boundary, and
//              ends on a 4-byte boundary, and is as long as possible.
//
//              The 'fore' and 'aft' sections are whatever is leftover
//              before and after the 'mid' section.
//
//          The 'mid' section is copied using unsigned ints, and the fore and aft
//          sections are copied reading/writing individual bytes.
//
//          The copying is performed out of order, with the 16-byte-aligned mid
//          section being copied first, and the non-aligned 'fore' and 'aft' sections
//          copied afterword.  (This order profiled noticeably faster than doing it in
//          the more intuitive order of fore, mid, aft.)
//
//          Example: in the following diagram, the 'row' to be copied doesn't start on
//          a 16-byte boundary, but instead is 2-bytes off that.
//
//      byte alignment: |               |               |               |               |
//                      0123456789ABCDEF0123456789ABCDEF0123456789ABCDEF0123456789ABCDEF0123456789ABCDEF
//      buffer            ************************************************************************
//                        |             |                                                      | |
//      speed             |             |<--------------- fast-------------------------------->| |
//                        |<--slow----->|                                                      |-| slow
//      zone                    fore                            middle                          aft
//
//
// Notes:   Profiling did not show any advantage to writing "int2" or "int4" rather than "int".
// ===============================================================================================
#include <stdio.h>

#include "gf100_kernel_consts.h"
#include "gm10x_kernel_memcpy.h"

typedef unsigned char       uchar;
typedef unsigned int        uint32;
typedef unsigned long long  uint64;

//#define VERBOSE 1

#define MID_SECTION_ALIGNMENT_MODULUS       GM10X_MISALIGNED_MEMCPY_MID_SECTION_ALIGNMENT_MODULUS
#define AFT_SECTION_ALIGNMENT_MODULUS       GM10X_MISALIGNED_MEMCPY_AFT_SECTION_ALIGNMENT_MODULUS

#define MID_SECTION_ALIGNMENT_MASK          (MID_SECTION_ALIGNMENT_MODULUS-1)
#define AFT_SECTION_ALIGNMENT_MASK          (AFT_SECTION_ALIGNMENT_MODULUS-1)


// Macro:   PTR_TO_UINT32( somePointer )
//
// Desc:    Downcast address 'somePointer' to an unsigned int.
//          This macro avoids the nvcc compiler warning you get if you do:
//
//              (uint) somePtr;
//
#define PTR_TO_UINT32( ptr_ ) ((uint32)((size_t)ptr_))



// Macro:   CALC_FORESIZE( dstRowAlignment )
//
// Desc:    Returns the # bytes in the 'fore' section of the given row.
//          The 'fore' section is the # of bytes from the start of the row to the mid.
//
// Arg:     dstRowAlignment     This is the aligment of the given row.
//                              For a destination MemObj (dev-ptr), this is simply the
//                              address of the row.
//
//                              For an destination Array, this is the 'dstOriginX'
//                              offset into the surface.
//
#define CALC_FORESIZE( dstRowAlignment ) \
    ((MID_SECTION_ALIGNMENT_MODULUS - (dstRowAlignment)) & MID_SECTION_ALIGNMENT_MASK)

//old:     (MID_SECTION_ALIGNMENT_MODULUS - (dstRowAlignment & MID_SECTION_ALIGNMENT_MASK)) & MID_SECTION_ALIGNMENT_MASK

#define DECLARE_FORE_MID_AFT_VARS \
    uint32 foreSize, midSize, aftSize, midCount

#define DECLARE_BYTESHIFT_AND_BITSHIFT_VARS \
    uint32 byteShift, bitShiftLower, bitShiftUpper;

// Macro:   MISALIGNED_MEMCPY_COMMON_DECLS
//
// Desc:    Declares the common variables used by all "memcpy*Misaligned" kernels.
//
//          foreSize        # of bytes in 'fore' section of the current row
//          midSize         # of bytes in 'mid' section of the current row
//          aftSize         # of bytes in 'aft' section of the current row
//          midCount        # of uints in the 'mid' section of the current row.
//          byteShift       how many bytes is the src-row misaligned vs the dst row
//          bitShiftUpper   how many bits of a src mid value straddle the upper word
//          bitShiftLower   how many bits of a src mid value straddle the lower word
//
// See:     MISALIGNED_MEMCPY_COMMON_SETUP
//
#define MISALIGNED_MEMCPY_COMMON_DECLS \
    DECLARE_FORE_MID_AFT_VARS; \
    DECLARE_BYTESHIFT_AND_BITSHIFT_VARS

// Macro:   INIT_FORE_MID_AFT_SIZES( dstRowAligment, copyWidth )
//
// Args:    dstRowAlignment     How the destination row is byte-aligned.
//          copyWidth           # of bytes to copy per-row
//
// Desc:    Intializes the values for the following variables:
//
//          foreSize        # of bytes in 'fore' section of the current row
//          midSize         # of bytes in 'mid' section of the current row
//          aftSize         # of bytes in 'aft' section of the current row
//          midCount        # of uints in the 'mid' section of the current row.
//
#define INIT_FORE_MID_AFT_SIZES( _dstRowAlignment, _copyWidth ) \
    foreSize = CALC_FORESIZE(_dstRowAlignment); \
    if (foreSize >= _copyWidth) { \
        foreSize = _copyWidth; \
        midCount = 0; \
        midSize  = 0; \
        aftSize  = 0; \
    } \
    else { \
        aftSize  = ((_dstRowAlignment + _copyWidth) & AFT_SECTION_ALIGNMENT_MASK); \
        midSize  = _copyWidth - (foreSize+aftSize); \
        if (midSize > 0) { \
            aftSize += sizeof(uint32); \
            midSize -= sizeof(uint32); \
        }  \
        midCount = midSize / sizeof(uint32); \
    }

// Macro:   INIT_BYTESHIFT_AND_BITSHIFTS( srcRowAlignment )
//
// Args:    srcRowAlignment     How the source row is byte-aligned
//
// Desc:    Initializes the values for the following variables:
//
//          byteShift       how many bytes is the src-row misaligned vs the dst row
//          bitShiftUpper   how many bits of a src mid value straddle the upper word
//          bitShiftLower   how many bits of a src mid value straddle the lower word
//
// Requires:   Variable 'foreSize' must be defined and initialized.
//
#define INIT_BYTESHIFT_AND_BITSHIFTS( _srcRowAlignment ) \
    byteShift      = ((_srcRowAlignment) + foreSize) & 3; \
    bitShiftLower  = byteShift*8;  \
    bitShiftUpper  = (32-bitShiftLower)

// Macro:   MISALIGNED_MEMCPY_COMMON_SETUP( dstRow, srcRow, copyWidth )
//
// Desc:    Initializes the common variables used by all "memcpy*Misaligned" kernels.
//          (See also MISALIGNED_MEMCPY_COMMON_DECLS)
//
// Args:    dstRowAlignment     How the destination row is byte-aligned.
//          srcRowAlignment     How the source row is byte-aligned
//          copyWidth           # of bytes to copy per-row
//
// Computes:
//          foreSize        # of bytes in 'fore' section of the current row
//          midSize         # of bytes in 'mid' section of the current row
//          aftSize         # of bytes in 'aft' section of the current row
//          midCount        # of uints in the 'mid' section of the current row.
//          byteShift       how many bytes is the src-row misaligned vs the dst row
//          bitShiftUpper   how many bits of a src mid value straddle the upper word
//          bitShiftLower   how many bits of a src mid value straddle the lower word
//
#define MISALIGNED_MEMCPY_COMMON_SETUP( _dstRowAlignment, _srcRowAlignment, _copyWidth ) \
    INIT_FORE_MID_AFT_SIZES( _dstRowAlignment, _copyWidth ); \
    INIT_BYTESHIFT_AND_BITSHIFTS( _srcRowAlignment )


// Surfaces
extern "C" surface< void, 2 > isurfref2D;
extern "C" surface< void, 2 > osurfref2D;
extern "C" surface< void, 3 > isurfref3D;
extern "C" surface< void, 3 > osurfref3D;

// ====================================================================================================
// Section:     Generic surface read/write wrapper functions.
//
// Desc:        This makes all surf<N>Dread() and all the surf<N>Dwrite() functions
//              have the same argument list.   This makes it possible to use
//              templatized functions for the AtoD, DtoA, and AtoA kernels
//
// ====================================================================================================

template <typename T>
__forceinline__ __device__ void
readSurface2D( T* value, uint32 srcX, uint32 srcY, uint32 srcZ )
{
    surf2Dread( value, isurfref2D, srcX, srcY );
}

template <typename T>
__forceinline__ __device__ void
readSurface3D( T* value, uint32 srcX, uint32 srcY, uint32 srcZ )
{
    surf3Dread( value, isurfref3D, srcX, srcY, srcZ );
}

template <typename T>
__forceinline__ __device__ void
writeSurface2D( T value, uint32 dstX, uint32 dstY, uint32 dstZ )
{
    surf2Dwrite( value, osurfref2D, dstX, dstY );
}

template <typename T>
__forceinline__ __device__ void
writeSurface3D( T value, uint32 dstX, uint32 dstY, uint32 dstZ )
{
    surf3Dwrite( value, osurfref3D, dstX, dstY, dstZ );
}


// ====================================================================================================
// Section:     DtoD kernels
//
// Desc:        This section contains kernels which perform copies where both the source and
//              destination are  Device Ptrs (D)
// ====================================================================================================

//#define VERBOSE 1

// -----------------------------------------------------------------------------------------------
// Kernel:      memcpyDtoD3DAligned( dstBuf, dstPitch, dstHeight, srcBuf, srcPitch, srcHeight copyWidth )
//
// Desc:        Copy 'srcBuf' to 'dstBuf' using 32-bit integers.
//
//              This is the fastest kernel, used when the buffers,
//              and pitches and copyWidth are all 4-byte aligned.
//
// Requires:    srcBuf and dstBuf must both be aligned on a 4-byte boundary
//              srcPitch and dstPitch must both be 4-byte aligned.
//              copyWidth must be 4-byte aligned.
//
//              block shape is always 1D (n,1,1).
//              grid shape is always 3D (m,height,depth)
//              Each (grid.x * block.x) writes an entire row of the surface
//
// Notes:       The GT200 kernels are faster than this kernel for the
//              1D and 2D copies, but this kernel is faster for 3D copies.
//
// -----------------------------------------------------------------------------------------------
extern "C" __global__ void
memcpyDtoD3DAligned(
    uchar           *dstBuf,
    uint64           dstPitch, // bytes
    uint32           dstHeight,
    const uchar     *srcBuf,
    uint64           srcPitch, // bytes
    uint32           srcHeight,
    uint32           copyWidth )    // bytes
{
    const uint32  tid    = threadIdx.x + (blockIdx.x * blockDim.x);
    const uint32  idxStride = (blockDim.x * gridDim.x);
    const uint32 *srcRow = (const uint32*) (srcBuf + ((srcHeight*blockIdx.z + blockIdx.y)*srcPitch));
    uint32       *dstRow = (uint32*)       (dstBuf + ((dstHeight*blockIdx.z + blockIdx.y)*dstPitch));
    uint32        count  = copyWidth >> 2; // # of uint32 values to copy

    for (uint32 index=tid; index<count; index+=idxStride) {
        dstRow[ index ] = srcRow[ index ];
    }
}


// -----------------------------------------------------------------------------------------------
// Kernel:      memcpyDtoD3DMisaligned(dst,dstPitch,dstHeight,src,srcPitch,srcHeight,copyWidth)
//
// Desc:        This kernel copies memory when the source and destination
//              surfaces are misaligned.
//
//              We subdivide each row into 3 sections: fore, mid, aft.
//
//              The 'mid' section starts on a 16-byte boundary, and
//              ends on a 4-byte boundary, and is as long as possible.
//
//              The 'fore' and 'aft' sections are whatever is leftover
//              before and after the 'mid' section.
//
//              The copying is performed out of order, with the
//              nicely-aligned mid section being copied first,
//              and the non-aligned 'fore' and 'aft' sections
//              copied afterword.  (This order profiled
//              noticeably faster than doing it in the more
//              logical order of fore, mid, aft)
//
//              Since the source and destinations are misaligned, for each destination value
//              in the 'mid' section, we have to read 2 uint values from the source surface,
//              and bit-shift them together to get the destination value.
//
//              It's a lot of setup logic, but for a non-trivial sized copy, this
//              is at least twice as fast as doing the copy on a byte-by-byte basis.
// -----------------------------------------------------------------------------------------------

//#define VERBOSE

extern "C" __global__ void
memcpyDtoD3DMisaligned(
    uchar       *dstBuf,
    uint64       dstPitch,   // in bytes
    uint32       dstHeight,  // in rows
    const uchar *srcBuf,
    uint64       srcPitch,   // in bytes
    uint32       srcHeight,  // rows
    uint32       copyWidth ) // in bytes
{
    const uint32  tid       = threadIdx.x + (blockIdx.x * blockDim.x);
    const uint32  idxStride = (blockDim.x * gridDim.x);
    const uchar  *srcRow    = srcBuf + ((srcHeight*blockIdx.z + blockIdx.y)*srcPitch); // not aligned
    uchar        *dstRow    = dstBuf + ((dstHeight*blockIdx.z + blockIdx.y)*dstPitch); // not aligned
    const uint32 *srcMid;
    uint32       *dstMid;
    MISALIGNED_MEMCPY_COMMON_DECLS;

    MISALIGNED_MEMCPY_COMMON_SETUP( PTR_TO_UINT32(dstRow), PTR_TO_UINT32(srcRow), copyWidth );

#ifdef VERBOSE
    printf("memcpyDtoD3DMisaligned: row #%d: tid=%d, copyWidth=%d, stride=%d, foreSize=%d, midSize=%d, aftSize=%d\n",
        blockIdx.y, tid, copyWidth, idxStride, foreSize, midSize, aftSize );
#endif


    dstMid = (uint32*) (dstRow + foreSize);
    srcMid = (const uint32*) (srcRow + ((int)foreSize - (int)byteShift));

    //
    // --------- actual copying starts here --------------------------------------
    //

    // Copy the 16-byte aligned 'mid' section first.
    if (bitShiftLower == 0) {
        // src & dst mid sections are aligned.  No bit-shifting required.
        for (uint32 midIdx=tid; midIdx<midCount; midIdx+=idxStride) {
            dstMid[ midIdx ] = srcMid[ midIdx ];
#ifdef VERBOSE
            printf( "row #%d: tid=%d, midIdx=%d, value=0x%08x\n",
                blockIdx.y, tid, midIdx, srcMid[ midIdx ] );
#endif
        }
    }
    else {
        // src and dst are misaligned.   We need to read 2 adjacent src values
        // and bit-shift them to make one dst value.
        for (uint32 midIdx=tid; midIdx<midCount; midIdx+=idxStride) {
            uint32 srcLower, srcUpper;
            uint32 dstValue;

            srcLower = srcMid[ midIdx ];
            srcUpper = srcMid[ midIdx+1 ];
            dstValue = (srcLower >> bitShiftLower) | (srcUpper << bitShiftUpper);

//#define VERBOSE 1
    #ifdef VERBOSE
            printf( "row #%d: tid=%d, midIdx=%d, shift=%d, correct=0x%02x%02x%02x%02x, srcLower=0x%08x, srcUpper=0x%08x, dstValue=0x%08x\n",
                blockIdx.y, tid, midIdx, bitShiftLower,
                srcRow[ foreSize + (midIdx*4) + 3 ],
                srcRow[ foreSize + (midIdx*4) + 2 ],
                srcRow[ foreSize + (midIdx*4) + 1 ],
                srcRow[ foreSize + (midIdx*4) + 0 ],
                srcLower, srcUpper, dstValue );
    #endif
//    #undef VERBOSE

            dstMid[ midIdx ] = dstValue;
        } // for (midIdx...)
    }

    // Now copy the non-aligned 'fore' and 'aft' sections
    if (tid < foreSize+aftSize) {
        uint32 idx = tid; // fore
        if (tid >= foreSize)
            idx += midSize; // aft

#ifdef VERBOSE
            printf( "row #%d: tid=%d, idx=%d, value=0x%02x\n",
                blockIdx.y, tid, idx, srcRow[ idx ] );
#endif

        dstRow[ idx ] = srcRow[ idx ];
    }
 }

#undef VERBOSE

// ====================================================================================================
// Section:     DtoA kernels
//
// Desc:        This section contains kernels which perform copies where the source is a Device Ptr (D)
//              and the destination if a CudaArray (A)
// ====================================================================================================

//#define VERBOSE 1

template <
    void writeSurfaceU32( uint32 value, uint32 dstX, uint32 dstY, uint32 dstZ ),
    void writeSurfaceU8( uchar value, uint32 dstX, uint32 dstY, uint32 dstZ )
    >
__forceinline__ __device__  void
memcpyDtoA(
    uint32       dstOriginX, // bytes
    uint32       dstOriginY, // rows
    uint32       dstOriginZ, //
    const uchar *srcBuf,
    uint64       srcPitch,   // bytes
    uint32       srcHeight,
    uint32       copyWidth ) // bytes
{
    const uint32  tid       = threadIdx.x + (blockIdx.x * blockDim.x);
    const uint32  idxStride = (blockDim.x * gridDim.x);
    const uint32  xStride   = idxStride * sizeof(uint32);
    const uchar  *srcRow    = srcBuf + ((srcHeight*blockIdx.z + blockIdx.y)*srcPitch); // not aligned
    const uint32 *srcMid;
    uint32 dstX, dstY, dstZ;
    MISALIGNED_MEMCPY_COMMON_DECLS;

    MISALIGNED_MEMCPY_COMMON_SETUP( dstOriginX, PTR_TO_UINT32(srcRow), copyWidth );

    srcMid = (const uint32*) (srcRow + ((int)foreSize - (int)byteShift));
    dstX   = dstOriginX + foreSize + (tid*sizeof(uint32));
    dstY   = dstOriginY + blockIdx.y;
    dstZ   = dstOriginZ + blockIdx.z;

    //
    // --------- actual copying starts here --------------------------------------
    //

    // Copy the 16-byte aligned 'mid' section first.
    if (bitShiftLower == 0) {
        // src & dst mid sections are aligned.  No bit-shifting required.
        for (uint32 midIdx=tid; midIdx<midCount; midIdx+=idxStride) {
            uint32 value;
            value = srcMid[ midIdx ];
            writeSurfaceU32( value, dstX, dstY, dstZ );
            dstX += xStride;
        }
    }
    else {
        // src and dst are misaligned.   We need to read 2 adjacent src values
        // and bit-shift them to make one dst value.
        for (uint32 midIdx=tid; midIdx<midCount; midIdx+=idxStride) {
            uint32 srcLower, srcUpper;
            uint32 dstValue;

            srcLower = srcMid[ midIdx ];
            srcUpper = srcMid[ midIdx+1 ];
            dstValue = (srcLower >> bitShiftLower) | (srcUpper << bitShiftUpper);

    #ifdef VERBOSE
            printf( "midIdx=%d, mode=mid, dstX=%d, dstY=%d, shift=%d, correct=0x%02x%02x%02x%02x, srcLower=0x%08x, srcUpper=0x%08x, dstValue=0x%08x\n",
                midIdx, dstX, dstY, bitShiftLower,
                srcRow[ foreSize + (midIdx*4) + 3 ],
                srcRow[ foreSize + (midIdx*4) + 2 ],
                srcRow[ foreSize + (midIdx*4) + 1 ],
                srcRow[ foreSize + (midIdx*4) + 0 ],
                srcLower, srcUpper, dstValue );
    #endif

            writeSurfaceU32( dstValue, dstX, dstY, dstZ );
            dstX += xStride;
        }
    }

    // Now copy the non-aligned 'fore' and 'aft' sections
    if (tid < foreSize+aftSize) {
        uchar value;
        uint32 srcIdx = tid; // fore
        dstX = dstOriginX + tid;
        if (tid >= foreSize) {
            srcIdx += midSize; // aft
            dstX   += midSize;
        }
        value = srcRow[ srcIdx ];
        writeSurfaceU8( value, dstX, dstY, dstZ );
    }
}

// Now create 1D, 2D, 3D instances

// DtoA 2D
extern "C" __global__ void
memcpyD3DtoA2D(
    uint32       dstOriginX, // bytes
    uint32       dstOriginY, // rows
    uint32       dstOriginZ, // not used for 2D
    const uchar *srcBuf,
    uint64       srcPitch,   // bytes
    uint32       srcHeight,  // not used for 2D
    uint32       copyWidth ) // bytes
{
    memcpyDtoA< writeSurface2D<uint32>, writeSurface2D<uchar> >(
        dstOriginX, dstOriginY, dstOriginZ,
        srcBuf, srcPitch, srcHeight,
        copyWidth );
}

// DtoA 3D
extern "C" __global__ void
memcpyD3DtoA3D(
    uint32       dstOriginX, // bytes
    uint32       dstOriginY, // rows
    uint32       dstOriginZ, //
    const uchar *srcBuf,
    uint64       srcPitch,   // bytes
    uint32       srcHeight,
    uint32       copyWidth ) // bytes
{
    memcpyDtoA< writeSurface3D<uint32>, writeSurface3D<uchar> >(
        dstOriginX, dstOriginY, dstOriginZ,
        srcBuf, srcPitch, srcHeight,
        copyWidth );
}


// ====================================================================================================
// Section:     AtoD kernels
//
// Desc:        This section contains kernels which perform copies where the source is a Cuda Array (A)
//              and the destination is a Device Ptr (D).
// ====================================================================================================

//#define VERBOSE 1

template <
    void readSurfaceU32( uint32* value, uint32 dstX, uint32 dstY, uint32 dstZ ),
    void readSurfaceU8( uchar* value, uint32 dstX, uint32 dstY, uint32 dstZ )
    >
__forceinline__ __device__  void
memcpyAtoD(
    uchar   *dstBuf,
    uint64   dstPitch,   // bytes
    uint32   dstHeight,
    uint32   srcOriginX, // bytes
    uint32   srcOriginY, // rows
    uint32   srcOriginZ, //
    uint32   copyWidth ) // bytes
{
    const uint32  tid       = threadIdx.x + (blockIdx.x * blockDim.x);
    const uint32  idxStride = (blockDim.x * gridDim.x);
    const uint32  xStride   = idxStride * sizeof(uint32);
    uchar        *dstRow    = dstBuf + ((dstHeight*blockIdx.z + blockIdx.y)*dstPitch); // not aligned
    uint32       *dstMid;
    uint32        srcX, srcY, srcZ;
    MISALIGNED_MEMCPY_COMMON_DECLS;

    MISALIGNED_MEMCPY_COMMON_SETUP( PTR_TO_UINT32(dstRow), srcOriginX, copyWidth );
    // compute fore, mid, aft zones for the current row

    dstMid = (uint32*) (dstRow + foreSize);
    srcX   = srcOriginX + foreSize - byteShift + (tid*sizeof(uint32));
    srcY   = srcOriginY + blockIdx.y;
    srcZ   = srcOriginZ + blockIdx.z;

#ifdef VERBOSE
    printf( "memcpyAtoD[%d][%d]( \n"
            "\tdstBuf=0x%08llx, dstPitch=%lld, dstHeight=%d,\n"
            "\tsrcOriginX=%d,srcOriginY=%d,srcOriginZ=%d,\n"
            "\tcopyWidth=%d )\n"
            "\tidxStride=%d, bitShiftLower=%d\n"
            "\tforeSize=%d, midSize=%d, aftSize=%d, midCount=%d,\n"
            "\tdstRow=0x%08llx\n",

            blockIdx.y, tid,
            (unsigned long long) dstBuf, dstPitch, dstHeight,
            srcOriginX, srcOriginY, srcOriginZ,
            copyWidth,
            idxStride, bitShiftLower,
            foreSize, midSize, aftSize, midCount,
            (unsigned long long) dstRow );
#endif
    //
    // --------- actual copying starts here --------------------------------------
    //

    // Copy the 16-byte aligned 'mid' section first.
    if (bitShiftLower == 0) {
        // src & dst mid sections are aligned.  No bit-shifting required.
        for (uint32 midIdx=tid; midIdx<midCount; midIdx+=idxStride) {
            uint32 value;
            readSurfaceU32( &value, srcX, srcY, srcZ );
            dstMid[ midIdx ] = value;
            srcX += xStride;
        }
    }
    else {
        // src and dst are misaligned.   We need to read 2 adjacent src values
        //  and bit-shift them to make a dst value.
        for (uint32 midIdx=tid; midIdx<midCount; midIdx+=idxStride) {
            uint32 srcLower, srcUpper;
            uint32 dstValue;
            readSurfaceU32( &srcLower, srcX,                srcY, srcZ );
            readSurfaceU32( &srcUpper, srcX+sizeof(uint32), srcY, srcZ );
            dstValue = (srcLower >> bitShiftLower) | (srcUpper << bitShiftUpper);
            dstMid[ midIdx ] = dstValue;
        }
    }

    // Now copy the non-aligned 'fore' and 'aft' sections

    if (tid < foreSize+aftSize) {
        uchar value;
        uint32 idx = tid; // fore
        srcX = srcOriginX + tid;
        if (tid >= foreSize) {
            idx  += midSize; // aft
            srcX += midSize;
        }
   
        readSurfaceU8( &value, srcX, srcY, srcZ );
        dstRow[ idx ] = value;
    }

    //printf( "end memcpyAtoD[%d][%d]\n", blockIdx.y, tid );
}

// AtoD 2D
extern "C" __global__ void
memcpyA2DtoD3D(
    uchar   *dstBuf,
    uint64   dstPitch,   // bytes
    uint32   dstHeight,  // not used for 2D
    uint32   srcOriginX, // bytes
    uint32   srcOriginY, // rows
    uint32   srcOriginZ, // not used for 2D
    uint32   copyWidth )      // bytes
{
    memcpyAtoD< readSurface2D<uint32>, readSurface2D<uchar> >(
        dstBuf, dstPitch, dstHeight,
        srcOriginX, srcOriginY, srcOriginZ,
        copyWidth );
}

// AtoD 3D
extern "C" __global__ void
memcpyA3DtoD3D(
    uchar   *dstBuf,
    uint64   dstPitch,   // bytes
    uint32   dstHeight,
    uint32   srcOriginX, // bytes
    uint32   srcOriginY, // rows
    uint32   srcOriginZ, //
    uint32   copyWidth )      // bytes
{
    memcpyAtoD< readSurface3D<uint32>, readSurface3D<uchar> >(
        dstBuf, dstPitch, dstHeight,
        srcOriginX, srcOriginY, srcOriginZ,
        copyWidth );
}

// ====================================================================================================
// Section:     AtoA kernels
//
// Desc:        This section contains kernels which perform copies where the source and destination
//              are both Cuda Arrays.
// ====================================================================================================

//#define VERBOSE 1

template <
    void readSurfaceU32( uint32* value, uint32 dstX, uint32 dstY, uint32 dstZ ),
    void readSurfaceU8( uchar* value, uint32 dstX, uint32 dstY, uint32 dstZ ),
    void writeSurfaceU32( uint32 value, uint32 dstX, uint32 dstY, uint32 dstZ ),
    void writeSurfaceU8( uchar value, uint32 dstX, uint32 dstY, uint32 dstZ )
        >
__forceinline__ __device__  void
memcpyAtoA(
   // destination origin
    uint32   dstOriginX, // bytes
    uint32   dstOriginY,
    uint32   dstOriginZ,
    // source origin
    uint32   srcOriginX, // bytes
    uint32   srcOriginY,
    uint32   srcOriginZ,
    // copy size
    uint32   copyWidth )      // bytes
{
    const uint32  tid        = threadIdx.x + (blockIdx.x * blockDim.x);
    const uint32  idxStride  = (blockDim.x * gridDim.x);
    const uint32  xStride    = idxStride * sizeof(uint32);
    uint32 srcX, srcY, srcZ, dstX, dstY, dstZ;

    MISALIGNED_MEMCPY_COMMON_DECLS;

    MISALIGNED_MEMCPY_COMMON_SETUP( dstOriginX, srcOriginX, copyWidth );

    srcX = srcOriginX + foreSize - byteShift + (tid*sizeof(uint32));
    srcY = srcOriginY + blockIdx.y;
    srcZ = srcOriginZ + blockIdx.z;

    dstX = dstOriginX + foreSize + (tid*sizeof(uint32));
    dstY = dstOriginY + blockIdx.y;
    dstZ = dstOriginZ + blockIdx.z;

    //
    // --------- actual copying starts here --------------------------------------
    //

    // Copy the 16-byte aligned 'mid' section first.
    if (bitShiftLower == 0) {
        // src & dst mid sections are aligned.  No bit-shifting required.
        for (uint32 midIdx=tid; midIdx<midCount; midIdx+=idxStride) {
            uint32 value;
            readSurfaceU32( &value, srcX, srcY, srcZ );
            writeSurfaceU32( value, dstX, dstY, dstZ );
            srcX += xStride;
            dstX += xStride;
        }
    }
    else {
        // src and dst are misaligned.   We need to read 2 adjacent src values
        // and bit-shift them to make one dst value.
        for (uint32 midIdx=tid; midIdx<midCount; midIdx+=idxStride) {
            uint32 srcLower, srcUpper;
            uint32 dstValue;

            readSurfaceU32( &srcLower, srcX,                srcY, srcZ );
            readSurfaceU32( &srcUpper, srcX+sizeof(uint32), srcY, srcZ );
            dstValue = (srcLower >> bitShiftLower) | (srcUpper << bitShiftUpper);

    #ifdef VERBOSE
            printf( "midIdx=%d, mode=mid, srcX=%d, srcY=%d, shift=%d, srcLower=0x%08x, srcUpper=0x%08x, dstX=%d, dstValue=0x%08x\n",
                midIdx, srcX, srcY, bitShiftLower,
                srcLower, srcUpper, dstX, dstValue );
    #endif
            writeSurfaceU32( dstValue, dstX, dstY, dstZ );
            srcX += xStride;
            dstX += xStride;
        }
    }

    // Now copy the non-aligned 'fore' and 'aft' sections
    if (tid < foreSize+aftSize) {
        uchar value;
        srcX = srcOriginX + tid; // fore
        dstX = dstOriginX + tid; // fore

        if (tid >= foreSize) {
            srcX += midSize; // aft
            dstX += midSize;
        }
        readSurfaceU8( &value, srcX, srcY, srcZ );
        writeSurfaceU8( value, dstX, dstY, dstZ );
    }
}

// AtoA 2D -> 2D
extern "C" __global__ void
memcpyA2DtoA2D(
    // destination origin
    uint32   dstOriginX, // bytes
    uint32   dstOriginY,
    uint32   dstOriginZ, // not used
    // source origin
    uint32   srcOriginX, // bytes
    uint32   srcOriginY,
    uint32   srcOriginZ, // not used
    // copy size
    uint32   copyWidth )      // bytes
{
    memcpyAtoA< readSurface2D<uint32>,  readSurface2D<uchar>,
                writeSurface2D<uint32>, writeSurface2D<uchar> >
        (   dstOriginX, dstOriginY, dstOriginZ,
            srcOriginX, srcOriginY, srcOriginZ,
            copyWidth );
}

// AtoA 2D -> 3D
extern "C" __global__ void
memcpyA2DtoA3D(
    // destination origin
    uint32   dstOriginX, // bytes
    uint32   dstOriginY,
    uint32   dstOriginZ, // not used
    // source origin
    uint32   srcOriginX, // bytes
    uint32   srcOriginY,
    uint32   srcOriginZ, // not used
    // copy size
    uint32   copyWidth )      // bytes
{
    memcpyAtoA< readSurface2D<uint32>,  readSurface2D<uchar>,
                writeSurface3D<uint32>, writeSurface3D<uchar> >
        (   dstOriginX, dstOriginY, dstOriginZ,
            srcOriginX, srcOriginY, srcOriginZ,
            copyWidth );
}

// AtoA 3D -> 2D
extern "C" __global__ void
memcpyA3DtoA2D(
    // destination origin
    uint32   dstOriginX, // bytes
    uint32   dstOriginY,
    uint32   dstOriginZ,
    // source origin
    uint32   srcOriginX, // bytes
    uint32   srcOriginY,
    uint32   srcOriginZ,
    // copy size
    uint32   copyWidth )      // bytes
{
    memcpyAtoA< readSurface3D<uint32>,  readSurface3D<uchar>,
                writeSurface2D<uint32>, writeSurface2D<uchar> >
        (   dstOriginX, dstOriginY, dstOriginZ,
            srcOriginX, srcOriginY, srcOriginZ,
            copyWidth );
}


// AtoA 3D -> 3D
extern "C" __global__ void
memcpyA3DtoA3D(
    // destination origin
    uint32   dstOriginX, // bytes
    uint32   dstOriginY,
    uint32   dstOriginZ,
    // source origin
    uint32   srcOriginX, // bytes
    uint32   srcOriginY,
    uint32   srcOriginZ,
    // copy size
    uint32   copyWidth )      // bytes
{
    memcpyAtoA< readSurface3D<uint32>,  readSurface3D<uchar>,
                writeSurface3D<uint32>, writeSurface3D<uchar> >
        (   dstOriginX, dstOriginY, dstOriginZ,
            srcOriginX, srcOriginY, srcOriginZ,
            copyWidth );
}

