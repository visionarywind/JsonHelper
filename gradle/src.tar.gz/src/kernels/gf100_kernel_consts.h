/*
 * Copyright 2005-2011 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

#ifndef __gf100_kernel_consts_h__
#define __gf100_kernel_consts_h__

#define ROUNDUP_DIV(x, y)       (((x) + (y) - 1) / (y))

#define MAX_GRID_DIM            65535ULL
#define MAX_GRID_X              MAX_GRID_DIM

// Parameter for memcpy, use 64bit literals to avoid overflow
#define CUI_MEMCPY_ALIGNMENT        128ULL
#define CUI_MEMCPY_BLOCK_DIM_X      256ULL
#define CUI_MEMCPY_BLOCK_DIM_Y      1ULL
#define CUI_MEMCPY_STEP_SIZE        (CUI_MEMCPY_BLOCK_DIM_Y * CUI_MEMCPY_BLOCK_DIM_X)
#define CUI_MEMCPY_THREAD_COPYSIZE  16ULL
#define CUI_MEMCPY_THRESHOLD        (1 * 1024 * 1024ULL)

#define MISALIGNED_BYTES(x)     (CUI_MEMCPY_ALIGNMENT - (size_t)(x)) & (CUI_MEMCPY_ALIGNMENT - 1)
#define MISALIGNED_BYTES4(x)     ((4 - ((size_t)(x) & 3)) & 3)


#if CUI_MEMCPY_BLOCK_DIM_Y == 1
    #define MEMCPY_GETTID                  ( CUI_MEMCPY_BLOCK_DIM_X * (blockIdx.y*gridDim.x + blockIdx.x) + threadIdx.x)
    #define MEMCPY_GETTID128   ((CUI_MEMCPY_STEP_SIZE * (blockIdx.y*gridDim.x + blockIdx.x)) << 2) + threadIdx.x;
    #define MEMCPY_GETTID_FAST ( CUI_MEMCPY_BLOCK_DIM_X * blockIdx.x + threadIdx.x)
#else 
    #define MEMCPY_GETTID                  ((blockDim.x * blockDim.y) * (blockIdx.y*gridDim.x + blockIdx.x) + threadIdx.y * blockDim.x + threadIdx.x)
    #define MEMCPY_GETTID128   ((CUI_MEMCPY_STEP_SIZE * (blockIdx.y*gridDim.x + blockIdx.x)) << 2) + threadIdx.x  + threadIdx.y * blockDim.x;
    #define MEMCPY_GETTID_FAST MEMCPY_GETTID
#endif

// Parameter for memset, use 64bit literals to avoid overflow
#define CUI_MEMSET_ALIGNMENT        128ULL
#define CUI_MEMSET_BLOCK_DIM_X      64ULL
#define CUI_MEMSET_BLOCK_DIM_Y      1ULL
#define CUI_MEMSET_BLOCK_SIZE       (CUI_MEMSET_BLOCK_DIM_X * CUI_MEMSET_BLOCK_DIM_Y)
#define CUI_MEMSET_STEP_SIZE        CUI_MEMSET_BLOCK_SIZE
#define CUI_MEMSET_THREAD_COPYSIZE  16ULL
#define CUI_MEMSET_BLOCK_COPYSIZE   (CUI_MEMSET_THREAD_COPYSIZE * CUI_MEMSET_BLOCK_SIZE)
#define CUI_MEMSET_MISALIGNED_BYTES(x)     (CUI_MEMSET_ALIGNMENT - (size_t)(x)) & (CUI_MEMSET_ALIGNMENT - 1)
// biggest memset size supported (the limit is negligibly bigger for misaligned memsets), currently almost 4TB
#define CUI_MEMSET_MAX_SIZE         ((NvU64)CUI_MEMSET_BLOCK_COPYSIZE * MAX_GRID_DIM * MAX_GRID_DIM)

#if CUI_MEMSET_BLOCK_DIM_Y == 1

#define MEMSET_GETTID      ( CUI_MEMSET_BLOCK_DIM_X * (blockIdx.y*gridDim.x + blockIdx.x) + threadIdx.x)
#define MEMSET_GETTID128   ((CUI_MEMSET_STEP_SIZE * (blockIdx.y*gridDim.x + blockIdx.x)) << 2) + threadIdx.x;
#define MEMSET_GETTID_FAST ( CUI_MEMSET_BLOCK_DIM_X * blockIdx.x + threadIdx.x)

#else 
#define MEMSET_GETTID                  ((blockDim.x * blockDim.y) * (blockIdx.y*gridDim.x + blockIdx.x) + threadIdx.y * blockDim.x + threadIdx.x)
#define MEMSET_GETTID128   ((CUI_MEMCPY_STEP_SIZE * (blockIdx.y*gridDim.x + blockIdx.x)) << 2) + threadIdx.x  + threadIdx.y * blockDim.x;
#define MEMSET_GETTID_FAST MEMCPY_GETTID
#endif

#define CUI_MEMSET32_THRESHOLD  (1024 * 1024ULL)

#endif
