//Memcheck syscalls kernels
// The builtin syscalls kernels must be compiled with :
// ./buildkernel.pl memcheck_kernels_syscalls.cu -n memcheck_syscalls -nocbank  -cross -nop4 -verbose -nourf -syscall

#include "../devtools/memcheck/memcheck_dynamic_schemes.cu"
