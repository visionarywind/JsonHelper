/*
 * Copyright 2005-2011 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

#include "kernel_internal.h"
#include "kernel_memset_internal.h"
#include "kernel_memset.h"
#include "gt200_kernel_consts.h"
#include "bikernels.h"
#include "cuimemset.h"

// Maximum block sizes for optimal performance
#define OPTIMAL_BLOCK_SIZE_PRE_KEPLER       256
#define OPTIMAL_BLOCK_SIZE_KEPLER_PLUS      512

// Load factor represents the number of `int` each thread should ideally write. We use a
// "load factor" to compute the optimal block/grid sizes. This strategy ensures that grid
// width scales with the workload's width without a significant blowup. It also ensures
// that we're very conservative with block/grid width when handling a narrow workload. This
// approach attempts to sustain high per-SM TLB hit rates for all widths.
//
// Load factor of 4 profiled extremely well on Kepler+ devices. "Why?" is yet to be answered.
#define OPTIMAL_LOAD_FACTOR                 4

static NV_INLINE CUkernelMemsetGT200 *
getKernelData(CUctx *ctx)
{
    return ctx->kernelMemset.tesla;
}

static NV_INLINE void
setKernelData(CUctx *ctx, CUkernelMemsetGT200 *data)
{
    ctx->kernelMemset.tesla = data;
}

// ----------------------------------------------------------------------------
// Func:    gt200KernelMemsetInit( ctx )
//
// Desc:    Initialize gt200 memset kernel
// ----------------------------------------------------------------------------
CUresult
gt200KernelMemsetInit(CUctx *ctx)
{
    CUresult status;
    CUjitCompileData compileData;
    CUkernelMemsetGT200 *pMemsetData;

    CU_TRACE_FUNCTION();
    CU_ASSERT(ctx);

    pMemsetData = (CUkernelMemsetGT200*)malloc(sizeof(*pMemsetData));
    if (!pMemsetData) {
        CU_ERROR_PRINT(("Failed to allocate memory\n"));
        status = CUDA_ERROR_OUT_OF_MEMORY;
        goto Error;
    }

    memset(pMemsetData, 0, sizeof(*pMemsetData));
    setKernelData(ctx, pMemsetData);

    cuiSetDefaultCompilerOptions(&compileData);
    status = cuiModuleLoadData(ctx, &getKernelData(ctx)->mod,
                               cuiGetBIKCubin(allCubins_gt200_kernel_memset,
                                              ctx->device->state.major,
                                              ctx->device->state.minor),
                               NULL, &compileData, ctx->api);
    if (CUDA_SUCCESS != status) {
        CU_DEBUG_PRINT(("Failed to load memset cubin.\n"));
        goto Error;
    }

    LOAD_FUNCTION(status, getKernelData(ctx), memset8);
    LOAD_FUNCTION(status, getKernelData(ctx), memset32);

    return CUDA_SUCCESS;

Error:
    gt200KernelMemsetDestroy(ctx);
    return status;
}

// ----------------------------------------------------------------------------
// func:    gt200KernelMemsetDestroy( ctx )
//
// desc:    Cleanup and free auxiliary kernel data structures
// ----------------------------------------------------------------------------
void
gt200KernelMemsetDestroy(CUctx *ctx)
{
    CU_TRACE_FUNCTION();
    CU_ASSERT(ctx);

    if (getKernelData(ctx)) {
        if (getKernelData(ctx)->mod) {
            cuiModuleUnload(getKernelData(ctx)->mod);
        }
        free(getKernelData(ctx));
        setKernelData(ctx, NULL);
    }
}

static CUresult
recordKernel(
    CUfunc* func, CUdeviceptr_v2 dstDevice, CUdim3 gridDim, CUdim3 blockDim,
    NvU32 value, size_t width, size_t pitch, CUImemsetInfo *info)
{
    // Don't actually launch for graphs
    CUImemsetKernelInfo *kernelInfo = cuiMemsetKernelInfoCreate(info);
    if (kernelInfo == NULL) {
        return CUDA_ERROR_OUT_OF_MEMORY;
    }
    kernelInfo->params.func = func;
    kernelInfo->params.gridDimX = gridDim.x;
    kernelInfo->params.gridDimY = gridDim.y;
    kernelInfo->params.gridDimZ = gridDim.z;
    kernelInfo->params.blockDimX = blockDim.x;
    kernelInfo->params.blockDimY = blockDim.y;
    kernelInfo->params.blockDimZ = blockDim.z;
    kernelInfo->params.kernelParams = kernelInfo->argv;
    kernelInfo->dstDevice = dstDevice;
    kernelInfo->argv[0] = &kernelInfo->dstDevice;
    kernelInfo->value = value;
    kernelInfo->argv[1] = &kernelInfo->value;
    kernelInfo->width = width;
    kernelInfo->argv[2] = &kernelInfo->width;
    kernelInfo->pitch = pitch;
    kernelInfo->argv[3] = &kernelInfo->pitch;
    return CUDA_SUCCESS;
}

// ----------------------------------------------------------------------------
// Func:    launchKernel( ctx, func, dstDevice, grid, block , value,
//              width, pitch, stream, flags )
//
// Desc:    Launch a memset kernel function with the specified parameters.
// ----------------------------------------------------------------------------
static CUresult
launchKernel(
    CUctx *ctx, CUfunc* func, CUdeviceptr_v2 dstDevice, CUdim3 gridDim, CUdim3 blockDim,
    NvU32 value, size_t width, size_t pitch, CUIstream *stream, NvU32 flags)
{
    CUresult status;
    unsigned int offset = 0;

    // Set thread shape
    status = cuiFuncSetBlockShape(func, blockDim.x, blockDim.y, blockDim.z);
    if( status != CUDA_SUCCESS ) {
        CU_ERROR_PRINT(("Couldn't set block shape.\n"));
        goto Error;
    }

    // Set parameters. This returns out of GPUmemset if error!
    {
        unsigned int uiC = (unsigned int)value;
        SETPARAMV(dstDevice, status, offset, 1);
        SETPARAMV(value, status, offset, 2);
        SETPARAMV(width, status, offset, 3);
        SETPARAMV(pitch, status, offset, 4);
    }

    // Set param sizes
    status = cuiParamSetSize( func, offset );
    if( status != CUDA_SUCCESS ) {
        CU_ERROR_PRINT(("Couldn't set param size.\n"));
        goto Error;
    }

    if(isProfilingEnabled(ctx) && (flags & CUI_MEMSET_API_REQUESTED)) {
        // Launch grid to do memset
        status = cuiProfilerLaunchGrid(func, gridDim, stream, NULL, 0);
    }
    else {
        // Launch grid to do memset
        status = cuiLaunchGrid(func, gridDim, stream, NULL, 0);
    }

Error:
    return status;
}

// ----------------------------------------------------------------------------
// Func:    configureShape( &grid, &block, &width, height, elementSize,
//              warpSize, maxBlockWidth, maxGridWidth )
//
// Desc:    Set the optimal `grid` and `block` shape. Reduce `width` if we it
//          is too large to optimally handle. 
// ----------------------------------------------------------------------------
static CUresult
configureShape(
    CUdim3 *gridDim, CUdim3 *blockDim, size_t *width, size_t height, NvU32 elementSize,
    const unsigned int warpSize, const unsigned int maxBlockWidth, const unsigned int maxGridWidth)
{
    // Block is always 1D
    blockDim->y = 1;
    blockDim->z = 1;

    // Scale Y blocks with height
    gridDim->y = (unsigned int)((height - 1) / blockDim->y + 1);

    // Grid is never 3D
    gridDim->z = 1;

    // Based on byte, int memset, configure block and grid shapes
    switch( elementSize ) {
        case 1:
            // Compute optimal block size
            blockDim->x = (unsigned int) MIN(MAX(*width / (sizeof(int) * OPTIMAL_LOAD_FACTOR), warpSize),
                                          maxBlockWidth);

            // Round it up to warpSize
            CU_ASSERT((warpSize & (warpSize - 1)) == 0);
            blockDim->x = (blockDim->x + warpSize - 1) & ~(warpSize - 1);

            // Compute grid size along X
            gridDim->x = (unsigned int) MAX((*width / sizeof(int)) / (OPTIMAL_LOAD_FACTOR * blockDim->x), 1);

            // Partition the workload if we need more blocks than supported by hardware
            if (gridDim->x > maxGridWidth) {
                // Set width to the maximum we can optimally set in a single grid launch
                *width -= (gridDim->x - maxGridWidth) * blockDim->x * OPTIMAL_LOAD_FACTOR * sizeof(int);
                gridDim->x = maxGridWidth;
            }
            break;
        case 4:
            // Compute optimal block size
            blockDim->x = (unsigned int) MIN( MAX(*width / OPTIMAL_LOAD_FACTOR, warpSize), maxBlockWidth );

            // Round it up to warpSize
            CU_ASSERT((warpSize & (warpSize - 1)) == 0);
            blockDim->x = (blockDim->x + warpSize - 1) & ~(warpSize - 1);

            // Compute grid size along X
            gridDim->x = (unsigned int) MAX((*width) / (OPTIMAL_LOAD_FACTOR * blockDim->x), 1);

            // Partition the workload if we need more blocks than supported by hardware
            if (gridDim->x > maxGridWidth) {
                // Set width to the maximum we can optimally set in a single grid launch
                *width -= (gridDim->x - maxGridWidth) * blockDim->x * OPTIMAL_LOAD_FACTOR;
                gridDim->x = maxGridWidth;
            }
            break;
        default:
            CU_DEBUG_PRINT(("invalid memset size\n"));
            return CUDA_ERROR_INVALID_VALUE;
    }

    return CUDA_SUCCESS;
}

// --------------------------------------------------------------------------------------
// Func:    gt200KernelMemsetInternal( ctx, func, dstDevice, value, width, pitch, height,
//              elementSize, desc, stream, memobj, flags )
//
// Desc:    Perform a memset on a 2D memory surface whose dimensions are potentially
//          larger than we can possibly handle in a single grid launch.
//
//          This function subdivides the requested 2D extent into sub-rectangles of
//          optimal size, and memsets each one.
// --------------------------------------------------------------------------------------
static CUresult
gt200KernelMemsetInternal(
    CUctx *ctx, CUfunc* func, CUdeviceptr_v2 dstDevice, NvU32 value,
    size_t width, size_t pitch, size_t height, NvU32 elementSize,
    CUImemsetInfo *info, CUIstream *stream, CUmemobj *memobj, NvU32 flags)
{
    CUresult status = CUDA_SUCCESS;
    CUImemsetDesc *desc = &info->desc;
    NvU32 numKernels;

    // Max number blocks that can be scheduled in each dim
    const unsigned int limitBlocksX = ctx->device->state.limits.maxCtaGridWidth;
    const unsigned int limitBlocksY = ctx->device->state.limits.maxCtaGridHeight;

    const unsigned int warpSize = ctx->device->state.limits.warpSize;

    // Maximum number of rows we can handle in one grid
    // Block height is always 1D
    const size_t maxHeight = 1 * limitBlocksY;

    // Select optimal block size
    unsigned int maxBlockSize = OPTIMAL_BLOCK_SIZE_KEPLER_PLUS;
    if (ctx->device->state.major < 3) {
        maxBlockSize = OPTIMAL_BLOCK_SIZE_PRE_KEPLER;
    }

    CU_TRACE_FUNCTION();

    // Compute number of kernels to launch
    numKernels  = (NvU32)((desc->height + maxHeight - 1) / maxHeight);

    if (!info->onlyCountKernels) {
        // Notify tools of the start of memset
        cuiToolsNotifyMemsetBegin(ctx, desc, stream, memobj, numKernels, NULL, CU_ENGINE_COMPUTE, NULL);
    }

    // Track the memobj
    kernelMemsetTrackMemobj(func, memobj);

    // If we have to set more elements in Y dim than we can at any given time,
    // we loop through and set horizontal slices.
    size_t baseY = 0;
    while( baseY < height ) {
        // How many rows can we set with this grid
        size_t curH = MIN( (height-baseY), maxHeight );

        // If we have to set more elements in X dim than we can at any given
        // time, we loop through and set sub-regions of current height-slice.
        size_t baseX = 0;
        while( baseX < width ) {

            // How many cols can we set with the grid
            size_t curW = width - baseX;

            // Compute the base pointer for our sub region that we're setting.
            CUdeviceptr_v2 tmpDevice =  dstDevice + baseY*pitch;

            // Increment base address based on work we have done
            switch( elementSize ) {
                case 1:
                    // Shift dst address by width we have already memset
                    tmpDevice = tmpDevice + baseX;
                    break;
                case 4:
                    // Shift dst address by width we have already memset
                    // baseX is counting offset in `int`s, change to bytes
                    tmpDevice = tmpDevice + (baseX * sizeof(int));

                    CU_ASSERT(0 == (tmpDevice & 3));
                    break;
                default:
                    CU_DEBUG_PRINT(("invalid memset size\n"));
                    return CUDA_ERROR_INVALID_VALUE;
            }

            CUdim3 gridDim, blockDim;

            // Compute optimal grid and block shape, for a maximum `curW` we can optimally handle
            // in a single grid launch.
            if (configureShape(&gridDim, &blockDim, &curW, curH, elementSize, warpSize, maxBlockSize, limitBlocksX)
                != CUDA_SUCCESS) {
                goto Error;
            }

            // Set thread shape
            if (info->onlyCountKernels) {
                info->memsetKernelCount++;
            }
            else if (info->noLaunch) {
                status = recordKernel(func, tmpDevice, gridDim, blockDim, value, curW, pitch, info);
            }
            else {
                status = launchKernel(ctx, func, tmpDevice, gridDim, blockDim, value, curW, pitch, stream, flags);
            }

            if(status != CUDA_SUCCESS) {
                goto Error;
            }

            // Step by the last memset width
            baseX += curW;
        }

        // Step to the next height-slice
        baseY += maxHeight;
    }

    // Success falls through to error case -- always give tools a
    // matching end callback, and return status
Error:
    if (!info->onlyCountKernels) {
        // Notify tools that the memset has finished
        cuiToolsNotifyMemsetEnd(ctx, stream, status, NULL, CU_ENGINE_COMPUTE, NULL);
    }
    return status;
}

// ----------------------------------------------------------------------------------------
// Func:    gt200KernelMemset( ctx, desc, stream, memobj, flags )
//
// Desc:    Entry function for unified memset.
// ----------------------------------------------------------------------------------------
CUresult
gt200KernelMemset(CUctx *ctx, CUImemsetInfo *info, CUIstream *stream, CUmemobj *memobj, NvU32 flags)
{
    CUfunc *func = NULL;
    NvU64 dstDevice;
    CUImemsetDesc *desc = &info->desc;

    CU_TRACE_FUNCTION();
    CU_ASSERT(ctx && desc && (info->noLaunch || stream) && (!info->onlyCountKernels || info->noLaunch));

    // Based on size, select kernel func.
    dstDevice = desc->dptr;
    switch (desc->elementSize) {
        case 1:
            func = getKernelData(ctx)->memset8;

            // Replicate byte to form an `int` value
            desc->value = desc->value | (desc->value << 8);
            desc->value = desc->value | (desc->value << 16);
            break;
        case 2:
            // Use memset8 even when `short`-aligned
            func = getKernelData(ctx)->memset8;

            // width is in `shorts`, change it to `bytes`
            desc->width *= 2;
            desc->elementSize = 1;

            // Replicate `short` to form an `int` value
            desc->value = desc->value | (desc->value << 16);
            break;
        case 4:
            func = getKernelData(ctx)->memset32;
            break;
        default:
            CU_DEBUG_PRINT(("invalid memset size\n"));
            return CUDA_ERROR_INVALID_VALUE;
            break;
    }
    return gt200KernelMemsetInternal(
        ctx, func, desc->dptr, desc->value,
        (size_t)desc->width, (size_t)desc->pitch, (size_t)desc->height, desc->elementSize,
        info, stream, memobj, flags);
}
