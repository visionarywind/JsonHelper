#!/usr/bin/perl

use strict;
use warnings;

# Compile all kernels listed in this file.

# Uses cuda-spare-2. Look at crossbuildkernel for requirements to run
# this script.

# Add files here to put them in the script which recompiles all kernels.

# Format: "kernel.cu [name [pass_thru_option]]", where both name and
# pass_thru_option are optional.
# Note that last item needs to not have a trailing comma.
my @kernels =   (
               "gt200_kernel_memcpy.cu    gt200_kernel_memcpy",
               "gt200_kernel_memset.cu    gt200_kernel_memset",
               "gf100_kernel_memcpy.cu    gf100_kernel_memcpy",
               "gm10x_kernel_memcpy.cu    gm10x_kernel_memcpy",
               "kernel_graph_scheduler.cu kernel_graph_scheduler",
#               "syscall_device_shared.cu syscalls -syscall",
#               "memcheck_kernels.cu      memcheck -syscall"
                );


# Kernel compilation.
foreach(@kernels)
{
    my @kernel = split(' ', $_);
    my $length = @kernel;

    (($length <= 3) && ($length >= 1)) or die "Malformed kernel/name pair.\n";

    my $command = "./crossbuildkernel.pl $kernel[0]";

    if($length >= 2) {
        $command .= " -n $kernel[1]";
    }

    # add generic pass through option
    if ($length == 3) {
        $command .= " " . $kernel[2];
    }

    print `$command`; print "\n";
}
