If you're working on syscall device code and want to see how the
build system can automatically generate $ARCH/syscalls.fatbin.c
during the build, look in drivers/gpgpu/cuda/src/cuda.mk and
search for SYSCALL_DEVELOPER.

IMPORTANT NOTE!!!
    Building syscalls requires passing the special "-assyscall"
    command line option to ptxas.  This option is not present in
    the release builds of the compiler.  Given that even our debug
    builds of the toolkit copy over the release versions of the
    compiler exports, there is no way to build syscalls using the
    normal build.  However, building with:

        NATIVE_EXPORT=1 make

    will  pull over build-appropriate compilers.  Make sure you
    build the syscall fatbin from within a debug build environment
    though.  Otherwise you'll get a nice error message from nvcc.
