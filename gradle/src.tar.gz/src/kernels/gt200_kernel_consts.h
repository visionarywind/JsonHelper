/*
 * Copyright 2005-2011 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */
#ifndef __gt200_kernel_consts_h__
#define __gt200_kernel_consts_h__

#define MEMORY_ALIGNMENT        128
#define MEMORY_BLOCK_DIM_X      32
#define MEMORY_BLOCK_DIM_Y      8
#define MEMORY_STEP_SIZE        (MEMORY_BLOCK_DIM_Y * MEMORY_BLOCK_DIM_X)
#define MEMORY_THREAD_COPYSIZE  16
#define MEMORY_THRESHOLD        (8*1024*1024)  
#define MAX_GRID_X              65535
#define MISALIGNED_BYTES(x)     (MEMORY_ALIGNMENT - (size_t)(x)) & (MEMORY_ALIGNMENT - 1)
#define ROUNDUP_DIV(x, y)       ((x + y - 1) / y)
#define GETTID                  ((blockDim.x * blockDim.y) * (blockIdx.y*gridDim.x + blockIdx.x) + threadIdx.y * blockDim.x + threadIdx.x)

#endif
