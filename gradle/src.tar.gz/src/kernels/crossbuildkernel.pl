#!/usr/bin/perl

use strict;
use warnings;
use Getopt::Long;



# This is a simple wrapper script to compile a given .cu kernel file, using
#  the buildkernel.pl script.

# This script ssh's to machines that can build the kernels for the correct
# architectures, compiles remotely, and copies back the .fatbin.c files.

# The folder used for compilation is the md5sum of the kernel source, so there
# is very unlikely to be a namespace collision.

# Local machine is used if possible, otherwise cuda-spare-2 is the machine
# used for compilation. Read Usage for further details.

# Note that nvcc, arch, p4, and md5sum must be in your path.

# Note also that this should be run out of cuda/src/kernels/. All paths used
#  are relative, so plan accordingly.




############### Argument handling ###############

sub Usage {
print STDERR
"
Usage: ./crossbuildkernel.pl file.cu [ -n function_name -syscall
                                       -linux64 machine64]

file.cu - File to compile kernels from.

--n function_name option specifies a different output file/function name.
    The resulting C-Struct is __fatDeviceText_(function_name).

--syscall will compile the device code to be relocatable.

-devarch=device_arch_list specifies a comma separated list of real
    architectures for which sass is to be generated, e.g, '-devarch=sm_20,sm_35'.
    The script default is to generate sass for all supported architectures.

--linux64 specifies the x86_64 linux machine on which the kernel should be
    compiled. If the local machine is x86_64 linux, local will be used.

NOTE: ssh keys should be set up. nvcc _must_ be in \$PATH on the machines
    that will be used for compilation.

    If no machines are given, local will be used where possible,
    cuda-spare-2 will be used for linux64.  Be careful to have nvcc path
    set up accordingly if cuda-spare-2 is. Your .bashrc should basically
    have:
\"
if [ \$HOSTNAME = cuda-spare-2 ]; then
    export PATH=\$PATH:(path to nvcc bin)/x86_64_Linux_debug
fi
\"
";

exit;
}

# Assert not on windows
( $^O !~ m/MSWin32/ ) or die "Windows not supported for this script.\n";

# Assert that all necessary programs are available.
( system("which ssh > /dev/null 2> /dev/null") == 0 )
    or die "Error: ssh must be configured.\n";
( system("which scp > /dev/null 2> /dev/null") == 0 )
    or die "Error: scp must be configured.\n";
( system("which uname > /dev/null 2> /dev/null") == 0 )
    or die "Error: uname must be configured.\n";

# Argument parsing.
my $funcname='';
my $needshelp='';
my $syscall='';
my $machine64='cuda-spare-2';
my $archList='';

GetOptions( 'n=s' => \$funcname, 'h|help' => \$needshelp,
            'syscall' => \$syscall,
            'linux64=s' => \$machine64,
            'devarch:s' => \$archList );

if( $needshelp )
{ &Usage(); }

my $numArgs = $#ARGV+1;
$numArgs >= 1 and $ARGV[0]=~/.*\.cu$/
    or &Usage();

my $infile = $ARGV[0];


############### Initialization ###############

# Determine system architecture. Windows not currently supported.
my $arch = `uname -m`;
chomp($arch);

# Hash the source file. Used as a non-collision directory on ssh'd machines.
my $md5 = &md5source($arch, $infile);

# Name of function and output file.
# C function name is: __fatDeviceText_$name
# Fatbin goes to: (arch)/$name.fatbin.c
my $name = $infile;
$name =~ s/\.cu$//;
if ($funcname) { $name = $funcname }

if ($syscall) {
    $syscall = '-syscall';
}

# If supplied, pass argument "-devarch=<sm_architectures>"
# on to buildkernel.pl
my $devarch = "";
if (length $archList) {
    $devarch = "-devarch=$archList";
}


# Ugly ssh mess if it can't be done locally. Cross compile 32bit and 64bit
# on an x86_64 machine.
if( $arch =~ m/x86_64/ ) {
    print "Compiling $infile on x86_64 and i686 locally...\n";
    print "./buildkernel.pl $infile -n $name $devarch -cross $syscall\n";
    `./buildkernel.pl $infile -n $name $devarch -cross $syscall`;
} else {
    print "Compiling $infile on x86_64 and i686 on $machine64...\n";
    `ssh $machine64 mkdir $md5`;
    `ssh $machine64 mkdir $md5/x86_64`;
    `ssh $machine64 mkdir $md5/i686`;
    `scp $infile $machine64:$md5/$infile`;
    `scp buildkernel.pl $machine64:$md5/buildkernel.pl`;
    `ssh $machine64 cd $md5 '&&'./buildkernel.pl $infile -n $name $devarch -nop4 -cross $syscall`;
    `scp $machine64:$md5/i686/$name.fatbin.c i686/$name.fatbin.c`;
    `scp $machine64:$md5/x86_64/$name.fatbin.c x86_64/$name.fatbin.c`;
    `ssh $machine64 rm -r $md5`;
}


# Compute md5 hash of file. Used for remote compilation folder.
sub md5source {
    # args: arch of system to know which md5 to run. windows not supported?
    # filename to hash

    my $md5local = $_[0];
    my $filetohash = $_[1];
    $md5local = `md5sum $filetohash`;
    $md5local =~ s/\s.*//;
    chomp($md5local);
    return $md5local;
}

