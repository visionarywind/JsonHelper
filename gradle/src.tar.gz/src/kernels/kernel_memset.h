/*
 * Copyright 2005-2011 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

#ifndef __kernel_memset_h__
#define __kernel_memset_h__

#include "cuda_types.h"

// === Tesla GT200 Memset Kernel ======================================================

typedef struct CUkernelMemsetGT200_st {
    CUmod *mod;

    // General purpose memset kernels that can handle any size or
    // alignment and 1D as well as 2D memsets
    CUfunc *memset8;
    CUfunc *memset32;
} CUkernelMemsetGT200;

CUresult gt200KernelMemsetInit(CUctx *ctx);

void gt200KernelMemsetDestroy(CUctx *ctx);

CUresult
gt200KernelMemset(
    CUctx *ctx,
    CUImemsetInfo *info,
    CUIstream *stream,
    CUmemobj *memobj,
    NvU32 flags);

// === Fermi GF100 Memset Kernel ======================================================

typedef struct CUkernelMemsetGF100_st {
    // 1d optimized memset kernels
    CUmod *mod;

    // functions
    CUfunc *memset128;
    CUfunc *memset8_post;
    CUfunc *memset16_post;
    CUfunc *memset32_post;
    CUfunc *memset8_pre_post;
    CUfunc *memset16_pre_post;
    CUfunc *memset32_pre_post;
} CUkernelMemsetGF100;

CUresult gf100KernelMemsetInit(CUctx *ctx);

void gf100KernelMemsetDestroy(CUctx *ctx);

CUresult
gf100KernelMemset(
    CUctx *ctx,
    CUdeviceptr dst,
    unsigned int myvalue,
    size_t size,
    unsigned int elementSize,
    CUIstream *stream,
    CUmemobj *memobj,
    NvU32 flags);


// === Maxwell GM100 Memset Kernel ======================================================

typedef struct CUkernelMemsetGM10x_st 
{
    CUmod  *mod;
    CUfunc *memset2D; 
} CUkernelMemsetGM10x;

CUresult gm10xKernelMemsetInit(CUctx *ctx);
void gm10xKernelMemsetDestroy(CUctx *ctx);
NvBool gm10xMemsetKernelIsSupported(const CUImemsetDesc *memsetDesc); 

CUresult gm10xKernelMemset(
    CUctx *ctx, 
    const CUImemsetDesc *memsetDesc, 
    CUIstream *stream, 
    CUmemobj *memobj, 
    NvU32 flags );

// === All Memset Kernels ======================================================

typedef struct CUkernelMemset_st {
    CUkernelMemsetGT200   *tesla;
    CUkernelMemsetGF100   *fermi;
    CUkernelMemsetGM10x   *maxwell;
} CUkernelMemset;

#endif // __kernel_memset_h__
