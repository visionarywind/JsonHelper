#!/usr/bin/perl

use strict;
use warnings;
use Getopt::Long;


# This is a simple script to compile a given .cu kernel file down to
# a set of arch-specific .cubins, convert them to something that can
# be compiled into the driver, and write them to
# (arch)/(function_name).cubins.c.
# (function_name) defaults to (file) from file.cu, but can be changed
# with -n function_name.
#
# See usage for parameter information.

# New suggested way to add a new kernel: Add to and run makekernels.pl
#
# Suggested usage to add a new kernel, assume function_name == NAME
# In .h file where the fatDeviceText is needed:
#   extern __cudaFatCudaBinary __fatDeviceTest__NAME[];
# In cuda/src/kernels/ directory, add NEWKERNEL.cu
#
# Log into a linux x86_64 machine
# ./buildkernels.pl NEWKERNEL.cu -n NAME -nop4 -cross
# Where x86_64/ and i686/ directories must preexist.
# -cross will compile for both x86_64 and i686.
# __This can only be done from a linux x86_64 machine__.
#
# Take resulting (arch)/NAME.cubins.c files back, put in perforce.
# If rebuilding, the -nop4 flag should not be used.
#
# Note that if you're building system calls, you should pass in
# the -syscall option.

# Note that nvcc, uname and p4 must be in your path.

# The version of nvcc used is stored as a comment in all resulting
# .cubins.c files.

# Note also that this should be run out of the local directory. All paths used
#  are relative, so plan accordingly.

# ADDING NEW ARCHITECTURES: Adding support for new architectures is
# actually pretty simple.
#
#   1) Extend %archOpts with the new arch specific compilation options.
#
#   2) Extend @defaultBuildArch with the new architecture major/minor
#      version number
#
#   3) Optionally extend %protectDeviceCode.  Generally speaking this
#      will always be a desireable thing to do, as it protects arch
#      specific code from leaking into branches where it is not intended
#      to be supported.
#
#   4) Optionally modify cuiGetBIKCubin() in cuibikernels.c to map
#      multiple device major/minor numbers to the specific arch
#      you added in step 1.

############### Argument handling ###############

sub Usage {
print STDERR
"
Usage: ./buildkernel.pl file.cu [-n function_name] [-nop4] [-cross] \\
                                [-syscall] [-verbose] [-devarch]
                                [-abiminregs] [-sepcomp] [-nocbank] [-debug] [-lineinfo] [-nourf]

file.cu - File to compile kernels from.

-n function_name option specifies a different output file/function name.
    The resulting C array is allCubins_<function_name>.

-nop4 forces no check to verify that (arch)/name.cubins.c files
    are opened in p4.  For use compiling outside of tree.

-cross will attempt to compile the kernels for arch=i686 and arch=x86_64

-syscall will compile the device code to be relocatable.

-abiminregs will compile the device code for minimum number of ABI regs

-sepcomp will compile the device code for separate compilation

-nocbank will disable OCG Cbank

-verbose will print out all shell commands being executed

-debug will build cubins with debug info

-lineinfo will build cubins with line info

-nourf will disable the use of uniform registers

-devarch=device_arch_list specifies a comma separated list of real
    architectures for which sass is to be generated, e.g, '-devarch=sm_20,sm_35'.
    The script default is to generate sass for all supported architectures.

";
    exit;
}

# Assert not on Windows
($^O !~ m/MSWin32/) or die "Windows not supported for this script.\n";

# Assert that all necessary programs are available
(system("which nvcc > /dev/null 2> /dev/null") == 0)
    or die "Error: nvcc must be in path\n";
(system("which bin2c > /dev/null 2> /dev/null") == 0)
    or die "Error: bin2c must be in path\n";
(system("which uname > /dev/null 2> /dev/null") == 0)
    or die "Error: uname must be in path\n";
(system("which p4 > /dev/null 2> /dev/null") == 0)
    or die "Error: p4 must be in path\n";

# Determine system architecture
my $hostArch = $ENV{'TARGET_ARCH'};
if (not $hostArch) {
    $hostArch = `uname -m`;
    chomp($hostArch);
}

# Argument parsing
my $funcname='';
my $nop4='';
my $crossbuild='';
my $syscall='';
my $needshelp='';
my $useSurfHack='';
my $verbose='';
my $archList='';
my $abiminregs='';
my $sepcomp='';
my $nocbank='';
my $debug='';
my $lineinfo='';
my $nourf ='';

GetOptions('n=s' => \$funcname,
           'nop4' => \$nop4,
           'cross' => \$crossbuild,
           'syscall' => \$syscall,
           'abiminregs' => \$abiminregs,
           'nocbank' => \$nocbank,
           'debug' => \$debug,
           'lineinfo' => \$lineinfo,
           'sepcomp' => \$sepcomp,
           'h|help' => \$needshelp,
           'useSurfHack' => \$useSurfHack,
           'verbose' => \$verbose,
           'devarch:s' => \$archList,
           'nourf' => \$nourf);

if ($needshelp) {
    &Usage();
}

my $numArgs = $#ARGV+1;
$numArgs >= 1 and $ARGV[0]=~/.*\.cu$/
    or &Usage();

my $infile = $ARGV[0];

# default device architectures to build for
my @defaultBuildArch = (30, 32, 35, 50, 53, 60, 62, 70, 72, 75, 80, 86);

# Disable Hopper+ architectures for memcheck
if (($infile eq "memcheck_kernels.cu") or
    ($infile eq "memcheck_kernels_syscalls.cu")) {
    @defaultBuildArch = @defaultBuildArch[0..11]
}

# optional nvcfg ifdef protection for device kernel code
# entries in the output file
my %protectDeviceCode = (
    30 => "#if NVCFG(GLOBAL_GPU_FAMILY_GK10X)",
    32 => "#if NVCFG(GLOBAL_CHIP_T124) || NVCFG(GLOBAL_GPU_IMPL_GK20A)",
    35 => "#if NVCFG(GLOBAL_GPU_FAMILY_GK11X)",
    50 => "#if NVCFG(GLOBAL_ARCH_MAXWELL)",
    53 => "#if NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B)",
    60 => "#if NVCFG(GLOBAL_ARCH_PASCAL)",
    62 => "#if NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)",
    70 => "#if NVCFG(GLOBAL_ARCH_VOLTA)",
    72 => "#if NVCFG(GLOBAL_CHIP_T194) || NVCFG(GLOBAL_GPU_IMPL_GV11B)",
    75 => "#if NVCFG(GLOBAL_ARCH_TURING)",
    80 => "#if NVCFG(GLOBAL_ARCH_AMPERE)",
    86 => "#if NVCFG(GLOBAL_ARCH_AMPERE)",
);



############### Initialization ###############

# parse -devarch argument to determine device architectures for the build
my @buildArch = ();
if ($archList eq "") {
    @buildArch = @defaultBuildArch;
} else {
    foreach (split(/,/, $archList)) {
        m/sm_(\d\d)/ or die "Invalid argument to -devarch: $_\n";
        push @buildArch, $1;
    }
}
die "No valid architectures passed to -devarch" unless @buildArch > 0;

@buildArch = sort @buildArch;


# Make sure we're not trying to cross build from not x86_64
if (($hostArch !~ m/x86_64/) and $crossbuild) {
    die "Error: Cannot cross compile from on $hostArch.
    Only cross build currently supported is i686/x86_64 from Linux x86_64.\n";
}

# Name of function and output file.
# C function name is: __fatDeviceText_$name
# cubins go to: (arch)/$name.cubins.c
my $name = $infile;
$name =~ s/\.cu$//;
if ($funcname) {
    $name = $funcname
}



############### Compilation ###############

# In the sadly rare case where we can cross compile, build for i686/x86_64
# Must be on x86_64 Linux to do this.
# Otherwise, just build on current host arch.
if ($crossbuild) {
    &buildOnArch("i686",   "-m32");
    &buildOnArch("x86_64", "-m64");
} else {
    # pass in explicit -m[32,64] to allow TARGET_ARCH to specify a
    # different host arch than what nvcc will default too (this is particularly
    # useful when you're developing on AMODEL)
    if ($hostArch =~ m/x86_64/) {
        &buildOnArch($hostArch, "-m64");
    } else {
        &buildOnArch($hostArch, "-m32");
    }
}



############### Subroutines ###############

# Build on a specific host arch, with special compile flags for nvcc.
# NOTE: This method uses global variables!
sub buildOnArch {
    #args: (host arch) to compile for.
    #       String of nvcc flags.
    my $useHostArch = $_[0];
    my $nvccflags = $_[1];

    $nvccflags .= " -I../../inc ";
    $nvccflags .= " -I../ ";
    $nvccflags .= " -I../syscalls/cnp ";
    $nvccflags .= " -I../../../../../drivers/common/inc ";
    $nvccflags .= " -I../../../../../sdk/nvidia/inc ";
    $nvccflags .= " -I../../../compiler/gpgpu/export/cuda/tools/cudart ";
    $nvccflags .= " -I../../../compiler/gpgpu/export/bin/x86_64_Linux_develop ";

    # Output file goes into arch/$name.cubins.c.
    # Check if the user has this file p4 opened or are forcing nop4.
    # If not opened and not forcing nop4, then quit.
    my $outfilename = "$useHostArch\/$name.cubins.c";
    if (not $nop4) {
        &p4checkopen($outfilename)
            or die "Error: $outfilename not opened on this p4 client.\n";
    }

    # Build up all arch-specific options
    my %archOpts;
    $archOpts{30} = " --keep-device-functions -gencode arch=compute_30,\"code=sm_30\"";
    $archOpts{32} = " --keep-device-functions -gencode arch=compute_32,\"code=sm_32\"";
    $archOpts{35} = " --keep-device-functions -gencode arch=compute_35,\"code=sm_35\"";
    $archOpts{50} = " --keep-device-functions -gencode arch=compute_50,\"code=sm_50\"";
    $archOpts{53} = " --keep-device-functions -gencode arch=compute_53,\"code=sm_53\"";
    $archOpts{60} = " --keep-device-functions -gencode arch=compute_60,\"code=sm_60\"";
    $archOpts{62} = " --keep-device-functions -gencode arch=compute_62,\"code=sm_62\"";
    $archOpts{70} = " --keep-device-functions -gencode arch=compute_70,\"code=sm_70\"";
    $archOpts{72} = " --keep-device-functions -gencode arch=compute_72,\"code=sm_72\"";
    $archOpts{75} = " --keep-device-functions -gencode arch=compute_75,\"code=sm_75\"";
    $archOpts{80} = " --keep-device-functions -gencode arch=compute_80,\"code=sm_80\"";
    $archOpts{86} = " --keep-device-functions -gencode arch=compute_86,\"code=sm_86\"";

    $archOpts{30} .= " -I../devtools/common/halo/inc/fermi/ -I../devtools/common/halo/inc/volta/";
    $archOpts{32} .= " -I../devtools/common/halo/inc/fermi/ -I../devtools/common/halo/inc/volta/";
    $archOpts{35} .= " -I../devtools/common/halo/inc/fermi/ -I../devtools/common/halo/inc/volta/";
    $archOpts{50} .= " -I../devtools/common/halo/inc/fermi/ -I../devtools/common/halo/inc/volta/";
    $archOpts{53} .= " -I../devtools/common/halo/inc/fermi/ -I../devtools/common/halo/inc/volta/";
    $archOpts{60} .= " -I../devtools/common/halo/inc/fermi/ -I../devtools/common/halo/inc/volta/";
    $archOpts{62} .= " -I../devtools/common/halo/inc/fermi/ -I../devtools/common/halo/inc/volta/";
    $archOpts{70} .= " -I../devtools/common/halo/inc/fermi/ -I../devtools/common/halo/inc/volta/";
    $archOpts{72} .= " -I../devtools/common/halo/inc/fermi/ -I../devtools/common/halo/inc/volta/";
    $archOpts{75} .= " -I../devtools/common/halo/inc/fermi/ -I../devtools/common/halo/inc/volta/";
    $archOpts{80} .= " -I../devtools/common/halo/inc/fermi/ -I../devtools/common/halo/inc/volta/";
    $archOpts{86} .= " -I../devtools/common/halo/inc/fermi/ -I../devtools/common/halo/inc/volta/";

    if ($syscall) {
        # limit register usage for syscalls to minimum supported value
        $archOpts{30} .= " -maxrregcount 16";
        $archOpts{32} .= " -maxrregcount 32";
        $archOpts{35} .= " -maxrregcount 32";
        $archOpts{50} .= " -maxrregcount 32";
        $archOpts{53} .= " -maxrregcount 32";
        $archOpts{60} .= " -maxrregcount 32";
        $archOpts{62} .= " -maxrregcount 32";
        $archOpts{70} .= " -maxrregcount 32";
        $archOpts{72} .= " -maxrregcount 32";
        $archOpts{75} .= " -maxrregcount 32";
        $archOpts{80} .= " -maxrregcount 32";
        $archOpts{86} .= " -maxrregcount 32";

        # The const_offset flag instructs the compiler where to begin loading
        # syscall constants from the device's syscall bank. When compiling
        # syscalls for a given device architecture this has to match the
        # driver's abiConstBanks.syscallOffset devstate value. On Fermi that
        # value is 260.

        # WAR bug 2321221: put memcheck syscall constants at offset 1024
        if ($name eq "memcheck_syscalls")
        {
            $archOpts{30} .= " -Xptxas \"-assyscall const_offset=1024\"";
            $archOpts{32} .= " -Xptxas \"-assyscall const_offset=1024\"";
            $archOpts{35} .= " -Xptxas \"-assyscall const_offset=1024\"";
            $archOpts{50} .= " -Xptxas \"-assyscall const_offset=1024\"";
            $archOpts{53} .= " -Xptxas \"-assyscall const_offset=1024\"";
            $archOpts{60} .= " -Xptxas \"-assyscall const_offset=1024\"";
            $archOpts{62} .= " -Xptxas \"-assyscall const_offset=1024\"";
            $archOpts{70} .= " -Xptxas \"-assyscall const_offset=1024\"";
            $archOpts{72} .= " -Xptxas \"-assyscall const_offset=1024\"";
            $archOpts{75} .= " -Xptxas \"-assyscall const_offset=1024\"";
            $archOpts{80} .= " -Xptxas \"-assyscall const_offset=1024\"";
            $archOpts{86} .= " -Xptxas \"-assyscall const_offset=1024\"";
        }
        else
        {
            $archOpts{30} .= " -Xptxas \"-assyscall const_offset=0\"";
            $archOpts{32} .= " -Xptxas \"-assyscall const_offset=0\"";
            $archOpts{35} .= " -Xptxas \"-assyscall const_offset=32\"";
            $archOpts{50} .= " -Xptxas \"-assyscall const_offset=32\"";
            $archOpts{53} .= " -Xptxas \"-assyscall const_offset=32\"";
            $archOpts{60} .= " -Xptxas \"-assyscall const_offset=32\"";
            $archOpts{62} .= " -Xptxas \"-assyscall const_offset=32\"";
            $archOpts{70} .= " -Xptxas \"-assyscall const_offset=32\"";
            $archOpts{72} .= " -Xptxas \"-assyscall const_offset=32\"";
            $archOpts{75} .= " -Xptxas \"-assyscall const_offset=32\"";
            $archOpts{80} .= " -Xptxas \"-assyscall const_offset=32\"";
            $archOpts{86} .= " -Xptxas \"-assyscall const_offset=32\"";
        }
    }

    if ($abiminregs) {
        # limit register usage to ABI minimum
        $archOpts{30} .= " -maxrregcount 16";
        $archOpts{32} .= " -maxrregcount 16";
        $archOpts{35} .= " -maxrregcount 16";
        $archOpts{50} .= " -maxrregcount 16";
        $archOpts{53} .= " -maxrregcount 16";
        $archOpts{60} .= " -maxrregcount 16";
        $archOpts{62} .= " -maxrregcount 16";
        $archOpts{70} .= " -maxrregcount 24";
        $archOpts{72} .= " -maxrregcount 24";
        $archOpts{75} .= " -maxrregcount 24";
        $archOpts{80} .= " -maxrregcount 24";
        $archOpts{86} .= " -maxrregcount 24";
    }

    if ($sepcomp) {
        $archOpts{30} .= " -rdc=true -cudart=none";
        $archOpts{32} .= " -rdc=true -cudart=none";
        $archOpts{35} .= " -rdc=true -cudart=none";
        $archOpts{50} .= " -rdc=true -cudart=none";
        $archOpts{53} .= " -rdc=true -cudart=none";
        $archOpts{60} .= " -rdc=true -cudart=none";
        $archOpts{62} .= " -rdc=true -cudart=none";
        $archOpts{70} .= " -rdc=true -cudart=none";
        $archOpts{72} .= " -rdc=true -cudart=none";
        $archOpts{75} .= " -rdc=true -cudart=none";
        $archOpts{80} .= " -rdc=true -cudart=none";
        $archOpts{86} .= " -rdc=true -cudart=none";
    }

    if ($nocbank) {
        $archOpts{30} .= " -Xptxas -disable-optimizer-consts";
        $archOpts{32} .= " -Xptxas -disable-optimizer-consts";
        $archOpts{35} .= " -Xptxas -disable-optimizer-consts";
        $archOpts{50} .= " -Xptxas -disable-optimizer-consts";
        $archOpts{53} .= " -Xptxas -disable-optimizer-consts";
        $archOpts{60} .= " -Xptxas -disable-optimizer-consts";
        $archOpts{62} .= " -Xptxas -disable-optimizer-consts";
        $archOpts{70} .= " -Xptxas -disable-optimizer-consts";
        $archOpts{72} .= " -Xptxas -disable-optimizer-consts";
        $archOpts{75} .= " -Xptxas -disable-optimizer-consts";
        $archOpts{80} .= " -Xptxas -disable-optimizer-consts";
        $archOpts{86} .= " -Xptxas -disable-optimizer-consts";
    }

    if ($nourf) {
        $archOpts{75} .= " -Xptxas \"-knob DisableUreg=1\"";
        $archOpts{80} .= " -Xptxas \"-knob DisableUreg=1\"";
        $archOpts{86} .= " -Xptxas \"-knob DisableUreg=1\"";
    }

    # SM_52 supports caching, but builtin kernels are not well verified
    # with caching on. So force -dlcm=cg on all Maxwell
    $archOpts{50} .= " -Xptxas \"-dlcm=cg\"";
    $archOpts{53} .= " -Xptxas \"-dlcm=cg\"";
    $archOpts{60} .= " -Xptxas \"-dlcm=cg\"";
    $archOpts{62} .= " -Xptxas \"-dlcm=cg\"";
    $archOpts{70} .= " -Xptxas \"-dlcm=cg\"";
    $archOpts{72} .= " -Xptxas \"-dlcm=cg\"";
    $archOpts{75} .= " -Xptxas \"-dlcm=cg\"";
    $archOpts{80} .= " -Xptxas \"-dlcm=cg\"";
    $archOpts{86} .= " -Xptxas \"-dlcm=cg\"";

    if ($debug) {
        $archOpts{30} .= " -G";
        $archOpts{32} .= " -G";
        $archOpts{35} .= " -G";
        $archOpts{50} .= " -G";
        $archOpts{53} .= " -G";
        $archOpts{60} .= " -G";
        $archOpts{62} .= " -G";
        $archOpts{70} .= " -G";
        $archOpts{72} .= " -G";
        $archOpts{75} .= " -G";
        $archOpts{80} .= " -G";
        $archOpts{86} .= " -G";
    }

    if ($lineinfo) {
        $archOpts{30} .= " -lineinfo";
        $archOpts{32} .= " -lineinfo";
        $archOpts{35} .= " -lineinfo";
        $archOpts{50} .= " -lineinfo";
        $archOpts{53} .= " -lineinfo";
        $archOpts{60} .= " -lineinfo";
        $archOpts{62} .= " -lineinfo";
        $archOpts{70} .= " -lineinfo";
        $archOpts{72} .= " -lineinfo";
        $archOpts{75} .= " -lineinfo";
        $archOpts{80} .= " -lineinfo";
        $archOpts{86} .= " -lineinfo";
    }

    # Start with a clean slate
    RunCommand("rm -f $outfilename");

    # Copy nvcc version info into leading comment
    RunCommand("nvcc -V | sed \"s|^|// |\" > $outfilename");

    # include stdio.h for NULL, and g_nvconfig.h for NVCFG defines
    RunCommand("echo \"\n#include <stdio.h>\n" .
                        "#include <g_nvconfig.h>\n" .
                        "#include \\\"bikernels.h\\\"\n\" >> $outfilename");

    # loop over all arches
    foreach my $key (@buildArch) {
        my $tmp = "tmp_sm". $key . "_" . $useHostArch . ".cubin";
        # archOpts must have entry for every built dev arch
        die "Device arch sm_$key is not in \%archOpts.\n" unless exists $archOpts{$key};

        # Generate arch specific cubin
        RunCommand("nvcc $archOpts{$key} $nvccflags $infile -cubin -o $tmp");

        # add optional compilation protection around this arch's cubin
        if ($protectDeviceCode{$key}) {
            RunCommand("echo \"\n$protectDeviceCode{$key}\n\" >> $outfilename");
        }

        # Convert cubin to a C array, delete cubin
        RunCommand("bin2c --static --const --type longlong --padd 0 --name __cubin_sm_$key" . "_$name $tmp >> $outfilename");
#RunCommand("rm -f $tmp");

        # close optional compilation protection around this arch's cubin
        if ($protectDeviceCode{$key}) {
            RunCommand("echo \"#endif // $protectDeviceCode{$key}\" >> $outfilename");
        }
    }

    # now that all the cubins have been C-ified, create an array to rule
    # them all, and in the darkness bind them
    RunCommand("echo \"\nconst BIKernel allCubins_$name\[\] = {\" >> $outfilename");
    foreach my $key (@buildArch) {
        if ($protectDeviceCode{$key}) {
            RunCommand("echo \"$protectDeviceCode{$key}\n" .
                              "    { \\\"$key\\\", __cubin_sm_$key" . "_$name, sizeof(__cubin_sm_$key" . "_$name) }, // sm_$key\n" .
                              "#endif\" >> $outfilename");
        } else {
            RunCommand("echo \"    { \\\"$key\\\", __cubin_sm_$key" . "_$name, sizeof(__cubin_sm_$key" . "_$name) }, // sm_$key\" >> $outfilename");
        }
    }
    RunCommand("echo \"    { 0 } // end of array marker\n};\" >> $outfilename");
}

# Run a command, and optionally print it out
sub RunCommand {
    `$_[0]`;
    if ($? != 0) {
        die "The following shell command did not complete successfully:\n" .
            "$_[0] (shell returned: $?)";
    } else {
        if ($verbose) {
            print STDERR "# $_[0]\n";
        }
    }
}

# Check if file is open in p4.
sub p4checkopen {
    # arg: p4 file to check opened.
    my $p4file = $_[0];
    my $isopened = `p4 opened $p4file`;

    return ($isopened !~ m/.*"not opened".*/);
}
