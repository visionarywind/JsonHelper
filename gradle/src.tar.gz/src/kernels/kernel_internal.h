/*
 * Copyright 2005-2011 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

#ifndef __kernel_internal_h__
#define __kernel_internal_h__

#include "cuda_macros.h"

#define LOAD_FUNCTION( status, cpystruct, name )                               \
do {                                                                           \
    status = cuiFuncGetByName(cpystruct->mod, # name, &cpystruct->name);       \
    if(CUDA_SUCCESS != status)                                                 \
    {                                                                          \
        CU_DEBUG_PRINT(("Failed to get handle to " # name " function.\n"));    \
        goto Error;                                                            \
    }                                                                          \
} while(0)

#define SETPARAMVF( func, param, status, offset, paramnum )                    \
do {                                                                           \
    ROUND_AND_ASSIGN( offset, offset, __alignof( param ));                     \
    status = cuiParamSetv( func, offset, &param, sizeof( param ) );            \
    offset += sizeof( param );                                                 \
    if( status != CUDA_SUCCESS ) {                                             \
        CU_ERROR_PRINT(("Couldn't set parameter %d\n", paramnum));             \
        return status;                                                         \
    }                                                                          \
} while(0)

#define SETPARAMV( param, status, offset, paramnum ) SETPARAMVF(func, param, status, offset, paramnum)

#endif // __kernel_internal_h__
