#include "kernel_graph_scheduler.h"
#include "cuda_internal.h"
#include "kernel_internal.h"
#include "bikernels.h"
#include "cuda_device.h"
#include "cuictx.h"
#include "memobj.h"

CUresult
kernelGraphSchedulerInit(CUctx *ctx)
{
    CUresult status = CUDA_SUCCESS;
    CUkernelGraphScheduler *schedulerKernelData;
    CUjitCompileData compileData;
    const unsigned long long *cubin;

    CU_TRACE_FUNCTION();
    CU_ASSERT(ctx);

    schedulerKernelData = &(ctx->kernelGraphScheduler);

    // PCAS from within a kernel is only supported on SM3.5+
    if (!cuiDeviceArchIsKeplerGK11XPlus(ctx->device)) {
        return CUDA_SUCCESS;
    }

    // Already initialized, nothing to do
    if (schedulerKernelData->mod) {
        return CUDA_SUCCESS;
    }

    // Load built-in module
    cuiSetDefaultCompilerOptions(&compileData);
    cubin = cuiGetBIKCubin(
        allCubins_kernel_graph_scheduler,
        ctx->device->state.major,
        ctx->device->state.minor);
    CU_ASSERT(cubin);

    status = cuiModuleLoadData(
        ctx, 
        &schedulerKernelData->mod,
        cubin,
        NULL, 
        &compileData,
        ctx->api);
    if (CUDA_SUCCESS != status) {
        CU_ERROR_PRINT(("Failed to load scheduler cubin.\n"));
        goto Error;
    }

    LOAD_FUNCTION(status, schedulerKernelData, graphScheduler);

    return status;

Error:
    kernelGraphSchedulerDestroy(ctx);
    return status;
}

void
kernelGraphSchedulerDestroy(CUctx *ctx)
{
    CUkernelGraphScheduler schedulerKernelData;

    CU_TRACE_FUNCTION();
    CU_ASSERT(ctx);

    schedulerKernelData = ctx->kernelGraphScheduler;
    if (schedulerKernelData.mod) {
        cuiModuleUnload(schedulerKernelData.mod);
        schedulerKernelData.mod = NULL;
    }
}
