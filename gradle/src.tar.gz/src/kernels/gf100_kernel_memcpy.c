/*
 * Copyright 1993-2011 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */
#include "kernel_memcpy.h"
#include "kernel_memcpy_internal.h"
#include "kernel_internal.h"
#include "bikernels.h"
#include "gf100_kernel_consts.h"

static CUresult 
gf100KernelMemcpy1DSmallInternal(
    CUctx *ctx, 
    const CUImemcpyDesc *copyDesc,
    CUIstream *stream, 
    NvU8 *dst, NvU8 *src,
    size_t size)
{
    CUresult status;
    NvU32 paramOffset = 0;
    CUfunc *func;
    CUdim3 gridDim;
    CUkernelMemcpyGF100 *kernels;
    size_t misalignedDst = MISALIGNED_BYTES4(dst);
    size_t misalignedSrc = MISALIGNED_BYTES4(src);

    CU_TRACE_FUNCTION();
    CU_ASSERT(ctx && stream && copyDesc);
    kernels = ctx->kernelmemcpy.fermi;

    // deal with misaligned or size % 4 != 0 cases
    if ((misalignedDst == 0) && (misalignedSrc == 0) && ((size & 3) == 0)) {
        size_t numWords = size >> 2;
        func = kernels->memcpy32_post;

        // Set grid size
        gridDim.x = (unsigned int)ROUNDUP_DIV(numWords, CUI_MEMCPY_BLOCK_DIM_X * CUI_MEMCPY_BLOCK_DIM_Y);
        gridDim.y = 1;
        gridDim.z = 1;

        // Set params
        SETPARAMV(dst,      status, paramOffset, 1);
        SETPARAMV(src,      status, paramOffset, 2);
        SETPARAMV(numWords, status, paramOffset, 3);
    }
    else if (misalignedDst == misalignedSrc && size > CUI_MEMCPY_BLOCK_DIM_X * CUI_MEMCPY_BLOCK_DIM_Y * sizeof(int)) {
        size_t totalThreads = ((size - misalignedDst) >> 2) + 2;
        size_t totalInt = totalThreads - 2; // how many integers to copy
        size_t rightChunk = (size - misalignedDst) & 3;
        NvU8 *alignedDst = dst + misalignedDst;
        NvU8 *alignedSrc = src + misalignedSrc;
        func = kernels->memcpy_post_faster;

        // Set grid size
        gridDim.x = (unsigned int)ROUNDUP_DIV(totalThreads, CUI_MEMCPY_BLOCK_DIM_X * CUI_MEMCPY_BLOCK_DIM_Y);
        gridDim.y = 1;
        gridDim.z  = 1;

        // Set params
        SETPARAMV(alignedDst,    status, paramOffset, 1);
        SETPARAMV(alignedSrc,    status, paramOffset, 2);
        SETPARAMV(misalignedDst, status, paramOffset, 3);
        SETPARAMV(totalInt,      status, paramOffset, 4);
        SETPARAMV(rightChunk,    status, paramOffset, 5);
    }
    else {
        func = kernels->memcpy_post;

        // set grid size
        gridDim.x = (unsigned int)ROUNDUP_DIV(size, CUI_MEMCPY_BLOCK_DIM_X * CUI_MEMCPY_BLOCK_DIM_Y);
        gridDim.y = 1;
        gridDim.z = 1;

        // set params
        SETPARAMV(dst,  status, paramOffset, 1);
        SETPARAMV(src,  status, paramOffset, 2);
        SETPARAMV(size, status, paramOffset, 3);
    }

    // Set block size
    status = cuiFuncSetBlockShape(
        func, 
        CUI_MEMCPY_BLOCK_DIM_X,
        CUI_MEMCPY_BLOCK_DIM_Y,
        1);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to set block shape.\n"));
        return status;
    }

    // Set param size
    status = cuiParamSetSize(func, paramOffset);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to set parameter size.\n"));
        return status;
    }

    // Track memobj for opencl
    kernelMemcpyTrackMemobj(ctx, func, copyDesc);

    // Launch kernel
    status = cuiLaunchGrid(func, gridDim, stream, NULL, 0);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Launch failure.\n"));
        return status;
    }

    return CUDA_SUCCESS;
}

static CUresult 
gf100KernelMemcpy1DInternal(
    CUctx *ctx, 
    const CUImemcpyDesc *copyDesc,
    CUIstream *stream, 
    NvU8 *dst, NvU8 *src,
    size_t size)
{
    size_t misalignedDst = MISALIGNED_BYTES(dst);
    size_t misalignedSrc = MISALIGNED_BYTES(src);
    size_t alignedSize, redundantSize;
    NvU32 gridXSize;
    size_t middleSize;
    CUdim3 gridDim;
    CUresult status;
    CUkernelMemcpyGF100 *kernels;

    CU_TRACE_FUNCTION();
    CU_ASSERT(ctx && copyDesc && stream);
    kernels = ctx->kernelmemcpy.fermi;

    if (misalignedDst >= size) {
        alignedSize = 0;
    }
    else {
        alignedSize = size - misalignedDst;
    }

    gridXSize  = (unsigned int)(alignedSize / (CUI_MEMCPY_THREAD_COPYSIZE * CUI_MEMCPY_BLOCK_DIM_X * CUI_MEMCPY_BLOCK_DIM_Y)) ;
    redundantSize = (unsigned int)(alignedSize - gridXSize * (CUI_MEMCPY_THREAD_COPYSIZE * CUI_MEMCPY_BLOCK_DIM_X * CUI_MEMCPY_BLOCK_DIM_Y));
    middleSize = 0;

    // try to process the big chunk in fastest speed
    if (gridXSize > 0 && size >= CUI_MEMCPY_THRESHOLD)
    {
        // simple algorithm to make sure the maximum bandwidth kernel can deal with most of the data
        NvU32 gridYSize = 1;
        NvU32 paramOffset = 0;
        NvU8 *newSrc, *newDst;
        CUfunc *func;

        gridYSize = ROUNDUP_DIV(gridXSize, MAX_GRID_X);
        gridXSize = gridXSize / gridYSize;
        middleSize = (gridXSize * gridYSize) * (CUI_MEMCPY_THREAD_COPYSIZE * CUI_MEMCPY_BLOCK_DIM_X * CUI_MEMCPY_BLOCK_DIM_Y);
        redundantSize = (size - middleSize);

        newDst = dst + misalignedDst;
        newSrc = src + misalignedDst;

        // same alignment big chunk, should read the maximum speed
        if (misalignedDst == misalignedSrc) {
            func = kernels->memcpy128;
        }
        else if ((misalignedDst & 3) == 0 && (misalignedSrc & 3) == 0) {
            func = kernels->memcpy128;
        }
        // different alignment cases, it should reach 80% of the peak performance
        else {
            func = kernels->memcpy128_unaligned;
        }

        // Set block size
        status = cuiFuncSetBlockShape(
            func,
            CUI_MEMCPY_BLOCK_DIM_X, 
            CUI_MEMCPY_BLOCK_DIM_Y,
            1);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to set block shape.\n"));
            return status;
        }

        // Set parameters
        SETPARAMV(newDst, status, paramOffset, 1);
        SETPARAMV(newSrc, status, paramOffset, 2);

        // Set parameter size
        status = cuiParamSetSize(func, paramOffset);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to set parameter size.\n"));
            return status;
        }

        // Track memobj for opencl
        kernelMemcpyTrackMemobj(ctx, func, copyDesc);

        // Launch kernel
        gridDim.x = gridXSize;
        gridDim.y = gridYSize;
        gridDim.z = 1;

        status = cuiLaunchGrid(func, gridDim, stream, NULL, 0);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Launch failure.\n"));
            return status;
        }
    }
    else {
        // the memcpy size is too small to run maximum bandwidth program
        return gf100KernelMemcpy1DSmallInternal(ctx, copyDesc, stream, dst, src, size);
    }

    if (redundantSize + misalignedDst != 0) {
        if (misalignedDst == 0 || (redundantSize == size)) // only one chunk needs to be finished
        {
            NvU8 *newDst = dst + size - redundantSize;
            NvU8 *newSrc = src + size - redundantSize;
            
            return gf100KernelMemcpy1DSmallInternal(ctx, copyDesc, stream, newDst, newSrc, redundantSize);
        }
        else {
            CUfunc *func = kernels->memcpy_pre_post;
            NvU32 paramOffset = 0;

            // Set block shape
            status = cuiFuncSetBlockShape(
                func, 
                CUI_MEMCPY_BLOCK_DIM_X, 
                CUI_MEMCPY_BLOCK_DIM_Y, 
                1);
            if (status != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Failed to set block shape.\n"));
                return status;
            }

            // Set parameters
            SETPARAMV(dst,           status, paramOffset, 1);
            SETPARAMV(src,           status, paramOffset, 2);
            SETPARAMV(misalignedDst, status, paramOffset, 3);
            SETPARAMV(middleSize,    status, paramOffset, 4);
            SETPARAMV(redundantSize, status, paramOffset, 5);

            // Set param size
            status = cuiParamSetSize(func, paramOffset);
            if (status != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Failed to set parameter size.\n"));
                return status;
            }

            // Track memobj for opencl
            kernelMemcpyTrackMemobj(ctx, func, copyDesc);

            // Launch kernel
            gridDim.x = (unsigned int)ROUNDUP_DIV(redundantSize, CUI_MEMCPY_BLOCK_DIM_X * CUI_MEMCPY_BLOCK_DIM_Y);
            gridDim.y = 1;
            gridDim.z = 1;

            status = cuiLaunchGrid(func, gridDim, stream, NULL, 0);
            if (status != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Launch failure.\n"));
                return status;
            }
        }
    }
    return CUDA_SUCCESS;
}

CUresult 
gf100KernelMemcpy1DDtoD(CUctx *ctx, 
                        const CUImemcpyDesc *copyDesc, 
                        CUIstream *stream, 
                        CUImemcpyCbInfo *copyCbInfo)
{
    NvU8 *dst, *src;

    CU_TRACE_FUNCTION();
    CU_ASSERT(ctx && copyDesc && stream && copyCbInfo);
    CU_ASSERT(copyDesc->extent.depth == 1 && copyDesc->extent.height == 1);

    // get origin addresses of src/dst
    src = (NvU8*)(uintptr_t)cuiMemcpyOperandGetOriginAddr(&copyDesc->src);
    dst = (NvU8*)(uintptr_t)cuiMemcpyOperandGetOriginAddr(&copyDesc->dst);

    // launch copy
    return gf100KernelMemcpy1DInternal(
        ctx,
        copyDesc,
        stream,
        dst,
        src,
        (size_t)copyDesc->extent.widthInBytes);
}

CUresult gf100KernelMemcpy1DInit(CUctx *ctx)
{
    CUresult status;
    CUkernelMemcpyGF100 *kernelHandles;
    CUjitCompileData compileData;
    const unsigned long long *cubin;

    CU_TRACE_FUNCTION();
    CU_ASSERT(ctx);

    // If already initialized, bail out
    if (ctx->kernelmemcpy.fermi) {
        return CUDA_SUCCESS;
    }    

    // Allocate memory to store kernel handles
    kernelHandles = (CUkernelMemcpyGF100*)malloc(sizeof(CUkernelMemcpyGF100));
    if (!kernelHandles) {
        status = CUDA_ERROR_OUT_OF_MEMORY;
        goto Error;
    }
    memset(kernelHandles, 0, sizeof(CUkernelMemcpyGF100));
    ctx->kernelmemcpy.fermi = kernelHandles;

    // Load built-in module
    cuiSetDefaultCompilerOptions(&compileData);
    cubin = cuiGetBIKCubin(
        allCubins_gf100_kernel_memcpy,
        ctx->device->state.major,
        ctx->device->state.minor);
    CU_ASSERT(cubin);

    status = cuiModuleLoadData(
        ctx, 
        &kernelHandles->mod,
        cubin,
        NULL, 
        &compileData,
        ctx->api);
    if (CUDA_SUCCESS != status) {
        CU_DEBUG_PRINT(("Failed to load memcpy cubin.\n"));
        goto Error;
    }

    // 1D Device-Device
    LOAD_FUNCTION(status, kernelHandles, memcpy128);
    LOAD_FUNCTION(status, kernelHandles, memcpy128_unaligned);
    LOAD_FUNCTION(status, kernelHandles, memcpy_post);
    LOAD_FUNCTION(status, kernelHandles, memcpy_pre_post);
    LOAD_FUNCTION(status, kernelHandles, memcpy32_post);
    LOAD_FUNCTION(status, kernelHandles, memcpy_post_faster);
    return status;

Error:
    gf100KernelMemcpy1DDestroy(ctx);
    return status;
}

void gf100KernelMemcpy1DDestroy(CUctx *ctx)
{
    CUkernelMemcpyGF100 *kernelHandles;

    CU_TRACE_FUNCTION();
    CU_ASSERT(ctx);

    kernelHandles = ctx->kernelmemcpy.fermi;
    if (kernelHandles) {
        if (kernelHandles->mod) {
            cuiModuleUnload(kernelHandles->mod);
            kernelHandles->mod = NULL;
        }
        free(kernelHandles); 
        ctx->kernelmemcpy.fermi = NULL;
    }
}
