/*
 * Copyright 1993-2016 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

/******************************************************************************
*
*   Module: cuda_defines.h
*
*   Description:
*       Internal defines for compute driver architecture.
*
******************************************************************************/

#ifndef __cuda_defines_h__
#define __cuda_defines_h__

#include <g_nvconfig.h>
#if NVCFG(GLOBAL_ARCH_KEPLER)
#include "class/cla06fsubch.h"
#endif

#include "cuda_platform.h"

#if cuiPlatformIncludesWddm()
#include "nvLDDMKmode.h"  //contains defines for subchannels
#endif

#define CU_AMODEL_HANDLE_POOL_SIZE  DIRECTAMODEL_MAX_CHANNELS

#define CU_INTERRUPT_TIMEOUT                           1000

// Enum for different device targets supported by the Cuda driver
typedef enum CUdevtarget {
    CU_DEVICE_TARGET_AMODEL = 0,
    CU_DEVICE_TARGET_SILICON,
    CU_DEVICE_TARGET_FMODEL, // Not yet supported
    CU_DEVICE_TARGET_EMULATION,
    CU_DEVICE_TARGETS
} CUdevtarget;

typedef enum {
    CU_WORK_DISTRIBUTION_DEFAULT = 0,
    CU_WORK_DISTRIBUTION_ROUND_ROBIN,
    CU_WORK_DISTRIBUTION_DYNAMIC,
    CU_WORK_DISTRIBUTION_LAST
} CUworkDistributionMode;

// Flags for launch resource finalization in the HAL
#define CU_LAUNCH_FINALIZE_SKIP_BINDLESS_BANKS     0x1
#define CU_LAUNCH_FINALIZE_FORCE_SEMA_RED_ADD      0x2

// This the max number of rm handles outstanding by
// the driver.  Currently this is arbirarily set.
// We need a lot of handles for UVA reservations on systems
// with a lot of RAM and GPUs. 1M handles should be pretty safe:
// ~1 TB of RAM / 128MB VA chunks * 16 GPUS -> 128K handles
// TODO we should make the pool dynamically sized
#define CU_HANDLE_POOL_SIZE (1024 * 1024)
// This is the prefix for the handles in the RM handle pool
// used by RM and Amodel
#define CU_HANDLE_POOL_PREFIX 0x5C000000

#define DIRECTAMODEL_FLUSH_LOG_PAYLOAD 0x4321

// Class handles for Amodel channels
#define DIRECTAMODEL_COMPUTE_OBJECT 0x0a0d0004
#define DIRECTAMODEL_MEMORY_TO_MEMORY_OBJECT 0x0a0d0005
#define DIRECTAMODEL_TWOD_OBJECT 0x0a0d0006
#define DIRECTAMODEL_COPY_ENGINE_OBJECT 0xa0d0007

#define DIRECTAMODEL_MAX_CHANNELS 512

// This is arbitrary but is used to statically allocate the number of attributes
// we may need at runtime. May be increased if more attributes are required.
#define DIRECTAMODEL_MAX_SURFACE_ATTRIBUTES 9

/* Subchannels */
#if defined(WINLH)

#define CU_SUBCHANNEL_DMA        NV_D3D_SUBCH_DMA_COPY
#define CU_SUBCHANNEL_COMPUTE    NV_DD_SUBCH_COMPUTE
#define CU_SUBCHANNEL_CE         NV_D3D_SUBCH_DMA_COPY
#define CU_SUBCHANNEL_MEM2MEM    NV_D3D_SUBCH_MEMTOMEM
#define CU_SUBCHANNEL_TWOD       NV_D3D_SUBCH_TWOD

#else //!WINLH

#define CU_SUBCHANNEL_DMA        0x0 // Here to avoid further abuse of the push macros
#define CU_SUBCHANNEL_COMPUTE    0x2
#define CU_SUBCHANNEL_CE         0x5
#define CU_SUBCHANNEL_MEM2MEM    0x3
#define CU_SUBCHANNEL_TWOD       0x4

#endif  //WINLH

#if NVCFG(GLOBAL_ARCH_KEPLER)
#define CU_SUBCHANNEL_KEPLER_COMPUTE NVA06F_SUBCHANNEL_COMPUTE
#define CU_SUBCHANNEL_KEPLER_CE      NVA06F_SUBCHANNEL_COPY_ENGINE
#endif

#if NVCFG(GLOBAL_ARCH_MAXWELL)
#define CU_SUBCHANNEL_MAXWELL_COMPUTE NVA06F_SUBCHANNEL_COMPUTE
#define CU_SUBCHANNEL_MAXWELL_CE      NVA06F_SUBCHANNEL_COPY_ENGINE
#endif

#if NVCFG(GLOBAL_ARCH_PASCAL)
#define CU_SUBCHANNEL_PASCAL_COMPUTE NVA06F_SUBCHANNEL_COMPUTE
#define CU_SUBCHANNEL_PASCAL_CE      NVA06F_SUBCHANNEL_COPY_ENGINE
#endif

#if NVCFG(GLOBAL_ARCH_VOLTA)
#define CU_SUBCHANNEL_VOLTA_COMPUTE NVA06F_SUBCHANNEL_COMPUTE
#define CU_SUBCHANNEL_VOLTA_CE      NVA06F_SUBCHANNEL_COPY_ENGINE
#endif

#if NVCFG(GLOBAL_ARCH_TURING)
#define CU_SUBCHANNEL_TURING_COMPUTE NVA06F_SUBCHANNEL_COMPUTE
#define CU_SUBCHANNEL_TURING_CE      NVA06F_SUBCHANNEL_COPY_ENGINE
#endif

#if NVCFG(GLOBAL_ARCH_AMPERE)
#define CU_SUBCHANNEL_AMPERE_COMPUTE NVA06F_SUBCHANNEL_COMPUTE
#define CU_SUBCHANNEL_AMPERE_CE      NVA06F_SUBCHANNEL_COPY_ENGINE
#endif

// These defines map classes to subchannels defined above.
#if NVCFG(GLOBAL_ARCH_FERMI)
#define CU_CLASS_90C0       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_COMPUTE) // FERMI_COMPUTE_A
#define CU_CLASS_91C0       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_COMPUTE) // FERMI_COMPUTE_B
#define CU_CLASS_906F       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_DMA)     // GF100_CHANNEL_GPFIFO
#define CU_CLASS_9039       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_MEM2MEM) // Fermi MEM2MEM class
#define CU_CLASS_902D       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_TWOD)    // Fermi TWOD class
#define CU_CLASS_90B5       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_CE)      // Fermi CopyEngine
#endif
#if NVCFG(GLOBAL_ARCH_KEPLER)
#define CU_CLASS_A0C0       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_KEPLER_COMPUTE) // KEPLER_COMPUTE_A
#define CU_CLASS_A1C0       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_KEPLER_COMPUTE) // KEPLER_COMPUTE_B
#define CU_CLASS_A0B5       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_KEPLER_CE)      // Kepler CopyEngine
#define CU_CLASS_A06F       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_DMA)            // Kepler GPFIFO (Host)
#define CU_CLASS_A16F       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_DMA)            // Kepler GPFIFO (Host)
#define CU_CLASS_A26F       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_DMA)
#endif
#if NVCFG(GLOBAL_ARCH_MAXWELL)
#define CU_CLASS_B0C0       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_MAXWELL_COMPUTE) // MAXWELL_COMPUTE_A
#define CU_CLASS_B1C0       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_MAXWELL_COMPUTE) // MAXWELL_COMPUTE_B
#define CU_CLASS_B0B5       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_MAXWELL_CE)      // Maxwell CopyEngine
#define CU_CLASS_B06F       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_DMA)             // Maxwell GPFIFO (Host)
#endif
#if NVCFG(GLOBAL_ARCH_PASCAL)
#define CU_CLASS_C0C0       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_PASCAL_COMPUTE)  // PASCAL_COMPUTE_A
#define CU_CLASS_C1C0       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_PASCAL_COMPUTE)  // PASCAL_COMPUTE_B
#define CU_CLASS_C0B5       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_PASCAL_CE)       // Pascal CopyEngine
#define CU_CLASS_C06F       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_DMA)             // Pascal GPFIFO (Host)
#endif
#if NVCFG(GLOBAL_ARCH_VOLTA)
#define CU_CLASS_C3C0       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_VOLTA_COMPUTE)  // VOLTA_COMPUTE_A
#define CU_CLASS_C3B5       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_VOLTA_CE)       // Volta CopyEngine
#define CU_CLASS_C36F       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_DMA)            // Volta GPFIFO (Host)
#endif
#if NVCFG(GLOBAL_ARCH_TURING)
#define CU_CLASS_C5C0       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_TURING_COMPUTE) // TURING_COMPUTE_A
#define CU_CLASS_C5B5       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_TURING_CE)      // Turing CopyEngine
#define CU_CLASS_C46F       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_DMA)            // Turing GPFIFO (Host)
#endif
#if NVCFG(GLOBAL_ARCH_AMPERE)
#define CU_CLASS_C6C0       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_AMPERE_COMPUTE) // AMPERE_COMPUTE_A
#define CU_CLASS_C7C0       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_AMPERE_COMPUTE) // AMPERE_COMPUTE_B
#define CU_CLASS_C6B5       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_AMPERE_CE)      // Ampere CopyEngine (placeholder)
#define CU_CLASS_C56F       CU_CLASS_ENCODE(1,CU_SUBCHANNEL_DMA)            // Ampere GPFIFO (Host, placeholder)
#endif


#define CU_MAX_CONST_POOLS             8 // Max const banks of any HW class we support
#define CU_INVALID_CONST_BANK          0xFFFFFFFF

// XXX: These NV50 defines should be properly HAL-ified
#define CU_NV50_NUM_GMEM_REGIONS       16

#define CU_NV50_TEXHDR_SIZE_DWORDS     8
#define CU_NV50_TEXSAMPLER_SIZE_DWORDS 8

#define CU_SURFHDR_SIZE_BYTES          32
#define CU_SURFDESC_SIZE_BYTES         28
#define CU_SURFHDR_SIZE_DWORDS         8

// Enum for indexing locally cached function memory
typedef enum CUlocallyCachedCodeData {
    CU_CODE_DATA_MASTER = 0,
    CU_CODE_DATA_TEMP,
    CU_CODE_DATA_ORIGINAL,
    CU_CODE_DATA_MAX
} CUlocallyCachedCodeData;

// Enum for the async memcpy engine types supported by the driver
typedef enum CUasyncEngineTypes {
    CU_ASYNC_ENGINE_NONE = 0,
    CU_ASYNC_ENGINE_CE
} CUasyncEngineTypes;

// Enum for clocks supported by the driver
typedef enum CUclockDomains {
    CU_CLK_GRAPHICS = 0,
    CU_CLK_MEMORY,
    CU_CLK_MAX
} CUclockDomains;

// Default value for the clock when it is not possible to query it
#define CU_CLK_DEFAULT_PROCESSOR_VALUE   0x100000; // 1GHz
#define CU_CLK_DEFAULT_MEMORY_VALUE      0x100000; // 1GHz

#define CU_FUNC_MEM_RANGE_SIZE        0x100000000ULL

// Maximum amount to memcpy via memcpy1D HAL entry point per push buffer submission
#define CU_MEMCPY_MAXSIZE_1D    ((size_t) 0x20000000)

#define CU_PRI_REG_CONTEXT      0x1
#define CU_PRI_REG_GLOBAL       0x2
#define CU_PRI_REG_CONTEXT_QUAD 0x3

#define ENABLE_REGISTER_LOGGING 0

//Driver instrumentation
#define CUDA_INSTRUMENT_DRIVER 0
enum CUinstrumentType
{
    CU_INSTRUMENT_GLOBAL_TIMER     = 1,
    CU_INSTRUMENT_UNKNOWN          = 9999
};

// Number of bytes below which we should use inline memcpy for HtoD
#define CU_INLINEHTOD_THRESHOLD 0x10000

// The texture header/sampler mode the module is using
typedef enum CUtextureHeaderSamplerMode
{
    CU_TEX_HEADER_SAMPLER_INVALID  = 0,
    CU_TEX_HEADER_SAMPLER_COMBINED = 1,
    CU_TEX_HEADER_SAMPLER_SEPARATE = 2
} CUtextureHeaderSamplerMode;

// PM trigger payloads for perfsim
#define CU_PM_TRIGGER_BEGIN 0x40000000
#define CU_PM_TRIGGER_END   0x80000000

// Maximum size in bytes of the syscall data that lives in the syscall const
// bank. Care needs to be taken to ensure this is large enough for both 32bit
// and 64bit configurations.
#define CU_SYSCALL_MAX_CONST_SIZE 2048

#define CU_DEFAULT_REG_PATH     "SOFTWARE\\NVIDIA Corporation\\Global\\CUDA"

// Number of environment "registers" in env const bank (for OpenCL)
#define CU_FUNC_NUM_ENV_VALUES 32

// Directory and path separators for Windows versus everything else
#if defined(_WIN32)
  #define CU_DIR_SEP  '\\'
  #define CU_PATH_SEP ';'
#else
  #define CU_DIR_SEP  '/'
  #define CU_PATH_SEP ':'
#endif

#define CU_SUPPORT_TEXTURE_3D_ALTERNATE 1

// ELF reloc fields, from nvelf.h. The NV_ prefix is required to make the
// various DRF macros work.
#define NV_R_CUDA_ABS32_26              57:26 // Requires using 64-bit DRF macros.
#define NV_R_CUDA_ABS32_23              54:23 // Requires using 64-bit DRF macros.
#define NV_R_CUDA_ABS32_20              51:20 // Requires using 64-bit DRF macros.
#define NV_R_CUDA_ABS32_32              63:32 // Requires using 64-bit DRF macros.
#define NV_R_CUDA_ABS47_34_LO           63:34 // Requires using 64-bit DRF macros.
#define NV_R_CUDA_ABS47_34_HI           16:0  // Requires using 64-bit DRF macros.
#define NV_R_CUDA_TEX_HEADER_INDEX      19:0  // See nvelf.h
#define NV_R_CUDA_SAMP_HEADER_INDEX     31:20 // See nvelf.h
#define NV_R_CUDA_SURF_HEADER_INDEX     19:0  // See nvelf.h

// The smallest page size supported by all GPUs is 4K
#define CU_DEVICE_SMALLEST_PAGE_SIZE    0x1000ULL

#ifdef _WIN32
#if _MSC_VER < 1900
#define snprintf _snprintf
#endif
#endif

// Shared and local memory windows
#define CU_GTAS_WINDOW_ALIGN 0x1000000    // 16MB
#define CU_GTAS_WINDOW_SIZE  0x1000000    // 16MB
#define CU_GTAS_BUFFER_SIZE  0x1000000    // 16MB

#define CU_GTAS_WINDOWS_ALLOC_SIZE (2 * CU_GTAS_WINDOW_SIZE + 3 * CU_GTAS_BUFFER_SIZE)

// Profiler class scope
typedef enum CUprofilerClassScope
{
    CU_PROFILER_CLASS_SCOPE_INVALID  = 0,
    CU_PROFILER_CLASS_SCOPE_GLOBAL   = 1,
    CU_PROFILER_CLASS_SCOPE_CONTEXT  = 2,
} CUprofilerClassScope;

#define CU_PROFILER_CLASS_CMD_RESERVE  1
#define CU_PROFILER_CLASS_CMD_RELEASE  2

// Mps Defines
#define CU_MPS_LEGACY_MAX_CLIENT_CONTEXTS                16
#define CU_MPS_MAX_CLIENT_CONTEXTS                       48
#define CU_MPS_CLIENT_COMPUTE_CHANNEL_POOL_SIZE  2
#define CU_MPS_CLIENT_ASYNC_CHANNEL_POOL_SIZE    2

#endif /*__cuda_defines_h__*/

