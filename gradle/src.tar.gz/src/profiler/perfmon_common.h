/*
 * Copyright 2011 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

#ifndef __PERFMON_COMMON_H__
#define __PERFMON_COMMON_H__

CUprofResult perfmonInitEventDomainData(CUprof_EventDomainID eventDomain);
CUprofResult perfmonGetEventDomainData(CUprof_EventDomainID eventDomain,
                                       CUdomainData **pDomainData_out,
                                       NvBool *bFound);
CUprofResult perfmonGetSignalDesc(CUprof_EventID eventId,
                                  SignalDescriptionTable **pSignalDesc_out,
                                  NvBool *bFound);
CUprofResult perfmonGetSizeOfSignalTableEntry(CUPerfSignalTableType signalTableType,
                                  NvU32 *size);

void perfmonDemangleStrings (void);
int perfmonInternalCountersExposed (void);
int perfmonPmCtxswEnabled (void);
int perfmonCssDisabled (void);
CUprofResult setupStreamingResources(CUcontext ctx);
CUprofResult cleanupStreamingResources(CUcontext ctx);

#endif // __PERFMON_COMMON_H__
