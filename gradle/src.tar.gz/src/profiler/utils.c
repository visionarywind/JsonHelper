/*
 * Copyright 1993-2009 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

/******************************************************************************
*
*   Module: utils.c
*
*   Description:
*       utility routines implementation
*
******************************************************************************/

#include "utils.h"
#include "cuos.h"

/******************************************************
* Generic linked list implementation
*******************************************************/

// init the linked list
CUresult listInit(CUlistHeader **hdr,  
              CUresult (*addToHead)(CUlistHeader *hdr, void *data),
              CUresult (*addToTail)(CUlistHeader *hdr, void *data),
              CUresult (*remFrom)  (CUlistHeader *hdr, void *data),
              NvBool (*compareData)(const void *data1, const void *data2))
{
    CUresult status = CUDA_SUCCESS;
    CUlistHeader *header = NULL;
    
    header = (CUlistHeader*)malloc(sizeof(CUlistHeader));
    if (header == NULL) {
        return CUDA_ERROR_OUT_OF_MEMORY;
    }
    memset(header, 0, sizeof(*header));

    header->addToHead   = addToHead;
    header->addToTail   = addToTail;
    header->remFrom     = remFrom;
    header->compareData = compareData;
    
    *hdr = header;

    return status;
}

CUresult listRemoveAllNodes(CUlistHeader *hdr)
{
    CUresult status = CUDA_SUCCESS;
    CUnode *currNode = NULL;
    CUnode *nextNode = NULL;

    if (!hdr) {
        return CUDA_ERROR_INVALID_HANDLE;
    }

    currNode = hdr->head;

    while (currNode) {
        nextNode = currNode->next;
        free (currNode);
        currNode = nextNode;
    }
    hdr->head = NULL;
    hdr->tail = NULL;
    hdr->numElements = 0;

    return status;
}

// destroy the list
CUresult listDestroy(CUlistHeader *hdr)
{
    CUresult status = CUDA_SUCCESS;

    status = listRemoveAllNodes(hdr);
    if (status != CUDA_SUCCESS) {
        return status;
    }

    free (hdr);
    hdr = NULL;

    return status;
}

// generic function to remove node from the head of the list
CUresult listGenericRemNodeFromHead(CUlistHeader *hdr, void **data)
{
    CUresult status = CUDA_SUCCESS;
    CUnode *node = NULL;

    if (!(hdr && data)) {
        return CUDA_ERROR_INVALID_HANDLE;
    }

    if ((hdr->head) && (hdr->head == hdr->tail)) {
        *data = hdr->head->data;
        free (hdr->head);
        hdr->head = hdr->tail = NULL;
        hdr->numElements--;
    } 
    else if (hdr->head) {
        node = hdr->head;
        hdr->head = hdr->head->next;
        *data = node->data;
        free (node);
        hdr->numElements--;
    }
    else {
        *data = NULL;
    }

    return status;
}

// add node at the head of the list
CUresult listAddToHead(CUlistHeader *hdr, void *data) 
{
    if (!(hdr && data)) {
        return CUDA_ERROR_INVALID_HANDLE;
    }

    if (hdr->addToHead != NULL) {
        // Call custom function
        return hdr->addToHead(hdr, data); 
    }
    else {
        // Call generic function
        return listGenericAddToHead(hdr, data);
    }
}

// add node at the tail of the list
CUresult listAddToTail(CUlistHeader *hdr, void *data)
{
    if (!(hdr && data)) {
        return CUDA_ERROR_INVALID_HANDLE;
    }

    if (hdr->addToTail != NULL) {
        // Call custom function
        return hdr->addToTail(hdr, data); 
    }
    else {
        // Call generic function
        return listGenericAddToTail(hdr, data);
    }
}

// generic function to add node at the head of the list
static CUresult listGenericAddToHead(CUlistHeader *hdr, void *data)
{
    CUresult status = CUDA_SUCCESS;
    CUnode *node = NULL;

    if (!(hdr && data)) {
        return CUDA_ERROR_INVALID_HANDLE;
    }

    node = (CUnode*)malloc(sizeof(CUnode));
    if (node == NULL) {
        return CUDA_ERROR_OUT_OF_MEMORY;
    }

    node->data = data;
    node->next = NULL;

    if (hdr->head) {
        node->next = hdr->head;
        hdr->head = node;
    }
    else {
        hdr->head = hdr->tail = node;
    }

    hdr->numElements++;

    return status;
}

// generic function to add node at the tail of the list
static CUresult listGenericAddToTail(CUlistHeader *hdr, void *data)
{
    CUresult status = CUDA_SUCCESS;
    CUnode *node = NULL;

    if (!(hdr && data)) {
        return CUDA_ERROR_INVALID_HANDLE;
    }

    node = (CUnode*)malloc(sizeof(CUnode));
    if (node == NULL) {
        return CUDA_ERROR_OUT_OF_MEMORY;
    }

    node->data = data;
    node->next = NULL;

    if (hdr->tail) {
        hdr->tail->next = node;
        hdr->tail = node;
    }
    else {
        hdr->head = hdr->tail = node;
    }

    hdr->numElements++;

    return status;
}

// remove the node containing the data from the list
CUresult listRemFrom(CUlistHeader *hdr, void *data) 
{
    if (!(hdr && data)) {
        return CUDA_ERROR_INVALID_HANDLE;
    }

    if (hdr->remFrom != NULL) {
        // Call custom function
        return hdr->remFrom(hdr, data); 
    }
    else {
        // Call generic function
        return listGenericRemFrom(hdr, data);
    }
}

// generic function to remove the node containing the data from the list
static CUresult listGenericRemFrom(CUlistHeader *hdr, void *data)
{
    CUnode *currNode = NULL;
    CUnode *prevNode = NULL;

    if (!(hdr && data)) {
        return CUDA_ERROR_INVALID_HANDLE;
    }

    currNode = hdr->head;

    while (currNode && (currNode->data != data)) {
        prevNode = currNode;
        currNode = currNode->next;
    }
    if (currNode) {
        if (currNode == hdr->head) {
            hdr->head = hdr->head->next;
        }
        if (currNode == hdr->tail) {
            hdr->tail = prevNode;
        }
        if (prevNode) {
            prevNode->next = currNode->next;
        }

        free (currNode);

        hdr->numElements--;
    }

    return CUDA_SUCCESS;
}

// find the node containing the data and return pointer to it
void* listFind(CUlistHeader *hdr, void *data)
{
    CUnode *node = NULL;

    if (!(hdr && data)) {
        return NULL;
    }

    node = hdr->head;

    while (node) {
        if (hdr->compareData(node->data, data) == 1) {
            return (void*)node->data;
        }
        node = node->next;
    }

    // return NULL if not found 
    return NULL;
}

// remove the node containing the data from the list
void* listDataRemFrom(CUlistHeader *hdr, void *data)
{
    CUnode *currNode = NULL;
    CUnode *prevNode = NULL;
    void *ret = NULL;

    if (!(hdr && data)) {
        return NULL;
    }

    currNode = hdr->head;

    while (currNode) {
        if (hdr->compareData(currNode->data, data) == 1) {
            break;
        }
        prevNode = currNode;
        currNode = currNode->next;
    }

    if (currNode) {
        if (currNode == hdr->head) {
            hdr->head = hdr->head->next;
        }
        if (currNode == hdr->tail) {
            hdr->tail = prevNode;
        }
        if (prevNode) {
            prevNode->next = currNode->next;
        }

        ret = currNode->data;

        free (currNode);

        hdr->numElements--;
    }

    return ret;
}

// function to get next node from the list
void* listGetNext(CUlistHeader *hdr, void **nodeBase)
{
    CUnode *node = NULL;

    if (hdr) {
        *nodeBase = (void*)hdr->head;
    }

    node = *(CUnode**)nodeBase;
    if (node == NULL) {
        return NULL;
    }

    // move current node ahead
    *nodeBase = (void*)node->next;

    return (void*)node->data;
}

// return pointer to node located at given index
void* listAtIndex(CUlistHeader *hdr, const size_t index)
{
    CUnode *node = NULL;
    size_t i = 0;

    if (!(hdr && hdr->head)) {
        return NULL;
    }

    node = hdr->head;

    while (node && i < index) {
        node = node->next;
        ++i;
    }

    if (!node) {
        return NULL;
    }
    else {
        return (void*)node->data;
    }
}

// length (num of nodes) of the list
size_t listLen(CUlistHeader *hdr)
{
    if (hdr) {
        return hdr->numElements;
    }
    else {
        return 0;
    }
}
