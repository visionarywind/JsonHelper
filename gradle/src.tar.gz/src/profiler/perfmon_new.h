/*
* Copyright 2009 by NVIDIA Corporation.  All rights reserved.  All
* information contained herein is proprietary and confidential to NVIDIA
* Corporation.  Any use, reproduction, or disclosure without the written
* permission of NVIDIA Corporation is prohibited.
*/

/******************************************************************************
*
*   Module: perfmon_new.h
*
*   Description:
*       Performance monitor support in compute driver architecture.
*
******************************************************************************/

/* As per the requirement following changes are made in the existing design:
* Clock domain tables (TeslaClockDomainId<arch>) are self-contained now in place of common + device specific tables
* Add domain data tables for each arch containing domain name and other info which is going be exposed to third party
* Perf Signal Table -
  a) Perf signal table will now be device specific only, remove common table/s
  b) Have different perf signals for different clock domains
  c) differentiate between external and internal signals using a prefix
  d) Add SM signals to perf signal tables
* Array of perf signal table for all archs (PerfSignalTable *pPerfSignalArray<arch>)
  it helps us in parsing as well as we know what all domains are exposed.
* Addition of generic linked list to ease the task on maintaining the lists of event groups and event data, 
  Also it helps in removing the duplication of like code for different data types.
* Add a pointer to struct in context which helps in tracking of event groups. This struct may contain other data also if required.
* typedef PerfSignalTable CUEventData it helps in reducing the memory footprint as well as we have access to all attributes of the event (signal).
* teslaperfmonControl() to control PM HW
* lookupDomainSignalTable() to lookup signals in a apecific domain. Earlier we had similar function for entire perf signal table.
* teslaPerfmonTryAddingCounter() removed code patching stuff
* teslaPerfmonInit() removed pm init stuff
* teslaPerfmonDestroy() - !teslaPerfmon1Init()
* Forced to adapt the use of pm struct, I tried to avoid it and rely on event data list instead but 
  I landed up in rewriting the core functions again which is very risky at this point of time.
* We now have pm associated with each event group
*/


#ifndef __PERFMON_NEW_H__
#define __PERFMON_NEW_H__

#include <string.h>
#include <ctype.h>

#include "cuos.h"
#include "Nvcm.h"
#include "utils.h"
#include "perfmon.h"
#include "cuprofiler.h"
#include "cuimutex.h"

#if cuiPlatformIncludesMrm()
#include "nvrm_all.h"
#endif

//Enable when http://nvbugs/1259185 is fixed in RM
//#define BUG_1259185_FIXED

//Timeout in ms for sampling feature
#define SAMPLING_TIMEOUT 1

#if !defined(START_PACKED_ALIGNMENT)
#if defined(_WIN32) // Windows 32- and 64-bit
#define START_PACKED_ALIGNMENT __pragma(pack(push,1)) // exact fit - no padding
#define PACKED_ALIGNMENT __declspec(align(1))
#define END_PACKED_ALIGNMENT __pragma(pack(pop))
#elif defined(__GNUC__) // GCC
#define START_PACKED_ALIGNMENT
#define PACKED_ALIGNMENT __attribute__ ((__packed__)) __attribute__ ((aligned (1)))
#define END_PACKED_ALIGNMENT
#else // all other compilers
#define START_PACKED_ALIGNMENT
#define PACKED_ALIGNMENT
#define END_PACKED_ALIGNMENT
#endif
#endif

#define COUNTER_MAX32BIT    0xFFFFFFFFU
#define COUNTER_MAX64BIT    0xFFFFFFFFFFFFFFFFULL

#define FERMI_MAX_SW_COUNTER_PER_EVENTGROUP  8
#define KEPLER_MAX_SW_COUNTER_PER_EVENTGROUP 4
#define MAXWELL_MAX_SW_COUNTER_PER_EVENTGROUP 4
#define PASCAL_MAX_SW_COUNTER_PER_EVENTGROUP 4
#define MAX_SIGNAL_TABLES_PER_DOMAIN 8
#define MAX_DOMAINS 16
#define PM_INTERNAL_SIGNAL_PREFIX        "__"
#define INTERNAL_EVENT_DESCRIPTION       "internal event"
#define INVALID_PM_SIGNAL_NEW ((NvU32)-1)
#define INVALID_SW_COUNTER    ((NvU32)-1)
#define INVALID_DOMAIN_ID     -1

#define CLOCKS_PER_STREAMING_RECORD_FROM_ROUTER_TO_PMA_ON_PRI    24
#define SIZE_OF_STREAMING_RECORD                32
#define SIZE_OF_STREAMING_RECORD_PAYLOAD        28
// max time between flusing PC Sampling records in ms
#define MAX_PC_SAMPLING_FLUSH_TIME_MS           34
//set minimum period allowed by HW - 32 = 2^(0+5)
#define MIN_SAMPLING_PERIOD 0
//set maximum period that is useful to the end users - 4096 = 2^(7+5)
#define MAX_SAMPLING_PERIOD 7
#define MAX_DROPPED_COUNT ((1<<14)-1)
// Define to protect the NVLINK PM changes
#define NVLINK_PM  0

// Read Mask to read value using CTRL CALL NV90CC_CTRL_CMD_HWPM_MODE_B_TRIGGER
#define HWPM_MODE_B_TRIGGER_READ_MASK 0xFF

#define PROF_COMPUTE_LOG2(out,x)              \
    do {                                 \
        NvU32 i, j;                      \
        for (i=0, j=(x); (j>>1); i++) {  \
            j = j >> 1;                  \
        }                                \
        (out) = i;                       \
    } while(0)

// various flags
typedef enum CUpmFlags_enum {
    CU_PM_FLAG_FALCON_05_METHOD         = 1<<0
    // add other flags, each having unique slot (bit)
}CUpmFlags;

typedef enum CUPerfSignalType_enum {
    PERF_SIG_TABLE_TYPE_COMMON,
    PERF_SIG_TABLE_TYPE_SMPC,
    PERF_SIG_TABLE_TYPE_HWPM,
    PERF_SIG_TABLE_TYPE_LUT,
    PERF_SIG_TABLE_TYPE_HWPM_EXPT,
    PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1,
    PERF_SIG_TABLE_TYPE_HWPM_VIRTUAL_EXPT,
    PERF_SIG_TABLE_TYPE_HWPMMUX,
    PERF_SIG_TABLE_TYPE_NVLINK,
    PERF_SIG_TABLE_TYPE_MULTI_GROUP,
    PERF_SIG_TABLE_TYPE_NVLINK_THROUGHPUT_CNTR,
    PERF_SIG_TABLE_TYPE_SMPC_EXPERIMENT,
    PERF_SIG_TABLE_TYPE_CUPTI_SW, // Volta+ chips have SW counter fully
                                  // implemented in CUPTI
} CUPerfSignalTableType;

typedef struct PerfSignalTableBasic_st
{
    NvU32 signalId;                         // signal ID
    const char *pSignalName;                // signal name for CUDA/OpenCL
}PerfSignalTableBasic;

typedef struct PerfSignalTableNew_st
{
    NvU32 signalId;                         // signal ID
    const char *pSignalName;                // signal name for CUDA/OpenCL
    NvU32 eventGroup;                       // signal event-group
    NvU32 perfEvent;                        // signal perf-event
    NvU32 function;                         // signal function combination
    NvU32 watchBus;                         // watchbus
    NvU32 clockDomain;                      // clock domain
    NvU32 pmUnitId;                         // PM unit Id - SM, SMC, TEX, FB etc
    NvBool busSelBits[SIG_MAX_BUS_WIDTH];   // array of bus selection bits
    NvU32 sigType;                          // single signal or combination of multiple signals
    NvU32 chipletType;                      // chiplet type - SYS, GPC, FBP 
    NvU32 eventGroup1;                      // This is specifically added for tex signals for GF10x
    NvU32 isExpt;                           // Singnifies that a counter requires more than 1 event to be profiled.
    NvU32 functionExpt;                     // function required for the extra signal to be configured for experiment
    NvU32 watchBusExpt;                     // watchbus required for the extra signal to be configured for experiment
    //event group can be a combination of all groups required to get the experiemnt profiled, this should override the earlier event group.
    NvU32 eventGroupExpt;                   // event group required for the extra signal to be configured for experiment
    NvU32 eventGroupMaskExpt;               // unit id required for the extra signal to be configured for experiment
    NvU32 instanceSelectExpt;               // used to set the instance selected in all event groups
}PerfSignalTableNew;

typedef struct PerfSignalHwpm_st
{
    NvU32 signalId;                         // signal ID
    const char *pSignalName;                // signal name for CUDA/OpenCL
    NvU32 eventGroup;                       // signal event-group
    NvU32 function;                         // signal function combination
    NvU32 watchBus;                         // watchbus
    NvU32 pmUnitId;                         // PM unit Id - SM, SMC, TEX, FB etc
    NvU32 busWidth;                         // array of bus selection bits
    NvU32 eventGroup1;                      // This is specifically added for tex signals for GF10x
    //2nd level mux still required for tex. TBD can create separate table for this
    NvU32 pmUnitId1;                         // PM unit Id - SM, SMC, TEX, FB etc
    //TBD mode can be removed, if it needs to be kept, need to check mode overriding via table works properly.
    NvU32 mode;                             // New mode field added to select from various mode.
    //In this table mode can be either INCR, 4444, event4/6, vivek
}PerfSignalHwpm;

typedef struct PerfSignalNvLink_st
{
    NvU32 signalId;                         // signal ID
    char *pSignalName;                      // signal name for CUDA/OpenCL
    NvU32 eventGroup;                       // signal event-group o be set in NV_IOCTRL_PERFMON_M1_SEL
    NvU32 function;                         // signal function combination
    NvU32 watchBus;                         // watchbus
    NvU32 pmUnitId;                         // PM unit Id - SM, SMC, TEX, FB etc
    NvU32 busWidth;                         // array of bus selection bits
    NvU32 instance;                          // NV_IOCTRL_PERFMON_SELECT_M2SEL0-3
    NvU32 m1mode;                            // incr counter at every cycle or on data change
    NvU32 m3mode;                            // 1:1 or 2:1 mode
    //In this table mode can be either INCR, 4444, event4/6, vivek
}PerfSignalNvLink;

typedef struct PerfSignalHwpmMux_st
{
    NvU32 signalId;                         // signal ID
    const char *pSignalName;                // signal name for CUDA/OpenCL
    NvU32 eventGroup;                       // signal event-group
    NvU32 function;                         // signal function combination
    NvU32 watchBus;                         // watchbus
    NvU32 pmUnitId;                         // PM unit Id - SM, SMC, TEX, FB etc
    NvU32 busWidth;                         // array of bus selection bits
    NvU32 startPos;                         // Start position in the SMPM group required for HWPMMux
}PerfSignalHwpmMux;

typedef struct PerfSignalHwpmExpt_st
{
    NvU32 signalId;                         // signal ID
    const char *pSignalName;                // signal name for CUDA/OpenCL
    NvU32 signalId_increment;               // Gives signal ids which will be used to increment.
    NvU32 signalId_combination[7];          // In HWPM, we can have signal id combination for upto 7 signals.
    NvU32 function;                         // signal function combination 
                                            // TBD find out how to use signal combination for > 4 signals
    NvU32 mode;                             // New mode field added to select from various mode 
                                            // (can ideally be set depending on the combinationa and increment).
    NvU8 dSel;                              // Delay signal select for HWPM expts
                                            // Check bits 16-20 in NV_PERF_PMMGPC_SAMPLE_OP_FUNC for reference.
    //Ideally this table should be split and two new tables should be added to support new signals for supporting 
    //combination of signals for modes 2X4B4I, trig 4/6.
}PerfSignalHwpmExpt;

//Mode is not used so removing in pascal
typedef struct PerfSignalHwpmExpt_v1_st
{
    NvU32 signalId;                         // signal ID
    const char *pSignalName;                // signal name for CUDA/OpenCL
    NvU32 signalId_increment;               // Gives signal ids which will be used to increment.
    NvU32 signalId_combination[7];          // In HWPM, we can have signal id combination for upto 7 signals.
    NvU32 function;                         // signal function combination 
                                            // TBD find out how to use signal combination for > 4 signals
    NvU32 signalId_filter;                  // signal ID for sideband filtering
    NvU8 dSel;                              // Delay signal select for HWPM expts
                                            // Check bits 16-20 in NV_PERF_PMMGPC_SAMPLE_OP_FUNC for reference.
    NvU32 mode;                             // Only NV_PMM_CONTROL_ADDTOCTR_4444 will be honored, other mode will be ignored.
}PerfSignalHwpmExpt_v1;

typedef enum CUPerfSignalVirtualValue_enum {
    PERF_SIG_VALUES_INVALID,
    PERF_SIG_VALUES_INTERLEAVE,
    PERF_SIG_VALUES_REPEAT,
} CUPerfSignalVirtualValue;


//For SM virtualization in Pascal, we need to interleave the values of 2 halves of SM.
typedef struct PerfSignalHwpmVirtualExpt_st
{
    NvU32 signalId;                         // signal ID
    const char *pSignalName;                // signal name for CUDA/OpenCL
    CUPerfSignalVirtualValue flag;          // flag to indicate if values should be repeated (elapsed_clks) or interleaved (active_cycles)
    NvU32 validSignals;                     // Indicates for how many user signals the values of hw counters should be repeated OR 
                                            // for interleaving this means 1 user counter corresponds to how many HW counters and the values shoudl be interleaved accordingly.
    NvU32 signalId_combination[2];          // In HWPM, we can have signal id combination for upto 7 signals.
}PerfSignalHwpmVirtualExpt;

typedef struct PerfSignalSmpc_st
{
    NvU32 signalId;                         // signal ID
    const char *pSignalName;                // signal name for CUDA/OpenCL
    NvU32 eventGroup;                       // signal event-group
    NvU32 perfEvent;                        // signal perf-event
    NvU32 function;                         // signal function combination
    NvU32 pmUnitId;                         // PM unit Id - SM, SMC, TEX, FB etc
    NvU32 busWidth;                         // array of bus selection bits
    NvU32 signalId_filter;
}PerfSignalSmpc;

typedef struct PerfSignalSmpcExpt_st
{
    NvU32 signalId;                         // signal ID
    const char *pSignalName;                 // signal name for CUDA/OpenCL
    NvU32 pmUnitId;                         // PM unit Id - core, quad
    // 4 signals allowed for LUT and 6 signals allowed for multi-group increment signals:
    NvU32 signalId_combination[6];          // signal event-group 
    // For multi-group increment signals, function will be calculated at run-time. This field in signaltable is needed only for LUT signals:
    NvU32 function;                         // signal function combination for LUT will be added here.
    NvU32 signalId_filter;
}PerfSignalSmpcExpt;

// Used to interleave the h0 and h1 values of SMPC MIO counters for SM virtualization
typedef struct PerfSignalSmpcExpt1_st
{
    NvU32 signalId;                         // signal ID
    const char *pSignalName;                // signal name for CUDA/OpenCL
    NvU32 pmUnitId;                         // PM unit Id - core, quad
    NvU32 signalId_combination[4];          // signal event-group 
    NvU32 numSignals;                       // number of signals in experiment
}PerfSignalSmpcExpt1;

typedef struct PerfSignalNvLinkThroughputCounters_st
{
    NvU32       signalId;                       // signal ID
    const char  *pSignalName;                   // signal name for CUDA/OpenCL
    /*********************************************
    Value  Traffic units:
    0       CYCLES
    1       PACKETS
    2       FLITS
    3       BYTES
    *********************************************/
    NvU32   unitOfTraffic;                      // Defines what unit of traffic this counter will count
    /*********************************************
    Bit     Flit Types:
    0       None
    1       Header
    2       AE
    3       BE
    4       Data
    5       Idle
    *********************************************/
    NvU32   typeOfFlits;                    // Identifies the type(s) of flits to count when Unit = Flits

    NvU32   transactionType;                // Qualifies the counting to particular packet types when the counting unit is Packets, Flits, or Data Bytes

   /*********************************************
    Available options:
      - CUPROF_NVLINK_DATA_TRANSMIT
      - CUPROF_NVLINK_DATA_RECIEVE
    *********************************************/
    CUprofNvlinkDataTransferDirection direction;

    NvU32   responseType;                   // Qualifies the counting to particular packet types when the counting unit is Packets, Flits, or Data Bytes
}PerfSignalNvLinkThroughputCounters;


// CUPTI based software counters are ATOM based and require driver only to use
// signal enumeration and grouping
typedef struct PerfSignalCUPTIsw_st
{
    NvU32 signalId;                         // signal ID
    const char *pSignalName;                // signal name for CUDA
}PerfSignalCUPTIsw;

// LUT mode allows for a 4-bit truth table experiment.
//
// The four inputs are specified as signalNames[4] where
// signalName[0] = event0
// signalName[1] = event1
// signalName[2] = event2
// signalName[3] = event3
//
// function field is defined as 16-bit enable bitmask of the following
// signals were 0 is the lsb.
//
//Function        Expression
//    Func[0]  =  !event3 && !event2 && !event1 && !event0
//    Func[1]  =  !event3 && !event2 && !event1 &&  event0
//    Func[2]  =  !event3 && !event2 &&  event1 && !event0
//    Func[3]  =  !event3 && !event2 &&  event1 &&  event0
//    Func[4]  =  !event3 &&  event2 && !event1 && !event0
//    Func[5]  =  !event3 &&  event2 && !event1 &&  event0
//    Func[6]  =  !event3 &&  event2 &&  event1 && !event0
//    Func[7]  =  !event3 &&  event2 &&  event1 &&  event0
//    Func[8]  =   event3 && !event2 && !event1 && !event0
//    Func[9]  =   event3 && !event2 && !event1 &&  event0
//    Func[10] =   event3 && !event2 &&  event1 && !event0
//    Func[11] =   event3 && !event2 &&  event1 &&  event0
//    Func[12] =   event3 &&  event2 && !event1 && !event0
//    Func[13] =   event3 &&  event2 && !event1 &&  event0
//    Func[14] =   event3 &&  event2 &&  event1 && !event0
//    Func[15] =   event3 &&  event2 &&  event1 &&  event0
//

// Constants for the 4-bit Fermi truth table. For single signal counters
// the event signal will be routed to bit 0 and the truth table function
// needs to be set to bit 0 true only.
#define TRUTH_TABLE_FUNCTION_BIT_0_TRUE  0xAAAA
#define TRUTH_TABLE_FUNCTION_BIT_1_TRUE  0xCCCC
#define TRUTH_TABLE_FUNCTION_BIT_2_TRUE  0xF0F0
#define TRUTH_TABLE_FUNCTION_BIT_3_TRUE  0XFF00
#define TRUTH_TABLE_FUNCTION_ALL_TRUE    0XFFFF
#define TRUTH_TABLE_FUNCTION_ALL_FALSE   0X0000

typedef struct SignalDescriptionTable_st
{
    NvU32                   signalId;                         // signal ID
    const char              *name;                            // signal name
    const char              *pUIName;                         // signal name for CUDA/OpenCL
    CUprof_EventCategory     category;                         // signal category
    const char              *pDescription;                    // signal description for CUDA/OpenCL
}SignalDescriptionTable;

typedef NvU32 CUeventID;
typedef NvU32 CUeventDomainID;
typedef PerfSignalTableBasic CUeventDataBasic;
typedef PerfSignalTableNew CUeventData;
typedef PerfSignalSmpc CUeventDataSmpc;
typedef PerfSignalHwpm CUeventDataHwpm;
typedef PerfSignalHwpmMux CUeventDataHwpmMux;
typedef PerfSignalNvLink CUeventDataNvLink;
typedef PerfSignalHwpmExpt CUeventDataHwpmExpt;
typedef PerfSignalHwpmExpt_v1 CUeventDataHwpmExpt_v1;
typedef PerfSignalHwpmVirtualExpt CUeventDataHwpmVirtualExpt;
typedef PerfSignalSmpcExpt CUeventDataSmpcExpt;
typedef PerfSignalNvLinkThroughputCounters CUeventDataNvlinkThroughputCounters;
typedef PerfSignalSmpcExpt1 CUeventDataSmpcExpt_v1;
typedef PerfSignalCUPTIsw CueventCUPTIsw;

typedef struct CUteslaEventGroup_st  CUteslaEventGroup;     // Tesla specific perfmon properties
typedef struct CUfermiEventGroup_st  CUfermiEventGroup;     // Fermi specific perfmon properties (fermi_perfmon.h)
typedef struct CUkeplerEventGroup_st CUkeplerEventGroup;    // Kepler specific perfmon properties
typedef struct CUmaxwellEventGroup_st CUmaxwellEventGroup;    // Kepler specific perfmon properties
typedef struct CUpascalEventGroup_st CUpascalEventGroup;    // Pascal specific perfmon properties
typedef struct CUvoltaEventGroup_st CUvoltaEventGroup;    // Pascal specific perfmon properties

enum chipletsType{
    PM_CHIPLET_TYPE_SYS                                             =   0,
    PM_CHIPLET_TYPE_GPC                                             =   1,
    PM_CHIPLET_TYPE_FBP                                             =   2,
    PM_MAX_CHIPLET_TYPES                                            =   3,
    // HACK!! TYPE_NONE is used for SW counter domains
    PM_CHIPLET_TYPE_NONE                                            =   4,
};

typedef struct eventTableInfo_st{
    void *pEventData;
    CUPerfSignalTableType signalTableType;
} CUeventInfo;

typedef struct CUdomainData_st {
    CUeventDomainID domainId;
    char *domainName;
    CUprof_EventCollectionMethod eventCollectionMethod; // HWPM, SMPERF, SW etc
    //EventData can be actually array of pointers to individual entries of PerfSignalTable
    CUeventInfo   pEventTableInfo[MAX_SIGNAL_TABLES_PER_DOMAIN];
    NvU32       maxExternalEvents;            //max external events in a domain //have all the external events in front of array.
    NvU32       maxInternalEvents;            //max internal events in a domain
    NvU32       exposedEvents;                //max events in a domain
    NvU32       chipletType;                  //Store chiplet type of domain, this will decide the pmmbaseaddress for all chiplets and priaddress for GPC
    volatile unsigned int bInit;              // flag to indicate whether domain info is initialized fully
    volatile unsigned int bInitStarted;
    NvU32        numPerfSignalTables;
    CUprof_EventCollectionScope eventCollectionScope; // Profiling scope of the event group: context, global, both.
}CUdomainData;

typedef struct CUdomainInfo_st {
    NvU32 numDomains;                                 // num of exposed domains
    CUdomainData *pDomainTable;                       // pointer to table containing data for each exposed domain
    SignalDescriptionTable *pSignalDescriptionArray;  //Pointer to a table of short description for signals 
    volatile unsigned int bInit;                      // flag to indicate whether domain info is initialized fully
    volatile unsigned int bInitStarted;               // flag to indicate whether domain info is initialized fully
}CUdomainInfo;

typedef struct CUnopTrigSwCounter_st {
    // 8 NOPTRIG can be used on Fermi. 4 on Kepler.
    // Taking the upper limit.
    NvU32 signalID[FERMI_MAX_SW_COUNTER_PER_EVENTGROUP];    // Array to keep track of requested event IDs.
    NvU32 numSwCountersRequested;                           // Counter to track number of s/w counters requested by user.
    CUeventDomainID nopTrigDomainId;
}CUnopTrigSwCounter;

// Event group profiling scope
typedef enum CUeventGroupScope_enum {
    CU_EVENT_GROUP_SCOPE_CONTEXT    = 0,
    CU_EVENT_GROUP_SCOPE_DEVICE     = 1,
    CU_EVENT_GROUP_SCOPE_BOTH       = 2,
    CU_EVENT_GROUP_SCOPE_FORCE_INT  = 0x7fffffff,
}CUeventGroupScope;

//CUeventGroup will store the information for one event group. 
typedef struct CUeventGroup_st {
    CUeventDomainID     domainId;
    CUdomainData        *domain;                        //Domain for the eventgroup
    CUctx               *pCtx;                          //Context for which eventgroup is created
    void                *userData;
    NvU32               profileAll;                     // Flag to indicate if all the instances of the domain are needed to profile  
    NvU32               isEnabled;                      // Flag to indicate if this eventgroup is enabled 
    CUlistHeader        *pEventInfoList;                 // List of events and its info
    NvU64               *values;                        // Array of values for all the chiplet instances for all the counters selected in this domain
    NvU32               totalCounters;                  // total no of counters in a eventgroup
    NvU32               instanceCountTotal;             // max intances of domain, same as no of chiplets
    NvU32               instanceCountAvail;             // available intances of domain
    void                *devSwCounterBuffer;            // The pointers that points to the buffer that holds the sw counter values on device
    CUnopTrigSwCounter  *nopTrigSwCounterData;          // Structure that maintains data needed for NOP.TRIG based sw counters
    // Fields added to handle separate compilation and no-cloning.
    // Values of these fields will be kernel specific.
    // They will be set just before cuilaunch and cleared after that.
    char                **depFuncNames; // Array of pointers of related functions
    NvU32               numDepFuncs; //  Actual number of entries that are used in depFuncNames array
    CUlistHeader        *memobjList; // List of patch memobj
    NvBool              configChanged;
    CUeventGroupScope   eventGroupScope;        // Profiling scope for the eventgroup
    // Architecture Specific
    union {
        CUteslaEventGroup  *teslaEventGroup;
        CUfermiEventGroup  *fermiEventGroup;
        CUkeplerEventGroup *keplerEventGroup;
        CUmaxwellEventGroup *maxwellEventGroup;
        CUpascalEventGroup *pascalEventGroup;
        CUvoltaEventGroup *voltaEventGroup;
    } arch;
}CUeventGroup;


typedef struct CUdomainConfig_st {
    NvU32 chipletType;
    CUprof_EventCollectionMethod method;
    CUeventDomainID domainId;
    NvU32           numEvents;
    CUlistHeader    *eventList;
}CUdomainConfig;

START_PACKED_ALIGNMENT
typedef struct PACKED_ALIGNMENT CUprofStreamingRecord_st
{
    // global 40 timestamp
    NvU32 timestamp00_31;
    NvU8  timestamp39_32;
    NvU8  perfmonId;

    // typically smplCnt is wired to #pmtrigger count
    NvU16 smplCnt_ds_sz;

    // counter results
    NvU32 eventCnt;
    NvU32 trigger0Cnt;
    NvU32 trigger1Cnt;
    NvU32 sampleCnt;

    NvU32 zero2;
    NvU32 zero3;
}CUprofStreamingRecord;
END_PACKED_ALIGNMENT

START_PACKED_ALIGNMENT
typedef struct PACKED_ALIGNMENT CUprofSamplingRecord_st
{
    // global 40 timestamp
    NvU16  data0[2];
    NvU8  d_cnt;
    NvU8  perfmonId;

    NvU16 smplCnt_tm_ds_sz_0_0;
    NvU16  data1[12];
}CUprofSamplingRecord;
END_PACKED_ALIGNMENT

#define IS_RECORD_DELAYED(smplCnt_ds_sz) (smplCnt_ds_sz & 0x1000)
#define GET_SAMPLE_COUNT(smplCnt_ds_sz) (smplCnt_ds_sz & 0x0FFF)

// context level information for perfmon
typedef struct CUperfMonNew_st {
    NvU32           maxDomainsTypes;                             //max types of domains supported
    CUdomainData    *pDomainData;                                //Array of supported domains.
    CUlistHeader    *egList;                                     //List of eventgroups created
    NvU32           totalEventGroups;                            //Eventgroups created for this context
    NvU32           domainEventGroupEnabled[MAX_DOMAINS];        //Since only one eventgroup from a domain can be enabled at a time keep flag for it.
    NvU32           perfmonHWReservedRefCount;                   //If perfmon hw is reserved refCount should be >= 1 else it is free.
    NvU32           perfmonTriggerRefCount;                      // ref count for pm trigger
    NvU32           patchFlag;                                   // Code Patching Flag (for patched counters)
    NvU32           flag;                                        // generic bit flag, unique bit for each flag
    CUeventGroup    *egSwCounters;                               // Pointer to eventgroup created for s/w counter domain
    CUprof_EventCollectionMode eventCollectionMode;              // event collection mode
    NvU32           isMembarWarEnabled;                          // flag to indicate whether the membar related WAR is enabled or disabled
    //If the events do not change during the context, then do not overwrite the registers.
    CUlistHeader    *lastDomainConfig;                            //List of domain configuration enabled previously in this context
    NvU32           hProfilerObjContext;                          //profiler object with context scope
    NvU32           hProfilerObjGlobal;                           //profiler object with global scope
    // Flag to detect the state of PM Ctxsw mode. This is required because 
    // the PM CTXSW bit should be set only once for every context.
    NvBool          isPmCtxswModeEnabled;
    //Keep track if the ctxsw mode is changed
    NvBool          ctxswModeChanged;
    NvU32           samplingFlag;                                  // generic bit flag, unique bit for each flag
    // Indicates the regOp type
    // Possible values:
    //   CU_PRI_REG_CONTEXT
    //   CU_PRI_REG_GLOBAL
    NvU32 regOpType;
    void *cpuAddrStreamingBuffer;
    NvU64 gpuAddrStreamingBuffer;
    size_t sizeStreamingBuffer;
    NvU32 rmPerfObject;
    NvU32 rmPerfMemory;
    NvU32 samplingPeriod;
    NvU32 userPeriod;
    NvU8 isUserPeriod2;
    CUprofPCSamplingReadDataCallback pcSamplingReadDataCallback;
    void *userData;
#if cuiPlatformIncludesMrm()
    NvRmMemHandle memHandler;
    NvU32 perfmonIdStart;
    CUnvchannel *channel;
    NvBool isCSSDisabled;  // If set to true, CycleStats Snapshot is not used. PERFBUF_MAP is used instead.
#endif
}CUperfMonNew;

typedef struct CUprofBuff_st {
    NvU32 *buff;
    NvU32 buffSize;
    // Queue of all devices
    CUdev *head, *tail;
}CUprofBuff;

// Template structure for PC sampling data,
// GP100+ we additionally get instIssued0 information with a record to
// which will be set when there is no inst issued set while the data was
// recorded
typedef struct CUprofSamplingData_st {
    NvU32 totalSamples;     // Number of times the cant-issue-reason was
                            // collected
    NvU32 latencySamples;   // Number of times inst issued0 bit was set when the
                            // cant-issue-reason was collected
} CUprofSamplingData;

typedef struct CUprofDeviceState_st {
    // PMHW owner context on device
    CUctx* ctxHWPMOwner;

    // Ref count to track of enabling/disabling power/clock gating.
    NvU32 powerStateRefCount;
    // flag indicating perfmon reservation status by profilerClass/CUPTI on each device (Bug 1408976)
    NvBool isPerfmonReservedOutsideHal;

    //Thread to read the sampling data asynchronously
    CUOSthread *samplingThreadReadData;
    CUOSthread *samplingThreadParseData;

    void *samplingDataHashMap;
    NvU32 totalDroppedRecords;
    NvU32 terminateSamplingThread;
    NvU32 terminateSamplingParseDataThread;
    cuosSem readSemaphore;
    cuosSem parseDoneSemaphore;
    CUImutex buffListMutex;
    void *buffList;
    uint32_t profilerObj;
    CUctx    *pCtx;
    uint32_t refCount;
}CUprofDeviceState;

// pm trigger flag enum
typedef enum CUpmTriggerFlag_enum {
    CU_PM_TRIGGER_FLAG_BEGIN,
    CU_PM_TRIGGER_FLAG_END,
    CU_PM_TRIGGER_FLAG_RESET,
} CUpmTriggerFlag;

// event group control flags
typedef enum CUeventGroupFlag_enum {
    CU_EVENT_GROUP_FLAG_SET_PROFILE_ALL_DOMAIN_INSTANCES,       // profile all instances of the domain of events in event group
    CU_EVENT_GROUP_FLAG_GET_CHIP_TYPE_FB,                       // queries whether chip type of events in event group is FB?
    CU_EVENT_GROUP_FLAG_GET_UNIT_TYPE_SM                        // queries whether SMPERF ?
}CUeventGroupFlag;

typedef enum
{
    HWPM_TRIGGER_TYPE_START_EXPERIMENT = 0,
    HWPM_TRIGGER_TYPE_PMA_TESLA_MODE,
    HWPM_TRIGGER_TYPE_PMA_MIXED_MODE_START,
    HWPM_TRIGGER_TYPE_PMA_MIXED_MODE_END,
} HWPM_TRIGGER_TYPE;

/* Must match NvSnapshotBufferFifo
  //sw/dev/gpu_drv/cuda_a/drivers/common/cyclestats/gpu/KernelInterface/nvSnapshotBufferFIFO.h*/
typedef struct gk20a_cs_snapshot_fifo_st
{
    /* layout description of the buffer */
    uint32_t    start;
    uint32_t    end;

    /* snafu bits */
    uint32_t    hw_overflow_events_occured;
    uint32_t    sw_overflow_events_occured;

    /* the kernel copies new entries to put and
     * increment the put++. if put == get then
     * overflowEventsOccured++
     */
    uint32_t    put;
    uint32_t    _r10;
    uint32_t    _r11;
    uint32_t    _r12;

    /* the driver/client reads from get until
     * put==get, get++ */
    uint32_t    get;
    uint32_t    _r20;
    uint32_t    _r21;
    uint32_t    _r22;

    /* unused */
    uint32_t    _r30;
    uint32_t    _r31;
    uint32_t    _r32;
    uint32_t    _r33;
} gk20a_cs_snapshot_fifo;

CUprofResult perfmonEventGroupEnable(CUeventGroup *pEventGroup);
CUprofResult perfmonEventGroupDisable(CUeventGroup *pEventGroup);
CUprofResult perfmonEventGroupResetAllEvents(CUeventGroup *pEventGroup);
CUprofResult perfmonEventGroupReadEvent(CUeventGroup          *pEventGroup,
                                         CUprof_ReadEventFlags flags,
                                         CUprof_EventID        eventID, 
                                         size_t                *bufferSizeBytes,
                                         NvU64                 *counterData);
CUprofResult perfmonEventGroupReadAllEvents(CUeventGroup *pEventGroup,
                                             CUprof_ReadEventFlags  flags,
                                             size_t                 *bufferSizeBytes,
                                             NvU64                  *counterDataBuffer,
                                             size_t                 *arraySizeBytes,
                                             CUprof_EventID         *eventIDArray,
                                             size_t                 *numCountersRead);
CUprofResult perfmonControl(CUctx *ctx, NvBool bAcquire, NvBool isHWPM);
CUprofResult perfmonControlPowerState(CUctx *ctx, NvBool bDisable);
CUprofResult perfmonStructCreate(CUperfMonNew **pm);
CUprofResult perfmonStructDestroy(CUperfMonNew *pm);

CUprofResult perfmonControlPowerGatingProfilerClass(CUctx *ctx, NvU32 hProfilerObj, NvBool bDisable);
CUprofResult perfmonControlClockGatingProfilerClass(CUctx *ctx, NvU32 hProfilerObj, NvBool bDisable);
CUprofResult perfmonControlThermalSettingsProfilerClass(CUctx *ctx, NvU32 hProfilerObj, NvBool bDisable);
CUprofResult perfmonControlVatProfilerClass(CUctx *ctx, NvU32 hProfilerObj, NvBool bDisable);
CUprofResult perfmonControlPerfmonHWProfilerClass(CUctx *ctx, NvU32 hProfilerObj, NvBool bAcquire);
CUprofResult perfmonSetupPMCtxswMode(CUctx *ctx, NvBool bEnable);
CUprofResult getExposedEventProfilingScope(CUprof_EventID eventID, NvU32 *scope);
uint8_t profilingModeDevice();

static void 
setDomainEventGroup(NvU32 *domainEventGroupEnabled,
                    NvU32 domainId,
                    NvU32 val)
{
    NvU32 i = 0;

    if (val == 1) {
        for (i = 0; i < MAX_DOMAINS; i++) {
            if (domainEventGroupEnabled[i] == 0) {
                domainEventGroupEnabled[i] = domainId;
                break;
            }
       }
    }
    else if (val == 0) {
        for (i = 0; i < MAX_DOMAINS; i++) {
            if (domainEventGroupEnabled[i] == domainId) {
                domainEventGroupEnabled[i] = 0;
                break;
            }
       }
    }
}

#endif /* __PERFMON_NEW_H__ */
