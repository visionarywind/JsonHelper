/*
 * Copyright 2011-2014 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

#ifndef __SIGNAL_COMMON_H__
#define __SIGNAL_COMMON_H__

#ifdef VULCAN
#include "nvtypes.h"
#endif
#include "ctrl/ctrl2080/ctrl2080mc.h"
// assign unique domain ids across all chips

//
// This #define is moved from ctrl2080mc.h here, because GM000 is no more a chip,
// but to maintain backward compatibility as CUDA profiler driver release r6.0 uses
// this value as a base for MAXWELL though not correct, as GM000 was just a test chip
// Reference Bug 1455732
//
#ifndef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM000
#define NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM000              (0x00000000)
#endif

// fermi has more than 10 clock domains
#define FERMI_CLK_DOMAIN_GF100_START       100
#define FERMI_CLK_DOMAIN_GF104_START       130
#define FERMI_CLK_DOMAIN_GF108_START       160
#define FERMI_CLK_DOMAIN_GF119_START       190
#define FERMI_CLK_DOMAIN_SW_START          220
#define FERMI_CLK_DOMAIN_GF117_START       250
// kepler has more than 10 clock domains
#define KEPLER_CLK_DOMAIN_GK104_START      300
#define KEPLER_CLK_DOMAIN_GK110_START      400
#define KEPLER_CLK_DOMAIN_GK208_START      500
#define KEPLER_CLK_DOMAIN_GK20A_START      600

// Logic for domain ids
// Bit 31 to 16 = Architecture + Implementation
// Bit 15 = Internal domain
// Bit 14 = Software domain

#define INTERNAL_DOMAIN             0x01
#define SW_DOMAIN                   0x01

#define CHIP_ID_BITS_POS            0x10
#define SW_DOMAIN_BITS_POS          0X0E
#define INTERNAL_DOMAIN_BITS_POS    0X0F

/*********************************************************
    |0000|0000|  000000000000000000000000|
     Type ChipId EventId

     - TYPE: 
        00 - Exposed events
        01 - Exposed publicly but internal (cannot be profiled individually via CUPTI. These can be queried/profiled only for any metric. 
             if any attributes are queried for such an event, dummy information will be returned)
        10 - Internal (for testing)
        11 - Internal (used only inexperiments)
    - CHIP Arch: 
        These will be present in the eventIds for Kepler onwards. For Kepler, they will be added only for type 10 and 11. 
        For Maxwell onwards, they will be seen in all types of signals.
        00 - Tesla
        01 - Fermi
        10 - Kepler
        11 - Maxwell

*********************************************************/
#define TYPE_MASK                   0xF0000000
#define TYPE_BITS_START             28
#define SIG_TYPE_EXPOSED            (0x0 << TYPE_BITS_START)
#define SIG_TYPE_EXPOSED_INTERNAL   (0x1 << TYPE_BITS_START)
#define SIG_TYPE_INTERNAL_EXPOSED   (0x2 << TYPE_BITS_START)
#define SIG_TYPE_INTERNAL           (0x3 << TYPE_BITS_START)

#define CHIP_MASK                   0x0F000000
#define CHIP_BITS_START             24
#define CHIP_ARCH_TESLA             (0x1 << CHIP_BITS_START)
#define CHIP_ARCH_FERMI             (0x2 << CHIP_BITS_START)
#define CHIP_ARCH_KEPLER            (0x3 << CHIP_BITS_START)
#define CHIP_ARCH_MAXWELL           (0x4 << CHIP_BITS_START)
#define CHIP_ARCH_PASCAL            (0x5 << CHIP_BITS_START)
#define CHIP_ARCH_VOLTA             (0x6 << CHIP_BITS_START)

#define DEFAULT_EVENT_NAME          "event_name"
#define DEFAULT_EVENT_DESC_SHORT    "event_desc_short"
#define DEFAULT_EVENT_DESC_LONG     "event_desc_long"

#define SIG_TYPE_IS_EXPOSED(sig)            (((sig) & TYPE_MASK) == SIG_TYPE_EXPOSED)

#define SIG_TYPE_IS_EXPOSED_INTERNAL(sig)   (((sig) & TYPE_MASK) == SIG_TYPE_EXPOSED_INTERNAL)

#define SIG_TYPE_IS_INTERNAL_EXPOSED(sig)   (((sig) & TYPE_MASK) == SIG_TYPE_INTERNAL_EXPOSED)

#define SIG_TYPE_IS_INTERNAL(sig)           (((sig) & TYPE_MASK) == SIG_TYPE_INTERNAL)

#define SIG_DEVICE_ARCH_IS_TESLA(sig)       (((sig) & CHIP_MASK) == CHIP_ARCH_TESLA)

#define SIG_DEVICE_ARCH_IS_FERMI(sig)       (((sig) & CHIP_MASK) == CHIP_ARCH_FERMI)

#define SIG_DEVICE_ARCH_IS_KEPLER(sig)      (((sig) & CHIP_MASK) == CHIP_ARCH_KEPLER)

#define SIG_DEVICE_ARCH_IS_MAXWELL(sig)     (((sig) & CHIP_MASK) == CHIP_ARCH_MAXWELL)

#define SIG_DEVICE_ARCH_IS_PASCAL(sig)      (((sig) & CHIP_MASK) == CHIP_ARCH_PASCAL)

#define SIG_DEVICE_ARCH_IS_VOLTA(sig)       (((sig) & CHIP_MASK) == CHIP_ARCH_VOLTA)

#define KEPLER_CLK_DOMAIN_INTERNAL_SW_START     ((NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 << CHIP_ID_BITS_POS) | \
                                                (INTERNAL_DOMAIN << INTERNAL_DOMAIN_BITS_POS) | \
                                                (SW_DOMAIN << SW_DOMAIN_BITS_POS))

#define MAXWELL_CLK_DOMAIN_GM000_START          ((NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM000 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM000) << CHIP_ID_BITS_POS)
#define MAXWELL_CLK_DOMAIN_GM200_START          ((NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200) << CHIP_ID_BITS_POS)
#define MAXWELL_CLK_DOMAIN_GM20Y_START          ((NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM20B) << CHIP_ID_BITS_POS)
#define PASCAL_CLK_DOMAIN_GP100_START           ((NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GP100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GP100) << CHIP_ID_BITS_POS)
#define PASCAL_CLK_DOMAIN_GP10Y_START           ((NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GP100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GP10B) << CHIP_ID_BITS_POS)
#define PASCAL_CLK_DOMAIN_GP10X_START           ((NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GP100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GP102) << CHIP_ID_BITS_POS)
// This enum will be used for both GP107 and GP108 chip
#define PASCAL_CLK_DOMAIN_GP107_START           ((NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GP100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GP107) << CHIP_ID_BITS_POS)
#define VOLTA_CLK_DOMAIN_GV100_START            ((NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GV100) << CHIP_ID_BITS_POS)
#define VOLTA_CLK_DOMAIN_GV11B_START            ((NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GV11B) << CHIP_ID_BITS_POS)

// keep fermi signal ids starting from 0 as cupti users
// might have stored the values offline
#define TESLA_FIRST_SIGNAL_ID       1001    // Keeping this define just for comparision of signalId
#define FERMI_FIRST_SIGNAL_ID       0
#define KEPLER_FIRST_SIGNAL_ID      2001
#define MAXWELL_FIRST_SIGNAL_ID     (SIG_TYPE_EXPOSED + CHIP_ARCH_MAXWELL + 1)
#define PASCAL_FIRST_SIGNAL_ID      (SIG_TYPE_EXPOSED + CHIP_ARCH_PASCAL + 1)
#define VOLTA_FIRST_SIGNAL_ID       (SIG_TYPE_EXPOSED + CHIP_ARCH_VOLTA + 1)

#endif // __SIGNAL_COMMON_H__
