/*
 * Copyright 1993-2010 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

/******************************************************************************
*
*   Module: fermi_prof_func.c
*
*   Description:
*       Kernel instruction patching code related to profiler for Fermi class.
*
******************************************************************************/

#include "fermi_prof_func.h"
#include "fermi_perfmon_new.h"

#define ADDRESS_MASK 0xff000000

#define MAX_NUM_INST_TO_BE_COUNTED 16

#define LD_INST_U8BIT_OPCODE       0x8000000000000005ULL
#define LD_INST_S8BIT_OPCODE       0x8000000000000025ULL
#define LD_INST_U16BIT_OPCODE      0x8000000000000045ULL
#define LD_INST_S16BIT_OPCODE      0x8000000000000065ULL
#define LD_INST_32BIT_OPCODE       0x8000000000000085ULL
#define LD_INST_64BIT_OPCODE       0x80000000000000a5ULL
#define LD_INST_128BIT_OPCODE      0x80000000000000c5ULL
#define LDU_INST_U8BIT_OPCODE      0x8800000000000005ULL
#define LDU_INST_S8BIT_OPCODE      0x8800000000000025ULL
#define LDU_INST_U16BIT_OPCODE     0x8800000000000045ULL
#define LDU_INST_S16BIT_OPCODE     0x8800000000000065ULL
#define LDU_INST_32BIT_OPCODE      0x8800000000000085ULL
#define LDU_INST_64BIT_OPCODE      0x88000000000000a5ULL
#define LDU_INST_128BIT_OPCODE     0x88000000000000c5ULL
#define ST_INST_U8BIT_OPCODE       0x9000000000000005ULL
#define ST_INST_S8BIT_OPCODE       0x9000000000000025ULL
#define ST_INST_U16BIT_OPCODE      0x9000000000000045ULL
#define ST_INST_S16BIT_OPCODE      0x9000000000000065ULL
#define ST_INST_32BIT_OPCODE       0x9000000000000085ULL
#define ST_INST_64BIT_OPCODE       0x90000000000000a5ULL
#define ST_INST_128BIT_OPCODE      0x90000000000000c5ULL

NvU32 fermiAtomPerLdStInstOccurencePatch[] = {
                                0xc8000000,0x03f01c85, // STL  [0x0], R0;
                                0xc8000000,0x13f05c85, // STL  [0x4], R1;
                                0xc8000000,0x23f09c85, // STL  [0x8], R2;
                                0xc8000000,0x33f0dc85, // STL  [0xc], R3;
                                0x3000c3ff,0xfff0dc04, // P2R R3, PR, RZ, 0xffff;
                                0xc8000000,0x43f0dc85, // STL  [0x10], R3;
                                0xc0000000,0x33f0dd85, // LDL.CG R3 ,[0xc];
                                0x190e0000,0xfff1dc03, // ISETP.EQ.U32.AND P0, PT, RZ, RZ, PT;
                                0x28000000,0x40001de4, // MOV R0, R16;
                                0x28000000,0x44005de4, // MOV R1, R17;
                                0x18000000,0x00009de2, // MOV32I R2, 0x0;
                                0x48000000,0x08001c03, // IADD R0.CC, R0, R2;
                                0x48010000,0x7c105c43, // IADD.X R1, R1, RZ;
                                0x1bfc0000,0x00009de2, // MOV32I R2, 0xff000000;
                                0x68000000,0x08001c03, // LOP.AND R0, R0, R2;
                                0x190e4000,0x1003dc03, // ISETP.EQ.U32.AND P1, PT, R0, c [0x0] [0x4], PT;
                                0x19224000,0x0003dc03, // ISETP.EQ.U32.OR P1, PT, R0, c [0x0] [0x0], P1;
                                0x19020000,0xfc13dc03, // ISETP.EQ.U32.AND P1, PT, R1, RZ, P1;
                                0x0c0e0000,0x2401dc04, // PSETP.AND.AND P0, PT, P0, !P1, PT;
                                0x1800c000,0x000001e2, // @P0 MOV32I R0, 0x300000;
                                0x18000000,0x080041e2, // @P0 MOV32I R1, 0x2;
                                0x18000000,0x040081e2, // @P0 MOV32I R2, 0x1;
                                0x14000000,0x00008005, // @P0 RED.E.ADD  [R0], R2;
                                0xc0000000,0x43f0dd85, // LDL.CG R3 ,[0x10];
                                0x3400c3ff,0xfc301c04, // R2P PR, R3;
                                0xc0000000,0x03f01d85, // LDL.CG R0 ,[0x0];
                                0xc0000000,0x13f05d85, // LDL.CG R1 ,[0x4];
                                0xc0000000,0x23f09d85, // LDL.CG R2 ,[0x8];
                                0xc0000000,0x33f0dd85, // LDL.CG R3 ,[0xc];
                                0x84000000,0x01055c05, // LD.E.U8 R21 ,[R16];
                                0x00000000,0x00001de7, // JMP 0x0;
                                };

NvU32 fermiAtomPerLduInstOccurencePatch[] = {
                                0xc8000000,0x03f01c85, // STL  [0x0], R0;
                                0xc8000000,0x13f05c85, // STL  [0x4], R1;
                                0xc8000000,0x23f09c85, // STL  [0x8], R2;
                                0xc8000000,0x33f0dc85, // STL  [0xc], R3;
                                0x3000c3ff,0xfff0dc04, // P2R R3, PR, RZ, 0xffff;
                                0xc8000000,0x43f0dc85, // STL  [0x10], R3;
                                0xc0000000,0x33f0dd85, // LDL.CG R3 ,[0xc];
                                0x1800c000,0x000001e2, // @P0 MOV32I R0, 0x300000;
                                0x18000000,0x080041e2, // @P0 MOV32I R1, 0x2;
                                0x18000000,0x040081e2, // @P0 MOV32I R2, 0x1;
                                0x14000000,0x00008005, // @P0 RED.E.ADD  [R0], R2;
                                0xc0000000,0x43f0dd85, // LDL.CG R3 ,[0x10];
                                0x3400c3ff,0xfc301c04, // R2P PR, R3;
                                0xc0000000,0x03f01d85, // LDL.CG R0 ,[0x0];
                                0xc0000000,0x13f05d85, // LDL.CG R1 ,[0x4];
                                0xc0000000,0x23f09d85, // LDL.CG R2 ,[0x8];
                                0xc0000000,0x33f0dd85, // LDL.CG R3 ,[0xc];
                                0x84000000,0x01055c05, // LD.E.U8 R21 ,[R16];
                                0x00000000,0x00001de7, // JMP 0x0;
                                };

#define LD_ST_INST_PATCH_SIZE  sizeof(fermiAtomPerLdStInstOccurencePatch)
#define LDU_INST_PATCH_SIZE    sizeof(fermiAtomPerLduInstOccurencePatch)

#define PATCH_LDU_SKIP_INST_SIZE 6*sizeof(NvU64) // Number of instruction to skip from common routine in case of LDU instruction

NvU32 fermiNopTrigCommonRoutinePatch[] = {
                                0x747f8000,0x001fc00a, // MOV32I R2, -0x1000000;
                                0xe2000000,0x011c0002, // LOP.AND R0, R0, R2;
                                0x5b201c00,0x009c003e, // ISETP.EQ.U32.AND P1, pt, R0, c [0x0] [0x4], pt;
                                0x5b210400,0x001c003e, // ISETP.EQ.U32.OR P1, pt, R0, c [0x0] [0x0], P1;
                                0xdb200400,0x7f9c043e, // ISETP.EQ.U32.AND P1, pt, R1, RZ, P1;
                                0x84802400,0x001dc01e, // PSETP.AND.AND P0, pt, pt, P0, !P1;
                                0x14800007,0x3c000000, // SSY 0xeb0;
                                0x12000007,0x3420003c, // @!P0 BRA 0xea8;
                                0x86cf1c00,0x001c0002, // VOTE.ANY R0, pt, pt;
                                0xc84003ff,0xff9c0001, // POPC R0, R0, 0xfffff;
                                0x74000000,0x101fc006, // MOV32I R1, 0x20;
                                0xe0880000,0x001c0402, // IADD R0, R1, -R0;
                                0x2e000000,0x041c0002, // IMUL32I R0, R0, 0x8;
                                0x12800006,0xd41c003c, // BRX R0 0xda8;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x401cbc02, // NOP.TRIG CC.T, 0x80;
                                0x85800000,0x005c3c02, // NOP.S CC.T;
                                0x7a208000,0x061ffc0a, // LDL.CG R2, [0xc];
                                0xc680007f,0xff9c0801, // R2P PR, R2;
                                0x7a208000,0x001ffc02, // LDL.CG R0, [0x0];
                                0x7a208000,0x021ffc06, // LDL.CG R1, [0x4];
                                0x7a208000,0x041ffc0a, // LDL.CG R2, [0x8];
                                0x19000000,0x001c003c, // RET;
                                };

NvU32 fermiNopTrigPerLdStInstOccurencePatch[] = {
                                0x00000000,0x00000000, // Fermi: NOP/ Kepler: TEXDEPBAR 0;
                                0x7aa00000,0x001ffc02, // STL [0x0], R0;
                                0x7aa00000,0x021ffc06, // STL [0x4], R1;
                                0x7aa00000,0x041ffc0a, // STL [0x8], R2;
                                0xc640007f,0xff9ffc09, // P2R R2, PR, RZ, 0xffff;
                                0x7aa00000,0x061ffc0a, // STL [0xc], R2;
                                0xdb201c00,0x7f9ffc1e, // ISETP.EQ.U32.AND P0, pt, RZ, RZ, pt;
                                0x7a208000,0x041ffc0a, // LDL.CG R2, [0x8];
                                0xe4c03c00,0x081c0002, // MOV R0, R16;
                                0xe4c03c00,0x089c0006, // MOV R1, R17;
                                0x18000000,0x00009de2, // MOV32I R2, 0;
                                0x48010000,0x08001c03, // IADD R0.CC, R0, R2;
                                0x48000000,0xfc105c43, // IADD.X R1, R1, RZ;
                                0x13007fff,0xd8000100, // CAL 0x1a0;
                                0xc0800000,0x001c4008, // LD.E.U8 R2, [R16];
                                0x00000000,0x00001de7, // JMP 0x0;
};

NvU32 fermiNopTrigPerLduInstOccurencePatch[] = {
                                0x00000000,0x00000000, // Fermi: NOP/ Kepler: TEXDEPBAR 0;
                                0x7aa00000,0x001ffc02, // STL [0x0], R0;
                                0x7aa00000,0x021ffc06, // STL [0x4], R1;
                                0x7aa00000,0x041ffc0a, // STL [0x8], R2;
                                0xc640007f,0xff9ffc09, // P2R R2, PR, RZ, 0xffff;
                                0x7aa00000,0x061ffc0a, // STL [0xc], R2;
                                0xdb201c00,0x7f9ffc1e, // ISETP.EQ.U32.AND P0, pt, RZ, RZ, pt;
                                0x7a208000,0x041ffc0a, // LDL.CG R2, [0x8];
                                0x13007fff,0xd8000100, // CAL 0x1a0;
                                0xc0800000,0x001c4008, // LD.E.U8 R2, [R16];
                                0x00000000,0x00001de7, // JMP 0x0;
};

#define COMMON_ROUTINE_PATCH_SIZE                               sizeof(fermiNopTrigCommonRoutinePatch)
#define PER_GENERIC_ANY_ADDR_WINDOW_INST_OCCURENCE_PATCH_SIZE   sizeof(fermiNopTrigPerLdStInstOccurencePatch)
#define PER_GLOBAL_ADDR_WINDOW_INST_OCCURENCE_PATCH_SIZE        sizeof(fermiNopTrigPerLduInstOccurencePatch)

#define LDC_INST_SYNC_KERNEL_PATCH  8
#define LDC_INST_ENTRY_PATCH        32
#define LDC_INST_EXIT_PATCH         12
#define CAL_INST_ENTRY_PATCH        44

// Note: LDU instruction is generated for global mem addresses only. So patch differs from LD/ST instrcutions

#define MASK_BITS_LD_ST_INST 0xf8000000000000efULL

#define FERMI_SWINLO 0x0
#define FERMI_LWINLO 0x4

// Code patch used for collecting warp event data
NvU32 fermiWarpEventCodeBinary[] = { 
                                0x88001c04,  0x2c000000, // S2R R0, SR_Tid_Y;
                                0x30009de4,  0x28004000, // MOV R2, c [0x0] [0xc];
                                0x8c005c04,  0x2c000000, // S2R R1, SR_Tid_Z;
                                0x20001c03,  0x50004000, // IMUL.U32.U32 R0, R0, c [0x0] [0x8];
                                0x20209c03,  0x50004000, // IMUL.U32.U32 R2, R2, c [0x0] [0x8];
                                0x8400dc04,  0x2c000000, // S2R R3, SR_Tid_X;
                                0x08101c03,  0x20000000, // IMAD.U32.U32 R0, R1, R2, R0;
                                0x0030dc03,  0x48000000, // IADD R3, R3, R0;
                                0x7c301c03,  0x6800c000, // LOP.AND R0, R3, 0x1f; //need to store R3
                                0x00000000,  0x00000000,// MOV32I R4, [lmemaddress];
                                0x2040dc85,  0xc8000000,// STL.32 [R4+0x8], R3;
                                0x00000000,  0x00000000,// SSY {bra 0x0};
                                0xfc01dc03,  0x1a8e0000, // ISETP.NE.U32.AND P0, pt, R0, RZ, pt;
                                0x000001e7,  0x80000000,// @P0 BRA {nop.s};
                                0x00011de2,  0x197afc00,// MOV32I R4, [BufferPtrLo];
                                0x28015de2,  0x18000000,// MOV32I R5, [BufferPtrHi];
                                0x00401ca5,  0x84000000, // LD.E.64 R0, [R4];
                                0xfc0fdd03,  0x48010000, // IADD RZ.CC, R0, -RZ;
                                0xfc11dc43,  0x190e0000, // ISETP.EQ.U32.X.AND P0, pt, R1, RZ, pt;
                                0x000001e7,  0x80000000,// @P0 BRA {nop.s};
                                0x40011c04,  0x2c000001, // S2R R4, SR_ClockLo;
                                0x04411e03,  0x6000c000, // SHL R4, R4, 0x1;
                                0x94019c04,  0x2c000000, // S2R R6, SR_CTAid_X;
                                0x98015c04,  0x2c000000, // S2R R5, SR_CTAid_Y;
                                0x40209c03,  0x50004000, // IMUL.U32.U32 R2, R2, c [0x0] [0x10];
                                0x1431dc03,  0x5800c000, // SHR.U32.W R7, R3, 0x5;
                                0x50515c03,  0x200c4000, // IMAD.U32.U32 R5, R5, c [0x0] [0x14], R6;
                                0x14209c03,  0x5800c000, // SHR.U32.W R2, R2, 0x5;
                                0x0c00dc04,  0x2c000000, // S2R R3, SR_VirtId;
                                0x54029de2,  0x18000000, // MOV32I R10, 0x15;
                                0x08519c03,  0x200e0000, // IMAD.U32.U32 R6, R5, R2, R7;
                                0x0c009c04,  0x2c000000, // S2R R2, SR_VirtId;
                                0x80621c03,  0x2001c000, // IMAD.U32.U32 R8.CC, R6, 0x20, R0;
                                0x50201c03,  0x7000c024, // BFE.U32 R0, R2, 0x914;
                                0x08019de2,  0x18000001, // MOV32I R6, 0x42;
                                0x07f25c43,  0x48000000, // IADD.X R9, RZ, R1;
                                0x20305c03,  0x7000c014, // BFE.U32 R1, R3, 0x508;
                                0x00815c45,  0x94000000, // ST.E.U16 [R8], R5;
                                0x0881dc25,  0x94000000, // ST.E.S8 [R8+0x2], R7;
                                0x0c801c25,  0x94000000, // ST.E.S8 [R8+0x3], R0;
                                0x10805c25,  0x94000000, // ST.E.S8 [R8+0x4], R1;
                                0x14829c25,  0x94000000, // ST.E.S8 [R8+0x5], R10;
                                0x18819c45,  0x94000000, // ST.E.U16 [R8+0x6], R6;
                                0x20811c85,  0x94000000, // ST.E [R8+0x8], R4;
                                0x30811c85,  0x94000000, // ST.E [R8+0xc], R4;
                                0x00000000,  0x00000000,// MOV32I R0, [lmemAddress];
                                0x00021ca5,  0xc8000000,// STL.64 [R0], R8; //Store actual address of buffer to local memory
                                0x00001df4,  0x40000000,// NOP.S;
                                0x00001de7,  0x80000000,// BRA 0x0;
                                //-----exit patch---------
                                0x00000000,  0x00000000,// MOV32I R0, [lmemaddress];
                                0x2000dc85,  0xc0000000,// LDL.32 R3, [R0+0x8];
                                0x00021ca5,  0xc0000000,// LDL.64 R8, [R0];
                                0x7c301c03,  0x6800c000, // LOP.AND R0, R3, 0x1f; 
                                0xfc01dc03,  0x1a8e0000, // ISETP.NE.U32.AND P0, pt, R0, RZ, pt;
                                0x000001e7,  0x80000000, // @P0 EXIT;
                                0x00000000,  0x00000000,// MOV32I R4, [bufferAddLo];
                                0x00000000,  0x00000000,// MOV32I R5, [bufferAddHi];
                                0x00401ca5,  0x84000000, // LD.E.64 R0, [R4];
                                0xfc0fdd03,  0x48010000, // IADD RZ.CC, R0, -RZ;
                                0xfc11dc43,  0x190e0000, // ISETP.EQ.U32.X.AND P0, pt, R1, RZ, pt;
                                0x000001e7,  0x80000000, // @P0 EXIT;
                                0x40011c04,  0x2c000001, // S2R R4, SR_ClockLo;
                                0x04411e03,  0x6000c000, // SHL R4, R4, 0x1;
                                0x30811c85,  0x94000000, // ST.E [R8+0xc], R4;
                                0x00001de7,  0x80000000, // EXIT;
                              };

NvU32 fermiConcKernelTraceEntryBinaryPatch[] = {  
                                        0x44005c04, 0x2c000001, // 1  S2R        R1, SR81;                  # Clock Hi
                                        0x40001c04, 0x2c000001, // 2  S2R        R0, SR80;                  # Clock Lo
                                        0x44011c04, 0x2c000001, // 3  S2R        R4, SR81;                  # Clock Hi
                                        0x10105c23, 0x30800000, // 4  ICMP.LT    R1, R1, R4, R0;            # if(R0 < 0) R1 = R1, else R1 = R4
                                        0x94009c04, 0x2c000000, // 5  S2R        R2, SR_CTAid.X;            # load block.x
                                        0x9800dc04, 0x2c000000, // 6  S2R        R3, SR_CTAid.Y;            # load block.y
                                        0x9c011c04, 0x2c000000, // 7  S2R        R4, SR_CTAid.Z;            # load block.z
                                        0x0c209c03, 0x48000000, // 8  IADD       R2, R2, R3;                # add block.x + block.y 
                                        0x80000007, 0x60000001, // 9  SSY <inst 22>;                        # Create sync point at instruction #22
                                        0x0043dc23, 0x190ec000, // 10 ISETP.EQ      P1, R4, 0x0;            # P1 = (block.z == 0)
                                        0x00225c23, 0x1902c000, // 11 ISETP.EQ.AND  P1, P1, R2, 0x0, P1;    # P1 = (block.x + block.y) == 0 && block.z == 0)
                                        0x000025e7, 0x40000001, // 12 @!P1 BRA Lab1;                        # if !(block == 0) return
                                        0x80011c04, 0x2c000000, // 13 S2R           R4, SR_Tid;             # load thread id (all 3 components)
                                        0x0043dc23, 0x190ec000, // 14 ISETP.EQ      P1, R4, 0x0;            # P1 = (thread == 0)
                                        0x001fdc24, 0x48800000, // 15 VOTE.ANY      P2, P1;                 # P2 = (warp == 0)
                                        0x800029e7, 0x40000000, // 16 @!P2 BRA Lab1;                        # if !(warp == 0) return
                                        0x23f11ca6, 0x14004400, // 17 LDC.64        R4, c[17][8];           # .rela { ImmConstant, BaseAddress, 0x0 }
                                        0x0c009c04, 0x2c000000, // 18 S2R           R2, SR_VirtId;          # load SR that contains SMId
                                        0x50209c03, 0x7000c024, // 19 BFE.U32       R2, R2, 0x0914;         # extract SMId    
                                        0x004004c5, 0x94000000, // 20 @P1 ST.E.128  [R4], R0;               # Store Clock, SmId
                                        0x00001df4, 0x40000000, // 21 NOP.S;                                # Sync instruction for earlier divergence
                                        0x40000007, 0x58000000, // 22 PLONGJMP 0x18;                        # Prepare LONGJMP target to start of exit patch
                                        0xa0010007, 0x5003ffff, // 23 CAL 0X0;                              # CAL start of kernel
                                        0x00001de7, 0x88000000, // 22 LONGJMP;                              # LONGJMP to exitpatch
};

NvU32 fermiConcKernelTraceExitBinaryPatch[] = { 
                                        //exit patch//
                                        0x00011c04, 0x2c000000, //  1 S2R           R4, SR_LaneId;
                                        0x0043dc23, 0x190ec000, //  2 ISETP.EQ      P1, R4, 0;
                                        0x44005c04, 0x2c000001, //  3 S2R           R1, SR81;               # Clock Hi
                                        0x40001c04, 0x2c000001, //  4 S2R           R0, SR80;               # Clock Lo
                                        0x44011c04, 0x2c000001, //  5 S2R           R4, SR81;               # Clock Hi
                                        0x10105c23, 0x30800000, //  6 ICMP.LT       R1, R1, R4, R0;         # if(R0 < 0) R1 = R1, else R1 = R4
                                        0x23f11ca6, 0x14004400, //  7 LDC.64        R4, c[17][8];           # Load buffer address from cbank
                                        0x0c009c04, 0x2c000000, // 10 S2R           R2, SR_VirtId;          # load SR that contains SMId
                                        0x50209c03, 0x7000c024, // 11 BFE.U32       R2, R2, 0x0914;         # extract SMId
                                        0x404004c5, 0x94000000, // 12 @P1 ST.E.128 [R4+16], R0;             # Store Clock and SMid
                                        0x00001de7, 0x80000000, // 13 EXIT;                                 # exit code
                                    };

NvU32 fermiConcKernelTraceSyncKernelBinary[] = {
                                        0x4400dc04, 0x2c000001, //  1 S2R               R3, SR81;           # Clock Hi
                                        0x40009c04, 0x2c000001, //  2 S2R               R2, SR80;           # Clock Lo
                                        0x44011c04, 0x2c000001, //  3 S2R               R4, SR81;           # Clock Hi
                                        0x1030dc23, 0x30840000, //  4 ICMP.LT           R3, R3, R4, R2;     # if(R2 < 0) R3 = R3, else R3 = R4
                                        0x23f01ca6, 0x14004400, //  5 LDC.64            R0, c[17][8];       # rela { ImmConstant, BaseAddress, 0x0 }
                                        0x0c011c04, 0x2c000000, //  6 S2R               R4, SR_VirtId;      # load SR that contains SMId
                                        0x50411c03, 0x7000c024, //  7 BFE.U32           R4, R4, 0x0914;     # extract SMId
                                        0x40411c02, 0x10000000, //  8 IMUL32I.U32.U32   R4, R4, 0x10;       # each block is 16 Bytes
                                        0x10001c03, 0x48010000, //  9 IADD              R0.CC, R0, R4;      # add base address (low)
                                        0xfc105c43, 0x48010000, // 10 IADD.X            R1.CC, R1, RZ;      # add base address (high)
                                        0x00009ca5, 0x94000000, // 11 ST.E.64           [R0 + 0], R2;       # store clock
                                        0x0c009c04, 0x2c000000, // 12 S2R               R2, SR_VirtId;      # load SR that contains SMId
                                        0x50209c03, 0x7000c024, // 13 BFE.U32           R2, R2, 0x0914;     # extract SMId
                                        0x20009c85, 0x94000000, // 14 ST.E              [R0 + 8], R2;       # store SMid
                                        0x70009c04, 0x2c000000, // 15 S2R               R2,SR_AFFINITY;     # load SR that contains GPCid
                                        0x00209c03, 0x7000c020, // 16 BFE.U32           R2, R2, 0x0800;     # extract GPC id
                                        0x30009c85, 0x94000000, // 17 ST.E              [R0 + 12], R2;      # store GPC id
                                        0x00001de2, 0x18000000, // 18 MOV32I            R0, 0;              # Create loop to extend running time of kernel
                                        0x04001c03, 0x4800c000, // 19 IADD              R0, R0, 1;          # Label: Wait
                                        0x4001dc23, 0x1b0ec01f, // 20 ISETP.GE          P0, R0, 2000;    
                                        0xa00021e7, 0x4003ffff, // 21 @!P0 BRA          Wait;               # Branch to Wait
                                        0x00001de7, 0x80000000, // 22 EXIT;
};

#define CONC_KERNEL_TRACE_SYNC_KERNEL_PATCH_SIZE    sizeof(fermiConcKernelTraceSyncKernelBinary)    // patch size in bytes
#define CONC_KERNEL_TRACE_ENTRY_PATCH_SIZE          sizeof(fermiConcKernelTraceEntryBinaryPatch)    // patch size in bytes
#define CONC_KERNEL_TRACE_EXIT_PATCH_SIZE           sizeof(fermiConcKernelTraceExitBinaryPatch)     // patch size in bytes

// Code patching to record warp events required for warp trace
static CUresult 
fermiFuncRecordWarpEvent(CUctx* ctx, const CUfunc* func, 
                         NvU32** patchCode, NvU32* patchSize)
{
    CUresult status = CUDA_SUCCESS;
    int   i;
    int funcCodeSize;
    int patchCodeIdx = 0;
    int codeBinaryIdx = 0;
    unsigned int *code;
    NvU32 branchToStartInstrHi;
    NvU32 branchToStartInstrLo;
    NvU32 branchToExitPatchHi = 0;
    NvU32 branchToExitPatchLo = 0;
    NvU32 PRegBitsVal=0;
    NvU32 cccBitsVal=0;
    NvU32 mov32iInstrHi = 0;
    NvU32 mov32iInstrLo = 0;
    NvU64 pBufferAddress = 0;
    NvU32 pBufferAddressHi = 0;
    NvU32 pBufferAddressLo = 0;
    NvU32 lmemAddress = LMEM_HI_SCRATCH;
    NvU32 branchTarget = 0;
    
    code = (unsigned int*)cuiFuncGetCodeData(func, CU_CODE_DATA_MASTER);

    *patchSize = func->codeSize + (FERMI_WARP_EVENTS_ENTRY_PATCH_SIZE)*sizeof(NvU64)
                                + (FERMI_WARP_EVENTS_EXIT_PATCH_SIZE)*sizeof(NvU64) ;
    // Allocate memory for the new patched code
    *patchCode = (NvU32*)malloc((*patchSize));
    if(!(*patchCode)) {
        CU_DEBUG_PRINT(("Failed to allocate storage for patchCode.\n"));
        status = CUDA_ERROR_OUT_OF_MEMORY;
        return status;
    }

    funcCodeSize = func->codeSize/4;
 
    // Copy the remaining instructions as they are in patchCode
    for (i = 0; i < funcCodeSize; ) {  
        if(CU_FERMI_IS_32B_INSTR(code[i])) {
            // If its 32bit instruction, copy 
            // only 32bits as they are
            (*patchCode)[i]     = code[i];
            i += 1;
        }
        else {
            if (CU_FERMI_IS_EXIT_INSTR(code[i + 1], code[i])) {
                // Replace EXIT instruction with BRANCH to exit patch
                // Note: In Fermi, Branch target is specified as an offset in bytes, not instructions or word, 
                // relative to the PC of the next instruction within the address range specified by the 40b 
                // virtual base address (PROGRAM_BASE)
                branchTarget = ((func->codeSize - (i*sizeof(NvU32))) + ((FERMI_WARP_EVENTS_ENTRY_PATCH_SIZE)*sizeof(NvU64)) - sizeof(NvU64));

                // Create BRANCH instruction
                cccBitsVal = 0;
                PRegBitsVal = 0;
                branchToExitPatchHi = 0;
                branchToExitPatchLo = 0;
                CU_FERMI_GET_CCC_BITS(code[i], cccBitsVal);
                CU_FERMI_GET_P_REG_BITS(code[i], PRegBitsVal);
                CU_FERMI_CREATE_BRANCH_INSTR(branchToExitPatchHi, branchToExitPatchLo, PRegBitsVal, cccBitsVal, branchTarget);
                (*patchCode)[i + 1] = branchToExitPatchHi;
                (*patchCode)[i]     = branchToExitPatchLo;
                i += 2;
            }
            else {
                // Copy 64bit instruction as it is
                (*patchCode)[i + 1] = code[i + 1];
                (*patchCode)[i]     = code[i];
                i += 2;
            }
        }
    }

    // ENTRY PATCH BEGINS
    for ( patchCodeIdx=0; patchCodeIdx<18 ; ) {
        (*patchCode)[funcCodeSize +  patchCodeIdx++] = fermiWarpEventCodeBinary[codeBinaryIdx++];
        (*patchCode)[funcCodeSize +  patchCodeIdx++] = fermiWarpEventCodeBinary[codeBinaryIdx++];
    }

    // move lmemAddress to R4 register
    CU_FERMI_CREATE_MOV32I_INSTR(mov32iInstrHi, mov32iInstrLo, REG_4, lmemAddress, P_REG_7)
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = mov32iInstrLo;
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = mov32iInstrHi;

    //local store absolute tid at lmemAddress
    codeBinaryIdx = patchCodeIdx;
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = fermiWarpEventCodeBinary[codeBinaryIdx++];
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = fermiWarpEventCodeBinary[codeBinaryIdx++];

    // Create SSY instruction with target at the BRA 0x0 instr in the code patch
    branchTarget = (36)*sizeof(NvU64);
    CU_FERMI_CREATE_SSY_INSTR(branchToStartInstrHi, branchToStartInstrLo, branchTarget)
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = branchToStartInstrLo;
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = branchToStartInstrHi;

    codeBinaryIdx = patchCodeIdx;
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = fermiWarpEventCodeBinary[codeBinaryIdx++];
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = fermiWarpEventCodeBinary[codeBinaryIdx++];

    // If tid%32 != 0, then branch to NOP.S instruction in the code patch
    branchTarget = (33)*sizeof(NvU64);
    CU_FERMI_CREATE_BRANCH_INSTR(branchToStartInstrHi, branchToStartInstrLo, P_REG_0, 0xf, branchTarget)
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = branchToStartInstrLo;
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = branchToStartInstrHi;

    pBufferAddress = (NvU64)(uintptr_t)ctx->profiler->warpEventData->pBufferPtr;
    pBufferAddressHi = (NvU32)(pBufferAddress >> 32);
    pBufferAddressLo = (NvU32)(pBufferAddress);

    CU_FERMI_CREATE_MOV32I_INSTR(mov32iInstrHi, mov32iInstrLo, REG_4, pBufferAddressLo, P_REG_7)
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = mov32iInstrLo;
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = mov32iInstrHi;

    CU_FERMI_CREATE_MOV32I_INSTR(mov32iInstrHi, mov32iInstrLo, REG_5, pBufferAddressHi, P_REG_7)
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = mov32iInstrLo;
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = mov32iInstrHi;

    codeBinaryIdx = patchCodeIdx;
    for ( ; patchCodeIdx<38; ) {
        (*patchCode)[funcCodeSize +  patchCodeIdx++] = fermiWarpEventCodeBinary[codeBinaryIdx++];
        (*patchCode)[funcCodeSize +  patchCodeIdx++] = fermiWarpEventCodeBinary[codeBinaryIdx++];
    }

    // if pBufferAddress = 0, then branch to NOP.S instruction in the code patch
    branchTarget = (27)*sizeof(NvU64);
    CU_FERMI_CREATE_BRANCH_INSTR(branchToStartInstrHi, branchToStartInstrLo, P_REG_0, 0xf, branchTarget)
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = branchToStartInstrLo;
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = branchToStartInstrHi;

    codeBinaryIdx = patchCodeIdx;
    for ( ; patchCodeIdx<90; ) {
        (*patchCode)[funcCodeSize +  patchCodeIdx++] = fermiWarpEventCodeBinary[codeBinaryIdx++];
        (*patchCode)[funcCodeSize +  patchCodeIdx++] = fermiWarpEventCodeBinary[codeBinaryIdx++];
    }

    // move lmemAddress to R0 register
    CU_FERMI_CREATE_MOV32I_INSTR(mov32iInstrHi, mov32iInstrLo, REG_0, lmemAddress, P_REG_7)
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = mov32iInstrLo;
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = mov32iInstrHi;

    // store actual buffer address for the warp to local memory
    codeBinaryIdx = patchCodeIdx;
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = fermiWarpEventCodeBinary[codeBinaryIdx++];
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = fermiWarpEventCodeBinary[codeBinaryIdx++];

    (*patchCode)[funcCodeSize +  patchCodeIdx++] = fermiWarpEventCodeBinary[codeBinaryIdx++];
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = fermiWarpEventCodeBinary[codeBinaryIdx++];

    // Unconditional branch to first instr in user kernel
    branchTarget = ((func->codeSize + (FERMI_WARP_EVENTS_ENTRY_PATCH_SIZE)*sizeof(NvU64))*(-1));
    CU_FERMI_CREATE_BRANCH_INSTR(branchToStartInstrHi, branchToStartInstrLo, P_REG_7, 0xf, branchTarget)
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = branchToStartInstrLo;
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = branchToStartInstrHi;

    // EXIT PATCH BEGINS

    // move lmemAddress to R0 register
    CU_FERMI_CREATE_MOV32I_INSTR(mov32iInstrHi, mov32iInstrLo, REG_0, lmemAddress, P_REG_7)
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = mov32iInstrLo;
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = mov32iInstrHi;

    // Load absolute tid stored during entry patch from local mem
    codeBinaryIdx = patchCodeIdx;
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = fermiWarpEventCodeBinary[codeBinaryIdx++];
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = fermiWarpEventCodeBinary[codeBinaryIdx++];

    // Load buffer address where warp event data is stored for the warp
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = fermiWarpEventCodeBinary[codeBinaryIdx++];
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = fermiWarpEventCodeBinary[codeBinaryIdx++];

    for ( ; patchCodeIdx<110; ) {
        (*patchCode)[funcCodeSize +  patchCodeIdx++] = fermiWarpEventCodeBinary[codeBinaryIdx++];
        (*patchCode)[funcCodeSize +  patchCodeIdx++] = fermiWarpEventCodeBinary[codeBinaryIdx++];
    }

    // Add pBufferAddressLo to R4
    CU_FERMI_CREATE_MOV32I_INSTR(mov32iInstrHi, mov32iInstrLo, REG_4, pBufferAddressLo, P_REG_7)
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = mov32iInstrLo;
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = mov32iInstrHi;

    // Add pBufferAddressHi to R5
    CU_FERMI_CREATE_MOV32I_INSTR(mov32iInstrHi, mov32iInstrLo, REG_5, pBufferAddressHi, P_REG_7)
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = mov32iInstrLo;
    (*patchCode)[funcCodeSize +  patchCodeIdx++] = mov32iInstrHi;

    codeBinaryIdx = patchCodeIdx;
    for ( ; patchCodeIdx<130; ) {
        (*patchCode)[funcCodeSize +  patchCodeIdx++] = fermiWarpEventCodeBinary[codeBinaryIdx++];
        (*patchCode)[funcCodeSize +  patchCodeIdx++] = fermiWarpEventCodeBinary[codeBinaryIdx++];
    }

#ifdef DEBUG_SASS
    funcPatchDumpSASSpatch((NvU32 *)cuiFuncGetCodeData(func, CU_CODE_DATA_MASTER), func->codeSize, *patchCode, *patchSize);
#endif

    return CUDA_SUCCESS;
}

static NvU32 fermiGetLDExrAddr(unsigned int origInstrHi)
{
    return (CU_FERMI_GET_LD_EXT_ADDR(origInstrHi));
}

static NvU32 fermiGetLDAddrReg(unsigned int origInstrLo)
{
    return (CU_FERMI_GET_LD_ADDR_REG(origInstrLo));
}

static NvU32 fermiGetLDImm32(unsigned int origInstrHi, unsigned int origInstrLo)
{
    return (CU_FERMI_GET_LD_IMM32(origInstrHi, origInstrLo));
}

// Function to create Branch Instruction
static void fermiCreateBraInst(NvU32* instHi, NvU32* instLo, NvU32 PRegBitsVal, NvU32 cccBitsVal, NvU32 branchTarget)
{
    CU_FERMI_CREATE_BRANCH_INSTR(*instHi, *instLo, PRegBitsVal, cccBitsVal, branchTarget);
}

static void fermiCreateStlInst(NvU32* instHi, NvU32* instLo, NvU32 lmemAddr, NvU32 reg)
{
    *instHi = STL_HI(lmemAddr, reg);
    *instLo = STL_LO(lmemAddr, reg);
}

static void fermiCreateP2rInst(NvU32* instHi, NvU32* instLo, NvU32 reg)
{
    *instHi = P2R_HI(reg);
    *instLo = P2R_LO(reg);
}

static void fermiCreateLdlInst(NvU32* instHi, NvU32* instLo, NvU32 reg, NvU32 lmemAddr)
{
    *instHi = LDL_HI(reg, lmemAddr);
    *instLo = LDL_LO(reg, lmemAddr);
}

// Function to create Move Instruction
static void fermiCreateMovInst(NvU32* instHi, NvU32* instLo, NvU32 destReg, NvU32 sourceReg)
{
    CU_FERMI_CREATE_MOV_INSTR(*instHi, *instLo, destReg, sourceReg);
}

// Function to create Move Instruction
static void fermiCreateMov32iInst(NvU32* instHi, NvU32* instLo, NvU32 reg, NvU32 value, NvU32 predReg)
{
    CU_FERMI_CREATE_MOV32I_INSTR(*instHi, *instLo, reg, value, predReg);
}

// Function to extract P Reg Bits from the code
static NvU32 fermiGetPRegBits(NvU32 code) 
{
    NvU32 pregBits;
    CU_FERMI_GET_P_REG_BITS(code, pregBits);
    return pregBits;
}

static void fermiCreateRedInst(NvU32* instHi, NvU32* instLo, NvU32 regA, NvU32 regB, NvU32 PRegBits)
{
    *instHi = RED_U32_ADD_HI(regA, regB);
    *instLo = RED_U32_ADD_LO(regA, regB, PRegBits);
}

static void fermiCreateR2pInst(NvU32* instHi, NvU32* instLo, NvU32 reg)
{
    *instHi = R2P_HI(reg);
    *instLo = R2P_LO(reg);
}

static NvU32 fermiCreateSrcBFieldFromRegister(NvU32 reg)
{
    return(CU_FERMI_CREATE_SRC_B_FIELD_FROM_REGISTER(reg));
}

static NvU32 fermiCreateSrcBFieldFromConstantAddress(NvU32 bankNumber, NvU32 bankOffset)
{
    return(CU_FERMI_CREATE_SRC_B_FIELD_FROM_CONSTANT_ADDRESS(bankNumber, bankOffset));
}

static void fermiCreateIsetpInst(NvU32 *instHi, NvU32 *instLo, NvU32 cmp, NvU32 bop, NvU32 predSrc, NvU32 abc,
           NvU32 srcB, NvU32 regA, NvU32 predDest)
{
    CU_FERMI_CREATE_ISETP_INSTR(*instHi, *instLo, cmp, bop, predSrc, abc, srcB, regA, predDest)
}

static void fermiCreatePsetpInst(NvU32 *instHi, NvU32 *instLo, NvU32 bop, NvU32 predSrc1, NvU32 predSrc2, NvU32 predDest)
{
    CU_FERMI_CREATE_PSETP_INSTR(*instHi, *instLo, bop, predSrc1, predSrc2, predDest)
}

static void fermiCreateLopInst(NvU32 *instHi, NvU32 *instLo)
{
    *instHi = FERMI_LOP_INSTR_HI_OPCODE;
    *instLo = FERMI_LOP_INSTR_LO_OPCODE;
}

static void fermiCreateNopInst(NvU32 *instHi, NvU32 *instLo, NvU32 trigFlag, NvU32 syncFlag, NvU32 mask, NvU32 pred)
{
    CU_FERMI_CREATE_NOP_INSTR(*instHi, *instLo, trigFlag, syncFlag, mask, pred)
}

static void fermiCreateRetInst(NvU32 *instHi, NvU32 *instLo, NvU32 PReg, NvU32 CCCbits)
{
    CU_FERMI_CREATE_RET_INSTR(*instHi, *instLo, PReg, CCCbits)
}

static void fermiCreateCalInst(NvU32 *instHi, NvU32 *instLo, NvU32 target)
{
    CU_FERMI_CREATE_CAL_INSTR(*instHi, *instLo, target)
}

static void fermiCreateJcalInst(NvU32 *instHi, NvU32 *instLo, NvU32 target)
{
    CU_FERMI_CREATE_JCAL_INSTR(*instHi, *instLo, target)
}

static void fermiCreateVoteInst(NvU32 *instHi, NvU32 *instLo)
{
    *instLo = CU_FERMI_VOTE_INSTR_LO_OPCODE;
    *instHi = CU_FERMI_VOTE_INSTR_HI_OPCODE;
}

static void fermiCreatePopcInst(NvU32 *instHi, NvU32 *instLo)
{
    *instLo = CU_FERMI_POPC_INSTR_LO_OPCODE;
    *instHi = CU_FERMI_POPC_INSTR_HI_OPCODE;
}

static void fermiCreateImul32iInst(NvU32 *instHi, NvU32 *instLo)
{
    *instLo = CU_FERMI_IMUL32I_INSTR_LO_OPCODE;
    *instHi = CU_FERMI_IMUL32I_INSTR_HI_OPCODE;
}

static void fermiCreateBrxInst(NvU32 *instHi, NvU32 *instLo)
{
    *instLo = CU_FERMI_BRX_INSTR_LO_OPCODE;
    *instHi = CU_FERMI_BRX_INSTR_HI_OPCODE;
}

static void fermiCreateSsyInst(NvU32 *instHi, NvU32 *instLo, NvU32 syncTarget)
{
    CU_FERMI_CREATE_SSY_INSTR(*instHi, *instLo, syncTarget)
}

static NvU32 fermiGetCCCBits(NvU32 code) 
{
    NvU32 cccBitsVal;

    CU_FERMI_GET_CCC_BITS(code, cccBitsVal);

    return cccBitsVal;
}

static NvU32 fermiIsExitInst(NvU32 instrHi, NvU32 instrLo)
{
    return (CU_FERMI_IS_EXIT_INSTR(instrHi, instrLo));
}

static void fermiCreateLdcInst(NvU32* instHi, NvU32* instLo, NvU32 cBank, NvU32 offset, NvU32 dest, NvU32 PReg)
{
    CU_FERMI_CREATE_LDC64_INSTR(*instHi, *instLo, cBank, offset, dest, PReg);
}

// Function to create LONGJMP Instruction
static void fermiCreateLongjmpInst(NvU32* instHi, NvU32* instLo, NvU32 PRegBitsVal, NvU32 cccBitsVal)
{
    CU_FERMI_CREATE_LONGJMP_INSTR(*instHi, *instLo, PRegBitsVal, cccBitsVal);
}

static void fermiCreateIaddInst(NvU32 *instHi, NvU32 *instLo, NvU32 xmFlag, NvU32 psign, NvU32 destReg, NvU32 ccFlag, NvU32 srcReg1, NvU32 srcReg2)
{
    CU_FERMI_CREATE_IADD_INSTR(*instHi, *instLo, xmFlag, psign, destReg, ccFlag, srcReg1, srcReg2);
}

static void fermiCreateJmpInst(NvU32 *instHi, NvU32 *instLo, NvU32 target)
{
    CU_FERMI_CREATE_JMP_INSTR(*instHi, *instLo, target)
}

static void fermiCreateShintInst(NvU32 *instHi, NvU32 *instLo, NvU64 hint)
{
    CU_ERROR_PRINT(("SHINT instruction is not on fermi.\n"));
    CU_ASSERT(0);
}

static void fermiCreateTexdepbarInst(NvU32 *instHi, NvU32 *instLo)
{
    *instLo = CU_FERMI_TEXDEPBAR_INSTR_LO_OPCODE;
    *instHi = CU_FERMI_TEXDEPBAR_INSTR_HI_OPCODE;
}

static NvU32 fermiIsJcalInst(NvU32 instHi, NvU32 instLo)
{
    return (CU_FERMI_IS_JCAL_INSTR(instHi, instLo));
}

static NvU32 fermiIsJmpInst(NvU32 instHi, NvU32 instLo)
{
    return (CU_FERMI_IS_JMP_INSTR(instHi, instLo));
}

static NvU32 fermiIsJmxInst(NvU32 instHi, NvU32 instLo)
{
    return (CU_FERMI_IS_JMX_INSTR(instHi, instLo));
}

// Function takes the current instruction as a parameter and produces
// 0 if the instruction is not JCAL or JMP
// 1 if the instruction is JCAL or JMP
static NvU32 fermiIsDirectCall(const NvU64 *inst)
{
    if (!inst)
        return 0;

    return (fermiIsJcalInst(EXTRACT_HI_WORD(*inst), EXTRACT_LO_WORD(*inst))
        || fermiIsJmpInst(EXTRACT_HI_WORD(*inst), EXTRACT_LO_WORD(*inst)));
}

// Function takes the current instruction as a parameter and produces
// 0 if the instruction is not JMX
// 1 if the instruction is JMX
static NvU32 fermiIsIndirectCall(const NvU64 *inst, NvU32 offset)
{
    if (!inst)
        return 0;

    return (fermiIsJmxInst(EXTRACT_HI_WORD(*inst), EXTRACT_LO_WORD(*inst)));
}

static int fermiGetPMSignalsIndex(NvU32 signalId)
{
    switch(signalId) {
        case FERMI_SW_COUNTER_GLD8BIT_INST:
        case FERMI_INTERNAL_SW_COUNTER_GLD8BIT_INST:
            return LD_INST_8BIT;

        case FERMI_SW_COUNTER_GLD16BIT_INST:
        case FERMI_INTERNAL_SW_COUNTER_GLD16BIT_INST:
            return LD_INST_16BIT;

        case FERMI_SW_COUNTER_GLD32BIT_INST:
        case FERMI_INTERNAL_SW_COUNTER_GLD32BIT_INST:
            return LD_INST_32BIT;

        case FERMI_SW_COUNTER_GLD64BIT_INST:
        case FERMI_INTERNAL_SW_COUNTER_GLD64BIT_INST:
            return LD_INST_64BIT;

        case FERMI_SW_COUNTER_GLD128BIT_INST:
        case FERMI_INTERNAL_SW_COUNTER_GLD128BIT_INST:
            return LD_INST_128BIT;

        case FERMI_SW_COUNTER_GST8BIT_INST:
        case FERMI_INTERNAL_SW_COUNTER_GST8BIT_INST:
            return ST_INST_8BIT;

        case FERMI_SW_COUNTER_GST16BIT_INST:
        case FERMI_INTERNAL_SW_COUNTER_GST16BIT_INST:
            return ST_INST_16BIT;

        case FERMI_SW_COUNTER_GST32BIT_INST:
        case FERMI_INTERNAL_SW_COUNTER_GST32BIT_INST:
            return ST_INST_32BIT;

        case FERMI_SW_COUNTER_GST64BIT_INST:
        case FERMI_INTERNAL_SW_COUNTER_GST64BIT_INST:
            return ST_INST_64BIT;

        case FERMI_SW_COUNTER_GST128BIT_INST:
        case FERMI_INTERNAL_SW_COUNTER_GST128BIT_INST:
            return ST_INST_128BIT;

        default: 
            break;
    }
    return -1;
}

// http://nvbugs/1268176 Data fetched from LDU is cached in constant cache. 
// It is not reflected in the L1 hit/miss as well as request from L1 to L2
// To keep the gld_requested_throughput consistent with gld_throughput LDU instruction is not patched
// Set/reset the following define to skip/count LDU instruction in s/w counters
#define SKIP_LDU_INST 1

static int fermiGetOpcodeIndex(NvU64 origOpcode,NvBool* canUseAddrWindows)
{
    NvU64 opcode = origOpcode;
    opcode &= MASK_BITS_LD_ST_INST;
    *canUseAddrWindows =NV_TRUE;
    switch(opcode) {
#if !(SKIP_LDU_INST)
        case LDU_INST_U8BIT_OPCODE:
        case LDU_INST_S8BIT_OPCODE:
            *canUseAddrWindows =NV_FALSE;
#endif
        case LD_INST_S8BIT_OPCODE:
        case LD_INST_U8BIT_OPCODE:
            return LD_INST_8BIT;

#if !(SKIP_LDU_INST)
        case LDU_INST_U16BIT_OPCODE:
        case LDU_INST_S16BIT_OPCODE:
            *canUseAddrWindows =NV_FALSE;
#endif
        case LD_INST_U16BIT_OPCODE:
        case LD_INST_S16BIT_OPCODE:
            return LD_INST_16BIT;

#if !(SKIP_LDU_INST)
        case LDU_INST_32BIT_OPCODE:
            *canUseAddrWindows =NV_FALSE;
#endif
        case LD_INST_32BIT_OPCODE:
            return LD_INST_32BIT;

#if !(SKIP_LDU_INST)
        case LDU_INST_64BIT_OPCODE:
            *canUseAddrWindows =NV_FALSE;
#endif
        case LD_INST_64BIT_OPCODE:
            return LD_INST_64BIT;

#if !(SKIP_LDU_INST)
        case LDU_INST_128BIT_OPCODE:
            *canUseAddrWindows =NV_FALSE;
#endif
        case LD_INST_128BIT_OPCODE:
            return LD_INST_128BIT;

        case ST_INST_U8BIT_OPCODE:
        case ST_INST_S8BIT_OPCODE:
            return ST_INST_8BIT;

        case ST_INST_U16BIT_OPCODE:
        case ST_INST_S16BIT_OPCODE:
            return ST_INST_16BIT;

        case ST_INST_32BIT_OPCODE:
            return ST_INST_32BIT;

        case ST_INST_64BIT_OPCODE:
            return ST_INST_64BIT;

        case ST_INST_128BIT_OPCODE:
            return ST_INST_128BIT;

        default:
            break;
    }
    return -1;
}

// The following function returns true if the kernel has a JMX instruction else it returns false
// This function will be common to Fermi and Kepler
static NvBool fermiKernelHasJmx(CUctx* ctx, const CUfunc *func, sassInstGen *sassInstGenPtr)
{
    NvU32 *code;
    NvU32 i, isFermiDevice = 0;
    unsigned int smVersion;
    smVersion = ctx->device->state.major*10 + ctx->device->state.minor;

    if(smVersion >=20 && smVersion < 30) {
        isFermiDevice = 1;
    }

    code = (NvU32*)cuiFuncGetCodeData(func, CU_CODE_DATA_MASTER);
    for(i = 0; i < func->codeSize/4;) {
        if(isFermiDevice && CU_FERMI_IS_32B_INSTR(code[i])) {
            // If its 32bit instruction, continue
            i += 1;
        }
        else {
            if(sassInstGenPtr->isJmxInst(code[i + 1], code[i])) {
                return NV_TRUE;
            }
            i +=2;
        }
    }
    return NV_FALSE;
}

/**************************************************************************************
fermiInsertAtomInstBasedPatch(): This function inserts a patch at the end of the present code.
    Creates a BRANCH inst to end of code in the place of original inst, stores R0-R3 in lmem,
    stores Predicate register, atomically increments sw counter stored at bufferPtr, restores
    all saved registers and then performs Original inst before Branching back to the user 
    kernel at the successive inst of the Original inst.
***************************************************************************************/
static void fermiInsertAtomInstBasedPatch(swCounterTable *swCounterTablePtr, sassInstGen *sassInstGenPtr, unsigned int origInstrLo, unsigned int origInstrHi,
                        void *bufferPtr,    // Address where count is incremented
                        NvU32 lmemAddress,  // lmemAddress where Registers can be stored.
                        NvU32 instPointer,  // Current instruction relative address
                        NvU64 funcStartPC,  // Current func start PC
                        NvU32 *patchCode,   // Actual address at the end of the present last instruction in the code
                        NvBool canUseAddrWindows) {  // flag for LD or ST instr. If LD or ST then check for generic LD or ST
    int i =0 ;
    NvU32 lmemAddr = 0;
    NvU32 PRegBitsVal = P_REG_7;
    NvU64 pBufferAddress = 0;
    NvU32 pBufferAddressLo = 0;
    NvU32 pBufferAddressHi = 0;
    NvU32 offset = 0;
    // Used for storing argument of LD instr 
    NvU32 addrRegLo = 0;
    NvU32 addrRegHi = 0;
    NvU32 isExtAddr = 0;

    // Throw an error if lmem size is not in range
    // Ideally this value should not exceed 96 bytes.
    // But keeping a tight bound for now
    ct_assert(CU_PROF_SW_COUNTER_LMEMSIZE <= 20);

    if(canUseAddrWindows) {
        isExtAddr = sassInstGenPtr->getLDExrAddr(origInstrHi);
        addrRegLo = sassInstGenPtr->getLDAddrReg(origInstrLo);

        // Same getLDImm32 can be used for LD and ST instruction
        offset = sassInstGenPtr->getLDImm32(origInstrHi, origInstrLo);

        // For 32 bit machine, set addregHi to RZ which has 0x0 value
        if(addrRegLo != sassInstGenPtr->regZ) {
            addrRegHi = isExtAddr ? addrRegLo + 1 : sassInstGenPtr->regZ;
        }
        else {
            addrRegHi = sassInstGenPtr->regZ;
        }
    }

    lmemAddr = lmemAddress;
/*******************************************************************************************************
    We donot use a predicated jump instruction as the kernel can have a barrier instruction and 
    behaviour of BAR instruction change in case of divergent code. Memcheck faced a similar issue.
    Please see http://nvbugs/687852. Hence we use the original predicate with the atomic add instruction.
*********************************************************************************************************/

    i =0 ;

    // Patch instruction #1
    // Store registers in local memory
    sassInstGenPtr->STL((patchCode + i + 1), (patchCode + i), lmemAddr, REG_0);
    i +=2;
    
    // Patch instruction #2
    lmemAddr += 4;
    sassInstGenPtr->STL((patchCode + i + 1), (patchCode + i), lmemAddr, REG_1);
    i +=2;
    
    // Patch instruction #3
    lmemAddr += 4;
    sassInstGenPtr->STL((patchCode + i + 1), (patchCode + i), lmemAddr, REG_2);
    i +=2;

    // Patch instruction #4
    lmemAddr += 4;
    sassInstGenPtr->STL((patchCode + i + 1), (patchCode + i), lmemAddr, REG_3);
    i +=2;

    // Patch instruction #5
    // Store predicate register in R3
    sassInstGenPtr->P2R((patchCode + i + 1), (patchCode + i), REG_3);
    i +=2;

    // Patch instruction #6
    // Store predicate reg to lmem  from R3
    lmemAddr += 4;
    sassInstGenPtr->STL((patchCode + i + 1), (patchCode + i), lmemAddr, REG_3);
    i +=2;

    // Patch instruction #7
    // Restore R3
    lmemAddr -= 4;
    sassInstGenPtr->LDL((patchCode + i + 1), (patchCode + i), REG_3, lmemAddr);
    i +=2;

    // Extract guard predicate from original instruction
    PRegBitsVal = sassInstGenPtr->getPRegBits(origInstrLo);

    if (canUseAddrWindows) {
        // Check the memory if it is global
        // For 64 bit 
        // if ((((addrLo & 0xff000000) == smemWinLo) || ((addrLo & 0xff000000) == lmemWinLo)) 
        //      && (addrHi == 0))
        // For 32 bit 
        // if ((((addrLo & 0xff000000) == smemWinLo) || ((addrLo & 0xff000000) == lmemWinLo)))

        // Patch instruction #8
        // Store original predicate to P0
        // ISETP.EQ.U32.AND P0, pt, RZ, RZ, PRegBitsVal;
        sassInstGenPtr->ISETP((patchCode + i + 1), (patchCode + i), CMP_EQ, BOP_AND, PRegBitsVal,
            ABC_RRR, sassInstGenPtr->createSrcBFieldFromRegister(sassInstGenPtr->regZ), sassInstGenPtr->regZ, P_REG_0);
        i +=2;

        // Logic followed to get original instruction address is
        // MOV R0, addrRegLo;
        // MOV R1, addrRegHi;
        // MOV32I R2, offset;
        // IADD R0.CC, R0, R2;
        // IADD.X R1, R1, RZ;

        // Patch instruction #9
        // Move register containing lower addr bits to R0
        sassInstGenPtr->MOV((patchCode + i + 1), (patchCode + i), REG_0, addrRegLo);
        i +=2;

        // Patch instruction #10
        // Move register containing hi addr bits to R1
        // For 32 bit machine, copying contents of RZ register to R1
        sassInstGenPtr->MOV((patchCode + i + 1), (patchCode + i), REG_1, addrRegHi);
        i +=2;

        // Patch instruction #11
        // Move offset to R2
        sassInstGenPtr->MOV32I((patchCode + i + 1), (patchCode + i), REG_2, offset, P_REG_7);
        i +=2;

        // Patch instruction #12
        sassInstGenPtr->IADD((patchCode + i + 1), (patchCode + i), !XM_FLAG, PSIGN_A_B_0, REG_0, CC_FLAG, REG_0, REG_2);
        i +=2;

        // Patch instruction #13
        sassInstGenPtr->IADD((patchCode + i + 1), (patchCode + i), XM_FLAG, PSIGN_A_B_0, REG_1, !CC_FLAG, REG_1, sassInstGenPtr->regZ);
        i +=2;

        // Patch instruction #14
        // Move address mask in R2 to mask higher 8 bits of addrLo
        sassInstGenPtr->MOV32I((patchCode + i + 1), (patchCode + i), REG_2, ADDRESS_MASK, P_REG_7);
        i +=2;

        // the following opcodes are generated using SASS2.exe utility
        // Patch instruction #15
        // Logical AND of addrLo with mask
        // LOP.AND     R0, R0, R2;
        sassInstGenPtr->LOP((patchCode + i + 1), (patchCode + i));
        i +=2;

        // Patch instruction #16
        // Compare with lmemWinLo
        // ISETP.EQ.U32.AND P1, pt, R0, c [0x0] [0x4], pt;
        sassInstGenPtr->ISETP((patchCode + i + 1), (patchCode + i), CMP_EQ, BOP_AND, P_REG_7,
            ABC_RCR, sassInstGenPtr->createSrcBFieldFromConstantAddress(0x0, swCounterTablePtr->lmemWinLo), REG_0, P_REG_1);
        i +=2;

        // Patch instruction #17
        // Compare with smemWinLo
        // ISETP.EQ.U32.OR P1, pt, R0, c [0x0] [0x0], P1;
        sassInstGenPtr->ISETP((patchCode + i + 1), (patchCode + i), CMP_EQ, BOP_OR, P_REG_1,
            ABC_RCR, sassInstGenPtr->createSrcBFieldFromConstantAddress(0x0, swCounterTablePtr->smemWinLo), REG_0, P_REG_1);
        i +=2;

        // Patch instruction #18
        // Check if AddrHi is zero
        // ISETP.EQ.U32.AND P1, pt, R1, RZ, P1;
        // This condition will always hold true for 32 bit machine as contents of R1 are set to 0x0
        // See patch instruction 9.
        sassInstGenPtr->ISETP((patchCode + i + 1), (patchCode + i), CMP_EQ, BOP_AND, P_REG_1,
            ABC_RRR, sassInstGenPtr->createSrcBFieldFromRegister(sassInstGenPtr->regZ), REG_1, P_REG_1);
        i +=2;

        // Patch instruction #19
        // PSETP.AND P0, P0, !P1
        sassInstGenPtr->PSETP((patchCode + i + 1), (patchCode + i), BOP_AND, P_REG_0, P_REG_N1, P_REG_0);
        i +=2;

        // Setting PRegBitsVal to P0.
        PRegBitsVal = P_REG_0;
    }

    // increment the counter by 1
    pBufferAddress = (NvU64)(uintptr_t)bufferPtr;
    pBufferAddressHi = (NvU32)(pBufferAddress >> 32);
    pBufferAddressLo = (NvU32)(pBufferAddress);

    // Patch instruction #20
    // Move buffer address
    sassInstGenPtr->MOV32I((patchCode + i + 1), (patchCode + i), REG_0, pBufferAddressLo, PRegBitsVal);
    i += 2;

    // Patch instruction #21
    // Move buffer address High
    sassInstGenPtr->MOV32I((patchCode + i + 1), (patchCode + i), REG_1, pBufferAddressHi, PRegBitsVal);
    i += 2;

    // Patch instruction #22
    // Move value 1 in R2
    sassInstGenPtr->MOV32I((patchCode + i + 1), (patchCode + i), REG_2, 1, PRegBitsVal);
    i += 2;

    // Patch instruction #23
    // atomic increment of counter based on predication of Original LD/ST/LDU instruction
    sassInstGenPtr->RED((patchCode + i + 1), (patchCode + i), REG_0, REG_2, PRegBitsVal);
    i += 2;

    // Patch instruction #24
    // Restore predicate reg stored in lmem to R3
    lmemAddr += 4;
    sassInstGenPtr->LDL((patchCode + i + 1), (patchCode + i), REG_3, lmemAddr);
    i += 2;

    // Patch instruction #25
    // Restore predicate register from R3
    sassInstGenPtr->R2P((patchCode + i + 1), (patchCode + i), REG_3);
    i += 2;

    // Patch instruction #26
    // Restore registers from local memory
    lmemAddr = lmemAddress;
    sassInstGenPtr->LDL((patchCode + i + 1), (patchCode + i), REG_0, lmemAddr);
    i += 2;

    // Patch instruction #27
    lmemAddr += 4;
    sassInstGenPtr->LDL((patchCode + i + 1), (patchCode + i), REG_1, lmemAddr);
    i += 2;

    // Patch instruction #28
    lmemAddr += 4;
    sassInstGenPtr->LDL((patchCode + i + 1), (patchCode + i), REG_2, lmemAddr);
    i += 2;

    // Patch instruction #29
    lmemAddr += 4;
    sassInstGenPtr->LDL((patchCode + i + 1), (patchCode + i), REG_3, lmemAddr);
    i += 2;

    // Patch instruction #30
    // Original Instruction
    patchCode[i++] = origInstrLo;
    patchCode[i++] = origInstrHi;

    // Patch instruction #31
    // Branch back to original PC
    sassInstGenPtr->JMP((patchCode + i + 1), (patchCode + i), ((NvU32)funcStartPC + instPointer + sizeof(NvU64)));

    return;
}

/**************************************************************************************
fermiInsertNopTrigBasedPatch(): This function inserts a routine at the end of the present code.
    stores R2 in lmem, stores Predicate register, issues NOP.TRIG instructions 
    restores all saved registers and then return 
***************************************************************************************/
static void fermiInsertNopTrigBasedPatch(swCounterTable *swCounterTablePtr, sassInstGen *sassInstGenPtr,
                        NvU32 *patchCode, // Actual address at the end of the present last instruction in the code
                        NvU32 lmemAddress,  // lmemAddress where Registers can be stored.
                        NvBool canUseAddrWindows, // if true then check for a generic address that can target local, shared or global windows
                        NvU32 mask) {  // Mask for NOP.TRIG
    int i =0, instAdded;
    NvU32 syncTarget;
    int branchTarget = 0;

    // Throw an error if lmem size is not in range
    // Ideally this value should not exceed 96 bytes.
    // But keeping a tight bound for now
    ct_assert(CU_PROF_NOPTRIG_SW_COUNTER_LMEMSIZE <= 16);

    // Check the memory if it is global
    // For 64 bit 
    // if ((((addrLo & 0xff000000) == smemWinLo) || ((addrLo & 0xff000000) == lmemWinLo)) 
    //      && (addrHi == 0))
    // For 32 bit 
    // if ((((addrLo & 0xff000000) == smemWinLo) || ((addrLo & 0xff000000) == lmemWinLo)))
    // R0 contains lower addr bits
    // R1 containing hi addr bits

    // Patch instruction #1
    // Move address mask in R2 to mask higher 8 bits of addrLo
    sassInstGenPtr->MOV32I((patchCode + i + 1), (patchCode + i), REG_2, ADDRESS_MASK, P_REG_7);
    i +=2;

    // the following opcodes are generated using SASS2.exe utility
    // Patch instruction #2
    // Logical AND of addrLo with mask
    // LOP.AND     R0, R0, R2;
    sassInstGenPtr->LOP((patchCode + i + 1), (patchCode + i));
    i +=2;

    // Patch instruction #3
    // Compare with lmemWinLo
    // ISETP.EQ.U32.AND P1, pt, R0, c [0x0] [0x4], pt;
    sassInstGenPtr->ISETP((patchCode + i + 1), (patchCode + i), CMP_EQ, BOP_AND, P_REG_7,
        ABC_RCR, sassInstGenPtr->createSrcBFieldFromConstantAddress(0x0, swCounterTablePtr->lmemWinLo), REG_0, P_REG_1);
    i +=2;

    // Patch instruction #4
    // Compare with smemWinLo
    // ISETP.EQ.U32.OR P1, pt, R0, c [0x0] [0x0], P1;
    sassInstGenPtr->ISETP((patchCode + i + 1), (patchCode + i), CMP_EQ, BOP_OR, P_REG_1,
        ABC_RCR, sassInstGenPtr->createSrcBFieldFromConstantAddress(0x0, swCounterTablePtr->smemWinLo), REG_0, P_REG_1);
    i +=2;

    // Patch instruction #5
    // Check if AddrHi is zero
    // ISETP.EQ.U32.AND P1, pt, R1, RZ, P1;
    // This condition will always hold true for 32 bit machine as contents of R1 are set to 0x0
    // See patch instruction 9.
    sassInstGenPtr->ISETP((patchCode + i + 1), (patchCode + i), CMP_EQ, BOP_AND, P_REG_1,
        ABC_RRR, sassInstGenPtr->createSrcBFieldFromRegister(sassInstGenPtr->regZ), REG_1, P_REG_1);
    i +=2;

    // Patch instruction #6
    // PSETP.AND P0, P0, !P1
    sassInstGenPtr->PSETP((patchCode + i + 1), (patchCode + i), BOP_AND, P_REG_N1, P_REG_0, P_REG_0);
    i +=2;

    // Patch instruction #7
    // SSY <inst 46>
    syncTarget = 40 * sizeof(NvU64);
    sassInstGenPtr->SSY((patchCode + i + 1), (patchCode + i), syncTarget);
    i +=2;

    // Patch instruction #8
    // Branch to NOP.S
    branchTarget = 38 * sizeof(NvU64);
    sassInstGenPtr->BRA((patchCode + i + 1), (patchCode + i), P_REG_N0, CCC_BITS_CC_T, branchTarget);
    i +=2;

    // Patch instruction #9
    // VOTE instruction to enable bits of R0 register
    // for all active threads in the warp
    sassInstGenPtr->VOTE((patchCode + i + 1), (patchCode + i));
    i +=2;

    // Patch instruction #10
    // Population count instruction to count enabled bits in RO
    // Store it in R0
    sassInstGenPtr->POPC((patchCode + i + 1), (patchCode + i));
    i +=2;

    // Patch instruction #11
    // Move 32 to R1
    sassInstGenPtr->MOV32I((patchCode + i + 1), (patchCode + i), REG_1, 32, P_REG_7);
    i +=2;

    // Patch instruction #12
    // Subtract R1 for R0. Store in RO
    sassInstGenPtr->IADD((patchCode + i + 1), (patchCode + i), !XM_FLAG, PSIGN_A_NB_1, REG_0, !CC_FLAG, REG_1, REG_0);
    i +=2;

    // Patch instruction #13
    // Multiply 8 to RO. Store in RO
    sassInstGenPtr->IMUL32I((patchCode + i + 1), (patchCode + i));
    i +=2;

    // Patch instruction #14
    // Uncoditional jump to relative value stored in R0
     sassInstGenPtr->BRX((patchCode + i + 1), (patchCode + i));
     i +=2;

    // Patch instruction #15 - #46
    // Insert 32 NOP.TRIG
    //Suppose 15 warps execute the instruction then skip first 17 NOP.TRIG
    //and issue the next 15 NOP.TRIG
    instAdded = i;
    for(;i < instAdded + 64; i += 2) {
        sassInstGenPtr->NOP((patchCode+i+1), (patchCode+i), !SYNC_FLAG, TRIG_FLAG, mask, P_REG_7);
    }

    // Patch instruction #47
    sassInstGenPtr->NOP((patchCode+i+1), (patchCode+i), SYNC_FLAG, !TRIG_FLAG, 0x0, P_REG_7);
    i += 2;

    // Patch instruction #48
    // Restore predicate reg stored in lmem to R2
    // lmem[lmemAddr + 12] = PR
    // lmem[lmemAddr + 8] = R2
    // lmem[lmemAddr + 4] = R1
    // lmem[lmemAddr + 0] = R0
    sassInstGenPtr->LDL((patchCode+i+1), (patchCode+i), REG_2, lmemAddress + LMEM_OFF_PR);
    i += 2;

    // Patch instruction #49
    // Restore predicate register from R2
    sassInstGenPtr->R2P((patchCode+i+1), (patchCode+i), REG_2);
    i += 2;

    // Patch instruction #50
    // Restore registers from local memory
    sassInstGenPtr->LDL((patchCode+i+1), (patchCode+i), REG_0, lmemAddress + LMEM_OFF_R0);
    i += 2;

    // Patch instruction #51
    sassInstGenPtr->LDL((patchCode+i+1), (patchCode+i), REG_1, lmemAddress + LMEM_OFF_R1);
    i += 2;

    // Patch instruction #52
    sassInstGenPtr->LDL((patchCode+i+1), (patchCode+i), REG_2, lmemAddress + LMEM_OFF_R2);
    i += 2;

    // Patch instruction #53
    // Return
    sassInstGenPtr->RET((patchCode+i+1), (patchCode+i), P_REG_7, CCC_BITS_CC_T);

    return;
}

/**************************************************************************************
fermiInsertPatchPerInstOccurence(): This function inserts a patch at the end of the present code.
    Creates a BRANCH inst to end of code in the place of original inst, stores R0-R3 in lmem,
    stores Predicate register, atomically increments sw counter stored at bufferPtr, restores
    all saved registers and then performs Original inst before Branching back to the user 
    kernel at the successive inst of the Original inst.
***************************************************************************************/
static void fermiInsertPatchPerInstOccurence(swCounterTable *swCounterTablePtr, sassInstGen *sassInstGenPtr, unsigned int origInstrLo, unsigned int origInstrHi,
                        NvU32 lmemAddress,  // lmemAddress where Registers can be stored.
                        NvU32 instPointer,  // Current instruction relative address
                        NvU32 patchAddr,    // Relative address where patch needs to be added. (This is at end of code)
                        NvU64 funcStartPC,  // Current func start PC
                        NvU32 *patchCode,   // Actual address at the end of the present last instruction in the code
                        NvU32 nopPatchAddr, // Relative address where NOP patch is addded.
                        NvBool canUseAddrWindows) {  // if true then check for a generic address that can target local, shared or global windows
    int i =0 ;
    NvU32 PRegBitsVal = P_REG_7;
    NvU32 calTarget;
    NvU32 offset = 0;

    // Used for storing argument of LD instr 
    NvU32 addrRegLo = 0;
    NvU32 addrRegHi = 0;
    NvU32 isExtAddr = 0;

    if(canUseAddrWindows) {
        isExtAddr = sassInstGenPtr->getLDExrAddr(origInstrHi);
        addrRegLo = sassInstGenPtr->getLDAddrReg(origInstrLo);

        // Same getLDImm32 can be used for LD and ST instruction
        offset = sassInstGenPtr->getLDImm32(origInstrHi, origInstrLo);

        // For 32 bit machine, set addregHi to RZ which has 0x0 value
        if(addrRegLo != sassInstGenPtr->regZ) {
            addrRegHi = isExtAddr ? addrRegLo + 1 : sassInstGenPtr->regZ;
        }
        else {
            addrRegHi = sassInstGenPtr->regZ;
        }
    }

/*******************************************************************************************************
    We donot use a predicated jump instruction as the kernel can have a barrier instruction and 
    behaviour of BAR instruction change in case of divergent code. Memcheck faced a similar issue.
    Please see http://nvbugs/687852. Hence we use the original predicate with the atomic add instruction.
*********************************************************************************************************/
    i =0 ;

    // Patch instruction #1
    if(swCounterTablePtr->smVersion >= 30) {
        // Insert TEXDEPBAR for Kepler
        sassInstGenPtr->TEXDEPBAR((patchCode + i + 1), (patchCode + i));
    }
    else {
        // Insert a NOP for Fermi
        sassInstGenPtr->NOP((patchCode + i + 1), (patchCode + i), !SYNC_FLAG, !TRIG_FLAG, 0x0, P_REG_7);
    }
    i += 2;

    // Patch instruction #2
    // Store registers in local memory
    sassInstGenPtr->STL((patchCode + i + 1), (patchCode + i), lmemAddress + LMEM_OFF_R0, REG_0);
    i +=2;
    
    // Patch instruction #3
    sassInstGenPtr->STL((patchCode + i + 1), (patchCode + i), lmemAddress + LMEM_OFF_R1, REG_1);
    i +=2;

    // Patch instruction #4
    sassInstGenPtr->STL((patchCode + i + 1), (patchCode + i), lmemAddress + LMEM_OFF_R2, REG_2);
    i +=2;

    // Patch instruction #5
    // Store predicate register in R2
    sassInstGenPtr->P2R((patchCode + i + 1), (patchCode + i), REG_2);
    i +=2;

    // Patch instruction #6
    // Store predicate reg to lmem  from R2
    sassInstGenPtr->STL((patchCode + i + 1), (patchCode + i), lmemAddress + LMEM_OFF_PR, REG_2);
    i +=2;

    // Extract guard predicate from original instruction
    PRegBitsVal = sassInstGenPtr->getPRegBits(origInstrLo);

    // Patch instruction #7
    // Store original predicate to P0
    // ISETP.EQ.U32.AND P0, pt, RZ, RZ, PRegBitsVal;
    sassInstGenPtr->ISETP((patchCode + i + 1), (patchCode + i), CMP_EQ, BOP_AND, PRegBitsVal,
        ABC_RRR, sassInstGenPtr->createSrcBFieldFromRegister(sassInstGenPtr->regZ), sassInstGenPtr->regZ, P_REG_0);
    i +=2;

    // Patch instruction #8
    // Restore contents of R2 back as it may contain the address in original instruction
    sassInstGenPtr->LDL((patchCode+i+1), (patchCode+i), REG_2, lmemAddress + LMEM_OFF_R2);
    i += 2;
    if (canUseAddrWindows) {
        // Logic followed to get original instruction address is
        // MOV R0, addrRegLo;
        // MOV R1, addrRegHi;
        // MOV32I R2, offset;
        // IADD R0.CC, R0, R2;
        // IADD.X R1, R1, RZ;

        // Patch instruction #9
        // Move register containing lower addr bits to R0
        sassInstGenPtr->MOV((patchCode + i + 1), (patchCode + i), REG_0, addrRegLo);
        i +=2;

        // Patch instruction #10
        // Move register containing hi addr bits to R1
        // For 32 bit machine, copying contents of RZ register to R1
        sassInstGenPtr->MOV((patchCode + i + 1), (patchCode + i), REG_1, addrRegHi);
        i +=2;

        // Patch instruction #11
        // Move offset to R2
        sassInstGenPtr->MOV32I((patchCode + i + 1), (patchCode + i), REG_2, offset, P_REG_7);
        i +=2;

        // Patch instruction #12
        sassInstGenPtr->IADD((patchCode + i + 1), (patchCode + i), !XM_FLAG, PSIGN_A_B_0, REG_0, CC_FLAG, REG_0, REG_2);
        i +=2;

        // Patch instruction #13
        sassInstGenPtr->IADD((patchCode + i + 1), (patchCode + i), XM_FLAG, PSIGN_A_B_0, REG_1, !CC_FLAG, REG_1, sassInstGenPtr->regZ);
        i +=2;

    }

    // TARGET = Relative address where patch is being added
    //          + Location of CAL in the patch
    //          - Relative address where NOP patch is addded
    calTarget = (patchAddr + (i + 2) * sizeof(NvU32) - nopPatchAddr) * -1;
    if(!canUseAddrWindows) {
        // Skip the first 6 instructions which are specific to generic instruction
        calTarget += PATCH_LDU_SKIP_INST_SIZE;
    }

    // Patch instruction #14
    // Call common routine for generic LD/ST inst for gld/gst_inst_xxxbit
    sassInstGenPtr->CAL((patchCode+i+1), (patchCode+i), calTarget);
    i += 2;

    // Patch instruction #15
    // Original Instruction
    patchCode[i++] = origInstrLo;
    patchCode[i++] = origInstrHi;

    // Patch instruction #16
    sassInstGenPtr->JMP((patchCode+i+1), (patchCode+i), ((NvU32)funcStartPC + instPointer + sizeof(NvU64)));

    return;
}

static CUresult fermiFuncInsertICachePadding(sassInstGen *sassInstGenPtr,
                        NvU32 *patchCode,   // Actual address at the end of the present last instruction in the code
                        NvU32 numPadInstRequired) {
    // The WAR is not applicable for fermi
    return CUDA_SUCCESS;
}

swCounterTable fermiSwCounterTable = {
    FERMI_NOPTRIG_SW_COUNTERS_DOMAIN,
    0, // Placeholder for SM Version
    CU_PROF_SW_COUNTER_NUMREGS,
    CU_PROF_SW_COUNTER_LMEMSIZE,
    COMMON_ROUTINE_PATCH_SIZE,
    PER_GLOBAL_ADDR_WINDOW_INST_OCCURENCE_PATCH_SIZE,
    PER_GENERIC_ANY_ADDR_WINDOW_INST_OCCURENCE_PATCH_SIZE,
    FERMI_SWINLO,
    FERMI_LWINLO,
    NULL,
    0,
    &fermiGetPMSignalsIndex,
    &fermiGetOpcodeIndex,
    &fermiInsertAtomInstBasedPatch,
    &fermiInsertNopTrigBasedPatch,
    &fermiInsertPatchPerInstOccurence,
    &fermiKernelHasJmx,
};

// Top level Function that modifies code to collect concurrent kernel trace
static CUresult 
fermiFuncCollectConcKernelTrace(CUctx* ctx, const CUfunc* func, profilerHal *profilerHalPtr,
                         NvU32** patchedCode, NvU32* patchedSize)
{
    // patchedCode contains the patched original code
    // i.e. with EXITs replaced with longjmp
    // patchCode contains the Entry + Exit Patch
    CUresult status = CUDA_SUCCESS;
    unsigned int i;
    unsigned int funcCodeSize;
    unsigned int patchCodeIdx = 0;
    unsigned int *code;
    NvU32 cccBitsVal = 0;
    NvU32 PRegBitsVal = 0;
    NvU32 jcalTarget = 0;
    NvU32 ldc64instrHi = 0;
    NvU32 ldc64instrLo = 0;
    NvU32 cbankNumber = 0;
    NvU32 cbankOffset = 0;
    sassInstGen *sassInstGenPtr = profilerHalPtr->sassInstGenPtr;
    NvU32 *patchCode, patchSize;
    CUmemobj *memobj = NULL;
    NvU64 patchCodePC;

    // Modify LDC.64 c[][] instruction with cbank number and offset and create statment again
    // Insert this statement in entry and exit patches
    cbankNumber = ctx->profiler->concKernelTraceData->constBankNumber;
    cbankOffset = ctx->profiler->concKernelTraceData->offsetInBytes;

    sassInstGenPtr->LDC(&ldc64instrHi, &ldc64instrLo, cbankNumber, cbankOffset, REG_4, P_REG_7);
    fermiConcKernelTraceEntryBinaryPatch[LDC_INST_ENTRY_PATCH]     = ldc64instrLo;
    fermiConcKernelTraceEntryBinaryPatch[LDC_INST_ENTRY_PATCH + 1] = ldc64instrHi;

    fermiConcKernelTraceExitBinaryPatch[LDC_INST_EXIT_PATCH]     = ldc64instrLo;
    fermiConcKernelTraceExitBinaryPatch[LDC_INST_EXIT_PATCH + 1] = ldc64instrHi;
    

    // Start creating patch
    code = (unsigned int*)cuiFuncGetCodeData(func, CU_CODE_DATA_MASTER);

    funcCodeSize = func->codeSize/4;
    patchSize = sizeof(fermiConcKernelTraceEntryBinaryPatch) + sizeof(fermiConcKernelTraceExitBinaryPatch);
    patchCode = (NvU32*)malloc(patchSize);
    if(!patchCode) {
        CU_DEBUG_PRINT(("Failed to allocate storage for patchCode.\n"));
        status = CUDA_ERROR_OUT_OF_MEMORY;
        return status;
    }

    *patchedSize = func->codeSize;
    *patchedCode = (NvU32*)malloc(func->codeSize);
    if(!(*patchedCode)) {
        CU_DEBUG_PRINT(("Failed to allocate storage for patchCode.\n"));
        status = CUDA_ERROR_OUT_OF_MEMORY;
        free (patchCode);
        patchCode = NULL;
        return status;
    }

    for (i = 0; i < funcCodeSize; ) {
        if(CU_FERMI_IS_32B_INSTR(code[i])) {
            // If its 32bit instruction, copy 
            // only 32bits as they are
            (*patchedCode)[i]     = code[i];
            i += 1;
        }
        else {
            if (sassInstGenPtr->isExitInst(code[i + 1], code[i])) {
                 // Replace EXIT instruction with LONGJMP to exit patch

                // Create LONGJMP instruction
                cccBitsVal = 0;
                PRegBitsVal = 0;
                cccBitsVal = sassInstGenPtr->getCCCBits(code[i]);
                PRegBitsVal = sassInstGenPtr->getPRegBits(code[i]);
                sassInstGenPtr->LONGJMP(((*patchedCode) + i + 1), ((*patchedCode) + i), PRegBitsVal, cccBitsVal);
                i += 2;
            }
            else {
                (*patchedCode)[i + 1] = code[i + 1];
                (*patchedCode)[i]     = code[i];
                i +=2;
            }
        }
    }

    for (patchCodeIdx = 0; patchCodeIdx < (sizeof(fermiConcKernelTraceEntryBinaryPatch)/4); ) {  
        patchCode[patchCodeIdx + 1] = fermiConcKernelTraceEntryBinaryPatch[patchCodeIdx + 1];
        patchCode[patchCodeIdx]     = fermiConcKernelTraceEntryBinaryPatch[patchCodeIdx];
        patchCodeIdx +=2;
    }

    // Unconditional JCAL first instr in user kernel
    jcalTarget = (NvU32)ctx->device->hal.funcGetStartPC((CUfunc *)func);
    sassInstGenPtr->JCAL((patchCode + CAL_INST_ENTRY_PATCH + 1), (patchCode + CAL_INST_ENTRY_PATCH), jcalTarget);

    for (i=0 ; patchCodeIdx < ((sizeof(fermiConcKernelTraceEntryBinaryPatch) + sizeof(fermiConcKernelTraceExitBinaryPatch))/4); ) {  
        patchCode[patchCodeIdx + 1] = fermiConcKernelTraceExitBinaryPatch[i + 1];
        patchCode[patchCodeIdx]     = fermiConcKernelTraceExitBinaryPatch[i];
        patchCodeIdx +=2;
        i += 2;
    }

    if(!ctx->profiler->concKernelTraceData->memobjList) {
        // memobjList hasn't been initialized yet, do it now
        status = listInit(&ctx->profiler->concKernelTraceData->memobjList, NULL, NULL, NULL, NULL);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to init linked list\n"));
            return status;
        }
    }
    // Allocate memory for the patch code
    status = cuiFuncAlloc(ctx, ctx->api, patchSize, func->codeAlign, &memobj);
    if (status != CUDA_SUCCESS) {
        return status;
    }

    status = listAddToTail(ctx->profiler->concKernelTraceData->memobjList, memobj);
    if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to add new data to linked list\n"));
            return status;
    }

    patchCodePC = ctx->device->hal.memobjGetPc(ctx, memobj);
    CU_ASSERT((patchCodePC % 8) == 0);

    CU_TRACE_PRINT(("Uploading patch code for function: %s (%u) to GPU VA 0x%llx\n",
            func->name, func->symbolIndex, memobjGetDeviceVaddr(memobj)));
    status = cuiMemcpyHtoD(
        ctx,
        memobj,
        0,
        patchCode,
        patchSize,
        ctx->barrierStream,
        CUI_MEMCPY_ASYNC_EXCEPT_PAGEABLE,
        NULL);
    if (status != CUDA_SUCCESS) {
        return status;
    }

    // Set offset to point to start of entry patch
    ((profFuncState_st *)(func->profFuncState))->pcOffset = (NvU32)patchCodePC - jcalTarget;

#ifdef DEBUG_SASS
    funcPatchDumpSASSpatch((NvU32 *)cuiFuncGetCodeData(func, CU_CODE_DATA_MASTER), func->codeSize, *patchedCode, *patchedSize);
    funcPatchDumpSASSpatch((NvU32 *)*patchedCode, *patchedSize, patchCode, patchSize);
#endif

    free(patchCode);
    patchCode = NULL;

    return status;
}


static CUresult 
fermiFuncPatchConcKernelTraceSyncKernel(CUctx* ctx, const CUfunc* func,
                                        NvU32** patchCode, NvU32* patchSize)
{
    CUresult status = CUDA_SUCCESS;
    unsigned int patchCodeIdx = 0;
    NvU32 ldc64instrHi = 0;
    NvU32 ldc64instrLo = 0;
    NvU32 cbankNumber = 0;
    NvU32 cbankOffset = 0;

    // Modify LDC.64 c[][] instruction with cbank number and offset and create statment again
    // Insert this statement in entry and exit patches
    cbankNumber = ctx->profiler->concKernelTraceData->constBankNumber;
    cbankOffset = ctx->profiler->concKernelTraceData->offsetInBytes;

    CU_FERMI_CREATE_LDC64_INSTR(ldc64instrHi, ldc64instrLo, cbankNumber, cbankOffset, REG_0, P_REG_7);
    fermiConcKernelTraceSyncKernelBinary[LDC_INST_SYNC_KERNEL_PATCH]     = ldc64instrLo;
    fermiConcKernelTraceSyncKernelBinary[LDC_INST_SYNC_KERNEL_PATCH + 1] = ldc64instrHi;

    *patchSize = CONC_KERNEL_TRACE_SYNC_KERNEL_PATCH_SIZE;

    *patchCode = (NvU32*)malloc(*patchSize);
    if(!(*patchCode)) {
        CU_DEBUG_PRINT(("Failed to allocate storage for patchCode.\n"));
        status = CUDA_ERROR_OUT_OF_MEMORY;
        return status;
    }

    for (patchCodeIdx = 0; patchCodeIdx < ((CONC_KERNEL_TRACE_SYNC_KERNEL_PATCH_SIZE)/4); ) {  
        (*patchCode)[patchCodeIdx + 1] = fermiConcKernelTraceSyncKernelBinary[patchCodeIdx + 1];
        (*patchCode)[patchCodeIdx]     = fermiConcKernelTraceSyncKernelBinary[patchCodeIdx];
        patchCodeIdx +=2;
    }

#ifdef DEBUG_SASS
    funcPatchDumpSASSpatch((NvU32 *)cuiFuncGetCodeData(func, CU_CODE_DATA_MASTER), func->codeSize, *patchCode, *patchSize);
#endif

    return status;
}

static CUresult fermiFuncLocateSSYs(CUctx* ctx, CUfunc* func)
{
    CU_ERROR_PRINT(("Locate SSY unsupported on fermi.\n"));
    CU_ASSERT(0);
    return CUDA_ERROR_UNKNOWN;
}

static CUresult fermiFuncPatchInstructions(CUctx* ctx, const CUfunc* func, NvU32** patchCode, NvU32* patchSize, CUprofPatchNopTrig* profPatchNopTrig)
{
    CU_ERROR_PRINT(("NOP trigger patching unsupported on fermi.\n"));
    CU_ASSERT(0);
    return CUDA_ERROR_UNKNOWN;
}

static CUresult fermiFuncCountBlockOnSM(CUctx* ctx, const CUfunc* func, NvU32** patchCode, NvU32* patchSize, CUprofPatchNopTrig* profPatchNopTrig)
{
    CU_ERROR_PRINT(("sm_cta_lauched through patching unsupported on fermi.\n"));
    CU_ASSERT(0);
    return CUDA_ERROR_UNKNOWN;
}

CUresult 
fermiFuncApplyReloc(CUctx* ctx, CUfunc* func, profilerHal* profilerHalPtr,
                                        NvU32** patchCode, NvU32 patchSize)
{
    CUresult status = CUDA_SUCCESS;
    CUmemobj *memobj = NULL;
    NvU64 patchCodeStartPC;
    NvU32 *code;
    NvU32 jmpTarget;
    NvU32 instPointer;
    NvU32 i;

    if(!ctx->pmNew->egSwCounters->memobjList) {
        // memobjList hasn't been initialized yet, do it now
        status = listInit(&ctx->pmNew->egSwCounters->memobjList, NULL, NULL, NULL, NULL);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to init linked list\n"));
            return status;
        }
    }
    // Allocate memory for the patched code
    status = cuiFuncAlloc(ctx, ctx->api, patchSize, func->codeAlign, &memobj);
    if (status != CUDA_SUCCESS) {
        return status;
    }

    status = listAddToTail(ctx->pmNew->egSwCounters->memobjList, memobj);
    if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to add new data to linked list\n"));
            return status;
    }

    patchCodeStartPC = ctx->device->hal.memobjGetPc(ctx, memobj);
    CU_ASSERT((patchCodeStartPC % 8) == 0);

    CU_TRACE_PRINT(("Uploading patch code for function: %s (%u) to GPU VA 0x%llx\n",
            func->name, func->symbolIndex, memobjGetDeviceVaddr(memobj)));
    status = cuiMemcpyHtoD(
        ctx,
        memobj,
        0,
        *patchCode,
        patchSize,
        ctx->barrierStream,
        CUI_MEMCPY_ASYNC_EXCEPT_PAGEABLE,
        NULL);
    if (status != CUDA_SUCCESS) {
        return status;
    }

    free(*patchCode);
    *patchCode = NULL;

    // allocate memory for CU_CODE_DATA_ORIGINAL and return if error.
    func->codeData[CU_CODE_DATA_ORIGINAL] = (unsigned char*)malloc( func->codeAlign + func->codeSize );
    if ( ! func->codeData[CU_CODE_DATA_ORIGINAL] ) {
        CU_DEBUG_PRINT(("Failed to allocate storage for CU_CODE_DATA_TEMP.\n"));
        return CUDA_ERROR_OUT_OF_MEMORY;
    }
    memcpy(cuiFuncGetCodeData(func, CU_CODE_DATA_ORIGINAL), cuiFuncGetCodeData(func, CU_CODE_DATA_MASTER), func->codeSize);

    code = (NvU32 *)cuiFuncGetCodeData(func, CU_CODE_DATA_MASTER);
    for(i = 0; i < profilerHalPtr->swCounterTablePtr->numInstPatched; i++) {
        instPointer = profilerHalPtr->swCounterTablePtr->relocPcPtr[i].origInstPc/sizeof(NvU32);
        jmpTarget = (NvU32)patchCodeStartPC + profilerHalPtr->swCounterTablePtr->relocPcPtr[i].patchCodeFirstInstPc;
        profilerHalPtr->sassInstGenPtr->JMP((code+instPointer+1), (code+instPointer), jmpTarget);
    }

    profilerHalPtr->swCounterTablePtr->numInstPatched = 0;
    free(profilerHalPtr->swCounterTablePtr->relocPcPtr);
    profilerHalPtr->swCounterTablePtr->relocPcPtr = NULL;

#ifdef DEBUG_SASS
    funcPatchDumpSASSpatch((NvU32 *)cuiFuncGetCodeData(func, CU_CODE_DATA_ORIGINAL), func->codeSize, (NvU32 *)cuiFuncGetCodeData(func, CU_CODE_DATA_MASTER), func->codeSize);
#endif

    return status;
}

sassInstGen fermiSassInstGen = {
    REG_63,
    FERMI_INST_SIZE_BYTES,
    &fermiGetLDExrAddr,
    &fermiGetLDAddrReg,
    &fermiGetLDImm32,
    &fermiCreateSrcBFieldFromRegister,
    &fermiCreateSrcBFieldFromConstantAddress,
    &fermiGetPRegBits,
    &fermiIsExitInst,
    &fermiGetCCCBits,
    &fermiIsJcalInst,
    &fermiIsJmpInst,
    &fermiIsJmxInst,
    &fermiIsDirectCall,
    &fermiIsIndirectCall,
    &fermiCreateBraInst,
    &fermiCreateStlInst,
    &fermiCreateP2rInst,
    &fermiCreateLdlInst,
    &fermiCreateMovInst,
    &fermiCreateMov32iInst,
    &fermiCreateRedInst,
    &fermiCreateR2pInst,
    &fermiCreateIsetpInst,
    &fermiCreatePsetpInst,
    &fermiCreateLopInst,
    &fermiCreateNopInst,
    &fermiCreateRetInst,
    &fermiCreateCalInst,
    &fermiCreateJcalInst,
    &fermiCreateVoteInst,
    &fermiCreatePopcInst,
    &fermiCreateImul32iInst,
    &fermiCreateBrxInst,
    &fermiCreateSsyInst,
    &fermiCreateLdcInst,
    &fermiCreateLongjmpInst,
    &fermiCreateIaddInst,
    &fermiCreateJmpInst,
    &fermiCreateShintInst,
    &fermiCreateTexdepbarInst,
};

// Function to initialize Tables in Profiler Hal Structure
CUresult fermiFuncInitializeTables(NvU32 smVersion, profilerHal* profHal)
{
    if(!profHal->swCounterTablePtr) {
        return CUDA_ERROR_UNKNOWN;
    }
    profHal->sassInstGenPtr = &fermiSassInstGen;
    memcpy(profHal->swCounterTablePtr, &fermiSwCounterTable, sizeof(swCounterTable));

    profHal->swCounterTablePtr->smVersion = smVersion;

    // Remove the following conditions during clean up.
    if(profHal->patchFlag & CU_PROF_PATCH_FLAG_NOPTRIG_SW_COUNTER) {
        profHal->swCounterTablePtr->swCountersDomain = FERMI_NOPTRIG_SW_COUNTERS_DOMAIN;
        profHal->swCounterTablePtr->numReg = CU_PROF_NOPTRIG_SW_COUNTER_NUMREGS;
        profHal->swCounterTablePtr->lmemSize = CU_PROF_NOPTRIG_SW_COUNTER_LMEMSIZE;
        profHal->swCounterTablePtr->globalAddrWindowPatchSize = PER_GLOBAL_ADDR_WINDOW_INST_OCCURENCE_PATCH_SIZE;
        profHal->swCounterTablePtr->genericAnyAddrWindowPatchSize = PER_GENERIC_ANY_ADDR_WINDOW_INST_OCCURENCE_PATCH_SIZE;
    }
    else if(profHal->patchFlag & CU_PROF_PATCH_FLAG_SW_COUNTER) {
        profHal->swCounterTablePtr->swCountersDomain = FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST;
        profHal->swCounterTablePtr->numReg = CU_PROF_SW_COUNTER_NUMREGS;
        profHal->swCounterTablePtr->lmemSize = CU_PROF_SW_COUNTER_LMEMSIZE;
        profHal->swCounterTablePtr->globalAddrWindowPatchSize = LDU_INST_PATCH_SIZE;
        profHal->swCounterTablePtr->genericAnyAddrWindowPatchSize = LD_ST_INST_PATCH_SIZE;
    }
    return CUDA_SUCCESS;
}

#if NVCFG(GLOBAL_ARCH_FERMI)
CUresult fermiInitProfilerHal(profilerHal* profHal, NvU32 smVersion)
{
    CUresult status = CUDA_SUCCESS;
    if(profHal == NULL) {
        return CUDA_ERROR_UNKNOWN;
    }
    status = fermiFuncInitializeTables(smVersion, profHal);
    profHal->funcApplyReloc = &fermiFuncApplyReloc;
    profHal->funcLocateSSYs = &fermiFuncLocateSSYs;
    profHal->funcPatchNOPTRIGInstructions = &fermiFuncPatchInstructions;
    profHal->funcCountBlockOnSM = &fermiFuncCountBlockOnSM;
    profHal->funcRecordWarpEvent = &fermiFuncRecordWarpEvent;
    profHal->funcCollectSwCounters = &funcCollectSwCounters;
    profHal->funcPatchConcKernelTraceSyncKernel = &fermiFuncPatchConcKernelTraceSyncKernel;
    profHal->funcCollectConcKernelTrace = &fermiFuncCollectConcKernelTrace;
    profHal->funcInsertICachePadding = &fermiFuncInsertICachePadding;
    return status;
}

#endif
