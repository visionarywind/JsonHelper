/*
* Copyright 1993-2009 by NVIDIA Corporation.  All rights reserved.  All
* information contained herein is proprietary and confidential to NVIDIA
* Corporation.  Any use, reproduction, or disclosure without the written
* permission of NVIDIA Corporation is prohibited.
*/

/******************************************************************************
*
*   Module: fermi_perfmon_new.h
*
*   Description:
*       fermi specific perfmon definitions
*
******************************************************************************/
#ifndef __FERMI_PERFMON_NEW_H__
#define __FERMI_PERFMON_NEW_H__

#include "cuda_device.h"
#include "class/cl90c0.h"
#include "fermi/gf100/dev_graphics_nobundle.h"
#include "fermi/gf100/dev_top.h"
#include "perfmon_new.h"
#include "fermi_signals.h"
#include "fermi/gf100/dev_ltc.h"

#define PACK4B(b0, b1, b2, b3)              ((b0)|((b1)<<8)|((b2)<<16)|((b3)<<24))

// Fermi clock domains
// gpc domains
#define FERMI_CLK_DOMAIN_GPC_MAX 1
// sys domains
#define FERMI_CLK_DOMAIN_SYS_MAX 8
// fbp domains
#define FERMI_CLK_DOMAIN_FBP_MAX 2

#define FERMI_CLK_DOMAIN_MAX     (FERMI_CLK_DOMAIN_GPC_MAX + FERMI_CLK_DOMAIN_SYS_MAX + FERMI_CLK_DOMAIN_FBP_MAX)

#define PM_MAX_GPC                              8
#define PM_MAX_TPC                              8
#define PM_MAX_FBP                              8
#define PM_MAX_CHIPLETS_PER_CHIPLET_TYPE        8
#define PM_MAX_DOMAIN_PER_CHIPLET               8

// Max number of supported counters in each mode
#if CU_PROF_FERMI_PM_MODE_A
#define CU_FERMI_MAX_PM_COUNTERS (1 * FERMI_CLK_DOMAIN_MAX)
#elif CU_PROF_FERMI_PM_MODE_B
#define CU_FERMI_MAX_PM_COUNTERS (4 * FERMI_CLK_DOMAIN_MAX)     // 4 counters per domain can be monitored concurrently in ModeB
#elif CU_PROF_FERMI_PM_MODE_C
#define CU_FERMI_MAX_PM_COUNTERS (12 * FERMI_CLK_DOMAIN_MAX)
#elif CU_PROF_FERMI_PM_SM_INTERNAL
#define CU_FERMI_MAX_PM_COUNTERS 8
#elif CU_PROF_FERMI_PM_MODE_MIXED
#define CU_FERMI_MAX_PM_COUNTERS (8 + 4 * FERMI_CLK_DOMAIN_MAX) // 8 for SM internal and (4 * FERMI_CLK_DOMAIN_MAX) for ModeB
#else
#define CU_FERMI_MAX_PM_COUNTERS 0
#endif

//****************************************************************************************
//  ref "Fermi PGRAPH Memory Map.xls"
//****************************************************************************************
#define NV_GPC_PRI_BASE                     0x00500000
#define NV_GPC_PRI_STRIDE                   0x00008000

#define NV_TPC_IN_GPC_BASE                  0x00004000
#define NV_TPC_IN_GPC_STRIDE                0x00000800

#define NV_PRI_TPC_ADDR(gpc, tpc)           (NV_GPC_PRI_BASE+((gpc)*NV_GPC_PRI_STRIDE)+NV_TPC_IN_GPC_BASE+((tpc)*NV_TPC_IN_GPC_STRIDE))

#define NV_PLTCG_BASE                       0x00140000 // dev_ltc.h - NV_PLTCG
#define NV_PLTCG_STRIDE                     0x00002000
#define NV_PLTCG_ADDR(fbp)                  (NV_PLTCG_BASE+fbp*NV_PLTCG_STRIDE)
#define NV_PLTS_BASE                        0x00001000 // dev_ltc.h - NV_PLTCG
#define NV_PLTS_STRIDE                      0x00000400

//Use broadcast register to sent PM_enable for the FBPA counters. This is a workaround as the
//unicast access to FBPA was not working fine for GTX470.
#define NV_FBPA_PRI_BASE_BROADCAST          0x0010F000 // pri_fbpa.ref - NV_PFB_FBPA

#define NV_FBPA_PRI_BASE                    0x00110000 // pri_fbpa.ref - NV_PFB_FBPA_0
#define NV_FBPA_PRI_STRIDE                  0x00001000
#define NV_FBPA_PRI_ADDR(fbp)               (NV_FBP_PA_PRI_BASE+fbp*NV_FBP_PA_PRI_STRIDE)

// no of available TPCs/ZCULLs in a GPC
// NUM_AVAILABLE_TPCS - 4:0, NUM_AVAILABLE_ZCULLS - 20:16 
#define NV_GPCCS_FS_GPC(gpcId)              (NV_PGRAPH_PRI_GPC0_GPCCS_FS_GPC + NV_GPC_PRI_STRIDE * gpcId)

// SM perfmon related defines, refer fermi/gf100/dev_graphics_nobundle.h for details

// PM control register
#define NV_SM_PM_CTRL(gpcId, tpcId)        (NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_PM_CTRL_SEL                  NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_SEL
#define NV_SM_PM_CTRL_ENABLE               NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_ENABLE
#define NV_SM_PM_CTRL_ENABLE_ENABLE        NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_ENABLE_ENABLE
#define NV_SM_PM_CTRL_ENABLE_DISABLE       NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_ENABLE_DISABLE

// ------------------------------------------------------------------
// Perf counters
// ------------------------------------------------------------------

// Block and Edge selection registers
// BLOCK0 - 2:0, EDGE0 - 3:3, BLOCK1 - 6:4, EDGE1 - 7:7, ... BLOCK7 - 30:28, EDGE7 - 31:31
// BLOCK[0..7] are not implemented since they have been depreciated. These fields are not writeable and will always read 0.
#define NV_SM_DSM_PERF_COUNTER_CONTROL0(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER_CONTROL0 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)

// Function combination selection register
// FUNC0 - 15:0, FUNC1 - 31:16
#define NV_SM_DSM_PERF_COUNTER_CONTROL1(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER_CONTROL1 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER_CONTROL2(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER_CONTROL2 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER_CONTROL3(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER_CONTROL3 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER_CONTROL4(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER_CONTROL4 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)

// Performance Counter Group mux select - group selection registers
// GRP0 - 7:0, GRP1 - 15:8, GRP2 - 23:16, GRP3 - 31:24
#define NV_SM_DSM_PERF_COUNTER_CONTROL_SEL0(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER_CONTROL_SEL0 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER_CONTROL_SEL1(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER_CONTROL_SEL1 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)

// ----------------------------------------------------------------------
// Continuation of the performance counter control registers.  These
// registers configures the mux structure of each bit of each counter.
// ----------------------------------------------------------------------
// Each perf counter has 4 bits feeding into a function table.  Each bit
// can be selected from 1 of 8 bits of 1 of the 8 groups (selected via 
// the PERF_COUNTER_CONTROL_SEL* register above).
// BIT#_GRP selects 1 of 8 groups 
// BIT#_SIG selects 1 of the 8 signals from that selected group
// BIT0_GRP - 3:0, BIT0_SIG - 7:4, ... BIT3_GRP - 27:24, BIT3_SIG - 31:28
#define NV_SM_DSM_PERF_COUNTER0_CONTROL(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER0_CONTROL + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER1_CONTROL(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER1_CONTROL + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER2_CONTROL(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER2_CONTROL + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER3_CONTROL(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER3_CONTROL + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER4_CONTROL(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER4_CONTROL + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER5_CONTROL(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER5_CONTROL + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER6_CONTROL(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER6_CONTROL + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER7_CONTROL(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER7_CONTROL + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)

// Perf counter values themselves
#define NV_SM_DSM_PERF_COUNTER0(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER0 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER1(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER1 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER2(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER2 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER3(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER3 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER4(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER4 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER5(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER5 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER6(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER6 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER7(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER7 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)

// Perf counter status report - counter overflow
#define NV_SM_DSM_PERF_COUNTER_STATUS(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER_STATUS + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
    
#define CU_PROF_SW_COUNTERS_MAX         10
#define CU_PROF_PM_GENERAL_START_INDEX  CU_PROF_PM_SM_MAX_COUNTERS

enum PMUnitId_enum {
    PM_UNIT_SM              = 0,
        PM_UNIT_MPC             = 1,
        PM_UNIT_L1C             = 2,
        PM_UNIT_LTC             = 3,
        PM_UNIT_LTC1            = 4,
        PM_UNIT_LTC2            = 5,
        PM_UNIT_LTC3            = 6,
        PM_UNIT_LTC4            = 7,
        PM_UNIT_LTC5            = 8,
        PM_UNIT_HUBMMU          = 9,
        PM_UNIT_TEX             = 10,
        PM_UNIT_FB              = 11,
        PM_UNIT_FB1             = 12,
        PM_UNIT_TEX_D           = 13,
        PM_UNIT_MAX             = 14    // invalid unit
};

enum PMMRegisters_enum {  
        NV_PMM_TRIG0                = 1,
        NV_PMM_TRIG1                = (NV_PMM_TRIG0 << 1),
        NV_PMM_EVENT                = (NV_PMM_TRIG0 << 2),
        NV_PMM_SAMPLE               = (NV_PMM_TRIG0 << 3),
        NV_ELAPSED_CLOCKS           = (NV_PMM_TRIG0 << 4),
        NV_PMM_SIG_MASK             = NV_PMM_TRIG0 | NV_PMM_TRIG1 | NV_PMM_EVENT | NV_PMM_SAMPLE
};

enum PM_REGISTERS
{
        // sys chiplet (one chiplet + one instance only)
        NV_PERF_PMMSYS_BASE                                             =   0x1B0000,
        // gpc chiplet (multiple chiplets with multiple instances each)
        NV_PERF_PMMGPC_BASE                                             =   0x180000,
        NV_PERF_PMMGPC_CHIPLET_OFFSET                                   =   0x1000,
        // fbp chiplet (multiple chiplets with multiple instances each)
        NV_PERF_PMMFBP_BASE                                             =   0x1A0000,
        NV_PERF_PMMFBP_CHIPLET_OFFSET                                   =   0x1000,
        
        // PMM (applies to all perfmon blocks), these are relative offsets per domain
        NV_PMM_TRIG0_SEL                                                =   0x40,
        NV_PMM_TRIG0_OP                                                 =   0x44,
        NV_PMM_TRIG1_SEL                                                =   0x48,
        NV_PMM_TRIG1_OP                                                 =   0x4c,
        NV_PMM_EVENT_SEL                                                =   0x50,
        NV_PMM_EVENT_OP                                                 =   0x54,
        NV_PMM_SAMPLE_SEL                                               =   0x58,
        NV_PMM_SAMPLE_OP                                                =   0x5c,
        NV_PMM_SETFLAG_OP                                               =   0x60,
        NV_PMM_CLRFLAG_OP                                               =   0x64,
        
        NV_PMM_ENGINE_SEL                                               =   0x6c,
        
        NV_PMM_ELAPSED                                                  =   0x70,
        NV_PMM_EVENTCNT                                                 =   0x80,
        NV_PMM_THRESHCNT                                                =   0x88,
        NV_PMM_TRIGGERCNT                                               =   0x8c,
        NV_PMM_SAMPLECNT                                                =   0x90,
        
        NV_PMM_CONTROL                                                  =   0x9c,
        NV_PMM_CONTROL_MODE__SHIFT                                      =   0,
        NV_PMM_CONTROL_MODE__MASK                                       =   7 << NV_PMM_CONTROL_MODE__SHIFT,
        NV_PMM_CONTROL_MODE_DISABLE                                     =   0,
        NV_PMM_CONTROL_MODE_A                                           =   1,
        NV_PMM_CONTROL_MODE_B                                           =   2,
        NV_PMM_CONTROL_MODE_C                                           =   3,
        NV_PMM_CONTROL_MODE_E                                           =   5,
        NV_PMM_CONTROL_ADDTOCTR__SHIFT                                  =   3,
        NV_PMM_CONTROL_ADDTOCTR__MASK                                   =   7 << NV_PMM_CONTROL_ADDTOCTR__SHIFT,
        NV_PMM_CONTROL_ADDTOCTR_INCR                                    =   0,
        NV_PMM_CONTROL_ADDTOCTR_EVENT4                                  =   1,
        NV_PMM_CONTROL_ADDTOCTR_EVENT6                                  =   2,
        NV_PMM_CONTROL_ADDTOCTR_TRIG4                                   =   3,
        NV_PMM_CONTROL_ADDTOCTR_TRIG6                                   =   4,
        NV_PMM_CONTROL_ADDTOCTR_VIVEK                                   =   5,
        
        NV_PMM_CONTROL_CTXSW_MODE__SHIFT                                =   18,
        NV_PMM_CONTROL_CTXSW_MODE__MASK                                 =   1 << NV_PMM_CONTROL_CTXSW_MODE__SHIFT,
        NV_PMM_CONTROL_CTXSW_MODE_ENABLED                               =   0,
        NV_PMM_CONTROL_CTXSW_MODE_DISABLED                              =   1,

        //TBD check how to use the following 2 fields effectively using masks. They are defined only for last 8 bits.
        NV_PERF_PMM_RELEASE                                             =   0xA0,
        NV_PERF_PMM_RELEASE_SHADOWS_DOIT                                =   1,

        NV_PERF_PMM_STARTEXPERIMENT                                     =   0xe0,
        NV_PERF_PMM_STARTEXPERIMENT_START_DOIT                          =   1,

        NV_PMM_CLAMP_CYA_CONTROL                                        =   0x100,
        NV_PMM_CLAMP_CYA_CONTROL_ENABLECYA_DISABLE                      =   0,
        NV_PMM_CLAMP_CYA_CONTROL_ENABLECYA_ENABLE                       =   1,
        
        NV_PMM_DOMAIN_OFFSET                                            =   0x200,
};

typedef struct FermiSignalName2Numeric_st
{
    const char             *name;
    unsigned int           numericId;
} FermiSignalName2Numeric;


typedef struct CUparsedUnit_st {
    NvU32 pmUnitId;         // hw unit id
    NvU32 pmUnitIdx;        // hw unit idx in the PerfUnitTable
    NvU32 group[4];         // event-group id
    NvU32 groupCount;       // no of event-groups assigned so far
    NvU32 maxGroups;        // max no of allowed event-groups for the unit
} CUparsedUnit;

//Assunming we will profile same signal for all chiplets, I have used having array of values for all chiplets, inside the domain. 
//Instead we can have array of chilpet structures for max chiplets.  This way we can profile different signals for different chiplets if required. (There doesn't seem any use case for this)
typedef struct CUparsedClk_st {
    CUparsedUnit *pParsedUnit[CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS+1];   // This stores the unique unit-ids and groups. Not one-to-one with the signals
    NvBool       bParsedMBWS;                                          // multi bus-width signal is parsed?
    NvU32        indexMBWS;                                            // index of multibuswidth signal in the current domain.
    PerfSignalTableNew *sigtable[CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS+1];// Pointer to current signal from the signal table
    NvU32        eventspec[CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS+1];      // Event specifier for PM signals 
    NvU32        *values;                                              // Array of values for all the chiplet instances for all the counters selected in this domain
    NvU32        isElapsedClocksProfiled;
} CUparsedClk;

typedef struct CUSMCtrInfo_st {
    PerfSignalTableNew *sigtable[CU_PROF_PM_SM_MAX_COUNTERS];          // Pointer to current signal from the signal table
    //Ideally SM counters can be collected for all TPCs, 
    //but if we want to profile the PM singals from gpc0 domain 
    //then we need to provide only 4 TPCs else don't allow sm0 
    //and gpc0 together.
    //TBD Discuss this behaviour with all
    NvU32        *values;                                              // Array of values for all the chiplet instances for all the counters selected in this domain
    NvU32         bitCount[CU_PROF_PM_SM_MAX_COUNTERS];
    NvU32         start[CU_PROF_PM_SM_MAX_COUNTERS];
    NvU32        SMCountersAdded;
} CUSMCtrInfo;

struct CUfermiEventGroup_st {
    NvU32           *pmmAddress;                                       //Store domain address for each chiplet 
    NvU32           *priAddress;                                       //Store pri address for each chiplet
    NvU32           maxChiplets;
    NvU32           pmUnitMask;
    NvU32           chipletType;                                       // Chiplet type for this domain
    CUparsedClk     *pParsedClk;                                       //Used for PM signals only
    NvU32           clkIdx;
    //TBD: Check if following can be removed. 
    NvU32           gpcCount;
    NvU32           *tpcPerGpcCount;
    NvU32           fbpCount;
    CUSMCtrInfo     *pSM;                                               //Used for SM counters only
};


extern CUdomainInfo domainInfoGF100;
extern CUdomainInfo domainInfoGF104;
extern CUdomainInfo domainInfoGF108;
extern CUdomainInfo domainInfoGF119;
extern CUdomainInfo domainInfoGF117;

//  3rd party tool specific specific functions
CUprofResult fermiPerfmonDeviceInitEventDomainInfo(CUdev *pDev);
CUprofResult fermiPerfmonGetInstanceValues(CUdev *dev, CUdomainData *domainData, 
                                                 NvU32 *avail, NvU32 *total) ;
CUprofResult fermiPerfmonEventGroupCreate(CUctx *pCtx, CUeventGroup **pEventGroup);
CUprofResult fermiPerfmonEventGroupDestroy(CUeventGroup *pEventGroup);
CUprofResult fermiPerfmonEventGroupAddEvent(CUeventGroup *pEventGroup, NvU32 eventID);
CUprofResult fermiPerfmonEventGroupRemoveEvent(CUeventGroup *pEventGroup, NvU32 eventID);
CUprofResult fermiPerfmonEventGroupRemoveAllEvents(CUeventGroup *pEventGroup);
CUprofResult fermiPerfmonEventGroupResetAllEvents(CUeventGroup *pEventGroup);
CUprofResult fermiPerfmonEventGroupEnable(CUeventGroup *pEventGroup);
CUprofResult fermiPerfmonEventGroupDisable(CUeventGroup *pEventGroup);
CUprofResult fermiPerfmonEventGroupReadEvent(CUeventGroup          *pEventGroup,
                                             CUprof_ReadEventFlags flags,
                                             CUprof_EventID        eventID, 
                                             size_t                *bufferSizeBytes,
                                             NvU64                 *counterData);
CUprofResult fermiPerfmonEventGroupReadAllEvents(CUeventGroup           *pEventGroup,
                                                 CUprof_ReadEventFlags  flags,
                                                 size_t                 *bufferSizeBytes,
                                                 NvU64                  *counterDataBuffer,
                                                 size_t                 *arraySizeBytes,
                                                 CUprof_EventID         *eventIDArray,
                                                 size_t                 *numCountersRead);
CUprofResult fermiPerfmonEventGroupControl(CUeventGroup *pEventGroup,
                                           CUeventGroupFlag flag,
                                           void *value);
CUprofResult fermiPerfmonDomainCheckCompatible(CUctx *ctx,
                                               CUeventDomainID domainId1,
                                               CUeventDomainID domainId2,
                                               NvBool *bCompatible);

void fermiPerfmonStartCounters(CUnvCurrent** nvCurrent, CUeventGroup *pEventGroup);
void fermiPerfmonStopCounters(CUnvCurrent** nvCurrent, CUeventGroup *pEventGroup);
#endif // __FERMI_PERFMON_H__
