/*
 * Copyright 2005-2010 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

// Macros used by profiler for code patching
#ifndef FERMI_PROF_FUNC_H
#define FERMI_PROF_FUNC_H

#include "../../prof_func.h"

#define REG_63  0x3f

#define FERMI_INST_SIZE_BYTES 8

#define FERMI_WARP_EVENTS_ENTRY_PATCH_SIZE      49
#define FERMI_WARP_EVENTS_EXIT_PATCH_SIZE       16

#define CU_FERMI_IS_EXIT_INSTR(instrHi, instrLo)                   \
        (((instrHi & 0xf0000000) == 0x80000000) & ((instrLo & 0x0000000f) == 0x00000007))

#define CU_FERMI_IS_JCAL_INSTR(instrHi, instrLo)                   \
        (((instrHi & 0xf8000000) == 0x10000000) & ((instrLo & 0x0000000f) == 0x00000007))

#define CU_FERMI_IS_JMP_INSTR(instrHi, instrLo)                   \
        (((instrHi & 0xf8000000) == 0x00000000) & ((instrLo & 0x0000000f) == 0x00000007))

#define CU_FERMI_IS_JMX_INSTR(instrHi, instrLo)                   \
        (((instrHi & 0xf8000000) == 0x08000000) & ((instrLo & 0x0000000f) == 0x00000007))

#define CU_FERMI_GET_CCC_BITS(instr, CCCbits)                      \
        CCCbits = ((instr & 0x000003e0) >> 5)

#define CU_FERMI_GET_P_REG_BITS(instr, PRegBits)                   \
        PRegBits = ((instr & 0x00003c00) >> 10)

#define FERMI_MOV32I_INSTR_HI_OPCODE                               \
        (0x18000000)

#define FERMI_MOV32I_INSTR_HI_IMMEDIATE(value)                     \
        (value >> 6)

#define FERMI_MOV32I_INSTR_LO_OPCODE                               \
        (0x000001e2)

#define FERMI_MOV32I_INSTR_LO_IMMEDIATE(value)                     \
        ((value & 0x0000003f) << 26)

#define FERMI_MOV32I_INSTR_DEST(reg)                               \
        ((reg & 0x0000003f) << 14)

#define FERMI_MOV32I_INSTR_PRED_BITS(preg)                         \
        ((preg & 0x0000000f) << 10)

//this creates an instruction of the type:
// @Pg MOV32I R2, 0x32000000;
#define CU_FERMI_CREATE_MOV32I_INSTR(instrHi, instrLo, reg, value, preg)    \
        instrHi = (0                                                        \
                   | FERMI_MOV32I_INSTR_HI_OPCODE                           \
                   | FERMI_MOV32I_INSTR_HI_IMMEDIATE(value)                 \
                   );                                                       \
        instrLo = (0                                                        \
                   | FERMI_MOV32I_INSTR_LO_OPCODE                           \
                   | FERMI_MOV32I_INSTR_LO_IMMEDIATE(value)                 \
                   | FERMI_MOV32I_INSTR_DEST(reg)                           \
                   | FERMI_MOV32I_INSTR_PRED_BITS(preg)                     \
                   );

#define FERMI_BRANCH_INSTR_HI_OPCODE                                        \
        (0x40000000)

#define FERMI_BRANCH_INSTR_HI_IMMEDIATE(value)                              \
        ((value & 0x00ffffff) >> 6)

#define FERMI_BRANCH_INSTR_LO_OPCODE                                        \
        (0x00000007)

#define FERMI_BRANCH_INSTR_PREG(PReg)                                       \
        ((PReg & 0x0000000f) << 10)

#define FERMI_BRANCH_INSTR_CCC_BITS(CCCbits)                                \
        ((CCCbits & 0x0000001f) << 5)

#define FERMI_BRANCH_INSTR_LO_IMMEDIATE(value)                              \
        ((value & 0x0000003f) << 26)

#define CU_FERMI_CREATE_BRANCH_INSTR(instrHi, instrLo, PReg, CCCbits, value)\
        instrHi = (0                                                        \
                   | FERMI_BRANCH_INSTR_HI_OPCODE                           \
                   | FERMI_BRANCH_INSTR_HI_IMMEDIATE(value)                 \
                   );                                                       \
        instrLo = (0                                                        \
                   | FERMI_BRANCH_INSTR_LO_OPCODE                           \
                   | FERMI_BRANCH_INSTR_PREG(PReg)                          \
                   | FERMI_BRANCH_INSTR_CCC_BITS(CCCbits)                   \
                   | FERMI_BRANCH_INSTR_LO_IMMEDIATE(value)                 \
                   );

#define FERMI_SSY_INSTR_HI_OPCODE                                           \
        (0x60000000)

#define FERMI_SSY_INSTR_HI_IMMEDIATE(value)                                 \
        ((value & 0x00ffffff) >> 6)

#define FERMI_SSY_INSTR_LO_OPCODE                                           \
        (0x00000007)

#define FERMI_SSY_INSTR_LO_IMMEDIATE(value)                                 \
        ((value & 0x0000003f) << 26)

#define CU_FERMI_CREATE_SSY_INSTR(instrHi, instrLo, value)                  \
        instrHi = (0                                                        \
                   | FERMI_SSY_INSTR_HI_OPCODE                              \
                   | FERMI_SSY_INSTR_HI_IMMEDIATE(value)                    \
                   );                                                       \
        instrLo = (0                                                        \
                   | FERMI_SSY_INSTR_LO_OPCODE                              \
                   | FERMI_SSY_INSTR_LO_IMMEDIATE(value)                    \
                   );

#define FERMI_RET_INSTR_HI_OPCODE                                        \
        (0x90000000)

#define FERMI_RET_INSTR_LO_OPCODE                                        \
        (0x00000007)

#define FERMI_RET_INSTR_PREG(PReg)                                       \
        ((PReg & 0x0000000f) << 10)

#define FERMI_RET_INSTR_CCC_BITS(CCCbits)                                \
        ((CCCbits & 0x0000001f) << 5)

#define CU_FERMI_CREATE_RET_INSTR(instrHi, instrLo, PReg, CCCbits)       \
        instrHi = (0                                                     \
                   | FERMI_RET_INSTR_HI_OPCODE                           \
                   );                                                    \
        instrLo = (0                                                     \
                   | FERMI_RET_INSTR_LO_OPCODE                           \
                   | FERMI_RET_INSTR_PREG(PReg)                          \
                   | FERMI_RET_INSTR_CCC_BITS(CCCbits)                   \
                   );

#define FERMI_LONGJMP_INSTR_HI_OPCODE                                    \
        (0x88000000)

#define FERMI_LONGJMP_INSTR_LO_OPCODE                                    \
        (0x00000007)

#define FERMI_LONGJMP_INSTR_PREG(PReg)                                   \
        ((PReg & 0x0000000f) << 10)

#define FERMI_LONGJMP_INSTR_CCC_BITS(CCCbits)                            \
        ((CCCbits & 0x0000001f) << 5)

#define CU_FERMI_CREATE_LONGJMP_INSTR(instrHi, instrLo, PReg, CCCbits)   \
        instrHi = (0                                                     \
                   | FERMI_LONGJMP_INSTR_HI_OPCODE                       \
                   );                                                    \
        instrLo = (0                                                     \
                   | FERMI_LONGJMP_INSTR_LO_OPCODE                       \
                   | FERMI_LONGJMP_INSTR_PREG(PReg)                      \
                   | FERMI_LONGJMP_INSTR_CCC_BITS(CCCbits)               \
                   );

#define FERMI_LDC64_INSTR_HI_OPCODE                                                 \
        (0x14000000)

#define FERMI_LDC64_INSTR_CBANK(cBank)                                              \
        (cBank << 10)

#define FERMI_LDC64_INSTR_OFFSET_HI(offset)                                         \
        (offset >> 6)

#define FERMI_LDC64_INSTR_LO_OPCODE                                                 \
        (0x03f000a6)

#define FERMI_LDC64_INSTR_OFFSET_LO(offset)                                         \
        (offset << 26)

#define FERMI_LDC64_INSTR_PREG(PReg)                                                \
        ((PReg & 0x0000000f) << 10)

#define FERMI_LDC64_INSTR_DEST(dest)                                                \
        (dest << 14)


#define CU_FERMI_CREATE_LDC64_INSTR(instrHi, instrLo, cBank, offset, dest, PReg)    \
        instrHi = (0                                                                \
                   | FERMI_LDC64_INSTR_HI_OPCODE                                    \
                   | FERMI_LDC64_INSTR_CBANK(cBank)                                 \
                   | FERMI_LDC64_INSTR_OFFSET_HI(offset)                            \
                   );                                                               \
        instrLo = (0                                                                \
                   | FERMI_LDC64_INSTR_LO_OPCODE                                    \
                   | FERMI_LDC64_INSTR_PREG(PReg)                                   \
                   | FERMI_LDC64_INSTR_DEST(dest)                                   \
                   | FERMI_LDC64_INSTR_OFFSET_LO(offset)                            \
                   );



#define STL_TOP8    0xc8000000
#define STL_LAST14  0x00001c85
#define STL_REG_A   0x03f00000 // These bits need to made all 1 for instruction to take imme addr
#define STL_LMEM_ADDR_HI(lmemAddr) (lmemAddr >> 6)
#define STL_LMEM_ADDR_LO(lmemAddr) (lmemAddr << 26)
#define STL_REG(reg) (reg << 14)

#define STL_HI(lmemAddr, reg) STL_TOP8 | STL_LMEM_ADDR_HI(lmemAddr)
#define STL_LO(lmemAddr, reg) STL_LMEM_ADDR_LO(lmemAddr) | STL_REG_A | STL_REG(reg) | STL_LAST14

#define LDL_TOP8    0xc0000000
#define LDL_LAST14  0x00001d85
#define LDL_REG_A   0x03f00000
#define LDL_LMEM_ADDR_HI(lmemAddr) (lmemAddr >> 6)
#define LDL_LMEM_ADDR_LO(lmemAddr) (lmemAddr << 26)
#define LDL_REG(reg) (reg << 14)

#define LDL_HI(reg, lmemAddr) LDL_TOP8 | LDL_LMEM_ADDR_HI(lmemAddr)
#define LDL_LO(reg, lmemAddr) LDL_LMEM_ADDR_LO(lmemAddr) | LDL_REG_A | LDL_REG(reg) | LDL_LAST14

#define P2R_TOP18   0x3000c3ff
#define P2R_LAST14  0xfff01c04
#define P2R_REG(reg) (reg << 14)

#define P2R_LO(reg) P2R_REG(reg) | P2R_LAST14
#define P2R_HI(reg) P2R_TOP18 

#define R2P_TOP18   0x3400c3ff
#define R2P_LAST14  0xfc001c04
#define R2P_REG(reg) (reg << 20)

#define R2P_LO(reg) R2P_REG(reg) | R2P_LAST14
#define R2P_HI(reg) R2P_TOP18 

#define RED_LAST14  0x00000005
#define RED_U32_ADD_LO(regA, regB, PRegBits) (regA << 20) | (regB << 14) | (PRegBits << 10) | RED_LAST14
#define RED_U32_ADD_HI(regA, regB) 0x14000000

#define CU_FERMI_GET_LD_EXT_ADDR(origInstrHi) \
        ((origInstrHi & 0x04000000) >> 26)

#define CU_FERMI_GET_LD_ADDR_REG(origInstrLo) \
        ((origInstrLo & 0x03f00000) >> 20)

#define CU_FERMI_GET_LD_IMM32(origInstrHi, origInstrLo) \
        ((origInstrHi << 6) | (origInstrLo >> 26))

#define FERMI_MOV_INSTR_HI_OPCODE 0x28000000
#define FERMI_MOV_INSTR_LO_OPCODE 0x00001de4

#define FERMI_MOV_INSTR_SRC_REG(sourceReg)\
        (sourceReg << 26)

#define FERMI_MOV_INSTR_DEST_REG(destReg)\
        (destReg << 14)

#define CU_FERMI_CREATE_MOV_INSTR(instrHi, instrLo, destReg, sourceReg) \
        instrHi = FERMI_MOV_INSTR_HI_OPCODE;                            \
        instrLo = (0                                                    \
                   | FERMI_MOV_INSTR_LO_OPCODE                          \
                   | FERMI_MOV_INSTR_SRC_REG(sourceReg)                 \
                   | FERMI_MOV_INSTR_DEST_REG(destReg)                  \
                   );

#define CU_FERMI_CREATE_SRC_B_FIELD_FROM_REGISTER(reg)\
        ((reg & 0x000fffff))

#define CU_FERMI_CREATE_SRC_B_FIELD_FROM_CONSTANT_ADDRESS(bankNumber, bankOffset)\
        (((bankNumber & 0x000fffff) << 16) | (((bankOffset/4) & 0x000fffff) << 2))

#define FERMI_ISETP_INSTR_HI_OPCODE 0x18000000

#define FERMI_ISETP_INSTR_CMP_BITS(cmp)\
        (cmp << 23)

#define FERMI_ISETP_INSTR_BOP_BITS(bop)\
        (bop << 21)

#define FERMI_ISETP_INSTR_PRED_SRC_BITS(predSrc)\
        (predSrc << 17)

#define FERMI_ISETP_INSTR_ABC_BITS(abc)\
        (abc << 14)

#define FERMI_ISETP_INSTR_SRC_B_FIELD_HI(srcB)\
        ((srcB & 0xffffffff) >> 18)

#define FERMI_ISETP_INSTR_LO_OPCODE 0x0001dc03

#define FERMI_ISETP_INSTR_SRC_B_FIELD_LO(srcB)\
        (srcB << 26)

#define FERMI_ISETP_INSTR_SRC_A_FIELD(regA)\
        (regA << 20)

#define FERMI_ISETP_INSTR_PRED_DEST_BITS(predDest)\
        (predDest << 17)

// Other bit-fields could be added later if required
#define CU_FERMI_CREATE_ISETP_INSTR(instrHi, instrLo, cmp, bop, predSrc, abc, srcB, regA, predDest) \
        instrHi = (0                                                                                \
                   | FERMI_ISETP_INSTR_HI_OPCODE                                                    \
                   | FERMI_ISETP_INSTR_CMP_BITS(cmp)                                                \
                   | FERMI_ISETP_INSTR_BOP_BITS(bop)                                                \
                   | FERMI_ISETP_INSTR_PRED_SRC_BITS(predSrc)                                       \
                   | FERMI_ISETP_INSTR_ABC_BITS(abc)                                                \
                   | FERMI_ISETP_INSTR_SRC_B_FIELD_HI(srcB)                                         \
                  );                                                                                \
        instrLo = (0                                                                                \
                   | FERMI_ISETP_INSTR_LO_OPCODE                                                    \
                   | FERMI_ISETP_INSTR_SRC_B_FIELD_LO(srcB)                                         \
                   | FERMI_ISETP_INSTR_SRC_A_FIELD(regA)                                            \
                   | FERMI_ISETP_INSTR_PRED_DEST_BITS(predDest)                                     \
                  );

#define FERMI_PSETP_INSTR_HI_OPCODE 0x0c0e0000

#define FERMI_PSETP_INSTR_LO_OPCODE 0x0001dc04

#define FERMI_PSETP_INSTR_BOP_BITS(bop)\
        ((bop & 0x00000003) << 29)

#define FERMI_PSETP_INSTR_PRED_SRC1_BITS(predSrc1)\
        ((predSrc1 & 0x0000000f) << 20)

#define FERMI_PSETP_INSTR_PRED_SRC2_BITS(predSrc2)\
        ((predSrc2  & 0x0000000f)<< 26)

#define FERMI_PSETP_INSTR_PRED_DEST_BITS(predDest)\
        (predDest << 17)

// Other bit-fields could be added later if required
#define CU_FERMI_CREATE_PSETP_INSTR(instrHi, instrLo, bop, predSrc1, predSrc2, predDest) \
        instrHi = (0                                                                     \
                   | FERMI_PSETP_INSTR_HI_OPCODE                                         \
                  );                                                                     \
        instrLo = (0                                                                     \
                   | FERMI_PSETP_INSTR_LO_OPCODE                                         \
                   | FERMI_PSETP_INSTR_BOP_BITS(bop)                                     \
                   | FERMI_PSETP_INSTR_PRED_SRC1_BITS(predSrc1)                          \
                   | FERMI_PSETP_INSTR_PRED_SRC2_BITS(predSrc2)                          \
                   | FERMI_PSETP_INSTR_PRED_DEST_BITS(predDest)                          \
                  );

// Creates instruction LOP.AND R0, R0, R2;
#define FERMI_LOP_INSTR_HI_OPCODE 0x68000000
#define FERMI_LOP_INSTR_LO_OPCODE 0x08001c03

#define FERMI_NOP_INSTR_HI_OPCODE 0x40000000

#define FERMI_NOP_INST_TRIG_BIT(trigFlag) \
        ((0x00000001 & trigFlag) << 18)

#define FERMI_NOP_INSTR_HI_IMMEDIATE(mask) \
        ((mask & 0x0000ffff) >> 6)

#define FERMI_NOP_INSTR_LO_OPCODE 0x000001e4

#define FERMI_NOP_INSTR_SYNC_BIT(syncFlag) \
        ((syncFlag & 0x00000001) << 4)

#define FERMI_NOP_INSTR_LO_IMMEDIATE(mask) \
        ((mask & 0x0000ffff) << 26)

#define FERMI_NOP_INSTR_PRED_BITS(pred) \
        ((pred & 0x0000000f) << 10)

// Other bit-fields could be added later if required
#define CU_FERMI_CREATE_NOP_INSTR(instrHi, instrLo, syncFlag, trigFlag, mask, pred) \
        instrHi = (0                                                                \
                   | FERMI_NOP_INSTR_HI_OPCODE                                      \
                   | FERMI_NOP_INST_TRIG_BIT(trigFlag)                              \
                   | FERMI_NOP_INSTR_HI_IMMEDIATE(mask)                             \
                   );                                                               \
        instrLo = (0                                                                \
                   | FERMI_NOP_INSTR_LO_OPCODE                                      \
                   | FERMI_NOP_INSTR_LO_IMMEDIATE(mask)                             \
                   | FERMI_NOP_INSTR_SYNC_BIT(syncFlag)                             \
                   | FERMI_NOP_INSTR_PRED_BITS(pred)                                \
                   );

#define FERMI_CAL_INSTR_HI_OPCODE 0x50000000

#define FERMI_CAL_INSTR_HI_IMMEDIATE(target) \
        ((target & 0x00ffffff) >> 6)

#define FERMI_CAL_INSTR_LO_OPCODE 0x00010007

#define FERMI_CAL_INSTR_LO_IMMEDIATE(target) \
        ((target & 0x00ffffff) << 26)

// Other bit-fields could be added later if required
#define CU_FERMI_CREATE_CAL_INSTR(instrHi, instrLo, target) \
        instrHi = (0                                        \
                   | FERMI_CAL_INSTR_HI_OPCODE              \
                   | FERMI_CAL_INSTR_HI_IMMEDIATE(target)   \
                   );                                       \
        instrLo = (0                                        \
                   | FERMI_CAL_INSTR_LO_OPCODE              \
                   | FERMI_CAL_INSTR_LO_IMMEDIATE(target)   \
                   );

#define FERMI_JCAL_INSTR_HI_OPCODE 0x10000000

#define FERMI_JCAL_INSTR_HI_IMMEDIATE(target) \
        ((target & 0x00ffffff) >> 6)

#define FERMI_JCAL_INSTR_LO_OPCODE 0x00010007

#define FERMI_JCAL_INSTR_LO_IMMEDIATE(target) \
        ((target & 0x00ffffff) << 26)

// Other bit-fields could be added later if required
#define CU_FERMI_CREATE_JCAL_INSTR(instrHi, instrLo, target)    \
        instrHi = (0                                            \
                   | FERMI_JCAL_INSTR_HI_OPCODE                 \
                   | FERMI_JCAL_INSTR_HI_IMMEDIATE(target)      \
                   );                                           \
        instrLo = (0                                            \
                   | FERMI_JCAL_INSTR_LO_OPCODE                 \
                   | FERMI_JCAL_INSTR_LO_IMMEDIATE(target)      \
                   );

// Other bit-fields could be added later if required
// Creates VOTE.ANY R0, PT, PT;
#define CU_FERMI_VOTE_INSTR_HI_OPCODE 0x49c00000
#define CU_FERMI_VOTE_INSTR_LO_OPCODE 0x00701c24

// Other bit-fields could be added later if required
// Creates POPC R0, R0, 0xFFFFF;
#define CU_FERMI_POPC_INSTR_HI_OPCODE 0x5400ffff
#define CU_FERMI_POPC_INSTR_LO_OPCODE 0xfc001c04

// Other bit-fields could be added later if required
// Creates IMUL32I R0, R0, 8;
#define CU_FERMI_IMUL32I_INSTR_HI_OPCODE 0x10000000
#define CU_FERMI_IMUL32I_INSTR_LO_OPCODE 0x20001ca2

// Other bit-fields could be added later if required
// Creates BRX R0;
#define CU_FERMI_BRX_INSTR_HI_OPCODE 0x48000000
#define CU_FERMI_BRX_INSTR_LO_OPCODE 0x00001de7

#define FERMI_IADD_INSTR_HI_OPCODE 0x48000000

#define FERMI_IADD_INSTR_HI_WRITE_CC_BIT(ccFlag) \
        ((ccFlag & 0x00000001) << 16)

#define FERMI_IADD_INSTR_LO_OPCODE 0x00001c03

#define FERMI_IADD_INSTR_LO_XM_BIT(xmFlag) \
        ((xmFlag & 0x00000001) << 6)

#define FERMI_IADD_INSTR_LO_PSIGN_BIT(psign) \
        ((psign & 0x00000003) << 8)

#define FERMI_IADD_INSTR_LO_DEST_REG(destReg) \
        ((destReg & 0x0000003f) << 14)

#define FERMI_IADD_INSTR_LO_SRC_REG1(srcReg) \
        ((srcReg & 0x0000003f) << 20)

#define FERMI_IADD_INSTR_LO_SRC_REG2(srcReg) \
        ((srcReg & 0x0000003f) << 26)

// Other bit-fields could be added later if required
#define CU_FERMI_CREATE_IADD_INSTR(instrHi, instrLo, xmFlag, psign,     \
        destReg, ccFlag, srcReg1, srcReg2)                              \
        instrHi = (0                                                    \
                   | FERMI_IADD_INSTR_HI_OPCODE                         \
                   | FERMI_IADD_INSTR_HI_WRITE_CC_BIT(ccFlag)           \
                   );                                                   \
        instrLo = (0                                                    \
                   | FERMI_IADD_INSTR_LO_OPCODE                         \
                   | FERMI_IADD_INSTR_LO_XM_BIT(xmFlag)                 \
                   | FERMI_IADD_INSTR_LO_PSIGN_BIT(psign)               \
                   | FERMI_IADD_INSTR_LO_DEST_REG(destReg)              \
                   | FERMI_IADD_INSTR_LO_SRC_REG1(srcReg1)              \
                   | FERMI_IADD_INSTR_LO_SRC_REG2(srcReg2)              \
                   );

#define FERMI_JMP_INSTR_HI_OPCODE 0x00000000

#define FERMI_JMP_INSTR_HI_IMMEDIATE(target) \
        ((target & 0xffffffff) >> 6)

#define FERMI_JMP_INSTR_LO_OPCODE 0x00001de7

#define FERMI_JMP_INSTR_LO_IMMEDIATE(target) \
        ((target & 0xffffffff) << 26)

// Other bit-fields could be added later if required
#define CU_FERMI_CREATE_JMP_INSTR(instrHi, instrLo, target) \
        instrHi = (0                                        \
                   | FERMI_JMP_INSTR_HI_OPCODE              \
                   | FERMI_JMP_INSTR_HI_IMMEDIATE(target)   \
                   );                                       \
        instrLo = (0                                        \
                   | FERMI_JMP_INSTR_LO_OPCODE              \
                   | FERMI_JMP_INSTR_LO_IMMEDIATE(target)   \
                   );

// Other bit-fields could be added later if required
// Creates TEXDEPBAR 0x0;
#define CU_FERMI_TEXDEPBAR_INSTR_HI_OPCODE 0xf0000000
#define CU_FERMI_TEXDEPBAR_INSTR_LO_OPCODE 0x00001c06

#endif
