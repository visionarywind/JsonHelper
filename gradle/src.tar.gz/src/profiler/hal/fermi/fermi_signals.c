/*
* Copyright 1993-2009 by NVIDIA Corporation.  All rights reserved.  All
* information contained herein is proprietary and confidential to NVIDIA
* Corporation.  Any use, reproduction, or disclosure without the written
* permission of NVIDIA Corporation is prohibited.
*/

/******************************************************************************
*
*   Module: fermi_signals.c
*
*   Description:
*       fermi specific signals information
*
******************************************************************************/

// Perf signal table for fermi
// perf-event: signal0 - 2:0, signal1 - 6:4, signal2 - 10:8, signal3 - 14:12
// Some sigmals are commented and not removed so that they can be used for testing purpose in future.
// Fermi clock domains
#include "fermi_perfmon_new.h"
#include "perfmon_new.h"
#include "fermi_signals_strings.h"

#define INVALID_ADDRESS 0xFFFFFFFF
//SMPM: To test the SM Perf signals
//#define SMPM

// Below tables contain info about the PM Enable and Group Selection Registers
// Unit         HW manual       PM Enable reg/bits                  Group Selection reg/bits
// ------------------------------------------------------------------------------------------
// SM           pri_sm.ref      NV_PTPC_PRI_SM_PM_CTRL/ENABLE       NV_PTPC_PRI_SM_PM_CTRL/SEL

// L1C          pri_l1c.ref     NV_PTPC_PRI_L1C_PM/ENABLE           NV_PTPC_PRI_L1C_PM/SEL
// LTC          pri_ltc.ref     NV_PLTC_MISC_LTC_PM/ENABLE          NV_PLTC_MISC_LTC_PM/SEL
// MPC          pri_mpc.ref     NV_PTPC_PRI_MPC_PM_CTRL/ENABLE      NV_PTPC_PRI_MPC_PM_CTRL/SEL
// TEX          pri_tex.ref     NV_PTPC_PRI_TEX_M_PM/PM_ENABLE      NV_PTPC_PRI_TEX_M_PM/PM_SEL
// FB           pri_fbpa.ref    NV_PFB_FBPA_PM/ENABLE               NV_PFB_FBPA_PM_ENABLE/SELECT
// for fermi - GF100

//Watchbus numbers are taken from the file //sw/<branch>/drivers/resman/kernel/inc/fermi/gf100/pm_signals.h
PerfUnitTable PerfUnitTableGF100[] = {
// Unit-name                 PM enable                       GroupSel              maxGroups priBaseAddress                    priChipletOffset   priInstanceOffset         priInstance1Base
//                      register  start end val        register  start end width
//Signals from GPC will ahve PRI base and stride address depending on the GPC id and TPC id both hence they will be initialized runtime.
{PM_UNIT_SM,           {0x00000600,  31, 31, 1},       {0x00000600,  0,  6,  7},      1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE,   NV_TPC_IN_GPC_STRIDE},
// SM  - watch buses from 49 to 56 (decimal) are assigned to SM2PM_GPC_MUXED_BUS_#
{PM_UNIT_MPC,          {0x0000040c,  31, 31, 1},       {0x0000040c,  0,  5,  6},      1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE,   NV_TPC_IN_GPC_STRIDE},
// MPC - watch buses from 32 to 40 (decimal) are assigned to MPC2PM_MUXED_BUS_#
{PM_UNIT_L1C,          {0x000004a8,  31, 31, 1},       {0x000004a8,  0,  5,  6},      1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE,   NV_TPC_IN_GPC_STRIDE},
// L1C - watch buses from  0 to  9 (decimal) are assigned to L1C2PM_GPC_MUXED_BUS_#
{PM_UNIT_TEX,          {0x000002c0,  31, 31, 1},       {0x000002C0,  0,  3,  4},      1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE,   NV_TPC_IN_GPC_STRIDE},
{PM_UNIT_TEX_D,        {0x000002bc,  31, 31, 1},       {0x000002bc,  0,  2,  3},      1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE,   NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_LTC,          {0x00000028,   0,  0, 1},       {0x00000028,  1,  3,  3},      1, NV_PLTCG_BASE,                         NV_PLTCG_STRIDE,    0},
// LTC - watch buses from 27 to 30 (decimal) are assigned to LTC2PM_LTC_SECTOR_MUXED_BUS_#
{PM_UNIT_LTC1,         {0x00000028,   0,  0, 1},       {0x00000028,  4,  8,  5},      1, NV_PLTCG_BASE,                         NV_PLTCG_STRIDE,    0},
// LTC1 - watch buses from 0 to 14 (decimal) are assigned to LTC2PM_LTC_LTC_MUXED_BUS__#
{PM_UNIT_LTC2,         {0x00000028,   0,  0, 1},       {0x00000028,  9,  13, 5},      1, NV_PLTCG_BASE,                         NV_PLTCG_STRIDE,    0},
// LTC2 - watch buses from 31      (decimal) are assigned to LTC2PM_LTC_SRCUNIT_MUXED_BUS
{PM_UNIT_LTC3,         {0x00000028,   0,  0, 1},       {0x00000028,  16, 18, 3},      1, NV_PLTCG_BASE,                         NV_PLTCG_STRIDE,    0},
{PM_UNIT_LTC4,         {0x00000028,   0,  0, 1},       {0x00000028,  24, 25, 2},      1, NV_PLTCG_BASE,                         NV_PLTCG_STRIDE,    0},
{PM_UNIT_LTC5,         {0x00000028,   0,  0, 1},       {0x00000028,  29, 29, 1},      1, NV_PLTCG_BASE,                         NV_PLTCG_STRIDE,    0},
// LTC5 - watch buses from 32 to 57(decimal) are assigned to LTC2PM_LTC_EXTENDED_MUXED_BUS_#
{PM_UNIT_FB,           {0x00000100,   0,  0, 1},       {0x00000100,   4,  9, 6},      1, NV_FBPA_PRI_BASE,                      NV_FBPA_PRI_STRIDE, 0},
//FB - mwatch buses from 15 to 26(decimal) are assigned to FBPA2PM_LTC_FB_PERF_MUXED_BUS_#
{PM_UNIT_HUBMMU,       {INVALID_ADDRESS,   0,  0, 0},  {0x00100C84,   0,  5, 6},      1, 0,                                     0,                  0},
// HUBMMU - watch buses from 5 to 8(decimal) are assigned to HUBMMU2PM_HUB_MUXED_BUS_#
// TODO: add other units here
{PM_UNIT_MAX                                                                          }
};

PerfUnitTable PerfUnitTableGF104[] = {
// Unit-name                 PM enable                       GroupSel              maxGroups
//                      register  start end val        register  start end width
// smquick has different regiser width for group selection
{PM_UNIT_SM,           {0x00000600,  31, 31, 1},       {0x00000600,  0,  7,  8},      1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// SM  - watch buses from 49 to 56 (decimal) are assigned to SM2PM_GPC_MUXED_BUS_#
{PM_UNIT_MPC,          {0x0000040c,  31, 31, 1},       {0x0000040c,  0,  5,  6},      1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// MPC - watch buses from 32 to 40 (decimal) are assigned to MPC2PM_MUXED_BUS_#
{PM_UNIT_L1C,          {0x000004a8,  31, 31, 1},       {0x000004a8,  0,  5,  6},      1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// L1C - watch buses from  0 to  9 (decimal) are assigned to L1C2PM_GPC_MUXED_BUS_#
{PM_UNIT_TEX,          {0x000002c0,  31, 31, 1},       {0x000002C0,  0,  3,  4},      1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE, {0x000002c8,  31, 31, 1}, {0x000002C8,  0,  2,  3}},
{PM_UNIT_TEX_D,        {0x000002bc,  31, 31, 1},       {0x000002bc,  0,  2,  3},      1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE,   NV_TPC_IN_GPC_STRIDE, {0x000002c8,  31, 31, 1}, {0x000002C8,  3,  3,  1}},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_LTC,          {0x00000028,   0,  0, 1},       {0x00000028,  1,  3,  3},      1, NV_PLTCG_BASE,                         NV_PLTCG_STRIDE,    0},
// LTC - watch buses from 27 to 30 (decimal) are assigned to LTC2PM_LTC_SECTOR_MUXED_BUS_#
{PM_UNIT_LTC1,         {0x00000028,   0,  0, 1},       {0x00000028,  4,  8,  5},      1, NV_PLTCG_BASE,                         NV_PLTCG_STRIDE,    0},
// LTC1 - watch buses from 0 to 14 (decimal) are assigned to LTC2PM_LTC_LTC_MUXED_BUS__#
{PM_UNIT_LTC2,         {0x00000028,   0,  0, 1},       {0x00000028,  9,  13, 5},      1, NV_PLTCG_BASE,                         NV_PLTCG_STRIDE,    0},
// LTC2 - watch buses from 31      (decimal) are assigned to LTC2PM_LTC_SRCUNIT_MUXED_BUS
{PM_UNIT_LTC3,         {0x00000028,   0,  0, 1},       {0x00000028,  16, 18, 3},      1, NV_PLTCG_BASE,                         NV_PLTCG_STRIDE,    0},
{PM_UNIT_LTC4,         {0x00000028,   0,  0, 1},       {0x00000028,  24, 25, 2},      1, NV_PLTCG_BASE,                         NV_PLTCG_STRIDE,    0},
{PM_UNIT_LTC5,         {0x00000028,   0,  0, 1},       {0x00000028,  29, 29, 1},      1, NV_PLTCG_BASE,                         NV_PLTCG_STRIDE,    0},
// LTC5 - watch buses from 32 to 57(decimal) are assigned to LTC2PM_LTC_EXTENDED_MUXED_BUS_#
{PM_UNIT_FB,           {0x00000100,   0,  0, 1},       {0x00000100,   4,  9, 6},      1, NV_FBPA_PRI_BASE,                      NV_FBPA_PRI_STRIDE, 0},
//FB - mwatch buses from 15 to 26(decimal) are assigned to FBPA2PM_LTC_FB_PERF_MUXED_BUS_#
{PM_UNIT_HUBMMU,       {INVALID_ADDRESS,   0,  0, 0},  {0x00100C84,   0,  5, 6},      1, 0,                                     0,                  0},
// HUBMMU - watch buses from 5 to 8(decimal) are assigned to HUBMMU2PM_HUB_MUXED_BUS_#
// TODO: add other units here
{PM_UNIT_MAX                                                                          }
};


PerfUnitTable PerfUnitTableGF108[] = {
// Unit-name                 PM enable                       GroupSel              maxGroups
//                      register  start end val        register  start end width
// smquick has different regiser width for group selection
{PM_UNIT_SM,           {0x00000600,  31, 31, 1},       {0x00000600,  0,  7,  8},      1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// SM  - watch buses from 49 to 56 (decimal) are assigned to SM2PM_GPC_MUXED_BUS_#
{PM_UNIT_MPC,          {0x0000040c,  31, 31, 1},       {0x0000040c,  0,  5,  6},      1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// MPC - watch buses from 32 to 40 (decimal) are assigned to MPC2PM_MUXED_BUS_#
{PM_UNIT_L1C,          {0x000004a8,  31, 31, 1},       {0x000004a8,  0,  5,  6},      1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// L1C - watch buses from  0 to  9 (decimal) are assigned to L1C2PM_GPC_MUXED_BUS_#
{PM_UNIT_TEX,          {0x000002c0,  31, 31, 1},       {0x000002C0,  0,  3,  4},      1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE, {0x000002c8,  31, 31, 1}, {0x000002C8,  0,  2,  3}},
{PM_UNIT_TEX_D,        {0x000002bc,  31, 31, 1},       {0x000002bc,  0,  2,  3},      1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE, {0x000002c8,  31, 31, 1}, {0x000002C8,  3,  3,  1}},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_LTC,          {0x00000028,   0,  0, 1},       {0x00000028,  1,  3,  3},      1, NV_PLTCG_BASE,                         NV_PLTCG_STRIDE,    0},

// LTC - watch buses from 44 to 47 (decimal) are assigned to LTC2PM_LTC_SECTOR_MUXED_BUS_#
{PM_UNIT_LTC1,         {0x00000028,   0,  0, 1},       {0x00000028,  4,  8,  5},      1, NV_PLTCG_BASE,                         NV_PLTCG_STRIDE,    0},
// LTC1 - watch buses from 0 to 19 (decimal) are assigned to LTC2PM_LTC_LTC_MUXED_BUS__#
{PM_UNIT_LTC2,         {0x00000028,   0,  0, 1},       {0x00000028,  9,  13, 5},      1, NV_PLTCG_BASE,                         NV_PLTCG_STRIDE,    0},
// LTC2 - watch bus 48 (decimal) is assigned to LTC2PM_LTC_SRCUNIT_MUXED_BUS
{PM_UNIT_LTC3,         {0x00000028,   0,  0, 1},       {0x00000028,  16, 18, 3},      1, NV_PLTCG_BASE,                         NV_PLTCG_STRIDE,    0},
{PM_UNIT_LTC4,         {0x00000028,   0,  0, 1},       {0x00000028,  24, 25, 2},      1, NV_PLTCG_BASE,                         NV_PLTCG_STRIDE,    0},
{PM_UNIT_LTC5,         {0x00000028,   0,  0, 1},       {0x00000028,  29, 29, 1},      1, NV_PLTCG_BASE,                         NV_PLTCG_STRIDE,    0},
//Extended watchbus is not there in GF108, instead LTC2PM_LTC_LTC_MUXED_BUS__# has more width
// LTC5 - watch buses from 0 to 19 (decimal) are assigned to LTC2PM_LTC_LTC_MUXED_BUS__#

//GF108 has 2 FB partitions in one FBP chiplet and both of them have independent watch buses
//Hence the signals from both partitions can be sampled in parallel. Have defined indepedent units and signals from both the units here.
{PM_UNIT_FB,           {0x00000100,   0,  0, 1},       {0x00000100,   4,  9, 6},      1, NV_FBPA_PRI_BASE,                      NV_FBPA_PRI_STRIDE, 0},
// FB - watch buses from 20 to 31 (decimal) are assigned to FBPA02PM_LTC_FB_PERF_MUXED_BUS_#
{PM_UNIT_FB1,          {0x00000100,   0,  0, 1},       {0x00000100,   4,  9, 6},      1, (NV_FBPA_PRI_BASE+NV_FBPA_PRI_STRIDE), NV_FBPA_PRI_STRIDE, 0},
// FB1 - watch buses from 32 to 43 (decimal) are assigned to FBPA12PM_LTC_FB_PERF_MUXED_BUS_#

{PM_UNIT_HUBMMU,       {INVALID_ADDRESS,   0,  0, 0},  {0x00100C84,   0,  5, 6},      1, 0, 0, 0},
// HUBMMU - watch buses from 5 to 8(decimal) are assigned to HUBMMU2PM_HUB_MUXED_BUS_#
// TODO: add other units here
{PM_UNIT_MAX                                                                          }
};



PerfUnitTable PerfUnitTableGF119[] = {
// Unit-name                 PM enable                       GroupSel              maxGroups
//                      register  start end val        register  start end width
// smquick has different regiser width for group selection
{PM_UNIT_SM,           {0x00000600,  31, 31, 1},       {0x00000600,  0,  7,  8},      1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// SM  - watch buses from 49 to 56 (decimal) are assigned to SM2PM_GPC_MUXED_BUS_#
{PM_UNIT_MPC,          {0x0000040c,  31, 31, 1},       {0x0000040c,  0,  5,  6},      1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// MPC - watch buses from 32 to 40 (decimal) are assigned to MPC2PM_MUXED_BUS_#
{PM_UNIT_L1C,          {0x000004a8,  31, 31, 1},       {0x000004a8,  0,  5,  6},      1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// L1C - watch buses from  0 to  9 (decimal) are assigned to L1C2PM_GPC_MUXED_BUS_#
{PM_UNIT_TEX,          {0x000002c0,  31, 31, 1},       {0x000002C0,  0,  3,  4},      1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE, {0x000002c8,  31, 31, 1}, {0x000002C8,  0,  2,  3}},
{PM_UNIT_TEX_D,        {0x000002bc,  31, 31, 1},       {0x000002bc,  0,  2,  3},      1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE, {0x000002c8,  31, 31, 1}, {0x000002C8,  3,  3,  1}},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#

//Ideally in GF119 we should enable one L2 slice and disable all others to profile an L2 slice correctly, but since in G119, we have only 1 L2 slice we need not do that.
//May have to consider it for GF117.
{PM_UNIT_LTC,          {0x0000025c,   0,  0, 1},       {0x0000025c,  1,  3,  3},      1, (NV_PLTCG_BASE+NV_PLTS_BASE),          NV_PLTCG_STRIDE,    NV_PLTS_STRIDE, {0x00000028,   0,  0, 1},       {0x00000028,  1,  3,  3}},
{PM_UNIT_LTC1,         {0x0000025c,   0,  0, 1},       {0x0000025c,  4,  8,  5},      1, (NV_PLTCG_BASE+NV_PLTS_BASE),          NV_PLTCG_STRIDE,    NV_PLTS_STRIDE, {0x00000028,   0,  0, 1},       {0x00000028,  4,  8,  5}},
{PM_UNIT_LTC2,         {0x0000025c,   0,  0, 1},       {0x0000025c,  9,  13, 5},      1, (NV_PLTCG_BASE+NV_PLTS_BASE),          NV_PLTCG_STRIDE,    NV_PLTS_STRIDE, {0x00000028,   0,  0, 1},       {0x00000028,  9,  13, 5}},
{PM_UNIT_FB,           {0x00000100,   0,  0, 1},       {0x00000100,  4,  9, 6},       1, NV_FBPA_PRI_BASE,                      NV_FBPA_PRI_STRIDE, 0},
//FB - mwatch buses from 0 to 11(decimal) are assigned to FBPA2PM_LTC_FB_PERF_MUXED_BUS_#
{PM_UNIT_HUBMMU,       {INVALID_ADDRESS,   0,  0, 0},  {0x00100C84,   0,  5, 6},      1, 0,                                     0,                  0},
// HUBMMU - watch buses from 5 to 8(decimal) are assigned to HUBMMU2PM_HUB_MUXED_BUS_#
// TODO: add other units here
{PM_UNIT_MAX                                                                          }
};

PerfSignalTableNew PerfSignalTableGF100_gpc0[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type
    // ########### SM Unit ###########
    // ***LOAD/STORE***
    // agu_l1_local_ld                  AGU L1 LD is to local space (based on priority thread space)
    // agu_l1_global_ld                 AGU L1 LD is to global space (based on priority thread space)
    // agu_l1_local_st                  AGU L1 ST is to local space (based on priority thread space)
    // agu_l1_global_st                 AGU L1 ST is to global space (based on priority thread space)
    // agu_l1_shared_ld                 AGU L1 LD is to shared space (based on priority thread space)
    // agu_l1_shared_st                 AGU L1 ST is to shared space (based on priority thread space)
#ifdef SMPM
    { HWPM_FERMI_AGU_L1_LOCAL_LD,                  hwpm_fermi_agu_l1_local_ld_enc_str_1,               0x00000064, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_AGU_L1_LOCAL_ST,                  hwpm_fermi_agu_l1_local_st_enc_str_1,              0x00000064, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_AGU_L1_GLOBAL_LD,                 hwpm_fermi_agu_l1_global_ld_enc_str_1,              0x00000064, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_AGU_L1_GLOBAL_ST,                 hwpm_fermi_agu_l1_global_st_enc_str_1,              0x00000064, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_AGU_L1_SHARED_LD,                 hwpm_fermi_agu_l1_shared_ld_enc_str_1,              0x00000064, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_AGU_L1_SHARED_ST,                 hwpm_fermi_agu_l1_shared_st_enc_str_1,             0x00000064, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ***BRANCH***
    // fet_fetch_hit_vld                FET made fetch request for any warp (icache hit)
    // fet_fetch_flow_control           FET: one of the fetched inst(s) is a flow control inst
    // FERMI_FET_FETCH_BRANCH                 fet_fetch_hit_vld && fet_fetch_flow_control
    //{ FERMI_FET_FETCH_BRANCH,               "fet_fetch_branch",         "fet_fetch_branch",         0x00000012, 0x00000010, 0x00008888,  0x3231,       FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,0,0,0,0,0,0}, SIG_TYPE_MULTIPLE, PM_CHIPLET_TYPE_GPC },
    //{ FERMI_FET_FETCH_FLOW_CONTROL,         "fet_fetch_flow_control",   "fet_fetch_flow_control",   0x00000012, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    //{ FERMI_FET_FETCH_INST_COUNT,           "fet_fetch_inst_count",     "fet_fetch_inst_count",     0x00000012, 0x00000002, 0x0000AAAA,  0X33,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,1,1,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },

    // fet_unique_branches              FET: number of processed (SW) unique branches
    // fet_taken_branches               FET: number of processed (SW) unique (any thread) taken branches
    //                                  i.e. number of unique branches that have at least one thread taken
    { HWPM_FERMI_FET_UNIQUE_BRANCHES,              hwpm_fermi_fet_unique_branches_enc_str_1,                   0x0000001a, 0x00000010, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_FET_TAKEN_BRANCHES,               hwpm_fermi_fet_taken_branches_enc_str_1,     0x00000019, 0x00000010, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },

    // ***DIVERGENT BRANCHES***
    // fet_odd_unique_diverged_imm      FET: odd half processed a unique diverged non-indexed branch
    // fet_odd_unique_diverged_idx      FET: odd half processed a unique diverged indexed branch
    // fet_even_unique_diverged_imm     FET: even half processed a unique diverged non-indexed branch
    // fet_even_unique_diverged_idx     FET: even half processed a unique diverged indexed branch
    // FERMI_FET_ODD_UNIQUE_DIVERGED_BRA  =   fet_odd_unique_diverged_imm || fet_odd_unique_diverged_idx
    // FERMI_FET_EVEN_UNIQUE_DIVERGED_BRA =   fet_even_unique_diverged_imm || fet_even_unique_diverged_idx
    //{ FERMI_FET_ODD_UNIQUE_DIVERGED_BRA,    "fet_odd_unique_diverged_bra",  "fet_odd_unique_diverged_bra",      0x00000016, 0x00000054, 0x0000EEEE,  0x3635,       FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,0,0}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },
    //{ FERMI_FET_EVEN_UNIQUE_DIVERGED_BRA,   "fet_even_unique_diverged_bra", "fet_even_unique_diverged_bra",     0x00000018, 0x00000054, 0x0000EEEE,  0x3635,       FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,0,0}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },

    // fet_diverged_branches            FET: number of processed (SW) unique diverged branches
    // fet_odd_control_flow_stall       = sm2pm_gpc_fet_even_active & !sm2pm_gpc_fet_even_request & sm2pm_gpc_fet_even_all_branching
    // fet_even_control_flow_stall      = sm2pm_gpc_fet_odd_active & !sm2pm_gpc_fet_odd_request & sm2pm_gpc_fet_odd_all_branching
    //                                  When a side is not able to fetch and it is that side's turn to fetch and SCH can accept instructions (enough scoreboard and instruction buffer slots),
    //                                  increment by the number of warps which have enough InstructionBuffer/Scoreboard entries but can't fetch due to control flow

    { HWPM_FERMI_FET_DIVERGED_BRANCHES,            hwpm_fermi_fet_diverged_branches_enc_str_1,           0x00000019, 0x00000032, 0x0000FFFF,  0x33,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,1,1,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_FET_ODD_CONTROL_FLOW_STALL,       hwpm_fermi_fet_odd_control_flow_stall_enc_str_1,  0x00000020, 0x00000014, 0x00002020,  0x313235,     FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,0,0,1,0,0,0}, SIG_TYPE_MULTIPLE,   PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_FET_EVEN_CONTROL_FLOW_STALL,      hwpm_fermi_fet_even_control_flow_stall_enc_str_1, 0x00000021, 0x00000014, 0x00002020,  0x313235,     FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,0,0,1,0,0,0}, SIG_TYPE_MULTIPLE,   PM_CHIPLET_TYPE_GPC },

    // ***INSTRUCTIONS***
    // sch_odd_issue                    SCH odd half issued an instruction
    // sch_even_issue                   SCH even half issued an instruction
    //{ FERMI_SCH_ODD_ISSUE,                  "sch_odd_issue",            "sch_odd_issue",            0x0000002c, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_EVEN_ISSUE,                 "sch_even_issue",           "sch_even_issue",           0x0000002c, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_EVEN_THREAD_INST_DECODED,   "sch_even_thread_inst_decoded","sch_even_thread_inst_decoded",  0x0000002f, 0x00543210, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_ODD_THREAD_INST_DECODED,    "sch_odd_thread_inst_decoded", "sch_odd_thread_inst_decoded",   0x00000030, 0x00543210, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ***REPLAY REASONS***
    // sl_l1_deferred                   SL L1 had a defer (defer_mask != 0)
    //                                  i.e. total number of replays due to L1 deferral. cost not because of the program, but L1 design. counted in sl
    // sl_l1_divergent                  SL L1 instr had a replay due to divergence
    //                                  i.e. total number of replays due to memory address divergence. basically the extra cost you pay for your program pattern (serialization). counted in sl
    // sl_l1_replayed                   SL L1 instr replayed (due to divergence or defer)
    //                                  i.e. total number of memory instructions (instruction count) that are replayed (i.e. divergent or deferred). note: divergence and L1 deferral can happen for the same instruction. counted in sl
    // sch_even_imc_replay              sch got a replay request from imc
    // sch_odd_imc_replay               sch got a replay request from imc
    // sch_replay_others                SCH number of imc/idc miss or ipa replays
    // dsm_ipa_or_pixld_replay          DSM replay on an ipa or pixld instruction
    // agu_idc_replayed                 AGU indexed c$ access replayed
    //                                  i.e. total number of constant cache instructions that are replayed. counted in aguc

    // sm_even_imc_miss_replay          sm2pm_gpc_dsm_imc0_miss | sm2pm_gpc_dsm_imc0_match | sm2pm_gpc_dsm_imc0_full
    //                                  i.e. number of replays due to IMC miss
    // sm_odd_imc_miss_replay           sm2pm_gpc_dsm_imc1_miss | sm2pm_gpc_dsm_imc1_match | sm2pm_gpc_dsm_imc1_full
    //                                  i.e. number of replays due to IMC miss
    { HWPM_FERMI_SL_L1_DEFERRED,                   hwpm_fermi_sl_l1_deferred_enc_str_1,         0x0000006a, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SL_L1_DIVERGENT,                  hwpm_fermi_sl_l1_divergent_enc_str_1,        0x0000006a, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SL_L1_REPLAYED,                   hwpm_fermi_sl_l1_replayed_enc_str_1,         0x0000006a, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_EVEN_IMC_REPLAY,            "__sch_even_imc_replay",    0x00000025, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_ODD_IMC_REPLAY,             "__sch_odd_imc_replay",     0x00000025, 0x00000007, 0x0000AAAA,  0x38,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,0,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_DSM_EVEN_IMC_MISS_REPLAY,         fermi_dsm_even_imc_miss_replay_enc_str_4,0x00000062, 0x00000321, 0x0000FEFE,  0x343332,     FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_DSM_ODD_IMC_MISS_REPLAY,          fermi_dsm_odd_imc_miss_replay_enc_str_4, 0x00000062, 0x00000765, 0x0000FEFE,  0x383736,     FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,1,1}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_REPLAY_OTHERS,              "__sch_replay_others",      0x0000002c, 0x00000076, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_DSM_IPA_OR_PIXLD_REPLAY,          hwpm_fermi_dsm_ipa_or_pixld_replay_enc_str_1,0x00000057, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_AGU_IDC_REPLAYED,                 hwpm_fermi_agu_idc_replayed_enc_str_1,       0x00000068, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ***LAUNCHED***
    // sch_warps_launched               SM has launched 1 warp
    // sch_threads_launched             number of threads SM launched this cycle
    { HWPM_FERMI_SCH_WARPS_LAUNCHED,               hwpm_fermi_sch_warps_launched_enc_str_1,           0x00000026, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_THREADS_LAUNCHED,             hwpm_fermi_sch_threads_launched_enc_str_1,         0x00000026, 0x00000001, 0x0000FFFF,  0x32,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,1,1,1,1,1,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ****ACTIVE_WARPS***
    // sch_active_cycles                sch has at lest 1 active warp.
    // sch_active_warps                 number of active warps SM currently has
    //                                  i.e. Every cycle, increment this counter by the number of active warps
    //{ FERMI_SCH_ACTIVE_CYCLES,              "sch_active_cycles",        0x00000024, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ACTIVE_WARPS,                 hwpm_fermi_sch_active_warps_enc_str_1,             0x00000024, 0x00000001, 0x0000FFFF,  0x32,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,1,1,1,1,1,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // sch_warp_issue_holes             number of warps not eligible to be issued this cycle
    //                                  i.e. Every cycle, increment this counter by the number of active warps that do not have an instruction eligible for issue due to warp only reasons.
    //                                  Warp only reason includes register scoreboard, 3 cycle reissue limit, no instruction in the SCH. If any warp only reason is true, the count is incremented regardless of any other ineligibility reason.
    { HWPM_FERMI_SCH_WARP_ISSUE_HOLES,             hwpm_fermi_sch_warp_issue_holes_enc_str_1,   0x00000027, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // sch_warp_issue_holes_long        number of warps not eligible to be issued for > 32 cycles
    //                                  i.e. similar to warp_issue_holes, but only count warps that have not been issue for at least 31 cycles.
    { HWPM_FERMI_SCH_WARP_ISSUE_HOLES_LONG,        hwpm_fermi_sch_warp_issue_holes_long_enc_str_1, 0x00000028,0x00000000,  0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // sch_warp_issue_eligible          number of warps eligible to be issued this cycle
    //                                  i.e. Every cycle, increment this counter by the number of warps eligible to issue. A warp is counted if it eligible for issue, even it is not ultimately selected.
    { HWPM_FERMI_SCH_WARP_ISSUE_ELIGIBLE,          hwpm_fermi_sch_warp_issue_eligible_enc_str_1,    0x00000029, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // fet_icc_miss                     FET: fetch resulted in an I$ miss
    //                                  i.e. count the number of cache new misses. Covered misses and miss fail are not counted.
    // fet_icc_hit                      FET: fetch resulted in an I$ hit
    //                                  i.e. count the number of cache hits
    { HWPM_FERMI_FET_ICC_MISS,                     hwpm_fermi_fet_icc_miss_enc_str_1,               0x00000014, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_FET_ICC_HIT,                      hwpm_fermi_fet_icc_hit_enc_str_1,                0x00000014, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // fet_any_active                   FET: has at least 1 active warp
    //                                  i.e. Count total number of cycles SM has at least one active warp, existing warp, not necessarily to be schedulable
    { HWPM_FERMI_FET_ANY_ACTIVE,                   hwpm_fermi_fet_any_active_enc_str_1,            0x00000011, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // sch_even_cant_issue_no_inst              SCH number of warps with no instructions in the IB
    // sch_even_cant_issue_interlock_long       SCH number of warps blocked on ld/st or scoreboard interlock > 32 clocks
    // sch_even_cant_issue_interlock_short      SCH number of warps blocked on ld/st or scoreboard interlock < 32 clocks
    // sch_even_cant_issue_reissue              SCH number of warps blocked by 3 cycle reissue limit
    // sch_even_cant_issue_dsm_q_full           SCH number of warps blocked by full dsm queue
    // sch_even_cant_issue_barrier              SCH number of warps blocked by barrier
    // sch_even_cant_issue_l1_sleep             SCH number of warps blocked by l1 deferral
    // sch_even_cant_issue_all                  SCH number of warps blocked by any reason

    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_NO_INST,          hwpm_fermi_sch_even_cant_issue_no_inst_enc_str_1,        0x0000003b, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_INTERLOCK_LONG,   hwpm_fermi_sch_even_cant_issue_interlock_long_enc_str_1, 0x0000003c, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_INTERLOCK_SHORT,  hwpm_fermi_sch_even_cant_issue_interlock_short_enc_str_1,0x0000003d, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_REISSUE,          hwpm_fermi_sch_even_cant_issue_reissue_enc_str_1,        0x0000003e, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_DSM_Q_FULL,       hwpm_fermi_sch_even_cant_issue_dsm_q_full_enc_str_1,     0x0000003f, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_TEX_SIDE,         hwpm_fermi_sch_even_cant_issue_tex_side_enc_str_1,       0x00000043, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_BARRIER,          hwpm_fermi_sch_even_cant_issue_barrier_enc_str_1,        0x00000045, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_L1_SLEEP,         hwpm_fermi_sch_even_cant_issue_l1_sleep_enc_str_1,       0x00000046, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_ALL,              hwpm_fermi_sch_even_cant_issue_all_enc_str_1,            0x00000047, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_NO_INST,           hwpm_fermi_sch_odd_cant_issue_no_inst_enc_str_1,         0x00000048, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_INTERLOCK_LONG,    hwpm_fermi_sch_odd_cant_issue_interlock_long_enc_str_1,  0x00000049, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_INTERLOCK_SHORT,   hwpm_fermi_sch_odd_cant_issue_interlock_short_enc_str_1, 0x0000004a, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_REISSUE,           hwpm_fermi_sch_odd_cant_issue_reissue_enc_str_1,         0x0000004b, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_DSM_Q_FULL,        hwpm_fermi_sch_odd_cant_issue_dsm_q_full_enc_str_1,      0x0000004c, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_TEX_SIDE,          hwpm_fermi_sch_odd_cant_issue_tex_side_enc_str_1,        0x00000050, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_BARRIER,           hwpm_fermi_sch_odd_cant_issue_barrier_enc_str_1,         0x00000052, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_L1_SLEEP,          hwpm_fermi_sch_odd_cant_issue_l1_sleep_enc_str_1,        0x00000053, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_ALL,               hwpm_fermi_sch_odd_cant_issue_all_enc_str_1,             0x00000054, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
#endif

    // ########### MPC Unit ###########
    // mpc_total_CTAs_launched          Total number of CTAs launched by this MPC
    { FERMI_MPC_TOTAL_CTAS_LAUNCHED,          fermi_mpc_total_ctas_launched_enc_str_1,          0x0000000e, 0x00000006, 0x0000AAAA,  0x26,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_MPC,    {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ########### L1 Cache (L1C) Unit ###########
    // local_load_hit                   local load hit (includes LinkAs)
    // local_load_miss                  local load miss(includes LinkBs)
    // local_store_hit                  local store hit
    // local_store_miss                 local store miss
    // global_load_hit                  global load hit
    // global_load_miss                 global load miss (only cached global loads that miss)
    // uncached_global_load             uncached global load count. Increments by 1 for each 32bit word.
    // global_store                     global store - always uncached. Increments by 1 for each 32bit word.
    { FERMI_L1C_SHARED_LOAD_TRANSACTIONS,     fermi_l1c_shared_load_transactions_enc_str_1, 0x00000000, 0x00000000, 0x0000AAAA,  0x0,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_L1C,    {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_SHARED_STORE_TRANSACTIONS,    fermi_l1c_shared_store_transactions_enc_str_1,0x00000000, 0x00000001, 0x0000AAAA,  0x1,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_L1C,    {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_LOCAL_LOAD_HIT,               fermi_l1c_local_load_hit_enc_str_1,          0x00000001, 0x00000000, 0x0000AAAA,  0x0,          FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_L1C,    {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_LOCAL_LOAD_MISS,              fermi_l1c_local_load_miss_enc_str_1,         0x00000001, 0x00000001, 0x0000AAAA,  0x1,          FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_L1C,    {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_LOCAL_STORE_HIT,              fermi_l1c_local_store_hit_enc_str_1,         0x00000001, 0x00000002, 0x0000AAAA,  0x2,          FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_L1C,    {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_LOCAL_STORE_MISS,             fermi_l1c_local_store_miss_enc_str_1,        0x00000001, 0x00000003, 0x0000AAAA,  0x3,          FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_L1C,    {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_PARTIAL_LOCAL_STORE_MISS,     fermi_l1c_partial_local_store_miss_enc_str_1,0x00000001, 0x00000043, 0x00008888,  0x0403,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_L1C,    {0,0,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_GLOBAL_LOAD_HIT,              fermi_l1c_global_load_hit_enc_str_1,         0x00000001, 0x00000005, 0x0000AAAA,  0x5,          FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_L1C,    {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_GLOBAL_LOAD_MISS,             fermi_l1c_global_load_miss_enc_str_1,        0x00000001, 0x00000006, 0x0000AAAA,  0x6,          FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_L1C,    {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DIRTY_LINE_EVICTION,          fermi_l1c_dirty_line_eviction_enc_str_1,     0x00000001, 0x00000007, 0x0000AAAA,  0x7,          FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_L1C,    {0,0,0,0,0,0,0,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_UNCACHED_GLOBAL_LOAD,         fermi_l1c_uncached_global_load_enc_str_1, 0x00000002, 0x00000002, 0x0000AAAA,  0x2,          FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_L1C,    {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_GLOBAL_STORE,                 fermi_l1c_global_store_enc_str_1,         0x00000002, 0x00000003, 0x0000AAAA,  0x3,          FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_L1C,    {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ***DEFER REASONS***
    // defer_prt_full                   PRT is full
    //                                  i.e. count number of L1 PRT full deferral
    // defer_gni_stall                  GNI backpressures L1
    //                                  i.e. count number of deferes due to GNI backpressure (t2m fifo full) L1
    // defer_no_allocatable_cline       all ways are not allocatable
    //                                  i.e. count number of defers due to all lines in the same set having pending operations
    // defer_shared_bank_conflict       shared load/store bank conflict (>1 address within same bank accessed)
    // defer_store_bank_collision       Counts global atom/red memory conflicts (where multiple threads from a warp are writing into same memory-word)
    // defer_prt_load_limit             PRT reached load limit
    //                                  i.e. count number of times L1 had to defer cached loads because it reached PRT load limit
    // defer_prt_store_limit            PRT reached store limit
    //                                  i.e. count number of times L1 had to defer cached stores because it reached PRT store limit
    // defer_uncached_load_limit        reached max # uncached LDs to same set
    //                                  i.e. count number of times L1 is deferred because max number of uncached LD to the same set is reached
    { FERMI_L1C_DEFER_PRT_FULL,               fermi_l1c_defer_prt_full_enc_str_1,             0x00000005, 0x00000004, 0x0000AAAA,  0x04,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_L1C,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DEFER_GNI_STALL,              fermi_l1c_defer_gni_stall_enc_str_1,            0x00000005, 0x00000005, 0x0000AAAA,  0x05,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_L1C,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DEFER_NO_ALLOCATABLE_CLINE,   fermi_l1c_defer_no_allocatable_cline_enc_str_1, 0x00000005, 0x00000006, 0x0000AAAA,  0x06,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_L1C,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DEFER_SHARED_BANK_CONFLICT,   fermi_l1c_defer_shared_bank_conflict_enc_str_1,          0x00000006, 0x00000000, 0x0000AAAA,  0x00,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_L1C,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DEFER_STORE_BANK_COLLISION,   fermi_l1c_defer_store_bank_collision_enc_str_1, 0x00000006, 0x00000001, 0x0000AAAA,  0x01,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_L1C,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DEFER_PRT_LOAD_LIMIT,         fermi_l1c_defer_prt_load_limit_enc_str_1,       0x00000006, 0x00000003, 0x0000AAAA,  0x03,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_L1C,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DEFER_PRT_STORE_LIMIT,        fermi_l1c_defer_prt_store_limit_enc_str_1,      0x00000006, 0x00000004, 0x0000AAAA,  0x04,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_L1C,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DEFER_UNCACHED_LOAD_LIMIT,    fermi_l1c_defer_uncached_load_limit_enc_str_1,  0x00000006, 0x00000005, 0x0000AAAA,  0x05,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_L1C,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
#ifdef SMPM
    // NOP TRIGGERS
    // dsm_nop_trig_grp0                DSM: NOP trigger[7:0]
    // dsm_nop_trig_grp1                DSM: NOP trigger[15:8]
    { HWPM_FERMI_NOP_TRIG_00,                      hwpm_fermi_nop_trig_00_enc_str_1,          0x00000001, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_01,                      hwpm_fermi_nop_trig_01_enc_str_1,          0x00000001, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_02,                      hwpm_fermi_nop_trig_02_enc_str_1,          0x00000001, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_03,                      hwpm_fermi_nop_trig_03_enc_str_1,          0x00000001, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_04,                      hwpm_fermi_nop_trig_04_enc_str_1,          0x00000001, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_05,                      hwpm_fermi_nop_trig_05_enc_str_1,          0x00000001, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_06,                      hwpm_fermi_nop_trig_06_enc_str_1,          0x00000001, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_07,                      hwpm_fermi_nop_trig_07_enc_str_1,          0x00000001, 0x00000007, 0x0000AAAA,  0x38,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,0,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_08,                      hwpm_fermi_nop_trig_08_enc_str_1,             0x00000002, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_09,                      hwpm_fermi_nop_trig_09_enc_str_1,             0x00000002, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_10,                      hwpm_fermi_nop_trig_10_enc_str_1,             0x00000002, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_11,                      hwpm_fermi_nop_trig_11_enc_str_1,             0x00000002, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_12,                      hwpm_fermi_nop_trig_12_enc_str_1,             0x00000002, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_13,                      hwpm_fermi_nop_trig_13_enc_str_1,             0x00000002, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_14,                      hwpm_fermi_nop_trig_14_enc_str_1,             0x00000002, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_15,                      hwpm_fermi_nop_trig_15_enc_str_1,             0x00000002, 0x00000007, 0x0000AAAA,  0x38,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,0,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // sch_inst_issued                  number of insts issued this cycle
    //                                  i.e. count instructions issued (inc each cycle by 0 to 2)
    // sch_inst_decoded                 SCH insts decoded this cycle
    //                                  i.e. Count total number of instructions executed, do not count replay. It counts the number of instructions decoded in SCH
    { HWPM_FERMI_SCH_INST_ISSUED,                  hwpm_fermi_sch_inst_issued_enc_str_1,              0x00000027, 0x00000076, 0x0000FFFF,  0x37,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_INST_DECODED,                 hwpm_fermi_sch_inst_decoded_enc_str_1,            0x0000002d, 0x00000010, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    //sch_even_thread_inst_decoded      even half threads decoded
    //sch_odd_thread_inst_decoded       odd half threads decoded
    //Count threads executed at even/odd side, it is inst_executed at even/odd side multiplied by active mask, predicated off threads are also included.
    { HWPM_FERMI_SCH_EVEN_THREAD_INST_DECODED,     hwpm_fermi_sch_even0_thread_inst_decoded_enc_str_1, 0x0000002f, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_THREAD_INST_DECODED,      hwpm_fermi_sch_odd0_thread_inst_decoded_enc_str_1, 0x00000030, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // sm_odd_alu_only_inst_executed                Count ALU pipe only instructions decoded on the odd side
    // sm_odd_xlu_only_inst_executed                count XLU pipe only instructions decoded on the odd side
    // sm_odd_alu_xlu_bipipe_inst_executed          count ALU XLU bipipe instructions decoded on the odd side
    // sm_odd_fmalite_only_inst_executed            Count FMALite pipe instructions decoded on the odd side
    // sm_odd_fma32_only_inst_executed              count FMA32 only instruction decoded on the odd side
    // sm_odd_fmalite_fma32_bipipe_inst_executed    count FMALite FMA32 bipipe instruction decoded on the odd side
    // sm_odd_fu_inst_executed                      count FU pipe instruction decoded on the odd side
    // sm_odd_fma64_inst_executed                   count FMA64 pipe instruction decoded on the odd side
    // sm_odd_su_inst_executed                      count SU pipe instruction decoded on the odd side
    // sm_odd_agu_inst_executed                     count AGU pipe instruction decoded on the odd side
    // sm_odd_tex_inst_executed                     count TEX instruction decoded on the odd side
    // sm_odd_dsm_inst_executed                     count DSM pipe instruction decoded on the odd side
    // sm_odd_sch_internal_inst_executed            count SCH internal instruction decoded on the odd side
    // sm_odd_fe_inst_executed                      count FE pipe instruction decoded on the odd side


    { HWPM_FERMI_SM_ODD_ALU_ONLY_INST_EXECUTED,              hwpm_fermi_sm_odd_alu_only_inst_executed_enc_str_1,            0x00000055, 0x00007654, 0x00000800, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD_XLU_ONLY_INST_EXECUTED,              hwpm_fermi_sm_odd_xlu_only_inst_executed_enc_str_1,            0x00000055, 0x00007654, 0x00000004, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD_ALU_XLU_BIPIPE_INST_EXECUTED,        hwpm_fermi_sm_odd_alu_xlu_bipipe_inst_executed_enc_str_1,      0x00000055, 0x00007654, 0x00000002, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD_FMALITE_ONLY_INST_EXECUTED,          hwpm_fermi_sm_odd_fmalite_only_inst_executed_enc_str_1,        0x00000055, 0x00007654, 0x00000400, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD_FMA32_ONLY_INST_EXECUTED,            hwpm_fermi_sm_odd_fma32_only_inst_executed_enc_str_1,          0x00000055, 0x00007654, 0x00000010, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD_FMALITE_FMA32_BIPIPE_INST_EXECUTED,  hwpm_fermi_sm_odd_fmalite_fma32_bipipe_inst_executed_enc_str_1,0x00000055, 0x00007654, 0x00000001, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD_FU_INST_EXECUTED,                    hwpm_fermi_sm_odd_fu_inst_executed_enc_str_1,                  0x00000055, 0x00007654, 0x00000020, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD_FMA64_INST_EXECUTED,                 hwpm_fermi_sm_odd_fma64_inst_executed_enc_str_1,               0x00000055, 0x00007654, 0x00000040, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD_SU_INST_EXECUTED,                    hwpm_fermi_sm_odd_su_inst_executed_enc_str_1,                  0x00000055, 0x00007654, 0x00000008, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD_AGU_INST_EXECUTED,                   hwpm_fermi_sm_odd_agu_inst_executed_enc_str_1,                 0x00000055, 0x00007654, 0x00000080, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD_TEX_INST_EXECUTED,                   hwpm_fermi_sm_odd_tex_inst_executed_enc_str_1,                 0x00000055, 0x00007654, 0x00000100, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD_DSM_INST_EXECUTED,                   hwpm_fermi_sm_odd_dsm_inst_executed_enc_str_1,                 0x00000055, 0x00007654, 0x00000200, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD_SCH_INTERNAL_INST_EXECUTED,          hwpm_fermi_sm_odd_sch_internal_inst_executed_enc_str_1,        0x00000055, 0x00007654, 0x00002000, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD_FE_INST_EXECUTED,                    hwpm_fermi_sm_odd_fe_inst_executed_enc_str_1,                  0x00000055, 0x00007654, 0x00001000, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },


    // sm_even_alu_only_inst_executed               Count ALU pipe only instructions decoded on the even side
    // sm_even_xlu_only_inst_executed               count XLU pipe only instructions decoded on the even side
    // sm_even_alu_xlu_bipipe_inst_executed         count ALU XLU bipipe instructions decoded on the even side
    // sm_even_fmalite_only_inst_executed           Count FMALite pipe instructions decoded on the even side
    // sm_even_fma32_only_inst_executed             count FMA32 only instruction decoded on the even side
    // sm_even_fmalite_fma32_bipipe_inst_executed   count FMALite FMA32 bipipe instruction decoded on the even side
    // sm_even_fu_inst_executed                     count FU pipe instruction decoded on the even side
    // sm_even_fma64_inst_executed                  count FMA64 pipe instruction decoded on the even side
    // sm_even_su_inst_executed                     count SU pipe instruction decoded on the even side
    // sm_even_agu_inst_executed                    count AGU pipe instruction decoded on the even side
    // sm_even_tex_inst_executed                    count TEX instruction decoded on the even side
    // sm_even_dsm_inst_executed                    count DSM pipe instruction decoded on the even side
    // sm_even_sch_internal_inst_executed           count SCH internal instruction decoded on the even side
    // sm_even_fe_inst_executed                     count FE pipe instruction decoded on the even side

    { HWPM_FERMI_SM_EVEN_ALU_ONLY_INST_EXECUTED,              hwpm_fermi_sm_even_alu_only_inst_executed_enc_str_1,            0x00000055, 0x00003210, 0x00000800, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN_XLU_ONLY_INST_EXECUTED,              hwpm_fermi_sm_even_xlu_only_inst_executed_enc_str_1,            0x00000055, 0x00003210, 0x00000004, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN_ALU_XLU_BIPIPE_INST_EXECUTED,        hwpm_fermi_sm_even_alu_xlu_bipipe_inst_executed_enc_str_1,      0x00000055, 0x00003210, 0x00000002, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN_FMALITE_ONLY_INST_EXECUTED,          hwpm_fermi_sm_even_fmalite_only_inst_executed_enc_str_1,        0x00000055, 0x00003210, 0x00000400, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN_FMA32_ONLY_INST_EXECUTED,            hwpm_fermi_sm_even_fma32_only_inst_executed_enc_str_1,          0x00000055, 0x00003210, 0x00000010, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN_FMALITE_FMA32_BIPIPE_INST_EXECUTED,  hwpm_fermi_sm_even_fmalite_fma32_bipipe_inst_executed_enc_str_1,0x00000055, 0x00003210, 0x00000001, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN_FU_INST_EXECUTED,                    hwpm_fermi_sm_even_fu_inst_executed_enc_str_1,                  0x00000055, 0x00003210, 0x00000020, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN_FMA64_INST_EXECUTED,                 hwpm_fermi_sm_even_fma64_inst_executed_enc_str_1,               0x00000055, 0x00003210, 0x00000040, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN_SU_INST_EXECUTED,                    hwpm_fermi_sm_even_su_inst_executed_enc_str_1,                  0x00000055, 0x00003210, 0x00000008, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN_AGU_INST_EXECUTED,                   hwpm_fermi_sm_even_agu_inst_executed_enc_str_1,                 0x00000055, 0x00003210, 0x00000080, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN_TEX_INST_EXECUTED,                   hwpm_fermi_sm_even_tex_inst_executed_enc_str_1,                 0x00000055, 0x00003210, 0x00000100, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN_DSM_INST_EXECUTED,                   hwpm_fermi_sm_even_dsm_inst_executed_enc_str_1,                 0x00000055, 0x00003210, 0x00000200, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN_SCH_INTERNAL_INST_EXECUTED,          hwpm_fermi_sm_even_sch_internal_inst_executed_enc_str_1,        0x00000055, 0x00003210, 0x00002000, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN_FE_INST_EXECUTED,                    hwpm_fermi_sm_even_fe_inst_executed_enc_str_1,                  0x00000055, 0x00003210, 0x00001000, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
#endif
    //Tex signals
    //tex0_cache_sector_queries  = tex2pm_gpc_t_sector_queries
    //tex0_cache_sector_misses   = tex2pm_gpc_t_missed_sectors
    { FERMI_TEX_CACHE_SECTOR_QUERIES,    fermi_tex_cache_sector_queries_enc_str_1, 0x00000005, 0x00000000, 0x0000FFFF, 0x0000000e, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_TEX,     {0,0,0,0,1,1,1,1,1,0 }, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_TEX_CACHE_SECTOR_MISSES,     fermi_tex_cache_sector_misses_enc_str_1,  0x00000004, 0x00000000, 0x0000FFFF, 0x0000000a, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_TEX,     {1,1,1,1,1,0,0,0,0,0 }, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    { FERMI_TEX0_RETURN_PACKET_COUNT,    fermi_tex0_return_packet_count_enc_str_1,   0x00000003, 0x00000000, 0x00008888, 0x00006263, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_TEX_D,     {0,0,0,0,0,0,0,0,0,0 }, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC},

    { FERMI_ELAPSED_CYCLES_SM,     fermi_elapsed_cycles_sm_enc_str_1,  0x00000000, 0x00000000, 0x00000000, 0x00000000, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000, 0x00000000,  0x00,         FERMI_CLK_DOMAIN_MAX,     PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE }
};

PerfSignalTableNew PerfSignalTableGF100_ltc0[] = {
    //FBP signals
    //fb_subp*_read_sectors = pm_subp${subp}_dramc_read
    { FERMI_FB_SUBP0_DRAMC_READ,                          fermi_fb_subp0_dramc_read_enc_str_1,                        0x00000011, 0x00000000, 0x0000AAAA,  0x0000000f, FERMI_CLK_DOMAIN_GF100_LTC0,   PM_UNIT_FB,     {1,0,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB_SUBP1_DRAMC_READ,                          fermi_fb_subp1_dramc_read_enc_str_1,                        0x00000012, 0x00000000, 0x0000AAAA,  0x0000000f, FERMI_CLK_DOMAIN_GF100_LTC0,   PM_UNIT_FB,     {1,0,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    //fb_subp*_write_sectors = pm_subp${subp}_dramc_write
    { FERMI_FB_SUBP0_DRAMC_WRITE,                         fermi_fb_subp0_dramc_write_enc_str_1,                       0x00000011, 0x00000001, 0x0000AAAA,  0x00000010, FERMI_CLK_DOMAIN_GF100_LTC0,   PM_UNIT_FB,     {0,1,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB_SUBP1_DRAMC_WRITE,                         fermi_fb_subp1_dramc_write_enc_str_1,                       0x00000012, 0x00000001, 0x0000AAAA,  0x00000010, FERMI_CLK_DOMAIN_GF100_LTC0,   PM_UNIT_FB,     {0,1,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    //fb_subp*_write_activates = pm_subp${subp}_actarb_activate from spec file
    { FERMI_FB_SUBP0_DRAM_ACTIVATES,                      fermi_fb_subp0_dram_activates_enc_str_1,                         0x00000001, 0x00000006, 0x0000AAAA,  0x00000015, FERMI_CLK_DOMAIN_GF100_LTC0,   PM_UNIT_FB,     {0,0,0,0,0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB_SUBP1_DRAM_ACTIVATES,                      fermi_fb_subp1_dram_activates_enc_str_1,                         0x00000002, 0x00000006, 0x0000AAAA,  0x00000015, FERMI_CLK_DOMAIN_GF100_LTC0,   PM_UNIT_FB,     {0,0,0,0,0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },

    //LTC signals
    // l2_subp0_write_sector_misses = ltc_ltc2fb_dirty_dat0_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 0
    // l2_subp1_write_sector_misses = ltc_ltc2fb_dirty_dat1_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 1
    // l2_subp0_read_sector_misses  = ltc_fb2ltc_rdat0_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 0
    // l2_subp1_read_sector_misses  = ltc_fb2ltc_rdat1_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 1
    // l2_subp0_write_sector_queries = ltc2pm_ltc_lts0_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 0
    // l2_subp1_write_sector_queries = ltc2pm_ltc_lts1_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 1
    // l2_subp0_read_sector_queries  = ltc2pm_ltc_lts0_request_rd_op && ltc2pm_ltc_lts1_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 0
    // l2_subp1_read_sector_queries  = ltc2pm_ltc_lts1_request_rd_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 1

    { FERMI_LTC0_WRITE_MISS_SECTORS,  fermi_ltc0_write_miss_sectors_enc_str_1,    0x00000010, 0x00000004, 0x0000AAAA,  0x04,  FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC1,    {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP },
    { FERMI_LTC1_WRITE_MISS_SECTORS,  fermi_ltc1_write_miss_sectors_enc_str_1,    0x00000011, 0x00000004, 0x0000AAAA,  0x04,  FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC1,    {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP },
    { FERMI_LTC0_READ_MISS_SECTORS,   fermi_ltc0_read_miss_sectors_enc_str_1,     0x00000008, 0x00000000, 0x0000AAAA,  0x00,  FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC1,    {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP },
    { FERMI_LTC1_READ_MISS_SECTORS,   fermi_ltc1_read_miss_sectors_enc_str_1,     0x00000009, 0x00000000, 0x0000AAAA,  0x00,  FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC1,    {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP },

    //Event group mask is calculated from NV_PLTC_MISC_LTC_PM, excluding the PM_ENABLE bit
    //NV_PLTC_MISC_LTC_PM_SECTOR_MUX_SELECT : 0xe
    //NV_PLTC_MISC_LTC_PM_SELECT : 0x1F0
    //NV_PLTC_MISC_LTC_PM_SRCUNIT_MUX_SELECT : 0x3E00
    //NV_PLTC_MISC_LTC_PM_VC_SELECT : 0x70000
    //NV_PLTC_MISC_LTC_PM_SECTOR_COUNT_SELECT : 0x3000000
    //NV_PLTC_MISC_LTC_PM_LTS_MUX_SELECT : 0x20000000
    //Final mask: 0x23073FFE

    //For this particular signal we have following groups
    //subp0
    //NV_PLTC_MISC_LTC_PM_SECTOR_MUX_SELECT : 0x0  : group 0
    //NV_PLTC_MISC_LTC_PM_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_SRCUNIT_MUX_SELECT : 0x1000  : src unit L1, group 8
    //NV_PLTC_MISC_LTC_PM_VC_SELECT : 0x00000
    //NV_PLTC_MISC_LTC_PM_SECTOR_COUNT_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_LTS_MUX_SELECT : 0x00000000  : group 0
    //Final value: 0x1000
    //subp1
    //NV_PLTC_MISC_LTC_PM_SECTOR_MUX_SELECT : 0x6  : group 3
    //NV_PLTC_MISC_LTC_PM_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_SRCUNIT_MUX_SELECT : 0x1200 : src unit L1, group 9
    //NV_PLTC_MISC_LTC_PM_VC_SELECT : 0x00000
    //NV_PLTC_MISC_LTC_PM_SECTOR_COUNT_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_LTS_MUX_SELECT : 0x20000000 : group 1
    //Final value: 0x20001206

    { FERMI_LTC0_WRITE_SECTORS_FBP,   fermi_ltc0_write_sectors_fbp_enc_str_1, 0x00000000, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x2e1f21, 0x00001000, 0x20003E0E},
    { FERMI_LTC1_WRITE_SECTORS_FBP,   fermi_ltc1_write_sectors_fbp_enc_str_1, 0x00000003, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x2e1f21, 0x20001206, 0x20003E0E},
    { FERMI_LTC0_READ_SECTORS_FBP,    fermi_ltc0_read_sectors_fbp_enc_str_1,  0x00000000, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x2f1f21, 0x00001000, 0x20003E0E},
    { FERMI_LTC1_READ_SECTORS_FBP,    fermi_ltc1_read_sectors_fbp_enc_str_1,  0x00000003, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x2f1f21, 0x20001206, 0x20003E0E},


    // l2_subp0_atomic_l1_sector_queries = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_atomic_op & ltc2pm_ltc_lts0_request_src_unit_l1
    { FERMI_LTC0_ATOMIC_L1_SECTORS_FBP,      fermi_ltc0_atomic_l1_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x00212d1f, 0x00001000, 0x20003E0E},
    { FERMI_LTC1_ATOMIC_L1_SECTORS_FBP,      fermi_ltc1_atomic_l1_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x00212d1f, 0x20001206, 0x20003E0E},

    //For this particular signal we have following groups
    //subp0
    //NV_PLTC_MISC_LTC_PM_SECTOR_MUX_SELECT : 0x0  : group 0
    //NV_PLTC_MISC_LTC_PM_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_SRCUNIT_MUX_SELECT : 0xC00  : src unit Tex, group 6
    //NV_PLTC_MISC_LTC_PM_VC_SELECT : 0x00000
    //NV_PLTC_MISC_LTC_PM_SECTOR_COUNT_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_LTS_MUX_SELECT : 0x00000000  : group 0
    //Final value: 0xC00
    //subp1
    //NV_PLTC_MISC_LTC_PM_SECTOR_MUX_SELECT : 0x6  : group 3
    //NV_PLTC_MISC_LTC_PM_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_SRCUNIT_MUX_SELECT : 0xE00 : src unit Tex, group 7
    //NV_PLTC_MISC_LTC_PM_VC_SELECT : 0x00000
    //NV_PLTC_MISC_LTC_PM_SECTOR_COUNT_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_LTS_MUX_SELECT : 0x20000000 : group 1
    //Final value: 0x20000E06

    { FERMI_LTC0_READ_TEX_SECTORS_FBP, fermi_ltc0_read_tex_sectors_fbp_enc_str_1,  0x00000000, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x2f1f21, 0x00000C00, 0x20003E0E},
    { FERMI_LTC1_READ_TEX_SECTORS_FBP, fermi_ltc1_read_tex_sectors_fbp_enc_str_1,  0x00000003, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x2f1f21, 0x20000E06, 0x20003E0E},

    { FERMI_LTC0_READ_CB_SECTORS_FBP,  fermi_ltc0_read_cb_sectors_fbp_enc_str_1,   0x00000000, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x2f2821, 0x00000000, 0x2000000E},
    { FERMI_LTC1_READ_CB_SECTORS_FBP,  fermi_ltc1_read_cb_sectors_fbp_enc_str_1,   0x00000003, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x2f2821, 0x20000006, 0x2000000E},
    { FERMI_LTC0_WRITE_CB_SECTORS_FBP, fermi_ltc0_write_cb_sectors_fbp_enc_str_1,  0x00000000, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x2e2821, 0x00000000, 0x2000000E},
    { FERMI_LTC1_WRITE_CB_SECTORS_FBP, fermi_ltc1_write_cb_sectors_fbp_enc_str_1,  0x00000003, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x2e2821, 0x20000006, 0x2000000E},

    { FERMI_LTC0_READ_HIT_SECTORS_FBP,     fermi_ltc0_read_hit_sectors_fbp_enc_str_1,      0x00000000, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008000,  0x212f1f02, 0x00001002, 0x20003FFE},
    { FERMI_LTC1_READ_HIT_SECTORS_FBP,     fermi_ltc1_read_hit_sectors_fbp_enc_str_1,      0x00000003, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008000,  0x212f1f02, 0x20001218, 0x20003EFE},
    { FERMI_LTC0_READ_TEX_HIT_SECTORS_FBP, fermi_ltc0_read_tex_hit_sectors_fbp_enc_str_1,  0x00000000, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008000,  0x212f1f02, 0x00000C02, 0x20003FFE},
    { FERMI_LTC1_READ_TEX_HIT_SECTORS_FBP, fermi_ltc1_read_tex_hit_sectors_fbp_enc_str_1,  0x00000003, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008000,  0x212f1f02, 0x20000E18, 0x20003EFE},
    { FERMI_LTC0_READ_CB_HIT_SECTORS_FBP,  fermi_ltc0_read_cb_hit_sectors_fbp_enc_str_1,   0x00000000, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008000,  0x212f2802, 0x00000002, 0x200001FE},
    { FERMI_LTC1_READ_CB_HIT_SECTORS_FBP,  fermi_ltc1_read_cb_hit_sectors_fbp_enc_str_1,   0x00000003, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008000,  0x212f2802, 0x20000018, 0x200001FE},

    // ltc_read_sysmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_sysmem
    { FERMI_LTC0_READ_SYSMEM_SECTORS_FBP,      fermi_ltc0_read_sysmem_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x00212f01, 0x00000000, 0x200001FE},
    { FERMI_LTC1_READ_SYSMEM_SECTORS_FBP,      fermi_ltc1_read_sysmem_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x00212f01, 0x20000016, 0x200001FE},

    // ltc_write_sysmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_sysmem
    { FERMI_LTC0_WRITE_SYSMEM_SECTORS_FBP,      fermi_ltc0_write_sysmem_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x00212e01, 0x00000000, 0x200001FE},
    { FERMI_LTC1_WRITE_SYSMEM_SECTORS_FBP,      fermi_ltc1_write_sysmem_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x00212e01, 0x20000016, 0x200001FE},

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { FERMI_LTC0_TOTAL_READ_SECTORS_FBP,      fermi_ltc0_total_read_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008888,  0x0000212f, 0x00000000, 0x2000000E},
    { FERMI_LTC1_TOTAL_READ_SECTORS_FBP,      fermi_ltc1_total_read_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008888,  0x0000212f, 0x20000006, 0x2000000E},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { FERMI_LTC0_TOTAL_WRITE_SECTORS_FBP,      fermi_ltc0_total_write_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008888,  0x0000212e, 0x00000000, 0x2000000E},
    { FERMI_LTC1_TOTAL_WRITE_SECTORS_FBP,      fermi_ltc1_total_write_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008888,  0x0000212e, 0x20000006, 0x2000000E},

    // ltc_read_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { FERMI_LTC0_READ_VIDMEM_SECTORS_FBP,      fermi_ltc0_read_vidmem_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x00212f00, 0x00000000, 0x200001FE},
    { FERMI_LTC1_READ_VIDMEM_SECTORS_FBP,      fermi_ltc1_read_vidmem_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x00212f00, 0x20000016, 0x200001FE},

    // ltc_write_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { FERMI_LTC0_WRITE_VIDMEM_SECTORS_FBP,      fermi_ltc0_write_vidmem_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x00212e00, 0x00000000, 0x200001FE},
    { FERMI_LTC1_WRITE_VIDMEM_SECTORS_FBP,      fermi_ltc1_write_vidmem_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF100_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x00212e00, 0x20000016, 0x200001FE},

    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000, 0x00000000,  0x00,         FERMI_CLK_DOMAIN_MAX,     PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE }
};

PerfSignalTableNew PerfSignalTableGF100_hub0[] = {
    //Hub TLB signals
    //__hub_tlb_hit        = hubmmu2pm_hub_hub_tlb_hit                                      count # of PTE hits in hub TLB
    //__hub_tlb_miss       = (hubmmu2pm_hub_hub_tlb_miss & !hubmmu2pm_hub_hub_tlb_hit)      count # of PTE misses in hub TLB
    { FERMI_MMU_HUB_TLB_HIT,    fermi_mmu_hub_tlb_hit_enc_str_1,    0x00000004,   0x00000000, 0x0000AAAA, 0x05,   FERMI_CLK_DOMAIN_GF100_HUB0,    PM_UNIT_HUBMMU,    {1,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_SYS },
    { FERMI_MMU_HUB_TLB_MISS,   fermi_mmu_hub_tlb_miss_enc_str_1,   0x00000004,   0x00000001, 0x00004444, 0x0605, FERMI_CLK_DOMAIN_GF100_HUB0,    PM_UNIT_HUBMMU,    {1,1,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_SYS },

    // mmu_fill_pte_hit    = hubmmu2pm_hub_fill_pte_hit                                     "count # of PTE hits in mmu fill unit"
    // mmu_fill_pte_miss   = (hubmmu2pm_hub_fill_pte_miss & !hubmmu2pm_hub_fill_pte_hit)    "count # of PTE misses in mmu fill unit"
    { FERMI_MMU_FILL_PTE_HIT,   fermi_mmu_fill_pte_hit_enc_str_1,   0x00000006,   0x00000000, 0x0000AAAA, 0x05,   FERMI_CLK_DOMAIN_GF100_HUB0,    PM_UNIT_HUBMMU,    {1,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_SYS },
    { FERMI_MMU_FILL_PTE_MISS,  fermi_mmu_fill_pte_miss_enc_str_1,  0x00000006,   0x00000010, 0x00004444, 0x0605, FERMI_CLK_DOMAIN_GF100_HUB0,    PM_UNIT_HUBMMU,    {1,1,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_SYS },

    // mmu_fill_pde_hit    = hubmmu2pm_hub_fill_pde_hit                                     "count # of PDE hits in mmu fill unit"
    // mmu_fill_pde_miss   = hubmmu2pm_hub_fill_pde_miss                                    "count # of PDE misses in mmu fill unit"
    { FERMI_MMU_FILL_PDE_HIT,   fermi_mmu_fill_pde_hit_enc_str_1,   0x00000006,   0x00000002, 0x0000AAAA, 0x07,   FERMI_CLK_DOMAIN_GF100_HUB0,    PM_UNIT_HUBMMU,    {0,0,1,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_SYS },
    { FERMI_MMU_FILL_PDE_MISS,  fermi_mmu_fill_pde_miss_enc_str_1,  0x00000006,   0x00000003, 0x0000AAAA, 0x08,   FERMI_CLK_DOMAIN_GF100_HUB0,    PM_UNIT_HUBMMU,    {0,0,0,1}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_SYS },

    //L2 TLB signals
    //__hub_gpcl2_tlb_hit  = hubmmu2pm_hub_gpcl2_tlb_hit                                    count # of PTE hits in gpcl2 TLB
    //__hub_gpcl2_tlb_miss = (hubmmu2pm_hub_gpcl2_tlb_miss & !hubmmu2pm_hub_gpcl2_tlb_hit)  count # of PTE misses in gpcl2 TLB
    { FERMI_MMU_GPCL2_TLB_HIT,  fermi_mmu_gpcl2_tlb_hit_enc_str_1,  0x00000003,   0x00000000, 0x0000AAAA, 0x05,   FERMI_CLK_DOMAIN_GF100_HUB0,    PM_UNIT_HUBMMU,    {1,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_SYS },
    { FERMI_MMU_GPCL2_TLB_MISS, fermi_mmu_gpcl2_tlb_miss_enc_str_1, 0x00000003,   0x00000001, 0x00004444, 0x0605, FERMI_CLK_DOMAIN_GF100_HUB0,    PM_UNIT_HUBMMU,    {1,1,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_SYS },

    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000, 0x00000000,  0x00,         FERMI_CLK_DOMAIN_MAX,     PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE }
};

PerfSignalTableNew PerfSignalTableGF100_sm0[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type
    // ########### SM Unit ###########
    // ***LOAD/STORE***
    // agu_l1_local_ld                  AGU L1 LD is to local space (based on priority thread space)
    // agu_l1_global_ld                 AGU L1 LD is to global space (based on priority thread space)
    // agu_l1_local_st                  AGU L1 ST is to local space (based on priority thread space)
    // agu_l1_global_st                 AGU L1 ST is to global space (based on priority thread space)
    // agu_l1_shared_ld                 AGU L1 LD is to shared space (based on priority thread space)
    // agu_l1_shared_st                 AGU L1 ST is to shared space (based on priority thread space)
    { FERMI_AGU_L1_LOCAL_LD,                  fermi_agu_l1_local_ld_enc_str_1,               0x00000064, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_AGU_L1_LOCAL_ST,                  fermi_agu_l1_local_st_enc_str_1,              0x00000064, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_AGU_L1_GLOBAL_LD,                 fermi_agu_l1_global_ld_enc_str_1,              0x00000064, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_AGU_L1_GLOBAL_ST,                 fermi_agu_l1_global_st_enc_str_1,              0x00000064, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_AGU_L1_SHARED_LD,                 fermi_agu_l1_shared_ld_enc_str_1,              0x00000064, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_AGU_L1_SHARED_ST,                 fermi_agu_l1_shared_st_enc_str_1,             0x00000064, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ***BRANCH***
    // fet_fetch_hit_vld                FET made fetch request for any warp (icache hit)
    // fet_fetch_flow_control           FET: one of the fetched inst(s) is a flow control inst
    // FERMI_FET_FETCH_BRANCH                 fet_fetch_hit_vld && fet_fetch_flow_control
    //{ FERMI_FET_FETCH_BRANCH,               "fet_fetch_branch",         "fet_fetch_branch",         0x00000012, 0x00000010, 0x00008888,  0x3231,       FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,0,0,0,0,0,0}, SIG_TYPE_MULTIPLE, PM_CHIPLET_TYPE_GPC },
    //{ FERMI_FET_FETCH_FLOW_CONTROL,         "fet_fetch_flow_control",   "fet_fetch_flow_control",   0x00000012, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    //{ FERMI_FET_FETCH_INST_COUNT,           "fet_fetch_inst_count",     "fet_fetch_inst_count",     0x00000012, 0x00000002, 0x0000AAAA,  0X33,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,1,1,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    // fet_unique_branches              FET: number of processed (SW) unique branches
    //                                  i.e. number of unique branches that have at least one thread taken
    { FERMI_FET_UNIQUE_BRANCHES_0,            fermi_fet_unique_branches_0_enc_str_1,               0x0000001a, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_UNIQUE_BRANCHES_1,            fermi_fet_unique_branches_1_enc_str_1,               0x0000001a, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_UNIQUE_BRANCHES,              fermi_fet_unique_branches_enc_str_1,                   0x0000001a, 0x00000010, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },

    // ***DIVERGENT BRANCHES***
    // fet_odd_unique_diverged_imm      FET: odd half processed a unique diverged non-indexed branch
    // fet_odd_unique_diverged_idx      FET: odd half processed a unique diverged indexed branch
    // fet_even_unique_diverged_imm     FET: even half processed a unique diverged non-indexed branch
    // fet_even_unique_diverged_idx     FET: even half processed a unique diverged indexed branch
    // FERMI_FET_ODD_UNIQUE_DIVERGED_BRA  =   fet_odd_unique_diverged_imm || fet_odd_unique_diverged_idx
    // FERMI_FET_EVEN_UNIQUE_DIVERGED_BRA =   fet_even_unique_diverged_imm || fet_even_unique_diverged_idx
    //{ FERMI_FET_ODD_UNIQUE_DIVERGED_BRA,    "fet_odd_unique_diverged_bra",  "fet_odd_unique_diverged_bra",      0x00000016, 0x00000054, 0x0000EEEE,  0x3635,       FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,0,0}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },
    //{ FERMI_FET_EVEN_UNIQUE_DIVERGED_BRA,   "fet_even_unique_diverged_bra", "fet_even_unique_diverged_bra",     0x00000018, 0x00000054, 0x0000EEEE,  0x3635,       FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,0,0}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },

    // fet_diverged_branches            FET: number of processed (SW) unique diverged branches
    // fet_odd_control_flow_stall       = sm2pm_gpc_fet_even_active & !sm2pm_gpc_fet_even_request & sm2pm_gpc_fet_even_all_branching
    // fet_even_control_flow_stall      = sm2pm_gpc_fet_odd_active & !sm2pm_gpc_fet_odd_request & sm2pm_gpc_fet_odd_all_branching
    //                                  When a side is not able to fetch and it is that side's turn to fetch and SCH can accept instructions (enough scoreboard and instruction buffer slots),
    //                                  increment by the number of warps which have enough InstructionBuffer/Scoreboard entries but can't fetch due to control flow

    { FERMI_FET_DIVERGED_BRANCHES,            fermi_fet_diverged_branches_enc_str_1,           0x00000019, 0x00000032, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,1,1,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_ODD_CONTROL_FLOW_STALL,       fermi_fet_odd_control_flow_stall_enc_str_1,  0x00000020, 0x00000014, 0x00002020,  0x313235,     FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,0,0,1,0,0,0}, SIG_TYPE_MULTIPLE,   PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_EVEN_CONTROL_FLOW_STALL,      fermi_fet_even_control_flow_stall_enc_str_1, 0x00000021, 0x00000014, 0x00002020,  0x313235,     FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,0,0,1,0,0,0}, SIG_TYPE_MULTIPLE,   PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_DIVERGED_BRANCHES_0,          fermi_fet_diverged_branches_0_enc_str_1,       0x00000019, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_DIVERGED_BRANCHES_1,          fermi_fet_diverged_branches_1_enc_str_1,       0x00000019, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },

    // ***REPLAY REASONS***
    // sl_l1_deferred                   SL L1 had a defer (defer_mask != 0)
    //                                  i.e. total number of replays due to L1 deferral. cost not because of the program, but L1 design. counted in sl
    // sl_l1_divergent                  SL L1 instr had a replay due to divergence
    //                                  i.e. total number of replays due to memory address divergence. basically the extra cost you pay for your program pattern (serialization). counted in sl
    // sl_l1_replayed                   SL L1 instr replayed (due to divergence or defer)
    //                                  i.e. total number of memory instructions (instruction count) that are replayed (i.e. divergent or deferred). note: divergence and L1 deferral can happen for the same instruction. counted in sl
    // sch_even_imc_replay              sch got a replay request from imc
    // sch_odd_imc_replay               sch got a replay request from imc
    // sch_replay_others                SCH number of imc/idc miss or ipa replays
    // dsm_ipa_or_pixld_replay          DSM replay on an ipa or pixld instruction
    // agu_idc_replayed                 AGU indexed c$ access replayed
    //                                  i.e. total number of constant cache instructions that are replayed. counted in aguc

    // sm_even_imc_miss_replay          sm2pm_gpc_dsm_imc0_miss | sm2pm_gpc_dsm_imc0_match | sm2pm_gpc_dsm_imc0_full
    //                                  i.e. number of replays due to IMC miss
    // sm_odd_imc_miss_replay           sm2pm_gpc_dsm_imc1_miss | sm2pm_gpc_dsm_imc1_match | sm2pm_gpc_dsm_imc1_full
    //                                  i.e. number of replays due to IMC miss
    { FERMI_SL_L1_DEFERRED,                   fermi_sl_l1_deferred_enc_str_1,         0x0000006a, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SL_L1_DIVERGENT,                  fermi_sl_l1_divergent_enc_str_1,        0x0000006a, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SL_L1_REPLAYED,                   fermi_sl_l1_replayed_enc_str_1,         0x0000006a, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_EVEN_IMC_REPLAY,            "__sch_even_imc_replay",    0x00000025, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_ODD_IMC_REPLAY,             "__sch_odd_imc_replay",     0x00000025, 0x00000007, 0x0000AAAA,  0x38,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,0,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_DSM_EVEN_IMC_MISS_REPLAY,         fermi_dsm_even_imc_miss_replay_enc_str_1,0x00000062, 0x00000321, 0x0000FEFE,  0x343332,     FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },
    { FERMI_DSM_ODD_IMC_MISS_REPLAY,          fermi_dsm_odd_imc_miss_replay_enc_str_1, 0x00000062, 0x00000765, 0x0000FEFE,  0x383736,     FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,1,1}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_REPLAY_OTHERS,              "__sch_replay_others",      0x0000002c, 0x00000076, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_DSM_IPA_OR_PIXLD_REPLAY,          fermi_dsm_ipa_or_pixld_replay_enc_str_1,0x00000057, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_AGU_IDC_REPLAYED,                 fermi_agu_idc_replayed_enc_str_1,       0x00000068, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ***LAUNCHED***
    // sch_warps_launched               SM has launched 1 warp
    // sch_threads_launched             number of threads SM launched this cycle
    { FERMI_SCH_WARPS_LAUNCHED,               fermi_sch_warps_launched_enc_str_1,         0x00000026, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_THREADS_LAUNCHED,             fermi_sch_threads_launched_enc_str_1,       0x00000026, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,1,1,1,1,1,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_THREADS_LAUNCHED_0,         fermi_sch_threads_launched_0_enc_str_1,     0x00000026, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_THREADS_LAUNCHED_1,         fermi_sch_threads_launched_1_enc_str_1,     0x00000026, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_THREADS_LAUNCHED_2,         fermi_sch_threads_launched_2_enc_str_1,     0x00000026, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_THREADS_LAUNCHED_3,         fermi_sch_threads_launched_3_enc_str_1,     0x00000026, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_THREADS_LAUNCHED_4,         fermi_sch_threads_launched_4_enc_str_1,     0x00000026, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_THREADS_LAUNCHED_5,         fermi_sch_threads_launched_5_enc_str_1,     0x00000026, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ****ACTIVE_WARPS***
    // sch_active_cycles                sch has at lest 1 active warp.
    // sch_active_warps                 number of active warps SM currently has
    //                                  i.e. Every cycle, increment this counter by the number of active warps
    //{ FERMI_SCH_ACTIVE_CYCLES,              "sch_active_cycles",        0x00000024, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ACTIVE_WARPS,                 fermi_sch_active_warps_enc_str_1,             0x00000024, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,1,1,1,1,1,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // sch_warp_issue_holes             number of warps not eligible to be issued this cycle
    //                                  i.e. Every cycle, increment this counter by the number of active warps that do not have an instruction eligible for issue due to warp only reasons.
    //                                  Warp only reason includes register scoreboard, 3 cycle reissue limit, no instruction in the SCH. If any warp only reason is true, the count is incremented regardless of any other ineligibility reason.
    { FERMI_SCH_WARP_ISSUE_HOLES,             fermi_sch_warp_issue_holes_enc_str_1,   0x00000027, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // sch_warp_issue_holes_long        number of warps not eligible to be issued for > 32 cycles
    //                                  i.e. similar to warp_issue_holes, but only count warps that have not been issue for at least 31 cycles.
    { FERMI_SCH_WARP_ISSUE_HOLES_LONG,        fermi_sch_warp_issue_holes_long_enc_str_1, 0x00000028,0x00000000,  0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // sch_warp_issue_eligible          number of warps eligible to be issued this cycle
    //                                  i.e. Every cycle, increment this counter by the number of warps eligible to issue. A warp is counted if it eligible for issue, even it is not ultimately selected.
    { FERMI_SCH_WARP_ISSUE_ELIGIBLE,          fermi_sch_warp_issue_eligible_enc_str_1,    0x00000029, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // fet_icc_miss                     FET: fetch resulted in an I$ miss
    //                                  i.e. count the number of cache new misses. Covered misses and miss fail are not counted.
    // fet_icc_hit                      FET: fetch resulted in an I$ hit
    //                                  i.e. count the number of cache hits
    { FERMI_FET_ICC_MISS,                     fermi_fet_icc_miss_enc_str_1,               0x00000014, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_ICC_HIT,                      fermi_fet_icc_hit_enc_str_1,                0x00000014, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // fet_any_active                   FET: has at least 1 active warp
    //                                  i.e. Count total number of cycles SM has at least one active warp, existing warp, not necessarily to be schedulable
    { FERMI_FET_ANY_ACTIVE,                   fermi_fet_any_active_enc_str_1,            0x00000011, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // sch_even_cant_issue_no_inst              SCH number of warps with no instructions in the IB
    // sch_even_cant_issue_interlock_long       SCH number of warps blocked on ld/st or scoreboard interlock > 32 clocks
    // sch_even_cant_issue_interlock_short      SCH number of warps blocked on ld/st or scoreboard interlock < 32 clocks
    // sch_even_cant_issue_reissue              SCH number of warps blocked by 3 cycle reissue limit
    // sch_even_cant_issue_dsm_q_full           SCH number of warps blocked by full dsm queue
    // sch_even_cant_issue_tex_q_full           SCH number of warps blocked by full dsm tex queue
    // sch_even_cant_issue_tex_req_table_full   SCH number of warps blocked by full tex_req table
    // sch_even_cant_issue_tile                 SCH number of warps blocked by tex_tile interlock
    // sch_even_cant_issue_tex_side             SCH number of warps blocked by tex even/odd arb
    // sch_even_cant_issue_issue_throttle       SCH number of warps blocked by shadow dsm throttling
    // sch_even_cant_issue_barrier              SCH number of warps blocked by barrier
    // sch_even_cant_issue_l1_sleep             SCH number of warps blocked by l1 deferral
    // sch_even_cant_issue_all                  SCH number of warps blocked by any reason

    { FERMI_SCH_EVEN_CANT_ISSUE_NO_INST,            fermi_sch_even_cant_issue_no_inst_enc_str_1,            0x0000003b, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_INTERLOCK_LONG,     fermi_sch_even_cant_issue_interlock_long_enc_str_1,     0x0000003c, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_INTERLOCK_SHORT,    fermi_sch_even_cant_issue_interlock_short_enc_str_1,    0x0000003d, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_REISSUE,            fermi_sch_even_cant_issue_reissue_enc_str_1,            0x0000003e, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_DSM_Q_FULL,         fermi_sch_even_cant_issue_dsm_q_full_enc_str_1,         0x0000003f, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_TEX_Q_FULL,         fermi_sch_even_cant_issue_tex_q_full_enc_str_1,         0x00000040, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_TEX_REQ_TABLE_FULL, fermi_sch_even_cant_issue_tex_req_table_full_enc_str_1, 0x00000041, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_TILE,               fermi_sch_even_cant_issue_tile_enc_str_1,               0x00000042, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_TEX_SIDE,           fermi_sch_even_cant_issue_tex_side_enc_str_1,           0x00000043, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_ISSUE_THROTTLE,     fermi_sch_even_cant_issue_issue_throttle_enc_str_1,     0x00000044, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_BARRIER,            fermi_sch_even_cant_issue_barrier_enc_str_1,            0x00000045, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_L1_SLEEP,           fermi_sch_even_cant_issue_l1_sleep_enc_str_1,           0x00000046, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_ALL,                fermi_sch_even_cant_issue_all_enc_str_1,                0x00000047, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    { FERMI_SCH_ODD_CANT_ISSUE_NO_INST,             fermi_sch_odd_cant_issue_no_inst_enc_str_1,             0x00000048, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_INTERLOCK_LONG,      fermi_sch_odd_cant_issue_interlock_long_enc_str_1,      0x00000049, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_INTERLOCK_SHORT,     fermi_sch_odd_cant_issue_interlock_short_enc_str_1,     0x0000004a, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_REISSUE,             fermi_sch_odd_cant_issue_reissue_enc_str_1,             0x0000004b, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_DSM_Q_FULL,          fermi_sch_odd_cant_issue_dsm_q_full_enc_str_1,          0x0000004c, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_TEX_Q_FULL,          fermi_sch_odd_cant_issue_tex_q_full_enc_str_1,          0x0000004d, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_TEX_REQ_TABLE_FULL,  fermi_sch_odd_cant_issue_tex_req_table_full_enc_str_1,  0x0000004e, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_TILE,                fermi_sch_odd_cant_issue_tile_enc_str_1,                0x0000004f, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_TEX_SIDE,            fermi_sch_odd_cant_issue_tex_side_enc_str_1,            0x00000050, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_ISSUE_THROTTLE,      fermi_sch_odd_cant_issue_issue_throttle_enc_str_1,      0x00000051, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_BARRIER,             fermi_sch_odd_cant_issue_barrier_enc_str_1,             0x00000052, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_L1_SLEEP,            fermi_sch_odd_cant_issue_l1_sleep_enc_str_1,            0x00000053, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_ALL,                 fermi_sch_odd_cant_issue_all_enc_str_1,                 0x00000054, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // NOP TRIGGERS
    // dsm_nop_trig_grp0                DSM: NOP trigger[7:0]
    // dsm_nop_trig_grp1                DSM: NOP trigger[15:8]
    { FERMI_NOP_TRIG_00,                      fermi_nop_trig_00_enc_str_1,          0x00000001, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_01,                      fermi_nop_trig_01_enc_str_1,          0x00000001, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_02,                      fermi_nop_trig_02_enc_str_1,          0x00000001, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_03,                      fermi_nop_trig_03_enc_str_1,          0x00000001, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_04,                      fermi_nop_trig_04_enc_str_1,          0x00000001, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_05,                      fermi_nop_trig_05_enc_str_1,          0x00000001, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_06,                      fermi_nop_trig_06_enc_str_1,          0x00000001, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_07,                      fermi_nop_trig_07_enc_str_1,          0x00000001, 0x00000007, 0x0000AAAA,  0x38,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,0,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_08,                      fermi_nop_trig_08_enc_str_1,             0x00000002, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_09,                      fermi_nop_trig_09_enc_str_1,             0x00000002, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_10,                      fermi_nop_trig_10_enc_str_1,             0x00000002, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_11,                      fermi_nop_trig_11_enc_str_1,             0x00000002, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_12,                      fermi_nop_trig_12_enc_str_1,             0x00000002, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_13,                      fermi_nop_trig_13_enc_str_1,             0x00000002, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_14,                      fermi_nop_trig_14_enc_str_1,             0x00000002, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_15,                      fermi_nop_trig_15_enc_str_1,             0x00000002, 0x00000007, 0x0000AAAA,  0x38,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,0,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // sch_inst_issued                  number of insts issued this cycle
    //                                  i.e. count instructions issued (inc each cycle by 0 to 2)
    // sch_inst_decoded                 SCH insts decoded this cycle
    //                                  i.e. Count total number of instructions executed, do not count replay. It counts the number of instructions decoded in SCH
    { FERMI_SCH_INST_ISSUED,                  fermi_sch_inst_issued_enc_str_1,              0x00000027, 0x00000076, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_INST_DECODED,                 fermi_sch_inst_decoded_enc_str_1,            0x0000002d, 0x00000010, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_INST_ISSUED_0,                fermi_sch_inst_issued_0_enc_str_1,          0x00000027, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_INST_ISSUED_1,                fermi_sch_inst_issued_1_enc_str_1,          0x00000027, 0x00000007, 0x0000AAAA,  0x38,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,0,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_INST_DECODED_0,               fermi_sch_inst_decoded_0_enc_str_1,        0x0000002d, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_INST_DECODED_1,               fermi_sch_inst_decoded_1_enc_str_1,        0x0000002d, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    //sch_even_thread_inst_decoded      even half threads decoded
    //sch_odd_thread_inst_decoded       odd half threads decoded
    //Count threads executed at even/odd side, it is inst_executed at even/odd side multiplied by active mask, predicated off threads are also included.
    { FERMI_SCH_EVEN_THREAD_INST_DECODED,     fermi_sch_even0_thread_inst_decoded_enc_str_1, 0x0000002f, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_THREAD_INST_DECODED,      fermi_sch_odd0_thread_inst_decoded_enc_str_1, 0x00000030, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // sm_odd_alu_only_inst_executed                Count ALU pipe only instructions decoded on the odd side
    // sm_odd_xlu_only_inst_executed                count XLU pipe only instructions decoded on the odd side
    // sm_odd_alu_xlu_bipipe_inst_executed          count ALU XLU bipipe instructions decoded on the odd side
    // sm_odd_fmalite_only_inst_executed            Count FMALite pipe instructions decoded on the odd side
    // sm_odd_fma32_only_inst_executed              count FMA32 only instruction decoded on the odd side
    // sm_odd_fmalite_fma32_bipipe_inst_executed    count FMALite FMA32 bipipe instruction decoded on the odd side
    // sm_odd_fu_inst_executed                      count FU pipe instruction decoded on the odd side
    // sm_odd_fma64_inst_executed                   count FMA64 pipe instruction decoded on the odd side
    // sm_odd_su_inst_executed                      count SU pipe instruction decoded on the odd side
    // sm_odd_agu_inst_executed                     count AGU pipe instruction decoded on the odd side
    // sm_odd_tex_inst_executed                     count TEX instruction decoded on the odd side
    // sm_odd_dsm_inst_executed                     count DSM pipe instruction decoded on the odd side
    // sm_odd_sch_internal_inst_executed            count SCH internal instruction decoded on the odd side
    // sm_odd_fe_inst_executed                      count FE pipe instruction decoded on the odd side


    { FERMI_SM_ODD_ALU_ONLY_INST_EXECUTED,              fermi_sm_odd_alu_only_inst_executed_enc_str_1,            0x00000055, 0x00007654, 0x00000800, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_XLU_ONLY_INST_EXECUTED,              fermi_sm_odd_xlu_only_inst_executed_enc_str_1,            0x00000055, 0x00007654, 0x00000004, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_ALU_XLU_BIPIPE_INST_EXECUTED,        fermi_sm_odd_alu_xlu_bipipe_inst_executed_enc_str_1,      0x00000055, 0x00007654, 0x00000002, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_FMALITE_ONLY_INST_EXECUTED,          fermi_sm_odd_fmalite_only_inst_executed_enc_str_1,        0x00000055, 0x00007654, 0x00000400, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_FMA32_ONLY_INST_EXECUTED,            fermi_sm_odd_fma32_only_inst_executed_enc_str_1,          0x00000055, 0x00007654, 0x00000010, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_FMALITE_FMA32_BIPIPE_INST_EXECUTED,  fermi_sm_odd_fmalite_fma32_bipipe_inst_executed_enc_str_1,0x00000055, 0x00007654, 0x00000001, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_FU_INST_EXECUTED,                    fermi_sm_odd_fu_inst_executed_enc_str_1,                  0x00000055, 0x00007654, 0x00000020, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_FMA64_INST_EXECUTED,                 fermi_sm_odd_fma64_inst_executed_enc_str_1,               0x00000055, 0x00007654, 0x00000040, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_SU_INST_EXECUTED,                    fermi_sm_odd_su_inst_executed_enc_str_1,                  0x00000055, 0x00007654, 0x00000008, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_AGU_INST_EXECUTED,                   fermi_sm_odd_agu_inst_executed_enc_str_1,                 0x00000055, 0x00007654, 0x00000080, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_TEX_INST_EXECUTED,                   fermi_sm_odd_tex_inst_executed_enc_str_1,                 0x00000055, 0x00007654, 0x00000100, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_DSM_INST_EXECUTED,                   fermi_sm_odd_dsm_inst_executed_enc_str_1,                 0x00000055, 0x00007654, 0x00000200, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_SCH_INTERNAL_INST_EXECUTED,          fermi_sm_odd_sch_internal_inst_executed_enc_str_1,        0x00000055, 0x00007654, 0x00002000, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_FE_INST_EXECUTED,                    fermi_sm_odd_fe_inst_executed_enc_str_1,                  0x00000055, 0x00007654, 0x00001000, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },


    // sm_even_alu_only_inst_executed               Count ALU pipe only instructions decoded on the even side
    // sm_even_xlu_only_inst_executed               count XLU pipe only instructions decoded on the even side
    // sm_even_alu_xlu_bipipe_inst_executed         count ALU XLU bipipe instructions decoded on the even side
    // sm_even_fmalite_only_inst_executed           Count FMALite pipe instructions decoded on the even side
    // sm_even_fma32_only_inst_executed             count FMA32 only instruction decoded on the even side
    // sm_even_fmalite_fma32_bipipe_inst_executed   count FMALite FMA32 bipipe instruction decoded on the even side
    // sm_even_fu_inst_executed                     count FU pipe instruction decoded on the even side
    // sm_even_fma64_inst_executed                  count FMA64 pipe instruction decoded on the even side
    // sm_even_su_inst_executed                     count SU pipe instruction decoded on the even side
    // sm_even_agu_inst_executed                    count AGU pipe instruction decoded on the even side
    // sm_even_tex_inst_executed                    count TEX instruction decoded on the even side
    // sm_even_dsm_inst_executed                    count DSM pipe instruction decoded on the even side
    // sm_even_sch_internal_inst_executed           count SCH internal instruction decoded on the even side
    // sm_even_fe_inst_executed                     count FE pipe instruction decoded on the even side

    { FERMI_SM_EVEN_ALU_ONLY_INST_EXECUTED,              fermi_sm_even_alu_only_inst_executed_enc_str_1,            0x00000055, 0x00003210, 0x00000800, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_XLU_ONLY_INST_EXECUTED,              fermi_sm_even_xlu_only_inst_executed_enc_str_1,            0x00000055, 0x00003210, 0x00000004, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_ALU_XLU_BIPIPE_INST_EXECUTED,        fermi_sm_even_alu_xlu_bipipe_inst_executed_enc_str_1,      0x00000055, 0x00003210, 0x00000002, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_FMALITE_ONLY_INST_EXECUTED,          fermi_sm_even_fmalite_only_inst_executed_enc_str_1,        0x00000055, 0x00003210, 0x00000400, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_FMA32_ONLY_INST_EXECUTED,            fermi_sm_even_fma32_only_inst_executed_enc_str_1,          0x00000055, 0x00003210, 0x00000010, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_FMALITE_FMA32_BIPIPE_INST_EXECUTED,  fermi_sm_even_fmalite_fma32_bipipe_inst_executed_enc_str_1,0x00000055, 0x00003210, 0x00000001, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_FU_INST_EXECUTED,                    fermi_sm_even_fu_inst_executed_enc_str_1,                  0x00000055, 0x00003210, 0x00000020, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_FMA64_INST_EXECUTED,                 fermi_sm_even_fma64_inst_executed_enc_str_1,               0x00000055, 0x00003210, 0x00000040, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_SU_INST_EXECUTED,                    fermi_sm_even_su_inst_executed_enc_str_1,                  0x00000055, 0x00003210, 0x00000008, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_AGU_INST_EXECUTED,                   fermi_sm_even_agu_inst_executed_enc_str_1,                 0x00000055, 0x00003210, 0x00000080, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_TEX_INST_EXECUTED,                   fermi_sm_even_tex_inst_executed_enc_str_1,                 0x00000055, 0x00003210, 0x00000100, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_DSM_INST_EXECUTED,                   fermi_sm_even_dsm_inst_executed_enc_str_1,                 0x00000055, 0x00003210, 0x00000200, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_SCH_INTERNAL_INST_EXECUTED,          fermi_sm_even_sch_internal_inst_executed_enc_str_1,        0x00000055, 0x00003210, 0x00002000, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_FE_INST_EXECUTED,                    fermi_sm_even_fe_inst_executed_enc_str_1,                  0x00000055, 0x00003210, 0x00001000, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },

    // sm_odd_alu_only_inst_issued                Count ALU pipe only instructions issued on the odd side
    // sm_odd_xlu_only_inst_issued                count XLU pipe only instructions issued on the odd side
    // sm_odd_alu_xlu_bipipe_inst_issued          count ALU XLU bipipe instructions issued on the odd side
    // sm_odd_fmalite_only_inst_issued            Count FMALite pipe instructions issued on the odd side
    // sm_odd_fma32_only_inst_issued              count FMA32 only instruction issued on the odd side
    // sm_odd_fmalite_fma32_bipipe_inst_issued    count FMALite FMA32 bipipe instruction issued on the odd side
    // sm_odd_fu_inst_issued                      count FU pipe instruction issued on the odd side
    // sm_odd_fma64_inst_issued                   count FMA64 pipe instruction issued on the odd side
    // sm_odd_su_inst_issued                      count SU pipe instruction issued on the odd side
    // sm_odd_agu_inst_issued                     count AGU pipe instruction issued on the odd side
    // sm_odd_tex_inst_issued                     count TEX instruction issued on the odd side
    // sm_odd_dsm_inst_issued                     count DSM pipe instruction issued on the odd side
    // sm_odd_sch_internal_inst_issued            count SCH internal instruction issued on the odd side
    // sm_odd_fe_inst_issued                      count FE pipe instruction issued on the odd side

    { FERMI_SM_ODD_ALU_ONLY_INST_ISSUED,              fermi_sm_odd_alu_only_inst_issued_enc_str_1,            0x00000056, 0x00007654, 0x00000800, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_XLU_ONLY_INST_ISSUED,              fermi_sm_odd_xlu_only_inst_issued_enc_str_1,            0x00000056, 0x00007654, 0x00000004, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_ALU_XLU_BIPIPE_INST_ISSUED,        fermi_sm_odd_alu_xlu_bipipe_inst_issued_enc_str_1,      0x00000056, 0x00007654, 0x00000002, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_FMALITE_ONLY_INST_ISSUED,          fermi_sm_odd_fmalite_only_inst_issued_enc_str_1,        0x00000056, 0x00007654, 0x00000400, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_FMA32_ONLY_INST_ISSUED,            fermi_sm_odd_fma32_only_inst_issued_enc_str_1,          0x00000056, 0x00007654, 0x00000010, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_FMALITE_FMA32_BIPIPE_INST_ISSUED,  fermi_sm_odd_fmalite_fma32_bipipe_inst_issued_enc_str_1,0x00000056, 0x00007654, 0x00000001, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_FU_INST_ISSUED,                    fermi_sm_odd_fu_inst_issued_enc_str_1,                  0x00000056, 0x00007654, 0x00000020, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_FMA64_INST_ISSUED,                 fermi_sm_odd_fma64_inst_issued_enc_str_1,               0x00000056, 0x00007654, 0x00000040, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_SU_INST_ISSUED,                    fermi_sm_odd_su_inst_issued_enc_str_1,                  0x00000056, 0x00007654, 0x00000008, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_AGU_INST_ISSUED,                   fermi_sm_odd_agu_inst_issued_enc_str_1,                 0x00000056, 0x00007654, 0x00000080, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_TEX_INST_ISSUED,                   fermi_sm_odd_tex_inst_issued_enc_str_1,                 0x00000056, 0x00007654, 0x00000100, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_DSM_INST_ISSUED,                   fermi_sm_odd_dsm_inst_issued_enc_str_1,                 0x00000056, 0x00007654, 0x00000200, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_SCH_INTERNAL_INST_ISSUED,          fermi_sm_odd_sch_internal_inst_issued_enc_str_1,        0x00000056, 0x00007654, 0x00002000, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD_FE_INST_ISSUED,                    fermi_sm_odd_fe_inst_issued_enc_str_1,                  0x00000056, 0x00007654, 0x00001000, 0x38373635, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },


    // sm_even_alu_only_inst_issued               Count ALU pipe only instructions issued on the even side
    // sm_even_xlu_only_inst_issued               count XLU pipe only instructions issued on the even side
    // sm_even_alu_xlu_bipipe_inst_issued         count ALU XLU bipipe instructions issued on the even side
    // sm_even_fmalite_only_inst_issued           Count FMALite pipe instructions issued on the even side
    // sm_even_fma32_only_inst_issued             count FMA32 only instruction issued on the even side
    // sm_even_fmalite_fma32_bipipe_inst_issued   count FMALite FMA32 bipipe instruction issued on the even side
    // sm_even_fu_inst_issued                     count FU pipe instruction issued on the even side
    // sm_even_fma64_inst_issued                  count FMA64 pipe instruction issued on the even side
    // sm_even_su_inst_issued                     count SU pipe instruction issued on the even side
    // sm_even_agu_inst_issued                    count AGU pipe instruction issued on the even side
    // sm_even_tex_inst_issued                    count TEX instruction issued on the even side
    // sm_even_dsm_inst_issued                    count DSM pipe instruction issued on the even side
    // sm_even_sch_internal_inst_issued           count SCH internal instruction issued on the even side
    // sm_even_fe_inst_issued                     count FE pipe instruction issued on the even side

    { FERMI_SM_EVEN_ALU_ONLY_INST_ISSUED,              fermi_sm_even_alu_only_inst_issued_enc_str_1,            0x00000056, 0x00003210, 0x00000800, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_XLU_ONLY_INST_ISSUED,              fermi_sm_even_xlu_only_inst_issued_enc_str_1,            0x00000056, 0x00003210, 0x00000004, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_ALU_XLU_BIPIPE_INST_ISSUED,        fermi_sm_even_alu_xlu_bipipe_inst_issued_enc_str_1,      0x00000056, 0x00003210, 0x00000002, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_FMALITE_ONLY_INST_ISSUED,          fermi_sm_even_fmalite_only_inst_issued_enc_str_1,        0x00000056, 0x00003210, 0x00000400, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_FMA32_ONLY_INST_ISSUED,            fermi_sm_even_fma32_only_inst_issued_enc_str_1,          0x00000056, 0x00003210, 0x00000010, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_FMALITE_FMA32_BIPIPE_INST_ISSUED,  fermi_sm_even_fmalite_fma32_bipipe_inst_issued_enc_str_1,0x00000056, 0x00003210, 0x00000001, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_FU_INST_ISSUED,                    fermi_sm_even_fu_inst_issued_enc_str_1,                  0x00000056, 0x00003210, 0x00000020, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_FMA64_INST_ISSUED,                 fermi_sm_even_fma64_inst_issued_enc_str_1,               0x00000056, 0x00003210, 0x00000040, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_SU_INST_ISSUED,                    fermi_sm_even_su_inst_issued_enc_str_1,                  0x00000056, 0x00003210, 0x00000008, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_AGU_INST_ISSUED,                   fermi_sm_even_agu_inst_issued_enc_str_1,                 0x00000056, 0x00003210, 0x00000080, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_TEX_INST_ISSUED,                   fermi_sm_even_tex_inst_issued_enc_str_1,                 0x00000056, 0x00003210, 0x00000100, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_DSM_INST_ISSUED,                   fermi_sm_even_dsm_inst_issued_enc_str_1,                 0x00000056, 0x00003210, 0x00000200, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_SCH_INTERNAL_INST_ISSUED,          fermi_sm_even_sch_internal_inst_issued_enc_str_1,        0x00000056, 0x00003210, 0x00002000, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN_FE_INST_ISSUED,                    fermi_sm_even_fe_inst_issued_enc_str_1,                  0x00000056, 0x00003210, 0x00001000, 0x34333231, FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },

    { FERMI_SM_L1C_ATOM_COUNT,                    fermi_sm_l1c_atom_count_enc_str_1,         0x00000063, 0x00000003, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_L1C_GRED_COUNT,                    fermi_sm_l1c_gred_count_enc_str_1,         0x00000063, 0x00000004, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF100_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000, 0x00000000,  0x00,         FERMI_CLK_DOMAIN_MAX,     PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE }
};
PerfSignalTableNew PerfSignalTableGF104_gpc0[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type
    // ########### SM Unit ###########
    // ***LOAD/STORE***
    // agu_l1_local_ld                  AGU L1 LD is to local space (based on priority thread space)
    // agu_l1_global_ld                 AGU L1 LD is to global space (based on priority thread space)
    // agu_l1_local_st                  AGU L1 ST is to local space (based on priority thread space)
    // agu_l1_global_st                 AGU L1 ST is to global space (based on priority thread space)
    // agu_l1_shared_ld                 AGU L1 LD is to shared space (based on priority thread space)
    // agu_l1_shared_st                 AGU L1 ST is to shared space (based on priority thread space)
#ifdef SMPM
    { HWPM_FERMI_AGU_L1_LOCAL_LD,                  hwpm_fermi_agu_l1_local_ld_enc_str_1,               0x00000064, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_AGU_L1_LOCAL_ST,                  hwpm_fermi_agu_l1_local_st_enc_str_1,              0x00000064, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_AGU_L1_GLOBAL_LD,                 hwpm_fermi_agu_l1_global_ld_enc_str_1,              0x00000064, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_AGU_L1_GLOBAL_ST,                 hwpm_fermi_agu_l1_global_st_enc_str_1,              0x00000064, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_AGU_L1_SHARED_LD,                 hwpm_fermi_agu_l1_shared_ld_enc_str_1,              0x00000064, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_AGU_L1_SHARED_ST,                 hwpm_fermi_agu_l1_shared_st_enc_str_1,             0x00000064, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ***BRANCH***
    // fet_fetch_hit_vld                FET made fetch request for any warp (icache hit)
    // fet_fetch_flow_control           FET: one of the fetched inst(s) is a flow control inst
    // FERMI_FET_FETCH_BRANCH                 fet_fetch_hit_vld && fet_fetch_flow_control
    //{ FERMI_FET_FETCH_BRANCH,               "fet_fetch_branch",         "fet_fetch_branch",         0x00000012, 0x00000010, 0x00008888,  0x3231,       FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,0,0,0,0,0,0}, SIG_TYPE_MULTIPLE, PM_CHIPLET_TYPE_GPC },
    //{ FERMI_FET_FETCH_FLOW_CONTROL,         "fet_fetch_flow_control",   "fet_fetch_flow_control",   0x00000012, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    //{ FERMI_FET_FETCH_INST_COUNT,           "fet_fetch_inst_count",     "fet_fetch_inst_count",     0x00000012, 0x00000002, 0x0000AAAA,  0X33,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,1,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },

    // fet_unique_branches              FET: number of processed (SW) unique branches
    // fet_taken_branches               FET: number of processed (SW) unique (any thread) taken branches
    //                                  i.e. number of unique branches that have at least one thread taken
    { HWPM_FERMI_FET_UNIQUE_BRANCHES,              hwpm_fermi_fet_unique_branches_enc_str_1,                   0x0000001a, 0x00000010, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_FET_TAKEN_BRANCHES,               hwpm_fermi_fet_taken_branches_enc_str_1,     0x00000019, 0x00000010, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },

    // ***DIVERGENT BRANCHES***
    // fet_odd_unique_diverged_imm      FET: odd half processed a unique diverged non-indexed branch
    // fet_odd_unique_diverged_idx      FET: odd half processed a unique diverged indexed branch
    // fet_even_unique_diverged_imm     FET: even half processed a unique diverged non-indexed branch
    // fet_even_unique_diverged_idx     FET: even half processed a unique diverged indexed branch
    // FERMI_FET_ODD_UNIQUE_DIVERGED_BRA  =   fet_odd_unique_diverged_imm || fet_odd_unique_diverged_idx
    // FERMI_FET_EVEN_UNIQUE_DIVERGED_BRA =   fet_even_unique_diverged_imm || fet_even_unique_diverged_idx
    //{ FERMI_FET_ODD_UNIQUE_DIVERGED_BRA,    "fet_odd_unique_diverged_bra",  "fet_odd_unique_diverged_bra",      0x00000016, 0x00000054, 0x0000EEEE,  0x3635,       FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,0,0}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },
    //{ FERMI_FET_EVEN_UNIQUE_DIVERGED_BRA,   "fet_even_unique_diverged_bra", "fet_even_unique_diverged_bra",     0x00000018, 0x00000054, 0x0000EEEE,  0x3635,       FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,0,0}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },

    // fet_diverged_branches            FET: number of processed (SW) unique diverged branches
    // fet_odd_control_flow_stall       = sm2pm_gpc_fet_even_active & !sm2pm_gpc_fet_even_request & sm2pm_gpc_fet_even_all_branching
    // fet_even_control_flow_stall      = sm2pm_gpc_fet_odd_active & !sm2pm_gpc_fet_odd_request & sm2pm_gpc_fet_odd_all_branching
    //                                  When a side is not able to fetch and it is that side's turn to fetch and SCH can accept instructions (enough scoreboard and instruction buffer slots),
    //                                  increment by the number of warps which have enough InstructionBuffer/Scoreboard entries but can't fetch due to control flow

    { HWPM_FERMI_FET_DIVERGED_BRANCHES,            hwpm_fermi_fet_diverged_branches_enc_str_1,         0x00000019, 0x00000032, 0x0000FFFF,  0x33,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,1,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_FET_ODD_CONTROL_FLOW_STALL,       hwpm_fermi_fet_odd_control_flow_stall_enc_str_1,  0x00000020, 0x00000014, 0x00002020,  0x313235,     FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,0,0,1,0,0,0}, SIG_TYPE_MULTIPLE,   PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_FET_EVEN_CONTROL_FLOW_STALL,      hwpm_fermi_fet_even_control_flow_stall_enc_str_1, 0x00000021, 0x00000014, 0x00002020,  0x313235,     FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,0,0,1,0,0,0}, SIG_TYPE_MULTIPLE,   PM_CHIPLET_TYPE_GPC },

    // ***INSTRUCTIONS***
    // sch_odd_issue                    SCH odd half issued an instruction
    // sch_even_issue                   SCH even half issued an instruction
    //{ FERMI_SCH_ODD_ISSUE,                  "sch_odd_issue",            "sch_odd_issue",            0x0000002c, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_EVEN_ISSUE,                 "sch_even_issue",           "sch_even_issue",           0x0000002c, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_EVEN_THREAD_INST_DECODED,   "sch_even_thread_inst_decoded","sch_even_thread_inst_decoded",  0x0000002f, 0x00543210, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_ODD_THREAD_INST_DECODED,    "sch_odd_thread_inst_decoded", "sch_odd_thread_inst_decoded",   0x00000030, 0x00543210, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ***REPLAY REASONS***
    // sl_l1_deferred                   SL L1 had a defer (defer_mask != 0)
    //                                  i.e. total number of replays due to L1 deferral. cost not because of the program, but L1 design. counted in sl
    // sl_l1_divergent                  SL L1 instr had a replay due to divergence
    //                                  i.e. total number of replays due to memory address divergence. basically the extra cost you pay for your program pattern (serialization). counted in sl
    // sl_l1_replayed                   SL L1 instr replayed (due to divergence or defer)
    //                                  i.e. total number of memory instructions (instruction count) that are replayed (i.e. divergent or deferred). note: divergence and L1 deferral can happen for the same instruction. counted in sl
    // sch_even_imc_replay              sch got a replay request from imc
    // sch_odd_imc_replay               sch got a replay request from imc
    // sch_replay_others                SCH number of imc/idc miss or ipa replays
    // dsm_ipa_or_pixld_replay          DSM replay on an ipa or pixld instruction
    // agu_idc_replayed                 AGU indexed c$ access replayed
    //                                  i.e. total number of constant cache instructions that are replayed. counted in aguc

    // sm_even_imc_miss_replay          sm2pm_gpc_dsm_imc0_miss | sm2pm_gpc_dsm_imc0_match | sm2pm_gpc_dsm_imc0_full
    //                                  i.e. number of replays due to IMC miss
    // sm_odd_imc_miss_replay           sm2pm_gpc_dsm_imc1_miss | sm2pm_gpc_dsm_imc1_match | sm2pm_gpc_dsm_imc1_full
    //                                  i.e. number of replays due to IMC miss

    { HWPM_FERMI_SL_L1_DEFERRED,                   hwpm_fermi_sl_l1_deferred_enc_str_1,         0x0000006a, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SL_L1_DIVERGENT,                  hwpm_fermi_sl_l1_divergent_enc_str_1,        0x0000006a, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SL_L1_REPLAYED,                   hwpm_fermi_sl_l1_replayed_enc_str_1,         0x0000006a, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_EVEN_IMC_REPLAY,            "__sch_even_imc_replay",    0x00000025, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_ODD_IMC_REPLAY,             "__sch_odd_imc_replay",     0x00000025, 0x00000007, 0x0000AAAA,  0x38,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,0,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_DSM_EVEN_IMC_MISS_REPLAY,         fermi_dsm_even_imc_miss_replay_enc_str_4,0x00000062, 0x00000321, 0x0000FEFE,  0x343332,     FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_DSM_ODD_IMC_MISS_REPLAY,          fermi_dsm_odd_imc_miss_replay_enc_str_4, 0x00000062, 0x00000765, 0x0000FEFE,  0x383736,     FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,1,1}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_REPLAY_OTHERS,              "__sch_replay_others",      0x0000002c, 0x00000076, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_DSM_IPA_OR_PIXLD_REPLAY,          hwpm_fermi_dsm_ipa_or_pixld_replay_enc_str_1,0x00000057, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_AGU_IDC_REPLAYED,                 hwpm_fermi_agu_idc_replayed_enc_str_1,       0x00000068, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ***LAUNCHED***
    // sch_warps_launched               SM has launched 1 warp
    // sch_threads_launched             number of threads SM launched this cycle
    { HWPM_FERMI_SCH_WARPS_LAUNCHED,               hwpm_fermi_sch_warps_launched_enc_str_1,           0x00000026, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_THREADS_LAUNCHED,             hwpm_fermi_sch_threads_launched_enc_str_1,         0x00000026, 0x00000001, 0x0000FFFF,  0x32,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,1,1,1,1,1,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ****ACTIVE_WARPS***
    // sch_active_cycles                sch has at lest 1 active warp.
    // sch_active_warps                 number of active warps SM currently has
    //                                  i.e. Every cycle, increment this counter by the number of active warps
    //{ FERMI_SCH_ACTIVE_CYCLES,              "sch_active_cycles",        0x00000024, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ACTIVE_WARPS,                 hwpm_fermi_sch_active_warps_enc_str_1,             0x00000024, 0x00000001, 0x0000FFFF,  0x32,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,1,1,1,1,1,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // sch_warp_issue_holes             number of warps not eligible to be issued this cycle
    //                                  i.e. Every cycle, increment this counter by the number of active warps that do not have an instruction eligible for issue due to warp only reasons.
    //                                  Warp only reason includes register scoreboard, 3 cycle reissue limit, no instruction in the SCH. If any warp only reason is true, the count is incremented regardless of any other ineligibility reason.
    { HWPM_FERMI_SCH_WARP_ISSUE_HOLES,             hwpm_fermi_sch_warp_issue_holes_enc_str_1,   0x00000027, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // sch_warp_issue_holes_long        number of warps not eligible to be issued for > 32 cycles
    //                                  i.e. similar to warp_issue_holes, but only count warps that have not been issue for at least 31 cycles.
    { HWPM_FERMI_SCH_WARP_ISSUE_HOLES_LONG,        hwpm_fermi_sch_warp_issue_holes_long_enc_str_1, 0x00000028,0x00000000,  0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // sch_warp_issue_eligible          number of warps eligible to be issued this cycle
    //                                  i.e. Every cycle, increment this counter by the number of warps eligible to issue. A warp is counted if it eligible for issue, even it is not ultimately selected.
    { HWPM_FERMI_SCH_WARP_ISSUE_ELIGIBLE,          hwpm_fermi_sch_warp_issue_eligible_enc_str_1,    0x00000029, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // fet_icc_miss                     FET: fetch resulted in an I$ miss
    //                                  i.e. count the number of cache new misses. Covered misses and miss fail are not counted.
    // fet_icc_hit                      FET: fetch resulted in an I$ hit
    //                                  i.e. count the number of cache hits
    { HWPM_FERMI_FET_ICC_MISS,                     hwpm_fermi_fet_icc_miss_enc_str_1,               0x00000014, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_FET_ICC_HIT,                      hwpm_fermi_fet_icc_hit_enc_str_1,                0x00000014, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // fet_any_active                   FET: has at least 1 active warp
    //                                  i.e. Count total number of cycles SM has at least one active warp, existing warp, not necessarily to be schedulable
    { HWPM_FERMI_FET_ANY_ACTIVE,                   hwpm_fermi_fet_any_active_enc_str_1,            0x00000011, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // sch_even_cant_issue_no_inst              SCH number of warps with no instructions in the IB
    // sch_even_cant_issue_interlock_long       SCH number of warps blocked on ld/st or scoreboard interlock > 32 clocks
    // sch_even_cant_issue_interlock_short      SCH number of warps blocked on ld/st or scoreboard interlock < 32 clocks
    // sch_even_cant_issue_reissue              SCH number of warps blocked by 3 cycle reissue limit
    // sch_even_cant_issue_dsm_q_full           SCH number of warps blocked by full dsm queue
    // sch_even_cant_issue_barrier              SCH number of warps blocked by barrier
    // sch_even_cant_issue_l1_sleep             SCH number of warps blocked by l1 deferral
    // sch_even_cant_issue_all                  SCH number of warps blocked by any reason

    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_NO_INST,          hwpm_fermi_sch_even_cant_issue_no_inst_enc_str_1,        0x0000003b, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_INTERLOCK_LONG,   hwpm_fermi_sch_even_cant_issue_interlock_long_enc_str_1, 0x0000003c, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_INTERLOCK_SHORT,  hwpm_fermi_sch_even_cant_issue_interlock_short_enc_str_1,0x0000003d, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_REISSUE,          hwpm_fermi_sch_even_cant_issue_reissue_enc_str_1,        0x0000003e, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_DSM_Q_FULL,       hwpm_fermi_sch_even_cant_issue_dsm_q_full_enc_str_1,     0x0000003f, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_TEX_SIDE,         hwpm_fermi_sch_even_cant_issue_tex_side_enc_str_1,       0x00000043, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_BARRIER,          hwpm_fermi_sch_even_cant_issue_barrier_enc_str_1,        0x00000045, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_L1_SLEEP,         hwpm_fermi_sch_even_cant_issue_l1_sleep_enc_str_1,       0x00000046, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_ALL,              hwpm_fermi_sch_even_cant_issue_all_enc_str_1,            0x00000047, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_NO_INST,           hwpm_fermi_sch_odd_cant_issue_no_inst_enc_str_1,         0x00000048, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_INTERLOCK_LONG,    hwpm_fermi_sch_odd_cant_issue_interlock_long_enc_str_1,  0x00000049, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_INTERLOCK_SHORT,   hwpm_fermi_sch_odd_cant_issue_interlock_short_enc_str_1, 0x0000004a, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_REISSUE,           hwpm_fermi_sch_odd_cant_issue_reissue_enc_str_1,         0x0000004b, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_DSM_Q_FULL,        hwpm_fermi_sch_odd_cant_issue_dsm_q_full_enc_str_1,      0x0000004c, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_TEX_SIDE,          hwpm_fermi_sch_odd_cant_issue_tex_side_enc_str_1,        0x00000050, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_BARRIER,           hwpm_fermi_sch_odd_cant_issue_barrier_enc_str_1,         0x00000052, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_L1_SLEEP,          hwpm_fermi_sch_odd_cant_issue_l1_sleep_enc_str_1,        0x00000053, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_ALL,               hwpm_fermi_sch_odd_cant_issue_all_enc_str_1,             0x00000054, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

#endif
    // ########### MPC Unit ###########
    // mpc_total_CTAs_launched          Total number of CTAs launched by this MPC
    { FERMI_MPC_TOTAL_CTAS_LAUNCHED,          fermi_mpc_total_ctas_launched_enc_str_1,          0x0000000e, 0x00000006, 0x0000AAAA,  0x26,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_MPC,    {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ########### L1 Cache (L1C) Unit ###########
    // local_load_hit                   local load hit (includes LinkAs)
    // local_load_miss                  local load miss(includes LinkBs)
    // local_store_hit                  local store hit
    // local_store_miss                 local store miss
    // global_load_hit                  global load hit
    // global_load_miss                 global load miss (only cached global loads that miss)
    // uncached_global_load             uncached global load count. Increments by 1 for each 32bit word.
    // global_store                     global store - always uncached. Increments by 1 for each 32bit word.
    { FERMI_L1C_SHARED_LOAD_TRANSACTIONS,     fermi_l1c_shared_load_transactions_enc_str_1, 0x00000000, 0x00000000, 0x0000AAAA,  0x0,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_L1C,    {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_SHARED_STORE_TRANSACTIONS,    fermi_l1c_shared_store_transactions_enc_str_1,0x00000000, 0x00000001, 0x0000AAAA,  0x1,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_L1C,    {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_LOCAL_LOAD_HIT,               fermi_l1c_local_load_hit_enc_str_1,          0x00000001, 0x00000000, 0x0000AAAA,  0x0,          FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_L1C,    {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_LOCAL_LOAD_MISS,              fermi_l1c_local_load_miss_enc_str_1,         0x00000001, 0x00000001, 0x0000AAAA,  0x1,          FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_L1C,    {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_LOCAL_STORE_HIT,              fermi_l1c_local_store_hit_enc_str_1,         0x00000001, 0x00000002, 0x0000AAAA,  0x2,          FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_L1C,    {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_LOCAL_STORE_MISS,             fermi_l1c_local_store_miss_enc_str_1,        0x00000001, 0x00000003, 0x0000AAAA,  0x3,          FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_L1C,    {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_PARTIAL_LOCAL_STORE_MISS,     fermi_l1c_partial_local_store_miss_enc_str_1,0x00000001, 0x00000043, 0x00008888,  0x0403,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_L1C,    {0,0,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_GLOBAL_LOAD_HIT,              fermi_l1c_global_load_hit_enc_str_1,         0x00000001, 0x00000005, 0x0000AAAA,  0x5,          FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_L1C,    {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_GLOBAL_LOAD_MISS,             fermi_l1c_global_load_miss_enc_str_1,        0x00000001, 0x00000006, 0x0000AAAA,  0x6,          FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_L1C,    {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DIRTY_LINE_EVICTION,          fermi_l1c_dirty_line_eviction_enc_str_1,     0x00000001, 0x00000007, 0x0000AAAA,  0x7,          FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_L1C,    {0,0,0,0,0,0,0,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_UNCACHED_GLOBAL_LOAD,         fermi_l1c_uncached_global_load_enc_str_1, 0x00000002, 0x00000002, 0x0000AAAA,  0x2,          FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_L1C,    {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_GLOBAL_STORE,                 fermi_l1c_global_store_enc_str_1,         0x00000002, 0x00000003, 0x0000AAAA,  0x3,          FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_L1C,    {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ***DEFER REASONS***
    // defer_prt_full                   PRT is full
    //                                  i.e. count number of L1 PRT full deferral
    // defer_gni_stall                  GNI backpressures L1
    //                                  i.e. count number of deferes due to GNI backpressure (t2m fifo full) L1
    // defer_no_allocatable_cline       all ways are not allocatable
    //                                  i.e. count number of defers due to all lines in the same set having pending operations
    // defer_shared_bank_conflict       shared load/store bank conflict (>1 address within same bank accessed)
    // defer_store_bank_collision       Counts global atom/red memory conflicts (where multiple threads from a warp are writing into same memory-word)
    // defer_prt_load_limit             PRT reached load limit
    //                                  i.e. count number of times L1 had to defer cached loads because it reached PRT load limit
    // defer_prt_store_limit            PRT reached store limit
    //                                  i.e. count number of times L1 had to defer cached stores because it reached PRT store limit
    // defer_uncached_load_limit        reached max # uncached LDs to same set
    //                                  i.e. count number of times L1 is deferred because max number of uncached LD to the same set is reached
    { FERMI_L1C_DEFER_PRT_FULL,               fermi_l1c_defer_prt_full_enc_str_1,             0x00000005, 0x00000004, 0x0000AAAA,  0x04,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_L1C,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DEFER_GNI_STALL,              fermi_l1c_defer_gni_stall_enc_str_1,            0x00000005, 0x00000005, 0x0000AAAA,  0x05,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_L1C,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DEFER_NO_ALLOCATABLE_CLINE,   fermi_l1c_defer_no_allocatable_cline_enc_str_1, 0x00000005, 0x00000006, 0x0000AAAA,  0x06,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_L1C,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DEFER_SHARED_BANK_CONFLICT,   fermi_l1c_defer_shared_bank_conflict_enc_str_1,          0x00000006, 0x00000000, 0x0000AAAA,  0x00,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_L1C,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DEFER_STORE_BANK_COLLISION,   fermi_l1c_defer_store_bank_collision_enc_str_1, 0x00000006, 0x00000001, 0x0000AAAA,  0x01,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_L1C,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DEFER_PRT_LOAD_LIMIT,         fermi_l1c_defer_prt_load_limit_enc_str_1,       0x00000006, 0x00000003, 0x0000AAAA,  0x03,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_L1C,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DEFER_PRT_STORE_LIMIT,        fermi_l1c_defer_prt_store_limit_enc_str_1,      0x00000006, 0x00000004, 0x0000AAAA,  0x04,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_L1C,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DEFER_UNCACHED_LOAD_LIMIT,    fermi_l1c_defer_uncached_load_limit_enc_str_1,  0x00000006, 0x00000005, 0x0000AAAA,  0x05,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_L1C,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
#ifdef SMPM
    // NOP TRIGGERS
    // dsm_nop_trig_grp0                DSM: NOP trigger[7:0]
    // dsm_nop_trig_grp1                DSM: NOP trigger[15:8]
    { HWPM_FERMI_NOP_TRIG_00,                      hwpm_fermi_nop_trig_00_enc_str_1,          0x00000001, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_01,                      hwpm_fermi_nop_trig_01_enc_str_1,          0x00000001, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_02,                      hwpm_fermi_nop_trig_02_enc_str_1,          0x00000001, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_03,                      hwpm_fermi_nop_trig_03_enc_str_1,          0x00000001, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_04,                      hwpm_fermi_nop_trig_04_enc_str_1,          0x00000001, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_05,                      hwpm_fermi_nop_trig_05_enc_str_1,          0x00000001, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_06,                      hwpm_fermi_nop_trig_06_enc_str_1,          0x00000001, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_07,                      hwpm_fermi_nop_trig_07_enc_str_1,          0x00000001, 0x00000007, 0x0000AAAA,  0x38,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,0,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_08,                      hwpm_fermi_nop_trig_08_enc_str_1,            0x00000002, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_09,                      hwpm_fermi_nop_trig_09_enc_str_1,            0x00000002, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_10,                      hwpm_fermi_nop_trig_10_enc_str_1,            0x00000002, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_11,                      hwpm_fermi_nop_trig_11_enc_str_1,            0x00000002, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_12,                      hwpm_fermi_nop_trig_12_enc_str_1,            0x00000002, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_13,                      hwpm_fermi_nop_trig_13_enc_str_1,            0x00000002, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_14,                      hwpm_fermi_nop_trig_14_enc_str_1,            0x00000002, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_15,                      hwpm_fermi_nop_trig_15_enc_str_1,            0x00000002, 0x00000007, 0x0000AAAA,  0x38,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,0,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },


    // sch_inst_decoded                SCH insts decoded this cycle
    //                                 i.e. Count total number of instructions executed, do not count replay. It counts the number of instructions decoded in SCH
    { HWPM_FERMI_SCH_INST_DECODED,         hwpm_fermi_sch_inst_decoded_enc_str_1,            0x0000002d, 0x00000210, 0x0000FFFF,  0x31,  FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    //sch_even0_thread_inst_decoded      first poistion of even half threads decoded
    //sch_even1_thread_inst_decoded      second poistion of even half threads decoded
    //sch_odd0_thread_inst_decoded       first poistion of odd half threads decoded
    //sch_odd1_thread_inst_decoded       second poistion of odd half threads decoded
    //Count threads executed at first/second poistion of even/odd side, it is inst_executed at even/odd side multiplied by active mask, predicated off threads are also included.
    { HWPM_FERMI_SCH_EVEN0_THREAD_INST_DECODED,     hwpm_fermi_sch_even0_thread_inst_decoded_enc_str_1, 0x000000a3, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN1_THREAD_INST_DECODED,     hwpm_fermi_sch_even1_thread_inst_decoded_enc_str_1, 0x000000a4, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD0_THREAD_INST_DECODED,      hwpm_fermi_sch_odd0_thread_inst_decoded_enc_str_1, 0x000000a5, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD1_THREAD_INST_DECODED,      hwpm_fermi_sch_odd1_thread_inst_decoded_enc_str_1, 0x000000a6, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // sch_even_inst_issued_1          1 instructions issued this clock
    // sch_even_inst_issued_2          2 instructions issued this clock
    // sch_odd_inst_issued_1           1 instructions issued this clock
    // sch_odd_inst_issued_2           2 instructions issued this clock
    { HWPM_FERMI_SCH_EVEN_INST_ISSUED_1,   hwpm_fermi_sch_even_inst_issued_1_enc_str_1, 0x0000007e, 0x00000001, 0x0000AAAA,  0x32,  FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_INST_ISSUED_2,   hwpm_fermi_sch_even_inst_issued_2_enc_str_1, 0x0000007e, 0x00000002, 0x0000AAAA,  0x33,  FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_INST_ISSUED_1,    hwpm_fermi_sch_odd_inst_issued_1_enc_str_1,  0x0000007e, 0x00000004, 0x0000AAAA,  0x35,  FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_INST_ISSUED_2,    hwpm_fermi_sch_odd_inst_issued_2_enc_str_1,  0x0000007e, 0x00000005, 0x0000AAAA,  0x36,  FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    //sm_super_scalar_decoded1 = !sm2pm_gpc_fet_fetch_inst_count_1 & sm2pm_gpc_fet_fetch_inst_count_0
    //                          Count the number of cycles that SCH accepts/decodes one super-scalar-pair or singleton
    { HWPM_FERMI_SUPER_SCALAR_DECODED1,    hwpm_fermi_super_scalar_decoded1_enc_str_1,  0x00000012, 0x00000032, 0x00002222,  0x3433,  FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE, PM_CHIPLET_TYPE_GPC },
    //sm_super_scalar_decoded2 = sm2pm_gpc_fet_fetch_inst_count_1 & !sm2pm_gpc_fet_fetch_inst_count_0
    //                          Count the number of cycles that SCH accepts/decodes two super-scalar-pair or singleton
    { HWPM_FERMI_SUPER_SCALAR_DECODED2,    hwpm_fermi_super_scalar_decoded2_enc_str_1,  0x00000012, 0x00000032, 0x00004444,  0x3433,  FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE, PM_CHIPLET_TYPE_GPC },
    //sm_super_scalar_decoded = Count the number of super-scalar-pair or super-scalar-singleton that are decoded/accepted by SCH
    { HWPM_FERMI_SUPER_SCALAR_DECODED,     hwpm_fermi_super_scalar_decoded_enc_str_1,   0x00000012, 0x00000002, 0x0000FFFF,  0x33,    FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,1,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },


    // sm_odd_alu_only_inst_executed                Count ALU pipe only instructions decoded on the odd side
    // sm_odd_xlu_only_inst_executed                count XLU pipe only instructions decoded on the odd side
    // sm_odd_alu_xlu_bipipe_inst_executed          count ALU XLU bipipe instructions decoded on the odd side
    // sm_odd_fmalite_only_inst_executed            Count FMALite pipe instructions decoded on the odd side
    // sm_odd_fma32_only_inst_executed              count FMA32 only instruction decoded on the odd side
    // sm_odd_fmalite_fma32_bipipe_inst_executed    count FMALite FMA32 bipipe instruction decoded on the odd side
    // sm_odd_fu_inst_executed                      count FU pipe instruction decoded on the odd side
    // sm_odd_fma64_inst_executed                   count FMA64 pipe instruction decoded on the odd side
    // sm_odd_su_inst_executed                      count SU pipe instruction decoded on the odd side
    // sm_odd_agu_inst_executed                     count AGU pipe instruction decoded on the odd side
    // sm_odd_tex_inst_executed                     count TEX instruction decoded on the odd side
    // sm_odd_dsm_inst_executed                     count DSM pipe instruction decoded on the odd side
    // sm_odd_sch_internal_inst_executed            count SCH internal instruction decoded on the odd side
    // sm_odd_fe_inst_executed                      count FE pipe instruction decoded on the odd side


    { HWPM_FERMI_SM_ODD0_ALU_ONLY_INST_EXECUTED,              hwpm_fermi_sm_odd0_alu_only_inst_executed_enc_str_1,            0x0000009e, 0x00003210, 0x00000800, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_XLU_ONLY_INST_EXECUTED,              hwpm_fermi_sm_odd0_xlu_only_inst_executed_enc_str_1,            0x0000009e, 0x00003210, 0x00000004, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_ALU_XLU_BIPIPE_INST_EXECUTED,        hwpm_fermi_sm_odd0_alu_xlu_bipipe_inst_executed_enc_str_1,      0x0000009e, 0x00003210, 0x00000002, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_FMALITE_ONLY_INST_EXECUTED,          hwpm_fermi_sm_odd0_fmalite_only_inst_executed_enc_str_1,        0x0000009e, 0x00003210, 0x00000400, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_FMA32_ONLY_INST_EXECUTED,            hwpm_fermi_sm_odd0_fma32_only_inst_executed_enc_str_1,          0x0000009e, 0x00003210, 0x00000010, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_FMALITE_FMA32_BIPIPE_INST_EXECUTED,  hwpm_fermi_sm_odd0_fmalite_fma32_bipipe_inst_executed_enc_str_1,0x0000009e, 0x00003210, 0x00000001, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_FU_INST_EXECUTED,                    hwpm_fermi_sm_odd0_fu_inst_executed_enc_str_1,                  0x0000009e, 0x00003210, 0x00000020, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_FMA64_INST_EXECUTED,                 hwpm_fermi_sm_odd0_fma64_inst_executed_enc_str_1,               0x0000009e, 0x00003210, 0x00000040, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_SU_INST_EXECUTED,                    hwpm_fermi_sm_odd0_su_inst_executed_enc_str_1,                  0x0000009e, 0x00003210, 0x00000008, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_AGU_INST_EXECUTED,                   hwpm_fermi_sm_odd0_agu_inst_executed_enc_str_1,                 0x0000009e, 0x00003210, 0x00000080, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_TEX_INST_EXECUTED,                   hwpm_fermi_sm_odd0_tex_inst_executed_enc_str_1,                 0x0000009e, 0x00003210, 0x00000100, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_DSM_INST_EXECUTED,                   hwpm_fermi_sm_odd0_dsm_inst_executed_enc_str_1,                 0x0000009e, 0x00003210, 0x00000200, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_SCH_INTERNAL_INST_EXECUTED,          hwpm_fermi_sm_odd0_sch_internal_inst_executed_enc_str_1,        0x0000009e, 0x00003210, 0x00002000, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_FE_INST_EXECUTED,                    hwpm_fermi_sm_odd0_fe_inst_executed_enc_str_1,                  0x0000009e, 0x00003210, 0x00001000, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },

    { HWPM_FERMI_SM_ODD1_ALU_ONLY_INST_EXECUTED,              hwpm_fermi_sm_odd1_alu_only_inst_executed_enc_str_1,            0x0000009e, 0x00007654, 0x00000800, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_XLU_ONLY_INST_EXECUTED,              hwpm_fermi_sm_odd1_xlu_only_inst_executed_enc_str_1,            0x0000009e, 0x00007654, 0x00000004, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_ALU_XLU_BIPIPE_INST_EXECUTED,        hwpm_fermi_sm_odd1_alu_xlu_bipipe_inst_executed_enc_str_1,      0x0000009e, 0x00007654, 0x00000002, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_FMALITE_ONLY_INST_EXECUTED,          hwpm_fermi_sm_odd1_fmalite_only_inst_executed_enc_str_1,        0x0000009e, 0x00007654, 0x00000400, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_FMA32_ONLY_INST_EXECUTED,            hwpm_fermi_sm_odd1_fma32_only_inst_executed_enc_str_1,          0x0000009e, 0x00007654, 0x00000010, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_FMALITE_FMA32_BIPIPE_INST_EXECUTED,  hwpm_fermi_sm_odd1_fmalite_fma32_bipipe_inst_executed_enc_str_1,0x0000009e, 0x00007654, 0x00000001, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_FU_INST_EXECUTED,                    hwpm_fermi_sm_odd1_fu_inst_executed_enc_str_1,                  0x0000009e, 0x00007654, 0x00000020, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_FMA64_INST_EXECUTED,                 hwpm_fermi_sm_odd1_fma64_inst_executed_enc_str_1,               0x0000009e, 0x00007654, 0x00000040, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_SU_INST_EXECUTED,                    hwpm_fermi_sm_odd1_su_inst_executed_enc_str_1,                  0x0000009e, 0x00007654, 0x00000008, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_AGU_INST_EXECUTED,                   hwpm_fermi_sm_odd1_agu_inst_executed_enc_str_1,                 0x0000009e, 0x00007654, 0x00000080, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_TEX_INST_EXECUTED,                   hwpm_fermi_sm_odd1_tex_inst_executed_enc_str_1,                 0x0000009e, 0x00007654, 0x00000100, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_DSM_INST_EXECUTED,                   hwpm_fermi_sm_odd1_dsm_inst_executed_enc_str_1,                 0x0000009e, 0x00007654, 0x00000200, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_SCH_INTERNAL_INST_EXECUTED,          hwpm_fermi_sm_odd1_sch_internal_inst_executed_enc_str_1,        0x0000009e, 0x00007654, 0x00002000, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_FE_INST_EXECUTED,                    hwpm_fermi_sm_odd1_fe_inst_executed_enc_str_1,                  0x0000009e, 0x00007654, 0x00001000, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },

    // sm_even_alu_only_inst_executed               Count ALU pipe only instructions decoded on the even side
    // sm_even_xlu_only_inst_executed               count XLU pipe only instructions decoded on the even side
    // sm_even_alu_xlu_bipipe_inst_executed         count ALU XLU bipipe instructions decoded on the even side
    // sm_even_fmalite_only_inst_executed           Count FMALite pipe instructions decoded on the even side
    // sm_even_fma32_only_inst_executed             count FMA32 only instruction decoded on the even side
    // sm_even_fmalite_fma32_bipipe_inst_executed   count FMALite FMA32 bipipe instruction decoded on the even side
    // sm_even_fu_inst_executed                     count FU pipe instruction decoded on the even side
    // sm_even_fma64_inst_executed                  count FMA64 pipe instruction decoded on the even side
    // sm_even_su_inst_executed                     count SU pipe instruction decoded on the even side
    // sm_even_agu_inst_executed                    count AGU pipe instruction decoded on the even side
    // sm_even_tex_inst_executed                    count TEX instruction decoded on the even side
    // sm_even_dsm_inst_executed                    count DSM pipe instruction decoded on the even side
    // sm_even_sch_internal_inst_executed           count SCH internal instruction decoded on the even side
    // sm_even_fe_inst_executed                     count FE pipe instruction decoded on the even side

    { HWPM_FERMI_SM_EVEN0_ALU_ONLY_INST_EXECUTED,              hwpm_fermi_sm_even0_alu_only_inst_executed_enc_str_1,            0x0000009d, 0x00003210, 0x00000800, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_XLU_ONLY_INST_EXECUTED,              hwpm_fermi_sm_even0_xlu_only_inst_executed_enc_str_1,            0x0000009d, 0x00003210, 0x00000004, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_ALU_XLU_BIPIPE_INST_EXECUTED,        hwpm_fermi_sm_even0_alu_xlu_bipipe_inst_executed_enc_str_1,      0x0000009d, 0x00003210, 0x00000002, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_FMALITE_ONLY_INST_EXECUTED,          hwpm_fermi_sm_even0_fmalite_only_inst_executed_enc_str_1,        0x0000009d, 0x00003210, 0x00000400, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_FMA32_ONLY_INST_EXECUTED,            hwpm_fermi_sm_even0_fma32_only_inst_executed_enc_str_1,          0x0000009d, 0x00003210, 0x00000010, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_FMALITE_FMA32_BIPIPE_INST_EXECUTED,  hwpm_fermi_sm_even0_fmalite_fma32_bipipe_inst_executed_enc_str_1,0x0000009d, 0x00003210, 0x00000001, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_FU_INST_EXECUTED,                    hwpm_fermi_sm_even0_fu_inst_executed_enc_str_1,                  0x0000009d, 0x00003210, 0x00000020, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_FMA64_INST_EXECUTED,                 hwpm_fermi_sm_even0_fma64_inst_executed_enc_str_1,               0x0000009d, 0x00003210, 0x00000040, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_SU_INST_EXECUTED,                    hwpm_fermi_sm_even0_su_inst_executed_enc_str_1,                  0x0000009d, 0x00003210, 0x00000008, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_AGU_INST_EXECUTED,                   hwpm_fermi_sm_even0_agu_inst_executed_enc_str_1,                 0x0000009d, 0x00003210, 0x00000080, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_TEX_INST_EXECUTED,                   hwpm_fermi_sm_even0_tex_inst_executed_enc_str_1,                 0x0000009d, 0x00003210, 0x00000100, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_DSM_INST_EXECUTED,                   hwpm_fermi_sm_even0_dsm_inst_executed_enc_str_1,                 0x0000009d, 0x00003210, 0x00000200, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_SCH_INTERNAL_INST_EXECUTED,          hwpm_fermi_sm_even0_sch_internal_inst_executed_enc_str_1,        0x0000009d, 0x00003210, 0x00002000, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_FE_INST_EXECUTED,                    hwpm_fermi_sm_even0_fe_inst_executed_enc_str_1,                  0x0000009d, 0x00003210, 0x00001000, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },

    { HWPM_FERMI_SM_EVEN1_ALU_ONLY_INST_EXECUTED,              hwpm_fermi_sm_even1_alu_only_inst_executed_enc_str_1,            0x0000009d, 0x00007654, 0x00000800, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_XLU_ONLY_INST_EXECUTED,              hwpm_fermi_sm_even1_xlu_only_inst_executed_enc_str_1,            0x0000009d, 0x00007654, 0x00000004, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_ALU_XLU_BIPIPE_INST_EXECUTED,        hwpm_fermi_sm_even1_alu_xlu_bipipe_inst_executed_enc_str_1,      0x0000009d, 0x00007654, 0x00000002, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_FMALITE_ONLY_INST_EXECUTED,          hwpm_fermi_sm_even1_fmalite_only_inst_executed_enc_str_1,        0x0000009d, 0x00007654, 0x00000400, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_FMA32_ONLY_INST_EXECUTED,            hwpm_fermi_sm_even1_fma32_only_inst_executed_enc_str_1,          0x0000009d, 0x00007654, 0x00000010, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_FMALITE_FMA32_BIPIPE_INST_EXECUTED,  hwpm_fermi_sm_even1_fmalite_fma32_bipipe_inst_executed_enc_str_1,0x0000009d, 0x00007654, 0x00000001, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_FU_INST_EXECUTED,                    hwpm_fermi_sm_even1_fu_inst_executed_enc_str_1,                  0x0000009d, 0x00007654, 0x00000020, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_FMA64_INST_EXECUTED,                 hwpm_fermi_sm_even1_fma64_inst_executed_enc_str_1,               0x0000009d, 0x00007654, 0x00000040, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_SU_INST_EXECUTED,                    hwpm_fermi_sm_even1_su_inst_executed_enc_str_1,                  0x0000009d, 0x00007654, 0x00000008, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_AGU_INST_EXECUTED,                   hwpm_fermi_sm_even1_agu_inst_executed_enc_str_1,                 0x0000009d, 0x00007654, 0x00000080, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_TEX_INST_EXECUTED,                   hwpm_fermi_sm_even1_tex_inst_executed_enc_str_1,                 0x0000009d, 0x00007654, 0x00000100, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_DSM_INST_EXECUTED,                   hwpm_fermi_sm_even1_dsm_inst_executed_enc_str_1,                 0x0000009d, 0x00007654, 0x00000200, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_SCH_INTERNAL_INST_EXECUTED,          hwpm_fermi_sm_even1_sch_internal_inst_executed_enc_str_1,        0x0000009d, 0x00007654, 0x00002000, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_FE_INST_EXECUTED,                    hwpm_fermi_sm_even1_fe_inst_executed_enc_str_1,                  0x0000009d, 0x00007654, 0x00001000, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
#endif

    //Tex signals
    //tex0_cache_sector_queries  = tex02pm_gpc_t_sector_queries
    //tex0_cache_sector_misses   = tex02pm_gpc_t_missed_sectors
    //tex1_cache_sector_queries = tex12pm_gpc_t_sector_queries
    //tex1_cache_sector_misses  = tex12pm_gpc_t_missed_sectors

    { FERMI_TEX_CACHE_SECTOR_QUERIES,    fermi_tex_cache_sector_queries_enc_str_1, 0x00000005, 0x00000000, 0x0000FFFF, 0x0000000e, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_TEX,     {0,0,0,0,1,1,1,1,1,0 }, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC, 0x00000003},
    { FERMI_TEX_CACHE_SECTOR_MISSES,     fermi_tex_cache_sector_misses_enc_str_1,  0x00000004, 0x00000000, 0x0000FFFF, 0x0000000a, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_TEX,     {1,1,1,1,1,0,0,0,0,0 }, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC, 0x00000003},
    { FERMI_TEX1_CACHE_SECTOR_QUERIES,   fermi_tex1_cache_sector_queries_enc_str_1,0x00000005, 0x00000000, 0x0000FFFF, 0x0000000e, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_TEX,     {0,0,0,0,1,1,1,1,1,0 }, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC, 0x00000004},
    { FERMI_TEX1_CACHE_SECTOR_MISSES,    fermi_tex1_cache_sector_misses_enc_str_1, 0x00000004, 0x00000000, 0x0000FFFF, 0x0000000a, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_TEX,     {1,1,1,1,1,0,0,0,0,0 }, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC, 0x00000004},

    { FERMI_TEX0_RETURN_PACKET_COUNT,    fermi_tex0_return_packet_count_enc_str_1,   0x00000003, 0x00000000, 0x00008888, 0x00006263, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_TEX_D,     {0,0,0,0,0,0,0,0,0,0 }, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC, 0x00000000},
    { FERMI_TEX1_RETURN_PACKET_COUNT,    fermi_tex1_return_packet_count_enc_str_1,   0x00000003, 0x00000000, 0x00008888, 0x00006263, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_TEX_D,     {0,0,0,0,0,0,0,0,0,0 }, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC, 0x00000001},

    { FERMI_ELAPSED_CYCLES_SM,     fermi_elapsed_cycles_sm_enc_str_1,  0x00000000, 0x00000000, 0x00000000, 0x00000000, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000, 0x00000000,  0x00,         FERMI_CLK_DOMAIN_MAX,     PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE }
};


PerfSignalTableNew PerfSignalTableGF104_sm0[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type
    // ########### SM Unit ###########
    // ***LOAD/STORE***
    // agu_l1_local_ld                  AGU L1 LD is to local space (based on priority thread space)
    // agu_l1_global_ld                 AGU L1 LD is to global space (based on priority thread space)
    // agu_l1_local_st                  AGU L1 ST is to local space (based on priority thread space)
    // agu_l1_global_st                 AGU L1 ST is to global space (based on priority thread space)
    // agu_l1_shared_ld                 AGU L1 LD is to shared space (based on priority thread space)
    // agu_l1_shared_st                 AGU L1 ST is to shared space (based on priority thread space)
    { FERMI_AGU_L1_LOCAL_LD,                  fermi_agu_l1_local_ld_enc_str_1,               0x00000064, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_AGU_L1_LOCAL_ST,                  fermi_agu_l1_local_st_enc_str_1,              0x00000064, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_AGU_L1_GLOBAL_LD,                 fermi_agu_l1_global_ld_enc_str_1,              0x00000064, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_AGU_L1_GLOBAL_ST,                 fermi_agu_l1_global_st_enc_str_1,              0x00000064, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_AGU_L1_SHARED_LD,                 fermi_agu_l1_shared_ld_enc_str_1,              0x00000064, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_AGU_L1_SHARED_ST,                 fermi_agu_l1_shared_st_enc_str_1,             0x00000064, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ***BRANCH***
    { FERMI_FET_UNIQUE_BRANCHES,              fermi_fet_unique_branches_enc_str_1,                 0x0000001a, 0x00000010, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_TAKEN_BRANCHES,               fermi_fet_taken_branches_enc_str_1,     0x00000019, 0x00000010, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_UNIQUE_BRANCHES_0,            fermi_fet_unique_branches_0_enc_str_1,               0x0000001a, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_UNIQUE_BRANCHES_1,            fermi_fet_unique_branches_1_enc_str_1,               0x0000001a, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_DIVERGED_BRANCHES,            fermi_fet_diverged_branches_enc_str_1,         0x00000019, 0x00000032, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,1,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_ODD_CONTROL_FLOW_STALL,       fermi_fet_odd_control_flow_stall_enc_str_1,  0x00000020, 0x00000014, 0x00002020,  0x313235,     FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,0,0,1,0,0,0}, SIG_TYPE_MULTIPLE,   PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_EVEN_CONTROL_FLOW_STALL,      fermi_fet_even_control_flow_stall_enc_str_1, 0x00000021, 0x00000014, 0x00002020,  0x313235,     FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,0,0,1,0,0,0}, SIG_TYPE_MULTIPLE,   PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_DIVERGED_BRANCHES_0,          fermi_fet_diverged_branches_0_enc_str_1,     0x00000019, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_DIVERGED_BRANCHES_1,          fermi_fet_diverged_branches_1_enc_str_1,     0x00000019, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ***LAUNCHED***
    // sch_warps_launched               SM has launched 1 warp
    // sch_threads_launched             number of threads SM launched this cycle
    { FERMI_SCH_WARPS_LAUNCHED,               fermi_sch_warps_launched_enc_str_1,           0x00000026, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_THREADS_LAUNCHED,             fermi_sch_threads_launched_enc_str_1,         0x00000026, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,1,1,1,1,1,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_THREADS_LAUNCHED_0,           fermi_sch_threads_launched_0_enc_str_1,     0x00000026, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_THREADS_LAUNCHED_1,           fermi_sch_threads_launched_1_enc_str_1,     0x00000026, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_THREADS_LAUNCHED_2,           fermi_sch_threads_launched_2_enc_str_1,     0x00000026, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_THREADS_LAUNCHED_3,           fermi_sch_threads_launched_3_enc_str_1,     0x00000026, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_THREADS_LAUNCHED_4,           fermi_sch_threads_launched_4_enc_str_1,     0x00000026, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_THREADS_LAUNCHED_5,           fermi_sch_threads_launched_5_enc_str_1,     0x00000026, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // sch_even_inst_issued_1          1 instructions issued this clock
    // sch_even_inst_issued_2          2 instructions issued this clock
    // sch_odd_inst_issued_1           1 instructions issued this clock
    // sch_odd_inst_issued_2           2 instructions issued this clock
    { FERMI_SCH_EVEN_INST_ISSUED_1,   fermi_sch_even_inst_issued_1_enc_str_1, 0x0000007e, 0x00000001, 0x0000AAAA,  0x32,  FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_INST_ISSUED_2,   fermi_sch_even_inst_issued_2_enc_str_1, 0x0000007e, 0x00000002, 0x0000AAAA,  0x33,  FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_INST_ISSUED_1,    fermi_sch_odd_inst_issued_1_enc_str_1,  0x0000007e, 0x00000004, 0x0000AAAA,  0x35,  FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_INST_ISSUED_2,    fermi_sch_odd_inst_issued_2_enc_str_1,  0x0000007e, 0x00000005, 0x0000AAAA,  0x36,  FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // NOP TRIGGERS
    // dsm_nop_trig_grp0                DSM: NOP trigger[7:0]
    // dsm_nop_trig_grp1                DSM: NOP trigger[15:8]
    { FERMI_NOP_TRIG_00,                      fermi_nop_trig_00_enc_str_1,          0x00000001, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_01,                      fermi_nop_trig_01_enc_str_1,          0x00000001, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_02,                      fermi_nop_trig_02_enc_str_1,          0x00000001, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_03,                      fermi_nop_trig_03_enc_str_1,          0x00000001, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_04,                      fermi_nop_trig_04_enc_str_1,          0x00000001, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_05,                      fermi_nop_trig_05_enc_str_1,          0x00000001, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_06,                      fermi_nop_trig_06_enc_str_1,          0x00000001, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_07,                      fermi_nop_trig_07_enc_str_1,          0x00000001, 0x00000007, 0x0000AAAA,  0x38,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,0,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_08,                      fermi_nop_trig_08_enc_str_1,            0x00000002, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_09,                      fermi_nop_trig_09_enc_str_1,            0x00000002, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_10,                      fermi_nop_trig_10_enc_str_1,            0x00000002, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_11,                      fermi_nop_trig_11_enc_str_1,            0x00000002, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_12,                      fermi_nop_trig_12_enc_str_1,            0x00000002, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_13,                      fermi_nop_trig_13_enc_str_1,            0x00000002, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_14,                      fermi_nop_trig_14_enc_str_1,            0x00000002, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_15,                      fermi_nop_trig_15_enc_str_1,            0x00000002, 0x00000007, 0x0000AAAA,  0x38,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,0,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // sch_inst_decoded                SCH insts decoded this cycle
    //                                 i.e. Count total number of instructions executed, do not count replay. It counts the number of instructions decoded in SCH
    { FERMI_SCH_INST_DECODED,                 fermi_sch_inst_decoded_enc_str_1,            0x0000002d, 0x00000210, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_INST_DECODED_0,               fermi_sch_inst_decoded_0_enc_str_1,        0x0000002d, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_INST_DECODED_1,               fermi_sch_inst_decoded_1_enc_str_1,        0x0000002d, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_INST_DECODED_2,               fermi_sch_inst_decoded_2_enc_str_1,        0x0000002d, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    //sch_even0_thread_inst_decoded      first poistion of even half threads decoded
    //sch_even1_thread_inst_decoded      second poistion of even half threads decoded
    //sch_odd0_thread_inst_decoded       first poistion of odd half threads decoded
    //sch_odd1_thread_inst_decoded       second poistion of odd half threads decoded
    //Count threads executed at first/second poistion of even/odd side, it is inst_executed at even/odd side multiplied by active mask, predicated off threads are also included.
    { FERMI_SCH_EVEN0_THREAD_INST_DECODED,     fermi_sch_even0_thread_inst_decoded_enc_str_1, 0x000000a3, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN1_THREAD_INST_DECODED,     fermi_sch_even1_thread_inst_decoded_enc_str_1, 0x000000a4, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD0_THREAD_INST_DECODED,      fermi_sch_odd0_thread_inst_decoded_enc_str_1, 0x000000a5, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD1_THREAD_INST_DECODED,      fermi_sch_odd1_thread_inst_decoded_enc_str_1, 0x000000a6, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    //sm_super_scalar_decoded1 = !sm2pm_gpc_fet_fetch_inst_count_1 & sm2pm_gpc_fet_fetch_inst_count_0
    //                          Count the number of cycles that SCH accepts/decodes one super-scalar-pair or singleton
    { FERMI_SUPER_SCALAR_DECODED1,    fermi_super_scalar_decoded1_enc_str_1,  0x00000012, 0x00000032, 0x00002222,  0x3433,  FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE, PM_CHIPLET_TYPE_GPC },
    //sm_super_scalar_decoded2 = sm2pm_gpc_fet_fetch_inst_count_1 & !sm2pm_gpc_fet_fetch_inst_count_0
    //                          Count the number of cycles that SCH accepts/decodes two super-scalar-pair or singleton
    { FERMI_SUPER_SCALAR_DECODED2,    fermi_super_scalar_decoded2_enc_str_1,  0x00000012, 0x00000032, 0x00004444,  0x3433,  FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE, PM_CHIPLET_TYPE_GPC },
    //sm_super_scalar_decoded = Count the number of super-scalar-pair or super-scalar-singleton that are decoded/accepted by SCH
    { FERMI_SUPER_SCALAR_DECODED,     fermi_super_scalar_decoded_enc_str_1,   0x00000012, 0x00000002, 0x0000AAAA,  0x33,    FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,1,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },


    // sm_odd_alu_only_inst_executed                Count ALU pipe only instructions decoded on the odd side
    // sm_odd_xlu_only_inst_executed                count XLU pipe only instructions decoded on the odd side
    // sm_odd_alu_xlu_bipipe_inst_executed          count ALU XLU bipipe instructions decoded on the odd side
    // sm_odd_fmalite_only_inst_executed            Count FMALite pipe instructions decoded on the odd side
    // sm_odd_fma32_only_inst_executed              count FMA32 only instruction decoded on the odd side
    // sm_odd_fmalite_fma32_bipipe_inst_executed    count FMALite FMA32 bipipe instruction decoded on the odd side
    // sm_odd_fu_inst_executed                      count FU pipe instruction decoded on the odd side
    // sm_odd_fma64_inst_executed                   count FMA64 pipe instruction decoded on the odd side
    // sm_odd_su_inst_executed                      count SU pipe instruction decoded on the odd side
    // sm_odd_agu_inst_executed                     count AGU pipe instruction decoded on the odd side
    // sm_odd_tex_inst_executed                     count TEX instruction decoded on the odd side
    // sm_odd_dsm_inst_executed                     count DSM pipe instruction decoded on the odd side
    // sm_odd_sch_internal_inst_executed            count SCH internal instruction decoded on the odd side
    // sm_odd_fe_inst_executed                      count FE pipe instruction decoded on the odd side


    { FERMI_SM_ODD0_ALU_ONLY_INST_EXECUTED,              fermi_sm_odd0_alu_only_inst_executed_enc_str_1,            0x0000009e, 0x00003210, 0x00000800, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_XLU_ONLY_INST_EXECUTED,              fermi_sm_odd0_xlu_only_inst_executed_enc_str_1,            0x0000009e, 0x00003210, 0x00000004, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_ALU_XLU_BIPIPE_INST_EXECUTED,        fermi_sm_odd0_alu_xlu_bipipe_inst_executed_enc_str_1,      0x0000009e, 0x00003210, 0x00000002, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FMALITE_ONLY_INST_EXECUTED,          fermi_sm_odd0_fmalite_only_inst_executed_enc_str_1,        0x0000009e, 0x00003210, 0x00000400, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FMA32_ONLY_INST_EXECUTED,            fermi_sm_odd0_fma32_only_inst_executed_enc_str_1,          0x0000009e, 0x00003210, 0x00000010, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FMALITE_FMA32_BIPIPE_INST_EXECUTED,  fermi_sm_odd0_fmalite_fma32_bipipe_inst_executed_enc_str_1,0x0000009e, 0x00003210, 0x00000001, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FU_INST_EXECUTED,                    fermi_sm_odd0_fu_inst_executed_enc_str_1,                  0x0000009e, 0x00003210, 0x00000020, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FMA64_INST_EXECUTED,                 fermi_sm_odd0_fma64_inst_executed_enc_str_1,               0x0000009e, 0x00003210, 0x00000040, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_SU_INST_EXECUTED,                    fermi_sm_odd0_su_inst_executed_enc_str_1,                  0x0000009e, 0x00003210, 0x00000008, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_AGU_INST_EXECUTED,                   fermi_sm_odd0_agu_inst_executed_enc_str_1,                 0x0000009e, 0x00003210, 0x00000080, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_TEX_INST_EXECUTED,                   fermi_sm_odd0_tex_inst_executed_enc_str_1,                 0x0000009e, 0x00003210, 0x00000100, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_DSM_INST_EXECUTED,                   fermi_sm_odd0_dsm_inst_executed_enc_str_1,                 0x0000009e, 0x00003210, 0x00000200, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_SCH_INTERNAL_INST_EXECUTED,          fermi_sm_odd0_sch_internal_inst_executed_enc_str_1,        0x0000009e, 0x00003210, 0x00002000, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FE_INST_EXECUTED,                    fermi_sm_odd0_fe_inst_executed_enc_str_1,                  0x0000009e, 0x00003210, 0x00001000, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },

    { FERMI_SM_ODD1_ALU_ONLY_INST_EXECUTED,              fermi_sm_odd1_alu_only_inst_executed_enc_str_1,            0x0000009e, 0x00007654, 0x00000800, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_XLU_ONLY_INST_EXECUTED,              fermi_sm_odd1_xlu_only_inst_executed_enc_str_1,            0x0000009e, 0x00007654, 0x00000004, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_ALU_XLU_BIPIPE_INST_EXECUTED,        fermi_sm_odd1_alu_xlu_bipipe_inst_executed_enc_str_1,      0x0000009e, 0x00007654, 0x00000002, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FMALITE_ONLY_INST_EXECUTED,          fermi_sm_odd1_fmalite_only_inst_executed_enc_str_1,        0x0000009e, 0x00007654, 0x00000400, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FMA32_ONLY_INST_EXECUTED,            fermi_sm_odd1_fma32_only_inst_executed_enc_str_1,          0x0000009e, 0x00007654, 0x00000010, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FMALITE_FMA32_BIPIPE_INST_EXECUTED,  fermi_sm_odd1_fmalite_fma32_bipipe_inst_executed_enc_str_1,0x0000009e, 0x00007654, 0x00000001, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FU_INST_EXECUTED,                    fermi_sm_odd1_fu_inst_executed_enc_str_1,                  0x0000009e, 0x00007654, 0x00000020, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FMA64_INST_EXECUTED,                 fermi_sm_odd1_fma64_inst_executed_enc_str_1,               0x0000009e, 0x00007654, 0x00000040, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_SU_INST_EXECUTED,                    fermi_sm_odd1_su_inst_executed_enc_str_1,                  0x0000009e, 0x00007654, 0x00000008, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_AGU_INST_EXECUTED,                   fermi_sm_odd1_agu_inst_executed_enc_str_1,                 0x0000009e, 0x00007654, 0x00000080, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_TEX_INST_EXECUTED,                   fermi_sm_odd1_tex_inst_executed_enc_str_1,                 0x0000009e, 0x00007654, 0x00000100, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_DSM_INST_EXECUTED,                   fermi_sm_odd1_dsm_inst_executed_enc_str_1,                 0x0000009e, 0x00007654, 0x00000200, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_SCH_INTERNAL_INST_EXECUTED,          fermi_sm_odd1_sch_internal_inst_executed_enc_str_1,        0x0000009e, 0x00007654, 0x00002000, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FE_INST_EXECUTED,                    fermi_sm_odd1_fe_inst_executed_enc_str_1,                  0x0000009e, 0x00007654, 0x00001000, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },

    // sm_even_alu_only_inst_executed               Count ALU pipe only instructions decoded on the even side
    // sm_even_xlu_only_inst_executed               count XLU pipe only instructions decoded on the even side
    // sm_even_alu_xlu_bipipe_inst_executed         count ALU XLU bipipe instructions decoded on the even side
    // sm_even_fmalite_only_inst_executed           Count FMALite pipe instructions decoded on the even side
    // sm_even_fma32_only_inst_executed             count FMA32 only instruction decoded on the even side
    // sm_even_fmalite_fma32_bipipe_inst_executed   count FMALite FMA32 bipipe instruction decoded on the even side
    // sm_even_fu_inst_executed                     count FU pipe instruction decoded on the even side
    // sm_even_fma64_inst_executed                  count FMA64 pipe instruction decoded on the even side
    // sm_even_su_inst_executed                     count SU pipe instruction decoded on the even side
    // sm_even_agu_inst_executed                    count AGU pipe instruction decoded on the even side
    // sm_even_tex_inst_executed                    count TEX instruction decoded on the even side
    // sm_even_dsm_inst_executed                    count DSM pipe instruction decoded on the even side
    // sm_even_sch_internal_inst_executed           count SCH internal instruction decoded on the even side
    // sm_even_fe_inst_executed                     count FE pipe instruction decoded on the even side

    { FERMI_SM_EVEN0_ALU_ONLY_INST_EXECUTED,              fermi_sm_even0_alu_only_inst_executed_enc_str_1,            0x0000009d, 0x00003210, 0x00000800, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_XLU_ONLY_INST_EXECUTED,              fermi_sm_even0_xlu_only_inst_executed_enc_str_1,            0x0000009d, 0x00003210, 0x00000004, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_ALU_XLU_BIPIPE_INST_EXECUTED,        fermi_sm_even0_alu_xlu_bipipe_inst_executed_enc_str_1,      0x0000009d, 0x00003210, 0x00000002, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FMALITE_ONLY_INST_EXECUTED,          fermi_sm_even0_fmalite_only_inst_executed_enc_str_1,        0x0000009d, 0x00003210, 0x00000400, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FMA32_ONLY_INST_EXECUTED,            fermi_sm_even0_fma32_only_inst_executed_enc_str_1,          0x0000009d, 0x00003210, 0x00000010, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FMALITE_FMA32_BIPIPE_INST_EXECUTED,  fermi_sm_even0_fmalite_fma32_bipipe_inst_executed_enc_str_1,0x0000009d, 0x00003210, 0x00000001, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FU_INST_EXECUTED,                    fermi_sm_even0_fu_inst_executed_enc_str_1,                  0x0000009d, 0x00003210, 0x00000020, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FMA64_INST_EXECUTED,                 fermi_sm_even0_fma64_inst_executed_enc_str_1,               0x0000009d, 0x00003210, 0x00000040, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_SU_INST_EXECUTED,                    fermi_sm_even0_su_inst_executed_enc_str_1,                  0x0000009d, 0x00003210, 0x00000008, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_AGU_INST_EXECUTED,                   fermi_sm_even0_agu_inst_executed_enc_str_1,                 0x0000009d, 0x00003210, 0x00000080, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_TEX_INST_EXECUTED,                   fermi_sm_even0_tex_inst_executed_enc_str_1,                 0x0000009d, 0x00003210, 0x00000100, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_DSM_INST_EXECUTED,                   fermi_sm_even0_dsm_inst_executed_enc_str_1,                 0x0000009d, 0x00003210, 0x00000200, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_SCH_INTERNAL_INST_EXECUTED,          fermi_sm_even0_sch_internal_inst_executed_enc_str_1,        0x0000009d, 0x00003210, 0x00002000, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FE_INST_EXECUTED,                    fermi_sm_even0_fe_inst_executed_enc_str_1,                  0x0000009d, 0x00003210, 0x00001000, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },

    { FERMI_SM_EVEN1_ALU_ONLY_INST_EXECUTED,              fermi_sm_even1_alu_only_inst_executed_enc_str_1,            0x0000009d, 0x00007654, 0x00000800, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_XLU_ONLY_INST_EXECUTED,              fermi_sm_even1_xlu_only_inst_executed_enc_str_1,            0x0000009d, 0x00007654, 0x00000004, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_ALU_XLU_BIPIPE_INST_EXECUTED,        fermi_sm_even1_alu_xlu_bipipe_inst_executed_enc_str_1,      0x0000009d, 0x00007654, 0x00000002, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FMALITE_ONLY_INST_EXECUTED,          fermi_sm_even1_fmalite_only_inst_executed_enc_str_1,        0x0000009d, 0x00007654, 0x00000400, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FMA32_ONLY_INST_EXECUTED,            fermi_sm_even1_fma32_only_inst_executed_enc_str_1,          0x0000009d, 0x00007654, 0x00000010, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FMALITE_FMA32_BIPIPE_INST_EXECUTED,  fermi_sm_even1_fmalite_fma32_bipipe_inst_executed_enc_str_1,0x0000009d, 0x00007654, 0x00000001, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FU_INST_EXECUTED,                    fermi_sm_even1_fu_inst_executed_enc_str_1,                  0x0000009d, 0x00007654, 0x00000020, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FMA64_INST_EXECUTED,                 fermi_sm_even1_fma64_inst_executed_enc_str_1,               0x0000009d, 0x00007654, 0x00000040, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_SU_INST_EXECUTED,                    fermi_sm_even1_su_inst_executed_enc_str_1,                  0x0000009d, 0x00007654, 0x00000008, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_AGU_INST_EXECUTED,                   fermi_sm_even1_agu_inst_executed_enc_str_1,                 0x0000009d, 0x00007654, 0x00000080, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_TEX_INST_EXECUTED,                   fermi_sm_even1_tex_inst_executed_enc_str_1,                 0x0000009d, 0x00007654, 0x00000100, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_DSM_INST_EXECUTED,                   fermi_sm_even1_dsm_inst_executed_enc_str_1,                 0x0000009d, 0x00007654, 0x00000200, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_SCH_INTERNAL_INST_EXECUTED,          fermi_sm_even1_sch_internal_inst_executed_enc_str_1,        0x0000009d, 0x00007654, 0x00002000, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FE_INST_EXECUTED,                    fermi_sm_even1_fe_inst_executed_enc_str_1,                  0x0000009d, 0x00007654, 0x00001000, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },

    // sm_odd_alu_only_inst_issued                Count ALU pipe only instructions issued on the odd side
    // sm_odd_xlu_only_inst_issued                count XLU pipe only instructions issued on the odd side
    // sm_odd_alu_xlu_bipipe_inst_issued          count ALU XLU bipipe instructions issued on the odd side
    // sm_odd_fmalite_only_inst_issued            Count FMALite pipe instructions issued on the odd side
    // sm_odd_fma32_only_inst_issued              count FMA32 only instruction issued on the odd side
    // sm_odd_fmalite_fma32_bipipe_inst_issued    count FMALite FMA32 bipipe instruction issued on the odd side
    // sm_odd_fu_inst_issued                      count FU pipe instruction issued on the odd side
    // sm_odd_fma64_inst_issued                   count FMA64 pipe instruction issued on the odd side
    // sm_odd_su_inst_issued                      count SU pipe instruction issued on the odd side
    // sm_odd_agu_inst_issued                     count AGU pipe instruction issued on the odd side
    // sm_odd_tex_inst_issued                     count TEX instruction issued on the odd side
    // sm_odd_dsm_inst_issued                     count DSM pipe instruction issued on the odd side
    // sm_odd_sch_internal_inst_issued            count SCH internal instruction issued on the odd side
    // sm_odd_fe_inst_issued                      count FE pipe instruction issued on the odd side


    { FERMI_SM_ODD0_ALU_ONLY_INST_ISSUED,              fermi_sm_odd0_alu_only_inst_issued_enc_str_1,            0x000000a0, 0x00003210, 0x00000800, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_XLU_ONLY_INST_ISSUED,              fermi_sm_odd0_xlu_only_inst_issued_enc_str_1,            0x000000a0, 0x00003210, 0x00000004, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_ALU_XLU_BIPIPE_INST_ISSUED,        fermi_sm_odd0_alu_xlu_bipipe_inst_issued_enc_str_1,      0x000000a0, 0x00003210, 0x00000002, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FMALITE_ONLY_INST_ISSUED,          fermi_sm_odd0_fmalite_only_inst_issued_enc_str_1,        0x000000a0, 0x00003210, 0x00000400, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FMA32_ONLY_INST_ISSUED,            fermi_sm_odd0_fma32_only_inst_issued_enc_str_1,          0x000000a0, 0x00003210, 0x00000010, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FMALITE_FMA32_BIPIPE_INST_ISSUED,  fermi_sm_odd0_fmalite_fma32_bipipe_inst_issued_enc_str_1,0x000000a0, 0x00003210, 0x00000001, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FU_INST_ISSUED,                    fermi_sm_odd0_fu_inst_issued_enc_str_1,                  0x000000a0, 0x00003210, 0x00000020, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FMA64_INST_ISSUED,                 fermi_sm_odd0_fma64_inst_issued_enc_str_1,               0x000000a0, 0x00003210, 0x00000040, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_SU_INST_ISSUED,                    fermi_sm_odd0_su_inst_issued_enc_str_1,                  0x000000a0, 0x00003210, 0x00000008, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_AGU_INST_ISSUED,                   fermi_sm_odd0_agu_inst_issued_enc_str_1,                 0x000000a0, 0x00003210, 0x00000080, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_TEX_INST_ISSUED,                   fermi_sm_odd0_tex_inst_issued_enc_str_1,                 0x000000a0, 0x00003210, 0x00000100, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_DSM_INST_ISSUED,                   fermi_sm_odd0_dsm_inst_issued_enc_str_1,                 0x000000a0, 0x00003210, 0x00000200, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_SCH_INTERNAL_INST_ISSUED,          fermi_sm_odd0_sch_internal_inst_issued_enc_str_1,        0x000000a0, 0x00003210, 0x00002000, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FE_INST_ISSUED,                    fermi_sm_odd0_fe_inst_issued_enc_str_1,                  0x000000a0, 0x00003210, 0x00001000, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },

    { FERMI_SM_ODD1_ALU_ONLY_INST_ISSUED,              fermi_sm_odd1_alu_only_inst_issued_enc_str_1,            0x000000a0, 0x00007654, 0x00000800, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_XLU_ONLY_INST_ISSUED,              fermi_sm_odd1_xlu_only_inst_issued_enc_str_1,            0x000000a0, 0x00007654, 0x00000004, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_ALU_XLU_BIPIPE_INST_ISSUED,        fermi_sm_odd1_alu_xlu_bipipe_inst_issued_enc_str_1,      0x000000a0, 0x00007654, 0x00000002, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FMALITE_ONLY_INST_ISSUED,          fermi_sm_odd1_fmalite_only_inst_issued_enc_str_1,        0x000000a0, 0x00007654, 0x00000400, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FMA32_ONLY_INST_ISSUED,            fermi_sm_odd1_fma32_only_inst_issued_enc_str_1,          0x000000a0, 0x00007654, 0x00000010, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FMALITE_FMA32_BIPIPE_INST_ISSUED,  fermi_sm_odd1_fmalite_fma32_bipipe_inst_issued_enc_str_1,0x000000a0, 0x00007654, 0x00000001, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FU_INST_ISSUED,                    fermi_sm_odd1_fu_inst_issued_enc_str_1,                  0x000000a0, 0x00007654, 0x00000020, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FMA64_INST_ISSUED,                 fermi_sm_odd1_fma64_inst_issued_enc_str_1,               0x000000a0, 0x00007654, 0x00000040, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_SU_INST_ISSUED,                    fermi_sm_odd1_su_inst_issued_enc_str_1,                  0x000000a0, 0x00007654, 0x00000008, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_AGU_INST_ISSUED,                   fermi_sm_odd1_agu_inst_issued_enc_str_1,                 0x000000a0, 0x00007654, 0x00000080, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_TEX_INST_ISSUED,                   fermi_sm_odd1_tex_inst_issued_enc_str_1,                 0x000000a0, 0x00007654, 0x00000100, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_DSM_INST_ISSUED,                   fermi_sm_odd1_dsm_inst_issued_enc_str_1,                 0x000000a0, 0x00007654, 0x00000200, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_SCH_INTERNAL_INST_ISSUED,          fermi_sm_odd1_sch_internal_inst_issued_enc_str_1,        0x000000a0, 0x00007654, 0x00002000, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FE_INST_ISSUED,                    fermi_sm_odd1_fe_inst_issued_enc_str_1,                  0x000000a0, 0x00007654, 0x00001000, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },

    // sm_even_alu_only_inst_issued               Count ALU pipe only instructions issued on the even side
    // sm_even_xlu_only_inst_issued               count XLU pipe only instructions issued on the even side
    // sm_even_alu_xlu_bipipe_inst_issued         count ALU XLU bipipe instructions issued on the even side
    // sm_even_fmalite_only_inst_issued           Count FMALite pipe instructions issued on the even side
    // sm_even_fma32_only_inst_issued             count FMA32 only instruction issued on the even side
    // sm_even_fmalite_fma32_bipipe_inst_issued   count FMALite FMA32 bipipe instruction issued on the even side
    // sm_even_fu_inst_issued                     count FU pipe instruction issued on the even side
    // sm_even_fma64_inst_issued                  count FMA64 pipe instruction issued on the even side
    // sm_even_su_inst_issued                     count SU pipe instruction issued on the even side
    // sm_even_agu_inst_issued                    count AGU pipe instruction issued on the even side
    // sm_even_tex_inst_issued                    count TEX instruction issued on the even side
    // sm_even_dsm_inst_issued                    count DSM pipe instruction issued on the even side
    // sm_even_sch_internal_inst_issued           count SCH internal instruction issued on the even side
    // sm_even_fe_inst_issued                     count FE pipe instruction issued on the even side

    { FERMI_SM_EVEN0_ALU_ONLY_INST_ISSUED,              fermi_sm_even0_alu_only_inst_issued_enc_str_1,            0x0000009f, 0x00003210, 0x00000800, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_XLU_ONLY_INST_ISSUED,              fermi_sm_even0_xlu_only_inst_issued_enc_str_1,            0x0000009f, 0x00003210, 0x00000004, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_ALU_XLU_BIPIPE_INST_ISSUED,        fermi_sm_even0_alu_xlu_bipipe_inst_issued_enc_str_1,      0x0000009f, 0x00003210, 0x00000002, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FMALITE_ONLY_INST_ISSUED,          fermi_sm_even0_fmalite_only_inst_issued_enc_str_1,        0x0000009f, 0x00003210, 0x00000400, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FMA32_ONLY_INST_ISSUED,            fermi_sm_even0_fma32_only_inst_issued_enc_str_1,          0x0000009f, 0x00003210, 0x00000010, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FMALITE_FMA32_BIPIPE_INST_ISSUED,  fermi_sm_even0_fmalite_fma32_bipipe_inst_issued_enc_str_1,0x0000009f, 0x00003210, 0x00000001, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FU_INST_ISSUED,                    fermi_sm_even0_fu_inst_issued_enc_str_1,                  0x0000009f, 0x00003210, 0x00000020, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FMA64_INST_ISSUED,                 fermi_sm_even0_fma64_inst_issued_enc_str_1,               0x0000009f, 0x00003210, 0x00000040, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_SU_INST_ISSUED,                    fermi_sm_even0_su_inst_issued_enc_str_1,                  0x0000009f, 0x00003210, 0x00000008, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_AGU_INST_ISSUED,                   fermi_sm_even0_agu_inst_issued_enc_str_1,                 0x0000009f, 0x00003210, 0x00000080, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_TEX_INST_ISSUED,                   fermi_sm_even0_tex_inst_issued_enc_str_1,                 0x0000009f, 0x00003210, 0x00000100, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_DSM_INST_ISSUED,                   fermi_sm_even0_dsm_inst_issued_enc_str_1,                 0x0000009f, 0x00003210, 0x00000200, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_SCH_INTERNAL_INST_ISSUED,          fermi_sm_even0_sch_internal_inst_issued_enc_str_1,        0x0000009f, 0x00003210, 0x00002000, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FE_INST_ISSUED,                    fermi_sm_even0_fe_inst_issued_enc_str_1,                  0x0000009f, 0x00003210, 0x00001000, 0x34333231, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },

    { FERMI_SM_EVEN1_ALU_ONLY_INST_ISSUED,              fermi_sm_even1_alu_only_inst_issued_enc_str_1,            0x0000009f, 0x00007654, 0x00000800, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_XLU_ONLY_INST_ISSUED,              fermi_sm_even1_xlu_only_inst_issued_enc_str_1,            0x0000009f, 0x00007654, 0x00000004, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_ALU_XLU_BIPIPE_INST_ISSUED,        fermi_sm_even1_alu_xlu_bipipe_inst_issued_enc_str_1,      0x0000009f, 0x00007654, 0x00000002, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FMALITE_ONLY_INST_ISSUED,          fermi_sm_even1_fmalite_only_inst_issued_enc_str_1,        0x0000009f, 0x00007654, 0x00000400, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FMA32_ONLY_INST_ISSUED,            fermi_sm_even1_fma32_only_inst_issued_enc_str_1,          0x0000009f, 0x00007654, 0x00000010, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FMALITE_FMA32_BIPIPE_INST_ISSUED,  fermi_sm_even1_fmalite_fma32_bipipe_inst_issued_enc_str_1,0x0000009f, 0x00007654, 0x00000001, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FU_INST_ISSUED,                    fermi_sm_even1_fu_inst_issued_enc_str_1,                  0x0000009f, 0x00007654, 0x00000020, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FMA64_INST_ISSUED,                 fermi_sm_even1_fma64_inst_issued_enc_str_1,               0x0000009f, 0x00007654, 0x00000040, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_SU_INST_ISSUED,                    fermi_sm_even1_su_inst_issued_enc_str_1,                  0x0000009f, 0x00007654, 0x00000008, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_AGU_INST_ISSUED,                   fermi_sm_even1_agu_inst_issued_enc_str_1,                 0x0000009f, 0x00007654, 0x00000080, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_TEX_INST_ISSUED,                   fermi_sm_even1_tex_inst_issued_enc_str_1,                 0x0000009f, 0x00007654, 0x00000100, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_DSM_INST_ISSUED,                   fermi_sm_even1_dsm_inst_issued_enc_str_1,                 0x0000009f, 0x00007654, 0x00000200, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_SCH_INTERNAL_INST_ISSUED,          fermi_sm_even1_sch_internal_inst_issued_enc_str_1,        0x0000009f, 0x00007654, 0x00002000, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FE_INST_ISSUED,                    fermi_sm_even1_fe_inst_issued_enc_str_1,                  0x0000009f, 0x00007654, 0x00001000, 0x38373635, FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },


    // ****ACTIVE_WARPS***
    // sch_active_cycles                sch has at lest 1 active warp.
    // sch_active_warps                 number of active warps SM currently has
    //                                  i.e. Every cycle, increment this counter by the number of active warps
    //{ FERMI_SCH_ACTIVE_CYCLES,              "sch_active_cycles",        0x00000024, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ACTIVE_WARPS,                 fermi_sch_active_warps_enc_str_1,             0x00000024, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,1,1,1,1,1,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // sch_warp_issue_holes             number of warps not eligible to be issued this cycle
    //                                  i.e. Every cycle, increment this counter by the number of active warps that do not have an instruction eligible for issue due to warp only reasons.
    //                                  Warp only reason includes register scoreboard, 3 cycle reissue limit, no instruction in the SCH. If any warp only reason is true, the count is incremented regardless of any other ineligibility reason.
    { FERMI_SCH_WARP_ISSUE_HOLES,             fermi_sch_warp_issue_holes_enc_str_1,   0x00000027, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // sch_warp_issue_holes_long        number of warps not eligible to be issued for > 32 cycles
    //                                  i.e. similar to warp_issue_holes, but only count warps that have not been issue for at least 31 cycles.
    { FERMI_SCH_WARP_ISSUE_HOLES_LONG,        fermi_sch_warp_issue_holes_long_enc_str_1, 0x00000028,0x00000000,  0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // sch_warp_issue_eligible          number of warps eligible to be issued this cycle
    //                                  i.e. Every cycle, increment this counter by the number of warps eligible to issue. A warp is counted if it eligible for issue, even it is not ultimately selected.
    { FERMI_SCH_WARP_ISSUE_ELIGIBLE,          fermi_sch_warp_issue_eligible_enc_str_1,    0x00000029, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // fet_icc_miss                     FET: fetch resulted in an I$ miss
    //                                  i.e. count the number of cache new misses. Covered misses and miss fail are not counted.
    // fet_icc_hit                      FET: fetch resulted in an I$ hit
    //                                  i.e. count the number of cache hits
    { FERMI_FET_ICC_MISS,                     fermi_fet_icc_miss_enc_str_1,               0x00000014, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_ICC_HIT,                      fermi_fet_icc_hit_enc_str_1,                0x00000014, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // fet_any_active                   FET: has at least 1 active warp
    //                                  i.e. Count total number of cycles SM has at least one active warp, existing warp, not necessarily to be schedulable
    { FERMI_FET_ANY_ACTIVE,                   fermi_fet_any_active_enc_str_1,            0x00000011, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // sch_even_cant_issue_no_inst              SCH number of warps with no instructions in the IB
    // sch_even_cant_issue_interlock_long       SCH number of warps blocked on ld/st or scoreboard interlock > 32 clocks
    // sch_even_cant_issue_interlock_short      SCH number of warps blocked on ld/st or scoreboard interlock < 32 clocks
    // sch_even_cant_issue_reissue              SCH number of warps blocked by 3 cycle reissue limit
    // sch_even_cant_issue_dsm_q_full           SCH number of warps blocked by full dsm queue
    // sch_even_cant_issue_tex_q_full           SCH number of warps blocked by full dsm tex queue
    // sch_even_cant_issue_tex_req_table_full   SCH number of warps blocked by full tex_req table
    // sch_even_cant_issue_tile                 SCH number of warps blocked by tex_tile interlock
    // sch_even_cant_issue_tex_side             SCH number of warps blocked by tex even/odd arb
    // sch_even_cant_issue_issue_throttle       SCH number of warps blocked by shadow dsm throttling
    // sch_even_cant_issue_barrier              SCH number of warps blocked by barrier
    // sch_even_cant_issue_l1_sleep             SCH number of warps blocked by l1 deferral
    // sch_even_cant_issue_all                  SCH number of warps blocked by any reason

    { FERMI_SCH_EVEN_CANT_ISSUE_NO_INST,            fermi_sch_even_cant_issue_no_inst_enc_str_1,            0x0000003b, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_INTERLOCK_LONG,     fermi_sch_even_cant_issue_interlock_long_enc_str_1,     0x0000003c, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_INTERLOCK_SHORT,    fermi_sch_even_cant_issue_interlock_short_enc_str_1,    0x0000003d, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_REISSUE,            fermi_sch_even_cant_issue_reissue_enc_str_1,            0x0000003e, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_DSM_Q_FULL,         fermi_sch_even_cant_issue_dsm_q_full_enc_str_1,         0x0000003f, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_TEX_Q_FULL,         fermi_sch_even_cant_issue_tex_q_full_enc_str_1,         0x00000040, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_TEX_REQ_TABLE_FULL, fermi_sch_even_cant_issue_tex_req_table_full_enc_str_1, 0x00000041, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_TILE,               fermi_sch_even_cant_issue_tile_enc_str_1,               0x00000042, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_TEX_SIDE,           fermi_sch_even_cant_issue_tex_side_enc_str_1,           0x00000043, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_ISSUE_THROTTLE,     fermi_sch_even_cant_issue_issue_throttle_enc_str_1,     0x00000044, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_BARRIER,            fermi_sch_even_cant_issue_barrier_enc_str_1,            0x00000045, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_L1_SLEEP,           fermi_sch_even_cant_issue_l1_sleep_enc_str_1,           0x00000046, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_ALL,                fermi_sch_even_cant_issue_all_enc_str_1,                0x00000047, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    { FERMI_SCH_ODD_CANT_ISSUE_NO_INST,             fermi_sch_odd_cant_issue_no_inst_enc_str_1,             0x00000048, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_INTERLOCK_LONG,      fermi_sch_odd_cant_issue_interlock_long_enc_str_1,      0x00000049, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_INTERLOCK_SHORT,     fermi_sch_odd_cant_issue_interlock_short_enc_str_1,     0x0000004a, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_REISSUE,             fermi_sch_odd_cant_issue_reissue_enc_str_1,             0x0000004b, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_DSM_Q_FULL,          fermi_sch_odd_cant_issue_dsm_q_full_enc_str_1,          0x0000004c, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_TEX_Q_FULL,          fermi_sch_odd_cant_issue_tex_q_full_enc_str_1,          0x0000004d, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_TEX_REQ_TABLE_FULL,  fermi_sch_odd_cant_issue_tex_req_table_full_enc_str_1,  0x0000004e, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_TILE,                fermi_sch_odd_cant_issue_tile_enc_str_1,                0x0000004f, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_TEX_SIDE,            fermi_sch_odd_cant_issue_tex_side_enc_str_1,            0x00000050, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_ISSUE_THROTTLE,      fermi_sch_odd_cant_issue_issue_throttle_enc_str_1,      0x00000051, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_BARRIER,             fermi_sch_odd_cant_issue_barrier_enc_str_1,             0x00000052, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_L1_SLEEP,            fermi_sch_odd_cant_issue_l1_sleep_enc_str_1,            0x00000053, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_ALL,                 fermi_sch_odd_cant_issue_all_enc_str_1,                 0x00000054, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ***REPLAY REASONS***
    // sl_l1_deferred                   SL L1 had a defer (defer_mask != 0)
    //                                  i.e. total number of replays due to L1 deferral. cost not because of the program, but L1 design. counted in sl
    // sl_l1_divergent                  SL L1 instr had a replay due to divergence
    //                                  i.e. total number of replays due to memory address divergence. basically the extra cost you pay for your program pattern (serialization). counted in sl
    // sl_l1_replayed                   SL L1 instr replayed (due to divergence or defer)
    //                                  i.e. total number of memory instructions (instruction count) that are replayed (i.e. divergent or deferred). note: divergence and L1 deferral can happen for the same instruction. counted in sl
    // sch_even_imc_replay              sch got a replay request from imc
    // sch_odd_imc_replay               sch got a replay request from imc
    // sch_replay_others                SCH number of imc/idc miss or ipa replays
    // dsm_ipa_or_pixld_replay          DSM replay on an ipa or pixld instruction
    // agu_idc_replayed                 AGU indexed c$ access replayed
    //                                  i.e. total number of constant cache instructions that are replayed. counted in aguc

    // sm_even_imc_miss_replay          sm2pm_gpc_dsm_imc0_miss | sm2pm_gpc_dsm_imc0_match | sm2pm_gpc_dsm_imc0_full
    //                                  i.e. number of replays due to IMC miss
    // sm_odd_imc_miss_replay           sm2pm_gpc_dsm_imc1_miss | sm2pm_gpc_dsm_imc1_match | sm2pm_gpc_dsm_imc1_full
    //                                  i.e. number of replays due to IMC miss
    { FERMI_SL_L1_DEFERRED,                   fermi_sl_l1_deferred_enc_str_1,         0x0000006a, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SL_L1_DIVERGENT,                  fermi_sl_l1_divergent_enc_str_1,        0x0000006a, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SL_L1_REPLAYED,                   fermi_sl_l1_replayed_enc_str_1,         0x0000006a, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_DSM_EVEN_IMC_MISS_REPLAY,         fermi_dsm_even_imc_miss_replay_enc_str_1,0x00000062, 0x00000321, 0x0000FEFE,  0x343332,     FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },
    { FERMI_DSM_ODD_IMC_MISS_REPLAY,          fermi_dsm_odd_imc_miss_replay_enc_str_1, 0x00000062, 0x00000765, 0x0000FEFE,  0x383736,     FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,1,1}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },
    { FERMI_DSM_IPA_OR_PIXLD_REPLAY,          fermi_dsm_ipa_or_pixld_replay_enc_str_1,0x00000057, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_AGU_IDC_REPLAYED,                 fermi_agu_idc_replayed_enc_str_1,       0x00000068, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    { FERMI_SM_L1C_ATOM_COUNT,                    fermi_sm_l1c_atom_count_enc_str_1,         0x00000063, 0x00000003, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_L1C_GRED_COUNT,                    fermi_sm_l1c_gred_count_enc_str_1,         0x00000063, 0x00000004, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF104_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    { INVALID_PM_SIGNAL_NEW,            "",                       0xffffffff, 0x00000000, 0x00000000,  0x00,         FERMI_CLK_DOMAIN_MAX,           PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE }
};

PerfSignalTableNew PerfSignalTableGF104_ltc0[] = {
    //FBP signals
    //fb_subp*_read_sectors = pm_subp${subp}_dramc_read
    { FERMI_FB_SUBP0_DRAMC_READ,                          fermi_fb_subp0_dramc_read_enc_str_1,                        0x00000011, 0x00000000, 0x0000AAAA,  0x0000000f, FERMI_CLK_DOMAIN_GF104_LTC0,   PM_UNIT_FB,     {1,0,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB_SUBP1_DRAMC_READ,                          fermi_fb_subp1_dramc_read_enc_str_1,                        0x00000012, 0x00000000, 0x0000AAAA,  0x0000000f, FERMI_CLK_DOMAIN_GF104_LTC0,   PM_UNIT_FB,     {1,0,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    //fb_subp*_write_sectors = pm_subp${subp}_dramc_write
    { FERMI_FB_SUBP0_DRAMC_WRITE,                         fermi_fb_subp0_dramc_write_enc_str_1,                       0x00000011, 0x00000001, 0x0000AAAA,  0x00000010, FERMI_CLK_DOMAIN_GF104_LTC0,   PM_UNIT_FB,     {0,1,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB_SUBP1_DRAMC_WRITE,                         fermi_fb_subp1_dramc_write_enc_str_1,                       0x00000012, 0x00000001, 0x0000AAAA,  0x00000010, FERMI_CLK_DOMAIN_GF104_LTC0,   PM_UNIT_FB,     {0,1,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    //fb_subp*_write_activates = pm_subp${subp}_actarb_activate from spec file
    { FERMI_FB_SUBP0_DRAM_ACTIVATES,                     fermi_fb_subp0_dram_activates_enc_str_1,                          0x00000001, 0x00000006, 0x0000AAAA,  0x00000015, FERMI_CLK_DOMAIN_GF104_LTC0,   PM_UNIT_FB,     {0,0,0,0,0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB_SUBP1_DRAM_ACTIVATES,                     fermi_fb_subp1_dram_activates_enc_str_1,                          0x00000002, 0x00000006, 0x0000AAAA,  0x00000015, FERMI_CLK_DOMAIN_GF104_LTC0,   PM_UNIT_FB,     {0,0,0,0,0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },

    //LTC signals
    // l2_subp0_write_sector_misses = ltc_ltc2fb_dirty_dat0_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 0
    // l2_subp1_write_sector_misses = ltc_ltc2fb_dirty_dat1_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 1
    // l2_subp0_read_sector_misses  = ltc_fb2ltc_rdat0_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 0
    // l2_subp1_read_sector_misses  = ltc_fb2ltc_rdat1_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 1
    // l2_subp0_write_sector_queries = ltc2pm_ltc_lts0_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 0
    // l2_subp1_write_sector_queries = ltc2pm_ltc_lts1_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 1
    // l2_subp0_read_sector_queries  = ltc2pm_ltc_lts0_request_rd_op && ltc2pm_ltc_lts1_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 0
    // l2_subp1_read_sector_queries  = ltc2pm_ltc_lts1_request_rd_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 1

    { FERMI_LTC0_WRITE_MISS_SECTORS,  fermi_ltc0_write_miss_sectors_enc_str_1,    0x00000010, 0x00000004, 0x0000AAAA,  0x04,  FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC1,    {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP },
    { FERMI_LTC1_WRITE_MISS_SECTORS,  fermi_ltc1_write_miss_sectors_enc_str_1,    0x00000011, 0x00000004, 0x0000AAAA,  0x04,  FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC1,    {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP },
    { FERMI_LTC0_READ_MISS_SECTORS,   fermi_ltc0_read_miss_sectors_enc_str_1,     0x00000008, 0x00000000, 0x0000AAAA,  0x00,  FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC1,    {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP },
    { FERMI_LTC1_READ_MISS_SECTORS,   fermi_ltc1_read_miss_sectors_enc_str_1,     0x00000009, 0x00000000, 0x0000AAAA,  0x00,  FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC1,    {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP },

    //Event group mask is calculated from NV_PLTC_MISC_LTC_PM, excluding the PM_ENABLE bit
    //NV_PLTC_MISC_LTC_PM_SECTOR_MUX_SELECT : 0xe
    //NV_PLTC_MISC_LTC_PM_SELECT : 0x1F0
    //NV_PLTC_MISC_LTC_PM_SRCUNIT_MUX_SELECT : 0x3E00
    //NV_PLTC_MISC_LTC_PM_VC_SELECT : 0x70000
    //NV_PLTC_MISC_LTC_PM_SECTOR_COUNT_SELECT : 0x3000000
    //NV_PLTC_MISC_LTC_PM_LTS_MUX_SELECT : 0x20000000
    //Full mask: 0x23073FFE
    //Mask used for this expt: 0x20003E0E (only sector, srcunit amd lts group are used).

    //For this particular signal we have following groups
    //subp0
    //NV_PLTC_MISC_LTC_PM_SECTOR_MUX_SELECT : 0x0  : group 0
    //NV_PLTC_MISC_LTC_PM_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_SRCUNIT_MUX_SELECT : 0x1000  : src unit L1, group 8
    //NV_PLTC_MISC_LTC_PM_VC_SELECT : 0x00000
    //NV_PLTC_MISC_LTC_PM_SECTOR_COUNT_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_LTS_MUX_SELECT : 0x00000000  : group 0
    //Final value: 0x1000
    //subp1
    //NV_PLTC_MISC_LTC_PM_SECTOR_MUX_SELECT : 0x6  : group 3
    //NV_PLTC_MISC_LTC_PM_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_SRCUNIT_MUX_SELECT : 0x1200 : src unit L1, group 9
    //NV_PLTC_MISC_LTC_PM_VC_SELECT : 0x00000
    //NV_PLTC_MISC_LTC_PM_SECTOR_COUNT_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_LTS_MUX_SELECT : 0x20000000 : group 1
    //Final value: 0x20001206

    { FERMI_LTC0_WRITE_SECTORS_FBP,   fermi_ltc0_write_sectors_fbp_enc_str_1, 0x00000000, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x2e1f21, 0x00001000, 0x20003E0E},
    { FERMI_LTC1_WRITE_SECTORS_FBP,   fermi_ltc1_write_sectors_fbp_enc_str_1, 0x00000003, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x2e1f21, 0x20001206, 0x20003E0E},
    { FERMI_LTC0_READ_SECTORS_FBP,    fermi_ltc0_read_sectors_fbp_enc_str_1,  0x00000000, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x2f1f21, 0x00001000, 0x20003E0E},
    { FERMI_LTC1_READ_SECTORS_FBP,    fermi_ltc1_read_sectors_fbp_enc_str_1,  0x00000003, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x2f1f21, 0x20001206, 0x20003E0E},

    // l2_subp0_atomic_l1_sector_queries = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_atomic_op & ltc2pm_ltc_lts0_request_src_unit_l1
    { FERMI_LTC0_ATOMIC_L1_SECTORS_FBP,      fermi_ltc0_atomic_l1_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x212d1f, 0x00001000, 0x20003E0E},
    { FERMI_LTC1_ATOMIC_L1_SECTORS_FBP,      fermi_ltc1_atomic_l1_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x212d1f, 0x20001206, 0x20003E0E},

    //For this particular signal we have following groups
    //subp0
    //NV_PLTC_MISC_LTC_PM_SECTOR_MUX_SELECT : 0x0  : group 0
    //NV_PLTC_MISC_LTC_PM_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_SRCUNIT_MUX_SELECT : 0xC00  : src unit L1, group 6
    //NV_PLTC_MISC_LTC_PM_VC_SELECT : 0x00000
    //NV_PLTC_MISC_LTC_PM_SECTOR_COUNT_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_LTS_MUX_SELECT : 0x00000000  : group 0
    //Final value: 0xC00
    //subp1
    //NV_PLTC_MISC_LTC_PM_SECTOR_MUX_SELECT : 0x6  : group 3
    //NV_PLTC_MISC_LTC_PM_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_SRCUNIT_MUX_SELECT : 0xE00 : src unit L1, group 7
    //NV_PLTC_MISC_LTC_PM_VC_SELECT : 0x00000
    //NV_PLTC_MISC_LTC_PM_SECTOR_COUNT_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_LTS_MUX_SELECT : 0x20000000 : group 1
    //Final value: 0x20000E06

    { FERMI_LTC0_READ_TEX_SECTORS_FBP, fermi_ltc0_read_tex_sectors_fbp_enc_str_1,  0x00000000, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x2f1f21, 0x00000C00, 0x20003E0E},
    { FERMI_LTC1_READ_TEX_SECTORS_FBP, fermi_ltc1_read_tex_sectors_fbp_enc_str_1,  0x00000003, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x2f1f21, 0x20000E06, 0x20003E0E},

    { FERMI_LTC0_READ_CB_SECTORS_FBP,  fermi_ltc0_read_cb_sectors_fbp_enc_str_1,   0x00000000, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x2f2821, 0x00000000, 0x2000000E},
    { FERMI_LTC1_READ_CB_SECTORS_FBP,  fermi_ltc1_read_cb_sectors_fbp_enc_str_1,   0x00000003, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x2f2821, 0x20000006, 0x2000000E},
    { FERMI_LTC0_WRITE_CB_SECTORS_FBP, fermi_ltc0_write_cb_sectors_fbp_enc_str_1,  0x00000000, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x2e2821, 0x00000000, 0x2000000E},
    { FERMI_LTC1_WRITE_CB_SECTORS_FBP, fermi_ltc1_write_cb_sectors_fbp_enc_str_1,  0x00000003, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x2e2821, 0x20000006, 0x2000000E},

    { FERMI_LTC0_READ_HIT_SECTORS_FBP,     fermi_ltc0_read_hit_sectors_fbp_enc_str_1,      0x00000000, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008000,  0x212f1f02, 0x00001002, 0x20003FFE},
    { FERMI_LTC1_READ_HIT_SECTORS_FBP,     fermi_ltc1_read_hit_sectors_fbp_enc_str_1,      0x00000003, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008000,  0x212f1f02, 0x20001218, 0x20003EFE},
    { FERMI_LTC0_READ_TEX_HIT_SECTORS_FBP, fermi_ltc0_read_tex_hit_sectors_fbp_enc_str_1,  0x00000000, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008000,  0x212f1f02, 0x00000C02, 0x20003FFE},
    { FERMI_LTC1_READ_TEX_HIT_SECTORS_FBP, fermi_ltc1_read_tex_hit_sectors_fbp_enc_str_1,  0x00000003, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008000,  0x212f1f02, 0x20000E18, 0x20003EFE},
    { FERMI_LTC0_READ_CB_HIT_SECTORS_FBP,  fermi_ltc0_read_cb_hit_sectors_fbp_enc_str_1,   0x00000000, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008000,  0x212f2802, 0x00000002, 0x200001FE},
    { FERMI_LTC1_READ_CB_HIT_SECTORS_FBP,  fermi_ltc1_read_cb_hit_sectors_fbp_enc_str_1,   0x00000003, 0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008000,  0x212f2802, 0x20000018, 0x200001FE},

    // ltc_read_sysmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_sysmem
    { FERMI_LTC0_READ_SYSMEM_SECTORS_FBP,      fermi_ltc0_read_sysmem_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x00212f01, 0, 0x200001FE},
    { FERMI_LTC1_READ_SYSMEM_SECTORS_FBP,      fermi_ltc1_read_sysmem_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x00212f01, 0x20000016, 0x200001FE},

    // ltc_write_sysmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_sysmem
    { FERMI_LTC0_WRITE_SYSMEM_SECTORS_FBP,      fermi_ltc0_write_sysmem_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x00212e01, 0, 0x200001FE},
    { FERMI_LTC1_WRITE_SYSMEM_SECTORS_FBP,      fermi_ltc1_write_sysmem_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x00212e01, 0x20000016, 0x200001FE},

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { FERMI_LTC0_TOTAL_READ_SECTORS_FBP,      fermi_ltc0_total_read_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008888,  0x0000212f, 0, 0x2000000E},
    { FERMI_LTC1_TOTAL_READ_SECTORS_FBP,      fermi_ltc1_total_read_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008888,  0x0000212f, 0x20000006, 0x2000000E},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { FERMI_LTC0_TOTAL_WRITE_SECTORS_FBP,      fermi_ltc0_total_write_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008888,  0x0000212e, 0, 0x2000000E},
    { FERMI_LTC1_TOTAL_WRITE_SECTORS_FBP,      fermi_ltc1_total_write_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008888,  0x0000212e, 0x20000006, 0x2000000E},

    // ltc_read_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { FERMI_LTC0_READ_VIDMEM_SECTORS_FBP,      fermi_ltc0_read_vidmem_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x00212f00, 0x00000000, 0x200001FE},
    { FERMI_LTC1_READ_VIDMEM_SECTORS_FBP,      fermi_ltc1_read_vidmem_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x00212f00, 0x20000016, 0x200001FE},

    // ltc_write_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { FERMI_LTC0_WRITE_VIDMEM_SECTORS_FBP,      fermi_ltc0_write_vidmem_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x00212e00, 0x00000000, 0x200001FE},
    { FERMI_LTC1_WRITE_VIDMEM_SECTORS_FBP,      fermi_ltc1_write_vidmem_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0x1b,   FERMI_CLK_DOMAIN_GF104_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x00212e00, 0x20000016, 0x200001FE},

    { INVALID_PM_SIGNAL_NEW,                "",                 0xffffffff, 0x00000000, 0x00000000,  0x00,     FERMI_CLK_DOMAIN_MAX,     PM_UNIT_MAX,     {0,0,0,0,0,0,0,0},                 SIG_TYPE_SINGLE }
};

PerfSignalTableNew PerfSignalTableGF104_hub0[] = {
    //Hub TLB signals
    //__hub_tlb_hit        = hubmmu2pm_hub_hub_tlb_hit                                      count # of PTE hits in hub TLB
    //__hub_tlb_miss       = (hubmmu2pm_hub_hub_tlb_miss & !hubmmu2pm_hub_hub_tlb_hit)      count # of PTE misses in hub TLB
    { FERMI_MMU_HUB_TLB_HIT,    fermi_mmu_hub_tlb_hit_enc_str_1,    0x00000004,   0x00000000, 0x0000AAAA, 0x05,   FERMI_CLK_DOMAIN_GF104_HUB0,    PM_UNIT_HUBMMU,    {1,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_SYS },
    { FERMI_MMU_HUB_TLB_MISS,   fermi_mmu_hub_tlb_miss_enc_str_1,   0x00000004,   0x00000001, 0x00004444, 0x0605, FERMI_CLK_DOMAIN_GF104_HUB0,    PM_UNIT_HUBMMU,    {1,1,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_SYS },

    // mmu_fill_pte_hit    = hubmmu2pm_hub_fill_pte_hit                                     "count # of PTE hits in mmu fill unit"
    // mmu_fill_pte_miss   = (hubmmu2pm_hub_fill_pte_miss & !hubmmu2pm_hub_fill_pte_hit)    "count # of PTE misses in mmu fill unit"
    { FERMI_MMU_FILL_PTE_HIT,   fermi_mmu_fill_pte_hit_enc_str_1,   0x00000006,   0x00000000, 0x0000AAAA, 0x05,   FERMI_CLK_DOMAIN_GF104_HUB0,    PM_UNIT_HUBMMU,    {1,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_SYS },
    { FERMI_MMU_FILL_PTE_MISS,  fermi_mmu_fill_pte_miss_enc_str_1,  0x00000006,   0x00000010, 0x00004444, 0x0605, FERMI_CLK_DOMAIN_GF104_HUB0,    PM_UNIT_HUBMMU,    {1,1,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_SYS },

    // mmu_fill_pde_hit    = hubmmu2pm_hub_fill_pde_hit                                     "count # of PDE hits in mmu fill unit"
    // mmu_fill_pde_miss   = hubmmu2pm_hub_fill_pde_miss                                    "count # of PDE misses in mmu fill unit"
    { FERMI_MMU_FILL_PDE_HIT,   fermi_mmu_fill_pde_hit_enc_str_1,   0x00000006,   0x00000002, 0x0000AAAA, 0x07,   FERMI_CLK_DOMAIN_GF104_HUB0,    PM_UNIT_HUBMMU,    {0,0,1,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_SYS },
    { FERMI_MMU_FILL_PDE_MISS,  fermi_mmu_fill_pde_miss_enc_str_1,  0x00000006,   0x00000003, 0x0000AAAA, 0x08,   FERMI_CLK_DOMAIN_GF104_HUB0,    PM_UNIT_HUBMMU,    {0,0,0,1}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_SYS },

    //L2 TLB signals
    //__hub_gpcl2_tlb_hit  = hubmmu2pm_hub_gpcl2_tlb_hit                                    count # of PTE hits in gpcl2 TLB
    //__hub_gpcl2_tlb_miss = (hubmmu2pm_hub_gpcl2_tlb_miss & !hubmmu2pm_hub_gpcl2_tlb_hit)  count # of PTE misses in gpcl2 TLB
    { FERMI_MMU_GPCL2_TLB_HIT,        fermi_mmu_gpcl2_tlb_hit_enc_str_1,      0x00000003, 0x00000000, 0x0000AAAA,  0x05,  FERMI_CLK_DOMAIN_GF104_HUB0,    PM_UNIT_HUBMMU, {1,0,0,0},         SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_SYS },
    { FERMI_MMU_GPCL2_TLB_MISS,       fermi_mmu_gpcl2_tlb_miss_enc_str_1,     0x00000003, 0x00000001, 0x00004444,  0x0605,FERMI_CLK_DOMAIN_GF104_HUB0,    PM_UNIT_HUBMMU, {1,1,0,0},         SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_SYS },

    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000, 0x00000000,  0x00,         FERMI_CLK_DOMAIN_MAX,     PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE }
};

PerfSignalTableNew PerfSignalTableGF108_sm0[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type
    // ########### SM Unit ###########
    // ***LOAD/STORE***
    // agu_l1_local_ld                  AGU L1 LD is to local space (based on priority thread space)
    // agu_l1_global_ld                 AGU L1 LD is to global space (based on priority thread space)
    // agu_l1_local_st                  AGU L1 ST is to local space (based on priority thread space)
    // agu_l1_global_st                 AGU L1 ST is to global space (based on priority thread space)
    // agu_l1_shared_ld                 AGU L1 LD is to shared space (based on priority thread space)
    // agu_l1_shared_st                 AGU L1 ST is to shared space (based on priority thread space)
    { FERMI_AGU_L1_LOCAL_LD,                  fermi_agu_l1_local_ld_enc_str_1,               0x00000064, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_AGU_L1_LOCAL_ST,                  fermi_agu_l1_local_st_enc_str_1,              0x00000064, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_AGU_L1_GLOBAL_LD,                 fermi_agu_l1_global_ld_enc_str_1,              0x00000064, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_AGU_L1_GLOBAL_ST,                 fermi_agu_l1_global_st_enc_str_1,              0x00000064, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_AGU_L1_SHARED_LD,                 fermi_agu_l1_shared_ld_enc_str_1,              0x00000064, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_AGU_L1_SHARED_ST,                 fermi_agu_l1_shared_st_enc_str_1,             0x00000064, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

     // ***BRANCH***
    // fet_fetch_hit_vld                FET made fetch request for any warp (icache hit)
    // fet_fetch_flow_control           FET: one of the fetched inst(s) is a flow control inst
    // FERMI_FET_FETCH_BRANCH                 fet_fetch_hit_vld && fet_fetch_flow_control
    //{ FERMI_FET_FETCH_BRANCH,               "fet_fetch_branch",         "fet_fetch_branch",         0x00000012, 0x00000010, 0x00008888,  0x3231,       FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,0,0,0,0,0,0}, SIG_TYPE_MULTIPLE, PM_CHIPLET_TYPE_GPC },
    //{ FERMI_FET_FETCH_FLOW_CONTROL,         "fet_fetch_flow_control",   "fet_fetch_flow_control",   0x00000012, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    //{ FERMI_FET_FETCH_INST_COUNT,           "fet_fetch_inst_count",     "fet_fetch_inst_count",     0x00000012, 0x00000002, 0x0000AAAA,  0X33,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,1,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },

    // fet_unique_branches              FET: number of processed (SW) unique branches
    // fet_taken_branches               FET: number of processed (SW) unique (any thread) taken branches
    //                                  i.e. number of unique branches that have at least one thread taken
    { FERMI_FET_UNIQUE_BRANCHES,              fermi_fet_unique_branches_enc_str_1,                   0x0000001a, 0x00000010, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_TAKEN_BRANCHES,               fermi_fet_taken_branches_enc_str_1,     0x00000019, 0x00000010, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_UNIQUE_BRANCHES_0,            fermi_fet_unique_branches_0_enc_str_1,               0x0000001a, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_UNIQUE_BRANCHES_1,            fermi_fet_unique_branches_1_enc_str_1,               0x0000001a, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },

    // ***DIVERGENT BRANCHES***
    // fet_odd_unique_diverged_imm      FET: odd half processed a unique diverged non-indexed branch
    // fet_odd_unique_diverged_idx      FET: odd half processed a unique diverged indexed branch
    // fet_even_unique_diverged_imm     FET: even half processed a unique diverged non-indexed branch
    // fet_even_unique_diverged_idx     FET: even half processed a unique diverged indexed branch
    // FERMI_FET_ODD_UNIQUE_DIVERGED_BRA  =   fet_odd_unique_diverged_imm || fet_odd_unique_diverged_idx
    // FERMI_FET_EVEN_UNIQUE_DIVERGED_BRA =   fet_even_unique_diverged_imm || fet_even_unique_diverged_idx
    //{ FERMI_FET_ODD_UNIQUE_DIVERGED_BRA,    "fet_odd_unique_diverged_bra",  "fet_odd_unique_diverged_bra",      0x00000016, 0x00000054, 0x0000EEEE,  0x3635,       FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,0,0}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },
    //{ FERMI_FET_EVEN_UNIQUE_DIVERGED_BRA,   "fet_even_unique_diverged_bra", "fet_even_unique_diverged_bra",     0x00000018, 0x00000054, 0x0000EEEE,  0x3635,       FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,0,0}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },

    // fet_diverged_branches            FET: number of processed (SW) unique diverged branches
    // fet_odd_control_flow_stall       = sm2pm_gpc_fet_even_active & !sm2pm_gpc_fet_even_request & sm2pm_gpc_fet_even_all_branching
    // fet_even_control_flow_stall      = sm2pm_gpc_fet_odd_active & !sm2pm_gpc_fet_odd_request & sm2pm_gpc_fet_odd_all_branching
    //                                  When a side is not able to fetch and it is that side's turn to fetch and SCH can accept instructions (enough scoreboard and instruction buffer slots),
    //                                  increment by the number of warps which have enough InstructionBuffer/Scoreboard entries but can't fetch due to control flow

    { FERMI_FET_DIVERGED_BRANCHES,            fermi_fet_diverged_branches_enc_str_1,         0x00000019, 0x00000032, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,1,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_ODD_CONTROL_FLOW_STALL,       fermi_fet_odd_control_flow_stall_enc_str_1,  0x00000020, 0x00000014, 0x00002020,  0x313235,     FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,0,0,1,0,0,0}, SIG_TYPE_MULTIPLE,   PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_EVEN_CONTROL_FLOW_STALL,      fermi_fet_even_control_flow_stall_enc_str_1, 0x00000021, 0x00000014, 0x00002020,  0x313235,     FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,0,0,1,0,0,0}, SIG_TYPE_MULTIPLE,   PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_DIVERGED_BRANCHES_0,          fermi_fet_diverged_branches_0_enc_str_1,     0x00000019, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_DIVERGED_BRANCHES_1,          fermi_fet_diverged_branches_1_enc_str_1,     0x00000019, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },

    // ***REPLAY REASONS***
    // sl_l1_deferred                   SL L1 had a defer (defer_mask != 0)
    //                                  i.e. total number of replays due to L1 deferral. cost not because of the program, but L1 design. counted in sl
    // sl_l1_divergent                  SL L1 instr had a replay due to divergence
    //                                  i.e. total number of replays due to memory address divergence. basically the extra cost you pay for your program pattern (serialization). counted in sl
    // sl_l1_replayed                   SL L1 instr replayed (due to divergence or defer)
    //                                  i.e. total number of memory instructions (instruction count) that are replayed (i.e. divergent or deferred). note: divergence and L1 deferral can happen for the same instruction. counted in sl
    // sch_even_imc_replay              sch got a replay request from imc
    // sch_odd_imc_replay               sch got a replay request from imc
    // sch_replay_others                SCH number of imc/idc miss or ipa replays
    // dsm_ipa_or_pixld_replay          DSM replay on an ipa or pixld instruction
    // agu_idc_replayed                 AGU indexed c$ access replayed
    //                                  i.e. total number of constant cache instructions that are replayed. counted in aguc

    // sm_even_imc_miss_replay          sm2pm_gpc_dsm_imc0_miss | sm2pm_gpc_dsm_imc0_match | sm2pm_gpc_dsm_imc0_full
    //                                  i.e. number of replays due to IMC miss
    // sm_odd_imc_miss_replay           sm2pm_gpc_dsm_imc1_miss | sm2pm_gpc_dsm_imc1_match | sm2pm_gpc_dsm_imc1_full
    //                                  i.e. number of replays due to IMC miss
    { FERMI_SL_L1_DEFERRED,                   fermi_sl_l1_deferred_enc_str_1,         0x0000006a, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SL_L1_DIVERGENT,                  fermi_sl_l1_divergent_enc_str_1,        0x0000006a, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SL_L1_REPLAYED,                   fermi_sl_l1_replayed_enc_str_1,         0x0000006a, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_EVEN_IMC_REPLAY,            "__sch_even_imc_replay",    0x00000025, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_ODD_IMC_REPLAY,             "__sch_odd_imc_replay",     0x00000025, 0x00000007, 0x0000AAAA,  0x38,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,0,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_DSM_EVEN_IMC_MISS_REPLAY,         fermi_dsm_even_imc_miss_replay_enc_str_1,0x00000062, 0x00000321, 0x0000FEFE,  0x343332,     FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },
    { FERMI_DSM_ODD_IMC_MISS_REPLAY,          fermi_dsm_odd_imc_miss_replay_enc_str_1, 0x00000062, 0x00000765, 0x0000FEFE,  0x383736,     FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,1,1}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_REPLAY_OTHERS,              "__sch_replay_others",      0x0000002c, 0x00000076, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_DSM_IPA_OR_PIXLD_REPLAY,          fermi_dsm_ipa_or_pixld_replay_enc_str_1,0x00000057, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_AGU_IDC_REPLAYED,                 fermi_agu_idc_replayed_enc_str_1,       0x00000068, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ***LAUNCHED***
    // sch_warps_launched               SM has launched 1 warp
    // sch_threads_launched             number of threads SM launched this cycle
    { FERMI_SCH_WARPS_LAUNCHED,               fermi_sch_warps_launched_enc_str_1,           0x00000026, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_THREADS_LAUNCHED_0,           fermi_sch_threads_launched_0_enc_str_1,     0x00000026, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_THREADS_LAUNCHED_1,           fermi_sch_threads_launched_1_enc_str_1,     0x00000026, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_THREADS_LAUNCHED_2,           fermi_sch_threads_launched_2_enc_str_1,     0x00000026, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_THREADS_LAUNCHED_3,           fermi_sch_threads_launched_3_enc_str_1,     0x00000026, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_THREADS_LAUNCHED_4,           fermi_sch_threads_launched_4_enc_str_1,     0x00000026, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_THREADS_LAUNCHED_5,           fermi_sch_threads_launched_5_enc_str_1,     0x00000026, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_THREADS_LAUNCHED,             fermi_sch_threads_launched_enc_str_1,         0x00000026, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,1,1,1,1,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ****ACTIVE_WARPS***
    // sch_active_cycles                sch has at lest 1 active warp.
    // sch_active_warps                 number of active warps SM currently has
    //                                  i.e. Every cycle, increment this counter by the number of active warps
    //{ FERMI_SCH_ACTIVE_CYCLES,              "sch_active_cycles",        0x00000024, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ACTIVE_WARPS,                 fermi_sch_active_warps_enc_str_1,             0x00000024, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,1,1,1,1,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // sch_warp_issue_holes             number of warps not eligible to be issued this cycle
    //                                  i.e. Every cycle, increment this counter by the number of active warps that do not have an instruction eligible for issue due to warp only reasons.
    //                                  Warp only reason includes register scoreboard, 3 cycle reissue limit, no instruction in the SCH. If any warp only reason is true, the count is incremented regardless of any other ineligibility reason.
    { FERMI_SCH_WARP_ISSUE_HOLES,             fermi_sch_warp_issue_holes_enc_str_1,   0x00000027, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // sch_warp_issue_holes_long        number of warps not eligible to be issued for > 32 cycles
    //                                  i.e. similar to warp_issue_holes, but only count warps that have not been issue for at least 31 cycles.
    { FERMI_SCH_WARP_ISSUE_HOLES_LONG,        fermi_sch_warp_issue_holes_long_enc_str_1, 0x00000028,0x00000000,  0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // sch_warp_issue_eligible          number of warps eligible to be issued this cycle
    //                                  i.e. Every cycle, increment this counter by the number of warps eligible to issue. A warp is counted if it eligible for issue, even it is not ultimately selected.
    { FERMI_SCH_WARP_ISSUE_ELIGIBLE,          fermi_sch_warp_issue_eligible_enc_str_1,    0x00000029, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // fet_icc_miss                     FET: fetch resulted in an I$ miss
    //                                  i.e. count the number of cache new misses. Covered misses and miss fail are not counted.
    // fet_icc_hit                      FET: fetch resulted in an I$ hit
    //                                  i.e. count the number of cache hits    { FERMI_FET_ICC_MISS,                     "__fet_icc_miss",               0x00000014, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_ICC_MISS,                     fermi_fet_icc_miss_enc_str_1,               0x00000014, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_FET_ICC_HIT,                      fermi_fet_icc_hit_enc_str_1,                0x00000014, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // fet_any_active                   FET: has at least 1 active warp
    //                                  i.e. Count total number of cycles SM has at least one active warp, existing warp, not necessarily to be schedulable
    { FERMI_FET_ANY_ACTIVE,                   fermi_fet_any_active_enc_str_1,            0x00000011, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // sch_even_cant_issue_no_inst              SCH number of warps with no instructions in the IB
    // sch_even_cant_issue_interlock_long       SCH number of warps blocked on ld/st or scoreboard interlock > 32 clocks
    // sch_even_cant_issue_interlock_short      SCH number of warps blocked on ld/st or scoreboard interlock < 32 clocks
    // sch_even_cant_issue_reissue              SCH number of warps blocked by 3 cycle reissue limit
    // sch_even_cant_issue_dsm_q_full           SCH number of warps blocked by full dsm queue
    // sch_even_cant_issue_tex_q_full           SCH number of warps blocked by full dsm tex queue
    // sch_even_cant_issue_tex_req_table_full   SCH number of warps blocked by full tex_req table
    // sch_even_cant_issue_tile                 SCH number of warps blocked by tex_tile interlock
    // sch_even_cant_issue_tex_side             SCH number of warps blocked by tex even/odd arb
    // sch_even_cant_issue_issue_throttle       SCH number of warps blocked by shadow dsm throttling
    // sch_even_cant_issue_barrier              SCH number of warps blocked by barrier
    // sch_even_cant_issue_l1_sleep             SCH number of warps blocked by l1 deferral
    // sch_even_cant_issue_all                  SCH number of warps blocked by any reason

    { FERMI_SCH_EVEN_CANT_ISSUE_NO_INST,            fermi_sch_even_cant_issue_no_inst_enc_str_1,            0x0000003b, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_INTERLOCK_LONG,     fermi_sch_even_cant_issue_interlock_long_enc_str_1,     0x0000003c, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_INTERLOCK_SHORT,    fermi_sch_even_cant_issue_interlock_short_enc_str_1,    0x0000003d, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_REISSUE,            fermi_sch_even_cant_issue_reissue_enc_str_1,            0x0000003e, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_DSM_Q_FULL,         fermi_sch_even_cant_issue_dsm_q_full_enc_str_1,         0x0000003f, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_TEX_Q_FULL,         fermi_sch_even_cant_issue_tex_q_full_enc_str_1,         0x00000040, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_TEX_REQ_TABLE_FULL, fermi_sch_even_cant_issue_tex_req_table_full_enc_str_1, 0x00000041, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_TILE,               fermi_sch_even_cant_issue_tile_enc_str_1,               0x00000042, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_TEX_SIDE,           fermi_sch_even_cant_issue_tex_side_enc_str_1,           0x00000043, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_ISSUE_THROTTLE,     fermi_sch_even_cant_issue_issue_throttle_enc_str_1,     0x00000044, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_BARRIER,            fermi_sch_even_cant_issue_barrier_enc_str_1,            0x00000045, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_L1_SLEEP,           fermi_sch_even_cant_issue_l1_sleep_enc_str_1,           0x00000046, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_CANT_ISSUE_ALL,                fermi_sch_even_cant_issue_all_enc_str_1,                0x00000047, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    { FERMI_SCH_ODD_CANT_ISSUE_NO_INST,             fermi_sch_odd_cant_issue_no_inst_enc_str_1,             0x00000048, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_INTERLOCK_LONG,      fermi_sch_odd_cant_issue_interlock_long_enc_str_1,      0x00000049, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_INTERLOCK_SHORT,     fermi_sch_odd_cant_issue_interlock_short_enc_str_1,     0x0000004a, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_REISSUE,             fermi_sch_odd_cant_issue_reissue_enc_str_1,             0x0000004b, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_DSM_Q_FULL,          fermi_sch_odd_cant_issue_dsm_q_full_enc_str_1,          0x0000004c, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_TEX_Q_FULL,          fermi_sch_odd_cant_issue_tex_q_full_enc_str_1,          0x0000004d, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_TEX_REQ_TABLE_FULL,  fermi_sch_odd_cant_issue_tex_req_table_full_enc_str_1,  0x0000004e, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_TILE,                fermi_sch_odd_cant_issue_tile_enc_str_1,                0x0000004f, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_TEX_SIDE,            fermi_sch_odd_cant_issue_tex_side_enc_str_1,            0x00000050, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_ISSUE_THROTTLE,      fermi_sch_odd_cant_issue_issue_throttle_enc_str_1,      0x00000051, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_BARRIER,             fermi_sch_odd_cant_issue_barrier_enc_str_1,             0x00000052, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_L1_SLEEP,            fermi_sch_odd_cant_issue_l1_sleep_enc_str_1,            0x00000053, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_CANT_ISSUE_ALL,                 fermi_sch_odd_cant_issue_all_enc_str_1,                 0x00000054, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // NOP TRIGGERS
    // dsm_nop_trig_grp0                DSM: NOP trigger[7:0]
    // dsm_nop_trig_grp1                DSM: NOP trigger[15:8]
    { FERMI_NOP_TRIG_00,                      fermi_nop_trig_00_enc_str_1,          0x00000001, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_01,                      fermi_nop_trig_01_enc_str_1,          0x00000001, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_02,                      fermi_nop_trig_02_enc_str_1,          0x00000001, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_03,                      fermi_nop_trig_03_enc_str_1,          0x00000001, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_04,                      fermi_nop_trig_04_enc_str_1,          0x00000001, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_05,                      fermi_nop_trig_05_enc_str_1,          0x00000001, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_06,                      fermi_nop_trig_06_enc_str_1,          0x00000001, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_07,                      fermi_nop_trig_07_enc_str_1,          0x00000001, 0x00000007, 0x0000AAAA,  0x38,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,0,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_08,                      fermi_nop_trig_08_enc_str_1,            0x00000002, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_09,                      fermi_nop_trig_09_enc_str_1,            0x00000002, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_10,                      fermi_nop_trig_10_enc_str_1,            0x00000002, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_11,                      fermi_nop_trig_11_enc_str_1,            0x00000002, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_12,                      fermi_nop_trig_12_enc_str_1,            0x00000002, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_13,                      fermi_nop_trig_13_enc_str_1,            0x00000002, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_14,                      fermi_nop_trig_14_enc_str_1,            0x00000002, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_NOP_TRIG_15,                      fermi_nop_trig_15_enc_str_1,            0x00000002, 0x00000007, 0x0000AAAA,  0x38,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,0,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // sch_inst_decoded                 SCH insts decoded this cycle
    //                                  i.e. Count total number of instructions executed, do not count replay. It counts the number of instructions decoded in SCH
    { FERMI_SCH_INST_DECODED,         fermi_sch_inst_decoded_enc_str_1,            0x0000002d, 0x00000210, 0x0000AAAA,  0x31,  FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_INST_DECODED_0,       fermi_sch_inst_decoded_0_enc_str_1,        0x0000002d, 0x00000000, 0x0000AAAA,  0x31,  FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_INST_DECODED_1,       fermi_sch_inst_decoded_1_enc_str_1,        0x0000002d, 0x00000001, 0x0000AAAA,  0x32,  FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_INST_DECODED_2,       fermi_sch_inst_decoded_2_enc_str_1,        0x0000002d, 0x00000002, 0x0000AAAA,  0x33,  FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    //sch_even0_thread_inst_decoded      first poistion of even half threads decoded
    //sch_even1_thread_inst_decoded      second poistion of even half threads decoded
    //sch_odd0_thread_inst_decoded       first poistion of odd half threads decoded
    //sch_odd1_thread_inst_decoded       second poistion of odd half threads decoded
    //Count threads executed at first/second poistion of even/odd side, it is inst_executed at even/odd side multiplied by active mask, predicated off threads are also included.
    { FERMI_SCH_EVEN0_THREAD_INST_DECODED,     fermi_sch_even0_thread_inst_decoded_enc_str_1,0x000000a3, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN1_THREAD_INST_DECODED,     fermi_sch_even1_thread_inst_decoded_enc_str_1,0x000000a4, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD0_THREAD_INST_DECODED,      fermi_sch_odd0_thread_inst_decoded_enc_str_1, 0x000000a5, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD1_THREAD_INST_DECODED,      fermi_sch_odd1_thread_inst_decoded_enc_str_1, 0x000000a6, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // sch_even_inst_issued_1           1 instructions issued this clock
    // sch_even_inst_issued_2           2 instructions issued this clock
    // sch_odd_inst_issued_1            1 instructions issued this clock
    // sch_odd_inst_issued_2            2 instructions issued this clock
    { FERMI_SCH_EVEN_INST_ISSUED_1,   fermi_sch_even_inst_issued_1_enc_str_1, 0x0000007e, 0x00000001, 0x0000AAAA,  0x32,  FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_EVEN_INST_ISSUED_2,   fermi_sch_even_inst_issued_2_enc_str_1, 0x0000007e, 0x00000002, 0x0000AAAA,  0x33,  FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_INST_ISSUED_1,    fermi_sch_odd_inst_issued_1_enc_str_1,  0x0000007e, 0x00000004, 0x0000AAAA,  0x35,  FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SCH_ODD_INST_ISSUED_2,    fermi_sch_odd_inst_issued_2_enc_str_1,  0x0000007e, 0x00000005, 0x0000AAAA,  0x36,  FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    //sm_super_scalar_decoded1 = !sm2pm_gpc_fet_fetch_inst_count_1 & sm2pm_gpc_fet_fetch_inst_count_0
    //                          Count the number of cycles that SCH accepts/decodes one super-scalar-pair or singleton
    { FERMI_SUPER_SCALAR_DECODED1,    fermi_super_scalar_decoded1_enc_str_1,  0x00000012, 0x00000032, 0x00002222,  0x3433,  FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE, PM_CHIPLET_TYPE_GPC },
    //sm_super_scalar_decoded2 = sm2pm_gpc_fet_fetch_inst_count_1 & !sm2pm_gpc_fet_fetch_inst_count_0
    //                          Count the number of cycles that SCH accepts/decodes two super-scalar-pair or singleton
    { FERMI_SUPER_SCALAR_DECODED2,    fermi_super_scalar_decoded2_enc_str_1,  0x00000012, 0x00000032, 0x00004444,  0x3433,  FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE, PM_CHIPLET_TYPE_GPC },
    //sm_super_scalar_decoded = Count the number of super-scalar-pair or super-scalar-singleton that are decoded/accepted by SCH
    { FERMI_SUPER_SCALAR_DECODED,     fermi_super_scalar_decoded_enc_str_1,   0x00000012, 0x00000002, 0x0000FFFF,  0x33,    FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,1,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },

    // sm_odd_alu_only_inst_executed                Count ALU pipe only instructions decoded on the odd side
    // sm_odd_xlu_only_inst_executed                count XLU pipe only instructions decoded on the odd side
    // sm_odd_alu_xlu_bipipe_inst_executed          count ALU XLU bipipe instructions decoded on the odd side
    // sm_odd_fmalite_only_inst_executed            Count FMALite pipe instructions decoded on the odd side
    // sm_odd_fma32_only_inst_executed              count FMA32 only instruction decoded on the odd side
    // sm_odd_fmalite_fma32_bipipe_inst_executed    count FMALite FMA32 bipipe instruction decoded on the odd side
    // sm_odd_fu_inst_executed                      count FU pipe instruction decoded on the odd side
    // sm_odd_fma64_inst_executed                   count FMA64 pipe instruction decoded on the odd side
    // sm_odd_su_inst_executed                      count SU pipe instruction decoded on the odd side
    // sm_odd_agu_inst_executed                     count AGU pipe instruction decoded on the odd side
    // sm_odd_tex_inst_executed                     count TEX instruction decoded on the odd side
    // sm_odd_dsm_inst_executed                     count DSM pipe instruction decoded on the odd side
    // sm_odd_sch_internal_inst_executed            count SCH internal instruction decoded on the odd side
    // sm_odd_fe_inst_executed                      count FE pipe instruction decoded on the odd side


    { FERMI_SM_ODD0_ALU_ONLY_INST_EXECUTED,              fermi_sm_odd0_alu_only_inst_executed_enc_str_1,            0x0000009e, 0x00003210, 0x00000800, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_XLU_ONLY_INST_EXECUTED,              fermi_sm_odd0_xlu_only_inst_executed_enc_str_1,            0x0000009e, 0x00003210, 0x00000004, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_ALU_XLU_BIPIPE_INST_EXECUTED,        fermi_sm_odd0_alu_xlu_bipipe_inst_executed_enc_str_1,      0x0000009e, 0x00003210, 0x00000002, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FMALITE_ONLY_INST_EXECUTED,          fermi_sm_odd0_fmalite_only_inst_executed_enc_str_1,        0x0000009e, 0x00003210, 0x00000400, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FMA32_ONLY_INST_EXECUTED,            fermi_sm_odd0_fma32_only_inst_executed_enc_str_1,          0x0000009e, 0x00003210, 0x00000010, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FMALITE_FMA32_BIPIPE_INST_EXECUTED,  fermi_sm_odd0_fmalite_fma32_bipipe_inst_executed_enc_str_1,0x0000009e, 0x00003210, 0x00000001, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FU_INST_EXECUTED,                    fermi_sm_odd0_fu_inst_executed_enc_str_1,                  0x0000009e, 0x00003210, 0x00000020, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FMA64_INST_EXECUTED,                 fermi_sm_odd0_fma64_inst_executed_enc_str_1,               0x0000009e, 0x00003210, 0x00000040, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_SU_INST_EXECUTED,                    fermi_sm_odd0_su_inst_executed_enc_str_1,                  0x0000009e, 0x00003210, 0x00000008, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_AGU_INST_EXECUTED,                   fermi_sm_odd0_agu_inst_executed_enc_str_1,                 0x0000009e, 0x00003210, 0x00000080, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_TEX_INST_EXECUTED,                   fermi_sm_odd0_tex_inst_executed_enc_str_1,                 0x0000009e, 0x00003210, 0x00000100, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_DSM_INST_EXECUTED,                   fermi_sm_odd0_dsm_inst_executed_enc_str_1,                 0x0000009e, 0x00003210, 0x00000200, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_SCH_INTERNAL_INST_EXECUTED,          fermi_sm_odd0_sch_internal_inst_executed_enc_str_1,        0x0000009e, 0x00003210, 0x00002000, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FE_INST_EXECUTED,                    fermi_sm_odd0_fe_inst_executed_enc_str_1,                  0x0000009e, 0x00003210, 0x00001000, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },

    { FERMI_SM_ODD1_ALU_ONLY_INST_EXECUTED,              fermi_sm_odd1_alu_only_inst_executed_enc_str_1,            0x0000009e, 0x00007654, 0x00000800, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_XLU_ONLY_INST_EXECUTED,              fermi_sm_odd1_xlu_only_inst_executed_enc_str_1,            0x0000009e, 0x00007654, 0x00000004, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_ALU_XLU_BIPIPE_INST_EXECUTED,        fermi_sm_odd1_alu_xlu_bipipe_inst_executed_enc_str_1,      0x0000009e, 0x00007654, 0x00000002, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FMALITE_ONLY_INST_EXECUTED,          fermi_sm_odd1_fmalite_only_inst_executed_enc_str_1,        0x0000009e, 0x00007654, 0x00000400, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FMA32_ONLY_INST_EXECUTED,            fermi_sm_odd1_fma32_only_inst_executed_enc_str_1,          0x0000009e, 0x00007654, 0x00000010, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FMALITE_FMA32_BIPIPE_INST_EXECUTED,  fermi_sm_odd1_fmalite_fma32_bipipe_inst_executed_enc_str_1,0x0000009e, 0x00007654, 0x00000001, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FU_INST_EXECUTED,                    fermi_sm_odd1_fu_inst_executed_enc_str_1,                  0x0000009e, 0x00007654, 0x00000020, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FMA64_INST_EXECUTED,                 fermi_sm_odd1_fma64_inst_executed_enc_str_1,               0x0000009e, 0x00007654, 0x00000040, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_SU_INST_EXECUTED,                    fermi_sm_odd1_su_inst_executed_enc_str_1,                  0x0000009e, 0x00007654, 0x00000008, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_AGU_INST_EXECUTED,                   fermi_sm_odd1_agu_inst_executed_enc_str_1,                 0x0000009e, 0x00007654, 0x00000080, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_TEX_INST_EXECUTED,                   fermi_sm_odd1_tex_inst_executed_enc_str_1,                 0x0000009e, 0x00007654, 0x00000100, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_DSM_INST_EXECUTED,                   fermi_sm_odd1_dsm_inst_executed_enc_str_1,                 0x0000009e, 0x00007654, 0x00000200, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_SCH_INTERNAL_INST_EXECUTED,          fermi_sm_odd1_sch_internal_inst_executed_enc_str_1,        0x0000009e, 0x00007654, 0x00002000, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FE_INST_EXECUTED,                    fermi_sm_odd1_fe_inst_executed_enc_str_1,                  0x0000009e, 0x00007654, 0x00001000, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },

    // sm_even_alu_only_inst_executed               Count ALU pipe only instructions decoded on the even side
    // sm_even_xlu_only_inst_executed               count XLU pipe only instructions decoded on the even side
    // sm_even_alu_xlu_bipipe_inst_executed         count ALU XLU bipipe instructions decoded on the even side
    // sm_even_fmalite_only_inst_executed           Count FMALite pipe instructions decoded on the even side
    // sm_even_fma32_only_inst_executed             count FMA32 only instruction decoded on the even side
    // sm_even_fmalite_fma32_bipipe_inst_executed   count FMALite FMA32 bipipe instruction decoded on the even side
    // sm_even_fu_inst_executed                     count FU pipe instruction decoded on the even side
    // sm_even_fma64_inst_executed                  count FMA64 pipe instruction decoded on the even side
    // sm_even_su_inst_executed                     count SU pipe instruction decoded on the even side
    // sm_even_agu_inst_executed                    count AGU pipe instruction decoded on the even side
    // sm_even_tex_inst_executed                    count TEX instruction decoded on the even side
    // sm_even_dsm_inst_executed                    count DSM pipe instruction decoded on the even side
    // sm_even_sch_internal_inst_executed           count SCH internal instruction decoded on the even side
    // sm_even_fe_inst_executed                     count FE pipe instruction decoded on the even side

    { FERMI_SM_EVEN0_ALU_ONLY_INST_EXECUTED,              fermi_sm_even0_alu_only_inst_executed_enc_str_1,            0x0000009d, 0x00003210, 0x00000800, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_XLU_ONLY_INST_EXECUTED,              fermi_sm_even0_xlu_only_inst_executed_enc_str_1,            0x0000009d, 0x00003210, 0x00000004, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_ALU_XLU_BIPIPE_INST_EXECUTED,        fermi_sm_even0_alu_xlu_bipipe_inst_executed_enc_str_1,      0x0000009d, 0x00003210, 0x00000002, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FMALITE_ONLY_INST_EXECUTED,          fermi_sm_even0_fmalite_only_inst_executed_enc_str_1,        0x0000009d, 0x00003210, 0x00000400, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FMA32_ONLY_INST_EXECUTED,            fermi_sm_even0_fma32_only_inst_executed_enc_str_1,          0x0000009d, 0x00003210, 0x00000010, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FMALITE_FMA32_BIPIPE_INST_EXECUTED,  fermi_sm_even0_fmalite_fma32_bipipe_inst_executed_enc_str_1,0x0000009d, 0x00003210, 0x00000001, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FU_INST_EXECUTED,                    fermi_sm_even0_fu_inst_executed_enc_str_1,                  0x0000009d, 0x00003210, 0x00000020, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FMA64_INST_EXECUTED,                 fermi_sm_even0_fma64_inst_executed_enc_str_1,               0x0000009d, 0x00003210, 0x00000040, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_SU_INST_EXECUTED,                    fermi_sm_even0_su_inst_executed_enc_str_1,                  0x0000009d, 0x00003210, 0x00000008, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_AGU_INST_EXECUTED,                   fermi_sm_even0_agu_inst_executed_enc_str_1,                 0x0000009d, 0x00003210, 0x00000080, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_TEX_INST_EXECUTED,                   fermi_sm_even0_tex_inst_executed_enc_str_1,                 0x0000009d, 0x00003210, 0x00000100, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_DSM_INST_EXECUTED,                   fermi_sm_even0_dsm_inst_executed_enc_str_1,                 0x0000009d, 0x00003210, 0x00000200, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_SCH_INTERNAL_INST_EXECUTED,          fermi_sm_even0_sch_internal_inst_executed_enc_str_1,        0x0000009d, 0x00003210, 0x00002000, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FE_INST_EXECUTED,                    fermi_sm_even0_fe_inst_executed_enc_str_1,                  0x0000009d, 0x00003210, 0x00001000, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },

    { FERMI_SM_EVEN1_ALU_ONLY_INST_EXECUTED,              fermi_sm_even1_alu_only_inst_executed_enc_str_1,            0x0000009d, 0x00007654, 0x00000800, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_XLU_ONLY_INST_EXECUTED,              fermi_sm_even1_xlu_only_inst_executed_enc_str_1,            0x0000009d, 0x00007654, 0x00000004, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_ALU_XLU_BIPIPE_INST_EXECUTED,        fermi_sm_even1_alu_xlu_bipipe_inst_executed_enc_str_1,      0x0000009d, 0x00007654, 0x00000002, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FMALITE_ONLY_INST_EXECUTED,          fermi_sm_even1_fmalite_only_inst_executed_enc_str_1,        0x0000009d, 0x00007654, 0x00000400, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FMA32_ONLY_INST_EXECUTED,            fermi_sm_even1_fma32_only_inst_executed_enc_str_1,          0x0000009d, 0x00007654, 0x00000010, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FMALITE_FMA32_BIPIPE_INST_EXECUTED,  fermi_sm_even1_fmalite_fma32_bipipe_inst_executed_enc_str_1,0x0000009d, 0x00007654, 0x00000001, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FU_INST_EXECUTED,                    fermi_sm_even1_fu_inst_executed_enc_str_1,                  0x0000009d, 0x00007654, 0x00000020, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FMA64_INST_EXECUTED,                 fermi_sm_even1_fma64_inst_executed_enc_str_1,               0x0000009d, 0x00007654, 0x00000040, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_SU_INST_EXECUTED,                    fermi_sm_even1_su_inst_executed_enc_str_1,                  0x0000009d, 0x00007654, 0x00000008, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_AGU_INST_EXECUTED,                   fermi_sm_even1_agu_inst_executed_enc_str_1,                 0x0000009d, 0x00007654, 0x00000080, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_TEX_INST_EXECUTED,                   fermi_sm_even1_tex_inst_executed_enc_str_1,                 0x0000009d, 0x00007654, 0x00000100, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_DSM_INST_EXECUTED,                   fermi_sm_even1_dsm_inst_executed_enc_str_1,                 0x0000009d, 0x00007654, 0x00000200, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_SCH_INTERNAL_INST_EXECUTED,          fermi_sm_even1_sch_internal_inst_executed_enc_str_1,        0x0000009d, 0x00007654, 0x00002000, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FE_INST_EXECUTED,                    fermi_sm_even1_fe_inst_executed_enc_str_1,                  0x0000009d, 0x00007654, 0x00001000, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },

    // sm_odd_alu_only_inst_issued                Count ALU pipe only instructions issued on the odd side
    // sm_odd_xlu_only_inst_issued                count XLU pipe only instructions issued on the odd side
    // sm_odd_alu_xlu_bipipe_inst_issued          count ALU XLU bipipe instructions issued on the odd side
    // sm_odd_fmalite_only_inst_issued            Count FMALite pipe instructions issued on the odd side
    // sm_odd_fma32_only_inst_issued              count FMA32 only instruction issued on the odd side
    // sm_odd_fmalite_fma32_bipipe_inst_issued    count FMALite FMA32 bipipe instruction issued on the odd side
    // sm_odd_fu_inst_issued                      count FU pipe instruction issued on the odd side
    // sm_odd_fma64_inst_issued                   count FMA64 pipe instruction issued on the odd side
    // sm_odd_su_inst_issued                      count SU pipe instruction issued on the odd side
    // sm_odd_agu_inst_issued                     count AGU pipe instruction issued on the odd side
    // sm_odd_tex_inst_issued                     count TEX instruction issued on the odd side
    // sm_odd_dsm_inst_issued                     count DSM pipe instruction issued on the odd side
    // sm_odd_sch_internal_inst_issued            count SCH internal instruction issued on the odd side
    // sm_odd_fe_inst_issued                      count FE pipe instruction issued on the odd side


    { FERMI_SM_ODD0_ALU_ONLY_INST_ISSUED,              fermi_sm_odd0_alu_only_inst_issued_enc_str_1,            0x000000a0, 0x00003210, 0x00000800, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_XLU_ONLY_INST_ISSUED,              fermi_sm_odd0_xlu_only_inst_issued_enc_str_1,            0x000000a0, 0x00003210, 0x00000004, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_ALU_XLU_BIPIPE_INST_ISSUED,        fermi_sm_odd0_alu_xlu_bipipe_inst_issued_enc_str_1,      0x000000a0, 0x00003210, 0x00000002, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FMALITE_ONLY_INST_ISSUED,          fermi_sm_odd0_fmalite_only_inst_issued_enc_str_1,        0x000000a0, 0x00003210, 0x00000400, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FMA32_ONLY_INST_ISSUED,            fermi_sm_odd0_fma32_only_inst_issued_enc_str_1,          0x000000a0, 0x00003210, 0x00000010, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FMALITE_FMA32_BIPIPE_INST_ISSUED,  fermi_sm_odd0_fmalite_fma32_bipipe_inst_issued_enc_str_1,0x000000a0, 0x00003210, 0x00000001, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FU_INST_ISSUED,                    fermi_sm_odd0_fu_inst_issued_enc_str_1,                  0x000000a0, 0x00003210, 0x00000020, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FMA64_INST_ISSUED,                 fermi_sm_odd0_fma64_inst_issued_enc_str_1,               0x000000a0, 0x00003210, 0x00000040, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_SU_INST_ISSUED,                    fermi_sm_odd0_su_inst_issued_enc_str_1,                  0x000000a0, 0x00003210, 0x00000008, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_AGU_INST_ISSUED,                   fermi_sm_odd0_agu_inst_issued_enc_str_1,                 0x000000a0, 0x00003210, 0x00000080, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_TEX_INST_ISSUED,                   fermi_sm_odd0_tex_inst_issued_enc_str_1,                 0x000000a0, 0x00003210, 0x00000100, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_DSM_INST_ISSUED,                   fermi_sm_odd0_dsm_inst_issued_enc_str_1,                 0x000000a0, 0x00003210, 0x00000200, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_SCH_INTERNAL_INST_ISSUED,          fermi_sm_odd0_sch_internal_inst_issued_enc_str_1,        0x000000a0, 0x00003210, 0x00002000, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD0_FE_INST_ISSUED,                    fermi_sm_odd0_fe_inst_issued_enc_str_1,                  0x000000a0, 0x00003210, 0x00001000, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },

    { FERMI_SM_ODD1_ALU_ONLY_INST_ISSUED,              fermi_sm_odd1_alu_only_inst_issued_enc_str_1,            0x000000a0, 0x00007654, 0x00000800, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_XLU_ONLY_INST_ISSUED,              fermi_sm_odd1_xlu_only_inst_issued_enc_str_1,            0x000000a0, 0x00007654, 0x00000004, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_ALU_XLU_BIPIPE_INST_ISSUED,        fermi_sm_odd1_alu_xlu_bipipe_inst_issued_enc_str_1,      0x000000a0, 0x00007654, 0x00000002, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FMALITE_ONLY_INST_ISSUED,          fermi_sm_odd1_fmalite_only_inst_issued_enc_str_1,        0x000000a0, 0x00007654, 0x00000400, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FMA32_ONLY_INST_ISSUED,            fermi_sm_odd1_fma32_only_inst_issued_enc_str_1,          0x000000a0, 0x00007654, 0x00000010, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FMALITE_FMA32_BIPIPE_INST_ISSUED,  fermi_sm_odd1_fmalite_fma32_bipipe_inst_issued_enc_str_1,0x000000a0, 0x00007654, 0x00000001, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FU_INST_ISSUED,                    fermi_sm_odd1_fu_inst_issued_enc_str_1,                  0x000000a0, 0x00007654, 0x00000020, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FMA64_INST_ISSUED,                 fermi_sm_odd1_fma64_inst_issued_enc_str_1,               0x000000a0, 0x00007654, 0x00000040, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_SU_INST_ISSUED,                    fermi_sm_odd1_su_inst_issued_enc_str_1,                  0x000000a0, 0x00007654, 0x00000008, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_AGU_INST_ISSUED,                   fermi_sm_odd1_agu_inst_issued_enc_str_1,                 0x000000a0, 0x00007654, 0x00000080, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_TEX_INST_ISSUED,                   fermi_sm_odd1_tex_inst_issued_enc_str_1,                 0x000000a0, 0x00007654, 0x00000100, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_DSM_INST_ISSUED,                   fermi_sm_odd1_dsm_inst_issued_enc_str_1,                 0x000000a0, 0x00007654, 0x00000200, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_SCH_INTERNAL_INST_ISSUED,          fermi_sm_odd1_sch_internal_inst_issued_enc_str_1,        0x000000a0, 0x00007654, 0x00002000, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_ODD1_FE_INST_ISSUED,                    fermi_sm_odd1_fe_inst_issued_enc_str_1,                  0x000000a0, 0x00007654, 0x00001000, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },

    // sm_even_alu_only_inst_issued               Count ALU pipe only instructions issued on the even side
    // sm_even_xlu_only_inst_issued               count XLU pipe only instructions issued on the even side
    // sm_even_alu_xlu_bipipe_inst_issued         count ALU XLU bipipe instructions issued on the even side
    // sm_even_fmalite_only_inst_issued           Count FMALite pipe instructions issued on the even side
    // sm_even_fma32_only_inst_issued             count FMA32 only instruction issued on the even side
    // sm_even_fmalite_fma32_bipipe_inst_issued   count FMALite FMA32 bipipe instruction issued on the even side
    // sm_even_fu_inst_issued                     count FU pipe instruction issued on the even side
    // sm_even_fma64_inst_issued                  count FMA64 pipe instruction issued on the even side
    // sm_even_su_inst_issued                     count SU pipe instruction issued on the even side
    // sm_even_agu_inst_issued                    count AGU pipe instruction issued on the even side
    // sm_even_tex_inst_issued                    count TEX instruction issued on the even side
    // sm_even_dsm_inst_issued                    count DSM pipe instruction issued on the even side
    // sm_even_sch_internal_inst_issued           count SCH internal instruction issued on the even side
    // sm_even_fe_inst_issued                     count FE pipe instruction issued on the even side

    { FERMI_SM_EVEN0_ALU_ONLY_INST_ISSUED,              fermi_sm_even0_alu_only_inst_issued_enc_str_1,            0x0000009f, 0x00003210, 0x00000800, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_XLU_ONLY_INST_ISSUED,              fermi_sm_even0_xlu_only_inst_issued_enc_str_1,            0x0000009f, 0x00003210, 0x00000004, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_ALU_XLU_BIPIPE_INST_ISSUED,        fermi_sm_even0_alu_xlu_bipipe_inst_issued_enc_str_1,      0x0000009f, 0x00003210, 0x00000002, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FMALITE_ONLY_INST_ISSUED,          fermi_sm_even0_fmalite_only_inst_issued_enc_str_1,        0x0000009f, 0x00003210, 0x00000400, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FMA32_ONLY_INST_ISSUED,            fermi_sm_even0_fma32_only_inst_issued_enc_str_1,          0x0000009f, 0x00003210, 0x00000010, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FMALITE_FMA32_BIPIPE_INST_ISSUED,  fermi_sm_even0_fmalite_fma32_bipipe_inst_issued_enc_str_1,0x0000009f, 0x00003210, 0x00000001, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FU_INST_ISSUED,                    fermi_sm_even0_fu_inst_issued_enc_str_1,                  0x0000009f, 0x00003210, 0x00000020, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FMA64_INST_ISSUED,                 fermi_sm_even0_fma64_inst_issued_enc_str_1,               0x0000009f, 0x00003210, 0x00000040, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_SU_INST_ISSUED,                    fermi_sm_even0_su_inst_issued_enc_str_1,                  0x0000009f, 0x00003210, 0x00000008, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_AGU_INST_ISSUED,                   fermi_sm_even0_agu_inst_issued_enc_str_1,                 0x0000009f, 0x00003210, 0x00000080, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_TEX_INST_ISSUED,                   fermi_sm_even0_tex_inst_issued_enc_str_1,                 0x0000009f, 0x00003210, 0x00000100, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_DSM_INST_ISSUED,                   fermi_sm_even0_dsm_inst_issued_enc_str_1,                 0x0000009f, 0x00003210, 0x00000200, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_SCH_INTERNAL_INST_ISSUED,          fermi_sm_even0_sch_internal_inst_issued_enc_str_1,        0x0000009f, 0x00003210, 0x00002000, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN0_FE_INST_ISSUED,                    fermi_sm_even0_fe_inst_issued_enc_str_1,                  0x0000009f, 0x00003210, 0x00001000, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },

    { FERMI_SM_EVEN1_ALU_ONLY_INST_ISSUED,              fermi_sm_even1_alu_only_inst_issued_enc_str_1,            0x0000009f, 0x00007654, 0x00000800, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_XLU_ONLY_INST_ISSUED,              fermi_sm_even1_xlu_only_inst_issued_enc_str_1,            0x0000009f, 0x00007654, 0x00000004, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_ALU_XLU_BIPIPE_INST_ISSUED,        fermi_sm_even1_alu_xlu_bipipe_inst_issued_enc_str_1,      0x0000009f, 0x00007654, 0x00000002, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FMALITE_ONLY_INST_ISSUED,          fermi_sm_even1_fmalite_only_inst_issued_enc_str_1,        0x0000009f, 0x00007654, 0x00000400, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FMA32_ONLY_INST_ISSUED,            fermi_sm_even1_fma32_only_inst_issued_enc_str_1,          0x0000009f, 0x00007654, 0x00000010, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FMALITE_FMA32_BIPIPE_INST_ISSUED,  fermi_sm_even1_fmalite_fma32_bipipe_inst_issued_enc_str_1,0x0000009f, 0x00007654, 0x00000001, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FU_INST_ISSUED,                    fermi_sm_even1_fu_inst_issued_enc_str_1,                  0x0000009f, 0x00007654, 0x00000020, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FMA64_INST_ISSUED,                 fermi_sm_even1_fma64_inst_issued_enc_str_1,               0x0000009f, 0x00007654, 0x00000040, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_SU_INST_ISSUED,                    fermi_sm_even1_su_inst_issued_enc_str_1,                  0x0000009f, 0x00007654, 0x00000008, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_AGU_INST_ISSUED,                   fermi_sm_even1_agu_inst_issued_enc_str_1,                 0x0000009f, 0x00007654, 0x00000080, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_TEX_INST_ISSUED,                   fermi_sm_even1_tex_inst_issued_enc_str_1,                 0x0000009f, 0x00007654, 0x00000100, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_DSM_INST_ISSUED,                   fermi_sm_even1_dsm_inst_issued_enc_str_1,                 0x0000009f, 0x00007654, 0x00000200, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_SCH_INTERNAL_INST_ISSUED,          fermi_sm_even1_sch_internal_inst_issued_enc_str_1,        0x0000009f, 0x00007654, 0x00002000, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_EVEN1_FE_INST_ISSUED,                    fermi_sm_even1_fe_inst_issued_enc_str_1,                  0x0000009f, 0x00007654, 0x00001000, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },

    { FERMI_SM_L1C_ATOM_COUNT,                    fermi_sm_l1c_atom_count_enc_str_1,         0x00000063, 0x00000003, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_SM_L1C_GRED_COUNT,                    fermi_sm_l1c_gred_count_enc_str_1,         0x00000063, 0x00000004, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    { INVALID_PM_SIGNAL_NEW,                "",                 0xffffffff, 0x00000000, 0x00000000,  0x00,     FERMI_CLK_DOMAIN_MAX,     PM_UNIT_MAX,     {0,0,0,0,0,0,0,0},                 SIG_TYPE_SINGLE }
};

PerfSignalTableNew PerfSignalTableGF108_gpc0[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type
    // ########### SM Unit ###########
    // ***LOAD/STORE***
    // agu_l1_local_ld                  AGU L1 LD is to local space (based on priority thread space)
    // agu_l1_global_ld                 AGU L1 LD is to global space (based on priority thread space)
    // agu_l1_local_st                  AGU L1 ST is to local space (based on priority thread space)
    // agu_l1_global_st                 AGU L1 ST is to global space (based on priority thread space)
    // agu_l1_shared_ld                 AGU L1 LD is to shared space (based on priority thread space)
    // agu_l1_shared_st                 AGU L1 ST is to shared space (based on priority thread space)
#ifdef SMPM
    { HWPM_FERMI_AGU_L1_LOCAL_LD,                  hwpm_fermi_agu_l1_local_ld_enc_str_1,               0x00000064, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_AGU_L1_LOCAL_ST,                  hwpm_fermi_agu_l1_local_st_enc_str_1,              0x00000064, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_AGU_L1_GLOBAL_LD,                 hwpm_fermi_agu_l1_global_ld_enc_str_1,              0x00000064, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_AGU_L1_GLOBAL_ST,                 hwpm_fermi_agu_l1_global_st_enc_str_1,              0x00000064, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_AGU_L1_SHARED_LD,                 hwpm_fermi_agu_l1_shared_ld_enc_str_1,              0x00000064, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_AGU_L1_SHARED_ST,                 hwpm_fermi_agu_l1_shared_st_enc_str_1,             0x00000064, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ***BRANCH***
    // fet_fetch_hit_vld                FET made fetch request for any warp (icache hit)
    // fet_fetch_flow_control           FET: one of the fetched inst(s) is a flow control inst
    // FERMI_FET_FETCH_BRANCH                 fet_fetch_hit_vld && fet_fetch_flow_control
    //{ FERMI_FET_FETCH_BRANCH,               "fet_fetch_branch",         "fet_fetch_branch",         0x00000012, 0x00000010, 0x00008888,  0x3231,       FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,0,0,0,0,0,0}, SIG_TYPE_MULTIPLE, PM_CHIPLET_TYPE_GPC },
    //{ FERMI_FET_FETCH_FLOW_CONTROL,         "fet_fetch_flow_control",   "fet_fetch_flow_control",   0x00000012, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    //{ FERMI_FET_FETCH_INST_COUNT,           "fet_fetch_inst_count",     "fet_fetch_inst_count",     0x00000012, 0x00000002, 0x0000AAAA,  0X33,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,1,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },

    // fet_unique_branches              FET: number of processed (SW) unique branches
    // fet_taken_branches               FET: number of processed (SW) unique (any thread) taken branches
    //                                  i.e. number of unique branches that have at least one thread taken
    { HWPM_FERMI_FET_UNIQUE_BRANCHES,              hwpm_fermi_fet_unique_branches_enc_str_1,                   0x0000001a, 0x00000010, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_FET_TAKEN_BRANCHES,               hwpm_fermi_fet_taken_branches_enc_str_1,     0x00000019, 0x00000010, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },

    // ***DIVERGENT BRANCHES***
    // fet_odd_unique_diverged_imm      FET: odd half processed a unique diverged non-indexed branch
    // fet_odd_unique_diverged_idx      FET: odd half processed a unique diverged indexed branch
    // fet_even_unique_diverged_imm     FET: even half processed a unique diverged non-indexed branch
    // fet_even_unique_diverged_idx     FET: even half processed a unique diverged indexed branch
    // FERMI_FET_ODD_UNIQUE_DIVERGED_BRA  =   fet_odd_unique_diverged_imm || fet_odd_unique_diverged_idx
    // FERMI_FET_EVEN_UNIQUE_DIVERGED_BRA =   fet_even_unique_diverged_imm || fet_even_unique_diverged_idx
    //{ FERMI_FET_ODD_UNIQUE_DIVERGED_BRA,    "fet_odd_unique_diverged_bra",  "fet_odd_unique_diverged_bra",      0x00000016, 0x00000054, 0x0000EEEE,  0x3635,       FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,0,0}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },
    //{ FERMI_FET_EVEN_UNIQUE_DIVERGED_BRA,   "fet_even_unique_diverged_bra", "fet_even_unique_diverged_bra",     0x00000018, 0x00000054, 0x0000EEEE,  0x3635,       FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,0,0}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },

    // fet_diverged_branches            FET: number of processed (SW) unique diverged branches
    // fet_odd_control_flow_stall       = sm2pm_gpc_fet_even_active & !sm2pm_gpc_fet_even_request & sm2pm_gpc_fet_even_all_branching
    // fet_even_control_flow_stall      = sm2pm_gpc_fet_odd_active & !sm2pm_gpc_fet_odd_request & sm2pm_gpc_fet_odd_all_branching
    //                                  When a side is not able to fetch and it is that side's turn to fetch and SCH can accept instructions (enough scoreboard and instruction buffer slots),
    //                                  increment by the number of warps which have enough InstructionBuffer/Scoreboard entries but can't fetch due to control flow

    { HWPM_FERMI_FET_DIVERGED_BRANCHES,            hwpm_fermi_fet_diverged_branches_enc_str_1,         0x00000019, 0x00000032, 0x0000FFFF,  0x33,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,1,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_FET_ODD_CONTROL_FLOW_STALL,       hwpm_fermi_fet_odd_control_flow_stall_enc_str_1,  0x00000020, 0x00000014, 0x00002020,  0x313235,     FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,0,0,1,0,0,0}, SIG_TYPE_MULTIPLE,   PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_FET_EVEN_CONTROL_FLOW_STALL,      hwpm_fermi_fet_even_control_flow_stall_enc_str_1, 0x00000021, 0x00000014, 0x00002020,  0x313235,     FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,0,0,1,0,0,0}, SIG_TYPE_MULTIPLE,   PM_CHIPLET_TYPE_GPC },

    // ***INSTRUCTIONS***
    // sch_odd_issue                    SCH odd half issued an instruction
    // sch_even_issue                   SCH even half issued an instruction
    //{ FERMI_SCH_ODD_ISSUE,                  "sch_odd_issue",            "sch_odd_issue",            0x0000002c, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_EVEN_ISSUE,                 "sch_even_issue",           "sch_even_issue",           0x0000002c, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_EVEN_THREAD_INST_DECODED,   "sch_even_thread_inst_decoded","sch_even_thread_inst_decoded",  0x0000002f, 0x00543210, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_ODD_THREAD_INST_DECODED,    "sch_odd_thread_inst_decoded", "sch_odd_thread_inst_decoded",   0x00000030, 0x00543210, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ***REPLAY REASONS***
    // sl_l1_deferred                   SL L1 had a defer (defer_mask != 0)
    //                                  i.e. total number of replays due to L1 deferral. cost not because of the program, but L1 design. counted in sl
    // sl_l1_divergent                  SL L1 instr had a replay due to divergence
    //                                  i.e. total number of replays due to memory address divergence. basically the extra cost you pay for your program pattern (serialization). counted in sl
    // sl_l1_replayed                   SL L1 instr replayed (due to divergence or defer)
    //                                  i.e. total number of memory instructions (instruction count) that are replayed (i.e. divergent or deferred). note: divergence and L1 deferral can happen for the same instruction. counted in sl
    // sch_even_imc_replay              sch got a replay request from imc
    // sch_odd_imc_replay               sch got a replay request from imc
    // sch_replay_others                SCH number of imc/idc miss or ipa replays
    // dsm_ipa_or_pixld_replay          DSM replay on an ipa or pixld instruction
    // agu_idc_replayed                 AGU indexed c$ access replayed
    //                                  i.e. total number of constant cache instructions that are replayed. counted in aguc

    // sm_even_imc_miss_replay          sm2pm_gpc_dsm_imc0_miss | sm2pm_gpc_dsm_imc0_match | sm2pm_gpc_dsm_imc0_full
    //                                  i.e. number of replays due to IMC miss
    // sm_odd_imc_miss_replay           sm2pm_gpc_dsm_imc1_miss | sm2pm_gpc_dsm_imc1_match | sm2pm_gpc_dsm_imc1_full
    //                                  i.e. number of replays due to IMC miss
    { HWPM_FERMI_SL_L1_DEFERRED,                   hwpm_fermi_sl_l1_deferred_enc_str_1,         0x0000006a, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SL_L1_DIVERGENT,                  hwpm_fermi_sl_l1_divergent_enc_str_1,        0x0000006a, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SL_L1_REPLAYED,                   hwpm_fermi_sl_l1_replayed_enc_str_1,         0x0000006a, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_EVEN_IMC_REPLAY,            "__sch_even_imc_replay",    0x00000025, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_ODD_IMC_REPLAY,             "__sch_odd_imc_replay",     0x00000025, 0x00000007, 0x0000AAAA,  0x38,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,0,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_DSM_EVEN_IMC_MISS_REPLAY,         fermi_dsm_even_imc_miss_replay_enc_str_4,0x00000062, 0x00000321, 0x0000FEFE,  0x343332,     FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },
    { FERMI_DSM_ODD_IMC_MISS_REPLAY,          fermi_dsm_odd_imc_miss_replay_enc_str_4, 0x00000062, 0x00000765, 0x0000FEFE,  0x383736,     FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,1,1}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },
    //{ FERMI_SCH_REPLAY_OTHERS,              "__sch_replay_others",      0x0000002c, 0x00000076, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_DSM_IPA_OR_PIXLD_REPLAY,          hwpm_fermi_dsm_ipa_or_pixld_replay_enc_str_1,0x00000057, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_AGU_IDC_REPLAYED,                 hwpm_fermi_agu_idc_replayed_enc_str_1,       0x00000068, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ***LAUNCHED***
    // sch_warps_launched               SM has launched 1 warp
    // sch_threads_launched             number of threads SM launched this cycle
    { HWPM_FERMI_SCH_WARPS_LAUNCHED,               hwpm_fermi_sch_warps_launched_enc_str_1,           0x00000026, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_THREADS_LAUNCHED,             hwpm_fermi_sch_threads_launched_enc_str_1,         0x00000026, 0x00000001, 0x0000FFFF,  0x32,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,1,1,1,1,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ****ACTIVE_WARPS***
    // sch_active_cycles                sch has at lest 1 active warp.
    // sch_active_warps                 number of active warps SM currently has
    //                                  i.e. Every cycle, increment this counter by the number of active warps
    //{ FERMI_SCH_ACTIVE_CYCLES,              "sch_active_cycles",        0x00000024, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ACTIVE_WARPS,                 hwpm_fermi_sch_active_warps_enc_str_1,             0x00000024, 0x00000001, 0x0000FFFF,  0x32,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,1,1,1,1,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // sch_warp_issue_holes             number of warps not eligible to be issued this cycle
    //                                  i.e. Every cycle, increment this counter by the number of active warps that do not have an instruction eligible for issue due to warp only reasons.
    //                                  Warp only reason includes register scoreboard, 3 cycle reissue limit, no instruction in the SCH. If any warp only reason is true, the count is incremented regardless of any other ineligibility reason.
    { HWPM_FERMI_SCH_WARP_ISSUE_HOLES,             hwpm_fermi_sch_warp_issue_holes_enc_str_1,   0x00000027, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // sch_warp_issue_holes_long        number of warps not eligible to be issued for > 32 cycles
    //                                  i.e. similar to warp_issue_holes, but only count warps that have not been issue for at least 31 cycles.
    { HWPM_FERMI_SCH_WARP_ISSUE_HOLES_LONG,        hwpm_fermi_sch_warp_issue_holes_long_enc_str_1, 0x00000028,0x00000000,  0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // sch_warp_issue_eligible          number of warps eligible to be issued this cycle
    //                                  i.e. Every cycle, increment this counter by the number of warps eligible to issue. A warp is counted if it eligible for issue, even it is not ultimately selected.
    { HWPM_FERMI_SCH_WARP_ISSUE_ELIGIBLE,          hwpm_fermi_sch_warp_issue_eligible_enc_str_1,    0x00000029, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // fet_icc_miss                     FET: fetch resulted in an I$ miss
    //                                  i.e. count the number of cache new misses. Covered misses and miss fail are not counted.
    // fet_icc_hit                      FET: fetch resulted in an I$ hit
    //                                  i.e. count the number of cache hits
    { HWPM_FERMI_FET_ICC_MISS,                     hwpm_fermi_fet_icc_miss_enc_str_1,               0x00000014, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_FET_ICC_HIT,                      hwpm_fermi_fet_icc_hit_enc_str_1,                0x00000014, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    // fet_any_active                   FET: has at least 1 active warp
    //                                  i.e. Count total number of cycles SM has at least one active warp, existing warp, not necessarily to be schedulable
    { HWPM_FERMI_FET_ANY_ACTIVE,                   hwpm_fermi_fet_any_active_enc_str_1,            0x00000011, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // sch_even_cant_issue_no_inst              SCH number of warps with no instructions in the IB
    // sch_even_cant_issue_interlock_long       SCH number of warps blocked on ld/st or scoreboard interlock > 32 clocks
    // sch_even_cant_issue_interlock_short      SCH number of warps blocked on ld/st or scoreboard interlock < 32 clocks
    // sch_even_cant_issue_reissue              SCH number of warps blocked by 3 cycle reissue limit
    // sch_even_cant_issue_dsm_q_full           SCH number of warps blocked by full dsm queue
    // sch_even_cant_issue_barrier              SCH number of warps blocked by barrier
    // sch_even_cant_issue_l1_sleep             SCH number of warps blocked by l1 deferral
    // sch_even_cant_issue_all                  SCH number of warps blocked by any reason

    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_NO_INST,          hwpm_fermi_sch_even_cant_issue_no_inst_enc_str_1,        0x0000003b, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_INTERLOCK_LONG,   hwpm_fermi_sch_even_cant_issue_interlock_long_enc_str_1, 0x0000003c, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_INTERLOCK_SHORT,  hwpm_fermi_sch_even_cant_issue_interlock_short_enc_str_1,0x0000003d, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_REISSUE,          hwpm_fermi_sch_even_cant_issue_reissue_enc_str_1,        0x0000003e, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_DSM_Q_FULL,       hwpm_fermi_sch_even_cant_issue_dsm_q_full_enc_str_1,     0x0000003f, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_TEX_SIDE,         hwpm_fermi_sch_even_cant_issue_tex_side_enc_str_1,       0x00000043, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_BARRIER,          hwpm_fermi_sch_even_cant_issue_barrier_enc_str_1,        0x00000045, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_L1_SLEEP,         hwpm_fermi_sch_even_cant_issue_l1_sleep_enc_str_1,       0x00000046, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_CANT_ISSUE_ALL,              hwpm_fermi_sch_even_cant_issue_all_enc_str_1,            0x00000047, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_NO_INST,           hwpm_fermi_sch_odd_cant_issue_no_inst_enc_str_1,         0x00000048, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_INTERLOCK_LONG,    hwpm_fermi_sch_odd_cant_issue_interlock_long_enc_str_1,  0x00000049, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_INTERLOCK_SHORT,   hwpm_fermi_sch_odd_cant_issue_interlock_short_enc_str_1, 0x0000004a, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_REISSUE,           hwpm_fermi_sch_odd_cant_issue_reissue_enc_str_1,         0x0000004b, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_DSM_Q_FULL,        hwpm_fermi_sch_odd_cant_issue_dsm_q_full_enc_str_1,      0x0000004c, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_TEX_SIDE,          hwpm_fermi_sch_odd_cant_issue_tex_side_enc_str_1,        0x00000050, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_BARRIER,           hwpm_fermi_sch_odd_cant_issue_barrier_enc_str_1,         0x00000052, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_L1_SLEEP,          hwpm_fermi_sch_odd_cant_issue_l1_sleep_enc_str_1,        0x00000053, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_CANT_ISSUE_ALL,               hwpm_fermi_sch_odd_cant_issue_all_enc_str_1,             0x00000054, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
#endif

    // ########### MPC Unit ###########
    // mpc_total_CTAs_launched          Total number of CTAs launched by this MPC
    { FERMI_MPC_TOTAL_CTAS_LAUNCHED,          fermi_mpc_total_ctas_launched_enc_str_1,          0x0000000e, 0x00000006, 0x0000AAAA,  0x26,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_MPC,    {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ########### L1 Cache (L1C) Unit ###########
    // local_load_hit                   local load hit (includes LinkAs)
    // local_load_miss                  local load miss(includes LinkBs)
    // local_store_hit                  local store hit
    // local_store_miss                 local store miss
    // global_load_hit                  global load hit
    // global_load_miss                 global load miss (only cached global loads that miss)
    // uncached_global_load             uncached global load count. Increments by 1 for each 32bit word.
    // global_store                     global store - always uncached. Increments by 1 for each 32bit word.
    { FERMI_L1C_SHARED_LOAD_TRANSACTIONS,     fermi_l1c_shared_load_transactions_enc_str_1, 0x00000000, 0x00000000, 0x0000AAAA,  0x0,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_L1C,    {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_SHARED_STORE_TRANSACTIONS,    fermi_l1c_shared_store_transactions_enc_str_1,0x00000000, 0x00000001, 0x0000AAAA,  0x1,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_L1C,    {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_LOCAL_LOAD_HIT,               fermi_l1c_local_load_hit_enc_str_1,          0x00000001, 0x00000000, 0x0000AAAA,  0x0,          FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_L1C,    {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_LOCAL_LOAD_MISS,              fermi_l1c_local_load_miss_enc_str_1,         0x00000001, 0x00000001, 0x0000AAAA,  0x1,          FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_L1C,    {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_LOCAL_STORE_HIT,              fermi_l1c_local_store_hit_enc_str_1,         0x00000001, 0x00000002, 0x0000AAAA,  0x2,          FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_L1C,    {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_LOCAL_STORE_MISS,             fermi_l1c_local_store_miss_enc_str_1,        0x00000001, 0x00000003, 0x0000AAAA,  0x3,          FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_L1C,    {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_PARTIAL_LOCAL_STORE_MISS,     fermi_l1c_partial_local_store_miss_enc_str_1,0x00000001, 0x00000043, 0x00008888,  0x0403,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_L1C,    {0,0,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,  PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_GLOBAL_LOAD_HIT,              fermi_l1c_global_load_hit_enc_str_1,         0x00000001, 0x00000005, 0x0000AAAA,  0x5,          FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_L1C,    {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_GLOBAL_LOAD_MISS,             fermi_l1c_global_load_miss_enc_str_1,        0x00000001, 0x00000006, 0x0000AAAA,  0x6,          FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_L1C,    {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DIRTY_LINE_EVICTION,          fermi_l1c_dirty_line_eviction_enc_str_1,     0x00000001, 0x00000007, 0x0000AAAA,  0x7,          FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_L1C,    {0,0,0,0,0,0,0,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_UNCACHED_GLOBAL_LOAD,         fermi_l1c_uncached_global_load_enc_str_1, 0x00000002, 0x00000002, 0x0000AAAA,  0x2,          FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_L1C,    {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_GLOBAL_STORE,                 fermi_l1c_global_store_enc_str_1,         0x00000002, 0x00000003, 0x0000AAAA,  0x3,          FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_L1C,    {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // ***DEFER REASONS***
    // defer_prt_full                   PRT is full
    //                                  i.e. count number of L1 PRT full deferral
    // defer_gni_stall                  GNI backpressures L1
    //                                  i.e. count number of deferes due to GNI backpressure (t2m fifo full) L1
    // defer_no_allocatable_cline       all ways are not allocatable
    //                                  i.e. count number of defers due to all lines in the same set having pending operations
    // defer_shared_bank_conflict       shared load/store bank conflict (>1 address within same bank accessed)
    // defer_store_bank_collision       Counts global atom/red memory conflicts (where multiple threads from a warp are writing into same memory-word)
    // defer_prt_load_limit             PRT reached load limit
    //                                  i.e. count number of times L1 had to defer cached loads because it reached PRT load limit
    // defer_prt_store_limit            PRT reached store limit
    //                                  i.e. count number of times L1 had to defer cached stores because it reached PRT store limit
    // defer_uncached_load_limit        reached max # uncached LDs to same set
    //                                  i.e. count number of times L1 is deferred because max number of uncached LD to the same set is reached
    { FERMI_L1C_DEFER_PRT_FULL,               fermi_l1c_defer_prt_full_enc_str_1,             0x00000005, 0x00000004, 0x0000AAAA,  0x04,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_L1C,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DEFER_GNI_STALL,              fermi_l1c_defer_gni_stall_enc_str_1,            0x00000005, 0x00000005, 0x0000AAAA,  0x05,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_L1C,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DEFER_NO_ALLOCATABLE_CLINE,   fermi_l1c_defer_no_allocatable_cline_enc_str_1, 0x00000005, 0x00000006, 0x0000AAAA,  0x06,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_L1C,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DEFER_SHARED_BANK_CONFLICT,   fermi_l1c_defer_shared_bank_conflict_enc_str_1,          0x00000006, 0x00000000, 0x0000AAAA,  0x00,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_L1C,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DEFER_STORE_BANK_COLLISION,   fermi_l1c_defer_store_bank_collision_enc_str_1, 0x00000006, 0x00000001, 0x0000AAAA,  0x01,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_L1C,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DEFER_PRT_LOAD_LIMIT,         fermi_l1c_defer_prt_load_limit_enc_str_1,       0x00000006, 0x00000003, 0x0000AAAA,  0x03,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_L1C,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DEFER_PRT_STORE_LIMIT,        fermi_l1c_defer_prt_store_limit_enc_str_1,      0x00000006, 0x00000004, 0x0000AAAA,  0x04,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_L1C,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
    { FERMI_L1C_DEFER_UNCACHED_LOAD_LIMIT,    fermi_l1c_defer_uncached_load_limit_enc_str_1,  0x00000006, 0x00000005, 0x0000AAAA,  0x05,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_L1C,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,     PM_CHIPLET_TYPE_GPC },
#ifdef PMSM
    // NOP TRIGGERS
    // dsm_nop_trig_grp0                DSM: NOP trigger[7:0]
    // dsm_nop_trig_grp1                DSM: NOP trigger[15:8]
    { HWPM_FERMI_NOP_TRIG_00,                      hwpm_fermi_nop_trig_00_enc_str_1,          0x00000001, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_01,                      hwpm_fermi_nop_trig_01_enc_str_1,          0x00000001, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_02,                      hwpm_fermi_nop_trig_02_enc_str_1,          0x00000001, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_03,                      hwpm_fermi_nop_trig_03_enc_str_1,          0x00000001, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_04,                      hwpm_fermi_nop_trig_04_enc_str_1,          0x00000001, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_05,                      hwpm_fermi_nop_trig_05_enc_str_1,          0x00000001, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_06,                      hwpm_fermi_nop_trig_06_enc_str_1,          0x00000001, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_07,                      hwpm_fermi_nop_trig_07_enc_str_1,          0x00000001, 0x00000007, 0x0000AAAA,  0x38,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,0,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_08,                      hwpm_fermi_nop_trig_08_enc_str_1,            0x00000002, 0x00000000, 0x0000AAAA,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_09,                      hwpm_fermi_nop_trig_09_enc_str_1,            0x00000002, 0x00000001, 0x0000AAAA,  0x32,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_10,                      hwpm_fermi_nop_trig_10_enc_str_1,            0x00000002, 0x00000002, 0x0000AAAA,  0x33,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_11,                      hwpm_fermi_nop_trig_11_enc_str_1,            0x00000002, 0x00000003, 0x0000AAAA,  0x34,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,1,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_12,                      hwpm_fermi_nop_trig_12_enc_str_1,            0x00000002, 0x00000004, 0x0000AAAA,  0x35,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_13,                      hwpm_fermi_nop_trig_13_enc_str_1,            0x00000002, 0x00000005, 0x0000AAAA,  0x36,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_14,                      hwpm_fermi_nop_trig_14_enc_str_1,            0x00000002, 0x00000006, 0x0000AAAA,  0x37,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,1,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_NOP_TRIG_15,                      hwpm_fermi_nop_trig_15_enc_str_1,            0x00000002, 0x00000007, 0x0000AAAA,  0x38,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,0,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // sch_inst_decoded                 SCH insts decoded this cycle
    //                                  i.e. Count total number of instructions executed, do not count replay. It counts the number of instructions decoded in SCH
    { HWPM_FERMI_SCH_INST_DECODED,         hwpm_fermi_sch_inst_decoded_enc_str_1,            0x0000002d, 0x00000210, 0x0000FFFF,  0x31,  FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_INST_DECODED_0,       hwpm_fermi_sch_inst_decoded_0_enc_str_1,        0x0000002d, 0x00000000, 0x0000AAAA,  0x31,  FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_INST_DECODED_1,       hwpm_fermi_sch_inst_decoded_1_enc_str_1,        0x0000002d, 0x00000001, 0x0000AAAA,  0x32,  FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_INST_DECODED_2,       hwpm_fermi_sch_inst_decoded_2_enc_str_1,        0x0000002d, 0x00000002, 0x0000AAAA,  0x33,  FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    //sch_even0_thread_inst_decoded      first poistion of even half threads decoded
    //sch_even1_thread_inst_decoded      second poistion of even half threads decoded
    //sch_odd0_thread_inst_decoded       first poistion of odd half threads decoded
    //sch_odd1_thread_inst_decoded       second poistion of odd half threads decoded
    //Count threads executed at first/second poistion of even/odd side, it is inst_executed at even/odd side multiplied by active mask, predicated off threads are also included.
    { HWPM_FERMI_SCH_EVEN0_THREAD_INST_DECODED,     hwpm_fermi_sch_even0_thread_inst_decoded_enc_str_1,0x000000a3, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN1_THREAD_INST_DECODED,     hwpm_fermi_sch_even1_thread_inst_decoded_enc_str_1,0x000000a4, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD0_THREAD_INST_DECODED,      hwpm_fermi_sch_odd0_thread_inst_decoded_enc_str_1, 0x000000a5, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD1_THREAD_INST_DECODED,      hwpm_fermi_sch_odd1_thread_inst_decoded_enc_str_1, 0x000000a6, 0x00000000, 0x0000FFFF,  0x31,         FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,1,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    // sch_even_inst_issued_1           1 instructions issued this clock
    // sch_even_inst_issued_2           2 instructions issued this clock
    // sch_odd_inst_issued_1            1 instructions issued this clock
    // sch_odd_inst_issued_2            2 instructions issued this clock
    { HWPM_FERMI_SCH_EVEN_INST_ISSUED_1,   hwpm_fermi_sch_even_inst_issued_1_enc_str_1, 0x0000007e, 0x00000001, 0x0000AAAA,  0x32,  FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,1,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_EVEN_INST_ISSUED_2,   hwpm_fermi_sch_even_inst_issued_2_enc_str_1, 0x0000007e, 0x00000002, 0x0000AAAA,  0x33,  FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_INST_ISSUED_1,    hwpm_fermi_sch_odd_inst_issued_1_enc_str_1,  0x0000007e, 0x00000004, 0x0000AAAA,  0x35,  FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SCH_ODD_INST_ISSUED_2,    hwpm_fermi_sch_odd_inst_issued_2_enc_str_1,  0x0000007e, 0x00000005, 0x0000AAAA,  0x36,  FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    //sm_super_scalar_decoded1 = !sm2pm_gpc_fet_fetch_inst_count_1 & sm2pm_gpc_fet_fetch_inst_count_0
    //                          Count the number of cycles that SCH accepts/decodes one super-scalar-pair or singleton
    { HWPM_FERMI_SUPER_SCALAR_DECODED1,    hwpm_fermi_super_scalar_decoded1_enc_str_1,  0x00000012, 0x00000032, 0x00002222,  0x3433,  FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE, PM_CHIPLET_TYPE_GPC },
    //sm_super_scalar_decoded2 = sm2pm_gpc_fet_fetch_inst_count_1 & !sm2pm_gpc_fet_fetch_inst_count_0
    //                          Count the number of cycles that SCH accepts/decodes two super-scalar-pair or singleton
    { HWPM_FERMI_SUPER_SCALAR_DECODED2,    hwpm_fermi_super_scalar_decoded2_enc_str_1,  0x00000012, 0x00000032, 0x00004444,  0x3433,  FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE, PM_CHIPLET_TYPE_GPC },
    //sm_super_scalar_decoded = Count the number of super-scalar-pair or super-scalar-singleton that are decoded/accepted by SCH
    { HWPM_FERMI_SUPER_SCALAR_DECODED,     hwpm_fermi_super_scalar_decoded_enc_str_1,   0x00000012, 0x00000002, 0x0000FFFF,  0x33,    FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,1,1,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },

    // sm_odd_alu_only_inst_executed                Count ALU pipe only instructions decoded on the odd side
    // sm_odd_xlu_only_inst_executed                count XLU pipe only instructions decoded on the odd side
    // sm_odd_alu_xlu_bipipe_inst_executed          count ALU XLU bipipe instructions decoded on the odd side
    // sm_odd_fmalite_only_inst_executed            Count FMALite pipe instructions decoded on the odd side
    // sm_odd_fma32_only_inst_executed              count FMA32 only instruction decoded on the odd side
    // sm_odd_fmalite_fma32_bipipe_inst_executed    count FMALite FMA32 bipipe instruction decoded on the odd side
    // sm_odd_fu_inst_executed                      count FU pipe instruction decoded on the odd side
    // sm_odd_fma64_inst_executed                   count FMA64 pipe instruction decoded on the odd side
    // sm_odd_su_inst_executed                      count SU pipe instruction decoded on the odd side
    // sm_odd_agu_inst_executed                     count AGU pipe instruction decoded on the odd side
    // sm_odd_tex_inst_executed                     count TEX instruction decoded on the odd side
    // sm_odd_dsm_inst_executed                     count DSM pipe instruction decoded on the odd side
    // sm_odd_sch_internal_inst_executed            count SCH internal instruction decoded on the odd side
    // sm_odd_fe_inst_executed                      count FE pipe instruction decoded on the odd side


    { HWPM_FERMI_SM_ODD0_ALU_ONLY_INST_EXECUTED,              hwpm_fermi_sm_odd0_alu_only_inst_executed_enc_str_1,            0x0000009e, 0x00003210, 0x00000800, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_XLU_ONLY_INST_EXECUTED,              hwpm_fermi_sm_odd0_xlu_only_inst_executed_enc_str_1,            0x0000009e, 0x00003210, 0x00000004, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_ALU_XLU_BIPIPE_INST_EXECUTED,        hwpm_fermi_sm_odd0_alu_xlu_bipipe_inst_executed_enc_str_1,      0x0000009e, 0x00003210, 0x00000002, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_FMALITE_ONLY_INST_EXECUTED,          hwpm_fermi_sm_odd0_fmalite_only_inst_executed_enc_str_1,        0x0000009e, 0x00003210, 0x00000400, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_FMA32_ONLY_INST_EXECUTED,            hwpm_fermi_sm_odd0_fma32_only_inst_executed_enc_str_1,          0x0000009e, 0x00003210, 0x00000010, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_FMALITE_FMA32_BIPIPE_INST_EXECUTED,  hwpm_fermi_sm_odd0_fmalite_fma32_bipipe_inst_executed_enc_str_1,0x0000009e, 0x00003210, 0x00000001, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_FU_INST_EXECUTED,                    hwpm_fermi_sm_odd0_fu_inst_executed_enc_str_1,                  0x0000009e, 0x00003210, 0x00000020, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_FMA64_INST_EXECUTED,                 hwpm_fermi_sm_odd0_fma64_inst_executed_enc_str_1,               0x0000009e, 0x00003210, 0x00000040, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_SU_INST_EXECUTED,                    hwpm_fermi_sm_odd0_su_inst_executed_enc_str_1,                  0x0000009e, 0x00003210, 0x00000008, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_AGU_INST_EXECUTED,                   hwpm_fermi_sm_odd0_agu_inst_executed_enc_str_1,                 0x0000009e, 0x00003210, 0x00000080, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_TEX_INST_EXECUTED,                   hwpm_fermi_sm_odd0_tex_inst_executed_enc_str_1,                 0x0000009e, 0x00003210, 0x00000100, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_DSM_INST_EXECUTED,                   hwpm_fermi_sm_odd0_dsm_inst_executed_enc_str_1,                 0x0000009e, 0x00003210, 0x00000200, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_SCH_INTERNAL_INST_EXECUTED,          hwpm_fermi_sm_odd0_sch_internal_inst_executed_enc_str_1,        0x0000009e, 0x00003210, 0x00002000, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD0_FE_INST_EXECUTED,                    hwpm_fermi_sm_odd0_fe_inst_executed_enc_str_1,                  0x0000009e, 0x00003210, 0x00001000, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },

    { HWPM_FERMI_SM_ODD1_ALU_ONLY_INST_EXECUTED,              hwpm_fermi_sm_odd1_alu_only_inst_executed_enc_str_1,            0x0000009e, 0x00007654, 0x00000800, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_XLU_ONLY_INST_EXECUTED,              hwpm_fermi_sm_odd1_xlu_only_inst_executed_enc_str_1,            0x0000009e, 0x00007654, 0x00000004, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_ALU_XLU_BIPIPE_INST_EXECUTED,        hwpm_fermi_sm_odd1_alu_xlu_bipipe_inst_executed_enc_str_1,      0x0000009e, 0x00007654, 0x00000002, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_FMALITE_ONLY_INST_EXECUTED,          hwpm_fermi_sm_odd1_fmalite_only_inst_executed_enc_str_1,        0x0000009e, 0x00007654, 0x00000400, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_FMA32_ONLY_INST_EXECUTED,            hwpm_fermi_sm_odd1_fma32_only_inst_executed_enc_str_1,          0x0000009e, 0x00007654, 0x00000010, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_FMALITE_FMA32_BIPIPE_INST_EXECUTED,  hwpm_fermi_sm_odd1_fmalite_fma32_bipipe_inst_executed_enc_str_1,0x0000009e, 0x00007654, 0x00000001, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_FU_INST_EXECUTED,                    hwpm_fermi_sm_odd1_fu_inst_executed_enc_str_1,                  0x0000009e, 0x00007654, 0x00000020, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_FMA64_INST_EXECUTED,                 hwpm_fermi_sm_odd1_fma64_inst_executed_enc_str_1,               0x0000009e, 0x00007654, 0x00000040, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_SU_INST_EXECUTED,                    hwpm_fermi_sm_odd1_su_inst_executed_enc_str_1,                  0x0000009e, 0x00007654, 0x00000008, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_AGU_INST_EXECUTED,                   hwpm_fermi_sm_odd1_agu_inst_executed_enc_str_1,                 0x0000009e, 0x00007654, 0x00000080, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_TEX_INST_EXECUTED,                   hwpm_fermi_sm_odd1_tex_inst_executed_enc_str_1,                 0x0000009e, 0x00007654, 0x00000100, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_DSM_INST_EXECUTED,                   hwpm_fermi_sm_odd1_dsm_inst_executed_enc_str_1,                 0x0000009e, 0x00007654, 0x00000200, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_SCH_INTERNAL_INST_EXECUTED,          hwpm_fermi_sm_odd1_sch_internal_inst_executed_enc_str_1,        0x0000009e, 0x00007654, 0x00002000, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_ODD1_FE_INST_EXECUTED,                    hwpm_fermi_sm_odd1_fe_inst_executed_enc_str_1,                  0x0000009e, 0x00007654, 0x00001000, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },

    // sm_even_alu_only_inst_executed               Count ALU pipe only instructions decoded on the even side
    // sm_even_xlu_only_inst_executed               count XLU pipe only instructions decoded on the even side
    // sm_even_alu_xlu_bipipe_inst_executed         count ALU XLU bipipe instructions decoded on the even side
    // sm_even_fmalite_only_inst_executed           Count FMALite pipe instructions decoded on the even side
    // sm_even_fma32_only_inst_executed             count FMA32 only instruction decoded on the even side
    // sm_even_fmalite_fma32_bipipe_inst_executed   count FMALite FMA32 bipipe instruction decoded on the even side
    // sm_even_fu_inst_executed                     count FU pipe instruction decoded on the even side
    // sm_even_fma64_inst_executed                  count FMA64 pipe instruction decoded on the even side
    // sm_even_su_inst_executed                     count SU pipe instruction decoded on the even side
    // sm_even_agu_inst_executed                    count AGU pipe instruction decoded on the even side
    // sm_even_tex_inst_executed                    count TEX instruction decoded on the even side
    // sm_even_dsm_inst_executed                    count DSM pipe instruction decoded on the even side
    // sm_even_sch_internal_inst_executed           count SCH internal instruction decoded on the even side
    // sm_even_fe_inst_executed                     count FE pipe instruction decoded on the even side

    { HWPM_FERMI_SM_EVEN0_ALU_ONLY_INST_EXECUTED,              hwpm_fermi_sm_even0_alu_only_inst_executed_enc_str_1,            0x0000009d, 0x00003210, 0x00000800, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_XLU_ONLY_INST_EXECUTED,              hwpm_fermi_sm_even0_xlu_only_inst_executed_enc_str_1,            0x0000009d, 0x00003210, 0x00000004, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_ALU_XLU_BIPIPE_INST_EXECUTED,        hwpm_fermi_sm_even0_alu_xlu_bipipe_inst_executed_enc_str_1,      0x0000009d, 0x00003210, 0x00000002, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_FMALITE_ONLY_INST_EXECUTED,          hwpm_fermi_sm_even0_fmalite_only_inst_executed_enc_str_1,        0x0000009d, 0x00003210, 0x00000400, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_FMA32_ONLY_INST_EXECUTED,            hwpm_fermi_sm_even0_fma32_only_inst_executed_enc_str_1,          0x0000009d, 0x00003210, 0x00000010, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_FMALITE_FMA32_BIPIPE_INST_EXECUTED,  hwpm_fermi_sm_even0_fmalite_fma32_bipipe_inst_executed_enc_str_1,0x0000009d, 0x00003210, 0x00000001, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_FU_INST_EXECUTED,                    hwpm_fermi_sm_even0_fu_inst_executed_enc_str_1,                  0x0000009d, 0x00003210, 0x00000020, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_FMA64_INST_EXECUTED,                 hwpm_fermi_sm_even0_fma64_inst_executed_enc_str_1,               0x0000009d, 0x00003210, 0x00000040, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_SU_INST_EXECUTED,                    hwpm_fermi_sm_even0_su_inst_executed_enc_str_1,                  0x0000009d, 0x00003210, 0x00000008, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_AGU_INST_EXECUTED,                   hwpm_fermi_sm_even0_agu_inst_executed_enc_str_1,                 0x0000009d, 0x00003210, 0x00000080, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_TEX_INST_EXECUTED,                   hwpm_fermi_sm_even0_tex_inst_executed_enc_str_1,                 0x0000009d, 0x00003210, 0x00000100, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_DSM_INST_EXECUTED,                   hwpm_fermi_sm_even0_dsm_inst_executed_enc_str_1,                 0x0000009d, 0x00003210, 0x00000200, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_SCH_INTERNAL_INST_EXECUTED,          hwpm_fermi_sm_even0_sch_internal_inst_executed_enc_str_1,        0x0000009d, 0x00003210, 0x00002000, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN0_FE_INST_EXECUTED,                    hwpm_fermi_sm_even0_fe_inst_executed_enc_str_1,                  0x0000009d, 0x00003210, 0x00001000, 0x34333231, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {1,1,1,1,0,0,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },

    { HWPM_FERMI_SM_EVEN1_ALU_ONLY_INST_EXECUTED,              hwpm_fermi_sm_even1_alu_only_inst_executed_enc_str_1,            0x0000009d, 0x00007654, 0x00000800, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_XLU_ONLY_INST_EXECUTED,              hwpm_fermi_sm_even1_xlu_only_inst_executed_enc_str_1,            0x0000009d, 0x00007654, 0x00000004, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_ALU_XLU_BIPIPE_INST_EXECUTED,        hwpm_fermi_sm_even1_alu_xlu_bipipe_inst_executed_enc_str_1,      0x0000009d, 0x00007654, 0x00000002, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_FMALITE_ONLY_INST_EXECUTED,          hwpm_fermi_sm_even1_fmalite_only_inst_executed_enc_str_1,        0x0000009d, 0x00007654, 0x00000400, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_FMA32_ONLY_INST_EXECUTED,            hwpm_fermi_sm_even1_fma32_only_inst_executed_enc_str_1,          0x0000009d, 0x00007654, 0x00000010, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_FMALITE_FMA32_BIPIPE_INST_EXECUTED,  hwpm_fermi_sm_even1_fmalite_fma32_bipipe_inst_executed_enc_str_1,0x0000009d, 0x00007654, 0x00000001, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_FU_INST_EXECUTED,                    hwpm_fermi_sm_even1_fu_inst_executed_enc_str_1,                  0x0000009d, 0x00007654, 0x00000020, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_FMA64_INST_EXECUTED,                 hwpm_fermi_sm_even1_fma64_inst_executed_enc_str_1,               0x0000009d, 0x00007654, 0x00000040, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_SU_INST_EXECUTED,                    hwpm_fermi_sm_even1_su_inst_executed_enc_str_1,                  0x0000009d, 0x00007654, 0x00000008, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_AGU_INST_EXECUTED,                   hwpm_fermi_sm_even1_agu_inst_executed_enc_str_1,                 0x0000009d, 0x00007654, 0x00000080, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_TEX_INST_EXECUTED,                   hwpm_fermi_sm_even1_tex_inst_executed_enc_str_1,                 0x0000009d, 0x00007654, 0x00000100, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_DSM_INST_EXECUTED,                   hwpm_fermi_sm_even1_dsm_inst_executed_enc_str_1,                 0x0000009d, 0x00007654, 0x00000200, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_SCH_INTERNAL_INST_EXECUTED,          hwpm_fermi_sm_even1_sch_internal_inst_executed_enc_str_1,        0x0000009d, 0x00007654, 0x00002000, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
    { HWPM_FERMI_SM_EVEN1_FE_INST_EXECUTED,                    hwpm_fermi_sm_even1_fe_inst_executed_enc_str_1,                  0x0000009d, 0x00007654, 0x00001000, 0x38373635, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,1,1,1,1}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC },
#endif
    //Tex signals
    //tex0_cache_sector_queries  = tex02pm_gpc_t_sector_queries
    //tex0_cache_sector_misses   = tex02pm_gpc_t_missed_sectors
    //tex1_cache_sector_queries = tex12pm_gpc_t_sector_queries
    //tex1_cache_sector_misses  = tex12pm_gpc_t_missed_sectors

    { FERMI_TEX_CACHE_SECTOR_QUERIES,    fermi_tex_cache_sector_queries_enc_str_1, 0x00000005, 0x00000000, 0x0000FFFF, 0x0000000e, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_TEX,     {0,0,0,0,1,1,1,1,1,0 }, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC, 0x00000003},
    { FERMI_TEX_CACHE_SECTOR_MISSES,     fermi_tex_cache_sector_misses_enc_str_1,  0x00000004, 0x00000000, 0x0000FFFF, 0x0000000a, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_TEX,     {1,1,1,1,1,0,0,0,0,0 }, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC, 0x00000003},
    { FERMI_TEX1_CACHE_SECTOR_QUERIES,   fermi_tex1_cache_sector_queries_enc_str_1,0x00000005, 0x00000000, 0x0000FFFF, 0x0000000e, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_TEX,     {0,0,0,0,1,1,1,1,1,0 }, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC, 0x00000004},
    { FERMI_TEX1_CACHE_SECTOR_MISSES,    fermi_tex1_cache_sector_misses_enc_str_1, 0x00000004, 0x00000000, 0x0000FFFF, 0x0000000a, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_TEX,     {1,1,1,1,1,0,0,0,0,0 }, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC, 0x00000004},

    { FERMI_TEX0_RETURN_PACKET_COUNT,    fermi_tex0_return_packet_count_enc_str_1,   0x00000003, 0x00000000, 0x00008888, 0x00006263, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_TEX_D,     {0,0,0,0,0,0,0,0,0,0 }, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC, 0x00000000},
    { FERMI_TEX1_RETURN_PACKET_COUNT,    fermi_tex1_return_packet_count_enc_str_1,   0x00000003, 0x00000000, 0x00008888, 0x00006263, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_TEX_D,     {0,0,0,0,0,0,0,0,0,0 }, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_GPC, 0x00000001},

    { FERMI_ELAPSED_CYCLES_SM,     fermi_elapsed_cycles_sm_enc_str_1,  0x00000000, 0x00000000, 0x00000000, 0x00000000, FERMI_CLK_DOMAIN_GF108_GPC0,    PM_UNIT_SM,     {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_GPC },

    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000, 0x00000000,  0x00,         FERMI_CLK_DOMAIN_MAX,     PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE }
};

PerfSignalTableNew PerfSignalTableGF108_ltc0[] = {
    //FBP signals
    { FERMI_FB0_SUBP0_DRAMC_READ,                         fermi_fb0_subp0_dramc_read_enc_str_1,                      0x00000011, 0x00000000, 0x0000AAAA,  0x00000014, FERMI_CLK_DOMAIN_GF108_LTC0,   PM_UNIT_FB,     {1,0,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB0_SUBP1_DRAMC_READ,                         fermi_fb0_subp1_dramc_read_enc_str_1,                      0x00000012, 0x00000000, 0x0000AAAA,  0x00000014, FERMI_CLK_DOMAIN_GF108_LTC0,   PM_UNIT_FB,     {1,0,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB0_SUBP0_DRAMC_WRITE,                        fermi_fb0_subp0_dramc_write_enc_str_1,                     0x00000011, 0x00000001, 0x0000AAAA,  0x00000015, FERMI_CLK_DOMAIN_GF108_LTC0,   PM_UNIT_FB,     {0,1,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB0_SUBP1_DRAMC_WRITE,                        fermi_fb0_subp1_dramc_write_enc_str_1,                     0x00000012, 0x00000001, 0x0000AAAA,  0x00000015, FERMI_CLK_DOMAIN_GF108_LTC0,   PM_UNIT_FB,     {0,1,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB0_SUBP0_DRAM_ACTIVATES,                     fermi_fb0_subp0_dram_activates_enc_str_1,                       0x00000001, 0x00000006, 0x0000AAAA,  0x0000001a, FERMI_CLK_DOMAIN_GF108_LTC0,   PM_UNIT_FB,     {0,0,0,0,0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB0_SUBP1_DRAM_ACTIVATES,                     fermi_fb0_subp1_dram_activates_enc_str_1,                       0x00000002, 0x00000006, 0x0000AAAA,  0x0000001a, FERMI_CLK_DOMAIN_GF108_LTC0,   PM_UNIT_FB,     {0,0,0,0,0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },

    { FERMI_FB1_SUBP0_DRAMC_READ,                         fermi_fb1_subp0_dramc_read_enc_str_1,                      0x00000011, 0x00000000, 0x0000AAAA,  0x00000020, FERMI_CLK_DOMAIN_GF108_LTC0,   PM_UNIT_FB1,    {1,0,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB1_SUBP1_DRAMC_READ,                         fermi_fb1_subp1_dramc_read_enc_str_1,                      0x00000012, 0x00000000, 0x0000AAAA,  0x00000020, FERMI_CLK_DOMAIN_GF108_LTC0,   PM_UNIT_FB1,    {1,0,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB1_SUBP0_DRAMC_WRITE,                        fermi_fb1_subp0_dramc_write_enc_str_1,                     0x00000011, 0x00000001, 0x0000AAAA,  0x00000021, FERMI_CLK_DOMAIN_GF108_LTC0,   PM_UNIT_FB1,    {0,1,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB1_SUBP1_DRAMC_WRITE,                        fermi_fb1_subp1_dramc_write_enc_str_1,                     0x00000012, 0x00000001, 0x0000AAAA,  0x00000021, FERMI_CLK_DOMAIN_GF108_LTC0,   PM_UNIT_FB1,    {0,1,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB1_SUBP0_DRAM_ACTIVATES,                     fermi_fb1_subp0_dram_activates_enc_str_1,                       0x00000001, 0x00000006, 0x0000AAAA,  0x00000026, FERMI_CLK_DOMAIN_GF108_LTC0,   PM_UNIT_FB1,     {0,0,0,0,0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB1_SUBP1_DRAM_ACTIVATES,                     fermi_fb1_subp1_dram_activates_enc_str_1,                       0x00000002, 0x00000006, 0x0000AAAA,  0x00000026, FERMI_CLK_DOMAIN_GF108_LTC0,   PM_UNIT_FB1,     {0,0,0,0,0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },



    //LTC signals
    // l2_subp0_write_sector_misses = ltc_ltc2fb_dirty_dat0_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 0
    // l2_subp1_write_sector_misses = ltc_ltc2fb_dirty_dat1_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 1
    // l2_subp0_read_sector_misses  = ltc_fb2ltc_rdat0_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 0
    // l2_subp1_read_sector_misses  = ltc_fb2ltc_rdat1_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 1
    // l2_subp0_write_sector_queries = ltc2pm_ltc_lts0_request_wr_op && ltc2pm_ltc_lts0_request_active   Valid requets to L2 for write operation/Total sectors written to L2 slice 0
    // l2_subp1_write_sector_queries = ltc2pm_ltc_lts1_request_wr_op && ltc2pm_ltc_lts1_request_active   Valid requets to L2 for write operation/Total sectors written to L2 slice 1
    // l2_subp0_read_sector_queries  = ltc2pm_ltc_lts0_request_rd_op && ltc2pm_ltc_lts0_request_active   Valid requets to L2 for read operation/Total sectors read from L2 slice 0
    // l2_subp1_read_sector_queries  = ltc2pm_ltc_lts1_request_rd_op && ltc2pm_ltc_lts1_request_active   Valid requets to L2 for read operation/Total sectors read from L2 slice 1


    { FERMI_LTC0_WRITE_MISS_SECTORS,  fermi_ltc0_write_miss_sectors_enc_str_1,    0x0000000c, 0x00000004, 0x0000AAAA,  0x04,  FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC1,    {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP },
    { FERMI_LTC1_WRITE_MISS_SECTORS,  fermi_ltc1_write_miss_sectors_enc_str_1,    0x0000000d, 0x00000004, 0x0000AAAA,  0x04,  FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC1,    {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP },
    { FERMI_LTC0_READ_MISS_SECTORS,   fermi_ltc0_read_miss_sectors_enc_str_1,     0x0000000c, 0x00000005, 0x0000AAAA,  0x05,  FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC1,    {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP },
    { FERMI_LTC1_READ_MISS_SECTORS,   fermi_ltc1_read_miss_sectors_enc_str_1,     0x0000000d, 0x00000005, 0x0000AAAA,  0x05,  FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC1,    {0,0,0,0,0,1,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP },
    //changed unit for read/write sectors signals to PM_UNIT_LTC1 (was PM_UNIT_LTC5) The perf event field for these signals are not correct
    //but they are not used for profiling PM signals hence no harm.
    //changed watchbus to 1 for ltc2pm_ltc_lts1_request_active
    //changed watchbus to 0x12 for ltc2pm_ltc_lts1_request_wr_op
    //changed watchbus to 0x13 for ltc2pm_ltc_lts1_request_rd_op


    //Event group mask is calculated from NV_PLTC_MISC_LTC_PM, excluding the PM_ENABLE bit
    //NV_PLTC_MISC_LTC_PM_SECTOR_MUX_SELECT : 0xe
    //NV_PLTC_MISC_LTC_PM_SELECT : 0x1F0
    //NV_PLTC_MISC_LTC_PM_SRCUNIT_MUX_SELECT : 0x3E00
    //NV_PLTC_MISC_LTC_PM_VC_SELECT : 0x70000
    //NV_PLTC_MISC_LTC_PM_SECTOR_COUNT_SELECT : 0x3000000
    //NV_PLTC_MISC_LTC_PM_LTS_MUX_SELECT : 0x20000000
    //Full mask: 0x23073FFE
    //Mask used for this expt: 0x00003FFE (only sector, PM_SELECT and srcunit amd lts group are used).

    //For this particular signal we have following groups
    //subp0
    //NV_PLTC_MISC_LTC_PM_SECTOR_MUX_SELECT : 0x0  : group 0
    //NV_PLTC_MISC_LTC_PM_SELECT : 0x0             : group 0
    //NV_PLTC_MISC_LTC_PM_SRCUNIT_MUX_SELECT : 0x1000  : src unit L1, group 8
    //NV_PLTC_MISC_LTC_PM_VC_SELECT : 0x00000
    //NV_PLTC_MISC_LTC_PM_SECTOR_COUNT_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_LTS_MUX_SELECT : 0x00000000
    //Final value: 0x1000
    //subp1
    //NV_PLTC_MISC_LTC_PM_SECTOR_MUX_SELECT : 0x6  : group 3
    //NV_PLTC_MISC_LTC_PM_SELECT : 0x10            : group 1
    //NV_PLTC_MISC_LTC_PM_SRCUNIT_MUX_SELECT : 0x1200 : src unit L1, group 9
    //NV_PLTC_MISC_LTC_PM_VC_SELECT : 0x00000
    //NV_PLTC_MISC_LTC_PM_SECTOR_COUNT_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_LTS_MUX_SELECT : 0x00000000
    //Final value: 0x00001216
    //In the following signals using PM_UNIT_LTC1 as sector_misses signals use the same group that is required for sector_queries signals. They should not be profiled in same run
    { FERMI_LTC0_WRITE_SECTORS_FBP,   fermi_ltc0_write_sectors_fbp_enc_str_1, 0x00000000, 0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC1,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x013012, 0x00001000, 0x00003FFE},
    { FERMI_LTC1_WRITE_SECTORS_FBP,   fermi_ltc1_write_sectors_fbp_enc_str_1, 0x00000003, 0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC1,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x013012, 0x00001216, 0x00003FFE},
    { FERMI_LTC0_READ_SECTORS_FBP,    fermi_ltc0_read_sectors_fbp_enc_str_1,  0x00000000, 0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC1,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x013013, 0x00001000, 0x00003FFE},
    { FERMI_LTC1_READ_SECTORS_FBP,    fermi_ltc1_read_sectors_fbp_enc_str_1,  0x00000003, 0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC1,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x013013, 0x00001216, 0x00003FFE},

    // l2_subp0_atomic_l1_sector_queries = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_atomic_op & ltc2pm_ltc_lts0_request_src_unit_l1
    { FERMI_LTC0_ATOMIC_L1_SECTORS_FBP,      fermi_ltc0_atomic_l1_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC1,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x011130, 0x00001000, 0x00003FFE},
    { FERMI_LTC1_ATOMIC_L1_SECTORS_FBP,      fermi_ltc1_atomic_l1_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC1,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x011130, 0x00001216, 0x00003FFE},


    //For this particular signal we have following groups
    //subp0
    //NV_PLTC_MISC_LTC_PM_SECTOR_MUX_SELECT : 0x0  : group 0
    //NV_PLTC_MISC_LTC_PM_SELECT : 0x0             : group 0
    //NV_PLTC_MISC_LTC_PM_SRCUNIT_MUX_SELECT : 0xC00  : src unit L1, group 6
    //NV_PLTC_MISC_LTC_PM_VC_SELECT : 0x00000
    //NV_PLTC_MISC_LTC_PM_SECTOR_COUNT_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_LTS_MUX_SELECT : 0x00000000
    //Final value: 0xC00
    //subp1
    //NV_PLTC_MISC_LTC_PM_SECTOR_MUX_SELECT : 0x6  : group 3
    //NV_PLTC_MISC_LTC_PM_SELECT : 0x10            : group 1
    //NV_PLTC_MISC_LTC_PM_SRCUNIT_MUX_SELECT : 0xE00 : src unit L1, group 7
    //NV_PLTC_MISC_LTC_PM_VC_SELECT : 0x00000
    //NV_PLTC_MISC_LTC_PM_SECTOR_COUNT_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_LTS_MUX_SELECT : 0x00000000
    //Final value: 0x0000E16

    { FERMI_LTC0_READ_TEX_SECTORS_FBP, fermi_ltc0_read_tex_sectors_fbp_enc_str_1,  0x00000000, 0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC1,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x013013, 0x00000C00, 0x00003FFE},
    { FERMI_LTC1_READ_TEX_SECTORS_FBP, fermi_ltc1_read_tex_sectors_fbp_enc_str_1,  0x00000003, 0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC1,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x013013, 0x00000E16, 0x00003FFE},

    { FERMI_LTC0_READ_CB_SECTORS_FBP,  fermi_ltc0_read_cb_sectors_fbp_enc_str_1,   0x00000000, 0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC1,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x011306, 0x00000000, 0x000001FE},
    { FERMI_LTC1_READ_CB_SECTORS_FBP,  fermi_ltc1_read_cb_sectors_fbp_enc_str_1,   0x00000003, 0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC1,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x011306, 0x00000016, 0x000001FE},
    { FERMI_LTC0_WRITE_CB_SECTORS_FBP, fermi_ltc0_write_cb_sectors_fbp_enc_str_1,  0x00000000, 0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC1,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x011206, 0x00000000, 0x000001FE},
    { FERMI_LTC1_WRITE_CB_SECTORS_FBP, fermi_ltc1_write_cb_sectors_fbp_enc_str_1,  0x00000003, 0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC1,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x011206, 0x00000016, 0x000001FE},

    { FERMI_LTC0_READ_HIT_SECTORS_FBP,     fermi_ltc0_read_hit_sectors_fbp_enc_str_1,     0x00000000, 0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC1,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008000,  0x01301307, 0x00001002, 0x00003FFE},
    { FERMI_LTC1_READ_HIT_SECTORS_FBP,     fermi_ltc1_read_hit_sectors_fbp_enc_str_1,     0x00000003, 0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC1,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008000,  0x01301307, 0x00001218, 0x00003EFE},
    { FERMI_LTC0_READ_TEX_HIT_SECTORS_FBP, fermi_ltc0_read_tex_hit_sectors_fbp_enc_str_1, 0x00000000, 0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC1,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008000,  0x01301307, 0x00000C02, 0x00003FFE},
    { FERMI_LTC1_READ_TEX_HIT_SECTORS_FBP, fermi_ltc1_read_tex_hit_sectors_fbp_enc_str_1, 0x00000003, 0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC1,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008000,  0x01301307, 0x00000E18, 0x00003EFE},
    { FERMI_LTC0_READ_CB_HIT_SECTORS_FBP,  fermi_ltc0_read_cb_hit_sectors_fbp_enc_str_1,  0x00000000, 0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC1,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008000,  0x01130607, 0x00000002, 0x000001FE},
    { FERMI_LTC1_READ_CB_HIT_SECTORS_FBP,  fermi_ltc1_read_cb_hit_sectors_fbp_enc_str_1,  0x00000003, 0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC1,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008000,  0x01130607, 0x00000018, 0x000001FE},

    // ltc_read_sysmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_sysmem
    { FERMI_LTC0_READ_SYSMEM_SECTORS_FBP,      fermi_ltc0_read_sysmem_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x0001130d, 0x00000000, 0x000001FE},
    { FERMI_LTC1_READ_SYSMEM_SECTORS_FBP,      fermi_ltc1_read_sysmem_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x0001130d, 0x00000016, 0x000001FE},

    // ltc_write_sysmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_sysmem
    { FERMI_LTC0_WRITE_SYSMEM_SECTORS_FBP,      fermi_ltc0_write_sysmem_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x0001120d, 0x00000000, 0x000001FE},
    { FERMI_LTC1_WRITE_SYSMEM_SECTORS_FBP,      fermi_ltc1_write_sysmem_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x0001120d, 0x00000016, 0x000001FE},

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { FERMI_LTC0_TOTAL_READ_SECTORS_FBP,      fermi_ltc0_total_read_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008888,  0x00000113, 0x00000000, 0x000001FE},
    { FERMI_LTC1_TOTAL_READ_SECTORS_FBP,      fermi_ltc1_total_read_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008888,  0x00000113, 0x00000016, 0x000001FE},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { FERMI_LTC0_TOTAL_WRITE_SECTORS_FBP,      fermi_ltc0_total_write_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008888,  0x00000112, 0x00000000, 0x000001FE},
    { FERMI_LTC1_TOTAL_WRITE_SECTORS_FBP,      fermi_ltc1_total_write_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008888,  0x00000112, 0x00000016, 0x000001FE},

    // ltc_read_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { FERMI_LTC0_READ_VIDMEM_SECTORS_FBP,      fermi_ltc0_read_vidmem_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x0001130c, 0x00000000, 0x000001FE},
    { FERMI_LTC1_READ_VIDMEM_SECTORS_FBP,      fermi_ltc1_read_vidmem_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x0001130c, 0x00000016, 0x000001FE},

    // ltc_write_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { FERMI_LTC0_WRITE_VIDMEM_SECTORS_FBP,      fermi_ltc0_write_vidmem_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x0001120c, 0x00000000, 0x000001FE},
    { FERMI_LTC1_WRITE_VIDMEM_SECTORS_FBP,      fermi_ltc1_write_vidmem_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0x2c,   FERMI_CLK_DOMAIN_GF108_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x0001120c, 0x00000016, 0x000001FE},

    { INVALID_PM_SIGNAL_NEW,                "",                 0xffffffff, 0x00000000, 0x00000000,  0x00,     FERMI_CLK_DOMAIN_MAX,     PM_UNIT_MAX,     {0,0,0,0,0,0,0,0},                 SIG_TYPE_SINGLE }
};

PerfSignalTableNew PerfSignalTableGF108_hub0[] = {
    //Hub TLB signals
    //__hub_tlb_hit        = hubmmu2pm_hub_hub_tlb_hit                                      count # of PTE hits in hub TLB
    //__hub_tlb_miss       = (hubmmu2pm_hub_hub_tlb_miss & !hubmmu2pm_hub_hub_tlb_hit)      count # of PTE misses in hub TLB
    { FERMI_MMU_HUB_TLB_HIT,    fermi_mmu_hub_tlb_hit_enc_str_1,    0x00000004,   0x00000000, 0x0000AAAA, 0x05,   FERMI_CLK_DOMAIN_GF108_HUB0,    PM_UNIT_HUBMMU,    {1,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_SYS },
    { FERMI_MMU_HUB_TLB_MISS,   fermi_mmu_hub_tlb_miss_enc_str_1,   0x00000004,   0x00000001, 0x00004444, 0x0605, FERMI_CLK_DOMAIN_GF108_HUB0,    PM_UNIT_HUBMMU,    {1,1,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_SYS },

    // mmu_fill_pte_hit    = hubmmu2pm_hub_fill_pte_hit                                     "count # of PTE hits in mmu fill unit"
    // mmu_fill_pte_miss   = (hubmmu2pm_hub_fill_pte_miss & !hubmmu2pm_hub_fill_pte_hit)    "count # of PTE misses in mmu fill unit"
    { FERMI_MMU_FILL_PTE_HIT,   fermi_mmu_fill_pte_hit_enc_str_1,   0x00000006,   0x00000000, 0x0000AAAA, 0x05,   FERMI_CLK_DOMAIN_GF108_HUB0,    PM_UNIT_HUBMMU,    {1,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_SYS },
    { FERMI_MMU_FILL_PTE_MISS,  fermi_mmu_fill_pte_miss_enc_str_1,  0x00000006,   0x00000010, 0x00004444, 0x0605, FERMI_CLK_DOMAIN_GF108_HUB0,    PM_UNIT_HUBMMU,    {1,1,0,0}, SIG_TYPE_MULTIPLE,    PM_CHIPLET_TYPE_SYS },

    // mmu_fill_pde_hit    = hubmmu2pm_hub_fill_pde_hit                                     "count # of PDE hits in mmu fill unit"
    // mmu_fill_pde_miss   = hubmmu2pm_hub_fill_pde_miss                                    "count # of PDE misses in mmu fill unit"
    { FERMI_MMU_FILL_PDE_HIT,   fermi_mmu_fill_pde_hit_enc_str_1,   0x00000006,   0x00000002, 0x0000AAAA, 0x07,   FERMI_CLK_DOMAIN_GF108_HUB0,    PM_UNIT_HUBMMU,    {0,0,1,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_SYS },
    { FERMI_MMU_FILL_PDE_MISS,  fermi_mmu_fill_pde_miss_enc_str_1,  0x00000006,   0x00000003, 0x0000AAAA, 0x08,   FERMI_CLK_DOMAIN_GF108_HUB0,    PM_UNIT_HUBMMU,    {0,0,0,1}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_SYS },

    //GF108 does not have L2 TLB

    { INVALID_PM_SIGNAL_NEW,                "",                 0xffffffff, 0x00000000, 0x00000000,  0x00,     FERMI_CLK_DOMAIN_MAX,     PM_UNIT_MAX,     {0,0,0,0,0,0,0,0},                 SIG_TYPE_SINGLE }
};


PerfSignalTableNew PerfSignalTableGF119_ltc0[] = {
    //FBP signals
    { FERMI_FB_SUBP0_DRAMC_READ,     fermi_fb_subp0_dramc_read_enc_str_1,   0x00000011, 0x00000000, 0x0000AAAA,  0x00000000, FERMI_CLK_DOMAIN_GF119_LTC0,   PM_UNIT_FB,     {1,0,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB_SUBP1_DRAMC_READ,     fermi_fb_subp1_dramc_read_enc_str_1,   0x00000012, 0x00000000, 0x0000AAAA,  0x00000000, FERMI_CLK_DOMAIN_GF119_LTC0,   PM_UNIT_FB,     {1,0,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB_SUBP0_DRAMC_WRITE,    fermi_fb_subp0_dramc_write_enc_str_1,  0x00000011, 0x00000001, 0x0000AAAA,  0x00000001, FERMI_CLK_DOMAIN_GF119_LTC0,   PM_UNIT_FB,     {0,1,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB_SUBP1_DRAMC_WRITE,    fermi_fb_subp1_dramc_write_enc_str_1,  0x00000012, 0x00000001, 0x0000AAAA,  0x00000001, FERMI_CLK_DOMAIN_GF119_LTC0,   PM_UNIT_FB,     {0,1,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB_SUBP0_DRAM_ACTIVATES, fermi_fb_subp0_dram_activates_enc_str_1,    0x00000001, 0x00000006, 0x0000AAAA,  0x00000006, FERMI_CLK_DOMAIN_GF119_LTC0,   PM_UNIT_FB,     {0,0,0,0,0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB_SUBP1_DRAM_ACTIVATES, fermi_fb_subp1_dram_activates_enc_str_1,    0x00000002, 0x00000006, 0x0000AAAA,  0x00000006, FERMI_CLK_DOMAIN_GF119_LTC0,   PM_UNIT_FB,     {0,0,0,0,0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },

    //LTC signals
    // l2_subp0_write_sector_misses = ltc_ltc2fb_dirty_dat0_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 0
    // l2_subp1_write_sector_misses = ltc_ltc2fb_dirty_dat1_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 1
    // l2_subp0_read_sector_misses  = ltc_fb2ltc_rdat0_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 0
    // l2_subp1_read_sector_misses  = ltc_fb2ltc_rdat1_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 1

    // Last 0 is for slice numer
    { FERMI_LTC0_WRITE_MISS_SECTORS,  fermi_ltc0_write_miss_sectors_enc_str_1,    0x00000006, 0x00000000, 0x0000AAAA,  0x15,  FERMI_CLK_DOMAIN_GF119_LTC0,    PM_UNIT_LTC1,    {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0},
    { FERMI_LTC0_READ_MISS_SECTORS,   fermi_ltc0_read_miss_sectors_enc_str_1,     0x00000006, 0x00000000, 0x0000AAAA,  0x16,  FERMI_CLK_DOMAIN_GF119_LTC0,    PM_UNIT_LTC1,    {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0},

    // l2_subp0_write_sector_queries = ltc2pm_ltc_lts0_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 0
    // l2_subp1_write_sector_queries = ltc2pm_ltc_lts1_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 1
    // l2_subp0_read_sector_queries  = ltc2pm_ltc_lts0_request_rd_op && ltc2pm_ltc_lts1_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 0
    // l2_subp1_read_sector_queries  = ltc2pm_ltc_lts1_request_rd_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 1

    //Event group mask is calculated from NV_PLTC_MISC_LTC_PM, excluding the PM_ENABLE bit
    //NV_PLTC_MISC_LTC_PM_SECTOR_MUX_SELECT : 0xe
    //NV_PLTC_MISC_LTC_PM_SELECT : 0x1F0
    //NV_PLTC_MISC_LTC_PM_SRCUNIT_MUX_SELECT : 0x3E00
    //Full mask: 0x0003FFE

    //For this particular signal we have following groups
    //slice 0
    //NV_PLTC_MISC_LTC_PM_SECTOR_MUX_SELECT : 0x0  : group 0
    //NV_PLTC_MISC_LTC_PM_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_SRCUNIT_MUX_SELECT : 0x800  : src unit L1 - 4

    //Final value: 0x800

    { FERMI_LTC0_WRITE_SECTORS_FBP,   fermi_ltc0_write_sectors_fbp_enc_str_1, 0x00000000, 0x00003210, 0x0000FFFF,  0x0c,   FERMI_CLK_DOMAIN_GF119_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x121023, 0x00000800, 0x00003FFE},
    { FERMI_LTC0_READ_SECTORS_FBP,    fermi_ltc0_read_sectors_fbp_enc_str_1,  0x00000000, 0x00003210, 0x0000FFFF,  0x0c,   FERMI_CLK_DOMAIN_GF119_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x121024, 0x00000800, 0x00003FFE},

    // l2_subp0_atomic_l1_sector_queries = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_atomic_op & ltc2pm_ltc_lts0_request_src_unit_l1
    { FERMI_LTC0_ATOMIC_L1_SECTORS_FBP,      fermi_ltc0_atomic_l1_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF119_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x122210, 0x00000800, 0x00003FFE},

    //For this particular signal we have following groups
    //slice 0
    //NV_PLTC_MISC_LTC_PM_SECTOR_MUX_SELECT : 0x0  : group 0
    //NV_PLTC_MISC_LTC_PM_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_SRCUNIT_MUX_SELECT : 0x600  : src unit tex - 3
    //Final value: 0x600

    { FERMI_LTC0_READ_TEX_SECTORS_FBP, fermi_ltc0_read_tex_sectors_fbp_enc_str_1,  0x00000000, 0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF119_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x121024, 0x00000600, 0x00003FFE},

    { FERMI_LTC0_READ_CB_SECTORS_FBP,  fermi_ltc0_read_cb_sectors_fbp_enc_str_1,   0x00000000, 0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF119_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x122417, 0x00000000, 0x000001FE},
    { FERMI_LTC0_WRITE_CB_SECTORS_FBP, fermi_ltc0_write_cb_sectors_fbp_enc_str_1,  0x00000000, 0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF119_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x122317, 0x00000000, 0x000001FE},

    { FERMI_LTC0_READ_HIT_SECTORS_FBP,     fermi_ltc0_read_hit_sectors_fbp_enc_str_1,     0x00000000, 0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF119_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008000,  0x12102418, 0x00000802, 0x00003FFE},
    { FERMI_LTC0_READ_TEX_HIT_SECTORS_FBP, fermi_ltc0_read_tex_hit_sectors_fbp_enc_str_1, 0x00000000, 0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF119_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008000,  0x12102418, 0x00000602, 0x00003FFE},
    { FERMI_LTC0_READ_CB_HIT_SECTORS_FBP,  fermi_ltc0_read_cb_hit_sectors_fbp_enc_str_1,  0x00000000, 0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF119_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008000,  0x12241718, 0x00000002, 0x000001FE},

    // ltc_read_sysmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_sysmem
    { FERMI_LTC0_READ_SYSMEM_SECTORS_FBP,      fermi_ltc0_read_sysmem_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF119_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x0012241e, 0x00000000, 0x000001FE},

    // ltc_write_sysmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_sysmem
    { FERMI_LTC0_WRITE_SYSMEM_SECTORS_FBP,      fermi_ltc0_write_sysmem_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF119_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x0012231e, 0x00000000, 0x000001FE},

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { FERMI_LTC0_TOTAL_READ_SECTORS_FBP,      fermi_ltc0_total_read_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF119_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008888,  0x00001224, 0x00000000, 0x000001FE},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { FERMI_LTC0_TOTAL_WRITE_SECTORS_FBP,      fermi_ltc0_total_write_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF119_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008888,  0x00001223, 0x00000000, 0x000001FE},

    // ltc_read_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { FERMI_LTC0_READ_VIDMEM_SECTORS_FBP,      fermi_ltc0_read_vidmem_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF119_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x0012241d, 0x00000000, 0x000001FE},

    // ltc_write_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { FERMI_LTC0_WRITE_VIDMEM_SECTORS_FBP,      fermi_ltc0_write_vidmem_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF119_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x0012231d, 0x00000000, 0x000001FE},

    { INVALID_PM_SIGNAL_NEW,                "",                 0xffffffff, 0x00000000, 0x00000000,  0x00,     FERMI_CLK_DOMAIN_MAX,     PM_UNIT_MAX,     {0,0,0,0,0,0,0,0},                 SIG_TYPE_SINGLE }
};

PerfSignalTableNew PerfSignalTableGF117_ltc0[] = {
    //FBP signals
    { FERMI_FB_SUBP0_DRAMC_READ,     fermi_fb_subp0_dramc_read_enc_str_1,   0x00000011, 0x00000000, 0x0000AAAA,  0x00000000, FERMI_CLK_DOMAIN_GF117_LTC0,   PM_UNIT_FB,     {1,0,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB_SUBP1_DRAMC_READ,     fermi_fb_subp1_dramc_read_enc_str_1,   0x00000012, 0x00000000, 0x0000AAAA,  0x00000000, FERMI_CLK_DOMAIN_GF117_LTC0,   PM_UNIT_FB,     {1,0,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB_SUBP0_DRAMC_WRITE,    fermi_fb_subp0_dramc_write_enc_str_1,  0x00000011, 0x00000001, 0x0000AAAA,  0x00000001, FERMI_CLK_DOMAIN_GF117_LTC0,   PM_UNIT_FB,     {0,1,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB_SUBP1_DRAMC_WRITE,    fermi_fb_subp1_dramc_write_enc_str_1,  0x00000012, 0x00000001, 0x0000AAAA,  0x00000001, FERMI_CLK_DOMAIN_GF117_LTC0,   PM_UNIT_FB,     {0,1,0,0,0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB_SUBP0_DRAM_ACTIVATES, fermi_fb_subp0_dram_activates_enc_str_1,    0x00000001, 0x00000006, 0x0000AAAA,  0x00000006, FERMI_CLK_DOMAIN_GF117_LTC0,   PM_UNIT_FB,     {0,0,0,0,0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },
    { FERMI_FB_SUBP1_DRAM_ACTIVATES, fermi_fb_subp1_dram_activates_enc_str_1,    0x00000002, 0x00000006, 0x0000AAAA,  0x00000006, FERMI_CLK_DOMAIN_GF117_LTC0,   PM_UNIT_FB,     {0,0,0,0,0,0,1,0,0,0,0,0}, SIG_TYPE_SINGLE, PM_CHIPLET_TYPE_FBP },

    //LTC signals
    // l2_subp0_write_sector_misses = ltc_ltc2fb_dirty_dat0_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 0
    // l2_subp1_write_sector_misses = ltc_ltc2fb_dirty_dat1_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 1
    // l2_subp0_read_sector_misses  = ltc_fb2ltc_rdat0_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 0
    // l2_subp1_read_sector_misses  = ltc_fb2ltc_rdat1_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 1

    // Last 0 is for slice numer
    { FERMI_LTC0_WRITE_MISS_SECTORS,  fermi_ltc0_write_miss_sectors_enc_str_1,    0x00000006, 0x00000000, 0x0000AAAA,  0x15,  FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC1,    {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0},
    { FERMI_LTC0_READ_MISS_SECTORS,   fermi_ltc0_read_miss_sectors_enc_str_1,     0x00000006, 0x00000000, 0x0000AAAA,  0x16,  FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC1,    {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0},

    { FERMI_LTC1_WRITE_MISS_SECTORS,  fermi_ltc1_write_miss_sectors_enc_str_1,    0x00000006, 0x00000000, 0x0000AAAA,  0x15,  FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC1,    {0,0,0,0,1,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1},
    { FERMI_LTC1_READ_MISS_SECTORS,   fermi_ltc1_read_miss_sectors_enc_str_1,     0x00000006, 0x00000000, 0x0000AAAA,  0x16,  FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC1,    {1,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1},

    // l2_subp0_write_sector_queries = ltc2pm_ltc_lts0_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 0
    // l2_subp1_write_sector_queries = ltc2pm_ltc_lts1_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 1
    // l2_subp0_read_sector_queries  = ltc2pm_ltc_lts0_request_rd_op && ltc2pm_ltc_lts1_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 0
    // l2_subp1_read_sector_queries  = ltc2pm_ltc_lts1_request_rd_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 1

    //Event group mask is calculated from NV_PLTC_MISC_LTC_PM, excluding the PM_ENABLE bit
    //NV_PLTC_MISC_LTC_PM_SECTOR_MUX_SELECT : 0xe
    //NV_PLTC_MISC_LTC_PM_SELECT : 0x1F0
    //NV_PLTC_MISC_LTC_PM_SRCUNIT_MUX_SELECT : 0x3E00
    //Full mask: 0x0003FFE

    //For this particular signal we have following groups
    //slice 0
    //NV_PLTC_MISC_LTC_PM_SECTOR_MUX_SELECT : 0x0  : group 0
    //NV_PLTC_MISC_LTC_PM_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_SRCUNIT_MUX_SELECT : 0x800  : src unit L1 - 4

    //Final value: 0x800

    { FERMI_LTC0_WRITE_SECTORS_FBP,   fermi_ltc0_write_sectors_fbp_enc_str_1, 0x00000000, 0x00003210, 0x0000FFFF,  0x0c,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x121023, 0x00000800, 0x00003FFE, 0},
    { FERMI_LTC0_READ_SECTORS_FBP,    fermi_ltc0_read_sectors_fbp_enc_str_1,  0x00000000, 0x00003210, 0x0000FFFF,  0x0c,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x121024, 0x00000800, 0x00003FFE, 0},

    { FERMI_LTC1_WRITE_SECTORS_FBP,   fermi_ltc1_write_sectors_fbp_enc_str_1, 0x00000000, 0x00003210, 0x0000FFFF,  0x0c,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x121023, 0x00000800, 0x00003FFE,0x00000212},
    { FERMI_LTC1_READ_SECTORS_FBP,    fermi_ltc1_read_sectors_fbp_enc_str_1,  0x00000000, 0x00003210, 0x0000FFFF,  0x0c,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x121024, 0x00000800, 0x00003FFE,0x00000212},

    // l2_subp0_atomic_l1_sector_queries = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_atomic_op & ltc2pm_ltc_lts0_request_src_unit_l1
    { FERMI_LTC0_ATOMIC_L1_SECTORS_FBP,      fermi_ltc0_atomic_l1_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x122210, 0x00003FFE, 0},
    { FERMI_LTC1_ATOMIC_L1_SECTORS_FBP,      fermi_ltc1_atomic_l1_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x122210, 0x00003FFE,0x00000212},

    //For this particular signal we have following groups
    //slice 0
    //NV_PLTC_MISC_LTC_PM_SECTOR_MUX_SELECT : 0x0  : group 0
    //NV_PLTC_MISC_LTC_PM_SELECT : 0x0
    //NV_PLTC_MISC_LTC_PM_SRCUNIT_MUX_SELECT : 0x600  : src unit tex - 3
    //Final value: 0x600

    { FERMI_LTC0_READ_TEX_SECTORS_FBP, fermi_ltc0_read_tex_sectors_fbp_enc_str_1,  0x00000000, 0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x121024, 0x00000600, 0x00003FFE, 0},
    { FERMI_LTC1_READ_TEX_SECTORS_FBP, fermi_ltc1_read_tex_sectors_fbp_enc_str_1,  0x00000000, 0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,    {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x121024, 0x00000600, 0x00003FFE, 0x00000212},

    { FERMI_LTC0_READ_CB_SECTORS_FBP,  fermi_ltc0_read_cb_sectors_fbp_enc_str_1,   0x00000000, 0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x122417, 0x00000000, 0x000001FE, 0},
    { FERMI_LTC0_WRITE_CB_SECTORS_FBP, fermi_ltc0_write_cb_sectors_fbp_enc_str_1,  0x00000000, 0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x122317, 0x00000000, 0x000001FE, 0},

    { FERMI_LTC0_READ_HIT_SECTORS_FBP,     fermi_ltc0_read_hit_sectors_fbp_enc_str_1,     0x00000000, 0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008000,  0x12102418, 0x00000802, 0x00003FFE, 0},
    { FERMI_LTC0_READ_TEX_HIT_SECTORS_FBP, fermi_ltc0_read_tex_hit_sectors_fbp_enc_str_1, 0x00000000, 0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008000,  0x12102418, 0x00000602, 0x00003FFE, 0},
    { FERMI_LTC1_READ_HIT_SECTORS_FBP,     fermi_ltc1_read_hit_sectors_fbp_enc_str_1,     0x00000000, 0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008000,  0x12102418, 0x00000802, 0x00003FFE, 0x00000212},
    { FERMI_LTC1_READ_TEX_HIT_SECTORS_FBP, fermi_ltc1_read_tex_hit_sectors_fbp_enc_str_1, 0x00000000, 0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008000,  0x12102418, 0x00000602, 0x00003FFE, 0x00000212},

    { FERMI_LTC0_READ_CB_HIT_SECTORS_FBP,  fermi_ltc0_read_cb_hit_sectors_fbp_enc_str_1,  0x00000000, 0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008000,  0x12241718, 0x00000002, 0x000001FE, 0},

    // ltc_read_sysmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_sysmem
    { FERMI_LTC0_READ_SYSMEM_SECTORS_FBP,      fermi_ltc0_read_sysmem_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x0012241e, 0x00000000, 0x000001FE},
    { FERMI_LTC1_READ_SYSMEM_SECTORS_FBP,      fermi_ltc1_read_sysmem_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x0012241e, 0x00000012, 0x000001FE},

    // ltc_write_sysmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_sysmem
    { FERMI_LTC0_WRITE_SYSMEM_SECTORS_FBP,      fermi_ltc0_write_sysmem_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x0012231e, 0x00000000, 0x000001FE},
    { FERMI_LTC1_WRITE_SYSMEM_SECTORS_FBP,      fermi_ltc1_write_sysmem_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x0012231e, 0x00000012, 0x000001FE},

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { FERMI_LTC0_TOTAL_READ_SECTORS_FBP,      fermi_ltc0_total_read_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008888,  0x00001224, 0x00000000, 0x000001FE},
    { FERMI_LTC1_TOTAL_READ_SECTORS_FBP,      fermi_ltc1_total_read_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008888,  0x00001224, 0x00000012, 0x000001FE},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { FERMI_LTC0_TOTAL_WRITE_SECTORS_FBP,      fermi_ltc0_total_write_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008888,  0x00001223, 0x00000000, 0x000001FE},
    { FERMI_LTC1_TOTAL_WRITE_SECTORS_FBP,      fermi_ltc1_total_write_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008888,  0x00001223, 0x00000012, 0x000001FE},

    // ltc_read_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { FERMI_LTC0_READ_VIDMEM_SECTORS_FBP,      fermi_ltc0_read_vidmem_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x0012241d, 0x00000000, 0x000001FE},
    { FERMI_LTC1_READ_VIDMEM_SECTORS_FBP,      fermi_ltc1_read_vidmem_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x0012241d, 0x00000012, 0x000001FE},

    // ltc_write_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { FERMI_LTC0_WRITE_VIDMEM_SECTORS_FBP,      fermi_ltc0_write_vidmem_sectors_fbp_enc_str_1,    0x00000000,  0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 0, 1, 0x00008080,  0x0012231d, 0x00000000, 0x000001FE},
    { FERMI_LTC1_WRITE_VIDMEM_SECTORS_FBP,      fermi_ltc1_write_vidmem_sectors_fbp_enc_str_1,    0x00000003,  0x00003210, 0x0000FFFF,  0xc,   FERMI_CLK_DOMAIN_GF117_LTC0,    PM_UNIT_LTC,   {1,1,1,1}, SIG_TYPE_SINGLE,    PM_CHIPLET_TYPE_FBP, 1, 1, 0x00008080,  0x0012231d, 0x00000012, 0x000001FE},

    { INVALID_PM_SIGNAL_NEW,                "",                 0xffffffff, 0x00000000, 0x00000000,  0x00,     FERMI_CLK_DOMAIN_MAX,     PM_UNIT_MAX,     {0,0,0,0,0,0,0,0},                 SIG_TYPE_SINGLE }
};

PerfSignalTableNew PerfSignalTableGFNopTrigSwCounters_ld_st_inst[] = {
    // Software counters work for all Fermi chips
    // TO DO: Change this table and make it more suitable for sw counters as most of the fields are not used
    { FERMI_SW_COUNTER_GLD8BIT_INST,    fermi_sw_counter_gld8bit_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,  0x00,   FERMI_NOPTRIG_SW_COUNTERS_DOMAIN,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_GPC },
    { FERMI_SW_COUNTER_GLD16BIT_INST,   fermi_sw_counter_gld16bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,  0x00,   FERMI_NOPTRIG_SW_COUNTERS_DOMAIN,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_GPC },
    { FERMI_SW_COUNTER_GLD32BIT_INST,   fermi_sw_counter_gld32bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,  0x00,   FERMI_NOPTRIG_SW_COUNTERS_DOMAIN,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_GPC },
    { FERMI_SW_COUNTER_GLD64BIT_INST,   fermi_sw_counter_gld64bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,  0x00,   FERMI_NOPTRIG_SW_COUNTERS_DOMAIN,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_GPC },
    { FERMI_SW_COUNTER_GLD128BIT_INST,  fermi_sw_counter_gld128bit_inst_enc_str_1,  0xffffffff, 0x00000000, 0x00000000,  0x00,   FERMI_NOPTRIG_SW_COUNTERS_DOMAIN,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_GPC },
    { FERMI_SW_COUNTER_GST8BIT_INST,    fermi_sw_counter_gst8bit_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,  0x00,   FERMI_NOPTRIG_SW_COUNTERS_DOMAIN,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_GPC },
    { FERMI_SW_COUNTER_GST16BIT_INST,   fermi_sw_counter_gst16bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,  0x00,   FERMI_NOPTRIG_SW_COUNTERS_DOMAIN,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_GPC },
    { FERMI_SW_COUNTER_GST32BIT_INST,   fermi_sw_counter_gst32bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,  0x00,   FERMI_NOPTRIG_SW_COUNTERS_DOMAIN,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_GPC },
    { FERMI_SW_COUNTER_GST64BIT_INST,   fermi_sw_counter_gst64bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,  0x00,   FERMI_NOPTRIG_SW_COUNTERS_DOMAIN,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_GPC },
    { FERMI_SW_COUNTER_GST128BIT_INST,  fermi_sw_counter_gst128bit_inst_enc_str_1,  0xffffffff, 0x00000000, 0x00000000,  0x00,   FERMI_NOPTRIG_SW_COUNTERS_DOMAIN,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_GPC },
    { INVALID_SW_COUNTER,               "",           0xffffffff, 0x00000000, 0x00000000,  0x00,   FERMI_CLK_DOMAIN_MAX,                   PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE }
};

PerfSignalTableNew PerfSignalTableGFNopTrigSwCounters_sld_sst[] = {
    // Software counters work for all Fermi chips
    { FERMI_SW_COUNTER_SLD8BIT_INST,    fermi_sw_counter_sld8bit_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { FERMI_SW_COUNTER_SLD16BIT_INST,   fermi_sw_counter_sld16bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { FERMI_SW_COUNTER_SLD32BIT_INST,   fermi_sw_counter_sld32bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { FERMI_SW_COUNTER_SLD64BIT_INST,   fermi_sw_counter_sld64bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { FERMI_SW_COUNTER_SLD128BIT_INST,  fermi_sw_counter_sld128bit_inst_enc_str_1,  0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { FERMI_SW_COUNTER_SST8BIT_INST,    fermi_sw_counter_sst8bit_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { FERMI_SW_COUNTER_SST16BIT_INST,   fermi_sw_counter_sst16bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { FERMI_SW_COUNTER_SST32BIT_INST,   fermi_sw_counter_sst32bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { FERMI_SW_COUNTER_SST64BIT_INST,   fermi_sw_counter_sst64bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { FERMI_SW_COUNTER_SST128BIT_INST,  fermi_sw_counter_sst128bit_inst_enc_str_1,  0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { INVALID_SW_COUNTER,               "",                                         0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX,0 }
};

PerfSignalTableNew PerfSignalTableGFSwCounters_nop_trig[] = {
    // Software counters work for all Fermi chips
    // TO DO: Change this table and make it more suitable for sw counters as most of the fields are not used
    { FERMI_SW_COUNTER_FADD_INST,   fermi_sw_counter_fadd_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,  0x00,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_GPC },
    { FERMI_SW_COUNTER_FMUL_INST,   fermi_sw_counter_fmul_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,  0x00,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_GPC },
    { FERMI_SW_COUNTER_FFMA_INST,   fermi_sw_counter_ffma_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,  0x00,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_GPC },
    { FERMI_SW_COUNTER_DADD_INST,   fermi_sw_counter_dadd_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,  0x00,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_GPC },
    { FERMI_SW_COUNTER_DMUL_INST,   fermi_sw_counter_dmul_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,  0x00,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_GPC },
    { FERMI_SW_COUNTER_DFMA_INST,   fermi_sw_counter_dfma_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,  0x00,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_GPC },
    { FERMI_SW_COUNTER_COS_INST,    fermi_sw_counter_cos_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,  0x00,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_GPC },
    { FERMI_SW_COUNTER_EX2_INST,    fermi_sw_counter_ex2_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,  0x00,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_GPC },
    { FERMI_SW_COUNTER_LG2_INST,    fermi_sw_counter_lg2_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,  0x00,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_GPC },
    { FERMI_SW_COUNTER_RCP_INST,    fermi_sw_counter_rcp_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,  0x00,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_GPC },
    { FERMI_SW_COUNTER_RSQ_INST,    fermi_sw_counter_rsq_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,  0x00,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_GPC },
    { FERMI_SW_COUNTER_SIN_INST,    fermi_sw_counter_sin_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,  0x00,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_CHIPLET_TYPE_GPC },

    { INVALID_SW_COUNTER,           "",             0xffffffff, 0x00000000, 0x00000000,  0x00,   FERMI_CLK_DOMAIN_MAX,          PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE }
};

PerfSignalTableNew PerfSignalTableGFSwCounters_transactions[] = {
    { FERMI_SW_COUNTER_L2_GLOBAL_WRITE_L1_SECTOR_QUERIES,         fermi_sw_counter_l2_global_write_l1_sector_queries_enc_str_1,           0xffffffff, 0x00000000, 0x00000000,  0x00,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, PM_UNIT_MAX,  {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    { FERMI_SW_COUNTER_L2_UCACHED_GLOBAL_READ_L1_SECTOR_QUERIES,  fermi_sw_counter_l2_ucached_global_read_l1_sector_queries_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,  0x00,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, PM_UNIT_MAX,  {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,   PM_CHIPLET_TYPE_GPC },
    { INVALID_SW_COUNTER,           "",             0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 }
};

PerfSignalTableNew PerfSignalTableGFSwCounters_instrClass[] = {
    { FERMI_SW_COUNTER_INSTR_CLASS_FP_32,                       fermi_sw_counter_instr_class_fp_32_enc_str_1                      , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { FERMI_SW_COUNTER_INSTR_CLASS_FP_64,                       fermi_sw_counter_instr_class_fp_64_enc_str_1                      , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { FERMI_SW_COUNTER_INSTR_CLASS_INTEGER,                     fermi_sw_counter_instr_class_integer_enc_str_1                    , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { FERMI_SW_COUNTER_INSTR_CLASS_BIT_CONVERT,                 fermi_sw_counter_instr_class_bit_convert_enc_str_1                , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { FERMI_SW_COUNTER_INSTR_CLASS_CONTROL,                     fermi_sw_counter_instr_class_control_enc_str_1                    , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { FERMI_SW_COUNTER_INSTR_CLASS_COMPUTE_LD_ST,               fermi_sw_counter_instr_class_compute_ld_st_enc_str_1              , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { FERMI_SW_COUNTER_INSTR_CLASS_MISCELLANEOUS,               fermi_sw_counter_instr_class_miscellaneous_enc_str_1              , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { FERMI_SW_COUNTER_INSTR_CLASS_INTER_THREAD_COMMUNICATION,  fermi_sw_counter_instr_class_inter_thread_communication_enc_str_1 , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { INVALID_SW_COUNTER,           "",             0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 }
};

PerfSignalTableNew PerfSignalTableGFSwCounters_genericLdStCounters[] = {
    { FERMI_SW_COUNTER_GENERIC_SHARED_LOAD,           fermi_sw_counter_generic_shared_ld_enc_str_1          , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { FERMI_SW_COUNTER_GENERIC_SHARED_STORE,          fermi_sw_counter_generic_shared_st_enc_str_1          , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { FERMI_SW_COUNTER_GENERIC_LOCAL_LOAD,            fermi_sw_counter_generic_local_ld_enc_str_1           , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { FERMI_SW_COUNTER_GENERIC_LOCAL_STORE,           fermi_sw_counter_generic_local_st_enc_str_1           , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { FERMI_SW_COUNTER_GENERIC_GLOBAL_LOAD,           fermi_sw_counter_generic_global_ld_enc_str_1          , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { FERMI_SW_COUNTER_GENERIC_GLOBAL_STORE,          fermi_sw_counter_generic_global_st_enc_str_1          , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { INVALID_SW_COUNTER,           "",             0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 }
};

PerfSignalTableNew PerfSignalTableGFswCounters_ld_st_inst[] = {
    // Software counters work for all Fermi chips
    // TO DO: Change this table and make it more suitable for sw counters as most of the fields are not used
    { FERMI_INTERNAL_SW_COUNTER_GLD8BIT_INST,    fermi_internal_sw_counter_gld8bit_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,  0x00,   FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_MAX_CHIPLET_TYPES },
    { FERMI_INTERNAL_SW_COUNTER_GLD16BIT_INST,   fermi_internal_sw_counter_gld16bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,  0x00,   FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_MAX_CHIPLET_TYPES },
    { FERMI_INTERNAL_SW_COUNTER_GLD32BIT_INST,   fermi_internal_sw_counter_gld32bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,  0x00,   FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_MAX_CHIPLET_TYPES },
    { FERMI_INTERNAL_SW_COUNTER_GLD64BIT_INST,   fermi_internal_sw_counter_gld64bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,  0x00,   FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_MAX_CHIPLET_TYPES },
    { FERMI_INTERNAL_SW_COUNTER_GLD128BIT_INST,  fermi_internal_sw_counter_gld128bit_inst_enc_str_1,  0xffffffff, 0x00000000, 0x00000000,  0x00,   FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_MAX_CHIPLET_TYPES },
    { FERMI_INTERNAL_SW_COUNTER_GST8BIT_INST,    fermi_internal_sw_counter_gst8bit_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,  0x00,   FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_MAX_CHIPLET_TYPES },
    { FERMI_INTERNAL_SW_COUNTER_GST16BIT_INST,   fermi_internal_sw_counter_gst16bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,  0x00,   FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_MAX_CHIPLET_TYPES },
    { FERMI_INTERNAL_SW_COUNTER_GST32BIT_INST,   fermi_internal_sw_counter_gst32bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,  0x00,   FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_MAX_CHIPLET_TYPES },
    { FERMI_INTERNAL_SW_COUNTER_GST64BIT_INST,   fermi_internal_sw_counter_gst64bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,  0x00,   FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_MAX_CHIPLET_TYPES },
    { FERMI_INTERNAL_SW_COUNTER_GST128BIT_INST,  fermi_internal_sw_counter_gst128bit_inst_enc_str_1,  0xffffffff, 0x00000000, 0x00000000,  0x00,   FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE,      PM_MAX_CHIPLET_TYPES },
    { INVALID_SW_COUNTER,               "",           0xffffffff, 0x00000000, 0x00000000,  0x00,   FERMI_CLK_DOMAIN_MAX,                   PM_UNIT_MAX,    {0,0,0,0,0,0,0,0}, SIG_TYPE_SINGLE }
};

//Internal domains (domains having all internal events) should always be kept at the end of the domaintable.
CUdomainData domainTableGF100[] = {
    {FERMI_CLK_DOMAIN_GF100_GPC0,                 fermi_clk_domain_gf100_gpc0_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_HWPM,       {{PerfSignalTableGF100_gpc0, PERF_SIG_TABLE_TYPE_COMMON}},                     0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_CLK_DOMAIN_GF100_LTC0,                 fermi_clk_domain_gf100_ltc0_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_HWPM,       {{PerfSignalTableGF100_ltc0, PERF_SIG_TABLE_TYPE_COMMON}},                     0,  0,  0,  PM_CHIPLET_TYPE_FBP, 0, 0, 1},
    // Creating separate domain  for sw counters
    // sw counters may also have separate domain types based on type of instrumentation
    {FERMI_NOPTRIG_SW_COUNTERS_DOMAIN,            fermi_noptrig_sw_counters_domain_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW,     {{PerfSignalTableGFNopTrigSwCounters_ld_st_inst, PERF_SIG_TABLE_TYPE_COMMON}}, 0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_CLK_DOMAIN_GF100_SM0,                  fermi_clk_domain_gf100_sm0_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_SMPERF,         {{PerfSignalTableGF100_sm0, PERF_SIG_TABLE_TYPE_COMMON}},                      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF100_PPA_NOPTRIG_FLOPS,     fermi_sw_domain_gf100_ppa_noptrig_flops_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFSwCounters_nop_trig, PERF_SIG_TABLE_TYPE_COMMON}},          0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF100_PPA_NOPTRIG_TRANSACTIONS, fermi_sw_domain_gf100_ppa_noptrig_transactions_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFSwCounters_transactions, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF100_PPA_NOPTRIG_INSTR_CLASS, fermi_sw_domain_gf100_ppa_noptrig_instr_class_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFSwCounters_instrClass, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF100_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS, fermi_sw_domain_gf100_ppa_noptrig_generic_counters_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFSwCounters_genericLdStCounters, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF100_PPA_NOPTRIG_SLD_SST,   fermi_sw_domain_gf100_ppa_noptrig_sld_sst_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFNopTrigSwCounters_sld_sst, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    // domains that are not exposed
    {FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST,         fermi_sw_counters_domain_ld_st_inst_enc_str_1, CUPROF_EVENT_COLLECTION_METHOD_SW,             {{PerfSignalTableGFswCounters_ld_st_inst, PERF_SIG_TABLE_TYPE_COMMON}},        0,  0,  0,  PM_MAX_CHIPLET_TYPES, 0, 0, 1},
    {FERMI_CLK_DOMAIN_GF100_HUB0,                 fermi_clk_domain_gf100_hub0_enc_str_1, CUPROF_EVENT_COLLECTION_METHOD_HWPM,           {{PerfSignalTableGF100_hub0, PERF_SIG_TABLE_TYPE_COMMON}},                     0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 1}
};

CUdomainData domainTableGF104[] = {
    {FERMI_CLK_DOMAIN_GF104_GPC0,                 fermi_clk_domain_gf104_gpc0_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_HWPM,           {{PerfSignalTableGF104_gpc0, PERF_SIG_TABLE_TYPE_COMMON}},                     0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_CLK_DOMAIN_GF104_LTC0,                 fermi_clk_domain_gf104_ltc0_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_HWPM,           {{PerfSignalTableGF104_ltc0, PERF_SIG_TABLE_TYPE_COMMON}},                     0,  0,  0,  PM_CHIPLET_TYPE_FBP, 0, 0, 1},
    // Creating separate domain  for sw counters
    // sw counters may also have separate domain types based on type of instrumentation
    {FERMI_NOPTRIG_SW_COUNTERS_DOMAIN,            fermi_noptrig_sw_counters_domain_enc_str_2,   CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW,     {{PerfSignalTableGFNopTrigSwCounters_ld_st_inst, PERF_SIG_TABLE_TYPE_COMMON}}, 0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_CLK_DOMAIN_GF104_SM0,                  fermi_clk_domain_gf104_sm0_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_SMPERF,         {{PerfSignalTableGF104_sm0, PERF_SIG_TABLE_TYPE_COMMON}},                      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF104_PPA_NOPTRIG_FLOPS,     fermi_sw_domain_gf104_ppa_noptrig_flops_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFSwCounters_nop_trig, PERF_SIG_TABLE_TYPE_COMMON}},          0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF104_PPA_NOPTRIG_TRANSACTIONS, fermi_sw_domain_gf104_ppa_noptrig_transactions_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFSwCounters_transactions, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF104_PPA_NOPTRIG_INSTR_CLASS, fermi_sw_domain_gf104_ppa_noptrig_instr_class_enc_str_2,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFSwCounters_instrClass, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF104_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS, fermi_sw_domain_gf104_ppa_noptrig_generic_counters_enc_str_2,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFSwCounters_genericLdStCounters, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF100_PPA_NOPTRIG_SLD_SST,   fermi_sw_domain_gf100_ppa_noptrig_sld_sst_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFNopTrigSwCounters_sld_sst, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    // domains that are not exposed
    {FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST,         fermi_sw_counters_domain_ld_st_inst_enc_str_2, CUPROF_EVENT_COLLECTION_METHOD_SW,             {{PerfSignalTableGFswCounters_ld_st_inst, PERF_SIG_TABLE_TYPE_COMMON}},        0,  0,  0,  PM_MAX_CHIPLET_TYPES, 0, 0, 1},
    {FERMI_CLK_DOMAIN_GF104_HUB0,                 fermi_clk_domain_gf104_hub0_enc_str_1, CUPROF_EVENT_COLLECTION_METHOD_HWPM,           {{PerfSignalTableGF104_hub0, PERF_SIG_TABLE_TYPE_COMMON}},                     0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 1}
};

CUdomainData domainTableGF108[] = {
    {FERMI_CLK_DOMAIN_GF108_GPC0,                fermi_clk_domain_gf108_gpc0_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_HWPM,            {{PerfSignalTableGF108_gpc0, PERF_SIG_TABLE_TYPE_COMMON}},                     0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_CLK_DOMAIN_GF108_LTC0,                fermi_clk_domain_gf108_ltc0_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_HWPM,            {{PerfSignalTableGF108_ltc0, PERF_SIG_TABLE_TYPE_COMMON}},                     0,  0,  0,  PM_CHIPLET_TYPE_FBP, 0, 0, 1},
    // Creating separate domain  for sw counters
    // sw counters may also have separate domain types based on type of instrumentation
    {FERMI_NOPTRIG_SW_COUNTERS_DOMAIN,            fermi_noptrig_sw_counters_domain_enc_str_3,   CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW,     {{PerfSignalTableGFNopTrigSwCounters_ld_st_inst, PERF_SIG_TABLE_TYPE_COMMON}}, 0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_CLK_DOMAIN_GF108_SM0,                  fermi_clk_domain_gf108_sm0_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_SMPERF,         {{PerfSignalTableGF108_sm0, PERF_SIG_TABLE_TYPE_COMMON}},                      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF108_PPA_NOPTRIG_FLOPS,     fermi_sw_domain_gf108_ppa_noptrig_flops_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFSwCounters_nop_trig, PERF_SIG_TABLE_TYPE_COMMON}},          0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF108_PPA_NOPTRIG_TRANSACTIONS, fermi_sw_domain_gf108_ppa_noptrig_transactions_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFSwCounters_transactions, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF108_PPA_NOPTRIG_INSTR_CLASS, fermi_sw_domain_gf108_ppa_noptrig_instr_class_enc_str_3,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFSwCounters_instrClass, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF108_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS, fermi_sw_domain_gf108_ppa_noptrig_generic_counters_enc_str_3,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFSwCounters_genericLdStCounters, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF100_PPA_NOPTRIG_SLD_SST,   fermi_sw_domain_gf100_ppa_noptrig_sld_sst_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFNopTrigSwCounters_sld_sst, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    // domains that are not exposed
    {FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST,         fermi_sw_counters_domain_ld_st_inst_enc_str_3, CUPROF_EVENT_COLLECTION_METHOD_SW,             {{PerfSignalTableGFswCounters_ld_st_inst, PERF_SIG_TABLE_TYPE_COMMON}},        0,  0,  0,  PM_MAX_CHIPLET_TYPES, 0, 0, 1},
    {FERMI_CLK_DOMAIN_GF108_HUB0,                 fermi_clk_domain_gf108_hub0_enc_str_1, CUPROF_EVENT_COLLECTION_METHOD_HWPM,           {{PerfSignalTableGF108_hub0, PERF_SIG_TABLE_TYPE_COMMON}},                     0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 1}
};

// please change gf119 domain ids in function getClkIdx() if you happen to change
// gf108 domain ids in gf119 domain table
CUdomainData domainTableGF119[] = {
    {FERMI_CLK_DOMAIN_GF108_GPC0,                fermi_clk_domain_gf108_gpc0_enc_str_2,   CUPROF_EVENT_COLLECTION_METHOD_HWPM,            {{PerfSignalTableGF108_gpc0, PERF_SIG_TABLE_TYPE_COMMON}},                     0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_CLK_DOMAIN_GF119_LTC0,                fermi_clk_domain_gf119_ltc0_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_HWPM,            {{PerfSignalTableGF119_ltc0, PERF_SIG_TABLE_TYPE_COMMON}},                     0,  0,  0,  PM_CHIPLET_TYPE_FBP, 0, 0, 1},
    // Creating separate domain  for sw counters
    // sw counters may also have separate domain types based on type of instrumentation
    {FERMI_NOPTRIG_SW_COUNTERS_DOMAIN,            fermi_noptrig_sw_counters_domain_enc_str_4,   CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW,     {{PerfSignalTableGFNopTrigSwCounters_ld_st_inst, PERF_SIG_TABLE_TYPE_COMMON}}, 0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_CLK_DOMAIN_GF108_SM0,                  fermi_clk_domain_gf108_sm0_enc_str_2,   CUPROF_EVENT_COLLECTION_METHOD_SMPERF,         {{PerfSignalTableGF108_sm0, PERF_SIG_TABLE_TYPE_COMMON}},                      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF119_PPA_NOPTRIG_FLOPS,     fermi_sw_domain_gf119_ppa_noptrig_flops_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFSwCounters_nop_trig, PERF_SIG_TABLE_TYPE_COMMON}},          0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF119_PPA_NOPTRIG_TRANSACTIONS, fermi_sw_domain_gf119_ppa_noptrig_transactions_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFSwCounters_transactions, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF119_PPA_NOPTRIG_INSTR_CLASS, fermi_sw_domain_gf119_ppa_noptrig_instr_class_enc_str_4,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFSwCounters_instrClass, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF119_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS, fermi_sw_domain_gf119_ppa_noptrig_generic_counters_enc_str_4,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFSwCounters_genericLdStCounters, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF100_PPA_NOPTRIG_SLD_SST,   fermi_sw_domain_gf100_ppa_noptrig_sld_sst_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFNopTrigSwCounters_sld_sst, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    // domains that are not exposed
    {FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST,         fermi_sw_counters_domain_ld_st_inst_enc_str_4, CUPROF_EVENT_COLLECTION_METHOD_SW,             {{PerfSignalTableGFswCounters_ld_st_inst, PERF_SIG_TABLE_TYPE_COMMON}},        0,  0,  0,  PM_MAX_CHIPLET_TYPES, 0, 0, 1},
    {FERMI_CLK_DOMAIN_GF108_HUB0,                 fermi_clk_domain_gf108_hub0_enc_str_2, CUPROF_EVENT_COLLECTION_METHOD_HWPM,           {{PerfSignalTableGF108_hub0, PERF_SIG_TABLE_TYPE_COMMON}},                     0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 1}

};

CUdomainData domainTableGF117[] = {
    {FERMI_CLK_DOMAIN_GF108_GPC0,                 fermi_clk_domain_gf108_gpc0_enc_str_3,   CUPROF_EVENT_COLLECTION_METHOD_HWPM,           {{PerfSignalTableGF108_gpc0, PERF_SIG_TABLE_TYPE_COMMON}},                     0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_CLK_DOMAIN_GF117_LTC0,                 fermi_clk_domain_gf117_ltc0_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_HWPM,           {{PerfSignalTableGF117_ltc0, PERF_SIG_TABLE_TYPE_COMMON}},                     0,  0,  0,  PM_CHIPLET_TYPE_FBP, 0, 0, 1},
    // Creating separate domain  for sw counters
    // sw counters may also have separate domain types based on type of instrumentation
    {FERMI_NOPTRIG_SW_COUNTERS_DOMAIN,            fermi_noptrig_sw_counters_domain_enc_str_5,   CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW,     {{PerfSignalTableGFNopTrigSwCounters_ld_st_inst, PERF_SIG_TABLE_TYPE_COMMON}}, 0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_CLK_DOMAIN_GF108_SM0,                  fermi_clk_domain_gf108_sm0_enc_str_3,   CUPROF_EVENT_COLLECTION_METHOD_SMPERF,         {{PerfSignalTableGF108_sm0, PERF_SIG_TABLE_TYPE_COMMON}},                      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF117_PPA_NOPTRIG_FLOPS,     fermi_sw_domain_gf117_ppa_noptrig_flops_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFSwCounters_nop_trig, PERF_SIG_TABLE_TYPE_COMMON}},          0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF117_PPA_NOPTRIG_TRANSACTIONS, fermi_sw_domain_gf117_ppa_noptrig_transactions_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFSwCounters_transactions, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF117_PPA_NOPTRIG_INSTR_CLASS, fermi_sw_domain_gf117_ppa_noptrig_instr_class_enc_str_5,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFSwCounters_instrClass, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF117_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS, fermi_sw_domain_gf117_ppa_noptrig_generic_counters_enc_str_5,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFSwCounters_genericLdStCounters, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {FERMI_SW_DOMAIN_GF100_PPA_NOPTRIG_SLD_SST,   fermi_sw_domain_gf100_ppa_noptrig_sld_sst_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGFNopTrigSwCounters_sld_sst, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    // domains that are not exposed
    {FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST,         fermi_sw_counters_domain_ld_st_inst_enc_str_5, CUPROF_EVENT_COLLECTION_METHOD_SW,             {{PerfSignalTableGFswCounters_ld_st_inst, PERF_SIG_TABLE_TYPE_COMMON}},        0,  0,  0,  PM_MAX_CHIPLET_TYPES, 0, 0, 1},
    {FERMI_CLK_DOMAIN_GF108_HUB0,                 fermi_clk_domain_gf108_hub0_enc_str_3, CUPROF_EVENT_COLLECTION_METHOD_HWPM,           {{PerfSignalTableGF108_hub0, PERF_SIG_TABLE_TYPE_COMMON}},                     0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 1}

};

SignalDescriptionTable pFermiSignalDescriptionArray[] = {
    {FERMI_AGU_L1_LOCAL_LD,fermi_agu_l1_local_ld_enc_str_1, fermi_agu_l1_local_ld_enc_str_5,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_agu_l1_local_ld_enc_str_6},
    {FERMI_AGU_L1_LOCAL_ST,fermi_agu_l1_local_st_enc_str_1, fermi_agu_l1_local_st_enc_str_5,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_agu_l1_local_st_enc_str_6},
    {FERMI_AGU_L1_GLOBAL_LD,fermi_agu_l1_global_ld_enc_str_1, fermi_agu_l1_global_ld_enc_str_5,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_agu_l1_global_ld_enc_str_6},
    {FERMI_AGU_L1_GLOBAL_ST,fermi_agu_l1_global_st_enc_str_1, fermi_agu_l1_global_st_enc_str_5,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_agu_l1_global_st_enc_str_6},
    {FERMI_AGU_L1_SHARED_LD,fermi_agu_l1_shared_ld_enc_str_1, fermi_agu_l1_shared_ld_enc_str_5,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_agu_l1_shared_ld_enc_str_6},
    {FERMI_AGU_L1_SHARED_ST,fermi_agu_l1_shared_st_enc_str_1, fermi_agu_l1_shared_st_enc_str_5,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_agu_l1_shared_st_enc_str_6},

    {FERMI_FET_UNIQUE_BRANCHES,fermi_fet_unique_branches_enc_str_1, fermi_fet_unique_branches_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_fet_unique_branches_enc_str_6},

    {FERMI_FET_DIVERGED_BRANCHES,fermi_fet_diverged_branches_enc_str_1, fermi_fet_diverged_branches_enc_str_5,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_fet_diverged_branches_enc_str_6},

    {FERMI_FET_ANY_ACTIVE,fermi_fet_any_active_enc_str_1, fermi_fet_any_active_enc_str_5,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_fet_any_active_enc_str_6},

    {FERMI_SCH_INST_ISSUED,fermi_sch_inst_issued_enc_str_1, fermi_sch_inst_issued_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sch_inst_issued_enc_str_4},

    {FERMI_SCH_EVEN_INST_ISSUED_1,fermi_sch_even_inst_issued_1_enc_str_1, fermi_sch_even_inst_issued_1_enc_str_4,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sch_even_inst_issued_1_enc_str_5},
    {FERMI_SCH_EVEN_INST_ISSUED_2,fermi_sch_even_inst_issued_2_enc_str_1, fermi_sch_even_inst_issued_2_enc_str_4,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sch_even_inst_issued_2_enc_str_5},
    {FERMI_SCH_ODD_INST_ISSUED_1,fermi_sch_odd_inst_issued_1_enc_str_1, fermi_sch_odd_inst_issued_1_enc_str_4,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sch_odd_inst_issued_1_enc_str_5},
    {FERMI_SCH_ODD_INST_ISSUED_2,fermi_sch_odd_inst_issued_2_enc_str_1, fermi_sch_odd_inst_issued_2_enc_str_4,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sch_odd_inst_issued_2_enc_str_5},

    {FERMI_SCH_INST_DECODED,fermi_sch_inst_decoded_enc_str_1, fermi_sch_inst_decoded_enc_str_5,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sch_inst_decoded_enc_str_6},
    {FERMI_SCH_EVEN_THREAD_INST_DECODED,fermi_sch_even0_thread_inst_decoded_enc_str_1, fermi_sch_even0_thread_inst_decoded_enc_str_4,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sch_even0_thread_inst_decoded_enc_str_5},
    {FERMI_SCH_ODD_THREAD_INST_DECODED,fermi_sch_odd0_thread_inst_decoded_enc_str_1, fermi_sch_odd0_thread_inst_decoded_enc_str_4,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sch_odd0_thread_inst_decoded_enc_str_5},

    {FERMI_SCH_WARPS_LAUNCHED,fermi_sch_warps_launched_enc_str_1, fermi_sch_warps_launched_enc_str_5,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sch_warps_launched_enc_str_6},
    {FERMI_SCH_THREADS_LAUNCHED,fermi_sch_threads_launched_enc_str_1, fermi_sch_threads_launched_enc_str_5,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sch_threads_launched_enc_str_6},

    {FERMI_SCH_ACTIVE_WARPS,fermi_sch_active_warps_enc_str_1, fermi_sch_active_warps_enc_str_5,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sch_active_warps_enc_str_6},

    {FERMI_TEX_CACHE_SECTOR_QUERIES,fermi_tex_cache_sector_queries_enc_str_1, fermi_tex_cache_sector_queries_enc_str_5,  CUPROF_EVENT_CATEGORY_CACHE,fermi_tex_cache_sector_queries_enc_str_6},
    {FERMI_TEX_CACHE_SECTOR_MISSES,fermi_tex_cache_sector_misses_enc_str_1, fermi_tex_cache_sector_misses_enc_str_5,  CUPROF_EVENT_CATEGORY_CACHE,fermi_tex_cache_sector_misses_enc_str_6},
    {FERMI_TEX1_CACHE_SECTOR_QUERIES,fermi_tex1_cache_sector_queries_enc_str_1, fermi_tex1_cache_sector_queries_enc_str_4,  CUPROF_EVENT_CATEGORY_CACHE,fermi_tex1_cache_sector_queries_enc_str_5},
    {FERMI_TEX1_CACHE_SECTOR_MISSES,fermi_tex1_cache_sector_misses_enc_str_1, fermi_tex1_cache_sector_misses_enc_str_4,  CUPROF_EVENT_CATEGORY_CACHE,fermi_tex1_cache_sector_misses_enc_str_5},

    // MPC Signals
    {FERMI_MPC_TOTAL_CTAS_LAUNCHED,fermi_mpc_total_ctas_launched_enc_str_1, fermi_mpc_total_ctas_launched_enc_str_5,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_mpc_total_ctas_launched_enc_str_6},
    // L1C Signals
    {FERMI_L1C_SHARED_LOAD_TRANSACTIONS,fermi_l1c_shared_load_transactions_enc_str_1, fermi_l1c_shared_load_transactions_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE,fermi_l1c_shared_load_transactions_enc_str_6},
    {FERMI_L1C_SHARED_STORE_TRANSACTIONS,fermi_l1c_shared_store_transactions_enc_str_1,fermi_l1c_shared_store_transactions_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE,fermi_l1c_shared_store_transactions_enc_str_6},
    {FERMI_L1C_LOCAL_LOAD_HIT,fermi_l1c_local_load_hit_enc_str_1, fermi_l1c_local_load_hit_enc_str_5,  CUPROF_EVENT_CATEGORY_CACHE,fermi_l1c_local_load_hit_enc_str_6},
    {FERMI_L1C_LOCAL_LOAD_MISS,fermi_l1c_local_load_miss_enc_str_1, fermi_l1c_local_load_miss_enc_str_5,  CUPROF_EVENT_CATEGORY_CACHE,fermi_l1c_local_load_miss_enc_str_6},
    {FERMI_L1C_LOCAL_STORE_HIT,fermi_l1c_local_store_hit_enc_str_1, fermi_l1c_local_store_hit_enc_str_5,  CUPROF_EVENT_CATEGORY_CACHE,fermi_l1c_local_store_hit_enc_str_6},
    {FERMI_L1C_LOCAL_STORE_MISS,fermi_l1c_local_store_miss_enc_str_1, fermi_l1c_local_store_miss_enc_str_5,  CUPROF_EVENT_CATEGORY_CACHE,fermi_l1c_local_store_miss_enc_str_6},
    {FERMI_L1C_PARTIAL_LOCAL_STORE_MISS,fermi_l1c_partial_local_store_miss_enc_str_1,fermi_l1c_partial_local_store_miss_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE,fermi_l1c_partial_local_store_miss_enc_str_6},
    {FERMI_L1C_GLOBAL_LOAD_HIT,fermi_l1c_global_load_hit_enc_str_1, fermi_l1c_global_load_hit_enc_str_5,  CUPROF_EVENT_CATEGORY_CACHE,fermi_l1c_global_load_hit_enc_str_6},
    {FERMI_L1C_GLOBAL_LOAD_MISS,fermi_l1c_global_load_miss_enc_str_1, fermi_l1c_global_load_miss_enc_str_5,  CUPROF_EVENT_CATEGORY_CACHE,fermi_l1c_global_load_miss_enc_str_6},
    {FERMI_L1C_DIRTY_LINE_EVICTION,fermi_l1c_dirty_line_eviction_enc_str_1, fermi_l1c_dirty_line_eviction_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, fermi_l1c_dirty_line_eviction_enc_str_6 },
    {FERMI_L1C_UNCACHED_GLOBAL_LOAD,fermi_l1c_uncached_global_load_enc_str_1, fermi_l1c_uncached_global_load_enc_str_5,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_l1c_uncached_global_load_enc_str_6},
    {FERMI_L1C_GLOBAL_STORE,fermi_l1c_global_store_enc_str_1, fermi_l1c_global_store_enc_str_5,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_l1c_global_store_enc_str_6},
    {FERMI_L1C_DEFER_SHARED_BANK_CONFLICT,fermi_l1c_defer_shared_bank_conflict_enc_str_1, fermi_l1c_defer_shared_bank_conflict_enc_str_5,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_l1c_defer_shared_bank_conflict_enc_str_6},

    {FERMI_SM_L1C_ATOM_COUNT,     fermi_sm_l1c_atom_count_enc_str_1, fermi_sm_l1c_atom_count_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE,fermi_sm_l1c_atom_count_enc_str_6},
    {FERMI_SM_L1C_GRED_COUNT,     fermi_sm_l1c_gred_count_enc_str_1, fermi_sm_l1c_gred_count_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE,fermi_sm_l1c_gred_count_enc_str_6},

    {FERMI_NOP_TRIG_00,fermi_nop_trig_00_enc_str_1, fermi_nop_trig_00_enc_str_5,  CUPROF_EVENT_CATEGORY_PROF_TRIG,fermi_nop_trig_00_enc_str_6},
    {FERMI_NOP_TRIG_01,fermi_nop_trig_01_enc_str_1, fermi_nop_trig_01_enc_str_5,  CUPROF_EVENT_CATEGORY_PROF_TRIG,fermi_nop_trig_00_enc_str_6},
    {FERMI_NOP_TRIG_02,fermi_nop_trig_02_enc_str_1, fermi_nop_trig_02_enc_str_5,  CUPROF_EVENT_CATEGORY_PROF_TRIG,fermi_nop_trig_00_enc_str_6},
    {FERMI_NOP_TRIG_03,fermi_nop_trig_03_enc_str_1, fermi_nop_trig_03_enc_str_5,  CUPROF_EVENT_CATEGORY_PROF_TRIG,fermi_nop_trig_00_enc_str_6},
    {FERMI_NOP_TRIG_04,fermi_nop_trig_04_enc_str_1, fermi_nop_trig_04_enc_str_5,  CUPROF_EVENT_CATEGORY_PROF_TRIG,fermi_nop_trig_00_enc_str_6},
    {FERMI_NOP_TRIG_05,fermi_nop_trig_05_enc_str_1, fermi_nop_trig_05_enc_str_5,  CUPROF_EVENT_CATEGORY_PROF_TRIG,fermi_nop_trig_00_enc_str_6},
    {FERMI_NOP_TRIG_06,fermi_nop_trig_06_enc_str_1, fermi_nop_trig_06_enc_str_5,  CUPROF_EVENT_CATEGORY_PROF_TRIG,fermi_nop_trig_00_enc_str_6},
    {FERMI_NOP_TRIG_07,fermi_nop_trig_07_enc_str_1, fermi_nop_trig_07_enc_str_5,  CUPROF_EVENT_CATEGORY_PROF_TRIG,fermi_nop_trig_00_enc_str_6},

    {FERMI_SCH_EVEN0_THREAD_INST_DECODED,fermi_sch_even0_thread_inst_decoded_enc_str_1, fermi_sch_even0_thread_inst_decoded_enc_str_4,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sch_even0_thread_inst_decoded_enc_str_5},
    {FERMI_SCH_EVEN1_THREAD_INST_DECODED,fermi_sch_even1_thread_inst_decoded_enc_str_1, fermi_sch_even1_thread_inst_decoded_enc_str_4,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sch_even1_thread_inst_decoded_enc_str_5},
    {FERMI_SCH_ODD0_THREAD_INST_DECODED,fermi_sch_odd0_thread_inst_decoded_enc_str_1, fermi_sch_odd0_thread_inst_decoded_enc_str_4,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sch_odd0_thread_inst_decoded_enc_str_5},
    {FERMI_SCH_ODD1_THREAD_INST_DECODED,fermi_sch_odd1_thread_inst_decoded_enc_str_1, fermi_sch_odd1_thread_inst_decoded_enc_str_4,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sch_odd1_thread_inst_decoded_enc_str_5},

    {FERMI_FB_SUBP0_DRAMC_READ,fermi_fb_subp0_dramc_read_enc_str_1, fermi_fb_subp0_dramc_read_enc_str_6,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_fb_subp0_dramc_read_enc_str_7},
    {FERMI_FB_SUBP1_DRAMC_READ,fermi_fb_subp1_dramc_read_enc_str_1, fermi_fb_subp1_dramc_read_enc_str_6,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_fb_subp1_dramc_read_enc_str_7},
    {FERMI_FB_SUBP0_DRAMC_WRITE,fermi_fb_subp0_dramc_write_enc_str_1, fermi_fb_subp0_dramc_write_enc_str_6,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_fb_subp0_dramc_write_enc_str_7},
    {FERMI_FB_SUBP1_DRAMC_WRITE,fermi_fb_subp1_dramc_write_enc_str_1, fermi_fb_subp1_dramc_write_enc_str_6,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_fb_subp1_dramc_write_enc_str_7},

    {FERMI_FB0_SUBP0_DRAMC_READ,fermi_fb0_subp0_dramc_read_enc_str_1, fermi_fb0_subp0_dramc_read_enc_str_3,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_fb0_subp0_dramc_read_enc_str_4},
    {FERMI_FB0_SUBP1_DRAMC_READ,fermi_fb0_subp1_dramc_read_enc_str_1, fermi_fb0_subp1_dramc_read_enc_str_3,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_fb0_subp1_dramc_read_enc_str_4},
    {FERMI_FB0_SUBP0_DRAMC_WRITE,fermi_fb0_subp0_dramc_write_enc_str_1, fermi_fb0_subp0_dramc_write_enc_str_3,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_fb0_subp0_dramc_write_enc_str_4},
    {FERMI_FB0_SUBP1_DRAMC_WRITE,fermi_fb0_subp1_dramc_write_enc_str_1, fermi_fb0_subp1_dramc_write_enc_str_3,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_fb0_subp1_dramc_write_enc_str_4},

    {FERMI_FB1_SUBP0_DRAMC_READ,fermi_fb1_subp0_dramc_read_enc_str_1, fermi_fb1_subp0_dramc_read_enc_str_3,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_fb1_subp0_dramc_read_enc_str_4},
    {FERMI_FB1_SUBP1_DRAMC_READ,fermi_fb1_subp1_dramc_read_enc_str_1, fermi_fb1_subp1_dramc_read_enc_str_3,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_fb1_subp1_dramc_read_enc_str_4},
    {FERMI_FB1_SUBP0_DRAMC_WRITE,fermi_fb1_subp0_dramc_write_enc_str_1, fermi_fb1_subp0_dramc_write_enc_str_3,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_fb1_subp0_dramc_write_enc_str_4},
    {FERMI_FB1_SUBP1_DRAMC_WRITE,fermi_fb1_subp1_dramc_write_enc_str_1, fermi_fb1_subp1_dramc_write_enc_str_3,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_fb1_subp1_dramc_write_enc_str_4},

    {FERMI_LTC0_WRITE_MISS_SECTORS,fermi_ltc0_write_miss_sectors_enc_str_1, fermi_ltc0_write_miss_sectors_enc_str_7,  CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc0_write_miss_sectors_enc_str_8},
    {FERMI_LTC1_WRITE_MISS_SECTORS,fermi_ltc1_write_miss_sectors_enc_str_1, fermi_ltc1_write_miss_sectors_enc_str_6,  CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc1_write_miss_sectors_enc_str_7},
    {FERMI_LTC0_READ_MISS_SECTORS,fermi_ltc0_read_miss_sectors_enc_str_1, fermi_ltc0_read_miss_sectors_enc_str_7,  CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc0_read_miss_sectors_enc_str_8},
    {FERMI_LTC1_READ_MISS_SECTORS,fermi_ltc1_read_miss_sectors_enc_str_1, fermi_ltc1_read_miss_sectors_enc_str_6,  CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc1_read_miss_sectors_enc_str_7},

    {FERMI_LTC0_WRITE_SECTORS_FBP,fermi_ltc0_write_sectors_fbp_enc_str_1, fermi_ltc0_write_sectors_fbp_enc_str_7,  CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc0_write_sectors_fbp_enc_str_8},
    {FERMI_LTC1_WRITE_SECTORS_FBP,fermi_ltc1_write_sectors_fbp_enc_str_1, fermi_ltc1_write_sectors_fbp_enc_str_6,  CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc1_write_sectors_fbp_enc_str_7},
    {FERMI_LTC0_READ_SECTORS_FBP,fermi_ltc0_read_sectors_fbp_enc_str_1, fermi_ltc0_read_sectors_fbp_enc_str_7,  CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc0_read_sectors_fbp_enc_str_8},
    {FERMI_LTC1_READ_SECTORS_FBP,fermi_ltc1_read_sectors_fbp_enc_str_1, fermi_ltc1_read_sectors_fbp_enc_str_6,  CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc1_read_sectors_fbp_enc_str_7},
    {FERMI_LTC0_READ_TEX_SECTORS_FBP,fermi_ltc0_read_tex_sectors_fbp_enc_str_1, fermi_ltc0_read_tex_sectors_fbp_enc_str_7,  CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc0_read_tex_sectors_fbp_enc_str_8},
    {FERMI_LTC1_READ_TEX_SECTORS_FBP,fermi_ltc1_read_tex_sectors_fbp_enc_str_1, fermi_ltc1_read_tex_sectors_fbp_enc_str_6,  CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc1_read_tex_sectors_fbp_enc_str_7},

    {FERMI_LTC0_READ_CB_SECTORS_FBP,fermi_ltc0_read_cb_sectors_fbp_enc_str_1, fermi_ltc0_read_cb_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc0_read_cb_sectors_fbp_enc_str_8},
    {FERMI_LTC1_READ_CB_SECTORS_FBP,fermi_ltc1_read_cb_sectors_fbp_enc_str_1, fermi_ltc1_read_cb_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc1_read_cb_sectors_fbp_enc_str_6},
    {FERMI_LTC0_WRITE_CB_SECTORS_FBP,fermi_ltc0_write_cb_sectors_fbp_enc_str_1, fermi_ltc0_write_cb_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc0_write_cb_sectors_fbp_enc_str_8},
    {FERMI_LTC1_WRITE_CB_SECTORS_FBP,fermi_ltc1_write_cb_sectors_fbp_enc_str_1, fermi_ltc1_write_cb_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc1_write_cb_sectors_fbp_enc_str_6},

    // Software counters to count ld/st instructions
    {FERMI_SW_COUNTER_GLD8BIT_INST,fermi_sw_counter_gld8bit_inst_enc_str_1, fermi_sw_counter_gld8bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_internal_sw_counter_gld8bit_inst_enc_str_4},
    {FERMI_SW_COUNTER_GLD16BIT_INST,fermi_sw_counter_gld16bit_inst_enc_str_1, fermi_sw_counter_gld16bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_internal_sw_counter_gld16bit_inst_enc_str_4},
    {FERMI_SW_COUNTER_GLD32BIT_INST,fermi_sw_counter_gld32bit_inst_enc_str_1, fermi_sw_counter_gld32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_internal_sw_counter_gld32bit_inst_enc_str_4},
    {FERMI_SW_COUNTER_GLD64BIT_INST,fermi_sw_counter_gld64bit_inst_enc_str_1, fermi_sw_counter_gld64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_internal_sw_counter_gld64bit_inst_enc_str_4},
    {FERMI_SW_COUNTER_GLD128BIT_INST,fermi_sw_counter_gld128bit_inst_enc_str_1, fermi_sw_counter_gld128bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_internal_sw_counter_gld128bit_inst_enc_str_4},
    {FERMI_SW_COUNTER_GST8BIT_INST,fermi_sw_counter_gst8bit_inst_enc_str_1, fermi_sw_counter_gst8bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_internal_sw_counter_gst8bit_inst_enc_str_4},
    {FERMI_SW_COUNTER_GST16BIT_INST,fermi_sw_counter_gst16bit_inst_enc_str_1, fermi_sw_counter_gst16bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_internal_sw_counter_gst16bit_inst_enc_str_4},
    {FERMI_SW_COUNTER_GST32BIT_INST,fermi_sw_counter_gst32bit_inst_enc_str_1, fermi_sw_counter_gst32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_internal_sw_counter_gst32bit_inst_enc_str_4},
    {FERMI_SW_COUNTER_GST64BIT_INST,fermi_sw_counter_gst64bit_inst_enc_str_1, fermi_sw_counter_gst64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_internal_sw_counter_gst64bit_inst_enc_str_4},
    {FERMI_SW_COUNTER_GST128BIT_INST,fermi_sw_counter_gst128bit_inst_enc_str_1, fermi_sw_counter_gst128bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_internal_sw_counter_gst128bit_inst_enc_str_4},

    // Software counters to count shared load/store instructions
    {FERMI_SW_COUNTER_SLD8BIT_INST,fermi_sw_counter_sld8bit_inst_enc_str_1, fermi_sw_counter_sld8bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_sw_counter_sld8bit_inst_enc_str_4},
    {FERMI_SW_COUNTER_SLD16BIT_INST,fermi_sw_counter_sld16bit_inst_enc_str_1, fermi_sw_counter_sld16bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_sw_counter_sld16bit_inst_enc_str_4},
    {FERMI_SW_COUNTER_SLD32BIT_INST,fermi_sw_counter_sld32bit_inst_enc_str_1, fermi_sw_counter_sld32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_sw_counter_sld32bit_inst_enc_str_4},
    {FERMI_SW_COUNTER_SLD64BIT_INST,fermi_sw_counter_sld64bit_inst_enc_str_1, fermi_sw_counter_sld64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_sw_counter_sld64bit_inst_enc_str_4},
    {FERMI_SW_COUNTER_SLD128BIT_INST,fermi_sw_counter_sld128bit_inst_enc_str_1, fermi_sw_counter_sld128bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_sw_counter_sld128bit_inst_enc_str_4},
    {FERMI_SW_COUNTER_SST8BIT_INST,fermi_sw_counter_sst8bit_inst_enc_str_1, fermi_sw_counter_sst8bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_sw_counter_sst8bit_inst_enc_str_4},
    {FERMI_SW_COUNTER_SST16BIT_INST,fermi_sw_counter_sst16bit_inst_enc_str_1, fermi_sw_counter_sst16bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_sw_counter_sst16bit_inst_enc_str_4},
    {FERMI_SW_COUNTER_SST32BIT_INST,fermi_sw_counter_sst32bit_inst_enc_str_1, fermi_sw_counter_sst32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_sw_counter_sst32bit_inst_enc_str_4},
    {FERMI_SW_COUNTER_SST64BIT_INST,fermi_sw_counter_sst64bit_inst_enc_str_1, fermi_sw_counter_sst64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_sw_counter_sst64bit_inst_enc_str_4},
    {FERMI_SW_COUNTER_SST128BIT_INST,fermi_sw_counter_sst128bit_inst_enc_str_1, fermi_sw_counter_sst128bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_sw_counter_sst128bit_inst_enc_str_4},

    // Software counters to count the transactions
    {FERMI_SW_COUNTER_L2_GLOBAL_WRITE_L1_SECTOR_QUERIES,  fermi_sw_counter_l2_global_write_l1_sector_queries_enc_str_1, fermi_sw_counter_l2_global_write_l1_sector_queries_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY,fermi_sw_counter_l2_global_write_l1_sector_queries_enc_str_4},
    {FERMI_SW_COUNTER_L2_UCACHED_GLOBAL_READ_L1_SECTOR_QUERIES,  fermi_sw_counter_l2_ucached_global_read_l1_sector_queries_enc_str_1, fermi_sw_counter_l2_ucached_global_read_l1_sector_queries_enc_str_1,CUPROF_EVENT_CATEGORY_MEMORY,fermi_sw_counter_l2_ucached_global_read_l1_sector_queries_enc_str_4},

    // Software counters to count the number of instructions executed from a particular instruction class:
    { FERMI_SW_COUNTER_INSTR_CLASS_FP_32,                       fermi_sw_counter_instr_class_fp_32_enc_str_1                      , fermi_sw_counter_instr_class_fp_32_enc_str_1                      , CUPROF_EVENT_CATEGORY_INSTRUCTION, fermi_sw_counter_instr_class_fp_32_enc_str_4},
    { FERMI_SW_COUNTER_INSTR_CLASS_FP_64,                       fermi_sw_counter_instr_class_fp_64_enc_str_1                      , fermi_sw_counter_instr_class_fp_64_enc_str_1                      , CUPROF_EVENT_CATEGORY_INSTRUCTION, fermi_sw_counter_instr_class_fp_64_enc_str_4},
    { FERMI_SW_COUNTER_INSTR_CLASS_INTEGER,                     fermi_sw_counter_instr_class_integer_enc_str_1                    , fermi_sw_counter_instr_class_integer_enc_str_1                    , CUPROF_EVENT_CATEGORY_INSTRUCTION, fermi_sw_counter_instr_class_integer_enc_str_4},
    { FERMI_SW_COUNTER_INSTR_CLASS_BIT_CONVERT,                 fermi_sw_counter_instr_class_bit_convert_enc_str_1                , fermi_sw_counter_instr_class_bit_convert_enc_str_1                , CUPROF_EVENT_CATEGORY_INSTRUCTION, fermi_sw_counter_instr_class_bit_convert_enc_str_4},
    { FERMI_SW_COUNTER_INSTR_CLASS_CONTROL,                     fermi_sw_counter_instr_class_control_enc_str_1                    , fermi_sw_counter_instr_class_control_enc_str_1                    , CUPROF_EVENT_CATEGORY_INSTRUCTION, fermi_sw_counter_instr_class_control_enc_str_4},
    { FERMI_SW_COUNTER_INSTR_CLASS_COMPUTE_LD_ST,               fermi_sw_counter_instr_class_compute_ld_st_enc_str_1              , fermi_sw_counter_instr_class_compute_ld_st_enc_str_1              , CUPROF_EVENT_CATEGORY_INSTRUCTION, fermi_sw_counter_instr_class_compute_ld_st_enc_str_4},
    { FERMI_SW_COUNTER_INSTR_CLASS_MISCELLANEOUS,               fermi_sw_counter_instr_class_miscellaneous_enc_str_1              , fermi_sw_counter_instr_class_miscellaneous_enc_str_1              , CUPROF_EVENT_CATEGORY_INSTRUCTION, fermi_sw_counter_instr_class_miscellaneous_enc_str_4},
    { FERMI_SW_COUNTER_INSTR_CLASS_INTER_THREAD_COMMUNICATION,  fermi_sw_counter_instr_class_inter_thread_communication_enc_str_1 , fermi_sw_counter_instr_class_inter_thread_communication_enc_str_1 , CUPROF_EVENT_CATEGORY_INSTRUCTION, fermi_sw_counter_instr_class_inter_thread_communication_enc_str_4},

    // Software counters to count the different load/stores from the generic accesses
    { FERMI_SW_COUNTER_GENERIC_SHARED_LOAD,                fermi_sw_counter_generic_shared_ld_enc_str_1               , fermi_sw_counter_generic_shared_ld_enc_str_1               , CUPROF_EVENT_CATEGORY_INSTRUCTION, fermi_sw_counter_generic_shared_ld_enc_str_4},
    { FERMI_SW_COUNTER_GENERIC_SHARED_STORE,               fermi_sw_counter_generic_shared_st_enc_str_1               , fermi_sw_counter_generic_shared_st_enc_str_1               , CUPROF_EVENT_CATEGORY_INSTRUCTION, fermi_sw_counter_generic_shared_ld_enc_str_4},
    { FERMI_SW_COUNTER_GENERIC_LOCAL_LOAD,                 fermi_sw_counter_generic_local_ld_enc_str_1                , fermi_sw_counter_generic_local_ld_enc_str_1                , CUPROF_EVENT_CATEGORY_INSTRUCTION, fermi_sw_counter_generic_local_ld_enc_str_4},
    { FERMI_SW_COUNTER_GENERIC_LOCAL_STORE,                fermi_sw_counter_generic_local_st_enc_str_1                , fermi_sw_counter_generic_local_st_enc_str_1                , CUPROF_EVENT_CATEGORY_INSTRUCTION, fermi_sw_counter_generic_local_ld_enc_str_4},
    { FERMI_SW_COUNTER_GENERIC_GLOBAL_LOAD,                fermi_sw_counter_generic_global_ld_enc_str_1               , fermi_sw_counter_generic_global_ld_enc_str_1               , CUPROF_EVENT_CATEGORY_INSTRUCTION, fermi_sw_counter_generic_global_ld_enc_str_4},
    { FERMI_SW_COUNTER_GENERIC_GLOBAL_STORE,               fermi_sw_counter_generic_global_st_enc_str_1               , fermi_sw_counter_generic_global_st_enc_str_1               , CUPROF_EVENT_CATEGORY_INSTRUCTION, fermi_sw_counter_generic_global_ld_enc_str_4},

    // Software counters to count floating point instructions
    {FERMI_SW_COUNTER_FADD_INST,fermi_sw_counter_fadd_inst_enc_str_1, fermi_sw_counter_fadd_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sw_counter_fadd_inst_enc_str_4},
    {FERMI_SW_COUNTER_FMUL_INST,fermi_sw_counter_fmul_inst_enc_str_1, fermi_sw_counter_fmul_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sw_counter_fmul_inst_enc_str_4},
    {FERMI_SW_COUNTER_FFMA_INST,fermi_sw_counter_ffma_inst_enc_str_1, fermi_sw_counter_ffma_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sw_counter_ffma_inst_enc_str_4},
    {FERMI_SW_COUNTER_DADD_INST,fermi_sw_counter_dadd_inst_enc_str_1, fermi_sw_counter_dadd_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sw_counter_dadd_inst_enc_str_4},
    {FERMI_SW_COUNTER_DMUL_INST,fermi_sw_counter_dmul_inst_enc_str_1, fermi_sw_counter_dmul_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sw_counter_dmul_inst_enc_str_4},
    {FERMI_SW_COUNTER_DFMA_INST,fermi_sw_counter_dfma_inst_enc_str_1, fermi_sw_counter_dfma_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sw_counter_dfma_inst_enc_str_4},
    {FERMI_SW_COUNTER_COS_INST,fermi_sw_counter_cos_inst_enc_str_1, fermi_sw_counter_cos_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sw_counter_cos_inst_enc_str_4},
    {FERMI_SW_COUNTER_EX2_INST,fermi_sw_counter_ex2_inst_enc_str_1, fermi_sw_counter_ex2_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sw_counter_ex2_inst_enc_str_4},
    {FERMI_SW_COUNTER_LG2_INST,fermi_sw_counter_lg2_inst_enc_str_1, fermi_sw_counter_lg2_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sw_counter_lg2_inst_enc_str_4},
    {FERMI_SW_COUNTER_RCP_INST,fermi_sw_counter_rcp_inst_enc_str_1, fermi_sw_counter_rcp_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sw_counter_rcp_inst_enc_str_4},
    {FERMI_SW_COUNTER_RSQ_INST,fermi_sw_counter_rsq_inst_enc_str_1, fermi_sw_counter_rsq_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sw_counter_rsq_inst_enc_str_4},
    {FERMI_SW_COUNTER_SIN_INST,fermi_sw_counter_sin_inst_enc_str_1, fermi_sw_counter_sin_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sw_counter_sin_inst_enc_str_4},

    {FERMI_INTERNAL_SW_COUNTER_GLD8BIT_INST,fermi_internal_sw_counter_gld8bit_inst_enc_str_1, fermi_internal_sw_counter_gld8bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_internal_sw_counter_gld8bit_inst_enc_str_4},
    {FERMI_INTERNAL_SW_COUNTER_GLD16BIT_INST,fermi_internal_sw_counter_gld16bit_inst_enc_str_1, fermi_internal_sw_counter_gld16bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_internal_sw_counter_gld16bit_inst_enc_str_4},
    {FERMI_INTERNAL_SW_COUNTER_GLD32BIT_INST,fermi_internal_sw_counter_gld32bit_inst_enc_str_1, fermi_internal_sw_counter_gld32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_internal_sw_counter_gld32bit_inst_enc_str_4},
    {FERMI_INTERNAL_SW_COUNTER_GLD64BIT_INST,fermi_internal_sw_counter_gld64bit_inst_enc_str_1, fermi_internal_sw_counter_gld64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_internal_sw_counter_gld64bit_inst_enc_str_4},
    {FERMI_INTERNAL_SW_COUNTER_GLD128BIT_INST,fermi_internal_sw_counter_gld128bit_inst_enc_str_1, fermi_internal_sw_counter_gld128bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_internal_sw_counter_gld128bit_inst_enc_str_4},
    {FERMI_INTERNAL_SW_COUNTER_GST8BIT_INST,fermi_internal_sw_counter_gst8bit_inst_enc_str_1, fermi_internal_sw_counter_gst8bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_internal_sw_counter_gst8bit_inst_enc_str_4},
    {FERMI_INTERNAL_SW_COUNTER_GST16BIT_INST,fermi_internal_sw_counter_gst16bit_inst_enc_str_1, fermi_internal_sw_counter_gst16bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_internal_sw_counter_gst16bit_inst_enc_str_4},
    {FERMI_INTERNAL_SW_COUNTER_GST32BIT_INST,fermi_internal_sw_counter_gst32bit_inst_enc_str_1, fermi_internal_sw_counter_gst32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_internal_sw_counter_gst32bit_inst_enc_str_4},
    {FERMI_INTERNAL_SW_COUNTER_GST64BIT_INST,fermi_internal_sw_counter_gst64bit_inst_enc_str_1, fermi_internal_sw_counter_gst64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_internal_sw_counter_gst64bit_inst_enc_str_4},
    {FERMI_INTERNAL_SW_COUNTER_GST128BIT_INST,fermi_internal_sw_counter_gst128bit_inst_enc_str_1, fermi_internal_sw_counter_gst128bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,fermi_internal_sw_counter_gst128bit_inst_enc_str_4},
    {FERMI_LTC0_READ_HIT_SECTORS_FBP,fermi_ltc0_read_hit_sectors_fbp_enc_str_1, fermi_ltc0_read_hit_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc0_read_hit_sectors_fbp_enc_str_8},
    {FERMI_LTC1_READ_HIT_SECTORS_FBP,fermi_ltc1_read_hit_sectors_fbp_enc_str_1, fermi_ltc1_read_hit_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc1_read_hit_sectors_fbp_enc_str_7},
    {FERMI_LTC0_READ_TEX_HIT_SECTORS_FBP,fermi_ltc0_read_tex_hit_sectors_fbp_enc_str_1, fermi_ltc0_read_tex_hit_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc0_read_tex_hit_sectors_fbp_enc_str_8},
    {FERMI_LTC1_READ_TEX_HIT_SECTORS_FBP,fermi_ltc1_read_tex_hit_sectors_fbp_enc_str_1, fermi_ltc1_read_tex_hit_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc1_read_tex_hit_sectors_fbp_enc_str_7},
    {FERMI_LTC0_READ_CB_HIT_SECTORS_FBP,fermi_ltc0_read_cb_hit_sectors_fbp_enc_str_1, fermi_ltc0_read_cb_hit_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc0_read_cb_hit_sectors_fbp_enc_str_8},
    {FERMI_LTC1_READ_CB_HIT_SECTORS_FBP,fermi_ltc1_read_cb_hit_sectors_fbp_enc_str_1, fermi_ltc1_read_cb_hit_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc1_read_cb_hit_sectors_fbp_enc_str_6},

    // Internal events
#ifdef SMPM
    {HWPM_FERMI_FET_TAKEN_BRANCHES,hwpm_fermi_fet_taken_branches_enc_str_1, hwpm_fermi_fet_taken_branches_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_FET_ODD_CONTROL_FLOW_STALL,hwpm_fermi_fet_odd_control_flow_stall_enc_str_1, hwpm_fermi_fet_odd_control_flow_stall_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_FET_EVEN_CONTROL_FLOW_STALL,hwpm_fermi_fet_even_control_flow_stall_enc_str_1, hwpm_fermi_fet_even_control_flow_stall_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SL_L1_DEFERRED,hwpm_fermi_sl_l1_deferred_enc_str_1, hwpm_fermi_sl_l1_deferred_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SL_L1_DIVERGENT,hwpm_fermi_sl_l1_divergent_enc_str_1, hwpm_fermi_sl_l1_divergent_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SL_L1_REPLAYED,hwpm_fermi_sl_l1_replayed_enc_str_1, hwpm_fermi_sl_l1_replayed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_DSM_EVEN_IMC_MISS_REPLAY,fermi_dsm_even_imc_miss_replay_enc_str_4, fermi_dsm_even_imc_miss_replay_enc_str_4, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_DSM_ODD_IMC_MISS_REPLAY,fermi_dsm_odd_imc_miss_replay_enc_str_4, fermi_dsm_odd_imc_miss_replay_enc_str_4, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_DSM_IPA_OR_PIXLD_REPLAY,hwpm_fermi_dsm_ipa_or_pixld_replay_enc_str_1, hwpm_fermi_dsm_ipa_or_pixld_replay_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_AGU_IDC_REPLAYED,hwpm_fermi_agu_idc_replayed_enc_str_1, hwpm_fermi_agu_idc_replayed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SCH_WARP_ISSUE_HOLES,hwpm_fermi_sch_warp_issue_holes_enc_str_1, hwpm_fermi_sch_warp_issue_holes_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SCH_WARP_ISSUE_HOLES_LONG,hwpm_fermi_sch_warp_issue_holes_long_enc_str_1, hwpm_fermi_sch_warp_issue_holes_long_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SCH_WARP_ISSUE_ELIGIBLE,hwpm_fermi_sch_warp_issue_eligible_enc_str_1, hwpm_fermi_sch_warp_issue_eligible_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_FET_ICC_MISS,hwpm_fermi_fet_icc_miss_enc_str_1, hwpm_fermi_fet_icc_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_FET_ICC_HIT,hwpm_fermi_fet_icc_hit_enc_str_1, hwpm_fermi_fet_icc_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SCH_EVEN_CANT_ISSUE_NO_INST,hwpm_fermi_sch_even_cant_issue_no_inst_enc_str_1, hwpm_fermi_sch_even_cant_issue_no_inst_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SCH_EVEN_CANT_ISSUE_INTERLOCK_LONG,hwpm_fermi_sch_even_cant_issue_interlock_long_enc_str_1, hwpm_fermi_sch_even_cant_issue_interlock_long_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SCH_EVEN_CANT_ISSUE_INTERLOCK_SHORT,hwpm_fermi_sch_even_cant_issue_interlock_short_enc_str_1, hwpm_fermi_sch_even_cant_issue_interlock_short_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SCH_EVEN_CANT_ISSUE_REISSUE,hwpm_fermi_sch_even_cant_issue_reissue_enc_str_1, hwpm_fermi_sch_even_cant_issue_reissue_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SCH_EVEN_CANT_ISSUE_DSM_Q_FULL,hwpm_fermi_sch_even_cant_issue_dsm_q_full_enc_str_1, hwpm_fermi_sch_even_cant_issue_dsm_q_full_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SCH_EVEN_CANT_ISSUE_TEX_SIDE,hwpm_fermi_sch_even_cant_issue_tex_side_enc_str_1, hwpm_fermi_sch_even_cant_issue_tex_side_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SCH_EVEN_CANT_ISSUE_BARRIER,hwpm_fermi_sch_even_cant_issue_barrier_enc_str_1, hwpm_fermi_sch_even_cant_issue_barrier_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SCH_EVEN_CANT_ISSUE_L1_SLEEP,hwpm_fermi_sch_even_cant_issue_l1_sleep_enc_str_1, hwpm_fermi_sch_even_cant_issue_l1_sleep_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SCH_EVEN_CANT_ISSUE_ALL,hwpm_fermi_sch_even_cant_issue_all_enc_str_1, hwpm_fermi_sch_even_cant_issue_all_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SCH_ODD_CANT_ISSUE_NO_INST,hwpm_fermi_sch_odd_cant_issue_no_inst_enc_str_1, hwpm_fermi_sch_odd_cant_issue_no_inst_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SCH_ODD_CANT_ISSUE_INTERLOCK_LONG,hwpm_fermi_sch_odd_cant_issue_interlock_long_enc_str_1, hwpm_fermi_sch_odd_cant_issue_interlock_long_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SCH_ODD_CANT_ISSUE_INTERLOCK_SHORT,hwpm_fermi_sch_odd_cant_issue_interlock_short_enc_str_1, hwpm_fermi_sch_odd_cant_issue_interlock_short_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SCH_ODD_CANT_ISSUE_REISSUE,hwpm_fermi_sch_odd_cant_issue_reissue_enc_str_1, hwpm_fermi_sch_odd_cant_issue_reissue_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SCH_ODD_CANT_ISSUE_DSM_Q_FULL,hwpm_fermi_sch_odd_cant_issue_dsm_q_full_enc_str_1, hwpm_fermi_sch_odd_cant_issue_dsm_q_full_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SCH_ODD_CANT_ISSUE_TEX_SIDE,hwpm_fermi_sch_odd_cant_issue_tex_side_enc_str_1, hwpm_fermi_sch_odd_cant_issue_tex_side_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SCH_ODD_CANT_ISSUE_BARRIER,hwpm_fermi_sch_odd_cant_issue_barrier_enc_str_1, hwpm_fermi_sch_odd_cant_issue_barrier_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SCH_ODD_CANT_ISSUE_L1_SLEEP,hwpm_fermi_sch_odd_cant_issue_l1_sleep_enc_str_1, hwpm_fermi_sch_odd_cant_issue_l1_sleep_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SCH_ODD_CANT_ISSUE_ALL,hwpm_fermi_sch_odd_cant_issue_all_enc_str_1, hwpm_fermi_sch_odd_cant_issue_all_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_NOP_TRIG_08,hwpm_fermi_nop_trig_08_enc_str_1, hwpm_fermi_nop_trig_08_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_NOP_TRIG_09,hwpm_fermi_nop_trig_09_enc_str_1, hwpm_fermi_nop_trig_09_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_NOP_TRIG_10,hwpm_fermi_nop_trig_10_enc_str_1, hwpm_fermi_nop_trig_10_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_NOP_TRIG_11,hwpm_fermi_nop_trig_11_enc_str_1, hwpm_fermi_nop_trig_11_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_NOP_TRIG_12,hwpm_fermi_nop_trig_12_enc_str_1, hwpm_fermi_nop_trig_12_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_NOP_TRIG_13,hwpm_fermi_nop_trig_13_enc_str_1, hwpm_fermi_nop_trig_13_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_NOP_TRIG_14,hwpm_fermi_nop_trig_14_enc_str_1, hwpm_fermi_nop_trig_14_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_NOP_TRIG_15,hwpm_fermi_nop_trig_15_enc_str_1, hwpm_fermi_nop_trig_15_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SUPER_SCALAR_DECODED1, hwpm_fermi_super_scalar_decoded1_enc_str_1, hwpm_fermi_super_scalar_decoded1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SUPER_SCALAR_DECODED2, hwpm_fermi_super_scalar_decoded2_enc_str_1, hwpm_fermi_super_scalar_decoded2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SUPER_SCALAR_DECODED,  hwpm_fermi_super_scalar_decoded_enc_str_1, hwpm_fermi_super_scalar_decoded_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_ODD_ALU_ONLY_INST_EXECUTED,hwpm_fermi_sm_odd_alu_only_inst_executed_enc_str_1, hwpm_fermi_sm_odd_alu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_ODD_XLU_ONLY_INST_EXECUTED,hwpm_fermi_sm_odd_xlu_only_inst_executed_enc_str_1, hwpm_fermi_sm_odd_xlu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_ODD_ALU_XLU_BIPIPE_INST_EXECUTED,hwpm_fermi_sm_odd_alu_xlu_bipipe_inst_executed_enc_str_1, hwpm_fermi_sm_odd_alu_xlu_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_ODD_FMALITE_ONLY_INST_EXECUTED,hwpm_fermi_sm_odd_fmalite_only_inst_executed_enc_str_1, hwpm_fermi_sm_odd_fmalite_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_ODD_FMA32_ONLY_INST_EXECUTED,hwpm_fermi_sm_odd_fma32_only_inst_executed_enc_str_1, hwpm_fermi_sm_odd_fma32_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_ODD_FMALITE_FMA32_BIPIPE_INST_EXECUTED,hwpm_fermi_sm_odd_fmalite_fma32_bipipe_inst_executed_enc_str_1, hwpm_fermi_sm_odd_fmalite_fma32_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_ODD_FU_INST_EXECUTED,hwpm_fermi_sm_odd_fu_inst_executed_enc_str_1, hwpm_fermi_sm_odd_fu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_ODD_FMA64_INST_EXECUTED,hwpm_fermi_sm_odd_fma64_inst_executed_enc_str_1, hwpm_fermi_sm_odd_fma64_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_ODD_SU_INST_EXECUTED,hwpm_fermi_sm_odd_su_inst_executed_enc_str_1, hwpm_fermi_sm_odd_su_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_ODD_AGU_INST_EXECUTED,hwpm_fermi_sm_odd_agu_inst_executed_enc_str_1, hwpm_fermi_sm_odd_agu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_ODD_TEX_INST_EXECUTED,hwpm_fermi_sm_odd_tex_inst_executed_enc_str_1, hwpm_fermi_sm_odd_tex_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_ODD_DSM_INST_EXECUTED,hwpm_fermi_sm_odd_dsm_inst_executed_enc_str_1, hwpm_fermi_sm_odd_dsm_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_ODD_SCH_INTERNAL_INST_EXECUTED,hwpm_fermi_sm_odd_sch_internal_inst_executed_enc_str_1, hwpm_fermi_sm_odd_sch_internal_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_ODD_FE_INST_EXECUTED,hwpm_fermi_sm_odd_fe_inst_executed_enc_str_1, hwpm_fermi_sm_odd_fe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_EVEN_ALU_ONLY_INST_EXECUTED,hwpm_fermi_sm_even_alu_only_inst_executed_enc_str_1, hwpm_fermi_sm_even_alu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_EVEN_XLU_ONLY_INST_EXECUTED,hwpm_fermi_sm_even_xlu_only_inst_executed_enc_str_1, hwpm_fermi_sm_even_xlu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_EVEN_ALU_XLU_BIPIPE_INST_EXECUTED,hwpm_fermi_sm_even_alu_xlu_bipipe_inst_executed_enc_str_1, hwpm_fermi_sm_even_alu_xlu_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_EVEN_FMALITE_ONLY_INST_EXECUTED,hwpm_fermi_sm_even_fmalite_only_inst_executed_enc_str_1, hwpm_fermi_sm_even_fmalite_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_EVEN_FMA32_ONLY_INST_EXECUTED,hwpm_fermi_sm_even_fma32_only_inst_executed_enc_str_1, hwpm_fermi_sm_even_fma32_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_EVEN_FMALITE_FMA32_BIPIPE_INST_EXECUTED,hwpm_fermi_sm_even_fmalite_fma32_bipipe_inst_executed_enc_str_1, hwpm_fermi_sm_even_fmalite_fma32_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_EVEN_FU_INST_EXECUTED,hwpm_fermi_sm_even_fu_inst_executed_enc_str_1, hwpm_fermi_sm_even_fu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_EVEN_FMA64_INST_EXECUTED,hwpm_fermi_sm_even_fma64_inst_executed_enc_str_1, hwpm_fermi_sm_even_fma64_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_EVEN_SU_INST_EXECUTED,hwpm_fermi_sm_even_su_inst_executed_enc_str_1, hwpm_fermi_sm_even_su_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_EVEN_AGU_INST_EXECUTED,hwpm_fermi_sm_even_agu_inst_executed_enc_str_1, hwpm_fermi_sm_even_agu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_EVEN_TEX_INST_EXECUTED,hwpm_fermi_sm_even_tex_inst_executed_enc_str_1, hwpm_fermi_sm_even_tex_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_EVEN_DSM_INST_EXECUTED,hwpm_fermi_sm_even_dsm_inst_executed_enc_str_1, hwpm_fermi_sm_even_dsm_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_EVEN_SCH_INTERNAL_INST_EXECUTED,hwpm_fermi_sm_even_sch_internal_inst_executed_enc_str_1, hwpm_fermi_sm_even_sch_internal_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {HWPM_FERMI_SM_EVEN_FE_INST_EXECUTED,hwpm_fermi_sm_even_fe_inst_executed_enc_str_1, hwpm_fermi_sm_even_fe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD0_ALU_ONLY_INST_EXECUTED, hwpm_fermi_sm_odd0_alu_only_inst_executed_enc_str_1, hwpm_fermi_sm_odd0_alu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD0_XLU_ONLY_INST_EXECUTED, hwpm_fermi_sm_odd0_xlu_only_inst_executed_enc_str_1, hwpm_fermi_sm_odd0_xlu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD0_ALU_XLU_BIPIPE_INST_EXECUTED, hwpm_fermi_sm_odd0_alu_xlu_bipipe_inst_executed_enc_str_1, hwpm_fermi_sm_odd0_alu_xlu_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD0_FMALITE_ONLY_INST_EXECUTED, hwpm_fermi_sm_odd0_fmalite_only_inst_executed_enc_str_1, hwpm_fermi_sm_odd0_fmalite_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD0_FMA32_ONLY_INST_EXECUTED, hwpm_fermi_sm_odd0_fma32_only_inst_executed_enc_str_1, hwpm_fermi_sm_odd0_fma32_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD0_FMALITE_FMA32_BIPIPE_INST_EXECUTED, hwpm_fermi_sm_odd0_fmalite_fma32_bipipe_inst_executed_enc_str_1, hwpm_fermi_sm_odd0_fmalite_fma32_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD0_FU_INST_EXECUTED, hwpm_fermi_sm_odd0_fu_inst_executed_enc_str_1, hwpm_fermi_sm_odd0_fu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD0_FMA64_INST_EXECUTED, hwpm_fermi_sm_odd0_fma64_inst_executed_enc_str_1, hwpm_fermi_sm_odd0_fma64_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD0_SU_INST_EXECUTED, hwpm_fermi_sm_odd0_su_inst_executed_enc_str_1, hwpm_fermi_sm_odd0_su_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD0_AGU_INST_EXECUTED, hwpm_fermi_sm_odd0_agu_inst_executed_enc_str_1, hwpm_fermi_sm_odd0_agu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD0_TEX_INST_EXECUTED, hwpm_fermi_sm_odd0_tex_inst_executed_enc_str_1, hwpm_fermi_sm_odd0_tex_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD0_DSM_INST_EXECUTED, hwpm_fermi_sm_odd0_dsm_inst_executed_enc_str_1, hwpm_fermi_sm_odd0_dsm_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD0_SCH_INTERNAL_INST_EXECUTED, hwpm_fermi_sm_odd0_sch_internal_inst_executed_enc_str_1, hwpm_fermi_sm_odd0_sch_internal_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD0_FE_INST_EXECUTED, hwpm_fermi_sm_odd0_fe_inst_executed_enc_str_1, hwpm_fermi_sm_odd0_fe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD1_ALU_ONLY_INST_EXECUTED, hwpm_fermi_sm_odd1_alu_only_inst_executed_enc_str_1, hwpm_fermi_sm_odd1_alu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD1_XLU_ONLY_INST_EXECUTED, hwpm_fermi_sm_odd1_xlu_only_inst_executed_enc_str_1, hwpm_fermi_sm_odd1_xlu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD1_ALU_XLU_BIPIPE_INST_EXECUTED, hwpm_fermi_sm_odd1_alu_xlu_bipipe_inst_executed_enc_str_1, hwpm_fermi_sm_odd1_alu_xlu_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD1_FMALITE_ONLY_INST_EXECUTED, hwpm_fermi_sm_odd1_fmalite_only_inst_executed_enc_str_1, hwpm_fermi_sm_odd1_fmalite_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD1_FMA32_ONLY_INST_EXECUTED, hwpm_fermi_sm_odd1_fma32_only_inst_executed_enc_str_1, hwpm_fermi_sm_odd1_fma32_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD1_FMALITE_FMA32_BIPIPE_INST_EXECUTED, hwpm_fermi_sm_odd1_fmalite_fma32_bipipe_inst_executed_enc_str_1, hwpm_fermi_sm_odd1_fmalite_fma32_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD1_FU_INST_EXECUTED, hwpm_fermi_sm_odd1_fu_inst_executed_enc_str_1, hwpm_fermi_sm_odd1_fu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD1_FMA64_INST_EXECUTED, hwpm_fermi_sm_odd1_fma64_inst_executed_enc_str_1, hwpm_fermi_sm_odd1_fma64_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD1_SU_INST_EXECUTED, hwpm_fermi_sm_odd1_su_inst_executed_enc_str_1, hwpm_fermi_sm_odd1_su_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD1_AGU_INST_EXECUTED, hwpm_fermi_sm_odd1_agu_inst_executed_enc_str_1, hwpm_fermi_sm_odd1_agu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD1_TEX_INST_EXECUTED, hwpm_fermi_sm_odd1_tex_inst_executed_enc_str_1, hwpm_fermi_sm_odd1_tex_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD1_DSM_INST_EXECUTED, hwpm_fermi_sm_odd1_dsm_inst_executed_enc_str_1, hwpm_fermi_sm_odd1_dsm_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD1_SCH_INTERNAL_INST_EXECUTED, hwpm_fermi_sm_odd1_sch_internal_inst_executed_enc_str_1, hwpm_fermi_sm_odd1_sch_internal_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_ODD1_FE_INST_EXECUTED, hwpm_fermi_sm_odd1_fe_inst_executed_enc_str_1, hwpm_fermi_sm_odd1_fe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN0_ALU_ONLY_INST_EXECUTED, hwpm_fermi_sm_even0_alu_only_inst_executed_enc_str_1, hwpm_fermi_sm_even0_alu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN0_XLU_ONLY_INST_EXECUTED, hwpm_fermi_sm_even0_xlu_only_inst_executed_enc_str_1, hwpm_fermi_sm_even0_xlu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN0_ALU_XLU_BIPIPE_INST_EXECUTED, hwpm_fermi_sm_even0_alu_xlu_bipipe_inst_executed_enc_str_1, hwpm_fermi_sm_even0_alu_xlu_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN0_FMALITE_ONLY_INST_EXECUTED, hwpm_fermi_sm_even0_fmalite_only_inst_executed_enc_str_1, hwpm_fermi_sm_even0_fmalite_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN0_FMA32_ONLY_INST_EXECUTED, hwpm_fermi_sm_even0_fma32_only_inst_executed_enc_str_1, hwpm_fermi_sm_even0_fma32_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN0_FMALITE_FMA32_BIPIPE_INST_EXECUTED, hwpm_fermi_sm_even0_fmalite_fma32_bipipe_inst_executed_enc_str_1, hwpm_fermi_sm_even0_fmalite_fma32_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN0_FU_INST_EXECUTED, hwpm_fermi_sm_even0_fu_inst_executed_enc_str_1, hwpm_fermi_sm_even0_fu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN0_FMA64_INST_EXECUTED, hwpm_fermi_sm_even0_fma64_inst_executed_enc_str_1, hwpm_fermi_sm_even0_fma64_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN0_SU_INST_EXECUTED, hwpm_fermi_sm_even0_su_inst_executed_enc_str_1, hwpm_fermi_sm_even0_su_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN0_AGU_INST_EXECUTED, hwpm_fermi_sm_even0_agu_inst_executed_enc_str_1, hwpm_fermi_sm_even0_agu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN0_TEX_INST_EXECUTED, hwpm_fermi_sm_even0_tex_inst_executed_enc_str_1, hwpm_fermi_sm_even0_tex_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN0_DSM_INST_EXECUTED, hwpm_fermi_sm_even0_dsm_inst_executed_enc_str_1, hwpm_fermi_sm_even0_dsm_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN0_SCH_INTERNAL_INST_EXECUTED, hwpm_fermi_sm_even0_sch_internal_inst_executed_enc_str_1, hwpm_fermi_sm_even0_sch_internal_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN0_FE_INST_EXECUTED, hwpm_fermi_sm_even0_fe_inst_executed_enc_str_1, hwpm_fermi_sm_even0_fe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN1_ALU_ONLY_INST_EXECUTED, hwpm_fermi_sm_even1_alu_only_inst_executed_enc_str_1, hwpm_fermi_sm_even1_alu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN1_XLU_ONLY_INST_EXECUTED, hwpm_fermi_sm_even1_xlu_only_inst_executed_enc_str_1, hwpm_fermi_sm_even1_xlu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN1_ALU_XLU_BIPIPE_INST_EXECUTED, hwpm_fermi_sm_even1_alu_xlu_bipipe_inst_executed_enc_str_1, hwpm_fermi_sm_even1_alu_xlu_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN1_FMALITE_ONLY_INST_EXECUTED, hwpm_fermi_sm_even1_fmalite_only_inst_executed_enc_str_1, hwpm_fermi_sm_even1_fmalite_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN1_FMA32_ONLY_INST_EXECUTED, hwpm_fermi_sm_even1_fma32_only_inst_executed_enc_str_1, hwpm_fermi_sm_even1_fma32_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN1_FMALITE_FMA32_BIPIPE_INST_EXECUTED, hwpm_fermi_sm_even1_fmalite_fma32_bipipe_inst_executed_enc_str_1, hwpm_fermi_sm_even1_fmalite_fma32_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN1_FU_INST_EXECUTED, hwpm_fermi_sm_even1_fu_inst_executed_enc_str_1, hwpm_fermi_sm_even1_fu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN1_FMA64_INST_EXECUTED, hwpm_fermi_sm_even1_fma64_inst_executed_enc_str_1, hwpm_fermi_sm_even1_fma64_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN1_SU_INST_EXECUTED, hwpm_fermi_sm_even1_su_inst_executed_enc_str_1, hwpm_fermi_sm_even1_su_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN1_AGU_INST_EXECUTED, hwpm_fermi_sm_even1_agu_inst_executed_enc_str_1, hwpm_fermi_sm_even1_agu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN1_TEX_INST_EXECUTED, hwpm_fermi_sm_even1_tex_inst_executed_enc_str_1, hwpm_fermi_sm_even1_tex_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN1_DSM_INST_EXECUTED, hwpm_fermi_sm_even1_dsm_inst_executed_enc_str_1, hwpm_fermi_sm_even1_dsm_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN1_SCH_INTERNAL_INST_EXECUTED, hwpm_fermi_sm_even1_sch_internal_inst_executed_enc_str_1, hwpm_fermi_sm_even1_sch_internal_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    { HWPM_FERMI_SM_EVEN1_FE_INST_EXECUTED, hwpm_fermi_sm_even1_fe_inst_executed_enc_str_1, hwpm_fermi_sm_even1_fe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
#endif

    {FERMI_L1C_DEFER_PRT_FULL,fermi_l1c_defer_prt_full_enc_str_1, fermi_l1c_defer_prt_full_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_L1C_DEFER_GNI_STALL,fermi_l1c_defer_gni_stall_enc_str_1, fermi_l1c_defer_gni_stall_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_L1C_DEFER_NO_ALLOCATABLE_CLINE,fermi_l1c_defer_no_allocatable_cline_enc_str_1, fermi_l1c_defer_no_allocatable_cline_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_L1C_DEFER_STORE_BANK_COLLISION,fermi_l1c_defer_store_bank_collision_enc_str_1, fermi_l1c_defer_store_bank_collision_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_L1C_DEFER_PRT_LOAD_LIMIT,fermi_l1c_defer_prt_load_limit_enc_str_1, fermi_l1c_defer_prt_load_limit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_L1C_DEFER_PRT_STORE_LIMIT,fermi_l1c_defer_prt_store_limit_enc_str_1, fermi_l1c_defer_prt_store_limit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_L1C_DEFER_UNCACHED_LOAD_LIMIT,fermi_l1c_defer_uncached_load_limit_enc_str_1, fermi_l1c_defer_uncached_load_limit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_FB_SUBP0_DRAM_ACTIVATES,fermi_fb_subp0_dram_activates_enc_str_1, fermi_fb_subp0_dram_activates_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_FB_SUBP1_DRAM_ACTIVATES,fermi_fb_subp1_dram_activates_enc_str_1, fermi_fb_subp1_dram_activates_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_FB0_SUBP0_DRAM_ACTIVATES, fermi_fb0_subp0_dram_activates_enc_str_1, fermi_fb0_subp0_dram_activates_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_FB0_SUBP1_DRAM_ACTIVATES, fermi_fb0_subp1_dram_activates_enc_str_1, fermi_fb0_subp1_dram_activates_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_FB1_SUBP0_DRAM_ACTIVATES, fermi_fb1_subp0_dram_activates_enc_str_1, fermi_fb1_subp0_dram_activates_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_FB1_SUBP1_DRAM_ACTIVATES, fermi_fb1_subp1_dram_activates_enc_str_1, fermi_fb1_subp1_dram_activates_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_LTC0_READ_CB_SECTORS_FBP,fermi_ltc0_read_cb_sectors_fbp_enc_str_1, fermi_ltc0_read_cb_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_LTC1_READ_CB_SECTORS_FBP,fermi_ltc1_read_cb_sectors_fbp_enc_str_1, fermi_ltc1_read_cb_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_LTC0_WRITE_CB_SECTORS_FBP,fermi_ltc0_write_cb_sectors_fbp_enc_str_1, fermi_ltc0_write_cb_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_LTC1_WRITE_CB_SECTORS_FBP,fermi_ltc1_write_cb_sectors_fbp_enc_str_1, fermi_ltc1_write_cb_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_LTC0_READ_HIT_SECTORS_FBP,fermi_ltc0_read_hit_sectors_fbp_enc_str_1, fermi_ltc0_read_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_LTC1_READ_HIT_SECTORS_FBP,fermi_ltc1_read_hit_sectors_fbp_enc_str_1, fermi_ltc1_read_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_LTC0_READ_TEX_HIT_SECTORS_FBP,fermi_ltc0_read_tex_hit_sectors_fbp_enc_str_1, fermi_ltc0_read_tex_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_LTC1_READ_TEX_HIT_SECTORS_FBP,fermi_ltc1_read_tex_hit_sectors_fbp_enc_str_1, fermi_ltc1_read_tex_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_LTC0_READ_CB_HIT_SECTORS_FBP,fermi_ltc0_read_cb_hit_sectors_fbp_enc_str_1, fermi_ltc0_read_cb_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_LTC1_READ_CB_HIT_SECTORS_FBP,fermi_ltc1_read_cb_hit_sectors_fbp_enc_str_1, fermi_ltc1_read_cb_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_LTC0_READ_SYSMEM_SECTORS_FBP,fermi_ltc0_read_sysmem_sectors_fbp_enc_str_1, fermi_ltc0_read_sysmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc0_read_sysmem_sectors_fbp_enc_str_8},
    {FERMI_LTC1_READ_SYSMEM_SECTORS_FBP,fermi_ltc1_read_sysmem_sectors_fbp_enc_str_1, fermi_ltc1_read_sysmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc1_read_sysmem_sectors_fbp_enc_str_7},
    {FERMI_LTC0_WRITE_SYSMEM_SECTORS_FBP,fermi_ltc0_write_sysmem_sectors_fbp_enc_str_1, fermi_ltc0_write_sysmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc0_write_sysmem_sectors_fbp_enc_str_8},
    {FERMI_LTC1_WRITE_SYSMEM_SECTORS_FBP,fermi_ltc1_write_sysmem_sectors_fbp_enc_str_1, fermi_ltc1_write_sysmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc1_write_sysmem_sectors_fbp_enc_str_7},
    {FERMI_LTC0_TOTAL_READ_SECTORS_FBP,fermi_ltc0_total_read_sectors_fbp_enc_str_1, fermi_ltc0_total_read_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc0_total_read_sectors_fbp_enc_str_8},
    {FERMI_LTC1_TOTAL_READ_SECTORS_FBP,fermi_ltc1_total_read_sectors_fbp_enc_str_1, fermi_ltc1_total_read_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc1_total_read_sectors_fbp_enc_str_7},
    {FERMI_LTC0_TOTAL_WRITE_SECTORS_FBP,fermi_ltc0_total_write_sectors_fbp_enc_str_1, fermi_ltc0_total_write_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc0_total_write_sectors_fbp_enc_str_8},
    {FERMI_LTC1_TOTAL_WRITE_SECTORS_FBP,fermi_ltc1_total_write_sectors_fbp_enc_str_1, fermi_ltc1_total_write_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE,fermi_ltc1_total_write_sectors_fbp_enc_str_7},

    {FERMI_MMU_HUB_TLB_HIT,fermi_mmu_hub_tlb_hit_enc_str_1, fermi_mmu_hub_tlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_MMU_HUB_TLB_MISS,fermi_mmu_hub_tlb_miss_enc_str_1, fermi_mmu_hub_tlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_MMU_FILL_PTE_HIT,fermi_mmu_fill_pte_hit_enc_str_1,fermi_mmu_fill_pte_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_MMU_FILL_PTE_MISS,fermi_mmu_fill_pte_miss_enc_str_1,fermi_mmu_fill_pte_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_MMU_FILL_PDE_HIT,fermi_mmu_fill_pde_hit_enc_str_1,fermi_mmu_fill_pde_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_MMU_FILL_PDE_MISS,fermi_mmu_fill_pde_miss_enc_str_1,fermi_mmu_fill_pde_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_MMU_GPCL2_TLB_HIT,fermi_mmu_gpcl2_tlb_hit_enc_str_1, fermi_mmu_gpcl2_tlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_MMU_GPCL2_TLB_MISS,fermi_mmu_gpcl2_tlb_miss_enc_str_1, fermi_mmu_gpcl2_tlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_FET_TAKEN_BRANCHES,fermi_fet_taken_branches_enc_str_1, fermi_fet_taken_branches_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_FET_UNIQUE_BRANCHES_0,fermi_fet_unique_branches_0_enc_str_1, fermi_fet_unique_branches_0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_FET_UNIQUE_BRANCHES_1,fermi_fet_unique_branches_1_enc_str_1, fermi_fet_unique_branches_1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_FET_ODD_CONTROL_FLOW_STALL,fermi_fet_odd_control_flow_stall_enc_str_1, fermi_fet_odd_control_flow_stall_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_FET_EVEN_CONTROL_FLOW_STALL,fermi_fet_even_control_flow_stall_enc_str_1, fermi_fet_even_control_flow_stall_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_FET_DIVERGED_BRANCHES_0,fermi_fet_diverged_branches_0_enc_str_1, fermi_fet_diverged_branches_0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_FET_DIVERGED_BRANCHES_1,fermi_fet_diverged_branches_1_enc_str_1, fermi_fet_diverged_branches_1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SL_L1_DEFERRED,fermi_sl_l1_deferred_enc_str_1, fermi_sl_l1_deferred_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SL_L1_DIVERGENT,fermi_sl_l1_divergent_enc_str_1, fermi_sl_l1_divergent_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SL_L1_REPLAYED,fermi_sl_l1_replayed_enc_str_1, fermi_sl_l1_replayed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_DSM_EVEN_IMC_MISS_REPLAY,fermi_dsm_even_imc_miss_replay_enc_str_1, fermi_dsm_even_imc_miss_replay_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_DSM_ODD_IMC_MISS_REPLAY,fermi_dsm_odd_imc_miss_replay_enc_str_1, fermi_dsm_odd_imc_miss_replay_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_DSM_IPA_OR_PIXLD_REPLAY,fermi_dsm_ipa_or_pixld_replay_enc_str_1, fermi_dsm_ipa_or_pixld_replay_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_AGU_IDC_REPLAYED,fermi_agu_idc_replayed_enc_str_1, fermi_agu_idc_replayed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_THREADS_LAUNCHED_0,fermi_sch_threads_launched_0_enc_str_1, fermi_sch_threads_launched_0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_THREADS_LAUNCHED_1,fermi_sch_threads_launched_1_enc_str_1, fermi_sch_threads_launched_1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_THREADS_LAUNCHED_2,fermi_sch_threads_launched_2_enc_str_1, fermi_sch_threads_launched_2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_THREADS_LAUNCHED_3,fermi_sch_threads_launched_3_enc_str_1, fermi_sch_threads_launched_3_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_THREADS_LAUNCHED_4,fermi_sch_threads_launched_4_enc_str_1, fermi_sch_threads_launched_4_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_THREADS_LAUNCHED_5,fermi_sch_threads_launched_5_enc_str_1, fermi_sch_threads_launched_5_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_WARP_ISSUE_HOLES,fermi_sch_warp_issue_holes_enc_str_1, fermi_sch_warp_issue_holes_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_WARP_ISSUE_HOLES_LONG,fermi_sch_warp_issue_holes_long_enc_str_1, fermi_sch_warp_issue_holes_long_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_WARP_ISSUE_ELIGIBLE,fermi_sch_warp_issue_eligible_enc_str_1, fermi_sch_warp_issue_eligible_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_FET_ICC_MISS,fermi_fet_icc_miss_enc_str_1, fermi_fet_icc_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_FET_ICC_HIT,fermi_fet_icc_hit_enc_str_1, fermi_fet_icc_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_EVEN_CANT_ISSUE_NO_INST,fermi_sch_even_cant_issue_no_inst_enc_str_1, fermi_sch_even_cant_issue_no_inst_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_EVEN_CANT_ISSUE_INTERLOCK_LONG,fermi_sch_even_cant_issue_interlock_long_enc_str_1, fermi_sch_even_cant_issue_interlock_long_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_EVEN_CANT_ISSUE_INTERLOCK_SHORT,fermi_sch_even_cant_issue_interlock_short_enc_str_1, fermi_sch_even_cant_issue_interlock_short_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_EVEN_CANT_ISSUE_REISSUE,fermi_sch_even_cant_issue_reissue_enc_str_1, fermi_sch_even_cant_issue_reissue_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_EVEN_CANT_ISSUE_DSM_Q_FULL,fermi_sch_even_cant_issue_dsm_q_full_enc_str_1, fermi_sch_even_cant_issue_dsm_q_full_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_EVEN_CANT_ISSUE_TEX_SIDE,fermi_sch_even_cant_issue_tex_side_enc_str_1, fermi_sch_even_cant_issue_tex_side_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_EVEN_CANT_ISSUE_BARRIER,fermi_sch_even_cant_issue_barrier_enc_str_1, fermi_sch_even_cant_issue_barrier_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_EVEN_CANT_ISSUE_L1_SLEEP,fermi_sch_even_cant_issue_l1_sleep_enc_str_1, fermi_sch_even_cant_issue_l1_sleep_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_EVEN_CANT_ISSUE_ALL,fermi_sch_even_cant_issue_all_enc_str_1, fermi_sch_even_cant_issue_all_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_EVEN_CANT_ISSUE_TEX_REQ_TABLE_FULL,fermi_sch_even_cant_issue_tex_req_table_full_enc_str_1,fermi_sch_even_cant_issue_tex_req_table_full_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sch_even_cant_issue_tex_req_table_full_enc_str_6},
    {FERMI_SCH_EVEN_CANT_ISSUE_TILE,fermi_sch_even_cant_issue_tile_enc_str_1,fermi_sch_even_cant_issue_tile_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sch_even_cant_issue_tile_enc_str_6},
    {FERMI_SCH_EVEN_CANT_ISSUE_ISSUE_THROTTLE,fermi_sch_even_cant_issue_issue_throttle_enc_str_1,fermi_sch_even_cant_issue_issue_throttle_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sch_even_cant_issue_issue_throttle_enc_str_6},
    {FERMI_SCH_EVEN_CANT_ISSUE_TEX_Q_FULL,fermi_sch_even_cant_issue_tex_q_full_enc_str_1,fermi_sch_even_cant_issue_tex_q_full_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sch_even_cant_issue_tex_q_full_enc_str_6},
    {FERMI_SCH_ODD_CANT_ISSUE_NO_INST,fermi_sch_odd_cant_issue_no_inst_enc_str_1, fermi_sch_odd_cant_issue_no_inst_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_ODD_CANT_ISSUE_INTERLOCK_LONG,fermi_sch_odd_cant_issue_interlock_long_enc_str_1, fermi_sch_odd_cant_issue_interlock_long_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_ODD_CANT_ISSUE_INTERLOCK_SHORT,fermi_sch_odd_cant_issue_interlock_short_enc_str_1, fermi_sch_odd_cant_issue_interlock_short_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_ODD_CANT_ISSUE_REISSUE,fermi_sch_odd_cant_issue_reissue_enc_str_1, fermi_sch_odd_cant_issue_reissue_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_ODD_CANT_ISSUE_DSM_Q_FULL,fermi_sch_odd_cant_issue_dsm_q_full_enc_str_1, fermi_sch_odd_cant_issue_dsm_q_full_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_ODD_CANT_ISSUE_TEX_SIDE,fermi_sch_odd_cant_issue_tex_side_enc_str_1, fermi_sch_odd_cant_issue_tex_side_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_ODD_CANT_ISSUE_BARRIER,fermi_sch_odd_cant_issue_barrier_enc_str_1, fermi_sch_odd_cant_issue_barrier_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_ODD_CANT_ISSUE_L1_SLEEP,fermi_sch_odd_cant_issue_l1_sleep_enc_str_1, fermi_sch_odd_cant_issue_l1_sleep_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_ODD_CANT_ISSUE_ALL,fermi_sch_odd_cant_issue_all_enc_str_1, fermi_sch_odd_cant_issue_all_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_ODD_CANT_ISSUE_TEX_REQ_TABLE_FULL,fermi_sch_odd_cant_issue_tex_req_table_full_enc_str_1,fermi_sch_odd_cant_issue_tex_req_table_full_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sch_even_cant_issue_tex_req_table_full_enc_str_6},
    {FERMI_SCH_ODD_CANT_ISSUE_TILE,fermi_sch_odd_cant_issue_tile_enc_str_1,fermi_sch_odd_cant_issue_tile_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sch_even_cant_issue_tile_enc_str_6},
    {FERMI_SCH_ODD_CANT_ISSUE_ISSUE_THROTTLE,fermi_sch_odd_cant_issue_issue_throttle_enc_str_1,fermi_sch_odd_cant_issue_issue_throttle_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sch_even_cant_issue_issue_throttle_enc_str_6},
    {FERMI_SCH_ODD_CANT_ISSUE_TEX_Q_FULL,fermi_sch_odd_cant_issue_tex_q_full_enc_str_1,fermi_sch_odd_cant_issue_tex_q_full_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_sch_even_cant_issue_tex_q_full_enc_str_6},
    {FERMI_NOP_TRIG_08,fermi_nop_trig_08_enc_str_1, fermi_nop_trig_08_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_NOP_TRIG_09,fermi_nop_trig_09_enc_str_1, fermi_nop_trig_09_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_NOP_TRIG_10,fermi_nop_trig_10_enc_str_1, fermi_nop_trig_10_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_NOP_TRIG_11,fermi_nop_trig_11_enc_str_1, fermi_nop_trig_11_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_NOP_TRIG_12,fermi_nop_trig_12_enc_str_1, fermi_nop_trig_12_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_NOP_TRIG_13,fermi_nop_trig_13_enc_str_1, fermi_nop_trig_13_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_NOP_TRIG_14,fermi_nop_trig_14_enc_str_1, fermi_nop_trig_14_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_NOP_TRIG_15,fermi_nop_trig_15_enc_str_1, fermi_nop_trig_15_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SUPER_SCALAR_DECODED1,fermi_super_scalar_decoded1_enc_str_1, fermi_super_scalar_decoded1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SUPER_SCALAR_DECODED2,fermi_super_scalar_decoded2_enc_str_1, fermi_super_scalar_decoded2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SUPER_SCALAR_DECODED,fermi_super_scalar_decoded_enc_str_1, fermi_super_scalar_decoded_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_INST_ISSUED_0,fermi_sch_inst_issued_0_enc_str_1, fermi_sch_inst_issued_0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_INST_ISSUED_1,fermi_sch_inst_issued_1_enc_str_1, fermi_sch_inst_issued_1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_INST_DECODED_0,fermi_sch_inst_decoded_0_enc_str_1, fermi_sch_inst_decoded_0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_INST_DECODED_1,fermi_sch_inst_decoded_1_enc_str_1, fermi_sch_inst_decoded_1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SCH_INST_DECODED_2,fermi_sch_inst_decoded_2_enc_str_1, fermi_sch_inst_decoded_2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_ALU_ONLY_INST_EXECUTED,fermi_sm_odd_alu_only_inst_executed_enc_str_1, fermi_sm_odd_alu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_XLU_ONLY_INST_EXECUTED,fermi_sm_odd_xlu_only_inst_executed_enc_str_1, fermi_sm_odd_xlu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_ALU_XLU_BIPIPE_INST_EXECUTED,fermi_sm_odd_alu_xlu_bipipe_inst_executed_enc_str_1, fermi_sm_odd_alu_xlu_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_FMALITE_ONLY_INST_EXECUTED,fermi_sm_odd_fmalite_only_inst_executed_enc_str_1, fermi_sm_odd_fmalite_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_FMA32_ONLY_INST_EXECUTED,fermi_sm_odd_fma32_only_inst_executed_enc_str_1, fermi_sm_odd_fma32_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_FMALITE_FMA32_BIPIPE_INST_EXECUTED,fermi_sm_odd_fmalite_fma32_bipipe_inst_executed_enc_str_1, fermi_sm_odd_fmalite_fma32_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_FU_INST_EXECUTED,fermi_sm_odd_fu_inst_executed_enc_str_1, fermi_sm_odd_fu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_FMA64_INST_EXECUTED,fermi_sm_odd_fma64_inst_executed_enc_str_1, fermi_sm_odd_fma64_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_SU_INST_EXECUTED,fermi_sm_odd_su_inst_executed_enc_str_1, fermi_sm_odd_su_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_AGU_INST_EXECUTED,fermi_sm_odd_agu_inst_executed_enc_str_1, fermi_sm_odd_agu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_TEX_INST_EXECUTED,fermi_sm_odd_tex_inst_executed_enc_str_1, fermi_sm_odd_tex_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_DSM_INST_EXECUTED,fermi_sm_odd_dsm_inst_executed_enc_str_1, fermi_sm_odd_dsm_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_SCH_INTERNAL_INST_EXECUTED,fermi_sm_odd_sch_internal_inst_executed_enc_str_1, fermi_sm_odd_sch_internal_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_FE_INST_EXECUTED,fermi_sm_odd_fe_inst_executed_enc_str_1, fermi_sm_odd_fe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_ALU_ONLY_INST_EXECUTED,fermi_sm_even_alu_only_inst_executed_enc_str_1, fermi_sm_even_alu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_XLU_ONLY_INST_EXECUTED,fermi_sm_even_xlu_only_inst_executed_enc_str_1, fermi_sm_even_xlu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_ALU_XLU_BIPIPE_INST_EXECUTED,fermi_sm_even_alu_xlu_bipipe_inst_executed_enc_str_1, fermi_sm_even_alu_xlu_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_FMALITE_ONLY_INST_EXECUTED,fermi_sm_even_fmalite_only_inst_executed_enc_str_1, fermi_sm_even_fmalite_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_FMA32_ONLY_INST_EXECUTED,fermi_sm_even_fma32_only_inst_executed_enc_str_1, fermi_sm_even_fma32_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_FMALITE_FMA32_BIPIPE_INST_EXECUTED,fermi_sm_even_fmalite_fma32_bipipe_inst_executed_enc_str_1, fermi_sm_even_fmalite_fma32_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_FU_INST_EXECUTED,fermi_sm_even_fu_inst_executed_enc_str_1, fermi_sm_even_fu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_FMA64_INST_EXECUTED,fermi_sm_even_fma64_inst_executed_enc_str_1, fermi_sm_even_fma64_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_SU_INST_EXECUTED,fermi_sm_even_su_inst_executed_enc_str_1, fermi_sm_even_su_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_AGU_INST_EXECUTED,fermi_sm_even_agu_inst_executed_enc_str_1, fermi_sm_even_agu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_TEX_INST_EXECUTED,fermi_sm_even_tex_inst_executed_enc_str_1, fermi_sm_even_tex_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_DSM_INST_EXECUTED,fermi_sm_even_dsm_inst_executed_enc_str_1, fermi_sm_even_dsm_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_SCH_INTERNAL_INST_EXECUTED,fermi_sm_even_sch_internal_inst_executed_enc_str_1, fermi_sm_even_sch_internal_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_FE_INST_EXECUTED,fermi_sm_even_fe_inst_executed_enc_str_1, fermi_sm_even_fe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_ALU_ONLY_INST_EXECUTED, fermi_sm_odd0_alu_only_inst_executed_enc_str_1, fermi_sm_odd0_alu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_XLU_ONLY_INST_EXECUTED, fermi_sm_odd0_xlu_only_inst_executed_enc_str_1, fermi_sm_odd0_xlu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_ALU_XLU_BIPIPE_INST_EXECUTED, fermi_sm_odd0_alu_xlu_bipipe_inst_executed_enc_str_1, fermi_sm_odd0_alu_xlu_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_FMALITE_ONLY_INST_EXECUTED, fermi_sm_odd0_fmalite_only_inst_executed_enc_str_1, fermi_sm_odd0_fmalite_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_FMA32_ONLY_INST_EXECUTED, fermi_sm_odd0_fma32_only_inst_executed_enc_str_1, fermi_sm_odd0_fma32_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_FMALITE_FMA32_BIPIPE_INST_EXECUTED, fermi_sm_odd0_fmalite_fma32_bipipe_inst_executed_enc_str_1, fermi_sm_odd0_fmalite_fma32_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_FU_INST_EXECUTED, fermi_sm_odd0_fu_inst_executed_enc_str_1, fermi_sm_odd0_fu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_FMA64_INST_EXECUTED, fermi_sm_odd0_fma64_inst_executed_enc_str_1, fermi_sm_odd0_fma64_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_SU_INST_EXECUTED, fermi_sm_odd0_su_inst_executed_enc_str_1, fermi_sm_odd0_su_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_AGU_INST_EXECUTED, fermi_sm_odd0_agu_inst_executed_enc_str_1, fermi_sm_odd0_agu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_TEX_INST_EXECUTED, fermi_sm_odd0_tex_inst_executed_enc_str_1, fermi_sm_odd0_tex_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_DSM_INST_EXECUTED, fermi_sm_odd0_dsm_inst_executed_enc_str_1, fermi_sm_odd0_dsm_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_SCH_INTERNAL_INST_EXECUTED, fermi_sm_odd0_sch_internal_inst_executed_enc_str_1, fermi_sm_odd0_sch_internal_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_FE_INST_EXECUTED, fermi_sm_odd0_fe_inst_executed_enc_str_1, fermi_sm_odd0_fe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_ALU_ONLY_INST_EXECUTED, fermi_sm_odd1_alu_only_inst_executed_enc_str_1, fermi_sm_odd1_alu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_XLU_ONLY_INST_EXECUTED, fermi_sm_odd1_xlu_only_inst_executed_enc_str_1, fermi_sm_odd1_xlu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_ALU_XLU_BIPIPE_INST_EXECUTED, fermi_sm_odd1_alu_xlu_bipipe_inst_executed_enc_str_1, fermi_sm_odd1_alu_xlu_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_FMALITE_ONLY_INST_EXECUTED, fermi_sm_odd1_fmalite_only_inst_executed_enc_str_1, fermi_sm_odd1_fmalite_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_FMA32_ONLY_INST_EXECUTED, fermi_sm_odd1_fma32_only_inst_executed_enc_str_1, fermi_sm_odd1_fma32_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_FMALITE_FMA32_BIPIPE_INST_EXECUTED, fermi_sm_odd1_fmalite_fma32_bipipe_inst_executed_enc_str_1, fermi_sm_odd1_fmalite_fma32_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_FU_INST_EXECUTED, fermi_sm_odd1_fu_inst_executed_enc_str_1, fermi_sm_odd1_fu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_FMA64_INST_EXECUTED, fermi_sm_odd1_fma64_inst_executed_enc_str_1, fermi_sm_odd1_fma64_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_SU_INST_EXECUTED, fermi_sm_odd1_su_inst_executed_enc_str_1, fermi_sm_odd1_su_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_AGU_INST_EXECUTED, fermi_sm_odd1_agu_inst_executed_enc_str_1, fermi_sm_odd1_agu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_TEX_INST_EXECUTED, fermi_sm_odd1_tex_inst_executed_enc_str_1, fermi_sm_odd1_tex_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_DSM_INST_EXECUTED, fermi_sm_odd1_dsm_inst_executed_enc_str_1, fermi_sm_odd1_dsm_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_SCH_INTERNAL_INST_EXECUTED, fermi_sm_odd1_sch_internal_inst_executed_enc_str_1, fermi_sm_odd1_sch_internal_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_FE_INST_EXECUTED, fermi_sm_odd1_fe_inst_executed_enc_str_1, fermi_sm_odd1_fe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_ALU_ONLY_INST_EXECUTED, fermi_sm_even0_alu_only_inst_executed_enc_str_1, fermi_sm_even0_alu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_XLU_ONLY_INST_EXECUTED, fermi_sm_even0_xlu_only_inst_executed_enc_str_1, fermi_sm_even0_xlu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_ALU_XLU_BIPIPE_INST_EXECUTED, fermi_sm_even0_alu_xlu_bipipe_inst_executed_enc_str_1, fermi_sm_even0_alu_xlu_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_FMALITE_ONLY_INST_EXECUTED, fermi_sm_even0_fmalite_only_inst_executed_enc_str_1, fermi_sm_even0_fmalite_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_FMA32_ONLY_INST_EXECUTED, fermi_sm_even0_fma32_only_inst_executed_enc_str_1, fermi_sm_even0_fma32_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_FMALITE_FMA32_BIPIPE_INST_EXECUTED, fermi_sm_even0_fmalite_fma32_bipipe_inst_executed_enc_str_1, fermi_sm_even0_fmalite_fma32_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_FU_INST_EXECUTED, fermi_sm_even0_fu_inst_executed_enc_str_1, fermi_sm_even0_fu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_FMA64_INST_EXECUTED, fermi_sm_even0_fma64_inst_executed_enc_str_1, fermi_sm_even0_fma64_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_SU_INST_EXECUTED, fermi_sm_even0_su_inst_executed_enc_str_1, fermi_sm_even0_su_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_AGU_INST_EXECUTED, fermi_sm_even0_agu_inst_executed_enc_str_1, fermi_sm_even0_agu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_TEX_INST_EXECUTED, fermi_sm_even0_tex_inst_executed_enc_str_1, fermi_sm_even0_tex_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_DSM_INST_EXECUTED, fermi_sm_even0_dsm_inst_executed_enc_str_1, fermi_sm_even0_dsm_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_SCH_INTERNAL_INST_EXECUTED, fermi_sm_even0_sch_internal_inst_executed_enc_str_1, fermi_sm_even0_sch_internal_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_FE_INST_EXECUTED, fermi_sm_even0_fe_inst_executed_enc_str_1, fermi_sm_even0_fe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_ALU_ONLY_INST_EXECUTED, fermi_sm_even1_alu_only_inst_executed_enc_str_1, fermi_sm_even1_alu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_XLU_ONLY_INST_EXECUTED, fermi_sm_even1_xlu_only_inst_executed_enc_str_1, fermi_sm_even1_xlu_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_ALU_XLU_BIPIPE_INST_EXECUTED, fermi_sm_even1_alu_xlu_bipipe_inst_executed_enc_str_1, fermi_sm_even1_alu_xlu_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_FMALITE_ONLY_INST_EXECUTED, fermi_sm_even1_fmalite_only_inst_executed_enc_str_1, fermi_sm_even1_fmalite_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_FMA32_ONLY_INST_EXECUTED, fermi_sm_even1_fma32_only_inst_executed_enc_str_1, fermi_sm_even1_fma32_only_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_FMALITE_FMA32_BIPIPE_INST_EXECUTED, fermi_sm_even1_fmalite_fma32_bipipe_inst_executed_enc_str_1, fermi_sm_even1_fmalite_fma32_bipipe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_FU_INST_EXECUTED, fermi_sm_even1_fu_inst_executed_enc_str_1, fermi_sm_even1_fu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_FMA64_INST_EXECUTED, fermi_sm_even1_fma64_inst_executed_enc_str_1, fermi_sm_even1_fma64_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_SU_INST_EXECUTED, fermi_sm_even1_su_inst_executed_enc_str_1, fermi_sm_even1_su_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_AGU_INST_EXECUTED, fermi_sm_even1_agu_inst_executed_enc_str_1, fermi_sm_even1_agu_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_TEX_INST_EXECUTED, fermi_sm_even1_tex_inst_executed_enc_str_1, fermi_sm_even1_tex_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_DSM_INST_EXECUTED, fermi_sm_even1_dsm_inst_executed_enc_str_1, fermi_sm_even1_dsm_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_SCH_INTERNAL_INST_EXECUTED, fermi_sm_even1_sch_internal_inst_executed_enc_str_1, fermi_sm_even1_sch_internal_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_FE_INST_EXECUTED, fermi_sm_even1_fe_inst_executed_enc_str_1, fermi_sm_even1_fe_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_ELAPSED_CYCLES_SM,     fermi_elapsed_cycles_sm_enc_str_1, fermi_elapsed_cycles_sm_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION,fermi_elapsed_cycles_sm_enc_str_6},
    {FERMI_LTC0_READ_VIDMEM_SECTORS_FBP,fermi_ltc0_read_vidmem_sectors_fbp_enc_str_1,fermi_ltc0_read_vidmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, fermi_ltc0_read_vidmem_sectors_fbp_enc_str_8},
    {FERMI_LTC1_READ_VIDMEM_SECTORS_FBP,fermi_ltc1_read_vidmem_sectors_fbp_enc_str_1,fermi_ltc1_read_vidmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, fermi_ltc0_read_vidmem_sectors_fbp_enc_str_8},
    {FERMI_LTC0_WRITE_VIDMEM_SECTORS_FBP,fermi_ltc0_write_vidmem_sectors_fbp_enc_str_1,fermi_ltc0_write_vidmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, fermi_ltc0_write_vidmem_sectors_fbp_enc_str_8},
    {FERMI_LTC1_WRITE_VIDMEM_SECTORS_FBP,fermi_ltc1_write_vidmem_sectors_fbp_enc_str_1,fermi_ltc1_write_vidmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, fermi_ltc0_write_vidmem_sectors_fbp_enc_str_8},
    {FERMI_LTC0_ATOMIC_L1_SECTORS_FBP,fermi_ltc0_atomic_l1_sectors_fbp_enc_str_1,fermi_ltc0_atomic_l1_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, fermi_ltc0_atomic_l1_sectors_fbp_enc_str_8},
    {FERMI_LTC1_ATOMIC_L1_SECTORS_FBP,fermi_ltc1_atomic_l1_sectors_fbp_enc_str_1,fermi_ltc1_atomic_l1_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, fermi_ltc0_atomic_l1_sectors_fbp_enc_str_8},
    {FERMI_SM_ODD_ALU_ONLY_INST_ISSUED,fermi_sm_odd_alu_only_inst_issued_enc_str_1, fermi_sm_odd_alu_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_XLU_ONLY_INST_ISSUED,fermi_sm_odd_xlu_only_inst_issued_enc_str_1, fermi_sm_odd_xlu_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_ALU_XLU_BIPIPE_INST_ISSUED,fermi_sm_odd_alu_xlu_bipipe_inst_issued_enc_str_1, fermi_sm_odd_alu_xlu_bipipe_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_FMALITE_ONLY_INST_ISSUED,fermi_sm_odd_fmalite_only_inst_issued_enc_str_1, fermi_sm_odd_fmalite_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_FMA32_ONLY_INST_ISSUED,fermi_sm_odd_fma32_only_inst_issued_enc_str_1, fermi_sm_odd_fma32_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_FMALITE_FMA32_BIPIPE_INST_ISSUED,fermi_sm_odd_fmalite_fma32_bipipe_inst_issued_enc_str_1, fermi_sm_odd_fmalite_fma32_bipipe_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_FU_INST_ISSUED,fermi_sm_odd_fu_inst_issued_enc_str_1, fermi_sm_odd_fu_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_FMA64_INST_ISSUED,fermi_sm_odd_fma64_inst_issued_enc_str_1, fermi_sm_odd_fma64_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_SU_INST_ISSUED,fermi_sm_odd_su_inst_issued_enc_str_1, fermi_sm_odd_su_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_AGU_INST_ISSUED,fermi_sm_odd_agu_inst_issued_enc_str_1, fermi_sm_odd_agu_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_TEX_INST_ISSUED,fermi_sm_odd_tex_inst_issued_enc_str_1, fermi_sm_odd_tex_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_DSM_INST_ISSUED,fermi_sm_odd_dsm_inst_issued_enc_str_1, fermi_sm_odd_dsm_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_SCH_INTERNAL_INST_ISSUED,fermi_sm_odd_sch_internal_inst_issued_enc_str_1, fermi_sm_odd_sch_internal_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD_FE_INST_ISSUED,fermi_sm_odd_fe_inst_issued_enc_str_1, fermi_sm_odd_fe_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_ALU_ONLY_INST_ISSUED,fermi_sm_even_alu_only_inst_issued_enc_str_1, fermi_sm_even_alu_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_XLU_ONLY_INST_ISSUED,fermi_sm_even_xlu_only_inst_issued_enc_str_1, fermi_sm_even_xlu_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_ALU_XLU_BIPIPE_INST_ISSUED,fermi_sm_even_alu_xlu_bipipe_inst_issued_enc_str_1, fermi_sm_even_alu_xlu_bipipe_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_FMALITE_ONLY_INST_ISSUED,fermi_sm_even_fmalite_only_inst_issued_enc_str_1, fermi_sm_even_fmalite_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_FMA32_ONLY_INST_ISSUED,fermi_sm_even_fma32_only_inst_issued_enc_str_1, fermi_sm_even_fma32_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_FMALITE_FMA32_BIPIPE_INST_ISSUED,fermi_sm_even_fmalite_fma32_bipipe_inst_issued_enc_str_1, fermi_sm_even_fmalite_fma32_bipipe_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_FU_INST_ISSUED,fermi_sm_even_fu_inst_issued_enc_str_1, fermi_sm_even_fu_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_FMA64_INST_ISSUED,fermi_sm_even_fma64_inst_issued_enc_str_1, fermi_sm_even_fma64_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_SU_INST_ISSUED,fermi_sm_even_su_inst_issued_enc_str_1, fermi_sm_even_su_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_AGU_INST_ISSUED,fermi_sm_even_agu_inst_issued_enc_str_1, fermi_sm_even_agu_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_TEX_INST_ISSUED,fermi_sm_even_tex_inst_issued_enc_str_1, fermi_sm_even_tex_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_DSM_INST_ISSUED,fermi_sm_even_dsm_inst_issued_enc_str_1, fermi_sm_even_dsm_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_SCH_INTERNAL_INST_ISSUED,fermi_sm_even_sch_internal_inst_issued_enc_str_1, fermi_sm_even_sch_internal_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN_FE_INST_ISSUED,fermi_sm_even_fe_inst_issued_enc_str_1, fermi_sm_even_fe_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_ALU_ONLY_INST_ISSUED, fermi_sm_odd0_alu_only_inst_issued_enc_str_1, fermi_sm_odd0_alu_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_XLU_ONLY_INST_ISSUED, fermi_sm_odd0_xlu_only_inst_issued_enc_str_1, fermi_sm_odd0_xlu_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_ALU_XLU_BIPIPE_INST_ISSUED, fermi_sm_odd0_alu_xlu_bipipe_inst_issued_enc_str_1, fermi_sm_odd0_alu_xlu_bipipe_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_FMALITE_ONLY_INST_ISSUED, fermi_sm_odd0_fmalite_only_inst_issued_enc_str_1, fermi_sm_odd0_fmalite_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_FMA32_ONLY_INST_ISSUED, fermi_sm_odd0_fma32_only_inst_issued_enc_str_1, fermi_sm_odd0_fma32_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_FMALITE_FMA32_BIPIPE_INST_ISSUED, fermi_sm_odd0_fmalite_fma32_bipipe_inst_issued_enc_str_1, fermi_sm_odd0_fmalite_fma32_bipipe_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_FU_INST_ISSUED, fermi_sm_odd0_fu_inst_issued_enc_str_1, fermi_sm_odd0_fu_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_FMA64_INST_ISSUED, fermi_sm_odd0_fma64_inst_issued_enc_str_1, fermi_sm_odd0_fma64_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_SU_INST_ISSUED, fermi_sm_odd0_su_inst_issued_enc_str_1, fermi_sm_odd0_su_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_AGU_INST_ISSUED, fermi_sm_odd0_agu_inst_issued_enc_str_1, fermi_sm_odd0_agu_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_TEX_INST_ISSUED, fermi_sm_odd0_tex_inst_issued_enc_str_1, fermi_sm_odd0_tex_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_DSM_INST_ISSUED, fermi_sm_odd0_dsm_inst_issued_enc_str_1, fermi_sm_odd0_dsm_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_SCH_INTERNAL_INST_ISSUED, fermi_sm_odd0_sch_internal_inst_issued_enc_str_1, fermi_sm_odd0_sch_internal_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD0_FE_INST_ISSUED, fermi_sm_odd0_fe_inst_issued_enc_str_1, fermi_sm_odd0_fe_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_ALU_ONLY_INST_ISSUED, fermi_sm_odd1_alu_only_inst_issued_enc_str_1, fermi_sm_odd1_alu_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_XLU_ONLY_INST_ISSUED, fermi_sm_odd1_xlu_only_inst_issued_enc_str_1, fermi_sm_odd1_xlu_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_ALU_XLU_BIPIPE_INST_ISSUED, fermi_sm_odd1_alu_xlu_bipipe_inst_issued_enc_str_1, fermi_sm_odd1_alu_xlu_bipipe_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_FMALITE_ONLY_INST_ISSUED, fermi_sm_odd1_fmalite_only_inst_issued_enc_str_1, fermi_sm_odd1_fmalite_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_FMA32_ONLY_INST_ISSUED, fermi_sm_odd1_fma32_only_inst_issued_enc_str_1, fermi_sm_odd1_fma32_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_FMALITE_FMA32_BIPIPE_INST_ISSUED, fermi_sm_odd1_fmalite_fma32_bipipe_inst_issued_enc_str_1, fermi_sm_odd1_fmalite_fma32_bipipe_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_FU_INST_ISSUED, fermi_sm_odd1_fu_inst_issued_enc_str_1, fermi_sm_odd1_fu_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_FMA64_INST_ISSUED, fermi_sm_odd1_fma64_inst_issued_enc_str_1, fermi_sm_odd1_fma64_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_SU_INST_ISSUED, fermi_sm_odd1_su_inst_issued_enc_str_1, fermi_sm_odd1_su_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_AGU_INST_ISSUED, fermi_sm_odd1_agu_inst_issued_enc_str_1, fermi_sm_odd1_agu_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_TEX_INST_ISSUED, fermi_sm_odd1_tex_inst_issued_enc_str_1, fermi_sm_odd1_tex_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_DSM_INST_ISSUED, fermi_sm_odd1_dsm_inst_issued_enc_str_1, fermi_sm_odd1_dsm_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_SCH_INTERNAL_INST_ISSUED, fermi_sm_odd1_sch_internal_inst_issued_enc_str_1, fermi_sm_odd1_sch_internal_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_ODD1_FE_INST_ISSUED, fermi_sm_odd1_fe_inst_issued_enc_str_1, fermi_sm_odd1_fe_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_ALU_ONLY_INST_ISSUED, fermi_sm_even0_alu_only_inst_issued_enc_str_1, fermi_sm_even0_alu_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_XLU_ONLY_INST_ISSUED, fermi_sm_even0_xlu_only_inst_issued_enc_str_1, fermi_sm_even0_xlu_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_ALU_XLU_BIPIPE_INST_ISSUED, fermi_sm_even0_alu_xlu_bipipe_inst_issued_enc_str_1, fermi_sm_even0_alu_xlu_bipipe_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_FMALITE_ONLY_INST_ISSUED, fermi_sm_even0_fmalite_only_inst_issued_enc_str_1, fermi_sm_even0_fmalite_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_FMA32_ONLY_INST_ISSUED, fermi_sm_even0_fma32_only_inst_issued_enc_str_1, fermi_sm_even0_fma32_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_FMALITE_FMA32_BIPIPE_INST_ISSUED, fermi_sm_even0_fmalite_fma32_bipipe_inst_issued_enc_str_1, fermi_sm_even0_fmalite_fma32_bipipe_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_FU_INST_ISSUED, fermi_sm_even0_fu_inst_issued_enc_str_1, fermi_sm_even0_fu_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_FMA64_INST_ISSUED, fermi_sm_even0_fma64_inst_issued_enc_str_1, fermi_sm_even0_fma64_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_SU_INST_ISSUED, fermi_sm_even0_su_inst_issued_enc_str_1, fermi_sm_even0_su_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_AGU_INST_ISSUED, fermi_sm_even0_agu_inst_issued_enc_str_1, fermi_sm_even0_agu_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_TEX_INST_ISSUED, fermi_sm_even0_tex_inst_issued_enc_str_1, fermi_sm_even0_tex_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_DSM_INST_ISSUED, fermi_sm_even0_dsm_inst_issued_enc_str_1, fermi_sm_even0_dsm_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_SCH_INTERNAL_INST_ISSUED, fermi_sm_even0_sch_internal_inst_issued_enc_str_1, fermi_sm_even0_sch_internal_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN0_FE_INST_ISSUED, fermi_sm_even0_fe_inst_issued_enc_str_1, fermi_sm_even0_fe_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_ALU_ONLY_INST_ISSUED, fermi_sm_even1_alu_only_inst_issued_enc_str_1, fermi_sm_even1_alu_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_XLU_ONLY_INST_ISSUED, fermi_sm_even1_xlu_only_inst_issued_enc_str_1, fermi_sm_even1_xlu_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_ALU_XLU_BIPIPE_INST_ISSUED, fermi_sm_even1_alu_xlu_bipipe_inst_issued_enc_str_1, fermi_sm_even1_alu_xlu_bipipe_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_FMALITE_ONLY_INST_ISSUED, fermi_sm_even1_fmalite_only_inst_issued_enc_str_1, fermi_sm_even1_fmalite_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_FMA32_ONLY_INST_ISSUED, fermi_sm_even1_fma32_only_inst_issued_enc_str_1, fermi_sm_even1_fma32_only_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_FMALITE_FMA32_BIPIPE_INST_ISSUED, fermi_sm_even1_fmalite_fma32_bipipe_inst_issued_enc_str_1, fermi_sm_even1_fmalite_fma32_bipipe_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_FU_INST_ISSUED, fermi_sm_even1_fu_inst_issued_enc_str_1, fermi_sm_even1_fu_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_FMA64_INST_ISSUED, fermi_sm_even1_fma64_inst_issued_enc_str_1, fermi_sm_even1_fma64_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_SU_INST_ISSUED, fermi_sm_even1_su_inst_issued_enc_str_1, fermi_sm_even1_su_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_AGU_INST_ISSUED, fermi_sm_even1_agu_inst_issued_enc_str_1, fermi_sm_even1_agu_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_TEX_INST_ISSUED, fermi_sm_even1_tex_inst_issued_enc_str_1, fermi_sm_even1_tex_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_DSM_INST_ISSUED, fermi_sm_even1_dsm_inst_issued_enc_str_1, fermi_sm_even1_dsm_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_SCH_INTERNAL_INST_ISSUED, fermi_sm_even1_sch_internal_inst_issued_enc_str_1, fermi_sm_even1_sch_internal_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_SM_EVEN1_FE_INST_ISSUED, fermi_sm_even1_fe_inst_issued_enc_str_1, fermi_sm_even1_fe_inst_issued_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, INTERNAL_EVENT_DESCRIPTION},
    {FERMI_TEX0_RETURN_PACKET_COUNT, fermi_tex0_return_packet_count_enc_str_1, fermi_tex0_return_packet_count_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, fermi_tex0_return_packet_count_enc_str_6},
    {FERMI_TEX1_RETURN_PACKET_COUNT, fermi_tex1_return_packet_count_enc_str_1, fermi_tex1_return_packet_count_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, fermi_tex1_return_packet_count_enc_str_5},

    {INVALID_PM_SIGNAL_NEW, ""}
};

CUdomainInfo domainInfoGF100   = { 11,    domainTableGF100, pFermiSignalDescriptionArray, 0 , 0};
CUdomainInfo domainInfoGF104   = { 11,    domainTableGF104, pFermiSignalDescriptionArray, 0 , 0};
CUdomainInfo domainInfoGF108   = { 11,    domainTableGF108, pFermiSignalDescriptionArray, 0 , 0};
CUdomainInfo domainInfoGF119   = { 11,    domainTableGF119, pFermiSignalDescriptionArray, 0 , 0};
CUdomainInfo domainInfoGF117   = { 11,    domainTableGF117, pFermiSignalDescriptionArray, 0 , 0};
