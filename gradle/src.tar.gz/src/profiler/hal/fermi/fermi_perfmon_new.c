/*
* Copyright 1993-2009 by NVIDIA Corporation.  All rights reserved.  All
* information contained herein is proprietary and confidential to NVIDIA
* Corporation.  Any use, reproduction, or disclosure without the written
* permission of NVIDIA Corporation is prohibited.
*/

/******************************************************************************
*
*   Module: fermi_perfmon_new.c
*
*   Description:
*       Performance monitor support in compute driver architecture.
*
******************************************************************************/

#include <string.h>
#include <ctype.h>

#include "fermi_perfmon_new.h"
#include "cuda_internal.h"
#include "cuda_device.h"
#include "cuda_macros.h"
#include "cuos.h"
#include "fermi/gf100/dev_perf.h"
#include "fermi/gf100/pm_signals.h"
#include "fermi/gf100/dev_ctxsw_prog.h"     // needed for falcon method
#include "halo_helper.h"
#include "cui/hal/fermi/fermi.h"
#include "perfmon_common.h"
#include "stream_push.h"

//TBD collect all scattered register settings for each domain and put in one function
//TBD Set register common function need to be different and should be thread safe
//TBD check all the parameters, pointers etc for validity.

// compare function for event group
static NvBool egCompareData(const void *data1, const void *data2) {
    return ( (CUeventGroup*)data1 == (CUeventGroup*)data2 );
}

// compare function for event (signal) Ids
static NvBool eventIdCompareData(const void *data1, const void *data2) {
    return (((CUeventData*)((CUeventInfo*)data1)->pEventData)->signalId == *(NvU32*)data2 );
}

static NV_INLINE NvBool fermiIsPpaSoftwareCounterDomain(CUeventDomainID domainId, NvU64 arch);
static CUprofResult fermiDestroyEventGroup(CUeventGroup *pEventGroup);
//TBD : Shift these functions up in the file to get rid of declaration
static CUresult detectCounterOverflowSMInternal(const CUeventGroup *pEventGroup, NvBool* bIsOverflow);
static CUresult SetupPMRegistersSMInternal(CUeventGroup *pEventGroup);
static CUresult resetPMSMInternal(CUeventGroup *pEventGroup);
static CUresult logPMCountersSMInternal(CUeventGroup *pEventGroup);
static CUresult setPMEnableRegSM(const CUeventGroup *pEventGroup, NvBool bEnable);
static CUprofResult PMReleaseModeB(const CUeventGroup *pEventGroup);
static CUresult setFalcon05Method(CUctx* ctx);

// Routine to setup Falcon05 method
static CUresult setFalcon05Method(CUctx* ctx)
{
    CUresult status = CUDA_SUCCESS;
    CUnvCurrent* nvCurrent = NULL;
    uint32_t data, mask;
    uint32_t headerOffset, headerType, headerIndex, accessHeader;
    int i = 0;

    CU_TRACE_FUNCTION();

    if (ctx->pmNew->flag & CU_PM_FLAG_FALCON_05_METHOD) {
        // falcon05 method is already set
        return CUDA_SUCCESS;
    }

    // https://wiki.nvidia.com/fermi/index.php/Fermi_Firmware_Methods#Class_0x9097.2C_SetFalcon05
    //
    // SetFaclon05              = data access_header
    // SetMmeShadowScratch[0]   = flag register
    // SetMmeShadowScratch[1]   = data
    // SetMmeShadowScratch[2]   = mask

    streamBeginPush(ctx->streamManager, CU_CHANNEL_COMPUTE, ctx->barrierStream, &nvCurrent, NULL);

    data = NV_CTXSW_MAIN_IMAGE_MISC_OPTIONS_SM_PRI_WAR_ENABLED;
    mask = DRF_SHIFTMASK(NV_CTXSW_MAIN_IMAGE_MISC_OPTIONS_SM_PRI_WAR);
    headerOffset = REF_NUM(NV_CTXSW_MAIN_IMAGE_ACCESS_HEADER_OFFSET, NV_CTXSW_MAIN_IMAGE_MISC_OPTIONS);
    headerType   = REF_NUM(NV_CTXSW_MAIN_IMAGE_ACCESS_HEADER_TYPE, NV_CTXSW_MAIN_IMAGE_ACCESS_HEADER_TYPE_MAIN);
    headerIndex  = REF_NUM(NV_CTXSW_MAIN_IMAGE_ACCESS_HEADER_INDEX, 0);
    accessHeader = headerOffset | headerType | headerIndex;

    NV_PUSH_1U(90C0, WAIT_FOR_IDLE,  0);

    NV_PUSH_3U(90C0, SET_MME_SHADOW_SCRATCH(0), 0,
                     SET_MME_SHADOW_SCRATCH(1), data,
                     SET_MME_SHADOW_SCRATCH(2), mask);
    NV_PUSH_1U(90C0, SET_FALCON05, accessHeader);

    for (i  = 0; i < 10; i++) {
        NV_PUSH_1U(90C0, NO_OPERATION, 0);
    }

    NV_PUSH_1U(90C0, WAIT_FOR_IDLE,  0);

    streamEndPush(ctx->barrierStream, nvCurrent, NULL);

    // Wait for the write to complete
    status = cuiCtxSynchronize(ctx);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Ctx sync failed following Falcon05 method.\n"));
        return status;
    }

    // set flag
    ctx->pmNew->flag |= CU_PM_FLAG_FALCON_05_METHOD;

    return status;
}

CUprofResult fermiPerfmonGetInstanceValues(CUdev *dev, CUdomainData *domainData, NvU32 *avail, NvU32 *total)
{
    NvU32 k = 0;
    if(!avail || !total)
        return CUPROF_ERROR_INVALID_PARAMETER;

    *avail = *total = 1;
    if (domainData->domainId == FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST)
        return CUPROF_SUCCESS;

    switch(domainData->chipletType)
    {
    case PM_CHIPLET_TYPE_GPC:
        *total = 0;
        for(k=0; k<dev->state.limits.numGpcs; k++) {
            *total += dev->state.limits.numTpcsPerGpc[k];
        }
        if((CUPROF_EVENT_COLLECTION_METHOD_SMPERF == domainData->eventCollectionMethod) ||
          (CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW == domainData->eventCollectionMethod) ||
          (CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW == domainData->eventCollectionMethod)) {
            *avail = *total;
        }
        else {
            *avail = dev->state.limits.numGpcs;
        }
        break;
    case PM_CHIPLET_TYPE_FBP:
        *total = dev->state.limits.numFbps;
        *avail = *total;
        break;
    case PM_CHIPLET_TYPE_SYS:
        *total = 1;
        *avail = *total;
        break;
    default:
        CU_ASSERT(0);
        break;
    }
    return CUPROF_SUCCESS;
}

CUprofResult fermiPerfmonDeviceInitEventDomainInfo(CUdev *pDev) {
    CUprofResult status = CUPROF_SUCCESS;
    PerfSignalTableNew *pSignalTable = NULL;
    CUdomainData *pDomainData = NULL;
    NvU32 maxInternalSignals = 0;
    NvU32 maxExternalSignals = 0;
    NvU32 numDomains = 0;
    NvU32 numInternalDomains = 0;
    NvU32 i = 0;
    NvU32 j = 0, sigTableIdx = 0;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pDev);

    if(pDev->state.pDomainInfo == NULL) {
        return CUPROF_ERROR_UNKNOWN;
    }

    if (pDev->state.pDomainInfo->bInit) {
        // domain data is already populated
        return CUPROF_SUCCESS;
    }
    else
    {
        NvBool internalCountersExposed = 0;
        unsigned int old = cuosInterlockedExchange(&pDev->state.pDomainInfo->bInitStarted, 1);
        if (old == 0) {
            perfmonDemangleStrings();
            internalCountersExposed = perfmonInternalCountersExposed();
            numDomains = pDev->state.pDomainInfo->numDomains;

            if(!internalCountersExposed) {
                for (i = 0; i < numDomains; i++) {
                        if (!strncmp(pDev->state.pDomainInfo->pDomainTable[i].domainName, PM_INTERNAL_SIGNAL_PREFIX, 2)) {
                            numInternalDomains++;
                        }
                }
                numDomains -= numInternalDomains;
            }

            pDev->state.pDomainInfo->numDomains = numDomains;

            for (i = 0; i < numDomains; i++) {
                maxExternalSignals = maxInternalSignals = 0;
                for(sigTableIdx = 0; sigTableIdx < pDev->state.pDomainInfo->pDomainTable[i].numPerfSignalTables; sigTableIdx++) {
                    j = 0;
                    pSignalTable = (PerfSignalTableNew*)pDev->state.pDomainInfo->pDomainTable[i].pEventTableInfo[sigTableIdx].pEventData;
                    if (pSignalTable != NULL) {
                        while (pSignalTable[j].signalId != INVALID_PM_SIGNAL_NEW) {
                            // Increment for only EXPOSED type of signals:
                            if (SIG_TYPE_IS_EXPOSED(pSignalTable[j].signalId)) {
                                maxExternalSignals++;
                            }
                            // Increment for exposed but internal and internally exposed for testing type signals:
                            else if (!SIG_TYPE_IS_INTERNAL(pSignalTable[j].signalId)){
                                maxInternalSignals++;
                            }
                            j++;
                        }
                    }
                }
                pDomainData = &pDev->state.pDomainInfo->pDomainTable[i];

                pDomainData->maxExternalEvents = maxExternalSignals;
                pDomainData->maxInternalEvents = maxInternalSignals;

                if(internalCountersExposed) {
                    pDomainData->exposedEvents         = maxExternalSignals + maxInternalSignals;
                }
                else {
                    pDomainData->exposedEvents         = maxExternalSignals;
                }
            }
            cuosInterlockedIncrement(&pDev->state.pDomainInfo->bInit);
        }
        else {
            // Another thread has started initialization, all other threads
            // must wait until it has completed.
            while (pDev->state.pDomainInfo->bInit == 0) {
                cuosThreadYield();
            }
        }
    }

    return status;
}

//Allocate the arch specific eventgroup structure and initialize it
static CUprofResult fermiInitEventGroup(CUeventGroup *pEventGroup)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUfermiEventGroup *pFermiEg = NULL;

    CU_TRACE_FUNCTION();

    if(pEventGroup->arch.fermiEventGroup == NULL) {
        pFermiEg = (CUfermiEventGroup*)malloc(sizeof(CUfermiEventGroup));
        if(!pFermiEg) {
            CU_ERROR_PRINT(("Failed to allocate memory for CUfermiEventGroup\n"));
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto Error;
        }
        cuosMemset(pFermiEg, 0, sizeof(CUfermiEventGroup));

        pEventGroup->arch.fermiEventGroup = pFermiEg;

        //TBD allocation of domain specific structures can be delayed until the
        //first event is added, saves memory
        //Following is used only for PM signals
        pFermiEg->pParsedClk = (CUparsedClk*)malloc(sizeof(CUparsedClk));

        if (!pFermiEg->pParsedClk) {
            CU_ERROR_PRINT(("Failed to allocate memory for CUparsedClk\n"));
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto Error;
        }
        cuosMemset(pFermiEg->pParsedClk, 0, sizeof(CUparsedClk));

        //Following is used only for SM counters
        pFermiEg->pSM = (CUSMCtrInfo*)malloc(sizeof(CUSMCtrInfo));

        if (!pFermiEg->pSM) {
            CU_ERROR_PRINT(("Failed to allocate memory for CUSMCtrInfo\n"));
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto Error;
        }
        cuosMemset(pFermiEg->pSM, 0, sizeof(CUSMCtrInfo));
    }

Error:
    if (status != CUPROF_SUCCESS) {
        fermiDestroyEventGroup(pEventGroup);
    }

    return status;
}

//Destroy the arch specific eventgroup structure
static CUprofResult fermiDestroyEventGroup(CUeventGroup *pEventGroup)
{
    NvU32 idx = 0;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if (pEventGroup->domainId != FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST) {
        if(pEventGroup->arch.fermiEventGroup)
        {
            if(pEventGroup->arch.fermiEventGroup->pParsedClk)
            {
                // Freeing the extra space as well which is allocated for profiling elapsed_clocks
                for (idx = 0; idx < (CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS+1); idx++) {
                    if(pEventGroup->arch.fermiEventGroup->pParsedClk->pParsedUnit[idx])
                    {
                        free (pEventGroup->arch.fermiEventGroup->pParsedClk->pParsedUnit[idx]);
                        pEventGroup->arch.fermiEventGroup->pParsedClk->pParsedUnit[idx] = NULL;
                    }
                }
                if(pEventGroup->arch.fermiEventGroup->pParsedClk->values) {
                    free (pEventGroup->arch.fermiEventGroup->pParsedClk->values);
                    pEventGroup->arch.fermiEventGroup->pParsedClk->values = NULL;
                }

                free(pEventGroup->arch.fermiEventGroup->pParsedClk);
                pEventGroup->arch.fermiEventGroup->pParsedClk = NULL;
            }

            if(pEventGroup->arch.fermiEventGroup->pSM)
            {
                if(pEventGroup->arch.fermiEventGroup->pSM->values) {
                    free (pEventGroup->arch.fermiEventGroup->pSM->values);
                    pEventGroup->arch.fermiEventGroup->pSM->values = NULL;
                }
                free(pEventGroup->arch.fermiEventGroup->pSM);
                pEventGroup->arch.fermiEventGroup->pSM = NULL;
            }

            if(pEventGroup->arch.fermiEventGroup->priAddress)
            {
                free(pEventGroup->arch.fermiEventGroup->priAddress);
                pEventGroup->arch.fermiEventGroup->priAddress = NULL;
            }

            if(pEventGroup->arch.fermiEventGroup->pmmAddress)
            {
                free(pEventGroup->arch.fermiEventGroup->pmmAddress);
                pEventGroup->arch.fermiEventGroup->pmmAddress = NULL;
            }


            free(pEventGroup->arch.fermiEventGroup);
            pEventGroup->arch.fermiEventGroup = NULL;
        }
    }
    return CUPROF_SUCCESS;
}

CUprofResult fermiPerfmonEventGroupCreate(CUctx *pCtx, CUeventGroup **pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    CUeventGroup *pGroup = NULL;

    CU_TRACE_FUNCTION();

    CU_ASSERT(pEventGroup);
    CU_ASSERT(pCtx);

    pGroup = (CUeventGroup*)malloc(sizeof(CUeventGroup));
    if (pGroup == NULL) {
        CU_DEBUG_PRINT(("Failed to allocate memory to event group\n"));
        return CUPROF_ERROR_OUT_OF_MEMORY;
    }
    cuosMemset(pGroup, 0, sizeof(CUeventGroup));

    pGroup->domainId = INVALID_DOMAIN_ID;
    pGroup->pCtx = pCtx;                 //Context for which eventgroup is created

    *pEventGroup = pGroup;

    if (pCtx->pmNew == NULL) {
        status = perfmonStructCreate(&pCtx->pmNew);
        if (status != CUPROF_SUCCESS) {
            goto Exit;
        }
    }

    if (pCtx->pmNew->egList == NULL) {
        // event object list hasn't been init yet, do it now
        status = (CUprofResult)listInit(&pCtx->pmNew->egList, NULL, NULL, NULL, egCompareData);
        if (status != CUPROF_SUCCESS) {
            goto Exit;
        }
    }

    // add to the event group list maintained in the context
    listAddToHead(pCtx->pmNew->egList, *pEventGroup);

    pCtx->pmNew->totalEventGroups++;
    return CUPROF_SUCCESS;

Exit:
    //If any error occurs, free allocated memory and return NULL
    fermiDestroyEventGroup(pGroup);
    free(pGroup->values);
    free(pGroup);
    free (pCtx->pmNew);
    pCtx->pmNew = NULL;

    *pEventGroup = NULL;
    CU_ERROR_PRINT(("fermiPerfmonEventGroupCreate Failed\n"));
    return status;
}

CUprofResult fermiPerfmonEventGroupDestroy(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 i = 0;
    CUeventInfo *currEvent = NULL;
    void *eventBase = NULL;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if (pEventGroup->isEnabled) {
        // don't allow destroy for enabled event group
        return CUPROF_ERROR_INVALID_OPERATION;
    }

    currEvent = (CUeventInfo*)listGetNext(pEventGroup->pEventInfoList, &eventBase);
    for (i = 0; (i < pEventGroup->totalCounters) && currEvent; i++, currEvent = (CUeventInfo*)listGetNext(NULL, &eventBase)) {
        if(currEvent) {
            if((pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW) ||
                (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW)) {
                free(currEvent->pEventData);
                currEvent->pEventData = NULL;
            }
            free(currEvent);
        }
    }

    // deallocate arch specific eventgroup
    status = fermiDestroyEventGroup(pEventGroup);

    // destroy event list
    if (pEventGroup->pEventInfoList) {
        listDestroy(pEventGroup->pEventInfoList);
        pEventGroup->pEventInfoList = NULL;
    }
    // deallocate values array
    free (pEventGroup->values);
    pEventGroup->values = NULL;

    // remove event group from list first
    listRemFrom(pEventGroup->pCtx->pmNew->egList, pEventGroup);

    // reduce event group count in context
    pEventGroup->pCtx->pmNew->totalEventGroups--;

    if(pEventGroup->nopTrigSwCounterData) {
        free(pEventGroup->nopTrigSwCounterData);
        pEventGroup->nopTrigSwCounterData = NULL;
    }
    free (pEventGroup);
    pEventGroup = NULL;

    return status;
}

// traverse domain signal table for matching signal
static NV_INLINE CUeventInfo* fermiLookupDomainSignalTable(CUdomainData *pDomainData, const NvU32 eventID)
{
    CUeventData* pEventData = NULL;
    CUeventInfo* pEventTableInfo_temp = NULL;
    NvU32 sigTableIdx = 0;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pDomainData);
    pEventTableInfo_temp = (CUeventInfo*)calloc(1, sizeof(CUeventInfo));
    if (pEventTableInfo_temp == NULL) {
        CU_DEBUG_PRINT(("Failed to allocate memory to pEventTableInfo_temp\n"));
        return NULL;
    }
    for(sigTableIdx = 0; sigTableIdx < pDomainData->numPerfSignalTables; sigTableIdx++) {
        pEventData = (CUeventData*)pDomainData->pEventTableInfo[sigTableIdx].pEventData;
        while (pEventData->signalId != INVALID_PM_SIGNAL_NEW) {
            if (eventID == pEventData->signalId) {
                pEventTableInfo_temp->signalTableType = pDomainData->pEventTableInfo[0].signalTableType;
                pEventTableInfo_temp->pEventData = (void*) pEventData;
                return pEventTableInfo_temp;
            }
            pEventData++;
        }
    }

    // return NULL if not found
    free(pEventTableInfo_temp);
    return NULL;
}

// We can monitor up to four inc-by-1 experiments per domain in ModeB
// Each chiplet/PMM can be configured individually, i.e. 1x8 domains for sys + 4x1 gpcs + 6x2 fpcs
// (as we have 1 SYS, 4 GPCs and 6 FBPs in GF100) results in 24*4 = 96 inc-by-1 experiments
// that can run concurrently on gf100
static CUprofResult canSigBeProfiledModeB(CUeventGroup *pEventGroup, CUeventData *pEventData, NvBool *added)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 i = 0, j = 0, busWidth = 0;
    CUparsedUnit *pParsedUnit = NULL;
    CUparsedClk  *pParsedClk = NULL;

    CU_TRACE_FUNCTION();

    if (!pEventGroup || !pEventGroup->arch.fermiEventGroup || !pEventData) {
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        *added = NV_FALSE;
        goto EXIT;
    }

    pParsedClk = pEventGroup->arch.fermiEventGroup->pParsedClk;

    if (!pParsedClk) {
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        *added = NV_FALSE;
        goto EXIT;
    }

    if (pEventData->signalId == FERMI_ELAPSED_CYCLES_SM) {
        if(pParsedClk->isElapsedClocksProfiled) {
            status = CUPROF_ERROR_NOT_COMPATIBLE;
            *added = NV_FALSE;
            goto EXIT;
        }
        pParsedClk->isElapsedClocksProfiled = 1;
        *added = NV_TRUE;
        goto EXIT;
    }
    if (pEventGroup->totalCounters >= (NvU32)(CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS - (pParsedClk->bParsedMBWS ? 1 : 0) + pParsedClk->isElapsedClocksProfiled)) {
        *added = NV_FALSE;
        status = CUPROF_ERROR_MAX_LIMIT_REACHED;
        goto EXIT;
    }

    // check if multi bus-width signals can be monitored in this run
    busWidth = countBusWidth(pEventData->busSelBits);
    if ((busWidth > 1) && (pEventData->sigType == SIG_TYPE_SINGLE)) {
        if ((pParsedClk && pParsedClk->bParsedMBWS) || (pEventGroup->totalCounters >= (CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS - 1))) {
            CU_DEBUG_PRINT(("Can't monitor multi bus-width signal %s in this run\n", pEventData->pSignalName));
            status = CUPROF_ERROR_NOT_COMPATIBLE;
            *added = NV_FALSE;
            goto EXIT;
        }
    }

    // search for the group in already parsed group table
    for (i = 0; i < CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS; i++) {
        if (pParsedClk->pParsedUnit[i]) {
            pParsedUnit = pParsedClk->pParsedUnit[i];
            if (pParsedUnit->pmUnitId == pEventData->pmUnitId) {
                for (j = 0; j < pParsedUnit->groupCount; j++) {
                    if (pEventData->eventGroup == pParsedUnit->group[j]) {
                        *added = NV_TRUE;
                        goto EXIT;
                    }
                }
                if (pParsedUnit->groupCount >= pParsedUnit->maxGroups) {
                    status = CUPROF_ERROR_NOT_COMPATIBLE;
                    *added = NV_FALSE;
                    goto EXIT;
                }
                else {
                    pParsedUnit->group[pParsedUnit->groupCount] = pEventData->eventGroup;
                    pParsedUnit->groupCount++;
                    *added = NV_TRUE;
                    goto EXIT;

                }
            }
        }
        else {
            break;
        }
    }
    if (i == CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS) {
        status = CUPROF_ERROR_NOT_COMPATIBLE;
        *added = NV_FALSE;
        goto EXIT;
    }
    // group is not found if we gets here, add this group to the table then
    j = 0;
    pParsedClk->pParsedUnit[i] = (CUparsedUnit*)malloc(sizeof(CUparsedUnit));
    if (!pParsedClk->pParsedUnit[i]) {
        CU_ERROR_PRINT(("Failed to allocate memory for pParsedUnit\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        *added = NV_FALSE;
        goto EXIT;
    }
    cuosMemset(pParsedClk->pParsedUnit[i], 0, sizeof(CUparsedUnit));
    pParsedUnit = pParsedClk->pParsedUnit[i];

    while (pEventGroup->pCtx->device->state.pPerfUnitTable[j].pmUnitId != PM_UNIT_MAX) {
        if (pEventGroup->pCtx->device->state.pPerfUnitTable[j].pmUnitId == pEventData->pmUnitId) {
            pParsedUnit->pmUnitId   = pEventData->pmUnitId;
            pParsedUnit->pmUnitIdx  = j;
            pParsedUnit->maxGroups  = pEventGroup->pCtx->device->state.pPerfUnitTable[j].maxGroups;
            pParsedUnit->group[0]   = pEventData->eventGroup;
            pParsedUnit->groupCount = 1;
            *added = NV_TRUE;
            goto EXIT;
        }
        j++;
    }

EXIT:
    if (*added == NV_TRUE) {
        pParsedClk->sigtable[pEventGroup->totalCounters] = pEventData;
        //An experiment also requires both event and trig1, hence treat it as multibus width signal.
        if (((busWidth > 1) && (pEventData->sigType == SIG_TYPE_SINGLE)) || (pEventData->isExpt)) {
            pParsedClk->bParsedMBWS = NV_TRUE;
            pParsedClk->indexMBWS = pEventGroup->totalCounters;
        }
    }

    return status;
}



//TBD get rid of following function. Search if we can use any domain id
static NvU32 getClkIdx(const CUctx *ctx, CUeventDomainID domainId, NvU32 chipletType)
{
    NvU32 clkIdx;
    const NvU32 (*pDomainIds)[PM_MAX_DOMAIN_PER_CHIPLET] = {NULL};

    //gf100 domain ids are valid for GF100B, GF104 and GF106
    const NvU32 gf100_domainIds[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        // sys chiplet
        {FERMI_CLK_DOMAIN_GF100_HOST0 , FERMI_CLK_DOMAIN_GF100_HUB0, FERMI_CLK_DOMAIN_GF100_LEG0, FERMI_CLK_DOMAIN_GF100_LEG1, FERMI_CLK_DOMAIN_GF100_MSD0, FERMI_CLK_DOMAIN_GF100_PCIE0, FERMI_CLK_DOMAIN_GF100_SYS0, FERMI_CLK_DOMAIN_GF100_XBAR0},

            // gpc chiplet
        {FERMI_CLK_DOMAIN_GF100_GPC0},

        // fbp chiplet
        {FERMI_CLK_DOMAIN_GF100_LTC0, FERMI_CLK_DOMAIN_GF100_ROP0}
    };

    const NvU32 gf104_domainIds[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        // sys chiplet
        {FERMI_CLK_DOMAIN_GF104_HOST0 , FERMI_CLK_DOMAIN_GF104_HUB0, FERMI_CLK_DOMAIN_GF104_LEG0, FERMI_CLK_DOMAIN_GF104_LEG1, FERMI_CLK_DOMAIN_GF104_MSD0, FERMI_CLK_DOMAIN_GF104_PCIE0, FERMI_CLK_DOMAIN_GF104_SYS0, FERMI_CLK_DOMAIN_GF104_XBAR0},

            // gpc chiplet
        {FERMI_CLK_DOMAIN_GF104_GPC0},

        // fbp chiplet
        {FERMI_CLK_DOMAIN_GF104_LTC0, FERMI_CLK_DOMAIN_GF104_ROP0}
    };

    // gf108 domain ids
    const NvU32 gf108_domainIds[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        // sys chiplet
        {FERMI_CLK_DOMAIN_GF108_HUB0, FERMI_CLK_DOMAIN_GF108_LEG0, FERMI_CLK_DOMAIN_GF108_LEG1, FERMI_CLK_DOMAIN_GF108_MSD0, FERMI_CLK_DOMAIN_GF108_SYS0, FERMI_CLK_DOMAIN_GF108_XBAR0},

            // gpc chiplet
        {FERMI_CLK_DOMAIN_GF108_GPC0},

        // fbp chiplet
        {FERMI_CLK_DOMAIN_GF108_LTC0, FERMI_CLK_DOMAIN_GF108_ROP0}
    };

    // GF119 domain ids - same as gf108 except LTC0
    // reason - gf119 is sharing gf108 signal tables except LTC one
    const NvU32 gf119_domainIds[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        // sys chiplet
        {FERMI_CLK_DOMAIN_GF108_HUB0, FERMI_CLK_DOMAIN_GF108_LEG0, FERMI_CLK_DOMAIN_GF108_LEG1, FERMI_CLK_DOMAIN_GF108_MSD0, FERMI_CLK_DOMAIN_GF108_SYS0, FERMI_CLK_DOMAIN_GF108_XBAR0},

        // gpc chiplet
        {FERMI_CLK_DOMAIN_GF108_GPC0},

        // fbp chiplet
        {FERMI_CLK_DOMAIN_GF119_LTC0, FERMI_CLK_DOMAIN_GF108_ROP0}
    };

    const NvU32 gf117_domainIds[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        // sys chiplet
        {FERMI_CLK_DOMAIN_GF108_HUB0, FERMI_CLK_DOMAIN_GF108_LEG0, FERMI_CLK_DOMAIN_GF108_LEG1, FERMI_CLK_DOMAIN_GF108_MSD0, FERMI_CLK_DOMAIN_GF108_SYS0, FERMI_CLK_DOMAIN_GF108_XBAR0},

        // gpc chiplet
        {FERMI_CLK_DOMAIN_GF108_GPC0},

        // fbp chiplet
        {FERMI_CLK_DOMAIN_GF117_LTC0, FERMI_CLK_DOMAIN_GF108_ROP0}
    };

    CU_TRACE_FUNCTION();

    if (chipletType >= PM_MAX_CHIPLET_TYPES ) {
        CU_ERROR_PRINT(("Invalid chiplet values\n"));
        CU_ASSERT (0);
        return PM_MAX_DOMAIN_PER_CHIPLET;
    }

    switch(ctx->device->state.chip) {
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF100:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF100B:
        pDomainIds = gf100_domainIds;
        break;
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF104:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF106:
#if defined(NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF104B) && defined(NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF106B)
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF104B:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF106B:
#endif
        pDomainIds = gf104_domainIds;
        break;
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF108:
        pDomainIds = gf108_domainIds;
        break;
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF119:
        pDomainIds = gf119_domainIds;
        break;
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF117:
        pDomainIds = gf117_domainIds;
        break;
#endif
        // TODO : enable other (arch + implementation) when defined
        //case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF110:
        //case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF112:
        //case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF117:
        //case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF118:
        // TODO: implement
        //return 0;
    default:
        CU_ASSERT(0);
        break;
    }

    if (!pDomainIds) {
        CU_ERROR_PRINT(("Invalid domain id values\n"));
        CU_ASSERT (0);
        return PM_MAX_DOMAIN_PER_CHIPLET;
    }

    for(clkIdx=0; clkIdx<PM_MAX_DOMAIN_PER_CHIPLET; clkIdx++)
    {
        if(pDomainIds[chipletType][clkIdx] == domainId)
            return clkIdx;
    }
    CU_ASSERT(clkIdx != PM_MAX_DOMAIN_PER_CHIPLET);

    CU_ASSERT(0);
    return PM_MAX_DOMAIN_PER_CHIPLET;
}

static CUprofResult fermiPerfmonTryAddingCounterNew(CUeventGroup *pEventGroup, CUdomainData *pDomainData, CUeventData *pEventData, NvBool *added, NvU32 *maxSignals)
{
    CUprofResult status = CUPROF_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!pEventGroup || !pDomainData || !pEventData) {
        return CUPROF_ERROR_UNKNOWN;
    }

    *added = NV_FALSE;
    switch(pDomainData->eventCollectionMethod)
    {
    case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
        // Do not allow profiling any SM signal via HWPM except FERMI_ELAPSED_CYCLES_SM:
        if ((pEventData->signalId != FERMI_ELAPSED_CYCLES_SM) && (pEventData->pmUnitId == PM_UNIT_SM)) {
            return CUPROF_ERROR_NOT_COMPATIBLE;
        }
        //Try adding PM signal.
        //Assigning additional space in pEventGroup->values array for elapsed_clocks:
        *maxSignals = CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS+1;
        if (pEventData) {
            status = canSigBeProfiledModeB(pEventGroup, pEventData, added);
        }
        if((*added == NV_TRUE) && (!pEventGroup->totalCounters))
        {
            //Store the chiplet type
            pEventGroup->arch.fermiEventGroup->chipletType = pDomainData->chipletType;
            pEventGroup->arch.fermiEventGroup->clkIdx = getClkIdx(pEventGroup->pCtx, pDomainData->domainId, pDomainData->chipletType);
        }
        break;

    case CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
        //Try adding SM counter.
        if((pEventData->sigType == SIG_TYPE_SINGLE &&
            ((pEventGroup->arch.fermiEventGroup->pSM->SMCountersAdded + countBusWidth(pEventData->busSelBits)) <= CU_PROF_PM_SM_MAX_COUNTERS)) ||
            (pEventData->sigType == SIG_TYPE_MULTIPLE &&
            (pEventGroup->arch.fermiEventGroup->pSM->SMCountersAdded < CU_PROF_PM_SM_MAX_COUNTERS))) {
            pEventGroup->arch.fermiEventGroup->pSM->sigtable[pEventGroup->totalCounters] = pEventData;
            if(0 == pEventGroup->totalCounters) {
                pEventGroup->arch.fermiEventGroup->chipletType = pDomainData->chipletType;
                // clkIdx not required in case of SM Counters. Hence commenting the code.
                //pEventGroup->arch.fermiEventGroup->clkIdx = getClkIdx(pEventGroup->pCtx, FERMI_CLK_DOMAIN_GF100_GPC0, pDomainData->chipletType);
            }
        }
        else {
            return CUPROF_ERROR_MAX_LIMIT_REACHED;
        }
        pEventGroup->arch.fermiEventGroup->pSM->start[pEventGroup->totalCounters] = pEventGroup->arch.fermiEventGroup->pSM->SMCountersAdded;
        // Increment the SMCountersAdded by the bit count in a multibit counter for Sm domain.
        if(pEventData->sigType == SIG_TYPE_SINGLE) {
            pEventGroup->arch.fermiEventGroup->pSM->bitCount[pEventGroup->totalCounters] = countBusWidth(pEventData->busSelBits);
            pEventGroup->arch.fermiEventGroup->pSM->SMCountersAdded += countBusWidth(pEventData->busSelBits);
        }
        else {
            pEventGroup->arch.fermiEventGroup->pSM->bitCount[pEventGroup->totalCounters] = 1;
            pEventGroup->arch.fermiEventGroup->pSM->SMCountersAdded ++;
        }
        *maxSignals = CU_PROF_PM_SM_MAX_COUNTERS;
        *added = NV_TRUE;
        break;

    case CUPROF_EVENT_COLLECTION_METHOD_SW:
        *maxSignals = CU_PROF_SW_COUNTERS_MAX;
        *added = NV_TRUE;
        break;
    default:
        break;
    }
    return status;
}

// fermiCreateSignalTableEntry creates a new signal table entry
// and associates a nop trigger with each s/w counter requested
// In the new table entry the function copies the requested signal ID and name
// and copies the remaining CUeventData structure entries from the associated nop trigger signal table
static CUprofResult fermiCreateSignalTableEntry(CUeventGroup *pEventGroup, CUeventInfo **pEventInfoData, NvU32 eventID)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 i, nopTrigEventID;
    CUdev *pDev = NULL;
    NvU32 numDomains = 0;
    CUdomainData *nopTrigDomainData = NULL;
    CUeventData *nopTrigEventData = NULL;
    CUeventInfo *nopTrigEventInfoData = NULL;
    CUeventData *tempEventData = NULL;

    if(pEventGroup->nopTrigSwCounterData == NULL) {
        return CUPROF_ERROR_UNKNOWN;
    }

    tempEventData = (CUeventData *)calloc(1, sizeof(CUeventData));
    if(!tempEventData) {
        CU_ERROR_PRINT(("Failed to allocate memory for CUeventData\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        return status;
    }

    if(pEventGroup->nopTrigSwCounterData->numSwCountersRequested == FERMI_MAX_SW_COUNTER_PER_EVENTGROUP) {
        CU_DEBUG_PRINT(("Eventgroup limit reached\n"));
        // Only 8 nop_triggers can be issued on fermi. Return from here
        free(tempEventData);
        return CUPROF_ERROR_MAX_LIMIT_REACHED;
    }

    for(i = 0; ; i++) {
        if((eventID == pEventGroup->nopTrigSwCounterData->signalID[i]) || (i == pEventGroup->nopTrigSwCounterData->numSwCountersRequested)) {
            break;
        }
    }

        // If the signal is not requested earlier then associate an internal NOP.TRIG with it.
    if(i == pEventGroup->nopTrigSwCounterData->numSwCountersRequested) {
        nopTrigEventID = FERMI_NOP_TRIG_08 + pEventGroup->nopTrigSwCounterData->numSwCountersRequested;
        pEventGroup->nopTrigSwCounterData->signalID[pEventGroup->nopTrigSwCounterData->numSwCountersRequested] = eventID;
        (pEventGroup->nopTrigSwCounterData->numSwCountersRequested)++;
    }
    else {
        // Else consider the previous associated NOP.TRIG
        nopTrigEventID = FERMI_NOP_TRIG_08 + i;
    }

    pDev = pEventGroup->pCtx->device;
    numDomains = pDev->state.pDomainInfo->numDomains;

    for (i = 0; (i < numDomains && nopTrigEventInfoData == NULL); i++) {
        nopTrigDomainData = &pDev->state.pDomainInfo->pDomainTable[i];
        nopTrigEventInfoData = fermiLookupDomainSignalTable(nopTrigDomainData, nopTrigEventID);
        if(nopTrigEventInfoData) {
            nopTrigEventData = (CUeventData*)nopTrigEventInfoData->pEventData;
            if(nopTrigEventData == NULL) {
                free(tempEventData);
                free(nopTrigEventInfoData);
                return CUPROF_ERROR_UNKNOWN;
            }
        }
    }

    if(nopTrigEventInfoData == NULL) {
        // This means that there is an error in higher level due to which fermiLookupDomainSignalTable did not find any valid signalID
        free(tempEventData);
        return CUPROF_ERROR_UNKNOWN;
    }

    tempEventData->signalId = ((CUeventData*)((*pEventInfoData)->pEventData))->signalId;
    tempEventData->pSignalName = ((CUeventData*)((*pEventInfoData)->pEventData))->pSignalName;
    tempEventData->eventGroup = nopTrigEventData->eventGroup;
    tempEventData->perfEvent = nopTrigEventData->perfEvent;
    tempEventData->function = nopTrigEventData->function;
    tempEventData->watchBus = nopTrigEventData->watchBus;
    tempEventData->clockDomain = nopTrigEventData->clockDomain;
    tempEventData->pmUnitId = nopTrigEventData->pmUnitId;
    for(i = 0; i < SIG_MAX_BUS_WIDTH; i++) {
        tempEventData->busSelBits[i] = nopTrigEventData->busSelBits[i];
    }
    tempEventData->sigType = nopTrigEventData->sigType;
    tempEventData->chipletType = nopTrigEventData->chipletType;
    tempEventData->eventGroup1 = nopTrigEventData->eventGroup1;
    tempEventData->isExpt = nopTrigEventData->isExpt;
    tempEventData->functionExpt = nopTrigEventData->functionExpt;
    tempEventData->watchBusExpt = nopTrigEventData->watchBusExpt;
    tempEventData->eventGroupExpt = nopTrigEventData->eventGroupExpt;
    tempEventData->eventGroupMaskExpt = nopTrigEventData->eventGroupMaskExpt;
    tempEventData->instanceSelectExpt = nopTrigEventData->instanceSelectExpt;

    (*pEventInfoData)->pEventData = (void*)tempEventData;
    (*pEventInfoData)->signalTableType = nopTrigEventInfoData->signalTableType;

    //Store SMPC domainid
    pEventGroup->nopTrigSwCounterData->nopTrigDomainId = nopTrigDomainData->domainId;

    free(nopTrigEventInfoData);

    return status;
}

CUprofResult fermiPerfmonEventGroupAddEvent(CUeventGroup *pEventGroup,
                                            NvU32 eventID)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUdomainData *pDomainData = NULL;
    CUeventData *pEventData = NULL;
    CUeventInfo *tempEventInfo = NULL;
    CUdev *pDev = NULL;
    NvBool bAdded = NV_FALSE;
    NvU32 numDomains = 0;
    NvU32 i = 0, maxSignals = 0;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);
    if (pEventGroup->isEnabled) {
        // don't allow addition of events for enabled event group
        return CUPROF_ERROR_INVALID_OPERATION;
    }

    pDev = pEventGroup->pCtx->device;

    if(!pDev->state.pDomainInfo)
        return CUPROF_ERROR_UNKNOWN;

    numDomains = pDev->state.pDomainInfo->numDomains;

    if (pEventGroup->totalCounters == 0) {
        // first signal, search in all domains
        for (i = 0; i < numDomains; i++) {
            pDomainData = &pDev->state.pDomainInfo->pDomainTable[i];
            tempEventInfo = fermiLookupDomainSignalTable(pDomainData, eventID);
            if (tempEventInfo) {
                pEventData = (CUeventData*)tempEventInfo->pEventData;
                if (!pEventData) {
                    free(tempEventInfo);
                    return CUPROF_ERROR_INVALID_EVENT_ID;
                }
                break;
            }
        }
        if (pEventData != NULL && pDomainData->domainId != FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST) {
            status = fermiInitEventGroup(pEventGroup);
            if(CUPROF_SUCCESS != status) {
                CU_DEBUG_PRINT(("fermiInitEventGroup Failed\n"));
                free(tempEventInfo);
                return status;
            }
        }
        else if (pEventData == NULL) {
            return CUPROF_ERROR_INVALID_EVENT_ID;
        }
    }
    else {
        tempEventInfo = fermiLookupDomainSignalTable(pEventGroup->domain, eventID);
        if (tempEventInfo) {
            pEventData = (CUeventData*)tempEventInfo->pEventData;
            if (!pEventData) {
                free(tempEventInfo);
                return CUPROF_ERROR_INVALID_EVENT_ID;
            }
            pDomainData = pEventGroup->domain;
        }
        else {
            for (i = 0; i < numDomains; i++) {
                pDomainData = &pDev->state.pDomainInfo->pDomainTable[i];
                tempEventInfo = fermiLookupDomainSignalTable(pDomainData, eventID);
                if (tempEventInfo) {
                    free(tempEventInfo);
                    return CUPROF_ERROR_NOT_COMPATIBLE;
                }
            }

            return CUPROF_ERROR_INVALID_EVENT_ID;
        }
    }

    if((pDomainData->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW) ||
        (pDomainData->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW)) {
        if(pEventGroup->nopTrigSwCounterData == NULL){
            pEventGroup->nopTrigSwCounterData = (CUnopTrigSwCounter *)calloc(1, sizeof(CUnopTrigSwCounter));
            if (pEventGroup->nopTrigSwCounterData == NULL) {
                CU_DEBUG_PRINT(("Failed to allocate memory to event group\n"));
                free(tempEventInfo);
                return CUPROF_ERROR_OUT_OF_MEMORY;
            }
        }
        if(pEventGroup->totalCounters == 0) {
            memset(pEventGroup->nopTrigSwCounterData, 0, sizeof(CUnopTrigSwCounter));
        }
        status = fermiCreateSignalTableEntry(pEventGroup, &tempEventInfo, eventID);
        if (status != CUPROF_SUCCESS) {
            if(status != CUPROF_ERROR_MAX_LIMIT_REACHED) {
                CU_ERROR_PRINT(("Failed to create signal table entry\n"));
            }
            free(tempEventInfo);
            return status;
        }
        pEventData = (CUeventData*)tempEventInfo->pEventData;
        if (pEventData == NULL) {
            free(pEventData);
            free(tempEventInfo);
            return CUPROF_ERROR_INVALID_EVENT_ID;
        }
    }

    // return if event is not found or it's a internal only event
    if (pEventData == NULL) {
        free(tempEventInfo);
        return CUPROF_ERROR_INVALID_EVENT_ID;
    }
    else if ((SIG_TYPE_IS_INTERNAL_EXPOSED(pEventData->signalId)
             && (pDomainData->exposedEvents == pDomainData->maxExternalEvents)) || SIG_TYPE_IS_INTERNAL(pEventData->signalId)) {
        free(tempEventInfo);
        return CUPROF_ERROR_INVALID_EVENT_ID;
    }

    status = fermiPerfmonTryAddingCounterNew(pEventGroup,
            pDomainData,
            pEventData,
            &bAdded,&maxSignals);
    if (status != CUPROF_SUCCESS) {
            CU_ERROR_PRINT(("Failed to add new counter\n"));
            free(tempEventInfo);
            return status;
    }
    CU_ASSERT(bAdded);

    if (pEventGroup->totalCounters == 0) {
        pEventGroup->domainId = pDomainData->domainId;
        pEventGroup->domain   = pDomainData;

        fermiPerfmonGetInstanceValues(pDev, pEventGroup->domain,
                &pEventGroup->instanceCountAvail, &pEventGroup->instanceCountTotal);

        if(pEventGroup->values != NULL)
        {
            free(pEventGroup->values);
            pEventGroup->values = NULL;
        }

        if(pEventGroup->values == NULL) {
            pEventGroup->values = (NvU64*)malloc(sizeof(NvU64) * maxSignals * pEventGroup->instanceCountAvail);
            if (pEventGroup->values == NULL) {
                CU_DEBUG_PRINT(("Failed to allocate memory to event group values\n"));
                free(tempEventInfo);
                return CUPROF_ERROR_OUT_OF_MEMORY;
            }
        }
        cuosMemset(pEventGroup->values, 0, sizeof(NvU64) * maxSignals * pEventGroup->instanceCountAvail);
    }

    if (pEventGroup->pEventInfoList == NULL) {
        // event list hasn't been init yet, do it now
        status = (CUprofResult)listInit(&pEventGroup->pEventInfoList, NULL, NULL, NULL, eventIdCompareData);
        if (status != CUPROF_SUCCESS) {
            CU_ERROR_PRINT(("Failed to init linked list\n"));
            free(tempEventInfo);
            return status;
        }
    }
    // add event to the list
    listAddToTail(pEventGroup->pEventInfoList, tempEventInfo);
    pEventGroup->totalCounters++;
    return status;
}

CUprofResult fermiPerfmonEventGroupRemoveEvent(CUeventGroup *pEventGroup, NvU32 eventID) {
    CUprofResult status = CUPROF_SUCCESS;
    CUeventInfo *currEvent = NULL;
    void *eventBase = NULL;
    NvBool bAdded = NV_FALSE;
    void *data = NULL;
    NvU32 i = 0, remainingCounters = 0, maxsignals = 0;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if (pEventGroup->totalCounters == 0) {
        return CUPROF_SUCCESS;
    }

    if (pEventGroup->isEnabled) {
        // don't allow removal of events for enabled event group
        return CUPROF_ERROR_INVALID_OPERATION;
    }

    //TBD modify this function to simplify removing SM event counter
    // remove from list
    data = listDataRemFrom(pEventGroup->pEventInfoList, &eventID);
    if (data != NULL) {
        // Do memory cleanup as eventInfoData is a pointer to structure storing the event data and signal type info
        free(data);
        remainingCounters = pEventGroup->totalCounters - 1;
        pEventGroup->totalCounters = 0;

        //Destroy the earlier parsed info and recreate the structure.
        status = fermiDestroyEventGroup(pEventGroup);
        if(remainingCounters)
        {
            if (pEventGroup->domainId != FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST) {
                status = fermiInitEventGroup(pEventGroup);
                if(status != CUPROF_SUCCESS)
                    return status;
            }

            //Add remaining counters back to build the parsed info
            currEvent = (CUeventInfo*)listGetNext(pEventGroup->pEventInfoList, &eventBase);
            for (i = 0; (i < remainingCounters) && currEvent; i++, currEvent = (CUeventInfo*)listGetNext(NULL, &eventBase)) {
                status = fermiPerfmonTryAddingCounterNew(pEventGroup,
                    pEventGroup->domain,
                    (CUeventData*)(currEvent->pEventData),
                    &bAdded, &maxsignals);

                if (status != CUPROF_SUCCESS) {
                    CU_ERROR_PRINT(("Failed to add new counter\n"));
                    return status;
                }

                if (bAdded == NV_FALSE) {
                    //This is unlikely to happen. earlier we had the same counters residing in one group
                    CU_ASSERT(0);
                    CU_DEBUG_PRINT(("Event %d can not be added to current event group\n", ((CUeventData*)(currEvent->pEventData))->signalId));
                    return CUPROF_ERROR_UNKNOWN;
                }
                pEventGroup->totalCounters++;
            }
        }
        else {
            //Destroy the event list if the removed event was the last one.
            //TBD check if Tesla needs this.
            status = (CUprofResult)listDestroy(pEventGroup->pEventInfoList);
            if (status != CUPROF_SUCCESS) {
                return status;
            }
            pEventGroup->pEventInfoList = NULL;
        }
    }
    else {
        return CUPROF_ERROR_INVALID_EVENT_ID;
    }

    return status;
}

CUprofResult fermiPerfmonEventGroupRemoveAllEvents(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 i = 0;
    void *data = NULL;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if (pEventGroup->totalCounters == 0) {
        //No event is added
        return CUPROF_SUCCESS;
    }

    if (pEventGroup->isEnabled) {
        // don't allow removal of events for enabled event group
        return CUPROF_ERROR_INVALID_OPERATION;
    }

    for (i = 0; i < pEventGroup->totalCounters; i++) {
        status = (CUprofResult)listGenericRemNodeFromHead(pEventGroup->pEventInfoList, &data);
        if (status == CUPROF_SUCCESS) {
            free(data);
        }
        else {
            return CUPROF_ERROR_UNKNOWN;
        }
    }
    CU_ASSERT(listLen(pEventGroup->pEventInfoList) == 0);
    // destroy the event list
    status = (CUprofResult)listDestroy(pEventGroup->pEventInfoList);
    if (status != CUPROF_SUCCESS) {
        return status;
    }
    pEventGroup->pEventInfoList = NULL;

    status = fermiDestroyEventGroup(pEventGroup);

    pEventGroup->totalCounters = 0;
    return status;
}

// function to enable PM module for units
static CUprofResult setPMEnableReg(const CUeventGroup *pEventGroup, NvBool bEnable)
{
    //Function to be changed for new version
    CUresult status = CUDA_SUCCESS;
    NvU32 offset[8], value[8], startBit = 0, endBit = 0, cntr = 0;
    NvU32 count = 0, tempChipIdx = 0, totalTpcCount = 0, pmUnitIdx = 0;
    NvU32 chipIdx = 0, i = 0, j = 0, numL2Slices = 0;
    PMEnableRegInfo *pPMEnableRegInfo = NULL;
    PMEnableRegInfo *pPMEnableRegInfo1 = NULL;
    PerfUnitTable   *pTempPerfUnitTable = NULL;
    CUparsedClk *pParsedClk = NULL;
    PerfSignalTableNew *pSignal = NULL;

    CU_TRACE_FUNCTION();

    pParsedClk = pEventGroup->arch.fermiEventGroup->pParsedClk;

    CU_ASSERT(pParsedClk);

    // Use PRI registers to get the number of LTS per LTC:
    if(bEnable && pEventGroup->arch.fermiEventGroup->chipletType == PM_CHIPLET_TYPE_FBP) {
        offset[0] = NV_PLTCG_LTC0_LTS0_CBC_PARAM;
        status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, 1, offset, value, 0);
        if (status != CUDA_SUCCESS) {
            return CUPROF_ERROR_HARDWARE;
        }
        numL2Slices = GETFIELD32(value[0],NV_PLTCG_LTC0_LTS0_CBC_PARAM_SLICES_PER_FBP);
    }
    for (chipIdx = 0; chipIdx < pEventGroup->arch.fermiEventGroup->maxChiplets; chipIdx++) {
        if(pEventGroup->arch.fermiEventGroup->pmUnitMask & (1<<chipIdx))
        {
            for(cntr=0; cntr<pEventGroup->totalCounters; cntr++)
            {
                pSignal = pParsedClk->sigtable[cntr];
                pmUnitIdx = 0;
                // PM_ENABLE bit setting in not required for elapsed_cycles_sm counter
                if(pSignal->signalId == FERMI_ELAPSED_CYCLES_SM) {
                    continue;
                }
                //Search the unit table to get the unit.
                //TBD check if we can shift the unit table to domain table
                //TBD check we can directly store the pmunittable pointer to save the following search
                while (pEventGroup->pCtx->device->state.pPerfUnitTable[pmUnitIdx].pmUnitId != PM_UNIT_MAX) {
                    if (pEventGroup->pCtx->device->state.pPerfUnitTable[pmUnitIdx].pmUnitId == pSignal->pmUnitId) {
                        break;
                    }
                    pmUnitIdx++;
                }
                CU_ASSERT(pEventGroup->pCtx->device->state.pPerfUnitTable[pmUnitIdx].pmUnitId != PM_UNIT_MAX);

                pTempPerfUnitTable = &pEventGroup->pCtx->device->state.pPerfUnitTable[pmUnitIdx];
                pPMEnableRegInfo = &pTempPerfUnitTable->pmEnableRegInfo;

                count = 0;
                totalTpcCount = 0;
                switch (pEventGroup->arch.fermiEventGroup->chipletType) {
                    // Bug 646910 : only one instance can be selected at a time
                    // The selected instance gets the "value" field value assigned while all others instances are zeroed out
                    // TODO: this change is not complete though, refer pm_programming_guide.txt file to derive
                    // the instance type (like INVALID, NONE, TPC, WXBAR_CQ_DAISY, MXBAR_CQ_DAISY etc) and no. of instances

                case PM_CHIPLET_TYPE_GPC:
                    // count total tpcs within the gpc
                    //TBD remove hack (assumed chipidx pointing to a gpc here. This will not be required if we had 1 perfmon/tpc)
                    if((((pSignal->pmUnitId == PM_UNIT_TEX) || (pSignal->pmUnitId == PM_UNIT_TEX_D)) &&
                        ((pEventGroup->pCtx->device->state.chip == NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF100) ||
                        (pEventGroup->pCtx->device->state.chip == NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF100B))) ||
                        ((pSignal->pmUnitId != PM_UNIT_TEX) && (pSignal->pmUnitId != PM_UNIT_TEX_D)))
                    {

                        for(tempChipIdx = 0; tempChipIdx < pEventGroup->arch.fermiEventGroup->gpcCount; tempChipIdx++) {

                            count = pEventGroup->arch.fermiEventGroup->tpcPerGpcCount[tempChipIdx];
                            if (!((chipIdx >= totalTpcCount) && (chipIdx < (totalTpcCount + count)))) {
                                totalTpcCount+=count;
                                continue;
                            }

                            for (i = 0; i < count; i++) {
                                offset[i] = NV_PRI_TPC_ADDR(tempChipIdx, i) + pPMEnableRegInfo->regOffset;
                            }
                            // read _PM registers
                            status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, count, offset, value, 0);
                            if (status != CUDA_SUCCESS) {
                                return CUPROF_ERROR_HARDWARE;
                            }
                            // set PM_ENABLE bit by ORing the read value for selected instance
                            // disable PM_ENABLE bit by ANDing the read value for all others instances
                            for (i = 0; i < count; i++) {
                                if(((totalTpcCount + i) == chipIdx) && bEnable){
                                    value[i] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                                }
                                else {
                                    value[i] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
                                }
                            }
                            break;
                        }
                    }
                    else {
                        pPMEnableRegInfo1 = &pTempPerfUnitTable->pmEnableRegInfo1;
                        for(tempChipIdx = 0; tempChipIdx < pEventGroup->arch.fermiEventGroup->gpcCount; tempChipIdx++) {

                            count = pEventGroup->arch.fermiEventGroup->tpcPerGpcCount[tempChipIdx];
                            if (!((chipIdx >= totalTpcCount) && (chipIdx < (totalTpcCount + count)))) {
                                totalTpcCount+=count;
                                continue;
                            }

                            for (i = 0, j = 0; i < count; i++) {
                                offset[j++] = NV_PRI_TPC_ADDR(tempChipIdx, i) + pPMEnableRegInfo->regOffset;
                                offset[j++] = NV_PRI_TPC_ADDR(tempChipIdx, i) + pPMEnableRegInfo1->regOffset;
                            }
                            // read _PM registers
                            status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, j, offset, value, 0);
                            if (status != CUDA_SUCCESS) {
                                return CUPROF_ERROR_HARDWARE;
                            }
                            // set PM_ENABLE bit by ORing the read value for selected instance
                            // disable PM_ENABLE bit by ANDing the read value for all others instances
                            for (i = 0, j = 0; i < count; i++) {
                                if(((totalTpcCount + i) == chipIdx) && bEnable) {
                                    value[j++] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                                    value[j++] |= (pPMEnableRegInfo1->value << pPMEnableRegInfo1->firstBit);
                                }
                                else {
                                    value[j++] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
                                    value[j++] &= ~(DRF_MASK(pPMEnableRegInfo1->lastBit : pPMEnableRegInfo1->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo1->lastBit : pPMEnableRegInfo1->firstBit)));
                                }
                            }
                            break;
                        }
                        count = j;
                    }
                    break;
                case PM_CHIPLET_TYPE_SYS:
                    // TODO: implement
                    count = 0;
                    break;
                case PM_CHIPLET_TYPE_FBP:

                    count = 0;
                    //TBD The changes done for GF108 can be removed as no chip in kepler hs 2 FBPA per FBP
                    // everything but fbpa2pm_ltc_fb_perf_muxed_bus/NV_PFB_FBPA_*_PM is floorswept in virtual address space
                    if((pSignal->pmUnitId == PM_UNIT_FB) || (pSignal->pmUnitId == PM_UNIT_FB1)) {
                        count = 1;
                        // everything but fbpa2pm_ltc_fb_perf_muxed_bus/NV_PFB_FBPA_*_PM is floorswept in virtual address space
                        //TBD add logic to enable one slice at a time for L2 signals for GF119
                        if((pEventGroup->pCtx->device->state.chip != (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF108))
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110
                            && (pEventGroup->pCtx->device->state.chip != (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF119))
                            && (pEventGroup->pCtx->device->state.chip != (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF117))
#endif
                          ) {
                            //Use broadcast register to enable PM for FBPA as unicast are giving wrong values
                            //Writing to boardcast register for each chiplet to avoid conditions, otherwise writing
                            //only once is sufficient
                            //This is not needed for GF108 as it has only 1 FB chiplet with 2 FBPA and address of
                            //both FBPAs are different.
                            offset[0] = NV_FBPA_PRI_BASE_BROADCAST + pPMEnableRegInfo->regOffset;
                        }
                        else {
                            offset[0] = pTempPerfUnitTable->priBaseAddress
                                + pTempPerfUnitTable->priChipletOffset * chipIdx
                                + pPMEnableRegInfo->regOffset;
                        }

                        // read _PM registers
                        status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, count, offset, value, 0);
                        if (status != CUDA_SUCCESS) {
                            return CUPROF_ERROR_HARDWARE;
                        }
                        // set PM_ENABLE bit by ORing the read value for selected instance
                        // disable PM_ENABLE bit by ANDing the read value for all others instances
                        if(bEnable)
                        {
                            value[0] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                        }
                        else
                        {
                            value[0] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
                        }
                    }
                    else {
                        if((pSignal->pmUnitId == PM_UNIT_LTC) || (pSignal->pmUnitId == PM_UNIT_LTC1) || (pSignal->pmUnitId == PM_UNIT_LTC5)) {
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110
                            if((pEventGroup->pCtx->device->state.chip == (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF119))
                                || (pEventGroup->pCtx->device->state.chip == (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF117))) {

                                pPMEnableRegInfo1 = &pTempPerfUnitTable->pmEnableRegInfo1;
                                for(count = 0; count < numL2Slices; count++) {
                                    offset[count] = pTempPerfUnitTable->priBaseAddress
                                        + pTempPerfUnitTable->priChipletOffset * chipIdx
                                        + pTempPerfUnitTable->priInstanceOffset * count
                                        + pPMEnableRegInfo->regOffset;
                                }
                                //set the PM enable bit for
                                offset[count++] = NV_PLTCG_BASE
                                    + pTempPerfUnitTable->priChipletOffset * chipIdx
                                    + pPMEnableRegInfo1->regOffset;

                                status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, count, offset, value, 0);
                                if (status != CUDA_SUCCESS) {
                                    return CUPROF_ERROR_HARDWARE;
                                }
                                for(count = 0; count < numL2Slices; count++) {
                                    //Enable only 1 LTS out of the 4 and disable remaining 3.
                                    //Check if a signal from subp0 gets combined with miss from subp1
                                    //TBD hardcode the value for now as GF119 has only one slice.
                                    if((pSignal->eventGroup1 == count) && bEnable){
                                        value[count] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                                        // assign group to GROUP bit/s by ORing into read value
                                        startBit = pTempPerfUnitTable->pmGroupSelRegInfo.firstBit;
                                        endBit   = startBit + pTempPerfUnitTable->pmGroupSelRegInfo.subFieldWidth - 1;

                                        // Set the group for experiment for a L2 slice.
                                        //Normally the group for a signal is set in setPMGroupReg function, but for GF119 and GF117, we
                                        //set the group here in the loop for L2 slices.
                                        //TBD we can collapse the setPMEnableReg and setPMGroupReg functions for all the PMs units.
                                        value[count] = DRF_REPLACE(value[count], pSignal->eventGroup, endBit:startBit);
                                        if(pSignal->isExpt) {
                                            value[count] &= ~pSignal->eventGroupMaskExpt;
                                            value[count] |= (pSignal->eventGroupExpt);
                                        }
                                    }
                                    else {
                                        value[count] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
                                        if(pSignal->isExpt) {
                                            value[count] &= ~pSignal->eventGroupMaskExpt;
                                        }
                                    }
                                }
                                //TBD remove hardcoded values everywhere
                                if(bEnable)
                                {
                                    value[count] |= (pPMEnableRegInfo1->value << pPMEnableRegInfo1->firstBit);
                                    // assign group to GROUP bit/s by ORing into read value
                                    startBit = pTempPerfUnitTable->pmGroupSelRegInfo1.firstBit;
                                    endBit   = startBit + pTempPerfUnitTable->pmGroupSelRegInfo1.subFieldWidth - 1;
                                    value[count] = DRF_REPLACE(value[count], pSignal->eventGroup1, endBit:startBit);
                                    if(pSignal->isExpt) {
                                        //For an experiment we need to set the slice number in each group from
                                        //which the signals are being profiled.
                                        value[count] &= ~(pSignal->eventGroupMaskExpt);
                                        value[count] |= pSignal->instanceSelectExpt;
                                    }
                                }
                                else
                                {
                                    value[count] &= ~(DRF_MASK(pPMEnableRegInfo1->lastBit : pPMEnableRegInfo1->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo1->lastBit : pPMEnableRegInfo1->firstBit)));
                                    if(pSignal->isExpt) {
                                        value[count] &= ~(pSignal->eventGroupMaskExpt);
                                    }
                                }

                                count++;

                            } else
#endif
                            {
                                count = 1;
                                offset[0] = pTempPerfUnitTable->priBaseAddress
                                    + pTempPerfUnitTable->priChipletOffset * chipIdx
                                    + pPMEnableRegInfo->regOffset;

                                // read _PM registers
                                status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, count, offset, value, 0);
                                if (status != CUDA_SUCCESS) {
                                    return CUPROF_ERROR_HARDWARE;
                                }
                                // set PM_ENABLE bit by ORing the read value for selected instance
                                // disable PM_ENABLE bit by ANDing the read value for all others instances
                                if(bEnable)
                                {
                                    value[0] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                                }
                                else
                                {
                                    value[0] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
                                }

                            }
                        }
                    }

                    break;
                default:
                    CU_ERROR_PRINT(("Not a valid chiplet type.\n"));
                    break;
                    }
                    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, count, offset, value, 0);
                    if (status != CUDA_SUCCESS) {
                        return CUPROF_ERROR_HARDWARE;
                    }
                }
        }
    }

    return CUPROF_SUCCESS;
}

static void resetPMTarget(const CUeventGroup *pEventGroup) {
    CUfermiEventGroup  *fermiEventGroup;
    fermiEventGroup = pEventGroup->arch.fermiEventGroup;

    //It is possible that after eventgroup disable, the user can remove all ids
    //and add id from different domain. So the pmmaddress/priaddress need to be
    //recalculated for that chiplet.
    //Free pmm/pri address pointers otherwise they cause memory leak
    if (fermiEventGroup->pmmAddress) {
        free(fermiEventGroup->pmmAddress);
        fermiEventGroup->pmmAddress = NULL;
    }
    if (fermiEventGroup->priAddress) {
        free(fermiEventGroup->priAddress);
        fermiEventGroup->priAddress = NULL;
    }
}

static CUprofResult setupPMTarget(const CUeventGroup *pEventGroup)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 gpcId = 0, tpcId = 0, gpcCount = 0, tpcCount = 0, maxtpc = 0, totalTPCCount = 0;
    NvU32 i = 0, SMIdx = 0;
    NvU32 fbpCount = 0, tpcSelected = 0;
    CUparsedClk  *pParsedClk = NULL;
    CUSMCtrInfo  *pSM = NULL;
    CUfermiEventGroup  *fermiEventGroup;

    //For PM signals
    fermiEventGroup = pEventGroup->arch.fermiEventGroup;
    pParsedClk = pEventGroup->arch.fermiEventGroup->pParsedClk;
    pSM = pEventGroup->arch.fermiEventGroup->pSM;

    CU_TRACE_FUNCTION();

    switch(pEventGroup->arch.fermiEventGroup->chipletType)
    {
        //Allocate structure for chiplets that store the base address for the PRI registers for each chiplet
    case PM_CHIPLET_TYPE_SYS:
        fermiEventGroup->pmmAddress = (NvU32 *) malloc(sizeof(NvU32) * 1);
        fermiEventGroup->priAddress = (NvU32 *) malloc(sizeof(NvU32) * 1);
        if (!(fermiEventGroup->pmmAddress && fermiEventGroup->priAddress))
        {
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto EXIT;
        }

        fermiEventGroup->maxChiplets = 1;
        fermiEventGroup->priAddress[0] = 0;
        fermiEventGroup->pmmAddress[0] = NV_PERF_PMMSYS_BASE;
        fermiEventGroup->pmUnitMask = 1;

        break;

    case PM_CHIPLET_TYPE_GPC:
        //TBD Shift the gpc processing related part to a function.

        // handle floor-sweeping case
        // On fermi the floorsweeping has all been abstracted to SW so that we dont worry about what units are swept,
        // we really just care about how many of each unit we have, and access them sequentially from [0-max]
        // the HW deals with mapping them internally
        gpcCount = pEventGroup->pCtx->device->state.limits.numGpcs;   // no. of available GPCs after floorsweep

        CU_ASSERT(gpcCount);

        fermiEventGroup->gpcCount = gpcCount;
        fermiEventGroup->tpcPerGpcCount = pEventGroup->pCtx->device->state.limits.numTpcsPerGpc;

        // Enable NV_SM_PM_CTRL for selected GPC/TPC and disable for others
        // disable NV_SM_PM_CTRL in other GPCs
        for (gpcId = 0; gpcId < gpcCount; gpcId++) {

            // get no of available TPCs in the GPC
            tpcCount = fermiEventGroup->tpcPerGpcCount[gpcId];
            if(pEventGroup->pCtx->device->state.workDistributionMode == CU_WORK_DISTRIBUTION_DYNAMIC)
            {
                //Select the 1st GPC that has highest no of SMs becuase in dynamic scheduling that's the first one chosen for scheduling
                if (maxtpc < tpcCount)
                {
                    maxtpc = tpcCount;
                    //select first tpc (tpc0) of selected gpc
                    tpcSelected = totalTPCCount;
                }
            }

            totalTPCCount += tpcCount;

#ifdef DEBUG
            CU_DEBUG_PRINT(("GPC %d : num of active TPCs = %d\n", gpcId, tpcCount));
#endif
        }

        fermiEventGroup->pmmAddress = (NvU32 *) malloc(sizeof(NvU32) * totalTPCCount);
        fermiEventGroup->priAddress = (NvU32 *) malloc(sizeof(NvU32) * totalTPCCount);
        if (!(fermiEventGroup->pmmAddress && fermiEventGroup->priAddress))
        {
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto EXIT;
        }

        fermiEventGroup->maxChiplets = totalTPCCount;
        //pmUnitMask for gpc is set for the selected gpc and tpc 0 will be profiled from the seleced gpc by default
        //this hack will be gone if we have 1 perfmon per tpc in kepler


        if(CUPROF_EVENT_COLLECTION_METHOD_HWPM == pEventGroup->domain->eventCollectionMethod) //HWPM
        {
            SMIdx = 0;
            //Assign the pri and pmm base addreses so that they need not be calcualted again and again
            for (gpcId = 0; gpcId < gpcCount; gpcId++) {
                //Profile only first tpc from a GPC.
                fermiEventGroup->pmUnitMask |= (1 << SMIdx);
                for (tpcId = 0; tpcId < pEventGroup->arch.fermiEventGroup->tpcPerGpcCount[gpcId]; tpcId++) {
                    //Assumed that TPC 0 of GPC will be profiled everytime
                    fermiEventGroup->priAddress[SMIdx] = NV_PRI_TPC_ADDR(gpcId, tpcId);
                    fermiEventGroup->pmmAddress[SMIdx] = NV_PERF_PMMGPC_BASE + gpcId * NV_PERF_PMMGPC_CHIPLET_OFFSET;
                    SMIdx++;
                }
            }
        }
        else //SMPERF
        {
            SMIdx = 0;
            //Assign the pri and pmm base addreses so that they need not be calcualted again and again
            for (gpcId = 0; gpcId < gpcCount; gpcId++) {
                for (tpcId = 0; tpcId < pEventGroup->arch.fermiEventGroup->tpcPerGpcCount[gpcId]; tpcId++) {
                    //Profile all tpcs from a GPC for SM counters.
                    fermiEventGroup->pmUnitMask |= (1 << SMIdx);
                    fermiEventGroup->priAddress[SMIdx] = NV_PRI_TPC_ADDR(gpcId, tpcId);
                    fermiEventGroup->pmmAddress[SMIdx] = NV_PERF_PMMGPC_BASE + gpcId * NV_PERF_PMMGPC_CHIPLET_OFFSET;
                    SMIdx++;
                }
            }

        }

        if(!pEventGroup->profileAll) {
            //If profileall flag is not set, then profile only the first tpc selected by scheduler.
            fermiEventGroup->pmUnitMask = 1 << tpcSelected;
        }

        break;

    case PM_CHIPLET_TYPE_FBP:
        fbpCount = pEventGroup->pCtx->device->state.limits.numFbps;
        CU_ASSERT(fbpCount);

        fermiEventGroup->pmmAddress = (NvU32 *) malloc(sizeof(NvU32) * fbpCount);
        fermiEventGroup->priAddress = (NvU32 *) malloc(sizeof(NvU32) * fbpCount);
        if (!(fermiEventGroup->pmmAddress && fermiEventGroup->priAddress))
        {
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto EXIT;
        }

        fermiEventGroup->maxChiplets = fbpCount;
        for (i = 0; i < fbpCount; i++) {
            //Since PRI base/offset for FBPA and LTC is different, though they belong to same chiplet, the PRI base/offset are stored in unit table.
            //fermiEventGroup->pmmAddress[i] = (NV_PLTCG_BASE+i*NV_PLTCG_STRIDE);
            //fermiEventGroup->priAddress[i] = (NV_FBPA_PRI_BASE+i*NV_FBPA_PRI_STRIDE);
            fermiEventGroup->pmmAddress[i] = (NV_PERF_PMMFBP_BASE+i*NV_PERF_PMMFBP_CHIPLET_OFFSET);
            fermiEventGroup->pmUnitMask |= 1 << i;
        }

        if(!pEventGroup->profileAll) {
            //If profileall flag is not set, then profile only the first fbp.
            fermiEventGroup->pmUnitMask = 1;
        }
        break;

    default:
        CU_ASSERT(0);
        break;
    }

    //TBD Shift values to fermieventgroup structure to remove the following switch
    switch(pEventGroup->domain->eventCollectionMethod)
    {
    case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
        if ((pParsedClk) && (pEventGroup->totalCounters)) {
            if(pParsedClk->values == NULL) {
                pParsedClk->values = (NvU32 *) malloc(fermiEventGroup->maxChiplets     * //no of chiplets
                    (CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS + CU_PROF_ELAPSED_CLOCK_SLOT) * //no of counters to be profiled in this domain
                    sizeof(NvU32));
                if(pParsedClk->values == NULL)
                {
                    status = CUPROF_ERROR_OUT_OF_MEMORY;
                    goto EXIT;
                }
            }
            cuosMemset(pParsedClk->values, 0, sizeof(NvU32) * fermiEventGroup->maxChiplets * pEventGroup->totalCounters);
        }
        break;

    case CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
        if ((pSM) && (pSM->SMCountersAdded)) {
            if(pSM->values == NULL) {
                pSM->values = (NvU32 *) malloc(pEventGroup->instanceCountAvail     * //no of chiplets
                    (CU_PROF_PM_SM_MAX_COUNTERS)       * //no of counters to be profiled in this domain
                    sizeof(NvU32));
                if(pSM->values == NULL)
                {
                    status = CUPROF_ERROR_OUT_OF_MEMORY;
                    goto EXIT;
                }
            }
            cuosMemset(pSM->values, 0, sizeof(NvU32) * pEventGroup->instanceCountAvail * pSM->SMCountersAdded);
        }
        break;

    default:
        //TBD Add s/w counters here
        break;
    }


    return status;
EXIT:
    free(pParsedClk->values);
    free(fermiEventGroup->pmmAddress);
    free(fermiEventGroup->priAddress);
    return status;
}
// function to configure event-groups
static CUprofResult setPMGroupReg(const CUeventGroup *pEventGroup)
{
    //Function to be changed for new version
    CUresult status = CUDA_SUCCESS;
    NvU32 offset[2], value[2];
    NvU32 chipIdx = 0;
    NvU32 startBit = 0, endBit = 0, i = 0, pmUnitIdx = 0;
    PerfSignalTableNew *pSignal = NULL;
    PMGroupSelRegInfo *pPMGroupSelRegInfo = NULL;
    PMGroupSelRegInfo *pPMGroupSelRegInfo1 = NULL;
    CUfermiEventGroup *fermiEventGroup;
    PerfUnitTable   *pTempPerfUnitTable = NULL;
    CUparsedClk     *pTempParsedClk = NULL;
    CU_TRACE_FUNCTION();

    fermiEventGroup = pEventGroup->arch.fermiEventGroup;

    for (chipIdx = 0; chipIdx < pEventGroup->arch.fermiEventGroup->maxChiplets; chipIdx++) {
        if(fermiEventGroup->pmUnitMask & (1<<chipIdx)) {
            pTempParsedClk = fermiEventGroup->pParsedClk;
            for(i=0; i<pEventGroup->totalCounters; i++)
            {
                pSignal = pTempParsedClk->sigtable[i];
                pmUnitIdx = 0;
                // elapsed_cycles_sm do not require any eventGroup setting:
                if(pSignal->signalId == FERMI_ELAPSED_CYCLES_SM) {
                    continue;
                }
                //Search the unit table to get the unit.
                //TBD check if we can shift the unit table to domain table
                while (pEventGroup->pCtx->device->state.pPerfUnitTable[pmUnitIdx].pmUnitId != PM_UNIT_MAX) {
                    if (pEventGroup->pCtx->device->state.pPerfUnitTable[pmUnitIdx].pmUnitId == pSignal->pmUnitId) {
                        break;
                    }
                    pmUnitIdx++;
                }
                CU_ASSERT(pEventGroup->pCtx->device->state.pPerfUnitTable[pmUnitIdx].pmUnitId != PM_UNIT_MAX);

                pTempPerfUnitTable = &pEventGroup->pCtx->device->state.pPerfUnitTable[pmUnitIdx];
                pPMGroupSelRegInfo = &pTempPerfUnitTable->pmGroupSelRegInfo;

                //The earlier design was assuming that there will be only 1 PRI base address for 1 instance of a chiplettype
                //FBP has different base addresses for LTC and FBP, to solve this currently added the pri base address to unit table.
                //This doesn't work directly for GPC as the TPC pri base address are based on gpcid and tpcid both.
                //TBD: Adding hack here, to remove this hack, we will have to add an extra loop for instance in each function.
                if(PM_CHIPLET_TYPE_FBP == pEventGroup->arch.fermiEventGroup->chipletType) {
                    if((pSignal->pmUnitId == PM_UNIT_FB) &&
                         (pEventGroup->pCtx->device->state.chip != (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF108))
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110
                         &&
                         (pEventGroup->pCtx->device->state.chip != (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF119))
                         &&
                         (pEventGroup->pCtx->device->state.chip != (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF117))
#endif
                      ) {
                        //Use broadcast register to enable PM for FBPA as unicast are giving wrong values
                        //Writing to boardcast register for each chiplet to avoid conditions, otherwise writing
                        //only once is sufficient
                        //This is not needed for GF108 as it has only 1 FB chiplet with 2 FBPA and address of
                        //both FBPAs are different.
                        offset[0] = NV_FBPA_PRI_BASE_BROADCAST + pPMGroupSelRegInfo->regOffset;
                    }
                    else {
                        offset[0] = pTempPerfUnitTable->priBaseAddress
                            + pTempPerfUnitTable->priChipletOffset * chipIdx
                            + pPMGroupSelRegInfo->regOffset;
                    }
                }
                else {
                    offset[0] = fermiEventGroup->priAddress[chipIdx] + pPMGroupSelRegInfo->regOffset;
                }

                // Again a hack. For GF10x tex, we have to select the TRM
                // The NV_PTPC_PRI_TEX_TRM_PM register controls PM signal muxing for TRM.
                // TRM_PM_PM_SEL defines the selection among trm internal pm, tex0_m and tex1_m.
                // So we have a double layer of group selection.
                if((((pSignal->pmUnitId == PM_UNIT_TEX) || (pSignal->pmUnitId == PM_UNIT_TEX_D)) &&
                    ((pEventGroup->pCtx->device->state.chip == NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF100) ||
                     (pEventGroup->pCtx->device->state.chip == NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF100B))) ||
                     ((pSignal->pmUnitId != PM_UNIT_TEX) && (pSignal->pmUnitId != PM_UNIT_TEX_D)))
                {
                    // read the register
                    status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, 1, offset, value, 0);
                    if (status != CUDA_SUCCESS) {
                        return CUPROF_ERROR_HARDWARE;
                    }

                    if(pSignal->isExpt) {
                        // For some experiments we may required to set more than 1 group for same PM register,
                        // hence used eventgroupmask and eventgroupexpt fields.
                        // While defining the expt, take care of setting these properly
                        value[0] &= ~pSignal->eventGroupMaskExpt;
                        value[0] |= (pSignal->eventGroupExpt & pSignal->eventGroupMaskExpt);
                    }
                    else {
                        // assign group to GROUP bit/s by ORing into read value
                        startBit = pPMGroupSelRegInfo->firstBit;
                        endBit   = startBit + pPMGroupSelRegInfo->subFieldWidth - 1;
                        value[0] = DRF_REPLACE(value[0], pSignal->eventGroup, endBit:startBit);
                    }

                    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, 1, offset, value, 0);
                    if (status != CUDA_SUCCESS) {
                        return CUPROF_ERROR_HARDWARE;
                    }
                }
                else {
                    pPMGroupSelRegInfo1 = &pTempPerfUnitTable->pmGroupSelRegInfo1;
                    offset[1] = fermiEventGroup->priAddress[chipIdx] + pPMGroupSelRegInfo1->regOffset;

                    // read the register
                    status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, 2, offset, value, 0);
                    if (status != CUDA_SUCCESS) {
                        return CUPROF_ERROR_HARDWARE;
                    }

                    // assign group to GROUP bit/s by ORing into read value
                    startBit = pPMGroupSelRegInfo->firstBit;
                    endBit   = startBit + pPMGroupSelRegInfo->subFieldWidth - 1;
                    value[0] = DRF_REPLACE(value[0], pSignal->eventGroup, endBit:startBit);

                    startBit = pPMGroupSelRegInfo1->firstBit;
                    endBit   = startBit + pPMGroupSelRegInfo1->subFieldWidth - 1;
                    value[1] = DRF_REPLACE(value[1], pSignal->eventGroup1, endBit:startBit);

                    //TBD check how to handle expt here
                    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, 2, offset, value, 0);
                    if (status != CUDA_SUCCESS) {
                        return CUPROF_ERROR_HARDWARE;
                    }
                }
            }
        }
    }
    return CUPROF_SUCCESS;
}

static CUprofResult setupEventSpec(const CUeventGroup *pEventGroup) {
    NvU32 chipIdx = 0, i = 0, j = 0;
    int eventMask = 0;
    CUparsedClk *pTempParsedClk;
    CUfermiEventGroup  *fermiEventGroup;
    CUeventInfo *currEventInfo = NULL;
    void *eventBase = NULL;

    CU_TRACE_FUNCTION();

    fermiEventGroup = pEventGroup->arch.fermiEventGroup;

    // select the right event specification for each counter
    for (chipIdx = 0; chipIdx < PM_MAX_CHIPLET_TYPES; chipIdx++) {
        if (fermiEventGroup->pParsedClk) {
            pTempParsedClk = fermiEventGroup->pParsedClk;
            eventMask = 0;
            if (pTempParsedClk->bParsedMBWS == NV_TRUE)
            {
                pTempParsedClk->eventspec[pTempParsedClk->indexMBWS] = NV_PMM_TRIG1 | NV_PMM_EVENT;
                eventMask = (NV_PMM_TRIG1 | NV_PMM_EVENT);
            }
            currEventInfo = (CUeventInfo*)listGetNext(pEventGroup->pEventInfoList, &eventBase);
            for(i=0; i<pEventGroup->totalCounters && currEventInfo; i++, currEventInfo = (CUeventInfo*)listGetNext(NULL, &eventBase))
            {
                j = 0;

                if(((CUeventDataHwpm*)currEventInfo->pEventData)->signalId == FERMI_ELAPSED_CYCLES_SM) {
                    pTempParsedClk->eventspec[i] = NV_ELAPSED_CLOCKS;
                    continue;
                }
                if((i == pTempParsedClk->indexMBWS) && (pTempParsedClk->bParsedMBWS == NV_TRUE)) continue;

                while((eventMask & (NV_PMM_TRIG0 << j))) j+=1;
                pTempParsedClk->eventspec[i] = (NV_PMM_TRIG0 << j);
                eventMask |= (NV_PMM_TRIG0 << j);
            }
        }
    }

    return CUPROF_SUCCESS;
}

static CUprofResult setupPMRegistersModeB(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *value = NULL, valueSignal[6] = {0};
    NvU32 count = 0, i = 0, j = 0, k = 0, size = 0;
    NvU32 busWidth = 0, func = 0x0, finalvalue = 0;
    PerfSignalTableNew *pSignal = NULL;
    NvU32 domainRegOffset = 0, chipIdx = 0;
    CUfermiEventGroup  *fermiEventGroup;

    CU_TRACE_FUNCTION();

    //For PM signals
    fermiEventGroup = pEventGroup->arch.fermiEventGroup;

    if(!fermiEventGroup)
        return CUPROF_ERROR_UNKNOWN; //TBD check if we can return this error.

    setupEventSpec(pEventGroup);

    if (pEventGroup->configChanged) {
        size = sizeof(NvU32) * 25 * fermiEventGroup->maxChiplets;                //TBD: Replace the magic no
        offset = (NvU32*)malloc(size);
        value  = (NvU32*)malloc(size);
        if (!offset || !value) {
            CU_ERROR_PRINT(("Failed to allocate memory for offset and value\n"));
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto EXIT;
        }

        status = setPMGroupReg(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            goto EXIT;
        }

        for (chipIdx = 0; chipIdx < fermiEventGroup->maxChiplets; chipIdx++) {
            if(fermiEventGroup->pmUnitMask & (1<<chipIdx))
            {
                if (fermiEventGroup->pParsedClk && pEventGroup->totalCounters) {
                    CUparsedClk *pTempParsedClk = fermiEventGroup->pParsedClk;
                    domainRegOffset = fermiEventGroup->pmmAddress[chipIdx] + fermiEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
                    offset[count]  = domainRegOffset + NV_PMM_CONTROL;
                    value[count++] = (NV_PMM_CONTROL_MODE_B                   << NV_PMM_CONTROL_MODE__SHIFT)    |
                        (NV_PMM_CONTROL_ADDTOCTR_INCR            << NV_PMM_CONTROL_ADDTOCTR__SHIFT)|
                        (NV_PMM_CONTROL_CTXSW_MODE_DISABLED      << NV_PMM_CONTROL_CTXSW_MODE__SHIFT);

                    offset[count]  = domainRegOffset + NV_PMM_TRIG0_SEL;
                    value[count++] = 0;
                    offset[count]  = domainRegOffset + NV_PMM_TRIG0_OP;
                    value[count++] = 0;
                    offset[count]  = domainRegOffset + NV_PMM_TRIG1_SEL;
                    value[count++] = 0;
                    offset[count]  = domainRegOffset + NV_PMM_TRIG1_OP;
                    value[count++] = 0;
                    offset[count]  = domainRegOffset + NV_PMM_EVENT_SEL;
                    value[count++] = 0;
                    offset[count]  = domainRegOffset + NV_PMM_EVENT_OP;
                    value[count++] = 0;
                    offset[count]  = domainRegOffset + NV_PMM_SAMPLE_SEL;
                    value[count++] = 0;
                    offset[count]  = domainRegOffset + NV_PMM_SAMPLE_OP;
                    value[count++] = 0;

                    for(i=0; i<pEventGroup->totalCounters; i++)
                    {
                        pSignal = pTempParsedClk->sigtable[i];

                        switch(pTempParsedClk->eventspec[i]) {
                        case (NV_PMM_TRIG1 | NV_PMM_EVENT):
                            j = 0;
                            for (k = 0; k < SIG_MAX_BUS_WIDTH; k++) {
                                if (pSignal->busSelBits[k]) {
                                    valueSignal[j] = (pSignal->watchBus & 0xff) + j;
                                    j++;
                                }
                            }

                            busWidth = countBusWidth(pSignal->busSelBits);
                            func = pSignal->function;

                            if (busWidth <= 4) {

                                for (k = 0; k < busWidth; k++) {
                                    finalvalue |= (valueSignal[k] << (8*k));
                                }
                                //0xef is the "false" signal.
                                //In cases where there is an inc_amount signal the trig1_sel gets programmed with the signals to inc on,
                                //but it requires 4 or six signals to be present.  The false signal is used as a place holder.
                                for (k = busWidth; k < 4; k++) {
                                    finalvalue |= (0xef) << (8*k);
                                }

                                // When ADDTOCTR is EVENT4, the 4 trigger1 signals are added to the event
                                // counter when the event strobe is active.
                                offset[count]  = domainRegOffset + NV_PMM_CONTROL;
                                value[count++] = (NV_PMM_CONTROL_MODE_B                   << NV_PMM_CONTROL_MODE__SHIFT)    |
                                    (NV_PMM_CONTROL_ADDTOCTR_EVENT4          << NV_PMM_CONTROL_ADDTOCTR__SHIFT)|
                                    (NV_PMM_CONTROL_CTXSW_MODE_DISABLED      << NV_PMM_CONTROL_CTXSW_MODE__SHIFT);


                                offset[count]  = domainRegOffset + NV_PMM_TRIG1_SEL;
                                value[count++] = finalvalue;
                                offset[count]  = domainRegOffset + NV_PMM_TRIG1_OP;
                                value[count]   = DRF_REPLACE(value[count], func, NV_PERF_PMMSYS_EVENT_OP_FUNC);
                                count++;

                                //An experiment has both event and trig1 specified in the signal table,so instead of using false signals, use actual events.
                                if(pSignal->isExpt) {
                                    offset[count]  = domainRegOffset + NV_PMM_EVENT_SEL;
                                    value[count++] = pSignal->watchBusExpt;
                                    offset[count]  = domainRegOffset + NV_PMM_EVENT_OP;
                                    value[count]   = DRF_REPLACE(value[count], pSignal->functionExpt, NV_PERF_PMMSYS_EVENT_OP_FUNC);
                                    count++;
                                }
                                else {
                                    offset[count]  = domainRegOffset + NV_PMM_EVENT_SEL;
                                    value[count++] = 0x000000ef;
                                    offset[count]  = domainRegOffset + NV_PMM_EVENT_OP;
                                    value[count]   = DRF_REPLACE(value[count], func, NV_PERF_PMMSYS_EVENT_OP_FUNC);
                                    count++;
                                }

                            }
                            else if (busWidth <= 6){
                                // When ADDTOCTR is EVENT6, the signals {EVENT[3:2],TRIG1[3:0]} are added
                                // to the event counter when the event strobe is active.
                                offset[count]  = domainRegOffset + NV_PMM_CONTROL;
                                value[count++] = (NV_PMM_CONTROL_MODE_B                   << NV_PMM_CONTROL_MODE__SHIFT)    |
                                    (NV_PMM_CONTROL_ADDTOCTR_EVENT6          << NV_PMM_CONTROL_ADDTOCTR__SHIFT)|
                                    (NV_PMM_CONTROL_CTXSW_MODE_DISABLED      << NV_PMM_CONTROL_CTXSW_MODE__SHIFT);

                                offset[count]  = domainRegOffset + NV_PMM_TRIG1_SEL;
                                value[count++] = (valueSignal[3] << 24) | (valueSignal[2] << 16) | (valueSignal[1] << 8) | (valueSignal[0] << 0);
                                offset[count]  = domainRegOffset + NV_PMM_TRIG1_OP;
                                value[count]   = DRF_REPLACE(value[count], func, NV_PERF_PMMSYS_TRIG1_OP_FUNC);
                                count++;

                                //An experiment has both event and trig1 specified in the signal table,so instead of using false signals, use actual events.
                                if(pSignal->isExpt) {
                                    offset[count]  = domainRegOffset + NV_PMM_EVENT_SEL;
                                    if (busWidth == 5)
                                        value[count++] = (0xef << 24) | (valueSignal[4] << 16) | pSignal->watchBusExpt;
                                    else
                                        value[count++] = (valueSignal[5] << 24) | (valueSignal[4] << 16) | pSignal->watchBusExpt;
                                    offset[count]  = domainRegOffset + NV_PMM_EVENT_OP;
                                    value[count]   = DRF_REPLACE(value[count], pSignal->functionExpt, NV_PERF_PMMSYS_EVENT_OP_FUNC);
                                    count++;
                                }
                                else {
                                    offset[count]  = domainRegOffset + NV_PMM_EVENT_SEL;
                                    if (busWidth == 5)
                                        value[count++] = (0xef << 24) | (valueSignal[4] << 16) | (0x00 << 8) | (0xef << 0);
                                    else
                                        value[count++] = (valueSignal[5] << 24) | (valueSignal[4] << 16) | (0x00 << 8) | (0xef << 0);
                                    offset[count]  = domainRegOffset + NV_PMM_EVENT_OP;
                                    value[count]   = DRF_REPLACE(value[count], func, NV_PERF_PMMSYS_EVENT_OP_FUNC);
                                    count++;
                                }

                            }
                            else {
                                CU_ERROR_PRINT(("Inavlid configuration of signal\n"));
                            }
                            break;
                        case NV_PMM_TRIG0:
                            offset[count]  = domainRegOffset + NV_PMM_TRIG0_SEL;
                            value[count++] = pSignal->watchBus;
                            offset[count]  = domainRegOffset + NV_PMM_TRIG0_OP;
                            value[count]   = DRF_REPLACE(value[count], pSignal->function, NV_PERF_PMMSYS_TRIG0_OP_FUNC);
                            count++;
                            break;
                        case NV_PMM_TRIG1:
                            offset[count]  = domainRegOffset + NV_PMM_TRIG1_SEL;
                            value[count++] = pSignal->watchBus;
                            offset[count]  = domainRegOffset + NV_PMM_TRIG1_OP;
                            value[count]   = DRF_REPLACE(value[count], pSignal->function, NV_PERF_PMMSYS_TRIG1_OP_FUNC);
                            count++;
                            break;
                        case NV_PMM_EVENT:
                            offset[count]  = domainRegOffset + NV_PMM_EVENT_SEL;
                            value[count++] = pSignal->watchBus;
                            offset[count]  = domainRegOffset + NV_PMM_EVENT_OP;
                            value[count]   = DRF_REPLACE(value[count], pSignal->function, NV_PERF_PMMSYS_EVENT_OP_FUNC);
                            count++;
                            break;
                        case NV_PMM_SAMPLE:
                            offset[count]  = domainRegOffset + NV_PMM_SAMPLE_SEL;
                            value[count++] = pSignal->watchBus;
                            offset[count]  = domainRegOffset + NV_PMM_SAMPLE_OP;
                            value[count]   = DRF_REPLACE(value[count], pSignal->function, NV_PERF_PMMSYS_SAMPLE_OP_FUNC);
                            count++;
                            break;
                        default:
                            CU_ERROR_PRINT(("Invalid event specification.\n"));
                            break;
                        }
                    }
                }
            }
        }
        CU_ASSERT(size >= count * sizeof(NvU32));
        // write signal configuration
        if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, count, offset, value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }
EXIT:
    free (offset);
    free (value);
    }
    return status;
}

static CUprofResult setupPMRegistersModeCommon(const CUeventGroup *pEventGroup, NvU32* perfmonTriggerRefCount) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL;
    NvU32 *value  = NULL;
    NvU32 count = 0;
    NvU32 domainRegOffset = 0, chipIdx = 0;
    NvU32 numDomains = 0;
    NvU32 size = 0;
    CUfermiEventGroup  *fermiEventGroup;

    CU_TRACE_FUNCTION();

    numDomains = PM_MAX_CHIPLET_TYPES * PM_MAX_CHIPLETS_PER_CHIPLET_TYPE * PM_MAX_DOMAIN_PER_CHIPLET;
    size  = sizeof(NvU32) * (numDomains + 16);
    offset = (NvU32*)malloc(size);
    value  = (NvU32*)malloc(size);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset/value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    fermiEventGroup = pEventGroup->arch.fermiEventGroup;
    CU_ASSERT(fermiEventGroup->pParsedClk);

    // Vivek Gupta suggests disable the safety clamp before you can get pass signals to the performance monitors on net35 and above.
    // This is to prevent us being affected by cdc/async bugs inside units that feed to the monitors
    for (chipIdx = 0; chipIdx < fermiEventGroup->maxChiplets; chipIdx++) {
        if(fermiEventGroup->pmUnitMask & (1<<chipIdx)) {
            if(pEventGroup->totalCounters) {
                domainRegOffset = fermiEventGroup->pmmAddress[chipIdx] + fermiEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
                offset[count]  = domainRegOffset + NV_PMM_CLAMP_CYA_CONTROL;
                value[count++] = NV_PMM_CLAMP_CYA_CONTROL_ENABLECYA_DISABLE;
            }
        }
    }

    if(!(*perfmonTriggerRefCount)) {
        offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_STATUS;
        value[count++] = 0x0;

        offset[count]  = NV_PERF_PMASYS_FBP_TRIGGER_STATUS;
        value[count++] = 0x0;

        offset[count]  = NV_PERF_PMASYS_SYS_TRIGGER_STATUS;
        value[count++] = 0x0;

        offset[count]  = NV_PERF_PMASYS_CONTROL;
        value[count++] = HWCONST(_PERF_PMASYS, CONTROL, STOPVPMCAPTURE, DOIT);

        offset[count]  = NV_PERF_PMASYS_CONTROL;
        value[count++] = 0x0;

        // setup PMA to push trigger to GPC chiplet
        offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_START_MASK;
        value[count++] = 0xffffffff;

        offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_STOP_MASK;
        value[count++] = 0xffffffff;

        offset[count]  = NV_PERF_PMASYS_SYS_TRIGGER_START_MASK;
        value[count++] = 0xffffffff;

        offset[count]  = NV_PERF_PMASYS_SYS_TRIGGER_STOP_MASK;
        value[count++] = 0xffffffff;

        offset[count]  = NV_PERF_PMASYS_FBP_TRIGGER_START_MASK;
        value[count++] = 0xffffffff;

        offset[count]  = NV_PERF_PMASYS_FBP_TRIGGER_STOP_MASK;
        value[count++] = 0xffffffff;
#if 1
        offset[count]  = NV_PERF_PMASYS_TRIGGER_GLOBAL;
        value[count++] = HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, ENABLE, ENABLED) |
            HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_GPC, ENABLE) |
            HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_FBP, ENABLE) |
            HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_SYS, ENABLE);
#else
        offset[count]  = NV_PERF_PMASYS_TRIGGER_GLOBAL;
        value[count++] = HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, MANUAL_START, PULSE) |
            HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, MANUAL_STOP, PULSE);
#endif
        offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_CONFIG_MIXED_MODE;
        value[count++] = 0xffffffff;
    }
    (*perfmonTriggerRefCount)++;

    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, count, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

EXIT:
    free(offset);
    free(value);

    return status;
}

// returns numeric value corresponding to signal name
static NvU32 resolveCoreSignalName(const CUctx *ctx, const NvU32 clkIdx, const NvU32 chipletType)
{
    const NvU32 (*signalNames)[PM_MAX_DOMAIN_PER_CHIPLET] = NULL;
    NvU32 numericId = ~0U;

    // For reference:
    // cut-down list containing pma_trigger signals only
    //The pma_trigger table for GF100 is valid for GF100B, GF104 and GF106 too.
    //The array is arranged in the order of domain ids, do not change the sequence
    // of the array, it will affect the counter values.
    //static const FermiSignalName2Numeric nvgf100_pma_trigger[] =
    //{
    //    {"gpc0_sigval_pma_trigger",                         237},
    //    {"host0_sigval_pma_trigger",                        77},
    //    {"hub0_sigval_pma_trigger",                         45},
    //    {"leg0_sigval_pma_trigger",                         77},
    //    {"leg1_sigval_pma_trigger",                         109},
    //    {"msd0_sigval_pma_trigger",                         77},
    //    {"pcie0_sigval_pma_trigger",                        45},
    //    {"sys0_sigval_pma_trigger",                         109},
    //    {"xbar0_sigval_pma_trigger",                        45},
    //    {"ltc0_sigval_pma_trigger",                         109},
    //    {"rop0_sigval_pma_trigger",                         77}
    //};
    static const NvU32 nvgf100_pma_trigger[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
    {77, 45, 77, 109, 77, 45, 109, 45},
    {237},
    {109, 77}
    };

    //static const FermiSignalName2Numeric nvgf108_pma_trigger[] =
    //{
    //    {"gpc0_sigval_pma_trigger",                         205},
    //    {"hub0_sigval_pma_trigger",                         45},
    //    {"leg0_sigval_pma_trigger",                         109},
    //    {"leg1_sigval_pma_trigger",                         109},
    //    {"msd0_sigval_pma_trigger",                         77},
    //    {"sys0_sigval_pma_trigger",                         109},
    //    {"xbar0_sigval_pma_trigger",                        45},
    //    {"ltc0_sigval_pma_trigger",                         77},
    //    {"rop0_sigval_pma_trigger",                         77},
    //};

    static const NvU32 nvgf108_pma_trigger[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        {45,109,109,77,109,45},
        {205},
        {77,77}
    };
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110
//    static const FermiSignalName2Numeric nvgf119_pma_trigger[] =
//    {
//        {"gpc0_sigval_pma_trigger",                         237},
//        {"hub0_sigval_pma_trigger",                         77},
//        {"leg0_sigval_pma_trigger",                         109},
//        {"leg1_sigval_pma_trigger",                         77},
//        {"msd0_sigval_pma_trigger",                         77},
//        {"sys0_sigval_pma_trigger",                         109},
//        {"xbar0_sigval_pma_trigger",                        45},
//        {"ltc0_sigval_pma_trigger",                         77},
//        {"rop0_sigval_pma_trigger",                         77},
//    };

    static const NvU32 nvgf119_pma_trigger[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        {77,109,77,77,109,45},
        {237},
        {77,77}
    };
#endif

    CU_TRACE_FUNCTION();

    if (chipletType >= PM_MAX_CHIPLET_TYPES || clkIdx >= PM_MAX_DOMAIN_PER_CHIPLET) {
        CU_ERROR_PRINT(("Invalid chiplet/clk values\n"));
        CU_ASSERT (0);
        return numericId;
    }

    switch(ctx->device->state.chip) {
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF100:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF104:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF106:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF100B:
#if defined(NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF104B) && defined(NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF106B)
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF104B:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF106B:
#endif
        signalNames = nvgf100_pma_trigger;
        break;

    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF108:
        signalNames = nvgf108_pma_trigger;
        break;
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF119:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF117:
        signalNames = nvgf119_pma_trigger;
        break;
#endif
        // TODO : enable other (arch + implementation) when defined
        //case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF110:
        //case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF112:
        //case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF117:
        //case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF118:
        // TODO: implement
        //signalNames = NULL;
        //numSignals = 0;
        //break;
    default:
        CU_ASSERT(0);
        break;
    }

    if (signalNames) {
        numericId = signalNames[chipletType][clkIdx];
    }
    else {
        CU_ASSERT(0); // Throw assert if signal names is NULL
    }

    return numericId;
}
static CUprofResult AssertEngineModeB(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *value = NULL;
    NvU32 j = 0, size = 0, pmaTriggerSignalIndex = ~0U;
    NvU32 domainRegOffset = 0, chipIdx = 0;
    CUparsedClk  *pParsedClk = NULL;
    CUfermiEventGroup  *fermiEventGroup;

    CU_TRACE_FUNCTION();

    //For PM signals
    pParsedClk = pEventGroup->arch.fermiEventGroup->pParsedClk;
    fermiEventGroup = pEventGroup->arch.fermiEventGroup;

    CU_ASSERT(pParsedClk);
    CU_ASSERT(fermiEventGroup);

    size = fermiEventGroup->maxChiplets * sizeof(NvU32);

    offset = (NvU32*)malloc(size);
    value = (NvU32*)malloc(size);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset/value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    // assert ENGINE
    // set register NV_PERF_PMM[chipletType]_ENGINE_SEL(domain) to NV_PERF_PMM[chipletType]_[domain]_SIGVAL_PMA_TRIGGER
    // for all instances of all chipletTypes
    // like for (GPC#0 + domain GPC0) - NV_PERF_PMMGPC_ENGINE_SEL(FERMI_CLK_DOMAIN_GPC0) = NV_PERF_PMMGPC_GPC0_SIGVAL_PMA_TRIGGER

    for (chipIdx = 0; chipIdx < fermiEventGroup->maxChiplets; chipIdx++) {
        if(fermiEventGroup->pmUnitMask & (1<<chipIdx))
        {
            domainRegOffset = fermiEventGroup->pmmAddress[chipIdx] + fermiEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
            offset[j]  = domainRegOffset + NV_PMM_ENGINE_SEL;
            // lookup the numeric value for the signal
            //TBD, check how we can put this in the domain table and get rid of resolveCoreSignalName function
            pmaTriggerSignalIndex = resolveCoreSignalName(pEventGroup->pCtx, fermiEventGroup->clkIdx, pEventGroup->domain->chipletType);
            CU_ASSERT(pmaTriggerSignalIndex != ~0U);
            value[j++] = pmaTriggerSignalIndex;
        }
    }

    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, j, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

EXIT:
    free (offset);
    free (value);

    return status;
}

static CUprofResult StartExptModeB(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;

    NvU32 *offset = NULL, *value = NULL;
    NvU32 j = 0, size = 0;
    NvU32 domainRegOffset = 0, chipIdx = 0;
    CUfermiEventGroup  *fermiEventGroup;

    CU_TRACE_FUNCTION();

    //For PM signals
    fermiEventGroup = pEventGroup->arch.fermiEventGroup;

    CU_ASSERT(fermiEventGroup);

    size = fermiEventGroup->maxChiplets * sizeof(NvU32);

    offset = (NvU32*)malloc(size);
    value = (NvU32*)malloc(size);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset/value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    // assert ENGINE
    // set register NV_PERF_PMM[chipletType]_ENGINE_SEL(domain) to NV_PERF_PMM[chipletType]_[domain]_SIGVAL_PMA_TRIGGER
    // for all instances of all chipletTypes
    // like for (GPC#0 + domain GPC0) - NV_PERF_PMMGPC_ENGINE_SEL(FERMI_CLK_DOMAIN_GPC0) = NV_PERF_PMMGPC_GPC0_SIGVAL_PMA_TRIGGER

    for (chipIdx = 0; chipIdx < fermiEventGroup->maxChiplets; chipIdx++) {
        if(fermiEventGroup->pmUnitMask & (1<<chipIdx))
        {
            domainRegOffset = fermiEventGroup->pmmAddress[chipIdx] + fermiEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
            offset[j]  = domainRegOffset + NV_PERF_PMM_STARTEXPERIMENT;
            value[j++] = NV_PERF_PMM_STARTEXPERIMENT_START_DOIT;
        }
    }

    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, j, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

EXIT:
    free (offset);
    free (value);

    return status;
}

CUprofResult fermiPerfmonEventGroupResetAllEvents(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);
    CU_ASSERT(pEventGroup->pCtx);


    switch(pEventGroup->domain->eventCollectionMethod)
    {
    case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
        // if event group is enabled, trigger the PM  Otherwise it would have been
        // done in disable event group call
        if (pEventGroup->isEnabled) {
            //status = AssertEngineModeB(pEventGroup);
            status = StartExptModeB(pEventGroup);
        }
        break;

    case CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
        // configure PM target and SM internal registers
        if (pEventGroup->isEnabled) {
            status = (CUprofResult)resetPMSMInternal(pEventGroup);
        }
        break;

    default:
        break;
    }

     // now reset all values for the event group
    cuosMemset(pEventGroup->values, 0, sizeof(NvU64) * pEventGroup->totalCounters
                                                     * pEventGroup->instanceCountAvail);

    return status;
}

static NV_INLINE NvBool fermiIsPpaSoftwareCounterDomain(CUeventDomainID domainId, NvU64 arch) {

    if(domainId == FERMI_SW_DOMAIN_GF100_PPA_NOPTRIG_SLD_SST) {
        return NV_TRUE;
    }

    switch(arch){
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF100:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF100B:
            {
                if((domainId == FERMI_SW_DOMAIN_GF100_PPA_NOPTRIG_FLOPS) ||
                 (domainId == FERMI_SW_DOMAIN_GF100_PPA_NOPTRIG_TRANSACTIONS) ||
                 (domainId == FERMI_SW_DOMAIN_GF100_PPA_NOPTRIG_INSTR_CLASS) ||
                 (domainId == FERMI_SW_DOMAIN_GF100_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS)) {
                    return NV_TRUE;
                }
            }
            break;
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF104:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF106:
#if defined(NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF104B) && defined(NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF106B)
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF104B:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF106B:
#endif
            {
                if((domainId == FERMI_SW_DOMAIN_GF104_PPA_NOPTRIG_FLOPS) ||
                 (domainId == FERMI_SW_DOMAIN_GF104_PPA_NOPTRIG_TRANSACTIONS) ||
                 (domainId == FERMI_SW_DOMAIN_GF104_PPA_NOPTRIG_INSTR_CLASS) ||
                 (domainId == FERMI_SW_DOMAIN_GF104_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS)) {
                    return NV_TRUE;
                }
            }
            break;
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF108:
            {
                if((domainId == FERMI_SW_DOMAIN_GF108_PPA_NOPTRIG_FLOPS) ||
                 (domainId == FERMI_SW_DOMAIN_GF108_PPA_NOPTRIG_TRANSACTIONS) ||
                 (domainId == FERMI_SW_DOMAIN_GF108_PPA_NOPTRIG_INSTR_CLASS) ||
                 (domainId == FERMI_SW_DOMAIN_GF108_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS)) {
                    return NV_TRUE;
                }
            }
            break;
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF119:

            {
                if((domainId == FERMI_SW_DOMAIN_GF119_PPA_NOPTRIG_FLOPS) ||
                 (domainId == FERMI_SW_DOMAIN_GF119_PPA_NOPTRIG_TRANSACTIONS) ||
                 (domainId == FERMI_SW_DOMAIN_GF119_PPA_NOPTRIG_INSTR_CLASS) ||
                 (domainId == FERMI_SW_DOMAIN_GF119_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS)) {
                    return NV_TRUE;
                }
            }
            break;
#endif
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF117:
            {
                if((domainId == FERMI_SW_DOMAIN_GF117_PPA_NOPTRIG_FLOPS) ||
                 (domainId == FERMI_SW_DOMAIN_GF117_PPA_NOPTRIG_TRANSACTIONS) ||
                 (domainId == FERMI_SW_DOMAIN_GF117_PPA_NOPTRIG_INSTR_CLASS) ||
                 (domainId == FERMI_SW_DOMAIN_GF117_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS)) {
                    return NV_TRUE;
                }
            }
            break;
        default:
            return NV_FALSE;
    }
    return NV_FALSE;
}

CUprofResult fermiPerfmonDomainCheckCompatible(CUctx *ctx,
                                               CUeventDomainID domainId1,
                                               CUeventDomainID domainId2,
                                               NvBool *bCompatible) {
    CUprofResult status = CUPROF_SUCCESS;
    CU_TRACE_FUNCTION();

    *bCompatible = NV_TRUE;

    if (domainId1 == domainId2) {
        return status;
    }

    //The ppaSwCounter domains are not compatible with each other:
    if (fermiIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip) &&
        fermiIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip)) {
        *bCompatible = NV_FALSE;
        return status;
    }

    if (((FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST == domainId2) &&
        (FERMI_NOPTRIG_SW_COUNTERS_DOMAIN == domainId1)) ||
        ((FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST == domainId1) &&
        (FERMI_NOPTRIG_SW_COUNTERS_DOMAIN == domainId2))) {
        *bCompatible = NV_FALSE;
        return status;
    }

    switch(ctx->device->state.chip){
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF100:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF100B:
        {
            if (((domainId1 == FERMI_CLK_DOMAIN_GF100_GPC0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF100_LTC0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF100_SM0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF100_HUB0) ||
                 (fermiIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip))) &&
                ((domainId2 == FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST) ||
                 (domainId2 == FERMI_NOPTRIG_SW_COUNTERS_DOMAIN))) {
                *bCompatible = NV_FALSE;
                return status;
            }

            if (((domainId2 == FERMI_CLK_DOMAIN_GF100_GPC0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF100_LTC0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF100_SM0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF100_HUB0) ||
                 (fermiIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip))) &&
                ((domainId1 == FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST) ||
                 (domainId1 == FERMI_NOPTRIG_SW_COUNTERS_DOMAIN))) {
                *bCompatible = NV_FALSE;
                return status;
            }

            if (((domainId1 == FERMI_CLK_DOMAIN_GF100_GPC0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF100_LTC0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF100_SM0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF100_HUB0)) &&
                 (fermiIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip))) {
                *bCompatible = NV_FALSE;
                return status;
            }

            if (((domainId2 == FERMI_CLK_DOMAIN_GF100_GPC0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF100_LTC0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF100_SM0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF100_HUB0)) &&
                 (fermiIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip))) {
                *bCompatible = NV_FALSE;
                return status;
            }
        }
        break;
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF104:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF106:
#if defined(NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF104B) && defined(NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF106B)
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF104B:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF106B:
#endif
        {
            if (((domainId1 == FERMI_CLK_DOMAIN_GF104_GPC0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF104_LTC0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF104_SM0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF104_HUB0) ||
                 (fermiIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip))) &&
                ((domainId2 == FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST) ||
                 (domainId2 == FERMI_NOPTRIG_SW_COUNTERS_DOMAIN))) {
                *bCompatible = NV_FALSE;
                return status;
            }

            if (((domainId2 == FERMI_CLK_DOMAIN_GF104_GPC0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF104_LTC0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF104_SM0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF104_HUB0) ||
                 (fermiIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip))) &&
                ((domainId1 == FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST) ||
                 (domainId1 == FERMI_NOPTRIG_SW_COUNTERS_DOMAIN))) {
                *bCompatible = NV_FALSE;
                return status;
            }

            if (((domainId1 == FERMI_CLK_DOMAIN_GF104_GPC0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF104_LTC0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF104_SM0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF104_HUB0)) &&
                 (fermiIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip))) {
                *bCompatible = NV_FALSE;
                return status;
            }

            if (((domainId2 == FERMI_CLK_DOMAIN_GF104_GPC0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF104_LTC0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF104_SM0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF104_HUB0)) &&
                 (fermiIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip))) {
                *bCompatible = NV_FALSE;
                return status;
            }
        }
        break;
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF108:
        {
            if (((domainId1 == FERMI_CLK_DOMAIN_GF108_GPC0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF108_LTC0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF108_HUB0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF108_SM0) ||
                 (fermiIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip))) &&
                ((domainId2 == FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST) ||
                 (domainId2 == FERMI_NOPTRIG_SW_COUNTERS_DOMAIN))) {
                *bCompatible = NV_FALSE;
                return status;
            }

            if (((domainId2 == FERMI_CLK_DOMAIN_GF108_GPC0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF108_LTC0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF108_HUB0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF108_SM0) ||
                 (fermiIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip))) &&
                ((domainId1 == FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST) ||
                 (domainId1 == FERMI_NOPTRIG_SW_COUNTERS_DOMAIN))) {
                *bCompatible = NV_FALSE;
                return status;
            }

            if (((domainId1 == FERMI_CLK_DOMAIN_GF108_GPC0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF108_LTC0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF108_HUB0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF108_SM0)) &&
                 (fermiIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip))) {
                *bCompatible = NV_FALSE;
                return status;
            }

            if (((domainId2 == FERMI_CLK_DOMAIN_GF108_GPC0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF108_LTC0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF108_HUB0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF108_SM0)) &&
                 (fermiIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip))) {
                *bCompatible = NV_FALSE;
                return status;
            }
        }
        break;
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF119:
        {
            if (((domainId1 == FERMI_CLK_DOMAIN_GF108_GPC0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF119_LTC0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF108_HUB0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF108_SM0) ||
                 (fermiIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip))) &&
                ((domainId2 == FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST) ||
                 (domainId2 == FERMI_NOPTRIG_SW_COUNTERS_DOMAIN))) {
                *bCompatible = NV_FALSE;
                return status;
            }

            if (((domainId2 == FERMI_CLK_DOMAIN_GF108_GPC0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF119_LTC0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF108_HUB0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF108_SM0) ||
                 (fermiIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip))) &&
                ((domainId1 == FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST) ||
                 (domainId1 == FERMI_NOPTRIG_SW_COUNTERS_DOMAIN))) {
                *bCompatible = NV_FALSE;
                return status;
            }

            if (((domainId1 == FERMI_CLK_DOMAIN_GF108_GPC0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF119_LTC0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF108_HUB0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF108_SM0)) &&
                 (fermiIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip))) {
                *bCompatible = NV_FALSE;
                return status;
            }

            if (((domainId2 == FERMI_CLK_DOMAIN_GF108_GPC0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF119_LTC0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF108_HUB0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF108_SM0)) &&
                 (fermiIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip))) {
                *bCompatible = NV_FALSE;
                return status;
            }
        }
        break;
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF117:
        {
            if (((domainId1 == FERMI_CLK_DOMAIN_GF108_GPC0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF117_LTC0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF108_HUB0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF108_SM0) ||
                 (fermiIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip))) &&
                ((domainId2 == FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST) ||
                 (domainId2 == FERMI_NOPTRIG_SW_COUNTERS_DOMAIN))) {
                *bCompatible = NV_FALSE;
                return status;
            }

            if (((domainId2 == FERMI_CLK_DOMAIN_GF108_GPC0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF117_LTC0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF108_HUB0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF108_SM0) ||
                 (fermiIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip))) &&
                ((domainId1 == FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST) ||
                 (domainId1 == FERMI_NOPTRIG_SW_COUNTERS_DOMAIN))) {
                *bCompatible = NV_FALSE;
                return status;
            }

            if (((domainId1 == FERMI_CLK_DOMAIN_GF108_GPC0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF117_LTC0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF108_HUB0) ||
                 (domainId1 == FERMI_CLK_DOMAIN_GF108_SM0)) &&
                 (fermiIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip))) {
                *bCompatible = NV_FALSE;
                return status;
            }

            if (((domainId2 == FERMI_CLK_DOMAIN_GF108_GPC0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF117_LTC0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF108_HUB0) ||
                 (domainId2 == FERMI_CLK_DOMAIN_GF108_SM0)) &&
                 (fermiIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip))) {
                *bCompatible = NV_FALSE;
                return status;
            }
        }
        break;
#endif

    default :
        *bCompatible = NV_FALSE; // Default case should never be encountered
        break;
    }

    return status;
}

// Function to check if domain is already enabled for profiling
static CUprofResult fermiDomainCompatible(CUctx *ctx, CUeventDomainID domainId, NvBool *bCompatible) {
    CUprofResult status = CUPROF_SUCCESS;
    CUeventGroup *currEg = NULL;
    void *eventBase = NULL;
    NvU32 i = 0;

    CU_TRACE_FUNCTION();

    *bCompatible = NV_TRUE;

    currEg = (CUeventGroup*)listGetNext(ctx->pmNew->egList, &eventBase);
    for (i = 0; (i < ctx->pmNew->totalEventGroups) && currEg; i++, currEg = (CUeventGroup*)listGetNext(NULL, &eventBase)) {
        if (currEg->isEnabled) {
            //cannot enable 2 eventgroups from same domain simultaneously
            if (domainId == currEg->domainId) {
                *bCompatible = NV_FALSE;
            }
            else {
                fermiPerfmonDomainCheckCompatible(ctx, domainId, currEg->domainId, bCompatible);
            }
            if (*bCompatible == NV_FALSE) {
                break;
            }
        }
    }

    return status;
}

CUprofResult fermiPerfmonEventGroupEnable(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    CUctx *ctx = NULL;
    NvBool bCompatible = NV_TRUE;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);
    //CU_ASSERT(pEventGroup->domainId < MAX_DOMAINS);

    ctx = pEventGroup->pCtx;
    // make launch blocking
    //ctx->launchBlocking = 1;

    status = fermiDomainCompatible(ctx, pEventGroup->domainId, &bCompatible);
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("Failed to check domain enable/disable status\n"));
        return status;
    }
    if (bCompatible == NV_FALSE) {
        CU_ERROR_PRINT(("Profiler allows to monitor only one event group from any domain\n"));
        return CUPROF_ERROR_NOT_COMPATIBLE;
    }

    switch(pEventGroup->domain->eventCollectionMethod)
    {
    case CUPROF_EVENT_COLLECTION_METHOD_HWPM:

        /************************************************************************
           Reserve the perfmon if CUPTI have not taken care of it already. This 
           extra perfmon reserve call is required for supporting HWPM counter 
           profiling for toolkits < R5.5. The flag isPerfmonReserved is modified 
           only while reserving perfmon via CUPTI. This call will ideally not be 
           executed for Toolkits > R5.0 (Bug 1408976)
        *************************************************************************/
        if (!ctx->device->state.profilerState.isPerfmonReservedOutsideHal) {
            status = perfmonControl(ctx, NV_TRUE, NV_TRUE);
            if (status != CUPROF_SUCCESS) {
                CU_ERROR_PRINT(("Failed to control PM HW\n"));
                return status;
            }
        }

        // configure PM target and mode B settings
        status = setupPMTarget(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            goto Error;
        }

        if (pEventGroup->configChanged) {
          status = setupPMRegistersModeCommon(pEventGroup,
                          &pEventGroup->pCtx->pmNew->perfmonTriggerRefCount);
          if (CUPROF_SUCCESS != status) {
              goto Error;
          }
        }

          status = setupPMRegistersModeB(pEventGroup);
          if (CUPROF_SUCCESS != status) {
              pEventGroup->pCtx->pmNew->perfmonTriggerRefCount--;
              goto Error;
          }

        status = setPMEnableReg(pEventGroup, NV_TRUE);
        if (CUPROF_SUCCESS != status) {
            goto Error;
        }

        if (ctx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS) {
            status = StartExptModeB(pEventGroup);
            if (CUPROF_SUCCESS != status) {
                goto Error;
            }
        }
        status = AssertEngineModeB(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            //Release Mode B in case Assert fail.
            PMReleaseModeB(pEventGroup);
            goto Error;
        }

        break;

    case CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
        // configure PM target and SM internal registers
      status = setupPMTarget(pEventGroup);
      if (CUPROF_SUCCESS != status) {
          goto Error;
      }

        if (pEventGroup->configChanged) {
          status = (CUprofResult)SetupPMRegistersSMInternal(pEventGroup);
          if (CUPROF_SUCCESS != status) {
              goto Error;
          }
        }

        status = (CUprofResult)setPMEnableRegSM(pEventGroup, NV_TRUE);
        if (CUPROF_SUCCESS != status) {
            goto Error;
        }

        if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS) {
            fermiPerfmonStartCounters(NULL, pEventGroup);
        }

        break;

    default:
        //s/w counters do nothing
        break;
    }


    // set enable flags
    pEventGroup->isEnabled = 1;
    setDomainEventGroup(ctx->pmNew->domainEventGroupEnabled, pEventGroup->domainId, 1);

    // reset all counters
    if((pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_SMPERF) ||
        (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW) ||
        (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW))
        cuosMemset(pEventGroup->values, 0, sizeof(NvU64) * pEventGroup->arch.fermiEventGroup->pSM->SMCountersAdded
                                                     * pEventGroup->instanceCountAvail);
    else
        cuosMemset(pEventGroup->values, 0, sizeof(NvU64) * pEventGroup->totalCounters
                                                     * pEventGroup->instanceCountAvail);

    return CUPROF_SUCCESS;

Error:
    return status;
}

static CUprofResult logPMCountersModeB(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *values = NULL;
    NvU32 size = 0, j = 0;
    NvU32 domainRegOffset = 0, chipIdx = 0, i = 0;
    CUfermiEventGroup  *fermiEventGroup;
    CUparsedClk *pTempParsedClk = NULL;
    CU_TRACE_FUNCTION();


    fermiEventGroup = pEventGroup->arch.fermiEventGroup;
    CU_ASSERT(fermiEventGroup);
    size  = sizeof(NvU32) * (CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS + fermiEventGroup->pParsedClk->isElapsedClocksProfiled);;

    offset = (NvU32*)malloc(size*fermiEventGroup->maxChiplets);
    values = (NvU32*)malloc(size*fermiEventGroup->maxChiplets);
    if (!offset || !values) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset or values\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    pTempParsedClk = fermiEventGroup->pParsedClk;

    for (chipIdx = 0; chipIdx < fermiEventGroup->maxChiplets; chipIdx++) {
        if(fermiEventGroup->pmUnitMask & (1<<chipIdx))
        {
            for(i=0; i<pEventGroup->totalCounters; i++, j++)
            {

                domainRegOffset = fermiEventGroup->pmmAddress[chipIdx] + fermiEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
                switch(pTempParsedClk->eventspec[i]) {
                case (NV_PMM_TRIG1 | NV_PMM_EVENT):
                    offset[j] = domainRegOffset + NV_PMM_EVENTCNT;
                    break;
                case NV_PMM_TRIG0:
                    offset[j] = domainRegOffset + NV_PMM_TRIGGERCNT;
                    break;
                case NV_PMM_TRIG1:
                    offset[j] = domainRegOffset + NV_PMM_THRESHCNT;
                    break;
                case NV_PMM_EVENT:
                    offset[j] = domainRegOffset + NV_PMM_EVENTCNT;
                    break;
                case NV_PMM_SAMPLE:
                    offset[j] = domainRegOffset + NV_PMM_SAMPLECNT;
                    break;
                case NV_ELAPSED_CLOCKS:
                    offset[j] =  domainRegOffset + NV_PMM_ELAPSED;
                    break;

                default:
                    CU_ERROR_PRINT(("Not a valid trigger type.\n"));
                    break;
                }
            }
        }
    }
    CU_ASSERT(j <= (CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS + fermiEventGroup->pParsedClk->isElapsedClocksProfiled)*fermiEventGroup->maxChiplets);
    // read counter value in temporary folder as the indexing is by chipidx and for HWPM
    //the mask can be true for intermediate chipIdx (specially for gpctpc counters
    if (CUDA_SUCCESS != PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, j, offset, values, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }
    j = 0;
    for (chipIdx = 0; chipIdx < fermiEventGroup->maxChiplets; chipIdx++) {
        if(fermiEventGroup->pmUnitMask & (1<<chipIdx))
        {
            memcpy((pTempParsedClk->values + (pEventGroup->totalCounters * chipIdx)),
                    values + (pEventGroup->totalCounters * j),
                    pEventGroup->totalCounters * sizeof(NvU32));
            j++;
        }
    }
EXIT:
    free (offset);
    free (values);

    return status;
}

// detect if there has been a counter overflow
static CUprofResult detectCounterOverflowModeB(const CUeventGroup *pEventGroup, NvBool* bIsOverflow)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUfermiEventGroup  *fermiEventGroup;
    CUparsedClk *pTempParsedClk = NULL;
    NvU32 chipIdx = 0, i = 0;

    CU_TRACE_FUNCTION();

    fermiEventGroup = pEventGroup->arch.fermiEventGroup;
    CU_ASSERT(fermiEventGroup);

    // NV_PERF_PMM_CONTROL_SHADOW_STATE_OVERFLOW field has nothing to do with overflowing snapshots (pm_trigger).
    // in mode B the fact that the counter is saturated (0xFFFFFFFF) is enough to assume overflow.
    for (chipIdx = 0; chipIdx < fermiEventGroup->maxChiplets; chipIdx++) {
        if(fermiEventGroup->pmUnitMask & (1<<chipIdx)) {
            pTempParsedClk = pEventGroup->arch.fermiEventGroup->pParsedClk;
            for(i=0; i<pEventGroup->totalCounters; i++) {
                if (COUNTER_MAX32BIT == *(pTempParsedClk->values + (pEventGroup->totalCounters * chipIdx) + i)) {
                    *bIsOverflow = NV_TRUE;
                    return CUPROF_SUCCESS;
                }
            }
        }
    }
    return status;
}

static CUprofResult PMReleaseModeB(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *value = NULL;
    NvU32 count = 0, size = 0, domainRegOffset = 0;
    NvU32 chipIdx = 0;
    CUfermiEventGroup  *fermiEventGroup;

    CU_TRACE_FUNCTION();
    fermiEventGroup = pEventGroup->arch.fermiEventGroup;


    size = sizeof(NvU32) * fermiEventGroup->maxChiplets;
    offset = (NvU32*)malloc(size);
    value  = (NvU32*)malloc(size);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset and value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    for (chipIdx = 0; chipIdx < fermiEventGroup->maxChiplets; chipIdx++) {
        if(fermiEventGroup->pmUnitMask & (1<<chipIdx))
        {
            domainRegOffset = fermiEventGroup->pmmAddress[chipIdx] + fermiEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
            offset[count]  = domainRegOffset + NV_PERF_PMM_RELEASE;
            value[count++] = NV_PERF_PMM_RELEASE_SHADOWS_DOIT;
        }
    }

    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, count, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

EXIT:
    free (offset);
    free (value);

    return status;
}

static CUprofResult fermiPerfmonSampleCountersNew(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvBool bIsOverflow = NV_FALSE;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS) {
        status = StartExptModeB(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            goto EXIT;
        }
    }

    status = logPMCountersModeB(pEventGroup);
    if (CUPROF_SUCCESS != status) {
        goto EXIT;
    }

    // report overflow if any
    if (CUPROF_SUCCESS != detectCounterOverflowModeB(pEventGroup, &bIsOverflow)) {
        goto EXIT;
    }

    if (bIsOverflow) {
        CU_ERROR_PRINT(("One or more counter is overflowing.\n"));
    }

    status = PMReleaseModeB(pEventGroup);
    if (CUPROF_SUCCESS != status) {
        goto EXIT;
    }

EXIT:

    return status;
}

// Function to read counters from hardware
static CUprofResult fermiReadCounters(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 i = 0, chipIdx = 0, j = 0, smcntr_idx, lsh_cnt;
    CUparsedClk     *pTempParsedClk = NULL;
    CUSMCtrInfo     *pSM = NULL;
    NvBool          bIsOverflow = NV_FALSE;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);
    CU_ASSERT(pEventGroup->isEnabled);

    if (!pEventGroup->totalCounters) {
        return CUPROF_SUCCESS;
    }

    switch(pEventGroup->domain->eventCollectionMethod)
    {
    case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
        //sample PM signals
        status = fermiPerfmonSampleCountersNew(pEventGroup);
        if (status != CUPROF_SUCCESS) {
            return status;
        }

        for (chipIdx = 0; chipIdx < pEventGroup->arch.fermiEventGroup->maxChiplets; chipIdx++) {
            if(pEventGroup->arch.fermiEventGroup->pmUnitMask & (1<<chipIdx))
            {
                pTempParsedClk = pEventGroup->arch.fermiEventGroup->pParsedClk;
                for(i=0; i<pEventGroup->totalCounters; i++)
                {
                    //copy linearly in eventgroup in folowing fashion: [instancecount][counter]
                    if ((*(pTempParsedClk->values + pEventGroup->totalCounters * chipIdx + i) != COUNTER_MAX32BIT) &&
                        (pEventGroup->values[j] != COUNTER_MAX64BIT))
                    {
                        pEventGroup->values[j++] += *(pTempParsedClk->values + pEventGroup->totalCounters * chipIdx + i);
                    }
                    else {
                        // 32-bit counter is overflowing, set 64-bit out value to max
                        pEventGroup->values[j++] = COUNTER_MAX64BIT;
                    }
                }
            }
        }

        break;

    case CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
        //sample SM counters
        if (CUDA_SUCCESS != logPMCountersSMInternal(pEventGroup)) {
            return CUPROF_ERROR_UNKNOWN;
        }

        // report overflow if any
        if (CUDA_SUCCESS != detectCounterOverflowSMInternal(pEventGroup, &bIsOverflow)) {
            return status;
        }
        if (bIsOverflow) {
            CU_ERROR_PRINT(("One or more counter is overflowing.\n"));
        }

        pSM = pEventGroup->arch.fermiEventGroup->pSM;

        for (chipIdx = 0; chipIdx < pEventGroup->arch.fermiEventGroup->maxChiplets; chipIdx++) {
            if(pEventGroup->arch.fermiEventGroup->pmUnitMask & (1<<chipIdx))
            {
                for(i=0; i<pEventGroup->totalCounters; i++)
                {
                    // The values have to be aggregated in case of the multi-bit SM Counters. Hence, leftshifting the values and adding them.
                    lsh_cnt = 0;
                    for(smcntr_idx = pSM->start[i] ; smcntr_idx < (pSM->start[i] + pSM->bitCount[i]) ; smcntr_idx++) {
                        //copy linearly in eventgroup in folowing fashion: [instancecount][counter]
                        if ((*(pSM->values + pSM->SMCountersAdded * chipIdx + smcntr_idx) != COUNTER_MAX32BIT) &&
                            (pEventGroup->values[j] != COUNTER_MAX64BIT))
                        {
                            pEventGroup->values[j] += (NvU64)(*(pSM->values + pSM->SMCountersAdded * chipIdx + smcntr_idx)) << lsh_cnt++;
                        }
                        else {
                            // if one of the signal of multi-bit counter overflow, mark counter for overflow
                            // 32-bit counter is overflowing, set 64-bit out value to max
                            pEventGroup->values[j] = COUNTER_MAX64BIT;
                            break;
                        }
                    }
                    j++;
                }
            }
        }
        break;

    default:
        break;
    }


    return status;
}

CUprofResult fermiPerfmonEventGroupDisable(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    CUctx *ctx;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);
    //CU_ASSERT(pEventGroup->domainId < MAX_DOMAINS);

    ctx = pEventGroup->pCtx;

    // set flag
    pEventGroup->isEnabled = 0;
    setDomainEventGroup(ctx->pmNew->domainEventGroupEnabled, pEventGroup->domainId, 0);

    switch(pEventGroup->domain->eventCollectionMethod) {
        case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
            // PM_ENABLE bit setting is Global. It will affect counter profiling in a multi-process/multi-ctx scenario
            // Commenting the Code to clear off the PM_ENABLE bit:(Bug 1254320)
            // To do: Re-enable the code when bug 973271 is fixed
#if 0
            status = setPMEnableReg(pEventGroup, NV_FALSE);
            if (CUPROF_SUCCESS != status) {
                CU_ERROR_PRINT(("Failed to disable the HW PMReg\n"));
            }
#endif
            resetPMTarget(pEventGroup);
            /************************************************************************
               Release the perfmon if perfmon is reserved in eventGroupEnable. This 
               extra perfmon release call is required for supporting HWPM counter 
               profiling for toolkits < R5.5. The flag isPerfmonReserved is modified 
               only while reserving perfmon via CUPTI. This call will ideally not be 
               executed for Toolkits > R5.0 (Bug 1408976)
            *************************************************************************/
            if (!ctx->device->state.profilerState.isPerfmonReservedOutsideHal) {
                status = perfmonControl(ctx, NV_FALSE, NV_TRUE);
                if (status != CUPROF_SUCCESS) {
                    CU_ERROR_PRINT(("Failed to control PM HW\n"));
                    return status;
                }
            }
            break;

        case CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW:
        case CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW:
        case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:

            if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS) {
                fermiPerfmonStopCounters(NULL, pEventGroup);
            }

            // PM_ENABLE bit setting is Global. It will affect counter profiling in a multi-process/multi-ctx scenario
            // Commenting the Code to clear off the PM_ENABLE bit:(Bug 1254320)
            // To do: Re-enable the code when bug 973271 is fixed
#if 0
            status = setPMEnableRegSM(pEventGroup, NV_FALSE);
            if (CUPROF_SUCCESS != status) {
                CU_ERROR_PRINT(("Failed to disable the SMPERF PMReg\n"));
            }
#endif
            resetPMTarget(pEventGroup);
            break;

        case CUPROF_EVENT_COLLECTION_METHOD_SW:
        default:
            //do nothing
            break;
    }

    return status;
}

CUprofResult fermiPerfmonEventGroupReadEvent(CUeventGroup          *pEventGroup,
                                             CUprof_ReadEventFlags flags,
                                             CUprof_EventID        eventID,
                                             size_t                *bufferSizeBytes,
                                             NvU64                 *counterData)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUeventInfo *currEvent = NULL;
    void *eventBase = NULL;
    NvU32 i = 0, j = 0, instanceCount = 0;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if (pEventGroup->domainId != FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST)
        CU_ASSERT(pEventGroup->arch.fermiEventGroup);

    currEvent = (CUeventInfo*)listGetNext(pEventGroup->pEventInfoList, &eventBase);
    for (i = 0; (i < pEventGroup->totalCounters) && currEvent; i++, currEvent = (CUeventInfo*)listGetNext(NULL, &eventBase)) {
        if (((CUeventData*)currEvent->pEventData)->signalId == eventID) {
            break;
        }
    }

    if (i == pEventGroup->totalCounters) {
        CU_ERROR_PRINT(("Invalid event-id %d\n", (int)eventID));
        return CUPROF_ERROR_INVALID_EVENT_ID;
    }

    // trigger the PM and read counters
    if (pEventGroup->domainId != FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST) {
        status = fermiReadCounters(pEventGroup);
        if (status != CUPROF_SUCCESS) {
            CU_ERROR_PRINT(("Failed to read counters or reset pm\n"));
            return status;
        }
    }

    if(pEventGroup->profileAll) {
        instanceCount = pEventGroup->instanceCountAvail;
    }
    else {
        instanceCount = 1;
    }

    //Check how many bytes are allocated for counterData
    instanceCount = MIN(*(NvU32*)bufferSizeBytes / sizeof(NvU64), instanceCount);
    *bufferSizeBytes = instanceCount * sizeof(NvU64);

    for(j = 0; j < instanceCount; j++)
    {
        counterData[j] = pEventGroup->values[i + j*pEventGroup->totalCounters];
        // zero out the stored value, only returned counter values are considered
        pEventGroup->values[i + j*pEventGroup->totalCounters] = 0;
    }

    if((CUPROF_EVENT_COLLECTION_METHOD_SMPERF == pEventGroup->domain->eventCollectionMethod) ||
       (CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW == pEventGroup->domain->eventCollectionMethod) ||
       (CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW == pEventGroup->domain->eventCollectionMethod)) {
        status = (CUprofResult)resetPMSMInternal(pEventGroup);
    }

    return status;
}

CUprofResult fermiPerfmonEventGroupReadAllEvents(CUeventGroup *pEventGroup,
                                                 CUprof_ReadEventFlags  flags,
                                                 size_t                 *bufferSizeBytes,
                                                 NvU64                  *counterDataBuffer,
                                                 size_t                 *arraySizeBytes,
                                                 CUprof_EventID         *eventIDArray,
                                                 size_t                 *numCountersRead)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUeventInfo *currEvent = NULL;
    void *eventBase = NULL;
    NvU32 numEvents = 0, i = 0, j = 0, totalValues = 0, instanceCount = 0;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if (pEventGroup->domainId != FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST)
        CU_ASSERT(pEventGroup->arch.fermiEventGroup);

    // trigger the PM and read counters
    if (pEventGroup->domainId != FERMI_SW_COUNTERS_DOMAIN_LD_ST_INST) {
        status = fermiReadCounters(pEventGroup);
        if (status != CUPROF_SUCCESS) {
            CU_ERROR_PRINT(("Failed to read counters or reset pm\n"));
            return status;
        }
    }

    if(pEventGroup->profileAll) {
        instanceCount = pEventGroup->instanceCountAvail;
    }
    else {
        instanceCount = 1;
    }

    //Check how many bytes are allocated for counterData
    totalValues = instanceCount * pEventGroup->totalCounters;
    totalValues = MIN(*(NvU32*)bufferSizeBytes / sizeof(NvU64), totalValues);

    //It makes sense to give all instances of possible number of events
    numEvents = totalValues / instanceCount;

    *bufferSizeBytes = numEvents * instanceCount * sizeof(NvU64);

    for(i = 0; i < instanceCount; i++) {
        for(j = 0; j < numEvents; j++) {
            *(counterDataBuffer+i*numEvents+j) = *(pEventGroup->values + i*pEventGroup->totalCounters + j);
            // zero out the stored value, only returned counter values are considered
            *(pEventGroup->values + i*pEventGroup->totalCounters + j) = 0;
        }
    }

    *numCountersRead = numEvents;

    // assuming eventId params are optional
    if (arraySizeBytes && (*arraySizeBytes > 0) && eventIDArray) {
        numEvents = MIN(*(NvU32*)arraySizeBytes / sizeof(CUprof_EventID), *(NvU32*)numCountersRead);
        currEvent = (CUeventInfo*)listGetNext(pEventGroup->pEventInfoList, &eventBase);

        for (i = 0; (i < pEventGroup->totalCounters) && (i < numEvents) && currEvent; i++, currEvent = (CUeventInfo*)listGetNext(NULL, &eventBase)) {
            eventIDArray[i] = ((CUeventData*)currEvent->pEventData)->signalId;
        }
        *arraySizeBytes = numEvents * sizeof(CUprof_EventID);
    }

    if((CUPROF_EVENT_COLLECTION_METHOD_SMPERF == pEventGroup->domain->eventCollectionMethod) ||
       (CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW == pEventGroup->domain->eventCollectionMethod) ||
       (CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW == pEventGroup->domain->eventCollectionMethod)){
        status = (CUprofResult)resetPMSMInternal(pEventGroup);
    }

    return status;
}

// this function is not exposed to external users
// it assists internal tools (profiler) to control event group
// based operations
CUprofResult fermiPerfmonEventGroupControl(CUeventGroup *pEventGroup,
                                           CUeventGroupFlag flag,
                                           void *value)
{
    CUprofResult status = CUPROF_SUCCESS;

    CU_TRACE_FUNCTION();

    CU_ASSERT(pEventGroup);

    switch (flag) {
        case CU_EVENT_GROUP_FLAG_SET_PROFILE_ALL_DOMAIN_INSTANCES:
            pEventGroup->profileAll = 1;
            break;
    case CU_EVENT_GROUP_FLAG_GET_CHIP_TYPE_FB:
            if (pEventGroup->domain->chipletType == PM_CHIPLET_TYPE_FBP) {
                *(int*)value = 1;
            }
            else {
                *(int*)value = 0;
            }
            break;
    case CU_EVENT_GROUP_FLAG_GET_UNIT_TYPE_SM:
            if ((pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_SMPERF) ||
               (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW) ||
               (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW)) {
                *(int*)value = 1;
            }
            else {
                *(int*)value = 0;
            }
            break;
        default:
            CU_ERROR_PRINT(("Not a valid flag (%d)\n", flag));
            break;
    }

    return status;
}
// detect if there has been a counter overflow
static CUresult detectCounterOverflowSMInternal(const CUeventGroup *pEventGroup, NvBool* bIsOverflow)
{
    CUresult status = CUDA_SUCCESS;
    CUfermiEventGroup  *pFermiEventGroup = NULL;
    NvBool bOverflow = NV_FALSE;
    NvU32 offset = 0, value = 0, gpcId = 0, tpcId = 0, smId = 0;
    NvU32 i = 0;

    CU_TRACE_FUNCTION();

    *bIsOverflow = NV_FALSE;
    pFermiEventGroup = pEventGroup->arch.fermiEventGroup;

    // Bug 542157 - PRI_SM_DSM_PERF_COUNTER_STATUS which contains 8 bits of overflow, is too "sticky".
    // when these counters overflow, the overflow bit is set and continues to be set until explicitly
    // cleared by either state bundles to reload the perf counters or PRI write. it's a gf100/gf110 only issue.
    // the issue is that once these overflow bits are set, they will not be and can not be cleared until a context reset
    // as a result we'd end up reporting overflow for all sebsequent launches once it occurs for any launch
    for(gpcId = 0; gpcId < pFermiEventGroup->gpcCount; gpcId++)
    {
        for(tpcId = 0; tpcId < pFermiEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
        {
            if(pFermiEventGroup->pmUnitMask & (1<<smId))
            {
                offset = 0, value = 0;
                // query status register
                offset = NV_SM_DSM_PERF_COUNTER_STATUS(gpcId, tpcId);
                status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, 1, &offset, &value, 0);
                if (CUDA_SUCCESS != status) {
                    return status;
                }

                // bits [7:0] are overflow bits, 1 bit for each of the 8 SM internal perf counters
                for (i = 0; i < pFermiEventGroup->pSM->SMCountersAdded; i++) {
                    if (value & (1<<i)) {
                        // set counter value to overflow
                        *(pFermiEventGroup->pSM->values + pFermiEventGroup->pSM->SMCountersAdded * smId + i) = COUNTER_MAX32BIT;
                    }
                }

                bOverflow = (value & 0xff) ? NV_TRUE : NV_FALSE;
                // update the return value by ORing else overflow status of previous instnace
                // might get lost
                *bIsOverflow |= bOverflow;

                if (bOverflow) {
                    // Clear the overflow bits
                    value = 0x0;
                    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, 1, &offset, &value, 0);
                    if (CUDA_SUCCESS != status) {
                        return status;
                    }
                    // don't return since we need to check the overflow in all profiled instances
                }
            }
            smId++;
        }
    }

    return status;
}


static CUresult setPMEnableRegSM(const CUeventGroup *pEventGroup, NvBool bEnable)
{
    //Function to be changed for new version
    CUresult status = CUDA_SUCCESS;
    NvU32 offset, value, j = 0;
    PMEnableRegInfo *pPMEnableRegInfo = NULL;

    CU_TRACE_FUNCTION();


    pPMEnableRegInfo = &pEventGroup->pCtx->device->state.pPerfUnitTable[PM_UNIT_SM].pmEnableRegInfo;

    for(j=0; j< pEventGroup->arch.fermiEventGroup->maxChiplets; j++)
    {
        if(pEventGroup->arch.fermiEventGroup->pmUnitMask & (1<<j))
        {
            offset = pEventGroup->arch.fermiEventGroup->priAddress[j] + pPMEnableRegInfo->regOffset;
            value = 0;

            // read _PM registers
            status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, 1, &offset, &value, 0);
            if (status != CUDA_SUCCESS) {
                return status;
            }

            // set PM_ENABLE bit by ORing the read value for selected instance
            // disable PM_ENABLE bit by ANDing the read value for all others instances
            if(bEnable)
            {
                value |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
            }
            else
            {
                value &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
            }

            status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, 1, &offset, &value, 0);
            if (status != CUDA_SUCCESS) {
                return status;
            }
        }
    }

    return status;
}

static CUresult SetupPMRegistersSMInternal(CUeventGroup *pEventGroup) {
    CUresult status = CUDA_SUCCESS;
    NvU32 gpcTarget = 0, tpcTarget = 0;
    NvU32 *offset = NULL, i, gpcId = 0, tpcId = 0, smId = 0;
    NvU32 *value  = NULL;
    NvU32 count = 0, valueA = 0, perfEvent, numRegs = 20;
    NvU64 eventGroup = 0;
    CUnvCurrent* nvCurrent = NULL;
    NvU32 index = 0, smcntr_idx;
    CUSMCtrInfo     *pSM = NULL;

    CU_TRACE_FUNCTION();

    if((pEventGroup->pCtx->device->state.chip == (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF100)) ||
       (pEventGroup->pCtx->device->state.chip == (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF100B)))
    {
        // Enable the workaround for the NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER[0..7]_CONTROL registers on GF100/GF110
        // see bugs 555914, 542023, 879041
        // Use the new RM Control call for enabling the WAR if it is defined:
#if defined(NV2080_CTRL_CMD_GR_CTXSW_SMPC_MODE)
        if (!pEventGroup->pCtx->pmNew->flag)
        {
            status = pEventGroup->pCtx->device->dmal.deviceSetSMPCCtxswMode(pEventGroup->pCtx, NV_TRUE);
            if (status != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Error setting the CTXSW bit\n"));
                goto EXIT;
            }
            pEventGroup->pCtx->pmNew->flag = 1;
        }
#else
        status = setFalcon05Method(pEventGroup->pCtx);
        if (status != CUDA_SUCCESS) {
            return status;
        }
#endif

    }

    //----------------Changes done for supporting multi-bit signals in SM0 domain---------------------------------
    //A structure having details as bitCount, start position, overflow bit, pointer to sigtable is maintained.
    //The details of each SM signal is maintained in this structure.
    //The values in control registers are set as seperate single bit counters and then aggregated later.
    //------------------------------------------------------------------------------------------------------------

    //Allocate memory of size = (numRegs * #SMs * sizeof(NvU32))
    offset = (NvU32 *)malloc(numRegs * pEventGroup->instanceCountAvail * sizeof(NvU32));
    value = (NvU32 *)calloc(numRegs * pEventGroup->instanceCountAvail, sizeof(NvU32));

    if(!(offset && value)) {
        CU_ERROR_PRINT(("Error allocating memory for offset-value arrays.\n"));
        status = (CUresult)CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    pSM = pEventGroup->arch.fermiEventGroup->pSM;
    for(gpcId = 0; gpcId < pEventGroup->arch.fermiEventGroup->gpcCount; gpcId++)
    {
        for(tpcId = 0; tpcId < pEventGroup->arch.fermiEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
        {
            if(pEventGroup->arch.fermiEventGroup->pmUnitMask & (1<<smId))
            {
                gpcTarget = gpcId;
                tpcTarget = tpcId;

                // Select group, edge, func etc

                for(i=0; i<(NvU32)pEventGroup->totalCounters; i++)
                {
                    for(smcntr_idx = pSM->start[i] ; smcntr_idx < (pSM->start[i] + pSM->bitCount[i]) ; smcntr_idx++)
                        eventGroup |= ((NvU64)pSM->sigtable[i]->eventGroup) << (smcntr_idx*8);
                }

                // Performance Counter Group mux select
                // GRP0 - 7:0,  GRP1 - 15:8, GRP2 - 23:16, GRP3 - 31:24
                offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL_SEL0(gpcTarget, tpcTarget);
                value[count++] = (NvU32) (eventGroup & 0xffffffff);
                offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL_SEL1(gpcTarget, tpcTarget);
                value[count++] = (NvU32) (eventGroup >> 32);

                // Performance Counter - edge
                // EDGE0 - 3:3, EDGE1 - 7:7, EDGE2 - 11:11, EDGE3 - 15:15, EDGE4 - 19:19, EDGE5 - 23:23, EDGE6 - 27:27, EDGE7 - 31:31
                offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL0(gpcTarget, tpcTarget);
                value[count++] = 0x00000000;

                {
                    // setting the function values to 0
                    // These values will be set just before the kernel launch

                    offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL1(gpcTarget, tpcTarget);
                    value[count++] = 0;
                    offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL2(gpcTarget, tpcTarget);
                    value[count++] = 0;
                    offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL3(gpcTarget, tpcTarget);
                    value[count++] = 0;
                    offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL4(gpcTarget, tpcTarget);
                    value[count++] = 0;
                }

                // Each perf counter has 4 bits feeding into a function table.  Each bit
                // can be selected from 1 of 8 bits of 1 of the 8 groups (selected via
                // the PERF_COUNTER_CONTROL_SEL* register above).
                // BIT#_GRP selects 1 of 8 groups
                // BIT#_SIG selects 1 of the 8 signals from that selected group

                if ((pEventGroup->pCtx->device->state.chip != (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF100)) &&
                    (pEventGroup->pCtx->device->state.chip != (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF100B))) {
                    for (index = 0; index < pEventGroup->totalCounters; index++) {
                        perfEvent = pSM->sigtable[index]->perfEvent;
                        for(smcntr_idx = pSM->start[index] ; smcntr_idx < (pSM->start[index] + pSM->bitCount[index]) ; smcntr_idx++) {
                            switch(smcntr_idx)
                            {
                                case 0:
                                    offset[count] = NV_SM_DSM_PERF_COUNTER0_CONTROL(gpcTarget, tpcTarget);
                                    break;
                                case 1:
                                    offset[count] = NV_SM_DSM_PERF_COUNTER1_CONTROL(gpcTarget, tpcTarget);
                                    break;
                                case 2:
                                    offset[count] = NV_SM_DSM_PERF_COUNTER2_CONTROL(gpcTarget, tpcTarget);
                                    break;
                                case 3:
                                    offset[count] = NV_SM_DSM_PERF_COUNTER3_CONTROL(gpcTarget, tpcTarget);
                                    break;
                                case 4:
                                    offset[count] = NV_SM_DSM_PERF_COUNTER4_CONTROL(gpcTarget, tpcTarget);
                                    break;
                                case 5:
                                    offset[count] = NV_SM_DSM_PERF_COUNTER5_CONTROL(gpcTarget, tpcTarget);
                                    break;
                                case 6:
                                    offset[count] = NV_SM_DSM_PERF_COUNTER6_CONTROL(gpcTarget, tpcTarget);
                                    break;
                                case 7:
                                    offset[count] = NV_SM_DSM_PERF_COUNTER7_CONTROL(gpcTarget, tpcTarget);
                                    break;
                            }
                            if(pSM->sigtable[index]->sigType == SIG_TYPE_MULTIPLE) {
                                value[count]  = smcntr_idx | (perfEvent & 0x00000007) << 4;
                                value[count] |= (smcntr_idx | ((perfEvent & 0x00000070)>>4) << 4) << 8;
                                value[count] |= (smcntr_idx | ((perfEvent & 0x00000700)>>8) << 4) << 16;
                                value[count] |= (smcntr_idx | ((perfEvent & 0x00007000)>>12) << 4) << 24;
                            }
                            else {
                                value[count]  = smcntr_idx | (perfEvent & 0x00000007) << 4;
                                perfEvent++;
                            }
                            count++;
                        }
                    }
                }
            }
            smId++;
        }
    }
    CU_ASSERT(count <= (numRegs * pEventGroup->instanceCountAvail));
    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, count, offset, value, 0);
    if (status != CUDA_SUCCESS) {
        goto EXIT;
    }

    // configure the mux structure of each bit of each counter
    // SM_DSM_PERF_COUNTER0_CONTROL registers (0...7) are not writable through PRI.
    // See bug 540853 and instance bug  542023 (corresponding ctxsw WAR).
    // Use the SetShaderPerformanceCounterControlA methods instead
    // EVENT# selects 1 of 8 groups
    // BIT_SELECT# selects 1 of the 8 signals from that selected group

    if ((pEventGroup->pCtx->device->state.chip == (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF100)) ||
        (pEventGroup->pCtx->device->state.chip == (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GF100B))) {

    streamBeginPush(
        pEventGroup->pCtx->streamManager,
        CU_CHANNEL_COMPUTE,
        pEventGroup->pCtx->barrierStream,
        &nvCurrent,
        NULL);

    for (index = 0; index < pEventGroup->totalCounters; index++) {
        perfEvent = pSM->sigtable[index]->perfEvent;
        for(smcntr_idx = pSM->start[index] ; smcntr_idx < (pSM->start[index] + pSM->bitCount[index]) ; smcntr_idx++) {
            valueA  = HWVALUE(90C0, SET_SHADER_PERFORMANCE_COUNTER_CONTROL_A,    EVENT0,         smcntr_idx);
            valueA |= HWVALUE(90C0, SET_SHADER_PERFORMANCE_COUNTER_CONTROL_A,    BIT_SELECT0,    (perfEvent & 0x00000007));
            valueA |= HWVALUE(90C0, SET_SHADER_PERFORMANCE_COUNTER_CONTROL_A,    EVENT1,         smcntr_idx);
            valueA |= HWVALUE(90C0, SET_SHADER_PERFORMANCE_COUNTER_CONTROL_A,    BIT_SELECT1,    (perfEvent & 0x00000070)>>4);
            valueA |= HWVALUE(90C0, SET_SHADER_PERFORMANCE_COUNTER_CONTROL_A,    EVENT2,         smcntr_idx);
            valueA |= HWVALUE(90C0, SET_SHADER_PERFORMANCE_COUNTER_CONTROL_A,    BIT_SELECT2,    (perfEvent & 0x00000700)>>8);
            valueA |= HWVALUE(90C0, SET_SHADER_PERFORMANCE_COUNTER_CONTROL_A,    EVENT3,         smcntr_idx);
            valueA |= HWVALUE(90C0, SET_SHADER_PERFORMANCE_COUNTER_CONTROL_A,    BIT_SELECT3,    (perfEvent & 0x00007000)>>12);

            NV_PUSH_1U(90C0, SET_SHADER_PERFORMANCE_COUNTER_CONTROL_A(smcntr_idx),  valueA);
            perfEvent++;
        }
    }
    streamEndPush(pEventGroup->pCtx->barrierStream, nvCurrent, NULL);
    }

EXIT:
    if(offset) {
        free(offset);
    }
    if(value) {
        free(value);
    }
    return status;
}

static CUresult resetPMSMInternal(CUeventGroup *pEventGroup) {
    CUresult status = CUDA_SUCCESS;
    NvU32 gpcTarget = 0, tpcTarget = 0, count = 0, gpcId = 0, tpcId = 0, smId = 0;
    NvU32 *offset;
    NvU32 *value;

    CU_TRACE_FUNCTION();
    offset = (NvU32 *)malloc(CU_PROF_PM_SM_MAX_COUNTERS * pEventGroup->instanceCountAvail * sizeof(NvU32));
    value = (NvU32 *)calloc(CU_PROF_PM_SM_MAX_COUNTERS * pEventGroup->instanceCountAvail, sizeof(NvU32));
    if(!(offset && value)) {
        CU_ERROR_PRINT(("Error allocating memory for offset-value arrays.\n"));
        status = (CUresult)CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    for(gpcId = 0; gpcId < pEventGroup->arch.fermiEventGroup->gpcCount; gpcId++)
    {
        for(tpcId = 0; tpcId < pEventGroup->arch.fermiEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
        {
            if(pEventGroup->arch.fermiEventGroup->pmUnitMask & (1<<smId))
            {

                gpcTarget = gpcId;
                tpcTarget = tpcId;

                offset[count++]  = NV_SM_DSM_PERF_COUNTER0(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER1(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER2(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER3(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER4(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER5(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER6(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER7(gpcTarget, tpcTarget);
            }
            smId++;
        }
    }

    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, count, offset, value, 0);

EXIT:
    if(offset) {
        free(offset);
    }
    if(value) {
        free(value);
    }
    return status;
}

void fermiPerfmonStartCounters(CUnvCurrent** nvCurrent_temp, CUeventGroup *pEventGroup)
{
    // Set the function values only if domanin = SMPerf
    if((pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_SMPERF) ||
       (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW) ||
       (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW))
    {
        if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_KERNEL) {
            NvU32 valueA = 0;
            CUSMCtrInfo     *pSM = NULL;
            unsigned int index, smcntr_idx;
            CUnvCurrent* nvCurrent = *nvCurrent_temp;

            pSM = pEventGroup->arch.fermiEventGroup->pSM;
            for(index = 0; index < pEventGroup->totalCounters; index++){
                for(smcntr_idx = pSM->start[index] ;
                    smcntr_idx < (pSM->start[index] + pSM->bitCount[index]) ; smcntr_idx++) {
                    // Zero out the counter values before starting the counters:
                    valueA = HWVALUE(90C0, SET_SHADER_PERFORMANCE_COUNTER_VALUE, V, 0);
                    NV_PUSH_1U(90C0, SET_SHADER_PERFORMANCE_COUNTER_VALUE(smcntr_idx),  valueA);
                    // Set function values:
                    valueA = HWVALUE(90C0, SET_SHADER_PERFORMANCE_COUNTER_CONTROL_B,    FUNC,         pSM->sigtable[index]->function);
                    NV_PUSH_1U(90C0, SET_SHADER_PERFORMANCE_COUNTER_CONTROL_B(smcntr_idx),  valueA);
                }
            }
            *nvCurrent_temp = nvCurrent;
        } else if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS){
            NvU32 *value  = NULL, *offset = NULL;
            NvU32 count = 0, gpcId = 0, tpcId = 0, smId = 0;
            NvU32 smcntr_idx = 0, index = 0, func[4] = {0};
            CUresult status = CUDA_SUCCESS;
            CUSMCtrInfo *pSM = NULL;

            //Allocate memory of size = (4 * #SMs * sizeof(NvU32))
            offset = (NvU32 *)malloc(4 * pEventGroup->instanceCountAvail * sizeof(NvU32));
            value = (NvU32 *)calloc(4 * pEventGroup->instanceCountAvail, sizeof(NvU32));
            if(!(offset && value)) {
                CU_ERROR_PRINT(("Error allocating memory for offset-value arrays.\n"));
                status = (CUresult)CUPROF_ERROR_OUT_OF_MEMORY;
                goto EXIT;
            }
            pSM = pEventGroup->arch.fermiEventGroup->pSM;
            for(gpcId = 0; gpcId < pEventGroup->arch.fermiEventGroup->gpcCount; gpcId++)
            {
                for(tpcId = 0; tpcId < pEventGroup->arch.fermiEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
                {
                    if(pEventGroup->arch.fermiEventGroup->pmUnitMask & (1<<smId))
                    {
                        for (index = 0; index < pEventGroup->totalCounters; index++) {
                            for(smcntr_idx = pSM->start[index] ; smcntr_idx < (pSM->start[index] + pSM->bitCount[index]) ; smcntr_idx++) {
                                if(smcntr_idx & 1)
                                    func[smcntr_idx>>1] |= pSM->sigtable[index]->function << 16;
                                else
                                    func[smcntr_idx>>1] |= pSM->sigtable[index]->function;
                            }
                        }
                        offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL1(gpcId, tpcId);
                        value[count++] = func[0];
                        offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL2(gpcId, tpcId);
                        value[count++] = func[1];
                        offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL3(gpcId, tpcId);
                        value[count++] = func[2];
                        offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL4(gpcId, tpcId);
                        value[count++] = func[3];
                    }
                    smId++;
                }
            }
            CU_ASSERT(count <= (4 * pEventGroup->instanceCountAvail));
            status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, count, offset, value, 0);
            CU_ASSERT(status == CUDA_SUCCESS);
EXIT:
            if(offset)
                free(offset);
            if(value)
                free(value);
        }
    }
}

void fermiPerfmonStopCounters(CUnvCurrent** nvCurrent_temp, CUeventGroup *pEventGroup)
{
    // Reset the function values only if domanin = SMPerf
    if((pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_SMPERF) ||
       (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW) ||
       (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW)) {
        if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_KERNEL) {
            CUnvCurrent* nvCurrent = *nvCurrent_temp;
            NvU32 valueA = 0;
            unsigned int index, smcntr_idx;
            CUSMCtrInfo     *pSM = NULL;
            pSM = pEventGroup->arch.fermiEventGroup->pSM;
            for(index = 0; index < pEventGroup->totalCounters; index++){
                for(smcntr_idx = pSM->start[index] ;
                smcntr_idx < (pSM->start[index] + pSM->bitCount[index]) ; smcntr_idx++) {
                    valueA = HWVALUE(90C0, SET_SHADER_PERFORMANCE_COUNTER_CONTROL_B,    FUNC,         0);
                    NV_PUSH_1U(90C0, SET_SHADER_PERFORMANCE_COUNTER_CONTROL_B(smcntr_idx),  valueA);
                }
            }
            *nvCurrent_temp = nvCurrent;
        } else {

            //Stop the counters in continuous mode. SM counters keep running unless we set the func to 0.
            NvU32 *value  = NULL, *offset = NULL;
            NvU32 count = 0, gpcId = 0, tpcId = 0, smId = 0;
            CUresult status = CUDA_SUCCESS;

            //Allocate memory of size = (4 * #SMs * sizeof(NvU32))
            offset = (NvU32 *)malloc(4 * pEventGroup->instanceCountAvail * sizeof(NvU32));
            value = (NvU32 *)calloc(4 * pEventGroup->instanceCountAvail, sizeof(NvU32));
            if(!(offset && value)) {
                CU_ERROR_PRINT(("Error allocating memory for offset-value arrays.\n"));
                status = (CUresult)CUPROF_ERROR_OUT_OF_MEMORY;
                goto EXIT;
            }
            for(gpcId = 0; gpcId < pEventGroup->arch.fermiEventGroup->gpcCount; gpcId++)
            {
                for(tpcId = 0; tpcId < pEventGroup->arch.fermiEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
                {
                    if(pEventGroup->arch.fermiEventGroup->pmUnitMask & (1<<smId))
                    {
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_CONTROL1(gpcId, tpcId);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_CONTROL2(gpcId, tpcId);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_CONTROL3(gpcId, tpcId);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_CONTROL4(gpcId, tpcId);
                    }
                    smId++;
                }
            }
            CU_ASSERT(count <= (4 * pEventGroup->instanceCountAvail));
            status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, count, offset, value, 0);
            CU_ASSERT(status == CUDA_SUCCESS);
EXIT:
            if(offset)
                free(offset);
            if(value)
                free(value);
        }
    }
}

static CUresult logPMCountersSMInternal(CUeventGroup *pEventGroup) {
    CUresult status = CUDA_SUCCESS;
    NvU32 gpcId = 0, tpcId = 0, smId = 0;
    NvU32 offset[8] = {0};

    CU_TRACE_FUNCTION();

    for(gpcId = 0; gpcId < pEventGroup->arch.fermiEventGroup->gpcCount; gpcId++)
    {
        for(tpcId = 0; tpcId < pEventGroup->arch.fermiEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
        {
            if(pEventGroup->arch.fermiEventGroup->pmUnitMask & (1<<smId))
            {

                // read back perf counter values
                offset[0]  = NV_SM_DSM_PERF_COUNTER0(gpcId, tpcId);
                offset[1]  = NV_SM_DSM_PERF_COUNTER1(gpcId, tpcId);
                offset[2]  = NV_SM_DSM_PERF_COUNTER2(gpcId, tpcId);
                offset[3]  = NV_SM_DSM_PERF_COUNTER3(gpcId, tpcId);
                offset[4]  = NV_SM_DSM_PERF_COUNTER4(gpcId, tpcId);
                offset[5]  = NV_SM_DSM_PERF_COUNTER5(gpcId, tpcId);
                offset[6]  = NV_SM_DSM_PERF_COUNTER6(gpcId, tpcId);
                offset[7]  = NV_SM_DSM_PERF_COUNTER7(gpcId, tpcId);

                //TBD write to a proper output record
                status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, pEventGroup->arch.fermiEventGroup->pSM->SMCountersAdded, offset, (pEventGroup->arch.fermiEventGroup->pSM->values + pEventGroup->arch.fermiEventGroup->pSM->SMCountersAdded * smId), 0);

                if (CUDA_SUCCESS != status) {
                    goto EXIT;
                }
            }
            smId++;
        }
    }

EXIT:
    return status;
}
