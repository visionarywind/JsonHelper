/*
* Copyright 1993-2009 by NVIDIA Corporation.  All rights reserved.  All
* information contained herein is proprietary and confidential to NVIDIA
* Corporation.  Any use, reproduction, or disclosure without the written
* permission of NVIDIA Corporation is prohibited.
*/

/******************************************************************************
*
*   Module: kepelr_signals.c
*
*   Description:
*       maxwell specific signals information
*
******************************************************************************/

#include "maxwell_perfmon_new.h"
#include "perfmon_new.h"
#include "maxwell_signals.h"
#include "maxwell_signals_strings.h"

//TBD Check for all watchbus and PM ENABLE and group registers
PerfUnitTable PerfUnitTableGM000[] = {
// Unit-name                 PM enable                       GroupSel              maxGroups
//                      register  start end val        register  start end width
// smquick has different regiser width for group selection
{PM_UNIT_SMCORE,   {0x00000600,   7,  7, 1},       {0x00000600,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
{PM_UNIT_SMQCTL,   {0x00000600,  15, 15, 1},       {0x00000600,  8, 14,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
{PM_UNIT_MIO,      {0x00000600,  23, 23, 1},       {0x00000600, 16, 22,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// SM  - watch buses from 32 to 39 (decimal) are assigned to SMK2PM_GPCTPC#TPC_MUXED_BUS_LOWER_0_#
// SM  - watch buses from 40 to 47 (decimal) are assigned to SMK2PM_GPCTPC#TPC_MUXED_BUS_UPPER_0_#
{PM_UNIT_MPC,      {0x0000040c,  31, 31, 1},       {0x0000040c,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// MPC - watch buses from 32 to 40 (decimal) are assigned to MPC2PM_MUXED_BUS_#
{PM_UNIT_TEX_S,      {0x000002b0,  31, 31, 1},       {0x000002b0,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_T,      {0x000002b8,  31, 31, 1},       {0x000002b8,  0,  2,  3},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_T1,      {0x000002b8,  31, 31, 1},       {0x000002b8,  3,  7,  5},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_T2,      {0x000002b8,  31, 31, 1},       {0x000002b8,  8,  10,  3},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_T3,      {0x000002b8,  31, 31, 1},       {0x000002b8,  11,  15,  5},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_D,      {0x000002bc,  31, 31, 1},       {0x000002bc,  0,  5,  6},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_M,      {0x000002c0,  31, 31, 1},       {0x000002C0,  0,  5,  6},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_M1,      {0x000002c0,  31, 31, 1},       {0x000002C0,  8,  11,  4},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},

//Add unit for each L2 slice, this way we can set each slice independently
{PM_UNIT_LTS,      {0x00000150,   0,  0, 1},       {0x00000150,  1,  3,  3},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE},
{PM_UNIT_LTS1,     {0x00000150,   0,  0, 1},       {0x00000150,  4,  8,  5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE},
{PM_UNIT_LTS2,     {0x00000150,   0,  0, 1},       {0x00000150,  9,  13, 5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE},

{PM_UNIT_LTS_1,      {(0x00000150 + (NV_PLTS_STRIDE *1)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *1)),  1,  3,  3},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},
{PM_UNIT_LTS1_1,     {(0x00000150 + (NV_PLTS_STRIDE *1)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *1)),  4,  8,  5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},
{PM_UNIT_LTS2_1,     {(0x00000150 + (NV_PLTS_STRIDE *1)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *1)),  9,  13, 5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},

{PM_UNIT_LTS_2,      {(0x00000150 + (NV_PLTS_STRIDE *2)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *2)),  1,  3,  3},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},
{PM_UNIT_LTS1_2,     {(0x00000150 + (NV_PLTS_STRIDE *2)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *2)),  4,  8,  5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},
{PM_UNIT_LTS2_2,     {(0x00000150 + (NV_PLTS_STRIDE *2)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *2)),  9,  13, 5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},

{PM_UNIT_LTS_3,      {(0x00000150 + (NV_PLTS_STRIDE *3)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *3)),  1,  3,  3},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},
{PM_UNIT_LTS1_3,     {(0x00000150 + (NV_PLTS_STRIDE *3)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *3)),  4,  8,  5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},
{PM_UNIT_LTS2_3,     {(0x00000150 + (NV_PLTS_STRIDE *3)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *3)),  9,  13, 5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},

{PM_UNIT_LTC,      {0x00000028,   0,  0, 1},       {0x00000028,  1,  2,  2},  1, (NV_PLTCG_BASE),         NV_PLTCG_STRIDE,   0},
// LTC - watch buses from 12 to 15 (decimal) are assigned to LTC2PM_LTC_SECTOR_MUXED_BUS_#
{PM_UNIT_LTC1,     {0x00000028,   0,  0, 1},       {0x00000028,  3,  5,  3},  1, (NV_PLTCG_BASE),         NV_PLTCG_STRIDE,   0},
// LTC1 - watch buses from 17 to 42 (decimal) are assigned to LTC2PM_LTC_MUXED_BUS_#
{PM_UNIT_LTC2,     {0x00000028,   0,  0, 1},       {0x00000028,  6,  7,  2},  1, (NV_PLTCG_BASE),         NV_PLTCG_STRIDE,   0},
// LTC2 - watch buses from 16      (decimal) are assigned to LTC2PM_LTC_SRCUNIT_MUXED_BUS
// LTC5 - watch buses from 32 to 57(decimal) are assigned to LTC2PM_LTC_EXTENDED_MUXED_BUS_#
{PM_UNIT_FB,       {0x00000100,   0,  0, 1},       {0x00000100,   4,  10, 7},      1, NV_FBPA_PRI_BASE,                 NV_FBPA_PRI_STRIDE,0},
//FB - mwatch buses from 15 to 26(decimal) are assigned to FBPA2PM_LTC_FB_PERF_MUXED_BUS_#
{PM_UNIT_HUBMMU,   {0x00100C84,  31, 31, 1},       {0x00100C84,   0,  7, 8},  1, 0, 0, 0},
// HUBMMU - watch buses from 5 to 8(decimal) are assigned to HUBMMU2PM_HUB_MUXED_BUS_#
{PM_UNIT_HUBMMU,   {0x00100C84,  31, 31, 1},       {0x00100C84,   30,  30, 1},  1, 0, 0, 0},
// HUBMMU - watch buses from 5 to 8(decimal) are assigned to HUBMMU2PM_HUB_MUXED_BUS_#
// TODO: add other units here
{PM_UNIT_MAX                                                                          }
};

PerfUnitTable PerfUnitTableGM200[] = {
#if NVCFG(GLOBAL_GPU_FAMILY_GM20X)
// Unit-name                 PM enable                       GroupSel              maxGroups
//                      register  start end val        register  start end width
// smquick has different regiser width for group selection
{PM_UNIT_SMCORE,   {0x00000600,   7,  7, 1},       {0x00000600,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
{PM_UNIT_SMQCTL,   {0x00000600,  15, 15, 1},       {0x00000600,  8, 14,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
{PM_UNIT_MIO,      {0x00000600,  23, 23, 1},       {0x00000600, 16, 22,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// SM  - watch buses from 32 to 39 (decimal) are assigned to SMK2PM_GPCTPC#TPC_MUXED_BUS_LOWER_0_#
// SM  - watch buses from 40 to 47 (decimal) are assigned to SMK2PM_GPCTPC#TPC_MUXED_BUS_UPPER_0_#
{PM_UNIT_MPC,      {0x0000040c,  31, 31, 1},       {0x0000040c,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// MPC - watch buses from 32 to 40 (decimal) are assigned to MPC2PM_MUXED_BUS_#
{PM_UNIT_TEX_S,      {0x000002b0,  31, 31, 1},       {0x000002b0,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_T,      {0x000002b8,  31, 31, 1},       {0x000002b8,  0,  2,  3},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_T1,      {0x000002b8,  31, 31, 1},       {0x000002b8,  3,  7,  5},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_T2,      {0x000002b8,  31, 31, 1},       {0x000002b8,  8,  10,  3},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_T3,      {0x000002b8,  31, 31, 1},       {0x000002b8,  11,  17,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_D,      {0x000002bc,  31, 31, 1},       {0x000002bc,  0,  5,  6},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_M,      {0x000002c0,  31, 31, 1},       {0x000002C0,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_M1,      {0x000002c0,  31, 31, 1},       {0x000002C0,  8,  11,  4},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},

//Add unit for each L2 slice, this way we can set each slice independently
{PM_UNIT_LTS,      {0x00000150,   0,  0, 1},       {0x00000150,  1,  3,  3},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE},
{PM_UNIT_LTS1,     {0x00000150,   0,  0, 1},       {0x00000150,  4,  8,  5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE},
{PM_UNIT_LTS2,     {0x00000150,   0,  0, 1},       {0x00000150,  9,  13, 5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE},

{PM_UNIT_LTS_1,      {(0x00000150 + (NV_PLTS_STRIDE *1)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *1)),  1,  3,  3},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},
{PM_UNIT_LTS1_1,     {(0x00000150 + (NV_PLTS_STRIDE *1)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *1)),  4,  8,  5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},
{PM_UNIT_LTS2_1,     {(0x00000150 + (NV_PLTS_STRIDE *1)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *1)),  9,  13, 5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},

{PM_UNIT_LTS_2,      {(0x00000150 + (NV_PLTS_STRIDE *2)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *2)),  1,  3,  3},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},
{PM_UNIT_LTS1_2,     {(0x00000150 + (NV_PLTS_STRIDE *2)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *2)),  4,  8,  5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},
{PM_UNIT_LTS2_2,     {(0x00000150 + (NV_PLTS_STRIDE *2)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *2)),  9,  13, 5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},

{PM_UNIT_LTS_3,      {(0x00000150 + (NV_PLTS_STRIDE *3)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *3)),  1,  3,  3},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},
{PM_UNIT_LTS1_3,     {(0x00000150 + (NV_PLTS_STRIDE *3)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *3)),  4,  8,  5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},
{PM_UNIT_LTS2_3,     {(0x00000150 + (NV_PLTS_STRIDE *3)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *3)),  9,  13, 5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},

{PM_UNIT_LTC,      {0x00000028,   0,  0, 1},       {0x00000028,  1,  2,  2},  1, (NV_PLTCG_BASE),         NV_PLTCG_STRIDE,   0},
// LTC - watch buses from 12 to 15 (decimal) are assigned to LTC2PM_LTC_SECTOR_MUXED_BUS_#
{PM_UNIT_LTC1,     {0x00000028,   0,  0, 1},       {0x00000028,  3,  5,  3},  1, (NV_PLTCG_BASE),         NV_PLTCG_STRIDE,   0},
// LTC1 - watch buses from 17 to 42 (decimal) are assigned to LTC2PM_LTC_MUXED_BUS_#
{PM_UNIT_LTC2,     {0x00000028,   0,  0, 1},       {0x00000028,  6,  7,  2},  1, (NV_PLTCG_BASE),         NV_PLTCG_STRIDE,   0},
// LTC2 - watch buses from 16      (decimal) are assigned to LTC2PM_LTC_SRCUNIT_MUXED_BUS
// LTC5 - watch buses from 32 to 57(decimal) are assigned to LTC2PM_LTC_EXTENDED_MUXED_BUS_#
{PM_UNIT_FB,       {0x00000100,   0,  0, 1},       {0x00000100,   4,  10, 7},      1, NV_FBPA_PRI_BASE,                 NV_FBPA_PRI_STRIDE,0},
//FB - mwatch buses from 15 to 26(decimal) are assigned to FBPA2PM_LTC_FB_PERF_MUXED_BUS_#
{PM_UNIT_HUBMMU,   {0x00100C84,  31, 31, 1},       {0x00100C84,   0,  7, 8},  1, 0, 0, 0},
// HUBMMU - watch buses from 5 to 8(decimal) are assigned to HUBMMU2PM_HUB_MUXED_BUS_#
{PM_UNIT_HUBMMU,   {0x00100C84,  31, 31, 1},       {0x00100C84,   30,  30, 1},  1, 0, 0, 0},
// SKED
{PM_UNIT_SKED,   {0x00407010,  31, 31, 1},       {0x00407010,   0,  6, 7},  1, 0, 0, 0},
// HUBMMU - watch buses from 5 to 8(decimal) are assigned to HUBMMU2PM_HUB_MUXED_BUS_#

// Units added for PCI counter profiling
{PM_UNIT_XVE1,     {0x000884f4,  31, 31, 1 },      {0x000884f4,  0, 4, 5 },  1, 0, 0, 0 },
{PM_UNIT_XVE2,     {0x000884f4,  31, 31, 1 },      {0x000884f4,  5, 9, 5 },  1, 0, 0, 0 },
#endif /* NVCFG(GLOBAL_GPU_FAMILY_GM20X) */
// TODO: add other units here
{PM_UNIT_MAX                                                                          }
};

// Perf signal table for maxwell
// perf-event: signal0 - 2:0, signal1 - 6:4, signal2 - 10:8, signal3 - 14:12
// Some sigmals are commented and not removed so that they can be used for testing purpose in future.
PerfSignalHwpm PerfSignalTableGM000_gpc0[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type
    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpmMux PerfSignalTableGM000_hwpmmux[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type

#if CU_MAXWELL_PROFILE_SM_SIGNALS_VIA_HWPM
    // ########### SM Unit ###########
    // ***LAUNCHED***
    // sch_warps_launched               SM has launched 1 warp
    // sch_threads_launched             number of threads SM launched this cycle
    //TBD check with latest files, threads_launched watchbus looks incorrect
    {MAXWELL_HWPMMUX_WARPS_LAUNCHED, maxwell_hwpmmux_warps_launched_enc_str_1, 0x1, 0xaaaa, 0x1d, PM_UNIT_SMQCTL, 1, 13},
    {MAXWELL_HWPMMUX_THREADS_LAUNCHED, maxwell_hwpmmux_threads_launched_enc_str_1, 0x16, 0xffff, 0x10, PM_UNIT_SMQCTL, 6, 0},
    {MAXWELL_HWPMMUX_ACTIVE_CYCLES, maxwell_hwpmmux_active_cycles_enc_str_1, 0x1, 0xaaaa, 0x1, PM_UNIT_SMCORE, 1, 1},
    {MAXWELL_HWPMMUX_ACTIVE_WARPS, maxwell_hwpmmux_active_warps_enc_str_1, 0x1, 0xffff, 0x2, PM_UNIT_SMCORE, 6, 2},
    {MAXWELL_HWPMMUX_CTA_LAUNCHED, maxwell_hwpmmux_cta_launched_enc_str_1, 0x6, 0xaaaa, 0x1, PM_UNIT_SMCORE, 1, 1},
    {MAXWELL_HWPMMUX_SHARED_LD_MEM_DIVERGENCE_REPLAYS, maxwell_hwpmmux_shared_ld_mem_divergence_replays_enc_str_1, 0x00000007, 0xaaaa, 0x00000050, PM_UNIT_MIO, 1 ,0 },
    {MAXWELL_HWPMMUX_SHARED_ST_MEM_DIVERGENCE_REPLAYS, maxwell_hwpmmux_shared_st_mem_divergence_replays_enc_str_1, 0x00000007, 0xaaaa, 0x00000051, PM_UNIT_MIO, 1 ,1 },
    {MAXWELL_HWPMMUX_SHARED_LD_TRANSACTIONS,           maxwell_hwpmmux_shared_ld_transactions_enc_str_1,           0x00000007, 0xaaaa, 0x00000052, PM_UNIT_MIO, 1 ,2 },
    {MAXWELL_HWPMMUX_SHARED_ST_TRANSACTIONS,           maxwell_hwpmmux_shared_st_transactions_enc_str_1,           0x00000007, 0xaaaa, 0x00000053, PM_UNIT_MIO, 1 ,3 },
#endif
    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};
// Perf signal table for maxwell
// perf-event: signal0 - 2:0, signal1 - 6:4, signal2 - 10:8, signal3 - 14:12
// Some sigmals are commented and not removed so that they can be used for testing purpose in future.
PerfSignalHwpm PerfSignalTableGM000_gpctpc[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type

#if CU_MAXWELL_PROFILE_SM_SIGNALS_VIA_HWPM
    // ########### SM Unit ###########
    // ***LAUNCHED***
    // sch_warps_launched               SM has launched 1 warp
    // sch_threads_launched             number of threads SM launched this cycle
    //TBD check with latest files, threads_launched watchbus looks incorrect
    {MAXWELL_HWPM_WARPS_LAUNCHED_0, maxwell_hwpm_warps_launched_0_enc_str_1, 0x1, 0xaaaa, 0x1d, PM_UNIT_SMQCTL, 1},
    {MAXWELL_HWPM_WARPS_LAUNCHED_1, maxwell_hwpm_warps_launched_1_enc_str_1, 0x1, 0xaaaa, 0x2d, PM_UNIT_SMQCTL, 1},
    {MAXWELL_HWPM_WARPS_LAUNCHED_2, maxwell_hwpm_warps_launched_2_enc_str_1, 0x1, 0xaaaa, 0x3d, PM_UNIT_SMQCTL, 1},
    {MAXWELL_HWPM_WARPS_LAUNCHED_3, maxwell_hwpm_warps_launched_3_enc_str_1, 0x1, 0xaaaa, 0x4d, PM_UNIT_SMQCTL, 1},
    {MAXWELL_HWPM_THREADS_LAUNCHED_0, maxwell_hwpm_threads_launched_0_enc_str_1, 0x16, 0xffff, 0x10, PM_UNIT_SMQCTL, 6},
    {MAXWELL_HWPM_THREADS_LAUNCHED_1, maxwell_hwpm_threads_launched_1_enc_str_1, 0x16, 0xffff, 0x20, PM_UNIT_SMQCTL, 6},
    {MAXWELL_HWPM_THREADS_LAUNCHED_2, maxwell_hwpm_threads_launched_2_enc_str_1, 0x16, 0xffff, 0x30, PM_UNIT_SMQCTL, 6},
    {MAXWELL_HWPM_THREADS_LAUNCHED_3, maxwell_hwpm_threads_launched_3_enc_str_1, 0x16, 0xffff, 0x40, PM_UNIT_SMQCTL, 6},

    {MAXWELL_HWPM_INST_EXECUTED_TEX_OPS_Q0, maxwell_hwpm_inst_executed_tex_ops_q0_enc_str_1, 0xf, 0xaaaa, 0x1e, PM_UNIT_SMQCTL, 1},
    {MAXWELL_HWPM_INST_EXECUTED_TEX_OPS_Q1, maxwell_hwpm_inst_executed_tex_ops_q1_enc_str_1, 0xf, 0xaaaa, 0x2e, PM_UNIT_SMQCTL, 1},
    {MAXWELL_HWPM_INST_EXECUTED_TEX_OPS_Q2, maxwell_hwpm_inst_executed_tex_ops_q2_enc_str_1, 0xf, 0xaaaa, 0x3e, PM_UNIT_SMQCTL, 1},
    {MAXWELL_HWPM_INST_EXECUTED_TEX_OPS_Q3, maxwell_hwpm_inst_executed_tex_ops_q3_enc_str_1, 0xf, 0xaaaa, 0x4e, PM_UNIT_SMQCTL, 1},

    {MAXWELL_HWPM_ACTIVE_CYCLES, maxwell_hwpm_active_cycles_enc_str_1, 0x1, 0xaaaa, 0x1, PM_UNIT_SMCORE, 1},
    {MAXWELL_HWPM_ACTIVE_WARPS, maxwell_hwpm_active_warps_enc_str_1, 0x1, 0xffff, 0x2, PM_UNIT_SMCORE, 6},
    {MAXWELL_HWPM_CTA_LAUNCHED, maxwell_hwpm_cta_launched_enc_str_1, 0x6, 0xaaaa, 0x1, PM_UNIT_SMCORE, 1},
    {MAXWELL_HWPM_SHARED_LD_MEM_DIVERGENCE_REPLAYS, maxwell_hwpm_shared_ld_mem_divergence_replays_enc_str_1, 0x00000007, 0xaaaa, 0x00000050, PM_UNIT_MIO, 1},
    {MAXWELL_HWPM_SHARED_ST_MEM_DIVERGENCE_REPLAYS, maxwell_hwpm_shared_st_mem_divergence_replays_enc_str_1, 0x00000007, 0xaaaa, 0x00000051, PM_UNIT_MIO, 1},
    {MAXWELL_HWPM_SHARED_LD_TRANSACTIONS,           maxwell_hwpm_shared_ld_transactions_enc_str_1,           0x00000007, 0xaaaa, 0x00000052, PM_UNIT_MIO, 1},
    {MAXWELL_HWPM_SHARED_ST_TRANSACTIONS,           maxwell_hwpm_shared_st_transactions_enc_str_1,           0x00000007, 0xaaaa, 0x00000053, PM_UNIT_MIO, 1},
#endif
    //mpc signals
    //ctas_launched is doubtful. watchbus is 7e? On emulator 7d is working
    {MAXWELL_MPC_CTAS_LAUNCHED, maxwell_mpc_ctas_launched_enc_str_1, 0xf, 0xaaaa, 0x7d, PM_UNIT_MPC, 1},
    {MAXWELL_MPC_THREADS_LAUNCHED, maxwell_mpc_threads_launched_enc_str_1, 0x10, 0xffff, 0x77, PM_UNIT_MPC, 6},
    {MAXWELL_MPC_WARPS_IN_FLIGHT, maxwell_mpc_warps_in_flight_enc_str_1, 0x42, 0xffff, 0x77, PM_UNIT_MPC, 7},
    {MAXWELL_MPC_COMPUTE_CTAS_IN_FLIGHT, maxwell_mpc_compute_ctas_in_flight_enc_str_1, 0x46, 0xffff, 0x77, PM_UNIT_MPC, 5},

    //Tex signals
    // based on experiments - tex_cache_misses_gpc0_tpc0_tex0 and tex_cache_sector_queries_gpc0_tpc0_tex0
    // defined in \\hw\tools\perfalyze\chips\gm107\pml_files\tex.pml
    //tex0_cache_lg_sector_queries  = tex02pm_gpc_t_lg_sector_queries
    //tex0_cache_lg_sector_misses   = tex02pm_gpc_t_lg_missed_sectors
    //tex1_cache_lg_sector_queries = tex12pm_gpc_t_lg_sector_queries
    //tex1_cache_lg_sector_misses  = tex12pm_gpc_t_lg_missed_sectors

    {MAXWELL_TEX0_LG_SECTOR_QUERIES, maxwell_tex0_lg_sector_queries_enc_str_1, 0x1b, 0xffff, 0x84, PM_UNIT_TEX_M, 4},
    {MAXWELL_TEX1_LG_SECTOR_QUERIES, maxwell_tex1_lg_sector_queries_enc_str_1, 0x1b, 0xffff, 0x70, PM_UNIT_TEX_M, 4},
    {MAXWELL_TEX0_LG_MISSED_SECTORS, maxwell_tex0_lg_missed_sectors_enc_str_1, 0x1b, 0xffff, 0x80, PM_UNIT_TEX_M, 4},
    {MAXWELL_TEX1_LG_MISSED_SECTORS, maxwell_tex1_lg_missed_sectors_enc_str_1, 0x1b, 0xffff, 0x6c, PM_UNIT_TEX_M, 4},

    //tex0_cache_sector_queries  = tex02pm_gpc_t_sector_queries
    //tex0_cache_sector_misses   = tex02pm_gpc_t_missed_sectors
    //tex1_cache_sector_queries = tex12pm_gpc_t_sector_queries
    //tex1_cache_sector_misses  = tex12pm_gpc_t_missed_sectors
    {MAXWELL_TEX0_SECTOR_QUERIES, maxwell_tex0_sector_queries_enc_str_1, 0x5, 0xffff, 0x84, PM_UNIT_TEX_M, 5},
    {MAXWELL_TEX1_SECTOR_QUERIES, maxwell_tex1_sector_queries_enc_str_1, 0x5, 0xffff, 0x70, PM_UNIT_TEX_M, 5},
    {MAXWELL_TEX0_MISSED_SECTORS, maxwell_tex0_missed_sectors_enc_str_1, 0x4, 0xffff, 0x80, PM_UNIT_TEX_M, 5},
    {MAXWELL_TEX1_MISSED_SECTORS, maxwell_tex1_missed_sectors_enc_str_1, 0x4, 0xffff, 0x6c, PM_UNIT_TEX_M, 5},

    {MAXWELL_TEX0_MISSED_SECTORS_ANY, maxwell_tex0_missed_sectors_any_enc_str_1, 0x4, 0xaaaa, 0x85, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_MISSED_SECTORS_ANY, maxwell_tex1_missed_sectors_any_enc_str_1, 0x4, 0xaaaa, 0x71, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_COALESCED_SECTORS, maxwell_tex0_coalesced_sectors_enc_str_1, 0x5, 0xffff, 0x80, PM_UNIT_TEX_M, 4},
    {MAXWELL_TEX1_COALESCED_SECTORS, maxwell_tex1_coalesced_sectors_enc_str_1, 0x5, 0xffff, 0x6c, PM_UNIT_TEX_M, 4},

    {MAXWELL_TEX0_CACHED_GLOBAL_LD_REQUESTS, maxwell_tex0_cached_global_ld_requests_enc_str_1, 0x40, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_CACHED_GLOBAL_LD_REQUESTS, maxwell_tex1_cached_global_ld_requests_enc_str_1, 0x40, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_GLOBAL_LD_REQUESTS, maxwell_tex0_global_ld_requests_enc_str_1, 0x40, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_GLOBAL_LD_REQUESTS, maxwell_tex1_global_ld_requests_enc_str_1, 0x40, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_UNCACHED_GLOBAL_LD_REQUESTS, maxwell_tex0_uncached_global_ld_requests_enc_str_1, 0x40, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_UNCACHED_GLOBAL_LD_REQUESTS, maxwell_tex1_uncached_global_ld_requests_enc_str_1, 0x40, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},

    {MAXWELL_TEX0_LOCAL_LD_REQUESTS, maxwell_tex0_local_ld_requests_enc_str_1, 0x43, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_LOCAL_LD_REQUESTS, maxwell_tex1_local_ld_requests_enc_str_1, 0x43, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_CACHED_LOCAL_LD_REQUESTS, maxwell_tex0_cached_local_ld_requests_enc_str_1, 0x43, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_CACHED_LOCAL_LD_REQUESTS, maxwell_tex1_cached_local_ld_requests_enc_str_1, 0x43, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_UNCACHED_LOCAL_LD_REQUESTS, maxwell_tex0_uncached_local_ld_requests_enc_str_1, 0x43, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_UNCACHED_LOCAL_LD_REQUESTS, maxwell_tex1_uncached_local_ld_requests_enc_str_1, 0x43, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},

    {MAXWELL_TEX0_CACHED_GLOBAL_LD_HITS, maxwell_tex0_cached_global_ld_hits_enc_str_1, 0x12, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_CACHED_GLOBAL_LD_HITS, maxwell_tex1_cached_global_ld_hits_enc_str_1, 0x12, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_CACHED_GLOBAL_LD_MISSES, maxwell_tex0_cached_global_ld_misses_enc_str_1, 0x12, 0xffff, 0x84, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_CACHED_GLOBAL_LD_MISSES, maxwell_tex1_cached_global_ld_misses_enc_str_1, 0x12, 0xffff, 0x70, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_UNCACHED_GLOBAL_LD_MISSES, maxwell_tex0_uncached_global_ld_misses_enc_str_1, 0x16, 0xffff, 0x84, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_UNCACHED_GLOBAL_LD_MISSES, maxwell_tex1_uncached_global_ld_misses_enc_str_1, 0x16, 0xffff, 0x70, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_GLOBAL_LD_HITS, maxwell_tex0_global_ld_hits_enc_str_1, 0x11, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_LD_HITS, maxwell_tex1_global_ld_hits_enc_str_1, 0x11, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_LD_MISSES, maxwell_tex0_global_ld_misses_enc_str_1, 0x11, 0xffff, 0x84, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_LD_MISSES, maxwell_tex1_global_ld_misses_enc_str_1, 0x11, 0xffff, 0x70, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_LOCAL_LD_HITS, maxwell_tex0_local_ld_hits_enc_str_1, 0x13, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_LOCAL_LD_HITS, maxwell_tex1_local_ld_hits_enc_str_1, 0x13, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_LOCAL_LD_MISSES, maxwell_tex0_local_ld_misses_enc_str_1, 0x13, 0xffff, 0x84, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_LOCAL_LD_MISSES, maxwell_tex1_local_ld_misses_enc_str_1, 0x13, 0xffff, 0x70, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_NUM_32_BIT_T_16, maxwell_tex0_num_32_bit_t_16_enc_str_1, 0x16, 0xffff, 0x88, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_NUM_64_BIT_T_16, maxwell_tex0_num_64_bit_t_16_enc_str_1, 0x16, 0xffff, 0x89, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_NUM_128_BIT_T_16, maxwell_tex0_num_128_bit_t_16_enc_str_1, 0x16, 0xffff, 0x8a, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_NUM_32_BIT_T_16, maxwell_tex1_num_32_bit_t_16_enc_str_1, 0x16, 0xffff, 0x74, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_NUM_64_BIT_T_16, maxwell_tex1_num_64_bit_t_16_enc_str_1, 0x16, 0xffff, 0x75, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_NUM_128_BIT_T_16, maxwell_tex1_num_128_bit_t_16_enc_str_1, 0x16, 0xffff, 0x76, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_SURFACE_LD_MISSES, maxwell_tex0_surface_ld_misses_enc_str_1, 0x19, 0xffff, 0x84, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_LD_MISSES, maxwell_tex1_surface_ld_misses_enc_str_1, 0x19, 0xffff, 0x70, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
/*
From Will Kohut:
I found that the following PM always seems to be 0:
tex2pm_gpc_t_global_cctl_invalidates (this may also apply to the local PM flavor as well)

Seema and I looked at the waves, and it appears that its 0 because the CCTL we use is an IVALL, which doesnt return a hits value (ie: no tag comparison is done, we just go ahead and invalidate everything).  Without a hits value, this PM will never toggle.

The PM spreadsheet defines these two PMs (ie: both global and local versions) as follows:
how many sector hits for the request.
Note,  cache invalidate request is considered as a hit
*/
    //{MAXWELL_TEX0_GLOBAL_CCTL_INVALIDATES, "__tex0_global_cctl_invalidates", 0x1d, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    //{MAXWELL_TEX1_GLOBAL_CCTL_INVALIDATES, "__tex1_global_cctl_invalidates", 0x1d, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_LD_SET_CONFLICTS, maxwell_tex0_global_ld_set_conflicts_enc_str_1, 0x6, 0xaaaa, 0x86, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_LD_SET_CONFLICTS, maxwell_tex1_global_ld_set_conflicts_enc_str_1, 0x6, 0xaaaa, 0x72, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_CACHED_GLOBAL_LD_SET_CONFLICTS, maxwell_tex0_cached_global_ld_set_conflicts_enc_str_1, 0x7, 0xaaaa, 0x86, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_CACHED_GLOBAL_LD_SET_CONFLICTS, maxwell_tex1_cached_global_ld_set_conflicts_enc_str_1, 0x7, 0xaaaa, 0x72, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_UNCACHED_GLOBAL_LD_SET_CONFLICTS, maxwell_tex0_uncached_global_ld_set_conflicts_enc_str_1, 0x7, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_UNCACHED_GLOBAL_LD_SET_CONFLICTS, maxwell_tex1_uncached_global_ld_set_conflicts_enc_str_1, 0x7, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_UNCACHED_GLOBAL_LD_COALESCING, maxwell_tex0_uncached_global_ld_coalescing_enc_str_1, 0x16, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_UNCACHED_GLOBAL_LD_COALESCING, maxwell_tex1_uncached_global_ld_coalescing_enc_str_1, 0x16, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_LD_COALESCING, maxwell_tex0_global_ld_coalescing_enc_str_1, 0x15, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_LD_COALESCING, maxwell_tex1_global_ld_coalescing_enc_str_1, 0x15, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_CACHED_LOCAL_LD_HITS, maxwell_tex0_cached_local_ld_hits_enc_str_1, 0x14, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_CACHED_LOCAL_LD_HITS, maxwell_tex1_cached_local_ld_hits_enc_str_1, 0x14, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_CACHED_LOCAL_LD_MISSES, maxwell_tex0_cached_local_ld_misses_enc_str_1, 0x14, 0xffff, 0x84, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_CACHED_LOCAL_LD_MISSES, maxwell_tex1_cached_local_ld_misses_enc_str_1, 0x14, 0xffff, 0x70, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_UNCACHED_LOCAL_LD_MISSES, maxwell_tex0_uncached_local_ld_misses_enc_str_1, 0x18, 0xffff, 0x84, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_UNCACHED_LOCAL_LD_MISSES, maxwell_tex1_uncached_local_ld_misses_enc_str_1, 0x18, 0xffff, 0x70, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_CACHED_GLOBAL_LD_SET_ACCESS, maxwell_tex0_cached_global_ld_set_access_enc_str_1, 0x7, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_CACHED_GLOBAL_LD_SET_ACCESS, maxwell_tex1_cached_global_ld_set_access_enc_str_1, 0x7, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_LD_SET_ACCESS, maxwell_tex0_global_ld_set_access_enc_str_1, 0x6, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_LD_SET_ACCESS, maxwell_tex1_global_ld_set_access_enc_str_1, 0x6, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_UNCACHED_GLOBAL_LD_SET_ACCESS, maxwell_tex0_uncached_global_ld_set_access_enc_str_1, 0x7, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_UNCACHED_GLOBAL_LD_SET_ACCESS, maxwell_tex1_uncached_global_ld_set_access_enc_str_1, 0x7, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_CACHED_LOCAL_LD_SET_ACCESS, maxwell_tex0_cached_local_ld_set_access_enc_str_1, 0xb, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_CACHED_LOCAL_LD_SET_ACCESS, maxwell_tex1_cached_local_ld_set_access_enc_str_1, 0xb, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_LOCAL_LD_SET_ACCESS, maxwell_tex0_local_ld_set_access_enc_str_1, 0xa, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_LOCAL_LD_SET_ACCESS, maxwell_tex1_local_ld_set_access_enc_str_1, 0xa, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_UNCACHED_LOCAL_LD_SET_ACCESS, maxwell_tex0_uncached_local_ld_set_access_enc_str_1, 0xb, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_UNCACHED_LOCAL_LD_SET_ACCESS, maxwell_tex1_uncached_local_ld_set_access_enc_str_1, 0xb, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},

    //{MAXWELL_TEX0_LOCAL_CCTL_INVALIDATES, "__tex0_local_cctl_invalidates", 0x1d, 0xffff, 0x84, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    //{MAXWELL_TEX1_LOCAL_CCTL_INVALIDATES, "__tex1_local_cctl_invalidates", 0x1d, 0xffff, 0x70, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_CACHED_LOCAL_LD_SET_CONFLICTS, maxwell_tex0_cached_local_ld_set_conflicts_enc_str_1, 0xb, 0xaaaa, 0x86, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_CACHED_LOCAL_LD_SET_CONFLICTS, maxwell_tex1_cached_local_ld_set_conflicts_enc_str_1, 0xb, 0xaaaa, 0x72, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_LOCAL_LD_SET_CONFLICTS, maxwell_tex0_local_ld_set_conflicts_enc_str_1, 0xa, 0xaaaa, 0x83, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_LOCAL_LD_SET_CONFLICTS, maxwell_tex1_local_ld_set_conflicts_enc_str_1, 0xa, 0xaaaa, 0x6f, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_UNCACHED_LOCAL_LD_SET_CONFLICTS, maxwell_tex0_uncached_local_ld_set_conflicts_enc_str_1, 0xb, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_UNCACHED_LOCAL_LD_SET_CONFLICTS, maxwell_tex1_uncached_local_ld_set_conflicts_enc_str_1, 0xb, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_LOCAL_LD_COALESCING, maxwell_tex0_local_ld_coalescing_enc_str_1, 0x17, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_LOCAL_LD_COALESCING, maxwell_tex1_local_ld_coalescing_enc_str_1, 0x17, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_UNCACHED_LOCAL_LD_COALESCING, maxwell_tex0_uncached_local_ld_coalescing_enc_str_1, 0x18, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_UNCACHED_LOCAL_LD_COALESCING, maxwell_tex1_uncached_local_ld_coalescing_enc_str_1, 0x18, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_GLOBAL_ST_REQUESTS, maxwell_tex0_global_st_requests_enc_str_1, 0x41, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_GLOBAL_ST_REQUESTS, maxwell_tex1_global_st_requests_enc_str_1, 0x41, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_LOCAL_ST_REQUESTS, maxwell_tex0_local_st_requests_enc_str_1, 0x44, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_LOCAL_ST_REQUESTS, maxwell_tex1_local_st_requests_enc_str_1, 0x44, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},

    {MAXWELL_TEX0_GLOBAL_ST_SET_ACCESS, maxwell_tex0_global_st_set_access_enc_str_1, 0x6, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_ST_SET_ACCESS, maxwell_tex1_global_st_set_access_enc_str_1, 0x6, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_LOCAL_ST_SET_ACCESS, maxwell_tex0_local_st_set_access_enc_str_1, 0xc, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_LOCAL_ST_SET_ACCESS, maxwell_tex1_local_st_set_access_enc_str_1, 0xc, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_GLOBAL_ST_SET_CONFLICTS, maxwell_tex0_global_st_set_conflicts_enc_str_1, 0x6, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_ST_SET_CONFLICTS, maxwell_tex1_global_st_set_conflicts_enc_str_1, 0x6, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_LOCAL_ST_SET_CONFLICTS, maxwell_tex0_local_st_set_conflicts_enc_str_1, 0xc, 0xaaaa, 0x86, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_LOCAL_ST_SET_CONFLICTS, maxwell_tex1_local_st_set_conflicts_enc_str_1, 0xc, 0xaaaa, 0x72, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_CACHED_GLOBAL_LD_DATA_CONFLICTS, maxwell_tex0_cached_global_ld_data_conflicts_enc_str_1, 0x15, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_CACHED_LOCAL_LD_DATA_CONFLICTS, maxwell_tex0_cached_local_ld_data_conflicts_enc_str_1, 0x18, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_GLOBAL_ATOM_CAS_DATA_CONFLICTS, maxwell_tex0_global_atom_cas_data_conflicts_enc_str_1, 0x16, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_GLOBAL_ATOM_DATA_CONFLICTS, maxwell_tex0_global_atom_data_conflicts_enc_str_1, 0x16, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_GLOBAL_LD_DATA_CONFLICTS, maxwell_tex0_global_ld_data_conflicts_enc_str_1, 0x14, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_LOCAL_LD_DATA_CONFLICTS, maxwell_tex0_local_ld_data_conflicts_enc_str_1, 0x17, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_SURFACE_ATOM_CAS_DATA_CONFLICTS, maxwell_tex0_surface_atom_cas_data_conflicts_enc_str_1, 0x1a, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_SURFACE_ATOM_DATA_CONFLICTS, maxwell_tex0_surface_atom_data_conflicts_enc_str_1, 0x1a, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_SURFACE_LD_DATA_CONFLICTS, maxwell_tex0_surface_ld_data_conflicts_enc_str_1, 0x19, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_UNCACHED_GLOBAL_LD_DATA_CONFLICTS, maxwell_tex0_uncached_global_ld_data_conflicts_enc_str_1, 0x15, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_UNCACHED_LOCAL_LD_DATA_CONFLICTS, maxwell_tex0_uncached_local_ld_data_conflicts_enc_str_1, 0x18, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_CACHED_GLOBAL_LD_DATA_CONFLICTS, maxwell_tex1_cached_global_ld_data_conflicts_enc_str_1, 0x15, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_CACHED_LOCAL_LD_DATA_CONFLICTS, maxwell_tex1_cached_local_ld_data_conflicts_enc_str_1, 0x18, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_GLOBAL_ATOM_CAS_DATA_CONFLICTS, maxwell_tex1_global_atom_cas_data_conflicts_enc_str_1, 0x16, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_GLOBAL_ATOM_DATA_CONFLICTS, maxwell_tex1_global_atom_data_conflicts_enc_str_1, 0x16, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_GLOBAL_LD_DATA_CONFLICTS, maxwell_tex1_global_ld_data_conflicts_enc_str_1, 0x14, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_LOCAL_LD_DATA_CONFLICTS, maxwell_tex1_local_ld_data_conflicts_enc_str_1, 0x17, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_SURFACE_ATOM_CAS_DATA_CONFLICTS, maxwell_tex1_surface_atom_cas_data_conflicts_enc_str_1, 0x1a, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_SURFACE_ATOM_DATA_CONFLICTS, maxwell_tex1_surface_atom_data_conflicts_enc_str_1, 0x1a, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_SURFACE_LD_DATA_CONFLICTS, maxwell_tex1_surface_ld_data_conflicts_enc_str_1, 0x19, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_UNCACHED_GLOBAL_LD_DATA_CONFLICTS, maxwell_tex1_uncached_global_ld_data_conflicts_enc_str_1, 0x15, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_UNCACHED_LOCAL_LD_DATA_CONFLICTS, maxwell_tex1_uncached_local_ld_data_conflicts_enc_str_1, 0x18, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_CACHED_GLOBAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex0_cached_global_ld_row_column_conflicts_enc_str_1, 0x1c, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_CACHED_LOCAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex0_cached_local_ld_row_column_conflicts_enc_str_1, 0x1f, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_GLOBAL_ATOM_CAS_ROW_COLUMN_CONFLICTS, maxwell_tex0_global_atom_cas_row_column_conflicts_enc_str_1, 0x1d, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_GLOBAL_ATOM_ROW_COLUMN_CONFLICTS, maxwell_tex0_global_atom_row_column_conflicts_enc_str_1, 0x1d, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_GLOBAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex0_global_ld_row_column_conflicts_enc_str_1, 0x1b, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_LOCAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex0_local_ld_row_column_conflicts_enc_str_1, 0x1e, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_SURFACE_ATOM_CAS_ROW_COLUMN_CONFLICTS, maxwell_tex0_surface_atom_cas_row_column_conflicts_enc_str_1, 0x21, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_SURFACE_ATOM_ROW_COLUMN_CONFLICTS, maxwell_tex0_surface_atom_row_column_conflicts_enc_str_1, 0x21, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_SURFACE_LD_ROW_COLUMN_CONFLICTS, maxwell_tex0_surface_ld_row_column_conflicts_enc_str_1, 0x20, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_UNCACHED_GLOBAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex0_uncached_global_ld_row_column_conflicts_enc_str_1, 0x1c, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_UNCACHED_LOCAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex0_uncached_local_ld_row_column_conflicts_enc_str_1, 0x1f, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_CACHED_GLOBAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex1_cached_global_ld_row_column_conflicts_enc_str_1, 0x1c, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_CACHED_LOCAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex1_cached_local_ld_row_column_conflicts_enc_str_1, 0x1f, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_GLOBAL_ATOM_CAS_ROW_COLUMN_CONFLICTS, maxwell_tex1_global_atom_cas_row_column_conflicts_enc_str_1, 0x1d, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_GLOBAL_ATOM_ROW_COLUMN_CONFLICTS, maxwell_tex1_global_atom_row_column_conflicts_enc_str_1, 0x1d, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_GLOBAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex1_global_ld_row_column_conflicts_enc_str_1, 0x1b, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_LOCAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex1_local_ld_row_column_conflicts_enc_str_1, 0x1e, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_SURFACE_ATOM_CAS_ROW_COLUMN_CONFLICTS, maxwell_tex1_surface_atom_cas_row_column_conflicts_enc_str_1, 0x21, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_SURFACE_ATOM_ROW_COLUMN_CONFLICTS, maxwell_tex1_surface_atom_row_column_conflicts_enc_str_1, 0x21, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_SURFACE_LD_ROW_COLUMN_CONFLICTS, maxwell_tex1_surface_ld_row_column_conflicts_enc_str_1, 0x20, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_UNCACHED_GLOBAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex1_uncached_global_ld_row_column_conflicts_enc_str_1, 0x1c, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_UNCACHED_LOCAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex1_uncached_local_ld_row_column_conflicts_enc_str_1, 0x1f, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},

    {MAXWELL_TEX0_GLOBAL_ATOM_REQUESTS, maxwell_tex0_global_atom_requests_enc_str_1, 0x42, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_GLOBAL_ATOM_REQUESTS, maxwell_tex1_global_atom_requests_enc_str_1, 0x42, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_GLOBAL_ATOM_SET_ACCESS, maxwell_tex0_global_atom_set_access_enc_str_1, 0x9, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_ATOM_SET_ACCESS, maxwell_tex1_global_atom_set_access_enc_str_1, 0x9, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_ATOM_SET_CONFLICTS, maxwell_tex0_global_atom_set_conflicts_enc_str_1, 0x9, 0xaaaa, 0x86, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_ATOM_SET_CONFLICTS, maxwell_tex1_global_atom_set_conflicts_enc_str_1, 0x9, 0xaaaa, 0x72, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_ATOM_CAS_REQUESTS, maxwell_tex0_global_atom_cas_requests_enc_str_1, 0x42, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_GLOBAL_ATOM_CAS_REQUESTS, maxwell_tex1_global_atom_cas_requests_enc_str_1, 0x42, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_GLOBAL_ATOM_CAS_SET_ACCESS, maxwell_tex0_global_atom_cas_set_access_enc_str_1, 0x9, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_ATOM_CAS_SET_ACCESS, maxwell_tex1_global_atom_cas_set_access_enc_str_1, 0x9, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_ATOM_CAS_SET_CONFLICTS, maxwell_tex0_global_atom_cas_set_conflicts_enc_str_1, 0x9, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_ATOM_CAS_SET_CONFLICTS, maxwell_tex1_global_atom_cas_set_conflicts_enc_str_1, 0x9, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_RED_REQUESTS, maxwell_tex0_global_red_requests_enc_str_1, 0x42, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_GLOBAL_RED_REQUESTS, maxwell_tex1_global_red_requests_enc_str_1, 0x42, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_GLOBAL_RED_SET_ACCESS, maxwell_tex0_global_red_set_access_enc_str_1, 0x8, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_RED_SET_ACCESS, maxwell_tex1_global_red_set_access_enc_str_1, 0x8, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_RED_SET_CONFLICTS, maxwell_tex0_global_red_set_conflicts_enc_str_1, 0x8, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_RED_SET_CONFLICTS, maxwell_tex1_global_red_set_conflicts_enc_str_1, 0x8, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_LD_SET_ACCESS, maxwell_tex0_surface_ld_set_access_enc_str_1, 0xd, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_LD_SET_ACCESS, maxwell_tex1_surface_ld_set_access_enc_str_1, 0xd, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_LD_SET_CONFLICTS, maxwell_tex0_surface_ld_set_conflicts_enc_str_1, 0xd, 0xaaaa, 0x86, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_LD_SET_CONFLICTS, maxwell_tex1_surface_ld_set_conflicts_enc_str_1, 0xd, 0xaaaa, 0x72, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_ST_SET_ACCESS, maxwell_tex0_surface_st_set_access_enc_str_1, 0xd, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_ST_SET_ACCESS, maxwell_tex1_surface_st_set_access_enc_str_1, 0xd, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_ST_SET_CONFLICTS, maxwell_tex0_surface_st_set_conflicts_enc_str_1, 0xd, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_ST_SET_CONFLICTS, maxwell_tex1_surface_st_set_conflicts_enc_str_1, 0xd, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_RED_SET_ACCESS, maxwell_tex0_surface_red_set_access_enc_str_1, 0xe, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_RED_SET_ACCESS, maxwell_tex1_surface_red_set_access_enc_str_1, 0xe, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_RED_SET_CONFLICTS, maxwell_tex0_surface_red_set_conflicts_enc_str_1, 0xe, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_RED_SET_CONFLICTS, maxwell_tex1_surface_red_set_conflicts_enc_str_1, 0xe, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_ATOM_SET_ACCESS, maxwell_tex0_surface_atom_set_access_enc_str_1, 0xf, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_ATOM_SET_ACCESS, maxwell_tex1_surface_atom_set_access_enc_str_1, 0xf, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_ATOM_CAS_SET_ACCESS, maxwell_tex0_surface_atom_cas_set_access_enc_str_1, 0xf, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_ATOM_CAS_SET_ACCESS, maxwell_tex1_surface_atom_cas_set_access_enc_str_1, 0xf, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_ATOM_SET_CONFLICTS, maxwell_tex0_surface_atom_set_conflicts_enc_str_1, 0xf, 0xaaaa, 0x86, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_ATOM_SET_CONFLICTS, maxwell_tex1_surface_atom_set_conflicts_enc_str_1, 0xf, 0xaaaa, 0x72, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_ATOM_CAS_SET_CONFLICTS, maxwell_tex0_surface_atom_cas_set_conflicts_enc_str_1, 0xf, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_ATOM_CAS_SET_CONFLICTS, maxwell_tex1_surface_atom_cas_set_conflicts_enc_str_1, 0xf, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_LD_REQUESTS, maxwell_tex0_surface_ld_requests_enc_str_1, 0x45, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_SURFACE_LD_REQUESTS, maxwell_tex1_surface_ld_requests_enc_str_1, 0x45, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_SURFACE_ST_REQUESTS, maxwell_tex0_surface_st_requests_enc_str_1, 0x45, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_SURFACE_ST_REQUESTS, maxwell_tex1_surface_st_requests_enc_str_1, 0x45, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_SURFACE_RED_REQUESTS, maxwell_tex0_surface_red_requests_enc_str_1, 0x46, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_SURFACE_RED_REQUESTS, maxwell_tex1_surface_red_requests_enc_str_1, 0x46, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_SURFACE_ATOM_REQUESTS, maxwell_tex0_surface_atom_requests_enc_str_1, 0x46, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_SURFACE_ATOM_REQUESTS, maxwell_tex1_surface_atom_requests_enc_str_1, 0x46, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_SURFACE_ATOM_CAS_REQUESTS, maxwell_tex0_surface_atom_cas_requests_enc_str_1, 0x46, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_SURFACE_ATOM_CAS_REQUESTS, maxwell_tex1_surface_atom_cas_requests_enc_str_1, 0x46, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},

    {MAXWELL_TEX0_GLOBAL_ATOM_ADDRESS_CONFLICTS, maxwell_tex0_global_atom_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x80, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_ATOM_CAS_ADDRESS_CONFLICTS, maxwell_tex0_global_atom_cas_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x81, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_RED_ADDRESS_CONFLICTS, maxwell_tex0_global_red_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x82, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_ATOM_ADDRESS_CONFLICTS, maxwell_tex0_surface_atom_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x83, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_ATOM_CAS_ADDRESS_CONFLICTS, maxwell_tex0_surface_atom_cas_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x84, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_RED_ADDRESS_CONFLICTS, maxwell_tex0_surface_red_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x85, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_ATOM_ADDRESS_CONFLICTS, maxwell_tex1_global_atom_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x6c, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_ATOM_CAS_ADDRESS_CONFLICTS, maxwell_tex1_global_atom_cas_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x6d, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_RED_ADDRESS_CONFLICTS, maxwell_tex1_global_red_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x6e, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_ATOM_ADDRESS_CONFLICTS, maxwell_tex1_surface_atom_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x6f, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_ATOM_CAS_ADDRESS_CONFLICTS, maxwell_tex1_surface_atom_cas_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x70, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_RED_ADDRESS_CONFLICTS, maxwell_tex1_surface_red_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x71, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_ST_HITS_IN_WARP, maxwell_tex0_global_st_hits_in_warp_enc_str_1, 0x1a, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_LOCAL_ST_HITS_IN_WARP, maxwell_tex0_local_st_hits_in_warp_enc_str_1, 0x1b, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_ST_HITS_IN_WARP, maxwell_tex0_surface_st_hits_in_warp_enc_str_1, 0x1c, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_ST_HITS_IN_WARP, maxwell_tex1_global_st_hits_in_warp_enc_str_1, 0x1a, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_LOCAL_ST_HITS_IN_WARP, maxwell_tex1_local_st_hits_in_warp_enc_str_1, 0x1b, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_ST_HITS_IN_WARP, maxwell_tex1_surface_st_hits_in_warp_enc_str_1, 0x1c, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_INPUT_ST_SECTOR_SUM, maxwell_tex0_input_st_sector_sum_enc_str_1, 0x1e, 0xffff, 0x82, PM_UNIT_TEX_M, 3},
    {MAXWELL_TEX1_INPUT_ST_SECTOR_SUM, maxwell_tex1_input_st_sector_sum_enc_str_1, 0x1e, 0xffff, 0x6e, PM_UNIT_TEX_M, 3},
    {MAXWELL_TEX0_INPUT_WR_SECTOR_SUM, maxwell_tex0_input_wr_sector_sum_enc_str_1, 0x1e, 0xffff, 0x85, PM_UNIT_TEX_M, 3},
    {MAXWELL_TEX1_INPUT_WR_SECTOR_SUM, maxwell_tex1_input_wr_sector_sum_enc_str_1, 0x1e, 0xffff, 0x71, PM_UNIT_TEX_M, 3},
    {MAXWELL_TEX0_OUTPUT_ST_SECTOR_SUM, maxwell_tex0_output_st_sector_sum_enc_str_1, 0x20, 0xffff, 0x80, PM_UNIT_TEX_M, 3},
    {MAXWELL_TEX1_OUTPUT_ST_SECTOR_SUM, maxwell_tex1_output_st_sector_sum_enc_str_1, 0x20, 0xffff, 0x6c, PM_UNIT_TEX_M, 3},
    {MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM, maxwell_tex0_output_wr_sector_sum_enc_str_1, 0x20, 0xffff, 0x83, PM_UNIT_TEX_M, 3},
    {MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM, maxwell_tex1_output_wr_sector_sum_enc_str_1, 0x20, 0xffff, 0x6f, PM_UNIT_TEX_M, 3},
    {MAXWELL_TEX0_OUTPUT_GLOBAL, maxwell_tex0_output_global_enc_str_1, 0x20, 0xffff, 0x86, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_OUTPUT_GLOBAL, maxwell_tex1_output_global_enc_str_1, 0x20, 0xffff, 0x72, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_OUTPUT_LOCAL, maxwell_tex0_output_local_enc_str_1, 0x20, 0xffff, 0x87, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_OUTPUT_LOCAL, maxwell_tex1_output_local_enc_str_1, 0x20, 0xffff, 0x73, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_OUTPUT_SUST, maxwell_tex0_output_sust_enc_str_1, 0x20, 0xffff, 0x88, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_OUTPUT_SUST, maxwell_tex1_output_sust_enc_str_1, 0x20, 0xffff, 0x74, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_OUTPUT_ATOM_OR_ATOM_CAS, maxwell_tex0_output_atom_or_atom_cas_enc_str_1, 0x20, 0xffff, 0x89, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_OUTPUT_ATOM_OR_ATOM_CAS, maxwell_tex1_output_atom_or_atom_cas_enc_str_1, 0x20, 0xffff, 0x75, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_OUTPUT_RED, maxwell_tex0_output_red_enc_str_1, 0x20, 0xffff, 0x8a, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_OUTPUT_RED, maxwell_tex1_output_red_enc_str_1, 0x20, 0xffff, 0x76, PM_UNIT_TEX_M, 1},

    {MAXWELL_TEX0_TEX2SM_TEX_PRDY, maxwell_tex0_tex2sm_tex_prdy_enc_str_1, 0x3, 0xaaaa, 0xa3, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_TEX2SM_TEX_PRDY, maxwell_tex1_tex2sm_tex_prdy_enc_str_1, 0x3, 0xaaaa, 0x9a, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_TEX2SM_TEX_PVLD, maxwell_tex0_tex2sm_tex_pvld_enc_str_1, 0x3, 0xaaaa, 0xa2, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_TEX2SM_TEX_PVLD, maxwell_tex1_tex2sm_tex_pvld_enc_str_1, 0x3, 0xaaaa, 0x99, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_SM2TEX_REQ_PRDY, maxwell_tex0_sm2tex_req_prdy_enc_str_1, 0x24 , 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_SM2TEX_REQ_PRDY, maxwell_tex1_sm2tex_req_prdy_enc_str_1, 0x24 , 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_SM2TEX_REQ_PVLD, maxwell_tex0_sm2tex_req_pvld_enc_str_1, 0x24 , 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_SM2TEX_REQ_PVLD, maxwell_tex1_sm2tex_req_pvld_enc_str_1, 0x24 , 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_C0_IS_TEX, maxwell_tex0_c0_is_tex_enc_str_1, 0x24, 0xaaaa, 0x90, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_C0_IS_TEX, maxwell_tex1_c0_is_tex_enc_str_1, 0x24, 0xaaaa, 0x96, PM_UNIT_TEX_S, 1},

    { MAXWELL_ELAPSED_CYCLES_SM,            maxwell_elapsed_cycles_sm_enc_str_1,          0x00000000, 0x00000000, 0x00000000,    PM_UNIT_SMCORE,0},
    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpmExpt PerfSignalTableGM000_gpctpc_expt[] = {
    { MAXWELL_TEX0_RETURN_PACKET_COUNT,    maxwell_tex0_return_packet_count_enc_str_1,   INVALID_PM_SIGNAL_NEW, {MAXWELL_TEX0_TEX2SM_TEX_PRDY, MAXWELL_TEX0_TEX2SM_TEX_PVLD, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { MAXWELL_TEX1_RETURN_PACKET_COUNT,    maxwell_tex1_return_packet_count_enc_str_1,   INVALID_PM_SIGNAL_NEW, {MAXWELL_TEX1_TEX2SM_TEX_PRDY, MAXWELL_TEX1_TEX2SM_TEX_PVLD, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},

    { MAXWELL_TEX0_UNCACHED_GLOBAL_LD_MISSES_32, maxwell_tex0_uncached_global_ld_misses_32_enc_str_1, MAXWELL_TEX0_UNCACHED_GLOBAL_LD_MISSES, {MAXWELL_TEX0_NUM_32_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX0_UNCACHED_GLOBAL_LD_MISSES_64, maxwell_tex0_uncached_global_ld_misses_64_enc_str_1, MAXWELL_TEX0_UNCACHED_GLOBAL_LD_MISSES, {MAXWELL_TEX0_NUM_64_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX0_UNCACHED_GLOBAL_LD_MISSES_128, maxwell_tex0_uncached_global_ld_misses_128_enc_str_1, MAXWELL_TEX0_UNCACHED_GLOBAL_LD_MISSES, {MAXWELL_TEX0_NUM_128_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_UNCACHED_GLOBAL_LD_MISSES_32, maxwell_tex1_uncached_global_ld_misses_32_enc_str_1, MAXWELL_TEX1_UNCACHED_GLOBAL_LD_MISSES, {MAXWELL_TEX1_NUM_32_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_UNCACHED_GLOBAL_LD_MISSES_64, maxwell_tex1_uncached_global_ld_misses_64_enc_str_1, MAXWELL_TEX1_UNCACHED_GLOBAL_LD_MISSES, {MAXWELL_TEX1_NUM_64_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_UNCACHED_GLOBAL_LD_MISSES_128, maxwell_tex1_uncached_global_ld_misses_128_enc_str_1, MAXWELL_TEX1_UNCACHED_GLOBAL_LD_MISSES, {MAXWELL_TEX1_NUM_128_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},

    { MAXWELL_TEX0_UNCACHED_GLOBAL_LD_COALESCING_32, maxwell_tex0_uncached_global_ld_coalescing_32_enc_str_1, MAXWELL_TEX0_UNCACHED_GLOBAL_LD_COALESCING, {MAXWELL_TEX0_NUM_32_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX0_UNCACHED_GLOBAL_LD_COALESCING_64, maxwell_tex0_uncached_global_ld_coalescing_64_enc_str_1, MAXWELL_TEX0_UNCACHED_GLOBAL_LD_COALESCING, {MAXWELL_TEX0_NUM_64_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX0_UNCACHED_GLOBAL_LD_COALESCING_128, maxwell_tex0_uncached_global_ld_coalescing_128_enc_str_1, MAXWELL_TEX0_UNCACHED_GLOBAL_LD_COALESCING, {MAXWELL_TEX0_NUM_128_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_UNCACHED_GLOBAL_LD_COALESCING_32, maxwell_tex1_uncached_global_ld_coalescing_32_enc_str_1, MAXWELL_TEX1_UNCACHED_GLOBAL_LD_COALESCING, {MAXWELL_TEX1_NUM_32_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_UNCACHED_GLOBAL_LD_COALESCING_64, maxwell_tex1_uncached_global_ld_coalescing_64_enc_str_1, MAXWELL_TEX1_UNCACHED_GLOBAL_LD_COALESCING, {MAXWELL_TEX1_NUM_64_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_UNCACHED_GLOBAL_LD_COALESCING_128, maxwell_tex1_uncached_global_ld_coalescing_128_enc_str_1, MAXWELL_TEX1_UNCACHED_GLOBAL_LD_COALESCING, {MAXWELL_TEX1_NUM_128_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},

    { MAXWELL_TEX0_STORE_SECTOR_MISSES_GLOBAL,           maxwell_tex0_store_sector_misses_global_enc_str_1, MAXWELL_TEX0_OUTPUT_ST_SECTOR_SUM, {MAXWELL_TEX0_OUTPUT_GLOBAL, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_GLOBAL,           maxwell_tex1_store_sector_misses_global_enc_str_1, MAXWELL_TEX1_OUTPUT_ST_SECTOR_SUM, {MAXWELL_TEX1_OUTPUT_GLOBAL, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX0_STORE_SECTOR_MISSES_LOCAL,            maxwell_tex0_store_sector_misses_local_enc_str_1,  MAXWELL_TEX0_OUTPUT_ST_SECTOR_SUM, {MAXWELL_TEX0_OUTPUT_LOCAL, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_LOCAL,            maxwell_tex1_store_sector_misses_local_enc_str_1,  MAXWELL_TEX1_OUTPUT_ST_SECTOR_SUM, {MAXWELL_TEX1_OUTPUT_LOCAL, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX0_STORE_SECTOR_MISSES_SUST,             maxwell_tex0_store_sector_misses_sust_enc_str_1,   MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX0_OUTPUT_SUST, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_SUST,             maxwell_tex1_store_sector_misses_sust_enc_str_1,   MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX1_OUTPUT_SUST, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX0_STORE_SECTOR_MISSES_ATOM_OR_ATOM_CAS, maxwell_tex0_store_sector_misses_atom_or_atom_cas_enc_str_1, MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX0_OUTPUT_ATOM_OR_ATOM_CAS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_ATOM_OR_ATOM_CAS, maxwell_tex1_store_sector_misses_atom_or_atom_cas_enc_str_1, MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX1_OUTPUT_ATOM_OR_ATOM_CAS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX0_STORE_SECTOR_MISSES_RED,              maxwell_tex0_store_sector_misses_red_enc_str_1, MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX0_OUTPUT_RED, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_RED,              maxwell_tex1_store_sector_misses_red_enc_str_1, MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX1_OUTPUT_RED, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},

    { MAXWELL_TEX0_STORE_SECTOR_MISSES_SUST_NONATOM, maxwell_tex0_store_sector_misses_sust_nonatom_enc_str_1,  MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX0_OUTPUT_SUST, MAXWELL_TEX0_OUTPUT_ATOM_OR_ATOM_CAS, MAXWELL_TEX0_OUTPUT_RED, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_SUST_NONATOM, maxwell_tex1_store_sector_misses_sust_nonatom_enc_str_1,  MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX1_OUTPUT_SUST, MAXWELL_TEX1_OUTPUT_ATOM_OR_ATOM_CAS, MAXWELL_TEX1_OUTPUT_RED, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX0_STORE_SECTOR_MISSES_SUST_ATOM_OR_ATOM_CAS, maxwell_tex0_store_sector_misses_sust_atom_or_atom_cas_enc_str_1,  MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX0_OUTPUT_SUST, MAXWELL_TEX0_OUTPUT_ATOM_OR_ATOM_CAS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_SUST_ATOM_OR_ATOM_CAS, maxwell_tex1_store_sector_misses_sust_atom_or_atom_cas_enc_str_1,  MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX1_OUTPUT_SUST, MAXWELL_TEX1_OUTPUT_ATOM_OR_ATOM_CAS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX0_STORE_SECTOR_MISSES_SUST_RED, maxwell_tex0_store_sector_misses_sust_red_enc_str_1,  MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX0_OUTPUT_SUST, MAXWELL_TEX0_OUTPUT_RED, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_SUST_RED, maxwell_tex1_store_sector_misses_sust_red_enc_str_1,  MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX1_OUTPUT_SUST, MAXWELL_TEX1_OUTPUT_RED, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_TEX0_WRITE_SECTORS_GLOBAL_NONATOM, maxwell_tex0_write_sectors_global_nonatom_enc_str_1, MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX0_OUTPUT_GLOBAL, MAXWELL_TEX0_OUTPUT_ATOM_OR_ATOM_CAS, MAXWELL_TEX0_OUTPUT_RED, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX1_WRITE_SECTORS_GLOBAL_NONATOM, maxwell_tex1_write_sectors_global_nonatom_enc_str_1, MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX1_OUTPUT_GLOBAL, MAXWELL_TEX1_OUTPUT_ATOM_OR_ATOM_CAS, MAXWELL_TEX1_OUTPUT_RED, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX0_WRITE_SECTORS_GLOBAL_ATOM, maxwell_tex0_write_sectors_global_atom_enc_str_1, MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX0_OUTPUT_GLOBAL, MAXWELL_TEX0_OUTPUT_ATOM_OR_ATOM_CAS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX1_WRITE_SECTORS_GLOBAL_ATOM, maxwell_tex1_write_sectors_global_atom_enc_str_1, MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX1_OUTPUT_GLOBAL, MAXWELL_TEX1_OUTPUT_ATOM_OR_ATOM_CAS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX0_WRITE_SECTORS_GLOBAL_RED, maxwell_tex0_write_sectors_global_red_enc_str_1, MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX0_OUTPUT_GLOBAL, MAXWELL_TEX0_OUTPUT_RED, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX1_WRITE_SECTORS_GLOBAL_RED, maxwell_tex1_write_sectors_global_red_enc_str_1, MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX1_OUTPUT_GLOBAL, MAXWELL_TEX1_OUTPUT_RED, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX0_WRITE_SECTORS_LOCAL_ST, maxwell_tex0_write_sectors_local_st_enc_str_1, MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX0_OUTPUT_LOCAL, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX1_WRITE_SECTORS_LOCAL_ST, maxwell_tex1_write_sectors_local_st_enc_str_1, MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX1_OUTPUT_LOCAL, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_TEX0_TEX_QUAD_COUNT, maxwell_tex0_tex_quad_count_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_TEX0_SM2TEX_REQ_PRDY, MAXWELL_TEX0_SM2TEX_REQ_PVLD, MAXWELL_TEX0_C0_IS_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX1_TEX_QUAD_COUNT, maxwell_tex1_tex_quad_count_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_TEX1_SM2TEX_REQ_PRDY, MAXWELL_TEX1_SM2TEX_REQ_PVLD, MAXWELL_TEX1_C0_IS_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000,  0x00},
};


#if NVCFG(GLOBAL_GPU_FAMILY_GM20X) || NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
PerfSignalHwpmExpt PerfSignalTableGM200_gpctpc_expt[] = {
    { MAXWELL_TEX0_RETURN_PACKET_COUNT,    maxwell_tex0_return_packet_count_enc_str_1,   INVALID_PM_SIGNAL_NEW, {MAXWELL_TEX0_TEX2SM_TEX_PRDY, MAXWELL_TEX0_TEX2SM_TEX_PVLD, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { MAXWELL_TEX1_RETURN_PACKET_COUNT,    maxwell_tex1_return_packet_count_enc_str_1,   INVALID_PM_SIGNAL_NEW, {MAXWELL_TEX1_TEX2SM_TEX_PRDY, MAXWELL_TEX1_TEX2SM_TEX_PVLD, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},

    { MAXWELL_TEX0_UNCACHED_GLOBAL_LD_MISSES_32, maxwell_tex0_uncached_global_ld_misses_32_enc_str_1, MAXWELL_TEX0_UNCACHED_GLOBAL_LD_MISSES, {MAXWELL_TEX0_NUM_32_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX0_UNCACHED_GLOBAL_LD_MISSES_64, maxwell_tex0_uncached_global_ld_misses_64_enc_str_1, MAXWELL_TEX0_UNCACHED_GLOBAL_LD_MISSES, {MAXWELL_TEX0_NUM_64_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX0_UNCACHED_GLOBAL_LD_MISSES_128, maxwell_tex0_uncached_global_ld_misses_128_enc_str_1, MAXWELL_TEX0_UNCACHED_GLOBAL_LD_MISSES, {MAXWELL_TEX0_NUM_128_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_UNCACHED_GLOBAL_LD_MISSES_32, maxwell_tex1_uncached_global_ld_misses_32_enc_str_1, MAXWELL_TEX1_UNCACHED_GLOBAL_LD_MISSES, {MAXWELL_TEX1_NUM_32_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_UNCACHED_GLOBAL_LD_MISSES_64, maxwell_tex1_uncached_global_ld_misses_64_enc_str_1, MAXWELL_TEX1_UNCACHED_GLOBAL_LD_MISSES, {MAXWELL_TEX1_NUM_64_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_UNCACHED_GLOBAL_LD_MISSES_128, maxwell_tex1_uncached_global_ld_misses_128_enc_str_1, MAXWELL_TEX1_UNCACHED_GLOBAL_LD_MISSES, {MAXWELL_TEX1_NUM_128_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},

    { MAXWELL_TEX0_UNCACHED_GLOBAL_LD_COALESCING_32, maxwell_tex0_uncached_global_ld_coalescing_32_enc_str_1, MAXWELL_TEX0_UNCACHED_GLOBAL_LD_COALESCING, {MAXWELL_TEX0_NUM_32_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX0_UNCACHED_GLOBAL_LD_COALESCING_64, maxwell_tex0_uncached_global_ld_coalescing_64_enc_str_1, MAXWELL_TEX0_UNCACHED_GLOBAL_LD_COALESCING, {MAXWELL_TEX0_NUM_64_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX0_UNCACHED_GLOBAL_LD_COALESCING_128, maxwell_tex0_uncached_global_ld_coalescing_128_enc_str_1, MAXWELL_TEX0_UNCACHED_GLOBAL_LD_COALESCING, {MAXWELL_TEX0_NUM_128_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_UNCACHED_GLOBAL_LD_COALESCING_32, maxwell_tex1_uncached_global_ld_coalescing_32_enc_str_1, MAXWELL_TEX1_UNCACHED_GLOBAL_LD_COALESCING, {MAXWELL_TEX1_NUM_32_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_UNCACHED_GLOBAL_LD_COALESCING_64, maxwell_tex1_uncached_global_ld_coalescing_64_enc_str_1, MAXWELL_TEX1_UNCACHED_GLOBAL_LD_COALESCING, {MAXWELL_TEX1_NUM_64_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_UNCACHED_GLOBAL_LD_COALESCING_128, maxwell_tex1_uncached_global_ld_coalescing_128_enc_str_1, MAXWELL_TEX1_UNCACHED_GLOBAL_LD_COALESCING, {MAXWELL_TEX1_NUM_128_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},

    { MAXWELL_TEX0_STORE_SECTOR_MISSES_GLOBAL,           maxwell_tex0_store_sector_misses_global_enc_str_1, MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX0_OUTPUT_GLOBAL, MAXWELL_TEX0_MISSES_LG_ST, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_GLOBAL,           maxwell_tex1_store_sector_misses_global_enc_str_1, MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX1_OUTPUT_GLOBAL, MAXWELL_TEX1_MISSES_LG_ST, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { MAXWELL_TEX0_STORE_SECTOR_MISSES_LOCAL,            maxwell_tex0_store_sector_misses_local_enc_str_1,  MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX0_OUTPUT_LOCAL, MAXWELL_TEX0_MISSES_LG_ST, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_LOCAL,            maxwell_tex1_store_sector_misses_local_enc_str_1,  MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX1_OUTPUT_LOCAL, MAXWELL_TEX1_MISSES_LG_ST, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { MAXWELL_TEX0_STORE_SECTOR_MISSES_RED,              maxwell_tex0_store_sector_misses_red_enc_str_1, MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX0_OUTPUT_RED, MAXWELL_TEX0_OUTPUT_LOCAL, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_RED,              maxwell_tex1_store_sector_misses_red_enc_str_1, MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX1_OUTPUT_RED, MAXWELL_TEX1_OUTPUT_LOCAL, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},

    { MAXWELL_TEX0_STORE_SECTOR_MISSES_ATOM, maxwell_tex0_store_sector_misses_atom_enc_str_1, MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX0_OUTPUT_ATOM, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_ATOM, maxwell_tex1_store_sector_misses_atom_enc_str_1, MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX1_OUTPUT_ATOM, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},

    { MAXWELL_TEX0_STORE_SECTOR_MISSES_ATOM_CAS, maxwell_tex0_store_sector_misses_atom_cas_enc_str_1, MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX0_OUTPUT_ATOM_CAS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_ATOM_CAS, maxwell_tex1_store_sector_misses_atom_cas_enc_str_1, MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM, {MAXWELL_TEX1_OUTPUT_ATOM_CAS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},

    { MAXWELL_TEX0_STORE_SECTOR_MISSES_ATOM_OR_ATOM_CAS, maxwell_tex0_store_sector_misses_atom_or_atom_cas_enc_str_1, MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM_GRP20, {MAXWELL_TEX0_OUTPUT_ATOM_OR_ATOM_CAS_GRP20, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_ATOM_OR_ATOM_CAS, maxwell_tex1_store_sector_misses_atom_or_atom_cas_enc_str_1, MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM_GRP20, {MAXWELL_TEX1_OUTPUT_ATOM_OR_ATOM_CAS_GRP20, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_TEX0_STORE_SECTOR_MISSES_SUST_NONATOM, maxwell_tex0_store_sector_misses_sust_nonatom_enc_str_1,  MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM_GRP20, {MAXWELL_TEX0_OUTPUT_SUST_GRP20, MAXWELL_TEX0_OUTPUT_ATOM_OR_ATOM_CAS_GRP20, MAXWELL_TEX0_OUTPUT_RED_GRP20, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_SUST_NONATOM, maxwell_tex1_store_sector_misses_sust_nonatom_enc_str_1,  MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM_GRP20, {MAXWELL_TEX1_OUTPUT_SUST_GRP20, MAXWELL_TEX1_OUTPUT_ATOM_OR_ATOM_CAS_GRP20, MAXWELL_TEX1_OUTPUT_RED_GRP20, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX0_STORE_SECTOR_MISSES_SUST_ATOM_OR_ATOM_CAS, maxwell_tex0_store_sector_misses_sust_atom_or_atom_cas_enc_str_1,  MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM_GRP20, {MAXWELL_TEX0_OUTPUT_SUST_GRP20, MAXWELL_TEX0_OUTPUT_ATOM_OR_ATOM_CAS_GRP20, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_SUST_ATOM_OR_ATOM_CAS, maxwell_tex1_store_sector_misses_sust_atom_or_atom_cas_enc_str_1,  MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM_GRP20, {MAXWELL_TEX1_OUTPUT_SUST_GRP20, MAXWELL_TEX1_OUTPUT_ATOM_OR_ATOM_CAS_GRP20, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX0_STORE_SECTOR_MISSES_SUST_RED, maxwell_tex0_store_sector_misses_sust_red_enc_str_1,  MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM_GRP20, {MAXWELL_TEX0_OUTPUT_SUST_GRP20, MAXWELL_TEX0_OUTPUT_RED_GRP20, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_SUST_RED, maxwell_tex1_store_sector_misses_sust_red_enc_str_1,  MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM_GRP20, {MAXWELL_TEX1_OUTPUT_SUST_GRP20, MAXWELL_TEX1_OUTPUT_RED_GRP20, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_TEX0_WRITE_SECTORS_GLOBAL_NONATOM, maxwell_tex0_write_sectors_global_nonatom_enc_str_1, MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM_GRP20, {MAXWELL_TEX0_OUTPUT_GLOBAL_GRP20, MAXWELL_TEX0_OUTPUT_ATOM_OR_ATOM_CAS_GRP20, MAXWELL_TEX0_OUTPUT_RED_GRP20, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX1_WRITE_SECTORS_GLOBAL_NONATOM, maxwell_tex1_write_sectors_global_nonatom_enc_str_1, MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM_GRP20, {MAXWELL_TEX1_OUTPUT_GLOBAL_GRP20, MAXWELL_TEX1_OUTPUT_ATOM_OR_ATOM_CAS_GRP20, MAXWELL_TEX1_OUTPUT_RED_GRP20, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX0_WRITE_SECTORS_GLOBAL_ATOM, maxwell_tex0_write_sectors_global_atom_enc_str_1, MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM_GRP20, {MAXWELL_TEX0_OUTPUT_GLOBAL_GRP20, MAXWELL_TEX0_OUTPUT_ATOM_OR_ATOM_CAS_GRP20, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX1_WRITE_SECTORS_GLOBAL_ATOM, maxwell_tex1_write_sectors_global_atom_enc_str_1, MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM_GRP20, {MAXWELL_TEX1_OUTPUT_GLOBAL_GRP20, MAXWELL_TEX1_OUTPUT_ATOM_OR_ATOM_CAS_GRP20, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX0_WRITE_SECTORS_GLOBAL_RED, maxwell_tex0_write_sectors_global_red_enc_str_1, MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM_GRP20, {MAXWELL_TEX0_OUTPUT_GLOBAL_GRP20, MAXWELL_TEX0_OUTPUT_RED_GRP20, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX1_WRITE_SECTORS_GLOBAL_RED, maxwell_tex1_write_sectors_global_red_enc_str_1, MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM_GRP20, {MAXWELL_TEX1_OUTPUT_GLOBAL_GRP20, MAXWELL_TEX1_OUTPUT_RED_GRP20, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX0_WRITE_SECTORS_LOCAL_ST, maxwell_tex0_write_sectors_local_st_enc_str_1, MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM_GRP20, {MAXWELL_TEX0_OUTPUT_LOCAL_GRP20, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX1_WRITE_SECTORS_LOCAL_ST, maxwell_tex1_write_sectors_local_st_enc_str_1, MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM_GRP20, {MAXWELL_TEX1_OUTPUT_LOCAL_GRP20, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},

//Store sector queries - misses at m2
    { MAXWELL_TEX0_STORE_SECTOR_QURIES_GLOBAL,   maxwell_tex0_store_sector_queries_global_enc_str_1, MAXWELL_TEX0_M2_SECTOR_MISSES_WRITE_SUM_2d, {MAXWELL_TEX0_M2_MISSES_GLOBAL_2d, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_STORE_SECTOR_QURIES_GLOBAL,   maxwell_tex1_store_sector_queries_global_enc_str_1, MAXWELL_TEX1_M2_SECTOR_MISSES_WRITE_SUM_2d, {MAXWELL_TEX1_M2_MISSES_GLOBAL_2d, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX0_STORE_SECTOR_QURIES_LOCAL,    maxwell_tex0_store_sector_queries_local_enc_str_1,  MAXWELL_TEX0_M2_SECTOR_MISSES_WRITE_SUM_2d, {MAXWELL_TEX0_M2_MISSES_LOCAL_2d, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_STORE_SECTOR_QURIES_LOCAL,    maxwell_tex1_store_sector_queries_local_enc_str_1,  MAXWELL_TEX1_M2_SECTOR_MISSES_WRITE_SUM_2d, {MAXWELL_TEX1_M2_MISSES_LOCAL_2d, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX0_STORE_SECTOR_QURIES_ATOM_CAS, maxwell_tex0_store_sector_queries_atom_cas_enc_str_1, MAXWELL_TEX0_M2_SECTOR_MISSES_WRITE_SUM_2d, {MAXWELL_TEX0_M2_MISSES_LG_ATOM_CAS_2d, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_STORE_SECTOR_QURIES_ATOM_CAS, maxwell_tex1_store_sector_queries_atom_cas_enc_str_1, MAXWELL_TEX1_M2_SECTOR_MISSES_WRITE_SUM_2d, {MAXWELL_TEX1_M2_MISSES_LG_ATOM_CAS_2d, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX0_STORE_SECTOR_QURIES_ATOM,     maxwell_tex0_store_sector_queries_atom_enc_str_1, MAXWELL_TEX0_M2_SECTOR_MISSES_WRITE_SUM_2d, {MAXWELL_TEX0_M2_MISSES_LG_ATOM_2d, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_STORE_SECTOR_QURIES_ATOM,     maxwell_tex1_store_sector_queries_atom_enc_str_1, MAXWELL_TEX1_M2_SECTOR_MISSES_WRITE_SUM_2d, {MAXWELL_TEX1_M2_MISSES_LG_ATOM_2d, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX0_STORE_SECTOR_QURIES_RED,     maxwell_tex0_store_sector_queries_red_enc_str_1, MAXWELL_TEX0_M2_SECTOR_MISSES_WRITE_SUM_2d, {MAXWELL_TEX0_M2_MISSES_LG_RED_2d, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_STORE_SECTOR_QURIES_RED,     maxwell_tex1_store_sector_queries_red_enc_str_1, MAXWELL_TEX1_M2_SECTOR_MISSES_WRITE_SUM_2d, {MAXWELL_TEX1_M2_MISSES_LG_RED_2d, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},

//Load sector queries - misses at m2.
    { MAXWELL_TEX0_LOAD_SECTOR_QURIES_GLOBAL,   maxwell_tex0_load_sector_queries_global_enc_str_1, MAXWELL_TEX0_M2_SECTOR_MISSES_READ_SUM_27, {MAXWELL_TEX0_M2_MISSES_GLOBAL_27, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_LOAD_SECTOR_QURIES_GLOBAL,   maxwell_tex1_load_sector_queries_global_enc_str_1, MAXWELL_TEX1_M2_SECTOR_MISSES_READ_SUM_27, {MAXWELL_TEX1_M2_MISSES_GLOBAL_27, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX0_LOAD_SECTOR_QURIES_LOCAL,    maxwell_tex0_load_sector_queries_local_enc_str_1,  MAXWELL_TEX0_M2_SECTOR_MISSES_READ_SUM_27, {MAXWELL_TEX0_M2_MISSES_LOCAL_27, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_LOAD_SECTOR_QURIES_LOCAL,    maxwell_tex1_load_sector_queries_local_enc_str_1,  MAXWELL_TEX1_M2_SECTOR_MISSES_READ_SUM_27, {MAXWELL_TEX1_M2_MISSES_LOCAL_27, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX0_LOAD_SECTOR_QURIES_ATOM_CAS, maxwell_tex0_load_sector_queries_atom_cas_enc_str_1, MAXWELL_TEX0_M2_SECTOR_MISSES_READ_SUM_27, {MAXWELL_TEX0_M2_MISSES_LG_ATOM_CAS_27, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_LOAD_SECTOR_QURIES_ATOM_CAS, maxwell_tex1_load_sector_queries_atom_cas_enc_str_1, MAXWELL_TEX1_M2_SECTOR_MISSES_READ_SUM_27, {MAXWELL_TEX1_M2_MISSES_LG_ATOM_CAS_27, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX0_LOAD_SECTOR_QURIES_ATOM,     maxwell_tex0_load_sector_queries_atom_enc_str_1, MAXWELL_TEX0_M2_SECTOR_MISSES_READ_SUM_27, {MAXWELL_TEX0_M2_MISSES_LG_ATOM_27, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { MAXWELL_TEX1_LOAD_SECTOR_QURIES_ATOM,     maxwell_tex1_load_sector_queries_atom_enc_str_1, MAXWELL_TEX1_M2_SECTOR_MISSES_READ_SUM_27, {MAXWELL_TEX1_M2_MISSES_LG_ATOM_27, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},

    { MAXWELL_TEX0_TEX_QUAD_COUNT, maxwell_tex0_tex_quad_count_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_TEX0_SM2TEX_REQ_PVLD, MAXWELL_TEX0_SM2TEX_REQ_PRDY, MAXWELL_TEX0_C0_IS_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX1_TEX_QUAD_COUNT, maxwell_tex1_tex_quad_count_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_TEX1_SM2TEX_REQ_PVLD, MAXWELL_TEX1_SM2TEX_REQ_PRDY, MAXWELL_TEX1_C0_IS_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_TEX0_GLOBAL_LD_REQUESTS_8BIT , maxwell_tex0_global_ld_requests_8bit_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_TEX0_GLOBAL_LD_REQUESTS_4B, MAXWELL_TEX0_NUM_8_BIT_4B, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX1_GLOBAL_LD_REQUESTS_8BIT , maxwell_tex1_global_ld_requests_8bit_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_TEX1_GLOBAL_LD_REQUESTS_4B, MAXWELL_TEX1_NUM_8_BIT_4B, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX0_GLOBAL_LD_REQUESTS_16BIT , maxwell_tex0_global_ld_requests_16bit_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_TEX0_GLOBAL_LD_REQUESTS_4B, MAXWELL_TEX0_NUM_16_BIT_4B, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX1_GLOBAL_LD_REQUESTS_16BIT , maxwell_tex1_global_ld_requests_16bit_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_TEX1_GLOBAL_LD_REQUESTS_4B, MAXWELL_TEX1_NUM_16_BIT_4B, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX0_GLOBAL_LD_REQUESTS_FP16X2 , maxwell_tex0_global_ld_requests_fp16x2_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_TEX0_GLOBAL_LD_REQUESTS_4B, MAXWELL_TEX0_NUM_FP16X2_4B, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX1_GLOBAL_LD_REQUESTS_FP16X2 , maxwell_tex1_global_ld_requests_fp16x2_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_TEX1_GLOBAL_LD_REQUESTS_4B, MAXWELL_TEX1_NUM_FP16X2_4B, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX0_GLOBAL_LD_REQUESTS_32BIT , maxwell_tex0_global_ld_requests_32bit_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_TEX0_GLOBAL_LD_REQUESTS_4C, MAXWELL_TEX0_NUM_32_BIT_4C, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX1_GLOBAL_LD_REQUESTS_32BIT , maxwell_tex1_global_ld_requests_32bit_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_TEX1_GLOBAL_LD_REQUESTS_4C, MAXWELL_TEX1_NUM_32_BIT_4C, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX0_GLOBAL_LD_REQUESTS_64BIT , maxwell_tex0_global_ld_requests_64bit_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_TEX0_GLOBAL_LD_REQUESTS_4C, MAXWELL_TEX0_NUM_64_BIT_4C, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX1_GLOBAL_LD_REQUESTS_64BIT , maxwell_tex1_global_ld_requests_64bit_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_TEX1_GLOBAL_LD_REQUESTS_4C, MAXWELL_TEX1_NUM_64_BIT_4C, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX0_GLOBAL_LD_REQUESTS_128BIT , maxwell_tex0_global_ld_requests_128bit_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_TEX0_GLOBAL_LD_REQUESTS_4C, MAXWELL_TEX0_NUM_128_BIT_4C, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { MAXWELL_TEX1_GLOBAL_LD_REQUESTS_128BIT , maxwell_tex1_global_ld_requests_128bit_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_TEX1_GLOBAL_LD_REQUESTS_4C, MAXWELL_TEX1_NUM_128_BIT_4C, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},

    { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000,  0x00},
};
#endif /* NVCFG(GLOBAL_GPU_FAMILY_GM20X) || NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)*/

PerfSignalHwpm PerfSignalTableGM000_fbp0[] = {
    //FBP signals
    { MAXWELL_FB_SUBP0_DRAMC_READ,          maxwell_fb_subp0_dramc_read_enc_str_1,            0x00000011, 0x0000AAAA,  0x00000000,   PM_UNIT_FB,1 },
    { MAXWELL_FB_SUBP1_DRAMC_READ,          maxwell_fb_subp1_dramc_read_enc_str_1,            0x00000012, 0x0000AAAA,  0x00000000,   PM_UNIT_FB,1 },
    { MAXWELL_FB_SUBP0_DRAMC_WRITE,         maxwell_fb_subp0_dramc_write_enc_str_1,           0x00000011, 0x0000AAAA,  0x00000001,   PM_UNIT_FB,1 },
    { MAXWELL_FB_SUBP1_DRAMC_WRITE,         maxwell_fb_subp1_dramc_write_enc_str_1,           0x00000012, 0x0000AAAA,  0x00000001,   PM_UNIT_FB,1 },

    // fb_dram_activates_subp0_fbp0_pa0       = fbpa02pm_subp0_actarb_activate      "Number of bank activates in subpartition-0"
    // fb_dram_activates_subp1_fbp0_pa0       = fbpa02pm_subp1_actarb_activate      "Number of bank activates in subpartition-1"
    { MAXWELL_FB_SUBP0_DRAM_ACTIVATES,      maxwell_fb_subp0_dram_activates_enc_str_1,             0x00000001, 0x0000AAAA,  0x00000006,   PM_UNIT_FB,1 },
    { MAXWELL_FB_SUBP1_DRAM_ACTIVATES,      maxwell_fb_subp1_dram_activates_enc_str_1,             0x00000002, 0x0000AAAA,  0x00000006,   PM_UNIT_FB,1 },
    { INVALID_PM_SIGNAL_NEW,        "",                                 0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

//To match the output with pmlsplitter, use perfmon 0 for slice 0 and 2
PerfSignalHwpm PerfSignalTableGM000_ltc0[] = {
    //LTC signals
    // l2_subp0_write_sector_misses = ltc_ltc2fb_dirty_dat0_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 0
    // l2_subp1_write_sector_misses = ltc_ltc2fb_dirty_dat1_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 1
    // l2_subp0_read_sector_misses  = ltc_fb2ltc_rdat0_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 0
    // l2_subp1_read_sector_misses  = ltc_fb2ltc_rdat1_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 1
    // l2_subp0_write_l1_sector_queries = ltc2pm_ltc_lts0_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 0
    // l2_subp1_write_l1_sector_queries = ltc2pm_ltc_lts1_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 1
    // l2_subp0_read_l1_sector_queries  = ltc2pm_ltc_lts0_request_rd_op && ltc2pm_ltc_lts1_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 0
    // l2_subp1_read_l1_sector_queries  = ltc2pm_ltc_lts1_request_rd_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 1

    {MAXWELL_LTC0_WRITE_MISS_SECTORS, maxwell_ltc0_write_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x26, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC0_READ_MISS_SECTORS, maxwell_ltc0_read_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x27, PM_UNIT_LTS1, 1},

    {MAXWELL_LTC0_HIT_SECTORS, maxwell_ltc0_hit_sectors_enc_str_1, 0x1, 0xffff, 0x18, PM_UNIT_LTS, 4},
    {MAXWELL_LTC0_REQUEST_SECTORS, maxwell_ltc0_request_sectors_enc_str_1, 0x0, 0xffff, 0x18, PM_UNIT_LTS, 4},
    {MAXWELL_LTC0_MISS_SECTORS, maxwell_ltc0_miss_sectors_enc_str_1, 0x4, 0xffff, 0x1c, PM_UNIT_LTS, 4},

    {MAXWELL_LTC0_REQUEST_SRC_UNIT_L1, maxwell_ltc0_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x20, PM_UNIT_LTS2, 1},
    {MAXWELL_LTC0_REQUEST_SRC_UNIT_TEX, maxwell_ltc0_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x20, PM_UNIT_LTS2, 1},
    {MAXWELL_LTC0_REQUEST_SRC_UNIT_GCC, maxwell_ltc0_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x20, PM_UNIT_LTS2, 1},

    {MAXWELL_LTC0_REQUEST_ACTIVE, maxwell_ltc0_request_active_enc_str_1, 0x0, 0xaaaa, 0x23, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC0_REQUEST_RD_OP, maxwell_ltc0_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x36, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC0_REQUEST_WR_OP, maxwell_ltc0_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x35, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC0_REQUEST_ATOMIC_OP, maxwell_ltc0_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x34, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC0_REQUEST_APERTURE_SYSMEM, maxwell_ltc0_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x30, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC0_REQUEST_APERTURE_VIDMEM, maxwell_ltc0_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x2f, PM_UNIT_LTS1, 1},

    {MAXWELL_LTC0_HIT, maxwell_ltc0_hit_enc_str_1, 0x0, 0xaaaa, 0x2a, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC0_REQUEST, maxwell_ltc0_request_enc_str_1, 0x0, 0xaaaa, 0x22, PM_UNIT_LTS1, 1},

    {MAXWELL_LTC1_WRITE_MISS_SECTORS, maxwell_ltc1_write_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x4, PM_UNIT_LTS1_1, 1},
    {MAXWELL_LTC1_READ_MISS_SECTORS, maxwell_ltc1_read_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x5, PM_UNIT_LTS1_1, 1},

    {MAXWELL_LTC1_HIT_SECTORS, maxwell_ltc1_hit_sectors_enc_str_1, 0x1, 0xffff, 0x1c, PM_UNIT_LTS_1, 4},
    {MAXWELL_LTC1_REQUEST_SECTORS, maxwell_ltc1_request_sectors_enc_str_1, 0x0, 0xffff, 0x1c, PM_UNIT_LTS_1, 4},
    {MAXWELL_LTC1_MISS_SECTORS, maxwell_ltc1_miss_sectors_enc_str_1, 0x4, 0xffff, 0x20, PM_UNIT_LTS_1, 4},

    {MAXWELL_LTC1_REQUEST_SRC_UNIT_L1, maxwell_ltc1_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x21, PM_UNIT_LTS2_1, 1},
    {MAXWELL_LTC1_REQUEST_SRC_UNIT_TEX, maxwell_ltc1_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x21, PM_UNIT_LTS2_1, 1},
    {MAXWELL_LTC1_REQUEST_SRC_UNIT_GCC, maxwell_ltc1_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x21, PM_UNIT_LTS2_1, 1},

    {MAXWELL_LTC1_REQUEST_ACTIVE, maxwell_ltc1_request_active_enc_str_1, 0x0, 0xaaaa, 0x1, PM_UNIT_LTS1_1, 1},
    {MAXWELL_LTC1_REQUEST_RD_OP, maxwell_ltc1_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x14, PM_UNIT_LTS1_1, 1},
    {MAXWELL_LTC1_REQUEST_WR_OP, maxwell_ltc1_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x13, PM_UNIT_LTS1_1, 1},
    {MAXWELL_LTC1_REQUEST_ATOMIC_OP, maxwell_ltc1_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x12, PM_UNIT_LTS1_1, 1},
    {MAXWELL_LTC1_REQUEST_APERTURE_SYSMEM, maxwell_ltc1_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0xe, PM_UNIT_LTS1_1, 1},
    {MAXWELL_LTC1_REQUEST_APERTURE_VIDMEM, maxwell_ltc1_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0xd, PM_UNIT_LTS1_1, 1},

    {MAXWELL_LTC1_HIT, maxwell_ltc1_hit_enc_str_1, 0x0, 0xaaaa, 0x8, PM_UNIT_LTS1_1, 1},
    {MAXWELL_LTC1_REQUEST, maxwell_ltc1_request_enc_str_1, 0x0, 0xaaaa, 0x0, PM_UNIT_LTS1_1, 1},

    { INVALID_PM_SIGNAL_NEW,        "",                                 0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpmExpt PerfSignalTableGM000_ltc0_expt[] = {
    //write a combination of the signals.

    // ltc_read_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { MAXWELL_LTC0_READ_TEX_SECTORS_FBP, maxwell_ltc0_read_tex_sectors_fbp_enc_str_1, MAXWELL_LTC0_REQUEST_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_RD_OP, MAXWELL_LTC0_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_request_sectors_src_unit_tex_op_atomic_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_request_atomic_op
    { MAXWELL_LTC0_ATOMIC_TEX_SECTORS_FBP, maxwell_ltc0_atomic_tex_sectors_fbp_enc_str_1, MAXWELL_LTC0_REQUEST_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_ATOMIC_OP, MAXWELL_LTC0_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { MAXWELL_LTC0_WRITE_TEX_SECTORS_FBP, maxwell_ltc0_write_tex_sectors_fbp_enc_str_1, MAXWELL_LTC0_REQUEST_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_WR_OP, MAXWELL_LTC0_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_hit_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_hit
    { MAXWELL_LTC0_READ_TEX_HIT_SECTORS_FBP, maxwell_ltc0_read_tex_hit_sectors_fbp_enc_str_1,  MAXWELL_LTC0_HIT_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_RD_OP, MAXWELL_LTC0_REQUEST_SRC_UNIT_TEX, MAXWELL_LTC0_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},

    { MAXWELL_LTC0_WRITE_TEX_HIT_SECTORS_FBP, maxwell_ltc0_write_tex_hit_sectors_fbp_enc_str_1,  MAXWELL_LTC0_HIT_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_WR_OP, MAXWELL_LTC0_REQUEST_SRC_UNIT_TEX, MAXWELL_LTC0_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},

    { MAXWELL_LTC0_READ_SYSMEM_SECTORS_FBP, maxwell_ltc0_read_sysmem_sectors_fbp_enc_str_1, MAXWELL_LTC0_REQUEST_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_RD_OP, MAXWELL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { MAXWELL_LTC0_WRITE_SYSMEM_SECTORS_FBP, maxwell_ltc0_write_sysmem_sectors_fbp_enc_str_1, MAXWELL_LTC0_REQUEST_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_WR_OP, MAXWELL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { MAXWELL_LTC0_TOTAL_READ_SECTORS_FBP, maxwell_ltc0_total_read_sectors_fbp_enc_str_1, MAXWELL_LTC0_REQUEST_SECTORS, {MAXWELL_LTC0_REQUEST_ATOMIC_OP, MAXWELL_LTC0_REQUEST_RD_OP, MAXWELL_LTC0_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { MAXWELL_LTC0_TOTAL_WRITE_SECTORS_FBP, maxwell_ltc0_total_write_sectors_fbp_enc_str_1, MAXWELL_LTC0_REQUEST_SECTORS, {MAXWELL_LTC0_REQUEST_ATOMIC_OP, MAXWELL_LTC0_REQUEST_WR_OP, MAXWELL_LTC0_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { MAXWELL_LTC0_READ_VIDMEM_SECTORS_FBP,      maxwell_ltc0_read_vidmem_sectors_fbp_enc_str_1,    MAXWELL_LTC0_REQUEST_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_RD_OP, MAXWELL_LTC0_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { MAXWELL_LTC0_WRITE_VIDMEM_SECTORS_FBP,      maxwell_ltc0_write_vidmem_sectors_fbp_enc_str_1,    MAXWELL_LTC0_REQUEST_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_WR_OP, MAXWELL_LTC0_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { MAXWELL_LTC0_READ_SYSMEM_HIT_SECTORS_FBP, maxwell_ltc0_read_sysmem_hit_sectors_fbp_enc_str_1, MAXWELL_LTC0_HIT_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_RD_OP, MAXWELL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_LTC0_WRITE_SYSMEM_HIT_SECTORS_FBP, maxwell_ltc0_write_sysmem_hit_sectors_fbp_enc_str_1, MAXWELL_LTC0_HIT_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_WR_OP, MAXWELL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_LTC0_READ_SYSMEM_MISS_SECTORS_FBP, maxwell_ltc0_read_sysmem_miss_sectors_fbp_enc_str_1, MAXWELL_LTC0_MISS_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_RD_OP, MAXWELL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_LTC0_WRITE_SYSMEM_MISS_SECTORS_FBP, maxwell_ltc0_write_sysmem_miss_sectors_fbp_enc_str_1, MAXWELL_LTC0_MISS_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_WR_OP, MAXWELL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_pm_request_src_unit_gcc_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_src_unit_gcc & ltc2pm_ltc_lts0_request
    { MAXWELL_LTC0_PM_REQ_SRC_UNIT_GCC_FBP,      maxwell_ltc0_pm_req_src_unit_gcc_fbp_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC0_REQUEST, MAXWELL_LTC0_REQUEST_SRC_UNIT_GCC, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},

    // ltc_read_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { MAXWELL_LTC1_READ_TEX_SECTORS_FBP, maxwell_ltc1_read_tex_sectors_fbp_enc_str_1, MAXWELL_LTC1_REQUEST_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_RD_OP, MAXWELL_LTC1_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_request_sectors_src_unit_tex_op_atomic_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_request_atomic_op
    { MAXWELL_LTC1_ATOMIC_TEX_SECTORS_FBP, maxwell_ltc1_atomic_tex_sectors_fbp_enc_str_1, MAXWELL_LTC1_REQUEST_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_ATOMIC_OP, MAXWELL_LTC1_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_sectors_tex_fbp0_l2slice1 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { MAXWELL_LTC1_WRITE_TEX_SECTORS_FBP, maxwell_ltc1_write_tex_sectors_fbp_enc_str_1, MAXWELL_LTC1_REQUEST_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_WR_OP, MAXWELL_LTC1_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_hit_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_hit
    { MAXWELL_LTC1_READ_TEX_HIT_SECTORS_FBP, maxwell_ltc1_read_tex_hit_sectors_fbp_enc_str_1,  MAXWELL_LTC1_HIT_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_RD_OP, MAXWELL_LTC1_REQUEST_SRC_UNIT_TEX, MAXWELL_LTC1_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},

    { MAXWELL_LTC1_WRITE_TEX_HIT_SECTORS_FBP, maxwell_ltc1_write_tex_hit_sectors_fbp_enc_str_1,  MAXWELL_LTC1_HIT_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_WR_OP, MAXWELL_LTC1_REQUEST_SRC_UNIT_TEX, MAXWELL_LTC1_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},

    { MAXWELL_LTC1_READ_SYSMEM_SECTORS_FBP, maxwell_ltc1_read_sysmem_sectors_fbp_enc_str_1, MAXWELL_LTC1_REQUEST_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_RD_OP, MAXWELL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { MAXWELL_LTC1_WRITE_SYSMEM_SECTORS_FBP, maxwell_ltc1_write_sysmem_sectors_fbp_enc_str_1, MAXWELL_LTC1_REQUEST_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_WR_OP, MAXWELL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { MAXWELL_LTC1_TOTAL_READ_SECTORS_FBP, maxwell_ltc1_total_read_sectors_fbp_enc_str_1, MAXWELL_LTC1_REQUEST_SECTORS, {MAXWELL_LTC1_REQUEST_ATOMIC_OP, MAXWELL_LTC1_REQUEST_RD_OP, MAXWELL_LTC1_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { MAXWELL_LTC1_TOTAL_WRITE_SECTORS_FBP, maxwell_ltc1_total_write_sectors_fbp_enc_str_1, MAXWELL_LTC1_REQUEST_SECTORS, {MAXWELL_LTC1_REQUEST_ATOMIC_OP, MAXWELL_LTC1_REQUEST_WR_OP, MAXWELL_LTC1_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { MAXWELL_LTC1_READ_VIDMEM_SECTORS_FBP,      maxwell_ltc1_read_vidmem_sectors_fbp_enc_str_1,    MAXWELL_LTC1_REQUEST_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_RD_OP, MAXWELL_LTC1_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { MAXWELL_LTC1_WRITE_VIDMEM_SECTORS_FBP,      maxwell_ltc1_write_vidmem_sectors_fbp_enc_str_1,    MAXWELL_LTC1_REQUEST_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_WR_OP, MAXWELL_LTC1_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { MAXWELL_LTC1_READ_SYSMEM_HIT_SECTORS_FBP, maxwell_ltc1_read_sysmem_hit_sectors_fbp_enc_str_1, MAXWELL_LTC1_HIT_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_RD_OP, MAXWELL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_LTC1_WRITE_SYSMEM_HIT_SECTORS_FBP, maxwell_ltc1_write_sysmem_hit_sectors_fbp_enc_str_1, MAXWELL_LTC1_HIT_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_WR_OP, MAXWELL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_LTC1_READ_SYSMEM_MISS_SECTORS_FBP, maxwell_ltc1_read_sysmem_miss_sectors_fbp_enc_str_1, MAXWELL_LTC1_MISS_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_RD_OP, MAXWELL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_LTC1_WRITE_SYSMEM_MISS_SECTORS_FBP, maxwell_ltc1_write_sysmem_miss_sectors_fbp_enc_str_1, MAXWELL_LTC1_MISS_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_WR_OP, MAXWELL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_pm_request_src_unit_gcc_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_src_unit_gcc & ltc2pm_ltc_lts0_request
    { MAXWELL_LTC1_PM_REQ_SRC_UNIT_GCC_FBP,      maxwell_ltc1_pm_req_src_unit_gcc_fbp_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC1_REQUEST, MAXWELL_LTC1_REQUEST_SRC_UNIT_GCC, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},

    { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000,  0x00},
};

//To match the output with pmlsplitter, use perfmon 0 for slice 1 and 3
PerfSignalHwpm PerfSignalTableGM000_ltc1[] = {
    //LTC signals
    // l2_subp0_write_sector_misses = ltc_ltc2fb_dirty_dat0_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 0
    // l2_subp1_write_sector_misses = ltc_ltc2fb_dirty_dat1_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 1
    // l2_subp0_read_sector_misses  = ltc_fb2ltc_rdat0_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 0
    // l2_subp1_read_sector_misses  = ltc_fb2ltc_rdat1_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 1
    // l2_subp0_write_l1_sector_queries = ltc2pm_ltc_lts0_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 0
    // l2_subp1_write_l1_sector_queries = ltc2pm_ltc_lts1_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 1
    // l2_subp0_read_l1_sector_queries  = ltc2pm_ltc_lts0_request_rd_op && ltc2pm_ltc_lts1_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 0
    // l2_subp1_read_l1_sector_queries  = ltc2pm_ltc_lts1_request_rd_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 1

    {MAXWELL_LTC2_WRITE_MISS_SECTORS, maxwell_ltc2_write_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x26, PM_UNIT_LTS1_2, 1},
    {MAXWELL_LTC2_READ_MISS_SECTORS, maxwell_ltc2_read_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x27, PM_UNIT_LTS1_2, 1},

    {MAXWELL_LTC2_HIT_SECTORS, maxwell_ltc2_hit_sectors_enc_str_1, 0x1, 0xffff, 0x18, PM_UNIT_LTS_2, 4},
    {MAXWELL_LTC2_REQUEST_SECTORS, maxwell_ltc2_request_sectors_enc_str_1, 0x0, 0xffff, 0x18, PM_UNIT_LTS_2, 4},
    {MAXWELL_LTC2_MISS_SECTORS, maxwell_ltc2_miss_sectors_enc_str_1, 0x2, 0xffff, 0x18, PM_UNIT_LTS_2, 4},

    {MAXWELL_LTC2_REQUEST_SRC_UNIT_L1, maxwell_ltc2_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x20, PM_UNIT_LTS2_2, 1},
    {MAXWELL_LTC2_REQUEST_SRC_UNIT_TEX, maxwell_ltc2_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x20, PM_UNIT_LTS2_2, 1},
    {MAXWELL_LTC2_REQUEST_SRC_UNIT_GCC, maxwell_ltc2_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x20, PM_UNIT_LTS2_2, 1},

    {MAXWELL_LTC2_REQUEST_ACTIVE, maxwell_ltc2_request_active_enc_str_1, 0x0, 0xaaaa, 0x23, PM_UNIT_LTS1_2, 1},
    {MAXWELL_LTC2_REQUEST_RD_OP, maxwell_ltc2_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x36, PM_UNIT_LTS1_2, 1},
    {MAXWELL_LTC2_REQUEST_WR_OP, maxwell_ltc2_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x35, PM_UNIT_LTS1_2, 1},
    {MAXWELL_LTC2_REQUEST_ATOMIC_OP, maxwell_ltc2_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x34, PM_UNIT_LTS1_2, 1},
    {MAXWELL_LTC2_REQUEST_APERTURE_SYSMEM, maxwell_ltc2_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x30, PM_UNIT_LTS1_2, 1},
    {MAXWELL_LTC2_REQUEST_APERTURE_VIDMEM, maxwell_ltc2_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x2f, PM_UNIT_LTS1_2, 1},

    {MAXWELL_LTC2_HIT, maxwell_ltc2_hit_enc_str_1, 0x0, 0xaaaa, 0x2a, PM_UNIT_LTS1_2, 1},
    {MAXWELL_LTC2_REQUEST, maxwell_ltc2_request_enc_str_1, 0x0, 0xaaaa, 0x22, PM_UNIT_LTS1_2, 1},

    {MAXWELL_LTC3_WRITE_MISS_SECTORS, maxwell_ltc3_write_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x4, PM_UNIT_LTS1_3, 1},
    {MAXWELL_LTC3_READ_MISS_SECTORS, maxwell_ltc3_read_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x5, PM_UNIT_LTS1_3, 1},

    {MAXWELL_LTC3_HIT_SECTORS, maxwell_ltc3_hit_sectors_enc_str_1, 0x1, 0xffff, 0x1c, PM_UNIT_LTS_3, 4},
    {MAXWELL_LTC3_REQUEST_SECTORS, maxwell_ltc3_request_sectors_enc_str_1, 0x0, 0xffff, 0x1c, PM_UNIT_LTS_3, 4},
    {MAXWELL_LTC3_MISS_SECTORS, maxwell_ltc3_miss_sectors_enc_str_1, 0x2, 0xffff, 0x1c, PM_UNIT_LTS_3, 4},

    {MAXWELL_LTC3_REQUEST_SRC_UNIT_L1, maxwell_ltc3_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x21, PM_UNIT_LTS2_3, 1},
    {MAXWELL_LTC3_REQUEST_SRC_UNIT_TEX, maxwell_ltc3_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x21, PM_UNIT_LTS2_3, 1},
    {MAXWELL_LTC3_REQUEST_SRC_UNIT_GCC, maxwell_ltc3_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x21, PM_UNIT_LTS2_3, 1},

    {MAXWELL_LTC3_REQUEST_ACTIVE, maxwell_ltc3_request_active_enc_str_1, 0x0, 0xaaaa, 0x1, PM_UNIT_LTS1_3, 1},
    {MAXWELL_LTC3_REQUEST_RD_OP, maxwell_ltc3_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x14, PM_UNIT_LTS1_3, 1},
    {MAXWELL_LTC3_REQUEST_WR_OP, maxwell_ltc3_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x13, PM_UNIT_LTS1_3, 1},
    {MAXWELL_LTC3_REQUEST_ATOMIC_OP, maxwell_ltc3_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x12, PM_UNIT_LTS1_3, 1},
    {MAXWELL_LTC3_REQUEST_APERTURE_SYSMEM, maxwell_ltc3_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0xe, PM_UNIT_LTS1_3, 1},
    {MAXWELL_LTC3_REQUEST_APERTURE_VIDMEM, maxwell_ltc3_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0xd, PM_UNIT_LTS1_3, 1},

    {MAXWELL_LTC3_HIT, maxwell_ltc3_hit_enc_str_1, 0x0, 0xaaaa, 0x8, PM_UNIT_LTS1_3, 1},
    {MAXWELL_LTC3_REQUEST, maxwell_ltc3_request_enc_str_1, 0x0, 0xaaaa, 0x0, PM_UNIT_LTS1_3, 1},

    { INVALID_PM_SIGNAL_NEW,        "",                                 0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpmExpt PerfSignalTableGM000_ltc1_expt[] = {
    //Event group mask is calculated from NV_PLTC_MISC_LTC_PM, excluding the PM_ENABLE bit
    //NV_PLTC_MISC_LTC_PM_SECTOR_MUX_SELECT : 0xe
    //NV_PLTC_MISC_LTC_PM_SELECT : 0x1F0
    //NV_PLTC_MISC_LTC_PM_SRCUNIT_MUX_SELECT : 0x3E00
    //Final mask: 0x00003FFE
    //write a combination of the signals.

    // ltc_read_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { MAXWELL_LTC2_READ_TEX_SECTORS_FBP, maxwell_ltc2_read_tex_sectors_fbp_enc_str_1, MAXWELL_LTC2_REQUEST_SECTORS, {MAXWELL_LTC2_REQUEST_ACTIVE, MAXWELL_LTC2_REQUEST_RD_OP, MAXWELL_LTC2_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_request_sectors_src_unit_tex_op_atomic_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_request_atomic_op
    { MAXWELL_LTC2_ATOMIC_TEX_SECTORS_FBP, maxwell_ltc2_atomic_tex_sectors_fbp_enc_str_1, MAXWELL_LTC2_REQUEST_SECTORS, {MAXWELL_LTC2_REQUEST_ACTIVE, MAXWELL_LTC2_REQUEST_ATOMIC_OP, MAXWELL_LTC2_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { MAXWELL_LTC2_WRITE_TEX_SECTORS_FBP, maxwell_ltc2_write_tex_sectors_fbp_enc_str_1, MAXWELL_LTC2_REQUEST_SECTORS, {MAXWELL_LTC2_REQUEST_ACTIVE, MAXWELL_LTC2_REQUEST_WR_OP, MAXWELL_LTC2_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_hit_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_hit
    { MAXWELL_LTC2_READ_TEX_HIT_SECTORS_FBP, maxwell_ltc2_read_tex_hit_sectors_fbp_enc_str_1,  MAXWELL_LTC2_HIT_SECTORS, {MAXWELL_LTC2_REQUEST_ACTIVE, MAXWELL_LTC2_REQUEST_RD_OP, MAXWELL_LTC2_REQUEST_SRC_UNIT_TEX, MAXWELL_LTC2_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},

    { MAXWELL_LTC2_WRITE_TEX_HIT_SECTORS_FBP, maxwell_ltc2_write_tex_hit_sectors_fbp_enc_str_1,  MAXWELL_LTC2_HIT_SECTORS, {MAXWELL_LTC2_REQUEST_ACTIVE, MAXWELL_LTC2_REQUEST_WR_OP, MAXWELL_LTC2_REQUEST_SRC_UNIT_TEX, MAXWELL_LTC2_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},

    { MAXWELL_LTC2_READ_SYSMEM_SECTORS_FBP, maxwell_ltc2_read_sysmem_sectors_fbp_enc_str_1, MAXWELL_LTC2_REQUEST_SECTORS, {MAXWELL_LTC2_REQUEST_ACTIVE, MAXWELL_LTC2_REQUEST_RD_OP, MAXWELL_LTC2_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { MAXWELL_LTC2_WRITE_SYSMEM_SECTORS_FBP, maxwell_ltc2_write_sysmem_sectors_fbp_enc_str_1, MAXWELL_LTC2_REQUEST_SECTORS, {MAXWELL_LTC2_REQUEST_ACTIVE, MAXWELL_LTC2_REQUEST_WR_OP, MAXWELL_LTC2_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { MAXWELL_LTC2_TOTAL_READ_SECTORS_FBP, maxwell_ltc2_total_read_sectors_fbp_enc_str_1, MAXWELL_LTC2_REQUEST_SECTORS, {MAXWELL_LTC2_REQUEST_ATOMIC_OP, MAXWELL_LTC2_REQUEST_RD_OP, MAXWELL_LTC2_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { MAXWELL_LTC2_TOTAL_WRITE_SECTORS_FBP, maxwell_ltc2_total_write_sectors_fbp_enc_str_1, MAXWELL_LTC2_REQUEST_SECTORS, {MAXWELL_LTC2_REQUEST_ATOMIC_OP, MAXWELL_LTC2_REQUEST_WR_OP, MAXWELL_LTC2_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { MAXWELL_LTC2_READ_VIDMEM_SECTORS_FBP,      maxwell_ltc2_read_vidmem_sectors_fbp_enc_str_1,    MAXWELL_LTC2_REQUEST_SECTORS, {MAXWELL_LTC2_REQUEST_ACTIVE, MAXWELL_LTC2_REQUEST_RD_OP, MAXWELL_LTC2_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { MAXWELL_LTC2_WRITE_VIDMEM_SECTORS_FBP,      maxwell_ltc2_write_vidmem_sectors_fbp_enc_str_1,    MAXWELL_LTC2_REQUEST_SECTORS, {MAXWELL_LTC2_REQUEST_ACTIVE, MAXWELL_LTC2_REQUEST_WR_OP, MAXWELL_LTC2_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_pm_request_src_unit_gcc_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_src_unit_gcc & ltc2pm_ltc_lts0_request
    { MAXWELL_LTC2_PM_REQ_SRC_UNIT_GCC_FBP,      maxwell_ltc2_pm_req_src_unit_gcc_fbp_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC2_REQUEST, MAXWELL_LTC2_REQUEST_SRC_UNIT_GCC, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},

    { MAXWELL_LTC2_READ_SYSMEM_HIT_SECTORS_FBP, maxwell_ltc2_read_sysmem_hit_sectors_fbp_enc_str_1, MAXWELL_LTC2_HIT_SECTORS, {MAXWELL_LTC2_REQUEST_ACTIVE, MAXWELL_LTC2_REQUEST_RD_OP, MAXWELL_LTC2_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_LTC2_WRITE_SYSMEM_HIT_SECTORS_FBP, maxwell_ltc2_write_sysmem_hit_sectors_fbp_enc_str_1, MAXWELL_LTC2_HIT_SECTORS, {MAXWELL_LTC2_REQUEST_ACTIVE, MAXWELL_LTC2_REQUEST_WR_OP, MAXWELL_LTC2_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_LTC2_READ_SYSMEM_MISS_SECTORS_FBP, maxwell_ltc2_read_sysmem_miss_sectors_fbp_enc_str_1, MAXWELL_LTC2_MISS_SECTORS, {MAXWELL_LTC2_REQUEST_ACTIVE, MAXWELL_LTC2_REQUEST_RD_OP, MAXWELL_LTC2_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_LTC2_WRITE_SYSMEM_MISS_SECTORS_FBP, maxwell_ltc2_write_sysmem_miss_sectors_fbp_enc_str_1, MAXWELL_LTC2_MISS_SECTORS, {MAXWELL_LTC2_REQUEST_ACTIVE, MAXWELL_LTC2_REQUEST_WR_OP, MAXWELL_LTC2_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},    

    // ltc_read_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { MAXWELL_LTC3_READ_TEX_SECTORS_FBP, maxwell_ltc3_read_tex_sectors_fbp_enc_str_1, MAXWELL_LTC3_REQUEST_SECTORS, {MAXWELL_LTC3_REQUEST_ACTIVE, MAXWELL_LTC3_REQUEST_RD_OP, MAXWELL_LTC3_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_request_sectors_src_unit_tex_op_atomic_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_request_atomic_op
    { MAXWELL_LTC3_ATOMIC_TEX_SECTORS_FBP, maxwell_ltc3_atomic_tex_sectors_fbp_enc_str_1, MAXWELL_LTC3_REQUEST_SECTORS, {MAXWELL_LTC3_REQUEST_ACTIVE, MAXWELL_LTC3_REQUEST_ATOMIC_OP, MAXWELL_LTC3_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { MAXWELL_LTC3_WRITE_TEX_SECTORS_FBP, maxwell_ltc3_write_tex_sectors_fbp_enc_str_1, MAXWELL_LTC3_REQUEST_SECTORS, {MAXWELL_LTC3_REQUEST_ACTIVE, MAXWELL_LTC3_REQUEST_WR_OP, MAXWELL_LTC3_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_hit_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_hit
    { MAXWELL_LTC3_READ_TEX_HIT_SECTORS_FBP, maxwell_ltc3_read_tex_hit_sectors_fbp_enc_str_1,  MAXWELL_LTC3_HIT_SECTORS, {MAXWELL_LTC3_REQUEST_ACTIVE, MAXWELL_LTC3_REQUEST_RD_OP, MAXWELL_LTC3_REQUEST_SRC_UNIT_TEX, MAXWELL_LTC3_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},

    { MAXWELL_LTC3_WRITE_TEX_HIT_SECTORS_FBP, maxwell_ltc3_write_tex_hit_sectors_fbp_enc_str_1,  MAXWELL_LTC3_HIT_SECTORS, {MAXWELL_LTC3_REQUEST_ACTIVE, MAXWELL_LTC3_REQUEST_WR_OP, MAXWELL_LTC3_REQUEST_SRC_UNIT_TEX, MAXWELL_LTC3_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},

    { MAXWELL_LTC3_READ_SYSMEM_SECTORS_FBP, maxwell_ltc3_read_sysmem_sectors_fbp_enc_str_1, MAXWELL_LTC3_REQUEST_SECTORS, {MAXWELL_LTC3_REQUEST_ACTIVE, MAXWELL_LTC3_REQUEST_RD_OP, MAXWELL_LTC3_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { MAXWELL_LTC3_WRITE_SYSMEM_SECTORS_FBP, maxwell_ltc3_write_sysmem_sectors_fbp_enc_str_1, MAXWELL_LTC3_REQUEST_SECTORS, {MAXWELL_LTC3_REQUEST_ACTIVE, MAXWELL_LTC3_REQUEST_WR_OP, MAXWELL_LTC3_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { MAXWELL_LTC3_TOTAL_READ_SECTORS_FBP, maxwell_ltc3_total_read_sectors_fbp_enc_str_1, MAXWELL_LTC3_REQUEST_SECTORS, {MAXWELL_LTC3_REQUEST_ATOMIC_OP, MAXWELL_LTC3_REQUEST_RD_OP, MAXWELL_LTC3_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { MAXWELL_LTC3_TOTAL_WRITE_SECTORS_FBP, maxwell_ltc3_total_write_sectors_fbp_enc_str_1, MAXWELL_LTC3_REQUEST_SECTORS, {MAXWELL_LTC3_REQUEST_ATOMIC_OP, MAXWELL_LTC3_REQUEST_WR_OP, MAXWELL_LTC3_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { MAXWELL_LTC3_READ_VIDMEM_SECTORS_FBP,      maxwell_ltc3_read_vidmem_sectors_fbp_enc_str_1,    MAXWELL_LTC3_REQUEST_SECTORS, {MAXWELL_LTC3_REQUEST_ACTIVE, MAXWELL_LTC3_REQUEST_RD_OP, MAXWELL_LTC3_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { MAXWELL_LTC3_WRITE_VIDMEM_SECTORS_FBP,      maxwell_ltc3_write_vidmem_sectors_fbp_enc_str_1,    MAXWELL_LTC3_REQUEST_SECTORS, {MAXWELL_LTC3_REQUEST_ACTIVE, MAXWELL_LTC3_REQUEST_WR_OP, MAXWELL_LTC3_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_pm_request_src_unit_gcc_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_src_unit_gcc & ltc2pm_ltc_lts0_request
    { MAXWELL_LTC3_PM_REQ_SRC_UNIT_GCC_FBP,      maxwell_ltc3_pm_req_src_unit_gcc_fbp_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC3_REQUEST, MAXWELL_LTC3_REQUEST_SRC_UNIT_GCC, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},

    { MAXWELL_LTC3_READ_SYSMEM_HIT_SECTORS_FBP, maxwell_ltc3_read_sysmem_hit_sectors_fbp_enc_str_1, MAXWELL_LTC3_HIT_SECTORS, {MAXWELL_LTC3_REQUEST_ACTIVE, MAXWELL_LTC3_REQUEST_RD_OP, MAXWELL_LTC3_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_LTC3_WRITE_SYSMEM_HIT_SECTORS_FBP, maxwell_ltc3_write_sysmem_hit_sectors_fbp_enc_str_1, MAXWELL_LTC3_HIT_SECTORS, {MAXWELL_LTC3_REQUEST_ACTIVE, MAXWELL_LTC3_REQUEST_WR_OP, MAXWELL_LTC3_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_LTC3_READ_SYSMEM_MISS_SECTORS_FBP, maxwell_ltc3_read_sysmem_miss_sectors_fbp_enc_str_1, MAXWELL_LTC3_MISS_SECTORS, {MAXWELL_LTC3_REQUEST_ACTIVE, MAXWELL_LTC3_REQUEST_RD_OP, MAXWELL_LTC3_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_LTC3_WRITE_SYSMEM_MISS_SECTORS_FBP, maxwell_ltc3_write_sysmem_miss_sectors_fbp_enc_str_1, MAXWELL_LTC3_MISS_SECTORS, {MAXWELL_LTC3_REQUEST_ACTIVE, MAXWELL_LTC3_REQUEST_WR_OP, MAXWELL_LTC3_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000,  0x00},
};

PerfSignalSmpc PerfSignalTableGM000_sm0[] = {

    { MAXWELL_SM_PROF_TRIGGER_00,  maxwell_sm_prof_trigger_00_enc_str_1, 0x00000000, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig0"
    { MAXWELL_SM_PROF_TRIGGER_01,  maxwell_sm_prof_trigger_01_enc_str_1, 0x00000000, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig1"
    { MAXWELL_SM_PROF_TRIGGER_02,  maxwell_sm_prof_trigger_02_enc_str_1, 0x00000000, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig2"
    { MAXWELL_SM_PROF_TRIGGER_03,  maxwell_sm_prof_trigger_03_enc_str_1, 0x00000000, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig3"
    { MAXWELL_SM_PROF_TRIGGER_04,  maxwell_sm_prof_trigger_04_enc_str_1, 0x00000000, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig4"
    { MAXWELL_SM_PROF_TRIGGER_05,  maxwell_sm_prof_trigger_05_enc_str_1, 0x00000000, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig5"
    { MAXWELL_SM_PROF_TRIGGER_06,  maxwell_sm_prof_trigger_06_enc_str_1, 0x00000000, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig6"
    { MAXWELL_SM_PROF_TRIGGER_07,  maxwell_sm_prof_trigger_07_enc_str_1, 0x00000000, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig7"
    { MAXWELL_SM_PMTRIG8,  maxwell_sm_pmtrig8_enc_str_1, 0x00000001, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig8"
    { MAXWELL_SM_PMTRIG9,  maxwell_sm_pmtrig9_enc_str_1, 0x00000001, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig9"
    { MAXWELL_SM_PMTRIG10,  maxwell_sm_pmtrig10_enc_str_1, 0x00000001, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig10"
    { MAXWELL_SM_PMTRIG11,  maxwell_sm_pmtrig11_enc_str_1, 0x00000001, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig11"
    { MAXWELL_SM_PMTRIG12,  maxwell_sm_pmtrig12_enc_str_1, 0x00000001, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig12"
    { MAXWELL_SM_PMTRIG13,  maxwell_sm_pmtrig13_enc_str_1, 0x00000001, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig13"
    { MAXWELL_SM_PMTRIG14,  maxwell_sm_pmtrig14_enc_str_1, 0x00000001, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig14"
    { MAXWELL_SM_PMTRIG15,  maxwell_sm_pmtrig15_enc_str_1, 0x00000001, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig15"
    { MAXWELL_SM_NON_IDLE_QUAD,  maxwell_sm_non_idle_quad_enc_str_1, 0x00000002, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "non_idle"
    { MAXWELL_SM_ACTIVE_CYCLES_QUAD,  maxwell_sm_active_cycles_quad_enc_str_1, 0x00000002, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "active_cycles_quad"
    { MAXWELL_SM_WARPS_LAUNCHED,  maxwell_sm_warps_launched_enc_str_1, 0x00000002, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "warps_launched"
    { MAXWELL_SM_INST_ISSUED0,  maxwell_sm_inst_issued0_enc_str_1, 0x00000002, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_issued0"
    { MAXWELL_SM_INST_ISSUED1,  maxwell_sm_inst_issued1_enc_str_1, 0x00000002, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_issued1"
    { MAXWELL_SM_INST_ISSUED2,  maxwell_sm_inst_issued2_enc_str_1, 0x00000002, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_issued2"
    { MAXWELL_SM_INST_EXECUTED,  maxwell_sm_inst_executed_enc_str_1, 0x00000002, 0x00000076, 0x00000003, PM_UNIT_SMQCTL,  2}, //    "inst_executed"
    { MAXWELL_SM_ACTIVE_WARPS_QUAD,  maxwell_sm_active_warps_quad_enc_str_1, 0x00000003, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5}, //    "active_warps_quad"
    { MAXWELL_SM_WARPS_ON_DECK,  maxwell_sm_warps_on_deck_enc_str_1, 0x00000003, 0x00000765, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "warps_on_deck"
    { MAXWELL_SM_THREAD_INST_EXECUTED,  maxwell_sm_thread_inst_executed_enc_str_1, 0x00000004, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL,  6}, //    "thread_inst_executed"
    { MAXWELL_SM_WARPS_MOVED_ON_DECK,  maxwell_sm_warps_moved_on_deck_enc_str_1, 0x00000004, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "warps_moved_on_deck"
    { MAXWELL_SM_WARPS_MOVED_OFF_DECK,  maxwell_sm_warps_moved_off_deck_enc_str_1, 0x00000004, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "warps_moved_off_deck"
    { MAXWELL_SM_NOT_PREDICATED_OFF_THREAD_INST_EXECUTED,  maxwell_sm_not_predicated_off_thread_inst_executed_enc_str_1, 0x00000005, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL,  6}, //    "not_predicated_off_thread_inst_executed"
    { MAXWELL_SM_TRAP_IN_TRAP_QUAD,  maxwell_sm_trap_in_trap_quad_enc_str_1, 0x00000005, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "trap_in_trap"
    { MAXWELL_SM_WARP_CANT_ISSUE_DRAIN,  maxwell_sm_warp_cant_issue_drain_enc_str_1, 0x00000006, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5}, //    "warp_cant_issue_drain"
    { MAXWELL_SM_WARP_CANT_ISSUE_ON_DECK_SHORT_SCOREBOARD,  maxwell_sm_warp_cant_issue_on_deck_short_scoreboard_enc_str_1, 0x00000006, 0x00000765, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "warp_cant_issue_on_deck_short_scoreboard"
    { MAXWELL_SM_WARP_CANT_ISSUE_ICACHE_MISS,  maxwell_sm_warp_cant_issue_icache_miss_enc_str_1, 0x00000007, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5}, //    "warp_cant_issue_icache_miss"
    { MAXWELL_SM_WARP_CANT_ISSUE_WAIT,  maxwell_sm_warp_cant_issue_wait_enc_str_1, 0x00000007, 0x00000765, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "warp_cant_issue_wait"
    { MAXWELL_SM_WARP_CANT_ISSUE_IMC_MISS,  maxwell_sm_warp_cant_issue_imc_miss_enc_str_1, 0x00000008, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5}, //    "warp_cant_issue_imc_miss"
    { MAXWELL_SM_WARP_CANT_ISSUE_NO_INSTRUCTIONS,  maxwell_sm_warp_cant_issue_no_instructions_enc_str_1, 0x00000008, 0x00000765, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "warp_cant_issue_no_instructions"
    { MAXWELL_SM_WARP_CANT_ISSUE_LONG_SCOREBOARD,  maxwell_sm_warp_cant_issue_long_scoreboard_enc_str_1, 0x00000009, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5}, //    "warp_cant_issue_long_scoreboard"
    { MAXWELL_SM_WARP_CANT_ISSUE_SHADOW_PIPE_THROTTLE,  maxwell_sm_warp_cant_issue_shadow_pipe_throttle_enc_str_1, 0x00000009, 0x00000765, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "warp_cant_issue_shadow_pipe_throttle"
    { MAXWELL_SM_WARP_CANT_ISSUE_BARRIER,  maxwell_sm_warp_cant_issue_barrier_enc_str_1, 0x0000000a, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5}, //    "warp_cant_issue_barrier"
    { MAXWELL_SM_WARP_CANT_ISSUE_TEX_THROTTLE,  maxwell_sm_warp_cant_issue_tex_throttle_enc_str_1, 0x0000000a, 0x00000765, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "warp_cant_issue_tex_throttle"
    { MAXWELL_SM_WARP_CANT_ISSUE_OFF_DECK_SHORT_SCOREBOARD,  maxwell_sm_warp_cant_issue_off_deck_short_scoreboard_enc_str_1, 0x0000000b, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5}, //    "warp_cant_issue_off_deck_short_scoreboard"
    { MAXWELL_SM_WARP_CANT_ISSUE_MIO_THROTTLE,  maxwell_sm_warp_cant_issue_mio_throttle_enc_str_1, 0x0000000b, 0x00000765, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "warp_cant_issue_mio_throttle"
    { MAXWELL_SM_WARP_CANT_ISSUE_TILE_ALLOCATION_STALL,  maxwell_sm_warp_cant_issue_tile_allocation_stall_enc_str_1, 0x0000000c, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5}, //    "warp_cant_issue_tile_allocation_stall"
    { MAXWELL_SM_WARP_CANT_ISSUE_DISPATCH_STALL,  maxwell_sm_warp_cant_issue_dispatch_stall_enc_str_1, 0x0000000c, 0x00000765, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "warp_cant_issue_dispatch_stall"
    { MAXWELL_SM_WARP_CANT_ISSUE_ALLOCATION_STALL_NO_SPACE,  maxwell_sm_warp_cant_issue_allocation_stall_no_space_enc_str_1, 0x0000000d, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5}, //    "warp_cant_issue_allocation_stall_no_space"
    { MAXWELL_SM_WARP_CANT_ISSUE_NOT_SELECTED,  maxwell_sm_warp_cant_issue_not_selected_enc_str_1, 0x0000000d, 0x00000065, 0x00000003, PM_UNIT_SMQCTL,  2}, //    "warp_cant_issue_not_selected"
    { MAXWELL_SM_WARP_CANT_ISSUE_SELECTED,  maxwell_sm_warp_cant_issue_selected_enc_str_1, 0x0000000d, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "warp_cant_issue_selected"
    { MAXWELL_SM_WARP_CANT_ISSUE_ALLOCATION_STALL_NOT_ELIGIBLE,  maxwell_sm_warp_cant_issue_allocation_stall_not_eligible_enc_str_1, 0x0000000e, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5}, //    "warp_cant_issue_allocation_stall_not_eligible"
    { MAXWELL_SM_WARP_CANT_ISSUE_MISC,  maxwell_sm_warp_cant_issue_misc_enc_str_1, 0x0000000f, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5}, //    "warp_cant_issue_misc"
    { MAXWELL_SM_WARP_CANT_ISSUE_ON_DECK_MISC,  maxwell_sm_warp_cant_issue_on_deck_misc_enc_str_1, 0x0000000f, 0x00000765, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "warp_cant_issue_on_deck_misc"
    { MAXWELL_SM_WARP_ISSUE_ELIGIBLE,  maxwell_sm_warp_issue_eligible_enc_str_1, 0x00000010, 0x00000210, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "warp_issue_eligible"
    { MAXWELL_SM_WARP_CANT_ISSUE_MEMBAR,  maxwell_sm_warp_cant_issue_membar_enc_str_1, 0x00000010, 0x00076543, 0x0000001f, PM_UNIT_SMQCTL,  5}, //    "warp_cant_issue_membar"
    { MAXWELL_SM_CANT_DISPATCH_REGISTER_READ,  maxwell_sm_cant_dispatch_register_read_enc_str_1, 0x00000011, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "cant_dispatch_register_read"
    { MAXWELL_SM_CANT_DISPATCH_REGISTER_WRITE,  maxwell_sm_cant_dispatch_register_write_enc_str_1, 0x00000011, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "cant_dispatch_register_write"
    { MAXWELL_SM_CANT_DISPATCH_POWER_THROTTLE,  maxwell_sm_cant_dispatch_power_throttle_enc_str_1, 0x00000011, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "cant_dispatch_power_throttle"
    { MAXWELL_SM_CANT_DISPATCH_PREDCC_WRITE,  maxwell_sm_cant_dispatch_predcc_write_enc_str_1, 0x00000011, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "cant_dispatch_predcc_write"
    { MAXWELL_SM_CANT_DISPATCH_DIVERGED_CHAIN_IPA,  maxwell_sm_cant_dispatch_diverged_chain_ipa_enc_str_1, 0x00000011, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "cant_dispatch_diverged_chain_ipa"
    { MAXWELL_SM_CANT_DISPATCH_DIVERGED_GENERIC_LD_ST,  maxwell_sm_cant_dispatch_diverged_generic_ld_st_enc_str_1, 0x00000011, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "cant_dispatch_diverged_generic_ld_st"
    { MAXWELL_SM_INST_EXECUTED_DECOUPLED_PRED_OFF,  maxwell_sm_inst_executed_decoupled_pred_off_enc_str_1, 0x00000012, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_decoupled_pred_off"
    { MAXWELL_SM_INST_EXECUTED_COUPLED_PRED_OFF,  maxwell_sm_inst_executed_coupled_pred_off_enc_str_1, 0x00000012, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_coupled_pred_off"
    { MAXWELL_SM_INST_EXECUTED_32B,  maxwell_sm_inst_executed_32b_enc_str_1, 0x00000012, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_32b"
    { MAXWELL_SM_INST_EXECUTED_64B,  maxwell_sm_inst_executed_64b_enc_str_1, 0x00000012, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_64b"
    { MAXWELL_SM_INST_EXECUTED_128B,  maxwell_sm_inst_executed_128b_enc_str_1, 0x00000012, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_128b"
    { MAXWELL_SM_INST_EXECUTED_U128B,  maxwell_sm_inst_executed_u128b_enc_str_1, 0x00000012, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_U128b"
    { MAXWELL_SM_GENERIC_SHARED,  maxwell_sm_generic_shared_enc_str_1, 0x00000012, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_lsu_generic_shared"
    { MAXWELL_SM_GENERIC_TEX,  maxwell_sm_generic_tex_enc_str_1, 0x00000012, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_lsu_generic_tex"
    { MAXWELL_SM_LOCAL_STORE,  maxwell_sm_local_store_enc_str_1, 0x00000013, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_local_st"
    { MAXWELL_SM_LOCAL_LOAD,  maxwell_sm_local_load_enc_str_1, 0x00000013, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_local_ld"
    { MAXWELL_SM_SHARED_LOAD,  maxwell_sm_shared_load_enc_str_1, 0x00000013, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_shared_ld"
    { MAXWELL_SM_SHARED_STORE,  maxwell_sm_shared_store_enc_str_1, 0x00000013, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_shared_st"
    { MAXWELL_SM_SHARED_ATOM_CAS,  maxwell_sm_shared_atom_cas_enc_str_1, 0x00000013, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_shared_atom_cas"
    { MAXWELL_SM_SHARED_ATOM,  maxwell_sm_shared_atom_enc_str_1, 0x00000013, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_shared_atom"
    { MAXWELL_SM_ATTRIBUTE_STORE,  maxwell_sm_attribute_store_enc_str_1, 0x00000013, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_attribute_st"
    { MAXWELL_SM_ATTRIBUTE_LOAD,  maxwell_sm_attribute_load_enc_str_1, 0x00000013, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_attribute_ld"
    { MAXWELL_SM_GLOBAL_ATOM_CAS,  maxwell_sm_global_atom_cas_enc_str_1, 0x00000014, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_global_atom_cas"
    { MAXWELL_SM_GLOBAL_ATOM,  maxwell_sm_global_atom_enc_str_1, 0x00000014, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_global_atom"
    { MAXWELL_SM_GLOBAL_RED,  maxwell_sm_global_red_enc_str_1, 0x00000014, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_global_red"
    { MAXWELL_SM_GLOBAL_LOAD,  maxwell_sm_global_load_enc_str_1, 0x00000014, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_global_ld"
    { MAXWELL_SM_GLOBAL_STORE,  maxwell_sm_global_store_enc_str_1, 0x00000014, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_global_st"
    { MAXWELL_SM_GENERIC_LOAD,  maxwell_sm_generic_load_enc_str_1, 0x00000014, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_generic_ld"
    { MAXWELL_SM_GENERIC_STORE,  maxwell_sm_generic_store_enc_str_1, 0x00000014, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_generic_st"
    { MAXWELL_SM_SURFACE_ATOM,  maxwell_sm_surface_atom_enc_str_1, 0x00000015, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_surface_atom"
    { MAXWELL_SM_SURFACE_ATOM_CAS,  maxwell_sm_surface_atom_cas_enc_str_1, 0x00000015, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_surface_atom_cas"
    { MAXWELL_SM_SURFACE_RED,  maxwell_sm_surface_red_enc_str_1, 0x00000015, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_surface_red"
    { MAXWELL_SM_SURFACE_LOAD,  maxwell_sm_surface_load_enc_str_1, 0x00000015, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_surface_ld"
    { MAXWELL_SM_SURFACE_STORE,  maxwell_sm_surface_store_enc_str_1, 0x00000015, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_surface_st"
    { MAXWELL_SM_INST_ROLLBACKED,  maxwell_sm_inst_rollbacked_enc_str_1, 0x00000015, 0x00000765, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "inst_rollbacked"
    { MAXWELL_SM_ROLLBACKS_IMC,  maxwell_sm_rollbacks_imc_enc_str_1, 0x00000016, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "rollbacks_imc"
    { MAXWELL_SM_TEX_WB_REQUESTS_PENDING,  maxwell_sm_tex_wb_requests_pending_enc_str_1, 0x00000016, 0x00654321, 0x0000003f, PM_UNIT_SMQCTL,  6}, //    "tex_wb_requests_pending"
    { MAXWELL_SM_TEX_WB_REQUESTS,  maxwell_sm_tex_wb_requests_enc_str_1, 0x00000016, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "tex_wb_requests"
    { MAXWELL_SM_IMC_HIT,  maxwell_sm_imc_hit_enc_str_1, 0x00000017, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "imc_hit"
    { MAXWELL_SM_IMC_FULL_TAG,  maxwell_sm_imc_full_tag_enc_str_1, 0x00000017, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "imc_full_tag"
    { MAXWELL_SM_IMC_TRUE_MISS,  maxwell_sm_imc_true_miss_enc_str_1, 0x00000017, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "imc_true_miss"
    { MAXWELL_SM_IMC_COVERED_MISS,  maxwell_sm_imc_covered_miss_enc_str_1, 0x00000017, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "imc_covered_miss"
    { MAXWELL_SM_IMC_MISSES_OUTSTANDING,  maxwell_sm_imc_misses_outstanding_enc_str_1, 0x00000017, 0x00000654, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "imc_misses_outstanding"
    { MAXWELL_SM_FET_FETCHED_LINES,  maxwell_sm_fet_fetched_lines_enc_str_1, 0x00000017, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "fet_fetched_lines"
    { MAXWELL_SM_INST_EXECUTED_ADU_PIPE,  maxwell_sm_inst_executed_adu_pipe_enc_str_1, 0x00000018, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_adu_pipe"
    { MAXWELL_SM_INST_EXECUTED_BRU_PIPE,  maxwell_sm_inst_executed_bru_pipe_enc_str_1, 0x00000018, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_bru_pipe"
    { MAXWELL_SM_INST_EXECUTED_LDC_PIPE,  maxwell_sm_inst_executed_ldc_pipe_enc_str_1, 0x00000018, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_ldc_pipe"
    { MAXWELL_SM_INST_EXECUTED_LSU_PIPE,  maxwell_sm_inst_executed_lsu_pipe_enc_str_1, 0x00000018, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_lsu_pipe"
    { MAXWELL_SM_INST_EXECUTED_XU_PIPE,  maxwell_sm_inst_executed_xu_pipe_enc_str_1, 0x00000018, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_xu_pipe"
    { MAXWELL_SM_INST_EXECUTED_TEX_PIPE,  maxwell_sm_inst_executed_tex_pipe_enc_str_1, 0x00000018, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_tex_pipe"
    { MAXWELL_SM_INST_EXECUTED_FMAI_PIPE,  maxwell_sm_inst_executed_fmai_pipe_enc_str_1, 0x00000018, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_fmai_pipe"
    { MAXWELL_SM_INST_EXECUTED_FXU_PIPE,  maxwell_sm_inst_executed_fxu_pipe_enc_str_1, 0x00000018, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_fxu_pipe"
    { MAXWELL_SM_INST_EXECUTED_FMA64LITE_PIPE,  maxwell_sm_inst_executed_fma64lite_pipe_enc_str_1, 0x00000019, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_fma64lite_pipe"
    { MAXWELL_SM_INST_EXECUTED_FMA64PLUS_PIPE,  maxwell_sm_inst_executed_fma64plus_pipe_enc_str_1, 0x00000019, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_fma64plus_pipe"
    { MAXWELL_SM_INST_EXECUTED_FMA64PLUSPLUS_PIPE,  maxwell_sm_inst_executed_fma64plusplus_pipe_enc_str_1, 0x00000019, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_fma64plusplus_pipe"
    { MAXWELL_SM_INST_EXECUTED_BAR_PIPE,  maxwell_sm_inst_executed_bar_pipe_enc_str_1, 0x00000019, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_bar_pipe"
    { MAXWELL_SM_INST_EXECUTED_FE_PIPE,  maxwell_sm_inst_executed_fe_pipe_enc_str_1, 0x00000019, 0x00000054, 0x00000003, PM_UNIT_SMQCTL,  2}, //    "inst_executed_fe_pipe"
    { MAXWELL_SM_INST_EXECUTED_VOTE_VTG,  maxwell_sm_inst_executed_vote_vtg_enc_str_1, 0x00000019, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_vote_vtg"
    { MAXWELL_SM_INST_EXECUTED_SU_PIPE,  maxwell_sm_inst_executed_su_pipe_enc_str_1, 0x00000019, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_su_pipe"
    { MAXWELL_SM_UNWINDING_BR_EXECUTED,  maxwell_sm_unwinding_br_executed_enc_str_1, 0x0000001a, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "unwinding_br_executed"
    { MAXWELL_SM_DIVERGED_BR_EXECUTED,  maxwell_sm_diverged_br_executed_enc_str_1, 0x0000001a, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "diverged_br_executed"
    { MAXWELL_SM_UNIQUE_IDX_BR_EXECUTED,  maxwell_sm_unique_idx_br_executed_enc_str_1, 0x0000001a, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "unique_idx_br_executed"
    { MAXWELL_SM_RVAL_DIV_IDX_BR_EXECUTED,  maxwell_sm_rval_div_idx_br_executed_enc_str_1, 0x0000001a, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "rval_div_idx_br_executed"
    { MAXWELL_SM_BRANCH,  maxwell_sm_branch_enc_str_1, 0x0000001a, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "br_executed"
    { MAXWELL_SM_TAKEN_BR_EXECUTED,  maxwell_sm_taken_br_executed_enc_str_1, 0x0000001a, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "taken_br_executed"
    { MAXWELL_SM_PRED_DIV_IDX_BR_EXECUTED,  maxwell_sm_pred_div_idx_br_executed_enc_str_1, 0x0000001a, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pred_div_idx_br_executed"
    { MAXWELL_SM_CRS_FILL,  maxwell_sm_crs_fill_enc_str_1, 0x0000001b, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "crs_fill"
    { MAXWELL_SM_CRS_SPILL,  maxwell_sm_crs_spill_enc_str_1, 0x0000001b, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "crs_spill"
    { MAXWELL_SM_CRS_PUSH_ACTION,  maxwell_sm_crs_push_action_enc_str_1, 0x0000001b, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "crs_push_action"
    { MAXWELL_SM_TEX_REQUESTS,  maxwell_sm_tex_requests_enc_str_1, 0x0000001b, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "tex_requests"
    { MAXWELL_SM_TEX_REQ_ACTIVE,  maxwell_sm_tex_req_active_enc_str_1, 0x0000001b, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "tex_req_active"
    { MAXWELL_SM_TEX_REQ_STALLED,  maxwell_sm_tex_req_stalled_enc_str_1, 0x0000001b, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "tex_req_stalled"
    { MAXWELL_SM_TEX_REQ_STARVED,  maxwell_sm_tex_req_starved_enc_str_1, 0x0000001b, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "tex_req_starved"
    { MAXWELL_SM_TEX_REQ_IDLE,  maxwell_sm_tex_req_idle_enc_str_1, 0x0000001b, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "tex_req_idle"
    { MAXWELL_SM_LSU_WB_OPS_PENDING,  maxwell_sm_lsu_wb_ops_pending_enc_str_1, 0x0000001c, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL,  6}, //    "lsu_wb_ops_pending"
    { MAXWELL_SM_INST_EXECUTED_LSU_WB_OPS,  maxwell_sm_inst_executed_lsu_wb_ops_enc_str_1, 0x0000001c, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_lsu_wb_ops"
    { MAXWELL_SM_TEX_INST_PENDING,  maxwell_sm_tex_inst_pending_enc_str_1, 0x0000001d, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL,  6}, //    "tex_inst_pending"
    { MAXWELL_SM_TEX_WB_INST_EXECUTED,  maxwell_sm_tex_wb_inst_executed_enc_str_1, 0x0000001d, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "tex_wb_inst_executed"

//CORE/MIO Signals:

    { MAXWELL_SM_NON_IDLE,  maxwell_sm_non_idle_enc_str_1, 0x00000000, 0x00000000, 0x00000001, PM_UNIT_SMCORE,  1}, //    "non_idle"
    { MAXWELL_SM_ACTIVE_CYCLES,  maxwell_sm_active_cycles_enc_str_1, 0x00000000, 0x00000001, 0x00000001, PM_UNIT_SMCORE,  1}, //    "active_cycles"
    { MAXWELL_SM_ACTIVE_WARPS,  maxwell_sm_active_warps_enc_str_1, 0x00000000, 0x00765432, 0x0000003f, PM_UNIT_SMCORE,  6}, //    "active_warps"
    { MAXWELL_SM_ACTIVE_CTAS,  maxwell_sm_active_ctas_enc_str_1, 0x00000001, 0x00543210, 0x0000003f, PM_UNIT_SMCORE,  6}, //    "active_ctas"
    { MAXWELL_SM_CTA_LAUNCHED,  maxwell_sm_cta_launched_enc_str_1, 0x00000001, 0x00000006, 0x00000001, PM_UNIT_SMCORE,  1}, //    "ctas_launched"
    { MAXWELL_SM_LSU_BUSY,  maxwell_sm_lsu_busy_enc_str_1, 0x00000001, 0x00000007, 0x00000001, PM_UNIT_SMCORE,  1}, //    "lsu_busy"
    { MAXWELL_SM_ACTIVE_WARPS_PS,  maxwell_sm_active_warps_ps_enc_str_1, 0x00000002, 0x00543210, 0x0000003f, PM_UNIT_SMCORE,  6}, //    "active_warps_ps"
    { MAXWELL_SM_ACTIVE_WARPS_VTG,  maxwell_sm_active_warps_vtg_enc_str_1, 0x00000003, 0x00543210, 0x0000003f, PM_UNIT_SMCORE,  6}, //    "active_warps_vtg"
    { MAXWELL_SM_ACTIVE_SUBTILES,  maxwell_sm_active_subtiles_enc_str_1, 0x00000004, 0x00543210, 0x0000003f, PM_UNIT_SMCORE,  6}, //    "active_subtiles"
    { MAXWELL_SM_SUBTILES_LAUNCHED_H0,  maxwell_sm_subtiles_launched_h0_enc_str_1, 0x00000004, 0x00000006, 0x00000001, PM_UNIT_SMCORE,  1}, //    "subtiles_launched_h0"
    { MAXWELL_SM_SUBTILES_LAUNCHED_H1,  maxwell_sm_subtiles_launched_h1_enc_str_1, 0x00000004, 0x00000007, 0x00000001, PM_UNIT_SMCORE,  1}, //    "subtiles_launched_h1"
    { MAXWELL_SM_TRAP_COALESCING,  maxwell_sm_trap_coalescing_enc_str_1, 0x00000005, 0x00000000, 0x00000001, PM_UNIT_SMCORE,  1}, //    "trap_coalescing"
    { MAXWELL_SM_TRAP_COUNT,  maxwell_sm_trap_count_enc_str_1, 0x00000005, 0x00000001, 0x00000001, PM_UNIT_SMCORE,  1}, //    "trap_count"
    { MAXWELL_SM_TRAP_IDLING_FOR_TRAP,  maxwell_sm_trap_idling_for_trap_enc_str_1, 0x00000005, 0x00000002, 0x00000001, PM_UNIT_SMCORE,  1}, //    "trap_idling_for_trap"
    { MAXWELL_SM_TRAP_IN_TRAP,  maxwell_sm_trap_in_trap_enc_str_1, 0x00000005, 0x00000003, 0x00000001, PM_UNIT_SMCORE,  1}, //    "trap_in_trap"
    { MAXWELL_SM_TRAP_STALL_LAUNCHES,  maxwell_sm_trap_stall_launches_enc_str_1, 0x00000005, 0x00000004, 0x00000001, PM_UNIT_SMCORE,  1}, //    "trap_stall_launches"
    { MAXWELL_SM_TRAP_WAITING_FOR_IDE,  maxwell_sm_trap_waiting_for_ide_enc_str_1, 0x00000005, 0x00000005, 0x00000001, PM_UNIT_SMCORE,  1}, //    "trap_waiting_for_ide"
    { MAXWELL_SM_ICC_HIT,  maxwell_sm_icc_hit_enc_str_1, 0x00000006, 0x00000000, 0x00000001, PM_UNIT_SMCORE,  1}, //    "icc_hit"
    { MAXWELL_SM_ICC_TRUE_MISS,  maxwell_sm_icc_true_miss_enc_str_1, 0x00000006, 0x00000001, 0x00000001, PM_UNIT_SMCORE,  1}, //    "icc_true_miss"
    { MAXWELL_SM_ICC_COVERED_MISS,  maxwell_sm_icc_covered_miss_enc_str_1, 0x00000006, 0x00000002, 0x00000001, PM_UNIT_SMCORE,  1}, //    "icc_covered_miss"
    { MAXWELL_SM_ICC_FULL_TAG,  maxwell_sm_icc_full_tag_enc_str_1, 0x00000006, 0x00000003, 0x00000001, PM_UNIT_SMCORE,  1}, //    "icc_full_tag"
    { MAXWELL_SM_ICC_PREFETCHES,  maxwell_sm_icc_prefetches_enc_str_1, 0x00000006, 0x00000004, 0x00000001, PM_UNIT_SMCORE,  1}, //    "icc_prefetches"
    { MAXWELL_SM_ICC_UNLOCK_ALL,  maxwell_sm_icc_unlock_all_enc_str_1, 0x00000006, 0x00000005, 0x00000001, PM_UNIT_SMCORE,  1}, //    "icc_unlock_all"
    { MAXWELL_SM_ICC_MISSES_OUTSTANDING,  maxwell_sm_icc_misses_outstanding_enc_str_1, 0x00000007, 0x00000210, 0x00000007, PM_UNIT_SMCORE,  3}, //    "icc_misses_outstanding"
    { MAXWELL_SM_SHARED_LD_BANK_CONFLICT,  maxwell_sm_shared_ld_bank_conflict_enc_str_1, 0x0000000e, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "shm_ld_bank_conflict"
    { MAXWELL_SM_SHARED_ST_BANK_CONFLICT,  maxwell_sm_shared_st_bank_conflict_enc_str_1, 0x0000000e, 0x00000001, 0x00000001, PM_UNIT_MIO,  1}, //    "shm_st_bank_conflict"
    { MAXWELL_SM_SHARED_LOAD_TRANSACTIONS,  maxwell_sm_shared_load_transactions_enc_str_1, 0x0000000e, 0x00000002, 0x00000001, PM_UNIT_MIO,  1}, //    "shm_ld_count"
    { MAXWELL_SM_SHARED_STORE_TRANSACTIONS,  maxwell_sm_shared_store_transactions_enc_str_1, 0x0000000e, 0x00000003, 0x00000001, PM_UNIT_MIO,  1}, //    "shm_st_count"
    { MAXWELL_SM_PQ_WRITE_H0,  maxwell_sm_pq_write_h0_enc_str_1, 0x0000000e, 0x00000004, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_write_h0"
    { MAXWELL_SM_PQ_WRITE_H1,  maxwell_sm_pq_write_h1_enc_str_1, 0x0000000e, 0x00000005, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_write_h1"
    { MAXWELL_SM_ADU_REPLAY_H0,  maxwell_sm_adu_replay_h0_enc_str_1, 0x0000000e, 0x00000006, 0x00000001, PM_UNIT_MIO,  1}, //    "adu_replay_h0"
    { MAXWELL_SM_ADU_REPLAY_H1,  maxwell_sm_adu_replay_h1_enc_str_1, 0x0000000e, 0x00000007, 0x00000001, PM_UNIT_MIO,  1}, //    "adu_replay_h1"
    { MAXWELL_SM_PQ_READS_FOR_SHM_H0,  maxwell_sm_pq_reads_for_shm_h0_enc_str_1, 0x0000000f, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_reads_for_shm_h0"
    { MAXWELL_SM_PQ_READS_FOR_PIXOUT_H0,  maxwell_sm_pq_reads_for_pixout_h0_enc_str_1, 0x0000000f, 0x00000001, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_reads_for_pixout_h0"
    { MAXWELL_SM_PQ_READS_FOR_TEX_H0,  maxwell_sm_pq_reads_for_tex_h0_enc_str_1, 0x0000000f, 0x00000002, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_reads_for_tex_h0"
    { MAXWELL_SM_PQ_READS_FOR_SHM_STOLEN_H0,  maxwell_sm_pq_reads_for_shm_stolen_h0_enc_str_1, 0x0000000f, 0x00000003, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_reads_for_shm_stolen_h0"
    { MAXWELL_SM_PQ_READS_FOR_SHM_H1,  maxwell_sm_pq_reads_for_shm_h1_enc_str_1, 0x0000000f, 0x00000004, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_reads_for_shm_h1"
    { MAXWELL_SM_PQ_READS_FOR_PIXOUT_H1,  maxwell_sm_pq_reads_for_pixout_h1_enc_str_1, 0x0000000f, 0x00000005, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_reads_for_pixout_h1"
    { MAXWELL_SM_PQ_READS_FOR_TEX_H1,  maxwell_sm_pq_reads_for_tex_h1_enc_str_1, 0x0000000f, 0x00000006, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_reads_for_tex_h1"
    { MAXWELL_SM_PQ_READS_FOR_SHM_STOLEN_H1,  maxwell_sm_pq_reads_for_shm_stolen_h1_enc_str_1, 0x0000000f, 0x00000007, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_reads_for_shm_stolen_h1"
    { MAXWELL_SM_IDC_HIT,  maxwell_sm_idc_hit_enc_str_1, 0x00000010, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "idc_hit"
    { MAXWELL_SM_IDC_FULL_TAG,  maxwell_sm_idc_full_tag_enc_str_1, 0x00000010, 0x00000001, 0x00000001, PM_UNIT_MIO,  1}, //    "idc_full_tag"
    { MAXWELL_SM_IDC_TRUE_MISS,  maxwell_sm_idc_true_miss_enc_str_1, 0x00000010, 0x00000002, 0x00000001, PM_UNIT_MIO,  1}, //    "idc_true_miss"
    { MAXWELL_SM_IDC_COVERED_MISS,  maxwell_sm_idc_covered_miss_enc_str_1, 0x00000010, 0x00000003, 0x00000001, PM_UNIT_MIO,  1}, //    "idc_covered_miss"
    { MAXWELL_SM_IDC_DIVERGENCE_REPLAY_H0,  maxwell_sm_idc_divergence_replay_h0_enc_str_1, 0x00000010, 0x00000004, 0x00000001, PM_UNIT_MIO,  1}, //    "idc_divergence_replay_h0"
    { MAXWELL_SM_IDC_DIVERGENT_INSTRUCTION_H0,  maxwell_sm_idc_divergent_instruction_h0_enc_str_1, 0x00000010, 0x00000005, 0x00000001, PM_UNIT_MIO,  1}, //    "idc_divergent_instruction_h0"
    { MAXWELL_SM_IDC_DIVERGENCE_REPLAY_H1,  maxwell_sm_idc_divergence_replay_h1_enc_str_1, 0x00000010, 0x00000006, 0x00000001, PM_UNIT_MIO,  1}, //    "idc_divergence_replay_h1"
    { MAXWELL_SM_IDC_DIVERGENT_INSTRUCTION_H1,  maxwell_sm_idc_divergent_instruction_h1_enc_str_1, 0x00000010, 0x00000007, 0x00000001, PM_UNIT_MIO,  1}, //    "idc_divergent_instruction_h1"
    { MAXWELL_SM_MEMBAR_EXECUTED,  maxwell_sm_membar_executed_enc_str_1, 0x00000011, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "membar_executed"
    { MAXWELL_SM_MEMBAR_PENDING,  maxwell_sm_membar_pending_enc_str_1, 0x00000011, 0x00000001, 0x00000001, PM_UNIT_MIO,  1}, //    "membar_pending"
    { MAXWELL_SM_MEMBAR_SENT_TO_TEX,  maxwell_sm_membar_sent_to_tex_enc_str_1, 0x00000011, 0x00000002, 0x00000001, PM_UNIT_MIO,  1}, //    "membar_sent_to_tex"
    { MAXWELL_SM_MEMBAR_CTA_SENT_TO_TEX_H0,  maxwell_sm_membar_cta_sent_to_tex_h0_enc_str_1, 0x00000011, 0x00000003, 0x00000001, PM_UNIT_MIO,  1}, //    "membar_cta_sent_to_tex_h0"
    { MAXWELL_SM_MEMBAR_CTA_SENT_TO_TEX_H1,  maxwell_sm_membar_cta_sent_to_tex_h1_enc_str_1, 0x00000011, 0x00000004, 0x00000001, PM_UNIT_MIO,  1}, //    "membar_cta_sent_to_tex_h1"
    { MAXWELL_SM_MEMBAR_CTA_SYNTHETIC,  maxwell_sm_membar_cta_synthetic_enc_str_1, 0x00000011, 0x00000005, 0x00000001, PM_UNIT_MIO,  1}, //    "membar_cta_synthetic"
    { MAXWELL_SM_PIXOUT_QUADS_DRAINED,  maxwell_sm_pixout_quads_drained_enc_str_1, 0x00000012, 0x00000010, 0x00000003, PM_UNIT_MIO,  2}, //    "pixout_quads_drained"
    { MAXWELL_SM_HALF_WARPS_KILLED_BY_SHADER,  maxwell_sm_half_warps_killed_by_shader_enc_str_1, 0x00000012, 0x00000032, 0x00000003, PM_UNIT_MIO,  2}, //    "half_warps_killed_by_shader"
    { MAXWELL_SM_QUADS_KILLED_BY_SHADER,  maxwell_sm_quads_killed_by_shader_enc_str_1, 0x00000012, 0x00007654, 0x0000000f, PM_UNIT_MIO,  4}, //    "quads_killed_by_shader"
    { MAXWELL_SM_WARPS_KILLED_BY_SHADER,  maxwell_sm_warps_killed_by_shader_enc_str_1, 0x00000013, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "warps_killed_by_shader"
    { MAXWELL_SM_PIXELS_KILLED_SHADERCOVG,  maxwell_sm_pixels_killed_shadercovg_enc_str_1, 0x00000013, 0x00654321, 0x0000003f, PM_UNIT_MIO,  6}, //    "pixels_killed_shadercovg"
    { MAXWELL_SM_SM2GPM_OUTPUT_STALL,  maxwell_sm_sm2gpm_output_stall_enc_str_1, 0x00000013, 0x00000007, 0x00000001, PM_UNIT_MIO,  1}, //    "sm2gpm_output_stall"
    { MAXWELL_SM_MIO_ISBE_WRITE,  maxwell_sm_mio_isbe_write_enc_str_1, 0x00000014, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "mio_isbe_write"
    { MAXWELL_SM_MIO_ISBE_READ,  maxwell_sm_mio_isbe_read_enc_str_1, 0x00000014, 0x00000001, 0x00000001, PM_UNIT_MIO,  1}, //    "mio_isbe_read"
    { MAXWELL_SM_MIO_SM_STALLED_DUE_TO_PE_H0,  maxwell_sm_mio_sm_stalled_due_to_pe_h0_enc_str_1, 0x00000014, 0x00000002, 0x00000001, PM_UNIT_MIO,  1}, //    "mio_sm_stalled_due_to_pe_h0"
    { MAXWELL_SM_MIO_SM_STALLED_DUE_TO_PE_H1,  maxwell_sm_mio_sm_stalled_due_to_pe_h1_enc_str_1, 0x00000014, 0x00000003, 0x00000001, PM_UNIT_MIO,  1}, //    "mio_sm_stalled_due_to_pe_h1"
    { MAXWELL_SM_PE2MIO_ISBE_READ_REQ,  maxwell_sm_pe2mio_isbe_read_req_enc_str_1, 0x00000015, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "pe2mio_isbe_read_req"
    { MAXWELL_SM_PE2MIO_ISBE_WRITE_REQ,  maxwell_sm_pe2mio_isbe_write_req_enc_str_1, 0x00000015, 0x00000001, 0x00000001, PM_UNIT_MIO,  1}, //    "pe2mio_isbe_write_req"
    { MAXWELL_SM_PE2MIO_TRAM_WRITE,  maxwell_sm_pe2mio_tram_write_enc_str_1, 0x00000015, 0x00000002, 0x00000001, PM_UNIT_MIO,  1}, //    "pe2mio_tram_write"
    { MAXWELL_SM_PE_ISBE_WR_DELAYED_DUE_TO_CAMPING,  maxwell_sm_pe_isbe_wr_delayed_due_to_camping_enc_str_1, 0x00000015, 0x00000003, 0x00000001, PM_UNIT_MIO,  1}, //    "pe_isbe_wr_delayed_due_to_camping"
    { MAXWELL_SM_PE_TRAM_WR_DELAYED_AND_LOST_THROUGHPUT,  maxwell_sm_pe_tram_wr_delayed_and_lost_throughput_enc_str_1, 0x00000015, 0x00000004, 0x00000001, PM_UNIT_MIO,  1}, //    "pe_tram_wr_delayed_and_lost_throughput"
    { MAXWELL_SM_PE_TRAM_WR_DELAYED_DUE_TO_CAMPING,  maxwell_sm_pe_tram_wr_delayed_due_to_camping_enc_str_1, 0x00000015, 0x00000005, 0x00000001, PM_UNIT_MIO,  1}, //    "pe_tram_wr_delayed_due_to_camping"
    { MAXWELL_SM_SMM2TEX_DATA_LG_COUNT_H0,  maxwell_sm_smm2tex_data_lg_count_h0_enc_str_1, 0x00000016, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "smm2tex_data_lg_count_h0"
    { MAXWELL_SM_SMM2TEX_DATA_TEX_COUNT_H0,  maxwell_sm_smm2tex_data_tex_count_h0_enc_str_1, 0x00000016, 0x00000001, 0x00000001, PM_UNIT_MIO,  1}, //    "smm2tex_data_tex_count_h0"
    { MAXWELL_SM_SMM2TEX_DATA_LG_COUNT_H1,  maxwell_sm_smm2tex_data_lg_count_h1_enc_str_1, 0x00000016, 0x00000002, 0x00000001, PM_UNIT_MIO,  1}, //    "smm2tex_data_lg_count_h1"
    { MAXWELL_SM_SMM2TEX_DATA_TEX_COUNT_H1,  maxwell_sm_smm2tex_data_tex_count_h1_enc_str_1, 0x00000016, 0x00000003, 0x00000001, PM_UNIT_MIO,  1}, //    "smm2tex_data_tex_count_h1"
    { MAXWELL_SM_MIO_CANT_DISPATCH_LSU_ADU_OVER_SHM_H0,  maxwell_sm_mio_cant_dispatch_lsu_adu_over_shm_h0_enc_str_1, 0x00000017, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "mio_cant_dispatch_lsu_adu_over_shm_h0"
    { MAXWELL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_ADU_H0,  maxwell_sm_mio_cant_dispatch_lsu_pixout_over_adu_h0_enc_str_1, 0x00000017, 0x00000001, 0x00000001, PM_UNIT_MIO,  1}, //    "mio_cant_dispatch_lsu_pixout_over_adu_h0"
    { MAXWELL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_SHM_H0,  maxwell_sm_mio_cant_dispatch_lsu_pixout_over_shm_h0_enc_str_1, 0x00000017, 0x00000002, 0x00000001, PM_UNIT_MIO,  1}, //    "mio_cant_dispatch_lsu_pixout_over_shm_h0"
    { MAXWELL_SM_MIO_CANT_DISPATCH_LSU_ADU_OVER_SHM_H1,  maxwell_sm_mio_cant_dispatch_lsu_adu_over_shm_h1_enc_str_1, 0x00000017, 0x00000003, 0x00000001, PM_UNIT_MIO,  1}, //    "mio_cant_dispatch_lsu_adu_over_shm_h1"
    { MAXWELL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_ADU_H1,  maxwell_sm_mio_cant_dispatch_lsu_pixout_over_adu_h1_enc_str_1, 0x00000017, 0x00000004, 0x00000001, PM_UNIT_MIO,  1}, //    "mio_cant_dispatch_lsu_pixout_over_adu_h1"
    { MAXWELL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_SHM_H1,  maxwell_sm_mio_cant_dispatch_lsu_pixout_over_shm_h1_enc_str_1, 0x00000017, 0x00000005, 0x00000001, PM_UNIT_MIO,  1}, //    "mio_cant_dispatch_lsu_pixout_over_shm_h1"
    { MAXWELL_SM_IDC_MISSES_OUTSTANDING,  maxwell_sm_idc_misses_outstanding_enc_str_1, 0x00000018, 0x00000210, 0x00000007, PM_UNIT_MIO,  3}, //    "idc_misses_outstanding"
    { MAXWELL_SM_PQ_FULL_H0,  maxwell_sm_pq_full_h0_enc_str_1, 0x00000019, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_full_h0"
    { MAXWELL_SM_PQ_FULL_H1,  maxwell_sm_pq_full_h1_enc_str_1, 0x00000019, 0x00000001, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_full_h1"
    { MAXWELL_SM_PIX_PQ_FULL_H0,  maxwell_sm_pix_pq_full_h0_enc_str_1, 0x00000019, 0x00000002, 0x00000001, PM_UNIT_MIO,  1}, //    "pix_pq_full_h0"
    { MAXWELL_SM_PIX_PQ_FULL_H1,  maxwell_sm_pix_pq_full_h1_enc_str_1, 0x00000019, 0x00000003, 0x00000001, PM_UNIT_MIO,  1}, //    "pix_pq_full_h1"
    { MAXWELL_SM_SHM_PQ_FULL_H0,  maxwell_sm_shm_pq_full_h0_enc_str_1, 0x00000019, 0x00000004, 0x00000001, PM_UNIT_MIO,  1}, //    "shm_pq_full_h0"
    { MAXWELL_SM_SHM_PQ_FULL_H1,  maxwell_sm_shm_pq_full_h1_enc_str_1, 0x00000019, 0x00000005, 0x00000001, PM_UNIT_MIO,  1}, //    "shm_pq_full_h1"
    { MAXWELL_SM_TEX_PQ_FULL_H0,  maxwell_sm_tex_pq_full_h0_enc_str_1, 0x00000019, 0x00000006, 0x00000001, PM_UNIT_MIO,  1}, //    "tex_pq_full_h0"
    { MAXWELL_SM_TEX_PQ_FULL_H1,  maxwell_sm_tex_pq_full_h1_enc_str_1, 0x00000019, 0x00000007, 0x00000001, PM_UNIT_MIO,  1}, //    "tex_pq_full_h1"
    { MAXWELL_SM_PQ_WRITE_BACK_LSU_STALL_H0,  maxwell_sm_pq_write_back_lsu_stall_h0_enc_str_1, 0x0000001a, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_write_back_lsu_stall_h0"
    { MAXWELL_SM_PQ_WRITE_BACK_TEX_STALL_H0,  maxwell_sm_pq_write_back_tex_stall_h0_enc_str_1, 0x0000001a, 0x00000001, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_write_back_tex_stall_h0"
    { MAXWELL_SM_PQ_WRITE_BACK_LSU_STALL_H1,  maxwell_sm_pq_write_back_lsu_stall_h1_enc_str_1, 0x0000001a, 0x00000002, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_write_back_lsu_stall_h1"
    { MAXWELL_SM_PQ_WRITE_BACK_TEX_STALL_H1,  maxwell_sm_pq_write_back_tex_stall_h1_enc_str_1, 0x0000001a, 0x00000003, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_write_back_tex_stall_h1"
    { MAXWELL_SM_LSU_IQ_FIFO_FULL_H0,  maxwell_sm_lsu_iq_fifo_full_h0_enc_str_1, 0x0000001b, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "lsu_iq_fifo_full_h0"
    { MAXWELL_SM_TEX_IQ_FIFO_FULL_H0,  maxwell_sm_tex_iq_fifo_full_h0_enc_str_1, 0x0000001b, 0x00000001, 0x00000001, PM_UNIT_MIO,  1}, //    "tex_iq_fifo_full_h0"
    { MAXWELL_SM_PIX_IQ_FIFO_FULL_H0,  maxwell_sm_pix_iq_fifo_full_h0_enc_str_1, 0x0000001b, 0x00000002, 0x00000001, PM_UNIT_MIO,  1}, //    "pix_iq_fifo_full_h0"
    { MAXWELL_SM_RTY_IQ_FIFO_FULL_H0,  maxwell_sm_rty_iq_fifo_full_h0_enc_str_1, 0x0000001b, 0x00000003, 0x00000001, PM_UNIT_MIO,  1}, //    "rty_iq_fifo_full_h0"
    { MAXWELL_SM_LSU_IQ_FIFO_FULL_H1,  maxwell_sm_lsu_iq_fifo_full_h1_enc_str_1, 0x0000001b, 0x00000004, 0x00000001, PM_UNIT_MIO,  1}, //    "lsu_iq_fifo_full_h1"
    { MAXWELL_SM_TEX_IQ_FIFO_FULL_H1,  maxwell_sm_tex_iq_fifo_full_h1_enc_str_1, 0x0000001b, 0x00000005, 0x00000001, PM_UNIT_MIO,  1}, //    "tex_iq_fifo_full_h1"
    { MAXWELL_SM_PIX_IQ_FIFO_FULL_H1,  maxwell_sm_pix_iq_fifo_full_h1_enc_str_1, 0x0000001b, 0x00000006, 0x00000001, PM_UNIT_MIO,  1}, //    "pix_iq_fifo_full_h1"
    { MAXWELL_SM_RTY_IQ_FIFO_FULL_H1,  maxwell_sm_rty_iq_fifo_full_h1_enc_str_1, 0x0000001b, 0x00000007, 0x00000001, PM_UNIT_MIO,  1}, //    "rty_iq_fifo_full_h1"
    { INVALID_PM_SIGNAL_NEW,            "",                       0xffffffff, 0x00000000, 0x00000000,     PM_UNIT_MAX,0 }
};

PerfSignalHwpm PerfSignalTableGM000_sys0[] = {
    //Hub TLB signals
    //__hub_tlb_hit        = hubmmu2pm_hub_hub_tlb_hit                                      count # of PTE hits in hub TLB
    //__hub_tlb_miss       = (hubmmu2pm_hub_hub_tlb_miss & !hubmmu2pm_hub_hub_tlb_hit)      count # of PTE misses in hub TLB
    { MAXWELL_MMU_HUB_TLB_HIT,    maxwell_mmu_hub_tlb_hit_enc_str_1,    0x00000004, 0x0000AAAA, 0x4e,    PM_UNIT_HUBMMU, 1 },
    { MAXWELL_MMU_HUB_TLB_MISS_INT,   maxwell_mmu_hub_tlb_miss_int_enc_str_1,   0x00000004, 0x0000AAAA, 0x4f,    PM_UNIT_HUBMMU, 1 },

    // mmu_fill_pte_hit    = hubmmu2pm_hub_fill_pte_hit                                     "count # of PTE hits in mmu fill unit"
    // mmu_fill_pte_miss   = (hubmmu2pm_hub_fill_pte_miss & !hubmmu2pm_hub_fill_pte_hit)    "count # of PTE misses in mmu fill unit"
    { MAXWELL_MMU_FILL_PTE_HIT,   maxwell_mmu_fill_pte_hit_enc_str_1,   0x00000006, 0x0000AAAA, 0x4e,    PM_UNIT_HUBMMU, 1 },
    { MAXWELL_MMU_FILL_PTE_MISS_INT,  maxwell_mmu_fill_pte_miss_int_enc_str_1,  0x00000006, 0x0000AAAA, 0x4f,    PM_UNIT_HUBMMU, 1 },

    // mmu_fill_pde_hit    = hubmmu2pm_hub_fill_pde_hit                                     "count # of PDE hits in mmu fill unit"
    // mmu_fill_pde_miss   = hubmmu2pm_hub_fill_pde_miss                                    "count # of PDE misses in mmu fill unit"
    { MAXWELL_MMU_FILL_PDE_HIT,   maxwell_mmu_fill_pde_hit_enc_str_1,   0x00000006, 0x0000AAAA, 0x50,    PM_UNIT_HUBMMU,1 },
    { MAXWELL_MMU_FILL_PDE_MISS,  maxwell_mmu_fill_pde_miss_enc_str_1,  0x00000006, 0x0000AAAA, 0x51,    PM_UNIT_HUBMMU,1 },

    { INVALID_PM_SIGNAL_NEW,     "",                     0xffffffff, 0x00000000, 0x00,     PM_UNIT_MAX,0}
};

PerfSignalHwpmExpt PerfSignalTableGM000_sys0_expt[] = {
    //Hub TLB signals
    //__hub_tlb_miss       = (hubmmu2pm_hub_hub_tlb_miss & !hubmmu2pm_hub_hub_tlb_hit)      count # of PTE misses in hub TLB
    { MAXWELL_MMU_HUB_TLB_MISS, maxwell_mmu_hub_tlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_MMU_HUB_TLB_HIT, MAXWELL_MMU_HUB_TLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},

    // mmu_fill_pte_miss   = (hubmmu2pm_hub_fill_pte_miss & !hubmmu2pm_hub_fill_pte_hit)    "count # of PTE misses in mmu fill unit"
    { MAXWELL_MMU_FILL_PTE_MISS, maxwell_mmu_fill_pte_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_MMU_FILL_PTE_HIT, MAXWELL_MMU_FILL_PTE_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},

   { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000,  0x00}
};

PerfSignalSmpc PerfSignalTableGMSwCounters_nop_trig_global_load_store[] = {
    // TO DO: Change this table and make it more suitable for sw counters as most of the fields are not used
    { MAXWELL_SW_COUNTER_GLD8BIT_INST,    maxwell_sw_counter_gld8bit_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_GLD16BIT_INST,   maxwell_sw_counter_gld16bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_GLD32BIT_INST,   maxwell_sw_counter_gld32bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_GLD64BIT_INST,   maxwell_sw_counter_gld64bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_GLD128BIT_INST,  maxwell_sw_counter_gld128bit_inst_enc_str_1,  0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_GST8BIT_INST,    maxwell_sw_counter_gst8bit_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_GST16BIT_INST,   maxwell_sw_counter_gst16bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_GST32BIT_INST,   maxwell_sw_counter_gst32bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_GST64BIT_INST,   maxwell_sw_counter_gst64bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_GST128BIT_INST,  maxwell_sw_counter_gst128bit_inst_enc_str_1,  0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { INVALID_SW_COUNTER,               "",           0xffffffff, 0x00000000, 0x00000000,                   PM_UNIT_MAX,0 }
};

PerfSignalTableNew PerfSignalTableGMSwCounters_nop_trig_shared_load_store[] = {
    // Software counters work for all Maxwell chips
    { MAXWELL_SW_COUNTER_SLD8BIT_INST,    maxwell_sw_counter_sld8bit_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_SLD16BIT_INST,   maxwell_sw_counter_sld16bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_SLD32BIT_INST,   maxwell_sw_counter_sld32bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_SLD64BIT_INST,   maxwell_sw_counter_sld64bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_SLD128BIT_INST,  maxwell_sw_counter_sld128bit_inst_enc_str_1,  0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_SST8BIT_INST,    maxwell_sw_counter_sst8bit_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_SST16BIT_INST,   maxwell_sw_counter_sst16bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_SST32BIT_INST,   maxwell_sw_counter_sst32bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_SST64BIT_INST,   maxwell_sw_counter_sst64bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_SST128BIT_INST,  maxwell_sw_counter_sst128bit_inst_enc_str_1,  0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { INVALID_SW_COUNTER,               "",                                         0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX,0 }
};

PerfSignalTableNew PerfSignalTableGMSwCounters_unique_gld_gst[] = {
    //Software counters work for all maxwell chips 
    { MAXWELL_SW_COUNTER_UNIQUE_GLD1BYTE_REQUESTED,    maxwell_sw_counter_unique_gld_1byte_requested_enc_str_1,    0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_UNIQUE_GLD4BYTE_REQUESTED,   maxwell_sw_counter_unique_gld_4byte_requested_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_UNIQUE_GLD8BYTE_REQUESTED,   maxwell_sw_counter_unique_gld_8byte_requested_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_UNIQUE_GLD16BYTE_REQUESTED,  maxwell_sw_counter_unique_gld_16byte_requested_enc_str_1,  0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_UNIQUE_GST1BYTE_REQUESTED,    maxwell_sw_counter_unique_gst_1byte_requested_enc_str_1,    0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_UNIQUE_GST4BYTE_REQUESTED,   maxwell_sw_counter_unique_gst_4byte_requested_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_UNIQUE_GST8BYTE_REQUESTED,   maxwell_sw_counter_unique_gst_8byte_requested_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_UNIQUE_GST16BYTE_REQUESTED,  maxwell_sw_counter_unique_gst_16byte_requested_enc_str_1,  0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { INVALID_SW_COUNTER,                       "",                                                 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0}
};

PerfSignalTableNew PerfSignalTableGMSwCounters_unique_sector_access_gld[] = {
    { MAXWELL_SW_COUNTER_UNIQUE_SECTOR_ACCESS_GLD,        maxwell_sw_counter_unique_sector_access_gld_enc_str_1,         0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX,0 },
    { INVALID_SW_COUNTER,                       "",                                                 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0}
};

PerfSignalSmpc PerfSignalTableGMSwCounters_nop_trig_flops[] = {
    // TO DO: Change this table and make it more suitable for sw counters as most of the fields are not used
    { MAXWELL_SW_COUNTER_FADD_INST,  maxwell_sw_counter_fadd_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_FMUL_INST,  maxwell_sw_counter_fmul_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_FFMA_INST,  maxwell_sw_counter_ffma_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_DADD_INST,  maxwell_sw_counter_dadd_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_DMUL_INST,  maxwell_sw_counter_dmul_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_DFMA_INST,  maxwell_sw_counter_dfma_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_COS_INST,   maxwell_sw_counter_cos_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_EX2_INST,   maxwell_sw_counter_ex2_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_LG2_INST,   maxwell_sw_counter_lg2_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_RCP_INST,   maxwell_sw_counter_rcp_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_RSQ_INST,   maxwell_sw_counter_rsq_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_SIN_INST,   maxwell_sw_counter_sin_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_SQRT_INST,  maxwell_sw_counter_sqrt_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_HADD_INST,  maxwell_sw_counter_hadd_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_HMUL_INST,  maxwell_sw_counter_hmul_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { MAXWELL_SW_COUNTER_HFMA_INST,  maxwell_sw_counter_hfma_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },

    { INVALID_SW_COUNTER,           "",             0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 }
};

PerfSignalSmpc PerfSignalTableGMSwCounters_instrClass[] = {
    { MAXWELL_SW_COUNTER_INSTR_CLASS_FP_32,                       maxwell_sw_counter_instr_class_fp_32_enc_str_1                      , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_INSTR_CLASS_FP_64,                       maxwell_sw_counter_instr_class_fp_64_enc_str_1                      , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_INSTR_CLASS_INTEGER,                     maxwell_sw_counter_instr_class_integer_enc_str_1                    , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_INSTR_CLASS_BIT_CONVERT,                 maxwell_sw_counter_instr_class_bit_convert_enc_str_1                , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_INSTR_CLASS_CONTROL,                     maxwell_sw_counter_instr_class_control_enc_str_1                    , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_INSTR_CLASS_COMPUTE_LD_ST,               maxwell_sw_counter_instr_class_compute_ld_st_enc_str_1              , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_INSTR_CLASS_MISCELLANEOUS,               maxwell_sw_counter_instr_class_miscellaneous_enc_str_1              , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_INSTR_CLASS_INTER_THREAD_COMMUNICATION,  maxwell_sw_counter_instr_class_inter_thread_communication_enc_str_1 , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_INSTR_CLASS_FP_16,                       maxwell_sw_counter_instr_class_fp_16_enc_str_1                      , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { INVALID_SW_COUNTER,           "",             0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 }
};

PerfSignalSmpc PerfSignalTableGMSwCounters_genericLdStCounters[] = {
    { MAXWELL_SW_COUNTER_GENERIC_SHARED_LOAD,           maxwell_sw_counter_generic_shared_ld_enc_str_1          , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_GENERIC_SHARED_STORE,          maxwell_sw_counter_generic_shared_st_enc_str_1          , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_GENERIC_LOCAL_LOAD,            maxwell_sw_counter_generic_local_ld_enc_str_1           , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_GENERIC_LOCAL_STORE,           maxwell_sw_counter_generic_local_st_enc_str_1           , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_GENERIC_GLOBAL_LOAD,           maxwell_sw_counter_generic_global_ld_enc_str_1          , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { MAXWELL_SW_COUNTER_GENERIC_GLOBAL_STORE,          maxwell_sw_counter_generic_global_st_enc_str_1          , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { INVALID_SW_COUNTER,           "",             0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 }
};

CUeventDataSmpcExpt PerfSignalTableGM000_LutModeCounters[] = {
    { MAXWELL_LUT_COUNTER_GLD32BIT_INST,             maxwell_lut_counter_gld32bit_inst_enc_str_1,             PM_UNIT_SMQCTL,     {MAXWELL_SM_INST_EXECUTED_32B,MAXWELL_SM_GENERIC_LOAD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { MAXWELL_LUT_COUNTER_GST32BIT_INST,             maxwell_lut_counter_gst32bit_inst_enc_str_1,             PM_UNIT_SMQCTL,     {MAXWELL_SM_INST_EXECUTED_32B,MAXWELL_SM_GENERIC_STORE,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { MAXWELL_LUT_COUNTER_GLD64BIT_INST,             maxwell_lut_counter_gld64bit_inst_enc_str_1,             PM_UNIT_SMQCTL,     {MAXWELL_SM_INST_EXECUTED_64B,MAXWELL_SM_GENERIC_LOAD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { MAXWELL_LUT_COUNTER_GST64BIT_INST,             maxwell_lut_counter_gst64bit_inst_enc_str_1,             PM_UNIT_SMQCTL,     {MAXWELL_SM_INST_EXECUTED_64B,MAXWELL_SM_GENERIC_STORE,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { MAXWELL_LUT_COUNTER_GLD128BIT_INST,            maxwell_lut_counter_gld128bit_inst_enc_str_1,            PM_UNIT_SMQCTL,     {MAXWELL_SM_INST_EXECUTED_128B,MAXWELL_SM_GENERIC_LOAD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { MAXWELL_LUT_COUNTER_GST128BIT_INST,            maxwell_lut_counter_gst128bit_inst_enc_str_1,            PM_UNIT_SMQCTL,     {MAXWELL_SM_INST_EXECUTED_128B,MAXWELL_SM_GENERIC_STORE,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},    (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { MAXWELL_LUT_COUNTER_SHLD_32BIT_INST,           maxwell_lut_counter_shld_32bit_inst_enc_str_1,         PM_UNIT_SMQCTL,     {MAXWELL_SM_INST_EXECUTED_32B,MAXWELL_SM_SHARED_LOAD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { MAXWELL_LUT_COUNTER_SHLD_64BIT_INST,           maxwell_lut_counter_shld_64bit_inst_enc_str_1,         PM_UNIT_SMQCTL,     {MAXWELL_SM_INST_EXECUTED_64B,MAXWELL_SM_SHARED_LOAD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { MAXWELL_LUT_COUNTER_SHLD_128BIT_INST,          maxwell_lut_counter_shld_128bit_inst_enc_str_1,        PM_UNIT_SMQCTL,     {MAXWELL_SM_INST_EXECUTED_128B,MAXWELL_SM_SHARED_LOAD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { MAXWELL_LUT_COUNTER_SHLD_U128BIT_INST,         maxwell_lut_counter_shld_u128bit_inst_enc_str_1,      PM_UNIT_SMQCTL,     {MAXWELL_SM_INST_EXECUTED_U128B,MAXWELL_SM_SHARED_LOAD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { MAXWELL_LUT_COUNTER_SHST_32BIT_INST,           maxwell_lut_counter_shst_32bit_inst_enc_str_1,         PM_UNIT_SMQCTL,     {MAXWELL_SM_INST_EXECUTED_32B,MAXWELL_SM_SHARED_STORE,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { MAXWELL_LUT_COUNTER_SHST_64BIT_INST,           maxwell_lut_counter_shst_64bit_inst_enc_str_1,         PM_UNIT_SMQCTL,     {MAXWELL_SM_INST_EXECUTED_64B,MAXWELL_SM_SHARED_STORE,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { MAXWELL_LUT_COUNTER_SHST_128BIT_INST,          maxwell_lut_counter_shst_128bit_inst_enc_str_1,        PM_UNIT_SMQCTL,     {MAXWELL_SM_INST_EXECUTED_128B,MAXWELL_SM_SHARED_STORE,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},

    { MAXWELL_LUT_COUNTER_GENERIC_SHARED_LD_INST,    maxwell_lut_counter_generic_shared_ld_inst_enc_str_1,     PM_UNIT_SMQCTL,     {MAXWELL_SM_GENERIC_LOAD,MAXWELL_SM_GENERIC_SHARED,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { MAXWELL_LUT_COUNTER_GENERIC_SHARED_ST_INST,    maxwell_lut_counter_generic_shared_st_inst_enc_str_1,     PM_UNIT_SMQCTL,     {MAXWELL_SM_GENERIC_STORE,MAXWELL_SM_GENERIC_SHARED,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},

    { MAXWELL_LUT_COUNTER_GENERIC_SHARED_LD_32BIT_INST,    maxwell_lut_counter_generic_shared_ld_32bit_inst_enc_str_1,     PM_UNIT_SMQCTL,     {MAXWELL_SM_GENERIC_LOAD,MAXWELL_SM_GENERIC_SHARED,MAXWELL_SM_INST_EXECUTED_32B,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE)},
    { MAXWELL_LUT_COUNTER_GENERIC_SHARED_LD_64BIT_INST,    maxwell_lut_counter_generic_shared_ld_64bit_inst_enc_str_1,     PM_UNIT_SMQCTL,     {MAXWELL_SM_GENERIC_LOAD,MAXWELL_SM_GENERIC_SHARED,MAXWELL_SM_INST_EXECUTED_64B,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE)},
    { MAXWELL_LUT_COUNTER_GENERIC_SHARED_LD_128BIT_INST,   maxwell_lut_counter_generic_shared_ld_128bit_inst_enc_str_1,    PM_UNIT_SMQCTL,     {MAXWELL_SM_GENERIC_LOAD,MAXWELL_SM_GENERIC_SHARED,MAXWELL_SM_INST_EXECUTED_128B,INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE)},

    { MAXWELL_LUT_COUNTER_GENERIC_SHARED_ST_32BIT_INST,    maxwell_lut_counter_generic_shared_st_32bit_inst_enc_str_1,     PM_UNIT_SMQCTL,     {MAXWELL_SM_GENERIC_STORE,MAXWELL_SM_GENERIC_SHARED,MAXWELL_SM_INST_EXECUTED_32B,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE)},
    { MAXWELL_LUT_COUNTER_GENERIC_SHARED_ST_64BIT_INST,    maxwell_lut_counter_generic_shared_st_64bit_inst_enc_str_1,     PM_UNIT_SMQCTL,     {MAXWELL_SM_GENERIC_STORE,MAXWELL_SM_GENERIC_SHARED,MAXWELL_SM_INST_EXECUTED_64B,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE)},
    { MAXWELL_LUT_COUNTER_GENERIC_SHARED_ST_128BIT_INST,   maxwell_lut_counter_generic_shared_st_128bit_inst_enc_str_1,    PM_UNIT_SMQCTL,     {MAXWELL_SM_GENERIC_STORE,MAXWELL_SM_GENERIC_SHARED,MAXWELL_SM_INST_EXECUTED_128B,INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE)},


    { MAXWELL_LUT_COUNTER_SH_ATOM_32BIT_INST,        maxwell_lut_counter_sh_atom_32bit_inst_enc_str_1,       PM_UNIT_SMQCTL,     {MAXWELL_SM_INST_EXECUTED_32B,MAXWELL_SM_SHARED_ATOM,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { MAXWELL_LUT_COUNTER_SH_ATOM_64BIT_INST,        maxwell_lut_counter_sh_atom_64bit_inst_enc_str_1,       PM_UNIT_SMQCTL,     {MAXWELL_SM_INST_EXECUTED_64B,MAXWELL_SM_SHARED_ATOM,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { MAXWELL_LUT_COUNTER_SH_ATOM_CAS_32BIT_INST,    maxwell_lut_counter_sh_atom_cas_32bit_inst_enc_str_1,   PM_UNIT_SMQCTL,     {MAXWELL_SM_INST_EXECUTED_32B,MAXWELL_SM_SHARED_ATOM_CAS,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { MAXWELL_LUT_COUNTER_SH_ATOM_CAS_64BIT_INST,    maxwell_lut_counter_sh_atom_cas_64bit_inst_enc_str_1,   PM_UNIT_SMQCTL,     {MAXWELL_SM_INST_EXECUTED_64B,MAXWELL_SM_SHARED_ATOM_CAS,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},

    { INVALID_PM_SIGNAL_NEW,               "", PM_UNIT_MAX, {INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW} , TRUTH_TABLE_FUNCTION_ALL_FALSE}
};

CUeventDataSmpcExpt PerfSignalTableGM000_multiGroup[] = {
    { MAXWELL_SM_PMTRIG_MULTI_GROUP,             maxwell_multigrp_counter_pmtrig_enc_str_1,             PM_UNIT_SMQCTL,     {MAXWELL_SM_PROF_TRIGGER_00,MAXWELL_SM_PROF_TRIGGER_04,MAXWELL_SM_PMTRIG10,MAXWELL_SM_PMTRIG15,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW}},

    { INVALID_PM_SIGNAL_NEW,               "", PM_UNIT_MAX, {INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW} , TRUTH_TABLE_FUNCTION_ALL_FALSE}
};

#if NVCFG(GLOBAL_GPU_FAMILY_GM20X) || NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
PerfSignalHwpm PerfSignalTableGM200_gpctpc[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type

#if CU_MAXWELL_PROFILE_SM_SIGNALS_VIA_HWPM
    // ########### SM Unit ###########
    // ***LAUNCHED***
    // sch_warps_launched               SM has launched 1 warp
    // sch_threads_launched             number of threads SM launched this cycle
    //TBD check with latest files, threads_launched watchbus looks incorrect
    {MAXWELL_HWPM_WARPS_LAUNCHED_0, maxwell_hwpm_warps_launched_0_enc_str_1, 0x1, 0xaaaa, 0x11, PM_UNIT_SMQCTL, 1},
    {MAXWELL_HWPM_WARPS_LAUNCHED_1, maxwell_hwpm_warps_launched_1_enc_str_1, 0x1, 0xaaaa, 0x21, PM_UNIT_SMQCTL, 1},
    {MAXWELL_HWPM_WARPS_LAUNCHED_2, maxwell_hwpm_warps_launched_2_enc_str_1, 0x1, 0xaaaa, 0x31, PM_UNIT_SMQCTL, 1},
    {MAXWELL_HWPM_WARPS_LAUNCHED_3, maxwell_hwpm_warps_launched_3_enc_str_1, 0x1, 0xaaaa, 0x41, PM_UNIT_SMQCTL, 1},
    {MAXWELL_HWPM_THREADS_LAUNCHED_0, maxwell_hwpm_threads_launched_0_enc_str_1, 0x19, 0xffff, 0x10, PM_UNIT_SMQCTL, 6},
    {MAXWELL_HWPM_THREADS_LAUNCHED_1, maxwell_hwpm_threads_launched_1_enc_str_1, 0x19, 0xffff, 0x20, PM_UNIT_SMQCTL, 6},
    {MAXWELL_HWPM_THREADS_LAUNCHED_2, maxwell_hwpm_threads_launched_2_enc_str_1, 0x19, 0xffff, 0x30, PM_UNIT_SMQCTL, 6},
    {MAXWELL_HWPM_THREADS_LAUNCHED_3, maxwell_hwpm_threads_launched_3_enc_str_1, 0x19, 0xffff, 0x40, PM_UNIT_SMQCTL, 6},
    {MAXWELL_HWPM_ACTIVE_CYCLES, maxwell_hwpm_active_cycles_enc_str_1, 0x1, 0xaaaa, 0x1, PM_UNIT_SMCORE, 1},
    {MAXWELL_HWPM_ACTIVE_WARPS, maxwell_hwpm_active_warps_enc_str_1, 0x1, 0xffff, 0x2, PM_UNIT_SMCORE, 6},
    {MAXWELL_HWPM_CTA_LAUNCHED, maxwell_hwpm_cta_launched_enc_str_1, 0x6, 0xaaaa, 0x1, PM_UNIT_SMCORE, 1},
    {MAXWELL_HWPM_SHARED_LD_MEM_DIVERGENCE_REPLAYS, maxwell_hwpm_shared_ld_mem_divergence_replays_enc_str_1, 0x00000007, 0xaaaa, 0x00000050, PM_UNIT_MIO, 1},
    {MAXWELL_HWPM_SHARED_ST_MEM_DIVERGENCE_REPLAYS, maxwell_hwpm_shared_st_mem_divergence_replays_enc_str_1, 0x00000007, 0xaaaa, 0x00000051, PM_UNIT_MIO, 1},
    {MAXWELL_HWPM_SHARED_LD_TRANSACTIONS,           maxwell_hwpm_shared_ld_transactions_enc_str_1,           0x00000007, 0xaaaa, 0x00000052, PM_UNIT_MIO, 1},
    {MAXWELL_HWPM_SHARED_ST_TRANSACTIONS,           maxwell_hwpm_shared_st_transactions_enc_str_1,           0x00000007, 0xaaaa, 0x00000053, PM_UNIT_MIO, 1},
    {MAXWELL_HWPM_INST_EXECUTED_TEX_OPS_Q0, maxwell_hwpm_inst_executed_tex_ops_q0_enc_str_1, 0x12, 0xaaaa, 0x1e, PM_UNIT_SMQCTL, 1},
    {MAXWELL_HWPM_INST_EXECUTED_TEX_OPS_Q1, maxwell_hwpm_inst_executed_tex_ops_q1_enc_str_1, 0x12, 0xaaaa, 0x2e, PM_UNIT_SMQCTL, 1},
    {MAXWELL_HWPM_INST_EXECUTED_TEX_OPS_Q2, maxwell_hwpm_inst_executed_tex_ops_q2_enc_str_1, 0x12, 0xaaaa, 0x3e, PM_UNIT_SMQCTL, 1},
    {MAXWELL_HWPM_INST_EXECUTED_TEX_OPS_Q3, maxwell_hwpm_inst_executed_tex_ops_q3_enc_str_1, 0x12, 0xaaaa, 0x4e, PM_UNIT_SMQCTL, 1},
#endif
    {MAXWELL_PROFILER_FIRST,           maxwell_profiler_first_enc_str_1,           0x0000000a, 0xaaaa, 0x00000008, PM_UNIT_SMCORE, 1},
    {MAXWELL_PROFILER_VALID,           maxwell_profiler_valid_enc_str_1,           0x0000000a, 0xaaaa, 0x00000009, PM_UNIT_SMCORE, 1},

    //mpc signals
    //ctas_launched is doubtful. watchbus is 7e? On emulator 7d is working
    {MAXWELL_MPC_CTAS_LAUNCHED, maxwell_mpc_ctas_launched_enc_str_1, 0xf, 0xaaaa, 0x7e, PM_UNIT_MPC, 1},
    {MAXWELL_MPC_THREADS_LAUNCHED, maxwell_mpc_threads_launched_enc_str_1, 0x10, 0xffff, 0x77, PM_UNIT_MPC, 6},
    {MAXWELL_MPC_WARPS_IN_FLIGHT, maxwell_mpc_warps_in_flight_enc_str_1, 0x42, 0xffff, 0x77, PM_UNIT_MPC, 7},
    {MAXWELL_MPC_COMPUTE_CTAS_IN_FLIGHT, maxwell_mpc_compute_ctas_in_flight_enc_str_1, 0x46, 0xffff, 0x77, PM_UNIT_MPC, 5},

//    {MAXWELL_MPC_PIX_WARPS_IN_FLIGHT, maxwell_mpc_pix_warps_in_flight_enc_str_1, 0x48, 0xffff, 0x77, PM_UNIT_MPC, 8},
//    {MAXWELL_MPC_COMPUTE_CTAS_IN_FLIGHT, maxwell_mpc_compute_ctas_in_flight_enc_str_1, 0x4c, 0xffff, 0x77, PM_UNIT_MPC, 6},

    //Tex signals
    // based on experiments - tex_cache_misses_gpc0_tpc0_tex0 and tex_cache_sector_queries_gpc0_tpc0_tex0
    // defined in \\hw\tools\perfalyze\chips\gm107\pml_files\tex.pml
    //tex0_cache_lg_sector_queries  = tex02pm_gpc_t_lg_sector_queries
    //tex0_cache_lg_sector_misses   = tex02pm_gpc_t_lg_missed_sectors
    //tex1_cache_lg_sector_queries = tex12pm_gpc_t_lg_sector_queries
    //tex1_cache_lg_sector_misses  = tex12pm_gpc_t_lg_missed_sectors

    {MAXWELL_TEX0_LG_SECTOR_QUERIES, maxwell_tex0_lg_sector_queries_enc_str_1, 0x1b, 0xffff, 0x84, PM_UNIT_TEX_M, 4},
    {MAXWELL_TEX1_LG_SECTOR_QUERIES, maxwell_tex1_lg_sector_queries_enc_str_1, 0x1b, 0xffff, 0x70, PM_UNIT_TEX_M, 4},
    {MAXWELL_TEX0_LG_MISSED_SECTORS, maxwell_tex0_lg_missed_sectors_enc_str_1, 0x1b, 0xffff, 0x80, PM_UNIT_TEX_M, 4},
    {MAXWELL_TEX1_LG_MISSED_SECTORS, maxwell_tex1_lg_missed_sectors_enc_str_1, 0x1b, 0xffff, 0x6c, PM_UNIT_TEX_M, 4},

    //tex0_cache_sector_queries  = tex02pm_gpc_t_sector_queries
    //tex0_cache_sector_misses   = tex02pm_gpc_t_missed_sectors
    //tex1_cache_sector_queries = tex12pm_gpc_t_sector_queries
    //tex1_cache_sector_misses  = tex12pm_gpc_t_missed_sectors
    {MAXWELL_TEX0_SECTOR_QUERIES, maxwell_tex0_sector_queries_enc_str_1, 0x5, 0xffff, 0x84, PM_UNIT_TEX_M, 5},
    {MAXWELL_TEX1_SECTOR_QUERIES, maxwell_tex1_sector_queries_enc_str_1, 0x5, 0xffff, 0x70, PM_UNIT_TEX_M, 5},
    {MAXWELL_TEX0_MISSED_SECTORS, maxwell_tex0_missed_sectors_enc_str_1, 0x4, 0xffff, 0x80, PM_UNIT_TEX_M, 5},
    {MAXWELL_TEX1_MISSED_SECTORS, maxwell_tex1_missed_sectors_enc_str_1, 0x4, 0xffff, 0x6c, PM_UNIT_TEX_M, 5},

    {MAXWELL_TEX0_MISSED_SECTORS_ANY, maxwell_tex0_missed_sectors_any_enc_str_1, 0x4, 0xaaaa, 0x85, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_MISSED_SECTORS_ANY, maxwell_tex1_missed_sectors_any_enc_str_1, 0x4, 0xaaaa, 0x71, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_COALESCED_SECTORS, maxwell_tex0_coalesced_sectors_enc_str_1, 0x5, 0xffff, 0x80, PM_UNIT_TEX_M, 4},
    {MAXWELL_TEX1_COALESCED_SECTORS, maxwell_tex1_coalesced_sectors_enc_str_1, 0x5, 0xffff, 0x6c, PM_UNIT_TEX_M, 4},

    {MAXWELL_TEX0_CACHED_GLOBAL_LD_REQUESTS, maxwell_tex0_cached_global_ld_requests_enc_str_1, 0x40, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_CACHED_GLOBAL_LD_REQUESTS, maxwell_tex1_cached_global_ld_requests_enc_str_1, 0x40, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_GLOBAL_LD_REQUESTS, maxwell_tex0_global_ld_requests_enc_str_1, 0x40, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_GLOBAL_LD_REQUESTS, maxwell_tex1_global_ld_requests_enc_str_1, 0x40, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_UNCACHED_GLOBAL_LD_REQUESTS, maxwell_tex0_uncached_global_ld_requests_enc_str_1, 0x40, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_UNCACHED_GLOBAL_LD_REQUESTS, maxwell_tex1_uncached_global_ld_requests_enc_str_1, 0x40, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},

    {MAXWELL_TEX0_LOCAL_LD_REQUESTS, maxwell_tex0_local_ld_requests_enc_str_1, 0x43, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_LOCAL_LD_REQUESTS, maxwell_tex1_local_ld_requests_enc_str_1, 0x43, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_CACHED_LOCAL_LD_REQUESTS, maxwell_tex0_cached_local_ld_requests_enc_str_1, 0x43, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_CACHED_LOCAL_LD_REQUESTS, maxwell_tex1_cached_local_ld_requests_enc_str_1, 0x43, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_UNCACHED_LOCAL_LD_REQUESTS, maxwell_tex0_uncached_local_ld_requests_enc_str_1, 0x43, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_UNCACHED_LOCAL_LD_REQUESTS, maxwell_tex1_uncached_local_ld_requests_enc_str_1, 0x43, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},

    {MAXWELL_TEX0_CACHED_GLOBAL_LD_HITS, maxwell_tex0_cached_global_ld_hits_enc_str_1, 0x12, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_CACHED_GLOBAL_LD_HITS, maxwell_tex1_cached_global_ld_hits_enc_str_1, 0x12, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_CACHED_GLOBAL_LD_MISSES, maxwell_tex0_cached_global_ld_misses_enc_str_1, 0x12, 0xffff, 0x84, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_CACHED_GLOBAL_LD_MISSES, maxwell_tex1_cached_global_ld_misses_enc_str_1, 0x12, 0xffff, 0x70, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_UNCACHED_GLOBAL_LD_MISSES, maxwell_tex0_uncached_global_ld_misses_enc_str_1, 0x16, 0xffff, 0x84, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_UNCACHED_GLOBAL_LD_MISSES, maxwell_tex1_uncached_global_ld_misses_enc_str_1, 0x16, 0xffff, 0x70, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_GLOBAL_LD_HITS, maxwell_tex0_global_ld_hits_enc_str_1, 0x11, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_LD_HITS, maxwell_tex1_global_ld_hits_enc_str_1, 0x11, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_LD_MISSES, maxwell_tex0_global_ld_misses_enc_str_1, 0x11, 0xffff, 0x84, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_LD_MISSES, maxwell_tex1_global_ld_misses_enc_str_1, 0x11, 0xffff, 0x70, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_LOCAL_LD_HITS, maxwell_tex0_local_ld_hits_enc_str_1, 0x13, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_LOCAL_LD_HITS, maxwell_tex1_local_ld_hits_enc_str_1, 0x13, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_LOCAL_LD_MISSES, maxwell_tex0_local_ld_misses_enc_str_1, 0x13, 0xffff, 0x84, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_LOCAL_LD_MISSES, maxwell_tex1_local_ld_misses_enc_str_1, 0x13, 0xffff, 0x70, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_NUM_32_BIT_T_16, maxwell_tex0_num_32_bit_t_16_enc_str_1, 0x16, 0xffff, 0x88, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_NUM_64_BIT_T_16, maxwell_tex0_num_64_bit_t_16_enc_str_1, 0x16, 0xffff, 0x89, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_NUM_128_BIT_T_16, maxwell_tex0_num_128_bit_t_16_enc_str_1, 0x16, 0xffff, 0x8a, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_NUM_32_BIT_T_16, maxwell_tex1_num_32_bit_t_16_enc_str_1, 0x16, 0xffff, 0x74, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_NUM_64_BIT_T_16, maxwell_tex1_num_64_bit_t_16_enc_str_1, 0x16, 0xffff, 0x75, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_NUM_128_BIT_T_16, maxwell_tex1_num_128_bit_t_16_enc_str_1, 0x16, 0xffff, 0x76, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_SURFACE_LD_MISSES, maxwell_tex0_surface_ld_misses_enc_str_1, 0x19, 0xffff, 0x84, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_LD_MISSES, maxwell_tex1_surface_ld_misses_enc_str_1, 0x19, 0xffff, 0x70, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
/*
From Will Kohut:
I found that the following PM always seems to be 0:
tex2pm_gpc_t_global_cctl_invalidates (this may also apply to the local PM flavor as well)

Seema and I looked at the waves, and it appears that its 0 because the CCTL we use is an IVALL, which doesnt return a hits value (ie: no tag comparison is done, we just go ahead and invalidate everything).  Without a hits value, this PM will never toggle.

The PM spreadsheet defines these two PMs (ie: both global and local versions) as follows:
how many sector hits for the request.
Note,  cache invalidate request is considered as a hit
*/
    //{MAXWELL_TEX0_GLOBAL_CCTL_INVALIDATES, "__tex0_global_cctl_invalidates", 0x1d, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    //{MAXWELL_TEX1_GLOBAL_CCTL_INVALIDATES, "__tex1_global_cctl_invalidates", 0x1d, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_LD_SET_CONFLICTS, maxwell_tex0_global_ld_set_conflicts_enc_str_1, 0x6, 0xaaaa, 0x86, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_LD_SET_CONFLICTS, maxwell_tex1_global_ld_set_conflicts_enc_str_1, 0x6, 0xaaaa, 0x72, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_CACHED_GLOBAL_LD_SET_CONFLICTS, maxwell_tex0_cached_global_ld_set_conflicts_enc_str_1, 0x7, 0xaaaa, 0x86, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_CACHED_GLOBAL_LD_SET_CONFLICTS, maxwell_tex1_cached_global_ld_set_conflicts_enc_str_1, 0x7, 0xaaaa, 0x72, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_UNCACHED_GLOBAL_LD_SET_CONFLICTS, maxwell_tex0_uncached_global_ld_set_conflicts_enc_str_1, 0x7, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_UNCACHED_GLOBAL_LD_SET_CONFLICTS, maxwell_tex1_uncached_global_ld_set_conflicts_enc_str_1, 0x7, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_UNCACHED_GLOBAL_LD_COALESCING, maxwell_tex0_uncached_global_ld_coalescing_enc_str_1, 0x16, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_UNCACHED_GLOBAL_LD_COALESCING, maxwell_tex1_uncached_global_ld_coalescing_enc_str_1, 0x16, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_LD_COALESCING, maxwell_tex0_global_ld_coalescing_enc_str_1, 0x15, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_LD_COALESCING, maxwell_tex1_global_ld_coalescing_enc_str_1, 0x15, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_CACHED_LOCAL_LD_HITS, maxwell_tex0_cached_local_ld_hits_enc_str_1, 0x14, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_CACHED_LOCAL_LD_HITS, maxwell_tex1_cached_local_ld_hits_enc_str_1, 0x14, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_CACHED_LOCAL_LD_MISSES, maxwell_tex0_cached_local_ld_misses_enc_str_1, 0x14, 0xffff, 0x84, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_CACHED_LOCAL_LD_MISSES, maxwell_tex1_cached_local_ld_misses_enc_str_1, 0x14, 0xffff, 0x70, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_UNCACHED_LOCAL_LD_MISSES, maxwell_tex0_uncached_local_ld_misses_enc_str_1, 0x18, 0xffff, 0x84, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_UNCACHED_LOCAL_LD_MISSES, maxwell_tex1_uncached_local_ld_misses_enc_str_1, 0x18, 0xffff, 0x70, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_CACHED_GLOBAL_LD_SET_ACCESS, maxwell_tex0_cached_global_ld_set_access_enc_str_1, 0x7, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_CACHED_GLOBAL_LD_SET_ACCESS, maxwell_tex1_cached_global_ld_set_access_enc_str_1, 0x7, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_LD_SET_ACCESS, maxwell_tex0_global_ld_set_access_enc_str_1, 0x6, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_LD_SET_ACCESS, maxwell_tex1_global_ld_set_access_enc_str_1, 0x6, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_UNCACHED_GLOBAL_LD_SET_ACCESS, maxwell_tex0_uncached_global_ld_set_access_enc_str_1, 0x7, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_UNCACHED_GLOBAL_LD_SET_ACCESS, maxwell_tex1_uncached_global_ld_set_access_enc_str_1, 0x7, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_CACHED_LOCAL_LD_SET_ACCESS, maxwell_tex0_cached_local_ld_set_access_enc_str_1, 0xb, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_CACHED_LOCAL_LD_SET_ACCESS, maxwell_tex1_cached_local_ld_set_access_enc_str_1, 0xb, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_LOCAL_LD_SET_ACCESS, maxwell_tex0_local_ld_set_access_enc_str_1, 0xa, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_LOCAL_LD_SET_ACCESS, maxwell_tex1_local_ld_set_access_enc_str_1, 0xa, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_UNCACHED_LOCAL_LD_SET_ACCESS, maxwell_tex0_uncached_local_ld_set_access_enc_str_1, 0xb, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_UNCACHED_LOCAL_LD_SET_ACCESS, maxwell_tex1_uncached_local_ld_set_access_enc_str_1, 0xb, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},

    //{MAXWELL_TEX0_LOCAL_CCTL_INVALIDATES, "__tex0_local_cctl_invalidates", 0x1d, 0xffff, 0x84, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    //{MAXWELL_TEX1_LOCAL_CCTL_INVALIDATES, "__tex1_local_cctl_invalidates", 0x1d, 0xffff, 0x70, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_CACHED_LOCAL_LD_SET_CONFLICTS, maxwell_tex0_cached_local_ld_set_conflicts_enc_str_1, 0xb, 0xaaaa, 0x86, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_CACHED_LOCAL_LD_SET_CONFLICTS, maxwell_tex1_cached_local_ld_set_conflicts_enc_str_1, 0xb, 0xaaaa, 0x72, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_LOCAL_LD_SET_CONFLICTS, maxwell_tex0_local_ld_set_conflicts_enc_str_1, 0xa, 0xaaaa, 0x83, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_LOCAL_LD_SET_CONFLICTS, maxwell_tex1_local_ld_set_conflicts_enc_str_1, 0xa, 0xaaaa, 0x6f, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_UNCACHED_LOCAL_LD_SET_CONFLICTS, maxwell_tex0_uncached_local_ld_set_conflicts_enc_str_1, 0xb, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_UNCACHED_LOCAL_LD_SET_CONFLICTS, maxwell_tex1_uncached_local_ld_set_conflicts_enc_str_1, 0xb, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_LOCAL_LD_COALESCING, maxwell_tex0_local_ld_coalescing_enc_str_1, 0x17, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_LOCAL_LD_COALESCING, maxwell_tex1_local_ld_coalescing_enc_str_1, 0x17, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_UNCACHED_LOCAL_LD_COALESCING, maxwell_tex0_uncached_local_ld_coalescing_enc_str_1, 0x18, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_UNCACHED_LOCAL_LD_COALESCING, maxwell_tex1_uncached_local_ld_coalescing_enc_str_1, 0x18, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_GLOBAL_ST_REQUESTS, maxwell_tex0_global_st_requests_enc_str_1, 0x41, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_GLOBAL_ST_REQUESTS, maxwell_tex1_global_st_requests_enc_str_1, 0x41, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_LOCAL_ST_REQUESTS, maxwell_tex0_local_st_requests_enc_str_1, 0x44, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_LOCAL_ST_REQUESTS, maxwell_tex1_local_st_requests_enc_str_1, 0x44, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},

    {MAXWELL_TEX0_GLOBAL_ST_SET_ACCESS, maxwell_tex0_global_st_set_access_enc_str_1, 0x6, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_ST_SET_ACCESS, maxwell_tex1_global_st_set_access_enc_str_1, 0x6, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_LOCAL_ST_SET_ACCESS, maxwell_tex0_local_st_set_access_enc_str_1, 0xc, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_LOCAL_ST_SET_ACCESS, maxwell_tex1_local_st_set_access_enc_str_1, 0xc, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_GLOBAL_ST_SET_CONFLICTS, maxwell_tex0_global_st_set_conflicts_enc_str_1, 0x6, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_ST_SET_CONFLICTS, maxwell_tex1_global_st_set_conflicts_enc_str_1, 0x6, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_LOCAL_ST_SET_CONFLICTS, maxwell_tex0_local_st_set_conflicts_enc_str_1, 0xc, 0xaaaa, 0x86, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_LOCAL_ST_SET_CONFLICTS, maxwell_tex1_local_st_set_conflicts_enc_str_1, 0xc, 0xaaaa, 0x72, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_CACHED_GLOBAL_LD_DATA_CONFLICTS, maxwell_tex0_cached_global_ld_data_conflicts_enc_str_1, 0x15, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_CACHED_LOCAL_LD_DATA_CONFLICTS, maxwell_tex0_cached_local_ld_data_conflicts_enc_str_1, 0x18, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_GLOBAL_ATOM_CAS_DATA_CONFLICTS, maxwell_tex0_global_atom_cas_data_conflicts_enc_str_1, 0x16, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_GLOBAL_ATOM_DATA_CONFLICTS, maxwell_tex0_global_atom_data_conflicts_enc_str_1, 0x16, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_GLOBAL_LD_DATA_CONFLICTS, maxwell_tex0_global_ld_data_conflicts_enc_str_1, 0x14, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_LOCAL_LD_DATA_CONFLICTS, maxwell_tex0_local_ld_data_conflicts_enc_str_1, 0x17, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_SURFACE_ATOM_CAS_DATA_CONFLICTS, maxwell_tex0_surface_atom_cas_data_conflicts_enc_str_1, 0x1a, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_SURFACE_ATOM_DATA_CONFLICTS, maxwell_tex0_surface_atom_data_conflicts_enc_str_1, 0x1a, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_SURFACE_LD_DATA_CONFLICTS, maxwell_tex0_surface_ld_data_conflicts_enc_str_1, 0x19, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_UNCACHED_GLOBAL_LD_DATA_CONFLICTS, maxwell_tex0_uncached_global_ld_data_conflicts_enc_str_1, 0x15, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_UNCACHED_LOCAL_LD_DATA_CONFLICTS, maxwell_tex0_uncached_local_ld_data_conflicts_enc_str_1, 0x18, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_CACHED_GLOBAL_LD_DATA_CONFLICTS, maxwell_tex1_cached_global_ld_data_conflicts_enc_str_1, 0x15, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_CACHED_LOCAL_LD_DATA_CONFLICTS, maxwell_tex1_cached_local_ld_data_conflicts_enc_str_1, 0x18, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_GLOBAL_ATOM_CAS_DATA_CONFLICTS, maxwell_tex1_global_atom_cas_data_conflicts_enc_str_1, 0x16, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_GLOBAL_ATOM_DATA_CONFLICTS, maxwell_tex1_global_atom_data_conflicts_enc_str_1, 0x16, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_GLOBAL_LD_DATA_CONFLICTS, maxwell_tex1_global_ld_data_conflicts_enc_str_1, 0x14, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_LOCAL_LD_DATA_CONFLICTS, maxwell_tex1_local_ld_data_conflicts_enc_str_1, 0x17, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_SURFACE_ATOM_CAS_DATA_CONFLICTS, maxwell_tex1_surface_atom_cas_data_conflicts_enc_str_1, 0x1a, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_SURFACE_ATOM_DATA_CONFLICTS, maxwell_tex1_surface_atom_data_conflicts_enc_str_1, 0x1a, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_SURFACE_LD_DATA_CONFLICTS, maxwell_tex1_surface_ld_data_conflicts_enc_str_1, 0x19, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_UNCACHED_GLOBAL_LD_DATA_CONFLICTS, maxwell_tex1_uncached_global_ld_data_conflicts_enc_str_1, 0x15, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_UNCACHED_LOCAL_LD_DATA_CONFLICTS, maxwell_tex1_uncached_local_ld_data_conflicts_enc_str_1, 0x18, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_CACHED_GLOBAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex0_cached_global_ld_row_column_conflicts_enc_str_1, 0x1c, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_CACHED_LOCAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex0_cached_local_ld_row_column_conflicts_enc_str_1, 0x1f, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_GLOBAL_ATOM_CAS_ROW_COLUMN_CONFLICTS, maxwell_tex0_global_atom_cas_row_column_conflicts_enc_str_1, 0x1d, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_GLOBAL_ATOM_ROW_COLUMN_CONFLICTS, maxwell_tex0_global_atom_row_column_conflicts_enc_str_1, 0x1d, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_GLOBAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex0_global_ld_row_column_conflicts_enc_str_1, 0x1b, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_LOCAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex0_local_ld_row_column_conflicts_enc_str_1, 0x1e, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_SURFACE_ATOM_CAS_ROW_COLUMN_CONFLICTS, maxwell_tex0_surface_atom_cas_row_column_conflicts_enc_str_1, 0x21, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_SURFACE_ATOM_ROW_COLUMN_CONFLICTS, maxwell_tex0_surface_atom_row_column_conflicts_enc_str_1, 0x21, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_SURFACE_LD_ROW_COLUMN_CONFLICTS, maxwell_tex0_surface_ld_row_column_conflicts_enc_str_1, 0x20, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_UNCACHED_GLOBAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex0_uncached_global_ld_row_column_conflicts_enc_str_1, 0x1c, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_UNCACHED_LOCAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex0_uncached_local_ld_row_column_conflicts_enc_str_1, 0x1f, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_CACHED_GLOBAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex1_cached_global_ld_row_column_conflicts_enc_str_1, 0x1c, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_CACHED_LOCAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex1_cached_local_ld_row_column_conflicts_enc_str_1, 0x1f, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_GLOBAL_ATOM_CAS_ROW_COLUMN_CONFLICTS, maxwell_tex1_global_atom_cas_row_column_conflicts_enc_str_1, 0x1d, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_GLOBAL_ATOM_ROW_COLUMN_CONFLICTS, maxwell_tex1_global_atom_row_column_conflicts_enc_str_1, 0x1d, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_GLOBAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex1_global_ld_row_column_conflicts_enc_str_1, 0x1b, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_LOCAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex1_local_ld_row_column_conflicts_enc_str_1, 0x1e, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_SURFACE_ATOM_CAS_ROW_COLUMN_CONFLICTS, maxwell_tex1_surface_atom_cas_row_column_conflicts_enc_str_1, 0x21, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_SURFACE_ATOM_ROW_COLUMN_CONFLICTS, maxwell_tex1_surface_atom_row_column_conflicts_enc_str_1, 0x21, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_SURFACE_LD_ROW_COLUMN_CONFLICTS, maxwell_tex1_surface_ld_row_column_conflicts_enc_str_1, 0x20, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_UNCACHED_GLOBAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex1_uncached_global_ld_row_column_conflicts_enc_str_1, 0x1c, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_UNCACHED_LOCAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex1_uncached_local_ld_row_column_conflicts_enc_str_1, 0x1f, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},

    {MAXWELL_TEX0_GLOBAL_ATOM_REQUESTS, maxwell_tex0_global_atom_requests_enc_str_1, 0x42, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_GLOBAL_ATOM_REQUESTS, maxwell_tex1_global_atom_requests_enc_str_1, 0x42, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_GLOBAL_ATOM_SET_ACCESS, maxwell_tex0_global_atom_set_access_enc_str_1, 0x9, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_ATOM_SET_ACCESS, maxwell_tex1_global_atom_set_access_enc_str_1, 0x9, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_ATOM_SET_CONFLICTS, maxwell_tex0_global_atom_set_conflicts_enc_str_1, 0x9, 0xaaaa, 0x86, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_ATOM_SET_CONFLICTS, maxwell_tex1_global_atom_set_conflicts_enc_str_1, 0x9, 0xaaaa, 0x72, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_ATOM_CAS_REQUESTS, maxwell_tex0_global_atom_cas_requests_enc_str_1, 0x42, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_GLOBAL_ATOM_CAS_REQUESTS, maxwell_tex1_global_atom_cas_requests_enc_str_1, 0x42, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_GLOBAL_ATOM_CAS_SET_ACCESS, maxwell_tex0_global_atom_cas_set_access_enc_str_1, 0x9, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_ATOM_CAS_SET_ACCESS, maxwell_tex1_global_atom_cas_set_access_enc_str_1, 0x9, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_ATOM_CAS_SET_CONFLICTS, maxwell_tex0_global_atom_cas_set_conflicts_enc_str_1, 0x9, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_ATOM_CAS_SET_CONFLICTS, maxwell_tex1_global_atom_cas_set_conflicts_enc_str_1, 0x9, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_RED_REQUESTS, maxwell_tex0_global_red_requests_enc_str_1, 0x42, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_GLOBAL_RED_REQUESTS, maxwell_tex1_global_red_requests_enc_str_1, 0x42, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_GLOBAL_RED_SET_ACCESS, maxwell_tex0_global_red_set_access_enc_str_1, 0x8, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_RED_SET_ACCESS, maxwell_tex1_global_red_set_access_enc_str_1, 0x8, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_RED_SET_CONFLICTS, maxwell_tex0_global_red_set_conflicts_enc_str_1, 0x8, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_RED_SET_CONFLICTS, maxwell_tex1_global_red_set_conflicts_enc_str_1, 0x8, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_LD_SET_ACCESS, maxwell_tex0_surface_ld_set_access_enc_str_1, 0xd, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_LD_SET_ACCESS, maxwell_tex1_surface_ld_set_access_enc_str_1, 0xd, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_LD_SET_CONFLICTS, maxwell_tex0_surface_ld_set_conflicts_enc_str_1, 0xd, 0xaaaa, 0x86, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_LD_SET_CONFLICTS, maxwell_tex1_surface_ld_set_conflicts_enc_str_1, 0xd, 0xaaaa, 0x72, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_ST_SET_ACCESS, maxwell_tex0_surface_st_set_access_enc_str_1, 0xd, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_ST_SET_ACCESS, maxwell_tex1_surface_st_set_access_enc_str_1, 0xd, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_ST_SET_CONFLICTS, maxwell_tex0_surface_st_set_conflicts_enc_str_1, 0xd, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_ST_SET_CONFLICTS, maxwell_tex1_surface_st_set_conflicts_enc_str_1, 0xd, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_RED_SET_ACCESS, maxwell_tex0_surface_red_set_access_enc_str_1, 0xe, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_RED_SET_ACCESS, maxwell_tex1_surface_red_set_access_enc_str_1, 0xe, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_RED_SET_CONFLICTS, maxwell_tex0_surface_red_set_conflicts_enc_str_1, 0xe, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_RED_SET_CONFLICTS, maxwell_tex1_surface_red_set_conflicts_enc_str_1, 0xe, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_ATOM_SET_ACCESS, maxwell_tex0_surface_atom_set_access_enc_str_1, 0xf, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_ATOM_SET_ACCESS, maxwell_tex1_surface_atom_set_access_enc_str_1, 0xf, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_ATOM_CAS_SET_ACCESS, maxwell_tex0_surface_atom_cas_set_access_enc_str_1, 0xf, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_ATOM_CAS_SET_ACCESS, maxwell_tex1_surface_atom_cas_set_access_enc_str_1, 0xf, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_ATOM_SET_CONFLICTS, maxwell_tex0_surface_atom_set_conflicts_enc_str_1, 0xf, 0xaaaa, 0x86, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_ATOM_SET_CONFLICTS, maxwell_tex1_surface_atom_set_conflicts_enc_str_1, 0xf, 0xaaaa, 0x72, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_ATOM_CAS_SET_CONFLICTS, maxwell_tex0_surface_atom_cas_set_conflicts_enc_str_1, 0xf, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_ATOM_CAS_SET_CONFLICTS, maxwell_tex1_surface_atom_cas_set_conflicts_enc_str_1, 0xf, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_LD_REQUESTS, maxwell_tex0_surface_ld_requests_enc_str_1, 0x45, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_SURFACE_LD_REQUESTS, maxwell_tex1_surface_ld_requests_enc_str_1, 0x45, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_SURFACE_ST_REQUESTS, maxwell_tex0_surface_st_requests_enc_str_1, 0x45, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_SURFACE_ST_REQUESTS, maxwell_tex1_surface_st_requests_enc_str_1, 0x45, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_SURFACE_RED_REQUESTS, maxwell_tex0_surface_red_requests_enc_str_1, 0x46, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_SURFACE_RED_REQUESTS, maxwell_tex1_surface_red_requests_enc_str_1, 0x46, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_SURFACE_ATOM_REQUESTS, maxwell_tex0_surface_atom_requests_enc_str_1, 0x46, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_SURFACE_ATOM_REQUESTS, maxwell_tex1_surface_atom_requests_enc_str_1, 0x46, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_SURFACE_ATOM_CAS_REQUESTS, maxwell_tex0_surface_atom_cas_requests_enc_str_1, 0x46, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_SURFACE_ATOM_CAS_REQUESTS, maxwell_tex1_surface_atom_cas_requests_enc_str_1, 0x46, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},

    {MAXWELL_TEX0_GLOBAL_ATOM_ADDRESS_CONFLICTS, maxwell_tex0_global_atom_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x80, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_ATOM_CAS_ADDRESS_CONFLICTS, maxwell_tex0_global_atom_cas_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x81, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_RED_ADDRESS_CONFLICTS, maxwell_tex0_global_red_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x82, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_ATOM_ADDRESS_CONFLICTS, maxwell_tex0_surface_atom_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x83, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_ATOM_CAS_ADDRESS_CONFLICTS, maxwell_tex0_surface_atom_cas_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x84, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_RED_ADDRESS_CONFLICTS, maxwell_tex0_surface_red_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x85, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_ATOM_ADDRESS_CONFLICTS, maxwell_tex1_global_atom_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x6c, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_ATOM_CAS_ADDRESS_CONFLICTS, maxwell_tex1_global_atom_cas_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x6d, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_RED_ADDRESS_CONFLICTS, maxwell_tex1_global_red_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x6e, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_ATOM_ADDRESS_CONFLICTS, maxwell_tex1_surface_atom_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x6f, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_ATOM_CAS_ADDRESS_CONFLICTS, maxwell_tex1_surface_atom_cas_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x70, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_RED_ADDRESS_CONFLICTS, maxwell_tex1_surface_red_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x71, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_GLOBAL_ST_HITS_IN_WARP, maxwell_tex0_global_st_hits_in_warp_enc_str_1, 0x1a, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_LOCAL_ST_HITS_IN_WARP, maxwell_tex0_local_st_hits_in_warp_enc_str_1, 0x1b, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX0_SURFACE_ST_HITS_IN_WARP, maxwell_tex0_surface_st_hits_in_warp_enc_str_1, 0x1c, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_GLOBAL_ST_HITS_IN_WARP, maxwell_tex1_global_st_hits_in_warp_enc_str_1, 0x1a, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_LOCAL_ST_HITS_IN_WARP, maxwell_tex1_local_st_hits_in_warp_enc_str_1, 0x1b, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {MAXWELL_TEX1_SURFACE_ST_HITS_IN_WARP, maxwell_tex1_surface_st_hits_in_warp_enc_str_1, 0x1c, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {MAXWELL_TEX0_INPUT_ST_SECTOR_SUM, maxwell_tex0_input_st_sector_sum_enc_str_1, 0x1e, 0xffff, 0x82, PM_UNIT_TEX_M, 3},
    {MAXWELL_TEX1_INPUT_ST_SECTOR_SUM, maxwell_tex1_input_st_sector_sum_enc_str_1, 0x1e, 0xffff, 0x6e, PM_UNIT_TEX_M, 3},
    {MAXWELL_TEX0_INPUT_WR_SECTOR_SUM, maxwell_tex0_input_wr_sector_sum_enc_str_1, 0x1e, 0xffff, 0x85, PM_UNIT_TEX_M, 3},
    {MAXWELL_TEX1_INPUT_WR_SECTOR_SUM, maxwell_tex1_input_wr_sector_sum_enc_str_1, 0x1e, 0xffff, 0x71, PM_UNIT_TEX_M, 3},
    {MAXWELL_TEX0_OUTPUT_ST_SECTOR_SUM, maxwell_tex0_output_st_sector_sum_enc_str_1, 0x35, 0xffff, 0x80, PM_UNIT_TEX_M, 3},
    {MAXWELL_TEX1_OUTPUT_ST_SECTOR_SUM, maxwell_tex1_output_st_sector_sum_enc_str_1, 0x35, 0xffff, 0x6c, PM_UNIT_TEX_M, 3},
    {MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM, maxwell_tex0_output_wr_sector_sum_enc_str_1, 0x35, 0xffff, 0x80, PM_UNIT_TEX_M, 3},
    {MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM, maxwell_tex1_output_wr_sector_sum_enc_str_1, 0x35, 0xffff, 0x6c, PM_UNIT_TEX_M, 3},
    {MAXWELL_TEX0_MISSES_LG_ST, maxwell_tex0_misses_lg_st_enc_str_1, 0x35, 0xffff, 0x83, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_MISSES_LG_ST, maxwell_tex1_misses_lg_st_enc_str_1, 0x35, 0xffff, 0x6f, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_OUTPUT_GLOBAL, maxwell_tex0_output_global_enc_str_1, 0x35, 0xffff, 0x84, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_OUTPUT_GLOBAL, maxwell_tex1_output_global_enc_str_1, 0x35, 0xffff, 0x70, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_OUTPUT_LOCAL, maxwell_tex0_output_local_enc_str_1, 0x35, 0xffff, 0x85, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_OUTPUT_LOCAL, maxwell_tex1_output_local_enc_str_1, 0x35, 0xffff, 0x71, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_OUTPUT_ATOM, maxwell_tex0_output_atom_enc_str_1, 0x35, 0xffff, 0x86, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_OUTPUT_ATOM, maxwell_tex1_output_atom_enc_str_1, 0x35, 0xffff, 0x72, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_OUTPUT_ATOM_CAS, maxwell_tex0_output_atom_cas_enc_str_1, 0x35, 0xffff, 0x87, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_OUTPUT_ATOM_CAS, maxwell_tex1_output_atom_cas_enc_str_1, 0x35, 0xffff, 0x73, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_OUTPUT_RED, maxwell_tex0_output_red_enc_str_1, 0x35, 0xffff, 0x88, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_OUTPUT_RED, maxwell_tex1_output_red_enc_str_1, 0x35, 0xffff, 0x74, PM_UNIT_TEX_M, 1},

    {MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM_GRP20, maxwell_tex0_output_wr_sector_sum_grp20_enc_str_1, 0x20, 0xffff, 0x83, PM_UNIT_TEX_M, 3},
    {MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM_GRP20, maxwell_tex1_output_wr_sector_sum_grp20_enc_str_1, 0x20, 0xffff, 0x6f, PM_UNIT_TEX_M, 3},
    {MAXWELL_TEX0_OUTPUT_GLOBAL_GRP20, maxwell_tex0_output_global_grp20_enc_str_1, 0x20, 0xffff, 0x86, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_OUTPUT_GLOBAL_GRP20, maxwell_tex1_output_global_grp20_enc_str_1, 0x20, 0xffff, 0x72, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_OUTPUT_LOCAL_GRP20, maxwell_tex0_output_local_grp20_enc_str_1, 0x20, 0xffff, 0x87, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_OUTPUT_LOCAL_GRP20, maxwell_tex1_output_local_grp20_enc_str_1, 0x20, 0xffff, 0x73, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_OUTPUT_SUST_GRP20, maxwell_tex0_output_sust_grp20_enc_str_1, 0x20, 0xffff, 0x88, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_OUTPUT_SUST_GRP20, maxwell_tex1_output_sust_grp20_enc_str_1, 0x20, 0xffff, 0x74, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_OUTPUT_RED_GRP20, maxwell_tex0_output_red_grp20_enc_str_1, 0x20, 0xffff, 0x8a, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_OUTPUT_RED_GRP20, maxwell_tex1_output_red_grp20_enc_str_1, 0x20, 0xffff, 0x76, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_OUTPUT_ATOM_OR_ATOM_CAS_GRP20, maxwell_tex0_output_atom_or_atom_cas_grp20_enc_str_1, 0x20, 0xffff, 0x89, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_OUTPUT_ATOM_OR_ATOM_CAS_GRP20, maxwell_tex1_output_atom_or_atom_cas_grp20_enc_str_1, 0x20, 0xffff, 0x75, PM_UNIT_TEX_M, 1},

    {MAXWELL_TEX0_TEX2SM_TEX_PRDY, maxwell_tex0_tex2sm_tex_prdy_enc_str_1, 0x3, 0xaaaa, 0xa3, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_TEX2SM_TEX_PRDY, maxwell_tex1_tex2sm_tex_prdy_enc_str_1, 0x3, 0xaaaa, 0x9a, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX0_TEX2SM_TEX_PVLD, maxwell_tex0_tex2sm_tex_pvld_enc_str_1, 0x3, 0xaaaa, 0xa2, PM_UNIT_TEX_D, 1},
    {MAXWELL_TEX1_TEX2SM_TEX_PVLD, maxwell_tex1_tex2sm_tex_pvld_enc_str_1, 0x3, 0xaaaa, 0x99, PM_UNIT_TEX_D, 1},

    {MAXWELL_TEX0_GLOBAL_LD_REQUESTS_4B, maxwell_tex0_global_ld_requests_4b_enc_str_1, 0x4b, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_GLOBAL_LD_REQUESTS_4B, maxwell_tex1_global_ld_requests_4b_enc_str_1, 0x4b, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_NUM_8_BIT_4B, maxwell_tex0_num_8_bit_4b_enc_str_1, 0x4b, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_NUM_8_BIT_4B, maxwell_tex1_num_8_bit_4b_enc_str_1, 0x4b, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_NUM_16_BIT_4B, maxwell_tex0_num_16_bit_4b_enc_str_1, 0x4b, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_NUM_16_BIT_4B, maxwell_tex1_num_16_bit_4b_enc_str_1, 0x4b, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_NUM_FP16X2_4B, maxwell_tex0_num_fp16x2_4b_enc_str_1, 0x4b, 0xaaaa, 0x8e, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_NUM_FP16X2_4B, maxwell_tex1_num_fp16x2_4b_enc_str_1, 0x4b, 0xaaaa, 0x94, PM_UNIT_TEX_S, 1},

    {MAXWELL_TEX0_GLOBAL_LD_REQUESTS_4C, maxwell_tex0_global_ld_requests_4c_enc_str_1, 0x4c, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_GLOBAL_LD_REQUESTS_4C, maxwell_tex1_global_ld_requests_4c_enc_str_1, 0x4c, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_NUM_32_BIT_4C, maxwell_tex0_num_32_bit_4c_enc_str_1, 0x4c, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_NUM_32_BIT_4C, maxwell_tex1_num_32_bit_4c_enc_str_1, 0x4c, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_NUM_64_BIT_4C, maxwell_tex0_num_64_bit_4c_enc_str_1, 0x4c, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_NUM_64_BIT_4C, maxwell_tex1_num_64_bit_4c_enc_str_1, 0x4c, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_NUM_128_BIT_4C, maxwell_tex0_num_128_bit_4c_enc_str_1, 0x4c, 0xaaaa, 0x8e, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_NUM_128_BIT_4C, maxwell_tex1_num_128_bit_4c_enc_str_1, 0x4c, 0xaaaa, 0x94, PM_UNIT_TEX_S, 1},

    {MAXWELL_TEX0_SM2TEX_REQ_PRDY, maxwell_tex0_sm2tex_req_prdy_enc_str_1, 0x24 , 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_SM2TEX_REQ_PRDY, maxwell_tex1_sm2tex_req_prdy_enc_str_1, 0x24 , 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_SM2TEX_REQ_PVLD, maxwell_tex0_sm2tex_req_pvld_enc_str_1, 0x24 , 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_SM2TEX_REQ_PVLD, maxwell_tex1_sm2tex_req_pvld_enc_str_1, 0x24 , 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX0_C0_IS_TEX, maxwell_tex0_c0_is_tex_enc_str_1, 0x24, 0xaaaa, 0x90, PM_UNIT_TEX_S, 1},
    {MAXWELL_TEX1_C0_IS_TEX, maxwell_tex1_c0_is_tex_enc_str_1, 0x24, 0xaaaa, 0x96, PM_UNIT_TEX_S, 1},      

    {MAXWELL_TEX0_M2_SECTOR_MISSES_READ_SUM_27, maxwell_tex0_m2_sector_misses_read_sum_27_enc_str_1, 0x27, 0xffff, 0x80, PM_UNIT_TEX_M, 3},
    {MAXWELL_TEX1_M2_SECTOR_MISSES_READ_SUM_27, maxwell_tex1_m2_sector_misses_read_sum_27_enc_str_1, 0x27, 0xffff, 0x6c, PM_UNIT_TEX_M, 3},
    {MAXWELL_TEX0_M2_MISSES_GLOBAL_27, maxwell_tex0_m2_misses_global_27_enc_str_1, 0x27, 0xaaaa, 0x83, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_M2_MISSES_GLOBAL_2d, maxwell_tex0_m2_misses_global_2d_enc_str_1, 0x2d, 0xaaaa, 0x83, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_M2_MISSES_GLOBAL_27, maxwell_tex1_m2_misses_global_27_enc_str_1, 0x27, 0xaaaa, 0x6f, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_M2_MISSES_GLOBAL_2d, maxwell_tex1_m2_misses_global_2d_enc_str_1, 0x2d, 0xaaaa, 0x6f, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_M2_MISSES_LOCAL_27, maxwell_tex0_m2_misses_local_27_enc_str_1, 0x27, 0xaaaa, 0x84, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_M2_MISSES_LOCAL_27, maxwell_tex1_m2_misses_local_27_enc_str_1, 0x27, 0xaaaa, 0x70, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_M2_MISSES_LOCAL_2d, maxwell_tex0_m2_misses_local_2d_enc_str_1, 0x2d, 0xaaaa, 0x84, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_M2_MISSES_LOCAL_2d, maxwell_tex1_m2_misses_local_2d_enc_str_1, 0x2d, 0xaaaa, 0x70, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_M2_MISSES_LG_LD_27, maxwell_tex0_m2_misses_lg_ld_27_enc_str_1, 0x27, 0xaaaa, 0x85, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_M2_MISSES_LG_LD_27, maxwell_tex1_m2_misses_lg_ld_27_enc_str_1, 0x27, 0xaaaa, 0x71, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_M2_MISSES_LG_ATOM_27, maxwell_tex0_m2_misses_lg_atom_27_enc_str_1, 0x27, 0xaaaa, 0x86, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_M2_MISSES_LG_ATOM_2d, maxwell_tex0_m2_misses_lg_atom_2d_enc_str_1, 0x2d, 0xaaaa, 0x86, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_M2_MISSES_LG_ATOM_CAS_27, maxwell_tex0_m2_misses_lg_atom_cas_27_enc_str_1, 0x27, 0xaaaa, 0x87, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_M2_MISSES_LG_ATOM_CAS_2d, maxwell_tex0_m2_misses_lg_atom_cas_2d_enc_str_1, 0x2d, 0xaaaa, 0x87, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_M2_MISSES_LG_ATOM_27, maxwell_tex1_m2_misses_lg_atom_27_enc_str_1, 0x27, 0xaaaa, 0x72, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_M2_MISSES_LG_ATOM_2d, maxwell_tex1_m2_misses_lg_atom_2d_enc_str_1, 0x2d, 0xaaaa, 0x72, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_M2_MISSES_LG_ATOM_CAS_27, maxwell_tex1_m2_misses_lg_atom_cas_27_enc_str_1, 0x27, 0xaaaa, 0x73, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_M2_MISSES_LG_ATOM_CAS_2d, maxwell_tex1_m2_misses_lg_atom_cas_2d_enc_str_1, 0x2d, 0xaaaa, 0x73, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_M2_MISSES_LG_ST_2d, maxwell_tex0_m2_misses_lg_st_2d_enc_str_1, 0x2d, 0xaaaa, 0x85, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_M2_MISSES_LG_ST_2d, maxwell_tex1_m2_misses_lg_st_2d_enc_str_1, 0x2d, 0xaaaa, 0x71, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX0_M2_SECTOR_MISSES_WRITE_SUM_2d, maxwell_tex0_m2_sector_misses_write_sum_2d_enc_str_1, 0x2d, 0xffff, 0x80, PM_UNIT_TEX_M, 3},
    {MAXWELL_TEX1_M2_SECTOR_MISSES_WRITE_SUM_2d, maxwell_tex1_m2_sector_misses_write_sum_2d_enc_str_1, 0x2d, 0xffff, 0x6c, PM_UNIT_TEX_M, 3},
    {MAXWELL_TEX0_M2_MISSES_LG_RED_2d, maxwell_tex0_m2_misses_lg_red_2d_enc_str_1, 0x2d, 0xaaaa, 0x88, PM_UNIT_TEX_M, 1},
    {MAXWELL_TEX1_M2_MISSES_LG_RED_2d, maxwell_tex1_m2_misses_lg_red_2d_enc_str_1, 0x2d, 0xaaaa, 0x74, PM_UNIT_TEX_M, 1},

    { MAXWELL_ELAPSED_CYCLES_SM,            maxwell_elapsed_cycles_sm_enc_str_1,          0x00000000, 0x00000000, 0x00000000,    PM_UNIT_SMCORE,0},
    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpmMux PerfSignalTableGM200_hwpmmux[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type

#if CU_MAXWELL_PROFILE_SM_SIGNALS_VIA_HWPM
    // ########### SM Unit ###########
    // ***LAUNCHED***
    // sch_warps_launched               SM has launched 1 warp
    // sch_threads_launched             number of threads SM launched this cycle
    //TBD check with latest files, threads_launched watchbus looks incorrect
    {MAXWELL_HWPMMUX_WARPS_LAUNCHED, maxwell_hwpmmux_warps_launched_enc_str_1, 0x1, 0xaaaa, 0x11, PM_UNIT_SMQCTL, 1, 1},
    {MAXWELL_HWPMMUX_THREADS_LAUNCHED, maxwell_hwpmmux_threads_launched_enc_str_1, 0x19, 0xffff, 0x10, PM_UNIT_SMQCTL, 6, 0},
    {MAXWELL_HWPMMUX_ACTIVE_CYCLES, maxwell_hwpmmux_active_cycles_enc_str_1, 0x1, 0xaaaa, 0x1, PM_UNIT_SMCORE, 1, 1},
    {MAXWELL_HWPMMUX_ACTIVE_WARPS, maxwell_hwpmmux_active_warps_enc_str_1, 0x1, 0xffff, 0x2, PM_UNIT_SMCORE, 6, 2},
    {MAXWELL_HWPMMUX_CTA_LAUNCHED, maxwell_hwpmmux_cta_launched_enc_str_1, 0x6, 0xaaaa, 0x1, PM_UNIT_SMCORE, 1, 1},
    {MAXWELL_HWPMMUX_SHARED_LD_MEM_DIVERGENCE_REPLAYS, maxwell_hwpmmux_shared_ld_mem_divergence_replays_enc_str_1, 0x00000007, 0xaaaa, 0x00000050, PM_UNIT_MIO, 1 ,0 },
    {MAXWELL_HWPMMUX_SHARED_ST_MEM_DIVERGENCE_REPLAYS, maxwell_hwpmmux_shared_st_mem_divergence_replays_enc_str_1, 0x00000007, 0xaaaa, 0x00000051, PM_UNIT_MIO, 1 ,1 },
    {MAXWELL_HWPMMUX_SHARED_LD_TRANSACTIONS,           maxwell_hwpmmux_shared_ld_transactions_enc_str_1,           0x00000007, 0xaaaa, 0x00000052, PM_UNIT_MIO, 1 ,2 },
    {MAXWELL_HWPMMUX_SHARED_ST_TRANSACTIONS,           maxwell_hwpmmux_shared_st_transactions_enc_str_1,           0x00000007, 0xaaaa, 0x00000053, PM_UNIT_MIO, 1 ,3 },
#endif
    { MAXWELL_SMQCTL_INST_EXECUTED_FP16G0_PIPE, maxwell_smqctl_inst_executed_fp16g0_pipe_enc_str_1, 0xe, 0xaaaa, 0x1a, PM_UNIT_SMQCTL, 1, 0xa},
    { MAXWELL_SMQCTL_INST_EXECUTED_FP16G1_PIPE, maxwell_smqctl_inst_executed_fp16g1_pipe_enc_str_1, 0xe, 0xaaaa, 0x1b, PM_UNIT_SMQCTL, 1, 0xb},
    { MAXWELL_SMQCTL_INST_EXECUTED_FP16G0_PIPE_HIGHPOWER, maxwell_smqctl_inst_executed_fp16g0_pipe_highpower_enc_str_1, 0xe, 0xaaaa, 0x1c, PM_UNIT_SMQCTL, 1, 0xc},
    { MAXWELL_SMQCTL_INST_EXECUTED_FP16G1_PIPE_HIGHPOWER, maxwell_smqctl_inst_executed_fp16g1_pipe_highpower_enc_str_1, 0xe, 0xaaaa, 0x1d, PM_UNIT_SMQCTL, 1, 0xd},
    { MAXWELL_SMQCTL_INST_FP16G0_PIPE_UNIFORM_DATA_QUAD_Q, maxwell_smqctl_inst_fp16g0_pipe_uniform_data_quad_q_enc_str_1, 0x55, 0xffff, 0x18, PM_UNIT_SMQCTL, 3, 0x8},
    { MAXWELL_SMQCTL_INST_FP16G1_PIPE_UNIFORM_DATA_QUAD_Q, maxwell_smqctl_inst_fp16g1_pipe_uniform_data_quad_q_enc_str_1, 0x55, 0xffff, 0x1b, PM_UNIT_SMQCTL, 3, 0xb},

    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpm PerfSignalTableGM200_ltc0[] = {
    //LTC signals
    // l2_subp0_write_sector_misses = ltc_ltc2fb_dirty_dat0_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 0
    // l2_subp1_write_sector_misses = ltc_ltc2fb_dirty_dat1_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 1
    // l2_subp0_read_sector_misses  = ltc_fb2ltc_rdat0_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 0
    // l2_subp1_read_sector_misses  = ltc_fb2ltc_rdat1_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 1
    // l2_subp0_write_l1_sector_queries = ltc2pm_ltc_lts0_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 0
    // l2_subp1_write_l1_sector_queries = ltc2pm_ltc_lts1_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 1
    // l2_subp0_read_l1_sector_queries  = ltc2pm_ltc_lts0_request_rd_op && ltc2pm_ltc_lts1_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 0
    // l2_subp1_read_l1_sector_queries  = ltc2pm_ltc_lts1_request_rd_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 1

    {MAXWELL_LTC0_WRITE_MISS_SECTORS, maxwell_ltc0_write_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x28, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC0_READ_MISS_SECTORS, maxwell_ltc0_read_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x29, PM_UNIT_LTS1, 1},

    {MAXWELL_LTC0_HIT_SECTORS, maxwell_ltc0_hit_sectors_enc_str_1, 0x1, 0xffff, 0x1c, PM_UNIT_LTS, 4},
    {MAXWELL_LTC0_REQUEST_SECTORS, maxwell_ltc0_request_sectors_enc_str_1, 0x0, 0xffff, 0x1c, PM_UNIT_LTS, 4},
    {MAXWELL_LTC0_MISS_SECTORS, maxwell_ltc0_miss_sectors_enc_str_1, 0x2, 0xffff, 0x1c, PM_UNIT_LTS, 4},

    {MAXWELL_LTC0_REQUEST_SRC_UNIT_L1, maxwell_ltc0_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x40, PM_UNIT_LTS2, 1},
    {MAXWELL_LTC0_REQUEST_SRC_UNIT_TEX, maxwell_ltc0_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x40, PM_UNIT_LTS2, 1},
    {MAXWELL_LTC0_REQUEST_SRC_UNIT_GCC, maxwell_ltc0_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x40, PM_UNIT_LTS2, 1},

    {MAXWELL_LTC0_REQUEST_ACTIVE, maxwell_ltc0_request_active_enc_str_1, 0x0, 0xaaaa, 0x25, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC0_REQUEST_RD_OP, maxwell_ltc0_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x3d, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC0_REQUEST_WR_OP, maxwell_ltc0_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x3c, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC0_REQUEST_ATOMIC_OP, maxwell_ltc0_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x3b, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC0_REQUEST_APERTURE_SYSMEM, maxwell_ltc0_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x37, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC0_REQUEST_APERTURE_VIDMEM, maxwell_ltc0_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x36, PM_UNIT_LTS1, 1},

    {MAXWELL_LTC0_HIT, maxwell_ltc0_hit_enc_str_1, 0x0, 0xaaaa, 0x2c, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC0_REQUEST, maxwell_ltc0_request_enc_str_1, 0x0, 0xaaaa, 0x24, PM_UNIT_LTS1, 1},

    {MAXWELL_LTC1_WRITE_MISS_SECTORS, maxwell_ltc1_write_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x4, PM_UNIT_LTS1_1, 1},
    {MAXWELL_LTC1_READ_MISS_SECTORS, maxwell_ltc1_read_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x5, PM_UNIT_LTS1_1, 1},

    {MAXWELL_LTC1_HIT_SECTORS, maxwell_ltc1_hit_sectors_enc_str_1, 0x1, 0xffff, 0x20, PM_UNIT_LTS_1, 4},
    {MAXWELL_LTC1_REQUEST_SECTORS, maxwell_ltc1_request_sectors_enc_str_1, 0x0, 0xffff, 0x20, PM_UNIT_LTS_1, 4},
    {MAXWELL_LTC1_MISS_SECTORS, maxwell_ltc1_miss_sectors_enc_str_1, 0x2, 0xffff, 0x20, PM_UNIT_LTS_1, 4},

    {MAXWELL_LTC1_REQUEST_SRC_UNIT_L1, maxwell_ltc1_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x41, PM_UNIT_LTS2_1, 1},
    {MAXWELL_LTC1_REQUEST_SRC_UNIT_TEX, maxwell_ltc1_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x41, PM_UNIT_LTS2_1, 1},
    {MAXWELL_LTC1_REQUEST_SRC_UNIT_GCC, maxwell_ltc1_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x41, PM_UNIT_LTS2_1, 1},

    {MAXWELL_LTC1_REQUEST_ACTIVE, maxwell_ltc1_request_active_enc_str_1, 0x0, 0xaaaa, 0x1, PM_UNIT_LTS1_1, 1},
    {MAXWELL_LTC1_REQUEST_RD_OP, maxwell_ltc1_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x19, PM_UNIT_LTS1_1, 1},
    {MAXWELL_LTC1_REQUEST_WR_OP, maxwell_ltc1_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x18, PM_UNIT_LTS1_1, 1},
    {MAXWELL_LTC1_REQUEST_ATOMIC_OP, maxwell_ltc1_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x17, PM_UNIT_LTS1_1, 1},
    {MAXWELL_LTC1_REQUEST_APERTURE_SYSMEM, maxwell_ltc1_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x13, PM_UNIT_LTS1_1, 1},
    {MAXWELL_LTC1_REQUEST_APERTURE_VIDMEM, maxwell_ltc1_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x12, PM_UNIT_LTS1_1, 1},

    {MAXWELL_LTC1_HIT, maxwell_ltc1_hit_enc_str_1, 0x0, 0xaaaa, 0x8, PM_UNIT_LTS1_1, 1},
    {MAXWELL_LTC1_REQUEST, maxwell_ltc1_request_enc_str_1, 0x0, 0xaaaa, 0x0, PM_UNIT_LTS1_1, 1},

    { INVALID_PM_SIGNAL_NEW,        "",                                 0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpm PerfSignalTableGM200_sys0[] = {
    //Hub TLB signals
    //__hub_tlb_hit        = hubmmu2pm_hub_hub_tlb_hit                                      count # of PTE hits in hub TLB
    //__hub_tlb_miss       = (hubmmu2pm_hub_hub_tlb_miss & !hubmmu2pm_hub_hub_tlb_hit)      count # of PTE misses in hub TLB
    { MAXWELL_MMU_HUB_TLB_HIT,    maxwell_mmu_hub_tlb_hit_enc_str_1,    0x00000004, 0x0000AAAA, 0x54,    PM_UNIT_HUBMMU, 1 },
    { MAXWELL_MMU_HUB_TLB_MISS_INT,   maxwell_mmu_hub_tlb_miss_int_enc_str_1,   0x00000004, 0x0000AAAA, 0x55,    PM_UNIT_HUBMMU, 1 },

    // mmu_fill_pte_hit    = hubmmu2pm_hub_fill_pte_hit                                     "count # of PTE hits in mmu fill unit"
    // mmu_fill_pte_miss   = (hubmmu2pm_hub_fill_pte_miss & !hubmmu2pm_hub_fill_pte_hit)    "count # of PTE misses in mmu fill unit"
    { MAXWELL_MMU_FILL_PTE_HIT,   maxwell_mmu_fill_pte_hit_enc_str_1,   0x00000006, 0x0000AAAA, 0x54,    PM_UNIT_HUBMMU, 1 },
    { MAXWELL_MMU_FILL_PTE_MISS_INT,  maxwell_mmu_fill_pte_miss_int_enc_str_1,  0x00000006, 0x0000AAAA, 0x55,    PM_UNIT_HUBMMU, 1 },

    // mmu_fill_pde_hit    = hubmmu2pm_hub_fill_pde_hit                                     "count # of PDE hits in mmu fill unit"
    // mmu_fill_pde_miss   = hubmmu2pm_hub_fill_pde_miss                                    "count # of PDE misses in mmu fill unit"
    { MAXWELL_MMU_FILL_PDE_HIT,   maxwell_mmu_fill_pde_hit_enc_str_1,   0x00000006, 0x0000AAAA, 0x56,    PM_UNIT_HUBMMU,1 },
    { MAXWELL_MMU_FILL_PDE_MISS,  maxwell_mmu_fill_pde_miss_enc_str_1,  0x00000006, 0x0000AAAA, 0x57,    PM_UNIT_HUBMMU,1 },

    {MAXWELL_MMU_GPCL2_TLB_HIT, maxwell_mmu_gpcl2_tlb_hit_enc_str_1, 0x3, 0xaaaa, 0x54, PM_UNIT_HUBMMU, 1},
    {MAXWELL_MMU_GPCL2_TLB_MISS_INT, maxwell_mmu_gpcl2_tlb_miss_int_enc_str_1, 0x3, 0xaaaa, 0x55, PM_UNIT_HUBMMU, 1},

    {MAXWELL_SKED_VSFSM_VSPAN_ADD, maxwell_sked_vsfsm_vspan_add_enc_str_1, 0x6, 0xaaaa, 0x29, PM_UNIT_SKED, 1},
    {MAXWELL_SKED_VSFSM_VSPAN_BRIDGE, maxwell_sked_vsfsm_vspan_bridge_enc_str_1, 0x6, 0xaaaa, 0x2a, PM_UNIT_SKED, 1},
    {MAXWELL_SKED_VSFSM_VSPAN_MERGE, maxwell_sked_vsfsm_vspan_merge_enc_str_1, 0x6, 0xaaaa, 0x28, PM_UNIT_SKED, 1},
    {MAXWELL_SKED_VSFSM_UPDATE_PUT_VLD, maxwell_sked_vsfsm_update_put_vld_enc_str_1, 0x6, 0xaaaa, 0x2c, PM_UNIT_SKED, 1},
    {MAXWELL_SKED_VSFSM_UPDATE_PUT_RDY, maxwell_sked_vsfsm_update_put_rdy_enc_str_1, 0x6, 0xaaaa, 0x2d, PM_UNIT_SKED, 1},
    {MAXWELL_SKED_VSFSM_READ, maxwell_sked_vsfsm_read_enc_str_1, 0x6, 0xaaaa, 0x2e, PM_UNIT_SKED, 1},
    {MAXWELL_SKED_VSFSM_WRITE, maxwell_sked_vsfsm_write_enc_str_1, 0x6, 0xaaaa, 0x2f, PM_UNIT_SKED, 1},
    {MAXWELL_SKED_VSM_FB_WRITE, maxwell_sked_vsm_fb_write_enc_str_1, 0x7, 0xaaaa, 0x28, PM_UNIT_SKED, 1},
    {MAXWELL_SKED_VSM_FB_READ, maxwell_sked_vsm_fb_read_enc_str_1, 0x7, 0xaaaa, 0x29, PM_UNIT_SKED, 1},
    {MAXWELL_SKED_VSM_LOCAL_WRITE, maxwell_sked_vsm_local_write_enc_str_1, 0x7, 0xaaaa, 0x2a, PM_UNIT_SKED, 1},
    {MAXWELL_SKED_VSM_LOCAL_READ, maxwell_sked_vsm_local_read_enc_str_1, 0x7, 0xaaaa, 0x2b, PM_UNIT_SKED, 1},
    {MAXWELL_SKED_VSM_LOCAL_FREE, maxwell_sked_vsm_local_free_enc_str_1, 0x7, 0xaaaa, 0x2c, PM_UNIT_SKED, 1},
    {MAXWELL_SKED_VSM_FB_FREE, maxwell_sked_vsm_fb_free_enc_str_1, 0x7, 0xaaaa, 0x2d, PM_UNIT_SKED, 1},
    {MAXWELL_SKED_VSM_LOCAL_ALLOC, maxwell_sked_vsm_local_alloc_enc_str_1, 0x7, 0xaaaa, 0x2e, PM_UNIT_SKED, 1},
    {MAXWELL_SKED_VSM_FB_ALLOC, maxwell_sked_vsm_fb_alloc_enc_str_1, 0x7, 0xaaaa, 0x2f, PM_UNIT_SKED, 1},

    { INVALID_PM_SIGNAL_NEW,     "",                     0xffffffff, 0x00000000, 0x00,     PM_UNIT_MAX,0}
};

#if NVCFG(GLOBAL_GPU_FAMILY_GM20X)
PerfSignalHwpm PerfSignalTableGM20x_pcie0[] = {
    {MAXWELL_PCIE_TX_ACTIVE, maxwell_pcie_tx_active_enc_str_1,  0xb,        0xaaaa,     0x4,    PM_UNIT_XVE1,   1},
    {MAXWELL_PCIE_TX_IDLE,   maxwell_pcie_tx_idle_enc_str_1,    0xb,        0xaaaa,     0x3,    PM_UNIT_XVE1,   1},
    {MAXWELL_PCIE_RX_ACTIVE, maxwell_pcie_rx_active_enc_str_1,  0xe,        0xaaaa,     0x1e,   PM_UNIT_XVE2,   1},
    {MAXWELL_PCIE_RX_IDLE,   maxwell_pcie_rx_idle_enc_str_1,    0xe,        0xaaaa,     0x1d,   PM_UNIT_XVE2,   1},
    {INVALID_PM_SIGNAL_NEW, "",                                 0xffffffff, 0x00000000, 0x00,   PM_UNIT_MAX,    0 }
};
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GM20X) */

PerfSignalHwpmExpt PerfSignalTableGM200_sys0_expt[] = {
    //Hub TLB signals
    //__hub_tlb_miss       = (hubmmu2pm_hub_hub_tlb_miss & !hubmmu2pm_hub_hub_tlb_hit)      count # of PTE misses in hub TLB
    { MAXWELL_MMU_HUB_TLB_MISS, maxwell_mmu_hub_tlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_MMU_HUB_TLB_HIT, MAXWELL_MMU_HUB_TLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},

    // mmu_fill_pte_miss   = (hubmmu2pm_hub_fill_pte_miss & !hubmmu2pm_hub_fill_pte_hit)    "count # of PTE misses in mmu fill unit"
    { MAXWELL_MMU_FILL_PTE_MISS, maxwell_mmu_fill_pte_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_MMU_FILL_PTE_HIT, MAXWELL_MMU_FILL_PTE_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},

    //__hub_gpcl2_tlb_miss = (hubmmu2pm_hub_gpcl2_tlb_miss & !hubmmu2pm_hub_gpcl2_tlb_hit)  count # of PTE misses in gpcl2 TLB
    { MAXWELL_MMU_GPCL2_TLB_MISS, maxwell_mmu_gpcl2_tlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_MMU_GPCL2_TLB_HIT, MAXWELL_MMU_GPCL2_TLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},

   { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000,  0x00}
};

PerfSignalSmpc PerfSignalTableGM200_sm0[] = {

    { MAXWELL_SM_PROF_TRIGGER_00,  maxwell_sm_prof_trigger_00_enc_str_1, 0x00000000, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig0"
    { MAXWELL_SM_PROF_TRIGGER_01,  maxwell_sm_prof_trigger_01_enc_str_1, 0x00000000, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig1"
    { MAXWELL_SM_PROF_TRIGGER_02,  maxwell_sm_prof_trigger_02_enc_str_1, 0x00000000, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig2"
    { MAXWELL_SM_PROF_TRIGGER_03,  maxwell_sm_prof_trigger_03_enc_str_1, 0x00000000, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig3"
    { MAXWELL_SM_PROF_TRIGGER_04,  maxwell_sm_prof_trigger_04_enc_str_1, 0x00000000, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig4"
    { MAXWELL_SM_PROF_TRIGGER_05,  maxwell_sm_prof_trigger_05_enc_str_1, 0x00000000, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig5"
    { MAXWELL_SM_PROF_TRIGGER_06,  maxwell_sm_prof_trigger_06_enc_str_1, 0x00000000, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig6"
    { MAXWELL_SM_PROF_TRIGGER_07,  maxwell_sm_prof_trigger_07_enc_str_1, 0x00000000, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig7"
    { MAXWELL_SM_PMTRIG8,  maxwell_sm_pmtrig8_enc_str_1, 0x00000001, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig8"
    { MAXWELL_SM_PMTRIG9,  maxwell_sm_pmtrig9_enc_str_1, 0x00000001, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig9"
    { MAXWELL_SM_PMTRIG10,  maxwell_sm_pmtrig10_enc_str_1, 0x00000001, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig10"
    { MAXWELL_SM_PMTRIG11,  maxwell_sm_pmtrig11_enc_str_1, 0x00000001, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig11"
    { MAXWELL_SM_PMTRIG12,  maxwell_sm_pmtrig12_enc_str_1, 0x00000001, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig12"
    { MAXWELL_SM_PMTRIG13,  maxwell_sm_pmtrig13_enc_str_1, 0x00000001, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig13"
    { MAXWELL_SM_PMTRIG14,  maxwell_sm_pmtrig14_enc_str_1, 0x00000001, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig14"
    { MAXWELL_SM_PMTRIG15,  maxwell_sm_pmtrig15_enc_str_1, 0x00000001, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pmtrig15"
    { MAXWELL_SM_ACTIVE_WARPS_QUAD,  maxwell_sm_active_warps_quad_enc_str_1, 0x00000002, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL,  6}, //    "active_warps_quad"
    { MAXWELL_SM_ACTIVE_CYCLES_QUAD,  maxwell_sm_active_cycles_quad_enc_str_1, 0x00000002, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, // "active_cycles"
    { MAXWELL_SM_WARPS_LAUNCHED,  maxwell_sm_warps_launched_enc_str_1, 0x00000002, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "warps_launched"
    { MAXWELL_SM_INST_ISSUED0,  maxwell_sm_inst_issued0_enc_str_1, 0x00000003, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_issued0"
    { MAXWELL_SM_INST_ISSUED1,  maxwell_sm_inst_issued1_enc_str_1, 0x00000003, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_issued1"
    { MAXWELL_SM_INST_ISSUED2,  maxwell_sm_inst_issued2_enc_str_1, 0x00000003, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_issued2"
    { MAXWELL_SM_INST_EXECUTED,  maxwell_sm_inst_executed_enc_str_1, 0x00000003, 0x00000043, 0x00000003, PM_UNIT_SMQCTL,  2}, //    "inst_executed"
    { MAXWELL_SM_INST_ROLLBACKED,  maxwell_sm_inst_rollbacked_enc_str_1, 0x00000003, 0x00000765, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "inst_rollbacked"
    { MAXWELL_SM_THREAD_INST_EXECUTED,  maxwell_sm_thread_inst_executed_enc_str_1, 0x00000004, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL,  6}, //    "thread_inst_executed"
    { MAXWELL_SM_WARPS_MOVED_ON_DECK,  maxwell_sm_warps_moved_on_deck_enc_str_1, 0x00000004, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "warps_moved_on_deck"
    { MAXWELL_SM_WARPS_MOVED_OFF_DECK,  maxwell_sm_warps_moved_off_deck_enc_str_1, 0x00000004, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "warps_moved_off_deck"
    { MAXWELL_SM_NOT_PREDICATED_OFF_THREAD_INST_EXECUTED,  maxwell_sm_not_predicated_off_thread_inst_executed_enc_str_1, 0x00000005, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL,  6}, //    "not_predicated_off_thread_inst_executed"
    { MAXWELL_SM_TRAP_IN_TRAP_QUAD,  maxwell_sm_trap_in_trap_quad_enc_str_1, 0x00000005, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "trap_in_trap"
    { MAXWELL_SM_NON_IDLE_QUAD,  maxwell_sm_non_idle_quad_enc_str_1, 0x00000005, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "non_idle"
    { MAXWELL_SM_WARP_CANT_ISSUE_DRAIN,  maxwell_sm_warp_cant_issue_drain_enc_str_1, 0x00000006, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL,  6}, //    "warp_cant_issue_drain"
    { MAXWELL_SM_LOCAL_STORE,  maxwell_sm_local_store_enc_str_1, 0x00000006, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_local_st"
    { MAXWELL_SM_LOCAL_LOAD,  maxwell_sm_local_load_enc_str_1, 0x00000006, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_local_ld"
    { MAXWELL_SM_WARP_CANT_ISSUE_ICACHE_MISS,  maxwell_sm_warp_cant_issue_icache_miss_enc_str_1, 0x00000007, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL,  6}, //    "warp_cant_issue_icache_miss"
    { MAXWELL_SM_SHARED_LOAD,  maxwell_sm_shared_load_enc_str_1, 0x00000007, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_shared_ld"
    { MAXWELL_SM_SHARED_STORE,  maxwell_sm_shared_store_enc_str_1, 0x00000007, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_shared_st"
    { MAXWELL_SM_WARP_CANT_ISSUE_IMC_MISS,  maxwell_sm_warp_cant_issue_imc_miss_enc_str_1, 0x00000008, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL,  6}, //    "warp_cant_issue_imc_miss"
    { MAXWELL_SM_SHARED_ATOM_CAS,  maxwell_sm_shared_atom_cas_enc_str_1, 0x00000008, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_shared_atom_cas"
    { MAXWELL_SM_SHARED_ATOM,  maxwell_sm_shared_atom_enc_str_1, 0x00000008, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_shared_atom"
    { MAXWELL_SM_WARP_CANT_ISSUE_LONG_SCOREBOARD,  maxwell_sm_warp_cant_issue_long_scoreboard_enc_str_1, 0x00000009, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL,  6}, //    "warp_cant_issue_long_scoreboard"
    { MAXWELL_SM_ATTRIBUTE_STORE,  maxwell_sm_attribute_store_enc_str_1, 0x00000009, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_attribute_st"
    { MAXWELL_SM_ATTRIBUTE_LOAD,  maxwell_sm_attribute_load_enc_str_1, 0x00000009, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_attribute_ld"
    { MAXWELL_SM_WARP_CANT_ISSUE_BARRIER,  maxwell_sm_warp_cant_issue_barrier_enc_str_1, 0x0000000a, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL,  6}, //    "warp_cant_issue_barrier"
    { MAXWELL_SM_GLOBAL_ATOM_CAS,  maxwell_sm_global_atom_cas_enc_str_1, 0x0000000a, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_global_atom_cas"
    { MAXWELL_SM_GLOBAL_ATOM,  maxwell_sm_global_atom_enc_str_1, 0x0000000a, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_global_atom"
    { MAXWELL_SM_WARP_CANT_ISSUE_OFF_DECK_SHORT_SCOREBOARD,  maxwell_sm_warp_cant_issue_off_deck_short_scoreboard_enc_str_1, 0x0000000b, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL,  6}, //    "warp_cant_issue_off_deck_short_scoreboard"
    { MAXWELL_SM_GLOBAL_LOAD,  maxwell_sm_global_load_enc_str_1, 0x0000000b, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_global_ld"
    { MAXWELL_SM_GLOBAL_STORE,  maxwell_sm_global_store_enc_str_1, 0x0000000b, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_global_st"
    { MAXWELL_SM_WARP_CANT_ISSUE_TILE_ALLOCATION_STALL,  maxwell_sm_warp_cant_issue_tile_allocation_stall_enc_str_1, 0x0000000c, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL,  6}, //    "warp_cant_issue_tile_allocation_stall"
    { MAXWELL_SM_GENERIC_LOAD,  maxwell_sm_generic_load_enc_str_1, 0x0000000c, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_generic_ld"
    { MAXWELL_SM_GENERIC_STORE,  maxwell_sm_generic_store_enc_str_1, 0x0000000c, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_generic_st"
    { MAXWELL_SM_WARP_CANT_ISSUE_ALLOCATION_STALL_NO_SPACE,  maxwell_sm_warp_cant_issue_allocation_stall_no_space_enc_str_1, 0x0000000d, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL,  6}, //    "warp_cant_issue_allocation_stall_no_space"
    { MAXWELL_SM_SURFACE_ATOM,  maxwell_sm_surface_atom_enc_str_1, 0x0000000d, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_surface_atom"
    { MAXWELL_SM_SURFACE_ATOM_CAS,  maxwell_sm_surface_atom_cas_enc_str_1, 0x0000000d, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_surface_atom_cas"
    { MAXWELL_SM_WARP_CANT_ISSUE_ALLOCATION_STALL_NOT_ELIGIBLE,  maxwell_sm_warp_cant_issue_allocation_stall_not_eligible_enc_str_1, 0x0000000e, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL,  6}, //    "warp_cant_issue_allocation_stall_not_eligible"
    { MAXWELL_SM_SURFACE_LOAD,  maxwell_sm_surface_load_enc_str_1, 0x0000000e, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_surface_ld"
    { MAXWELL_SM_SURFACE_STORE,  maxwell_sm_surface_store_enc_str_1, 0x0000000e, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_surface_st"
    { MAXWELL_SM_WARP_CANT_ISSUE_MISC,  maxwell_sm_warp_cant_issue_misc_enc_str_1, 0x0000000f, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL,  6}, //    "warp_cant_issue_misc"
    { MAXWELL_SM_GLOBAL_RED,  maxwell_sm_global_red_enc_str_1, 0x0000000f, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_global_red"
    { MAXWELL_SM_SURFACE_RED,  maxwell_sm_surface_red_enc_str_1, 0x0000000f, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_surface_red"
    { MAXWELL_SM_WARP_CANT_ISSUE_MEMBAR,  maxwell_sm_warp_cant_issue_membar_enc_str_1, 0x00000010, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL,  6}, //    "warp_cant_issue_membar"
    { MAXWELL_SM_INST_EXECUTED_ADU_PIPE,  maxwell_sm_inst_executed_adu_pipe_enc_str_1, 0x00000010, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_adu_pipe"
    { MAXWELL_SM_INST_EXECUTED_SU_PIPE,  maxwell_sm_inst_executed_su_pipe_enc_str_1, 0x00000010, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_su_pipe"
    { MAXWELL_SM_WARP_CANT_ISSUE_ON_DECK_SHORT_SCOREBOARD,  maxwell_sm_warp_cant_issue_on_deck_short_scoreboard_enc_str_1, 0x00000011, 0x00000210, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "warp_cant_issue_on_deck_short_scoreboard"
    { MAXWELL_SM_WARP_CANT_ISSUE_WAIT,  maxwell_sm_warp_cant_issue_wait_enc_str_1, 0x00000011, 0x00000543, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "warp_cant_issue_wait"
    { MAXWELL_SM_INST_EXECUTED_LDC_PIPE,  maxwell_sm_inst_executed_ldc_pipe_enc_str_1, 0x00000011, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_ldc_pipe"
    { MAXWELL_SM_INST_EXECUTED_LSU_PIPE,  maxwell_sm_inst_executed_lsu_pipe_enc_str_1, 0x00000011, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_lsu_pipe"
    { MAXWELL_SM_WARP_CANT_ISSUE_NO_INSTRUCTIONS,  maxwell_sm_warp_cant_issue_no_instructions_enc_str_1, 0x00000012, 0x00000210, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "warp_cant_issue_no_instructions"
    { MAXWELL_SM_WARP_CANT_ISSUE_SHADOW_PIPE_THROTTLE,  maxwell_sm_warp_cant_issue_shadow_pipe_throttle_enc_str_1, 0x00000012, 0x00000543, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "warp_cant_issue_shadow_pipe_throttle"
    { MAXWELL_SM_INST_EXECUTED_FMAI_PIPE,  maxwell_sm_inst_executed_fmai_pipe_enc_str_1, 0x00000012, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_fmai_pipe"
    { MAXWELL_SM_INST_EXECUTED_FXU_PIPE,  maxwell_sm_inst_executed_fxu_pipe_enc_str_1, 0x00000012, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_fxu_pipe"
    { MAXWELL_SM_WARP_CANT_ISSUE_TEX_THROTTLE,  maxwell_sm_warp_cant_issue_tex_throttle_enc_str_1, 0x00000013, 0x00000210, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "warp_cant_issue_tex_throttle"
    { MAXWELL_SM_WARP_CANT_ISSUE_MIO_THROTTLE,  maxwell_sm_warp_cant_issue_mio_throttle_enc_str_1, 0x00000013, 0x00000543, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "warp_cant_issue_mio_throttle"
    { MAXWELL_SM_INST_EXECUTED_FE_PIPE,  maxwell_sm_inst_executed_fe_pipe_enc_str_1, 0x00000013, 0x00000076, 0x00000003, PM_UNIT_SMQCTL,  2}, //    "inst_executed_fe_pipe"
    { MAXWELL_SM_WARP_CANT_ISSUE_DISPATCH_STALL,  maxwell_sm_warp_cant_issue_dispatch_stall_enc_str_1, 0x00000014, 0x00000210, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "warp_cant_issue_dispatch_stall"
    { MAXWELL_SM_WARP_CANT_ISSUE_NOT_SELECTED,  maxwell_sm_warp_cant_issue_not_selected_enc_str_1, 0x00000014, 0x00000543, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "warp_cant_issue_not_selected"
    { MAXWELL_SM_INST_EXECUTED_FMA64LITE_PIPE,  maxwell_sm_inst_executed_fma64lite_pipe_enc_str_1, 0x00000014, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_fma64lite_pipe"
    { MAXWELL_SM_INST_EXECUTED_FMA64PLUS_PIPE,  maxwell_sm_inst_executed_fma64plus_pipe_enc_str_1, 0x00000014, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_fma64plus_pipe"
    { MAXWELL_SM_WARP_CANT_ISSUE_ON_DECK_LONG_SCOREBOARD,  maxwell_sm_warp_cant_issue_on_deck_long_scoreboard_enc_str_1, 0x00000015, 0x00000210, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "warp_cant_issue_on_deck_short_scoreboard"
    { MAXWELL_SM_WARP_CANT_ISSUE_ON_DECK_MISC,  maxwell_sm_warp_cant_issue_on_deck_misc_enc_str_1, 0x00000015, 0x00000543, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "warp_cant_issue_on_deck_misc"
    { MAXWELL_SM_INST_EXECUTED_FMA64PLUSPLUS_PIPE,  maxwell_sm_inst_executed_fma64plusplus_pipe_enc_str_1, 0x00000015, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_fma64plusplus_pipe"
    { MAXWELL_SM_INST_EXECUTED_BAR_PIPE,  maxwell_sm_inst_executed_bar_pipe_enc_str_1, 0x00000015, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_bar_pipe"
    { MAXWELL_SM_WARP_CANT_ISSUE_SELECTED,  maxwell_sm_warp_cant_issue_selected_enc_str_1, 0x00000016, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "warp_cant_issue_selected"
    { MAXWELL_SM_WARP_ISSUE_ELIGIBLE,  maxwell_sm_warp_issue_eligible_enc_str_1, 0x00000016, 0x00000321, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "warp_issue_eligible"
    { MAXWELL_SM_WARPS_ON_DECK,  maxwell_sm_warps_on_deck_enc_str_1, 0x00000016, 0x00000654, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "warps_on_deck"
    { MAXWELL_SM_INST_EXECUTED_XU_PIPE,  maxwell_sm_inst_executed_xu_pipe_enc_str_1, 0x00000016, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_xu_pipe"
    { MAXWELL_SM_INST_EXECUTED_DECOUPLED_PRED_OFF,  maxwell_sm_inst_executed_decoupled_pred_off_enc_str_1, 0x00000017, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_decoupled_pred_off"
    { MAXWELL_SM_INST_EXECUTED_COUPLED_PRED_OFF,  maxwell_sm_inst_executed_coupled_pred_off_enc_str_1, 0x00000017, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_coupled_pred_off"
    { MAXWELL_SM_INST_EXECUTED_32B,  maxwell_sm_inst_executed_32b_enc_str_1, 0x00000017, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_32b"
    { MAXWELL_SM_INST_EXECUTED_64B,  maxwell_sm_inst_executed_64b_enc_str_1, 0x00000017, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_64b"
    { MAXWELL_SM_INST_EXECUTED_128B,  maxwell_sm_inst_executed_128b_enc_str_1, 0x00000017, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_128b"
    { MAXWELL_SM_INST_EXECUTED_U128B,  maxwell_sm_inst_executed_u128b_enc_str_1, 0x00000017, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_U128b"
    { MAXWELL_SM_GENERIC_SHARED,  maxwell_sm_generic_shared_enc_str_1, 0x00000017, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_lsu_generic_shared"
    { MAXWELL_SM_GENERIC_TEX,  maxwell_sm_generic_tex_enc_str_1, 0x00000017, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_lsu_generic_tex"
    { MAXWELL_SM_ROLLBACKS_IMC,  maxwell_sm_rollbacks_imc_enc_str_1, 0x00000018, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "rollbacks_imc"
    { MAXWELL_SM_TEX_WB_REQUESTS_PENDING,  maxwell_sm_tex_wb_requests_pending_enc_str_1, 0x00000018, 0x00654321, 0x0000003f, PM_UNIT_SMQCTL,  6}, //    "tex_wb_requests_pending"
    { MAXWELL_SM_TEX_WB_REQUESTS,  maxwell_sm_tex_wb_requests_enc_str_1, 0x00000018, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "tex_wb_requests"
    { MAXWELL_SM_IMC_HIT,  maxwell_sm_imc_hit_enc_str_1, 0x00000019, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "imc_hit"
    { MAXWELL_SM_IMC_FULL_TAG,  maxwell_sm_imc_full_tag_enc_str_1, 0x00000019, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "imc_full_tag"
    { MAXWELL_SM_IMC_TRUE_MISS,  maxwell_sm_imc_true_miss_enc_str_1, 0x00000019, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "imc_true_miss"
    { MAXWELL_SM_IMC_COVERED_MISS,  maxwell_sm_imc_covered_miss_enc_str_1, 0x00000019, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "imc_covered_miss"
    { MAXWELL_SM_IMC_MISSES_OUTSTANDING,  maxwell_sm_imc_misses_outstanding_enc_str_1, 0x00000019, 0x00000654, 0x00000007, PM_UNIT_SMQCTL,  3}, //    "imc_misses_outstanding"
    { MAXWELL_SM_FET_FETCHED_LINES,  maxwell_sm_fet_fetched_lines_enc_str_1, 0x00000019, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "fet_fetched_lines"
    { MAXWELL_SM_UNWINDING_BR_EXECUTED,  maxwell_sm_unwinding_br_executed_enc_str_1, 0x0000001a, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "unwinding_br_executed"
    { MAXWELL_SM_DIVERGED_BR_EXECUTED,  maxwell_sm_diverged_br_executed_enc_str_1, 0x0000001a, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "diverged_br_executed"
    { MAXWELL_SM_UNIQUE_IDX_BR_EXECUTED,  maxwell_sm_unique_idx_br_executed_enc_str_1, 0x0000001a, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "unique_idx_br_executed"
    { MAXWELL_SM_RVAL_DIV_IDX_BR_EXECUTED,  maxwell_sm_rval_div_idx_br_executed_enc_str_1, 0x0000001a, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "rval_div_idx_br_executed"
    { MAXWELL_SM_BRANCH,  maxwell_sm_branch_enc_str_1, 0x0000001a, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "br_executed"
    { MAXWELL_SM_TAKEN_BR_EXECUTED,  maxwell_sm_taken_br_executed_enc_str_1, 0x0000001a, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "taken_br_executed"
    { MAXWELL_SM_PRED_DIV_IDX_BR_EXECUTED,  maxwell_sm_pred_div_idx_br_executed_enc_str_1, 0x0000001a, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "pred_div_idx_br_executed"
    { MAXWELL_SM_INST_EXECUTED_BRU_PIPE,  maxwell_sm_inst_executed_bru_pipe_enc_str_1, 0x0000001a, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_bru_pipe"
    { MAXWELL_SM_CRS_FILL,  maxwell_sm_crs_fill_enc_str_1, 0x0000001b, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "crs_fill"
    { MAXWELL_SM_CRS_SPILL,  maxwell_sm_crs_spill_enc_str_1, 0x0000001b, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "crs_spill"
    { MAXWELL_SM_CRS_PUSH_ACTION,  maxwell_sm_crs_push_action_enc_str_1, 0x0000001b, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "crs_push_action"
    { MAXWELL_SM_TEX_REQUESTS,  maxwell_sm_tex_requests_enc_str_1, 0x0000001b, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "tex_requests"
    { MAXWELL_SM_TEX_REQ_ACTIVE,  maxwell_sm_tex_req_active_enc_str_1, 0x0000001b, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "tex_req_active"
    { MAXWELL_SM_TEX_REQ_STALLED,  maxwell_sm_tex_req_stalled_enc_str_1, 0x0000001b, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "tex_req_stalled"
    { MAXWELL_SM_TEX_REQ_STARVED,  maxwell_sm_tex_req_starved_enc_str_1, 0x0000001b, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "tex_req_starved"
    { MAXWELL_SM_TEX_REQ_IDLE,  maxwell_sm_tex_req_idle_enc_str_1, 0x0000001b, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "tex_req_idle"
    { MAXWELL_SM_LSU_WB_OPS_PENDING,  maxwell_sm_lsu_wb_ops_pending_enc_str_1, 0x0000001c, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL,  6}, //    "lsu_wb_ops_pending"
    { MAXWELL_SM_INST_EXECUTED_LSU_WB_OPS,  maxwell_sm_inst_executed_lsu_wb_ops_enc_str_1, 0x0000001c, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_lsu_wb_ops"
    { MAXWELL_SM_INST_EXECUTED_VOTE_VTG,  maxwell_sm_inst_executed_vote_vtg_enc_str_1, 0x0000001c, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_vote_vtg"
    { MAXWELL_SM_TEX_INST_PENDING,  maxwell_sm_tex_inst_pending_enc_str_1, 0x0000001d, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL,  6}, //    "tex_inst_pending"
    { MAXWELL_SM_TEX_WB_INST_EXECUTED,  maxwell_sm_tex_wb_inst_executed_enc_str_1, 0x0000001d, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "tex_wb_inst_executed"
    { MAXWELL_SM_INST_EXECUTED_TEX_PIPE,  maxwell_sm_inst_executed_tex_pipe_enc_str_1, 0x0000001d, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, //    "inst_executed_tex_pipe"

//CORE/MIO Signals:

    { MAXWELL_SM_NON_IDLE,  maxwell_sm_non_idle_enc_str_1, 0x00000000, 0x00000000, 0x00000001, PM_UNIT_SMCORE,  1}, //    "non_idle"
    { MAXWELL_SM_ACTIVE_CYCLES,  maxwell_sm_active_cycles_enc_str_1, 0x00000000, 0x00000001, 0x00000001, PM_UNIT_SMCORE,  1}, //    "active_cycles"
    { MAXWELL_SM_ACTIVE_WARPS,  maxwell_sm_active_warps_enc_str_1, 0x00000000, 0x00765432, 0x0000003f, PM_UNIT_SMCORE,  6}, //    "active_warps"
    { MAXWELL_SM_ACTIVE_CTAS,  maxwell_sm_active_ctas_enc_str_1, 0x00000001, 0x00543210, 0x0000003f, PM_UNIT_SMCORE,  6}, //    "active_ctas"
    { MAXWELL_SM_CTA_LAUNCHED,  maxwell_sm_cta_launched_enc_str_1, 0x00000001, 0x00000006, 0x00000001, PM_UNIT_SMCORE,  1}, //    "ctas_launched"
    { MAXWELL_SM_LSU_BUSY,  maxwell_sm_lsu_busy_enc_str_1, 0x00000001, 0x00000007, 0x00000001, PM_UNIT_SMCORE,  1}, //    "lsu_busy"
    { MAXWELL_SM_ACTIVE_WARPS_PS,  maxwell_sm_active_warps_ps_enc_str_1, 0x00000002, 0x00543210, 0x0000003f, PM_UNIT_SMCORE,  6}, //    "active_warps_ps"
    { MAXWELL_SM_ACTIVE_WARPS_VTG,  maxwell_sm_active_warps_vtg_enc_str_1, 0x00000003, 0x00543210, 0x0000003f, PM_UNIT_SMCORE,  6}, //    "active_warps_vtg"
    { MAXWELL_SM_ACTIVE_SUBTILES,  maxwell_sm_active_subtiles_enc_str_1, 0x00000004, 0x00543210, 0x0000003f, PM_UNIT_SMCORE,  6}, //    "active_subtiles"
    { MAXWELL_SM_SUBTILES_LAUNCHED_H0,  maxwell_sm_subtiles_launched_h0_enc_str_1, 0x00000004, 0x00000006, 0x00000001, PM_UNIT_SMCORE,  1}, //    "subtiles_launched_h0"
    { MAXWELL_SM_SUBTILES_LAUNCHED_H1,  maxwell_sm_subtiles_launched_h1_enc_str_1, 0x00000004, 0x00000007, 0x00000001, PM_UNIT_SMCORE,  1}, //    "subtiles_launched_h1"
    { MAXWELL_SM_TRAP_COALESCING,  maxwell_sm_trap_coalescing_enc_str_1, 0x00000005, 0x00000000, 0x00000001, PM_UNIT_SMCORE,  1}, //    "trap_coalescing"
    { MAXWELL_SM_TRAP_COUNT,  maxwell_sm_trap_count_enc_str_1, 0x00000005, 0x00000001, 0x00000001, PM_UNIT_SMCORE,  1}, //    "trap_count"
    { MAXWELL_SM_TRAP_IDLING_FOR_TRAP,  maxwell_sm_trap_idling_for_trap_enc_str_1, 0x00000005, 0x00000002, 0x00000001, PM_UNIT_SMCORE,  1}, //    "trap_idling_for_trap"
    { MAXWELL_SM_TRAP_IN_TRAP,  maxwell_sm_trap_in_trap_enc_str_1, 0x00000005, 0x00000003, 0x00000001, PM_UNIT_SMCORE,  1}, //    "trap_in_trap"
    { MAXWELL_SM_TRAP_CLEARING_IDE,  maxwell_sm_trap_clearing_ide_enc_str_1, 0x00000005, 0x00000004, 0x00000001, PM_UNIT_SMCORE,  1}, //    "trap_in_trap"
    { MAXWELL_SM_TRAP_WAITING_FOR_IDE,  maxwell_sm_trap_waiting_for_ide_enc_str_1, 0x00000005, 0x00000005, 0x00000001, PM_UNIT_SMCORE,  1}, //    "trap_waiting_for_ide"
    { MAXWELL_SM_ICC_HIT,  maxwell_sm_icc_hit_enc_str_1, 0x00000006, 0x00000000, 0x00000001, PM_UNIT_SMCORE,  1}, //    "icc_hit"
    { MAXWELL_SM_ICC_TRUE_MISS,  maxwell_sm_icc_true_miss_enc_str_1, 0x00000006, 0x00000001, 0x00000001, PM_UNIT_SMCORE,  1}, //    "icc_true_miss"
    { MAXWELL_SM_ICC_COVERED_MISS,  maxwell_sm_icc_covered_miss_enc_str_1, 0x00000006, 0x00000002, 0x00000001, PM_UNIT_SMCORE,  1}, //    "icc_covered_miss"
    { MAXWELL_SM_ICC_FULL_TAG,  maxwell_sm_icc_full_tag_enc_str_1, 0x00000006, 0x00000003, 0x00000001, PM_UNIT_SMCORE,  1}, //    "icc_full_tag"
    { MAXWELL_SM_ICC_PREFETCHES,  maxwell_sm_icc_prefetches_enc_str_1, 0x00000006, 0x00000004, 0x00000001, PM_UNIT_SMCORE,  1}, //    "icc_prefetches"
    { MAXWELL_SM_ICC_UNLOCK_ALL,  maxwell_sm_icc_unlock_all_enc_str_1, 0x00000006, 0x00000005, 0x00000001, PM_UNIT_SMCORE,  1}, //    "icc_unlock_all"
    { MAXWELL_SM_ICC_MISSES_OUTSTANDING,  maxwell_sm_icc_misses_outstanding_enc_str_1, 0x00000007, 0x00000210, 0x00000007, PM_UNIT_SMCORE,  3}, //    "icc_misses_outstanding"
    { MAXWELL_SM_SHARED_LD_BANK_CONFLICT,  maxwell_sm_shared_ld_bank_conflict_enc_str_1, 0x0000000e, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "shm_ld_bank_conflict"
    { MAXWELL_SM_SHARED_ST_BANK_CONFLICT,  maxwell_sm_shared_st_bank_conflict_enc_str_1, 0x0000000e, 0x00000001, 0x00000001, PM_UNIT_MIO,  1}, //    "shm_st_bank_conflict"
    { MAXWELL_SM_SHARED_LOAD_TRANSACTIONS,  maxwell_sm_shared_load_transactions_enc_str_1, 0x0000000e, 0x00000002, 0x00000001, PM_UNIT_MIO,  1}, //    "shm_ld_count"
    { MAXWELL_SM_SHARED_STORE_TRANSACTIONS,  maxwell_sm_shared_store_transactions_enc_str_1, 0x0000000e, 0x00000003, 0x00000001, PM_UNIT_MIO,  1}, //    "shm_st_count"
    { MAXWELL_SM_PQ_WRITE_H0,  maxwell_sm_pq_write_h0_enc_str_1, 0x0000000e, 0x00000004, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_write_h0"
    { MAXWELL_SM_PQ_WRITE_H1,  maxwell_sm_pq_write_h1_enc_str_1, 0x0000000e, 0x00000005, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_write_h1"
    { MAXWELL_SM_ADU_REPLAY_H0,  maxwell_sm_adu_replay_h0_enc_str_1, 0x0000000e, 0x00000006, 0x00000001, PM_UNIT_MIO,  1}, //    "adu_replay_h0"
    { MAXWELL_SM_ADU_REPLAY_H1,  maxwell_sm_adu_replay_h1_enc_str_1, 0x0000000e, 0x00000007, 0x00000001, PM_UNIT_MIO,  1}, //    "adu_replay_h1"
    { MAXWELL_SM_PQ_READS_FOR_SHM_H0,  maxwell_sm_pq_reads_for_shm_h0_enc_str_1, 0x0000000f, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_reads_for_shm_h0"
    { MAXWELL_SM_PQ_READS_FOR_PIXOUT_H0,  maxwell_sm_pq_reads_for_pixout_h0_enc_str_1, 0x0000000f, 0x00000001, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_reads_for_pixout_h0"
    { MAXWELL_SM_PQ_READS_FOR_TEX_H0,  maxwell_sm_pq_reads_for_tex_h0_enc_str_1, 0x0000000f, 0x00000002, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_reads_for_tex_h0"
    { MAXWELL_SM_PQ_READS_FOR_SHM_STOLEN_H0,  maxwell_sm_pq_reads_for_shm_stolen_h0_enc_str_1, 0x0000000f, 0x00000003, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_reads_for_shm_stolen_h0"
    { MAXWELL_SM_PQ_READS_FOR_SHM_H1,  maxwell_sm_pq_reads_for_shm_h1_enc_str_1, 0x0000000f, 0x00000004, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_reads_for_shm_h1"
    { MAXWELL_SM_PQ_READS_FOR_PIXOUT_H1,  maxwell_sm_pq_reads_for_pixout_h1_enc_str_1, 0x0000000f, 0x00000005, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_reads_for_pixout_h1"
    { MAXWELL_SM_PQ_READS_FOR_TEX_H1,  maxwell_sm_pq_reads_for_tex_h1_enc_str_1, 0x0000000f, 0x00000006, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_reads_for_tex_h1"
    { MAXWELL_SM_PQ_READS_FOR_SHM_STOLEN_H1,  maxwell_sm_pq_reads_for_shm_stolen_h1_enc_str_1, 0x0000000f, 0x00000007, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_reads_for_shm_stolen_h1"
    { MAXWELL_SM_IDC_HIT,  maxwell_sm_idc_hit_enc_str_1, 0x00000010, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "idc_hit"
    { MAXWELL_SM_IDC_FULL_TAG,  maxwell_sm_idc_full_tag_enc_str_1, 0x00000010, 0x00000001, 0x00000001, PM_UNIT_MIO,  1}, //    "idc_full_tag"
    { MAXWELL_SM_IDC_TRUE_MISS,  maxwell_sm_idc_true_miss_enc_str_1, 0x00000010, 0x00000002, 0x00000001, PM_UNIT_MIO,  1}, //    "idc_true_miss"
    { MAXWELL_SM_IDC_COVERED_MISS,  maxwell_sm_idc_covered_miss_enc_str_1, 0x00000010, 0x00000003, 0x00000001, PM_UNIT_MIO,  1}, //    "idc_covered_miss"
    { MAXWELL_SM_IDC_DIVERGENCE_REPLAY_H0,  maxwell_sm_idc_divergence_replay_h0_enc_str_1, 0x00000010, 0x00000004, 0x00000001, PM_UNIT_MIO,  1}, //    "idc_divergence_replay_h0"
    { MAXWELL_SM_IDC_DIVERGENT_INSTRUCTION_H0,  maxwell_sm_idc_divergent_instruction_h0_enc_str_1, 0x00000010, 0x00000005, 0x00000001, PM_UNIT_MIO,  1}, //    "idc_divergent_instruction_h0"
    { MAXWELL_SM_IDC_DIVERGENCE_REPLAY_H1,  maxwell_sm_idc_divergence_replay_h1_enc_str_1, 0x00000010, 0x00000006, 0x00000001, PM_UNIT_MIO,  1}, //    "idc_divergence_replay_h1"
    { MAXWELL_SM_IDC_DIVERGENT_INSTRUCTION_H1,  maxwell_sm_idc_divergent_instruction_h1_enc_str_1, 0x00000010, 0x00000007, 0x00000001, PM_UNIT_MIO,  1}, //    "idc_divergent_instruction_h1"
    { MAXWELL_SM_MEMBAR_EXECUTED,  maxwell_sm_membar_executed_enc_str_1, 0x00000011, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "membar_executed"
    { MAXWELL_SM_MEMBAR_PENDING,  maxwell_sm_membar_pending_enc_str_1, 0x00000011, 0x00000001, 0x00000001, PM_UNIT_MIO,  1}, //    "membar_pending"
    { MAXWELL_SM_MEMBAR_SENT_TO_TEX,  maxwell_sm_membar_sent_to_tex_enc_str_1, 0x00000011, 0x00000002, 0x00000001, PM_UNIT_MIO,  1}, //    "membar_sent_to_tex"
    { MAXWELL_SM_MEMBAR_CTA_SENT_TO_TEX_H0,  maxwell_sm_membar_cta_sent_to_tex_h0_enc_str_1, 0x00000011, 0x00000003, 0x00000001, PM_UNIT_MIO,  1}, //    "membar_cta_sent_to_tex_h0"
    { MAXWELL_SM_MEMBAR_CTA_SENT_TO_TEX_H1,  maxwell_sm_membar_cta_sent_to_tex_h1_enc_str_1, 0x00000011, 0x00000004, 0x00000001, PM_UNIT_MIO,  1}, //    "membar_cta_sent_to_tex_h1"
    { MAXWELL_SM_MEMBAR_CTA_SYNTHETIC,  maxwell_sm_membar_cta_synthetic_enc_str_1, 0x00000011, 0x00000005, 0x00000001, PM_UNIT_MIO,  1}, //    "membar_cta_synthetic"
    { MAXWELL_SM_PIXOUT_QUADS_DRAINED,  maxwell_sm_pixout_quads_drained_enc_str_1, 0x00000012, 0x00000010, 0x00000003, PM_UNIT_MIO,  2}, //    "pixout_quads_drained"
    { MAXWELL_SM_HALF_WARPS_KILLED_BY_SHADER,  maxwell_sm_half_warps_killed_by_shader_enc_str_1, 0x00000012, 0x00000032, 0x00000003, PM_UNIT_MIO,  2}, //    "half_warps_killed_by_shader"
    { MAXWELL_SM_QUADS_KILLED_BY_SHADER,  maxwell_sm_quads_killed_by_shader_enc_str_1, 0x00000012, 0x00007654, 0x0000000f, PM_UNIT_MIO,  4}, //    "quads_killed_by_shader"
    { MAXWELL_SM_WARPS_KILLED_BY_SHADER,  maxwell_sm_warps_killed_by_shader_enc_str_1, 0x00000013, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "warps_killed_by_shader"
    { MAXWELL_SM_PIXELS_KILLED_SHADERCOVG,  maxwell_sm_pixels_killed_shadercovg_enc_str_1, 0x00000013, 0x00654321, 0x0000003f, PM_UNIT_MIO,  6}, //    "pixels_killed_shadercovg"
    { MAXWELL_SM_SM2GPM_OUTPUT_STALL,  maxwell_sm_sm2gpm_output_stall_enc_str_1, 0x00000013, 0x00000007, 0x00000001, PM_UNIT_MIO,  1}, //    "sm2gpm_output_stall"
    { MAXWELL_SM_MIO_ISBE_WRITE,  maxwell_sm_mio_isbe_write_enc_str_1, 0x00000014, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "mio_isbe_write"
    { MAXWELL_SM_MIO_ISBE_READ,  maxwell_sm_mio_isbe_read_enc_str_1, 0x00000014, 0x00000001, 0x00000001, PM_UNIT_MIO,  1}, //    "mio_isbe_read"
    { MAXWELL_SM_MIO_SM_STALLED_DUE_TO_PE_H0,  maxwell_sm_mio_sm_stalled_due_to_pe_h0_enc_str_1, 0x00000014, 0x00000002, 0x00000001, PM_UNIT_MIO,  1}, //    "mio_sm_stalled_due_to_pe_h0"
    { MAXWELL_SM_MIO_SM_STALLED_DUE_TO_PE_H1,  maxwell_sm_mio_sm_stalled_due_to_pe_h1_enc_str_1, 0x00000014, 0x00000003, 0x00000001, PM_UNIT_MIO,  1}, //    "mio_sm_stalled_due_to_pe_h1"
    { MAXWELL_SM_PE2MIO_ISBE_READ_REQ,  maxwell_sm_pe2mio_isbe_read_req_enc_str_1, 0x00000015, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "pe2mio_isbe_read_req"
    { MAXWELL_SM_PE2MIO_ISBE_WRITE_REQ,  maxwell_sm_pe2mio_isbe_write_req_enc_str_1, 0x00000015, 0x00000001, 0x00000001, PM_UNIT_MIO,  1}, //    "pe2mio_isbe_write_req"
    { MAXWELL_SM_PE2MIO_TRAM_WRITE,  maxwell_sm_pe2mio_tram_write_enc_str_1, 0x00000015, 0x00000002, 0x00000001, PM_UNIT_MIO,  1}, //    "pe2mio_tram_write"
    { MAXWELL_SM_PE_ISBE_WR_DELAYED_DUE_TO_CAMPING,  maxwell_sm_pe_isbe_wr_delayed_due_to_camping_enc_str_1, 0x00000015, 0x00000003, 0x00000001, PM_UNIT_MIO,  1}, //    "pe_isbe_wr_delayed_due_to_camping"
    { MAXWELL_SM_PE_TRAM_WR_DELAYED_AND_LOST_THROUGHPUT,  maxwell_sm_pe_tram_wr_delayed_and_lost_throughput_enc_str_1, 0x00000015, 0x00000004, 0x00000001, PM_UNIT_MIO,  1}, //    "pe_tram_wr_delayed_and_lost_throughput"
    { MAXWELL_SM_PE_TRAM_WR_DELAYED_DUE_TO_CAMPING,  maxwell_sm_pe_tram_wr_delayed_due_to_camping_enc_str_1, 0x00000015, 0x00000005, 0x00000001, PM_UNIT_MIO,  1}, //    "pe_tram_wr_delayed_due_to_camping"
    { MAXWELL_SM_SMM2TEX_DATA_LG_COUNT_H0,  maxwell_sm_smm2tex_data_lg_count_h0_enc_str_1, 0x00000016, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "smm2tex_data_lg_count_h0"
    { MAXWELL_SM_SMM2TEX_DATA_TEX_COUNT_H0,  maxwell_sm_smm2tex_data_tex_count_h0_enc_str_1, 0x00000016, 0x00000001, 0x00000001, PM_UNIT_MIO,  1}, //    "smm2tex_data_tex_count_h0"
    { MAXWELL_SM_SMM2TEX_DATA_LG_COUNT_H1,  maxwell_sm_smm2tex_data_lg_count_h1_enc_str_1, 0x00000016, 0x00000002, 0x00000001, PM_UNIT_MIO,  1}, //    "smm2tex_data_lg_count_h1"
    { MAXWELL_SM_SMM2TEX_DATA_TEX_COUNT_H1,  maxwell_sm_smm2tex_data_tex_count_h1_enc_str_1, 0x00000016, 0x00000003, 0x00000001, PM_UNIT_MIO,  1}, //    "smm2tex_data_tex_count_h1"
    { MAXWELL_SM_MIO_CANT_DISPATCH_LSU_ADU_OVER_SHM_H0,  maxwell_sm_mio_cant_dispatch_lsu_adu_over_shm_h0_enc_str_1, 0x00000017, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "mio_cant_dispatch_lsu_adu_over_shm_h0"
    { MAXWELL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_ADU_H0,  maxwell_sm_mio_cant_dispatch_lsu_pixout_over_adu_h0_enc_str_1, 0x00000017, 0x00000001, 0x00000001, PM_UNIT_MIO,  1}, //    "mio_cant_dispatch_lsu_pixout_over_adu_h0"
    { MAXWELL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_SHM_H0,  maxwell_sm_mio_cant_dispatch_lsu_pixout_over_shm_h0_enc_str_1, 0x00000017, 0x00000002, 0x00000001, PM_UNIT_MIO,  1}, //    "mio_cant_dispatch_lsu_pixout_over_shm_h0"
    { MAXWELL_SM_MIO_CANT_DISPATCH_LSU_ADU_OVER_SHM_H1,  maxwell_sm_mio_cant_dispatch_lsu_adu_over_shm_h1_enc_str_1, 0x00000017, 0x00000003, 0x00000001, PM_UNIT_MIO,  1}, //    "mio_cant_dispatch_lsu_adu_over_shm_h1"
    { MAXWELL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_ADU_H1,  maxwell_sm_mio_cant_dispatch_lsu_pixout_over_adu_h1_enc_str_1, 0x00000017, 0x00000004, 0x00000001, PM_UNIT_MIO,  1}, //    "mio_cant_dispatch_lsu_pixout_over_adu_h1"
    { MAXWELL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_SHM_H1,  maxwell_sm_mio_cant_dispatch_lsu_pixout_over_shm_h1_enc_str_1, 0x00000017, 0x00000005, 0x00000001, PM_UNIT_MIO,  1}, //    "mio_cant_dispatch_lsu_pixout_over_shm_h1"
    { MAXWELL_SM_IDC_MISSES_OUTSTANDING,  maxwell_sm_idc_misses_outstanding_enc_str_1, 0x00000018, 0x00000210, 0x00000007, PM_UNIT_MIO,  3}, //    "idc_misses_outstanding"
    { MAXWELL_SM_PQ_FULL_H0,  maxwell_sm_pq_full_h0_enc_str_1, 0x00000019, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_full_h0"
    { MAXWELL_SM_PQ_FULL_H1,  maxwell_sm_pq_full_h1_enc_str_1, 0x00000019, 0x00000001, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_full_h1"
    { MAXWELL_SM_PIX_PQ_FULL_H0,  maxwell_sm_pix_pq_full_h0_enc_str_1, 0x00000019, 0x00000002, 0x00000001, PM_UNIT_MIO,  1}, //    "pix_pq_full_h0"
    { MAXWELL_SM_PIX_PQ_FULL_H1,  maxwell_sm_pix_pq_full_h1_enc_str_1, 0x00000019, 0x00000003, 0x00000001, PM_UNIT_MIO,  1}, //    "pix_pq_full_h1"
    { MAXWELL_SM_SHM_PQ_FULL_H0,  maxwell_sm_shm_pq_full_h0_enc_str_1, 0x00000019, 0x00000004, 0x00000001, PM_UNIT_MIO,  1}, //    "shm_pq_full_h0"
    { MAXWELL_SM_SHM_PQ_FULL_H1,  maxwell_sm_shm_pq_full_h1_enc_str_1, 0x00000019, 0x00000005, 0x00000001, PM_UNIT_MIO,  1}, //    "shm_pq_full_h1"
    { MAXWELL_SM_TEX_PQ_FULL_H0,  maxwell_sm_tex_pq_full_h0_enc_str_1, 0x00000019, 0x00000006, 0x00000001, PM_UNIT_MIO,  1}, //    "tex_pq_full_h0"
    { MAXWELL_SM_TEX_PQ_FULL_H1,  maxwell_sm_tex_pq_full_h1_enc_str_1, 0x00000019, 0x00000007, 0x00000001, PM_UNIT_MIO,  1}, //    "tex_pq_full_h1"
    { MAXWELL_SM_PQ_WRITE_BACK_LSU_STALL_H0,  maxwell_sm_pq_write_back_lsu_stall_h0_enc_str_1, 0x0000001a, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_write_back_lsu_stall_h0"
    { MAXWELL_SM_PQ_WRITE_BACK_TEX_STALL_H0,  maxwell_sm_pq_write_back_tex_stall_h0_enc_str_1, 0x0000001a, 0x00000001, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_write_back_tex_stall_h0"
    { MAXWELL_SM_PQ_WRITE_BACK_LSU_STALL_H1,  maxwell_sm_pq_write_back_lsu_stall_h1_enc_str_1, 0x0000001a, 0x00000002, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_write_back_lsu_stall_h1"
    { MAXWELL_SM_PQ_WRITE_BACK_TEX_STALL_H1,  maxwell_sm_pq_write_back_tex_stall_h1_enc_str_1, 0x0000001a, 0x00000003, 0x00000001, PM_UNIT_MIO,  1}, //    "pq_write_back_tex_stall_h1"
    { MAXWELL_SM_LSU_IQ_FIFO_FULL_H0,  maxwell_sm_lsu_iq_fifo_full_h0_enc_str_1, 0x0000001b, 0x00000000, 0x00000001, PM_UNIT_MIO,  1}, //    "lsu_iq_fifo_full_h0"
    { MAXWELL_SM_TEX_IQ_FIFO_FULL_H0,  maxwell_sm_tex_iq_fifo_full_h0_enc_str_1, 0x0000001b, 0x00000001, 0x00000001, PM_UNIT_MIO,  1}, //    "tex_iq_fifo_full_h0"
    { MAXWELL_SM_PIX_IQ_FIFO_FULL_H0,  maxwell_sm_pix_iq_fifo_full_h0_enc_str_1, 0x0000001b, 0x00000002, 0x00000001, PM_UNIT_MIO,  1}, //    "pix_iq_fifo_full_h0"
    { MAXWELL_SM_RTY_IQ_FIFO_FULL_H0,  maxwell_sm_rty_iq_fifo_full_h0_enc_str_1, 0x0000001b, 0x00000003, 0x00000001, PM_UNIT_MIO,  1}, //    "rty_iq_fifo_full_h0"
    { MAXWELL_SM_LSU_IQ_FIFO_FULL_H1,  maxwell_sm_lsu_iq_fifo_full_h1_enc_str_1, 0x0000001b, 0x00000004, 0x00000001, PM_UNIT_MIO,  1}, //    "lsu_iq_fifo_full_h1"
    { MAXWELL_SM_TEX_IQ_FIFO_FULL_H1,  maxwell_sm_tex_iq_fifo_full_h1_enc_str_1, 0x0000001b, 0x00000005, 0x00000001, PM_UNIT_MIO,  1}, //    "tex_iq_fifo_full_h1"
    { MAXWELL_SM_PIX_IQ_FIFO_FULL_H1,  maxwell_sm_pix_iq_fifo_full_h1_enc_str_1, 0x0000001b, 0x00000006, 0x00000001, PM_UNIT_MIO,  1}, //    "pix_iq_fifo_full_h1"
    { MAXWELL_SM_RTY_IQ_FIFO_FULL_H1,  maxwell_sm_rty_iq_fifo_full_h1_enc_str_1, 0x0000001b, 0x00000007, 0x00000001, PM_UNIT_MIO,  1}, //    "rty_iq_fifo_full_h1"
    { INVALID_PM_SIGNAL_NEW,            "",                       0xffffffff, 0x00000000, 0x00000000,     PM_UNIT_MAX,0 }
};
#endif /* NVCFG(GLOBAL_GPU_FAMILY_GM20X) || NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)*/

#if NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
PerfSignalHwpm PerfSignalTableGM20Y_ltc0[] = {
    //LTC signals
    // l2_subp0_write_sector_misses = ltc_ltc2fb_dirty_dat0_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 0
    // l2_subp0_read_sector_misses  = ltc_fb2ltc_rdat0_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 0

    {MAXWELL_LTC0_WRITE_MISS_SECTORS, maxwell_ltc0_write_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x2c, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC1_WRITE_MISS_SECTORS, maxwell_ltc1_write_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x4c, PM_UNIT_LTS1_1, 1},
    {MAXWELL_LTC0_READ_MISS_SECTORS, maxwell_ltc0_read_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x2d, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC1_READ_MISS_SECTORS, maxwell_ltc1_read_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x2d, PM_UNIT_LTS1_1, 1},

    // l2_subp0_write_l1_sector_queries = ltc2pm_ltc_lts0_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 0
    // l2_subp0_read_l1_sector_queries  = ltc2pm_ltc_lts0_request_rd_op && ltc2pm_ltc_lts1_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 0

    {MAXWELL_LTC0_REQUEST_SRC_UNIT_L1, maxwell_ltc0_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x92, PM_UNIT_LTS2, 1},
    {MAXWELL_LTC1_REQUEST_SRC_UNIT_L1, maxwell_ltc1_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x93, PM_UNIT_LTS2_1, 1},
    {MAXWELL_LTC0_REQUEST_SRC_UNIT_TEX, maxwell_ltc0_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x92, PM_UNIT_LTS2, 1},
    {MAXWELL_LTC1_REQUEST_SRC_UNIT_TEX, maxwell_ltc1_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x93, PM_UNIT_LTS2_1, 1},
    {MAXWELL_LTC0_REQUEST_SRC_UNIT_GCC, maxwell_ltc0_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x92, PM_UNIT_LTS2, 1},
    {MAXWELL_LTC1_REQUEST_SRC_UNIT_GCC, maxwell_ltc1_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x93, PM_UNIT_LTS2_1, 1},

    {MAXWELL_LTC0_HIT_SECTORS, maxwell_ltc0_hit_sectors_enc_str_1, 0x1, 0xffff, 0x7c, PM_UNIT_LTS, 4},
    {MAXWELL_LTC1_HIT_SECTORS, maxwell_ltc1_hit_sectors_enc_str_1, 0x1, 0xffff, 0x8c, PM_UNIT_LTS_1, 4},
    {MAXWELL_LTC0_MISS_SECTORS, maxwell_ltc0_miss_sectors_enc_str_1, 0x2, 0xffff, 0x7c, PM_UNIT_LTS, 4},
    {MAXWELL_LTC1_MISS_SECTORS, maxwell_ltc1_miss_sectors_enc_str_1, 0x2, 0xffff, 0x8c, PM_UNIT_LTS_1, 4},

    {MAXWELL_LTC0_REQUEST_SECTORS, maxwell_ltc0_request_sectors_enc_str_1, 0x0, 0xffff, 0x7c, PM_UNIT_LTS, 4},
    {MAXWELL_LTC1_REQUEST_SECTORS, maxwell_ltc1_request_sectors_enc_str_1, 0x0, 0xffff, 0x8c, PM_UNIT_LTS_1, 4},

    {MAXWELL_LTC0_REQUEST_ACTIVE, maxwell_ltc0_request_active_enc_str_1, 0x0, 0xaaaa, 0x29, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC1_REQUEST_ACTIVE, maxwell_ltc1_request_active_enc_str_1, 0x0, 0xaaaa, 0x49, PM_UNIT_LTS1_1, 1},

    {MAXWELL_LTC0_REQUEST_RD_OP, maxwell_ltc0_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x3c, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC1_REQUEST_RD_OP, maxwell_ltc1_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x5c, PM_UNIT_LTS1_1, 1},

    {MAXWELL_LTC0_REQUEST_WR_OP, maxwell_ltc0_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x3b, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC1_REQUEST_WR_OP, maxwell_ltc1_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x5b, PM_UNIT_LTS1_1, 1},

    {MAXWELL_LTC0_REQUEST_ATOMIC_OP, maxwell_ltc0_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x3a, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC1_REQUEST_ATOMIC_OP, maxwell_ltc1_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x5a, PM_UNIT_LTS1_1, 1},

    {MAXWELL_LTC0_REQUEST_APERTURE_SYSMEM, maxwell_ltc0_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x36, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC1_REQUEST_APERTURE_SYSMEM, maxwell_ltc1_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x56, PM_UNIT_LTS1_1, 1},
    {MAXWELL_LTC0_REQUEST_APERTURE_VIDMEM, maxwell_ltc0_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x35, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC1_REQUEST_APERTURE_VIDMEM, maxwell_ltc1_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x55, PM_UNIT_LTS1_1, 1},

    {MAXWELL_LTC0_LTCX_MC_REQ_RD, maxwell_ltc0_ltcx_mc_req_rd_enc_str_1, 0x10, 0xaaaa, 0x2f, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC1_LTCX_MC_REQ_RD, maxwell_ltc1_ltcx_mc_req_rd_enc_str_1, 0x10, 0xaaaa, 0x4f, PM_UNIT_LTS1_1, 1},

    {MAXWELL_LTC0_LTCX_MC_REQ_RD_SIZE, maxwell_ltc0_ltcx_mc_req_rd_size_enc_str_1, 0x10, 0xaaaa, 0x30, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC1_LTCX_MC_REQ_RD_SIZE, maxwell_ltc1_ltcx_mc_req_rd_size_enc_str_1, 0x10, 0xaaaa, 0x50, PM_UNIT_LTS1_1, 1},

    {MAXWELL_LTC0_LTCX_MC_REQ_WR, maxwell_ltc0_ltcx_mc_req_wr_enc_str_1, 0x10, 0xaaaa, 0x33, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC1_LTCX_MC_REQ_WR, maxwell_ltc1_ltcx_mc_req_wr_enc_str_1, 0x10, 0xaaaa, 0x53, PM_UNIT_LTS1_1, 1},

    {MAXWELL_LTC0_LTCX_MC_REQ_WR_SIZE_0, maxwell_ltc0_ltcx_mc_req_wr_size_0_enc_str_1, 0x10, 0xaaaa, 0x34, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC1_LTCX_MC_REQ_WR_SIZE_0, maxwell_ltc1_ltcx_mc_req_wr_size_0_enc_str_1, 0x10, 0xaaaa, 0x54, PM_UNIT_LTS1_1, 1},

    {MAXWELL_LTC0_LTCX_MC_REQ_WR_SIZE_1, maxwell_ltc0_ltcx_mc_req_wr_size_1_enc_str_1, 0x10, 0xaaaa, 0x35, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC1_LTCX_MC_REQ_WR_SIZE_1, maxwell_ltc1_ltcx_mc_req_wr_size_1_enc_str_1, 0x10, 0xaaaa, 0x55, PM_UNIT_LTS1_1, 1},

    {MAXWELL_LTC0_LTCX_MC_REQ_WR_PARTIAL, maxwell_ltc0_ltcx_mc_req_wr_partial_enc_str_1, 0x10, 0xaaaa, 0x38, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC1_LTCX_MC_REQ_WR_PARTIAL, maxwell_ltc1_ltcx_mc_req_wr_partial_enc_str_1, 0x10, 0xaaaa, 0x58, PM_UNIT_LTS1_1, 1},

    {MAXWELL_LTC0_LTCX_REQ_RD, maxwell_ltc0_ltcx_req_rd_enc_str_1, 0x10, 0xaaaa, 0x28, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC1_LTCX_REQ_RD, maxwell_ltc1_ltcx_req_rd_enc_str_1, 0x10, 0xaaaa, 0x48, PM_UNIT_LTS1_1, 1},

    {MAXWELL_LTC0_LTCX_REQ_RD_SIZE_0, maxwell_ltc0_ltcx_req_rd_size_0_enc_str_1, 0x10, 0xaaaa, 0x29, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC1_LTCX_REQ_RD_SIZE_0, maxwell_ltc1_ltcx_req_rd_size_0_enc_str_1, 0x10, 0xaaaa, 0x49, PM_UNIT_LTS1_1, 1},

    {MAXWELL_LTC0_LTCX_REQ_RD_SIZE_1, maxwell_ltc0_ltcx_req_rd_size_1_enc_str_1, 0x10, 0xaaaa, 0x2a, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC1_LTCX_REQ_RD_SIZE_1, maxwell_ltc1_ltcx_req_rd_size_1_enc_str_1, 0x10, 0xaaaa, 0x4a, PM_UNIT_LTS1_1, 1},

    {MAXWELL_LTC0_LTCX_REQ_WR, maxwell_ltc0_ltcx_req_wr_enc_str_1, 0x10, 0xaaaa, 0x2b, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC1_LTCX_REQ_WR, maxwell_ltc1_ltcx_req_wr_enc_str_1, 0x10, 0xaaaa, 0x4b, PM_UNIT_LTS1_1, 1},

    {MAXWELL_LTC0_LTCX_REQ_WR_SIZE_0, maxwell_ltc0_ltcx_req_wr_size_0_enc_str_1, 0x10, 0xaaaa, 0x2c, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC1_LTCX_REQ_WR_SIZE_0, maxwell_ltc1_ltcx_req_wr_size_0_enc_str_1, 0x10, 0xaaaa, 0x4c, PM_UNIT_LTS1_1, 1},

    {MAXWELL_LTC0_LTCX_REQ_WR_SIZE_1, maxwell_ltc0_ltcx_req_wr_size_1_enc_str_1, 0x10, 0xaaaa, 0x2d, PM_UNIT_LTS1, 1},
    {MAXWELL_LTC1_LTCX_REQ_WR_SIZE_1, maxwell_ltc1_ltcx_req_wr_size_1_enc_str_1, 0x10, 0xaaaa, 0x4d, PM_UNIT_LTS1_1, 1},

    { INVALID_PM_SIGNAL_NEW,        "",                                 0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpmExpt PerfSignalTableGM20Y_ltc0_expt[] = {
    //write a combination of the signals.

    // ltc_read_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { MAXWELL_LTC0_READ_TEX_SECTORS_FBP, maxwell_ltc0_read_tex_sectors_fbp_enc_str_1, MAXWELL_LTC0_REQUEST_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_RD_OP, MAXWELL_LTC0_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_request_sectors_src_unit_tex_op_atomic_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_request_atomic_op
    { MAXWELL_LTC0_ATOMIC_TEX_SECTORS_FBP, maxwell_ltc0_atomic_tex_sectors_fbp_enc_str_1, MAXWELL_LTC0_REQUEST_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_ATOMIC_OP, MAXWELL_LTC0_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { MAXWELL_LTC0_WRITE_TEX_SECTORS_FBP, maxwell_ltc0_write_tex_sectors_fbp_enc_str_1, MAXWELL_LTC0_REQUEST_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_WR_OP, MAXWELL_LTC0_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_hit_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_hit
    { MAXWELL_LTC0_READ_TEX_HIT_SECTORS_FBP, maxwell_ltc0_read_tex_hit_sectors_fbp_enc_str_1,  MAXWELL_LTC0_HIT_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_RD_OP, MAXWELL_LTC0_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { MAXWELL_LTC0_WRITE_TEX_HIT_SECTORS_FBP, maxwell_ltc0_write_tex_hit_sectors_fbp_enc_str_1,  MAXWELL_LTC0_HIT_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_WR_OP, MAXWELL_LTC0_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { MAXWELL_LTC0_READ_SYSMEM_SECTORS_FBP, maxwell_ltc0_read_sysmem_sectors_fbp_enc_str_1, MAXWELL_LTC0_REQUEST_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_RD_OP, MAXWELL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { MAXWELL_LTC0_WRITE_SYSMEM_SECTORS_FBP, maxwell_ltc0_write_sysmem_sectors_fbp_enc_str_1, MAXWELL_LTC0_REQUEST_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_WR_OP, MAXWELL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { MAXWELL_LTC0_TOTAL_READ_SECTORS_FBP, maxwell_ltc0_total_read_sectors_fbp_enc_str_1, MAXWELL_LTC0_REQUEST_SECTORS, {MAXWELL_LTC0_REQUEST_ATOMIC_OP, MAXWELL_LTC0_REQUEST_RD_OP, MAXWELL_LTC0_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { MAXWELL_LTC0_TOTAL_WRITE_SECTORS_FBP, maxwell_ltc0_total_write_sectors_fbp_enc_str_1, MAXWELL_LTC0_REQUEST_SECTORS, {MAXWELL_LTC0_REQUEST_ATOMIC_OP, MAXWELL_LTC0_REQUEST_WR_OP, MAXWELL_LTC0_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { MAXWELL_LTC0_READ_VIDMEM_SECTORS_FBP,      maxwell_ltc0_read_vidmem_sectors_fbp_enc_str_1,    MAXWELL_LTC0_REQUEST_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_RD_OP, MAXWELL_LTC0_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { MAXWELL_LTC0_WRITE_VIDMEM_SECTORS_FBP,      maxwell_ltc0_write_vidmem_sectors_fbp_enc_str_1,    MAXWELL_LTC0_REQUEST_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_WR_OP, MAXWELL_LTC0_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { MAXWELL_LTC0_READ_SYSMEM_HIT_SECTORS_FBP, maxwell_ltc0_read_sysmem_hit_sectors_fbp_enc_str_1, MAXWELL_LTC0_HIT_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_RD_OP, MAXWELL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_LTC0_WRITE_SYSMEM_HIT_SECTORS_FBP, maxwell_ltc0_write_sysmem_hit_sectors_fbp_enc_str_1, MAXWELL_LTC0_HIT_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_WR_OP, MAXWELL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_LTC0_READ_SYSMEM_MISS_SECTORS_FBP, maxwell_ltc0_read_sysmem_miss_sectors_fbp_enc_str_1, MAXWELL_LTC0_MISS_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_RD_OP, MAXWELL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_LTC0_WRITE_SYSMEM_MISS_SECTORS_FBP, maxwell_ltc0_write_sysmem_miss_sectors_fbp_enc_str_1, MAXWELL_LTC0_MISS_SECTORS, {MAXWELL_LTC0_REQUEST_ACTIVE, MAXWELL_LTC0_REQUEST_WR_OP, MAXWELL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_LTC0_LTCX_MC_REQ_RD_SIZE_32B, maxwell_ltc0_ltcx_mc_req_rd_size_32b_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC0_LTCX_MC_REQ_RD, MAXWELL_LTC0_LTCX_MC_REQ_RD_SIZE, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE)), 0},
    { MAXWELL_LTC0_LTCX_MC_REQ_RD_SIZE_64B, maxwell_ltc0_ltcx_mc_req_rd_size_64b_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC0_LTCX_MC_REQ_RD, MAXWELL_LTC0_LTCX_MC_REQ_RD_SIZE, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { MAXWELL_LTC0_LTCX_MC_REQ_WR_SIZE_16B, maxwell_ltc0_ltcx_mc_req_wr_size_16b_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC0_LTCX_MC_REQ_WR, MAXWELL_LTC0_LTCX_MC_REQ_WR_SIZE_0, MAXWELL_LTC0_LTCX_MC_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { MAXWELL_LTC0_LTCX_MC_REQ_WR_SIZE_32B, maxwell_ltc0_ltcx_mc_req_wr_size_32b_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC0_LTCX_MC_REQ_WR, MAXWELL_LTC0_LTCX_MC_REQ_WR_SIZE_0, MAXWELL_LTC0_LTCX_MC_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { MAXWELL_LTC0_LTCX_MC_REQ_WR_SIZE_64B, maxwell_ltc0_ltcx_mc_req_wr_size_64b_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC0_LTCX_MC_REQ_WR, MAXWELL_LTC0_LTCX_MC_REQ_WR_SIZE_0, MAXWELL_LTC0_LTCX_MC_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { MAXWELL_LTC0_LTCX_REQ_RD_SECTOR_COUNT_1, maxwell_ltc0_ltcx_req_rd_sector_count_1_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC0_LTCX_REQ_RD, MAXWELL_LTC0_LTCX_REQ_RD_SIZE_0, MAXWELL_LTC0_LTCX_REQ_RD_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { MAXWELL_LTC0_LTCX_REQ_RD_SECTOR_COUNT_2, maxwell_ltc0_ltcx_req_rd_sector_count_2_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC0_LTCX_REQ_RD, MAXWELL_LTC0_LTCX_REQ_RD_SIZE_0, MAXWELL_LTC0_LTCX_REQ_RD_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { MAXWELL_LTC0_LTCX_REQ_RD_SECTOR_COUNT_3, maxwell_ltc0_ltcx_req_rd_sector_count_3_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC0_LTCX_REQ_RD, MAXWELL_LTC0_LTCX_REQ_RD_SIZE_0, MAXWELL_LTC0_LTCX_REQ_RD_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { MAXWELL_LTC0_LTCX_REQ_RD_SECTOR_COUNT_4, maxwell_ltc0_ltcx_req_rd_sector_count_4_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC0_LTCX_REQ_RD, MAXWELL_LTC0_LTCX_REQ_RD_SIZE_0, MAXWELL_LTC0_LTCX_REQ_RD_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { MAXWELL_LTC0_LTCX_REQ_WR_SECTOR_COUNT_1, maxwell_ltc0_ltcx_req_wr_sector_count_1_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC0_LTCX_REQ_WR, MAXWELL_LTC0_LTCX_REQ_WR_SIZE_0, MAXWELL_LTC0_LTCX_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { MAXWELL_LTC0_LTCX_REQ_WR_SECTOR_COUNT_2, maxwell_ltc0_ltcx_req_wr_sector_count_2_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC0_LTCX_REQ_WR, MAXWELL_LTC0_LTCX_REQ_WR_SIZE_0, MAXWELL_LTC0_LTCX_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { MAXWELL_LTC0_LTCX_REQ_WR_SECTOR_COUNT_3, maxwell_ltc0_ltcx_req_wr_sector_count_3_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC0_LTCX_REQ_WR, MAXWELL_LTC0_LTCX_REQ_WR_SIZE_0, MAXWELL_LTC0_LTCX_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { MAXWELL_LTC0_LTCX_REQ_WR_SECTOR_COUNT_4, maxwell_ltc0_ltcx_req_wr_sector_count_4_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC0_LTCX_REQ_WR, MAXWELL_LTC0_LTCX_REQ_WR_SIZE_0, MAXWELL_LTC0_LTCX_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { MAXWELL_LTC1_READ_TEX_SECTORS_FBP, maxwell_ltc1_read_tex_sectors_fbp_enc_str_1, MAXWELL_LTC1_REQUEST_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_RD_OP, MAXWELL_LTC1_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_request_sectors_src_unit_tex_op_atomic_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_request_atomic_op
    { MAXWELL_LTC1_ATOMIC_TEX_SECTORS_FBP, maxwell_ltc1_atomic_tex_sectors_fbp_enc_str_1, MAXWELL_LTC1_REQUEST_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_ATOMIC_OP, MAXWELL_LTC1_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { MAXWELL_LTC1_WRITE_TEX_SECTORS_FBP, maxwell_ltc1_write_tex_sectors_fbp_enc_str_1, MAXWELL_LTC1_REQUEST_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_WR_OP, MAXWELL_LTC1_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_hit_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_hit
    { MAXWELL_LTC1_READ_TEX_HIT_SECTORS_FBP, maxwell_ltc1_read_tex_hit_sectors_fbp_enc_str_1,  MAXWELL_LTC1_HIT_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_RD_OP, MAXWELL_LTC1_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { MAXWELL_LTC1_WRITE_TEX_HIT_SECTORS_FBP, maxwell_ltc1_write_tex_hit_sectors_fbp_enc_str_1,  MAXWELL_LTC1_HIT_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_WR_OP, MAXWELL_LTC1_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { MAXWELL_LTC1_READ_SYSMEM_SECTORS_FBP, maxwell_ltc1_read_sysmem_sectors_fbp_enc_str_1, MAXWELL_LTC1_REQUEST_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_RD_OP, MAXWELL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { MAXWELL_LTC1_WRITE_SYSMEM_SECTORS_FBP, maxwell_ltc1_write_sysmem_sectors_fbp_enc_str_1, MAXWELL_LTC1_REQUEST_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_WR_OP, MAXWELL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { MAXWELL_LTC1_TOTAL_READ_SECTORS_FBP, maxwell_ltc1_total_read_sectors_fbp_enc_str_1, MAXWELL_LTC1_REQUEST_SECTORS, {MAXWELL_LTC1_REQUEST_ATOMIC_OP, MAXWELL_LTC1_REQUEST_RD_OP, MAXWELL_LTC1_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { MAXWELL_LTC1_TOTAL_WRITE_SECTORS_FBP, maxwell_ltc1_total_write_sectors_fbp_enc_str_1, MAXWELL_LTC1_REQUEST_SECTORS, {MAXWELL_LTC1_REQUEST_ATOMIC_OP, MAXWELL_LTC1_REQUEST_WR_OP, MAXWELL_LTC1_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { MAXWELL_LTC1_READ_VIDMEM_SECTORS_FBP,      maxwell_ltc1_read_vidmem_sectors_fbp_enc_str_1,    MAXWELL_LTC1_REQUEST_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_RD_OP, MAXWELL_LTC1_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { MAXWELL_LTC1_WRITE_VIDMEM_SECTORS_FBP,      maxwell_ltc1_write_vidmem_sectors_fbp_enc_str_1,    MAXWELL_LTC1_REQUEST_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_WR_OP, MAXWELL_LTC1_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { MAXWELL_LTC1_READ_SYSMEM_HIT_SECTORS_FBP, maxwell_ltc1_read_sysmem_hit_sectors_fbp_enc_str_1, MAXWELL_LTC1_HIT_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_RD_OP, MAXWELL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_LTC1_WRITE_SYSMEM_HIT_SECTORS_FBP, maxwell_ltc1_write_sysmem_hit_sectors_fbp_enc_str_1, MAXWELL_LTC1_HIT_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_WR_OP, MAXWELL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_LTC1_READ_SYSMEM_MISS_SECTORS_FBP, maxwell_ltc1_read_sysmem_miss_sectors_fbp_enc_str_1, MAXWELL_LTC1_MISS_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_RD_OP, MAXWELL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { MAXWELL_LTC1_WRITE_SYSMEM_MISS_SECTORS_FBP, maxwell_ltc1_write_sysmem_miss_sectors_fbp_enc_str_1, MAXWELL_LTC1_MISS_SECTORS, {MAXWELL_LTC1_REQUEST_ACTIVE, MAXWELL_LTC1_REQUEST_WR_OP, MAXWELL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},


    { MAXWELL_LTC1_LTCX_MC_REQ_RD_SIZE_32B, maxwell_ltc1_ltcx_mc_req_rd_size_32b_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC1_LTCX_MC_REQ_RD, MAXWELL_LTC1_LTCX_MC_REQ_RD_SIZE, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE)), 0},
    { MAXWELL_LTC1_LTCX_MC_REQ_RD_SIZE_64B, maxwell_ltc1_ltcx_mc_req_rd_size_64b_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC1_LTCX_MC_REQ_RD, MAXWELL_LTC1_LTCX_MC_REQ_RD_SIZE, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { MAXWELL_LTC1_LTCX_MC_REQ_WR_SIZE_16B, maxwell_ltc1_ltcx_mc_req_wr_size_16b_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC1_LTCX_MC_REQ_WR, MAXWELL_LTC1_LTCX_MC_REQ_WR_SIZE_0, MAXWELL_LTC1_LTCX_MC_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { MAXWELL_LTC1_LTCX_MC_REQ_WR_SIZE_32B, maxwell_ltc1_ltcx_mc_req_wr_size_32b_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC1_LTCX_MC_REQ_WR, MAXWELL_LTC1_LTCX_MC_REQ_WR_SIZE_0, MAXWELL_LTC1_LTCX_MC_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { MAXWELL_LTC1_LTCX_MC_REQ_WR_SIZE_64B, maxwell_ltc1_ltcx_mc_req_wr_size_64b_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC1_LTCX_MC_REQ_WR, MAXWELL_LTC1_LTCX_MC_REQ_WR_SIZE_0, MAXWELL_LTC1_LTCX_MC_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { MAXWELL_LTC1_LTCX_REQ_RD_SECTOR_COUNT_1, maxwell_ltc1_ltcx_req_rd_sector_count_1_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC1_LTCX_REQ_RD, MAXWELL_LTC1_LTCX_REQ_RD_SIZE_0, MAXWELL_LTC1_LTCX_REQ_RD_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { MAXWELL_LTC1_LTCX_REQ_RD_SECTOR_COUNT_2, maxwell_ltc1_ltcx_req_rd_sector_count_2_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC1_LTCX_REQ_RD, MAXWELL_LTC1_LTCX_REQ_RD_SIZE_0, MAXWELL_LTC1_LTCX_REQ_RD_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { MAXWELL_LTC1_LTCX_REQ_RD_SECTOR_COUNT_3, maxwell_ltc1_ltcx_req_rd_sector_count_3_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC1_LTCX_REQ_RD, MAXWELL_LTC1_LTCX_REQ_RD_SIZE_0, MAXWELL_LTC1_LTCX_REQ_RD_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { MAXWELL_LTC1_LTCX_REQ_RD_SECTOR_COUNT_4, maxwell_ltc1_ltcx_req_rd_sector_count_4_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC1_LTCX_REQ_RD, MAXWELL_LTC1_LTCX_REQ_RD_SIZE_0, MAXWELL_LTC1_LTCX_REQ_RD_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { MAXWELL_LTC1_LTCX_REQ_WR_SECTOR_COUNT_1, maxwell_ltc1_ltcx_req_wr_sector_count_1_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC1_LTCX_REQ_WR, MAXWELL_LTC1_LTCX_REQ_WR_SIZE_0, MAXWELL_LTC1_LTCX_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { MAXWELL_LTC1_LTCX_REQ_WR_SECTOR_COUNT_2, maxwell_ltc1_ltcx_req_wr_sector_count_2_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC1_LTCX_REQ_WR, MAXWELL_LTC1_LTCX_REQ_WR_SIZE_0, MAXWELL_LTC1_LTCX_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { MAXWELL_LTC1_LTCX_REQ_WR_SECTOR_COUNT_3, maxwell_ltc1_ltcx_req_wr_sector_count_3_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC1_LTCX_REQ_WR, MAXWELL_LTC1_LTCX_REQ_WR_SIZE_0, MAXWELL_LTC1_LTCX_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { MAXWELL_LTC1_LTCX_REQ_WR_SECTOR_COUNT_4, maxwell_ltc1_ltcx_req_wr_sector_count_4_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_LTC1_LTCX_REQ_WR, MAXWELL_LTC1_LTCX_REQ_WR_SIZE_0, MAXWELL_LTC1_LTCX_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000,  0x00},
};

PerfSignalHwpm PerfSignalTableGM20Y_sys0[] = {
    //Hub TLB signals
    //__hub_tlb_hit        = hubmmu2pm_hub_hub_tlb_hit                                      count # of PTE hits in hub TLB
    //__hub_tlb_miss       = (hubmmu2pm_hub_hub_tlb_miss & !hubmmu2pm_hub_hub_tlb_hit)      count # of PTE misses in hub TLB
    { MAXWELL_MMU_HUB_TLB_HIT,    maxwell_mmu_hub_tlb_hit_enc_str_1,    0x00000004, 0x0000AAAA, 0x51,    PM_UNIT_HUBMMU, 1 },
    { MAXWELL_MMU_HUB_TLB_MISS_INT,   maxwell_mmu_hub_tlb_miss_int_enc_str_1,   0x00000004, 0x0000AAAA, 0x52,    PM_UNIT_HUBMMU, 1 },

    // mmu_fill_pte_hit    = hubmmu2pm_hub_fill_pte_hit                                     "count # of PTE hits in mmu fill unit"
    // mmu_fill_pte_miss   = (hubmmu2pm_hub_fill_pte_miss & !hubmmu2pm_hub_fill_pte_hit)    "count # of PTE misses in mmu fill unit"
    { MAXWELL_MMU_FILL_PTE_HIT,   maxwell_mmu_fill_pte_hit_enc_str_1,   0x00000006, 0x0000AAAA, 0x51,    PM_UNIT_HUBMMU, 1 },
    { MAXWELL_MMU_FILL_PTE_MISS_INT,  maxwell_mmu_fill_pte_miss_int_enc_str_1,  0x00000006, 0x0000AAAA, 0x52,    PM_UNIT_HUBMMU, 1 },

    // mmu_fill_pde_hit    = hubmmu2pm_hub_fill_pde_hit                                     "count # of PDE hits in mmu fill unit"
    // mmu_fill_pde_miss   = hubmmu2pm_hub_fill_pde_miss                                    "count # of PDE misses in mmu fill unit"
    { MAXWELL_MMU_FILL_PDE_HIT,   maxwell_mmu_fill_pde_hit_enc_str_1,   0x00000006, 0x0000AAAA, 0x53,    PM_UNIT_HUBMMU,1 },
    { MAXWELL_MMU_FILL_PDE_MISS,  maxwell_mmu_fill_pde_miss_enc_str_1,  0x00000006, 0x0000AAAA, 0x54,    PM_UNIT_HUBMMU,1 },

    { INVALID_PM_SIGNAL_NEW,     "",                     0xffffffff, 0x00000000, 0x00,     PM_UNIT_MAX,0}
};

PerfSignalHwpmExpt PerfSignalTableGM20Y_sys0_expt[] = {
    //Hub TLB signals
    //__hub_tlb_miss       = (hubmmu2pm_hub_hub_tlb_miss & !hubmmu2pm_hub_hub_tlb_hit)      count # of PTE misses in hub TLB
    { MAXWELL_MMU_HUB_TLB_MISS, maxwell_mmu_hub_tlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_MMU_HUB_TLB_HIT, MAXWELL_MMU_HUB_TLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},

    // mmu_fill_pte_miss   = (hubmmu2pm_hub_fill_pte_miss & !hubmmu2pm_hub_fill_pte_hit)    "count # of PTE misses in mmu fill unit"
    { MAXWELL_MMU_FILL_PTE_MISS, maxwell_mmu_fill_pte_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {MAXWELL_MMU_FILL_PTE_HIT, MAXWELL_MMU_FILL_PTE_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},

   { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000,  0x00}
};
#endif /* NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B) */

CUdomainData domainTableGM000[] = {
    {MAXWELL_CLK_DOMAIN_GM000_GPCTPC,                       maxwell_clk_domain_gm000_gpctpc_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGM000_gpctpc, PERF_SIG_TABLE_TYPE_HWPM},{(void *)PerfSignalTableGM000_gpctpc_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}},    0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 2},
    //Both ltc0 and ltc1 clock domains will be supported by this external domain
    {MAXWELL_CLK_DOMAIN_GM000_FBP0,                         maxwell_clk_domain_gm000_fbp0_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGM000_fbp0, PERF_SIG_TABLE_TYPE_HWPM}},                                0,  0,  0,  PM_CHIPLET_TYPE_FBP, 0, 0, 1},
    // Creating separate domain  for sw counters
    // sw counters may also have separate domain types based on type of instrumentation
    {MAXWELL_SW_DOMAIN_PPA_NOPTRIG_GLOBAL_LOAD_STORE, maxwell_sw_domain_ppa_noptrig_global_load_store_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGMSwCounters_nop_trig_global_load_store, PERF_SIG_TABLE_TYPE_SMPC}},   0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {MAXWELL_CLK_DOMAIN_GM000_SM0,                          maxwell_clk_domain_gm000_sm0_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_SMPERF,            {{(void *)PerfSignalTableGM000_sm0, PERF_SIG_TABLE_TYPE_SMPC}, {(void *)PerfSignalTableGM000_LutModeCounters, PERF_SIG_TABLE_TYPE_LUT}, {(void *)PerfSignalTableGM000_multiGroup, PERF_SIG_TABLE_TYPE_MULTI_GROUP}},        0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 3},
    {MAXWELL_CLK_DOMAIN_GM000_LTC0,                         maxwell_clk_domain_gm000_ltc0_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGM000_ltc0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGM000_ltc0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}},       0,  0,  0,  PM_CHIPLET_TYPE_FBP, 0, 0, 2},
    {MAXWELL_CLK_DOMAIN_GM000_LTC1,                         maxwell_clk_domain_gm000_ltc1_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGM000_ltc1, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGM000_ltc1_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}},       0,  0,  0,  PM_CHIPLET_TYPE_FBP, 0, 0, 2},
    {MAXWELL_SW_DOMAIN_PPA_NOPTRIG_FLOPS,             maxwell_sw_domain_ppa_noptrig_flops_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGMSwCounters_nop_trig_flops, PERF_SIG_TABLE_TYPE_SMPC}},               0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {MAXWELL_SW_DOMAIN_PPA_NOPTRIG_INSTR_CLASS,       maxwell_sw_domain_ppa_noptrig_instr_class_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGMSwCounters_instrClass, PERF_SIG_TABLE_TYPE_SMPC}},               0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {MAXWELL_SW_DOMAIN_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS,       maxwell_sw_domain_ppa_noptrig_generic_counters_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGMSwCounters_genericLdStCounters, PERF_SIG_TABLE_TYPE_SMPC}},               0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {MAXWELL_SW_DOMAIN_PPA_NOPTRIG_SHARED_LOAD_STORE, maxwell_sw_domain_ppa_noptrig_shared_load_store_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGMSwCounters_nop_trig_shared_load_store, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {MAXWELL_SW_DOMAIN_PPA_NOPTRIG_UNIQUE_GLD_GST,   maxwell_sw_domain_ppa_noptrig_unique_gld_gst_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGMSwCounters_unique_gld_gst, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {MAXWELL_SW_DOMAIN_PPA_NOPTRIG_UNIQUE_SECTOR_ACCESS_GLD,   maxwell_sw_domain_ppa_noptrig_unique_sector_access_gld_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGMSwCounters_unique_sector_access_gld, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    //MAXWELL_CLK_DOMAIN_GM000_HWPMMUX will be a dummy id that is used to identify the HWPM signals profiled via SMPC.
    //We require this so that we can restrict profiling these signals with pure HWPM or pure SMPC signals
    //Currently there is no way to avoid this except having check at domain level, also it is possible that we will allow pure HWPM signals with pure SMPC.
    //Internally this domain id will be mapped to MAXWELL_CLK_DOMAIN_GM000_GPCTPC
    {MAXWELL_CLK_DOMAIN_GM000_HWPMMUX,                      maxwell_clk_domain_gm000_hwpmmux_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX,              {{(void *)PerfSignalTableGM000_hwpmmux, PERF_SIG_TABLE_TYPE_HWPMMUX}},                          0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {MAXWELL_CLK_DOMAIN_GM000_SYS0,                         maxwell_clk_domain_gm000_sys0_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGM000_sys0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGM000_sys0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}},       0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 2},
    {MAXWELL_CLK_DOMAIN_GM000_GPC0,                         maxwell_clk_domain_gm000_gpc0_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGM000_gpc0, PERF_SIG_TABLE_TYPE_HWPM}},                                0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
};

#if NVCFG(GLOBAL_GPU_FAMILY_GM20X)
CUdomainData domainTableGM200[] = {
    {MAXWELL_CLK_DOMAIN_GM200_GPCTPC,                       maxwell_clk_domain_gm000_gpctpc_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGM200_gpctpc, PERF_SIG_TABLE_TYPE_HWPM},{(void *)PerfSignalTableGM200_gpctpc_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}},    0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 2},
    //Both ltc0 and ltc1 clock domains will be supported by this external domain
    {MAXWELL_CLK_DOMAIN_GM000_FBP0,                         maxwell_clk_domain_gm000_fbp0_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGM000_fbp0, PERF_SIG_TABLE_TYPE_HWPM}},                                0,  0,  0,  PM_CHIPLET_TYPE_FBP, 0, 0, 1},
    // Creating separate domain  for sw counters
    // sw counters may also have separate domain types based on type of instrumentation
    {MAXWELL_SW_DOMAIN_PPA_NOPTRIG_GLOBAL_LOAD_STORE, maxwell_sw_domain_ppa_noptrig_global_load_store_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGMSwCounters_nop_trig_global_load_store, PERF_SIG_TABLE_TYPE_SMPC}},   0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {MAXWELL_CLK_DOMAIN_GM200_SM0,                          maxwell_clk_domain_gm000_sm0_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_SMPERF,            {{(void *)PerfSignalTableGM200_sm0, PERF_SIG_TABLE_TYPE_SMPC}, {(void *)PerfSignalTableGM000_LutModeCounters, PERF_SIG_TABLE_TYPE_LUT}, {(void *)PerfSignalTableGM000_multiGroup, PERF_SIG_TABLE_TYPE_MULTI_GROUP}},        0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 3},
    {MAXWELL_CLK_DOMAIN_GM200_LTC0,                         maxwell_clk_domain_gm000_ltc0_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGM200_ltc0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGM000_ltc0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}},       0,  0,  0,  PM_CHIPLET_TYPE_FBP, 0, 0, 2},
    {MAXWELL_SW_DOMAIN_PPA_NOPTRIG_FLOPS,             maxwell_sw_domain_ppa_noptrig_flops_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGMSwCounters_nop_trig_flops, PERF_SIG_TABLE_TYPE_SMPC}},               0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {MAXWELL_SW_DOMAIN_PPA_NOPTRIG_INSTR_CLASS,       maxwell_sw_domain_ppa_noptrig_instr_class_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGMSwCounters_instrClass, PERF_SIG_TABLE_TYPE_SMPC}},               0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {MAXWELL_SW_DOMAIN_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS,       maxwell_sw_domain_ppa_noptrig_generic_counters_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGMSwCounters_genericLdStCounters, PERF_SIG_TABLE_TYPE_SMPC}},               0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {MAXWELL_SW_DOMAIN_PPA_NOPTRIG_SHARED_LOAD_STORE, maxwell_sw_domain_ppa_noptrig_shared_load_store_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGMSwCounters_nop_trig_shared_load_store, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {MAXWELL_SW_DOMAIN_PPA_NOPTRIG_UNIQUE_GLD_GST,   maxwell_sw_domain_ppa_noptrig_unique_gld_gst_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGMSwCounters_unique_gld_gst, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    // Keep domains of exposed events and events used in metrics, before domains belong to internal events.
    // Else, such events won't get enumerated.
    {MAXWELL_CLK_DOMAIN_GM200_PCIE0,    maxwell_clk_domain_gm200_pcie0_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_HWPM,    {{(void *)PerfSignalTableGM20x_pcie0, PERF_SIG_TABLE_TYPE_HWPM}},      0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 1, CUPROF_EVENT_COLLECTION_SCOPE_DEVICE},
    {MAXWELL_SW_DOMAIN_PPA_NOPTRIG_UNIQUE_SECTOR_ACCESS_GLD,   maxwell_sw_domain_ppa_noptrig_unique_sector_access_gld_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGMSwCounters_unique_sector_access_gld, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    //MAXWELL_CLK_DOMAIN_GM000_HWPMMUX will be a dummy id that is used to identify the HWPM signals profiled via SMPC.
    //We require this so that we can restrict profiling these signals with pure HWPM or pure SMPC signals
    //Currently there is no way to avoid this except having check at domain level, also it is possible that we will allow pure HWPM signals with pure SMPC.
    //Internally this domain id will be mapped to MAXWELL_CLK_DOMAIN_GM000_GPCTPC
    {MAXWELL_CLK_DOMAIN_GM200_HWPMMUX,                      maxwell_clk_domain_gm000_hwpmmux_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX,        {{(void *)PerfSignalTableGM200_hwpmmux, PERF_SIG_TABLE_TYPE_HWPMMUX}},                          0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {MAXWELL_CLK_DOMAIN_GM200_SYS0,                         maxwell_clk_domain_gm000_sys0_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGM200_sys0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGM200_sys0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}},       0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 2},
    {MAXWELL_CLK_DOMAIN_GM000_GPC0,                         maxwell_clk_domain_gm000_gpc0_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGM000_gpc0, PERF_SIG_TABLE_TYPE_HWPM}},                                0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
};
#endif /* NVCFG(GLOBAL_GPU_FAMILY_GM20X) */

#if NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
CUdomainData domainTableGM20Y[] = {
    {MAXWELL_CLK_DOMAIN_GM20Y_GPCTPC,                       maxwell_clk_domain_gm000_gpctpc_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGM200_gpctpc, PERF_SIG_TABLE_TYPE_HWPM},{(void *)PerfSignalTableGM200_gpctpc_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}},    0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 2},
    // Creating separate domain  for sw counters
    // sw counters may also have separate domain types based on type of instrumentation
    {MAXWELL_SW_DOMAIN_PPA_NOPTRIG_GLOBAL_LOAD_STORE, maxwell_sw_domain_ppa_noptrig_global_load_store_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGMSwCounters_nop_trig_global_load_store, PERF_SIG_TABLE_TYPE_SMPC}},   0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {MAXWELL_CLK_DOMAIN_GM20Y_SM0,                          maxwell_clk_domain_gm000_sm0_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_SMPERF,            {{(void *)PerfSignalTableGM200_sm0, PERF_SIG_TABLE_TYPE_SMPC}, {(void *)PerfSignalTableGM000_LutModeCounters, PERF_SIG_TABLE_TYPE_LUT}, {(void *)PerfSignalTableGM000_multiGroup, PERF_SIG_TABLE_TYPE_MULTI_GROUP}},        0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 3},
    {MAXWELL_CLK_DOMAIN_GM20Y_FBP0,                         maxwell_clk_domain_gm000_ltc0_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGM20Y_ltc0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGM20Y_ltc0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}},       0,  0,  0,  PM_CHIPLET_TYPE_FBP, 0, 0, 2},
    {MAXWELL_SW_DOMAIN_PPA_NOPTRIG_FLOPS,             maxwell_sw_domain_ppa_noptrig_flops_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGMSwCounters_nop_trig_flops, PERF_SIG_TABLE_TYPE_SMPC}},               0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {MAXWELL_SW_DOMAIN_PPA_NOPTRIG_INSTR_CLASS,       maxwell_sw_domain_ppa_noptrig_instr_class_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGMSwCounters_instrClass, PERF_SIG_TABLE_TYPE_SMPC}},               0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {MAXWELL_SW_DOMAIN_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS,       maxwell_sw_domain_ppa_noptrig_generic_counters_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGMSwCounters_genericLdStCounters, PERF_SIG_TABLE_TYPE_SMPC}},               0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {MAXWELL_SW_DOMAIN_PPA_NOPTRIG_SHARED_LOAD_STORE, maxwell_sw_domain_ppa_noptrig_shared_load_store_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGMSwCounters_nop_trig_shared_load_store, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {MAXWELL_SW_DOMAIN_PPA_NOPTRIG_UNIQUE_GLD_GST,   maxwell_sw_domain_ppa_noptrig_unique_gld_gst_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGMSwCounters_unique_gld_gst, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {MAXWELL_SW_DOMAIN_PPA_NOPTRIG_UNIQUE_SECTOR_ACCESS_GLD,   maxwell_sw_domain_ppa_noptrig_unique_sector_access_gld_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGMSwCounters_unique_sector_access_gld, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    //MAXWELL_CLK_DOMAIN_GM000_HWPMMUX will be a dummy id that is used to identify the HWPM signals profiled via SMPC.
    //We require this so that we can restrict profiling these signals with pure HWPM or pure SMPC signals
    //Currently there is no way to avoid this except having check at domain level, also it is possible that we will allow pure HWPM signals with pure SMPC.
    //Internally this domain id will be mapped to MAXWELL_CLK_DOMAIN_GM000_GPCTPC
    {MAXWELL_CLK_DOMAIN_GM20Y_HWPMMUX,                      maxwell_clk_domain_gm20y_hwpmmux_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX,        {{(void *)PerfSignalTableGM200_hwpmmux, PERF_SIG_TABLE_TYPE_HWPMMUX}},                          0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {MAXWELL_CLK_DOMAIN_GM20Y_SYS0,                         maxwell_clk_domain_gm000_sys0_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGM20Y_sys0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGM20Y_sys0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}},       0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 2},
    {MAXWELL_CLK_DOMAIN_GM20Y_GPC0,                         maxwell_clk_domain_gm000_gpc0_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGM000_gpc0, PERF_SIG_TABLE_TYPE_HWPM}},                                0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
};
#endif /* NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B) */

SignalDescriptionTable pMaxwellSignalDescriptionArray[] = {
    {MAXWELL_TEX0_SECTOR_QUERIES, maxwell_tex0_sector_queries_enc_str_1, maxwell_tex0_sector_queries_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_sector_queries_enc_str_4},
    {MAXWELL_TEX1_SECTOR_QUERIES, maxwell_tex1_sector_queries_enc_str_1, maxwell_tex1_sector_queries_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_sector_queries_enc_str_4},
    {MAXWELL_TEX0_MISSED_SECTORS, maxwell_tex0_missed_sectors_enc_str_1, maxwell_tex0_missed_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_missed_sectors_enc_str_4},
    {MAXWELL_TEX1_MISSED_SECTORS, maxwell_tex1_missed_sectors_enc_str_1, maxwell_tex1_missed_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_missed_sectors_enc_str_4},
    {MAXWELL_TEX0_LG_SECTOR_QUERIES, maxwell_tex0_lg_sector_queries_enc_str_1, maxwell_tex0_lg_sector_queries_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_lg_sector_queries_enc_str_4},
    {MAXWELL_TEX1_LG_SECTOR_QUERIES, maxwell_tex1_lg_sector_queries_enc_str_1, maxwell_tex1_lg_sector_queries_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_lg_sector_queries_enc_str_4},
    {MAXWELL_TEX0_LG_MISSED_SECTORS, maxwell_tex0_lg_missed_sectors_enc_str_1, maxwell_tex0_lg_missed_sectors_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_lg_missed_sectors_enc_str_4},
    {MAXWELL_TEX1_LG_MISSED_SECTORS, maxwell_tex1_lg_missed_sectors_enc_str_1, maxwell_tex1_lg_missed_sectors_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_lg_missed_sectors_enc_str_4},
    {MAXWELL_TEX0_MISSED_SECTORS_ANY, maxwell_tex0_missed_sectors_any_enc_str_1, maxwell_tex0_missed_sectors_any_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_missed_sectors_any_enc_str_1},
    {MAXWELL_TEX1_MISSED_SECTORS_ANY, maxwell_tex1_missed_sectors_any_enc_str_1, maxwell_tex1_missed_sectors_any_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_missed_sectors_any_enc_str_1},
    {MAXWELL_TEX0_COALESCED_SECTORS, maxwell_tex0_coalesced_sectors_enc_str_1, maxwell_tex0_coalesced_sectors_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_coalesced_sectors_enc_str_1},
    {MAXWELL_TEX1_COALESCED_SECTORS, maxwell_tex1_coalesced_sectors_enc_str_1, maxwell_tex1_coalesced_sectors_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_coalesced_sectors_enc_str_1},

    {MAXWELL_TEX0_GLOBAL_LD_HITS,   maxwell_tex0_global_ld_hits_enc_str_1,   maxwell_tex0_global_ld_hits_enc_str_1,   CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_ld_hits_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_LD_HITS,   maxwell_tex1_global_ld_hits_enc_str_1,   maxwell_tex1_global_ld_hits_enc_str_1,   CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_ld_hits_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_LD_MISSES, maxwell_tex0_global_ld_misses_enc_str_1, maxwell_tex0_global_ld_misses_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_ld_misses_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_LD_MISSES, maxwell_tex1_global_ld_misses_enc_str_1, maxwell_tex1_global_ld_misses_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_ld_misses_enc_str_1},
    {MAXWELL_TEX0_LOCAL_LD_HITS,    maxwell_tex0_local_ld_hits_enc_str_1,    maxwell_tex0_local_ld_hits_enc_str_1,    CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_local_ld_hits_enc_str_1},
    {MAXWELL_TEX1_LOCAL_LD_HITS,    maxwell_tex1_local_ld_hits_enc_str_1,    maxwell_tex1_local_ld_hits_enc_str_1,    CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_local_ld_hits_enc_str_1},
    {MAXWELL_TEX0_LOCAL_LD_MISSES,  maxwell_tex0_local_ld_misses_enc_str_1,  maxwell_tex0_local_ld_misses_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_local_ld_misses_enc_str_1},
    {MAXWELL_TEX1_LOCAL_LD_MISSES,  maxwell_tex1_local_ld_misses_enc_str_1,  maxwell_tex1_local_ld_misses_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_local_ld_misses_enc_str_1},
    {MAXWELL_TEX0_SURFACE_LD_MISSES, maxwell_tex0_surface_ld_misses_enc_str_1, maxwell_tex0_surface_ld_misses_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_ld_misses_enc_str_1},
    {MAXWELL_TEX1_SURFACE_LD_MISSES, maxwell_tex1_surface_ld_misses_enc_str_1, maxwell_tex1_surface_ld_misses_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_ld_misses_enc_str_1},

    {MAXWELL_TEX0_CACHED_GLOBAL_LD_HITS, maxwell_tex0_cached_global_ld_hits_enc_str_1, maxwell_tex0_cached_global_ld_hits_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_cached_global_ld_hits_enc_str_1},
    {MAXWELL_TEX1_CACHED_GLOBAL_LD_HITS, maxwell_tex1_cached_global_ld_hits_enc_str_1, maxwell_tex1_cached_global_ld_hits_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_cached_global_ld_hits_enc_str_1},
    {MAXWELL_TEX0_CACHED_GLOBAL_LD_MISSES, maxwell_tex0_cached_global_ld_misses_enc_str_1, maxwell_tex0_cached_global_ld_misses_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_cached_global_ld_misses_enc_str_1},
    {MAXWELL_TEX0_UNCACHED_GLOBAL_LD_MISSES, maxwell_tex0_uncached_global_ld_misses_enc_str_1, maxwell_tex0_uncached_global_ld_misses_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_uncached_global_ld_misses_enc_str_1},
    {MAXWELL_TEX1_CACHED_GLOBAL_LD_MISSES, maxwell_tex1_cached_global_ld_misses_enc_str_1, maxwell_tex1_cached_global_ld_misses_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_cached_global_ld_misses_enc_str_1},
    {MAXWELL_TEX1_UNCACHED_GLOBAL_LD_MISSES, maxwell_tex1_uncached_global_ld_misses_enc_str_1, maxwell_tex1_uncached_global_ld_misses_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_uncached_global_ld_misses_enc_str_1},
    {MAXWELL_TEX0_CACHED_GLOBAL_LD_SET_CONFLICTS, maxwell_tex0_cached_global_ld_set_conflicts_enc_str_1, maxwell_tex0_cached_global_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_cached_global_ld_set_conflicts_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_LD_SET_CONFLICTS, maxwell_tex0_global_ld_set_conflicts_enc_str_1, maxwell_tex0_global_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_ld_set_conflicts_enc_str_1},
    {MAXWELL_TEX0_UNCACHED_GLOBAL_LD_SET_CONFLICTS, maxwell_tex0_uncached_global_ld_set_conflicts_enc_str_1, maxwell_tex0_uncached_global_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_uncached_global_ld_set_conflicts_enc_str_1},
    {MAXWELL_TEX1_CACHED_GLOBAL_LD_SET_CONFLICTS, maxwell_tex1_cached_global_ld_set_conflicts_enc_str_1, maxwell_tex1_cached_global_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_cached_global_ld_set_conflicts_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_LD_SET_CONFLICTS, maxwell_tex1_global_ld_set_conflicts_enc_str_1, maxwell_tex1_global_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_ld_set_conflicts_enc_str_1},
    {MAXWELL_TEX1_UNCACHED_GLOBAL_LD_SET_CONFLICTS, maxwell_tex1_uncached_global_ld_set_conflicts_enc_str_1, maxwell_tex1_uncached_global_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_uncached_global_ld_set_conflicts_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_LD_COALESCING, maxwell_tex0_global_ld_coalescing_enc_str_1, maxwell_tex0_global_ld_coalescing_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_ld_coalescing_enc_str_1},
    {MAXWELL_TEX0_UNCACHED_GLOBAL_LD_COALESCING, maxwell_tex0_uncached_global_ld_coalescing_enc_str_1, maxwell_tex0_uncached_global_ld_coalescing_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_uncached_global_ld_coalescing_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_LD_COALESCING, maxwell_tex1_global_ld_coalescing_enc_str_1, maxwell_tex1_global_ld_coalescing_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_ld_coalescing_enc_str_1},
    {MAXWELL_TEX1_UNCACHED_GLOBAL_LD_COALESCING, maxwell_tex1_uncached_global_ld_coalescing_enc_str_1, maxwell_tex1_uncached_global_ld_coalescing_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_uncached_global_ld_coalescing_enc_str_1},
    {MAXWELL_TEX0_CACHED_LOCAL_LD_HITS, maxwell_tex0_cached_local_ld_hits_enc_str_1, maxwell_tex0_cached_local_ld_hits_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_cached_local_ld_hits_enc_str_1},
    {MAXWELL_TEX1_CACHED_LOCAL_LD_HITS, maxwell_tex1_cached_local_ld_hits_enc_str_1, maxwell_tex1_cached_local_ld_hits_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_cached_local_ld_hits_enc_str_1},
    {MAXWELL_TEX0_CACHED_LOCAL_LD_MISSES, maxwell_tex0_cached_local_ld_misses_enc_str_1, maxwell_tex0_cached_local_ld_misses_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_cached_local_ld_misses_enc_str_1},
    {MAXWELL_TEX0_UNCACHED_LOCAL_LD_MISSES, maxwell_tex0_uncached_local_ld_misses_enc_str_1, maxwell_tex0_uncached_local_ld_misses_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_uncached_local_ld_misses_enc_str_1},
    {MAXWELL_TEX1_CACHED_LOCAL_LD_MISSES, maxwell_tex1_cached_local_ld_misses_enc_str_1, maxwell_tex1_cached_local_ld_misses_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_cached_local_ld_misses_enc_str_1},
    {MAXWELL_TEX1_UNCACHED_LOCAL_LD_MISSES, maxwell_tex1_uncached_local_ld_misses_enc_str_1, maxwell_tex1_uncached_local_ld_misses_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_uncached_local_ld_misses_enc_str_1},
    {MAXWELL_TEX0_CACHED_GLOBAL_LD_SET_ACCESS, maxwell_tex0_cached_global_ld_set_access_enc_str_1, maxwell_tex0_cached_global_ld_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_cached_global_ld_set_access_enc_str_1},
    {MAXWELL_TEX1_CACHED_GLOBAL_LD_SET_ACCESS, maxwell_tex1_cached_global_ld_set_access_enc_str_1, maxwell_tex1_cached_global_ld_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_cached_global_ld_set_access_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_LD_SET_ACCESS, maxwell_tex0_global_ld_set_access_enc_str_1, maxwell_tex0_global_ld_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_ld_set_access_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_LD_SET_ACCESS, maxwell_tex1_global_ld_set_access_enc_str_1, maxwell_tex1_global_ld_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_ld_set_access_enc_str_1},
    {MAXWELL_TEX0_UNCACHED_GLOBAL_LD_SET_ACCESS, maxwell_tex0_uncached_global_ld_set_access_enc_str_1, maxwell_tex0_uncached_global_ld_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_uncached_global_ld_set_access_enc_str_1},
    {MAXWELL_TEX1_UNCACHED_GLOBAL_LD_SET_ACCESS, maxwell_tex1_uncached_global_ld_set_access_enc_str_1, maxwell_tex1_uncached_global_ld_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_uncached_global_ld_set_access_enc_str_1},
    {MAXWELL_TEX0_CACHED_LOCAL_LD_SET_ACCESS, maxwell_tex0_cached_local_ld_set_access_enc_str_1, maxwell_tex0_cached_local_ld_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_cached_local_ld_set_access_enc_str_1},
    {MAXWELL_TEX0_LOCAL_LD_SET_ACCESS, maxwell_tex0_local_ld_set_access_enc_str_1, maxwell_tex0_local_ld_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_local_ld_set_access_enc_str_1},
    {MAXWELL_TEX0_UNCACHED_LOCAL_LD_SET_ACCESS, maxwell_tex0_uncached_local_ld_set_access_enc_str_1, maxwell_tex0_uncached_local_ld_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_uncached_local_ld_set_access_enc_str_1},
    {MAXWELL_TEX1_CACHED_LOCAL_LD_SET_ACCESS, maxwell_tex1_cached_local_ld_set_access_enc_str_1, maxwell_tex1_cached_local_ld_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_cached_local_ld_set_access_enc_str_1},
    {MAXWELL_TEX1_LOCAL_LD_SET_ACCESS, maxwell_tex1_local_ld_set_access_enc_str_1, maxwell_tex1_local_ld_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_local_ld_set_access_enc_str_1},
    {MAXWELL_TEX1_UNCACHED_LOCAL_LD_SET_ACCESS, maxwell_tex1_uncached_local_ld_set_access_enc_str_1, maxwell_tex1_uncached_local_ld_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_uncached_local_ld_set_access_enc_str_1},
    {MAXWELL_TEX0_CACHED_LOCAL_LD_SET_CONFLICTS, maxwell_tex0_cached_local_ld_set_conflicts_enc_str_1, maxwell_tex0_cached_local_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_cached_local_ld_set_conflicts_enc_str_1},
    {MAXWELL_TEX0_LOCAL_LD_SET_CONFLICTS, maxwell_tex0_local_ld_set_conflicts_enc_str_1, maxwell_tex0_local_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_local_ld_set_conflicts_enc_str_1},
    {MAXWELL_TEX0_UNCACHED_LOCAL_LD_SET_CONFLICTS, maxwell_tex0_uncached_local_ld_set_conflicts_enc_str_1, maxwell_tex0_uncached_local_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_uncached_local_ld_set_conflicts_enc_str_1},
    {MAXWELL_TEX1_CACHED_LOCAL_LD_SET_CONFLICTS, maxwell_tex1_cached_local_ld_set_conflicts_enc_str_1, maxwell_tex1_cached_local_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_cached_local_ld_set_conflicts_enc_str_1},
    {MAXWELL_TEX1_LOCAL_LD_SET_CONFLICTS, maxwell_tex1_local_ld_set_conflicts_enc_str_1, maxwell_tex1_local_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_local_ld_set_conflicts_enc_str_1},
    {MAXWELL_TEX1_UNCACHED_LOCAL_LD_SET_CONFLICTS, maxwell_tex1_uncached_local_ld_set_conflicts_enc_str_1, maxwell_tex1_uncached_local_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_uncached_local_ld_set_conflicts_enc_str_1},
    {MAXWELL_TEX0_LOCAL_LD_COALESCING, maxwell_tex0_local_ld_coalescing_enc_str_1, maxwell_tex0_local_ld_coalescing_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_local_ld_coalescing_enc_str_1},
    {MAXWELL_TEX0_UNCACHED_LOCAL_LD_COALESCING, maxwell_tex0_uncached_local_ld_coalescing_enc_str_1, maxwell_tex0_uncached_local_ld_coalescing_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_uncached_local_ld_coalescing_enc_str_1},
    {MAXWELL_TEX1_LOCAL_LD_COALESCING, maxwell_tex1_local_ld_coalescing_enc_str_1, maxwell_tex1_local_ld_coalescing_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_local_ld_coalescing_enc_str_1},
    {MAXWELL_TEX1_UNCACHED_LOCAL_LD_COALESCING, maxwell_tex1_uncached_local_ld_coalescing_enc_str_1, maxwell_tex1_uncached_local_ld_coalescing_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_uncached_local_ld_coalescing_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_ST_REQUESTS, maxwell_tex0_global_st_requests_enc_str_1, maxwell_tex0_global_st_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_st_requests_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_ST_REQUESTS, maxwell_tex1_global_st_requests_enc_str_1, maxwell_tex1_global_st_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_st_requests_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_ST_SET_ACCESS, maxwell_tex0_global_st_set_access_enc_str_1, maxwell_tex0_global_st_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_st_set_access_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_ST_SET_ACCESS, maxwell_tex1_global_st_set_access_enc_str_1, maxwell_tex1_global_st_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_st_set_access_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_ST_SET_CONFLICTS, maxwell_tex0_global_st_set_conflicts_enc_str_1, maxwell_tex0_global_st_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_st_set_conflicts_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_ST_SET_CONFLICTS, maxwell_tex1_global_st_set_conflicts_enc_str_1, maxwell_tex1_global_st_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_st_set_conflicts_enc_str_1},
    {MAXWELL_TEX0_LOCAL_ST_REQUESTS, maxwell_tex0_local_st_requests_enc_str_1, maxwell_tex0_local_st_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_local_st_requests_enc_str_1},
    {MAXWELL_TEX1_LOCAL_ST_REQUESTS, maxwell_tex1_local_st_requests_enc_str_1, maxwell_tex1_local_st_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_local_st_requests_enc_str_1},
    {MAXWELL_TEX0_LOCAL_ST_SET_ACCESS, maxwell_tex0_local_st_set_access_enc_str_1, maxwell_tex0_local_st_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_local_st_set_access_enc_str_1},
    {MAXWELL_TEX1_LOCAL_ST_SET_ACCESS, maxwell_tex1_local_st_set_access_enc_str_1, maxwell_tex1_local_st_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_local_st_set_access_enc_str_1},
    {MAXWELL_TEX0_LOCAL_ST_SET_CONFLICTS, maxwell_tex0_local_st_set_conflicts_enc_str_1, maxwell_tex0_local_st_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_local_st_set_conflicts_enc_str_1},
    {MAXWELL_TEX1_LOCAL_ST_SET_CONFLICTS, maxwell_tex1_local_st_set_conflicts_enc_str_1, maxwell_tex1_local_st_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_local_st_set_conflicts_enc_str_1},

    {MAXWELL_TEX0_CACHED_GLOBAL_LD_DATA_CONFLICTS, maxwell_tex0_cached_global_ld_data_conflicts_enc_str_1, maxwell_tex0_cached_global_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_cached_global_ld_data_conflicts_enc_str_1},
    {MAXWELL_TEX0_CACHED_LOCAL_LD_DATA_CONFLICTS, maxwell_tex0_cached_local_ld_data_conflicts_enc_str_1, maxwell_tex0_cached_local_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_cached_local_ld_data_conflicts_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_ATOM_CAS_DATA_CONFLICTS, maxwell_tex0_global_atom_cas_data_conflicts_enc_str_1, maxwell_tex0_global_atom_cas_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_atom_cas_data_conflicts_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_ATOM_DATA_CONFLICTS, maxwell_tex0_global_atom_data_conflicts_enc_str_1, maxwell_tex0_global_atom_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_atom_data_conflicts_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_LD_DATA_CONFLICTS, maxwell_tex0_global_ld_data_conflicts_enc_str_1, maxwell_tex0_global_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_ld_data_conflicts_enc_str_1},
    {MAXWELL_TEX0_LOCAL_LD_DATA_CONFLICTS, maxwell_tex0_local_ld_data_conflicts_enc_str_1, maxwell_tex0_local_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_local_ld_data_conflicts_enc_str_1},
    {MAXWELL_TEX0_SURFACE_ATOM_CAS_DATA_CONFLICTS, maxwell_tex0_surface_atom_cas_data_conflicts_enc_str_1, maxwell_tex0_surface_atom_cas_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_atom_cas_data_conflicts_enc_str_1},
    {MAXWELL_TEX0_SURFACE_ATOM_DATA_CONFLICTS, maxwell_tex0_surface_atom_data_conflicts_enc_str_1, maxwell_tex0_surface_atom_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_atom_data_conflicts_enc_str_1},
    {MAXWELL_TEX0_SURFACE_LD_DATA_CONFLICTS, maxwell_tex0_surface_ld_data_conflicts_enc_str_1, maxwell_tex0_surface_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_ld_data_conflicts_enc_str_1},
    {MAXWELL_TEX0_UNCACHED_GLOBAL_LD_DATA_CONFLICTS, maxwell_tex0_uncached_global_ld_data_conflicts_enc_str_1, maxwell_tex0_uncached_global_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_uncached_global_ld_data_conflicts_enc_str_1},
    {MAXWELL_TEX0_UNCACHED_LOCAL_LD_DATA_CONFLICTS, maxwell_tex0_uncached_local_ld_data_conflicts_enc_str_1, maxwell_tex0_uncached_local_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_uncached_local_ld_data_conflicts_enc_str_1},
    {MAXWELL_TEX1_CACHED_GLOBAL_LD_DATA_CONFLICTS, maxwell_tex1_cached_global_ld_data_conflicts_enc_str_1, maxwell_tex1_cached_global_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_cached_global_ld_data_conflicts_enc_str_1},
    {MAXWELL_TEX1_CACHED_LOCAL_LD_DATA_CONFLICTS, maxwell_tex1_cached_local_ld_data_conflicts_enc_str_1, maxwell_tex1_cached_local_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_cached_local_ld_data_conflicts_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_ATOM_CAS_DATA_CONFLICTS, maxwell_tex1_global_atom_cas_data_conflicts_enc_str_1, maxwell_tex1_global_atom_cas_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_atom_cas_data_conflicts_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_ATOM_DATA_CONFLICTS, maxwell_tex1_global_atom_data_conflicts_enc_str_1, maxwell_tex1_global_atom_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_atom_data_conflicts_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_LD_DATA_CONFLICTS, maxwell_tex1_global_ld_data_conflicts_enc_str_1, maxwell_tex1_global_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_ld_data_conflicts_enc_str_1},
    {MAXWELL_TEX1_LOCAL_LD_DATA_CONFLICTS, maxwell_tex1_local_ld_data_conflicts_enc_str_1, maxwell_tex1_local_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_local_ld_data_conflicts_enc_str_1},
    {MAXWELL_TEX1_SURFACE_ATOM_CAS_DATA_CONFLICTS, maxwell_tex1_surface_atom_cas_data_conflicts_enc_str_1, maxwell_tex1_surface_atom_cas_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_atom_cas_data_conflicts_enc_str_1},
    {MAXWELL_TEX1_SURFACE_ATOM_DATA_CONFLICTS, maxwell_tex1_surface_atom_data_conflicts_enc_str_1, maxwell_tex1_surface_atom_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_atom_data_conflicts_enc_str_1},
    {MAXWELL_TEX1_SURFACE_LD_DATA_CONFLICTS, maxwell_tex1_surface_ld_data_conflicts_enc_str_1, maxwell_tex1_surface_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_ld_data_conflicts_enc_str_1},
    {MAXWELL_TEX1_UNCACHED_GLOBAL_LD_DATA_CONFLICTS, maxwell_tex1_uncached_global_ld_data_conflicts_enc_str_1, maxwell_tex1_uncached_global_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_uncached_global_ld_data_conflicts_enc_str_1},
    {MAXWELL_TEX1_UNCACHED_LOCAL_LD_DATA_CONFLICTS, maxwell_tex1_uncached_local_ld_data_conflicts_enc_str_1, maxwell_tex1_uncached_local_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_uncached_local_ld_data_conflicts_enc_str_1},
    {MAXWELL_TEX0_CACHED_GLOBAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex0_cached_global_ld_row_column_conflicts_enc_str_1, maxwell_tex0_cached_global_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_cached_global_ld_row_column_conflicts_enc_str_1},
    {MAXWELL_TEX0_CACHED_LOCAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex0_cached_local_ld_row_column_conflicts_enc_str_1, maxwell_tex0_cached_local_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_cached_local_ld_row_column_conflicts_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_ATOM_CAS_ROW_COLUMN_CONFLICTS, maxwell_tex0_global_atom_cas_row_column_conflicts_enc_str_1, maxwell_tex0_global_atom_cas_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_atom_cas_row_column_conflicts_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_ATOM_ROW_COLUMN_CONFLICTS, maxwell_tex0_global_atom_row_column_conflicts_enc_str_1, maxwell_tex0_global_atom_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_atom_row_column_conflicts_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex0_global_ld_row_column_conflicts_enc_str_1, maxwell_tex0_global_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_ld_row_column_conflicts_enc_str_1},
    {MAXWELL_TEX0_LOCAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex0_local_ld_row_column_conflicts_enc_str_1, maxwell_tex0_local_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_local_ld_row_column_conflicts_enc_str_1},
    {MAXWELL_TEX0_SURFACE_ATOM_CAS_ROW_COLUMN_CONFLICTS, maxwell_tex0_surface_atom_cas_row_column_conflicts_enc_str_1, maxwell_tex0_surface_atom_cas_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_atom_cas_row_column_conflicts_enc_str_1},
    {MAXWELL_TEX0_SURFACE_ATOM_ROW_COLUMN_CONFLICTS, maxwell_tex0_surface_atom_row_column_conflicts_enc_str_1, maxwell_tex0_surface_atom_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_atom_row_column_conflicts_enc_str_1},
    {MAXWELL_TEX0_SURFACE_LD_ROW_COLUMN_CONFLICTS, maxwell_tex0_surface_ld_row_column_conflicts_enc_str_1, maxwell_tex0_surface_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_ld_row_column_conflicts_enc_str_1},
    {MAXWELL_TEX0_UNCACHED_GLOBAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex0_uncached_global_ld_row_column_conflicts_enc_str_1, maxwell_tex0_uncached_global_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_uncached_global_ld_row_column_conflicts_enc_str_1},
    {MAXWELL_TEX0_UNCACHED_LOCAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex0_uncached_local_ld_row_column_conflicts_enc_str_1, maxwell_tex0_uncached_local_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_uncached_local_ld_row_column_conflicts_enc_str_1},
    {MAXWELL_TEX1_CACHED_GLOBAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex1_cached_global_ld_row_column_conflicts_enc_str_1, maxwell_tex1_cached_global_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_cached_global_ld_row_column_conflicts_enc_str_1},
    {MAXWELL_TEX1_CACHED_LOCAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex1_cached_local_ld_row_column_conflicts_enc_str_1, maxwell_tex1_cached_local_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_cached_local_ld_row_column_conflicts_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_ATOM_CAS_ROW_COLUMN_CONFLICTS, maxwell_tex1_global_atom_cas_row_column_conflicts_enc_str_1, maxwell_tex1_global_atom_cas_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_atom_cas_row_column_conflicts_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_ATOM_ROW_COLUMN_CONFLICTS, maxwell_tex1_global_atom_row_column_conflicts_enc_str_1, maxwell_tex1_global_atom_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_atom_row_column_conflicts_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex1_global_ld_row_column_conflicts_enc_str_1, maxwell_tex1_global_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_ld_row_column_conflicts_enc_str_1},
    {MAXWELL_TEX1_LOCAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex1_local_ld_row_column_conflicts_enc_str_1, maxwell_tex1_local_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_local_ld_row_column_conflicts_enc_str_1},
    {MAXWELL_TEX1_SURFACE_ATOM_CAS_ROW_COLUMN_CONFLICTS, maxwell_tex1_surface_atom_cas_row_column_conflicts_enc_str_1, maxwell_tex1_surface_atom_cas_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_atom_cas_row_column_conflicts_enc_str_1},
    {MAXWELL_TEX1_SURFACE_ATOM_ROW_COLUMN_CONFLICTS, maxwell_tex1_surface_atom_row_column_conflicts_enc_str_1, maxwell_tex1_surface_atom_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_atom_row_column_conflicts_enc_str_1},
    {MAXWELL_TEX1_SURFACE_LD_ROW_COLUMN_CONFLICTS, maxwell_tex1_surface_ld_row_column_conflicts_enc_str_1, maxwell_tex1_surface_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_ld_row_column_conflicts_enc_str_1},
    {MAXWELL_TEX1_UNCACHED_GLOBAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex1_uncached_global_ld_row_column_conflicts_enc_str_1, maxwell_tex1_uncached_global_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_uncached_global_ld_row_column_conflicts_enc_str_1},
    {MAXWELL_TEX1_UNCACHED_LOCAL_LD_ROW_COLUMN_CONFLICTS, maxwell_tex1_uncached_local_ld_row_column_conflicts_enc_str_1, maxwell_tex1_uncached_local_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_uncached_local_ld_row_column_conflicts_enc_str_1},

    {MAXWELL_TEX0_LOCAL_LD_REQUESTS, maxwell_tex0_local_ld_requests_enc_str_1, maxwell_tex0_local_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_local_ld_requests_enc_str_1},
    {MAXWELL_TEX1_LOCAL_LD_REQUESTS, maxwell_tex1_local_ld_requests_enc_str_1, maxwell_tex1_local_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_local_ld_requests_enc_str_1},
    {MAXWELL_TEX0_CACHED_LOCAL_LD_REQUESTS, maxwell_tex0_cached_local_ld_requests_enc_str_1, maxwell_tex0_cached_local_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_cached_local_ld_requests_enc_str_1},
    {MAXWELL_TEX1_CACHED_LOCAL_LD_REQUESTS, maxwell_tex1_cached_local_ld_requests_enc_str_1, maxwell_tex1_cached_local_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_cached_local_ld_requests_enc_str_1},
    {MAXWELL_TEX0_UNCACHED_LOCAL_LD_REQUESTS, maxwell_tex0_uncached_local_ld_requests_enc_str_1, maxwell_tex0_uncached_local_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_uncached_local_ld_requests_enc_str_1},
    {MAXWELL_TEX1_UNCACHED_LOCAL_LD_REQUESTS, maxwell_tex1_uncached_local_ld_requests_enc_str_1, maxwell_tex1_uncached_local_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_uncached_local_ld_requests_enc_str_1},

    {MAXWELL_TEX0_CACHED_GLOBAL_LD_REQUESTS, maxwell_tex0_cached_global_ld_requests_enc_str_1, maxwell_tex0_cached_global_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_cached_global_ld_requests_enc_str_1},
    {MAXWELL_TEX1_CACHED_GLOBAL_LD_REQUESTS, maxwell_tex1_cached_global_ld_requests_enc_str_1, maxwell_tex1_cached_global_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_cached_global_ld_requests_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_LD_REQUESTS, maxwell_tex0_global_ld_requests_enc_str_1,  maxwell_tex0_global_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_ld_requests_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_LD_REQUESTS, maxwell_tex1_global_ld_requests_enc_str_1,  maxwell_tex1_global_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_ld_requests_enc_str_1},
    {MAXWELL_TEX0_UNCACHED_GLOBAL_LD_REQUESTS, maxwell_tex0_uncached_global_ld_requests_enc_str_1, maxwell_tex0_uncached_global_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_uncached_global_ld_requests_enc_str_1},
    {MAXWELL_TEX1_UNCACHED_GLOBAL_LD_REQUESTS, maxwell_tex1_uncached_global_ld_requests_enc_str_1, maxwell_tex1_uncached_global_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_uncached_global_ld_requests_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_ATOM_REQUESTS, maxwell_tex0_global_atom_requests_enc_str_1, maxwell_tex0_global_atom_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_atom_requests_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_ATOM_REQUESTS, maxwell_tex1_global_atom_requests_enc_str_1, maxwell_tex1_global_atom_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_atom_requests_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_ATOM_SET_ACCESS, maxwell_tex0_global_atom_set_access_enc_str_1, maxwell_tex0_global_atom_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_atom_set_access_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_ATOM_SET_ACCESS, maxwell_tex1_global_atom_set_access_enc_str_1, maxwell_tex1_global_atom_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_atom_set_access_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_ATOM_SET_CONFLICTS, maxwell_tex0_global_atom_set_conflicts_enc_str_1, maxwell_tex0_global_atom_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_atom_set_conflicts_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_ATOM_SET_CONFLICTS, maxwell_tex1_global_atom_set_conflicts_enc_str_1, maxwell_tex1_global_atom_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_atom_set_conflicts_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_ATOM_CAS_REQUESTS, maxwell_tex0_global_atom_cas_requests_enc_str_1, maxwell_tex0_global_atom_cas_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_atom_cas_requests_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_ATOM_CAS_REQUESTS, maxwell_tex1_global_atom_cas_requests_enc_str_1, maxwell_tex1_global_atom_cas_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_atom_cas_requests_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_ATOM_CAS_SET_ACCESS, maxwell_tex0_global_atom_cas_set_access_enc_str_1, maxwell_tex0_global_atom_cas_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_atom_cas_set_access_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_ATOM_CAS_SET_ACCESS, maxwell_tex1_global_atom_cas_set_access_enc_str_1, maxwell_tex1_global_atom_cas_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_atom_cas_set_access_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_ATOM_CAS_SET_CONFLICTS, maxwell_tex0_global_atom_cas_set_conflicts_enc_str_1, maxwell_tex0_global_atom_cas_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_atom_cas_set_conflicts_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_ATOM_CAS_SET_CONFLICTS, maxwell_tex1_global_atom_cas_set_conflicts_enc_str_1, maxwell_tex1_global_atom_cas_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_atom_cas_set_conflicts_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_RED_REQUESTS, maxwell_tex0_global_red_requests_enc_str_1, maxwell_tex0_global_red_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_red_requests_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_RED_REQUESTS, maxwell_tex1_global_red_requests_enc_str_1, maxwell_tex1_global_red_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_red_requests_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_RED_SET_ACCESS, maxwell_tex0_global_red_set_access_enc_str_1, maxwell_tex0_global_red_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_red_set_access_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_RED_SET_ACCESS, maxwell_tex1_global_red_set_access_enc_str_1, maxwell_tex1_global_red_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_red_set_access_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_RED_SET_CONFLICTS, maxwell_tex0_global_red_set_conflicts_enc_str_1, maxwell_tex0_global_red_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_red_set_conflicts_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_RED_SET_CONFLICTS, maxwell_tex1_global_red_set_conflicts_enc_str_1, maxwell_tex1_global_red_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_red_set_conflicts_enc_str_1},
    {MAXWELL_TEX0_SURFACE_LD_SET_ACCESS, maxwell_tex0_surface_ld_set_access_enc_str_1, maxwell_tex0_surface_ld_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_ld_set_access_enc_str_1},
    {MAXWELL_TEX1_SURFACE_LD_SET_ACCESS, maxwell_tex1_surface_ld_set_access_enc_str_1, maxwell_tex1_surface_ld_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_ld_set_access_enc_str_1},
    {MAXWELL_TEX0_SURFACE_LD_SET_CONFLICTS, maxwell_tex0_surface_ld_set_conflicts_enc_str_1, maxwell_tex0_surface_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_ld_set_conflicts_enc_str_1},
    {MAXWELL_TEX1_SURFACE_LD_SET_CONFLICTS, maxwell_tex1_surface_ld_set_conflicts_enc_str_1, maxwell_tex1_surface_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_ld_set_conflicts_enc_str_1},
    {MAXWELL_TEX0_SURFACE_ST_SET_ACCESS, maxwell_tex0_surface_st_set_access_enc_str_1, maxwell_tex0_surface_st_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_st_set_access_enc_str_1},
    {MAXWELL_TEX1_SURFACE_ST_SET_ACCESS, maxwell_tex1_surface_st_set_access_enc_str_1, maxwell_tex1_surface_st_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_st_set_access_enc_str_1},
    {MAXWELL_TEX0_SURFACE_ST_SET_CONFLICTS, maxwell_tex0_surface_st_set_conflicts_enc_str_1, maxwell_tex0_surface_st_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_st_set_conflicts_enc_str_1},
    {MAXWELL_TEX1_SURFACE_ST_SET_CONFLICTS, maxwell_tex1_surface_st_set_conflicts_enc_str_1, maxwell_tex1_surface_st_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_st_set_conflicts_enc_str_1},
    {MAXWELL_TEX0_SURFACE_RED_SET_ACCESS, maxwell_tex0_surface_red_set_access_enc_str_1, maxwell_tex0_surface_red_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_red_set_access_enc_str_1},
    {MAXWELL_TEX1_SURFACE_RED_SET_ACCESS, maxwell_tex1_surface_red_set_access_enc_str_1, maxwell_tex1_surface_red_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_red_set_access_enc_str_1},
    {MAXWELL_TEX0_SURFACE_RED_SET_CONFLICTS, maxwell_tex0_surface_red_set_conflicts_enc_str_1, maxwell_tex0_surface_red_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_red_set_conflicts_enc_str_1},
    {MAXWELL_TEX1_SURFACE_RED_SET_CONFLICTS, maxwell_tex1_surface_red_set_conflicts_enc_str_1, maxwell_tex1_surface_red_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_red_set_conflicts_enc_str_1},
    {MAXWELL_TEX0_SURFACE_ATOM_SET_ACCESS, maxwell_tex0_surface_atom_set_access_enc_str_1, maxwell_tex0_surface_atom_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_atom_set_access_enc_str_1},
    {MAXWELL_TEX1_SURFACE_ATOM_SET_ACCESS, maxwell_tex1_surface_atom_set_access_enc_str_1, maxwell_tex1_surface_atom_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_atom_set_access_enc_str_1},
    {MAXWELL_TEX0_SURFACE_ATOM_CAS_SET_ACCESS, maxwell_tex0_surface_atom_cas_set_access_enc_str_1, maxwell_tex0_surface_atom_cas_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_atom_cas_set_access_enc_str_1},
    {MAXWELL_TEX1_SURFACE_ATOM_CAS_SET_ACCESS, maxwell_tex1_surface_atom_cas_set_access_enc_str_1, maxwell_tex1_surface_atom_cas_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_atom_cas_set_access_enc_str_1},
    {MAXWELL_TEX0_SURFACE_ATOM_SET_CONFLICTS, maxwell_tex0_surface_atom_set_conflicts_enc_str_1, maxwell_tex0_surface_atom_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_atom_set_conflicts_enc_str_1},
    {MAXWELL_TEX1_SURFACE_ATOM_SET_CONFLICTS, maxwell_tex1_surface_atom_set_conflicts_enc_str_1, maxwell_tex1_surface_atom_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_atom_set_conflicts_enc_str_1},
    {MAXWELL_TEX0_SURFACE_ATOM_CAS_SET_CONFLICTS, maxwell_tex0_surface_atom_cas_set_conflicts_enc_str_1, maxwell_tex0_surface_atom_cas_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_atom_cas_set_conflicts_enc_str_1},
    {MAXWELL_TEX1_SURFACE_ATOM_CAS_SET_CONFLICTS, maxwell_tex1_surface_atom_cas_set_conflicts_enc_str_1, maxwell_tex1_surface_atom_cas_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_atom_cas_set_conflicts_enc_str_1},
    {MAXWELL_TEX0_SURFACE_LD_REQUESTS, maxwell_tex0_surface_ld_requests_enc_str_1, maxwell_tex0_surface_ld_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_ld_requests_enc_str_1},
    {MAXWELL_TEX1_SURFACE_LD_REQUESTS, maxwell_tex1_surface_ld_requests_enc_str_1, maxwell_tex1_surface_ld_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_ld_requests_enc_str_1},
    {MAXWELL_TEX0_SURFACE_ST_REQUESTS, maxwell_tex0_surface_st_requests_enc_str_1, maxwell_tex0_surface_st_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_st_requests_enc_str_1},
    {MAXWELL_TEX1_SURFACE_ST_REQUESTS, maxwell_tex1_surface_st_requests_enc_str_1, maxwell_tex1_surface_st_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_st_requests_enc_str_1},
    {MAXWELL_TEX0_SURFACE_RED_REQUESTS, maxwell_tex0_surface_red_requests_enc_str_1, maxwell_tex0_surface_red_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_red_requests_enc_str_1},
    {MAXWELL_TEX1_SURFACE_RED_REQUESTS, maxwell_tex1_surface_red_requests_enc_str_1, maxwell_tex1_surface_red_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_red_requests_enc_str_1},
    {MAXWELL_TEX0_SURFACE_ATOM_REQUESTS, maxwell_tex0_surface_atom_requests_enc_str_1, maxwell_tex0_surface_atom_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_atom_requests_enc_str_1},
    {MAXWELL_TEX1_SURFACE_ATOM_REQUESTS, maxwell_tex1_surface_atom_requests_enc_str_1, maxwell_tex1_surface_atom_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_atom_requests_enc_str_1},
    {MAXWELL_TEX0_SURFACE_ATOM_CAS_REQUESTS, maxwell_tex0_surface_atom_cas_requests_enc_str_1, maxwell_tex0_surface_atom_cas_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_atom_cas_requests_enc_str_1},
    {MAXWELL_TEX1_SURFACE_ATOM_CAS_REQUESTS, maxwell_tex1_surface_atom_cas_requests_enc_str_1, maxwell_tex1_surface_atom_cas_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_atom_cas_requests_enc_str_1},

    {MAXWELL_TEX0_GLOBAL_ATOM_ADDRESS_CONFLICTS, maxwell_tex0_global_atom_address_conflicts_enc_str_1, maxwell_tex0_global_atom_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_atom_address_conflicts_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_ATOM_CAS_ADDRESS_CONFLICTS, maxwell_tex0_global_atom_cas_address_conflicts_enc_str_1, maxwell_tex0_global_atom_cas_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_atom_cas_address_conflicts_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_RED_ADDRESS_CONFLICTS, maxwell_tex0_global_red_address_conflicts_enc_str_1, maxwell_tex0_global_red_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_red_address_conflicts_enc_str_1},
    {MAXWELL_TEX0_SURFACE_ATOM_ADDRESS_CONFLICTS, maxwell_tex0_surface_atom_address_conflicts_enc_str_1, maxwell_tex0_surface_atom_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_atom_address_conflicts_enc_str_1},
    {MAXWELL_TEX0_SURFACE_ATOM_CAS_ADDRESS_CONFLICTS, maxwell_tex0_surface_atom_cas_address_conflicts_enc_str_1, maxwell_tex0_surface_atom_cas_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_atom_cas_address_conflicts_enc_str_1},
    {MAXWELL_TEX0_SURFACE_RED_ADDRESS_CONFLICTS, maxwell_tex0_surface_red_address_conflicts_enc_str_1, maxwell_tex0_surface_red_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_red_address_conflicts_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_ATOM_ADDRESS_CONFLICTS, maxwell_tex1_global_atom_address_conflicts_enc_str_1, maxwell_tex1_global_atom_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_atom_address_conflicts_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_ATOM_CAS_ADDRESS_CONFLICTS, maxwell_tex1_global_atom_cas_address_conflicts_enc_str_1, maxwell_tex1_global_atom_cas_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_atom_cas_address_conflicts_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_RED_ADDRESS_CONFLICTS, maxwell_tex1_global_red_address_conflicts_enc_str_1, maxwell_tex1_global_red_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_red_address_conflicts_enc_str_1},
    {MAXWELL_TEX1_SURFACE_ATOM_ADDRESS_CONFLICTS, maxwell_tex1_surface_atom_address_conflicts_enc_str_1, maxwell_tex1_surface_atom_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_atom_address_conflicts_enc_str_1},
    {MAXWELL_TEX1_SURFACE_ATOM_CAS_ADDRESS_CONFLICTS, maxwell_tex1_surface_atom_cas_address_conflicts_enc_str_1, maxwell_tex1_surface_atom_cas_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_atom_cas_address_conflicts_enc_str_1},
    {MAXWELL_TEX1_SURFACE_RED_ADDRESS_CONFLICTS, maxwell_tex1_surface_red_address_conflicts_enc_str_1, maxwell_tex1_surface_red_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_red_address_conflicts_enc_str_1},
    {MAXWELL_TEX0_GLOBAL_ST_HITS_IN_WARP, maxwell_tex0_global_st_hits_in_warp_enc_str_1, maxwell_tex0_global_st_hits_in_warp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_st_hits_in_warp_enc_str_1},
    {MAXWELL_TEX0_LOCAL_ST_HITS_IN_WARP, maxwell_tex0_local_st_hits_in_warp_enc_str_1, maxwell_tex0_local_st_hits_in_warp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_local_st_hits_in_warp_enc_str_1},
    {MAXWELL_TEX0_SURFACE_ST_HITS_IN_WARP, maxwell_tex0_surface_st_hits_in_warp_enc_str_1, maxwell_tex0_surface_st_hits_in_warp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_st_hits_in_warp_enc_str_1},
    {MAXWELL_TEX1_GLOBAL_ST_HITS_IN_WARP, maxwell_tex1_global_st_hits_in_warp_enc_str_1, maxwell_tex1_global_st_hits_in_warp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_st_hits_in_warp_enc_str_1},
    {MAXWELL_TEX1_LOCAL_ST_HITS_IN_WARP, maxwell_tex1_local_st_hits_in_warp_enc_str_1, maxwell_tex1_local_st_hits_in_warp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_local_st_hits_in_warp_enc_str_1},
    {MAXWELL_TEX1_SURFACE_ST_HITS_IN_WARP, maxwell_tex1_surface_st_hits_in_warp_enc_str_1, maxwell_tex1_surface_st_hits_in_warp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_st_hits_in_warp_enc_str_1},
    {MAXWELL_TEX0_SURFACE_LD_MISSES, maxwell_tex0_surface_ld_misses_enc_str_1, maxwell_tex0_surface_ld_misses_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_surface_ld_misses_enc_str_1},
    {MAXWELL_TEX1_SURFACE_LD_MISSES, maxwell_tex1_surface_ld_misses_enc_str_1, maxwell_tex1_surface_ld_misses_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_surface_ld_misses_enc_str_1},

    { MAXWELL_TEX0_UNCACHED_GLOBAL_LD_MISSES_32,  maxwell_tex0_uncached_global_ld_misses_32_enc_str_1, maxwell_tex0_uncached_global_ld_misses_32_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_uncached_global_ld_misses_32_enc_str_1},
    { MAXWELL_TEX0_UNCACHED_GLOBAL_LD_MISSES_64,  maxwell_tex0_uncached_global_ld_misses_64_enc_str_1, maxwell_tex0_uncached_global_ld_misses_64_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_uncached_global_ld_misses_64_enc_str_1},
    { MAXWELL_TEX0_UNCACHED_GLOBAL_LD_MISSES_128, maxwell_tex0_uncached_global_ld_misses_128_enc_str_1, maxwell_tex0_uncached_global_ld_misses_128_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_uncached_global_ld_misses_128_enc_str_1},
    { MAXWELL_TEX1_UNCACHED_GLOBAL_LD_MISSES_32,  maxwell_tex1_uncached_global_ld_misses_32_enc_str_1, maxwell_tex1_uncached_global_ld_misses_32_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_uncached_global_ld_misses_32_enc_str_1},
    { MAXWELL_TEX1_UNCACHED_GLOBAL_LD_MISSES_64,  maxwell_tex1_uncached_global_ld_misses_64_enc_str_1, maxwell_tex1_uncached_global_ld_misses_64_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_uncached_global_ld_misses_64_enc_str_1},
    { MAXWELL_TEX1_UNCACHED_GLOBAL_LD_MISSES_128, maxwell_tex1_uncached_global_ld_misses_128_enc_str_1, maxwell_tex1_uncached_global_ld_misses_128_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_uncached_global_ld_misses_128_enc_str_1},

    { MAXWELL_TEX0_UNCACHED_GLOBAL_LD_COALESCING_32,  maxwell_tex0_uncached_global_ld_coalescing_32_enc_str_1, maxwell_tex0_uncached_global_ld_coalescing_32_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_uncached_global_ld_coalescing_32_enc_str_1},
    { MAXWELL_TEX0_UNCACHED_GLOBAL_LD_COALESCING_64,  maxwell_tex0_uncached_global_ld_coalescing_64_enc_str_1, maxwell_tex0_uncached_global_ld_coalescing_64_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_uncached_global_ld_coalescing_64_enc_str_1},
    { MAXWELL_TEX0_UNCACHED_GLOBAL_LD_COALESCING_128, maxwell_tex0_uncached_global_ld_coalescing_128_enc_str_1, maxwell_tex0_uncached_global_ld_coalescing_128_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_uncached_global_ld_coalescing_128_enc_str_1},
    { MAXWELL_TEX1_UNCACHED_GLOBAL_LD_COALESCING_32,  maxwell_tex1_uncached_global_ld_coalescing_32_enc_str_1, maxwell_tex1_uncached_global_ld_coalescing_32_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_uncached_global_ld_coalescing_32_enc_str_1},
    { MAXWELL_TEX1_UNCACHED_GLOBAL_LD_COALESCING_64,  maxwell_tex1_uncached_global_ld_coalescing_64_enc_str_1, maxwell_tex1_uncached_global_ld_coalescing_64_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_uncached_global_ld_coalescing_64_enc_str_1},
    { MAXWELL_TEX1_UNCACHED_GLOBAL_LD_COALESCING_128, maxwell_tex1_uncached_global_ld_coalescing_128_enc_str_1, maxwell_tex1_uncached_global_ld_coalescing_128_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_uncached_global_ld_coalescing_128_enc_str_1},

#if CU_MAXWELL_PROFILE_SM_SIGNALS_VIA_HWPM
    {MAXWELL_HWPM_CTA_LAUNCHED, maxwell_hwpm_cta_launched_enc_str_1, maxwell_hwpm_cta_launched_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_cta_launched_enc_str_4},
    {MAXWELL_HWPM_THREADS_LAUNCHED_0, maxwell_hwpm_threads_launched_0_enc_str_1, maxwell_hwpm_threads_launched_0_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_threads_launched_0_enc_str_4},
    {MAXWELL_HWPM_THREADS_LAUNCHED_1, maxwell_hwpm_threads_launched_1_enc_str_1, maxwell_hwpm_threads_launched_1_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_threads_launched_1_enc_str_4},
    {MAXWELL_HWPM_THREADS_LAUNCHED_2, maxwell_hwpm_threads_launched_2_enc_str_1, maxwell_hwpm_threads_launched_2_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_threads_launched_2_enc_str_4},
    {MAXWELL_HWPM_THREADS_LAUNCHED_3, maxwell_hwpm_threads_launched_3_enc_str_1, maxwell_hwpm_threads_launched_3_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_threads_launched_3_enc_str_4},
    {MAXWELL_HWPM_WARPS_LAUNCHED_0, maxwell_hwpm_warps_launched_0_enc_str_1, maxwell_hwpm_warps_launched_0_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_warps_launched_0_enc_str_4},
    {MAXWELL_HWPM_WARPS_LAUNCHED_1, maxwell_hwpm_warps_launched_1_enc_str_1, maxwell_hwpm_warps_launched_1_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_warps_launched_1_enc_str_4},
    {MAXWELL_HWPM_WARPS_LAUNCHED_2, maxwell_hwpm_warps_launched_2_enc_str_1, maxwell_hwpm_warps_launched_2_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_warps_launched_2_enc_str_4},
    {MAXWELL_HWPM_WARPS_LAUNCHED_3, maxwell_hwpm_warps_launched_3_enc_str_1, maxwell_hwpm_warps_launched_3_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_warps_launched_3_enc_str_4},
    {MAXWELL_HWPM_ACTIVE_CYCLES, maxwell_hwpm_active_cycles_enc_str_1, maxwell_hwpm_active_cycles_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_active_cycles_enc_str_4},
    {MAXWELL_HWPM_ACTIVE_WARPS, maxwell_hwpm_active_warps_enc_str_1, maxwell_hwpm_active_warps_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_active_warps_enc_str_4},
    {MAXWELL_HWPM_SHARED_LD_MEM_DIVERGENCE_REPLAYS, maxwell_hwpm_shared_ld_mem_divergence_replays_enc_str_1, maxwell_hwpm_shared_ld_mem_divergence_replays_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_hwpm_shared_ld_mem_divergence_replays_enc_str_1},
    {MAXWELL_HWPM_SHARED_ST_MEM_DIVERGENCE_REPLAYS, maxwell_hwpm_shared_st_mem_divergence_replays_enc_str_1, maxwell_hwpm_shared_st_mem_divergence_replays_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_hwpm_shared_st_mem_divergence_replays_enc_str_1},
    {MAXWELL_HWPM_SHARED_LD_TRANSACTIONS,           maxwell_hwpm_shared_ld_transactions_enc_str_1,           maxwell_hwpm_shared_ld_transactions_enc_str_1,           CUPROF_EVENT_CATEGORY_MEMORY, maxwell_hwpm_shared_ld_transactions_enc_str_1},
    {MAXWELL_HWPM_SHARED_ST_TRANSACTIONS,           maxwell_hwpm_shared_st_transactions_enc_str_1,           maxwell_hwpm_shared_st_transactions_enc_str_1,           CUPROF_EVENT_CATEGORY_MEMORY, maxwell_hwpm_shared_st_transactions_enc_str_1},

    {MAXWELL_HWPMMUX_CTA_LAUNCHED, maxwell_hwpmmux_cta_launched_enc_str_1, maxwell_hwpmmux_cta_launched_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_cta_launched_enc_str_4},
    {MAXWELL_HWPMMUX_THREADS_LAUNCHED, maxwell_hwpmmux_threads_launched_enc_str_1, maxwell_hwpmmux_threads_launched_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_threads_launched_0_enc_str_4},
    {MAXWELL_HWPMMUX_WARPS_LAUNCHED, maxwell_hwpmmux_warps_launched_enc_str_1, maxwell_hwpmmux_warps_launched_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_warps_launched_0_enc_str_4},
    {MAXWELL_HWPMMUX_ACTIVE_CYCLES, maxwell_hwpmmux_active_cycles_enc_str_1, maxwell_hwpmmux_active_cycles_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_active_cycles_enc_str_4},
    {MAXWELL_HWPMMUX_ACTIVE_WARPS, maxwell_hwpmmux_active_warps_enc_str_1, maxwell_hwpmmux_active_warps_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_active_warps_enc_str_4},
    {MAXWELL_HWPMMUX_SHARED_LD_MEM_DIVERGENCE_REPLAYS, maxwell_hwpmmux_shared_ld_mem_divergence_replays_enc_str_1, maxwell_hwpmmux_shared_ld_mem_divergence_replays_enc_str_3, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_hwpm_shared_ld_mem_divergence_replays_enc_str_1},
    {MAXWELL_HWPMMUX_SHARED_ST_MEM_DIVERGENCE_REPLAYS, maxwell_hwpmmux_shared_st_mem_divergence_replays_enc_str_1, maxwell_hwpmmux_shared_st_mem_divergence_replays_enc_str_3, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_hwpm_shared_st_mem_divergence_replays_enc_str_1},
    {MAXWELL_HWPMMUX_SHARED_LD_TRANSACTIONS,           maxwell_hwpmmux_shared_ld_transactions_enc_str_1,           maxwell_hwpmmux_shared_ld_transactions_enc_str_3,           CUPROF_EVENT_CATEGORY_MEMORY, maxwell_hwpm_shared_ld_transactions_enc_str_1},
    {MAXWELL_HWPMMUX_SHARED_ST_TRANSACTIONS,           maxwell_hwpmmux_shared_st_transactions_enc_str_1,           maxwell_hwpmmux_shared_st_transactions_enc_str_3,           CUPROF_EVENT_CATEGORY_MEMORY, maxwell_hwpm_shared_st_transactions_enc_str_1},
#endif
    { MAXWELL_SMQCTL_INST_EXECUTED_FP16G0_PIPE, maxwell_smqctl_inst_executed_fp16g0_pipe_enc_str_1, maxwell_smqctl_inst_executed_fp16g0_pipe_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_smqctl_inst_executed_fp16g0_pipe_enc_str_2 },
    { MAXWELL_SMQCTL_INST_EXECUTED_FP16G1_PIPE, maxwell_smqctl_inst_executed_fp16g1_pipe_enc_str_1, maxwell_smqctl_inst_executed_fp16g1_pipe_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_smqctl_inst_executed_fp16g1_pipe_enc_str_2 },
    { MAXWELL_SMQCTL_INST_EXECUTED_FP16G0_PIPE_HIGHPOWER, maxwell_smqctl_inst_executed_fp16g0_pipe_highpower_enc_str_1, maxwell_smqctl_inst_executed_fp16g0_pipe_highpower_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_smqctl_inst_executed_fp16g0_pipe_highpower_enc_str_2 },
    { MAXWELL_SMQCTL_INST_EXECUTED_FP16G1_PIPE_HIGHPOWER, maxwell_smqctl_inst_executed_fp16g1_pipe_highpower_enc_str_1, maxwell_smqctl_inst_executed_fp16g1_pipe_highpower_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_smqctl_inst_executed_fp16g1_pipe_highpower_enc_str_2 },
    { MAXWELL_SMQCTL_INST_FP16G0_PIPE_UNIFORM_DATA_QUAD_Q, maxwell_smqctl_inst_fp16g0_pipe_uniform_data_quad_q_enc_str_1, maxwell_smqctl_inst_fp16g0_pipe_uniform_data_quad_q_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_smqctl_inst_fp16g0_pipe_uniform_data_quad_q_enc_str_2 },
    { MAXWELL_SMQCTL_INST_FP16G1_PIPE_UNIFORM_DATA_QUAD_Q, maxwell_smqctl_inst_fp16g1_pipe_uniform_data_quad_q_enc_str_1, maxwell_smqctl_inst_fp16g1_pipe_uniform_data_quad_q_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_smqctl_inst_fp16g1_pipe_uniform_data_quad_q_enc_str_1 },

    {MAXWELL_HWPM_INST_EXECUTED_TEX_OPS_Q0, maxwell_hwpm_inst_executed_tex_ops_q0_enc_str_1, maxwell_hwpm_inst_executed_tex_ops_q0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_inst_executed_tex_ops_q0_enc_str_1},
    {MAXWELL_HWPM_INST_EXECUTED_TEX_OPS_Q1, maxwell_hwpm_inst_executed_tex_ops_q1_enc_str_1, maxwell_hwpm_inst_executed_tex_ops_q1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_inst_executed_tex_ops_q1_enc_str_1},
    {MAXWELL_HWPM_INST_EXECUTED_TEX_OPS_Q2, maxwell_hwpm_inst_executed_tex_ops_q2_enc_str_1, maxwell_hwpm_inst_executed_tex_ops_q2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_inst_executed_tex_ops_q2_enc_str_1},
    {MAXWELL_HWPM_INST_EXECUTED_TEX_OPS_Q3, maxwell_hwpm_inst_executed_tex_ops_q3_enc_str_1, maxwell_hwpm_inst_executed_tex_ops_q3_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_inst_executed_tex_ops_q3_enc_str_1},

    {MAXWELL_FB_SUBP0_DRAMC_READ, maxwell_fb_subp0_dramc_read_enc_str_1, maxwell_fb_subp0_dramc_read_enc_str_3, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_fb1_subp0_dramc_read_enc_str_3},
    {MAXWELL_FB_SUBP1_DRAMC_READ, maxwell_fb_subp1_dramc_read_enc_str_1, maxwell_fb_subp1_dramc_read_enc_str_3, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_fb1_subp1_dramc_read_enc_str_3},
    {MAXWELL_FB_SUBP0_DRAMC_WRITE, maxwell_fb_subp0_dramc_write_enc_str_1, maxwell_fb_subp0_dramc_write_enc_str_3, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_fb1_subp0_dramc_write_enc_str_3},
    {MAXWELL_FB_SUBP1_DRAMC_WRITE, maxwell_fb_subp1_dramc_write_enc_str_1, maxwell_fb_subp1_dramc_write_enc_str_3, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_fb1_subp1_dramc_write_enc_str_3},

    {MAXWELL_LTC0_WRITE_MISS_SECTORS, maxwell_ltc0_write_miss_sectors_enc_str_1, maxwell_ltc0_write_miss_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_write_miss_sectors_enc_str_4},
    {MAXWELL_LTC1_WRITE_MISS_SECTORS, maxwell_ltc1_write_miss_sectors_enc_str_1, maxwell_ltc1_write_miss_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc1_write_miss_sectors_enc_str_4},
    {MAXWELL_LTC2_WRITE_MISS_SECTORS, maxwell_ltc2_write_miss_sectors_enc_str_1, maxwell_ltc2_write_miss_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc2_write_miss_sectors_enc_str_4},
    {MAXWELL_LTC3_WRITE_MISS_SECTORS, maxwell_ltc3_write_miss_sectors_enc_str_1, maxwell_ltc3_write_miss_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc3_write_miss_sectors_enc_str_4},
    {MAXWELL_LTC0_READ_MISS_SECTORS, maxwell_ltc0_read_miss_sectors_enc_str_1, maxwell_ltc0_read_miss_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_read_miss_sectors_enc_str_4},
    {MAXWELL_LTC1_READ_MISS_SECTORS, maxwell_ltc1_read_miss_sectors_enc_str_1, maxwell_ltc1_read_miss_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc1_read_miss_sectors_enc_str_4},
    {MAXWELL_LTC2_READ_MISS_SECTORS, maxwell_ltc2_read_miss_sectors_enc_str_1, maxwell_ltc2_read_miss_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc2_read_miss_sectors_enc_str_4},
    {MAXWELL_LTC3_READ_MISS_SECTORS, maxwell_ltc3_read_miss_sectors_enc_str_1, maxwell_ltc3_read_miss_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc3_read_miss_sectors_enc_str_4},

    {MAXWELL_LTC0_READ_TEX_SECTORS_FBP, maxwell_ltc0_read_tex_sectors_fbp_enc_str_1, maxwell_ltc0_read_tex_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_read_tex_sectors_fbp_enc_str_4},
    {MAXWELL_LTC1_READ_TEX_SECTORS_FBP, maxwell_ltc1_read_tex_sectors_fbp_enc_str_1, maxwell_ltc1_read_tex_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc1_read_tex_sectors_fbp_enc_str_4},
    {MAXWELL_LTC2_READ_TEX_SECTORS_FBP, maxwell_ltc2_read_tex_sectors_fbp_enc_str_1, maxwell_ltc2_read_tex_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc2_read_tex_sectors_fbp_enc_str_4},
    {MAXWELL_LTC3_READ_TEX_SECTORS_FBP, maxwell_ltc3_read_tex_sectors_fbp_enc_str_1, maxwell_ltc3_read_tex_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc3_read_tex_sectors_fbp_enc_str_4},

    {MAXWELL_LTC0_WRITE_TEX_SECTORS_FBP, maxwell_ltc0_write_tex_sectors_fbp_enc_str_1, maxwell_ltc0_write_tex_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_write_tex_sectors_fbp_enc_str_4},
    {MAXWELL_LTC1_WRITE_TEX_SECTORS_FBP, maxwell_ltc1_write_tex_sectors_fbp_enc_str_1, maxwell_ltc1_write_tex_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc1_write_tex_sectors_fbp_enc_str_4},
    {MAXWELL_LTC2_WRITE_TEX_SECTORS_FBP, maxwell_ltc2_write_tex_sectors_fbp_enc_str_1, maxwell_ltc2_write_tex_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc2_write_tex_sectors_fbp_enc_str_4},
    {MAXWELL_LTC3_WRITE_TEX_SECTORS_FBP, maxwell_ltc3_write_tex_sectors_fbp_enc_str_1, maxwell_ltc3_write_tex_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc3_write_tex_sectors_fbp_enc_str_4},

    {MAXWELL_LTC0_READ_TEX_HIT_SECTORS_FBP, maxwell_ltc0_read_tex_hit_sectors_fbp_enc_str_1, maxwell_ltc0_read_tex_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_read_tex_hit_sectors_fbp_enc_str_4},
    {MAXWELL_LTC1_READ_TEX_HIT_SECTORS_FBP, maxwell_ltc1_read_tex_hit_sectors_fbp_enc_str_1, maxwell_ltc1_read_tex_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc1_read_tex_hit_sectors_fbp_enc_str_4},
    {MAXWELL_LTC2_READ_TEX_HIT_SECTORS_FBP, maxwell_ltc2_read_tex_hit_sectors_fbp_enc_str_1, maxwell_ltc2_read_tex_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc2_read_tex_hit_sectors_fbp_enc_str_4},
    {MAXWELL_LTC3_READ_TEX_HIT_SECTORS_FBP, maxwell_ltc3_read_tex_hit_sectors_fbp_enc_str_1, maxwell_ltc3_read_tex_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc3_read_tex_hit_sectors_fbp_enc_str_4},

    {MAXWELL_LTC0_WRITE_TEX_HIT_SECTORS_FBP, maxwell_ltc0_write_tex_hit_sectors_fbp_enc_str_1, maxwell_ltc0_write_tex_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_write_tex_hit_sectors_fbp_enc_str_4},
    {MAXWELL_LTC1_WRITE_TEX_HIT_SECTORS_FBP, maxwell_ltc1_write_tex_hit_sectors_fbp_enc_str_1, maxwell_ltc1_write_tex_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc1_write_tex_hit_sectors_fbp_enc_str_4},
    {MAXWELL_LTC2_WRITE_TEX_HIT_SECTORS_FBP, maxwell_ltc2_write_tex_hit_sectors_fbp_enc_str_1, maxwell_ltc2_write_tex_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc2_write_tex_hit_sectors_fbp_enc_str_4},
    {MAXWELL_LTC3_WRITE_TEX_HIT_SECTORS_FBP, maxwell_ltc3_write_tex_hit_sectors_fbp_enc_str_1, maxwell_ltc3_write_tex_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc3_write_tex_hit_sectors_fbp_enc_str_4},

    // ltc_read_sysmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_sysmem
    { MAXWELL_LTC0_READ_SYSMEM_SECTORS_FBP,      maxwell_ltc0_read_sysmem_sectors_fbp_enc_str_1, maxwell_ltc0_read_sysmem_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_read_sysmem_sectors_fbp_enc_str_4},
    { MAXWELL_LTC1_READ_SYSMEM_SECTORS_FBP,      maxwell_ltc1_read_sysmem_sectors_fbp_enc_str_1, maxwell_ltc1_read_sysmem_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc1_read_sysmem_sectors_fbp_enc_str_4},
    { MAXWELL_LTC2_READ_SYSMEM_SECTORS_FBP,      maxwell_ltc2_read_sysmem_sectors_fbp_enc_str_1, maxwell_ltc2_read_sysmem_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc2_read_sysmem_sectors_fbp_enc_str_4},
    { MAXWELL_LTC3_READ_SYSMEM_SECTORS_FBP,      maxwell_ltc3_read_sysmem_sectors_fbp_enc_str_1, maxwell_ltc3_read_sysmem_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc3_read_sysmem_sectors_fbp_enc_str_4},

    // ltc_write_sysmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_sysmem
    { MAXWELL_LTC0_WRITE_SYSMEM_SECTORS_FBP,      maxwell_ltc0_write_sysmem_sectors_fbp_enc_str_1, maxwell_ltc0_write_sysmem_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_write_sysmem_sectors_fbp_enc_str_4},
    { MAXWELL_LTC1_WRITE_SYSMEM_SECTORS_FBP,      maxwell_ltc1_write_sysmem_sectors_fbp_enc_str_1, maxwell_ltc1_write_sysmem_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc1_write_sysmem_sectors_fbp_enc_str_4},
    { MAXWELL_LTC2_WRITE_SYSMEM_SECTORS_FBP,      maxwell_ltc2_write_sysmem_sectors_fbp_enc_str_1, maxwell_ltc2_write_sysmem_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc2_write_sysmem_sectors_fbp_enc_str_4},
    { MAXWELL_LTC3_WRITE_SYSMEM_SECTORS_FBP,      maxwell_ltc3_write_sysmem_sectors_fbp_enc_str_1, maxwell_ltc3_write_sysmem_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc3_write_sysmem_sectors_fbp_enc_str_4},

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { MAXWELL_LTC0_TOTAL_READ_SECTORS_FBP,      maxwell_ltc0_total_read_sectors_fbp_enc_str_1, maxwell_ltc0_total_read_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_total_read_sectors_fbp_enc_str_4},
    { MAXWELL_LTC1_TOTAL_READ_SECTORS_FBP,      maxwell_ltc1_total_read_sectors_fbp_enc_str_1, maxwell_ltc1_total_read_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc1_total_read_sectors_fbp_enc_str_4},
    { MAXWELL_LTC2_TOTAL_READ_SECTORS_FBP,      maxwell_ltc2_total_read_sectors_fbp_enc_str_1, maxwell_ltc2_total_read_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc2_total_read_sectors_fbp_enc_str_4},
    { MAXWELL_LTC3_TOTAL_READ_SECTORS_FBP,      maxwell_ltc3_total_read_sectors_fbp_enc_str_1, maxwell_ltc3_total_read_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc3_total_read_sectors_fbp_enc_str_4},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { MAXWELL_LTC0_TOTAL_WRITE_SECTORS_FBP,      maxwell_ltc0_total_write_sectors_fbp_enc_str_1, maxwell_ltc0_total_write_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_total_write_sectors_fbp_enc_str_4},
    { MAXWELL_LTC1_TOTAL_WRITE_SECTORS_FBP,      maxwell_ltc1_total_write_sectors_fbp_enc_str_1, maxwell_ltc1_total_write_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc1_total_write_sectors_fbp_enc_str_4},
    { MAXWELL_LTC2_TOTAL_WRITE_SECTORS_FBP,      maxwell_ltc2_total_write_sectors_fbp_enc_str_1, maxwell_ltc2_total_write_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc2_total_write_sectors_fbp_enc_str_4},
    { MAXWELL_LTC3_TOTAL_WRITE_SECTORS_FBP,      maxwell_ltc3_total_write_sectors_fbp_enc_str_1, maxwell_ltc3_total_write_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc3_total_write_sectors_fbp_enc_str_4},

    {MAXWELL_MMU_HUB_TLB_HIT, maxwell_mmu_hub_tlb_hit_enc_str_1, maxwell_mmu_hub_tlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_mmu_hub_tlb_hit_enc_str_4},
    {MAXWELL_MMU_HUB_TLB_MISS, maxwell_mmu_hub_tlb_miss_enc_str_1, maxwell_mmu_hub_tlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_mmu_hub_tlb_miss_enc_str_4},
    {MAXWELL_MMU_HUB_TLB_MISS_INT, maxwell_mmu_hub_tlb_miss_int_enc_str_1, maxwell_mmu_hub_tlb_miss_int_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_mmu_fill_pte_miss_int_enc_str_4},
    {MAXWELL_MMU_FILL_PTE_HIT, maxwell_mmu_fill_pte_hit_enc_str_1, maxwell_mmu_fill_pte_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_mmu_fill_pte_hit_enc_str_4},
    {MAXWELL_MMU_FILL_PTE_MISS, maxwell_mmu_fill_pte_miss_enc_str_1, maxwell_mmu_fill_pte_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_mmu_fill_pte_miss_enc_str_4},
    {MAXWELL_MMU_FILL_PTE_MISS_INT, maxwell_mmu_fill_pte_miss_int_enc_str_1, maxwell_mmu_fill_pte_miss_int_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_mmu_fill_pte_miss_int_enc_str_4},
    {MAXWELL_MMU_FILL_PDE_HIT, maxwell_mmu_fill_pde_hit_enc_str_1, maxwell_mmu_fill_pde_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_mmu_fill_pde_hit_enc_str_4},
    {MAXWELL_MMU_FILL_PDE_MISS, maxwell_mmu_fill_pde_miss_enc_str_1, maxwell_mmu_fill_pde_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_mmu_fill_pde_miss_enc_str_4},

    {MAXWELL_FB_SUBP0_DRAM_ACTIVATES, maxwell_fb_subp0_dram_activates_enc_str_1, maxwell_fb_subp0_dram_activates_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_fb_subp0_dram_activates_enc_str_4},
    {MAXWELL_FB_SUBP1_DRAM_ACTIVATES, maxwell_fb_subp1_dram_activates_enc_str_1, maxwell_fb_subp1_dram_activates_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_fb_subp1_dram_activates_enc_str_4},

    // Software counters to count ld/st instructions
    {MAXWELL_SW_COUNTER_GLD8BIT_INST, maxwell_sw_counter_gld8bit_inst_enc_str_1, maxwell_sw_counter_gld8bit_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_MEMORY, maxwell_sw_counter_gld8bit_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_GLD16BIT_INST, maxwell_sw_counter_gld16bit_inst_enc_str_1, maxwell_sw_counter_gld16bit_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_MEMORY, maxwell_sw_counter_gld16bit_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_GLD32BIT_INST, maxwell_sw_counter_gld32bit_inst_enc_str_1, maxwell_sw_counter_gld32bit_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_gld32bit_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_GLD64BIT_INST, maxwell_sw_counter_gld64bit_inst_enc_str_1, maxwell_sw_counter_gld64bit_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_MEMORY, maxwell_sw_counter_gld64bit_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_GLD128BIT_INST, maxwell_sw_counter_gld128bit_inst_enc_str_1, maxwell_sw_counter_gld128bit_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_MEMORY, maxwell_sw_counter_gld128bit_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_GST8BIT_INST, maxwell_sw_counter_gst8bit_inst_enc_str_1, maxwell_sw_counter_gst8bit_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_MEMORY, maxwell_sw_counter_gst8bit_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_GST16BIT_INST, maxwell_sw_counter_gst16bit_inst_enc_str_1, maxwell_sw_counter_gst16bit_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_MEMORY, maxwell_sw_counter_gst16bit_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_GST32BIT_INST, maxwell_sw_counter_gst32bit_inst_enc_str_1, maxwell_sw_counter_gst32bit_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_gst32bit_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_GST64BIT_INST, maxwell_sw_counter_gst64bit_inst_enc_str_1, maxwell_sw_counter_gst64bit_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_gld64bit_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_GST128BIT_INST, maxwell_sw_counter_gst128bit_inst_enc_str_1, maxwell_sw_counter_gst128bit_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_gld128bit_inst_enc_str_4},

    // Software counters to count shared load/store instructions
    {MAXWELL_SW_COUNTER_SLD8BIT_INST,maxwell_sw_counter_sld8bit_inst_enc_str_1, maxwell_sw_counter_sld8bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,maxwell_sw_counter_sld8bit_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_SLD16BIT_INST,maxwell_sw_counter_sld16bit_inst_enc_str_1, maxwell_sw_counter_sld16bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,maxwell_sw_counter_sld16bit_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_SLD32BIT_INST,maxwell_sw_counter_sld32bit_inst_enc_str_1, maxwell_sw_counter_sld32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,maxwell_sw_counter_sld32bit_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_SLD64BIT_INST,maxwell_sw_counter_sld64bit_inst_enc_str_1, maxwell_sw_counter_sld64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,maxwell_sw_counter_sld64bit_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_SLD128BIT_INST,maxwell_sw_counter_sld128bit_inst_enc_str_1, maxwell_sw_counter_sld128bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,maxwell_sw_counter_sld128bit_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_SST8BIT_INST,maxwell_sw_counter_sst8bit_inst_enc_str_1, maxwell_sw_counter_sst8bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,maxwell_sw_counter_sst8bit_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_SST16BIT_INST,maxwell_sw_counter_sst16bit_inst_enc_str_1, maxwell_sw_counter_sst16bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,maxwell_sw_counter_sst16bit_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_SST32BIT_INST,maxwell_sw_counter_sst32bit_inst_enc_str_1, maxwell_sw_counter_sst32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,maxwell_sw_counter_sst32bit_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_SST64BIT_INST,maxwell_sw_counter_sst64bit_inst_enc_str_1, maxwell_sw_counter_sst64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,maxwell_sw_counter_sst64bit_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_SST128BIT_INST,maxwell_sw_counter_sst128bit_inst_enc_str_1, maxwell_sw_counter_sst128bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,maxwell_sw_counter_sst128bit_inst_enc_str_4},

    // Software counters to count unique global load/store instructions
    {MAXWELL_SW_COUNTER_UNIQUE_GLD1BYTE_REQUESTED,maxwell_sw_counter_unique_gld_1byte_requested_enc_str_1, maxwell_sw_counter_unique_gld_1byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,maxwell_sw_counter_unique_gld_1byte_requested_enc_str_4},
    {MAXWELL_SW_COUNTER_UNIQUE_GLD4BYTE_REQUESTED,maxwell_sw_counter_unique_gld_4byte_requested_enc_str_1, maxwell_sw_counter_unique_gld_4byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,maxwell_sw_counter_unique_gld_4byte_requested_enc_str_4},
    {MAXWELL_SW_COUNTER_UNIQUE_GLD8BYTE_REQUESTED,maxwell_sw_counter_unique_gld_8byte_requested_enc_str_1, maxwell_sw_counter_unique_gld_8byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,maxwell_sw_counter_unique_gld_8byte_requested_enc_str_4},
    {MAXWELL_SW_COUNTER_UNIQUE_GLD16BYTE_REQUESTED,maxwell_sw_counter_unique_gld_16byte_requested_enc_str_1, maxwell_sw_counter_unique_gld_16byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,maxwell_sw_counter_unique_gld_16byte_requested_enc_str_4},
    {MAXWELL_SW_COUNTER_UNIQUE_GST1BYTE_REQUESTED,maxwell_sw_counter_unique_gst_1byte_requested_enc_str_1, maxwell_sw_counter_unique_gst_1byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,maxwell_sw_counter_unique_gst_1byte_requested_enc_str_4},
    {MAXWELL_SW_COUNTER_UNIQUE_GST4BYTE_REQUESTED,maxwell_sw_counter_unique_gst_4byte_requested_enc_str_1, maxwell_sw_counter_unique_gst_4byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,maxwell_sw_counter_unique_gst_4byte_requested_enc_str_4},
    {MAXWELL_SW_COUNTER_UNIQUE_GST8BYTE_REQUESTED,maxwell_sw_counter_unique_gst_8byte_requested_enc_str_1, maxwell_sw_counter_unique_gst_8byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,maxwell_sw_counter_unique_gst_8byte_requested_enc_str_4},
    {MAXWELL_SW_COUNTER_UNIQUE_GST16BYTE_REQUESTED,maxwell_sw_counter_unique_gst_16byte_requested_enc_str_1, maxwell_sw_counter_unique_gst_16byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,maxwell_sw_counter_unique_gst_16byte_requested_enc_str_4},
    {MAXWELL_SW_COUNTER_UNIQUE_SECTOR_ACCESS_GLD,maxwell_sw_counter_unique_sector_access_gld_enc_str_1, maxwell_sw_counter_unique_sector_access_gld_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,maxwell_sw_counter_unique_sector_access_gld_enc_str_4},

    // Software counters to count floating point instructions
    {MAXWELL_SW_COUNTER_FADD_INST, maxwell_sw_counter_fadd_inst_enc_str_1, maxwell_sw_counter_fadd_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_fadd_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_FMUL_INST, maxwell_sw_counter_fmul_inst_enc_str_1, maxwell_sw_counter_fmul_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_fmul_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_FFMA_INST, maxwell_sw_counter_ffma_inst_enc_str_1, maxwell_sw_counter_ffma_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_ffma_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_DADD_INST, maxwell_sw_counter_dadd_inst_enc_str_1, maxwell_sw_counter_dadd_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_dadd_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_DMUL_INST, maxwell_sw_counter_dmul_inst_enc_str_1, maxwell_sw_counter_dmul_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_dmul_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_DFMA_INST, maxwell_sw_counter_dfma_inst_enc_str_1, maxwell_sw_counter_dfma_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_dfma_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_COS_INST, maxwell_sw_counter_cos_inst_enc_str_1, maxwell_sw_counter_cos_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_cos_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_EX2_INST, maxwell_sw_counter_ex2_inst_enc_str_1, maxwell_sw_counter_ex2_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_ex2_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_LG2_INST, maxwell_sw_counter_lg2_inst_enc_str_1, maxwell_sw_counter_lg2_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_lg2_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_RCP_INST, maxwell_sw_counter_rcp_inst_enc_str_1, maxwell_sw_counter_rcp_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_rcp_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_RSQ_INST, maxwell_sw_counter_rsq_inst_enc_str_1, maxwell_sw_counter_rsq_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_rsq_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_SIN_INST, maxwell_sw_counter_sin_inst_enc_str_1, maxwell_sw_counter_sin_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_sin_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_SQRT_INST, maxwell_sw_counter_sqrt_inst_enc_str_1, maxwell_sw_counter_sqrt_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_sqrt_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_HADD_INST, maxwell_sw_counter_hadd_inst_enc_str_1, maxwell_sw_counter_hadd_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_hadd_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_HMUL_INST, maxwell_sw_counter_hmul_inst_enc_str_1, maxwell_sw_counter_hmul_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_hmul_inst_enc_str_4},
    {MAXWELL_SW_COUNTER_HFMA_INST, maxwell_sw_counter_hfma_inst_enc_str_1, maxwell_sw_counter_hfma_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_hfma_inst_enc_str_4},

    // Software counters to count the number of instructions executed from a particular instruction class:
    // Software counters to count the number of instructions executed from a particular instruction class:
    { MAXWELL_SW_COUNTER_INSTR_CLASS_FP_32,                       maxwell_sw_counter_instr_class_fp_32_enc_str_1                      , maxwell_sw_counter_instr_class_fp_32_enc_str_1                      , CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_instr_class_fp_32_enc_str_4},
    { MAXWELL_SW_COUNTER_INSTR_CLASS_FP_64,                       maxwell_sw_counter_instr_class_fp_64_enc_str_1                      , maxwell_sw_counter_instr_class_fp_64_enc_str_1                      , CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_instr_class_fp_64_enc_str_4},
    { MAXWELL_SW_COUNTER_INSTR_CLASS_INTEGER,                     maxwell_sw_counter_instr_class_integer_enc_str_1                    , maxwell_sw_counter_instr_class_integer_enc_str_1                    , CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_instr_class_integer_enc_str_4},
    { MAXWELL_SW_COUNTER_INSTR_CLASS_BIT_CONVERT,                 maxwell_sw_counter_instr_class_bit_convert_enc_str_1                , maxwell_sw_counter_instr_class_bit_convert_enc_str_1                , CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_instr_class_bit_convert_enc_str_4},
    { MAXWELL_SW_COUNTER_INSTR_CLASS_CONTROL,                     maxwell_sw_counter_instr_class_control_enc_str_1                    , maxwell_sw_counter_instr_class_control_enc_str_1                    , CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_instr_class_control_enc_str_4},
    { MAXWELL_SW_COUNTER_INSTR_CLASS_COMPUTE_LD_ST,               maxwell_sw_counter_instr_class_compute_ld_st_enc_str_1              , maxwell_sw_counter_instr_class_compute_ld_st_enc_str_1              , CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_instr_class_compute_ld_st_enc_str_4},
    { MAXWELL_SW_COUNTER_INSTR_CLASS_MISCELLANEOUS,               maxwell_sw_counter_instr_class_miscellaneous_enc_str_1              , maxwell_sw_counter_instr_class_miscellaneous_enc_str_1              , CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_instr_class_miscellaneous_enc_str_4},
    { MAXWELL_SW_COUNTER_INSTR_CLASS_INTER_THREAD_COMMUNICATION,  maxwell_sw_counter_instr_class_inter_thread_communication_enc_str_1 , maxwell_sw_counter_instr_class_inter_thread_communication_enc_str_1 , CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_instr_class_inter_thread_communication_enc_str_4},
    { MAXWELL_SW_COUNTER_INSTR_CLASS_FP_16,                       maxwell_sw_counter_instr_class_fp_16_enc_str_1                      , maxwell_sw_counter_instr_class_fp_16_enc_str_1                      , CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_instr_class_fp_16_enc_str_4},

    // Software counters to count the different load/stores from the generic accesses
    { MAXWELL_SW_COUNTER_GENERIC_SHARED_LOAD,                maxwell_sw_counter_generic_shared_ld_enc_str_1               , maxwell_sw_counter_generic_shared_ld_enc_str_1               , CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_generic_shared_ld_enc_str_4},
    { MAXWELL_SW_COUNTER_GENERIC_SHARED_STORE,               maxwell_sw_counter_generic_shared_st_enc_str_1               , maxwell_sw_counter_generic_shared_st_enc_str_1               , CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_generic_shared_ld_enc_str_4},
    { MAXWELL_SW_COUNTER_GENERIC_LOCAL_LOAD,                 maxwell_sw_counter_generic_local_ld_enc_str_1                , maxwell_sw_counter_generic_local_ld_enc_str_1                , CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_generic_local_ld_enc_str_4},
    { MAXWELL_SW_COUNTER_GENERIC_LOCAL_STORE,                maxwell_sw_counter_generic_local_st_enc_str_1                , maxwell_sw_counter_generic_local_st_enc_str_1                , CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_generic_local_ld_enc_str_4},
    { MAXWELL_SW_COUNTER_GENERIC_GLOBAL_LOAD,                maxwell_sw_counter_generic_global_ld_enc_str_1               , maxwell_sw_counter_generic_global_ld_enc_str_1               , CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_generic_global_ld_enc_str_4},
    { MAXWELL_SW_COUNTER_GENERIC_GLOBAL_STORE,               maxwell_sw_counter_generic_global_st_enc_str_1               , maxwell_sw_counter_generic_global_st_enc_str_1               , CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_sw_counter_generic_global_ld_enc_str_4},

    // LDG signals
    { MAXWELL_LUT_COUNTER_GLD32BIT_INST,      maxwell_lut_counter_gld32bit_inst_enc_str_1,  maxwell_lut_counter_gld32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_gld32bit_inst_enc_str_4},
    { MAXWELL_LUT_COUNTER_GST32BIT_INST,      maxwell_lut_counter_gst32bit_inst_enc_str_1,  maxwell_lut_counter_gst32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_gst32bit_inst_enc_str_4},
    { MAXWELL_LUT_COUNTER_GLD64BIT_INST,      maxwell_lut_counter_gld64bit_inst_enc_str_1,  maxwell_lut_counter_gld64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_gld64bit_inst_enc_str_4},
    { MAXWELL_LUT_COUNTER_GST64BIT_INST,      maxwell_lut_counter_gst64bit_inst_enc_str_1,  maxwell_lut_counter_gst64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_gld64bit_inst_enc_str_4},
    { MAXWELL_LUT_COUNTER_GLD128BIT_INST,     maxwell_lut_counter_gld128bit_inst_enc_str_1, maxwell_lut_counter_gld128bit_inst_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_gld128bit_inst_enc_str_4},
    { MAXWELL_LUT_COUNTER_GST128BIT_INST,     maxwell_lut_counter_gst128bit_inst_enc_str_1, maxwell_lut_counter_gst128bit_inst_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_gld128bit_inst_enc_str_4},
    { MAXWELL_LUT_COUNTER_SHLD_32BIT_INST,    maxwell_lut_counter_shld_32bit_inst_enc_str_1,        maxwell_lut_counter_shld_32bit_inst_enc_str_1,        CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_shld_32bit_inst_enc_str_4 },
    { MAXWELL_LUT_COUNTER_SHLD_64BIT_INST,    maxwell_lut_counter_shld_64bit_inst_enc_str_1,        maxwell_lut_counter_shld_64bit_inst_enc_str_1,        CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_shld_64bit_inst_enc_str_4 },
    { MAXWELL_LUT_COUNTER_SHLD_128BIT_INST,   maxwell_lut_counter_shld_128bit_inst_enc_str_1,       maxwell_lut_counter_shld_128bit_inst_enc_str_1,       CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_shld_128bit_inst_enc_str_4 },
    { MAXWELL_LUT_COUNTER_SHLD_U128BIT_INST,  maxwell_lut_counter_shld_u128bit_inst_enc_str_1,     maxwell_lut_counter_shld_u128bit_inst_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_shld_u128bit_inst_enc_str_4 },
    { MAXWELL_LUT_COUNTER_SHST_32BIT_INST,    maxwell_lut_counter_shst_32bit_inst_enc_str_1,        maxwell_lut_counter_shst_32bit_inst_enc_str_1,        CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_shst_32bit_inst_enc_str_4 },
    { MAXWELL_LUT_COUNTER_SHST_64BIT_INST,    maxwell_lut_counter_shst_64bit_inst_enc_str_1,        maxwell_lut_counter_shst_64bit_inst_enc_str_1,        CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_shst_64bit_inst_enc_str_4 },
    { MAXWELL_LUT_COUNTER_SHST_128BIT_INST,   maxwell_lut_counter_shst_128bit_inst_enc_str_1,       maxwell_lut_counter_shst_128bit_inst_enc_str_1,       CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_shst_128bit_inst_enc_str_4 },

    { MAXWELL_LUT_COUNTER_GENERIC_SHARED_LD_INST,       maxwell_lut_counter_generic_shared_ld_inst_enc_str_1,      maxwell_lut_counter_generic_shared_ld_inst_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_generic_shared_ld_inst_enc_str_4},
    { MAXWELL_LUT_COUNTER_GENERIC_SHARED_ST_INST,       maxwell_lut_counter_generic_shared_st_inst_enc_str_1,      maxwell_lut_counter_generic_shared_st_inst_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_generic_shared_st_inst_enc_str_4},

    { MAXWELL_LUT_COUNTER_GENERIC_SHARED_LD_32BIT_INST, maxwell_lut_counter_generic_shared_ld_32bit_inst_enc_str_1,  maxwell_lut_counter_generic_shared_ld_32bit_inst_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_generic_shared_ld_32bit_inst_enc_str_4},
    { MAXWELL_LUT_COUNTER_GENERIC_SHARED_LD_64BIT_INST, maxwell_lut_counter_generic_shared_ld_64bit_inst_enc_str_1,  maxwell_lut_counter_generic_shared_ld_64bit_inst_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_generic_shared_ld_64bit_inst_enc_str_4},
    { MAXWELL_LUT_COUNTER_GENERIC_SHARED_LD_128BIT_INST, maxwell_lut_counter_generic_shared_ld_128bit_inst_enc_str_1, maxwell_lut_counter_generic_shared_ld_128bit_inst_enc_str_1,CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_generic_shared_ld_128bit_inst_enc_str_4},

    { MAXWELL_LUT_COUNTER_GENERIC_SHARED_ST_32BIT_INST, maxwell_lut_counter_generic_shared_st_32bit_inst_enc_str_1,  maxwell_lut_counter_generic_shared_st_32bit_inst_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_generic_shared_st_32bit_inst_enc_str_4},
    { MAXWELL_LUT_COUNTER_GENERIC_SHARED_ST_64BIT_INST, maxwell_lut_counter_generic_shared_st_64bit_inst_enc_str_1,  maxwell_lut_counter_generic_shared_st_64bit_inst_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_generic_shared_st_64bit_inst_enc_str_4},
    { MAXWELL_LUT_COUNTER_GENERIC_SHARED_ST_128BIT_INST, maxwell_lut_counter_generic_shared_st_128bit_inst_enc_str_1, maxwell_lut_counter_generic_shared_st_128bit_inst_enc_str_1,CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_generic_shared_st_128bit_inst_enc_str_4},

    { MAXWELL_LUT_COUNTER_SH_ATOM_32BIT_INST,        maxwell_lut_counter_sh_atom_32bit_inst_enc_str_1,      maxwell_lut_counter_sh_atom_32bit_inst_enc_str_1,      CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_sh_atom_32bit_inst_enc_str_4 },
    { MAXWELL_LUT_COUNTER_SH_ATOM_64BIT_INST,        maxwell_lut_counter_sh_atom_64bit_inst_enc_str_1,      maxwell_lut_counter_sh_atom_64bit_inst_enc_str_1,      CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_sh_atom_64bit_inst_enc_str_4 },
    { MAXWELL_LUT_COUNTER_SH_ATOM_CAS_32BIT_INST,    maxwell_lut_counter_sh_atom_cas_32bit_inst_enc_str_1,  maxwell_lut_counter_sh_atom_cas_32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_sh_atom_cas_32bit_inst_enc_str_4 },
    { MAXWELL_LUT_COUNTER_SH_ATOM_CAS_64BIT_INST,    maxwell_lut_counter_sh_atom_cas_64bit_inst_enc_str_1,  maxwell_lut_counter_sh_atom_cas_64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, maxwell_lut_counter_sh_atom_cas_64bit_inst_enc_str_4 },
    {MAXWELL_MPC_CTAS_LAUNCHED, maxwell_mpc_ctas_launched_enc_str_1, maxwell_mpc_ctas_launched_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_mpc_ctas_launched_enc_str_1},
    {MAXWELL_MPC_THREADS_LAUNCHED, maxwell_mpc_threads_launched_enc_str_1, maxwell_mpc_threads_launched_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_mpc_threads_launched_enc_str_1},
    {MAXWELL_MPC_WARPS_IN_FLIGHT, maxwell_mpc_warps_in_flight_enc_str_1, maxwell_mpc_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_mpc_warps_in_flight_enc_str_1},
    {MAXWELL_MPC_COMPUTE_CTAS_IN_FLIGHT, maxwell_mpc_compute_ctas_in_flight_enc_str_1, maxwell_mpc_compute_ctas_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_mpc_compute_ctas_in_flight_enc_str_1},
    {MAXWELL_ELAPSED_CYCLES_SM, maxwell_elapsed_cycles_sm_enc_str_1, maxwell_elapsed_cycles_sm_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_elapsed_cycles_sm_enc_str_4},
    {MAXWELL_LTC0_ATOMIC_TEX_SECTORS_FBP, maxwell_ltc0_atomic_tex_sectors_fbp_enc_str_1, maxwell_ltc0_atomic_tex_sectors_fbp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_atomic_tex_sectors_fbp_enc_str_4},
    {MAXWELL_LTC1_ATOMIC_TEX_SECTORS_FBP, maxwell_ltc1_atomic_tex_sectors_fbp_enc_str_1, maxwell_ltc1_atomic_tex_sectors_fbp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc1_atomic_tex_sectors_fbp_enc_str_4},
    {MAXWELL_LTC2_ATOMIC_TEX_SECTORS_FBP, maxwell_ltc2_atomic_tex_sectors_fbp_enc_str_1, maxwell_ltc2_atomic_tex_sectors_fbp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc2_atomic_tex_sectors_fbp_enc_str_4},
    {MAXWELL_LTC3_ATOMIC_TEX_SECTORS_FBP, maxwell_ltc3_atomic_tex_sectors_fbp_enc_str_1, maxwell_ltc3_atomic_tex_sectors_fbp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc3_atomic_tex_sectors_fbp_enc_str_4},

    { MAXWELL_LTC0_READ_VIDMEM_SECTORS_FBP,      maxwell_ltc0_read_vidmem_sectors_fbp_enc_str_1,   maxwell_ltc0_read_vidmem_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_read_vidmem_sectors_fbp_enc_str_4},
    { MAXWELL_LTC1_READ_VIDMEM_SECTORS_FBP,      maxwell_ltc1_read_vidmem_sectors_fbp_enc_str_1,   maxwell_ltc1_read_vidmem_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_read_vidmem_sectors_fbp_enc_str_4},
    { MAXWELL_LTC2_READ_VIDMEM_SECTORS_FBP,      maxwell_ltc2_read_vidmem_sectors_fbp_enc_str_1,   maxwell_ltc2_read_vidmem_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_read_vidmem_sectors_fbp_enc_str_4},
    { MAXWELL_LTC3_READ_VIDMEM_SECTORS_FBP,      maxwell_ltc3_read_vidmem_sectors_fbp_enc_str_1,   maxwell_ltc3_read_vidmem_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_read_vidmem_sectors_fbp_enc_str_4},

    { MAXWELL_LTC0_WRITE_VIDMEM_SECTORS_FBP,      maxwell_ltc0_write_vidmem_sectors_fbp_enc_str_1, maxwell_ltc0_write_vidmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_write_vidmem_sectors_fbp_enc_str_4},
    { MAXWELL_LTC1_WRITE_VIDMEM_SECTORS_FBP,      maxwell_ltc1_write_vidmem_sectors_fbp_enc_str_1, maxwell_ltc1_write_vidmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_write_vidmem_sectors_fbp_enc_str_4},
    { MAXWELL_LTC2_WRITE_VIDMEM_SECTORS_FBP,      maxwell_ltc2_write_vidmem_sectors_fbp_enc_str_1, maxwell_ltc2_write_vidmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_write_vidmem_sectors_fbp_enc_str_4},
    { MAXWELL_LTC3_WRITE_VIDMEM_SECTORS_FBP,      maxwell_ltc3_write_vidmem_sectors_fbp_enc_str_1, maxwell_ltc3_write_vidmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_write_vidmem_sectors_fbp_enc_str_4},

    { MAXWELL_LTC0_READ_SYSMEM_HIT_SECTORS_FBP, maxwell_ltc0_read_sysmem_hit_sectors_fbp_enc_str_1, maxwell_ltc0_read_sysmem_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_read_sysmem_hit_sectors_fbp_enc_str_1},
    { MAXWELL_LTC1_READ_SYSMEM_HIT_SECTORS_FBP, maxwell_ltc1_read_sysmem_hit_sectors_fbp_enc_str_1, maxwell_ltc1_read_sysmem_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc1_read_sysmem_hit_sectors_fbp_enc_str_1},
    { MAXWELL_LTC2_READ_SYSMEM_HIT_SECTORS_FBP, maxwell_ltc2_read_sysmem_hit_sectors_fbp_enc_str_1, maxwell_ltc2_read_sysmem_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc2_read_sysmem_hit_sectors_fbp_enc_str_1},
    { MAXWELL_LTC3_READ_SYSMEM_HIT_SECTORS_FBP, maxwell_ltc3_read_sysmem_hit_sectors_fbp_enc_str_1, maxwell_ltc3_read_sysmem_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc3_read_sysmem_hit_sectors_fbp_enc_str_1},
    { MAXWELL_LTC0_WRITE_SYSMEM_HIT_SECTORS_FBP, maxwell_ltc0_write_sysmem_hit_sectors_fbp_enc_str_1, maxwell_ltc0_write_sysmem_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_write_sysmem_hit_sectors_fbp_enc_str_1},
    { MAXWELL_LTC1_WRITE_SYSMEM_HIT_SECTORS_FBP, maxwell_ltc1_write_sysmem_hit_sectors_fbp_enc_str_1, maxwell_ltc1_write_sysmem_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc1_write_sysmem_hit_sectors_fbp_enc_str_1},
    { MAXWELL_LTC2_WRITE_SYSMEM_HIT_SECTORS_FBP, maxwell_ltc2_write_sysmem_hit_sectors_fbp_enc_str_1, maxwell_ltc2_write_sysmem_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc2_write_sysmem_hit_sectors_fbp_enc_str_1},
    { MAXWELL_LTC3_WRITE_SYSMEM_HIT_SECTORS_FBP, maxwell_ltc3_write_sysmem_hit_sectors_fbp_enc_str_1, maxwell_ltc3_write_sysmem_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc3_write_sysmem_hit_sectors_fbp_enc_str_1},
    { MAXWELL_LTC0_READ_SYSMEM_MISS_SECTORS_FBP, maxwell_ltc0_read_sysmem_miss_sectors_fbp_enc_str_1, maxwell_ltc0_read_sysmem_miss_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_read_sysmem_miss_sectors_fbp_enc_str_1},
    { MAXWELL_LTC1_READ_SYSMEM_MISS_SECTORS_FBP, maxwell_ltc1_read_sysmem_miss_sectors_fbp_enc_str_1, maxwell_ltc1_read_sysmem_miss_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc1_read_sysmem_miss_sectors_fbp_enc_str_1},
    { MAXWELL_LTC2_READ_SYSMEM_MISS_SECTORS_FBP, maxwell_ltc2_read_sysmem_miss_sectors_fbp_enc_str_1, maxwell_ltc2_read_sysmem_miss_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc2_read_sysmem_miss_sectors_fbp_enc_str_1},
    { MAXWELL_LTC3_READ_SYSMEM_MISS_SECTORS_FBP, maxwell_ltc3_read_sysmem_miss_sectors_fbp_enc_str_1, maxwell_ltc3_read_sysmem_miss_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc3_read_sysmem_miss_sectors_fbp_enc_str_1},
    { MAXWELL_LTC0_WRITE_SYSMEM_MISS_SECTORS_FBP, maxwell_ltc0_write_sysmem_miss_sectors_fbp_enc_str_1, maxwell_ltc0_write_sysmem_miss_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_write_sysmem_miss_sectors_fbp_enc_str_1},
    { MAXWELL_LTC1_WRITE_SYSMEM_MISS_SECTORS_FBP, maxwell_ltc1_write_sysmem_miss_sectors_fbp_enc_str_1, maxwell_ltc1_write_sysmem_miss_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc1_write_sysmem_miss_sectors_fbp_enc_str_1},
    { MAXWELL_LTC2_WRITE_SYSMEM_MISS_SECTORS_FBP, maxwell_ltc2_write_sysmem_miss_sectors_fbp_enc_str_1, maxwell_ltc2_write_sysmem_miss_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc2_write_sysmem_miss_sectors_fbp_enc_str_1},
    { MAXWELL_LTC3_WRITE_SYSMEM_MISS_SECTORS_FBP, maxwell_ltc3_write_sysmem_miss_sectors_fbp_enc_str_1, maxwell_ltc3_write_sysmem_miss_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc3_write_sysmem_miss_sectors_fbp_enc_str_1},

    { MAXWELL_LTC0_PM_REQ_SRC_UNIT_GCC_FBP,      maxwell_ltc0_pm_req_src_unit_gcc_fbp_enc_str_1,    maxwell_ltc0_pm_req_src_unit_gcc_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_pm_req_src_unit_gcc_fbp_enc_str_4},
    { MAXWELL_LTC1_PM_REQ_SRC_UNIT_GCC_FBP,      maxwell_ltc1_pm_req_src_unit_gcc_fbp_enc_str_1,    maxwell_ltc1_pm_req_src_unit_gcc_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_pm_req_src_unit_gcc_fbp_enc_str_4},
    { MAXWELL_LTC2_PM_REQ_SRC_UNIT_GCC_FBP,      maxwell_ltc2_pm_req_src_unit_gcc_fbp_enc_str_1,    maxwell_ltc2_pm_req_src_unit_gcc_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_pm_req_src_unit_gcc_fbp_enc_str_4},
    { MAXWELL_LTC3_PM_REQ_SRC_UNIT_GCC_FBP,      maxwell_ltc3_pm_req_src_unit_gcc_fbp_enc_str_1,    maxwell_ltc3_pm_req_src_unit_gcc_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, maxwell_ltc0_pm_req_src_unit_gcc_fbp_enc_str_4},

    { MAXWELL_SM_PROF_TRIGGER_00,  maxwell_sm_prof_trigger_00_enc_str_1,  maxwell_sm_prof_trigger_00_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_prof_trigger_00_enc_str_4}, //    "pmtrig0"
    { MAXWELL_SM_PROF_TRIGGER_01,  maxwell_sm_prof_trigger_01_enc_str_1,  maxwell_sm_prof_trigger_01_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_prof_trigger_01_enc_str_4}, //    "pmtrig1"
    { MAXWELL_SM_PROF_TRIGGER_02,  maxwell_sm_prof_trigger_02_enc_str_1,  maxwell_sm_prof_trigger_02_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_prof_trigger_02_enc_str_4}, //    "pmtrig2"
    { MAXWELL_SM_PROF_TRIGGER_03,  maxwell_sm_prof_trigger_03_enc_str_1,  maxwell_sm_prof_trigger_03_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_prof_trigger_03_enc_str_4}, //    "pmtrig3"
    { MAXWELL_SM_PROF_TRIGGER_04,  maxwell_sm_prof_trigger_04_enc_str_1,  maxwell_sm_prof_trigger_04_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_prof_trigger_04_enc_str_4}, //    "pmtrig4"
    { MAXWELL_SM_PROF_TRIGGER_05,  maxwell_sm_prof_trigger_05_enc_str_1,  maxwell_sm_prof_trigger_05_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_prof_trigger_05_enc_str_4}, //    "pmtrig5"
    { MAXWELL_SM_PROF_TRIGGER_06,  maxwell_sm_prof_trigger_06_enc_str_1,  maxwell_sm_prof_trigger_06_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_prof_trigger_06_enc_str_4}, //    "pmtrig6"
    { MAXWELL_SM_PROF_TRIGGER_07,  maxwell_sm_prof_trigger_07_enc_str_1,  maxwell_sm_prof_trigger_07_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_prof_trigger_07_enc_str_4}, //    "pmtrig7"
    { MAXWELL_SM_PMTRIG8,   maxwell_sm_pmtrig8_enc_str_1,   maxwell_sm_pmtrig8_enc_str_1,   CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pmtrig8_enc_str_4},  //    "pmtrig08"
    { MAXWELL_SM_PMTRIG9,   maxwell_sm_pmtrig9_enc_str_1,   maxwell_sm_pmtrig9_enc_str_1,   CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pmtrig9_enc_str_4},  //    "pmtrig09"
    { MAXWELL_SM_PMTRIG10,  maxwell_sm_pmtrig10_enc_str_1,  maxwell_sm_pmtrig10_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pmtrig10_enc_str_4}, //    "pmtrig10"
    { MAXWELL_SM_PMTRIG11,  maxwell_sm_pmtrig11_enc_str_1,  maxwell_sm_pmtrig11_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pmtrig11_enc_str_4}, //    "pmtrig11"
    { MAXWELL_SM_PMTRIG12,  maxwell_sm_pmtrig12_enc_str_1,  maxwell_sm_pmtrig12_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pmtrig12_enc_str_4}, //    "pmtrig12"
    { MAXWELL_SM_PMTRIG13,  maxwell_sm_pmtrig13_enc_str_1,  maxwell_sm_pmtrig13_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pmtrig13_enc_str_4}, //    "pmtrig13"
    { MAXWELL_SM_PMTRIG14,  maxwell_sm_pmtrig14_enc_str_1,  maxwell_sm_pmtrig14_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pmtrig14_enc_str_4}, //    "pmtrig14"
    { MAXWELL_SM_PMTRIG15,  maxwell_sm_pmtrig15_enc_str_1,  maxwell_sm_pmtrig15_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pmtrig15_enc_str_4}, //    "pmtrig15"
    { MAXWELL_SM_PMTRIG_MULTI_GROUP,  maxwell_multigrp_counter_pmtrig_enc_str_1,  maxwell_multigrp_counter_pmtrig_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_multigrp_counter_pmtrig_enc_str_1},

    { MAXWELL_SM_NON_IDLE_QUAD,  maxwell_sm_non_idle_quad_enc_str_1,  maxwell_sm_non_idle_quad_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_non_idle_quad_enc_str_4}, //    "non_idle"
    { MAXWELL_SM_ACTIVE_CYCLES_QUAD,  maxwell_sm_active_cycles_quad_enc_str_1,  maxwell_sm_active_cycles_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_active_cycles_quad_enc_str_4}, //    "active_cycles_quad"
    { MAXWELL_SM_WARPS_LAUNCHED,  maxwell_sm_warps_launched_enc_str_1,  maxwell_sm_warps_launched_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warps_launched_enc_str_4}, //    "warps_launched"
    { MAXWELL_SM_INST_ISSUED0,  maxwell_sm_inst_issued0_enc_str_1,  maxwell_sm_inst_issued0_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_issued0_enc_str_4}, //    "inst_issued0"
    { MAXWELL_SM_INST_ISSUED1,  maxwell_sm_inst_issued1_enc_str_1,  maxwell_sm_inst_issued1_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_issued1_enc_str_4}, //    "inst_issued1"
    { MAXWELL_SM_INST_ISSUED2,  maxwell_sm_inst_issued2_enc_str_1,  maxwell_sm_inst_issued2_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_issued2_enc_str_4}, //    "inst_issued2"
    { MAXWELL_SM_INST_EXECUTED,  maxwell_sm_inst_executed_enc_str_1,  maxwell_sm_inst_executed_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_executed_enc_str_4}, //    "inst_executed"
    { MAXWELL_SM_ACTIVE_WARPS_QUAD,  maxwell_sm_active_warps_quad_enc_str_1,  maxwell_sm_active_warps_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_active_warps_quad_enc_str_4}, //    "active_warps_quad"
    { MAXWELL_SM_WARPS_ON_DECK,  maxwell_sm_warps_on_deck_enc_str_1,  maxwell_sm_warps_on_deck_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warps_on_deck_enc_str_4}, //    "warps_on_deck"
    { MAXWELL_SM_THREAD_INST_EXECUTED,  maxwell_sm_thread_inst_executed_enc_str_1,  maxwell_sm_thread_inst_executed_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_thread_inst_executed_enc_str_4}, //    "thread_inst_executed"
    { MAXWELL_SM_WARPS_MOVED_ON_DECK,  maxwell_sm_warps_moved_on_deck_enc_str_1,  maxwell_sm_warps_moved_on_deck_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warps_moved_on_deck_enc_str_4}, //    "warps_moved_on_deck"
    { MAXWELL_SM_WARPS_MOVED_OFF_DECK,  maxwell_sm_warps_moved_off_deck_enc_str_1,  maxwell_sm_warps_moved_off_deck_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warps_moved_off_deck_enc_str_4}, //    "warps_moved_off_deck"
    { MAXWELL_SM_NOT_PREDICATED_OFF_THREAD_INST_EXECUTED,  maxwell_sm_not_predicated_off_thread_inst_executed_enc_str_1,  maxwell_sm_not_predicated_off_thread_inst_executed_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_not_predicated_off_thread_inst_executed_enc_str_4}, //    "not_predicated_off_thread_inst_executed"
    { MAXWELL_SM_TRAP_IN_TRAP_QUAD,  maxwell_sm_trap_in_trap_quad_enc_str_1,  maxwell_sm_trap_in_trap_quad_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_trap_in_trap_quad_enc_str_4}, //    "trap_in_trap"
    { MAXWELL_SM_WARP_CANT_ISSUE_DRAIN,  maxwell_sm_warp_cant_issue_drain_enc_str_1,  maxwell_sm_warp_cant_issue_drain_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warp_cant_issue_drain_enc_str_4}, //    "warp_cant_issue_drain"
    { MAXWELL_SM_WARP_CANT_ISSUE_ON_DECK_SHORT_SCOREBOARD,  maxwell_sm_warp_cant_issue_on_deck_short_scoreboard_enc_str_1,  maxwell_sm_warp_cant_issue_on_deck_short_scoreboard_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warp_cant_issue_off_deck_short_scoreboard_enc_str_4}, //    "warp_cant_issue_on_deck_short_scoreboard"
    { MAXWELL_SM_WARP_CANT_ISSUE_ICACHE_MISS,  maxwell_sm_warp_cant_issue_icache_miss_enc_str_1,  maxwell_sm_warp_cant_issue_icache_miss_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warp_cant_issue_icache_miss_enc_str_4}, //    "warp_cant_issue_icache_miss"
    { MAXWELL_SM_WARP_CANT_ISSUE_WAIT,  maxwell_sm_warp_cant_issue_wait_enc_str_1,  maxwell_sm_warp_cant_issue_wait_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warp_cant_issue_wait_enc_str_4}, //    "warp_cant_issue_wait"
    { MAXWELL_SM_WARP_CANT_ISSUE_IMC_MISS,  maxwell_sm_warp_cant_issue_imc_miss_enc_str_1,  maxwell_sm_warp_cant_issue_imc_miss_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warp_cant_issue_imc_miss_enc_str_4}, //    "warp_cant_issue_imc_miss"
    { MAXWELL_SM_WARP_CANT_ISSUE_NO_INSTRUCTIONS,  maxwell_sm_warp_cant_issue_no_instructions_enc_str_1,  maxwell_sm_warp_cant_issue_no_instructions_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warp_cant_issue_no_instructions_enc_str_4}, //    "warp_cant_issue_no_instructions"
    { MAXWELL_SM_WARP_CANT_ISSUE_LONG_SCOREBOARD,  maxwell_sm_warp_cant_issue_long_scoreboard_enc_str_1,  maxwell_sm_warp_cant_issue_long_scoreboard_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warp_cant_issue_long_scoreboard_enc_str_4}, //    "warp_cant_issue_long_scoreboard"
    { MAXWELL_SM_WARP_CANT_ISSUE_SHADOW_PIPE_THROTTLE,  maxwell_sm_warp_cant_issue_shadow_pipe_throttle_enc_str_1,  maxwell_sm_warp_cant_issue_shadow_pipe_throttle_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warp_cant_issue_shadow_pipe_throttle_enc_str_4}, //    "warp_cant_issue_shadow_pipe_throttle"
    { MAXWELL_SM_WARP_CANT_ISSUE_BARRIER,  maxwell_sm_warp_cant_issue_barrier_enc_str_1,  maxwell_sm_warp_cant_issue_barrier_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warp_cant_issue_barrier_enc_str_4}, //    "warp_cant_issue_barrier"
    { MAXWELL_SM_WARP_CANT_ISSUE_TEX_THROTTLE,  maxwell_sm_warp_cant_issue_tex_throttle_enc_str_1,  maxwell_sm_warp_cant_issue_tex_throttle_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warp_cant_issue_tex_throttle_enc_str_4}, //    "warp_cant_issue_tex_throttle"
    { MAXWELL_SM_WARP_CANT_ISSUE_OFF_DECK_SHORT_SCOREBOARD,  maxwell_sm_warp_cant_issue_off_deck_short_scoreboard_enc_str_1,  maxwell_sm_warp_cant_issue_off_deck_short_scoreboard_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warp_cant_issue_off_deck_short_scoreboard_enc_str_4}, //    "warp_cant_issue_off_deck_short_scoreboard"
    { MAXWELL_SM_WARP_CANT_ISSUE_MIO_THROTTLE,  maxwell_sm_warp_cant_issue_mio_throttle_enc_str_1,  maxwell_sm_warp_cant_issue_mio_throttle_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warp_cant_issue_mio_throttle_enc_str_4}, //    "warp_cant_issue_mio_throttle"
    { MAXWELL_SM_WARP_CANT_ISSUE_TILE_ALLOCATION_STALL,  maxwell_sm_warp_cant_issue_tile_allocation_stall_enc_str_1,  maxwell_sm_warp_cant_issue_tile_allocation_stall_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warp_cant_issue_tile_allocation_stall_enc_str_4}, //    "warp_cant_issue_tile_allocation_stall"
    { MAXWELL_SM_WARP_CANT_ISSUE_DISPATCH_STALL,  maxwell_sm_warp_cant_issue_dispatch_stall_enc_str_1,  maxwell_sm_warp_cant_issue_dispatch_stall_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warp_cant_issue_dispatch_stall_enc_str_4}, //    "warp_cant_issue_dispatch_stall"
    { MAXWELL_SM_WARP_CANT_ISSUE_ALLOCATION_STALL_NO_SPACE,  maxwell_sm_warp_cant_issue_allocation_stall_no_space_enc_str_1,  maxwell_sm_warp_cant_issue_allocation_stall_no_space_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warp_cant_issue_allocation_stall_no_space_enc_str_4}, //    "warp_cant_issue_allocation_stall_no_space"
    { MAXWELL_SM_WARP_CANT_ISSUE_NOT_SELECTED,  maxwell_sm_warp_cant_issue_not_selected_enc_str_1,  maxwell_sm_warp_cant_issue_not_selected_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warp_cant_issue_not_selected_enc_str_4}, //    "warp_cant_issue_not_selected"
    { MAXWELL_SM_WARP_CANT_ISSUE_SELECTED,  maxwell_sm_warp_cant_issue_selected_enc_str_1,  maxwell_sm_warp_cant_issue_selected_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warp_cant_issue_selected_enc_str_4}, //    "warp_cant_issue_selected"
    { MAXWELL_SM_WARP_CANT_ISSUE_ALLOCATION_STALL_NOT_ELIGIBLE,  maxwell_sm_warp_cant_issue_allocation_stall_not_eligible_enc_str_1,  maxwell_sm_warp_cant_issue_allocation_stall_not_eligible_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warp_cant_issue_allocation_stall_not_eligible_enc_str_4}, //    "warp_cant_issue_allocation_stall_not_eligible"
    { MAXWELL_SM_WARP_CANT_ISSUE_MISC,  maxwell_sm_warp_cant_issue_misc_enc_str_1,  maxwell_sm_warp_cant_issue_misc_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warp_cant_issue_misc_enc_str_4}, //    "warp_cant_issue_misc"
    { MAXWELL_SM_WARP_CANT_ISSUE_ON_DECK_MISC,  maxwell_sm_warp_cant_issue_on_deck_misc_enc_str_1,  maxwell_sm_warp_cant_issue_on_deck_misc_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warp_cant_issue_on_deck_misc_enc_str_4}, //    "warp_cant_issue_on_deck_misc"
    { MAXWELL_SM_WARP_ISSUE_ELIGIBLE,  maxwell_sm_warp_issue_eligible_enc_str_1,  maxwell_sm_warp_issue_eligible_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warp_issue_eligible_enc_str_4}, //    "warp_issue_eligible"
    { MAXWELL_SM_WARP_CANT_ISSUE_MEMBAR,  maxwell_sm_warp_cant_issue_membar_enc_str_1,  maxwell_sm_warp_cant_issue_membar_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warp_cant_issue_membar_enc_str_4}, //    "warp_cant_issue_membar"
    { MAXWELL_SM_CANT_DISPATCH_REGISTER_READ,  maxwell_sm_cant_dispatch_register_read_enc_str_1,  maxwell_sm_cant_dispatch_register_read_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_cant_dispatch_register_read_enc_str_4}, //    "cant_dispatch_register_read"
    { MAXWELL_SM_CANT_DISPATCH_REGISTER_WRITE,  maxwell_sm_cant_dispatch_register_write_enc_str_1,  maxwell_sm_cant_dispatch_register_write_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_cant_dispatch_register_write_enc_str_4}, //    "cant_dispatch_register_write"
    { MAXWELL_SM_CANT_DISPATCH_POWER_THROTTLE,  maxwell_sm_cant_dispatch_power_throttle_enc_str_1,  maxwell_sm_cant_dispatch_power_throttle_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_cant_dispatch_power_throttle_enc_str_4}, //    "cant_dispatch_power_throttle"
    { MAXWELL_SM_CANT_DISPATCH_PREDCC_WRITE,  maxwell_sm_cant_dispatch_predcc_write_enc_str_1,  maxwell_sm_cant_dispatch_predcc_write_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_cant_dispatch_predcc_write_enc_str_4}, //    "cant_dispatch_predcc_write"
    { MAXWELL_SM_CANT_DISPATCH_DIVERGED_CHAIN_IPA,  maxwell_sm_cant_dispatch_diverged_chain_ipa_enc_str_1,  maxwell_sm_cant_dispatch_diverged_chain_ipa_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_cant_dispatch_diverged_chain_ipa_enc_str_4}, //    "cant_dispatch_diverged_chain_ipa"
    { MAXWELL_SM_CANT_DISPATCH_DIVERGED_GENERIC_LD_ST,  maxwell_sm_cant_dispatch_diverged_generic_ld_st_enc_str_1,  maxwell_sm_cant_dispatch_diverged_generic_ld_st_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_cant_dispatch_diverged_generic_ld_st_enc_str_4}, //    "cant_dispatch_diverged_generic_ld_st"
    { MAXWELL_SM_INST_EXECUTED_DECOUPLED_PRED_OFF,  maxwell_sm_inst_executed_decoupled_pred_off_enc_str_1,  maxwell_sm_inst_executed_decoupled_pred_off_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_executed_decoupled_pred_off_enc_str_4}, //    "inst_executed_decoupled_pred_off"
    { MAXWELL_SM_INST_EXECUTED_COUPLED_PRED_OFF,  maxwell_sm_inst_executed_coupled_pred_off_enc_str_1,  maxwell_sm_inst_executed_coupled_pred_off_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_executed_coupled_pred_off_enc_str_4}, //    "inst_executed_coupled_pred_off"
    { MAXWELL_SM_INST_EXECUTED_32B,  maxwell_sm_inst_executed_32b_enc_str_1,  maxwell_sm_inst_executed_32b_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_executed_32b_enc_str_4}, //    "inst_executed_32b"
    { MAXWELL_SM_INST_EXECUTED_64B,  maxwell_sm_inst_executed_64b_enc_str_1,  maxwell_sm_inst_executed_64b_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_executed_64b_enc_str_4}, //    "inst_executed_64b"
    { MAXWELL_SM_INST_EXECUTED_128B,  maxwell_sm_inst_executed_128b_enc_str_1,  maxwell_sm_inst_executed_128b_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_executed_128b_enc_str_4}, //    "inst_executed_128b"
    { MAXWELL_SM_INST_EXECUTED_U128B,  maxwell_sm_inst_executed_u128b_enc_str_1,  maxwell_sm_inst_executed_u128b_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_executed_u128b_enc_str_4}, //    "inst_executed_U128b"
    { MAXWELL_SM_GENERIC_SHARED,  maxwell_sm_generic_shared_enc_str_1,  maxwell_sm_generic_shared_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_generic_shared_enc_str_4}, //    "inst_executed_lsu_generic_shared"
    { MAXWELL_SM_GENERIC_TEX,  maxwell_sm_generic_tex_enc_str_1,  maxwell_sm_generic_tex_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_generic_tex_enc_str_4}, //    "inst_executed_lsu_generic_tex"
    { MAXWELL_SM_LOCAL_STORE,  maxwell_sm_local_store_enc_str_1,  maxwell_sm_local_store_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_local_store_enc_str_4}, //    "inst_executed_local_st"
    { MAXWELL_SM_LOCAL_LOAD,  maxwell_sm_local_load_enc_str_1,  maxwell_sm_local_load_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_local_load_enc_str_4}, //    "inst_executed_local_ld"
    { MAXWELL_SM_SHARED_LOAD,  maxwell_sm_shared_load_enc_str_1,  maxwell_sm_shared_load_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_shared_load_enc_str_4}, //    "inst_executed_shared_ld"
    { MAXWELL_SM_SHARED_STORE,  maxwell_sm_shared_store_enc_str_1,  maxwell_sm_shared_store_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_shared_store_enc_str_4}, //    "inst_executed_shared_st"
    { MAXWELL_SM_SHARED_ATOM_CAS,  maxwell_sm_shared_atom_cas_enc_str_1,  maxwell_sm_shared_atom_cas_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_shared_atom_cas_enc_str_4}, //    "inst_executed_shared_atom_cas"
    { MAXWELL_SM_SHARED_ATOM,  maxwell_sm_shared_atom_enc_str_1,  maxwell_sm_shared_atom_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_shared_atom_enc_str_4}, //    "inst_executed_shared_atom"
    { MAXWELL_SM_ATTRIBUTE_STORE,  maxwell_sm_attribute_store_enc_str_1,  maxwell_sm_attribute_store_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_attribute_store_enc_str_4}, //    "inst_executed_attribute_st"
    { MAXWELL_SM_ATTRIBUTE_LOAD,  maxwell_sm_attribute_load_enc_str_1,  maxwell_sm_attribute_load_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_attribute_load_enc_str_4}, //    "inst_executed_attribute_ld"
    { MAXWELL_SM_GLOBAL_ATOM_CAS,  maxwell_sm_global_atom_cas_enc_str_1,  maxwell_sm_global_atom_cas_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_global_atom_cas_enc_str_4}, //    "inst_executed_global_atom_cas"
    { MAXWELL_SM_GLOBAL_ATOM,  maxwell_sm_global_atom_enc_str_1,  maxwell_sm_global_atom_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_global_atom_enc_str_4}, //    "inst_executed_global_atom"
    { MAXWELL_SM_GLOBAL_RED,  maxwell_sm_global_red_enc_str_1,  maxwell_sm_global_red_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_global_red_enc_str_4}, //    "inst_executed_global_red"
    { MAXWELL_SM_GLOBAL_LOAD,  maxwell_sm_global_load_enc_str_1,  maxwell_sm_global_load_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_global_load_enc_str_4}, //    "inst_executed_global_ld"
    { MAXWELL_SM_GLOBAL_STORE,  maxwell_sm_global_store_enc_str_1,  maxwell_sm_global_store_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_global_store_enc_str_4}, //    "inst_executed_global_st"
    { MAXWELL_SM_GENERIC_LOAD,  maxwell_sm_generic_load_enc_str_1,  maxwell_sm_generic_load_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_generic_load_enc_str_4}, //    "inst_executed_generic_ld"
    { MAXWELL_SM_GENERIC_STORE,  maxwell_sm_generic_store_enc_str_1,  maxwell_sm_generic_store_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_generic_store_enc_str_4}, //    "inst_executed_generic_st"
    { MAXWELL_SM_SURFACE_ATOM,  maxwell_sm_surface_atom_enc_str_1,  maxwell_sm_surface_atom_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_surface_atom_enc_str_4}, //    "inst_executed_surface_atom"
    { MAXWELL_SM_SURFACE_ATOM_CAS,  maxwell_sm_surface_atom_cas_enc_str_1,  maxwell_sm_surface_atom_cas_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_surface_atom_cas_enc_str_4}, //    "inst_executed_surface_atom_cas"
    { MAXWELL_SM_SURFACE_RED,  maxwell_sm_surface_red_enc_str_1,  maxwell_sm_surface_red_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_surface_red_enc_str_4}, //    "inst_executed_surface_red"
    { MAXWELL_SM_SURFACE_LOAD,  maxwell_sm_surface_load_enc_str_1,  maxwell_sm_surface_load_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_surface_load_enc_str_4}, //    "inst_executed_surface_ld"
    { MAXWELL_SM_SURFACE_STORE,  maxwell_sm_surface_store_enc_str_1,  maxwell_sm_surface_store_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_surface_store_enc_str_4}, //    "inst_executed_surface_st"
    { MAXWELL_SM_INST_ROLLBACKED,  maxwell_sm_inst_rollbacked_enc_str_1,  maxwell_sm_inst_rollbacked_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_rollbacked_enc_str_4}, //    "inst_rollbacked"
    { MAXWELL_SM_ROLLBACKS_IMC,  maxwell_sm_rollbacks_imc_enc_str_1,  maxwell_sm_rollbacks_imc_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_rollbacks_imc_enc_str_4}, //    "rollbacks_imc"
    { MAXWELL_SM_TEX_WB_REQUESTS_PENDING,  maxwell_sm_tex_wb_requests_pending_enc_str_1,  maxwell_sm_tex_wb_requests_pending_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_tex_wb_requests_pending_enc_str_4}, //    "tex_wb_requests_pending"
    { MAXWELL_SM_TEX_WB_REQUESTS,  maxwell_sm_tex_wb_requests_enc_str_1,  maxwell_sm_tex_wb_requests_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_tex_wb_requests_enc_str_4}, //    "tex_wb_requests"
    { MAXWELL_SM_IMC_HIT,  maxwell_sm_imc_hit_enc_str_1,  maxwell_sm_imc_hit_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_imc_hit_enc_str_4}, //    "imc_hit"
    { MAXWELL_SM_IMC_FULL_TAG,  maxwell_sm_imc_full_tag_enc_str_1,  maxwell_sm_imc_full_tag_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_imc_full_tag_enc_str_4}, //    "imc_full_tag"
    { MAXWELL_SM_IMC_TRUE_MISS,  maxwell_sm_imc_true_miss_enc_str_1,  maxwell_sm_imc_true_miss_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_imc_true_miss_enc_str_4}, //    "imc_true_miss"
    { MAXWELL_SM_IMC_COVERED_MISS,  maxwell_sm_imc_covered_miss_enc_str_1,  maxwell_sm_imc_covered_miss_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_imc_covered_miss_enc_str_4}, //    "imc_covered_miss"
    { MAXWELL_SM_IMC_MISSES_OUTSTANDING,  maxwell_sm_imc_misses_outstanding_enc_str_1,  maxwell_sm_imc_misses_outstanding_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_imc_misses_outstanding_enc_str_4}, //    "imc_misses_outstanding"
    { MAXWELL_SM_FET_FETCHED_LINES,  maxwell_sm_fet_fetched_lines_enc_str_1,  maxwell_sm_fet_fetched_lines_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_fet_fetched_lines_enc_str_4}, //    "fet_fetched_lines"
    { MAXWELL_SM_INST_EXECUTED_ADU_PIPE,  maxwell_sm_inst_executed_adu_pipe_enc_str_1,  maxwell_sm_inst_executed_adu_pipe_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_executed_adu_pipe_enc_str_4}, //    "inst_executed_adu_pipe"
    { MAXWELL_SM_INST_EXECUTED_BRU_PIPE,  maxwell_sm_inst_executed_bru_pipe_enc_str_1,  maxwell_sm_inst_executed_bru_pipe_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_executed_bru_pipe_enc_str_4}, //    "inst_executed_bru_pipe"
    { MAXWELL_SM_INST_EXECUTED_LDC_PIPE,  maxwell_sm_inst_executed_ldc_pipe_enc_str_1,  maxwell_sm_inst_executed_ldc_pipe_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_executed_ldc_pipe_enc_str_4}, //    "inst_executed_ldc_pipe"
    { MAXWELL_SM_INST_EXECUTED_LSU_PIPE,  maxwell_sm_inst_executed_lsu_pipe_enc_str_1,  maxwell_sm_inst_executed_lsu_pipe_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_executed_lsu_pipe_enc_str_4}, //    "inst_executed_lsu_pipe"
    { MAXWELL_SM_INST_EXECUTED_XU_PIPE,  maxwell_sm_inst_executed_xu_pipe_enc_str_1,  maxwell_sm_inst_executed_xu_pipe_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_executed_xu_pipe_enc_str_4}, //    "inst_executed_xu_pipe"
    { MAXWELL_SM_INST_EXECUTED_TEX_PIPE,  maxwell_sm_inst_executed_tex_pipe_enc_str_1,  maxwell_sm_inst_executed_tex_pipe_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_executed_tex_pipe_enc_str_4}, //    "inst_executed_tex_pipe"
    { MAXWELL_SM_INST_EXECUTED_FMAI_PIPE,  maxwell_sm_inst_executed_fmai_pipe_enc_str_1,  maxwell_sm_inst_executed_fmai_pipe_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_executed_fmai_pipe_enc_str_4}, //    "inst_executed_fmai_pipe"
    { MAXWELL_SM_INST_EXECUTED_FXU_PIPE,  maxwell_sm_inst_executed_fxu_pipe_enc_str_1,  maxwell_sm_inst_executed_fxu_pipe_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_executed_fxu_pipe_enc_str_4}, //    "inst_executed_fxu_pipe"
    { MAXWELL_SM_INST_EXECUTED_FMA64LITE_PIPE,  maxwell_sm_inst_executed_fma64lite_pipe_enc_str_1,  maxwell_sm_inst_executed_fma64lite_pipe_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_executed_fma64lite_pipe_enc_str_4}, //    "inst_executed_fma64lite_pipe"
    { MAXWELL_SM_INST_EXECUTED_FMA64PLUS_PIPE,  maxwell_sm_inst_executed_fma64plus_pipe_enc_str_1,  maxwell_sm_inst_executed_fma64plus_pipe_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_executed_fma64plus_pipe_enc_str_4}, //    "inst_executed_fma64plus_pipe"
    { MAXWELL_SM_INST_EXECUTED_FMA64PLUSPLUS_PIPE,  maxwell_sm_inst_executed_fma64plusplus_pipe_enc_str_1,  maxwell_sm_inst_executed_fma64plusplus_pipe_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_executed_fma64plusplus_pipe_enc_str_4}, //    "inst_executed_fma64plusplus_pipe"
    { MAXWELL_SM_INST_EXECUTED_BAR_PIPE,  maxwell_sm_inst_executed_bar_pipe_enc_str_1,  maxwell_sm_inst_executed_bar_pipe_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_executed_bar_pipe_enc_str_4}, //    "inst_executed_bar_pipe"
    { MAXWELL_SM_INST_EXECUTED_FE_PIPE,  maxwell_sm_inst_executed_fe_pipe_enc_str_1,  maxwell_sm_inst_executed_fe_pipe_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_executed_fe_pipe_enc_str_4}, //    "inst_executed_fe_pipe"
    { MAXWELL_SM_INST_EXECUTED_VOTE_VTG,  maxwell_sm_inst_executed_vote_vtg_enc_str_1,  maxwell_sm_inst_executed_vote_vtg_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_executed_vote_vtg_enc_str_4}, //    "inst_executed_vote_vtg"
    { MAXWELL_SM_INST_EXECUTED_SU_PIPE,  maxwell_sm_inst_executed_su_pipe_enc_str_1,  maxwell_sm_inst_executed_su_pipe_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_executed_su_pipe_enc_str_4}, //    "inst_executed_su_pipe"
    { MAXWELL_SM_UNWINDING_BR_EXECUTED,  maxwell_sm_unwinding_br_executed_enc_str_1,  maxwell_sm_unwinding_br_executed_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_unwinding_br_executed_enc_str_4}, //    "unwinding_br_executed"
    { MAXWELL_SM_DIVERGED_BR_EXECUTED,  maxwell_sm_diverged_br_executed_enc_str_1,  maxwell_sm_diverged_br_executed_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_diverged_br_executed_enc_str_4}, //    "diverged_br_executed"
    { MAXWELL_SM_UNIQUE_IDX_BR_EXECUTED,  maxwell_sm_unique_idx_br_executed_enc_str_1,  maxwell_sm_unique_idx_br_executed_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_unique_idx_br_executed_enc_str_4}, //    "unique_idx_br_executed"
    { MAXWELL_SM_RVAL_DIV_IDX_BR_EXECUTED,  maxwell_sm_rval_div_idx_br_executed_enc_str_1,  maxwell_sm_rval_div_idx_br_executed_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_rval_div_idx_br_executed_enc_str_4}, //    "rval_div_idx_br_executed"
    { MAXWELL_SM_BRANCH,  maxwell_sm_branch_enc_str_1,  maxwell_sm_branch_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_branch_enc_str_4}, //    "br_executed"
    { MAXWELL_SM_TAKEN_BR_EXECUTED,  maxwell_sm_taken_br_executed_enc_str_1,  maxwell_sm_taken_br_executed_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_taken_br_executed_enc_str_4}, //    "taken_br_executed"
    { MAXWELL_SM_PRED_DIV_IDX_BR_EXECUTED,  maxwell_sm_pred_div_idx_br_executed_enc_str_1,  maxwell_sm_pred_div_idx_br_executed_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pred_div_idx_br_executed_enc_str_4}, //    "pred_div_idx_br_executed"
    { MAXWELL_SM_CRS_FILL,  maxwell_sm_crs_fill_enc_str_1,  maxwell_sm_crs_fill_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_crs_fill_enc_str_4}, //    "crs_fill"
    { MAXWELL_SM_CRS_SPILL,  maxwell_sm_crs_spill_enc_str_1,  maxwell_sm_crs_spill_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_crs_spill_enc_str_4}, //    "crs_spill"
    { MAXWELL_SM_CRS_PUSH_ACTION,  maxwell_sm_crs_push_action_enc_str_1,  maxwell_sm_crs_push_action_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_crs_push_action_enc_str_4}, //    "crs_push_action"
    { MAXWELL_SM_TEX_REQUESTS,  maxwell_sm_tex_requests_enc_str_1,  maxwell_sm_tex_requests_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_tex_requests_enc_str_4}, //    "tex_requests"
    { MAXWELL_SM_TEX_REQ_ACTIVE,  maxwell_sm_tex_req_active_enc_str_1,  maxwell_sm_tex_req_active_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_tex_req_active_enc_str_4}, //    "tex_req_active"
    { MAXWELL_SM_TEX_REQ_STALLED,  maxwell_sm_tex_req_stalled_enc_str_1,  maxwell_sm_tex_req_stalled_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_tex_req_stalled_enc_str_4}, //    "tex_req_stalled"
    { MAXWELL_SM_TEX_REQ_STARVED,  maxwell_sm_tex_req_starved_enc_str_1,  maxwell_sm_tex_req_starved_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_tex_req_starved_enc_str_4}, //    "tex_req_starved"
    { MAXWELL_SM_TEX_REQ_IDLE,  maxwell_sm_tex_req_idle_enc_str_1,  maxwell_sm_tex_req_idle_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_tex_req_idle_enc_str_4}, //    "tex_req_idle"
    { MAXWELL_SM_LSU_WB_OPS_PENDING,  maxwell_sm_lsu_wb_ops_pending_enc_str_1,  maxwell_sm_lsu_wb_ops_pending_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_lsu_wb_ops_pending_enc_str_4}, //    "lsu_wb_ops_pending"
    { MAXWELL_SM_INST_EXECUTED_LSU_WB_OPS,  maxwell_sm_inst_executed_lsu_wb_ops_enc_str_1,  maxwell_sm_inst_executed_lsu_wb_ops_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_inst_executed_lsu_wb_ops_enc_str_4}, //    "inst_executed_lsu_wb_ops"
    { MAXWELL_SM_TEX_INST_PENDING,  maxwell_sm_tex_inst_pending_enc_str_1,  maxwell_sm_tex_inst_pending_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_tex_inst_pending_enc_str_4}, //    "tex_inst_pending"
    { MAXWELL_SM_TEX_WB_INST_EXECUTED,  maxwell_sm_tex_wb_inst_executed_enc_str_1,  maxwell_sm_tex_wb_inst_executed_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_tex_wb_inst_executed_enc_str_4}, //    "tex_wb_inst_executed"
    { MAXWELL_SM_NON_IDLE,  maxwell_sm_non_idle_enc_str_1,  maxwell_sm_non_idle_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_non_idle_enc_str_4}, //    "non_idle"
    { MAXWELL_SM_ACTIVE_CYCLES,  maxwell_sm_active_cycles_enc_str_1,  maxwell_sm_active_cycles_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_active_cycles_enc_str_4}, //    "active_cycles"
    { MAXWELL_SM_ACTIVE_WARPS,  maxwell_sm_active_warps_enc_str_1,  maxwell_sm_active_warps_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_active_warps_enc_str_4}, //    "active_warps"
    { MAXWELL_SM_ACTIVE_CTAS,  maxwell_sm_active_ctas_enc_str_1,  maxwell_sm_active_ctas_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_active_ctas_enc_str_4}, //    "active_ctas"
    { MAXWELL_SM_CTA_LAUNCHED,  maxwell_sm_cta_launched_enc_str_1,  maxwell_sm_cta_launched_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_cta_launched_enc_str_4}, //    "ctas_launched"
    { MAXWELL_SM_LSU_BUSY,  maxwell_sm_lsu_busy_enc_str_1,  maxwell_sm_lsu_busy_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_lsu_busy_enc_str_4}, //    "lsu_busy"
    { MAXWELL_SM_ACTIVE_WARPS_PS,  maxwell_sm_active_warps_ps_enc_str_1,  maxwell_sm_active_warps_ps_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_active_warps_ps_enc_str_4}, //    "active_warps_ps"
    { MAXWELL_SM_ACTIVE_WARPS_VTG,  maxwell_sm_active_warps_vtg_enc_str_1,  maxwell_sm_active_warps_vtg_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_active_warps_vtg_enc_str_4}, //    "active_warps_vtg"
    { MAXWELL_SM_ACTIVE_SUBTILES,  maxwell_sm_active_subtiles_enc_str_1,  maxwell_sm_active_subtiles_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_active_subtiles_enc_str_4}, //    "active_subtiles"
    { MAXWELL_SM_SUBTILES_LAUNCHED_H0,  maxwell_sm_subtiles_launched_h0_enc_str_1,  maxwell_sm_subtiles_launched_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_subtiles_launched_h0_enc_str_4}, //    "subtiles_launched_h0"
    { MAXWELL_SM_SUBTILES_LAUNCHED_H1,  maxwell_sm_subtiles_launched_h1_enc_str_1,  maxwell_sm_subtiles_launched_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_subtiles_launched_h1_enc_str_4}, //    "subtiles_launched_h1"
    { MAXWELL_SM_TRAP_COALESCING,  maxwell_sm_trap_coalescing_enc_str_1,  maxwell_sm_trap_coalescing_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_trap_coalescing_enc_str_4}, //    "trap_coalescing"
    { MAXWELL_SM_TRAP_COUNT,  maxwell_sm_trap_count_enc_str_1,  maxwell_sm_trap_count_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_trap_count_enc_str_4}, //    "trap_count"
    { MAXWELL_SM_TRAP_IDLING_FOR_TRAP,  maxwell_sm_trap_idling_for_trap_enc_str_1,  maxwell_sm_trap_idling_for_trap_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_trap_idling_for_trap_enc_str_4}, //    "trap_idling_for_trap"
    { MAXWELL_SM_TRAP_IN_TRAP,  maxwell_sm_trap_in_trap_enc_str_1,  maxwell_sm_trap_in_trap_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_trap_in_trap_enc_str_4}, //    "trap_in_trap"
    { MAXWELL_SM_TRAP_STALL_LAUNCHES,  maxwell_sm_trap_stall_launches_enc_str_1,  maxwell_sm_trap_stall_launches_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_trap_stall_launches_enc_str_4}, //    "trap_stall_launches"
    { MAXWELL_SM_TRAP_WAITING_FOR_IDE,  maxwell_sm_trap_waiting_for_ide_enc_str_1,  maxwell_sm_trap_waiting_for_ide_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_trap_waiting_for_ide_enc_str_4}, //    "trap_waiting_for_ide"
    { MAXWELL_SM_ICC_HIT,  maxwell_sm_icc_hit_enc_str_1,  maxwell_sm_icc_hit_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_icc_hit_enc_str_4}, //    "icc_hit"
    { MAXWELL_SM_ICC_TRUE_MISS,  maxwell_sm_icc_true_miss_enc_str_1,  maxwell_sm_icc_true_miss_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_icc_true_miss_enc_str_4}, //    "icc_true_miss"
    { MAXWELL_SM_ICC_COVERED_MISS,  maxwell_sm_icc_covered_miss_enc_str_1,  maxwell_sm_icc_covered_miss_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_icc_covered_miss_enc_str_4}, //    "icc_covered_miss"
    { MAXWELL_SM_ICC_FULL_TAG,  maxwell_sm_icc_full_tag_enc_str_1,  maxwell_sm_icc_full_tag_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_icc_full_tag_enc_str_4}, //    "icc_full_tag"
    { MAXWELL_SM_ICC_PREFETCHES,  maxwell_sm_icc_prefetches_enc_str_1,  maxwell_sm_icc_prefetches_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_icc_prefetches_enc_str_4}, //    "icc_prefetches"
    { MAXWELL_SM_ICC_UNLOCK_ALL,  maxwell_sm_icc_unlock_all_enc_str_1,  maxwell_sm_icc_unlock_all_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_icc_unlock_all_enc_str_4}, //    "icc_unlock_all"
    { MAXWELL_SM_ICC_MISSES_OUTSTANDING,  maxwell_sm_icc_misses_outstanding_enc_str_1,  maxwell_sm_icc_misses_outstanding_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_icc_misses_outstanding_enc_str_4}, //    "icc_misses_outstanding"
    { MAXWELL_SM_SHARED_LD_BANK_CONFLICT,  maxwell_sm_shared_ld_bank_conflict_enc_str_1,  maxwell_sm_shared_ld_bank_conflict_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_shared_ld_bank_conflict_enc_str_4}, //    "shm_ld_bank_conflict"
    { MAXWELL_SM_SHARED_ST_BANK_CONFLICT,  maxwell_sm_shared_st_bank_conflict_enc_str_1,  maxwell_sm_shared_st_bank_conflict_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_shared_st_bank_conflict_enc_str_4}, //    "shm_st_bank_conflict"
    { MAXWELL_SM_SHARED_LOAD_TRANSACTIONS,  maxwell_sm_shared_load_transactions_enc_str_1,  maxwell_sm_shared_load_transactions_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_shared_load_transactions_enc_str_4}, //    "shm_ld_count"
    { MAXWELL_SM_SHARED_STORE_TRANSACTIONS,  maxwell_sm_shared_store_transactions_enc_str_1,  maxwell_sm_shared_store_transactions_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_shared_store_transactions_enc_str_4}, //    "shm_st_count"
    { MAXWELL_SM_PQ_WRITE_H0,  maxwell_sm_pq_write_h0_enc_str_1,  maxwell_sm_pq_write_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pq_write_h0_enc_str_4}, //    "pq_write_h0"
    { MAXWELL_SM_PQ_WRITE_H1,  maxwell_sm_pq_write_h1_enc_str_1,  maxwell_sm_pq_write_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pq_write_h1_enc_str_4}, //    "pq_write_h1"
    { MAXWELL_SM_ADU_REPLAY_H0,  maxwell_sm_adu_replay_h0_enc_str_1,  maxwell_sm_adu_replay_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_adu_replay_h0_enc_str_4}, //    "adu_replay_h0"
    { MAXWELL_SM_ADU_REPLAY_H1,  maxwell_sm_adu_replay_h1_enc_str_1,  maxwell_sm_adu_replay_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_adu_replay_h1_enc_str_4}, //    "adu_replay_h1"
    { MAXWELL_SM_PQ_READS_FOR_SHM_H0,  maxwell_sm_pq_reads_for_shm_h0_enc_str_1,  maxwell_sm_pq_reads_for_shm_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pq_reads_for_shm_h0_enc_str_4}, //    "pq_reads_for_shm_h0"
    { MAXWELL_SM_PQ_READS_FOR_PIXOUT_H0,  maxwell_sm_pq_reads_for_pixout_h0_enc_str_1,  maxwell_sm_pq_reads_for_pixout_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pq_reads_for_pixout_h0_enc_str_4}, //    "pq_reads_for_pixout_h0"
    { MAXWELL_SM_PQ_READS_FOR_TEX_H0,  maxwell_sm_pq_reads_for_tex_h0_enc_str_1,  maxwell_sm_pq_reads_for_tex_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pq_reads_for_tex_h0_enc_str_4}, //    "pq_reads_for_tex_h0"
    { MAXWELL_SM_PQ_READS_FOR_SHM_STOLEN_H0,  maxwell_sm_pq_reads_for_shm_stolen_h0_enc_str_1,  maxwell_sm_pq_reads_for_shm_stolen_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pq_reads_for_shm_stolen_h0_enc_str_4}, //    "pq_reads_for_shm_stolen_h0"
    { MAXWELL_SM_PQ_READS_FOR_SHM_H1,  maxwell_sm_pq_reads_for_shm_h1_enc_str_1,  maxwell_sm_pq_reads_for_shm_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pq_reads_for_shm_h1_enc_str_4}, //    "pq_reads_for_shm_h1"
    { MAXWELL_SM_PQ_READS_FOR_PIXOUT_H1,  maxwell_sm_pq_reads_for_pixout_h1_enc_str_1,  maxwell_sm_pq_reads_for_pixout_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pq_reads_for_pixout_h1_enc_str_4}, //    "pq_reads_for_pixout_h1"
    { MAXWELL_SM_PQ_READS_FOR_TEX_H1,  maxwell_sm_pq_reads_for_tex_h1_enc_str_1,  maxwell_sm_pq_reads_for_tex_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pq_reads_for_tex_h1_enc_str_4}, //    "pq_reads_for_tex_h1"
    { MAXWELL_SM_PQ_READS_FOR_SHM_STOLEN_H1,  maxwell_sm_pq_reads_for_shm_stolen_h1_enc_str_1,  maxwell_sm_pq_reads_for_shm_stolen_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pq_reads_for_shm_stolen_h1_enc_str_4}, //    "pq_reads_for_shm_stolen_h1"
    { MAXWELL_SM_IDC_HIT,  maxwell_sm_idc_hit_enc_str_1,  maxwell_sm_idc_hit_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_idc_hit_enc_str_4}, //    "idc_hit"
    { MAXWELL_SM_IDC_FULL_TAG,  maxwell_sm_idc_full_tag_enc_str_1,  maxwell_sm_idc_full_tag_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_idc_full_tag_enc_str_4}, //    "idc_full_tag"
    { MAXWELL_SM_IDC_TRUE_MISS,  maxwell_sm_idc_true_miss_enc_str_1,  maxwell_sm_idc_true_miss_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_idc_true_miss_enc_str_4}, //    "idc_true_miss"
    { MAXWELL_SM_IDC_COVERED_MISS,  maxwell_sm_idc_covered_miss_enc_str_1,  maxwell_sm_idc_covered_miss_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_idc_covered_miss_enc_str_4}, //    "idc_covered_miss"
    { MAXWELL_SM_IDC_DIVERGENCE_REPLAY_H0,  maxwell_sm_idc_divergence_replay_h0_enc_str_1,  maxwell_sm_idc_divergence_replay_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_idc_divergence_replay_h0_enc_str_4}, //    "idc_divergence_replay_h0"
    { MAXWELL_SM_IDC_DIVERGENT_INSTRUCTION_H0,  maxwell_sm_idc_divergent_instruction_h0_enc_str_1,  maxwell_sm_idc_divergent_instruction_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_idc_divergent_instruction_h0_enc_str_4}, //    "idc_divergent_instruction_h0"
    { MAXWELL_SM_IDC_DIVERGENCE_REPLAY_H1,  maxwell_sm_idc_divergence_replay_h1_enc_str_1,  maxwell_sm_idc_divergence_replay_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_idc_divergence_replay_h1_enc_str_4}, //    "idc_divergence_replay_h1"
    { MAXWELL_SM_IDC_DIVERGENT_INSTRUCTION_H1,  maxwell_sm_idc_divergent_instruction_h1_enc_str_1,  maxwell_sm_idc_divergent_instruction_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_idc_divergent_instruction_h1_enc_str_4}, //    "idc_divergent_instruction_h1"
    { MAXWELL_SM_MEMBAR_EXECUTED,  maxwell_sm_membar_executed_enc_str_1,  maxwell_sm_membar_executed_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_membar_executed_enc_str_4}, //    "membar_executed"
    { MAXWELL_SM_MEMBAR_PENDING,  maxwell_sm_membar_pending_enc_str_1,  maxwell_sm_membar_pending_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_membar_executed_enc_str_4}, //    "membar_pending"
    { MAXWELL_SM_MEMBAR_SENT_TO_TEX,  maxwell_sm_membar_sent_to_tex_enc_str_1,  maxwell_sm_membar_sent_to_tex_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_membar_sent_to_tex_enc_str_4}, //    "membar_sent_to_tex"
    { MAXWELL_SM_MEMBAR_CTA_SENT_TO_TEX_H0,  maxwell_sm_membar_cta_sent_to_tex_h0_enc_str_1,  maxwell_sm_membar_cta_sent_to_tex_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_membar_cta_sent_to_tex_h0_enc_str_4}, //    "membar_cta_sent_to_tex_h0"
    { MAXWELL_SM_MEMBAR_CTA_SENT_TO_TEX_H1,  maxwell_sm_membar_cta_sent_to_tex_h1_enc_str_1,  maxwell_sm_membar_cta_sent_to_tex_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_membar_cta_sent_to_tex_h0_enc_str_4}, //    "membar_cta_sent_to_tex_h1"
    { MAXWELL_SM_MEMBAR_CTA_SYNTHETIC,  maxwell_sm_membar_cta_synthetic_enc_str_1,  maxwell_sm_membar_cta_synthetic_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_membar_cta_synthetic_enc_str_4}, //    "membar_cta_synthetic"
    { MAXWELL_SM_PIXOUT_QUADS_DRAINED,  maxwell_sm_pixout_quads_drained_enc_str_1,  maxwell_sm_pixout_quads_drained_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pixout_quads_drained_enc_str_4}, //    "pixout_quads_drained"
    { MAXWELL_SM_HALF_WARPS_KILLED_BY_SHADER,  maxwell_sm_half_warps_killed_by_shader_enc_str_1,  maxwell_sm_half_warps_killed_by_shader_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_half_warps_killed_by_shader_enc_str_4}, //    "half_warps_killed_by_shader"
    { MAXWELL_SM_QUADS_KILLED_BY_SHADER,  maxwell_sm_quads_killed_by_shader_enc_str_1,  maxwell_sm_quads_killed_by_shader_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_quads_killed_by_shader_enc_str_4}, //    "quads_killed_by_shader"
    { MAXWELL_SM_WARPS_KILLED_BY_SHADER,  maxwell_sm_warps_killed_by_shader_enc_str_1,  maxwell_sm_warps_killed_by_shader_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warps_killed_by_shader_enc_str_4}, //    "warps_killed_by_shader"
    { MAXWELL_SM_PIXELS_KILLED_SHADERCOVG,  maxwell_sm_pixels_killed_shadercovg_enc_str_1,  maxwell_sm_pixels_killed_shadercovg_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pixels_killed_shadercovg_enc_str_4}, //    "pixels_killed_shadercovg"
    { MAXWELL_SM_SM2GPM_OUTPUT_STALL,  maxwell_sm_sm2gpm_output_stall_enc_str_1,  maxwell_sm_sm2gpm_output_stall_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_sm2gpm_output_stall_enc_str_4}, //    "sm2gpm_output_stall"
    { MAXWELL_SM_MIO_ISBE_WRITE,  maxwell_sm_mio_isbe_write_enc_str_1,  maxwell_sm_mio_isbe_write_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_mio_isbe_write_enc_str_4}, //    "mio_isbe_write"
    { MAXWELL_SM_MIO_ISBE_READ,  maxwell_sm_mio_isbe_read_enc_str_1,  maxwell_sm_mio_isbe_read_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_mio_isbe_read_enc_str_4}, //    "mio_isbe_read"
    { MAXWELL_SM_MIO_SM_STALLED_DUE_TO_PE_H0,  maxwell_sm_mio_sm_stalled_due_to_pe_h0_enc_str_1,  maxwell_sm_mio_sm_stalled_due_to_pe_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_mio_sm_stalled_due_to_pe_h0_enc_str_4}, //    "mio_sm_stalled_due_to_pe_h0"
    { MAXWELL_SM_MIO_SM_STALLED_DUE_TO_PE_H1,  maxwell_sm_mio_sm_stalled_due_to_pe_h1_enc_str_1,  maxwell_sm_mio_sm_stalled_due_to_pe_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_mio_sm_stalled_due_to_pe_h0_enc_str_4}, //    "mio_sm_stalled_due_to_pe_h1"
    { MAXWELL_SM_PE2MIO_ISBE_READ_REQ,  maxwell_sm_pe2mio_isbe_read_req_enc_str_1,  maxwell_sm_pe2mio_isbe_read_req_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pe2mio_isbe_read_req_enc_str_4}, //    "pe2mio_isbe_read_req"
    { MAXWELL_SM_PE2MIO_ISBE_WRITE_REQ,  maxwell_sm_pe2mio_isbe_write_req_enc_str_1,  maxwell_sm_pe2mio_isbe_write_req_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pe2mio_isbe_write_req_enc_str_4}, //    "pe2mio_isbe_write_req"
    { MAXWELL_SM_PE2MIO_TRAM_WRITE,  maxwell_sm_pe2mio_tram_write_enc_str_1,  maxwell_sm_pe2mio_tram_write_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pe2mio_tram_write_enc_str_4}, //    "pe2mio_tram_write"
    { MAXWELL_SM_PE_ISBE_WR_DELAYED_DUE_TO_CAMPING,  maxwell_sm_pe_isbe_wr_delayed_due_to_camping_enc_str_1,  maxwell_sm_pe_isbe_wr_delayed_due_to_camping_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pe_isbe_wr_delayed_due_to_camping_enc_str_4}, //    "pe_isbe_wr_delayed_due_to_camping"
    { MAXWELL_SM_PE_TRAM_WR_DELAYED_AND_LOST_THROUGHPUT,  maxwell_sm_pe_tram_wr_delayed_and_lost_throughput_enc_str_1,  maxwell_sm_pe_tram_wr_delayed_and_lost_throughput_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pe_tram_wr_delayed_and_lost_throughput_enc_str_4}, //    "pe_tram_wr_delayed_and_lost_throughput"
    { MAXWELL_SM_PE_TRAM_WR_DELAYED_DUE_TO_CAMPING,  maxwell_sm_pe_tram_wr_delayed_due_to_camping_enc_str_1,  maxwell_sm_pe_tram_wr_delayed_due_to_camping_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pe_tram_wr_delayed_due_to_camping_enc_str_4}, //    "pe_tram_wr_delayed_due_to_camping"
    { MAXWELL_SM_SMM2TEX_DATA_LG_COUNT_H0,  maxwell_sm_smm2tex_data_lg_count_h0_enc_str_1,  maxwell_sm_smm2tex_data_lg_count_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_smm2tex_data_lg_count_h0_enc_str_4}, //    "smm2tex_data_lg_count_h0"
    { MAXWELL_SM_SMM2TEX_DATA_TEX_COUNT_H0,  maxwell_sm_smm2tex_data_tex_count_h0_enc_str_1,  maxwell_sm_smm2tex_data_tex_count_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_smm2tex_data_tex_count_h0_enc_str_4}, //    "smm2tex_data_tex_count_h0"
    { MAXWELL_SM_SMM2TEX_DATA_LG_COUNT_H1,  maxwell_sm_smm2tex_data_lg_count_h1_enc_str_1,  maxwell_sm_smm2tex_data_lg_count_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_smm2tex_data_lg_count_h0_enc_str_4}, //    "smm2tex_data_lg_count_h1"
    { MAXWELL_SM_SMM2TEX_DATA_TEX_COUNT_H1,  maxwell_sm_smm2tex_data_tex_count_h1_enc_str_1,  maxwell_sm_smm2tex_data_tex_count_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_smm2tex_data_tex_count_h1_enc_str_4}, //    "smm2tex_data_tex_count_h1"
    { MAXWELL_SM_MIO_CANT_DISPATCH_LSU_ADU_OVER_SHM_H0,  maxwell_sm_mio_cant_dispatch_lsu_adu_over_shm_h0_enc_str_1,  maxwell_sm_mio_cant_dispatch_lsu_adu_over_shm_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_mio_cant_dispatch_lsu_adu_over_shm_h0_enc_str_4}, //    "mio_cant_dispatch_lsu_adu_over_shm_h0"
    { MAXWELL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_ADU_H0,  maxwell_sm_mio_cant_dispatch_lsu_pixout_over_adu_h0_enc_str_1,  maxwell_sm_mio_cant_dispatch_lsu_pixout_over_adu_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_mio_cant_dispatch_lsu_pixout_over_adu_h0_enc_str_4}, //    "mio_cant_dispatch_lsu_pixout_over_adu_h0"
    { MAXWELL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_SHM_H0,  maxwell_sm_mio_cant_dispatch_lsu_pixout_over_shm_h0_enc_str_1,  maxwell_sm_mio_cant_dispatch_lsu_pixout_over_shm_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_mio_cant_dispatch_lsu_pixout_over_shm_h0_enc_str_4}, //    "mio_cant_dispatch_lsu_pixout_over_shm_h0"
    { MAXWELL_SM_MIO_CANT_DISPATCH_LSU_ADU_OVER_SHM_H1,  maxwell_sm_mio_cant_dispatch_lsu_adu_over_shm_h1_enc_str_1,  maxwell_sm_mio_cant_dispatch_lsu_adu_over_shm_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_mio_cant_dispatch_lsu_adu_over_shm_h0_enc_str_4}, //    "mio_cant_dispatch_lsu_adu_over_shm_h1"
    { MAXWELL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_ADU_H1,  maxwell_sm_mio_cant_dispatch_lsu_pixout_over_adu_h1_enc_str_1,  maxwell_sm_mio_cant_dispatch_lsu_pixout_over_adu_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_mio_cant_dispatch_lsu_pixout_over_adu_h0_enc_str_4}, //    "mio_cant_dispatch_lsu_pixout_over_adu_h1"
    { MAXWELL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_SHM_H1,  maxwell_sm_mio_cant_dispatch_lsu_pixout_over_shm_h1_enc_str_1,  maxwell_sm_mio_cant_dispatch_lsu_pixout_over_shm_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_mio_cant_dispatch_lsu_pixout_over_shm_h0_enc_str_4}, //    "mio_cant_dispatch_lsu_pixout_over_shm_h1"
    { MAXWELL_SM_IDC_MISSES_OUTSTANDING,  maxwell_sm_idc_misses_outstanding_enc_str_1,  maxwell_sm_idc_misses_outstanding_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_idc_misses_outstanding_enc_str_4}, //    "idc_misses_outstanding"
    { MAXWELL_SM_PQ_FULL_H0,  maxwell_sm_pq_full_h0_enc_str_1,  maxwell_sm_pq_full_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pq_full_h0_enc_str_4}, //    "pq_full_h0"
    { MAXWELL_SM_PQ_FULL_H1,  maxwell_sm_pq_full_h1_enc_str_1,  maxwell_sm_pq_full_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pq_full_h1_enc_str_4}, //    "pq_full_h1"
    { MAXWELL_SM_PIX_PQ_FULL_H0,  maxwell_sm_pix_pq_full_h0_enc_str_1,  maxwell_sm_pix_pq_full_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pix_pq_full_h0_enc_str_4}, //    "pix_pq_full_h0"
    { MAXWELL_SM_PIX_PQ_FULL_H1,  maxwell_sm_pix_pq_full_h1_enc_str_1,  maxwell_sm_pix_pq_full_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pix_pq_full_h1_enc_str_4}, //    "pix_pq_full_h1"
    { MAXWELL_SM_SHM_PQ_FULL_H0,  maxwell_sm_shm_pq_full_h0_enc_str_1,  maxwell_sm_shm_pq_full_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_shm_pq_full_h0_enc_str_4}, //    "shm_pq_full_h0"
    { MAXWELL_SM_SHM_PQ_FULL_H1,  maxwell_sm_shm_pq_full_h1_enc_str_1,  maxwell_sm_shm_pq_full_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_shm_pq_full_h1_enc_str_4}, //    "shm_pq_full_h1"
    { MAXWELL_SM_TEX_PQ_FULL_H0,  maxwell_sm_tex_pq_full_h0_enc_str_1,  maxwell_sm_tex_pq_full_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_tex_pq_full_h0_enc_str_4}, //    "tex_pq_full_h0"
    { MAXWELL_SM_TEX_PQ_FULL_H1,  maxwell_sm_tex_pq_full_h1_enc_str_1,  maxwell_sm_tex_pq_full_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_tex_pq_full_h1_enc_str_4}, //    "tex_pq_full_h1"
    { MAXWELL_SM_PQ_WRITE_BACK_LSU_STALL_H0,  maxwell_sm_pq_write_back_lsu_stall_h0_enc_str_1,  maxwell_sm_pq_write_back_lsu_stall_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pq_write_back_lsu_stall_h0_enc_str_4}, //    "pq_write_back_lsu_stall_h0"
    { MAXWELL_SM_PQ_WRITE_BACK_TEX_STALL_H0,  maxwell_sm_pq_write_back_tex_stall_h0_enc_str_1,  maxwell_sm_pq_write_back_tex_stall_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pq_write_back_tex_stall_h0_enc_str_4}, //    "pq_write_back_tex_stall_h0"
    { MAXWELL_SM_PQ_WRITE_BACK_LSU_STALL_H1,  maxwell_sm_pq_write_back_lsu_stall_h1_enc_str_1,  maxwell_sm_pq_write_back_lsu_stall_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pq_write_back_lsu_stall_h1_enc_str_4}, //    "pq_write_back_lsu_stall_h1"
    { MAXWELL_SM_PQ_WRITE_BACK_TEX_STALL_H1,  maxwell_sm_pq_write_back_tex_stall_h1_enc_str_1,  maxwell_sm_pq_write_back_tex_stall_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pq_write_back_tex_stall_h1_enc_str_4}, //    "pq_write_back_tex_stall_h1"
    { MAXWELL_SM_LSU_IQ_FIFO_FULL_H0,  maxwell_sm_lsu_iq_fifo_full_h0_enc_str_1,  maxwell_sm_lsu_iq_fifo_full_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_lsu_iq_fifo_full_h0_enc_str_4}, //    "lsu_iq_fifo_full_h0"
    { MAXWELL_SM_TEX_IQ_FIFO_FULL_H0,  maxwell_sm_tex_iq_fifo_full_h0_enc_str_1,  maxwell_sm_tex_iq_fifo_full_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_tex_iq_fifo_full_h0_enc_str_4}, //    "tex_iq_fifo_full_h0"
    { MAXWELL_SM_PIX_IQ_FIFO_FULL_H0,  maxwell_sm_pix_iq_fifo_full_h0_enc_str_1,  maxwell_sm_pix_iq_fifo_full_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pix_iq_fifo_full_h0_enc_str_4}, //    "pix_iq_fifo_full_h0"
    { MAXWELL_SM_RTY_IQ_FIFO_FULL_H0,  maxwell_sm_rty_iq_fifo_full_h0_enc_str_1,  maxwell_sm_rty_iq_fifo_full_h0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_rty_iq_fifo_full_h0_enc_str_4}, //    "rty_iq_fifo_full_h0"
    { MAXWELL_SM_LSU_IQ_FIFO_FULL_H1,  maxwell_sm_lsu_iq_fifo_full_h1_enc_str_1,  maxwell_sm_lsu_iq_fifo_full_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_lsu_iq_fifo_full_h1_enc_str_4}, //    "lsu_iq_fifo_full_h1"
    { MAXWELL_SM_TEX_IQ_FIFO_FULL_H1,  maxwell_sm_tex_iq_fifo_full_h1_enc_str_1,  maxwell_sm_tex_iq_fifo_full_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_tex_iq_fifo_full_h1_enc_str_4}, //    "tex_iq_fifo_full_h1"
    { MAXWELL_SM_PIX_IQ_FIFO_FULL_H1,  maxwell_sm_pix_iq_fifo_full_h1_enc_str_1,  maxwell_sm_pix_iq_fifo_full_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_pix_iq_fifo_full_h1_enc_str_4}, //    "pix_iq_fifo_full_h1"
    { MAXWELL_SM_RTY_IQ_FIFO_FULL_H1,  maxwell_sm_rty_iq_fifo_full_h1_enc_str_1,  maxwell_sm_rty_iq_fifo_full_h1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_rty_iq_fifo_full_h1_enc_str_4}, //    "rty_iq_fifo_full_h1"
    { MAXWELL_TEX0_STORE_SECTOR_MISSES_GLOBAL,           maxwell_tex0_store_sector_misses_global_enc_str_1,           maxwell_tex0_store_sector_misses_global_enc_str_1,           CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_store_sector_misses_global_enc_str_1          },
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_GLOBAL,           maxwell_tex1_store_sector_misses_global_enc_str_1,           maxwell_tex1_store_sector_misses_global_enc_str_1,           CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_store_sector_misses_global_enc_str_1          },
    { MAXWELL_TEX0_STORE_SECTOR_MISSES_LOCAL,            maxwell_tex0_store_sector_misses_local_enc_str_1,            maxwell_tex0_store_sector_misses_local_enc_str_1,            CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_store_sector_misses_local_enc_str_1           },
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_LOCAL,            maxwell_tex1_store_sector_misses_local_enc_str_1,            maxwell_tex1_store_sector_misses_local_enc_str_1,            CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_store_sector_misses_local_enc_str_1           },
    { MAXWELL_TEX0_STORE_SECTOR_MISSES_SUST,             maxwell_tex0_store_sector_misses_sust_enc_str_1,             maxwell_tex0_store_sector_misses_sust_enc_str_1,             CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_store_sector_misses_sust_enc_str_1            },
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_SUST,             maxwell_tex1_store_sector_misses_sust_enc_str_1,             maxwell_tex1_store_sector_misses_sust_enc_str_1,             CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_store_sector_misses_sust_enc_str_1            },
    { MAXWELL_TEX0_STORE_SECTOR_MISSES_ATOM_OR_ATOM_CAS, maxwell_tex0_store_sector_misses_atom_or_atom_cas_enc_str_1, maxwell_tex0_store_sector_misses_atom_or_atom_cas_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_store_sector_misses_atom_or_atom_cas_enc_str_1},
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_ATOM_OR_ATOM_CAS, maxwell_tex1_store_sector_misses_atom_or_atom_cas_enc_str_1, maxwell_tex1_store_sector_misses_atom_or_atom_cas_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_store_sector_misses_atom_or_atom_cas_enc_str_1},
    { MAXWELL_TEX0_STORE_SECTOR_MISSES_RED,              maxwell_tex0_store_sector_misses_red_enc_str_1,              maxwell_tex0_store_sector_misses_red_enc_str_1,              CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_store_sector_misses_red_enc_str_1             },
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_RED,              maxwell_tex1_store_sector_misses_red_enc_str_1,              maxwell_tex1_store_sector_misses_red_enc_str_1,              CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_store_sector_misses_red_enc_str_1             },
    { MAXWELL_TEX0_INPUT_ST_SECTOR_SUM,  maxwell_tex0_input_st_sector_sum_enc_str_1, maxwell_tex0_input_st_sector_sum_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_input_st_sector_sum_enc_str_1},
    { MAXWELL_TEX1_INPUT_ST_SECTOR_SUM,  maxwell_tex1_input_st_sector_sum_enc_str_1, maxwell_tex1_input_st_sector_sum_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_input_st_sector_sum_enc_str_1},
    { MAXWELL_TEX0_INPUT_WR_SECTOR_SUM,  maxwell_tex0_input_wr_sector_sum_enc_str_1, maxwell_tex0_input_wr_sector_sum_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_input_wr_sector_sum_enc_str_1},
    { MAXWELL_TEX1_INPUT_WR_SECTOR_SUM,  maxwell_tex1_input_wr_sector_sum_enc_str_1, maxwell_tex1_input_wr_sector_sum_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_input_wr_sector_sum_enc_str_1},
    { MAXWELL_TEX0_OUTPUT_ST_SECTOR_SUM, maxwell_tex0_output_st_sector_sum_enc_str_1, maxwell_tex0_output_st_sector_sum_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_output_st_sector_sum_enc_str_1},
    { MAXWELL_TEX1_OUTPUT_ST_SECTOR_SUM, maxwell_tex1_output_st_sector_sum_enc_str_1, maxwell_tex1_output_st_sector_sum_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_output_st_sector_sum_enc_str_1},
    { MAXWELL_TEX0_OUTPUT_WR_SECTOR_SUM, maxwell_tex0_output_wr_sector_sum_enc_str_1, maxwell_tex0_output_wr_sector_sum_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_output_wr_sector_sum_enc_str_1},
    { MAXWELL_TEX1_OUTPUT_WR_SECTOR_SUM, maxwell_tex1_output_wr_sector_sum_enc_str_1, maxwell_tex1_output_wr_sector_sum_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_output_wr_sector_sum_enc_str_1},
    { MAXWELL_TEX0_RETURN_PACKET_COUNT, maxwell_tex0_return_packet_count_enc_str_1, maxwell_tex0_return_packet_count_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_return_packet_count_enc_str_4},
    { MAXWELL_TEX1_RETURN_PACKET_COUNT, maxwell_tex1_return_packet_count_enc_str_1, maxwell_tex1_return_packet_count_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_return_packet_count_enc_str_4},

    { MAXWELL_TEX0_STORE_SECTOR_MISSES_SUST_NONATOM,     maxwell_tex0_store_sector_misses_sust_nonatom_enc_str_1,     maxwell_tex0_store_sector_misses_sust_nonatom_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_store_sector_misses_sust_nonatom_enc_str_1    },
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_SUST_NONATOM,     maxwell_tex1_store_sector_misses_sust_nonatom_enc_str_1,     maxwell_tex1_store_sector_misses_sust_nonatom_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_store_sector_misses_sust_nonatom_enc_str_1    },
    { MAXWELL_TEX0_STORE_SECTOR_MISSES_SUST_ATOM_OR_ATOM_CAS,     maxwell_tex0_store_sector_misses_sust_atom_or_atom_cas_enc_str_1,     maxwell_tex0_store_sector_misses_sust_atom_or_atom_cas_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_store_sector_misses_sust_atom_or_atom_cas_enc_str_1    },
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_SUST_ATOM_OR_ATOM_CAS,     maxwell_tex1_store_sector_misses_sust_atom_or_atom_cas_enc_str_1,     maxwell_tex1_store_sector_misses_sust_atom_or_atom_cas_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_store_sector_misses_sust_atom_or_atom_cas_enc_str_1    },
    { MAXWELL_TEX0_STORE_SECTOR_MISSES_SUST_RED,     maxwell_tex0_store_sector_misses_sust_red_enc_str_1,     maxwell_tex0_store_sector_misses_sust_red_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_store_sector_misses_sust_red_enc_str_1    },
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_SUST_RED,     maxwell_tex1_store_sector_misses_sust_red_enc_str_1,     maxwell_tex1_store_sector_misses_sust_red_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_store_sector_misses_sust_red_enc_str_1    },
    { MAXWELL_TEX0_WRITE_SECTORS_GLOBAL_NONATOM, maxwell_tex0_write_sectors_global_nonatom_enc_str_1, maxwell_tex0_write_sectors_global_nonatom_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_write_sectors_global_nonatom_enc_str_1},
    { MAXWELL_TEX1_WRITE_SECTORS_GLOBAL_NONATOM, maxwell_tex1_write_sectors_global_nonatom_enc_str_1, maxwell_tex1_write_sectors_global_nonatom_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_write_sectors_global_nonatom_enc_str_1},
    { MAXWELL_TEX0_WRITE_SECTORS_GLOBAL_ATOM, maxwell_tex0_write_sectors_global_atom_enc_str_1, maxwell_tex0_write_sectors_global_atom_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_write_sectors_global_atom_enc_str_1},
    { MAXWELL_TEX1_WRITE_SECTORS_GLOBAL_ATOM, maxwell_tex1_write_sectors_global_atom_enc_str_1, maxwell_tex1_write_sectors_global_atom_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_write_sectors_global_atom_enc_str_1},
    { MAXWELL_TEX0_WRITE_SECTORS_GLOBAL_RED, maxwell_tex0_write_sectors_global_red_enc_str_1, maxwell_tex0_write_sectors_global_red_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_write_sectors_global_red_enc_str_1},
    { MAXWELL_TEX1_WRITE_SECTORS_GLOBAL_RED, maxwell_tex1_write_sectors_global_red_enc_str_1, maxwell_tex1_write_sectors_global_red_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_write_sectors_global_red_enc_str_1},
    { MAXWELL_TEX0_WRITE_SECTORS_LOCAL_ST, maxwell_tex0_write_sectors_local_st_enc_str_1, maxwell_tex0_write_sectors_local_st_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_write_sectors_local_st_enc_str_1},
    { MAXWELL_TEX1_WRITE_SECTORS_LOCAL_ST, maxwell_tex1_write_sectors_local_st_enc_str_1, maxwell_tex1_write_sectors_local_st_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_write_sectors_local_st_enc_str_1},
    { MAXWELL_TEX0_TEX_QUAD_COUNT, maxwell_tex0_tex_quad_count_enc_str_1, maxwell_tex0_tex_quad_count_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_tex_quad_count_enc_str_1},
    { MAXWELL_TEX1_TEX_QUAD_COUNT, maxwell_tex1_tex_quad_count_enc_str_1, maxwell_tex1_tex_quad_count_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_tex_quad_count_enc_str_1},
    { MAXWELL_TEX0_GLOBAL_LD_REQUESTS_8BIT , maxwell_tex0_global_ld_requests_8bit_enc_str_1, maxwell_tex0_global_ld_requests_8bit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_ld_requests_8bit_enc_str_1},
    { MAXWELL_TEX1_GLOBAL_LD_REQUESTS_8BIT , maxwell_tex1_global_ld_requests_8bit_enc_str_1, maxwell_tex1_global_ld_requests_8bit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_ld_requests_8bit_enc_str_1},
    { MAXWELL_TEX0_GLOBAL_LD_REQUESTS_16BIT , maxwell_tex0_global_ld_requests_16bit_enc_str_1, maxwell_tex0_global_ld_requests_16bit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_ld_requests_16bit_enc_str_1},
    { MAXWELL_TEX1_GLOBAL_LD_REQUESTS_16BIT , maxwell_tex1_global_ld_requests_16bit_enc_str_1, maxwell_tex1_global_ld_requests_16bit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_ld_requests_16bit_enc_str_1},
    { MAXWELL_TEX0_GLOBAL_LD_REQUESTS_FP16X2 , maxwell_tex0_global_ld_requests_fp16x2_enc_str_1, maxwell_tex0_global_ld_requests_fp16x2_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_ld_requests_fp16x2_enc_str_1},
    { MAXWELL_TEX1_GLOBAL_LD_REQUESTS_FP16X2 , maxwell_tex1_global_ld_requests_fp16x2_enc_str_1, maxwell_tex1_global_ld_requests_fp16x2_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_ld_requests_fp16x2_enc_str_1},
    { MAXWELL_TEX0_GLOBAL_LD_REQUESTS_32BIT , maxwell_tex0_global_ld_requests_32bit_enc_str_1, maxwell_tex0_global_ld_requests_32bit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_ld_requests_32bit_enc_str_1},
    { MAXWELL_TEX1_GLOBAL_LD_REQUESTS_32BIT , maxwell_tex1_global_ld_requests_32bit_enc_str_1, maxwell_tex1_global_ld_requests_32bit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_ld_requests_32bit_enc_str_1},
    { MAXWELL_TEX0_GLOBAL_LD_REQUESTS_64BIT , maxwell_tex0_global_ld_requests_64bit_enc_str_1, maxwell_tex0_global_ld_requests_64bit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_ld_requests_64bit_enc_str_1},
    { MAXWELL_TEX1_GLOBAL_LD_REQUESTS_64BIT , maxwell_tex1_global_ld_requests_64bit_enc_str_1, maxwell_tex1_global_ld_requests_64bit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_ld_requests_64bit_enc_str_1},
    { MAXWELL_TEX0_GLOBAL_LD_REQUESTS_128BIT , maxwell_tex0_global_ld_requests_128bit_enc_str_1, maxwell_tex0_global_ld_requests_128bit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_global_ld_requests_128bit_enc_str_1},
    { MAXWELL_TEX1_GLOBAL_LD_REQUESTS_128BIT , maxwell_tex1_global_ld_requests_128bit_enc_str_1, maxwell_tex1_global_ld_requests_128bit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_global_ld_requests_128bit_enc_str_1},


#if NVCFG(GLOBAL_GPU_FAMILY_GM20X) || NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
    { MAXWELL_SM_WARP_CANT_ISSUE_ON_DECK_LONG_SCOREBOARD,  maxwell_sm_warp_cant_issue_on_deck_long_scoreboard_enc_str_2,  maxwell_sm_warp_cant_issue_on_deck_long_scoreboard_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  maxwell_sm_warp_cant_issue_on_deck_long_scoreboard_enc_str_4}, //    "warp_cant_issue_on_deck_long_scoreboard"
    { MAXWELL_MMU_GPCL2_TLB_HIT,  maxwell_mmu_gpcl2_tlb_hit_enc_str_1, maxwell_mmu_gpcl2_tlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_mmu_gpcl2_tlb_hit_enc_str_2},
    { MAXWELL_MMU_GPCL2_TLB_MISS,  maxwell_mmu_gpcl2_tlb_miss_enc_str_1, maxwell_mmu_gpcl2_tlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_mmu_gpcl2_tlb_miss_enc_str_2},
    { MAXWELL_SM_TRAP_CLEARING_IDE,  maxwell_sm_trap_clearing_ide_enc_str_1, maxwell_sm_trap_clearing_ide_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_sm_trap_clearing_ide_enc_str_2},
    { MAXWELL_PROFILER_FIRST,  maxwell_profiler_first_enc_str_1, maxwell_profiler_first_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_profiler_first_enc_str_2},
    { MAXWELL_PROFILER_VALID,  maxwell_profiler_valid_enc_str_1, maxwell_profiler_valid_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_profiler_valid_enc_str_2},
    { MAXWELL_TEX0_STORE_SECTOR_MISSES_ATOM_CAS, maxwell_tex0_store_sector_misses_atom_cas_enc_str_1, maxwell_tex0_store_sector_misses_atom_cas_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_store_sector_misses_atom_cas_enc_str_1},
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_ATOM_CAS, maxwell_tex1_store_sector_misses_atom_cas_enc_str_1, maxwell_tex1_store_sector_misses_atom_cas_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_store_sector_misses_atom_cas_enc_str_1},
    { MAXWELL_TEX0_STORE_SECTOR_MISSES_ATOM, maxwell_tex0_store_sector_misses_atom_enc_str_1, maxwell_tex0_store_sector_misses_atom_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_store_sector_misses_atom_enc_str_1},
    { MAXWELL_TEX1_STORE_SECTOR_MISSES_ATOM, maxwell_tex1_store_sector_misses_atom_enc_str_1, maxwell_tex1_store_sector_misses_atom_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_store_sector_misses_atom_enc_str_1},

    { MAXWELL_TEX0_STORE_SECTOR_QURIES_GLOBAL,   maxwell_tex0_store_sector_queries_global_enc_str_1,   maxwell_tex0_store_sector_queries_global_enc_str_1,   CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_store_sector_queries_global_enc_str_1},
    { MAXWELL_TEX1_STORE_SECTOR_QURIES_GLOBAL,   maxwell_tex1_store_sector_queries_global_enc_str_1,   maxwell_tex1_store_sector_queries_global_enc_str_1,   CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_store_sector_queries_global_enc_str_1},
    { MAXWELL_TEX0_STORE_SECTOR_QURIES_LOCAL,    maxwell_tex0_store_sector_queries_local_enc_str_1,    maxwell_tex0_store_sector_queries_local_enc_str_1,    CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_store_sector_queries_local_enc_str_1},
    { MAXWELL_TEX1_STORE_SECTOR_QURIES_LOCAL,    maxwell_tex1_store_sector_queries_local_enc_str_1,    maxwell_tex1_store_sector_queries_local_enc_str_1,    CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_store_sector_queries_local_enc_str_1},
    { MAXWELL_TEX0_STORE_SECTOR_QURIES_ATOM_CAS, maxwell_tex0_store_sector_queries_atom_cas_enc_str_1, maxwell_tex0_store_sector_queries_atom_cas_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_store_sector_queries_atom_cas_enc_str_1},
    { MAXWELL_TEX1_STORE_SECTOR_QURIES_ATOM_CAS, maxwell_tex1_store_sector_queries_atom_cas_enc_str_1, maxwell_tex1_store_sector_queries_atom_cas_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_store_sector_queries_atom_cas_enc_str_1},
    { MAXWELL_TEX0_STORE_SECTOR_QURIES_ATOM,     maxwell_tex0_store_sector_queries_atom_enc_str_1,     maxwell_tex0_store_sector_queries_atom_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_store_sector_queries_atom_enc_str_1},
    { MAXWELL_TEX1_STORE_SECTOR_QURIES_ATOM,     maxwell_tex1_store_sector_queries_atom_enc_str_1,     maxwell_tex1_store_sector_queries_atom_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_store_sector_queries_atom_enc_str_1},
    { MAXWELL_TEX0_STORE_SECTOR_QURIES_RED,     maxwell_tex0_store_sector_queries_red_enc_str_1,     maxwell_tex0_store_sector_queries_red_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_store_sector_queries_red_enc_str_1},
    { MAXWELL_TEX1_STORE_SECTOR_QURIES_RED,     maxwell_tex1_store_sector_queries_red_enc_str_1,     maxwell_tex1_store_sector_queries_red_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_store_sector_queries_red_enc_str_1},

    { MAXWELL_TEX0_LOAD_SECTOR_QURIES_GLOBAL,   maxwell_tex0_load_sector_queries_global_enc_str_1,   maxwell_tex0_load_sector_queries_global_enc_str_1,   CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_load_sector_queries_global_enc_str_1},
    { MAXWELL_TEX1_LOAD_SECTOR_QURIES_GLOBAL,   maxwell_tex1_load_sector_queries_global_enc_str_1,   maxwell_tex1_load_sector_queries_global_enc_str_1,   CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_load_sector_queries_global_enc_str_1},
    { MAXWELL_TEX0_LOAD_SECTOR_QURIES_LOCAL,    maxwell_tex0_load_sector_queries_local_enc_str_1,    maxwell_tex0_load_sector_queries_local_enc_str_1,    CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_load_sector_queries_local_enc_str_1},
    { MAXWELL_TEX1_LOAD_SECTOR_QURIES_LOCAL,    maxwell_tex1_load_sector_queries_local_enc_str_1,    maxwell_tex1_load_sector_queries_local_enc_str_1,    CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_load_sector_queries_local_enc_str_1},
    { MAXWELL_TEX0_LOAD_SECTOR_QURIES_ATOM_CAS, maxwell_tex0_load_sector_queries_atom_cas_enc_str_1, maxwell_tex0_load_sector_queries_atom_cas_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_load_sector_queries_atom_cas_enc_str_1},
    { MAXWELL_TEX1_LOAD_SECTOR_QURIES_ATOM_CAS, maxwell_tex1_load_sector_queries_atom_cas_enc_str_1, maxwell_tex1_load_sector_queries_atom_cas_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_load_sector_queries_atom_cas_enc_str_1},
    { MAXWELL_TEX0_LOAD_SECTOR_QURIES_ATOM,     maxwell_tex0_load_sector_queries_atom_enc_str_1,     maxwell_tex0_load_sector_queries_atom_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex0_load_sector_queries_atom_enc_str_1},
    { MAXWELL_TEX1_LOAD_SECTOR_QURIES_ATOM,     maxwell_tex1_load_sector_queries_atom_enc_str_1,     maxwell_tex1_load_sector_queries_atom_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, maxwell_tex1_load_sector_queries_atom_enc_str_1},

    { MAXWELL_PCIE_TX_ACTIVE, maxwell_pcie_tx_active_enc_str_1, maxwell_pcie_tx_active_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_pcie_tx_active_enc_str_1 },
    { MAXWELL_PCIE_TX_IDLE, maxwell_pcie_tx_idle_enc_str_1, maxwell_pcie_tx_idle_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_pcie_tx_idle_enc_str_1 },
    { MAXWELL_PCIE_RX_ACTIVE, maxwell_pcie_rx_active_enc_str_1, maxwell_pcie_rx_active_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_pcie_rx_active_enc_str_1 },
    { MAXWELL_PCIE_RX_IDLE, maxwell_pcie_rx_idle_enc_str_1, maxwell_pcie_rx_idle_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_pcie_rx_idle_enc_str_1 },

    {MAXWELL_HWPM_INST_EXECUTED_TEX_OPS_Q0, maxwell_hwpm_inst_executed_tex_ops_q0_enc_str_1, maxwell_hwpm_inst_executed_tex_ops_q0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_inst_executed_tex_ops_q0_enc_str_1},
    {MAXWELL_HWPM_INST_EXECUTED_TEX_OPS_Q1, maxwell_hwpm_inst_executed_tex_ops_q1_enc_str_1, maxwell_hwpm_inst_executed_tex_ops_q1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_inst_executed_tex_ops_q1_enc_str_1},
    {MAXWELL_HWPM_INST_EXECUTED_TEX_OPS_Q2, maxwell_hwpm_inst_executed_tex_ops_q2_enc_str_1, maxwell_hwpm_inst_executed_tex_ops_q2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_inst_executed_tex_ops_q2_enc_str_1},
    {MAXWELL_HWPM_INST_EXECUTED_TEX_OPS_Q3, maxwell_hwpm_inst_executed_tex_ops_q3_enc_str_1, maxwell_hwpm_inst_executed_tex_ops_q3_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, maxwell_hwpm_inst_executed_tex_ops_q3_enc_str_1},
#endif /* NVCFG(GLOBAL_GPU_FAMILY_GM20X) || NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)*/

#if NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
    {MAXWELL_LTC0_LTCX_MC_REQ_RD_SIZE_32B,    maxwell_ltc0_ltcx_mc_req_rd_size_32b_enc_str_1,     maxwell_ltc0_ltcx_mc_req_rd_size_32b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc0_ltcx_mc_req_rd_size_32b_enc_str_4},
    {MAXWELL_LTC0_LTCX_MC_REQ_RD_SIZE_64B,    maxwell_ltc0_ltcx_mc_req_rd_size_64b_enc_str_1,     maxwell_ltc0_ltcx_mc_req_rd_size_64b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc0_ltcx_mc_req_rd_size_64b_enc_str_4},
    {MAXWELL_LTC0_LTCX_MC_REQ_WR_SIZE_16B,    maxwell_ltc0_ltcx_mc_req_wr_size_16b_enc_str_1,     maxwell_ltc0_ltcx_mc_req_wr_size_16b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc0_ltcx_mc_req_wr_size_16b_enc_str_4},
    {MAXWELL_LTC0_LTCX_MC_REQ_WR_SIZE_32B,    maxwell_ltc0_ltcx_mc_req_wr_size_32b_enc_str_1,     maxwell_ltc0_ltcx_mc_req_wr_size_32b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc0_ltcx_mc_req_wr_size_32b_enc_str_4},
    {MAXWELL_LTC0_LTCX_MC_REQ_WR_SIZE_64B,    maxwell_ltc0_ltcx_mc_req_wr_size_64b_enc_str_1,     maxwell_ltc0_ltcx_mc_req_wr_size_64b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc0_ltcx_mc_req_wr_size_64b_enc_str_4},

    {MAXWELL_LTC0_LTCX_REQ_RD_SECTOR_COUNT_1, maxwell_ltc0_ltcx_req_rd_sector_count_1_enc_str_1,  maxwell_ltc0_ltcx_req_rd_sector_count_1_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc0_ltcx_req_rd_sector_count_1_enc_str_4},
    {MAXWELL_LTC0_LTCX_REQ_RD_SECTOR_COUNT_2, maxwell_ltc0_ltcx_req_rd_sector_count_2_enc_str_1,  maxwell_ltc0_ltcx_req_rd_sector_count_2_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc0_ltcx_req_rd_sector_count_2_enc_str_4},
    {MAXWELL_LTC0_LTCX_REQ_RD_SECTOR_COUNT_3, maxwell_ltc0_ltcx_req_rd_sector_count_3_enc_str_1,  maxwell_ltc0_ltcx_req_rd_sector_count_3_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc0_ltcx_req_rd_sector_count_3_enc_str_4},
    {MAXWELL_LTC0_LTCX_REQ_RD_SECTOR_COUNT_4, maxwell_ltc0_ltcx_req_rd_sector_count_4_enc_str_1,  maxwell_ltc0_ltcx_req_rd_sector_count_4_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc0_ltcx_req_rd_sector_count_4_enc_str_4},

    {MAXWELL_LTC0_LTCX_REQ_WR_SECTOR_COUNT_1, maxwell_ltc0_ltcx_req_wr_sector_count_1_enc_str_1,  maxwell_ltc0_ltcx_req_wr_sector_count_1_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc0_ltcx_req_wr_sector_count_1_enc_str_4},
    {MAXWELL_LTC0_LTCX_REQ_WR_SECTOR_COUNT_2, maxwell_ltc0_ltcx_req_wr_sector_count_2_enc_str_1,  maxwell_ltc0_ltcx_req_wr_sector_count_2_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc0_ltcx_req_wr_sector_count_2_enc_str_4},
    {MAXWELL_LTC0_LTCX_REQ_WR_SECTOR_COUNT_3, maxwell_ltc0_ltcx_req_wr_sector_count_3_enc_str_1,  maxwell_ltc0_ltcx_req_wr_sector_count_3_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc0_ltcx_req_wr_sector_count_3_enc_str_4},
    {MAXWELL_LTC0_LTCX_REQ_WR_SECTOR_COUNT_4, maxwell_ltc0_ltcx_req_wr_sector_count_4_enc_str_1,  maxwell_ltc0_ltcx_req_wr_sector_count_4_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc0_ltcx_req_wr_sector_count_4_enc_str_4},

    {MAXWELL_LTC1_LTCX_MC_REQ_RD_SIZE_32B,    maxwell_ltc1_ltcx_mc_req_rd_size_32b_enc_str_1,     maxwell_ltc1_ltcx_mc_req_rd_size_32b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc1_ltcx_mc_req_rd_size_32b_enc_str_4},
    {MAXWELL_LTC1_LTCX_MC_REQ_RD_SIZE_64B,    maxwell_ltc1_ltcx_mc_req_rd_size_64b_enc_str_1,     maxwell_ltc1_ltcx_mc_req_rd_size_64b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc1_ltcx_mc_req_rd_size_64b_enc_str_4},
    {MAXWELL_LTC1_LTCX_MC_REQ_WR_SIZE_16B,    maxwell_ltc1_ltcx_mc_req_wr_size_16b_enc_str_1,     maxwell_ltc1_ltcx_mc_req_wr_size_16b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc1_ltcx_mc_req_wr_size_16b_enc_str_4},
    {MAXWELL_LTC1_LTCX_MC_REQ_WR_SIZE_32B,    maxwell_ltc1_ltcx_mc_req_wr_size_32b_enc_str_1,     maxwell_ltc1_ltcx_mc_req_wr_size_32b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc1_ltcx_mc_req_wr_size_32b_enc_str_4},
    {MAXWELL_LTC1_LTCX_MC_REQ_WR_SIZE_64B,    maxwell_ltc1_ltcx_mc_req_wr_size_64b_enc_str_1,     maxwell_ltc1_ltcx_mc_req_wr_size_64b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc1_ltcx_mc_req_wr_size_64b_enc_str_4},

    {MAXWELL_LTC1_LTCX_REQ_RD_SECTOR_COUNT_1, maxwell_ltc1_ltcx_req_rd_sector_count_1_enc_str_1,  maxwell_ltc1_ltcx_req_rd_sector_count_1_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc1_ltcx_req_rd_sector_count_1_enc_str_4},
    {MAXWELL_LTC1_LTCX_REQ_RD_SECTOR_COUNT_2, maxwell_ltc1_ltcx_req_rd_sector_count_2_enc_str_1,  maxwell_ltc1_ltcx_req_rd_sector_count_2_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc1_ltcx_req_rd_sector_count_2_enc_str_4},
    {MAXWELL_LTC1_LTCX_REQ_RD_SECTOR_COUNT_3, maxwell_ltc1_ltcx_req_rd_sector_count_3_enc_str_1,  maxwell_ltc1_ltcx_req_rd_sector_count_3_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc1_ltcx_req_rd_sector_count_3_enc_str_4},
    {MAXWELL_LTC1_LTCX_REQ_RD_SECTOR_COUNT_4, maxwell_ltc1_ltcx_req_rd_sector_count_4_enc_str_1,  maxwell_ltc1_ltcx_req_rd_sector_count_4_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc1_ltcx_req_rd_sector_count_4_enc_str_4},

    {MAXWELL_LTC1_LTCX_REQ_WR_SECTOR_COUNT_1, maxwell_ltc1_ltcx_req_wr_sector_count_1_enc_str_1,  maxwell_ltc1_ltcx_req_wr_sector_count_1_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc1_ltcx_req_wr_sector_count_1_enc_str_4},
    {MAXWELL_LTC1_LTCX_REQ_WR_SECTOR_COUNT_2, maxwell_ltc1_ltcx_req_wr_sector_count_2_enc_str_1,  maxwell_ltc1_ltcx_req_wr_sector_count_2_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc1_ltcx_req_wr_sector_count_2_enc_str_4},
    {MAXWELL_LTC1_LTCX_REQ_WR_SECTOR_COUNT_3, maxwell_ltc1_ltcx_req_wr_sector_count_3_enc_str_1,  maxwell_ltc1_ltcx_req_wr_sector_count_3_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc1_ltcx_req_wr_sector_count_3_enc_str_4},
    {MAXWELL_LTC1_LTCX_REQ_WR_SECTOR_COUNT_4, maxwell_ltc1_ltcx_req_wr_sector_count_4_enc_str_1,  maxwell_ltc1_ltcx_req_wr_sector_count_4_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, maxwell_ltc1_ltcx_req_wr_sector_count_4_enc_str_4},

#endif // NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)

#if NVCFG(GLOBAL_GPU_FAMILY_GM20X) || NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
    {MAXWELL_SKED_VSFSM_VSPAN_ADD, maxwell_sked_vsfsm_vspan_add_enc_str_1, maxwell_sked_vsfsm_vspan_add_enc_str_1, (CUprof_EventCategory)0, maxwell_sked_vsfsm_vspan_add_enc_str_1},
    {MAXWELL_SKED_VSFSM_VSPAN_BRIDGE, maxwell_sked_vsfsm_vspan_bridge_enc_str_1, maxwell_sked_vsfsm_vspan_bridge_enc_str_1, (CUprof_EventCategory)0, maxwell_sked_vsfsm_vspan_bridge_enc_str_1},
    {MAXWELL_SKED_VSFSM_VSPAN_MERGE, maxwell_sked_vsfsm_vspan_merge_enc_str_1, maxwell_sked_vsfsm_vspan_merge_enc_str_1, (CUprof_EventCategory)0, maxwell_sked_vsfsm_vspan_merge_enc_str_1},
    {MAXWELL_SKED_VSFSM_UPDATE_PUT_VLD, maxwell_sked_vsfsm_update_put_vld_enc_str_1, maxwell_sked_vsfsm_update_put_vld_enc_str_1, (CUprof_EventCategory)0, maxwell_sked_vsfsm_update_put_vld_enc_str_1},
    {MAXWELL_SKED_VSFSM_UPDATE_PUT_RDY, maxwell_sked_vsfsm_update_put_rdy_enc_str_1, maxwell_sked_vsfsm_update_put_rdy_enc_str_1, (CUprof_EventCategory)0, maxwell_sked_vsfsm_update_put_rdy_enc_str_1},
    {MAXWELL_SKED_VSFSM_READ, maxwell_sked_vsfsm_read_enc_str_1, maxwell_sked_vsfsm_read_enc_str_1, (CUprof_EventCategory)0, maxwell_sked_vsfsm_read_enc_str_1},
    {MAXWELL_SKED_VSFSM_WRITE, maxwell_sked_vsfsm_write_enc_str_1, maxwell_sked_vsfsm_write_enc_str_1, (CUprof_EventCategory)0, maxwell_sked_vsfsm_write_enc_str_1},
    {MAXWELL_SKED_VSM_FB_WRITE, maxwell_sked_vsm_fb_write_enc_str_1, maxwell_sked_vsm_fb_write_enc_str_1, (CUprof_EventCategory)0, maxwell_sked_vsm_fb_write_enc_str_1},
    {MAXWELL_SKED_VSM_FB_READ, maxwell_sked_vsm_fb_read_enc_str_1, maxwell_sked_vsm_fb_read_enc_str_1, (CUprof_EventCategory)0, maxwell_sked_vsm_fb_read_enc_str_1},
    {MAXWELL_SKED_VSM_LOCAL_WRITE, maxwell_sked_vsm_local_write_enc_str_1, maxwell_sked_vsm_local_write_enc_str_1, (CUprof_EventCategory)0, maxwell_sked_vsm_local_write_enc_str_1},
    {MAXWELL_SKED_VSM_LOCAL_READ, maxwell_sked_vsm_local_read_enc_str_1, maxwell_sked_vsm_local_read_enc_str_1, (CUprof_EventCategory)0, maxwell_sked_vsm_local_read_enc_str_1},
    {MAXWELL_SKED_VSM_LOCAL_FREE, maxwell_sked_vsm_local_free_enc_str_1, maxwell_sked_vsm_local_free_enc_str_1, (CUprof_EventCategory)0, maxwell_sked_vsm_local_free_enc_str_1},
    {MAXWELL_SKED_VSM_FB_FREE, maxwell_sked_vsm_fb_free_enc_str_1, maxwell_sked_vsm_fb_free_enc_str_1, (CUprof_EventCategory)0, maxwell_sked_vsm_fb_free_enc_str_1},
    {MAXWELL_SKED_VSM_LOCAL_ALLOC, maxwell_sked_vsm_local_alloc_enc_str_1, maxwell_sked_vsm_local_alloc_enc_str_1, (CUprof_EventCategory)0, maxwell_sked_vsm_local_alloc_enc_str_1},
    {MAXWELL_SKED_VSM_FB_ALLOC, maxwell_sked_vsm_fb_alloc_enc_str_1, maxwell_sked_vsm_fb_alloc_enc_str_1, (CUprof_EventCategory)0, maxwell_sked_vsm_fb_alloc_enc_str_1},
#endif /* NVCFG(GLOBAL_GPU_FAMILY_GM20X) || NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B) */
    {INVALID_PM_SIGNAL_NEW, ""}
};

CUdomainInfo domainInfoGM000   = { 15,    domainTableGM000, pMaxwellSignalDescriptionArray};

#if NVCFG(GLOBAL_GPU_FAMILY_GM20X)
CUdomainInfo domainInfoGM200   = { 15,  domainTableGM200, pMaxwellSignalDescriptionArray};
#else
CUdomainInfo domainInfoGM200   = { 0,  NULL, pMaxwellSignalDescriptionArray};
#endif /* NVCFG(GLOBAL_GPU_FAMILY_GM20X) */
#if NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
CUdomainInfo domainInfoGM20Y   = { 13,  domainTableGM20Y, pMaxwellSignalDescriptionArray};
#endif // NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
