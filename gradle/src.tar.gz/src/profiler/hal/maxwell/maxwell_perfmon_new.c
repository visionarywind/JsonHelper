/*
* Copyright 1993-2009 by NVIDIA Corporation.  All rights reserved.  All
* information contained herein is proprietary and confidential to NVIDIA
* Corporation.  Any use, reproduction, or disclosure without the written
* permission of NVIDIA Corporation is prohibited.
*/

/******************************************************************************
*
*   Module: maxwell_perfmon_new.c
*
*   Description:
*       Performance monitor support in compute driver architecture.
*
******************************************************************************/

#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#include "maxwell_perfmon_new.h"
#include "maxwell_signals.h"
#include "cuda_internal.h"
#include "cuda_device.h"
#include "cuda_macros.h"
#include "cuos.h"
#include "maxwell/gm204/dev_perf.h"
#include "maxwell/gm107/pm_signals.h"
#include "maxwell/gm204/dev_fuse.h"
#include "halo_helper.h"
#include "maxwell/gm107/dev_ctxsw_prog.h"     // needed for falcon method
#include "cui/hal/maxwell/maxwell.h"
#include "perfmon_common.h"
#include "perfmon_new.h"
#include "tools_shared.h"
#include "tools_shared_hashmap.h"
#include "tools_shared_list.h"
#include "stream_push.h"

#define FALSE_WATCH_BUS_SIGNAL 0xef
//TBD collect all scattered register settings for each domain and put in one function
//TBD Set register common function need to be different and should be thread safe
//TBD check all the parameters, pointers etc for validity.

#define PACKET_SIZE 5
#define MAX_SM_IN_MAXWELL   24
#define MAXWELL_RECORD_SIZE 32
#ifdef DEBUG
#define ENABLE_SAMPLING_PRINTS
#endif

#define GENERATE_BINARY_STREAMS 0

// compare function for event group
static NvBool egCompareData(const void *data1, const void *data2) {
    return ( (CUeventGroup*)data1 == (CUeventGroup*)data2 );
}

// compare function for event (signal) Ids
static NvBool eventIdCompareData(const void *data1, const void *data2) {
    return (((CUeventDataBasic*)((CUeventInfo*)data1)->pEventData)->signalId == *(NvU32*)data2 );
}

static NV_INLINE NvBool maxwellIsPpaSoftwareCounterDomain(CUeventDomainID domainId, NvU64 arch);
static NV_INLINE NvBool maxwellIsDeviceLevelCounterDomain(CUeventDomainID domainId);
static CUprofResult maxwellDestroyEventGroup(CUeventGroup *pEventGroup);
//TBD : Shift these functions up in the file to get rid of declaration
static CUresult SetupPMRegistersSMInternal(CUeventGroup *pEventGroup);
static CUresult resetPMSMInternal(CUeventGroup *pEventGroup);
// Broadcast version of SetupPMRegistersSMInternal:
static CUresult SetupPMRegistersSM_bc(CUeventGroup *pEventGroup, NvU32 eventGroupQctl, NvU32 eventGroupCore, 
                                        NvU32* funcQctl, NvU32* funcCore, NvU32 enableQctl, NvU32 enableCore);
// Broadcast version of resetPMSMInternal:
static CUresult resetPMSM_bc(CUeventGroup *pEventGroup, NvU32 *funcQctl, NvU32 *funcCore);
// Unicast version of SetupPMRegistersSMInternal:
static CUresult SetupPMRegistersSM(CUeventGroup *pEventGroup, NvU32 eventGroupQctl, NvU32 eventGroupCore, 
                                    NvU32* funcQctl, NvU32* funcCore, NvU32 enableQctl, NvU32 enableCore);
// Unicast version of resetPMSMInternal:
static CUresult resetPMSM(CUeventGroup *pEventGroup, NvU32 *funcQctl, NvU32 *funcCore);
static CUresult logPMCountersSMInternal(CUeventGroup *pEventGroup, NvU8 *highValuesQuad, NvU8 *highValuesCore);
static CUresult detectCounterOverflowSMInternal(const CUeventGroup *pEventGroup, NvBool* bIsOverflow, NvU8* overflowValuesQuad, NvU8* overflowValuesCore);
static CUresult setPMEnableRegSM(const CUeventGroup *pEventGroup, NvBool bEnable);
static CUprofResult PMReleaseModeB(const CUeventGroup *pEventGroup);
static NvU32 getCounterMultiplicationFactor(NvU64 arch, CUeventID eventId);
static NvBool getSplittingInfo(CUeventID eventId, NvU32 *splitWidth);
static CUprofResult maxwellPerfmonAddSMCounterEntryForHWPMMux(CUeventGroup *pEventGroup, CUdomainData *pDomainData, CUeventInfo *pEventInfo, NvBool *bAdded, NvU32 *maxSignals);
static int maxwellPerfmonPCSamplingReadData(void *userData);
static int maxwellPerfmonPCSamplingParseData(void *userData);

// PC Sampling
static CUprofResult maxwellOnPacket(const uint8_t *pPacketRaw, CUctx *ctx);
static CUprofResult maxwellOnRecord(uint8_t *pModeERecord, chiplet *chipInstanceData, CUctx *ctx, uint32_t *totalDroppedBytes);
static inline size_t   incrementRecordOffset(size_t recordOffset);
static inline uint16_t getValidBytes(const uint8_t *pModeERecord);
static inline uint16_t getPerfmonId(const uint8_t *pModeERecord);
static inline uint8_t  isDelayed(const uint8_t *pModeERecord);
static inline uint16_t getDroppedBytes(const uint8_t *pModeERecord);
static inline uint32_t getPC(const uint8_t *pPacketRaw);
static inline uint32_t getCIR(const uint8_t *pPacketRaw);

/*******************************************************************************
SMPC (SM performance counters) require custom ctxsw ucode to properly disable
counters as early as possible in the save routine and enable the counters as
late as possible in the restore routine. In addition some of the registers are
per QCTL (as opposed to per SM) and need to be saved and restored without
corrupting the QCTL PRI mapping registers.
This Falcon05 method sets the SMPC CTXSW MODE for ensuring the same.
********************************************************************************/

static CUresult setFalcon05Method(CUctx* ctx)
{
    CUresult status = CUDA_SUCCESS;
    CUnvCurrent* nvCurrent = NULL;
    uint32_t data, mask;
    uint32_t headerOffset, headerType, headerIndex, accessHeader;
    int i = 0;

    CU_TRACE_FUNCTION();

    if (ctx->pmNew->flag & CU_PM_FLAG_FALCON_05_METHOD) {
        // falcon05 method is already set
        return CUDA_SUCCESS;
    }

    // https://wiki.nvidia.com/fermi/index.php/Fermi_Firmware_Methods#Class_0x9097.2C_SetFalcon05
    //
    // SetFaclon05              = data access_header
    // SetMmeShadowScratch[0]   = flag register
    // SetMmeShadowScratch[1]   = data
    // SetMmeShadowScratch[2]   = mask

    streamBeginPush(ctx->streamManager, CU_CHANNEL_COMPUTE, ctx->barrierStream, &nvCurrent, NULL);

    data = REF_NUM(NV_CTXSW_MAIN_IMAGE_SMPC_MODE, NV_CTXSW_MAIN_IMAGE_SMPC_MODE_CTXSW);
    mask = DRF_SHIFTMASK(NV_CTXSW_MAIN_IMAGE_SMPC_MODE);
    headerOffset = REF_NUM(NV_CTXSW_MAIN_IMAGE_ACCESS_HEADER_OFFSET, NV_CTXSW_MAIN_IMAGE_PM);
    headerType   = REF_NUM(NV_CTXSW_MAIN_IMAGE_ACCESS_HEADER_TYPE, NV_CTXSW_MAIN_IMAGE_ACCESS_HEADER_TYPE_MAIN);
    headerIndex  = REF_NUM(NV_CTXSW_MAIN_IMAGE_ACCESS_HEADER_INDEX, 0);
    accessHeader = headerOffset | headerType | headerIndex;

    NV_PUSH_1U(B0C0, WAIT_FOR_IDLE,  0);

    NV_PUSH_3U(B0C0, SET_MME_SHADOW_SCRATCH(0), 0,
        SET_MME_SHADOW_SCRATCH(1), data,
        SET_MME_SHADOW_SCRATCH(2), mask);
    NV_PUSH_1U(B0C0, SET_FALCON05, accessHeader);

    for (i  = 0; i < 10; i++) {
        NV_PUSH_1U(B0C0, NO_OPERATION, 0);
    }

    NV_PUSH_1U(B0C0, WAIT_FOR_IDLE,  0);

    streamEndPush(ctx->barrierStream, nvCurrent, NULL);

    // Wait for the write to complete
    status = cuiCtxSynchronize(ctx);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Ctx sync failed following Falcon05 method.\n"));
        return status;
    }

    // set flag
    ctx->pmNew->flag |= CU_PM_FLAG_FALCON_05_METHOD;

    return status;
}

ct_assert((CUprofMaxwellWarpCantIssueReasons) CUPROF_WARP_CANT_ISSUE_DRAIN == CUPROF_MAXWELL_WARP_CANT_ISSUE_DRAIN);
ct_assert((CUprofMaxwellWarpCantIssueReasons) CUPROF_WARP_CANT_ISSUE_ICACHE_MISS == CUPROF_MAXWELL_WARP_CANT_ISSUE_ICACHE_MISS);
ct_assert((CUprofMaxwellWarpCantIssueReasons) CUPROF_WARP_CANT_ISSUE_IMC_MISS == CUPROF_MAXWELL_WARP_CANT_ISSUE_IMC_MISS);
ct_assert((CUprofMaxwellWarpCantIssueReasons) CUPROF_WARP_CANT_ISSUE_LONG_SCOREBOARD == CUPROF_MAXWELL_WARP_CANT_ISSUE_LONG_SCOREBOARD);
ct_assert((CUprofMaxwellWarpCantIssueReasons) CUPROF_WARP_CANT_ISSUE_BARRIER == CUPROF_MAXWELL_WARP_CANT_ISSUE_BARRIER);
ct_assert((CUprofMaxwellWarpCantIssueReasons) CUPROF_WARP_CANT_ISSUE_MEMBAR == CUPROF_MAXWELL_WARP_CANT_ISSUE_MEMBAR);
ct_assert((CUprofMaxwellWarpCantIssueReasons) CUPROF_WARP_CANT_ISSUE_OFF_DECK_SHORT_SCOREBOARD == CUPROF_MAXWELL_WARP_CANT_ISSUE_OFF_DECK_SHORT_SCOREBOARD);
ct_assert((CUprofMaxwellWarpCantIssueReasons) CUPROF_WARP_CANT_ISSUE_TILE_ALLOCATION_STALL == CUPROF_MAXWELL_WARP_CANT_ISSUE_TILE_ALLOCATION_STALL);
ct_assert((CUprofMaxwellWarpCantIssueReasons) CUPROF_WARP_CANT_ISSUE_ALLOCATION_STALL_NOT_ELIGIBLE == CUPROF_MAXWELL_WARP_CANT_ISSUE_ALLOCATION_STALL_NOT_ELIGIBLE);
ct_assert((CUprofMaxwellWarpCantIssueReasons) CUPROF_WARP_CANT_ISSUE_ALLOCATION_STALL_NO_SPACE == CUPROF_MAXWELL_WARP_CANT_ISSUE_ALLOCATION_STALL_NO_SPACE);
ct_assert((CUprofMaxwellWarpCantIssueReasons) CUPROF_WARP_CANT_ISSUE_WAIT == CUPROF_MAXWELL_WARP_CANT_ISSUE_WAIT);
ct_assert((CUprofMaxwellWarpCantIssueReasons) CUPROF_WARP_CANT_ISSUE_ON_DECK_LONG_SCOREBOARD == CUPROF_MAXWELL_WARP_CANT_ISSUE_ON_DECK_LONG_SCOREBOARD);
ct_assert((CUprofMaxwellWarpCantIssueReasons) CUPROF_WARP_CANT_ISSUE_ON_DECK_SHORT_SCOREBOARD == CUPROF_MAXWELL_WARP_CANT_ISSUE_ON_DECK_SHORT_SCOREBOARD);
ct_assert((CUprofMaxwellWarpCantIssueReasons) CUPROF_WARP_CANT_ISSUE_NO_INSTRUCTIONS == CUPROF_MAXWELL_WARP_CANT_ISSUE_NO_INSTRUCTIONS);
ct_assert((CUprofMaxwellWarpCantIssueReasons) CUPROF_WARP_CANT_ISSUE_SHADOW_PIPE_THROTTLE == CUPROF_MAXWELL_WARP_CANT_ISSUE_SHADOW_PIPE_THROTTLE);
ct_assert((CUprofMaxwellWarpCantIssueReasons) CUPROF_WARP_CANT_ISSUE_TEX_THROTTLE == CUPROF_MAXWELL_WARP_CANT_ISSUE_TEX_THROTTLE);
ct_assert((CUprofMaxwellWarpCantIssueReasons) CUPROF_WARP_CANT_ISSUE_MIO_THROTTLE == CUPROF_MAXWELL_WARP_CANT_ISSUE_MIO_THROTTLE);
ct_assert((CUprofMaxwellWarpCantIssueReasons) CUPROF_WARP_CANT_ISSUE_DISPATCH_STALL == CUPROF_MAXWELL_WARP_CANT_ISSUE_DISPATCH_STALL);
ct_assert((CUprofMaxwellWarpCantIssueReasons) CUPROF_WARP_CANT_ISSUE_NOT_SELECTED == CUPROF_MAXWELL_WARP_CANT_ISSUE_NOT_SELECTED);
ct_assert((CUprofMaxwellWarpCantIssueReasons) CUPROF_WARP_CANT_ISSUE_SELECTED == CUPROF_MAXWELL_WARP_CANT_ISSUE_SELECTED);
ct_assert((CUprofMaxwellWarpCantIssueReasons) CUPROF_WARP_CANT_ISSUE_MISC == CUPROF_MAXWELL_WARP_CANT_ISSUE_MISC);
ct_assert((CUprofMaxwellWarpCantIssueReasons) CUPROF_WARP_CANT_ISSUE_ON_DECK_MISC == CUPROF_MAXWELL_WARP_CANT_ISSUE_ON_DECK_MISC);

static uint32_t getPCSamplingStallReasonDriver(uint32_t cantIssueReason)
{
    // If the environment variable is set to expose all the cant issue reasons
    // from driver, then return the same cant issue reason if it is valid.
    if (cantIssueReason >= CUPROF_MAXWELL_WARP_CANT_ISSUE_MAX_CIR)
        return CUPROF_WARP_CANT_ISSUE_INVALID;
    else
       return cantIssueReason;
}

static uint32_t getPCSamplingStallReasonCupti(uint32_t cantIssueReason)
{
    // Map the cant issue reason from driver to the proper one which is
    //    exposed in toolkit
    switch(cantIssueReason)
    {
    case CUPROF_MAXWELL_WARP_CANT_ISSUE_SELECTED:
        return CUPROF_PC_SAMPLING_STALL_GROUP_NONE;
    case CUPROF_MAXWELL_WARP_CANT_ISSUE_ICACHE_MISS:
    case CUPROF_MAXWELL_WARP_CANT_ISSUE_NO_INSTRUCTIONS:
        return CUPROF_PC_SAMPLING_STALL_GROUP_INST_FETCH;
    case CUPROF_MAXWELL_WARP_CANT_ISSUE_OFF_DECK_SHORT_SCOREBOARD:
    case CUPROF_MAXWELL_WARP_CANT_ISSUE_ON_DECK_SHORT_SCOREBOARD:
    case CUPROF_MAXWELL_WARP_CANT_ISSUE_WAIT:
        return CUPROF_PC_SAMPLING_STALL_GROUP_EXEC_DEPENDENCY;
    case CUPROF_MAXWELL_WARP_CANT_ISSUE_LONG_SCOREBOARD:
    case CUPROF_MAXWELL_WARP_CANT_ISSUE_ON_DECK_LONG_SCOREBOARD:
        return CUPROF_PC_SAMPLING_STALL_GROUP_MEMORY_DEPENDENCY;
    case CUPROF_MAXWELL_WARP_CANT_ISSUE_TEX_THROTTLE:
    case CUPROF_MAXWELL_WARP_CANT_ISSUE_TILE_ALLOCATION_STALL:
        return CUPROF_PC_SAMPLING_STALL_GROUP_TEXTURE;
    case CUPROF_MAXWELL_WARP_CANT_ISSUE_BARRIER:
    case CUPROF_MAXWELL_WARP_CANT_ISSUE_MEMBAR:
        return CUPROF_PC_SAMPLING_STALL_GROUP_SYNC;
    case CUPROF_MAXWELL_WARP_CANT_ISSUE_IMC_MISS:
        return CUPROF_PC_SAMPLING_STALL_GROUP_CONSTANT_MEMORY_DEPENDENCY;
    case CUPROF_MAXWELL_WARP_CANT_ISSUE_SHADOW_PIPE_THROTTLE:
    case CUPROF_MAXWELL_WARP_CANT_ISSUE_MIO_THROTTLE:
        return CUPROF_PC_SAMPLING_STALL_GROUP_PIPE_BUSY;
    case CUPROF_MAXWELL_WARP_CANT_ISSUE_DRAIN:
        return CUPROF_PC_SAMPLING_STALL_GROUP_MEMORY_THROTTLE;
    case CUPROF_MAXWELL_WARP_CANT_ISSUE_NOT_SELECTED:
        return CUPROF_PC_SAMPLING_STALL_GROUP_NOT_SELECTED;
    case CUPROF_MAXWELL_WARP_CANT_ISSUE_ALLOCATION_STALL_NOT_ELIGIBLE:
    case CUPROF_MAXWELL_WARP_CANT_ISSUE_ALLOCATION_STALL_NO_SPACE:
    case CUPROF_MAXWELL_WARP_CANT_ISSUE_MISC:
    case CUPROF_MAXWELL_WARP_CANT_ISSUE_ON_DECK_MISC:
    case CUPROF_MAXWELL_WARP_CANT_ISSUE_DISPATCH_STALL:
        return CUPROF_PC_SAMPLING_STALL_GROUP_OTHER;
    case CUPROF_MAXWELL_WARP_CANT_ISSUE_INVALID:
    default:
        return CUPROF_PC_SAMPLING_STALL_GROUP_INVALID;
    }
}

static NvU32 getCounterMultiplicationFactor(NvU64 arch, CUeventID eventId) {
    // see bug 876915 for a complete list of counters
    // which require multiplication factor
    // TODO: current list is valid for GM107/106/110 chips
    // verify for other chips as and when they come
    switch(eventId) {
        case MAXWELL_SM_THREAD_INST_EXECUTED:
        case MAXWELL_SM_NOT_PREDICATED_OFF_THREAD_INST_EXECUTED:
            // The warp_cant_issue_* signals will not require a multiplication factor if profiled via HWPM.
            return 2;
        case MAXWELL_HWPM_ACTIVE_WARPS:
        case MAXWELL_HWPMMUX_ACTIVE_WARPS:
        case MAXWELL_SM_ACTIVE_WARPS:
        /* # active_warps has different ranges for gm20x and gm20y. The signals below are the most
           # significant 6 bits of a 7 or 8-bit signal. There is an internal accumulator for the
           # missing bits. Multiply the final results by 2x or 4x. Maximum error is 2^n - 1 where
           # n is the missing bits.*/
#if NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B)
            if(arch ==
               (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM20B)) {
                return 4;
            }
#endif
#if NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM21B
            if(arch ==
               (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM21B)) {
                return 4;
            }
#endif // NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM21B
#endif
            return 2;
        default:
            return 1;
    }

    return 0;
}

static NvBool getSplittingInfo(CUeventID eventId, NvU32 *splitWidth)
{
    switch(eventId) {
        case MAXWELL_SM_ACTIVE_WARPS:
            *splitWidth = 2;
            break;
        default:
            *splitWidth = 0;
            return NV_FALSE;
    }
    return NV_TRUE;
}

CUprofResult maxwellPerfmonGetInstanceValues(CUdev *dev, CUdomainData *domainData, NvU32 *avail, NvU32 *total)
{
    NvU32 k = 0;
    if(!avail || !total)
        return CUPROF_ERROR_INVALID_PARAMETER;

    *avail = *total = 1;

    switch(domainData->chipletType)
    {
    case PM_CHIPLET_TYPE_GPC:
        *total = 0;
        for(k=0; k<dev->state.limits.numGpcs; k++) {
            *total += dev->state.limits.numTpcsPerGpc[k];
        }
        *avail = *total;
        break;
    case PM_CHIPLET_TYPE_FBP:
        if (dev->dmalType == CU_DMAL_AMODEL) {
            *total = 1;
        } else {
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200
            if((cuiDeviceArchIsMaxwellGM20XPlus(dev)) &&
                (domainData->domainId == MAXWELL_CLK_DOMAIN_GM200_LTC0)) {
                *total = dev->state.limits.numL2;
            } else
#endif
            {
                *total = dev->state.limits.numFbps;
            }
        }
        *avail = *total;
        break;
    case PM_CHIPLET_TYPE_SYS:
        *total = 1;
        *avail = *total;
        break;
    default:
        CU_ASSERT(0);
        break;
    }
    return CUPROF_SUCCESS;
}

CUprofResult maxwellPerfmonDeviceInitEventDomainInfo(CUdev *pDev) {
    CUprofResult status = CUPROF_SUCCESS;
    void *pSignalTable = NULL;
    CUdomainData *pDomainData = NULL;
    NvU32 maxInternalSignals = 0;
    NvU32 maxExternalSignals = 0;
    NvU32 numDomains = 0;
    NvU32 numInternalDomains = 0;
    NvU32 i = 0;
    NvU32 sigTableIdx = 0;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pDev);

    if(pDev->state.pDomainInfo == NULL) {
        return CUPROF_ERROR_UNKNOWN;
    }

    if (pDev->state.pDomainInfo->bInit) {
        // domain data is already populated
        return CUPROF_SUCCESS;
    }
    else
    {
        NvBool internalCountersExposed = 0;
        NvU32 signalTableEntrySize = 0;
        unsigned int old = cuosInterlockedExchange(&pDev->state.pDomainInfo->bInitStarted, 1);
        if (old == 0) {
            perfmonDemangleStrings();
            internalCountersExposed = perfmonInternalCountersExposed();
            numDomains = pDev->state.pDomainInfo->numDomains;

            if(!internalCountersExposed) {
                for (i = 0; i < numDomains; i++) {
                    if (!strncmp(pDev->state.pDomainInfo->pDomainTable[i].domainName, PM_INTERNAL_SIGNAL_PREFIX, 2)) {
                        numInternalDomains++;
                    }
                }
                numDomains -= numInternalDomains;
            }

            pDev->state.pDomainInfo->numDomains = numDomains;

            for (i = 0; i < numDomains; i++) {
                maxExternalSignals = maxInternalSignals = 0;
                for(sigTableIdx = 0; sigTableIdx < pDev->state.pDomainInfo->pDomainTable[i].numPerfSignalTables; sigTableIdx++) {
                    perfmonGetSizeOfSignalTableEntry(pDev->state.pDomainInfo->pDomainTable[i].pEventTableInfo[sigTableIdx].signalTableType,
                                                     &signalTableEntrySize);
                    pSignalTable = pDev->state.pDomainInfo->pDomainTable[i].pEventTableInfo[sigTableIdx].pEventData;
                    if (pSignalTable != NULL) {
                        while (((CUeventDataBasic*)pSignalTable)->signalId != INVALID_PM_SIGNAL_NEW) {
                            if (SIG_TYPE_IS_EXPOSED(((CUeventDataBasic*)pSignalTable)->signalId)) {
                                maxExternalSignals++;
                            }
                            else if (!SIG_TYPE_IS_INTERNAL(((CUeventDataBasic*)pSignalTable)->signalId)){
                                maxInternalSignals++;
                            }
                            pSignalTable = (void*)((NvU8*)pSignalTable + signalTableEntrySize);
                        }
                    }
                }
                pDomainData = &pDev->state.pDomainInfo->pDomainTable[i];

                pDomainData->maxExternalEvents = maxExternalSignals;
                pDomainData->maxInternalEvents = maxInternalSignals;

                if(internalCountersExposed) {
                    pDomainData->exposedEvents         = maxExternalSignals + maxInternalSignals;
                }
                else {
                    pDomainData->exposedEvents         = maxExternalSignals;
                }
            }
            cuosInterlockedIncrement(&pDev->state.pDomainInfo->bInit);
        }
        else {
            // Another thread has started initialization, all other threads
            // must wait until it has completed.
            while (pDev->state.pDomainInfo->bInit == 0) {
                cuosThreadYield();
            }
        }
    }

    return status;
}

//Allocate the arch specific eventgroup structure and initialize it
static CUprofResult maxwellInitEventGroup(CUeventGroup *pEventGroup)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUmaxwellEventGroup *pMaxwellEg = NULL;

    CU_TRACE_FUNCTION();

    if(pEventGroup->arch.maxwellEventGroup == NULL) {
        pMaxwellEg = (CUmaxwellEventGroup*)malloc(sizeof(CUmaxwellEventGroup));
        if(!pMaxwellEg) {
            CU_ERROR_PRINT(("Failed to allocate memory for CUmaxwellEventGroup\n"));
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto Error;
        }
        cuosMemset(pMaxwellEg, 0, sizeof(CUmaxwellEventGroup));

        pEventGroup->arch.maxwellEventGroup = pMaxwellEg;

        //TBD allocation of domain specific structures can be delayed until the
        //first event is added, saves memory
        //Following is used only for PM signals
        pMaxwellEg->pParsedClk = (CUparsedClk*)malloc(sizeof(CUparsedClk));

        if (!pMaxwellEg->pParsedClk) {
            CU_ERROR_PRINT(("Failed to allocate memory for CUparsedClk\n"));
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto Error;
        }
        cuosMemset(pMaxwellEg->pParsedClk, 0, sizeof(CUparsedClk));

        //Following is used only for SM counters
        pMaxwellEg->pSM = (CUSMCtrInfo*)malloc(sizeof(CUSMCtrInfo));

        if (!pMaxwellEg->pSM) {
            CU_ERROR_PRINT(("Failed to allocate memory for CUSMCtrInfo\n"));
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto Error;
        }
        cuosMemset(pMaxwellEg->pSM, 0, sizeof(CUSMCtrInfo));
    }

Error:
    if (status != CUPROF_SUCCESS) {
        maxwellDestroyEventGroup(pEventGroup);
    }

    return status;
}

//Destroy the arch specific eventgroup structure
static CUprofResult maxwellDestroyEventGroup(CUeventGroup *pEventGroup)
{
    NvU32 idx = 0;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if(pEventGroup->arch.maxwellEventGroup)
    {
        if(pEventGroup->arch.maxwellEventGroup->pParsedClk)
        {
            // Freeing the extra space as well which is allocated for profiling elapsed_clocks
            for (idx = 0; idx < (CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS +  CU_PROF_ELAPSED_CLOCK_SLOT); idx++) {
                if(pEventGroup->arch.maxwellEventGroup->pParsedClk->pParsedUnit[idx])
                {
                    free (pEventGroup->arch.maxwellEventGroup->pParsedClk->pParsedUnit[idx]);
                    pEventGroup->arch.maxwellEventGroup->pParsedClk->pParsedUnit[idx] = NULL;
                }
            }
            if(pEventGroup->arch.maxwellEventGroup->pParsedClk->values) {
                free (pEventGroup->arch.maxwellEventGroup->pParsedClk->values);
                pEventGroup->arch.maxwellEventGroup->pParsedClk->values = NULL;
            }

            free(pEventGroup->arch.maxwellEventGroup->pParsedClk);
            pEventGroup->arch.maxwellEventGroup->pParsedClk = NULL;
        }

        if(pEventGroup->arch.maxwellEventGroup->pSM)
        {
            NvU32 sig_cnt = 0, smcntr_idx = 0, j = 0;
            CUSMCtrInfo *pSM = NULL;
            pSM=pEventGroup->arch.maxwellEventGroup->pSM;
            if(pSM->values) {
                free (pSM->values);
                pSM->values = NULL;
            }
            if(pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_SMPERF) {
                // Free the memory allocated additionally for splitted counters, if any.
                for(sig_cnt=0; sig_cnt < pEventGroup->totalCounters; sig_cnt++)
                {
                    if(pSM->splitParts[sig_cnt] > 1) {
                        for(j=smcntr_idx; j<(smcntr_idx + pSM->splitParts[sig_cnt]); j++) {
                            free(pSM->sigtableInfo[j]->pEventData);
                            free(pSM->sigtableInfo[j]);
                        }
                    }
                    smcntr_idx += pSM->splitParts[sig_cnt];
                }
            }
            if(pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX){
                // Free the memory allocated additionally for splitted counters, if any.
                for(sig_cnt=0; sig_cnt < pEventGroup->totalCounters; sig_cnt++)
                {
                    //SMPC table entry was temporarily created for HWPM mux signals
                    free(pSM->sigtableInfo[sig_cnt]->pEventData);
                    free(pSM->sigtableInfo[sig_cnt]);
                }
            }
            free(pSM);
            pSM = NULL;
        }

        free(pEventGroup->arch.maxwellEventGroup);
        pEventGroup->arch.maxwellEventGroup = NULL;
    }

    return CUPROF_SUCCESS;
}

CUprofResult maxwellPerfmonEventGroupCreate(CUctx *pCtx, CUeventGroup **pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    CUeventGroup *pGroup = NULL;

    CU_TRACE_FUNCTION();

    CU_ASSERT(pEventGroup);
    CU_ASSERT(pCtx);

    pGroup = (CUeventGroup*)malloc(sizeof(CUeventGroup));
    if (pGroup == NULL) {
        CU_DEBUG_PRINT(("Failed to allocate memory to event group\n"));
        return CUPROF_ERROR_OUT_OF_MEMORY;
    }
    cuosMemset(pGroup, 0, sizeof(CUeventGroup));

    pGroup->domainId = INVALID_DOMAIN_ID;
    pGroup->pCtx = pCtx;                 //Context for which eventgroup is created

    // Initializing the profiling scope of the event Group.
    // The scope of the event group will be set by CUPTI based on following:
    //      1. Domain scope of the event
    //      2. Scope of the event which user sets.
    pGroup->eventGroupScope = CU_EVENT_GROUP_SCOPE_FORCE_INT;

    *pEventGroup = pGroup;

    if (pCtx->pmNew == NULL) {
        status = perfmonStructCreate(&pCtx->pmNew);
        if (status != CUPROF_SUCCESS) {
            goto Exit;
        }
    }

    if (pCtx->pmNew->egList == NULL) {
        // event object list hasn't been init yet, do it now
        status = (CUprofResult)listInit(&pCtx->pmNew->egList, NULL, NULL, NULL, egCompareData);
        if (status != CUPROF_SUCCESS) {
            goto Exit;
        }
    }

    // add to the event group list maintained in the context
    listAddToHead(pCtx->pmNew->egList, *pEventGroup);

    pCtx->pmNew->totalEventGroups++;
    return CUPROF_SUCCESS;

Exit:
    //If any error occurs, free allocated memory and return NULL
    maxwellDestroyEventGroup(pGroup);
    free(pGroup->values);
    free(pGroup);
    free (pCtx->pmNew);
    pCtx->pmNew = NULL;

    *pEventGroup = NULL;
    CU_ERROR_PRINT(("maxwellPerfmonEventGroupCreate Failed\n"));
    return status;
}

CUprofResult maxwellPerfmonEventGroupDestroy(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 i = 0;
    CUeventInfo *currEvent = NULL;
    void *eventBase = NULL;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if (pEventGroup->isEnabled) {
        // don't allow destroy for enabled event group
        return CUPROF_ERROR_UNKNOWN;
    }

    // deallocate arch specific eventgroup
    status = maxwellDestroyEventGroup(pEventGroup);

    currEvent = (CUeventInfo*)listGetNext(pEventGroup->pEventInfoList, &eventBase);
    for (i = 0; (i < pEventGroup->totalCounters) && currEvent; i++, currEvent = (CUeventInfo*)listGetNext(NULL, &eventBase)) {
        if(currEvent) {
            if(pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW) {
                free(currEvent->pEventData);
            }
            free(currEvent);
        }
    }

    // destroy event list
    if (pEventGroup->pEventInfoList) {
        listDestroy(pEventGroup->pEventInfoList);
        pEventGroup->pEventInfoList = NULL;
    }
    // deallocate values array
    free (pEventGroup->values);
    pEventGroup->values = NULL;

    // remove event group from list first
    listRemFrom(pEventGroup->pCtx->pmNew->egList, pEventGroup);

    // reduce event group count in context
    pEventGroup->pCtx->pmNew->totalEventGroups--;

    if(pEventGroup->nopTrigSwCounterData) {
        free(pEventGroup->nopTrigSwCounterData);
        pEventGroup->nopTrigSwCounterData = NULL;
    }
    free (pEventGroup);
    pEventGroup = NULL;

    return status;
}

// traverse domain signal table for matching signal
static NV_INLINE CUeventInfo* maxwellLookupDomainSignalTable(CUdomainData *pDomainData, const NvU32 eventID)
{
    NvU32 sigTableIdx = 0, signalTableEntrySize = 0;
    CUeventInfo* pEventTableInfo_temp = NULL;
    void* pEventData = NULL;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pDomainData);

    pEventTableInfo_temp = (CUeventInfo*)calloc(1, sizeof(CUeventInfo));
    if (pEventTableInfo_temp == NULL) {
        CU_DEBUG_PRINT(("Failed to allocate memory to pEventTableInfo_temp\n"));
        return NULL;
    }
    for(sigTableIdx = 0; sigTableIdx < pDomainData->numPerfSignalTables; sigTableIdx++) {
        perfmonGetSizeOfSignalTableEntry(pDomainData->pEventTableInfo[sigTableIdx].signalTableType,
                                         &signalTableEntrySize);

        pEventData = pDomainData->pEventTableInfo[sigTableIdx].pEventData;
        while (((CUeventDataBasic*)pEventData)->signalId != INVALID_PM_SIGNAL_NEW) {
            if (eventID == ((CUeventDataBasic*)pEventData)->signalId) {
                pEventTableInfo_temp->signalTableType = pDomainData->pEventTableInfo[sigTableIdx].signalTableType;
                pEventTableInfo_temp->pEventData = pEventData;
                return pEventTableInfo_temp;
            }
            pEventData = (void*)((NvU8*)pEventData + signalTableEntrySize);
        }
    }
    // return NULL if not found
    free(pEventTableInfo_temp);
    return NULL;
}
//*****************************************************************
static CUprofResult getWatchbus(signalConfig *tempSignalConfig, NvU32 startBit, NvU32 partWidth, NvU32 width, NvU32 *out)
{
    NvU32 startWord = 0;
    NvU32 endWord = 0;
    NvU32 startPos = 0;
    NvU32 endPos = 0;
    NvU32 startWatchBus = 0;
    NvU32 endWatchBus = 0;
    NvU32 endBit = (startBit+partWidth-1);

    startWord = startBit >> 2; startPos = startBit & 3;
    endWord = endBit >> 2; endPos = endBit & 3;
    startWatchBus = tempSignalConfig->tempWatchbus[startWord];
    endWatchBus = tempSignalConfig->tempWatchbus[endWord];

    startPos *= 8; endPos = ((endPos + 1) * 8) - 1;
    *out = 0;
    if (startWatchBus == endWatchBus) {
        *out = REF_VAL(endPos:startPos, startWatchBus);
    } else {
        *out |= REF_VAL(31:startPos, startWatchBus);
        *out |= (REF_VAL(endPos:0, endWatchBus)) << (32 - startPos);
        //*out |= startWatchBus >> (startPos * 8);
        //*out |= endWatchBus << ((4 - startPos) * 8);
    }

    if (partWidth < width) {
        //false watchbus signal to avoid garbage values
        startWatchBus = (FALSE_WATCH_BUS_SIGNAL<<24) | (FALSE_WATCH_BUS_SIGNAL<<16) |
                        (FALSE_WATCH_BUS_SIGNAL<<8) | (FALSE_WATCH_BUS_SIGNAL);
        *out |= (REF_VAL((width*8-1):(partWidth*8), startWatchBus)) << (partWidth*8);
    }

    return CUPROF_SUCCESS;
}

static CUprofResult getEventSpec(const CUparsedClk *pTempParsedClk, signalConfig *tempSignalConfig, NvU32 *pEventSpec, NvU32 *pNewMode, NvU32 totalCounters) {

    NvU32 mode = tempSignalConfig->mode;
    NvU32 busWidth = tempSignalConfig->busWidth;

    CU_TRACE_FUNCTION();

    *pEventSpec = 0;

    // select the right event specification for each counter
    if (pTempParsedClk) {
        //Check mode compatibility first
        //Check if this counter has event available
        //set new mode if everything goes fine
        switch(mode) {
            case NV_PMM_CONTROL_ADDTOCTR_INCR:
                //Don't allow INCR4444 with INCR mode if signal width is 0. INCR4444 doesn't allow counter
                //to be incremented on a logical combination.
                if ((pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_2X4B4I) ||
                    ((pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_4444) && (tempSignalConfig->busWidth == 0))) {
                    return CUPROF_ERROR_NOT_COMPATIBLE;
                }

                if ((pTempParsedClk->eventSpecUsed & NV_PMM_SAMPLE) == 0) {
                    *pEventSpec = NV_PMM_SAMPLE;
                    tempSignalConfig->watchBus[NV_PMM_SAMPLE_BIT_POS] = tempSignalConfig->tempWatchbus[0];
                    tempSignalConfig->partNumber |= (NV_PMM_SAMPLE_BIT_POS + 1);
                }
                else if ((pTempParsedClk->eventSpecUsed & NV_PMM_TRIG0) == 0) {
                    *pEventSpec = NV_PMM_TRIG0;
                    tempSignalConfig->watchBus[NV_PMM_TRIG0_BIT_POS] = tempSignalConfig->tempWatchbus[0];
                    tempSignalConfig->partNumber |= (NV_PMM_TRIG0_BIT_POS + 1);
                }
                //Keep TRIG1 and EVENT at the end so that we can allow the event/TRIG 4/6 modes along with INCR
                else if ((pTempParsedClk->eventSpecUsed & NV_PMM_EVENT) == 0) {
                    *pEventSpec = NV_PMM_EVENT;
                    tempSignalConfig->watchBus[NV_PMM_EVENT_BIT_POS] = tempSignalConfig->tempWatchbus[0];
                    tempSignalConfig->partNumber |= (NV_PMM_EVENT_BIT_POS + 1);
                }
                else if ((pTempParsedClk->eventSpecUsed & NV_PMM_TRIG1) == 0) {
                    *pEventSpec = NV_PMM_TRIG1;
                    tempSignalConfig->watchBus[NV_PMM_TRIG1_BIT_POS] = tempSignalConfig->tempWatchbus[0];
                    tempSignalConfig->partNumber |= (NV_PMM_TRIG1_BIT_POS + 1);
                }
                else
                    //All 4 events are used
                    return CUPROF_ERROR_MAX_LIMIT_REACHED;

                if (pTempParsedClk->mode != (NvU32)-1) {
                    *pNewMode = pTempParsedClk->mode;
                }

                //mode is INCR then set the mode only if mode is not initialized, else it will be subset of some other compatible mode.
                if (pTempParsedClk->mode == (NvU32) -1)
                    *pNewMode = mode;

                break;

            case NV_PMM_CONTROL_ADDTOCTR_EVENT4:
            case NV_PMM_CONTROL_ADDTOCTR_TRIG4:
                CU_ASSERT(busWidth <= 4);

            case NV_PMM_CONTROL_ADDTOCTR_EVENT6:
            case NV_PMM_CONTROL_ADDTOCTR_TRIG6:
                CU_ASSERT(busWidth <= 6);
                if ((pTempParsedClk->mode != NV_PMM_CONTROL_ADDTOCTR_INCR) && (pTempParsedClk->mode != (NvU32) -1))
                    return CUPROF_ERROR_NOT_COMPATIBLE;

                if ((pTempParsedClk->eventSpecUsed & NV_PMM_TRIG1) || (pTempParsedClk->eventSpecUsed & NV_PMM_EVENT))
                    //The events required for the mode are not available
                    return CUPROF_ERROR_NOT_COMPATIBLE;

                if (busWidth == 2) {
                    tempSignalConfig->watchBus[NV_PMM_EVENT_BIT_POS] |= (tempSignalConfig->tempWatchbus[1] & 0x0000ffff);
                } else {
                    tempSignalConfig->watchBus[NV_PMM_TRIG1_BIT_POS] = tempSignalConfig->tempWatchbus[1];
                    tempSignalConfig->watchBus[NV_PMM_EVENT_BIT_POS] |= tempSignalConfig->tempWatchbus[0];
                }

                *pEventSpec = NV_PMM_TRIG1 | NV_PMM_EVENT;

                *pNewMode = mode;
                break;

            case NV_PMM_CONTROL_ADDTOCTR_2X4B4I:
                if ((pTempParsedClk->mode != NV_PMM_CONTROL_ADDTOCTR_2X4B4I) && (pTempParsedClk->mode != (NvU32) -1))
                    return CUPROF_ERROR_NOT_COMPATIBLE;

                if (((pTempParsedClk->eventSpecUsed & NV_PMM_TRIG1) == 0) || ((pTempParsedClk->eventSpecUsed & NV_PMM_EVENT) == 0)) {
                    tempSignalConfig->watchBus[NV_PMM_TRIG1_BIT_POS] = tempSignalConfig->tempWatchbus[0];
                    tempSignalConfig->watchBus[NV_PMM_EVENT_BIT_POS] |= tempSignalConfig->tempWatchbus[1];

                    *pEventSpec = NV_PMM_TRIG1 | NV_PMM_EVENT;
                }
                else if (((pTempParsedClk->eventSpecUsed & NV_PMM_TRIG0) == 0) || ((pTempParsedClk->eventSpecUsed & NV_PMM_SAMPLE) == 0)) {
                    tempSignalConfig->watchBus[NV_PMM_SAMPLE_BIT_POS] = tempSignalConfig->tempWatchbus[0];
                    tempSignalConfig->watchBus[NV_PMM_TRIG0_BIT_POS] |= tempSignalConfig->tempWatchbus[1];

                    *pEventSpec = NV_PMM_TRIG0 | NV_PMM_SAMPLE;
                }
                else
                    //The events required for the mode are not available
                    return CUPROF_ERROR_MAX_LIMIT_REACHED;

                *pNewMode = mode;
                break;

            case NV_PMM_CONTROL_ADDTOCTR_4444:
            {
                NvU32 counter = 0;
                if ((pTempParsedClk->mode != (NvU32)-1)
                    && (pTempParsedClk->mode != NV_PMM_CONTROL_ADDTOCTR_4444) 
                    && (pTempParsedClk->mode != NV_PMM_CONTROL_ADDTOCTR_INCR)) {
                    return CUPROF_ERROR_NOT_COMPATIBLE;
                }

                if (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_INCR) {
                    //If eventgroup mode is INCR and all previously added counters are
                    //single bit counters, allow promoting mode to 4444.
                    while (counter < totalCounters) {
                        if (pTempParsedClk->width[counter] == 0 && pTempParsedClk->eventspec[counter] != NV_ELAPSED_CLOCKS) {
                            //Cannot allow 4444 counter with counter in INCR mode that increments on logical commbination
                            return CUPROF_ERROR_NOT_COMPATIBLE;
                        }
                        counter++;
                    }
                }
                {
                    NvU32 partNumber = 0, startPos = 0, partWidth = 0, out = 0, eventSpecUsed = 0, spec = NV_PMM_TRIG0_BIT_POS;
                    eventSpecUsed = pTempParsedClk->eventSpecUsed;
                    while ((busWidth > 0) && (spec <= NV_PMM_SAMPLE_BIT_POS)) {
                        //Keep TRIG1 and EVENT at the end so that we can allow the event/TRIG 4/6 modes along with INCR
                        if ((eventSpecUsed & (1 << spec)) == 0) {
                            eventSpecUsed |= (1 << spec);
                            *pEventSpec |= (1 << spec);
                            partWidth = (busWidth >= 4) ? 4 : busWidth;
                            getWatchbus(tempSignalConfig, startPos, partWidth, 4, &out);
                            //TBD add false signal here at the beginning if busWidth < 4
                            startPos += partWidth;
                            tempSignalConfig->watchBus[spec] = out;
                            busWidth -= partWidth;
                            //Adding + 1 to eventspec position as it can't be 0 becuase then we cannot
                            //distinguish between uninitialized and spec 0.
                            //Can't initialize to 0xff as we need to OR the part numbers (increases complexity)
                            tempSignalConfig->partNumber |= ((spec + 1) << (partNumber * 8));
                            partNumber++;
                        }
                        spec++;
                    }
                    if ((spec > NV_PMM_SAMPLE_BIT_POS) && (busWidth > 0)) {
                        //All 4 events are used
                        return CUPROF_ERROR_MAX_LIMIT_REACHED;
                    }
                }
                *pNewMode = mode;
            }
            break;
        }
    }
    return CUPROF_SUCCESS;
}


#define GETVAL(n, drf) (((n)>>DRF_SHIFT(drf))&DRF_MASK(drf))
#define SETVAL(n, drf) (((n)&DRF_MASK(drf))<<DRF_SHIFT(drf))

#define CHECK_AND_SET_GROUP_ADD(oldAdd, newAdd) \
    do { \
    if ((oldAdd != INVALID_ADDRESS) && (oldAdd != newAdd)) {\
    status = CUPROF_ERROR_NOT_COMPATIBLE; \
    goto EXIT; \
    } else if (oldAdd == INVALID_ADDRESS) { \
    oldAdd = newAdd; \
    } \
    } while(0)

#define CHECK_AND_SET_GROUP_MASK_VAL(oldMask, oldVal, drf, val) \
    do { \
    if((oldMask != 0) && (GETVAL(oldMask, drf)!=0)) {\
    n = GETVAL(oldVal, drf); \
    if (val != n) {\
    status = CUPROF_ERROR_NOT_COMPATIBLE; \
    goto EXIT;  \
    }\
    } else {\
    oldMask = DRF_REPLACE(oldMask, 0xffffffff, endBit:startBit);\
    oldVal  = DRF_REPLACE(oldVal, val, endBit:startBit);\
    }\
    } while(0)

static CUprofResult performUnitCompatibilityCheck(CUparsedClk *pParsedClk, PerfUnitTable *tempPerfUnitTable, signalConfig *tempSignalConfig, CUeventDataHwpm * pEventData, NvU32 init)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 k =0, j = 0, n = 0, i = 0, startBit = 0, endBit = 0, unitsReqd = 1, unit = 0;
    NvU32 foundInTemp = 0, foundInParsedClk = 0, unitId = 0, eventGroup = 0;

    if (pEventData->pmUnitId == PM_UNIT_TEX_T3) {
        unitsReqd = 2;
    }

    for (unit = 0; unit < unitsReqd; unit++) {
        //TBD generalize this
        if (unit == 0) {
            unitId = pEventData->pmUnitId;
            eventGroup = pEventData->eventGroup;
        } else if (unit == 1){
            unitId = pEventData->pmUnitId1;
            eventGroup = pEventData->eventGroup1;
        }
        while (tempPerfUnitTable[j].pmUnitId != PM_UNIT_MAX) {
            if (tempPerfUnitTable[j].pmUnitId == unitId) {

                //if (init)
                {
                    i = 0;
                    while(tempSignalConfig->unitInfo[i]) {
                        //if (tempSignalConfig->unitInfo[i]->groupSelAddress == tempPerfUnitTable[j].pmGroupSelRegInfo.regOffset) {
                        if (tempSignalConfig->unitInfo[i]->unitId == tempPerfUnitTable[j].pmUnitId) {

                            //another signal with same unit has already been added while preparing config for this expt
                            //Should be true only for expt cases
                            foundInTemp = 1;
                            break;
                        }
                        i++;
                    }
                    k = 0;
                    while(pParsedClk && pParsedClk->pParsedUnit[k] && !foundInTemp) {
                        //Check if have already added any signal from same unit and same group
                        //if so, assign those values to temp values so that we can check if
                        //we are using same group else return error.
                        //if (pParsedClk->pParsedUnit[k]->groupSelAddress == tempPerfUnitTable[j].pmGroupSelRegInfo.regOffset) {
                        if (pParsedClk->pParsedUnit[k]->unitId == tempPerfUnitTable[j].pmUnitId) {

                            tempSignalConfig->unitInfo[i] = (signalUnitConfig *) malloc(sizeof(signalUnitConfig));
                            if (!tempSignalConfig->unitInfo[i]) {
                                status = CUPROF_ERROR_OUT_OF_MEMORY;
                                goto EXIT;
                            }
                            //CU_ASSERT(pParsedClk->pParsedUnit[k]->unitId == tempPerfUnitTable[j].pmUnitId);
                            tempSignalConfig->unitInfo[i]->groupSelAddress = pParsedClk->pParsedUnit[k]->groupSelAddress;
                            tempSignalConfig->unitInfo[i]->groupSelMask = pParsedClk->pParsedUnit[k]->groupSelMask;
                            tempSignalConfig->unitInfo[i]->groupSelValue = pParsedClk->pParsedUnit[k]->groupSelValue;
                            tempSignalConfig->unitInfo[i]->unitId = pParsedClk->pParsedUnit[k]->unitId;
                            foundInParsedClk = 1;
                            break;
                        }
                        k++;
                    }
                }

                if (!foundInParsedClk && !foundInTemp) {
                    //This is a new unit
                    tempSignalConfig->unitInfo[i] = (signalUnitConfig *) malloc(sizeof(signalUnitConfig));
                    if (!tempSignalConfig->unitInfo[i]) {
                        status = CUPROF_ERROR_OUT_OF_MEMORY;
                        goto EXIT;
                    }
                    memset(tempSignalConfig->unitInfo[i], 0, sizeof(signalUnitConfig));
                    tempSignalConfig->unitInfo[i]->groupSelAddress = INVALID_ADDRESS;
                    tempSignalConfig->unitInfo[i]->unitId = unitId;
                }

                CHECK_AND_SET_GROUP_ADD(tempSignalConfig->unitInfo[i]->groupSelAddress, tempPerfUnitTable[j].pmGroupSelRegInfo.regOffset);

                startBit = tempPerfUnitTable[j].pmGroupSelRegInfo.firstBit;
                endBit   = startBit + tempPerfUnitTable[j].pmGroupSelRegInfo.subFieldWidth - 1;
                //This macro should check if the group is already set, the value shgoudl be equal, if not return error.
                CHECK_AND_SET_GROUP_MASK_VAL(tempSignalConfig->unitInfo[i]->groupSelMask, tempSignalConfig->unitInfo[i]->groupSelValue, endBit:startBit, eventGroup);

    #if 0
                //TBD enable this part only of we can remove SetPMEnableReg.
                CU_ASSERT(tempSignalConfig->unitInfo[i]->groupSelAddress == tempPerfUnitTable[j].pPMEnableRegInfo->regOffset)
                    startBit = tempPerfUnitTable[j].pPMEnableRegInfo.firstBit;
                endBit   = startBit + tempPerfUnitTable[j].pPMEnableRegInfo.subFieldWidth - 1;
                CHECK_AND_SET_GROUP_MASK_VAL(tempSignalConfig->unitInfo[i]->groupSelMask, tempSignalConfig->unitInfo[i]->groupSelValue, endBit:startBit, 1);
    #endif
                tempSignalConfig->unitInfo[i]->pPerfUnitTable = &tempPerfUnitTable[j];
                break;
            }
            j++;
        }
    }
EXIT:
    return status;
}

static CUprofResult getExptConfig(CUeventGroup *pEventGroup, CUdomainData *pDomainData, CUeventDataHwpmExpt *pEventData,
                                  signalConfig *tempSignalConfig)
{
    CUeventDataHwpm *pEventdataTemp[7] = {NULL};
    CUeventInfo *pEventInfoTemp[7] = {NULL};
    CUeventInfo *pEventInfoIncr = NULL;
    NvU32 j = 0, numSignals = 0, k = 0, busWidthIncrSignal = 0;
    CUprofResult status = CUPROF_SUCCESS;
    CUparsedClk *pParsedClk =  pEventGroup->arch.maxwellEventGroup->pParsedClk;

    numSignals = 0;
    //TBD add support for 7 signal combination later
    while((pEventData->signalId_combination[numSignals] != INVALID_PM_SIGNAL_NEW) && (numSignals < 4))
    {
        pEventInfoTemp[numSignals] = maxwellLookupDomainSignalTable(pDomainData, pEventData->signalId_combination[numSignals]);
        if(pEventInfoTemp[numSignals])
        {
            pEventdataTemp[numSignals] = (CUeventDataHwpm*)pEventInfoTemp[numSignals]->pEventData;
            //CU_ASSERT(pEventdataTemp[numSignals]->pmUnitId == pEventData->pmUnitId); //For LTC this assert will not be valid, check for groupreg and mask instead.
            CU_ASSERT(pEventdataTemp[numSignals]->busWidth == 1);
            tempSignalConfig->tempWatchbus[0] |= ((pEventdataTemp[numSignals]->watchBus & 0xff) << (numSignals * 8));

            status = performUnitCompatibilityCheck(pParsedClk, pEventGroup->pCtx->device->state.pPerfUnitTable, tempSignalConfig, pEventdataTemp[numSignals], (!numSignals));
            if(status != CUPROF_SUCCESS) {
                numSignals++;
                goto EXIT;
            }
        } else {
            status = CUPROF_ERROR_INVALID_EVENT_ID;
                numSignals++;
            goto EXIT;
        }
        numSignals++;
    }
    if ((numSignals > 4) && (numSignals == 0)) {
        //Support upto 7 bit combination later
        //numSignals = 0 so we cannot call this a real expt,
        //in expt, it is assumed that the combination is valid
        CU_ASSERT(0);
        status = CUPROF_ERROR_NOT_COMPATIBLE;
        goto EXIT;
    }
    if (pEventData->signalId_increment != INVALID_PM_SIGNAL_NEW) {
        pEventInfoIncr = maxwellLookupDomainSignalTable(pDomainData, pEventData->signalId_increment);
        if (!pEventInfoIncr) {
            //Increment event not found
            status = CUPROF_ERROR_INVALID_EVENT_ID;
            goto EXIT;
        }
        busWidthIncrSignal = ((CUeventDataHwpm*)pEventInfoIncr->pEventData)->busWidth;
        if (busWidthIncrSignal > 6) {
            //can't use signal > 6bit in expt
            CU_ASSERT(0);
            status = CUPROF_ERROR_NOT_COMPATIBLE;
            goto EXIT;
        }

        if ((numSignals > 2) && (busWidthIncrSignal > 4)) {
            //for signals > 4, the combination cannot be > 2 signals
            CU_ASSERT(0);
            status = CUPROF_ERROR_NOT_COMPATIBLE;
            goto EXIT;
        }

        status = performUnitCompatibilityCheck(pParsedClk, pEventGroup->pCtx->device->state.pPerfUnitTable, tempSignalConfig,
            (CUeventDataHwpm*)pEventInfoIncr->pEventData, 0);
        if(status != CUPROF_SUCCESS)
            goto EXIT;
        //setup watchbus
        for (k = 0; k < 4; k++) {
            //Store watchbus for LSB 4 bits in tempWatchbus[0]
            if (k < busWidthIncrSignal)
                tempSignalConfig->tempWatchbus[1] |= (((((CUeventDataHwpm *)pEventInfoIncr->pEventData)->watchBus & 0xff) + k) << (k * 8));
            else
                tempSignalConfig->tempWatchbus[1] |= (FALSE_WATCH_BUS_SIGNAL << (k * 8));
        }
        if (busWidthIncrSignal > 4) {
            for (k = 4; k < 6; k++) {
                //Store watchbus for MSB 2 bits in the upper part of the tempWatchbus[1]
                if (k < busWidthIncrSignal)
                    tempSignalConfig->tempWatchbus[0] |= (((((CUeventDataHwpm *)pEventInfoIncr->pEventData)->watchBus & 0xff) + k) << ((k - 2) * 8));
                else
                    //Add false signal to the vacant space.
                    tempSignalConfig->tempWatchbus[0] |= (FALSE_WATCH_BUS_SIGNAL << ((k - 2) * 8));
            }
        }
    }
    //If we reach here, the groups are compatible, set expected mode for this signal.
    if (tempSignalConfig->mode == 0) {
        //mode is not explicitly set, try to apply generic rules, this might not give optimal combinations
        if (busWidthIncrSignal == 0) {
            tempSignalConfig->mode = NV_PMM_CONTROL_ADDTOCTR_INCR; //incrment by 1 on a logical combination of 4 signals in the table.
        }
        //No need to use NV_PMM_CONTROL_ADDTOCTR_EVENT4 in maxwell
        else if (busWidthIncrSignal <= 4) {
            tempSignalConfig->mode = NV_PMM_CONTROL_ADDTOCTR_2X4B4I;
        } else if (busWidthIncrSignal <= 6) {
            tempSignalConfig->mode = NV_PMM_CONTROL_ADDTOCTR_EVENT6;
        }
    }

    tempSignalConfig->busWidth = busWidthIncrSignal;
    tempSignalConfig->function = pEventData->function;
    tempSignalConfig->delaySelect = pEventData->dSel;

EXIT:
    for(j = 0; j < numSignals; j++) {
        free(pEventInfoTemp[j]);
    }
    free(pEventInfoIncr);
    return status;
}

static CUprofResult getSigConfig(CUeventGroup *pEventGroup, CUdomainData *pDomainData, PerfSignalHwpm *pEventData, signalConfig *tempSignalConfig)
{
    CUeventInfo *pEventInfo = NULL;
    NvU32 k = 0, busWidthIncrSignal = 0, busWidth = 0;
    CUprofResult status = CUPROF_SUCCESS;
    CUparsedClk *pParsedClk =  pEventGroup->arch.maxwellEventGroup->pParsedClk;

    pEventInfo = maxwellLookupDomainSignalTable(pDomainData, pEventData->signalId);
    if (!pEventInfo) {
        //Increment event not found
        status = CUPROF_ERROR_INVALID_EVENT_ID;
        goto EXIT;
    }

    if (pEventData->busWidth > 14) {
        //can't use signal > 6bit in expt
        CU_ASSERT(0);
        status = CUPROF_ERROR_NOT_COMPATIBLE;
        goto EXIT;
    }

    status = performUnitCompatibilityCheck(pParsedClk, pEventGroup->pCtx->device->state.pPerfUnitTable, tempSignalConfig,
        pEventData, 1);
    if(status != CUPROF_SUCCESS)
        goto EXIT;

    //setup watchbus
    busWidth = 0;
    busWidthIncrSignal = pEventData->busWidth;
    if ((busWidthIncrSignal > 0) && (busWidthIncrSignal <= 14)) {
        //TBD write macros for below loops after debugging
        for (k = 0; k < 4; k++) {
            if (busWidth < busWidthIncrSignal) {
                tempSignalConfig->tempWatchbus[0] |= (((pEventData->watchBus & 0xff) + k) << (k * 8));
                busWidth++;
            } else {
                //Add false signal in vacant space
                tempSignalConfig->tempWatchbus[0] |= ((FALSE_WATCH_BUS_SIGNAL) << (k * 8));
            }
        }
        for (k = 4; k < 8; k++) {
            if (busWidth < busWidthIncrSignal) {
                tempSignalConfig->tempWatchbus[1] |= (((pEventData->watchBus & 0xff) + k) << ((k-4) * 8));
                busWidth++;
            } else {
                //Add false signal in vacant space
                tempSignalConfig->tempWatchbus[1] |= ((FALSE_WATCH_BUS_SIGNAL) << ((k-4) * 8));
            }
        }
        for (k = 8; k < 12; k++) {
            if (busWidth < busWidthIncrSignal) {
                tempSignalConfig->tempWatchbus[2] |= (((pEventData->watchBus & 0xff) + k) << ((k-8) * 8));
                busWidth++;
            } else {
                tempSignalConfig->tempWatchbus[2] |= ((FALSE_WATCH_BUS_SIGNAL) << ((k-8) * 8));
            }
        }
        for (k = 12; k < 14; k++) {
            if (busWidth < busWidthIncrSignal) {
                tempSignalConfig->tempWatchbus[3] |= (((pEventData->watchBus & 0xff) + k) << ((k-12) * 8));
                busWidth++;
            } else {
                tempSignalConfig->tempWatchbus[3] |= ((FALSE_WATCH_BUS_SIGNAL) << ((k-12) * 8));
            }
        }
    }

    tempSignalConfig->busWidth = busWidthIncrSignal;
    tempSignalConfig->function = pEventData->function;

    //If we reach here, the groups are compatible, set expected mode for this signal.
    if (tempSignalConfig->mode == 0) {
        //mode is not explicitly set, try to apply generic rules, this might not give optimal combinations
        if (busWidthIncrSignal == 1) {
            //Increment signals can be profiled along with experiments as well,
            //so use NV_PMM_CONTROL_ADDTOCTR_INCR here
            //It can be promoted to be used with the 2X4B4I and EVENT6 mode
            //It can also be promoted to 4444 mode
            tempSignalConfig->mode = NV_PMM_CONTROL_ADDTOCTR_INCR;
            //When in EVENT6 mode, watch bus is used from slot 1.
            tempSignalConfig->tempWatchbus[1] = tempSignalConfig->tempWatchbus[0];
        }
        else if ((busWidthIncrSignal > 1) && (busWidthIncrSignal <= 14)) {
            tempSignalConfig->mode = NV_PMM_CONTROL_ADDTOCTR_4444;
        } else {
            status = CUPROF_ERROR_NOT_COMPATIBLE;
            goto EXIT;
        }
    }

EXIT:
    free(pEventInfo);
    return status;

}
//*****************************************************************
// We can monitor up to four inc-by-1 experiments per domain in ModeB
// Each chiplet/PMM can be configured individually, so we have. 1x8 domains for sys + 4x1 gpcs + 4x2 gpctpcs
// + 6x2 fbps experiments that can run concurrently on gm000
static CUprofResult canSigBeProfiledModeB(CUeventGroup *pEventGroup, CUdomainData *pDomainData, CUeventInfo *pEventInfo, NvBool *added)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 i = 0, j = 0, k = 0;
    CUparsedClk  *pParsedClk = NULL;
    NvU32 eventSpec = 0, newMode = 0;
    signalConfig tempSignalConfig;

    CU_TRACE_FUNCTION();

    memset(&tempSignalConfig, 0, sizeof(signalConfig));

    pParsedClk = pEventGroup->arch.maxwellEventGroup->pParsedClk;
    if(!pParsedClk) {
        return CUPROF_ERROR_UNKNOWN;
    }

    if (pEventGroup->totalCounters == 0) {
        pParsedClk->eventSpecUsed = 0;
        pParsedClk->mode = (NvU32) -1;
        for (i = 0; i < CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS; i++) {
            pParsedClk->watchBus[i] = 0xefefefef; //Assuming this is false signal TBD check if assumption is still correct.
            pParsedClk->function[i] = 0;          //Assuming this is false signal TBD check if assumption is still correct.
        }
    }

    if (((CUeventDataHwpm*)pEventInfo->pEventData)->signalId == MAXWELL_ELAPSED_CYCLES_SM) {
        if(pParsedClk->isElapsedClocksProfiled) {
            status = CUPROF_ERROR_NOT_COMPATIBLE;
            *added = NV_FALSE;
            return status;
        }
        pParsedClk->eventspec[pEventGroup->totalCounters] = NV_ELAPSED_CLOCKS;
        pParsedClk->isElapsedClocksProfiled = 1;
        *added = NV_TRUE;
        return status;
    }

    if (pParsedClk->eventSpecUsed == (NV_PMM_TRIG1 | NV_PMM_EVENT | NV_PMM_TRIG0 | NV_PMM_SAMPLE))
        return CUPROF_ERROR_MAX_LIMIT_REACHED;

    //HWPM Mux experiments are not supported now.
    if(pEventInfo->signalTableType == PERF_SIG_TABLE_TYPE_HWPM_EXPT) {
        status = getExptConfig(pEventGroup, pDomainData, (CUeventDataHwpmExpt *)(pEventInfo->pEventData), &tempSignalConfig);
        if (status != CUPROF_SUCCESS)
            goto Failed;
    } else {
        status = getSigConfig(pEventGroup, pDomainData, (PerfSignalHwpm *)(pEventInfo->pEventData), &tempSignalConfig);
        if (status != CUPROF_SUCCESS)
            goto Failed;
    }

    //Setup the event mask and in vivel mode, set the partnumbers
    //TBD correctly return the error code if non_compatible or max_limit_reached
    status = getEventSpec(pParsedClk, &tempSignalConfig, &eventSpec, &newMode, pEventGroup->totalCounters);
    if (status != CUPROF_SUCCESS)
        goto Failed;

    if (((tempSignalConfig.unitInfo[0]->unitId == PM_UNIT_SMCORE) ||
        (tempSignalConfig.unitInfo[0]->unitId == PM_UNIT_SMQCTL) ||
        (tempSignalConfig.unitInfo[0]->unitId == PM_UNIT_MIO)) &&
        (pEventInfo->signalTableType == PERF_SIG_TABLE_TYPE_HWPMMUX)){
        NvU32 maxSignals;
        NvBool added = 0;
        maxwellPerfmonAddSMCounterEntryForHWPMMux(pEventGroup, pDomainData, pEventInfo, &added, &maxSignals);
        CU_ASSERT(added);
    }
    //No error, so add this signal in the parsedClk now
    j = 0;
    while(tempSignalConfig.unitInfo[j]) {
        k = 0;
        while(pParsedClk && pParsedClk->pParsedUnit[k]) {
            //Check if have already added any signal from same unit and same group
            //if so, assign those values to temp values so that we can check if
            //we are using same group else return error.
            //if (pParsedClk->pParsedUnit[k]->groupSelAddress == tempSignalConfig.unitInfo[j]->groupSelAddress) {
            if (pParsedClk->pParsedUnit[k]->unitId == tempSignalConfig.unitInfo[j]->unitId) {
                break;
            }
            k++;
        }

        if(!pParsedClk->pParsedUnit[k]) {
            pParsedClk->pParsedUnit[k] = (CUparsedUnit*)malloc(sizeof(CUparsedUnit));
            if(!pParsedClk->pParsedUnit[k]) goto Failed;
            cuosMemset(pParsedClk->pParsedUnit[k], 0, sizeof(CUparsedUnit));
        }

        pParsedClk->pParsedUnit[k]->unitId = tempSignalConfig.unitInfo[j]->unitId;
        pParsedClk->pParsedUnit[k]->groupSelAddress = tempSignalConfig.unitInfo[j]->groupSelAddress;
        pParsedClk->pParsedUnit[k]->groupSelMask = tempSignalConfig.unitInfo[j]->groupSelMask;
        pParsedClk->pParsedUnit[k]->groupSelValue = tempSignalConfig.unitInfo[j]->groupSelValue;

        pParsedClk->pParsedUnit[k]->pPerfUnitTable = tempSignalConfig.unitInfo[j]->pPerfUnitTable;
        j++;
    }

    pParsedClk->mode = newMode;
    pParsedClk->eventspec[pEventGroup->totalCounters] = eventSpec;
    pParsedClk->eventSpecUsed |= eventSpec;
    pParsedClk->width[pEventGroup->totalCounters] = tempSignalConfig.busWidth;
    pParsedClk->partNumber[pEventGroup->totalCounters] = tempSignalConfig.partNumber;


    if(eventSpec & NV_PMM_TRIG0) {
        pParsedClk->watchBus[NV_PMM_TRIG0_BIT_POS] = tempSignalConfig.watchBus[NV_PMM_TRIG0_BIT_POS];
        pParsedClk->function[NV_PMM_TRIG0_BIT_POS] = tempSignalConfig.function;
        pParsedClk->delaySelects[NV_PMM_TRIG0_BIT_POS] = tempSignalConfig.delaySelect;
    }
    if(eventSpec & NV_PMM_TRIG1) {
        pParsedClk->watchBus[NV_PMM_TRIG1_BIT_POS] = tempSignalConfig.watchBus[NV_PMM_TRIG1_BIT_POS];
        pParsedClk->function[NV_PMM_TRIG1_BIT_POS] = tempSignalConfig.function;
        pParsedClk->delaySelects[NV_PMM_TRIG1_BIT_POS] = tempSignalConfig.delaySelect;
    }
    if(eventSpec & NV_PMM_SAMPLE) {
        pParsedClk->watchBus[NV_PMM_SAMPLE_BIT_POS] = tempSignalConfig.watchBus[NV_PMM_SAMPLE_BIT_POS];
        pParsedClk->function[NV_PMM_SAMPLE_BIT_POS] = tempSignalConfig.function;
        pParsedClk->delaySelects[NV_PMM_SAMPLE_BIT_POS] = tempSignalConfig.delaySelect;
    }
    if(eventSpec & NV_PMM_EVENT) {
        pParsedClk->watchBus[NV_PMM_EVENT_BIT_POS] = tempSignalConfig.watchBus[NV_PMM_EVENT_BIT_POS];
        pParsedClk->function[NV_PMM_EVENT_BIT_POS] = tempSignalConfig.function;
        pParsedClk->delaySelects[NV_PMM_EVENT_BIT_POS] = tempSignalConfig.delaySelect;
    }

    if ((tempSignalConfig.mode != NV_PMM_CONTROL_ADDTOCTR_INCR) && (tempSignalConfig.mode != NV_PMM_CONTROL_ADDTOCTR_4444)) {
        if ((tempSignalConfig.mode == NV_PMM_CONTROL_ADDTOCTR_EVENT4 || tempSignalConfig.mode == NV_PMM_CONTROL_ADDTOCTR_EVENT6)) {
            pParsedClk->function[NV_PMM_EVENT_BIT_POS] = tempSignalConfig.function;
            pParsedClk->function[NV_PMM_TRIG1_BIT_POS] = 0xffff;
        } else if ((tempSignalConfig.mode == NV_PMM_CONTROL_ADDTOCTR_TRIG4 || tempSignalConfig.mode == NV_PMM_CONTROL_ADDTOCTR_TRIG6)) {
            pParsedClk->function[NV_PMM_EVENT_BIT_POS] = 0xffff;
            pParsedClk->function[NV_PMM_TRIG1_BIT_POS] = 0xffff;
        } else if (tempSignalConfig.mode == NV_PMM_CONTROL_ADDTOCTR_2X4B4I) {
            pParsedClk->function[NV_PMM_EVENT_BIT_POS] = 0xffff;
            pParsedClk->function[NV_PMM_TRIG0_BIT_POS] = 0xffff;
        }
    }

    *added = NV_TRUE;

    return status;

Failed:
    j = 0;
    while(tempSignalConfig.unitInfo[j]) {
        free(tempSignalConfig.unitInfo[j]);
        ++j;
    }

    return status;
}

//TBD get rid of following function. Search if we can use any domain id
static NvU32 getClkIdx(const CUctx *ctx, CUeventDomainID domainId, NvU32 chipletType)
{
    NvU32 clkIdx;
    NvU32 const (*domainIds)[PM_MAX_DOMAIN_PER_CHIPLET] = NULL;

    // GM107/GK106/GK107 domain Ids
#if NVCFG(GLOBAL_ARCH_MAXWELL)
    static const NvU32 gm000_domainIds[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        // sys chiplet
        {MAXWELL_CLK_DOMAIN_GM000_HOST0, MAXWELL_CLK_DOMAIN_GM000_MSD0, MAXWELL_CLK_DOMAIN_GM000_MSD1, MAXWELL_CLK_DOMAIN_GM000_PCIE0, MAXWELL_CLK_DOMAIN_GM000_PWR0, MAXWELL_CLK_DOMAIN_GM000_SYS0, MAXWELL_CLK_DOMAIN_GM000_XBAR0},

        // gpc chiplet
        //TBD : Returning same value for gpctpc0 and gpctpc1 domains.
        //The base values of pmmaddress are adjusted accordingly.
        {MAXWELL_CLK_DOMAIN_GM000_GPC0, MAXWELL_CLK_DOMAIN_GM000_GPCTPC},

        // fbp chiplet
        {MAXWELL_CLK_DOMAIN_GM000_FBP0, MAXWELL_CLK_DOMAIN_GM000_LTC0, MAXWELL_CLK_DOMAIN_GM000_LTC1, MAXWELL_CLK_DOMAIN_GM000_ROP0}
    };

#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200
    static const NvU32 gm200_domainIds[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        // sys chiplet
        {MAXWELL_CLK_DOMAIN_GM000_HOST0, MAXWELL_CLK_DOMAIN_GM000_MSD0, MAXWELL_CLK_DOMAIN_GM000_MSD1, MAXWELL_CLK_DOMAIN_GM200_PCIE0, MAXWELL_CLK_DOMAIN_GM000_PWR0, MAXWELL_CLK_DOMAIN_GM200_SYS0, MAXWELL_CLK_DOMAIN_GM000_XBAR0},

        // gpc chiplet
        //TBD : Returning same value for gpctpc0 and gpctpc1 domains.
        //The base values of pmmaddress are adjusted accordingly.
        {MAXWELL_CLK_DOMAIN_GM000_GPC0, MAXWELL_CLK_DOMAIN_GM200_GPCTPC},

        // fbp chiplet
        {MAXWELL_CLK_DOMAIN_GM000_FBP0, MAXWELL_CLK_DOMAIN_GM200_LTC0, MAXWELL_CLK_DOMAIN_GM200_LTC1, MAXWELL_CLK_DOMAIN_GM000_ROP0, MAXWELL_CLK_DOMAIN_GM200_ROP1}
    };
#endif // NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200
#endif // NVCFG(GLOBAL_ARCH_MAXWELL)
#if NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
    static const NvU32 gm20y_domainIds[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        // sys chiplet
        {MAXWELL_CLK_DOMAIN_GM20Y_ACB0, MAXWELL_CLK_DOMAIN_GM20Y_MC0, MAXWELL_CLK_DOMAIN_GM20Y_PWR0, MAXWELL_CLK_DOMAIN_GM20Y_SYS0},

        // gpc chiplet
        //TBD : Returning same value for gpctpc0 and gpctpc1 domains.
        //The base values of pmmaddress are adjusted accordingly.
        {MAXWELL_CLK_DOMAIN_GM20Y_GPC0, MAXWELL_CLK_DOMAIN_GM20Y_GPCTPC},

        // fbp chiplet
        {MAXWELL_CLK_DOMAIN_GM20Y_FBP0}
    };
#endif // NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
    CU_TRACE_FUNCTION();

    if (chipletType >= PM_MAX_CHIPLET_TYPES) {
        CU_ERROR_PRINT(("Invalid chiplet values\n"));
        CU_ASSERT (0);
        return PM_MAX_DOMAIN_PER_CHIPLET;
    }

    if (domainId == MAXWELL_CLK_DOMAIN_GM000_HWPMMUX) {
        //Hack hack hack
        //MAXWELL_CLK_DOMAIN_GM000_HWPMMUX will be a dummy id that is used to identify the HWPM signals profiled via SMPC.
        //We require this so that we can restrict profiling these signals with pure HWPM or pure SMPC signals
        //Currently there is no way to avoid this except having check at domain level, also it is possible that we will allow pure HWPM signals with pure SMPC.
        //Internally this domain id will be mapped to MAXWELL_CLK_DOMAIN_GM000_GPCTPC
        domainId = MAXWELL_CLK_DOMAIN_GM000_GPCTPC;
    }
    if (domainId == MAXWELL_CLK_DOMAIN_GM200_HWPMMUX) {
        domainId = MAXWELL_CLK_DOMAIN_GM200_GPCTPC;
    }
    if (domainId == MAXWELL_CLK_DOMAIN_GM20Y_HWPMMUX) {
        domainId = MAXWELL_CLK_DOMAIN_GM20Y_GPCTPC;
    }
    switch(ctx->device->state.chip) {
#if NVCFG(GLOBAL_ARCH_MAXWELL)
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM000 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM107):
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM000 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM108):
        domainIds = gm000_domainIds;
        break;
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200):
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM204):
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM206):
        domainIds = gm200_domainIds;
        break;
#endif // NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200
#endif // NVCFG(GLOBAL_ARCH_MAXWELL)
#if NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM20B):
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM21B
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM21B):
#endif // NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM21B
        domainIds = gm20y_domainIds;
        break;
#endif // NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
    default:
        CU_ASSERT(0);
        return (NvU32)-1;
        break;
    }

    for(clkIdx=0; clkIdx<(NvU32)PM_MAX_DOMAIN_PER_CHIPLET; clkIdx++)
    {
        if(domainIds[chipletType][clkIdx] == domainId)
            return clkIdx;
    }
    CU_ASSERT(clkIdx != PM_MAX_DOMAIN_PER_CHIPLET);
    CU_ASSERT(0);
    return PM_MAX_DOMAIN_PER_CHIPLET;
}

static CUprofResult tryAddingSmpcCounter(CUeventGroup *pEventGroup, CUdomainData *pDomainData, CUeventDataSmpc *pEventData)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 newGroupIdx = 0;
    CUSMCtrInfo *pSM = NULL;

    pSM = pEventGroup->arch.maxwellEventGroup->pSM;

    if(((pEventData->pmUnitId == PM_UNIT_SMCORE) || (pEventData->pmUnitId == PM_UNIT_MIO)) && (pSM->coreCount == CU_PROF_SM_CORE_PROFILED_MAX)) {
        return CUPROF_ERROR_NOT_COMPATIBLE;
    }
    else if((pEventData->pmUnitId == PM_UNIT_SMQCTL) && (pSM->qctlCount == CU_PROF_SM_QUAD_PROFILED_MAX)) {
        return CUPROF_ERROR_NOT_COMPATIBLE;
    }
    switch(pEventData->pmUnitId)
    {
    case PM_UNIT_SMCORE:
    case PM_UNIT_MIO:
        {
            NvU32 coreIdx = 0;
            while(coreIdx < pSM->numGroupsCore)
            {
                if(pEventData->eventGroup == pSM->groupsCore[coreIdx])
                {
                    newGroupIdx = coreIdx;
                    pSM->coreCount++;
                    break;
                }
                coreIdx++;
            }
            if(coreIdx == pSM->numGroupsCore)
            {
                if(pSM->numGroupsCore == CU_PROF_SM_CORE_PROFILED_MAX) {
                    return CUPROF_ERROR_NOT_COMPATIBLE;
                }
                newGroupIdx = pSM->numGroupsCore;
                pSM->groupsCore[pSM->numGroupsCore++] = pEventData->eventGroup;
                pSM->coreCount++;
            }
        }
        break;
    case PM_UNIT_SMQCTL:
        {
            NvU32 quadIdx = 0;
            while(quadIdx < pSM->numGroupsQuad)
            {
                if(pEventData->eventGroup == pSM->groupsQuad[quadIdx])
                {
                    newGroupIdx = quadIdx;
                    pSM->qctlCount++;
                    break;
                }
                quadIdx++;
            }
            if(quadIdx == pSM->numGroupsQuad)
            {
                if(pSM->numGroupsQuad == CU_PROF_SM_QUAD_PROFILED_MAX) {
                    return CUPROF_ERROR_NOT_COMPATIBLE;
                }
                newGroupIdx = pSM->numGroupsQuad;
                pSM->groupsQuad[pSM->numGroupsQuad++] = pEventData->eventGroup;
                pSM->qctlCount++;
            }
        }
        break;
    }

    pSM->function[pSM->SMCountersAdded] = pEventData->function;
    pSM->pmUnitId[pSM->SMCountersAdded] = pEventData->pmUnitId;
    pSM->mode[pSM->SMCountersAdded] = NV_SM_DSM_PERF_COUNTER_CONTROL_MODE_COUNT;

    pSM->perfEventInfo[pSM->SMCountersAdded]  = (newGroupIdx & 3) | (pEventData->perfEvent & 0x00000007) << 2;
    pSM->perfEventInfo[pSM->SMCountersAdded] |= ((newGroupIdx & 3) | ((pEventData->perfEvent & 0x00000070)>>4) << 2) << 5;
    pSM->perfEventInfo[pSM->SMCountersAdded] |= ((newGroupIdx & 3) | ((pEventData->perfEvent & 0x00000700)>>8) << 2) << 10;
    pSM->perfEventInfo[pSM->SMCountersAdded] |= ((newGroupIdx & 3) | ((pEventData->perfEvent & 0x00007000)>>12) << 2) << 15;
    pSM->perfEventInfo[pSM->SMCountersAdded] |= ((newGroupIdx & 3) | ((pEventData->perfEvent & 0x00070000)>>16) << 2) << 20;
    pSM->perfEventInfo[pSM->SMCountersAdded] |= ((newGroupIdx & 3) | ((pEventData->perfEvent & 0x00700000)>>20) << 2) << 25;

    return status;
}

static CUprofResult tryAddingMultiGroupOrLutCounter(CUeventGroup *pEventGroup, CUdomainData *pDomainData, CUeventDataSmpcExpt *pEventData, NvU32 signalTableType)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUeventDataSmpc *pEventdataTemp[6] = {NULL};
    CUeventInfo *pEventInfoTemp[6] = {NULL};
    CUSMCtrInfo *pSM = NULL;
    NvU32 j = 0, newEventGroups = 0, newGroupIds[6] = {0}, newGroupIdx[6] = {0}, numSignals = 0, busWidth[6] = {0};
    NvU32 totalSigWidth, sigWidth, maxSignalsAllowed = 0;

    pSM = pEventGroup->arch.maxwellEventGroup->pSM;
    maxSignalsAllowed = (signalTableType == PERF_SIG_TABLE_TYPE_LUT) ? 4 : 6;
    if(((pEventData->pmUnitId == PM_UNIT_SMCORE) || (pEventData->pmUnitId == PM_UNIT_MIO)) && (pSM->coreCount == CU_PROF_SM_CORE_PROFILED_MAX)) {
        return CUPROF_ERROR_NOT_COMPATIBLE;
    }
    else if((pEventData->pmUnitId == PM_UNIT_SMQCTL) && (pSM->qctlCount == CU_PROF_SM_QUAD_PROFILED_MAX)) {
        return CUPROF_ERROR_NOT_COMPATIBLE;
    }
    // Only one array of newGroupIdx is maintained here as the signals can be from any SINGLE unit.
    // Signals with different units cannot combine to form an LUT or multi-group increment signal.
    while(pEventData->signalId_combination[numSignals] != INVALID_PM_SIGNAL_NEW && numSignals < maxSignalsAllowed)
    {
        pEventInfoTemp[numSignals] = maxwellLookupDomainSignalTable(pDomainData, pEventData->signalId_combination[numSignals]);
        if(pEventInfoTemp[numSignals])
        {
            pEventdataTemp[numSignals] = (CUeventDataSmpc*)pEventInfoTemp[numSignals]->pEventData;
            CU_ASSERT(pEventdataTemp[numSignals]->pmUnitId == pEventData->pmUnitId);
            // Allow only single bit signal combinations for LUT:
            if(signalTableType == PERF_SIG_TABLE_TYPE_LUT) {
                CU_ASSERT(pEventdataTemp[numSignals]->busWidth == 1);
            }
            busWidth[numSignals] = pEventdataTemp[numSignals]->busWidth;
            switch(pEventData->pmUnitId)
            {
            case PM_UNIT_SMCORE:
            case PM_UNIT_MIO:
                {
                    NvU32 coreIdx = 0;
                    while(coreIdx < pSM->numGroupsCore)
                    {
                        if(pEventdataTemp[numSignals]->eventGroup == pSM->groupsCore[coreIdx])
                        {
                            newGroupIdx[numSignals] = coreIdx;
                            break;
                        }
                        coreIdx++;
                    }
                    if(coreIdx == pSM->numGroupsCore)
                    {
                        for(j = 0; j < newEventGroups; j++) {
                            if(pEventdataTemp[numSignals]->eventGroup == newGroupIds[j])
                            {
                                newGroupIdx[numSignals] = pSM->numGroupsCore + j;
                                break;
                            }
                        }
                        if(j == newEventGroups) {
                            newGroupIds[newEventGroups] = pEventdataTemp[numSignals]->eventGroup;
                            newGroupIdx[numSignals] = newEventGroups + pSM->numGroupsCore;
                            newEventGroups++;
                        }
                    }
                }
                break;
            case PM_UNIT_SMQCTL:
                {
                    NvU32 quadIdx = 0;
                    while(quadIdx < pSM->numGroupsQuad)
                    {
                        if(pEventdataTemp[numSignals]->eventGroup == pSM->groupsQuad[quadIdx])
                        {
                            newGroupIdx[numSignals] = quadIdx;
                            break;
                        }
                        quadIdx++;
                    }
                    if(quadIdx == pSM->numGroupsQuad)
                    {
                        for(j = 0; j < newEventGroups; j++) {
                            if(pEventdataTemp[numSignals]->eventGroup == newGroupIds[j])
                            {
                                newGroupIdx[numSignals] = pSM->numGroupsQuad + j;
                                break;
                            }
                        }
                        if(j == newEventGroups) {
                            newGroupIds[newEventGroups] = pEventdataTemp[numSignals]->eventGroup;
                            newGroupIdx[numSignals] = newEventGroups + pSM->numGroupsQuad;
                            newEventGroups++;
                        }
                    }
                }
                break;
            }
        }
        else
        {
            status = CUPROF_ERROR_INVALID_EVENT_ID;
            goto EXIT;
        }
        numSignals++;
    }
    if ((pEventData->pmUnitId == PM_UNIT_SMCORE) || (pEventData->pmUnitId == PM_UNIT_MIO)) {
        if((pSM->numGroupsCore + newEventGroups) > CU_PROF_SM_CORE_PROFILED_MAX) {
            status = CUPROF_ERROR_NOT_COMPATIBLE;
            goto EXIT;
        }
        for(j = 0; j < newEventGroups; j++)
        {
            pSM->groupsCore[pSM->numGroupsCore++] = newGroupIds[j];
        }
        pSM->coreCount++;
    }
    else {
        if((pSM->numGroupsQuad + newEventGroups) > CU_PROF_SM_QUAD_PROFILED_MAX) {
            status = CUPROF_ERROR_NOT_COMPATIBLE;
            goto EXIT;
        }
        for(j = 0; j < newEventGroups; j++)
        {
            pSM->groupsQuad[pSM->numGroupsQuad++] = newGroupIds[j];
        }
        pSM->qctlCount++;
    }
    // Add the function directly from the signal table for LUT signals:
    if (signalTableType == PERF_SIG_TABLE_TYPE_LUT)
        pSM->function[pSM->SMCountersAdded] = pEventData->function;
    else {
        // Compute the function for multi-group increment signals:
        NvU32 func = 0;
        totalSigWidth = 0;
        for (j = 0; j < numSignals; j++)
        {
            sigWidth = 0;
            while (sigWidth < busWidth[j]) {
                func |= 0x1 << (totalSigWidth + sigWidth);
                sigWidth++;
            }
            totalSigWidth += busWidth[j];
        }
        pSM->function[pSM->SMCountersAdded] = func;
    }
    pSM->pmUnitId[pSM->SMCountersAdded] = pEventData->pmUnitId;
    // Assign the mode based on the signal table type:
    pSM->mode[pSM->SMCountersAdded] = (signalTableType == PERF_SIG_TABLE_TYPE_LUT) ? NV_SM_DSM_PERF_COUNTER_CONTROL_MODE_LUT : NV_SM_DSM_PERF_COUNTER_CONTROL_MODE_COUNT;
    j = 0;
    totalSigWidth = 0;
    while(j < numSignals)
    {
        // sigWidth is specifically for multi-group increment signals as in LUT mode, only single bit signals are allowed in the combination.
        sigWidth = 0;
        while(sigWidth < busWidth[j]) {
            pSM->perfEventInfo[pSM->SMCountersAdded] |= ((newGroupIdx[j] & 3) | ((pEventdataTemp[j]->perfEvent & (0x00000007 << (4 * sigWidth))) >> (4 * sigWidth)) << 2)
                                                         << (5 * (totalSigWidth + sigWidth));
            sigWidth++;
        }
        totalSigWidth += busWidth[j];
        j++;
    }

EXIT:
    for(j = 0; j < numSignals; j++) {
        free(pEventInfoTemp[j]);
    }
    return status;
}

static CUprofResult maxwellPerfmonTryAddingCounterNew(CUeventGroup *pEventGroup, CUdomainData *pDomainData,  CUeventInfo *pEventInfo, NvBool *added, NvU32 *maxSignals)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUSMCtrInfo  *pSM = NULL;

    CU_TRACE_FUNCTION();

    *added = NV_FALSE;
    switch(pDomainData->eventCollectionMethod)
    {
    case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
    case CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX:
        //Try adding PM signal.
        *maxSignals = CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS + CU_PROF_ELAPSED_CLOCK_SLOT;
        if (pEventInfo && pEventInfo->pEventData) {
            status = canSigBeProfiledModeB(pEventGroup, pDomainData, pEventInfo, added);
        }
        if((*added == NV_TRUE) && (!pEventGroup->totalCounters))
        {
            //Store the chiplet type
            pEventGroup->arch.maxwellEventGroup->chipletType = pDomainData->chipletType;
            pEventGroup->arch.maxwellEventGroup->clkIdx = getClkIdx(pEventGroup->pCtx, pDomainData->domainId, pDomainData->chipletType);
        }
        break;

    case CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
        //Try adding SM counter.
        {
            pSM = pEventGroup->arch.maxwellEventGroup->pSM;
            if ((pEventInfo->signalTableType == PERF_SIG_TABLE_TYPE_LUT) || (pEventInfo->signalTableType == PERF_SIG_TABLE_TYPE_MULTI_GROUP))
            {
                status = tryAddingMultiGroupOrLutCounter(pEventGroup, pDomainData, (CUeventDataSmpcExpt*)pEventInfo->pEventData, pEventInfo->signalTableType);
                if (status != CUPROF_SUCCESS) {
                    CU_ERROR_PRINT(("Failed to add new counter\n"));
                    return status;
                }
            }
            else if (pEventInfo->signalTableType == PERF_SIG_TABLE_TYPE_SMPC)
            {
                status = tryAddingSmpcCounter(pEventGroup, pDomainData, (CUeventDataSmpc*)pEventInfo->pEventData);
                if (status != CUPROF_SUCCESS) {
                    CU_ERROR_PRINT(("Failed to add new counter\n"));
                    return status;
                }
            }
            *maxSignals = (CU_PROF_SM_CORE_PROFILED_MAX + CU_PROF_SM_QUAD_PROFILED_MAX);
            if(pSM->SMCountersAdded < *maxSignals) {
                *added = NV_TRUE;
                pSM->sigtableInfo[pSM->SMCountersAdded] = pEventInfo;
                if(0 == pEventGroup->totalCounters) {
                    pEventGroup->arch.maxwellEventGroup->chipletType = pDomainData->chipletType;
                }
            }
            else {
                return CUPROF_ERROR_MAX_LIMIT_REACHED;
            }
            pSM->SMCountersAdded++;
        }
        break;
    case CUPROF_EVENT_COLLECTION_METHOD_SW:
        *maxSignals = CU_PROF_SW_COUNTERS_MAX;
        *added = NV_TRUE;
        break;
    default:
        break;
    }
    return status;
}

/*****************************************************************
Variables used in the function:
- signalParts: Number of parts into which the signal is divided
- signalWidth: Original width of the signal
- splitWidth : Width of each splitted part of the signal
******************************************************************/
CUprofResult maxwellPerfmonAddSplitSignalsSM(CUeventGroup *pEventGroup, CUdomainData *pDomainData, CUeventInfo *pEventInfo, NvBool *bAdded, NvU32 *maxSignals, NvU32 splitWidth)
{
    NvU32 signalParts = 0, startBit, endBit;
    NvU32 func, i, signalWidth, maxSignalsSM = 0;
    CUprofResult status = CUPROF_SUCCESS;
    CUSMCtrInfo  *pSM = NULL;
    CUeventDataSmpc *pEventData = NULL;

    pSM = pEventGroup->arch.maxwellEventGroup->pSM;
    pEventData = (CUeventDataSmpc*)pEventInfo->pEventData;
    signalWidth = pEventData->busWidth;

    // Case handled for any signal of odd width
    signalParts = (signalWidth + (splitWidth - 1))/splitWidth;
    maxSignalsSM = (CU_PROF_SM_CORE_PROFILED_MAX + CU_PROF_SM_QUAD_PROFILED_MAX);

    if(pSM->SMCountersAdded < maxSignalsSM) {
        switch(pEventData->pmUnitId)
        {
        case PM_UNIT_SMCORE:
        case PM_UNIT_MIO:
            if (pSM->coreCount + signalParts > CU_PROF_SM_CORE_PROFILED_MAX) {
                return CUPROF_ERROR_NOT_COMPATIBLE;
            }
            break;
        case PM_UNIT_SMQCTL:
            if (pSM->qctlCount + signalParts > CU_PROF_SM_QUAD_PROFILED_MAX) {
                return CUPROF_ERROR_NOT_COMPATIBLE;
            }
            break;
        }
        func = pEventData->function;
        for(i = 0; i < signalParts; i++) {
            CUeventInfo *pEventInfoTemp = NULL;
            CUeventDataSmpc *pEventDataTemp = NULL;
            pEventInfoTemp = (CUeventInfo *) malloc (sizeof(CUeventInfo));
            if(pEventInfoTemp == NULL) {
                return CUPROF_ERROR_OUT_OF_MEMORY;
            }
            pEventDataTemp = (CUeventDataSmpc *) malloc (sizeof(CUeventDataSmpc));
            if(pEventDataTemp == NULL) {
                free(pEventInfoTemp);
                return CUPROF_ERROR_OUT_OF_MEMORY;
            }
            memcpy(pEventDataTemp, pEventData, sizeof(CUeventDataSmpc));
            pEventInfoTemp->signalTableType = pEventInfo->signalTableType;
            pEventInfoTemp->pEventData = (void*)pEventDataTemp;
            pEventDataTemp->perfEvent = 0;
            startBit = i * 4 * splitWidth;
            splitWidth = (signalWidth<splitWidth)?signalWidth:splitWidth;
            endBit = startBit + (splitWidth * 4) -1 ;
            pEventDataTemp->perfEvent = GETFIELD32(pEventData->perfEvent, endBit:startBit);
            pEventDataTemp->function = GETFIELD32(func,(splitWidth - 1):0);
            status = maxwellPerfmonTryAddingCounterNew(pEventGroup,
                pDomainData,
                pEventInfoTemp,
                bAdded,
                maxSignals);
            if ((status != CUPROF_SUCCESS) || (*bAdded == NV_FALSE)) {
                CU_ERROR_PRINT(("Failed to add new counter\n"));
                return status;
            }
            CU_ASSERT(*bAdded);
            func = func >> splitWidth;
            signalWidth -= splitWidth;
        }
        pSM->splitParts[pEventGroup->totalCounters] = signalParts;
    }
    else {
        status = CUPROF_ERROR_MAX_LIMIT_REACHED;
        *bAdded = NV_FALSE;
        CU_ERROR_PRINT(("Failed to add new counter\n"));
    }
    return status;
}

#define SMCORE_UPPER_EVENT_GROUP 28
#define SMCORE_LOWER_EVENT_GROUP 29
#define MIO_UPPER_EVENT_GROUP 30
#define MIO_LOWER_EVENT_GROUP 31
#define QUAD_UPPER_EVENT_GROUP 30
#define QUAD_LOWER_EVENT_GROUP 31
#define SMPC_GROUP_WIDTH 16

static CUprofResult maxwellPerfmonAddSMCounterEntryForHWPMMux(CUeventGroup *pEventGroup, CUdomainData *pDomainData, CUeventInfo *pEventInfo, NvBool *bAdded, NvU32 *maxSignals)
{
    NvU32 i = 0;
    CUprofResult status = CUPROF_SUCCESS;
    CUSMCtrInfo  *pSM = NULL;
    CUeventDataHwpmMux *pEventData = NULL;
    CUeventInfo *pEventInfoTemp = NULL;
    CUeventDataSmpc *pEventDataTemp = NULL;
    uint32_t upperEventGroup = 0, lowerEventGroup = 0;

    pSM = pEventGroup->arch.maxwellEventGroup->pSM;
    pEventData = (CUeventDataHwpmMux*)pEventInfo->pEventData;

   *maxSignals = (CU_PROF_SM_CORE_PROFILED_MAX + CU_PROF_SM_QUAD_PROFILED_MAX);

    if(pSM->SMCountersAdded < *maxSignals) {
        switch(pEventData->pmUnitId)
        {
        case PM_UNIT_SMCORE:
        case PM_UNIT_MIO:
            if(pSM->numGroupsCore == CU_PROF_SM_CORE_PROFILED_MAX) {
                return CUPROF_ERROR_NOT_COMPATIBLE;
            }
            break;
        case PM_UNIT_SMQCTL:
            if (pSM->qctlCount == CU_PROF_SM_QUAD_PROFILED_MAX) {
                return CUPROF_ERROR_NOT_COMPATIBLE;
            }
            break;
        }
        pEventInfoTemp = (CUeventInfo *) malloc (sizeof(CUeventInfo));
        if(pEventInfoTemp == NULL) {
            return CUPROF_ERROR_OUT_OF_MEMORY;
        }
        pEventDataTemp = (CUeventDataSmpc *) malloc (sizeof(CUeventDataSmpc));
        if(pEventDataTemp == NULL) {
            free(pEventInfoTemp);
            return CUPROF_ERROR_OUT_OF_MEMORY;
        }

        pEventInfoTemp->signalTableType = PERF_SIG_TABLE_TYPE_SMPC;
        pEventInfoTemp->pEventData = (void*)pEventDataTemp;
        pEventDataTemp->signalId = pEventData->signalId;
        pEventDataTemp->pSignalName = pEventData->pSignalName;
        pEventDataTemp->eventGroup = pEventData->eventGroup;
        pEventDataTemp->pmUnitId = pEventData->pmUnitId;
        pEventDataTemp->busWidth = pEventData->busWidth;
        //Need to get perfevent in pm_programming guide, else difficult to add in the SM events
        //Configure for increment, for HWPM experiments have to consider width of increment signal
        pEventDataTemp->function =  (1<<pEventData->busWidth) - 1;

        switch(pEventData->pmUnitId)
        {
        case PM_UNIT_SMCORE:
            upperEventGroup = SMCORE_UPPER_EVENT_GROUP;
            lowerEventGroup = SMCORE_LOWER_EVENT_GROUP;
            break;
        case PM_UNIT_MIO:
            upperEventGroup = MIO_UPPER_EVENT_GROUP;
            lowerEventGroup = MIO_LOWER_EVENT_GROUP;
            break;
        case PM_UNIT_SMQCTL:
            upperEventGroup = QUAD_UPPER_EVENT_GROUP;
            lowerEventGroup = QUAD_LOWER_EVENT_GROUP;
            break;
        }
        if (pEventData->startPos < (SMPC_GROUP_WIDTH>>1) ) {
            CU_ASSERT((pEventData->startPos + pEventData->busWidth) <= (SMPC_GROUP_WIDTH>>1));
            pEventDataTemp->eventGroup = upperEventGroup;
        }
        else
            pEventDataTemp->eventGroup = lowerEventGroup;

        //TBD perfevent should be derived from width and startpos of signals in SMPC
        pEventDataTemp->perfEvent = 0;
        for(i=0; i<pEventDataTemp->busWidth; i++) {
            pEventDataTemp->perfEvent |= (pEventData->startPos + i) << (i*4);
        }

        //Try adding SM counter.
        {
            pSM = pEventGroup->arch.maxwellEventGroup->pSM;
            //The SM counter setting will always be increment.
            status = tryAddingSmpcCounter(pEventGroup, pDomainData, pEventDataTemp);
            if (status != CUPROF_SUCCESS) {
                CU_ERROR_PRINT(("Failed to add new counter\n"));
                goto EXIT;
            }

            if(pSM->SMCountersAdded < *maxSignals) {
                pSM->splitParts[pSM->SMCountersAdded] = 1;
                pSM->sigtableInfo[pSM->SMCountersAdded] = pEventInfoTemp;
                if(0 == pEventGroup->totalCounters) {
                    pEventGroup->arch.maxwellEventGroup->chipletType = pDomainData->chipletType;
                }
            }
            else {
                status = CUPROF_ERROR_MAX_LIMIT_REACHED;
                goto EXIT;
            }
            *bAdded = NV_TRUE;
            pSM->SMCountersAdded++;
        }

        CU_ASSERT(*bAdded);
    }
    else {
        status = CUPROF_ERROR_MAX_LIMIT_REACHED;
        *bAdded = NV_FALSE;
        CU_ERROR_PRINT(("Failed to add new counter\n"));
    }
    return status;
EXIT:
    if (pEventInfoTemp) free (pEventInfoTemp);
    if (pEventDataTemp) free (pEventDataTemp);
    return status;
}
// maxwellCreateSignalTableEntry creates a new signal table entry
// and associates a nop trigger with each s/w counter requested
// In the new table entry the function copies the requested signal ID and name
// and copies the remaining CUeventData structure entries from the associated nop trigger signal table
static CUprofResult maxwellCreateSignalTableEntry(CUeventGroup *pEventGroup, CUeventInfo **pEventInfoData, NvU32 eventID)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 i, nopTrigEventID;
    CUdev *pDev = NULL;
    NvU32 numDomains = 0;
    CUdomainData *nopTrigDomainData = NULL;
    CUeventDataSmpc *nopTrigEventData = NULL;
    CUeventInfo *nopTrigEventInfoData = NULL;
    CUeventDataSmpc *tempEventData = NULL;

    if(pEventGroup->nopTrigSwCounterData == NULL) {
        return CUPROF_ERROR_UNKNOWN;
    }

    tempEventData = (CUeventDataSmpc *)calloc(1, sizeof(CUeventDataSmpc));
    if(!tempEventData) {
        CU_ERROR_PRINT(("Failed to allocate memory for CUeventDataSmpc\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        return status;
    }

    if(pEventGroup->nopTrigSwCounterData->numSwCountersRequested == MAXWELL_MAX_SW_COUNTER_PER_EVENTGROUP) {
        CU_DEBUG_PRINT(("Eventgroup limit reached\n"));
        // Only 4 nop_triggers can be issued on Maxwell. Return from here
        free(tempEventData);
        return CUPROF_ERROR_NOT_COMPATIBLE;
    }

    for(i = 0; ; i++){
        if((eventID == pEventGroup->nopTrigSwCounterData->signalID[i]) || (i == pEventGroup->nopTrigSwCounterData->numSwCountersRequested)) {
            break;
        }
    }

    // If the signal is not requested earlier then associate an internal NOP.TRIG with it.
    if(i == pEventGroup->nopTrigSwCounterData->numSwCountersRequested) {
        nopTrigEventID = MAXWELL_SM_PMTRIG8 + pEventGroup->nopTrigSwCounterData->numSwCountersRequested;
        pEventGroup->nopTrigSwCounterData->signalID[pEventGroup->nopTrigSwCounterData->numSwCountersRequested] = eventID;
        (pEventGroup->nopTrigSwCounterData->numSwCountersRequested)++;
    }
    else {
        // Else consider the previous associated NOP.TRIG
        nopTrigEventID = MAXWELL_SM_PMTRIG8 + i;
    }

    pDev = pEventGroup->pCtx->device;
    numDomains = pDev->state.pDomainInfo->numDomains;

    for (i = 0; (i < numDomains && nopTrigEventInfoData == NULL); i++) {
        nopTrigDomainData = &pDev->state.pDomainInfo->pDomainTable[i];
        nopTrigEventInfoData = maxwellLookupDomainSignalTable(nopTrigDomainData, nopTrigEventID);
        if(nopTrigEventInfoData) {
            nopTrigEventData = (CUeventDataSmpc*)nopTrigEventInfoData->pEventData;
            if(nopTrigEventData == NULL) {
                free(tempEventData);
                free(nopTrigEventInfoData);
                return CUPROF_ERROR_UNKNOWN;
            }
        }
    }

    if(nopTrigEventInfoData == NULL) {
        // This means that there is an error in higher level due to which maxwellLookupDomainSignalTable did not find any valid signalID
        free(tempEventData);
        return CUPROF_ERROR_UNKNOWN;
    }

    tempEventData->signalId = ((CUeventData*)((*pEventInfoData)->pEventData))->signalId;
    tempEventData->pSignalName = ((CUeventData*)((*pEventInfoData)->pEventData))->pSignalName;
    tempEventData->eventGroup = nopTrigEventData->eventGroup;
    tempEventData->perfEvent = nopTrigEventData->perfEvent;
    tempEventData->function = nopTrigEventData->function;
    tempEventData->pmUnitId = nopTrigEventData->pmUnitId;
    tempEventData->busWidth = nopTrigEventData->busWidth;

    (*pEventInfoData)->pEventData = (void*)tempEventData;
    (*pEventInfoData)->signalTableType = nopTrigEventInfoData->signalTableType;

    //Store SMPC domainid
    pEventGroup->nopTrigSwCounterData->nopTrigDomainId = nopTrigDomainData->domainId;

    free(nopTrigEventInfoData);

    return status;
}

CUprofResult maxwellPerfmonEventGroupAddEvent(CUeventGroup *pEventGroup,
                                              NvU32 eventID)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUdomainData *pDomainData = NULL;
    void *pEventData = NULL;
    CUeventInfo *tempEventInfo = NULL;
    CUdev *pDev = NULL;
    NvBool bAdded = NV_FALSE;
    NvU32 numDomains = 0;
    NvU32 i = 0, maxSignals = 0, splitWidth = 0;
    CUSMCtrInfo  *pSM = NULL;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);
    if (pEventGroup->isEnabled) {
        // don't allow addition of events for enabled event group
        return CUPROF_ERROR_INVALID_OPERATION;
    }

    pDev = pEventGroup->pCtx->device;

    if(!pDev->state.pDomainInfo)
        return CUPROF_ERROR_UNKNOWN;

    numDomains = pDev->state.pDomainInfo->numDomains;

    if (pEventGroup->totalCounters == 0) {
        // first signal, search in all domains
        for (i = 0; i < numDomains; i++) {
            pDomainData = &pDev->state.pDomainInfo->pDomainTable[i];
            tempEventInfo = maxwellLookupDomainSignalTable(pDomainData, eventID);
            if (tempEventInfo) {
                pEventData = tempEventInfo->pEventData;
                if (!pEventData) {
                    free(tempEventInfo);
                    return CUPROF_ERROR_UNKNOWN;
                }
                break;
            }
        }
        // If lookup succeeds then initialize event group
        if (tempEventInfo != NULL) {
            status = maxwellInitEventGroup(pEventGroup);
            if(CUPROF_SUCCESS != status) {
                CU_DEBUG_PRINT(("maxwellInitEventGroup Failed\n"));
                free(tempEventInfo);
                return status;
            }
        }
        else {
            return CUPROF_ERROR_INVALID_EVENT_ID;
        }
    }
    else {
        tempEventInfo = maxwellLookupDomainSignalTable(pEventGroup->domain, eventID);
        if (tempEventInfo) {
            pEventData = tempEventInfo->pEventData;
            if (!pEventData) {
                free(tempEventInfo);
                return CUPROF_ERROR_UNKNOWN;
            }
            pDomainData = pEventGroup->domain;
        }
        else {
            for (i = 0; i < numDomains; i++) {
                pDomainData = &pDev->state.pDomainInfo->pDomainTable[i];
                tempEventInfo = maxwellLookupDomainSignalTable(pDomainData, eventID);
                if (tempEventInfo) {
                    free(tempEventInfo);
                    return CUPROF_ERROR_NOT_COMPATIBLE;
                }
            }

            return CUPROF_ERROR_INVALID_EVENT_ID;
        }
    }

    if(pDomainData->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW) {
        if(pEventGroup->nopTrigSwCounterData == NULL){
            pEventGroup->nopTrigSwCounterData = (CUnopTrigSwCounter *)calloc(1, sizeof(CUnopTrigSwCounter));
            if (pEventGroup->nopTrigSwCounterData == NULL) {
                CU_DEBUG_PRINT(("Failed to allocate memory to event group\n"));
                free(tempEventInfo);
                return CUPROF_ERROR_OUT_OF_MEMORY;
            }
        }
        if(pEventGroup->totalCounters == 0) {
            memset(pEventGroup->nopTrigSwCounterData, 0, sizeof(CUnopTrigSwCounter));
        }
        status = maxwellCreateSignalTableEntry(pEventGroup, &tempEventInfo, eventID);
        if (status != CUPROF_SUCCESS) {
            if(status != CUPROF_ERROR_NOT_COMPATIBLE) {
                CU_ERROR_PRINT(("Failed to create signal table entry\n"));
            }
            free(tempEventInfo);
            return status;
        }
        pEventData = tempEventInfo->pEventData;
        if (pEventData == NULL) {
            free(pEventData);
            free(tempEventInfo);
            return CUPROF_ERROR_INVALID_EVENT_ID;
        }
    }

    // return if event is not found or it's a internal only event
    if (pEventData == NULL) {
        free(tempEventInfo);
        return CUPROF_ERROR_INVALID_EVENT_ID;
    }
    else if ((SIG_TYPE_IS_INTERNAL_EXPOSED(((CUeventDataBasic*)pEventData)->signalId)
             && (pDomainData->exposedEvents == pDomainData->maxExternalEvents)) || SIG_TYPE_IS_INTERNAL(((CUeventDataBasic*)pEventData)->signalId)) {
        free(tempEventInfo);
        return CUPROF_ERROR_INVALID_EVENT_ID;
    }
    switch(pDomainData->eventCollectionMethod) {
        case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
        case CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX:
        case CUPROF_EVENT_COLLECTION_METHOD_SW:
            status = maxwellPerfmonTryAddingCounterNew(pEventGroup,
                pDomainData,
                tempEventInfo,
                &bAdded,
                &maxSignals);
            break;
        case CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW:
        case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
            pSM = pEventGroup->arch.maxwellEventGroup->pSM;
            if(getSplittingInfo(((CUeventDataSmpc*)pEventData)->signalId, &splitWidth)) {
                status = maxwellPerfmonAddSplitSignalsSM(pEventGroup, pDomainData, tempEventInfo, &bAdded, &maxSignals, splitWidth);
            }
            else {
                status = maxwellPerfmonTryAddingCounterNew(pEventGroup,
                    pDomainData,
                    tempEventInfo,
                    &bAdded,
                    &maxSignals);
                if(status == CUPROF_SUCCESS) {
                    pSM->splitParts[pEventGroup->totalCounters] = 1;
                }
            }
            break;
        default:
            CU_DEBUG_PRINT(("Invalid domain attribute\n"));
            free(tempEventInfo);
            return CUPROF_ERROR_INVALID_EVENT_DOMAIN_ID;
    }
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("Failed to add new counter\n"));
        free(tempEventInfo);
        return status;
    }
    CU_ASSERT(bAdded);

    if (pEventGroup->totalCounters == 0) {
        pEventGroup->domainId = pDomainData->domainId;
        pEventGroup->domain   = pDomainData;

        maxwellPerfmonGetInstanceValues(pDev, pEventGroup->domain,
            &pEventGroup->instanceCountAvail, &pEventGroup->instanceCountTotal);

        if(pEventGroup->values != NULL)
        {
            free(pEventGroup->values);
            pEventGroup->values = NULL;
        }

        if(pEventGroup->values == NULL) {
            pEventGroup->values = (NvU64*)malloc(sizeof(NvU64) * maxSignals * pEventGroup->instanceCountAvail);
            if (pEventGroup->values == NULL) {
                CU_DEBUG_PRINT(("Failed to allocate memory to event group values\n"));
                free(tempEventInfo);
                return CUPROF_ERROR_OUT_OF_MEMORY;
            }
        }
        cuosMemset(pEventGroup->values, 0, sizeof(NvU64) * maxSignals * pEventGroup->instanceCountAvail);
    }

    if (pEventGroup->pEventInfoList == NULL) {
        // event list hasn't been init yet, do it now
        status = (CUprofResult)listInit(&pEventGroup->pEventInfoList, NULL, NULL, NULL, eventIdCompareData);
        if (status != CUPROF_SUCCESS) {
            free(tempEventInfo);
            CU_ERROR_PRINT(("Failed to init linked list\n"));
            return status;
        }
    }
    // add event to the list
    listAddToTail(pEventGroup->pEventInfoList, tempEventInfo);
    pEventGroup->totalCounters++;
    return status;
}

CUprofResult maxwellPerfmonEventGroupRemoveEvent(CUeventGroup *pEventGroup, NvU32 eventID) {
    CUprofResult status = CUPROF_SUCCESS;
    CUeventInfo *currEvent = NULL;
    void *eventBase = NULL;
    NvBool bAdded = NV_FALSE;
    void *data = NULL;
    NvU32 i = 0, remainingCounters = 0, maxsignals = 0, splitWidth;
    CUdomainData *pDomainData = NULL;
    CUSMCtrInfo  *pSM = NULL;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if (pEventGroup->totalCounters == 0) {
        return CUPROF_SUCCESS;
    }

    if (pEventGroup->isEnabled) {
        // don't allow removal of events for enabled event group
        return CUPROF_ERROR_INVALID_OPERATION;
    }

    // remove from list
    data = listDataRemFrom(pEventGroup->pEventInfoList, &eventID);
    if (data != NULL) {
        //Do memory cleanup as eventInfoData is a pointer to structure storing the event data and signal type info
        free(data);
        remainingCounters = pEventGroup->totalCounters - 1;

        //Destroy the earlier parsed info and recreate the structure.
        status = maxwellDestroyEventGroup(pEventGroup);
        pEventGroup->totalCounters = 0;

        if(remainingCounters)
        {
            status = maxwellInitEventGroup(pEventGroup);
            if(status != CUPROF_SUCCESS)
                return status;
            pDomainData = pEventGroup->domain;
            //Add remaining counters back to build the parsed info
            currEvent = (CUeventInfo*)listGetNext(pEventGroup->pEventInfoList, &eventBase);
            for (i = 0; (i < remainingCounters) && currEvent; i++, currEvent = (CUeventInfo*)listGetNext(NULL, &eventBase)) {
                switch(pDomainData->eventCollectionMethod) {
                    case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
                    case CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX:
                    case CUPROF_EVENT_COLLECTION_METHOD_SW:
                        status = maxwellPerfmonTryAddingCounterNew(pEventGroup,
                            pEventGroup->domain,
                            currEvent,
                            &bAdded, &maxsignals);
                        break;
                    case CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW:
                    case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
                        pSM = pEventGroup->arch.maxwellEventGroup->pSM;
                        if(getSplittingInfo(((CUeventDataSmpc *)currEvent->pEventData)->signalId, &splitWidth)) {
                            status = maxwellPerfmonAddSplitSignalsSM(pEventGroup, pDomainData, currEvent, &bAdded, &maxsignals, splitWidth);
                        }
                        else {
                            status = maxwellPerfmonTryAddingCounterNew(pEventGroup,
                                pDomainData,
                                currEvent,
                                &bAdded,
                                &maxsignals);
                            if(status == CUPROF_SUCCESS) {
                                pSM->splitParts[pEventGroup->totalCounters] = 1;
                            }
                        }
                        break;
                    default:
                        CU_DEBUG_PRINT(("Invalid domain attribute\n"));
                        return CUPROF_ERROR_INVALID_EVENT_DOMAIN_ID;
                }
                if ((status != CUPROF_SUCCESS) || (bAdded == NV_FALSE)) {
                    CU_ERROR_PRINT(("Failed to add new counter\n"));
                    return status;
                }
                CU_ASSERT(bAdded);
                pEventGroup->totalCounters++;
            }
        }
        else {
            //Destroy the event list if the removed event was the last one.
            //TBD check if Tesla needs this.
            status = (CUprofResult)listDestroy(pEventGroup->pEventInfoList);
            if (status != CUPROF_SUCCESS) {
                return status;
            }
            pEventGroup->pEventInfoList = NULL;
        }
    }
    else {
        return CUPROF_ERROR_INVALID_EVENT_ID;
    }

    return status;
}

CUprofResult maxwellPerfmonEventGroupRemoveAllEvents(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 i = 0;
    void *data = NULL;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if (pEventGroup->totalCounters == 0) {
        //No event is added
        return CUPROF_SUCCESS;
    }

    if (pEventGroup->isEnabled) {
        // don't allow removal of events for enabled event group
        return CUPROF_ERROR_INVALID_OPERATION;
    }

    for (i = 0; i < pEventGroup->totalCounters; i++) {
        status = (CUprofResult)listGenericRemNodeFromHead(pEventGroup->pEventInfoList, &data);
        if (status == CUPROF_SUCCESS) {
            free(data);
        }
        else {
            return CUPROF_ERROR_UNKNOWN;
        }
    }
    CU_ASSERT(listLen(pEventGroup->pEventInfoList) == 0);
    // destroy the event list
    status = (CUprofResult)listDestroy(pEventGroup->pEventInfoList);
    if (status != CUPROF_SUCCESS) {
        return status;
    }
    pEventGroup->pEventInfoList = NULL;

    status = maxwellDestroyEventGroup(pEventGroup);

    pEventGroup->totalCounters = 0;
    return status;
}

// function to enable PM module for units
static CUprofResult setPMEnableReg(const CUeventGroup *pEventGroup, NvBool bEnable)
{
    //Function to be changed for new version
    CUresult status = CUDA_SUCCESS;
    NvU32 offset[10] = {0}, value[10] = {0};
    NvU32 count = 0, i = 0;
    NvU32 chipIdx = 0;
    PMEnableRegInfo *pPMEnableRegInfo = NULL;
    CUmaxwellEventGroup *maxwellEventGroup;
    CUparsedClk *pParsedClk = NULL;
#if 0
    NvU32 smValue = 0, smMask = 0;
#endif
    PerfUnitTable   *pTempPerfUnitTable = NULL;

    CU_TRACE_FUNCTION();

    pParsedClk = pEventGroup->arch.maxwellEventGroup->pParsedClk;

    CU_ASSERT(pParsedClk);

    maxwellEventGroup = pEventGroup->arch.maxwellEventGroup;

    for (chipIdx = 0; chipIdx < maxwellEventGroup->maxChiplets; chipIdx++) {
        if(maxwellEventGroup->pmUnitMask & (1<<chipIdx)) {
            pParsedClk = maxwellEventGroup->pParsedClk;
            i = 0;
            while(pParsedClk && pParsedClk->pParsedUnit[i]) {
                pTempPerfUnitTable = pParsedClk->pParsedUnit[i]->pPerfUnitTable;
                pPMEnableRegInfo = &pTempPerfUnitTable->pmEnableRegInfo;

                count = 0;
                switch (maxwellEventGroup->chipletType) {
                    // Bug 646910 : only one instance can be selected at a time
                    // The selected instance gets the "value" field value assigned while all others instances are zeroed out
                    // TODO: this change is not complete though, refer pm_programming_guide.txt file to derive
                    // the instance type (like INVALID, NONE, TPC, WXBAR_CQ_DAISY, MXBAR_CQ_DAISY etc) and no. of instances

                    case PM_CHIPLET_TYPE_GPC:
                        // count total tpcs within the gpc
                        //TBD remove hack (assumed chipidx pointing to a gpc here. This will not be required if we had 1 perfmon/tpc)
                        //TBD Check how many texture units we have in maxwell and if we need to change this code.
                        if((pParsedClk->pParsedUnit[i]->unitId == PM_UNIT_TEX_S) || pParsedClk->pParsedUnit[i]->unitId == PM_UNIT_TEX_T ||
                            pParsedClk->pParsedUnit[i]->unitId == PM_UNIT_TEX_T1 || pParsedClk->pParsedUnit[i]->unitId == PM_UNIT_TEX_T2 ||
                            pParsedClk->pParsedUnit[i]->unitId == PM_UNIT_TEX_T3 || pParsedClk->pParsedUnit[i]->unitId == PM_UNIT_TEX_D ||
                            pParsedClk->pParsedUnit[i]->unitId == PM_UNIT_TEX_M) {

                                count = 0;
                                //TBD check if NV_PTPC_PRI_TEX_T_PM_PM_ENABLE_ON is required to be set for tex unit
                                //If not remove the whole if condition here.
                                offset[count++] = maxwellEventGroup->priAddress[chipIdx] + pPMEnableRegInfo->regOffset;
                                offset[count++] = maxwellEventGroup->priAddress[chipIdx] + NV_PTPC_PRI_TEX_T_PM;
                                offset[count++] = NV_PRI_FE_PERFMON;

                                // read _PM registers
                                status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
                                if (status != CUDA_SUCCESS) {
                                    return CUPROF_ERROR_HARDWARE;
                                }
                                // set PM_ENABLE bit by ORing the read value for selected instance
                                // disable PM_ENABLE bit by ANDing the read value for all others instances
                                count = 0;
                                if(bEnable)
                                {
                                    value[count++] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                                    value[count]  = DRF_REPLACE(value[count], NV_PTPC_PRI_TEX_T_PM_PM_ENABLE_ON, NV_PTPC_PRI_TEX_T_PM_PM_ENABLE);
                                    count++;
                                    value[count]  = DRF_REPLACE(value[count], NV_PRI_FE_PERFMON_ENABLE_ENABLE, NV_PRI_FE_PERFMON_ENABLE);
                                    count++;
                                }
                                else
                                {
                                    value[count++] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
                                    value[count++] &= ~(DRF_MASK(NV_PTPC_PRI_TEX_T_PM_PM_ENABLE)<<(DRF_SHIFT(NV_PTPC_PRI_TEX_T_PM_PM_ENABLE)));
                                    value[count++] &= ~(DRF_MASK(NV_PRI_FE_PERFMON_ENABLE)<<(DRF_SHIFT(NV_PRI_FE_PERFMON_ENABLE)));
                                }

                        } else if (pParsedClk->pParsedUnit[i]->unitId == PM_UNIT_MPC) {
                            count = 0;
                            //If not remove the whole if condition here.
                            offset[count++] = maxwellEventGroup->priAddress[chipIdx] + pPMEnableRegInfo->regOffset;
                            offset[count++] = NV_PRI_FE_PERFMON;

                            // read _PM registers
                            status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
                            if (status != CUDA_SUCCESS) {
                                return CUPROF_ERROR_HARDWARE;
                            }
                            // set PM_ENABLE bit by ORing the read value for selected instance
                            // disable PM_ENABLE bit by ANDing the read value for all others instances
                            count = 0;
                            if(bEnable)
                            {
                                value[count++] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                                value[count]  = DRF_REPLACE(value[count], NV_PRI_FE_PERFMON_ENABLE_ENABLE, NV_PRI_FE_PERFMON_ENABLE);
                                count++;
                            }
                            else
                            {
                                value[count++] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
                                value[count++] &= ~(DRF_MASK(NV_PRI_FE_PERFMON_ENABLE)<<(DRF_SHIFT(NV_PRI_FE_PERFMON_ENABLE)));
                            }
                        }
                        else {
                            count = 0;
                            offset[count++] = maxwellEventGroup->priAddress[chipIdx] + pPMEnableRegInfo->regOffset;
                            offset[count++] = NV_PRI_FE_PERFMON;
                            // read _PM registers
                            status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
                            if (status != CUDA_SUCCESS) {
                                return CUPROF_ERROR_HARDWARE;
                            }
                            count = 0;

#if 0
                            if (0
#if NVCFG(GLOBAL_ARCH_MAXWELL)
                                || ((pEventGroup->pCtx->device->state.chip == NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM000 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM107)
                                ||  (pEventGroup->pCtx->device->state.chip == NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM000 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM108)
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200
                                ||  (pEventGroup->pCtx->device->state.chip == NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200)
                                ||  (pEventGroup->pCtx->device->state.chip == NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM204)
                                ||  (pEventGroup->pCtx->device->state.chip == NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM206)
                                ||  (pEventGroup->pCtx->device->state.chip == NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM20B)
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM21B
                                ||  (pEventGroup->pCtx->device->state.chip == NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM21B)
#endif // NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM21B
#endif
                                )
#endif
                                )
                            {
                                //The following can be dynamically modified. hacking the code to test all modes.
                                switch(pTempPerfUnitTable->pmUnitId)
                                {
                                case PM_UNIT_SMCORE :
                                    //Enable core on upper watchbus
                                    //smValue = 0x0508080;
                                    smValue = 0x0408080;
                                    smMask  = 0x07f8080;
                                    value[0] |= (smValue & smMask);
                                    break;
                                case PM_UNIT_SMQCTL :
                                    //enable qctl0 on upper watchbus
                                    smValue = 0x0508080;
                                    smMask  = 0x07f0080;
                                    value[0] |= (smValue & smMask);
                                    //Enable only 1 QCTL on upper watchbus
                                    break;
                                case PM_UNIT_MIO:
                                    count = 2;
                                    //TBD: remove the hardcoded value used
                                    offset[1] = pEventGroup->arch.maxwellEventGroup->priAddress[chipIdx] + 0x00000600;
                                    status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, 1, &offset[1], &value[1], 0);
                                    if (status != CUDA_SUCCESS) {
                                        return CUPROF_ERROR_HARDWARE;
                                    }
                                    // set SMK_ENABLE and SMK_LOWER/UPPER
                                    value[1] = DRF_REPLACE(value[1], NV_SM_PM_CTRL_MIO_ENABLE_ENABLE,    NV_SM_PM_CTRL_MIO_ENABLE);
                                    smValue = value[1];
                                    smMask  = NV_SM_PM_CTRL_ENABLE_BITS_MASK;
                                    if(bEnable)
                                    {
                                        value[1] |= (smValue & smMask);
                                    }
                                    else
                                    {
                                        value[1] &= ~(smMask);
                                    }
                                    break;
                                default:
                                    CU_ERROR_PRINT(("Not a valid chiplet type.\n"));
                                }
                            }

#endif
                            // set PM_ENABLE bit by ORing the read value for selected instance
                            // disable PM_ENABLE bit by ANDing the read value for all others instances
                            if(bEnable)
                            {
                                value[count++] |= ((pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit) | 0x80);
                                value[count]  = DRF_REPLACE(value[count], NV_PRI_FE_PERFMON_ENABLE_ENABLE, NV_PRI_FE_PERFMON_ENABLE);
                                count++;
                            }
                            else
                            {
                                value[count++] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
                                value[count++] &= ~(DRF_MASK(NV_PRI_FE_PERFMON_ENABLE)<<(DRF_SHIFT(NV_PRI_FE_PERFMON_ENABLE)));
                            }
#if 0
                //Enable sampling for SM unit to profile the profiler_valid and profiler_first signals.
                offset[count] = pEventGroup->arch.maxwellEventGroup->priAddress[chipIdx] + NV_PTPC_PRI_SM_PM_SAMP_CTRL;
                value[count]  = DRF_REPLACE(value[count], NV_PTPC_PRI_SM_PM_SAMP_CTRL_ENABLE_ENABLE, NV_PTPC_PRI_SM_PM_SAMP_CTRL_ENABLE);
                //TBD change value for backpressure cases
                value[count]  = DRF_REPLACE(value[count], 5, NV_PTPC_PRI_SM_PM_SAMP_CTRL_TIMER);
                printf("\nVALUE:0x%x\n",value[count]);
                count++;
#endif
                            break;
                        }
                        break;
                    case PM_CHIPLET_TYPE_SYS:
                        count = 0;
                        offset[count++] = maxwellEventGroup->priAddress[chipIdx] + pPMEnableRegInfo->regOffset;
                        offset[count++] = NV_PRI_FE_PERFMON;

                        // read _PM registers
                        status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
                        if (status != CUDA_SUCCESS) {
                            return CUPROF_ERROR_HARDWARE;
                        }

                        count = 0;
                        // set PM_ENABLE bit by ORing the read value for selected instance
                        // disable PM_ENABLE bit by ANDing the read value for all others instances
                        if(bEnable) {
                            value[count++] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                            value[count]  = DRF_REPLACE(value[count], NV_PRI_FE_PERFMON_ENABLE_ENABLE, NV_PRI_FE_PERFMON_ENABLE);
                            count++;
                        }
                        else {
                            value[count++] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
                            value[count++] &= ~(DRF_MASK(NV_PRI_FE_PERFMON_ENABLE)<<(DRF_SHIFT(NV_PRI_FE_PERFMON_ENABLE)));
                        }
                        break;
                    case PM_CHIPLET_TYPE_FBP:
                        count = 0;
                        //TBD The changes done for GF108 can be removed as no chip in maxwell hs 2 FBPA per FBP
                        // everything but fbpa2pm_ltc_fb_perf_muxed_bus/NV_PFB_FBPA_*_PM is floorswept in virtual address space
                        if(pParsedClk->pParsedUnit[i]->unitId == PM_UNIT_FB) {
                            //Use broadcast register to enable PM for FBPA as unicast are giving wrong values
                            //Writing to boardcast register for each chiplet to avoid conditions, otherwise writing
                            //only once is sufficient
                                offset[count++] = NV_FBPA_PRI_BASE_BROADCAST + pPMEnableRegInfo->regOffset;
                                offset[count++] = NV_PRI_FE_PERFMON;
                            // read _PM registers
                            status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
                            if (status != CUDA_SUCCESS) {
                                return CUPROF_ERROR_HARDWARE;
                            }
                                count = 0;
                            // set PM_ENABLE bit by ORing the read value for selected instance
                            // disable PM_ENABLE bit by ANDing the read value for all others instances
                            if(bEnable)
                            {
                                    value[count++] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                                    value[count]  = DRF_REPLACE(value[count], NV_PRI_FE_PERFMON_ENABLE_ENABLE, NV_PRI_FE_PERFMON_ENABLE);
                                    count++;
                            }
                            else
                            {
                                    value[count++] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)
                                    <<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
                                    value[count++] &= ~(DRF_MASK(NV_PRI_FE_PERFMON_ENABLE)<<(DRF_SHIFT(NV_PRI_FE_PERFMON_ENABLE)));
                            }

                        }
                        else {
                            //For LTC units write into the selected unit directly
                            count = 0;
                            if (cuiDeviceArchIsMaxwellGM20XPlus(pEventGroup->pCtx->device)) {
                                // Required for GM20X: Use broadcast registers (Bug 200001628)
                                offset[count++] = NV_PLTCG_LTCS_LTSS_MISC_LTC_LTS_PM;
                            }
                            else {
                                offset[count++] = pTempPerfUnitTable->priBaseAddress
                                    + pTempPerfUnitTable->priChipletOffset * chipIdx
                                    + pPMEnableRegInfo->regOffset;
                            }
                            offset[count++] = NV_PRI_FE_PERFMON;

                            status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
                            if (status != CUDA_SUCCESS) {
                                return CUPROF_ERROR_HARDWARE;
                            }
                            //for maxwell 2nd level mux is removed that required a slice to be chosen
                            count = 0;
                            //In Maxwell, all LTS can be enabled simultaneously.
                            if(bEnable) {
                                    value[count++] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                                    value[count]  = DRF_REPLACE(value[count], NV_PRI_FE_PERFMON_ENABLE_ENABLE, NV_PRI_FE_PERFMON_ENABLE);
                                    count++;
                            }
                            else {
                                    value[count++] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
                                    value[count++] &= ~(DRF_MASK(NV_PRI_FE_PERFMON_ENABLE)<<(DRF_SHIFT(NV_PRI_FE_PERFMON_ENABLE)));
                            }
                        }

                        break;
                    default:
                        CU_ERROR_PRINT(("Not a valid chiplet type.\n"));
                        break;
                }
                status = PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
                if (status != CUDA_SUCCESS) {
                    return CUPROF_ERROR_HARDWARE;
                }
                i++;
            }
        }
    }

    return CUPROF_SUCCESS;
}

#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200
// no of available FBP units after floorsweep
static CUprofResult getLtcFloorsweeping(CUctx* ctx,
                                        NvU32 **virtualtoPhysicalRopL2UnitIndex,
                                        NvU32 *totalActiveRopL2Count,
                                        NvU32 *ropL2PerFbpCount)
{
    NvU32 activefbp = 0, fbpDisableMask = 0, ropL2DisableMask = 0;
    NvU32 i = 0, maxRopL2Count = 0, ropL2Idx = 0, fsRopL2CountInFbp = 0;

    if (ctx->device->dmalType == CU_DMAL_AMODEL) {
        //For a-model set fbpcount = 1
        *totalActiveRopL2Count = 1;
        virtualtoPhysicalRopL2UnitIndex[0][0] = 0;
        return CUPROF_SUCCESS;
    }

    //Total ROP L2 count
    maxRopL2Count = ctx->device->state.limits.maxFbps *
                    MAX_ROP_L2_UNITS_PER_FBP;

    fbpDisableMask = ctx->device->state.limits.fbpDisableMask;

    *totalActiveRopL2Count = 0;
    activefbp = 0;
    for (i = 0;
         i < ctx->device->state.limits.maxFbps;
         fbpDisableMask >>= 1, i++) {

        //Following var stores the rop_l2 indes considering floorsweeping
        fsRopL2CountInFbp = 0;
        ropL2DisableMask = ctx->device->state.limits.ropL2DisableMask[i];
        //Get floorswept count for ropL2Idx units
        for (ropL2Idx = 0; ropL2Idx < MAX_ROP_L2_UNITS_PER_FBP;
             ropL2DisableMask >>= 1, ropL2Idx++) {

            if ((ropL2DisableMask & 1) == 0) {
                //pmm addrses space of rop_l2 unit is not floorswept
               virtualtoPhysicalRopL2UnitIndex[activefbp][fsRopL2CountInFbp] = ropL2Idx;
                (*totalActiveRopL2Count)++;
                fsRopL2CountInFbp++;
                ropL2PerFbpCount[activefbp]++;
            }
        }
        if ((fbpDisableMask & 1) == 0) {
            activefbp++;
        }
    }
#if 0
    for (i=0; i<ctx->device->state.limits.maxFbps; i++)
    {
        printf("ROP_L2 in fbp[%d] = %d\n", i, ropL2PerFbpCount[i]);
    }
    printf("activefbp = %d\n", activefbp);
#endif
    CU_ASSERT(*totalActiveRopL2Count <= maxRopL2Count);
    return CUPROF_SUCCESS;
}
#endif

// Index of available TPCs after floorsweep
static CUprofResult getVirtualTpcIdx(CUctx* ctx, NvU32 **virtualtoPhysicalTpcIndex, NvU32 *gpcCount)
{
    NvU32 tpcDisableMask = 0, maxtpcCount = 0, tpcCount = 0;
    NvU32 gpc = 0, tpc = 0;

    maxtpcCount = ctx->device->state.limits.maxTpcsPerGpc;

    if (ctx->device->dmalType == CU_DMAL_AMODEL) {
        //For a-model set gpcmask properly
        for(gpc = 0; gpc < *gpcCount; gpc++) {
            for(tpc = 0; tpc < ctx->device->state.limits.numTpcsPerGpc[gpc]; tpc++) {
                ctx->device->state.limits.gpcTpcMask[gpc] |= 1 << tpc;
            }
        }
    }

    for(gpc = 0; gpc < *gpcCount; gpc++)
    {
        tpcCount = 0;
        //Read floorsweeping status for the engine
        tpcDisableMask = ctx->device->state.limits.gpcTpcMask[gpc];
        CU_DEBUG_PRINT(("GpcTpc Mask for GPC:%d =  0x%.08x\n", gpc,tpcDisableMask));

        for(tpc = 0; tpc < maxtpcCount; tpcDisableMask>>=1, tpc++)
        {
            if((tpcDisableMask & 1) != 0)
            {
                virtualtoPhysicalTpcIndex[gpc][tpcCount] = tpc;
                tpcCount++;
            }
        }
        CU_ASSERT(tpcCount == ctx->device->state.limits.numTpcsPerGpc[gpc]);
    }

    return CUPROF_SUCCESS;
}

static CUprofResult allocateMemoryForCounterValuesSMPC(const CUeventGroup *pEventGroup)
{
    CUSMCtrInfo  *pSM = NULL;

    pSM = pEventGroup->arch.maxwellEventGroup->pSM;

    if ((pSM) && (pSM->SMCountersAdded)) {
        if(pSM->values == NULL) {
            //Allocate memory for max SMPC counters
            pSM->values = (NvU64 *) malloc(pEventGroup->instanceCountAvail     * //no of chiplets
                (CU_PROF_SM_CORE_PROFILED_MAX + CU_PROF_SM_QUAD_PROFILED_MAX)  * //no of counters to be profiled in this domain
                sizeof(NvU64));
            if(pSM->values == NULL)
            {
                return CUPROF_ERROR_OUT_OF_MEMORY;
            }
        }
        cuosMemset(pSM->values, 0, sizeof(NvU64) * pEventGroup->instanceCountAvail * pSM->SMCountersAdded);
    }
    return CUPROF_SUCCESS;
}

static void resetPMTarget(const CUeventGroup *pEventGroup) {
    CUmaxwellEventGroup  *maxwellEventGroup;
    maxwellEventGroup = pEventGroup->arch.maxwellEventGroup;

    //It is possible that after eventgroup disable, the user can remove all ids
    //and add id from different domain. So the pmmaddress/priaddress need to be
    //recalculated for that chiplet.
    //Free pmm/pri address pointers otherwise they cause memory leak
    if (maxwellEventGroup->pmmAddress) {
        free(maxwellEventGroup->pmmAddress);
        maxwellEventGroup->pmmAddress = NULL;
    }
    if (maxwellEventGroup->priAddress) {
        free(maxwellEventGroup->priAddress);
        maxwellEventGroup->priAddress = NULL;
    }
}

static CUprofResult getSMPMMAddress(CUctx *ctx, NvU32 *pmmAddress, NvU32 *maxInstances) {
    NvU32  **virtualtoPhysicalTpcIndex = NULL, gpcCount = ctx->device->state.limits.numGpcs;
    NvU32 gpcId = 0, tpcId = 0, SMIdx = 0, index = 0;
    CUprofResult status = CUPROF_SUCCESS;

    virtualtoPhysicalTpcIndex = (NvU32 **)malloc(sizeof(NvU32 *) * gpcCount);
    if (!virtualtoPhysicalTpcIndex) {
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }
    for (index = 0; index < gpcCount; index++)
    {
        virtualtoPhysicalTpcIndex[index] = (NvU32 *)malloc(sizeof(NvU32)* ctx->device->state.limits.maxTpcsPerGpc);
        if (!virtualtoPhysicalTpcIndex[index]) {
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto EXIT;
        }
    }
    status = getVirtualTpcIdx(ctx, virtualtoPhysicalTpcIndex, &gpcCount);
    if (status != CUPROF_SUCCESS) {
        goto EXIT;
    }
    CU_ASSERT(gpcCount);
    SMIdx = 0;
    for (gpcId = 0; gpcId < gpcCount; gpcId++) {
        for (tpcId = 0; tpcId < ctx->device->state.limits.numTpcsPerGpc[gpcId]; tpcId++) {
            pmmAddress[SMIdx] = NV_PERF_PMMGPC_BASE + gpcId * NV_PERF_PMMGPC_CHIPLET_OFFSET + virtualtoPhysicalTpcIndex[gpcId][tpcId] * NV_PMM_DOMAIN_OFFSET;
            SMIdx++;
        }
    }
    *maxInstances = SMIdx;
EXIT:
    if (virtualtoPhysicalTpcIndex) {
        for (index = 0; index < gpcCount; index++) {
            free(virtualtoPhysicalTpcIndex[index]);
        }
        free(virtualtoPhysicalTpcIndex);
    }
    return status;
}

static CUprofResult setupPMTarget(const CUeventGroup *pEventGroup)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 gpcId = 0, tpcId = 0, gpcCount = 0, tpcCount = 0, maxtpc = 0, totalTPCCount = 0;
    NvU32 i = 0, SMIdx = 0, maxInstances = 0;
    NvU32 fbpCount = 0, tpcSelected = 0, maxtpcCount;
    CUparsedClk  *pParsedClk = NULL;
    CUmaxwellEventGroup  *maxwellEventGroup;

    //For PM signals
    maxwellEventGroup = pEventGroup->arch.maxwellEventGroup;
    pParsedClk = pEventGroup->arch.maxwellEventGroup->pParsedClk;

    CU_TRACE_FUNCTION();

    switch(pEventGroup->arch.maxwellEventGroup->chipletType)
    {
        //Allocate structure for chiplets that store the base address for the PRI registers for each chiplet
    case PM_CHIPLET_TYPE_SYS:
        maxwellEventGroup->pmmAddress = (NvU32 *) malloc(sizeof(NvU32) * 1);
        maxwellEventGroup->priAddress = (NvU32 *) malloc(sizeof(NvU32) * 1);
        if (!(maxwellEventGroup->pmmAddress && maxwellEventGroup->priAddress))
        {
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto EXIT;
        }

        maxwellEventGroup->maxChiplets = 1;
        // TODO: it seems units under chiplet SYS have absolute address
        // in spec file, thus keeping priAddress = 0. Verify it
        maxwellEventGroup->priAddress[0] = 0;
        maxwellEventGroup->pmmAddress[0] = NV_PERF_PMMSYS_BASE;
        maxwellEventGroup->pmUnitMask = 1;

        break;

    case PM_CHIPLET_TYPE_GPC:
        //TBD Shift the gpc processing related part to a function.

        // handle floor-sweeping case
        // On fermi the floorsweeping has all been abstracted to SW so that we dont worry about what units are swept,
        // we really just care about how many of each unit we have, and access them sequentially from [0-max]
        // the HW deals with mapping them internally
        gpcCount = pEventGroup->pCtx->device->state.limits.numGpcs;   // no. of available GPCs after floorsweep
        maxtpcCount = pEventGroup->pCtx->device->state.limits.maxTpcsPerGpc;
        maxwellEventGroup->gpcCount = gpcCount;
        maxwellEventGroup->tpcPerGpcCount = pEventGroup->pCtx->device->state.limits.numTpcsPerGpc;

        // Enable NV_SM_PM_CTRL for selected GPC/TPC and disable for others
        // disable NV_SM_PM_CTRL in other GPCs
        for (gpcId = 0; gpcId < gpcCount; gpcId++) {
            // get no of available TPCs in the GPC
            tpcCount = maxwellEventGroup->tpcPerGpcCount[gpcId];
            if(pEventGroup->pCtx->device->state.workDistributionMode == CU_WORK_DISTRIBUTION_DYNAMIC)
            {
                //From Gentaro Hirota and Tanmoy Mandal:
                //In Maxwell, CWD is blind to GPC. It just launches CTAs directly to SMs.
                //So the 1st SM picked by CWD after idle would be always the SM with highest logical id.
                //RM assigns each SM a logical id. SM in TPC0 of GPC0 gets logical id zero.
                //see function fermi_getInfo in //sw/dev/gpu_drv/cuda_a/drivers/gpgpu/cuda/src/devtools/common/halo/fermi/fermi.c
                //to understand the algorithm behind SM logical-id
                //in short, select the last SM of last GPC that has highest no of SMs becuase that's the first one chosen for scheduling

                totalTPCCount += tpcCount;

                if (maxtpc <= tpcCount) {
                    maxtpc = tpcCount;
                    //select last tpc of selected gpc
                    tpcSelected = totalTPCCount - 1;
                }
            }

#ifdef DEBUG
            CU_DEBUG_PRINT(("GPC %d : num of active TPCs = %d\n", gpcId, tpcCount));
#endif
        }

        maxwellEventGroup->pmmAddress = (NvU32 *) malloc(sizeof(NvU32) * totalTPCCount);
        maxwellEventGroup->priAddress = (NvU32 *) malloc(sizeof(NvU32) * totalTPCCount);
        if (!(maxwellEventGroup->pmmAddress && maxwellEventGroup->priAddress))
        {
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto EXIT;
        }

        maxwellEventGroup->maxChiplets = totalTPCCount;
        //pmUnitMask for gpc is set for the selected gpc and tpc 0 will be profiled from the seleced gpc by default
        //this hack will be gone if we have 1 perfmon per tpc in maxwell

        if((CUPROF_EVENT_COLLECTION_METHOD_HWPM == pEventGroup->domain->eventCollectionMethod) ||
           (CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX == pEventGroup->domain->eventCollectionMethod))//HWPM
        {
            SMIdx = 0;

            status = getSMPMMAddress(pEventGroup->pCtx, maxwellEventGroup->pmmAddress, &maxInstances);
            if (status != CUPROF_SUCCESS) {
                CU_ERROR_PRINT(("Failed to map virtual to physical TPC index\n"));
                goto EXIT;
            }

            //Assign the pri and pmm base addreses so that they need not be calcualted again and again
            for (gpcId = 0; gpcId < gpcCount; gpcId++) {
                for (tpcId = 0; tpcId < pEventGroup->arch.maxwellEventGroup->tpcPerGpcCount[gpcId]; tpcId++) {
                    maxwellEventGroup->pmUnitMask |= (1 << SMIdx);
                    maxwellEventGroup->priAddress[SMIdx] = NV_PRI_TPC_ADDR(gpcId, tpcId);
                    //TBD A hack here to access the second domain from the gpc for tpc.
                    //The getClkIdx function will return same value for all gpctpc domain for all tpcs.
                    //So we add the domain offset in pmmaddress here. Else we will have to expose separate
                    //domain for each tpc, resulting in multiple signal tables etc.
                    SMIdx++;
                }
            }
        }
        if(CUPROF_EVENT_COLLECTION_METHOD_HWPM != pEventGroup->domain->eventCollectionMethod)
        {
            //Need for SMPC and HWPMMux both
            SMIdx = 0;
            //Assign the pri and pmm base addreses so that they need not be calcualted again and again
            for (gpcId = 0; gpcId < gpcCount; gpcId++) {
                for (tpcId = 0; tpcId < pEventGroup->arch.maxwellEventGroup->tpcPerGpcCount[gpcId]; tpcId++) {
                    //Profile all tpcs from a GPC for SM counters.
                    maxwellEventGroup->pmUnitMask |= (1 << SMIdx);
                    maxwellEventGroup->priAddress[SMIdx] = NV_PRI_TPC_ADDR(gpcId, tpcId);
                    maxwellEventGroup->pmmAddress[SMIdx] = NV_PERF_PMMGPC_BASE + gpcId * NV_PERF_PMMGPC_CHIPLET_OFFSET;
                    SMIdx++;
                }
            }

        }

        if(!pEventGroup->profileAll) {
            //If profileall flag is not set, then profile only the first tpc selected by scheduler.
            maxwellEventGroup->pmUnitMask = 1 << tpcSelected;
        }

        break;

    case PM_CHIPLET_TYPE_FBP:
        {
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200
            NvU32 *ropL2PerFbpCount = NULL, fbpId = 0, ropL2IdInFbp = 0, ropL2Idx = 0, i = 0;
            NvU32 **virtualtoPhysicalRopL2UnitIndex = NULL, ropL2Count;
#endif
            fbpCount = pEventGroup->pCtx->device->state.limits.numFbps;

#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200
            if((cuiDeviceArchIsMaxwellGM20XPlus(pEventGroup->pCtx->device)) &&
                (MAXWELL_CLK_DOMAIN_GM200_LTC0 == pEventGroup->domain->domainId))
            {
                ropL2PerFbpCount = (NvU32 *) calloc (fbpCount, sizeof(NvU32));
                if(ropL2PerFbpCount == NULL)
                {
                    status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
                    goto CLEANUP_ROP_L2_RESOURCES;
                }

                virtualtoPhysicalRopL2UnitIndex = (NvU32 **) calloc (fbpCount, sizeof(NvU32 *));
                if(virtualtoPhysicalRopL2UnitIndex == NULL)
                {
                    status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
                    goto CLEANUP_ROP_L2_RESOURCES;
                }
                for (fbpId = 0; fbpId < fbpCount; fbpId++) {
                    virtualtoPhysicalRopL2UnitIndex[fbpId] = (NvU32 *) calloc (MAX_ROP_L2_UNITS_PER_FBP, sizeof(NvU32));
                    if(virtualtoPhysicalRopL2UnitIndex[fbpId] == NULL)
                    {
                        status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
                        goto CLEANUP_ROP_L2_RESOURCES;
                    }
                }

                // query active LTC units and its floorsweeping status
                status = getLtcFloorsweeping(pEventGroup->pCtx,
                                             virtualtoPhysicalRopL2UnitIndex,
                                             &ropL2Count,
                                             ropL2PerFbpCount);
                CU_ASSERT(ropL2Count);
                if(status != CUPROF_SUCCESS)
                    goto EXIT;
                maxwellEventGroup->maxChiplets = ropL2Count;

                maxwellEventGroup->pmmAddress = (NvU32 *) malloc(sizeof(NvU32) * ropL2Count);
                maxwellEventGroup->priAddress = (NvU32 *) malloc(sizeof(NvU32) * ropL2Count);
                if (!(maxwellEventGroup->pmmAddress && maxwellEventGroup->priAddress))
                {
                    status = CUPROF_ERROR_OUT_OF_MEMORY;
                    goto CLEANUP_ROP_L2_RESOURCES;
                }
                ropL2Idx = 0;
                //Assign the pri and pmm base addreses so that they need not be calcualted again and again
                for (fbpId = 0; fbpId < fbpCount; fbpId++) {
                    for (ropL2IdInFbp = 0; ropL2IdInFbp < ropL2PerFbpCount[fbpId]; ropL2IdInFbp++) {
                        maxwellEventGroup->pmUnitMask |= (1 << ropL2Idx);

                        //use broadcast priAddress for enabling PM or selecting group

                        //From GM20x, there are multiple 2 rop_l2 units in each ebp chiplet and they are
                        //independently floorsweepable. The perfmon unit's address space is not floorswept.
                        //A hack here to access the second domain from the fbp for rop_l2 unit.
                        //The getClkIdx function will return same value for all rop_l2 domain for all rop_l2s.
                        //So we add the domain offset in pmmaddress here. Else we will have to expose separate
                        //domain for each rop_l2, resulting in multiple signal tables etc.
                        if(ropL2PerFbpCount[fbpId] > 0) {
                            maxwellEventGroup->pmmAddress[ropL2Idx] = NV_PERF_PMMFBP_BASE + fbpId * NV_PERF_PMMFBP_CHIPLET_OFFSET +
                                virtualtoPhysicalRopL2UnitIndex[fbpId][ropL2IdInFbp] * NV_PMM_DOMAIN_OFFSET;
                        }
                        ropL2Idx++;
                    }
                }
CLEANUP_ROP_L2_RESOURCES:
                free(ropL2PerFbpCount);
                if (virtualtoPhysicalRopL2UnitIndex) {
                    for (fbpId = 0; fbpId < fbpCount; fbpId++) {
                        free(virtualtoPhysicalRopL2UnitIndex[fbpId]);
                    }
                    free(virtualtoPhysicalRopL2UnitIndex);
                }
                if (status != CUPROF_SUCCESS) {
                    goto EXIT;
                }
            } else
#endif
            {
                maxwellEventGroup->pmmAddress = (NvU32 *) malloc(sizeof(NvU32) * fbpCount);
                maxwellEventGroup->priAddress = (NvU32 *) malloc(sizeof(NvU32) * fbpCount);
                if (!(maxwellEventGroup->pmmAddress && maxwellEventGroup->priAddress))
                {
                    status = CUPROF_ERROR_OUT_OF_MEMORY;
                    goto EXIT;
                }

                maxwellEventGroup->maxChiplets = fbpCount;
                for (i = 0; i < fbpCount; i++) {
                    //Since PRI base/offset for FBPA and LTC is different, though they belong to same chiplet, the PRI base/offset are stored in unit table.
                    //maxwellEventGroup->pmmAddress[i] = (NV_PLTCG_BASE+i*NV_PLTCG_STRIDE);
                    //maxwellEventGroup->priAddress[i] = (NV_FBPA_PRI_BASE+i*NV_FBPA_PRI_STRIDE);
                    maxwellEventGroup->pmmAddress[i] = (NV_PERF_PMMFBP_BASE+i*NV_PERF_PMMFBP_CHIPLET_OFFSET);
                    maxwellEventGroup->pmUnitMask |= 1 << i;
                }
            }

            if(!pEventGroup->profileAll) {
                //If profileall flag is not set, then profile only the first fbp.
                maxwellEventGroup->pmUnitMask = 1;
            }
        }
        break;

    default:
        CU_ASSERT(0);
        break;
    }

    //TBD Shift values to maxwelleventgroup structure to remove the following switch
    switch(pEventGroup->domain->eventCollectionMethod)
    {
    case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
        if ((pParsedClk) && (pEventGroup->totalCounters)) {
            if(pParsedClk->values == NULL) {
                //Allocate memory for max counters + 1 for elapsed_clocks
                pParsedClk->values = (NvU32 *) malloc(maxwellEventGroup->maxChiplets     * //no of chiplets
                    (CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS + CU_PROF_ELAPSED_CLOCK_SLOT)  * //no of counters to be profiled in this domain
                    sizeof(NvU32));
                if(pParsedClk->values == NULL)
                {
                    status = CUPROF_ERROR_OUT_OF_MEMORY;
                    goto EXIT;
                }
            }
            cuosMemset(pParsedClk->values, 0, sizeof(NvU32) * maxwellEventGroup->maxChiplets * pEventGroup->totalCounters);
        }
        break;

    case CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
    case CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX:
        status = allocateMemoryForCounterValuesSMPC(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            goto EXIT;
        }
        break;

    default:
        //TBD Add s/w counters here
        break;
    }

    return status;
EXIT:
    free(pParsedClk->values);
    free(maxwellEventGroup->pmmAddress);
    free(maxwellEventGroup->priAddress);
    return status;
}
// function to configure event-groups
static CUprofResult setPMGroupReg(const CUeventGroup *pEventGroup)
{
    //Function to be changed for new version
    CUresult status = CUDA_SUCCESS;
    NvU32 offset[2], value[2];
    NvU32 chipIdx = 0, tempUnitId = 0;
    NvU32 i = 0;
    CUmaxwellEventGroup *maxwellEventGroup;
    CUparsedClk     *pTempParsedClk = NULL;
    CU_TRACE_FUNCTION();

    maxwellEventGroup = pEventGroup->arch.maxwellEventGroup;

    for (chipIdx = 0; chipIdx < pEventGroup->arch.maxwellEventGroup->maxChiplets; chipIdx++) {
        if(maxwellEventGroup->pmUnitMask & (1<<chipIdx)) {
            pTempParsedClk = maxwellEventGroup->pParsedClk;
            i = 0;
            while(pTempParsedClk && pTempParsedClk->pParsedUnit[i])
            {
                //The earlier design was assuming that there will be only 1 PRI base address for 1 instance of a chiplettype
                //FBP has different base addresses for LTC and FBP, to solve this currently added the pri base address to unit table.
                //This doesn't work directly for GPC as the TPC pri base address are based on gpcid and tpcid both.
                //TBD: Adding hack here, to remove this hack, we will have to add an extra loop for instance in each function.
                tempUnitId = pTempParsedClk->pParsedUnit[i]->unitId;
                if(PM_CHIPLET_TYPE_FBP == pEventGroup->arch.maxwellEventGroup->chipletType) {
                    if(tempUnitId == PM_UNIT_FB) {
                        //Use broadcast register to enable PM for FBPA as unicast are giving wrong values
                        //Writing to boardcast register for each chiplet to avoid conditions, otherwise writing
                        //only once is sufficient
                        //This is not needed for GF108 as it has only 1 FB chiplet with 2 FBPA and address of
                        //both FBPAs are different.
                        offset[0] = NV_FBPA_PRI_BASE_BROADCAST + pTempParsedClk->pParsedUnit[i]->groupSelAddress;
                    }
                    else {
                        if (cuiDeviceArchIsMaxwellGM20XPlus(pEventGroup->pCtx->device)) {
                            // Required for GM20X: Use broadcast registers (Bug 200001628)
                            offset[0] = NV_PLTCG_LTCS_LTSS_MISC_LTC_LTS_PM;
                        }
                        else {
                            PerfUnitTable   *pTempPerfUnitTable = pTempParsedClk->pParsedUnit[i]->pPerfUnitTable;
                            offset[0] = pTempPerfUnitTable->priBaseAddress
                                + pTempPerfUnitTable->priChipletOffset * chipIdx
                                + pTempParsedClk->pParsedUnit[i]->groupSelAddress;
                        }
                    }
                }
                else {
                    offset[0] = maxwellEventGroup->priAddress[chipIdx] + pTempParsedClk->pParsedUnit[i]->groupSelAddress;
                }

                // For maxwell, the TRM is removed. So we don't have a double layer of group
                //selection for tex.

                // read the register
                status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, 1, offset, value, 0);
                if (status != CUDA_SUCCESS) {
                    return CUPROF_ERROR_HARDWARE;
                }
                {
                    value[0] &= ~pTempParsedClk->pParsedUnit[i]->groupSelMask;
                    value[0] |= (pTempParsedClk->pParsedUnit[i]->groupSelValue & pTempParsedClk->pParsedUnit[i]->groupSelMask);
                }
                status = PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, 1, offset, value, 0);
                if (status != CUDA_SUCCESS) {
                    return CUPROF_ERROR_HARDWARE;
                }
                i++;
            }
        }
    }
    return CUPROF_SUCCESS;
}

static CUprofResult setupPMRegistersModeB(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *value = NULL;
    NvU32 count = 0, size = 0, numReg = 0;
    NvU32 domainRegOffset = 0, chipIdx = 0;
    CUmaxwellEventGroup  *maxwellEventGroup;

    CU_TRACE_FUNCTION();

    //For PM signals
    maxwellEventGroup = pEventGroup->arch.maxwellEventGroup;

    if(!maxwellEventGroup)
        return CUPROF_ERROR_UNKNOWN; //TBD check if we can return this error.

    //8 - reset sel+op for all 4 counters
    //8 - set sel+op for all 4 counters
    //2 - PMM_CONTROL and PMM_CONTROL2
    //4*7 - 4 counters, max 7 units/counter (tex has max 7 units)
    numReg = (8 + 8 + 2 + 4 * 7) * maxwellEventGroup->maxChiplets; //TBD: Replace the magic no
    size = sizeof(NvU32) * numReg;
    offset = (NvU32*)malloc(size);
    value  = (NvU32*)calloc(size, 1);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset and value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    status = setPMGroupReg(pEventGroup);
    if (CUPROF_SUCCESS != status) {
        goto EXIT;
    }

    for (chipIdx = 0; chipIdx < maxwellEventGroup->maxChiplets; chipIdx++) {
        if(maxwellEventGroup->pmUnitMask & (1<<chipIdx))
        {
            if (maxwellEventGroup->pParsedClk && pEventGroup->totalCounters) {
                CUparsedClk *pTempParsedClk = maxwellEventGroup->pParsedClk;
                if((pTempParsedClk->mode == -1) && (pEventGroup->totalCounters == 1)) {
                    //if elapsed_cycles_sm is the only signal added, then the mode remains -1 which affects the registers below, so just set to 0.
                    pTempParsedClk->mode = 0;
                }
                domainRegOffset = maxwellEventGroup->pmmAddress[chipIdx] + maxwellEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
                offset[count]  = domainRegOffset + NV_PMM_CONTROL;

                if ((pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_KERNEL) ||
                    (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS)) {
                    if (pEventGroup->pCtx->pmNew->isPmCtxswModeEnabled) {
                        value[count++] = (NV_PMM_CONTROL_MODE_B                   << NV_PMM_CONTROL_MODE__SHIFT)    |
                                         (pTempParsedClk->mode                    << NV_PMM_CONTROL_ADDTOCTR__SHIFT)|
                                         (NV_PMM_CONTROL_CTXSW_MODE_ENABLED       << NV_PMM_CONTROL_CTXSW_MODE__SHIFT);
                    }
                    else {
                        value[count++] = (NV_PMM_CONTROL_MODE_B                   << NV_PMM_CONTROL_MODE__SHIFT)    |
                                         (pTempParsedClk->mode                    << NV_PMM_CONTROL_ADDTOCTR__SHIFT)|
                                         (NV_PMM_CONTROL_CTXSW_MODE_DISABLED      << NV_PMM_CONTROL_CTXSW_MODE__SHIFT);
                    }
                } else if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING){

                    NvU8 perfmonid = 0;
                    //Assign 8 bit perfmonId as follows:
                    //for FBP and GPC, LSB ro MSB : 2 bits for chiplet, 2 bits for clkidx and 4 bits for instance.
                    //for SYS, LSB ro MSB : 2 bits for chiplet, 3 bits for clkidx and 3 bits for instance.
                    if (pEventGroup->arch.maxwellEventGroup->chipletType == PM_CHIPLET_TYPE_SYS) {
                        //There is only 1 instance of sys but it can have max 8 domains so use different encoding
                        perfmonid = (pEventGroup->arch.maxwellEventGroup->chipletType & 3) | ((maxwellEventGroup->clkIdx & 7) << 2) | ((chipIdx & 0x7) << 5);
                    } else {
                        //TBD On maxwell check max no of SMs/chip
                        perfmonid = (pEventGroup->arch.maxwellEventGroup->chipletType & 3) | ((maxwellEventGroup->clkIdx & 3) << 2) | ((chipIdx & 0xf)<< 4);
                    }
                    value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_MODE_E, NV_PERF_PMMSYS_CONTROL_MODE);
                    value[count] = DRF_REPLACE(value[count], pTempParsedClk->mode, NV_PERF_PMMSYS_CONTROL_ADDTOCTR);
                    value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_CTXSW_MODE_DISABLED, NV_PERF_PMMSYS_CONTROL_CTXSW_MODE);
                    value[count] = DRF_REPLACE(value[count], pEventGroup->pCtx->pmNew->samplingPeriod, NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES);
                    value[count] = DRF_REPLACE(value[count], perfmonid, NV_PERF_PMMSYS_CONTROL_PERFMONID);
                    count++;

                    offset[count]  = domainRegOffset + NV_PMM_CONTROL2;
                    value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL2_PTIMER_ENABLED, NV_PERF_PMMSYS_CONTROL2_PTIMER);
                    count++;
                }

                offset[count]  = domainRegOffset + NV_PMM_TRIG0_SEL;
                value[count++] = 0;
                offset[count]  = domainRegOffset + NV_PMM_TRIG0_OP;
                value[count++] = 0;
                offset[count]  = domainRegOffset + NV_PMM_TRIG1_SEL;
                value[count++] = 0;
                offset[count]  = domainRegOffset + NV_PMM_TRIG1_OP;
                value[count++] = 0;
                offset[count]  = domainRegOffset + NV_PMM_EVENT_SEL;
                value[count++] = 0;
                offset[count]  = domainRegOffset + NV_PMM_EVENT_OP;
                value[count++] = 0;
                offset[count]  = domainRegOffset + NV_PMM_SAMPLE_SEL;
                value[count++] = 0;
                offset[count]  = domainRegOffset + NV_PMM_SAMPLE_OP;
                value[count++] = 0;

                if (pTempParsedClk->eventSpecUsed & NV_PMM_TRIG1) {
                    offset[count]  = domainRegOffset + NV_PMM_TRIG1_SEL;
                    value[count++] = pTempParsedClk->watchBus[NV_PMM_TRIG1_BIT_POS];
                    offset[count]  = domainRegOffset + NV_PMM_TRIG1_OP;
                    value[count]   = DRF_REPLACE(value[count], pTempParsedClk->function[NV_PMM_TRIG1_BIT_POS], NV_PERF_PMMSYS_TRIG1_OP_FUNC);
                    value[count]   = DRF_REPLACE(value[count], pTempParsedClk->delaySelects[NV_PMM_TRIG1_BIT_POS], NV_PERF_PMMSYS_DSELS);
                    count++;
                }

                if (pTempParsedClk->eventSpecUsed & NV_PMM_TRIG0) {
                    offset[count]  = domainRegOffset + NV_PMM_TRIG0_SEL;
                    value[count++] = pTempParsedClk->watchBus[NV_PMM_TRIG0_BIT_POS];
                    offset[count]  = domainRegOffset + NV_PMM_TRIG0_OP;
                    value[count]   = DRF_REPLACE(value[count], pTempParsedClk->function[NV_PMM_TRIG0_BIT_POS], NV_PERF_PMMSYS_TRIG0_OP_FUNC);
                    value[count]   = DRF_REPLACE(value[count], pTempParsedClk->delaySelects[NV_PMM_TRIG0_BIT_POS], NV_PERF_PMMSYS_DSELS);
                    count++;
                }

                if (pTempParsedClk->eventSpecUsed & NV_PMM_EVENT) {
                    offset[count]  = domainRegOffset + NV_PMM_EVENT_SEL;
                    value[count++] = pTempParsedClk->watchBus[NV_PMM_EVENT_BIT_POS];
                    offset[count]  = domainRegOffset + NV_PMM_EVENT_OP;
                    value[count]   = DRF_REPLACE(value[count], pTempParsedClk->function[NV_PMM_EVENT_BIT_POS], NV_PERF_PMMSYS_EVENT_OP_FUNC);
                    value[count]   = DRF_REPLACE(value[count], pTempParsedClk->delaySelects[NV_PMM_EVENT_BIT_POS], NV_PERF_PMMSYS_DSELS);
                    count++;
                }

                if (pTempParsedClk->eventSpecUsed & NV_PMM_SAMPLE) {
                    offset[count]  = domainRegOffset + NV_PMM_SAMPLE_SEL;
                    value[count++] = pTempParsedClk->watchBus[NV_PMM_SAMPLE_BIT_POS];
                    offset[count]  = domainRegOffset + NV_PMM_SAMPLE_OP;
                    value[count]   = DRF_REPLACE(value[count], pTempParsedClk->function[NV_PMM_SAMPLE_BIT_POS], NV_PERF_PMMSYS_SAMPLE_OP_FUNC);
                    value[count]   = DRF_REPLACE(value[count], pTempParsedClk->delaySelects[NV_PMM_SAMPLE_BIT_POS], NV_PERF_PMMSYS_DSELS);
                    count++;
                }
            }
        }
    }
    CU_ASSERT(count <= numReg);
    // write signal configuration
    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

EXIT:
    free (offset);
    free (value);

    return status;
}

static CUprofResult setupPMRegistersModeCommon(const CUeventGroup *pEventGroup, NvU32* perfmonTriggerRefCount) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL;
    NvU32 *value  = NULL;
    NvU32 count = 0;
    NvU32 domainRegOffset = 0, chipIdx = 0;
    NvU32 numDomains = 0;
    NvU32 size = 0;
    CUmaxwellEventGroup  *maxwellEventGroup;

    CU_TRACE_FUNCTION();

    numDomains = PM_MAX_CHIPLET_TYPES * PM_MAX_CHIPLETS_PER_CHIPLET_TYPE * PM_MAX_DOMAIN_PER_CHIPLET;
    size  = sizeof(NvU32) * (numDomains * 6 + 16);
    offset = (NvU32*)malloc(size);
    value  = (NvU32*)calloc(size, 1);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset/value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    maxwellEventGroup = pEventGroup->arch.maxwellEventGroup;
    CU_ASSERT(maxwellEventGroup->pParsedClk);

    // Vivek Gupta suggests disable the safety clamp before you can get pass signals to the performance monitors on net35 and above.
    // This is to prevent us being affected by cdc/async bugs inside units that feed to the monitors
    for (chipIdx = 0; chipIdx < maxwellEventGroup->maxChiplets; chipIdx++) {
        if(maxwellEventGroup->pmUnitMask & (1<<chipIdx)) {
            if(pEventGroup->totalCounters) {
                domainRegOffset = maxwellEventGroup->pmmAddress[chipIdx] + maxwellEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
                offset[count]  = domainRegOffset + NV_PMM_CLAMP_CYA_CONTROL;
                value[count++] = NV_PMM_CLAMP_CYA_CONTROL_ENABLECYA_DISABLE;
                offset[count++]  = domainRegOffset + NV_PERF_WBSKEW0;
                offset[count++]  = domainRegOffset + NV_PERF_WBSKEW1;
                offset[count++]  = domainRegOffset + NV_PERF_WBSKEW2;
                offset[count++]  = domainRegOffset + NV_PERF_WBSKEW_CHAIN0;
                offset[count++]  = domainRegOffset + NV_PERF_WBSKEW_CHAIN1;
            }
        }
    }

    if(!(*perfmonTriggerRefCount)) {
        offset[count++]  = NV_PERF_PMASYS_GPC_TRIGGER_STATUS;

        offset[count++]  = NV_PERF_PMASYS_FBP_TRIGGER_STATUS;

        offset[count++]  = NV_PERF_PMASYS_SYS_TRIGGER_STATUS;

        offset[count]  = NV_PERF_PMASYS_CONTROL;
        value[count++] = HWCONST(_PERF_PMASYS, CONTROL, STOPVPMCAPTURE, DOIT);

        offset[count++]  = NV_PERF_PMASYS_CONTROL;

        // setup PMA to push trigger to GPC chiplet
        offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_START_MASK;
        value[count++] = 0xffffffff;

        offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_STOP_MASK;
        value[count++] = 0xffffffff;

        offset[count]  = NV_PERF_PMASYS_SYS_TRIGGER_START_MASK;
        value[count++] = 0xffffffff;

        offset[count]  = NV_PERF_PMASYS_SYS_TRIGGER_STOP_MASK;
        value[count++] = 0xffffffff;

        offset[count]  = NV_PERF_PMASYS_FBP_TRIGGER_START_MASK;
        value[count++] = 0xffffffff;

        offset[count]  = NV_PERF_PMASYS_FBP_TRIGGER_STOP_MASK;
        value[count++] = 0xffffffff;
#if 1
        offset[count]  = NV_PERF_PMASYS_TRIGGER_GLOBAL;
        value[count++] = HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, ENABLE, ENABLED) |
            HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_GPC, ENABLE) |
            HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_FBP, ENABLE) |
            HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_SYS, ENABLE);
#else
        offset[count]  = NV_PERF_PMASYS_TRIGGER_GLOBAL;
        value[count++] = HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, MANUAL_START, PULSE) |
            HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, MANUAL_STOP, PULSE);
#endif
        offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_CONFIG_MIXED_MODE;
        value[count++] = 0xffffffff;
    }
    (*perfmonTriggerRefCount)++;

    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

EXIT:
    free(offset);
    free(value);

    return status;
}

static NvU32 resolveTPulse(const CUctx *ctx, const NvU32 clkIdx, const NvU32 chipletType)
{
    NvU32 const (*tPulse)[PM_MAX_DOMAIN_PER_CHIPLET] = NULL;
    NvU32 numericId = ~0U;

    static const NvU32 nvgm000_t_pulse[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        //#defines taken from pm_signals.h
        {GM10X_NV_PERF_PMMSYS_HOST0_SIGVAL_T_PULSE, GM10X_NV_PERF_PMMSYS_MSD0_SIGVAL_T_PULSE, GM10X_NV_PERF_PMMSYS_MSD1_SIGVAL_T_PULSE, GM10X_NV_PERF_PMMSYS_PCIE0_SIGVAL_T_PULSE, GM10X_NV_PERF_PMMSYS_PWR0_SIGVAL_T_PULSE, GM10X_NV_PERF_PMMSYS_SYS0_SIGVAL_T_PULSE, GM10X_NV_PERF_PMMSYS_XBAR0_SIGVAL_T_PULSE},
        {GM10X_NV_PERF_PMMGPC_GPC0_SIGVAL_T_PULSE, GM10X_NV_PERF_PMMGPC_GPCTPC0_SIGVAL_T_PULSE},
        {GM10X_NV_PERF_PMMFBP_FBP0_SIGVAL_T_PULSE, GM10X_NV_PERF_PMMFBP_LTC0_SIGVAL_T_PULSE, GM10X_NV_PERF_PMMFBP_LTC1_SIGVAL_T_PULSE, GM10X_NV_PERF_PMMFBP_ROP0_SIGVAL_T_PULSE}
    };

    static const NvU32 nvgm200_t_pulse[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        //#defines taken from pm_signals.h
        {GM20X_NV_PERF_PMMSYS_HOST0_SIGVAL_T_PULSE, GM20X_NV_PERF_PMMSYS_MSD0_SIGVAL_T_PULSE, GM20X_NV_PERF_PMMSYS_MSD1_SIGVAL_T_PULSE, GM20X_NV_PERF_PMMSYS_PCIE0_SIGVAL_T_PULSE, GM20X_NV_PERF_PMMSYS_PWR0_SIGVAL_T_PULSE, GM20X_NV_PERF_PMMSYS_SYS0_SIGVAL_T_PULSE, GM20X_NV_PERF_PMMSYS_XBAR0_SIGVAL_T_PULSE},
        {GM20X_NV_PERF_PMMGPC_GPC0_SIGVAL_T_PULSE, GM20X_NV_PERF_PMMGPC_GPCTPC0_SIGVAL_T_PULSE},
        {GM20X_NV_PERF_PMMFBP_FBP0_SIGVAL_T_PULSE, GM20X_NV_PERF_PMMFBP_LTC0_SIGVAL_T_PULSE, GM20X_NV_PERF_PMMFBP_LTC1_SIGVAL_T_PULSE, GM20X_NV_PERF_PMMFBP_ROP0_SIGVAL_T_PULSE, GM20X_NV_PERF_PMMFBP_ROP1_SIGVAL_T_PULSE}
    };
#if NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
    static const NvU32 nvgm20y_t_pulse[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        //#defines taken from pm_signals.h
        {GM20Y_NV_PERF_PMMSYS_ACB0_SIGVAL_T_PULSE, GM20Y_NV_PERF_PMMSYS_MC0_SIGVAL_T_PULSE, GM20Y_NV_PERF_PMMSYS_PWR0_SIGVAL_T_PULSE, GM20Y_NV_PERF_PMMSYS_SYS0_SIGVAL_T_PULSE},
        {GM20Y_NV_PERF_PMMGPC_GPC0_SIGVAL_T_PULSE, GM20Y_NV_PERF_PMMGPC_GPCTPC0_SIGVAL_T_PULSE},
        {GM20Y_NV_PERF_PMMFBP_FBP0_SIGVAL_T_PULSE}
    };
#endif // NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)

    if (chipletType >= PM_MAX_CHIPLET_TYPES || clkIdx >= PM_MAX_DOMAIN_PER_CHIPLET) {
        CU_ERROR_PRINT(("Invalid chiplet/clk values\n"));
        CU_ASSERT (0);
        return numericId;
    }

    CU_TRACE_FUNCTION();

    switch(ctx->device->state.chip) {
#if NVCFG(GLOBAL_ARCH_MAXWELL)
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM000 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM107:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM000 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM108:
        tPulse = nvgm000_t_pulse;
        break;
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM204:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM206:
        tPulse = nvgm200_t_pulse;
        break;
#endif // NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200
#endif // NVCFG(GLOBAL_ARCH_MAXWELL)
#if NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM20B:
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM21B
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM21B:
#endif // NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM21B
        tPulse = nvgm20y_t_pulse;
        break;
#endif // NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
    default:
        CU_ASSERT(0);
        return numericId;
    }

    if (tPulse) {
        numericId = tPulse[chipletType][clkIdx];
    }
    else {
        CU_ASSERT(0); // Throw assert if signal names is NULL
    }

    return numericId;
}

// returns numeric value corresponding to signal name
static NvU32 resolveCoreSignalName(const CUctx *ctx, const NvU32 clkIdx, const NvU32 chipletType)
{
    NvU32 const (*signalNames)[PM_MAX_DOMAIN_PER_CHIPLET] = NULL;
    NvU32 numericId = ~0U;

    // cut-down list containing pma_trigger signals only
    //The array is arranged in the order of domain ids, do not change the sequence
    // of the array, it will affect the counter values.
    // source: <branch>\drivers\common\inc\hwref\maxwell\gm107\dev_perf.h
    //static const maxwellSignalName2Numeric nvgm000_pma_trigger[] =
    //{
    //    {"gpc0_sigval_pma_trigger",                         237},
    //    //TBD: Currently we have trigger value same for all gpctpc domains so expose it as one domain.
    //    //{"gpctpc0_sigval_pma_trigger",                      173},
    //    //{"gpctpc1_sigval_pma_trigger",                      173},
    //    //{"gpctpc2_sigval_pma_trigger",                      173},
    //    //{"gpctpc3_sigval_pma_trigger",                      173},
    //    //{"gpctpc4_sigval_pma_trigger",                      173},
    //    {"gpctpc_sigval_pma_trigger",                      173},
    //    {"host0_sigval_pma_trigger",                        77},
    //    {"msd0_sigval_pma_trigger",                         77},
    //    {"msd1_sigval_pma_trigger",                         77},
    //    {"pcie0_sigval_pma_trigger",                        45},
    //    {"pwr0_sigval_pma_trigger",                         77},
    //    {"sys0_sigval_pma_trigger",                         173},
    //    {"xbar0_sigval_pma_trigger",                        77},
    //    {"fbp0_sigval_pma_trigger",                         45},
    //    {"ltc0_sigval_pma_trigger",                         109}
    //    {"ltc1_sigval_pma_trigger",                         109},
    //    {"rop0_sigval_pma_trigger",                         77}
    //};

    static const NvU32 nvgm000_pma_trigger[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        //#defines taken from pm_signals.h
        {GM10X_NV_PERF_PMMSYS_HOST0_SIGVAL_PMA_TRIGGER, GM10X_NV_PERF_PMMSYS_MSD0_SIGVAL_PMA_TRIGGER, GM10X_NV_PERF_PMMSYS_MSD1_SIGVAL_PMA_TRIGGER, GM10X_NV_PERF_PMMSYS_PCIE0_SIGVAL_PMA_TRIGGER, GM10X_NV_PERF_PMMSYS_PWR0_SIGVAL_PMA_TRIGGER, GM10X_NV_PERF_PMMSYS_SYS0_SIGVAL_PMA_TRIGGER, GM10X_NV_PERF_PMMSYS_XBAR0_SIGVAL_PMA_TRIGGER},
        {GM10X_NV_PERF_PMMGPC_GPC0_SIGVAL_PMA_TRIGGER, GM10X_NV_PERF_PMMGPC_GPCTPC0_SIGVAL_PMA_TRIGGER},
        {GM10X_NV_PERF_PMMFBP_FBP0_SIGVAL_PMA_TRIGGER, GM10X_NV_PERF_PMMFBP_LTC0_SIGVAL_PMA_TRIGGER, GM10X_NV_PERF_PMMFBP_LTC1_SIGVAL_PMA_TRIGGER, GM10X_NV_PERF_PMMFBP_ROP0_SIGVAL_PMA_TRIGGER}
    };

#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200
    static const NvU32 nvgm200_pma_trigger[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        //#defines taken from pm_signals.h
        {GM20X_NV_PERF_PMMSYS_HOST0_SIGVAL_PMA_TRIGGER, GM20X_NV_PERF_PMMSYS_MSD0_SIGVAL_PMA_TRIGGER, GM20X_NV_PERF_PMMSYS_MSD1_SIGVAL_PMA_TRIGGER, GM20X_NV_PERF_PMMSYS_PCIE0_SIGVAL_PMA_TRIGGER, GM20X_NV_PERF_PMMSYS_PWR0_SIGVAL_PMA_TRIGGER, GM20X_NV_PERF_PMMSYS_SYS0_SIGVAL_PMA_TRIGGER, GM20X_NV_PERF_PMMSYS_XBAR0_SIGVAL_PMA_TRIGGER},
        {GM20X_NV_PERF_PMMGPC_GPC0_SIGVAL_PMA_TRIGGER, GM20X_NV_PERF_PMMGPC_GPCTPC0_SIGVAL_PMA_TRIGGER},
        {GM20X_NV_PERF_PMMFBP_FBP0_SIGVAL_PMA_TRIGGER, GM20X_NV_PERF_PMMFBP_LTC0_SIGVAL_PMA_TRIGGER, GM20X_NV_PERF_PMMFBP_LTC1_SIGVAL_PMA_TRIGGER, GM20X_NV_PERF_PMMFBP_ROP0_SIGVAL_PMA_TRIGGER, GM20X_NV_PERF_PMMFBP_ROP1_SIGVAL_PMA_TRIGGER}
    };
#endif

#if NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
    static const NvU32 nvgm20y_pma_trigger[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        //#defines taken from pm_signals.h
        {GM20Y_NV_PERF_PMMSYS_ACB0_SIGVAL_PMA_TRIGGER, GM20Y_NV_PERF_PMMSYS_MC0_SIGVAL_PMA_TRIGGER, GM20Y_NV_PERF_PMMSYS_PWR0_SIGVAL_PMA_TRIGGER, GM20Y_NV_PERF_PMMSYS_SYS0_SIGVAL_PMA_TRIGGER},
        {GM20Y_NV_PERF_PMMGPC_GPC0_SIGVAL_PMA_TRIGGER, GM20Y_NV_PERF_PMMGPC_GPCTPC0_SIGVAL_PMA_TRIGGER},
        {GM20Y_NV_PERF_PMMFBP_FBP0_SIGVAL_PMA_TRIGGER}
    };
#endif // NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)

    if (chipletType >= PM_MAX_CHIPLET_TYPES || clkIdx >= PM_MAX_DOMAIN_PER_CHIPLET) {
        CU_ERROR_PRINT(("Invalid chiplet/clk values\n"));
        CU_ASSERT (0);
        return numericId;
    }

    CU_TRACE_FUNCTION();

    switch(ctx->device->state.chip) {
#if NVCFG(GLOBAL_ARCH_MAXWELL)
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM000 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM107:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM000 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM108:
        signalNames = nvgm000_pma_trigger;
        break;
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM204:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM206:
        signalNames = nvgm200_pma_trigger;
        break;
#endif // NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200
#endif // NVCFG(GLOBAL_ARCH_MAXWELL)
#if NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM20B:
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM21B
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM21B:
#endif // NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM21B
        signalNames = nvgm20y_pma_trigger;
        break;
#endif // NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
    default:
        CU_ASSERT(0);
        break;
    }

    if (signalNames) {
        numericId = signalNames[chipletType][clkIdx];
    }
    else {
        CU_ASSERT(0); // Throw assert if signal names is NULL
    }

    return numericId;
}

static CUprofResult AssertEngineModeB(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *value = NULL;
    NvU32 j = 0, size = 0, pmaTriggerSignalIndex = ~0U;
    NvU32 domainRegOffset = 0, chipIdx = 0;
    CUparsedClk  *pParsedClk = NULL;
    CUmaxwellEventGroup  *maxwellEventGroup;

    CU_TRACE_FUNCTION();

    //For PM signals
    pParsedClk = pEventGroup->arch.maxwellEventGroup->pParsedClk;
    maxwellEventGroup = pEventGroup->arch.maxwellEventGroup;

    CU_ASSERT(pParsedClk);
    CU_ASSERT(maxwellEventGroup);

    size = maxwellEventGroup->maxChiplets * sizeof(NvU32);

    offset = (NvU32*)malloc(size);
    value = (NvU32*)malloc(size);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset/value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    // assert ENGINE
    // set register NV_PERF_PMM[chipletType]_ENGINE_SEL(domain) to NV_PERF_PMM[chipletType]_[domain]_SIGVAL_PMA_TRIGGER
    // for all instances of all chipletTypes
    // like for (GPC#0 + domain GPC0) - NV_PERF_PMMGPC_ENGINE_SEL(MAXWELL_CLK_DOMAIN_GPC0) = NV_PERF_PMMGPC_GPC0_SIGVAL_PMA_TRIGGER

    for (chipIdx = 0; chipIdx < maxwellEventGroup->maxChiplets; chipIdx++) {
        if(maxwellEventGroup->pmUnitMask & (1<<chipIdx))
        {
            domainRegOffset = maxwellEventGroup->pmmAddress[chipIdx] + maxwellEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
            offset[j]  = domainRegOffset + NV_PMM_ENGINE_SEL;
            // lookup the numeric value for the signal
            //TBD, check how we can put this in the domain table and get rid of resolveCoreSignalName function
            //TBD Since gpctpc0 and gpctpc1 are identical, we can safely call this function with gpctpc0 domain name only.

            if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING) {
                pmaTriggerSignalIndex = resolveTPulse(pEventGroup->pCtx, maxwellEventGroup->clkIdx, pEventGroup->domain->chipletType);
            } else
            {
                pmaTriggerSignalIndex = resolveCoreSignalName(pEventGroup->pCtx, maxwellEventGroup->clkIdx, pEventGroup->domain->chipletType);
            }
            CU_ASSERT(pmaTriggerSignalIndex != ~0U);
            value[j++] = pmaTriggerSignalIndex;
        }
    }

    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, j, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

EXIT:
    free (offset);
    free (value);

    return status;
}

static CUprofResult StartExptModeB(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
#if 1
    NvU32 *offset = NULL, *value = NULL;
    NvU32 j = 0, size = 0;
    NvU32 domainRegOffset = 0, chipIdx = 0;
    CUmaxwellEventGroup  *maxwellEventGroup;

    CU_TRACE_FUNCTION();
    //For PM signals
    maxwellEventGroup = pEventGroup->arch.maxwellEventGroup;

    CU_ASSERT(maxwellEventGroup);

    size = maxwellEventGroup->maxChiplets * sizeof(NvU32);

    offset = (NvU32*)malloc(size);
    value = (NvU32*)malloc(size);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset/value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    // assert ENGINE
    // set register NV_PERF_PMM[chipletType]_ENGINE_SEL(domain) to NV_PERF_PMM[chipletType]_[domain]_SIGVAL_PMA_TRIGGER
    // for all instances of all chipletTypes
    // like for (GPC#0 + domain GPC0) - NV_PERF_PMMGPC_ENGINE_SEL(MAXWELL_CLK_DOMAIN_GPC0) = NV_PERF_PMMGPC_GPC0_SIGVAL_PMA_TRIGGER

    for (chipIdx = 0; chipIdx < maxwellEventGroup->maxChiplets; chipIdx++) {
        if(maxwellEventGroup->pmUnitMask & (1<<chipIdx))
        {
            domainRegOffset = maxwellEventGroup->pmmAddress[chipIdx] + maxwellEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
            offset[j]  = domainRegOffset + NV_PERF_PMM_STARTEXPERIMENT;
            value[j++] = NV_PERF_PMM_STARTEXPERIMENT_START_DOIT;
        }
    }

    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, j, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

EXIT:
    free (offset);
    free (value);
#endif
    return status;
}

static CUprofResult startStreaming(CUctx *ctx) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *value = NULL;
    NvU32 j = 0, size = 0;

    CU_TRACE_FUNCTION();

    size = sizeof(NvU32) * 16;

    //If we require to setup only one register here, remove malloc
    offset = (NvU32*)malloc(size);
    value = (NvU32*)calloc(size, 1);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset/value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    // assert ENGINE
    // set register NV_PERF_PMM[chipletType]_ENGINE_SEL(domain) to NV_PERF_PMM[chipletType]_[domain]_SIGVAL_PMA_TRIGGER
    // for all instances of all chipletTypes
    // like for (GPC#0 + domain GPC0) - NV_PERF_PMMGPC_ENGINE_SEL(KEPLER_CLK_DOMAIN_GPC0) = NV_PERF_PMMGPC_GPC0_SIGVAL_PMA_TRIGGER
    j = 0;
    offset[j++] = NV_PERF_PMASYS_MEM_BYTES;

    if (CUDA_SUCCESS != PRIREAD32(ctx, CU_PRI_REG_GLOBAL, j, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

    //The bytes read from the buffer at the time of startStreaming should be 0
    //In case of non-0, we will need to read from cpuAddrStreamingBuffer + values[0]
    //which is not supported in the code. This means that you have to take care of
    //disabling mode E at the time of stop streaming.
    //CU_ASSERT(value[0] == 0);
#ifdef ENABLE_SAMPLING_PRINTS
    printf("**** buffer contains data from previous runs %d bytes ***\n", value[0]);
#endif
    //Write value read from mem_bytes to mem_bump
    j = 0;
    offset[j++] = NV_PERF_PMASYS_MEM_BUMP;

    if (CUDA_SUCCESS != PRIWRITE32(ctx, CU_PRI_REG_GLOBAL, j, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

    if (ctx->pmNew->cpuAddrStreamingBuffer) {
        j = 0;
        offset[j]  = NV_PERF_PMASYS_OUTBASE;
        value[j++] = ctx->pmNew->gpuAddrStreamingBuffer & 0xFFFFFFFF;

        offset[j]  = NV_PERF_PMASYS_OUTBASEUPPER;
        value[j++] = (ctx->pmNew->gpuAddrStreamingBuffer >> 32) & 0xff;

        offset[j]  = NV_PERF_PMASYS_OUTSIZE;
        value[j++] = (NvU32)ctx->pmNew->sizeStreamingBuffer;

        offset[j]  = NV_PERF_PMASYS_CONTROL;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_CONTROL_STREAM_ENABLE, NV_PERF_PMASYS_CONTROL_STREAM);
        if (ctx->pmNew->isPmCtxswModeEnabled)
            value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_CONTROL_PMACTXSW_MODE_ENABLE, NV_PERF_PMASYS_CONTROL_PMACTXSW_MODE);
        else
            value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_CONTROL_PMACTXSW_MODE_DISABLE, NV_PERF_PMASYS_CONTROL_PMACTXSW_MODE);
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_CONTROL_MEMBUF_CLEAR_STATUS_DOIT, NV_PERF_PMASYS_CONTROL_MEMBUF_CLEAR_STATUS);
        j++;
#if 0
        offset[j]  = NV_PERF_PMASYS_MEM_BLOCK;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_MEM_BLOCK_VALID_TRUE, NV_PERF_PMASYS_MEM_BLOCK_VALID);
        j++;

        offset[j]  = NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
        j++;
        // Set HOLD_* to TRUE
        offset[j]  = NV_PERF_PMMGPCROUTER_GLOBAL_CNTRL;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
        j++;

        offset[j]  = NV_PERF_PMMFBPROUTER_GLOBAL_CNTRL;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
        j++;
        //Then set HOLD_* to FALSE
        offset[j]  = NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_FALSE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_FALSE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
        j++;

        offset[j]  = NV_PERF_PMMGPCROUTER_GLOBAL_CNTRL;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_FALSE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_FALSE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
        j++;

        offset[j]  = NV_PERF_PMMFBPROUTER_GLOBAL_CNTRL;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_FALSE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_FALSE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
        j++;
#endif

        //Remember to add following so that we don't miss any records
        //If MEM_BYTES = sysmem(NV_PERF_PMA_MEM_BYTES_ADDR), then there are no records
        //  in flight between PMA and system memory.

        //NvU32 uNumBytes = 0;
        //ReadRegister32(NV_PERF_PMASYS_MEM_BYTES, &uNumBytes);
        //WriteRegister32(NV_PERF_PMASYS_MEM_BUMP, 0x00000000, uNumBytes);
        if (CUDA_SUCCESS != PRIWRITE32(ctx, ctx->pmNew->regOpType, j, offset, value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }
    }

EXIT:
    free (offset);
    free (value);
    return status;
}

static CUprofResult stopStreaming(CUctx *ctx) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *value = NULL;
    NvU32 j = 0, size = 0;
#if 0
    NvU32 domainRegOffset = 0, chipIdx = 0;
    CUmaxwellEventGroup  *maxwellEventGroup;
#endif

    CU_TRACE_FUNCTION();

   size = sizeof(NvU32) * 4;

    //If we require to setup only one register here, remove malloc
    offset = (NvU32*)malloc(size);
    value = (NvU32*)malloc(size);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset/value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    // assert ENGINE
    // set register NV_PERF_PMM[chipletType]_ENGINE_SEL(domain) to NV_PERF_PMM[chipletType]_[domain]_SIGVAL_PMA_TRIGGER
    // for all instances of all chipletTypes
    // like for (GPC#0 + domain GPC0) - NV_PERF_PMMGPC_ENGINE_SEL(KEPLER_CLK_DOMAIN_GPC0) = NV_PERF_PMMGPC_GPC0_SIGVAL_PMA_TRIGGER

    offset[j]  = NV_PERF_PMASYS_CONTROL;
    value[j] = 0;
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_CONTROL_STREAM_DISABLE, NV_PERF_PMASYS_CONTROL_STREAM);
    if (ctx->pmNew->isPmCtxswModeEnabled)
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_CONTROL_PMACTXSW_MODE_ENABLE, NV_PERF_PMASYS_CONTROL_PMACTXSW_MODE);
    else
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_CONTROL_PMACTXSW_MODE_DISABLE, NV_PERF_PMASYS_CONTROL_PMACTXSW_MODE);
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_CONTROL_MEMBUF_CLEAR_STATUS_DOIT, NV_PERF_PMASYS_CONTROL_MEMBUF_CLEAR_STATUS);
    j++;
/*
    offset[j]  = NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL;
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
    j++;
    // Set HOLD_* to TRUE
    offset[j]  = NV_PERF_PMMGPCROUTER_GLOBAL_CNTRL;
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
    j++;

    offset[j]  = NV_PERF_PMMFBPROUTER_GLOBAL_CNTRL;
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
    j++;
*/
    if (CUDA_SUCCESS != PRIWRITE32(ctx, ctx->pmNew->regOpType, j, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }
#if 0
    maxwellEventGroup = pEventGroup->arch.maxwellEventGroup;

    if(!maxwellEventGroup)
        return CUPROF_ERROR_UNKNOWN; //TBD check if we can return this error.

    for (chipIdx = 0; chipIdx < maxwellEventGroup->maxChiplets; chipIdx++) {
        if(maxwellEventGroup->pmUnitMask & (1<<chipIdx))
        {
            if (maxwellEventGroup->pParsedClk && pEventGroup->totalCounters) {
                domainRegOffset = maxwellEventGroup->pmmAddress[chipIdx] + maxwellEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
                offset[0]  = domainRegOffset + NV_PMM_CONTROL;
                value[0] = (NV_PMM_CONTROL_MODE_DISABLE        << NV_PMM_CONTROL_MODE__SHIFT);

                if (CUDA_SUCCESS != PRIWRITE32(ctx, CU_PRI_REG_GLOBAL, 1, offset, value, 0)) {
                    status = CUPROF_ERROR_HARDWARE;
                    goto EXIT;
                }
            }
        }
    }

    for (chipIdx = 0; chipIdx < maxwellEventGroup->maxChiplets; chipIdx++) {
        if(maxwellEventGroup->pmUnitMask & (1<<chipIdx))
        {
            if (maxwellEventGroup->pParsedClk && pEventGroup->totalCounters) {
                domainRegOffset = maxwellEventGroup->pmmAddress[chipIdx] + maxwellEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
                offset[0]  = domainRegOffset + NV_PMM_ENGINESTATUS;
READ_STATUS:
                if (CUDA_SUCCESS != PRIREAD32(ctx, CU_PRI_REG_GLOBAL, 1, offset, value, 0)) {
                    status = CUPROF_ERROR_HARDWARE;
                    goto EXIT;
                }
                if ((value[0] & 0x7) == NV_PERF_PMMSYS_ENGINESTATUS_STATUS_ACTIVE) {
                    printf("Engine not empty\n");
                    goto READ_STATUS;
                } else {
                    if ((value[0] & 0x7) == NV_PERF_PMMSYS_ENGINESTATUS_STATUS_FAULTED) {
                        CU_ERROR_PRINT(("PMM Engine status faulted\n"));
                    }
                    continue;
                }
            }
        }
    }

    do {
        offset[0]  = NV_PERF_PMMSYSROUTER_ENGINESTATUS;
        offset[1]  = NV_PERF_PMMGPCROUTER_ENGINESTATUS;
        offset[2]  = NV_PERF_PMMFBPROUTER_ENGINESTATUS;
        value[0] = value[1] = value[2] = 0;

        if (CUDA_SUCCESS != PRIREAD32(ctx, CU_PRI_REG_GLOBAL, 3, offset, value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }

        if (((value[0] & 0x7) == 0) && ((value[1] & 0x7) == 0) && ((value[2] & 0x7) == 0)) {
            break;
        }

        printf("Engine status %d %d %d\n", (value[0] & 0x7), (value[1] & 0x7), (value[2] & 0x7));

        if (((value[0] & 0x7) == NV_PERF_PMMSYSROUTER_ENGINESTATUS_STATUS_FAULTED) &&
            ((value[1] & 0x7) == NV_PERF_PMMGPCROUTER_ENGINESTATUS_STATUS_FAULTED) &&
            ((value[2] & 0x7) == NV_PERF_PMMFBPROUTER_ENGINESTATUS_STATUS_FAULTED)) {
            CU_ERROR_PRINT(("PMM Engine status faulted\n"));
            break;
        }

        //printf("Reading status again for routers\n");
    } while(1);

    offset[0]  = NV_PERF_PMASYS_ENGINESTATUS;
    value[0] = 0;

    if (CUDA_SUCCESS != PRIREAD32(ctx, CU_PRI_REG_GLOBAL, 1, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

    if ((value[0] & 0x7) == NV_PERF_PMASYS_ENGINESTATUS_STATUS_FAULTED) {
        printf("PMA engine status faulted.\n");
        CU_ASSERT(0);
    }

    if ((value[0] & 0x7) == NV_PERF_PMASYS_ENGINESTATUS_STATUS_FAULTED) {
        printf("PMA engine succesfully stopped.\n");
    }
#endif

EXIT:
    free (offset);
    free (value);
    return status;
}

CUprofResult maxwellPerfmonEventGroupResetAllEvents(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);
    CU_ASSERT(pEventGroup->pCtx);


    switch(pEventGroup->domain->eventCollectionMethod)
    {
    case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
    case CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX:
        // if event group is enabled, trigger the PM  Otherwise it would have been
        // done in disable event group call
        if (pEventGroup->isEnabled) {
            //status = AssertEngineModeB(pEventGroup);
            status = StartExptModeB(pEventGroup);
        }

        if (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX) {
            if(status != CUPROF_SUCCESS) {
                return status;
            }
            if (pEventGroup->isEnabled) {
                status = (CUprofResult)resetPMSMInternal(pEventGroup);
            }
        }
        break;

    case CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
        // configure PM target and SM internal registers
        if (pEventGroup->isEnabled) {
            status = (CUprofResult)resetPMSMInternal(pEventGroup);
        }
        break;

    default:
        break;
    }

    // now reset all values for the event group
    cuosMemset(pEventGroup->values, 0, sizeof(NvU64) * pEventGroup->totalCounters
        * pEventGroup->instanceCountAvail);

    return status;
}

static NV_INLINE NvBool maxwellIsPpaSoftwareCounterDomain(CUeventDomainID domainId, NvU64 arch) {

    if(domainId == MAXWELL_SW_DOMAIN_PPA_NOPTRIG_SHARED_LOAD_STORE || 
        domainId == MAXWELL_SW_DOMAIN_PPA_NOPTRIG_UNIQUE_GLD_GST ||
        domainId == MAXWELL_SW_DOMAIN_PPA_NOPTRIG_UNIQUE_SECTOR_ACCESS_GLD) {
        return NV_TRUE;
    }

    switch(arch){
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM000 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM107:
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM000 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM108:
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200:
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM204:
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM206:
#endif // NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200
#if NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM20B:
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM21B
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM21B:
#endif // NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM21B
#endif // NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
            {
                if((domainId == MAXWELL_SW_DOMAIN_PPA_NOPTRIG_FLOPS) ||
                    (domainId == MAXWELL_SW_DOMAIN_PPA_NOPTRIG_GLOBAL_LOAD_STORE) ||
                    (domainId == MAXWELL_SW_DOMAIN_PPA_NOPTRIG_INSTR_CLASS) ||
                    (domainId == MAXWELL_SW_DOMAIN_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS)) {
                    return NV_TRUE;
                }
            }
            break;
        default:
            return NV_FALSE;
    }
    return NV_FALSE;
}

static NV_INLINE NvBool maxwellIsDeviceLevelCounterDomain(CUeventDomainID domainId) {
    if((domainId == MAXWELL_CLK_DOMAIN_GM000_PCIE0) ||
       (domainId == MAXWELL_CLK_DOMAIN_GM200_PCIE0)) {
        return NV_TRUE;
    }

    return NV_FALSE;
}

CUprofResult maxwellPerfmonDomainCheckCompatible(CUctx *ctx,
                                                 CUeventDomainID domainId1,
                                                 CUeventDomainID domainId2,
                                                 NvBool *bCompatible) {
    CUprofResult status = CUPROF_SUCCESS;
    CU_TRACE_FUNCTION();

    *bCompatible = NV_TRUE;

    // Allow device level counter domains only with same or other device level counter domain only
    if ((maxwellIsDeviceLevelCounterDomain(domainId1) && !maxwellIsDeviceLevelCounterDomain(domainId2)) ||
        (maxwellIsDeviceLevelCounterDomain(domainId2) && !maxwellIsDeviceLevelCounterDomain(domainId1))) {
            *bCompatible = NV_FALSE;
            return status;
    }

    //The ppaSwCounter domains are not compatible with each other:
    if (maxwellIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip) &&
        maxwellIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip)) {
        if(domainId1 == domainId2) {
            *bCompatible = NV_TRUE;
        }
        else {
            *bCompatible = NV_FALSE;
        }
        return status;
    }
    // Bug 874703: Mix of signals from SM domain + GPCTPC domain is not working properly
    // Hence updating the DomainCheckCompatible function to avoid profiling these signals together.
    switch(ctx->device->state.chip){
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM000 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM107:
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM000 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM108:
            {
                //HWPMMux is not allowed with SMPC or HWPM signals.
                if (((MAXWELL_CLK_DOMAIN_GM000_HWPMMUX == domainId2) &&
                    (MAXWELL_CLK_DOMAIN_GM000_GPCTPC == domainId1)) ||
                    ((MAXWELL_CLK_DOMAIN_GM000_HWPMMUX == domainId1) &&
                    (MAXWELL_CLK_DOMAIN_GM000_GPCTPC == domainId2))) {
                        *bCompatible = NV_FALSE;
                        return status;
                }
                if (((MAXWELL_CLK_DOMAIN_GM000_HWPMMUX == domainId2) &&
                    (MAXWELL_CLK_DOMAIN_GM000_SM0 == domainId1)) ||
                    ((MAXWELL_CLK_DOMAIN_GM000_HWPMMUX == domainId1) &&
                    (MAXWELL_CLK_DOMAIN_GM000_SM0 == domainId2))) {
                        *bCompatible = NV_FALSE;
                        return status;
                }

                if (((domainId1 == MAXWELL_CLK_DOMAIN_GM000_GPCTPC) ||
                    (domainId1 == MAXWELL_CLK_DOMAIN_GM000_SM0) ||
                    (domainId1 == MAXWELL_CLK_DOMAIN_GM000_FBP0) ||
                    (domainId1 == MAXWELL_CLK_DOMAIN_GM000_LTC0) ||
                    (domainId1 == MAXWELL_CLK_DOMAIN_GM000_LTC1) ||
                    (domainId1 == MAXWELL_CLK_DOMAIN_GM000_HWPMMUX) ||
                    (domainId1 == MAXWELL_CLK_DOMAIN_GM000_GPC0) ||
                     (domainId1 == MAXWELL_CLK_DOMAIN_GM000_SYS0)) &&
                    (maxwellIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip))) {
                        *bCompatible = NV_FALSE;
                        return status;
                }

                if (((domainId2 == MAXWELL_CLK_DOMAIN_GM000_GPCTPC) ||
                    (domainId2 == MAXWELL_CLK_DOMAIN_GM000_SM0) ||
                    (domainId2 == MAXWELL_CLK_DOMAIN_GM000_FBP0) ||
                    (domainId2 == MAXWELL_CLK_DOMAIN_GM000_LTC0) ||
                    (domainId2 == MAXWELL_CLK_DOMAIN_GM000_LTC1) ||
                    (domainId2 == MAXWELL_CLK_DOMAIN_GM000_HWPMMUX) ||
                    (domainId2 == MAXWELL_CLK_DOMAIN_GM000_GPC0) ||
                     (domainId2 == MAXWELL_CLK_DOMAIN_GM000_SYS0)) &&
                    (maxwellIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip))) {
                        *bCompatible = NV_FALSE;
                        return status;
                }
            }
            break;
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200:
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM204:
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM206:
            {
                //HWPMMux is not allowed with SMPC or HWPM signals.
                if (((MAXWELL_CLK_DOMAIN_GM200_HWPMMUX == domainId2) &&
                    (MAXWELL_CLK_DOMAIN_GM200_GPCTPC == domainId1)) ||
                    ((MAXWELL_CLK_DOMAIN_GM200_HWPMMUX == domainId1) &&
                    (MAXWELL_CLK_DOMAIN_GM200_GPCTPC == domainId2))) {
                        *bCompatible = NV_FALSE;
                        return status;
                }
                if (((MAXWELL_CLK_DOMAIN_GM200_HWPMMUX == domainId2) &&
                    (MAXWELL_CLK_DOMAIN_GM200_SM0 == domainId1)) ||
                    ((MAXWELL_CLK_DOMAIN_GM200_HWPMMUX == domainId1) &&
                    (MAXWELL_CLK_DOMAIN_GM200_SM0 == domainId2))) {
                        *bCompatible = NV_FALSE;
                        return status;
                }

                if (((domainId1 == MAXWELL_CLK_DOMAIN_GM200_GPCTPC) ||
                    (domainId1 == MAXWELL_CLK_DOMAIN_GM200_SM0) ||
                    (domainId1 == MAXWELL_CLK_DOMAIN_GM000_FBP0) ||
                    (domainId1 == MAXWELL_CLK_DOMAIN_GM200_LTC0) ||
                    (domainId1 == MAXWELL_CLK_DOMAIN_GM200_LTC1) ||
                    (domainId1 == MAXWELL_CLK_DOMAIN_GM200_HWPMMUX) ||
                    (domainId1 == MAXWELL_CLK_DOMAIN_GM000_GPC0) ||
                     (domainId1 == MAXWELL_CLK_DOMAIN_GM200_SYS0)) &&
                    (maxwellIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip))) {
                        *bCompatible = NV_FALSE;
                        return status;
                }

                if (((domainId2 == MAXWELL_CLK_DOMAIN_GM200_GPCTPC) ||
                    (domainId2 == MAXWELL_CLK_DOMAIN_GM200_SM0) ||
                    (domainId2 == MAXWELL_CLK_DOMAIN_GM000_FBP0) ||
                    (domainId2 == MAXWELL_CLK_DOMAIN_GM200_LTC0) ||
                    (domainId2 == MAXWELL_CLK_DOMAIN_GM200_LTC1) ||
                    (domainId2 == MAXWELL_CLK_DOMAIN_GM200_HWPMMUX) ||
                    (domainId2 == MAXWELL_CLK_DOMAIN_GM000_GPC0) ||
                     (domainId2 == MAXWELL_CLK_DOMAIN_GM200_SYS0)) &&
                    (maxwellIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip))) {
                        *bCompatible = NV_FALSE;
                        return status;
                }
            }
            break;
#endif
#if NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM20B:
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM21B
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM21B:
#endif // NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM21B
            {
                //HWPMMux is not allowed with SMPC or HWPM signals.
                if (((MAXWELL_CLK_DOMAIN_GM20Y_HWPMMUX == domainId2) &&
                    (MAXWELL_CLK_DOMAIN_GM20Y_GPCTPC == domainId1)) ||
                    ((MAXWELL_CLK_DOMAIN_GM20Y_HWPMMUX == domainId1) &&
                    (MAXWELL_CLK_DOMAIN_GM20Y_GPCTPC == domainId2))) {
                        *bCompatible = NV_FALSE;
                        return status;
                }
                if (((MAXWELL_CLK_DOMAIN_GM20Y_HWPMMUX == domainId2) &&
                    (MAXWELL_CLK_DOMAIN_GM20Y_SM0 == domainId1)) ||
                    ((MAXWELL_CLK_DOMAIN_GM20Y_HWPMMUX == domainId1) &&
                    (MAXWELL_CLK_DOMAIN_GM20Y_SM0 == domainId2))) {
                        *bCompatible = NV_FALSE;
                        return status;
                }

                if (((domainId1 == MAXWELL_CLK_DOMAIN_GM20Y_GPCTPC) ||
                    (domainId1 == MAXWELL_CLK_DOMAIN_GM20Y_SM0) ||
                    (domainId1 == MAXWELL_CLK_DOMAIN_GM20Y_FBP0) ||
                    (domainId1 == MAXWELL_CLK_DOMAIN_GM20Y_HWPMMUX) ||
                    (domainId1 == MAXWELL_CLK_DOMAIN_GM20Y_GPC0) ||
                     (domainId1 == MAXWELL_CLK_DOMAIN_GM20Y_SYS0)) &&
                    (maxwellIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip))) {
                        *bCompatible = NV_FALSE;
                        return status;
                }

                if (((domainId2 == MAXWELL_CLK_DOMAIN_GM20Y_GPCTPC) ||
                    (domainId2 == MAXWELL_CLK_DOMAIN_GM20Y_SM0) ||
                    (domainId2 == MAXWELL_CLK_DOMAIN_GM20Y_FBP0) ||
                    (domainId2 == MAXWELL_CLK_DOMAIN_GM20Y_HWPMMUX) ||
                    (domainId2 == MAXWELL_CLK_DOMAIN_GM20Y_GPC0) ||
                     (domainId2 == MAXWELL_CLK_DOMAIN_GM20Y_SYS0)) &&
                    (maxwellIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip))) {
                        *bCompatible = NV_FALSE;
                        return status;
                }
            }
            break;
#endif // NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
        default:
            CU_ASSERT(0);
            *bCompatible = NV_FALSE;  // Default case should never be encountered
            break;
    }
    return status;
}

// Function to check if domain is already enabled for profiling
static CUprofResult maxwellDomainCompatible(CUctx *ctx, CUeventDomainID domainId, NvBool *bCompatible) {
    CUprofResult status = CUPROF_SUCCESS;
    CUeventGroup *currEg = NULL;
    void *eventBase = NULL;
    NvU32 i = 0;

    CU_TRACE_FUNCTION();

    *bCompatible = NV_TRUE;

    currEg = (CUeventGroup*)listGetNext(ctx->pmNew->egList, &eventBase);
    for (i = 0; (i < ctx->pmNew->totalEventGroups) && currEg; i++, currEg = (CUeventGroup*)listGetNext(NULL, &eventBase)) {

        if (currEg->isEnabled) {
            //cannot enable 2 eventgroups from same domain simultaneously
            if (currEg->domainId == domainId) {
                *bCompatible = NV_FALSE;
            }
            else {
                maxwellPerfmonDomainCheckCompatible(ctx, domainId, currEg->domainId, bCompatible);
            }
            if (*bCompatible == NV_FALSE) {
                break;
            }
        }
    }

    return status;
}

CUprofResult maxwellPerfmonEventGroupEnable(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    CUctx *ctx = NULL;
    NvBool bCompatible = NV_TRUE;
    CUmaxwellEventGroup  *maxwellEventGroup;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);
    //CU_ASSERT(pEventGroup->domainId < MAX_DOMAINS);

    ctx = pEventGroup->pCtx;
    // make launch blocking
    //ctx->launchBlocking = 1;

    status = maxwellDomainCompatible(ctx, pEventGroup->domainId, &bCompatible);
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("Failed to check domain enable/disable status\n"));
        return status;
    }
    if (bCompatible == NV_FALSE) {
        CU_ERROR_PRINT(("Profiler allows to monitor only one event group from any domain\n"));
        return CUPROF_ERROR_NOT_COMPATIBLE;
    }

    // If new driver and old CUPTI, pEventGroup->eventGroupScope will be CU_EVENT_GROUP_SCOPE_FORCE_INT.
    // This will handle backward compatibility.
    if (pEventGroup->eventGroupScope == CU_EVENT_GROUP_SCOPE_FORCE_INT) {
        if (!maxwellIsDeviceLevelCounterDomain(pEventGroup->domainId)) {
            /********************************************************************************
               Set the PM CtxSw bit here as we want this feature for SM_PM_CTRL registers
                   as well which are used in SMPC signal profiling:
               Currently, the feature is only supported on GK110
            ********************************************************************************/
            status = perfmonSetupPMCtxswMode(ctx, NV_TRUE);
        } else {
            status = perfmonSetupPMCtxswMode(ctx, NV_FALSE);
        }
    }
    else {
        if (pEventGroup->eventGroupScope == CU_EVENT_GROUP_SCOPE_DEVICE) {

            status = perfmonSetupPMCtxswMode(ctx, NV_FALSE);
        } else {
            /********************************************************************************
                Set the PM CtxSw bit here as we want this feature for SM_PM_CTRL registers
                    as well which are used in SMPC signal profiling:
            ********************************************************************************/
            status = perfmonSetupPMCtxswMode(ctx, NV_TRUE);
        }
    }

        if (CUPROF_SUCCESS != status) {
            CU_ERROR_PRINT(("Failed to set the PM Ctxsw bit\n"));
            goto Error;
        }

    // Check if the PM CtxSw bit is enabled and assign the proper regOp type:
    pEventGroup->pCtx->pmNew->regOpType = ctx->pmNew->isPmCtxswModeEnabled ? CU_PRI_REG_CONTEXT : CU_PRI_REG_GLOBAL;

    switch(pEventGroup->domain->eventCollectionMethod)
    {
    case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
    case CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX:
        maxwellEventGroup = pEventGroup->arch.maxwellEventGroup;
        CU_ASSERT(maxwellEventGroup);
        status = setupPMTarget(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            goto Error;
        }

        if (pEventGroup->configChanged) {
            // configure PM target and mode B settings
            status = setupPMRegistersModeCommon(pEventGroup,
                &pEventGroup->pCtx->pmNew->perfmonTriggerRefCount);
            if (CUPROF_SUCCESS != status) {
                goto Error;
            }

            status = setupPMRegistersModeB(pEventGroup);
            if (CUPROF_SUCCESS != status) {
                goto Error;
            }
        }
        status = setPMEnableReg(pEventGroup, NV_TRUE);
        if (CUPROF_SUCCESS != status) {
            goto Error;
        }
#ifndef BUG_1259185_FIXED
        if (ctx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING) {
            status = setupStreamingResources(ctx);
            if (status != CUPROF_SUCCESS) {
                cleanupStreamingResources(ctx);
                CU_ERROR_PRINT(("Failed to setup streaming resources\n"));
                goto Error;
            }
        }
#endif
        status = AssertEngineModeB(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            //Release Mode B in case Assert fail.
            PMReleaseModeB(pEventGroup);
            goto Error;
        }


        if (ctx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING) {
            status = startStreaming(pEventGroup->pCtx);
            if (CUPROF_SUCCESS != status) {
                goto Error;
            }
        }

        if ((ctx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS) ||
            (ctx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING)) {
            status = StartExptModeB(pEventGroup);
            if (CUPROF_SUCCESS != status) {
                goto Error;
            }
        }

        if (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX) {
            //setupPMTarget is already done, so avoid it
            //while configuring SMPC
            status = (CUprofResult)SetupPMRegistersSMInternal(pEventGroup);
            if (CUPROF_SUCCESS != status) {
                goto Error;
            }

            status = (CUprofResult)resetPMSMInternal(pEventGroup);
            if (CUPROF_SUCCESS != status) {
                goto Error;
            }

            if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS){
                maxwellPerfmonStartCounters(NULL, pEventGroup);
                status = (CUprofResult)resetPMSMInternal(pEventGroup);
                if (CUPROF_SUCCESS != status) {
                    goto Error;
                }
            }
        }

        break;

    case CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
        status = setupPMTarget(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            goto Error;
        }

        if (pEventGroup->configChanged) {
            // configure PM target and SM internal registers
            status = (CUprofResult)SetupPMRegistersSMInternal(pEventGroup);
            if (CUPROF_SUCCESS != status) {
                goto Error;
            }
        }

        status = (CUprofResult)setPMEnableRegSM(pEventGroup, NV_TRUE);
        if (CUPROF_SUCCESS != status) {
            goto Error;
        }

        if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS) {
            maxwellPerfmonStartCounters(NULL, pEventGroup);
            status = (CUprofResult)resetPMSMInternal(pEventGroup);
            if (CUPROF_SUCCESS != status) {
                goto Error;
            }
        }


        break;

    default:
        //s/w counters do nothing
        break;
    }


    // set enable flags
    pEventGroup->isEnabled = 1;
    setDomainEventGroup(ctx->pmNew->domainEventGroupEnabled, pEventGroup->domainId, 1);

    // reset all counters
    cuosMemset(pEventGroup->values, 0, sizeof(NvU64) * pEventGroup->totalCounters
        * pEventGroup->instanceCountAvail);

    return CUPROF_SUCCESS;

    //release HWPM in case any call fails after perfmonControlHWPM
Error:
#ifndef BUG_1259185_FIXED
    cleanupStreamingResources(ctx);
#endif
    return status;
}

static CUprofResult logPMCountersModeBStreamingMode(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *values = NULL, *currPosInValueArray = NULL;
    NvU32 size = 0;
    NvU32 chipIdx = 0, i = 0, j = 0;
    CUmaxwellEventGroup  *maxwellEventGroup;
    CUparsedClk *pTempParsedClk = NULL;
    NvU32 memHeadPtr = 0, totalBytes = 0; //memBytes = 0
    NvU32 chipletType, clkIdx;
    CUprofStreamingRecord *recPtr;
#ifdef PRINT_EVENT_SAMPLING_RECORDS
    FILE *tempfp;
    char filename[CUOS_ENV_VAR_LENGTH+20];
#endif

    CU_TRACE_FUNCTION();

    maxwellEventGroup = pEventGroup->arch.maxwellEventGroup;
    CU_ASSERT(maxwellEventGroup);

    //elapsed_clocks is always read
    size  = sizeof(NvU32) * (CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS + CU_PROF_ELAPSED_CLOCK_SLOT);

    offset = (NvU32*)malloc(size);
    values = (NvU32*)malloc(size);
    if (!offset || !values) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    offset[j]  = NV_PERF_PMASYS_MEM_BYTES;
    values[j] = 0;
    j++;
    offset[j]  = NV_PERF_PMASYS_MEM_HEAD;
    values[j] = 0;
    j++;

    // read counter values for all HW counters then populate the values in eventgroup depending on the mode
    if (CUDA_SUCCESS != PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, j, offset, values, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

    //memBytes = GETVAL(values[0], NV_PERF_PMASYS_MEM_BYTES_NUMBYTES);
    //memHeadPtr = GETVAL(values[1], NV_PERF_PMASYS_MEM_HEAD_PTR);
    memHeadPtr = values[1];

    totalBytes = (NvU32)(memHeadPtr - pEventGroup->pCtx->pmNew->gpuAddrStreamingBuffer);

    pTempParsedClk = maxwellEventGroup->pParsedClk;
    if (!pTempParsedClk) {
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    recPtr = (CUprofStreamingRecord *)pEventGroup->pCtx->pmNew->cpuAddrStreamingBuffer;
    if (!recPtr) goto EXIT;

    cuosMemset(pTempParsedClk->values, 0, sizeof(NvU32) * maxwellEventGroup->maxChiplets * pEventGroup->totalCounters);

#ifdef PRINT_EVENT_SAMPLING_RECORDS
    strcpy(filename, pEventGroup->pCtx->profiler->logfile);
    strcat(filename, "_event_samples");
    tempfp = fopen(filename, "a");
    if (NULL == tempfp) {
        CU_DEBUG_PRINT(("Failed to open cuda sampling log: %s\n", filename));
        //return CUDA_ERROR_FILE_NOT_FOUND;
    }
#endif

    while(totalBytes) {
        chipletType = recPtr->perfmonId & 3;
        if(PM_CHIPLET_TYPE_SYS == chipletType) {
            clkIdx = (recPtr->perfmonId & 0x1c) >> 2;
            chipIdx = (recPtr->perfmonId & 0xE0) >> 5;
        } else {
            clkIdx = (recPtr->perfmonId & 0xc) >> 2;
            chipIdx = (recPtr->perfmonId & 0xF0) >> 4;
        }

        if (clkIdx != maxwellEventGroup->clkIdx) {
            recPtr ++;
            totalBytes -= sizeof(CUprofStreamingRecord);
            continue;
        }

#ifdef PRINT_EVENT_SAMPLING_RECORDS
        if(tempfp && (recPtr->eventCnt || recPtr->trigger0Cnt || recPtr->trigger1Cnt || recPtr->sampleCnt)) {
            fprintf(tempfp, "0x%lx,0x%x,0x%x,%lu,%lu,%lu,%lu\n",  (long unsigned int)(((uint64_t)recPtr->timestamp39_32<<32) | recPtr->timestamp00_31), recPtr->perfmonId, recPtr->smplCnt_ds_sz, (long unsigned int)recPtr->eventCnt, (long unsigned int)recPtr->trigger0Cnt, (long unsigned int)recPtr->trigger1Cnt, (long unsigned int)recPtr->sampleCnt);
        }
#endif
        values[NV_PMM_TRIG0_BIT_POS] = recPtr->trigger0Cnt;
        values[NV_PMM_TRIG1_BIT_POS] = recPtr->trigger1Cnt;
        values[NV_PMM_EVENT_BIT_POS] = recPtr->eventCnt;
        values[NV_PMM_SAMPLE_BIT_POS] = recPtr->sampleCnt;
        //Let's write timestamp in elapsed_clocks for now
        values[NV_PMM_ELAPSED_CLOCKS_BIT_POS] = recPtr->timestamp00_31;

        currPosInValueArray = (pTempParsedClk->values + (pEventGroup->totalCounters * chipIdx));
        for(i=0; i<pEventGroup->totalCounters; i++)
        {
            if (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_4444) {
                if(pTempParsedClk->eventspec[i] == NV_ELAPSED_CLOCKS) {
                    currPosInValueArray[i] += values[NV_PMM_ELAPSED_CLOCKS_BIT_POS];
                } else {
                    NvU32 partNo = 0, spec = 0, width = 0, lshCount = 0, partWidth = 0, tempPartNumber = 0;
                    //currPosInValueArray[i] = 0;
                    tempPartNumber = pTempParsedClk->partNumber[i];
                    width = pTempParsedClk->width[i];
                    while(tempPartNumber) {
                        spec = (tempPartNumber & 0xff);
                        spec--;
                        partWidth = (width >= 4) ? 4 : width;
                        //change values in parsedClk to 64 bit.
                        currPosInValueArray[i] +=  (NvU32)(((NvU64)(values[spec]) << lshCount));
                        lshCount += partWidth;
                        width -= partWidth;
                        partNo++;
                        tempPartNumber >>= 8;
                    }
                    //At the end of while loop the width has to be 0
                    CU_ASSERT(width == 0);
                }
            } else {
                switch(pTempParsedClk->eventspec[i]) {
                    case (NV_PMM_TRIG1 | NV_PMM_EVENT):
                        if ((pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_EVENT4) ||
                            (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_EVENT6) ||
                            (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_2X4B4I)) {
                                currPosInValueArray[i] += values[NV_PMM_EVENT_BIT_POS];
                        }
                        else if ((pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_TRIG4) || (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_TRIG6)) {
                            if ((pTempParsedClk->width[i] == 2) && (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_TRIG6)) {
                                //This case should occur rarely as we will give preference to 4444 mode
                                currPosInValueArray[i] += values[NV_PMM_EVENT_BIT_POS];
                            } else {
                                currPosInValueArray[i] += values[NV_PMM_TRIG1_BIT_POS];
                            }
                        }
                        break;
                    case (NV_PMM_TRIG0 | NV_PMM_SAMPLE):
                        currPosInValueArray[i] += values[NV_PMM_TRIG0_BIT_POS];
                        break;
                    case NV_PMM_TRIG0:
                        currPosInValueArray[i] += values[NV_PMM_TRIG0_BIT_POS];
                        break;
                    case NV_PMM_TRIG1:
                        currPosInValueArray[i] += values[NV_PMM_TRIG1_BIT_POS];
                        break;
                    case NV_PMM_EVENT:
                        currPosInValueArray[i] += values[NV_PMM_EVENT_BIT_POS];
                        break;
                    case NV_PMM_SAMPLE:
                        currPosInValueArray[i] += values[NV_PMM_SAMPLE_BIT_POS];
                        break;
                    case NV_ELAPSED_CLOCKS:
                        currPosInValueArray[i] += values[NV_PMM_ELAPSED_CLOCKS_BIT_POS];
                        break;
                    default:
                        CU_ERROR_PRINT(("Not a valid trigger type.\n"));
                        break;
                }
            }
        }

     recPtr ++;
     totalBytes -= sizeof(CUprofStreamingRecord);
    }

#ifdef PRINT_EVENT_SAMPLING_RECORDS
    if (tempfp) {
        fflush(tempfp);
        fclose(tempfp);
        //return CUDA_ERROR_FILE_NOT_FOUND;
    }
#endif

    j = 0;
    offset[j++] = NV_PERF_PMASYS_MEM_BYTES;

    if (CUDA_SUCCESS != PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, j, offset, values, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }
    //Write value read from mem_bytes to mem_bump
    j = 0;
    offset[j] = NV_PERF_PMASYS_MEM_BUMP;

    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, j, offset, values, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

EXIT:
    free (offset);
    free (values);
    return status;
}

static CUprofResult logPMCountersModeB(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *values = NULL, *currPosInValueArray = NULL;
    NvU32 size = 0, totalSlots = 0;
    NvU32 domainRegOffset = 0, chipIdx = 0, i = 0, idx = 0;
    CUmaxwellEventGroup  *maxwellEventGroup;
    CUparsedClk *pTempParsedClk = NULL;
    CU_TRACE_FUNCTION();

    maxwellEventGroup = pEventGroup->arch.maxwellEventGroup;
    CU_ASSERT(maxwellEventGroup);

    //elapsed_clocks is always read
    totalSlots = (CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS + CU_PROF_ELAPSED_CLOCK_SLOT);
    size  = sizeof(NvU32) * totalSlots * maxwellEventGroup->maxChiplets;

    offset = (NvU32*)malloc(size);
    values = (NvU32*)malloc(size);
    if (!offset || !values) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    pTempParsedClk = pEventGroup->arch.maxwellEventGroup->pParsedClk;

    for (chipIdx = 0; chipIdx < maxwellEventGroup->maxChiplets; chipIdx++) {
        if(maxwellEventGroup->pmUnitMask & (1<<chipIdx))
        {
            domainRegOffset = maxwellEventGroup->pmmAddress[chipIdx] + maxwellEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;

            offset[NV_PMM_TRIG0_BIT_POS+(totalSlots*idx)] = domainRegOffset + NV_PMM_TRIGGERCNT;
            offset[NV_PMM_TRIG1_BIT_POS+(totalSlots*idx)] = domainRegOffset + NV_PMM_THRESHCNT;
            offset[NV_PMM_EVENT_BIT_POS+(totalSlots*idx)] = domainRegOffset + NV_PMM_EVENTCNT;
            offset[NV_PMM_SAMPLE_BIT_POS+(totalSlots*idx)] = domainRegOffset + NV_PMM_SAMPLECNT;
            offset[NV_PMM_ELAPSED_CLOCKS_BIT_POS+(totalSlots*idx)] = domainRegOffset + NV_PMM_ELAPSED;
            idx++;
        }
    }
    CU_ASSERT(idx <= totalSlots * maxwellEventGroup->maxChiplets);
    // read counter values for all HW counters then populate the values in eventgroup depending on the mode
    if (CUDA_SUCCESS != PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, totalSlots*idx, offset, values, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        pTempParsedClk = NULL;
        goto EXIT;
    }

    idx = 0;
    for (chipIdx = 0; chipIdx < maxwellEventGroup->maxChiplets; chipIdx++) {
        if(maxwellEventGroup->pmUnitMask & (1<<chipIdx))
        {
            if (!pTempParsedClk) {
                status = CUPROF_ERROR_OUT_OF_MEMORY;
                goto EXIT;
            }
            currPosInValueArray = (pTempParsedClk->values + (pEventGroup->totalCounters * chipIdx));
            for(i=0; i<pEventGroup->totalCounters; i++)
            {
                if (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_4444) {
                    if(pTempParsedClk->eventspec[i] == NV_ELAPSED_CLOCKS) {
                        currPosInValueArray[i] = values[NV_PMM_ELAPSED_CLOCKS_BIT_POS+(totalSlots*idx)];
                    } else {
                        NvU32 partNo = 0, spec = 0, width = 0, lshCount = 0, partWidth = 0, tempPartNumber = 0;
                        currPosInValueArray[i] = 0;
                        tempPartNumber = pTempParsedClk->partNumber[i];
                        width = pTempParsedClk->width[i];
                        while(tempPartNumber) {
                            spec = (tempPartNumber & 0xff);
                            spec--;
                            partWidth = (width >= 4) ? 4 : width;
                            //change values in parsedClk to 64 bit.
                            currPosInValueArray[i] +=  (NvU32)(((NvU64)(values[spec+(totalSlots*idx)]) << lshCount));
                            lshCount += partWidth;
                            width -= partWidth;
                            partNo++;
                            tempPartNumber >>= 8;
                        }
                        //At the end of while loop the width has to be 0
                        CU_ASSERT(width == 0);
                    }
                } else {
                    switch(pTempParsedClk->eventspec[i]) {
                    case (NV_PMM_TRIG1 | NV_PMM_EVENT):
                        if ((pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_EVENT4) ||
                            (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_EVENT6) ||
                            (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_2X4B4I)) {
                                currPosInValueArray[i] = values[NV_PMM_EVENT_BIT_POS+(totalSlots*idx)];
                        }
                        else if ((pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_TRIG4) || (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_TRIG6)) {
                            if ((pTempParsedClk->width[i] == 2) && (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_TRIG6)) {
                                //This case should occur rarely as we will give preference to 4444 mode
                                currPosInValueArray[i] = values[NV_PMM_EVENT_BIT_POS+(totalSlots*idx)];
                            } else {
                                currPosInValueArray[i] = values[NV_PMM_TRIG1_BIT_POS+(totalSlots*idx)];
                            }
                        }
                        break;
                    case (NV_PMM_TRIG0 | NV_PMM_SAMPLE):
                        currPosInValueArray[i] = values[NV_PMM_TRIG0_BIT_POS+(totalSlots*idx)];
                        break;
                    case NV_PMM_TRIG0:
                        currPosInValueArray[i] = values[NV_PMM_TRIG0_BIT_POS+(totalSlots*idx)];
                        break;
                    case NV_PMM_TRIG1:
                        currPosInValueArray[i] = values[NV_PMM_TRIG1_BIT_POS+(totalSlots*idx)];
                        break;
                    case NV_PMM_EVENT:
                        currPosInValueArray[i] = values[NV_PMM_EVENT_BIT_POS+(totalSlots*idx)];
                        break;
                    case NV_PMM_SAMPLE:
                        currPosInValueArray[i] = values[NV_PMM_SAMPLE_BIT_POS+(totalSlots*idx)];
                        break;
                    case NV_ELAPSED_CLOCKS:
                        currPosInValueArray[i] = values[NV_PMM_ELAPSED_CLOCKS_BIT_POS+(totalSlots*idx)];
                        break;
                    default:
                        CU_ERROR_PRINT(("Not a valid trigger type.\n"));
                        break;
                    }
                }
            }
            idx++;
        }
    }

EXIT:
    free (offset);
    free (values);
    return status;
}
// detect if there has been a counter overflow
static CUprofResult detectCounterOverflowModeB(const CUeventGroup *pEventGroup, NvBool* bIsOverflow)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUmaxwellEventGroup  *maxwellEventGroup;
    CUparsedClk *pTempParsedClk = NULL;
    NvU32 chipIdx = 0, i = 0;

    CU_TRACE_FUNCTION();

    maxwellEventGroup = pEventGroup->arch.maxwellEventGroup;
    CU_ASSERT(maxwellEventGroup);

    // NV_PERF_PMM_CONTROL_SHADOW_STATE_OVERFLOW field has nothing to do with overflowing snapshots (pm_trigger).
    // in mode B the fact that the counter is saturated (0xFFFFFFFF) is enough to assume overflow.
    for (chipIdx = 0; chipIdx < maxwellEventGroup->maxChiplets; chipIdx++) {
        if(maxwellEventGroup->pmUnitMask & (1<<chipIdx)) {
            pTempParsedClk = pEventGroup->arch.maxwellEventGroup->pParsedClk;
            for(i=0; i<pEventGroup->totalCounters; i++) {
                if (COUNTER_MAX32BIT == *(pTempParsedClk->values + (pEventGroup->totalCounters * chipIdx) + i)) {
                    *bIsOverflow = NV_TRUE;
                    return CUPROF_SUCCESS;
                }
            }
        }
    }
    return status;
}
static CUprofResult PMReleaseModeB(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *value = NULL;
    NvU32 count = 0, size = 0, domainRegOffset = 0;
    NvU32 chipIdx = 0;
    CUmaxwellEventGroup  *maxwellEventGroup;

    CU_TRACE_FUNCTION();
    maxwellEventGroup = pEventGroup->arch.maxwellEventGroup;


    size = sizeof(NvU32) * maxwellEventGroup->maxChiplets;
    offset = (NvU32*)malloc(size);
    value  = (NvU32*)malloc(size);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset and value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    for (chipIdx = 0; chipIdx < maxwellEventGroup->maxChiplets; chipIdx++) {
        if(maxwellEventGroup->pmUnitMask & (1<<chipIdx))
        {
            domainRegOffset = maxwellEventGroup->pmmAddress[chipIdx] + maxwellEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
            offset[count]  = domainRegOffset + NV_PERF_PMM_RELEASE;
            value[count++] = NV_PERF_PMM_RELEASE_SHADOWS_DOIT;
        }
    }

    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

EXIT:
    free (offset);
    free (value);

    return status;
}

static CUprofResult maxwellPerfmonSampleCountersNew(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvBool bIsOverflow = NV_FALSE;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if (!pEventGroup->totalCounters) {
        return CUPROF_SUCCESS;
    }

    if ((pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS)
        ||
        (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING)
        ) {
        status = StartExptModeB(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            goto EXIT;
        }
    }

    if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING) {
        stopStreaming(pEventGroup->pCtx);
        status = logPMCountersModeBStreamingMode(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            goto EXIT;
        }
    } else {
        status = logPMCountersModeB(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            goto EXIT;
        }
        // report overflow if any
        if (CUPROF_SUCCESS != detectCounterOverflowModeB(pEventGroup, &bIsOverflow)) {
            goto EXIT;
        }

        if (bIsOverflow) {
            CU_ERROR_PRINT(("One or more counter is overflowing.\n"));
        }
    }

    status = PMReleaseModeB(pEventGroup);
    if (CUPROF_SUCCESS != status) {
        goto EXIT;
    }

EXIT:

    return status;
}

static CUprofResult readCountersDetectOverflowSMPC(CUeventGroup *pEventGroup)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUSMCtrInfo     *pSM = NULL;
    NvBool          bIsOverflow = NV_FALSE;
    CUeventInfo *currEventInfo = NULL;
    void *currEvent = NULL;
    void *eventBase = NULL;
    NvU32 multiplier[CU_PROF_PM_EVENT_GROUP_MAX_COUNTERS] = {0}, splitWidth[CU_PROF_PM_EVENT_GROUP_MAX_COUNTERS] = {0};
    NvU8 overflowValuesQuad[CU_PROF_SM_QUAD_PROFILED_MAX] = {0}, overflowValuesCore[CU_PROF_SM_CORE_PROFILED_MAX] = {0};
    NvU32 i = 0, chipIdx = 0, j = 0, smcntr_idx, lsh_cnt = 0;

    currEventInfo = (CUeventInfo*)listGetNext(pEventGroup->pEventInfoList, &eventBase);
    for (i = 0; (i < pEventGroup->totalCounters) && currEventInfo; i++, currEventInfo = (CUeventInfo*)listGetNext(NULL, &eventBase)) {
        currEvent = currEventInfo->pEventData;
        // store multiplication factor of each signal in the event group
        multiplier[i] = getCounterMultiplicationFactor(pEventGroup->pCtx->device->state.chip, ((CUeventDataSmpc*)currEvent)->signalId);
        getSplittingInfo(((CUeventDataSmpc*)currEvent)->signalId, &splitWidth[i]);
    }
    status = (CUprofResult)logPMCountersSMInternal(pEventGroup, overflowValuesQuad, overflowValuesCore);
    if (CUPROF_SUCCESS != status) {
        return status;
    }
    // report overflow if any
    if (CUDA_SUCCESS != detectCounterOverflowSMInternal(pEventGroup, &bIsOverflow, overflowValuesQuad, overflowValuesCore)) {
        return status;
    }
    if (bIsOverflow) {
        CU_ERROR_PRINT(("One or more counter is overflowing.\n"));
    }

    pSM = pEventGroup->arch.maxwellEventGroup->pSM;

    for (chipIdx = 0; chipIdx < pEventGroup->arch.maxwellEventGroup->maxChiplets; chipIdx++) {
        if(pEventGroup->arch.maxwellEventGroup->pmUnitMask & (1<<chipIdx))
        {
            NvU32 sig_cnt = 0;
            for(i=0; i<pSM->SMCountersAdded && sig_cnt < pEventGroup->totalCounters; i+=((pSM->splitParts[i]!=0) ? pSM->splitParts[i] : 1), sig_cnt++)
            {
                NvU64 temp_vals = 0;
                lsh_cnt = 0;
                for(smcntr_idx = i ; smcntr_idx < (i + pSM->splitParts[sig_cnt]) ; smcntr_idx++) {
                    //copy linearly in eventgroup in folowing fashion: [instancecount][counter]
                    // As the counterwidth has now changed to 40 bits, we will need to compare with COUNTER_MAX64BIT
                    if ((*(pSM->values + pSM->SMCountersAdded * chipIdx + smcntr_idx) != COUNTER_MAX64BIT) &&
                        (temp_vals != COUNTER_MAX64BIT))
                    {
                        temp_vals += *(pSM->values + pSM->SMCountersAdded * chipIdx + smcntr_idx) << lsh_cnt;
                    }
                    else {
                        // 32-bit counter is overflowing, set 64-bit out value to max
                        temp_vals = COUNTER_MAX64BIT;
                        break;
                    }
                    lsh_cnt += splitWidth[i];
                }
                if(temp_vals != COUNTER_MAX64BIT){
                    temp_vals *= multiplier[sig_cnt];
                }
                pEventGroup->values[j++] += temp_vals;
            }
        }
    }
    return CUPROF_SUCCESS;
}

// Function to read counters from hardware
static CUprofResult maxwellReadCounters(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 i = 0, chipIdx = 0, j = 0;
    CUparsedClk     *pTempParsedClk = NULL;
    CUeventInfo *currEventInfo = NULL;
    void *currEvent = NULL;
    void *eventBase = NULL;
    NvU32 multiplier[CU_PROF_PM_EVENT_GROUP_MAX_COUNTERS] = {0};

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);
    CU_ASSERT(pEventGroup->isEnabled);

    if (!pEventGroup->totalCounters) {
        return CUPROF_SUCCESS;
    }


    switch(pEventGroup->domain->eventCollectionMethod)
    {
    case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
            //sample PM signals
            currEventInfo = (CUeventInfo*)listGetNext(pEventGroup->pEventInfoList, &eventBase);
            for (i = 0; (i < pEventGroup->totalCounters) && currEventInfo; i++, currEventInfo = (CUeventInfo*)listGetNext(NULL, &eventBase)) {
                currEvent = currEventInfo->pEventData;
                // store multiplication factor of each signal in the event group
                multiplier[i] = getCounterMultiplicationFactor(pEventGroup->pCtx->device->state.chip, ((CUeventData*)currEvent)->signalId);
            }

            status = maxwellPerfmonSampleCountersNew(pEventGroup);
            if (status != CUPROF_SUCCESS) {
                return status;
            }

            for (chipIdx = 0; chipIdx < pEventGroup->arch.maxwellEventGroup->maxChiplets; chipIdx++) {
                if(pEventGroup->arch.maxwellEventGroup->pmUnitMask & (1<<chipIdx))
                {
                    pTempParsedClk = pEventGroup->arch.maxwellEventGroup->pParsedClk;;
                    for(i=0; i<pEventGroup->totalCounters; i++)
                    {
                        //copy linearly in eventgroup in folowing fashion: [instancecount][counter]
                        if ((*(pTempParsedClk->values + pEventGroup->totalCounters * chipIdx + i) != COUNTER_MAX32BIT) &&
                            (pEventGroup->values[j] != COUNTER_MAX64BIT))
                        {
                            pEventGroup->values[j++] += (NvU64)*(pTempParsedClk->values + pEventGroup->totalCounters * chipIdx + i) * multiplier[i];
                        }
                        else {
                            // 32-bit counter is overflowing, set 64-bit out value to max
                            pEventGroup->values[j++] = COUNTER_MAX64BIT;
                        }
                    }
                }
            }
        break;

    case CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX:
    case CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
        {
            status = readCountersDetectOverflowSMPC(pEventGroup);
            if (CUPROF_SUCCESS != status) {
                return status;
            }
        }
        break;

    default:
        break;
    }

    return status;
}

CUprofResult maxwellPerfmonEventGroupDisable(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    CUctx *ctx;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);
    //CU_ASSERT(pEventGroup->domainId < MAX_DOMAINS);

    ctx = pEventGroup->pCtx;
    setDomainEventGroup(ctx->pmNew->domainEventGroupEnabled, pEventGroup->domainId, 0);
    pEventGroup->isEnabled = 0;

    switch(pEventGroup->domain->eventCollectionMethod) {
        case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
            if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING) {
                stopStreaming(pEventGroup->pCtx);
#ifndef BUG_1259185_FIXED
                cleanupStreamingResources(ctx);
#endif
            }
            // fallthrough
        case CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX:
            // PM_ENABLE bit setting is Global. It will affect counter profiling in a multi-process/multi-ctx scenario
            // Commenting the Code to clear off the PM_ENABLE bit:(Bug 1254320)
            // To do: Re-enable the code when bug 973271 is fixed
#if 0
            status = setPMEnableReg(pEventGroup, NV_FALSE);
            if (CUPROF_SUCCESS != status) {
                CU_ERROR_PRINT(("Failed to disable the PME\n"));
            }
#endif
            if (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX) {
                //TBD since we have already disabled the PM enableBits for HWPM ,
                //we need not disable them again, if we do so guard with refcount
                if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS) {
                    maxwellPerfmonStopCounters(NULL, pEventGroup);
                }
            }
            resetPMTarget(pEventGroup);
            break;

        case CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW:
        case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
            if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS) {
                maxwellPerfmonStopCounters(NULL, pEventGroup);
            }
            // PM_ENABLE bit setting is Global. It will affect counter profiling in a multi-process/multi-ctx scenario
            // Commenting the Code to clear off the PM_ENABLE bit:(Bug 1254320)
            // To do: Re-enable the code when bug 973271 is fixed
#if 0
            status = setPMEnableRegSM(pEventGroup, NV_FALSE);
            if (CUPROF_SUCCESS != status) {
                CU_ERROR_PRINT(("Failed to disable the SMPERF PMReg\n"));
            }
#endif
            resetPMTarget(pEventGroup);
            break;

        case CUPROF_EVENT_COLLECTION_METHOD_SW:
        default:
            //do nothing
            break;
    }

    return status;
}

CUprofResult maxwellPerfmonEventGroupReadEvent(CUeventGroup          *pEventGroup,
                                               CUprof_ReadEventFlags flags,
                                               CUprof_EventID        eventID,
                                               size_t                *bufferSizeBytes,
                                               NvU64                 *counterData)
{
    CUprofResult status = CUPROF_SUCCESS;
    void *currEvent = NULL;
    CUeventInfo *currEventInfo = NULL;
    void *eventBase = NULL;
    NvU32 i = 0, j = 0, instanceCount = 0;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    CU_ASSERT(pEventGroup->arch.maxwellEventGroup);
    CU_ASSERT(bufferSizeBytes && counterData);

    currEventInfo = (CUeventInfo *)listGetNext(pEventGroup->pEventInfoList, &eventBase);
    for (i = 0; (i < pEventGroup->totalCounters) && currEventInfo; i++, currEventInfo = (CUeventInfo *)listGetNext(NULL, &eventBase)) {
        currEvent = currEventInfo->pEventData;
        if (((CUeventDataBasic*)currEvent)->signalId == eventID) {
            break;
        }
    }

    if (i == pEventGroup->totalCounters) {
        CU_ERROR_PRINT(("Invalid event-id %d\n", (int)eventID));
        return CUPROF_ERROR_INVALID_EVENT_ID;
    }

    // trigger the PM and read counters
    status = maxwellReadCounters(pEventGroup);
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read counters or reset pm\n"));
        return status;
    }

    if(pEventGroup->profileAll) {
        instanceCount = pEventGroup->instanceCountAvail;
    }
    else {
        instanceCount = 1;
    }

    //Check how many bytes are allocated for counterData
    instanceCount = MIN(*(NvU32*)bufferSizeBytes / sizeof(NvU64), instanceCount);
    *bufferSizeBytes = instanceCount * sizeof(NvU64);

    for(j = 0; j < instanceCount; j++)
    {
        counterData[j] = pEventGroup->values[i + j*pEventGroup->totalCounters];
        // zero out the stored value, only returned counter values are considered
        pEventGroup->values[i + j*pEventGroup->totalCounters] = 0;
    }

    if ((pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX) ||
        (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW) ||
        (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_SMPERF)) {
            status = (CUprofResult)resetPMSMInternal(pEventGroup);
    }
    if (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_HWPM) {
        status = StartExptModeB(pEventGroup);
    }

    return status;
}

CUprofResult maxwellPerfmonEventGroupReadAllEvents(CUeventGroup *pEventGroup,
                                                   CUprof_ReadEventFlags  flags,
                                                   size_t                 *bufferSizeBytes,
                                                   NvU64                  *counterDataBuffer,
                                                   size_t                 *arraySizeBytes,
                                                   CUprof_EventID         *eventIDArray,
                                                   size_t                 *numCountersRead)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUeventInfo *currEventInfo = NULL;
    void *currEvent = NULL;
    void *eventBase = NULL;
    NvU32 numEvents = 0, i = 0, j = 0, totalValues = 0, instanceCount = 0;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    CU_ASSERT(pEventGroup->arch.maxwellEventGroup);
    CU_ASSERT(bufferSizeBytes && counterDataBuffer);
    CU_ASSERT(numCountersRead);

    // trigger the PM and read counters
    status = maxwellReadCounters(pEventGroup);
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read counters or reset pm\n"));
        return status;
    }

    if(pEventGroup->profileAll) {
        instanceCount = pEventGroup->instanceCountAvail;
    }
    else {
        instanceCount = 1;
    }

    //Check how many bytes are allocated for counterData
    totalValues = instanceCount * pEventGroup->totalCounters;
    totalValues = MIN(*(NvU32*)bufferSizeBytes / sizeof(NvU64), totalValues);

    //It makes sense to give all instances of possible number of events
    numEvents = totalValues / instanceCount;

    *bufferSizeBytes = numEvents * instanceCount * sizeof(NvU64);

    for(i = 0; i < instanceCount; i++) {
        for(j = 0; j < numEvents; j++) {
            *(counterDataBuffer+i*numEvents+j) = *(pEventGroup->values + i*pEventGroup->totalCounters + j);
            // zero out the stored value, only returned counter values are considered
            *(pEventGroup->values + i*pEventGroup->totalCounters + j) = 0;
        }
    }

    *numCountersRead = numEvents;

    // assuming eventId params are optional
    if (arraySizeBytes && (*arraySizeBytes > 0) && eventIDArray) {
        numEvents = MIN(*(NvU32*)arraySizeBytes / sizeof(CUprof_EventID), *(NvU32*)numCountersRead);
        currEventInfo = (CUeventInfo*)listGetNext(pEventGroup->pEventInfoList, &eventBase);

        for (i = 0; (i < pEventGroup->totalCounters) && (i < numEvents) && currEventInfo; i++, currEventInfo = (CUeventInfo*)listGetNext(NULL, &eventBase)) {
            currEvent = currEventInfo->pEventData;
            eventIDArray[i] = ((CUeventDataBasic*)currEvent)->signalId;
        }
        *arraySizeBytes = numEvents * sizeof(CUprof_EventID);
    }

    if ((pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX) ||
        (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW) ||
        (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_SMPERF)) {
            status = (CUprofResult)resetPMSMInternal(pEventGroup);
    }

    return status;
}

// this function is not exposed to external users
// it assists internal tools (profiler) to control event group
// based operations
CUprofResult maxwellPerfmonEventGroupControl(CUeventGroup *pEventGroup,
                                             CUeventGroupFlag flag,
                                             void *value)
{
    CUprofResult status = CUPROF_SUCCESS;

    CU_TRACE_FUNCTION();

    CU_ASSERT(pEventGroup);

    switch (flag) {
    case CU_EVENT_GROUP_FLAG_SET_PROFILE_ALL_DOMAIN_INSTANCES:
        pEventGroup->profileAll = 1;
        break;
    case CU_EVENT_GROUP_FLAG_GET_CHIP_TYPE_FB:
        if (pEventGroup->domain->chipletType == PM_CHIPLET_TYPE_FBP) {
            *(int*)value = 1;
        }
        else {
            *(int*)value = 0;
        }
        break;
    case CU_EVENT_GROUP_FLAG_GET_UNIT_TYPE_SM:
        if ((pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW) ||
        (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_SMPERF)) {
                *(int*)value = 1;
        }
        else {
            *(int*)value = 0;
        }
        break;
    default:
        CU_ERROR_PRINT(("Not a valid flag (%d)\n", flag));
        break;
    }

    return status;
}
// detect if there has been a counter overflow
static CUresult detectCounterOverflowSMInternal(const CUeventGroup *pEventGroup, NvBool* bIsOverflow, NvU8* overflowValuesQuad, NvU8* overflowValuesCore)
{
    CUresult status = CUDA_SUCCESS;
    CUmaxwellEventGroup  *pMaxwellEventGroup = NULL;
    NvU32 gpcId = 0, tpcId = 0, smId = 0;
    NvU32 idxQctl = 0, idxCore = 0;
    NvU32 i = 0;
    CUSMCtrInfo     *pSM = NULL;

    CU_TRACE_FUNCTION();

    pMaxwellEventGroup = pEventGroup->arch.maxwellEventGroup;
    pSM = pMaxwellEventGroup->pSM;

    /*******************************************************************************
    - Now, as the status register will now contain higher 8 bits of counter value,
    we can get these values in from the logPmCountersSMInternal function itself
    when we read the counter values.
    - So we will need to check if the 8 bits have the value 0xFF in them to detect
    overflow case.
    - Bits assigned to each signal:
    0:7 - counter1      8:15 - counter2
    16:23- counter3     24:31 - counter4
    *******************************************************************************/
    // check for overflow
    idxQctl = 0;
    idxCore = 0;

    for(i=0; i<(NvU32)pSM->SMCountersAdded; i++) {
        switch (pSM->pmUnitId[i]) {
        case PM_UNIT_SMQCTL:
            if (overflowValuesQuad[idxQctl] == COUNTER_OVERFLOW_VALUE) {
                // we will be clearing the status registers while clearing off the signals values.
                for(gpcId = 0; gpcId < pMaxwellEventGroup->gpcCount; gpcId++)
                {
                    for(tpcId = 0; tpcId < pMaxwellEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
                    {
                        if(pMaxwellEventGroup->pmUnitMask & (1<<smId))
                        {
                            *(pSM->values + pSM->SMCountersAdded * smId + i) = COUNTER_MAX64BIT;
                        }
                        smId++;
                    }
                }
                *bIsOverflow = NV_TRUE;
            }
            idxQctl++;
            break;
        case PM_UNIT_SMCORE:
        case PM_UNIT_MIO:
            if (overflowValuesCore[idxCore] == COUNTER_OVERFLOW_VALUE) {
                // we will be clearing the status registers while clearing off the signals values.
                for(gpcId = 0; gpcId < pMaxwellEventGroup->gpcCount; gpcId++)
                {
                    for(tpcId = 0; tpcId < pMaxwellEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
                    {
                        if(pMaxwellEventGroup->pmUnitMask & (1<<smId))
                        {
                            *(pSM->values + pSM->SMCountersAdded * smId + i) = COUNTER_MAX64BIT;
                        }
                        smId++;
                    }
                }
                *bIsOverflow = NV_TRUE;
            }
            idxCore++;
            break;
        }
    }
    return status;
}

static CUresult setPMEnableRegSM(const CUeventGroup *pEventGroup, NvBool bEnable)
{
    //Function to be changed for new version
    CUresult status = CUDA_SUCCESS;
    NvU32 offset, value;
    NvU32 i = 0, j = 0;
    NvU32 smValue, smMask;
    NvU32 pmUnitIdx = 0;
    PMEnableRegInfo *pPMEnableRegInfo = NULL;
    CUSMCtrInfo     *pSM = NULL;

    CU_TRACE_FUNCTION();

    pSM = pEventGroup->arch.maxwellEventGroup->pSM;

    for(i=0; i<(NvU32)pSM->SMCountersAdded; i++) {
        pmUnitIdx = 0;

        //Search the unit table to get the unit.
        //TBD check if we can shift the unit table to domain table
        while (pEventGroup->pCtx->device->state.pPerfUnitTable[pmUnitIdx].pmUnitId != PM_UNIT_MAX) {
            if (pEventGroup->pCtx->device->state.pPerfUnitTable[pmUnitIdx].pmUnitId == pSM->pmUnitId[i]) {
                break;
            }
            pmUnitIdx++;
        }

        if (pEventGroup->pCtx->device->state.pPerfUnitTable[pmUnitIdx].pmUnitId == PM_UNIT_MAX) {
            // perf unit not found
            continue;
        }

        pPMEnableRegInfo = &pEventGroup->pCtx->device->state.pPerfUnitTable[pmUnitIdx].pmEnableRegInfo;

        for(j=0; j< pEventGroup->arch.maxwellEventGroup->maxChiplets; j++)
        {
            if(pEventGroup->arch.maxwellEventGroup->pmUnitMask & (1<<j))
            {
                offset = pEventGroup->arch.maxwellEventGroup->priAddress[j] + pPMEnableRegInfo->regOffset;
                value = 0;
                smValue = 0;

                // read _PM registers
                status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, 1, &offset, &value, 0);
                if (status != CUDA_SUCCESS) {
                    return status;
                }

                // set PM_ENABLE bit by ORing the read value for selected instance
                smValue = (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                smValue |= 0x80;
                smMask  = NV_SM_PM_CTRL_ENABLE_BITS_MASK;
                if(bEnable)
                {
                    value |= (smValue & smMask);
                }
                else
                {
                    value &= ~(smMask);
                }

                status = PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, 1, &offset, &value, 0);
                if (status != CUDA_SUCCESS) {
                    return status;
                }
            }
        }
    }
    return status;
}

static CUresult SetupPMRegistersSMInternal(CUeventGroup *pEventGroup) {
    CUresult status = CUDA_SUCCESS;
    CUresult (*setupSmpcRegs)(CUeventGroup *pEventGroup, NvU32 eventGroupQctl, NvU32 eventGroupCore, 
                                                    NvU32* funcQctl, NvU32* funcCore, NvU32 enableQctl, NvU32 enableCore);
    NvU32 eventGroupQctl = 0, eventGroupCore = 0;
    NvU32 funcQctl[2] = {0}, funcCore[2] = {0};
    NvU32 idxQctl = 0, idxCore = 0;
    NvU32 enableQctl = 0, enableCore = 0;
    NvU32 i = 0, index = 0;
    CUSMCtrInfo     *pSM = NULL;

    CU_TRACE_FUNCTION();

    pSM = pEventGroup->arch.maxwellEventGroup->pSM;

    // Select group, edge, func etc
    // first four slots of perf registers are reserved for quad signals
    // while last four are for core/lsu signals

    idxQctl = 0;
    idxCore = 0;

    for(i=0; i<pSM->numGroupsQuad; i++)
    {
        eventGroupQctl |= pSM->groupsQuad[i] << (idxQctl*8);
        idxQctl++;
    }
    for(i=0; i<pSM->numGroupsCore; i++)
    {
        eventGroupCore |= pSM->groupsCore[i] << (idxCore*8);
        idxCore++;
    }

    // function combination
    // FUNC0 - 15:0, FUNC1 - 31:16
    idxCore = 0;
    idxQctl = 0;

    for (index = 0; index < pSM->SMCountersAdded; index++) {
        switch(pSM->pmUnitId[index]) {
        case PM_UNIT_SMQCTL:
            if(idxQctl & 1) {
                funcQctl[idxQctl>>1] |= pSM->function[index] << 16;
            }
            else {
                funcQctl[idxQctl>>1] |= pSM->function[index];
            }
            idxQctl++;
            break;
        case PM_UNIT_SMCORE:
        case PM_UNIT_MIO:
            if(idxCore & 1) {
                funcCore[idxCore>>1] |= pSM->function[index] << 16;
            }
            else {
                funcCore[idxCore>>1] |= pSM->function[index];
            }
            idxCore++;
            break;
        }
    }
    idxQctl = 0;
    idxCore = 0;
    for (index = 0; index < pSM->SMCountersAdded; index++) {
        NvU32 startBit, endBit;
        switch(pSM->pmUnitId[index])
        {
        case PM_UNIT_SMQCTL:
            startBit = (idxQctl * 4) + 1;
            endBit = startBit + 1;
            enableQctl = DRF_REPLACE(enableQctl, pSM->mode[index], endBit:startBit);
            idxQctl++;
            break;
        case PM_UNIT_SMCORE:
        case PM_UNIT_MIO:
            startBit = (idxCore * 4) + 1;
            endBit = startBit + 1;
            enableCore = DRF_REPLACE(enableCore, pSM->mode[index], endBit:startBit);
            idxCore++;
            break;
        }
    }

    // Call the broadcase version if profileAll option is selected:
    if(pEventGroup->profileAll) {
        setupSmpcRegs = &SetupPMRegistersSM_bc;
    }
    // Else. call the unicast version:
    else {
        setupSmpcRegs = &SetupPMRegistersSM;
    }

    // Use the new RM Control call for enabling the WAR if it is defined:
#if defined(NV2080_CTRL_CMD_GR_CTXSW_SMPC_MODE)
    if (!pEventGroup->pCtx->pmNew->flag)
    {
        status = pEventGroup->pCtx->device->dmal.deviceSetSMPCCtxswMode(pEventGroup->pCtx, NV_TRUE);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Error setting the CTXSW_SMPC_MODE bit\n"));
            goto EXIT;
        }
        pEventGroup->pCtx->pmNew->flag = 1;
    }
#else
    status = setFalcon05Method(pEventGroup->pCtx);
    if (status != CUDA_SUCCESS) {
        return status;
    }
#endif
    status = (*setupSmpcRegs)(pEventGroup, eventGroupQctl, eventGroupCore, funcQctl, funcCore, enableQctl, enableCore);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Error setting the SMPC configuration registers\n"));
        goto EXIT;
    }
EXIT:
    return status;
}

static CUresult SetupPMRegistersSM(CUeventGroup *pEventGroup, NvU32 eventGroupQctl, NvU32 eventGroupCore, 
                                    NvU32* funcQctl, NvU32* funcCore, NvU32 enableQctl, NvU32 enableCore) {
    CUresult status = CUDA_SUCCESS;
    NvU32 gpcTarget = 0, tpcTarget = 0;
    //TBD Increasing arbitrarity to higher value, later on check exactly how much memory is required
    NvU32 *offset = NULL, gpcId = 0, tpcId = 0, smId = 0;
    NvU32 *value  = NULL;
    NvU32 count = 0, numRegs = 20;
    NvU32 idxQctl = 0, idxCore = 0;
    NvU32 index = 0;
    CUSMCtrInfo     *pSM = NULL;

    CU_TRACE_FUNCTION();

    //Allocate memory of size = (CU_PROF_PM_SM_MAX_COUNTERS * #SMs * sizeof(NvU32))
    offset = (NvU32 *)malloc(numRegs * pEventGroup->instanceCountAvail * sizeof(NvU32));
    value = (NvU32 *)calloc(numRegs * pEventGroup->instanceCountAvail, sizeof(NvU32));

    if(!(offset && value)) {
        CU_ERROR_PRINT(("Error allocating memory for offset-value arrays.\n"));
        status = (CUresult)CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    pSM = pEventGroup->arch.maxwellEventGroup->pSM;

    for(gpcId = 0; gpcId < pEventGroup->arch.maxwellEventGroup->gpcCount; gpcId++)
    {
        for(tpcId = 0; tpcId < pEventGroup->arch.maxwellEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
        {
            if(pEventGroup->arch.maxwellEventGroup->pmUnitMask & (1<<smId))
            {
                gpcTarget = gpcId;
                tpcTarget = tpcId;

                // Performance Counter Group mux select
                // GRP0 - 7:0,  GRP1 - 15:8, GRP2 - 23:16, GRP3 - 31:24
                offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL_SEL0(gpcTarget, tpcTarget);
                value[count++] = eventGroupQctl;
                offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL_SEL1(gpcTarget, tpcTarget);
                value[count++] = eventGroupCore;

                // function combination
                // FUNC0 - 15:0, FUNC1 - 31:16
                offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL1(gpcTarget, tpcTarget);
                value[count++] = funcQctl[0];
                offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL2(gpcTarget, tpcTarget);
                value[count++] = funcQctl[1];
                offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL3(gpcTarget, tpcTarget);
                value[count++] = funcCore[0];
                offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL4(gpcTarget, tpcTarget);
                value[count++] = funcCore[1];

                // Each perf counter has 4 bits feeding into a function table.  Each bit
                // can be selected from 1 of 8 bits of 1 of the 8 groups (selected via
                // the PERF_COUNTER_CONTROL_SEL* register above).
                // BIT#_GRP selects 1 of 8 groups
                // BIT#_SIG selects 1 of the 8 signals from that selected group

                idxCore = 0;
                idxQctl = 0;

                for (index = 0; index < pSM->SMCountersAdded; index++) {
                    switch(pSM->pmUnitId[index]) {
                    case PM_UNIT_SMQCTL:
                        switch(idxQctl) {
                    case 0:
                        offset[count] = NV_SM_DSM_PERF_COUNTER0_CONTROL(gpcTarget, tpcTarget);
                        break;
                    case 1:
                        offset[count] = NV_SM_DSM_PERF_COUNTER1_CONTROL(gpcTarget, tpcTarget);
                        break;
                    case 2:
                        offset[count] = NV_SM_DSM_PERF_COUNTER2_CONTROL(gpcTarget, tpcTarget);
                        break;
                    case 3:
                        offset[count] = NV_SM_DSM_PERF_COUNTER3_CONTROL(gpcTarget, tpcTarget);
                        break;
                        }
                        idxQctl++;
                        break;

                    case PM_UNIT_SMCORE:
                    case PM_UNIT_MIO:
                        switch(idxCore) {
                    case 0:
                        offset[count] = NV_SM_DSM_PERF_COUNTER4_CONTROL(gpcTarget, tpcTarget);
                        break;
                    case 1:
                        offset[count] = NV_SM_DSM_PERF_COUNTER5_CONTROL(gpcTarget, tpcTarget);
                        break;
                    case 2:
                        offset[count] = NV_SM_DSM_PERF_COUNTER6_CONTROL(gpcTarget, tpcTarget);
                        break;
                    case 3:
                        offset[count] = NV_SM_DSM_PERF_COUNTER7_CONTROL(gpcTarget, tpcTarget);
                        break;
                        }
                        idxCore++;
                        break;
                    }
                    value[count++]  = pSM->perfEventInfo[index];
                }
                // Performance Counter - edge
                // EDGE0 - 0:0, EDGE1 - 4:4, EDGE2 - 8:8,   EDGE3 - 12:11
                // MODE0 - 2:1, MODE1 - 6:5, MODE2 - 10:9,  MODE3 - 14:13
                // set EDGE = DISABLE and MODE = COUNT

                offset[count] = NV_SM_DSM_PERF_COUNTER_CONTROL0(gpcTarget, tpcTarget);
                value[count++] = enableQctl;
                offset[count] = NV_SM_DSM_PERF_COUNTER_CONTROL5(gpcTarget, tpcTarget);
                value[count++] = enableCore;
            }
            smId++;
        }
    }
    CU_ASSERT(count <= (numRegs * pEventGroup->instanceCountAvail));
    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, count, offset, value, 0);
    if (status != CUDA_SUCCESS) {
        goto EXIT;
    }
EXIT:
    if(offset) {
        free(offset);
    }
    if(value) {
        free(value);
    }
    return status;
}

 static CUresult SetupPMRegistersSM_bc(CUeventGroup *pEventGroup, NvU32 eventGroupQctl, NvU32 eventGroupCore, 
                                    NvU32* funcQctl, NvU32* funcCore, NvU32 enableQctl, NvU32 enableCore) {
    CUresult status = CUDA_SUCCESS;
    NvU32 *offset = NULL;
    NvU32 *value  = NULL;
    NvU32 count = 0, numRegs = 20;
    NvU32 idxQctl = 0, idxCore = 0;
    NvU32 index = 0;
    CUSMCtrInfo     *pSM = NULL;

    CU_TRACE_FUNCTION();

    //Allocate memory of size = (CU_PROF_PM_SM_MAX_COUNTERS * sizeof(NvU32))
    offset = (NvU32 *)malloc(numRegs * sizeof(NvU32));
    value = (NvU32 *)calloc(numRegs, sizeof(NvU32));

    if(!(offset && value)) {
        CU_ERROR_PRINT(("Error allocating memory for offset-value arrays.\n"));
        status = (CUresult)CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    pSM = pEventGroup->arch.maxwellEventGroup->pSM;

    // Performance Counter Group mux select
    // GRP0 - 7:0,  GRP1 - 15:8, GRP2 - 23:16, GRP3 - 31:24
    offset[count]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL_SEL0;
    value[count++] = eventGroupQctl;
    offset[count]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL_SEL1;
    value[count++] = eventGroupCore;

    // function combination
    // FUNC0 - 15:0, FUNC1 - 31:16
    offset[count]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL1;
    value[count++] = funcQctl[0];
    offset[count]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL2;
    value[count++] = funcQctl[1];
    offset[count]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL3;
    value[count++] = funcCore[0];
    offset[count]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL4;
    value[count++] = funcCore[1];

    // Each perf counter has 4 bits feeding into a function table.  Each bit
    // can be selected from 1 of 8 bits of 1 of the 8 groups (selected via
    // the PERF_COUNTER_CONTROL_SEL* register above).
    // BIT#_GRP selects 1 of 8 groups
    // BIT#_SIG selects 1 of the 8 signals from that selected group

    idxCore = 0;
    idxQctl = 0;

    for (index = 0; index < pSM->SMCountersAdded; index++) {
        switch(pSM->pmUnitId[index]) {
        case PM_UNIT_SMQCTL:
            switch(idxQctl) {
        case 0:
            offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER0_CONTROL;
            break;
        case 1:
            offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER1_CONTROL;
            break;
        case 2:
            offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER2_CONTROL;
            break;
        case 3:
            offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER3_CONTROL;
            break;
            }
            idxQctl++;
            break;

        case PM_UNIT_SMCORE:
        case PM_UNIT_MIO:
            switch(idxCore) {
        case 0:
            offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER4_CONTROL;
            break;
        case 1:
            offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER5_CONTROL;
            break;
        case 2:
            offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER6_CONTROL;
            break;
        case 3:
            offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER7_CONTROL;
            break;
            }
            idxCore++;
            break;
        }
        value[count++]  = pSM->perfEventInfo[index];
    }
    // Performance Counter - edge
    // EDGE0 - 0:0, EDGE1 - 4:4, EDGE2 - 8:8,   EDGE3 - 12:11
    // MODE0 - 2:1, MODE1 - 6:5, MODE2 - 10:9,  MODE3 - 14:13
    // set EDGE = DISABLE and MODE = COUNT

    offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL0;
    value[count++] = enableQctl;
    offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL5;
    value[count++] = enableCore;

    CU_ASSERT(count <= numRegs);
    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, count, offset, value, 0);
    if (status != CUDA_SUCCESS) {
        goto EXIT;
    }
EXIT:
    if(offset) {
        free(offset);
    }
    if(value) {
        free(value);
    }
    return status;
}


static CUresult resetPMSMInternal(CUeventGroup *pEventGroup) {
    CUresult status = CUDA_SUCCESS;
    NvU32 funcQctl[2] = {0};
    NvU32 funcCore[2] = {0};
    NvU32 idxQctl = 0, idxCore = 0;
    NvU32 index = 0;
    CUSMCtrInfo     *pSM = NULL;
    CUresult (*resetSmpcRegs)(CUeventGroup *pEventGroup, NvU32 *funcQctl, NvU32 *funcCore);

    CU_TRACE_FUNCTION();

    // Call the broadcase version if profileAll option is selected:
    if(pEventGroup->profileAll) {
        resetSmpcRegs = &resetPMSM_bc;
    }
    // Else. call the unicast version:
    else {
        resetSmpcRegs = &resetPMSM;
    }

    // Compute the function values to be written in the FUNC registers after cleaing the final value registers:
    idxCore = 0;
    idxQctl = 0;
    pSM = pEventGroup->arch.maxwellEventGroup->pSM;

    for (index = 0; index < pSM->SMCountersAdded; index++) {
        switch(pSM->pmUnitId[index]) {
        case PM_UNIT_SMQCTL:
            if(idxQctl & 1) {
                funcQctl[idxQctl>>1] |= pSM->function[index] << 16;
            }
            else {
                funcQctl[idxQctl>>1] |= pSM->function[index];
            }
            idxQctl++;
            break;
        case PM_UNIT_SMCORE:
        case PM_UNIT_MIO:
            if(idxCore & 1) {
                funcCore[idxCore>>1] |= pSM->function[index] << 16;
            }
            else {
                funcCore[idxCore>>1] |= pSM->function[index];
            }
            idxCore++;
            break;
        }
    }
    status = (*resetSmpcRegs)(pEventGroup, funcQctl, funcCore);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Error re-setting the SMPC final value registers\n"));
    }
    return status;
}

static CUresult resetPMSM(CUeventGroup *pEventGroup, NvU32 *funcQctl, NvU32 *funcCore) {
    CUresult status = CUDA_SUCCESS;
    NvU32 gpcTarget = 0, tpcTarget = 0, gpcId = 0, tpcId = 0, smId = 0, count = 0;
    NvU32 *offset = NULL;
    NvU32 *value = NULL;

    CU_TRACE_FUNCTION();

    //(#quadCounters * 5) : 4 counter values + 1 status register per quad + 2 * numFuncRegisters
    //Allocate memory of size = ((#quadCounters * 5) + #coreCounters + 1 + 2 * numFuncRegisters) * #SMs * sizeof(NvU32))
    offset = (NvU32 *)malloc((CU_PROF_SM_CORE_PROFILED_MAX + 1 + CU_PROF_SM_QUAD_PROFILED_MAX * 5 + 2 * NUM_FUNC_REGISTERS) * pEventGroup->instanceCountAvail * sizeof(NvU32));
    value = (NvU32 *)calloc((CU_PROF_SM_CORE_PROFILED_MAX + 1 + CU_PROF_SM_QUAD_PROFILED_MAX * 5 + 2 * NUM_FUNC_REGISTERS) * pEventGroup->instanceCountAvail, sizeof(NvU32));
    if(!(offset && value)) {
        CU_ERROR_PRINT(("Error allocating memory for offset-value arrays.\n"));
        status = (CUresult)CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    for(gpcId = 0; gpcId < pEventGroup->arch.maxwellEventGroup->gpcCount; gpcId++)
    {
        for(tpcId = 0; tpcId < pEventGroup->arch.maxwellEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
        {
            if(pEventGroup->arch.maxwellEventGroup->pmUnitMask & (1<<smId))
            {

                gpcTarget = gpcId;
                tpcTarget = tpcId;

                /****************************************************************
                 Clear out the FUNC registers before writing to the
                     final value registers:
                ****************************************************************/
                offset[count++]  = NV_SM_DSM_PERF_COUNTER_CONTROL1(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER_CONTROL2(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER_CONTROL3(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER_CONTROL4(gpcTarget, tpcTarget);

                /****************************************************************
                As the status registers will now be used to store the higher
                8 bits of counter values, we will need to clear them off.
                ****************************************************************/
                // For qctl counters:
                offset[count++]  = NV_SM_DSM_PERF_COUNTER0_S0(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER1_S0(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER2_S0(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER3_S0(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER0_S1(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER1_S1(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER2_S1(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER3_S1(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER0_S2(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER1_S2(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER2_S2(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER3_S2(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER0_S3(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER1_S3(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER2_S3(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER3_S3(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER_STATUS_S0(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER_STATUS_S1(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER_STATUS_S2(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER_STATUS_S3(gpcTarget, tpcTarget);

                // For core counters:
                offset[count++]  = NV_SM_DSM_PERF_COUNTER4(gpcTarget, tpcTarget);
                offset[count++] = NV_SM_DSM_PERF_COUNTER_STATUS1(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER5(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER6(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER7(gpcTarget, tpcTarget);

                /****************************************************************
                 Set the FUNC registers after writing to the
                     final value registers:
                ****************************************************************/

                offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL1(gpcTarget, tpcTarget);
                value[count++] = funcQctl[0];
                offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL2(gpcTarget, tpcTarget);
                value[count++] = funcQctl[1];
                offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL3(gpcTarget, tpcTarget);
                value[count++] = funcCore[0];
                offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL4(gpcTarget, tpcTarget);
                value[count++] = funcCore[1];

            }
            smId++;
        }
    }
    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, count, offset, value, 0);
    if (status != CUDA_SUCCESS) {
        goto EXIT;
    }

    free(offset);
    free(value);

    return status;
EXIT:
    if (offset) {
        free (offset);
    }
    if (value) {
        free (value);
    }
    return status;
}

static CUresult resetPMSM_bc(CUeventGroup *pEventGroup, NvU32 *funcQctl, NvU32 *funcCore) {
    CUresult status = CUDA_SUCCESS;
    NvU32 count = 0;
    NvU32 *offset = NULL;
    NvU32 *value = NULL;

    CU_TRACE_FUNCTION();

    //(#quadCounters * 5) : 4 counter values + 1 status register per quad + 2 * numFuncRegisters
    //Allocate memory of size = ((#quadCounters * 5) + #coreCounters + 1 + 2 * numFuncRegisters) * sizeof(NvU32))
    offset = (NvU32 *)malloc((CU_PROF_SM_CORE_PROFILED_MAX + 1 + CU_PROF_SM_QUAD_PROFILED_MAX * 5 + 2 * NUM_FUNC_REGISTERS) * sizeof(NvU32));
    value = (NvU32 *)calloc((CU_PROF_SM_CORE_PROFILED_MAX + 1 + CU_PROF_SM_QUAD_PROFILED_MAX * 5 + 2 * NUM_FUNC_REGISTERS), sizeof(NvU32));
    if(!(offset && value)) {
        CU_ERROR_PRINT(("Error allocating memory for offset-value arrays.\n"));
        status = (CUresult)CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    /****************************************************************
        Clear out the FUNC registers before writing to the
            final value registers:
    ****************************************************************/
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL1;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL2;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL3;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL4;

    /****************************************************************
    As the status registers will now be used to store the higher
    8 bits of counter values, we will need to clear them off.
    ****************************************************************/
    // For qctl counters:
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER0_S0;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER1_S0;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER2_S0;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER3_S0;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER0_S1;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER1_S1;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER2_S1;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER3_S1;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER0_S2;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER1_S2;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER2_S2;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER3_S2;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER0_S3;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER1_S3;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER2_S3;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER3_S3;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_STATUS_S0;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_STATUS_S1;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_STATUS_S2;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_STATUS_S3;

    // For core counters:
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER4;
    offset[count++] = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_STATUS1;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER5;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER6;
    offset[count++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER7;

    /****************************************************************
        Set the FUNC registers after writing to the
            final value registers:
    ****************************************************************/

    offset[count]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL1;
    value[count++] = funcQctl[0];
    offset[count]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL2;
    value[count++] = funcQctl[1];
    offset[count]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL3;
    value[count++] = funcCore[0];
    offset[count]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL4;
    value[count++] = funcCore[1];

    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, count, offset, value, 0);
    if (status != CUDA_SUCCESS) {
        goto EXIT;
    }

    free(offset);
    free(value);

    return status;
EXIT:
    if (offset) {
        free (offset);
    }
    if (value) {
        free (value);
    }
    return status;
}

static CUresult logPMCountersSMInternal(CUeventGroup *pEventGroup, NvU8 *highValuesQuad, NvU8 *highValuesCore) {
    CUresult status = CUDA_SUCCESS;
    NvU32 gpcId = 0, tpcId = 0, smId = 0;
    NvU32 offset[30] = {0};
    NvU64 counterValuesQctl[4] = {0}, counterValuesCore[4] = {0};
    NvU32 counterValues[30] = {0}, count;
    NvU8 i = 0, j = 0;
    NvU32 idxQctl = 0, idxCore = 0;
    CUSMCtrInfo     *pSM = NULL;

    CU_TRACE_FUNCTION();
    pSM = pEventGroup->arch.maxwellEventGroup->pSM;

    for(gpcId = 0; gpcId < pEventGroup->arch.maxwellEventGroup->gpcCount; gpcId++)
    {
        for(tpcId = 0; tpcId < pEventGroup->arch.maxwellEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
        {
            if(pEventGroup->arch.maxwellEventGroup->pmUnitMask & (1<<smId))
            {
                count = 0;
                /*********************************************************************
                The status registers will now contain the higher 8 bits of the
                counter values.
                0:7   - counter 1   8:15 - counter 2
                16:23 - counter 3   24:31 - counter 4
                *********************************************************************/
                if (pSM->qctlCount) {
                    /*********************
                    Quad 0:
                    *********************/
                    // HI Register:
                    offset[count++] = NV_SM_DSM_PERF_COUNTER_STATUS_S0(gpcId, tpcId);
                    // LO Register:
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER0_S0(gpcId, tpcId);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER1_S0(gpcId, tpcId);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER2_S0(gpcId, tpcId);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER3_S0(gpcId, tpcId);
                    // HI Register:
                    offset[count++] = NV_SM_DSM_PERF_COUNTER_STATUS_S0(gpcId, tpcId);

                    /*********************
                    Quad 1:
                    *********************/
                    // HI Register:
                    offset[count++] = NV_SM_DSM_PERF_COUNTER_STATUS_S1(gpcId, tpcId);
                    // LO Register:
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER0_S1(gpcId, tpcId);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER1_S1(gpcId, tpcId);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER2_S1(gpcId, tpcId);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER3_S1(gpcId, tpcId);
                    // HI Register:
                    offset[count++] = NV_SM_DSM_PERF_COUNTER_STATUS_S1(gpcId, tpcId);

                    /*********************
                    Quad 2:
                    *********************/
                    // HI Register:
                    offset[count++] = NV_SM_DSM_PERF_COUNTER_STATUS_S2(gpcId, tpcId);
                    // LO Register:
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER0_S2(gpcId, tpcId);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER1_S2(gpcId, tpcId);
                    offset[count++] = NV_SM_DSM_PERF_COUNTER2_S2(gpcId, tpcId);
                    offset[count++] = NV_SM_DSM_PERF_COUNTER3_S2(gpcId, tpcId);
                    // HI Register:
                    offset[count++] = NV_SM_DSM_PERF_COUNTER_STATUS_S2(gpcId, tpcId);

                    /*********************
                    Quad 3:
                    *********************/
                    // HI Register:
                    offset[count++] = NV_SM_DSM_PERF_COUNTER_STATUS_S3(gpcId, tpcId);
                    // LO Register:
                    offset[count++] = NV_SM_DSM_PERF_COUNTER0_S3(gpcId, tpcId);
                    offset[count++] = NV_SM_DSM_PERF_COUNTER1_S3(gpcId, tpcId);
                    offset[count++] = NV_SM_DSM_PERF_COUNTER2_S3(gpcId, tpcId);
                    offset[count++] = NV_SM_DSM_PERF_COUNTER3_S3(gpcId, tpcId);
                    // HI Register:
                    offset[count++] = NV_SM_DSM_PERF_COUNTER_STATUS_S3(gpcId, tpcId);
                }

                if (pSM->coreCount) {
                    // HI Register:
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER_STATUS1(gpcId, tpcId);
                    // LO Register:
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER4(gpcId, tpcId);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER5(gpcId, tpcId);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER6(gpcId, tpcId);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER7(gpcId, tpcId);
                    // HI Register:
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER_STATUS1(gpcId, tpcId);
                }
                // read back perf counter values:
                status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, count, offset, counterValues, 0);
                if (CUDA_SUCCESS != status) {
                    goto EXIT;
                }
                if (pSM->qctlCount) {
                    NvU8 highValues1[4] = {0}, highValues2[4] = {0};
                    NvU32 shiftIdx = 0, regIdx = 0, counterValuesTemp[4] = {0};
                    NvU64 highValuesTemp[4] = {0};
                    cuosMemset(counterValuesQctl, 0, sizeof(NvU64)*4);
                    /***************************************************************************
                    - The while loop will run four times i.e. once for each quadrant
                    - Each quad will require 6 registers to be read
                    1 hi value register
                    4 registers having lo 32 bit counter values for each of the quad counter
                    1 hi value register again to take into account the wrap around case of
                    the hi value register
                    ***************************************************************************/
                    while (regIdx < 24) {
                        /*********************************************************************************
                        - Extract the higher 8 bits of signal value from  the status register
                        - The status register will contain higher 8 bits of all the four quad signals.
                        0-7 : quadSig1       8-15:quadSig2
                        16-23: quadSig3      24-31:quadSig4
                        - Store these 8 bits individually in the temporary array
                        *********************************************************************************/
                        for (j = 0; j < CU_PROF_SM_QUAD_PROFILED_MAX; j++) {
                            shiftIdx = j*8;
                            highValues1[j] = (NvU8)((counterValues[regIdx] & (0xFF << shiftIdx)) >> shiftIdx);
                        }
                        regIdx++;
                        /*********************************************************************************
                        - Store the lo 32 bits of the counters
                        *********************************************************************************/
                        for(j = 0; j < CU_PROF_SM_QUAD_PROFILED_MAX; j++) {
                            counterValuesTemp[j] = counterValues[regIdx++];
                        }
                        /*********************************************************************************
                        - Extract the higher 8 bits of signal value from  the status register
                        - The status register will contain higher 8 bits of all the four quad signals.
                        0-7 : quadSig1       8-15:quadSig2
                        16-23: quadSig3      24-31:quadSig4
                        - Store these 8 bits individually in the temporary array
                        *********************************************************************************/
                        for (j = 0; j < CU_PROF_SM_QUAD_PROFILED_MAX; j++) {
                            shiftIdx = j*8;
                            highValues2[j] = (NvU8)((counterValues[regIdx] & (0xFF << shiftIdx)) >> shiftIdx);
                        }
                        regIdx++;
                        /*********************************************************************************
                        - As the hi and lo bits for the signal values will be read in different cycles,
                        there is a possibility if the hi bits changing till we read them. Hence,
                        we read them in the order hi-lo-hi.
                        - Convert the lo value into signed integer. Compare the lo value
                        If the lo value is positive, take the hi bits read in the next cycle. Else,
                        take the hi bits read from the previous cycle.
                        *********************************************************************************/
                        for(j = 0; j < CU_PROF_SM_QUAD_PROFILED_MAX; j++) {
                            highValuesTemp[j] = (NvU64)((signed int)counterValuesTemp[j] < 0) ? highValues1[j] : highValues2[j];
                        }
                        /*********************************************************************************
                        - left shift the Hi value by 32 (as these are the higher 8 bits out of the 40
                        bit counter value
                        - OR the hi bits with the lo 32 bits to form the 40 bit counter value.
                        *********************************************************************************/
                        for(j = 0; j < CU_PROF_SM_QUAD_PROFILED_MAX; j++) {
                            counterValuesQctl[j] += (NvU64)(((NvU64)counterValuesTemp[j]) | (highValuesTemp[j] << 32));
                            // Update the array holding the higher 8 bits only if the value is 0xFF:
                            highValuesQuad[j] = ((NvU8)highValuesTemp[j] == COUNTER_OVERFLOW_VALUE) ? COUNTER_OVERFLOW_VALUE : highValuesQuad[j];
                        }
                    }
                }
                if (pSM->coreCount) {
                    NvU32 shiftIdx, regIdx = pSM->qctlCount ? 24 : 0, counterValuesTemp[4] = {0};
                    NvU8 highValues1[4] = {0}, highValues2[4] = {0};
                    NvU64 highValuesTemp[4] = {0};
                    for(j = 0;j < CU_PROF_SM_CORE_PROFILED_MAX; j++) {
                        shiftIdx = (j*8);
                        highValues1[j] = (NvU8)((counterValues[regIdx] & (0xFF << shiftIdx)) >> shiftIdx);
                    }
                    regIdx++;
                    for (j = 0;j < CU_PROF_SM_CORE_PROFILED_MAX; j++) {
                        counterValuesCore[j] = (NvU64)counterValues[regIdx++];
                    }
                    /*********************************************************************************
                    - Extract the higher 8 bits of signal value from  the status register
                    - The status register will contain higher 8 bits of all the four quad signals.
                    0-7 : quadSig1       8-15:quadSig2
                    16-23: quadSig3      24-31:quadSig4
                    - Store these 8 bits individually in the temporary array
                    *********************************************************************************/
                    for(j = 0;j < CU_PROF_SM_CORE_PROFILED_MAX; j++) {
                        shiftIdx = (j*8);
                        highValues2[j] = (NvU8)((counterValues[regIdx] & (0xFF << shiftIdx)) >> shiftIdx);
                    }
                    /*********************************************************************************
                    - As the hi and lo bits for the signal values will be read in different cycles,
                    there is a possibility if the hi bits changing till we read them. Hence,
                    we read them in the order hi-lo-hi.
                    - Convert the lo value into signed integer. Compare the lo value
                    If the lo value is positive, take the hi bits read in the next cycle. Else,
                    take the hi bits read from the previous cycle.
                    *********************************************************************************/
                    for(j = 0; j < CU_PROF_SM_CORE_PROFILED_MAX; j++) {
                        highValuesTemp[j] = (NvU64)((signed int)counterValuesTemp[j] < 0) ? highValues1[j] : highValues2[j];
                    }
                    /*********************************************************************************
                    - left shift the Hi value by 32 (as these are the higher 8 bits out of the 40
                    bit counter value
                    - OR the hi bits with the lo 32 bits to form the 40 bit counter value.
                    *********************************************************************************/
                    for(j = 0; j < CU_PROF_SM_CORE_PROFILED_MAX; j++) {
                        counterValuesCore[j] += (highValuesTemp[j] << 32);
                        // Update the array holding the higher 8 bits only if the value is 0xFF:
                        highValuesCore[j] = ((NvU8)highValuesTemp[j] == COUNTER_OVERFLOW_VALUE) ? COUNTER_OVERFLOW_VALUE : highValuesCore[j];
                    }
                }
                idxQctl = 0;
                idxCore = 0;

                // rearrange counter values
                for(i=0; i<pSM->SMCountersAdded; i++) {
                    switch (pSM->pmUnitId[i]) {
                    case PM_UNIT_SMQCTL:
                        *(pSM->values +pSM->SMCountersAdded * smId + i) = counterValuesQctl[idxQctl];
                        idxQctl++;
                        break;
                    case PM_UNIT_SMCORE:
                    case PM_UNIT_MIO:
                        *(pSM->values + pSM->SMCountersAdded * smId + i) = counterValuesCore[idxCore];
                        idxCore++;
                        break;
                    }
                }
            }
            smId++;
        }
    }

EXIT:
    return status;
}

void maxwellPerfmonStartCounters(CUnvCurrent** nvCurrent_temp, CUeventGroup *pEventGroup)
{
    // Set the function values only if domanin = SMPerf
    if ((pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX) ||
        (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW) ||
        (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_SMPERF)) {
        if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_KERNEL) {
            NvU32 valueA = 0, enableValue = 0;
            NvU32 index;
            CUnvCurrent* nvCurrent = *nvCurrent_temp;

            if(pEventGroup->arch.maxwellEventGroup->pSM->qctlCount) {
                for (index = 0; index < CU_PROF_SM_QUAD_PROFILED_MAX; index++) {
                    // Zero out the counter values before starting the counters:
                    valueA = HWVALUE(B0C0, SET_SHADER_PERFORMANCE_COUNTER_VALUE, V, 0);
                    NV_PUSH_1U(B0C0, SET_SHADER_PERFORMANCE_COUNTER_VALUE(index),  valueA);
                    // Zero out the upper 8 bits of the 40-bit SMPC counter.
                    valueA = HWVALUE(B0C0, SET_SHADER_PERFORMANCE_COUNTER_VALUE_UPPER, V, 0);
                    NV_PUSH_1U(B0C0, SET_SHADER_PERFORMANCE_COUNTER_VALUE_UPPER(index),  valueA);
                }
            }
            if(pEventGroup->arch.maxwellEventGroup->pSM->coreCount) {
                for (index = CU_PROF_SM_QUAD_PROFILED_MAX; index < (CU_PROF_SM_QUAD_PROFILED_MAX+CU_PROF_SM_CORE_PROFILED_MAX); index++) {
                    // Zero out the counter values before starting the counters:
                    valueA = HWVALUE(B0C0, SET_SHADER_PERFORMANCE_COUNTER_VALUE, V, 0);
                    NV_PUSH_1U(B0C0, SET_SHADER_PERFORMANCE_COUNTER_VALUE(index),  valueA);
                    // Zero out the upper 8 bits of the 40-bit SMPC counter.
                    valueA = HWVALUE(B0C0, SET_SHADER_PERFORMANCE_COUNTER_VALUE_UPPER, V, 0);
                    NV_PUSH_1U(B0C0, SET_SHADER_PERFORMANCE_COUNTER_VALUE_UPPER(index),  valueA);
                }
            }
            // Start the counters by setting the enable bits:
            // Set the enable bits only for those slots where we are profiling counters:
            //  The countermask is 8 bit mask where lsb 4 bits specify mask for quad counters
            //        and upper 4 bits are for core. 
            //        0: Dont enable
            //        1: Enable
            if(pEventGroup->arch.maxwellEventGroup->pSM->coreCount) {
                enableValue = NV_SM_DSM_PERF_COUNTER_CONTROL_ENABLE_ENABLE >> (CU_PROF_SM_CORE_PROFILED_MAX - pEventGroup->arch.maxwellEventGroup->pSM->coreCount);
                enableValue = enableValue << CU_PROF_SM_QUAD_PROFILED_MAX;
            }
            if(pEventGroup->arch.maxwellEventGroup->pSM->qctlCount) {
                enableValue |= NV_SM_DSM_PERF_COUNTER_CONTROL_ENABLE_ENABLE >> (CU_PROF_SM_QUAD_PROFILED_MAX - pEventGroup->arch.maxwellEventGroup->pSM->qctlCount);
            }
            valueA = HWVALUE(B0C0, START_SHADER_PERFORMANCE_COUNTER, COUNTER_MASK, enableValue);
            NV_PUSH_1U(B0C0, START_SHADER_PERFORMANCE_COUNTER,  valueA);
            *nvCurrent_temp = nvCurrent;
        } else if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS){
            //Start the counters in continuous mode.
            NvU32 *value  = NULL, *offset = NULL, *writeMask = NULL;
            NvU32 count = 0, gpcId = 0, tpcId = 0, smId = 0, enableValueCore = 0, enableValueQuad = 0;
            CUresult status = CUDA_SUCCESS;

            //Allocate memory of size = (2 * #SMs * sizeof(NvU32))
            offset = (NvU32 *)malloc(2 * pEventGroup->instanceCountAvail * sizeof(NvU32));
            value = (NvU32 *)calloc(2 * pEventGroup->instanceCountAvail, sizeof(NvU32));
            writeMask = (NvU32 *)calloc(2 * pEventGroup->instanceCountAvail, sizeof(NvU32));
            if(!(offset && value && writeMask)) {
                CU_ERROR_PRINT(("Error allocating memory for offset-value arrays.\n"));
                goto EXIT;
            }
            // Set the enable bits only for those slots where we are profiling counters:
            if(pEventGroup->arch.maxwellEventGroup->pSM->coreCount) {
                enableValueCore = NV_SM_DSM_PERF_COUNTER_CONTROL_ENABLE_ENABLE >> (CU_PROF_SM_CORE_PROFILED_MAX - pEventGroup->arch.maxwellEventGroup->pSM->coreCount);
            }
            if(pEventGroup->arch.maxwellEventGroup->pSM->qctlCount) {
                enableValueQuad = NV_SM_DSM_PERF_COUNTER_CONTROL_ENABLE_ENABLE >> (CU_PROF_SM_QUAD_PROFILED_MAX - pEventGroup->arch.maxwellEventGroup->pSM->qctlCount);
            }
            for(gpcId = 0; gpcId < pEventGroup->arch.maxwellEventGroup->gpcCount; gpcId++)
            {
                for(tpcId = 0; tpcId < pEventGroup->arch.maxwellEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
                {
                    if(pEventGroup->arch.maxwellEventGroup->pmUnitMask & (1<<smId))
                    {
                        if(pEventGroup->arch.maxwellEventGroup->pSM->qctlCount) {
                            value[count]  = DRF_REPLACE(value[count], enableValueQuad, NV_SM_DSM_PERF_COUNTER_CONTROL_ENABLE);
                            offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL0(gpcId, tpcId);
                            writeMask[count++] = ENABLE_BITS_MASK;
                        }
                        if(pEventGroup->arch.maxwellEventGroup->pSM->coreCount) {
                            value[count]  = DRF_REPLACE(value[count], enableValueCore, NV_SM_DSM_PERF_COUNTER_CONTROL_ENABLE);
                            offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL5(gpcId, tpcId);
                            writeMask[count++] = ENABLE_BITS_MASK;
                        }
                    }
                    smId++;
                }
            }
            CU_ASSERT(count <= (2 * pEventGroup->instanceCountAvail));
            status = PRIWRITEMASKED32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, count, offset, value, writeMask, 0);
            CU_ASSERT(status == CUDA_SUCCESS);
EXIT:
            if(offset) {
                free(offset);
            }
            if(value) {
                free(value);
            }
            if(writeMask) {
                free(writeMask);
            }
        }
    }
}

void maxwellPerfmonStopCounters(CUnvCurrent** nvCurrent_temp, CUeventGroup *pEventGroup)
{
    // Reset the function values only if domanin = SMPerf
    if ((pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX) ||
        (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW) ||
        (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_SMPERF)) {
            if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_KERNEL) {
                CUnvCurrent* nvCurrent = *nvCurrent_temp;
                NvU32 valueA = 0, disableValue = 0;
                // Set the disable bits only for those slots where we are profiling counters:
                //  The countermask is 8 bit mask where lsb 4 bits specify mask for quad counters
                //        and upper 4 bits are for core. 
                //        0: Dont disable
                //        1: Disable
                if(pEventGroup->arch.maxwellEventGroup->pSM->coreCount) {
                    disableValue = NV_SM_DSM_PERF_COUNTER_CONTROL_ENABLE_ENABLE >> (CU_PROF_SM_CORE_PROFILED_MAX - pEventGroup->arch.maxwellEventGroup->pSM->coreCount);
                    disableValue = disableValue << CU_PROF_SM_QUAD_PROFILED_MAX;
                }
                if(pEventGroup->arch.maxwellEventGroup->pSM->qctlCount) {
                    disableValue |= NV_SM_DSM_PERF_COUNTER_CONTROL_ENABLE_ENABLE >> (CU_PROF_SM_QUAD_PROFILED_MAX - pEventGroup->arch.maxwellEventGroup->pSM->qctlCount);
                }
                valueA = HWVALUE(B0C0, STOP_SHADER_PERFORMANCE_COUNTER, COUNTER_MASK, disableValue);
                NV_PUSH_1U(B0C0, STOP_SHADER_PERFORMANCE_COUNTER,  valueA);
                *nvCurrent_temp = nvCurrent;
            } else {
                //Stop the counters in continuous mode. SM counters keep running unless we set the ENABLE bits to 0.
                NvU32 *value  = NULL, *offset = NULL, *writeMask = NULL;
                NvU32 count = 0, gpcId = 0, tpcId = 0, smId = 0;
                CUresult status = CUDA_SUCCESS;

                //Allocate memory of size = (2 * #SMs * sizeof(NvU32))
                offset = (NvU32 *)malloc(2 * pEventGroup->instanceCountAvail * sizeof(NvU32));
                value = (NvU32 *)calloc(2 * pEventGroup->instanceCountAvail, sizeof(NvU32));
                writeMask = (NvU32 *)calloc(2 * pEventGroup->instanceCountAvail, sizeof(NvU32));
                if(!(offset && value && writeMask)) {
                    CU_ERROR_PRINT(("Error allocating memory for offset-value arrays.\n"));
                    goto EXIT;
                }
                for(gpcId = 0; gpcId < pEventGroup->arch.maxwellEventGroup->gpcCount; gpcId++)
                {
                    for(tpcId = 0; tpcId < pEventGroup->arch.maxwellEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
                    {
                        if(pEventGroup->arch.maxwellEventGroup->pmUnitMask & (1<<smId))
                        {
                            if(pEventGroup->arch.maxwellEventGroup->pSM->qctlCount) {
                                offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL0(gpcId, tpcId);
                                writeMask[count++] = ENABLE_BITS_MASK;
                            }
                            if(pEventGroup->arch.maxwellEventGroup->pSM->coreCount) {
                                offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL5(gpcId, tpcId);
                                writeMask[count++] = ENABLE_BITS_MASK;
                            }
                        }
                        smId++;
                    }
                }
                CU_ASSERT(count <= (2 * pEventGroup->instanceCountAvail));
                status = PRIWRITEMASKED32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, count, offset, value, writeMask, 0);
                CU_ASSERT(status == CUDA_SUCCESS);
EXIT:
                if(offset) {
                    free(offset);
                }
                if(value) {
                    free(value);
                }
                if(writeMask) {
                    free(writeMask);
                }
            }
    }
}

CUprofResult CUDAAPI maxwellPerfmonPCSamplingRegisterReadCallback(CUctx *ctx,
                                                                  CUprofPCSamplingReadDataCallback pfnCallback,
                                                                  void* pUserData) {
    CUprofResult status = CUPROF_SUCCESS;
    if (!ctx->pmNew) {
        return CUPROF_ERROR_UNKNOWN;
    }
    ctx->pmNew->pcSamplingReadDataCallback = pfnCallback;
    ctx->pmNew->userData = pUserData;
    return status;
}

#ifndef NV_MODS
static void deleteBuffNode(void *element, void *param) {
    CUprofBuff *tempBuff;
    tempBuff = (CUprofBuff *) element;
    free(tempBuff->buff);
}
#endif

// tools_shared code is not accessible on mods
#if defined(NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200) && !defined(NV_MODS)
static CUprofResult PCSamplingHashMapToBuffer(CUctx *ctx, NvU32 **buffer, size_t *bufferSize, NvU32 droppedRecords) {
    tHashMapItr *itr = NULL;
    tHashMapKey_t key;
    uint32_t *data  = NULL;
    NvU32 numValidPairs = 0, i = 0, idx = 0, bufferIdx = 0, validCirIndex = 0, totalRecords = 0;
    tHashMap *samplingDataHashMap;

    /*******************************************************************************
                                     BUFFER FORMAT:
                        |-----PAIR 1------|-----PAIR 2-----|    |-----PAIR n-----|
     PC1 #| VALID PAIRS#| CIR1 #| SAMPLES#|CIR2 #| SAMPLES#| ...|CIRn #| SAMPLES#
     PC2 #| VALID PAIRS#| CIR1 #| SAMPLES#|CIR2 #| SAMPLES#| ...|CIRn #| SAMPLES#
     ...
     PCn #| VALID PAIRS#| CIR1 #| SAMPLES#|CIR2 #| SAMPLES#| ...|CIRn #| SAMPLES#
    ********************************************************************************/
    samplingDataHashMap = (tHashMap *) ctx->device->state.profilerState.samplingDataHashMap;

    if (!samplingDataHashMap) {
        return CUPROF_ERROR_UNKNOWN;
    }

    /* Allocating Size to Buffer
     * The total size will be (total_no_of_pc * sizeof(NvU32) * (MAX_CIR * 2 + 2(storing PC & num_valid_cir for each PC)) 
                                            + (sizeof(NvU32) * 2(storing totalRecords & droppedRecords at the end of the buffer)))
     * The above allocated memory will only be used completely when all the PC's have non zero samples for all stall reasons.
     * In all the other cases the remaining memory is not used
     */
    *buffer = (NvU32 *) malloc(toolsHashMapSize(samplingDataHashMap) * sizeof(NvU32) * (CUPROF_WARP_CANT_ISSUE_MAX_CIR * 2 + 2) + ( sizeof(NvU32) * 2) );

    // Iterate through the hashmap and dump data in required format in the
    //     buffer for passing it to CUPTI:
    itr = toolsHashMapGetIterator(samplingDataHashMap);
    for (; itr; itr = toolsHashMapGetNext(samplingDataHashMap,itr)) {
        numValidPairs = 0; idx = 0;
        data = (uint32_t *)toolsHashMapGetEntry(itr);
        key = toolsHashMapGetKey(itr);
        (*buffer)[bufferIdx++] = (NvU32)key;
        validCirIndex = bufferIdx++;   // This index is recorded in variable validCirIndex and is used later to fill the numValidCirs which is calculated later.
        for(i=CUPROF_WARP_CANT_ISSUE_DRAIN ; i<CUPROF_WARP_CANT_ISSUE_MAX_CIR; i++) {
            if(data[i] != 0) {
                numValidPairs++;
                (*buffer)[bufferIdx++] = i;
                (*buffer)[bufferIdx++] = data[i];
                totalRecords += data[i];
            }
        }
        free(data);

        (*buffer)[validCirIndex] = numValidPairs;
    }
    if(bufferIdx == 0) {
        // return from here if there are no samples for the kernel
        goto EXIT;
    }
    (*buffer)[bufferIdx++] = totalRecords + droppedRecords;
    (*buffer)[bufferIdx++] = droppedRecords;
   /*******************************************************************************
    Print the buffer created (Keeping commented for now for debug purposes only):
    i = 0; idx = 0;
    while (i< (bufferIdx - 2)) {
        printf("\nPC: 0x%.08x\t",(*buffer)[i++]);
        numValidPairs = (*buffer)[i];
        printf("NUM PAIRS:%d\t",(*buffer)[i++]);
        for(idx=0 ; idx<numValidPairs ; idx++) {
            printf("%d:", (*buffer)[i++]);
            printf("%d\t", (*buffer)[i++]);
        }
    }
    *******************************************************************************/
    *bufferSize = bufferIdx * sizeof(NvU32);
EXIT:
    return CUPROF_SUCCESS;
}
#else
static CUprofResult PCSamplingHashMapToBuffer(CUctx *ctx, NvU32 **buffer, size_t *bufferSize, NvU32 droppedRecords) {
    return CUPROF_SUCCESS;
}
#endif

CUprofResult maxwellConsumePMABuffer(CUctx *ctx) 
{

    CUprofResult status = CUPROF_SUCCESS;
#ifndef NV_MODS
    ctx->device->state.profilerState.samplingDataHashMap
                      = (void*) toolsHashMapNew(toolsUint32HashFun, toolsUint64EqualFun, 64);
#endif

    status = startStreaming(ctx);
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("Failed to start streaming\n"));
    }

    if(!ctx->device->state.profilerState.samplingThreadReadData) {
        int cuosStatus = CUOS_SUCCESS;
        ctx->device->state.profilerState.totalDroppedRecords = 0;
        ctx->device->state.profilerState.terminateSamplingThread = 0;
        ctx->device->state.profilerState.terminateSamplingParseDataThread = 0;
        cuiMutexInitialize(&ctx->device->state.profilerState.buffListMutex, CUI_MUTEX_ORDER_TERMINAL, CUI_MUTEX_DEFAULT);
#ifndef NV_MODS
        ctx->device->state.profilerState.buffList = (void *) toolsListNew();
#endif
        if (!ctx->device->state.profilerState.buffList) {
            status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
            goto EXIT;
        }

        // create the readSemaphore to signal the worker thread at the end to flush data
        cuosStatus = cuosSemaphoreCreate(&ctx->device->state.profilerState.readSemaphore, 0);
        if (cuosStatus) {
             CU_ASSERT(0);
             goto EXIT;
        }

        cuosStatus = cuosThreadCreate(&ctx->device->state.profilerState.samplingThreadReadData, maxwellPerfmonPCSamplingReadData, (void *) ctx);
        if (CUOS_SUCCESS != cuosStatus) {
            CU_ASSERT(0);
            status = CUPROF_ERROR_UNKNOWN;
            goto EXIT;
        }
        cuosStatus = cuosThreadCreate(&ctx->device->state.profilerState.samplingThreadParseData, maxwellPerfmonPCSamplingParseData, (void *) ctx);
        if (CUOS_SUCCESS != cuosStatus) {
            CU_ASSERT(0);
            status = CUPROF_ERROR_UNKNOWN;
            goto EXIT;
        }
    }

EXIT:
#ifndef BUG_1259185_FIXED
    if (ctx->device->dmalType != CU_DMAL_AMODEL) {
        if (status != CUPROF_SUCCESS) {
            if(ctx->device->state.profilerState.samplingThreadReadData) {
                int retCode = 0;
                ctx->device->state.profilerState.terminateSamplingThread = 1;
                cuosThreadJoin(ctx->device->state.profilerState.samplingThreadReadData, &retCode);
                if (retCode != 0) {
                    CU_ERROR_PRINT(("Failed to join sampling thread\n"));
                }
                ctx->device->state.profilerState.samplingThreadReadData = NULL;
           }
            if(ctx->device->state.profilerState.samplingThreadParseData) {
                int retCode = 0;
                cuosThreadJoin(ctx->device->state.profilerState.samplingThreadParseData, &retCode);
                if (retCode != 0) {
                    CU_ERROR_PRINT(("Failed to join sampling thread\n"));
                }
                ctx->device->state.profilerState.samplingThreadParseData = NULL;
            }
            cuosSemaphoreDestroy(&ctx->device->state.profilerState.readSemaphore);
            if (ctx->device->state.profilerState.buffList) {
                cuiMutexLock(&ctx->device->state.profilerState.buffListMutex);
#ifndef NV_MODS
                toolsListDelete((tList *) ctx->device->state.profilerState.buffList, deleteBuffNode, NULL);
#endif
                ctx->device->state.profilerState.buffList = NULL;
                cuiMutexUnlock(&ctx->device->state.profilerState.buffListMutex);
            }

            cuiMutexDeinitialize(&ctx->device->state.profilerState.buffListMutex);
        }
    }
#endif
    return status;
}

CUprofResult maxwellReadIntermdiateBuffer(CUctx *ctx)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *buffer = NULL;
    size_t bufferSize = 0;

    status = stopStreaming(ctx);
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("Failed to stop streaming\n"));
    }

    if (ctx->device->state.profilerState.samplingThreadReadData) {
        int retCode = 0;
        cuosSemaphoreSignal(&ctx->device->state.profilerState.readSemaphore);
        cuosSleep(SAMPLING_TIMEOUT*2);
        ctx->device->state.profilerState.terminateSamplingThread = 1;

        cuosThreadJoin(ctx->device->state.profilerState.samplingThreadReadData, &retCode);
        if (retCode != 0) {
            CU_ERROR_PRINT(("Failed to join sampling thread\n"));
            status = (CUprofResult)retCode;
        }
        ctx->device->state.profilerState.samplingThreadReadData = NULL;
        if (ctx->device->state.profilerState.samplingThreadParseData) {
            cuosThreadJoin(ctx->device->state.profilerState.samplingThreadParseData, &retCode);
            if (retCode != 0) {
                CU_ERROR_PRINT(("Failed to join sampling thread\n"));
                status = (CUprofResult)retCode;
            }
            ctx->device->state.profilerState.samplingThreadParseData = NULL;
        }
        cuosSemaphoreDestroy(&ctx->device->state.profilerState.readSemaphore);
        if (ctx->device->state.profilerState.buffList) {
            cuiMutexLock(&ctx->device->state.profilerState.buffListMutex);
#ifndef NV_MODS
            toolsListDelete((tList *) ctx->device->state.profilerState.buffList, deleteBuffNode, NULL);
#endif
            ctx->device->state.profilerState.buffList = NULL;
            cuiMutexUnlock(&ctx->device->state.profilerState.buffListMutex);
        }

        cuiMutexDeinitialize(&ctx->device->state.profilerState.buffListMutex);
    }

    // Dump data into compact buffer which can be passed to CUPTI:
    PCSamplingHashMapToBuffer(ctx, &buffer, &bufferSize, ctx->device->state.profilerState.totalDroppedRecords);

    // Call the callBack function registered:
    ctx->pmNew->pcSamplingReadDataCallback(buffer, bufferSize, ctx->pmNew->userData);

    // Free the memory allocated for hashMap and buffer used for reading the sampling records from hardware:
    if (buffer) {
        free(buffer);
    }
#ifndef NV_MODS
    toolsHashMapDelete((tHashMap*)ctx->device->state.profilerState.samplingDataHashMap, NULL, NULL);
#endif
    return status;
}

CUprofResult maxwellBeginPCSampling(CUctx *ctx)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *value = NULL;
    NvU32 count = 0, size = 0, numReg = 0;
    NvU32 domainRegOffset = 0, chipIdx = 0, maxInstances = 0;
    NvU8 perfmonid = 0;
    //Set dummy varaibles for emulation
    //Refactor setupPMTarget to get below values indepdent of eventGroup data structure
    NvU32 chipletType = PM_CHIPLET_TYPE_GPC;
    NvU32 clkIdx = 1, totalTPCCount = 0;
    NvU32 gpcCount = ctx->device->state.limits.numGpcs;
    NvU32 *tpcPerGpcCount = ctx->device->state.limits.numTpcsPerGpc;
    NvU32 gpcId = 0, tpcId = 0, SMIdx = 0;
    NvU32 *pmmAddress = NULL;
    NvU32 *priAddress = NULL;
    NvU32 pmUnitMask = 1;

    CU_TRACE_FUNCTION();
    if (!(cuiDeviceArchIsMaxwellGM20XPlus(ctx->device)))
        return CUPROF_ERROR_NOT_SUPPORTED;

    status = perfmonSetupPMCtxswMode(ctx, NV_FALSE);
    if (CUPROF_SUCCESS != status) {
        CU_ERROR_PRINT(("Failed to re-set the PM Ctxsw bit\n"));
        return CUPROF_ERROR_UNKNOWN;
    }
    // Check if the PM CtxSw bit is disabled and assign the proper regOp type:
    ctx->pmNew->regOpType = ctx->pmNew->isPmCtxswModeEnabled ? CU_PRI_REG_CONTEXT : CU_PRI_REG_GLOBAL;

    for (gpcId = 0; gpcId < gpcCount; gpcId++) {
        totalTPCCount += tpcPerGpcCount[gpcId];
    }

    pmmAddress = (NvU32 *) malloc(sizeof(NvU32) * totalTPCCount);
    priAddress = (NvU32 *) malloc(sizeof(NvU32) * totalTPCCount);
    if (!pmmAddress || !priAddress) {
        status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }
#if defined(NV2080_CTRL_CMD_GR_PC_SAMPLING_MODE) && !cuiPlatformIncludesMrm()
    if (!ctx->pmNew->samplingFlag)
    {
        CUresult cudaStatus = CUDA_SUCCESS;
        cudaStatus = ctx->device->dmal.deviceSetPcSamplingMode(ctx, NV_TRUE);
        if (cudaStatus != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Error setting the PC_SAMPLING_MODE bit\n"));
            goto EXIT;
        }
        ctx->pmNew->samplingFlag = 1;
    }
#endif // defined(NV2080_CTRL_CMD_GR_PC_SAMPLING_MODE) && !cuiPlatformIncludesMrm()
    SMIdx = 0;
    for (gpcId = 0; gpcId < gpcCount; gpcId++) {
        for (tpcId = 0; tpcId < tpcPerGpcCount[gpcId]; tpcId++) {
            pmUnitMask |= (1 << SMIdx);
            priAddress[SMIdx] = NV_PRI_TPC_ADDR(gpcId, tpcId);
            SMIdx++;
        }
    }

    status = getSMPMMAddress(ctx, pmmAddress, &maxInstances);
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("Failed to map virtual to physical TPC index\n"));
        goto EXIT;
    }

    //8 - reset sel+op for all 4 counters
    //8 - set sel+op for all 4 counters
    //4 - PMM_CONTROL, control2, sampling, sm_pm_ctrl
    numReg = 13 + ((8 + 8 + 10) * SMIdx); //TBD: Replace the magic no
    size = sizeof(NvU32) * numReg;
    offset = (NvU32*)malloc(size);
    value  = (NvU32*)calloc(size, 1);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset and value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    //setupPMRegistersModeCommon
    offset[count++]  = NV_PERF_PMASYS_GPC_TRIGGER_STATUS;

    offset[count++]  = NV_PERF_PMASYS_FBP_TRIGGER_STATUS;

    offset[count++]  = NV_PERF_PMASYS_SYS_TRIGGER_STATUS;

    offset[count]  = NV_PERF_PMASYS_CONTROL;
    value[count++] = HWCONST(_PERF_PMASYS, CONTROL, STOPVPMCAPTURE, DOIT);

    offset[count++]  = NV_PERF_PMASYS_CONTROL;

    // setup PMA to push trigger to GPC chiplet
    offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_START_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_STOP_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_SYS_TRIGGER_START_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_SYS_TRIGGER_STOP_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_FBP_TRIGGER_START_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_FBP_TRIGGER_STOP_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_TRIGGER_GLOBAL;
    value[count++] = HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, ENABLE, ENABLED) |
        HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_GPC, ENABLE) |
        HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_FBP, ENABLE) |
        HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_SYS, ENABLE);

    offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_CONFIG_MIXED_MODE;
    value[count++] = 0xffffffff;

    for (chipIdx = 0; chipIdx < SMIdx; chipIdx++) {
        if(pmUnitMask & (1<<chipIdx))
        {
            domainRegOffset = pmmAddress[chipIdx] + clkIdx * NV_PMM_DOMAIN_OFFSET;
            {
                //setupPMRegistersModeCommon
                offset[count]  = domainRegOffset + NV_PMM_CLAMP_CYA_CONTROL;
                value[count++] = NV_PMM_CLAMP_CYA_CONTROL_ENABLECYA_DISABLE;
                offset[count++]  = domainRegOffset + NV_PERF_WBSKEW0;
                offset[count++]  = domainRegOffset + NV_PERF_WBSKEW1;
                offset[count++]  = domainRegOffset + NV_PERF_WBSKEW2;
                offset[count++]  = domainRegOffset + NV_PERF_WBSKEW_CHAIN0;
                offset[count++]  = domainRegOffset + NV_PERF_WBSKEW_CHAIN1;

                offset[count]  = domainRegOffset + NV_PMM_CONTROL;
                perfmonid = 0;
                //Assign 8 bit perfmonId as follows:
                //for FBP and GPC, LSB ro MSB : 2 bits for chiplet, and 6 bits for instance.
                //On maxwell there are max 24 SMs
                perfmonid = (chipletType & 3) | ((chipIdx & 0x3f)<< 2);
                value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_MODE_E, NV_PERF_PMMSYS_CONTROL_MODE);
                value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_CTXSW_MODE_DISABLED, NV_PERF_PMMSYS_CONTROL_CTXSW_MODE);
                value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES_DISABLED, NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES);
                value[count] = DRF_REPLACE(value[count], perfmonid, NV_PERF_PMMSYS_CONTROL_PERFMONID);
                count++;

                offset[count]  = domainRegOffset + NV_PMM_CONTROL2;
                value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL2_MODEE_USERDATA_ENABLED, NV_PERF_PMMSYS_CONTROL2_MODEE_USERDATA);
                count++;

                offset[count] = priAddress[chipIdx] + NV_PTPC_PRI_SM_PM_CTRL;
                value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_SEL_PROFILER, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_SEL);
                value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_ENABLE_ENABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_ENABLE);
                value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_QCTL_ENABLE_ENABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_QCTL_ENABLE);
                value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_MIO_ENABLE_ENABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_MIO_ENABLE);
                count++;
            }

            offset[count]  = domainRegOffset + NV_PMM_TRIG0_SEL;
            value[count++] = 0;
            offset[count]  = domainRegOffset + NV_PMM_TRIG0_OP;
            value[count++] = 0;
            offset[count]  = domainRegOffset + NV_PMM_TRIG1_SEL;
            value[count++] = 0;
            offset[count]  = domainRegOffset + NV_PMM_TRIG1_OP;
            value[count++] = 0;
            offset[count]  = domainRegOffset + NV_PMM_EVENT_SEL;
            value[count++] = 0;
            offset[count]  = domainRegOffset + NV_PMM_EVENT_OP;
            value[count++] = 0;
            offset[count]  = domainRegOffset + NV_PMM_SAMPLE_SEL;
            value[count++] = 0;
            offset[count]  = domainRegOffset + NV_PMM_SAMPLE_OP;
            value[count++] = 0;

            offset[count]  = domainRegOffset + NV_PMM_TRIG0_SEL;
            value[count++] = 0x03020100;
            offset[count]  = domainRegOffset + NV_PMM_TRIG0_OP;
            value[count++] = 0xffff;
            offset[count]  = domainRegOffset + NV_PMM_TRIG1_SEL;
            value[count++] = 0x07060504;
            offset[count]  = domainRegOffset + NV_PMM_TRIG1_OP;
            value[count++] = 0xffff;

            offset[count]  = domainRegOffset + NV_PMM_EVENT_SEL;
            value[count++] = 0xef08ef09;
            offset[count]  = domainRegOffset + NV_PMM_EVENT_OP;
            value[count++] = TRUTH_TABLE_FUNCTION_BIT_0_TRUE|TRUTH_TABLE_FUNCTION_BIT_2_TRUE;// 0xffff;

            //AssertEngineModeB
            offset[count]  = domainRegOffset + NV_PMM_ENGINE_SEL;
            value[count++] = resolveCoreSignalName(ctx, clkIdx, chipletType);
        }
    }
    CU_ASSERT(count <= numReg);
    // write signal configuration
    if (CUDA_SUCCESS != PRIWRITE32(ctx, ctx->pmNew->regOpType, count, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }
    // Set the SM_PM_SAMP_CTRL register using per-context access:
    {
        NvU32 offset, value = 0;
        offset = NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL;
        value  = DRF_REPLACE(value, NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL_ENABLE_ENABLE, NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL_ENABLE);
        value  = DRF_REPLACE(value, ctx->pmNew->samplingPeriod, NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL_TIMER);
        // write signal configuration
        if (CUDA_SUCCESS != PRIWRITE32(ctx, CU_PRI_REG_CONTEXT, 1, &offset, &value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }
    }

EXIT:
    free (offset);
    free (value);
    free(pmmAddress);
    free(priAddress);
    return status;

}

CUprofResult maxwellEndPCSampling(CUctx *ctx)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *buffer = NULL;
    size_t bufferSize = 0;
    NvU32 totalTPCCount = 0, gpcId = 0, tpcId = 0, SMIdx = 0;
    NvU32 *offset = NULL, *value = NULL, allocSize = 0;
    NvU32 count = 0, numReg = 0, clkIdx = 1;
    NvU32 domainRegOffset = 0, chipIdx = 0, pmUnitMask = 1, maxInstances = 0;
    NvU32 *pmmAddress = NULL, *priAddress = NULL;
    NvU32 gpcCount = ctx->device->state.limits.numGpcs;
    NvU32 *tpcPerGpcCount = ctx->device->state.limits.numTpcsPerGpc;

    CU_TRACE_FUNCTION();
    if (!(cuiDeviceArchIsMaxwellGM20XPlus(ctx->device)))
        return CUPROF_ERROR_NOT_SUPPORTED;

    for (gpcId = 0; gpcId < gpcCount; gpcId++) {
        totalTPCCount += tpcPerGpcCount[gpcId];
    }

    pmmAddress = (NvU32 *) malloc(sizeof(NvU32) * totalTPCCount);
    priAddress = (NvU32 *) malloc(sizeof(NvU32) * totalTPCCount);
    if (!pmmAddress || !priAddress) {
        status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    SMIdx = 0;
    for (gpcId = 0; gpcId < gpcCount; gpcId++) {
        for (tpcId = 0; tpcId < tpcPerGpcCount[gpcId]; tpcId++) {
            pmUnitMask |= (1 << SMIdx);
            priAddress[SMIdx] = NV_PRI_TPC_ADDR(gpcId, tpcId);
            SMIdx++;
        }
    }

    status = getSMPMMAddress(ctx, pmmAddress, &maxInstances);
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("Failed to map virtual to physical TPC index\n"));
        goto EXIT;
    }

    //8 - reset sel+op for all 4 counters
    //8 - set sel+op for all 4 counters
    //4 - control, control2, sampling, , sm_pm_ctrl
    numReg = (8 + 8 + 4) * SMIdx; //TBD: Replace the magic no
    allocSize = sizeof(NvU32) * numReg;
    offset = (NvU32*)malloc(allocSize);
    value  = (NvU32*)calloc(allocSize, 1);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset and value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    //Disable sampling:
    for (chipIdx = 0; chipIdx < SMIdx; chipIdx++) {
        if(pmUnitMask & (1<<chipIdx))
        {
            domainRegOffset = pmmAddress[chipIdx] + clkIdx * NV_PMM_DOMAIN_OFFSET;
            {
                offset[count]  = domainRegOffset + NV_PMM_CONTROL;
                value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_MODE_DISABLE, NV_PERF_PMMSYS_CONTROL_MODE);
                value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_CTXSW_MODE_DISABLED, NV_PERF_PMMSYS_CONTROL_CTXSW_MODE);
                count++;

                offset[count]  = domainRegOffset + NV_PMM_CONTROL2;
                value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL2_MODEE_USERDATA_DISABLED, NV_PERF_PMMSYS_CONTROL2_MODEE_USERDATA);
                value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL2_FLUSH_RECORD_DOIT, NV_PERF_PMMSYS_CONTROL2_FLUSH_RECORD);
                count++;

                offset[count] = priAddress[chipIdx] + NV_PTPC_PRI_SM_PM_CTRL;
                value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_ENABLE_DISABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_ENABLE);
                value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_QCTL_ENABLE_DISABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_QCTL_ENABLE);
                value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_MIO_ENABLE_DISABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_MIO_ENABLE);
                count++;
            }
        }
    }
    CU_ASSERT(count <= numReg);

    if (CUDA_SUCCESS != PRIWRITE32(ctx, ctx->pmNew->regOpType, count, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }
    // Disable sampling for SM unit using per-context accesses:
    {
        NvU32 offset, value = 0;
        offset = NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL;
        value  = DRF_REPLACE(value, NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL_ENABLE_DISABLE, NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL_ENABLE);
        if (CUDA_SUCCESS != PRIWRITE32(ctx, CU_PRI_REG_CONTEXT, 1, &offset, &value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }
    }
EXIT:
    free (offset);
    free (value);
    free(pmmAddress);
    free(priAddress);
    return status;
}

CUprofResult maxwellPerfmonPCSamplingEnable(CUctx *ctx) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *value = NULL;
    NvU32 count = 0, size = 0, numReg = 0;
    NvU32 domainRegOffset = 0, chipIdx = 0, maxInstances = 0;
    NvU8 perfmonid = 0;
    //Set dummy varaibles for emulation
    //Refactor setupPMTarget to get below values indepdent of eventGroup data structure
    NvU32 chipletType = PM_CHIPLET_TYPE_GPC;
    NvU32 clkIdx = 1, totalTPCCount = 0;
    NvU32 gpcCount = ctx->device->state.limits.numGpcs;
    NvU32 *tpcPerGpcCount = ctx->device->state.limits.numTpcsPerGpc;
    NvU32 gpcId = 0, tpcId = 0, SMIdx = 0;
    NvU32 *pmmAddress = NULL;
    NvU32 *priAddress = NULL;
    NvU32 pmUnitMask = 1;

    CU_TRACE_FUNCTION();
    if (!(cuiDeviceArchIsMaxwellGM20XPlus(ctx->device)))
        return CUPROF_ERROR_NOT_SUPPORTED;

    status = perfmonSetupPMCtxswMode(ctx, NV_FALSE);
    if (CUPROF_SUCCESS != status) {
        CU_ERROR_PRINT(("Failed to re-set the PM Ctxsw bit\n"));
        return CUPROF_ERROR_UNKNOWN;
    }
    // Check if the PM CtxSw bit is disabled and assign the proper regOp type:
    ctx->pmNew->regOpType = ctx->pmNew->isPmCtxswModeEnabled ? CU_PRI_REG_CONTEXT : CU_PRI_REG_GLOBAL;

#ifndef BUG_1259185_FIXED
    if (ctx->device->dmalType != CU_DMAL_AMODEL) {
        //G84_PERFBUFFER does not get allocated on amodel
        status = setupStreamingResources(ctx);
        if (status != CUPROF_SUCCESS) {
            CU_ERROR_PRINT(("Failed to setup streaming resources\n"));
            goto EXIT;
        }
    }
#endif
    for (gpcId = 0; gpcId < gpcCount; gpcId++) {
        totalTPCCount += tpcPerGpcCount[gpcId];
    }

    pmmAddress = (NvU32 *) malloc(sizeof(NvU32) * totalTPCCount);
    priAddress = (NvU32 *) malloc(sizeof(NvU32) * totalTPCCount);
    if (!pmmAddress || !priAddress) {
        status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }
#if defined(NV2080_CTRL_CMD_GR_PC_SAMPLING_MODE) && !cuiPlatformIncludesMrm()
    if (!ctx->pmNew->samplingFlag)
    {
        CUresult cudaStatus = CUDA_SUCCESS;
        cudaStatus = ctx->device->dmal.deviceSetPcSamplingMode(ctx, NV_TRUE);
        if (cudaStatus != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Error setting the PC_SAMPLING_MODE bit\n"));
            goto EXIT;
        }
        ctx->pmNew->samplingFlag = 1;
    }
#endif // defined(NV2080_CTRL_CMD_GR_PC_SAMPLING_MODE) && !cuiPlatformIncludesMrm()
    SMIdx = 0;
    for (gpcId = 0; gpcId < gpcCount; gpcId++) {
        for (tpcId = 0; tpcId < tpcPerGpcCount[gpcId]; tpcId++) {
            pmUnitMask |= (1 << SMIdx);
            priAddress[SMIdx] = NV_PRI_TPC_ADDR(gpcId, tpcId);
            SMIdx++;
        }
    }

    status = getSMPMMAddress(ctx, pmmAddress, &maxInstances);
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("Failed to map virtual to physical TPC index\n"));
        goto EXIT;
    }

    //8 - reset sel+op for all 4 counters
    //8 - set sel+op for all 4 counters
    //4 - PMM_CONTROL, control2, sampling, sm_pm_ctrl
    numReg = 13 + ((8 + 8 + 10) * SMIdx); //TBD: Replace the magic no
    size = sizeof(NvU32) * numReg;
    offset = (NvU32*)malloc(size);
    value  = (NvU32*)calloc(size, 1);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset and value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    //setupPMRegistersModeCommon
    offset[count++]  = NV_PERF_PMASYS_GPC_TRIGGER_STATUS;

    offset[count++]  = NV_PERF_PMASYS_FBP_TRIGGER_STATUS;

    offset[count++]  = NV_PERF_PMASYS_SYS_TRIGGER_STATUS;

    offset[count]  = NV_PERF_PMASYS_CONTROL;
    value[count++] = HWCONST(_PERF_PMASYS, CONTROL, STOPVPMCAPTURE, DOIT);

    offset[count++]  = NV_PERF_PMASYS_CONTROL;

    // setup PMA to push trigger to GPC chiplet
    offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_START_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_STOP_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_SYS_TRIGGER_START_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_SYS_TRIGGER_STOP_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_FBP_TRIGGER_START_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_FBP_TRIGGER_STOP_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_TRIGGER_GLOBAL;
    value[count++] = HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, ENABLE, ENABLED) |
        HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_GPC, ENABLE) |
        HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_FBP, ENABLE) |
        HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_SYS, ENABLE);

    offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_CONFIG_MIXED_MODE;
    value[count++] = 0xffffffff;

    for (chipIdx = 0; chipIdx < SMIdx; chipIdx++) {
        if(pmUnitMask & (1<<chipIdx))
        {
            domainRegOffset = pmmAddress[chipIdx] + clkIdx * NV_PMM_DOMAIN_OFFSET;
            {
                //setupPMRegistersModeCommon
                offset[count]  = domainRegOffset + NV_PMM_CLAMP_CYA_CONTROL;
                value[count++] = NV_PMM_CLAMP_CYA_CONTROL_ENABLECYA_DISABLE;
                offset[count++]  = domainRegOffset + NV_PERF_WBSKEW0;
                offset[count++]  = domainRegOffset + NV_PERF_WBSKEW1;
                offset[count++]  = domainRegOffset + NV_PERF_WBSKEW2;
                offset[count++]  = domainRegOffset + NV_PERF_WBSKEW_CHAIN0;
                offset[count++]  = domainRegOffset + NV_PERF_WBSKEW_CHAIN1;

                offset[count]  = domainRegOffset + NV_PMM_CONTROL;
                perfmonid = 0;
                //Assign 8 bit perfmonId as follows:
                //for FBP and GPC, LSB ro MSB : 2 bits for chiplet, and 6 bits for instance.
                //On maxwell there are max 24 SMs
                perfmonid = (chipletType & 3) | ((chipIdx & 0x3f)<< 2);
                value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_MODE_E, NV_PERF_PMMSYS_CONTROL_MODE);
                value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_CTXSW_MODE_DISABLED, NV_PERF_PMMSYS_CONTROL_CTXSW_MODE);
                value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES_DISABLED, NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES);
                value[count] = DRF_REPLACE(value[count], perfmonid, NV_PERF_PMMSYS_CONTROL_PERFMONID);
                count++;

                offset[count]  = domainRegOffset + NV_PMM_CONTROL2;
                value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL2_MODEE_USERDATA_ENABLED, NV_PERF_PMMSYS_CONTROL2_MODEE_USERDATA);
                count++;

                offset[count] = priAddress[chipIdx] + NV_PTPC_PRI_SM_PM_CTRL;
                value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_SEL_PROFILER, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_SEL);
                value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_ENABLE_ENABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_ENABLE);
                value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_QCTL_ENABLE_ENABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_QCTL_ENABLE);
                value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_MIO_ENABLE_ENABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_MIO_ENABLE);
                count++;
            }

            offset[count]  = domainRegOffset + NV_PMM_TRIG0_SEL;
            value[count++] = 0;
            offset[count]  = domainRegOffset + NV_PMM_TRIG0_OP;
            value[count++] = 0;
            offset[count]  = domainRegOffset + NV_PMM_TRIG1_SEL;
            value[count++] = 0;
            offset[count]  = domainRegOffset + NV_PMM_TRIG1_OP;
            value[count++] = 0;
            offset[count]  = domainRegOffset + NV_PMM_EVENT_SEL;
            value[count++] = 0;
            offset[count]  = domainRegOffset + NV_PMM_EVENT_OP;
            value[count++] = 0;
            offset[count]  = domainRegOffset + NV_PMM_SAMPLE_SEL;
            value[count++] = 0;
            offset[count]  = domainRegOffset + NV_PMM_SAMPLE_OP;
            value[count++] = 0;

            offset[count]  = domainRegOffset + NV_PMM_TRIG0_SEL;
            value[count++] = 0x03020100;
            offset[count]  = domainRegOffset + NV_PMM_TRIG0_OP;
            value[count++] = 0xffff;
            offset[count]  = domainRegOffset + NV_PMM_TRIG1_SEL;
            value[count++] = 0x07060504;
            offset[count]  = domainRegOffset + NV_PMM_TRIG1_OP;
            value[count++] = 0xffff;

            offset[count]  = domainRegOffset + NV_PMM_EVENT_SEL;
            value[count++] = 0xef08ef09;
            offset[count]  = domainRegOffset + NV_PMM_EVENT_OP;
            value[count++] = TRUTH_TABLE_FUNCTION_BIT_0_TRUE|TRUTH_TABLE_FUNCTION_BIT_2_TRUE;// 0xffff;

            //AssertEngineModeB
            offset[count]  = domainRegOffset + NV_PMM_ENGINE_SEL;
            value[count++] = resolveCoreSignalName(ctx, clkIdx, chipletType);
        }
    }
    CU_ASSERT(count <= numReg);
    // write signal configuration
    if (CUDA_SUCCESS != PRIWRITE32(ctx, ctx->pmNew->regOpType, count, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }
    // Set the SM_PM_SAMP_CTRL register using per-context access:
    {
        NvU32 offset, value = 0;
        offset = NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL;
        value  = DRF_REPLACE(value, NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL_ENABLE_ENABLE, NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL_ENABLE);
        value  = DRF_REPLACE(value, ctx->pmNew->samplingPeriod, NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL_TIMER);
        // write signal configuration
        if (CUDA_SUCCESS != PRIWRITE32(ctx, CU_PRI_REG_CONTEXT, 1, &offset, &value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }
    }
#ifndef NV_MODS
    ctx->device->state.profilerState.samplingDataHashMap
                      = (void*) toolsHashMapNew(toolsUint32HashFun, toolsUint64EqualFun, 64);
#endif

    status = startStreaming(ctx);
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("Failed to start streaming\n"));
    }

    if(!ctx->device->state.profilerState.samplingThreadReadData) {
        int cuosStatus = CUOS_SUCCESS;
        ctx->device->state.profilerState.totalDroppedRecords = 0;
        ctx->device->state.profilerState.terminateSamplingThread = 0;
        ctx->device->state.profilerState.terminateSamplingParseDataThread = 0;
        cuiMutexInitialize(&ctx->device->state.profilerState.buffListMutex, CUI_MUTEX_ORDER_TERMINAL, CUI_MUTEX_DEFAULT);
#ifndef NV_MODS
        ctx->device->state.profilerState.buffList = (void *) toolsListNew();
#endif
        if (!ctx->device->state.profilerState.buffList) {
            status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
            goto EXIT;
        }

        // create the readSemaphore to signal the worker thread at the end to flush data
        cuosStatus = cuosSemaphoreCreate(&ctx->device->state.profilerState.readSemaphore, 0);
        if (cuosStatus) {
             CU_ASSERT(0);
             goto EXIT;
        }

        cuosStatus = cuosThreadCreate(&ctx->device->state.profilerState.samplingThreadReadData, maxwellPerfmonPCSamplingReadData, (void *) ctx);
        if (CUOS_SUCCESS != cuosStatus) {
            CU_ASSERT(0);
            status = CUPROF_ERROR_UNKNOWN;
            goto EXIT;
        }
        cuosStatus = cuosThreadCreate(&ctx->device->state.profilerState.samplingThreadParseData, maxwellPerfmonPCSamplingParseData, (void *) ctx);
        if (CUOS_SUCCESS != cuosStatus) {
            CU_ASSERT(0);
            status = CUPROF_ERROR_UNKNOWN;
            goto EXIT;
        }
    }

EXIT:
#ifndef BUG_1259185_FIXED
    if (ctx->device->dmalType != CU_DMAL_AMODEL) {
        if (status != CUPROF_SUCCESS) {
            if(ctx->device->state.profilerState.samplingThreadReadData) {
                int retCode = 0;
                ctx->device->state.profilerState.terminateSamplingThread = 1;
                cuosThreadJoin(ctx->device->state.profilerState.samplingThreadReadData, &retCode);
                if (retCode != 0) {
                    CU_ERROR_PRINT(("Failed to join sampling thread\n"));
                }
                ctx->device->state.profilerState.samplingThreadReadData = NULL;
           }
            if(ctx->device->state.profilerState.samplingThreadParseData) {
                int retCode = 0;
                cuosThreadJoin(ctx->device->state.profilerState.samplingThreadParseData, &retCode);
                if (retCode != 0) {
                    CU_ERROR_PRINT(("Failed to join sampling thread\n"));
                }
                ctx->device->state.profilerState.samplingThreadParseData = NULL;
            }
            cuosSemaphoreDestroy(&ctx->device->state.profilerState.readSemaphore);
            if (ctx->device->state.profilerState.buffList) {
                cuiMutexLock(&ctx->device->state.profilerState.buffListMutex);
#ifndef NV_MODS
                toolsListDelete((tList *) ctx->device->state.profilerState.buffList, deleteBuffNode, NULL);
#endif
                ctx->device->state.profilerState.buffList = NULL;
                cuiMutexUnlock(&ctx->device->state.profilerState.buffListMutex);
            }

            cuiMutexDeinitialize(&ctx->device->state.profilerState.buffListMutex);
            cleanupStreamingResources(ctx);
        }
    }
#endif
    free (offset);
    free (value);
    free(pmmAddress);
    free(priAddress);
    return status;
}

CUprofResult maxwellPerfmonPCSamplingDisable(CUctx *ctx) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *buffer = NULL;
    size_t bufferSize = 0;
    NvU32 totalTPCCount = 0, gpcId = 0, tpcId = 0, SMIdx = 0;
    NvU32 *offset = NULL, *value = NULL, allocSize = 0;
    NvU32 count = 0, numReg = 0, clkIdx = 1;
    NvU32 domainRegOffset = 0, chipIdx = 0, pmUnitMask = 1, maxInstances = 0;
    NvU32 *pmmAddress = NULL, *priAddress = NULL;
    NvU32 gpcCount = ctx->device->state.limits.numGpcs;
    NvU32 *tpcPerGpcCount = ctx->device->state.limits.numTpcsPerGpc;

    CU_TRACE_FUNCTION();
    if (!(cuiDeviceArchIsMaxwellGM20XPlus(ctx->device)))
        return CUPROF_ERROR_NOT_SUPPORTED;

    status = stopStreaming(ctx);
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("Failed to stop streaming\n"));
    }

    for (gpcId = 0; gpcId < gpcCount; gpcId++) {
        totalTPCCount += tpcPerGpcCount[gpcId];
    }

    pmmAddress = (NvU32 *) malloc(sizeof(NvU32) * totalTPCCount);
    priAddress = (NvU32 *) malloc(sizeof(NvU32) * totalTPCCount);
    if (!pmmAddress || !priAddress) {
        status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    SMIdx = 0;
    for (gpcId = 0; gpcId < gpcCount; gpcId++) {
        for (tpcId = 0; tpcId < tpcPerGpcCount[gpcId]; tpcId++) {
            pmUnitMask |= (1 << SMIdx);
            priAddress[SMIdx] = NV_PRI_TPC_ADDR(gpcId, tpcId);
            SMIdx++;
        }
    }

    status = getSMPMMAddress(ctx, pmmAddress, &maxInstances);
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("Failed to map virtual to physical TPC index\n"));
        goto EXIT;
    }

    //8 - reset sel+op for all 4 counters
    //8 - set sel+op for all 4 counters
    //4 - control, control2, sampling, , sm_pm_ctrl
    numReg = (8 + 8 + 4) * SMIdx; //TBD: Replace the magic no
    allocSize = sizeof(NvU32) * numReg;
    offset = (NvU32*)malloc(allocSize);
    value  = (NvU32*)calloc(allocSize, 1);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset and value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

#if 0
    //Wait for all records to be flushed to memory, otherwise some records will be seen in
    //the next kernel sampling data. Currently this is not fixing bug 20028050 but we may require
    //in future
    for (chipIdx = 0; chipIdx < SMIdx; chipIdx++) {
        if(pmUnitMask & (1<<chipIdx))
        {
                domainRegOffset = pmmAddress[chipIdx] + clkIdx * NV_PMM_DOMAIN_OFFSET;
                offset[0]  = domainRegOffset + NV_PMM_CONTROL;
                value[0] = (NV_PMM_CONTROL_MODE_DISABLE        << NV_PMM_CONTROL_MODE__SHIFT);

                if (CUDA_SUCCESS != PRIWRITE32(ctx, CU_PRI_REG_GLOBAL, 1, offset, value, 0)) {
                    status = CUPROF_ERROR_HARDWARE;
                    goto EXIT;
                }
        }
    }

    for (chipIdx = 0; chipIdx < SMIdx; chipIdx++) {
        if(pmUnitMask & (1<<chipIdx))
        {
                domainRegOffset = pmmAddress[chipIdx] + clkIdx * NV_PMM_DOMAIN_OFFSET;
                offset[0]  = domainRegOffset + NV_PMM_ENGINESTATUS;
READ_STATUS:
                if (CUDA_SUCCESS != PRIREAD32(ctx, CU_PRI_REG_GLOBAL, 1, offset, value, 0)) {
                    status = CUPROF_ERROR_HARDWARE;
                    goto EXIT;
                }
                if ((value[0] & 0x7) == NV_PERF_PMMSYS_ENGINESTATUS_STATUS_ACTIVE) {
                    printf("Engine not empty\n");
                    goto READ_STATUS;
                } else {
                    if ((value[0] & 0x7) == NV_PERF_PMMSYS_ENGINESTATUS_STATUS_FAULTED) {
                        CU_ERROR_PRINT(("PMM Engine status faulted\n"));
                    }
                    continue;
                }
        }
    }

    do {
        offset[0]  = NV_PERF_PMMSYSROUTER_ENGINESTATUS;
        offset[1]  = NV_PERF_PMMGPCROUTER_ENGINESTATUS;
        offset[2]  = NV_PERF_PMMFBPROUTER_ENGINESTATUS;
        value[0] = value[1] = value[2] = 0;

        if (CUDA_SUCCESS != PRIREAD32(ctx, CU_PRI_REG_GLOBAL, 3, offset, value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }

        if (((value[0] & 0x7) == 0) && ((value[1] & 0x7) == 0) && ((value[2] & 0x7) == 0)) {
            break;
        }

        printf("Engine status %d %d %d\n", (value[0] & 0x7), (value[1] & 0x7), (value[2] & 0x7));

        if (((value[0] & 0x7) == NV_PERF_PMMSYSROUTER_ENGINESTATUS_STATUS_FAULTED) &&
            ((value[1] & 0x7) == NV_PERF_PMMGPCROUTER_ENGINESTATUS_STATUS_FAULTED) &&
            ((value[2] & 0x7) == NV_PERF_PMMFBPROUTER_ENGINESTATUS_STATUS_FAULTED)) {
            CU_ERROR_PRINT(("PMM Engine status faulted\n"));
            break;
        }

        //printf("Reading status again for routers\n");
    } while(1);

    offset[0]  = NV_PERF_PMASYS_ENGINESTATUS;
    value[0] = 0;

    if (CUDA_SUCCESS != PRIREAD32(ctx, CU_PRI_REG_GLOBAL, 1, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

    if ((value[0] & 0x7) == NV_PERF_PMASYS_ENGINESTATUS_STATUS_FAULTED) {
        printf("PMA engine status faulted.\n");
        CU_ASSERT(0);
    }

    if ((value[0] & 0x7) == NV_PERF_PMASYS_ENGINESTATUS_STATUS_FAULTED) {
        printf("PMA engine succesfully stopped.\n");
    }
#endif


    //Disable sampling:
    for (chipIdx = 0; chipIdx < SMIdx; chipIdx++) {
        if(pmUnitMask & (1<<chipIdx))
        {
            domainRegOffset = pmmAddress[chipIdx] + clkIdx * NV_PMM_DOMAIN_OFFSET;
            {
                offset[count]  = domainRegOffset + NV_PMM_CONTROL;
                value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_MODE_DISABLE, NV_PERF_PMMSYS_CONTROL_MODE);
                value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_CTXSW_MODE_DISABLED, NV_PERF_PMMSYS_CONTROL_CTXSW_MODE);
                count++;

                offset[count]  = domainRegOffset + NV_PMM_CONTROL2;
                value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL2_MODEE_USERDATA_DISABLED, NV_PERF_PMMSYS_CONTROL2_MODEE_USERDATA);
                value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL2_FLUSH_RECORD_DOIT, NV_PERF_PMMSYS_CONTROL2_FLUSH_RECORD);
                count++;

                offset[count] = priAddress[chipIdx] + NV_PTPC_PRI_SM_PM_CTRL;
                value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_ENABLE_DISABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_ENABLE);
                value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_QCTL_ENABLE_DISABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_QCTL_ENABLE);
                value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_MIO_ENABLE_DISABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_MIO_ENABLE);
                count++;
            }
        }
    }
    CU_ASSERT(count <= numReg);

    if (CUDA_SUCCESS != PRIWRITE32(ctx, ctx->pmNew->regOpType, count, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }
    // Disable sampling for SM unit using per-context accesses:
    {
        NvU32 offset, value = 0;
        offset = NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL;
        value  = DRF_REPLACE(value, NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL_ENABLE_DISABLE, NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL_ENABLE);
        if (CUDA_SUCCESS != PRIWRITE32(ctx, CU_PRI_REG_CONTEXT, 1, &offset, &value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }
    }

    if (ctx->device->state.profilerState.samplingThreadReadData) {
        int retCode = 0;
        cuosSemaphoreSignal(&ctx->device->state.profilerState.readSemaphore);
        cuosSleep(SAMPLING_TIMEOUT*2);
        ctx->device->state.profilerState.terminateSamplingThread = 1;

        cuosThreadJoin(ctx->device->state.profilerState.samplingThreadReadData, &retCode);
        if (retCode != 0) {
            CU_ERROR_PRINT(("Failed to join sampling thread\n"));
            status = (CUprofResult)retCode;
        }
        ctx->device->state.profilerState.samplingThreadReadData = NULL;
        if (ctx->device->state.profilerState.samplingThreadParseData) {
            cuosThreadJoin(ctx->device->state.profilerState.samplingThreadParseData, &retCode);
            if (retCode != 0) {
                CU_ERROR_PRINT(("Failed to join sampling thread\n"));
                status = (CUprofResult)retCode;
            }
            ctx->device->state.profilerState.samplingThreadParseData = NULL;
        }
        cuosSemaphoreDestroy(&ctx->device->state.profilerState.readSemaphore);
        if (ctx->device->state.profilerState.buffList) {
            cuiMutexLock(&ctx->device->state.profilerState.buffListMutex);
#ifndef NV_MODS
            toolsListDelete((tList *) ctx->device->state.profilerState.buffList, deleteBuffNode, NULL);
#endif
            ctx->device->state.profilerState.buffList = NULL;
            cuiMutexUnlock(&ctx->device->state.profilerState.buffListMutex);
        }

        cuiMutexDeinitialize(&ctx->device->state.profilerState.buffListMutex);
    }

    // Dump data into compact buffer which can be passed to CUPTI:
    PCSamplingHashMapToBuffer(ctx, &buffer, &bufferSize, ctx->device->state.profilerState.totalDroppedRecords);

    // Call the callBack function registered:
    ctx->pmNew->pcSamplingReadDataCallback(buffer, bufferSize, ctx->pmNew->userData);

    // Free the memory allocated for hashMap and buffer used for reading the sampling records from hardware:
    if (buffer) {
        free(buffer);
    }
#ifndef NV_MODS
    toolsHashMapDelete((tHashMap*)ctx->device->state.profilerState.samplingDataHashMap, NULL, NULL);
#endif
EXIT:
#ifndef BUG_1259185_FIXED
    if (ctx->device->dmalType != CU_DMAL_AMODEL) {
        cleanupStreamingResources(ctx);
    }
#endif
    free (offset);
    free (value);
    free(pmmAddress);
    free(priAddress);
    return status;
}

//Following function reads data from HW buffer and copied data
//to SW buffer to parse in an offline thread
static int maxwellPerfmonPCSamplingReadData(void *userData) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 offset[2], values[2];           //2 (mem_bytes+mem+head)
    NvU32 j = 0;
    NvU32 bytesToParse = 0, memBytes = 0;
    NvU8 *recPtr;
    //Set dummy varaibles for emulation
    CUctx *ctx;
    CUprofDeviceState *profDevState;
    int cuosResult = 0;

#if GENERATE_BINARY_STREAMS
    FILE *file = NULL;

    file = fopen("maxwellSamplingData", "wb");
#endif

    CU_TRACE_FUNCTION();

    if (!userData)
        return CUPROF_ERROR_NOT_SUPPORTED;

    ctx = (CUctx *) userData;
    profDevState = &ctx->device->state.profilerState;

    if (!(cuiDeviceArchIsMaxwellGM20XPlus(ctx->device)))
        return CUPROF_ERROR_NOT_SUPPORTED;

    recPtr = (NvU8 *)ctx->pmNew->cpuAddrStreamingBuffer;
    if (!recPtr) {
        status = CUPROF_ERROR_UNKNOWN;
        goto EXIT;
    }

    while(1) {
        cuosResult = cuosSemaphoreWait(&ctx->device->state.profilerState.readSemaphore, SAMPLING_TIMEOUT);
        if (cuosResult == CUOS_ERROR) {
            CU_ASSERT(0);
        }

        j = 0;
        //Loop for reading data from sampling output
        offset[j]  = NV_PERF_PMASYS_MEM_BYTES;
        values[j] = 0;
        j++;

        if (CUDA_SUCCESS != PRIREAD32(ctx, CU_PRI_REG_GLOBAL, j, offset, values, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }

        memBytes = values[0];
        if ((ctx->device->state.profilerState.terminateSamplingThread) && (!memBytes)) {
            break;
        }

        j = 0;
        offset[j]  = NV_PERF_PMASYS_CONTROL;
        values[j] = 0;
        j++;

        if (CUDA_SUCCESS != PRIREAD32(ctx, ctx->pmNew->regOpType, j, offset, values, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }

        if(GETVAL(values[0], NV_PERF_PMASYS_CONTROL_MEMBUF_STATUS) == NV_PERF_PMASYS_CONTROL_MEMBUF_STATUS_OVERFLOWED) {
            CU_ERROR_PRINT(("Streaming buffer overflowed.\n"));
            status = CUPROF_ERROR_HARDWARE;
            ctx->device->state.profilerState.terminateSamplingThread = 1;
        }

        bytesToParse = memBytes & ~0x1f;
#ifdef ENABLE_SAMPLING_PRINTS
        printf("totalBytes = %d, membytes = %d\n", bytesToParse, memBytes);
#endif

        if(bytesToParse) {
            if (recPtr == ((uint8_t*)ctx->pmNew->cpuAddrStreamingBuffer + ctx->pmNew->sizeStreamingBuffer)) {
                recPtr = (NvU8 *)ctx->pmNew->cpuAddrStreamingBuffer;
#ifdef ENABLE_SAMPLING_PRINTS
                printf("Buffer wrap around next pass\n");
#endif
            }
            //If there is a wraparound, then process the bytes at the end of the buffer first and then process remaining bytes in next pass
            if(((uint64_t)(uintptr_t)recPtr + bytesToParse) >= (uint64_t)(uintptr_t)((uint8_t*)ctx->pmNew->cpuAddrStreamingBuffer + ctx->pmNew->sizeStreamingBuffer)) {
#ifdef ENABLE_SAMPLING_PRINTS
                printf("Buffer wrap around first pass, bytesToParse before %d\n", bytesToParse);
#endif

                bytesToParse = (uint32_t)((uint64_t)(uintptr_t)((uint8_t*)ctx->pmNew->cpuAddrStreamingBuffer + ctx->pmNew->sizeStreamingBuffer) - (uint64_t)(uintptr_t)recPtr);
#ifdef ENABLE_SAMPLING_PRINTS
                printf("Buffer wrap around first pass, bytesToParse after %d\n", bytesToParse);
#endif
            }

            //Skip invalid records by reading backwards.
            {
                CUprofSamplingRecord *tempPtr = (CUprofSamplingRecord *)(recPtr + bytesToParse - 32);
                NvU32 bytesToSkip = 0;

                while (((tempPtr->smplCnt_tm_ds_sz_0_0 & 0xc000) == 0xc000) && (bytesToSkip < bytesToParse)) {
                    bytesToSkip += 32;
                    tempPtr--;
                }
#ifdef ENABLE_SAMPLING_PRINTS
                printf("Bytes skipped = %d\n", bytesToSkip);
#endif
                bytesToParse -= bytesToSkip;
            }

            if(bytesToParse) {
                //Allocate buffer struct
                CUprofBuff *tempBuff = NULL;
                tempBuff = (CUprofBuff*) malloc(sizeof(CUprofBuff));
                if (!tempBuff) {
                    status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
                    goto EXIT;
                }
                //Allocate buffer
                tempBuff->buff = (NvU32 *) malloc(bytesToParse);
                if (!tempBuff->buff) {
                    free(tempBuff);
                    status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
                    goto EXIT;
                }
                //Copy bytes
                memcpy(tempBuff->buff, recPtr, bytesToParse);
                tempBuff->buffSize = bytesToParse;
#if GENERATE_BINARY_STREAMS
                fwrite(recPtr, bytesToParse, 1, file);
#endif
                //Add to list
                cuiMutexLock(&profDevState->buffListMutex);
#ifndef NV_MODS
                toolsListAppendFront((tList *) profDevState->buffList, (void *)tempBuff);
#endif
                cuiMutexUnlock(&profDevState->buffListMutex); 
                recPtr += bytesToParse;

                //Tell hardware about the data read
                //Write value read from mem_bytes to mem_bump
                offset[0] = NV_PERF_PMASYS_MEM_BUMP;
                values[0] = bytesToParse;

                memset(recPtr - bytesToParse, 0xFF, bytesToParse);
                if (CUDA_SUCCESS != PRIWRITE32(ctx, CU_PRI_REG_GLOBAL, 1, offset, values, 0)) {
                    status = CUPROF_ERROR_HARDWARE;
                    goto EXIT;
                }
                bytesToParse = 0;
            }
        }
    }
EXIT:
#ifdef ENABLE_SAMPLING_PRINTS
    printf("Exited read thread, tt = %d\n", (int)ctx->device->state.profilerState.terminateSamplingThread);
#endif
    ctx->device->state.profilerState.terminateSamplingParseDataThread = 1;

#if GENERATE_BINARY_STREAMS
    fclose(file);
#endif
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("maxwellPerfmonPCSamplingReadData failed with error %d.\n", status));
    }
    return (int)status;
}

static inline size_t incrementRecordOffset(size_t recordOffset)
{
    uint8_t incAmount[32] = {
        1, 1, 1, 5, 0, 0, 0, 0,
        1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1
    };
    return recordOffset + incAmount[recordOffset];
}

static inline uint16_t getValidBytes(const uint8_t *pModeERecord)
{
    return pModeERecord[4] & 0x1F;
}

static inline uint16_t getPerfmonId(const uint8_t *pModeERecord)
{
    return pModeERecord[5];
}

static inline uint8_t isDelayed(const uint8_t *pModeERecord)
{
    return ((pModeERecord[7] & 0x10) != 0);
}

static inline uint16_t getDroppedBytes(const uint8_t *pModeERecord)
{
    uint16_t smplCnt_tm_ds_sz_0_0 = ((pModeERecord[7] << 8) | pModeERecord[6]);
    
    return ((smplCnt_tm_ds_sz_0_0 & 0x7ff) << 3) | ((pModeERecord[4] & 0xe0) >> 5);
}

static inline uint32_t getPC(const uint8_t *pPacketRaw) {
    return (pPacketRaw[0] << 3) | (pPacketRaw[1] << 11) | (pPacketRaw[2] << 19) | ((pPacketRaw[3] & 0x1f) << 27);    
}

static inline uint32_t getCIR(const uint8_t *pPacketRaw) {
    return (pPacketRaw[3] >> 5) | ((pPacketRaw[4] & 0x3) << 3);
}

// tools_shared code is not accessible on mods
#if defined(NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200) && !defined(NV_MODS)
CUprofResult maxwellOnPacket(const uint8_t *pPacketRaw, CUctx *ctx) {

    typedef uint32_t (*CUprofPCSamplingGetStallReason)(uint32_t cantIssueReason);
    CUprofPCSamplingGetStallReason pFn = NULL;
    tHashMap *samplingDataHashMap;
    NvU32 *ptrToData = NULL;

    if ((ctx->profiler) && (ctx->profiler->dumpAllReasons)) {
        pFn = (CUprofPCSamplingGetStallReason)&getPCSamplingStallReasonDriver;
    }
    else {
        pFn = (CUprofPCSamplingGetStallReason)&getPCSamplingStallReasonCupti;
    }

    /*******************************************************************************
                                     HASHMAP FORMAT:
              |KEY |                VALUE                           |
              PC1 #| CIR1 SAMPLES#|CIR2  SAMPLES#| ...|CIRn SAMPLES#
              PC2 #| CIR1 SAMPLES#|CIR2  SAMPLES#| ...|CIRn SAMPLES#
              ...
              PCn #| CIR1 SAMPLES#|CIR2  SAMPLES#| ...|CIRn SAMPLES#
    ********************************************************************************/

    const uint32_t pc = getPC(pPacketRaw);
    uint32_t cant_issue_reason = getCIR(pPacketRaw);

    // Assert used to check if the CIR's are invalid
    CU_ASSERT ((cant_issue_reason > 0) && (cant_issue_reason < CUPROF_MAXWELL_WARP_CANT_ISSUE_MAX_CIR ));

    cant_issue_reason = pFn(cant_issue_reason);

#ifdef ENABLE_SAMPLING_PRINTS
    // printf("**pc = %x, cir = %d\n", pc, cant_issue_reason);
#endif

    samplingDataHashMap = (tHashMap *) ctx->device->state.profilerState.samplingDataHashMap;

    ptrToData = (NvU32 *)toolsHashMapFind(samplingDataHashMap, tHashMapNumToKey(pc));
    if(!ptrToData) {
        //Allocate the data to hold CIR:
        ptrToData = (NvU32*)calloc(CUPROF_WARP_CANT_ISSUE_MAX_CIR, sizeof(NvU32));
        if(!ptrToData) {
            CU_ERROR_PRINT(("Error allocating memory.\n"));
            return CUPROF_ERROR_OUT_OF_MEMORY;
        }
        toolsHashMapInsert(samplingDataHashMap, tHashMapNumToKey(pc), (void*)ptrToData);
    }
    ptrToData[cant_issue_reason]++;

    return CUPROF_SUCCESS;
}
#else
CUprofResult maxwellOnPacket(const uint8_t *pPacketRaw, CUctx *ctx) {
    return CUPROF_SUCCESS;
}
#endif

CUprofResult maxwellOnRecord(uint8_t *pModeERecord, chiplet *chipInstanceData, CUctx *ctx, uint32_t *totalDroppedBytes) {
    
    CUprofResult status = CUPROF_SUCCESS;
    uint16_t validBytes = getValidBytes(pModeERecord);
    size_t recordOffset = 0;
    uint8_t packetSize = 5;                 // PacketSize for Maxwell is 5bytes
    uint32_t itr = 0;
    uint8_t bytesDiscarded;

#ifdef ENABLE_SAMPLING_PRINTS
    //Enable, only if there is an error in parsing.
    // printf("+++++++++++++++++++++++Start record\n");
    // printf("data0[0] = %x\n",  pModeERecord[0]);
    // printf("data0[1] = %x\n",  pModeERecord[1]);
    // printf("data0[2] = %x\n",  pModeERecord[2]);
    // printf("data0[3] = %x\n",  pModeERecord[3]);
    // printf("perfmonid = %x\n",  pModeERecord[5]);
    // printf("ByteCount = %x\n",  (pModeERecord[4] & 0x1f));
    // printf("smplCnt_tm_ds_sz_0_0 = %x\n",  ((pModeERecord[7] << 8) | pModeERecord[6]) );
    // for (int i = 0; i < 24; i++)
    //     printf("data1[%d] = %x\n", i, pModeERecord[i + 8]);
    // printf("----------------------End record\n");
#endif

#ifdef ENABLE_SAMPLING_PRINTS
    // printf("Dropped: %d\n",chipInstanceData->droppedBytes);
    // printf("numValidBytes:%d\n\n", validBytes);
#endif

    if (chipInstanceData->isDelayed || chipInstanceData->droppedBytes)
    {

        // Adding the dangling bytes from last read in totalDroppedRecords
        *totalDroppedBytes += (NvU32) chipInstanceData->packetOffset + chipInstanceData->droppedBytes;

        bytesDiscarded = (chipInstanceData->droppedBytes + chipInstanceData->packetOffset) % packetSize;
        chipInstanceData->packetOffset = packetSize - (bytesDiscarded ? bytesDiscarded : packetSize);

        while (chipInstanceData->packetOffset)
        {
            chipInstanceData->packetOffset--;
            recordOffset = incrementRecordOffset(recordOffset);
            itr++;
        }
    }

    // Adding the invalid bytes in total dropped records
    *totalDroppedBytes += itr;

    for ( ; itr < validBytes; itr++)
    {
        chipInstanceData->packet[chipInstanceData->packetOffset++] = pModeERecord[recordOffset];

        if (chipInstanceData->packetOffset == packetSize) {
            status = maxwellOnPacket(chipInstanceData->packet, ctx);
            if (status != CUPROF_SUCCESS) {
                return status;
            }
            chipInstanceData->packetOffset = 0;
        }

        recordOffset = incrementRecordOffset(recordOffset);
    }

#ifdef ENABLE_SAMPLING_PRINTS
    // printf("bytesInPacket: %ld\n",chipInstanceData->packetOffset);
    // printf("sizeofDanglingPacket in current record: %ld\n\n",chipInstanceData->packetOffset);
#endif

    // Get the dropped bytes in the next record
    chipInstanceData->droppedBytes = getDroppedBytes(pModeERecord);

    chipInstanceData->isDelayed = isDelayed(pModeERecord);

    if (chipInstanceData->droppedBytes == MAX_DROPPED_COUNT)
    {
        CU_ERROR_PRINT(("\nERROR in parsing, too many dropped records to continue parsing!!!\n"));
        return CUPROF_ERROR_UNKNOWN;
    }

    return status;
}


//Following function parses data from SW buffer queue
static int maxwellPerfmonPCSamplingParseData(void *userData) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 bytesToParse = 0;
    CUctx *ctx;
    uint32_t totalDroppedBytes = 0;
    CUprofDeviceState *profDevState;
    size_t offset = 0, itr = 0;
    chiplet chips[MAX_SM_IN_MAXWELL];
    uint8_t *pModeERecords;
    uint16_t perfmonId, chipletType, chipIdx;

    CU_TRACE_FUNCTION();

    if (!userData)
        return CUPROF_ERROR_NOT_SUPPORTED;

    ctx = (CUctx *) userData;
    profDevState = &ctx->device->state.profilerState;
    

    if (!(cuiDeviceArchIsMaxwellGM20XPlus(ctx->device)))
        return CUPROF_ERROR_NOT_SUPPORTED;

    // Initialize the structure with zero
    for (itr = 0; itr < MAX_SM_IN_MAXWELL; ++itr) {
        chips[itr].droppedBytes = 0;
        chips[itr].packetOffset = 0;
        chips[itr].isDelayed = 0;
    }
    ctx->device->state.profilerState.totalDroppedRecords = 0;

    while(1) {
        if ((!profDevState->buffList) && (!ctx->device->state.profilerState.terminateSamplingParseDataThread)) {
            cuosThreadYield();
        }
#ifndef NV_MODS
        else if ((toolsListSize((tList *) profDevState->buffList) == 0) && (!ctx->device->state.profilerState.terminateSamplingParseDataThread)) {
            cuosThreadYield();
        } 
#endif
        else {
            CUprofBuff *tempBuff = NULL;
#ifndef NV_MODS
            tListItr *last = NULL;

            if ((toolsListSize((const tList *)profDevState->buffList) == 0) && (ctx->device->state.profilerState.terminateSamplingParseDataThread)) {
                break;
            }
            cuiMutexLock(&profDevState->buffListMutex);
            last = toolsListGetTail((tList *) profDevState->buffList);
            tempBuff = (CUprofBuff *) toolsListGetElem(last);
            toolsListRemove((tList *) profDevState->buffList, tempBuff, NULL, 0);
            cuiMutexUnlock(&profDevState->buffListMutex);
#endif
            pModeERecords = (uint8_t *)tempBuff->buff;
            //The size of buffer is expected to be multiple of 32 bytes as
            //we read data multiple of 32 bytes
            bytesToParse = tempBuff->buffSize;

#ifdef ENABLE_SAMPLING_PRINTS
            printf("bytesToParse = %d\n", bytesToParse);
#endif

            if(bytesToParse) {
#if 0
                //Enable, only if there is an error in parsing.
                fwrite((void*)recPtr, dataSizeof(char), bytesToParse, logfp);
                fflush(logfp);
                fclose(logfp);
#else

                for (offset = 0; offset < bytesToParse; offset += MAXWELL_RECORD_SIZE) {
                    uint8_t *pModeERecord = &pModeERecords[offset];
                    perfmonId = getPerfmonId(pModeERecord);
                    chipletType = perfmonId & 3;
                    chipIdx = (perfmonId & 0xFC) >> 2;
                    
                    //All the records expected should be from gpctpc domain.
                    CU_ASSERT(chipletType == PM_CHIPLET_TYPE_GPC);
                    
                    chiplet *chip = &chips[chipIdx];
                    
                    status = maxwellOnRecord(pModeERecord, chip, ctx, &totalDroppedBytes);
                    if (status != CUPROF_SUCCESS) {
                        ctx->device->state.profilerState.terminateSamplingThread = 1;
                        return (int) status;
                    }
                }
                ctx->device->state.profilerState.totalDroppedRecords += (totalDroppedBytes/PACKET_SIZE);
#endif
            }
            free(tempBuff->buff);
            free(tempBuff);
        }
    }
#ifdef ENABLE_SAMPLING_PRINTS
    printf("Exited parsing thread, tt = %d\n", (int)ctx->device->state.profilerState.terminateSamplingParseDataThread);
#endif
    
    return (int)status;
}

CUprofResult maxwellPerfmonPCSamplingSetConfig(CUctx *ctx, CUprofSamplingConfig config, NvBool flag) {
    //TBD Hardcoding now, since the period is in cycles, it will vary from gpu to gpu.
    //We can decide after the experiments what is the better value to derive any good
    //conclusion about the kernel code.
    //The actual sampling period will be = 2^(ctx->pmNew->samplingPeriod + 5)
    NvU32 gpcId = 0, totalTPCCount = 0;
    NvU32 gpcCount = ctx->device->state.limits.numGpcs;
    NvU32 periodCycles = 0,periodLevel = 0;
    NvU32 *tpcPerGpcCount = ctx->device->state.limits.numTpcsPerGpc;
    NvU32 units;

    if (!(cuiDeviceArchIsMaxwellGM20XPlus(ctx->device)))
        return CUPROF_ERROR_NOT_SUPPORTED;

    for (gpcId = 0; gpcId < gpcCount; gpcId++) {
        totalTPCCount += tpcPerGpcCount[gpcId];
    }

    // Compute the number of units as minimum of blocks and SM count
    if (config.numBlocks) {
        // Do not overwrite the period if user has already specified using 'period2'
        if (ctx->pmNew->isUserPeriod2) {
            return CUPROF_SUCCESS;
        }
        units = (NvU32) MIN(config.numBlocks, totalTPCCount);
    } else {
        units = totalTPCCount;
    }

    if (flag == 1) {        // Flag will be set if period2 is to be used
        /* 
        * This will set the period with user given value
        * Period = (2 ^ config.period)
        * E.G if config.period2 = 10, the sampling period will be (2^10) cycles.
        */

        // Clamp the value in between 5 and 31
        config.period2 = MIN(config.period2, 31);
        config.period2 = MAX(config.period2, 5);
        //The actual sampling period will be = 2^(ctx->pmNew->samplingPeriod + 5)
        ctx->pmNew->samplingPeriod = config.period2 - 5;
        ctx->pmNew->isUserPeriod2 = 1;
    }
    else {

        if (config.period) {
            ctx->pmNew->userPeriod = config.period;
            ctx->pmNew->isUserPeriod2 = 0;
        }


        /*
        * PRI streaming rate is 1 streaming rec(of 32 bytes that has 28 bytes payload) in 48 cycles (actually 24 cycles, but we consider it slower so multiple by 2)
        * We want (clockrate/48) records in 1 sec.
        * At a sampling period SP, it will generate (Clockrate * 5 * #SM)/(SP * 28)  records
        * (clockrate/48) = (Clockrate * 5 * #SM)/(SP * 28)
        * Resolving above equation it gives:
        * SP = (#SM * 5 * 48)/28
        */ 
        periodCycles = (PACKET_SIZE * units * CLOCKS_PER_STREAMING_RECORD_FROM_ROUTER_TO_PMA_ON_PRI * 2) / SIZE_OF_STREAMING_RECORD_PAYLOAD;
        ROUND_UP_POW2(periodCycles);
        PROF_COMPUTE_LOG2(periodLevel, periodCycles);
        periodLevel = MAX(5, periodLevel);
        periodLevel -= 5;

        switch(ctx->pmNew->userPeriod) {
        case CUPROF_SAMPLING_PERIOD_MIN:
            ctx->pmNew->samplingPeriod = MIN_SAMPLING_PERIOD;
            break;
        case CUPROF_SAMPLING_PERIOD_LOW:
            ctx->pmNew->samplingPeriod = MIN(MAX_SAMPLING_PERIOD, (MIN_SAMPLING_PERIOD + periodLevel)/2);
            break;
        case CUPROF_SAMPLING_PERIOD_MID:
            ctx->pmNew->samplingPeriod = MIN(MAX_SAMPLING_PERIOD, periodLevel);
            break;
        case CUPROF_SAMPLING_PERIOD_HIGH:
            ctx->pmNew->samplingPeriod = MIN(MAX_SAMPLING_PERIOD, (periodLevel + MAX_SAMPLING_PERIOD)/2);
            break;
        case CUPROF_SAMPLING_PERIOD_MAX:
            ctx->pmNew->samplingPeriod = MAX_SAMPLING_PERIOD;
            break;
        default:
            ctx->pmNew->samplingPeriod = 0;
        }
    }

    return CUPROF_SUCCESS;
}

//TBD change this api to accept device when device level streaming is implemented.
CUprofResult maxwellPerfmonEventSamplingSetConfig(CUctx *ctx, CUprofSamplingConfig *config) {
    //TBD Hardcoding now, since the period is in cycles, it will vary from gpu to gpu.
    //We can decide after the experiments what is the better value to derive any good
    //conclusion about app.
    switch(config->period) {
    case CUPROF_SAMPLING_PERIOD_MIN:
        ctx->pmNew->samplingPeriod = NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES_1K;
        break;
    case CUPROF_SAMPLING_PERIOD_LOW:
        ctx->pmNew->samplingPeriod = NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES_4K;
        break;
    case CUPROF_SAMPLING_PERIOD_MID:
        ctx->pmNew->samplingPeriod = NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES_16K;
        break;
    case CUPROF_SAMPLING_PERIOD_HIGH:
        ctx->pmNew->samplingPeriod = NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES_32K;
        break;
    case CUPROF_SAMPLING_PERIOD_MAX:
        ctx->pmNew->samplingPeriod = NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES_64K;
        break;
    default:
        ctx->pmNew->samplingPeriod = NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES_1K;
    }
    return CUPROF_SUCCESS;
}
