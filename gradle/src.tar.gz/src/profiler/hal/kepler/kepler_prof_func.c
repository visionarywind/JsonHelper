/*
 * Copyright 1993-2011 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

/******************************************************************************
*
*   Module: kepler_prof_func.c
*
*   Description:
*       Kernel instruction patching code related to profiler for kepler class.
*
******************************************************************************/

#include "kepler_perfmon_new.h"
#include "kepler_prof_func_SM30.h"
#include "kepler_prof_func_SM35.h"

#define KEPLER_SWINLO 0x20
#define KEPLER_LWINLO 0x24

static CUresult 
keplerInitializeConcKernelTraceTable(CUctx* ctx, ConcKernelTraceTable **concKernelTraceTablePtr)
{
    CUresult status = CUDA_SUCCESS;
    unsigned int smVersion;
    smVersion = ctx->device->state.major*10 + ctx->device->state.minor;
    if(smVersion >= 32 && smVersion <= 37) {
        *concKernelTraceTablePtr = cuKeplerSM35InitializeConcKernelTraceTable();
    }
    else if(smVersion >= 30 && smVersion < 32) {
        *concKernelTraceTablePtr = cuKeplerSM30InitializeConcKernelTraceTable();
    }
    else {
        CU_DEBUG_PRINT(("Invalid SM Version\n"));
        status = CUDA_ERROR_UNKNOWN;
    }
    return status;
}

// Top level Function that modifies code to collect sw counters
static CUresult 
keplerFuncCollectConcKernelTrace(CUctx* ctx, const CUfunc* func,  profilerHal *profilerHalPtr,
                         NvU32** patchedCode, NvU32* patchedSize)
{
    // patchedCode contains the patched original code
    // i.e. with EXITs replaced with longjmp
    // patchCode contains the Entry + Exit Patch
    CUresult status = CUDA_SUCCESS;
    unsigned int i;
    unsigned int *code;
    NvU32 longjmpToExitPatchHi = 0;
    NvU32 longjmpToExitPatchLo = 0;
    NvU32 jcalTarget = 0;
    NvU32 jcalStartInstrLo;
    NvU32 jcalStartInstrHi;
    NvU32 ldc64instrHi = 0;
    NvU32 ldc64instrLo = 0;
    NvU32 cbankNumber = 0;
    NvU32 cbankOffset = 0;
    NvU32 cccBitsVal = 0;
    NvU32 PRegBitsVal = 0;
    NvU32 ldcInstrEntryPatch, ldcInstrExitPatch, jcalInstEntryPatch;
    NvU32 *keplerConcKernelTraceEntryBinaryPatch, *keplerConcKernelTraceExitBinaryPatch, *patchEntry, *patchExit, *pCodeEnd;
    NvU32 entryPatchSize, exitPatchSize;
    ConcKernelTraceTable *concKernelTraceTablePtr =NULL;
    NvU32 numPadInstRequired;
    sassInstGen *sassInstGenPtr = profilerHalPtr->sassInstGenPtr;
    NvU32 *patchCode, patchSize;
    CUmemobj *memobj = NULL;
    NvU64 patchCodePC;

    status = keplerInitializeConcKernelTraceTable(ctx, &concKernelTraceTablePtr);
    if(status != CUDA_SUCCESS) {
        return status;
    }

    keplerConcKernelTraceEntryBinaryPatch = concKernelTraceTablePtr ->keplerConcKernelTraceEntryBinaryPatch;
    keplerConcKernelTraceExitBinaryPatch  = concKernelTraceTablePtr ->keplerConcKernelTraceExitBinaryPatch;

    // Modify LDC.64 c[][] instruction with cbank number and offset and create statment again
    // Insert this statement in entry and exit patches
    cbankNumber = ctx->profiler->concKernelTraceData->constBankNumber;
    cbankOffset = ctx->profiler->concKernelTraceData->offsetInBytes;

    sassInstGenPtr->LDC(&ldc64instrHi, &ldc64instrLo, cbankNumber, cbankOffset, REG_4, P_REG_7);

    ldcInstrEntryPatch = concKernelTraceTablePtr->ldcInstrEntryPatch;
    ldcInstrExitPatch  = concKernelTraceTablePtr->ldcInstrExitPatch;
    keplerConcKernelTraceEntryBinaryPatch[ldcInstrEntryPatch]     = ldc64instrLo;
    keplerConcKernelTraceEntryBinaryPatch[ldcInstrEntryPatch + 1] = ldc64instrHi;

    keplerConcKernelTraceExitBinaryPatch[ldcInstrExitPatch]     = ldc64instrLo;
    keplerConcKernelTraceExitBinaryPatch[ldcInstrExitPatch + 1] = ldc64instrHi;
    

    // Start creating patch
    code = (unsigned int*)cuiFuncGetCodeData(func, CU_CODE_DATA_MASTER);

    entryPatchSize = concKernelTraceTablePtr->entryPatchSize;
    exitPatchSize  = concKernelTraceTablePtr->exitPatchSize;
    patchSize = entryPatchSize + exitPatchSize;

    // Add NOP at the end of the patch to make the size of patch a multiple of 64 bytes
    numPadInstRequired = (CEIL_TO_MULTIPLE_OF_64(patchSize) - patchSize)/sizeof(NvU64);

    patchSize = CEIL_TO_MULTIPLE_OF_64(patchSize);
    patchCode = (NvU32*)malloc(patchSize);
    if(!patchCode) {
        CU_DEBUG_PRINT(("Failed to allocate storage for patchCode.\n"));
        status = CUDA_ERROR_OUT_OF_MEMORY;
        return status;
    }

    *patchedSize = func->codeSize;
    *patchedCode = (NvU32*)malloc(func->codeSize);
    if(!(*patchedCode)) {
        CU_DEBUG_PRINT(("Failed to allocate storage for patchedCode.\n"));
        status = CUDA_ERROR_OUT_OF_MEMORY;
        free (patchCode);
        patchCode = NULL;
        return status;
    }

    for (i = 0; i < func->codeSize/4; ) {
        if (sassInstGenPtr->isExitInst(code[i + 1], code[i])) {
            // Replace EXIT instruction with LONGJMP to exit patch

            // Create LONGJMP instruction
            longjmpToExitPatchHi = 0;
            longjmpToExitPatchLo = 0;
            cccBitsVal = 0;
            PRegBitsVal = 0;
            cccBitsVal = sassInstGenPtr->getCCCBits(code[i]);
            PRegBitsVal = sassInstGenPtr->getPRegBits(code[i]);
            sassInstGenPtr->LONGJMP(&longjmpToExitPatchHi, &longjmpToExitPatchLo, PRegBitsVal, cccBitsVal);

            (*patchedCode)[i + 1] = longjmpToExitPatchHi;
            (*patchedCode)[i]     = longjmpToExitPatchLo;
            i += 2;
        }
        else {
            (*patchedCode)[i + 1] = code[i + 1];
            (*patchedCode)[i]     = code[i];
            i +=2;
        }
    }

    patchEntry = patchCode;
    memcpy(patchEntry, keplerConcKernelTraceEntryBinaryPatch, entryPatchSize);

    // Unconditional JCAL first instr in user kernel
    jcalTarget = (NvU32)ctx->device->hal.funcGetStartPC((CUfunc *)func);
    sassInstGenPtr->JCAL(&jcalStartInstrHi, &jcalStartInstrLo, jcalTarget);

    jcalInstEntryPatch = concKernelTraceTablePtr->jcalInstEntryPatch;
    patchEntry[jcalInstEntryPatch]     = jcalStartInstrLo;
    patchEntry[jcalInstEntryPatch + 1] = jcalStartInstrHi;

    patchExit = patchEntry + entryPatchSize/4;
    memcpy(patchExit, keplerConcKernelTraceExitBinaryPatch, exitPatchSize);

    pCodeEnd = patchExit + exitPatchSize/4;
    profilerHalPtr->funcInsertICachePadding(sassInstGenPtr, pCodeEnd, numPadInstRequired);
    
    if(!ctx->profiler->concKernelTraceData->memobjList) {
        // memobjList hasn't been initialized yet, do it now
        status = listInit(&ctx->profiler->concKernelTraceData->memobjList, NULL, NULL, NULL, NULL);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to init linked list\n"));
            return status;
        }
    }
    // Allocate memory for the patch code
    status = cuiFuncAlloc(ctx, ctx->api, patchSize, func->codeAlign, &memobj);
    if (status != CUDA_SUCCESS) {
        return status;
    }

    status = listAddToTail(ctx->profiler->concKernelTraceData->memobjList, memobj);
    if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to add new data to linked list\n"));
            return status;
    }

    patchCodePC = ctx->device->hal.memobjGetPc(ctx, memobj);
    CU_ASSERT((patchCodePC % 8) == 0);

    CU_TRACE_PRINT(("Uploading patch code for function: %s (%u) to GPU VA 0x%llx\n",
            func->name, func->symbolIndex, memobjGetDeviceVaddr(memobj)));
    status = cuiMemcpyHtoD(
        ctx,
        memobj,
        0,
        patchCode,
        patchSize,
        ctx->barrierStream,
        CUI_MEMCPY_ASYNC_EXCEPT_PAGEABLE,
        NULL);
    if (status != CUDA_SUCCESS) {
        return status;
    }

    // Set offset to point to start of entry patch
    ((profFuncState_st *)(func->profFuncState))->pcOffset = (NvU32)patchCodePC - jcalTarget;

#ifdef DEBUG_SASS
    funcPatchDumpSASSpatch((NvU32 *)cuiFuncGetCodeData(func, CU_CODE_DATA_MASTER), func->codeSize, *patchedCode, *patchedSize);
    funcPatchDumpSASSpatch((NvU32 *)*patchedCode, *patchedSize, patchCode, patchSize);
#endif

    free(patchCode);
    patchCode = NULL;

    return status;
}

static int keplerGetPMSignalsIndex(NvU32 signalId)
{
    switch(signalId) {
        case KEPLER_SW_COUNTER_GLD8BIT_INST:
        case KEPLER_INTERNAL_SW_COUNTER_GLD8BIT_INST:
            return LD_INST_8BIT;

        case KEPLER_SW_COUNTER_GLD16BIT_INST:
        case KEPLER_INTERNAL_SW_COUNTER_GLD16BIT_INST:
            return LD_INST_16BIT;

        case KEPLER_SW_COUNTER_GLD32BIT_INST:
        case KEPLER_INTERNAL_SW_COUNTER_GLD32BIT_INST:
            return LD_INST_32BIT;

        case KEPLER_SW_COUNTER_GLD64BIT_INST:
        case KEPLER_INTERNAL_SW_COUNTER_GLD64BIT_INST:
            return LD_INST_64BIT;

        case KEPLER_SW_COUNTER_GLD128BIT_INST:
        case KEPLER_INTERNAL_SW_COUNTER_GLD128BIT_INST:
            return LD_INST_128BIT;

        case KEPLER_SW_COUNTER_GST8BIT_INST:
        case KEPLER_INTERNAL_SW_COUNTER_GST8BIT_INST:
            return ST_INST_8BIT;

        case KEPLER_SW_COUNTER_GST16BIT_INST:
        case KEPLER_INTERNAL_SW_COUNTER_GST16BIT_INST:
            return ST_INST_16BIT;

        case KEPLER_SW_COUNTER_GST32BIT_INST:
        case KEPLER_INTERNAL_SW_COUNTER_GST32BIT_INST:
            return ST_INST_32BIT;

        case KEPLER_SW_COUNTER_GST64BIT_INST:
        case KEPLER_INTERNAL_SW_COUNTER_GST64BIT_INST:
            return ST_INST_64BIT;

        case KEPLER_SW_COUNTER_GST128BIT_INST:
        case KEPLER_INTERNAL_SW_COUNTER_GST128BIT_INST:
            return ST_INST_128BIT;

        case KEPLER_SW_COUNTER_NC_GLD8BIT_INST:
            return LDG_INST_8BIT;

        case KEPLER_SW_COUNTER_NC_GLD16BIT_INST:
            return LDG_INST_16BIT;

        case KEPLER_SW_COUNTER_NC_GLD32BIT_INST:
            return LDG_INST_32BIT;

        case KEPLER_SW_COUNTER_NC_GLD64BIT_INST:
            return LDG_INST_64BIT;

        case KEPLER_SW_COUNTER_NC_GLD128BIT_INST:
            return LDG_INST_128BIT;

        default: 
            break;
    }
    return -1;
}

/***************************************************************************************
NOTE:-
Function which adds NOP at the end of the patch code
to ensure that the total number of instructions in the patch is multiple of 8.
For more info see http://nvbugs/825158 
****************************************************************************************/
static CUresult keplerFuncInsertICachePadding(sassInstGen *sassInstGenPtr,
                        NvU32 *patchCode,   // Actual address at the end of the present last instruction in the code
                        NvU32 numPadInstRequired) {
    NvU32 i =0, j;
    NvU32 branchTarget;

    if(numPadInstRequired) {
        // branchTarget = sizeof(NvU64)*-1;
        // This is split into two steps to avoid compiler error
        branchTarget = sizeof(NvU64);
        branchTarget *= -1;
        sassInstGenPtr->BRA((patchCode + i + 1), (patchCode + i), P_REG_7, CCC_BITS_CC_T, branchTarget);
        i += 2;
    }

    // Starting with j = 1 as we have already added one instruction
    for(j = 1; j < numPadInstRequired; j++) {
        sassInstGenPtr->NOP((patchCode+i+1), (patchCode+i), !SYNC_FLAG, !TRIG_FLAG, 0x0, P_REG_7);
        i += 2;
    }
    return CUDA_SUCCESS;
}

static CUresult keplerFuncLocateSSYs(CUctx* ctx, CUfunc* func)
{
    CU_ERROR_PRINT(("Locate SSY unsupported on kepler.\n"));
    CU_ASSERT(0);
    return CUDA_ERROR_UNKNOWN;
}

static CUresult keplerFuncPatchInstructions(CUctx* ctx, const CUfunc* func, NvU32** patchCode, NvU32* patchSize, CUprofPatchNopTrig* profPatchNopTrig)
{
    CU_ERROR_PRINT(("NOP trigger patching unsupported on kepler.\n"));
    CU_ASSERT(0);
    return CUDA_ERROR_UNKNOWN;
}

static CUresult keplerFuncCountBlockOnSM(CUctx* ctx, const CUfunc* func, NvU32** patchCode, NvU32* patchSize, CUprofPatchNopTrig* profPatchNopTrig)
{
    CU_ERROR_PRINT(("sm_cta_lauched unsupported through patching on kepler.\n"));
    CU_ASSERT(0);
    return CUDA_ERROR_UNKNOWN;
}

static CUresult keplerFuncRecordWarpEvent(CUctx* ctx, const CUfunc* func, NvU32** patchCode, NvU32* patchSize)
{
    CU_ERROR_PRINT(("Warp event trace unsupported on kepler.\n"));
    CU_ASSERT(0);
    return CUDA_ERROR_UNKNOWN;
}

// Function to initialize swCounterTable
static CUresult keplerFuncInitializeTables(NvU32 smVersion, profilerHal* profHal, NvU64 chip)
{
    CUresult status = CUDA_SUCCESS;

    // swCounterTable is same for fermi and kepler except for certain fields
    status = fermiFuncInitializeTables(smVersion, profHal);

    // Remove the following condition during clean up.
    if(profHal->patchFlag & CU_PROF_PATCH_FLAG_SW_COUNTER){
        profHal->swCounterTablePtr->swCountersDomain = KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST;
    }

    profHal->swCounterTablePtr->smemWinLo = KEPLER_SWINLO;
    profHal->swCounterTablePtr->lmemWinLo = KEPLER_LWINLO;
    profHal->swCounterTablePtr->getPMSignalsIndex = &keplerGetPMSignalsIndex;

    if(smVersion >= 32 && smVersion <= 37) {
        status = keplerSM35FuncInitializeTables(profHal, chip);
    }
    else if(smVersion >= 30 && smVersion < 32) {
        status = keplerSM30FuncInitializeTables(profHal);
    }
    else {
        CU_DEBUG_PRINT(("Invalid SM Version\n"));
        status = CUDA_ERROR_UNKNOWN;
    }
    return status;
}

static CUresult keplerFuncPatchConcKernelTraceSyncKernel(CUctx* ctx, const CUfunc* func, NvU32** patchCode, NvU32* patchSize)
{
    CU_ERROR_PRINT(("Sync kernel patching unsupported on kepler.\n"));
    CU_ASSERT(0);
    return CUDA_ERROR_UNKNOWN;
}

#if NVCFG(GLOBAL_ARCH_KEPLER)
CUresult keplerInitProfilerHal(profilerHal* profHal, NvU32 smVersion, NvU64 chip)
{
    CUresult status = CUDA_SUCCESS;
    if(profHal == NULL) {
        return CUDA_ERROR_UNKNOWN;
    }
    status = keplerFuncInitializeTables(smVersion, profHal, chip);
    profHal->funcApplyReloc = &fermiFuncApplyReloc;
    profHal->funcLocateSSYs = &keplerFuncLocateSSYs;
    profHal->funcPatchNOPTRIGInstructions = &keplerFuncPatchInstructions;
    profHal->funcCountBlockOnSM = &keplerFuncCountBlockOnSM;
    profHal->funcRecordWarpEvent = &keplerFuncRecordWarpEvent;
    profHal->funcCollectSwCounters = &funcCollectSwCounters;
    profHal->funcPatchConcKernelTraceSyncKernel = &keplerFuncPatchConcKernelTraceSyncKernel;
    profHal->funcCollectConcKernelTrace = &keplerFuncCollectConcKernelTrace;
    profHal->funcInsertICachePadding = &keplerFuncInsertICachePadding;
    return status;
}
#endif // NVCFG(GLOBAL_ARCH_KEPLER)
