/*
 * Copyright 2005-2011 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

#include "kepler_prof_func_SM30.h"

// SM Version 3.0 specific Patch code 
NvU32 keplerSM30ConcKernelTraceEntryBinaryPatch[] = {  
                                        0x4c005c04, 0x2c000001, // 1  S2R        R1, SR83;                  # globalTimer Hi
                                        0x48001c04, 0x2c000001, // 2  S2R        R0, SR82;                  # globalTimer Lo
                                        0x4c011c04, 0x2c000001, // 3  S2R        R4, SR83;                  # globalTimer Hi
                                        0x10105c23, 0x30800000, // 4  ICMP.LT    R1, R1, R4, R0;            # if(R0 < 0) R1 = R1, else R1 = R4
                                        0x94009c04, 0x2c000000, // 5  S2R        R2, SR_CTAid.X;            # load block.x
                                        0x9800dc04, 0x2c000000, // 6  S2R        R3, SR_CTAid.Y;            # load block.y
                                        0x9c011c04, 0x2c000000, // 7  S2R        R4, SR_CTAid.Z;            # load block.z
                                        0x0c209c03, 0x48000000, // 8  IADD       R2, R2, R3;                # add block.x + block.y 
                                        0x40000007, 0x60000001, // 9  SSY <inst 20>;                        # Create sync point at instruction #20
                                        0x0043dc23, 0x190ec000, // 10 ISETP.EQ      P1, R4, 0x0;            # P1 = (block.z == 0)
                                        0x00225c23, 0x1902c000, // 11 ISETP.EQ.AND  P1, P1, R2, 0x0, P1;    # P1 = (block.x + block.y) == 0 && block.z == 0)
                                        0xc00025e7, 0x40000000, // 12 @!P1 BRA Lab1;                        # if !(block == 0) return
                                        0x80011c04, 0x2c000000, // 13 S2R           R4, SR_Tid;             # load thread id (all 3 components)
                                        0x0043dc23, 0x190ec000, // 14 ISETP.EQ      P1, R4, 0x0;            # P1 = (thread == 0)
                                        0x001fdc24, 0x48800000, // 15 VOTE.ANY      P2, P1;                 # P2 = (warp == 0)
                                        0x400029e7, 0x40000000, // 16 @!P2 BRA Lab1;                        # if !(warp == 0) return
                                        0x23f11ca6, 0x14004400, // 17 LDC.64        R4, c[17][8];           # .rela { ImmConstant, BaseAddress, 0x0 }
                                        0x004004a5, 0x94000000, // 18 @P1 ST.E.64   [R4], R0;               # Store Clock
                                        0x00001df4, 0x40000000, // 19 Lab1: NOP.S;                          # Sync instruction for earlier divergence
                                        0x40000007, 0x58000000, // 20 PLONGJMP 0x18;                        # Prepare LONGJMP target to start of exit patch
                                        0x00010007, 0x10000000, // 21 JCAL 0X0;                             # JCAL start of kernel
                                        0x00001de7, 0x88000000, // 22 LONGJMP;                              # LONGJMP to exitpatch
};

NvU32 keplerSM30ConcKernelTraceExitBinaryPatch[] = { 
                                        //exit patch//
                                        0x00011c04, 0x2c000000, //  1 S2R           R4, SR_LaneId;
                                        0x0043dc23, 0x190ec000, //  2 ISETP.EQ      P1, R4, 0;
                                        0x4c005c04, 0x2c000001, //  3 S2R           R1, SR83;               # globalTimer Hi
                                        0x48001c04, 0x2c000001, //  4 S2R           R0, SR82;               # globalTimer Lo
                                        0x4c011c04, 0x2c000001, //  5 S2R           R4, SR83;               # globalTimer Hi
                                        0x10105c23, 0x30800000, //  6 ICMP.LT       R1, R1, R4, R0;         # if(R0 < 0) R1 = R1, else R1 = R4
                                        0x23f11ca6, 0x14004400, //  7 LDC.64        R4, c[17][8];           # Load buffer address from cbank
                                        0x404004a5, 0x94000000, //  8 @P1 ST.E.64   [R4+16], R0;            # Store Clock
                                        0x00001de7, 0x80000000, //  9 EXIT;                                 # exit code
                                    };

// Initializing ConcKernelTraceTable for SM 3.0
ConcKernelTraceTable SM30ConcKernelTraceTable = {
    CU_KEPLER_SM30_CONC_KERNEL_JCAL_START_INST_PATCH,
    CU_KEPLER_SM30_CONC_KERNEL_LDC_INST_ENTRY_PATCH,
    CU_KEPLER_SM30_CONC_KERNEL_LDC_INST_EXIT_PATCH,
    CU_KEPLER_SM30_CONC_KERNEL_TRACE_ENTRY_PATCH_SIZE,
    CU_KEPLER_SM30_CONC_KERNEL_TRACE_EXIT_PATCH_SIZE,
    CU_KEPLER_SM30_CONC_KERNEL_TRACE_ENTRY_PATCH_PTR,
    CU_KEPLER_SM30_CONC_KERNEL_TRACE_EXIT_PATCH_PTR,
};

// SM 3.0 Specific Functions

// Function to initialize ConcKernelTraceTable
ConcKernelTraceTable* cuKeplerSM30InitializeConcKernelTraceTable()
{
    return (&SM30ConcKernelTraceTable);
}

// Function to initialize Tables in Profiler Hal Structure
CUresult keplerSM30FuncInitializeTables(profilerHal* profHal)
{
    CUresult status = CUDA_SUCCESS;
    if(!profHal->swCounterTablePtr) {
        return CUDA_ERROR_UNKNOWN;
    }

    if(profHal->patchFlag & CU_PROF_PATCH_FLAG_NOPTRIG_SW_COUNTER){
        profHal->swCounterTablePtr->swCountersDomain = KEPLER_SW_COUNTERS_DOMAIN_GK104_NOPTRIG;
    }

    return status;
}
