/*
 * Copyright 2005-2011 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

#ifndef __KEPLER_PROF_FUNC_SM35_H__
#define __KEPLER_PROF_FUNC_SM35_H__

#include "kepler_prof_func.h"

// SM Version 3.5 specific Functions

// Function to initialize ConcKerneTable
ConcKernelTraceTable* cuKeplerSM35InitializeConcKernelTraceTable(void);

// Function to initialize profHal tables
CUresult keplerSM35FuncInitializeTables(profilerHal*, NvU64);

int keplerSM35GetOpcodeIndex(NvU64, NvBool*);

// SM Version 3.5 Specific Macro
#define REG_255  0xff

#define KEPLER_SM35_INST_SIZE_BYTES 8

#define CU_KEPLER_SM35_IS_EXIT_INSTR(instrHi, instrLo)                              \
        (((instrHi & 0xff800000) == 0x18000000) & ((instrLo & 0x00000003) == 0x00000000))

#define CU_KEPLER_SM35_IS_JCAL_INSTR(instrHi, instrLo)                   \
        (((instrHi & 0xff800000) == 0x10800000) & ((instrLo & 0x00000003) == 0x00000000))

#define CU_KEPLER_SM35_IS_JMP_INSTR(instrHi, instrLo)                   \
        (((instrHi & 0xff800000) == 0x11000000) & ((instrLo & 0x00000003) == 0x00000000))

#define CU_KEPLER_SM35_IS_JMX_INSTR(instrHi, instrLo)                   \
        (((instrHi & 0xff800000) == 0x10000000) & ((instrLo & 0x00000003) == 0x00000000))

#define CU_KEPLER_SM35_IS_CAL_INSTR(instrHi, instrLo)                   \
        (((instrHi & 0xff800000) == 0x13000000) & ((instrLo & 0x00000003) == 0x00000000))

#define CU_KEPLER_SM35_IS_BRA_INSTR(instrHi, instrLo)                   \
        (((instrHi & 0xff800000) == 0x12000000) & ((instrLo & 0x00000003) == 0x00000000))

#define CU_KEPLER_SM35_IS_BRX_INSTR(instrHi, instrLo)                   \
        (((instrHi & 0xff800000) == 0x12800000) & ((instrLo & 0x00000003) == 0x00000000))

#define CU_KEPLER_SM35_IS_PRET_INSTR(instrHi, instrLo)                   \
        (((instrHi & 0xff800000) == 0x13800000) & ((instrLo & 0x00000003) == 0x00000000))

#define CU_KEPLER_SM35_IS_PLONGJMP_INSTR(instrHi, instrLo)                   \
        (((instrHi & 0xff800000) == 0x14000000) & ((instrLo & 0x00000003) == 0x00000000))

#define CU_KEPLER_SM35_IS_SSY_INSTR(instrHi, instrLo)                   \
        (((instrHi & 0xff800000) == 0x14800000) & ((instrLo & 0x00000003) == 0x00000000))

#define CU_KEPLER_SM35_GET_CCC_BITS(instr)                      \
        ((instr & 0x0000007c) >> 2)

#define CU_KEPLER_SM35_GET_P_REG_BITS(instr)                   \
        ((instr & 0x003c0000) >> 18)

#define KEPLER_SM35_BRANCH_INSTR_HI_OPCODE                                        \
        (0x12000000)

#define KEPLER_SM35_BRANCH_INSTR_HI_IMMEDIATE(value)                              \
        ((value & 0x00fffe00) >> 9)

#define KEPLER_SM35_BRANCH_INSTR_LO_OPCODE                                        \
        (0x00000000)

#define KEPLER_SM35_BRANCH_INSTR_PREG(instr)                                       \
        ((instr & 0x0000000f) << 18)

#define KEPLER_SM35_BRANCH_INSTR_CCC_BITS(instr)                                \
        ((instr & 0x0000001f) << 2)

#define KEPLER_SM35_BRANCH_INSTR_LO_IMMEDIATE(value)                              \
        ((value & 0x000001ff) << 23)

#define CU_KEPLER_SM35_CREATE_BRANCH_INSTR(instrHi, instrLo, PReg, CCCbits, value)     \
        instrHi = (0                                                                   \
                   | KEPLER_SM35_BRANCH_INSTR_HI_OPCODE                                \
                   | KEPLER_SM35_BRANCH_INSTR_HI_IMMEDIATE(value)                      \
                   );                                                                  \
        instrLo = (0                                                                   \
                   | KEPLER_SM35_BRANCH_INSTR_LO_OPCODE                                \
                   | KEPLER_SM35_BRANCH_INSTR_PREG(PReg)                               \
                   | KEPLER_SM35_BRANCH_INSTR_CCC_BITS(CCCbits)                        \
                   | KEPLER_SM35_BRANCH_INSTR_LO_IMMEDIATE(value)                      \
                   );

#define KEPLER_SM35_LDC64_INSTR_HI_OPCODE                                                 \
        (0x7ca80000)

#define KEPLER_SM35_LDC64_INSTR_CBANK(cBank)                                              \
        (cBank << 7)

#define KEPLER_SM35_LDC64_INSTR_OFFSET_HI(offset)                                         \
        (offset >> 9)

#define KEPLER_SM35_LDC64_INSTR_LO_OPCODE                                                 \
        (0x001ffc02)

#define KEPLER_SM35_LDC64_INSTR_OFFSET_LO(offset)                                         \
        (offset << 23)

#define KEPLER_SM35_LDC64_INSTR_PREG(PReg)                                                \
        ((PReg & 0x0000000f) << 18)

#define KEPLER_SM35_LDC64_INSTR_DEST(dest)                                                \
        (dest << 2)

#define CU_KEPLER_SM35_CREATE_LDC64_INSTR(instrHi, instrLo, cBank, offset, dest, PReg)    \
        instrHi = (0                                                                      \
                   | KEPLER_SM35_LDC64_INSTR_HI_OPCODE                                    \
                   | KEPLER_SM35_LDC64_INSTR_CBANK(cBank)                                 \
                   | KEPLER_SM35_LDC64_INSTR_OFFSET_HI(offset)                            \
                   );                                                                     \
        instrLo = (0                                                                      \
                   | KEPLER_SM35_LDC64_INSTR_LO_OPCODE                                    \
                   | KEPLER_SM35_LDC64_INSTR_PREG(PReg)                                   \
                   | KEPLER_SM35_LDC64_INSTR_DEST(dest)                                   \
                   | KEPLER_SM35_LDC64_INSTR_OFFSET_LO(offset)                            \
                   );

#define KEPLER_SM35_MOV32I_INSTR_HI_OPCODE                               \
        (0x74000000)

#define KEPLER_SM35_MOV32I_INSTR_HI_IMMEDIATE(value)                     \
        (value >> 9)

#define KEPLER_SM35_MOV32I_INSTR_LO_OPCODE                               \
        (0x0003c002)

#define KEPLER_SM35_MOV32I_INSTR_LO_IMMEDIATE(value)                     \
        (value << 23)

#define KEPLER_SM35_MOV32I_INSTR_DEST(reg)                               \
        (reg << 2)

#define KEPLER_SM35_MOV32I_INSTR_PRED_BITS(preg)                         \
        (preg << 18)

//this creates an instruction of the type:
// @Pg MOV32I R2, 0x32000000;
#define CU_KEPLER_SM35_CREATE_MOV32I_INSTR(instrHi, instrLo, reg, value, preg)    \
        instrHi = (0                                                        \
                   | KEPLER_SM35_MOV32I_INSTR_HI_OPCODE                           \
                   | KEPLER_SM35_MOV32I_INSTR_HI_IMMEDIATE(value)                 \
                   );                                                       \
        instrLo = (0                                                        \
                   | KEPLER_SM35_MOV32I_INSTR_LO_OPCODE                           \
                   | KEPLER_SM35_MOV32I_INSTR_LO_IMMEDIATE(value)                 \
                   | KEPLER_SM35_MOV32I_INSTR_DEST(reg)                           \
                   | KEPLER_SM35_MOV32I_INSTR_PRED_BITS(preg)                     \
                   );

#define STL_TOP17   0x7aa00000
#define STL_LAST23  0x001ffc02
#define STL_REG_A   0x0003fc00 // These bits need to made all 1 for instruction to take imme addr
#define STL_LMEM_ADDR_HI(lmemAddr) (lmemAddr >> 9)
#define STL_LMEM_ADDR_LO(lmemAddr) (lmemAddr << 23)
#define STL_REG(reg) (reg << 2)

#define STL_HI(lmemAddr, reg) STL_TOP17 | STL_LMEM_ADDR_HI(lmemAddr)
#define STL_LO(lmemAddr, reg) STL_LMEM_ADDR_LO(lmemAddr) | STL_REG_A | STL_REG(reg) | STL_LAST23

#define LDL_TOP17   0x7a208000
#define LDL_LAST21  0x001c0002
#define LDL_REG_A   0x0003fc00
#define LDL_LMEM_ADDR_HI(lmemAddr) (lmemAddr >> 9)
#define LDL_LMEM_ADDR_LO(lmemAddr) (lmemAddr << 23)
#define LDL_REG(reg) (reg << 2)

#define LDL_HI(reg, lmemAddr) LDL_TOP17 | LDL_LMEM_ADDR_HI(lmemAddr)
#define LDL_LO(reg, lmemAddr) LDL_LMEM_ADDR_LO(lmemAddr) | LDL_REG_A | LDL_REG(reg) | LDL_LAST21

#define P2R_TOP32   0xc640007f
#define P2R_LAST32  0xff9ffc01
#define P2R_REG(reg) (reg << 2)

#define P2R_LO(reg) P2R_REG(reg) | P2R_LAST32
#define P2R_HI(reg) P2R_TOP32 

#define R2P_TOP32   0xc680007f
#define R2P_LAST32  0xff9c0001
#define R2P_REG(reg) (reg << 10)

#define R2P_LO(reg) R2P_REG(reg) | R2P_LAST32
#define R2P_HI(reg) R2P_TOP32 

#define RED_LAST10  0x000003fe
#define RED_U32_ADD_LO(regA, regB, PRegBits) (regA << 10) | (regB << 23) | (PRegBits << 18) | RED_LAST10
#define RED_U32_ADD_HI(regA, regB) 0x68080000

#define CU_KEPLER_SM35_GET_LD_EXT_ADDR(origInstrHi) \
        ((origInstrHi & 0x00800000) >> 23)

#define CU_KEPLER_SM35_GET_LD_ADDR_REG(origInstrLo) \
        ((origInstrLo & 0x0000fc00) >> 10)

#define CU_KEPLER_SM35_GET_LD_IMM32(origInstrHi, origInstrLo) \
        ((origInstrHi << 9) | (origInstrLo >> 23))

#define CU_KEPLER_SM35_GET_IMM24(origInstrHi, origInstrLo) \
        ((0x00ffffff & (origInstrHi << 9)) | (origInstrLo >> 23))

#define KEPLER_SM35_MOV_INSTR_HI_OPCODE 0xe4c03c00
#define KEPLER_SM35_MOV_INSTR_LO_OPCODE 0x001c0002

#define KEPLER_SM35_MOV_INSTR_SRC_REG(sourceReg)\
        (sourceReg << 23)

#define KEPLER_SM35_MOV_INSTR_DEST_REG(destReg)\
        (destReg << 2)

// Other bit-fields could be added later if required
#define CU_KEPLER_SM35_CREATE_MOV_INSTR(instrHi, instrLo, destReg, sourceReg) \
        instrHi = KEPLER_SM35_MOV_INSTR_HI_OPCODE;                            \
        instrLo = (0                                                    \
                   | KEPLER_SM35_MOV_INSTR_LO_OPCODE                          \
                   | KEPLER_SM35_MOV_INSTR_SRC_REG(sourceReg)                 \
                   | KEPLER_SM35_MOV_INSTR_DEST_REG(destReg)                  \
                   );

#define KEPLER_SM35_SSY_INSTR_HI_OPCODE                                           \
        (0x14800000)

#define KEPLER_SM35_SSY_INSTR_HI_IMMEDIATE(value)                                 \
        (value >> 9)

#define KEPLER_SM35_SSY_INSTR_LO_OPCODE                                           \
        (0x00000000)

#define KEPLER_SM35_SSY_INSTR_LO_IMMEDIATE(value)                                 \
        (value << 23)

// Other bit-fields could be added later if required
#define CU_KEPLER_SM35_CREATE_SSY_INSTR(instrHi, instrLo, value)                  \
        instrHi = (0                                                        \
                   | KEPLER_SM35_SSY_INSTR_HI_OPCODE                              \
                   | KEPLER_SM35_SSY_INSTR_HI_IMMEDIATE(value)                    \
                   );                                                       \
        instrLo = (0                                                        \
                   | KEPLER_SM35_SSY_INSTR_LO_OPCODE                              \
                   | KEPLER_SM35_SSY_INSTR_LO_IMMEDIATE(value)                    \
                   );

#define CU_KEPLER_SM35_CREATE_SRC_B_FIELD_FROM_REGISTER(reg)\
        (reg)

#define CU_KEPLER_SM35_CREATE_SRC_B_FIELD_FROM_CONSTANT_ADDRESS(bankNumber, bankOffset)\
        ((bankNumber << 14) | (bankOffset/4))

#define KEPLER_SM35_ISETP_INSTR_HI_OPCODE 0x13000000

#define KEPLER_SM35_ISETP_INSTR_CMP_BITS(cmp)\
        (cmp << 20)

#define KEPLER_SM35_ISETP_INSTR_BOP_BITS(bop)\
        (bop << 16)

#define KEPLER_SM35_ISETP_INSTR_PRED_SRC_BITS(predSrc)\
        (predSrc << 10)

#define KEPLER_SM35_ISETP_INSTR_SRC_B_FIELD_HI(srcB)\
        (srcB >> 9)

#define KEPLER_SM35_ISETP_INSTR_LO_OPCODE 0x001c001e

#define KEPLER_SM35_ISETP_INSTR_SRC_B_FIELD_LO(srcB)\
        (srcB << 23)

#define KEPLER_SM35_ISETP_INSTR_SRC_A_FIELD(regA)\
        (regA << 10)

#define KEPLER_SM35_ISETP_INSTR_PRED_DEST_BITS(predDest)\
        (predDest << 5)

// Other bit-fields could be added later if required
#define CU_KEPLER_SM35_CREATE_ISETP_INSTR(instrHi, instrLo, cmp, bop, predSrc, abc, srcB, regA, predDest)   \
        instrHi = (0                                                                                        \
                   | KEPLER_SM35_ISETP_INSTR_HI_OPCODE                                                      \
                   | KEPLER_SM35_ISETP_INSTR_CMP_BITS(cmp)                                                  \
                   | KEPLER_SM35_ISETP_INSTR_BOP_BITS(bop)                                                  \
                   | KEPLER_SM35_ISETP_INSTR_PRED_SRC_BITS(predSrc)                                         \
                   | KEPLER_SM35_ISETP_INSTR_SRC_B_FIELD_HI(srcB)                                           \
                  );                                                                                        \
        instrLo = (0                                                                                        \
                   | KEPLER_SM35_ISETP_INSTR_LO_OPCODE                                                      \
                   | KEPLER_SM35_ISETP_INSTR_SRC_B_FIELD_LO(srcB)                                           \
                   | KEPLER_SM35_ISETP_INSTR_SRC_A_FIELD(regA)                                              \
                   | KEPLER_SM35_ISETP_INSTR_PRED_DEST_BITS(predDest)                                       \
                  );                                                                                        \
    if(abc == ABC_RRR) {                                                                                    \
        instrHi |= 0xc8000000;                                                                              \
    }                                                                                                       \
    else if(abc == ABC_RIR) {                                                                               \
        instrHi |= 0xa0000000;                                                                              \
    }                                                                                                       \
    else {                                                                                                  \
        instrHi |= 0x48000000;                                                                              \
    }

#define KEPLER_SM35_PSETP_INSTR_HI_OPCODE 0x84800000

#define KEPLER_SM35_PSETP_INSTR_PRED_SRC1_BITS(predSrc1)\
        (predSrc1 << 10)

#define KEPLER_SM35_PSETP_INSTR_PRED_SRC2_BITS(predSrc2)\
        (predSrc2)

#define KEPLER_SM35_PSETP_INSTR_LO_OPCODE 0x001dc01e

#define KEPLER_SM35_PSETP_INSTR_BOP_BITS(bop)\
        (bop << 27)

#define KEPLER_SM35_PSETP_INSTR_PRED_DEST_BITS(predDest)\
        (predDest << 5)

// Other bit-fields could be added later if required
#define CU_KEPLER_SM35_CREATE_PSETP_INSTR(instrHi, instrLo, bop, predSrc1, predSrc2, predDest) \
        instrHi = (0                                                                     \
                   | KEPLER_SM35_PSETP_INSTR_HI_OPCODE                                         \
                   | KEPLER_SM35_PSETP_INSTR_PRED_SRC1_BITS(predSrc1)                          \
                   | KEPLER_SM35_PSETP_INSTR_PRED_SRC2_BITS(predSrc2)                          \
                  );                                                                     \
        instrLo = (0                                                                     \
                   | KEPLER_SM35_PSETP_INSTR_LO_OPCODE                                         \
                   | KEPLER_SM35_PSETP_INSTR_BOP_BITS(bop)                                     \
                   | KEPLER_SM35_PSETP_INSTR_PRED_DEST_BITS(predDest)                          \
                  );

// Other bit-fields could be added later if required
// Creates instruction LOP.AND R0, R0, R2;
#define KEPLER_SM35_LOP_INSTR_HI_OPCODE 0xe2000000
#define KEPLER_SM35_LOP_INSTR_LO_OPCODE 0x011c0002

#define KEPLER_SM35_NOP_INSTR_HI_OPCODE 0x85800000

#define KEPLER_SM35_NOP_INST_TRIG_BIT(trigFlag) \
        (trigFlag << 15)

#define KEPLER_SM35_NOP_INSTR_HI_IMMEDIATE(mask) \
        (mask >> 9)

#define KEPLER_SM35_NOP_INSTR_LO_OPCODE 0x00003c02

#define KEPLER_SM35_NOP_INSTR_SYNC_BIT(syncFlag) \
        (syncFlag << 22)

#define KEPLER_SM35_NOP_INSTR_LO_IMMEDIATE(mask) \
        (mask << 23)

#define KEPLER_SM35_NOP_INSTR_PRED_BITS(pred) \
        (pred << 18)

// Other bit-fields could be added later if required
#define CU_KEPLER_SM35_CREATE_NOP_INSTR(instrHi, instrLo, syncFlag, trigFlag, mask, pred) \
        instrHi = (0                                                                \
                   | KEPLER_SM35_NOP_INSTR_HI_OPCODE                                      \
                   | KEPLER_SM35_NOP_INSTR_HI_IMMEDIATE(mask)                             \
                   );                                                               \
        instrLo = (0                                                                \
                   | KEPLER_SM35_NOP_INSTR_LO_OPCODE                                      \
                   | KEPLER_SM35_NOP_INSTR_LO_IMMEDIATE(mask)                             \
                   | KEPLER_SM35_NOP_INSTR_SYNC_BIT(syncFlag)                             \
                   | KEPLER_SM35_NOP_INSTR_PRED_BITS(pred)                                \
                   | KEPLER_SM35_NOP_INST_TRIG_BIT(trigFlag)                              \
                   );

#define KEPLER_SM35_CAL_INSTR_HI_OPCODE 0x13000000

#define KEPLER_SM35_CAL_INSTR_HI_IMMEDIATE(target) \
        (target >> 9)

#define KEPLER_SM35_CAL_INSTR_LO_OPCODE 0x00000100

#define KEPLER_SM35_CAL_INSTR_LO_IMMEDIATE(target) \
        (target << 23)

// Other bit-fields could be added later if required
#define CU_KEPLER_SM35_CREATE_CAL_INSTR(instrHi, instrLo, target) \
        instrHi = (0                                        \
                   | KEPLER_SM35_CAL_INSTR_HI_OPCODE              \
                   | KEPLER_SM35_CAL_INSTR_HI_IMMEDIATE(target)   \
                   );                                       \
        instrLo = (0                                        \
                   | KEPLER_SM35_CAL_INSTR_LO_OPCODE              \
                   | KEPLER_SM35_CAL_INSTR_LO_IMMEDIATE(target)   \
                   );

#define KEPLER_SM35_JCAL_INSTR_HI_OPCODE 0x11000000

#define KEPLER_SM35_JCAL_INSTR_HI_IMMEDIATE(target) \
        (target >> 9)

#define KEPLER_SM35_JCAL_INSTR_LO_OPCODE 0x00000100

#define KEPLER_SM35_JCAL_INSTR_LO_IMMEDIATE(target) \
        (target << 23)

// Other bit-fields could be added later if required
#define CU_KEPLER_SM35_CREATE_JCAL_INSTR(instrHi, instrLo, target)  \
        instrHi = (0                                                \
                   | KEPLER_SM35_JCAL_INSTR_HI_OPCODE               \
                   | KEPLER_SM35_JCAL_INSTR_HI_IMMEDIATE(target)    \
                   );                                               \
        instrLo = (0                                                \
                   | KEPLER_SM35_JCAL_INSTR_LO_OPCODE               \
                   | KEPLER_SM35_JCAL_INSTR_LO_IMMEDIATE(target)    \
                   );

// Other bit-fields could be added later if required
// Creates VOTE.ANY R0, PT, PT;
#define CU_KEPLER_SM35_VOTE_INSTR_HI_OPCODE 0x86cf1c00
#define CU_KEPLER_SM35_VOTE_INSTR_LO_OPCODE 0x001c0002

// Other bit-fields could be added later if required
// Creates RET;
#define CU_KEPLER_SM35_RET_INSTR_HI_OPCODE 0x19000000
#define CU_KEPLER_SM35_RET_INSTR_LO_OPCODE 0x001c003c

// Other bit-fields could be added later if required
// Creates POPC R0, R0, 0xFFFFF;
#define CU_KEPLER_SM35_POPC_INSTR_HI_OPCODE 0xc84003ff
#define CU_KEPLER_SM35_POPC_INSTR_LO_OPCODE 0xff9c0001

// Other bit-fields could be added later if required
// Creates IMUL32I R0, R0, 8;
#define CU_KEPLER_SM35_IMUL32I_INSTR_HI_OPCODE 0x2e000000
#define CU_KEPLER_SM35_IMUL32I_INSTR_LO_OPCODE 0x041c0002

// Other bit-fields could be added later if required
// Creates BRX R0;
#define CU_KEPLER_SM35_BRX_INSTR_HI_OPCODE 0x12800000
#define CU_KEPLER_SM35_BRX_INSTR_LO_OPCODE 0x001c003c

#define KEPLER_SM35_LONGJMP_INSTR_HI_OPCODE                                     \
        (0x18800000)

#define KEPLER_SM35_LONGJMP_INSTR_LO_OPCODE                                     \
        (0x00000000)

#define KEPLER_SM35_LONGJMP_INSTR_PREG(instr)                                   \
        ((instr & 0x0000000f) << 18)

#define KEPLER_SM35_LONGJMP_INSTR_CCC_BITS(instr)                               \
        ((instr & 0x0000001f) << 2)

#define CU_KEPLER_SM35_CREATE_LONGJMP_INSTR(instrHi, instrLo, PReg, CCCbits)    \
        instrHi = (0                                                            \
                   | KEPLER_SM35_LONGJMP_INSTR_HI_OPCODE                        \
                   );                                                           \
        instrLo = (0                                                            \
                   | KEPLER_SM35_LONGJMP_INSTR_LO_OPCODE                        \
                   | KEPLER_SM35_LONGJMP_INSTR_PREG(PReg)                       \
                   | KEPLER_SM35_LONGJMP_INSTR_CCC_BITS(CCCbits)                \
                   );

#define KEPLER_SM35_IADD_INSTR_HI_OPCODE 0xe0800000

#define KEPLER_SM35_IADD_INSTR_HI_XM_BIT(xmFlag) \
        ((xmFlag & 0x00000001) << 14)

#define KEPLER_SM35_IADD_INSTR_HI_PSIGN_BIT(psign) \
        ((psign & 0x00000003) << 19)

#define KEPLER_SM35_IADD_INSTR_HI_WRITE_CC_BIT(ccFlag) \
        ((ccFlag & 0x00000001) << 18)

#define KEPLER_SM35_IADD_INSTR_LO_OPCODE 0x001c0002

#define KEPLER_SM35_IADD_INSTR_LO_DEST_REG(destReg) \
        ((destReg & 0x000000ff) << 2)

#define KEPLER_SM35_IADD_INSTR_LO_SRC_REG1(srcReg) \
        ((srcReg & 0x000000ff) << 10)

#define KEPLER_SM35_IADD_INSTR_LO_SRC_REG2(srcReg) \
        ((srcReg & 0x000000ff) << 23)

// Other bit-fields could be added later if required
#define CU_KEPLER_SM35_CREATE_IADD_INSTR(instrHi, instrLo, xmFlag, psign,   \
        destReg, ccFlag, srcReg1, srcReg2)                                  \
        instrHi = (0                                                        \
                   | KEPLER_SM35_IADD_INSTR_HI_OPCODE                       \
                   | KEPLER_SM35_IADD_INSTR_HI_XM_BIT(xmFlag)               \
                   | KEPLER_SM35_IADD_INSTR_HI_PSIGN_BIT(psign)             \
                   | KEPLER_SM35_IADD_INSTR_HI_WRITE_CC_BIT(ccFlag)         \
                   );                                                       \
        instrLo = (0                                                        \
                   | KEPLER_SM35_IADD_INSTR_LO_OPCODE                       \
                   | KEPLER_SM35_IADD_INSTR_LO_DEST_REG(destReg)            \
                   | KEPLER_SM35_IADD_INSTR_LO_SRC_REG1(srcReg1)            \
                   | KEPLER_SM35_IADD_INSTR_LO_SRC_REG2(srcReg2)            \
                   );

#define KEPLER_SM35_JMP_INSTR_HI_OPCODE 0x10800000

#define KEPLER_SM35_JMP_INSTR_HI_IMMEDIATE(target) \
        (target >> 9)

#define KEPLER_SM35_JMP_INSTR_LO_OPCODE 0x001c003c

#define KEPLER_SM35_JMP_INSTR_LO_IMMEDIATE(target) \
        (target << 23)

// Other bit-fields could be added later if required
#define CU_KEPLER_SM35_CREATE_JMP_INSTR(instrHi, instrLo, target)   \
        instrHi = (0                                                \
                   | KEPLER_SM35_JMP_INSTR_HI_OPCODE                \
                   | KEPLER_SM35_JMP_INSTR_HI_IMMEDIATE(target)     \
                   );                                               \
        instrLo = (0                                                \
                   | KEPLER_SM35_JMP_INSTR_LO_OPCODE                \
                   | KEPLER_SM35_JMP_INSTR_LO_IMMEDIATE(target)     \
                   );

// Other bit-fields could be added later if required
// Creates TEXDEPBAR 0x0;
#define CU_KEPLER_SM35_TEXDEPBAR_INSTR_HI_OPCODE 0x77000000
#define CU_KEPLER_SM35_TEXDEPBAR_INSTR_LO_OPCODE 0x001c0002

#define KEPLER_SM35_SHINT_INSTR_HI_OPCODE 0x08000000

#define KEPLER_SM35_SHINT_INSTR_HI_HINT(hint) \
        ((0x00ffffff & EXTRACT_HI_WORD(hint) << 2) | (EXTRACT_LO_WORD(hint) >> 30))

#define KEPLER_SM35_SHINT_INSTR_LO_OPCODE 0x00000000

#define KEPLER_SM35_SHINT_INSTR_LO_HINT(hint) \
        (EXTRACT_LO_WORD(hint) << 2)

// Other bit-fields could be added later if required
#define CU_KEPLER_SM35_CREATE_SHINT_INSTR(instrHi, instrLo, hint)   \
        instrHi = (0                                                \
                   | KEPLER_SM35_SHINT_INSTR_HI_OPCODE              \
                   | KEPLER_SM35_SHINT_INSTR_HI_HINT(hint)          \
                   );                                               \
        instrLo = (0                                                \
                   | KEPLER_SM35_SHINT_INSTR_LO_OPCODE              \
                   | KEPLER_SM35_SHINT_INSTR_LO_HINT(hint)          \
                   );

#define CREATE_WAITw_SHINT_MNEMONIC(wait)   \
    (0x20 | (wait - 1))

#define CREATE_HINT(hint, instNum, instHint)    \
    hint |= ((NvU64)instHint << ((instNum - 1) * 8));

#define CU_KEPLER_SM35_CONC_KERNEL_JCAL_START_INST_PATCH       40
#define CU_KEPLER_SM35_CONC_KERNEL_LDC_INST_ENTRY_PATCH        32
#define CU_KEPLER_SM35_CONC_KERNEL_LDC_INST_EXIT_PATCH         12

#define CU_KEPLER_SM35_CONC_KERNEL_TRACE_ENTRY_PATCH_SIZE     sizeof(keplerSM35ConcKernelTraceEntryBinaryPatch)
#define CU_KEPLER_SM35_CONC_KERNEL_TRACE_EXIT_PATCH_SIZE      sizeof(keplerSM35ConcKernelTraceExitBinaryPatch)

#define CU_KEPLER_SM35_CONC_KERNEL_TRACE_ENTRY_PATCH_PTR        keplerSM35ConcKernelTraceEntryBinaryPatch
#define CU_KEPLER_SM35_CONC_KERNEL_TRACE_EXIT_PATCH_PTR         keplerSM35ConcKernelTraceExitBinaryPatch

#endif
