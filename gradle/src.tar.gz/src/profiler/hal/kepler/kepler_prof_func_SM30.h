/*
 * Copyright 2005-2011 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

#ifndef __KEPLER_PROF_FUNC_SM30_H__
#define __KEPLER_PROF_FUNC_SM30_H__

#include "kepler_prof_func.h"

// SM Version 3.0 specific Functions

// Function to initialize ConcKerneTable
ConcKernelTraceTable* cuKeplerSM30InitializeConcKernelTraceTable(void);

// Function to initialize profHal tables
CUresult keplerSM30FuncInitializeTables(profilerHal*);

// SM Version 3.0 Specific Macro

#define CU_KEPLER_SM30_CONC_KERNEL_JCAL_START_INST_PATCH        40
#define CU_KEPLER_SM30_CONC_KERNEL_LDC_INST_ENTRY_PATCH         32
#define CU_KEPLER_SM30_CONC_KERNEL_LDC_INST_EXIT_PATCH          12

#define CU_KEPLER_SM30_CONC_KERNEL_TRACE_ENTRY_PATCH_SIZE       sizeof(keplerSM30ConcKernelTraceEntryBinaryPatch)
#define CU_KEPLER_SM30_CONC_KERNEL_TRACE_EXIT_PATCH_SIZE        sizeof(keplerSM30ConcKernelTraceExitBinaryPatch)

#define CU_KEPLER_SM30_CONC_KERNEL_TRACE_ENTRY_PATCH_PTR        keplerSM30ConcKernelTraceEntryBinaryPatch
#define CU_KEPLER_SM30_CONC_KERNEL_TRACE_EXIT_PATCH_PTR         keplerSM30ConcKernelTraceExitBinaryPatch

#endif
