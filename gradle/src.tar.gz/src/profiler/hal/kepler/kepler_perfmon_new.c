/*
* Copyright 1993-2009 by NVIDIA Corporation.  All rights reserved.  All
* information contained herein is proprietary and confidential to NVIDIA
* Corporation.  Any use, reproduction, or disclosure without the written
* permission of NVIDIA Corporation is prohibited.
*/

/******************************************************************************
*
*   Module: kepler_perfmon_new.c
*
*   Description:
*       Performance monitor support in compute driver architecture.
*
******************************************************************************/

#include <string.h>
#include <ctype.h>

#include "kepler_perfmon_new.h"
#include "kepler_signals.h"
#include "cuda_internal.h"
#include "cuda_device.h"
#include "cuda_macros.h"
#include "cuos.h"
#include "kepler/gk104/dev_perf.h"
#include "kepler/gk104/pm_signals.h"
#include "halo_helper.h"
#include "kepler/gk104/dev_ctxsw_prog.h"     // needed for falcon method
#include "cui/hal/kepler/kepler.h"
#include "perfmon_common.h"
#include "perfmon_new.h"
#include "stream_push.h"

#define FALSE_WATCH_BUS_SIGNAL 0xef
//TBD collect all scattered register settings for each domain and put in one function
//TBD Set register common function need to be different and should be thread safe
//TBD check all the parameters, pointers etc for validity.

// compare function for event group
static NvBool egCompareData(const void *data1, const void *data2) {
    return ( (CUeventGroup*)data1 == (CUeventGroup*)data2 );
}

// compare function for event (signal) Ids
static NvBool eventIdCompareData(const void *data1, const void *data2) {
    return (((CUeventDataBasic*)((CUeventInfo*)data1)->pEventData)->signalId == *(NvU32*)data2 );
}

CUprofResult StartExptModeB(const CUeventGroup *pEventGroup);
static NV_INLINE NvBool keplerIsPpaSoftwareCounterDomain(CUeventDomainID domainId, NvU64 arch);
static CUprofResult keplerDestroyEventGroup(CUeventGroup *pEventGroup);
//TBD : Shift these functions up in the file to get rid of declaration
static CUresult detectCounterOverflowSMInternal(const CUeventGroup *pEventGroup, NvBool* bIsOverflow);
static CUresult SetupPMRegistersSMInternal(CUeventGroup *pEventGroup);
static CUresult resetPMSMInternal(CUeventGroup *pEventGroup);
static CUresult logPMCountersSMInternal(CUeventGroup *pEventGroup);
static CUresult setPMEnableRegSM(const CUeventGroup *pEventGroup, NvBool bEnable);
// Broadcast version of SetupPMRegistersSMInternal:
static CUresult SetupPMRegistersSM_bc(CUeventGroup *pEventGroup, NvU32 eventGroupQctl, NvU32 eventGroupCore, 
                                        NvU32 enableQctl, NvU32 enableCore);
// Broadcast version of resetPMSMInternal:
static CUresult resetPMSM_bc(CUeventGroup *pEventGroup);
// Unicast version of SetupPMRegistersSMInternal:
static CUresult SetupPMRegistersSM(CUeventGroup *pEventGroup, NvU32 eventGroupQctl, NvU32 eventGroupCore, 
                                    NvU32 enableQctl, NvU32 enableCore);
// Unicast version of resetPMSMInternal:
static CUresult resetPMSM(CUeventGroup *pEventGroup);
static CUprofResult PMReleaseModeB(const CUeventGroup *pEventGroup);
static NvU32 getCounterMultiplicationFactor_GK10x(CUeventID eventId);
static NvU32 getCounterMultiplicationFactor_GK11x(CUeventID eventId);
static NvBool getSplittingInfo(CUeventID eventId, NvU32 *splitWidth, NvU32 isMembarWarEnabled);

/*******************************************************************************
SMPC (SM performance counters) require custom ctxsw ucode to properly disable
counters as early as possible in the save routine and enable the counters as
late as possible in the restore routine. In addition some of the registers are
per QCTL (as opposed to per SM) and need to be saved and restored without
corrupting the QCTL PRI mapping registers.
This Falcon05 method sets the SMPC CTXSW MODE for ensuring the same.
********************************************************************************/
#if defined(NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_QUAD)
static CUresult setFalcon05Method(CUctx* ctx)
{
    CUresult status = CUDA_SUCCESS;
    CUnvCurrent* nvCurrent = NULL;
    uint32_t data, mask;
    uint32_t headerOffset, headerType, headerIndex, accessHeader;
    int i = 0;

    CU_TRACE_FUNCTION();

    if (ctx->pmNew->flag & CU_PM_FLAG_FALCON_05_METHOD) {
        // falcon05 method is already set
        return CUDA_SUCCESS;
    }

    // https://wiki.nvidia.com/fermi/index.php/Fermi_Firmware_Methods#Class_0x9097.2C_SetFalcon05
    //
    // SetFaclon05              = data access_header
    // SetMmeShadowScratch[0]   = flag register
    // SetMmeShadowScratch[1]   = data
    // SetMmeShadowScratch[2]   = mask

    streamBeginPush(ctx->streamManager, CU_CHANNEL_COMPUTE, ctx->barrierStream, &nvCurrent, NULL);

    data = REF_NUM(NV_CTXSW_MAIN_IMAGE_SMPC_MODE, NV_CTXSW_MAIN_IMAGE_SMPC_MODE_CTXSW);
    mask = DRF_SHIFTMASK(NV_CTXSW_MAIN_IMAGE_SMPC_MODE);
    headerOffset = REF_NUM(NV_CTXSW_MAIN_IMAGE_ACCESS_HEADER_OFFSET, NV_CTXSW_MAIN_IMAGE_PM);
    headerType   = REF_NUM(NV_CTXSW_MAIN_IMAGE_ACCESS_HEADER_TYPE, NV_CTXSW_MAIN_IMAGE_ACCESS_HEADER_TYPE_MAIN);
    headerIndex  = REF_NUM(NV_CTXSW_MAIN_IMAGE_ACCESS_HEADER_INDEX, 0);
    accessHeader = headerOffset | headerType | headerIndex;

    NV_PUSH_1U(A0C0, WAIT_FOR_IDLE,  0);

    NV_PUSH_3U(A0C0, SET_MME_SHADOW_SCRATCH(0), 0,
                     SET_MME_SHADOW_SCRATCH(1), data,
                     SET_MME_SHADOW_SCRATCH(2), mask);
    NV_PUSH_1U(A0C0, SET_FALCON05, accessHeader);

    for (i  = 0; i < 10; i++) {
        NV_PUSH_1U(A0C0, NO_OPERATION, 0);
    }

    NV_PUSH_1U(A0C0, WAIT_FOR_IDLE,  0);

    streamEndPush(ctx->barrierStream, nvCurrent, NULL);

    // Wait for the write to complete
    status = cuiCtxSynchronize(ctx);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Ctx sync failed following Falcon05 method.\n"));
        return status;
    }

    // set flag
    ctx->pmNew->flag |= CU_PM_FLAG_FALCON_05_METHOD;

    return status;
}
#endif

static NvU32 getCounterMultiplicationFactor_GK10x(CUeventID eventId) {
    // see bug 876915 for a complete list of counters
    // which require multiplication factor
    // TODO: current list is valid for GK104/106/110 chips
    // verify for other chips as and when they come
    switch(eventId) {
        case KEPLER_HWPM_ACTIVE_WARPS:
        case KEPLER_SM_ACTIVE_WARPS:
        case KEPLER_SM_THREAD_INST_EXECUTED:
        case KEPLER_SM_NOT_PREDICATED_OFF_THREAD_INST_EXECUTED:
            return 2;
        default:
            return 1;
    }

    return 0;
}

static NvU32 getCounterMultiplicationFactor_GK11x(CUeventID eventId) {
    // see bug 876915 for a complete list of counters
    // which require multiplication factor
    // TODO: current list is valid for GK104/106/110 chips
    // verify for other chips as and when they come
    switch(eventId) {
        case KEPLER_HWPM_ACTIVE_WARPS:
        case KEPLER_SM_ACTIVE_WARPS:
        case KEPLER_SM_THREAD_INST_EXECUTED:
        case KEPLER_SM_NOT_PREDICATED_OFF_THREAD_INST_EXECUTED:
            return 2;
        /*************************************************************************************************************
        The warp_cant_issue_* signals will not require a multiplication factor if profiled via HWPM.
        GK110 - reasons are the most significant 4-bits of the 5-bit signal plus a carry bit for the LSB.
                So the final value of these counters needs to be multiplied by 2.
        **************************************************************************************************************/
        case KEPLER_SM_WARP_CANT_ISSUE_BARRIER:
        case KEPLER_SM_WARP_CANT_ISSUE_NO_INST:
        case KEPLER_SM_WARP_CANT_ISSUE_DISPATCH_STALL:
        case KEPLER_SM_WARP_CANT_ISSUE_PARTIALLY_LOADED_SUBTILE:
        case KEPLER_SM_WARP_CANT_ISSUE_SWITCHING_IFB:
        case KEPLER_SM_WARP_CANT_ISSUE_WAITING:
        case KEPLER_SM_WARP_CANT_ISSUE_MULTI_ISSUE:
        case KEPLER_SM_WARP_CANT_ISSUE_REPLAY_EXECUTING:
        case KEPLER_SM_WARP_CANT_ISSUE_TEX_EXECUTING:
        case KEPLER_SM_WARP_CANT_ISSUE_TEX_DEPENDENCY:
        case KEPLER_SM_WARP_CANT_ISSUE_L1_MISS_DEPENDENCY:
        case KEPLER_SM_WARP_CANT_ISSUE_MSB_FULL:
        case KEPLER_SM_WARP_CANT_ISSUE_IMC_MISS_DEPENDENCY:
        case KEPLER_SM_WARP_CANT_ISSUE_SHADOW_PIPE_THROTTLE:
        case KEPLER_SM_WARP_CANT_ISSUE_TEX_THROTTLE:
        case KEPLER_SM_WARP_CANT_ISSUE_RIB_THROTTLE:
        case KEPLER_SM_WARP_CANT_ISSUE_TEX_LOCK_MISMATCH:
        case KEPLER_SM_WARP_CANT_ISSUE_MEMBAR:
        case KEPLER_SM_WARP_CANT_ISSUE_HOLD_MISMATCH:
        case KEPLER_SM_WARP_CANT_ISSUE_NOT_SELECT:
            return 2;
        default:
            return 1;
    }

    return 0;
}

static NvBool getSplittingInfo(CUeventID eventId, NvU32 *splitWidth, NvU32 isMembarWarEnabled)
{
    switch(eventId) {
        case KEPLER_SM_ACTIVE_WARPS:
            if(isMembarWarEnabled) {
                *splitWidth = 3;
            }
            else {
                *splitWidth = 2;
            }
            break;
        case KEPLER_SM_PRT_PENDING_ENTRIES:
            *splitWidth = 4;
            break;
        default:
            *splitWidth = 0;
            return NV_FALSE;
    }
    return NV_TRUE;
}

CUprofResult keplerPerfmonGetInstanceValues(CUdev *dev, CUdomainData *domainData, NvU32 *avail, NvU32 *total)
{
    NvU32 k = 0;
    if(!avail || !total)
        return CUPROF_ERROR_INVALID_PARAMETER;

    *avail = *total = 1;
    if (domainData->domainId == KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST)
        return CUPROF_SUCCESS;

    switch(domainData->chipletType)
    {
    case PM_CHIPLET_TYPE_GPC:
        *total = 0;
        if((domainData->domainId == KEPLER_CLK_DOMAIN_GK110_GPC0) ||
           (domainData->domainId == KEPLER_CLK_DOMAIN_GK104_GPC0)){
            *total = dev->state.limits.numGpcs;
        } else {
        for(k=0; k<dev->state.limits.numGpcs; k++) {
            *total += dev->state.limits.numTpcsPerGpc[k];
        }
        }
            *avail = *total;
        break;
    case PM_CHIPLET_TYPE_FBP:
        *total = dev->state.limits.numFbps;
        *avail = *total;
        break;
    case PM_CHIPLET_TYPE_SYS:
        *total = 1;
        *avail = *total;
        break;
    default:
        CU_ASSERT(0);
        break;
    }
    return CUPROF_SUCCESS;
}

CUprofResult keplerPerfmonDeviceInitEventDomainInfo(CUdev *pDev) {
    CUprofResult status = CUPROF_SUCCESS;
    void *pSignalTable = NULL;
    CUdomainData *pDomainData = NULL;
    NvU32 maxInternalSignals = 0;
    NvU32 maxExternalSignals = 0;
    NvU32 numDomains = 0;
    NvU32 numInternalDomains = 0;
    NvU32 i = 0;
    NvU32 sigTableIdx = 0;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pDev);

    if(pDev->state.pDomainInfo == NULL) {
        return CUPROF_ERROR_UNKNOWN;
    }

    if (pDev->state.pDomainInfo->bInit) {
        // domain data is already populated
        return CUPROF_SUCCESS;
    }
    else
    {
        NvBool internalCountersExposed = 0;
        NvU32 signalTableEntrySize = 0;
        unsigned int old = cuosInterlockedExchange(&pDev->state.pDomainInfo->bInitStarted, 1);
        if (old == 0) {
            perfmonDemangleStrings();
            internalCountersExposed = perfmonInternalCountersExposed();
            numDomains = pDev->state.pDomainInfo->numDomains;

            if(!internalCountersExposed) {
                for (i = 0; i < numDomains; i++) {
                        if (!strncmp(pDev->state.pDomainInfo->pDomainTable[i].domainName, PM_INTERNAL_SIGNAL_PREFIX, 2)) {
                            numInternalDomains++;
                        }
                }
                numDomains -= numInternalDomains;
            }

            pDev->state.pDomainInfo->numDomains = numDomains;

            for (i = 0; i < numDomains; i++) {
                maxExternalSignals = maxInternalSignals = 0;
                for(sigTableIdx = 0; sigTableIdx < pDev->state.pDomainInfo->pDomainTable[i].numPerfSignalTables; sigTableIdx++) {
                    perfmonGetSizeOfSignalTableEntry(pDev->state.pDomainInfo->pDomainTable[i].pEventTableInfo[sigTableIdx].signalTableType,
                                                     &signalTableEntrySize);
                    pSignalTable = pDev->state.pDomainInfo->pDomainTable[i].pEventTableInfo[sigTableIdx].pEventData;
                    if (pSignalTable != NULL) {
                        while (((CUeventDataBasic*)pSignalTable)->signalId != INVALID_PM_SIGNAL_NEW) {
                            // Increment for only EXPOSED type of signals:
                            if (SIG_TYPE_IS_EXPOSED(((CUeventDataBasic*)pSignalTable)->signalId)) {
                                maxExternalSignals++;
                            }
                            // Increment for exposed but internal and internally exposed for testing type signals:
                            else if (!SIG_TYPE_IS_INTERNAL(((CUeventDataBasic*)pSignalTable)->signalId)){
                                maxInternalSignals++;
                            }
                            pSignalTable = (void*)((NvU8*)pSignalTable + signalTableEntrySize);
                        }
                    }
                }
                pDomainData = &pDev->state.pDomainInfo->pDomainTable[i];

                pDomainData->maxExternalEvents = maxExternalSignals;
                pDomainData->maxInternalEvents = maxInternalSignals;

                if(internalCountersExposed) {
                    pDomainData->exposedEvents         = maxExternalSignals + maxInternalSignals;
                }
                else {
                    pDomainData->exposedEvents         = maxExternalSignals;
                }
            }
            cuosInterlockedIncrement(&pDev->state.pDomainInfo->bInit);
        }
        else {
            // Another thread has started initialization, all other threads
            // must wait until it has completed.
            while (pDev->state.pDomainInfo->bInit == 0) {
                cuosThreadYield();
            }
        }
    }

    return status;
}

//Allocate the arch specific eventgroup structure and initialize it
static CUprofResult keplerInitEventGroup(CUeventGroup *pEventGroup)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUkeplerEventGroup *pKeplerEg = NULL;

    CU_TRACE_FUNCTION();

    if(pEventGroup->arch.keplerEventGroup == NULL) {
        pKeplerEg = (CUkeplerEventGroup*)malloc(sizeof(CUkeplerEventGroup));
        if(!pKeplerEg) {
            CU_ERROR_PRINT(("Failed to allocate memory for CUkeplerEventGroup\n"));
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto Error;
        }
        cuosMemset(pKeplerEg, 0, sizeof(CUkeplerEventGroup));

        pEventGroup->arch.keplerEventGroup = pKeplerEg;

        //TBD allocation of domain specific structures can be delayed until the
        //first event is added, saves memory
        //Following is used only for PM signals
        pKeplerEg->pParsedClk = (CUparsedClk*)malloc(sizeof(CUparsedClk));

        if (!pKeplerEg->pParsedClk) {
            CU_ERROR_PRINT(("Failed to allocate memory for CUparsedClk\n"));
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto Error;
        }
        cuosMemset(pKeplerEg->pParsedClk, 0, sizeof(CUparsedClk));

        //Following is used only for SM counters
        pKeplerEg->pSM = (CUSMCtrInfo*)malloc(sizeof(CUSMCtrInfo));

        if (!pKeplerEg->pSM) {
            CU_ERROR_PRINT(("Failed to allocate memory for CUSMCtrInfo\n"));
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto Error;
        }
        cuosMemset(pKeplerEg->pSM, 0, sizeof(CUSMCtrInfo));
    }

Error:
    if (status != CUPROF_SUCCESS) {
        keplerDestroyEventGroup(pEventGroup);
    }

    return status;
}

//Destroy the arch specific eventgroup structure
static CUprofResult keplerDestroyEventGroup(CUeventGroup *pEventGroup)
{
    NvU32 idx = 0;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if(pEventGroup->domainId != KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST) {
        if(pEventGroup->arch.keplerEventGroup)
        {
            if(pEventGroup->arch.keplerEventGroup->pParsedClk)
            {
                // Freeing the extra space as well which is allocated for profiling elapsed_clocks
                for (idx = 0; idx < (CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS + CU_PROF_ELAPSED_CLOCK_SLOT) ; idx++) {
                    if(pEventGroup->arch.keplerEventGroup->pParsedClk->pParsedUnit[idx])
                    {
                        free (pEventGroup->arch.keplerEventGroup->pParsedClk->pParsedUnit[idx]);
                        pEventGroup->arch.keplerEventGroup->pParsedClk->pParsedUnit[idx] = NULL;
                    }
                }
                if(pEventGroup->arch.keplerEventGroup->pParsedClk->values) {
                    free (pEventGroup->arch.keplerEventGroup->pParsedClk->values);
                    pEventGroup->arch.keplerEventGroup->pParsedClk->values = NULL;
                }

                free(pEventGroup->arch.keplerEventGroup->pParsedClk);
                pEventGroup->arch.keplerEventGroup->pParsedClk = NULL;
            }

            if(pEventGroup->arch.keplerEventGroup->pSM)
            {
                NvU32 sig_cnt = 0, smcntr_idx = 0, j = 0;
                CUSMCtrInfo *pSM = NULL;
                pSM=pEventGroup->arch.keplerEventGroup->pSM;
                if(pSM->values) {
                    free (pSM->values);
                    pSM->values = NULL;
                }
                if(pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_SMPERF) {
                    // Free the memory allocated additionally for splitted counters, if any.
                    for(sig_cnt=0; sig_cnt < pEventGroup->totalCounters; sig_cnt++)
                    {
                        if(pSM->splitParts[sig_cnt] > 1) {
                            for(j=smcntr_idx; j<(smcntr_idx + pSM->splitParts[sig_cnt]); j++) {
                                free(pSM->sigtableInfo[j]->pEventData);
                                free(pSM->sigtableInfo[j]);
                            }
                        }
                        smcntr_idx += pSM->splitParts[sig_cnt];
                    }
                }
                free(pSM);
                pSM = NULL;
            }

            free(pEventGroup->arch.keplerEventGroup);
            pEventGroup->arch.keplerEventGroup = NULL;
        }
    }

    return CUPROF_SUCCESS;
}

CUprofResult keplerPerfmonEventGroupCreate(CUctx *pCtx, CUeventGroup **pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    CUeventGroup *pGroup = NULL;

    CU_TRACE_FUNCTION();

    CU_ASSERT(pEventGroup);
    CU_ASSERT(pCtx);

    pGroup = (CUeventGroup*)malloc(sizeof(CUeventGroup));
    if (pGroup == NULL) {
        CU_DEBUG_PRINT(("Failed to allocate memory to event group\n"));
        return CUPROF_ERROR_OUT_OF_MEMORY;
    }
    cuosMemset(pGroup, 0, sizeof(CUeventGroup));

    pGroup->domainId = INVALID_DOMAIN_ID;
    pGroup->pCtx = pCtx;                 //Context for which eventgroup is created

    *pEventGroup = pGroup;

    if (pCtx->pmNew == NULL) {
        status = perfmonStructCreate(&pCtx->pmNew);
        if (status != CUPROF_SUCCESS) {
            goto Exit;
        }
    }

    switch(pCtx->device->state.chip) {
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110:
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK208:
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK208S
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK208S:
#endif
#if NVCFG(GLOBAL_GPU_IMPL_GK20A) || NVCFG(GLOBAL_CHIP_T124)
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK20A:
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_T12X + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_T124:
#endif // NVCFG(GLOBAL_GPU_IMPL_GK20A) || NVCFG(GLOBAL_CHIP_T124)
#if NVCFG(GLOBAL_CHIP_T132)
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_T13X + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_T132:
#endif // NVCFG(GLOBAL_CHIP_T132)
            pGroup->pCtx->pmNew->isMembarWarEnabled = 1;
        break;

        default:
            pGroup->pCtx->pmNew->isMembarWarEnabled = 0;
        break;
    }

    if (pCtx->pmNew->egList == NULL) {
        // event object list hasn't been init yet, do it now
        status = (CUprofResult)listInit(&pCtx->pmNew->egList, NULL, NULL, NULL, egCompareData);
        if (status != CUPROF_SUCCESS) {
            goto Exit;
        }
    }

    // add to the event group list maintained in the context
    listAddToHead(pCtx->pmNew->egList, *pEventGroup);

    pCtx->pmNew->totalEventGroups++;
    return CUPROF_SUCCESS;

Exit:
    //If any error occurs, free allocated memory and return NULL
    keplerDestroyEventGroup(pGroup);
    free(pGroup->values);
    free(pGroup);
    free (pCtx->pmNew);
    pCtx->pmNew = NULL;

    *pEventGroup = NULL;
    CU_ERROR_PRINT(("keplerPerfmonEventGroupCreate Failed\n"));
    return status;
}

CUprofResult keplerPerfmonEventGroupDestroy(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 i = 0;
    CUeventInfo *currEvent = NULL;
    void *eventBase = NULL;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if (pEventGroup->isEnabled) {
        // don't allow destroy for enabled event group
        return CUPROF_ERROR_UNKNOWN;
    }

    // deallocate arch specific eventgroup
    status = keplerDestroyEventGroup(pEventGroup);

    currEvent = (CUeventInfo*)listGetNext(pEventGroup->pEventInfoList, &eventBase);
    for (i = 0; (i < pEventGroup->totalCounters) && currEvent; i++, currEvent = (CUeventInfo*)listGetNext(NULL, &eventBase)) {
        if(currEvent) {
            if((pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW) ||
                (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW)) {
                free(currEvent->pEventData);
            }
            free(currEvent);
        }
    }

    // destroy event list
    if (pEventGroup->pEventInfoList) {
        listDestroy(pEventGroup->pEventInfoList);
        pEventGroup->pEventInfoList = NULL;
    }
    // deallocate values array
    free (pEventGroup->values);
    pEventGroup->values = NULL;

    // remove event group from list first
    listRemFrom(pEventGroup->pCtx->pmNew->egList, pEventGroup);

    // reduce event group count in context
    pEventGroup->pCtx->pmNew->totalEventGroups--;

    if(pEventGroup->nopTrigSwCounterData) {
        free(pEventGroup->nopTrigSwCounterData);
        pEventGroup->nopTrigSwCounterData = NULL;
    }
    free (pEventGroup);
    pEventGroup = NULL;

    return status;
}

// traverse domain signal table for matching signal
static NV_INLINE CUeventInfo* keplerLookupDomainSignalTable(CUdomainData *pDomainData, const NvU32 eventID)
{
    NvU32 sigTableIdx = 0, signalTableEntrySize = 0;
    CUeventInfo* pEventTableInfo_temp = NULL;
    void* pEventData = NULL;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pDomainData);

    pEventTableInfo_temp = (CUeventInfo*)calloc(1, sizeof(CUeventInfo));
    if (pEventTableInfo_temp == NULL) {
        CU_DEBUG_PRINT(("Failed to allocate memory to pEventTableInfo_temp\n"));
        return NULL;
    }
    for(sigTableIdx = 0; sigTableIdx < pDomainData->numPerfSignalTables; sigTableIdx++) {
        perfmonGetSizeOfSignalTableEntry(pDomainData->pEventTableInfo[sigTableIdx].signalTableType,
                                         &signalTableEntrySize);

        pEventData = pDomainData->pEventTableInfo[sigTableIdx].pEventData;
        while (((CUeventDataBasic*)pEventData)->signalId != INVALID_PM_SIGNAL_NEW) {
            if (eventID == ((CUeventDataBasic*)pEventData)->signalId) {
                pEventTableInfo_temp->signalTableType = pDomainData->pEventTableInfo[sigTableIdx].signalTableType;
                pEventTableInfo_temp->pEventData = pEventData;
                return pEventTableInfo_temp;
            }
            pEventData = (void*)((NvU8*)pEventData + signalTableEntrySize);
        }

    }
    // return NULL if not found
    free(pEventTableInfo_temp);
    return NULL;
}

static CUprofResult getWatchbus(signalConfig *tempSignalConfig, NvU32 startBit, NvU32 partWidth, NvU32 width, NvU32 *out)
{
    NvU32 startWord = 0;
    NvU32 endWord = 0;
    NvU32 startPos = 0;
    NvU32 endPos = 0;
    NvU32 startWatchBus = 0;
    NvU32 endWatchBus = 0;

    NvU32 endBit = (startBit+partWidth-1);
    startWord = startBit >> 2; startPos = startBit & 3;
    endWord = endBit >> 2; endPos = endBit & 3;
    startWatchBus = tempSignalConfig->tempWatchbus[startWord];
    endWatchBus = tempSignalConfig->tempWatchbus[endWord];

    startPos *= 8; endPos = ((endPos + 1) * 8) - 1;
    *out = 0;
    if (startWatchBus == endWatchBus) {
        *out = REF_VAL(endPos:startPos, startWatchBus);
    } else {
        *out |= REF_VAL(31:startPos, startWatchBus);
        *out |= (REF_VAL(endPos:0, endWatchBus)) << (32 - startPos);
        //*out |= startWatchBus >> (startPos * 8);
        //*out |= endWatchBus << ((4 - startPos) * 8);
    }

    if (partWidth < width) {
        //false watchbus signal to avoid garbage values
        startWatchBus = (FALSE_WATCH_BUS_SIGNAL<<24) | (FALSE_WATCH_BUS_SIGNAL<<16) |
                        (FALSE_WATCH_BUS_SIGNAL<<8) | (FALSE_WATCH_BUS_SIGNAL);
        *out |= (REF_VAL((width*8-1):(partWidth*8), startWatchBus)) << (partWidth*8);
    }

    return CUPROF_SUCCESS;
}

static CUprofResult getEventSpec(const CUparsedClk *pTempParsedClk, signalConfig *tempSignalConfig, NvU32 *pEventSpec, NvU32 *pNewMode) {

    NvU32 mode = tempSignalConfig->mode;
    NvU32 busWidth = tempSignalConfig->busWidth;

    CU_TRACE_FUNCTION();

    *pEventSpec = 0;

    // select the right event specification for each counter
    if (pTempParsedClk) {
        //Check mode compatibility first
        //Check if this counter has event available
        //set new mode if everything goes fine
        switch(mode) {
            case NV_PMM_CONTROL_ADDTOCTR_INCR:
                //buswidth will not be 1 when the counter incremnts on logical combination of signals.
                //CU_ASSERT(busWidth == 1);
                //if ((pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_VIVEK) && (tempSignalConfig->busWidth == 0))
                //    return CUPROF_ERROR_NOT_COMPATIBLE;

                if ((pTempParsedClk->eventSpecUsed & NV_PMM_SAMPLE) == 0) {
                    *pEventSpec = NV_PMM_SAMPLE;
                    tempSignalConfig->watchBus[NV_PMM_SAMPLE_BIT_POS] = tempSignalConfig->tempWatchbus[0];
                    tempSignalConfig->partNumber |= (NV_PMM_SAMPLE_BIT_POS + 1);
                }
                else if ((pTempParsedClk->eventSpecUsed & NV_PMM_TRIG0) == 0) {
                    *pEventSpec = NV_PMM_TRIG0;
                    tempSignalConfig->watchBus[NV_PMM_TRIG0_BIT_POS] = tempSignalConfig->tempWatchbus[0];
                    tempSignalConfig->partNumber |= (NV_PMM_TRIG0_BIT_POS + 1);
                }
                //Keep TRIG1 and EVENT at the end so that we can allow the event/TRIG 4/6 modes along with INCR
                else if ((pTempParsedClk->eventSpecUsed & NV_PMM_EVENT) == 0) {
                    *pEventSpec = NV_PMM_EVENT;
                    tempSignalConfig->watchBus[NV_PMM_EVENT_BIT_POS] = tempSignalConfig->tempWatchbus[0];
                    tempSignalConfig->partNumber |= (NV_PMM_EVENT_BIT_POS + 1);
                }
                else if ((pTempParsedClk->eventSpecUsed & NV_PMM_TRIG1) == 0) {
                    *pEventSpec = NV_PMM_TRIG1;
                    tempSignalConfig->watchBus[NV_PMM_TRIG1_BIT_POS] = tempSignalConfig->tempWatchbus[0];
                    tempSignalConfig->partNumber |= (NV_PMM_TRIG1_BIT_POS + 1);
                }
                else
                    //All 4 events are used
                    return CUPROF_ERROR_MAX_LIMIT_REACHED;

                //Should be either INCR or any mode higher than it.
                if (pTempParsedClk->mode != (NvU32)-1) {
                    *pNewMode = pTempParsedClk->mode;
                }
                break;

            case NV_PMM_CONTROL_ADDTOCTR_EVENT4:
            case NV_PMM_CONTROL_ADDTOCTR_TRIG4:
                CU_ASSERT(busWidth <= 4);

            case NV_PMM_CONTROL_ADDTOCTR_EVENT6:
            case NV_PMM_CONTROL_ADDTOCTR_TRIG6:
                CU_ASSERT(busWidth <= 6);
                if ((pTempParsedClk->mode != NV_PMM_CONTROL_ADDTOCTR_INCR) && (pTempParsedClk->mode != (NvU32) -1))
                    return CUPROF_ERROR_NOT_COMPATIBLE;

                if ((pTempParsedClk->eventSpecUsed & NV_PMM_TRIG1) || (pTempParsedClk->eventSpecUsed & NV_PMM_EVENT))
                    //The events required for the mode are not available
                    return CUPROF_ERROR_NOT_COMPATIBLE;

                if (busWidth == 2) {
                    tempSignalConfig->watchBus[NV_PMM_EVENT_BIT_POS] |= (tempSignalConfig->tempWatchbus[1] & 0x0000ffff);
                } else {
                    tempSignalConfig->watchBus[NV_PMM_TRIG1_BIT_POS] = tempSignalConfig->tempWatchbus[1];
                    tempSignalConfig->watchBus[NV_PMM_EVENT_BIT_POS] |= tempSignalConfig->tempWatchbus[0];
                }

                *pEventSpec = NV_PMM_TRIG1 | NV_PMM_EVENT;

                *pNewMode = mode;
                break;

            case NV_PMM_CONTROL_ADDTOCTR_VIVEK:
                if ((pTempParsedClk->mode != (NvU32) -1) && (pTempParsedClk->mode != NV_PMM_CONTROL_ADDTOCTR_VIVEK))
                    return CUPROF_ERROR_NOT_COMPATIBLE;

                {
                    NvU32 partNumber = 0, startPos = 0, partWidth = 0, out = 0, eventSpecUsed = 0;
                    eventSpecUsed = pTempParsedClk->eventSpecUsed;
                    while (busWidth > 0) {
                        //Keep TRIG1 and EVENT at the end so that we can allow the event/TRIG 4/6 modes along with INCR
                        if ((eventSpecUsed & NV_PMM_SAMPLE) == 0) {
                            *pEventSpec |= NV_PMM_SAMPLE; eventSpecUsed |= NV_PMM_SAMPLE;
                            partWidth = (busWidth >= 3) ? 3 : busWidth;
                            getWatchbus(tempSignalConfig, startPos, partWidth, 3, &out);
                            //TBD add false signal here at the beginning if busWidth < 3
                            startPos += partWidth;
                            //SAMPLE and TRIG0 increment the signal from 3:1.
                            tempSignalConfig->watchBus[NV_PMM_SAMPLE_BIT_POS] = (out << 8);
                            busWidth -= partWidth;
                            //Adding + 1 to eventspec position as it can't be 0 becuase then we cannot
                            //distinguish between uninitialized and spec 0.
                            //Can't initialize to 0xff as we need to OR the part numbers (increases complexity)
                            tempSignalConfig->partNumber |= ((NV_PMM_SAMPLE_BIT_POS + 1) << (partNumber * 8));
                            partNumber++;
                        }
                        else if ((eventSpecUsed & NV_PMM_TRIG0) == 0)  {
                            *pEventSpec |= NV_PMM_TRIG0; eventSpecUsed |= NV_PMM_TRIG0;
                            partWidth = (busWidth >= 3) ? 3 : busWidth;
                            getWatchbus(tempSignalConfig, startPos, partWidth, 3, &out);
                            //TBD add false signal here at the beginning if busWidth < 3
                            startPos += partWidth;
                            //SAMPLE and TRIG0 increment the signal from 3:1.
                            tempSignalConfig->watchBus[NV_PMM_TRIG0_BIT_POS] = (out << 8);
                            busWidth -= partWidth;
                            tempSignalConfig->partNumber |= ( (NV_PMM_TRIG0_BIT_POS + 1) << (partNumber * 8));
                            partNumber++;
                        }
                        else if ((eventSpecUsed & NV_PMM_EVENT) == 0) {
                            *pEventSpec |= NV_PMM_EVENT; eventSpecUsed |= NV_PMM_EVENT;
                            partWidth = (busWidth >= 4) ? 4 : busWidth;
                            getWatchbus(tempSignalConfig, startPos, partWidth, 4, &out);
                            //TBD add false signal here at the beginning if busWidth < 4
                            startPos += partWidth;
                            tempSignalConfig->watchBus[NV_PMM_EVENT_BIT_POS] = out;
                            busWidth -= partWidth;
                            tempSignalConfig->partNumber |= ((NV_PMM_EVENT_BIT_POS + 1) << (partNumber * 8));
                            partNumber++;
                        }
                        else if ((eventSpecUsed & NV_PMM_TRIG1) == 0) {
                            *pEventSpec |= NV_PMM_TRIG1; eventSpecUsed |= NV_PMM_TRIG1;
                            partWidth = (busWidth >= 4) ? 4 : busWidth;
                            getWatchbus(tempSignalConfig, startPos, partWidth, 4, &out);
                            //TBD add false signal here at the beginning if busWidth < 4
                            startPos += partWidth;
                            tempSignalConfig->watchBus[NV_PMM_TRIG1_BIT_POS] = out;
                            busWidth -= partWidth;
                            tempSignalConfig->partNumber |= ((NV_PMM_TRIG1_BIT_POS + 1) << (partNumber * 8));
                            partNumber++;
                        }
                        else {
                            //CU_ASSERT(0);
                            //All 4 events are used
                            return CUPROF_ERROR_NOT_COMPATIBLE;
                        }
                    }
                }
                *pNewMode = mode;
                break;
        }
    }
    return CUPROF_SUCCESS;
}


#define GETVAL(n, drf) (((n)>>DRF_SHIFT(drf))&DRF_MASK(drf))
#define SETVAL(n, drf) (((n)&DRF_MASK(drf))<<DRF_SHIFT(drf))

#define CHECK_AND_SET_GROUP_ADD(oldAdd, newAdd) \
    do { \
        if ((oldAdd != INVALID_ADDRESS) && (oldAdd != newAdd)) {\
            status = CUPROF_ERROR_NOT_COMPATIBLE; \
            goto EXIT; \
        } else if (oldAdd == INVALID_ADDRESS) { \
            oldAdd = newAdd; \
        } \
    } while(0)

#define CHECK_AND_SET_GROUP_MASK_VAL(oldMask, oldVal, drf, val) \
    do { \
            if((oldMask != 0) && (GETVAL(oldMask, drf)!=0)) {\
                n = GETVAL(oldVal, drf); \
                if (val != n) {\
                    status = CUPROF_ERROR_NOT_COMPATIBLE; \
                    goto EXIT;  \
                }\
            } else {\
                oldMask = DRF_REPLACE(oldMask, 0xffffffff, endBit:startBit);\
                oldVal  = DRF_REPLACE(oldVal, val, endBit:startBit);\
            }\
        } while(0)

static CUprofResult performUnitCompatibilityCheck(CUparsedClk *pParsedClk, PerfUnitTable *tempPerfUnitTable, signalConfig *tempSignalConfig, CUeventDataHwpm * pEventData, NvU32 init)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 k =0, j = 0, n = 0, i = 0, startBit = 0, endBit = 0, secondSelAddressReqd = 0;
    NvU32 foundInTemp = 0, foundInParsedClk = 0;

    if ((pEventData->pmUnitId == PM_UNIT_TEX_M) || (pEventData->pmUnitId == PM_UNIT_TEX_S) ||
        (pEventData->pmUnitId == PM_UNIT_TEX_D) || (pEventData->pmUnitId == PM_UNIT_LTC5)||
        (pEventData->pmUnitId == PM_UNIT_LTC) || (pEventData->pmUnitId == PM_UNIT_LTC1) ||
        (pEventData->pmUnitId == PM_UNIT_LTC2) || (pEventData->pmUnitId == PM_UNIT_LTC3)) {
        secondSelAddressReqd = 1;
    }

    while (tempPerfUnitTable[j].pmUnitId != PM_UNIT_MAX) {
        if (tempPerfUnitTable[j].pmUnitId == pEventData->pmUnitId) {

            //if (init)
            {
                i = 0;
                while(tempSignalConfig->unitInfo[i]) {
                    if (tempSignalConfig->unitInfo[i]->groupSelAddress == tempPerfUnitTable[j].pmGroupSelRegInfo.regOffset) {
                        //another signal with same unit has already been added while preparing config for this expt
                        //Should be true only for expt cases
                        //Check if the signal is from same instance valid for L2 and TEX only.
                        if ((tempSignalConfig->instance != pEventData->eventGroup1) &&
                            (secondSelAddressReqd)){
                            status = CUPROF_ERROR_NOT_COMPATIBLE;
                            goto EXIT;
                        }
                        foundInTemp = 1;
                        break;
                    }
                    i++;
                }
                k = 0;
                while(pParsedClk && pParsedClk->pParsedUnit[k] && !foundInTemp) {
                    //Check if have already added any signal from same unit and same group
                    //if so, assign those values to temp values so that we can check if
                    //we are using same group else return error.
                    if (pParsedClk->pParsedUnit[k]->groupSelAddress == tempPerfUnitTable[j].pmGroupSelRegInfo.regOffset) {

                        tempSignalConfig->unitInfo[i] = (signalUnitConfig *) malloc(sizeof(signalUnitConfig));
                        if (!tempSignalConfig->unitInfo[i]) {
                            status = CUPROF_ERROR_OUT_OF_MEMORY;
                            goto EXIT;
                        }
                        //CU_ASSERT(pParsedClk->pParsedUnit[k]->unitId == tempPerfUnitTable[j].pmUnitId);
                        tempSignalConfig->unitInfo[i]->groupSelAddress = pParsedClk->pParsedUnit[k]->groupSelAddress;
                        tempSignalConfig->unitInfo[i]->groupSelMask = pParsedClk->pParsedUnit[k]->groupSelMask;
                        tempSignalConfig->unitInfo[i]->groupSelValue = pParsedClk->pParsedUnit[k]->groupSelValue;
                        tempSignalConfig->unitInfo[i]->unitId = pParsedClk->pParsedUnit[k]->unitId;
                        if (secondSelAddressReqd) {
                            tempSignalConfig->unitInfo[i]->groupSelAddress1 = pParsedClk->pParsedUnit[k]->groupSelAddress1;
                            tempSignalConfig->unitInfo[i]->groupSelMask1 = pParsedClk->pParsedUnit[k]->groupSelMask1;
                            tempSignalConfig->unitInfo[i]->groupSelValue1 = pParsedClk->pParsedUnit[k]->groupSelValue1;
                            if (pParsedClk->pParsedUnit[k]->instance != pEventData->eventGroup1) {
                                status = CUPROF_ERROR_NOT_COMPATIBLE;
                                goto EXIT;
                            }

                        }
                        foundInParsedClk = 1;
                        break;
                    }
                    k++;
                }
            }

            if (!foundInParsedClk && !foundInTemp) {
                //This is a new unit
                tempSignalConfig->unitInfo[i] = (signalUnitConfig *) malloc(sizeof(signalUnitConfig));
                if (!tempSignalConfig->unitInfo[i]) {
                    status = CUPROF_ERROR_OUT_OF_MEMORY;
                    goto EXIT;
                }
                memset(tempSignalConfig->unitInfo[i], 0, sizeof(signalUnitConfig));
                tempSignalConfig->unitInfo[i]->groupSelAddress = INVALID_ADDRESS;
                tempSignalConfig->unitInfo[i]->groupSelAddress1 = INVALID_ADDRESS;
                tempSignalConfig->unitInfo[i]->unitId = pEventData->pmUnitId;
            }

            CHECK_AND_SET_GROUP_ADD(tempSignalConfig->unitInfo[i]->groupSelAddress, tempPerfUnitTable[j].pmGroupSelRegInfo.regOffset);

            startBit = tempPerfUnitTable[j].pmGroupSelRegInfo.firstBit;
            endBit   = startBit + tempPerfUnitTable[j].pmGroupSelRegInfo.subFieldWidth - 1;
            //This macro should check if the group is already set, the value shgoudl be equal, if not return error.
            CHECK_AND_SET_GROUP_MASK_VAL(tempSignalConfig->unitInfo[i]->groupSelMask, tempSignalConfig->unitInfo[i]->groupSelValue, endBit:startBit, pEventData->eventGroup);

#if 0
            //TBD enable this part only of we can remove SetPMEnableReg.
            CU_ASSERT(tempSignalConfig->unitInfo[i]->groupSelAddress == tempPerfUnitTable[j].pPMEnableRegInfo->regOffset)
            startBit = tempPerfUnitTable[j].pPMEnableRegInfo.firstBit;
            endBit   = startBit + tempPerfUnitTable[j].pPMEnableRegInfo.subFieldWidth - 1;
            CHECK_AND_SET_GROUP_MASK_VAL(tempSignalConfig->unitInfo[i]->groupSelMask, tempSignalConfig->unitInfo[i]->groupSelValue, endBit:startBit, 1);
#endif
            if (secondSelAddressReqd) {
                CHECK_AND_SET_GROUP_ADD(tempSignalConfig->unitInfo[i]->groupSelAddress1, tempPerfUnitTable[j].pmGroupSelRegInfo1.regOffset);

                startBit = tempPerfUnitTable[j].pmGroupSelRegInfo1.firstBit;
                endBit   = startBit + tempPerfUnitTable[j].pmGroupSelRegInfo1.subFieldWidth - 1;
                //This macro should check if the group is already set, the value shgoudl be equal, if not return error.
                CHECK_AND_SET_GROUP_MASK_VAL(tempSignalConfig->unitInfo[i]->groupSelMask1, tempSignalConfig->unitInfo[i]->groupSelValue1, endBit:startBit, pEventData->eventGroup1);

                tempSignalConfig->instance = pEventData->eventGroup1;
#if 0
                //TBD enable this part only of we can remove SetPMEnableReg.
                startBit = tempPerfUnitTable[j].pPMEnableRegInfo1.firstBit;
                endBit   = startBit + tempPerfUnitTable[j].pPMEnableRegInfo1.subFieldWidth - 1;
                CHECK_AND_SET_GROUP_MASK_VAL(tempSignalConfig->unitInfo[i]->groupSelMask, tempSignalConfig->unitInfo[i]->groupSelValue, endBit:startBit, 1);
#endif
            }
            tempSignalConfig->unitInfo[i]->pPerfUnitTable = &tempPerfUnitTable[j];
            break;
        }
        j++;
    }
EXIT:
    return status;
}

static CUprofResult getExptConfig(CUeventGroup *pEventGroup, CUdomainData *pDomainData, CUeventDataHwpmExpt *pEventData,
                                  signalConfig *tempSignalConfig)
{
    CUeventDataHwpm *pEventdataTemp[7] = {NULL};
    CUeventInfo *pEventInfoTemp[7] = {NULL};
    CUeventInfo *pEventInfoIncr = NULL;
    NvU32 j = 0, numSignals = 0, k = 0, busWidthIncrSignal = 0;
    CUprofResult status = CUPROF_SUCCESS;
    CUparsedClk *pParsedClk =  pEventGroup->arch.keplerEventGroup->pParsedClk;

    numSignals = 0;
    //TBD add support for 7 signal combination later
    while((pEventData->signalId_combination[numSignals] != INVALID_PM_SIGNAL_NEW) && (numSignals < 4))
    {
        pEventInfoTemp[numSignals] = keplerLookupDomainSignalTable(pDomainData, pEventData->signalId_combination[numSignals]);
        if(pEventInfoTemp[numSignals])
        {
            pEventdataTemp[numSignals] = (CUeventDataHwpm*)pEventInfoTemp[numSignals]->pEventData;
            //CU_ASSERT(pEventdataTemp[numSignals]->pmUnitId == pEventData->pmUnitId); //For LTC this assert will not be valid, check for groupreg and mask instead.
            CU_ASSERT(pEventdataTemp[numSignals]->busWidth == 1);
            tempSignalConfig->tempWatchbus[0] |= ((pEventdataTemp[numSignals]->watchBus & 0xff) << (numSignals * 8));

            status = performUnitCompatibilityCheck(pParsedClk, pEventGroup->pCtx->device->state.pPerfUnitTable, tempSignalConfig, pEventdataTemp[numSignals], (!numSignals));
            if (status != CUPROF_SUCCESS) {
                numSignals++;
                goto EXIT;
            }
        } else {
            status = CUPROF_ERROR_INVALID_EVENT_ID;
            numSignals++;
            goto EXIT;
        }
        numSignals++;
    }
    if ((numSignals > 4) && (numSignals == 0)) {
        //Support upto 7 bit combination later
        //numSignals = 0 so we cannot call this a real expt,
        //in expt, it is assumed that the combination is valid
        CU_ASSERT(0);
            status = CUPROF_ERROR_NOT_COMPATIBLE;
            goto EXIT;
        }
    if (pEventData->signalId_increment != INVALID_PM_SIGNAL_NEW) {
        pEventInfoIncr = keplerLookupDomainSignalTable(pDomainData, pEventData->signalId_increment);
        if (!pEventInfoIncr) {
            //Increment event not found
            status = CUPROF_ERROR_INVALID_EVENT_ID;
            goto EXIT;
        }
        busWidthIncrSignal = ((CUeventDataHwpm*)pEventInfoIncr->pEventData)->busWidth;
        if (busWidthIncrSignal > 6) {
            //can't use signal > 6bit in expt
            CU_ASSERT(0);
            status = CUPROF_ERROR_NOT_COMPATIBLE;
            goto EXIT;
        }

        if ((numSignals > 2) && (busWidthIncrSignal > 4)) {
            //for signals > 4, the combination cannot be > 2 signals
            CU_ASSERT(0);
            status = CUPROF_ERROR_NOT_COMPATIBLE;
            goto EXIT;
        }

        status = performUnitCompatibilityCheck(pParsedClk, pEventGroup->pCtx->device->state.pPerfUnitTable, tempSignalConfig,
                                      (CUeventDataHwpm*)pEventInfoIncr->pEventData, 0);
        if(status != CUPROF_SUCCESS)
            goto EXIT;
        //setup watchbus
        for (k = 0; k < 4; k++) {
            //Store watchbus for LSB 4 bits in tempWatchbus[0]
            if (k < busWidthIncrSignal)
                tempSignalConfig->tempWatchbus[1] |= (((((CUeventDataHwpm *)pEventInfoIncr->pEventData)->watchBus & 0xff) + k) << (k * 8));
            else
                tempSignalConfig->tempWatchbus[1] |= (FALSE_WATCH_BUS_SIGNAL << (k * 8));
        }
        if (busWidthIncrSignal > 4) {
            for (k = 4; k < 6; k++) {
                //Store watchbus for MSB 2 bits in the upper part of the tempWatchbus[1]
                if (k < busWidthIncrSignal)
                    tempSignalConfig->tempWatchbus[0] |= (((((CUeventDataHwpm *)pEventInfoIncr->pEventData)->watchBus & 0xff) + k) << ((k - 2) * 8));
                else
                    //Add false signal to the vacant space.
                    tempSignalConfig->tempWatchbus[0] |= (FALSE_WATCH_BUS_SIGNAL << ((k - 2) * 8));
            }
        }
    }
    //If we reach here, the groups are compatible, set expected mode for this signal.
    if (tempSignalConfig->mode == 0) {
        //mode is not explicitly set, try to apply generic rules, this might not give optimal combinations
        if (busWidthIncrSignal == 0) {
            tempSignalConfig->mode = NV_PMM_CONTROL_ADDTOCTR_INCR; //incrment by 1 on a logical combination of 4 signals in the table.
        }
        else if (busWidthIncrSignal <= 4) {
            tempSignalConfig->mode = NV_PMM_CONTROL_ADDTOCTR_EVENT4;
        } else if (busWidthIncrSignal <= 6) {
            tempSignalConfig->mode = NV_PMM_CONTROL_ADDTOCTR_EVENT6;
        }
    }

    tempSignalConfig->busWidth = busWidthIncrSignal;
    tempSignalConfig->function = pEventData->function;

EXIT:
    for(j = 0; j < numSignals; j++) {
        free(pEventInfoTemp[j]);
    }
    free(pEventInfoIncr);
    return status;
}

static CUprofResult getSigConfig(CUeventGroup *pEventGroup, CUdomainData *pDomainData, PerfSignalHwpm *pEventData, signalConfig *tempSignalConfig)
{
    CUeventInfo *pEventInfo = NULL;
    NvU32 k = 0, busWidthIncrSignal = 0, busWidth = 0;
    CUprofResult status = CUPROF_SUCCESS;
    CUparsedClk *pParsedClk =  pEventGroup->arch.keplerEventGroup->pParsedClk;

    pEventInfo = keplerLookupDomainSignalTable(pDomainData, pEventData->signalId);
    if (!pEventInfo) {
        //Increment event not found
        status = CUPROF_ERROR_INVALID_EVENT_ID;
                goto EXIT;
            }

    if (pEventData->busWidth > 14) {
        //can't use signal > 6bit in expt
        CU_ASSERT(0);
        status = CUPROF_ERROR_NOT_COMPATIBLE;
        goto EXIT;
    }

    status = performUnitCompatibilityCheck(pParsedClk, pEventGroup->pCtx->device->state.pPerfUnitTable, tempSignalConfig,
                                  pEventData, 1);
    if(status != CUPROF_SUCCESS)
        goto EXIT;

    //setup watchbus
    busWidth = 0;
    busWidthIncrSignal = pEventData->busWidth;
    if ((busWidthIncrSignal > 1) && (busWidthIncrSignal <= 14)) {
        //TBD write macros for below loops after debugging
        for (k = 0; k < 4; k++) {
            //Store watchbus for LSB 4 bits in tempWatchbus[1]
            if (busWidth < busWidthIncrSignal) {
                tempSignalConfig->tempWatchbus[0] |= (((pEventData->watchBus & 0xff) + k) << (k * 8));
                busWidth++;
            } else {
                //Add false signal in vacant space
                tempSignalConfig->tempWatchbus[0] |= ((FALSE_WATCH_BUS_SIGNAL) << (k * 8));
            }
        }
        for (k = 4; k < 8; k++) {
            //Store watchbus for MSB 3 bits in tempWatchbus[1]
            if (busWidth < busWidthIncrSignal) {
                tempSignalConfig->tempWatchbus[1] |= (((pEventData->watchBus & 0xff) + k) << ((k-4) * 8));
                busWidth++;
            } else {
                //Add false signal in vacant space
                tempSignalConfig->tempWatchbus[1] |= ((FALSE_WATCH_BUS_SIGNAL) << ((k-4) * 8));
            }
        }
        for (k = 8; k < 12; k++) {
            //Store watchbus for LSB 4 bits in tempWatchbus[2]
            if (busWidth < busWidthIncrSignal) {
                tempSignalConfig->tempWatchbus[2] |= (((pEventData->watchBus & 0xff) + k) << ((k-8) * 8));
                busWidth++;
            } else {
                tempSignalConfig->tempWatchbus[2] |= ((FALSE_WATCH_BUS_SIGNAL) << ((k-8) * 8));
            }
        }
        for (k = 12; k < 14; k++) {
            //Store watchbus for MSB 3 bits in tempWatchbus[3]
            if (busWidth < busWidthIncrSignal) {
                tempSignalConfig->tempWatchbus[3] |= (((pEventData->watchBus & 0xff) + k) << ((k-12) * 8));
                busWidth++;
            } else {
                tempSignalConfig->tempWatchbus[3] |= ((FALSE_WATCH_BUS_SIGNAL) << ((k-12) * 8));
            }
        }
    } else {
        busWidth = busWidthIncrSignal;
        busWidth = (busWidth <= 4) ? (busWidth) : 4;
        for (k = 0; k < busWidth; k++) {
            //Store watchbus for LSB 4 bits in tempWatchbus[0]
            tempSignalConfig->tempWatchbus[1] |= (((pEventData->watchBus & 0xff) + k) << (k * 8));
        }
        for (k = 4; k < 6; k++) {
            //Store watchbus for MSB 2 bits in the upper part of the tempWatchbus[1]
            if (k < busWidthIncrSignal)
                tempSignalConfig->tempWatchbus[0] |= (((pEventData->watchBus & 0xff) + k) << ((k - 2) * 8));
            else
                //Add false signal to the vacant space.
                tempSignalConfig->tempWatchbus[0] |= (FALSE_WATCH_BUS_SIGNAL << ((k - 2) * 8));
        }
    }

    tempSignalConfig->busWidth = busWidthIncrSignal;
    tempSignalConfig->function = pEventData->function;

    //If we reach here, the groups are compatible, set expected mode for this signal.
    if (tempSignalConfig->mode == 0) {
        //mode is not explicitly set, try to apply generic rules, this might not give optimal combinations
        if (busWidthIncrSignal == 1) {
            tempSignalConfig->mode = NV_PMM_CONTROL_ADDTOCTR_INCR;
            tempSignalConfig->tempWatchbus[0] = tempSignalConfig->tempWatchbus[1];
        }
        else if ((busWidthIncrSignal > 1) && (busWidthIncrSignal <= 14)) {
            tempSignalConfig->mode = NV_PMM_CONTROL_ADDTOCTR_VIVEK;
        } else {
            status = CUPROF_ERROR_NOT_COMPATIBLE;
            goto EXIT;
        }
    }

EXIT:
    free(pEventInfo);
    return status;

}

// We can monitor up to four inc-by-1 experiments per domain in ModeB
// Each chiplet/PMM can be configured individually, so we have. 1x8 domains for sys + 4x1 gpcs + 4x2 gpctpcs
// + 6x2 fbps experiments that can run concurrently on gk104
static CUprofResult canSigBeProfiledModeB(CUeventGroup *pEventGroup, CUdomainData *pDomainData, CUeventInfo *pEventInfo, NvBool *added)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 i = 0, j = 0, k = 0;
    CUparsedClk  *pParsedClk = NULL;
    NvU32 eventSpec = 0, newMode = 0;
    signalConfig tempSignalConfig;

    CU_TRACE_FUNCTION();

    memset(&tempSignalConfig, 0, sizeof(signalConfig));

    pParsedClk = pEventGroup->arch.keplerEventGroup->pParsedClk;
    if(!pParsedClk) {
        return CUPROF_ERROR_UNKNOWN;
    }

    if (pEventGroup->totalCounters == 0) {
        pParsedClk->eventSpecUsed = 0;
        pParsedClk->mode = (NvU32) -1;
        for (i = 0; i < CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS; i++) {
            pParsedClk->watchBus[i] = 0xefefefef; //Assuming this is false signal TBD check if assumption is still correct.
            pParsedClk->function[i] = 0;          //Assuming this is false signal TBD check if assumption is still correct.
        }
    }

    if (((CUeventDataHwpm*)pEventInfo->pEventData)->signalId == KEPLER_ELAPSED_CYCLES_SM) {
        if(pParsedClk->isElapsedClocksProfiled) {
            status = CUPROF_ERROR_NOT_COMPATIBLE;
            *added = NV_FALSE;
            return status;
        }
        pParsedClk->eventspec[pEventGroup->totalCounters] = NV_ELAPSED_CLOCKS;
        pParsedClk->isElapsedClocksProfiled = 1;
                    *added = NV_TRUE;
        return status;
    }

    if (pParsedClk->eventSpecUsed == (NV_PMM_TRIG1 | NV_PMM_EVENT | NV_PMM_TRIG0 | NV_PMM_SAMPLE))
        return CUPROF_ERROR_MAX_LIMIT_REACHED;

    if(pEventInfo->signalTableType == PERF_SIG_TABLE_TYPE_HWPM_EXPT) {
        status = getExptConfig(pEventGroup, pDomainData, (CUeventDataHwpmExpt *)(pEventInfo->pEventData), &tempSignalConfig);
        if (status != CUPROF_SUCCESS)
            goto Failed;
    } else {
        status = getSigConfig(pEventGroup, pDomainData, (PerfSignalHwpm *)(pEventInfo->pEventData), &tempSignalConfig);
        if (status != CUPROF_SUCCESS)
            goto Failed;
        }

    //Setup the event mask and in vivel mode, set the partnumbers
    //TBD correctly return the error code if non_compatible or max_limit_reached
    status = getEventSpec(pParsedClk, &tempSignalConfig, &eventSpec, &newMode);
    if (status != CUPROF_SUCCESS)
        goto Failed;

    //No error, so add this signal in the parsedClk now
    j = 0;
    while(tempSignalConfig.unitInfo[j]) {
        k = 0;
        while(pParsedClk && pParsedClk->pParsedUnit[k]) {
            //Check if have already added any signal from same unit and same group
            //if so, assign those values to temp values so that we can check if
            //we are using same group else return error.
            if (pParsedClk->pParsedUnit[k]->groupSelAddress == tempSignalConfig.unitInfo[j]->groupSelAddress) {
                break;
            }
            k++;
        }

        if(!pParsedClk->pParsedUnit[k]) {
            pParsedClk->pParsedUnit[k] = (CUparsedUnit*)malloc(sizeof(CUparsedUnit));
            if(!pParsedClk->pParsedUnit[k]) goto Failed;
            cuosMemset(pParsedClk->pParsedUnit[k], 0, sizeof(CUparsedUnit));
        }

        pParsedClk->pParsedUnit[k]->unitId = tempSignalConfig.unitInfo[j]->unitId;
        pParsedClk->pParsedUnit[k]->groupSelAddress = tempSignalConfig.unitInfo[j]->groupSelAddress;
        pParsedClk->pParsedUnit[k]->groupSelMask = tempSignalConfig.unitInfo[j]->groupSelMask;
        pParsedClk->pParsedUnit[k]->groupSelValue = tempSignalConfig.unitInfo[j]->groupSelValue;

        pParsedClk->pParsedUnit[k]->groupSelAddress1 = tempSignalConfig.unitInfo[j]->groupSelAddress1;
        pParsedClk->pParsedUnit[k]->groupSelMask1 = tempSignalConfig.unitInfo[j]->groupSelMask1;
        pParsedClk->pParsedUnit[k]->groupSelValue1 = tempSignalConfig.unitInfo[j]->groupSelValue1;
        pParsedClk->pParsedUnit[k]->pPerfUnitTable = tempSignalConfig.unitInfo[j]->pPerfUnitTable;
        free(tempSignalConfig.unitInfo[j]);
        j++;
    }

    pParsedClk->pParsedUnit[k]->instance = tempSignalConfig.instance;

    pParsedClk->mode = newMode;
    pParsedClk->eventspec[pEventGroup->totalCounters] = eventSpec;
    pParsedClk->eventSpecUsed |= eventSpec;
    pParsedClk->width[pEventGroup->totalCounters] = tempSignalConfig.busWidth;
    pParsedClk->partNumber[pEventGroup->totalCounters] = tempSignalConfig.partNumber;

    if(eventSpec & NV_PMM_TRIG0) {
        pParsedClk->watchBus[NV_PMM_TRIG0_BIT_POS] = tempSignalConfig.watchBus[NV_PMM_TRIG0_BIT_POS];
        pParsedClk->function[NV_PMM_TRIG0_BIT_POS] = tempSignalConfig.function; //In Vivek mode it should be 0xffff
    }
    if(eventSpec & NV_PMM_TRIG1) {
        pParsedClk->watchBus[NV_PMM_TRIG1_BIT_POS] = tempSignalConfig.watchBus[NV_PMM_TRIG1_BIT_POS];
        pParsedClk->function[NV_PMM_TRIG1_BIT_POS] = tempSignalConfig.function; //In Vivek mode it should be 0xffff
    }
    if(eventSpec & NV_PMM_SAMPLE) {
        pParsedClk->watchBus[NV_PMM_SAMPLE_BIT_POS] = tempSignalConfig.watchBus[NV_PMM_SAMPLE_BIT_POS];
        pParsedClk->function[NV_PMM_SAMPLE_BIT_POS] = tempSignalConfig.function; //In Vivek mode it should be 0xffff
        }
    if(eventSpec & NV_PMM_EVENT) {
        pParsedClk->watchBus[NV_PMM_EVENT_BIT_POS] = tempSignalConfig.watchBus[NV_PMM_EVENT_BIT_POS];
        pParsedClk->function[NV_PMM_EVENT_BIT_POS] = tempSignalConfig.function; //In Vivek mode it should be 0xffff
    }

    if ((tempSignalConfig.mode != NV_PMM_CONTROL_ADDTOCTR_INCR) && (tempSignalConfig.mode != NV_PMM_CONTROL_ADDTOCTR_VIVEK)) {
        if ((tempSignalConfig.mode == NV_PMM_CONTROL_ADDTOCTR_EVENT4 || tempSignalConfig.mode == NV_PMM_CONTROL_ADDTOCTR_EVENT6)) {
            pParsedClk->function[NV_PMM_EVENT_BIT_POS] = tempSignalConfig.function;
            pParsedClk->function[NV_PMM_TRIG1_BIT_POS] = 0xffff;
        } else if ((tempSignalConfig.mode == NV_PMM_CONTROL_ADDTOCTR_TRIG4 || tempSignalConfig.mode == NV_PMM_CONTROL_ADDTOCTR_TRIG6)) {
            pParsedClk->function[NV_PMM_EVENT_BIT_POS] = 0xffff;
            pParsedClk->function[NV_PMM_TRIG1_BIT_POS] = 0xffff;
        }
    }

    *added = NV_TRUE;

    return status;

Failed:
    j = 0;
    while(tempSignalConfig.unitInfo[j]) {
        free(tempSignalConfig.unitInfo[j]);
        ++j;
    }

    return status;
}

//TBD get rid of following function. Search if we can use any domain id
static NvU32 getClkIdx(const CUctx *ctx, CUeventDomainID domainId, NvU32 chipletType)
{
    NvU32 clkIdx;
    // GK104/GK106/GK107 domain Ids
    const NvU32 gk104_domainIds[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        // sys chiplet
        {KEPLER_CLK_DOMAIN_GK104_HOST0, KEPLER_CLK_DOMAIN_GK104_HUB0, KEPLER_CLK_DOMAIN_GK104_MSD0, KEPLER_CLK_DOMAIN_GK104_MSD1, KEPLER_CLK_DOMAIN_GK104_PCIE0, KEPLER_CLK_DOMAIN_GK104_PWR0, KEPLER_CLK_DOMAIN_GK104_SYS0, KEPLER_CLK_DOMAIN_GK104_XBAR0},

            // gpc chiplet
            //TBD : Returning same value for gpctpc0 and gpctpc1 domains.
            //The base values of pmmaddress are adjusted accordingly.
        {KEPLER_CLK_DOMAIN_GK104_GPC0, KEPLER_CLK_DOMAIN_GK104_GPCTPC},

        // fbp chiplet
        {KEPLER_CLK_DOMAIN_GK104_LTC0, KEPLER_CLK_DOMAIN_GK104_ROP0}
    };

    // GK110 domain Ids
    const NvU32 gk110_domainIds[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        // sys chiplet
        // HUB domain has been removed from GK110
        {KEPLER_CLK_DOMAIN_GK110_HOST0, KEPLER_CLK_DOMAIN_GK110_MSD0, KEPLER_CLK_DOMAIN_GK110_MSD1, KEPLER_CLK_DOMAIN_GK110_PCIE0, KEPLER_CLK_DOMAIN_GK110_PWR0, KEPLER_CLK_DOMAIN_GK110_SYS0, KEPLER_CLK_DOMAIN_GK110_XBAR0},

        // gpc chiplet
        //TBD : Returning same value for gpctpc0 and gpctpc1 and gpctpc2 domains.
        //The base values of pmmaddress are adjusted accordingly.
        {KEPLER_CLK_DOMAIN_GK110_GPC0, KEPLER_CLK_DOMAIN_GK110_GPCTPC},

        // fbp chiplet
        {KEPLER_CLK_DOMAIN_GK110_LTC0, KEPLER_CLK_DOMAIN_GK110_ROP0}
    };

    // GK208 domain Ids
    const NvU32 gk208_domainIds[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        // sys chiplet
        // HUB domain has been removed from GK110
        {KEPLER_CLK_DOMAIN_GK110_HOST0, KEPLER_CLK_DOMAIN_GK110_MSD0, KEPLER_CLK_DOMAIN_GK110_MSD1, KEPLER_CLK_DOMAIN_GK110_PCIE0, KEPLER_CLK_DOMAIN_GK110_PWR0, KEPLER_CLK_DOMAIN_GK208_SYS0, KEPLER_CLK_DOMAIN_GK208_XBAR0},

        // gpc chiplet
        //TBD : Returning same value for gpctpc0 and gpctpc1 and gpctpc2 domains.
        //The base values of pmmaddress are adjusted accordingly.
        {KEPLER_CLK_DOMAIN_GK208_GPC0, KEPLER_CLK_DOMAIN_GK208_GPCTPC},

        // fbp chiplet
        {KEPLER_CLK_DOMAIN_GK208_LTC0, KEPLER_CLK_DOMAIN_GK110_ROP0}
    };

#if NVCFG(GLOBAL_ARCH_KEPLER)
#if NVCFG(GLOBAL_GPU_IMPL_GK20A) || NVCFG(GLOBAL_CHIP_T124) || NVCFG(GLOBAL_CHIP_T132)
    const NvU32 gk20a_domainIds[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        // sys chiplet
        {KEPLER_CLK_DOMAIN_GK20A_ACB0, KEPLER_CLK_DOMAIN_GK20A_MC0, KEPLER_CLK_DOMAIN_GK20A_SYS0},

        // gpc chiplet
        {KEPLER_CLK_DOMAIN_GK208_GPC0, KEPLER_CLK_DOMAIN_GK20A_GPCTPC},

        // fbp chiplet
        {KEPLER_CLK_DOMAIN_GK20A_FBP0}
    };
#endif
#endif

    CU_TRACE_FUNCTION();

    if (chipletType >= PM_MAX_CHIPLET_TYPES) {
        CU_ERROR_PRINT(("Invalid chiplet values\n"));
        CU_ASSERT (0);
        return PM_MAX_DOMAIN_PER_CHIPLET;
    }

    switch(ctx->device->state.chip) {
#if NVCFG(GLOBAL_ARCH_KEPLER)
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK104):
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK106):
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK107):
        {
            for(clkIdx=0; clkIdx<(NvU32)PM_MAX_DOMAIN_PER_CHIPLET; clkIdx++)
            {
                if(gk104_domainIds[chipletType][clkIdx] == domainId)
                    return clkIdx;
            }
            CU_ASSERT(clkIdx != PM_MAX_DOMAIN_PER_CHIPLET);
        }
        break;

#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110):
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110B
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110B):
#endif
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110C
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110C):
#endif
        {
            for(clkIdx=0; clkIdx<(NvU32)PM_MAX_DOMAIN_PER_CHIPLET; clkIdx++)
            {
                if(gk110_domainIds[chipletType][clkIdx] == domainId)
                    return clkIdx;
            }
            CU_ASSERT(clkIdx != PM_MAX_DOMAIN_PER_CHIPLET);
        }
        break;
#endif

#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK200
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK208):
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK208S
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK208S):
#endif
        {
            for(clkIdx=0; clkIdx<(NvU32)PM_MAX_DOMAIN_PER_CHIPLET; clkIdx++)
            {
                if(gk208_domainIds[chipletType][clkIdx] == domainId)
                    return clkIdx;
            }
            CU_ASSERT(clkIdx != PM_MAX_DOMAIN_PER_CHIPLET);
        }
        break;
#endif
#if NVCFG(GLOBAL_GPU_IMPL_GK20A) || NVCFG(GLOBAL_CHIP_T124) || NVCFG(GLOBAL_CHIP_T132)
#if NVCFG(GLOBAL_GPU_IMPL_GK20A) || NVCFG(GLOBAL_CHIP_T124)
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK20A):
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_T12X + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_T124):
#endif // NVCFG(GLOBAL_GPU_IMPL_GK20A) || NVCFG(GLOBAL_CHIP_T124)
#if NVCFG(GLOBAL_CHIP_T132)
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_T13X + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_T132):
#endif // NVCFG(GLOBAL_CHIP_T132)
        {
            for(clkIdx=0; clkIdx<(NvU32)PM_MAX_DOMAIN_PER_CHIPLET; clkIdx++)
            {
                if(gk20a_domainIds[chipletType][clkIdx] == domainId)
                    return clkIdx;
            }
            CU_ASSERT(clkIdx != PM_MAX_DOMAIN_PER_CHIPLET);
        }
        break;
#endif // NVCFG(GLOBAL_GPU_IMPL_GK20A) || NVCFG(GLOBAL_CHIP_T124) || NVCFG(GLOBAL_CHIP_T132)
#endif
    default:
        CU_ASSERT(0);
        break;
    }
    CU_ASSERT(0);
    return PM_MAX_DOMAIN_PER_CHIPLET;
}

static CUprofResult tryAddingSmpcCounter(CUeventGroup *pEventGroup, CUdomainData *pDomainData, CUeventDataSmpc *pEventData)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 newGroupIdx = 0, smCoreProfiled = 0;
    CUSMCtrInfo *pSM = NULL;

    pSM = pEventGroup->arch.keplerEventGroup->pSM;
    smCoreProfiled = pEventGroup->pCtx->pmNew->isMembarWarEnabled ? CU_PROF_SM_CORE_PROFILED_MAX_GK110 : CU_PROF_SM_CORE_PROFILED_MAX_GK10x;
    if((pEventData->pmUnitId == PM_UNIT_SMCORE) && (pSM->coreCount == smCoreProfiled)) {
        return CUPROF_ERROR_NOT_COMPATIBLE;
    }
    else if((pEventData->pmUnitId == PM_UNIT_SMQCTL) && (pSM->qctlCount == CU_PROF_SM_QUAD_PROFILED_MAX)) {
        return CUPROF_ERROR_NOT_COMPATIBLE;
    }
    switch(pEventData->pmUnitId)
    {
    case PM_UNIT_SMCORE:
        {
            NvU32 coreIdx = 0;
            while(coreIdx < pSM->numGroupsCore)
            {
                if(pEventData->eventGroup == pSM->groupsCore[coreIdx])
                {
                    newGroupIdx = coreIdx;
                    pSM->coreCount++;
                    break;
                }
                coreIdx++;
            }
            if(coreIdx == pSM->numGroupsCore)
            {
                if(pSM->numGroupsCore == smCoreProfiled) {
                    return CUPROF_ERROR_NOT_COMPATIBLE;
                }
                newGroupIdx = pSM->numGroupsCore;
                pSM->groupsCore[pSM->numGroupsCore++] = pEventData->eventGroup;
                pSM->coreCount++;
            }
        }
        break;
    case PM_UNIT_SMQCTL:
        {
            NvU32 quadIdx = 0;
            while(quadIdx < pSM->numGroupsQuad)
            {
                if(pEventData->eventGroup == pSM->groupsQuad[quadIdx])
                {
                    newGroupIdx = quadIdx;
                    pSM->qctlCount++;
                    break;
                }
                quadIdx++;
            }
            if(quadIdx == pSM->numGroupsQuad)
            {
                if(pSM->numGroupsQuad == CU_PROF_SM_QUAD_PROFILED_MAX) {
                    return CUPROF_ERROR_NOT_COMPATIBLE;
                }
                newGroupIdx = pSM->numGroupsQuad;
                pSM->groupsQuad[pSM->numGroupsQuad++] = pEventData->eventGroup;
                pSM->qctlCount++;
            }
        }
        break;
    }

    pSM->function[pSM->SMCountersAdded] = pEventData->function;
    pSM->pmUnitId[pSM->SMCountersAdded] = pEventData->pmUnitId;
    pSM->mode[pSM->SMCountersAdded] = NV_SM_DSM_PERF_COUNTER_CONTROL_MODE_COUNT;
    if(pEventData->pmUnitId == PM_UNIT_SMCORE && pEventGroup->pCtx->pmNew->isMembarWarEnabled) {
        newGroupIdx++;
    }
    pSM->perfEventInfo[pSM->SMCountersAdded]  = (newGroupIdx & 3) | (pEventData->perfEvent & 0x00000007) << 2;
    pSM->perfEventInfo[pSM->SMCountersAdded] |= ((newGroupIdx & 3) | ((pEventData->perfEvent & 0x00000070)>>4) << 2) << 5;
    pSM->perfEventInfo[pSM->SMCountersAdded] |= ((newGroupIdx & 3) | ((pEventData->perfEvent & 0x00000700)>>8) << 2) << 10;
    pSM->perfEventInfo[pSM->SMCountersAdded] |= ((newGroupIdx & 3) | ((pEventData->perfEvent & 0x00007000)>>12) << 2) << 15;
    pSM->perfEventInfo[pSM->SMCountersAdded] |= ((newGroupIdx & 3) | ((pEventData->perfEvent & 0x00070000)>>16) << 2) << 20;
    pSM->perfEventInfo[pSM->SMCountersAdded] |= ((newGroupIdx & 3) | ((pEventData->perfEvent & 0x00700000)>>20) << 2) << 25;

    return status;
}

static CUprofResult tryAddingLutCounter(CUeventGroup *pEventGroup, CUdomainData *pDomainData, CUeventDataSmpcExpt *pEventData)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUeventDataSmpc *pEventdataTemp[4] = {NULL};
    CUeventInfo *pEventInfoTemp[4] = {NULL};
    CUSMCtrInfo *pSM = NULL;
    NvU32 j = 0, newEventGroups = 0, newGroupIds[4], newGroupIdx[4], numSignals = 0, smCoreProfiled = 0;

    pSM = pEventGroup->arch.keplerEventGroup->pSM;
    smCoreProfiled = pEventGroup->pCtx->pmNew->isMembarWarEnabled ? CU_PROF_SM_CORE_PROFILED_MAX_GK110 : CU_PROF_SM_CORE_PROFILED_MAX_GK10x;

    if((pEventData->pmUnitId == PM_UNIT_SMCORE) && (pSM->coreCount == smCoreProfiled)) {
        return CUPROF_ERROR_NOT_COMPATIBLE;
    }
    else if((pEventData->pmUnitId == PM_UNIT_SMQCTL) && (pSM->qctlCount == CU_PROF_SM_QUAD_PROFILED_MAX)) {
        return CUPROF_ERROR_NOT_COMPATIBLE;
    }
    while(pEventData->signalId_combination[numSignals] != INVALID_PM_SIGNAL_NEW && numSignals < 4)
    {
        pEventInfoTemp[numSignals] = keplerLookupDomainSignalTable(pDomainData, pEventData->signalId_combination[numSignals]);
        if(pEventInfoTemp[numSignals])
        {
            pEventdataTemp[numSignals] = (CUeventDataSmpc*)pEventInfoTemp[numSignals]->pEventData;
            CU_ASSERT(pEventdataTemp[numSignals]->pmUnitId == pEventData->pmUnitId);
            CU_ASSERT(pEventdataTemp[numSignals]->busWidth == 1);
            switch(pEventData->pmUnitId)
            {
            case PM_UNIT_SMCORE:
                {
                    NvU32 coreIdx = 0;
                    while(coreIdx < pSM->numGroupsCore)
                    {
                        if(pEventdataTemp[numSignals]->eventGroup == pSM->groupsCore[coreIdx])
                        {
                            newGroupIdx[numSignals] = coreIdx;
                            break;
                        }
                        coreIdx++;
                    }
                    if(coreIdx == pSM->numGroupsCore)
                    {
                        for(j = 0; j < newEventGroups; j++) {
                            if(pEventdataTemp[numSignals]->eventGroup == newGroupIds[j])
                            {
                                newGroupIdx[numSignals] = pSM->numGroupsCore + j;
                                break;
                            }
                        }
                        if(j == newEventGroups) {
                            newGroupIds[newEventGroups] = pEventdataTemp[numSignals]->eventGroup;
                            newGroupIdx[numSignals] = newEventGroups + pSM->numGroupsCore;
                            newEventGroups++;
                        }
                    }
                }
                break;
            case PM_UNIT_SMQCTL:
                {
                    NvU32 quadIdx = 0;
                    while(quadIdx < pSM->numGroupsQuad)
                    {
                        if(pEventdataTemp[numSignals]->eventGroup == pSM->groupsQuad[quadIdx])
                        {
                            newGroupIdx[numSignals] = quadIdx;
                            break;
                        }
                        quadIdx++;
                    }
                    if(quadIdx == pSM->numGroupsQuad)
                    {
                        for(j = 0; j < newEventGroups; j++) {
                            if(pEventdataTemp[numSignals]->eventGroup == newGroupIds[j])
                            {
                                newGroupIdx[numSignals] = pSM->numGroupsQuad + j;
                                break;
                            }
                        }
                        if(j == newEventGroups) {
                            newGroupIds[newEventGroups] = pEventdataTemp[numSignals]->eventGroup;
                            newGroupIdx[numSignals] = newEventGroups + pSM->numGroupsQuad;
                            newEventGroups++;
                        }
                    }
                }
                break;
            }
        }
        else
        {
            status = CUPROF_ERROR_INVALID_EVENT_ID;
            goto EXIT;
        }
        numSignals++;
    }
    if (pEventData->pmUnitId == PM_UNIT_SMCORE) {
        if((pSM->numGroupsCore + newEventGroups) > smCoreProfiled) {
            status = CUPROF_ERROR_NOT_COMPATIBLE;
            goto EXIT;
        }
        for(j = 0; j < newEventGroups; j++)
        {
            pSM->groupsCore[pSM->numGroupsCore++] = newGroupIds[j];
        }
        pSM->coreCount++;
    }
    else {
        if((pSM->numGroupsQuad + newEventGroups) > CU_PROF_SM_QUAD_PROFILED_MAX) {
            status = CUPROF_ERROR_NOT_COMPATIBLE;
            goto EXIT;
        }
        for(j = 0; j < newEventGroups; j++)
        {
            pSM->groupsQuad[pSM->numGroupsQuad++] = newGroupIds[j];
        }
        pSM->qctlCount++;
    }
    pSM->function[pSM->SMCountersAdded] = pEventData->function;
    pSM->pmUnitId[pSM->SMCountersAdded] = pEventData->pmUnitId;
    pSM->mode[pSM->SMCountersAdded] = NV_SM_DSM_PERF_COUNTER_CONTROL_MODE_LUT;
    j = 0;
    while(j < numSignals)
    {
        if(pEventData->pmUnitId == PM_UNIT_SMCORE && pEventGroup->pCtx->pmNew->isMembarWarEnabled) {
            newGroupIdx[j]++;
        }
        pSM->perfEventInfo[pSM->SMCountersAdded] |= ((newGroupIdx[j] & 3) | (pEventdataTemp[j]->perfEvent & 0x00000007) << 2) << (5 * j);
        j++;
    }

EXIT:
    for(j = 0; j < numSignals; j++) {
        free(pEventInfoTemp[j]);
    }
    return status;
}

static CUprofResult keplerPerfmonTryAddingCounterNew(CUeventGroup *pEventGroup, CUdomainData *pDomainData, CUeventInfo *pEventInfo, NvBool *added, NvU32 *maxSignals)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUSMCtrInfo  *pSM = NULL;

    CU_TRACE_FUNCTION();

    *added = NV_FALSE;

    switch(pDomainData->eventCollectionMethod)
    {
    case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
        //Try adding PM signal.
        //Assigning additional space for elapsed_clocks
        *maxSignals = CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS + CU_PROF_ELAPSED_CLOCK_SLOT;
        if (pEventInfo && pEventInfo->pEventData) {
            status = canSigBeProfiledModeB(pEventGroup, pDomainData, pEventInfo, added);
        }
        if((*added == NV_TRUE) && (!pEventGroup->totalCounters))
        {
            //Store the chiplet type
            pEventGroup->arch.keplerEventGroup->chipletType = pDomainData->chipletType;
            pEventGroup->arch.keplerEventGroup->clkIdx = getClkIdx(pEventGroup->pCtx, pDomainData->domainId, pDomainData->chipletType);
        }
        break;

    case CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
        //Try adding SM counter.
        {
            pSM = pEventGroup->arch.keplerEventGroup->pSM;
            if (pEventInfo->signalTableType == PERF_SIG_TABLE_TYPE_LUT)
            {
                status = tryAddingLutCounter(pEventGroup, pDomainData, (CUeventDataSmpcExpt*)pEventInfo->pEventData);
                if (status != CUPROF_SUCCESS) {
                    CU_ERROR_PRINT(("Failed to add new counter\n"));
                    return status;
                }
            }
            else if (pEventInfo->signalTableType == PERF_SIG_TABLE_TYPE_SMPC)
            {
                status = tryAddingSmpcCounter(pEventGroup, pDomainData, (CUeventDataSmpc*)pEventInfo->pEventData);
                if (status != CUPROF_SUCCESS) {
                    CU_ERROR_PRINT(("Failed to add new counter\n"));
                    return status;
                }
            }
            if(pEventGroup->pCtx->pmNew->isMembarWarEnabled) {
                *maxSignals = (CU_PROF_SM_CORE_PROFILED_MAX_GK110 + CU_PROF_SM_QUAD_PROFILED_MAX);
            }
            else {
                *maxSignals = (CU_PROF_SM_CORE_PROFILED_MAX_GK10x + CU_PROF_SM_QUAD_PROFILED_MAX);
            }
            if(pSM->SMCountersAdded < *maxSignals) {
                *added = NV_TRUE;
                pSM->sigtableInfo[pSM->SMCountersAdded] = pEventInfo;
                if(0 == pEventGroup->totalCounters) {
                    pEventGroup->arch.keplerEventGroup->chipletType = pDomainData->chipletType;
                }
            }
            else {
                return CUPROF_ERROR_MAX_LIMIT_REACHED;
            }
            pSM->SMCountersAdded++;
        }
        break;
    case CUPROF_EVENT_COLLECTION_METHOD_SW:
        *maxSignals = CU_PROF_SW_COUNTERS_MAX;
        *added = NV_TRUE;
        break;
    default:
        break;
    }
    return status;
}

/*****************************************************************
    Variables used in the function:
    - signalParts: Number of parts into which the signal is divided
    - signalWidth: Original width of the signal
    - splitWidth : Width of each splitted part of the signal
******************************************************************/
CUprofResult keplerPerfmonAddSplitSignalsSM(CUeventGroup *pEventGroup, CUdomainData *pDomainData, CUeventInfo *pEventInfo, NvBool *bAdded, NvU32 *maxSignals, NvU32 splitWidth)
{
    NvU32 signalParts = 0, startBit, endBit;
    NvU32 func, i, signalWidth, maxSignalsSM = 0;
    CUprofResult status = CUPROF_SUCCESS;
    CUSMCtrInfo  *pSM = NULL;
    CUeventDataSmpc *pEventData = NULL;

    pSM = pEventGroup->arch.keplerEventGroup->pSM;
    pEventData = (CUeventDataSmpc*)pEventInfo->pEventData;
    signalWidth = pEventData->busWidth;

    // Case handled for any signal of odd width
    signalParts = (signalWidth + (splitWidth - 1))/splitWidth;
    if(pEventGroup->pCtx->pmNew->isMembarWarEnabled) {
        maxSignalsSM = (CU_PROF_SM_CORE_PROFILED_MAX_GK110 + CU_PROF_SM_QUAD_PROFILED_MAX);
    }
    else {
        maxSignalsSM = (CU_PROF_SM_CORE_PROFILED_MAX_GK10x + CU_PROF_SM_QUAD_PROFILED_MAX);
    }
    if(pSM->SMCountersAdded < maxSignalsSM) {
        switch(pEventData->pmUnitId)
        {
        case PM_UNIT_SMCORE:
            if(pEventGroup->pCtx->pmNew->isMembarWarEnabled) {
                if (pSM->coreCount + signalParts > CU_PROF_SM_CORE_PROFILED_MAX_GK110) {
                    return CUPROF_ERROR_NOT_COMPATIBLE;
                }
            }
            else {
                if (pSM->coreCount + signalParts > CU_PROF_SM_CORE_PROFILED_MAX_GK10x) {
                    return CUPROF_ERROR_NOT_COMPATIBLE;
                }
            }
            break;
        case PM_UNIT_SMQCTL:
            if (pSM->qctlCount + signalParts > CU_PROF_SM_QUAD_PROFILED_MAX) {
                return CUPROF_ERROR_NOT_COMPATIBLE;
            }
            break;
        }
        func = pEventData->function;
        for(i = 0; i < signalParts; i++) {
            CUeventInfo *pEventInfoTemp = NULL;
            CUeventDataSmpc *pEventDataTemp = NULL;
            pEventInfoTemp = (CUeventInfo *) malloc (sizeof(CUeventInfo));
            if(pEventInfoTemp == NULL) {
                return CUPROF_ERROR_OUT_OF_MEMORY;
            }
            pEventDataTemp = (CUeventDataSmpc *) malloc (sizeof(CUeventDataSmpc));
            if(pEventDataTemp == NULL) {
                free(pEventInfoTemp);
                return CUPROF_ERROR_OUT_OF_MEMORY;
            }
            memcpy(pEventDataTemp, pEventData, sizeof(CUeventDataSmpc));
            pEventInfoTemp->signalTableType = pEventInfo->signalTableType;
            pEventInfoTemp->pEventData = (void*)pEventDataTemp;
            ((CUeventDataSmpc*)pEventInfoTemp->pEventData)->perfEvent = 0;
            startBit = i * 4 * splitWidth;
            splitWidth = (signalWidth<splitWidth)?signalWidth:splitWidth;
            endBit = startBit + (splitWidth * 4) -1 ;
            ((CUeventDataSmpc*)pEventInfoTemp->pEventData)->perfEvent = GETFIELD32(pEventData->perfEvent, endBit:startBit);
            ((CUeventDataSmpc*)pEventInfoTemp->pEventData)->function = GETFIELD32(func,(splitWidth - 1):0);
            status = keplerPerfmonTryAddingCounterNew(pEventGroup,
                    pDomainData,
                    pEventInfoTemp,
                    bAdded,
                    maxSignals);
            if ((status != CUPROF_SUCCESS) || (*bAdded == NV_FALSE)) {
                CU_ERROR_PRINT(("Failed to add new counter\n"));
                return status;
            }
            CU_ASSERT(*bAdded);
            func = func >> splitWidth;
            signalWidth -= splitWidth;
        }
        pSM->splitParts[pEventGroup->totalCounters] = signalParts;
    }
    else {
        status = CUPROF_ERROR_MAX_LIMIT_REACHED;
        *bAdded = NV_FALSE;
        CU_ERROR_PRINT(("Failed to add new counter\n"));
    }
    return status;
}

// keplerCreateSignalTableEntry creates a new signal table entry
// and associates a nop trigger with each s/w counter requested
// In the new table entry the function copies the requested signal ID and name
// and copies the remaining CUeventData structure entries from the associated nop trigger signal table
static CUprofResult keplerCreateSignalTableEntry(CUeventGroup *pEventGroup, CUeventInfo **pEventInfoData, NvU32 eventID)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 i, nopTrigEventID;
    CUdev *pDev = NULL;
    NvU32 numDomains = 0;
    CUdomainData *nopTrigDomainData = NULL;
    CUeventDataSmpc *nopTrigEventData = NULL;
    CUeventInfo *nopTrigEventInfoData = NULL;
    CUeventDataSmpc *tempEventData = NULL;

    if(pEventGroup->nopTrigSwCounterData == NULL) {
        return CUPROF_ERROR_UNKNOWN;
    }

    tempEventData = (CUeventDataSmpc *)calloc(1, sizeof(CUeventDataSmpc));
    if(!tempEventData) {
        CU_ERROR_PRINT(("Failed to allocate memory for CUeventDataSmpc\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        return status;
    }

    if(pEventGroup->nopTrigSwCounterData->numSwCountersRequested == KEPLER_MAX_SW_COUNTER_PER_EVENTGROUP) {
        CU_DEBUG_PRINT(("Eventgroup limit reached\n"));
        // Only 4 nop_triggers can be issued on Kepler. Return from here
        free(tempEventData);
        return CUPROF_ERROR_NOT_COMPATIBLE;
    }

    for(i = 0; ; i++){
        if((eventID == pEventGroup->nopTrigSwCounterData->signalID[i]) || (i == pEventGroup->nopTrigSwCounterData->numSwCountersRequested)) {
            break;
        }
    }

    // If the signal is not requested earlier then associate an internal NOP.TRIG with it.
    if(i == pEventGroup->nopTrigSwCounterData->numSwCountersRequested) {
        nopTrigEventID = KEPLER_SM_NOP_TRIG_08 + pEventGroup->nopTrigSwCounterData->numSwCountersRequested;
        pEventGroup->nopTrigSwCounterData->signalID[pEventGroup->nopTrigSwCounterData->numSwCountersRequested] = eventID;
        (pEventGroup->nopTrigSwCounterData->numSwCountersRequested)++;
    }
    else {
        // Else consider the previous associated NOP.TRIG
        nopTrigEventID = KEPLER_SM_NOP_TRIG_08 + i;
    }

    pDev = pEventGroup->pCtx->device;
    numDomains = pDev->state.pDomainInfo->numDomains;

    for (i = 0; (i < numDomains && nopTrigEventInfoData == NULL); i++) {
        nopTrigDomainData = &pDev->state.pDomainInfo->pDomainTable[i];
        nopTrigEventInfoData = keplerLookupDomainSignalTable(nopTrigDomainData, nopTrigEventID);
        if(nopTrigEventInfoData) {
            nopTrigEventData = (CUeventDataSmpc*)nopTrigEventInfoData->pEventData;
            if(nopTrigEventData == NULL) {
                free(tempEventData);
                free(nopTrigEventInfoData);
                return CUPROF_ERROR_UNKNOWN;
            }
        }
    }

    if(nopTrigEventInfoData == NULL) {
        // This means that there is an error in higher level due to which keplerLookupDomainSignalTable did not find any valid signalID
        free(tempEventData);
        return CUPROF_ERROR_UNKNOWN;
    }

    tempEventData->signalId = ((CUeventData*)((*pEventInfoData)->pEventData))->signalId;
    tempEventData->pSignalName = ((CUeventData*)((*pEventInfoData)->pEventData))->pSignalName;
    tempEventData->eventGroup = nopTrigEventData->eventGroup;
    tempEventData->perfEvent = nopTrigEventData->perfEvent;
    tempEventData->function = nopTrigEventData->function;
    tempEventData->pmUnitId = nopTrigEventData->pmUnitId;
    tempEventData->busWidth = nopTrigEventData->busWidth;

    (*pEventInfoData)->pEventData = (void*)tempEventData;
    (*pEventInfoData)->signalTableType = nopTrigEventInfoData->signalTableType;
    //Store SMPC domainid
    pEventGroup->nopTrigSwCounterData->nopTrigDomainId = nopTrigDomainData->domainId;

    free(nopTrigEventInfoData);

    return status;
}

CUprofResult keplerPerfmonEventGroupAddEvent(CUeventGroup *pEventGroup,
                                             NvU32 eventID)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUdomainData *pDomainData = NULL;
    void *pEventData = NULL;
    CUeventInfo *tempEventInfo = NULL;
    CUdev *pDev = NULL;
    NvBool bAdded = NV_FALSE;
    NvU32 numDomains = 0;
    NvU32 i = 0, maxSignals = 0, splitWidth = 0;
    CUSMCtrInfo  *pSM = NULL;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);
    if (pEventGroup->isEnabled) {
        // don't allow addition of events for enabled event group
        return CUPROF_ERROR_INVALID_OPERATION;
    }

    pDev = pEventGroup->pCtx->device;

    if(!pDev->state.pDomainInfo)
        return CUPROF_ERROR_UNKNOWN;

    numDomains = pDev->state.pDomainInfo->numDomains;

    if (pEventGroup->totalCounters == 0) {
        // first signal, search in all domains
        for (i = 0; i < numDomains; i++) {
            pDomainData = &pDev->state.pDomainInfo->pDomainTable[i];
            tempEventInfo = keplerLookupDomainSignalTable(pDomainData, eventID);
            if (tempEventInfo) {
                pEventData = tempEventInfo->pEventData;
                if (!pEventData) {
                    free(tempEventInfo);
                    return CUPROF_ERROR_UNKNOWN;
                }
                break;
            }
        }
        // If lookup succeeds then initialize event group
        if (tempEventInfo != NULL && pDomainData->domainId != KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST) {
            status = keplerInitEventGroup(pEventGroup);
            if(CUPROF_SUCCESS != status) {
                CU_DEBUG_PRINT(("keplerInitEventGroup Failed\n"));
                free(tempEventInfo);
                return status;
            }
        }
        else if (tempEventInfo == NULL) {
            return CUPROF_ERROR_INVALID_EVENT_ID;
        }
    }
    else {
        tempEventInfo = keplerLookupDomainSignalTable(pEventGroup->domain, eventID);
        if (tempEventInfo) {
            pEventData = tempEventInfo->pEventData;
            if (!pEventData) {
                free(tempEventInfo);
                return CUPROF_ERROR_UNKNOWN;
            }
            pDomainData = pEventGroup->domain;
        }
        else {
            for (i = 0; i < numDomains; i++) {
                pDomainData = &pDev->state.pDomainInfo->pDomainTable[i];
                tempEventInfo = keplerLookupDomainSignalTable(pDomainData, eventID);
                if (tempEventInfo) {
                    free(tempEventInfo);
                    return CUPROF_ERROR_NOT_COMPATIBLE;
                }
            }

            return CUPROF_ERROR_INVALID_EVENT_ID;
        }
    }

    if((pDomainData->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW) ||
        (pDomainData->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW)) {
        if(pEventGroup->nopTrigSwCounterData == NULL){
            pEventGroup->nopTrigSwCounterData = (CUnopTrigSwCounter *)calloc(1, sizeof(CUnopTrigSwCounter));
            if (pEventGroup->nopTrigSwCounterData == NULL) {
                CU_DEBUG_PRINT(("Failed to allocate memory to event group\n"));
                free(tempEventInfo);
                return CUPROF_ERROR_OUT_OF_MEMORY;
            }
        }
        if(pEventGroup->totalCounters == 0) {
            memset(pEventGroup->nopTrigSwCounterData, 0, sizeof(CUnopTrigSwCounter));
        }
        status = keplerCreateSignalTableEntry(pEventGroup, &tempEventInfo, eventID);
        if (status != CUPROF_SUCCESS) {
            if(status != CUPROF_ERROR_NOT_COMPATIBLE) {
                CU_ERROR_PRINT(("Failed to create signal table entry\n"));
            }
            free(tempEventInfo);
            return status;
        }
        pEventData = tempEventInfo->pEventData;
        if (pEventData == NULL) {
            free(pEventData);
            free(tempEventInfo);
            return CUPROF_ERROR_INVALID_EVENT_ID;
        }
    }

    // return if event is not found or it's a internal only event
    if (pEventData == NULL) {
        free(tempEventInfo);
        return CUPROF_ERROR_INVALID_EVENT_ID;
    }
    else if ((SIG_TYPE_IS_INTERNAL_EXPOSED(((CUeventDataBasic*)pEventData)->signalId)
             && (pDomainData->exposedEvents == pDomainData->maxExternalEvents)) || SIG_TYPE_IS_INTERNAL(((CUeventDataBasic*)pEventData)->signalId)) {
        free(tempEventInfo);
        return CUPROF_ERROR_INVALID_EVENT_ID;
    }
    switch(pDomainData->eventCollectionMethod) {
        case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
        case CUPROF_EVENT_COLLECTION_METHOD_SW:
            status = keplerPerfmonTryAddingCounterNew(pEventGroup,
                pDomainData,
                tempEventInfo,
                &bAdded,
                &maxSignals);
            break;
        case CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW:
        case CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW:
        case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
            pSM = pEventGroup->arch.keplerEventGroup->pSM;
            if(getSplittingInfo(((CUeventDataSmpc*)pEventData)->signalId, &splitWidth, pEventGroup->pCtx->pmNew->isMembarWarEnabled)) {
                status = keplerPerfmonAddSplitSignalsSM(pEventGroup, pDomainData, tempEventInfo, &bAdded, &maxSignals, splitWidth);
            }
            else {
                status = keplerPerfmonTryAddingCounterNew(pEventGroup,
                    pDomainData,
                    tempEventInfo,
                    &bAdded,
                    &maxSignals);
                if(status == CUPROF_SUCCESS) {
                    pSM->splitParts[pEventGroup->totalCounters] = 1;
                }
            }
            break;
        default:
            CU_DEBUG_PRINT(("Invalid domain attribute\n"));
            free(tempEventInfo);
            return CUPROF_ERROR_INVALID_EVENT_DOMAIN_ID;
    }
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("Failed to add new counter\n"));
        free(tempEventInfo);
        return status;
    }
    CU_ASSERT(bAdded);

    if (pEventGroup->totalCounters == 0) {
        pEventGroup->domainId = pDomainData->domainId;
        pEventGroup->domain   = pDomainData;

        keplerPerfmonGetInstanceValues(pDev, pEventGroup->domain,
            &pEventGroup->instanceCountAvail, &pEventGroup->instanceCountTotal);

        if(pEventGroup->values != NULL)
        {
            free(pEventGroup->values);
            pEventGroup->values = NULL;
        }

        if(pEventGroup->values == NULL) {
            pEventGroup->values = (NvU64*)malloc(sizeof(NvU64) * maxSignals * pEventGroup->instanceCountAvail);
            if (pEventGroup->values == NULL) {
                CU_DEBUG_PRINT(("Failed to allocate memory to event group values\n"));
                free(tempEventInfo);
                return CUPROF_ERROR_OUT_OF_MEMORY;
            }
        }
        cuosMemset(pEventGroup->values, 0, sizeof(NvU64) * maxSignals * pEventGroup->instanceCountAvail);
    }

    if (pEventGroup->pEventInfoList == NULL) {
        // event list hasn't been init yet, do it now
        status = (CUprofResult)listInit(&pEventGroup->pEventInfoList, NULL, NULL, NULL, eventIdCompareData);
        if (status != CUPROF_SUCCESS) {
            free(tempEventInfo);
            CU_ERROR_PRINT(("Failed to init linked list\n"));
            return status;
        }
    }
    // add event to the list
    listAddToTail(pEventGroup->pEventInfoList, tempEventInfo);
    pEventGroup->totalCounters++;

    return status;
}

CUprofResult keplerPerfmonEventGroupRemoveEvent(CUeventGroup *pEventGroup, NvU32 eventID) {
    CUprofResult status = CUPROF_SUCCESS;
    CUeventInfo *currEvent = NULL;
    void *eventBase = NULL;
    NvBool bAdded = NV_FALSE;
    void *data = NULL;
    NvU32 i = 0, remainingCounters = 0, maxsignals = 0, splitWidth;
    CUdomainData *pDomainData = NULL;
    CUSMCtrInfo  *pSM = NULL;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if (pEventGroup->totalCounters == 0) {
        return CUPROF_SUCCESS;
    }

    if (pEventGroup->isEnabled) {
        // don't allow removal of events for enabled event group
        return CUPROF_ERROR_INVALID_OPERATION;
    }

    // remove from list
    data = listDataRemFrom(pEventGroup->pEventInfoList, &eventID);
    if (data != NULL) {
        //Do memory cleanup as eventInfoData is a pointer to structure storing the event data and signal type info
        free(data);
        remainingCounters = pEventGroup->totalCounters - 1;

        //Destroy the earlier parsed info and recreate the structure.
        status = keplerDestroyEventGroup(pEventGroup);
        pEventGroup->totalCounters = 0;

        if(remainingCounters)
        {
            if (pEventGroup->domainId != KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST) {
                status = keplerInitEventGroup(pEventGroup);
                if(status != CUPROF_SUCCESS)
                    return status;
            }
            pDomainData = pEventGroup->domain;
            //Add remaining counters back to build the parsed info
            currEvent = (CUeventInfo*)listGetNext(pEventGroup->pEventInfoList, &eventBase);
            for (i = 0; (i < remainingCounters) && currEvent; i++, currEvent = (CUeventInfo*)listGetNext(NULL, &eventBase)) {
                switch(pDomainData->eventCollectionMethod) {
                    case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
                    case CUPROF_EVENT_COLLECTION_METHOD_SW:
                        status = keplerPerfmonTryAddingCounterNew(pEventGroup,
                            pEventGroup->domain,
                            currEvent,
                            &bAdded, &maxsignals);
                        break;
                    case CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW:
                    case CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW:
                    case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
                        pSM = pEventGroup->arch.keplerEventGroup->pSM;
                        if(getSplittingInfo(((CUeventDataBasic *)currEvent->pEventData)->signalId, &splitWidth, pEventGroup->pCtx->pmNew->isMembarWarEnabled)) {
                            status = keplerPerfmonAddSplitSignalsSM(pEventGroup, pDomainData, currEvent, &bAdded, &maxsignals, splitWidth);
                        }
                        else {
                            status = keplerPerfmonTryAddingCounterNew(pEventGroup,
                                pDomainData,
                                currEvent,
                                &bAdded,
                                &maxsignals);
                            if(status == CUPROF_SUCCESS) {
                                pSM->splitParts[pEventGroup->totalCounters] = 1;
                            }
                        }
                        break;
                    default:
                        CU_DEBUG_PRINT(("Invalid domain attribute\n"));
                        return CUPROF_ERROR_INVALID_EVENT_DOMAIN_ID;
                }
                if ((status != CUPROF_SUCCESS) || (bAdded == NV_FALSE)) {
                    CU_ERROR_PRINT(("Failed to add new counter\n"));
                    return status;
                }
                CU_ASSERT(bAdded);
                pEventGroup->totalCounters++;
            }
        }
        else {
            //Destroy the event list if the removed event was the last one.
            //TBD check if Tesla needs this.
            status = (CUprofResult)listDestroy(pEventGroup->pEventInfoList);
            if (status != CUPROF_SUCCESS) {
                return status;
            }
            pEventGroup->pEventInfoList = NULL;
        }
    }
    else {
        return CUPROF_ERROR_INVALID_EVENT_ID;
    }

    return status;
}

CUprofResult keplerPerfmonEventGroupRemoveAllEvents(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 i = 0;
    void *data = NULL;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if (pEventGroup->totalCounters == 0) {
        //No event is added
        return CUPROF_SUCCESS;
    }

    if (pEventGroup->isEnabled) {
        // don't allow removal of events for enabled event group
        return CUPROF_ERROR_INVALID_OPERATION;
    }

    for (i = 0; i < pEventGroup->totalCounters; i++) {
        status = (CUprofResult)listGenericRemNodeFromHead(pEventGroup->pEventInfoList, &data);
        if (status == CUPROF_SUCCESS) {
            free(data);
        }
        else {
            return CUPROF_ERROR_UNKNOWN;
        }
    }
    CU_ASSERT(listLen(pEventGroup->pEventInfoList) == 0);
    // destroy the event list
    status = (CUprofResult)listDestroy(pEventGroup->pEventInfoList);
    if (status != CUPROF_SUCCESS) {
        return status;
    }
    pEventGroup->pEventInfoList = NULL;

    status = keplerDestroyEventGroup(pEventGroup);

    pEventGroup->totalCounters = 0;
    return status;
}

// function to enable PM module for units
static CUprofResult setPMEnableReg(const CUeventGroup *pEventGroup, NvBool bEnable)
{
    //Function to be changed for new version
    CUresult status = CUDA_SUCCESS;
    NvU32 offset[8], value[8];
    NvU32 count = 0, i = 0, j = 0;
    NvU32 tempChipIdx = 0, totalTpcCount = 0;
    NvU32 chipIdx = 0, numL2Slices = 0;
    PMEnableRegInfo *pPMEnableRegInfo = NULL;
    PMEnableRegInfo *pPMEnableRegInfo1 = NULL;
    CUkeplerEventGroup *keplerEventGroup;
    CUparsedClk *pParsedClk = NULL;
    NvU32 smValue = 0, smMask = 0;
    PerfUnitTable   *pTempPerfUnitTable = NULL;

    CU_TRACE_FUNCTION();

    pParsedClk = pEventGroup->arch.keplerEventGroup->pParsedClk;

    CU_ASSERT(pParsedClk);

    keplerEventGroup = pEventGroup->arch.keplerEventGroup;
    // Use PRI registers to get the number of LTS per LTC:
    if(bEnable && keplerEventGroup->chipletType == PM_CHIPLET_TYPE_FBP) {
        offset[0] = NV_PLTCG_LTC0_LTS0_CBC_PARAM;
        status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, 1, offset, value, 0);
        if (status != CUDA_SUCCESS) {
            return CUPROF_ERROR_HARDWARE;
        }
        numL2Slices = GETFIELD32(value[0],NV_PLTCG_LTC0_LTS0_CBC_PARAM_SLICES_PER_FBP);
    }

    for (chipIdx = 0; chipIdx < keplerEventGroup->maxChiplets; chipIdx++) {
        if(keplerEventGroup->pmUnitMask & (1<<chipIdx)) {
            pParsedClk = keplerEventGroup->pParsedClk;
            i = 0;
            while(pParsedClk && pParsedClk->pParsedUnit[i]) {
                pTempPerfUnitTable = pParsedClk->pParsedUnit[i]->pPerfUnitTable;
                pPMEnableRegInfo = &pTempPerfUnitTable->pmEnableRegInfo;

                count = 0;
                switch (keplerEventGroup->chipletType) {
                    // Bug 646910 : only one instance can be selected at a time
                    // The selected instance gets the "value" field value assigned while all others instances are zeroed out
                    // TODO: this change is not complete though, refer pm_programming_guide.txt file to derive
                    // the instance type (like INVALID, NONE, TPC, WXBAR_CQ_DAISY, MXBAR_CQ_DAISY etc) and no. of instances

                    case PM_CHIPLET_TYPE_GPC:
                        // count total tpcs within the gpc
                        //TBD remove hack (assumed chipidx pointing to a tpc here. This will not be required if we had 1 perfmon/tpc)
                        //TBD Check how many texture units we have in kepler and if we need to change this code.
                        if((pEventGroup->domain->domainId == KEPLER_CLK_DOMAIN_GK110_GPC0) ||
                            (pEventGroup->domain->domainId == KEPLER_CLK_DOMAIN_GK104_GPC0)) {
                           if (pParsedClk->pParsedUnit[i]->unitId == PM_UNIT_MPC) {
                                //gpc domain
                                totalTpcCount = 0;
                                count = 0;
                                for(tempChipIdx = 0; tempChipIdx < pEventGroup->arch.keplerEventGroup->gpcCount; tempChipIdx++) {

                                    count = pEventGroup->arch.keplerEventGroup->tpcPerGpcCount[tempChipIdx];
                                    if (!((chipIdx >= totalTpcCount) && (chipIdx < (totalTpcCount + count)))) {
                                        totalTpcCount+=count;
                                        continue;
                                    }

                                    for (j = 0; j < count; j++) {
                                        offset[j] = NV_PRI_TPC_ADDR(tempChipIdx, j) + pPMEnableRegInfo->regOffset;
                                    }
                                    // read _PM registers
                                    status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
                                    if (status != CUDA_SUCCESS) {
                                        return CUPROF_ERROR_HARDWARE;
                                    }
                                    // set PM_ENABLE bit by ORing the read value for selected instance
                                    // disable PM_ENABLE bit by ANDing the read value for all others instances
                                    for (j = 0; j < count; j++) {
                                        if((j == pParsedClk->pParsedUnit[i]->instance) && bEnable){
                                            value[j] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                                        }
                                        else {
                                            value[j] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
                                        }
                                    }
                                    break;
                                }
                           } else {
                                // for all units that are 1/GPC
                                totalTpcCount = 0;
                                count = 0;
                                //Identify the gpc
                                for(tempChipIdx = 0; tempChipIdx < pEventGroup->arch.keplerEventGroup->gpcCount; tempChipIdx++) {

                                    count = pEventGroup->arch.keplerEventGroup->tpcPerGpcCount[tempChipIdx];
                                    if (!((chipIdx >= totalTpcCount) && (chipIdx < (totalTpcCount + count)))) {
                                        totalTpcCount+=count;
                                        continue;
                                    } else {
                                        break;
                                    }
                                }

                                count = 0;
                                offset[count++] = pTempPerfUnitTable->priBaseAddress
                                        + pTempPerfUnitTable->priChipletOffset * tempChipIdx
                                        + pPMEnableRegInfo->regOffset;

                                status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
                                if (status != CUDA_SUCCESS) {
                                    return CUPROF_ERROR_HARDWARE;
                                }
                                count = 0;
                                if(bEnable)
                                {
                                    value[count++] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                                }
                                else
                                {
                                    value[count++] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
                                }
                           }
                        } else {
                            if((pParsedClk->pParsedUnit[i]->unitId == PM_UNIT_TEX_M) ||
                               (pParsedClk->pParsedUnit[i]->unitId == PM_UNIT_TEX_S) ||
                               (pParsedClk->pParsedUnit[i]->unitId == PM_UNIT_TEX_D)) {
                                    pPMEnableRegInfo1 = &pTempPerfUnitTable->pmEnableRegInfo1;

                                    count = 0;
                                    offset[count++] = keplerEventGroup->priAddress[chipIdx] + pPMEnableRegInfo->regOffset;
                                    offset[count++] = keplerEventGroup->priAddress[chipIdx] + pPMEnableRegInfo1->regOffset;
                                    offset[count++] = keplerEventGroup->priAddress[chipIdx] + NV_PTPC_PRI_TEX_T_PM;

                                    // read _PM registers
                                    status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
                                    if (status != CUDA_SUCCESS) {
                                        return CUPROF_ERROR_HARDWARE;
                                    }
                                    // set PM_ENABLE bit by ORing the read value for selected instance
                                    // disable PM_ENABLE bit by ANDing the read value for all others instances
                                    count = 0;
                                    if(bEnable)
                                    {
                                        value[count++] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                                        value[count++] |= (pPMEnableRegInfo1->value << pPMEnableRegInfo1->firstBit);
                                        value[count]  = DRF_REPLACE(value[count], NV_PTPC_PRI_TEX_T_PM_PM_ENABLE_ON, NV_PTPC_PRI_TEX_T_PM_PM_ENABLE);
                                        count++;
                                    }
                                    else
                                    {
                                        value[count++] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
                                        value[count++] &= ~(DRF_MASK(pPMEnableRegInfo1->lastBit : pPMEnableRegInfo1->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo1->lastBit : pPMEnableRegInfo1->firstBit)));
                                        value[count++] &= ~(DRF_MASK(NV_PTPC_PRI_TEX_T_PM_PM_ENABLE)<<(DRF_SHIFT(NV_PTPC_PRI_TEX_T_PM_PM_ENABLE)));
                                    }

                            }
                            else {
                                count = 1;
                                offset[0] = keplerEventGroup->priAddress[chipIdx] + pPMEnableRegInfo->regOffset;
                                // read _PM registers
                                status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
                                if (status != CUDA_SUCCESS) {
                                    return CUPROF_ERROR_HARDWARE;
                                }

                                if (0
    #if NVCFG(GLOBAL_ARCH_KEPLER)
                                || ((pEventGroup->pCtx->device->state.chip == NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK104)
                                ||  (pEventGroup->pCtx->device->state.chip == NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK106)
                                ||  (pEventGroup->pCtx->device->state.chip == NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK107))
    #endif
                                )
                                {
                                    //The following can be dynamically modified. hacking the code to test all modes.
                                    switch(pTempPerfUnitTable->pmUnitId)
                                    {
                                    case PM_UNIT_SMCORE :
                                        //Enable core on upper watchbus
                                        //smValue = 0x0508080;
                                        smValue = 0x0408080;
                                        smMask  = 0x07f8080;
                                        value[0] |= (smValue & smMask);
                                        break;
                                    case PM_UNIT_SMQCTL :
                                        //enable qctl0 on upper watchbus
                                        smValue = 0x0508080;
                                        smMask  = 0x07f0080;
                                        value[0] |= (smValue & smMask);
                                        //Enable only 1 QCTL on upper watchbus
                                        break;
                                    case PM_UNIT_SMKQUAD :
                                        //enable all 4 qctl on watchbus
                                        smValue = 0x0768080;
                                        smMask  = 0x07f0080;
                                        value[0] |= (smValue & smMask);
                                        //Enable only 4 low QCTLs on lower+upper watchbus
                                        break;
                                    case PM_UNIT_SMKHIGH :
                                    case PM_UNIT_SMKLOW :
                                        //Enable only 4 high QCTLs on lower+upper watchbus
                                        break;
                                    case PM_UNIT_L1C:
                                        count = 2;
                                        //TBD: remove the hardcoded value used
                                        offset[1] = pEventGroup->arch.keplerEventGroup->priAddress[chipIdx] + 0x00000600;
                                        status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, 1, &offset[1], &value[1], 0);
                                        if (status != CUDA_SUCCESS) {
                                            return CUPROF_ERROR_HARDWARE;
                                        }
                                        // set SMK_ENABLE and SMK_LOWER/UPPER
                                        value[1] = DRF_REPLACE(value[1], NV_SM_PM_CTRL_SMK_ENABLE_ENABLE,    NV_SM_PM_CTRL_SMK_ENABLE);
                                        value[1] = DRF_REPLACE(value[1], NV_SM_PM_CTRL_SMK_SEL_LOWER_SM_LSU, NV_SM_PM_CTRL_SMK_SEL_LOWER);
                                        value[1] = DRF_REPLACE(value[1], NV_SM_PM_CTRL_SMK_SEL_UPPER_SM_LSU, NV_SM_PM_CTRL_SMK_SEL_UPPER);

                                        smValue = value[1];
                                        smMask  = NV_SM_PM_CTRL_VALID_BITS_MASK;

                                        if(bEnable)
                                        {
                                            value[1] |= (smValue & smMask);
                                        }
                                        else
                                        {
                                            value[1] &= ~(smMask);
                                        }

                                        break;
                                    default:
                                        CU_ERROR_PRINT(("Not a valid chiplet type.\n"));
                                    }
                                }

                                // set PM_ENABLE bit by ORing the read value for selected instance
                                // disable PM_ENABLE bit by ANDing the read value for all others instances
                                if(bEnable)
                                {
                                    value[0] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                                }
                                else
                                {
                                    value[0] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
                                }

                                break;
                            }
                        }
                        break;
                    case PM_CHIPLET_TYPE_SYS:
                        count = 0;
                        offset[count++] = keplerEventGroup->priAddress[chipIdx] + pPMEnableRegInfo->regOffset;
                        offset[count++] = NV_PRI_FE_PERFMON;
                        // read _PM registers
                        status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
                        if (status != CUDA_SUCCESS) {
                            return CUPROF_ERROR_HARDWARE;
                        }

                        // set PM_ENABLE bit by ORing the read value for selected instance
                        // disable PM_ENABLE bit by ANDing the read value for all others instances
                        if(bEnable) {
                            value[0] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                            value[1]  = DRF_REPLACE(value[1], NV_PRI_FE_PERFMON_ENABLE_ENABLE, NV_PRI_FE_PERFMON_ENABLE);
                        }
                        else {
                            value[0] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
                            value[1] &= ~(DRF_MASK(NV_PRI_FE_PERFMON_ENABLE)<<(DRF_SHIFT(NV_PRI_FE_PERFMON_ENABLE)));
                        }
                        break;
                    case PM_CHIPLET_TYPE_FBP:
                        count = 0;
                        //TBD The changes done for GF108 can be removed as no chip in kepler hs 2 FBPA per FBP
                        // everything but fbpa2pm_ltc_fb_perf_muxed_bus/NV_PFB_FBPA_*_PM is floorswept in virtual address space
                        if(pParsedClk->pParsedUnit[i]->unitId == PM_UNIT_FB) {
                                count = 1;
                                //Use broadcast register to enable PM for FBPA as unicast are giving wrong values
                                //Writing to boardcast register for each chiplet to avoid conditions, otherwise writing
                                //only once is sufficient
                                //This is not needed for GF108 as it has only 1 FB chiplet with 2 FBPA and address of
                                //both FBPAs are different.
                                offset[0] = NV_FBPA_PRI_BASE_BROADCAST + pPMEnableRegInfo->regOffset;
                                // read _PM registers
                                status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
                                if (status != CUDA_SUCCESS) {
                                    return CUPROF_ERROR_HARDWARE;
                                }
                                // set PM_ENABLE bit by ORing the read value for selected instance
                                // disable PM_ENABLE bit by ANDing the read value for all others instances
                                if(bEnable)
                                {
                                    value[0] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                                }
                                else
                                {
                                    value[0] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)
                                                  <<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
                                }

                        }
                        else {
                            if((pParsedClk->pParsedUnit[i]->unitId == PM_UNIT_LTC) ||
                               (pParsedClk->pParsedUnit[i]->unitId == PM_UNIT_LTC1) ||
                               (pParsedClk->pParsedUnit[i]->unitId == PM_UNIT_LTC2) ||
                               (pParsedClk->pParsedUnit[i]->unitId == PM_UNIT_LTC3) ||
                               (pParsedClk->pParsedUnit[i]->unitId == PM_UNIT_LTC5)) {
                                pPMEnableRegInfo1 = &pTempPerfUnitTable->pmEnableRegInfo1;
                                for(count = 0; count < numL2Slices; count++) {
                                    offset[count] = pTempPerfUnitTable->priBaseAddress
                                        + pTempPerfUnitTable->priChipletOffset * chipIdx
                                        + pTempPerfUnitTable->priInstanceOffset * count
                                        + pPMEnableRegInfo->regOffset;
                                }
                                //set the PM enable bit for
                                offset[count++] = NV_PLTCG_BASE
                                    + pTempPerfUnitTable->priChipletOffset * chipIdx
                                    + pPMEnableRegInfo1->regOffset;

                                status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
                                if (status != CUDA_SUCCESS) {
                                    return CUPROF_ERROR_HARDWARE;
                                }
                                for(count = 0; count < numL2Slices; count++) {
                                    //Enable only 1 LTS out of the 4 and disable remaining 3.
                                    //Check if a signal from subp0 gets combined with miss from subp1
                                    if((pParsedClk->pParsedUnit[i]->instance == count) && bEnable) {
                                        value[count] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                                        value[count] &= ~pParsedClk->pParsedUnit[i]->groupSelMask;
                                        value[count] |= (pParsedClk->pParsedUnit[i]->groupSelValue & pParsedClk->pParsedUnit[i]->groupSelMask);
#if 0
                                        // assign group to GROUP bit/s by ORing into read value
                                        startBit = pTempPerfUnitTable->pmGroupSelRegInfo.firstBit;
                                        endBit   = startBit + pTempPerfUnitTable->pmGroupSelRegInfo.subFieldWidth - 1;

                                        // Set the group for experiment for a L2 slice.
                                        //Normally the group for a signal is set in setPMGroupReg function, but for slices 1,2,3, we
                                        //set the group here in the loop
                                        //TBD we can collapse the setPMEnableReg and setPMGroupReg functions for all the PMs units.
                                        value[count] = DRF_REPLACE(value[count], pSignal->eventGroup, endBit:startBit);
                                        if(pSignal->isExpt) {
                                            value[count] &= ~pSignal->eventGroupMaskExpt;
                                            value[count] |= (pSignal->eventGroupExpt);
                                        }
#endif
                                    }
                                    else {
                                        value[count] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
#if 0
                                        if(pSignal->isExpt) {
                                            value[count] &= ~pSignal->eventGroupMaskExpt;
                                        }
#endif
                                    }
                                }
                                //Select a slice
                                //TBD change the hardcoded value and put it in data structure.
                                if(bEnable)
                                {
                                    value[count] |= (pPMEnableRegInfo1->value << pPMEnableRegInfo1->firstBit);
#if 0
                                    // assign group to GROUP bit/s by ORing into read value
                                    startBit = pTempPerfUnitTable->pmGroupSelRegInfo1.firstBit;
                                    endBit   = startBit + pTempPerfUnitTable->pmGroupSelRegInfo1.subFieldWidth - 1;
                                    value[count] = DRF_REPLACE(value[count], pParsedClk->pParsedUnit[i].instance, endBit:startBit);
                                    if(pSignal->isExpt) {
                                        //For an experiment we need to set the slice number in each group from
                                        //which the signals are being profiled.
                                        value[count] &= ~(pSignal->eventGroupMaskExpt);
                                        value[count] |= pSignal->instanceSelectExpt;
                                    }
#endif
                                }
                                else
                                {
                                    value[count] &= ~(DRF_MASK(pPMEnableRegInfo1->lastBit : pPMEnableRegInfo1->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo1->lastBit : pPMEnableRegInfo1->firstBit)));
#if 0
                                    if(pSignal->isExpt) {
                                        value[count] &= ~(pSignal->eventGroupMaskExpt);
                                    }
#endif
                                }
                                count++;
                            }
                        }

                        break;
                    default:
                        CU_ERROR_PRINT(("Not a valid chiplet type.\n"));
                        break;
                }
                status = PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
                if (status != CUDA_SUCCESS) {
                    return CUPROF_ERROR_HARDWARE;
                }
                i++;
            }
        }
    }

    return CUPROF_SUCCESS;
}

// Index of available TPCs after floorsweep
static CUprofResult getVirtualTpcIdx(CUctx* ctx, NvU32 **virtualtoPhysicalTpcIndex, NvU32 *gpcCount)
{
    NvU32 tpcDisableMask = 0, maxtpcCount = 0, tpcCount = 0;
    NvU32 gpc = 0, tpc = 0;

    maxtpcCount = ctx->device->state.limits.maxTpcsPerGpc;

    for(gpc = 0; gpc < *gpcCount; gpc++)
    {
        tpcCount = 0;
        //Read floorsweeping status for the engine
        tpcDisableMask = ctx->device->state.limits.gpcTpcMask[gpc];

        CU_DEBUG_PRINT(("GpcTpc Mask for GPC:%d =  0x%.08x\n", gpc,tpcDisableMask));

        for(tpc = 0; tpc < maxtpcCount; tpcDisableMask>>=1, tpc++)
        {
            if((tpcDisableMask & 1) != 0)
            {
               virtualtoPhysicalTpcIndex[gpc][tpcCount] = tpc;
                tpcCount++;
            }
        }
        CU_ASSERT(tpcCount == ctx->device->state.limits.numTpcsPerGpc[gpc]);
    }

    return CUPROF_SUCCESS;
}

static void resetPMTarget(const CUeventGroup *pEventGroup) {
    CUkeplerEventGroup  *keplerEventGroup;
    keplerEventGroup = pEventGroup->arch.keplerEventGroup;

    //It is possible that after eventgroup disable, the user can remove all ids
    //and add id from different domain. So the pmmaddress/priaddress need to be
    //recalculated for that chiplet.
    //Free pmm/pri address pointers otherwise they cause memory leak
    if (keplerEventGroup->pmmAddress) {
        free(keplerEventGroup->pmmAddress);
        keplerEventGroup->pmmAddress = NULL;
    }
    if (keplerEventGroup->priAddress) {
        free(keplerEventGroup->priAddress);
        keplerEventGroup->priAddress = NULL;
    }
}

static CUprofResult setupPMTarget(const CUeventGroup *pEventGroup)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 gpcId = 0, tpcId = 0, gpcCount = 0, tpcCount = 0, maxtpc = 0, totalTPCCount = 0;
    NvU32 i = 0, SMIdx = 0;
    NvU32 fbpCount = 0, tpcSelected = 0, gpcSelected = 0;
    CUparsedClk  *pParsedClk = NULL;
    CUSMCtrInfo  *pSM = NULL;
    CUkeplerEventGroup  *keplerEventGroup;
    NvU32 maxtpcCount;
    NvU32  **virtualtoPhysicalTpcIndex = NULL;

    //For PM signals
    keplerEventGroup = pEventGroup->arch.keplerEventGroup;
    pParsedClk = pEventGroup->arch.keplerEventGroup->pParsedClk;
    pSM = pEventGroup->arch.keplerEventGroup->pSM;

    CU_TRACE_FUNCTION();

    switch(pEventGroup->arch.keplerEventGroup->chipletType)
    {
        //Allocate structure for chiplets that store the base address for the PRI registers for each chiplet
    case PM_CHIPLET_TYPE_SYS:
        keplerEventGroup->pmmAddress = (NvU32 *) malloc(sizeof(NvU32) * 1);
        keplerEventGroup->priAddress = (NvU32 *) malloc(sizeof(NvU32) * 1);
        if (!(keplerEventGroup->pmmAddress && keplerEventGroup->priAddress))
        {
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto EXIT;
        }

        keplerEventGroup->maxChiplets = 1;
        // TODO: it seems units under chiplet SYS have absolute address
        // in spec file, thus keeping priAddress = 0. Verify it
        keplerEventGroup->priAddress[0] = 0;
        keplerEventGroup->pmmAddress[0] = NV_PERF_PMMSYS_BASE;
        keplerEventGroup->pmUnitMask = 1;

        break;

    case PM_CHIPLET_TYPE_GPC:
        //TBD Shift the gpc processing related part to a function.

        // handle floor-sweeping case
        // On fermi the floorsweeping has all been abstracted to SW so that we dont worry about what units are swept,
        // we really just care about how many of each unit we have, and access them sequentially from [0-max]
        // the HW deals with mapping them internally
        gpcCount = pEventGroup->pCtx->device->state.limits.numGpcs;   // no. of available GPCs after floorsweep

        maxtpcCount = pEventGroup->pCtx->device->state.limits.maxTpcsPerGpc;
        if(CUPROF_EVENT_COLLECTION_METHOD_HWPM == pEventGroup->domain->eventCollectionMethod) //HWPM
        {
            virtualtoPhysicalTpcIndex = (NvU32 **) malloc(sizeof(NvU32 *) * gpcCount);
            for(i = 0; i < gpcCount; i++)
            {
                virtualtoPhysicalTpcIndex[i] = (NvU32 *) malloc(sizeof(NvU32) * maxtpcCount);
            }
            status = getVirtualTpcIdx(pEventGroup->pCtx, virtualtoPhysicalTpcIndex, &gpcCount);
            if(status != CUPROF_SUCCESS) {
                goto EXIT;
            }
            CU_ASSERT(gpcCount);
        }

        keplerEventGroup->gpcCount = gpcCount;
        keplerEventGroup->tpcPerGpcCount = pEventGroup->pCtx->device->state.limits.numTpcsPerGpc;

        // Enable NV_SM_PM_CTRL for selected GPC/TPC and disable for others
        // disable NV_SM_PM_CTRL in other GPCs
        for (gpcId = 0; gpcId < gpcCount; gpcId++) {
            // get no of available TPCs in the GPC
            tpcCount = keplerEventGroup->tpcPerGpcCount[gpcId];
            if(pEventGroup->pCtx->device->state.workDistributionMode == CU_WORK_DISTRIBUTION_DYNAMIC)
            {
                //From Gentaro Hirota and Tanmoy Mandal:
                //In Kepler, CWD is blind to GPC. It just launches CTAs directly to SMs.
                //So the 1st SM picked by CWD after idle would be always the SM with highest logical id.
                //RM assigns each SM a logical id. SM in TPC0 of GPC0 gets logical id zero.
                //see function fermi_getInfo in //sw/dev/gpu_drv/cuda_a/drivers/gpgpu/cuda/src/devtools/common/halo/fermi/fermi.c
                //to understand the algorithm behind SM logical-id
                //in short, select the last SM of last GPC that has highest no of SMs becuase that's the first one chosen for scheduling

                totalTPCCount += tpcCount;

                if (maxtpc <= tpcCount) {
                    maxtpc = tpcCount;
                    //select last tpc of selected gpc
                    tpcSelected = totalTPCCount - 1;
                    gpcSelected = gpcId;
                }
            }

#ifdef DEBUG
            CU_DEBUG_PRINT(("GPC %d : num of active TPCs = %d\n", gpcId, tpcCount));
#endif
        }

        keplerEventGroup->pmmAddress = (NvU32 *) malloc(sizeof(NvU32) * totalTPCCount);
        keplerEventGroup->priAddress = (NvU32 *) malloc(sizeof(NvU32) * totalTPCCount);
        if (!(keplerEventGroup->pmmAddress && keplerEventGroup->priAddress))
        {
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto EXIT;
        }

        keplerEventGroup->maxChiplets = totalTPCCount;
        //pmUnitMask for gpc is set for the selected gpc and tpc 0 will be profiled from the seleced gpc by default
        //this hack will be gone if we have 1 perfmon per tpc in kepler


        if((KEPLER_CLK_DOMAIN_GK110_GPC0 == pEventGroup->domain->domainId) ||
           (KEPLER_CLK_DOMAIN_GK104_GPC0 == pEventGroup->domain->domainId))//HWPM
        {
            //gpc domain supported only per gpc, so adjust sm mask accordingly
            SMIdx = 0;
            //Assign the pri and pmm base addreses so that they need not be calcualted again and again
            for (gpcId = 0; gpcId < gpcCount; gpcId++) {
                //Profile only first tpc from a GPC.
                for (tpcId = 0; tpcId < pEventGroup->arch.keplerEventGroup->tpcPerGpcCount[gpcId]; tpcId++) {
                    //Assuming till this point, we have checked grouping and all signals with same eventgroup1 are allowed.
                    if(pEventGroup->profileAll && (pParsedClk->pParsedUnit[0]->instance == tpcId)) {
                        //Profile required tpc of each gpc
                        keplerEventGroup->pmUnitMask |= (1 << SMIdx);
                    } else {
                        if((gpcId == gpcSelected) && (pParsedClk->pParsedUnit[0]->instance == tpcId)) {
                            //Profile required tpc of selected gpc
                            keplerEventGroup->pmUnitMask |= (1 << SMIdx);
                        }
                    }
                    keplerEventGroup->priAddress[SMIdx] = NV_PRI_TPC_ADDR(gpcId, tpcId);
                    keplerEventGroup->pmmAddress[SMIdx] = NV_PERF_PMMGPC_BASE + gpcId * NV_PERF_PMMGPC_CHIPLET_OFFSET;
                    SMIdx++;
                }
            }
        }
        else {
            if(CUPROF_EVENT_COLLECTION_METHOD_HWPM == pEventGroup->domain->eventCollectionMethod) //HWPM
            {
                SMIdx = 0;
                //Assign the pri and pmm base addreses so that they need not be calcualted again and again
                for (gpcId = 0; gpcId < gpcCount; gpcId++) {
                    for (tpcId = 0; tpcId < pEventGroup->arch.keplerEventGroup->tpcPerGpcCount[gpcId]; tpcId++) {
                        keplerEventGroup->pmUnitMask |= (1 << SMIdx);
                        keplerEventGroup->priAddress[SMIdx] = NV_PRI_TPC_ADDR(gpcId, tpcId);
                        //TBD A hack here to access the second domain from the gpc for tpc.
                        //The getClkIdx function will return same value for all gpctpc domain for all tpcs.
                        //So we add the domain offset in pmmaddress here. Else we will have to expose separate
                        //domain for each tpc, resulting in multiple signal tables etc.
                        if(keplerEventGroup->tpcPerGpcCount[gpcId] > 0) {
                            keplerEventGroup->pmmAddress[SMIdx] = NV_PERF_PMMGPC_BASE + gpcId * NV_PERF_PMMGPC_CHIPLET_OFFSET +
                                                                virtualtoPhysicalTpcIndex[gpcId][tpcId] * NV_PMM_DOMAIN_OFFSET;
                        }
                        SMIdx++;
                    }
                }
            }
            else //SMPERF
            {
                SMIdx = 0;
                //Assign the pri and pmm base addreses so that they need not be calcualted again and again
                for (gpcId = 0; gpcId < gpcCount; gpcId++) {
                    for (tpcId = 0; tpcId < pEventGroup->arch.keplerEventGroup->tpcPerGpcCount[gpcId]; tpcId++) {
                        //Profile all tpcs from a GPC for SM counters.
                        keplerEventGroup->pmUnitMask |= (1 << SMIdx);
                        keplerEventGroup->priAddress[SMIdx] = NV_PRI_TPC_ADDR(gpcId, tpcId);
                        keplerEventGroup->pmmAddress[SMIdx] = NV_PERF_PMMGPC_BASE + gpcId * NV_PERF_PMMGPC_CHIPLET_OFFSET;
                        SMIdx++;
                    }
                }

            }
            if(!pEventGroup->profileAll) {
                //If profileall flag is not set, then profile only the first tpc selected by scheduler.
                keplerEventGroup->pmUnitMask = 1 << tpcSelected;
            }
        }


        break;

    case PM_CHIPLET_TYPE_FBP:
        fbpCount = pEventGroup->pCtx->device->state.limits.numFbps;
        CU_ASSERT(fbpCount);

        keplerEventGroup->pmmAddress = (NvU32 *) malloc(sizeof(NvU32) * fbpCount);
        keplerEventGroup->priAddress = (NvU32 *) malloc(sizeof(NvU32) * fbpCount);
        if (!(keplerEventGroup->pmmAddress && keplerEventGroup->priAddress))
        {
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto EXIT;
        }

        keplerEventGroup->maxChiplets = fbpCount;
        for (i = 0; i < fbpCount; i++) {
            //Since PRI base/offset for FBPA and LTC is different, though they belong to same chiplet, the PRI base/offset are stored in unit table.
            //keplerEventGroup->pmmAddress[i] = (NV_PLTCG_BASE+i*NV_PLTCG_STRIDE);
            //keplerEventGroup->priAddress[i] = (NV_FBPA_PRI_BASE+i*NV_FBPA_PRI_STRIDE);
            keplerEventGroup->pmmAddress[i] = (NV_PERF_PMMFBP_BASE+i*NV_PERF_PMMFBP_CHIPLET_OFFSET);
            keplerEventGroup->pmUnitMask |= 1 << i;
        }

        if(!pEventGroup->profileAll) {
            //If profileall flag is not set, then profile only the first fbp.
            keplerEventGroup->pmUnitMask = 1;
        }
        break;

    default:
        CU_ASSERT(0);
        break;
    }

    //TBD Shift values to keplereventgroup structure to remove the following switch
    switch(pEventGroup->domain->eventCollectionMethod)
    {
    case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
        if ((pParsedClk) && (pEventGroup->totalCounters)) {
            if(pParsedClk->values == NULL) {
                pParsedClk->values = (NvU32 *) malloc(keplerEventGroup->maxChiplets     * //no of chiplets
                    (CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS + CU_PROF_ELAPSED_CLOCK_SLOT) * //no of counters to be profiled in this domain
                    sizeof(NvU32));
                if(pParsedClk->values == NULL)
                {
                    status = CUPROF_ERROR_OUT_OF_MEMORY;
                    goto EXIT;
                }
            }
            cuosMemset(pParsedClk->values, 0, sizeof(NvU32) * keplerEventGroup->maxChiplets * pEventGroup->totalCounters);
        }
        break;

    case CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
        if ((pSM) && (pSM->SMCountersAdded)) {
            if(pSM->values == NULL) {
                pSM->values = (NvU64 *) malloc(pEventGroup->instanceCountAvail     * //no of chiplets
                    (CU_PROF_PM_SM_MAX_COUNTERS)  * //no of counters to be profiled in this domain
                    sizeof(NvU64));
                if(pSM->values == NULL)
                {
                    status = CUPROF_ERROR_OUT_OF_MEMORY;
                    goto EXIT;
                }
            }
            cuosMemset(pSM->values, 0, sizeof(NvU64) * pEventGroup->instanceCountAvail * pSM->SMCountersAdded);
        }
        break;

    default:
        //TBD Add s/w counters here
        break;
    }
    //Freeing the memory allocated to virtualtoPhysicalTpcIndex to avoid memory leak:
    if(CUPROF_EVENT_COLLECTION_METHOD_HWPM == pEventGroup->domain->eventCollectionMethod) {
        if(virtualtoPhysicalTpcIndex) {
            for(i = 0; i < gpcCount; i++) {
                free(virtualtoPhysicalTpcIndex[i]);
            }
            free(virtualtoPhysicalTpcIndex);
        }
    }
    return status;
EXIT:
    free(pParsedClk->values);
    free(keplerEventGroup->pmmAddress);
    free(keplerEventGroup->priAddress);
    if(CUPROF_EVENT_COLLECTION_METHOD_HWPM == pEventGroup->domain->eventCollectionMethod) {
        if(virtualtoPhysicalTpcIndex) {
            for(i = 0; i < gpcCount; i++) {
                free(virtualtoPhysicalTpcIndex[i]);
            }
            free(virtualtoPhysicalTpcIndex);
        }
    }
    return status;
}
// function to configure event-groups
static CUprofResult setPMGroupReg(const CUeventGroup *pEventGroup)
{
    //Function to be changed for new version
    CUresult status = CUDA_SUCCESS;
    NvU32 offset[2], value[2];
    NvU32 chipIdx = 0, tempUnitId = 0;
    NvU32 i = 0;
    CUkeplerEventGroup *keplerEventGroup;
    PerfUnitTable   *pTempPerfUnitTable = NULL;
    CUparsedClk     *pTempParsedClk = NULL;
    CU_TRACE_FUNCTION();

    keplerEventGroup = pEventGroup->arch.keplerEventGroup;

    //TBD for LTC and FB, we can use broadcast register
    for (chipIdx = 0; chipIdx < pEventGroup->arch.keplerEventGroup->maxChiplets; chipIdx++) {
        if(keplerEventGroup->pmUnitMask & (1<<chipIdx)) {
            pTempParsedClk = keplerEventGroup->pParsedClk;
            i = 0;
            while(pTempParsedClk && pTempParsedClk->pParsedUnit[i])
            {
                pTempPerfUnitTable = pTempParsedClk->pParsedUnit[i]->pPerfUnitTable;
                //The earlier design was assuming that there will be only 1 PRI base address for 1 instance of a chiplettype
                //FBP has different base addresses for LTC and FBP, to solve this currently added the pri base address to unit table.
                //This doesn't work directly for GPC as the TPC pri base address are based on gpcid and tpcid both.
                //TBD: Adding hack here, to remove this hack, we will have to add an extra loop for instance in each function.
                tempUnitId = pTempParsedClk->pParsedUnit[i]->unitId;
                if(PM_CHIPLET_TYPE_FBP == pEventGroup->arch.keplerEventGroup->chipletType) {
                    if(tempUnitId == PM_UNIT_FB) {
                        //Use broadcast register to enable PM for FBPA as unicast are giving wrong values
                        //Writing to boardcast register for each chiplet to avoid conditions, otherwise writing
                        //only once is sufficient
                        //This is not needed for GF108 as it has only 1 FB chiplet with 2 FBPA and address of
                        //both FBPAs are different.
                        offset[0] = NV_FBPA_PRI_BASE_BROADCAST + pTempParsedClk->pParsedUnit[i]->groupSelAddress;
                    }
                    else {
                        //For LTC 2 muxes need to be configured, LTC and LTS
                        offset[0] = pTempPerfUnitTable->priBaseAddress
                            + pTempPerfUnitTable->priChipletOffset * chipIdx
                            + pTempParsedClk->pParsedUnit[i]->groupSelAddress;

                        //set the PM enable bit for
                        offset[1] = NV_PLTCG_BASE
                            + pTempPerfUnitTable->priChipletOffset * chipIdx
                            + pTempParsedClk->pParsedUnit[i]->groupSelAddress1;
                    }
                } else if (tempUnitId == PM_UNIT_GPCMMU) {
                    NvU32 tempChipIdx = 0, totalTpcCount = 0, count = 0;
                    // for all units that are 1/GPC
                    totalTpcCount = 0;
                    //Identify the gpc
                    for(tempChipIdx = 0; tempChipIdx < pEventGroup->arch.keplerEventGroup->gpcCount; tempChipIdx++) {

                        count = pEventGroup->arch.keplerEventGroup->tpcPerGpcCount[tempChipIdx];
                        if (!((chipIdx >= totalTpcCount) && (chipIdx < (totalTpcCount + count)))) {
                            totalTpcCount+=count;
                            continue;
                        } else {
                            break;
                        }
                    }

                    offset[0] = pTempPerfUnitTable->priBaseAddress
                            + pTempPerfUnitTable->priChipletOffset * tempChipIdx
                            + pTempParsedClk->pParsedUnit[i]->groupSelAddress;

                } else {
                    offset[0] = keplerEventGroup->priAddress[chipIdx] + pTempParsedClk->pParsedUnit[i]->groupSelAddress;
                    if ((tempUnitId == PM_UNIT_TEX_M) || (tempUnitId == PM_UNIT_TEX_S) || (tempUnitId == PM_UNIT_TEX_D)) {
                        //For Tex 2 muxes need to be configured
                        // Again a hack. For GF10x tex, we have to select the TRM
                        // The NV_PTPC_PRI_TEX_TRM_PM register controls PM signal muxing for TRM.
                        // TRM_PM_PM_SEL defines the selection among trm internal pm, tex0_m and tex1_m.
                        // So we have a double layer of group selection.
                        offset[1] = keplerEventGroup->priAddress[chipIdx] + pTempParsedClk->pParsedUnit[i]->groupSelAddress1;
                    }
                }

                if((tempUnitId == PM_UNIT_TEX_M) || (tempUnitId == PM_UNIT_TEX_S) || (tempUnitId == PM_UNIT_TEX_D) ||
                    (tempUnitId == PM_UNIT_LTC) || (tempUnitId == PM_UNIT_LTC1) ||
                    (tempUnitId == PM_UNIT_LTC2) || (tempUnitId == PM_UNIT_LTC3) ||
                    (tempUnitId == PM_UNIT_LTC5)) {

                    // read the register
                    status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, 2, offset, value, 0);
                    if (status != CUDA_SUCCESS) {
                        return CUPROF_ERROR_HARDWARE;
                    }

                    value[0] &= ~pTempParsedClk->pParsedUnit[i]->groupSelMask;
                    value[0] |= (pTempParsedClk->pParsedUnit[i]->groupSelValue & pTempParsedClk->pParsedUnit[i]->groupSelMask);

                    value[1] &= ~pTempParsedClk->pParsedUnit[i]->groupSelMask1;
                    value[1] |= (pTempParsedClk->pParsedUnit[i]->groupSelValue1 & pTempParsedClk->pParsedUnit[i]->groupSelMask1);

                    //TBD check how to handle expt here
                    status = PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, 2, offset, value, 0);
                    if (status != CUDA_SUCCESS) {
                        return CUPROF_ERROR_HARDWARE;
                    }

                }
                else {
                    // read the register
                    status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, 1, offset, value, 0);
                    if (status != CUDA_SUCCESS) {
                        return CUPROF_ERROR_HARDWARE;
                    }

                    value[0] &= ~pTempParsedClk->pParsedUnit[i]->groupSelMask;
                    value[0] |= (pTempParsedClk->pParsedUnit[i]->groupSelValue & pTempParsedClk->pParsedUnit[i]->groupSelMask);

                    status = PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, 1, offset, value, 0);
                    if (status != CUDA_SUCCESS) {
                        return CUPROF_ERROR_HARDWARE;
                    }
                }
                i++;
            }
                }
        }
    return CUPROF_SUCCESS;
}

static CUprofResult setupPMRegistersModeB(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *value = NULL;
    NvU32 count = 0, size = 0, numReg = 0;
    NvU32 domainRegOffset = 0, chipIdx = 0;
    CUkeplerEventGroup  *keplerEventGroup;

    CU_TRACE_FUNCTION();

    //For PM signals
    keplerEventGroup = pEventGroup->arch.keplerEventGroup;

    if(!keplerEventGroup)
        return CUPROF_ERROR_UNKNOWN; //TBD check if we can return this error.

    //8 - reset sel+op for all 4 counters
    //8 - set sel+op for all 4 counters
    //1 - PMM_CONTROL
    //4*6 - 4 counters, max 6 units/counter (ltc has max 6 units)
    numReg = (8 + 8 + 2 + 4 * 6) * keplerEventGroup->maxChiplets;   //TBD: Replace the magic no
    size = sizeof(NvU32) * numReg;
    offset = (NvU32*)malloc(size);
    //default value is 0
    value  = (NvU32*)calloc(size, 1);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset and value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    status = setPMGroupReg(pEventGroup);
    if (CUPROF_SUCCESS != status) {
        goto EXIT;
    }

    for (chipIdx = 0; chipIdx < keplerEventGroup->maxChiplets; chipIdx++) {
        if(keplerEventGroup->pmUnitMask & (1<<chipIdx))
        {
            if (keplerEventGroup->pParsedClk && pEventGroup->totalCounters) {
                CUparsedClk *pTempParsedClk = keplerEventGroup->pParsedClk;
                if((pTempParsedClk->mode == -1) && (pEventGroup->totalCounters == 1)) {
                    //if elapsed_cycles_sm is the only signal added, then the mode remains -1 which affects the registers below, so just set to 0.
                    pTempParsedClk->mode = 0;
                }
                domainRegOffset = keplerEventGroup->pmmAddress[chipIdx] + keplerEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
                offset[count]  = domainRegOffset + NV_PMM_CONTROL;
                if ((pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_KERNEL) ||
                    (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS)) {
                    if (pEventGroup->pCtx->pmNew->isPmCtxswModeEnabled) {
                        value[count++] = (NV_PMM_CONTROL_MODE_B                   << NV_PMM_CONTROL_MODE__SHIFT)    |
                                         (pTempParsedClk->mode                    << NV_PMM_CONTROL_ADDTOCTR__SHIFT)|
                                         (NV_PMM_CONTROL_CTXSW_MODE_ENABLED       << NV_PMM_CONTROL_CTXSW_MODE__SHIFT);
                    }
                    else {
                        value[count++] = (NV_PMM_CONTROL_MODE_B                   << NV_PMM_CONTROL_MODE__SHIFT)    |
                                         (pTempParsedClk->mode                    << NV_PMM_CONTROL_ADDTOCTR__SHIFT)|
                                         (NV_PMM_CONTROL_CTXSW_MODE_DISABLED      << NV_PMM_CONTROL_CTXSW_MODE__SHIFT);
                    }
                } else if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING){

                    NvU8 perfmonid = 0;
                    //Assign 8 bit perfmonId as follows:
                    //for FBP and GPC, LSB ro MSB : 2 bits for chiplet, 2 bits for clkidx and 4 bits for instance.
                    //for SYS, LSB ro MSB : 2 bits for chiplet, 3 bits for clkidx and 3 bits for instance.
                    if (pEventGroup->arch.keplerEventGroup->chipletType == PM_CHIPLET_TYPE_SYS) {
                        //There is only 1 instance of sys but it can have max 8 domains so use different encoding
                        perfmonid = (pEventGroup->arch.keplerEventGroup->chipletType & 3) | ((keplerEventGroup->clkIdx & 7) << 2) | ((chipIdx & 0x7) << 5);
                    } else {
                        //On fermi and kepler, there shouldn't be more than 16 SMs, On Tesla this approach wouldn't have worked
                        //On maxwell check max no of SMs/chip
                        perfmonid = (pEventGroup->arch.keplerEventGroup->chipletType & 3) | ((keplerEventGroup->clkIdx & 3) << 2) | ((chipIdx & 0xf)<< 4);
                    }
                    value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_MODE_E, NV_PERF_PMMSYS_CONTROL_MODE);
                    value[count] = DRF_REPLACE(value[count], pTempParsedClk->mode, NV_PERF_PMMSYS_CONTROL_ADDTOCTR);
                    value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_CTXSW_MODE_DISABLED, NV_PERF_PMMSYS_CONTROL_CTXSW_MODE);
                    value[count] = DRF_REPLACE(value[count], pEventGroup->pCtx->pmNew->samplingPeriod, NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES);
                    value[count] = DRF_REPLACE(value[count], perfmonid, NV_PERF_PMMSYS_CONTROL_PERFMONID);
                    count++;
                }
                offset[count]  = domainRegOffset + NV_PMM_TRIG0_SEL;
                value[count++] = 0;
                offset[count]  = domainRegOffset + NV_PMM_TRIG0_OP;
                value[count++] = 0;
                offset[count]  = domainRegOffset + NV_PMM_TRIG1_SEL;
                value[count++] = 0;
                offset[count]  = domainRegOffset + NV_PMM_TRIG1_OP;
                value[count++] = 0;
                offset[count]  = domainRegOffset + NV_PMM_EVENT_SEL;
                value[count++] = 0;
                offset[count]  = domainRegOffset + NV_PMM_EVENT_OP;
                value[count++] = 0;
                offset[count]  = domainRegOffset + NV_PMM_SAMPLE_SEL;
                value[count++] = 0;
                offset[count]  = domainRegOffset + NV_PMM_SAMPLE_OP;
                value[count++] = 0;

                if (pTempParsedClk->eventSpecUsed & NV_PMM_TRIG1) {
                    offset[count]  = domainRegOffset + NV_PMM_TRIG1_SEL;
                    value[count++] = pTempParsedClk->watchBus[NV_PMM_TRIG1_BIT_POS];
                    offset[count]  = domainRegOffset + NV_PMM_TRIG1_OP;
                    value[count]   = DRF_REPLACE(value[count], pTempParsedClk->function[NV_PMM_TRIG1_BIT_POS], NV_PERF_PMMSYS_TRIG1_OP_FUNC);
                    count++;
                }

                if (pTempParsedClk->eventSpecUsed & NV_PMM_TRIG0) {
                    offset[count]  = domainRegOffset + NV_PMM_TRIG0_SEL;
                    value[count++] = pTempParsedClk->watchBus[NV_PMM_TRIG0_BIT_POS];
                    offset[count]  = domainRegOffset + NV_PMM_TRIG0_OP;
                    value[count]   = DRF_REPLACE(value[count], pTempParsedClk->function[NV_PMM_TRIG0_BIT_POS], NV_PERF_PMMSYS_TRIG0_OP_FUNC);
                    count++;
                }

                if (pTempParsedClk->eventSpecUsed & NV_PMM_EVENT) {
                    offset[count]  = domainRegOffset + NV_PMM_EVENT_SEL;
                    value[count++] = pTempParsedClk->watchBus[NV_PMM_EVENT_BIT_POS];
                    offset[count]  = domainRegOffset + NV_PMM_EVENT_OP;
                    value[count]   = DRF_REPLACE(value[count], pTempParsedClk->function[NV_PMM_EVENT_BIT_POS], NV_PERF_PMMSYS_EVENT_OP_FUNC);
                    count++;
                }

                if (pTempParsedClk->eventSpecUsed & NV_PMM_SAMPLE) {
                    offset[count]  = domainRegOffset + NV_PMM_SAMPLE_SEL;
                    value[count++] = pTempParsedClk->watchBus[NV_PMM_SAMPLE_BIT_POS];
                    offset[count]  = domainRegOffset + NV_PMM_SAMPLE_OP;
                    value[count]   = DRF_REPLACE(value[count], pTempParsedClk->function[NV_PMM_SAMPLE_BIT_POS], NV_PERF_PMMSYS_SAMPLE_OP_FUNC);
                    count++;
                }
            }
        }
   }
    CU_ASSERT(count <= numReg);
    // write signal configuration
    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

EXIT:
    free (offset);
    free (value);
    return status;
}

static CUprofResult setupPMRegistersModeCommon(const CUeventGroup *pEventGroup, NvU32* perfmonTriggerRefCount) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL;
    NvU32 *value  = NULL;
    NvU32 count = 0;
    NvU32 domainRegOffset = 0, chipIdx = 0;
    NvU32 numDomains = 0;
    NvU32 size = 0;
    CUkeplerEventGroup  *keplerEventGroup;

    CU_TRACE_FUNCTION();

    numDomains = PM_MAX_CHIPLET_TYPES * PM_MAX_CHIPLETS_PER_CHIPLET_TYPE * PM_MAX_DOMAIN_PER_CHIPLET;
    size  = sizeof(NvU32) * (numDomains + 16);
    offset = (NvU32*)malloc(size);
    value  = (NvU32*)malloc(size);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset/value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    keplerEventGroup = pEventGroup->arch.keplerEventGroup;
    CU_ASSERT(keplerEventGroup->pParsedClk);

    // Vivek Gupta suggests disable the safety clamp before you can get pass signals to the performance monitors on net35 and above.
    // This is to prevent us being affected by cdc/async bugs inside units that feed to the monitors
    for (chipIdx = 0; chipIdx < keplerEventGroup->maxChiplets; chipIdx++) {
        if(keplerEventGroup->pmUnitMask & (1<<chipIdx)) {
            if(pEventGroup->totalCounters) {
                domainRegOffset = keplerEventGroup->pmmAddress[chipIdx] + keplerEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
                offset[count]  = domainRegOffset + NV_PMM_CLAMP_CYA_CONTROL;
                value[count++] = NV_PMM_CLAMP_CYA_CONTROL_ENABLECYA_DISABLE;
            }
        }
    }

    if(!(*perfmonTriggerRefCount)) {
        offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_STATUS;
        value[count++] = 0x0;

        offset[count]  = NV_PERF_PMASYS_FBP_TRIGGER_STATUS;
        value[count++] = 0x0;

        offset[count]  = NV_PERF_PMASYS_SYS_TRIGGER_STATUS;
        value[count++] = 0x0;

        offset[count]  = NV_PERF_PMASYS_CONTROL;
        value[count++] = HWCONST(_PERF_PMASYS, CONTROL, STOPVPMCAPTURE, DOIT);

        offset[count]  = NV_PERF_PMASYS_CONTROL;
        value[count++] = 0x0;

        // setup PMA to push trigger to GPC chiplet
        offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_START_MASK;
        value[count++] = 0xffffffff;

        offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_STOP_MASK;
        value[count++] = 0xffffffff;

        offset[count]  = NV_PERF_PMASYS_SYS_TRIGGER_START_MASK;
        value[count++] = 0xffffffff;

        offset[count]  = NV_PERF_PMASYS_SYS_TRIGGER_STOP_MASK;
        value[count++] = 0xffffffff;

        offset[count]  = NV_PERF_PMASYS_FBP_TRIGGER_START_MASK;
        value[count++] = 0xffffffff;

        offset[count]  = NV_PERF_PMASYS_FBP_TRIGGER_STOP_MASK;
        value[count++] = 0xffffffff;
#if 1
        offset[count]  = NV_PERF_PMASYS_TRIGGER_GLOBAL;
        value[count++] = HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, ENABLE, ENABLED) |
            HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_GPC, ENABLE) |
            HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_FBP, ENABLE) |
            HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_SYS, ENABLE);
#else
        offset[count]  = NV_PERF_PMASYS_TRIGGER_GLOBAL;
        value[count++] = HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, MANUAL_START, PULSE) |
            HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, MANUAL_STOP, PULSE);
#endif
        offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_CONFIG_MIXED_MODE;
        value[count++] = 0xffffffff;
    }
    (*perfmonTriggerRefCount)++;

    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

EXIT:
    free(offset);
    free(value);

    return status;
}

// returns numeric value corresponding to signal name
static NvU32 resolveTPulse(const CUctx *ctx, const NvU32 clkIdx, const NvU32 chipletType)
{
    NvU32 const (*tPulse)[PM_MAX_DOMAIN_PER_CHIPLET] = NULL;
    NvU32 numericId = ~0U;

    // cut-down list containing pma_trigger signals only
    //The array is arranged in the order of domain ids, do not change the sequence
    // of the array, it will affect the counter values.
    // source: <branch>\drivers\resman\kernel\inc\kepler\gk104\pm_signals.h
    //static const KeplerSignalName2Numeric nvgk104_pma_trigger[] =
    //{
    //    {"gpc0_sigval_pma_trigger",                         205},
    //    //TBD: Currently we have trigger value same for all gpctpc domains so expose it as one domain.
    //    //{"gpctpc0_sigval_pma_trigger",                      109},
    //    //{"gpctpc1_sigval_pma_trigger",                      109},
    //    {"gpctpc_sigval_pma_trigger",                      109},
    //    {"host0_sigval_pma_trigger",                        77},
    //    {"hub0_sigval_pma_trigger",                         45},
    //    {"msd0_sigval_pma_trigger",                         77},
    //    {"msd1_sigval_pma_trigger",                         77},
    //    {"pcie0_sigval_pma_trigger",                        45},
    //    {"pwr0_sigval_pma_trigger",                         77},
    //    {"sys0_sigval_pma_trigger",                         173},
    //    {"xbar0_sigval_pma_trigger",                        77},
    //    {"ltc0_sigval_pma_trigger",                         77},
    //    {"rop0_sigval_pma_trigger",                         77}
    //};

    static const NvU32 nvgk104_t_pulse[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        {0x4E, 0x2E, 0x4E, 0x4E, 0x2E, 0xAE, 0x4E, 0x4E},
        {0xCE, 0x6E},
        {0x4E, 0x4E}
    };

    // source: <branch>\drivers\resman\kernel\inc\kepler\gk110\pm_signals.h
    //static const KeplerSignalName2Numeric nvgk110_pma_trigger[] =
    //{
    //    {"gpc0_sigval_pma_trigger",                         205},
    //    //TBD: Currently we have trigger value same for all gpctpc domains so expose it as one domain.
    //    //{"gpctpc0_sigval_pma_trigger",                      141},
    //    //{"gpctpc1_sigval_pma_trigger",                      141},
    //    {"gpctpc_sigval_pma_trigger",                      141},
    //    {"host0_sigval_pma_trigger",                        77},
    //    {"msd0_sigval_pma_trigger",                         77},
    //    {"msd1_sigval_pma_trigger",                         77},
    //    {"pcie0_sigval_pma_trigger",                        45},
    //    {"pwr0_sigval_pma_trigger",                         77},
    //    {"sys0_sigval_pma_trigger",                         205},
    //    {"xbar0_sigval_pma_trigger",                        77},
    //    {"ltc0_sigval_pma_trigger",                         77},
    //    {"rop0_sigval_pma_trigger",                         77}
    //};

    static const NvU32 nvgk110_t_pulse[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        {0x4E, 0x4E, 0x4E, 0x2E, 0xCE, 0x4E, 0x4E},
        {0xCE, 0x8E},
        {0x4E, 0x4E}
    };

    // source: <branch>\drivers\resman\kernel\inc\kepler\gk208\pm_signals.h
    //static const KeplerSignalName2Numeric nvgk208_pma_trigger[] =
    //{
    //    {"gpc0_sigval_pma_trigger",                         173},
    //    //TBD: Currently we have trigger value same for all gpctpc domains so expose it as one domain.
    //    //{"gpctpc0_sigval_pma_trigger",                      141},
    //    //{"gpctpc1_sigval_pma_trigger",                      141},
    //    {"gpctpc_sigval_pma_trigger",                      141},
    //    {"host0_sigval_pma_trigger",                        77},
    //    {"msd0_sigval_pma_trigger",                         77},
    //    {"msd1_sigval_pma_trigger",                         77},
    //    {"pcie0_sigval_pma_trigger",                        45},
    //    {"pwr0_sigval_pma_trigger",                         77},
    //    {"sys0_sigval_pma_trigger",                         173},
    //    {"xbar0_sigval_pma_trigger",                        45},
    //    {"ltc0_sigval_pma_trigger",                         77},
    //    {"rop0_sigval_pma_trigger",                         77}
    //};

    static const NvU32 nvgk208_t_pulse[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        {0x4E, 0x4E, 0x4E, 0x2E, 0xAE, 0x2E, 0x4E},
        {0xAE, 0x8E},
        {0x4E, 0x4E}
    };

#if NVCFG(GLOBAL_CHIP_T132) || NVCFG(GLOBAL_CHIP_T124) || NVCFG(GLOBAL_GPU_IMPL_GK20A)
    static const NvU32 nvgk20a_t_pulse[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {   //acb0, mc0, sys0
        {45, 45, 173},
        //gpc0, gpctpc0
        {173, 141},
        //fbp0
        {109}
    };
#endif

    CU_TRACE_FUNCTION();

    switch(ctx->device->state.chip) {
#if NVCFG(GLOBAL_ARCH_KEPLER)
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK104:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK106:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK107:
        tPulse = nvgk104_t_pulse;
        break;
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110):
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110B
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110B):
#endif
        tPulse = nvgk110_t_pulse;
        break;
#endif

#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK200
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK208):
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK208S
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK208S):
#endif
        tPulse = nvgk208_t_pulse;
        break;
#endif
#if NVCFG(GLOBAL_CHIP_T124) || NVCFG(GLOBAL_GPU_IMPL_GK20A) || NVCFG(GLOBAL_CHIP_T132)
#if NVCFG(GLOBAL_CHIP_T124) || NVCFG(GLOBAL_GPU_IMPL_GK20A)
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK20A):
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_T12X + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_T124):
#endif // NVCFG(GLOBAL_CHIP_T124) || NVCFG(GLOBAL_GPU_IMPL_GK20A)
#if NVCFG(GLOBAL_CHIP_T132)
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_T13X + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_T132):
#endif // NVCFG(GLOBAL_CHIP_T132)
        CU_ASSERT(0);
        //To be done
        tPulse = nvgk20a_t_pulse;
        break;
#endif // NVCFG(GLOBAL_CHIP_T124) || NVCFG(GLOBAL_GPU_IMPL_GK20A) || NVCFG(GLOBAL_CHIP_T132)
#endif // NVCFG(GLOBAL_ARCH_KEPLER)
    default:
        CU_ASSERT(0);
        return numericId;
    }

    CU_ASSERT(chipletType < PM_MAX_CHIPLET_TYPES);
    CU_ASSERT(clkIdx < PM_MAX_DOMAIN_PER_CHIPLET);

    numericId = tPulse[chipletType][clkIdx];

    return numericId;
}

// returns numeric value corresponding to signal name
static NvU32 resolveCoreSignalName(const CUctx *ctx, const NvU32 clkIdx, const NvU32 chipletType)
{
    NvU32 const (*signalNames)[PM_MAX_DOMAIN_PER_CHIPLET] = NULL;
    NvU32 numericId = ~0U;

    // cut-down list containing pma_trigger signals only
    //The array is arranged in the order of domain ids, do not change the sequence
    // of the array, it will affect the counter values.
    // source: <branch>\drivers\resman\kernel\inc\kepler\gk104\pm_signals.h
    //static const KeplerSignalName2Numeric nvgk104_pma_trigger[] =
    //{
    //    {"gpc0_sigval_pma_trigger",                         205},
    //    //TBD: Currently we have trigger value same for all gpctpc domains so expose it as one domain.
    //    //{"gpctpc0_sigval_pma_trigger",                      109},
    //    //{"gpctpc1_sigval_pma_trigger",                      109},
    //    {"gpctpc_sigval_pma_trigger",                      109},
    //    {"host0_sigval_pma_trigger",                        77},
    //    {"hub0_sigval_pma_trigger",                         45},
    //    {"msd0_sigval_pma_trigger",                         77},
    //    {"msd1_sigval_pma_trigger",                         77},
    //    {"pcie0_sigval_pma_trigger",                        45},
    //    {"pwr0_sigval_pma_trigger",                         77},
    //    {"sys0_sigval_pma_trigger",                         173},
    //    {"xbar0_sigval_pma_trigger",                        77},
    //    {"ltc0_sigval_pma_trigger",                         77},
    //    {"rop0_sigval_pma_trigger",                         77}
    //};

    static const NvU32 nvgk104_pma_trigger[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        {77, 45, 77, 77, 45, 77, 173, 77},
        {205, 109},
        {77, 77}
    };

    // source: <branch>\drivers\resman\kernel\inc\kepler\gk110\pm_signals.h
    //static const KeplerSignalName2Numeric nvgk110_pma_trigger[] =
    //{
    //    {"gpc0_sigval_pma_trigger",                         205},
    //    //TBD: Currently we have trigger value same for all gpctpc domains so expose it as one domain.
    //    //{"gpctpc0_sigval_pma_trigger",                      141},
    //    //{"gpctpc1_sigval_pma_trigger",                      141},
    //    {"gpctpc_sigval_pma_trigger",                      141},
    //    {"host0_sigval_pma_trigger",                        77},
    //    {"msd0_sigval_pma_trigger",                         77},
    //    {"msd1_sigval_pma_trigger",                         77},
    //    {"pcie0_sigval_pma_trigger",                        45},
    //    {"pwr0_sigval_pma_trigger",                         77},
    //    {"sys0_sigval_pma_trigger",                         205},
    //    {"xbar0_sigval_pma_trigger",                        77},
    //    {"ltc0_sigval_pma_trigger",                         77},
    //    {"rop0_sigval_pma_trigger",                         77}
    //};

    static const NvU32 nvgk110_pma_trigger[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        {77, 77, 77, 45, 77, 205, 77},
        {205, 141},
        {77, 77}
    };

    // source: <branch>\drivers\resman\kernel\inc\kepler\gk208\pm_signals.h
    //static const KeplerSignalName2Numeric nvgk208_pma_trigger[] =
    //{
    //    {"gpc0_sigval_pma_trigger",                         173},
    //    //TBD: Currently we have trigger value same for all gpctpc domains so expose it as one domain.
    //    //{"gpctpc0_sigval_pma_trigger",                      141},
    //    //{"gpctpc1_sigval_pma_trigger",                      141},
    //    {"gpctpc_sigval_pma_trigger",                      141},
    //    {"host0_sigval_pma_trigger",                        77},
    //    {"msd0_sigval_pma_trigger",                         77},
    //    {"msd1_sigval_pma_trigger",                         77},
    //    {"pcie0_sigval_pma_trigger",                        45},
    //    {"pwr0_sigval_pma_trigger",                         77},
    //    {"sys0_sigval_pma_trigger",                         173},
    //    {"xbar0_sigval_pma_trigger",                        45},
    //    {"ltc0_sigval_pma_trigger",                         77},
    //    {"rop0_sigval_pma_trigger",                         77}
    //};

    static const NvU32 nvgk208_pma_trigger[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        {77, 77, 77, 45, 77, 173, 45},
        {173, 141},
        {77, 77}
    };

#if NVCFG(GLOBAL_ARCH_KEPLER)
#if NVCFG(GLOBAL_GPU_IMPL_GK20A) || NVCFG(GLOBAL_CHIP_T124) || NVCFG(GLOBAL_CHIP_T132)
    static const NvU32 nvgk20a_pma_trigger[PM_MAX_CHIPLET_TYPES][PM_MAX_DOMAIN_PER_CHIPLET] =
    {   //acb0, mc0, sys0
        {45, 45, 173},
        //gpc0, gpctpc0
        {173, 141},
        //fbp0
        {109}
    };
#endif
#endif

    CU_TRACE_FUNCTION();

    if (chipletType >= PM_MAX_CHIPLET_TYPES || clkIdx >= PM_MAX_DOMAIN_PER_CHIPLET) {
        CU_ERROR_PRINT(("Invalid chiplet/clk values\n"));
        CU_ASSERT (0);
        return numericId;
    }

    switch(ctx->device->state.chip) {
#if NVCFG(GLOBAL_ARCH_KEPLER)
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK104:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK106:
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK107:
        signalNames = nvgk104_pma_trigger;
        break;
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110):
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110B
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110B):
#endif
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110C
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110C):
#endif
        signalNames = nvgk110_pma_trigger;
        break;
#endif

#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK200
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK208):
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK208S 
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK208S):
#endif
        signalNames = nvgk208_pma_trigger;
        break;
#endif
#if NVCFG(GLOBAL_GPU_IMPL_GK20A) || NVCFG(GLOBAL_CHIP_T124) || NVCFG(GLOBAL_CHIP_T132)
#if NVCFG(GLOBAL_GPU_IMPL_GK20A) || NVCFG(GLOBAL_CHIP_T124)
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK20A):
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_T12X + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_T124):
#endif // NVCFG(GLOBAL_GPU_IMPL_GK20A) || NVCFG(GLOBAL_CHIP_T124)
#if NVCFG(GLOBAL_CHIP_T132)
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_T13X + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_T132):
#endif // NVCFG(GLOBAL_CHIP_T132)
        signalNames = nvgk20a_pma_trigger;
        break;
#endif // NVCFG(GLOBAL_GPU_IMPL_GK20A) || NVCFG(GLOBAL_CHIP_T124) || NVCFG(GLOBAL_CHIP_T132)
#endif
    default:
        CU_ASSERT(0);
        break;
    }

    if (signalNames) {
        numericId = signalNames[chipletType][clkIdx];
    }
    else {
        CU_ASSERT(0); // Throw assert if signal names is NULL
    }

    return numericId;
}

static CUprofResult AssertEngineModeB(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *value = NULL;
    NvU32 j = 0, size = 0, pmaTriggerSignalIndex = ~0U;
    NvU32 domainRegOffset = 0, chipIdx = 0;
    CUparsedClk  *pParsedClk = NULL;
    CUkeplerEventGroup  *keplerEventGroup;

    CU_TRACE_FUNCTION();

    //For PM signals
    pParsedClk = pEventGroup->arch.keplerEventGroup->pParsedClk;
    keplerEventGroup = pEventGroup->arch.keplerEventGroup;

    CU_ASSERT(pParsedClk);
    CU_ASSERT(keplerEventGroup);

    size = keplerEventGroup->maxChiplets * sizeof(NvU32);

    offset = (NvU32*)malloc(size);
    value = (NvU32*)malloc(size);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset/value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    // assert ENGINE
    // set register NV_PERF_PMM[chipletType]_ENGINE_SEL(domain) to NV_PERF_PMM[chipletType]_[domain]_SIGVAL_PMA_TRIGGER
    // for all instances of all chipletTypes
    // like for (GPC#0 + domain GPC0) - NV_PERF_PMMGPC_ENGINE_SEL(KEPLER_CLK_DOMAIN_GPC0) = NV_PERF_PMMGPC_GPC0_SIGVAL_PMA_TRIGGER

    for (chipIdx = 0; chipIdx < keplerEventGroup->maxChiplets; chipIdx++) {
        if(keplerEventGroup->pmUnitMask & (1<<chipIdx))
        {
            domainRegOffset = keplerEventGroup->pmmAddress[chipIdx] + keplerEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
            offset[j]  = domainRegOffset + NV_PMM_ENGINE_SEL;
            // lookup the numeric value for the signal
            //TBD, check how we can put this in the domain table and get rid of resolveCoreSignalName function
            //TBD Since gpctpc0 and gpctpc1 are identical, we can safely call this function with gpctpc0 domain name only.

            if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING) {
                pmaTriggerSignalIndex = resolveTPulse(pEventGroup->pCtx, keplerEventGroup->clkIdx, pEventGroup->domain->chipletType);
            } else
            {
                pmaTriggerSignalIndex = resolveCoreSignalName(pEventGroup->pCtx, keplerEventGroup->clkIdx, pEventGroup->domain->chipletType);
            }
            CU_ASSERT(pmaTriggerSignalIndex != ~0U);
            value[j++] = pmaTriggerSignalIndex;
        }
    }

    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, j, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

EXIT:
    free (offset);
    free (value);

    return status;
}

CUprofResult StartExptModeB(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
#if 1
    NvU32 *offset = NULL, *value = NULL;
    NvU32 j = 0, size = 0;
    NvU32 domainRegOffset = 0, chipIdx = 0;
    CUkeplerEventGroup  *keplerEventGroup;

    CU_TRACE_FUNCTION();
    //For PM signals
    keplerEventGroup = pEventGroup->arch.keplerEventGroup;

    if (keplerEventGroup == NULL) return status;

    size = keplerEventGroup->maxChiplets * sizeof(NvU32);

    offset = (NvU32*)malloc(size);
    value = (NvU32*)malloc(size);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset/value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    // assert ENGINE
    // set register NV_PERF_PMM[chipletType]_ENGINE_SEL(domain) to NV_PERF_PMM[chipletType]_[domain]_SIGVAL_PMA_TRIGGER
    // for all instances of all chipletTypes
    // like for (GPC#0 + domain GPC0) - NV_PERF_PMMGPC_ENGINE_SEL(KEPLER_CLK_DOMAIN_GPC0) = NV_PERF_PMMGPC_GPC0_SIGVAL_PMA_TRIGGER

    for (chipIdx = 0; chipIdx < keplerEventGroup->maxChiplets; chipIdx++) {
        if(keplerEventGroup->pmUnitMask & (1<<chipIdx))
        {
            domainRegOffset = keplerEventGroup->pmmAddress[chipIdx] + keplerEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
            offset[j]  = domainRegOffset + NV_PERF_PMM_STARTEXPERIMENT;
            value[j++] = NV_PERF_PMM_STARTEXPERIMENT_START_DOIT;
        }
    }

    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, j, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

EXIT:
    free (offset);
    free (value);
#endif
    return status;
}

static CUprofResult startStreaming(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *value = NULL;
    NvU32 j = 0, size = 0;

    CU_TRACE_FUNCTION();

    size = sizeof(NvU32) * 16;

    //If we require to setup only one register here, remove malloc
    offset = (NvU32*)malloc(size);
    value = (NvU32*)calloc(size, 1);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset/value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    // assert ENGINE
    // set register NV_PERF_PMM[chipletType]_ENGINE_SEL(domain) to NV_PERF_PMM[chipletType]_[domain]_SIGVAL_PMA_TRIGGER
    // for all instances of all chipletTypes
    // like for (GPC#0 + domain GPC0) - NV_PERF_PMMGPC_ENGINE_SEL(KEPLER_CLK_DOMAIN_GPC0) = NV_PERF_PMMGPC_GPC0_SIGVAL_PMA_TRIGGER
    if (pEventGroup->pCtx->pmNew->cpuAddrStreamingBuffer) {
        memset(pEventGroup->pCtx->pmNew->cpuAddrStreamingBuffer, 0xFF, pEventGroup->pCtx->pmNew->sizeStreamingBuffer);
        offset[j]  = NV_PERF_PMASYS_OUTBASE;
        value[j++] = pEventGroup->pCtx->pmNew->gpuAddrStreamingBuffer & 0xFFFFFFFF;

        offset[j]  = NV_PERF_PMASYS_OUTBASEUPPER;
        value[j++] = (pEventGroup->pCtx->pmNew->gpuAddrStreamingBuffer >> 32) & 0xff;

        offset[j]  = NV_PERF_PMASYS_OUTSIZE;
        value[j++] = (NvU32)pEventGroup->pCtx->pmNew->sizeStreamingBuffer;

        offset[j]  = NV_PERF_PMASYS_CONTROL;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_CONTROL_STREAM_ENABLE, NV_PERF_PMASYS_CONTROL_STREAM);
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_CONTROL_PMACTXSW_MODE_DISABLE, NV_PERF_PMASYS_CONTROL_PMACTXSW_MODE);
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_CONTROL_MEMBUF_CLEAR_STATUS_DOIT, NV_PERF_PMASYS_CONTROL_MEMBUF_CLEAR_STATUS);
        j++;
#if 0
        offset[j]  = NV_PERF_PMASYS_MEM_BLOCK;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_MEM_BLOCK_VALID_TRUE, NV_PERF_PMASYS_MEM_BLOCK_VALID);
        j++;

        offset[j]  = NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
        j++;
        // Set HOLD_* to TRUE
        offset[j]  = NV_PERF_PMMGPCROUTER_GLOBAL_CNTRL;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
        j++;

        offset[j]  = NV_PERF_PMMFBPROUTER_GLOBAL_CNTRL;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
        j++;
        //Then set HOLD_* to FALSE
        offset[j]  = NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_FALSE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_FALSE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
        j++;

        offset[j]  = NV_PERF_PMMGPCROUTER_GLOBAL_CNTRL;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_FALSE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_FALSE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
        j++;

        offset[j]  = NV_PERF_PMMFBPROUTER_GLOBAL_CNTRL;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_FALSE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_FALSE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
        j++;
#endif

        //Remember to add following so that we don't miss any records
        //If MEM_BYTES = sysmem(NV_PERF_PMA_MEM_BYTES_ADDR), then there are no records
        //  in flight between PMA and system memory.

        //NvU32 uNumBytes = 0;
        //ReadRegister32(NV_PERF_PMASYS_MEM_BYTES, &uNumBytes);
        //WriteRegister32(NV_PERF_PMASYS_MEM_BUMP, 0x00000000, uNumBytes);

        if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, j, offset, value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }

        j = 0;
        offset[j++] = NV_PERF_PMASYS_MEM_BYTES;

        if (CUDA_SUCCESS != PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, j, offset, value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }
        //Write value read from mem_bytes to mem_bump
        j = 0;
        offset[j] = NV_PERF_PMASYS_MEM_BUMP;

        if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, j, offset, value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }
    }

EXIT:
    free (offset);
    free (value);
    return status;
}

static CUprofResult stopStreaming(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *value = NULL;
    NvU32 j = 0, size = 0;
    NvU32 domainRegOffset = 0, chipIdx = 0;
    CUkeplerEventGroup  *keplerEventGroup;

    CU_TRACE_FUNCTION();

    size = sizeof(NvU32) * 4;

    //If we require to setup only one register here, remove malloc
    offset = (NvU32*)malloc(size);
    value = (NvU32*)malloc(size);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset/value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    // assert ENGINE
    // set register NV_PERF_PMM[chipletType]_ENGINE_SEL(domain) to NV_PERF_PMM[chipletType]_[domain]_SIGVAL_PMA_TRIGGER
    // for all instances of all chipletTypes
    // like for (GPC#0 + domain GPC0) - NV_PERF_PMMGPC_ENGINE_SEL(KEPLER_CLK_DOMAIN_GPC0) = NV_PERF_PMMGPC_GPC0_SIGVAL_PMA_TRIGGER

    offset[j]  = NV_PERF_PMASYS_CONTROL;
    value[j] = 0;
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_CONTROL_STREAM_DISABLE, NV_PERF_PMASYS_CONTROL_STREAM);
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_CONTROL_PMACTXSW_MODE_DISABLE, NV_PERF_PMASYS_CONTROL_PMACTXSW_MODE);
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_CONTROL_MEMBUF_CLEAR_STATUS_DOIT, NV_PERF_PMASYS_CONTROL_MEMBUF_CLEAR_STATUS);
    j++;
#if 0
    offset[j]  = NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL;
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
    j++;
    // Set HOLD_* to TRUE
    offset[j]  = NV_PERF_PMMGPCROUTER_GLOBAL_CNTRL;
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
    j++;

    offset[j]  = NV_PERF_PMMFBPROUTER_GLOBAL_CNTRL;
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
    j++;
#endif
    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, j, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

    keplerEventGroup = pEventGroup->arch.keplerEventGroup;

    if (!keplerEventGroup) {
        status = CUPROF_ERROR_UNKNOWN; //TBD check if we can return this error.
        goto EXIT;
    }

    for (chipIdx = 0; chipIdx < keplerEventGroup->maxChiplets; chipIdx++) {
        if(keplerEventGroup->pmUnitMask & (1<<chipIdx))
        {
            if (keplerEventGroup->pParsedClk && pEventGroup->totalCounters) {
                domainRegOffset = keplerEventGroup->pmmAddress[chipIdx] + keplerEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
                offset[0]  = domainRegOffset + NV_PMM_CONTROL;
                value[0] = (NV_PMM_CONTROL_MODE_DISABLE        << NV_PMM_CONTROL_MODE__SHIFT);

                if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, 1, offset, value, 0)) {
                    status = CUPROF_ERROR_HARDWARE;
                    goto EXIT;
                }
            }
        }
    }

    for (chipIdx = 0; chipIdx < keplerEventGroup->maxChiplets; chipIdx++) {
        if(keplerEventGroup->pmUnitMask & (1<<chipIdx))
        {
            if (keplerEventGroup->pParsedClk && pEventGroup->totalCounters) {
                domainRegOffset = keplerEventGroup->pmmAddress[chipIdx] + keplerEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
                offset[0]  = domainRegOffset + NV_PMM_ENGINESTATUS;
READ_STATUS:
                if (CUDA_SUCCESS != PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, 1, offset, value, 0)) {
                    status = CUPROF_ERROR_HARDWARE;
                    goto EXIT;
                }
                if ((value[0] & 0x7) == NV_PERF_PMMSYS_ENGINESTATUS_STATUS_ACTIVE) {
                    printf("Engine not empty\n");
                    goto READ_STATUS;
                } else {
                    if ((value[0] & 0x7) == NV_PERF_PMMSYS_ENGINESTATUS_STATUS_FAULTED) {
                        CU_ERROR_PRINT(("PMM Engine status faulted\n"));
                    }
                    continue;
                }
            }
        }
    }

    //do {
        offset[0]  = NV_PERF_PMMSYSROUTER_ENGINESTATUS;
        offset[1]  = NV_PERF_PMMGPCROUTER_ENGINESTATUS;
        offset[2]  = NV_PERF_PMMFBPROUTER_ENGINESTATUS;
        value[0] = value[1] = value[2] = 0;

        if (CUDA_SUCCESS != PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, 3, offset, value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }
        /*
        if (((value[0] & 0x7) == 0) && ((value[1] & 0x7) == 0) && ((value[2] & 0x7) == 0)) {
            break;
        }
        */
        //printf("Engine status %d %d %d\n", (value[0] & 0x7), (value[1] & 0x7), (value[2] & 0x7));

        if (((value[0] & 0x7) == NV_PERF_PMMSYSROUTER_ENGINESTATUS_STATUS_FAULTED) &&
            ((value[1] & 0x7) == NV_PERF_PMMGPCROUTER_ENGINESTATUS_STATUS_FAULTED) &&
            ((value[2] & 0x7) == NV_PERF_PMMFBPROUTER_ENGINESTATUS_STATUS_FAULTED)) {
            CU_ERROR_PRINT(("PMM Engine status faulted\n"));
        }

        //printf("Reading status again for routers\n");
    //} while(1);

    offset[0]  = NV_PERF_PMASYS_ENGINESTATUS;
    value[0] = 0;

    if (CUDA_SUCCESS != PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, 1, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

    if ((value[0] & 0x7) == NV_PERF_PMASYS_ENGINESTATUS_STATUS_FAULTED) {
        printf("PMA engine status faulted.\n");
        CU_ASSERT(0);
    }

    if ((value[0] & 0x7) == NV_PERF_PMASYS_ENGINESTATUS_STATUS_FAULTED) {
        printf("PMA engine succesfully stopped.\n");
    }

EXIT:
    free (offset);
    free (value);
    return status;
}

CUprofResult keplerPerfmonEventGroupResetAllEvents(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);
    CU_ASSERT(pEventGroup->pCtx);


    switch(pEventGroup->domain->eventCollectionMethod)
    {
    case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
        // if event group is enabled, trigger the PM  Otherwise it would have been
        // done in disable event group call
        if (pEventGroup->isEnabled) {
            //status = AssertEngineModeB(pEventGroup);
            status = StartExptModeB(pEventGroup);
        }
        break;

    case CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
        // configure PM target and SM internal registers
        if (pEventGroup->isEnabled) {
            status = (CUprofResult)resetPMSMInternal(pEventGroup);
        }
        break;

    default:
        break;
    }

    // now reset all values for the event group
    cuosMemset(pEventGroup->values, 0, sizeof(NvU64) * pEventGroup->totalCounters
        * pEventGroup->instanceCountAvail);

    return status;
}

static NV_INLINE NvBool keplerIsPpaSoftwareCounterDomain(CUeventDomainID domainId, NvU64 arch) {
    switch(arch){
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK104:
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK106:
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK107:
            {
                if((domainId == KEPLER_SW_DOMAIN_GK104_PPA_NOPTRIG_FLOPS) ||
                    (domainId == KEPLER_SW_DOMAIN_GK104_PPA_NOPTRIG_TRANSACTIONS) ||
                    (domainId == KEPLER_SW_DOMAIN_GK104_PPA_NOPTRIG_INSTR_CLASS) ||
                    (domainId == KEPLER_SW_DOMAIN_GK104_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS) ||
                    (domainId == KEPLER_SW_DOMAIN_GK104_PPA_NOPTRIG_SLD_SST) ||
                    (domainId == KEPLER_SW_DOMAIN_GK104_PPA_NOPTRIG_UNIQUE_GLD_GST)) {
                    return NV_TRUE;
                }
            }
            break;
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110:
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110B
        case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110B):
#endif
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110C
        case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110C):
#endif
            {
                if((domainId == KEPLER_SW_DOMAIN_GK110_PPA_NOPTRIG_FLOPS) ||
                     (domainId == KEPLER_SW_DOMAIN_GK110_PPA_NOPTRIG_TRANSACTIONS) ||
                    (domainId == KEPLER_SW_DOMAIN_GK110_PPA_NOPTRIG_INSTR_CLASS) ||
                    (domainId == KEPLER_SW_DOMAIN_GK110_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS) ||
                    (domainId == KEPLER_SW_DOMAIN_GK110_PPA_NOPTRIG_SLD_SST) ||
                    (domainId == KEPLER_SW_DOMAIN_GK110_PPA_NOPTRIG_UNIQUE_GLD_GST)) {
                    return NV_TRUE;
                }
            }
            break;
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK208:
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK208S
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK208S:
#endif
            {
                if((domainId == KEPLER_SW_DOMAIN_GK208_PPA_NOPTRIG_FLOPS) ||
                     (domainId == KEPLER_SW_DOMAIN_GK208_PPA_NOPTRIG_TRANSACTIONS) ||
                    (domainId == KEPLER_SW_DOMAIN_GK208_PPA_NOPTRIG_INSTR_CLASS) ||
                    (domainId == KEPLER_SW_DOMAIN_GK208_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS) ||
                    (domainId == KEPLER_SW_DOMAIN_GK110_PPA_NOPTRIG_SLD_SST) ||
                    (domainId == KEPLER_SW_DOMAIN_GK110_PPA_NOPTRIG_UNIQUE_GLD_GST)) {
                    return NV_TRUE;
                }
            }
            break;
#if NVCFG(GLOBAL_GPU_IMPL_GK20A) || NVCFG(GLOBAL_CHIP_T124)
        case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK20A):
        case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_T12X + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_T124):
#endif // NVCFG(GLOBAL_GPU_IMPL_GK20A) || NVCFG(GLOBAL_CHIP_T124)
#if NVCFG(GLOBAL_CHIP_T132)
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_T13X + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_T132:
#endif // NVCFG(GLOBAL_CHIP_T132)
            {
                if((domainId == KEPLER_SW_DOMAIN_GK208_PPA_NOPTRIG_FLOPS) ||
                    (domainId == KEPLER_SW_DOMAIN_GK20A_PPA_NOPTRIG_TRANSACTIONS) ||
                    (domainId == KEPLER_SW_DOMAIN_GK20A_PPA_NOPTRIG_INSTR_CLASS) ||
                    (domainId == KEPLER_SW_DOMAIN_GK20A_PPA_NOPTRIG_TRANSACTIONS) ||
                    (domainId == KEPLER_SW_DOMAIN_GK20A_PPA_NOPTRIG_INSTR_CLASS) ||
                    (domainId == KEPLER_SW_DOMAIN_GK20A_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS) ||
                    (domainId == KEPLER_SW_DOMAIN_GK110_PPA_NOPTRIG_SLD_SST) ||
                    (domainId == KEPLER_SW_DOMAIN_GK110_PPA_NOPTRIG_UNIQUE_GLD_GST)) {
                    return NV_TRUE;
                }
            }
            break;
        default:
            return NV_FALSE;
    }
    return NV_FALSE;
}
CUprofResult keplerPerfmonDomainCheckCompatible(CUctx *ctx,
                                               CUeventDomainID domainId1,
                                               CUeventDomainID domainId2,
                                               NvBool *bCompatible) {
    CUprofResult status = CUPROF_SUCCESS;
    CU_TRACE_FUNCTION();

    *bCompatible = NV_TRUE;

    //The ppaSwCounter domains are not compatible with each other:
    if (keplerIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip) &&
        keplerIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip)) {
        if(domainId1 == domainId2) {
            *bCompatible = NV_TRUE;
        }
        else {
            *bCompatible = NV_FALSE;
        }
        return status;
    }
    // Bug 874703: Mix of signals from SM domain + GPCTPC domain is not working properly
    // Hence updating the DomainCheckCompatible function to avoid profiling these signals together.
    switch(ctx->device->state.chip){
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK104:
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK106:
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK107:
            {
                if (((domainId1 == KEPLER_CLK_DOMAIN_GK104_GPCTPC) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK104_GPC0) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK104_SM0) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK104_LTC0) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK104_HUB0) ||
                     (keplerIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip))) &&
                     ((domainId2 == KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST) ||
                     (domainId2 == KEPLER_SW_COUNTERS_DOMAIN_GK104_NOPTRIG))) {
                    *bCompatible = NV_FALSE;
                    return status;
                }

                if (((domainId2 == KEPLER_CLK_DOMAIN_GK104_GPCTPC) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK104_GPC0) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK104_SM0) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK104_LTC0) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK104_HUB0) ||
                     (keplerIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip))) &&
                     ((domainId1 == KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST) ||
                     (domainId1 == KEPLER_SW_COUNTERS_DOMAIN_GK104_NOPTRIG))) {
                    *bCompatible = NV_FALSE;
                    return status;
                }

                if (((domainId1 == KEPLER_CLK_DOMAIN_GK104_GPCTPC) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK104_GPC0) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK104_SM0) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK104_LTC0) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK104_HUB0)) &&
                     ((keplerIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip)))) {
                    *bCompatible = NV_FALSE;
                    return status;
                }

                if (((domainId2 == KEPLER_CLK_DOMAIN_GK104_GPCTPC) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK104_GPC0) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK104_SM0) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK104_LTC0) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK104_HUB0)) &&
                     ((keplerIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip)))) {
                    *bCompatible = NV_FALSE;
                    return status;
                }

                if (((KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST == domainId2) &&
                    (KEPLER_SW_COUNTERS_DOMAIN_GK104_NOPTRIG == domainId1)) ||
                    ((KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST == domainId1) &&
                    (KEPLER_SW_COUNTERS_DOMAIN_GK104_NOPTRIG == domainId2))) {
                    *bCompatible = NV_FALSE;
                    return status;
                }
            }
            break;
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110:
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110B
        case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110B):
#endif
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110C
        case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110C):
#endif
            {
                if (((domainId1 == KEPLER_CLK_DOMAIN_GK110_GPCTPC) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK110_GPC0) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK110_SM0) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK110_LTC0) ||
                     (keplerIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip))) &&
                     ((domainId2 == KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST) ||
                     (domainId2 == KEPLER_SW_COUNTERS_DOMAIN_GK110_NOPTRIG))) {
                    *bCompatible = NV_FALSE;
                    return status;
                }

                if (((domainId2 == KEPLER_CLK_DOMAIN_GK110_GPCTPC) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK110_GPC0) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK110_SM0) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK110_LTC0) ||
                     (keplerIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip))) &&
                     ((domainId1 == KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST) ||
                     (domainId1 == KEPLER_SW_COUNTERS_DOMAIN_GK110_NOPTRIG))) {
                    *bCompatible = NV_FALSE;
                    return status;
                }

                if (((domainId1 == KEPLER_CLK_DOMAIN_GK110_GPCTPC) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK110_GPC0) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK110_SM0) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK110_LTC0)) &&
                     ((keplerIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip)))) {
                    *bCompatible = NV_FALSE;
                    return status;
                }

                if (((domainId2 == KEPLER_CLK_DOMAIN_GK110_GPCTPC) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK110_GPC0) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK110_SM0) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK110_LTC0)) &&
                     ((keplerIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip)))) {
                    *bCompatible = NV_FALSE;
                    return status;
                }

                if (((KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST == domainId2) &&
                    (KEPLER_SW_COUNTERS_DOMAIN_GK110_NOPTRIG == domainId1)) ||
                    ((KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST == domainId1) &&
                    (KEPLER_SW_COUNTERS_DOMAIN_GK110_NOPTRIG == domainId2))) {
                    *bCompatible = NV_FALSE;
                    return status;
                }
            }
            break;
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK208:
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK208S
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK208S:
#endif
            {
                if (((domainId1 == KEPLER_CLK_DOMAIN_GK208_GPCTPC) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK208_SM0) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK208_LTC0) ||
                     (keplerIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip))) &&
                     ((domainId2 == KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST) ||
                     (domainId2 == KEPLER_SW_COUNTERS_DOMAIN_GK208_NOPTRIG))) {
                    *bCompatible = NV_FALSE;
                    return status;
                }

                if (((domainId2 == KEPLER_CLK_DOMAIN_GK208_GPCTPC) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK208_SM0) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK208_LTC0) ||
                     (keplerIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip))) &&
                     ((domainId1 == KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST) ||
                     (domainId1 == KEPLER_SW_COUNTERS_DOMAIN_GK208_NOPTRIG))) {
                    *bCompatible = NV_FALSE;
                    return status;
                }

                if (((domainId1 == KEPLER_CLK_DOMAIN_GK208_GPCTPC) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK208_SM0) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK208_LTC0)) &&
                     ((keplerIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip)))) {
                    *bCompatible = NV_FALSE;
                    return status;
                }

                if (((domainId2 == KEPLER_CLK_DOMAIN_GK208_GPCTPC) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK208_SM0) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK208_LTC0)) &&
                     ((keplerIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip)))) {
                    *bCompatible = NV_FALSE;
                    return status;
                }

                if (((KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST == domainId2) &&
                    (KEPLER_SW_COUNTERS_DOMAIN_GK208_NOPTRIG == domainId1)) ||
                    ((KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST == domainId1) &&
                    (KEPLER_SW_COUNTERS_DOMAIN_GK208_NOPTRIG == domainId2))) {
                    *bCompatible = NV_FALSE;
                    return status;
                }
            }
            break;
#if NVCFG(GLOBAL_GPU_IMPL_GK20A) || NVCFG(GLOBAL_CHIP_T124)
        case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK20A):
        case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_T12X + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_T124):
#endif // NVCFG(GLOBAL_GPU_IMPL_GK20A) || NVCFG(GLOBAL_CHIP_T124)
#if NVCFG(GLOBAL_CHIP_T132)
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_T13X + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_T132:
#endif // NVCFG(GLOBAL_CHIP_T132)
            {
                if (((domainId1 == KEPLER_CLK_DOMAIN_GK20A_GPCTPC) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK208_SM0) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK20A_FBP0)  ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK20A_MC0)  ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK20A_SYS0)  ||
                     (keplerIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip))) &&
                     ((domainId2 == KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST) ||
                     (domainId2 == KEPLER_SW_COUNTERS_DOMAIN_GK208_NOPTRIG))) {
                    *bCompatible = NV_FALSE;
                    return status;
                }

                if (((domainId2 == KEPLER_CLK_DOMAIN_GK20A_GPCTPC) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK208_SM0) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK20A_FBP0)  ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK20A_MC0)   ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK20A_SYS0) ||
                     (keplerIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip))) &&
                     ((domainId1 == KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST) ||
                     (domainId1 == KEPLER_SW_COUNTERS_DOMAIN_GK208_NOPTRIG))) {
                    *bCompatible = NV_FALSE;
                    return status;
                }

                if (((domainId1 == KEPLER_CLK_DOMAIN_GK20A_GPCTPC) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK208_SM0) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK20A_FBP0) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK20A_MC0) ||
                     (domainId1 == KEPLER_CLK_DOMAIN_GK20A_SYS0)) &&
                     ((keplerIsPpaSoftwareCounterDomain(domainId2, ctx->device->state.chip)))) {
                    *bCompatible = NV_FALSE;
                    return status;
                }

                if (((domainId2 == KEPLER_CLK_DOMAIN_GK20A_GPCTPC) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK208_SM0) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK20A_FBP0) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK20A_MC0) ||
                     (domainId2 == KEPLER_CLK_DOMAIN_GK20A_SYS0)) &&
                     ((keplerIsPpaSoftwareCounterDomain(domainId1, ctx->device->state.chip)))) {
                    *bCompatible = NV_FALSE;
                    return status;
                }

                if (((KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST == domainId2) &&
                    (KEPLER_SW_COUNTERS_DOMAIN_GK208_NOPTRIG == domainId1)) ||
                    ((KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST == domainId1) &&
                    (KEPLER_SW_COUNTERS_DOMAIN_GK208_NOPTRIG == domainId2))) {
                    *bCompatible = NV_FALSE;
                    return status;
                }
            }
            break;
        default:
            CU_ASSERT(0);
            *bCompatible = NV_FALSE;  // Default case should never be encountered
            break;
    }
    return status;
}

// Function to check if domain is already enabled for profiling
static CUprofResult keplerDomainCompatible(CUctx *ctx, CUeventDomainID domainId, NvBool *bCompatible) {
    CUprofResult status = CUPROF_SUCCESS;
    CUeventGroup *currEg = NULL;
    void *eventBase = NULL;
    NvU32 i = 0;

    CU_TRACE_FUNCTION();

    *bCompatible = NV_TRUE;

    currEg = (CUeventGroup*)listGetNext(ctx->pmNew->egList, &eventBase);
    for (i = 0; (i < ctx->pmNew->totalEventGroups) && currEg; i++, currEg = (CUeventGroup*)listGetNext(NULL, &eventBase)) {

        if (currEg->isEnabled) {
            //cannot enable 2 eventgroups from same domain simultaneously
            if (currEg->domainId == domainId) {
                *bCompatible = NV_FALSE;
            }
            else {
                keplerPerfmonDomainCheckCompatible(ctx, domainId, currEg->domainId, bCompatible);
            }
            if (*bCompatible == NV_FALSE) {
                break;
            }
        }
    }

    return status;
}

CUprofResult keplerPerfmonEventGroupEnable(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    CUctx *ctx = NULL;
    NvBool bCompatible = NV_TRUE;
    CUkeplerEventGroup  *keplerEventGroup;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);
    //CU_ASSERT(pEventGroup->domainId < MAX_DOMAINS);

    ctx = pEventGroup->pCtx;
    // make launch blocking
    //ctx->launchBlocking = 1;

    status = keplerDomainCompatible(ctx, pEventGroup->domainId, &bCompatible);
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("Failed to check domain enable/disable status\n"));
        return status;
    }
    if (bCompatible == NV_FALSE) {
        CU_ERROR_PRINT(("Profiler allows to monitor only one event group from any domain\n"));
        return CUPROF_ERROR_NOT_COMPATIBLE;
    }

    /********************************************************************************
       Set the PM CtxSw bit here as we want this feature for SM_PM_CTRL registers
           as well which are used in SMPC signal profiling:
       Currently, the feature is only supported on GK110
    ********************************************************************************/
    status = perfmonSetupPMCtxswMode(ctx, NV_TRUE);
    if (CUPROF_SUCCESS != status) {
        CU_ERROR_PRINT(("Failed to set the PM Ctxsw bit\n"));
        goto Error;
    }

    // Check if the PM CtxSw bit is enabled and assign the proper regOp type:
    pEventGroup->pCtx->pmNew->regOpType = ctx->pmNew->isPmCtxswModeEnabled ? CU_PRI_REG_CONTEXT : CU_PRI_REG_GLOBAL;

    switch(pEventGroup->domain->eventCollectionMethod)
    {
    case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
        keplerEventGroup = pEventGroup->arch.keplerEventGroup;
        CU_ASSERT(keplerEventGroup);

        /************************************************************************
           Reserve the perfmon if CUPTI have not taken care of it already. This
           extra perfmon reserve call is required for supporting HWPM counter
           profiling for toolkits < R5.5. The flag isPerfmonReserved is modified
           only while reserving perfmon via CUPTI. This call will ideally not be
           executed for Toolkits > R5.0 (Bug 1408976)
        *************************************************************************/
        if (!ctx->device->state.profilerState.isPerfmonReservedOutsideHal) {
            status = perfmonControl(ctx, NV_TRUE, NV_TRUE);
            if (status != CUPROF_SUCCESS) {
                CU_ERROR_PRINT(("Failed to control PM HW\n"));
                return status;
            }
        }

        // configure PM target and mode B settings
        status = setupPMTarget(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            goto Error;
        }

        if (pEventGroup->configChanged) {
            status = setupPMRegistersModeCommon(pEventGroup,
                &pEventGroup->pCtx->pmNew->perfmonTriggerRefCount);
            if (CUPROF_SUCCESS != status) {
                goto Error;
            }

            status = setupPMRegistersModeB(pEventGroup);
            if (CUPROF_SUCCESS != status) {
                goto Error;
            }
        }
#ifndef BUG_1259185_FIXED
        if (ctx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING) {
            setupStreamingResources(ctx);
        }
#endif
        status = setPMEnableReg(pEventGroup, NV_TRUE);
        if (CUPROF_SUCCESS != status) {
            goto Error;
        }

        status = AssertEngineModeB(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            //Release Mode B in case Assert fail.
            PMReleaseModeB(pEventGroup);
            goto Error;
        }

        if ((ctx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS)
            ||
            (ctx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING)
            ) {
            status = StartExptModeB(pEventGroup);
            if (CUPROF_SUCCESS != status) {
                goto Error;
            }
        }

        if (ctx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING) {
            status = startStreaming(pEventGroup);
            if (CUPROF_SUCCESS != status) {
                goto Error;
            }
        }
        break;

    case CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:

        // configure PM target and SM internal registers
        status = setupPMTarget(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            goto Error;
        }

        if (pEventGroup->configChanged) {
            status = (CUprofResult)SetupPMRegistersSMInternal(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            goto Error;
        }
        }

        status = (CUprofResult)setPMEnableRegSM(pEventGroup, NV_TRUE);
        if (CUPROF_SUCCESS != status) {
            goto Error;
        }

        if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS) {
            keplerPerfmonStartCounters(NULL, pEventGroup);
            //reset counters only in case of continuous mode. In kernel mode they get reset
            //by pushbuffer method
            status = (CUprofResult)resetPMSMInternal(pEventGroup);
            if (CUPROF_SUCCESS != status) {
                goto Error;
            }
        }

        break;

    default:
        //s/w counters do nothing
        break;
    }


    // set enable flags
    pEventGroup->isEnabled = 1;
    setDomainEventGroup(ctx->pmNew->domainEventGroupEnabled, pEventGroup->domainId, 1);

    // reset all counters
    cuosMemset(pEventGroup->values, 0, sizeof(NvU64) * pEventGroup->totalCounters
        * pEventGroup->instanceCountAvail);

    return CUPROF_SUCCESS;

Error:
#ifndef BUG_1259185_FIXED
    cleanupStreamingResources(ctx);
#endif
    return status;
}

static CUprofResult logPMCountersModeBStreamingMode(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *values = NULL, *currPosInValueArray = NULL;
    NvU32 size = 0;
    NvU32 chipIdx = 0, i = 0, j = 0;
    CUkeplerEventGroup  *keplerEventGroup;
    CUparsedClk *pTempParsedClk = NULL;
    NvU32 memHeadPtr = 0, totalBytes = 0; //memBytes = 0
    NvU32 chipletType, clkIdx;
    CUprofStreamingRecord *recPtr;
#ifdef PRINT_EVENT_SAMPLING_RECORDS
    FILE *tempfp;
    char filename[CUOS_ENV_VAR_LENGTH+20];
#endif
    CU_TRACE_FUNCTION();

    keplerEventGroup = pEventGroup->arch.keplerEventGroup;
    CU_ASSERT(keplerEventGroup);

    //elapsed_clocks is always read
    size  = sizeof(NvU32) * (CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS + CU_PROF_ELAPSED_CLOCK_SLOT);

    offset = (NvU32*)malloc(size);
    values = (NvU32*)malloc(size);
    if (!offset || !values) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    offset[j]  = NV_PERF_PMASYS_MEM_BYTES;
    values[j] = 0;
    j++;
    offset[j]  = NV_PERF_PMASYS_MEM_HEAD;
    values[j] = 0;
    j++;

    // read counter values for all HW counters then populate the values in eventgroup depending on the mode
    if (CUDA_SUCCESS != PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, j, offset, values, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

    //memBytes = GETVAL(values[0], NV_PERF_PMASYS_MEM_BYTES_NUMBYTES);
    //memHeadPtr = GETVAL(values[1], NV_PERF_PMASYS_MEM_HEAD_PTR);
    memHeadPtr = values[1];

    //Just a check, can use one of memBytes and TotalBytes
    //TBD check if the buffer is circular
    totalBytes = (NvU32)(memHeadPtr - pEventGroup->pCtx->pmNew->gpuAddrStreamingBuffer);
    //printf("membytes = %d, totalBytes = %d\n", memBytes, totalBytes);
    //CU_ASSERT(totalBytes == memBytes);

    pTempParsedClk = keplerEventGroup->pParsedClk;
    if (!pTempParsedClk) {
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    recPtr = (CUprofStreamingRecord *)pEventGroup->pCtx->pmNew->cpuAddrStreamingBuffer;
    if (!recPtr) goto EXIT;

    cuosMemset(pTempParsedClk->values, 0, sizeof(NvU32) * keplerEventGroup->maxChiplets * pEventGroup->totalCounters);

#ifdef PRINT_EVENT_SAMPLING_RECORDS
    strcpy(filename, pEventGroup->pCtx->profiler->logfile);
    strcat(filename, "_event_samples");
    tempfp = fopen(filename, "a");
    if (NULL == tempfp) {
        CU_DEBUG_PRINT(("Failed to open cuda sampling log: %s\n", filename));
        //return CUDA_ERROR_FILE_NOT_FOUND;
    }
#endif

    while(totalBytes) {
        chipletType = recPtr->perfmonId & 3;
        if(PM_CHIPLET_TYPE_SYS == chipletType) {
            clkIdx = (recPtr->perfmonId & 0x1c) >> 2;
            chipIdx = (recPtr->perfmonId & 0xE0) >> 5;
        } else {
            clkIdx = (recPtr->perfmonId & 0xc) >> 2;
            chipIdx = (recPtr->perfmonId & 0xF0) >> 4;
        }

        if (clkIdx != keplerEventGroup->clkIdx) {
            recPtr ++;
            totalBytes -= sizeof(CUprofStreamingRecord);
            continue;
        }

#ifdef PRINT_EVENT_SAMPLING_RECORDS
        if(tempfp && (recPtr->eventCnt || recPtr->trigger0Cnt || recPtr->trigger1Cnt || recPtr->sampleCnt)) {
            fprintf(tempfp, "0x%lx,0x%x,0x%x,%lu,%lu,%lu,%lu\n", (long unsigned int)(((uint64_t)recPtr->timestamp39_32<<32) | recPtr->timestamp00_31), recPtr->perfmonId, recPtr->smplCnt_ds_sz, (long unsigned int)recPtr->eventCnt, (long unsigned int)recPtr->trigger0Cnt, (long unsigned int)recPtr->trigger1Cnt, (long unsigned int)recPtr->sampleCnt);
        }
#endif
        values[NV_PMM_TRIG0_BIT_POS] = recPtr->trigger0Cnt;
        values[NV_PMM_TRIG1_BIT_POS] = recPtr->trigger1Cnt;
        values[NV_PMM_EVENT_BIT_POS] = recPtr->eventCnt;
        values[NV_PMM_SAMPLE_BIT_POS] = recPtr->sampleCnt;
        //Let's write timestamp in elapsed_clocks for now
        values[NV_PMM_ELAPSED_CLOCKS_BIT_POS] = recPtr->timestamp00_31;

        currPosInValueArray = (pTempParsedClk->values + (pEventGroup->totalCounters * chipIdx));
        for(i=0; i<pEventGroup->totalCounters; i++)
        {
            if (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_VIVEK) {
                if(pTempParsedClk->eventspec[i] == NV_ELAPSED_CLOCKS) {
                    currPosInValueArray[i] += values[NV_PMM_ELAPSED_CLOCKS_BIT_POS];
                } else {
                    NvU32 partNo = 0, spec = 0, width = 0, lshCount = 0, partWidth = 0, tempPartNumber = 0;
                    //currPosInValueArray[i] = 0;
                    tempPartNumber = pTempParsedClk->partNumber[i];
                    width = pTempParsedClk->width[i];
                    while(tempPartNumber) {
                        spec = (tempPartNumber & 0xff);
                        spec--;
                        switch(spec) {
                            case NV_PMM_SAMPLE_BIT_POS : partWidth = (width >= 3) ? 3 : width; break;
                            case NV_PMM_TRIG0_BIT_POS  : partWidth = (width >= 3) ? 3 : width; break;
                            case NV_PMM_EVENT_BIT_POS  : partWidth = (width >= 4) ? 4 : width; break;
                            case NV_PMM_TRIG1_BIT_POS  : partWidth = (width >= 4) ? 4 : width; break;
                        }
                        //change values in parsedClk to 64 bit.
                        currPosInValueArray[i] +=  (NvU32)(((NvU64)(values[spec]) << lshCount));
                        lshCount += partWidth;
                        width -= partWidth;
                        partNo++;
                        tempPartNumber >>= 8;
                    }
                    //At the end of while loop the width has to be 0
                    CU_ASSERT(width == 0);
                }
            } else {
                switch(pTempParsedClk->eventspec[i]) {
                case (NV_PMM_TRIG1 | NV_PMM_EVENT):
                    if ((pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_EVENT4) || (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_EVENT6)) {
                        currPosInValueArray[i] += values[NV_PMM_EVENT_BIT_POS];
                    }
                    else if ((pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_TRIG4) || (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_TRIG6)) {
                        if ((pTempParsedClk->width[i] == 2) && (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_TRIG6)) {
                            //This case should occur rarely as we will give preference to vivek mode
                            currPosInValueArray[i] += values[NV_PMM_EVENT_BIT_POS];
                        } else {
                            currPosInValueArray[i] += values[NV_PMM_TRIG1_BIT_POS];
                        }
                    }
                    break;
                case NV_PMM_TRIG0:
                    currPosInValueArray[i] += values[NV_PMM_TRIG0_BIT_POS];
                    break;
                case NV_PMM_TRIG1:
                    currPosInValueArray[i] += values[NV_PMM_TRIG1_BIT_POS];
                    break;
                case NV_PMM_EVENT:
                    currPosInValueArray[i] += values[NV_PMM_EVENT_BIT_POS];
                    break;
                case NV_PMM_SAMPLE:
                    currPosInValueArray[i] += values[NV_PMM_SAMPLE_BIT_POS];
                    break;
                case NV_ELAPSED_CLOCKS:
                    currPosInValueArray[i] += values[NV_PMM_ELAPSED_CLOCKS_BIT_POS];
                    break;
                default:
                    CU_ERROR_PRINT(("Not a valid trigger type.\n"));
                    break;
                }
            }
        }

     recPtr ++;
     totalBytes -= sizeof(CUprofStreamingRecord);
    }

#ifdef PRINT_EVENT_SAMPLING_RECORDS
    if (tempfp) {
        fflush(tempfp);
        fclose(tempfp);
        //return CUDA_ERROR_FILE_NOT_FOUND;
    }
#endif
    j = 0;
    offset[j++] = NV_PERF_PMASYS_MEM_BYTES;

    if (CUDA_SUCCESS != PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, j, offset, values, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }
    //Write value read from mem_bytes to mem_bump
    j = 0;
    offset[j] = NV_PERF_PMASYS_MEM_BUMP;

    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, j, offset, values, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

EXIT:
    free (offset);
    free (values);
    return status;
}

static CUprofResult logPMCountersModeB(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *values = NULL, *currPosInValueArray = NULL;
    NvU32 size = 0, totalSlots = 0;
    NvU32 domainRegOffset = 0, chipIdx = 0, i = 0, idx = 0;
    CUkeplerEventGroup  *keplerEventGroup;
    CUparsedClk *pTempParsedClk = NULL;
    CU_TRACE_FUNCTION();

    keplerEventGroup = pEventGroup->arch.keplerEventGroup;
    CU_ASSERT(keplerEventGroup);

    //elapsed_clocks is always read
    totalSlots = (CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS + CU_PROF_ELAPSED_CLOCK_SLOT);
    size  = sizeof(NvU32) * totalSlots * keplerEventGroup->maxChiplets;

    offset = (NvU32*)malloc(size);
    values = (NvU32*)malloc(size);
    if (!offset || !values) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    pTempParsedClk = keplerEventGroup->pParsedClk;

    for (chipIdx = 0; chipIdx < keplerEventGroup->maxChiplets; chipIdx++) {
        if(keplerEventGroup->pmUnitMask & (1<<chipIdx))
        {
            domainRegOffset = keplerEventGroup->pmmAddress[chipIdx] + keplerEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;

            offset[NV_PMM_TRIG0_BIT_POS+(totalSlots*idx)] = domainRegOffset + NV_PMM_TRIGGERCNT;
            offset[NV_PMM_TRIG1_BIT_POS+(totalSlots*idx)] = domainRegOffset + NV_PMM_THRESHCNT;
            offset[NV_PMM_EVENT_BIT_POS+(totalSlots*idx)] = domainRegOffset + NV_PMM_EVENTCNT;
            offset[NV_PMM_SAMPLE_BIT_POS+(totalSlots*idx)] = domainRegOffset + NV_PMM_SAMPLECNT;
            offset[NV_PMM_ELAPSED_CLOCKS_BIT_POS+(totalSlots*idx)] = domainRegOffset + NV_PMM_ELAPSED;
            idx++;
        }
    }
    CU_ASSERT(idx <= totalSlots * keplerEventGroup->maxChiplets);
    // read counter values for all HW counters then populate the values in eventgroup depending on the mode
    if (CUDA_SUCCESS != PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, totalSlots*idx, offset, values, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

    idx = 0;
    for (chipIdx = 0; chipIdx < keplerEventGroup->maxChiplets; chipIdx++) {
        if(keplerEventGroup->pmUnitMask & (1<<chipIdx))
        {
            currPosInValueArray = (pTempParsedClk->values + (pEventGroup->totalCounters * chipIdx));
            for(i=0; i<pEventGroup->totalCounters; i++)
            {
                if (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_VIVEK) {
                    if(pTempParsedClk->eventspec[i] == NV_ELAPSED_CLOCKS) {
                        currPosInValueArray[i] = values[NV_PMM_ELAPSED_CLOCKS_BIT_POS+(totalSlots*idx)];
                    } else {
                        NvU32 partNo = 0, spec = 0, width = 0, lshCount = 0, partWidth = 0, tempPartNumber = 0;
                        currPosInValueArray[i] = 0;
                        tempPartNumber = pTempParsedClk->partNumber[i];
                        width = pTempParsedClk->width[i];
                        while(tempPartNumber) {
                            spec = (tempPartNumber & 0xff);
                            spec--;
                            switch(spec) {
                                case NV_PMM_SAMPLE_BIT_POS : partWidth = (width >= 3) ? 3 : width; break;
                                case NV_PMM_TRIG0_BIT_POS  : partWidth = (width >= 3) ? 3 : width; break;
                                case NV_PMM_EVENT_BIT_POS  : partWidth = (width >= 4) ? 4 : width; break;
                                case NV_PMM_TRIG1_BIT_POS  : partWidth = (width >= 4) ? 4 : width; break;
                            }
                            //change values in parsedClk to 64 bit.
                            currPosInValueArray[i] +=  (NvU32)(((NvU64)(values[spec+(totalSlots*idx)]) << lshCount));
                            lshCount += partWidth;
                            width -= partWidth;
                            partNo++;
                            tempPartNumber >>= 8;
                        }
                        //At the end of while loop the width has to be 0
                        CU_ASSERT(width == 0);
                    }
                } else {
                    switch(pTempParsedClk->eventspec[i]) {
                case (NV_PMM_TRIG1 | NV_PMM_EVENT):
                    if ((pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_EVENT4) || (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_EVENT6)) {
                        currPosInValueArray[i] = values[NV_PMM_EVENT_BIT_POS+(totalSlots*idx)];
                    }
                    else if ((pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_TRIG4) || (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_TRIG6)) {
                        if ((pTempParsedClk->width[i] == 2) && (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_TRIG6)) {
                            //This case should occur rarely as we will give preference to vivek mode
                            currPosInValueArray[i] = values[NV_PMM_EVENT_BIT_POS+(totalSlots*idx)];
                        } else {
                            currPosInValueArray[i] = values[NV_PMM_TRIG1_BIT_POS+(totalSlots*idx)];
                        }
                    }
                    break;
                case NV_PMM_TRIG0:
                    currPosInValueArray[i] = values[NV_PMM_TRIG0_BIT_POS+(totalSlots*idx)];
                    break;
                case NV_PMM_TRIG1:
                    currPosInValueArray[i] = values[NV_PMM_TRIG1_BIT_POS+(totalSlots*idx)];
                    break;
                case NV_PMM_EVENT:
                    currPosInValueArray[i] = values[NV_PMM_EVENT_BIT_POS+(totalSlots*idx)];
                    break;
                case NV_PMM_SAMPLE:
                    currPosInValueArray[i] = values[NV_PMM_SAMPLE_BIT_POS+(totalSlots*idx)];
                    break;
                case NV_ELAPSED_CLOCKS:
                    currPosInValueArray[i] = values[NV_PMM_ELAPSED_CLOCKS_BIT_POS+(totalSlots*idx)];
                    break;
                default:
                    CU_ERROR_PRINT(("Not a valid trigger type.\n"));
                    break;
                    }
                }
            }
            idx++;
        }
    }

EXIT:
    free (offset);
    free (values);
    return status;
}
// detect if there has been a counter overflow
static CUprofResult detectCounterOverflowModeB(const CUeventGroup *pEventGroup, NvBool* bIsOverflow)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUkeplerEventGroup  *keplerEventGroup;
    CUparsedClk *pTempParsedClk = NULL;
    NvU32 chipIdx = 0, i = 0;

    CU_TRACE_FUNCTION();

    keplerEventGroup = pEventGroup->arch.keplerEventGroup;
    CU_ASSERT(keplerEventGroup);

    // NV_PERF_PMM_CONTROL_SHADOW_STATE_OVERFLOW field has nothing to do with overflowing snapshots (pm_trigger).
    // in mode B the fact that the counter is saturated (0xFFFFFFFF) is enough to assume overflow.
    for (chipIdx = 0; chipIdx < keplerEventGroup->maxChiplets; chipIdx++) {
        if(keplerEventGroup->pmUnitMask & (1<<chipIdx)) {
            pTempParsedClk = pEventGroup->arch.keplerEventGroup->pParsedClk;
            for(i=0; i<pEventGroup->totalCounters; i++) {
                if (COUNTER_MAX32BIT == *(pTempParsedClk->values + (pEventGroup->totalCounters * chipIdx) + i)) {
                    *bIsOverflow = NV_TRUE;
                    return CUPROF_SUCCESS;
                }
            }
        }
    }
    return status;
}
static CUprofResult PMReleaseModeB(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *value = NULL;
    NvU32 count = 0, size = 0, domainRegOffset = 0;
    NvU32 chipIdx = 0;
    CUkeplerEventGroup  *keplerEventGroup;

    CU_TRACE_FUNCTION();
    keplerEventGroup = pEventGroup->arch.keplerEventGroup;


    size = sizeof(NvU32) * keplerEventGroup->maxChiplets;
    offset = (NvU32*)malloc(size);
    value  = (NvU32*)malloc(size);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset and value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    for (chipIdx = 0; chipIdx < keplerEventGroup->maxChiplets; chipIdx++) {
        if(keplerEventGroup->pmUnitMask & (1<<chipIdx))
        {
            domainRegOffset = keplerEventGroup->pmmAddress[chipIdx] + keplerEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
            offset[count]  = domainRegOffset + NV_PERF_PMM_RELEASE;
            value[count++] = NV_PERF_PMM_RELEASE_SHADOWS_DOIT;
        }
    }

    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

EXIT:
    free (offset);
    free (value);

    return status;
}

static CUprofResult keplerPerfmonSampleCountersNew(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvBool bIsOverflow = NV_FALSE;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if (!pEventGroup->totalCounters) {
        return CUPROF_SUCCESS;
    }

    if ((pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS)
        ||
        (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING)
        ) {
        status = StartExptModeB(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            goto EXIT;
        }
    }

    if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING) {
        stopStreaming(pEventGroup);
        status = logPMCountersModeBStreamingMode(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            goto EXIT;
        }
    } else {
        status = logPMCountersModeB(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            goto EXIT;
        }
        // report overflow if any
        if (CUPROF_SUCCESS != detectCounterOverflowModeB(pEventGroup, &bIsOverflow)) {
            goto EXIT;
        }

        if (bIsOverflow) {
            CU_ERROR_PRINT(("One or more counter is overflowing.\n"));
        }
    }



    status = PMReleaseModeB(pEventGroup);
    if (CUPROF_SUCCESS != status) {
        goto EXIT;
    }

EXIT:

    return status;
}

// Function to read counters from hardware
static CUprofResult keplerReadCounters(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 i = 0, chipIdx = 0, j = 0, smcntr_idx, lsh_cnt = 0;
    CUparsedClk     *pTempParsedClk = NULL;
    CUSMCtrInfo     *pSM = NULL;
    NvBool          bIsOverflow = NV_FALSE;
    CUeventInfo *currEventInfo = NULL;
    void *currEvent = NULL;
    void *eventBase = NULL;
    NvU32 multiplier[CU_PROF_PM_EVENT_GROUP_MAX_COUNTERS] = {0}, splitWidth[CU_PROF_PM_EVENT_GROUP_MAX_COUNTERS] = {0};

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);
    CU_ASSERT(pEventGroup->isEnabled);

    if (!pEventGroup->totalCounters) {
        return CUPROF_SUCCESS;
    }

    currEventInfo = (CUeventInfo*)listGetNext(pEventGroup->pEventInfoList, &eventBase);
    switch(pEventGroup->domain->eventCollectionMethod)
    {
    case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
        //sample PM signals
        for (i = 0; (i < pEventGroup->totalCounters) && currEventInfo; i++, currEventInfo = (CUeventInfo*)listGetNext(NULL, &eventBase)) {
            currEvent = currEventInfo->pEventData;
            // store multiplication factor of each signal in the event group
            if(pEventGroup->pCtx->device->state.minor < 5) {
                multiplier[i] = getCounterMultiplicationFactor_GK10x(((CUeventDataHwpm*)currEvent)->signalId);
            }
            else {
                multiplier[i] = getCounterMultiplicationFactor_GK11x(((CUeventDataHwpm*)currEvent)->signalId);
            }
            getSplittingInfo(((CUeventDataHwpm*)currEvent)->signalId, &splitWidth[i], pEventGroup->pCtx->pmNew->isMembarWarEnabled);
        }
        status = keplerPerfmonSampleCountersNew(pEventGroup);
        if (status != CUPROF_SUCCESS) {
            return status;
        }

        for (chipIdx = 0; chipIdx < pEventGroup->arch.keplerEventGroup->maxChiplets; chipIdx++) {
            if(pEventGroup->arch.keplerEventGroup->pmUnitMask & (1<<chipIdx))
            {
                pTempParsedClk = pEventGroup->arch.keplerEventGroup->pParsedClk;;
                for(i=0; i<pEventGroup->totalCounters; i++)
                {
                    //copy linearly in eventgroup in folowing fashion: [instancecount][counter]
                    if ((*(pTempParsedClk->values + pEventGroup->totalCounters * chipIdx + i) != COUNTER_MAX32BIT) &&
                        (pEventGroup->values[j] != COUNTER_MAX64BIT))
                    {
                        pEventGroup->values[j++] += (NvU64)*(pTempParsedClk->values + pEventGroup->totalCounters * chipIdx + i) * multiplier[i];
                    }
                    else {
                        // 32-bit counter is overflowing, set 64-bit out value to max
                        pEventGroup->values[j++] = COUNTER_MAX64BIT;
                    }
                }
            }
        }

        break;

    case CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW:
    case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
        //sample SM counters
        for (i = 0; (i < pEventGroup->totalCounters) && currEventInfo; i++, currEventInfo = (CUeventInfo *)listGetNext(NULL, &eventBase)) {
            currEvent = currEventInfo->pEventData;
            // store multiplication factor of each signal in the event group
            if(pEventGroup->pCtx->device->state.minor < 5) {
                multiplier[i] = getCounterMultiplicationFactor_GK10x(((CUeventDataSmpc*)currEvent)->signalId);
            }
            else {
                multiplier[i] = getCounterMultiplicationFactor_GK11x(((CUeventDataSmpc*)currEvent)->signalId);
            }
            getSplittingInfo(((CUeventDataBasic*)currEvent)->signalId, &splitWidth[i], pEventGroup->pCtx->pmNew->isMembarWarEnabled);
        }
        if (CUDA_SUCCESS != logPMCountersSMInternal(pEventGroup)) {
            return CUPROF_ERROR_UNKNOWN;
        }

        // report overflow if any
        if (CUDA_SUCCESS != detectCounterOverflowSMInternal(pEventGroup, &bIsOverflow)) {
            return status;
        }
        if (bIsOverflow) {
            CU_ERROR_PRINT(("One or more counter is overflowing.\n"));
        }

        pSM = pEventGroup->arch.keplerEventGroup->pSM;

        for (chipIdx = 0; chipIdx < pEventGroup->arch.keplerEventGroup->maxChiplets; chipIdx++) {
            if(pEventGroup->arch.keplerEventGroup->pmUnitMask & (1<<chipIdx))
            {
                NvU32 sig_cnt = 0;
                for(i=0; i<pSM->SMCountersAdded && sig_cnt < pEventGroup->totalCounters; i+=((pSM->splitParts[sig_cnt]!=0) ? pSM->splitParts[sig_cnt] : 1), sig_cnt++)
                {
                    NvU64 temp_vals = 0;
                    lsh_cnt = 0;
                    for(smcntr_idx = i ; smcntr_idx < (i + pSM->splitParts[sig_cnt]) ; smcntr_idx++) {
                        //copy linearly in eventgroup in folowing fashion: [instancecount][counter]
                        if ((*(pSM->values + pSM->SMCountersAdded * chipIdx + smcntr_idx) != COUNTER_MAX64BIT) &&
                            (temp_vals != COUNTER_MAX64BIT))
                        {
                            temp_vals += *(pSM->values + pSM->SMCountersAdded * chipIdx + smcntr_idx) << lsh_cnt;
                        }
                        else {
                            // 32-bit counter is overflowing, set 64-bit out value to max
                            temp_vals = COUNTER_MAX64BIT;
                            break;
                        }
                        lsh_cnt += splitWidth[i];
                    }
                    if(temp_vals != COUNTER_MAX64BIT){
                        temp_vals *= multiplier[sig_cnt];
                    }
                    pEventGroup->values[j++] += temp_vals;
                }
            }
        }
        break;

    default:
        break;
    }

    return status;
}

CUprofResult keplerPerfmonEventGroupDisable(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    CUctx *ctx;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);
    //CU_ASSERT(pEventGroup->domainId < MAX_DOMAINS);

    ctx = pEventGroup->pCtx;
    setDomainEventGroup(ctx->pmNew->domainEventGroupEnabled, pEventGroup->domainId, 0);
    pEventGroup->isEnabled = 0;

    switch(pEventGroup->domain->eventCollectionMethod) {
        case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
            if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING) {
                stopStreaming(pEventGroup);
#ifndef BUG_1259185_FIXED
                cleanupStreamingResources(ctx);
#endif
            }
            // PM_ENABLE bit setting is Global. It will affect counter profiling in a multi-process/multi-ctx scenario
            // Commenting the Code to clear off the PM_ENABLE bit:(Bug 1254320)
            // To do: Re-enable the code when bug 973271 is fixed
#if 0
            status = setPMEnableReg(pEventGroup, NV_FALSE);
            if (CUPROF_SUCCESS != status) {
                CU_ERROR_PRINT(("Failed to disable the PME\n"));
            }
#endif
            resetPMTarget(pEventGroup);
            /************************************************************************
               Release the perfmon if perfmon is reserved in eventGroupEnable. This
               extra perfmon release call is required for supporting HWPM counter
               profiling for toolkits < R5.5. The flag isPerfmonReserved is modified
               only while reserving perfmon via CUPTI. This call will ideally not be
               executed for Toolkits > R5.0 (Bug 1408976)
            *************************************************************************/
            if (!ctx->device->state.profilerState.isPerfmonReservedOutsideHal) {
                status = perfmonControl(ctx, NV_FALSE, NV_TRUE);
                if (status != CUPROF_SUCCESS) {
                    CU_ERROR_PRINT(("Failed to control PM HW\n"));
                    return status;
                }
            }
            break;

        case CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW:
        case CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW:
        case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
            if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS) {
                keplerPerfmonStopCounters(NULL, pEventGroup);
            }
            // SMK_ENABLE bit setting is Global. It will affect counter profiling in a multi-process/multi-ctx scenario
            // Commenting the Code to clear off the PM_ENABLE bit:(Bug 1254320)
            // To do: Re-enable the code when bug 973271 is fixed
#if 0
            // As the membar.pending signal will need the PM_ENABLE bit
            // to be always set, skipping the disable part.

            if(!pEventGroup->pCtx->pmNew->isMembarWarEnabled) {
                status = setPMEnableRegSM(pEventGroup, NV_FALSE);
                if (CUPROF_SUCCESS != status) {
                    CU_ERROR_PRINT(("Failed to disable the SMPERF PMReg\n"));
                }
            }
#endif
            resetPMTarget(pEventGroup);

            break;

        case CUPROF_EVENT_COLLECTION_METHOD_SW:
        default:
            //do nothing
            break;
    }

    return status;
}

CUprofResult keplerPerfmonEventGroupReadEvent(CUeventGroup          *pEventGroup,
                                              CUprof_ReadEventFlags flags,
                                              CUprof_EventID        eventID,
                                              size_t                *bufferSizeBytes,
                                              NvU64                 *counterData)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUeventInfo *currEventInfo = NULL;
    void *currEvent = NULL;
    void *eventBase = NULL;
    NvU32 i = 0, j = 0, instanceCount = 0;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if (pEventGroup->domainId != KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST)
        CU_ASSERT(pEventGroup->arch.keplerEventGroup);
    CU_ASSERT(bufferSizeBytes && counterData);

    currEventInfo = (CUeventInfo *)listGetNext(pEventGroup->pEventInfoList, &eventBase);
    for (i = 0; (i < pEventGroup->totalCounters) && currEventInfo; i++, currEventInfo = (CUeventInfo *)listGetNext(NULL, &eventBase)) {
        currEvent = currEventInfo->pEventData;
        if (((CUeventDataBasic*)currEvent)->signalId == eventID) {
                break;
        }
    }

    if (i == pEventGroup->totalCounters) {
        CU_ERROR_PRINT(("Invalid event-id %d\n", (int)eventID));
        return CUPROF_ERROR_INVALID_EVENT_ID;
    }

    // trigger the PM and read counters
    if (pEventGroup->domainId != KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST) {
        status = keplerReadCounters(pEventGroup);
        if (status != CUPROF_SUCCESS) {
            CU_ERROR_PRINT(("Failed to read counters or reset pm\n"));
            return status;
        }
    }

    if(pEventGroup->profileAll) {
        instanceCount = pEventGroup->instanceCountAvail;
    }
    else {
        instanceCount = 1;
    }

    //Check how many bytes are allocated for counterData
    instanceCount = MIN(*(NvU32*)bufferSizeBytes / sizeof(NvU64), instanceCount);
    *bufferSizeBytes = instanceCount * sizeof(NvU64);

    for(j = 0; j < instanceCount; j++)
    {
        counterData[j] = pEventGroup->values[i + j*pEventGroup->totalCounters];
        // zero out the stored value, only returned counter values are considered
        pEventGroup->values[i + j*pEventGroup->totalCounters] = 0;
    }

    if((CUPROF_EVENT_COLLECTION_METHOD_SMPERF == pEventGroup->domain->eventCollectionMethod) ||
        (CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW == pEventGroup->domain->eventCollectionMethod) ||
        (CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW == pEventGroup->domain->eventCollectionMethod)) {
        status = (CUprofResult)resetPMSMInternal(pEventGroup);
    }
    if (CUPROF_EVENT_COLLECTION_METHOD_HWPM == pEventGroup->domain->eventCollectionMethod) {
        status = StartExptModeB(pEventGroup);
    }

    return status;
}

CUprofResult keplerPerfmonEventGroupReadAllEvents(CUeventGroup *pEventGroup,
                                                  CUprof_ReadEventFlags  flags,
                                                  size_t                 *bufferSizeBytes,
                                                  NvU64                  *counterDataBuffer,
                                                  size_t                 *arraySizeBytes,
                                                  CUprof_EventID         *eventIDArray,
                                                  size_t                 *numCountersRead)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUeventInfo *currEventInfo = NULL;
    void *currEvent = NULL;
    void *eventBase = NULL;
    NvU32 numEvents = 0, i = 0, j = 0, totalValues = 0, instanceCount = 0;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if (pEventGroup->domainId != KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST)
        CU_ASSERT(pEventGroup->arch.keplerEventGroup);
    CU_ASSERT(bufferSizeBytes && counterDataBuffer);
    CU_ASSERT(numCountersRead);

    // trigger the PM and read counters
    if (pEventGroup->domainId != KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST) {
        status = keplerReadCounters(pEventGroup);
        if (status != CUPROF_SUCCESS) {
            CU_ERROR_PRINT(("Failed to read counters or reset pm\n"));
            return status;
        }
    }

    if(pEventGroup->profileAll) {
        instanceCount = pEventGroup->instanceCountAvail;
    }
    else {
        instanceCount = 1;
    }

    //Check how many bytes are allocated for counterData
    totalValues = instanceCount * pEventGroup->totalCounters;
    totalValues = MIN(*(NvU32*)bufferSizeBytes / sizeof(NvU64), totalValues);

    //It makes sense to give all instances of possible number of events
    numEvents = totalValues / instanceCount;

    *bufferSizeBytes = numEvents * instanceCount * sizeof(NvU64);

    for(i = 0; i < instanceCount; i++) {
        for(j = 0; j < numEvents; j++) {
            *(counterDataBuffer+i*numEvents+j) = *(pEventGroup->values + i*pEventGroup->totalCounters + j);
            // zero out the stored value, only returned counter values are considered
            *(pEventGroup->values + i*pEventGroup->totalCounters + j) = 0;
        }
    }
    *numCountersRead = numEvents;

    // assuming eventId params are optional
    if (arraySizeBytes && (*arraySizeBytes > 0) && eventIDArray) {
        numEvents = MIN(*(NvU32*)arraySizeBytes / sizeof(CUprof_EventID), *(NvU32*)numCountersRead);
        currEventInfo = (CUeventInfo*)listGetNext(pEventGroup->pEventInfoList, &eventBase);

        for (i = 0; (i < pEventGroup->totalCounters) && (i < numEvents) && currEventInfo; i++, currEventInfo = (CUeventInfo*)listGetNext(NULL, &eventBase)) {
            currEvent = currEventInfo->pEventData;
            eventIDArray[i] = ((CUeventDataBasic*)currEvent)->signalId;
        }
        *arraySizeBytes = numEvents * sizeof(CUprof_EventID);
    }

    if((CUPROF_EVENT_COLLECTION_METHOD_SMPERF == pEventGroup->domain->eventCollectionMethod) ||
        (CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW == pEventGroup->domain->eventCollectionMethod) ||
        (CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW == pEventGroup->domain->eventCollectionMethod)){
        status = (CUprofResult)resetPMSMInternal(pEventGroup);
    }

    return status;
}

// this function is not exposed to external users
// it assists internal tools (profiler) to control event group
// based operations
CUprofResult keplerPerfmonEventGroupControl(CUeventGroup *pEventGroup,
                                            CUeventGroupFlag flag,
                                            void *value)
{
    CUprofResult status = CUPROF_SUCCESS;

    CU_TRACE_FUNCTION();

    CU_ASSERT(pEventGroup);

    switch (flag) {
    case CU_EVENT_GROUP_FLAG_SET_PROFILE_ALL_DOMAIN_INSTANCES:
        pEventGroup->profileAll = 1;
        break;
    case CU_EVENT_GROUP_FLAG_GET_CHIP_TYPE_FB:
        if (pEventGroup->domain->chipletType == PM_CHIPLET_TYPE_FBP) {
            *(int*)value = 1;
        }
        else {
            *(int*)value = 0;
        }
        break;
    case CU_EVENT_GROUP_FLAG_GET_UNIT_TYPE_SM:
            if ((pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_SMPERF) ||
            (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW) ||
            (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW)) {
                *(int*)value = 1;
            }
            else {
                *(int*)value = 0;
            }
            break;
    default:
        CU_ERROR_PRINT(("Not a valid flag (%d)\n", flag));
        break;
    }

    return status;
}
// detect if there has been a counter overflow
static CUresult detectCounterOverflowSMInternal(const CUeventGroup *pEventGroup, NvBool* bIsOverflow)
{
    CUresult status = CUDA_SUCCESS;
    CUkeplerEventGroup  *pKeplerEventGroup = NULL;
    NvBool bOverflow = NV_FALSE;
    NvU32 offset = 0, value[2] = {0}, valueA = 0;
    NvU32 gpcId = 0, tpcId = 0, smId = 0;
    NvU32 idxQctl = 0, idxCore = 0;
    NvU32 i = 0;
    CUSMCtrInfo     *pSM = NULL;
#if defined(NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_QUAD)
    NvU8  regQuad = 0;
    NvU32 quadOffsets[CU_PROF_SM_QUAD_PROFILED_MAX];
    NvU32 quadClearValues[CU_PROF_SM_QUAD_PROFILED_MAX] = {0, 0, 0, 0};
    NvU8  quads[CU_PROF_SM_QUAD_PROFILED_MAX] = {0, 1, 2, 3};
#endif

    CU_TRACE_FUNCTION();

    pKeplerEventGroup = pEventGroup->arch.keplerEventGroup;
    pSM = pKeplerEventGroup->pSM;

    for(gpcId = 0; gpcId < pKeplerEventGroup->gpcCount; gpcId++)
    {
        for(tpcId = 0; tpcId < pKeplerEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
        {
            if(pKeplerEventGroup->pmUnitMask & (1<<smId))
            {
#if defined(NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_QUAD)
                for(regQuad = 0; regQuad < 4; regQuad++)
                {
                    // query status registers
                    offset = NV_SM_DSM_PERF_COUNTER_STATUS(gpcId, tpcId);
                    status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT_QUAD, 1, &offset, &valueA, &regQuad);
                    if (CUDA_SUCCESS != status) {
                        return status;
                    }
                    value[0] |= valueA;
                }
#else
                offset = NV_SM_DSM_PERF_COUNTER_STATUS(gpcId, tpcId);
                status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, 1, &offset, &valueA, 0);
                if (CUDA_SUCCESS != status) {
                    return status;
                }
                value[0] = valueA;
#endif

                offset = NV_SM_DSM_PERF_COUNTER_STATUS1(gpcId, tpcId);
                status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, 1, &offset, &valueA, 0);
                if (CUDA_SUCCESS != status) {
                    return status;
                }
                value[1] = valueA;

                // bits [3:0] of PERF_COUNTER_STATUS/1 are overflow bits,
                // 1 bit for each of the 8 SM internal perf counters

                // check for overflow
                idxQctl = 0;
                if(pEventGroup->pCtx->pmNew->isMembarWarEnabled) {
                    idxCore = 1;
                }
                else {
                    idxCore = 0;
                }
                for(i=0; i<(NvU32)pSM->SMCountersAdded; i++) {
                    switch (pSM->pmUnitId[i]) {
                    case PM_UNIT_SMQCTL:
                        if (value[0] & (1<<idxQctl)) {
                            *(pSM->values + pSM->SMCountersAdded * smId + i) = COUNTER_MAX64BIT;
                        }
                        idxQctl++;
                        break;
                    case PM_UNIT_SMCORE:
                        if (value[1] & (1<<idxCore)) {
                            *(pSM->values + pSM->SMCountersAdded * smId + i) = COUNTER_MAX64BIT;
                        }
                        idxCore++;
                        break;
                    }
                }

                bOverflow = ((value[0] & 0xf) ? NV_TRUE : NV_FALSE) ? NV_TRUE : ((value[1] & 0xf) ? NV_TRUE : NV_FALSE);
                // update the return value by ORing else overflow status of previous instnace
                // might get lost
                *bIsOverflow |= bOverflow;

                if (bOverflow) {
                    // Clear the overflow bits
#if defined(NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_QUAD)
                    // NOTE:  For each counter register, all quads must be written in a single operation.
                    // Bug 1021670
                    // Each index targets the same register, but hits a different quadrant
                    quadOffsets[0] = NV_SM_DSM_PERF_COUNTER_STATUS(gpcId, tpcId);
                    quadOffsets[1] = NV_SM_DSM_PERF_COUNTER_STATUS(gpcId, tpcId);
                    quadOffsets[2] = NV_SM_DSM_PERF_COUNTER_STATUS(gpcId, tpcId);
                    quadOffsets[3] = NV_SM_DSM_PERF_COUNTER_STATUS(gpcId, tpcId);

                    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT_QUAD, 4, quadOffsets, quadClearValues, quads);
                    if (CUDA_SUCCESS != status) {
                        return status;
                    }
#else
                    valueA = 0;
                    offset = NV_SM_DSM_PERF_COUNTER_STATUS(gpcId, tpcId);
                    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, 1, &offset, &valueA, 0);
                    if (CUDA_SUCCESS != status) {
                        return status;
                    }
#endif
                    valueA = 0;
                    offset = NV_SM_DSM_PERF_COUNTER_STATUS1(gpcId, tpcId);
                    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, 1, &offset, &valueA, 0);
                    if (CUDA_SUCCESS != status) {
                        return status;
                    }
                    // don't return since we need to check the overflow in all profiled instances
                }
            }
            smId++;
        }
    }

    return status;
}


static CUresult setPMEnableRegSM(const CUeventGroup *pEventGroup, NvBool bEnable)
{
    //Function to be changed for new version
    CUresult status = CUDA_SUCCESS;
    NvU32 offset, value;
    NvU32 i = 0, j = 0;
    NvU32 smValue, smMask;
    NvU32 pmUnitIdx = 0;
    PMEnableRegInfo *pPMEnableRegInfo = NULL;
    CUSMCtrInfo     *pSM = NULL;

    CU_TRACE_FUNCTION();

    pSM = pEventGroup->arch.keplerEventGroup->pSM;

    for(i=0; i<(NvU32)pSM->SMCountersAdded; i++) {
        pmUnitIdx = 0;

        //Search the unit table to get the unit.
        //TBD check if we can shift the unit table to domain table
        while (pEventGroup->pCtx->device->state.pPerfUnitTable[pmUnitIdx].pmUnitId != PM_UNIT_MAX) {
            if (pEventGroup->pCtx->device->state.pPerfUnitTable[pmUnitIdx].pmUnitId == pSM->pmUnitId[i]) {
                break;
            }
            pmUnitIdx++;
        }

        if (pEventGroup->pCtx->device->state.pPerfUnitTable[pmUnitIdx].pmUnitId == PM_UNIT_MAX) {
            // perf unit not found
            continue;
        }

        pPMEnableRegInfo = &pEventGroup->pCtx->device->state.pPerfUnitTable[pmUnitIdx].pmEnableRegInfo;

        for(j=0; j< pEventGroup->arch.keplerEventGroup->maxChiplets; j++)
        {
            if(pEventGroup->arch.keplerEventGroup->pmUnitMask & (1<<j))
            {
                offset = pEventGroup->arch.keplerEventGroup->priAddress[j] + pPMEnableRegInfo->regOffset;
                value = 0;
                smValue = 0;

                // read _PM registers
                status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, 1, &offset, &value, 0);
                if (status != CUDA_SUCCESS) {
                    return status;
                }

                // set SMK_ENABLE
                smValue = DRF_REPLACE(smValue, NV_SM_PM_CTRL_SMK_ENABLE_ENABLE, NV_SM_PM_CTRL_SMK_ENABLE);
                // set PM_ENABLE bit by ORing the read value for selected instance
                smValue |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                smMask  = NV_SM_PM_CTRL_VALID_BITS_MASK;
                if(bEnable)
                {
                    value |= (smValue & smMask);
                }
                else
                {
                    value &= ~(smMask);
                }

                status = PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, 1, &offset, &value, 0);
                if (status != CUDA_SUCCESS) {
                    return status;
                }
            }
        }
    }

   for(i=0; i<(NvU32)pSM->numGroupsCore; i++) {
       for(j=0; j< pEventGroup->arch.keplerEventGroup->maxChiplets; j++)
       {
           if(pEventGroup->arch.keplerEventGroup->pmUnitMask & (1<<j))
           {
                // special case for L1C counters
                // enable PRI_L1C_PM_ENABLE bit
                // HACK: L1C counters start from eventGroup #7, see perfmon_smperf_corelsu.spec
                if (pSM->groupsCore[i] >= 7) {
                    offset = pEventGroup->arch.keplerEventGroup->priAddress[j] + 0x000004a8;
                    status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, 1, &offset, &value, 0);
                    if (status != CUDA_SUCCESS) {
                        return status;
                    }

                    value = DRF_REPLACE(value, NV_L1C_PM_ENABLE_ENABLE, NV_L1C_PM_ENABLE);
                    status = PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, 1, &offset, &value, 0);
                    if (status != CUDA_SUCCESS) {
                        return status;
                    }
                }
            }
       }
   }

    return status;
}

static CUresult SetupPMRegistersSMInternal(CUeventGroup *pEventGroup) {
    CUresult status = CUDA_SUCCESS;
    NvU32 edgeModeQctl = 0, edgeModeCore = 0;
    NvU32 eventGroupQctl = 0, eventGroupCore = 0;
    NvU32 idxQctl = 0, idxCore = 0;
    NvU32 index = 0, i = 0;
    CUresult (*setupSmpcRegs)(CUeventGroup *pEventGroup, NvU32 eventGroupQctl, 
                                                    NvU32 eventGroupCore, NvU32 enableQctl, NvU32 enableCore);
    CUSMCtrInfo     *pSM = NULL;

    CU_TRACE_FUNCTION();

    pSM = pEventGroup->arch.keplerEventGroup->pSM;
    // Use the new RM Control call for enabling the WAR if it is defined:
#if defined(NV2080_CTRL_CMD_GR_CTXSW_SMPC_MODE)
    if (!pEventGroup->pCtx->pmNew->flag)
    {
        status = pEventGroup->pCtx->device->dmal.deviceSetSMPCCtxswMode(pEventGroup->pCtx, NV_TRUE);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Error setting the CTXSW_SMPC_MODE bit\n"));
            goto EXIT;
        }
        pEventGroup->pCtx->pmNew->flag = 1;
    }
#else
#if defined(NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_QUAD)
    status = setFalcon05Method(pEventGroup->pCtx);
    if (status != CUDA_SUCCESS) {
        goto EXIT;
    }
#endif
#endif

    // Call the broadcase version if profileAll option is selected:
    if(pEventGroup->profileAll &&
       pEventGroup->pCtx->device->dmalType != CU_DMAL_MRM) {
        // mrm bug 200118793
        setupSmpcRegs = &SetupPMRegistersSM_bc;
    }
    // Else. call the unicast version:
    else {
        setupSmpcRegs = &SetupPMRegistersSM;
    }
    // Select group, edge, func etc
    // first four slots of perf registers are reserved for quad signals
    // while last four are for core/lsu signals

    idxQctl = 0;
    idxCore = pEventGroup->pCtx->pmNew->isMembarWarEnabled ? 1 : 0;

    for(i=0; i<pSM->numGroupsQuad; i++)
    {
        eventGroupQctl |= pSM->groupsQuad[i] << (idxQctl*8);
        idxQctl++;
    }
    for(i=0; i<pSM->numGroupsCore; i++)
    {
        eventGroupCore |= pSM->groupsCore[i] << (idxCore*8);
        idxCore++;
    }

    // Performance Counter - edge
    // EDGE0 - 0:0, EDGE1 - 4:4, EDGE2 - 8:8,   EDGE3 - 12:11
    // MODE0 - 2:1, MODE1 - 6:5, MODE2 - 10:9,  MODE3 - 14:13
    // set EDGE = DISABLE and MODE = COUNT
    idxQctl = 0;
    idxCore = pEventGroup->pCtx->pmNew->isMembarWarEnabled ? 1 : 0;

    for (index = 0; index < pSM->SMCountersAdded; index++) {
        NvU32 startBit, endBit;
        switch(pSM->pmUnitId[index])
        {
        case PM_UNIT_SMQCTL:
                startBit = (idxQctl * 4) + 1;
                endBit = startBit + 1;
                edgeModeQctl = DRF_REPLACE(edgeModeQctl, pSM->mode[index], endBit:startBit);
                idxQctl++;
                break;
        case PM_UNIT_SMCORE:
                startBit = (idxCore * 4) + 1;
                endBit = startBit + 1;
                edgeModeCore = DRF_REPLACE(edgeModeCore, pSM->mode[index], endBit:startBit);
                idxCore++;
                break;
        }
    }
    status = (*setupSmpcRegs)(pEventGroup, eventGroupQctl, eventGroupCore, edgeModeQctl, edgeModeCore);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Error setting the SMPC configuration registers\n"));
        goto EXIT;
    }

EXIT:
    return status;
}

static CUresult SetupPMRegistersSM(CUeventGroup *pEventGroup, NvU32 eventGroupQctl, NvU32 eventGroupCore, NvU32 edgeModeQctl, NvU32 edgeModeCore) {
    CUresult status = CUDA_SUCCESS;
    NvU32 gpcTarget = 0, tpcTarget = 0;
    //TBD Increasing arbitrarity to higher value, later on check exactly how much memory is required
    NvU32 *offset = NULL, gpcId = 0, tpcId = 0, smId = 0;
    NvU32 *value = NULL, valueCore, offsetCore;
    NvU32 count = 0, numRegs = 20;
    NvU32 idxQctl = 0, idxCore = 0;
    NvU32 index = 0;
    CUSMCtrInfo     *pSM = NULL;

    CU_TRACE_FUNCTION();

    //Allocate memory of size = (CU_PROF_PM_SM_MAX_COUNTERS * #SMs * sizeof(NvU32))
    offset = (NvU32 *)malloc(numRegs * pEventGroup->instanceCountAvail * sizeof(NvU32));
    value = (NvU32 *)calloc(numRegs * pEventGroup->instanceCountAvail, sizeof(NvU32));

    if(!(offset && value)) {
        CU_ERROR_PRINT(("Error allocating memory for offset-value arrays.\n"));
        status = (CUresult)CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    pSM = pEventGroup->arch.keplerEventGroup->pSM;
    for(gpcId = 0; gpcId < pEventGroup->arch.keplerEventGroup->gpcCount; gpcId++)
    {
        for(tpcId = 0; tpcId < pEventGroup->arch.keplerEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
        {
            if(pEventGroup->arch.keplerEventGroup->pmUnitMask & (1<<smId))
            {
                gpcTarget = gpcId;
                tpcTarget = tpcId;

                // Performance Counter Group mux select
                // GRP0 - 7:0,  GRP1 - 15:8, GRP2 - 23:16, GRP3 - 31:24
                offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL_SEL0(gpcTarget, tpcTarget);
                value[count++] = eventGroupQctl;
                if(pEventGroup->pCtx->pmNew->isMembarWarEnabled) {
                    NvU32 writeMask;
                    // Using the read-modify-writes to retain the settings done for membar.pending signal
                    offsetCore  = NV_SM_DSM_PERF_COUNTER_CONTROL_SEL1(gpcTarget, tpcTarget);
                    valueCore = eventGroupCore;
                    writeMask = CU_PROF_SM_CORE_GROUP_MUX_SELECT_MASK;
                    status = PRIWRITEMASKED32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, 1, &offsetCore, &valueCore, &writeMask, 0);
                    if (status != CUDA_SUCCESS) {
                        goto EXIT;
                    }
                }
                else {
                    offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL_SEL1(gpcTarget, tpcTarget);
                    value[count++] = eventGroupCore;
                }
                // Performance Counter - edge
                // EDGE0 - 0:0, EDGE1 - 4:4, EDGE2 - 8:8,   EDGE3 - 12:11
                // MODE0 - 2:1, MODE1 - 6:5, MODE2 - 10:9,  MODE3 - 14:13
                // set EDGE = DISABLE and MODE = COUNT
                offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL0(gpcTarget, tpcTarget);
                value[count++] = edgeModeQctl;
                offsetCore = NV_SM_DSM_PERF_COUNTER_CONTROL5(gpcTarget, tpcTarget);
                if(pEventGroup->pCtx->pmNew->isMembarWarEnabled) {
                    // Using the read-modify-writes to retain the settings done for membar.pending signal
                    NvU32 writeMask;
                    writeMask = CU_PROF_SM_CORE_EDGE_MODE_SELECT_MASK;
                    status = PRIWRITEMASKED32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, 1, &offsetCore, &edgeModeCore, &writeMask, 0);
                    if (status != CUDA_SUCCESS) {
                        goto EXIT;
                    }
                }
                else {
                    offset[count]  = offsetCore;
                    value[count++] = edgeModeCore;
                }
                //Set function registers to 0 initially, will be enabled in startCounters for
                //both kernel and continuous mode
                {
                    // setting the function values to 0
                    // These values will be set just before the kernel launch
                    offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL1(gpcTarget, tpcTarget);
                    value[count++] = 0;
                    offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL2(gpcTarget, tpcTarget);
                    value[count++] = 0;
                    if(pEventGroup->pCtx->pmNew->isMembarWarEnabled) {
                        // Using the read-modify-writes to retain the settings done for membar.pending signal
                        NvU32 valueCore, writeMask, offsetCore;
                        offsetCore  = NV_SM_DSM_PERF_COUNTER_CONTROL3(gpcTarget, tpcTarget);
                        valueCore = 0;
                        writeMask = CU_PROF_SM_CORE_FUNCTION_COMBINATION_MASK;
                        status = PRIWRITEMASKED32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, 1, &offsetCore, &valueCore, &writeMask, 0);
                        if (status != CUDA_SUCCESS) {
                            goto EXIT;
                        }
                    }
                    else {
                        offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL3(gpcTarget, tpcTarget);
                        value[count++] = 0;
                    }
                    offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL4(gpcTarget, tpcTarget);
                    value[count++] = 0;
                }

                // Each perf counter has 4 bits feeding into a function table.  Each bit
                // can be selected from 1 of 8 bits of 1 of the 8 groups (selected via
                // the PERF_COUNTER_CONTROL_SEL* register above).
                // BIT#_GRP selects 1 of 8 groups
                // BIT#_SIG selects 1 of the 8 signals from that selected group

                idxCore = pEventGroup->pCtx->pmNew->isMembarWarEnabled ? 1 : 0;
                idxQctl = 0;

                for (index = 0; index < pSM->SMCountersAdded; index++) {
                    switch(pSM->pmUnitId[index]) {
                    case PM_UNIT_SMQCTL:
                        switch(idxQctl) {
                        case 0:
                            offset[count] = NV_SM_DSM_PERF_COUNTER0_CONTROL(gpcTarget, tpcTarget);
                            break;
                        case 1:
                            offset[count] = NV_SM_DSM_PERF_COUNTER1_CONTROL(gpcTarget, tpcTarget);
                            break;
                        case 2:
                            offset[count] = NV_SM_DSM_PERF_COUNTER2_CONTROL(gpcTarget, tpcTarget);
                            break;
                        case 3:
                            offset[count] = NV_SM_DSM_PERF_COUNTER3_CONTROL(gpcTarget, tpcTarget);
                            break;
                        }
                        idxQctl++;
                        break;

                    case PM_UNIT_SMCORE:
                        switch(idxCore) {
                        case 0:
                            // Skip NV_SM_DSM_PERF_COUNTER4_CONTROL register settings if the WAR is enabled
                            if(!pEventGroup->pCtx->pmNew->isMembarWarEnabled) {
                                offset[count] = NV_SM_DSM_PERF_COUNTER4_CONTROL(gpcTarget, tpcTarget);
                            }
                            break;
                        case 1:
                            offset[count] = NV_SM_DSM_PERF_COUNTER5_CONTROL(gpcTarget, tpcTarget);
                            break;
                        case 2:
                            offset[count] = NV_SM_DSM_PERF_COUNTER6_CONTROL(gpcTarget, tpcTarget);
                            break;
                        case 3:
                            offset[count] = NV_SM_DSM_PERF_COUNTER7_CONTROL(gpcTarget, tpcTarget);
                            break;
                        }
                        idxCore++;
                        break;
                    }
                    value[count++]  = pSM->perfEventInfo[index];
                }
            }
            smId++;
        }
    }
    CU_ASSERT(count <= (numRegs * pEventGroup->instanceCountAvail));
    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, count, offset, value, 0);
    if (status != CUDA_SUCCESS) {
        goto EXIT;
    }

EXIT:
    if(offset) {
        free(offset);
    }
    if(value) {
        free(value);
    }
    return status;
}

static CUresult SetupPMRegistersSM_bc(CUeventGroup *pEventGroup, NvU32 eventGroupQctl, NvU32 eventGroupCore, NvU32 edgeModeQctl, NvU32 edgeModeCore) {
    CUresult status = CUDA_SUCCESS;
    //TBD Increasing arbitrarity to higher value, later on check exactly how much memory is required
    NvU32 *offset = NULL;
    NvU32 *value = NULL, offsetCore;
    NvU32 count = 0, numRegs = 20;
    NvU32 idxQctl = 0, idxCore = 0;
    NvU32 index = 0;
    CUSMCtrInfo     *pSM = NULL;

    CU_TRACE_FUNCTION();

    //Allocate memory of size = (CU_PROF_PM_SM_MAX_COUNTERS * #SMs * sizeof(NvU32))
    offset = (NvU32 *)malloc(numRegs * sizeof(NvU32));
    value = (NvU32 *)calloc(numRegs, sizeof(NvU32));

    if(!(offset && value)) {
        CU_ERROR_PRINT(("Error allocating memory for offset-value arrays.\n"));
        status = (CUresult)CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    pSM = pEventGroup->arch.keplerEventGroup->pSM;

    // Performance Counter Group mux select
    // GRP0 - 7:0,  GRP1 - 15:8, GRP2 - 23:16, GRP3 - 31:24
    offset[count]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL_SEL0;
    value[count++] = eventGroupQctl;
    if(pEventGroup->pCtx->pmNew->isMembarWarEnabled) {
        NvU32 writeMask;
        // Using the read-modify-writes to retain the settings done for membar.pending signal
        offsetCore  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL_SEL1;
        writeMask = CU_PROF_SM_CORE_GROUP_MUX_SELECT_MASK;
        status = PRIWRITEMASKED32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, 1, &offsetCore, &eventGroupCore, &writeMask, 0);
        if (status != CUDA_SUCCESS) {
            goto EXIT;
        }
    }
    else {
        offset[count]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL_SEL1;
        value[count++] = eventGroupCore;
    }
    // Performance Counter - edge
    // EDGE0 - 0:0, EDGE1 - 4:4, EDGE2 - 8:8,   EDGE3 - 12:11
    // MODE0 - 2:1, MODE1 - 6:5, MODE2 - 10:9,  MODE3 - 14:13
    // set EDGE = DISABLE and MODE = COUNT
    offset[count]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL0;
    value[count++] = edgeModeQctl;
    offsetCore = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL5;
    if(pEventGroup->pCtx->pmNew->isMembarWarEnabled) {
        // Using the read-modify-writes to retain the settings done for membar.pending signal
        NvU32 writeMask;
        writeMask = CU_PROF_SM_CORE_EDGE_MODE_SELECT_MASK;
        status = PRIWRITEMASKED32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, 1, &offsetCore, &edgeModeCore, &writeMask, 0);
        if (status != CUDA_SUCCESS) {
            goto EXIT;
        }
    }
    else {
        offset[count]  = offsetCore;
        value[count++] = edgeModeCore;
    }
    //Set function registers to 0 initially, will be enabled in startCounters for
    //both kernel and continuous mode
    {
        // setting the function values to 0
        // These values will be set just before the kernel launch
        offset[count]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL1;
        value[count++] = 0;
        offset[count]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL2;
        value[count++] = 0;
        if(pEventGroup->pCtx->pmNew->isMembarWarEnabled) {
            // Using the read-modify-writes to retain the settings done for membar.pending signal
            NvU32 valueCore, writeMask, offsetCore;
            offsetCore  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL3;
            valueCore = 0;
            writeMask = CU_PROF_SM_CORE_FUNCTION_COMBINATION_MASK;
            status = PRIWRITEMASKED32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, 1, &offsetCore, &valueCore, &writeMask, 0);
            if (status != CUDA_SUCCESS) {
                goto EXIT;
            }
        }
        else {
            offset[count]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL3;
            value[count++] = 0;
        }
        offset[count]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER_CONTROL4;
        value[count++] = 0;
    }

    // Each perf counter has 4 bits feeding into a function table.  Each bit
    // can be selected from 1 of 8 bits of 1 of the 8 groups (selected via
    // the PERF_COUNTER_CONTROL_SEL* register above).
    // BIT#_GRP selects 1 of 8 groups
    // BIT#_SIG selects 1 of the 8 signals from that selected group

    idxCore = pEventGroup->pCtx->pmNew->isMembarWarEnabled ? 1 : 0;
    idxQctl = 0;

    for (index = 0; index < pSM->SMCountersAdded; index++) {
        switch(pSM->pmUnitId[index]) {
        case PM_UNIT_SMQCTL:
            switch(idxQctl) {
            case 0:
                offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER0_CONTROL;
                break;
            case 1:
                offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER1_CONTROL;
                break;
            case 2:
                offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER2_CONTROL;
                break;
            case 3:
                offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER3_CONTROL;
                break;
            }
            idxQctl++;
            break;

        case PM_UNIT_SMCORE:
            switch(idxCore) {
            case 0:
                // Skip NV_SM_DSM_PERF_COUNTER4_CONTROL register settings if the WAR is enabled
                if(!pEventGroup->pCtx->pmNew->isMembarWarEnabled) {
                    offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER4_CONTROL;
                }
                break;
            case 1:
                offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER5_CONTROL;
                break;
            case 2:
                offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER6_CONTROL;
                break;
            case 3:
                offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER7_CONTROL;
                break;
            }
            idxCore++;
            break;
        }
        value[count++]  = pSM->perfEventInfo[index];
    }
    CU_ASSERT(count <= numRegs);
    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, count, offset, value, 0);
    if (status != CUDA_SUCCESS) {
        goto EXIT;
    }
EXIT:
    if(offset) {
        free(offset);
    }
    if(value) {
        free(value);
    }
    return status;
}

static CUresult resetPMSMInternal(CUeventGroup *pEventGroup) {
    CUresult status = CUDA_SUCCESS;
    CUresult (*resetSmpcRegs)(CUeventGroup *pEventGroup);

    CU_TRACE_FUNCTION();

    // Call the broadcase version if profileAll option is selected:
    if(pEventGroup->profileAll &&
       pEventGroup->pCtx->device->dmalType != CU_DMAL_MRM) {
        // mrm bug 200118793
        resetSmpcRegs = &resetPMSM_bc;
    }
    // Else. call the unicast version:
    else {
        resetSmpcRegs = &resetPMSM;
    }
    status = (*resetSmpcRegs)(pEventGroup);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Error re-setting the SMPC final value registers\n"));
    }
    return status;
}

static CUresult resetPMSM(CUeventGroup *pEventGroup) {
    CUresult status = CUDA_SUCCESS;
    NvU32 gpcTarget = 0, tpcTarget = 0, gpcId = 0, tpcId = 0, smId = 0;
    NvU32 *offset, coreRegCount = 0;
    NvU8  quadrant = 0;
    NvU32 *values;
#if !defined(NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_QUAD)
    NvU32 offsetTemp[4];
    NvU32 valuesTemp[4];
#else
    NvU32 *quadOffsets = NULL;
    NvU8  *quads = NULL;
    NvU32 quadRegCount = 0;
#endif

    CU_TRACE_FUNCTION();

    //Allocate memory of size = ((#quadCounters * 4) + #coreCounters) * #SMs * sizeof(NvU32))
    offset = (NvU32 *)malloc(CU_PROF_SM_CORE_PROFILED_MAX_GK10x * pEventGroup->instanceCountAvail * sizeof(NvU32));
    //Allocate values array for quad as quad requires the biggest array
    values = (NvU32 *)calloc((4 * CU_PROF_SM_QUAD_PROFILED_MAX) * pEventGroup->instanceCountAvail, sizeof(NvU32));

    if(!(offset && values)) {
        CU_ERROR_PRINT(("Error allocating memory for offset-value arrays.\n"));
        status = (CUresult)CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

#if defined(NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_QUAD)
    quadOffsets = (NvU32 *)malloc((4 * CU_PROF_SM_QUAD_PROFILED_MAX) * pEventGroup->instanceCountAvail * sizeof(NvU32));
    quads = (NvU8 *)malloc((4 * CU_PROF_SM_QUAD_PROFILED_MAX) * pEventGroup->instanceCountAvail * sizeof(NvU8));
    if(!(quadOffsets && values && quads)) {
        CU_ERROR_PRINT(("Error allocating memory for quad offset-value arrays.\n"));
        status = (CUresult)CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }
#endif

    for(gpcId = 0; gpcId < pEventGroup->arch.keplerEventGroup->gpcCount; gpcId++)
    {
        for(tpcId = 0; tpcId < pEventGroup->arch.keplerEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
        {
            if(pEventGroup->arch.keplerEventGroup->pmUnitMask & (1<<smId))
            {
                gpcTarget = gpcId;
                tpcTarget = tpcId;

                // For qctl counters:
#if defined(NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_QUAD)
                for(quadrant = 0; quadrant < 4; quadrant++) {
                    quadOffsets[quadRegCount] = NV_SM_DSM_PERF_COUNTER0(gpcTarget, tpcTarget); //COUNTER0
                    quads[quadRegCount] = quadrant;
                    quadRegCount++;
                    quadOffsets[quadRegCount] = NV_SM_DSM_PERF_COUNTER1(gpcTarget, tpcTarget); //COUNTER0
                    quads[quadRegCount] = quadrant;
                    quadRegCount++;
                    quadOffsets[quadRegCount] = NV_SM_DSM_PERF_COUNTER2(gpcTarget, tpcTarget); //COUNTER0
                    quads[quadRegCount] = quadrant;
                    quadRegCount++;
                    quadOffsets[quadRegCount] = NV_SM_DSM_PERF_COUNTER3(gpcTarget, tpcTarget); //COUNTER0
                    quads[quadRegCount] = quadrant;
                    quadRegCount++;
                }
#else
                for(quadrant = 0; quadrant < 4; quadrant++)
                {
                    offsetTemp[0]  = NV_SM_DEBUG_SFE_CONTROL(gpcId, tpcId);
                    offsetTemp[1]  = NV_SM_HALFCTL_CTRL(gpcId, tpcId);

                    status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, 2, offsetTemp, valuesTemp, 0);

                    valuesTemp[0] &= 0xfffffffe;
                    valuesTemp[1] &= 0xffffffef;

                    valuesTemp[0] |= ((quadrant & 0x2) >> 1);
                    valuesTemp[1] |= ((quadrant & 0x1) << 4);;

                    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, 2, offsetTemp, valuesTemp, 0);

                    if (CUDA_SUCCESS != status) {
                        //return status;
                        goto EXIT;
                    }

                    // reset perf counter values
                    offsetTemp[0]  = NV_SM_DSM_PERF_COUNTER0(gpcId, tpcId);
                    offsetTemp[1]  = NV_SM_DSM_PERF_COUNTER1(gpcId, tpcId);
                    offsetTemp[2]  = NV_SM_DSM_PERF_COUNTER2(gpcId, tpcId);
                    offsetTemp[3]  = NV_SM_DSM_PERF_COUNTER3(gpcId, tpcId);

                    //use values array for value 0.
                    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, CU_PROF_SM_QUAD_PROFILED_MAX, offsetTemp, values, 0);
                    if (CUDA_SUCCESS != status) {
                        //return status;
                        goto EXIT;
                    }
                }
#endif
                if(pEventGroup->pCtx->pmNew->isMembarWarEnabled) {
                // NV_SM_DSM_PERF_COUNTER4 will now be used by membar.pending signal.
                    offset[coreRegCount++]  = NV_SM_DSM_PERF_COUNTER5(gpcTarget, tpcTarget);
                    offset[coreRegCount++]  = NV_SM_DSM_PERF_COUNTER6(gpcTarget, tpcTarget);
                    offset[coreRegCount++]  = NV_SM_DSM_PERF_COUNTER7(gpcTarget, tpcTarget);
                }
                else {
                    offset[coreRegCount++]  = NV_SM_DSM_PERF_COUNTER4(gpcTarget, tpcTarget);
                    offset[coreRegCount++]  = NV_SM_DSM_PERF_COUNTER5(gpcTarget, tpcTarget);
                    offset[coreRegCount++]  = NV_SM_DSM_PERF_COUNTER6(gpcTarget, tpcTarget);
                    offset[coreRegCount++]  = NV_SM_DSM_PERF_COUNTER7(gpcTarget, tpcTarget);
                }
            }
            smId++;
        }
    }

    //Write all quad and core counters together
    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, coreRegCount, offset, values, 0);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Error reseting core registers.\n"));
        goto EXIT;
    }
#if defined(NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_QUAD)
    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT_QUAD, quadRegCount, quadOffsets, values, quads);
    if (CUDA_SUCCESS != status) {
        CU_ERROR_PRINT(("Error reseting quad registers.\n"));
        goto EXIT;
    }
#endif

    free(offset);
    free(values);

#if defined(NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_QUAD)
    free(quadOffsets);
    free(quads);
#endif

    return status;
EXIT:
    if (offset) {
        free (offset);
    }
    if (values) {
        free (values);
    }
#if defined(NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_QUAD)
    if (quadOffsets) {
        free (quadOffsets);
    }
    if (quads) {
        free (quads);
    }
#endif
    return status;
}

static CUresult resetPMSM_bc(CUeventGroup *pEventGroup) {
    CUresult status = CUDA_SUCCESS;
    NvU32 *offset, coreRegCount = 0;
    NvU8  quadrant = 0;
    NvU32 *values;
#if !defined(NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_QUAD)
    NvU32 offsetTemp[4];
    NvU32 valuesTemp[4];
#else
    NvU32 *quadOffsets = NULL;
    NvU8  *quads = NULL;
    NvU32 quadRegCount = 0;
#endif

    CU_TRACE_FUNCTION();

    //Allocate memory of size = ((#quadCounters * 4) + #coreCounters) * #SMs * sizeof(NvU32))
    offset = (NvU32 *)malloc(CU_PROF_SM_CORE_PROFILED_MAX_GK10x * sizeof(NvU32));
    //Allocate values array for quad as quad requires the biggest array
    values = (NvU32 *)calloc((4 * CU_PROF_SM_QUAD_PROFILED_MAX), sizeof(NvU32));

    if(!(offset && values)) {
        CU_ERROR_PRINT(("Error allocating memory for offset-value arrays.\n"));
        status = (CUresult)CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

#if defined(NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_QUAD)
    quadOffsets = (NvU32 *)malloc((4 * CU_PROF_SM_QUAD_PROFILED_MAX) * sizeof(NvU32));
    quads = (NvU8 *)malloc((4 * CU_PROF_SM_QUAD_PROFILED_MAX) * sizeof(NvU8));
    if(!(quadOffsets && values && quads)) {
        CU_ERROR_PRINT(("Error allocating memory for quad offset-value arrays.\n"));
        status = (CUresult)CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }
#endif

    // For qctl counters:
#if defined(NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_QUAD)
    for(quadrant = 0; quadrant < 4; quadrant++) {
        quadOffsets[quadRegCount] = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER0; //COUNTER0
        quads[quadRegCount] = quadrant;
        quadRegCount++;
        quadOffsets[quadRegCount] = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER1; //COUNTER0
        quads[quadRegCount] = quadrant;
        quadRegCount++;
        quadOffsets[quadRegCount] = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER2; //COUNTER0
        quads[quadRegCount] = quadrant;
        quadRegCount++;
        quadOffsets[quadRegCount] = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER3; //COUNTER0
        quads[quadRegCount] = quadrant;
        quadRegCount++;
    }
#else
    for(quadrant = 0; quadrant < 4; quadrant++)
    {
        offsetTemp[0]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DEBUG_SFE_CONTROL;
        offsetTemp[1]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_HALFCTL_CTRL;

        status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, 2, offsetTemp, valuesTemp, 0);

        valuesTemp[0] &= 0xfffffffe;
        valuesTemp[1] &= 0xffffffef;

        valuesTemp[0] |= ((quadrant & 0x2) >> 1);
        valuesTemp[1] |= ((quadrant & 0x1) << 4);;

        status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, 2, offsetTemp, valuesTemp, 0);

        if (CUDA_SUCCESS != status) {
            //return status;
            goto EXIT;
        }

        // reset perf counter values
        offsetTemp[0]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER0;
        offsetTemp[1]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER1;
        offsetTemp[2]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER2;
        offsetTemp[3]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER3;

        //use values array for value 0.
        status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, CU_PROF_SM_QUAD_PROFILED_MAX, offsetTemp, values, 0);
        if (CUDA_SUCCESS != status) {
            //return status;
            goto EXIT;
        }
    }
#endif
    if(pEventGroup->pCtx->pmNew->isMembarWarEnabled) {
    // NV_SM_DSM_PERF_COUNTER4 will now be used by membar.pending signal.
        offset[coreRegCount++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER5;
        offset[coreRegCount++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER6;
        offset[coreRegCount++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER7;
    }
    else {
        offset[coreRegCount++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER4;
        offset[coreRegCount++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER5;
        offset[coreRegCount++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER6;
        offset[coreRegCount++]  = NV_PGRAPH_PRI_GPCS_TPCS_SM_DSM_PERF_COUNTER7;
    }

    //Write all quad and core counters together
    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, coreRegCount, offset, values, 0);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Error reseting core registers.\n"));
        goto EXIT;
    }
#if defined(NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_QUAD)
    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT_QUAD, quadRegCount, quadOffsets, values, quads);
    if (CUDA_SUCCESS != status) {
        CU_ERROR_PRINT(("Error reseting quad registers.\n"));
        goto EXIT;
    }
#endif

    free(offset);
    free(values);

#if defined(NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_QUAD)
    free(quadOffsets);
    free(quads);
#endif

    return status;
EXIT:
    if (offset) {
        free (offset);
    }
    if (values) {
        free (values);
    }
#if defined(NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_QUAD)
    if (quadOffsets) {
        free (quadOffsets);
    }
    if (quads) {
        free (quads);
    }
#endif
    return status;
}

static CUresult logPMCountersSMInternal(CUeventGroup *pEventGroup) {
    CUresult status = CUDA_SUCCESS;
    NvU32 gpcId = 0, tpcId = 0, smId = 0;
    NvU32 offset[8] = {0};
    NvU64 counterValuesQctl[4] = {0};
    NvU32 counterValuesCore[4] = {0};
    NvU32 counterValues[4] = {0};
    NvU8 quadrant = 0, i = 0;
#if !defined(NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_QUAD)
    NvU32 values[2] = {0};
#else
    NvU8 quads[CU_PROF_SM_QUAD_PROFILED_MAX];
#endif
    NvU32 idxQctl = 0, idxCore = 0;
    CUSMCtrInfo     *pSM = NULL;

    CU_TRACE_FUNCTION();
    pSM = pEventGroup->arch.keplerEventGroup->pSM;

    for(gpcId = 0; gpcId < pEventGroup->arch.keplerEventGroup->gpcCount; gpcId++)
    {
        for(tpcId = 0; tpcId < pEventGroup->arch.keplerEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
        {
            if(pEventGroup->arch.keplerEventGroup->pmUnitMask & (1<<smId))
            {
                if (pSM->qctlCount) {

                    // The values from each quad is added in counterValuesQctl
                    // This sum can exceed 64 bit, hence counterValuesQctl is a 64 bit data type
                    cuosMemset(counterValuesQctl, 0, sizeof(NvU64)*4);
#if defined(NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_QUAD)
                    for(quadrant = 0; quadrant < 4; quadrant++)
                    {
                        // read back perf counter values
                        offset[0]  = NV_SM_DSM_PERF_COUNTER0(gpcId, tpcId);
                        offset[1]  = NV_SM_DSM_PERF_COUNTER1(gpcId, tpcId);
                        offset[2]  = NV_SM_DSM_PERF_COUNTER2(gpcId, tpcId);
                        offset[3]  = NV_SM_DSM_PERF_COUNTER3(gpcId, tpcId);

                        quads[0] = quadrant;
                        quads[1] = quadrant;
                        quads[2] = quadrant;
                        quads[3] = quadrant;

                        status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT_QUAD, 4, offset, counterValues, quads);
                        if (CUDA_SUCCESS != status) {
                            goto EXIT;
                        }

                        // accumulate quad counter values into buffer
                        for(i=0; i<4; i++) {
                            counterValuesQctl[i] += counterValues[i];
                        }
                    }
#else
                    for(quadrant = 0; quadrant < 4; quadrant++)
                    {
                        offset[0]  = NV_SM_DEBUG_SFE_CONTROL(gpcId, tpcId);
                        offset[1]  = NV_SM_HALFCTL_CTRL(gpcId, tpcId);

                        status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, 2, offset, values, 0);

                        values[0] &= 0xfffffffe;
                        values[1] &= 0xffffffef;

                        values[0] |= ((quadrant & 0x2) >> 1);
                        values[1] |= ((quadrant & 0x1) << 4);;

                        status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, 2, offset, values, 0);

                        if (CUDA_SUCCESS != status) {
                            goto EXIT;
                        }

                        // read back perf counter values
                        offset[0]  = NV_SM_DSM_PERF_COUNTER0(gpcId, tpcId);
                        offset[1]  = NV_SM_DSM_PERF_COUNTER1(gpcId, tpcId);
                        offset[2]  = NV_SM_DSM_PERF_COUNTER2(gpcId, tpcId);
                        offset[3]  = NV_SM_DSM_PERF_COUNTER3(gpcId, tpcId);

                        status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, 4, offset, counterValues, 0);
                        if (CUDA_SUCCESS != status) {
                            goto EXIT;
                        }

                        // accumulate quad counter values into buffer
                        for(i=0; i<4; i++) {
                            counterValuesQctl[i] += counterValues[i];
                        }
                    }
#endif
                }

                if (pSM->coreCount) {
                    if(pEventGroup->pCtx->pmNew->isMembarWarEnabled) {
                        // NV_SM_DSM_PERF_COUNTER4 will now be used by membar.pending signal.
                        offset[0]  = NV_SM_DSM_PERF_COUNTER5(gpcId, tpcId);
                        offset[1]  = NV_SM_DSM_PERF_COUNTER6(gpcId, tpcId);
                        offset[2]  = NV_SM_DSM_PERF_COUNTER7(gpcId, tpcId);
                        status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, CU_PROF_SM_CORE_PROFILED_MAX_GK110, offset, counterValuesCore, 0);
                    }
                    else {
                        offset[0]  = NV_SM_DSM_PERF_COUNTER4(gpcId, tpcId);
                        offset[1]  = NV_SM_DSM_PERF_COUNTER5(gpcId, tpcId);
                        offset[2]  = NV_SM_DSM_PERF_COUNTER6(gpcId, tpcId);
                        offset[3]  = NV_SM_DSM_PERF_COUNTER7(gpcId, tpcId);
                        status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, CU_PROF_SM_CORE_PROFILED_MAX_GK10x, offset, counterValuesCore, 0);
                    }
                    if (CUDA_SUCCESS != status) {
                        goto EXIT;
                    }
                }

                idxQctl = 0;
                idxCore = 0;

                // rearrange counter values
                for(i=0; i<pSM->SMCountersAdded; i++) {
                    switch (pSM->pmUnitId[i]) {
                    case PM_UNIT_SMQCTL:
                        *(pSM->values +pSM->SMCountersAdded * smId + i) = counterValuesQctl[idxQctl];
                        idxQctl++;
                        break;
                    case PM_UNIT_SMCORE:
                        *(pSM->values + pSM->SMCountersAdded * smId + i) = counterValuesCore[idxCore];
                        idxCore++;
                        break;
                    }
                }
            }
            smId++;
        }
    }

EXIT:
    return status;
}

void keplerPerfmonStartCounters(CUnvCurrent** nvCurrent_temp, CUeventGroup *pEventGroup)
{
    // Set the function values only if domanin = SMPerf
    if((pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_SMPERF) ||
    (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW) ||
    (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW)) {
        if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_KERNEL) {
        NvU32 valueA = 0;
        NvU32 index;
        NvU32 func[8] = {0};
        NvU32 mode[8] = {0};
        NvU32 idxQctl = 0, idxCore;
        CUSMCtrInfo     *pSM = NULL;

            CUnvCurrent* nvCurrent = *nvCurrent_temp;
        pSM = pEventGroup->arch.keplerEventGroup->pSM;
        idxCore = pEventGroup->pCtx->pmNew->isMembarWarEnabled ? 1 : 0;

        for (index = 0; index < pSM->SMCountersAdded; index++) {
            switch(pSM->pmUnitId[index]) {
            case PM_UNIT_SMQCTL:
                func[idxQctl] = pSM->function[index];
                mode[idxQctl] = pSM->mode[index];
                idxQctl++;
                break;
            case PM_UNIT_SMCORE:
                func[idxCore+4] = pSM->function[index];
                mode[idxCore+4] = pSM->mode[index];
                idxCore++;
                break;
            }
        }

        for (index = 0; index < CU_PROF_PM_SM_MAX_COUNTERS; index++) {
            if(pEventGroup->pCtx->pmNew->isMembarWarEnabled) {
                // The settings for membar.pending signal should remain unchanged
                if(index == CU_PROF_SM_SLOT_MEMBAR_WAR) {
                    continue;
                }
            }
            // Zero out the counter values before starting the counters:
            valueA = HWVALUE(A0C0, SET_SHADER_PERFORMANCE_COUNTER_VALUE, V, 0);
            NV_PUSH_1U(A0C0, SET_SHADER_PERFORMANCE_COUNTER_VALUE(index),  valueA);
            // set MODE as well else it will be reset to 0 (LUT):
            valueA = HWVALUE(A0C0, SET_SHADER_PERFORMANCE_COUNTER_CONTROL_B, FUNC, func[index]);
            valueA |= HWVALUE(A0C0, SET_SHADER_PERFORMANCE_COUNTER_CONTROL_B, MODE, mode[index]);
            NV_PUSH_1U(A0C0, SET_SHADER_PERFORMANCE_COUNTER_CONTROL_B(index),  valueA);
        }
            *nvCurrent_temp = nvCurrent;
        } else if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS){
            CUresult status = CUDA_SUCCESS;
            NvU32 idxQctl = 0, idxCore = 0, index = 0, count = 0;
            NvU32 *offset = NULL, gpcId = 0, tpcId = 0, smId = 0;
            NvU32 *value = NULL;
            CUSMCtrInfo *pSM = NULL;

            NvU32 funcQctl[2] = {0};
            NvU32 funcCore[2] = {0};
            //Allocate memory of size = (4 * #SMs * sizeof(NvU32))
            offset = (NvU32 *)malloc(4 * pEventGroup->instanceCountAvail * sizeof(NvU32));
            value = (NvU32 *)calloc(4 * pEventGroup->instanceCountAvail, sizeof(NvU32));
            if(!(offset && value)) {
                CU_ERROR_PRINT(("Error allocating memory for offset-value arrays.\n"));
                goto EXIT;
            }
            pSM = pEventGroup->arch.keplerEventGroup->pSM;
            for(gpcId = 0; gpcId < pEventGroup->arch.keplerEventGroup->gpcCount; gpcId++)
            {
                for(tpcId = 0; tpcId < pEventGroup->arch.keplerEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
                {
                    if(pEventGroup->arch.keplerEventGroup->pmUnitMask & (1<<smId))
                    {
                        // function combination
                        // FUNC0 - 15:0, FUNC1 - 31:16
                        idxCore = pEventGroup->pCtx->pmNew->isMembarWarEnabled ? 1 : 0;
                        idxQctl = 0;
                        for (index = 0; index < pSM->SMCountersAdded; index++) {
                            switch(pSM->pmUnitId[index]) {
                            case PM_UNIT_SMQCTL:
                                if(idxQctl & 1) {
                                    funcQctl[idxQctl>>1] |= pSM->function[index] << 16;
                                }
                                else {
                                    funcQctl[idxQctl>>1] |= pSM->function[index];
    }
                                idxQctl++;
                                break;
                            case PM_UNIT_SMCORE:
                                if(idxCore & 1) {
                                    funcCore[idxCore>>1] |= pSM->function[index] << 16;
                                }
                                else {
                                    funcCore[idxCore>>1] |= pSM->function[index];
                                }
                                idxCore++;
                                break;
                            }
                        }
                        offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL1(gpcId, tpcId);
                        value[count++] = funcQctl[0];
                        offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL2(gpcId, tpcId);
                        value[count++] = funcQctl[1];
                        if(pEventGroup->pCtx->pmNew->isMembarWarEnabled) {
                            // Using the read-modify-writes to retain the settings done for membar.pending signal
                            NvU32 valueCore, writeMask, offsetCore;
                            offsetCore  = NV_SM_DSM_PERF_COUNTER_CONTROL3(gpcId, tpcId);
                            valueCore = funcCore[0];
                            writeMask = CU_PROF_SM_CORE_FUNCTION_COMBINATION_MASK;
                            status = PRIWRITEMASKED32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, 1, &offsetCore, &valueCore, &writeMask, 0);
                            if (status != CUDA_SUCCESS) {
                                goto EXIT;
                            }
                        }
                        else {
                            offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL3(gpcId, tpcId);
                            value[count++] = funcCore[0];
                        }
                        offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL4(gpcId, tpcId);
                        value[count++] = funcCore[1];
                    }
                    smId++;
                }
            }
            CU_ASSERT(count <= (4 * pEventGroup->instanceCountAvail));
            status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, count, offset, value, 0);
            CU_ASSERT(status == CUDA_SUCCESS);
EXIT:
            if(offset) {
                free(offset);
            }
            if(value) {
                free(value);
            }
        }
    }
}

void keplerPerfmonStopCounters(CUnvCurrent** nvCurrent_temp, CUeventGroup *pEventGroup)
{
    // Reset the function values only if domanin = SMPerf
    if((pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_SMPERF) ||
    (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW) ||
    (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW)) {
        if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_KERNEL) {
            CUnvCurrent* nvCurrent = *nvCurrent_temp;

            NvU32 valueA = 0;
            NvU32 index;
            for (index = 0; index < CU_PROF_PM_SM_MAX_COUNTERS; index++) {
                if(pEventGroup->pCtx->pmNew->isMembarWarEnabled) {
                    // The settings for membar.pending signal should remain unchanged
                    if(index == CU_PROF_SM_SLOT_MEMBAR_WAR) {
                        continue;
                    }
                }
                valueA = HWVALUE(A0C0, SET_SHADER_PERFORMANCE_COUNTER_CONTROL_B, FUNC, 0);
                NV_PUSH_1U(A0C0, SET_SHADER_PERFORMANCE_COUNTER_CONTROL_B(index),  valueA);
            }
            *nvCurrent_temp = nvCurrent;
        } else {

            //Stop the counters in continuous mode. SM counters keep running unless we set the func to 0.
            NvU32 *value  = NULL, *offset = NULL;
            NvU32 count = 0, gpcId = 0, tpcId = 0, smId = 0;
            CUresult status = CUDA_SUCCESS;

            //Allocate memory of size = (4 * #SMs * sizeof(NvU32))
            offset = (NvU32 *)malloc(4 * pEventGroup->instanceCountAvail * sizeof(NvU32));
            value = (NvU32 *)calloc(4 * pEventGroup->instanceCountAvail, sizeof(NvU32));
            if(!(offset && value)) {
                CU_ERROR_PRINT(("Error allocating memory for offset-value arrays.\n"));
                goto EXIT;
            }
            for(gpcId = 0; gpcId < pEventGroup->arch.keplerEventGroup->gpcCount; gpcId++)
            {
                for(tpcId = 0; tpcId < pEventGroup->arch.keplerEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
                {
                    if(pEventGroup->arch.keplerEventGroup->pmUnitMask & (1<<smId))
                    {
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_CONTROL1(gpcId, tpcId);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_CONTROL2(gpcId, tpcId);
                        if(pEventGroup->pCtx->pmNew->isMembarWarEnabled) {
                            NvU32 valueCore, offsetCore, writeMask;
                            // Using the read-modify-writes to retain the settings done for membar.pending signal
                            offsetCore  = NV_SM_DSM_PERF_COUNTER_CONTROL3(gpcId, tpcId);
                            valueCore = 0;
                            writeMask = CU_PROF_SM_CORE_FUNCTION_COMBINATION_MASK;
                            status = PRIWRITEMASKED32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, 1, &offsetCore, &valueCore, &writeMask, 0);
                            CU_ASSERT(status == CUDA_SUCCESS);
                        }
                        else {
                            offset[count++]  = NV_SM_DSM_PERF_COUNTER_CONTROL3(gpcId, tpcId);
                        }
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_CONTROL4(gpcId, tpcId);
                    }
                    smId++;
                }
            }
            CU_ASSERT(count <= (4 * pEventGroup->instanceCountAvail));
            status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, count, offset, value, 0);
            CU_ASSERT(status == CUDA_SUCCESS);
EXIT:
            if(offset) {
                free(offset);
            }
            if(value) {
                free(value);
            }
        }
    }
}

//TBD change this api to accept device when device level streaming is implemented.
CUprofResult keplerPerfmonEventSamplingSetConfig(CUctx *ctx, CUprofSamplingConfig *config) {
    //TBD Hardcoding now, since the period is in cycles, it will vary from gpu to gpu.
    //We can decide after the experiments what is the better value to derive any good
    //conclusion about app.
    switch(config->period) {
    case CUPROF_SAMPLING_PERIOD_MIN:
        ctx->pmNew->samplingPeriod = NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES_1K;
        break;
    case CUPROF_SAMPLING_PERIOD_LOW:
        ctx->pmNew->samplingPeriod = NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES_4K;
        break;
    case CUPROF_SAMPLING_PERIOD_MID:
        ctx->pmNew->samplingPeriod = NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES_16K;
        break;
    case CUPROF_SAMPLING_PERIOD_HIGH:
        ctx->pmNew->samplingPeriod = NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES_32K;
        break;
    case CUPROF_SAMPLING_PERIOD_MAX:
        ctx->pmNew->samplingPeriod = NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES_64K;
        break;
    default:
        ctx->pmNew->samplingPeriod = NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES_1K;
    }
    return CUPROF_SUCCESS;
}
