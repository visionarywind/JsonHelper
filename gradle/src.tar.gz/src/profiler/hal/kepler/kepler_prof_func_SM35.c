/*
 * Copyright 2005-2011 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

#include "kepler_prof_func_SM35.h"
#include "hal/kepler/kepler_structs.h"

#define MASK_BITS_LD_ST_INST       0xe700000000000003ULL

#define LD_INST_U8BIT_OPCODE       0xc000000000000000ULL
#define LD_INST_S8BIT_OPCODE       0xc100000000000000ULL
#define LD_INST_U16BIT_OPCODE      0xc200000000000000ULL
#define LD_INST_S16BIT_OPCODE      0xc300000000000000ULL
#define LD_INST_32BIT_OPCODE       0xc400000000000000ULL
#define LD_INST_64BIT_OPCODE       0xc500000000000000ULL
#define LD_INST_128BIT_OPCODE      0xc600000000000000ULL
#define LD_INST_U128BIT_OPCODE     0xc700000000000000ULL // Signifies LD.U.128
#define ST_INST_U8BIT_OPCODE       0xe000000000000000ULL
#define ST_INST_S8BIT_OPCODE       0xe100000000000000ULL
#define ST_INST_U16BIT_OPCODE      0xe200000000000000ULL
#define ST_INST_S16BIT_OPCODE      0xe300000000000000ULL
#define ST_INST_32BIT_OPCODE       0xe400000000000000ULL
#define ST_INST_64BIT_OPCODE       0xe500000000000000ULL
#define ST_INST_128BIT_OPCODE      0xe600000000000000ULL

#define MASK_BITS_TEX_INST         0xffff800000000003ULL

#define TEX_INST_U8BIT_OPCODE      0x6000000000000001ULL
#define TEX_INST_S8BIT_OPCODE      0x6000800000000001ULL
#define TEX_INST_U16BIT_OPCODE     0x6001000000000001ULL
#define TEX_INST_S16BIT_OPCODE     0x6001800000000001ULL
#define TEX_INST_32BIT_OPCODE      0x6002000000000001ULL
#define TEX_INST_64BIT_OPCODE      0x6002800000000001ULL
#define TEX_INST_128BIT_OPCODE     0x6003000000000001ULL

#define MASK_BITS_TLD_INST         0xffffe00000000003ULL

#define TLD_INST_U8BIT_OPCODE      0xc000000000000002ULL
#define TLD_INST_S8BIT_OPCODE      0xc100200000000002ULL
#define TLD_INST_U16BIT_OPCODE     0xc200400000000002ULL
#define TLD_INST_S16BIT_OPCODE     0xc300600000000002ULL
#define TLD_INST_32BIT_OPCODE      0xc400800000000002ULL
#define TLD_INST_64BIT_OPCODE      0xc500a00000000002ULL
#define TLD_INST_128BIT_OPCODE     0xc600c00000000002ULL

// SM Version 3.5 specific Patch code
NvU32 keplerSM35ConcKernelTraceEntryBinaryPatch[] = {
                                        0x299c0006, 0x86400000, // 1  S2R        R1, SR83;                  # globalTimer Hi
                                        0x291c0002, 0x86400000, // 2  S2R        R0, SR82;                  # globalTimer Lo
                                        0x299c0012, 0x86400000, // 3  S2R        R4, SR83;                  # globalTimer Hi
                                        0x021c0406, 0xda180000, // 4  ICMP.LT    R1, R1, R4, R0;            # if(R0 < 0) R1 = R1, else R1 = R4
                                        0x129c000a, 0x86400000, // 5  S2R        R2, SR_CTAid.X;            # load block.x
                                        0x131c000e, 0x86400000, // 6  S2R        R3, SR_CTAid.Y;            # load block.y
                                        0x139c0012, 0x86400000, // 7  S2R        R4, SR_CTAid.Z;            # load block.z
                                        0x019c080a, 0xe0800000, // 8  IADD       R2, R2, R3;                # add block.x + block.y
                                        0x28000000, 0x14800000, // 9  SSY <inst 20>;                        # Create sync point at instruction #20
                                        0x001c103d, 0xb3281c00, // 10 ISETP.EQ      P1, R4, 0x0;            # P1 = (block.z == 0)
                                        0x001c0825, 0xb3280400, // 11 ISETP.EQ.AND  P1, P1, R2, 0x0, P1;    # P1 = (block.x + block.y) == 0 && block.z == 0)
                                        0x1824003c, 0x12000000, // 12 @!P1 BRA Lab1;                        # if !(block == 0) return
                                        0x101c0012, 0x86400000, // 13 S2R           R4, SR_Tid;             # load thread id (all 3 components)
                                        0x001c103d, 0xb3281c00, // 14 ISETP.EQ      P1, R4, 0x0;            # P1 = (thread == 0)
                                        0x001c03fe, 0x86ca0400, // 15 VOTE.ANY      P2, P1;                 # P2 = (warp == 0)
                                        0x0828003c, 0x12000000, // 16 @!P2 BRA Lab1;                        # if !(warp == 0) return
                                        0x041ffc12, 0x7ca80880, // 17 LDC.64        R4, c[17][8];           # .rela { ImmConstant, BaseAddress, 0x0 }
                                        0x00041000, 0xe5800000, // 18 @P1 ST.E.64   [R4], R0;               # Store Clock
                                        0x005c3c02, 0x85800000, // 19 Lab1: NOP.S;                          # Sync instruction for earlier divergence
                                        0x08000000, 0x14000000, // 20 PLONGJMP 0x18;                        # Prepare LONGJMP target to start of exit patch
                                        0x00000100, 0x11000000, // 21 JCAL 0X0;                             # JCAL start of kernel
                                        0x001c003c, 0x18800000, // 22 LONGJMP;                              # LONGJMP to exitpatch
};

NvU32 keplerSM35ConcKernelTraceExitBinaryPatch[] = {
                                        //exit patch//
                                        0x001c0012, 0x86400000, //  1 S2R           R4, SR_LaneId;
                                        0x001c103d, 0xb3281c00, //  2 ISETP.EQ      P1, R4, 0;
                                        0x299c0006, 0x86400000, //  3 S2R           R1, SR83;               # globalTimer Hi
                                        0x291c0002, 0x86400000, //  4 S2R           R0, SR82;               # globalTimer Lo
                                        0x299c0012, 0x86400000, //  5 S2R           R4, SR83;               # globalTimer Hi
                                        0x021c0406, 0xda180000, //  6 ICMP.LT       R1, R1, R4, R0;         # if(R0 < 0) R1 = R1, else R1 = R4
                                        0x041ffc12, 0x7ca80880, //  7 LDC.64        R4, c[17][8];           # Load buffer address from cbank
                                        0x08041000, 0xe5800000, //  8 @P1 ST.E.64   [R4+16], R0;            # Store Clock
                                        0x001c003c, 0x18000000, //  9 EXIT;                                 # exit code
                                    };

// Initializing ConcKernelTraceTable for SM 3.5
ConcKernelTraceTable SM35ConcKernelTraceTable = {
    CU_KEPLER_SM35_CONC_KERNEL_JCAL_START_INST_PATCH,
    CU_KEPLER_SM35_CONC_KERNEL_LDC_INST_ENTRY_PATCH,
    CU_KEPLER_SM35_CONC_KERNEL_LDC_INST_EXIT_PATCH,
    CU_KEPLER_SM35_CONC_KERNEL_TRACE_ENTRY_PATCH_SIZE,
    CU_KEPLER_SM35_CONC_KERNEL_TRACE_EXIT_PATCH_SIZE,
    CU_KEPLER_SM35_CONC_KERNEL_TRACE_ENTRY_PATCH_PTR,
    CU_KEPLER_SM35_CONC_KERNEL_TRACE_EXIT_PATCH_PTR,
};

static NvU32 keplerSM35GetCCCBits(NvU32 code)
{
    return (CU_KEPLER_SM35_GET_CCC_BITS(code));
}

static NvU32 keplerSM35GetPRegBits(NvU32 code)
{
    return (CU_KEPLER_SM35_GET_P_REG_BITS(code));
}

static NvU32 keplerSM35IsExitInst(NvU32 instrHi, NvU32 instrLo)
{
    return (CU_KEPLER_SM35_IS_EXIT_INSTR(instrHi, instrLo));
}

// Function to create Branch Instruction
static void keplerSM35CreateBraInst(NvU32* instHi, NvU32* instLo, NvU32 PRegBitsVal, NvU32 cccBitsVal, NvU32 branchTarget)
{
    CU_KEPLER_SM35_CREATE_BRANCH_INSTR(*instHi, *instLo, PRegBitsVal, cccBitsVal, branchTarget);
}

static void keplerSM35CreateLdcInst(NvU32* instHi, NvU32* instLo, NvU32 cBank, NvU32 offset, NvU32 dest, NvU32 PReg)
{
    CU_KEPLER_SM35_CREATE_LDC64_INSTR(*instHi, *instLo, cBank, offset, dest, PReg);
}

static NvU32 keplerSM35GetLDExrAddr(unsigned int origInstrHi)
{
    return (CU_KEPLER_SM35_GET_LD_EXT_ADDR(origInstrHi));
}

static NvU32 keplerSM35GetLDAddrReg(unsigned int origInstrLo)
{
    return (CU_KEPLER_SM35_GET_LD_ADDR_REG(origInstrLo));
}

static NvU32 keplerSM35GetLDImm32(unsigned int origInstrHi, unsigned int origInstrLo)
{
    return (CU_KEPLER_SM35_GET_LD_IMM32(origInstrHi, origInstrLo));
}

static void keplerSM35CreateStlInst(NvU32 *instrHi, NvU32 *instrLo, NvU32 lmemAddr, NvU32 reg)
{
    *instrHi = STL_HI(lmemAddr, reg);
    *instrLo = STL_LO(lmemAddr, reg);
}

static void keplerSM35CreateP2rInst(NvU32 *instrHi, NvU32 *instrLo, NvU32 reg)
{
    *instrHi = P2R_HI(reg);
    *instrLo = P2R_LO(reg);
}

static void keplerSM35CreateLdlInst(NvU32 *instrHi, NvU32 *instrLo, NvU32 reg, NvU32 lmemAddr)
{
    *instrHi = LDL_HI(reg, lmemAddr);
    *instrLo = LDL_LO(reg, lmemAddr);
}

// Function to create Move Instruction
static void keplerSM35CreateMovInst(NvU32 *instrHi, NvU32 *instrLo, NvU32 destReg, NvU32 sourceReg)
{
    CU_KEPLER_SM35_CREATE_MOV_INSTR(*instrHi, *instrLo, destReg, sourceReg)
}

// Function to create Move32I Instruction
static void keplerSM35CreateMov32iInst(NvU32 *instrHi, NvU32 *instrLo, NvU32 reg, NvU32 value, NvU32 predReg)
{
    CU_KEPLER_SM35_CREATE_MOV32I_INSTR(*instrHi, *instrLo, reg, value, predReg)
}

static void keplerSM35CreateRedInst(NvU32 *instrHi, NvU32 *instrLo, NvU32 regA, NvU32 regB, NvU32 PRegBits)
{
    *instrHi = RED_U32_ADD_HI(regA, regB);
    *instrLo = RED_U32_ADD_LO(regA, regB, PRegBits);
}

static void keplerSM35CreateR2pInst(NvU32 *instrHi, NvU32 *instrLo, NvU32 reg)
{
    *instrHi = R2P_HI(reg);
    *instrLo = R2P_LO(reg);
}

static NvU32 keplerSM35CreateSrcBFieldFromRegister(NvU32 reg)
{
    return(CU_KEPLER_SM35_CREATE_SRC_B_FIELD_FROM_REGISTER(reg));
}

static NvU32 keplerSM35CreateSrcBFieldFromConstantAddress(NvU32 bankNumber, NvU32 bankOffset)
{
    return(CU_KEPLER_SM35_CREATE_SRC_B_FIELD_FROM_CONSTANT_ADDRESS(bankNumber, bankOffset));
}

static void keplerSM35CreateIsetpInst(NvU32 *instrHi, NvU32 *instrLo, NvU32 cmp, NvU32 bop, NvU32 predSrc, NvU32 abc,
           NvU32 srcB, NvU32 regA, NvU32 predDest)
{
    CU_KEPLER_SM35_CREATE_ISETP_INSTR(*instrHi, *instrLo, cmp, bop, predSrc, abc, srcB, regA, predDest)
}

static void keplerSM35CreatePsetpInst(NvU32 *instrHi, NvU32 *instrLo, NvU32 bop, NvU32 predSrc1, NvU32 predSrc2, NvU32 predDest)
{
    CU_KEPLER_SM35_CREATE_PSETP_INSTR(*instrHi, *instrLo, bop, predSrc1, predSrc2, predDest)
}

static void keplerSM35CreateLopInst(NvU32 *instrHi, NvU32 *instrLo)
{
    *instrHi = KEPLER_SM35_LOP_INSTR_HI_OPCODE;
    *instrLo = KEPLER_SM35_LOP_INSTR_LO_OPCODE;
}

static void keplerSM35CreateNopInst(NvU32 *instHi, NvU32 *instLo, NvU32 trigFlag, NvU32 syncFlag, NvU32 mask, NvU32 pred)
{
    CU_KEPLER_SM35_CREATE_NOP_INSTR(*instHi, *instLo, trigFlag, syncFlag, mask, pred)
}

static void keplerSM35CreateRetInst(NvU32 *instHi, NvU32 *instLo, NvU32 PReg, NvU32 CCCbits)
{
    *instHi = CU_KEPLER_SM35_RET_INSTR_HI_OPCODE;
    *instLo = CU_KEPLER_SM35_RET_INSTR_LO_OPCODE;
}

static void keplerSM35CreateCalInst(NvU32 *instHi, NvU32 *instLo, NvU32 target)
{
    CU_KEPLER_SM35_CREATE_CAL_INSTR(*instHi, *instLo, target)
}

static void keplerSM35CreateJcalInst(NvU32 *instHi, NvU32 *instLo, NvU32 target)
{
    CU_KEPLER_SM35_CREATE_JCAL_INSTR(*instHi, *instLo, target)
}

static void keplerSM35CreateVoteInst(NvU32 *instHi, NvU32 *instLo)
{
    *instLo = CU_KEPLER_SM35_VOTE_INSTR_LO_OPCODE;
    *instHi = CU_KEPLER_SM35_VOTE_INSTR_HI_OPCODE;
}


static void keplerSM35CreatePopcInst(NvU32 *instHi, NvU32 *instLo)
{
    *instLo = CU_KEPLER_SM35_POPC_INSTR_LO_OPCODE;
    *instHi = CU_KEPLER_SM35_POPC_INSTR_HI_OPCODE;
}

static void keplerSM35CreateImul32iInst(NvU32 *instHi, NvU32 *instLo)
{
    *instLo = CU_KEPLER_SM35_IMUL32I_INSTR_LO_OPCODE;
    *instHi = CU_KEPLER_SM35_IMUL32I_INSTR_HI_OPCODE;
}

static void keplerSM35CreateBrxInst(NvU32 *instHi, NvU32 *instLo)
{
    *instLo = CU_KEPLER_SM35_BRX_INSTR_LO_OPCODE;
    *instHi = CU_KEPLER_SM35_BRX_INSTR_HI_OPCODE;
}

static void keplerSM35CreateSsyInst(NvU32 *instHi, NvU32 *instLo, NvU32 syncTarget)
{
    CU_KEPLER_SM35_CREATE_SSY_INSTR(*instHi, *instLo, syncTarget)
}

// Function to create LONGJMP Instruction
static void keplerSM35CreateLongjmpInst(NvU32* instHi, NvU32* instLo, NvU32 PRegBitsVal, NvU32 cccBitsVal)
{
    CU_KEPLER_SM35_CREATE_LONGJMP_INSTR(*instHi, *instLo, PRegBitsVal, cccBitsVal);
}

static void keplerSM35CreateIaddInst(NvU32 *instHi, NvU32 *instLo, NvU32 xmFlag, NvU32 psign, NvU32 destReg, NvU32 ccFlag, NvU32 srcReg1, NvU32 srcReg2)
{
    CU_KEPLER_SM35_CREATE_IADD_INSTR(*instHi, *instLo, xmFlag, psign, destReg, ccFlag, srcReg1, srcReg2);
}

static void keplerSM35CreateJmpInst(NvU32 *instHi, NvU32 *instLo, NvU32 target)
{
    CU_KEPLER_SM35_CREATE_JMP_INSTR(*instHi, *instLo, target)
}

static void keplerSM35CreateTexdepbarInst(NvU32 *instHi, NvU32 *instLo)
{
    *instLo = CU_KEPLER_SM35_TEXDEPBAR_INSTR_LO_OPCODE;
    *instHi = CU_KEPLER_SM35_TEXDEPBAR_INSTR_HI_OPCODE;
}

static void keplerSM35CreateShintInst(NvU32 *instHi, NvU32 *instLo, NvU64 hint)
{
    CU_KEPLER_SM35_CREATE_SHINT_INSTR(*instHi, *instLo, hint)
}

static NvU32 keplerSM35IsJcalInst(NvU32 instHi, NvU32 instLo)
{
    return (CU_KEPLER_SM35_IS_JCAL_INSTR(instHi, instLo));
}

static NvU32 keplerSM35IsJmpInst(NvU32 instHi, NvU32 instLo)
{
    return (CU_KEPLER_SM35_IS_JMP_INSTR(instHi, instLo));
}

static NvU32 keplerSM35IsJmxInst(NvU32 instHi, NvU32 instLo)
{
    return (CU_KEPLER_SM35_IS_JMX_INSTR(instHi, instLo));
}

static NvU32 keplerSM35IsCalInst(NvU32 instHi, NvU32 instLo)
{
    return (CU_KEPLER_SM35_IS_CAL_INSTR(instHi, instLo));
}

static NvU32 keplerSM35IsBraInst(NvU32 instHi, NvU32 instLo)
{
    return (CU_KEPLER_SM35_IS_BRA_INSTR(instHi, instLo));
}

static NvU32 keplerSM35IsBrxInst(NvU32 instHi, NvU32 instLo)
{
    return (CU_KEPLER_SM35_IS_BRX_INSTR(instHi, instLo));
}

static NvU32 keplerSM35IsPretInst(NvU32 instHi, NvU32 instLo)
{
    return (CU_KEPLER_SM35_IS_PRET_INSTR(instHi, instLo));
}

static NvU32 keplerSM35IsPlongjmpInst(NvU32 instHi, NvU32 instLo)
{
    return (CU_KEPLER_SM35_IS_PLONGJMP_INSTR(instHi, instLo));
}

static NvU32 keplerSM35IsSsyInst(NvU32 instHi, NvU32 instLo)
{
    return (CU_KEPLER_SM35_IS_SSY_INSTR(instHi, instLo));
}

// Function takes the current instruction as a parameter and produces
// 0 if the instruction is not JCAL or JMP
// 1 if the instruction is JCAL or JMP
static NvU32 keplerSM35IsDirectCall(const NvU64 *inst)
{
    if (!inst)
        return 0;

    return (keplerSM35IsJcalInst(EXTRACT_HI_WORD(*inst), EXTRACT_LO_WORD(*inst))
        || keplerSM35IsJmpInst(EXTRACT_HI_WORD(*inst), EXTRACT_LO_WORD(*inst)));
}

// Function takes the current instruction as a parameter and produces
// 0 if the instruction is not JMX
// 1 if the instruction is JMX
static NvU32 keplerSM35IsIndirectCall(const NvU64 *inst, NvU32 offset)
{
    if (!inst)
        return 0;

    return (keplerSM35IsJmxInst(EXTRACT_HI_WORD(*inst), EXTRACT_LO_WORD(*inst)));
}

int keplerSM35GetOpcodeIndex(NvU64 origOpcode, NvBool* canUseAddrWindows)
{
    NvU64 opcode = origOpcode;

    // Need to set this as true here as this function is abstracted
    // and canUseAddrWindows is set as NV_FALSE for LDU in Fermi
    *canUseAddrWindows =NV_TRUE;

    opcode &= MASK_BITS_LD_ST_INST;

    switch(opcode) {
        case LD_INST_S8BIT_OPCODE:
        case LD_INST_U8BIT_OPCODE:
            return LD_INST_8BIT;

        case LD_INST_U16BIT_OPCODE:
        case LD_INST_S16BIT_OPCODE:
            return LD_INST_16BIT;

        case LD_INST_32BIT_OPCODE:
            return LD_INST_32BIT;

        case LD_INST_64BIT_OPCODE:
            return LD_INST_64BIT;

        case LD_INST_U128BIT_OPCODE: // Signifies LD.U.128
        case LD_INST_128BIT_OPCODE:
            return LD_INST_128BIT;

        case ST_INST_U8BIT_OPCODE:
        case ST_INST_S8BIT_OPCODE:
            return ST_INST_8BIT;

        case ST_INST_U16BIT_OPCODE:
        case ST_INST_S16BIT_OPCODE:
            return ST_INST_16BIT;

        case ST_INST_32BIT_OPCODE:
            return ST_INST_32BIT;

        case ST_INST_64BIT_OPCODE:
            return ST_INST_64BIT;

        case ST_INST_128BIT_OPCODE:
            return ST_INST_128BIT;

        default:
            break;
    }

    opcode = origOpcode;
    opcode &= MASK_BITS_TEX_INST;

    switch(opcode) {
        case TEX_INST_S8BIT_OPCODE:
        case TEX_INST_U8BIT_OPCODE:
            *canUseAddrWindows =NV_FALSE;
            return LDG_INST_8BIT;

        case TEX_INST_U16BIT_OPCODE:
        case TEX_INST_S16BIT_OPCODE:
            *canUseAddrWindows =NV_FALSE;
            return LDG_INST_16BIT;

        case TEX_INST_32BIT_OPCODE:
            *canUseAddrWindows =NV_FALSE;
            return LDG_INST_32BIT;

        case TEX_INST_64BIT_OPCODE:
            *canUseAddrWindows =NV_FALSE;
            return LDG_INST_64BIT;

        case TEX_INST_128BIT_OPCODE:
            *canUseAddrWindows =NV_FALSE;
            return LDG_INST_128BIT;

        default:
            break;
    }

    opcode = origOpcode;
    opcode &= MASK_BITS_TLD_INST;

    switch(opcode) {
        case TLD_INST_S8BIT_OPCODE:
        case TLD_INST_U8BIT_OPCODE:
            *canUseAddrWindows =NV_FALSE;
            return LDG_INST_8BIT;

        case TLD_INST_U16BIT_OPCODE:
        case TLD_INST_S16BIT_OPCODE:
            *canUseAddrWindows =NV_FALSE;
            return LDG_INST_16BIT;

        case TLD_INST_32BIT_OPCODE:
            *canUseAddrWindows =NV_FALSE;
            return LDG_INST_32BIT;

        case TLD_INST_64BIT_OPCODE:
            *canUseAddrWindows =NV_FALSE;
            return LDG_INST_64BIT;

        case TLD_INST_128BIT_OPCODE:
            *canUseAddrWindows =NV_FALSE;
            return LDG_INST_128BIT;

        default:
            break;
    }
    return -1;
}

ConcKernelTraceTable* cuKeplerSM35InitializeConcKernelTraceTable()
{
    return (&SM35ConcKernelTraceTable);
}

sassInstGen keplerSM35SassInstGen = {
    REG_255,
    KEPLER_SM35_INST_SIZE_BYTES,
    &keplerSM35GetLDExrAddr,
    &keplerSM35GetLDAddrReg,
    &keplerSM35GetLDImm32,
    &keplerSM35CreateSrcBFieldFromRegister,
    &keplerSM35CreateSrcBFieldFromConstantAddress,
    &keplerSM35GetPRegBits,
    &keplerSM35IsExitInst,
    &keplerSM35GetCCCBits,
    &keplerSM35IsJcalInst,
    &keplerSM35IsJmpInst,
    &keplerSM35IsJmxInst,
    &keplerSM35IsDirectCall,
    &keplerSM35IsIndirectCall,
    &keplerSM35CreateBraInst,
    &keplerSM35CreateStlInst,
    &keplerSM35CreateP2rInst,
    &keplerSM35CreateLdlInst,
    &keplerSM35CreateMovInst,
    &keplerSM35CreateMov32iInst,
    &keplerSM35CreateRedInst,
    &keplerSM35CreateR2pInst,
    &keplerSM35CreateIsetpInst,
    &keplerSM35CreatePsetpInst,
    &keplerSM35CreateLopInst,
    &keplerSM35CreateNopInst,
    &keplerSM35CreateRetInst,
    &keplerSM35CreateCalInst,
    &keplerSM35CreateJcalInst,
    &keplerSM35CreateVoteInst,
    &keplerSM35CreatePopcInst,
    &keplerSM35CreateImul32iInst,
    &keplerSM35CreateBrxInst,
    &keplerSM35CreateSsyInst,
    &keplerSM35CreateLdcInst,
    &keplerSM35CreateLongjmpInst,
    &keplerSM35CreateIaddInst,
    &keplerSM35CreateJmpInst,
    &keplerSM35CreateShintInst,
    &keplerSM35CreateTexdepbarInst,
};

// Function to initialize Tables in Profiler Hal Structure
CUresult keplerSM35FuncInitializeTables(profilerHal* profHal, NvU64 chip)
{
    CUresult status = CUDA_SUCCESS;
    if(!profHal->swCounterTablePtr) {
        return CUDA_ERROR_UNKNOWN;
    }

    profHal->swCounterTablePtr->getOpcodeIndex = &keplerSM35GetOpcodeIndex;

    if(profHal->patchFlag & CU_PROF_PATCH_FLAG_NOPTRIG_SW_COUNTER){
        switch(chip) {
            case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110:
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110B
            case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110B:
#endif
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110C
            case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK110C:
#endif
                profHal->swCounterTablePtr->swCountersDomain = KEPLER_SW_COUNTERS_DOMAIN_GK110_NOPTRIG;
                break;
            case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK208:
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK208S
            case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK200 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK208S:
#endif
#if NVCFG(GLOBAL_GPU_IMPL_GK20A) || NVCFG(GLOBAL_CHIP_T124)
            case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK20A:
            case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_T12X + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_T124:
#endif // NVCFG(GLOBAL_GPU_IMPL_GK20A) || NVCFG(GLOBAL_CHIP_T124)
#if NVCFG(GLOBAL_CHIP_T132)
            case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_T13X + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_T132:
#endif // NVCFG(GLOBAL_CHIP_T132)
                profHal->swCounterTablePtr->swCountersDomain = KEPLER_SW_COUNTERS_DOMAIN_GK208_NOPTRIG;
                break;
            default:
                return CUDA_ERROR_UNKNOWN;
        }
    }

    profHal->sassInstGenPtr = &keplerSM35SassInstGen;

    return status;
}
