/*
* Copyright 1993-2009 by NVIDIA Corporation.  All rights reserved.  All
* information contained herein is proprietary and confidential to NVIDIA
* Corporation.  Any use, reproduction, or disclosure without the written
* permission of NVIDIA Corporation is prohibited.
*/

/******************************************************************************
*
*   Module: kepelr_signals.c
*
*   Description:
*       kepler specific signals information
*
******************************************************************************/

#include "kepler_perfmon_new.h"
#include "perfmon_new.h"
#include "kepler_signals.h"
#include "kepler_signals_strings.h"

//TBD Check for all watchbus and PM ENABLE and group registers
PerfUnitTable PerfUnitTableGK104[] = {
// Unit-name                 PM enable                       GroupSel              maxGroups
//                      register  start end val        register  start end width
// smquick has different regiser width for group selection
//TBD check if 23rd bit NV_PTPC_PRI_SM_PM_CTRL_SMK_ENABLE also needs to be enabled for the two below.
{PM_UNIT_SMCORE,   {0x00000600,   7,  7, 1},       {0x00000600,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
{PM_UNIT_SMQCTL,   {0x00000600,  15, 15, 1},       {0x00000600,  8, 14,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
{PM_UNIT_SMKQUAD,  {0x00000600,  15, 15, 1},       {0x00000600,  8, 14,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
{PM_UNIT_SMKLOW,   {0x00000600,  22, 22, 1},       {0x00000604,  0,  7,  8},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
{PM_UNIT_SMKHIGH,  {0x00000600,  22, 22, 1},       {0x00000604,  0,  7,  8},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},

{PM_UNIT_SM,       {0x00000600,   7,  7, 1},       {0x00000600,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// SM  - watch buses from 32 to 39 (decimal) are assigned to SMK2PM_GPCTPC#TPC_MUXED_BUS_LOWER_0_#
// SM  - watch buses from 40 to 47 (decimal) are assigned to SMK2PM_GPCTPC#TPC_MUXED_BUS_UPPER_0_#
{PM_UNIT_MPC,      {0x0000040c,  31, 31, 1},       {0x0000040c,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
{PM_UNIT_GPCMMU,   {0x00000884,  31, 31, 1},       {0x00000884,  0,  7,  8},  1, (NV_GPC_PRI_BASE), NV_GPC_PRI_STRIDE, 0},
// MPC - watch buses from 32 to 40 (decimal) are assigned to MPC2PM_MUXED_BUS_#
{PM_UNIT_L1C,      {0x000004a8,  31, 31, 1},       {0x000004a8,  0,  5,  6},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// L1C - watch buses from  40 to  47 (decimal) are assigned to ?? (could not locate it in pm_signals.h), taken from pm_programming_guide.txt
{PM_UNIT_TEX_M,    {0x000002c0,  31, 31, 1},       {0x000002C0,  0,  3,  4},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE, {0x000002c8,  31, 31, 1}, {0x000002C8,  0,  2,  3}},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_D,    {0x000002bc,  31, 31, 1},       {0x000002bc,  0,  3,  4},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE, {0x000002c8,  31, 31, 1}, {0x000002C8,  3,  3,  1}},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_LTC,      {0x0000025c,   0,  0, 1},       {0x0000025c,  1,  3,  3},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE, {0x00000028,   0,  0, 1},       {0x00000028,  1,  3,  3}},
// LTC - watch buses from 12 to 15 (decimal) are assigned to LTC2PM_LTC_SECTOR_MUXED_BUS_#
{PM_UNIT_LTC1,     {0x0000025c,   0,  0, 1},       {0x0000025c,  4,  8,  5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE, {0x00000028,   0,  0, 1},       {0x00000028,  4,  8,  5}},
// LTC1 - watch buses from 17 to 42 (decimal) are assigned to LTC2PM_LTC_MUXED_BUS_#
{PM_UNIT_LTC2,     {0x0000025c,   0,  0, 1},       {0x0000025c,  9,  13, 5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE, {0x00000028,   0,  0, 1},       {0x00000028,  9,  13, 5}},
// LTC2 - watch buses from 16      (decimal) are assigned to LTC2PM_LTC_SRCUNIT_MUXED_BUS
{PM_UNIT_LTC3,     {0x0000025c,   0,  0, 1},       {0x0000025c,  16, 18, 3},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE, {0x00000028,   0,  0, 1},       {0x00000028, 16, 18, 3}},
{PM_UNIT_LTC4,     {0x0000025c,   0,  0, 1},       {0x0000025c,  24, 25, 2},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE, {0x00000028,   0,  0, 1},       {0x00000028, 24, 25, 2}},
{PM_UNIT_LTC5,     {0x0000025c,   0,  0, 1},       {0x0000025c,  29, 29, 1},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE, {0x00000028,   0,  0, 1},       {0x00000028, 29, 29, 1}},

// LTC5 - watch buses from 32 to 57(decimal) are assigned to LTC2PM_LTC_EXTENDED_MUXED_BUS_#
{PM_UNIT_FB,       {0x00000100,   0,  0, 1},       {0x00000100,   4,  9, 6},      1, NV_FBPA_PRI_BASE,                 NV_FBPA_PRI_STRIDE,0},
//FB - mwatch buses from 15 to 26(decimal) are assigned to FBPA2PM_LTC_FB_PERF_MUXED_BUS_#
{PM_UNIT_HUBMMU,   {0x00100C84,  31, 31, 1},       {0x00100C84,   0,  7, 8},  1, 0,                                0,                 0},
// HUBMMU - watch buses from 5 to 8(decimal) are assigned to HUBMMU2PM_HUB_MUXED_BUS_#
// TODO: add other units here
{PM_UNIT_MAX                                                                          }
};

PerfUnitTable PerfUnitTableGK110[] = {
// Unit-name                 PM enable                       GroupSel              maxGroups
//                      register  start end val        register  start end width
{PM_UNIT_SMCORE,   {0x00000600,   7,  7, 1},       {0x00000600,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// SMCORE - watch buses from 32 to 39 (decimal) are assigned to SM_CORE2PM_GPCTPC2_MUXED_BUS_#
{PM_UNIT_SMQCTL,   {0x00000600,  15, 15, 1},       {0x00000600,  8, 14,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// SMQCTL - watch buses from 48 to 79 (decimal) are assigned to SM_QCTL<no>2PM_GPCTPC0_MUXED_BUS_# where no = {0, 1, 2, 3}
{PM_UNIT_SM,       {0x00000600,   7,  7, 1},       {0x00000600,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
//
{PM_UNIT_MPC,      {0x0000040c,  31, 31, 1},       {0x0000040c,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
{PM_UNIT_GPCMMU,   {0x00000884,  31, 31, 1},       {0x00000884,  0,  7,  8},  1, (NV_GPC_PRI_BASE), NV_GPC_PRI_STRIDE, 0},
// MPC - watch buses from 12 to 20 (decimal) are assigned to MPC2PM_MUXED_BUS_#
{PM_UNIT_L1C,      {0x000004a8,  31, 31, 1},       {0x000004a8,  0,  5,  6},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// L1C - watch buses from  40 to  47 (decimal) are assigned to SM_LSU2PM_GPCTPC0_MUXED_BUS_#
{PM_UNIT_TEX_M,    {0x000002c0,  31, 31, 1},       {0x000002C0,  0,  3,  4},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE, {0x000002c8,  31, 31, 1}, {0x000002C8,  0,  2,  3}},
// TEX - watch buses from 0 to 9 (decimal) are assigned to TEX02PM_GPCTPC0_M_MUXED_BUS_#
{PM_UNIT_TEX_S,     {0x000002b0,  31, 31, 1},       {0x000002b0,  0,  5,  6},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE, {0x000002c8,  31, 31, 1}, {0x000002C8,  4,  4,  1}},
// TEX - watch buses from 0 to 9 (decimal) are assigned to TEX02PM_GPCTPC0_M_MUXED_BUS_#
{PM_UNIT_TEX_D,    {0x000002bc,  31, 31, 1},       {0x000002bc,  0,  3,  4},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE, {0x000002c8,  31, 31, 1}, {0x000002C8,  3,  3,  1}},
// TEX - watch buses from 0 to 9 (decimal) are assigned to TEX02PM_GPCTPC0_M_MUXED_BUS_#
{PM_UNIT_LTC,      {0x0000025c,   0,  0, 1},       {0x0000025c,  1,  3,  3},  1, (NV_PLTCG_BASE+NV_PLTS_BASE), NV_PLTCG_STRIDE, NV_PLTS_STRIDE , {0x00000028,   0,  0, 1}, {0x00000028,  1,  3,  3}},
// LTC - watch buses from 12 to 15 (decimal) are assigned to LTC2PM_LTC_SECTOR_MUXED_BUS_#
{PM_UNIT_LTC1,     {0x0000025c,   0,  0, 1},       {0x0000025c,  4,  8,  5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE), NV_PLTCG_STRIDE  , NV_PLTS_STRIDE, {0x00000028,   0,  0, 1}, {0x00000028,  4,  8,  5}},
// LTC1 - watch buses from 17 to 43 (decimal) are assigned to LTC2PM_LTC_MUXED_BUS_#
{PM_UNIT_LTC2,     {0x0000025c,   0,  0, 1},       {0x0000025c,  9,  13, 5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE, {0x00000028,   0,  0, 1},       {0x00000028,  9,  13, 5}},
// LTC2 - watch buses from 16      (decimal) are assigned to LTC2PM_LTC_SRCUNIT_MUXED_BUS
{PM_UNIT_LTC3,     {0x0000025c,   0,  0, 1},       {0x0000025c,  16, 18, 3},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE, {0x00000028,   0,  0, 1},       {0x00000028, 16, 18, 3}},
{PM_UNIT_LTC4,     {0x0000025c,   0,  0, 1},       {0x0000025c,  24, 25, 2},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE, {0x00000028,   0,  0, 1},       {0x00000028, 24, 25, 2}},
{PM_UNIT_LTC5,     {0x0000025c,   0,  0, 1},       {0x0000025c,  29, 29, 1},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE, {0x00000028,   0,  0, 1},       {0x00000028, 29, 29, 1}},
{PM_UNIT_FB,       {0x00000100,   0,  0, 1},       {0x00000100,   4,  10, 7},  1, NV_FBPA_PRI_BASE,                     NV_FBPA_PRI_STRIDE, 0},
//FB - watch buses from 0 to 11 (decimal) are assigned to FBPA02PM_LTC_FB_PERF_MUXED_BUS_#
{PM_UNIT_HUBMMU,   {0x00100C84,  31, 31, 1},       {0x00100C84,   0,  7, 8},  1, 0,                                0,                 0},
// HUBMMU - watch buses from 5 to 8(decimal) are assigned to HUBMMU2PM_HUB_MUXED_BUS_#
// Add SYS unit here
// TODO: add other units here
{PM_UNIT_MAX                                                                          }
};

PerfUnitTable PerfUnitTableGK20A[] = {
// Unit-name                 PM enable                       GroupSel              maxGroups
//                      register  start end val        register  start end width
{PM_UNIT_SMCORE,   {0x00000600,   7,  7, 1},       {0x00000600,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// SMCORE - watch buses from 32 to 39 (decimal) are assigned to SM_CORE2PM_GPCTPC2_MUXED_BUS_#
{PM_UNIT_SMQCTL,   {0x00000600,  15, 15, 1},       {0x00000600,  8, 14,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// SMQCTL - watch buses from 48 to 79 (decimal) are assigned to SM_QCTL<no>2PM_GPCTPC0_MUXED_BUS_# where no = {0, 1, 2, 3}
{PM_UNIT_SM,       {0x00000600,   7,  7, 1},       {0x00000600,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
//
{PM_UNIT_MPC,      {0x0000040c,  31, 31, 1},       {0x0000040c,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// MPC - watch buses from 12 to 20 (decimal) are assigned to MPC2PM_MUXED_BUS_#
{PM_UNIT_L1C,      {0x000004a8,  31, 31, 1},       {0x000004a8,  0,  5,  6},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// L1C - watch buses from  40 to  47 (decimal) are assigned to SM_LSU2PM_GPCTPC0_MUXED_BUS_#
{PM_UNIT_TEX_M,    {0x000002c0,  31, 31, 1},       {0x000002C0,  0,  4,  5},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE, {0x000002c8,  31, 31, 1}, {0x000002C8,  0,  2,  3}},
// TEX - watch buses from 0 to 9 (decimal) are assigned to TEX02PM_GPCTPC0_M_MUXED_BUS_#
{PM_UNIT_TEX_S,     {0x000002b0,  31, 31, 1},       {0x000002b0,  0,  5,  6},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE, {0x000002c8,  31, 31, 1}, {0x000002C8,  4,  4,  1}},
// TEX - watch buses from 0 to 9 (decimal) are assigned to TEX02PM_GPCTPC0_M_MUXED_BUS_#
{PM_UNIT_TEX_D,    {0x000002bc,  31, 31, 1},       {0x000002bc,  0,  3,  4},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE, {0x000002c8,  31, 31, 1}, {0x000002C8,  3,  3,  1}},
// TEX - watch buses from 0 to 9 (decimal) are assigned to TEX02PM_GPCTPC0_M_MUXED_BUS_#
{PM_UNIT_LTC,      {0x0000025c,   0,  0, 1},       {0x0000025c,  1,  3,  3},  1, (NV_PLTCG_BASE+NV_PLTS_BASE), NV_PLTCG_STRIDE, NV_PLTS_STRIDE , {0x00000028,   0,  0, 1}, {0x00000028,  1,  3,  3}},
// LTC - watch buses from 12 to 15 (decimal) are assigned to LTC2PM_LTC_SECTOR_MUXED_BUS_#
{PM_UNIT_LTC1,     {0x0000025c,   0,  0, 1},       {0x0000025c,  4,  8,  5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE), NV_PLTCG_STRIDE  , NV_PLTS_STRIDE, {0x00000028,   0,  0, 1}, {0x00000028,  4,  8,  5}},
// LTC1 - watch buses from 17 to 43 (decimal) are assigned to LTC2PM_LTC_MUXED_BUS_#
{PM_UNIT_LTC2,     {0x0000025c,   0,  0, 1},       {0x0000025c,  9,  13, 5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE, {0x00000028,   0,  0, 1},       {0x00000028,  9,  13, 5}},
// LTC2 - watch buses from 16      (decimal) are assigned to LTC2PM_LTC_SRCUNIT_MUXED_BUS
{PM_UNIT_LTC3,     {0x0000025c,   0,  0, 1},       {0x0000025c,  16, 18, 3},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE, {0x00000028,   0,  0, 1},       {0x00000028, 16, 18, 3}},
{PM_UNIT_LTC4,     {0x0000025c,   0,  0, 1},       {0x0000025c,  24, 25, 2},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE, {0x00000028,   0,  0, 1},       {0x00000028, 24, 25, 2}},
{PM_UNIT_LTC5,     {0x0000025c,   0,  0, 1},       {0x0000025c,  29, 29, 1},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE, {0x00000028,   0,  0, 1},       {0x00000028, 29, 29, 1}},
//NV_PERF_PMASYS (Memory controller perf mux is in PMASYS)
//NV_PERF_PMASYS_MISC
{PM_UNIT_MC,       {0x001b4128,   31,  31, 1},     {0x001b4128,   0,  7, 8},  1, 0, 0, 0},
//FB - watch buses from 0 to 11 (decimal) are assigned to FBPA02PM_LTC_FB_PERF_MUXED_BUS_#
{PM_UNIT_HUBMMU,   {0x00100C84,  31, 31, 1},       {0x00100C84,   0,  7, 8},  1, 0,                                0,                 0},
// HUBMMU - watch buses from 5 to 8(decimal) are assigned to HUBMMU2PM_HUB_MUXED_BUS_#
// Add SYS unit here
// TODO: add other units here
{PM_UNIT_MAX                                                                          }
};

// Perf signal table for kepler
// perf-event: signal0 - 2:0, signal1 - 6:4, signal2 - 10:8, signal3 - 14:12
// Some sigmals are commented and not removed so that they can be used for testing purpose in future.
PerfSignalHwpm PerfSignalTableGK104_gpctpc[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type

#if CU_PROFILE_SM_QUAD_SIGNALS_VIA_HWPM
    { KEPLER_SCH_WARPS_LAUNCHED_Q0,            kepler_sch_warps_launched_q0_enc_str_1,        0x00000002, 0x0000AAAA,  0x20,    PM_UNIT_SMKQUAD,1 },
    { KEPLER_SCH_WARPS_LAUNCHED_Q1,            kepler_sch_warps_launched_q1_enc_str_1,        0x00000002, 0x0000AAAA,  0x24,    PM_UNIT_SMKQUAD,1 },
    { KEPLER_SCH_WARPS_LAUNCHED_Q2,            kepler_sch_warps_launched_q2_enc_str_1,        0x00000002, 0x0000AAAA,  0x28,    PM_UNIT_SMKQUAD,1 },
    { KEPLER_SCH_WARPS_LAUNCHED_Q3,            kepler_sch_warps_launched_q3_enc_str_1,        0x00000002, 0x0000AAAA,  0x2C,    PM_UNIT_SMKQUAD,1 },
#endif

    { KEPLER_HWPM_THREADS_LAUNCHED,             kepler_hwpm_threads_launched_enc_str_1,         0x00000002, 0x0000FFFF,  0x29,    PM_UNIT_SMQCTL,6 },
    { KEPLER_HWPM_CTA_LAUNCHED,                     kepler_hwpm_cta_launched_enc_str_1,                 0x00000006, 0x0000AAAA,     0x22,    PM_UNIT_SMCORE,1 },
#if CU_PROFILE_SM_SIGNALS_VIA_HWPM
    // ########### SM Unit ###########
    // ***LAUNCHED***
    // sch_warps_launched               SM has launched 1 warp
    // sch_threads_launched             number of threads SM launched this cycle
    { KEPLER_HWPM_WARPS_LAUNCHED,               kepler_hwpm_warps_launched_enc_str_1,           0x00000002, 0x0000AAAA,  0x28,    PM_UNIT_SMQCTL,1 },

    // ****ACTIVE_WARPS***
    // fet_any_active                   FET: has at least 1 active warp
    //                                  i.e. Count total number of cycles SM has at least one active warp, existing warp, not necessarily to be schedulable
    { KEPLER_HWPM_ACTIVE_CYCLES,                   kepler_hwpm_active_cycles_enc_str_1,            0x00000001, 0x0000AAAA,  0x20,    PM_UNIT_SMCORE,1 },

    // sch_active_warps                 number of active warps SM currently has
    //                                  i.e. Every cycle, increment this counter by the number of active warps
    { KEPLER_HWPM_ACTIVE_WARPS,                     kepler_hwpm_active_warps_enc_str_1,             0x00000001, 0x0000FFFF,  0x21,    PM_UNIT_SMCORE,6 },
    { KEPLER_HWPM_L1C_LOCAL_LOAD_HIT,               kepler_hwpm_l1c_local_load_hit_enc_str_1,        0x00000019, 0x0000AAAA,     0x2a,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_LOCAL_LOAD_MISS,              kepler_hwpm_l1c_local_load_miss_enc_str_1,       0x00000019, 0x0000AAAA,     0x2b,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_LOCAL_STORE_HIT,              kepler_hwpm_l1c_local_store_hit_enc_str_1,       0x00000019, 0x0000AAAA,     0x2c,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_LOCAL_STORE_MISS,             kepler_hwpm_l1c_local_store_miss_enc_str_1,      0x00000019, 0x0000AAAA,     0x2d,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_GLOBAL_LOAD_HIT,              kepler_hwpm_l1c_global_load_hit_enc_str_1,       0x00000019, 0x0000AAAA,     0x2e,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_GLOBAL_LOAD_MISS,             kepler_hwpm_l1c_global_load_miss_enc_str_1,      0x00000019, 0x0000AAAA,     0x2f,    PM_UNIT_L1C,1 },

    //["LSU_TRANSACTIONS_0" =>
    //    ["local_ld_transactions",           1,      "off",   "count instructions at accept point", undef],
    //    ["local_st_transactions",           1,      "off",   "count instructions at accept point", undef],
    //    ["shared_ld_transactions",          1,      "off",   "count instructions at accept point", undef],
    //    ["shared_st_transactions",          1,      "off",   "count instructions at accept point", undef],
    //],
    //["LSU_TRANSACTIONS_1" =>
    //    ["global_ld_transactions",          1,      "off",   "count instructions at accept point", undef],
    //    ["global_st_transactions",          1,      "off",   "count instructions at accept point", undef],
    //],
    { KEPLER_HWPM_L1C_LOCAL_LOAD_TRANSACTIONS,      kepler_hwpm_l1c_local_load_transactions_enc_str_1,   0x00000017, 0x0000AAAA,     0x28,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_LOCAL_STORE_TRANSACTIONS,     kepler_hwpm_l1c_local_store_transactions_enc_str_1,  0x00000017, 0x0000AAAA,     0x29,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_SHARED_LOAD_TRANSACTIONS,     kepler_hwpm_l1c_shared_load_transactions_enc_str_1,  0x00000017, 0x0000AAAA,     0x2a,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_SHARED_STORE_TRANSACTIONS,    kepler_hwpm_l1c_shared_store_transactions_enc_str_1, 0x00000017, 0x0000AAAA,     0x2b,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_GLOBAL_LOAD_TRANSACTIONS,     kepler_hwpm_l1c_global_load_transactions_enc_str_1,  0x00000018, 0x0000AAAA,     0x28,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_GLOBAL_STORE_TRANSACTIONS,    kepler_hwpm_l1c_global_store_transactions_enc_str_1, 0x00000018, 0x0000AAAA,     0x29,    PM_UNIT_L1C,1 },

    // TBD: please cross check if signals below are correct??
    //["LSU_COUNT_1" =>
    //    ["l1_uncached_global_ld_count",     1,      "off",   "count instructions at accept point", undef],
    //    ["l1_global_st_count",              1,      "off",   "count instructions at accept point", undef],
    //],
    { KEPLER_HWPM_L1C_UNCACHED_GLOBAL_LOAD,         kepler_hwpm_l1c_uncached_global_load_enc_str_1,  0x0000001a, 0x0000AAAA,     0x28,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_GLOBAL_STORE,                 kepler_hwpm_l1c_global_store_enc_str_1,          0x0000001a, 0x0000AAAA,     0x29,    PM_UNIT_L1C,1 },
    //["TOQ_1" =>
    //    ["shared_ld_mem_divergence_replays",   1,      "off",   "shared ld is replayed due to bank conflict", undef],
    //    ["shared_st_mem_divergence_replays",   1,      "off",   "shared st is replayed due to bank conflict", undef],
    //],
    { KEPLER_HWPM_L1C_SHARED_LOAD_BANK_CONFLICT,    kepler_hwpm_l1c_shared_load_bank_conflict_enc_str_1,    0x00000007, 0x0000AAAA,     0x2a,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_SHARED_STORE_BANK_CONFLICT,   kepler_hwpm_l1c_shared_store_bank_conflict_enc_str_1,   0x00000007, 0x0000AAAA,     0x2b,    PM_UNIT_L1C,1 },
#endif

    //Tex signals
    // based on experiments - tex_cache_misses_gpc0_tpc0_tex0 and tex_cache_sector_queries_gpc0_tpc0_tex0
    // defined in \\hw\tools\perfalyze\chips\gk104\pml_files\tex.pml
    //tex0_cache_sector_queries  = tex02pm_gpc_t_sector_queries
    //tex0_cache_sector_misses   = tex02pm_gpc_t_missed_sectors
    //tex1_cache_sector_queries = tex12pm_gpc_t_sector_queries
    //tex1_cache_sector_misses  = tex12pm_gpc_t_missed_sectors

    { KEPLER_TEX0_CACHE_SECTOR_QUERIES,   kepler_tex0_cache_sector_queries_enc_str_1,  0x00000005, 0x0000FFFF, 0x00000004,    PM_UNIT_TEX_M,5, 0x00000003},
    { KEPLER_TEX1_CACHE_SECTOR_QUERIES,   kepler_tex1_cache_sector_queries_enc_str_1,  0x00000005, 0x0000FFFF, 0x00000004,    PM_UNIT_TEX_M,5, 0x00000004},
    { KEPLER_TEX2_CACHE_SECTOR_QUERIES,   kepler_tex2_cache_sector_queries_enc_str_1,  0x00000005, 0x0000FFFF, 0x0000000e,    PM_UNIT_TEX_M,5, 0x00000003},
    { KEPLER_TEX3_CACHE_SECTOR_QUERIES,   kepler_tex3_cache_sector_queries_enc_str_1,  0x00000005, 0x0000FFFF, 0x0000000e,    PM_UNIT_TEX_M,5, 0x00000004},

    { KEPLER_TEX0_CACHE_SECTOR_MISSES,    kepler_tex0_cache_sector_misses_enc_str_1,   0x00000004, 0x0000FFFF, 0x00000000,    PM_UNIT_TEX_M,5, 0x00000003},
    { KEPLER_TEX1_CACHE_SECTOR_MISSES,    kepler_tex1_cache_sector_misses_enc_str_1,   0x00000004, 0x0000FFFF, 0x00000000,    PM_UNIT_TEX_M,5, 0x00000004},
    { KEPLER_TEX2_CACHE_SECTOR_MISSES,    kepler_tex2_cache_sector_misses_enc_str_1,   0x00000004, 0x0000FFFF, 0x0000000a,    PM_UNIT_TEX_M,5, 0x00000003},
    { KEPLER_TEX3_CACHE_SECTOR_MISSES,    kepler_tex3_cache_sector_misses_enc_str_1,   0x00000004, 0x0000FFFF, 0x0000000a,    PM_UNIT_TEX_M,5, 0x00000004},

    { KEPLER_ELAPSED_CYCLES_SM,              kepler_elapsed_cycles_sm_enc_str_1,             0x00000000, 0x00000000, 0x00000000,    PM_UNIT_SMCORE,0},
    { KEPLER_L1C_PRT_PENDING_ENTRIES, kepler_l1c_prt_pending_entries_enc_str_1, 0xc, 0xffff, 0x28, PM_UNIT_L1C, 7},
    { KEPLER_L1C_PRT_ENTRIES_INUSE,   kepler_l1c_prt_entries_inuse_enc_str_1,   0xd, 0xffff, 0x28, PM_UNIT_L1C, 7},
    { KEPLER_L1C_PRT_ENTRIES_USABLE,  kepler_l1c_prt_entries_usable_enc_str_1,  0xe, 0xffff, 0x28, PM_UNIT_L1C, 7},

    { KEPLER_TEX0_BANK_CONFLICTS,    kepler_tex0_bank_conflicts_enc_str_1,   0x00000006,  0x0000aaaa, 0x31,    PM_UNIT_TEX_D,1, 0x00000000},
    { KEPLER_TEX1_BANK_CONFLICTS,    kepler_tex1_bank_conflicts_enc_str_1,   0x00000006,  0x0000aaaa, 0x31,    PM_UNIT_TEX_D,1, 0x00000001},
    { KEPLER_TEX2_BANK_CONFLICTS,    kepler_tex2_bank_conflicts_enc_str_1,   0x00000006,  0x0000aaaa, 0x3c,    PM_UNIT_TEX_D,1, 0x00000000},
    { KEPLER_TEX3_BANK_CONFLICTS,    kepler_tex3_bank_conflicts_enc_str_1,   0x00000006,  0x0000aaaa, 0x3c,    PM_UNIT_TEX_D,1, 0x00000001},

    {KEPLER_TEX0_TEX2SM_TEX_PRDY, kepler_tex0_tex2sm_tex_prdy_enc_str_1, 0x3, 0xaaaa, 0x33, PM_UNIT_TEX_D, 1, 0},
    {KEPLER_TEX1_TEX2SM_TEX_PRDY, kepler_tex1_tex2sm_tex_prdy_enc_str_1, 0x3, 0xaaaa, 0x33, PM_UNIT_TEX_D, 1, 1},
    {KEPLER_TEX2_TEX2SM_TEX_PRDY, kepler_tex2_tex2sm_tex_prdy_enc_str_1, 0x3, 0xaaaa, 0x3e, PM_UNIT_TEX_D, 1, 0},
    {KEPLER_TEX3_TEX2SM_TEX_PRDY, kepler_tex3_tex2sm_tex_prdy_enc_str_1, 0x3, 0xaaaa, 0x3e, PM_UNIT_TEX_D, 1, 1},
    {KEPLER_TEX0_TEX2SM_TEX_PVLD, kepler_tex0_tex2sm_tex_pvld_enc_str_1, 0x3, 0xaaaa, 0x32, PM_UNIT_TEX_D, 1, 0},
    {KEPLER_TEX1_TEX2SM_TEX_PVLD, kepler_tex1_tex2sm_tex_pvld_enc_str_1, 0x3, 0xaaaa, 0x32, PM_UNIT_TEX_D, 1, 1},
    {KEPLER_TEX2_TEX2SM_TEX_PVLD, kepler_tex2_tex2sm_tex_pvld_enc_str_1, 0x3, 0xaaaa, 0x3d, PM_UNIT_TEX_D, 1, 0},
    {KEPLER_TEX3_TEX2SM_TEX_PVLD, kepler_tex3_tex2sm_tex_pvld_enc_str_1, 0x3, 0xaaaa, 0x3d, PM_UNIT_TEX_D, 1, 1},

    { KEPLER_SM_L1C_DIRTY_LINE_EVICTION, kepler_sm_l1c_dirty_line_eviction_enc_str_1, 0x0000001a, 0x0000AAAA, 0x2d, PM_UNIT_L1C, 1},

    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpmExpt PerfSignalTableGK104_gpctpc_expt[] = {
    { KEPLER_TEX0_RETURN_PACKET_COUNT,    kepler_tex0_return_packet_count_enc_str_1,   INVALID_PM_SIGNAL_NEW, {KEPLER_TEX0_TEX2SM_TEX_PRDY, KEPLER_TEX0_TEX2SM_TEX_PVLD, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_TEX1_RETURN_PACKET_COUNT,    kepler_tex1_return_packet_count_enc_str_1,   INVALID_PM_SIGNAL_NEW, {KEPLER_TEX1_TEX2SM_TEX_PRDY, KEPLER_TEX1_TEX2SM_TEX_PVLD, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_TEX2_RETURN_PACKET_COUNT,    kepler_tex2_return_packet_count_enc_str_1,   INVALID_PM_SIGNAL_NEW, {KEPLER_TEX2_TEX2SM_TEX_PRDY, KEPLER_TEX2_TEX2SM_TEX_PVLD, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_TEX3_RETURN_PACKET_COUNT,    kepler_tex3_return_packet_count_enc_str_1,   INVALID_PM_SIGNAL_NEW, {KEPLER_TEX3_TEX2SM_TEX_PRDY, KEPLER_TEX3_TEX2SM_TEX_PVLD, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},

    { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000,  0x00},
};

PerfSignalHwpm PerfSignalTableGK104_ltc0[] = {
    //FBP signals
    { KEPLER_FB_SUBP0_DRAMC_READ,          kepler_fb_subp0_dramc_read_enc_str_1,            0x00000011, 0x0000AAAA,  0x00000000,   PM_UNIT_FB,1 },
    { KEPLER_FB_SUBP1_DRAMC_READ,          kepler_fb_subp1_dramc_read_enc_str_1,            0x00000012, 0x0000AAAA,  0x00000000,   PM_UNIT_FB,1 },
    { KEPLER_FB_SUBP0_DRAMC_WRITE,         kepler_fb_subp0_dramc_write_enc_str_1,           0x00000011, 0x0000AAAA,  0x00000001,   PM_UNIT_FB,1 },
    { KEPLER_FB_SUBP1_DRAMC_WRITE,         kepler_fb_subp1_dramc_write_enc_str_1,           0x00000012, 0x0000AAAA,  0x00000001,   PM_UNIT_FB,1 },

    // fb_dram_activates_subp0_fbp0_pa0       = fbpa02pm_subp0_actarb_activate      "Number of bank activates in subpartition-0"
    // fb_dram_activates_subp1_fbp0_pa0       = fbpa02pm_subp1_actarb_activate      "Number of bank activates in subpartition-1"
    { KEPLER_FB_SUBP0_DRAM_ACTIVATES,      kepler_fb_subp0_dram_activates_enc_str_1,             0x00000001, 0x0000AAAA,  0x00000006,   PM_UNIT_FB,1 },
    { KEPLER_FB_SUBP1_DRAM_ACTIVATES,      kepler_fb_subp1_dram_activates_enc_str_1,             0x00000002, 0x0000AAAA,  0x00000006,   PM_UNIT_FB,1 },

    //LTC signals
    // l2_subp0_write_sector_misses = ltc_ltc2fb_dirty_dat0_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 0
    // l2_subp1_write_sector_misses = ltc_ltc2fb_dirty_dat1_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 1
    // l2_subp0_read_sector_misses  = ltc_fb2ltc_rdat0_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 0
    // l2_subp1_read_sector_misses  = ltc_fb2ltc_rdat1_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 1
    // l2_subp0_write_l1_sector_queries = ltc2pm_ltc_lts0_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 0
    // l2_subp1_write_l1_sector_queries = ltc2pm_ltc_lts1_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 1
    // l2_subp0_read_l1_sector_queries  = ltc2pm_ltc_lts0_request_rd_op && ltc2pm_ltc_lts1_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 0
    // l2_subp1_read_l1_sector_queries  = ltc2pm_ltc_lts1_request_rd_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 1

    { KEPLER_LTC0_WRITE_MISS_SECTORS,      kepler_ltc0_write_miss_sectors_enc_str_1,     0x00000006, 0x0000AAAA,  0x15,    PM_UNIT_LTC1,1, 0},
    { KEPLER_LTC1_WRITE_MISS_SECTORS,      kepler_ltc1_write_miss_sectors_enc_str_1,     0x00000006, 0x0000AAAA,  0x15,    PM_UNIT_LTC1,1, 1},
    { KEPLER_LTC2_WRITE_MISS_SECTORS,      kepler_ltc2_write_miss_sectors_enc_str_1,     0x00000006, 0x0000AAAA,  0x15,    PM_UNIT_LTC1,1, 2},
    { KEPLER_LTC3_WRITE_MISS_SECTORS,      kepler_ltc3_write_miss_sectors_enc_str_1,     0x00000006, 0x0000AAAA,  0x15,    PM_UNIT_LTC1,1, 3},
    { KEPLER_LTC0_READ_MISS_SECTORS,       kepler_ltc0_read_miss_sectors_enc_str_1,      0x00000006, 0x0000AAAA,  0x16,    PM_UNIT_LTC1,1, 0},
    { KEPLER_LTC1_READ_MISS_SECTORS,       kepler_ltc1_read_miss_sectors_enc_str_1,      0x00000006, 0x0000AAAA,  0x16,    PM_UNIT_LTC1,1, 1},
    { KEPLER_LTC2_READ_MISS_SECTORS,       kepler_ltc2_read_miss_sectors_enc_str_1,      0x00000006, 0x0000AAAA,  0x16,    PM_UNIT_LTC1,1, 2},
    { KEPLER_LTC3_READ_MISS_SECTORS,       kepler_ltc3_read_miss_sectors_enc_str_1,      0x00000006, 0x0000AAAA,  0x16,    PM_UNIT_LTC1,1, 3},


    //Event group mask is calculated from NV_PLTC_MISC_LTC_PM, excluding the PM_ENABLE bit
    //NV_PLTC_MISC_LTC_PM_SECTOR_MUX_SELECT : 0xe
    //NV_PLTC_MISC_LTC_PM_SELECT : 0x1F0
    //NV_PLTC_MISC_LTC_PM_SRCUNIT_MUX_SELECT : 0x3E00
    //Final mask: 0x00003FFE
    //Generated using signal generator
    {KEPLER_LTC0_REQUEST_SECTORS, kepler_ltc0_request_sectors_enc_str_1, 0x0, 0xffff, 0xc, PM_UNIT_LTC, 4, 0},
    {KEPLER_LTC1_REQUEST_SECTORS, kepler_ltc1_request_sectors_enc_str_1, 0x0, 0xffff, 0xc, PM_UNIT_LTC, 4, 1},
    {KEPLER_LTC2_REQUEST_SECTORS, kepler_ltc2_request_sectors_enc_str_1, 0x0, 0xffff, 0xc, PM_UNIT_LTC, 4, 2},
    {KEPLER_LTC3_REQUEST_SECTORS, kepler_ltc3_request_sectors_enc_str_1, 0x0, 0xffff, 0xc, PM_UNIT_LTC, 4, 3},
    {KEPLER_LTC0_HIT_SECTORS, kepler_ltc0_hit_sectors_enc_str_1, 0x1, 0xffff, 0xc, PM_UNIT_LTC, 4, 0},
    {KEPLER_LTC1_HIT_SECTORS, kepler_ltc1_hit_sectors_enc_str_1, 0x1, 0xffff, 0xc, PM_UNIT_LTC, 4, 1},
    {KEPLER_LTC2_HIT_SECTORS, kepler_ltc2_hit_sectors_enc_str_1, 0x1, 0xffff, 0xc, PM_UNIT_LTC, 4, 2},
    {KEPLER_LTC3_HIT_SECTORS, kepler_ltc3_hit_sectors_enc_str_1, 0x1, 0xffff, 0xc, PM_UNIT_LTC, 4, 3},
    {KEPLER_LTC0_REQUEST_ACTIVE, kepler_ltc0_request_active_enc_str_1, 0x0, 0xaaaa, 0x12, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_REQUEST_ACTIVE, kepler_ltc1_request_active_enc_str_1, 0x0, 0xaaaa, 0x12, PM_UNIT_LTC1, 1, 1},
    {KEPLER_LTC2_REQUEST_ACTIVE, kepler_ltc2_request_active_enc_str_1, 0x0, 0xaaaa, 0x12, PM_UNIT_LTC1, 1, 2},
    {KEPLER_LTC3_REQUEST_ACTIVE, kepler_ltc3_request_active_enc_str_1, 0x0, 0xaaaa, 0x12, PM_UNIT_LTC1, 1, 3},
    {KEPLER_LTC0_REQUEST_RD_OP, kepler_ltc0_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x27, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_REQUEST_RD_OP, kepler_ltc1_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x27, PM_UNIT_LTC1, 1, 1},
    {KEPLER_LTC2_REQUEST_RD_OP, kepler_ltc2_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x27, PM_UNIT_LTC1, 1, 2},
    {KEPLER_LTC3_REQUEST_RD_OP, kepler_ltc3_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x27, PM_UNIT_LTC1, 1, 3},
    {KEPLER_LTC0_REQUEST_WR_OP, kepler_ltc0_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x26, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_REQUEST_WR_OP, kepler_ltc1_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x26, PM_UNIT_LTC1, 1, 1},
    {KEPLER_LTC2_REQUEST_WR_OP, kepler_ltc2_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x26, PM_UNIT_LTC1, 1, 2},
    {KEPLER_LTC3_REQUEST_WR_OP, kepler_ltc3_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x26, PM_UNIT_LTC1, 1, 3},
    {KEPLER_LTC0_HIT, kepler_ltc0_hit_enc_str_1, 0x0, 0xaaaa, 0x18, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_HIT, kepler_ltc1_hit_enc_str_1, 0x0, 0xaaaa, 0x18, PM_UNIT_LTC1, 1, 1},
    {KEPLER_LTC2_HIT, kepler_ltc2_hit_enc_str_1, 0x0, 0xaaaa, 0x18, PM_UNIT_LTC1, 1, 2},
    {KEPLER_LTC3_HIT, kepler_ltc3_hit_enc_str_1, 0x0, 0xaaaa, 0x18, PM_UNIT_LTC1, 1, 3},
    {KEPLER_LTC0_REQUEST_ATOMIC_OP, kepler_ltc0_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x25, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_REQUEST_ATOMIC_OP, kepler_ltc1_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x25, PM_UNIT_LTC1, 1, 1},
    {KEPLER_LTC2_REQUEST_ATOMIC_OP, kepler_ltc2_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x25, PM_UNIT_LTC1, 1, 2},
    {KEPLER_LTC3_REQUEST_ATOMIC_OP, kepler_ltc3_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x25, PM_UNIT_LTC1, 1, 3},
    {KEPLER_LTC0_REQUEST, kepler_ltc0_request_enc_str_1, 0x0, 0xaaaa, 0x11, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_REQUEST, kepler_ltc1_request_enc_str_1, 0x0, 0xaaaa, 0x11, PM_UNIT_LTC1, 1, 1},
    {KEPLER_LTC2_REQUEST, kepler_ltc2_request_enc_str_1, 0x0, 0xaaaa, 0x11, PM_UNIT_LTC1, 1, 2},
    {KEPLER_LTC3_REQUEST, kepler_ltc3_request_enc_str_1, 0x0, 0xaaaa, 0x11, PM_UNIT_LTC1, 1, 3},

    {KEPLER_LTC0_REQUEST_APERTURE_SYSMEM, kepler_ltc0_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x21, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_REQUEST_APERTURE_SYSMEM, kepler_ltc1_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x21, PM_UNIT_LTC1, 1, 1},
    {KEPLER_LTC2_REQUEST_APERTURE_SYSMEM, kepler_ltc2_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x21, PM_UNIT_LTC1, 1, 2},
    {KEPLER_LTC3_REQUEST_APERTURE_SYSMEM, kepler_ltc3_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x21, PM_UNIT_LTC1, 1, 3},
    {KEPLER_LTC0_REQUEST_APERTURE_VIDMEM, kepler_ltc0_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x20, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_REQUEST_APERTURE_VIDMEM, kepler_ltc1_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x20, PM_UNIT_LTC1, 1, 1},
    {KEPLER_LTC2_REQUEST_APERTURE_VIDMEM, kepler_ltc2_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x20, PM_UNIT_LTC1, 1, 2},
    {KEPLER_LTC3_REQUEST_APERTURE_VIDMEM, kepler_ltc3_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x20, PM_UNIT_LTC1, 1, 3},
    {KEPLER_LTC0_REQUEST_SRC_UNIT_GCC, kepler_ltc0_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 0},
    {KEPLER_LTC1_REQUEST_SRC_UNIT_GCC, kepler_ltc1_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 1},
    {KEPLER_LTC2_REQUEST_SRC_UNIT_GCC, kepler_ltc2_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 2},
    {KEPLER_LTC3_REQUEST_SRC_UNIT_GCC, kepler_ltc3_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 3},
    {KEPLER_LTC0_REQUEST_SRC_UNIT_L1, kepler_ltc0_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 0},
    {KEPLER_LTC1_REQUEST_SRC_UNIT_L1, kepler_ltc1_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 1},
    {KEPLER_LTC2_REQUEST_SRC_UNIT_L1, kepler_ltc2_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 2},
    {KEPLER_LTC3_REQUEST_SRC_UNIT_L1, kepler_ltc3_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 3},
    {KEPLER_LTC0_REQUEST_SRC_UNIT_TEX, kepler_ltc0_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 0},
    {KEPLER_LTC1_REQUEST_SRC_UNIT_TEX, kepler_ltc1_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 1},
    {KEPLER_LTC2_REQUEST_SRC_UNIT_TEX, kepler_ltc2_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 2},
    {KEPLER_LTC3_REQUEST_SRC_UNIT_TEX, kepler_ltc3_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 3},

    { INVALID_PM_SIGNAL_NEW,        "",                                 0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpmExpt PerfSignalTableGK104_ltc0_expt[] = {
    //write a combination of the signals.
    { KEPLER_LTC0_WRITE_L1_SECTORS_FBP, kepler_ltc0_write_l1_sectors_fbp_enc_str_1, KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_WR_OP, KEPLER_LTC0_REQUEST_SRC_UNIT_L1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC1_WRITE_L1_SECTORS_FBP, kepler_ltc1_write_l1_sectors_fbp_enc_str_1, KEPLER_LTC1_REQUEST_SECTORS, {KEPLER_LTC1_REQUEST_ACTIVE, KEPLER_LTC1_REQUEST_WR_OP, KEPLER_LTC1_REQUEST_SRC_UNIT_L1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC2_WRITE_L1_SECTORS_FBP, kepler_ltc2_write_l1_sectors_fbp_enc_str_1, KEPLER_LTC2_REQUEST_SECTORS, {KEPLER_LTC2_REQUEST_ACTIVE, KEPLER_LTC2_REQUEST_WR_OP, KEPLER_LTC2_REQUEST_SRC_UNIT_L1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC3_WRITE_L1_SECTORS_FBP, kepler_ltc3_write_l1_sectors_fbp_enc_str_1, KEPLER_LTC3_REQUEST_SECTORS, {KEPLER_LTC3_REQUEST_ACTIVE, KEPLER_LTC3_REQUEST_WR_OP, KEPLER_LTC3_REQUEST_SRC_UNIT_L1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { KEPLER_LTC0_ATOMIC_L1_SECTORS_FBP, kepler_ltc0_atomic_l1_sectors_fbp_enc_str_1, KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_ATOMIC_OP, KEPLER_LTC0_REQUEST_SRC_UNIT_L1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC1_ATOMIC_L1_SECTORS_FBP, kepler_ltc1_atomic_l1_sectors_fbp_enc_str_1, KEPLER_LTC1_REQUEST_SECTORS, {KEPLER_LTC1_REQUEST_ACTIVE, KEPLER_LTC1_REQUEST_ATOMIC_OP, KEPLER_LTC1_REQUEST_SRC_UNIT_L1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC2_ATOMIC_L1_SECTORS_FBP, kepler_ltc2_atomic_l1_sectors_fbp_enc_str_1, KEPLER_LTC2_REQUEST_SECTORS, {KEPLER_LTC2_REQUEST_ACTIVE, KEPLER_LTC2_REQUEST_ATOMIC_OP, KEPLER_LTC2_REQUEST_SRC_UNIT_L1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC3_ATOMIC_L1_SECTORS_FBP, kepler_ltc3_atomic_l1_sectors_fbp_enc_str_1, KEPLER_LTC3_REQUEST_SECTORS, {KEPLER_LTC3_REQUEST_ACTIVE, KEPLER_LTC3_REQUEST_ATOMIC_OP, KEPLER_LTC3_REQUEST_SRC_UNIT_L1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { KEPLER_LTC0_READ_L1_SECTORS_FBP, kepler_ltc0_read_l1_sectors_fbp_enc_str_1,  KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_RD_OP, KEPLER_LTC0_REQUEST_SRC_UNIT_L1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC1_READ_L1_SECTORS_FBP, kepler_ltc1_read_l1_sectors_fbp_enc_str_1,  KEPLER_LTC1_REQUEST_SECTORS, {KEPLER_LTC1_REQUEST_ACTIVE, KEPLER_LTC1_REQUEST_RD_OP, KEPLER_LTC1_REQUEST_SRC_UNIT_L1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC2_READ_L1_SECTORS_FBP, kepler_ltc2_read_l1_sectors_fbp_enc_str_1,  KEPLER_LTC2_REQUEST_SECTORS, {KEPLER_LTC2_REQUEST_ACTIVE, KEPLER_LTC2_REQUEST_RD_OP, KEPLER_LTC2_REQUEST_SRC_UNIT_L1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC3_READ_L1_SECTORS_FBP, kepler_ltc3_read_l1_sectors_fbp_enc_str_1,  KEPLER_LTC3_REQUEST_SECTORS, {KEPLER_LTC3_REQUEST_ACTIVE, KEPLER_LTC3_REQUEST_RD_OP, KEPLER_LTC3_REQUEST_SRC_UNIT_L1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_hit_sectors_l1_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_src_unit_l1 & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_hit
    { KEPLER_LTC0_WRITE_L1_HIT_SECTORS_FBP, kepler_ltc0_write_l1_hit_sectors_fbp_enc_str_1, KEPLER_LTC0_HIT_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_WR_OP, KEPLER_LTC0_REQUEST_SRC_UNIT_L1, KEPLER_LTC0_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},
    { KEPLER_LTC1_WRITE_L1_HIT_SECTORS_FBP, kepler_ltc1_write_l1_hit_sectors_fbp_enc_str_1, KEPLER_LTC1_HIT_SECTORS, {KEPLER_LTC1_REQUEST_ACTIVE, KEPLER_LTC1_REQUEST_WR_OP, KEPLER_LTC1_REQUEST_SRC_UNIT_L1, KEPLER_LTC1_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},
    { KEPLER_LTC2_WRITE_L1_HIT_SECTORS_FBP, kepler_ltc2_write_l1_hit_sectors_fbp_enc_str_1, KEPLER_LTC2_HIT_SECTORS, {KEPLER_LTC2_REQUEST_ACTIVE, KEPLER_LTC2_REQUEST_WR_OP, KEPLER_LTC2_REQUEST_SRC_UNIT_L1, KEPLER_LTC2_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},
    { KEPLER_LTC3_WRITE_L1_HIT_SECTORS_FBP, kepler_ltc3_write_l1_hit_sectors_fbp_enc_str_1, KEPLER_LTC3_HIT_SECTORS, {KEPLER_LTC3_REQUEST_ACTIVE, KEPLER_LTC3_REQUEST_WR_OP, KEPLER_LTC3_REQUEST_SRC_UNIT_L1, KEPLER_LTC3_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},

    { KEPLER_LTC0_READ_L1_HIT_SECTORS_FBP, kepler_ltc0_read_l1_hit_sectors_fbp_enc_str_1, KEPLER_LTC0_HIT_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_RD_OP, KEPLER_LTC0_REQUEST_SRC_UNIT_L1, KEPLER_LTC0_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},
    { KEPLER_LTC1_READ_L1_HIT_SECTORS_FBP, kepler_ltc1_read_l1_hit_sectors_fbp_enc_str_1, KEPLER_LTC1_HIT_SECTORS, {KEPLER_LTC1_REQUEST_ACTIVE, KEPLER_LTC1_REQUEST_RD_OP, KEPLER_LTC1_REQUEST_SRC_UNIT_L1, KEPLER_LTC1_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},
    { KEPLER_LTC2_READ_L1_HIT_SECTORS_FBP, kepler_ltc2_read_l1_hit_sectors_fbp_enc_str_1, KEPLER_LTC2_HIT_SECTORS, {KEPLER_LTC2_REQUEST_ACTIVE, KEPLER_LTC2_REQUEST_RD_OP, KEPLER_LTC2_REQUEST_SRC_UNIT_L1, KEPLER_LTC2_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},
    { KEPLER_LTC3_READ_L1_HIT_SECTORS_FBP, kepler_ltc3_read_l1_hit_sectors_fbp_enc_str_1, KEPLER_LTC3_HIT_SECTORS, {KEPLER_LTC3_REQUEST_ACTIVE, KEPLER_LTC3_REQUEST_RD_OP, KEPLER_LTC3_REQUEST_SRC_UNIT_L1, KEPLER_LTC3_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},

    // ltc_read_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { KEPLER_LTC0_READ_TEX_SECTORS_FBP, kepler_ltc0_read_tex_sectors_fbp_enc_str_1, KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_RD_OP, KEPLER_LTC0_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC1_READ_TEX_SECTORS_FBP, kepler_ltc1_read_tex_sectors_fbp_enc_str_1, KEPLER_LTC1_REQUEST_SECTORS, {KEPLER_LTC1_REQUEST_ACTIVE, KEPLER_LTC1_REQUEST_RD_OP, KEPLER_LTC1_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC2_READ_TEX_SECTORS_FBP, kepler_ltc2_read_tex_sectors_fbp_enc_str_1, KEPLER_LTC2_REQUEST_SECTORS, {KEPLER_LTC2_REQUEST_ACTIVE, KEPLER_LTC2_REQUEST_RD_OP, KEPLER_LTC2_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC3_READ_TEX_SECTORS_FBP, kepler_ltc3_read_tex_sectors_fbp_enc_str_1, KEPLER_LTC3_REQUEST_SECTORS, {KEPLER_LTC3_REQUEST_ACTIVE, KEPLER_LTC3_REQUEST_RD_OP, KEPLER_LTC3_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_hit_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_hit
    { KEPLER_LTC0_READ_TEX_HIT_SECTORS_FBP, kepler_ltc0_read_tex_hit_sectors_fbp_enc_str_1,  KEPLER_LTC0_HIT_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_RD_OP, KEPLER_LTC0_REQUEST_SRC_UNIT_TEX, KEPLER_LTC0_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},
    { KEPLER_LTC1_READ_TEX_HIT_SECTORS_FBP, kepler_ltc1_read_tex_hit_sectors_fbp_enc_str_1,  KEPLER_LTC1_HIT_SECTORS, {KEPLER_LTC1_REQUEST_ACTIVE, KEPLER_LTC1_REQUEST_RD_OP, KEPLER_LTC1_REQUEST_SRC_UNIT_TEX, KEPLER_LTC1_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},
    { KEPLER_LTC2_READ_TEX_HIT_SECTORS_FBP, kepler_ltc2_read_tex_hit_sectors_fbp_enc_str_1,  KEPLER_LTC2_HIT_SECTORS, {KEPLER_LTC2_REQUEST_ACTIVE, KEPLER_LTC2_REQUEST_RD_OP, KEPLER_LTC2_REQUEST_SRC_UNIT_TEX, KEPLER_LTC2_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},
    { KEPLER_LTC3_READ_TEX_HIT_SECTORS_FBP, kepler_ltc3_read_tex_hit_sectors_fbp_enc_str_1,  KEPLER_LTC3_HIT_SECTORS, {KEPLER_LTC3_REQUEST_ACTIVE, KEPLER_LTC3_REQUEST_RD_OP, KEPLER_LTC3_REQUEST_SRC_UNIT_TEX, KEPLER_LTC3_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},

    { KEPLER_LTC0_READ_SYSMEM_SECTORS_FBP, kepler_ltc0_read_sysmem_sectors_fbp_enc_str_1, KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_RD_OP, KEPLER_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC1_READ_SYSMEM_SECTORS_FBP, kepler_ltc1_read_sysmem_sectors_fbp_enc_str_1, KEPLER_LTC1_REQUEST_SECTORS, {KEPLER_LTC1_REQUEST_ACTIVE, KEPLER_LTC1_REQUEST_RD_OP, KEPLER_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC2_READ_SYSMEM_SECTORS_FBP, kepler_ltc2_read_sysmem_sectors_fbp_enc_str_1, KEPLER_LTC2_REQUEST_SECTORS, {KEPLER_LTC2_REQUEST_ACTIVE, KEPLER_LTC2_REQUEST_RD_OP, KEPLER_LTC2_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC3_READ_SYSMEM_SECTORS_FBP, kepler_ltc3_read_sysmem_sectors_fbp_enc_str_1, KEPLER_LTC3_REQUEST_SECTORS, {KEPLER_LTC3_REQUEST_ACTIVE, KEPLER_LTC3_REQUEST_RD_OP, KEPLER_LTC3_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { KEPLER_LTC0_WRITE_SYSMEM_SECTORS_FBP, kepler_ltc0_write_sysmem_sectors_fbp_enc_str_1, KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_WR_OP, KEPLER_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC1_WRITE_SYSMEM_SECTORS_FBP, kepler_ltc1_write_sysmem_sectors_fbp_enc_str_1, KEPLER_LTC1_REQUEST_SECTORS, {KEPLER_LTC1_REQUEST_ACTIVE, KEPLER_LTC1_REQUEST_WR_OP, KEPLER_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC2_WRITE_SYSMEM_SECTORS_FBP, kepler_ltc2_write_sysmem_sectors_fbp_enc_str_1, KEPLER_LTC2_REQUEST_SECTORS, {KEPLER_LTC2_REQUEST_ACTIVE, KEPLER_LTC2_REQUEST_WR_OP, KEPLER_LTC2_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC3_WRITE_SYSMEM_SECTORS_FBP, kepler_ltc3_write_sysmem_sectors_fbp_enc_str_1, KEPLER_LTC3_REQUEST_SECTORS, {KEPLER_LTC3_REQUEST_ACTIVE, KEPLER_LTC3_REQUEST_WR_OP, KEPLER_LTC3_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { KEPLER_LTC0_TOTAL_READ_SECTORS_FBP, kepler_ltc0_total_read_sectors_fbp_enc_str_1, KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ATOMIC_OP, KEPLER_LTC0_REQUEST_RD_OP, KEPLER_LTC0_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC1_TOTAL_READ_SECTORS_FBP, kepler_ltc1_total_read_sectors_fbp_enc_str_1, KEPLER_LTC1_REQUEST_SECTORS, {KEPLER_LTC1_REQUEST_ATOMIC_OP, KEPLER_LTC1_REQUEST_RD_OP, KEPLER_LTC1_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC2_TOTAL_READ_SECTORS_FBP, kepler_ltc2_total_read_sectors_fbp_enc_str_1, KEPLER_LTC2_REQUEST_SECTORS, {KEPLER_LTC2_REQUEST_ATOMIC_OP, KEPLER_LTC2_REQUEST_RD_OP, KEPLER_LTC2_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC3_TOTAL_READ_SECTORS_FBP, kepler_ltc3_total_read_sectors_fbp_enc_str_1, KEPLER_LTC3_REQUEST_SECTORS, {KEPLER_LTC3_REQUEST_ATOMIC_OP, KEPLER_LTC3_REQUEST_RD_OP, KEPLER_LTC3_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { KEPLER_LTC0_TOTAL_WRITE_SECTORS_FBP, kepler_ltc0_total_write_sectors_fbp_enc_str_1, KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ATOMIC_OP, KEPLER_LTC0_REQUEST_WR_OP, KEPLER_LTC0_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC1_TOTAL_WRITE_SECTORS_FBP, kepler_ltc1_total_write_sectors_fbp_enc_str_1, KEPLER_LTC1_REQUEST_SECTORS, {KEPLER_LTC1_REQUEST_ATOMIC_OP, KEPLER_LTC1_REQUEST_WR_OP, KEPLER_LTC1_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC2_TOTAL_WRITE_SECTORS_FBP, kepler_ltc2_total_write_sectors_fbp_enc_str_1, KEPLER_LTC2_REQUEST_SECTORS, {KEPLER_LTC2_REQUEST_ATOMIC_OP, KEPLER_LTC2_REQUEST_WR_OP, KEPLER_LTC2_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC3_TOTAL_WRITE_SECTORS_FBP, kepler_ltc3_total_write_sectors_fbp_enc_str_1, KEPLER_LTC3_REQUEST_SECTORS, {KEPLER_LTC3_REQUEST_ATOMIC_OP, KEPLER_LTC3_REQUEST_WR_OP, KEPLER_LTC3_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { KEPLER_LTC0_READ_VIDMEM_SECTORS_FBP,      kepler_ltc0_read_vidmem_sectors_fbp_enc_str_1,    KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_RD_OP, KEPLER_LTC0_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC1_READ_VIDMEM_SECTORS_FBP,      kepler_ltc1_read_vidmem_sectors_fbp_enc_str_1,    KEPLER_LTC1_REQUEST_SECTORS, {KEPLER_LTC1_REQUEST_ACTIVE, KEPLER_LTC1_REQUEST_RD_OP, KEPLER_LTC1_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC2_READ_VIDMEM_SECTORS_FBP,      kepler_ltc2_read_vidmem_sectors_fbp_enc_str_1,    KEPLER_LTC2_REQUEST_SECTORS, {KEPLER_LTC2_REQUEST_ACTIVE, KEPLER_LTC2_REQUEST_RD_OP, KEPLER_LTC2_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC3_READ_VIDMEM_SECTORS_FBP,      kepler_ltc3_read_vidmem_sectors_fbp_enc_str_1,    KEPLER_LTC3_REQUEST_SECTORS, {KEPLER_LTC3_REQUEST_ACTIVE, KEPLER_LTC3_REQUEST_RD_OP, KEPLER_LTC3_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { KEPLER_LTC0_WRITE_VIDMEM_SECTORS_FBP,      kepler_ltc0_write_vidmem_sectors_fbp_enc_str_1,    KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_WR_OP, KEPLER_LTC0_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC1_WRITE_VIDMEM_SECTORS_FBP,      kepler_ltc1_write_vidmem_sectors_fbp_enc_str_1,    KEPLER_LTC1_REQUEST_SECTORS, {KEPLER_LTC1_REQUEST_ACTIVE, KEPLER_LTC1_REQUEST_WR_OP, KEPLER_LTC1_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC2_WRITE_VIDMEM_SECTORS_FBP,      kepler_ltc2_write_vidmem_sectors_fbp_enc_str_1,    KEPLER_LTC2_REQUEST_SECTORS, {KEPLER_LTC2_REQUEST_ACTIVE, KEPLER_LTC2_REQUEST_WR_OP, KEPLER_LTC2_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC3_WRITE_VIDMEM_SECTORS_FBP,      kepler_ltc3_write_vidmem_sectors_fbp_enc_str_1,    KEPLER_LTC3_REQUEST_SECTORS, {KEPLER_LTC3_REQUEST_ACTIVE, KEPLER_LTC3_REQUEST_WR_OP, KEPLER_LTC3_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_pm_request_src_unit_gcc_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_src_unit_gcc & ltc2pm_ltc_lts0_request
    { KEPLER_LTC0_PM_REQ_SRC_UNIT_GCC_FBP,      kepler_ltc0_pm_req_src_unit_gcc_fbp_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_LTC0_REQUEST_SRC_UNIT_GCC, KEPLER_LTC0_REQUEST, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_LTC1_PM_REQ_SRC_UNIT_GCC_FBP,      kepler_ltc1_pm_req_src_unit_gcc_fbp_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_LTC1_REQUEST_SRC_UNIT_GCC, KEPLER_LTC1_REQUEST, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_LTC2_PM_REQ_SRC_UNIT_GCC_FBP,      kepler_ltc2_pm_req_src_unit_gcc_fbp_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_LTC2_REQUEST_SRC_UNIT_GCC, KEPLER_LTC2_REQUEST, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_LTC3_PM_REQ_SRC_UNIT_GCC_FBP,      kepler_ltc3_pm_req_src_unit_gcc_fbp_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_LTC3_REQUEST_SRC_UNIT_GCC, KEPLER_LTC3_REQUEST, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000,  0x00},
};

PerfSignalSmpc PerfSignalTableGK104_sm0[] = {
    // QCTL Signals

    //["GROUP1" =>
    //    ["nop_trig0",               1,      "off",  "# of nop.trig instructions executed where bit 0 of #Imm16 was set", undef],
    //    ["nop_trig1",               1,      "off",  "# of nop.trig instructions executed where bit 1 of #Imm16 was set", undef],
    //    ["nop_trig2",               1,      "off",  "# of nop.trig instructions executed where bit 2 of #Imm16 was set", undef],
    //    ["nop_trig3",               1,      "off",  "# of nop.trig instructions executed where bit 3 of #Imm16 was set", undef],
    //    ["nop_trig4",               1,      "off",  "# of nop.trig instructions executed where bit 4 of #Imm16 was set", undef],
    //    ["nop_trig5",               1,      "off",  "# of nop.trig instructions executed where bit 5 of #Imm16 was set", undef],
    //    ["nop_trig6",               1,      "off",  "# of nop.trig instructions executed where bit 6 of #Imm16 was set", undef],
    //    ["nop_trig7",               1,      "off",  "# of nop.trig instructions executed where bit 7 of #Imm16 was set", undef],
    //],
    //["GROUP2" =>
    //    ["nop_trig8",               1,      "off",  "# of nop.trig instructions executed where bit 8 of #Imm16 was set", undef],
    //    ["nop_trig9",               1,      "off",  "# of nop.trig instructions executed where bit 9 of #Imm16 was set", undef],
    //    ["nop_trig10",              1,      "off",  "# of nop.trig instructions executed where bit 10 of #Imm16 was set", undef],
    //    ["nop_trig11",              1,      "off",  "# of nop.trig instructions executed where bit 11 of #Imm16 was set", undef],
    //    ["nop_trig12",              1,      "off",  "# of nop.trig instructions executed where bit 12 of #Imm16 was set", undef],
    //    ["nop_trig13",              1,      "off",  "# of nop.trig instructions executed where bit 13 of #Imm16 was set", undef],
    //    ["nop_trig14",              1,      "off",  "# of nop.trig instructions executed where bit 14 of #Imm16 was set", undef],
    //    ["nop_trig15",              1,      "off",  "# of nop.trig instructions executed where bit 15 of #Imm16 was set", undef],
    //],
    { KEPLER_SM_NOP_TRIG_00,                      kepler_sm_nop_trig_00_enc_str_1,      0x00000001, 0x00000000, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_01,                      kepler_sm_nop_trig_01_enc_str_1,      0x00000001, 0x00000001, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_02,                      kepler_sm_nop_trig_02_enc_str_1,      0x00000001, 0x00000002, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_03,                      kepler_sm_nop_trig_03_enc_str_1,      0x00000001, 0x00000003, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_04,                      kepler_sm_nop_trig_04_enc_str_1,      0x00000001, 0x00000004, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_05,                      kepler_sm_nop_trig_05_enc_str_1,      0x00000001, 0x00000005, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_06,                      kepler_sm_nop_trig_06_enc_str_1,      0x00000001, 0x00000006, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_07,                      kepler_sm_nop_trig_07_enc_str_1,      0x00000001, 0x00000007, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_08,                      kepler_sm_nop_trig_08_enc_str_1,        0x00000002, 0x00000000, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_09,                      kepler_sm_nop_trig_09_enc_str_1,        0x00000002, 0x00000001, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_10,                      kepler_sm_nop_trig_10_enc_str_1,        0x00000002, 0x00000002, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_11,                      kepler_sm_nop_trig_11_enc_str_1,        0x00000002, 0x00000003, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_12,                      kepler_sm_nop_trig_12_enc_str_1,        0x00000002, 0x00000004, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_13,                      kepler_sm_nop_trig_13_enc_str_1,        0x00000002, 0x00000005, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_14,                      kepler_sm_nop_trig_14_enc_str_1,        0x00000002, 0x00000006, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_15,                      kepler_sm_nop_trig_15_enc_str_1,        0x00000002, 0x00000007, 0x00000001,    PM_UNIT_SMQCTL,1 },

    //["GROUP3" =>
    //    ["active_cycles_quad",      1,      "on",   "Sum of active cycles from all quads having At least 1 active warp",  undef],
    //    ["warps_launched",          1,      "on",   "If a warp was launched this cycle in this quad",       undef],
    //    ["threads_launched",        6,      "on",   "Number of threads launched this cycle in this quad",   undef],
    //],
    { KEPLER_SM_ACTIVE_CYCLES_QUAD,       kepler_sm_active_cycles_quad_enc_str_1,  0x00000003, 0x00000000, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_WARPS_LAUNCHED,           kepler_sm_warps_launched_enc_str_1,      0x00000003, 0x00000001, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_THREADS_LAUNCHED,         kepler_sm_threads_launched_enc_str_1,    0x00000003, 0x00765432, 0x0000003f,    PM_UNIT_SMQCTL,6 },

    //["GROUP5" =>
    //    ["inst_issued0",                    1,      "on",   "# of cycles issued 0 instructions",        undef],
    //    ["inst_issued1",                    1,      "on",   "# of cycles issued 1 instructions",        undef],
    //    ["inst_issued2",                    1,      "on",   "# of cycles issued 2 instructions",        undef],
    //]
    { KEPLER_SM_INST_ISSUED_1,             kepler_sm_inst_issued_1_enc_str_1,       0x00000005, 0x00000001, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_2,             kepler_sm_inst_issued_2_enc_str_1,       0x00000005, 0x00000002, 0x00000001,    PM_UNIT_SMQCTL,1 },

    //["GROUP4" =>
    //    ["threads_launched_for_execution",  6,      "on",   "Number of threads launched for execution, including helper threads", undef],
    //    ["inst_executed",                   2,      "on",   "# of instructions executed",              undef],
    //],
    { KEPLER_SM_INST_EXECUTED,            kepler_sm_inst_executed_enc_str_1,       0x00000004, 0x00000076, 0x00000003,    PM_UNIT_SMQCTL,2 },

#if 0
    // Disabling due to Bug 901771
    //["GROUP17" =>
    //    ["thread_inst_executed",    6,      "on",   "Number of thread instruction executed this cycle in this quad",   undef],
    //],
    { KEPLER_SM_THREAD_INST_EXECUTED,         kepler_sm_thread_inst_executed_enc_str_1,0x00000011, 0x00543210, 0x0000003f,    PM_UNIT_SMQCTL, 6 },

    //["GROUP20" =>
    //    ["not_predicated_off_thread_inst_executed", 6,      "off",  "# executed but not predicated off thread instructions", undef],
    //],
    { KEPLER_SM_NOT_PREDICATED_OFF_THREAD_INST_EXECUTED, kepler_sm_not_predicated_off_thread_inst_executed_enc_str_1,  0x00000014, 0x00543210, 0x0000003f,    PM_UNIT_SMQCTL,6 },
#endif

    //["GROUP18" =>
    //    ["tex_quad_fetches",                1,      "on",   "Texture quad requests in this quad",   undef],
    //],
    { KEPLER_SM_TEX_QUAD_FETCHES,             kepler_sm_tex_quad_fetches_enc_str_1,0x00000012, 0x00000000, 0x00000001,    PM_UNIT_SMQCTL,1 },

    //["GROUP29" =>
    //    ["inst_executed_lsu_size_128",      1,      "off",  "128b lsu instr",    undef],
    //    ["inst_executed_lsu_size_64",       1,      "off",  "64b lsu instr",     undef],
    //    ["inst_executed_lsu_size_32",       1,      "off",  "32b lsu instr",     undef],
    //    ["inst_executed_lsu_sub_size_32",   1,      "off",  "< 32b lsu instr",   undef],
    //],
    { KEPLER_SM_INST_EXECUTED_LSU_SIZE_128,     kepler_sm_inst_executed_lsu_size_128_enc_str_1,       0x0000001D, 0x00000000, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_SIZE_64,      kepler_sm_inst_executed_lsu_size_64_enc_str_1,        0x0000001D, 0x00000002, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_SIZE_32,      kepler_sm_inst_executed_lsu_size_32_enc_str_1,        0x0000001D, 0x00000003, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_SUB_SIZE_32,  kepler_sm_inst_executed_lsu_sub_size_32_enc_str_1,    0x0000001D, 0x00000004, 0x00000001,    PM_UNIT_SMQCTL,1 },

    //["GROUP27" =>
    //    ["inst_executed_lsu_lds",           1,      "off",  "shared store ",    undef],
    //    ["inst_executed_lsu_sts",           1,      "off",  "shared load ",     undef],
    //    ["inst_executed_lsu_ldl",           1,      "off",  "local load ",      undef],
    //    ["inst_executed_lsu_stl",           1,      "off",  "local store ",     undef],
    //    ["inst_executed_lsu_ld",            1,      "off",  "generic load",     undef],
    //    ["inst_executed_lsu_st",            1,      "off",  "generic store",    undef],
    //],
    { KEPLER_SM_SHARED_LOAD,                       kepler_sm_shared_load_enc_str_1,         0x0000001B, 0x00000000, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_SHARED_STORE,                      kepler_sm_shared_store_enc_str_1,        0x0000001B, 0x00000001, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_LOCAL_LOAD,                        kepler_sm_local_load_enc_str_1,          0x0000001B, 0x00000002, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_LOCAL_STORE,                       kepler_sm_local_store_enc_str_1,         0x0000001B, 0x00000003, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_GENERIC_LOAD,                      kepler_sm_generic_load_enc_str_1,         0x0000001B, 0x00000004, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_GENERIC_STORE,                     kepler_sm_generic_store_enc_str_1,         0x0000001B, 0x00000005, 0x00000001,    PM_UNIT_SMQCTL,1 },

    //["GROUP28" =>
    //    ["inst_executed_lsu_atom",          1,      "off",  "atom",             undef],
    //    ["inst_executed_lsu_red",           1,      "off",  "reduction",        undef],
    //    ["br_executed",                     1,      "off",  "unique committed branch", undef],
    //    ["diverged_br_executed",            1,      "off",  "unique branches that diverge", undef],
    //],
    { KEPLER_SM_L1C_ATOM_COUNT,                    kepler_sm_l1c_atom_count_enc_str_1,        0x0000001C, 0x00000000, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_L1_ATOM_CAS_COUNT,                 kepler_sm_l1_atom_cas_count_enc_str_1,     0x0000001C, 0x00000001, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_L1C_GRED_COUNT,                    kepler_sm_l1c_gred_count_enc_str_1,        0x0000001C, 0x00000002, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_UNIQUE_BRANCHES,                   kepler_sm_unique_branches_enc_str_1,               0x0000001C, 0x00000003, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_DIVERGED_BRANCHES,                 kepler_sm_diverged_branches_enc_str_1,     0x0000001C, 0x00000004, 0x00000001,    PM_UNIT_SMQCTL,1 },


    // CORE and L1C Signals

    //["GROUP2_CORE" =>
    //    ["active_cycles",           1,      "on",   "At least 1 active warp",                   undef],
    //    ["active_warps",            6,      "on",   "Number of active warps total in the SM",   undef],
    //    ["ctas_launched",           1,      "on",   "Number of CTAs launched in the SM",        undef],
    //],
    { KEPLER_SM_ACTIVE_CYCLES,                kepler_sm_active_cycles_enc_str_1,      0x00000002, 0x00000000, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_ACTIVE_WARPS,                 kepler_sm_active_warps_enc_str_1,       0x00000002, 0x00654321, 0x0000003f,    PM_UNIT_SMCORE,6 },
    { KEPLER_SM_CTA_LAUNCHED,                 kepler_sm_cta_launched_enc_str_1,    0x00000002, 0x00000007, 0x00000001,    PM_UNIT_SMCORE,1 },

    //["GROUP14_LSU" =>
    //    ["local_ld_transactions",   1,      "off",  "count instructions at accept point", undef],
    //    ["local_st_transactions",   1,      "off",  "count instructions at accept point", undef],
    //    ["shared_ld_transactions",  1,      "off",  "count instructions at accept point", undef],
    //    ["shared_st_transactions",  1,      "off",  "count instructions at accept point", undef],
    //],
    //["GROUP15_LSU" =>
    //    ["global_ld_transactions",              1,      "off",   "count instructions at accept point", undef],
    //    ["global_st_transactions",              1,      "off",   "count instructions at accept point", undef],
    //],
    { KEPLER_SM_L1C_LOCAL_LOAD_TRANSACTIONS,      kepler_sm_l1c_local_load_transactions_enc_str_1,   0x0000000e, 0x00000000, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_LOCAL_STORE_TRANSACTIONS,     kepler_sm_l1c_local_store_transactions_enc_str_1,  0x0000000e, 0x00000001, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_SHARED_LOAD_TRANSACTIONS,     kepler_sm_l1c_shared_load_transactions_enc_str_1,  0x0000000e, 0x00000002, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_SHARED_STORE_TRANSACTIONS,    kepler_sm_l1c_shared_store_transactions_enc_str_1, 0x0000000e, 0x00000003, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_GLOBAL_LOAD_TRANSACTIONS,     kepler_sm_l1c_global_load_transactions_enc_str_1,  0x0000000f, 0x00000000, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_GLOBAL_STORE_TRANSACTIONS,    kepler_sm_l1c_global_store_transactions_enc_str_1, 0x0000000f, 0x00000001, 0x00000001,    PM_UNIT_SMCORE,1 },

    //["GROUP16_LSU" =>
    //    ["l1_cached_local_ld_hits",             1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_local_ld_misses",           1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_local_st_hits",             1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_local_st_misses",           1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_global_ld_hits",            1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_global_ld_misses",          1,      "off",   "count instructions at accept point", undef],
    //],
    { KEPLER_SM_L1C_LOCAL_LOAD_HIT,           kepler_sm_l1c_local_load_hit_enc_str_1,    0x00000010, 0x00000000, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_LOCAL_LOAD_MISS,          kepler_sm_l1c_local_load_miss_enc_str_1,   0x00000010, 0x00000001, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_LOCAL_STORE_HIT,          kepler_sm_l1c_local_store_hit_enc_str_1,   0x00000010, 0x00000002, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_LOCAL_STORE_MISS,         kepler_sm_l1c_local_store_miss_enc_str_1,  0x00000010, 0x00000003, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_GLOBAL_LOAD_HIT,          kepler_sm_l1c_global_load_hit_enc_str_1,   0x00000010, 0x00000004, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_GLOBAL_LOAD_MISS,         kepler_sm_l1c_global_load_miss_enc_str_1,  0x00000010, 0x00000005, 0x00000001,    PM_UNIT_SMCORE,1 },

    //["GROUP17_LSU" =>
    //    ["l1_uncached_global_ld_count",         1,      "off",   "count instructions at accept point", undef],
    //    ["l1_global_st_count",                  1,      "off",   "count instructions at accept point", undef],
    { KEPLER_SM_L1C_UNCACHED_GLOBAL_LOAD,         kepler_sm_l1c_uncached_global_load_enc_str_1,  0x00000011, 0x00000000, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_GLOBAL_STORE,                 kepler_sm_l1c_global_store_enc_str_1,          0x00000011, 0x00000001, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_PARTIAL_LOCAL_CACHED_ST_MISSES, kepler_sm_l1c_partial_local_cached_st_misses_enc_str_1, 0x00000011, 0x00000002, 0x00000001,    PM_UNIT_SMCORE,1 },

    //["GROUP8_LSU" =>
    //    ["local_ld_mem_divergence_replays",     1,      "off",   "local ld is replayed due to divergence", undef],
    //    ["local_st_mem_divergence_replays",     1,      "off",   "local st is replayed due to divergence", undef],
    //    ["shared_ld_mem_divergence_replays",    1,      "off",   "shared ld is replayed due to bank conflict", undef],
    //    ["shared_st_mem_divergence_replays",    1,      "off",   "shared st is replayed due to bank conflict", undef],
    //    ["global_ld_mem_divergence_replays",    1,      "off",   "global ld is replayed due to divergence", undef],
    //    ["global_st_mem_divergence_replays",    1,      "off",   "global st is replayed due to divergence", undef],
    //    ["global_red_mem_divergence_replays",   1,      "off",   "global red is replayed due to divergence", undef],
    //    ["global_atom_mem_divergence_replays",  1,      "off",   "global atom is replayed due to divergence", undef],
    //],
    { KEPLER_SM_L1C_LOCAL_LD_MEM_DIVERGENCE_REPLAYS,   kepler_sm_l1c_local_ld_mem_divergence_replays_enc_str_1,  0x00000008, 0x00000000, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_LOCAL_ST_MEM_DIVERGENCE_REPLAYS,   kepler_sm_l1c_local_st_mem_divergence_replays_enc_str_1,  0x00000008, 0x00000001, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_SHARED_LOAD_BANK_CONFLICT,         kepler_sm_l1c_shared_load_bank_conflict_enc_str_1,        0x00000008, 0x00000002, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_SHARED_STORE_BANK_CONFLICT,        kepler_sm_l1c_shared_store_bank_conflict_enc_str_1,       0x00000008, 0x00000003, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_GLOBAL_LD_MEM_DIVERGENCE_REPLAYS,  kepler_sm_l1c_global_ld_mem_divergence_replays_enc_str_1, 0x00000008, 0x00000004, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_GLOBAL_ST_MEM_DIVERGENCE_REPLAYS,  kepler_sm_l1c_global_st_mem_divergence_replays_enc_str_1, 0x00000008, 0x00000005, 0x00000001,    PM_UNIT_SMCORE,1 },

    { KEPLER_SM_WARP_CANT_ISSUE_NO_INST,                      kepler_sm_warp_cant_issue_no_inst_enc_str_1,                    0x00000006, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_DISPATCH_STALL,               kepler_sm_warp_cant_issue_dispatch_stall_enc_str_1,             0x00000006, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_PARTIALLY_LOADED_SUBTILE,     kepler_sm_warp_cant_issue_partially_loaded_subtile_enc_str_1,   0x00000007, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_SWITCHING_IFB,                kepler_sm_warp_cant_issue_switching_ifb_enc_str_1,              0x00000007, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_WAITING,                      kepler_sm_warp_cant_issue_waiting_enc_str_1,                    0x00000008, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_MULTI_ISSUE,                  kepler_sm_warp_cant_issue_multi_issue_enc_str_1,                0x00000008, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_REPLAY_EXECUTING,             kepler_sm_warp_cant_issue_replay_executing_enc_str_1,           0x00000009, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_TEX_EXECUTING,                kepler_sm_warp_cant_issue_tex_executing_enc_str_1,              0x00000009, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_TEX_DEPENDENCY,               kepler_sm_warp_cant_issue_tex_dependency_enc_str_1,             0x0000000a, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_L1_MISS_DEPENDENCY,           kepler_sm_warp_cant_issue_l1_miss_dependency_enc_str_1,         0x0000000a, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_MSB_FULL,                     kepler_sm_warp_cant_issue_msb_full_enc_str_1,                   0x0000000b, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_IMC_MISS_DEPENDENCY,          kepler_sm_warp_cant_issue_imc_miss_dependency_enc_str_1,        0x0000000b, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_SHADOW_PIPE_THROTTLE,         kepler_sm_warp_cant_issue_shadow_pipe_throttle_enc_str_1,       0x0000000c, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_TEX_THROTTLE,                 kepler_sm_warp_cant_issue_tex_throttle_enc_str_1,               0x0000000c, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_RIB_THROTTLE,                 kepler_sm_warp_cant_issue_rib_throttle_enc_str_1,               0x0000000d, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_TEX_LOCK_MISMATCH,            kepler_sm_warp_cant_issue_tex_lock_mismatch_enc_str_1,          0x0000000d, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_MEMBAR,                       kepler_sm_warp_cant_issue_membar_enc_str_1,                     0x0000000e, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_HOLD_MISMATCH,                kepler_sm_warp_cant_issue_hold_mismatch_enc_str_1,              0x0000000f, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_NOT_SELECT,                   kepler_sm_warp_cant_issue_not_select_enc_str_1,                 0x0000000f, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_BARRIER,                      kepler_sm_warp_cant_issue_barrier_enc_str_1,                    0x0000000e, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },

    { KEPLER_SM_INST_ISSUED_XLU_PIPE,                         kepler_sm_inst_issued_xlu_pipe_enc_str_1,                       0x00000015, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_SU_PIPE,                          kepler_sm_inst_issued_su_pipe_enc_str_1,                        0x00000015, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FU_PIPE,                          kepler_sm_inst_issued_fu_pipe_enc_str_1,                        0x00000015, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FMAX_PIPE,                        kepler_sm_inst_issued_fmax_pipe_enc_str_1,                      0x00000015, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FMAXLITEW_PIPE,                   kepler_sm_inst_issued_fmaxlitew_pipe_enc_str_1,                 0x00000015, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FAU_PIPE,                         kepler_sm_inst_issued_fau_pipe_enc_str_1,                       0x00000015, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FE_PIPE,                          kepler_sm_inst_issued_fe_pipe_enc_str_1,                        0x00000015, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_BRU_PIPE,                         kepler_sm_inst_issued_bru_pipe_enc_str_1,                       0x00000015, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FMALITEW_PIPE,                    kepler_sm_inst_issued_fmalitew_pipe_enc_str_1,                  0x00000016, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_ADU_PIPE,                         kepler_sm_inst_issued_adu_pipe_enc_str_1,                       0x00000016, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_AGU_PIPE,                         kepler_sm_inst_issued_agu_pipe_enc_str_1,                       0x00000016, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_TEX_PIPE,                         kepler_sm_inst_issued_tex_pipe_enc_str_1,                       0x00000016, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FP64_TO_FMAX_PIPE,                kepler_sm_inst_issued_fp64_to_fmax_pipe_enc_str_1,              0x00000016, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FP64_TO_FMAXLITE_PIPE,            kepler_sm_inst_issued_fp64_to_fmaxlite_pipe_enc_str_1,          0x00000016, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_XLU_PIPE,                       kepler_sm_inst_executed_xlu_pipe_enc_str_1,                     0x00000017, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_SU_PIPE,                        kepler_sm_inst_executed_su_pipe_enc_str_1,                      0x00000017, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_FU_PIPE,                        kepler_sm_inst_executed_fu_pipe_enc_str_1,                      0x00000017, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_FMAX_PIPE,                      kepler_sm_inst_executed_fmax_pipe_enc_str_1,                    0x00000017, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_FMAXLITEW_PIPE,                 kepler_sm_inst_executed_fmaxlitew_pipe_enc_str_1,               0x00000017, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_FAU_PIPE,                       kepler_sm_inst_executed_fau_pipe_enc_str_1,                     0x00000017, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_FE_PIPE,                        kepler_sm_inst_executed_fe_pipe_enc_str_1,                      0x00000017, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_BRU_PIPE,                       kepler_sm_inst_executed_bru_pipe_enc_str_1,                     0x00000017, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_FMALITEW_PIPE,                  kepler_sm_inst_executed_fmalitew_pipe_enc_str_1,                0x00000018, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_ADU_PIPE,                       kepler_sm_inst_executed_adu_pipe_enc_str_1,                     0x00000018, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_AGU_PIPE,                       kepler_sm_inst_executed_agu_pipe_enc_str_1,                     0x00000018, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_TEX_PIPE,                       kepler_sm_inst_executed_tex_pipe_enc_str_1,                     0x00000018, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_TCS,                            kepler_sm_inst_executed_tcs_enc_str_1,                          0x00000018, 0x00000054, 0x00000003, PM_UNIT_SMQCTL,2 },
    { KEPLER_SM_INST_EXECUTED_TES,                            kepler_sm_inst_executed_tes_enc_str_1,                          0x00000018, 0x00000076, 0x00000003, PM_UNIT_SMQCTL,2 },
    { KEPLER_SM_INST_EXECUTED_VS,                             kepler_sm_inst_executed_vs_enc_str_1,                           0x00000019, 0x00000010, 0x00000003, PM_UNIT_SMQCTL,2 },
    { KEPLER_SM_INST_EXECUTED_PS,                             kepler_sm_inst_executed_ps_enc_str_1,                           0x00000019, 0x00000032, 0x00000003, PM_UNIT_SMQCTL,2 },
    { KEPLER_SM_INST_EXECUTED_GS,                             kepler_sm_inst_executed_gs_enc_str_1,                           0x00000019, 0x00000054, 0x00000003, PM_UNIT_SMQCTL,2 },
    { KEPLER_SM_INST_EXECUTED_CS,                             kepler_sm_inst_executed_cs_enc_str_1,                           0x00000019, 0x00000076, 0x00000003, PM_UNIT_SMQCTL,2 },
    { KEPLER_SM_INST_EXECUTED_LSU_SULDGA_B,                   kepler_sm_inst_executed_lsu_suldga_b_enc_str_1,                 0x0000001a, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_SULDGA_P,                   kepler_sm_inst_executed_lsu_suldga_p_enc_str_1,                 0x0000001a, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_SUSTGA_B,                   kepler_sm_inst_executed_lsu_sustga_b_enc_str_1,                 0x0000001a, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_SUSTGA_P,                   kepler_sm_inst_executed_lsu_sustga_p_enc_str_1,                 0x0000001a, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_ATOM_CAS,                   kepler_sm_inst_executed_lsu_atom_cas_enc_str_1,                 0x0000001c, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_ICC_HIT,                                      kepler_sm_icc_hit_enc_str_1,                                    0x00000005, 0x00000000, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_ICC_TRUE_MISS,                                kepler_sm_icc_true_miss_enc_str_1,                              0x00000005, 0x00000001, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_ICC_COVERED_MISS,                             kepler_sm_icc_covered_miss_enc_str_1,                           0x00000005, 0x00000002, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_CANT_DISPATCH_REGISTER_INTERLOCK,             kepler_sm_cant_dispatch_register_interlock_enc_str_1,           0x00000010, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_CANT_DISPATCH_MEMORY_INTERLOCK,               kepler_sm_cant_dispatch_memory_interlock_enc_str_1,             0x00000010, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_CANT_DISPATCH_REGISTER_READ,                  kepler_sm_cant_dispatch_register_read_enc_str_1,                0x00000010, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_CANT_DISPATCH_REGISTER_WRITE,                 kepler_sm_cant_dispatch_register_write_enc_str_1,               0x00000010, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_CANT_DISPATCH_CRS_SPILL_FILL,                 kepler_sm_cant_dispatch_crs_spill_fill_enc_str_1,               0x00000010, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_CANT_DISPATCH_ADU_F5_RF_READ,                 kepler_sm_cant_dispatch_adu_f5_rf_read_enc_str_1,               0x00000010, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_PRT_PENDING_ENTRIES,                          kepler_sm_prt_pending_entries_enc_str_1,                        0x0000000b, 0x06543210, 0x0000007f, PM_UNIT_SMCORE,7 },
    { KEPLER_SM_GLOBAL_RED_MEM_DIVERGENCE_REPLAYS,            kepler_sm_global_red_mem_divergence_replays_enc_str_1,          0x00000008, 0x00000006, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_GLOBAL_ATOM_MEM_DIVERGENCE_REPLAYS,           kepler_sm_global_atom_mem_divergence_replays_enc_str_1,         0x00000008, 0x00000007, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_GLOBAL_RED_TRANSACTIONS,                      kepler_sm_global_red_transactions_enc_str_1,                    0x0000000f, 0x00000002, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_GLOBAL_ATOM_TRANSACTIONS,                     kepler_sm_global_atom_transactions_enc_str_1,                   0x0000000f, 0x00000003, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_GLOBAL_ATOM_CAS_TRANSACTIONS,                 kepler_sm_global_atom_cas_transactions_enc_str_1,               0x0000000f, 0x00000004, 0x00000001, PM_UNIT_SMCORE,1 },

    { INVALID_PM_SIGNAL_NEW,            "",                       0xffffffff, 0x00000000, 0x00000000,     PM_UNIT_MAX,0 }
};

PerfSignalSmpc PerfSignalTableGK104_nopTrigSwCounters[] = {
    // TO DO: Change this table and make it more suitable for sw counters as most of the fields are not used
    { KEPLER_SW_COUNTER_GLD8BIT_INST,    kepler_sw_counter_gld8bit_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_GLD16BIT_INST,   kepler_sw_counter_gld16bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_GLD32BIT_INST,   kepler_sw_counter_gld32bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_GLD64BIT_INST,   kepler_sw_counter_gld64bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_GLD128BIT_INST,  kepler_sw_counter_gld128bit_inst_enc_str_1,  0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_GST8BIT_INST,    kepler_sw_counter_gst8bit_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_GST16BIT_INST,   kepler_sw_counter_gst16bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_GST32BIT_INST,   kepler_sw_counter_gst32bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_GST64BIT_INST,   kepler_sw_counter_gst64bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_GST128BIT_INST,  kepler_sw_counter_gst128bit_inst_enc_str_1,  0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { INVALID_SW_COUNTER,               "",           0xffffffff, 0x00000000, 0x00000000,                   PM_UNIT_MAX,0 }
};

PerfSignalHwpm PerfSignalTableGK104_gpc0[] = {
    //l1 TLB is 1 per GPC
    { KEPLER_GPCL1_TLB_HIT, gpcl1_tlb_hit_enc_str_1, 0x9, 0xaaaa, 0x60, PM_UNIT_GPCMMU, 1, 0},
    { KEPLER_TPC0_UTLB0_HIT, tpc0_utlb0_hit_enc_str_1, 0x3, 0xaaaa, 0x60, PM_UNIT_GPCMMU, 1, 0},
    { KEPLER_TPC1_UTLB0_HIT, tpc1_utlb0_hit_enc_str_1, 0x4, 0xaaaa, 0x60, PM_UNIT_GPCMMU, 1, 0},
    { KEPLER_TPC0_UTLB1_HIT, tpc0_utlb1_hit_enc_str_1, 0x5, 0xaaaa, 0x60, PM_UNIT_GPCMMU, 1, 0},
    { KEPLER_TPC1_UTLB1_HIT, tpc1_utlb1_hit_enc_str_1, 0x6, 0xaaaa, 0x60, PM_UNIT_GPCMMU, 1, 0},
    { KEPLER_RGG_UTLB_HIT, rgg_utlb_hit_enc_str_1, 0x7, 0xaaaa, 0x60, PM_UNIT_GPCMMU, 1, 0},

    { KEPLER_GPCL1_TLB_MISS_INT, gpcl1_tlb_miss_int_enc_str_1, 0x9, 0xaaaa, 0x61, PM_UNIT_GPCMMU, 1, 0},
    { KEPLER_TPC0_UTLB0_MISS_INT, tpc0_utlb0_miss_int_enc_str_1, 0x3, 0xaaaa, 0x61, PM_UNIT_GPCMMU, 1, 0},
    { KEPLER_TPC1_UTLB0_MISS_INT, tpc1_utlb0_miss_int_enc_str_1, 0x4, 0xaaaa, 0x61, PM_UNIT_GPCMMU, 1, 0},
    { KEPLER_TPC0_UTLB1_MISS_INT, tpc0_utlb1_miss_int_enc_str_1, 0x5, 0xaaaa, 0x61, PM_UNIT_GPCMMU, 1, 0},
    { KEPLER_TPC1_UTLB1_MISS_INT, tpc1_utlb1_miss_int_enc_str_1, 0x6, 0xaaaa, 0x61, PM_UNIT_GPCMMU, 1, 0},
    { KEPLER_RGG_UTLB_MISS_INT, rgg_utlb_miss_int_enc_str_1, 0x7, 0xaaaa, 0x61, PM_UNIT_GPCMMU, 1, 0},

    //GK10x can have only 2 tpcs/gpc
    { KEPLER_HWPM_MPC_COMPUTE_CTAS_IN_FLIGHT, kepler_hwpm_mpc_compute_ctas_in_flight_enc_str_1, 0x37, 0xffff, 0xb, PM_UNIT_MPC,5, 0},
    { KEPLER_HWPM_MPC_COMPUTE_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_compute_ctas_in_flight1_enc_str_1, 0x37, 0xffff, 0xb, PM_UNIT_MPC,5, 1},
    { KEPLER_HWPM_MPC_PIX_WARPS_IN_FLIGHT,  kepler_hwpm_mpc_pix_warps_in_flight_enc_str_1,   0x33, 0xffff, 0xb, PM_UNIT_MPC, 7, 0},
    { KEPLER_HWPM_MPC_PIX_WARPS_IN_FLIGHT1,  kepler_hwpm_mpc_pix_warps_in_flight1_enc_str_1,   0x33, 0xffff, 0xb, PM_UNIT_MPC, 7, 1},
    { KEPLER_HWPM_MPC_CNT_1_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_1_ctas_in_flight_enc_str_1, 0x1e, 0xaaaa, 0xb, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_2_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_2_ctas_in_flight_enc_str_1, 0x1e, 0xaaaa, 0xc, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_3_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_3_ctas_in_flight_enc_str_1, 0x1e, 0xaaaa, 0xd, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_4_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_4_ctas_in_flight_enc_str_1, 0x1e, 0xaaaa, 0xe, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_5_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_5_ctas_in_flight_enc_str_1, 0x1e, 0xaaaa, 0xf, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_6_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_6_ctas_in_flight_enc_str_1, 0x1e, 0xaaaa, 0x10, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_7_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_7_ctas_in_flight_enc_str_1, 0x1e, 0xaaaa, 0x11, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_8_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_8_ctas_in_flight_enc_str_1, 0x1e, 0xaaaa, 0x12, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_9_CTAS_IN_FLIGHT,  kepler_hwpm_mpc_cnt_9_ctas_in_flight_enc_str_1, 0x3e, 0xaaaa, 0xb, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_10_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_10_ctas_in_flight_enc_str_1, 0x3e, 0xaaaa, 0xc, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_11_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_11_ctas_in_flight_enc_str_1, 0x3e, 0xaaaa, 0xd, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_12_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_12_ctas_in_flight_enc_str_1, 0x3e, 0xaaaa, 0xe, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_13_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_13_ctas_in_flight_enc_str_1, 0x3e, 0xaaaa, 0xf, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_14_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_14_ctas_in_flight_enc_str_1, 0x3e, 0xaaaa, 0x10, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_15_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_15_ctas_in_flight_enc_str_1, 0x3e, 0xaaaa, 0x11, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_16_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_16_ctas_in_flight_enc_str_1, 0x3e, 0xaaaa, 0x12, PM_UNIT_MPC,1, 0},

    { KEPLER_HWPM_MPC_CNT_1_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_1_ctas_in_flight1_enc_str_1, 0x1e, 0xaaaa, 0xb, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_2_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_2_ctas_in_flight1_enc_str_1, 0x1e, 0xaaaa, 0xc, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_3_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_3_ctas_in_flight1_enc_str_1, 0x1e, 0xaaaa, 0xd, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_4_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_4_ctas_in_flight1_enc_str_1, 0x1e, 0xaaaa, 0xe, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_5_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_5_ctas_in_flight1_enc_str_1, 0x1e, 0xaaaa, 0xf, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_6_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_6_ctas_in_flight1_enc_str_1, 0x1e, 0xaaaa, 0x10, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_7_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_7_ctas_in_flight1_enc_str_1, 0x1e, 0xaaaa, 0x11, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_8_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_8_ctas_in_flight1_enc_str_1, 0x1e, 0xaaaa, 0x12, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_9_CTAS_IN_FLIGHT1,  kepler_hwpm_mpc_cnt_9_ctas_in_flight1_enc_str_1, 0x3e, 0xaaaa, 0xb, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_10_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_10_ctas_in_flight1_enc_str_1, 0x3e, 0xaaaa, 0xc, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_11_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_11_ctas_in_flight1_enc_str_1, 0x3e, 0xaaaa, 0xd, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_12_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_12_ctas_in_flight1_enc_str_1, 0x3e, 0xaaaa, 0xe, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_13_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_13_ctas_in_flight1_enc_str_1, 0x3e, 0xaaaa, 0xf, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_14_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_14_ctas_in_flight1_enc_str_1, 0x3e, 0xaaaa, 0x10, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_15_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_15_ctas_in_flight1_enc_str_1, 0x3e, 0xaaaa, 0x11, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_16_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_16_ctas_in_flight1_enc_str_1, 0x3e, 0xaaaa, 0x12, PM_UNIT_MPC,1, 1},

    { INVALID_PM_SIGNAL_NEW,            "",                         0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpmExpt PerfSignalTableGK104_gpc0_expt[] = {
    { KEPLER_TPC0_UTLB0_MISS, tpc0_utlb0_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_TPC0_UTLB0_HIT, KEPLER_TPC0_UTLB0_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_TPC1_UTLB0_MISS, tpc1_utlb0_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_TPC1_UTLB0_HIT, KEPLER_TPC1_UTLB0_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_TPC0_UTLB1_MISS, tpc0_utlb1_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_TPC0_UTLB1_HIT, KEPLER_TPC0_UTLB1_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_TPC1_UTLB1_MISS, tpc1_utlb1_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_TPC1_UTLB1_HIT, KEPLER_TPC1_UTLB1_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_GPCL1_TLB_MISS, gpcl1_tlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_GPCL1_TLB_HIT, KEPLER_GPCL1_TLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_RGG_UTLB_MISS, rgg_utlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_RGG_UTLB_HIT, KEPLER_RGG_UTLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},

    { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000,  0x00},
};

PerfSignalSmpcExpt PerfSignalTableGK104_LutModeCounters[] = {
    { KEPLER_LUT_COUNTER_SUB_GLD32BIT_INST,  kepler_lut_counter_sub_gld32bit_inst_enc_str_1,   PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SUB_SIZE_32,KEPLER_SM_GENERIC_LOAD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},  (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { KEPLER_LUT_COUNTER_SUB_GST32BIT_INST,  kepler_lut_counter_sub_gst32bit_inst_enc_str_1,   PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SUB_SIZE_32,KEPLER_SM_GENERIC_STORE,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { KEPLER_LUT_COUNTER_GLD32BIT_INST,      kepler_lut_counter_gld32bit_inst_enc_str_1,  PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SIZE_32,KEPLER_SM_GENERIC_LOAD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { KEPLER_LUT_COUNTER_GST32BIT_INST,      kepler_lut_counter_gst32bit_inst_enc_str_1,  PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SIZE_32,KEPLER_SM_GENERIC_STORE,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { KEPLER_LUT_COUNTER_GLD64BIT_INST,      kepler_lut_counter_gld64bit_inst_enc_str_1,  PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SIZE_64,KEPLER_SM_GENERIC_LOAD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { KEPLER_LUT_COUNTER_GST64BIT_INST,      kepler_lut_counter_gst64bit_inst_enc_str_1,  PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SIZE_64,KEPLER_SM_GENERIC_STORE,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { KEPLER_LUT_COUNTER_GLD128BIT_INST,     kepler_lut_counter_gld128bit_inst_enc_str_1, PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SIZE_128,KEPLER_SM_GENERIC_LOAD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { KEPLER_LUT_COUNTER_GST128BIT_INST,     kepler_lut_counter_gst128bit_inst_enc_str_1, PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SIZE_128,KEPLER_SM_GENERIC_STORE,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},    (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},

    { INVALID_PM_SIGNAL_NEW,               "", PM_UNIT_MAX, {INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW} , TRUTH_TABLE_FUNCTION_ALL_FALSE}
};

//
// GK110 signal tables
//
PerfSignalHwpm PerfSignalTableGK110_gpc0[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type
/*
    FIXME: MPC counters are not giving correct results, all counters are showing zero
           Disabling the counters from this unit
    // ########### MPC Unit ###########
    // mpc_total_CTAs_launched          Total number of CTAs launched by this MPC
    { KEPLER_HWPM_CTA_LAUNCHED,          kepler_hwpm_cta_launched_enc_str_2,             0x0000000e, 0x00000007, 0x0000AAAA,  0x13,    PM_UNIT_MPC,1 },
    // mpc_total_threads_launched   gpc%0     gr      mpc      6       Total number of threads launched by this MPC
    { KEPLER_SM_THREADS_LAUNCHED,              kepler_sm_threads_launched_enc_str_1,         0x0000000f, 0x00543210, 0x0000FFFF,  0x0c,    PM_UNIT_MPC,6 },
*/
    { KEPLER_GPCL1_TLB_HIT, gpcl1_tlb_hit_enc_str_1, 0x9, 0xaaaa, 0x6c, PM_UNIT_GPCMMU, 1, 0},
    { KEPLER_TPC0_UTLB0_HIT, tpc0_utlb0_hit_enc_str_1, 0x3, 0xaaaa, 0x6c, PM_UNIT_GPCMMU, 1, 0},
    { KEPLER_TPC1_UTLB0_HIT, tpc1_utlb0_hit_enc_str_1, 0x4, 0xaaaa, 0x6c, PM_UNIT_GPCMMU, 1, 0},
    { KEPLER_TPC2_UTLB0_HIT, tpc2_utlb0_hit_enc_str_1, 0x5, 0xaaaa, 0x6c, PM_UNIT_GPCMMU, 1, 0},
    { KEPLER_TPC0_UTLB1_HIT, tpc0_utlb1_hit_enc_str_1, 0x6, 0xaaaa, 0x6c, PM_UNIT_GPCMMU, 1, 0},
    { KEPLER_TPC1_UTLB1_HIT, tpc1_utlb1_hit_enc_str_1, 0x40, 0xaaaa, 0x6c, PM_UNIT_GPCMMU, 1, 0},
    { KEPLER_TPC2_UTLB1_HIT, tpc2_utlb1_hit_enc_str_1, 0x50, 0xaaaa, 0x6c, PM_UNIT_GPCMMU, 1, 0},
    { KEPLER_RGG_UTLB_HIT, rgg_utlb_hit_enc_str_1, 0x7, 0xaaaa, 0x6c, PM_UNIT_GPCMMU, 1, 0},

    { KEPLER_GPCL1_TLB_MISS_INT, gpcl1_tlb_miss_int_enc_str_1, 0x9, 0xaaaa, 0x6d, PM_UNIT_GPCMMU, 1, 1},
    { KEPLER_TPC0_UTLB0_MISS_INT, tpc0_utlb0_miss_int_enc_str_1, 0x3, 0xaaaa, 0x6d, PM_UNIT_GPCMMU, 1, 0},
    { KEPLER_TPC1_UTLB0_MISS_INT, tpc1_utlb0_miss_int_enc_str_1, 0x4, 0xaaaa, 0x6d, PM_UNIT_GPCMMU, 1, 0},
    { KEPLER_TPC2_UTLB0_MISS_INT, tpc2_utlb0_miss_int_enc_str_1, 0x5, 0xaaaa, 0x6d, PM_UNIT_GPCMMU, 1, 0},
    { KEPLER_TPC0_UTLB1_MISS_INT, tpc0_utlb1_miss_int_enc_str_1, 0x6, 0xaaaa, 0x6d, PM_UNIT_GPCMMU, 1, 0},
    { KEPLER_TPC1_UTLB1_MISS_INT, tpc1_utlb1_miss_int_enc_str_1, 0x40, 0xaaaa, 0x6d, PM_UNIT_GPCMMU, 1, 0},
    { KEPLER_TPC2_UTLB1_MISS_INT, tpc2_utlb1_miss_int_enc_str_1, 0x50, 0xaaaa, 0x6d, PM_UNIT_GPCMMU, 1, 0},
    { KEPLER_RGG_UTLB_MISS_INT, rgg_utlb_miss_int_enc_str_1, 0x7, 0xaaaa, 0x6d, PM_UNIT_GPCMMU, 1, 0},

//mpc singals.
    // defined in \\hw\tools\perfalyze\chips\gk110\pml_files\mpc.pml
    { KEPLER_HWPM_MPC_COMPUTE_CTAS_IN_FLIGHT,kepler_hwpm_mpc_compute_ctas_in_flight_enc_str_1, 0x37, 0xffff, 0xc, PM_UNIT_MPC,5, 0},
    { KEPLER_HWPM_MPC_COMPUTE_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_compute_ctas_in_flight1_enc_str_1, 0x37, 0xffff, 0xc, PM_UNIT_MPC,5, 1},
    { KEPLER_HWPM_MPC_COMPUTE_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_compute_ctas_in_flight2_enc_str_1, 0x37, 0xffff, 0xc, PM_UNIT_MPC,5, 2},
    { KEPLER_HWPM_MPC_PIX_WARPS_IN_FLIGHT,kepler_hwpm_mpc_pix_warps_in_flight_enc_str_1, 0x33, 0xffff, 0xc, PM_UNIT_MPC,7, 0},
    { KEPLER_HWPM_MPC_PIX_WARPS_IN_FLIGHT1,kepler_hwpm_mpc_pix_warps_in_flight1_enc_str_1, 0x33, 0xffff, 0xc, PM_UNIT_MPC,7, 1},
    { KEPLER_HWPM_MPC_PIX_WARPS_IN_FLIGHT2,kepler_hwpm_mpc_pix_warps_in_flight2_enc_str_1, 0x33, 0xffff, 0xc, PM_UNIT_MPC,7, 2},

    { KEPLER_HWPM_MPC_CNT_1_CTAS_IN_FLIGHT,kepler_hwpm_mpc_cnt_1_ctas_in_flight_enc_str_1, 0x1e, 0xaaaa, 0xc, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_2_CTAS_IN_FLIGHT,kepler_hwpm_mpc_cnt_2_ctas_in_flight_enc_str_1, 0x1e, 0xaaaa, 0xd, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_3_CTAS_IN_FLIGHT,kepler_hwpm_mpc_cnt_3_ctas_in_flight_enc_str_1, 0x1e, 0xaaaa, 0xe, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_4_CTAS_IN_FLIGHT,kepler_hwpm_mpc_cnt_4_ctas_in_flight_enc_str_1, 0x1e, 0xaaaa, 0xf, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_5_CTAS_IN_FLIGHT,kepler_hwpm_mpc_cnt_5_ctas_in_flight_enc_str_1, 0x1e, 0xaaaa, 0x10, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_6_CTAS_IN_FLIGHT,kepler_hwpm_mpc_cnt_6_ctas_in_flight_enc_str_1, 0x1e, 0xaaaa, 0x11, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_7_CTAS_IN_FLIGHT,kepler_hwpm_mpc_cnt_7_ctas_in_flight_enc_str_1, 0x1e, 0xaaaa, 0x12, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_8_CTAS_IN_FLIGHT,kepler_hwpm_mpc_cnt_8_ctas_in_flight_enc_str_1, 0x1e, 0xaaaa, 0x13, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_9_CTAS_IN_FLIGHT,kepler_hwpm_mpc_cnt_9_ctas_in_flight_enc_str_1, 0x3e, 0xaaaa, 0xc, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_10_CTAS_IN_FLIGHT,kepler_hwpm_mpc_cnt_10_ctas_in_flight_enc_str_1, 0x3e, 0xaaaa, 0xd, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_11_CTAS_IN_FLIGHT,kepler_hwpm_mpc_cnt_11_ctas_in_flight_enc_str_1, 0x3e, 0xaaaa, 0xe, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_12_CTAS_IN_FLIGHT,kepler_hwpm_mpc_cnt_12_ctas_in_flight_enc_str_1, 0x3e, 0xaaaa, 0xf, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_13_CTAS_IN_FLIGHT,kepler_hwpm_mpc_cnt_13_ctas_in_flight_enc_str_1, 0x3e, 0xaaaa, 0x10, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_14_CTAS_IN_FLIGHT,kepler_hwpm_mpc_cnt_14_ctas_in_flight_enc_str_1, 0x3e, 0xaaaa, 0x11, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_15_CTAS_IN_FLIGHT,kepler_hwpm_mpc_cnt_15_ctas_in_flight_enc_str_1, 0x3e, 0xaaaa, 0x12, PM_UNIT_MPC,1, 0},
    { KEPLER_HWPM_MPC_CNT_16_CTAS_IN_FLIGHT,kepler_hwpm_mpc_cnt_16_ctas_in_flight_enc_str_1, 0x3e, 0xaaaa, 0x13, PM_UNIT_MPC,1, 0},

    { KEPLER_HWPM_MPC_CNT_1_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_cnt_1_ctas_in_flight1_enc_str_1, 0x1e, 0xaaaa, 0xc, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_2_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_cnt_2_ctas_in_flight1_enc_str_1, 0x1e, 0xaaaa, 0xd, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_3_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_cnt_3_ctas_in_flight1_enc_str_1, 0x1e, 0xaaaa, 0xe, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_4_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_cnt_4_ctas_in_flight1_enc_str_1, 0x1e, 0xaaaa, 0xf, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_5_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_cnt_5_ctas_in_flight1_enc_str_1, 0x1e, 0xaaaa, 0x10, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_6_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_cnt_6_ctas_in_flight1_enc_str_1, 0x1e, 0xaaaa, 0x11, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_7_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_cnt_7_ctas_in_flight1_enc_str_1, 0x1e, 0xaaaa, 0x12, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_8_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_cnt_8_ctas_in_flight1_enc_str_1, 0x1e, 0xaaaa, 0x13, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_9_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_cnt_9_ctas_in_flight1_enc_str_1, 0x3e, 0xaaaa, 0xc, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_10_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_cnt_10_ctas_in_flight1_enc_str_1, 0x3e, 0xaaaa, 0xd, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_11_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_cnt_11_ctas_in_flight1_enc_str_1, 0x3e, 0xaaaa, 0xe, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_12_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_cnt_12_ctas_in_flight1_enc_str_1, 0x3e, 0xaaaa, 0xf, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_13_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_cnt_13_ctas_in_flight1_enc_str_1, 0x3e, 0xaaaa, 0x10, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_14_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_cnt_14_ctas_in_flight1_enc_str_1, 0x3e, 0xaaaa, 0x11, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_15_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_cnt_15_ctas_in_flight1_enc_str_1, 0x3e, 0xaaaa, 0x12, PM_UNIT_MPC,1, 1},
    { KEPLER_HWPM_MPC_CNT_16_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_cnt_16_ctas_in_flight1_enc_str_1, 0x3e, 0xaaaa, 0x13, PM_UNIT_MPC,1, 1},

    { KEPLER_HWPM_MPC_CNT_1_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_cnt_1_ctas_in_flight2_enc_str_1, 0x1e, 0xaaaa, 0xc, PM_UNIT_MPC,1, 2},
    { KEPLER_HWPM_MPC_CNT_2_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_cnt_2_ctas_in_flight2_enc_str_1, 0x1e, 0xaaaa, 0xd, PM_UNIT_MPC,1, 2},
    { KEPLER_HWPM_MPC_CNT_3_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_cnt_3_ctas_in_flight2_enc_str_1, 0x1e, 0xaaaa, 0xe, PM_UNIT_MPC,1, 2},
    { KEPLER_HWPM_MPC_CNT_4_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_cnt_4_ctas_in_flight2_enc_str_1, 0x1e, 0xaaaa, 0xf, PM_UNIT_MPC,1, 2},
    { KEPLER_HWPM_MPC_CNT_5_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_cnt_5_ctas_in_flight2_enc_str_1, 0x1e, 0xaaaa, 0x10, PM_UNIT_MPC,1, 2},
    { KEPLER_HWPM_MPC_CNT_6_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_cnt_6_ctas_in_flight2_enc_str_1, 0x1e, 0xaaaa, 0x11, PM_UNIT_MPC,1, 2},
    { KEPLER_HWPM_MPC_CNT_7_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_cnt_7_ctas_in_flight2_enc_str_1, 0x1e, 0xaaaa, 0x12, PM_UNIT_MPC,1, 2},
    { KEPLER_HWPM_MPC_CNT_8_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_cnt_8_ctas_in_flight2_enc_str_1, 0x1e, 0xaaaa, 0x13, PM_UNIT_MPC,1, 2},
    { KEPLER_HWPM_MPC_CNT_9_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_cnt_9_ctas_in_flight2_enc_str_1, 0x3e, 0xaaaa, 0xc, PM_UNIT_MPC,1, 2},
    { KEPLER_HWPM_MPC_CNT_10_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_cnt_10_ctas_in_flight2_enc_str_1, 0x3e, 0xaaaa, 0xd, PM_UNIT_MPC,1, 2},
    { KEPLER_HWPM_MPC_CNT_11_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_cnt_11_ctas_in_flight2_enc_str_1, 0x3e, 0xaaaa, 0xe, PM_UNIT_MPC,1, 2},
    { KEPLER_HWPM_MPC_CNT_12_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_cnt_12_ctas_in_flight2_enc_str_1, 0x3e, 0xaaaa, 0xf, PM_UNIT_MPC,1, 2},
    { KEPLER_HWPM_MPC_CNT_13_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_cnt_13_ctas_in_flight2_enc_str_1, 0x3e, 0xaaaa, 0x10, PM_UNIT_MPC,1, 2},
    { KEPLER_HWPM_MPC_CNT_14_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_cnt_14_ctas_in_flight2_enc_str_1, 0x3e, 0xaaaa, 0x11, PM_UNIT_MPC,1, 2},
    { KEPLER_HWPM_MPC_CNT_15_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_cnt_15_ctas_in_flight2_enc_str_1, 0x3e, 0xaaaa, 0x12, PM_UNIT_MPC,1, 2},
    { KEPLER_HWPM_MPC_CNT_16_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_cnt_16_ctas_in_flight2_enc_str_1, 0x3e, 0xaaaa, 0x13, PM_UNIT_MPC,1, 2},

    { KEPLER_HWPM_MPC_CNT_1_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_1_pixel_warps_in_flight_enc_str_1, 0x4b, 0xaaaa, 0xc, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_2_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_2_pixel_warps_in_flight_enc_str_1, 0x4b, 0xaaaa, 0xd, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_3_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_3_pixel_warps_in_flight_enc_str_1, 0x4b, 0xaaaa, 0xe, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_4_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_4_pixel_warps_in_flight_enc_str_1, 0x4b, 0xaaaa, 0xf, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_5_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_5_pixel_warps_in_flight_enc_str_1, 0x4b, 0xaaaa, 0x10, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_6_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_6_pixel_warps_in_flight_enc_str_1, 0x4b, 0xaaaa, 0x11, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_7_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_7_pixel_warps_in_flight_enc_str_1, 0x4b, 0xaaaa, 0x12, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_8_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_8_pixel_warps_in_flight_enc_str_1, 0x4b, 0xaaaa, 0x13, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_9_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_9_pixel_warps_in_flight_enc_str_1, 0x4c, 0xaaaa, 0xc, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_10_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_10_pixel_warps_in_flight_enc_str_1, 0x4c, 0xaaaa, 0xd, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_11_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_11_pixel_warps_in_flight_enc_str_1, 0x4c, 0xaaaa, 0xe, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_12_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_12_pixel_warps_in_flight_enc_str_1, 0x4c, 0xaaaa, 0xf, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_13_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_13_pixel_warps_in_flight_enc_str_1, 0x4c, 0xaaaa, 0x10, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_14_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_14_pixel_warps_in_flight_enc_str_1, 0x4c, 0xaaaa, 0x11, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_15_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_15_pixel_warps_in_flight_enc_str_1, 0x4c, 0xaaaa, 0x12, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_16_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_16_pixel_warps_in_flight_enc_str_1, 0x4c, 0xaaaa, 0x13, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_17_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_17_pixel_warps_in_flight_enc_str_1, 0x4d, 0xaaaa, 0xc, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_18_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_18_pixel_warps_in_flight_enc_str_1, 0x4d, 0xaaaa, 0xd, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_19_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_19_pixel_warps_in_flight_enc_str_1, 0x4d, 0xaaaa, 0xe, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_20_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_20_pixel_warps_in_flight_enc_str_1, 0x4d, 0xaaaa, 0xf, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_21_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_21_pixel_warps_in_flight_enc_str_1, 0x4d, 0xaaaa, 0x10, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_22_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_22_pixel_warps_in_flight_enc_str_1, 0x4d, 0xaaaa, 0x11, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_23_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_23_pixel_warps_in_flight_enc_str_1, 0x4d, 0xaaaa, 0x12, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_24_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_24_pixel_warps_in_flight_enc_str_1, 0x4d, 0xaaaa, 0x13, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_25_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_25_pixel_warps_in_flight_enc_str_1, 0x4e, 0xaaaa, 0xc, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_26_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_26_pixel_warps_in_flight_enc_str_1, 0x4e, 0xaaaa, 0xd, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_27_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_27_pixel_warps_in_flight_enc_str_1, 0x4e, 0xaaaa, 0xe, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_28_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_28_pixel_warps_in_flight_enc_str_1, 0x4e, 0xaaaa, 0xf, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_29_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_29_pixel_warps_in_flight_enc_str_1, 0x4e, 0xaaaa, 0x10, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_30_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_30_pixel_warps_in_flight_enc_str_1, 0x4e, 0xaaaa, 0x11, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_31_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_31_pixel_warps_in_flight_enc_str_1, 0x4e, 0xaaaa, 0x12, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_32_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_32_pixel_warps_in_flight_enc_str_1, 0x4e, 0xaaaa, 0x13, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_33_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_33_pixel_warps_in_flight_enc_str_1, 0x4f, 0xaaaa, 0xc, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_34_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_34_pixel_warps_in_flight_enc_str_1, 0x4f, 0xaaaa, 0xd, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_35_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_35_pixel_warps_in_flight_enc_str_1, 0x4f, 0xaaaa, 0xe, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_36_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_36_pixel_warps_in_flight_enc_str_1, 0x4f, 0xaaaa, 0xf, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_37_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_37_pixel_warps_in_flight_enc_str_1, 0x4f, 0xaaaa, 0x10, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_38_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_38_pixel_warps_in_flight_enc_str_1, 0x4f, 0xaaaa, 0x11, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_39_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_39_pixel_warps_in_flight_enc_str_1, 0x4f, 0xaaaa, 0x12, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_40_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_40_pixel_warps_in_flight_enc_str_1, 0x4f, 0xaaaa, 0x13, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_41_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_41_pixel_warps_in_flight_enc_str_1, 0x50, 0xaaaa, 0xc, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_42_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_42_pixel_warps_in_flight_enc_str_1, 0x50, 0xaaaa, 0xd, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_43_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_43_pixel_warps_in_flight_enc_str_1, 0x50, 0xaaaa, 0xe, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_44_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_44_pixel_warps_in_flight_enc_str_1, 0x50, 0xaaaa, 0xf, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_45_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_45_pixel_warps_in_flight_enc_str_1, 0x50, 0xaaaa, 0x10, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_46_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_46_pixel_warps_in_flight_enc_str_1, 0x50, 0xaaaa, 0x11, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_47_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_47_pixel_warps_in_flight_enc_str_1, 0x50, 0xaaaa, 0x12, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_48_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_48_pixel_warps_in_flight_enc_str_1, 0x50, 0xaaaa, 0x13, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_49_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_49_pixel_warps_in_flight_enc_str_1, 0x51, 0xaaaa, 0xc, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_50_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_50_pixel_warps_in_flight_enc_str_1, 0x51, 0xaaaa, 0xd, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_51_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_51_pixel_warps_in_flight_enc_str_1, 0x51, 0xaaaa, 0xe, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_52_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_52_pixel_warps_in_flight_enc_str_1, 0x51, 0xaaaa, 0xf, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_53_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_53_pixel_warps_in_flight_enc_str_1, 0x51, 0xaaaa, 0x10, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_54_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_54_pixel_warps_in_flight_enc_str_1, 0x51, 0xaaaa, 0x11, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_55_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_55_pixel_warps_in_flight_enc_str_1, 0x51, 0xaaaa, 0x12, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_56_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_56_pixel_warps_in_flight_enc_str_1, 0x51, 0xaaaa, 0x13, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_57_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_57_pixel_warps_in_flight_enc_str_1, 0x52, 0xaaaa, 0xc, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_58_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_58_pixel_warps_in_flight_enc_str_1, 0x52, 0xaaaa, 0xd, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_59_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_59_pixel_warps_in_flight_enc_str_1, 0x52, 0xaaaa, 0xe, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_60_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_60_pixel_warps_in_flight_enc_str_1, 0x52, 0xaaaa, 0xf, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_61_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_61_pixel_warps_in_flight_enc_str_1, 0x52, 0xaaaa, 0x10, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_62_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_62_pixel_warps_in_flight_enc_str_1, 0x52, 0xaaaa, 0x11, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_63_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_63_pixel_warps_in_flight_enc_str_1, 0x52, 0xaaaa, 0x12, PM_UNIT_MPC,1},
    { KEPLER_HWPM_MPC_CNT_64_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_64_pixel_warps_in_flight_enc_str_1, 0x52, 0xaaaa, 0x13, PM_UNIT_MPC,1},

    { INVALID_PM_SIGNAL_NEW,            "",                         0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }

};

PerfSignalHwpmExpt PerfSignalTableGK110_gpc0_expt[] = {
    { KEPLER_TPC0_UTLB0_MISS, tpc0_utlb0_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_TPC0_UTLB0_HIT, KEPLER_TPC0_UTLB0_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_TPC1_UTLB0_MISS, tpc1_utlb0_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_TPC1_UTLB0_HIT, KEPLER_TPC1_UTLB0_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_TPC2_UTLB0_MISS, tpc2_utlb0_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_TPC2_UTLB0_HIT, KEPLER_TPC2_UTLB0_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_TPC0_UTLB1_MISS, tpc0_utlb1_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_TPC0_UTLB1_HIT, KEPLER_TPC0_UTLB1_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_TPC1_UTLB1_MISS, tpc1_utlb1_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_TPC1_UTLB1_HIT, KEPLER_TPC1_UTLB1_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_TPC2_UTLB1_MISS, tpc2_utlb1_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_TPC2_UTLB1_HIT, KEPLER_TPC2_UTLB1_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_GPCL1_TLB_MISS, gpcl1_tlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_GPCL1_TLB_HIT, KEPLER_GPCL1_TLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_RGG_UTLB_MISS, rgg_utlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_RGG_UTLB_HIT, KEPLER_RGG_UTLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000,  0x00},
};

PerfSignalHwpmExpt PerfSignalTableGK110_gpctpc_expt[] = {
    { KEPLER_TEX0_RETURN_PACKET_COUNT,    kepler_tex0_return_packet_count_enc_str_1,   INVALID_PM_SIGNAL_NEW, {KEPLER_TEX0_TEX2SM_TEX_PRDY, KEPLER_TEX0_TEX2SM_TEX_PVLD, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_TEX1_RETURN_PACKET_COUNT,    kepler_tex1_return_packet_count_enc_str_1,   INVALID_PM_SIGNAL_NEW, {KEPLER_TEX1_TEX2SM_TEX_PRDY, KEPLER_TEX1_TEX2SM_TEX_PVLD, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_TEX2_RETURN_PACKET_COUNT,    kepler_tex2_return_packet_count_enc_str_1,   INVALID_PM_SIGNAL_NEW, {KEPLER_TEX2_TEX2SM_TEX_PRDY, KEPLER_TEX2_TEX2SM_TEX_PVLD, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_TEX3_RETURN_PACKET_COUNT,    kepler_tex3_return_packet_count_enc_str_1,   INVALID_PM_SIGNAL_NEW, {KEPLER_TEX3_TEX2SM_TEX_PRDY, KEPLER_TEX3_TEX2SM_TEX_PVLD, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},

    { KEPLER_TEX0_LG_SECTOR_QUERIES, kepler_tex0_lg_sector_queries_enc_str_1, KEPLER_TEX0_CACHE_SECTOR_QUERIES, {KEPLER_TEX0_GPC_T_LDG_CT_GRP5, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { KEPLER_TEX1_LG_SECTOR_QUERIES, kepler_tex1_lg_sector_queries_enc_str_1, KEPLER_TEX1_CACHE_SECTOR_QUERIES, {KEPLER_TEX1_GPC_T_LDG_CT_GRP5, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { KEPLER_TEX2_LG_SECTOR_QUERIES, kepler_tex2_lg_sector_queries_enc_str_1, KEPLER_TEX2_CACHE_SECTOR_QUERIES, {KEPLER_TEX2_GPC_T_LDG_CT_GRP5, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { KEPLER_TEX3_LG_SECTOR_QUERIES, kepler_tex3_lg_sector_queries_enc_str_1, KEPLER_TEX3_CACHE_SECTOR_QUERIES, {KEPLER_TEX3_GPC_T_LDG_CT_GRP5, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},

    { KEPLER_TEX0_LG_MISSED_SECTORS, kepler_tex0_lg_missed_sectors_enc_str_1, KEPLER_TEX0_CACHE_SECTOR_MISSES, {KEPLER_TEX0_GPC_T_LDG_CT_GRP4, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { KEPLER_TEX1_LG_MISSED_SECTORS, kepler_tex1_lg_missed_sectors_enc_str_1, KEPLER_TEX1_CACHE_SECTOR_MISSES, {KEPLER_TEX1_GPC_T_LDG_CT_GRP4, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { KEPLER_TEX2_LG_MISSED_SECTORS, kepler_tex2_lg_missed_sectors_enc_str_1, KEPLER_TEX2_CACHE_SECTOR_MISSES, {KEPLER_TEX2_GPC_T_LDG_CT_GRP4, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { KEPLER_TEX3_LG_MISSED_SECTORS, kepler_tex3_lg_missed_sectors_enc_str_1, KEPLER_TEX3_CACHE_SECTOR_MISSES, {KEPLER_TEX3_GPC_T_LDG_CT_GRP4, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},


    { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000,  0x00},
};

PerfSignalHwpm PerfSignalTableGK110_gpctpc[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type
    { KEPLER_HWPM_THREADS_LAUNCHED,              kepler_hwpm_threads_launched_enc_str_1,         0x00000002, 0x0000FFFF,  0x31,    PM_UNIT_SMQCTL,6 },
    { KEPLER_HWPM_CTA_LAUNCHED,                  kepler_hwpm_cta_launched_enc_str_1,             0x00000007, 0x0000AAAA,   0x22,   PM_UNIT_SMCORE,1 },
#if CU_PROFILE_SM_SIGNALS_VIA_HWPM
    // **** SM QUAD Signals ****

    //["LAUNCHED" =>
    //    ["warps_launched",          1,      "on",   "If a warp was launched this cycle in this quad",       undef],
    //    ["threads_launched",        6,      "on",   "Number of threads launched this cycle in this quad",   undef],
    //],
    { KEPLER_HWPM_WARPS_LAUNCHED,                kepler_hwpm_warps_launched_enc_str_1,           0x00000002, 0x0000AAAA,  0x30,    PM_UNIT_SMQCTL,1 },

    //["INST_ISSUE_EXECUTED_IPC" =>
    //    ["active_cycles",           1,      "on",   "At least 1 active warp in the quad",      undef],
    //    ["inst_issued0",            1,      "on",   "# of cycles issued 0 instructions",       undef],
    //    ["inst_issued1",            1,      "on",   "# of cycles issued 1 instructions",       undef],
    //    ["inst_issued2",            1,      "on",   "# of cycles issued 2 instructions",       undef],
    //    ["active_cycles_2",         1,      "on",   "At least 1 active warp in the quad",      undef],
    //    ["inst_executed",           2,      "on",   "# of instructions executed",              undef],
    //]
    { KEPLER_HWPM_INST_ISSUED_1,                 kepler_hwpm_inst_issued_1_enc_str_1,            0x00000004, 0x0000AAAA,  0x32,    PM_UNIT_SMQCTL,1 },
    { KEPLER_HWPM_INST_ISSUED_2,                 kepler_hwpm_inst_issued_2_enc_str_1,            0x00000004, 0x0000AAAA,  0x33,    PM_UNIT_SMQCTL,1 },
    { KEPLER_HWPM_INST_EXECUTED,                 kepler_hwpm_inst_executed_enc_str_1,            0x00000004, 0x0000FFFF,  0x35,    PM_UNIT_SMQCTL,2 },

    //["THREAD_INST_EXECUTED" =>
    //    ["thread_inst_executed",    6,      "on",   "Number of thread instruction executed this cycle in this quad",   undef],
    //],
    { KEPLER_HWPM_THREAD_INST_EXECUTED,          kepler_hwpm_thread_inst_executed_enc_str_1,     0x0000001d, 0x0000FFFF,  0x30,    PM_UNIT_SMQCTL,6 },

    //["LSU_INST_COUNT_1" =>
    //    ["inst_executed_lsu_lds", 1, "off", "shared load ", undef],
    //    ["inst_executed_lsu_sts", 1, "off", "shared store ", undef],
    //    ["inst_executed_lsu_ld", 1, "off", "generic load", undef],
    //]
    //["LSU_INST_COUNT_2" =>
    //    ["inst_executed_lsu_st", 1, "off", "generic store", undef],
    //    ["inst_executed_lsu_ldl", 1, "off", "local load", undef],
    //    ["inst_executed_lsu_stl", 1, "off", "local store", undef],
    //]
    { KEPLER_HWPM_SHARED_LOAD,                   kepler_hwpm_shared_load_enc_str_1,              0x0000003a, 0x0000AAAA,    0x30,    PM_UNIT_SMQCTL,1 },
    { KEPLER_HWPM_SHARED_STORE,                  kepler_hwpm_shared_store_enc_str_1,             0x0000003a, 0x0000AAAA,    0x31,    PM_UNIT_SMQCTL,1 },
    { KEPLER_HWPM_GENERIC_LOAD,                  kepler_hwpm_generic_load_enc_str_1,              0x0000003a, 0x0000AAAA,    0x32,    PM_UNIT_SMQCTL,1 },

    { KEPLER_HWPM_GENERIC_STORE,                 kepler_hwpm_generic_store_enc_str_1,              0x0000003b, 0x0000AAAA,    0x30,    PM_UNIT_SMQCTL,1 },
    { KEPLER_HWPM_LOCAL_LOAD,                    kepler_hwpm_local_load_enc_str_1,               0x0000003b, 0x0000AAAA,    0x31,    PM_UNIT_SMQCTL,1 },
    { KEPLER_HWPM_LOCAL_STORE,                   kepler_hwpm_local_store_enc_str_1,              0x0000003b, 0x0000AAAA,    0x32,    PM_UNIT_SMQCTL,1 },

    //["BRANCH" =>
    //    ["br_executed",                    1,      "off",  "unique committed branch", undef],
    //    ["diverged_br_executed",           1,      "off",  "unique branches that diverge", undef],
    //]

    // **** SM CORE Signals ****

    //["ACTIVE_WARPS" =>
    //    ["active_cycles",           1,      "on",   "At least 1 active warp",                   undef],
    //    ["active_warps",            6,      "on",   "Number of active warps total in the SM",   undef],
    //],
    { KEPLER_HWPM_ACTIVE_CYCLES,                 kepler_hwpm_active_cycles_enc_str_1,            0x00000002, 0x0000AAAA,     0x20,    PM_UNIT_SMCORE,1 },
    { KEPLER_HWPM_ACTIVE_WARPS,                  kepler_hwpm_active_warps_enc_str_1,             0x00000002, 0x0000FFFF,     0x21,    PM_UNIT_SMCORE,6 },

    // *** L1C Signals ***

    //
    // FIXME: as per HW manual pri_l1c.ref, event group for L1C signals seems incorrect.
    // for instance LSU_COUNT_0 = 0x0000001a, but it seems 0x00000019 (same as GK104) gives correct value
    //

    //["LSU_TRANSACTIONS_0" =>
    //    ["local_ld_transactions",           1,      "off",   "count instructions at accept point", undef],
    //    ["local_st_transactions",           1,      "off",   "count instructions at accept point", undef],
    //    ["shared_ld_transactions",          1,      "off",   "count instructions at accept point", undef],
    //    ["shared_st_transactions",          1,      "off",   "count instructions at accept point", undef],
    //],
    //["LSU_TRANSACTIONS_1" =>
    //    ["global_ld_transactions",          1,      "off",   "count instructions at accept point", undef],
    //    ["global_st_transactions",          1,      "off",   "count instructions at accept point", undef],
    //],
    { KEPLER_HWPM_L1C_LOCAL_LOAD_TRANSACTIONS,      kepler_hwpm_l1c_local_load_transactions_enc_str_1,   0x00000019, 0x0000AAAA,     0x28,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_LOCAL_STORE_TRANSACTIONS,     kepler_hwpm_l1c_local_store_transactions_enc_str_1,  0x00000019, 0x0000AAAA,     0x29,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_SHARED_LOAD_TRANSACTIONS,     kepler_hwpm_l1c_shared_load_transactions_enc_str_1,  0x00000019, 0x0000AAAA,     0x2a,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_SHARED_STORE_TRANSACTIONS,    kepler_hwpm_l1c_shared_store_transactions_enc_str_1, 0x00000019, 0x0000AAAA,     0x2b,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_GLOBAL_LOAD_TRANSACTIONS,     kepler_hwpm_l1c_global_load_transactions_enc_str_1,  0x0000001a, 0x0000AAAA,     0x28,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_GLOBAL_STORE_TRANSACTIONS,    kepler_hwpm_l1c_global_store_transactions_enc_str_1, 0x0000001a, 0x0000AAAA,     0x29,    PM_UNIT_L1C,1 },

    //["LSU_COUNT_0" =>
    //    ["l1_shared_ld_count",              1,      "off",   "count instructions at accept point", undef],
    //    ["l1_shared_st_count",              1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_local_ld_hits",         1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_local_ld_misses",       1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_local_st_hits",         1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_local_st_misses",       1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_global_ld_hits",        1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_global_ld_misses",      1,      "off",   "count instructions at accept point", undef],

    { KEPLER_HWPM_L1C_LOCAL_LOAD_HIT,               kepler_hwpm_l1c_local_load_hit_enc_str_1,        0x0000001b, 0x0000AAAA,     0x2a,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_LOCAL_LOAD_MISS,              kepler_hwpm_l1c_local_load_miss_enc_str_1,       0x0000001b, 0x0000AAAA,     0x2b,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_LOCAL_STORE_HIT,              kepler_hwpm_l1c_local_store_hit_enc_str_1,       0x0000001b, 0x0000AAAA,     0x2c,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_LOCAL_STORE_MISS,             kepler_hwpm_l1c_local_store_miss_enc_str_1,      0x0000001b, 0x0000AAAA,     0x2d,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_GLOBAL_LOAD_HIT,              kepler_hwpm_l1c_global_load_hit_enc_str_1,       0x0000001b, 0x0000AAAA,     0x2e,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_GLOBAL_LOAD_MISS,             kepler_hwpm_l1c_global_load_miss_enc_str_1,      0x0000001b, 0x0000AAAA,     0x2f,    PM_UNIT_L1C,1 },

    // TBD: please cross check if signals below are correct??
    //["LSU_COUNT_1" =>
    //    ["l1_uncached_global_ld_count",     1,      "off",   "count instructions at accept point", undef],
    //    ["l1_global_st_count",              1,      "off",   "count instructions at accept point", undef],
    //],
    { KEPLER_HWPM_L1C_UNCACHED_GLOBAL_LOAD,         kepler_hwpm_l1c_uncached_global_load_enc_str_1,  0x0000001c, 0x0000AAAA,     0x28,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_GLOBAL_STORE,                 kepler_hwpm_l1c_global_store_enc_str_1,          0x0000001c, 0x0000AAAA,     0x29,    PM_UNIT_L1C,1 },

    //["TOQ_1" =>
    //    ["shared_ld_mem_divergence_replays",   1,      "off",   "shared ld is replayed due to bank conflict", undef],
    //    ["shared_st_mem_divergence_replays",   1,      "off",   "shared st is replayed due to bank conflict", undef],
    //],
    { KEPLER_HWPM_L1C_SHARED_LOAD_BANK_CONFLICT,    kepler_hwpm_l1c_shared_load_bank_conflict_enc_str_1,    0x00000008, 0x0000AAAA,     0x2a,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_SHARED_STORE_BANK_CONFLICT,   kepler_hwpm_l1c_shared_store_bank_conflict_enc_str_1,   0x00000008, 0x0000AAAA,     0x2b,    PM_UNIT_L1C,1 },
#endif

    //Tex signals
    // based on experiments - tex_cache_misses_gpc0_tpc0_tex0 and tex_cache_sector_queries_gpc0_tpc0_tex0
    // defined in \\hw\tools\perfalyze\chips\gk110\pml_files\tex.pml
    //tex0_cache_sector_queries  = tex02pm_gpc_t_sector_queries
    //tex0_cache_sector_misses   = tex02pm_gpc_t_missed_sectors

    { KEPLER_TEX0_CACHE_SECTOR_QUERIES,   kepler_tex0_cache_sector_queries_enc_str_1,  0x00000005, 0x0000FFFF, 0x00000004,    PM_UNIT_TEX_M,5, 0x00000003},
    { KEPLER_TEX1_CACHE_SECTOR_QUERIES,   kepler_tex1_cache_sector_queries_enc_str_1,  0x00000005, 0x0000FFFF, 0x00000004,    PM_UNIT_TEX_M,5, 0x00000004},
    { KEPLER_TEX2_CACHE_SECTOR_QUERIES,   kepler_tex2_cache_sector_queries_enc_str_1,  0x00000005, 0x0000FFFF, 0x0000000e,    PM_UNIT_TEX_M,5, 0x00000003},
    { KEPLER_TEX3_CACHE_SECTOR_QUERIES,   kepler_tex3_cache_sector_queries_enc_str_1,  0x00000005, 0x0000FFFF, 0x0000000e,    PM_UNIT_TEX_M,5, 0x00000004},

    { KEPLER_TEX0_CACHE_SECTOR_MISSES,    kepler_tex0_cache_sector_misses_enc_str_1,   0x00000004, 0x0000FFFF, 0x00000000,    PM_UNIT_TEX_M,5, 0x00000003},
    { KEPLER_TEX1_CACHE_SECTOR_MISSES,    kepler_tex1_cache_sector_misses_enc_str_1,   0x00000004, 0x0000FFFF, 0x00000000,    PM_UNIT_TEX_M,5, 0x00000004},
    { KEPLER_TEX2_CACHE_SECTOR_MISSES,    kepler_tex2_cache_sector_misses_enc_str_1,   0x00000004, 0x0000FFFF, 0x0000000a,    PM_UNIT_TEX_M,5, 0x00000003},
    { KEPLER_TEX3_CACHE_SECTOR_MISSES,    kepler_tex3_cache_sector_misses_enc_str_1,   0x00000004, 0x0000FFFF, 0x0000000a,    PM_UNIT_TEX_M,5, 0x00000004},

    { KEPLER_TEX0_GPC_T_LDG_CT_GRP5, kepler_tex0_gpc_t_ldg_ct_grp5_enc_str_1, 0x5, 0xaaaa, 0x9, PM_UNIT_TEX_M, 1, 3},
    { KEPLER_TEX1_GPC_T_LDG_CT_GRP5, kepler_tex1_gpc_t_ldg_ct_grp5_enc_str_1, 0x5, 0xaaaa, 0x9, PM_UNIT_TEX_M, 1, 4},
    { KEPLER_TEX2_GPC_T_LDG_CT_GRP5, kepler_tex2_gpc_t_ldg_ct_grp5_enc_str_1, 0x5, 0xaaaa, 0x13, PM_UNIT_TEX_M, 1, 3},
    { KEPLER_TEX3_GPC_T_LDG_CT_GRP5, kepler_tex3_gpc_t_ldg_ct_grp5_enc_str_1, 0x5, 0xaaaa, 0x13, PM_UNIT_TEX_M, 1, 4},

    { KEPLER_TEX0_GPC_T_LDG_CT_GRP4, kepler_tex0_gpc_t_ldg_ct_grp4_enc_str_1, 0x4, 0xaaaa, 0x9, PM_UNIT_TEX_M, 1, 3},
    { KEPLER_TEX1_GPC_T_LDG_CT_GRP4, kepler_tex1_gpc_t_ldg_ct_grp4_enc_str_1, 0x4, 0xaaaa, 0x9, PM_UNIT_TEX_M, 1, 4},
    { KEPLER_TEX2_GPC_T_LDG_CT_GRP4, kepler_tex2_gpc_t_ldg_ct_grp4_enc_str_1, 0x4, 0xaaaa, 0x13, PM_UNIT_TEX_M, 1, 3},
    { KEPLER_TEX3_GPC_T_LDG_CT_GRP4, kepler_tex3_gpc_t_ldg_ct_grp4_enc_str_1, 0x4, 0xaaaa, 0x13, PM_UNIT_TEX_M, 1, 4},

    //LDG signals
    // based on experiments - tex0_02pm_gpc_tm_samp_ldg_32_warp_executed, tex0_02pm_gpc_tm_samp_ldg_64_warp_executed, tex0_02pm_gpc_tm_samp_ldg_128_warp_executed
    // defined in \\hw\tools\perfalyze\chips\gk110\pml_files\tex.pml
    //ldg_32_warp_executed : the LDG equivalent of global_ld_32_executed; counts total 8-bit, 16-bit, and 32-bit LDG requests (one increment per warp)
    //ldg_64_warp_executed : the LDG equivalent of global_ld_64_executed; counts total 64-bit LDG requests (one increment per warp)
    //ldg_128_warp_executed : the LDG equivalent of global_ld_executed; counts total 128-bit LDG requests (one increment per warp)

    { TEX0_LDG_WARP_COUNT_32B,              tex0_ldg_warp_count_32b_enc_str_1,   0x0000003a, 0x0000aaaa, 0x00000017,    PM_UNIT_TEX_S,1, 0x00000000},
    { TEX1_LDG_WARP_COUNT_32B,              tex1_ldg_warp_count_32b_enc_str_1,   0x0000003a, 0x0000aaaa, 0x00000017,    PM_UNIT_TEX_S,1, 0x00000001},
    { TEX2_LDG_WARP_COUNT_32B,              tex2_ldg_warp_count_32b_enc_str_1,   0x0000003a, 0x0000aaaa, 0x00000058,    PM_UNIT_TEX_S,1, 0x00000000},
    { TEX3_LDG_WARP_COUNT_32B,              tex3_ldg_warp_count_32b_enc_str_1,   0x0000003a, 0x0000aaaa, 0x00000058,    PM_UNIT_TEX_S,1, 0x00000001},

    { TEX0_LDG_WARP_COUNT_64B,              tex0_ldg_warp_count_64b_enc_str_1,   0x0000003b, 0x0000aaaa, 0x00000017,    PM_UNIT_TEX_S,1, 0x00000000},
    { TEX1_LDG_WARP_COUNT_64B,              tex1_ldg_warp_count_64b_enc_str_1,   0x0000003b, 0x0000aaaa, 0x00000017,    PM_UNIT_TEX_S,1, 0x00000001},
    { TEX2_LDG_WARP_COUNT_64B,              tex2_ldg_warp_count_64b_enc_str_1,   0x0000003b, 0x0000aaaa, 0x00000058,    PM_UNIT_TEX_S,1, 0x00000000},
    { TEX3_LDG_WARP_COUNT_64B,              tex3_ldg_warp_count_64b_enc_str_1,   0x0000003b, 0x0000aaaa, 0x00000058,    PM_UNIT_TEX_S,1, 0x00000001},

    { TEX0_LDG_WARP_COUNT_128B,              tex0_ldg_warp_count_128b_enc_str_1,   0x0000003c, 0x0000aaaa, 0x00000017,    PM_UNIT_TEX_S,1, 0x00000000},
    { TEX1_LDG_WARP_COUNT_128B,              tex1_ldg_warp_count_128b_enc_str_1,   0x0000003c, 0x0000aaaa, 0x00000017,    PM_UNIT_TEX_S,1, 0x00000001},
    { TEX2_LDG_WARP_COUNT_128B,              tex2_ldg_warp_count_128b_enc_str_1,   0x0000003c, 0x0000aaaa, 0x00000058,    PM_UNIT_TEX_S,1, 0x00000000},
    { TEX3_LDG_WARP_COUNT_128B,              tex3_ldg_warp_count_128b_enc_str_1,   0x0000003c, 0x0000aaaa, 0x00000058,    PM_UNIT_TEX_S,1, 0x00000001},

    //LDG signals
    // defined in \\hw\tools\perfalyze\chips\gk110\pml_files\tex.pml

    // based on experiments - tex0_02pm_gpc_tm_samp_ldg_32_thread_executed, tex0_02pm_gpc_tm_samp_ldg_64_thread_executed, tex0_02pm_gpc_tm_samp_ldg_128_thread_executed
    //ldg_32_thread_executed : counts total 8-bit, 16-bit, and 32-bit LDG requests (per thread)
    //ldg_64_thread_executed : counts total 64-bit LDG requests (per thread)
    //ldg_128_thread_executed : counts total 128-bit LDG requests (per thread)
    { TEX0_LDG_THREAD_COUNT_32B,          tex0_ldg_thread_count_32b_enc_str_1,   0x0000003a, 0x0000FFFF, 0x00000014,    PM_UNIT_TEX_S,3, 0x00000000},
    { TEX1_LDG_THREAD_COUNT_32B,          tex1_ldg_thread_count_32b_enc_str_1,   0x0000003a, 0x0000FFFF, 0x00000014,    PM_UNIT_TEX_S,3, 0x00000001},
    { TEX2_LDG_THREAD_COUNT_32B,          tex2_ldg_thread_count_32b_enc_str_1,   0x0000003a, 0x0000FFFF, 0x00000055,    PM_UNIT_TEX_S,3, 0x00000000},
    { TEX3_LDG_THREAD_COUNT_32B,          tex3_ldg_thread_count_32b_enc_str_1,   0x0000003a, 0x0000FFFF, 0x00000055,    PM_UNIT_TEX_S,3, 0x00000001},

    { TEX0_LDG_THREAD_COUNT_64B,          tex0_ldg_thread_count_64b_enc_str_1,   0x0000003b, 0x0000FFFF, 0x00000014,    PM_UNIT_TEX_S,3, 0x00000000},
    { TEX1_LDG_THREAD_COUNT_64B,          tex1_ldg_thread_count_64b_enc_str_1,   0x0000003b, 0x0000FFFF, 0x00000014,    PM_UNIT_TEX_S,3, 0x00000001},
    { TEX2_LDG_THREAD_COUNT_64B,          tex2_ldg_thread_count_64b_enc_str_1,   0x0000003b, 0x0000FFFF, 0x00000055,    PM_UNIT_TEX_S,3, 0x00000000},
    { TEX3_LDG_THREAD_COUNT_64B,          tex3_ldg_thread_count_64b_enc_str_1,   0x0000003b, 0x0000FFFF, 0x00000055,    PM_UNIT_TEX_S,3, 0x00000001},

    { TEX0_LDG_THREAD_COUNT_128B,          tex0_ldg_thread_count_128b_enc_str_1, 0x0000003c, 0x0000FFFF, 0x00000014,    PM_UNIT_TEX_S,3, 0x00000000},
    { TEX1_LDG_THREAD_COUNT_128B,          tex1_ldg_thread_count_128b_enc_str_1, 0x0000003c, 0x0000FFFF, 0x00000014,    PM_UNIT_TEX_S,3, 0x00000001},
    { TEX2_LDG_THREAD_COUNT_128B,          tex2_ldg_thread_count_128b_enc_str_1, 0x0000003c, 0x0000FFFF, 0x00000055,    PM_UNIT_TEX_S,3, 0x00000000},
    { TEX3_LDG_THREAD_COUNT_128B,          tex3_ldg_thread_count_128b_enc_str_1, 0x0000003c, 0x0000FFFF, 0x00000055,    PM_UNIT_TEX_S,3, 0x00000001},

    { KEPLER_ELAPSED_CYCLES_SM,              kepler_elapsed_cycles_sm_enc_str_1,             0x00000000, 0x00000000, 0x00000000,    PM_UNIT_SMCORE,0},

    { KEPLER_TEX0_BANK_CONFLICTS,    kepler_tex0_bank_conflicts_enc_str_1,   0x00000006, 0x0000aaaa, 0x51,    PM_UNIT_TEX_D,1, 0x00000000},
    { KEPLER_TEX1_BANK_CONFLICTS,    kepler_tex1_bank_conflicts_enc_str_1,   0x00000006, 0x0000aaaa, 0x51,    PM_UNIT_TEX_D,1, 0x00000001},
    { KEPLER_TEX2_BANK_CONFLICTS,    kepler_tex2_bank_conflicts_enc_str_1,   0x00000006, 0x0000aaaa, 0x5c,    PM_UNIT_TEX_D,1, 0x00000000},
    { KEPLER_TEX3_BANK_CONFLICTS,    kepler_tex3_bank_conflicts_enc_str_1,   0x00000006, 0x0000aaaa, 0x5c,    PM_UNIT_TEX_D,1, 0x00000001},

    {KEPLER_TEX0_TEX2SM_TEX_PRDY, kepler_tex0_tex2sm_tex_prdy_enc_str_1, 0x3, 0xaaaa, 0x53, PM_UNIT_TEX_D, 1, 0},
    {KEPLER_TEX1_TEX2SM_TEX_PRDY, kepler_tex1_tex2sm_tex_prdy_enc_str_1, 0x3, 0xaaaa, 0x53, PM_UNIT_TEX_D, 1, 1},
    {KEPLER_TEX2_TEX2SM_TEX_PRDY, kepler_tex2_tex2sm_tex_prdy_enc_str_1, 0x3, 0xaaaa, 0x5e, PM_UNIT_TEX_D, 1, 0},
    {KEPLER_TEX3_TEX2SM_TEX_PRDY, kepler_tex3_tex2sm_tex_prdy_enc_str_1, 0x3, 0xaaaa, 0x5e, PM_UNIT_TEX_D, 1, 1},
    {KEPLER_TEX0_TEX2SM_TEX_PVLD, kepler_tex0_tex2sm_tex_pvld_enc_str_1, 0x3, 0xaaaa, 0x52, PM_UNIT_TEX_D, 1, 0},
    {KEPLER_TEX1_TEX2SM_TEX_PVLD, kepler_tex1_tex2sm_tex_pvld_enc_str_1, 0x3, 0xaaaa, 0x52, PM_UNIT_TEX_D, 1, 1},
    {KEPLER_TEX2_TEX2SM_TEX_PVLD, kepler_tex2_tex2sm_tex_pvld_enc_str_1, 0x3, 0xaaaa, 0x5d, PM_UNIT_TEX_D, 1, 0},
    {KEPLER_TEX3_TEX2SM_TEX_PVLD, kepler_tex3_tex2sm_tex_pvld_enc_str_1, 0x3, 0xaaaa, 0x5d, PM_UNIT_TEX_D, 1, 1},

    {KEPLER_L1C_PRT_PENDING_ENTRIES, kepler_l1c_prt_pending_entries_enc_str_1, 0xe, 0xffff, 0x28, PM_UNIT_L1C, 7},
    {KEPLER_L1C_PRT_ENTRIES_INUSE,   kepler_l1c_prt_entries_inuse_enc_str_1,   0xf, 0xffff, 0x28, PM_UNIT_L1C, 7},
    {KEPLER_L1C_PRT_ENTRIES_USABLE,  kepler_l1c_prt_entries_usable_enc_str_1,  0x10, 0xffff, 0x28, PM_UNIT_L1C, 7},

    { INVALID_PM_SIGNAL_NEW,            "",                             0xffffffff, 0x00000000,     0x00,        PM_UNIT_MAX,0 }
};

PerfSignalHwpm PerfSignalTableGK110_ltc0[] = {
    //FBP signals
    { KEPLER_FB_SUBP0_DRAMC_READ,          kepler_fb_subp0_dramc_read_enc_str_1,            0x00000011, 0x0000AAAA,  0x00000000,   PM_UNIT_FB,1 },
    { KEPLER_FB_SUBP1_DRAMC_READ,          kepler_fb_subp1_dramc_read_enc_str_1,            0x00000012, 0x0000AAAA,  0x00000000,   PM_UNIT_FB,1 },
    { KEPLER_FB_SUBP0_DRAMC_WRITE,         kepler_fb_subp0_dramc_write_enc_str_1,           0x00000011, 0x0000AAAA,  0x00000001,   PM_UNIT_FB,1 },
    { KEPLER_FB_SUBP1_DRAMC_WRITE,         kepler_fb_subp1_dramc_write_enc_str_1,           0x00000012, 0x0000AAAA,  0x00000001,   PM_UNIT_FB,1 },

    // fb_dram_activates_subp0_fbp0_pa0       = fbpa02pm_subp0_actarb_activate      "Number of bank activates in subpartition-0"
    // fb_dram_activates_subp1_fbp0_pa0       = fbpa02pm_subp1_actarb_activate      "Number of bank activates in subpartition-1"
    { KEPLER_FB_SUBP0_DRAM_ACTIVATES,      kepler_fb_subp0_dram_activates_enc_str_1,             0x00000001, 0x0000AAAA,  0x00000006,   PM_UNIT_FB,1 },
    { KEPLER_FB_SUBP1_DRAM_ACTIVATES,      kepler_fb_subp1_dram_activates_enc_str_1,             0x00000002, 0x0000AAAA,  0x00000006,   PM_UNIT_FB,1 },

    //LTC signals
    // l2_subp0_write_sector_misses = ltc_ltc2fb_dirty_dat0_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 0
    // l2_subp1_write_sector_misses = ltc_ltc2fb_dirty_dat1_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 1
    // l2_subp0_read_sector_misses  = ltc_fb2ltc_rdat0_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 0
    // l2_subp1_read_sector_misses  = ltc_fb2ltc_rdat1_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 1
    // l2_subp0_write_l1_sector_queries = ltc2pm_ltc_lts0_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 0
    // l2_subp1_write_l1_sector_queries = ltc2pm_ltc_lts1_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 1
    // l2_subp0_read_l1_sector_queries  = ltc2pm_ltc_lts0_request_rd_op && ltc2pm_ltc_lts1_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 0
    // l2_subp1_read_l1_sector_queries  = ltc2pm_ltc_lts1_request_rd_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 1

    { KEPLER_LTC0_WRITE_MISS_SECTORS,      kepler_ltc0_write_miss_sectors_enc_str_1,     0x00000006, 0x0000AAAA,  0x15,    PM_UNIT_LTC1,1, 0},
    { KEPLER_LTC1_WRITE_MISS_SECTORS,      kepler_ltc1_write_miss_sectors_enc_str_1,     0x00000006, 0x0000AAAA,  0x15,    PM_UNIT_LTC1,1, 1},
    { KEPLER_LTC2_WRITE_MISS_SECTORS,      kepler_ltc2_write_miss_sectors_enc_str_1,     0x00000006, 0x0000AAAA,  0x15,    PM_UNIT_LTC1,1, 2},
    { KEPLER_LTC3_WRITE_MISS_SECTORS,      kepler_ltc3_write_miss_sectors_enc_str_1,     0x00000006, 0x0000AAAA,  0x15,    PM_UNIT_LTC1,1, 3},
    { KEPLER_LTC0_READ_MISS_SECTORS,       kepler_ltc0_read_miss_sectors_enc_str_1,      0x00000006, 0x0000AAAA,  0x16,    PM_UNIT_LTC1,1, 0},
    { KEPLER_LTC1_READ_MISS_SECTORS,       kepler_ltc1_read_miss_sectors_enc_str_1,      0x00000006, 0x0000AAAA,  0x16,    PM_UNIT_LTC1,1, 1},
    { KEPLER_LTC2_READ_MISS_SECTORS,       kepler_ltc2_read_miss_sectors_enc_str_1,      0x00000006, 0x0000AAAA,  0x16,    PM_UNIT_LTC1,1, 2},
    { KEPLER_LTC3_READ_MISS_SECTORS,       kepler_ltc3_read_miss_sectors_enc_str_1,      0x00000006, 0x0000AAAA,  0x16,    PM_UNIT_LTC1,1, 3},

    {KEPLER_LTC0_HIT_SECTORS, kepler_ltc0_hit_sectors_enc_str_1, 0x1, 0xffff, 0xc, PM_UNIT_LTC, 4, 0},
    {KEPLER_LTC1_HIT_SECTORS, kepler_ltc1_hit_sectors_enc_str_1, 0x1, 0xffff, 0xc, PM_UNIT_LTC, 4, 1},
    {KEPLER_LTC2_HIT_SECTORS, kepler_ltc2_hit_sectors_enc_str_1, 0x1, 0xffff, 0xc, PM_UNIT_LTC, 4, 2},
    {KEPLER_LTC3_HIT_SECTORS, kepler_ltc3_hit_sectors_enc_str_1, 0x1, 0xffff, 0xc, PM_UNIT_LTC, 4, 3},
    {KEPLER_LTC0_REQUEST_SECTORS, kepler_ltc0_request_sectors_enc_str_1, 0x0, 0xffff, 0xc, PM_UNIT_LTC, 4, 0},
    {KEPLER_LTC1_REQUEST_SECTORS, kepler_ltc1_request_sectors_enc_str_1, 0x0, 0xffff, 0xc, PM_UNIT_LTC, 4, 1},
    {KEPLER_LTC2_REQUEST_SECTORS, kepler_ltc2_request_sectors_enc_str_1, 0x0, 0xffff, 0xc, PM_UNIT_LTC, 4, 2},
    {KEPLER_LTC3_REQUEST_SECTORS, kepler_ltc3_request_sectors_enc_str_1, 0x0, 0xffff, 0xc, PM_UNIT_LTC, 4, 3},
    {KEPLER_LTC0_REQUEST_SRC_UNIT_TEX, kepler_ltc0_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 0},
    {KEPLER_LTC1_REQUEST_SRC_UNIT_TEX, kepler_ltc1_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 1},
    {KEPLER_LTC2_REQUEST_SRC_UNIT_TEX, kepler_ltc2_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 2},
    {KEPLER_LTC3_REQUEST_SRC_UNIT_TEX, kepler_ltc3_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 3},
    {KEPLER_LTC0_REQUEST_SRC_UNIT_L1, kepler_ltc0_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 0},
    {KEPLER_LTC1_REQUEST_SRC_UNIT_L1, kepler_ltc1_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 1},
    {KEPLER_LTC2_REQUEST_SRC_UNIT_L1, kepler_ltc2_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 2},
    {KEPLER_LTC3_REQUEST_SRC_UNIT_L1, kepler_ltc3_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 3},
    {KEPLER_LTC0_REQUEST_SRC_UNIT_GCC, kepler_ltc0_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 0},
    {KEPLER_LTC1_REQUEST_SRC_UNIT_GCC, kepler_ltc1_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 1},
    {KEPLER_LTC2_REQUEST_SRC_UNIT_GCC, kepler_ltc2_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 2},
    {KEPLER_LTC3_REQUEST_SRC_UNIT_GCC, kepler_ltc3_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 3},
    {KEPLER_LTC0_REQUEST_ACTIVE, kepler_ltc0_request_active_enc_str_1, 0x0, 0xaaaa, 0x12, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_REQUEST_ACTIVE, kepler_ltc1_request_active_enc_str_1, 0x0, 0xaaaa, 0x12, PM_UNIT_LTC1, 1, 1},
    {KEPLER_LTC2_REQUEST_ACTIVE, kepler_ltc2_request_active_enc_str_1, 0x0, 0xaaaa, 0x12, PM_UNIT_LTC1, 1, 2},
    {KEPLER_LTC3_REQUEST_ACTIVE, kepler_ltc3_request_active_enc_str_1, 0x0, 0xaaaa, 0x12, PM_UNIT_LTC1, 1, 3},
    {KEPLER_LTC0_REQUEST_RD_OP, kepler_ltc0_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x28, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_REQUEST_RD_OP, kepler_ltc1_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x28, PM_UNIT_LTC1, 1, 1},
    {KEPLER_LTC2_REQUEST_RD_OP, kepler_ltc2_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x28, PM_UNIT_LTC1, 1, 2},
    {KEPLER_LTC3_REQUEST_RD_OP, kepler_ltc3_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x28, PM_UNIT_LTC1, 1, 3},
    {KEPLER_LTC0_REQUEST_WR_OP, kepler_ltc0_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x27, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_REQUEST_WR_OP, kepler_ltc1_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x27, PM_UNIT_LTC1, 1, 1},
    {KEPLER_LTC2_REQUEST_WR_OP, kepler_ltc2_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x27, PM_UNIT_LTC1, 1, 2},
    {KEPLER_LTC3_REQUEST_WR_OP, kepler_ltc3_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x27, PM_UNIT_LTC1, 1, 3},
    {KEPLER_LTC0_REQUEST_ATOMIC_OP, kepler_ltc0_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x26, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_REQUEST_ATOMIC_OP, kepler_ltc1_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x26, PM_UNIT_LTC1, 1, 1},
    {KEPLER_LTC2_REQUEST_ATOMIC_OP, kepler_ltc2_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x26, PM_UNIT_LTC1, 1, 2},
    {KEPLER_LTC3_REQUEST_ATOMIC_OP, kepler_ltc3_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x26, PM_UNIT_LTC1, 1, 3},
    {KEPLER_LTC0_REQUEST_APERTURE_SYSMEM, kepler_ltc0_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x22, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_REQUEST_APERTURE_SYSMEM, kepler_ltc1_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x22, PM_UNIT_LTC1, 1, 1},
    {KEPLER_LTC2_REQUEST_APERTURE_SYSMEM, kepler_ltc2_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x22, PM_UNIT_LTC1, 1, 2},
    {KEPLER_LTC3_REQUEST_APERTURE_SYSMEM, kepler_ltc3_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x22, PM_UNIT_LTC1, 1, 3},
    {KEPLER_LTC0_REQUEST_APERTURE_VIDMEM, kepler_ltc0_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x21, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_REQUEST_APERTURE_VIDMEM, kepler_ltc1_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x21, PM_UNIT_LTC1, 1, 1},
    {KEPLER_LTC2_REQUEST_APERTURE_VIDMEM, kepler_ltc2_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x21, PM_UNIT_LTC1, 1, 2},
    {KEPLER_LTC3_REQUEST_APERTURE_VIDMEM, kepler_ltc3_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x21, PM_UNIT_LTC1, 1, 3},

    {KEPLER_LTC0_HIT, kepler_ltc0_hit_enc_str_1, 0x0, 0xaaaa, 0x18, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_HIT, kepler_ltc1_hit_enc_str_1, 0x0, 0xaaaa, 0x18, PM_UNIT_LTC1, 1, 1},
    {KEPLER_LTC2_HIT, kepler_ltc2_hit_enc_str_1, 0x0, 0xaaaa, 0x18, PM_UNIT_LTC1, 1, 2},
    {KEPLER_LTC3_HIT, kepler_ltc3_hit_enc_str_1, 0x0, 0xaaaa, 0x18, PM_UNIT_LTC1, 1, 3},

    {KEPLER_LTC0_REQUEST, kepler_ltc0_request_enc_str_1, 0x0, 0xaaaa, 0x11, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_REQUEST, kepler_ltc1_request_enc_str_1, 0x0, 0xaaaa, 0x11, PM_UNIT_LTC1, 1, 1},
    {KEPLER_LTC2_REQUEST, kepler_ltc2_request_enc_str_1, 0x0, 0xaaaa, 0x11, PM_UNIT_LTC1, 1, 2},
    {KEPLER_LTC3_REQUEST, kepler_ltc3_request_enc_str_1, 0x0, 0xaaaa, 0x11, PM_UNIT_LTC1, 1, 3},

    { INVALID_PM_SIGNAL_NEW,        "",                                 0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalSmpc PerfSignalTableGK110_sm0[] = {
    // QCTL Signals

    //["GROUP1" =>
    //    ["nop_trig0",               1,      "off",  "# of nop.trig instructions executed where bit 0 of #Imm16 was set", undef],
    //    ["nop_trig1",               1,      "off",  "# of nop.trig instructions executed where bit 1 of #Imm16 was set", undef],
    //    ["nop_trig2",               1,      "off",  "# of nop.trig instructions executed where bit 2 of #Imm16 was set", undef],
    //    ["nop_trig3",               1,      "off",  "# of nop.trig instructions executed where bit 3 of #Imm16 was set", undef],
    //    ["nop_trig4",               1,      "off",  "# of nop.trig instructions executed where bit 4 of #Imm16 was set", undef],
    //    ["nop_trig5",               1,      "off",  "# of nop.trig instructions executed where bit 5 of #Imm16 was set", undef],
    //    ["nop_trig6",               1,      "off",  "# of nop.trig instructions executed where bit 6 of #Imm16 was set", undef],
    //    ["nop_trig7",               1,      "off",  "# of nop.trig instructions executed where bit 7 of #Imm16 was set", undef],
    //],
    //["GROUP2" =>
    //    ["nop_trig8",               1,      "off",  "# of nop.trig instructions executed where bit 8 of #Imm16 was set", undef],
    //    ["nop_trig9",               1,      "off",  "# of nop.trig instructions executed where bit 9 of #Imm16 was set", undef],
    //    ["nop_trig10",              1,      "off",  "# of nop.trig instructions executed where bit 10 of #Imm16 was set", undef],
    //    ["nop_trig11",              1,      "off",  "# of nop.trig instructions executed where bit 11 of #Imm16 was set", undef],
    //    ["nop_trig12",              1,      "off",  "# of nop.trig instructions executed where bit 12 of #Imm16 was set", undef],
    //    ["nop_trig13",              1,      "off",  "# of nop.trig instructions executed where bit 13 of #Imm16 was set", undef],
    //    ["nop_trig14",              1,      "off",  "# of nop.trig instructions executed where bit 14 of #Imm16 was set", undef],
    //    ["nop_trig15",              1,      "off",  "# of nop.trig instructions executed where bit 15 of #Imm16 was set", undef],
    //],
    { KEPLER_SM_NOP_TRIG_00,                      kepler_sm_nop_trig_00_enc_str_1,      0x00000001, 0x00000000, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_01,                      kepler_sm_nop_trig_01_enc_str_1,      0x00000001, 0x00000001, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_02,                      kepler_sm_nop_trig_02_enc_str_1,      0x00000001, 0x00000002, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_03,                      kepler_sm_nop_trig_03_enc_str_1,      0x00000001, 0x00000003, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_04,                      kepler_sm_nop_trig_04_enc_str_1,      0x00000001, 0x00000004, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_05,                      kepler_sm_nop_trig_05_enc_str_1,      0x00000001, 0x00000005, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_06,                      kepler_sm_nop_trig_06_enc_str_1,      0x00000001, 0x00000006, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_07,                      kepler_sm_nop_trig_07_enc_str_1,      0x00000001, 0x00000007, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_08,                      kepler_sm_nop_trig_08_enc_str_1,        0x00000002, 0x00000000, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_09,                      kepler_sm_nop_trig_09_enc_str_1,        0x00000002, 0x00000001, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_10,                      kepler_sm_nop_trig_10_enc_str_1,        0x00000002, 0x00000002, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_11,                      kepler_sm_nop_trig_11_enc_str_1,        0x00000002, 0x00000003, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_12,                      kepler_sm_nop_trig_12_enc_str_1,        0x00000002, 0x00000004, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_13,                      kepler_sm_nop_trig_13_enc_str_1,        0x00000002, 0x00000005, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_14,                      kepler_sm_nop_trig_14_enc_str_1,        0x00000002, 0x00000006, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_15,                      kepler_sm_nop_trig_15_enc_str_1,        0x00000002, 0x00000007, 0x00000001,    PM_UNIT_SMQCTL,1 },

    //["GROUP3" =>
    //    ["active_cycles_quad",      1,      "on",   "Sum of active cycles from all quads having At least 1 active warp",  undef],
    //    ["warps_launched",          1,      "on",   "If a warp was launched this cycle in this quad",       undef],
    //    ["threads_launched",        6,      "on",   "Number of threads launched this cycle in this quad",   undef],
    //],
    { KEPLER_SM_ACTIVE_CYCLES_QUAD,       kepler_sm_active_cycles_quad_enc_str_1,  0x00000003, 0x00000000, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_WARPS_LAUNCHED,           kepler_sm_warps_launched_enc_str_1,      0x00000003, 0x00000001, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_THREADS_LAUNCHED,         kepler_sm_threads_launched_enc_str_1,    0x00000003, 0x00765432, 0x0000003f,    PM_UNIT_SMQCTL,6 },

    //["GROUP5" =>
    //    ["inst_issued0",                    1,      "on",   "# of cycles issued 0 instructions",        undef],
    //    ["inst_issued1",                    1,      "on",   "# of cycles issued 1 instructions",        undef],
    //    ["inst_issued2",                    1,      "on",   "# of cycles issued 2 instructions",        undef],
    //]
    { KEPLER_SM_INST_ISSUED_1,             kepler_sm_inst_issued_1_enc_str_1,       0x00000005, 0x00000001, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_2,             kepler_sm_inst_issued_2_enc_str_1,       0x00000005, 0x00000002, 0x00000001,    PM_UNIT_SMQCTL,1 },

    //["GROUP4" =>
    //    ["threads_launched_for_execution",  6,      "on",   "Number of threads launched for execution, including helper threads", undef],
    //    ["inst_executed",                   2,      "on",   "# of instructions executed",              undef],
    //],
    { KEPLER_SM_INST_EXECUTED,            kepler_sm_inst_executed_enc_str_1,       0x00000004, 0x00000076, 0x00000003,    PM_UNIT_SMQCTL,2 },

    //["GROUP17" =>
    //    ["thread_inst_executed",    6,      "on",   "Number of thread instruction executed this cycle in this quad",   undef],
    //],
    { KEPLER_SM_THREAD_INST_EXECUTED,         kepler_sm_thread_inst_executed_enc_str_1,0x00000011, 0x00543210, 0x0000003f,    PM_UNIT_SMQCTL,6 },

    //["GROUP18" =>
    //    ["tex_quad_fetches",                1,      "on",   "Texture quad requests in this quad",   undef],
    //],
    { KEPLER_SM_TEX_QUAD_FETCHES,             kepler_sm_tex_quad_fetches_enc_str_1,0x00000012, 0x00000000, 0x00000001,    PM_UNIT_SMQCTL,1 },

    //["GROUP29" =>
    //    ["inst_executed_lsu_size_128",      1,      "off",  "128b lsu instr",    undef],
    //    ["inst_executed_lsu_size_64",       1,      "off",  "64b lsu instr",     undef],
    //    ["inst_executed_lsu_size_32",       1,      "off",  "32b lsu instr",     undef],
    //    ["inst_executed_lsu_sub_size_32",   1,      "off",  "< 32b lsu instr",   undef],
    //    ["lsu_inst_predicated_off",         1,      "off",  "committed but completely predicated off LSU instructions", undef],
    //]
    { KEPLER_SM_INST_EXECUTED_LSU_SIZE_128,     kepler_sm_inst_executed_lsu_size_128_enc_str_1,       0x0000001D, 0x00000000, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_SIZE_64,      kepler_sm_inst_executed_lsu_size_64_enc_str_1,        0x0000001D, 0x00000002, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_SIZE_32,      kepler_sm_inst_executed_lsu_size_32_enc_str_1,        0x0000001D, 0x00000003, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_SUB_SIZE_32,  kepler_sm_inst_executed_lsu_sub_size_32_enc_str_1,    0x0000001D, 0x00000004, 0x00000001,    PM_UNIT_SMQCTL,1 },

    { KEPLER_SM_LSU_INST_PREDICATED_OFF,        kepler_sm_lsu_inst_predicated_off_enc_str_1,          0x0000001D, 0x00000005, 0x00000001,    PM_UNIT_SMQCTL,1 },
    //["GROUP20" =>
    //    ["not_predicated_off_thread_inst_executed", 6,      "off",  "# executed but not predicated off thread instructions", undef],
    //],
    { KEPLER_SM_NOT_PREDICATED_OFF_THREAD_INST_EXECUTED, kepler_sm_not_predicated_off_thread_inst_executed_enc_str_1,  0x00000014, 0x00543210, 0x0000003f,    PM_UNIT_SMQCTL,6 },

    //["GROUP26" =>
    //    ["inst_executed_lsu_atom",          1,      "off",  "atom",                     undef],
    //    ["inst_executed_lsu_red",           1,      "off",  "reduction",                undef],
    { KEPLER_SM_L1C_ATOM_COUNT,                    kepler_sm_l1c_atom_count_enc_str_1,        0x0000001A, 0x00000004, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_L1_ATOM_CAS_COUNT,                 kepler_sm_l1_atom_cas_count_enc_str_1,     0x0000001A, 0x00000005, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_L1C_GRED_COUNT,                    kepler_sm_l1c_gred_count_enc_str_1,        0x0000001A, 0x00000006, 0x00000001,    PM_UNIT_SMQCTL,1 },


    //["GROUP27" =>
    //    ["inst_executed_lsu_lds",           1,      "off",  "shared store ",    undef],
    //    ["inst_executed_lsu_sts",           1,      "off",  "shared load ",     undef],
    //    ["inst_executed_lsu_ldl",           1,      "off",  "local load ",      undef],
    //    ["inst_executed_lsu_stl",           1,      "off",  "local store ",     undef],
    //    ["inst_executed_lsu_ld",            1,      "off",  "generic load",     undef],
    //    ["inst_executed_lsu_st",            1,      "off",  "generic store",    undef],
    //],
    { KEPLER_SM_SHARED_LOAD,                       kepler_sm_shared_load_enc_str_1,         0x0000001B, 0x00000000, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_SHARED_STORE,                      kepler_sm_shared_store_enc_str_1,        0x0000001B, 0x00000001, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_LOCAL_LOAD,                        kepler_sm_local_load_enc_str_1,          0x0000001B, 0x00000002, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_LOCAL_STORE,                       kepler_sm_local_store_enc_str_1,         0x0000001B, 0x00000003, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_GENERIC_LOAD,                      kepler_sm_generic_load_enc_str_1,         0x0000001B, 0x00000004, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_GENERIC_STORE,                     kepler_sm_generic_store_enc_str_1,         0x0000001B, 0x00000005, 0x00000001,    PM_UNIT_SMQCTL,1 },

    //["GROUP28" =>
    //    ["br_executed",                     1,      "off",  "unique committed branch", undef],
    //    ["diverged_br_executed",            1,      "off",  "unique branches that diverge", undef],
    //],

    // Disable counters branch and divergent branch as they are not giving correct count on GK110 due to the following issues:(bug 972905)
    // (1) Early branch resolution seems to break br* signal counting
    // (2) Speculatively issued branches that get rolled back in the shadow of IMC miss are being counted
#if 0
    { KEPLER_SM_UNIQUE_BRANCHES,                   kepler_sm_unique_branches_enc_str_1,               0x0000001C, 0x00000000, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_DIVERGED_BRANCHES,                 kepler_sm_diverged_branches_enc_str_1,     0x0000001C, 0x00000001, 0x00000001,    PM_UNIT_SMQCTL,1 },
#endif

    // CORE and L1C Signals

    //["GROUP2_CORE" =>
    //    ["active_cycles",           1,      "on",   "At least 1 active warp",                   undef],
    //    ["active_warps",            6,      "on",   "Number of active warps total in the SM",   undef],
    //    ["ctas_launched",           1,      "on",   "Number of CTAs launched in the SM",        undef],
    //],
    { KEPLER_SM_ACTIVE_CYCLES,                kepler_sm_active_cycles_enc_str_1,      0x00000002, 0x00000000, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_ACTIVE_WARPS,                 kepler_sm_active_warps_enc_str_1,       0x00000002, 0x00654321, 0x0000003f,    PM_UNIT_SMCORE,6 },
    { KEPLER_SM_CTA_LAUNCHED,                 kepler_sm_cta_launched_enc_str_1,    0x00000002, 0x00000007, 0x00000001,    PM_UNIT_SMCORE,1 },

    //["GROUP14_LSU" =>
    //    ["local_ld_transactions",   1,      "off",  "count instructions at accept point", undef],
    //    ["local_st_transactions",   1,      "off",  "count instructions at accept point", undef],
    //    ["shared_ld_transactions",  1,      "off",  "count instructions at accept point", undef],
    //    ["shared_st_transactions",  1,      "off",  "count instructions at accept point", undef],
    //],
    //["GROUP15_LSU" =>
    //    ["global_ld_transactions",              1,      "off",   "count instructions at accept point", undef],
    //    ["global_st_transactions",              1,      "off",   "count instructions at accept point", undef],
    //],
    { KEPLER_SM_L1C_LOCAL_LOAD_TRANSACTIONS,      kepler_sm_l1c_local_load_transactions_enc_str_1,   0x0000000e, 0x00000000, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_LOCAL_STORE_TRANSACTIONS,     kepler_sm_l1c_local_store_transactions_enc_str_1,  0x0000000e, 0x00000001, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_SHARED_LOAD_TRANSACTIONS,     kepler_sm_l1c_shared_load_transactions_enc_str_1,  0x0000000e, 0x00000002, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_SHARED_STORE_TRANSACTIONS,    kepler_sm_l1c_shared_store_transactions_enc_str_1, 0x0000000e, 0x00000003, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_GLOBAL_LOAD_TRANSACTIONS,     kepler_sm_l1c_global_load_transactions_enc_str_1,  0x0000000f, 0x00000000, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_GLOBAL_STORE_TRANSACTIONS,    kepler_sm_l1c_global_store_transactions_enc_str_1, 0x0000000f, 0x00000001, 0x00000001,    PM_UNIT_SMCORE,1 },

    //["GROUP16_LSU" =>
    //    ["l1_cached_local_ld_hits",             1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_local_ld_misses",           1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_local_st_hits",             1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_local_st_misses",           1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_global_ld_hits",            1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_global_ld_misses",          1,      "off",   "count instructions at accept point", undef],
    //],
    { KEPLER_SM_L1C_LOCAL_LOAD_HIT,           kepler_sm_l1c_local_load_hit_enc_str_1,    0x00000010, 0x00000000, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_LOCAL_LOAD_MISS,          kepler_sm_l1c_local_load_miss_enc_str_1,   0x00000010, 0x00000001, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_LOCAL_STORE_HIT,          kepler_sm_l1c_local_store_hit_enc_str_1,   0x00000010, 0x00000002, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_LOCAL_STORE_MISS,         kepler_sm_l1c_local_store_miss_enc_str_1,  0x00000010, 0x00000003, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_GLOBAL_LOAD_HIT,          kepler_sm_l1c_global_load_hit_enc_str_1,   0x00000010, 0x00000004, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_GLOBAL_LOAD_MISS,         kepler_sm_l1c_global_load_miss_enc_str_1,  0x00000010, 0x00000005, 0x00000001,    PM_UNIT_SMCORE,1 },

    //["GROUP17_LSU" =>
    //    ["l1_uncached_global_ld_count",         1,      "off",   "count instructions at accept point", undef],
    //    ["l1_global_st_count",                  1,      "off",   "count instructions at accept point", undef],
    //    ["l1_atom_count",                       1,      "off",   "count instructions at accept point", undef],
    //    ["l1_atom_cas_count",                   1,      "off",   "count instructions at accept point", undef],
    //    ["l1_red_count",                        1,      "off",   "count instructions at accept point", undef],
    //    ["l1_dirty_line_eviction",              1,      "off",   "count instructions at accept point", undef],
    //    ["l1_partial_local_cached_st_misses",   1,      "off",   "count instructions at accept point", undef],
    //    ["lsu_rmw_wr_request",                  1,      "off",   "count instructions at accept point", undef],

    { KEPLER_SM_L1C_UNCACHED_GLOBAL_LOAD,           kepler_sm_l1c_uncached_global_load_enc_str_1,  0x00000011, 0x00000000, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_GLOBAL_STORE,                   kepler_sm_l1c_global_store_enc_str_1,          0x00000011, 0x00000001, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_DIRTY_LINE_EVICTION,            kepler_sm_l1c_dirty_line_eviction_enc_str_1,            0x00000011, 0x00000005, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_PARTIAL_LOCAL_CACHED_ST_MISSES, kepler_sm_l1c_partial_local_cached_st_misses_enc_str_1, 0x00000011, 0x00000006, 0x00000001,    PM_UNIT_SMCORE,1 },

    //["GROUP8_LSU" =>
    //    ["local_ld_mem_divergence_replays",     1,      "off",   "local ld is replayed due to divergence", undef],
    //    ["local_st_mem_divergence_replays",     1,      "off",   "local st is replayed due to divergence", undef],
    //    ["shared_ld_mem_divergence_replays",    1,      "off",   "shared ld is replayed due to bank conflict", undef],
    //    ["shared_st_mem_divergence_replays",    1,      "off",   "shared st is replayed due to bank conflict", undef],
    //    ["global_ld_mem_divergence_replays",    1,      "off",   "global ld is replayed due to divergence", undef],
    //    ["global_st_mem_divergence_replays",    1,      "off",   "global st is replayed due to divergence", undef],
    //    ["global_red_mem_divergence_replays",   1,      "off",   "global red is replayed due to divergence", undef],
    //    ["global_atom_mem_divergence_replays",  1,      "off",   "global atom is replayed due to divergence", undef],
    //],
    { KEPLER_SM_L1C_LOCAL_LD_MEM_DIVERGENCE_REPLAYS,   kepler_sm_l1c_local_ld_mem_divergence_replays_enc_str_1,  0x00000008, 0x00000000, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_LOCAL_ST_MEM_DIVERGENCE_REPLAYS,   kepler_sm_l1c_local_st_mem_divergence_replays_enc_str_1,  0x00000008, 0x00000001, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_SHARED_LOAD_BANK_CONFLICT,         kepler_sm_l1c_shared_load_bank_conflict_enc_str_1,        0x00000008, 0x00000002, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_SHARED_STORE_BANK_CONFLICT,        kepler_sm_l1c_shared_store_bank_conflict_enc_str_1,       0x00000008, 0x00000003, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_GLOBAL_LD_MEM_DIVERGENCE_REPLAYS,  kepler_sm_l1c_global_ld_mem_divergence_replays_enc_str_1, 0x00000008, 0x00000004, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_GLOBAL_ST_MEM_DIVERGENCE_REPLAYS,  kepler_sm_l1c_global_st_mem_divergence_replays_enc_str_1, 0x00000008, 0x00000005, 0x00000001,    PM_UNIT_SMCORE,1 },

    { KEPLER_SM_WARP_ISSUE_ELIGIBLE,                          kepler_sm_warp_issue_eligible_enc_str_1,                        0x00000005, 0x00076543, 0x0000001f, PM_UNIT_SMQCTL,5 },
    { KEPLER_SM_WARP_CANT_ISSUE_NO_INST,                      kepler_sm_warp_cant_issue_no_inst_enc_str_1,                    0x00000006, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_DISPATCH_STALL,               kepler_sm_warp_cant_issue_dispatch_stall_enc_str_1,             0x00000006, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_PARTIALLY_LOADED_SUBTILE,     kepler_sm_warp_cant_issue_partially_loaded_subtile_enc_str_1,   0x00000007, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_SWITCHING_IFB,                kepler_sm_warp_cant_issue_switching_ifb_enc_str_1,              0x00000007, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_WAITING,                      kepler_sm_warp_cant_issue_waiting_enc_str_1,                    0x00000008, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_MULTI_ISSUE,                  kepler_sm_warp_cant_issue_multi_issue_enc_str_1,                0x00000008, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_REPLAY_EXECUTING,             kepler_sm_warp_cant_issue_replay_executing_enc_str_1,           0x00000009, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_TEX_EXECUTING,                kepler_sm_warp_cant_issue_tex_executing_enc_str_1,              0x00000009, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_TEX_DEPENDENCY,               kepler_sm_warp_cant_issue_tex_dependency_enc_str_1,             0x0000000a, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_L1_MISS_DEPENDENCY,           kepler_sm_warp_cant_issue_l1_miss_dependency_enc_str_1,         0x0000000a, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_MSB_FULL,                     kepler_sm_warp_cant_issue_msb_full_enc_str_1,                   0x0000000b, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_IMC_MISS_DEPENDENCY,          kepler_sm_warp_cant_issue_imc_miss_dependency_enc_str_1,        0x0000000b, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4},
    { KEPLER_SM_WARP_CANT_ISSUE_SHADOW_PIPE_THROTTLE,         kepler_sm_warp_cant_issue_shadow_pipe_throttle_enc_str_1,       0x0000000c, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4, },
    { KEPLER_SM_WARP_CANT_ISSUE_TEX_THROTTLE,                 kepler_sm_warp_cant_issue_tex_throttle_enc_str_1,               0x0000000c, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4},
    { KEPLER_SM_WARP_CANT_ISSUE_RIB_THROTTLE,                 kepler_sm_warp_cant_issue_rib_throttle_enc_str_1,               0x0000000d, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_TEX_LOCK_MISMATCH,            kepler_sm_warp_cant_issue_tex_lock_mismatch_enc_str_1,          0x0000000d, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4, },
    { KEPLER_SM_WARP_CANT_ISSUE_MEMBAR,                       kepler_sm_warp_cant_issue_membar_enc_str_1,                     0x0000000e, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_HOLD_MISMATCH,                kepler_sm_warp_cant_issue_hold_mismatch_enc_str_1,              0x0000000f, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_NOT_SELECT,                   kepler_sm_warp_cant_issue_not_select_enc_str_1,                 0x0000000f, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_BARRIER,                      kepler_sm_warp_cant_issue_barrier_enc_str_1,                    0x0000000e, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4  },

    { KEPLER_SM_INST_EXECUTED_FAU_XLU_OPS,                    kepler_sm_inst_executed_fau_xlu_ops_enc_str_1,                  0x00000014, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_XLU_PIPE,                         kepler_sm_inst_issued_xlu_pipe_enc_str_1,                       0x00000015, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_SU_PIPE,                          kepler_sm_inst_issued_su_pipe_enc_str_1,                        0x00000015, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FU_PIPE,                          kepler_sm_inst_issued_fu_pipe_enc_str_1,                        0x00000015, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FMAX_PIPE,                        kepler_sm_inst_issued_fmax_pipe_enc_str_1,                      0x00000015, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FMAXLITEW_PIPE,                   kepler_sm_inst_issued_fmaxlitew_pipe_enc_str_1,                 0x00000015, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FAU_PIPE,                         kepler_sm_inst_issued_fau_pipe_enc_str_1,                       0x00000015, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FE_PIPE,                          kepler_sm_inst_issued_fe_pipe_enc_str_1,                        0x00000015, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_BRU_PIPE,                         kepler_sm_inst_issued_bru_pipe_enc_str_1,                       0x00000015, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FMALITEW_PIPE,                    kepler_sm_inst_issued_fmalitew_pipe_enc_str_1,                  0x00000016, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_ADU_PIPE,                         kepler_sm_inst_issued_adu_pipe_enc_str_1,                       0x00000016, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_AGU_PIPE,                         kepler_sm_inst_issued_agu_pipe_enc_str_1,                       0x00000016, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_TEX_PIPE,                         kepler_sm_inst_issued_tex_pipe_enc_str_1,                       0x00000016, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FP64_TO_FMAX_PIPE,                kepler_sm_inst_issued_fp64_to_fmax_pipe_enc_str_1,              0x00000016, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FP64_TO_FMAXLITE_PIPE,            kepler_sm_inst_issued_fp64_to_fmaxlite_pipe_enc_str_1,          0x00000016, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FMA64PLUS_PIPE,                   kepler_sm_inst_issued_fma64plus_pipe_enc_str_1,                 0x00000016, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FMA64LITE_PIPE,                   kepler_sm_inst_issued_fma64lite_pipe_enc_str_1,                 0x00000016, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_XLU_PIPE,                       kepler_sm_inst_executed_xlu_pipe_enc_str_1,                     0x00000017, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_SU_PIPE,                        kepler_sm_inst_executed_su_pipe_enc_str_1,                      0x00000017, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_FU_PIPE,                        kepler_sm_inst_executed_fu_pipe_enc_str_1,                      0x00000017, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_FMAX_PIPE,                      kepler_sm_inst_executed_fmax_pipe_enc_str_1,                    0x00000017, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_FMAXLITEW_PIPE,                 kepler_sm_inst_executed_fmaxlitew_pipe_enc_str_1,               0x00000017, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_FAU_PIPE,                       kepler_sm_inst_executed_fau_pipe_enc_str_1,                     0x00000017, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_FE_PIPE,                        kepler_sm_inst_executed_fe_pipe_enc_str_1,                      0x00000017, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_BRU_PIPE,                       kepler_sm_inst_executed_bru_pipe_enc_str_1,                     0x00000017, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_FMALITEW_PIPE,                  kepler_sm_inst_executed_fmalitew_pipe_enc_str_1,                0x00000018, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_ADU_PIPE,                       kepler_sm_inst_executed_adu_pipe_enc_str_1,                     0x00000018, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_AGU_PIPE,                       kepler_sm_inst_executed_agu_pipe_enc_str_1,                     0x00000018, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_TEX_PIPE,                       kepler_sm_inst_executed_tex_pipe_enc_str_1,                     0x00000018, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_TCS,                            kepler_sm_inst_executed_tcs_enc_str_1,                          0x00000018, 0x00000054, 0x00000003, PM_UNIT_SMQCTL,2 },
    { KEPLER_SM_INST_EXECUTED_TES,                            kepler_sm_inst_executed_tes_enc_str_1,                          0x00000018, 0x00000076, 0x00000003, PM_UNIT_SMQCTL,2 },
    { KEPLER_SM_INST_EXECUTED_VS,                             kepler_sm_inst_executed_vs_enc_str_1,                           0x00000019, 0x00000010, 0x00000003, PM_UNIT_SMQCTL,2 },
    { KEPLER_SM_INST_EXECUTED_PS,                             kepler_sm_inst_executed_ps_enc_str_1,                           0x00000019, 0x00000032, 0x00000003, PM_UNIT_SMQCTL,2 },
    { KEPLER_SM_INST_EXECUTED_GS,                             kepler_sm_inst_executed_gs_enc_str_1,                           0x00000019, 0x00000054, 0x00000003, PM_UNIT_SMQCTL,2 },
    { KEPLER_SM_INST_EXECUTED_CS,                             kepler_sm_inst_executed_cs_enc_str_1,                           0x00000019, 0x00000076, 0x00000003, PM_UNIT_SMQCTL,2 },
    { KEPLER_SM_INST_EXECUTED_LSU_SULDGA_B,                   kepler_sm_inst_executed_lsu_suldga_b_enc_str_1,                 0x0000001a, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_SULDGA_P,                   kepler_sm_inst_executed_lsu_suldga_p_enc_str_1,                 0x0000001a, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_SUSTGA_B,                   kepler_sm_inst_executed_lsu_sustga_b_enc_str_1,                 0x0000001a, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_SUSTGA_P,                   kepler_sm_inst_executed_lsu_sustga_p_enc_str_1,                 0x0000001a, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_ATOM_CAS,                   kepler_sm_inst_executed_lsu_atom_cas_enc_str_1,                 0x0000001a, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_LDS_U_128,                  kepler_sm_inst_executed_lsu_lds_u_128_enc_str_1,                0x0000001a, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_ALD,                        kepler_sm_inst_executed_lsu_ald_enc_str_1,                      0x0000001b, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_AST,                        kepler_sm_inst_executed_lsu_ast_enc_str_1,                      0x0000001b, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_ICC_HIT,                                      kepler_sm_icc_hit_enc_str_1,                                    0x00000005, 0x00000000, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_ICC_TRUE_MISS,                                kepler_sm_icc_true_miss_enc_str_1,                              0x00000005, 0x00000001, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_ICC_COVERED_MISS,                             kepler_sm_icc_covered_miss_enc_str_1,                           0x00000005, 0x00000002, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_ICC_PREFETCHES,                               kepler_sm_icc_prefetches_enc_str_1,                             0x00000005, 0x00000004, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_PRT_PENDING_ENTRIES,                          kepler_sm_prt_pending_entries_enc_str_1,                        0x0000000b, 0x06543210, 0x0000007f, PM_UNIT_SMCORE,7 },
    { KEPLER_SM_CANT_DISPATCH_REGISTER_INTERLOCK,             kepler_sm_cant_dispatch_register_interlock_enc_str_1,           0x00000010, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_CANT_DISPATCH_MEMORY_INTERLOCK,               kepler_sm_cant_dispatch_memory_interlock_enc_str_1,             0x00000010, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_CANT_DISPATCH_REGISTER_READ,                  kepler_sm_cant_dispatch_register_read_enc_str_1,                0x00000010, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_CANT_DISPATCH_REGISTER_WRITE,                 kepler_sm_cant_dispatch_register_write_enc_str_1,               0x00000010, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_CANT_DISPATCH_CRS_SPILL_FILL,                 kepler_sm_cant_dispatch_crs_spill_fill_enc_str_1,               0x00000010, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_CANT_DISPATCH_ADU_F5_RF_READ,                 kepler_sm_cant_dispatch_adu_f5_rf_read_enc_str_1,               0x00000010, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_CANT_DISPATCH_BRU_STALL,                      kepler_sm_cant_dispatch_bru_stall_enc_str_1,                    0x00000010, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_GLOBAL_RED_MEM_DIVERGENCE_REPLAYS,            kepler_sm_global_red_mem_divergence_replays_enc_str_1,          0x00000008, 0x00000006, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_GLOBAL_ATOM_MEM_DIVERGENCE_REPLAYS,           kepler_sm_global_atom_mem_divergence_replays_enc_str_1,         0x00000008, 0x00000007, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_GLOBAL_RED_TRANSACTIONS,                      kepler_sm_global_red_transactions_enc_str_1,                    0x0000000f, 0x00000002, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_GLOBAL_ATOM_TRANSACTIONS,                     kepler_sm_global_atom_transactions_enc_str_1,                   0x0000000f, 0x00000003, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_GLOBAL_ATOM_CAS_TRANSACTIONS,                 kepler_sm_global_atom_cas_transactions_enc_str_1,               0x0000000f, 0x00000004, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_IMC_DIVERGENCE_REPLAY,                        kepler_sm_imc_divergence_replay_enc_str_1,                      0x0000001c, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_PE_STOMP_DEFERRALS,                           kepler_sm_pe_stomp_deferrals_enc_str_1,                         0x00000009, 0x00000001, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_PRT_FULL_DEFERRALS,                           kepler_sm_prt_full_deferrals_enc_str_1,                         0x00000009, 0x00000002, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_WDB_FULL_DEFERRALS,                           kepler_sm_wdb_full_deferrals_enc_str_1,                         0x00000009, 0x00000003, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_T2M_FULL_DEFERRALS,                           kepler_sm_t2m_full_deferrals_enc_str_1,                         0x00000009, 0x00000004, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_SET_BUSY_DEFERRALS,                           kepler_sm_set_busy_deferrals_enc_str_1,                         0x0000000a, 0x00000000, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_UNCACHED_SET_BUSY_DEFERRALS,                  kepler_sm_uncached_set_busy_deferrals_enc_str_1,                0x0000000a, 0x00000001, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_ATOM_SET_BUSY_DEFERRALS,                      kepler_sm_atom_set_busy_deferrals_enc_str_1,                    0x0000000a, 0x00000002, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_LD_HIT_UNDER_MISS_DEFERRALS,                  kepler_sm_ld_hit_under_miss_deferrals_enc_str_1,                0x0000000a, 0x00000003, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1_MISS_GRANTS,                               kepler_sm_l1_miss_grants_enc_str_1,                             0x00000006, 0x00000000, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_PRE_SCHEDULED_REPLAYS,                        kepler_sm_pre_scheduled_replays_enc_str_1,                      0x00000013, 0x00000001, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_KILLED_PRE_SCHEDULED_REPLAYS,                 kepler_sm_killed_pre_scheduled_replays_enc_str_1,               0x00000013, 0x00000002, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_CCTL_MEM_DIVERGENCE_REPLAYS,                  kepler_sm_cctl_mem_divergence_replays_enc_str_1,                0x00000013, 0x00000003, 0x00000001, PM_UNIT_SMCORE,1 },

    { INVALID_PM_SIGNAL_NEW,            "",                       0xffffffff, 0x00000000, 0x00000000,     PM_UNIT_MAX,0 }
};

PerfSignalHwpm PerfSignalTableGK208_gpctpc[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type

    { KEPLER_HWPM_THREADS_LAUNCHED,              kepler_hwpm_threads_launched_enc_str_1,         0x00000002, 0x0000FFFF,  0x49,    PM_UNIT_SMQCTL,6 },
    { KEPLER_HWPM_CTA_LAUNCHED,                  kepler_hwpm_cta_launched_enc_str_1,             0x00000007, 0x0000AAAA,  0x2b,    PM_UNIT_SMCORE,1 },
#if CU_PROFILE_SM_SIGNALS_VIA_HWPM
    // **** SM QUAD Signals ****

    //["LAUNCHED" =>
    //    ["warps_launched",          1,      "on",   "If a warp was launched this cycle in this quad",       undef],
    //    ["threads_launched",        6,      "on",   "Number of threads launched this cycle in this quad",   undef],
    //],
    { KEPLER_HWPM_WARPS_LAUNCHED,                kepler_hwpm_warps_launched_enc_str_1,           0x00000002, 0x0000AAAA,  0x48,    PM_UNIT_SMQCTL,1 },

    //["INST_ISSUE_EXECUTED_IPC" =>
    //    ["active_cycles",           1,      "on",   "At least 1 active warp in the quad",      undef],
    //    ["inst_issued0",            1,      "on",   "# of cycles issued 0 instructions",       undef],
    //    ["inst_issued1",            1,      "on",   "# of cycles issued 1 instructions",       undef],
    //    ["inst_issued2",            1,      "on",   "# of cycles issued 2 instructions",       undef],
    //    ["active_cycles_2",         1,      "on",   "At least 1 active warp in the quad",      undef],
    //    ["inst_executed",           2,      "on",   "# of instructions executed",              undef],
    //]
    { KEPLER_HWPM_INST_ISSUED_1,                 kepler_hwpm_inst_issued_1_enc_str_1,            0x00000004, 0x0000AAAA,  0x4a,    PM_UNIT_SMQCTL,1 },
    { KEPLER_HWPM_INST_ISSUED_2,                 kepler_hwpm_inst_issued_2_enc_str_1,            0x00000004, 0x0000AAAA,  0x4b,    PM_UNIT_SMQCTL,1 },
    { KEPLER_HWPM_INST_EXECUTED,                 kepler_hwpm_inst_executed_enc_str_1,            0x00000004, 0x0000FFFF,  0x4d,    PM_UNIT_SMQCTL,2 },

    //["THREAD_INST_EXECUTED" =>
    //    ["thread_inst_executed",    6,      "on",   "Number of thread instruction executed this cycle in this quad",   undef],
    //],
    { KEPLER_HWPM_THREAD_INST_EXECUTED,          kepler_hwpm_thread_inst_executed_enc_str_1,     0x0000001d, 0x0000FFFF,  0x48,    PM_UNIT_SMQCTL,6 },

    //["LSU_INST_COUNT_1" =>
    //    ["inst_executed_lsu_lds", 1, "off", "shared load ", undef],
    //    ["inst_executed_lsu_sts", 1, "off", "shared store ", undef],
    //    ["inst_executed_lsu_ld", 1, "off", "generic load", undef],
    //]
    //["LSU_INST_COUNT_2" =>
    //    ["inst_executed_lsu_st", 1, "off", "generic store", undef],
    //    ["inst_executed_lsu_ldl", 1, "off", "local load", undef],
    //    ["inst_executed_lsu_stl", 1, "off", "local store", undef],
    //]
    { KEPLER_HWPM_SHARED_LOAD,                   kepler_hwpm_shared_load_enc_str_1,              0x0000003a, 0x0000AAAA,    0x48,    PM_UNIT_SMQCTL,1 },
    { KEPLER_HWPM_SHARED_STORE,                  kepler_hwpm_shared_store_enc_str_1,             0x0000003a, 0x0000AAAA,    0x49,    PM_UNIT_SMQCTL,1 },
    { KEPLER_HWPM_GENERIC_LOAD,                  kepler_hwpm_generic_load_enc_str_1,              0x0000003a, 0x0000AAAA,    0x4a,    PM_UNIT_SMQCTL,1 },

    { KEPLER_HWPM_GENERIC_STORE,                 kepler_hwpm_generic_store_enc_str_1,              0x0000003b, 0x0000AAAA,    0x48,    PM_UNIT_SMQCTL,1 },
    { KEPLER_HWPM_LOCAL_LOAD,                    kepler_hwpm_local_load_enc_str_1,               0x0000003b, 0x0000AAAA,    0x49,    PM_UNIT_SMQCTL,1 },
    { KEPLER_HWPM_LOCAL_STORE,                   kepler_hwpm_local_store_enc_str_1,              0x0000003b, 0x0000AAAA,    0x4a,    PM_UNIT_SMQCTL,1 },

    //["BRANCH" =>
    //    ["br_executed",                    1,      "off",  "unique committed branch", undef],
    //    ["diverged_br_executed",           1,      "off",  "unique branches that diverge", undef],
    //]

    // **** SM CORE Signals ****

    //["ACTIVE_WARPS" =>
    //    ["active_cycles",           1,      "on",   "At least 1 active warp",                   undef],
    //    ["active_warps",            6,      "on",   "Number of active warps total in the SM",   undef],
    //],
    { KEPLER_HWPM_ACTIVE_CYCLES,                 kepler_hwpm_active_cycles_enc_str_1,            0x00000002, 0x0000AAAA,     0x29,    PM_UNIT_SMCORE,1 },
    { KEPLER_HWPM_ACTIVE_WARPS,                  kepler_hwpm_active_warps_enc_str_1,             0x00000002, 0x0000FFFF,     0x2a,    PM_UNIT_SMCORE,6 },

    // *** L1C Signals ***

    //
    // FIXME: as per HW manual pri_l1c.ref, event group for L1C signals seems incorrect.
    // for instance LSU_COUNT_0 = 0x0000001a, but it seems 0x00000019 (same as GK104) gives correct value
    //

    //["LSU_TRANSACTIONS_0" =>
    //    ["local_ld_transactions",           1,      "off",   "count instructions at accept point", undef],
    //    ["local_st_transactions",           1,      "off",   "count instructions at accept point", undef],
    //    ["shared_ld_transactions",          1,      "off",   "count instructions at accept point", undef],
    //    ["shared_st_transactions",          1,      "off",   "count instructions at accept point", undef],
    //],
    //["LSU_TRANSACTIONS_1" =>
    //    ["global_ld_transactions",          1,      "off",   "count instructions at accept point", undef],
    //    ["global_st_transactions",          1,      "off",   "count instructions at accept point", undef],
    //],
    { KEPLER_HWPM_L1C_LOCAL_LOAD_TRANSACTIONS,      kepler_hwpm_l1c_local_load_transactions_enc_str_1,   0x00000019, 0x0000AAAA,     0x40,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_LOCAL_STORE_TRANSACTIONS,     kepler_hwpm_l1c_local_store_transactions_enc_str_1,  0x00000019, 0x0000AAAA,     0x41,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_SHARED_LOAD_TRANSACTIONS,     kepler_hwpm_l1c_shared_load_transactions_enc_str_1,  0x00000019, 0x0000AAAA,     0x42,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_SHARED_STORE_TRANSACTIONS,    kepler_hwpm_l1c_shared_store_transactions_enc_str_1, 0x00000019, 0x0000AAAA,     0x43,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_GLOBAL_LOAD_TRANSACTIONS,     kepler_hwpm_l1c_global_load_transactions_enc_str_1,  0x0000001a, 0x0000AAAA,     0x40,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_GLOBAL_STORE_TRANSACTIONS,    kepler_hwpm_l1c_global_store_transactions_enc_str_1, 0x0000001a, 0x0000AAAA,     0x41,    PM_UNIT_L1C,1 },

    //["LSU_COUNT_0" =>
    //    ["l1_shared_ld_count",              1,      "off",   "count instructions at accept point", undef],
    //    ["l1_shared_st_count",              1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_local_ld_hits",         1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_local_ld_misses",       1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_local_st_hits",         1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_local_st_misses",       1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_global_ld_hits",        1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_global_ld_misses",      1,      "off",   "count instructions at accept point", undef],

    { KEPLER_HWPM_L1C_LOCAL_LOAD_HIT,               kepler_hwpm_l1c_local_load_hit_enc_str_1,        0x0000001b, 0x0000AAAA,     0x42,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_LOCAL_LOAD_MISS,              kepler_hwpm_l1c_local_load_miss_enc_str_1,       0x0000001b, 0x0000AAAA,     0x43,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_LOCAL_STORE_HIT,              kepler_hwpm_l1c_local_store_hit_enc_str_1,       0x0000001b, 0x0000AAAA,     0x44,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_LOCAL_STORE_MISS,             kepler_hwpm_l1c_local_store_miss_enc_str_1,      0x0000001b, 0x0000AAAA,     0x45,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_GLOBAL_LOAD_HIT,              kepler_hwpm_l1c_global_load_hit_enc_str_1,       0x0000001b, 0x0000AAAA,     0x46,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_GLOBAL_LOAD_MISS,             kepler_hwpm_l1c_global_load_miss_enc_str_1,      0x0000001b, 0x0000AAAA,     0x47,    PM_UNIT_L1C,1 },

    // TBD: please cross check if signals below are correct??
    //["LSU_COUNT_1" =>
    //    ["l1_uncached_global_ld_count",     1,      "off",   "count instructions at accept point", undef],
    //    ["l1_global_st_count",              1,      "off",   "count instructions at accept point", undef],
    //],
    { KEPLER_HWPM_L1C_UNCACHED_GLOBAL_LOAD,         kepler_hwpm_l1c_uncached_global_load_enc_str_1,  0x0000001c, 0x0000AAAA,     0x40,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_GLOBAL_STORE,                 kepler_hwpm_l1c_global_store_enc_str_1,          0x0000001c, 0x0000AAAA,     0x41,    PM_UNIT_L1C,1 },

    //["TOQ_1" =>
    //    ["shared_ld_mem_divergence_replays",   1,      "off",   "shared ld is replayed due to bank conflict", undef],
    //    ["shared_st_mem_divergence_replays",   1,      "off",   "shared st is replayed due to bank conflict", undef],
    //],
    { KEPLER_HWPM_L1C_SHARED_LOAD_BANK_CONFLICT,    kepler_hwpm_l1c_shared_load_bank_conflict_enc_str_1,    0x00000008, 0x0000AAAA,     0x42,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_SHARED_STORE_BANK_CONFLICT,   kepler_hwpm_l1c_shared_store_bank_conflict_enc_str_1,   0x00000008, 0x0000AAAA,     0x43,    PM_UNIT_L1C,1 },
#endif

    //Tex signals
    // based on experiments - tex_cache_misses_gpc0_tpc0_tex0 and tex_cache_sector_queries_gpc0_tpc0_tex0
    // defined in \\hw\tools\perfalyze\chips\gk208\pml_files\tex.pml

    { KEPLER_TEX0_CACHE_SECTOR_QUERIES,   kepler_tex0_cache_sector_queries_enc_str_1,  0x00000005, 0x0000FFFF, 0x00000010,    PM_UNIT_TEX_M,5, 0x00000003},
    { KEPLER_TEX1_CACHE_SECTOR_QUERIES,   kepler_tex1_cache_sector_queries_enc_str_1,  0x00000005, 0x0000FFFF, 0x00000010,    PM_UNIT_TEX_M,5, 0x00000004},

    { KEPLER_TEX0_CACHE_SECTOR_MISSES,    kepler_tex0_cache_sector_misses_enc_str_1,   0x00000004, 0x0000FFFF, 0x0000000c,    PM_UNIT_TEX_M,5, 0x00000003},
    { KEPLER_TEX1_CACHE_SECTOR_MISSES,    kepler_tex1_cache_sector_misses_enc_str_1,   0x00000004, 0x0000FFFF, 0x0000000c,    PM_UNIT_TEX_M,5, 0x00000004},

    { KEPLER_TEX0_GPC_T_LDG_CT_GRP5, kepler_tex0_gpc_t_ldg_ct_grp5_enc_str_1, 0x5, 0xaaaa, 0x15, PM_UNIT_TEX_M, 1, 3},
    { KEPLER_TEX1_GPC_T_LDG_CT_GRP5, kepler_tex1_gpc_t_ldg_ct_grp5_enc_str_1, 0x5, 0xaaaa, 0x15, PM_UNIT_TEX_M, 1, 4},

    { KEPLER_TEX0_GPC_T_LDG_CT_GRP4, kepler_tex0_gpc_t_ldg_ct_grp4_enc_str_1, 0x4, 0xaaaa, 0x15, PM_UNIT_TEX_M, 1, 3},
    { KEPLER_TEX1_GPC_T_LDG_CT_GRP4, kepler_tex1_gpc_t_ldg_ct_grp4_enc_str_1, 0x4, 0xaaaa, 0x15, PM_UNIT_TEX_M, 1, 4},

    //LDG signals
    // based on experiments - tex0_02pm_gpc_tm_samp_ldg_32_warp_executed, tex0_02pm_gpc_tm_samp_ldg_64_warp_executed, tex0_02pm_gpc_tm_samp_ldg_128_warp_executed
    // defined in \\hw\tools\perfalyze\chips\gk208\pml_files\tex.pml
    //ldg_32_warp_executed : the LDG equivalent of global_ld_32_executed; counts total 8-bit, 16-bit, and 32-bit LDG requests (one increment per warp)
    //ldg_64_warp_executed : the LDG equivalent of global_ld_64_executed; counts total 64-bit LDG requests (one increment per warp)
    //ldg_128_warp_executed : the LDG equivalent of global_ld_executed; counts total 128-bit LDG requests (one increment per warp)

    { TEX0_LDG_WARP_COUNT_32B,              tex0_ldg_warp_count_32b_enc_str_1,   0x0000003a, 0x0000aaaa, 0x00000019,    PM_UNIT_TEX_S,1, 0x00000000},
    { TEX1_LDG_WARP_COUNT_32B,              tex1_ldg_warp_count_32b_enc_str_1,   0x0000003a, 0x0000aaaa, 0x00000019,    PM_UNIT_TEX_S,1, 0x00000001},

    { TEX0_LDG_WARP_COUNT_64B,              tex0_ldg_warp_count_64b_enc_str_1,   0x0000003b, 0x0000aaaa, 0x00000019,    PM_UNIT_TEX_S,1, 0x00000000},
    { TEX1_LDG_WARP_COUNT_64B,              tex1_ldg_warp_count_64b_enc_str_1,   0x0000003b, 0x0000aaaa, 0x00000019,    PM_UNIT_TEX_S,1, 0x00000001},

    { TEX0_LDG_WARP_COUNT_128B,              tex0_ldg_warp_count_128b_enc_str_1,   0x0000003c, 0x0000aaaa, 0x00000019,    PM_UNIT_TEX_S,1, 0x00000000},
    { TEX1_LDG_WARP_COUNT_128B,              tex1_ldg_warp_count_128b_enc_str_1,   0x0000003c, 0x0000aaaa, 0x00000019,    PM_UNIT_TEX_S,1, 0x00000001},

    //LDG signals
    // defined in \\hw\tools\perfalyze\chips\gk208\pml_files\tex.pml

    // based on experiments - tex0_02pm_gpc_tm_samp_ldg_32_thread_executed, tex0_02pm_gpc_tm_samp_ldg_64_thread_executed, tex0_02pm_gpc_tm_samp_ldg_128_thread_executed
    //ldg_32_thread_executed : counts total 8-bit, 16-bit, and 32-bit LDG requests (per thread)
    //ldg_64_thread_executed : counts total 64-bit LDG requests (per thread)
    //ldg_128_thread_executed : counts total 128-bit LDG requests (per thread)
    { TEX0_LDG_THREAD_COUNT_32B,          tex0_ldg_thread_count_32b_enc_str_1,   0x0000003a, 0x0000FFFF, 0x00000016,    PM_UNIT_TEX_S,3, 0x00000000},
    { TEX1_LDG_THREAD_COUNT_32B,          tex1_ldg_thread_count_32b_enc_str_1,   0x0000003a, 0x0000FFFF, 0x00000016,    PM_UNIT_TEX_S,3, 0x00000001},

    { TEX0_LDG_THREAD_COUNT_64B,          tex0_ldg_thread_count_64b_enc_str_1,   0x0000003b, 0x0000FFFF, 0x00000016,    PM_UNIT_TEX_S,3, 0x00000000},
    { TEX1_LDG_THREAD_COUNT_64B,          tex1_ldg_thread_count_64b_enc_str_1,   0x0000003b, 0x0000FFFF, 0x00000016,    PM_UNIT_TEX_S,3, 0x00000001},

    { TEX0_LDG_THREAD_COUNT_128B,          tex0_ldg_thread_count_128b_enc_str_1, 0x0000003c, 0x0000FFFF, 0x00000016,    PM_UNIT_TEX_S,3, 0x00000000},
    { TEX1_LDG_THREAD_COUNT_128B,          tex1_ldg_thread_count_128b_enc_str_1, 0x0000003c, 0x0000FFFF, 0x00000016,    PM_UNIT_TEX_S,3, 0x00000001},

    { KEPLER_ELAPSED_CYCLES_SM,              kepler_elapsed_cycles_sm_enc_str_1,             0x00000000, 0x00000000, 0x00000000,    PM_UNIT_SMCORE,0},
    { KEPLER_L1C_PRT_PENDING_ENTRIES,        kepler_l1c_prt_pending_entries_enc_str_1,   0xe, 0xffff, 0x40, PM_UNIT_L1C, 7},
    { KEPLER_L1C_PRT_ENTRIES_INUSE,          kepler_l1c_prt_entries_inuse_enc_str_1,     0xf, 0xffff, 0x40, PM_UNIT_L1C, 7},
    { KEPLER_L1C_PRT_ENTRIES_USABLE,         kepler_l1c_prt_entries_usable_enc_str_1,    0x10, 0xffff, 0x40, PM_UNIT_L1C, 7},

    { KEPLER_TEX0_BANK_CONFLICTS,    kepler_tex0_bank_conflicts_enc_str_1,   0x00000006, 0x0000aaaa, 0x1c,    PM_UNIT_TEX_D,1, 0x00000000},
    { KEPLER_TEX1_BANK_CONFLICTS,    kepler_tex1_bank_conflicts_enc_str_1,   0x00000006, 0x0000aaaa, 0x1c,    PM_UNIT_TEX_D,1, 0x00000001},

    {KEPLER_TEX0_TEX2SM_TEX_PRDY, kepler_tex0_tex2sm_tex_prdy_enc_str_1, 0x3, 0xaaaa, 0x1e, PM_UNIT_TEX_D, 1, 0},
    {KEPLER_TEX1_TEX2SM_TEX_PRDY, kepler_tex1_tex2sm_tex_prdy_enc_str_1, 0x3, 0xaaaa, 0x1e, PM_UNIT_TEX_D, 1, 1},
    {KEPLER_TEX0_TEX2SM_TEX_PVLD, kepler_tex0_tex2sm_tex_pvld_enc_str_1, 0x3, 0xaaaa, 0x1d, PM_UNIT_TEX_D, 1, 0},
    {KEPLER_TEX1_TEX2SM_TEX_PVLD, kepler_tex1_tex2sm_tex_pvld_enc_str_1, 0x3, 0xaaaa, 0x1d, PM_UNIT_TEX_D, 1, 1},

    { INVALID_PM_SIGNAL_NEW,             "",                             0xffffffff, 0x00000000,     0x00,        PM_UNIT_MAX,0 }
};

PerfSignalHwpmExpt PerfSignalTableGK208_gpctpc_expt[] = {
    { KEPLER_TEX0_RETURN_PACKET_COUNT,    kepler_tex0_return_packet_count_enc_str_1,   INVALID_PM_SIGNAL_NEW, {KEPLER_TEX0_TEX2SM_TEX_PRDY, KEPLER_TEX0_TEX2SM_TEX_PVLD, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_TEX1_RETURN_PACKET_COUNT,    kepler_tex1_return_packet_count_enc_str_1,   INVALID_PM_SIGNAL_NEW, {KEPLER_TEX1_TEX2SM_TEX_PRDY, KEPLER_TEX1_TEX2SM_TEX_PVLD, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},

    { KEPLER_TEX0_LG_SECTOR_QUERIES, kepler_tex0_lg_sector_queries_enc_str_1, KEPLER_TEX0_CACHE_SECTOR_QUERIES, {KEPLER_TEX0_GPC_T_LDG_CT_GRP5, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { KEPLER_TEX1_LG_SECTOR_QUERIES, kepler_tex1_lg_sector_queries_enc_str_1, KEPLER_TEX1_CACHE_SECTOR_QUERIES, {KEPLER_TEX1_GPC_T_LDG_CT_GRP5, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},

    { KEPLER_TEX0_LG_MISSED_SECTORS, kepler_tex0_lg_missed_sectors_enc_str_1, KEPLER_TEX0_CACHE_SECTOR_MISSES, {KEPLER_TEX0_GPC_T_LDG_CT_GRP4, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},
    { KEPLER_TEX1_LG_MISSED_SECTORS, kepler_tex1_lg_missed_sectors_enc_str_1, KEPLER_TEX1_CACHE_SECTOR_MISSES, {KEPLER_TEX1_GPC_T_LDG_CT_GRP4, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), 0},

    { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000,  0x00},
};

PerfSignalHwpm PerfSignalTableGK20A_gpctpc[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type

    { KEPLER_HWPM_THREADS_LAUNCHED,              kepler_hwpm_threads_launched_enc_str_1,         0x00000002, 0x0000FFFF,  0x49,    PM_UNIT_SMQCTL,6 },
    { KEPLER_HWPM_CTA_LAUNCHED,                  kepler_hwpm_cta_launched_enc_str_1,             0x00000007, 0x0000AAAA,  0x2b,    PM_UNIT_SMCORE,1 },
#if CU_PROFILE_SM_SIGNALS_VIA_HWPM
    // **** SM QUAD Signals ****

    //["LAUNCHED" =>
    //    ["warps_launched",          1,      "on",   "If a warp was launched this cycle in this quad",       undef],
    //    ["threads_launched",        6,      "on",   "Number of threads launched this cycle in this quad",   undef],
    //],
    { KEPLER_HWPM_WARPS_LAUNCHED,                kepler_hwpm_warps_launched_enc_str_1,           0x00000002, 0x0000AAAA,  0x48,    PM_UNIT_SMQCTL,1 },

    //["INST_ISSUE_EXECUTED_IPC" =>
    //    ["active_cycles",           1,      "on",   "At least 1 active warp in the quad",      undef],
    //    ["inst_issued0",            1,      "on",   "# of cycles issued 0 instructions",       undef],
    //    ["inst_issued1",            1,      "on",   "# of cycles issued 1 instructions",       undef],
    //    ["inst_issued2",            1,      "on",   "# of cycles issued 2 instructions",       undef],
    //    ["active_cycles_2",         1,      "on",   "At least 1 active warp in the quad",      undef],
    //    ["inst_executed",           2,      "on",   "# of instructions executed",              undef],
    //]
    { KEPLER_HWPM_INST_ISSUED_1,                 kepler_hwpm_inst_issued_1_enc_str_1,            0x00000004, 0x0000AAAA,  0x4a,    PM_UNIT_SMQCTL,1 },
    { KEPLER_HWPM_INST_ISSUED_2,                 kepler_hwpm_inst_issued_2_enc_str_1,            0x00000004, 0x0000AAAA,  0x4b,    PM_UNIT_SMQCTL,1 },
    { KEPLER_HWPM_INST_EXECUTED,                 kepler_hwpm_inst_executed_enc_str_1,            0x00000004, 0x0000FFFF,  0x4d,    PM_UNIT_SMQCTL,2 },

    //["THREAD_INST_EXECUTED" =>
    //    ["thread_inst_executed",    6,      "on",   "Number of thread instruction executed this cycle in this quad",   undef],
    //],
    { KEPLER_HWPM_THREAD_INST_EXECUTED,          kepler_hwpm_thread_inst_executed_enc_str_1,     0x0000001d, 0x0000FFFF,  0x48,    PM_UNIT_SMQCTL,6 },

    //["LSU_INST_COUNT_1" =>
    //    ["inst_executed_lsu_lds", 1, "off", "shared load ", undef],
    //    ["inst_executed_lsu_sts", 1, "off", "shared store ", undef],
    //    ["inst_executed_lsu_ld", 1, "off", "generic load", undef],
    //]
    //["LSU_INST_COUNT_2" =>
    //    ["inst_executed_lsu_st", 1, "off", "generic store", undef],
    //    ["inst_executed_lsu_ldl", 1, "off", "local load", undef],
    //    ["inst_executed_lsu_stl", 1, "off", "local store", undef],
    //]
    { KEPLER_HWPM_SHARED_LOAD,                   kepler_hwpm_shared_load_enc_str_1,              0x0000003a, 0x0000AAAA,    0x48,    PM_UNIT_SMQCTL,1 },
    { KEPLER_HWPM_SHARED_STORE,                  kepler_hwpm_shared_store_enc_str_1,             0x0000003a, 0x0000AAAA,    0x49,    PM_UNIT_SMQCTL,1 },
    { KEPLER_HWPM_GENERIC_LOAD,                  kepler_hwpm_generic_load_enc_str_1,              0x0000003a, 0x0000AAAA,    0x4a,    PM_UNIT_SMQCTL,1 },

    { KEPLER_HWPM_GENERIC_STORE,                 kepler_hwpm_generic_store_enc_str_1,              0x0000003b, 0x0000AAAA,    0x48,    PM_UNIT_SMQCTL,1 },
    { KEPLER_HWPM_LOCAL_LOAD,                    kepler_hwpm_local_load_enc_str_1,               0x0000003b, 0x0000AAAA,    0x49,    PM_UNIT_SMQCTL,1 },
    { KEPLER_HWPM_LOCAL_STORE,                   kepler_hwpm_local_store_enc_str_1,              0x0000003b, 0x0000AAAA,    0x4a,    PM_UNIT_SMQCTL,1 },

    //["BRANCH" =>
    //    ["br_executed",                    1,      "off",  "unique committed branch", undef],
    //    ["diverged_br_executed",           1,      "off",  "unique branches that diverge", undef],
    //]

    // **** SM CORE Signals ****

    //["ACTIVE_WARPS" =>
    //    ["active_cycles",           1,      "on",   "At least 1 active warp",                   undef],
    //    ["active_warps",            6,      "on",   "Number of active warps total in the SM",   undef],
    //],
    { KEPLER_HWPM_ACTIVE_CYCLES,                 kepler_hwpm_active_cycles_enc_str_1,            0x00000002, 0x0000AAAA,     0x29,    PM_UNIT_SMCORE,1 },
    { KEPLER_HWPM_ACTIVE_WARPS,                  kepler_hwpm_active_warps_enc_str_1,             0x00000002, 0x0000FFFF,     0x2a,    PM_UNIT_SMCORE,6 },

    // *** L1C Signals ***

    //
    // FIXME: as per HW manual pri_l1c.ref, event group for L1C signals seems incorrect.
    // for instance LSU_COUNT_0 = 0x0000001a, but it seems 0x00000019 (same as GK104) gives correct value
    //

    //["LSU_TRANSACTIONS_0" =>
    //    ["local_ld_transactions",           1,      "off",   "count instructions at accept point", undef],
    //    ["local_st_transactions",           1,      "off",   "count instructions at accept point", undef],
    //    ["shared_ld_transactions",          1,      "off",   "count instructions at accept point", undef],
    //    ["shared_st_transactions",          1,      "off",   "count instructions at accept point", undef],
    //],
    //["LSU_TRANSACTIONS_1" =>
    //    ["global_ld_transactions",          1,      "off",   "count instructions at accept point", undef],
    //    ["global_st_transactions",          1,      "off",   "count instructions at accept point", undef],
    //],
    { KEPLER_HWPM_L1C_LOCAL_LOAD_TRANSACTIONS,      kepler_hwpm_l1c_local_load_transactions_enc_str_1,   0x00000019, 0x0000AAAA,     0x40,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_LOCAL_STORE_TRANSACTIONS,     kepler_hwpm_l1c_local_store_transactions_enc_str_1,  0x00000019, 0x0000AAAA,     0x41,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_SHARED_LOAD_TRANSACTIONS,     kepler_hwpm_l1c_shared_load_transactions_enc_str_1,  0x00000019, 0x0000AAAA,     0x42,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_SHARED_STORE_TRANSACTIONS,    kepler_hwpm_l1c_shared_store_transactions_enc_str_1, 0x00000019, 0x0000AAAA,     0x43,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_GLOBAL_LOAD_TRANSACTIONS,     kepler_hwpm_l1c_global_load_transactions_enc_str_1,  0x0000001a, 0x0000AAAA,     0x40,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_GLOBAL_STORE_TRANSACTIONS,    kepler_hwpm_l1c_global_store_transactions_enc_str_1, 0x0000001a, 0x0000AAAA,     0x41,    PM_UNIT_L1C,1 },

    //["LSU_COUNT_0" =>
    //    ["l1_shared_ld_count",              1,      "off",   "count instructions at accept point", undef],
    //    ["l1_shared_st_count",              1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_local_ld_hits",         1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_local_ld_misses",       1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_local_st_hits",         1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_local_st_misses",       1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_global_ld_hits",        1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_global_ld_misses",      1,      "off",   "count instructions at accept point", undef],

    { KEPLER_HWPM_L1C_LOCAL_LOAD_HIT,               kepler_hwpm_l1c_local_load_hit_enc_str_1,        0x0000001b, 0x0000AAAA,     0x42,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_LOCAL_LOAD_MISS,              kepler_hwpm_l1c_local_load_miss_enc_str_1,       0x0000001b, 0x0000AAAA,     0x43,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_LOCAL_STORE_HIT,              kepler_hwpm_l1c_local_store_hit_enc_str_1,       0x0000001b, 0x0000AAAA,     0x44,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_LOCAL_STORE_MISS,             kepler_hwpm_l1c_local_store_miss_enc_str_1,      0x0000001b, 0x0000AAAA,     0x45,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_GLOBAL_LOAD_HIT,              kepler_hwpm_l1c_global_load_hit_enc_str_1,       0x0000001b, 0x0000AAAA,     0x46,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_GLOBAL_LOAD_MISS,             kepler_hwpm_l1c_global_load_miss_enc_str_1,      0x0000001b, 0x0000AAAA,     0x47,    PM_UNIT_L1C,1 },

    // TBD: please cross check if signals below are correct??
    //["LSU_COUNT_1" =>
    //    ["l1_uncached_global_ld_count",     1,      "off",   "count instructions at accept point", undef],
    //    ["l1_global_st_count",              1,      "off",   "count instructions at accept point", undef],
    //],
    { KEPLER_HWPM_L1C_UNCACHED_GLOBAL_LOAD,         kepler_hwpm_l1c_uncached_global_load_enc_str_1,  0x0000001c, 0x0000AAAA,     0x40,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_GLOBAL_STORE,                 kepler_hwpm_l1c_global_store_enc_str_1,          0x0000001c, 0x0000AAAA,     0x41,    PM_UNIT_L1C,1 },

    //["TOQ_1" =>
    //    ["shared_ld_mem_divergence_replays",   1,      "off",   "shared ld is replayed due to bank conflict", undef],
    //    ["shared_st_mem_divergence_replays",   1,      "off",   "shared st is replayed due to bank conflict", undef],
    //],
    { KEPLER_HWPM_L1C_SHARED_LOAD_BANK_CONFLICT,    kepler_hwpm_l1c_shared_load_bank_conflict_enc_str_1,    0x00000008, 0x0000AAAA,     0x42,    PM_UNIT_L1C,1 },
    { KEPLER_HWPM_L1C_SHARED_STORE_BANK_CONFLICT,   kepler_hwpm_l1c_shared_store_bank_conflict_enc_str_1,   0x00000008, 0x0000AAAA,     0x43,    PM_UNIT_L1C,1 },
#endif

    //Tex signals
    // based on experiments - tex_cache_misses_gpc0_tpc0_tex0 and tex_cache_sector_queries_gpc0_tpc0_tex0
    // defined in \\hw\tools\perfalyze\chips\gk208\pml_files\tex.pml

    { KEPLER_TEX0_CACHE_SECTOR_QUERIES,   kepler_tex0_cache_sector_queries_enc_str_1,  0x00000005, 0x0000FFFF, 0x00000010,    PM_UNIT_TEX_M,5, 0x00000003},
    { KEPLER_TEX1_CACHE_SECTOR_QUERIES,   kepler_tex1_cache_sector_queries_enc_str_1,  0x00000005, 0x0000FFFF, 0x00000010,    PM_UNIT_TEX_M,5, 0x00000004},

    { KEPLER_TEX0_CACHE_SECTOR_MISSES,    kepler_tex0_cache_sector_misses_enc_str_1,   0x00000004, 0x0000FFFF, 0x0000000c,    PM_UNIT_TEX_M,5, 0x00000003},
    { KEPLER_TEX1_CACHE_SECTOR_MISSES,    kepler_tex1_cache_sector_misses_enc_str_1,   0x00000004, 0x0000FFFF, 0x0000000c,    PM_UNIT_TEX_M,5, 0x00000004},

    { KEPLER_TEX0_GPC_T_LDG_CT_GRP5, kepler_tex0_gpc_t_ldg_ct_grp5_enc_str_1, 0x5, 0xaaaa, 0x15, PM_UNIT_TEX_M, 1, 3},
    { KEPLER_TEX1_GPC_T_LDG_CT_GRP5, kepler_tex1_gpc_t_ldg_ct_grp5_enc_str_1, 0x5, 0xaaaa, 0x15, PM_UNIT_TEX_M, 1, 4},

    { KEPLER_TEX0_GPC_T_LDG_CT_GRP4, kepler_tex0_gpc_t_ldg_ct_grp4_enc_str_1, 0x4, 0xaaaa, 0x15, PM_UNIT_TEX_M, 1, 3},
    { KEPLER_TEX1_GPC_T_LDG_CT_GRP4, kepler_tex1_gpc_t_ldg_ct_grp4_enc_str_1, 0x4, 0xaaaa, 0x15, PM_UNIT_TEX_M, 1, 4},

    //LDG signals
    // based on experiments - tex0_02pm_gpc_tm_samp_ldg_32_warp_executed, tex0_02pm_gpc_tm_samp_ldg_64_warp_executed, tex0_02pm_gpc_tm_samp_ldg_128_warp_executed
    // defined in \\hw\tools\perfalyze\chips\gk208\pml_files\tex.pml
    //ldg_32_warp_executed : the LDG equivalent of global_ld_32_executed; counts total 8-bit, 16-bit, and 32-bit LDG requests (one increment per warp)
    //ldg_64_warp_executed : the LDG equivalent of global_ld_64_executed; counts total 64-bit LDG requests (one increment per warp)
    //ldg_128_warp_executed : the LDG equivalent of global_ld_executed; counts total 128-bit LDG requests (one increment per warp)

    {TEX0_LDG_WARP_COUNT_128B, tex0_ldg_warp_count_128b_enc_str_1, 0x3c, 0xaaaa, 0x3d, PM_UNIT_TEX_S, 1, 0},
    {TEX0_LDG_WARP_COUNT_32B, tex0_ldg_warp_count_32b_enc_str_1, 0x3a, 0xaaaa, 0x3d, PM_UNIT_TEX_S, 1, 0},
    {TEX0_LDG_WARP_COUNT_64B, tex0_ldg_warp_count_64b_enc_str_1, 0x3b, 0xaaaa, 0x3d, PM_UNIT_TEX_S, 1, 0},
    {TEX1_LDG_WARP_COUNT_128B, tex1_ldg_warp_count_128b_enc_str_1, 0x3c, 0xaaaa, 0x3d, PM_UNIT_TEX_S, 1, 1},
    {TEX1_LDG_WARP_COUNT_32B, tex1_ldg_warp_count_32b_enc_str_1, 0x3a, 0xaaaa, 0x3d, PM_UNIT_TEX_S, 1, 1},
    {TEX1_LDG_WARP_COUNT_64B, tex1_ldg_warp_count_64b_enc_str_1, 0x3b, 0xaaaa, 0x3d, PM_UNIT_TEX_S, 1, 1},

    //LDG signals
    // defined in \\hw\tools\perfalyze\chips\gk208\pml_files\tex.pml

    // based on experiments - tex0_02pm_gpc_tm_samp_ldg_32_thread_executed, tex0_02pm_gpc_tm_samp_ldg_64_thread_executed, tex0_02pm_gpc_tm_samp_ldg_128_thread_executed
    //ldg_32_thread_executed : counts total 8-bit, 16-bit, and 32-bit LDG requests (per thread)
    //ldg_64_thread_executed : counts total 64-bit LDG requests (per thread)
    //ldg_128_thread_executed : counts total 128-bit LDG requests (per thread)

    {TEX0_LDG_THREAD_COUNT_128B, tex0_ldg_thread_count_128b_enc_str_1, 0x3c, 0xffff, 0x3a, PM_UNIT_TEX_S, 3, 0},
    {TEX0_LDG_THREAD_COUNT_32B, tex0_ldg_thread_count_32b_enc_str_1, 0x3a, 0xffff, 0x3a, PM_UNIT_TEX_S, 3, 0},
    {TEX0_LDG_THREAD_COUNT_64B, tex0_ldg_thread_count_64b_enc_str_1, 0x3b, 0xffff, 0x3a, PM_UNIT_TEX_S, 3, 0},
    {TEX1_LDG_THREAD_COUNT_128B, tex1_ldg_thread_count_128b_enc_str_1, 0x3c, 0xffff, 0x3a, PM_UNIT_TEX_S, 3, 1},
    {TEX1_LDG_THREAD_COUNT_32B, tex1_ldg_thread_count_32b_enc_str_1, 0x3a, 0xffff, 0x3a, PM_UNIT_TEX_S, 3, 1},
    {TEX1_LDG_THREAD_COUNT_64B, tex1_ldg_thread_count_64b_enc_str_1, 0x3b, 0xffff, 0x3a, PM_UNIT_TEX_S, 3, 1},

    { KEPLER_ELAPSED_CYCLES_SM,              kepler_elapsed_cycles_sm_enc_str_1,             0x00000000, 0x00000000, 0x00000000,    PM_UNIT_SMCORE,0},
    { KEPLER_L1C_PRT_PENDING_ENTRIES,        kepler_l1c_prt_pending_entries_enc_str_1,   0xe, 0xffff, 0x40, PM_UNIT_L1C, 7},
    { KEPLER_L1C_PRT_ENTRIES_INUSE,          kepler_l1c_prt_entries_inuse_enc_str_1,     0xf, 0xffff, 0x40, PM_UNIT_L1C, 7},
    { KEPLER_L1C_PRT_ENTRIES_USABLE,         kepler_l1c_prt_entries_usable_enc_str_1,    0x10, 0xffff, 0x40, PM_UNIT_L1C, 7},

    { KEPLER_TEX0_BANK_CONFLICTS,    kepler_tex0_bank_conflicts_enc_str_1,   0x00000006, 0x0000aaaa, 0x17,    PM_UNIT_TEX_D,1, 0x00000000},
    { KEPLER_TEX1_BANK_CONFLICTS,    kepler_tex1_bank_conflicts_enc_str_1,   0x00000006, 0x0000aaaa, 0x17,    PM_UNIT_TEX_D,1, 0x00000001},

    {KEPLER_TEX0_TEX2SM_TEX_PRDY, kepler_tex0_tex2sm_tex_prdy_enc_str_1, 0x3, 0xaaaa, 0x19, PM_UNIT_TEX_D, 1, 0},
    {KEPLER_TEX1_TEX2SM_TEX_PRDY, kepler_tex1_tex2sm_tex_prdy_enc_str_1, 0x3, 0xaaaa, 0x19, PM_UNIT_TEX_D, 1, 1},
    {KEPLER_TEX0_TEX2SM_TEX_PVLD, kepler_tex0_tex2sm_tex_pvld_enc_str_1, 0x3, 0xaaaa, 0x18, PM_UNIT_TEX_D, 1, 0},
    {KEPLER_TEX1_TEX2SM_TEX_PVLD, kepler_tex1_tex2sm_tex_pvld_enc_str_1, 0x3, 0xaaaa, 0x18, PM_UNIT_TEX_D, 1, 1},

    { INVALID_PM_SIGNAL_NEW,             "",                             0xffffffff, 0x00000000,     0x00,        PM_UNIT_MAX,0 }
};

PerfSignalHwpm PerfSignalTableGK208_ltc0[] = {
    //FBP signals
    { KEPLER_FB_SUBP0_DRAMC_READ,          kepler_fb_subp0_dramc_read_enc_str_1,            0x00000011, 0x0000AAAA,  0x00000000,   PM_UNIT_FB,1 },
    { KEPLER_FB_SUBP1_DRAMC_READ,          kepler_fb_subp1_dramc_read_enc_str_1,            0x00000012, 0x0000AAAA,  0x00000000,   PM_UNIT_FB,1 },
    { KEPLER_FB_SUBP0_DRAMC_WRITE,         kepler_fb_subp0_dramc_write_enc_str_1,           0x00000011, 0x0000AAAA,  0x00000001,   PM_UNIT_FB,1 },
    { KEPLER_FB_SUBP1_DRAMC_WRITE,         kepler_fb_subp1_dramc_write_enc_str_1,           0x00000012, 0x0000AAAA,  0x00000001,   PM_UNIT_FB,1 },

    // fb_dram_activates_subp0_fbp0_pa0       = fbpa02pm_subp0_actarb_activate      "Number of bank activates in subpartition-0"
    // fb_dram_activates_subp1_fbp0_pa0       = fbpa02pm_subp1_actarb_activate      "Number of bank activates in subpartition-1"
    { KEPLER_FB_SUBP0_DRAM_ACTIVATES,      kepler_fb_subp0_dram_activates_enc_str_1,             0x00000001, 0x0000AAAA,  0x00000006,   PM_UNIT_FB,1 },
    { KEPLER_FB_SUBP1_DRAM_ACTIVATES,      kepler_fb_subp1_dram_activates_enc_str_1,             0x00000002, 0x0000AAAA,  0x00000006,   PM_UNIT_FB,1 },

    //LTC signals
    // l2_subp0_write_sector_misses = ltc_ltc2fb_dirty_dat0_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 0
    // l2_subp1_write_sector_misses = ltc_ltc2fb_dirty_dat1_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 1
    // l2_subp0_read_sector_misses  = ltc_fb2ltc_rdat0_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 0
    // l2_subp1_read_sector_misses  = ltc_fb2ltc_rdat1_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 1
    // l2_subp0_write_l1_sector_queries = ltc2pm_ltc_lts0_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 0
    // l2_subp1_write_l1_sector_queries = ltc2pm_ltc_lts1_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 1
    // l2_subp0_read_l1_sector_queries  = ltc2pm_ltc_lts0_request_rd_op && ltc2pm_ltc_lts1_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 0
    // l2_subp1_read_l1_sector_queries  = ltc2pm_ltc_lts1_request_rd_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 1

    { KEPLER_LTC0_WRITE_MISS_SECTORS,      kepler_ltc0_write_miss_sectors_enc_str_1,     0x00000006, 0x0000AAAA,  0x15,    PM_UNIT_LTC1,1, 0},
    { KEPLER_LTC1_WRITE_MISS_SECTORS,      kepler_ltc1_write_miss_sectors_enc_str_1,     0x00000006, 0x0000AAAA,  0x15,    PM_UNIT_LTC1,1, 1},
    { KEPLER_LTC0_READ_MISS_SECTORS,       kepler_ltc0_read_miss_sectors_enc_str_1,      0x00000006, 0x0000AAAA,  0x16,    PM_UNIT_LTC1,1, 0},
    { KEPLER_LTC1_READ_MISS_SECTORS,       kepler_ltc1_read_miss_sectors_enc_str_1,      0x00000006, 0x0000AAAA,  0x16,    PM_UNIT_LTC1,1, 1},

    {KEPLER_LTC0_HIT_SECTORS, kepler_ltc0_hit_sectors_enc_str_1, 0x1, 0xffff, 0xc, PM_UNIT_LTC, 4, 0},
    {KEPLER_LTC1_HIT_SECTORS, kepler_ltc1_hit_sectors_enc_str_1, 0x1, 0xffff, 0xc, PM_UNIT_LTC, 4, 1},
    {KEPLER_LTC0_REQUEST_SECTORS, kepler_ltc0_request_sectors_enc_str_1, 0x0, 0xffff, 0xc, PM_UNIT_LTC, 4, 0},
    {KEPLER_LTC1_REQUEST_SECTORS, kepler_ltc1_request_sectors_enc_str_1, 0x0, 0xffff, 0xc, PM_UNIT_LTC, 4, 1},
    {KEPLER_LTC0_REQUEST_SRC_UNIT_TEX, kepler_ltc0_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 0},
    {KEPLER_LTC1_REQUEST_SRC_UNIT_TEX, kepler_ltc1_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 1},
    {KEPLER_LTC0_REQUEST_SRC_UNIT_L1, kepler_ltc0_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 0},
    {KEPLER_LTC1_REQUEST_SRC_UNIT_L1, kepler_ltc1_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 1},
    {KEPLER_LTC0_REQUEST_SRC_UNIT_GCC, kepler_ltc0_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 0},
    {KEPLER_LTC1_REQUEST_SRC_UNIT_GCC, kepler_ltc1_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x10, PM_UNIT_LTC2, 1, 1},
    {KEPLER_LTC0_REQUEST_ACTIVE, kepler_ltc0_request_active_enc_str_1, 0x0, 0xaaaa, 0x12, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_REQUEST_ACTIVE, kepler_ltc1_request_active_enc_str_1, 0x0, 0xaaaa, 0x12, PM_UNIT_LTC1, 1, 1},
    {KEPLER_LTC0_REQUEST_RD_OP, kepler_ltc0_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x25, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_REQUEST_RD_OP, kepler_ltc1_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x25, PM_UNIT_LTC1, 1, 1},
    {KEPLER_LTC0_REQUEST_WR_OP, kepler_ltc0_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x24, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_REQUEST_WR_OP, kepler_ltc1_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x24, PM_UNIT_LTC1, 1, 1},
    {KEPLER_LTC0_REQUEST_ATOMIC_OP, kepler_ltc0_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x23, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_REQUEST_ATOMIC_OP, kepler_ltc1_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x23, PM_UNIT_LTC1, 1, 1},
    {KEPLER_LTC0_REQUEST_APERTURE_SYSMEM, kepler_ltc0_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x1f, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_REQUEST_APERTURE_SYSMEM, kepler_ltc1_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x1f, PM_UNIT_LTC1, 1, 1},
    {KEPLER_LTC0_REQUEST_APERTURE_VIDMEM, kepler_ltc0_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x1e, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_REQUEST_APERTURE_VIDMEM, kepler_ltc1_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x1e, PM_UNIT_LTC1, 1, 1},
    {KEPLER_LTC0_HIT, kepler_ltc0_hit_enc_str_1, 0x0, 0xaaaa, 0x19, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_HIT, kepler_ltc1_hit_enc_str_1, 0x0, 0xaaaa, 0x19, PM_UNIT_LTC1, 1, 1},
    {KEPLER_LTC0_REQUEST, kepler_ltc0_request_enc_str_1, 0x0, 0xaaaa, 0x11, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC1_REQUEST, kepler_ltc1_request_enc_str_1, 0x0, 0xaaaa, 0x11, PM_UNIT_LTC1, 1, 1},

    { INVALID_PM_SIGNAL_NEW,        "",                                 0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpmExpt PerfSignalTableGK208_ltc0_expt[] = {
    //write a combination of the signals.
    { KEPLER_LTC0_WRITE_L1_SECTORS_FBP, kepler_ltc0_write_l1_sectors_fbp_enc_str_1, KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_WR_OP, KEPLER_LTC0_REQUEST_SRC_UNIT_L1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC1_WRITE_L1_SECTORS_FBP, kepler_ltc1_write_l1_sectors_fbp_enc_str_1, KEPLER_LTC1_REQUEST_SECTORS, {KEPLER_LTC1_REQUEST_ACTIVE, KEPLER_LTC1_REQUEST_WR_OP, KEPLER_LTC1_REQUEST_SRC_UNIT_L1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { KEPLER_LTC0_ATOMIC_L1_SECTORS_FBP, kepler_ltc0_atomic_l1_sectors_fbp_enc_str_1, KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_ATOMIC_OP, KEPLER_LTC0_REQUEST_SRC_UNIT_L1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC1_ATOMIC_L1_SECTORS_FBP, kepler_ltc1_atomic_l1_sectors_fbp_enc_str_1, KEPLER_LTC1_REQUEST_SECTORS, {KEPLER_LTC1_REQUEST_ACTIVE, KEPLER_LTC1_REQUEST_ATOMIC_OP, KEPLER_LTC1_REQUEST_SRC_UNIT_L1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { KEPLER_LTC0_READ_L1_SECTORS_FBP, kepler_ltc0_read_l1_sectors_fbp_enc_str_1,  KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_RD_OP, KEPLER_LTC0_REQUEST_SRC_UNIT_L1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC1_READ_L1_SECTORS_FBP, kepler_ltc1_read_l1_sectors_fbp_enc_str_1,  KEPLER_LTC1_REQUEST_SECTORS, {KEPLER_LTC1_REQUEST_ACTIVE, KEPLER_LTC1_REQUEST_RD_OP, KEPLER_LTC1_REQUEST_SRC_UNIT_L1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_hit_sectors_l1_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_src_unit_l1 & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_hit
    { KEPLER_LTC0_WRITE_L1_HIT_SECTORS_FBP, kepler_ltc0_write_l1_hit_sectors_fbp_enc_str_1, KEPLER_LTC0_HIT_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_WR_OP, KEPLER_LTC0_REQUEST_SRC_UNIT_L1, KEPLER_LTC0_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},
    { KEPLER_LTC1_WRITE_L1_HIT_SECTORS_FBP, kepler_ltc1_write_l1_hit_sectors_fbp_enc_str_1, KEPLER_LTC1_HIT_SECTORS, {KEPLER_LTC1_REQUEST_ACTIVE, KEPLER_LTC1_REQUEST_WR_OP, KEPLER_LTC1_REQUEST_SRC_UNIT_L1, KEPLER_LTC1_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},

    { KEPLER_LTC0_READ_L1_HIT_SECTORS_FBP, kepler_ltc0_read_l1_hit_sectors_fbp_enc_str_1, KEPLER_LTC0_HIT_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_RD_OP, KEPLER_LTC0_REQUEST_SRC_UNIT_L1, KEPLER_LTC0_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},
    { KEPLER_LTC1_READ_L1_HIT_SECTORS_FBP, kepler_ltc1_read_l1_hit_sectors_fbp_enc_str_1, KEPLER_LTC1_HIT_SECTORS, {KEPLER_LTC1_REQUEST_ACTIVE, KEPLER_LTC1_REQUEST_RD_OP, KEPLER_LTC1_REQUEST_SRC_UNIT_L1, KEPLER_LTC1_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},

    // ltc_read_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { KEPLER_LTC0_READ_TEX_SECTORS_FBP, kepler_ltc0_read_tex_sectors_fbp_enc_str_1, KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_RD_OP, KEPLER_LTC0_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC1_READ_TEX_SECTORS_FBP, kepler_ltc1_read_tex_sectors_fbp_enc_str_1, KEPLER_LTC1_REQUEST_SECTORS, {KEPLER_LTC1_REQUEST_ACTIVE, KEPLER_LTC1_REQUEST_RD_OP, KEPLER_LTC1_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_hit_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_hit
    { KEPLER_LTC0_READ_TEX_HIT_SECTORS_FBP, kepler_ltc0_read_tex_hit_sectors_fbp_enc_str_1,  KEPLER_LTC0_HIT_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_RD_OP, KEPLER_LTC0_REQUEST_SRC_UNIT_TEX, KEPLER_LTC0_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},
    { KEPLER_LTC1_READ_TEX_HIT_SECTORS_FBP, kepler_ltc1_read_tex_hit_sectors_fbp_enc_str_1,  KEPLER_LTC1_HIT_SECTORS, {KEPLER_LTC1_REQUEST_ACTIVE, KEPLER_LTC1_REQUEST_RD_OP, KEPLER_LTC1_REQUEST_SRC_UNIT_TEX, KEPLER_LTC1_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},

    { KEPLER_LTC0_READ_SYSMEM_SECTORS_FBP, kepler_ltc0_read_sysmem_sectors_fbp_enc_str_1, KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_RD_OP, KEPLER_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC1_READ_SYSMEM_SECTORS_FBP, kepler_ltc1_read_sysmem_sectors_fbp_enc_str_1, KEPLER_LTC1_REQUEST_SECTORS, {KEPLER_LTC1_REQUEST_ACTIVE, KEPLER_LTC1_REQUEST_RD_OP, KEPLER_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { KEPLER_LTC0_WRITE_SYSMEM_SECTORS_FBP, kepler_ltc0_write_sysmem_sectors_fbp_enc_str_1, KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_WR_OP, KEPLER_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC1_WRITE_SYSMEM_SECTORS_FBP, kepler_ltc1_write_sysmem_sectors_fbp_enc_str_1, KEPLER_LTC1_REQUEST_SECTORS, {KEPLER_LTC1_REQUEST_ACTIVE, KEPLER_LTC1_REQUEST_WR_OP, KEPLER_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { KEPLER_LTC0_TOTAL_READ_SECTORS_FBP, kepler_ltc0_total_read_sectors_fbp_enc_str_1, KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ATOMIC_OP, KEPLER_LTC0_REQUEST_RD_OP, KEPLER_LTC0_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC1_TOTAL_READ_SECTORS_FBP, kepler_ltc1_total_read_sectors_fbp_enc_str_1, KEPLER_LTC1_REQUEST_SECTORS, {KEPLER_LTC1_REQUEST_ATOMIC_OP, KEPLER_LTC1_REQUEST_RD_OP, KEPLER_LTC1_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { KEPLER_LTC0_TOTAL_WRITE_SECTORS_FBP, kepler_ltc0_total_write_sectors_fbp_enc_str_1, KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ATOMIC_OP, KEPLER_LTC0_REQUEST_WR_OP, KEPLER_LTC0_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC1_TOTAL_WRITE_SECTORS_FBP, kepler_ltc1_total_write_sectors_fbp_enc_str_1, KEPLER_LTC1_REQUEST_SECTORS, {KEPLER_LTC1_REQUEST_ATOMIC_OP, KEPLER_LTC1_REQUEST_WR_OP, KEPLER_LTC1_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { KEPLER_LTC0_READ_VIDMEM_SECTORS_FBP,      kepler_ltc0_read_vidmem_sectors_fbp_enc_str_1,    KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_RD_OP, KEPLER_LTC0_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC1_READ_VIDMEM_SECTORS_FBP,      kepler_ltc1_read_vidmem_sectors_fbp_enc_str_1,    KEPLER_LTC1_REQUEST_SECTORS, {KEPLER_LTC1_REQUEST_ACTIVE, KEPLER_LTC1_REQUEST_RD_OP, KEPLER_LTC1_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { KEPLER_LTC0_WRITE_VIDMEM_SECTORS_FBP,      kepler_ltc0_write_vidmem_sectors_fbp_enc_str_1,    KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_WR_OP, KEPLER_LTC0_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC1_WRITE_VIDMEM_SECTORS_FBP,      kepler_ltc1_write_vidmem_sectors_fbp_enc_str_1,    KEPLER_LTC1_REQUEST_SECTORS, {KEPLER_LTC1_REQUEST_ACTIVE, KEPLER_LTC1_REQUEST_WR_OP, KEPLER_LTC1_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_pm_request_src_unit_gcc_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_src_unit_gcc & ltc2pm_ltc_lts0_request
    { KEPLER_LTC0_PM_REQ_SRC_UNIT_GCC_FBP,      kepler_ltc0_pm_req_src_unit_gcc_fbp_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_LTC0_REQUEST_SRC_UNIT_GCC, KEPLER_LTC0_REQUEST, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_LTC1_PM_REQ_SRC_UNIT_GCC_FBP,      kepler_ltc1_pm_req_src_unit_gcc_fbp_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_LTC1_REQUEST_SRC_UNIT_GCC, KEPLER_LTC1_REQUEST, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000,  0x00},
};

PerfSignalHwpm PerfSignalTableGK20A_mc0[] = {
    ////MC signals
    {KEPLER_MC_DEV0_CMD_WRITE,    kepler_mc_dev0_cmd_write_enc_str_1, 0x6, 0xaaaa, 0x4, PM_UNIT_MC, 1},
    {KEPLER_MC_DEV0_CMD_WRITE4,   kepler_mc_dev0_cmd_write4_enc_str_1, 0x6, 0xaaaa, 0x5, PM_UNIT_MC, 1},
    {KEPLER_MC_DEV0_CMD_WRITE8,   kepler_mc_dev0_cmd_write8_enc_str_1, 0x6, 0xaaaa, 0x6, PM_UNIT_MC, 1},
    {KEPLER_MC_DEV0_CMD_WRITE8X2, kepler_mc_dev0_cmd_write8x2_enc_str_1, 0x6, 0xaaaa, 0x7, PM_UNIT_MC, 1},
    {KEPLER_MC_DEV0_CMD_READ,     kepler_mc_dev0_cmd_read_enc_str_1, 0x6, 0xaaaa, 0x0, PM_UNIT_MC, 1},
    {KEPLER_MC_DEV0_CMD_READ4,    kepler_mc_dev0_cmd_read4_enc_str_1, 0x6, 0xaaaa, 0x1, PM_UNIT_MC, 1},
    {KEPLER_MC_DEV0_CMD_READ8,    kepler_mc_dev0_cmd_read8_enc_str_1, 0x6, 0xaaaa, 0x2, PM_UNIT_MC, 1},
    {KEPLER_MC_DEV0_CMD_READ8X2,  kepler_mc_dev0_cmd_read8x2_enc_str_1, 0x6, 0xaaaa, 0x3, PM_UNIT_MC, 1},
    // Set the following registers in android kernel to get non-zero value
    // http://handheld-build.nvidia.com/manuals/t124/armc.html
    // Base = TEGRA_MC_BASE
    // MC_STAT_CONTROL_0 = 0x7
    // MC_STAT_EMC_FILTER_SET0_CLIENT_0_0 = 0x0
    // MC_STAT_EMC_FILTER_SET0_CLIENT_1_0 = 0x0
    // MC_STAT_EMC_FILTER_SET0_CLIENT_2_0 = 0x3
    // MC_STAT_EMC_FILTER_SET1_CLIENT_0_0 = 0x0
    // MC_STAT_EMC_FILTER_SET1_CLIENT_1_0 = 0x0
    // MC_STAT_EMC_FILTER_SET1_CLIENT_2_0 = 0x3
    {KEPLER_MC_REQ_CLIENT_MATCH_SET0, kepler_mc_req_client_match_set0_enc_str_1, 0x4, 0xaaaa, 0x2, PM_UNIT_MC, 1},
    {KEPLER_MC_REQ_CLIENT_MATCH_SET1, kepler_mc_req_client_match_set1_enc_str_1, 0x4, 0xaaaa, 0x5, PM_UNIT_MC, 1},


    {INVALID_PM_SIGNAL_NEW, "", 0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpm PerfSignalTableGK20A_ltc0[] = {
    //LTC signals
    // l2_subp0_write_sector_misses = ltc_ltc2fb_dirty_dat0_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 0
    // l2_subp1_write_sector_misses = ltc_ltc2fb_dirty_dat1_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 1
    // l2_subp0_read_sector_misses  = ltc_fb2ltc_rdat0_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 0
    // l2_subp1_read_sector_misses  = ltc_fb2ltc_rdat1_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 1
    // l2_subp0_write_l1_sector_queries = ltc2pm_ltc_lts0_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 0
    // l2_subp1_write_l1_sector_queries = ltc2pm_ltc_lts1_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 1
    // l2_subp0_read_l1_sector_queries  = ltc2pm_ltc_lts0_request_rd_op && ltc2pm_ltc_lts1_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 0
    // l2_subp1_read_l1_sector_queries  = ltc2pm_ltc_lts1_request_rd_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 1

    {KEPLER_LTC0_WRITE_MISS_SECTORS_GK20A, kepler_ltc0_write_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x2a, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC0_READ_MISS_SECTORS_GK20A, kepler_ltc0_read_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x2b, PM_UNIT_LTC1, 1, 0},

    {KEPLER_LTC0_REQUEST_SRC_UNIT_L1, kepler_ltc0_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x1c, PM_UNIT_LTC2, 1, 0},
    {KEPLER_LTC0_REQUEST_SRC_UNIT_HUB, kepler_ltc0_request_src_unit_hub_enc_str_1, 0xc, 0xaaaa, 0x1c, PM_UNIT_LTC2, 1, 0},
    {KEPLER_LTC0_REQUEST_SRC_UNIT_TEX, kepler_ltc0_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x1c, PM_UNIT_LTC2, 1, 0},
    {KEPLER_LTC0_REQUEST_SRC_UNIT_GCC, kepler_ltc0_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x1c, PM_UNIT_LTC2, 1, 0},
    {KEPLER_LTC0_HIT_SECTORS, kepler_ltc0_hit_sectors_enc_str_1, 0x1, 0xffff, 0x18, PM_UNIT_LTC, 4, 0},
    {KEPLER_LTC0_REQUEST_SECTORS, kepler_ltc0_request_sectors_enc_str_1, 0x0, 0xffff, 0x18, PM_UNIT_LTC, 4, 0},
    {KEPLER_LTC0_REQUEST_ACTIVE, kepler_ltc0_request_active_enc_str_1, 0x0, 0xaaaa, 0x27, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC0_REQUEST_RD_OP, kepler_ltc0_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x3a, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC0_REQUEST_WR_OP, kepler_ltc0_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x39, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC0_REQUEST_ATOMIC_OP, kepler_ltc0_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x38, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC0_REQUEST_APERTURE_SYSMEM, kepler_ltc0_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x34, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC0_REQUEST_APERTURE_VIDMEM, kepler_ltc0_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x33, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC0_HIT, kepler_ltc0_hit_enc_str_1, 0x0, 0xaaaa, 0x2e, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC0_REQUEST, kepler_ltc0_request_enc_str_1, 0x0, 0xaaaa, 0x26, PM_UNIT_LTC1, 1, 0},

    {KEPLER_LTC0_LTCX_MC_REQ_RD,        kepler_ltc0_ltcx_mc_req_rd_enc_str_1, 0x10, 0xaaaa, 0x2d, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC0_LTCX_MC_REQ_RD_SIZE,   kepler_ltc0_ltcx_mc_req_rd_size_enc_str_1, 0x10, 0xaaaa, 0x2e, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC0_LTCX_MC_REQ_WR,        kepler_ltc0_ltcx_mc_req_wr_enc_str_1, 0x10, 0xaaaa, 0x31, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC0_LTCX_MC_REQ_WR_SIZE_0, kepler_ltc0_ltcx_mc_req_wr_size_0_enc_str_1, 0x10, 0xaaaa, 0x32, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC0_LTCX_MC_REQ_WR_SIZE_1, kepler_ltc0_ltcx_mc_req_wr_size_1_enc_str_1, 0x10, 0xaaaa, 0x33, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC0_LTCX_MC_REQ_WR_PARTIAL,kepler_ltc0_ltcx_mc_req_wr_partial_enc_str_1, 0x10, 0xaaaa, 0x36, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC0_LTCX_REQ_RD,           kepler_ltc0_ltcx_req_rd_enc_str_1, 0x10, 0xaaaa, 0x26, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC0_LTCX_REQ_RD_SIZE_0,    kepler_ltc0_ltcx_req_rd_size_0_enc_str_1, 0x10, 0xaaaa, 0x27, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC0_LTCX_REQ_RD_SIZE_1,    kepler_ltc0_ltcx_req_rd_size_1_enc_str_1, 0x10, 0xaaaa, 0x28, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC0_LTCX_REQ_WR,           kepler_ltc0_ltcx_req_wr_enc_str_1, 0x10, 0xaaaa, 0x29, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC0_LTCX_REQ_WR_SIZE_0,    kepler_ltc0_ltcx_req_wr_size_0_enc_str_1, 0x10, 0xaaaa, 0x2a, PM_UNIT_LTC1, 1, 0},
    {KEPLER_LTC0_LTCX_REQ_WR_SIZE_1,    kepler_ltc0_ltcx_req_wr_size_1_enc_str_1, 0x10, 0xaaaa, 0x2b, PM_UNIT_LTC1, 1, 0},

    { INVALID_PM_SIGNAL_NEW,        "",                                 0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpmExpt PerfSignalTableGK20A_ltc0_expt[] = {
    //write a combination of the signals.
    { KEPLER_LTC0_WRITE_HUB_SECTORS_FBP, kepler_ltc0_write_hub_sectors_fbp_enc_str_1, KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_WR_OP, KEPLER_LTC0_REQUEST_SRC_UNIT_HUB, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { KEPLER_LTC0_ATOMIC_HUB_SECTORS_FBP, kepler_ltc0_atomic_hub_sectors_fbp_enc_str_1, KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_ATOMIC_OP, KEPLER_LTC0_REQUEST_SRC_UNIT_HUB, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { KEPLER_LTC0_READ_HUB_SECTORS_FBP, kepler_ltc0_read_hub_sectors_fbp_enc_str_1,  KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_RD_OP, KEPLER_LTC0_REQUEST_SRC_UNIT_HUB, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_hit_sectors_l1_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_src_unit_l1 & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_hit
    { KEPLER_LTC0_WRITE_HUB_HIT_SECTORS_FBP, kepler_ltc0_write_hub_hit_sectors_fbp_enc_str_1, KEPLER_LTC0_HIT_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_WR_OP, KEPLER_LTC0_REQUEST_SRC_UNIT_HUB, KEPLER_LTC0_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},

    { KEPLER_LTC0_READ_HUB_HIT_SECTORS_FBP, kepler_ltc0_read_hub_hit_sectors_fbp_enc_str_1, KEPLER_LTC0_HIT_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_RD_OP, KEPLER_LTC0_REQUEST_SRC_UNIT_HUB, KEPLER_LTC0_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},

    // ltc_read_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { KEPLER_LTC0_READ_TEX_SECTORS_FBP, kepler_ltc0_read_tex_sectors_fbp_enc_str_1, KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_RD_OP, KEPLER_LTC0_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_hit_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_hit
    { KEPLER_LTC0_READ_TEX_HIT_SECTORS_FBP_GK20A, kepler_ltc0_read_tex_hit_sectors_fbp_enc_str_1,  KEPLER_LTC0_HIT_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_RD_OP, KEPLER_LTC0_REQUEST_SRC_UNIT_TEX, KEPLER_LTC0_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), 0},

    { KEPLER_LTC0_READ_SYSMEM_SECTORS_FBP, kepler_ltc0_read_sysmem_sectors_fbp_enc_str_1, KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_RD_OP, KEPLER_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { KEPLER_LTC0_WRITE_SYSMEM_SECTORS_FBP, kepler_ltc0_write_sysmem_sectors_fbp_enc_str_1, KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_WR_OP, KEPLER_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { KEPLER_LTC0_TOTAL_READ_SECTORS_FBP, kepler_ltc0_total_read_sectors_fbp_enc_str_1, KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ATOMIC_OP, KEPLER_LTC0_REQUEST_RD_OP, KEPLER_LTC0_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { KEPLER_LTC0_TOTAL_WRITE_SECTORS_FBP, kepler_ltc0_total_write_sectors_fbp_enc_str_1, KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ATOMIC_OP, KEPLER_LTC0_REQUEST_WR_OP, KEPLER_LTC0_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { KEPLER_LTC0_READ_VIDMEM_SECTORS_FBP,      kepler_ltc0_read_vidmem_sectors_fbp_enc_str_1,    KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_RD_OP, KEPLER_LTC0_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { KEPLER_LTC0_WRITE_VIDMEM_SECTORS_FBP,      kepler_ltc0_write_vidmem_sectors_fbp_enc_str_1,    KEPLER_LTC0_REQUEST_SECTORS, {KEPLER_LTC0_REQUEST_ACTIVE, KEPLER_LTC0_REQUEST_WR_OP, KEPLER_LTC0_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_pm_request_src_unit_gcc_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_src_unit_gcc & ltc2pm_ltc_lts0_request
    { KEPLER_LTC0_PM_REQ_SRC_UNIT_GCC_FBP,      kepler_ltc0_pm_req_src_unit_gcc_fbp_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_LTC0_REQUEST_SRC_UNIT_GCC, KEPLER_LTC0_REQUEST, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},

    { KEPLER_LTC_LTCX_MC_REQ_RD_SIZE_32B, kepler_ltc_ltcx_mc_req_rd_size_32b_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_LTC0_LTCX_MC_REQ_RD, KEPLER_LTC0_LTCX_MC_REQ_RD_SIZE, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE)), 0},
    { KEPLER_LTC_LTCX_MC_REQ_RD_SIZE_64B, kepler_ltc_ltcx_mc_req_rd_size_64b_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_LTC0_LTCX_MC_REQ_RD, KEPLER_LTC0_LTCX_MC_REQ_RD_SIZE, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { KEPLER_LTC_LTCX_MC_REQ_WR_SIZE_16B, kepler_ltc_ltcx_mc_req_wr_size_16b_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_LTC0_LTCX_MC_REQ_WR, KEPLER_LTC0_LTCX_MC_REQ_WR_SIZE_0, KEPLER_LTC0_LTCX_MC_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { KEPLER_LTC_LTCX_MC_REQ_WR_SIZE_32B, kepler_ltc_ltcx_mc_req_wr_size_32b_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_LTC0_LTCX_MC_REQ_WR, KEPLER_LTC0_LTCX_MC_REQ_WR_SIZE_0, KEPLER_LTC0_LTCX_MC_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { KEPLER_LTC_LTCX_MC_REQ_WR_SIZE_64B, kepler_ltc_ltcx_mc_req_wr_size_64b_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_LTC0_LTCX_MC_REQ_WR, KEPLER_LTC0_LTCX_MC_REQ_WR_SIZE_0, KEPLER_LTC0_LTCX_MC_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { KEPLER_LTC_LTCX_REQ_RD_SECTOR_COUNT_1, kepler_ltc_ltcx_req_rd_sector_count_1_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_LTC0_LTCX_REQ_RD, KEPLER_LTC0_LTCX_REQ_RD_SIZE_0, KEPLER_LTC0_LTCX_REQ_RD_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { KEPLER_LTC_LTCX_REQ_RD_SECTOR_COUNT_2, kepler_ltc_ltcx_req_rd_sector_count_2_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_LTC0_LTCX_REQ_RD, KEPLER_LTC0_LTCX_REQ_RD_SIZE_0, KEPLER_LTC0_LTCX_REQ_RD_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { KEPLER_LTC_LTCX_REQ_RD_SECTOR_COUNT_3, kepler_ltc_ltcx_req_rd_sector_count_3_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_LTC0_LTCX_REQ_RD, KEPLER_LTC0_LTCX_REQ_RD_SIZE_0, KEPLER_LTC0_LTCX_REQ_RD_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC_LTCX_REQ_RD_SECTOR_COUNT_4, kepler_ltc_ltcx_req_rd_sector_count_4_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_LTC0_LTCX_REQ_RD, KEPLER_LTC0_LTCX_REQ_RD_SIZE_0, KEPLER_LTC0_LTCX_REQ_RD_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { KEPLER_LTC_LTCX_REQ_WR_SECTOR_COUNT_1, kepler_ltc_ltcx_req_wr_sector_count_1_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_LTC0_LTCX_REQ_WR, KEPLER_LTC0_LTCX_REQ_WR_SIZE_0, KEPLER_LTC0_LTCX_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { KEPLER_LTC_LTCX_REQ_WR_SECTOR_COUNT_2, kepler_ltc_ltcx_req_wr_sector_count_2_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_LTC0_LTCX_REQ_WR, KEPLER_LTC0_LTCX_REQ_WR_SIZE_0, KEPLER_LTC0_LTCX_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { KEPLER_LTC_LTCX_REQ_WR_SECTOR_COUNT_3, kepler_ltc_ltcx_req_wr_sector_count_3_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_LTC0_LTCX_REQ_WR, KEPLER_LTC0_LTCX_REQ_WR_SIZE_0, KEPLER_LTC0_LTCX_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { KEPLER_LTC_LTCX_REQ_WR_SECTOR_COUNT_4, kepler_ltc_ltcx_req_wr_sector_count_4_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_LTC0_LTCX_REQ_WR, KEPLER_LTC0_LTCX_REQ_WR_SIZE_0, KEPLER_LTC0_LTCX_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000,  0x00},
};

PerfSignalHwpm PerfSignalTableGK20A_sys0[] = {
    //Hub TLB signals

    //mmu_hub_tlb_hit      = hubmmu2pm_hub_hub_tlb_hit                                      count # of PTE hits in hub TLB
    //mmu_hub_tlb_miss     = (hubmmu2pm_hub_hub_tlb_miss & !hubmmu2pm_hub_hub_tlb_hit)      count # of PTE misses in hub TLB
    { KEPLER_MMU_HUB_TLB_HIT,    kepler_mmu_hub_tlb_hit_enc_str_1,    0x00000004, 0x0000AAAA, 0x51,    PM_UNIT_HUBMMU,1 },
    { KEPLER_MMU_HUB_TLB_MISS_INT,   kepler_mmu_hub_tlb_miss_int_enc_str_1,   0x00000004, 0x0000AAAA, 0x52,    PM_UNIT_HUBMMU,1 },

    // mmu_fill_pte_hit    = hubmmu2pm_hub_fill_pte_hit                                     "count # of PTE hits in mmu fill unit"
    // mmu_fill_pte_miss   = (hubmmu2pm_hub_fill_pte_miss & !hubmmu2pm_hub_fill_pte_hit)    "count # of PTE misses in mmu fill unit"
    { KEPLER_MMU_FILL_PTE_HIT,   kepler_mmu_fill_pte_hit_enc_str_1,   0x00000006, 0x0000AAAA, 0x51,    PM_UNIT_HUBMMU,1 },
    { KEPLER_MMU_FILL_PTE_MISS_INT,  kepler_mmu_fill_pte_miss_int_enc_str_1,  0x00000006, 0x0000AAAA, 0x52,    PM_UNIT_HUBMMU,1 },

    // mmu_fill_pde_hit    = hubmmu2pm_hub_fill_pde_hit                                     "count # of PDE hits in mmu fill unit"
    // mmu_fill_pde_miss   = hubmmu2pm_hub_fill_pde_miss                                    "count # of PDE misses in mmu fill unit"
    { KEPLER_MMU_FILL_PDE_HIT,   kepler_mmu_fill_pde_hit_enc_str_1,   0x00000006, 0x0000AAAA, 0x53,    PM_UNIT_HUBMMU,1 },
    { KEPLER_MMU_FILL_PDE_MISS,  kepler_mmu_fill_pde_miss_enc_str_1,  0x00000006, 0x0000AAAA, 0x54,    PM_UNIT_HUBMMU,1 },

    //GK20a doesn't have L2 TLB
    { INVALID_PM_SIGNAL_NEW,     "",                     0xffffffff, 0x00000000, 0x00,     PM_UNIT_MAX,0}
};

PerfSignalSmpcExpt PerfSignalTableGK208_LutModeCounters[] = {
    { KEPLER_LUT_COUNTER_SUB_GLD32BIT_INST,  kepler_lut_counter_sub_gld32bit_inst_enc_str_1,   PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SUB_SIZE_32,KEPLER_SM_GENERIC_LOAD,KEPLER_SM_LSU_INST_PREDICATED_OFF,INVALID_PM_SIGNAL_NEW},  (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE))},
    { KEPLER_LUT_COUNTER_SUB_GST32BIT_INST,  kepler_lut_counter_sub_gst32bit_inst_enc_str_1,   PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SUB_SIZE_32,KEPLER_SM_GENERIC_STORE,KEPLER_SM_LSU_INST_PREDICATED_OFF,INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE))},
    { KEPLER_LUT_COUNTER_GLD32BIT_INST,      kepler_lut_counter_gld32bit_inst_enc_str_1,  PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SIZE_32,KEPLER_SM_GENERIC_LOAD,KEPLER_SM_LSU_INST_PREDICATED_OFF,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE))},
    { KEPLER_LUT_COUNTER_GST32BIT_INST,      kepler_lut_counter_gst32bit_inst_enc_str_1,  PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SIZE_32,KEPLER_SM_GENERIC_STORE,KEPLER_SM_LSU_INST_PREDICATED_OFF,INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE))},
    { KEPLER_LUT_COUNTER_GLD64BIT_INST,      kepler_lut_counter_gld64bit_inst_enc_str_1,  PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SIZE_64,KEPLER_SM_GENERIC_LOAD,KEPLER_SM_LSU_INST_PREDICATED_OFF,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE))},
    { KEPLER_LUT_COUNTER_GST64BIT_INST,      kepler_lut_counter_gst64bit_inst_enc_str_1,  PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SIZE_64,KEPLER_SM_GENERIC_STORE,KEPLER_SM_LSU_INST_PREDICATED_OFF,INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE))},
    { KEPLER_LUT_COUNTER_GLD128BIT_INST,     kepler_lut_counter_gld128bit_inst_enc_str_1, PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SIZE_128,KEPLER_SM_GENERIC_LOAD,KEPLER_SM_LSU_INST_PREDICATED_OFF,INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE))},
    { KEPLER_LUT_COUNTER_GST128BIT_INST,     kepler_lut_counter_gst128bit_inst_enc_str_1, PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SIZE_128,KEPLER_SM_GENERIC_STORE,KEPLER_SM_LSU_INST_PREDICATED_OFF,INVALID_PM_SIGNAL_NEW},    (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE))},
    { KEPLER_SM_L1C_SHARED_LOAD_BANK_CONFLICT,       kepler_sm_l1c_shared_load_bank_conflict_enc_str_1                   , PM_UNIT_SMCORE, {KEPLER_SM_MEM_DIVERGENT_OR_DEFERRED_INSTRUCTION,KEPLER_SHARED_LOAD_REPLAY_INTERNAL,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW} ,                    (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { KEPLER_SM_L1C_SHARED_STORE_BANK_CONFLICT,      kepler_sm_l1c_shared_store_bank_conflict_enc_str_1                  , PM_UNIT_SMCORE, {KEPLER_SM_MEM_DIVERGENT_OR_DEFERRED_INSTRUCTION,KEPLER_SHARED_STORE_REPLAY_INTERNAL,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW} ,                   (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { KEPLER_SM_GLOBAL_RED_MEM_DIVERGENCE_REPLAYS,   kepler_sm_global_red_mem_divergence_replays_enc_str_1  , PM_UNIT_SMCORE, {KEPLER_SM_MEM_DIVERGENT_OR_DEFERRED_INSTRUCTION,KEPLER_SM_GLOBAL_RED_MEM_DIVERGENCE_REPLAYS_INTERNAL,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW} ,           (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { KEPLER_SM_GLOBAL_ATOM_MEM_DIVERGENCE_REPLAYS,  kepler_sm_global_atom_mem_divergence_replays_enc_str_1 , PM_UNIT_SMCORE, {KEPLER_SM_MEM_DIVERGENT_OR_DEFERRED_INSTRUCTION,KEPLER_SM_GLOBAL_ATOM_MEM_DIVERGENCE_REPLAYS_INTERNAL,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW} , (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},

    { INVALID_PM_SIGNAL_NEW,               "", PM_UNIT_MAX,          {INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW} , TRUTH_TABLE_FUNCTION_ALL_FALSE}
};

PerfSignalSmpc PerfSignalTableGK208_sm0[] = {
    // QCTL Signals

    //["GROUP1" =>
    //    ["nop_trig0",               1,      "off",  "# of nop.trig instructions executed where bit 0 of #Imm16 was set", undef],
    //    ["nop_trig1",               1,      "off",  "# of nop.trig instructions executed where bit 1 of #Imm16 was set", undef],
    //    ["nop_trig2",               1,      "off",  "# of nop.trig instructions executed where bit 2 of #Imm16 was set", undef],
    //    ["nop_trig3",               1,      "off",  "# of nop.trig instructions executed where bit 3 of #Imm16 was set", undef],
    //    ["nop_trig4",               1,      "off",  "# of nop.trig instructions executed where bit 4 of #Imm16 was set", undef],
    //    ["nop_trig5",               1,      "off",  "# of nop.trig instructions executed where bit 5 of #Imm16 was set", undef],
    //    ["nop_trig6",               1,      "off",  "# of nop.trig instructions executed where bit 6 of #Imm16 was set", undef],
    //    ["nop_trig7",               1,      "off",  "# of nop.trig instructions executed where bit 7 of #Imm16 was set", undef],
    //],
    //["GROUP2" =>
    //    ["nop_trig8",               1,      "off",  "# of nop.trig instructions executed where bit 8 of #Imm16 was set", undef],
    //    ["nop_trig9",               1,      "off",  "# of nop.trig instructions executed where bit 9 of #Imm16 was set", undef],
    //    ["nop_trig10",              1,      "off",  "# of nop.trig instructions executed where bit 10 of #Imm16 was set", undef],
    //    ["nop_trig11",              1,      "off",  "# of nop.trig instructions executed where bit 11 of #Imm16 was set", undef],
    //    ["nop_trig12",              1,      "off",  "# of nop.trig instructions executed where bit 12 of #Imm16 was set", undef],
    //    ["nop_trig13",              1,      "off",  "# of nop.trig instructions executed where bit 13 of #Imm16 was set", undef],
    //    ["nop_trig14",              1,      "off",  "# of nop.trig instructions executed where bit 14 of #Imm16 was set", undef],
    //    ["nop_trig15",              1,      "off",  "# of nop.trig instructions executed where bit 15 of #Imm16 was set", undef],
    //],
    { KEPLER_SM_NOP_TRIG_00,                      kepler_sm_nop_trig_00_enc_str_1,      0x00000001, 0x00000000, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_01,                      kepler_sm_nop_trig_01_enc_str_1,      0x00000001, 0x00000001, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_02,                      kepler_sm_nop_trig_02_enc_str_1,      0x00000001, 0x00000002, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_03,                      kepler_sm_nop_trig_03_enc_str_1,      0x00000001, 0x00000003, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_04,                      kepler_sm_nop_trig_04_enc_str_1,      0x00000001, 0x00000004, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_05,                      kepler_sm_nop_trig_05_enc_str_1,      0x00000001, 0x00000005, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_06,                      kepler_sm_nop_trig_06_enc_str_1,      0x00000001, 0x00000006, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_07,                      kepler_sm_nop_trig_07_enc_str_1,      0x00000001, 0x00000007, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_08,                      kepler_sm_nop_trig_08_enc_str_1,        0x00000002, 0x00000000, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_09,                      kepler_sm_nop_trig_09_enc_str_1,        0x00000002, 0x00000001, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_10,                      kepler_sm_nop_trig_10_enc_str_1,        0x00000002, 0x00000002, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_11,                      kepler_sm_nop_trig_11_enc_str_1,        0x00000002, 0x00000003, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_12,                      kepler_sm_nop_trig_12_enc_str_1,        0x00000002, 0x00000004, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_13,                      kepler_sm_nop_trig_13_enc_str_1,        0x00000002, 0x00000005, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_14,                      kepler_sm_nop_trig_14_enc_str_1,        0x00000002, 0x00000006, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_NOP_TRIG_15,                      kepler_sm_nop_trig_15_enc_str_1,        0x00000002, 0x00000007, 0x00000001,    PM_UNIT_SMQCTL,1 },

    //["GROUP3" =>
    //    ["active_cycles_quad",      1,      "on",   "Sum of active cycles from all quads having At least 1 active warp",  undef],
    //    ["warps_launched",          1,      "on",   "If a warp was launched this cycle in this quad",       undef],
    //    ["threads_launched",        6,      "on",   "Number of threads launched this cycle in this quad",   undef],
    //],
    { KEPLER_SM_ACTIVE_CYCLES_QUAD,       kepler_sm_active_cycles_quad_enc_str_1,  0x00000003, 0x00000000, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_WARPS_LAUNCHED,           kepler_sm_warps_launched_enc_str_1,      0x00000003, 0x00000001, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_THREADS_LAUNCHED,         kepler_sm_threads_launched_enc_str_1,    0x00000003, 0x00765432, 0x0000003f,    PM_UNIT_SMQCTL,6 },

    //["GROUP5" =>
    //    ["inst_issued0",                    1,      "on",   "# of cycles issued 0 instructions",        undef],
    //    ["inst_issued1",                    1,      "on",   "# of cycles issued 1 instructions",        undef],
    //    ["inst_issued2",                    1,      "on",   "# of cycles issued 2 instructions",        undef],
    //]
    { KEPLER_SM_INST_ISSUED_1,             kepler_sm_inst_issued_1_enc_str_1,       0x00000005, 0x00000001, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_2,             kepler_sm_inst_issued_2_enc_str_1,       0x00000005, 0x00000002, 0x00000001,    PM_UNIT_SMQCTL,1 },

    //["GROUP4" =>
    //    ["threads_launched_for_execution",  6,      "on",   "Number of threads launched for execution, including helper threads", undef],
    //    ["inst_executed",                   2,      "on",   "# of instructions executed",              undef],
    //],
    { KEPLER_SM_INST_EXECUTED,            kepler_sm_inst_executed_enc_str_1,       0x00000004, 0x00000076, 0x00000003,    PM_UNIT_SMQCTL,2 },

    //["GROUP17" =>
    //    ["thread_inst_executed",    6,      "on",   "Number of thread instruction executed this cycle in this quad",   undef],
    //],
    { KEPLER_SM_THREAD_INST_EXECUTED,         kepler_sm_thread_inst_executed_enc_str_1,0x00000011, 0x00543210, 0x0000003f,    PM_UNIT_SMQCTL,6 },

    //["GROUP18" =>
    //    ["tex_quad_fetches",                1,      "on",   "Texture quad requests in this quad",   undef],
    //],
    { KEPLER_SM_TEX_QUAD_FETCHES,             kepler_sm_tex_quad_fetches_enc_str_1,0x00000012, 0x00000000, 0x00000001,    PM_UNIT_SMQCTL,1 },

    //["GROUP29" =>
    //    ["inst_executed_lsu_size_128",      1,      "off",  "128b lsu instr",    undef],
    //    ["inst_executed_lsu_size_64",       1,      "off",  "64b lsu instr",     undef],
    //    ["inst_executed_lsu_size_32",       1,      "off",  "32b lsu instr",     undef],
    //    ["inst_executed_lsu_sub_size_32",   1,      "off",  "< 32b lsu instr",   undef],
    //    ["lsu_inst_predicated_off",         1,      "off",  "committed but completely predicated off LSU instructions", undef],
    //]
    { KEPLER_SM_INST_EXECUTED_LSU_SIZE_128,     kepler_sm_inst_executed_lsu_size_128_enc_str_1,       0x0000001D, 0x00000000, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_SIZE_64,      kepler_sm_inst_executed_lsu_size_64_enc_str_1,        0x0000001D, 0x00000002, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_SIZE_32,      kepler_sm_inst_executed_lsu_size_32_enc_str_1,        0x0000001D, 0x00000003, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_SUB_SIZE_32,  kepler_sm_inst_executed_lsu_sub_size_32_enc_str_1,    0x0000001D, 0x00000004, 0x00000001,    PM_UNIT_SMQCTL,1 },

    { KEPLER_SM_LSU_INST_PREDICATED_OFF,        kepler_sm_lsu_inst_predicated_off_enc_str_1,          0x0000001D, 0x00000005, 0x00000001,    PM_UNIT_SMQCTL,1 },
    //["GROUP20" =>
    //    ["not_predicated_off_thread_inst_executed", 6,      "off",  "# executed but not predicated off thread instructions", undef],
    //],
    { KEPLER_SM_NOT_PREDICATED_OFF_THREAD_INST_EXECUTED, kepler_sm_not_predicated_off_thread_inst_executed_enc_str_1,  0x00000014, 0x00543210, 0x0000003f,    PM_UNIT_SMQCTL,6 },

    //["GROUP26" =>
    //    ["inst_executed_lsu_atom",          1,      "off",  "atom",                     undef],
    //    ["inst_executed_lsu_red",           1,      "off",  "reduction",                undef],
    { KEPLER_SM_L1C_ATOM_COUNT,                    kepler_sm_l1c_atom_count_enc_str_1,        0x0000001A, 0x00000004, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_L1_ATOM_CAS_COUNT,                 kepler_sm_l1_atom_cas_count_enc_str_1,     0x0000001A, 0x00000005, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_L1C_GRED_COUNT,                    kepler_sm_l1c_gred_count_enc_str_1,        0x0000001A, 0x00000006, 0x00000001,    PM_UNIT_SMQCTL,1 },


    //["GROUP27" =>
    //    ["inst_executed_lsu_lds",           1,      "off",  "shared store ",    undef],
    //    ["inst_executed_lsu_sts",           1,      "off",  "shared load ",     undef],
    //    ["inst_executed_lsu_ldl",           1,      "off",  "local load ",      undef],
    //    ["inst_executed_lsu_stl",           1,      "off",  "local store ",     undef],
    //    ["inst_executed_lsu_ld",            1,      "off",  "generic load",     undef],
    //    ["inst_executed_lsu_st",            1,      "off",  "generic store",    undef],
    //],
    { KEPLER_SM_SHARED_LOAD,                       kepler_sm_shared_load_enc_str_1,         0x0000001B, 0x00000000, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_SHARED_STORE,                      kepler_sm_shared_store_enc_str_1,        0x0000001B, 0x00000001, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_LOCAL_LOAD,                        kepler_sm_local_load_enc_str_1,          0x0000001B, 0x00000002, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_LOCAL_STORE,                       kepler_sm_local_store_enc_str_1,         0x0000001B, 0x00000003, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_GENERIC_LOAD,                      kepler_sm_generic_load_enc_str_1,         0x0000001B, 0x00000004, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_GENERIC_STORE,                     kepler_sm_generic_store_enc_str_1,         0x0000001B, 0x00000005, 0x00000001,    PM_UNIT_SMQCTL,1 },

    //["GROUP28" =>
    //    ["br_executed",                     1,      "off",  "unique committed branch", undef],
    //    ["diverged_br_executed",            1,      "off",  "unique branches that diverge", undef],
    //],
#if 0
    { KEPLER_SM_UNIQUE_BRANCHES,                   kepler_sm_unique_branches_enc_str_1,               0x0000001C, 0x00000000, 0x00000001,    PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_DIVERGED_BRANCHES,                 kepler_sm_diverged_branches_enc_str_1,     0x0000001C, 0x00000001, 0x00000001,    PM_UNIT_SMQCTL,1 },
#endif
    // CORE and L1C Signals

    //["GROUP2_CORE" =>
    //    ["active_cycles",           1,      "on",   "At least 1 active warp",                   undef],
    //    ["active_warps",            6,      "on",   "Number of active warps total in the SM",   undef],
    //    ["ctas_launched",           1,      "on",   "Number of CTAs launched in the SM",        undef],
    //],
    { KEPLER_SM_ACTIVE_CYCLES,                kepler_sm_active_cycles_enc_str_1,      0x00000002, 0x00000000, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_ACTIVE_WARPS,                 kepler_sm_active_warps_enc_str_1,       0x00000002, 0x00654321, 0x0000003f,    PM_UNIT_SMCORE,6 },
    { KEPLER_SM_CTA_LAUNCHED,                 kepler_sm_cta_launched_enc_str_1,    0x00000002, 0x00000007, 0x00000001,    PM_UNIT_SMCORE,1 },

    //["GROUP14_LSU" =>
    //    ["local_ld_transactions",   1,      "off",  "count instructions at accept point", undef],
    //    ["local_st_transactions",   1,      "off",  "count instructions at accept point", undef],
    //    ["shared_ld_transactions",  1,      "off",  "count instructions at accept point", undef],
    //    ["shared_st_transactions",  1,      "off",  "count instructions at accept point", undef],
    //],
    //["GROUP15_LSU" =>
    //    ["global_ld_transactions",              1,      "off",   "count instructions at accept point", undef],
    //    ["global_st_transactions",              1,      "off",   "count instructions at accept point", undef],
    //],
    { KEPLER_SM_L1C_LOCAL_LOAD_TRANSACTIONS,      kepler_sm_l1c_local_load_transactions_enc_str_1,   0x0000000e, 0x00000000, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_LOCAL_STORE_TRANSACTIONS,     kepler_sm_l1c_local_store_transactions_enc_str_1,  0x0000000e, 0x00000001, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_SHARED_LOAD_TRANSACTIONS,     kepler_sm_l1c_shared_load_transactions_enc_str_1,  0x0000000e, 0x00000002, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_SHARED_STORE_TRANSACTIONS,    kepler_sm_l1c_shared_store_transactions_enc_str_1, 0x0000000e, 0x00000003, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_GLOBAL_LOAD_TRANSACTIONS,     kepler_sm_l1c_global_load_transactions_enc_str_1,  0x0000000f, 0x00000000, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_GLOBAL_STORE_TRANSACTIONS,    kepler_sm_l1c_global_store_transactions_enc_str_1, 0x0000000f, 0x00000001, 0x00000001,    PM_UNIT_SMCORE,1 },

    //["GROUP16_LSU" =>
    //    ["l1_cached_local_ld_hits",             1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_local_ld_misses",           1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_local_st_hits",             1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_local_st_misses",           1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_global_ld_hits",            1,      "off",   "count instructions at accept point", undef],
    //    ["l1_cached_global_ld_misses",          1,      "off",   "count instructions at accept point", undef],
    //],
    { KEPLER_SM_L1C_LOCAL_LOAD_HIT,           kepler_sm_l1c_local_load_hit_enc_str_1,    0x00000010, 0x00000000, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_LOCAL_LOAD_MISS,          kepler_sm_l1c_local_load_miss_enc_str_1,   0x00000010, 0x00000001, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_LOCAL_STORE_HIT,          kepler_sm_l1c_local_store_hit_enc_str_1,   0x00000010, 0x00000002, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_LOCAL_STORE_MISS,         kepler_sm_l1c_local_store_miss_enc_str_1,  0x00000010, 0x00000003, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_GLOBAL_LOAD_HIT,          kepler_sm_l1c_global_load_hit_enc_str_1,   0x00000010, 0x00000004, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_GLOBAL_LOAD_MISS,         kepler_sm_l1c_global_load_miss_enc_str_1,  0x00000010, 0x00000005, 0x00000001,    PM_UNIT_SMCORE,1 },

    //["GROUP17_LSU" =>
    //    ["l1_uncached_global_ld_count",         1,      "off",   "count instructions at accept point", undef],
    //    ["l1_global_st_count",                  1,      "off",   "count instructions at accept point", undef],
    //    ["l1_atom_count",                       1,      "off",   "count instructions at accept point", undef],
    //    ["l1_atom_cas_count",                   1,      "off",   "count instructions at accept point", undef],
    //    ["l1_red_count",                        1,      "off",   "count instructions at accept point", undef],
    //    ["l1_dirty_line_eviction",              1,      "off",   "count instructions at accept point", undef],
    //    ["l1_partial_local_cached_st_misses",   1,      "off",   "count instructions at accept point", undef],
    //    ["lsu_rmw_wr_request",                  1,      "off",   "count instructions at accept point", undef],

    { KEPLER_SM_L1C_UNCACHED_GLOBAL_LOAD,          kepler_sm_l1c_uncached_global_load_enc_str_1,  0x00000011, 0x00000000, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_GLOBAL_STORE,                  kepler_sm_l1c_global_store_enc_str_1,          0x00000011, 0x00000001, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_DIRTY_LINE_EVICTION,           kepler_sm_l1c_dirty_line_eviction_enc_str_1,            0x00000011, 0x00000005, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_PARTIAL_LOCAL_CACHED_ST_MISSES,kepler_sm_l1c_partial_local_cached_st_misses_enc_str_1, 0x00000011, 0x00000006, 0x00000001,    PM_UNIT_SMCORE,1 },

    //["GROUP8_LSU" =>
    //    ["local_ld_mem_divergence_replays",     1,      "off",   "local ld is replayed due to divergence", undef],
    //    ["local_st_mem_divergence_replays",     1,      "off",   "local st is replayed due to divergence", undef],
    //    ["shared_ld_mem_divergence_replays",    1,      "off",   "shared ld is replayed due to bank conflict", undef],
    //    ["shared_st_mem_divergence_replays",    1,      "off",   "shared st is replayed due to bank conflict", undef],
    //    ["global_ld_mem_divergence_replays",    1,      "off",   "global ld is replayed due to divergence", undef],
    //    ["global_st_mem_divergence_replays",    1,      "off",   "global st is replayed due to divergence", undef],
    //    ["global_red_mem_divergence_replays",   1,      "off",   "global red is replayed due to divergence", undef],
    //    ["global_atom_mem_divergence_replays",  1,      "off",   "global atom is replayed due to divergence", undef],
    //],
    { KEPLER_SM_L1C_LOCAL_LD_MEM_DIVERGENCE_REPLAYS,   kepler_sm_l1c_local_ld_mem_divergence_replays_enc_str_1,  0x00000008, 0x00000000, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_LOCAL_ST_MEM_DIVERGENCE_REPLAYS,   kepler_sm_l1c_local_st_mem_divergence_replays_enc_str_1,  0x00000008, 0x00000001, 0x00000001,    PM_UNIT_SMCORE,1 },

    //    The signals shared_load/store_replay are broken for GK208. These will be implemented using new signals. LUT mode is being implemented to support these new signals.
    { KEPLER_SHARED_LOAD_REPLAY_INTERNAL,         kepler_shared_load_replay_internal_enc_str_1,        0x00000008, 0x00000002, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SHARED_STORE_REPLAY_INTERNAL,        kepler_shared_store_replay_internal_enc_str_1,       0x00000008, 0x00000003, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_MEM_DIVERGENT_OR_DEFERRED_INSTRUCTION, kepler_sm_mem_divergent_or_deferred_instruction_enc_str_1,      0x00000013, 0x00000004, 0x00000001, PM_UNIT_SMCORE,1 },

    { KEPLER_SM_L1C_GLOBAL_LD_MEM_DIVERGENCE_REPLAYS,  kepler_sm_l1c_global_ld_mem_divergence_replays_enc_str_1, 0x00000008, 0x00000004, 0x00000001,    PM_UNIT_SMCORE,1 },
    { KEPLER_SM_L1C_GLOBAL_ST_MEM_DIVERGENCE_REPLAYS,  kepler_sm_l1c_global_st_mem_divergence_replays_enc_str_1, 0x00000008, 0x00000005, 0x00000001,    PM_UNIT_SMCORE,1 },

    { KEPLER_SM_WARP_ISSUE_ELIGIBLE,                          kepler_sm_warp_issue_eligible_enc_str_1,                        0x00000005, 0x00076543, 0x0000001f, PM_UNIT_SMQCTL,5 },
    { KEPLER_SM_WARP_CANT_ISSUE_NO_INST,                      kepler_sm_warp_cant_issue_no_inst_enc_str_1,                    0x00000006, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_DISPATCH_STALL,               kepler_sm_warp_cant_issue_dispatch_stall_enc_str_1,             0x00000006, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_PARTIALLY_LOADED_SUBTILE,     kepler_sm_warp_cant_issue_partially_loaded_subtile_enc_str_1,   0x00000007, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_SWITCHING_IFB,                kepler_sm_warp_cant_issue_switching_ifb_enc_str_1,              0x00000007, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_WAITING,                      kepler_sm_warp_cant_issue_waiting_enc_str_1,                    0x00000008, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_MULTI_ISSUE,                  kepler_sm_warp_cant_issue_multi_issue_enc_str_1,                0x00000008, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_REPLAY_EXECUTING,             kepler_sm_warp_cant_issue_replay_executing_enc_str_1,           0x00000009, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_TEX_EXECUTING,                kepler_sm_warp_cant_issue_tex_executing_enc_str_1,              0x00000009, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_TEX_DEPENDENCY,               kepler_sm_warp_cant_issue_tex_dependency_enc_str_1,             0x0000000a, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_L1_MISS_DEPENDENCY,           kepler_sm_warp_cant_issue_l1_miss_dependency_enc_str_1,         0x0000000a, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_MSB_FULL,                     kepler_sm_warp_cant_issue_msb_full_enc_str_1,                   0x0000000b, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_IMC_MISS_DEPENDENCY,          kepler_sm_warp_cant_issue_imc_miss_dependency_enc_str_1,        0x0000000b, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4},
    { KEPLER_SM_WARP_CANT_ISSUE_SHADOW_PIPE_THROTTLE,         kepler_sm_warp_cant_issue_shadow_pipe_throttle_enc_str_1,       0x0000000c, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4, },
    { KEPLER_SM_WARP_CANT_ISSUE_TEX_THROTTLE,                 kepler_sm_warp_cant_issue_tex_throttle_enc_str_1,               0x0000000c, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4},
    { KEPLER_SM_WARP_CANT_ISSUE_RIB_THROTTLE,                 kepler_sm_warp_cant_issue_rib_throttle_enc_str_1,               0x0000000d, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_TEX_LOCK_MISMATCH,            kepler_sm_warp_cant_issue_tex_lock_mismatch_enc_str_1,          0x0000000d, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4, },
    { KEPLER_SM_WARP_CANT_ISSUE_MEMBAR,                       kepler_sm_warp_cant_issue_membar_enc_str_1,                     0x0000000e, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_HOLD_MISMATCH,                kepler_sm_warp_cant_issue_hold_mismatch_enc_str_1,              0x0000000f, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_NOT_SELECT,                   kepler_sm_warp_cant_issue_not_select_enc_str_1,                 0x0000000f, 0x00007654, 0x0000000f, PM_UNIT_SMQCTL,4 },
    { KEPLER_SM_WARP_CANT_ISSUE_BARRIER,                      kepler_sm_warp_cant_issue_barrier_enc_str_1,                    0x0000000e, 0x00003210, 0x0000000f, PM_UNIT_SMQCTL,4  },

    { KEPLER_SM_INST_EXECUTED_FAU_XLU_OPS,                    kepler_sm_inst_executed_fau_xlu_ops_enc_str_1,                  0x00000014, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_XLU_PIPE,                         kepler_sm_inst_issued_xlu_pipe_enc_str_1,                       0x00000015, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_SU_PIPE,                          kepler_sm_inst_issued_su_pipe_enc_str_1,                        0x00000015, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FU_PIPE,                          kepler_sm_inst_issued_fu_pipe_enc_str_1,                        0x00000015, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FMAX_PIPE,                        kepler_sm_inst_issued_fmax_pipe_enc_str_1,                      0x00000015, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FMAXLITEW_PIPE,                   kepler_sm_inst_issued_fmaxlitew_pipe_enc_str_1,                 0x00000015, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FAU_PIPE,                         kepler_sm_inst_issued_fau_pipe_enc_str_1,                       0x00000015, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FE_PIPE,                          kepler_sm_inst_issued_fe_pipe_enc_str_1,                        0x00000015, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_BRU_PIPE,                         kepler_sm_inst_issued_bru_pipe_enc_str_1,                       0x00000015, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FMALITEW_PIPE,                    kepler_sm_inst_issued_fmalitew_pipe_enc_str_1,                  0x00000016, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_ADU_PIPE,                         kepler_sm_inst_issued_adu_pipe_enc_str_1,                       0x00000016, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_AGU_PIPE,                         kepler_sm_inst_issued_agu_pipe_enc_str_1,                       0x00000016, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_TEX_PIPE,                         kepler_sm_inst_issued_tex_pipe_enc_str_1,                       0x00000016, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FP64_TO_FMAX_PIPE,                kepler_sm_inst_issued_fp64_to_fmax_pipe_enc_str_1,              0x00000016, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FP64_TO_FMAXLITE_PIPE,            kepler_sm_inst_issued_fp64_to_fmaxlite_pipe_enc_str_1,          0x00000016, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FMA64PLUS_PIPE,                   kepler_sm_inst_issued_fma64plus_pipe_enc_str_1,                 0x00000016, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_ISSUED_FMA64LITE_PIPE,                   kepler_sm_inst_issued_fma64lite_pipe_enc_str_1,                 0x00000016, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_XLU_PIPE,                       kepler_sm_inst_executed_xlu_pipe_enc_str_1,                     0x00000017, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_SU_PIPE,                        kepler_sm_inst_executed_su_pipe_enc_str_1,                      0x00000017, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_FU_PIPE,                        kepler_sm_inst_executed_fu_pipe_enc_str_1,                      0x00000017, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_FMAX_PIPE,                      kepler_sm_inst_executed_fmax_pipe_enc_str_1,                    0x00000017, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_FMAXLITEW_PIPE,                 kepler_sm_inst_executed_fmaxlitew_pipe_enc_str_1,               0x00000017, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_FAU_PIPE,                       kepler_sm_inst_executed_fau_pipe_enc_str_1,                     0x00000017, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_FE_PIPE,                        kepler_sm_inst_executed_fe_pipe_enc_str_1,                      0x00000017, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_BRU_PIPE,                       kepler_sm_inst_executed_bru_pipe_enc_str_1,                     0x00000017, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_FMALITEW_PIPE,                  kepler_sm_inst_executed_fmalitew_pipe_enc_str_1,                0x00000018, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_ADU_PIPE,                       kepler_sm_inst_executed_adu_pipe_enc_str_1,                     0x00000018, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_AGU_PIPE,                       kepler_sm_inst_executed_agu_pipe_enc_str_1,                     0x00000018, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_TEX_PIPE,                       kepler_sm_inst_executed_tex_pipe_enc_str_1,                     0x00000018, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_TCS,                            kepler_sm_inst_executed_tcs_enc_str_1,                          0x00000018, 0x00000054, 0x00000003, PM_UNIT_SMQCTL,2 },
    { KEPLER_SM_INST_EXECUTED_TES,                            kepler_sm_inst_executed_tes_enc_str_1,                          0x00000018, 0x00000076, 0x00000003, PM_UNIT_SMQCTL,2 },
    { KEPLER_SM_INST_EXECUTED_VS,                             kepler_sm_inst_executed_vs_enc_str_1,                           0x00000019, 0x00000010, 0x00000003, PM_UNIT_SMQCTL,2 },
    { KEPLER_SM_INST_EXECUTED_PS,                             kepler_sm_inst_executed_ps_enc_str_1,                           0x00000019, 0x00000032, 0x00000003, PM_UNIT_SMQCTL,2 },
    { KEPLER_SM_INST_EXECUTED_GS,                             kepler_sm_inst_executed_gs_enc_str_1,                           0x00000019, 0x00000054, 0x00000003, PM_UNIT_SMQCTL,2 },
    { KEPLER_SM_INST_EXECUTED_CS,                             kepler_sm_inst_executed_cs_enc_str_1,                           0x00000019, 0x00000076, 0x00000003, PM_UNIT_SMQCTL,2 },
    { KEPLER_SM_INST_EXECUTED_LSU_SULDGA_B,                   kepler_sm_inst_executed_lsu_suldga_b_enc_str_1,                 0x0000001a, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_SULDGA_P,                   kepler_sm_inst_executed_lsu_suldga_p_enc_str_1,                 0x0000001a, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_SUSTGA_B,                   kepler_sm_inst_executed_lsu_sustga_b_enc_str_1,                 0x0000001a, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_SUSTGA_P,                   kepler_sm_inst_executed_lsu_sustga_p_enc_str_1,                 0x0000001a, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_ATOM_CAS,                   kepler_sm_inst_executed_lsu_atom_cas_enc_str_1,                 0x0000001a, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_LDS_U_128,                  kepler_sm_inst_executed_lsu_lds_u_128_enc_str_1,                0x0000001a, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_ALD,                        kepler_sm_inst_executed_lsu_ald_enc_str_1,                      0x0000001b, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_INST_EXECUTED_LSU_AST,                        kepler_sm_inst_executed_lsu_ast_enc_str_1,                      0x0000001b, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_ICC_HIT,                                      kepler_sm_icc_hit_enc_str_1,                                    0x00000005, 0x00000000, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_ICC_TRUE_MISS,                                kepler_sm_icc_true_miss_enc_str_1,                              0x00000005, 0x00000001, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_ICC_COVERED_MISS,                             kepler_sm_icc_covered_miss_enc_str_1,                           0x00000005, 0x00000002, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_ICC_PREFETCHES,                               kepler_sm_icc_prefetches_enc_str_1,                             0x00000005, 0x00000004, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_PRT_PENDING_ENTRIES,                          kepler_sm_prt_pending_entries_enc_str_1,                        0x0000000b, 0x06543210, 0x0000007f, PM_UNIT_SMCORE,7 },
    { KEPLER_SM_CANT_DISPATCH_REGISTER_INTERLOCK,             kepler_sm_cant_dispatch_register_interlock_enc_str_1,           0x00000010, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_CANT_DISPATCH_MEMORY_INTERLOCK,               kepler_sm_cant_dispatch_memory_interlock_enc_str_1,             0x00000010, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_CANT_DISPATCH_REGISTER_READ,                  kepler_sm_cant_dispatch_register_read_enc_str_1,                0x00000010, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_CANT_DISPATCH_REGISTER_WRITE,                 kepler_sm_cant_dispatch_register_write_enc_str_1,               0x00000010, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_CANT_DISPATCH_CRS_SPILL_FILL,                 kepler_sm_cant_dispatch_crs_spill_fill_enc_str_1,               0x00000010, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_CANT_DISPATCH_ADU_F5_RF_READ,                 kepler_sm_cant_dispatch_adu_f5_rf_read_enc_str_1,               0x00000010, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_CANT_DISPATCH_BRU_STALL,                      kepler_sm_cant_dispatch_bru_stall_enc_str_1,                    0x00000010, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,1 },
    { KEPLER_SM_GLOBAL_RED_MEM_DIVERGENCE_REPLAYS_INTERNAL,   kepler_sm_global_red_mem_divergence_replays_internal_enc_str_1,     0x00000008, 0x00000006, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_GLOBAL_ATOM_MEM_DIVERGENCE_REPLAYS_INTERNAL,  kepler_sm_global_atom_mem_divergence_replays_internal_enc_str_1,    0x00000008, 0x00000007, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_GLOBAL_RED_TRANSACTIONS,                      kepler_sm_global_red_transactions_enc_str_1,                    0x0000000f, 0x00000002, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_GLOBAL_ATOM_TRANSACTIONS,                     kepler_sm_global_atom_transactions_enc_str_1,                   0x0000000f, 0x00000003, 0x00000001, PM_UNIT_SMCORE,1 },
    { KEPLER_SM_GLOBAL_ATOM_CAS_TRANSACTIONS,                 kepler_sm_global_atom_cas_transactions_enc_str_1,               0x0000000f, 0x00000004, 0x00000001, PM_UNIT_SMCORE,1 },

    { INVALID_PM_SIGNAL_NEW,            "",                       0xffffffff, 0x00000000, 0x00000000,     PM_UNIT_MAX,0 }
};

// clock-domain HUB0 is NOT present on GK110

PerfSignalHwpm PerfSignalTableGK104_sys0[] = {
    //Hub TLB signals

    //mmu_hub_tlb_hit      = hubmmu2pm_hub_hub_tlb_hit                                      count # of PTE hits in hub TLB
    //mmu_hub_tlb_miss     = (hubmmu2pm_hub_hub_tlb_miss & !hubmmu2pm_hub_hub_tlb_hit)      count # of PTE misses in hub TLB
    { KEPLER_MMU_HUB_TLB_HIT,    kepler_mmu_hub_tlb_hit_enc_str_1,    0x00000004, 0x0000AAAA, 0x4e,    PM_UNIT_HUBMMU,1 },
    { KEPLER_MMU_HUB_TLB_MISS_INT,   kepler_mmu_hub_tlb_miss_int_enc_str_1,   0x00000004, 0x0000AAAA, 0x4f,    PM_UNIT_HUBMMU,1 },

    // mmu_fill_pte_hit    = hubmmu2pm_hub_fill_pte_hit                                     "count # of PTE hits in mmu fill unit"
    // mmu_fill_pte_miss   = (hubmmu2pm_hub_fill_pte_miss & !hubmmu2pm_hub_fill_pte_hit)    "count # of PTE misses in mmu fill unit"
    { KEPLER_MMU_FILL_PTE_HIT,   kepler_mmu_fill_pte_hit_enc_str_1,   0x00000006, 0x0000AAAA, 0x4e,    PM_UNIT_HUBMMU,1 },
    { KEPLER_MMU_FILL_PTE_MISS_INT,  kepler_mmu_fill_pte_miss_int_enc_str_1,  0x00000006, 0x0000AAAA, 0x4f,    PM_UNIT_HUBMMU,1 },

    // mmu_fill_pde_hit    = hubmmu2pm_hub_fill_pde_hit                                     "count # of PDE hits in mmu fill unit"
    // mmu_fill_pde_miss   = hubmmu2pm_hub_fill_pde_miss                                    "count # of PDE misses in mmu fill unit"
    { KEPLER_MMU_FILL_PDE_HIT,   kepler_mmu_fill_pde_hit_enc_str_1,   0x00000006, 0x0000AAAA, 0x50,    PM_UNIT_HUBMMU,1 },
    { KEPLER_MMU_FILL_PDE_MISS,  kepler_mmu_fill_pde_miss_enc_str_1,  0x00000006, 0x0000AAAA, 0x51,    PM_UNIT_HUBMMU,1 },

    //__hub_gpcl2_tlb_hit  = hubmmu2pm_hub_gpcl2_tlb_hit                                    count # of PTE hits in gpcl2 TLB
    //__hub_gpcl2_tlb_miss = hubmmu2pm_hub_gpcl2_tlb_miss                                   count # of PTE misses in gpcl2 TLB
    { KEPLER_MMU_GPCL2_TLB_HIT,  kepler_mmu_gpcl2_tlb_hit_enc_str_1,  0x00000003, 0x0000AAAA, 0x4e,    PM_UNIT_HUBMMU,1 },
    { KEPLER_MMU_GPCL2_TLB_MISS_INT, kepler_mmu_gpcl2_tlb_miss_int_enc_str_1, 0x00000003, 0x0000AAAA, 0x4f,    PM_UNIT_HUBMMU,1 },

    { INVALID_PM_SIGNAL_NEW,     "",                     0xffffffff, 0x00000000, 0x00,     PM_UNIT_MAX,0}
};

PerfSignalHwpmExpt PerfSignalTableGK104_sys0_expt[] = {
    //Hub TLB signals

    //mmu_hub_tlb_miss     = (hubmmu2pm_hub_hub_tlb_miss & !hubmmu2pm_hub_hub_tlb_hit)      count # of PTE misses in hub TLB
    { KEPLER_MMU_HUB_TLB_MISS, kepler_mmu_hub_tlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_MMU_HUB_TLB_HIT, KEPLER_MMU_HUB_TLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},

    // mmu_fill_pte_miss   = (hubmmu2pm_hub_fill_pte_miss & !hubmmu2pm_hub_fill_pte_hit)    "count # of PTE misses in mmu fill unit"
    { KEPLER_MMU_FILL_PTE_MISS, kepler_mmu_fill_pte_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_MMU_FILL_PTE_HIT, KEPLER_MMU_FILL_PTE_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},

    //__hub_gpcl2_tlb_miss = (hubmmu2pm_hub_gpcl2_tlb_miss & !hubmmu2pm_hub_gpcl2_tlb_hit)  count # of PTE misses in gpcl2 TLB
    { KEPLER_MMU_GPCL2_TLB_MISS, kepler_mmu_gpcl2_tlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_MMU_GPCL2_TLB_HIT, KEPLER_MMU_GPCL2_TLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},

    //GK208 doesn't have L2 TLB
    { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000,  0x00}
};

PerfSignalHwpm PerfSignalTableGK208_sys0[] = {
    //Hub TLB signals

    //mmu_hub_tlb_hit      = hubmmu2pm_hub_hub_tlb_hit                                      count # of PTE hits in hub TLB
    //mmu_hub_tlb_miss     = (hubmmu2pm_hub_hub_tlb_miss & !hubmmu2pm_hub_hub_tlb_hit)      count # of PTE misses in hub TLB
    { KEPLER_MMU_HUB_TLB_HIT,    kepler_mmu_hub_tlb_hit_enc_str_1,    0x00000004, 0x0000AAAA, 0x4e,    PM_UNIT_HUBMMU,1 },
    { KEPLER_MMU_HUB_TLB_MISS_INT,   kepler_mmu_hub_tlb_miss_int_enc_str_1,   0x00000004, 0x0000AAAA, 0x4f,    PM_UNIT_HUBMMU,1 },

    // mmu_fill_pte_hit    = hubmmu2pm_hub_fill_pte_hit                                     "count # of PTE hits in mmu fill unit"
    // mmu_fill_pte_miss   = (hubmmu2pm_hub_fill_pte_miss & !hubmmu2pm_hub_fill_pte_hit)    "count # of PTE misses in mmu fill unit"
    { KEPLER_MMU_FILL_PTE_HIT,   kepler_mmu_fill_pte_hit_enc_str_1,   0x00000006, 0x0000AAAA, 0x4e,    PM_UNIT_HUBMMU,1 },
    { KEPLER_MMU_FILL_PTE_MISS_INT,  kepler_mmu_fill_pte_miss_int_enc_str_1,  0x00000006, 0x0000AAAA, 0x4f,    PM_UNIT_HUBMMU,1 },

    // mmu_fill_pde_hit    = hubmmu2pm_hub_fill_pde_hit                                     "count # of PDE hits in mmu fill unit"
    // mmu_fill_pde_miss   = hubmmu2pm_hub_fill_pde_miss                                    "count # of PDE misses in mmu fill unit"
    { KEPLER_MMU_FILL_PDE_HIT,   kepler_mmu_fill_pde_hit_enc_str_1,   0x00000006, 0x0000AAAA, 0x50,    PM_UNIT_HUBMMU,1 },
    { KEPLER_MMU_FILL_PDE_MISS,  kepler_mmu_fill_pde_miss_enc_str_1,  0x00000006, 0x0000AAAA, 0x51,    PM_UNIT_HUBMMU,1 },

    //GK208 doesn't have L2 TLB
    { INVALID_PM_SIGNAL_NEW,     "",                     0xffffffff, 0x00000000, 0x00,     PM_UNIT_MAX,0}
};

PerfSignalHwpmExpt PerfSignalTableGK208_sys0_expt[] = {
    //Hub TLB signals

    //mmu_hub_tlb_miss     = (hubmmu2pm_hub_hub_tlb_miss & !hubmmu2pm_hub_hub_tlb_hit)      count # of PTE misses in hub TLB
    { KEPLER_MMU_HUB_TLB_MISS, kepler_mmu_hub_tlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_MMU_HUB_TLB_HIT, KEPLER_MMU_HUB_TLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},

    // mmu_fill_pte_miss   = (hubmmu2pm_hub_fill_pte_miss & !hubmmu2pm_hub_fill_pte_hit)    "count # of PTE misses in mmu fill unit"
    { KEPLER_MMU_FILL_PTE_MISS, kepler_mmu_fill_pte_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {KEPLER_MMU_FILL_PTE_HIT, KEPLER_MMU_FILL_PTE_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},

    //GK208 doesn't have L2 TLB
    { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000,  0x00}
};

PerfSignalSmpc PerfSignalTableGK110_nopTrigSwCounters[] = {
    // TO DO: Change this table and make it more suitable for sw counters as most of the fields are not used
    { KEPLER_SW_COUNTER_GLD8BIT_INST,    kepler_sw_counter_gld8bit_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_GLD16BIT_INST,   kepler_sw_counter_gld16bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_GLD32BIT_INST,   kepler_sw_counter_gld32bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_GLD64BIT_INST,   kepler_sw_counter_gld64bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_GLD128BIT_INST,  kepler_sw_counter_gld128bit_inst_enc_str_1,  0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_GST8BIT_INST,    kepler_sw_counter_gst8bit_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_GST16BIT_INST,   kepler_sw_counter_gst16bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_GST32BIT_INST,   kepler_sw_counter_gst32bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_GST64BIT_INST,   kepler_sw_counter_gst64bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_GST128BIT_INST,  kepler_sw_counter_gst128bit_inst_enc_str_1,  0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    // LDG signals are for GK11x only
    { KEPLER_SW_COUNTER_NC_GLD8BIT_INST,    kepler_sw_counter_nc_gld8bit_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_NC_GLD16BIT_INST,   kepler_sw_counter_nc_gld16bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_NC_GLD32BIT_INST,   kepler_sw_counter_nc_gld32bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_NC_GLD64BIT_INST,   kepler_sw_counter_nc_gld64bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_NC_GLD128BIT_INST,  kepler_sw_counter_nc_gld128bit_inst_enc_str_1,  0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },

    { INVALID_SW_COUNTER,               "",           0xffffffff, 0x00000000, 0x00000000,                   PM_UNIT_MAX,0 }
};

PerfSignalTableNew PerfSignalTableGKSwCounters_sld_sst[] = {
    // Software counters work for all Kepler chips
    { KEPLER_SW_COUNTER_SLD8BIT_INST,    kepler_sw_counter_sld8bit_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_SLD16BIT_INST,   kepler_sw_counter_sld16bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_SLD32BIT_INST,   kepler_sw_counter_sld32bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_SLD64BIT_INST,   kepler_sw_counter_sld64bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_SLD128BIT_INST,  kepler_sw_counter_sld128bit_inst_enc_str_1,  0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_SST8BIT_INST,    kepler_sw_counter_sst8bit_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_SST16BIT_INST,   kepler_sw_counter_sst16bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_SST32BIT_INST,   kepler_sw_counter_sst32bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_SST64BIT_INST,   kepler_sw_counter_sst64bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_SST128BIT_INST,  kepler_sw_counter_sst128bit_inst_enc_str_1,  0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { INVALID_SW_COUNTER,               "",                                         0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX,0 }
};

PerfSignalTableNew PerfSignalTableGKSwCounters_unique_gld_gst[] = {
    //Software counters work for all kepler chips 
    { KEPLER_SW_COUNTER_UNIQUE_GLD1BYTE_REQUESTED,    kepler_sw_counter_unique_gld_1byte_requested_enc_str_1,    0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_UNIQUE_GLD4BYTE_REQUESTED,   kepler_sw_counter_unique_gld_4byte_requested_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_UNIQUE_GLD8BYTE_REQUESTED,   kepler_sw_counter_unique_gld_8byte_requested_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_UNIQUE_GLD16BYTE_REQUESTED,  kepler_sw_counter_unique_gld_16byte_requested_enc_str_1,  0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_UNIQUE_GST1BYTE_REQUESTED,    kepler_sw_counter_unique_gst_1byte_requested_enc_str_1,    0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_UNIQUE_GST4BYTE_REQUESTED,   kepler_sw_counter_unique_gst_4byte_requested_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_UNIQUE_GST8BYTE_REQUESTED,   kepler_sw_counter_unique_gst_8byte_requested_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_UNIQUE_GST16BYTE_REQUESTED,  kepler_sw_counter_unique_gst_16byte_requested_enc_str_1,  0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { INVALID_SW_COUNTER,                       "",                                                 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0}
};

PerfSignalSmpcExpt PerfSignalTableGK110_LutModeCounters[] = {
    { KEPLER_LUT_COUNTER_SUB_GLD32BIT_INST,  kepler_lut_counter_sub_gld32bit_inst_enc_str_1,   PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SUB_SIZE_32,KEPLER_SM_GENERIC_LOAD,KEPLER_SM_LSU_INST_PREDICATED_OFF,INVALID_PM_SIGNAL_NEW},  (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE))},
    { KEPLER_LUT_COUNTER_SUB_GST32BIT_INST,  kepler_lut_counter_sub_gst32bit_inst_enc_str_1,   PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SUB_SIZE_32,KEPLER_SM_GENERIC_STORE,KEPLER_SM_LSU_INST_PREDICATED_OFF,INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE))},
    { KEPLER_LUT_COUNTER_GLD32BIT_INST,      kepler_lut_counter_gld32bit_inst_enc_str_1,  PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SIZE_32,KEPLER_SM_GENERIC_LOAD,KEPLER_SM_LSU_INST_PREDICATED_OFF,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE))},
    { KEPLER_LUT_COUNTER_GST32BIT_INST,      kepler_lut_counter_gst32bit_inst_enc_str_1,  PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SIZE_32,KEPLER_SM_GENERIC_STORE,KEPLER_SM_LSU_INST_PREDICATED_OFF,INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE))},
    { KEPLER_LUT_COUNTER_GLD64BIT_INST,      kepler_lut_counter_gld64bit_inst_enc_str_1,  PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SIZE_64,KEPLER_SM_GENERIC_LOAD,KEPLER_SM_LSU_INST_PREDICATED_OFF,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE))},
    { KEPLER_LUT_COUNTER_GST64BIT_INST,      kepler_lut_counter_gst64bit_inst_enc_str_1,  PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SIZE_64,KEPLER_SM_GENERIC_STORE,KEPLER_SM_LSU_INST_PREDICATED_OFF,INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE))},
    { KEPLER_LUT_COUNTER_GLD128BIT_INST,     kepler_lut_counter_gld128bit_inst_enc_str_1, PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SIZE_128,KEPLER_SM_GENERIC_LOAD,KEPLER_SM_LSU_INST_PREDICATED_OFF,INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE))},
    { KEPLER_LUT_COUNTER_GST128BIT_INST,     kepler_lut_counter_gst128bit_inst_enc_str_1, PM_UNIT_SMQCTL,     {KEPLER_SM_INST_EXECUTED_LSU_SIZE_128,KEPLER_SM_GENERIC_STORE,KEPLER_SM_LSU_INST_PREDICATED_OFF,INVALID_PM_SIGNAL_NEW},    (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE))},

    { INVALID_PM_SIGNAL_NEW,               "", PM_UNIT_MAX,           {INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW} , TRUTH_TABLE_FUNCTION_ALL_FALSE}
};

PerfSignalSmpc PerfSignalTableGKSwCounters_nop_trig[] = {
    // TO DO: Change this table and make it more suitable for sw counters as most of the fields are not used
    { KEPLER_SW_COUNTER_FADD_INST,  kepler_sw_counter_fadd_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_FMUL_INST,  kepler_sw_counter_fmul_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_FFMA_INST,  kepler_sw_counter_ffma_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_DADD_INST,  kepler_sw_counter_dadd_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_DMUL_INST,  kepler_sw_counter_dmul_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_DFMA_INST,  kepler_sw_counter_dfma_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_COS_INST,   kepler_sw_counter_cos_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_EX2_INST,   kepler_sw_counter_ex2_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_LG2_INST,   kepler_sw_counter_lg2_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_RCP_INST,   kepler_sw_counter_rcp_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_RSQ_INST,   kepler_sw_counter_rsq_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_SIN_INST,   kepler_sw_counter_sin_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },

    { INVALID_SW_COUNTER,           "",             0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 }
};

PerfSignalSmpc PerfSignalTableGKSwCounters_transactions[] = {
    { KEPLER_SW_COUNTER_L2_GLOBAL_WRITE_L1_SECTOR_QUERIES,         kepler_sw_counter_l2_global_write_l1_sector_queries_enc_str_1,            0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { KEPLER_SW_COUNTER_L2_UCACHED_GLOBAL_READ_L1_SECTOR_QUERIES,  kepler_sw_counter_l2_ucached_global_read_l1_sector_queries_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { INVALID_SW_COUNTER,                     "",                           0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 }
};

PerfSignalTableNew PerfSignalTableGKswCounters_ld_st_inst[] = {
    // TO DO: Change this table and make it more suitable for sw counters as most of the fields are not used
    { KEPLER_INTERNAL_SW_COUNTER_GLD8BIT_INST,    kepler_internal_sw_counter_gld8bit_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,  0x00,   KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0},      PM_MAX_CHIPLET_TYPES },
    { KEPLER_INTERNAL_SW_COUNTER_GLD16BIT_INST,   kepler_internal_sw_counter_gld16bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,  0x00,   KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0},      PM_MAX_CHIPLET_TYPES },
    { KEPLER_INTERNAL_SW_COUNTER_GLD32BIT_INST,   kepler_internal_sw_counter_gld32bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,  0x00,   KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0},      PM_MAX_CHIPLET_TYPES },
    { KEPLER_INTERNAL_SW_COUNTER_GLD64BIT_INST,   kepler_internal_sw_counter_gld64bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,  0x00,   KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0},      PM_MAX_CHIPLET_TYPES },
    { KEPLER_INTERNAL_SW_COUNTER_GLD128BIT_INST,  kepler_internal_sw_counter_gld128bit_inst_enc_str_1,  0xffffffff, 0x00000000, 0x00000000,  0x00,   KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0},      PM_MAX_CHIPLET_TYPES },
    { KEPLER_INTERNAL_SW_COUNTER_GST8BIT_INST,    kepler_internal_sw_counter_gst8bit_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,  0x00,   KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0},      PM_MAX_CHIPLET_TYPES },
    { KEPLER_INTERNAL_SW_COUNTER_GST16BIT_INST,   kepler_internal_sw_counter_gst16bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,  0x00,   KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0},      PM_MAX_CHIPLET_TYPES },
    { KEPLER_INTERNAL_SW_COUNTER_GST32BIT_INST,   kepler_internal_sw_counter_gst32bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,  0x00,   KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0},      PM_MAX_CHIPLET_TYPES },
    { KEPLER_INTERNAL_SW_COUNTER_GST64BIT_INST,   kepler_internal_sw_counter_gst64bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,  0x00,   KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0},      PM_MAX_CHIPLET_TYPES },
    { KEPLER_INTERNAL_SW_COUNTER_GST128BIT_INST,  kepler_internal_sw_counter_gst128bit_inst_enc_str_1,  0xffffffff, 0x00000000, 0x00000000,  0x00,   KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST,    PM_UNIT_MAX,    {0,0,0,0,0,0,0,0},      PM_MAX_CHIPLET_TYPES },
    { INVALID_SW_COUNTER,               "",           0xffffffff, 0x00000000, 0x00000000,  0x00,   KEPLER_CLK_DOMAIN_MAX,                   PM_UNIT_MAX,    {0,0,0,0,0,0,0,0} }
};

PerfSignalSmpc PerfSignalTableGKSwCounters_instrClass[] = {
    { KEPLER_SW_COUNTER_INSTR_CLASS_FP_32,                       kepler_sw_counter_instr_class_fp_32_enc_str_1                      , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_INSTR_CLASS_FP_64,                       kepler_sw_counter_instr_class_fp_64_enc_str_1                      , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_INSTR_CLASS_INTEGER,                     kepler_sw_counter_instr_class_integer_enc_str_1                    , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_INSTR_CLASS_BIT_CONVERT,                 kepler_sw_counter_instr_class_bit_convert_enc_str_1                , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_INSTR_CLASS_CONTROL,                     kepler_sw_counter_instr_class_control_enc_str_1                    , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_INSTR_CLASS_COMPUTE_LD_ST,               kepler_sw_counter_instr_class_compute_ld_st_enc_str_1              , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_INSTR_CLASS_MISCELLANEOUS,               kepler_sw_counter_instr_class_miscellaneous_enc_str_1              , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_INSTR_CLASS_INTER_THREAD_COMMUNICATION,  kepler_sw_counter_instr_class_inter_thread_communication_enc_str_1 , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { INVALID_SW_COUNTER,           "",             0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 }
};

PerfSignalSmpc PerfSignalTableGKSwCounters_genericLdStCounters[] = {
    { KEPLER_SW_COUNTER_GENERIC_SHARED_LOAD,           kepler_sw_counter_generic_shared_ld_enc_str_1          , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_GENERIC_SHARED_STORE,          kepler_sw_counter_generic_shared_st_enc_str_1          , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_GENERIC_LOCAL_LOAD,            kepler_sw_counter_generic_local_ld_enc_str_1           , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_GENERIC_LOCAL_STORE,           kepler_sw_counter_generic_local_st_enc_str_1           , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_GENERIC_GLOBAL_LOAD,           kepler_sw_counter_generic_global_ld_enc_str_1          , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { KEPLER_SW_COUNTER_GENERIC_GLOBAL_STORE,          kepler_sw_counter_generic_global_st_enc_str_1          , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { INVALID_SW_COUNTER,           "",                0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 }
};

CUdomainData domainTableGK104[] = {
    {KEPLER_CLK_DOMAIN_GK104_GPCTPC,               kepler_clk_domain_gk104_gpctpc_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_HWPM,           {{(void *)PerfSignalTableGK104_gpctpc, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGK104_gpctpc_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}}, 0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 2},
    {KEPLER_CLK_DOMAIN_GK104_LTC0,                 kepler_clk_domain_gk104_ltc0_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_HWPM,       {{(void *)PerfSignalTableGK104_ltc0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGK104_ltc0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}},  0,  0,  0,  PM_CHIPLET_TYPE_FBP, 0, 0, 2},
    // Creating separate domain  for sw counters
    // sw counters may also have separate domain types based on type of instrumentation
    {KEPLER_SW_COUNTERS_DOMAIN_GK104_NOPTRIG,      kepler_sw_counters_domain_gk104_noptrig_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW,     {{(void *)PerfSignalTableGK104_nopTrigSwCounters, PERF_SIG_TABLE_TYPE_SMPC}},        0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {KEPLER_CLK_DOMAIN_GK104_SM0,                  kepler_clk_domain_gk104_sm0_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_SMPERF,         {{(void *)PerfSignalTableGK104_sm0, PERF_SIG_TABLE_TYPE_SMPC}, {(void*)PerfSignalTableGK104_LutModeCounters, PERF_SIG_TABLE_TYPE_LUT}}, 0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 2},
    {KEPLER_SW_DOMAIN_GK104_PPA_NOPTRIG_FLOPS,     kepler_sw_domain_gk104_ppa_noptrig_flops_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{(void *)PerfSignalTableGKSwCounters_nop_trig, PERF_SIG_TABLE_TYPE_SMPC}},          0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {KEPLER_SW_DOMAIN_GK104_PPA_NOPTRIG_TRANSACTIONS,      kepler_sw_domain_gk104_ppa_noptrig_transactions_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{(void *)PerfSignalTableGKSwCounters_transactions, PERF_SIG_TABLE_TYPE_SMPC}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {KEPLER_SW_DOMAIN_GK104_PPA_NOPTRIG_INSTR_CLASS,  kepler_sw_domain_gk104_ppa_noptrig_instr_class_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{(void *)PerfSignalTableGKSwCounters_instrClass, PERF_SIG_TABLE_TYPE_SMPC}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {KEPLER_SW_DOMAIN_GK104_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS,  kepler_sw_domain_gk104_ppa_noptrig_generic_counters_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{(void *)PerfSignalTableGKSwCounters_genericLdStCounters, PERF_SIG_TABLE_TYPE_SMPC}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {KEPLER_SW_DOMAIN_GK104_PPA_NOPTRIG_SLD_SST,   kepler_sw_domain_gk104_ppa_noptrig_sld_sst_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGKSwCounters_sld_sst, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {KEPLER_SW_DOMAIN_GK104_PPA_NOPTRIG_UNIQUE_GLD_GST,   kepler_sw_domain_gk104_ppa_noptrig_unique_gld_gst_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGKSwCounters_unique_gld_gst, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    // Internal domains starts from here ======================
    {KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST,         kepler_sw_counters_domain_ld_st_inst_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_SW,             {{(void *)PerfSignalTableGKswCounters_ld_st_inst, PERF_SIG_TABLE_TYPE_COMMON}},        0,  0,  0,  PM_MAX_CHIPLET_TYPES, 0, 0, 1},
    {KEPLER_CLK_DOMAIN_GK104_SYS0,                 kepler_clk_domain_gk104_sys0_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPM,           {{(void *)PerfSignalTableGK104_sys0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGK104_sys0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}},  0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 2},
    {KEPLER_CLK_DOMAIN_GK104_GPC0,                 kepler_clk_domain_gk104_gpc0_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPM,           {{(void *)PerfSignalTableGK104_gpc0,PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGK104_gpc0_expt,PERF_SIG_TABLE_TYPE_HWPM_EXPT}},                     0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 2},
};

CUdomainData domainTableGK110[] = {
    {KEPLER_CLK_DOMAIN_GK110_GPCTPC,               kepler_clk_domain_gk110_gpctpc_enc_str_1,     CUPROF_EVENT_COLLECTION_METHOD_HWPM,            {{(void *)PerfSignalTableGK110_gpctpc, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGK110_gpctpc_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}},                   0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 2},
    {KEPLER_CLK_DOMAIN_GK110_LTC0,                 kepler_clk_domain_gk110_ltc0_enc_str_1,     CUPROF_EVENT_COLLECTION_METHOD_HWPM,       {{(void *)PerfSignalTableGK110_ltc0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGK104_ltc0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}}, 0,  0,  0,  PM_CHIPLET_TYPE_FBP, 0, 0, 2},
    {KEPLER_SW_COUNTERS_DOMAIN_GK110_NOPTRIG,      kepler_sw_counters_domain_gk110_noptrig_enc_str_1,     CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW,      {{(void *)PerfSignalTableGK110_nopTrigSwCounters, PERF_SIG_TABLE_TYPE_SMPC}},        0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {KEPLER_CLK_DOMAIN_GK110_SM0,                  kepler_clk_domain_gk110_sm0_enc_str_1,     CUPROF_EVENT_COLLECTION_METHOD_SMPERF,          {{(void *)PerfSignalTableGK110_sm0, PERF_SIG_TABLE_TYPE_SMPC}, {(void*)PerfSignalTableGK110_LutModeCounters, PERF_SIG_TABLE_TYPE_LUT}}, 0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 2},
    {KEPLER_SW_DOMAIN_GK110_PPA_NOPTRIG_FLOPS,     kepler_sw_domain_gk110_ppa_noptrig_flops_enc_str_1,     CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,  {{(void *)PerfSignalTableGKSwCounters_nop_trig, PERF_SIG_TABLE_TYPE_SMPC}},          0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {KEPLER_SW_DOMAIN_GK110_PPA_NOPTRIG_TRANSACTIONS,      kepler_sw_domain_gk110_ppa_noptrig_transactions_enc_str_1,     CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,  {{(void *)PerfSignalTableGKSwCounters_transactions, PERF_SIG_TABLE_TYPE_SMPC}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {KEPLER_SW_DOMAIN_GK110_PPA_NOPTRIG_INSTR_CLASS,  kepler_sw_domain_gk110_ppa_noptrig_instr_class_enc_str_2,     CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,  {{(void *)PerfSignalTableGKSwCounters_instrClass, PERF_SIG_TABLE_TYPE_SMPC}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {KEPLER_SW_DOMAIN_GK110_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS,  kepler_sw_domain_gk110_ppa_noptrig_generic_counters_enc_str_2,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{(void *)PerfSignalTableGKSwCounters_genericLdStCounters, PERF_SIG_TABLE_TYPE_SMPC}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {KEPLER_SW_DOMAIN_GK110_PPA_NOPTRIG_SLD_SST,   kepler_sw_domain_gk110_ppa_noptrig_sld_sst_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGKSwCounters_sld_sst, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {KEPLER_SW_DOMAIN_GK110_PPA_NOPTRIG_UNIQUE_GLD_GST,   kepler_sw_domain_gk110_ppa_noptrig_unique_gld_gst_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGKSwCounters_unique_gld_gst, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    // Internal domains starts from here ======================
    {KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST,         kepler_sw_counters_domain_ld_st_inst_enc_str_2,   CUPROF_EVENT_COLLECTION_METHOD_SW,              {{(void *)PerfSignalTableGKswCounters_ld_st_inst, PERF_SIG_TABLE_TYPE_COMMON}},    0,  0,  0,  PM_MAX_CHIPLET_TYPES, 0, 0, 1},
    {KEPLER_CLK_DOMAIN_GK110_SYS0,                 kepler_clk_domain_gk110_sys0_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_HWPM,            {{(void *)PerfSignalTableGK104_sys0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGK104_sys0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}},                     0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 2},
    {KEPLER_CLK_DOMAIN_GK110_GPC0,                 kepler_clk_domain_gk110_gpc0_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_HWPM,            {{(void *)PerfSignalTableGK110_gpc0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGK110_gpc0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}},                     0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 2},
};

CUdomainData domainTableGK208[] = {
    {KEPLER_CLK_DOMAIN_GK208_GPCTPC,               kepler_clk_domain_gk208_gpctpc_enc_str_1,     CUPROF_EVENT_COLLECTION_METHOD_HWPM,            {{(void *)PerfSignalTableGK208_gpctpc, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGK208_gpctpc_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}},                   0,  0,  0,  PM_CHIPLET_TYPE_GPC,  0, 0, 2},
    {KEPLER_CLK_DOMAIN_GK208_LTC0,                 kepler_clk_domain_gk208_ltc0_enc_str_1,     CUPROF_EVENT_COLLECTION_METHOD_HWPM,       {{(void *)PerfSignalTableGK208_ltc0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGK208_ltc0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}},  0,  0,  0,  PM_CHIPLET_TYPE_FBP,  0, 0, 2},
    {KEPLER_SW_COUNTERS_DOMAIN_GK208_NOPTRIG,      kepler_sw_counters_domain_gk208_noptrig_enc_str_1,     CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW,      {{(void *)PerfSignalTableGK110_nopTrigSwCounters, PERF_SIG_TABLE_TYPE_SMPC}},        0,  0,  0,  PM_CHIPLET_TYPE_GPC,  0, 0, 1},
    {KEPLER_CLK_DOMAIN_GK208_SM0,                  kepler_clk_domain_gk208_sm0_enc_str_1,     CUPROF_EVENT_COLLECTION_METHOD_SMPERF,          {{(void *)PerfSignalTableGK208_sm0, PERF_SIG_TABLE_TYPE_SMPC}, {(void*)PerfSignalTableGK208_LutModeCounters, PERF_SIG_TABLE_TYPE_LUT}},  0,  0,  0,  PM_CHIPLET_TYPE_GPC,  0, 0, 2},
    {KEPLER_SW_DOMAIN_GK208_PPA_NOPTRIG_FLOPS,     kepler_sw_domain_gk208_ppa_noptrig_flops_enc_str_1,     CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,  {{(void *)PerfSignalTableGKSwCounters_nop_trig, PERF_SIG_TABLE_TYPE_SMPC}},          0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {KEPLER_SW_DOMAIN_GK208_PPA_NOPTRIG_TRANSACTIONS,      kepler_sw_domain_gk208_ppa_noptrig_transactions_enc_str_1,     CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,  {{(void *)PerfSignalTableGKSwCounters_transactions, PERF_SIG_TABLE_TYPE_SMPC}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {KEPLER_SW_DOMAIN_GK208_PPA_NOPTRIG_INSTR_CLASS,  kepler_sw_domain_gk208_ppa_noptrig_instr_class_enc_str_3,     CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,  {{(void *)PerfSignalTableGKSwCounters_instrClass, PERF_SIG_TABLE_TYPE_SMPC}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {KEPLER_SW_DOMAIN_GK208_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS,  kepler_sw_domain_gk208_ppa_noptrig_generic_counters_enc_str_3,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{(void *)PerfSignalTableGKSwCounters_genericLdStCounters, PERF_SIG_TABLE_TYPE_SMPC}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {KEPLER_SW_DOMAIN_GK110_PPA_NOPTRIG_SLD_SST,   kepler_sw_domain_gk110_ppa_noptrig_sld_sst_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGKSwCounters_sld_sst, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {KEPLER_SW_DOMAIN_GK110_PPA_NOPTRIG_UNIQUE_GLD_GST,   kepler_sw_domain_gk110_ppa_noptrig_unique_gld_gst_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGKSwCounters_unique_gld_gst, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    // Internal domains starts from here ======================
    {KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST,         kepler_sw_counters_domain_ld_st_inst_enc_str_3,   CUPROF_EVENT_COLLECTION_METHOD_SW,              {{(void *)PerfSignalTableGKswCounters_ld_st_inst, PERF_SIG_TABLE_TYPE_COMMON}},        0,  0,  0,  PM_MAX_CHIPLET_TYPES,  0, 0, 1},
    {KEPLER_CLK_DOMAIN_GK208_SYS0,                 kepler_clk_domain_gk208_sys0_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_HWPM,       {{(void *)PerfSignalTableGK208_sys0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGK208_sys0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}},  0,  0,  0,  PM_CHIPLET_TYPE_SYS,  0, 0, 2},
};

CUdomainData domainTableGK20A[] = {
    {KEPLER_CLK_DOMAIN_GK20A_GPCTPC,               kepler_clk_domain_gk20a_gpctpc_enc_str_1,     CUPROF_EVENT_COLLECTION_METHOD_HWPM,            {{(void *)PerfSignalTableGK20A_gpctpc, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGK208_gpctpc_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}},                   0,  0,  0,  PM_CHIPLET_TYPE_GPC,  0, 0, 2},
    {KEPLER_CLK_DOMAIN_GK20A_FBP0,                 kepler_clk_domain_gk20a_fbp0_enc_str_1,     CUPROF_EVENT_COLLECTION_METHOD_HWPM,       {{(void *)PerfSignalTableGK20A_ltc0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGK20A_ltc0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}},  0,  0,  0,  PM_CHIPLET_TYPE_FBP,  0, 0, 2},
    {KEPLER_SW_COUNTERS_DOMAIN_GK208_NOPTRIG,      kepler_sw_counters_domain_gk208_noptrig_enc_str_2,     CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW,      {{(void *)PerfSignalTableGK110_nopTrigSwCounters, PERF_SIG_TABLE_TYPE_SMPC}},        0,  0,  0,  PM_CHIPLET_TYPE_GPC,  0, 0, 1},
    {KEPLER_CLK_DOMAIN_GK208_SM0,                  kepler_clk_domain_gk208_sm0_enc_str_2,     CUPROF_EVENT_COLLECTION_METHOD_SMPERF,          {{(void *)PerfSignalTableGK208_sm0, PERF_SIG_TABLE_TYPE_SMPC}, {(void*)PerfSignalTableGK208_LutModeCounters, PERF_SIG_TABLE_TYPE_LUT}},  0,  0,  0,  PM_CHIPLET_TYPE_GPC,  0, 0, 2},
    {KEPLER_SW_DOMAIN_GK208_PPA_NOPTRIG_FLOPS,     kepler_sw_domain_gk208_ppa_noptrig_flops_enc_str_2,     CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,  {{(void *)PerfSignalTableGKSwCounters_nop_trig, PERF_SIG_TABLE_TYPE_SMPC}},          0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {KEPLER_CLK_DOMAIN_GK20A_MC0,                  kepler_clk_domain_gk20a_mc0_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_HWPM,       {{(void *)PerfSignalTableGK20A_mc0, PERF_SIG_TABLE_TYPE_HWPM}},  0,  0,  0,  PM_CHIPLET_TYPE_SYS,  0, 0, 1},
    {KEPLER_SW_DOMAIN_GK20A_PPA_NOPTRIG_TRANSACTIONS,      kepler_sw_domain_gk20a_ppa_noptrig_transactions_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{(void *)PerfSignalTableGKSwCounters_transactions, PERF_SIG_TABLE_TYPE_SMPC}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {KEPLER_SW_DOMAIN_GK20A_PPA_NOPTRIG_INSTR_CLASS,  kepler_sw_domain_gk20a_ppa_noptrig_instr_class_enc_str_4,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,  {{(void *)PerfSignalTableGKSwCounters_instrClass, PERF_SIG_TABLE_TYPE_SMPC}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {KEPLER_SW_DOMAIN_GK20A_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS,  kepler_sw_domain_gk20a_ppa_noptrig_generic_counters_enc_str_4,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{(void *)PerfSignalTableGKSwCounters_genericLdStCounters, PERF_SIG_TABLE_TYPE_SMPC}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {KEPLER_SW_DOMAIN_GK110_PPA_NOPTRIG_SLD_SST,   kepler_sw_domain_gk110_ppa_noptrig_sld_sst_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGKSwCounters_sld_sst, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {KEPLER_SW_DOMAIN_GK110_PPA_NOPTRIG_UNIQUE_GLD_GST,   kepler_sw_domain_gk110_ppa_noptrig_unique_gld_gst_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGKSwCounters_unique_gld_gst, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    // Internal domains starts from here ======================
    {KEPLER_SW_COUNTERS_DOMAIN_LD_ST_INST,         kepler_sw_counters_domain_ld_st_inst_enc_str_4,   CUPROF_EVENT_COLLECTION_METHOD_SW,              {{(void *)PerfSignalTableGKswCounters_ld_st_inst, PERF_SIG_TABLE_TYPE_COMMON}},        0,  0,  0,  PM_MAX_CHIPLET_TYPES,  0, 0, 1},
    {KEPLER_CLK_DOMAIN_GK20A_SYS0,                 kepler_clk_domain_gk20a_sys0_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_HWPM,       {{(void *)PerfSignalTableGK20A_sys0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGK208_sys0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}},  0,  0,  0,  PM_CHIPLET_TYPE_SYS,  0, 0, 2},
};

SignalDescriptionTable pKeplerSignalDescriptionArray[] = {
    {KEPLER_SM_LOCAL_LOAD, kepler_sm_local_load_enc_str_1, kepler_sm_local_load_enc_str_5, CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_local_load_enc_str_6},
    {KEPLER_SM_LOCAL_STORE, kepler_sm_local_store_enc_str_1, kepler_sm_local_store_enc_str_5, CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_local_store_enc_str_6},
    {KEPLER_SM_GENERIC_LOAD, kepler_sm_generic_load_enc_str_1, kepler_sm_generic_load_enc_str_5, CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_generic_load_enc_str_6},
    {KEPLER_SM_GENERIC_STORE, kepler_sm_generic_store_enc_str_1, kepler_sm_generic_store_enc_str_5, CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_generic_store_enc_str_6},
    {KEPLER_SM_SHARED_LOAD, kepler_sm_shared_load_enc_str_1, kepler_sm_shared_load_enc_str_5, CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_shared_load_enc_str_6},
    {KEPLER_SM_SHARED_STORE, kepler_sm_shared_store_enc_str_1, kepler_sm_shared_store_enc_str_5, CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_shared_store_enc_str_6},

    {KEPLER_SM_UNIQUE_BRANCHES, kepler_sm_unique_branches_enc_str_1, kepler_sm_unique_branches_enc_str_2, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_sm_unique_branches_enc_str_6},
    {KEPLER_SM_DIVERGED_BRANCHES, kepler_sm_diverged_branches_enc_str_1, kepler_sm_diverged_branches_enc_str_5, CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_sm_diverged_branches_enc_str_6},

    {KEPLER_SM_ACTIVE_CYCLES,kepler_sm_active_cycles_enc_str_1, kepler_sm_active_cycles_enc_str_5, CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_sm_active_cycles_enc_str_6},
    {KEPLER_SM_ACTIVE_CYCLES_QUAD,kepler_sm_active_cycles_quad_enc_str_1, kepler_sm_active_cycles_quad_enc_str_5, CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_sm_active_cycles_quad_enc_str_6},

    {KEPLER_SM_THREAD_INST_EXECUTED, kepler_sm_thread_inst_executed_enc_str_1, kepler_sm_thread_inst_executed_enc_str_5, CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_hwpm_thread_inst_executed_enc_str_6},
    {KEPLER_SM_TEX_QUAD_FETCHES,  kepler_sm_tex_quad_fetches_enc_str_1, kepler_sm_tex_quad_fetches_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_sm_tex_quad_fetches_enc_str_2},

    {KEPLER_SM_INST_ISSUED_1, kepler_sm_inst_issued_1_enc_str_1,  kepler_sm_inst_issued_1_enc_str_5, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_inst_issued_1_enc_str_6},
    {KEPLER_SM_INST_ISSUED_2, kepler_sm_inst_issued_2_enc_str_1,  kepler_sm_inst_issued_2_enc_str_5, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_inst_issued_2_enc_str_6},

    {KEPLER_SM_INST_EXECUTED, kepler_sm_inst_executed_enc_str_1, kepler_sm_inst_executed_enc_str_5, CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_hwpm_inst_executed_enc_str_6},
    {KEPLER_SM_LSU_INST_PREDICATED_OFF, kepler_sm_lsu_inst_predicated_off_enc_str_1, kepler_sm_lsu_inst_predicated_off_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_sm_lsu_inst_predicated_off_enc_str_5},
    {KEPLER_SM_NOT_PREDICATED_OFF_THREAD_INST_EXECUTED, kepler_sm_not_predicated_off_thread_inst_executed_enc_str_1, kepler_sm_not_predicated_off_thread_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_sm_not_predicated_off_thread_inst_executed_enc_str_6},

    {KEPLER_SM_WARPS_LAUNCHED, kepler_sm_warps_launched_enc_str_1, kepler_sm_warps_launched_enc_str_5, CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_hwpm_warps_launched_enc_str_7},

#if CU_PROFILE_SM_QUAD_SIGNALS_VIA_HWPM
    {KEPLER_SCH_WARPS_LAUNCHED_Q0, kepler_sch_warps_launched_q0_enc_str_1, kepler_sch_warps_launched_q0_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_sch_warps_launched_q0_enc_str_4},
    {KEPLER_SCH_WARPS_LAUNCHED_Q1, kepler_sch_warps_launched_q1_enc_str_1, kepler_sch_warps_launched_q1_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_sch_warps_launched_q1_enc_str_4},
    {KEPLER_SCH_WARPS_LAUNCHED_Q2, kepler_sch_warps_launched_q2_enc_str_1, kepler_sch_warps_launched_q2_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_sch_warps_launched_q2_enc_str_4},
    {KEPLER_SCH_WARPS_LAUNCHED_Q3, kepler_sch_warps_launched_q3_enc_str_1, kepler_sch_warps_launched_q3_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_sch_warps_launched_q3_enc_str_4},
#endif

    {KEPLER_SM_THREADS_LAUNCHED, kepler_sm_threads_launched_enc_str_1, kepler_sm_threads_launched_enc_str_6, CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_hwpm_threads_launched_enc_str_7},

    {KEPLER_SM_ACTIVE_WARPS, kepler_sm_active_warps_enc_str_1, kepler_hwpm_active_warps_enc_str_6, CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_hwpm_active_warps_enc_str_7},

    {KEPLER_TEX0_CACHE_SECTOR_QUERIES, kepler_tex0_cache_sector_queries_enc_str_1, kepler_tex0_cache_sector_queries_enc_str_6, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex0_cache_sector_queries_enc_str_7},
    {KEPLER_TEX1_CACHE_SECTOR_QUERIES, kepler_tex1_cache_sector_queries_enc_str_1, kepler_tex1_cache_sector_queries_enc_str_6, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex1_cache_sector_queries_enc_str_7},
    {KEPLER_TEX2_CACHE_SECTOR_QUERIES, kepler_tex2_cache_sector_queries_enc_str_1, kepler_tex2_cache_sector_queries_enc_str_4, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex2_cache_sector_queries_enc_str_5},
    {KEPLER_TEX3_CACHE_SECTOR_QUERIES, kepler_tex3_cache_sector_queries_enc_str_1, kepler_tex3_cache_sector_queries_enc_str_4, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex3_cache_sector_queries_enc_str_5},
    {KEPLER_TEX0_CACHE_SECTOR_MISSES, kepler_tex0_cache_sector_misses_enc_str_1, kepler_tex0_cache_sector_misses_enc_str_6, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex0_cache_sector_misses_enc_str_7},
    {KEPLER_TEX1_CACHE_SECTOR_MISSES, kepler_tex1_cache_sector_misses_enc_str_1, kepler_tex1_cache_sector_misses_enc_str_6, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex1_cache_sector_misses_enc_str_7},
    {KEPLER_TEX2_CACHE_SECTOR_MISSES, kepler_tex2_cache_sector_misses_enc_str_1, kepler_tex2_cache_sector_misses_enc_str_4, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex2_cache_sector_misses_enc_str_5},
    {KEPLER_TEX3_CACHE_SECTOR_MISSES, kepler_tex3_cache_sector_misses_enc_str_1, kepler_tex3_cache_sector_misses_enc_str_4, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex3_cache_sector_misses_enc_str_5},

    {KEPLER_SM_CTA_LAUNCHED, kepler_sm_cta_launched_enc_str_1, kepler_sm_cta_launched_enc_str_5, CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_hwpm_cta_launched_enc_str_8},

    // L1C Signals
    {KEPLER_SM_L1C_LOCAL_LOAD_HIT, kepler_sm_l1c_local_load_hit_enc_str_1, kepler_sm_l1c_local_load_hit_enc_str_5, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_local_load_hit_enc_str_7},
    {KEPLER_SM_L1C_LOCAL_LOAD_MISS, kepler_sm_l1c_local_load_miss_enc_str_1, kepler_sm_l1c_local_load_miss_enc_str_5, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_local_load_miss_enc_str_7},
    {KEPLER_SM_L1C_LOCAL_STORE_HIT, kepler_sm_l1c_local_store_hit_enc_str_1, kepler_sm_l1c_local_store_hit_enc_str_5, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_local_store_hit_enc_str_7},
    {KEPLER_SM_L1C_LOCAL_STORE_MISS, kepler_sm_l1c_local_store_miss_enc_str_1, kepler_sm_l1c_local_store_miss_enc_str_5, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_local_store_miss_enc_str_7},
    {KEPLER_SM_L1C_GLOBAL_LOAD_HIT, kepler_sm_l1c_global_load_hit_enc_str_1, kepler_sm_l1c_global_load_hit_enc_str_5, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_global_load_hit_enc_str_7},
    {KEPLER_SM_L1C_GLOBAL_LOAD_MISS, kepler_sm_l1c_global_load_miss_enc_str_1, kepler_sm_l1c_global_load_miss_enc_str_5, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_global_load_miss_enc_str_7},
    {KEPLER_SM_L1C_UNCACHED_GLOBAL_LOAD, kepler_sm_l1c_uncached_global_load_enc_str_1, kepler_sm_l1c_uncached_global_load_enc_str_5, CUPROF_EVENT_CATEGORY_MEMORY,kepler_hwpm_l1c_uncached_global_load_enc_str_7},
    {KEPLER_SM_L1C_GLOBAL_STORE, kepler_sm_l1c_global_store_enc_str_1, kepler_sm_l1c_global_store_enc_str_5, CUPROF_EVENT_CATEGORY_MEMORY,kepler_hwpm_l1c_global_store_enc_str_7},
    {KEPLER_SM_L1C_SHARED_LOAD_BANK_CONFLICT, kepler_sm_l1c_shared_load_bank_conflict_enc_str_1, kepler_sm_l1c_shared_load_bank_conflict_enc_str_5, CUPROF_EVENT_CATEGORY_MEMORY, kepler_hwpm_l1c_shared_load_bank_conflict_enc_str_7},
    {KEPLER_SM_L1C_SHARED_STORE_BANK_CONFLICT, kepler_sm_l1c_shared_store_bank_conflict_enc_str_1, kepler_sm_l1c_shared_store_bank_conflict_enc_str_5, CUPROF_EVENT_CATEGORY_MEMORY, kepler_hwpm_l1c_shared_store_bank_conflict_enc_str_7},
    {KEPLER_SM_L1C_LOCAL_LD_MEM_DIVERGENCE_REPLAYS, kepler_sm_l1c_local_ld_mem_divergence_replays_enc_str_1, kepler_sm_l1c_local_ld_mem_divergence_replays_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_l1c_local_ld_mem_divergence_replays_enc_str_6},
    {KEPLER_SM_L1C_LOCAL_ST_MEM_DIVERGENCE_REPLAYS, kepler_sm_l1c_local_st_mem_divergence_replays_enc_str_1, kepler_sm_l1c_local_st_mem_divergence_replays_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_l1c_local_st_mem_divergence_replays_enc_str_6},
    {KEPLER_SM_L1C_GLOBAL_LD_MEM_DIVERGENCE_REPLAYS, kepler_sm_l1c_global_ld_mem_divergence_replays_enc_str_1, kepler_sm_l1c_global_ld_mem_divergence_replays_enc_str_2, CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_l1c_global_ld_mem_divergence_replays_enc_str_6},
    {KEPLER_SM_L1C_GLOBAL_ST_MEM_DIVERGENCE_REPLAYS, kepler_sm_l1c_global_st_mem_divergence_replays_enc_str_1, kepler_sm_l1c_global_st_mem_divergence_replays_enc_str_2, CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_l1c_global_st_mem_divergence_replays_enc_str_6},

    {KEPLER_SM_L1C_LOCAL_LOAD_TRANSACTIONS, kepler_sm_l1c_local_load_transactions_enc_str_1, kepler_sm_l1c_local_load_transactions_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_local_load_transactions_enc_str_7},
    {KEPLER_SM_L1C_LOCAL_STORE_TRANSACTIONS, kepler_sm_l1c_local_store_transactions_enc_str_1, kepler_sm_l1c_local_store_transactions_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_local_store_transactions_enc_str_7},
    {KEPLER_SM_L1C_SHARED_LOAD_TRANSACTIONS, kepler_sm_l1c_shared_load_transactions_enc_str_1, kepler_sm_l1c_shared_load_transactions_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_shared_load_transactions_enc_str_7},
    {KEPLER_SM_L1C_SHARED_STORE_TRANSACTIONS, kepler_sm_l1c_shared_store_transactions_enc_str_1, kepler_sm_l1c_shared_store_transactions_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_shared_store_transactions_enc_str_7},
    {KEPLER_SM_L1C_GLOBAL_LOAD_TRANSACTIONS, kepler_sm_l1c_global_load_transactions_enc_str_1, kepler_sm_l1c_global_load_transactions_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_global_load_transactions_enc_str_7},
    {KEPLER_SM_L1C_GLOBAL_STORE_TRANSACTIONS, kepler_sm_l1c_global_store_transactions_enc_str_1, kepler_sm_l1c_global_store_transactions_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_global_store_transactions_enc_str_7},

    { KEPLER_SM_L1C_ATOM_COUNT,     kepler_sm_l1c_atom_count_enc_str_1, kepler_sm_l1c_atom_count_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_sm_l1c_atom_count_enc_str_6},
    { KEPLER_SM_L1C_GRED_COUNT,     kepler_sm_l1c_gred_count_enc_str_1, kepler_sm_l1c_gred_count_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_sm_l1c_gred_count_enc_str_6},

    {KEPLER_HWPM_THREADS_LAUNCHED, kepler_hwpm_threads_launched_enc_str_1, kepler_hwpm_threads_launched_enc_str_6, CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_hwpm_threads_launched_enc_str_7},
    {KEPLER_HWPM_CTA_LAUNCHED, kepler_hwpm_cta_launched_enc_str_1, kepler_hwpm_cta_launched_enc_str_7, CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_hwpm_cta_launched_enc_str_8},
#if CU_PROFILE_SM_SIGNALS_VIA_HWPM
    {KEPLER_HWPM_WARPS_LAUNCHED, kepler_hwpm_warps_launched_enc_str_1, kepler_hwpm_warps_launched_enc_str_6, CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_hwpm_warps_launched_enc_str_7},
    {KEPLER_HWPM_ACTIVE_CYCLES, kepler_hwpm_active_cycles_enc_str_1, kepler_hwpm_active_cycles_enc_str_6, CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_hwpm_active_cycles_enc_str_7},
    {KEPLER_HWPM_ACTIVE_WARPS, kepler_hwpm_active_warps_enc_str_1, kepler_hwpm_active_warps_enc_str_6, CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_hwpm_active_warps_enc_str_7},
    {KEPLER_HWPM_L1C_LOCAL_LOAD_HIT, kepler_hwpm_l1c_local_load_hit_enc_str_1, kepler_hwpm_l1c_local_load_hit_enc_str_6, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_local_load_hit_enc_str_7},
    {KEPLER_HWPM_L1C_LOCAL_LOAD_MISS, kepler_hwpm_l1c_local_load_miss_enc_str_1, kepler_hwpm_l1c_local_load_miss_enc_str_6, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_local_load_miss_enc_str_7},
    {KEPLER_HWPM_L1C_LOCAL_STORE_HIT, kepler_hwpm_l1c_local_store_hit_enc_str_1, kepler_hwpm_l1c_local_store_hit_enc_str_6, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_local_store_hit_enc_str_7},
    {KEPLER_HWPM_L1C_LOCAL_STORE_MISS, kepler_hwpm_l1c_local_store_miss_enc_str_1, kepler_hwpm_l1c_local_store_miss_enc_str_6, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_local_store_miss_enc_str_7},
    {KEPLER_HWPM_L1C_GLOBAL_LOAD_HIT, kepler_hwpm_l1c_global_load_hit_enc_str_1, kepler_hwpm_l1c_global_load_hit_enc_str_6, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_global_load_hit_enc_str_7},
    {KEPLER_HWPM_L1C_GLOBAL_LOAD_MISS, kepler_hwpm_l1c_global_load_miss_enc_str_1, kepler_hwpm_l1c_global_load_miss_enc_str_6, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_global_load_miss_enc_str_7},
    {KEPLER_HWPM_L1C_UNCACHED_GLOBAL_LOAD, kepler_hwpm_l1c_uncached_global_load_enc_str_1, kepler_hwpm_l1c_uncached_global_load_enc_str_6, CUPROF_EVENT_CATEGORY_MEMORY,kepler_hwpm_l1c_uncached_global_load_enc_str_7},
    {KEPLER_HWPM_L1C_GLOBAL_STORE, kepler_hwpm_l1c_global_store_enc_str_1, kepler_hwpm_l1c_global_store_enc_str_6, CUPROF_EVENT_CATEGORY_MEMORY,kepler_hwpm_l1c_global_store_enc_str_7},
    {KEPLER_HWPM_L1C_SHARED_LOAD_BANK_CONFLICT, kepler_hwpm_l1c_shared_load_bank_conflict_enc_str_1, kepler_hwpm_l1c_shared_load_bank_conflict_enc_str_6, CUPROF_EVENT_CATEGORY_MEMORY, kepler_hwpm_l1c_shared_load_bank_conflict_enc_str_7},
    {KEPLER_HWPM_L1C_SHARED_STORE_BANK_CONFLICT, kepler_hwpm_l1c_shared_store_bank_conflict_enc_str_1, kepler_hwpm_l1c_shared_store_bank_conflict_enc_str_6, CUPROF_EVENT_CATEGORY_MEMORY, kepler_hwpm_l1c_shared_store_bank_conflict_enc_str_7},

    {KEPLER_HWPM_L1C_LOCAL_LOAD_TRANSACTIONS, kepler_hwpm_l1c_local_load_transactions_enc_str_1, kepler_hwpm_l1c_local_load_transactions_enc_str_6, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_local_load_transactions_enc_str_7},
    {KEPLER_HWPM_L1C_LOCAL_STORE_TRANSACTIONS, kepler_hwpm_l1c_local_store_transactions_enc_str_1, kepler_hwpm_l1c_local_store_transactions_enc_str_6, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_local_store_transactions_enc_str_7},
    {KEPLER_HWPM_L1C_SHARED_LOAD_TRANSACTIONS, kepler_hwpm_l1c_shared_load_transactions_enc_str_1, kepler_hwpm_l1c_shared_load_transactions_enc_str_6, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_shared_load_transactions_enc_str_7},
    {KEPLER_HWPM_L1C_SHARED_STORE_TRANSACTIONS, kepler_hwpm_l1c_shared_store_transactions_enc_str_1, kepler_hwpm_l1c_shared_store_transactions_enc_str_6, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_shared_store_transactions_enc_str_7},
    {KEPLER_HWPM_L1C_GLOBAL_LOAD_TRANSACTIONS, kepler_hwpm_l1c_global_load_transactions_enc_str_1, kepler_hwpm_l1c_global_load_transactions_enc_str_6, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_global_load_transactions_enc_str_7},
    {KEPLER_HWPM_L1C_GLOBAL_STORE_TRANSACTIONS, kepler_hwpm_l1c_global_store_transactions_enc_str_1, kepler_hwpm_l1c_global_store_transactions_enc_str_6, CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_l1c_global_store_transactions_enc_str_7},

    {KEPLER_HWPM_INST_ISSUED_1, kepler_hwpm_inst_issued_1_enc_str_1,  kepler_hwpm_inst_issued_1_enc_str_5, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_inst_issued_1_enc_str_6},
    {KEPLER_HWPM_INST_ISSUED_2, kepler_hwpm_inst_issued_2_enc_str_1,  kepler_hwpm_inst_issued_2_enc_str_5, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_inst_issued_2_enc_str_6},

    {KEPLER_HWPM_NOP_TRIG_00, kepler_hwpm_nop_trig_00_enc_str_1, kepler_hwpm_nop_trig_00_enc_str_2, CUPROF_EVENT_CATEGORY_PROF_TRIG,kepler_hwpm_nop_trig_00_enc_str_3},
    {KEPLER_HWPM_NOP_TRIG_01, kepler_hwpm_nop_trig_01_enc_str_1, kepler_hwpm_nop_trig_01_enc_str_2, CUPROF_EVENT_CATEGORY_PROF_TRIG,kepler_hwpm_nop_trig_00_enc_str_3},
    {KEPLER_HWPM_NOP_TRIG_02, kepler_hwpm_nop_trig_02_enc_str_1, kepler_hwpm_nop_trig_02_enc_str_2, CUPROF_EVENT_CATEGORY_PROF_TRIG,kepler_hwpm_nop_trig_00_enc_str_3},
    {KEPLER_HWPM_NOP_TRIG_03, kepler_hwpm_nop_trig_03_enc_str_1, kepler_hwpm_nop_trig_03_enc_str_2, CUPROF_EVENT_CATEGORY_PROF_TRIG,kepler_hwpm_nop_trig_00_enc_str_3},
    {KEPLER_HWPM_NOP_TRIG_04, kepler_hwpm_nop_trig_04_enc_str_1, kepler_hwpm_nop_trig_04_enc_str_2, CUPROF_EVENT_CATEGORY_PROF_TRIG,kepler_hwpm_nop_trig_00_enc_str_3},
    {KEPLER_HWPM_NOP_TRIG_05, kepler_hwpm_nop_trig_05_enc_str_1, kepler_hwpm_nop_trig_05_enc_str_2, CUPROF_EVENT_CATEGORY_PROF_TRIG,kepler_hwpm_nop_trig_00_enc_str_3},
    {KEPLER_HWPM_NOP_TRIG_06, kepler_hwpm_nop_trig_06_enc_str_1, kepler_hwpm_nop_trig_06_enc_str_2, CUPROF_EVENT_CATEGORY_PROF_TRIG,kepler_hwpm_nop_trig_00_enc_str_3},
    {KEPLER_HWPM_NOP_TRIG_07, kepler_hwpm_nop_trig_07_enc_str_1, kepler_hwpm_nop_trig_07_enc_str_2, CUPROF_EVENT_CATEGORY_PROF_TRIG,kepler_hwpm_nop_trig_00_enc_str_3},
    {KEPLER_HWPM_INST_EXECUTED, kepler_hwpm_inst_executed_enc_str_1, kepler_hwpm_inst_executed_enc_str_5,CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_inst_executed_enc_str_6},
    {KEPLER_HWPM_THREAD_INST_EXECUTED, kepler_hwpm_thread_inst_executed_enc_str_1, kepler_hwpm_thread_inst_executed_enc_str_5,    CUPROF_EVENT_CATEGORY_CACHE,kepler_hwpm_thread_inst_executed_enc_str_6},

    {KEPLER_HWPM_SHARED_LOAD, kepler_hwpm_shared_load_enc_str_1, kepler_hwpm_shared_load_enc_str_5, CUPROF_EVENT_CATEGORY_MEMORY,kepler_hwpm_shared_load_enc_str_6},
    {KEPLER_HWPM_SHARED_STORE, kepler_hwpm_shared_store_enc_str_1, kepler_hwpm_shared_store_enc_str_5, CUPROF_EVENT_CATEGORY_MEMORY,kepler_hwpm_shared_store_enc_str_6},
    {KEPLER_HWPM_GENERIC_LOAD, kepler_hwpm_generic_load_enc_str_1, kepler_hwpm_generic_load_enc_str_5, CUPROF_EVENT_CATEGORY_MEMORY,kepler_hwpm_generic_load_enc_str_6},
    {KEPLER_HWPM_GENERIC_STORE, kepler_hwpm_generic_store_enc_str_1, kepler_hwpm_generic_store_enc_str_5, CUPROF_EVENT_CATEGORY_MEMORY,kepler_hwpm_generic_store_enc_str_6},
    {KEPLER_HWPM_LOCAL_LOAD, kepler_hwpm_local_load_enc_str_1, kepler_hwpm_local_load_enc_str_5, CUPROF_EVENT_CATEGORY_MEMORY,kepler_hwpm_local_load_enc_str_6},
    {KEPLER_HWPM_LOCAL_STORE, kepler_hwpm_local_store_enc_str_1, kepler_hwpm_local_store_enc_str_5, CUPROF_EVENT_CATEGORY_MEMORY,kepler_hwpm_local_store_enc_str_6},
#endif
    {KEPLER_SM_NOP_TRIG_00, kepler_sm_nop_trig_00_enc_str_1, kepler_sm_nop_trig_00_enc_str_5, CUPROF_EVENT_CATEGORY_PROF_TRIG,kepler_sm_nop_trig_00_enc_str_6},
    {KEPLER_SM_NOP_TRIG_01, kepler_sm_nop_trig_01_enc_str_1, kepler_sm_nop_trig_01_enc_str_5, CUPROF_EVENT_CATEGORY_PROF_TRIG,kepler_sm_nop_trig_00_enc_str_6},
    {KEPLER_SM_NOP_TRIG_02, kepler_sm_nop_trig_02_enc_str_1, kepler_sm_nop_trig_02_enc_str_5, CUPROF_EVENT_CATEGORY_PROF_TRIG,kepler_sm_nop_trig_00_enc_str_6},
    {KEPLER_SM_NOP_TRIG_03, kepler_sm_nop_trig_03_enc_str_1, kepler_sm_nop_trig_03_enc_str_5, CUPROF_EVENT_CATEGORY_PROF_TRIG,kepler_sm_nop_trig_00_enc_str_6},
    {KEPLER_SM_NOP_TRIG_04, kepler_sm_nop_trig_04_enc_str_1, kepler_sm_nop_trig_04_enc_str_5, CUPROF_EVENT_CATEGORY_PROF_TRIG,kepler_sm_nop_trig_00_enc_str_6},
    {KEPLER_SM_NOP_TRIG_05, kepler_sm_nop_trig_05_enc_str_1, kepler_sm_nop_trig_05_enc_str_5, CUPROF_EVENT_CATEGORY_PROF_TRIG,kepler_sm_nop_trig_00_enc_str_6},
    {KEPLER_SM_NOP_TRIG_06, kepler_sm_nop_trig_06_enc_str_1, kepler_sm_nop_trig_06_enc_str_5, CUPROF_EVENT_CATEGORY_PROF_TRIG,kepler_sm_nop_trig_00_enc_str_6},
    {KEPLER_SM_NOP_TRIG_07, kepler_sm_nop_trig_07_enc_str_1, kepler_sm_nop_trig_07_enc_str_5, CUPROF_EVENT_CATEGORY_PROF_TRIG,kepler_sm_nop_trig_00_enc_str_6},

    {KEPLER_SM_NOP_TRIG_08, kepler_sm_nop_trig_08_enc_str_1, kepler_sm_nop_trig_08_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, kepler_sm_nop_trig_00_enc_str_6},
    {KEPLER_SM_NOP_TRIG_09, kepler_sm_nop_trig_09_enc_str_1, kepler_sm_nop_trig_09_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, kepler_sm_nop_trig_00_enc_str_6},
    {KEPLER_SM_NOP_TRIG_10, kepler_sm_nop_trig_10_enc_str_1, kepler_sm_nop_trig_10_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, kepler_sm_nop_trig_00_enc_str_6},
    {KEPLER_SM_NOP_TRIG_11, kepler_sm_nop_trig_11_enc_str_1, kepler_sm_nop_trig_11_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, kepler_sm_nop_trig_00_enc_str_6},
    {KEPLER_SM_NOP_TRIG_12, kepler_sm_nop_trig_12_enc_str_1, kepler_sm_nop_trig_12_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, kepler_sm_nop_trig_00_enc_str_6},
    {KEPLER_SM_NOP_TRIG_13, kepler_sm_nop_trig_13_enc_str_1, kepler_sm_nop_trig_13_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, kepler_sm_nop_trig_00_enc_str_6},
    {KEPLER_SM_NOP_TRIG_14, kepler_sm_nop_trig_14_enc_str_1, kepler_sm_nop_trig_14_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, kepler_sm_nop_trig_00_enc_str_6},
    {KEPLER_SM_NOP_TRIG_15, kepler_sm_nop_trig_15_enc_str_1, kepler_sm_nop_trig_15_enc_str_1, CUPROF_EVENT_CATEGORY_PROF_TRIG, kepler_sm_nop_trig_00_enc_str_6},

    {KEPLER_FB_SUBP0_DRAMC_READ, kepler_fb_subp0_dramc_read_enc_str_1, kepler_fb_subp0_dramc_read_enc_str_5, CUPROF_EVENT_CATEGORY_MEMORY,kepler_fb1_subp0_dramc_read_enc_str_3},
    {KEPLER_FB_SUBP1_DRAMC_READ, kepler_fb_subp1_dramc_read_enc_str_1, kepler_fb_subp1_dramc_read_enc_str_5, CUPROF_EVENT_CATEGORY_MEMORY,kepler_fb1_subp1_dramc_read_enc_str_3},
    {KEPLER_FB_SUBP0_DRAMC_WRITE, kepler_fb_subp0_dramc_write_enc_str_1, kepler_fb_subp0_dramc_write_enc_str_5, CUPROF_EVENT_CATEGORY_MEMORY,kepler_fb1_subp0_dramc_write_enc_str_3},
    {KEPLER_FB_SUBP1_DRAMC_WRITE, kepler_fb_subp1_dramc_write_enc_str_1, kepler_fb_subp1_dramc_write_enc_str_5, CUPROF_EVENT_CATEGORY_MEMORY,kepler_fb1_subp1_dramc_write_enc_str_3},

    {KEPLER_FB1_SUBP0_DRAMC_READ, kepler_fb1_subp0_dramc_read_enc_str_1, kepler_fb1_subp0_dramc_read_enc_str_2, CUPROF_EVENT_CATEGORY_MEMORY,kepler_fb1_subp0_dramc_read_enc_str_3},
    {KEPLER_FB1_SUBP1_DRAMC_READ, kepler_fb1_subp1_dramc_read_enc_str_1, kepler_fb1_subp1_dramc_read_enc_str_2, CUPROF_EVENT_CATEGORY_MEMORY,kepler_fb1_subp1_dramc_read_enc_str_3},
    {KEPLER_FB1_SUBP0_DRAMC_WRITE, kepler_fb1_subp0_dramc_write_enc_str_1, kepler_fb1_subp0_dramc_write_enc_str_2, CUPROF_EVENT_CATEGORY_MEMORY,kepler_fb1_subp0_dramc_write_enc_str_3},
    {KEPLER_FB1_SUBP1_DRAMC_WRITE, kepler_fb1_subp1_dramc_write_enc_str_1, kepler_fb1_subp1_dramc_write_enc_str_2, CUPROF_EVENT_CATEGORY_MEMORY,kepler_fb1_subp1_dramc_write_enc_str_3},

    {KEPLER_LTC0_WRITE_MISS_SECTORS, kepler_ltc0_write_miss_sectors_enc_str_1, kepler_ltc0_write_miss_sectors_enc_str_6, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc0_write_miss_sectors_enc_str_7},
    {KEPLER_LTC1_WRITE_MISS_SECTORS, kepler_ltc1_write_miss_sectors_enc_str_1, kepler_ltc1_write_miss_sectors_enc_str_5, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc1_write_miss_sectors_enc_str_6},
    {KEPLER_LTC2_WRITE_MISS_SECTORS, kepler_ltc2_write_miss_sectors_enc_str_1, kepler_ltc2_write_miss_sectors_enc_str_4, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc2_write_miss_sectors_enc_str_5},
    {KEPLER_LTC3_WRITE_MISS_SECTORS, kepler_ltc3_write_miss_sectors_enc_str_1, kepler_ltc3_write_miss_sectors_enc_str_4, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc3_write_miss_sectors_enc_str_5},
    {KEPLER_LTC0_READ_MISS_SECTORS, kepler_ltc0_read_miss_sectors_enc_str_1, kepler_ltc0_read_miss_sectors_enc_str_6, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc0_read_miss_sectors_enc_str_7},
    {KEPLER_LTC1_READ_MISS_SECTORS, kepler_ltc1_read_miss_sectors_enc_str_1, kepler_ltc1_read_miss_sectors_enc_str_5, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc1_read_miss_sectors_enc_str_6},
    {KEPLER_LTC2_READ_MISS_SECTORS, kepler_ltc2_read_miss_sectors_enc_str_1, kepler_ltc2_read_miss_sectors_enc_str_4, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc2_read_miss_sectors_enc_str_5},
    {KEPLER_LTC3_READ_MISS_SECTORS, kepler_ltc3_read_miss_sectors_enc_str_1, kepler_ltc3_read_miss_sectors_enc_str_4, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc3_read_miss_sectors_enc_str_5},

    {KEPLER_LTC0_WRITE_L1_SECTORS_FBP, kepler_ltc0_write_l1_sectors_fbp_enc_str_1, kepler_ltc0_write_l1_sectors_fbp_enc_str_5, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc0_write_l1_sectors_fbp_enc_str_6},
    {KEPLER_LTC1_WRITE_L1_SECTORS_FBP, kepler_ltc1_write_l1_sectors_fbp_enc_str_1, kepler_ltc1_write_l1_sectors_fbp_enc_str_4, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc1_write_l1_sectors_fbp_enc_str_5},
    {KEPLER_LTC2_WRITE_L1_SECTORS_FBP, kepler_ltc2_write_l1_sectors_fbp_enc_str_1, kepler_ltc2_write_l1_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc2_write_l1_sectors_fbp_enc_str_4},
    {KEPLER_LTC3_WRITE_L1_SECTORS_FBP, kepler_ltc3_write_l1_sectors_fbp_enc_str_1, kepler_ltc3_write_l1_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc3_write_l1_sectors_fbp_enc_str_4},
    {KEPLER_LTC0_READ_L1_SECTORS_FBP, kepler_ltc0_read_l1_sectors_fbp_enc_str_1, kepler_ltc0_read_l1_sectors_fbp_enc_str_5, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc0_read_l1_sectors_fbp_enc_str_6},
    {KEPLER_LTC1_READ_L1_SECTORS_FBP, kepler_ltc1_read_l1_sectors_fbp_enc_str_1, kepler_ltc1_read_l1_sectors_fbp_enc_str_4, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc1_read_l1_sectors_fbp_enc_str_5},
    {KEPLER_LTC2_READ_L1_SECTORS_FBP, kepler_ltc2_read_l1_sectors_fbp_enc_str_1, kepler_ltc2_read_l1_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc2_read_l1_sectors_fbp_enc_str_4},
    {KEPLER_LTC3_READ_L1_SECTORS_FBP, kepler_ltc3_read_l1_sectors_fbp_enc_str_1, kepler_ltc3_read_l1_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc3_read_l1_sectors_fbp_enc_str_4},

    {KEPLER_LTC0_READ_L1_HIT_SECTORS_FBP, kepler_ltc0_read_l1_hit_sectors_fbp_enc_str_1, kepler_ltc0_read_l1_hit_sectors_fbp_enc_str_5, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc0_read_l1_hit_sectors_fbp_enc_str_6},
    {KEPLER_LTC1_READ_L1_HIT_SECTORS_FBP, kepler_ltc1_read_l1_hit_sectors_fbp_enc_str_1, kepler_ltc1_read_l1_hit_sectors_fbp_enc_str_4, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc1_read_l1_hit_sectors_fbp_enc_str_5},
    {KEPLER_LTC2_READ_L1_HIT_SECTORS_FBP, kepler_ltc2_read_l1_hit_sectors_fbp_enc_str_1, kepler_ltc2_read_l1_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc2_read_l1_hit_sectors_fbp_enc_str_4},
    {KEPLER_LTC3_READ_L1_HIT_SECTORS_FBP, kepler_ltc3_read_l1_hit_sectors_fbp_enc_str_1, kepler_ltc3_read_l1_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc3_read_l1_hit_sectors_fbp_enc_str_4},

    {KEPLER_LTC0_WRITE_L1_HIT_SECTORS_FBP, kepler_ltc0_write_l1_hit_sectors_fbp_enc_str_1, kepler_ltc0_write_l1_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc0_write_l1_hit_sectors_fbp_enc_str_6},
    {KEPLER_LTC1_WRITE_L1_HIT_SECTORS_FBP, kepler_ltc1_write_l1_hit_sectors_fbp_enc_str_1, kepler_ltc1_write_l1_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc1_write_l1_hit_sectors_fbp_enc_str_5},
    {KEPLER_LTC2_WRITE_L1_HIT_SECTORS_FBP, kepler_ltc2_write_l1_hit_sectors_fbp_enc_str_1, kepler_ltc2_write_l1_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc2_write_l1_hit_sectors_fbp_enc_str_4},
    {KEPLER_LTC3_WRITE_L1_HIT_SECTORS_FBP, kepler_ltc3_write_l1_hit_sectors_fbp_enc_str_1, kepler_ltc3_write_l1_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc3_write_l1_hit_sectors_fbp_enc_str_4},

    {KEPLER_LTC0_READ_TEX_SECTORS_FBP, kepler_ltc0_read_tex_sectors_fbp_enc_str_1, kepler_ltc0_read_tex_sectors_fbp_enc_str_5, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc0_read_tex_sectors_fbp_enc_str_6},
    {KEPLER_LTC1_READ_TEX_SECTORS_FBP, kepler_ltc1_read_tex_sectors_fbp_enc_str_1, kepler_ltc1_read_tex_sectors_fbp_enc_str_4, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc1_read_tex_sectors_fbp_enc_str_5},
    {KEPLER_LTC2_READ_TEX_SECTORS_FBP, kepler_ltc2_read_tex_sectors_fbp_enc_str_1, kepler_ltc2_read_tex_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc2_read_tex_sectors_fbp_enc_str_4},
    {KEPLER_LTC3_READ_TEX_SECTORS_FBP, kepler_ltc3_read_tex_sectors_fbp_enc_str_1, kepler_ltc3_read_tex_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc3_read_tex_sectors_fbp_enc_str_4},

    {KEPLER_LTC0_READ_TEX_HIT_SECTORS_FBP, kepler_ltc0_read_tex_hit_sectors_fbp_enc_str_1, kepler_ltc0_read_tex_hit_sectors_fbp_enc_str_5, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc0_read_tex_hit_sectors_fbp_enc_str_6},
    {KEPLER_LTC1_READ_TEX_HIT_SECTORS_FBP, kepler_ltc1_read_tex_hit_sectors_fbp_enc_str_1, kepler_ltc1_read_tex_hit_sectors_fbp_enc_str_4, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc1_read_tex_hit_sectors_fbp_enc_str_5},
    {KEPLER_LTC2_READ_TEX_HIT_SECTORS_FBP, kepler_ltc2_read_tex_hit_sectors_fbp_enc_str_1, kepler_ltc2_read_tex_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc2_read_tex_hit_sectors_fbp_enc_str_4},
    {KEPLER_LTC3_READ_TEX_HIT_SECTORS_FBP, kepler_ltc3_read_tex_hit_sectors_fbp_enc_str_1, kepler_ltc3_read_tex_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc3_read_tex_hit_sectors_fbp_enc_str_4},

    // ltc_read_sysmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_sysmem
    { KEPLER_LTC0_READ_SYSMEM_SECTORS_FBP,      kepler_ltc0_read_sysmem_sectors_fbp_enc_str_1, kepler_ltc0_read_sysmem_sectors_fbp_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc0_read_sysmem_sectors_fbp_enc_str_6},
    { KEPLER_LTC1_READ_SYSMEM_SECTORS_FBP,      kepler_ltc1_read_sysmem_sectors_fbp_enc_str_1, kepler_ltc1_read_sysmem_sectors_fbp_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc1_read_sysmem_sectors_fbp_enc_str_5},
    { KEPLER_LTC2_READ_SYSMEM_SECTORS_FBP,      kepler_ltc2_read_sysmem_sectors_fbp_enc_str_1, kepler_ltc2_read_sysmem_sectors_fbp_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc2_read_sysmem_sectors_fbp_enc_str_4},
    { KEPLER_LTC3_READ_SYSMEM_SECTORS_FBP,      kepler_ltc3_read_sysmem_sectors_fbp_enc_str_1, kepler_ltc3_read_sysmem_sectors_fbp_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc3_read_sysmem_sectors_fbp_enc_str_4},

    // ltc_write_sysmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_sysmem
    { KEPLER_LTC0_WRITE_SYSMEM_SECTORS_FBP,      kepler_ltc0_write_sysmem_sectors_fbp_enc_str_1, kepler_ltc0_write_sysmem_sectors_fbp_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc0_write_sysmem_sectors_fbp_enc_str_6},
    { KEPLER_LTC1_WRITE_SYSMEM_SECTORS_FBP,      kepler_ltc1_write_sysmem_sectors_fbp_enc_str_1, kepler_ltc1_write_sysmem_sectors_fbp_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc1_write_sysmem_sectors_fbp_enc_str_5},
    { KEPLER_LTC2_WRITE_SYSMEM_SECTORS_FBP,      kepler_ltc2_write_sysmem_sectors_fbp_enc_str_1, kepler_ltc2_write_sysmem_sectors_fbp_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc2_write_sysmem_sectors_fbp_enc_str_4},
    { KEPLER_LTC3_WRITE_SYSMEM_SECTORS_FBP,      kepler_ltc3_write_sysmem_sectors_fbp_enc_str_1, kepler_ltc3_write_sysmem_sectors_fbp_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc3_write_sysmem_sectors_fbp_enc_str_4},

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { KEPLER_LTC0_TOTAL_READ_SECTORS_FBP,      kepler_ltc0_total_read_sectors_fbp_enc_str_1, kepler_ltc0_total_read_sectors_fbp_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc0_total_read_sectors_fbp_enc_str_6},
    { KEPLER_LTC1_TOTAL_READ_SECTORS_FBP,      kepler_ltc1_total_read_sectors_fbp_enc_str_1, kepler_ltc1_total_read_sectors_fbp_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc1_total_read_sectors_fbp_enc_str_5},
    { KEPLER_LTC2_TOTAL_READ_SECTORS_FBP,      kepler_ltc2_total_read_sectors_fbp_enc_str_1, kepler_ltc2_total_read_sectors_fbp_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc2_total_read_sectors_fbp_enc_str_4},
    { KEPLER_LTC3_TOTAL_READ_SECTORS_FBP,      kepler_ltc3_total_read_sectors_fbp_enc_str_1, kepler_ltc3_total_read_sectors_fbp_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc3_total_read_sectors_fbp_enc_str_4},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { KEPLER_LTC0_TOTAL_WRITE_SECTORS_FBP,      kepler_ltc0_total_write_sectors_fbp_enc_str_1, kepler_ltc0_total_write_sectors_fbp_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc0_total_write_sectors_fbp_enc_str_6},
    { KEPLER_LTC1_TOTAL_WRITE_SECTORS_FBP,      kepler_ltc1_total_write_sectors_fbp_enc_str_1, kepler_ltc1_total_write_sectors_fbp_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc1_total_write_sectors_fbp_enc_str_5},
    { KEPLER_LTC2_TOTAL_WRITE_SECTORS_FBP,      kepler_ltc2_total_write_sectors_fbp_enc_str_1, kepler_ltc2_total_write_sectors_fbp_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc2_total_write_sectors_fbp_enc_str_4},
    { KEPLER_LTC3_TOTAL_WRITE_SECTORS_FBP,      kepler_ltc3_total_write_sectors_fbp_enc_str_1, kepler_ltc3_total_write_sectors_fbp_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc3_total_write_sectors_fbp_enc_str_4},


    {KEPLER_MMU_HUB_TLB_HIT, kepler_mmu_hub_tlb_hit_enc_str_1, kepler_mmu_hub_tlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_mmu_hub_tlb_hit_enc_str_5},
    {KEPLER_MMU_HUB_TLB_MISS, kepler_mmu_hub_tlb_miss_enc_str_1, kepler_mmu_hub_tlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_mmu_hub_tlb_miss_enc_str_5},
    {KEPLER_MMU_FILL_PTE_HIT, kepler_mmu_fill_pte_hit_enc_str_1, kepler_mmu_fill_pte_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_mmu_fill_pte_hit_enc_str_5},
    {KEPLER_MMU_FILL_PTE_MISS, kepler_mmu_fill_pte_miss_enc_str_1, kepler_mmu_fill_pte_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_mmu_fill_pte_miss_enc_str_5},
    {KEPLER_MMU_FILL_PDE_HIT, kepler_mmu_fill_pde_hit_enc_str_1, kepler_mmu_fill_pde_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_mmu_fill_pde_hit_enc_str_5},
    {KEPLER_MMU_FILL_PDE_MISS, kepler_mmu_fill_pde_miss_enc_str_1, kepler_mmu_fill_pde_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_mmu_fill_pde_miss_enc_str_5},
    {KEPLER_MMU_GPCL2_TLB_HIT,kepler_mmu_gpcl2_tlb_hit_enc_str_1, kepler_mmu_gpcl2_tlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_mmu_gpcl2_tlb_hit_enc_str_4},
    {KEPLER_MMU_GPCL2_TLB_MISS,kepler_mmu_gpcl2_tlb_miss_enc_str_1, kepler_mmu_gpcl2_tlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_mmu_gpcl2_tlb_miss_enc_str_4},
    {KEPLER_FB_SUBP0_DRAM_ACTIVATES, kepler_fb_subp0_dram_activates_enc_str_1, kepler_fb_subp0_dram_activates_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, kepler_fb_subp0_dram_activates_enc_str_6},
    {KEPLER_FB_SUBP1_DRAM_ACTIVATES, kepler_fb_subp1_dram_activates_enc_str_1, kepler_fb_subp1_dram_activates_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, kepler_fb_subp1_dram_activates_enc_str_6},

    // Software counters to count ld/st instructions
    {KEPLER_SW_COUNTER_GLD8BIT_INST,kepler_sw_counter_gld8bit_inst_enc_str_1, kepler_sw_counter_gld8bit_inst_enc_str_2,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gld8bit_inst_enc_str_4},
    {KEPLER_SW_COUNTER_GLD16BIT_INST,kepler_sw_counter_gld16bit_inst_enc_str_1, kepler_sw_counter_gld16bit_inst_enc_str_2,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gld16bit_inst_enc_str_4},
    {KEPLER_SW_COUNTER_GLD32BIT_INST,kepler_sw_counter_gld32bit_inst_enc_str_1, kepler_sw_counter_gld32bit_inst_enc_str_2,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gld32bit_inst_enc_str_4},
    {KEPLER_SW_COUNTER_GLD64BIT_INST,kepler_sw_counter_gld64bit_inst_enc_str_1, kepler_sw_counter_gld64bit_inst_enc_str_2,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gld64bit_inst_enc_str_4},
    {KEPLER_SW_COUNTER_GLD128BIT_INST,kepler_sw_counter_gld128bit_inst_enc_str_1, kepler_sw_counter_gld128bit_inst_enc_str_2,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gld128bit_inst_enc_str_4},
    {KEPLER_SW_COUNTER_GST8BIT_INST,kepler_sw_counter_gst8bit_inst_enc_str_1, kepler_sw_counter_gst8bit_inst_enc_str_2,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gst8bit_inst_enc_str_4},
    {KEPLER_SW_COUNTER_GST16BIT_INST,kepler_sw_counter_gst16bit_inst_enc_str_1, kepler_sw_counter_gst16bit_inst_enc_str_2,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gst16bit_inst_enc_str_4},
    {KEPLER_SW_COUNTER_GST32BIT_INST,kepler_sw_counter_gst32bit_inst_enc_str_1, kepler_sw_counter_gst32bit_inst_enc_str_2,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gst32bit_inst_enc_str_4},
    {KEPLER_SW_COUNTER_GST64BIT_INST,kepler_sw_counter_gst64bit_inst_enc_str_1, kepler_sw_counter_gst64bit_inst_enc_str_2,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gst64bit_inst_enc_str_4},
    {KEPLER_SW_COUNTER_GST128BIT_INST,kepler_sw_counter_gst128bit_inst_enc_str_1, kepler_sw_counter_gst128bit_inst_enc_str_2,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gst128bit_inst_enc_str_4},

    // Software counters to count uinque ld/st instructions
    {KEPLER_SW_COUNTER_UNIQUE_GLD1BYTE_REQUESTED,kepler_sw_counter_unique_gld_1byte_requested_enc_str_1, kepler_sw_counter_unique_gld_1byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_unique_gld_1byte_requested_enc_str_4},
    {KEPLER_SW_COUNTER_UNIQUE_GLD4BYTE_REQUESTED,kepler_sw_counter_unique_gld_4byte_requested_enc_str_1, kepler_sw_counter_unique_gld_4byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_unique_gld_4byte_requested_enc_str_4},
    {KEPLER_SW_COUNTER_UNIQUE_GLD8BYTE_REQUESTED,kepler_sw_counter_unique_gld_8byte_requested_enc_str_1, kepler_sw_counter_unique_gld_8byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_unique_gld_8byte_requested_enc_str_4},
    {KEPLER_SW_COUNTER_UNIQUE_GLD16BYTE_REQUESTED,kepler_sw_counter_unique_gld_16byte_requested_enc_str_1, kepler_sw_counter_unique_gld_16byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_unique_gld_16byte_requested_enc_str_4},
    {KEPLER_SW_COUNTER_UNIQUE_GST1BYTE_REQUESTED,kepler_sw_counter_unique_gst_1byte_requested_enc_str_1, kepler_sw_counter_unique_gst_1byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_unique_gst_1byte_requested_enc_str_4},
    {KEPLER_SW_COUNTER_UNIQUE_GST4BYTE_REQUESTED,kepler_sw_counter_unique_gst_4byte_requested_enc_str_1, kepler_sw_counter_unique_gst_4byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_unique_gst_4byte_requested_enc_str_4},
    {KEPLER_SW_COUNTER_UNIQUE_GST8BYTE_REQUESTED,kepler_sw_counter_unique_gst_8byte_requested_enc_str_1, kepler_sw_counter_unique_gst_8byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_unique_gst_8byte_requested_enc_str_4},
    {KEPLER_SW_COUNTER_UNIQUE_GST16BYTE_REQUESTED,kepler_sw_counter_unique_gst_16byte_requested_enc_str_1, kepler_sw_counter_unique_gst_16byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_unique_gst_16byte_requested_enc_str_4},

    // Software counters to count shared load/store instructions
    {KEPLER_SW_COUNTER_SLD8BIT_INST,kepler_sw_counter_sld8bit_inst_enc_str_1, kepler_sw_counter_sld8bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_sld8bit_inst_enc_str_4},
    {KEPLER_SW_COUNTER_SLD16BIT_INST,kepler_sw_counter_sld16bit_inst_enc_str_1, kepler_sw_counter_sld16bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_sld16bit_inst_enc_str_4},
    {KEPLER_SW_COUNTER_SLD32BIT_INST,kepler_sw_counter_sld32bit_inst_enc_str_1, kepler_sw_counter_sld32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_sld32bit_inst_enc_str_4},
    {KEPLER_SW_COUNTER_SLD64BIT_INST,kepler_sw_counter_sld64bit_inst_enc_str_1, kepler_sw_counter_sld64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_sld64bit_inst_enc_str_4},
    {KEPLER_SW_COUNTER_SLD128BIT_INST,kepler_sw_counter_sld128bit_inst_enc_str_1, kepler_sw_counter_sld128bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_sld128bit_inst_enc_str_4},
    {KEPLER_SW_COUNTER_SST8BIT_INST,kepler_sw_counter_sst8bit_inst_enc_str_1, kepler_sw_counter_sst8bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_sst8bit_inst_enc_str_4},
    {KEPLER_SW_COUNTER_SST16BIT_INST,kepler_sw_counter_sst16bit_inst_enc_str_1, kepler_sw_counter_sst16bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_sst16bit_inst_enc_str_4},
    {KEPLER_SW_COUNTER_SST32BIT_INST,kepler_sw_counter_sst32bit_inst_enc_str_1, kepler_sw_counter_sst32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_sst32bit_inst_enc_str_4},
    {KEPLER_SW_COUNTER_SST64BIT_INST,kepler_sw_counter_sst64bit_inst_enc_str_1, kepler_sw_counter_sst64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_sst64bit_inst_enc_str_4},
    {KEPLER_SW_COUNTER_SST128BIT_INST,kepler_sw_counter_sst128bit_inst_enc_str_1, kepler_sw_counter_sst128bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_sst128bit_inst_enc_str_4},

    // Software counters to count ldg instructions
    {KEPLER_SW_COUNTER_NC_GLD8BIT_INST,kepler_sw_counter_nc_gld8bit_inst_enc_str_1, kepler_sw_counter_nc_gld8bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_nc_gld8bit_inst_enc_str_4},
    {KEPLER_SW_COUNTER_NC_GLD16BIT_INST,kepler_sw_counter_nc_gld16bit_inst_enc_str_1, kepler_sw_counter_nc_gld16bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_nc_gld16bit_inst_enc_str_4},
    {KEPLER_SW_COUNTER_NC_GLD32BIT_INST,kepler_sw_counter_nc_gld32bit_inst_enc_str_1, kepler_sw_counter_nc_gld32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_nc_gld32bit_inst_enc_str_4},
    {KEPLER_SW_COUNTER_NC_GLD64BIT_INST,kepler_sw_counter_nc_gld64bit_inst_enc_str_1, kepler_sw_counter_nc_gld64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_nc_gld64bit_inst_enc_str_4},
    {KEPLER_SW_COUNTER_NC_GLD128BIT_INST,kepler_sw_counter_nc_gld128bit_inst_enc_str_1, kepler_sw_counter_nc_gld128bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_nc_gld128bit_inst_enc_str_4},

    // Software counters to count floating point instructions
    {KEPLER_SW_COUNTER_FADD_INST,kepler_sw_counter_fadd_inst_enc_str_1, kepler_sw_counter_fadd_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_sw_counter_fadd_inst_enc_str_4},
    {KEPLER_SW_COUNTER_FMUL_INST,kepler_sw_counter_fmul_inst_enc_str_1, kepler_sw_counter_fmul_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_sw_counter_fmul_inst_enc_str_4},
    {KEPLER_SW_COUNTER_FFMA_INST,kepler_sw_counter_ffma_inst_enc_str_1, kepler_sw_counter_ffma_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_sw_counter_ffma_inst_enc_str_4},
    {KEPLER_SW_COUNTER_DADD_INST,kepler_sw_counter_dadd_inst_enc_str_1, kepler_sw_counter_dadd_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_sw_counter_dadd_inst_enc_str_4},
    {KEPLER_SW_COUNTER_DMUL_INST,kepler_sw_counter_dmul_inst_enc_str_1, kepler_sw_counter_dmul_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_sw_counter_dmul_inst_enc_str_4},
    {KEPLER_SW_COUNTER_DFMA_INST,kepler_sw_counter_dfma_inst_enc_str_1, kepler_sw_counter_dfma_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_sw_counter_dfma_inst_enc_str_4},
    {KEPLER_SW_COUNTER_COS_INST,kepler_sw_counter_cos_inst_enc_str_1, kepler_sw_counter_cos_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_sw_counter_cos_inst_enc_str_4},
    {KEPLER_SW_COUNTER_EX2_INST,kepler_sw_counter_ex2_inst_enc_str_1, kepler_sw_counter_ex2_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_sw_counter_ex2_inst_enc_str_4},
    {KEPLER_SW_COUNTER_LG2_INST,kepler_sw_counter_lg2_inst_enc_str_1, kepler_sw_counter_lg2_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_sw_counter_lg2_inst_enc_str_4},
    {KEPLER_SW_COUNTER_RCP_INST,kepler_sw_counter_rcp_inst_enc_str_1, kepler_sw_counter_rcp_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_sw_counter_rcp_inst_enc_str_4},
    {KEPLER_SW_COUNTER_RSQ_INST,kepler_sw_counter_rsq_inst_enc_str_1, kepler_sw_counter_rsq_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_sw_counter_rsq_inst_enc_str_4},
    {KEPLER_SW_COUNTER_SIN_INST,kepler_sw_counter_sin_inst_enc_str_1, kepler_sw_counter_sin_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_sw_counter_sin_inst_enc_str_4},

    // Software counters to count the transactions
    {KEPLER_SW_COUNTER_L2_GLOBAL_WRITE_L1_SECTOR_QUERIES,  kepler_sw_counter_l2_global_write_l1_sector_queries_enc_str_1, kepler_sw_counter_l2_global_write_l1_sector_queries_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_l2_global_write_l1_sector_queries_enc_str_4},
    {KEPLER_SW_COUNTER_L2_UCACHED_GLOBAL_READ_L1_SECTOR_QUERIES,  kepler_sw_counter_l2_ucached_global_read_l1_sector_queries_enc_str_1, kepler_sw_counter_l2_ucached_global_read_l1_sector_queries_enc_str_1,CUPROF_EVENT_CATEGORY_MEMORY,kepler_sw_counter_l2_ucached_global_read_l1_sector_queries_enc_str_4},

    // Software counters to count the number of instructions executed from a particular instruction class:
    { KEPLER_SW_COUNTER_INSTR_CLASS_FP_32,                       kepler_sw_counter_instr_class_fp_32_enc_str_1                      , kepler_sw_counter_instr_class_fp_32_enc_str_1                      , CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_sw_counter_instr_class_fp_32_enc_str_4},
    { KEPLER_SW_COUNTER_INSTR_CLASS_FP_64,                       kepler_sw_counter_instr_class_fp_64_enc_str_1                      , kepler_sw_counter_instr_class_fp_64_enc_str_1                      , CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_sw_counter_instr_class_fp_64_enc_str_4},
    { KEPLER_SW_COUNTER_INSTR_CLASS_INTEGER,                     kepler_sw_counter_instr_class_integer_enc_str_1                    , kepler_sw_counter_instr_class_integer_enc_str_1                    , CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_sw_counter_instr_class_integer_enc_str_4},
    { KEPLER_SW_COUNTER_INSTR_CLASS_BIT_CONVERT,                 kepler_sw_counter_instr_class_bit_convert_enc_str_1                , kepler_sw_counter_instr_class_bit_convert_enc_str_1                , CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_sw_counter_instr_class_bit_convert_enc_str_4},
    { KEPLER_SW_COUNTER_INSTR_CLASS_CONTROL,                     kepler_sw_counter_instr_class_control_enc_str_1                    , kepler_sw_counter_instr_class_control_enc_str_1                    , CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_sw_counter_instr_class_control_enc_str_4},
    { KEPLER_SW_COUNTER_INSTR_CLASS_COMPUTE_LD_ST,               kepler_sw_counter_instr_class_compute_ld_st_enc_str_1              , kepler_sw_counter_instr_class_compute_ld_st_enc_str_1              , CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_sw_counter_instr_class_compute_ld_st_enc_str_4},
    { KEPLER_SW_COUNTER_INSTR_CLASS_MISCELLANEOUS,               kepler_sw_counter_instr_class_miscellaneous_enc_str_1              , kepler_sw_counter_instr_class_miscellaneous_enc_str_1              , CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_sw_counter_instr_class_miscellaneous_enc_str_4},
    { KEPLER_SW_COUNTER_INSTR_CLASS_INTER_THREAD_COMMUNICATION,  kepler_sw_counter_instr_class_inter_thread_communication_enc_str_1 , kepler_sw_counter_instr_class_inter_thread_communication_enc_str_1 , CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_sw_counter_instr_class_inter_thread_communication_enc_str_4},

    // Software counters to count the different load/stores from the generic accesses
    { KEPLER_SW_COUNTER_GENERIC_SHARED_LOAD,                kepler_sw_counter_generic_shared_ld_enc_str_1               , kepler_sw_counter_generic_shared_ld_enc_str_1               , CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_sw_counter_generic_shared_ld_enc_str_4},
    { KEPLER_SW_COUNTER_GENERIC_SHARED_STORE,               kepler_sw_counter_generic_shared_st_enc_str_1               , kepler_sw_counter_generic_shared_st_enc_str_1               , CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_sw_counter_generic_shared_ld_enc_str_4},
    { KEPLER_SW_COUNTER_GENERIC_LOCAL_LOAD,                 kepler_sw_counter_generic_local_ld_enc_str_1                , kepler_sw_counter_generic_local_ld_enc_str_1                , CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_sw_counter_generic_local_ld_enc_str_4},
    { KEPLER_SW_COUNTER_GENERIC_LOCAL_STORE,                kepler_sw_counter_generic_local_st_enc_str_1                , kepler_sw_counter_generic_local_st_enc_str_1                , CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_sw_counter_generic_local_ld_enc_str_4},
    { KEPLER_SW_COUNTER_GENERIC_GLOBAL_LOAD,                kepler_sw_counter_generic_global_ld_enc_str_1               , kepler_sw_counter_generic_global_ld_enc_str_1               , CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_sw_counter_generic_global_ld_enc_str_4},
    { KEPLER_SW_COUNTER_GENERIC_GLOBAL_STORE,               kepler_sw_counter_generic_global_st_enc_str_1               , kepler_sw_counter_generic_global_st_enc_str_1               , CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_sw_counter_generic_global_ld_enc_str_4},

    // Software counters to count ld/st instructions
    {KEPLER_INTERNAL_SW_COUNTER_GLD8BIT_INST,kepler_internal_sw_counter_gld8bit_inst_enc_str_1, kepler_internal_sw_counter_gld8bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gld8bit_inst_enc_str_4},
    {KEPLER_INTERNAL_SW_COUNTER_GLD16BIT_INST,kepler_internal_sw_counter_gld16bit_inst_enc_str_1, kepler_internal_sw_counter_gld16bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gld16bit_inst_enc_str_4},
    {KEPLER_INTERNAL_SW_COUNTER_GLD32BIT_INST,kepler_internal_sw_counter_gld32bit_inst_enc_str_1, kepler_internal_sw_counter_gld32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gld32bit_inst_enc_str_4},
    {KEPLER_INTERNAL_SW_COUNTER_GLD64BIT_INST,kepler_internal_sw_counter_gld64bit_inst_enc_str_1, kepler_internal_sw_counter_gld64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gld64bit_inst_enc_str_4},
    {KEPLER_INTERNAL_SW_COUNTER_GLD128BIT_INST,kepler_internal_sw_counter_gld128bit_inst_enc_str_1, kepler_internal_sw_counter_gld128bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gld128bit_inst_enc_str_4},
    {KEPLER_INTERNAL_SW_COUNTER_GST8BIT_INST,kepler_internal_sw_counter_gst8bit_inst_enc_str_1, kepler_internal_sw_counter_gst8bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gst8bit_inst_enc_str_4},
    {KEPLER_INTERNAL_SW_COUNTER_GST16BIT_INST,kepler_internal_sw_counter_gst16bit_inst_enc_str_1, kepler_internal_sw_counter_gst16bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gst16bit_inst_enc_str_4},
    {KEPLER_INTERNAL_SW_COUNTER_GST32BIT_INST,kepler_internal_sw_counter_gst32bit_inst_enc_str_1, kepler_internal_sw_counter_gst32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gst32bit_inst_enc_str_4},
    {KEPLER_INTERNAL_SW_COUNTER_GST64BIT_INST,kepler_internal_sw_counter_gst64bit_inst_enc_str_1, kepler_internal_sw_counter_gst64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gst64bit_inst_enc_str_4},
    {KEPLER_INTERNAL_SW_COUNTER_GST128BIT_INST,kepler_internal_sw_counter_gst128bit_inst_enc_str_1, kepler_internal_sw_counter_gst128bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gst128bit_inst_enc_str_4},

    // LDG signals
    { TEX0_LDG_WARP_COUNT_32B,tex0_ldg_warp_count_32b_enc_str_1,tex0_ldg_warp_count_32b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex0_ldg_warp_count_32b_enc_str_6},
    { TEX1_LDG_WARP_COUNT_32B,tex1_ldg_warp_count_32b_enc_str_1,tex1_ldg_warp_count_32b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex1_ldg_warp_count_32b_enc_str_6},
    { TEX2_LDG_WARP_COUNT_32B,tex2_ldg_warp_count_32b_enc_str_1,tex2_ldg_warp_count_32b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex2_ldg_warp_count_32b_enc_str_4},
    { TEX3_LDG_WARP_COUNT_32B,tex3_ldg_warp_count_32b_enc_str_1,tex3_ldg_warp_count_32b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex3_ldg_warp_count_32b_enc_str_4},

    { TEX0_LDG_WARP_COUNT_64B,tex0_ldg_warp_count_64b_enc_str_1,tex0_ldg_warp_count_64b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex0_ldg_warp_count_64b_enc_str_6},
    { TEX1_LDG_WARP_COUNT_64B,tex1_ldg_warp_count_64b_enc_str_1,tex1_ldg_warp_count_64b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex1_ldg_warp_count_64b_enc_str_6},
    { TEX2_LDG_WARP_COUNT_64B,tex2_ldg_warp_count_64b_enc_str_1,tex2_ldg_warp_count_64b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex2_ldg_warp_count_64b_enc_str_4},
    { TEX3_LDG_WARP_COUNT_64B,tex3_ldg_warp_count_64b_enc_str_1,tex3_ldg_warp_count_64b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex3_ldg_warp_count_64b_enc_str_4},

    { TEX0_LDG_WARP_COUNT_128B,tex0_ldg_warp_count_128b_enc_str_1,tex0_ldg_warp_count_128b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex0_ldg_warp_count_128b_enc_str_6},
    { TEX1_LDG_WARP_COUNT_128B,tex1_ldg_warp_count_128b_enc_str_1,tex1_ldg_warp_count_128b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex1_ldg_warp_count_128b_enc_str_6},
    { TEX2_LDG_WARP_COUNT_128B,tex2_ldg_warp_count_128b_enc_str_1,tex2_ldg_warp_count_128b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex2_ldg_warp_count_128b_enc_str_4},
    { TEX3_LDG_WARP_COUNT_128B,tex3_ldg_warp_count_128b_enc_str_1,tex3_ldg_warp_count_128b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex3_ldg_warp_count_128b_enc_str_4},

    { TEX0_LDG_THREAD_COUNT_32B,tex0_ldg_thread_count_32b_enc_str_1,tex0_ldg_thread_count_32b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex0_ldg_thread_count_32b_enc_str_6},
    { TEX1_LDG_THREAD_COUNT_32B,tex1_ldg_thread_count_32b_enc_str_1,tex1_ldg_thread_count_32b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex1_ldg_thread_count_32b_enc_str_6},
    { TEX2_LDG_THREAD_COUNT_32B,tex2_ldg_thread_count_32b_enc_str_1,tex2_ldg_thread_count_32b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex2_ldg_thread_count_32b_enc_str_4},
    { TEX3_LDG_THREAD_COUNT_32B,tex3_ldg_thread_count_32b_enc_str_1,tex3_ldg_thread_count_32b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex3_ldg_thread_count_32b_enc_str_4},

    { TEX0_LDG_THREAD_COUNT_64B,tex0_ldg_thread_count_64b_enc_str_1,tex0_ldg_thread_count_64b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex0_ldg_thread_count_64b_enc_str_6},
    { TEX1_LDG_THREAD_COUNT_64B,tex1_ldg_thread_count_64b_enc_str_1,tex1_ldg_thread_count_64b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex1_ldg_thread_count_64b_enc_str_6},
    { TEX2_LDG_THREAD_COUNT_64B,tex2_ldg_thread_count_64b_enc_str_1,tex2_ldg_thread_count_64b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex2_ldg_thread_count_64b_enc_str_4},
    { TEX3_LDG_THREAD_COUNT_64B,tex3_ldg_thread_count_64b_enc_str_1,tex3_ldg_thread_count_64b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex3_ldg_thread_count_64b_enc_str_4},

    { TEX0_LDG_THREAD_COUNT_128B,tex0_ldg_thread_count_128b_enc_str_1,tex0_ldg_thread_count_128b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex0_ldg_thread_count_128b_enc_str_6},
    { TEX1_LDG_THREAD_COUNT_128B,tex1_ldg_thread_count_128b_enc_str_1,tex1_ldg_thread_count_128b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex1_ldg_thread_count_128b_enc_str_6},
    { TEX2_LDG_THREAD_COUNT_128B,tex2_ldg_thread_count_128b_enc_str_1,tex2_ldg_thread_count_128b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex2_ldg_thread_count_128b_enc_str_4},
    { TEX3_LDG_THREAD_COUNT_128B,tex3_ldg_thread_count_128b_enc_str_1,tex3_ldg_thread_count_128b_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, tex3_ldg_thread_count_128b_enc_str_4},

    { KEPLER_SM_WARP_ISSUE_ELIGIBLE,                          kepler_sm_warp_issue_eligible_enc_str_1,                          kepler_sm_warp_issue_eligible_enc_str_1,                           CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_warp_issue_eligible_enc_str_5},
    {KEPLER_SM_WARP_CANT_ISSUE_BARRIER,                       kepler_sm_warp_cant_issue_barrier_enc_str_1,                      kepler_sm_warp_cant_issue_barrier_enc_str_1,                       CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_warp_cant_issue_barrier_enc_str_6},
    { KEPLER_SM_WARP_CANT_ISSUE_NO_INST,                      kepler_sm_warp_cant_issue_no_inst_enc_str_1,                      kepler_sm_warp_cant_issue_no_inst_enc_str_1,                       CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_warp_cant_issue_no_inst_enc_str_6},
    { KEPLER_SM_WARP_CANT_ISSUE_DISPATCH_STALL,               kepler_sm_warp_cant_issue_dispatch_stall_enc_str_1,               kepler_sm_warp_cant_issue_dispatch_stall_enc_str_1,                CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_warp_cant_issue_dispatch_stall_enc_str_6},
    { KEPLER_SM_WARP_CANT_ISSUE_PARTIALLY_LOADED_SUBTILE,     kepler_sm_warp_cant_issue_partially_loaded_subtile_enc_str_1,     kepler_sm_warp_cant_issue_partially_loaded_subtile_enc_str_1,      CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_warp_cant_issue_partially_loaded_subtile_enc_str_6},
    { KEPLER_SM_WARP_CANT_ISSUE_SWITCHING_IFB,                kepler_sm_warp_cant_issue_switching_ifb_enc_str_1,                kepler_sm_warp_cant_issue_switching_ifb_enc_str_1,                 CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_warp_cant_issue_switching_ifb_enc_str_6},
    { KEPLER_SM_WARP_CANT_ISSUE_WAITING,                      kepler_sm_warp_cant_issue_waiting_enc_str_1,                      kepler_sm_warp_cant_issue_waiting_enc_str_1,                       CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_warp_cant_issue_waiting_enc_str_6},
    { KEPLER_SM_WARP_CANT_ISSUE_MULTI_ISSUE,                  kepler_sm_warp_cant_issue_multi_issue_enc_str_1,                  kepler_sm_warp_cant_issue_multi_issue_enc_str_1,                   CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_warp_cant_issue_multi_issue_enc_str_6},
    { KEPLER_SM_WARP_CANT_ISSUE_REPLAY_EXECUTING,             kepler_sm_warp_cant_issue_replay_executing_enc_str_1,             kepler_sm_warp_cant_issue_replay_executing_enc_str_1,              CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_warp_cant_issue_replay_executing_enc_str_6},
    { KEPLER_SM_WARP_CANT_ISSUE_TEX_EXECUTING,                kepler_sm_warp_cant_issue_tex_executing_enc_str_1,                kepler_sm_warp_cant_issue_tex_executing_enc_str_1,                 CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_warp_cant_issue_tex_executing_enc_str_6},
    { KEPLER_SM_WARP_CANT_ISSUE_TEX_DEPENDENCY,               kepler_sm_warp_cant_issue_tex_dependency_enc_str_1,               kepler_sm_warp_cant_issue_tex_dependency_enc_str_1,                CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_warp_cant_issue_tex_dependency_enc_str_6},
    { KEPLER_SM_WARP_CANT_ISSUE_L1_MISS_DEPENDENCY,           kepler_sm_warp_cant_issue_l1_miss_dependency_enc_str_1,           kepler_sm_warp_cant_issue_l1_miss_dependency_enc_str_1,            CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_warp_cant_issue_l1_miss_dependency_enc_str_6},
    { KEPLER_SM_WARP_CANT_ISSUE_MSB_FULL,                     kepler_sm_warp_cant_issue_msb_full_enc_str_1,                     kepler_sm_warp_cant_issue_msb_full_enc_str_1,                      CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_warp_cant_issue_msb_full_enc_str_6},
    { KEPLER_SM_WARP_CANT_ISSUE_IMC_MISS_DEPENDENCY,          kepler_sm_warp_cant_issue_imc_miss_dependency_enc_str_1,          kepler_sm_warp_cant_issue_imc_miss_dependency_enc_str_1,           CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_warp_cant_issue_imc_miss_dependency_enc_str_6},
    { KEPLER_SM_WARP_CANT_ISSUE_SHADOW_PIPE_THROTTLE,         kepler_sm_warp_cant_issue_shadow_pipe_throttle_enc_str_1,         kepler_sm_warp_cant_issue_shadow_pipe_throttle_enc_str_1,          CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_warp_cant_issue_shadow_pipe_throttle_enc_str_6},
    { KEPLER_SM_WARP_CANT_ISSUE_TEX_THROTTLE,                 kepler_sm_warp_cant_issue_tex_throttle_enc_str_1,                 kepler_sm_warp_cant_issue_tex_throttle_enc_str_1,                  CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_warp_cant_issue_tex_throttle_enc_str_6},
    { KEPLER_SM_WARP_CANT_ISSUE_RIB_THROTTLE,                 kepler_sm_warp_cant_issue_rib_throttle_enc_str_1,                 kepler_sm_warp_cant_issue_rib_throttle_enc_str_1,                  CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_warp_cant_issue_rib_throttle_enc_str_6},
    { KEPLER_SM_WARP_CANT_ISSUE_TEX_LOCK_MISMATCH,            kepler_sm_warp_cant_issue_tex_lock_mismatch_enc_str_1,            kepler_sm_warp_cant_issue_tex_lock_mismatch_enc_str_1,             CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_warp_cant_issue_tex_lock_mismatch_enc_str_6},
    { KEPLER_SM_WARP_CANT_ISSUE_MEMBAR,                       kepler_sm_warp_cant_issue_membar_enc_str_1,                       kepler_sm_warp_cant_issue_membar_enc_str_1,                        CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_warp_cant_issue_membar_enc_str_6},
    { KEPLER_SM_WARP_CANT_ISSUE_HOLD_MISMATCH,                kepler_sm_warp_cant_issue_hold_mismatch_enc_str_1,                kepler_sm_warp_cant_issue_hold_mismatch_enc_str_1,                 CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_warp_cant_issue_hold_mismatch_enc_str_6},
    { KEPLER_SM_WARP_CANT_ISSUE_NOT_SELECT,                   kepler_sm_warp_cant_issue_not_select_enc_str_1,                   kepler_sm_warp_cant_issue_not_select_enc_str_1,                    CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_warp_cant_issue_not_select_enc_str_6},

    { KEPLER_SM_INST_EXECUTED_FAU_XLU_OPS,                    kepler_sm_inst_executed_fau_xlu_ops_enc_str_1,                    kepler_sm_inst_executed_fau_xlu_ops_enc_str_1,                     CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_fau_xlu_ops_enc_str_5},
    { KEPLER_SM_INST_ISSUED_XLU_PIPE,                         kepler_sm_inst_issued_xlu_pipe_enc_str_1,                         kepler_sm_inst_issued_xlu_pipe_enc_str_1,                          CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_issued_xlu_pipe_enc_str_6},
    { KEPLER_SM_INST_ISSUED_SU_PIPE,                          kepler_sm_inst_issued_su_pipe_enc_str_1,                          kepler_sm_inst_issued_su_pipe_enc_str_1,                           CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_issued_su_pipe_enc_str_6},
    { KEPLER_SM_INST_ISSUED_FU_PIPE,                          kepler_sm_inst_issued_fu_pipe_enc_str_1,                          kepler_sm_inst_issued_fu_pipe_enc_str_1,                           CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_issued_fu_pipe_enc_str_6},
    { KEPLER_SM_INST_ISSUED_FMAX_PIPE,                        kepler_sm_inst_issued_fmax_pipe_enc_str_1,                        kepler_sm_inst_issued_fmax_pipe_enc_str_1,                         CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_issued_fmax_pipe_enc_str_6},
    { KEPLER_SM_INST_ISSUED_FMAXLITEW_PIPE,                   kepler_sm_inst_issued_fmaxlitew_pipe_enc_str_1,                   kepler_sm_inst_issued_fmaxlitew_pipe_enc_str_1,                    CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_issued_fmaxlitew_pipe_enc_str_6},
    { KEPLER_SM_INST_ISSUED_FAU_PIPE,                         kepler_sm_inst_issued_fau_pipe_enc_str_1,                         kepler_sm_inst_issued_fau_pipe_enc_str_1,                          CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_issued_fau_pipe_enc_str_6},
    { KEPLER_SM_INST_ISSUED_FE_PIPE,                          kepler_sm_inst_issued_fe_pipe_enc_str_1,                          kepler_sm_inst_issued_fe_pipe_enc_str_1,                           CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_issued_fe_pipe_enc_str_6},
    { KEPLER_SM_INST_ISSUED_BRU_PIPE,                         kepler_sm_inst_issued_bru_pipe_enc_str_1,                         kepler_sm_inst_issued_bru_pipe_enc_str_1,                          CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_issued_bru_pipe_enc_str_6},
    { KEPLER_SM_INST_ISSUED_FMALITEW_PIPE,                    kepler_sm_inst_issued_fmalitew_pipe_enc_str_1,                    kepler_sm_inst_issued_fmalitew_pipe_enc_str_1,                     CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_issued_fmalitew_pipe_enc_str_6},
    { KEPLER_SM_INST_ISSUED_ADU_PIPE,                         kepler_sm_inst_issued_adu_pipe_enc_str_1,                         kepler_sm_inst_issued_adu_pipe_enc_str_1,                          CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_issued_adu_pipe_enc_str_6},
    { KEPLER_SM_INST_ISSUED_AGU_PIPE,                         kepler_sm_inst_issued_agu_pipe_enc_str_1,                         kepler_sm_inst_issued_agu_pipe_enc_str_1,                          CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_issued_agu_pipe_enc_str_6},
    { KEPLER_SM_INST_ISSUED_TEX_PIPE,                         kepler_sm_inst_issued_tex_pipe_enc_str_1,                         kepler_sm_inst_issued_tex_pipe_enc_str_1,                          CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_issued_tex_pipe_enc_str_6},
    { KEPLER_SM_INST_ISSUED_FP64_TO_FMAX_PIPE,                kepler_sm_inst_issued_fp64_to_fmax_pipe_enc_str_1,                kepler_sm_inst_issued_fp64_to_fmax_pipe_enc_str_1,                 CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_issued_fp64_to_fmax_pipe_enc_str_6},
    { KEPLER_SM_INST_ISSUED_FP64_TO_FMAXLITE_PIPE,            kepler_sm_inst_issued_fp64_to_fmaxlite_pipe_enc_str_1,            kepler_sm_inst_issued_fp64_to_fmaxlite_pipe_enc_str_1,             CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_issued_fp64_to_fmax_pipe_enc_str_6},
    { KEPLER_SM_INST_ISSUED_FMA64PLUS_PIPE,                   kepler_sm_inst_issued_fma64plus_pipe_enc_str_1,                   kepler_sm_inst_issued_fma64plus_pipe_enc_str_1,                    CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_issued_fma64plus_pipe_enc_str_5},
    { KEPLER_SM_INST_ISSUED_FMA64LITE_PIPE,                   kepler_sm_inst_issued_fma64lite_pipe_enc_str_1,                   kepler_sm_inst_issued_fma64lite_pipe_enc_str_1,                    CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_issued_fma64lite_pipe_enc_str_5},
    { KEPLER_SM_INST_EXECUTED_XLU_PIPE,                       kepler_sm_inst_executed_xlu_pipe_enc_str_1,                       kepler_sm_inst_executed_xlu_pipe_enc_str_1,                        CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_xlu_pipe_enc_str_6},
    { KEPLER_SM_INST_EXECUTED_SU_PIPE,                        kepler_sm_inst_executed_su_pipe_enc_str_1,                        kepler_sm_inst_executed_su_pipe_enc_str_1,                         CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_su_pipe_enc_str_6},
    { KEPLER_SM_INST_EXECUTED_FU_PIPE,                        kepler_sm_inst_executed_fu_pipe_enc_str_1,                        kepler_sm_inst_executed_fu_pipe_enc_str_1,                         CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_fu_pipe_enc_str_6},
    { KEPLER_SM_INST_EXECUTED_FMAX_PIPE,                      kepler_sm_inst_executed_fmax_pipe_enc_str_1,                      kepler_sm_inst_executed_fmax_pipe_enc_str_1,                       CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_fmax_pipe_enc_str_6},
    { KEPLER_SM_INST_EXECUTED_FMAXLITEW_PIPE,                 kepler_sm_inst_executed_fmaxlitew_pipe_enc_str_1,                 kepler_sm_inst_executed_fmaxlitew_pipe_enc_str_1,                  CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_fmaxlitew_pipe_enc_str_6},
    { KEPLER_SM_INST_EXECUTED_FAU_PIPE,                       kepler_sm_inst_executed_fau_pipe_enc_str_1,                       kepler_sm_inst_executed_fau_pipe_enc_str_1,                        CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_fau_pipe_enc_str_6},
    { KEPLER_SM_INST_EXECUTED_FE_PIPE,                        kepler_sm_inst_executed_fe_pipe_enc_str_1,                        kepler_sm_inst_executed_fe_pipe_enc_str_1,                         CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_fe_pipe_enc_str_6},
    { KEPLER_SM_INST_EXECUTED_BRU_PIPE,                       kepler_sm_inst_executed_bru_pipe_enc_str_1,                       kepler_sm_inst_executed_bru_pipe_enc_str_1,                        CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_bru_pipe_enc_str_6},
    { KEPLER_SM_INST_EXECUTED_FMALITEW_PIPE,                  kepler_sm_inst_executed_fmalitew_pipe_enc_str_1,                  kepler_sm_inst_executed_fmalitew_pipe_enc_str_1,                   CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_fmalitew_pipe_enc_str_6},
    { KEPLER_SM_INST_EXECUTED_ADU_PIPE,                       kepler_sm_inst_executed_adu_pipe_enc_str_1,                       kepler_sm_inst_executed_adu_pipe_enc_str_1,                        CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_adu_pipe_enc_str_6},
    { KEPLER_SM_INST_EXECUTED_AGU_PIPE,                       kepler_sm_inst_executed_agu_pipe_enc_str_1,                       kepler_sm_inst_executed_agu_pipe_enc_str_1,                        CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_agu_pipe_enc_str_6},
    { KEPLER_SM_INST_EXECUTED_TEX_PIPE,                       kepler_sm_inst_executed_tex_pipe_enc_str_1,                       kepler_sm_inst_executed_tex_pipe_enc_str_1,                        CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_tex_pipe_enc_str_6},
    { KEPLER_SM_INST_EXECUTED_TCS,                            kepler_sm_inst_executed_tcs_enc_str_1,                            kepler_sm_inst_executed_tcs_enc_str_1,                             CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_tcs_enc_str_6},
    { KEPLER_SM_INST_EXECUTED_TES,                            kepler_sm_inst_executed_tes_enc_str_1,                            kepler_sm_inst_executed_tes_enc_str_1,                             CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_tes_enc_str_6},
    { KEPLER_SM_INST_EXECUTED_VS,                             kepler_sm_inst_executed_vs_enc_str_1,                             kepler_sm_inst_executed_vs_enc_str_1,                              CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_vs_enc_str_6},
    { KEPLER_SM_INST_EXECUTED_PS,                             kepler_sm_inst_executed_ps_enc_str_1,                             kepler_sm_inst_executed_ps_enc_str_1,                              CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_ps_enc_str_6},
    { KEPLER_SM_INST_EXECUTED_GS,                             kepler_sm_inst_executed_gs_enc_str_1,                             kepler_sm_inst_executed_gs_enc_str_1,                              CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_gs_enc_str_6},
    { KEPLER_SM_INST_EXECUTED_CS,                             kepler_sm_inst_executed_cs_enc_str_1,                             kepler_sm_inst_executed_cs_enc_str_1,                              CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_cs_enc_str_6},
    { KEPLER_SM_INST_EXECUTED_LSU_SULDGA_B,                   kepler_sm_inst_executed_lsu_suldga_b_enc_str_1,                   kepler_sm_inst_executed_lsu_suldga_b_enc_str_1,                    CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_lsu_suldga_b_enc_str_6},
    { KEPLER_SM_INST_EXECUTED_LSU_SULDGA_P,                   kepler_sm_inst_executed_lsu_suldga_p_enc_str_1,                   kepler_sm_inst_executed_lsu_suldga_p_enc_str_1,                    CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_lsu_suldga_p_enc_str_6},
    { KEPLER_SM_INST_EXECUTED_LSU_SUSTGA_B,                   kepler_sm_inst_executed_lsu_sustga_b_enc_str_1,                   kepler_sm_inst_executed_lsu_sustga_b_enc_str_1,                    CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_lsu_sustga_b_enc_str_6},
    { KEPLER_SM_INST_EXECUTED_LSU_SUSTGA_P,                   kepler_sm_inst_executed_lsu_sustga_p_enc_str_1,                   kepler_sm_inst_executed_lsu_sustga_p_enc_str_1,                    CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_lsu_sustga_p_enc_str_6},
    { KEPLER_SM_INST_EXECUTED_LSU_ATOM_CAS,                   kepler_sm_inst_executed_lsu_atom_cas_enc_str_1,                   kepler_sm_inst_executed_lsu_atom_cas_enc_str_1,                    CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_lsu_atom_cas_enc_str_6},
    { KEPLER_SM_INST_EXECUTED_LSU_LDS_U_128,                  kepler_sm_inst_executed_lsu_lds_u_128_enc_str_1,                  kepler_sm_inst_executed_lsu_lds_u_128_enc_str_1,                   CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_lsu_lds_u_128_enc_str_5},
    { KEPLER_SM_INST_EXECUTED_LSU_ALD,                        kepler_sm_inst_executed_lsu_ald_enc_str_1,                        kepler_sm_inst_executed_lsu_ald_enc_str_1,                         CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_lsu_ald_enc_str_5},
    { KEPLER_SM_INST_EXECUTED_LSU_AST,                        kepler_sm_inst_executed_lsu_ast_enc_str_1,                        kepler_sm_inst_executed_lsu_ast_enc_str_1,                         CUPROF_EVENT_CATEGORY_INSTRUCTION,    kepler_sm_inst_executed_lsu_ast_enc_str_5},

    { KEPLER_HWPM_MPC_COMPUTE_CTAS_IN_FLIGHT,kepler_hwpm_mpc_compute_ctas_in_flight_enc_str_1, kepler_hwpm_mpc_compute_ctas_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_compute_ctas_in_flight_enc_str_5},
    { KEPLER_HWPM_MPC_COMPUTE_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_compute_ctas_in_flight1_enc_str_1, kepler_hwpm_mpc_compute_ctas_in_flight1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_compute_ctas_in_flight1_enc_str_5},
    { KEPLER_HWPM_MPC_COMPUTE_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_compute_ctas_in_flight2_enc_str_1, kepler_hwpm_mpc_compute_ctas_in_flight2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_compute_ctas_in_flight2_enc_str_4},
    { KEPLER_HWPM_MPC_PIX_WARPS_IN_FLIGHT,kepler_hwpm_mpc_pix_warps_in_flight_enc_str_1, kepler_hwpm_mpc_pix_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_pix_warps_in_flight_enc_str_5},
    { KEPLER_HWPM_MPC_PIX_WARPS_IN_FLIGHT1,kepler_hwpm_mpc_pix_warps_in_flight1_enc_str_1, kepler_hwpm_mpc_pix_warps_in_flight1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_pix_warps_in_flight1_enc_str_5},
    { KEPLER_HWPM_MPC_PIX_WARPS_IN_FLIGHT2,kepler_hwpm_mpc_pix_warps_in_flight2_enc_str_1, kepler_hwpm_mpc_pix_warps_in_flight2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_pix_warps_in_flight2_enc_str_4},

    { KEPLER_HWPM_MPC_CNT_1_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_1_ctas_in_flight_enc_str_1,  kepler_hwpm_mpc_cnt_1_ctas_in_flight_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_1_ctas_in_flight_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_2_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_2_ctas_in_flight_enc_str_1,  kepler_hwpm_mpc_cnt_2_ctas_in_flight_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_2_ctas_in_flight_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_3_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_3_ctas_in_flight_enc_str_1,  kepler_hwpm_mpc_cnt_3_ctas_in_flight_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_3_ctas_in_flight_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_4_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_4_ctas_in_flight_enc_str_1,  kepler_hwpm_mpc_cnt_4_ctas_in_flight_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_4_ctas_in_flight_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_5_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_5_ctas_in_flight_enc_str_1,  kepler_hwpm_mpc_cnt_5_ctas_in_flight_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_5_ctas_in_flight_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_6_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_6_ctas_in_flight_enc_str_1,  kepler_hwpm_mpc_cnt_6_ctas_in_flight_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_6_ctas_in_flight_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_7_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_7_ctas_in_flight_enc_str_1,  kepler_hwpm_mpc_cnt_7_ctas_in_flight_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_7_ctas_in_flight_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_8_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_8_ctas_in_flight_enc_str_1,  kepler_hwpm_mpc_cnt_8_ctas_in_flight_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_8_ctas_in_flight_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_9_CTAS_IN_FLIGHT, kepler_hwpm_mpc_cnt_9_ctas_in_flight_enc_str_1,  kepler_hwpm_mpc_cnt_9_ctas_in_flight_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_9_ctas_in_flight_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_10_CTAS_IN_FLIGHT,kepler_hwpm_mpc_cnt_10_ctas_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_10_ctas_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_10_ctas_in_flight_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_11_CTAS_IN_FLIGHT,kepler_hwpm_mpc_cnt_11_ctas_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_11_ctas_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_11_ctas_in_flight_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_12_CTAS_IN_FLIGHT,kepler_hwpm_mpc_cnt_12_ctas_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_12_ctas_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_12_ctas_in_flight_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_13_CTAS_IN_FLIGHT,kepler_hwpm_mpc_cnt_13_ctas_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_13_ctas_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_13_ctas_in_flight_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_14_CTAS_IN_FLIGHT,kepler_hwpm_mpc_cnt_14_ctas_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_14_ctas_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_14_ctas_in_flight_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_15_CTAS_IN_FLIGHT,kepler_hwpm_mpc_cnt_15_ctas_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_15_ctas_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_15_ctas_in_flight_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_16_CTAS_IN_FLIGHT,kepler_hwpm_mpc_cnt_16_ctas_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_16_ctas_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_16_ctas_in_flight_enc_str_5},

    { KEPLER_HWPM_MPC_CNT_1_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_1_ctas_in_flight1_enc_str_1,  kepler_hwpm_mpc_cnt_1_ctas_in_flight1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_1_ctas_in_flight1_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_2_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_2_ctas_in_flight1_enc_str_1,  kepler_hwpm_mpc_cnt_2_ctas_in_flight1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_2_ctas_in_flight1_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_3_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_3_ctas_in_flight1_enc_str_1,  kepler_hwpm_mpc_cnt_3_ctas_in_flight1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_3_ctas_in_flight1_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_4_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_4_ctas_in_flight1_enc_str_1,  kepler_hwpm_mpc_cnt_4_ctas_in_flight1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_4_ctas_in_flight1_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_5_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_5_ctas_in_flight1_enc_str_1,  kepler_hwpm_mpc_cnt_5_ctas_in_flight1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_5_ctas_in_flight1_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_6_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_6_ctas_in_flight1_enc_str_1,  kepler_hwpm_mpc_cnt_6_ctas_in_flight1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_6_ctas_in_flight1_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_7_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_7_ctas_in_flight1_enc_str_1,  kepler_hwpm_mpc_cnt_7_ctas_in_flight1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_7_ctas_in_flight1_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_8_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_8_ctas_in_flight1_enc_str_1,  kepler_hwpm_mpc_cnt_8_ctas_in_flight1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_8_ctas_in_flight1_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_9_CTAS_IN_FLIGHT1, kepler_hwpm_mpc_cnt_9_ctas_in_flight1_enc_str_1,  kepler_hwpm_mpc_cnt_9_ctas_in_flight1_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_9_ctas_in_flight1_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_10_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_cnt_10_ctas_in_flight1_enc_str_1, kepler_hwpm_mpc_cnt_10_ctas_in_flight1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_10_ctas_in_flight1_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_11_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_cnt_11_ctas_in_flight1_enc_str_1, kepler_hwpm_mpc_cnt_11_ctas_in_flight1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_11_ctas_in_flight1_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_12_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_cnt_12_ctas_in_flight1_enc_str_1, kepler_hwpm_mpc_cnt_12_ctas_in_flight1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_12_ctas_in_flight1_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_13_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_cnt_13_ctas_in_flight1_enc_str_1, kepler_hwpm_mpc_cnt_13_ctas_in_flight1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_13_ctas_in_flight1_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_14_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_cnt_14_ctas_in_flight1_enc_str_1, kepler_hwpm_mpc_cnt_14_ctas_in_flight1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_14_ctas_in_flight1_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_15_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_cnt_15_ctas_in_flight1_enc_str_1, kepler_hwpm_mpc_cnt_15_ctas_in_flight1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_15_ctas_in_flight1_enc_str_5},
    { KEPLER_HWPM_MPC_CNT_16_CTAS_IN_FLIGHT1,kepler_hwpm_mpc_cnt_16_ctas_in_flight1_enc_str_1, kepler_hwpm_mpc_cnt_16_ctas_in_flight1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_16_ctas_in_flight1_enc_str_5},

    { KEPLER_HWPM_MPC_CNT_1_CTAS_IN_FLIGHT2, kepler_hwpm_mpc_cnt_1_ctas_in_flight2_enc_str_1,  kepler_hwpm_mpc_cnt_1_ctas_in_flight2_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_1_ctas_in_flight2_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_2_CTAS_IN_FLIGHT2, kepler_hwpm_mpc_cnt_2_ctas_in_flight2_enc_str_1,  kepler_hwpm_mpc_cnt_2_ctas_in_flight2_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_2_ctas_in_flight2_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_3_CTAS_IN_FLIGHT2, kepler_hwpm_mpc_cnt_3_ctas_in_flight2_enc_str_1,  kepler_hwpm_mpc_cnt_3_ctas_in_flight2_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_3_ctas_in_flight2_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_4_CTAS_IN_FLIGHT2, kepler_hwpm_mpc_cnt_4_ctas_in_flight2_enc_str_1,  kepler_hwpm_mpc_cnt_4_ctas_in_flight2_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_4_ctas_in_flight2_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_5_CTAS_IN_FLIGHT2, kepler_hwpm_mpc_cnt_5_ctas_in_flight2_enc_str_1,  kepler_hwpm_mpc_cnt_5_ctas_in_flight2_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_5_ctas_in_flight2_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_6_CTAS_IN_FLIGHT2, kepler_hwpm_mpc_cnt_6_ctas_in_flight2_enc_str_1,  kepler_hwpm_mpc_cnt_6_ctas_in_flight2_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_6_ctas_in_flight2_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_7_CTAS_IN_FLIGHT2, kepler_hwpm_mpc_cnt_7_ctas_in_flight2_enc_str_1,  kepler_hwpm_mpc_cnt_7_ctas_in_flight2_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_7_ctas_in_flight2_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_8_CTAS_IN_FLIGHT2, kepler_hwpm_mpc_cnt_8_ctas_in_flight2_enc_str_1,  kepler_hwpm_mpc_cnt_8_ctas_in_flight2_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_8_ctas_in_flight2_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_9_CTAS_IN_FLIGHT2, kepler_hwpm_mpc_cnt_9_ctas_in_flight2_enc_str_1,  kepler_hwpm_mpc_cnt_9_ctas_in_flight2_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_9_ctas_in_flight2_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_10_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_cnt_10_ctas_in_flight2_enc_str_1, kepler_hwpm_mpc_cnt_10_ctas_in_flight2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_10_ctas_in_flight2_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_11_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_cnt_11_ctas_in_flight2_enc_str_1, kepler_hwpm_mpc_cnt_11_ctas_in_flight2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_11_ctas_in_flight2_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_12_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_cnt_12_ctas_in_flight2_enc_str_1, kepler_hwpm_mpc_cnt_12_ctas_in_flight2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_12_ctas_in_flight2_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_13_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_cnt_13_ctas_in_flight2_enc_str_1, kepler_hwpm_mpc_cnt_13_ctas_in_flight2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_13_ctas_in_flight2_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_14_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_cnt_14_ctas_in_flight2_enc_str_1, kepler_hwpm_mpc_cnt_14_ctas_in_flight2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_14_ctas_in_flight2_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_15_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_cnt_15_ctas_in_flight2_enc_str_1, kepler_hwpm_mpc_cnt_15_ctas_in_flight2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_15_ctas_in_flight2_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_16_CTAS_IN_FLIGHT2,kepler_hwpm_mpc_cnt_16_ctas_in_flight2_enc_str_1, kepler_hwpm_mpc_cnt_16_ctas_in_flight2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_16_ctas_in_flight2_enc_str_4},

    { KEPLER_HWPM_MPC_CNT_1_PIXEL_WARPS_IN_FLIGHT, kepler_hwpm_mpc_cnt_1_pixel_warps_in_flight_enc_str_1,  kepler_hwpm_mpc_cnt_1_pixel_warps_in_flight_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_1_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_2_PIXEL_WARPS_IN_FLIGHT, kepler_hwpm_mpc_cnt_2_pixel_warps_in_flight_enc_str_1,  kepler_hwpm_mpc_cnt_2_pixel_warps_in_flight_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_2_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_3_PIXEL_WARPS_IN_FLIGHT, kepler_hwpm_mpc_cnt_3_pixel_warps_in_flight_enc_str_1,  kepler_hwpm_mpc_cnt_3_pixel_warps_in_flight_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_3_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_4_PIXEL_WARPS_IN_FLIGHT, kepler_hwpm_mpc_cnt_4_pixel_warps_in_flight_enc_str_1,  kepler_hwpm_mpc_cnt_4_pixel_warps_in_flight_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_4_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_5_PIXEL_WARPS_IN_FLIGHT, kepler_hwpm_mpc_cnt_5_pixel_warps_in_flight_enc_str_1,  kepler_hwpm_mpc_cnt_5_pixel_warps_in_flight_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_5_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_6_PIXEL_WARPS_IN_FLIGHT, kepler_hwpm_mpc_cnt_6_pixel_warps_in_flight_enc_str_1,  kepler_hwpm_mpc_cnt_6_pixel_warps_in_flight_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_6_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_7_PIXEL_WARPS_IN_FLIGHT, kepler_hwpm_mpc_cnt_7_pixel_warps_in_flight_enc_str_1,  kepler_hwpm_mpc_cnt_7_pixel_warps_in_flight_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_7_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_8_PIXEL_WARPS_IN_FLIGHT, kepler_hwpm_mpc_cnt_8_pixel_warps_in_flight_enc_str_1,  kepler_hwpm_mpc_cnt_8_pixel_warps_in_flight_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_8_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_9_PIXEL_WARPS_IN_FLIGHT, kepler_hwpm_mpc_cnt_9_pixel_warps_in_flight_enc_str_1,  kepler_hwpm_mpc_cnt_9_pixel_warps_in_flight_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_9_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_10_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_10_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_10_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_10_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_11_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_11_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_11_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_11_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_12_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_12_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_12_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_12_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_13_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_13_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_13_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_13_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_14_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_14_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_14_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_14_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_15_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_15_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_15_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_15_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_16_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_16_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_16_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_16_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_17_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_17_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_17_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_17_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_18_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_18_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_18_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_18_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_19_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_19_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_19_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_19_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_20_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_20_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_20_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_20_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_21_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_21_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_21_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_21_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_22_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_22_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_22_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_22_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_23_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_23_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_23_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_23_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_24_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_24_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_24_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_24_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_25_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_25_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_25_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_25_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_26_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_26_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_26_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_26_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_27_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_27_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_27_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_27_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_28_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_28_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_28_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_28_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_29_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_29_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_29_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_29_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_30_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_30_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_30_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_30_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_31_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_31_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_31_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_31_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_32_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_32_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_32_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_32_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_33_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_33_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_33_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_33_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_34_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_34_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_34_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_34_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_35_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_35_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_35_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_35_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_36_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_36_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_36_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_36_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_37_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_37_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_37_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_37_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_38_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_38_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_38_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_38_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_39_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_39_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_39_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_39_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_40_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_40_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_40_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_40_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_41_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_41_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_41_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_41_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_42_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_42_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_42_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_42_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_43_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_43_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_43_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_43_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_44_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_44_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_44_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_44_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_45_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_45_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_45_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_45_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_46_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_46_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_46_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_46_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_47_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_47_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_47_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_47_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_48_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_48_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_48_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_48_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_49_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_49_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_49_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_49_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_50_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_50_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_50_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_50_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_51_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_51_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_51_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_51_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_52_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_52_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_52_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_52_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_53_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_53_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_53_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_53_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_54_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_54_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_54_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_54_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_55_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_55_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_55_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_55_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_56_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_56_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_56_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_56_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_57_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_57_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_57_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_57_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_58_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_58_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_58_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_58_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_59_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_59_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_59_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_59_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_60_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_60_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_60_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_60_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_61_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_61_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_61_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_61_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_62_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_62_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_62_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_62_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_63_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_63_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_63_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_63_pixel_warps_in_flight_enc_str_4},
    { KEPLER_HWPM_MPC_CNT_64_PIXEL_WARPS_IN_FLIGHT,kepler_hwpm_mpc_cnt_64_pixel_warps_in_flight_enc_str_1, kepler_hwpm_mpc_cnt_64_pixel_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, kepler_hwpm_mpc_cnt_64_pixel_warps_in_flight_enc_str_4},
    { KEPLER_SM_ICC_HIT,                            kepler_sm_icc_hit_enc_str_1,                             kepler_sm_icc_hit_enc_str_1,                          CUPROF_EVENT_CATEGORY_CACHE, kepler_sm_icc_hit_enc_str_6},
    { KEPLER_SM_ICC_TRUE_MISS,                      kepler_sm_icc_true_miss_enc_str_1,                       kepler_sm_icc_true_miss_enc_str_1,                    CUPROF_EVENT_CATEGORY_CACHE, kepler_sm_icc_true_miss_enc_str_6},
    { KEPLER_SM_ICC_COVERED_MISS,                   kepler_sm_icc_covered_miss_enc_str_1,                    kepler_sm_icc_covered_miss_enc_str_1,                 CUPROF_EVENT_CATEGORY_CACHE, kepler_sm_icc_covered_miss_enc_str_6},
    { KEPLER_SM_ICC_PREFETCHES,                     kepler_sm_icc_prefetches_enc_str_1,                      kepler_sm_icc_prefetches_enc_str_1,                   CUPROF_EVENT_CATEGORY_CACHE, kepler_sm_icc_prefetches_enc_str_5},
    { KEPLER_SM_PRT_PENDING_ENTRIES,                kepler_sm_prt_pending_entries_enc_str_1,                 kepler_sm_prt_pending_entries_enc_str_1,              CUPROF_EVENT_CATEGORY_CACHE, kepler_sm_prt_pending_entries_enc_str_6},
    { KEPLER_SM_CANT_DISPATCH_REGISTER_INTERLOCK,   kepler_sm_cant_dispatch_register_interlock_enc_str_1,    kepler_sm_cant_dispatch_register_interlock_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_sm_cant_dispatch_register_interlock_enc_str_6},
    { KEPLER_SM_CANT_DISPATCH_MEMORY_INTERLOCK,     kepler_sm_cant_dispatch_memory_interlock_enc_str_1,      kepler_sm_cant_dispatch_memory_interlock_enc_str_1,   CUPROF_EVENT_CATEGORY_CACHE, kepler_sm_cant_dispatch_memory_interlock_enc_str_6},
    { KEPLER_SM_CANT_DISPATCH_REGISTER_READ,        kepler_sm_cant_dispatch_register_read_enc_str_1,         kepler_sm_cant_dispatch_register_read_enc_str_1,      CUPROF_EVENT_CATEGORY_CACHE, kepler_sm_cant_dispatch_register_read_enc_str_6},
    { KEPLER_SM_CANT_DISPATCH_REGISTER_WRITE,       kepler_sm_cant_dispatch_register_write_enc_str_1,        kepler_sm_cant_dispatch_register_write_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, kepler_sm_cant_dispatch_register_write_enc_str_6},
    { KEPLER_SM_CANT_DISPATCH_CRS_SPILL_FILL,       kepler_sm_cant_dispatch_crs_spill_fill_enc_str_1,        kepler_sm_cant_dispatch_crs_spill_fill_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, kepler_sm_cant_dispatch_crs_spill_fill_enc_str_6},
    { KEPLER_SM_CANT_DISPATCH_ADU_F5_RF_READ,       kepler_sm_cant_dispatch_adu_f5_rf_read_enc_str_1,        kepler_sm_cant_dispatch_adu_f5_rf_read_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, kepler_sm_cant_dispatch_adu_f5_rf_read_enc_str_6},
    { KEPLER_SM_CANT_DISPATCH_BRU_STALL,            kepler_sm_cant_dispatch_bru_stall_enc_str_1,             kepler_sm_cant_dispatch_bru_stall_enc_str_1,          CUPROF_EVENT_CATEGORY_CACHE, kepler_sm_cant_dispatch_bru_stall_enc_str_5},
    { KEPLER_SM_MEM_DIVERGENT_OR_DEFERRED_INSTRUCTION, kepler_sm_mem_divergent_or_deferred_instruction_enc_str_1, kepler_sm_mem_divergent_or_deferred_instruction_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_mem_divergent_or_deferred_instruction_enc_str_4},
    { KEPLER_LUT_COUNTER_SUB_GLD32BIT_INST,  kepler_lut_counter_sub_gld32bit_inst_enc_str_1,   kepler_lut_counter_sub_gld32bit_inst_enc_str_1,   CUPROF_EVENT_CATEGORY_MEMORY,kepler_lut_counter_sub_gld32bit_inst_enc_str_6},
    { KEPLER_LUT_COUNTER_SUB_GST32BIT_INST,  kepler_lut_counter_sub_gst32bit_inst_enc_str_1,   kepler_lut_counter_sub_gst32bit_inst_enc_str_1,   CUPROF_EVENT_CATEGORY_MEMORY,kepler_lut_counter_sub_gst32bit_inst_enc_str_6},
    { KEPLER_LUT_COUNTER_GLD32BIT_INST,      kepler_lut_counter_gld32bit_inst_enc_str_1,  kepler_lut_counter_gld32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gld32bit_inst_enc_str_4},
    { KEPLER_LUT_COUNTER_GST32BIT_INST,      kepler_lut_counter_gst32bit_inst_enc_str_1,  kepler_lut_counter_gst32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gst32bit_inst_enc_str_4},
    { KEPLER_LUT_COUNTER_GLD64BIT_INST,      kepler_lut_counter_gld64bit_inst_enc_str_1,  kepler_lut_counter_gld64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gst64bit_inst_enc_str_4},
    { KEPLER_LUT_COUNTER_GST64BIT_INST,      kepler_lut_counter_gst64bit_inst_enc_str_1,  kepler_lut_counter_gst64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gst64bit_inst_enc_str_4},
    { KEPLER_LUT_COUNTER_GLD128BIT_INST,     kepler_lut_counter_gld128bit_inst_enc_str_1, kepler_lut_counter_gld128bit_inst_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gst128bit_inst_enc_str_4},
    { KEPLER_LUT_COUNTER_GST128BIT_INST,     kepler_lut_counter_gst128bit_inst_enc_str_1, kepler_lut_counter_gst128bit_inst_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY,kepler_internal_sw_counter_gst128bit_inst_enc_str_4},

    { KEPLER_ELAPSED_CYCLES_SM,     kepler_elapsed_cycles_sm_enc_str_1, kepler_elapsed_cycles_sm_enc_str_7, CUPROF_EVENT_CATEGORY_INSTRUCTION,kepler_elapsed_cycles_sm_enc_str_7},

    { KEPLER_SM_GLOBAL_RED_MEM_DIVERGENCE_REPLAYS_INTERNAL,  kepler_sm_global_red_mem_divergence_replays_internal_enc_str_1,   kepler_sm_global_red_mem_divergence_replays_internal_enc_str_1,   CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_global_red_mem_divergence_replays_enc_str_6},
    { KEPLER_SM_GLOBAL_ATOM_MEM_DIVERGENCE_REPLAYS_INTERNAL, kepler_sm_global_atom_mem_divergence_replays_internal_enc_str_1,  kepler_sm_global_atom_mem_divergence_replays_internal_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_global_atom_mem_divergence_replays_enc_str_6},
    { KEPLER_SM_GLOBAL_RED_MEM_DIVERGENCE_REPLAYS,  kepler_sm_global_red_mem_divergence_replays_enc_str_1,   kepler_sm_global_red_mem_divergence_replays_enc_str_1,   CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_global_red_mem_divergence_replays_enc_str_6},
    { KEPLER_SM_GLOBAL_ATOM_MEM_DIVERGENCE_REPLAYS, kepler_sm_global_atom_mem_divergence_replays_enc_str_1,  kepler_sm_global_atom_mem_divergence_replays_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_global_atom_mem_divergence_replays_enc_str_6},
    { KEPLER_SM_GLOBAL_RED_TRANSACTIONS,            kepler_sm_global_red_transactions_enc_str_1,             kepler_sm_global_red_transactions_enc_str_1,             CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_global_atom_cas_transactions_enc_str_6},
    { KEPLER_SM_GLOBAL_ATOM_TRANSACTIONS,           kepler_sm_global_atom_transactions_enc_str_1,            kepler_sm_global_atom_transactions_enc_str_1,            CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_global_atom_cas_transactions_enc_str_6},
    { KEPLER_SM_GLOBAL_ATOM_CAS_TRANSACTIONS,       kepler_sm_global_atom_cas_transactions_enc_str_1,        kepler_sm_global_atom_cas_transactions_enc_str_1,        CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_global_atom_cas_transactions_enc_str_6},
    { KEPLER_SM_L1_ATOM_CAS_COUNT,                  kepler_sm_l1_atom_cas_count_enc_str_1,                   kepler_sm_l1_atom_cas_count_enc_str_2,                   CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_l1_atom_cas_count_enc_str_5},

    { KEPLER_LTC0_READ_VIDMEM_SECTORS_FBP,      kepler_ltc0_read_vidmem_sectors_fbp_enc_str_1,   kepler_ltc0_read_vidmem_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc0_read_vidmem_sectors_fbp_enc_str_6},
    { KEPLER_LTC1_READ_VIDMEM_SECTORS_FBP,      kepler_ltc1_read_vidmem_sectors_fbp_enc_str_1,   kepler_ltc1_read_vidmem_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc0_read_vidmem_sectors_fbp_enc_str_6},
    { KEPLER_LTC2_READ_VIDMEM_SECTORS_FBP,      kepler_ltc2_read_vidmem_sectors_fbp_enc_str_1,   kepler_ltc2_read_vidmem_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc0_read_vidmem_sectors_fbp_enc_str_6},
    { KEPLER_LTC3_READ_VIDMEM_SECTORS_FBP,      kepler_ltc3_read_vidmem_sectors_fbp_enc_str_1,   kepler_ltc3_read_vidmem_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc0_read_vidmem_sectors_fbp_enc_str_6},

    { KEPLER_LTC0_WRITE_VIDMEM_SECTORS_FBP,      kepler_ltc0_write_vidmem_sectors_fbp_enc_str_1, kepler_ltc0_write_vidmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc0_write_vidmem_sectors_fbp_enc_str_6},
    { KEPLER_LTC1_WRITE_VIDMEM_SECTORS_FBP,      kepler_ltc1_write_vidmem_sectors_fbp_enc_str_1, kepler_ltc1_write_vidmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc0_write_vidmem_sectors_fbp_enc_str_6},
    { KEPLER_LTC2_WRITE_VIDMEM_SECTORS_FBP,      kepler_ltc2_write_vidmem_sectors_fbp_enc_str_1, kepler_ltc2_write_vidmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc0_write_vidmem_sectors_fbp_enc_str_6},
    { KEPLER_LTC3_WRITE_VIDMEM_SECTORS_FBP,      kepler_ltc3_write_vidmem_sectors_fbp_enc_str_1, kepler_ltc3_write_vidmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc0_write_vidmem_sectors_fbp_enc_str_6},

    { KEPLER_LTC0_PM_REQ_SRC_UNIT_GCC_FBP,      kepler_ltc0_pm_req_src_unit_gcc_fbp_enc_str_1,    kepler_ltc0_pm_req_src_unit_gcc_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc0_pm_req_src_unit_gcc_fbp_enc_str_6},
    { KEPLER_LTC1_PM_REQ_SRC_UNIT_GCC_FBP,      kepler_ltc1_pm_req_src_unit_gcc_fbp_enc_str_1,    kepler_ltc1_pm_req_src_unit_gcc_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc0_pm_req_src_unit_gcc_fbp_enc_str_6},
    { KEPLER_LTC2_PM_REQ_SRC_UNIT_GCC_FBP,      kepler_ltc2_pm_req_src_unit_gcc_fbp_enc_str_1,    kepler_ltc2_pm_req_src_unit_gcc_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc0_pm_req_src_unit_gcc_fbp_enc_str_6},
    { KEPLER_LTC3_PM_REQ_SRC_UNIT_GCC_FBP,      kepler_ltc3_pm_req_src_unit_gcc_fbp_enc_str_1,    kepler_ltc3_pm_req_src_unit_gcc_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc0_pm_req_src_unit_gcc_fbp_enc_str_6},

    { KEPLER_TEX0_BANK_CONFLICTS,    kepler_tex0_bank_conflicts_enc_str_1,   kepler_tex0_bank_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex0_bank_conflicts_enc_str_7},
    { KEPLER_TEX1_BANK_CONFLICTS,    kepler_tex1_bank_conflicts_enc_str_1,   kepler_tex1_bank_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex0_bank_conflicts_enc_str_7},
    { KEPLER_TEX2_BANK_CONFLICTS,    kepler_tex2_bank_conflicts_enc_str_1,   kepler_tex2_bank_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex0_bank_conflicts_enc_str_7},
    { KEPLER_TEX3_BANK_CONFLICTS,    kepler_tex3_bank_conflicts_enc_str_1,   kepler_tex3_bank_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex0_bank_conflicts_enc_str_7},


    {KEPLER_LTC0_REQUEST_APERTURE_SYSMEM, kepler_ltc0_request_aperture_sysmem_enc_str_1, kepler_ltc0_request_aperture_sysmem_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc0_request_aperture_sysmem_enc_str_7},
    {KEPLER_LTC1_REQUEST_APERTURE_SYSMEM, kepler_ltc1_request_aperture_sysmem_enc_str_1, kepler_ltc1_request_aperture_sysmem_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc1_request_aperture_sysmem_enc_str_6},
    {KEPLER_LTC2_REQUEST_APERTURE_SYSMEM, kepler_ltc2_request_aperture_sysmem_enc_str_1, kepler_ltc2_request_aperture_sysmem_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc2_request_aperture_sysmem_enc_str_5},
    {KEPLER_LTC3_REQUEST_APERTURE_SYSMEM, kepler_ltc3_request_aperture_sysmem_enc_str_1, kepler_ltc3_request_aperture_sysmem_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc3_request_aperture_sysmem_enc_str_5},

    {KEPLER_LTC0_REQUEST_APERTURE_VIDMEM, kepler_ltc0_request_aperture_vidmem_enc_str_1, kepler_ltc0_request_aperture_vidmem_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc0_request_aperture_vidmem_enc_str_7},
    {KEPLER_LTC1_REQUEST_APERTURE_VIDMEM, kepler_ltc1_request_aperture_vidmem_enc_str_1, kepler_ltc1_request_aperture_vidmem_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc1_request_aperture_vidmem_enc_str_6},
    {KEPLER_LTC2_REQUEST_APERTURE_VIDMEM, kepler_ltc2_request_aperture_vidmem_enc_str_1, kepler_ltc2_request_aperture_vidmem_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc2_request_aperture_vidmem_enc_str_5},
    {KEPLER_LTC3_REQUEST_APERTURE_VIDMEM, kepler_ltc3_request_aperture_vidmem_enc_str_1, kepler_ltc3_request_aperture_vidmem_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc3_request_aperture_vidmem_enc_str_5},
    {KEPLER_LTC0_REQUEST_SRC_UNIT_GCC, kepler_ltc0_request_src_unit_gcc_enc_str_1, kepler_ltc0_request_src_unit_gcc_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc0_request_src_unit_gcc_enc_str_7},
    {KEPLER_LTC1_REQUEST_SRC_UNIT_GCC, kepler_ltc1_request_src_unit_gcc_enc_str_1, kepler_ltc1_request_src_unit_gcc_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc1_request_src_unit_gcc_enc_str_6},
    {KEPLER_LTC2_REQUEST_SRC_UNIT_GCC, kepler_ltc2_request_src_unit_gcc_enc_str_1, kepler_ltc2_request_src_unit_gcc_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc2_request_src_unit_gcc_enc_str_5},
    {KEPLER_LTC3_REQUEST_SRC_UNIT_GCC, kepler_ltc3_request_src_unit_gcc_enc_str_1, kepler_ltc3_request_src_unit_gcc_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc3_request_src_unit_gcc_enc_str_5},

    {KEPLER_MMU_HUB_TLB_MISS_INT,   kepler_mmu_hub_tlb_miss_int_enc_str_1, kepler_mmu_hub_tlb_miss_int_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_mmu_fill_pte_miss_int_enc_str_5},
    {KEPLER_MMU_FILL_PTE_MISS_INT,  kepler_mmu_fill_pte_miss_int_enc_str_1, kepler_mmu_fill_pte_miss_int_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_mmu_fill_pte_miss_int_enc_str_5 },
    {KEPLER_MMU_GPCL2_TLB_MISS_INT, kepler_mmu_gpcl2_tlb_miss_int_enc_str_1, kepler_mmu_gpcl2_tlb_miss_int_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_mmu_fill_pte_miss_int_enc_str_5 },

    {KEPLER_L1C_PRT_PENDING_ENTRIES, kepler_l1c_prt_pending_entries_enc_str_1, kepler_l1c_prt_pending_entries_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, kepler_l1c_prt_pending_entries_enc_str_7},
    {KEPLER_L1C_PRT_ENTRIES_INUSE,   kepler_l1c_prt_entries_inuse_enc_str_1,   kepler_l1c_prt_entries_inuse_enc_str_1,    CUPROF_EVENT_CATEGORY_CACHE, kepler_l1c_prt_entries_inuse_enc_str_7},
    {KEPLER_L1C_PRT_ENTRIES_USABLE,  kepler_l1c_prt_entries_usable_enc_str_1,  kepler_l1c_prt_entries_usable_enc_str_1,   CUPROF_EVENT_CATEGORY_CACHE, kepler_l1c_prt_entries_usable_enc_str_7},

    {KEPLER_LTC0_ATOMIC_L1_SECTORS_FBP, kepler_ltc0_atomic_l1_sectors_fbp_enc_str_1,kepler_ltc0_atomic_l1_sectors_fbp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc0_atomic_l1_sectors_fbp_enc_str_6},
    {KEPLER_LTC1_ATOMIC_L1_SECTORS_FBP, kepler_ltc1_atomic_l1_sectors_fbp_enc_str_1,kepler_ltc1_atomic_l1_sectors_fbp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc1_atomic_l1_sectors_fbp_enc_str_5},
    {KEPLER_LTC2_ATOMIC_L1_SECTORS_FBP, kepler_ltc2_atomic_l1_sectors_fbp_enc_str_1,kepler_ltc2_atomic_l1_sectors_fbp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc2_atomic_l1_sectors_fbp_enc_str_4},
    {KEPLER_LTC3_ATOMIC_L1_SECTORS_FBP, kepler_ltc3_atomic_l1_sectors_fbp_enc_str_1,kepler_ltc3_atomic_l1_sectors_fbp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc3_atomic_l1_sectors_fbp_enc_str_4},
    { KEPLER_TEX0_RETURN_PACKET_COUNT, kepler_tex0_return_packet_count_enc_str_1, kepler_tex0_return_packet_count_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex0_return_packet_count_enc_str_5},
    { KEPLER_TEX1_RETURN_PACKET_COUNT, kepler_tex1_return_packet_count_enc_str_1, kepler_tex1_return_packet_count_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex1_return_packet_count_enc_str_5},
    { KEPLER_TEX2_RETURN_PACKET_COUNT, kepler_tex2_return_packet_count_enc_str_1, kepler_tex2_return_packet_count_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex2_return_packet_count_enc_str_4},
    { KEPLER_TEX3_RETURN_PACKET_COUNT, kepler_tex3_return_packet_count_enc_str_1, kepler_tex3_return_packet_count_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex3_return_packet_count_enc_str_4},

    { KEPLER_SM_L1C_DIRTY_LINE_EVICTION,             kepler_sm_l1c_dirty_line_eviction_enc_str_1,           kepler_sm_l1c_dirty_line_eviction_enc_str_1,           CUPROF_EVENT_CATEGORY_CACHE, kepler_sm_l1c_dirty_line_eviction_enc_str_6 },
    { KEPLER_SM_L1C_PARTIAL_LOCAL_CACHED_ST_MISSES,  kepler_sm_l1c_partial_local_cached_st_misses_enc_str_1,kepler_sm_l1c_partial_local_cached_st_misses_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, kepler_sm_l1c_partial_local_cached_st_misses_enc_str_6 },
    {KEPLER_MC_DEV0_CMD_WRITE,    kepler_mc_dev0_cmd_write_enc_str_1,    kepler_mc_dev0_cmd_write_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, kepler_mc_dev0_cmd_write_enc_str_4},
    {KEPLER_MC_DEV0_CMD_WRITE4,   kepler_mc_dev0_cmd_write4_enc_str_1,   kepler_mc_dev0_cmd_write4_enc_str_1,   CUPROF_EVENT_CATEGORY_MEMORY, kepler_mc_dev0_cmd_write4_enc_str_4},
    {KEPLER_MC_DEV0_CMD_WRITE8,   kepler_mc_dev0_cmd_write8_enc_str_1,   kepler_mc_dev0_cmd_write8_enc_str_1,   CUPROF_EVENT_CATEGORY_MEMORY, kepler_mc_dev0_cmd_write8_enc_str_4},
    {KEPLER_MC_DEV0_CMD_WRITE8X2, kepler_mc_dev0_cmd_write8x2_enc_str_1, kepler_mc_dev0_cmd_write8x2_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, kepler_mc_dev0_cmd_write8x2_enc_str_4},
    {KEPLER_MC_DEV0_CMD_READ,     kepler_mc_dev0_cmd_read_enc_str_1,     kepler_mc_dev0_cmd_read_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, kepler_mc_dev0_cmd_read_enc_str_4},
    {KEPLER_MC_DEV0_CMD_READ4,    kepler_mc_dev0_cmd_read4_enc_str_1,    kepler_mc_dev0_cmd_read4_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, kepler_mc_dev0_cmd_read4_enc_str_4},
    {KEPLER_MC_DEV0_CMD_READ8,    kepler_mc_dev0_cmd_read8_enc_str_1,    kepler_mc_dev0_cmd_read8_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, kepler_mc_dev0_cmd_read8_enc_str_4},
    {KEPLER_MC_DEV0_CMD_READ8X2,  kepler_mc_dev0_cmd_read8x2_enc_str_1,  kepler_mc_dev0_cmd_read8x2_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, kepler_mc_dev0_cmd_read8x2_enc_str_4},

    {KEPLER_LTC_LTCX_MC_REQ_RD_SIZE_32B,    kepler_ltc_ltcx_mc_req_rd_size_32b_enc_str_1,     kepler_ltc_ltcx_mc_req_rd_size_32b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, kepler_ltc_ltcx_mc_req_rd_size_32b_enc_str_4},
    {KEPLER_LTC_LTCX_MC_REQ_RD_SIZE_64B,    kepler_ltc_ltcx_mc_req_rd_size_64b_enc_str_1,     kepler_ltc_ltcx_mc_req_rd_size_64b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, kepler_ltc_ltcx_mc_req_rd_size_64b_enc_str_4},
    {KEPLER_LTC_LTCX_MC_REQ_WR_SIZE_16B,    kepler_ltc_ltcx_mc_req_wr_size_16b_enc_str_1,     kepler_ltc_ltcx_mc_req_wr_size_16b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, kepler_ltc_ltcx_mc_req_wr_size_16b_enc_str_4},
    {KEPLER_LTC_LTCX_MC_REQ_WR_SIZE_32B,    kepler_ltc_ltcx_mc_req_wr_size_32b_enc_str_1,     kepler_ltc_ltcx_mc_req_wr_size_32b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, kepler_ltc_ltcx_mc_req_wr_size_32b_enc_str_4},
    {KEPLER_LTC_LTCX_MC_REQ_WR_SIZE_64B,    kepler_ltc_ltcx_mc_req_wr_size_64b_enc_str_1,     kepler_ltc_ltcx_mc_req_wr_size_64b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, kepler_ltc_ltcx_mc_req_wr_size_64b_enc_str_4},

    {KEPLER_LTC_LTCX_REQ_RD_SECTOR_COUNT_1, kepler_ltc_ltcx_req_rd_sector_count_1_enc_str_1,  kepler_ltc_ltcx_req_rd_sector_count_1_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, kepler_ltc_ltcx_req_rd_sector_count_1_enc_str_4},
    {KEPLER_LTC_LTCX_REQ_RD_SECTOR_COUNT_2, kepler_ltc_ltcx_req_rd_sector_count_2_enc_str_1,  kepler_ltc_ltcx_req_rd_sector_count_2_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, kepler_ltc_ltcx_req_rd_sector_count_2_enc_str_4},
    {KEPLER_LTC_LTCX_REQ_RD_SECTOR_COUNT_3, kepler_ltc_ltcx_req_rd_sector_count_3_enc_str_1,  kepler_ltc_ltcx_req_rd_sector_count_3_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, kepler_ltc_ltcx_req_rd_sector_count_3_enc_str_4},
    {KEPLER_LTC_LTCX_REQ_RD_SECTOR_COUNT_4, kepler_ltc_ltcx_req_rd_sector_count_4_enc_str_1,  kepler_ltc_ltcx_req_rd_sector_count_4_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, kepler_ltc_ltcx_req_rd_sector_count_4_enc_str_4},

    {KEPLER_LTC_LTCX_REQ_WR_SECTOR_COUNT_1, kepler_ltc_ltcx_req_wr_sector_count_1_enc_str_1,  kepler_ltc_ltcx_req_wr_sector_count_1_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, kepler_ltc_ltcx_req_wr_sector_count_1_enc_str_4},
    {KEPLER_LTC_LTCX_REQ_WR_SECTOR_COUNT_2, kepler_ltc_ltcx_req_wr_sector_count_2_enc_str_1,  kepler_ltc_ltcx_req_wr_sector_count_2_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, kepler_ltc_ltcx_req_wr_sector_count_2_enc_str_4},
    {KEPLER_LTC_LTCX_REQ_WR_SECTOR_COUNT_3, kepler_ltc_ltcx_req_wr_sector_count_3_enc_str_1,  kepler_ltc_ltcx_req_wr_sector_count_3_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, kepler_ltc_ltcx_req_wr_sector_count_3_enc_str_4},
    {KEPLER_LTC_LTCX_REQ_WR_SECTOR_COUNT_4, kepler_ltc_ltcx_req_wr_sector_count_4_enc_str_1,  kepler_ltc_ltcx_req_wr_sector_count_4_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, kepler_ltc_ltcx_req_wr_sector_count_4_enc_str_4},
    //From James Daming:
    //uTLB0 services read and write requests from L1 and PE and read requests from tex0
    //uTLB1 does not support write requests. It services read requests from PE and tex1
    {KEPLER_GPCL1_TLB_HIT,  gpcl1_tlb_hit_enc_str_1,  gpcl1_tlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, gpcl1_tlb_hit_enc_str_2},
    {KEPLER_GPCL1_TLB_MISS, gpcl1_tlb_miss_enc_str_1, gpcl1_tlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, gpcl1_tlb_miss_enc_str_2},
    {KEPLER_TPC0_UTLB0_HIT, tpc0_utlb0_hit_enc_str_1, tpc0_utlb0_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, tpc0_utlb0_hit_enc_str_2},
    {KEPLER_TPC1_UTLB0_HIT, tpc1_utlb0_hit_enc_str_1, tpc1_utlb0_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, tpc1_utlb0_hit_enc_str_2},
    {KEPLER_TPC2_UTLB0_HIT, tpc2_utlb0_hit_enc_str_1, tpc2_utlb0_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, tpc2_utlb0_hit_enc_str_2},
    {KEPLER_TPC0_UTLB1_HIT, tpc0_utlb1_hit_enc_str_1, tpc0_utlb1_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, tpc0_utlb1_hit_enc_str_2},
    {KEPLER_TPC1_UTLB1_HIT, tpc1_utlb1_hit_enc_str_1, tpc1_utlb1_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, tpc1_utlb1_hit_enc_str_2},
    {KEPLER_TPC2_UTLB1_HIT, tpc2_utlb1_hit_enc_str_1, tpc2_utlb1_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, tpc2_utlb1_hit_enc_str_2},
    {KEPLER_TPC0_UTLB0_MISS, tpc0_utlb0_miss_enc_str_1, tpc0_utlb0_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, tpc0_utlb0_miss_enc_str_2},
    {KEPLER_TPC1_UTLB0_MISS, tpc1_utlb0_miss_enc_str_1, tpc1_utlb0_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, tpc1_utlb0_miss_enc_str_2},
    {KEPLER_TPC2_UTLB0_MISS, tpc2_utlb0_miss_enc_str_1, tpc2_utlb0_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, tpc2_utlb0_miss_enc_str_2},
    {KEPLER_TPC0_UTLB1_MISS, tpc0_utlb1_miss_enc_str_1, tpc0_utlb1_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, tpc0_utlb1_miss_enc_str_2},
    {KEPLER_TPC1_UTLB1_MISS, tpc1_utlb1_miss_enc_str_1, tpc1_utlb1_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, tpc1_utlb1_miss_enc_str_2},
    {KEPLER_TPC2_UTLB1_MISS, tpc2_utlb1_miss_enc_str_1, tpc2_utlb1_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, tpc2_utlb1_miss_enc_str_2},
    {KEPLER_RGG_UTLB_HIT, rgg_utlb_hit_enc_str_1, rgg_utlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, rgg_utlb_hit_enc_str_2},
    {KEPLER_RGG_UTLB_MISS, rgg_utlb_miss_enc_str_1, rgg_utlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, rgg_utlb_miss_enc_str_2},

    {KEPLER_TEX0_LG_SECTOR_QUERIES, kepler_tex0_lg_sector_queries_enc_str_1, kepler_tex0_lg_sector_queries_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex0_lg_sector_queries_enc_str_2},
    {KEPLER_TEX1_LG_SECTOR_QUERIES, kepler_tex1_lg_sector_queries_enc_str_1, kepler_tex1_lg_sector_queries_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex1_lg_sector_queries_enc_str_2},
    {KEPLER_TEX2_LG_SECTOR_QUERIES, kepler_tex2_lg_sector_queries_enc_str_1, kepler_tex2_lg_sector_queries_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex2_lg_sector_queries_enc_str_2},
    {KEPLER_TEX3_LG_SECTOR_QUERIES, kepler_tex3_lg_sector_queries_enc_str_1, kepler_tex2_lg_sector_queries_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex3_lg_sector_queries_enc_str_2},

    {KEPLER_TEX0_LG_MISSED_SECTORS, kepler_tex0_lg_missed_sectors_enc_str_1, kepler_tex0_lg_missed_sectors_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex0_lg_missed_sectors_enc_str_2},
    {KEPLER_TEX1_LG_MISSED_SECTORS, kepler_tex1_lg_missed_sectors_enc_str_1, kepler_tex1_lg_missed_sectors_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex1_lg_missed_sectors_enc_str_2},
    {KEPLER_TEX2_LG_MISSED_SECTORS, kepler_tex2_lg_missed_sectors_enc_str_1, kepler_tex2_lg_missed_sectors_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex2_lg_missed_sectors_enc_str_2},
    {KEPLER_TEX3_LG_MISSED_SECTORS, kepler_tex3_lg_missed_sectors_enc_str_1, kepler_tex3_lg_missed_sectors_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, kepler_tex3_lg_missed_sectors_enc_str_2},

    { KEPLER_SM_IMC_DIVERGENCE_REPLAY,             kepler_sm_imc_divergence_replay_enc_str_1,          kepler_sm_imc_divergence_replay_enc_str_1,         CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_imc_divergence_replay_enc_str_2,        },
    { KEPLER_SM_PE_STOMP_DEFERRALS,                kepler_sm_pe_stomp_deferrals_enc_str_1,             kepler_sm_pe_stomp_deferrals_enc_str_1,            CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_pe_stomp_deferrals_enc_str_2,           },
    { KEPLER_SM_PRT_FULL_DEFERRALS,                kepler_sm_prt_full_deferrals_enc_str_1,             kepler_sm_prt_full_deferrals_enc_str_1,            CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_prt_full_deferrals_enc_str_2,           },
    { KEPLER_SM_WDB_FULL_DEFERRALS,                kepler_sm_wdb_full_deferrals_enc_str_1,             kepler_sm_wdb_full_deferrals_enc_str_1,            CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_wdb_full_deferrals_enc_str_2,           },
    { KEPLER_SM_T2M_FULL_DEFERRALS,                kepler_sm_t2m_full_deferrals_enc_str_1,             kepler_sm_t2m_full_deferrals_enc_str_1,            CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_t2m_full_deferrals_enc_str_2,           },
    { KEPLER_SM_SET_BUSY_DEFERRALS,                kepler_sm_set_busy_deferrals_enc_str_1,             kepler_sm_set_busy_deferrals_enc_str_1,            CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_set_busy_deferrals_enc_str_2,           },
    { KEPLER_SM_UNCACHED_SET_BUSY_DEFERRALS,       kepler_sm_uncached_set_busy_deferrals_enc_str_1,    kepler_sm_uncached_set_busy_deferrals_enc_str_1,   CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_uncached_set_busy_deferrals_enc_str_2,  },
    { KEPLER_SM_ATOM_SET_BUSY_DEFERRALS,           kepler_sm_atom_set_busy_deferrals_enc_str_1,        kepler_sm_atom_set_busy_deferrals_enc_str_1,       CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_atom_set_busy_deferrals_enc_str_2,      },
    { KEPLER_SM_LD_HIT_UNDER_MISS_DEFERRALS,       kepler_sm_ld_hit_under_miss_deferrals_enc_str_1,    kepler_sm_ld_hit_under_miss_deferrals_enc_str_1,   CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_ld_hit_under_miss_deferrals_enc_str_2,  },
    { KEPLER_SM_L1_MISS_GRANTS,                    kepler_sm_l1_miss_grants_enc_str_1,                 kepler_sm_l1_miss_grants_enc_str_1,                CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_l1_miss_grants_enc_str_2,               },
    { KEPLER_SM_PRE_SCHEDULED_REPLAYS,             kepler_sm_pre_scheduled_replays_enc_str_1,          kepler_sm_pre_scheduled_replays_enc_str_1,         CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_pre_scheduled_replays_enc_str_2,        },
    { KEPLER_SM_KILLED_PRE_SCHEDULED_REPLAYS,      kepler_sm_killed_pre_scheduled_replays_enc_str_1,   kepler_sm_killed_pre_scheduled_replays_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_killed_pre_scheduled_replays_enc_str_2, },
    { KEPLER_SM_CCTL_MEM_DIVERGENCE_REPLAYS,       kepler_sm_cctl_mem_divergence_replays_enc_str_1,    kepler_sm_cctl_mem_divergence_replays_enc_str_1,   CUPROF_EVENT_CATEGORY_MEMORY, kepler_sm_killed_pre_scheduled_replays_enc_str_2,  },

    {KEPLER_MC_REQ_CLIENT_MATCH_SET0,    kepler_mc_req_client_match_set0_enc_str_1,    kepler_mc_req_client_match_set0_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, kepler_mc_req_client_match_set0_enc_str_2},
    {KEPLER_MC_REQ_CLIENT_MATCH_SET1,   kepler_mc_req_client_match_set1_enc_str_1,   kepler_mc_req_client_match_set1_enc_str_1,   CUPROF_EVENT_CATEGORY_MEMORY, kepler_mc_req_client_match_set1_enc_str_2},
    { KEPLER_LTC0_WRITE_HUB_SECTORS_FBP, kepler_ltc0_write_hub_sectors_fbp_enc_str_1, kepler_ltc0_write_hub_sectors_fbp_enc_str_1,             CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc0_write_hub_sectors_fbp_enc_str_2},
    { KEPLER_LTC0_ATOMIC_HUB_SECTORS_FBP, kepler_ltc0_atomic_hub_sectors_fbp_enc_str_1, kepler_ltc0_atomic_hub_sectors_fbp_enc_str_1,          CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc0_atomic_hub_sectors_fbp_enc_str_2},
    { KEPLER_LTC0_READ_HUB_SECTORS_FBP, kepler_ltc0_read_hub_sectors_fbp_enc_str_1,  kepler_ltc0_read_hub_sectors_fbp_enc_str_1,               CUPROF_EVENT_CATEGORY_CACHE, kepler_ltc0_read_hub_sectors_fbp_enc_str_2},
    {KEPLER_LTC0_READ_TEX_HIT_SECTORS_FBP_GK20A, kepler_ltc0_read_tex_hit_sectors_fbp_enc_str_1, kepler_ltc0_read_tex_hit_sectors_fbp_enc_str_5, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc0_read_tex_hit_sectors_fbp_enc_str_6},
    {KEPLER_LTC0_WRITE_MISS_SECTORS_GK20A, kepler_ltc0_write_miss_sectors_enc_str_1, kepler_ltc0_write_miss_sectors_enc_str_6, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc0_write_miss_sectors_enc_str_7},
    {KEPLER_LTC0_READ_MISS_SECTORS_GK20A, kepler_ltc0_read_miss_sectors_enc_str_1, kepler_ltc0_read_miss_sectors_enc_str_6, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc0_read_miss_sectors_enc_str_7},
    {KEPLER_LTC0_WRITE_HUB_HIT_SECTORS_FBP, kepler_ltc0_write_hub_hit_sectors_fbp_enc_str_1, kepler_ltc0_write_hub_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc0_write_hub_hit_sectors_fbp_enc_str_1},
    {KEPLER_LTC0_READ_HUB_HIT_SECTORS_FBP, kepler_ltc0_read_hub_hit_sectors_fbp_enc_str_1, kepler_ltc0_read_hub_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE,kepler_ltc0_read_hub_hit_sectors_fbp_enc_str_1},

    {INVALID_PM_SIGNAL_NEW, ""}
};

CUdomainInfo domainInfoGK104   = { 13,    domainTableGK104, pKeplerSignalDescriptionArray};  // GK104/GK106/GK107
CUdomainInfo domainInfoGK110   = { 13,    domainTableGK110, pKeplerSignalDescriptionArray};
CUdomainInfo domainInfoGK208   = { 12,    domainTableGK208, pKeplerSignalDescriptionArray};
CUdomainInfo domainInfoGK20A   = { 13,    domainTableGK20A, pKeplerSignalDescriptionArray};
