/*
 * Copyright 2005-2011 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

#ifndef KEPLER_PROF_FUNC_H
#define KEPLER_PROF_FUNC_H

#include "../../prof_func.h"
#include "kepler_signals.h"

typedef struct ConcKernelTraceTable_st
{
    unsigned int jcalInstEntryPatch;
    unsigned int ldcInstrEntryPatch;
    unsigned int ldcInstrExitPatch;
    unsigned int entryPatchSize;
    unsigned int exitPatchSize;
    NvU32 *keplerConcKernelTraceEntryBinaryPatch;
    NvU32 *keplerConcKernelTraceExitBinaryPatch;
}ConcKernelTraceTable;

#endif
