/*
* Copyright 1993-2009 by NVIDIA Corporation.  All rights reserved.  All
* information contained herein is proprietary and confidential to NVIDIA
* Corporation.  Any use, reproduction, or disclosure without the written
* permission of NVIDIA Corporation is prohibited.
*/

/******************************************************************************
*
*   Module: volta_signals.c
*
*   Description:
*       volta specific signals information
*
******************************************************************************/

#include "volta_perfmon_new.h"
#include "perfmon_new.h"
#include "volta_signals.h"
#include "volta_signals_strings.h"

//TBD Check for all watchbus and PM ENABLE and group registers
PerfUnitTable PerfUnitTableGV100[] = {
// Unit-name                 PM enable                       GroupSel              maxGroups
//                      register  start end val        register  start end width
#if NVCFG(GLOBAL_ARCH_VOLTA)
// smquick has different regiser width for group selection
{PM_UNIT_SMCORE,   {0x00000304,   7,  7, 1},       {0x00000304,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
{PM_UNIT_SMQCTL,   {0x00000304,  15, 15, 1},       {0x00000304,  8, 14,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
{PM_UNIT_MIO,      {0x00000304,  23, 23, 1},       {0x00000304, 16, 22,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// SM  - watch buses from 32 to 39 (decimal) are assigned to SMK2PM_GPCTPC#TPC_MUXED_BUS_LOWER_0_#
// SM  - watch buses from 40 to 47 (decimal) are assigned to SMK2PM_GPCTPC#TPC_MUXED_BUS_UPPER_0_#
{PM_UNIT_MPC,      {0x0000040c,  31, 31, 1},       {0x0000040c,  0,  7,  8},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// MPC - watch buses from 32 to 40 (decimal) are assigned to MPC2PM_MUXED_BUS_#
{PM_UNIT_TEX,      {0x000002b0,   7,  7, 1},       {0x000002b0,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},

//Add unit for each L2 slice, this way we can set each slice independently
{PM_UNIT_LTS,      {0x00000150,   0,  0, 1},       {0x00000150,  1,  4,  5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE},
{PM_UNIT_LTS1,     {0x00000150,   0,  0, 1},       {0x00000150,  5, 10,  6},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE},
{PM_UNIT_LTS2,     {0x00000150,   0,  0, 1},       {0x00000150, 11, 15,  5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE},

{PM_UNIT_LTS_1,      {(0x00000150 + (NV_PLTS_STRIDE *1)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *1)),  1,  4,  5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},
{PM_UNIT_LTS1_1,     {(0x00000150 + (NV_PLTS_STRIDE *1)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *1)),  5, 10,  6},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},
{PM_UNIT_LTS2_1,     {(0x00000150 + (NV_PLTS_STRIDE *1)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *1)), 11, 15,  5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},

{PM_UNIT_LTC,      {0x00000028,   0,  0, 1},       {0x00000028,  1,  2,  2},  1, (NV_PLTCG_BASE),         NV_PLTCG_STRIDE,   0},
// LTC - watch buses from 12 to 15 (decimal) are assigned to LTC2PM_LTC_SECTOR_MUXED_BUS_#
{PM_UNIT_LTC1,     {0x00000028,   0,  0, 1},       {0x00000028,  3,  5,  3},  1, (NV_PLTCG_BASE),         NV_PLTCG_STRIDE,   0},
// LTC1 - watch buses from 17 to 42 (decimal) are assigned to LTC2PM_LTC_MUXED_BUS_#
{PM_UNIT_LTC2,     {0x00000028,   0,  0, 1},       {0x00000028,  6,  7,  2},  1, (NV_PLTCG_BASE),         NV_PLTCG_STRIDE,   0},
// LTC2 - watch buses from 16      (decimal) are assigned to LTC2PM_LTC_SRCUNIT_MUXED_BUS
// LTC5 - watch buses from 32 to 57(decimal) are assigned to LTC2PM_LTC_EXTENDED_MUXED_BUS_#
{PM_UNIT_FB,       {0x00000100,   0,  0, 1},       {0x00000100,   4,  10, 7},      1, NV_FBPA_PRI_BASE,                 NV_FBPA_PRI_STRIDE,0},
//FB - mwatch buses from 15 to 26(decimal) are assigned to FBPA2PM_LTC_FB_PERF_MUXED_BUS_#
{PM_UNIT_HUBMMU,   {0x00100C84,  31, 31, 1},       {0x00100C84,   0,  7, 8},  1, 0, 0, 0},
// HUBMMU - watch buses from 5 to 8(decimal) are assigned to HUBMMU2PM_HUB_MUXED_BUS_#
{PM_UNIT_HUBMMU1,  {0x00100C84,  31, 31, 1},       {0x00100C84,   30,  30, 1},  1, 0, 0, 0},
{PM_UNIT_GPCMMU1,  {0x00000884,  31, 31, 1},      {0x00000884,    8,  15, 8},  1, 0, 0, 0},
{PM_UNIT_GPCMMU,   {0x00000884,  31, 31, 1},      {0x00000884,    0,   7, 8},  1, 0, 0, 0},
{PM_UNIT_NVTX,     {0x00000470,  31, 31, 1},      {0x00000474,    0,   7, 8},  1, 0, 0, 0},
{PM_UNIT_NVRX,     {0x00000470,  31, 31, 1},      {0x00000474,    0,   7, 8},  1, 0, 0, 0},

// Units added for PCI counter profiling
{PM_UNIT_XVE1,     {0x000884f4,  31, 31, 1},      {0x000884f4,  0, 4, 5},  1, 0, 0, 0 },
{PM_UNIT_XVE2,     {0x000884f4,  31, 31, 1},      {0x000884f4,  5, 9, 5},  1, 0, 0, 0 },

// HSHUB 
{PM_UNIT_HSHUB_IG, {0x001fb000,  31, 31, 1},     {0x001fb000, 0, 9, 10},  1, 0, 0, 0 },
{PM_UNIT_HSHUB_EG, {0x001fb400,  31, 31, 1},     {0x001fb400, 0, 9, 10},  1, 0, 0, 0 },

// FE
{PM_UNIT_FE,       {0x0040415c,  31, 31, 1},     {0x0040415c, 0, 7, 8 },   1, 0, 0, 0 }, 
{PM_UNIT_SKED,     {0x00407010,  31, 31, 1},     {0x00407010, 0,10,11 },   1, 0, 0, 0 }, 
#endif /* #if NVCFG(GLOBAL_ARCH_VOLTA) */
// TODO: add other units here
{PM_UNIT_MAX                                                                          }
};

// Perf signal table for volta
// perf-event: signal0 - 2:0, signal1 - 6:4, signal2 - 10:8, signal3 - 14:12
// Some sigmals are commented and not removed so that they can be used for testing purpose in future.

#if NVCFG(GLOBAL_ARCH_VOLTA)
PerfSignalHwpmMux PerfSignalTableGV100_hwpmmux[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type
    //Watchbus is changed for gv11b but it doesn't matter for the HWPMMUx configuration so use the same table for gv11b
#if CU_VOLTA_PROFILE_SM_SIGNALS_VIA_HWPM
    // ########### SM Unit ###########
    // ***LAUNCHED***
    // sch_warps_launched               SM has launched 1 warp
    // sch_threads_launched             number of threads SM launched this cycle
    //TBD check with latest files, threads_launched watchbus looks incorrect
    {VOLTA_HWPMMUX_ACTIVE_CYCLES, volta_hwpmmux_active_cycles_enc_str_1, 0x1, 0xaaaa, 0x1, PM_UNIT_SMCORE, 1, 1},
    {VOLTA_HWPMMUX_ACTIVE_WARPS, volta_hwpmmux_active_warps_enc_str_1, 0x1, 0xffff, 0x2, PM_UNIT_SMCORE, 6, 2},
    {VOLTA_HWPMMUX_CTA_LAUNCHED, volta_hwpmmux_cta_launched_enc_str_1, 0x6, 0xaaaa, 0x7, PM_UNIT_SMCORE, 1, 7},
    {VOLTA_HWPMMUX_THREAD_INST_EXECUTED, volta_hwpmmux_thread_inst_executed_enc_str_1, 0x15, 0xffff, 0x10, PM_UNIT_SMQCTL, 6, 0},
    {VOLTA_HWPMMUX_NPO_THREAD_INST_EXECUTED, volta_hwpmmux_npo_thread_inst_executed_enc_str_1, 0x15, 0xffff, 0x18, PM_UNIT_SMQCTL, 6, 8},
    {VOLTA_HWPMMUX_WARPS_LAUNCHED, volta_hwpmmux_warps_launched_enc_str_1, 0x19, 0xaaaa, 0x17, PM_UNIT_SMQCTL, 1, 7},
    {VOLTA_HWPMMUX_THREADS_LAUNCHED, volta_hwpmmux_threads_launched_enc_str_1, 0x19, 0xffff, 0x10, PM_UNIT_SMQCTL, 6, 0},
    {VOLTA_HWPMMUX_INST_EXECUTED_HMMA_FP16_OPS, volta_inst_executed_hmma_fp16_ops_enc_str_1, 0xe, 0xaaaa, 0x1c, PM_UNIT_SMQCTL, 1, 0xc},
    {VOLTA_HWPMMUX_INST_EXECUTED_HMMA_FP32_OPS, volta_inst_executed_hmma_fp32_ops_enc_str_1, 0xe, 0xaaaa, 0x1d, PM_UNIT_SMQCTL, 1, 0xd},
    {VOLTA_HWPMMUX_INST_EXECUTED_HMMA_OPS, volta_inst_executed_hmma_ops_enc_str_1, 0x11, 0xaaaa, 0x12, PM_UNIT_SMQCTL, 1, 2},
#endif
    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};
#endif /* #if NVCFG(GLOBAL_ARCH_VOLTA) */

// Perf signal table for volta
// perf-event: signal0 - 2:0, signal1 - 6:4, signal2 - 10:8, signal3 - 14:12
// Some sigmals are commented and not removed so that they can be used for testing purpose in future.
#if NVCFG(GLOBAL_ARCH_VOLTA)
PerfSignalHwpm PerfSignalTableGV100_gpctpc[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type

#if CU_VOLTA_PROFILE_SM_SIGNALS_VIA_HWPM
    // ########### SM Unit ###########
    // ***LAUNCHED***
    // sch_warps_launched               SM has launched 1 warp
    // sch_threads_launched             number of threads SM launched this cycle
    //TBD check with latest files, threads_launched watchbus looks incorrect
    {VOLTA_HWPM_THREAD_INST_EXECUTED_0, volta_hwpm_thread_inst_executed_s0_enc_str_1, 0x15, 0xffff, 0x10, PM_UNIT_SMQCTL, 6, 0},
    {VOLTA_HWPM_NPO_THREAD_INST_EXECUTED_0, volta_hwpm_npo_thread_inst_executed_s0_enc_str_1, 0x15, 0xffff, 0x18, PM_UNIT_SMQCTL, 6, 0},
    {VOLTA_HWPM_INST_EXECUTED_S0, volta_hwpm_inst_executed_s0_enc_str_1, 0x15, 0xaaaa, 0x16, PM_UNIT_SMQCTL, 1},

    {VOLTA_SMQCTL_SHARED_LD_128B_ADDRESS_UNIFORM_S0, volta_smqctl_shared_ld_128b_address_uniform_s0_enc_str_1, 0x1d, 0xaaaa, 0x1e, PM_UNIT_SMQCTL, 1},
    {VOLTA_SMQCTL_SHARED_LD_128B_ADDRESS_UNIFORM_S1, volta_smqctl_shared_ld_128b_address_uniform_s1_enc_str_1, 0x1d, 0xaaaa, 0x2e, PM_UNIT_SMQCTL, 1},
    {VOLTA_SMQCTL_SHARED_LD_128B_ADDRESS_UNIFORM_S2, volta_smqctl_shared_ld_128b_address_uniform_s2_enc_str_1, 0x1d, 0xaaaa, 0x3e, PM_UNIT_SMQCTL, 1},
    {VOLTA_SMQCTL_SHARED_LD_128B_ADDRESS_UNIFORM_S3, volta_smqctl_shared_ld_128b_address_uniform_s3_enc_str_1, 0x1d, 0xaaaa, 0x4e, PM_UNIT_SMQCTL, 1},

    { VOLTA_HWPM_TOTAL_WARPS_LAUNCHED_0, volta_hwpm_total_warps_launched_0_enc_str_1, 0x19, 0xaaaa, 0x17, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_TOTAL_WARPS_LAUNCHED_1, volta_hwpm_total_warps_launched_1_enc_str_1, 0x19, 0xaaaa, 0x27, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_TOTAL_WARPS_LAUNCHED_2, volta_hwpm_total_warps_launched_2_enc_str_1, 0x19, 0xaaaa, 0x37, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_TOTAL_WARPS_LAUNCHED_3, volta_hwpm_total_warps_launched_3_enc_str_1, 0x19, 0xaaaa, 0x47, PM_UNIT_SMQCTL, 1 },

    {VOLTA_HWPM_RESTORE_WARPS_LAUNCHED_0, volta_hwpm_restore_warps_launched_0_enc_str_1, 0x19, 0xaaaa, 0x16, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_RESTORE_WARPS_LAUNCHED_1, volta_hwpm_restore_warps_launched_1_enc_str_1, 0x19, 0xaaaa, 0x26, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_RESTORE_WARPS_LAUNCHED_2, volta_hwpm_restore_warps_launched_2_enc_str_1, 0x19, 0xaaaa, 0x36, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_RESTORE_WARPS_LAUNCHED_3, volta_hwpm_restore_warps_launched_3_enc_str_1, 0x19, 0xaaaa, 0x46, PM_UNIT_SMQCTL, 1},

    {VOLTA_HWPM_THREADS_LAUNCHED_0, volta_hwpm_threads_launched_0_enc_str_1, 0x19, 0xffff, 0x10, PM_UNIT_SMQCTL, 6},
    {VOLTA_HWPM_THREADS_LAUNCHED_1, volta_hwpm_threads_launched_1_enc_str_1, 0x19, 0xffff, 0x20, PM_UNIT_SMQCTL, 6},
    {VOLTA_HWPM_THREADS_LAUNCHED_2, volta_hwpm_threads_launched_2_enc_str_1, 0x19, 0xffff, 0x30, PM_UNIT_SMQCTL, 6},
    {VOLTA_HWPM_THREADS_LAUNCHED_3, volta_hwpm_threads_launched_3_enc_str_1, 0x19, 0xffff, 0x40, PM_UNIT_SMQCTL, 6},

    { VOLTA_HWPM_NOP_TRIG_BIT0_5_S0, volta_hwpm_nop_trig_bit0_5_s0_enc_str_1, 0x18, 0xffff, 0x10, PM_UNIT_SMQCTL, 6 },
    { VOLTA_HWPM_NOP_TRIG_BIT0_5_S1, volta_hwpm_nop_trig_bit0_5_s1_enc_str_1, 0x18, 0xffff, 0x20, PM_UNIT_SMQCTL, 6 },
    { VOLTA_HWPM_NOP_TRIG_BIT0_5_S2, volta_hwpm_nop_trig_bit0_5_s2_enc_str_1, 0x18, 0xffff, 0x30, PM_UNIT_SMQCTL, 6 },
    { VOLTA_HWPM_NOP_TRIG_BIT0_5_S3, volta_hwpm_nop_trig_bit0_5_s3_enc_str_1, 0x18, 0xffff, 0x40, PM_UNIT_SMQCTL, 6 },

    { VOLTA_HWPM_NOP_TRIG_BIT6_S0, volta_hwpm_nop_trig_bit6_s0_enc_str_1, 0x18, 0xaaaa, 0x16, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_NOP_TRIG_BIT6_S1, volta_hwpm_nop_trig_bit6_s1_enc_str_1, 0x18, 0xaaaa, 0x26, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_NOP_TRIG_BIT6_S2, volta_hwpm_nop_trig_bit6_s2_enc_str_1, 0x18, 0xaaaa, 0x36, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_NOP_TRIG_BIT6_S3, volta_hwpm_nop_trig_bit6_s3_enc_str_1, 0x18, 0xaaaa, 0x46, PM_UNIT_SMQCTL, 1 },

    { VOLTA_HWPM_NOP_TRIG_BIT7_S0, volta_hwpm_nop_trig_bit7_s0_enc_str_1, 0x18, 0xaaaa, 0x17, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_NOP_TRIG_BIT7_S1, volta_hwpm_nop_trig_bit7_s1_enc_str_1, 0x18, 0xaaaa, 0x27, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_NOP_TRIG_BIT7_S2, volta_hwpm_nop_trig_bit7_s2_enc_str_1, 0x18, 0xaaaa, 0x37, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_NOP_TRIG_BIT7_S3, volta_hwpm_nop_trig_bit7_s3_enc_str_1, 0x18, 0xaaaa, 0x47, PM_UNIT_SMQCTL, 1 },

    { VOLTA_HWPM_ACTIVE_CYCLES_Q0, volta_hwpm_active_cycles_q0_enc_str_1, 0x1, 0xffff, 0x10, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_ACTIVE_CYCLES_Q1, volta_hwpm_active_cycles_q1_enc_str_1, 0x1, 0xffff, 0x20, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_ACTIVE_CYCLES_Q2, volta_hwpm_active_cycles_q2_enc_str_1, 0x1, 0xffff, 0x30, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_ACTIVE_CYCLES_Q3, volta_hwpm_active_cycles_q3_enc_str_1, 0x1, 0xffff, 0x40, PM_UNIT_SMQCTL, 1 },

    {VOLTA_HWPM_ACTIVE_CYCLES, volta_hwpm_active_cycles_enc_str_1, 0x1, 0xaaaa, 0x1, PM_UNIT_SMCORE, 1},
    {VOLTA_HWPM_ACTIVE_WARPS, volta_hwpm_active_warps_enc_str_1, 0x1, 0xffff, 0x2, PM_UNIT_SMCORE, 6},

    {VOLTA_HWPM_TOTAL_CTA_LAUNCHED, volta_hwpm_total_cta_launched_enc_str_1, 0x6, 0xaaaa, 0x7, PM_UNIT_SMCORE, 1},
    {VOLTA_HWPM_CTA_RESTORED, volta_hwpm_cta_restored_enc_str_1, 0x6, 0xaaaa, 0x8, PM_UNIT_SMCORE, 1 },
    
    {VOLTA_HWPM_TRAP_IN_TRAP, volta_hwpm_trap_in_trap_enc_str_1, 0x7, 0xaaaa, 0x0, PM_UNIT_SMCORE, 1 },
    {VOLTA_HWPM_TRAP_COUNT, volta_hwpm_trap_count_enc_str_1, 0x7, 0xaaaa, 0x1, PM_UNIT_SMCORE, 1 },

    {VOLTA_HWPM_INST_EXECUTED_HMMA_OPS_S0, volta_hwpm_inst_executed_hmma_ops_s0_enc_str_1, 0x11, 0xaaaa, 0x12, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_OPS_S1, volta_hwpm_inst_executed_hmma_ops_s1_enc_str_1, 0x11, 0xaaaa, 0x22, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_OPS_S2, volta_hwpm_inst_executed_hmma_ops_s2_enc_str_1, 0x11, 0xaaaa, 0x32, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_OPS_S3, volta_hwpm_inst_executed_hmma_ops_s3_enc_str_1, 0x11, 0xaaaa, 0x42, PM_UNIT_SMQCTL, 1},

    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP16_OPS_S0, volta_hwpm_inst_executed_hmma_fp16_ops_s0_enc_str_1, 0xe, 0xaaaa, 0x1c, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP16_OPS_S1, volta_hwpm_inst_executed_hmma_fp16_ops_s1_enc_str_1, 0xe, 0xaaaa, 0x2c, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP16_OPS_S2, volta_hwpm_inst_executed_hmma_fp16_ops_s2_enc_str_1, 0xe, 0xaaaa, 0x3c, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP16_OPS_S3, volta_hwpm_inst_executed_hmma_fp16_ops_s3_enc_str_1, 0xe, 0xaaaa, 0x4c, PM_UNIT_SMQCTL, 1},

    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP32_OPS_S0, volta_hwpm_inst_executed_hmma_fp32_ops_s0_enc_str_1, 0xe, 0xaaaa, 0x1d, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP32_OPS_S1, volta_hwpm_inst_executed_hmma_fp32_ops_s1_enc_str_1, 0xe, 0xaaaa, 0x2d, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP32_OPS_S2, volta_hwpm_inst_executed_hmma_fp32_ops_s2_enc_str_1, 0xe, 0xaaaa, 0x3d, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP32_OPS_S3, volta_hwpm_inst_executed_hmma_fp32_ops_s3_enc_str_1, 0xe, 0xaaaa, 0x4d, PM_UNIT_SMQCTL, 1},

#endif
    {VOLTA_PROFILER_FIRST,           volta_profiler_first_enc_str_1,           0x0000000a, 0xaaaa, 0x00000008, PM_UNIT_SMCORE, 1},
    {VOLTA_PROFILER_VALID,           volta_profiler_valid_enc_str_1,           0x0000000a, 0xaaaa, 0x00000009, PM_UNIT_SMCORE, 1},

    //mpc signals
    {VOLTA_MPC_CTAS_LAUNCHED, volta_mpc_ctas_launched_enc_str_1, 0x1e, 0xaaaa, 0x72, PM_UNIT_MPC, 1},
    {VOLTA_MPC_THREADS_LAUNCHED, volta_mpc_threads_launched_enc_str_1, 0x5a, 0xffff, 0x72, PM_UNIT_MPC, 6},
    {VOLTA_MPC_WARP_LAUNCH, volta_mpc_warp_launch_enc_str_1, 0x5a, 0xaaaa, 0x78, PM_UNIT_MPC, 1 },
    {VOLTA_MPC_WARPS_IN_FLIGHT, volta_mpc_warps_in_flight_enc_str_1, 0x42, 0xffff, 0x70, PM_UNIT_MPC, 6},
    {VOLTA_MPC_COMPUTE_CTAS_IN_FLIGHT, volta_mpc_compute_ctas_in_flight_enc_str_1, 0x3c, 0xffff, 0x70, PM_UNIT_MPC, 6},

    //Tex/eL1 signals
    // based on experiments defined in //hw/tools/perfalyze/chips/gv100/pml_files/smv.pml

    { VOLTA_MIO_L1DATA_DATA_CONFLICTS_GRP_2C, volta_mio_l1data_data_conflicts_grp_2c_enc_str_1, 0x2c, 0xffff, 0x56, PM_UNIT_MIO, 2 },
    { VOLTA_MIO_L1DATA_DATA_CONFLICTS_SM_XBAR_GRP_2C, volta_mio_l1data_data_conflicts_grp_2c_sm_xbar_enc_str_1, 0x2c, 0xaaaa, 0x58, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_SHARED_LD, volta_mio_l1data_shared_ld_enc_str_1, 0x2c, 0xaaaa, 0x59, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_SHARED_ST, volta_mio_l1data_shared_st_enc_str_1, 0x2c, 0xaaaa, 0x5a, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_SHARED_LD_REQUESTS, volta_mio_l1data_shared_ld_requests_enc_str_1, 0x2c, 0xaaaa, 0x5b, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_SHARED_ST_REQUESTS, volta_mio_l1data_shared_st_requests_enc_str_1, 0x2c, 0xaaaa, 0x5c, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_SHMEM, volta_mio_wavefront_count_l1data_shmem_enc_str_1, 0x2c, 0xaaaa, 0x5d, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1DATA_DATA_CONFLICTS, volta_mio_l1data_data_conflicts_enc_str_1, 0x6, 0xffff, 0x50, PM_UNIT_MIO, 2 },
    { VOLTA_MIO_L1DATA_DATA_CONFLICTS_SM_XBAR, volta_mio_l1data_data_conflicts_sm_xbar_enc_str_1, 0x6, 0xaaaa, 0x52, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1DATA_GLOBAL_LD, volta_mio_l1data_global_ld_enc_str_1, 0x6, 0xaaaa, 0x53, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_GLOBAL_ST, volta_mio_l1data_global_st_enc_str_1, 0x6, 0xaaaa, 0x54, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_ATOM, volta_mio_l1data_atom_enc_str_1, 0x6, 0xaaaa, 0x55, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_GLOBAL_RED, volta_mio_l1data_global_red_enc_str_1, 0x6, 0xaaaa, 0x56, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1DATA_IPA_LD, volta_mio_l1data_ipa_ld_enc_str_1, 0x6, 0xaaaa, 0x59, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_SURFACE_LD, volta_mio_l1data_surface_ld_enc_str_1, 0x6, 0xaaaa, 0x5a, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_SURFACE_ST, volta_mio_l1data_surface_st_enc_str_1, 0x6, 0xaaaa, 0x5b, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_SURFACE_ATOM, volta_mio_l1data_surface_atom_enc_str_1, 0x6, 0xaaaa, 0x5c, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_SURFACE_RED, volta_mio_l1data_surface_red_enc_str_1, 0x6, 0xaaaa, 0x5d, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA, volta_mio_wavefront_count_l1data_enc_str_1, 0x7, 0xaaaa, 0x50, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_LG, volta_mio_wavefront_count_l1data_lg_enc_str_1, 0x7, 0xaaaa, 0x51, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_BANK_READS, volta_mio_wavefront_count_l1data_bank_reads_enc_str_1, 0x7, 0xffff, 0x52, PM_UNIT_MIO, 6 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_BANK_WRITES, volta_mio_wavefront_count_l1data_bank_writes_enc_str_1, 0x7, 0xffff, 0x58, PM_UNIT_MIO, 6 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_READ, volta_mio_wavefront_count_l1data_read_enc_str_1, 0x7, 0xaaaa, 0x5e, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_WRITE, volta_mio_wavefront_count_l1data_write_enc_str_1, 0x7, 0xaaaa, 0x5f, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_SURF, volta_mio_wavefront_count_l1data_surf_enc_str_1, 0x8, 0xaaaa, 0x51, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_TEX, volta_mio_wavefront_count_l1data_tex_enc_str_1, 0x8, 0xaaaa, 0x52, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_TO_DSTAGE, volta_mio_wavefront_count_l1data_to_dstage_enc_str_1, 0x8, 0xaaaa, 0x53, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_TO_MIOP_WBB_DATA, volta_mio_wavefront_count_l1data_to_miop_wbb_data_enc_str_1, 0x8, 0xaaaa, 0x54, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1DATA_IPA_LD_REQUESTS, volta_mio_l1data_ipa_ld_requests_enc_str_1, 0x8, 0xaaaa, 0x57, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_SURFACE_ATOM_DATA_CONFLICTS, volta_mio_l1data_surface_atom_data_conflicts_enc_str_1, 0x8, 0xffff, 0x58, PM_UNIT_MIO, 2 },

    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_1, volta_mio_l1miss_l2_requests_missed_sectors_1_enc_str_1, 0xc, 0xaaaa, 0x50, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_2, volta_mio_l1miss_l2_requests_missed_sectors_2_enc_str_1, 0xc, 0xaaaa, 0x51, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_3, volta_mio_l1miss_l2_requests_missed_sectors_3_enc_str_1, 0xc, 0xaaaa, 0x52, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_4, volta_mio_l1miss_l2_requests_missed_sectors_4_enc_str_1, 0xc, 0xaaaa, 0x53, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_5, volta_mio_l1miss_l2_requests_missed_sectors_5_enc_str_1, 0xc, 0xaaaa, 0x54, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_6, volta_mio_l1miss_l2_requests_missed_sectors_6_enc_str_1, 0xc, 0xaaaa, 0x55, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_7, volta_mio_l1miss_l2_requests_missed_sectors_7_enc_str_1, 0xc, 0xaaaa, 0x56, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_8, volta_mio_l1miss_l2_requests_missed_sectors_8_enc_str_1, 0xc, 0xaaaa, 0x57, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_REQUESTS_PRECOALESCING, volta_mio_l1tag_requests_precoalescing_enc_str_1, 0x22, 0xffff, 0x50, PM_UNIT_MIO, 3 },
    { VOLTA_MIO_L1TAG_SECTORS_PRECOALESCING, volta_mio_l1tag_sectors_precoalescing_enc_str_1, 0x22, 0xffff, 0x53, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_READ_PRECOALESCING, volta_mio_l1tag_read_precoalescing_enc_str_1, 0x22, 0xaaaa, 0x58, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_WRITE_PRECOALESCING, volta_mio_l1tag_write_precoalescing_enc_str_1, 0x22, 0xaaaa, 0x59, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_LG, volta_mio_l1tag_lg_enc_str_1, 0x22, 0xaaaa, 0x5a, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE, volta_mio_l1tag_surface_enc_str_1, 0x22, 0xaaaa, 0x5b, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TEXTURE, volta_mio_l1tag_texture_enc_str_1, 0x22, 0xaaaa, 0x5c, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TEXTURE_TEX_REQUESTS, volta_mio_l1tag_texture_tex_requests_enc_str_1, 0x22, 0xaaaa, 0x5d, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TEXTURE_LD_REQUESTS, volta_mio_l1tag_texture_ld_requests_enc_str_1, 0x22, 0xaaaa, 0x5e, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1MISS_TEX2GNIC_REQUESTS_POSTCOALESCING, volta_mio_l1miss_tex2gnic_requests_postcoalescing_enc_str_1, 0xe, 0xaaaa, 0x56, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_SECTORS_SUM_POSTCOALESCING, volta_mio_l1miss_tex2gnic_sectors_sum_postcoalescing_enc_str_1, 0xe, 0xffff, 0x57, PM_UNIT_MIO, 3 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_IS_WRITE_POSTCOALESCING, volta_mio_l1miss_tex2gnic_is_write_postcoalescing_enc_str_1, 0xe, 0xaaaa, 0x5a, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_IS_READ_POSTCOALESCING, volta_mio_l1miss_tex2gnic_is_read_postcoalescing_enc_str_1, 0xe, 0xaaaa, 0x5b, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_IS_PREFETCH_POSTCOALESCING, volta_mio_l1miss_tex2gnic_is_prefetch_postcoalescing_enc_str_1, 0xe, 0xaaaa, 0x5c, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_IS_LG_POSTCOALESCING, volta_mio_l1miss_tex2gnic_is_lg_postcoalescing_enc_str_1, 0xe, 0xaaaa, 0x5d, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_IS_SURFACE_POSTCOALESCING, volta_mio_l1miss_tex2gnic_is_surface_postcoalescing_enc_str_1, 0xe, 0xaaaa, 0x5e, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_IS_TEXTURE_POSTCOALESCING, volta_mio_l1miss_tex2gnic_is_texture_postcoalescing_enc_str_1, 0xe, 0xaaaa, 0x5f, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_CACHE_SECTOR_QUERIES, volta_mio_l1tag_cache_sector_queries_enc_str_1, 0x10, 0xffff, 0x58, PM_UNIT_MIO, 5 },
    
    { VOLTA_MIO_IDC_DIVERGENCE_REPLAY, volta_mio_idc_divergence_replay_enc_str_1, 0x3, 0xaaaa, 0x50, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_IDC_DIVERGENT_INSTRUCTION, volta_mio_idc_divergent_instruction_enc_str_1, 0x3, 0xaaaa, 0x51, PM_UNIT_MIO, 1 },
    
    { VOLTA_MIO_L1TAG_TEXTURE_TEX, volta_mio_l1tag_texture_tex_enc_str_1, 0x21, 0xaaaa, 0x59, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_SET_ACCESSES, volta_mio_l1tag_set_accesses_enc_str_1, 0x14, 0xffff, 0x50, PM_UNIT_MIO, 3 },
    { VOLTA_MIO_L1TAG_SET_CONFLICTS, volta_mio_l1tag_set_conflicts_enc_str_1, 0x14, 0xaaaa, 0x53, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_ATOM_GRP_14, volta_mio_l1tag_atom_grp_14_enc_str_1, 0x14, 0xaaaa, 0x54, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_GLOBAL_RED_GRP_14, volta_mio_l1tag_global_red_grp_14_enc_str_1, 0x14, 0xaaaa, 0x55, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_LD_GRP_14, volta_mio_l1tag_surface_ld_grp_14_enc_str_1, 0x14, 0xaaaa, 0x56, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_ST_GRP_14, volta_mio_l1tag_surface_st_grp_14_enc_str_1, 0x14, 0xaaaa, 0x57, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_ATOM_GRP_14, volta_mio_l1tag_surface_atom_grp_14_enc_str_1, 0x14, 0xaaaa, 0x58, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_RED_GRP_14, volta_mio_l1tag_surface_red_grp_14_enc_str_1, 0x14, 0xaaaa, 0x59, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_LG_GRP_14, volta_mio_l1tag_lg_grp_14_enc_str_1, 0x14, 0xaaaa, 0x5a, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_GRP_14, volta_mio_l1tag_surface_grp_14_enc_str_1, 0x14, 0xaaaa, 0x5b, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TEXTURE_GRP_14, volta_mio_l1tag_texture_grp_14_enc_str_1, 0x14, 0xaaaa, 0x5c, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_SET_CONFLICTS_GRP_1A, volta_mio_l1tag_set_conflicts_grp_1a_enc_str_1, 0x1a, 0xaaaa, 0x50, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_GLOBAL_LD_GRP_1A, volta_mio_l1tag_global_ld_grp_1a_enc_str_1, 0x1a, 0xaaaa, 0x51, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_GLOBAL_ST_GRP_1A, volta_mio_l1tag_global_st_grp_1a_enc_str_1, 0x1a, 0xaaaa, 0x52, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SET_ACCESSES_GRP_1A, volta_mio_l1tag_set_accesses_grp_1a_enc_str_1, 0x1a, 0xffff, 0x53, PM_UNIT_MIO, 3 },
    { VOLTA_MIO_L1TAG_LOCAL_LD_GRP_1A, volta_mio_l1tag_local_ld_grp_1a_enc_str_1, 0x1a, 0xaaaa, 0x56, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_LOCAL_ST_GRP_1A, volta_mio_l1tag_local_st_grp_1a_enc_str_1, 0x1a, 0xaaaa, 0x57, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TEXTURE_LD_GRP_1A, volta_mio_l1tag_texture_ld_grp_1a_enc_str_1, 0x1a, 0xaaaa, 0x58, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TEXTURE_TEX_GRP_1A, volta_mio_l1tag_texture_tex_grp_1a_enc_str_1, 0x1a, 0xaaaa, 0x59, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_REQUESTS, volta_mio_l1tag_requests_enc_str_1, 0x13, 0xaaaa, 0x50, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_CCTL, volta_mio_l1tag_cctl_enc_str_1, 0x13, 0xaaaa, 0x51, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_LOCAL_CCTL, volta_mio_l1tag_local_cctl_enc_str_1, 0x13, 0xaaaa, 0x52, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_GLOBAL_CCTL, volta_mio_l1tag_global_cctl_enc_str_1, 0x13, 0xaaaa, 0x53, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_GLOBAL_ST, volta_mio_l1tag_global_st_enc_str_1, 0x13, 0xaaaa, 0x54, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_LOCAL_ST, volta_mio_l1tag_local_st_enc_str_1, 0x13, 0xaaaa, 0x55, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_MIXED_GENERIC_LD, volta_mio_l1tag_mixed_generic_ld_enc_str_1, 0x13, 0xaaaa, 0x56, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_MIXED_GENERIC_ST, volta_mio_l1tag_mixed_generic_st_enc_str_1, 0x13, 0xaaaa, 0x57, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_ST, volta_mio_l1tag_surface_st_enc_str_1, 0x13, 0xaaaa, 0x58, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TAG_TYPE_1D, volta_mio_l1tag_tag_type_1d_enc_str_1, 0x13, 0xaaaa, 0x59, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TAG_TYPE_1D_BUFFER, volta_mio_l1tag_tag_type_1d_buffer_enc_str_1, 0x13, 0xaaaa, 0x5a, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TAG_TYPE_2D, volta_mio_l1tag_tag_type_2d_enc_str_1, 0x13, 0xaaaa, 0x5b, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TAG_TYPE_3D, volta_mio_l1tag_tag_type_3d_enc_str_1, 0x13, 0xaaaa, 0x5c, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TAG_TYPE_CUBEMAP, volta_mio_l1tag_tag_type_cubemap_enc_str_1, 0x13, 0xaaaa, 0x5d, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TAG_TYPE_NO_MIPMAP, volta_mio_l1tag_tag_type_no_mipmap_enc_str_1, 0x13, 0xaaaa, 0x5e, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT, volta_mio_l1tag_sector_tag_hit_data_hit_enc_str_1, 0x1b, 0xffff, 0x51, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_BYPASS_T2D, volta_mio_l1tag_sector_tag_hit_data_hit_bypass_t2d_enc_str_1, 0x1b, 0xffff, 0x5b, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_SECTOR_TAG_MISS, volta_mio_l1tag_sector_tag_miss_enc_str_1, 0x1e, 0xffff, 0x50, PM_UNIT_MIO, 5 },

    { VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_2D, volta_mio_l1tag_sector_tag_hit_data_hit_grp_2d_enc_str_1, 0x2d, 0xffff, 0x50, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_2D, volta_mio_l1tag_sector_miss_grp_2d_enc_str_1, 0x2d, 0xffff, 0x55, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_LG_GRP_2D, volta_mio_l1tag_lg_grp_2d_enc_str_1, 0x2d, 0xaaaa, 0x5a, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_GRP_2D, volta_mio_l1tag_surface_grp_2d_enc_str_1, 0x2d, 0xaaaa, 0x5b, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TEXTURE_GRP_2D, volta_mio_l1tag_texture_grp_2d_enc_str_1, 0x2d, 0xaaaa, 0x5c, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_GLOBAL_LD_GRP_2D, volta_mio_l1tag_global_ld_grp_2d_enc_str_1, 0x2d, 0xaaaa, 0x5d, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_GLOBAL_ST_GRP_2D, volta_mio_l1tag_global_st_grp_2d_enc_str_1, 0x2d, 0xaaaa, 0x5e, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_GLOBAL_RED_GRP_2D, volta_mio_l1tag_global_red_grp_2d_enc_str_1, 0x2d, 0xaaaa, 0x5f, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_2E, volta_mio_l1tag_sector_tag_hit_data_hit_grp_2e_enc_str_1, 0x2e, 0xffff, 0x50, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_2E, volta_mio_l1tag_sector_miss_grp_2e_enc_str_1, 0x2e, 0xffff, 0x55, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_ATOM_GRP_2E, volta_mio_l1tag_atom_grp_2e_enc_str_1, 0x2e, 0xaaaa, 0x5a, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_LOCAL_LD_GRP_2E, volta_mio_l1tag_local_ld_grp_2e_enc_str_1, 0x2e, 0xaaaa, 0x5b, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_LOCAL_ST_GRP_2E, volta_mio_l1tag_local_st_grp_2e_enc_str_1, 0x2e, 0xaaaa, 0x5c, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TEXTURE_LD_GRP_2E, volta_mio_l1tag_texture_ld_grp_2e_enc_str_1, 0x2e, 0xaaaa, 0x5d, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TEXTURE_TEX_GRP_2E, volta_mio_l1tag_texture_tex_grp_2e_enc_str_1, 0x2e, 0xaaaa, 0x5e, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_2F, volta_mio_l1tag_sector_tag_hit_data_hit_grp_2f_enc_str_1, 0x2f, 0xffff, 0x50, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_2F, volta_mio_l1tag_sector_miss_grp_2f_enc_str_1, 0x2f, 0xffff, 0x55, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_SURFACE_LD_GRP_2F, volta_mio_l1tag_surface_ld_grp_2f_enc_str_1, 0x2f, 0xaaaa, 0x5a, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_ST_GRP_2F, volta_mio_l1tag_surface_st_grp_2f_enc_str_1, 0x2f, 0xaaaa, 0x5b, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_ATOM_GRP_2F, volta_mio_l1tag_surface_atom_grp_2f_enc_str_1, 0x2f, 0xaaaa, 0x5c, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_RED_GRP_2F, volta_mio_l1tag_surface_red_grp_2f_enc_str_1, 0x2f, 0xaaaa, 0x5d, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_30, volta_mio_l1tag_sector_tag_hit_data_hit_grp_30_enc_str_1, 0x30, 0xffff, 0x50, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_30, volta_mio_l1tag_sector_miss_grp_30_enc_str_1, 0x30, 0xffff, 0x55, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_TYPE_1D_GRP_30, volta_mio_l1tag_type_1d_grp_30_enc_str_1, 0x30, 0xaaaa, 0x5a, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TYPE_1D_BUFFER_GRP_30, volta_mio_l1tag_type_1d_buffer_grp_30_enc_str_1, 0x30, 0xaaaa, 0x5b, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TYPE_2D_GRP_30, volta_mio_l1tag_type_2d_grp_30_enc_str_1, 0x30, 0xaaaa, 0x5c, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TYPE_3D_GRP_30, volta_mio_l1tag_type_3d_grp_30_enc_str_1, 0x30, 0xaaaa, 0x5d, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TYPE_CUBEMAP_GRP_30, volta_mio_l1tag_type_cubemap_grp_30_enc_str_1, 0x30, 0xaaaa, 0x5e, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TYPE_NO_MIPMAP_GRP_30, volta_mio_l1tag_type_no_mipmap_grp_30_enc_str_1, 0x30, 0xaaaa, 0x5f, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_MISS, volta_mio_l1tag_sector_tag_hit_data_miss_enc_str_1, 0x1f, 0xffff, 0x50, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_REQUESTS_GRP_1F, volta_mio_l1tag_requests_grp_1f_enc_str_1, 0x1f, 0xaaaa, 0x55, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_GLOBAL_LD, volta_mio_l1tag_global_ld_enc_str_1, 0x1f, 0xaaaa, 0x56, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_ATOM, volta_mio_l1tag_atom_enc_str_1, 0x1f, 0xaaaa, 0x57, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_GLOBAL_RED, volta_mio_l1tag_global_red_enc_str_1, 0x1f, 0xaaaa, 0x58, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_LOCAL_LD, volta_mio_l1tag_local_ld_enc_str_1, 0x1f, 0xaaaa, 0x59, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_LD, volta_mio_l1tag_surface_ld_enc_str_1, 0x1f, 0xaaaa, 0x5a, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_ATOM, volta_mio_l1tag_surface_atom_enc_str_1, 0x1f, 0xaaaa, 0x5b, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_RED, volta_mio_l1tag_surface_red_enc_str_1, 0x1f, 0xaaaa, 0x5c, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TEXTURE_LD, volta_mio_l1tag_texture_ld_enc_str_1, 0x1f, 0xaaaa, 0x5d, PM_UNIT_MIO, 1 },

    { VOLTA_TEX_F_TEX2SM_TEX_PVLD, volta_tex_f_tex2sm_tex_pvld_enc_str_1, 0x6, 0xaaaa, 0x63, PM_UNIT_TEX, 1 },
    { VOLTA_TEX_F_TEX2SM_TEX_PRDY, volta_tex_f_tex2sm_tex_prdy_enc_str_1, 0x6, 0xaaaa, 0x64, PM_UNIT_TEX, 1 },
    { VOLTA_TEX_F_TEX2SM_COMP_LAST, volta_tex_f_tex2sm_comp_last_enc_str_1, 0x6, 0xaaaa, 0x65, PM_UNIT_TEX, 1 },

    { VOLTA_TEX_F_SKIPPED_RETURN_BEATS, volta_tex_f_skipped_return_beats_enc_str_1, 0x7, 0xaaaa, 0x69, PM_UNIT_TEX, 1 },
    { VOLTA_TEX_F_DATA_RETURN_BEATS, volta_tex_f_data_return_beats_enc_str_1, 0x7, 0xaaaa, 0x6a, PM_UNIT_TEX, 1 },

    { VOLTA_TEX_SMV2TEX_DATA_PVLD, volta_tex_smv2tex_data_pvld_enc_str_1, 0x0, 0xaaaa, 0x66, PM_UNIT_TEX, 1 },
    { VOLTA_TEX_SMV2TEX_DATA_PRDY, volta_tex_smv2tex_data_prdy_enc_str_1, 0x0, 0xaaaa, 0x67, PM_UNIT_TEX, 1 },
    { VOLTA_TEX_SMV2TEX_REQ_PVLD, volta_tex_smv2tex_req_pvld_enc_str_1, 0x0, 0xaaaa, 0x68, PM_UNIT_TEX, 1 },
    { VOLTA_TEX_SMV2TEX_REQ_PRDY, volta_tex_smv2tex_req_prdy_enc_str_1, 0x0, 0xaaaa, 0x69, PM_UNIT_TEX, 1 },

    { VOLTA_TEX_F_ACCUM_STALL, volta_tex_f_accum_stall_enc_str_1, 0x6, 0xaaaa, 0x6d, PM_UNIT_TEX, 1 },
    { VOLTA_TEX_F_ANY_PVLD, volta_tex_f_any_pvld_enc_str_1, 0x6, 0xaaaa, 0x6e, PM_UNIT_TEX, 1 },

    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_2SECTORS_SUM, volta_mio_l1miss_tex2gnic_fold_2sectors_sum_enc_str_1, 0xb, 0xffff, 0x52, PM_UNIT_MIO, 4 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_RD, volta_mio_l1miss_tex2gnic_fold_rd_enc_str_1, 0xb, 0xaaaa, 0x56, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_PACK_RD, volta_mio_l1miss_tex2gnic_fold_pack_rd_enc_str_1, 0xb, 0xaaaa, 0x57, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_GATOM, volta_mio_l1miss_tex2gnic_fold_gatom_enc_str_1, 0xb, 0xaaaa, 0x58, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_CONCAT_GATOM, volta_mio_l1miss_tex2gnic_fold_concat_gatom_enc_str_1, 0xb, 0xaaaa, 0x59, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_WR_BYTES_SUM, volta_mio_l1miss_tex2gnic_fold_wr_bytes_sum_enc_str_1, 0xd, 0xffff, 0x50, PM_UNIT_MIO, 6 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_WR, volta_mio_l1miss_tex2gnic_fold_wr_enc_str_1, 0xd, 0xaaaa, 0x5f, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_SECTOR_READ_REQUESTS, volta_mio_l1tag_sector_read_requests_enc_str_1, 0x19, 0xffff, 0x53, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_SECTOR_WRITE_REQUESTS, volta_mio_l1tag_sector_write_requests_enc_str_1, 0x19, 0xffff, 0x58, PM_UNIT_MIO, 5 },

    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_CONCAT_GRED, volta_mio_l1miss_tex2gnic_fold_concat_gred_enc_str_1, 0xe, 0xaaaa, 0x51, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_CONCAT_WR, volta_mio_l1miss_tex2gnic_fold_concat_wr_enc_str_1, 0xe, 0xaaaa, 0x52, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_GRED, volta_mio_l1miss_tex2gnic_fold_gred_enc_str_1, 0xe, 0xaaaa, 0x54, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_SECTORS_PROMOTED, volta_mio_l1tag_sectors_promoted_enc_str_1, 0x12, 0xffff, 0x50, PM_UNIT_MIO, 5 },

    {VOLTA_ELAPSED_CYCLES_SM, volta_elapsed_cycles_sm_enc_str_1,          0x00000000, 0x00000000, 0x00000000,    PM_UNIT_SMCORE,0 },
    {VOLTA_ELAPSED_CYCLES_SM_PM, volta_elapsed_cycles_sm_pm_enc_str_1,          0x00000000, 0x00000000, 0x00000000,    PM_UNIT_SMCORE,0 },

    {VOLTA_HWPM_INST_EXECUTED_FFMA_OPS_S0, volta_hwpm_inst_executed_ffma_ops_s0_enc_str_1,        0x11, 0xaaaa, 0x14, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_FFMA_OPS_S1, volta_hwpm_inst_executed_ffma_ops_s1_enc_str_1,        0x11, 0xaaaa, 0x24, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_FFMA_OPS_S2, volta_hwpm_inst_executed_ffma_ops_s2_enc_str_1,        0x11, 0xaaaa, 0x34, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_FFMA_OPS_S3, volta_hwpm_inst_executed_ffma_ops_s3_enc_str_1,        0x11, 0xaaaa, 0x44, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_OTHERFP_OPS_S0, volta_hwpm_inst_executed_otherfp_ops_s0_enc_str_1,  0x11, 0xaaaa, 0x13, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_OTHERFP_OPS_S1, volta_hwpm_inst_executed_otherfp_ops_s1_enc_str_1,  0x11, 0xaaaa, 0x23, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_OTHERFP_OPS_S2, volta_hwpm_inst_executed_otherfp_ops_s2_enc_str_1,  0x11, 0xaaaa, 0x33, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_OTHERFP_OPS_S3, volta_hwpm_inst_executed_otherfp_ops_s3_enc_str_1,  0x11, 0xaaaa, 0x43, PM_UNIT_SMQCTL, 1},

    {VOLTA_HWPM_INST_EXECUTED_HFMA_OPS_S0, volta_hwpm_inst_executed_hfma_ops_s0_enc_str_1, 0x11, 0xaaaa, 0x11, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_HFMA_OPS_S1, volta_hwpm_inst_executed_hfma_ops_s1_enc_str_1, 0x11, 0xaaaa, 0x21, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_HFMA_OPS_S2, volta_hwpm_inst_executed_hfma_ops_s2_enc_str_1, 0x11, 0xaaaa, 0x31, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_HFMA_OPS_S3, volta_hwpm_inst_executed_hfma_ops_s3_enc_str_1, 0x11, 0xaaaa, 0x41, PM_UNIT_SMQCTL, 1},

    {VOLTA_HWPM_INST_EXECUTED_FMA64LITE_PIPE_S0, volta_hwpm_inst_executed_fma64lite_pipe_s0_enc_str_1, 0xd, 0xaaaa, 0x12, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_FMA64LITE_PIPE_S1, volta_hwpm_inst_executed_fma64lite_pipe_s1_enc_str_1, 0xd, 0xaaaa, 0x22, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_FMA64LITE_PIPE_S2, volta_hwpm_inst_executed_fma64lite_pipe_s2_enc_str_1, 0xd, 0xaaaa, 0x32, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_FMA64LITE_PIPE_S3, volta_hwpm_inst_executed_fma64lite_pipe_s3_enc_str_1, 0xd, 0xaaaa, 0x42, PM_UNIT_SMQCTL, 1},

    {VOLTA_HWPM_INST_EXECUTED_FMA_PIPE_S0, volta_hwpm_inst_executed_fma_pipe_s0_enc_str_1, 0xd, 0xaaaa, 0x11, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_FMA_PIPE_S1, volta_hwpm_inst_executed_fma_pipe_s1_enc_str_1, 0xd, 0xaaaa, 0x21, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_FMA_PIPE_S2, volta_hwpm_inst_executed_fma_pipe_s2_enc_str_1, 0xd, 0xaaaa, 0x31, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_FMA_PIPE_S3, volta_hwpm_inst_executed_fma_pipe_s3_enc_str_1, 0xd, 0xaaaa, 0x41, PM_UNIT_SMQCTL, 1},

    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

#if NVCFG(GLOBAL_CHIP_T194) || NVCFG(GLOBAL_GPU_IMPL_GV11B)
PerfSignalHwpm PerfSignalTableGV11B_gpctpc[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type

#if CU_VOLTA_PROFILE_SM_SIGNALS_VIA_HWPM
    // ########### SM Unit ###########
    // ***LAUNCHED***
    // sch_warps_launched               SM has launched 1 warp
    // sch_threads_launched             number of threads SM launched this cycle
    //TBD check with latest files, threads_launched watchbus looks incorrect
    {VOLTA_HWPM_THREAD_INST_EXECUTED_0, volta_hwpm_thread_inst_executed_s0_enc_str_1, 0x15, 0xffff, 0x26, PM_UNIT_SMQCTL, 6, 0},
    {VOLTA_HWPM_NPO_THREAD_INST_EXECUTED_0, volta_hwpm_npo_thread_inst_executed_s0_enc_str_1, 0x15, 0xffff, 0x2e, PM_UNIT_SMQCTL, 6, 0},
    {VOLTA_HWPM_INST_EXECUTED_S0, volta_hwpm_inst_executed_s0_enc_str_1, 0x15, 0xaaaa, 0x2c, PM_UNIT_SMQCTL, 1},

    {VOLTA_SMQCTL_SHARED_LD_128B_ADDRESS_UNIFORM_S0, volta_smqctl_shared_ld_128b_address_uniform_s0_enc_str_1, 0x1d, 0xaaaa, 0x34, PM_UNIT_SMQCTL, 1},
    {VOLTA_SMQCTL_SHARED_LD_128B_ADDRESS_UNIFORM_S1, volta_smqctl_shared_ld_128b_address_uniform_s1_enc_str_1, 0x1d, 0xaaaa, 0x44, PM_UNIT_SMQCTL, 1},
    {VOLTA_SMQCTL_SHARED_LD_128B_ADDRESS_UNIFORM_S2, volta_smqctl_shared_ld_128b_address_uniform_s2_enc_str_1, 0x1d, 0xaaaa, 0x54, PM_UNIT_SMQCTL, 1},
    {VOLTA_SMQCTL_SHARED_LD_128B_ADDRESS_UNIFORM_S3, volta_smqctl_shared_ld_128b_address_uniform_s3_enc_str_1, 0x1d, 0xaaaa, 0x64, PM_UNIT_SMQCTL, 1},

    { VOLTA_HWPM_TOTAL_WARPS_LAUNCHED_0, volta_hwpm_total_warps_launched_0_enc_str_1, 0x19, 0xaaaa, 0x2d, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_TOTAL_WARPS_LAUNCHED_1, volta_hwpm_total_warps_launched_1_enc_str_1, 0x19, 0xaaaa, 0x3d, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_TOTAL_WARPS_LAUNCHED_2, volta_hwpm_total_warps_launched_2_enc_str_1, 0x19, 0xaaaa, 0x4d, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_TOTAL_WARPS_LAUNCHED_3, volta_hwpm_total_warps_launched_3_enc_str_1, 0x19, 0xaaaa, 0x5d, PM_UNIT_SMQCTL, 1 },

    {VOLTA_HWPM_RESTORE_WARPS_LAUNCHED_0, volta_hwpm_restore_warps_launched_0_enc_str_1, 0x19, 0xaaaa, 0x2c, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_RESTORE_WARPS_LAUNCHED_1, volta_hwpm_restore_warps_launched_1_enc_str_1, 0x19, 0xaaaa, 0x3c, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_RESTORE_WARPS_LAUNCHED_2, volta_hwpm_restore_warps_launched_2_enc_str_1, 0x19, 0xaaaa, 0x4c, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_RESTORE_WARPS_LAUNCHED_3, volta_hwpm_restore_warps_launched_3_enc_str_1, 0x19, 0xaaaa, 0x5c, PM_UNIT_SMQCTL, 1},

    {VOLTA_HWPM_THREADS_LAUNCHED_0, volta_hwpm_threads_launched_0_enc_str_1, 0x19, 0xffff, 0x26, PM_UNIT_SMQCTL, 6},
    {VOLTA_HWPM_THREADS_LAUNCHED_1, volta_hwpm_threads_launched_1_enc_str_1, 0x19, 0xffff, 0x36, PM_UNIT_SMQCTL, 6},
    {VOLTA_HWPM_THREADS_LAUNCHED_2, volta_hwpm_threads_launched_2_enc_str_1, 0x19, 0xffff, 0x46, PM_UNIT_SMQCTL, 6},
    {VOLTA_HWPM_THREADS_LAUNCHED_3, volta_hwpm_threads_launched_3_enc_str_1, 0x19, 0xffff, 0x56, PM_UNIT_SMQCTL, 6},

    { VOLTA_HWPM_NOP_TRIG_BIT0_5_S0, volta_hwpm_nop_trig_bit0_5_s0_enc_str_1, 0x18, 0xffff, 0x26, PM_UNIT_SMQCTL, 6 },
    { VOLTA_HWPM_NOP_TRIG_BIT0_5_S1, volta_hwpm_nop_trig_bit0_5_s1_enc_str_1, 0x18, 0xffff, 0x36, PM_UNIT_SMQCTL, 6 },
    { VOLTA_HWPM_NOP_TRIG_BIT0_5_S2, volta_hwpm_nop_trig_bit0_5_s2_enc_str_1, 0x18, 0xffff, 0x46, PM_UNIT_SMQCTL, 6 },
    { VOLTA_HWPM_NOP_TRIG_BIT0_5_S3, volta_hwpm_nop_trig_bit0_5_s3_enc_str_1, 0x18, 0xffff, 0x56, PM_UNIT_SMQCTL, 6 },

    { VOLTA_HWPM_NOP_TRIG_BIT6_S0, volta_hwpm_nop_trig_bit6_s0_enc_str_1, 0x18, 0xaaaa, 0x2c, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_NOP_TRIG_BIT6_S1, volta_hwpm_nop_trig_bit6_s1_enc_str_1, 0x18, 0xaaaa, 0x3c, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_NOP_TRIG_BIT6_S2, volta_hwpm_nop_trig_bit6_s2_enc_str_1, 0x18, 0xaaaa, 0x4c, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_NOP_TRIG_BIT6_S3, volta_hwpm_nop_trig_bit6_s3_enc_str_1, 0x18, 0xaaaa, 0x5c, PM_UNIT_SMQCTL, 1 },

    { VOLTA_HWPM_NOP_TRIG_BIT7_S0, volta_hwpm_nop_trig_bit7_s0_enc_str_1, 0x18, 0xaaaa, 0x2d, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_NOP_TRIG_BIT7_S1, volta_hwpm_nop_trig_bit7_s1_enc_str_1, 0x18, 0xaaaa, 0x3d, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_NOP_TRIG_BIT7_S2, volta_hwpm_nop_trig_bit7_s2_enc_str_1, 0x18, 0xaaaa, 0x4d, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_NOP_TRIG_BIT7_S3, volta_hwpm_nop_trig_bit7_s3_enc_str_1, 0x18, 0xaaaa, 0x5d, PM_UNIT_SMQCTL, 1 },

    { VOLTA_HWPM_ACTIVE_CYCLES_Q0, volta_hwpm_active_cycles_q0_enc_str_1, 0x1, 0xffff, 0x26, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_ACTIVE_CYCLES_Q1, volta_hwpm_active_cycles_q1_enc_str_1, 0x1, 0xffff, 0x36, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_ACTIVE_CYCLES_Q2, volta_hwpm_active_cycles_q2_enc_str_1, 0x1, 0xffff, 0x46, PM_UNIT_SMQCTL, 1 },
    { VOLTA_HWPM_ACTIVE_CYCLES_Q3, volta_hwpm_active_cycles_q3_enc_str_1, 0x1, 0xffff, 0x56, PM_UNIT_SMQCTL, 1 },

    {VOLTA_HWPM_ACTIVE_CYCLES, volta_hwpm_active_cycles_enc_str_1, 0x1, 0xaaaa, 0x17, PM_UNIT_SMCORE, 1},
    {VOLTA_HWPM_ACTIVE_WARPS, volta_hwpm_active_warps_enc_str_1, 0x1, 0xffff, 0x18, PM_UNIT_SMCORE, 6},

    {VOLTA_HWPM_TOTAL_CTA_LAUNCHED, volta_hwpm_total_cta_launched_enc_str_1, 0x6, 0xaaaa, 0x1d, PM_UNIT_SMCORE, 1},
    {VOLTA_HWPM_CTA_RESTORED, volta_hwpm_cta_restored_enc_str_1, 0x6, 0xaaaa, 0x1e, PM_UNIT_SMCORE, 1 },

    {VOLTA_HWPM_TRAP_IN_TRAP, volta_hwpm_trap_in_trap_enc_str_1, 0x7, 0xaaaa, 0x16, PM_UNIT_SMCORE, 1 },
    {VOLTA_HWPM_TRAP_COUNT, volta_hwpm_trap_count_enc_str_1, 0x7, 0xaaaa, 0x17, PM_UNIT_SMCORE, 1 },

    {VOLTA_HWPM_INST_EXECUTED_HMMA_OPS_S0, volta_hwpm_inst_executed_hmma_ops_s0_enc_str_1, 0x11, 0xaaaa, 0x28, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_OPS_S1, volta_hwpm_inst_executed_hmma_ops_s1_enc_str_1, 0x11, 0xaaaa, 0x38, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_OPS_S2, volta_hwpm_inst_executed_hmma_ops_s2_enc_str_1, 0x11, 0xaaaa, 0x48, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_OPS_S3, volta_hwpm_inst_executed_hmma_ops_s3_enc_str_1, 0x11, 0xaaaa, 0x58, PM_UNIT_SMQCTL, 1},

    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP16_OPS_S0, volta_hwpm_inst_executed_hmma_fp16_ops_s0_enc_str_1, 0xe, 0xaaaa, 0x32, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP16_OPS_S1, volta_hwpm_inst_executed_hmma_fp16_ops_s1_enc_str_1, 0xe, 0xaaaa, 0x42, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP16_OPS_S2, volta_hwpm_inst_executed_hmma_fp16_ops_s2_enc_str_1, 0xe, 0xaaaa, 0x52, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP16_OPS_S3, volta_hwpm_inst_executed_hmma_fp16_ops_s3_enc_str_1, 0xe, 0xaaaa, 0x62, PM_UNIT_SMQCTL, 1},

    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP32_OPS_S0, volta_hwpm_inst_executed_hmma_fp32_ops_s0_enc_str_1, 0xe, 0xaaaa, 0x33, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP32_OPS_S1, volta_hwpm_inst_executed_hmma_fp32_ops_s1_enc_str_1, 0xe, 0xaaaa, 0x43, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP32_OPS_S2, volta_hwpm_inst_executed_hmma_fp32_ops_s2_enc_str_1, 0xe, 0xaaaa, 0x53, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP32_OPS_S3, volta_hwpm_inst_executed_hmma_fp32_ops_s3_enc_str_1, 0xe, 0xaaaa, 0x63, PM_UNIT_SMQCTL, 1},
#endif
    {VOLTA_PROFILER_FIRST,           volta_profiler_first_enc_str_1,           0x0000000a, 0xaaaa, 0x1e, PM_UNIT_SMCORE, 1},
    {VOLTA_PROFILER_VALID,           volta_profiler_valid_enc_str_1,           0x0000000a, 0xaaaa, 0x1f, PM_UNIT_SMCORE, 1},

    //mpc signals
    {VOLTA_MPC_CTAS_LAUNCHED, volta_mpc_ctas_launched_enc_str_1, 0x1e, 0xaaaa, 0x88, PM_UNIT_MPC, 1},
    {VOLTA_MPC_THREADS_LAUNCHED, volta_mpc_threads_launched_enc_str_1, 0x5a, 0xffff, 0x88, PM_UNIT_MPC, 6},
    {VOLTA_MPC_WARP_LAUNCH, volta_mpc_warp_launch_enc_str_1, 0x5a, 0xaaaa, 0x8e, PM_UNIT_MPC, 1 },
    {VOLTA_MPC_WARPS_IN_FLIGHT, volta_mpc_warps_in_flight_enc_str_1, 0x42, 0xffff, 0x86, PM_UNIT_MPC, 6},
    {VOLTA_MPC_COMPUTE_CTAS_IN_FLIGHT, volta_mpc_compute_ctas_in_flight_enc_str_1, 0x3c, 0xffff, 0x86, PM_UNIT_MPC, 6},

    //Tex/eL1 signals
    // based on experiments defined in //hw/tools/perfalyze/chips/gv100/pml_files/smv.pml

    { VOLTA_MIO_L1DATA_DATA_CONFLICTS_GRP_2C, volta_mio_l1data_data_conflicts_grp_2c_enc_str_1, 0x2c, 0xffff, 0x6c, PM_UNIT_MIO, 2 },
    { VOLTA_MIO_L1DATA_DATA_CONFLICTS_SM_XBAR_GRP_2C, volta_mio_l1data_data_conflicts_grp_2c_sm_xbar_enc_str_1, 0x2c, 0xaaaa, 0x6e, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_SHARED_LD, volta_mio_l1data_shared_ld_enc_str_1, 0x2c, 0xaaaa, 0x6f, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_SHARED_ST, volta_mio_l1data_shared_st_enc_str_1, 0x2c, 0xaaaa, 0x70, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_SHARED_LD_REQUESTS, volta_mio_l1data_shared_ld_requests_enc_str_1, 0x2c, 0xaaaa, 0x71, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_SHARED_ST_REQUESTS, volta_mio_l1data_shared_st_requests_enc_str_1, 0x2c, 0xaaaa, 0x72, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_SHMEM, volta_mio_wavefront_count_l1data_shmem_enc_str_1, 0x2c, 0xaaaa, 0x73, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1DATA_DATA_CONFLICTS, volta_mio_l1data_data_conflicts_enc_str_1, 0x6, 0xffff, 0x66, PM_UNIT_MIO, 2 },
    { VOLTA_MIO_L1DATA_DATA_CONFLICTS_SM_XBAR, volta_mio_l1data_data_conflicts_sm_xbar_enc_str_1, 0x6, 0xaaaa, 0x68, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1DATA_GLOBAL_LD, volta_mio_l1data_global_ld_enc_str_1, 0x6, 0xaaaa, 0x69, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_GLOBAL_ST, volta_mio_l1data_global_st_enc_str_1, 0x6, 0xaaaa, 0x6a, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_ATOM, volta_mio_l1data_atom_enc_str_1, 0x6, 0xaaaa, 0x6b, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_GLOBAL_RED, volta_mio_l1data_global_red_enc_str_1, 0x6, 0xaaaa, 0x6c, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1DATA_IPA_LD, volta_mio_l1data_ipa_ld_enc_str_1, 0x6, 0xaaaa, 0x6f, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_SURFACE_LD, volta_mio_l1data_surface_ld_enc_str_1, 0x6, 0xaaaa, 0x70, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_SURFACE_ST, volta_mio_l1data_surface_st_enc_str_1, 0x6, 0xaaaa, 0x71, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_SURFACE_ATOM, volta_mio_l1data_surface_atom_enc_str_1, 0x6, 0xaaaa, 0x72, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_SURFACE_RED, volta_mio_l1data_surface_red_enc_str_1, 0x6, 0xaaaa, 0x73, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA, volta_mio_wavefront_count_l1data_enc_str_1, 0x7, 0xaaaa, 0x66, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_LG, volta_mio_wavefront_count_l1data_lg_enc_str_1, 0x7, 0xaaaa, 0x67, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_BANK_READS, volta_mio_wavefront_count_l1data_bank_reads_enc_str_1, 0x7, 0xffff, 0x68, PM_UNIT_MIO, 6 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_BANK_WRITES, volta_mio_wavefront_count_l1data_bank_writes_enc_str_1, 0x7, 0xffff, 0x6e, PM_UNIT_MIO, 6 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_READ, volta_mio_wavefront_count_l1data_read_enc_str_1, 0x7, 0xaaaa, 0x74, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_WRITE, volta_mio_wavefront_count_l1data_write_enc_str_1, 0x7, 0xaaaa, 0x75, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_SURF, volta_mio_wavefront_count_l1data_surf_enc_str_1, 0x8, 0xaaaa, 0x67, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_TEX, volta_mio_wavefront_count_l1data_tex_enc_str_1, 0x8, 0xaaaa, 0x68, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_TO_DSTAGE, volta_mio_wavefront_count_l1data_to_dstage_enc_str_1, 0x8, 0xaaaa, 0x69, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_TO_MIOP_WBB_DATA, volta_mio_wavefront_count_l1data_to_miop_wbb_data_enc_str_1, 0x8, 0xaaaa, 0x6a, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1DATA_IPA_LD_REQUESTS, volta_mio_l1data_ipa_ld_requests_enc_str_1, 0x8, 0xaaaa, 0x6d, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1DATA_SURFACE_ATOM_DATA_CONFLICTS, volta_mio_l1data_surface_atom_data_conflicts_enc_str_1, 0x8, 0xffff, 0x6e, PM_UNIT_MIO, 2 },

    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_1, volta_mio_l1miss_l2_requests_missed_sectors_1_enc_str_1, 0xc, 0xaaaa, 0x66, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_2, volta_mio_l1miss_l2_requests_missed_sectors_2_enc_str_1, 0xc, 0xaaaa, 0x67, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_3, volta_mio_l1miss_l2_requests_missed_sectors_3_enc_str_1, 0xc, 0xaaaa, 0x68, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_4, volta_mio_l1miss_l2_requests_missed_sectors_4_enc_str_1, 0xc, 0xaaaa, 0x69, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_5, volta_mio_l1miss_l2_requests_missed_sectors_5_enc_str_1, 0xc, 0xaaaa, 0x6a, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_6, volta_mio_l1miss_l2_requests_missed_sectors_6_enc_str_1, 0xc, 0xaaaa, 0x6b, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_7, volta_mio_l1miss_l2_requests_missed_sectors_7_enc_str_1, 0xc, 0xaaaa, 0x6c, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_8, volta_mio_l1miss_l2_requests_missed_sectors_8_enc_str_1, 0xc, 0xaaaa, 0x6d, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_REQUESTS_PRECOALESCING, volta_mio_l1tag_requests_precoalescing_enc_str_1, 0x22, 0xffff, 0x66, PM_UNIT_MIO, 3 },
    { VOLTA_MIO_L1TAG_SECTORS_PRECOALESCING, volta_mio_l1tag_sectors_precoalescing_enc_str_1, 0x22, 0xffff, 0x69, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_READ_PRECOALESCING, volta_mio_l1tag_read_precoalescing_enc_str_1, 0x22, 0xaaaa, 0x6e, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_WRITE_PRECOALESCING, volta_mio_l1tag_write_precoalescing_enc_str_1, 0x22, 0xaaaa, 0x6f, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_LG, volta_mio_l1tag_lg_enc_str_1, 0x22, 0xaaaa, 0x70, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE, volta_mio_l1tag_surface_enc_str_1, 0x22, 0xaaaa, 0x71, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TEXTURE, volta_mio_l1tag_texture_enc_str_1, 0x22, 0xaaaa, 0x72, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TEXTURE_TEX_REQUESTS, volta_mio_l1tag_texture_tex_requests_enc_str_1, 0x22, 0xaaaa, 0x73, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TEXTURE_LD_REQUESTS, volta_mio_l1tag_texture_ld_requests_enc_str_1, 0x22, 0xaaaa, 0x74, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1MISS_TEX2GNIC_REQUESTS_POSTCOALESCING, volta_mio_l1miss_tex2gnic_requests_postcoalescing_enc_str_1, 0xe, 0xaaaa, 0x6c, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_SECTORS_SUM_POSTCOALESCING, volta_mio_l1miss_tex2gnic_sectors_sum_postcoalescing_enc_str_1, 0xe, 0xffff, 0x6d, PM_UNIT_MIO, 3 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_IS_WRITE_POSTCOALESCING, volta_mio_l1miss_tex2gnic_is_write_postcoalescing_enc_str_1, 0xe, 0xaaaa, 0x70, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_IS_READ_POSTCOALESCING, volta_mio_l1miss_tex2gnic_is_read_postcoalescing_enc_str_1, 0xe, 0xaaaa, 0x71, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_IS_PREFETCH_POSTCOALESCING, volta_mio_l1miss_tex2gnic_is_prefetch_postcoalescing_enc_str_1, 0xe, 0xaaaa, 0x72, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_IS_LG_POSTCOALESCING, volta_mio_l1miss_tex2gnic_is_lg_postcoalescing_enc_str_1, 0xe, 0xaaaa, 0x73, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_IS_SURFACE_POSTCOALESCING, volta_mio_l1miss_tex2gnic_is_surface_postcoalescing_enc_str_1, 0xe, 0xaaaa, 0x74, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_IS_TEXTURE_POSTCOALESCING, volta_mio_l1miss_tex2gnic_is_texture_postcoalescing_enc_str_1, 0xe, 0xaaaa, 0x75, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_CACHE_SECTOR_QUERIES, volta_mio_l1tag_cache_sector_queries_enc_str_1, 0x10, 0xffff, 0x6e, PM_UNIT_MIO, 5 },

    { VOLTA_MIO_IDC_DIVERGENCE_REPLAY, volta_mio_idc_divergence_replay_enc_str_1, 0x3, 0xaaaa, 0x66, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_IDC_DIVERGENT_INSTRUCTION, volta_mio_idc_divergent_instruction_enc_str_1, 0x3, 0xaaaa, 0x67, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_TEXTURE_TEX, volta_mio_l1tag_texture_tex_enc_str_1, 0x21, 0xaaaa, 0x6f, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_SET_ACCESSES, volta_mio_l1tag_set_accesses_enc_str_1, 0x14, 0xffff, 0x66, PM_UNIT_MIO, 3 },
    { VOLTA_MIO_L1TAG_SET_CONFLICTS, volta_mio_l1tag_set_conflicts_enc_str_1, 0x14, 0xaaaa, 0x69, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_ATOM_GRP_14, volta_mio_l1tag_atom_grp_14_enc_str_1, 0x14, 0xaaaa, 0x6a, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_GLOBAL_RED_GRP_14, volta_mio_l1tag_global_red_grp_14_enc_str_1, 0x14, 0xaaaa, 0x6b, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_LD_GRP_14, volta_mio_l1tag_surface_ld_grp_14_enc_str_1, 0x14, 0xaaaa, 0x6c, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_ST_GRP_14, volta_mio_l1tag_surface_st_grp_14_enc_str_1, 0x14, 0xaaaa, 0x6d, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_ATOM_GRP_14, volta_mio_l1tag_surface_atom_grp_14_enc_str_1, 0x14, 0xaaaa, 0x6e, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_RED_GRP_14, volta_mio_l1tag_surface_red_grp_14_enc_str_1, 0x14, 0xaaaa, 0x6f, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_LG_GRP_14, volta_mio_l1tag_lg_grp_14_enc_str_1, 0x14, 0xaaaa, 0x70, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_GRP_14, volta_mio_l1tag_surface_grp_14_enc_str_1, 0x14, 0xaaaa, 0x71, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TEXTURE_GRP_14, volta_mio_l1tag_texture_grp_14_enc_str_1, 0x14, 0xaaaa, 0x72, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_SET_CONFLICTS_GRP_1A, volta_mio_l1tag_set_conflicts_grp_1a_enc_str_1, 0x1a, 0xaaaa, 0x66, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_GLOBAL_LD_GRP_1A, volta_mio_l1tag_global_ld_grp_1a_enc_str_1, 0x1a, 0xaaaa, 0x67, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_GLOBAL_ST_GRP_1A, volta_mio_l1tag_global_st_grp_1a_enc_str_1, 0x1a, 0xaaaa, 0x68, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SET_ACCESSES_GRP_1A, volta_mio_l1tag_set_accesses_grp_1a_enc_str_1, 0x1a, 0xffff, 0x69, PM_UNIT_MIO, 3 },
    { VOLTA_MIO_L1TAG_LOCAL_LD_GRP_1A, volta_mio_l1tag_local_ld_grp_1a_enc_str_1, 0x1a, 0xaaaa, 0x6c, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_LOCAL_ST_GRP_1A, volta_mio_l1tag_local_st_grp_1a_enc_str_1, 0x1a, 0xaaaa, 0x6d, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TEXTURE_LD_GRP_1A, volta_mio_l1tag_texture_ld_grp_1a_enc_str_1, 0x1a, 0xaaaa, 0x6e, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TEXTURE_TEX_GRP_1A, volta_mio_l1tag_texture_tex_grp_1a_enc_str_1, 0x1a, 0xaaaa, 0x6f, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_REQUESTS, volta_mio_l1tag_requests_enc_str_1, 0x13, 0xaaaa, 0x66, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_CCTL, volta_mio_l1tag_cctl_enc_str_1, 0x13, 0xaaaa, 0x67, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_LOCAL_CCTL, volta_mio_l1tag_local_cctl_enc_str_1, 0x13, 0xaaaa, 0x68, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_GLOBAL_CCTL, volta_mio_l1tag_global_cctl_enc_str_1, 0x13, 0xaaaa, 0x69, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_GLOBAL_ST, volta_mio_l1tag_global_st_enc_str_1, 0x13, 0xaaaa, 0x6a, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_LOCAL_ST, volta_mio_l1tag_local_st_enc_str_1, 0x13, 0xaaaa, 0x6b, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_MIXED_GENERIC_LD, volta_mio_l1tag_mixed_generic_ld_enc_str_1, 0x13, 0xaaaa, 0x6c, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_MIXED_GENERIC_ST, volta_mio_l1tag_mixed_generic_st_enc_str_1, 0x13, 0xaaaa, 0x6d, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_ST, volta_mio_l1tag_surface_st_enc_str_1, 0x13, 0xaaaa, 0x6e, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TAG_TYPE_1D, volta_mio_l1tag_tag_type_1d_enc_str_1, 0x13, 0xaaaa, 0x6f, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TAG_TYPE_1D_BUFFER, volta_mio_l1tag_tag_type_1d_buffer_enc_str_1, 0x13, 0xaaaa, 0x70, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TAG_TYPE_2D, volta_mio_l1tag_tag_type_2d_enc_str_1, 0x13, 0xaaaa, 0x71, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TAG_TYPE_3D, volta_mio_l1tag_tag_type_3d_enc_str_1, 0x13, 0xaaaa, 0x72, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TAG_TYPE_CUBEMAP, volta_mio_l1tag_tag_type_cubemap_enc_str_1, 0x13, 0xaaaa, 0x73, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TAG_TYPE_NO_MIPMAP, volta_mio_l1tag_tag_type_no_mipmap_enc_str_1, 0x13, 0xaaaa, 0x74, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT, volta_mio_l1tag_sector_tag_hit_data_hit_enc_str_1, 0x1b, 0xffff, 0x67, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_BYPASS_T2D, volta_mio_l1tag_sector_tag_hit_data_hit_bypass_t2d_enc_str_1, 0x1b, 0xffff, 0x71, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_SECTOR_TAG_MISS, volta_mio_l1tag_sector_tag_miss_enc_str_1, 0x1e, 0xffff, 0x66, PM_UNIT_MIO, 5 },

    { VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_2D, volta_mio_l1tag_sector_tag_hit_data_hit_grp_2d_enc_str_1, 0x2d, 0xffff, 0x66, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_2D, volta_mio_l1tag_sector_miss_grp_2d_enc_str_1, 0x2d, 0xffff, 0x6b, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_LG_GRP_2D, volta_mio_l1tag_lg_grp_2d_enc_str_1, 0x2d, 0xaaaa, 0x70, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_GRP_2D, volta_mio_l1tag_surface_grp_2d_enc_str_1, 0x2d, 0xaaaa, 0x71, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TEXTURE_GRP_2D, volta_mio_l1tag_texture_grp_2d_enc_str_1, 0x2d, 0xaaaa, 0x72, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_GLOBAL_LD_GRP_2D, volta_mio_l1tag_global_ld_grp_2d_enc_str_1, 0x2d, 0xaaaa, 0x73, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_GLOBAL_ST_GRP_2D, volta_mio_l1tag_global_st_grp_2d_enc_str_1, 0x2d, 0xaaaa, 0x74, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_GLOBAL_RED_GRP_2D, volta_mio_l1tag_global_red_grp_2d_enc_str_1, 0x2d, 0xaaaa, 0x75, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_2E, volta_mio_l1tag_sector_tag_hit_data_hit_grp_2e_enc_str_1, 0x2e, 0xffff, 0x66, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_2E, volta_mio_l1tag_sector_miss_grp_2e_enc_str_1, 0x2e, 0xffff, 0x6b, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_ATOM_GRP_2E, volta_mio_l1tag_atom_grp_2e_enc_str_1, 0x2e, 0xaaaa, 0x70, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_LOCAL_LD_GRP_2E, volta_mio_l1tag_local_ld_grp_2e_enc_str_1, 0x2e, 0xaaaa, 0x71, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_LOCAL_ST_GRP_2E, volta_mio_l1tag_local_st_grp_2e_enc_str_1, 0x2e, 0xaaaa, 0x72, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TEXTURE_LD_GRP_2E, volta_mio_l1tag_texture_ld_grp_2e_enc_str_1, 0x2e, 0xaaaa, 0x73, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TEXTURE_TEX_GRP_2E, volta_mio_l1tag_texture_tex_grp_2e_enc_str_1, 0x2e, 0xaaaa, 0x74, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_2F, volta_mio_l1tag_sector_tag_hit_data_hit_grp_2f_enc_str_1, 0x2f, 0xffff, 0x66, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_2F, volta_mio_l1tag_sector_miss_grp_2f_enc_str_1, 0x2f, 0xffff, 0x6b, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_SURFACE_LD_GRP_2F, volta_mio_l1tag_surface_ld_grp_2f_enc_str_1, 0x2f, 0xaaaa, 0x70, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_ST_GRP_2F, volta_mio_l1tag_surface_st_grp_2f_enc_str_1, 0x2f, 0xaaaa, 0x71, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_ATOM_GRP_2F, volta_mio_l1tag_surface_atom_grp_2f_enc_str_1, 0x2f, 0xaaaa, 0x72, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_RED_GRP_2F, volta_mio_l1tag_surface_red_grp_2f_enc_str_1, 0x2f, 0xaaaa, 0x73, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_30, volta_mio_l1tag_sector_tag_hit_data_hit_grp_30_enc_str_1, 0x30, 0xffff, 0x66, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_30, volta_mio_l1tag_sector_miss_grp_30_enc_str_1, 0x30, 0xffff, 0x6b, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_TYPE_1D_GRP_30, volta_mio_l1tag_type_1d_grp_30_enc_str_1, 0x30, 0xaaaa, 0x70, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TYPE_1D_BUFFER_GRP_30, volta_mio_l1tag_type_1d_buffer_grp_30_enc_str_1, 0x30, 0xaaaa, 0x71, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TYPE_2D_GRP_30, volta_mio_l1tag_type_2d_grp_30_enc_str_1, 0x30, 0xaaaa, 0x72, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TYPE_3D_GRP_30, volta_mio_l1tag_type_3d_grp_30_enc_str_1, 0x30, 0xaaaa, 0x73, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TYPE_CUBEMAP_GRP_30, volta_mio_l1tag_type_cubemap_grp_30_enc_str_1, 0x30, 0xaaaa, 0x74, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TYPE_NO_MIPMAP_GRP_30, volta_mio_l1tag_type_no_mipmap_grp_30_enc_str_1, 0x30, 0xaaaa, 0x75, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_MISS, volta_mio_l1tag_sector_tag_hit_data_miss_enc_str_1, 0x1f, 0xffff, 0x66, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_REQUESTS_GRP_1F, volta_mio_l1tag_requests_grp_1f_enc_str_1, 0x1f, 0xaaaa, 0x6b, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_GLOBAL_LD, volta_mio_l1tag_global_ld_enc_str_1, 0x1f, 0xaaaa, 0x6c, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_ATOM, volta_mio_l1tag_atom_enc_str_1, 0x1f, 0xaaaa, 0x6d, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_GLOBAL_RED, volta_mio_l1tag_global_red_enc_str_1, 0x1f, 0xaaaa, 0x6e, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_LOCAL_LD, volta_mio_l1tag_local_ld_enc_str_1, 0x1f, 0xaaaa, 0x6f, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_LD, volta_mio_l1tag_surface_ld_enc_str_1, 0x1f, 0xaaaa, 0x70, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_ATOM, volta_mio_l1tag_surface_atom_enc_str_1, 0x1f, 0xaaaa, 0x71, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_SURFACE_RED, volta_mio_l1tag_surface_red_enc_str_1, 0x1f, 0xaaaa, 0x72, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1TAG_TEXTURE_LD, volta_mio_l1tag_texture_ld_enc_str_1, 0x1f, 0xaaaa, 0x73, PM_UNIT_MIO, 1 },

    { VOLTA_TEX_F_TEX2SM_TEX_PVLD, volta_tex_f_tex2sm_tex_pvld_enc_str_1, 0x6, 0xaaaa, 0x79, PM_UNIT_TEX, 1 },
    { VOLTA_TEX_F_TEX2SM_TEX_PRDY, volta_tex_f_tex2sm_tex_prdy_enc_str_1, 0x6, 0xaaaa, 0x7a, PM_UNIT_TEX, 1 },
    { VOLTA_TEX_F_TEX2SM_COMP_LAST, volta_tex_f_tex2sm_comp_last_enc_str_1, 0x6, 0xaaaa, 0x7b, PM_UNIT_TEX, 1 },

    { VOLTA_TEX_F_SKIPPED_RETURN_BEATS, volta_tex_f_skipped_return_beats_enc_str_1, 0x7, 0xaaaa, 0x7f, PM_UNIT_TEX, 1 },
    { VOLTA_TEX_F_DATA_RETURN_BEATS, volta_tex_f_data_return_beats_enc_str_1, 0x7, 0xaaaa, 0x80, PM_UNIT_TEX, 1 },

    { VOLTA_TEX_SMV2TEX_DATA_PVLD, volta_tex_smv2tex_data_pvld_enc_str_1, 0x0, 0xaaaa, 0x7c, PM_UNIT_TEX, 1 },
    { VOLTA_TEX_SMV2TEX_DATA_PRDY, volta_tex_smv2tex_data_prdy_enc_str_1, 0x0, 0xaaaa, 0x7d, PM_UNIT_TEX, 1 },
    { VOLTA_TEX_SMV2TEX_REQ_PVLD, volta_tex_smv2tex_req_pvld_enc_str_1, 0x0, 0xaaaa, 0x7e, PM_UNIT_TEX, 1 },
    { VOLTA_TEX_SMV2TEX_REQ_PRDY, volta_tex_smv2tex_req_prdy_enc_str_1, 0x0, 0xaaaa, 0x7f, PM_UNIT_TEX, 1 },

    { VOLTA_TEX_F_ACCUM_STALL, volta_tex_f_accum_stall_enc_str_1, 0x6, 0xaaaa, 0x83, PM_UNIT_TEX, 1 },
    { VOLTA_TEX_F_ANY_PVLD, volta_tex_f_any_pvld_enc_str_1, 0x6, 0xaaaa, 0x84, PM_UNIT_TEX, 1 },

    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_2SECTORS_SUM, volta_mio_l1miss_tex2gnic_fold_2sectors_sum_enc_str_1, 0xb, 0xffff, 0x68, PM_UNIT_MIO, 4 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_RD, volta_mio_l1miss_tex2gnic_fold_rd_enc_str_1, 0xb, 0xaaaa, 0x6c, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_PACK_RD, volta_mio_l1miss_tex2gnic_fold_pack_rd_enc_str_1, 0xb, 0xaaaa, 0x6d, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_GATOM, volta_mio_l1miss_tex2gnic_fold_gatom_enc_str_1, 0xb, 0xaaaa, 0x6e, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_CONCAT_GATOM, volta_mio_l1miss_tex2gnic_fold_concat_gatom_enc_str_1, 0xb, 0xaaaa, 0x6f, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_WR_BYTES_SUM, volta_mio_l1miss_tex2gnic_fold_wr_bytes_sum_enc_str_1, 0xd, 0xffff, 0x66, PM_UNIT_MIO, 6 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_WR, volta_mio_l1miss_tex2gnic_fold_wr_enc_str_1, 0xd, 0xaaaa, 0x75, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_SECTOR_READ_REQUESTS, volta_mio_l1tag_sector_read_requests_enc_str_1, 0x19, 0xffff, 0x69, PM_UNIT_MIO, 5 },
    { VOLTA_MIO_L1TAG_SECTOR_WRITE_REQUESTS, volta_mio_l1tag_sector_write_requests_enc_str_1, 0x19, 0xffff, 0x6e, PM_UNIT_MIO, 5 },

    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_CONCAT_GRED, volta_mio_l1miss_tex2gnic_fold_concat_gred_enc_str_1, 0xe, 0xaaaa, 0x67, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_CONCAT_WR, volta_mio_l1miss_tex2gnic_fold_concat_wr_enc_str_1, 0xe, 0xaaaa, 0x68, PM_UNIT_MIO, 1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_GRED, volta_mio_l1miss_tex2gnic_fold_gred_enc_str_1, 0xe, 0xaaaa, 0x6a, PM_UNIT_MIO, 1 },

    { VOLTA_MIO_L1TAG_SECTORS_PROMOTED, volta_mio_l1tag_sectors_promoted_enc_str_1, 0x12, 0xffff, 0x66, PM_UNIT_MIO, 5 },

    {VOLTA_ELAPSED_CYCLES_SM, volta_elapsed_cycles_sm_enc_str_1,          0x00000000, 0x00000000, 0x00,    PM_UNIT_SMCORE,0 },
    {VOLTA_HWPM_INST_EXECUTED_FFMA_OPS_S0, volta_hwpm_inst_executed_ffma_ops_s0_enc_str_1,        0x11, 0xaaaa, 0x14, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_FFMA_OPS_S1, volta_hwpm_inst_executed_ffma_ops_s1_enc_str_1,        0x11, 0xaaaa, 0x24, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_FFMA_OPS_S2, volta_hwpm_inst_executed_ffma_ops_s2_enc_str_1,        0x11, 0xaaaa, 0x34, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_FFMA_OPS_S3, volta_hwpm_inst_executed_ffma_ops_s3_enc_str_1,        0x11, 0xaaaa, 0x44, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_OTHERFP_OPS_S0, volta_hwpm_inst_executed_otherfp_ops_s0_enc_str_1,  0x11, 0xaaaa, 0x13, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_OTHERFP_OPS_S1, volta_hwpm_inst_executed_otherfp_ops_s1_enc_str_1,  0x11, 0xaaaa, 0x23, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_OTHERFP_OPS_S2, volta_hwpm_inst_executed_otherfp_ops_s2_enc_str_1,  0x11, 0xaaaa, 0x33, PM_UNIT_SMQCTL, 1},
    {VOLTA_HWPM_INST_EXECUTED_OTHERFP_OPS_S3, volta_hwpm_inst_executed_otherfp_ops_s3_enc_str_1,  0x11, 0xaaaa, 0x43, PM_UNIT_SMQCTL, 1},
    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};
#endif

#endif /* #if NVCFG(GLOBAL_ARCH_VOLTA) */

/*
Filter signals for HWPM
1.      scg_mode_compute
2.      scg_mode_graphics
3.      sm_in_trap
4.      sm_not_in_trap
*/
#if NVCFG(GLOBAL_ARCH_VOLTA)
PerfSignalHwpmExpt_v1 PerfSignalTableGV100_gpctpc_expt[] = {
    { VOLTA_MPC_TOTAL_THREADS_LAUNCHED, volta_mpc_total_threads_launched_enc_str_1, VOLTA_MPC_THREADS_LAUNCHED, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MPC_WARP_LAUNCH }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_HWPM_WARPS_LAUNCHED_0, volta_hwpm_warps_launched_0_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_HWPM_TOTAL_WARPS_LAUNCHED_0, VOLTA_HWPM_RESTORE_WARPS_LAUNCHED_0, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & ~TRUTH_TABLE_FUNCTION_BIT_1_TRUE), HWPM_FILTER_SIGNAL_SM_IN_TRAP },
    { VOLTA_HWPM_WARPS_LAUNCHED_1, volta_hwpm_warps_launched_1_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_HWPM_TOTAL_WARPS_LAUNCHED_1, VOLTA_HWPM_RESTORE_WARPS_LAUNCHED_1, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & ~TRUTH_TABLE_FUNCTION_BIT_1_TRUE), HWPM_FILTER_SIGNAL_SM_IN_TRAP },
    { VOLTA_HWPM_WARPS_LAUNCHED_2, volta_hwpm_warps_launched_2_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_HWPM_TOTAL_WARPS_LAUNCHED_2, VOLTA_HWPM_RESTORE_WARPS_LAUNCHED_2, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & ~TRUTH_TABLE_FUNCTION_BIT_1_TRUE), HWPM_FILTER_SIGNAL_SM_IN_TRAP },
    { VOLTA_HWPM_WARPS_LAUNCHED_3, volta_hwpm_warps_launched_3_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_HWPM_TOTAL_WARPS_LAUNCHED_3, VOLTA_HWPM_RESTORE_WARPS_LAUNCHED_3, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & ~TRUTH_TABLE_FUNCTION_BIT_1_TRUE), HWPM_FILTER_SIGNAL_SM_IN_TRAP },

    { VOLTA_HWPM_EXPT_2X2B6I_S0, volta_hwpm_expt_2x2b6i_s0_enc_str_1, VOLTA_HWPM_NOP_TRIG_BIT0_5_S0, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_HWPM_NOP_TRIG_BIT6_S0, VOLTA_HWPM_NOP_TRIG_BIT7_S0 }, (~TRUTH_TABLE_FUNCTION_BIT_3_TRUE & ~TRUTH_TABLE_FUNCTION_BIT_2_TRUE), HWPM_FILTER_SIGNAL_SM_IN_TRAP },
    { VOLTA_HWPM_EXPT_2X2B6I_S1, volta_hwpm_expt_2x2b6i_s1_enc_str_1, VOLTA_HWPM_NOP_TRIG_BIT0_5_S1, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_HWPM_NOP_TRIG_BIT6_S1, VOLTA_HWPM_NOP_TRIG_BIT7_S1 }, (~TRUTH_TABLE_FUNCTION_BIT_3_TRUE & ~TRUTH_TABLE_FUNCTION_BIT_2_TRUE), HWPM_FILTER_SIGNAL_SM_IN_TRAP },
    { VOLTA_HWPM_EXPT_2X2B6I_S2, volta_hwpm_expt_2x2b6i_s2_enc_str_1, VOLTA_HWPM_NOP_TRIG_BIT0_5_S2, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_HWPM_NOP_TRIG_BIT6_S2, VOLTA_HWPM_NOP_TRIG_BIT7_S2 }, (~TRUTH_TABLE_FUNCTION_BIT_3_TRUE & ~TRUTH_TABLE_FUNCTION_BIT_2_TRUE), HWPM_FILTER_SIGNAL_SM_IN_TRAP },
    { VOLTA_HWPM_EXPT_2X2B6I_S3, volta_hwpm_expt_2x2b6i_s3_enc_str_1, VOLTA_HWPM_NOP_TRIG_BIT0_5_S3, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_HWPM_NOP_TRIG_BIT6_S3, VOLTA_HWPM_NOP_TRIG_BIT7_S3 }, (~TRUTH_TABLE_FUNCTION_BIT_3_TRUE & ~TRUTH_TABLE_FUNCTION_BIT_2_TRUE), HWPM_FILTER_SIGNAL_SM_IN_TRAP },

    { VOLTA_HWPM_CTA_LAUNCHED, volta_hwpm_cta_launched_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_HWPM_TOTAL_CTA_LAUNCHED, VOLTA_HWPM_CTA_RESTORED, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & ~TRUTH_TABLE_FUNCTION_BIT_1_TRUE), HWPM_FILTER_SIGNAL_SM_IN_TRAP },

    { VOLTA_TEX_RETURN_PACKET_COUNT, volta_tex_return_packet_count_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_TEX_F_TEX2SM_TEX_PVLD, VOLTA_TEX_F_TEX2SM_TEX_PRDY, VOLTA_TEX_F_TEX2SM_COMP_LAST, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_TEX_REQ_ACTIVE, volta_tex_tex_req_active_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_TEX_SMV2TEX_REQ_PVLD, VOLTA_TEX_SMV2TEX_REQ_PRDY, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_SHARED_LD_DATA_CONFLICTS, volta_tex_shared_ld_data_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1DATA_SHARED_LD, VOLTA_MIO_L1DATA_DATA_CONFLICTS_SM_XBAR_GRP_2C, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_SHARED_ST_DATA_CONFLICTS, volta_tex_shared_st_data_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1DATA_SHARED_ST, VOLTA_MIO_L1DATA_DATA_CONFLICTS_SM_XBAR_GRP_2C, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_TEX_GLOBAL_LD_DATA_CONFLICTS, volta_tex_global_ld_data_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1DATA_GLOBAL_LD, VOLTA_MIO_L1DATA_DATA_CONFLICTS_SM_XBAR, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_GLOBAL_ST_DATA_CONFLICTS, volta_tex_global_st_data_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1DATA_GLOBAL_ST, VOLTA_MIO_L1DATA_DATA_CONFLICTS_SM_XBAR, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_ATOM_DATA_CONFLICTS, volta_tex_atom_data_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1DATA_ATOM, VOLTA_MIO_L1DATA_DATA_CONFLICTS_SM_XBAR, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_GLOBAL_RED_DATA_CONFLICTS, volta_tex_global_red_data_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1DATA_GLOBAL_RED, VOLTA_MIO_L1DATA_DATA_CONFLICTS_SM_XBAR, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_SURFACE_RED_DATA_CONFLICTS, volta_tex_surface_red_data_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1DATA_SURFACE_RED, VOLTA_MIO_L1DATA_DATA_CONFLICTS_SM_XBAR, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_SURFACE_ST_DATA_CONFLICTS, volta_tex_surface_st_data_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1DATA_SURFACE_ST, VOLTA_MIO_L1DATA_DATA_CONFLICTS_SM_XBAR, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_TEX_ATOM_DATA_CONFLICTS, volta_tex_atom_data_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1DATA_ATOM, VOLTA_MIO_L1DATA_DATA_CONFLICTS_SM_XBAR, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_GLOBAL_RED_DATA_CONFLICTS, volta_tex_global_red_data_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1DATA_GLOBAL_RED, VOLTA_MIO_L1DATA_DATA_CONFLICTS_SM_XBAR, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_SURFACE_RED_DATA_CONFLICTS, volta_tex_surface_red_data_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1DATA_SURFACE_RED, VOLTA_MIO_L1DATA_DATA_CONFLICTS_SM_XBAR, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_SURFACE_ST_DATA_CONFLICTS, volta_tex_surface_st_data_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1DATA_SURFACE_ST, VOLTA_MIO_L1DATA_DATA_CONFLICTS_SM_XBAR, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_TEX_GLOBAL_LD_SET_CONFLICTS, volta_tex_global_ld_set_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_GLOBAL_LD_GRP_1A, VOLTA_MIO_L1TAG_SET_CONFLICTS_GRP_1A, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_GLOBAL_ST_SET_CONFLICTS, volta_tex_global_st_set_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_GLOBAL_ST_GRP_1A, VOLTA_MIO_L1TAG_SET_CONFLICTS_GRP_1A, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_LOCAL_LD_SET_CONFLICTS, volta_tex_local_ld_set_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_LOCAL_LD_GRP_1A, VOLTA_MIO_L1TAG_SET_CONFLICTS_GRP_1A, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_LOCAL_ST_SET_CONFLICTS, volta_tex_local_st_set_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_LOCAL_ST_GRP_1A, VOLTA_MIO_L1TAG_SET_CONFLICTS_GRP_1A, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_TEXTURE_LD_SET_CONFLICTS, volta_tex_texture_ld_set_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_TEXTURE_LD_GRP_1A, VOLTA_MIO_L1TAG_SET_CONFLICTS_GRP_1A, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_TEXTURE_TEX_SET_CONFLICTS, volta_tex_texture_tex_set_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_TEXTURE_TEX_GRP_1A, VOLTA_MIO_L1TAG_SET_CONFLICTS_GRP_1A, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_TEX_GLOBAL_LD_SET_ACCESS, volta_tex_global_ld_set_access_enc_str_1, VOLTA_MIO_L1TAG_SET_ACCESSES_GRP_1A, { VOLTA_MIO_L1TAG_GLOBAL_LD_GRP_1A, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_GLOBAL_ST_SET_ACCESS, volta_tex_global_st_set_access_enc_str_1, VOLTA_MIO_L1TAG_SET_ACCESSES_GRP_1A, { VOLTA_MIO_L1TAG_GLOBAL_ST_GRP_1A, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_LOCAL_LD_SET_ACCESS, volta_tex_local_ld_set_access_enc_str_1, VOLTA_MIO_L1TAG_SET_ACCESSES_GRP_1A, { VOLTA_MIO_L1TAG_LOCAL_LD_GRP_1A, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_LOCAL_ST_SET_ACCESS, volta_tex_local_st_set_access_enc_str_1, VOLTA_MIO_L1TAG_SET_ACCESSES_GRP_1A, { VOLTA_MIO_L1TAG_LOCAL_ST_GRP_1A, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_TEXTURE_LD_SET_ACCESS, volta_tex_texture_ld_set_access_enc_str_1, VOLTA_MIO_L1TAG_SET_ACCESSES_GRP_1A, { VOLTA_MIO_L1TAG_TEXTURE_LD_GRP_1A, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_TEXTURE_TEX_SET_ACCESS, volta_tex_texture_tex_set_access_enc_str_1, VOLTA_MIO_L1TAG_SET_ACCESSES_GRP_1A, { VOLTA_MIO_L1TAG_TEXTURE_TEX_GRP_1A, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_TEX_GLOBAL_RED_SET_CONFLICTS, volta_tex_global_red_set_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_GLOBAL_RED_GRP_14, VOLTA_MIO_L1TAG_SET_CONFLICTS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_ATOM_SET_CONFLICTS, volta_tex_atom_set_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_ATOM_GRP_14, VOLTA_MIO_L1TAG_SET_CONFLICTS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_SURFACE_LD_SET_CONFLICTS, volta_tex_surface_ld_set_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_SURFACE_LD_GRP_14, VOLTA_MIO_L1TAG_SET_CONFLICTS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_SURFACE_ST_SET_CONFLICTS, volta_tex_surface_st_set_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_SURFACE_ST_GRP_14, VOLTA_MIO_L1TAG_SET_CONFLICTS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_SURFACE_ATOM_SET_CONFLICTS, volta_tex_surface_atom_set_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_SURFACE_ATOM_GRP_14, VOLTA_MIO_L1TAG_SET_CONFLICTS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_SURFACE_RED_SET_CONFLICTS, volta_tex_surface_red_set_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_SURFACE_RED_GRP_14, VOLTA_MIO_L1TAG_SET_CONFLICTS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_LG_SET_CONFLICTS, volta_tex_lg_set_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_LG_GRP_14, VOLTA_MIO_L1TAG_SET_CONFLICTS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_SURFACE_SET_CONFLICTS, volta_tex_surface_set_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_SURFACE_GRP_14, VOLTA_MIO_L1TAG_SET_CONFLICTS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_TEXTURE_SET_CONFLICTS, volta_tex_texture_set_conflicts_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_TEXTURE_GRP_14, VOLTA_MIO_L1TAG_SET_CONFLICTS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_TEX_GLOBAL_RED_SET_ACCESS, volta_tex_global_red_set_access_enc_str_1, VOLTA_MIO_L1TAG_SET_ACCESSES, { VOLTA_MIO_L1TAG_GLOBAL_RED_GRP_14, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_ATOM_SET_ACCESS, volta_tex_atom_set_access_enc_str_1, VOLTA_MIO_L1TAG_SET_ACCESSES, { VOLTA_MIO_L1TAG_ATOM_GRP_14, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_SURFACE_LD_SET_ACCESS, volta_tex_surface_ld_set_access_enc_str_1, VOLTA_MIO_L1TAG_SET_ACCESSES, { VOLTA_MIO_L1TAG_SURFACE_LD_GRP_14, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_SURFACE_ST_SET_ACCESS, volta_tex_surface_st_set_access_enc_str_1, VOLTA_MIO_L1TAG_SET_ACCESSES, { VOLTA_MIO_L1TAG_SURFACE_ST_GRP_14, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_SURFACE_ATOM_SET_ACCESS, volta_tex_surface_atom_set_access_enc_str_1, VOLTA_MIO_L1TAG_SET_ACCESSES, { VOLTA_MIO_L1TAG_SURFACE_ATOM_GRP_14, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_SURFACE_RED_SET_ACCESS, volta_tex_surface_red_set_access_enc_str_1, VOLTA_MIO_L1TAG_SET_ACCESSES, { VOLTA_MIO_L1TAG_SURFACE_RED_GRP_14, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_LG_SET_ACCESS, volta_tex_lg_set_access_enc_str_1, VOLTA_MIO_L1TAG_SET_ACCESSES, { VOLTA_MIO_L1TAG_LG_GRP_14, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_SURFACE_SET_ACCESS, volta_tex_surface_set_access_enc_str_1, VOLTA_MIO_L1TAG_SET_ACCESSES, { VOLTA_MIO_L1TAG_SURFACE_GRP_14, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_TEX_TEXTURE_SET_ACCESS, volta_tex_texture_set_access_enc_str_1, VOLTA_MIO_L1TAG_SET_ACCESSES, { VOLTA_MIO_L1TAG_TEXTURE_GRP_14, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_MIO_LG_REQUESTS_PRECOALESCING, volta_mio_lg_requests_precoalescing_enc_str_1, VOLTA_MIO_L1TAG_REQUESTS_PRECOALESCING, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_LG }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_LG_SECTORS_PRECOALESCING, volta_mio_lg_sectors_precoalescing_enc_str_1, VOLTA_MIO_L1TAG_SECTORS_PRECOALESCING, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_LG }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_REQUESTS_PRECOALESCING, volta_mio_surface_requests_precoalescing_enc_str_1, VOLTA_MIO_L1TAG_REQUESTS_PRECOALESCING, { VOLTA_MIO_L1TAG_SURFACE, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_SECTORS_PRECOALESCING, volta_mio_surface_sectors_precoalescing_enc_str_1, VOLTA_MIO_L1TAG_SECTORS_PRECOALESCING, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_SURFACE }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TEXTURE_REQUESTS_PRECOALESCING, volta_mio_texture_requests_precoalescing_enc_str_1, VOLTA_MIO_L1TAG_REQUESTS_PRECOALESCING, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TEXTURE }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TEXTURE_SECTORS_PRECOALESCING, volta_mio_texture_sectors_precoalescing_enc_str_1, VOLTA_MIO_L1TAG_SECTORS_PRECOALESCING, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TEXTURE }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_LG_READ_REQUESTS_PRECOALESCING, volta_mio_lg_read_requests_precoalescing_enc_str_1, VOLTA_MIO_L1TAG_REQUESTS_PRECOALESCING, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_READ_PRECOALESCING, VOLTA_MIO_L1TAG_LG }, (TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_LG_READ_SECTORS_PRECOALESCING, volta_mio_lg_read_sectors_precoalescing_enc_str_1, VOLTA_MIO_L1TAG_SECTORS_PRECOALESCING, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_READ_PRECOALESCING, VOLTA_MIO_L1TAG_LG }, (TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_LG_WRITE_REQUESTS_PRECOALESCING, volta_mio_lg_write_requests_precoalescing_enc_str_1, VOLTA_MIO_L1TAG_REQUESTS_PRECOALESCING, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_WRITE_PRECOALESCING, VOLTA_MIO_L1TAG_LG }, (TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_LG_WRITE_SECTORS_PRECOALESCING, volta_mio_lg_write_sectors_precoalescing_enc_str_1, VOLTA_MIO_L1TAG_SECTORS_PRECOALESCING, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_WRITE_PRECOALESCING, VOLTA_MIO_L1TAG_LG }, (TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_READ_REQUESTS_PRECOALESCING, volta_mio_surface_read_requests_precoalescing_enc_str_1, VOLTA_MIO_L1TAG_REQUESTS_PRECOALESCING, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_READ_PRECOALESCING, VOLTA_MIO_L1TAG_SURFACE }, (TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_READ_SECTORS_PRECOALESCING, volta_mio_surface_read_sectors_precoalescing_enc_str_1, VOLTA_MIO_L1TAG_SECTORS_PRECOALESCING, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_READ_PRECOALESCING, VOLTA_MIO_L1TAG_SURFACE }, (TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_WRITE_REQUESTS_PRECOALESCING, volta_mio_surface_write_requests_precoalescing_enc_str_1, VOLTA_MIO_L1TAG_REQUESTS_PRECOALESCING, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_WRITE_PRECOALESCING, VOLTA_MIO_L1TAG_SURFACE }, (TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_WRITE_SECTORS_PRECOALESCING, volta_mio_surface_write_sectors_precoalescing_enc_str_1, VOLTA_MIO_L1TAG_SECTORS_PRECOALESCING, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_SURFACE, VOLTA_MIO_L1TAG_WRITE_PRECOALESCING }, (TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TEXTURE_TEX_REQUESTS_PRECOALESCING, volta_mio_texture_tex_requests_precoalescing_enc_str_1, VOLTA_MIO_L1TAG_REQUESTS_PRECOALESCING, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TEXTURE_TEX_REQUESTS }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TEXTURE_TEX_SECTORS_PRECOALESCING, volta_mio_texture_tex_sectors_precoalescing_enc_str_1, VOLTA_MIO_L1TAG_SECTORS_PRECOALESCING, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TEXTURE_TEX_REQUESTS }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TEXTURE_TLD_REQUESTS_PRECOALESCING, volta_mio_texture_ld_requests_precoalescing_enc_str_1, VOLTA_MIO_L1TAG_REQUESTS_PRECOALESCING, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TEXTURE_LD_REQUESTS }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TEXTURE_LD_SECTORS_PRECOALESCING, volta_mio_texture_ld_sectors_precoalescing_enc_str_1, VOLTA_MIO_L1TAG_SECTORS_PRECOALESCING, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TEXTURE_LD_REQUESTS }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_MIO_LG_REQUESTS_POSTCOALESCING, volta_mio_lg_requests_postcoalescing_enc_str_1, VOLTA_MIO_L1MISS_TEX2GNIC_REQUESTS_POSTCOALESCING, { VOLTA_MIO_L1MISS_TEX2GNIC_IS_LG_POSTCOALESCING, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_LG_SECTORS_POSTCOALESCING, volta_mio_lg_sectors_postcoalescing_enc_str_1, VOLTA_MIO_L1MISS_TEX2GNIC_SECTORS_SUM_POSTCOALESCING, { VOLTA_MIO_L1MISS_TEX2GNIC_IS_LG_POSTCOALESCING, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_REQUESTS_POSTCOALESCING, volta_mio_surface_requests_postcoalescing_enc_str_1, VOLTA_MIO_L1MISS_TEX2GNIC_REQUESTS_POSTCOALESCING, { VOLTA_MIO_L1MISS_TEX2GNIC_IS_SURFACE_POSTCOALESCING, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_SECTORS_POSTCOALESCING, volta_mio_surface_sectors_postcoalescing_enc_str_1, VOLTA_MIO_L1MISS_TEX2GNIC_SECTORS_SUM_POSTCOALESCING, { VOLTA_MIO_L1MISS_TEX2GNIC_IS_SURFACE_POSTCOALESCING, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TEXTURE_REQUESTS_POSTCOALESCING, volta_mio_texture_requests_postcoalescing_enc_str_1, VOLTA_MIO_L1MISS_TEX2GNIC_REQUESTS_POSTCOALESCING, { VOLTA_MIO_L1MISS_TEX2GNIC_IS_TEXTURE_POSTCOALESCING, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TEXTURE_SECTORS_POSTCOALESCING, volta_mio_texture_sectors_postcoalescing_enc_str_1, VOLTA_MIO_L1MISS_TEX2GNIC_SECTORS_SUM_POSTCOALESCING, { VOLTA_MIO_L1MISS_TEX2GNIC_IS_TEXTURE_POSTCOALESCING, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_LG_READ_REQUESTS_POSTCOALESCING, volta_mio_lg_read_requests_postcoalescing_enc_str_1, VOLTA_MIO_L1MISS_TEX2GNIC_REQUESTS_POSTCOALESCING, { VOLTA_MIO_L1MISS_TEX2GNIC_IS_READ_POSTCOALESCING, VOLTA_MIO_L1MISS_TEX2GNIC_IS_LG_POSTCOALESCING, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_LG_READ_SECTORS_POSTCOALESCING, volta_mio_lg_read_sectors_postcoalescing_enc_str_1, VOLTA_MIO_L1MISS_TEX2GNIC_SECTORS_SUM_POSTCOALESCING, { VOLTA_MIO_L1MISS_TEX2GNIC_IS_READ_POSTCOALESCING, VOLTA_MIO_L1MISS_TEX2GNIC_IS_LG_POSTCOALESCING, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_MIO_PREFETCH_REQUESTS_POSTCOALESCING, volta_mio_prefetch_requests_postcoalescing_enc_str_1, VOLTA_MIO_L1MISS_TEX2GNIC_REQUESTS_POSTCOALESCING, { VOLTA_MIO_L1MISS_TEX2GNIC_IS_PREFETCH_POSTCOALESCING, VOLTA_MIO_L1MISS_TEX2GNIC_IS_LG_POSTCOALESCING, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_PREFETCH_SECTORS_POSTCOALESCING, volta_mio_prefetch_sectors_postcoalescing_enc_str_1, VOLTA_MIO_L1MISS_TEX2GNIC_SECTORS_SUM_POSTCOALESCING, { VOLTA_MIO_L1MISS_TEX2GNIC_IS_PREFETCH_POSTCOALESCING, VOLTA_MIO_L1MISS_TEX2GNIC_IS_LG_POSTCOALESCING, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_MIO_LG_WRITE_REQUESTS_POSTCOALESCING, volta_mio_lg_write_requests_postcoalescing_enc_str_1, VOLTA_MIO_L1MISS_TEX2GNIC_REQUESTS_POSTCOALESCING, { VOLTA_MIO_L1MISS_TEX2GNIC_IS_WRITE_POSTCOALESCING, VOLTA_MIO_L1MISS_TEX2GNIC_IS_LG_POSTCOALESCING, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_LG_WRITE_SECTORS_POSTCOALESCING, volta_mio_lg_write_sectors_postcoalescing_enc_str_1, VOLTA_MIO_L1MISS_TEX2GNIC_SECTORS_SUM_POSTCOALESCING, { VOLTA_MIO_L1MISS_TEX2GNIC_IS_WRITE_POSTCOALESCING, VOLTA_MIO_L1MISS_TEX2GNIC_IS_LG_POSTCOALESCING, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_READ_REQUESTS_POSTCOALESCING, volta_mio_surface_read_requests_postcoalescing_enc_str_1, VOLTA_MIO_L1MISS_TEX2GNIC_REQUESTS_POSTCOALESCING, { VOLTA_MIO_L1MISS_TEX2GNIC_IS_READ_POSTCOALESCING, VOLTA_MIO_L1MISS_TEX2GNIC_IS_SURFACE_POSTCOALESCING, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_READ_SECTORS_POSTCOALESCING, volta_mio_surface_read_sectors_postcoalescing_enc_str_1, VOLTA_MIO_L1MISS_TEX2GNIC_SECTORS_SUM_POSTCOALESCING, { VOLTA_MIO_L1MISS_TEX2GNIC_IS_READ_POSTCOALESCING, VOLTA_MIO_L1MISS_TEX2GNIC_IS_SURFACE_POSTCOALESCING, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_WRITE_REQUESTS_POSTCOALESCING, volta_mio_surface_write_requests_postcoalescing_enc_str_1, VOLTA_MIO_L1MISS_TEX2GNIC_REQUESTS_POSTCOALESCING, { VOLTA_MIO_L1MISS_TEX2GNIC_IS_WRITE_POSTCOALESCING, VOLTA_MIO_L1MISS_TEX2GNIC_IS_SURFACE_POSTCOALESCING, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_WRITE_SECTORS_POSTCOALESCING, volta_mio_surface_write_sectors_postcoalescing_enc_str_1, VOLTA_MIO_L1MISS_TEX2GNIC_SECTORS_SUM_POSTCOALESCING, { VOLTA_MIO_L1MISS_TEX2GNIC_IS_WRITE_POSTCOALESCING, VOLTA_MIO_L1MISS_TEX2GNIC_IS_SURFACE_POSTCOALESCING, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_MIO_GLOBAL_ST_REQUESTS, volta_mio_global_st_requests_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_GLOBAL_ST, VOLTA_MIO_L1TAG_REQUESTS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_LOCAL_ST_REQUESTS, volta_mio_local_st_requests_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_LOCAL_ST, VOLTA_MIO_L1TAG_REQUESTS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_MIXED_GENERIC_LD_REQUESTS, volta_mio_mixed_generic_ld_requests_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_MIXED_GENERIC_LD, VOLTA_MIO_L1TAG_REQUESTS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_MIXED_GENERIC_ST_REQUESTS, volta_mio_mixed_generic_st_requests_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_MIXED_GENERIC_ST, VOLTA_MIO_L1TAG_REQUESTS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_ST_REQUESTS, volta_mio_surface_st_requests_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_SURFACE_ST, VOLTA_MIO_L1TAG_REQUESTS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TYPE_1D_REQUESTS, volta_mio_type_1d_requests_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_TAG_TYPE_1D, VOLTA_MIO_L1TAG_REQUESTS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TYPE_1D_BUFFER_REQUESTS, volta_mio_type_1d_buffer_requests_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_TAG_TYPE_1D_BUFFER, VOLTA_MIO_L1TAG_REQUESTS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TYPE_2D_REQUESTS, volta_mio_type_2d_requests_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_TAG_TYPE_2D, VOLTA_MIO_L1TAG_REQUESTS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TYPE_3D_REQUESTS, volta_mio_type_3d_requests_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_TAG_TYPE_3D, VOLTA_MIO_L1TAG_REQUESTS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TYPE_CUBEMAP_REQUESTS, volta_mio_type_cubemap_requests_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_TAG_TYPE_CUBEMAP, VOLTA_MIO_L1TAG_REQUESTS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TYPE_NO_MIPMAP_REQUESTS, volta_mio_type_no_mipmap_requests_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_TAG_TYPE_NO_MIPMAP, VOLTA_MIO_L1TAG_REQUESTS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_MIO_GLOBAL_LD_REQUESTS, volta_mio_global_ld_requests_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_GLOBAL_LD, VOLTA_MIO_L1TAG_REQUESTS_GRP_1F, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_LOCAL_LD_REQUESTS, volta_mio_local_ld_requests_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_LOCAL_LD, VOLTA_MIO_L1TAG_REQUESTS_GRP_1F, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_LD_REQUESTS, volta_mio_surface_ld_requests_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_SURFACE_LD, VOLTA_MIO_L1TAG_REQUESTS_GRP_1F, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_RED_REQUESTS, volta_mio_surface_red_requests_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_SURFACE_RED, VOLTA_MIO_L1TAG_REQUESTS_GRP_1F, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_ATOM_REQUESTS, volta_mio_surface_atom_requests_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_SURFACE_ATOM, VOLTA_MIO_L1TAG_REQUESTS_GRP_1F, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TEXTURE_LD_REQUESTS, volta_mio_texture_ld_requests_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_TEXTURE_LD, VOLTA_MIO_L1TAG_REQUESTS_GRP_1F, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_GLOBAL_RED_REQUESTS, volta_mio_global_red_requests_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_GLOBAL_RED, VOLTA_MIO_L1TAG_REQUESTS_GRP_1F, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_ATOM_REQUESTS, volta_mio_atom_requests_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_MIO_L1TAG_ATOM, VOLTA_MIO_L1TAG_REQUESTS_GRP_1F, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_L2_SECTOR_RESPONSES_RECEIVED, volta_mio_l2_sector_responses_received_enc_str_1, VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_2SECTORS_SUM, { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_RD, VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_PACK_RD, VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_GATOM, VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_CONCAT_GATOM }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE | TRUTH_TABLE_FUNCTION_BIT_2_TRUE | TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_MIO_LG_HIT, volta_mio_lg_hit_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_2D, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_LG_GRP_2D }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_HIT, volta_mio_surface_hit_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_2D, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_SURFACE_GRP_2D }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TEXTURE_HIT, volta_mio_texture_hit_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_2D, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TEXTURE_GRP_2D }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_GLOBAL_LD_HIT, volta_mio_global_ld_hit_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_2D, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_GLOBAL_LD_GRP_2D }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_GLOBAL_ST_HIT, volta_mio_global_st_hit_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_2D, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_GLOBAL_ST_GRP_2D }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_GLOBAL_RED_HIT, volta_mio_global_red_hit_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_2D, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_GLOBAL_RED_GRP_2D }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_MIO_LG_MISS, volta_mio_lg_miss_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_2D, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_LG_GRP_2D }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_MISS, volta_mio_surface_miss_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_2D, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_SURFACE_GRP_2D }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TEXTURE_MISS, volta_mio_texture_miss_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_2D, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TEXTURE_GRP_2D }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_GLOBAL_LD_MISS, volta_mio_global_ld_miss_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_2D, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_GLOBAL_LD_GRP_2D }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_GLOBAL_ST_MISS, volta_mio_global_st_miss_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_2D, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_GLOBAL_ST_GRP_2D }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_GLOBAL_RED_MISS, volta_mio_global_red_miss_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_2D, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_GLOBAL_RED_GRP_2D }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_MIO_ATOM_HIT, volta_mio_atom_hit_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_2E, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_ATOM_GRP_2E }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_LOCAL_LD_HIT, volta_mio_local_ld_hit_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_2E, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_LOCAL_LD_GRP_2E }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_LOCAL_ST_HIT, volta_mio_local_st_hit_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_2E, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_LOCAL_ST_GRP_2E }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TEXTURE_LD_HIT, volta_mio_texture_ld_hit_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_2E, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TEXTURE_LD_GRP_2E }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TEXTURE_TEX_HIT, volta_mio_texture_tex_hit_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_2E, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TEXTURE_TEX_GRP_2E }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_MIO_ATOM_MISS, volta_mio_atom_miss_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_2E, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_ATOM_GRP_2E }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_LOCAL_LD_MISS, volta_mio_local_ld_miss_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_2E, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_LOCAL_LD_GRP_2E }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_LOCAL_ST_MISS, volta_mio_local_st_miss_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_2E, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_LOCAL_ST_GRP_2E }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TEXTURE_LD_MISS, volta_mio_texture_ld_miss_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_2E, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TEXTURE_LD_GRP_2E }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TEXTURE_TEX_MISS, volta_mio_texture_tex_miss_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_2E, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TEXTURE_TEX_GRP_2E }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_MIO_SURFACE_LD_HIT, volta_mio_surface_ld_hit_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_2F, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_SURFACE_LD_GRP_2F }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_ST_HIT, volta_mio_surface_st_hit_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_2F, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_SURFACE_ST_GRP_2F }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_ATOM_HIT, volta_mio_surface_atom_hit_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_2F, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_SURFACE_ATOM_GRP_2F }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_RED_HIT, volta_mio_surface_red_hit_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_2F, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_SURFACE_RED_GRP_2F }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_MIO_SURFACE_LD_MISS, volta_mio_surface_ld_miss_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_2F, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_SURFACE_LD_GRP_2F }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_ST_MISS, volta_mio_surface_st_miss_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_2F, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_SURFACE_ST_GRP_2F }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_ATOM_MISS, volta_mio_surface_atom_miss_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_2F, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_SURFACE_ATOM_GRP_2F }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_SURFACE_RED_MISS, volta_mio_surface_red_miss_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_2F, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_SURFACE_RED_GRP_2F }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_MIO_TYPE_1D_HIT, volta_mio_type_1d_hit_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_30, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TYPE_1D_GRP_30 }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TYPE_1D_BUFFER_HIT, volta_mio_type_1d_buffer_hit_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_30, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TYPE_1D_BUFFER_GRP_30 }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TYPE_2D_HIT, volta_mio_type_2d_hit_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_30, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TYPE_2D_GRP_30 }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TYPE_3D_HIT, volta_mio_type_3d_hit_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_30, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TYPE_3D_GRP_30 }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TYPE_CUBEMAP_HIT, volta_mio_type_cubemap_hit_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_30, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TYPE_CUBEMAP_GRP_30 }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TYPE_NO_MIPMAP_HIT, volta_mio_type_no_mipmap_hit_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_30, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TYPE_NO_MIPMAP_GRP_30 }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_MIO_TYPE_1D_MISS, volta_mio_type_1d_miss_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_30, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TYPE_1D_GRP_30 }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TYPE_1D_BUFFER_MISS, volta_mio_type_1d_buffer_miss_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_30, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TYPE_1D_BUFFER_GRP_30 }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TYPE_2D_MISS, volta_mio_type_2d_miss_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_30, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TYPE_2D_GRP_30 }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TYPE_3D_MISS, volta_mio_type_3d_miss_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_30, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TYPE_3D_GRP_30 }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TYPE_CUBEMAP_MISS, volta_mio_type_cubemap_miss_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_30, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TYPE_CUBEMAP_GRP_30 }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_MIO_TYPE_NO_MIPMAP_MISS, volta_mio_type_no_mipmap_miss_enc_str_1, VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_30, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, VOLTA_MIO_L1TAG_TYPE_NO_MIPMAP_GRP_30 }, (TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW },

    //HWPM sideband filtering does not increment the counter when the filter signal is high (truly using signal as filter) (The behaviour is exactly opposite to SMPC sideband filtering)
    { VOLTA_HWPM_INST_EXECUTED_TRAP,     volta_hwpm_inst_executed_trap_enc_str_1, VOLTA_HWPM_INST_EXECUTED_S0, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0, HWPM_FILTER_SIGNAL_SM_NOT_IN_TRAP},
    { VOLTA_HWPM_INST_EXECUTED_NO_TRAP,  volta_hwpm_inst_executed_no_trap_enc_str_1, VOLTA_HWPM_INST_EXECUTED_S0, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0, HWPM_FILTER_SIGNAL_SM_IN_TRAP},

    { VOLTA_HWPM_ACTIVE_CYCLES_TRAP,     volta_hwpm_active_cycles_trap_enc_str_1, VOLTA_HWPM_ACTIVE_CYCLES, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0, HWPM_FILTER_SIGNAL_SM_NOT_IN_TRAP},
    { VOLTA_HWPM_ACTIVE_CYCLES_NO_TRAP,  volta_hwpm_active_cycles_no_trap_enc_str_1, VOLTA_HWPM_ACTIVE_CYCLES, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0, HWPM_FILTER_SIGNAL_SM_IN_TRAP},

    { VOLTA_HWPM_INST_EXECUTED_FP32_OPS_S0, volta_hwpm_inst_executed_fp32_ops_s0_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_HWPM_INST_EXECUTED_FFMA_OPS_S0, VOLTA_HWPM_INST_EXECUTED_OTHERFP_OPS_S0, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE), HWPM_FILTER_SIGNAL_SM_IN_TRAP},
    { VOLTA_HWPM_INST_EXECUTED_FP32_OPS_S1, volta_hwpm_inst_executed_fp32_ops_s1_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_HWPM_INST_EXECUTED_FFMA_OPS_S1, VOLTA_HWPM_INST_EXECUTED_OTHERFP_OPS_S1, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE), HWPM_FILTER_SIGNAL_SM_IN_TRAP},
    { VOLTA_HWPM_INST_EXECUTED_FP32_OPS_S2, volta_hwpm_inst_executed_fp32_ops_s2_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_HWPM_INST_EXECUTED_FFMA_OPS_S2, VOLTA_HWPM_INST_EXECUTED_OTHERFP_OPS_S2, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE), HWPM_FILTER_SIGNAL_SM_IN_TRAP},
    { VOLTA_HWPM_INST_EXECUTED_FP32_OPS_S3, volta_hwpm_inst_executed_fp32_ops_s3_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_HWPM_INST_EXECUTED_FFMA_OPS_S3, VOLTA_HWPM_INST_EXECUTED_OTHERFP_OPS_S3, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE), HWPM_FILTER_SIGNAL_SM_IN_TRAP},

    // Experiment to get tensor pipe active cycles in single pass.
    // This counter is multiplied by 2 since fp16 takes 4 clks and fp32 takes 2 clks on gv100 to executed single instruction
    { VOLTA_TENSOR_PIPE_ACTIVE_CYCLES_S0, volta_tensor_pipe_active_cycles_s0_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_HWPM_INST_EXECUTED_HMMA_FP32_OPS_S0, VOLTA_HWPM_INST_EXECUTED_HMMA_FP16_OPS_S0, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (0xFFFF), HWPM_FILTER_SIGNAL_SM_IN_TRAP, 0, NV_PMM_CONTROL_ADDTOCTR_4444},
    { VOLTA_TENSOR_PIPE_ACTIVE_CYCLES_S1, volta_tensor_pipe_active_cycles_s1_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_HWPM_INST_EXECUTED_HMMA_FP32_OPS_S1, VOLTA_HWPM_INST_EXECUTED_HMMA_FP16_OPS_S1, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (0xFFFF), HWPM_FILTER_SIGNAL_SM_IN_TRAP, 0, NV_PMM_CONTROL_ADDTOCTR_4444},
    { VOLTA_TENSOR_PIPE_ACTIVE_CYCLES_S2, volta_tensor_pipe_active_cycles_s2_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_HWPM_INST_EXECUTED_HMMA_FP32_OPS_S2, VOLTA_HWPM_INST_EXECUTED_HMMA_FP16_OPS_S2, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (0xFFFF), HWPM_FILTER_SIGNAL_SM_IN_TRAP, 0, NV_PMM_CONTROL_ADDTOCTR_4444},
    { VOLTA_TENSOR_PIPE_ACTIVE_CYCLES_S3, volta_tensor_pipe_active_cycles_s3_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_HWPM_INST_EXECUTED_HMMA_FP32_OPS_S3, VOLTA_HWPM_INST_EXECUTED_HMMA_FP16_OPS_S3, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (0xFFFF), HWPM_FILTER_SIGNAL_SM_IN_TRAP, 0, NV_PMM_CONTROL_ADDTOCTR_4444},

    { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000,  INVALID_PM_SIGNAL_NEW},
};
#endif /* #if NVCFG(GLOBAL_ARCH_VOLTA) */

#if NVCFG(GLOBAL_ARCH_VOLTA)
PerfSignalHwpm PerfSignalTableGV100_fbp0[] = {
    //FBP signals   
    // DRAM signals derived from fbp0.fbpa02pm_ba_sigs. Refer //hw/nvgpu_gvlit1/ip/memsys/fb/2.0/vmod/fb_pa/NV_FB_PA_paf.vx
    // assign pm_ba_sigs = {2'b00, num_of_tog_tsum_rd[10], num_of_tog_tsum_wr[9], num_of_1b1_tsum_rd[10], num_of_1b1_tsum_wr[9],
    // pm_subp1_dramc_write, pm_subp0_dramc_write, pm_subp1_dramc_read, pm_subp0_dramc_read, pm_subp1_dramc_activate, pm_subp0_dramc_activate}
    // dramc activate, read and write signals appear at bit positions 0-1, 2-3 and 4-5 respectively
    {VOLTA_FB_SUBP0_DRAMC_READ, volta_fb_subp0_dramc_read_enc_str_1, 0x40, 0xaaaa, 0x2, PM_UNIT_FB, 1},
    {VOLTA_FB_SUBP1_DRAMC_READ, volta_fb_subp1_dramc_read_enc_str_1, 0x40, 0xaaaa, 0x3, PM_UNIT_FB, 1},
    {VOLTA_FB_SUBP0_DRAMC_WRITE, volta_fb_subp0_dramc_write_enc_str_1, 0x40, 0xaaaa, 0x4, PM_UNIT_FB, 1},
    {VOLTA_FB_SUBP1_DRAMC_WRITE, volta_fb_subp1_dramc_write_enc_str_1, 0x40, 0xaaaa, 0x5, PM_UNIT_FB, 1},
    {VOLTA_FB_SUBP0_DRAM_ACTIVATES, volta_fb_subp0_dram_activates_enc_str_1, 0x40, 0xaaaa, 0x0, PM_UNIT_FB, 1},
    {VOLTA_FB_SUBP1_DRAM_ACTIVATES, volta_fb_subp1_dram_activates_enc_str_1, 0x40, 0xaaaa, 0x1, PM_UNIT_FB, 1},
    { INVALID_PM_SIGNAL_NEW,        "",                                 0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};
#endif

#if NVCFG(GLOBAL_ARCH_VOLTA)
//To match the output with pmlsplitter, use perfmon 0 for slice 0 and 2
PerfSignalHwpm PerfSignalTableGV100_ltc0[] = {
    //LTC signals

    // l2_subp0_write_sector_misses = ltc2fb_dirty_dat_pvld           l2 sent dirty data to fb
    {VOLTA_LTC0_WRITE_MISS_SECTORS, volta_ltc0_write_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0xe, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_WRITE_MISS_SECTORS, volta_ltc1_write_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x2d, PM_UNIT_LTS1_1, 1},

    // l2_subp0_read_sector_misses  = fb2ltc_rdat_pvld                fb sent fill data to l2
    {VOLTA_LTC0_READ_MISS_SECTORS, volta_ltc0_read_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0xf, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_READ_MISS_SECTORS, volta_ltc1_read_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x2e, PM_UNIT_LTS1_1, 1},

    //dirty_event                         tag             1       dirty event sent to fb - write into ltc
    {VOLTA_LTC0_DIRTY_EVENT, volta_ltc0_dirty_event_enc_str_1, 0x2, 0xaaaa, 0x1a, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_DIRTY_EVENT, volta_ltc1_dirty_event_enc_str_1, 0x2, 0xaaaa, 0x39, PM_UNIT_LTS1_1, 1},
    //fb_fill                             dstg            1       32b returned from fb
    {VOLTA_LTC0_FB_FILL, volta_ltc0_fb_fill_enc_str_1, 0x2, 0xaaaa, 0x1f, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_FB_FILL, volta_ltc1_fb_fill_enc_str_1, 0x2, 0xaaaa, 0x3e, PM_UNIT_LTS1_1, 1},
    //sys_fill                            dstg            1       32b returned from hub (pcie or nvlink)
    {VOLTA_LTC0_SYS_FILL, volta_ltc0_sys_fill_enc_str_1, 0x2, 0xaaaa, 0x20, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_SYS_FILL, volta_ltc1_sys_fill_enc_str_1, 0x2, 0xaaaa, 0x3f, PM_UNIT_LTS1_1, 1},

    {VOLTA_LTC0_REQUEST_SRC_UNIT_L1, volta_ltc0_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x8, PM_UNIT_LTS2, 1},
    {VOLTA_LTC1_REQUEST_SRC_UNIT_L1, volta_ltc1_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x9, PM_UNIT_LTS2_1, 1},
    {VOLTA_LTC0_REQUEST_SRC_UNIT_TEX, volta_ltc0_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x8, PM_UNIT_LTS2, 1},
    {VOLTA_LTC1_REQUEST_SRC_UNIT_TEX, volta_ltc1_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x9, PM_UNIT_LTS2_1, 1},
    {VOLTA_LTC0_REQUEST_SRC_UNIT_GCC, volta_ltc0_request_src_unit_gcc_enc_str_1, 0x9, 0xaaaa, 0x8, PM_UNIT_LTS2, 1},
    {VOLTA_LTC1_REQUEST_SRC_UNIT_GCC, volta_ltc1_request_src_unit_gcc_enc_str_1, 0x9, 0xaaaa, 0x9, PM_UNIT_LTS2_1, 1},

    {VOLTA_LTC0_HIT_SECTORS, volta_ltc0_hit_sectors_enc_str_1, 0x1, 0xffff, 0x0, PM_UNIT_LTS, 4},
    {VOLTA_LTC1_HIT_SECTORS, volta_ltc1_hit_sectors_enc_str_1, 0x1, 0xffff, 0x4, PM_UNIT_LTS_1, 4},
    {VOLTA_LTC0_MISS_SECTORS, volta_ltc0_miss_sectors_enc_str_1, 0x2, 0xffff, 0x0, PM_UNIT_LTS, 4},
    {VOLTA_LTC1_MISS_SECTORS, volta_ltc1_miss_sectors_enc_str_1, 0x2, 0xffff, 0x4, PM_UNIT_LTS_1, 4},
    {VOLTA_LTC0_REQUEST_SECTORS, volta_ltc0_request_sectors_enc_str_1, 0x0, 0xffff, 0x0, PM_UNIT_LTS, 4},
    {VOLTA_LTC1_REQUEST_SECTORS, volta_ltc1_request_sectors_enc_str_1, 0x0, 0xffff, 0x4, PM_UNIT_LTS_1, 4},

    {VOLTA_LTC0_REQUEST_ACTIVE, volta_ltc0_request_active_enc_str_1, 0x0, 0xaaaa, 0xb, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_REQUEST_ACTIVE, volta_ltc1_request_active_enc_str_1, 0x0, 0xaaaa, 0x2a, PM_UNIT_LTS1_1, 1},

    {VOLTA_LTC0_REQUEST_RD_OP, volta_ltc0_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x24, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_REQUEST_RD_OP, volta_ltc1_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x43, PM_UNIT_LTS1_1, 1},
    {VOLTA_LTC0_REQUEST_WR_OP, volta_ltc0_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x23, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_REQUEST_WR_OP, volta_ltc1_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x42, PM_UNIT_LTS1_1, 1},
    {VOLTA_LTC0_REQUEST_ATOMIC_OP, volta_ltc0_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x22, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_REQUEST_ATOMIC_OP, volta_ltc1_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x41, PM_UNIT_LTS1_1, 1},

    {VOLTA_LTC0_REQUEST_APERTURE_SYSMEM, volta_ltc0_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x1d, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_REQUEST_APERTURE_SYSMEM, volta_ltc1_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x3c, PM_UNIT_LTS1_1, 1},
    {VOLTA_LTC0_REQUEST_APERTURE_VIDMEM, volta_ltc0_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x1c, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_REQUEST_APERTURE_VIDMEM, volta_ltc1_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x3b, PM_UNIT_LTS1_1, 1},
    //For compute peer will not be cached in L2, so shoudl we add following counters?
    //{VOLTA_LTC0_REQUEST_APERTURE_PEERMEM, volta_ltc0_request_aperture_peermem_enc_str_1, 0x0, 0xaaaa, 0x1e, PM_UNIT_LTS1, 1 },
    //{VOLTA_LTC1_REQUEST_APERTURE_PEERMEM, volta_ltc1_request_aperture_peermem_enc_str_1, 0x0, 0xaaaa, 0x3d, PM_UNIT_LTS1_1, 1 },

    {VOLTA_LTC0_HIT, volta_ltc0_hit_enc_str_1, 0x0, 0xaaaa, 0x12, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_HIT, volta_ltc1_hit_enc_str_1, 0x0, 0xaaaa, 0x31, PM_UNIT_LTS1_1, 1},

    {VOLTA_LTC0_REQUEST, volta_ltc0_request_enc_str_1, 0x0, 0xaaaa, 0xa, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_REQUEST, volta_ltc1_request_enc_str_1, 0x0, 0xaaaa, 0x29, PM_UNIT_LTS1_1, 1},

    { INVALID_PM_SIGNAL_NEW,        "",                                 0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};
#endif /* #if NVCFG(GLOBAL_ARCH_VOLTA) */


#if NVCFG(GLOBAL_CHIP_T194) || NVCFG(GLOBAL_GPU_IMPL_GV11B)
PerfSignalHwpm PerfSignalTableGV11B_ltc0[] = {
    //LTC signals

    // l2_subp0_write_sector_misses = ltc2fb_dirty_dat_pvld           l2 sent dirty data to fb
    {VOLTA_LTC0_WRITE_MISS_SECTORS, volta_ltc0_write_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x24, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_WRITE_MISS_SECTORS, volta_ltc1_write_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x43, PM_UNIT_LTS1_1, 1},

    // l2_subp0_read_sector_misses  = fb2ltc_rdat_pvld                fb sent fill data to l2
    {VOLTA_LTC0_READ_MISS_SECTORS, volta_ltc0_read_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x25, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_READ_MISS_SECTORS, volta_ltc1_read_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x44, PM_UNIT_LTS1_1, 1},

    //dirty_event                         tag             1       dirty event sent to fb - write into ltc
    {VOLTA_LTC0_DIRTY_EVENT, volta_ltc0_dirty_event_enc_str_1, 0x2, 0xaaaa, 0x31, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_DIRTY_EVENT, volta_ltc1_dirty_event_enc_str_1, 0x2, 0xaaaa, 0x50, PM_UNIT_LTS1_1, 1},
    //fb_fill                             dstg            1       32b returned from fb
    {VOLTA_LTC0_FB_FILL, volta_ltc0_fb_fill_enc_str_1, 0x2, 0xaaaa, 0x36, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_FB_FILL, volta_ltc1_fb_fill_enc_str_1, 0x2, 0xaaaa, 0x55, PM_UNIT_LTS1_1, 1},
    //sys_fill                            dstg            1       32b returned from hub (pcie or nvlink)
    {VOLTA_LTC0_SYS_FILL, volta_ltc0_sys_fill_enc_str_1, 0x2, 0xaaaa, 0x37, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_SYS_FILL, volta_ltc1_sys_fill_enc_str_1, 0x2, 0xaaaa, 0x56, PM_UNIT_LTS1_1, 1},

    {VOLTA_LTC0_REQUEST_SRC_UNIT_L1, volta_ltc0_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x1e, PM_UNIT_LTS2, 1},
    {VOLTA_LTC1_REQUEST_SRC_UNIT_L1, volta_ltc1_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x1f, PM_UNIT_LTS2_1, 1},
    {VOLTA_LTC0_REQUEST_SRC_UNIT_TEX, volta_ltc0_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x1e, PM_UNIT_LTS2, 1},
    {VOLTA_LTC1_REQUEST_SRC_UNIT_TEX, volta_ltc1_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x1f, PM_UNIT_LTS2_1, 1},
    {VOLTA_LTC0_REQUEST_SRC_UNIT_GCC, volta_ltc0_request_src_unit_gcc_enc_str_1, 0x9, 0xaaaa, 0x1e, PM_UNIT_LTS2, 1},
    {VOLTA_LTC1_REQUEST_SRC_UNIT_GCC, volta_ltc1_request_src_unit_gcc_enc_str_1, 0x9, 0xaaaa, 0x1f, PM_UNIT_LTS2_1, 1},

    {VOLTA_LTC0_HIT_SECTORS, volta_ltc0_hit_sectors_enc_str_1, 0x1, 0xffff, 0x16, PM_UNIT_LTS, 4},
    {VOLTA_LTC1_HIT_SECTORS, volta_ltc1_hit_sectors_enc_str_1, 0x1, 0xffff, 0x1a, PM_UNIT_LTS_1, 4},
    {VOLTA_LTC0_MISS_SECTORS, volta_ltc0_miss_sectors_enc_str_1, 0x2, 0xffff, 0x16, PM_UNIT_LTS, 4},
    {VOLTA_LTC1_MISS_SECTORS, volta_ltc1_miss_sectors_enc_str_1, 0x2, 0xffff, 0x1a, PM_UNIT_LTS_1, 4},
    {VOLTA_LTC0_REQUEST_SECTORS, volta_ltc0_request_sectors_enc_str_1, 0x0, 0xffff, 0x16, PM_UNIT_LTS, 4},
    {VOLTA_LTC1_REQUEST_SECTORS, volta_ltc1_request_sectors_enc_str_1, 0x0, 0xffff, 0x1a, PM_UNIT_LTS_1, 4},

    {VOLTA_LTC0_REQUEST_ACTIVE, volta_ltc0_request_active_enc_str_1, 0x0, 0xaaaa, 0x21, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_REQUEST_ACTIVE, volta_ltc1_request_active_enc_str_1, 0x0, 0xaaaa, 0x40, PM_UNIT_LTS1_1, 1},

    {VOLTA_LTC0_REQUEST_RD_OP, volta_ltc0_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x35, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_REQUEST_RD_OP, volta_ltc1_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x54, PM_UNIT_LTS1_1, 1},
    {VOLTA_LTC0_REQUEST_WR_OP, volta_ltc0_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x34, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_REQUEST_WR_OP, volta_ltc1_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x53, PM_UNIT_LTS1_1, 1},
    {VOLTA_LTC0_REQUEST_ATOMIC_OP, volta_ltc0_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x33, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_REQUEST_ATOMIC_OP, volta_ltc1_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x52, PM_UNIT_LTS1_1, 1},

    {VOLTA_LTC0_REQUEST_APERTURE_SYSMEM, volta_ltc0_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x2e, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_REQUEST_APERTURE_SYSMEM, volta_ltc1_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x4d, PM_UNIT_LTS1_1, 1},
    {VOLTA_LTC0_REQUEST_APERTURE_VIDMEM, volta_ltc0_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x2d, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_REQUEST_APERTURE_VIDMEM, volta_ltc1_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x4c, PM_UNIT_LTS1_1, 1},
    //For compute peer will not be cached in L2, so shoudl we add following counters?
    //{VOLTA_LTC0_REQUEST_APERTURE_PEERMEM, volta_ltc0_request_aperture_peermem_enc_str_1, 0x0, 0xaaaa, 0x34, PM_UNIT_LTS1, 1 },
    //{VOLTA_LTC1_REQUEST_APERTURE_PEERMEM, volta_ltc1_request_aperture_peermem_enc_str_1, 0x0, 0xaaaa, 0x53, PM_UNIT_LTS1_1, 1 },

    {VOLTA_LTC0_HIT, volta_ltc0_hit_enc_str_1, 0x0, 0xaaaa, 0x28, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_HIT, volta_ltc1_hit_enc_str_1, 0x0, 0xaaaa, 0x47, PM_UNIT_LTS1_1, 1},

    {VOLTA_LTC0_REQUEST, volta_ltc0_request_enc_str_1, 0x0, 0xaaaa, 0x20, PM_UNIT_LTS1, 1},
    {VOLTA_LTC1_REQUEST, volta_ltc1_request_enc_str_1, 0x0, 0xaaaa, 0x3f, PM_UNIT_LTS1_1, 1},

    { INVALID_PM_SIGNAL_NEW,        "",                                 0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};
#endif /*#if NVCFG(GLOBAL_CHIP_T194) || NVCFG(GLOBAL_GPU_IMPL_GV11B)*/

#if NVCFG(GLOBAL_ARCH_VOLTA)
PerfSignalHwpmExpt_v1 PerfSignalTableGV100_ltc0_expt[] = {
    //write a combination of the signals.

    // ltc_read_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { VOLTA_LTC0_READ_TEX_SECTORS_FBP, volta_ltc0_read_tex_sectors_fbp_enc_str_1, VOLTA_LTC0_REQUEST_SECTORS, {VOLTA_LTC0_REQUEST_ACTIVE, VOLTA_LTC0_REQUEST_RD_OP, VOLTA_LTC0_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_request_sectors_src_unit_tex_op_atomic_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_request_atomic_op
    { VOLTA_LTC0_ATOMIC_TEX_SECTORS_FBP, volta_ltc0_atomic_tex_sectors_fbp_enc_str_1, VOLTA_LTC0_REQUEST_SECTORS, {VOLTA_LTC0_REQUEST_ACTIVE, VOLTA_LTC0_REQUEST_ATOMIC_OP, VOLTA_LTC0_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_write_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { VOLTA_LTC0_WRITE_TEX_SECTORS_FBP, volta_ltc0_write_tex_sectors_fbp_enc_str_1, VOLTA_LTC0_REQUEST_SECTORS, {VOLTA_LTC0_REQUEST_ACTIVE, VOLTA_LTC0_REQUEST_WR_OP, VOLTA_LTC0_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_read_hit_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_hit
    { VOLTA_LTC0_READ_TEX_HIT_SECTORS_FBP, volta_ltc0_read_tex_hit_sectors_fbp_enc_str_1,  VOLTA_LTC0_HIT_SECTORS, {VOLTA_LTC0_REQUEST_ACTIVE, VOLTA_LTC0_REQUEST_RD_OP, VOLTA_LTC0_REQUEST_SRC_UNIT_TEX, VOLTA_LTC0_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW},

    { VOLTA_LTC0_WRITE_TEX_HIT_SECTORS_FBP, volta_ltc0_write_tex_hit_sectors_fbp_enc_str_1,  VOLTA_LTC0_HIT_SECTORS, {VOLTA_LTC0_REQUEST_ACTIVE, VOLTA_LTC0_REQUEST_WR_OP, VOLTA_LTC0_REQUEST_SRC_UNIT_TEX, VOLTA_LTC0_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW},

    { VOLTA_LTC0_READ_SYSMEM_SECTORS_FBP, volta_ltc0_read_sysmem_sectors_fbp_enc_str_1, VOLTA_LTC0_REQUEST_SECTORS, {VOLTA_LTC0_REQUEST_ACTIVE, VOLTA_LTC0_REQUEST_RD_OP, VOLTA_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { VOLTA_LTC0_WRITE_SYSMEM_SECTORS_FBP, volta_ltc0_write_sysmem_sectors_fbp_enc_str_1, VOLTA_LTC0_REQUEST_SECTORS, {VOLTA_LTC0_REQUEST_ACTIVE, VOLTA_LTC0_REQUEST_WR_OP, VOLTA_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { VOLTA_LTC0_READ_SYSMEM_HIT_SECTORS_FBP, volta_ltc0_read_sysmem_hit_sectors_fbp_enc_str_1, VOLTA_LTC0_HIT_SECTORS, {VOLTA_LTC0_REQUEST_ACTIVE, VOLTA_LTC0_REQUEST_RD_OP, VOLTA_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { VOLTA_LTC0_WRITE_SYSMEM_HIT_SECTORS_FBP, volta_ltc0_write_sysmem_hit_sectors_fbp_enc_str_1, VOLTA_LTC0_HIT_SECTORS, {VOLTA_LTC0_REQUEST_ACTIVE, VOLTA_LTC0_REQUEST_WR_OP, VOLTA_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { VOLTA_LTC0_READ_SYSMEM_MISS_SECTORS_FBP, volta_ltc0_read_sysmem_miss_sectors_fbp_enc_str_1, VOLTA_LTC0_MISS_SECTORS, {VOLTA_LTC0_REQUEST_ACTIVE, VOLTA_LTC0_REQUEST_RD_OP, VOLTA_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { VOLTA_LTC0_WRITE_SYSMEM_MISS_SECTORS_FBP, volta_ltc0_write_sysmem_miss_sectors_fbp_enc_str_1, VOLTA_LTC0_MISS_SECTORS, {VOLTA_LTC0_REQUEST_ACTIVE, VOLTA_LTC0_REQUEST_WR_OP, VOLTA_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { VOLTA_LTC0_TOTAL_READ_SECTORS_FBP, volta_ltc0_total_read_sectors_fbp_enc_str_1, VOLTA_LTC0_REQUEST_SECTORS, {VOLTA_LTC0_REQUEST_ATOMIC_OP, VOLTA_LTC0_REQUEST_RD_OP, VOLTA_LTC0_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { VOLTA_LTC0_TOTAL_WRITE_SECTORS_FBP, volta_ltc0_total_write_sectors_fbp_enc_str_1, VOLTA_LTC0_REQUEST_SECTORS, {VOLTA_LTC0_REQUEST_ATOMIC_OP, VOLTA_LTC0_REQUEST_WR_OP, VOLTA_LTC0_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_read_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { VOLTA_LTC0_READ_VIDMEM_SECTORS_FBP,      volta_ltc0_read_vidmem_sectors_fbp_enc_str_1,    VOLTA_LTC0_REQUEST_SECTORS, {VOLTA_LTC0_REQUEST_ACTIVE, VOLTA_LTC0_REQUEST_RD_OP, VOLTA_LTC0_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_write_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { VOLTA_LTC0_WRITE_VIDMEM_SECTORS_FBP,      volta_ltc0_write_vidmem_sectors_fbp_enc_str_1,    VOLTA_LTC0_REQUEST_SECTORS, {VOLTA_LTC0_REQUEST_ACTIVE, VOLTA_LTC0_REQUEST_WR_OP, VOLTA_LTC0_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_read_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { VOLTA_LTC1_READ_TEX_SECTORS_FBP, volta_ltc1_read_tex_sectors_fbp_enc_str_1, VOLTA_LTC1_REQUEST_SECTORS, {VOLTA_LTC1_REQUEST_ACTIVE, VOLTA_LTC1_REQUEST_RD_OP, VOLTA_LTC1_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_request_sectors_src_unit_tex_op_atomic_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_request_atomic_op
    { VOLTA_LTC1_ATOMIC_TEX_SECTORS_FBP, volta_ltc1_atomic_tex_sectors_fbp_enc_str_1, VOLTA_LTC1_REQUEST_SECTORS, {VOLTA_LTC1_REQUEST_ACTIVE, VOLTA_LTC1_REQUEST_ATOMIC_OP, VOLTA_LTC1_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_write_sectors_tex_fbp0_l2slice1 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { VOLTA_LTC1_WRITE_TEX_SECTORS_FBP, volta_ltc1_write_tex_sectors_fbp_enc_str_1, VOLTA_LTC1_REQUEST_SECTORS, {VOLTA_LTC1_REQUEST_ACTIVE, VOLTA_LTC1_REQUEST_WR_OP, VOLTA_LTC1_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_read_hit_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_hit
    { VOLTA_LTC1_READ_TEX_HIT_SECTORS_FBP, volta_ltc1_read_tex_hit_sectors_fbp_enc_str_1,  VOLTA_LTC1_HIT_SECTORS, {VOLTA_LTC1_REQUEST_ACTIVE, VOLTA_LTC1_REQUEST_RD_OP, VOLTA_LTC1_REQUEST_SRC_UNIT_TEX, VOLTA_LTC1_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW},

    { VOLTA_LTC1_WRITE_TEX_HIT_SECTORS_FBP, volta_ltc1_write_tex_hit_sectors_fbp_enc_str_1,  VOLTA_LTC1_HIT_SECTORS, {VOLTA_LTC1_REQUEST_ACTIVE, VOLTA_LTC1_REQUEST_WR_OP, VOLTA_LTC1_REQUEST_SRC_UNIT_TEX, VOLTA_LTC1_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW},

    { VOLTA_LTC1_READ_SYSMEM_SECTORS_FBP, volta_ltc1_read_sysmem_sectors_fbp_enc_str_1, VOLTA_LTC1_REQUEST_SECTORS, {VOLTA_LTC1_REQUEST_ACTIVE, VOLTA_LTC1_REQUEST_RD_OP, VOLTA_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { VOLTA_LTC1_WRITE_SYSMEM_SECTORS_FBP, volta_ltc1_write_sysmem_sectors_fbp_enc_str_1, VOLTA_LTC1_REQUEST_SECTORS, {VOLTA_LTC1_REQUEST_ACTIVE, VOLTA_LTC1_REQUEST_WR_OP, VOLTA_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { VOLTA_LTC1_READ_SYSMEM_HIT_SECTORS_FBP, volta_ltc1_read_sysmem_hit_sectors_fbp_enc_str_1, VOLTA_LTC1_HIT_SECTORS, {VOLTA_LTC1_REQUEST_ACTIVE, VOLTA_LTC1_REQUEST_RD_OP, VOLTA_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { VOLTA_LTC1_WRITE_SYSMEM_HIT_SECTORS_FBP, volta_ltc1_write_sysmem_hit_sectors_fbp_enc_str_1, VOLTA_LTC1_HIT_SECTORS, {VOLTA_LTC1_REQUEST_ACTIVE, VOLTA_LTC1_REQUEST_WR_OP, VOLTA_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { VOLTA_LTC1_READ_SYSMEM_MISS_SECTORS_FBP, volta_ltc1_read_sysmem_miss_sectors_fbp_enc_str_1, VOLTA_LTC1_MISS_SECTORS, {VOLTA_LTC1_REQUEST_ACTIVE, VOLTA_LTC1_REQUEST_RD_OP, VOLTA_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { VOLTA_LTC1_WRITE_SYSMEM_MISS_SECTORS_FBP, volta_ltc1_write_sysmem_miss_sectors_fbp_enc_str_1, VOLTA_LTC1_MISS_SECTORS, {VOLTA_LTC1_REQUEST_ACTIVE, VOLTA_LTC1_REQUEST_WR_OP, VOLTA_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { VOLTA_LTC1_TOTAL_READ_SECTORS_FBP, volta_ltc1_total_read_sectors_fbp_enc_str_1, VOLTA_LTC1_REQUEST_SECTORS, {VOLTA_LTC1_REQUEST_ATOMIC_OP, VOLTA_LTC1_REQUEST_RD_OP, VOLTA_LTC1_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { VOLTA_LTC1_TOTAL_WRITE_SECTORS_FBP, volta_ltc1_total_write_sectors_fbp_enc_str_1, VOLTA_LTC1_REQUEST_SECTORS, {VOLTA_LTC1_REQUEST_ATOMIC_OP, VOLTA_LTC1_REQUEST_WR_OP, VOLTA_LTC1_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_read_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { VOLTA_LTC1_READ_VIDMEM_SECTORS_FBP,      volta_ltc1_read_vidmem_sectors_fbp_enc_str_1,    VOLTA_LTC1_REQUEST_SECTORS, {VOLTA_LTC1_REQUEST_ACTIVE, VOLTA_LTC1_REQUEST_RD_OP, VOLTA_LTC1_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_write_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { VOLTA_LTC1_WRITE_VIDMEM_SECTORS_FBP,      volta_ltc1_write_vidmem_sectors_fbp_enc_str_1,    VOLTA_LTC1_REQUEST_SECTORS, {VOLTA_LTC1_REQUEST_ACTIVE, VOLTA_LTC1_REQUEST_WR_OP, VOLTA_LTC1_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000, INVALID_PM_SIGNAL_NEW},
};

PerfSignalHwpm PerfSignalTableGV100_nvtx0[] = {
    { VOLTA_NVLINK_TX_FLIT_ANY, volta_nvlink_tx_flit_any_enc_str_1, 0x3c, 0xaaaa, 0x12, PM_UNIT_NVTX, 1},
    { VOLTA_NVLINK_TX_FLIT_DATA, volta_nvlink_tx_flit_data_enc_str_1, 0x3c, 0xaaaa, 0x13, PM_UNIT_NVTX, 1},
    { VOLTA_NVLINK_TX_PKT_RSP_ALL, volta_nvlink_tx_pkt_rsp_all_enc_str_1, 0x3c, 0xaaaa, 0x11, PM_UNIT_NVTX, 1 },
    { VOLTA_NVLINK_TX_PKT_REQ_WRITE, volta_nvlink_tx_pkt_req_write_enc_str_1, 0x1e, 0xaaaa, 0x10, PM_UNIT_NVTX, 1 },
    { VOLTA_NVLINK_TX_PKT_REQ_ATOMIC, volta_nvlink_tx_pkt_req_atomic_enc_str_1, 0x3b, 0xaaaa, 0x13, PM_UNIT_NVTX, 1 },
    { VOLTA_NVLINK_TX_PKT_REQ_ATOMIC_NONRED, volta_nvlink_tx_pkt_req_atomic_nonred_enc_str_1, 0x3b, 0xaaaa, 0x12, PM_UNIT_NVTX, 1 },
    { VOLTA_NVLINK_TX_PKT_REQ_ATOMIC_POSTED_RED, volta_nvlink_tx_pkt_req_atomic_posted_red_enc_str_1, 0x3b, 0xaaaa, 0x11, PM_UNIT_NVTX, 1 },
    { VOLTA_NVLINK_TX_PKT_REQ_ATOMIC_NONPOSTED_RED, volta_nvlink_tx_pkt_req_atomic_nonposted_red_enc_str_1, 0x3b, 0xaaaa, 0x10, PM_UNIT_NVTX, 1 },
    { VOLTA_NVLINK_TX_PKT_REQ_RMW, volta_nvlink_tx_pkt_req_rmw_enc_str_1, 0x2d, 0xaaaa, 0x10, PM_UNIT_NVTX, 1 },
    { VOLTA_NVLINK_TX_STALL_ANY_VC, volta_nvlink_tx_stall_any_vc_enc_str_1, 0x47, 0xaaaa, 0x13, PM_UNIT_NVTX, 1 },
    { VOLTA_NVLINK_TX_PKT_REQ_ALL, volta_nvlink_tx_pkt_req_all_enc_str_1, 0x48, 0xaaaa, 0x10, PM_UNIT_NVTX, 1 },
    { VOLTA_NVLINK_TX_STALL_ALL_VC, volta_nvlink_tx_stall_all_vc_enc_str_1, 0x48, 0xaaaa, 0x13, PM_UNIT_NVTX, 1 },
    { VOLTA_NVLINK_TX_PKT_REQ_READ, volta_nvlink_tx_pkt_req_read_enc_str_1, 0x14, 0xaaaa, 0x12, PM_UNIT_NVTX, 1 },
    { VOLTA_NVLINK_TX_FLIT_HEADER, volta_nvlink_tx_flit_header_enc_str_1, 0x0, 0xaaaa, 0x12, PM_UNIT_NVTX, 1 },
    /* Use nvwatch to configure nvlink throughput counters, and value of throughput counters should be reflected in the value of these PMs. Full support to do this programatically is not added in profiler. */
    { VOLTA_NVLINK_TX_THROUGHPUT_CNT0, volta_nvlink_tx_throughput_cnt0_enc_str_1, 0x57, 0xaaaa, 0x10, PM_UNIT_NVTX, 1 },
    { VOLTA_NVLINK_TX_THROUGHPUT_CNT1, volta_nvlink_tx_throughput_cnt1_enc_str_1, 0x57, 0xaaaa, 0x11, PM_UNIT_NVTX, 1 },
    { INVALID_PM_SIGNAL_NEW,        "",                                 0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpmExpt_v1 PerfSignalTableGV100_nvtx0_expt[] = {
    { VOLTA_NVLINK_TX_WRITE_TOTAL_FLITS, volta_nvlink_tx_write_total_flits_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_NVLINK_TX_PKT_REQ_WRITE, VOLTA_NVLINK_TX_FLIT_ANY, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_NVLINK_TX_WRITE_DATA_FLITS, volta_nvlink_tx_write_data_flits_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_NVLINK_TX_PKT_REQ_WRITE, VOLTA_NVLINK_TX_FLIT_DATA, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_NVLINK_TX_READ_TOTAL_FLITS, volta_nvlink_tx_read_total_flits_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_NVLINK_TX_PKT_REQ_READ, VOLTA_NVLINK_TX_FLIT_ANY, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_NVLINK_TX_READ_DATA_FLITS, volta_nvlink_tx_read_data_flits_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_NVLINK_TX_PKT_REQ_READ, VOLTA_NVLINK_TX_FLIT_DATA, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },

    //Following 2 experiments should give 0 value
    { VOLTA_NVLINK_TX_RSP_TOTAL_FLITS, volta_nvlink_tx_rsp_total_flits_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_NVLINK_TX_PKT_RSP_ALL, VOLTA_NVLINK_TX_FLIT_ANY, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_NVLINK_TX_RSP_DATA_FLITS, volta_nvlink_tx_rsp_data_flits_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_NVLINK_TX_PKT_RSP_ALL, VOLTA_NVLINK_TX_FLIT_DATA, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_NVLINK_TX_NRATOM_TOTAL_FLITS, volta_nvlink_tx_nratom_total_flits_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_NVLINK_TX_PKT_REQ_ATOMIC_NONRED, VOLTA_NVLINK_TX_FLIT_ANY, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_NVLINK_TX_NRATOM_DATA_FLITS, volta_nvlink_tx_nratom_data_flits_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_NVLINK_TX_PKT_REQ_ATOMIC_NONRED, VOLTA_NVLINK_TX_FLIT_DATA, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },

    { VOLTA_NVLINK_TX_RATOM_TOTAL_FLITS, volta_nvlink_tx_ratom_total_flits_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_NVLINK_TX_PKT_REQ_ATOMIC_POSTED_RED, VOLTA_NVLINK_TX_PKT_REQ_ATOMIC_NONPOSTED_RED, VOLTA_NVLINK_TX_FLIT_ANY, INVALID_PM_SIGNAL_NEW }, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_NVLINK_TX_RATOM_DATA_FLITS, volta_nvlink_tx_ratom_data_flits_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_NVLINK_TX_PKT_REQ_ATOMIC_POSTED_RED, VOLTA_NVLINK_TX_PKT_REQ_ATOMIC_NONPOSTED_RED, VOLTA_NVLINK_TX_FLIT_DATA, INVALID_PM_SIGNAL_NEW }, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW },

    { INVALID_PM_SIGNAL_NEW, "", INVALID_PM_SIGNAL_NEW, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, 0x00000000, INVALID_PM_SIGNAL_NEW },
};

PerfSignalHwpm PerfSignalTableGV100_nvrx0[] = {
    { VOLTA_NVLINK_RX_FLIT_ANY, volta_nvlink_rx_flit_any_enc_str_1, 0x3c, 0xaaaa, 0x12, PM_UNIT_NVRX, 1},
    { VOLTA_NVLINK_RX_FLIT_DATA, volta_nvlink_rx_flit_data_enc_str_1, 0x3c, 0xaaaa, 0x13, PM_UNIT_NVRX, 1},
    { VOLTA_NVLINK_RX_PKT_RSP_ALL, volta_nvlink_rx_pkt_rsp_all_enc_str_1, 0x3c, 0xaaaa, 0x11, PM_UNIT_NVRX, 1 },
    { VOLTA_NVLINK_RX_PKT_REQ_WRITE, volta_nvlink_rx_pkt_req_write_enc_str_1, 0x1e, 0xaaaa, 0x10, PM_UNIT_NVRX, 1 },
    { VOLTA_NVLINK_RX_PKT_REQ_ATOMIC, volta_nvlink_rx_pkt_req_atomic_enc_str_1, 0x3b, 0xaaaa, 0x13, PM_UNIT_NVRX, 1 },
    { VOLTA_NVLINK_RX_PKT_REQ_ATOMIC_NONRED, volta_nvlink_rx_pkt_req_atomic_nonred_enc_str_1, 0x3b, 0xaaaa, 0x12, PM_UNIT_NVRX, 1 },
    { VOLTA_NVLINK_RX_PKT_REQ_ATOMIC_POSTED_RED,    volta_nvlink_rx_pkt_req_atomic_posted_red_enc_str_1, 0x3b, 0xaaaa, 0x11, PM_UNIT_NVRX, 1 },
    { VOLTA_NVLINK_RX_PKT_REQ_ATOMIC_NONPOSTED_RED, volta_nvlink_rx_pkt_req_atomic_nonposted_red_enc_str_1, 0x3b, 0xaaaa, 0x10, PM_UNIT_NVRX, 1 },
    { VOLTA_NVLINK_RX_PKT_REQ_RMW, volta_nvlink_rx_pkt_req_rmw_enc_str_1, 0x2d, 0xaaaa, 0x10, PM_UNIT_NVRX, 1 },
    { VOLTA_NVLINK_RX_STALL_ANY_VC, volta_nvlink_rx_stall_any_vc_enc_str_1, 0x47, 0xaaaa, 0x13, PM_UNIT_NVRX, 1 },
    { VOLTA_NVLINK_RX_PKT_REQ_ALL, volta_nvlink_rx_pkt_req_all_enc_str_1, 0x48, 0xaaaa, 0x10, PM_UNIT_NVRX, 1 },
    { VOLTA_NVLINK_RX_STALL_ALL_VC, volta_nvlink_rx_stall_all_vc_enc_str_1, 0x48, 0xaaaa, 0x13, PM_UNIT_NVRX, 1 },
    { VOLTA_NVLINK_RX_PKT_REQ_READ, volta_nvlink_rx_pkt_req_read_enc_str_1, 0x14, 0xaaaa, 0x12, PM_UNIT_NVRX, 1 },
    { VOLTA_NVLINK_RX_FLIT_HEADER, volta_nvlink_rx_flit_header_enc_str_1, 0x0, 0xaaaa, 0x12, PM_UNIT_NVRX, 1 },
    /* Use nvwatch to configure nvlink throughput counters, and value of throughput counters should be reflected in the value of these PMs. Full support to do this programatically is not added in profiler. */
    { VOLTA_NVLINK_RX_THROUGHPUT_CNT0, volta_nvlink_rx_throughput_cnt0_enc_str_1, 0x57, 0xaaaa, 0x10, PM_UNIT_NVRX, 1 },
    { VOLTA_NVLINK_RX_THROUGHPUT_CNT1, volta_nvlink_rx_throughput_cnt1_enc_str_1, 0x57, 0xaaaa, 0x11, PM_UNIT_NVRX, 1 },
    { INVALID_PM_SIGNAL_NEW,        "",                                 0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpmExpt_v1 PerfSignalTableGV100_nvrx0_expt[] = {
    //Following 2 experiments should give 0 value
    { VOLTA_NVLINK_RX_WRITE_TOTAL_FLITS, volta_nvlink_rx_write_total_flits_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_NVLINK_RX_PKT_REQ_WRITE, VOLTA_NVLINK_RX_FLIT_ANY, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_NVLINK_RX_WRITE_DATA_FLITS, volta_nvlink_rx_write_data_flits_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_NVLINK_RX_PKT_REQ_WRITE, VOLTA_NVLINK_RX_FLIT_DATA, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },


    { VOLTA_NVLINK_RX_READ_TOTAL_FLITS, volta_nvlink_rx_read_total_flits_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_NVLINK_RX_PKT_REQ_READ, VOLTA_NVLINK_RX_FLIT_ANY, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_NVLINK_RX_READ_DATA_FLITS, volta_nvlink_rx_read_data_flits_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_NVLINK_RX_PKT_REQ_READ, VOLTA_NVLINK_RX_FLIT_DATA, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },


    { VOLTA_NVLINK_RX_RSP_TOTAL_FLITS, volta_nvlink_rx_rsp_total_flits_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_NVLINK_RX_PKT_RSP_ALL, VOLTA_NVLINK_RX_FLIT_ANY, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_NVLINK_RX_RSP_DATA_FLITS, volta_nvlink_rx_rsp_data_flits_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_NVLINK_RX_PKT_RSP_ALL, VOLTA_NVLINK_RX_FLIT_DATA, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },

    //Following 2 experiments should give 0 value
    { VOLTA_NVLINK_RX_NRATOM_TOTAL_FLITS, volta_nvlink_rx_nratom_total_flits_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_NVLINK_RX_PKT_REQ_ATOMIC_NONRED, VOLTA_NVLINK_RX_FLIT_ANY, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_NVLINK_RX_NRATOM_DATA_FLITS, volta_nvlink_rx_nratom_data_flits_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_NVLINK_RX_PKT_REQ_ATOMIC_NONRED, VOLTA_NVLINK_RX_FLIT_DATA, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW },

    //Following 2 experiments should give 0 value
    { VOLTA_NVLINK_RX_RATOM_TOTAL_FLITS, volta_nvlink_rx_ratom_total_flits_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_NVLINK_RX_PKT_REQ_ATOMIC_POSTED_RED, VOLTA_NVLINK_RX_PKT_REQ_ATOMIC_NONPOSTED_RED, VOLTA_NVLINK_RX_FLIT_ANY, INVALID_PM_SIGNAL_NEW }, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW },
    { VOLTA_NVLINK_RX_RATOM_DATA_FLITS, volta_nvlink_rx_ratom_data_flits_enc_str_1, INVALID_PM_SIGNAL_NEW, { VOLTA_NVLINK_RX_PKT_REQ_ATOMIC_POSTED_RED, VOLTA_NVLINK_RX_PKT_REQ_ATOMIC_NONPOSTED_RED, VOLTA_NVLINK_RX_FLIT_DATA, INVALID_PM_SIGNAL_NEW }, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW },

    { INVALID_PM_SIGNAL_NEW, "", INVALID_PM_SIGNAL_NEW, { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, 0x00000000, INVALID_PM_SIGNAL_NEW },
};

#endif /* #if NVCFG(GLOBAL_ARCH_VOLTA) */

#if NVCFG(GLOBAL_ARCH_VOLTA)
PerfSignalNvLinkThroughputCounters PerfSignalTableGV100_nvlinkTC[] = {
    // signalId     pSignalName     unitOfTraffic   typeOfFlits     transactionType/requestType     responseType     tranferDirection
    { VOLTA_NVLINK_TL_TX_TOTAL_FLITS, volta_nvlink_tl_tx_total_flits_enc_str_1, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, GV100_NVLINK_TX_TOTAL_FLITS,
        NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_REQ_FILTER_REQUESTFILTERMODE_INIT, CUPROF_NVLINK_DATA_TRANSMIT, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_INIT },

    { VOLTA_NVLINK_TL_TX_DATA_FLITS, volta_nvlink_tl_tx_data_flits_enc_str_1, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_FLITFILTER_DATA,
        NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_REQ_FILTER_REQUESTFILTERMODE_INIT, CUPROF_NVLINK_DATA_TRANSMIT, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_INIT },

    // This will give us read commands in request. we should use NONE for responsefiltermode.
    // TBD : Change the name of signal to flits_read_request.
    { VOLTA_NVLINK_TL_TX_READ_TOTAL_FLITS, volta_nvlink_tl_tx_read_total_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, GV100_NVLINK_TX_TOTAL_FLITS,
        GV100_NVLINK_TX_TOTAL_FLITS_READ, CUPROF_NVLINK_DATA_TRANSMIT, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_NONE },

    // We should use NONE for responsefiltermode, otherwise all response packets will be counted which is not intended. For write there is no response.
    { VOLTA_NVLINK_TL_TX_WRITE_TOTAL_FLITS, volta_nvlink_tl_tx_write_total_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, GV100_NVLINK_TX_TOTAL_FLITS,
        GV100_NVLINK_TX_TOTAL_FLITS_WRITE, CUPROF_NVLINK_DATA_TRANSMIT, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_NONE },

    // We should use NONE for responsefiltermode, otherwise all response packets will be counted which is not intended. For RED there is no response.
    { VOLTA_NVLINK_TL_TX_RATOM_TOTAL_FLITS, volta_nvlink_tl_tx_ratom_total_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, GV100_NVLINK_TX_TOTAL_FLITS,
        GV100_NVLINK_TX_TOTAL_FLITS_RATOM, CUPROF_NVLINK_DATA_TRANSMIT, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_NONE },

    // This is tricky as the non-red atom will have some data along with the request but the problem is we cannot separate the READ and NRATOM response from REQRSP_D and REQRSP_ND.
    // TBD : Rename this as FLITS_NRATOM_REQUEST counter. RESPONSEFILTERMODE should be NONE here.
    { VOLTA_NVLINK_TL_TX_NRATOM_TOTAL_FLITS, volta_nvlink_tl_tx_nratom_total_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, GV100_NVLINK_TX_TOTAL_FLITS,
        GV100_NVLINK_TX_TOTAL_FLITS_NRATOM, CUPROF_NVLINK_DATA_TRANSMIT, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_NONE },

    // RESPONSEFILTERMODE should be NONE here.
    // TBD : (Need to check if ATSD nonflush or flush should be included here)
    { VOLTA_NVLINK_TL_TX_FLUSH_TOTAL_FLITS, volta_nvlink_tl_tx_flush_total_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, GV100_NVLINK_TX_TOTAL_FLITS,
        NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_REQ_FILTER_REQUESTFILTERMODE_FLUSH, CUPROF_NVLINK_DATA_TRANSMIT, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_NONE },

    { VOLTA_NVLINK_TL_TX_RESPD_TOTAL_FLITS, volta_nvlink_tl_tx_respd_total_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, GV100_NVLINK_TX_TOTAL_FLITS,
        NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_REQ_FILTER_REQUESTFILTERMODE_NONE, CUPROF_NVLINK_DATA_TRANSMIT, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_INIT },

    // We should get 0 values for TX read data flits. RESPONSEFILTERMODE should be NONE here.
    { VOLTA_NVLINK_TL_TX_READ_DATA_FLITS, volta_nvlink_tl_tx_read_data_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_FLITFILTER_DATA,
        GV100_NVLINK_TX_TOTAL_FLITS_READ, CUPROF_NVLINK_DATA_TRANSMIT, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_NONE},

    // RESPONSEFILTERMODE should be NONE here.
    { VOLTA_NVLINK_TL_TX_WRITE_DATA_FLITS, volta_nvlink_tl_tx_write_data_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_FLITFILTER_DATA,
        GV100_NVLINK_TX_TOTAL_FLITS_WRITE, CUPROF_NVLINK_DATA_TRANSMIT, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_NONE },

    // RESPONSEFILTERMODE should be NONE here.
    { VOLTA_NVLINK_TL_TX_RATOM_DATA_FLITS, volta_nvlink_tl_tx_ratom_data_flits_enc_str_1,  NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_FLITFILTER_DATA,
        GV100_NVLINK_TX_TOTAL_FLITS_RATOM, CUPROF_NVLINK_DATA_TRANSMIT, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_NONE },

    // We should get 0 values for TX nratom data flits. RESPONSEFILTERMODE should be NONE here.
    { VOLTA_NVLINK_TL_TX_NRATOM_DATA_FLITS, volta_nvlink_tl_tx_nratom_data_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_FLITFILTER_DATA,
        GV100_NVLINK_TX_TOTAL_FLITS_NRATOM, CUPROF_NVLINK_DATA_TRANSMIT, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_NONE },

    // We should get 0 values for TX flush data flits. RESPONSEFILTERMODE should be NONE here
    { VOLTA_NVLINK_TL_TX_FLUSH_DATA_FLITS, volta_nvlink_tl_tx_flush_data_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_FLITFILTER_DATA,
        NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_REQ_FILTER_REQUESTFILTERMODE_FLUSH, CUPROF_NVLINK_DATA_TRANSMIT, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_NONE },

    // We will get 0 values for TX resp data flits.
    { VOLTA_NVLINK_TL_TX_RESPD_DATA_FLITS, volta_nvlink_tl_tx_respd_data_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_FLITFILTER_DATA,
        NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_REQ_FILTER_REQUESTFILTERMODE_NONE, CUPROF_NVLINK_DATA_TRANSMIT, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_INIT },

    { VOLTA_NVLINK_TL_TX_IDLE_FLITS, volta_nvlink_tl_tx_idle_flits_enc_str_1, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_FLITFILTER_IDLE,
        NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_REQ_FILTER_REQUESTFILTERMODE_INIT, CUPROF_NVLINK_DATA_TRANSMIT, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_INIT },

    //-----------------------------------------------------------------------------------------------------------------------------------------------------------------
    { VOLTA_NVLINK_TL_RX_TOTAL_FLITS, volta_nvlink_tl_rx_total_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, GV100_NVLINK_RX_TOTAL_FLITS,
        NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_REQ_FILTER_REQUESTFILTERMODE_INIT, CUPROF_NVLINK_DATA_RECIEVE, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_INIT },

    { VOLTA_NVLINK_TL_RX_DATA_FLITS, volta_nvlink_tl_rx_data_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_FLITFILTER_DATA,
        NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_REQ_FILTER_REQUESTFILTERMODE_INIT, CUPROF_NVLINK_DATA_RECIEVE, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_INIT },

    // Should be 0 as requests are sent from TX and in REQRSP we cannot separate the read and nratom response. So we have to use RESPONSEFILTERMODE as NONE.
    { VOLTA_NVLINK_TL_RX_READ_TOTAL_FLITS, volta_nvlink_tl_rx_read_total_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, GV100_NVLINK_RX_TOTAL_FLITS,
        GV100_NVLINK_RX_TOTAL_FLITS_READ, CUPROF_NVLINK_DATA_RECIEVE, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_NONE },

    // Should be 0. We have to use RESPONSEFILTERMODE as NONE.
    { VOLTA_NVLINK_TL_RX_WRITE_TOTAL_FLITS, volta_nvlink_tl_rx_write_total_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, GV100_NVLINK_RX_TOTAL_FLITS,
        GV100_NVLINK_RX_TOTAL_FLITS_WRITE, CUPROF_NVLINK_DATA_RECIEVE, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_NONE },

    // Should be 0. We have to use RESPONSEFILTERMODE as NONE.
    { VOLTA_NVLINK_TL_RX_RATOM_TOTAL_FLITS, volta_nvlink_tl_rx_ratom_total_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, GV100_NVLINK_RX_TOTAL_FLITS,
        GV100_NVLINK_RX_TOTAL_FLITS_RATOM, CUPROF_NVLINK_DATA_RECIEVE, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_NONE },

    // Should be 0 as the commands are sent from TX and in REQRSP, we cannot separate the read and nratom response. We have to use RESPONSEFILTERMODE as NONE.
    { VOLTA_NVLINK_TL_RX_NRATOM_TOTAL_FLITS, volta_nvlink_tl_rx_nratom_total_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, GV100_NVLINK_RX_TOTAL_FLITS,
        GV100_NVLINK_RX_TOTAL_FLITS_NRATOM, CUPROF_NVLINK_DATA_RECIEVE, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_NONE },

    // Should be 0. TX sends flush. We have to use RESPONSEFILTERMODE as NONE.
    { VOLTA_NVLINK_TL_RX_FLUSH_TOTAL_FLITS, volta_nvlink_tl_rx_flush_total_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, GV100_NVLINK_RX_TOTAL_FLITS,
        NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_REQ_FILTER_REQUESTFILTERMODE_FLUSH, CUPROF_NVLINK_DATA_RECIEVE, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_NONE },

    { VOLTA_NVLINK_TL_RX_RESPD_TOTAL_FLITS, volta_nvlink_tl_rx_respd_total_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, GV100_NVLINK_RX_TOTAL_FLITS,
        NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_REQ_FILTER_REQUESTFILTERMODE_NONE, CUPROF_NVLINK_DATA_RECIEVE, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_INIT },

    // This should be 0 anyways 
    // TBD : Since we cannot give accurate read data flits from reqrsp, we should remove this metric. 
    { VOLTA_NVLINK_TL_RX_READ_DATA_FLITS, volta_nvlink_tl_rx_read_data_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_FLITFILTER_DATA,
        GV100_NVLINK_RX_TOTAL_FLITS_READ, CUPROF_NVLINK_DATA_RECIEVE, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_NONE},

    // Should be 0. We have to use RESPONSEFILTERMODE as NONE.
    { VOLTA_NVLINK_TL_RX_WRITE_DATA_FLITS, volta_nvlink_tl_rx_write_data_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_FLITFILTER_DATA,
        GV100_NVLINK_RX_TOTAL_FLITS_WRITE, CUPROF_NVLINK_DATA_RECIEVE, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_NONE },

    // Should be 0. We have to use RESPONSEFILTERMODE as NONE.
    { VOLTA_NVLINK_TL_RX_RATOM_DATA_FLITS, volta_nvlink_tl_rx_ratom_data_flits_enc_str_1,  NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_FLITFILTER_DATA,
        GV100_NVLINK_RX_TOTAL_FLITS_RATOM, CUPROF_NVLINK_DATA_RECIEVE, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_NONE },

    // This should be 0 anyways.
    // TBD : Since we cannot give accurate read data flits from reqrsp, we should remove this metric. 
    { VOLTA_NVLINK_TL_RX_NRATOM_DATA_FLITS, volta_nvlink_tl_rx_nratom_data_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_FLITFILTER_DATA,
        GV100_NVLINK_RX_TOTAL_FLITS_NRATOM, CUPROF_NVLINK_DATA_RECIEVE, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_NONE },

    // This should be 0. We have to use RESPONSEFILTERMODE as NONE.
    { VOLTA_NVLINK_TL_RX_FLUSH_DATA_FLITS, volta_nvlink_tl_rx_flush_data_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_FLITFILTER_DATA,
        NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_REQ_FILTER_REQUESTFILTERMODE_FLUSH, CUPROF_NVLINK_DATA_RECIEVE, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_NONE },

    { VOLTA_NVLINK_TL_RX_RESPD_DATA_FLITS, volta_nvlink_tl_rx_respd_data_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_FLITFILTER_DATA,
        NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_REQ_FILTER_REQUESTFILTERMODE_NONE, CUPROF_NVLINK_DATA_RECIEVE, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_INIT },

    { VOLTA_NVLINK_TL_RX_IDLE_FLITS, volta_nvlink_tl_rx_idle_flits_enc_str_1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT_FLITS, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_FLITFILTER_IDLE,
        NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_REQ_FILTER_REQUESTFILTERMODE_INIT, CUPROF_NVLINK_DATA_RECIEVE, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE_INIT },

    { INVALID_PM_SIGNAL_NEW,        "",   CUPROF_NVLINK_INVALID, 0xff, 0xff, CUPROF_NVLINK_DATA_INVALID, 0xff }
};
#endif /* #if NVCFG(GLOBAL_ARCH_VOLTA) */

#if NVCFG(GLOBAL_ARCH_VOLTA)
PerfSignalSmpc PerfSignalTableGV100_sm0[] = { 
    //SMPC coreMio signal start
    { VOLTA_SM_ACTIVE_CYCLES, volta_sm_active_cycles_enc_str_1, 0x00000000, 0x00000000, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "active_cycles"
    { VOLTA_SM_ACTIVE_CYCLES_UNFILTERED, volta_sm_active_cycles_unfiltered_enc_str_1, 0x00000000, 0x00000000, 0x00000001, PM_UNIT_SMCORE,  1}, // "active_cycles_unfiltered"
    { VOLTA_SM_ACTIVE_WARPS, volta_sm_active_warps_enc_str_1, 0x00000000, 0x00654321, 0x0000003f, PM_UNIT_SMCORE,  6, VOLTA_SM_SM_NOT_IN_TRAP}, // "active_warps"
    { VOLTA_SM_GROUP0_PLACEHOLDER, volta_sm_group0_placeholder_enc_str_1, 0x00000000, 0x00000007, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "group0_placeholder"
    { VOLTA_SM_ACTIVE_CTAS, volta_sm_active_ctas_enc_str_1, 0x00000001, 0x00543210, 0x0000003f, PM_UNIT_SMCORE,  6, VOLTA_SM_SM_NOT_IN_TRAP}, // "active_ctas"
    { VOLTA_SM_CTAS_LAUNCHED, volta_sm_ctas_launched_enc_str_1, 0x00000001, 0x00000006, 0x00000001, PM_UNIT_SMCORE,  1}, // "ctas_launched_unfiltered"
    { VOLTA_SM_CTAS_RESTORED, volta_sm_ctas_restored_enc_str_1, 0x00000001, 0x00000007, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "ctas_restored"
    { VOLTA_SM_ACTIVE_WARPS_PS, volta_sm_active_warps_ps_enc_str_1, 0x00000002, 0x00543210, 0x0000003f, PM_UNIT_SMCORE,  6, VOLTA_SM_SM_NOT_IN_TRAP}, // "active_warps_ps"
    { VOLTA_SM_WARPS_EARLY_EXIT_ALL_PIXELS_KILLED, volta_sm_warps_early_exit_all_pixels_killed_enc_str_1, 0x00000002, 0x00000006, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "warps_early_exit_all_pixels_killed"
    { VOLTA_SM_YIELD_EXECUTED, volta_sm_yield_executed_enc_str_1, 0x00000002, 0x00000007, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "yield_executed"
    { VOLTA_SM_ACTIVE_WARPS_VTG, volta_sm_active_warps_vtg_enc_str_1, 0x00000003, 0x00543210, 0x0000003f, PM_UNIT_SMCORE,  6, VOLTA_SM_SM_NOT_IN_TRAP}, // "active_warps_vtg"
    { VOLTA_SM_PQ_STORE_FULL, volta_sm_pq_store_full_enc_str_1, 0x00000003, 0x00000006, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "pq_store_full"
    { VOLTA_SM_PQ_TEX_FULL, volta_sm_pq_tex_full_enc_str_1, 0x00000003, 0x00000007, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "pq_tex_full"
    { VOLTA_SM_ACTIVE_WARPS_CS, volta_sm_active_warps_cs_enc_str_1, 0x00000004, 0x00543210, 0x0000003f, PM_UNIT_SMCORE,  6, VOLTA_SM_SM_NOT_IN_TRAP}, // "active_warps_cs"
    { VOLTA_SM_GROUP4_PLACEHOLDER, volta_sm_group4_placeholder_enc_str_1, 0x00000004, 0x00000076, 0x00000003, PM_UNIT_SMCORE,  2, VOLTA_SM_SM_NOT_IN_TRAP}, // "group4_placeholder"
    { VOLTA_SM_ACTIVE_SUBTILES, volta_sm_active_subtiles_enc_str_1, 0x00000005, 0x00543210, 0x0000003f, PM_UNIT_SMCORE,  6, VOLTA_SM_SM_NOT_IN_TRAP}, // "active_subtiles"
    { VOLTA_SM_SUBTILES_LAUNCHED, volta_sm_subtiles_launched_enc_str_1, 0x00000005, 0x00000006, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "subtiles_launched"
    { VOLTA_SM_GROUP5_PLACEHOLDER, volta_sm_group5_placeholder_enc_str_1, 0x00000005, 0x00000007, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "group5_placeholder"
    { VOLTA_SM_ICC_HIT, volta_sm_icc_hit_enc_str_1, 0x00000006, 0x00000000, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "icc_hit"
    { VOLTA_SM_ICC_TRUE_MISS, volta_sm_icc_true_miss_enc_str_1, 0x00000006, 0x00000001, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "icc_true_miss"
    { VOLTA_SM_ICC_COVERED_MISS, volta_sm_icc_covered_miss_enc_str_1, 0x00000006, 0x00000002, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "icc_covered_miss"
    { VOLTA_SM_ICC_FULL_TAG_TPC, volta_sm_icc_full_tag_tpc_enc_str_1, 0x00000006, 0x00000003, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "icc_full_tag_tpc"
    { VOLTA_SM_ICC_PREFETCHES_TPC, volta_sm_icc_prefetches_tpc_enc_str_1, 0x00000006, 0x00000004, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "icc_prefetches_tpc"
    { VOLTA_SM_ICC_UNLOCK_ALL_TPC, volta_sm_icc_unlock_all_tpc_enc_str_1, 0x00000006, 0x00000005, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "icc_unlock_all_tpc"
    { VOLTA_SM_GROUP6_PLACEHOLDER, volta_sm_group6_placeholder_enc_str_1, 0x00000006, 0x00000076, 0x00000003, PM_UNIT_SMCORE,  2, VOLTA_SM_SM_NOT_IN_TRAP}, // "group6_placeholder"
    { VOLTA_SM_ICC_MISSES_OUTSTANDING_TPC, volta_sm_icc_misses_outstanding_tpc_enc_str_1, 0x00000007, 0x00003210, 0x0000000f, PM_UNIT_SMCORE,  4, VOLTA_SM_SM_NOT_IN_TRAP}, // "icc_misses_outstanding_tpc"
    { VOLTA_SM_IDC_INVALIDATES_EXPLICIT_TPC, volta_sm_idc_invalidates_explicit_tpc_enc_str_1, 0x00000007, 0x00000004, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "idc_invalidates_explicit_tpc"
    { VOLTA_SM_IDC_HIT, volta_sm_idc_hit_enc_str_1, 0x00000007, 0x00000005, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "idc_hit"
    { VOLTA_SM_IDC_TRUE_MISS, volta_sm_idc_true_miss_enc_str_1, 0x00000007, 0x00000006, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "idc_true_miss"
    { VOLTA_SM_IDC_COVERED_MISS, volta_sm_idc_covered_miss_enc_str_1, 0x00000007, 0x00000007, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "idc_covered_miss"
    { VOLTA_SM_GROUP8_PLACEHOLDER, volta_sm_group8_placeholder_enc_str_1, 0x00000008, 0x00000007, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "group8_placeholder"
    { VOLTA_SM_SCG_MODE_COMPUTE, volta_sm_scg_mode_compute_enc_str_1, 0x00000009, 0x00000000, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "scg_mode_compute"
    { VOLTA_SM_SCG_MODE_GRAPHICS, volta_sm_scg_mode_graphics_enc_str_1, 0x00000009, 0x00000001, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "scg_mode_graphics"
    { VOLTA_SM_SM_IN_TRAP, volta_sm_sm_in_trap_enc_str_1, 0x00000009, 0x00000002, 0x00000001, PM_UNIT_SMCORE,  1}, // "sm_in_trap"
    { VOLTA_SM_SM_NOT_IN_TRAP, volta_sm_sm_not_in_trap_enc_str_1, 0x00000009, 0x00000003, 0x00000001, PM_UNIT_SMCORE,  1}, // "sm_not_in_trap"
    { VOLTA_SM_MEMBAR_EXECUTED, volta_sm_membar_executed_enc_str_1, 0x00000009, 0x00000004, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "membar_executed"
    { VOLTA_SM_MEMBAR_PENDING_TPC, volta_sm_membar_pending_tpc_enc_str_1, 0x00000009, 0x00000005, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "membar_pending_tpc"
    { VOLTA_SM_MEMBAR_OUTSTANDING_TO_GNIC, volta_sm_membar_outstanding_to_gnic_enc_str_1, 0x00000009, 0x00000006, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "membar_outstanding_to_gnic"
    { VOLTA_SM_MEMBAR_SENT_TO_GNIC_TPC, volta_sm_membar_sent_to_gnic_tpc_enc_str_1, 0x00000009, 0x00000007, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "membar_sent_to_gnic_tpc"
    { VOLTA_SM_TRAP_IN_TRAP, volta_sm_trap_in_trap_enc_str_1, 0x0000000a, 0x00000000, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "trap_in_trap"
    { VOLTA_SM_TRAP_COUNT, volta_sm_trap_count_enc_str_1, 0x0000000a, 0x00000001, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "trap_count"
    { VOLTA_SM_TRAP_COALESCING, volta_sm_trap_coalescing_enc_str_1, 0x0000000a, 0x00000002, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "trap_coalescing"
    { VOLTA_SM_TRAP_IDLING_FOR_TRAP, volta_sm_trap_idling_for_trap_enc_str_1, 0x0000000a, 0x00000003, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "trap_idling_for_trap"
    { VOLTA_SM_TRAP_WAITING_FOR_IDE, volta_sm_trap_waiting_for_ide_enc_str_1, 0x0000000a, 0x00000004, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "trap_waiting_for_ide"
    { VOLTA_SM_BLOCKED_ON_BSYNC, volta_sm_blocked_on_bsync_enc_str_1, 0x0000000a, 0x00000005, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "blocked_on_bsync"
    { VOLTA_SM_CBU_CONVERGENT_IDX_BR_EXECUTED, volta_sm_cbu_convergent_idx_br_executed_enc_str_1, 0x0000000a, 0x00000006, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "cbu_convergent_idx_br_executed"
    { VOLTA_SM_CBU_DIVERGENT_IDX_BR_EXECUTED, volta_sm_cbu_divergent_idx_br_executed_enc_str_1, 0x0000000a, 0x00000007, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "cbu_divergent_idx_br_executed"
    { VOLTA_SM_CBU_ELECTION_JPC_OPT_STACK, volta_sm_cbu_election_jpc_opt_stack_enc_str_1, 0x0000000b, 0x00000000, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "cbu_election_jpc_opt_stack"
    { VOLTA_SM_CBU_ELECTION_JPC_RR, volta_sm_cbu_election_jpc_rr_enc_str_1, 0x0000000b, 0x00000001, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "cbu_election_jpc_rr"
    { VOLTA_SM_CBU_ELECTION_NO_JPC, volta_sm_cbu_election_no_jpc_enc_str_1, 0x0000000b, 0x00000002, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "cbu_election_no_jpc"
    { VOLTA_SM_CBU_JPC_ALL, volta_sm_cbu_jpc_all_enc_str_1, 0x0000000b, 0x00000003, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "cbu_jpc_all"
    { VOLTA_SM_CONVERGENT_BARRIER_ALIASED, volta_sm_convergent_barrier_aliased_enc_str_1, 0x0000000b, 0x00000004, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "convergent_barrier_aliased"
    { VOLTA_SM_CONVERGENT_BARRIER_RELEASED, volta_sm_convergent_barrier_released_enc_str_1, 0x0000000b, 0x00000005, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "convergent_barrier_released"
    { VOLTA_SM_CONVERGENT_BARRIER_RELEASED_ALIASED, volta_sm_convergent_barrier_released_aliased_enc_str_1, 0x0000000b, 0x00000006, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "convergent_barrier_released_aliased"
    { VOLTA_SM_WARP_ENTERS_SLEEP, volta_sm_warp_enters_sleep_enc_str_1, 0x0000000b, 0x00000007, 0x00000001, PM_UNIT_SMCORE,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "warp_enters_sleep"
    { VOLTA_SM_ADU_REPLAYS, volta_sm_adu_replays_enc_str_1, 0x0000000c, 0x00000000, 0x00000001, PM_UNIT_MIO,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "adu_replays"
    { VOLTA_SM_GROUP12_PLACEHOLDER, volta_sm_group12_placeholder_enc_str_1, 0x0000000c, 0x07654321, 0x0000007f, PM_UNIT_MIO,  7, VOLTA_SM_SM_NOT_IN_TRAP}, // "group12_placeholder"
    { VOLTA_SM_PQ_STORE_READS, volta_sm_pq_store_reads_enc_str_1, 0x0000000d, 0x00000000, 0x00000001, PM_UNIT_MIO,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "pq_store_reads"
    { VOLTA_SM_PQ_STORE_READS_FOR_PIXOUT, volta_sm_pq_store_reads_for_pixout_enc_str_1, 0x0000000d, 0x00000001, 0x00000001, PM_UNIT_MIO,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "pq_store_reads_for_pixout"
    { VOLTA_SM_PQ_STORE_WRITES, volta_sm_pq_store_writes_enc_str_1, 0x0000000d, 0x00000002, 0x00000001, PM_UNIT_MIO,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "pq_store_writes"
    { VOLTA_SM_PQ_TEX_READS_FOR_TEX, volta_sm_pq_tex_reads_for_tex_enc_str_1, 0x0000000d, 0x00000003, 0x00000001, PM_UNIT_MIO,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "pq_tex_reads_for_tex"
    { VOLTA_SM_PQ_TEX_READS_FOR_ADU, volta_sm_pq_tex_reads_for_adu_enc_str_1, 0x0000000d, 0x00000004, 0x00000001, PM_UNIT_MIO,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "pq_tex_reads_for_adu"
    { VOLTA_SM_MIO_SM_STALLED_DUE_TO_PE, volta_sm_mio_sm_stalled_due_to_pe_enc_str_1, 0x0000000d, 0x00000005, 0x00000001, PM_UNIT_MIO,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "mio_sm_stalled_due_to_pe"
    { VOLTA_SM_MIO_DATAPATH_ACTIVE, volta_sm_mio_datapath_active_enc_str_1, 0x0000000d, 0x00000006, 0x00000001, PM_UNIT_MIO,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "mio_datapath_active"
    { VOLTA_SM_GROUP13_PLACEHOLDER, volta_sm_group13_placeholder_enc_str_1, 0x0000000d, 0x00000007, 0x00000001, PM_UNIT_MIO,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "group13_placeholder"
    { VOLTA_SM_IDC_DIVERGENCE_REPLAY, volta_sm_idc_divergence_replay_enc_str_1, 0x0000000e, 0x00000000, 0x00000001, PM_UNIT_MIO,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "idc_divergence_replay"
    { VOLTA_SM_IDC_DIVERGENT_INSTRUCTION, volta_sm_idc_divergent_instruction_enc_str_1, 0x0000000e, 0x00000001, 0x00000001, PM_UNIT_MIO,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "idc_divergent_instruction"
    { VOLTA_SM_GROUP14_PLACEHOLDER, volta_sm_group14_placeholder_enc_str_1, 0x0000000e, 0x00765432, 0x0000003f, PM_UNIT_MIO,  6, VOLTA_SM_SM_NOT_IN_TRAP}, // "group14_placeholder"
    { VOLTA_SM_PIXOUT_QUADS_DRAINED, volta_sm_pixout_quads_drained_enc_str_1, 0x0000000f, 0x00000010, 0x00000003, PM_UNIT_MIO,  2, VOLTA_SM_SM_NOT_IN_TRAP}, // "pixout_quads_drained"
    { VOLTA_SM_HALF_WARPS_KILLED_BY_SHADER, volta_sm_half_warps_killed_by_shader_enc_str_1, 0x0000000f, 0x00000032, 0x00000003, PM_UNIT_MIO,  2, VOLTA_SM_SM_NOT_IN_TRAP}, // "half_warps_killed_by_shader"
    { VOLTA_SM_QUADS_KILLED_BY_SHADER, volta_sm_quads_killed_by_shader_enc_str_1, 0x0000000f, 0x00007654, 0x0000000f, PM_UNIT_MIO,  4, VOLTA_SM_SM_NOT_IN_TRAP}, // "quads_killed_by_shader"
    { VOLTA_SM_WARPS_KILLED_BY_SHADER, volta_sm_warps_killed_by_shader_enc_str_1, 0x00000010, 0x00000000, 0x00000001, PM_UNIT_MIO,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "warps_killed_by_shader"
    { VOLTA_SM_PIXELS_KILLED_SHADERCOVG, volta_sm_pixels_killed_shadercovg_enc_str_1, 0x00000010, 0x00654321, 0x0000003f, PM_UNIT_MIO,  6, VOLTA_SM_SM_NOT_IN_TRAP}, // "pixels_killed_shadercovg"
    { VOLTA_SM_SM2GPM_OUTPUT_STALL, volta_sm_sm2gpm_output_stall_enc_str_1, 0x00000010, 0x00000007, 0x00000001, PM_UNIT_MIO,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "sm2gpm_output_stall"
    { VOLTA_SM_MIO_ISBE_READ, volta_sm_mio_isbe_read_enc_str_1, 0x00000011, 0x00000000, 0x00000001, PM_UNIT_MIO,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "mio_isbe_read"
    { VOLTA_SM_MIO_ISBE_WRITE, volta_sm_mio_isbe_write_enc_str_1, 0x00000011, 0x00000001, 0x00000001, PM_UNIT_MIO,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "mio_isbe_write"
    { VOLTA_SM_GROUP17_PLACEHOLDER, volta_sm_group17_placeholder_enc_str_1, 0x00000011, 0x00765432, 0x0000003f, PM_UNIT_MIO,  6, VOLTA_SM_SM_NOT_IN_TRAP}, // "group17_placeholder"
    { VOLTA_SM_PE2MIO_ISBE_READ_REQ, volta_sm_pe2mio_isbe_read_req_enc_str_1, 0x00000012, 0x00000000, 0x00000001, PM_UNIT_MIO,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "pe2mio_isbe_read_req"
    { VOLTA_SM_PE2MIO_ISBE_WRITE_REQ, volta_sm_pe2mio_isbe_write_req_enc_str_1, 0x00000012, 0x00000001, 0x00000001, PM_UNIT_MIO,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "pe2mio_isbe_write_req"
    { VOLTA_SM_PE2MIO_TRAM_WRITE, volta_sm_pe2mio_tram_write_enc_str_1, 0x00000012, 0x00000002, 0x00000001, PM_UNIT_MIO,  1, VOLTA_SM_SM_NOT_IN_TRAP}, // "pe2mio_tram_write"
    { VOLTA_SM_GROUP18_PLACEHOLDER, volta_sm_group18_placeholder_enc_str_1, 0x00000012, 0x00076543, 0x0000001f, PM_UNIT_MIO,  5, VOLTA_SM_SM_NOT_IN_TRAP}, // "group18_placeholder"
    { VOLTA_SM_GROUP19_PLACEHOLDER, volta_sm_group19_placeholder_enc_str_1, 0x00000013, 0x00043210, 0x0000001f, PM_UNIT_MIO,  5, VOLTA_SM_SM_NOT_IN_TRAP}, // "group19_placeholder"
    { VOLTA_SM_GROUP20_PLACEHOLDER, volta_sm_group20_placeholder_enc_str_1, 0x00000014, 0x76543210, 0x000000ff, PM_UNIT_MIO,  8, VOLTA_SM_SM_NOT_IN_TRAP}, // "group20_placeholder"
    { VOLTA_SM_GROUP21_PLACEHOLDER, volta_sm_group21_placeholder_enc_str_1, 0x00000015, 0x76543210, 0x000000ff, PM_UNIT_MIO,  8, VOLTA_SM_SM_NOT_IN_TRAP}, // "group21_placeholder"
    { VOLTA_SM_GROUP22_PLACEHOLDER, volta_sm_group22_placeholder_enc_str_1, 0x00000016, 0x76543210, 0x000000ff, PM_UNIT_MIO,  8, VOLTA_SM_SM_NOT_IN_TRAP}, // "group22_placeholder"
    { VOLTA_SM_GROUP23_PLACEHOLDER, volta_sm_group23_placeholder_enc_str_1, 0x00000017, 0x76543210, 0x000000ff, PM_UNIT_MIO,  8, VOLTA_SM_SM_NOT_IN_TRAP}, // "group23_placeholder"
    { VOLTA_SM_GROUP24_PLACEHOLDER, volta_sm_group24_placeholder_enc_str_1, 0x00000018, 0x76543210, 0x000000ff, PM_UNIT_MIO,  8, VOLTA_SM_SM_NOT_IN_TRAP}, // "group24_placeholder"
    { VOLTA_SM_GROUP25_PLACEHOLDER, volta_sm_group25_placeholder_enc_str_1, 0x00000019, 0x76543210, 0x000000ff, PM_UNIT_MIO,  8, VOLTA_SM_SM_NOT_IN_TRAP}, // "group25_placeholder"
    { VOLTA_SM_CORE_HW_PM_MUX_LOWER, volta_sm_core_hw_pm_mux_lower_enc_str_1, 0x0000001c, 0x76543210, 0x000000ff, PM_UNIT_SMCORE,  8, VOLTA_SM_SM_NOT_IN_TRAP}, // "core_hw_pm_mux_lower"
    { VOLTA_SM_CORE_HW_PM_MUX_UPPER, volta_sm_core_hw_pm_mux_upper_enc_str_1, 0x0000001d, 0x76543210, 0x000000ff, PM_UNIT_SMCORE,  8, VOLTA_SM_SM_NOT_IN_TRAP}, // "core_hw_pm_mux_upper"
    { VOLTA_SM_MIO_HW_PM_MUX_LOWER, volta_sm_mio_hw_pm_mux_lower_enc_str_1, 0x0000001e, 0x76543210, 0x000000ff, PM_UNIT_MIO,  8, VOLTA_SM_SM_NOT_IN_TRAP}, // "mio_hw_pm_mux_lower"
    { VOLTA_SM_MIO_HW_PM_MUX_UPPER, volta_sm_mio_hw_pm_mux_upper_enc_str_1, 0x0000001f, 0x76543210, 0x000000ff, PM_UNIT_MIO,  8, VOLTA_SM_SM_NOT_IN_TRAP}, // "mio_hw_pm_mux_upper"
    //SMPC coreMio signal end

    //SMPC sctl signal start
    { VOLTA_SM_PMTRIG0, volta_sm_pmtrig0_enc_str_1, 0x00000000, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "pmtrig0"
    { VOLTA_SM_PMTRIG1, volta_sm_pmtrig1_enc_str_1, 0x00000000, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "pmtrig1"
    { VOLTA_SM_PMTRIG2, volta_sm_pmtrig2_enc_str_1, 0x00000000, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "pmtrig2"
    { VOLTA_SM_PMTRIG3, volta_sm_pmtrig3_enc_str_1, 0x00000000, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "pmtrig3"
    { VOLTA_SM_PMTRIG4, volta_sm_pmtrig4_enc_str_1, 0x00000000, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "pmtrig4"
    { VOLTA_SM_PMTRIG5, volta_sm_pmtrig5_enc_str_1, 0x00000000, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "pmtrig5"
    { VOLTA_SM_PMTRIG6, volta_sm_pmtrig6_enc_str_1, 0x00000000, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "pmtrig6"
    { VOLTA_SM_PMTRIG7, volta_sm_pmtrig7_enc_str_1, 0x00000000, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "pmtrig7"
    { VOLTA_SM_PMTRIG8, volta_sm_pmtrig8_enc_str_1, 0x00000001, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "pmtrig8"
    { VOLTA_SM_PMTRIG9, volta_sm_pmtrig9_enc_str_1, 0x00000001, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "pmtrig9"
    { VOLTA_SM_PMTRIG10, volta_sm_pmtrig10_enc_str_1, 0x00000001, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "pmtrig10"
    { VOLTA_SM_PMTRIG11, volta_sm_pmtrig11_enc_str_1, 0x00000001, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "pmtrig11"
    { VOLTA_SM_PMTRIG12, volta_sm_pmtrig12_enc_str_1, 0x00000001, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "pmtrig12"
    { VOLTA_SM_PMTRIG13, volta_sm_pmtrig13_enc_str_1, 0x00000001, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "pmtrig13"
    { VOLTA_SM_PMTRIG14, volta_sm_pmtrig14_enc_str_1, 0x00000001, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "pmtrig14"
    { VOLTA_SM_PMTRIG15, volta_sm_pmtrig15_enc_str_1, 0x00000001, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "pmtrig15"
    { VOLTA_SM_ACTIVE_WARPS_QUAD, volta_sm_active_warps_quad_enc_str_1, 0x00000002, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "active_warps"
    { VOLTA_SM_ACTIVE_CYCLES_QUAD, volta_sm_active_cycles_quad_enc_str_1, 0x00000002, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "active_cycles"
    { VOLTA_SM_WARPS_LAUNCHED, volta_sm_warps_launched_enc_str_1, 0x00000002, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, // "warps_launched_unfiltered"
    { VOLTA_SM_WARPS_RESTORED, volta_sm_warps_restored_enc_str_1, 0x00000002, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "warps_restored"
    { VOLTA_SM_INST_NOT_ISSUED, volta_sm_inst_not_issued_enc_str_1, 0x00000003, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_not_issued"
    { VOLTA_SM_INST_ISSUED, volta_sm_inst_issued_enc_str_1, 0x00000003, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_issued"
    { VOLTA_SM_INST_EXECUTED, volta_sm_inst_executed_enc_str_1, 0x00000003, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed"
    { VOLTA_SM_INST_ROLLBACKED, volta_sm_inst_rollbacked_enc_str_1, 0x00000003, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_rollbacked"
    { VOLTA_SM_SCG_MODE_COMPUTE_QUAD, volta_sm_scg_mode_compute_quad_enc_str_1, 0x00000003, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "scg_mode_compute"
    { VOLTA_SM_SCG_MODE_GRAPHICS_QUAD, volta_sm_scg_mode_graphics_quad_enc_str_1, 0x00000003, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "scg_mode_graphics"
    { VOLTA_SM_SM_IN_TRAP_QUAD, volta_sm_sm_in_trap_quad_enc_str_1, 0x00000003, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1}, // "sm_in_trap"
    { VOLTA_SM_SM_NOT_IN_TRAP_QUAD, volta_sm_sm_not_in_trap_quad_enc_str_1, 0x00000003, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1}, // "sm_not_in_trap"
    { VOLTA_SM_THREAD_INST_EXECUTED, volta_sm_thread_inst_executed_enc_str_1, 0x00000004, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL,  6, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "thread_inst_executed"
    { VOLTA_SM_WARP_CANT_ISSUE_SELECTED, volta_sm_warp_cant_issue_selected_enc_str_1, 0x00000004, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "warp_cant_issue_selected"
    { VOLTA_SM_WARP_CANT_ISSUE_INST_NOT_ISSUED, volta_sm_warp_cant_issue_inst_not_issued_enc_str_1, 0x00000004, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "warp_cant_issue_inst_not_issued"
    { VOLTA_SM_NOT_PREDICATED_OFF_THREAD_INST_EXECUTED, volta_sm_not_predicated_off_thread_inst_executed_enc_str_1, 0x00000005, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL,  6, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "not_predicated_off_thread_inst_executed"
    { VOLTA_SM_ROLLBACKS_IMC, volta_sm_rollbacks_imc_enc_str_1, 0x00000005, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "rollbacks_imc"
    { VOLTA_SM_ROLLBACKS_PREDICATED_BRANCH_NOT_FALLTHROUGH, volta_sm_rollbacks_predicated_branch_not_fallthrough_enc_str_1, 0x00000005, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "rollbacks_predicated_branch_not_fallthrough"
    { VOLTA_SM_WARP_CANT_ISSUE_BARRIER, volta_sm_warp_cant_issue_barrier_enc_str_1, 0x00000006, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "warp_cant_issue_barrier"
    { VOLTA_SM_INST_EXECUTED_DECOUPLED_PRED_OFF, volta_sm_inst_executed_decoupled_pred_off_enc_str_1, 0x00000006, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_decoupled_pred_off"
    { VOLTA_SM_BARRIER_EXECUTED, volta_sm_barrier_executed_enc_str_1, 0x00000006, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "barrier_executed"
    { VOLTA_SM_BSYNC_EXECUTED, volta_sm_bsync_executed_enc_str_1, 0x00000006, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "bsync_executed"
    { VOLTA_SM_WARP_CANT_ISSUE_BRANCH_RESOLVING, volta_sm_warp_cant_issue_branch_resolving_enc_str_1, 0x00000007, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "warp_cant_issue_branch_resolving"
    { VOLTA_SM_INST_EXECUTED_ATTRIBUTE_LD, volta_sm_inst_executed_attribute_ld_enc_str_1, 0x00000007, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_attribute_ld"
    { VOLTA_SM_INST_EXECUTED_ATTRIBUTE_ST, volta_sm_inst_executed_attribute_st_enc_str_1, 0x00000007, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_attribute_st"
    { VOLTA_SM_INST_EXECUTED_TEX_OPS, volta_sm_inst_executed_tex_ops_enc_str_1, 0x00000007, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_tex_ops"
    { VOLTA_SM_WARP_CANT_ISSUE_DISPATCH_STALL, volta_sm_warp_cant_issue_dispatch_stall_enc_str_1, 0x00000008, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "warp_cant_issue_dispatch_stall"
    { VOLTA_SM_INST_EXECUTED_GENERIC_LD, volta_sm_inst_executed_generic_ld_enc_str_1, 0x00000008, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_generic_ld"
    { VOLTA_SM_INST_EXECUTED_GENERIC_ST, volta_sm_inst_executed_generic_st_enc_str_1, 0x00000008, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_generic_st"
    { VOLTA_SM_NANOSLEEP_EXECUTED, volta_sm_nanosleep_executed_enc_str_1, 0x00000008, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "nanosleep_executed"
    { VOLTA_SM_WARP_CANT_ISSUE_DRAIN, volta_sm_warp_cant_issue_drain_enc_str_1, 0x00000009, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "warp_cant_issue_drain"
    { VOLTA_SM_INST_EXECUTED_GLOBAL_ATOM, volta_sm_inst_executed_global_atom_enc_str_1, 0x00000009, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_global_atom"
    { VOLTA_SM_INST_EXECUTED_GLOBAL_ATOM_ADD_F64B, volta_sm_inst_executed_global_atom_add_f64b_enc_str_1, 0x00000009, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_global_atom_add_f64b"
    { VOLTA_SM_INST_EXECUTED_GLOBAL_ATOM_CAS, volta_sm_inst_executed_global_atom_cas_enc_str_1, 0x00000009, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_global_atom_cas"
    { VOLTA_SM_WARP_CANT_ISSUE_IMC_MISS, volta_sm_warp_cant_issue_imc_miss_enc_str_1, 0x0000000a, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "warp_cant_issue_imc_miss"
    { VOLTA_SM_INST_EXECUTED_GLOBAL_RED, volta_sm_inst_executed_global_red_enc_str_1, 0x0000000a, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_global_red"
    { VOLTA_SM_INST_EXECUTED_GLOBAL_RED_ADD_F64B, volta_sm_inst_executed_global_red_add_f64b_enc_str_1, 0x0000000a, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_global_red_add_f64b"
    { VOLTA_SM_MIO_SM_STALLED_DUE_TO_PE_QUAD, volta_sm_mio_sm_stalled_due_to_pe_quad_enc_str_1, 0x0000000a, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "mio_sm_stalled_due_to_pe"
    { VOLTA_SM_WARP_CANT_ISSUE_LONG_SCOREBOARD, volta_sm_warp_cant_issue_long_scoreboard_enc_str_1, 0x0000000b, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "warp_cant_issue_long_scoreboard"
    { VOLTA_SM_INST_EXECUTED_GLOBAL_LD, volta_sm_inst_executed_global_ld_enc_str_1, 0x0000000b, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_global_ld"
    { VOLTA_SM_INST_EXECUTED_GLOBAL_ST, volta_sm_inst_executed_global_st_enc_str_1, 0x0000000b, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_global_st"
    { VOLTA_SM_INST_EXECUTED_LG_OPS, volta_sm_inst_executed_lg_ops_enc_str_1, 0x0000000b, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_lg_ops"
    { VOLTA_SM_WARP_CANT_ISSUE_MEMBAR, volta_sm_warp_cant_issue_membar_enc_str_1, 0x0000000c, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "warp_cant_issue_membar"
    { VOLTA_SM_INST_EXECUTED_LOCAL_LD, volta_sm_inst_executed_local_ld_enc_str_1, 0x0000000c, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_local_ld"
    { VOLTA_SM_INST_EXECUTED_LOCAL_ST, volta_sm_inst_executed_local_st_enc_str_1, 0x0000000c, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_local_st"
    { VOLTA_SM_MEMBAR_EXECUTED_QUAD, volta_sm_membar_executed_quad_enc_str_1, 0x0000000c, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "membar_executed"
    { VOLTA_SM_WARP_CANT_ISSUE_MIO_THROTTLE, volta_sm_warp_cant_issue_mio_throttle_enc_str_1, 0x0000000d, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "warp_cant_issue_mio_throttle"
    { VOLTA_SM_INST_EXECUTED_SHARED_ATOM, volta_sm_inst_executed_shared_atom_enc_str_1, 0x0000000d, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_shared_atom"
    { VOLTA_SM_INST_EXECUTED_SHARED_ATOM_CAS, volta_sm_inst_executed_shared_atom_cas_enc_str_1, 0x0000000d, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_shared_atom_cas"
    { VOLTA_SM_INST_EXECUTED_LDC_OPS, volta_sm_inst_executed_ldc_ops_enc_str_1, 0x0000000d, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_ldc_ops"
    { VOLTA_SM_WARP_CANT_ISSUE_MISC, volta_sm_warp_cant_issue_misc_enc_str_1, 0x0000000e, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "warp_cant_issue_misc"
    { VOLTA_SM_INST_EXECUTED_SHARED_LD, volta_sm_inst_executed_shared_ld_enc_str_1, 0x0000000e, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_shared_ld"
    { VOLTA_SM_INST_EXECUTED_SHARED_ST, volta_sm_inst_executed_shared_st_enc_str_1, 0x0000000e, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_shared_st"
    { VOLTA_SM_NON_IDLE, volta_sm_non_idle_enc_str_1, 0x0000000e, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "non_idle"
    { VOLTA_SM_WARP_CANT_ISSUE_NO_INSTRUCTIONS, volta_sm_warp_cant_issue_no_instructions_enc_str_1, 0x0000000f, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "warp_cant_issue_no_instructions"
    { VOLTA_SM_INST_EXECUTED_SURFACE_ATOM, volta_sm_inst_executed_surface_atom_enc_str_1, 0x0000000f, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_surface_atom"
    { VOLTA_SM_INST_EXECUTED_SURFACE_ATOM_CAS, volta_sm_inst_executed_surface_atom_cas_enc_str_1, 0x0000000f, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_surface_atom_cas"
    { VOLTA_SM_INST_EXECUTED_SURFACE_RED, volta_sm_inst_executed_surface_red_enc_str_1, 0x0000000f, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_surface_red"
    { VOLTA_SM_WARP_CANT_ISSUE_NOT_SELECTED, volta_sm_warp_cant_issue_not_selected_enc_str_1, 0x00000010, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "warp_cant_issue_not_selected"
    { VOLTA_SM_INST_EXECUTED_SURFACE_LD, volta_sm_inst_executed_surface_ld_enc_str_1, 0x00000010, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_surface_ld"
    { VOLTA_SM_INST_EXECUTED_SURFACE_ST, volta_sm_inst_executed_surface_st_enc_str_1, 0x00000010, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_surface_st"
    { VOLTA_SM_ADU_REPLAYS_QUAD, volta_sm_adu_replays_quad_enc_str_1, 0x00000010, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "adu_replays"
    { VOLTA_SM_WARP_CANT_ISSUE_SHADOW_PIPE_THROTTLE, volta_sm_warp_cant_issue_shadow_pipe_throttle_enc_str_1, 0x00000011, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "warp_cant_issue_shadow_pipe_throttle"
    { VOLTA_SM_INST_ISSUED_FROM_B2B, volta_sm_inst_issued_from_b2b_enc_str_1, 0x00000011, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_issued_from_b2b"
    { VOLTA_SM_HALF_WARP_COLLAPSED_ALU_PIPE, volta_sm_half_warp_collapsed_alu_pipe_enc_str_1, 0x00000011, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "half_warp_collapsed_alu_pipe"
    { VOLTA_SM_HALF_WARP_COLLAPSED_FMA_PIPE, volta_sm_half_warp_collapsed_fma_pipe_enc_str_1, 0x00000011, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "half_warp_collapsed_fma_pipe"
    { VOLTA_SM_WARP_CANT_ISSUE_SHORT_SCOREBOARD, volta_sm_warp_cant_issue_short_scoreboard_enc_str_1, 0x00000012, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "warp_cant_issue_short_scoreboard"
    { VOLTA_SM_TEX_WRITE_BACK, volta_sm_tex_write_back_enc_str_1, 0x00000012, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "tex_write_back"
    { VOLTA_SM_LSU_WRITE_BACK, volta_sm_lsu_write_back_enc_str_1, 0x00000012, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "lsu_write_back"
    { VOLTA_SM_ADU_WRITE_BACK, volta_sm_adu_write_back_enc_str_1, 0x00000012, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "adu_write_back"
    { VOLTA_SM_WARP_CANT_ISSUE_SLEEPING, volta_sm_warp_cant_issue_sleeping_enc_str_1, 0x00000013, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "warp_cant_issue_sleeping"
    { VOLTA_SM_WARP_CANT_ISSUE_TEX_THROTTLE, volta_sm_warp_cant_issue_tex_throttle_enc_str_1, 0x00000014, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "warp_cant_issue_tex_throttle"
    { VOLTA_SM_TEX_REQUESTS, volta_sm_tex_requests_enc_str_1, 0x00000014, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "tex_requests"
    { VOLTA_SM_TEX_QUAD_FETCH_REQUESTS, volta_sm_tex_quad_fetch_requests_enc_str_1, 0x00000014, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "tex_quad_fetch_requests"
    { VOLTA_SM_TEX_FETCHES, volta_sm_tex_fetches_enc_str_1, 0x00000014, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "tex_fetches"
    { VOLTA_SM_WARP_CANT_ISSUE_WAIT, volta_sm_warp_cant_issue_wait_enc_str_1, 0x00000015, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "warp_cant_issue_wait"
    { VOLTA_SM_WARP_ISSUE_ELIGIBLE, volta_sm_warp_issue_eligible_enc_str_1, 0x00000016, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "warp_issue_eligible"
    { VOLTA_SM_WARP_CANT_ISSUE_LG_THROTTLE, volta_sm_warp_cant_issue_lg_throttle_enc_str_1, 0x00000017, 0x00043210, 0x0000001f, PM_UNIT_SMQCTL,  5, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "warp_cant_issue_lg_throttle"
    { VOLTA_SM_INST_EXECUTED_BRANCH_OPS, volta_sm_inst_executed_branch_ops_enc_str_1, 0x00000018, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_branch_ops"
    { VOLTA_SM_TAKEN_BR_EXECUTED, volta_sm_taken_br_executed_enc_str_1, 0x00000018, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "taken_br_executed"
    { VOLTA_SM_PRED_DIVERGENT_BR_EXECUTED, volta_sm_pred_divergent_br_executed_enc_str_1, 0x00000018, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "pred_divergent_br_executed"
    { VOLTA_SM_FALLTHROUGH_BR_EXECUTED, volta_sm_fallthrough_br_executed_enc_str_1, 0x00000018, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "fallthrough_br_executed"
    { VOLTA_SM_INST_EXECUTED_CS, volta_sm_inst_executed_cs_enc_str_1, 0x00000019, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_cs"
    { VOLTA_SM_INST_EXECUTED_GS, volta_sm_inst_executed_gs_enc_str_1, 0x00000019, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_gs"
    { VOLTA_SM_INST_EXECUTED_PS, volta_sm_inst_executed_ps_enc_str_1, 0x00000019, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_ps"
    { VOLTA_SM_INST_EXECUTED_TCS, volta_sm_inst_executed_tcs_enc_str_1, 0x00000019, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_tcs"
    { VOLTA_SM_INST_EXECUTED_TES, volta_sm_inst_executed_tes_enc_str_1, 0x00000019, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_tes"
    { VOLTA_SM_INST_EXECUTED_VS, volta_sm_inst_executed_vs_enc_str_1, 0x00000019, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_vs"
    { VOLTA_SM_INST_EXECUTED_VSA, volta_sm_inst_executed_vsa_enc_str_1, 0x00000019, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_vsa"
    { VOLTA_SM_INST_EXECUTED_VSB, volta_sm_inst_executed_vsb_enc_str_1, 0x00000019, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_vsb"
    { VOLTA_SM_INST_EXECUTED_128B, volta_sm_inst_executed_128b_enc_str_1, 0x0000001a, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_128b"
    { VOLTA_SM_INST_EXECUTED_32B, volta_sm_inst_executed_32b_enc_str_1, 0x0000001a, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_32b"
    { VOLTA_SM_INST_EXECUTED_64B, volta_sm_inst_executed_64b_enc_str_1, 0x0000001a, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_64b"
    { VOLTA_SM_INST_EXECUTED_U128B, volta_sm_inst_executed_u128b_enc_str_1, 0x0000001a, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_U128b"
    { VOLTA_SM_INST_EXECUTED_ADU_PIPE, volta_sm_inst_executed_adu_pipe_enc_str_1, 0x0000001b, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_adu_pipe"
    { VOLTA_SM_INST_EXECUTED_ALU_PIPE, volta_sm_inst_executed_alu_pipe_enc_str_1, 0x0000001b, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_alu_pipe"
    { VOLTA_SM_INST_EXECUTED_BAR_OPS, volta_sm_inst_executed_bar_ops_enc_str_1, 0x0000001b, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_bar_ops"
    { VOLTA_SM_INST_EXECUTED_CBU_PIPE, volta_sm_inst_executed_cbu_pipe_enc_str_1, 0x0000001b, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_cbu_pipe"
    { VOLTA_SM_INST_EXECUTED_FE_PIPE, volta_sm_inst_executed_fe_pipe_enc_str_1, 0x0000001b, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_fe_pipe"
    { VOLTA_SM_INST_EXECUTED_FMA_PIPE, volta_sm_inst_executed_fma_pipe_enc_str_1, 0x0000001c, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_fma_pipe"
    { VOLTA_SM_INST_EXECUTED_FMA64LITE_PIPE, volta_sm_inst_executed_fma64lite_pipe_enc_str_1, 0x0000001c, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_fma64lite_pipe"
    { VOLTA_SM_INST_EXECUTED_FMA64PLUS_PIPE, volta_sm_inst_executed_fma64plus_pipe_enc_str_1, 0x0000001c, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_fma64plus_pipe"
    { VOLTA_SM_INST_EXECUTED_FP16ULTRA_PIPE, volta_sm_inst_executed_fp16ultra_pipe_enc_str_1, 0x0000001c, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_fp16ultra_pipe"
    { VOLTA_SM_INST_EXECUTED_IPA_PIPE, volta_sm_inst_executed_ipa_pipe_enc_str_1, 0x0000001c, 0x00000004, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_ipa_pipe"
    { VOLTA_SM_INST_EXECUTED_LSU_PIPE, volta_sm_inst_executed_lsu_pipe_enc_str_1, 0x0000001c, 0x00000005, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_lsu_pipe"
    { VOLTA_SM_INST_EXECUTED_TEX_PIPE, volta_sm_inst_executed_tex_pipe_enc_str_1, 0x0000001c, 0x00000006, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_tex_pipe"
    { VOLTA_SM_INST_EXECUTED_XU_PIPE, volta_sm_inst_executed_xu_pipe_enc_str_1, 0x0000001c, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "inst_executed_xu_pipe"
    { VOLTA_SM_IMC_HIT, volta_sm_imc_hit_enc_str_1, 0x0000001d, 0x00000000, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "imc_hit"
    { VOLTA_SM_IMC_FULL_TAG, volta_sm_imc_full_tag_enc_str_1, 0x0000001d, 0x00000001, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "imc_full_tag"
    { VOLTA_SM_IMC_TRUE_MISS, volta_sm_imc_true_miss_enc_str_1, 0x0000001d, 0x00000002, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "imc_true_miss"
    { VOLTA_SM_IMC_COVERED_MISS, volta_sm_imc_covered_miss_enc_str_1, 0x0000001d, 0x00000003, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "imc_covered_miss"
    { VOLTA_SM_IMC_MISSES_OUTSTANDING, volta_sm_imc_misses_outstanding_enc_str_1, 0x0000001d, 0x00000654, 0x00000007, PM_UNIT_SMQCTL,  3, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "imc_misses_outstanding"
    { VOLTA_SM_IMC_INVALIDATES_EXPLICIT, volta_sm_imc_invalidates_explicit_enc_str_1, 0x0000001d, 0x00000007, 0x00000001, PM_UNIT_SMQCTL,  1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "imc_invalidates_explicit"
    { VOLTA_SM_SCTL_HW_PM_MUX_LOWER, volta_sm_sctl_hw_pm_mux_lower_enc_str_1, 0x0000001e, 0x76543210, 0x000000ff, PM_UNIT_SMQCTL,  8, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "sctl_hw_pm_mux_lower"
    { VOLTA_SM_SCTL_HW_PM_MUX_UPPER, volta_sm_sctl_hw_pm_mux_upper_enc_str_1, 0x0000001f, 0x76543210, 0x000000ff, PM_UNIT_SMQCTL,  8, VOLTA_SM_SM_NOT_IN_TRAP_QUAD}, // "sctl_hw_pm_mux_upper"
    //SMPC sctl signal end

    { INVALID_PM_SIGNAL_NEW,            ", VOLTA_SM_SM_NOT_IN_TRAP_QUAD",                       0xffffffff, 0x00000000, 0x00000000,     PM_UNIT_MAX,0 }
};
#endif
#if NVCFG(GLOBAL_CHIP_T194) || NVCFG(GLOBAL_GPU_IMPL_GV11B)
PerfSignalSmpc PerfSignalTableGV100_sm0_gv11b[] = {
    //SMPC coreMio signal start
    { VOLTA_SM_INST_EXECUTED_IMMA_OPS, volta_sm_inst_executed_imma_ops_enc_str_1, 0x00000018, 0x00000004, 0x00000001, PM_UNIT_SMQCTL, 1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD }, // "inst_executed_imma_ops"
    { VOLTA_SM_INST_EXECUTED_IMMA_I8_I8_OPS, volta_sm_inst_executed_imma_i8_i8_ops_enc_str_1, 0x00000018, 0x00000005, 0x00000001, PM_UNIT_SMQCTL, 1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD }, // "inst_executed_imma_i8_i8_ops"
    { VOLTA_SM_INST_EXECUTED_IMMA_I16_I8_OPS, volta_sm_inst_executed_imma_i16_i8_ops_enc_str_1, 0x00000018, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD }, // "inst_executed_imma_i16_i8_ops"
    { VOLTA_SM_INST_EXECUTED_INTULTRA_PIPE, volta_sm_inst_executed_intultra_pipe_enc_str_1, 0x0000001b, 0x00000005, 0x00000001, PM_UNIT_SMQCTL, 1, VOLTA_SM_SM_NOT_IN_TRAP_QUAD }, // "inst_executed_intultra_pipe"
    { INVALID_PM_SIGNAL_NEW, ", VOLTA_SM_SM_NOT_IN_TRAP_QUAD", 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0 }
};
#endif /* #if NVCFG(GLOBAL_CHIP_T194) || NVCFG(GLOBAL_GPU_IMPL_GV11B) */


#if NVCFG(GLOBAL_ARCH_VOLTA)
PerfSignalHwpm PerfSignalTableGV100_sys0[] = {
    //Hub TLB signals
    //__hub_tlb_hit        = hubmmu2pm_hub_hub_tlb_hit                                      count # of PTE hits in hub TLB
    //__hub_tlb_miss       = (hubmmu2pm_hub_hub_tlb_miss & !hubmmu2pm_hub_hub_tlb_hit)      count # of PTE misses in hub TLB
    { VOLTA_MMU_HUB_TLB_HIT,    volta_mmu_hub_tlb_hit_enc_str_1,    0x00000004, 0x0000AAAA, 0x40,    PM_UNIT_HUBMMU, 1 },
    { VOLTA_MMU_HUB_TLB_MISS_INT,   volta_mmu_hub_tlb_miss_int_enc_str_1,   0x00000004, 0x0000AAAA, 0x41,    PM_UNIT_HUBMMU, 1 },

    // mmu_fill_pte_hit    = hubmmu2pm_hub_fill_pte_hit                                     "count # of PTE hits in mmu fill unit"
    // mmu_fill_pte_miss   = (hubmmu2pm_hub_fill_pte_miss & !hubmmu2pm_hub_fill_pte_hit)    "count # of PTE misses in mmu fill unit"
    { VOLTA_MMU_FILL_PTE_HIT,   volta_mmu_fill_pte_hit_enc_str_1,   0x00000006, 0x0000AAAA, 0x40,    PM_UNIT_HUBMMU, 1 },
    { VOLTA_MMU_FILL_PTE_MISS_INT,  volta_mmu_fill_pte_miss_int_enc_str_1,  0x00000006, 0x0000AAAA, 0x41,    PM_UNIT_HUBMMU, 1 },

    // mmu_fill_pde_hit    = hubmmu2pm_hub_fill_pde_hit                                     "count # of PDE hits in mmu fill unit"
    // mmu_fill_pde_miss   = hubmmu2pm_hub_fill_pde_miss                                    "count # of PDE misses in mmu fill unit"
    { VOLTA_MMU_FILL_PDE_HIT,   volta_mmu_fill_pde_hit_enc_str_1,   0x00000006, 0x0000AAAA, 0x42,    PM_UNIT_HUBMMU,1 },
    { VOLTA_MMU_FILL_PDE_MISS,  volta_mmu_fill_pde_miss_enc_str_1,  0x00000006, 0x0000AAAA, 0x43,    PM_UNIT_HUBMMU,1 },

    { VOLTA_MMU_GPCL2_TLB_HIT, volta_mmu_gpcl2_tlb_hit_enc_str_1, 0x3, 0xaaaa, 0x40, PM_UNIT_HUBMMU, 1},
    { VOLTA_MMU_GPCL2_TLB_MISS_INT, volta_mmu_gpcl2_tlb_miss_int_enc_str_1, 0x3, 0xaaaa, 0x41, PM_UNIT_HUBMMU, 1},

    { VOLTA_FE_SYS_GR_IDLE, volta_fe_sys_gr_idle_enc_str_1, 0x67, 0xaaaa, 0x11, PM_UNIT_FE, 1},
    { VOLTA_ELAPSED_CYCLES_SYS0, volta_elapsed_cycles_sys0_enc_str_1, 0x00000000, 0x00000000, 0x00, PM_UNIT_FE, 0},
    { INVALID_PM_SIGNAL_NEW,     "",                     0xffffffff, 0x00000000, 0x00,     PM_UNIT_MAX, 0}
};

PerfSignalHwpm PerfSignalTableGV100_sys1[] = {

    //sked2pm_sys_sked_status
    { VOLTA_SKED_STATUS_BIT0_SYS1, volta_sked_status_bit0_sys1_enc_str_1, 0x20, 0xaaaa, 0x8 , PM_UNIT_SKED, 1 },
    { VOLTA_SKED_STATUS_BIT1_SYS1, volta_sked_status_bit1_sys1_enc_str_1, 0x20, 0xaaaa, 0x9 , PM_UNIT_SKED, 1 },
    { VOLTA_SKED_STATUS_BIT2_SYS1, volta_sked_status_bit2_sys1_enc_str_1, 0x20, 0xaaaa, 0xa , PM_UNIT_SKED, 1 },
    { VOLTA_ELAPSED_CYCLES_SYS1, volta_elapsed_cycles_sys1_enc_str_1, 0x00000000, 0x00000000, 0x00, PM_UNIT_SKED, 0 },
    { INVALID_PM_SIGNAL_NEW,     "",                     0xffffffff, 0x00000000, 0x00,     PM_UNIT_MAX,0}
};

PerfSignalHwpm PerfSignalTableGV100_gpc0[] = {
    {VOLTA_MMU_GPC_LTP0_UTLB_HIT_COPY, volta_mmu_gpc_ltp0_utlb_hit_copy_enc_str_1, 0x3, 0xaaaa, 0x35, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP0_UTLB_MISS_COPY_INT, volta_mmu_gpc_ltp0_utlb_miss_copy_int_enc_str_1, 0x3, 0xaaaa, 0x36, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP1_UTLB_HIT_COPY, volta_mmu_gpc_ltp1_utlb_hit_copy_enc_str_1, 0x4, 0xaaaa, 0x35, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP1_UTLB_MISS_COPY_INT, volta_mmu_gpc_ltp1_utlb_miss_copy_int_enc_str_1, 0x4, 0xaaaa, 0x36, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP2_UTLB_HIT_COPY, volta_mmu_gpc_ltp2_utlb_hit_copy_enc_str_1, 0x5, 0xaaaa, 0x35, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP2_UTLB_MISS_COPY_INT, volta_mmu_gpc_ltp2_utlb_miss_copy_int_enc_str_1, 0x5, 0xaaaa, 0x36, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP3_UTLB_HIT_COPY, volta_mmu_gpc_ltp3_utlb_hit_copy_enc_str_1, 0x6, 0xaaaa, 0x35, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP3_UTLB_MISS_COPY_INT, volta_mmu_gpc_ltp3_utlb_miss_copy_int_enc_str_1, 0x6, 0xaaaa, 0x36, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP4_UTLB_HIT_COPY, volta_mmu_gpc_ltp4_utlb_hit_copy_enc_str_1, 0x40, 0xaaaa, 0x35, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP4_UTLB_MISS_COPY_INT, volta_mmu_gpc_ltp4_utlb_miss_copy_int_enc_str_1, 0x40, 0xaaaa, 0x36, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP5_UTLB_HIT_COPY, volta_mmu_gpc_ltp5_utlb_hit_copy_enc_str_1, 0x50, 0xaaaa, 0x35, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP5_UTLB_MISS_COPY_INT, volta_mmu_gpc_ltp5_utlb_miss_copy_int_enc_str_1, 0x50, 0xaaaa, 0x36, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP6_UTLB_HIT_COPY, volta_mmu_gpc_ltp6_utlb_hit_copy_enc_str_1, 0x51, 0xaaaa, 0x35, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP6_UTLB_MISS_COPY_INT, volta_mmu_gpc_ltp6_utlb_miss_copy_int_enc_str_1, 0x51, 0xaaaa, 0x36, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_RGG_UTLB_HIT_COPY, volta_mmu_gpc_rgg_utlb_hit_copy_enc_str_1, 0x7, 0xaaaa, 0x35, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_RGG_UTLB_MISS_COPY_INT, volta_mmu_gpc_rgg_utlb_miss_copy_int_enc_str_1, 0x7, 0xaaaa, 0x36, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_GPCL1_TLB_HIT_COPY, volta_mmu_gpc_gpcl1_tlb_hit_copy_enc_str_1, 0x9, 0xaaaa, 0x35, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_GPCL1_TLB_MISS_COPY_INT, volta_mmu_gpc_gpcl1_tlb_miss_copy_int_enc_str_1, 0x9, 0xaaaa, 0x36, PM_UNIT_GPCMMU1, 1},

    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_TPC4, volta_mmu_gpc_replayable_fault_tpc4_enc_str_1, 0xcc, 0xaaaa, 0x35, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_TPC5, volta_mmu_gpc_replayable_fault_tpc5_enc_str_1, 0xcc, 0xaaaa, 0x36, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_TPC6, volta_mmu_gpc_replayable_fault_tpc6_enc_str_1, 0xcc, 0xaaaa, 0x37, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_RGG,  volta_mmu_gpc_replayable_fault_rgg_enc_str_1,  0xcc, 0xaaaa, 0x38, PM_UNIT_GPCMMU1, 1},

    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_TPC4, volta_mmu_gpc_block_non_fatal_fault_tpc4_enc_str_1, 0xcf, 0xaaaa, 0x35, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_TPC5, volta_mmu_gpc_block_non_fatal_fault_tpc5_enc_str_1, 0xcf, 0xaaaa, 0x36, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_TPC6, volta_mmu_gpc_block_non_fatal_fault_tpc6_enc_str_1, 0xcf, 0xaaaa, 0x37, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_RGG,  volta_mmu_gpc_block_non_fatal_fault_rgg_enc_str_1,  0xcf, 0xaaaa, 0x38, PM_UNIT_GPCMMU1, 1},

    {VOLTA_MMU_GPC_TOTAL_REPLAYABLE_FAULT, volta_mmu_gpc_total_replayable_fault_enc_str_1, 0xcd, 0xffff, 0x35, PM_UNIT_GPCMMU1, 4},

    { INVALID_PM_SIGNAL_NEW,     "",                     0xffffffff, 0x00000000, 0x00,     PM_UNIT_MAX,0}
};

PerfSignalHwpmExpt_v1 PerfSignalTableGV100_gpc0_expt[] = {
    {VOLTA_MMU_GPC_LTP0_UTLB_MISS_COPY, volta_mmu_gpc_ltp0_utlb_miss_copy_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_GPC_LTP0_UTLB_HIT_COPY, VOLTA_MMU_GPC_LTP0_UTLB_MISS_COPY_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {VOLTA_MMU_GPC_LTP1_UTLB_MISS_COPY, volta_mmu_gpc_ltp1_utlb_miss_copy_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_GPC_LTP1_UTLB_HIT_COPY, VOLTA_MMU_GPC_LTP1_UTLB_MISS_COPY_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {VOLTA_MMU_GPC_LTP2_UTLB_MISS_COPY, volta_mmu_gpc_ltp2_utlb_miss_copy_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_GPC_LTP2_UTLB_HIT_COPY, VOLTA_MMU_GPC_LTP2_UTLB_MISS_COPY_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {VOLTA_MMU_GPC_LTP3_UTLB_MISS_COPY, volta_mmu_gpc_ltp3_utlb_miss_copy_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_GPC_LTP3_UTLB_HIT_COPY, VOLTA_MMU_GPC_LTP3_UTLB_MISS_COPY_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {VOLTA_MMU_GPC_LTP4_UTLB_MISS_COPY, volta_mmu_gpc_ltp4_utlb_miss_copy_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_GPC_LTP4_UTLB_HIT_COPY, VOLTA_MMU_GPC_LTP4_UTLB_MISS_COPY_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {VOLTA_MMU_GPC_LTP5_UTLB_MISS_COPY, volta_mmu_gpc_ltp5_utlb_miss_copy_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_GPC_LTP5_UTLB_HIT_COPY, VOLTA_MMU_GPC_LTP5_UTLB_MISS_COPY_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {VOLTA_MMU_GPC_LTP6_UTLB_MISS_COPY, volta_mmu_gpc_ltp6_utlb_miss_copy_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_GPC_LTP6_UTLB_HIT_COPY, VOLTA_MMU_GPC_LTP6_UTLB_MISS_COPY_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {VOLTA_MMU_GPC_RGG_UTLB_MISS_COPY, volta_mmu_gpc_rgg_utlb_miss_copy_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_GPC_RGG_UTLB_HIT_COPY, VOLTA_MMU_GPC_RGG_UTLB_MISS_COPY_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {VOLTA_MMU_GPC_GPCL1_TLB_MISS_COPY, volta_mmu_gpc_gpcl1_tlb_miss_copy_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_GPC_GPCL1_TLB_HIT_COPY, VOLTA_MMU_GPC_GPCL1_TLB_MISS_COPY_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},

    { INVALID_PM_SIGNAL_NEW,     "",                     0xffffffff, 0x00000000, 0x00,     PM_UNIT_MAX,0}
};

PerfSignalHwpm PerfSignalTableGV100_gpc1[] = {
    {VOLTA_MMU_GPC_LTP0_UTLB_HIT, volta_mmu_gpc_ltp0_utlb_hit_enc_str_1, 0x3, 0xaaaa, 0x36, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP0_UTLB_MISS_INT, volta_mmu_gpc_ltp0_utlb_miss_int_enc_str_1, 0x3, 0xaaaa, 0x37, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP1_UTLB_HIT, volta_mmu_gpc_ltp1_utlb_hit_enc_str_1, 0x4, 0xaaaa, 0x36, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP1_UTLB_MISS_INT, volta_mmu_gpc_ltp1_utlb_miss_int_enc_str_1, 0x4, 0xaaaa, 0x37, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP2_UTLB_HIT, volta_mmu_gpc_ltp2_utlb_hit_enc_str_1, 0x5, 0xaaaa, 0x36, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP2_UTLB_MISS_INT, volta_mmu_gpc_ltp2_utlb_miss_int_enc_str_1, 0x5, 0xaaaa, 0x37, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP3_UTLB_HIT, volta_mmu_gpc_ltp3_utlb_hit_enc_str_1, 0x6, 0xaaaa, 0x36, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP3_UTLB_MISS_INT, volta_mmu_gpc_ltp3_utlb_miss_int_enc_str_1, 0x6, 0xaaaa, 0x37, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP4_UTLB_HIT, volta_mmu_gpc_ltp4_utlb_hit_enc_str_1, 0x40, 0xaaaa, 0x36, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP4_UTLB_MISS_INT, volta_mmu_gpc_ltp4_utlb_miss_int_enc_str_1, 0x40, 0xaaaa, 0x37, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP5_UTLB_HIT, volta_mmu_gpc_ltp5_utlb_hit_enc_str_1, 0x50, 0xaaaa, 0x36, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP5_UTLB_MISS_INT, volta_mmu_gpc_ltp5_utlb_miss_int_enc_str_1, 0x50, 0xaaaa, 0x37, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP6_UTLB_HIT, volta_mmu_gpc_ltp6_utlb_hit_enc_str_1, 0x51, 0xaaaa, 0x36, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP6_UTLB_MISS_INT, volta_mmu_gpc_ltp6_utlb_miss_int_enc_str_1, 0x51, 0xaaaa, 0x37, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_RGG_UTLB_HIT, volta_mmu_gpc_rgg_utlb_hit_enc_str_1, 0x7, 0xaaaa, 0x36, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_RGG_UTLB_MISS_INT, volta_mmu_gpc_rgg_utlb_miss_int_enc_str_1, 0x7, 0xaaaa, 0x37, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_GPCL1_TLB_HIT, volta_mmu_gpc_gpcl1_tlb_hit_enc_str_1, 0x9, 0xaaaa, 0x36, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_GPCL1_TLB_MISS_INT, volta_mmu_gpc_gpcl1_tlb_miss_int_enc_str_1, 0x9, 0xaaaa, 0x37, PM_UNIT_GPCMMU, 1},

    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_TPC0, volta_mmu_gpc_replayable_fault_tpc0_enc_str_1, 0xcb, 0xaaaa, 0x36, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_TPC1, volta_mmu_gpc_replayable_fault_tpc1_enc_str_1, 0xcb, 0xaaaa, 0x37, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_TPC2, volta_mmu_gpc_replayable_fault_tpc2_enc_str_1, 0xcb, 0xaaaa, 0x38, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_TPC3, volta_mmu_gpc_replayable_fault_tpc3_enc_str_1, 0xcb, 0xaaaa, 0x39, PM_UNIT_GPCMMU, 1},

    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_TPC0, volta_mmu_gpc_block_non_fatal_fault_tpc0_enc_str_1, 0xce, 0xaaaa, 0x36, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_TPC1, volta_mmu_gpc_block_non_fatal_fault_tpc1_enc_str_1, 0xce, 0xaaaa, 0x37, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_TPC2, volta_mmu_gpc_block_non_fatal_fault_tpc2_enc_str_1, 0xce, 0xaaaa, 0x38, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_TPC3, volta_mmu_gpc_block_non_fatal_fault_tpc3_enc_str_1, 0xce, 0xaaaa, 0x39, PM_UNIT_GPCMMU, 1},

    {VOLTA_MMU_GPC_TOTAL_BLOCK_NON_FATAL_FAULT, volta_mmu_gpc_total_block_non_fatal_fault_enc_str_1, 0xd0, 0xffff, 0x36, PM_UNIT_GPCMMU, 4},

    { INVALID_PM_SIGNAL_NEW,     "",                     0xffffffff, 0x00000000, 0x00,     PM_UNIT_MAX,0}
};

PerfSignalHwpmExpt_v1 PerfSignalTableGV100_gpc1_expt[] = {
    {VOLTA_MMU_GPC_LTP0_UTLB_MISS, volta_mmu_gpc_ltp0_utlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_GPC_LTP0_UTLB_HIT, VOLTA_MMU_GPC_LTP0_UTLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {VOLTA_MMU_GPC_LTP1_UTLB_MISS, volta_mmu_gpc_ltp1_utlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_GPC_LTP1_UTLB_HIT, VOLTA_MMU_GPC_LTP1_UTLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {VOLTA_MMU_GPC_LTP2_UTLB_MISS, volta_mmu_gpc_ltp2_utlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_GPC_LTP2_UTLB_HIT, VOLTA_MMU_GPC_LTP2_UTLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {VOLTA_MMU_GPC_LTP3_UTLB_MISS, volta_mmu_gpc_ltp3_utlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_GPC_LTP3_UTLB_HIT, VOLTA_MMU_GPC_LTP3_UTLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {VOLTA_MMU_GPC_LTP4_UTLB_MISS, volta_mmu_gpc_ltp4_utlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_GPC_LTP4_UTLB_HIT, VOLTA_MMU_GPC_LTP4_UTLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {VOLTA_MMU_GPC_LTP5_UTLB_MISS, volta_mmu_gpc_ltp5_utlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_GPC_LTP5_UTLB_HIT, VOLTA_MMU_GPC_LTP5_UTLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {VOLTA_MMU_GPC_LTP6_UTLB_MISS, volta_mmu_gpc_ltp6_utlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_GPC_LTP6_UTLB_HIT, VOLTA_MMU_GPC_LTP6_UTLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {VOLTA_MMU_GPC_RGG_UTLB_MISS, volta_mmu_gpc_rgg_utlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_GPC_RGG_UTLB_HIT, VOLTA_MMU_GPC_RGG_UTLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {VOLTA_MMU_GPC_GPCL1_TLB_MISS, volta_mmu_gpc_gpcl1_tlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_GPC_GPCL1_TLB_HIT, VOLTA_MMU_GPC_GPCL1_TLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},

    { INVALID_PM_SIGNAL_NEW,     "",                     0xffffffff, 0x00000000, 0x00,     PM_UNIT_MAX,0}
};
#endif /* #if NVCFG(GLOBAL_ARCH_VOLTA) */

#if NVCFG(GLOBAL_CHIP_T194) || NVCFG(GLOBAL_GPU_IMPL_GV11B)
PerfSignalHwpm PerfSignalTableGV11B_sys0[] = {
    //Hub TLB signals
    //__hub_tlb_hit        = hubmmu2pm_hub_hub_tlb_hit                                      count # of PTE hits in hub TLB
    //__hub_tlb_miss       = (hubmmu2pm_hub_hub_tlb_miss & !hubmmu2pm_hub_hub_tlb_hit)      count # of PTE misses in hub TLB
    { VOLTA_MMU_HUB_TLB_HIT,    volta_mmu_hub_tlb_hit_enc_str_1,    0x00000004, 0x0000AAAA, 0x6c,    PM_UNIT_HUBMMU, 1 },
    { VOLTA_MMU_HUB_TLB_MISS_INT,   volta_mmu_hub_tlb_miss_int_enc_str_1,   0x00000004, 0x0000AAAA, 0x6d,    PM_UNIT_HUBMMU, 1 },

    // mmu_fill_pte_hit    = hubmmu2pm_hub_fill_pte_hit                                     "count # of PTE hits in mmu fill unit"
    // mmu_fill_pte_miss   = (hubmmu2pm_hub_fill_pte_miss & !hubmmu2pm_hub_fill_pte_hit)    "count # of PTE misses in mmu fill unit"
    { VOLTA_MMU_FILL_PTE_HIT,   volta_mmu_fill_pte_hit_enc_str_1,   0x00000006, 0x0000AAAA, 0x6c,    PM_UNIT_HUBMMU, 1 },
    { VOLTA_MMU_FILL_PTE_MISS_INT,  volta_mmu_fill_pte_miss_int_enc_str_1,  0x00000006, 0x0000AAAA, 0x6d,    PM_UNIT_HUBMMU, 1 },

    // mmu_fill_pde_hit    = hubmmu2pm_hub_fill_pde_hit                                     "count # of PDE hits in mmu fill unit"
    // mmu_fill_pde_miss   = hubmmu2pm_hub_fill_pde_miss                                    "count # of PDE misses in mmu fill unit"
    { VOLTA_MMU_FILL_PDE_HIT,   volta_mmu_fill_pde_hit_enc_str_1,   0x00000006, 0x0000AAAA, 0x6e,    PM_UNIT_HUBMMU,1 },
    { VOLTA_MMU_FILL_PDE_MISS,  volta_mmu_fill_pde_miss_enc_str_1,  0x00000006, 0x0000AAAA, 0x6f,    PM_UNIT_HUBMMU,1 },

    { VOLTA_MMU_GPCL2_TLB_HIT, volta_mmu_gpcl2_tlb_hit_enc_str_1, 0x3, 0xaaaa, 0x6c, PM_UNIT_HUBMMU, 1},
    { VOLTA_MMU_GPCL2_TLB_MISS_INT, volta_mmu_gpcl2_tlb_miss_int_enc_str_1, 0x3, 0xaaaa, 0x6d, PM_UNIT_HUBMMU, 1},

    { INVALID_PM_SIGNAL_NEW,     "",                     0xffffffff, 0x00000000, 0x00,     PM_UNIT_MAX,0}
};

PerfSignalHwpm PerfSignalTableGV11B_sys1[] = {
    { VOLTA_HSHUB_IG_ARB0_VLD_XBAR0, volta_hshub_ig_arb0_vld_xbar0_enc_str_1, 0x2, 0xaaaa, 0x16, PM_UNIT_HSHUB_IG, 1}, 
    { VOLTA_HSHUB_IG_ARB0_VLD_XBAR1, volta_hshub_ig_arb0_vld_xbar1_enc_str_1, 0x2, 0xaaaa, 0x17, PM_UNIT_HSHUB_IG, 1},
    { VOLTA_HSHUB_IG_ARB0_VLD_XBAR2, volta_hshub_ig_arb0_vld_xbar2_enc_str_1, 0x2, 0xaaaa, 0x18, PM_UNIT_HSHUB_IG, 1},
    { VOLTA_HSHUB_IG_ARB0_VLD_XBAR3, volta_hshub_ig_arb0_vld_xbar3_enc_str_1, 0x2, 0xaaaa, 0x19, PM_UNIT_HSHUB_IG, 1},
    { VOLTA_HSHUB_EG_ARB0_VLD_XBAR0, volta_hshub_eg_arb0_vld_xbar0_enc_str_1, 0x0, 0xaaaa, 0x2a, PM_UNIT_HSHUB_EG, 1}, 
    { VOLTA_HSHUB_EG_ARB0_VLD_XBAR1, volta_hshub_eg_arb0_vld_xbar1_enc_str_1, 0x0, 0xaaaa, 0x2b, PM_UNIT_HSHUB_EG, 1},
    { VOLTA_HSHUB_EG_ARB0_VLD_XBAR2, volta_hshub_eg_arb0_vld_xbar2_enc_str_1, 0x0, 0xaaaa, 0x2c, PM_UNIT_HSHUB_EG, 1},
    { VOLTA_HSHUB_EG_ARB0_VLD_XBAR3, volta_hshub_eg_arb0_vld_xbar3_enc_str_1, 0x0, 0xaaaa, 0x2d, PM_UNIT_HSHUB_EG, 1},
    { VOLTA_HSHUB_IG_NVLTL2HSH0_INPUT_PKT_RDAT, volta_hshub_ig_nvltl2hsh0_input_pkt_rdat_enc_str_1, 0x97, 0xaaaa, 0x19, PM_UNIT_HSHUB_IG, 1},
    { VOLTA_HSHUB_IG_NVLTL2HSH1_INPUT_PKT_RDAT, volta_hshub_ig_nvltl2hsh1_input_pkt_rdat_enc_str_1, 0xAF, 0xaaaa, 0x19, PM_UNIT_HSHUB_IG, 1},
    { VOLTA_HSHUB_IG_NVLTL2HSH2_INPUT_PKT_RDAT, volta_hshub_ig_nvltl2hsh2_input_pkt_rdat_enc_str_1, 0xC7, 0xaaaa, 0x19, PM_UNIT_HSHUB_IG, 1},
    { VOLTA_HSHUB_IG_NVLTL2HSH3_INPUT_PKT_RDAT, volta_hshub_ig_nvltl2hsh3_input_pkt_rdat_enc_str_1, 0xDF, 0xaaaa, 0x19, PM_UNIT_HSHUB_IG, 1},
    { VOLTA_HSHUB_IG_NVLTL2HSH0_INPUT_PKT_WDAT, volta_hshub_ig_nvltl2hsh0_input_pkt_wdat_enc_str_1, 0x97, 0xaaaa, 0x18, PM_UNIT_HSHUB_IG, 1},
    { VOLTA_HSHUB_IG_NVLTL2HSH1_INPUT_PKT_WDAT, volta_hshub_ig_nvltl2hsh1_input_pkt_wdat_enc_str_1, 0xAF, 0xaaaa, 0x18, PM_UNIT_HSHUB_IG, 1},
    { VOLTA_HSHUB_IG_NVLTL2HSH2_INPUT_PKT_WDAT, volta_hshub_ig_nvltl2hsh2_input_pkt_wdat_enc_str_1, 0xC7, 0xaaaa, 0x18, PM_UNIT_HSHUB_IG, 1},
    { VOLTA_HSHUB_IG_NVLTL2HSH3_INPUT_PKT_WDAT, volta_hshub_ig_nvltl2hsh3_input_pkt_wdat_enc_str_1, 0xDF, 0xaaaa, 0x18, PM_UNIT_HSHUB_IG, 1},
    { INVALID_PM_SIGNAL_NEW,         "",                                    0xffffffff, 0x00000000, 0x00,     PM_UNIT_MAX,0}
};

PerfSignalHwpm PerfSignalTableGV11B_gpc0[] = {
    {VOLTA_MMU_GPC_LTP0_UTLB_HIT_COPY, volta_mmu_gpc_ltp0_utlb_hit_copy_enc_str_1, 0x3, 0xaaaa, 0x4b, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP0_UTLB_MISS_COPY_INT, volta_mmu_gpc_ltp0_utlb_miss_copy_int_enc_str_1, 0x3, 0xaaaa, 0x4c, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP1_UTLB_HIT_COPY, volta_mmu_gpc_ltp1_utlb_hit_copy_enc_str_1, 0x4, 0xaaaa, 0x4b, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP1_UTLB_MISS_COPY_INT, volta_mmu_gpc_ltp1_utlb_miss_copy_int_enc_str_1, 0x4, 0xaaaa, 0x4c, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP2_UTLB_HIT_COPY, volta_mmu_gpc_ltp2_utlb_hit_copy_enc_str_1, 0x5, 0xaaaa, 0x4b, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP2_UTLB_MISS_COPY_INT, volta_mmu_gpc_ltp2_utlb_miss_copy_int_enc_str_1, 0x5, 0xaaaa, 0x4c, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP3_UTLB_HIT_COPY, volta_mmu_gpc_ltp3_utlb_hit_copy_enc_str_1, 0x6, 0xaaaa, 0x4b, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP3_UTLB_MISS_COPY_INT, volta_mmu_gpc_ltp3_utlb_miss_copy_int_enc_str_1, 0x6, 0xaaaa, 0x4c, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP4_UTLB_HIT_COPY, volta_mmu_gpc_ltp4_utlb_hit_copy_enc_str_1, 0x40, 0xaaaa, 0x4b, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP4_UTLB_MISS_COPY_INT, volta_mmu_gpc_ltp4_utlb_miss_copy_int_enc_str_1, 0x40, 0xaaaa, 0x4c, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP5_UTLB_HIT_COPY, volta_mmu_gpc_ltp5_utlb_hit_copy_enc_str_1, 0x50, 0xaaaa, 0x4b, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP5_UTLB_MISS_COPY_INT, volta_mmu_gpc_ltp5_utlb_miss_copy_int_enc_str_1, 0x50, 0xaaaa, 0x4c, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP6_UTLB_HIT_COPY, volta_mmu_gpc_ltp6_utlb_hit_copy_enc_str_1, 0x51, 0xaaaa, 0x4b, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_LTP6_UTLB_MISS_COPY_INT, volta_mmu_gpc_ltp6_utlb_miss_copy_int_enc_str_1, 0x51, 0xaaaa, 0x4c, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_RGG_UTLB_HIT_COPY, volta_mmu_gpc_rgg_utlb_hit_copy_enc_str_1, 0x7, 0xaaaa, 0x4b, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_RGG_UTLB_MISS_COPY_INT, volta_mmu_gpc_rgg_utlb_miss_copy_int_enc_str_1, 0x7, 0xaaaa, 0x4c, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_GPCL1_TLB_HIT_COPY, volta_mmu_gpc_gpcl1_tlb_hit_copy_enc_str_1, 0x9, 0xaaaa, 0x4b, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_GPCL1_TLB_MISS_COPY_INT, volta_mmu_gpc_gpcl1_tlb_miss_copy_int_enc_str_1, 0x9, 0xaaaa, 0x4c, PM_UNIT_GPCMMU1, 1},

    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_TPC4, volta_mmu_gpc_replayable_fault_tpc4_enc_str_1, 0xcc, 0xaaaa, 0x4b, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_TPC5, volta_mmu_gpc_replayable_fault_tpc5_enc_str_1, 0xcc, 0xaaaa, 0x4c, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_TPC6, volta_mmu_gpc_replayable_fault_tpc6_enc_str_1, 0xcc, 0xaaaa, 0x4d, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_RGG,  volta_mmu_gpc_replayable_fault_rgg_enc_str_1,  0xcc, 0xaaaa, 0x4e, PM_UNIT_GPCMMU1, 1},

    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_TPC4, volta_mmu_gpc_block_non_fatal_fault_tpc4_enc_str_1, 0xcf, 0xaaaa, 0x4b, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_TPC5, volta_mmu_gpc_block_non_fatal_fault_tpc5_enc_str_1, 0xcf, 0xaaaa, 0x4c, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_TPC6, volta_mmu_gpc_block_non_fatal_fault_tpc6_enc_str_1, 0xcf, 0xaaaa, 0x4d, PM_UNIT_GPCMMU1, 1},
    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_RGG,  volta_mmu_gpc_block_non_fatal_fault_rgg_enc_str_1,  0xcf, 0xaaaa, 0x4e, PM_UNIT_GPCMMU1, 1},

    {VOLTA_MMU_GPC_TOTAL_REPLAYABLE_FAULT, volta_mmu_gpc_total_replayable_fault_enc_str_1, 0xcd, 0xffff, 0x4b, PM_UNIT_GPCMMU1, 4},

    { INVALID_PM_SIGNAL_NEW,     "",                     0xffffffff, 0x00000000, 0x00,     PM_UNIT_MAX,0}
};

PerfSignalHwpm PerfSignalTableGV11B_gpc1[] = {
    {VOLTA_MMU_GPC_LTP0_UTLB_HIT, volta_mmu_gpc_ltp0_utlb_hit_enc_str_1, 0x3, 0xaaaa, 0x6a, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP0_UTLB_MISS_INT, volta_mmu_gpc_ltp0_utlb_miss_int_enc_str_1, 0x3, 0xaaaa, 0x6b, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP1_UTLB_HIT, volta_mmu_gpc_ltp1_utlb_hit_enc_str_1, 0x4, 0xaaaa, 0x6a, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP1_UTLB_MISS_INT, volta_mmu_gpc_ltp1_utlb_miss_int_enc_str_1, 0x4, 0xaaaa, 0x6b, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP2_UTLB_HIT, volta_mmu_gpc_ltp2_utlb_hit_enc_str_1, 0x5, 0xaaaa, 0x6a, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP2_UTLB_MISS_INT, volta_mmu_gpc_ltp2_utlb_miss_int_enc_str_1, 0x5, 0xaaaa, 0x6b, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP3_UTLB_HIT, volta_mmu_gpc_ltp3_utlb_hit_enc_str_1, 0x6, 0xaaaa, 0x6a, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP3_UTLB_MISS_INT, volta_mmu_gpc_ltp3_utlb_miss_int_enc_str_1, 0x6, 0xaaaa, 0x6b, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP4_UTLB_HIT, volta_mmu_gpc_ltp4_utlb_hit_enc_str_1, 0x40, 0xaaaa, 0x6a, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP4_UTLB_MISS_INT, volta_mmu_gpc_ltp4_utlb_miss_int_enc_str_1, 0x40, 0xaaaa, 0x6b, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP5_UTLB_HIT, volta_mmu_gpc_ltp5_utlb_hit_enc_str_1, 0x50, 0xaaaa, 0x6a, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP5_UTLB_MISS_INT, volta_mmu_gpc_ltp5_utlb_miss_int_enc_str_1, 0x50, 0xaaaa, 0x6b, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP6_UTLB_HIT, volta_mmu_gpc_ltp6_utlb_hit_enc_str_1, 0x51, 0xaaaa, 0x6a, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_LTP6_UTLB_MISS_INT, volta_mmu_gpc_ltp6_utlb_miss_int_enc_str_1, 0x51, 0xaaaa, 0x6b, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_RGG_UTLB_HIT, volta_mmu_gpc_rgg_utlb_hit_enc_str_1, 0x7, 0xaaaa, 0x6a, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_RGG_UTLB_MISS_INT, volta_mmu_gpc_rgg_utlb_miss_int_enc_str_1, 0x7, 0xaaaa, 0x6b, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_GPCL1_TLB_HIT, volta_mmu_gpc_gpcl1_tlb_hit_enc_str_1, 0x9, 0xaaaa, 0x6a, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_GPCL1_TLB_MISS_INT, volta_mmu_gpc_gpcl1_tlb_miss_int_enc_str_1, 0x9, 0xaaaa, 0x6b, PM_UNIT_GPCMMU, 1},

    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_TPC0, volta_mmu_gpc_replayable_fault_tpc0_enc_str_1, 0xcb, 0xaaaa, 0x6a, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_TPC1, volta_mmu_gpc_replayable_fault_tpc1_enc_str_1, 0xcb, 0xaaaa, 0x6b, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_TPC2, volta_mmu_gpc_replayable_fault_tpc2_enc_str_1, 0xcb, 0xaaaa, 0x6c, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_TPC3, volta_mmu_gpc_replayable_fault_tpc3_enc_str_1, 0xcb, 0xaaaa, 0x6d, PM_UNIT_GPCMMU, 1},

    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_TPC0, volta_mmu_gpc_block_non_fatal_fault_tpc0_enc_str_1, 0xce, 0xaaaa, 0x6a, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_TPC1, volta_mmu_gpc_block_non_fatal_fault_tpc1_enc_str_1, 0xce, 0xaaaa, 0x6b, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_TPC2, volta_mmu_gpc_block_non_fatal_fault_tpc2_enc_str_1, 0xce, 0xaaaa, 0x6c, PM_UNIT_GPCMMU, 1},
    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_TPC3, volta_mmu_gpc_block_non_fatal_fault_tpc3_enc_str_1, 0xce, 0xaaaa, 0x6d, PM_UNIT_GPCMMU, 1},

    {VOLTA_MMU_GPC_TOTAL_BLOCK_NON_FATAL_FAULT, volta_mmu_gpc_total_block_non_fatal_fault_enc_str_1, 0xd0, 0xffff, 0x6a, PM_UNIT_GPCMMU, 4},

    { INVALID_PM_SIGNAL_NEW,     "",                     0xffffffff, 0x00000000, 0x00,     PM_UNIT_MAX,0}
};
#endif

#if NVCFG(GLOBAL_ARCH_VOLTA)
PerfSignalHwpmExpt_v1 PerfSignalTableGV100_sys0_expt[] = {
    //Hub TLB signals
    //__hub_tlb_miss       = (hubmmu2pm_hub_hub_tlb_miss & !hubmmu2pm_hub_hub_tlb_hit)      count # of PTE misses in hub TLB
    { VOLTA_MMU_HUB_TLB_MISS, volta_mmu_hub_tlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_HUB_TLB_HIT, VOLTA_MMU_HUB_TLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW} ,

    // mmu_fill_pte_miss   = (hubmmu2pm_hub_fill_pte_miss & !hubmmu2pm_hub_fill_pte_hit)    "count # of PTE misses in mmu fill unit"
    { VOLTA_MMU_FILL_PTE_MISS, volta_mmu_fill_pte_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_FILL_PTE_HIT, VOLTA_MMU_FILL_PTE_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},

    //__hub_gpcl2_tlb_miss = (hubmmu2pm_hub_gpcl2_tlb_miss & !hubmmu2pm_hub_gpcl2_tlb_hit)  count # of PTE misses in gpcl2 TLB
    { VOLTA_MMU_GPCL2_TLB_MISS, volta_mmu_gpcl2_tlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_GPCL2_TLB_HIT, VOLTA_MMU_GPCL2_TLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},

    // fe_gr_busy = !fe_gr_idle
    { VOLTA_FE_SYS_GR_BUSY, volta_fe_sys_gr_busy_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_FE_SYS_GR_IDLE, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ~TRUTH_TABLE_FUNCTION_BIT_0_TRUE, INVALID_PM_SIGNAL_NEW},
    
    //TODO: hshub signals for GV100.

   { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000, INVALID_PM_SIGNAL_NEW},
};

PerfSignalHwpmExpt_v1 PerfSignalTableGV11B_sys0_expt[] = {
    //Hub TLB signals
    //__hub_tlb_miss       = (hubmmu2pm_hub_hub_tlb_miss & !hubmmu2pm_hub_hub_tlb_hit)      count # of PTE misses in hub TLB
    { VOLTA_MMU_HUB_TLB_MISS, volta_mmu_hub_tlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_HUB_TLB_HIT, VOLTA_MMU_HUB_TLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW} ,

    // mmu_fill_pte_miss   = (hubmmu2pm_hub_fill_pte_miss & !hubmmu2pm_hub_fill_pte_hit)    "count # of PTE misses in mmu fill unit"
    { VOLTA_MMU_FILL_PTE_MISS, volta_mmu_fill_pte_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_FILL_PTE_HIT, VOLTA_MMU_FILL_PTE_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},

    //__hub_gpcl2_tlb_miss = (hubmmu2pm_hub_gpcl2_tlb_miss & !hubmmu2pm_hub_gpcl2_tlb_hit)  count # of PTE misses in gpcl2 TLB
    { VOLTA_MMU_GPCL2_TLB_MISS, volta_mmu_gpcl2_tlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_MMU_GPCL2_TLB_HIT, VOLTA_MMU_GPCL2_TLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},

   { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000, INVALID_PM_SIGNAL_NEW},
};

PerfSignalHwpmExpt_v1 PerfSignalTableGV100_sys1_expt[] = {

   // to add: sked non idle
    { VOLTA_SKED_IDLE_SYS1, volta_sked_idle_sys1_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_SKED_STATUS_BIT0_SYS1, VOLTA_SKED_STATUS_BIT1_SYS1, VOLTA_SKED_STATUS_BIT2_SYS1, INVALID_PM_SIGNAL_NEW}, (~TRUTH_TABLE_FUNCTION_BIT_0_TRUE & ~TRUTH_TABLE_FUNCTION_BIT_1_TRUE & ~TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},
    { VOLTA_SKED_BUSY_SYS1, volta_sked_busy_sys1_enc_str_1, INVALID_PM_SIGNAL_NEW, {VOLTA_SKED_STATUS_BIT0_SYS1, VOLTA_SKED_STATUS_BIT1_SYS1, VOLTA_SKED_STATUS_BIT2_SYS1, INVALID_PM_SIGNAL_NEW}, ~(~TRUTH_TABLE_FUNCTION_BIT_0_TRUE & ~TRUTH_TABLE_FUNCTION_BIT_1_TRUE & ~TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},
    { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000, INVALID_PM_SIGNAL_NEW},
};
#endif /* #if NVCFG(GLOBAL_ARCH_VOLTA) */

#if NVCFG(GLOBAL_ARCH_VOLTA)
PerfSignalCUPTIsw PerfSignalTableGVSwCounters_shared_load_store[] = {
    { VOLTA_SW_COUNTER_SLD8BIT_INST,   volta_sw_counter_sld8bit_inst_enc_str_1},
    { VOLTA_SW_COUNTER_SLD16BIT_INST,  volta_sw_counter_sld16bit_inst_enc_str_1},
    { VOLTA_SW_COUNTER_SLD32BIT_INST,  volta_sw_counter_sld32bit_inst_enc_str_1},
    { VOLTA_SW_COUNTER_SLD64BIT_INST,  volta_sw_counter_sld64bit_inst_enc_str_1},
    { VOLTA_SW_COUNTER_SLD128BIT_INST, volta_sw_counter_sld128bit_inst_enc_str_1},
    { VOLTA_SW_COUNTER_SST8BIT_INST,   volta_sw_counter_sst8bit_inst_enc_str_1},
    { VOLTA_SW_COUNTER_SST16BIT_INST,  volta_sw_counter_sst16bit_inst_enc_str_1},
    { VOLTA_SW_COUNTER_SST32BIT_INST,  volta_sw_counter_sst32bit_inst_enc_str_1},
    { VOLTA_SW_COUNTER_SST64BIT_INST,  volta_sw_counter_sst64bit_inst_enc_str_1},
    { VOLTA_SW_COUNTER_SST128BIT_INST, volta_sw_counter_sst128bit_inst_enc_str_1},
    { INVALID_SW_COUNTER,              ""}
};
#endif /* #if NVCFG(GLOBAL_ARCH_VOLTA) */

#if NVCFG(GLOBAL_ARCH_VOLTA)
PerfSignalCUPTIsw PerfSignalTableGVSwCounters_flops[] = {
    { VOLTA_SW_COUNTER_FADD_INST, volta_sw_counter_fadd_inst_enc_str_1},
    { VOLTA_SW_COUNTER_FMUL_INST, volta_sw_counter_fmul_inst_enc_str_1},
    { VOLTA_SW_COUNTER_FFMA_INST, volta_sw_counter_ffma_inst_enc_str_1},
    { VOLTA_SW_COUNTER_DADD_INST, volta_sw_counter_dadd_inst_enc_str_1},
    { VOLTA_SW_COUNTER_DMUL_INST, volta_sw_counter_dmul_inst_enc_str_1},
    { VOLTA_SW_COUNTER_DFMA_INST, volta_sw_counter_dfma_inst_enc_str_1},
    { VOLTA_SW_COUNTER_COS_INST,  volta_sw_counter_cos_inst_enc_str_1},
    { VOLTA_SW_COUNTER_EX2_INST,  volta_sw_counter_ex2_inst_enc_str_1},
    { VOLTA_SW_COUNTER_LG2_INST,  volta_sw_counter_lg2_inst_enc_str_1},
    { VOLTA_SW_COUNTER_RCP_INST,  volta_sw_counter_rcp_inst_enc_str_1},
    { VOLTA_SW_COUNTER_RSQ_INST,  volta_sw_counter_rsq_inst_enc_str_1},
    { VOLTA_SW_COUNTER_SIN_INST,  volta_sw_counter_sin_inst_enc_str_1},
    { VOLTA_SW_COUNTER_SQRT_INST, volta_sw_counter_sqrt_inst_enc_str_1},
    { VOLTA_SW_COUNTER_HADD_INST, volta_sw_counter_hadd_inst_enc_str_1},
    { VOLTA_SW_COUNTER_HMUL_INST, volta_sw_counter_hmul_inst_enc_str_1},
    { VOLTA_SW_COUNTER_HFMA_INST, volta_sw_counter_hfma_inst_enc_str_1},
    { INVALID_SW_COUNTER,         ""}
};
#endif /* #if NVCFG(GLOBAL_ARCH_VOLTA) */

#if NVCFG(GLOBAL_ARCH_VOLTA)
PerfSignalCUPTIsw PerfSignalTableGVSwCounters_instrClass[] = {
    { VOLTA_SW_COUNTER_INSTR_CLASS_FP_32,                      volta_sw_counter_instr_class_fp_32_enc_str_1},
    { VOLTA_SW_COUNTER_INSTR_CLASS_FP_64,                      volta_sw_counter_instr_class_fp_64_enc_str_1},
    { VOLTA_SW_COUNTER_INSTR_CLASS_INTEGER,                    volta_sw_counter_instr_class_integer_enc_str_1},
    { VOLTA_SW_COUNTER_INSTR_CLASS_BIT_CONVERT,                volta_sw_counter_instr_class_bit_convert_enc_str_1},
    { VOLTA_SW_COUNTER_INSTR_CLASS_CONTROL,                    volta_sw_counter_instr_class_control_enc_str_1},
    { VOLTA_SW_COUNTER_INSTR_CLASS_COMPUTE_LD_ST,              volta_sw_counter_instr_class_compute_ld_st_enc_str_1},
    { VOLTA_SW_COUNTER_INSTR_CLASS_INTER_THREAD_COMMUNICATION, volta_sw_counter_instr_class_inter_thread_communication_enc_str_1},
    { VOLTA_SW_COUNTER_INSTR_CLASS_FP_16,                      volta_sw_counter_instr_class_fp_16_enc_str_1},
    { VOLTA_SW_COUNTER_INSTR_CLASS_MISCELLANEOUS,              volta_sw_counter_instr_class_miscellaneous_enc_str_1},
    { INVALID_SW_COUNTER,                                      ""}
};
#endif /* #if NVCFG(GLOBAL_ARCH_VOLTA) */


PerfSignalCUPTIsw PerfSignalTableGVSwCounters_unique_global_load_store[] = {
    { VOLTA_SW_COUNTER_UNIQUE_GLD8BIT_INST,   volta_sw_counter_unique_gld8bit_inst_enc_str_1},
    { VOLTA_SW_COUNTER_UNIQUE_GLD16BIT_INST,  volta_sw_counter_unique_gld16bit_inst_enc_str_1},
    { VOLTA_SW_COUNTER_UNIQUE_GLD32BIT_INST,  volta_sw_counter_unique_gld32bit_inst_enc_str_1},
    { VOLTA_SW_COUNTER_UNIQUE_GLD64BIT_INST,  volta_sw_counter_unique_gld64bit_inst_enc_str_1},
    { VOLTA_SW_COUNTER_UNIQUE_GLD128BIT_INST, volta_sw_counter_unique_gld128bit_inst_enc_str_1},
    { VOLTA_SW_COUNTER_UNIQUE_GST8BIT_INST,   volta_sw_counter_unique_gst8bit_inst_enc_str_1},
    { VOLTA_SW_COUNTER_UNIQUE_GST16BIT_INST,  volta_sw_counter_unique_gst16bit_inst_enc_str_1},
    { VOLTA_SW_COUNTER_UNIQUE_GST32BIT_INST,  volta_sw_counter_unique_gst32bit_inst_enc_str_1},
    { VOLTA_SW_COUNTER_UNIQUE_GST64BIT_INST,  volta_sw_counter_unique_gst64bit_inst_enc_str_1},
    { VOLTA_SW_COUNTER_UNIQUE_GST128BIT_INST, volta_sw_counter_unique_gst128bit_inst_enc_str_1},
    { INVALID_SW_COUNTER,              ""}
};

#if NVCFG(GLOBAL_ARCH_VOLTA)
PerfSignalCUPTIsw PerfSignalTableGVSwCounters_branch[] = {
    { VOLTA_SW_COUNTER_DIVERGED_BRANCH, volta_sw_counter_diverged_branch_enc_str_1},
    { VOLTA_SW_COUNTER_BRANCH_INST_EXECUTED, volta_sw_counter_branch_inst_executed_enc_str_1},
    { INVALID_SW_COUNTER,              ""}
};
#endif

#if NVCFG(GLOBAL_ARCH_VOLTA)
CUeventDataSmpcExpt PerfSignalTableGV100_LutModeCounters[] = {
    { VOLTA_LUT_COUNTER_GLD32BIT_INST,             volta_lut_counter_gld32bit_inst_enc_str_1,             PM_UNIT_SMQCTL,     {VOLTA_SM_INST_EXECUTED_32B,VOLTA_SM_INST_EXECUTED_GENERIC_LD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { VOLTA_LUT_COUNTER_GST32BIT_INST,             volta_lut_counter_gst32bit_inst_enc_str_1,             PM_UNIT_SMQCTL,     {VOLTA_SM_INST_EXECUTED_32B,VOLTA_SM_INST_EXECUTED_GENERIC_ST,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { VOLTA_LUT_COUNTER_GLD64BIT_INST,             volta_lut_counter_gld64bit_inst_enc_str_1,             PM_UNIT_SMQCTL,     {VOLTA_SM_INST_EXECUTED_64B,VOLTA_SM_INST_EXECUTED_GENERIC_LD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { VOLTA_LUT_COUNTER_GST64BIT_INST,             volta_lut_counter_gst64bit_inst_enc_str_1,             PM_UNIT_SMQCTL,     {VOLTA_SM_INST_EXECUTED_64B,VOLTA_SM_INST_EXECUTED_GENERIC_ST,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { VOLTA_LUT_COUNTER_GLD128BIT_INST,            volta_lut_counter_gld128bit_inst_enc_str_1,            PM_UNIT_SMQCTL,     {VOLTA_SM_INST_EXECUTED_128B,VOLTA_SM_INST_EXECUTED_GENERIC_LD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { VOLTA_LUT_COUNTER_GST128BIT_INST,            volta_lut_counter_gst128bit_inst_enc_str_1,            PM_UNIT_SMQCTL,     {VOLTA_SM_INST_EXECUTED_128B,VOLTA_SM_INST_EXECUTED_GENERIC_ST,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},    (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},

    { VOLTA_LUT_COUNTER_SHLD_32BIT_INST,           volta_lut_counter_shld_32bit_inst_enc_str_1,         PM_UNIT_SMQCTL,     {VOLTA_SM_INST_EXECUTED_32B,VOLTA_SM_INST_EXECUTED_SHARED_ST,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { VOLTA_LUT_COUNTER_SHLD_64BIT_INST,           volta_lut_counter_shld_64bit_inst_enc_str_1,         PM_UNIT_SMQCTL,     {VOLTA_SM_INST_EXECUTED_64B,VOLTA_SM_INST_EXECUTED_SHARED_LD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { VOLTA_LUT_COUNTER_SHLD_128BIT_INST,          volta_lut_counter_shld_128bit_inst_enc_str_1,        PM_UNIT_SMQCTL,     {VOLTA_SM_INST_EXECUTED_128B,VOLTA_SM_INST_EXECUTED_SHARED_LD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { VOLTA_LUT_COUNTER_SHLD_U128BIT_INST,         volta_lut_counter_shld_u128bit_inst_enc_str_1,      PM_UNIT_SMQCTL,     {VOLTA_SM_INST_EXECUTED_U128B,VOLTA_SM_INST_EXECUTED_SHARED_LD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { VOLTA_LUT_COUNTER_SHST_32BIT_INST,           volta_lut_counter_shst_32bit_inst_enc_str_1,         PM_UNIT_SMQCTL,     {VOLTA_SM_INST_EXECUTED_32B,VOLTA_SM_INST_EXECUTED_SHARED_ST,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { VOLTA_LUT_COUNTER_SHST_64BIT_INST,           volta_lut_counter_shst_64bit_inst_enc_str_1,         PM_UNIT_SMQCTL,     {VOLTA_SM_INST_EXECUTED_64B,VOLTA_SM_INST_EXECUTED_SHARED_ST,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { VOLTA_LUT_COUNTER_SHST_128BIT_INST,          volta_lut_counter_shst_128bit_inst_enc_str_1,        PM_UNIT_SMQCTL,     {VOLTA_SM_INST_EXECUTED_128B,VOLTA_SM_INST_EXECUTED_SHARED_ST,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { VOLTA_LUT_COUNTER_SH_ATOM_32BIT_INST,        volta_lut_counter_sh_atom_32bit_inst_enc_str_1,       PM_UNIT_SMQCTL,     {VOLTA_SM_INST_EXECUTED_32B,VOLTA_SM_INST_EXECUTED_SHARED_ATOM,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { VOLTA_LUT_COUNTER_SH_ATOM_64BIT_INST,        volta_lut_counter_sh_atom_64bit_inst_enc_str_1,       PM_UNIT_SMQCTL,     {VOLTA_SM_INST_EXECUTED_64B,VOLTA_SM_INST_EXECUTED_SHARED_ATOM,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { VOLTA_LUT_COUNTER_SH_ATOM_CAS_32BIT_INST,    volta_lut_counter_sh_atom_cas_32bit_inst_enc_str_1,   PM_UNIT_SMQCTL,     {VOLTA_SM_INST_EXECUTED_32B,VOLTA_SM_INST_EXECUTED_SHARED_ATOM_CAS,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { VOLTA_LUT_COUNTER_SH_ATOM_CAS_64BIT_INST,    volta_lut_counter_sh_atom_cas_64bit_inst_enc_str_1,   PM_UNIT_SMQCTL,     {VOLTA_SM_INST_EXECUTED_64B,VOLTA_SM_INST_EXECUTED_SHARED_ATOM_CAS,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { VOLTA_LUT_COUNTER_UNIQUE_WARPS_LAUNCHED, volta_lut_counter_unique_warps_launched_enc_str_1, PM_UNIT_SMQCTL, {VOLTA_SM_WARPS_LAUNCHED, VOLTA_SM_WARPS_RESTORED, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & ~TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { VOLTA_LUT_COUNTER_UNIQUE_CTAS_LAUNCHED, volta_lut_counter_unique_ctas_launched_enc_str_1, PM_UNIT_SMCORE, {VOLTA_SM_CTAS_LAUNCHED, VOLTA_SM_CTAS_RESTORED, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & ~TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},

    { INVALID_PM_SIGNAL_NEW,               "", PM_UNIT_MAX, {INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW} , TRUTH_TABLE_FUNCTION_ALL_FALSE}
};
#endif /* #if NVCFG(GLOBAL_ARCH_VOLTA) */

#if NVCFG(GLOBAL_ARCH_VOLTA)
PerfSignalHwpm PerfSignalTableGV100_pcie0[] = {
    { VOLTA_PCIE_TX_ACTIVE, volta_pcie_tx_active_enc_str_1,  0xb,        0xaaaa,     0x4,    PM_UNIT_XVE1,   1 },
    { VOLTA_PCIE_TX_IDLE,   volta_pcie_tx_idle_enc_str_1,    0xb,        0xaaaa,     0x3,    PM_UNIT_XVE1,   1 },
    { VOLTA_PCIE_RX_ACTIVE, volta_pcie_rx_active_enc_str_1,  0xe,        0xaaaa,     0x1e,   PM_UNIT_XVE2,   1 },
    { VOLTA_PCIE_RX_IDLE,   volta_pcie_rx_idle_enc_str_1,    0xe,        0xaaaa,     0x1d,   PM_UNIT_XVE2,   1 },
    { INVALID_PM_SIGNAL_NEW, "",                             0xffffffff, 0x00000000, 0x00,   PM_UNIT_MAX,    0 }
};
#endif /* #if NVCFG(GLOBAL_ARCH_VOLTA) */

#if NVCFG(GLOBAL_ARCH_VOLTA)
CUeventDataSmpcExpt PerfSignalTableGV100_multiGroup[] = {
    { VOLTA_SM_PMTRIG_MULTI_GROUP,             volta_multigrp_counter_pmtrig_enc_str_1,             PM_UNIT_SMQCTL,     {VOLTA_SM_PMTRIG0,VOLTA_SM_PMTRIG4,VOLTA_SM_PMTRIG10,VOLTA_SM_PMTRIG15,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW}},

    { INVALID_PM_SIGNAL_NEW,               "", PM_UNIT_MAX, {INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW} , TRUTH_TABLE_FUNCTION_ALL_FALSE}
};
#endif /* #if NVCFG(GLOBAL_ARCH_VOLTA) */

#if NVCFG(GLOBAL_ARCH_VOLTA)
CUdomainData domainTableGV100[] = {
    {VOLTA_CLK_DOMAIN_GV100_GPCTPC,                       volta_clk_domain_gv100_gpctpc_enc_str_1,         CUPROF_EVENT_COLLECTION_METHOD_HWPM,     { {(void *)PerfSignalTableGV100_gpctpc, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGV100_gpctpc_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1}},    0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 2},
    //Both ltc0 and ltc1 clock domains will be supported by this external domain
    {VOLTA_CLK_DOMAIN_GV100_FBP0,                         volta_clk_domain_gv100_fbp0_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGV100_fbp0, PERF_SIG_TABLE_TYPE_HWPM}},                                0,  0,  0,  PM_CHIPLET_TYPE_FBP, 0, 0, 1},
    // Creating separate domain  for sw counters
    {VOLTA_CLK_DOMAIN_GV100_SM0,                          volta_clk_domain_gv100_sm0_enc_str_1,  CUPROF_EVENT_COLLECTION_METHOD_SMPERF,            {{(void *)PerfSignalTableGV100_sm0, PERF_SIG_TABLE_TYPE_SMPC}, {(void *)PerfSignalTableGV100_LutModeCounters, PERF_SIG_TABLE_TYPE_LUT}, {(void *)PerfSignalTableGV100_multiGroup, PERF_SIG_TABLE_TYPE_MULTI_GROUP}},        0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 3},
    {VOLTA_CLK_DOMAIN_GV100_LTC0,                         volta_clk_domain_gv100_ltc0_enc_str_1, CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGV100_ltc0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGV100_ltc0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1}},       0,  0,  0,  PM_CHIPLET_TYPE_FBP, 0, 0, 2},
    {VOLTA_CLK_DOMAIN_GV100_NVLINK_THROUGHPUT_COUNTERS, volta_clk_domain_gv100_nvlink_throughput_counters_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_NVLINK_TC, {{PerfSignalTableGV100_nvlinkTC, PERF_SIG_TABLE_TYPE_NVLINK_THROUGHPUT_CNTR}},      0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 1, CUPROF_EVENT_COLLECTION_SCOPE_DEVICE},
    // sw counters
    {VOLTA_SW_DOMAIN_GV100_FLOPS,                  volta_sw_domain_gv100_flops_enc_str_1,             CUPROF_EVENT_COLLECTION_METHOD_CUPTI_SW, {{(void *)PerfSignalTableGVSwCounters_flops, PERF_SIG_TABLE_TYPE_CUPTI_SW}},             0, 0, 0, PM_CHIPLET_TYPE_NONE, 0, 0, 1},
    {VOLTA_SW_DOMAIN_GV100_INSTR_CLASS,            volta_sw_domain_gv100_instr_class_enc_str_1,       CUPROF_EVENT_COLLECTION_METHOD_CUPTI_SW, {{(void *)PerfSignalTableGVSwCounters_instrClass, PERF_SIG_TABLE_TYPE_CUPTI_SW}},                 0, 0, 0, PM_CHIPLET_TYPE_NONE, 0, 0, 1},
    {VOLTA_SW_DOMAIN_GV100_SHARED_LOAD_STORE,      volta_sw_domain_gv100_shared_load_store_enc_str_1, CUPROF_EVENT_COLLECTION_METHOD_CUPTI_SW, {{(void *)PerfSignalTableGVSwCounters_shared_load_store, PERF_SIG_TABLE_TYPE_CUPTI_SW}},        0, 0, 0, PM_CHIPLET_TYPE_NONE, 0, 0, 1},
    {VOLTA_SW_DOMAIN_GV100_UNIQUE_GLD_GST,         volta_sw_domain_gv100_unique_gld_gst_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_CUPTI_SW, {{(void *)PerfSignalTableGVSwCounters_unique_global_load_store, PERF_SIG_TABLE_TYPE_CUPTI_SW}}, 0, 0, 0, PM_CHIPLET_TYPE_NONE, 0, 0, 1},
    // Keep domains of exposed events and events used in metrics, before domains belong to internal events.
    // Else, such events won't get enumerated.
    {VOLTA_CLK_DOMAIN_GV100_PCIE0,                        volta_clk_domain_gv100_pcie0_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGV100_pcie0, PERF_SIG_TABLE_TYPE_HWPM}},      0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 1, CUPROF_EVENT_COLLECTION_SCOPE_DEVICE},
    {VOLTA_CLK_DOMAIN_GV100_SYS0,                         volta_clk_domain_gv100_sys0_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGV100_sys0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGV100_sys0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1}},      0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 2},
    {VOLTA_SW_DOMAIN_GV100_BRANCH, volta_sw_domain_gv100_branch_enc_str_1, CUPROF_EVENT_COLLECTION_METHOD_CUPTI_SW, {{(void *)PerfSignalTableGVSwCounters_branch, PERF_SIG_TABLE_TYPE_CUPTI_SW}}, 0, 0, 0, PM_CHIPLET_TYPE_NONE, 0, 0, 1},
    //Add all exposed domain before internal domains, otherwise whole parsing logic for domain and event will get messed up.
    //VOLTA_CLK_DOMAIN_GV100_HWPMMUX will be a dummy id that is used to identify the HWPM signals profiled via SMPC.
    //We require this so that we can restrict profiling these signals with pure HWPM or pure SMPC signals
    //Currently there is no way to avoid this except having check at domain level, also it is possible that we will allow pure HWPM signals with pure SMPC.
    //Internally this domain id will be mapped to VOLTA_CLK_DOMAIN_GV100_GPCTPC
    {VOLTA_CLK_DOMAIN_GV100_HWPMMUX,                      volta_clk_domain_gv100_hwpmmux_enc_str_1, CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX,           {{(void *)PerfSignalTableGV100_hwpmmux, PERF_SIG_TABLE_TYPE_HWPMMUX}},                          0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {VOLTA_CLK_DOMAIN_GV100_GPC0,                         volta_clk_domain_gv100_gpc0_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGV100_gpc0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGV100_gpc0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 2},
    {VOLTA_CLK_DOMAIN_GV100_GPC1,                         volta_clk_domain_gv100_gpc1_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGV100_gpc1, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGV100_gpc1_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 2},
    {VOLTA_CLK_DOMAIN_GV100_NVLRX0,                       volta_clk_domain_gv100_nvlrx0_enc_str_1,  CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGV100_nvrx0, PERF_SIG_TABLE_TYPE_HWPM }, {(void *)PerfSignalTableGV100_nvrx0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1}},   0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 2, CUPROF_EVENT_COLLECTION_SCOPE_DEVICE},
    {VOLTA_CLK_DOMAIN_GV100_NVLTX0,                       volta_clk_domain_gv100_nvltx0_enc_str_1,  CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGV100_nvtx0, PERF_SIG_TABLE_TYPE_HWPM }, {(void *)PerfSignalTableGV100_nvtx0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1}},   0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 2, CUPROF_EVENT_COLLECTION_SCOPE_DEVICE},
    {VOLTA_CLK_DOMAIN_GV100_SYS1,                         volta_clk_domain_gv100_sys1_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGV100_sys1, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGV100_sys1_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1}},      0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 2},
};

#endif /* #if NVCFG(GLOBAL_ARCH_VOLTA) */
#if NVCFG(GLOBAL_CHIP_T194) || NVCFG(GLOBAL_GPU_IMPL_GV11B)
CUdomainData domainTableGV11B[] = {
    { VOLTA_CLK_DOMAIN_GV11B_GPCTPC, volta_clk_domain_gv100_gpctpc_enc_str_1, CUPROF_EVENT_COLLECTION_METHOD_HWPM, { { (void *)PerfSignalTableGV11B_gpctpc, PERF_SIG_TABLE_TYPE_HWPM }, { (void *)PerfSignalTableGV100_gpctpc_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1 } }, 0, 0, 0, PM_CHIPLET_TYPE_GPC, 0, 0, 2 },
    // Creating separate domain  for sm counters
    { VOLTA_CLK_DOMAIN_GV11B_SM0,   volta_clk_domain_gv100_sm0_enc_str_1,  CUPROF_EVENT_COLLECTION_METHOD_SMPERF,  {{(void *)PerfSignalTableGV100_sm0, PERF_SIG_TABLE_TYPE_SMPC}, {(void *)PerfSignalTableGV100_sm0_gv11b, PERF_SIG_TABLE_TYPE_SMPC}, {(void *)PerfSignalTableGV100_LutModeCounters, PERF_SIG_TABLE_TYPE_LUT}, {(void *)PerfSignalTableGV100_multiGroup, PERF_SIG_TABLE_TYPE_MULTI_GROUP}},        0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 4},
    { VOLTA_CLK_DOMAIN_GV11B_LTC0, volta_clk_domain_gv100_ltc0_enc_str_1, CUPROF_EVENT_COLLECTION_METHOD_HWPM, { { (void *)PerfSignalTableGV11B_ltc0, PERF_SIG_TABLE_TYPE_HWPM }, { (void *)PerfSignalTableGV100_ltc0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1 } }, 0, 0, 0, PM_CHIPLET_TYPE_FBP, 0, 0, 2 },
    // sw counters
    { VOLTA_SW_DOMAIN_GV100_FLOPS, volta_sw_domain_gv100_flops_enc_str_1, CUPROF_EVENT_COLLECTION_METHOD_CUPTI_SW, { { (void *)PerfSignalTableGVSwCounters_flops, PERF_SIG_TABLE_TYPE_CUPTI_SW } }, 0, 0, 0, PM_CHIPLET_TYPE_NONE, 0, 0, 1 },
    { VOLTA_SW_DOMAIN_GV100_INSTR_CLASS, volta_sw_domain_gv100_instr_class_enc_str_1, CUPROF_EVENT_COLLECTION_METHOD_CUPTI_SW, { { (void *)PerfSignalTableGVSwCounters_instrClass, PERF_SIG_TABLE_TYPE_CUPTI_SW } }, 0, 0, 0, PM_CHIPLET_TYPE_NONE, 0, 0, 1 },
    { VOLTA_SW_DOMAIN_GV100_SHARED_LOAD_STORE, volta_sw_domain_gv100_shared_load_store_enc_str_1, CUPROF_EVENT_COLLECTION_METHOD_CUPTI_SW, { { (void *)PerfSignalTableGVSwCounters_shared_load_store, PERF_SIG_TABLE_TYPE_CUPTI_SW } }, 0, 0, 0, PM_CHIPLET_TYPE_NONE, 0, 0, 1 },
    { VOLTA_SW_DOMAIN_GV100_UNIQUE_GLD_GST, volta_sw_domain_gv100_unique_gld_gst_enc_str_1, CUPROF_EVENT_COLLECTION_METHOD_CUPTI_SW, { { (void *)PerfSignalTableGVSwCounters_unique_global_load_store, PERF_SIG_TABLE_TYPE_CUPTI_SW } }, 0, 0, 0, PM_CHIPLET_TYPE_NONE, 0, 0, 1 },
    { VOLTA_SW_DOMAIN_GV100_BRANCH, volta_sw_domain_gv100_branch_enc_str_1, CUPROF_EVENT_COLLECTION_METHOD_CUPTI_SW, {{(void *)PerfSignalTableGVSwCounters_branch, PERF_SIG_TABLE_TYPE_CUPTI_SW}}, 0, 0, 0, PM_CHIPLET_TYPE_NONE, 0, 0, 1},
    //VOLTA_CLK_DOMAIN_GV11B_HWPMMUX will be a dummy id that is used to identify the HWPM signals profiled via SMPC.
    //We require this so that we can restrict profiling these signals with pure HWPM or pure SMPC signals
    //Currently there is no way to avoid this except having check at domain level, also it is possible that we will allow pure HWPM signals with pure SMPC.
    //Internally this domain id will be mapped to VOLTA_CLK_DOMAIN_GV11B_GPCTPC
    { VOLTA_CLK_DOMAIN_GV11B_HWPMMUX, volta_clk_domain_gv100_hwpmmux_enc_str_1, CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX, { { (void *)PerfSignalTableGV100_hwpmmux, PERF_SIG_TABLE_TYPE_HWPMMUX } }, 0, 0, 0, PM_CHIPLET_TYPE_GPC, 0, 0, 1 },
    { VOLTA_CLK_DOMAIN_GV11B_SYS0, volta_clk_domain_gv11b_sys0_enc_str_1, CUPROF_EVENT_COLLECTION_METHOD_HWPM, { { (void *)PerfSignalTableGV11B_sys0, PERF_SIG_TABLE_TYPE_HWPM }, { (void *)PerfSignalTableGV11B_sys0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1 } }, 0, 0, 0, PM_CHIPLET_TYPE_SYS, 0, 0, 2 },
    { VOLTA_CLK_DOMAIN_GV11B_GPC0, volta_clk_domain_gv100_gpc0_enc_str_1, CUPROF_EVENT_COLLECTION_METHOD_HWPM, { { (void *)PerfSignalTableGV11B_gpc0, PERF_SIG_TABLE_TYPE_HWPM }, { (void *)PerfSignalTableGV100_gpc0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1 } }, 0, 0, 0, PM_CHIPLET_TYPE_GPC, 0, 0, 2 },
    { VOLTA_CLK_DOMAIN_GV11B_GPC1, volta_clk_domain_gv100_gpc1_enc_str_1, CUPROF_EVENT_COLLECTION_METHOD_HWPM, { { (void *)PerfSignalTableGV11B_gpc1, PERF_SIG_TABLE_TYPE_HWPM }, { (void *)PerfSignalTableGV100_gpc1_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1 } }, 0, 0, 0, PM_CHIPLET_TYPE_GPC, 0, 0, 2 },
    { VOLTA_CLK_DOMAIN_GV11B_SYS1, volta_clk_domain_gv100_sys1_enc_str_1, CUPROF_EVENT_COLLECTION_METHOD_HWPM, { { (void *)PerfSignalTableGV11B_sys1, PERF_SIG_TABLE_TYPE_HWPM } },                                                                               0, 0, 0, PM_CHIPLET_TYPE_SYS, 0, 0, 1 }
};
#endif

SignalDescriptionTable pVoltaSignalDescriptionArray[] = {
#if NVCFG(GLOBAL_ARCH_VOLTA)
#if CU_VOLTA_PROFILE_SM_SIGNALS_VIA_HWPM
    {VOLTA_HWPM_TRAP_IN_TRAP, volta_hwpm_trap_in_trap_enc_str_1, volta_hwpm_trap_in_trap_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_trap_in_trap_enc_str_1},
    {VOLTA_HWPM_TRAP_COUNT, volta_hwpm_trap_count_enc_str_1, volta_hwpm_trap_count_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_trap_count_enc_str_1 },

    {VOLTA_HWPM_TOTAL_CTA_LAUNCHED, volta_hwpm_total_cta_launched_enc_str_1, volta_hwpm_total_cta_launched_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_total_cta_launched_enc_str_1 },
    {VOLTA_HWPM_CTA_LAUNCHED, volta_hwpm_cta_launched_enc_str_1, volta_hwpm_cta_launched_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_cta_launched_enc_str_4},
    {VOLTA_HWPM_CTA_RESTORED, volta_hwpm_cta_restored_enc_str_1, volta_hwpm_cta_restored_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_cta_restored_enc_str_1},
    {VOLTA_HWPM_THREADS_LAUNCHED_0, volta_hwpm_threads_launched_0_enc_str_1, volta_hwpm_threads_launched_0_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_threads_launched_0_enc_str_4},
    {VOLTA_HWPM_THREADS_LAUNCHED_1, volta_hwpm_threads_launched_1_enc_str_1, volta_hwpm_threads_launched_1_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_threads_launched_1_enc_str_4},
    {VOLTA_HWPM_THREADS_LAUNCHED_2, volta_hwpm_threads_launched_2_enc_str_1, volta_hwpm_threads_launched_2_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_threads_launched_2_enc_str_4},
    {VOLTA_HWPM_THREADS_LAUNCHED_3, volta_hwpm_threads_launched_3_enc_str_1, volta_hwpm_threads_launched_3_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_threads_launched_3_enc_str_4},
    {VOLTA_HWPM_WARPS_LAUNCHED_0, volta_hwpm_warps_launched_0_enc_str_1, volta_hwpm_warps_launched_0_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_warps_launched_0_enc_str_4},
    {VOLTA_HWPM_WARPS_LAUNCHED_1, volta_hwpm_warps_launched_1_enc_str_1, volta_hwpm_warps_launched_1_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_warps_launched_1_enc_str_4},
    {VOLTA_HWPM_WARPS_LAUNCHED_2, volta_hwpm_warps_launched_2_enc_str_1, volta_hwpm_warps_launched_2_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_warps_launched_2_enc_str_4},
    {VOLTA_HWPM_WARPS_LAUNCHED_3, volta_hwpm_warps_launched_3_enc_str_1, volta_hwpm_warps_launched_3_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_warps_launched_3_enc_str_4},

    {VOLTA_HWPM_INST_EXECUTED_HMMA_OPS_S0, volta_hwpm_inst_executed_hmma_ops_s0_enc_str_1, volta_hwpm_inst_executed_hmma_ops_s0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_hmma_ops_s0_enc_str_1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_OPS_S1, volta_hwpm_inst_executed_hmma_ops_s1_enc_str_1, volta_hwpm_inst_executed_hmma_ops_s1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_hmma_ops_s1_enc_str_1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_OPS_S2, volta_hwpm_inst_executed_hmma_ops_s2_enc_str_1, volta_hwpm_inst_executed_hmma_ops_s2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_hmma_ops_s2_enc_str_1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_OPS_S3, volta_hwpm_inst_executed_hmma_ops_s3_enc_str_1, volta_hwpm_inst_executed_hmma_ops_s3_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_hmma_ops_s3_enc_str_1},

    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP16_OPS_S0, volta_hwpm_inst_executed_hmma_fp16_ops_s0_enc_str_1, volta_hwpm_inst_executed_hmma_fp16_ops_s0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_hmma_fp16_ops_s0_enc_str_1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP16_OPS_S1, volta_hwpm_inst_executed_hmma_fp16_ops_s1_enc_str_1, volta_hwpm_inst_executed_hmma_fp16_ops_s1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_hmma_fp16_ops_s1_enc_str_1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP16_OPS_S2, volta_hwpm_inst_executed_hmma_fp16_ops_s2_enc_str_1, volta_hwpm_inst_executed_hmma_fp16_ops_s2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_hmma_fp16_ops_s2_enc_str_1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP16_OPS_S3, volta_hwpm_inst_executed_hmma_fp16_ops_s3_enc_str_1, volta_hwpm_inst_executed_hmma_fp16_ops_s3_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_hmma_fp16_ops_s3_enc_str_1},

    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP32_OPS_S0, volta_hwpm_inst_executed_hmma_fp32_ops_s0_enc_str_1, volta_hwpm_inst_executed_hmma_fp32_ops_s0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_hmma_fp32_ops_s0_enc_str_1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP32_OPS_S1, volta_hwpm_inst_executed_hmma_fp32_ops_s1_enc_str_1, volta_hwpm_inst_executed_hmma_fp32_ops_s1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_hmma_fp32_ops_s1_enc_str_1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP32_OPS_S2, volta_hwpm_inst_executed_hmma_fp32_ops_s2_enc_str_1, volta_hwpm_inst_executed_hmma_fp32_ops_s2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_hmma_fp32_ops_s2_enc_str_1},
    {VOLTA_HWPM_INST_EXECUTED_HMMA_FP32_OPS_S3, volta_hwpm_inst_executed_hmma_fp32_ops_s3_enc_str_1, volta_hwpm_inst_executed_hmma_fp32_ops_s3_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_hmma_fp32_ops_s3_enc_str_1},

    {VOLTA_TENSOR_PIPE_ACTIVE_CYCLES_S0, volta_tensor_pipe_active_cycles_s0_enc_str_1, volta_tensor_pipe_active_cycles_s0_enc_str_2, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_tensor_pipe_active_cycles_s0_enc_str_3},
    {VOLTA_TENSOR_PIPE_ACTIVE_CYCLES_S1, volta_tensor_pipe_active_cycles_s1_enc_str_1, volta_tensor_pipe_active_cycles_s1_enc_str_2, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_tensor_pipe_active_cycles_s1_enc_str_3},
    {VOLTA_TENSOR_PIPE_ACTIVE_CYCLES_S2, volta_tensor_pipe_active_cycles_s2_enc_str_1, volta_tensor_pipe_active_cycles_s2_enc_str_2, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_tensor_pipe_active_cycles_s2_enc_str_3},
    {VOLTA_TENSOR_PIPE_ACTIVE_CYCLES_S3, volta_tensor_pipe_active_cycles_s3_enc_str_1, volta_tensor_pipe_active_cycles_s3_enc_str_2, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_tensor_pipe_active_cycles_s3_enc_str_3},

    {VOLTA_HWPM_INST_EXECUTED_HFMA_OPS_S0, volta_hwpm_inst_executed_hfma_ops_s0_enc_str_1, volta_hwpm_inst_executed_hfma_ops_s0_enc_str_2, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_hfma_ops_s0_enc_str_3},
    {VOLTA_HWPM_INST_EXECUTED_HFMA_OPS_S1, volta_hwpm_inst_executed_hfma_ops_s1_enc_str_1, volta_hwpm_inst_executed_hfma_ops_s1_enc_str_2, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_hfma_ops_s1_enc_str_3},
    {VOLTA_HWPM_INST_EXECUTED_HFMA_OPS_S2, volta_hwpm_inst_executed_hfma_ops_s2_enc_str_1, volta_hwpm_inst_executed_hfma_ops_s2_enc_str_2, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_hfma_ops_s2_enc_str_3},
    {VOLTA_HWPM_INST_EXECUTED_HFMA_OPS_S3, volta_hwpm_inst_executed_hfma_ops_s3_enc_str_1, volta_hwpm_inst_executed_hfma_ops_s3_enc_str_2, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_hfma_ops_s3_enc_str_3},

    {VOLTA_HWPM_INST_EXECUTED_FMA64LITE_PIPE_S0, volta_hwpm_inst_executed_fma64lite_pipe_s0_enc_str_1, volta_hwpm_inst_executed_fma64lite_pipe_s0_enc_str_2, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_fma64lite_pipe_s0_enc_str_3},
    {VOLTA_HWPM_INST_EXECUTED_FMA64LITE_PIPE_S1, volta_hwpm_inst_executed_fma64lite_pipe_s1_enc_str_1, volta_hwpm_inst_executed_fma64lite_pipe_s1_enc_str_2, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_fma64lite_pipe_s1_enc_str_3},
    {VOLTA_HWPM_INST_EXECUTED_FMA64LITE_PIPE_S2, volta_hwpm_inst_executed_fma64lite_pipe_s2_enc_str_1, volta_hwpm_inst_executed_fma64lite_pipe_s2_enc_str_2, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_fma64lite_pipe_s2_enc_str_3},
    {VOLTA_HWPM_INST_EXECUTED_FMA64LITE_PIPE_S3, volta_hwpm_inst_executed_fma64lite_pipe_s3_enc_str_1, volta_hwpm_inst_executed_fma64lite_pipe_s3_enc_str_2, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_fma64lite_pipe_s3_enc_str_3},

    {VOLTA_HWPM_INST_EXECUTED_FMA_PIPE_S0, volta_hwpm_inst_executed_fma_pipe_s0_enc_str_1, volta_hwpm_inst_executed_fma_pipe_s0_enc_str_2, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_fma_pipe_s0_enc_str_3},
    {VOLTA_HWPM_INST_EXECUTED_FMA_PIPE_S1, volta_hwpm_inst_executed_fma_pipe_s1_enc_str_1, volta_hwpm_inst_executed_fma_pipe_s1_enc_str_2, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_fma_pipe_s1_enc_str_3},
    {VOLTA_HWPM_INST_EXECUTED_FMA_PIPE_S2, volta_hwpm_inst_executed_fma_pipe_s2_enc_str_1, volta_hwpm_inst_executed_fma_pipe_s2_enc_str_2, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_fma_pipe_s2_enc_str_3},
    {VOLTA_HWPM_INST_EXECUTED_FMA_PIPE_S3, volta_hwpm_inst_executed_fma_pipe_s3_enc_str_1, volta_hwpm_inst_executed_fma_pipe_s3_enc_str_2, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_fma_pipe_s3_enc_str_3},

    {VOLTA_HWPM_TOTAL_WARPS_LAUNCHED_0, volta_hwpm_total_warps_launched_0_enc_str_1, volta_hwpm_total_warps_launched_0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_total_warps_launched_0_enc_str_1},
    {VOLTA_HWPM_TOTAL_WARPS_LAUNCHED_1, volta_hwpm_total_warps_launched_1_enc_str_1, volta_hwpm_total_warps_launched_1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_total_warps_launched_1_enc_str_1},
    {VOLTA_HWPM_TOTAL_WARPS_LAUNCHED_2, volta_hwpm_total_warps_launched_2_enc_str_1, volta_hwpm_total_warps_launched_2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_total_warps_launched_2_enc_str_1},
    {VOLTA_HWPM_TOTAL_WARPS_LAUNCHED_3, volta_hwpm_total_warps_launched_3_enc_str_1, volta_hwpm_total_warps_launched_3_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_total_warps_launched_3_enc_str_1},

    {VOLTA_HWPM_RESTORE_WARPS_LAUNCHED_0, volta_hwpm_restore_warps_launched_0_enc_str_1, volta_hwpm_restore_warps_launched_0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_restore_warps_launched_0_enc_str_1},
    {VOLTA_HWPM_RESTORE_WARPS_LAUNCHED_1, volta_hwpm_restore_warps_launched_1_enc_str_1, volta_hwpm_restore_warps_launched_1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_restore_warps_launched_1_enc_str_1},
    {VOLTA_HWPM_RESTORE_WARPS_LAUNCHED_2, volta_hwpm_restore_warps_launched_2_enc_str_1, volta_hwpm_restore_warps_launched_2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_restore_warps_launched_2_enc_str_1},
    {VOLTA_HWPM_RESTORE_WARPS_LAUNCHED_3, volta_hwpm_restore_warps_launched_3_enc_str_1, volta_hwpm_restore_warps_launched_3_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_restore_warps_launched_3_enc_str_1},

    {VOLTA_SMQCTL_SHARED_LD_128B_ADDRESS_UNIFORM_S0, volta_smqctl_shared_ld_128b_address_uniform_s0_enc_str_1, volta_smqctl_shared_ld_128b_address_uniform_s0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_smqctl_shared_ld_128b_address_uniform_s0_enc_str_1},
    {VOLTA_SMQCTL_SHARED_LD_128B_ADDRESS_UNIFORM_S1, volta_smqctl_shared_ld_128b_address_uniform_s1_enc_str_1, volta_smqctl_shared_ld_128b_address_uniform_s1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_smqctl_shared_ld_128b_address_uniform_s1_enc_str_1},
    {VOLTA_SMQCTL_SHARED_LD_128B_ADDRESS_UNIFORM_S2, volta_smqctl_shared_ld_128b_address_uniform_s2_enc_str_1, volta_smqctl_shared_ld_128b_address_uniform_s2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_smqctl_shared_ld_128b_address_uniform_s2_enc_str_1},
    {VOLTA_SMQCTL_SHARED_LD_128B_ADDRESS_UNIFORM_S3, volta_smqctl_shared_ld_128b_address_uniform_s3_enc_str_1, volta_smqctl_shared_ld_128b_address_uniform_s3_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_smqctl_shared_ld_128b_address_uniform_s3_enc_str_1},

    {VOLTA_HWPM_ACTIVE_CYCLES, volta_hwpm_active_cycles_enc_str_1, volta_hwpm_active_cycles_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_active_cycles_enc_str_4},
    {VOLTA_HWPM_ACTIVE_WARPS, volta_hwpm_active_warps_enc_str_1, volta_hwpm_active_warps_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_active_warps_enc_str_4},
    {VOLTA_HWPM_SHARED_LD_MEM_DIVERGENCE_REPLAYS_H0, volta_hwpm_shared_ld_mem_divergence_replays_h0_enc_str_1, volta_hwpm_shared_ld_mem_divergence_replays_h0_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_hwpm_shared_ld_mem_divergence_replays_h0_enc_str_1},
    {VOLTA_HWPM_SHARED_ST_MEM_DIVERGENCE_REPLAYS_H0, volta_hwpm_shared_st_mem_divergence_replays_h0_enc_str_1, volta_hwpm_shared_st_mem_divergence_replays_h0_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_hwpm_shared_st_mem_divergence_replays_h0_enc_str_1},
    {VOLTA_HWPM_SHARED_LD_TRANSACTIONS_H0,           volta_hwpm_shared_ld_transactions_h0_enc_str_1,           volta_hwpm_shared_ld_transactions_h0_enc_str_1,           CUPROF_EVENT_CATEGORY_MEMORY, volta_hwpm_shared_ld_transactions_h0_enc_str_1},
    {VOLTA_HWPM_SHARED_ST_TRANSACTIONS_H0,           volta_hwpm_shared_st_transactions_h0_enc_str_1,           volta_hwpm_shared_st_transactions_h0_enc_str_1,           CUPROF_EVENT_CATEGORY_MEMORY, volta_hwpm_shared_st_transactions_h0_enc_str_1},
    {VOLTA_HWPM_SHARED_LD_MEM_DIVERGENCE_REPLAYS_H1, volta_hwpm_shared_ld_mem_divergence_replays_h1_enc_str_1, volta_hwpm_shared_ld_mem_divergence_replays_h1_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_hwpm_shared_ld_mem_divergence_replays_h1_enc_str_1},
    {VOLTA_HWPM_SHARED_ST_MEM_DIVERGENCE_REPLAYS_H1, volta_hwpm_shared_st_mem_divergence_replays_h1_enc_str_1, volta_hwpm_shared_st_mem_divergence_replays_h1_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_hwpm_shared_st_mem_divergence_replays_h1_enc_str_1},
    {VOLTA_HWPM_SHARED_LD_TRANSACTIONS_H1,           volta_hwpm_shared_ld_transactions_h1_enc_str_1,           volta_hwpm_shared_ld_transactions_h1_enc_str_1,           CUPROF_EVENT_CATEGORY_MEMORY, volta_hwpm_shared_ld_transactions_h1_enc_str_1},
    {VOLTA_HWPM_SHARED_ST_TRANSACTIONS_H1,           volta_hwpm_shared_st_transactions_h1_enc_str_1,           volta_hwpm_shared_st_transactions_h1_enc_str_1,           CUPROF_EVENT_CATEGORY_MEMORY, volta_hwpm_shared_st_transactions_h1_enc_str_1},

    {VOLTA_HWPMMUX_CTA_LAUNCHED, volta_hwpmmux_cta_launched_enc_str_1, volta_hwpmmux_cta_launched_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_cta_launched_enc_str_4},
    {VOLTA_HWPMMUX_THREADS_LAUNCHED, volta_hwpmmux_threads_launched_enc_str_1, volta_hwpmmux_threads_launched_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_threads_launched_0_enc_str_4},
    {VOLTA_HWPMMUX_WARPS_LAUNCHED, volta_hwpmmux_warps_launched_enc_str_1, volta_hwpmmux_warps_launched_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_warps_launched_0_enc_str_4},
    {VOLTA_HWPMMUX_ACTIVE_CYCLES, volta_hwpmmux_active_cycles_enc_str_1, volta_hwpmmux_active_cycles_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_active_cycles_enc_str_4},
    {VOLTA_HWPMMUX_ACTIVE_WARPS, volta_hwpmmux_active_warps_enc_str_1, volta_hwpmmux_active_warps_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_active_warps_enc_str_4},
#endif

    {VOLTA_FB_SUBP0_DRAMC_READ, volta_fb_subp0_dramc_read_enc_str_1, volta_fb_subp0_dramc_read_enc_str_3, CUPROF_EVENT_CATEGORY_MEMORY, volta_fb_subp0_dramc_read_enc_str_4},
    {VOLTA_FB_SUBP1_DRAMC_READ, volta_fb_subp1_dramc_read_enc_str_1, volta_fb_subp1_dramc_read_enc_str_3, CUPROF_EVENT_CATEGORY_MEMORY, volta_fb_subp1_dramc_read_enc_str_4},
    {VOLTA_FB_SUBP0_DRAMC_WRITE, volta_fb_subp0_dramc_write_enc_str_1, volta_fb_subp0_dramc_write_enc_str_3, CUPROF_EVENT_CATEGORY_MEMORY, volta_fb_subp0_dramc_write_enc_str_4},
    {VOLTA_FB_SUBP1_DRAMC_WRITE, volta_fb_subp1_dramc_write_enc_str_1, volta_fb_subp1_dramc_write_enc_str_3, CUPROF_EVENT_CATEGORY_MEMORY, volta_fb_subp1_dramc_write_enc_str_4},

    {VOLTA_LTC0_WRITE_MISS_SECTORS, volta_ltc0_write_miss_sectors_enc_str_1, volta_ltc0_write_miss_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_write_miss_sectors_enc_str_4},
    {VOLTA_LTC1_WRITE_MISS_SECTORS, volta_ltc1_write_miss_sectors_enc_str_1, volta_ltc1_write_miss_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc1_write_miss_sectors_enc_str_4},

    {VOLTA_LTC0_READ_MISS_SECTORS, volta_ltc0_read_miss_sectors_enc_str_1, volta_ltc0_read_miss_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_read_miss_sectors_enc_str_4},
    {VOLTA_LTC1_READ_MISS_SECTORS, volta_ltc1_read_miss_sectors_enc_str_1, volta_ltc1_read_miss_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc1_read_miss_sectors_enc_str_4},

    {VOLTA_LTC0_READ_TEX_SECTORS_FBP, volta_ltc0_read_tex_sectors_fbp_enc_str_1, volta_ltc0_read_tex_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_read_tex_sectors_fbp_enc_str_4},
    {VOLTA_LTC1_READ_TEX_SECTORS_FBP, volta_ltc1_read_tex_sectors_fbp_enc_str_1, volta_ltc1_read_tex_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc1_read_tex_sectors_fbp_enc_str_4},

    {VOLTA_LTC0_WRITE_TEX_SECTORS_FBP, volta_ltc0_write_tex_sectors_fbp_enc_str_1, volta_ltc0_write_tex_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_write_tex_sectors_fbp_enc_str_4},
    {VOLTA_LTC1_WRITE_TEX_SECTORS_FBP, volta_ltc1_write_tex_sectors_fbp_enc_str_1, volta_ltc1_write_tex_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc1_write_tex_sectors_fbp_enc_str_4},

    {VOLTA_LTC0_READ_TEX_HIT_SECTORS_FBP, volta_ltc0_read_tex_hit_sectors_fbp_enc_str_1, volta_ltc0_read_tex_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_read_tex_hit_sectors_fbp_enc_str_4},
    {VOLTA_LTC1_READ_TEX_HIT_SECTORS_FBP, volta_ltc1_read_tex_hit_sectors_fbp_enc_str_1, volta_ltc1_read_tex_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc1_read_tex_hit_sectors_fbp_enc_str_4},

    {VOLTA_LTC0_WRITE_TEX_HIT_SECTORS_FBP, volta_ltc0_write_tex_hit_sectors_fbp_enc_str_1, volta_ltc0_write_tex_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_write_tex_hit_sectors_fbp_enc_str_4},
    {VOLTA_LTC1_WRITE_TEX_HIT_SECTORS_FBP, volta_ltc1_write_tex_hit_sectors_fbp_enc_str_1, volta_ltc1_write_tex_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc1_write_tex_hit_sectors_fbp_enc_str_4},

    // ltc_read_sysmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_sysmem
    { VOLTA_LTC0_READ_SYSMEM_SECTORS_FBP,      volta_ltc0_read_sysmem_sectors_fbp_enc_str_1, volta_ltc0_read_sysmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_read_sysmem_sectors_fbp_enc_str_4},
    { VOLTA_LTC1_READ_SYSMEM_SECTORS_FBP,      volta_ltc1_read_sysmem_sectors_fbp_enc_str_1, volta_ltc1_read_sysmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc1_read_sysmem_sectors_fbp_enc_str_4},

    // ltc_write_sysmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_sysmem
    { VOLTA_LTC0_WRITE_SYSMEM_SECTORS_FBP,      volta_ltc0_write_sysmem_sectors_fbp_enc_str_1, volta_ltc0_write_sysmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_write_sysmem_sectors_fbp_enc_str_4},
    { VOLTA_LTC1_WRITE_SYSMEM_SECTORS_FBP,      volta_ltc1_write_sysmem_sectors_fbp_enc_str_1, volta_ltc1_write_sysmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc1_write_sysmem_sectors_fbp_enc_str_4},
    { VOLTA_LTC0_READ_SYSMEM_HIT_SECTORS_FBP, volta_ltc0_read_sysmem_hit_sectors_fbp_enc_str_1, volta_ltc0_read_sysmem_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_read_sysmem_hit_sectors_fbp_enc_str_1},
    { VOLTA_LTC1_READ_SYSMEM_HIT_SECTORS_FBP, volta_ltc1_read_sysmem_hit_sectors_fbp_enc_str_1, volta_ltc1_read_sysmem_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc1_read_sysmem_hit_sectors_fbp_enc_str_1},
    { VOLTA_LTC0_WRITE_SYSMEM_HIT_SECTORS_FBP, volta_ltc0_write_sysmem_hit_sectors_fbp_enc_str_1, volta_ltc0_write_sysmem_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_write_sysmem_hit_sectors_fbp_enc_str_1},
    { VOLTA_LTC1_WRITE_SYSMEM_HIT_SECTORS_FBP, volta_ltc1_write_sysmem_hit_sectors_fbp_enc_str_1, volta_ltc1_write_sysmem_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc1_write_sysmem_hit_sectors_fbp_enc_str_1},
    { VOLTA_LTC0_READ_SYSMEM_MISS_SECTORS_FBP, volta_ltc0_read_sysmem_miss_sectors_fbp_enc_str_1, volta_ltc0_read_sysmem_miss_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_read_sysmem_miss_sectors_fbp_enc_str_1},
    { VOLTA_LTC1_READ_SYSMEM_MISS_SECTORS_FBP, volta_ltc1_read_sysmem_miss_sectors_fbp_enc_str_1, volta_ltc1_read_sysmem_miss_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc1_read_sysmem_miss_sectors_fbp_enc_str_1},
    { VOLTA_LTC0_WRITE_SYSMEM_MISS_SECTORS_FBP, volta_ltc0_write_sysmem_miss_sectors_fbp_enc_str_1, volta_ltc0_write_sysmem_miss_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_write_sysmem_miss_sectors_fbp_enc_str_1},
    { VOLTA_LTC1_WRITE_SYSMEM_MISS_SECTORS_FBP, volta_ltc1_write_sysmem_miss_sectors_fbp_enc_str_1, volta_ltc1_write_sysmem_miss_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc1_write_sysmem_miss_sectors_fbp_enc_str_1},
    

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { VOLTA_LTC0_TOTAL_READ_SECTORS_FBP,      volta_ltc0_total_read_sectors_fbp_enc_str_1, volta_ltc0_total_read_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_total_read_sectors_fbp_enc_str_4},
    { VOLTA_LTC1_TOTAL_READ_SECTORS_FBP,      volta_ltc1_total_read_sectors_fbp_enc_str_1, volta_ltc1_total_read_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc1_total_read_sectors_fbp_enc_str_4},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { VOLTA_LTC0_TOTAL_WRITE_SECTORS_FBP,      volta_ltc0_total_write_sectors_fbp_enc_str_1, volta_ltc0_total_write_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_total_write_sectors_fbp_enc_str_4},
    { VOLTA_LTC1_TOTAL_WRITE_SECTORS_FBP,      volta_ltc1_total_write_sectors_fbp_enc_str_1, volta_ltc1_total_write_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc1_total_write_sectors_fbp_enc_str_4},

    {VOLTA_LTC0_DIRTY_EVENT, volta_ltc0_dirty_event_enc_str_1, volta_ltc0_dirty_event_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_dirty_event_enc_str_2},
    {VOLTA_LTC1_DIRTY_EVENT, volta_ltc1_dirty_event_enc_str_1, volta_ltc1_dirty_event_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc1_dirty_event_enc_str_2},
    {VOLTA_LTC0_FB_FILL, volta_ltc0_fb_fill_enc_str_1, volta_ltc0_fb_fill_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_fb_fill_enc_str_2},
    {VOLTA_LTC1_FB_FILL, volta_ltc1_fb_fill_enc_str_1, volta_ltc1_fb_fill_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc1_fb_fill_enc_str_2},
    {VOLTA_LTC0_SYS_FILL, volta_ltc0_sys_fill_enc_str_1, volta_ltc0_sys_fill_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_sys_fill_enc_str_2},
    {VOLTA_LTC1_SYS_FILL, volta_ltc1_sys_fill_enc_str_1, volta_ltc1_sys_fill_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc1_sys_fill_enc_str_2},

    {VOLTA_MMU_HUB_TLB_HIT, volta_mmu_hub_tlb_hit_enc_str_1, volta_mmu_hub_tlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_hub_tlb_hit_enc_str_4},
    {VOLTA_MMU_HUB_TLB_MISS, volta_mmu_hub_tlb_miss_enc_str_1, volta_mmu_hub_tlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_hub_tlb_miss_enc_str_4},
    {VOLTA_MMU_HUB_TLB_MISS_INT, volta_mmu_hub_tlb_miss_int_enc_str_1, volta_mmu_hub_tlb_miss_int_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_fill_pte_miss_int_enc_str_4},
    {VOLTA_MMU_FILL_PTE_HIT, volta_mmu_fill_pte_hit_enc_str_1, volta_mmu_fill_pte_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_fill_pte_hit_enc_str_4},
    {VOLTA_MMU_FILL_PTE_MISS, volta_mmu_fill_pte_miss_enc_str_1, volta_mmu_fill_pte_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_fill_pte_miss_enc_str_4},
    {VOLTA_MMU_FILL_PTE_MISS_INT, volta_mmu_fill_pte_miss_int_enc_str_1, volta_mmu_fill_pte_miss_int_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_fill_pte_miss_int_enc_str_4},
    {VOLTA_MMU_FILL_PDE_HIT, volta_mmu_fill_pde_hit_enc_str_1, volta_mmu_fill_pde_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_fill_pde_hit_enc_str_4},
    {VOLTA_MMU_FILL_PDE_MISS, volta_mmu_fill_pde_miss_enc_str_1, volta_mmu_fill_pde_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_fill_pde_miss_enc_str_4},

    {VOLTA_FB_SUBP0_DRAM_ACTIVATES, volta_fb_subp0_dram_activates_enc_str_1, volta_fb_subp0_dram_activates_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_fb_subp0_dram_activates_enc_str_4},
    {VOLTA_FB_SUBP1_DRAM_ACTIVATES, volta_fb_subp1_dram_activates_enc_str_1, volta_fb_subp1_dram_activates_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_fb_subp1_dram_activates_enc_str_4},

    {VOLTA_FB1_SUBP0_DRAM_ACTIVATES, volta_fb1_subp0_dram_activates_enc_str_1, volta_fb1_subp0_dram_activates_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_fb1_subp0_dram_activates_enc_str_4},
    {VOLTA_FB1_SUBP1_DRAM_ACTIVATES, volta_fb1_subp1_dram_activates_enc_str_1, volta_fb1_subp1_dram_activates_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_fb1_subp1_dram_activates_enc_str_4},

    // Software counters to count shared load/store instructions
    {VOLTA_SW_COUNTER_SLD8BIT_INST,volta_sw_counter_sld8bit_inst_enc_str_1, volta_sw_counter_sld8bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,volta_sw_counter_sld8bit_inst_enc_str_4},
    {VOLTA_SW_COUNTER_SLD16BIT_INST,volta_sw_counter_sld16bit_inst_enc_str_1, volta_sw_counter_sld16bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,volta_sw_counter_sld16bit_inst_enc_str_4},
    {VOLTA_SW_COUNTER_SLD32BIT_INST,volta_sw_counter_sld32bit_inst_enc_str_1, volta_sw_counter_sld32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,volta_sw_counter_sld32bit_inst_enc_str_4},
    {VOLTA_SW_COUNTER_SLD64BIT_INST,volta_sw_counter_sld64bit_inst_enc_str_1, volta_sw_counter_sld64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,volta_sw_counter_sld64bit_inst_enc_str_4},
    {VOLTA_SW_COUNTER_SLD128BIT_INST,volta_sw_counter_sld128bit_inst_enc_str_1, volta_sw_counter_sld128bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,volta_sw_counter_sld128bit_inst_enc_str_4},
    {VOLTA_SW_COUNTER_SST8BIT_INST,volta_sw_counter_sst8bit_inst_enc_str_1, volta_sw_counter_sst8bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,volta_sw_counter_sst8bit_inst_enc_str_4},
    {VOLTA_SW_COUNTER_SST16BIT_INST,volta_sw_counter_sst16bit_inst_enc_str_1, volta_sw_counter_sst16bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,volta_sw_counter_sst16bit_inst_enc_str_4},
    {VOLTA_SW_COUNTER_SST32BIT_INST,volta_sw_counter_sst32bit_inst_enc_str_1, volta_sw_counter_sst32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,volta_sw_counter_sst32bit_inst_enc_str_4},
    {VOLTA_SW_COUNTER_SST64BIT_INST,volta_sw_counter_sst64bit_inst_enc_str_1, volta_sw_counter_sst64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,volta_sw_counter_sst64bit_inst_enc_str_4},
    {VOLTA_SW_COUNTER_SST128BIT_INST,volta_sw_counter_sst128bit_inst_enc_str_1, volta_sw_counter_sst128bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,volta_sw_counter_sst128bit_inst_enc_str_4},

    // Software counters to count floating point instructions
    {VOLTA_SW_COUNTER_FADD_INST, volta_sw_counter_fadd_inst_enc_str_1, volta_sw_counter_fadd_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_fadd_inst_enc_str_4},
    {VOLTA_SW_COUNTER_FMUL_INST, volta_sw_counter_fmul_inst_enc_str_1, volta_sw_counter_fmul_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_fmul_inst_enc_str_4},
    {VOLTA_SW_COUNTER_FFMA_INST, volta_sw_counter_ffma_inst_enc_str_1, volta_sw_counter_ffma_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_ffma_inst_enc_str_4},
    {VOLTA_SW_COUNTER_DADD_INST, volta_sw_counter_dadd_inst_enc_str_1, volta_sw_counter_dadd_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_dadd_inst_enc_str_4},
    {VOLTA_SW_COUNTER_DMUL_INST, volta_sw_counter_dmul_inst_enc_str_1, volta_sw_counter_dmul_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_dmul_inst_enc_str_4},
    {VOLTA_SW_COUNTER_DFMA_INST, volta_sw_counter_dfma_inst_enc_str_1, volta_sw_counter_dfma_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_dfma_inst_enc_str_4},
    {VOLTA_SW_COUNTER_COS_INST, volta_sw_counter_cos_inst_enc_str_1, volta_sw_counter_cos_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_cos_inst_enc_str_4},
    {VOLTA_SW_COUNTER_EX2_INST, volta_sw_counter_ex2_inst_enc_str_1, volta_sw_counter_ex2_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_ex2_inst_enc_str_4},
    {VOLTA_SW_COUNTER_LG2_INST, volta_sw_counter_lg2_inst_enc_str_1, volta_sw_counter_lg2_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_lg2_inst_enc_str_4},
    {VOLTA_SW_COUNTER_RCP_INST, volta_sw_counter_rcp_inst_enc_str_1, volta_sw_counter_rcp_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_rcp_inst_enc_str_4},
    {VOLTA_SW_COUNTER_RSQ_INST, volta_sw_counter_rsq_inst_enc_str_1, volta_sw_counter_rsq_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_rsq_inst_enc_str_4},
    {VOLTA_SW_COUNTER_SIN_INST, volta_sw_counter_sin_inst_enc_str_1, volta_sw_counter_sin_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_sin_inst_enc_str_4},
    {VOLTA_SW_COUNTER_SQRT_INST, volta_sw_counter_sqrt_inst_enc_str_1, volta_sw_counter_sqrt_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_sqrt_inst_enc_str_4},
    {VOLTA_SW_COUNTER_HADD_INST, volta_sw_counter_hadd_inst_enc_str_1, volta_sw_counter_hadd_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_hadd_inst_enc_str_4},
    {VOLTA_SW_COUNTER_HMUL_INST, volta_sw_counter_hmul_inst_enc_str_1, volta_sw_counter_hmul_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_hmul_inst_enc_str_4},
    {VOLTA_SW_COUNTER_HFMA_INST, volta_sw_counter_hfma_inst_enc_str_1, volta_sw_counter_hfma_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_hfma_inst_enc_str_4},

    // Software counters to count the number of instructions executed from a particular instruction class:
    // Software counters to count the number of instructions executed from a particular instruction class:
    { VOLTA_SW_COUNTER_INSTR_CLASS_FP_16,                       volta_sw_counter_instr_class_fp_16_enc_str_1                      , volta_sw_counter_instr_class_fp_16_enc_str_1                      , CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_instr_class_fp_16_enc_str_4},
    { VOLTA_SW_COUNTER_INSTR_CLASS_FP_32,                       volta_sw_counter_instr_class_fp_32_enc_str_1                      , volta_sw_counter_instr_class_fp_32_enc_str_1                      , CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_instr_class_fp_32_enc_str_4},
    { VOLTA_SW_COUNTER_INSTR_CLASS_FP_64,                       volta_sw_counter_instr_class_fp_64_enc_str_1                      , volta_sw_counter_instr_class_fp_64_enc_str_1                      , CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_instr_class_fp_64_enc_str_4},
    { VOLTA_SW_COUNTER_INSTR_CLASS_INTEGER,                     volta_sw_counter_instr_class_integer_enc_str_1                    , volta_sw_counter_instr_class_integer_enc_str_1                    , CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_instr_class_integer_enc_str_4},
    { VOLTA_SW_COUNTER_INSTR_CLASS_BIT_CONVERT,                 volta_sw_counter_instr_class_bit_convert_enc_str_1                , volta_sw_counter_instr_class_bit_convert_enc_str_1                , CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_instr_class_bit_convert_enc_str_4},
    { VOLTA_SW_COUNTER_INSTR_CLASS_CONTROL,                     volta_sw_counter_instr_class_control_enc_str_1                    , volta_sw_counter_instr_class_control_enc_str_1                    , CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_instr_class_control_enc_str_4},
    { VOLTA_SW_COUNTER_INSTR_CLASS_COMPUTE_LD_ST,               volta_sw_counter_instr_class_compute_ld_st_enc_str_1              , volta_sw_counter_instr_class_compute_ld_st_enc_str_1              , CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_instr_class_compute_ld_st_enc_str_4},
    { VOLTA_SW_COUNTER_INSTR_CLASS_MISCELLANEOUS,               volta_sw_counter_instr_class_miscellaneous_enc_str_1              , volta_sw_counter_instr_class_miscellaneous_enc_str_1              , CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_instr_class_miscellaneous_enc_str_4},
    { VOLTA_SW_COUNTER_INSTR_CLASS_INTER_THREAD_COMMUNICATION,  volta_sw_counter_instr_class_inter_thread_communication_enc_str_1 , volta_sw_counter_instr_class_inter_thread_communication_enc_str_1 , CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sw_counter_instr_class_inter_thread_communication_enc_str_4},

    // Software counters to count unique global load/store instructions
    {VOLTA_SW_COUNTER_UNIQUE_GLD8BIT_INST, volta_sw_counter_unique_gld8bit_inst_enc_str_1, volta_sw_counter_unique_gld8bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_sw_counter_unique_gld8bit_inst_enc_str_1},
    {VOLTA_SW_COUNTER_UNIQUE_GLD16BIT_INST, volta_sw_counter_unique_gld16bit_inst_enc_str_1, volta_sw_counter_unique_gld16bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_sw_counter_unique_gld16bit_inst_enc_str_1},
    {VOLTA_SW_COUNTER_UNIQUE_GLD32BIT_INST, volta_sw_counter_unique_gld32bit_inst_enc_str_1, volta_sw_counter_unique_gld32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_sw_counter_unique_gld32bit_inst_enc_str_1},
    {VOLTA_SW_COUNTER_UNIQUE_GLD64BIT_INST, volta_sw_counter_unique_gld64bit_inst_enc_str_1, volta_sw_counter_unique_gld64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_sw_counter_unique_gld64bit_inst_enc_str_1},
    {VOLTA_SW_COUNTER_UNIQUE_GLD128BIT_INST, volta_sw_counter_unique_gld128bit_inst_enc_str_1, volta_sw_counter_unique_gld128bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_sw_counter_unique_gld128bit_inst_enc_str_1},
    {VOLTA_SW_COUNTER_UNIQUE_GST8BIT_INST, volta_sw_counter_unique_gst8bit_inst_enc_str_1, volta_sw_counter_unique_gst8bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_sw_counter_unique_gst8bit_inst_enc_str_1},
    {VOLTA_SW_COUNTER_UNIQUE_GST16BIT_INST, volta_sw_counter_unique_gst16bit_inst_enc_str_1, volta_sw_counter_unique_gst16bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_sw_counter_unique_gst16bit_inst_enc_str_1},
    {VOLTA_SW_COUNTER_UNIQUE_GST32BIT_INST, volta_sw_counter_unique_gst32bit_inst_enc_str_1, volta_sw_counter_unique_gst32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_sw_counter_unique_gst32bit_inst_enc_str_1},
    {VOLTA_SW_COUNTER_UNIQUE_GST64BIT_INST, volta_sw_counter_unique_gst64bit_inst_enc_str_1, volta_sw_counter_unique_gst64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_sw_counter_unique_gst64bit_inst_enc_str_1},
    {VOLTA_SW_COUNTER_UNIQUE_GST128BIT_INST, volta_sw_counter_unique_gst128bit_inst_enc_str_1, volta_sw_counter_unique_gst128bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_sw_counter_unique_gst128bit_inst_enc_str_1},

    // sw counter to count number of diverged branch
    {VOLTA_SW_COUNTER_DIVERGED_BRANCH, volta_sw_counter_diverged_branch_enc_str_1, volta_sw_counter_diverged_branch_enc_str_2,  CUPROF_EVENT_CATEGORY_MEMORY, volta_sw_counter_diverged_branch_enc_str_3},
    // sw counter to count number of branch instruction per warp
    {VOLTA_SW_COUNTER_BRANCH_INST_EXECUTED, volta_sw_counter_branch_inst_executed_enc_str_1, volta_sw_counter_branch_inst_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_MEMORY, volta_sw_counter_branch_inst_executed_enc_str_3},
    // LDG signals
    { VOLTA_LUT_COUNTER_GLD32BIT_INST,      volta_lut_counter_gld32bit_inst_enc_str_1,  volta_lut_counter_gld32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_gld32bit_inst_enc_str_4},
    { VOLTA_LUT_COUNTER_GST32BIT_INST,      volta_lut_counter_gst32bit_inst_enc_str_1,  volta_lut_counter_gst32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_gst32bit_inst_enc_str_4},
    { VOLTA_LUT_COUNTER_GLD64BIT_INST,      volta_lut_counter_gld64bit_inst_enc_str_1,  volta_lut_counter_gld64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_gld64bit_inst_enc_str_4},
    { VOLTA_LUT_COUNTER_GST64BIT_INST,      volta_lut_counter_gst64bit_inst_enc_str_1,  volta_lut_counter_gst64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_gld64bit_inst_enc_str_4},
    { VOLTA_LUT_COUNTER_GLD128BIT_INST,     volta_lut_counter_gld128bit_inst_enc_str_1, volta_lut_counter_gld128bit_inst_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_gld128bit_inst_enc_str_4},
    { VOLTA_LUT_COUNTER_GST128BIT_INST,     volta_lut_counter_gst128bit_inst_enc_str_1, volta_lut_counter_gst128bit_inst_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_gld128bit_inst_enc_str_4},
    { VOLTA_LUT_COUNTER_SHLD_32BIT_INST,    volta_lut_counter_shld_32bit_inst_enc_str_1,        volta_lut_counter_shld_32bit_inst_enc_str_1,        CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_shld_32bit_inst_enc_str_4 },
    { VOLTA_LUT_COUNTER_SHLD_64BIT_INST,    volta_lut_counter_shld_64bit_inst_enc_str_1,        volta_lut_counter_shld_64bit_inst_enc_str_1,        CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_shld_64bit_inst_enc_str_4 },
    { VOLTA_LUT_COUNTER_SHLD_128BIT_INST,   volta_lut_counter_shld_128bit_inst_enc_str_1,       volta_lut_counter_shld_128bit_inst_enc_str_1,       CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_shld_128bit_inst_enc_str_4 },
    { VOLTA_LUT_COUNTER_SHLD_U128BIT_INST,  volta_lut_counter_shld_u128bit_inst_enc_str_1,     volta_lut_counter_shld_u128bit_inst_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_shld_u128bit_inst_enc_str_4 },
    { VOLTA_LUT_COUNTER_SHST_32BIT_INST,    volta_lut_counter_shst_32bit_inst_enc_str_1,        volta_lut_counter_shst_32bit_inst_enc_str_1,        CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_shst_32bit_inst_enc_str_4 },
    { VOLTA_LUT_COUNTER_SHST_64BIT_INST,    volta_lut_counter_shst_64bit_inst_enc_str_1,        volta_lut_counter_shst_64bit_inst_enc_str_1,        CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_shst_64bit_inst_enc_str_4 },
    { VOLTA_LUT_COUNTER_SHST_128BIT_INST,   volta_lut_counter_shst_128bit_inst_enc_str_1,       volta_lut_counter_shst_128bit_inst_enc_str_1,       CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_shst_128bit_inst_enc_str_4 },

    { VOLTA_LUT_COUNTER_GENERIC_SHARED_LD_INST,       volta_lut_counter_generic_shared_ld_inst_enc_str_1,      volta_lut_counter_generic_shared_ld_inst_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_generic_shared_ld_inst_enc_str_4},
    { VOLTA_LUT_COUNTER_GENERIC_SHARED_ST_INST,       volta_lut_counter_generic_shared_st_inst_enc_str_1,      volta_lut_counter_generic_shared_st_inst_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_generic_shared_st_inst_enc_str_4},

    { VOLTA_LUT_COUNTER_GENERIC_SHARED_LD_32BIT_INST, volta_lut_counter_generic_shared_ld_32bit_inst_enc_str_1,  volta_lut_counter_generic_shared_ld_32bit_inst_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_generic_shared_ld_32bit_inst_enc_str_4},
    { VOLTA_LUT_COUNTER_GENERIC_SHARED_LD_64BIT_INST, volta_lut_counter_generic_shared_ld_64bit_inst_enc_str_1,  volta_lut_counter_generic_shared_ld_64bit_inst_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_generic_shared_ld_64bit_inst_enc_str_4},
    { VOLTA_LUT_COUNTER_GENERIC_SHARED_LD_128BIT_INST, volta_lut_counter_generic_shared_ld_128bit_inst_enc_str_1, volta_lut_counter_generic_shared_ld_128bit_inst_enc_str_1,CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_generic_shared_ld_128bit_inst_enc_str_4},

    { VOLTA_LUT_COUNTER_GENERIC_SHARED_ST_32BIT_INST, volta_lut_counter_generic_shared_st_32bit_inst_enc_str_1,  volta_lut_counter_generic_shared_st_32bit_inst_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_generic_shared_st_32bit_inst_enc_str_4},
    { VOLTA_LUT_COUNTER_GENERIC_SHARED_ST_64BIT_INST, volta_lut_counter_generic_shared_st_64bit_inst_enc_str_1,  volta_lut_counter_generic_shared_st_64bit_inst_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_generic_shared_st_64bit_inst_enc_str_4},
    { VOLTA_LUT_COUNTER_GENERIC_SHARED_ST_128BIT_INST, volta_lut_counter_generic_shared_st_128bit_inst_enc_str_1, volta_lut_counter_generic_shared_st_128bit_inst_enc_str_1,CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_generic_shared_st_128bit_inst_enc_str_4},

    { VOLTA_LUT_COUNTER_SH_ATOM_32BIT_INST,        volta_lut_counter_sh_atom_32bit_inst_enc_str_1,      volta_lut_counter_sh_atom_32bit_inst_enc_str_1,      CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_sh_atom_32bit_inst_enc_str_4 },
    { VOLTA_LUT_COUNTER_SH_ATOM_64BIT_INST,        volta_lut_counter_sh_atom_64bit_inst_enc_str_1,      volta_lut_counter_sh_atom_64bit_inst_enc_str_1,      CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_sh_atom_64bit_inst_enc_str_4 },
    { VOLTA_LUT_COUNTER_SH_ATOM_CAS_32BIT_INST,    volta_lut_counter_sh_atom_cas_32bit_inst_enc_str_1,  volta_lut_counter_sh_atom_cas_32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_sh_atom_cas_32bit_inst_enc_str_4 },
    { VOLTA_LUT_COUNTER_SH_ATOM_CAS_64BIT_INST,    volta_lut_counter_sh_atom_cas_64bit_inst_enc_str_1,  volta_lut_counter_sh_atom_cas_64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_sh_atom_cas_64bit_inst_enc_str_4 },
    { VOLTA_LUT_COUNTER_UNIQUE_WARPS_LAUNCHED, volta_lut_counter_unique_warps_launched_enc_str_1, volta_lut_counter_unique_warps_launched_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_unique_warps_launched_enc_str_4},
    { VOLTA_LUT_COUNTER_UNIQUE_CTAS_LAUNCHED, volta_lut_counter_unique_ctas_launched_enc_str_1, volta_lut_counter_unique_ctas_launched_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_lut_counter_unique_ctas_launched_enc_str_4},
    { VOLTA_MPC_CTAS_LAUNCHED, volta_mpc_ctas_launched_enc_str_1, volta_mpc_ctas_launched_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_mpc_ctas_launched_enc_str_1},
    { VOLTA_MPC_WARP_LAUNCH, volta_mpc_warp_launch_enc_str_1, volta_mpc_warp_launch_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_mpc_warp_launch_enc_str_1 },
    { VOLTA_MPC_TOTAL_THREADS_LAUNCHED, volta_mpc_total_threads_launched_enc_str_1, volta_mpc_total_threads_launched_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_mpc_total_threads_launched_enc_str_1 },
    { VOLTA_MPC_WARPS_IN_FLIGHT, volta_mpc_warps_in_flight_enc_str_1, volta_mpc_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_mpc_warps_in_flight_enc_str_1},
    { VOLTA_MPC_COMPUTE_CTAS_IN_FLIGHT, volta_mpc_compute_ctas_in_flight_enc_str_1, volta_mpc_compute_ctas_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_mpc_compute_ctas_in_flight_enc_str_1},
    { VOLTA_ELAPSED_CYCLES_SM, volta_elapsed_cycles_sm_enc_str_1, volta_elapsed_cycles_sm_enc_str_4, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_elapsed_cycles_sm_enc_str_4},
    { VOLTA_ELAPSED_CYCLES_SM_PM, volta_elapsed_cycles_sm_pm_enc_str_1, volta_elapsed_cycles_sm_pm_enc_str_4, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_elapsed_cycles_sm_pm_enc_str_4},
    { VOLTA_LTC0_ATOMIC_TEX_SECTORS_FBP, volta_ltc0_atomic_tex_sectors_fbp_enc_str_1, volta_ltc0_atomic_tex_sectors_fbp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_atomic_tex_sectors_fbp_enc_str_4},
    { VOLTA_LTC1_ATOMIC_TEX_SECTORS_FBP, volta_ltc1_atomic_tex_sectors_fbp_enc_str_1, volta_ltc1_atomic_tex_sectors_fbp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, volta_ltc1_atomic_tex_sectors_fbp_enc_str_4},

    { VOLTA_LTC0_READ_VIDMEM_SECTORS_FBP,      volta_ltc0_read_vidmem_sectors_fbp_enc_str_1,   volta_ltc0_read_vidmem_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_read_vidmem_sectors_fbp_enc_str_4},
    { VOLTA_LTC1_READ_VIDMEM_SECTORS_FBP,      volta_ltc1_read_vidmem_sectors_fbp_enc_str_1,   volta_ltc1_read_vidmem_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_read_vidmem_sectors_fbp_enc_str_4},

    { VOLTA_LTC0_WRITE_VIDMEM_SECTORS_FBP,      volta_ltc0_write_vidmem_sectors_fbp_enc_str_1, volta_ltc0_write_vidmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_write_vidmem_sectors_fbp_enc_str_4},
    { VOLTA_LTC1_WRITE_VIDMEM_SECTORS_FBP,      volta_ltc1_write_vidmem_sectors_fbp_enc_str_1, volta_ltc1_write_vidmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_write_vidmem_sectors_fbp_enc_str_4},

    { VOLTA_LTC0_PM_REQ_SRC_UNIT_GCC_FBP,      volta_ltc0_pm_req_src_unit_gcc_fbp_enc_str_1,    volta_ltc0_pm_req_src_unit_gcc_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_pm_req_src_unit_gcc_fbp_enc_str_4},
    { VOLTA_LTC1_PM_REQ_SRC_UNIT_GCC_FBP,      volta_ltc1_pm_req_src_unit_gcc_fbp_enc_str_1,    volta_ltc1_pm_req_src_unit_gcc_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, volta_ltc0_pm_req_src_unit_gcc_fbp_enc_str_4},

    // SMPC coreMio signal start
    { VOLTA_SM_ACTIVE_CYCLES, volta_sm_active_cycles_enc_str_1, volta_sm_active_cycles_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_active_cycles_enc_str_3}, // "active_cycles" 
    { VOLTA_SM_ACTIVE_CYCLES_UNFILTERED, volta_sm_active_cycles_unfiltered_enc_str_1, volta_sm_active_cycles_unfiltered_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_active_cycles_unfiltered_enc_str_3}, // "active_cycles_unfiltered"
    { VOLTA_SM_ACTIVE_WARPS, volta_sm_active_warps_enc_str_1, volta_sm_active_warps_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_active_warps_enc_str_3}, // "active_warps" 
    { VOLTA_SM_GROUP0_PLACEHOLDER, volta_sm_group0_placeholder_enc_str_1, volta_sm_group0_placeholder_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_group0_placeholder_enc_str_3}, // "group0_placeholder" 
    { VOLTA_SM_ACTIVE_CTAS, volta_sm_active_ctas_enc_str_1, volta_sm_active_ctas_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_active_ctas_enc_str_3}, // "active_ctas" 
    { VOLTA_SM_CTAS_LAUNCHED, volta_sm_ctas_launched_enc_str_1, volta_sm_ctas_launched_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_ctas_launched_enc_str_3}, // "ctas_launched" 
    { VOLTA_SM_CTAS_RESTORED, volta_sm_ctas_restored_enc_str_1, volta_sm_ctas_restored_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_ctas_restored_enc_str_3}, // "ctas_restored" 
    { VOLTA_SM_ACTIVE_WARPS_PS, volta_sm_active_warps_ps_enc_str_1, volta_sm_active_warps_ps_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_active_warps_ps_enc_str_3}, // "active_warps_ps" 
    { VOLTA_SM_WARPS_EARLY_EXIT_ALL_PIXELS_KILLED, volta_sm_warps_early_exit_all_pixels_killed_enc_str_1, volta_sm_warps_early_exit_all_pixels_killed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warps_early_exit_all_pixels_killed_enc_str_3}, // "warps_early_exit_all_pixels_killed" 
    { VOLTA_SM_YIELD_EXECUTED, volta_sm_yield_executed_enc_str_1, volta_sm_yield_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_yield_executed_enc_str_3}, // "yield_executed" 
    { VOLTA_SM_ACTIVE_WARPS_VTG, volta_sm_active_warps_vtg_enc_str_1, volta_sm_active_warps_vtg_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_active_warps_vtg_enc_str_3}, // "active_warps_vtg" 
    { VOLTA_SM_PQ_STORE_FULL, volta_sm_pq_store_full_enc_str_1, volta_sm_pq_store_full_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pq_store_full_enc_str_3}, // "pq_store_full" 
    { VOLTA_SM_PQ_TEX_FULL, volta_sm_pq_tex_full_enc_str_1, volta_sm_pq_tex_full_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pq_tex_full_enc_str_3}, // "pq_tex_full" 
    { VOLTA_SM_ACTIVE_WARPS_CS, volta_sm_active_warps_cs_enc_str_1, volta_sm_active_warps_cs_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_active_warps_cs_enc_str_3}, // "active_warps_cs" 
    { VOLTA_SM_GROUP4_PLACEHOLDER, volta_sm_group4_placeholder_enc_str_1, volta_sm_group4_placeholder_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_group4_placeholder_enc_str_3}, // "group4_placeholder" 
    { VOLTA_SM_ACTIVE_SUBTILES, volta_sm_active_subtiles_enc_str_1, volta_sm_active_subtiles_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_active_subtiles_enc_str_3}, // "active_subtiles" 
    { VOLTA_SM_SUBTILES_LAUNCHED, volta_sm_subtiles_launched_enc_str_1, volta_sm_subtiles_launched_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_subtiles_launched_enc_str_3}, // "subtiles_launched" 
    { VOLTA_SM_GROUP5_PLACEHOLDER, volta_sm_group5_placeholder_enc_str_1, volta_sm_group5_placeholder_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_group5_placeholder_enc_str_3}, // "group5_placeholder" 
    { VOLTA_SM_ICC_HIT, volta_sm_icc_hit_enc_str_1, volta_sm_icc_hit_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_icc_hit_enc_str_3}, // "icc_hit" 
    { VOLTA_SM_ICC_TRUE_MISS, volta_sm_icc_true_miss_enc_str_1, volta_sm_icc_true_miss_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_icc_true_miss_enc_str_3}, // "icc_true_miss" 
    { VOLTA_SM_ICC_COVERED_MISS, volta_sm_icc_covered_miss_enc_str_1, volta_sm_icc_covered_miss_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_icc_covered_miss_enc_str_3}, // "icc_covered_miss" 
    { VOLTA_SM_ICC_FULL_TAG_TPC, volta_sm_icc_full_tag_tpc_enc_str_1, volta_sm_icc_full_tag_tpc_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_icc_full_tag_tpc_enc_str_3}, // "icc_full_tag_tpc" 
    { VOLTA_SM_ICC_PREFETCHES_TPC, volta_sm_icc_prefetches_tpc_enc_str_1, volta_sm_icc_prefetches_tpc_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_icc_prefetches_tpc_enc_str_3}, // "icc_prefetches_tpc" 
    { VOLTA_SM_ICC_UNLOCK_ALL_TPC, volta_sm_icc_unlock_all_tpc_enc_str_1, volta_sm_icc_unlock_all_tpc_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_icc_unlock_all_tpc_enc_str_3}, // "icc_unlock_all_tpc" 
    { VOLTA_SM_GROUP6_PLACEHOLDER, volta_sm_group6_placeholder_enc_str_1, volta_sm_group6_placeholder_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_group6_placeholder_enc_str_3}, // "group6_placeholder" 
    { VOLTA_SM_ICC_MISSES_OUTSTANDING_TPC, volta_sm_icc_misses_outstanding_tpc_enc_str_1, volta_sm_icc_misses_outstanding_tpc_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_icc_misses_outstanding_tpc_enc_str_3}, // "icc_misses_outstanding_tpc" 
    { VOLTA_SM_IDC_INVALIDATES_EXPLICIT_TPC, volta_sm_idc_invalidates_explicit_tpc_enc_str_1, volta_sm_idc_invalidates_explicit_tpc_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_idc_invalidates_explicit_tpc_enc_str_3}, // "idc_invalidates_explicit_tpc" 
    { VOLTA_SM_IDC_HIT, volta_sm_idc_hit_enc_str_1, volta_sm_idc_hit_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_idc_hit_enc_str_3}, // "idc_hit" 
    { VOLTA_SM_IDC_TRUE_MISS, volta_sm_idc_true_miss_enc_str_1, volta_sm_idc_true_miss_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_idc_true_miss_enc_str_3}, // "idc_true_miss" 
    { VOLTA_SM_IDC_COVERED_MISS, volta_sm_idc_covered_miss_enc_str_1, volta_sm_idc_covered_miss_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_idc_covered_miss_enc_str_3}, // "idc_covered_miss" 
    { VOLTA_SM_GROUP8_PLACEHOLDER, volta_sm_group8_placeholder_enc_str_1, volta_sm_group8_placeholder_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_group8_placeholder_enc_str_3}, // "group8_placeholder" 
    { VOLTA_SM_SCG_MODE_COMPUTE, volta_sm_scg_mode_compute_enc_str_1, volta_sm_scg_mode_compute_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_scg_mode_compute_enc_str_3}, // "scg_mode_compute" 
    { VOLTA_SM_SCG_MODE_GRAPHICS, volta_sm_scg_mode_graphics_enc_str_1, volta_sm_scg_mode_graphics_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_scg_mode_graphics_enc_str_3}, // "scg_mode_graphics" 
    { VOLTA_SM_SM_IN_TRAP, volta_sm_sm_in_trap_enc_str_1, volta_sm_sm_in_trap_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_sm_in_trap_enc_str_3}, // "sm_in_trap" 
    { VOLTA_SM_SM_NOT_IN_TRAP, volta_sm_sm_not_in_trap_enc_str_1, volta_sm_sm_not_in_trap_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_sm_not_in_trap_enc_str_3}, // "sm_not_in_trap" 
    { VOLTA_SM_MEMBAR_EXECUTED, volta_sm_membar_executed_enc_str_1, volta_sm_membar_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_membar_executed_enc_str_3}, // "membar_executed" 
    { VOLTA_SM_MEMBAR_PENDING_TPC, volta_sm_membar_pending_tpc_enc_str_1, volta_sm_membar_pending_tpc_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_membar_pending_tpc_enc_str_3}, // "membar_pending_tpc" 
    { VOLTA_SM_MEMBAR_OUTSTANDING_TO_GNIC, volta_sm_membar_outstanding_to_gnic_enc_str_1, volta_sm_membar_outstanding_to_gnic_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_membar_outstanding_to_gnic_enc_str_3}, // "membar_outstanding_to_gnic" 
    { VOLTA_SM_MEMBAR_SENT_TO_GNIC_TPC, volta_sm_membar_sent_to_gnic_tpc_enc_str_1, volta_sm_membar_sent_to_gnic_tpc_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_membar_sent_to_gnic_tpc_enc_str_3}, // "membar_sent_to_gnic_tpc" 
    { VOLTA_SM_TRAP_IN_TRAP, volta_sm_trap_in_trap_enc_str_1, volta_sm_trap_in_trap_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_trap_in_trap_enc_str_3}, // "trap_in_trap" 
    { VOLTA_SM_TRAP_COUNT, volta_sm_trap_count_enc_str_1, volta_sm_trap_count_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_trap_count_enc_str_3}, // "trap_count" 
    { VOLTA_SM_TRAP_COALESCING, volta_sm_trap_coalescing_enc_str_1, volta_sm_trap_coalescing_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_trap_coalescing_enc_str_3}, // "trap_coalescing" 
    { VOLTA_SM_TRAP_IDLING_FOR_TRAP, volta_sm_trap_idling_for_trap_enc_str_1, volta_sm_trap_idling_for_trap_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_trap_idling_for_trap_enc_str_3}, // "trap_idling_for_trap" 
    { VOLTA_SM_TRAP_WAITING_FOR_IDE, volta_sm_trap_waiting_for_ide_enc_str_1, volta_sm_trap_waiting_for_ide_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_trap_waiting_for_ide_enc_str_3}, // "trap_waiting_for_ide" 
    { VOLTA_SM_BLOCKED_ON_BSYNC, volta_sm_blocked_on_bsync_enc_str_1, volta_sm_blocked_on_bsync_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_blocked_on_bsync_enc_str_3}, // "blocked_on_bsync" 
    { VOLTA_SM_CBU_CONVERGENT_IDX_BR_EXECUTED, volta_sm_cbu_convergent_idx_br_executed_enc_str_1, volta_sm_cbu_convergent_idx_br_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_cbu_convergent_idx_br_executed_enc_str_3}, // "cbu_convergent_idx_br_executed" 
    { VOLTA_SM_CBU_DIVERGENT_IDX_BR_EXECUTED, volta_sm_cbu_divergent_idx_br_executed_enc_str_1, volta_sm_cbu_divergent_idx_br_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_cbu_divergent_idx_br_executed_enc_str_3}, // "cbu_divergent_idx_br_executed" 
    { VOLTA_SM_CBU_ELECTION_JPC_OPT_STACK, volta_sm_cbu_election_jpc_opt_stack_enc_str_1, volta_sm_cbu_election_jpc_opt_stack_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_cbu_election_jpc_opt_stack_enc_str_3}, // "cbu_election_jpc_opt_stack" 
    { VOLTA_SM_CBU_ELECTION_JPC_RR, volta_sm_cbu_election_jpc_rr_enc_str_1, volta_sm_cbu_election_jpc_rr_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_cbu_election_jpc_rr_enc_str_3}, // "cbu_election_jpc_rr" 
    { VOLTA_SM_CBU_ELECTION_NO_JPC, volta_sm_cbu_election_no_jpc_enc_str_1, volta_sm_cbu_election_no_jpc_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_cbu_election_no_jpc_enc_str_3}, // "cbu_election_no_jpc" 
    { VOLTA_SM_CBU_JPC_ALL, volta_sm_cbu_jpc_all_enc_str_1, volta_sm_cbu_jpc_all_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_cbu_jpc_all_enc_str_3}, // "cbu_jpc_all" 
    { VOLTA_SM_CONVERGENT_BARRIER_ALIASED, volta_sm_convergent_barrier_aliased_enc_str_1, volta_sm_convergent_barrier_aliased_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_convergent_barrier_aliased_enc_str_3}, // "convergent_barrier_aliased" 
    { VOLTA_SM_CONVERGENT_BARRIER_RELEASED, volta_sm_convergent_barrier_released_enc_str_1, volta_sm_convergent_barrier_released_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_convergent_barrier_released_enc_str_3}, // "convergent_barrier_released" 
    { VOLTA_SM_CONVERGENT_BARRIER_RELEASED_ALIASED, volta_sm_convergent_barrier_released_aliased_enc_str_1, volta_sm_convergent_barrier_released_aliased_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_convergent_barrier_released_aliased_enc_str_3}, // "convergent_barrier_released_aliased" 
    { VOLTA_SM_WARP_ENTERS_SLEEP, volta_sm_warp_enters_sleep_enc_str_1, volta_sm_warp_enters_sleep_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warp_enters_sleep_enc_str_3}, // "warp_enters_sleep" 
    { VOLTA_SM_ADU_REPLAYS, volta_sm_adu_replays_enc_str_1, volta_sm_adu_replays_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_adu_replays_enc_str_3}, // "adu_replays" 
    { VOLTA_SM_GROUP12_PLACEHOLDER, volta_sm_group12_placeholder_enc_str_1, volta_sm_group12_placeholder_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_group12_placeholder_enc_str_3}, // "group12_placeholder" 
    { VOLTA_SM_PQ_STORE_READS, volta_sm_pq_store_reads_enc_str_1, volta_sm_pq_store_reads_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pq_store_reads_enc_str_3}, // "pq_store_reads" 
    { VOLTA_SM_PQ_STORE_READS_FOR_PIXOUT, volta_sm_pq_store_reads_for_pixout_enc_str_1, volta_sm_pq_store_reads_for_pixout_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pq_store_reads_for_pixout_enc_str_3}, // "pq_store_reads_for_pixout" 
    { VOLTA_SM_PQ_STORE_WRITES, volta_sm_pq_store_writes_enc_str_1, volta_sm_pq_store_writes_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pq_store_writes_enc_str_3}, // "pq_store_writes" 
    { VOLTA_SM_PQ_TEX_READS_FOR_TEX, volta_sm_pq_tex_reads_for_tex_enc_str_1, volta_sm_pq_tex_reads_for_tex_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pq_tex_reads_for_tex_enc_str_3}, // "pq_tex_reads_for_tex" 
    { VOLTA_SM_PQ_TEX_READS_FOR_ADU, volta_sm_pq_tex_reads_for_adu_enc_str_1, volta_sm_pq_tex_reads_for_adu_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pq_tex_reads_for_adu_enc_str_3}, // "pq_tex_reads_for_adu" 
    { VOLTA_SM_MIO_SM_STALLED_DUE_TO_PE, volta_sm_mio_sm_stalled_due_to_pe_enc_str_1, volta_sm_mio_sm_stalled_due_to_pe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_mio_sm_stalled_due_to_pe_enc_str_3}, // "mio_sm_stalled_due_to_pe" 
    { VOLTA_SM_MIO_DATAPATH_ACTIVE, volta_sm_mio_datapath_active_enc_str_1, volta_sm_mio_datapath_active_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_mio_datapath_active_enc_str_3}, // "mio_datapath_active" 
    { VOLTA_SM_GROUP13_PLACEHOLDER, volta_sm_group13_placeholder_enc_str_1, volta_sm_group13_placeholder_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_group13_placeholder_enc_str_3}, // "group13_placeholder" 
    { VOLTA_SM_IDC_DIVERGENCE_REPLAY, volta_sm_idc_divergence_replay_enc_str_1, volta_sm_idc_divergence_replay_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_idc_divergence_replay_enc_str_3}, // "idc_divergence_replay" 
    { VOLTA_SM_IDC_DIVERGENT_INSTRUCTION, volta_sm_idc_divergent_instruction_enc_str_1, volta_sm_idc_divergent_instruction_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_idc_divergent_instruction_enc_str_3}, // "idc_divergent_instruction" 
    { VOLTA_SM_GROUP14_PLACEHOLDER, volta_sm_group14_placeholder_enc_str_1, volta_sm_group14_placeholder_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_group14_placeholder_enc_str_3}, // "group14_placeholder" 
    { VOLTA_SM_PIXOUT_QUADS_DRAINED, volta_sm_pixout_quads_drained_enc_str_1, volta_sm_pixout_quads_drained_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pixout_quads_drained_enc_str_3}, // "pixout_quads_drained" 
    { VOLTA_SM_HALF_WARPS_KILLED_BY_SHADER, volta_sm_half_warps_killed_by_shader_enc_str_1, volta_sm_half_warps_killed_by_shader_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_half_warps_killed_by_shader_enc_str_3}, // "half_warps_killed_by_shader" 
    { VOLTA_SM_QUADS_KILLED_BY_SHADER, volta_sm_quads_killed_by_shader_enc_str_1, volta_sm_quads_killed_by_shader_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_quads_killed_by_shader_enc_str_3}, // "quads_killed_by_shader" 
    { VOLTA_SM_WARPS_KILLED_BY_SHADER, volta_sm_warps_killed_by_shader_enc_str_1, volta_sm_warps_killed_by_shader_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warps_killed_by_shader_enc_str_3}, // "warps_killed_by_shader" 
    { VOLTA_SM_PIXELS_KILLED_SHADERCOVG, volta_sm_pixels_killed_shadercovg_enc_str_1, volta_sm_pixels_killed_shadercovg_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pixels_killed_shadercovg_enc_str_3}, // "pixels_killed_shadercovg" 
    { VOLTA_SM_SM2GPM_OUTPUT_STALL, volta_sm_sm2gpm_output_stall_enc_str_1, volta_sm_sm2gpm_output_stall_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_sm2gpm_output_stall_enc_str_3}, // "sm2gpm_output_stall" 
    { VOLTA_SM_MIO_ISBE_READ, volta_sm_mio_isbe_read_enc_str_1, volta_sm_mio_isbe_read_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_mio_isbe_read_enc_str_3}, // "mio_isbe_read" 
    { VOLTA_SM_MIO_ISBE_WRITE, volta_sm_mio_isbe_write_enc_str_1, volta_sm_mio_isbe_write_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_mio_isbe_write_enc_str_3}, // "mio_isbe_write" 
    { VOLTA_SM_GROUP17_PLACEHOLDER, volta_sm_group17_placeholder_enc_str_1, volta_sm_group17_placeholder_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_group17_placeholder_enc_str_3}, // "group17_placeholder" 
    { VOLTA_SM_PE2MIO_ISBE_READ_REQ, volta_sm_pe2mio_isbe_read_req_enc_str_1, volta_sm_pe2mio_isbe_read_req_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pe2mio_isbe_read_req_enc_str_3}, // "pe2mio_isbe_read_req" 
    { VOLTA_SM_PE2MIO_ISBE_WRITE_REQ, volta_sm_pe2mio_isbe_write_req_enc_str_1, volta_sm_pe2mio_isbe_write_req_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pe2mio_isbe_write_req_enc_str_3}, // "pe2mio_isbe_write_req" 
    { VOLTA_SM_PE2MIO_TRAM_WRITE, volta_sm_pe2mio_tram_write_enc_str_1, volta_sm_pe2mio_tram_write_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pe2mio_tram_write_enc_str_3}, // "pe2mio_tram_write" 
    { VOLTA_SM_GROUP18_PLACEHOLDER, volta_sm_group18_placeholder_enc_str_1, volta_sm_group18_placeholder_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_group18_placeholder_enc_str_3}, // "group18_placeholder" 
    { VOLTA_SM_GROUP19_PLACEHOLDER, volta_sm_group19_placeholder_enc_str_1, volta_sm_group19_placeholder_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_group19_placeholder_enc_str_3}, // "group19_placeholder" 
    { VOLTA_SM_GROUP20_PLACEHOLDER, volta_sm_group20_placeholder_enc_str_1, volta_sm_group20_placeholder_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_group20_placeholder_enc_str_3}, // "group20_placeholder" 
    { VOLTA_SM_GROUP21_PLACEHOLDER, volta_sm_group21_placeholder_enc_str_1, volta_sm_group21_placeholder_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_group21_placeholder_enc_str_3}, // "group21_placeholder" 
    { VOLTA_SM_GROUP22_PLACEHOLDER, volta_sm_group22_placeholder_enc_str_1, volta_sm_group22_placeholder_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_group22_placeholder_enc_str_3}, // "group22_placeholder" 
    { VOLTA_SM_GROUP23_PLACEHOLDER, volta_sm_group23_placeholder_enc_str_1, volta_sm_group23_placeholder_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_group23_placeholder_enc_str_3}, // "group23_placeholder" 
    { VOLTA_SM_GROUP24_PLACEHOLDER, volta_sm_group24_placeholder_enc_str_1, volta_sm_group24_placeholder_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_group24_placeholder_enc_str_3}, // "group24_placeholder" 
    { VOLTA_SM_GROUP25_PLACEHOLDER, volta_sm_group25_placeholder_enc_str_1, volta_sm_group25_placeholder_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_group25_placeholder_enc_str_3}, // "group25_placeholder" 
    { VOLTA_SM_CORE_HW_PM_MUX_LOWER, volta_sm_core_hw_pm_mux_lower_enc_str_1, volta_sm_core_hw_pm_mux_lower_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_core_hw_pm_mux_lower_enc_str_3}, // "core_hw_pm_mux_lower" 
    { VOLTA_SM_CORE_HW_PM_MUX_UPPER, volta_sm_core_hw_pm_mux_upper_enc_str_1, volta_sm_core_hw_pm_mux_upper_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_core_hw_pm_mux_upper_enc_str_3}, // "core_hw_pm_mux_upper" 
    { VOLTA_SM_MIO_HW_PM_MUX_LOWER, volta_sm_mio_hw_pm_mux_lower_enc_str_1, volta_sm_mio_hw_pm_mux_lower_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_mio_hw_pm_mux_lower_enc_str_3}, // "mio_hw_pm_mux_lower" 
    { VOLTA_SM_MIO_HW_PM_MUX_UPPER, volta_sm_mio_hw_pm_mux_upper_enc_str_1, volta_sm_mio_hw_pm_mux_upper_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_mio_hw_pm_mux_upper_enc_str_3}, // "mio_hw_pm_mux_upper" 
    // SMPC coreMio signal end

    // SMPC sctl signal start
    { VOLTA_SM_PMTRIG0, volta_sm_pmtrig0_enc_str_1, volta_sm_pmtrig0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pmtrig0_enc_str_3}, // "pmtrig0" 
    { VOLTA_SM_PMTRIG1, volta_sm_pmtrig1_enc_str_1, volta_sm_pmtrig1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pmtrig1_enc_str_3}, // "pmtrig1" 
    { VOLTA_SM_PMTRIG2, volta_sm_pmtrig2_enc_str_1, volta_sm_pmtrig2_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pmtrig2_enc_str_3}, // "pmtrig2" 
    { VOLTA_SM_PMTRIG3, volta_sm_pmtrig3_enc_str_1, volta_sm_pmtrig3_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pmtrig3_enc_str_3}, // "pmtrig3" 
    { VOLTA_SM_PMTRIG4, volta_sm_pmtrig4_enc_str_1, volta_sm_pmtrig4_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pmtrig4_enc_str_3}, // "pmtrig4" 
    { VOLTA_SM_PMTRIG5, volta_sm_pmtrig5_enc_str_1, volta_sm_pmtrig5_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pmtrig5_enc_str_3}, // "pmtrig5" 
    { VOLTA_SM_PMTRIG6, volta_sm_pmtrig6_enc_str_1, volta_sm_pmtrig6_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pmtrig6_enc_str_3}, // "pmtrig6" 
    { VOLTA_SM_PMTRIG7, volta_sm_pmtrig7_enc_str_1, volta_sm_pmtrig7_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pmtrig7_enc_str_3}, // "pmtrig7" 
    { VOLTA_SM_PMTRIG8, volta_sm_pmtrig8_enc_str_1, volta_sm_pmtrig8_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pmtrig8_enc_str_3}, // "pmtrig8" 
    { VOLTA_SM_PMTRIG9, volta_sm_pmtrig9_enc_str_1, volta_sm_pmtrig9_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pmtrig9_enc_str_3}, // "pmtrig9" 
    { VOLTA_SM_PMTRIG10, volta_sm_pmtrig10_enc_str_1, volta_sm_pmtrig10_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pmtrig10_enc_str_3}, // "pmtrig10" 
    { VOLTA_SM_PMTRIG11, volta_sm_pmtrig11_enc_str_1, volta_sm_pmtrig11_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pmtrig11_enc_str_3}, // "pmtrig11" 
    { VOLTA_SM_PMTRIG12, volta_sm_pmtrig12_enc_str_1, volta_sm_pmtrig12_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pmtrig12_enc_str_3}, // "pmtrig12" 
    { VOLTA_SM_PMTRIG13, volta_sm_pmtrig13_enc_str_1, volta_sm_pmtrig13_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pmtrig13_enc_str_3}, // "pmtrig13" 
    { VOLTA_SM_PMTRIG14, volta_sm_pmtrig14_enc_str_1, volta_sm_pmtrig14_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pmtrig14_enc_str_3}, // "pmtrig14" 
    { VOLTA_SM_PMTRIG15, volta_sm_pmtrig15_enc_str_1, volta_sm_pmtrig15_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pmtrig15_enc_str_3}, // "pmtrig15" 
    { VOLTA_SM_ACTIVE_WARPS_QUAD, volta_sm_active_warps_quad_enc_str_1, volta_sm_active_warps_quad_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_active_warps_quad_enc_str_3}, // "active_warps_quad" 
    { VOLTA_SM_ACTIVE_CYCLES_QUAD, volta_sm_active_cycles_quad_enc_str_1, volta_sm_active_cycles_quad_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_active_cycles_quad_enc_str_3}, // "active_cycles_quad" 
    { VOLTA_SM_WARPS_LAUNCHED, volta_sm_warps_launched_enc_str_1, volta_sm_warps_launched_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warps_launched_enc_str_3}, // "warps_launched" 
    { VOLTA_SM_PMTRIG_MULTI_GROUP, volta_multigrp_counter_pmtrig_enc_str_1, volta_multigrp_counter_pmtrig_enc_str_2 , CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_multigrp_counter_pmtrig_enc_str_3},
    { VOLTA_SM_WARPS_RESTORED, volta_sm_warps_restored_enc_str_1, volta_sm_warps_restored_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warps_restored_enc_str_3}, // "warps_restored" 
    { VOLTA_SM_INST_NOT_ISSUED, volta_sm_inst_not_issued_enc_str_1, volta_sm_inst_not_issued_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_not_issued_enc_str_3}, // "inst_not_issued" 
    { VOLTA_SM_INST_ISSUED, volta_sm_inst_issued_enc_str_1, volta_sm_inst_issued_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_issued_enc_str_3}, // "inst_issued" 
    { VOLTA_SM_INST_EXECUTED, volta_sm_inst_executed_enc_str_1, volta_sm_inst_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_enc_str_3}, // "inst_executed" 
    { VOLTA_SM_INST_ROLLBACKED, volta_sm_inst_rollbacked_enc_str_1, volta_sm_inst_rollbacked_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_rollbacked_enc_str_3}, // "inst_rollbacked" 
    { VOLTA_SM_SCG_MODE_COMPUTE_QUAD, volta_sm_scg_mode_compute_quad_enc_str_1, volta_sm_scg_mode_compute_quad_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_scg_mode_compute_quad_enc_str_3}, // "scg_mode_compute" 
    { VOLTA_SM_SCG_MODE_GRAPHICS_QUAD, volta_sm_scg_mode_graphics_quad_enc_str_1, volta_sm_scg_mode_graphics_quad_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_scg_mode_graphics_quad_enc_str_3}, // "scg_mode_graphics" 
    { VOLTA_SM_SM_IN_TRAP_QUAD, volta_sm_sm_in_trap_quad_enc_str_1, volta_sm_sm_in_trap_quad_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_sm_in_trap_quad_enc_str_3}, // "sm_in_trap" 
    { VOLTA_SM_SM_NOT_IN_TRAP_QUAD, volta_sm_sm_not_in_trap_quad_enc_str_1, volta_sm_sm_not_in_trap_quad_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_sm_not_in_trap_quad_enc_str_3}, // "sm_not_in_trap" 
    { VOLTA_SM_THREAD_INST_EXECUTED, volta_sm_thread_inst_executed_enc_str_1, volta_sm_thread_inst_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_thread_inst_executed_enc_str_3}, // "thread_inst_executed" 
    { VOLTA_SM_WARP_CANT_ISSUE_SELECTED, volta_sm_warp_cant_issue_selected_enc_str_1, volta_sm_warp_cant_issue_selected_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warp_cant_issue_selected_enc_str_3}, // "warp_cant_issue_selected" 
    { VOLTA_SM_WARP_CANT_ISSUE_INST_NOT_ISSUED, volta_sm_warp_cant_issue_inst_not_issued_enc_str_1, volta_sm_warp_cant_issue_inst_not_issued_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warp_cant_issue_inst_not_issued_enc_str_3}, // "warp_cant_issue_inst_not_issued" 
    { VOLTA_SM_NOT_PREDICATED_OFF_THREAD_INST_EXECUTED, volta_sm_not_predicated_off_thread_inst_executed_enc_str_1, volta_sm_not_predicated_off_thread_inst_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_not_predicated_off_thread_inst_executed_enc_str_3}, // "not_predicated_off_thread_inst_executed" 
    { VOLTA_SM_ROLLBACKS_IMC, volta_sm_rollbacks_imc_enc_str_1, volta_sm_rollbacks_imc_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_rollbacks_imc_enc_str_3}, // "rollbacks_imc" 
    { VOLTA_SM_ROLLBACKS_PREDICATED_BRANCH_NOT_FALLTHROUGH, volta_sm_rollbacks_predicated_branch_not_fallthrough_enc_str_1, volta_sm_rollbacks_predicated_branch_not_fallthrough_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_rollbacks_predicated_branch_not_fallthrough_enc_str_3}, // "rollbacks_predicated_branch_not_fallthrough" 
    { VOLTA_SM_WARP_CANT_ISSUE_BARRIER, volta_sm_warp_cant_issue_barrier_enc_str_1, volta_sm_warp_cant_issue_barrier_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warp_cant_issue_barrier_enc_str_3}, // "warp_cant_issue_barrier" 
    { VOLTA_SM_INST_EXECUTED_DECOUPLED_PRED_OFF, volta_sm_inst_executed_decoupled_pred_off_enc_str_1, volta_sm_inst_executed_decoupled_pred_off_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_decoupled_pred_off_enc_str_3}, // "inst_executed_decoupled_pred_off" 
    { VOLTA_SM_BARRIER_EXECUTED, volta_sm_barrier_executed_enc_str_1, volta_sm_barrier_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_barrier_executed_enc_str_3}, // "barrier_executed" 
    { VOLTA_SM_BSYNC_EXECUTED, volta_sm_bsync_executed_enc_str_1, volta_sm_bsync_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_bsync_executed_enc_str_3}, // "bsync_executed" 
    { VOLTA_SM_WARP_CANT_ISSUE_BRANCH_RESOLVING, volta_sm_warp_cant_issue_branch_resolving_enc_str_1, volta_sm_warp_cant_issue_branch_resolving_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warp_cant_issue_branch_resolving_enc_str_3}, // "warp_cant_issue_branch_resolving" 
    { VOLTA_SM_INST_EXECUTED_ATTRIBUTE_LD, volta_sm_inst_executed_attribute_ld_enc_str_1, volta_sm_inst_executed_attribute_ld_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_attribute_ld_enc_str_3}, // "inst_executed_attribute_ld" 
    { VOLTA_SM_INST_EXECUTED_ATTRIBUTE_ST, volta_sm_inst_executed_attribute_st_enc_str_1, volta_sm_inst_executed_attribute_st_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_attribute_st_enc_str_3}, // "inst_executed_attribute_st" 
    { VOLTA_SM_INST_EXECUTED_TEX_OPS, volta_sm_inst_executed_tex_ops_enc_str_1, volta_sm_inst_executed_tex_ops_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_tex_ops_enc_str_3}, // "inst_executed_tex_ops" 
    { VOLTA_SM_WARP_CANT_ISSUE_DISPATCH_STALL, volta_sm_warp_cant_issue_dispatch_stall_enc_str_1, volta_sm_warp_cant_issue_dispatch_stall_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warp_cant_issue_dispatch_stall_enc_str_3}, // "warp_cant_issue_dispatch_stall" 
    { VOLTA_SM_INST_EXECUTED_GENERIC_LD, volta_sm_inst_executed_generic_ld_enc_str_1, volta_sm_inst_executed_generic_ld_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_generic_ld_enc_str_3}, // "inst_executed_generic_ld" 
    { VOLTA_SM_INST_EXECUTED_GENERIC_ST, volta_sm_inst_executed_generic_st_enc_str_1, volta_sm_inst_executed_generic_st_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_generic_st_enc_str_3}, // "inst_executed_generic_st" 
    { VOLTA_SM_NANOSLEEP_EXECUTED, volta_sm_nanosleep_executed_enc_str_1, volta_sm_nanosleep_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_nanosleep_executed_enc_str_3}, // "nanosleep_executed" 
    { VOLTA_SM_WARP_CANT_ISSUE_DRAIN, volta_sm_warp_cant_issue_drain_enc_str_1, volta_sm_warp_cant_issue_drain_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warp_cant_issue_drain_enc_str_3}, // "warp_cant_issue_drain" 
    { VOLTA_SM_INST_EXECUTED_GLOBAL_ATOM, volta_sm_inst_executed_global_atom_enc_str_1, volta_sm_inst_executed_global_atom_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_global_atom_enc_str_3}, // "inst_executed_global_atom" 
    { VOLTA_SM_INST_EXECUTED_GLOBAL_ATOM_ADD_F64B, volta_sm_inst_executed_global_atom_add_f64b_enc_str_1, volta_sm_inst_executed_global_atom_add_f64b_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_global_atom_add_f64b_enc_str_3}, // "inst_executed_global_atom_add_f64b" 
    { VOLTA_SM_INST_EXECUTED_GLOBAL_ATOM_CAS, volta_sm_inst_executed_global_atom_cas_enc_str_1, volta_sm_inst_executed_global_atom_cas_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_global_atom_cas_enc_str_3}, // "inst_executed_global_atom_cas" 
    { VOLTA_SM_WARP_CANT_ISSUE_IMC_MISS, volta_sm_warp_cant_issue_imc_miss_enc_str_1, volta_sm_warp_cant_issue_imc_miss_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warp_cant_issue_imc_miss_enc_str_3}, // "warp_cant_issue_imc_miss" 
    { VOLTA_SM_INST_EXECUTED_GLOBAL_RED, volta_sm_inst_executed_global_red_enc_str_1, volta_sm_inst_executed_global_red_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_global_red_enc_str_3}, // "inst_executed_global_red" 
    { VOLTA_SM_INST_EXECUTED_GLOBAL_RED_ADD_F64B, volta_sm_inst_executed_global_red_add_f64b_enc_str_1, volta_sm_inst_executed_global_red_add_f64b_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_global_red_add_f64b_enc_str_3}, // "inst_executed_global_red_add_f64b" 
    { VOLTA_SM_MIO_SM_STALLED_DUE_TO_PE_QUAD, volta_sm_mio_sm_stalled_due_to_pe_quad_enc_str_1, volta_sm_mio_sm_stalled_due_to_pe_quad_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_mio_sm_stalled_due_to_pe_quad_enc_str_3}, // "mio_sm_stalled_due_to_pe" 
    { VOLTA_SM_WARP_CANT_ISSUE_LONG_SCOREBOARD, volta_sm_warp_cant_issue_long_scoreboard_enc_str_1, volta_sm_warp_cant_issue_long_scoreboard_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warp_cant_issue_long_scoreboard_enc_str_3}, // "warp_cant_issue_long_scoreboard" 
    { VOLTA_SM_INST_EXECUTED_GLOBAL_LD, volta_sm_inst_executed_global_ld_enc_str_1, volta_sm_inst_executed_global_ld_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_global_ld_enc_str_3}, // "inst_executed_global_ld" 
    { VOLTA_SM_INST_EXECUTED_GLOBAL_ST, volta_sm_inst_executed_global_st_enc_str_1, volta_sm_inst_executed_global_st_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_global_st_enc_str_3}, // "inst_executed_global_st" 
    { VOLTA_SM_INST_EXECUTED_LG_OPS, volta_sm_inst_executed_lg_ops_enc_str_1, volta_sm_inst_executed_lg_ops_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_lg_ops_enc_str_3}, // "inst_executed_lg_ops" 
    { VOLTA_SM_WARP_CANT_ISSUE_MEMBAR, volta_sm_warp_cant_issue_membar_enc_str_1, volta_sm_warp_cant_issue_membar_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warp_cant_issue_membar_enc_str_3}, // "warp_cant_issue_membar" 
    { VOLTA_SM_INST_EXECUTED_LOCAL_LD, volta_sm_inst_executed_local_ld_enc_str_1, volta_sm_inst_executed_local_ld_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_local_ld_enc_str_3}, // "inst_executed_local_ld" 
    { VOLTA_SM_INST_EXECUTED_LOCAL_ST, volta_sm_inst_executed_local_st_enc_str_1, volta_sm_inst_executed_local_st_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_local_st_enc_str_3}, // "inst_executed_local_st" 
    { VOLTA_SM_MEMBAR_EXECUTED_QUAD, volta_sm_membar_executed_quad_enc_str_1, volta_sm_membar_executed_quad_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_membar_executed_quad_enc_str_3}, // "membar_executed" 
    { VOLTA_SM_WARP_CANT_ISSUE_MIO_THROTTLE, volta_sm_warp_cant_issue_mio_throttle_enc_str_1, volta_sm_warp_cant_issue_mio_throttle_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warp_cant_issue_mio_throttle_enc_str_3}, // "warp_cant_issue_mio_throttle" 
    { VOLTA_SM_INST_EXECUTED_SHARED_ATOM, volta_sm_inst_executed_shared_atom_enc_str_1, volta_sm_inst_executed_shared_atom_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_shared_atom_enc_str_3}, // "inst_executed_shared_atom" 
    { VOLTA_SM_INST_EXECUTED_SHARED_ATOM_CAS, volta_sm_inst_executed_shared_atom_cas_enc_str_1, volta_sm_inst_executed_shared_atom_cas_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_shared_atom_cas_enc_str_3}, // "inst_executed_shared_atom_cas" 
    { VOLTA_SM_INST_EXECUTED_LDC_OPS, volta_sm_inst_executed_ldc_ops_enc_str_1, volta_sm_inst_executed_ldc_ops_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_ldc_ops_enc_str_3}, // "inst_executed_ldc_ops" 
    { VOLTA_SM_WARP_CANT_ISSUE_MISC, volta_sm_warp_cant_issue_misc_enc_str_1, volta_sm_warp_cant_issue_misc_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warp_cant_issue_misc_enc_str_3}, // "warp_cant_issue_misc" 
    { VOLTA_SM_INST_EXECUTED_SHARED_LD, volta_sm_inst_executed_shared_ld_enc_str_1, volta_sm_inst_executed_shared_ld_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_shared_ld_enc_str_3}, // "inst_executed_shared_ld" 
    { VOLTA_SM_INST_EXECUTED_SHARED_ST, volta_sm_inst_executed_shared_st_enc_str_1, volta_sm_inst_executed_shared_st_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_shared_st_enc_str_3}, // "inst_executed_shared_st" 
    { VOLTA_SM_NON_IDLE, volta_sm_non_idle_enc_str_1, volta_sm_non_idle_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_non_idle_enc_str_3}, // "non_idle" 
    { VOLTA_SM_WARP_CANT_ISSUE_NO_INSTRUCTIONS, volta_sm_warp_cant_issue_no_instructions_enc_str_1, volta_sm_warp_cant_issue_no_instructions_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warp_cant_issue_no_instructions_enc_str_3}, // "warp_cant_issue_no_instructions" 
    { VOLTA_SM_INST_EXECUTED_SURFACE_ATOM, volta_sm_inst_executed_surface_atom_enc_str_1, volta_sm_inst_executed_surface_atom_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_surface_atom_enc_str_3}, // "inst_executed_surface_atom" 
    { VOLTA_SM_INST_EXECUTED_SURFACE_ATOM_CAS, volta_sm_inst_executed_surface_atom_cas_enc_str_1, volta_sm_inst_executed_surface_atom_cas_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_surface_atom_cas_enc_str_3}, // "inst_executed_surface_atom_cas" 
    { VOLTA_SM_INST_EXECUTED_SURFACE_RED, volta_sm_inst_executed_surface_red_enc_str_1, volta_sm_inst_executed_surface_red_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_surface_red_enc_str_3}, // "inst_executed_surface_red" 
    { VOLTA_SM_WARP_CANT_ISSUE_NOT_SELECTED, volta_sm_warp_cant_issue_not_selected_enc_str_1, volta_sm_warp_cant_issue_not_selected_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warp_cant_issue_not_selected_enc_str_3}, // "warp_cant_issue_not_selected" 
    { VOLTA_SM_INST_EXECUTED_SURFACE_LD, volta_sm_inst_executed_surface_ld_enc_str_1, volta_sm_inst_executed_surface_ld_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_surface_ld_enc_str_3}, // "inst_executed_surface_ld" 
    { VOLTA_SM_INST_EXECUTED_SURFACE_ST, volta_sm_inst_executed_surface_st_enc_str_1, volta_sm_inst_executed_surface_st_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_surface_st_enc_str_3}, // "inst_executed_surface_st" 
    { VOLTA_SM_ADU_REPLAYS_QUAD, volta_sm_adu_replays_quad_enc_str_1, volta_sm_adu_replays_quad_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_adu_replays_quad_enc_str_3}, // "adu_replays" 
    { VOLTA_SM_WARP_CANT_ISSUE_SHADOW_PIPE_THROTTLE, volta_sm_warp_cant_issue_shadow_pipe_throttle_enc_str_1, volta_sm_warp_cant_issue_shadow_pipe_throttle_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warp_cant_issue_shadow_pipe_throttle_enc_str_3}, // "warp_cant_issue_shadow_pipe_throttle" 
    { VOLTA_SM_INST_ISSUED_FROM_B2B, volta_sm_inst_issued_from_b2b_enc_str_1, volta_sm_inst_issued_from_b2b_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_issued_from_b2b_enc_str_3}, // "inst_issued_from_b2b" 
    { VOLTA_SM_HALF_WARP_COLLAPSED_ALU_PIPE, volta_sm_half_warp_collapsed_alu_pipe_enc_str_1, volta_sm_half_warp_collapsed_alu_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_half_warp_collapsed_alu_pipe_enc_str_3}, // "half_warp_collapsed_alu_pipe" 
    { VOLTA_SM_HALF_WARP_COLLAPSED_FMA_PIPE, volta_sm_half_warp_collapsed_fma_pipe_enc_str_1, volta_sm_half_warp_collapsed_fma_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_half_warp_collapsed_fma_pipe_enc_str_3}, // "half_warp_collapsed_fma_pipe" 
    { VOLTA_SM_WARP_CANT_ISSUE_SHORT_SCOREBOARD, volta_sm_warp_cant_issue_short_scoreboard_enc_str_1, volta_sm_warp_cant_issue_short_scoreboard_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warp_cant_issue_short_scoreboard_enc_str_3}, // "warp_cant_issue_short_scoreboard" 
    { VOLTA_SM_TEX_WRITE_BACK, volta_sm_tex_write_back_enc_str_1, volta_sm_tex_write_back_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_tex_write_back_enc_str_3}, // "tex_write_back" 
    { VOLTA_SM_LSU_WRITE_BACK, volta_sm_lsu_write_back_enc_str_1, volta_sm_lsu_write_back_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_lsu_write_back_enc_str_3}, // "lsu_write_back" 
    { VOLTA_SM_ADU_WRITE_BACK, volta_sm_adu_write_back_enc_str_1, volta_sm_adu_write_back_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_adu_write_back_enc_str_3}, // "adu_write_back" 
    { VOLTA_SM_WARP_CANT_ISSUE_SLEEPING, volta_sm_warp_cant_issue_sleeping_enc_str_1, volta_sm_warp_cant_issue_sleeping_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warp_cant_issue_sleeping_enc_str_3}, // "warp_cant_issue_sleeping" 
    { VOLTA_SM_WARP_CANT_ISSUE_TEX_THROTTLE, volta_sm_warp_cant_issue_tex_throttle_enc_str_1, volta_sm_warp_cant_issue_tex_throttle_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warp_cant_issue_tex_throttle_enc_str_3}, // "warp_cant_issue_tex_throttle" 
    { VOLTA_SM_TEX_REQUESTS, volta_sm_tex_requests_enc_str_1, volta_sm_tex_requests_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_tex_requests_enc_str_3}, // "tex_requests" 
    { VOLTA_SM_TEX_QUAD_FETCH_REQUESTS, volta_sm_tex_quad_fetch_requests_enc_str_1, volta_sm_tex_quad_fetch_requests_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_tex_quad_fetch_requests_enc_str_3}, // "tex_quad_fetch_requests" 
    { VOLTA_SM_TEX_FETCHES, volta_sm_tex_fetches_enc_str_1, volta_sm_tex_fetches_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_tex_fetches_enc_str_3}, // "tex_fetches" 
    { VOLTA_SM_WARP_CANT_ISSUE_WAIT, volta_sm_warp_cant_issue_wait_enc_str_1, volta_sm_warp_cant_issue_wait_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warp_cant_issue_wait_enc_str_3}, // "warp_cant_issue_wait" 
    { VOLTA_SM_WARP_ISSUE_ELIGIBLE, volta_sm_warp_issue_eligible_enc_str_1, volta_sm_warp_issue_eligible_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warp_issue_eligible_enc_str_3}, // "warp_issue_eligible" 
    { VOLTA_SM_WARP_CANT_ISSUE_LG_THROTTLE, volta_sm_warp_cant_issue_lg_throttle_enc_str_1, volta_sm_warp_cant_issue_lg_throttle_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_warp_cant_issue_lg_throttle_enc_str_3}, // "warp_cant_issue_lg_throttle" 
    { VOLTA_SM_INST_EXECUTED_BRANCH_OPS, volta_sm_inst_executed_branch_ops_enc_str_1, volta_sm_inst_executed_branch_ops_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_branch_ops_enc_str_3}, // "inst_executed_branch_ops" 
    { VOLTA_SM_TAKEN_BR_EXECUTED, volta_sm_taken_br_executed_enc_str_1, volta_sm_taken_br_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_taken_br_executed_enc_str_3}, // "taken_br_executed" 
    { VOLTA_SM_PRED_DIVERGENT_BR_EXECUTED, volta_sm_pred_divergent_br_executed_enc_str_1, volta_sm_pred_divergent_br_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pred_divergent_br_executed_enc_str_3}, // "pred_divergent_br_executed" 
    { VOLTA_SM_FALLTHROUGH_BR_EXECUTED, volta_sm_fallthrough_br_executed_enc_str_1, volta_sm_fallthrough_br_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_fallthrough_br_executed_enc_str_3}, // "fallthrough_br_executed" 
    { VOLTA_SM_INST_EXECUTED_CS, volta_sm_inst_executed_cs_enc_str_1, volta_sm_inst_executed_cs_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_cs_enc_str_3}, // "inst_executed_cs" 
    { VOLTA_SM_INST_EXECUTED_GS, volta_sm_inst_executed_gs_enc_str_1, volta_sm_inst_executed_gs_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_gs_enc_str_3}, // "inst_executed_gs" 
    { VOLTA_SM_INST_EXECUTED_PS, volta_sm_inst_executed_ps_enc_str_1, volta_sm_inst_executed_ps_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_ps_enc_str_3}, // "inst_executed_ps" 
    { VOLTA_SM_INST_EXECUTED_TCS, volta_sm_inst_executed_tcs_enc_str_1, volta_sm_inst_executed_tcs_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_tcs_enc_str_3}, // "inst_executed_tcs" 
    { VOLTA_SM_INST_EXECUTED_TES, volta_sm_inst_executed_tes_enc_str_1, volta_sm_inst_executed_tes_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_tes_enc_str_3}, // "inst_executed_tes" 
    { VOLTA_SM_INST_EXECUTED_VS, volta_sm_inst_executed_vs_enc_str_1, volta_sm_inst_executed_vs_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_vs_enc_str_3}, // "inst_executed_vs" 
    { VOLTA_SM_INST_EXECUTED_VSA, volta_sm_inst_executed_vsa_enc_str_1, volta_sm_inst_executed_vsa_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_vsa_enc_str_3}, // "inst_executed_vsa" 
    { VOLTA_SM_INST_EXECUTED_VSB, volta_sm_inst_executed_vsb_enc_str_1, volta_sm_inst_executed_vsb_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_vsb_enc_str_3}, // "inst_executed_vsb" 
    { VOLTA_SM_INST_EXECUTED_128B, volta_sm_inst_executed_128b_enc_str_1, volta_sm_inst_executed_128b_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_128b_enc_str_3}, // "inst_executed_128b" 
    { VOLTA_SM_INST_EXECUTED_32B, volta_sm_inst_executed_32b_enc_str_1, volta_sm_inst_executed_32b_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_32b_enc_str_3}, // "inst_executed_32b" 
    { VOLTA_SM_INST_EXECUTED_64B, volta_sm_inst_executed_64b_enc_str_1, volta_sm_inst_executed_64b_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_64b_enc_str_3}, // "inst_executed_64b" 
    { VOLTA_SM_INST_EXECUTED_U128B, volta_sm_inst_executed_u128b_enc_str_1, volta_sm_inst_executed_u128b_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_u128b_enc_str_3}, // "inst_executed_U128b" 
    { VOLTA_SM_INST_EXECUTED_ADU_PIPE, volta_sm_inst_executed_adu_pipe_enc_str_1, volta_sm_inst_executed_adu_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_adu_pipe_enc_str_3}, // "inst_executed_adu_pipe" 
    { VOLTA_SM_INST_EXECUTED_ALU_PIPE, volta_sm_inst_executed_alu_pipe_enc_str_1, volta_sm_inst_executed_alu_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_alu_pipe_enc_str_3}, // "inst_executed_alu_pipe" 
    { VOLTA_SM_INST_EXECUTED_BAR_OPS, volta_sm_inst_executed_bar_ops_enc_str_1, volta_sm_inst_executed_bar_ops_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_bar_ops_enc_str_3}, // "inst_executed_bar_ops" 
    { VOLTA_SM_INST_EXECUTED_CBU_PIPE, volta_sm_inst_executed_cbu_pipe_enc_str_1, volta_sm_inst_executed_cbu_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_cbu_pipe_enc_str_3}, // "inst_executed_cbu_pipe" 
    { VOLTA_SM_INST_EXECUTED_FE_PIPE, volta_sm_inst_executed_fe_pipe_enc_str_1, volta_sm_inst_executed_fe_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_fe_pipe_enc_str_3}, // "inst_executed_fe_pipe" 
    { VOLTA_SM_INST_EXECUTED_FMA_PIPE, volta_sm_inst_executed_fma_pipe_enc_str_1, volta_sm_inst_executed_fma_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_fma_pipe_enc_str_3}, // "inst_executed_fma_pipe" 
    { VOLTA_SM_INST_EXECUTED_FMA64LITE_PIPE, volta_sm_inst_executed_fma64lite_pipe_enc_str_1, volta_sm_inst_executed_fma64lite_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_fma64lite_pipe_enc_str_3}, // "inst_executed_fma64lite_pipe" 
    { VOLTA_SM_INST_EXECUTED_FMA64PLUS_PIPE, volta_sm_inst_executed_fma64plus_pipe_enc_str_1, volta_sm_inst_executed_fma64plus_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_fma64plus_pipe_enc_str_3}, // "inst_executed_fma64plus_pipe" 
    { VOLTA_SM_INST_EXECUTED_FP16ULTRA_PIPE, volta_sm_inst_executed_fp16ultra_pipe_enc_str_1, volta_sm_inst_executed_fp16ultra_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_fp16ultra_pipe_enc_str_3}, // "inst_executed_fp16ultra_pipe" 
    { VOLTA_SM_INST_EXECUTED_IPA_PIPE, volta_sm_inst_executed_ipa_pipe_enc_str_1, volta_sm_inst_executed_ipa_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_ipa_pipe_enc_str_3}, // "inst_executed_ipa_pipe" 
    { VOLTA_SM_INST_EXECUTED_LSU_PIPE, volta_sm_inst_executed_lsu_pipe_enc_str_1, volta_sm_inst_executed_lsu_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_lsu_pipe_enc_str_3}, // "inst_executed_lsu_pipe" 
    { VOLTA_SM_INST_EXECUTED_TEX_PIPE, volta_sm_inst_executed_tex_pipe_enc_str_1, volta_sm_inst_executed_tex_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_tex_pipe_enc_str_3}, // "inst_executed_tex_pipe" 
    { VOLTA_SM_INST_EXECUTED_XU_PIPE, volta_sm_inst_executed_xu_pipe_enc_str_1, volta_sm_inst_executed_xu_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_xu_pipe_enc_str_3}, // "inst_executed_xu_pipe" 
    { VOLTA_SM_IMC_HIT, volta_sm_imc_hit_enc_str_1, volta_sm_imc_hit_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_imc_hit_enc_str_3}, // "imc_hit" 
    { VOLTA_SM_IMC_FULL_TAG, volta_sm_imc_full_tag_enc_str_1, volta_sm_imc_full_tag_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_imc_full_tag_enc_str_3}, // "imc_full_tag" 
    { VOLTA_SM_IMC_TRUE_MISS, volta_sm_imc_true_miss_enc_str_1, volta_sm_imc_true_miss_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_imc_true_miss_enc_str_3}, // "imc_true_miss" 
    { VOLTA_SM_IMC_COVERED_MISS, volta_sm_imc_covered_miss_enc_str_1, volta_sm_imc_covered_miss_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_imc_covered_miss_enc_str_3}, // "imc_covered_miss" 
    { VOLTA_SM_IMC_MISSES_OUTSTANDING, volta_sm_imc_misses_outstanding_enc_str_1, volta_sm_imc_misses_outstanding_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_imc_misses_outstanding_enc_str_3}, // "imc_misses_outstanding" 
    { VOLTA_SM_IMC_INVALIDATES_EXPLICIT, volta_sm_imc_invalidates_explicit_enc_str_1, volta_sm_imc_invalidates_explicit_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_imc_invalidates_explicit_enc_str_3}, // "imc_invalidates_explicit" 
    { VOLTA_SM_SCTL_HW_PM_MUX_LOWER, volta_sm_sctl_hw_pm_mux_lower_enc_str_1, volta_sm_sctl_hw_pm_mux_lower_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_sctl_hw_pm_mux_lower_enc_str_3}, // "sctl_hw_pm_mux_lower" 
    { VOLTA_SM_SCTL_HW_PM_MUX_UPPER, volta_sm_sctl_hw_pm_mux_upper_enc_str_1, volta_sm_sctl_hw_pm_mux_upper_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_sctl_hw_pm_mux_upper_enc_str_3}, // "sctl_hw_pm_mux_upper" 
    // SMPC sctl signal end

    { VOLTA_MMU_GPCL2_TLB_HIT,  volta_mmu_gpcl2_tlb_hit_enc_str_1, volta_mmu_gpcl2_tlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpcl2_tlb_hit_enc_str_2},
    { VOLTA_MMU_GPCL2_TLB_MISS,  volta_mmu_gpcl2_tlb_miss_enc_str_1, volta_mmu_gpcl2_tlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpcl2_tlb_miss_enc_str_2},
    { VOLTA_PROFILER_FIRST,  volta_profiler_first_enc_str_1, volta_profiler_first_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_profiler_first_enc_str_2},
    { VOLTA_PROFILER_VALID,  volta_profiler_valid_enc_str_1, volta_profiler_valid_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_profiler_valid_enc_str_2},

    { VOLTA_HWPM_INST_EXECUTED_TRAP,     volta_hwpm_inst_executed_trap_enc_str_1,     volta_hwpm_inst_executed_trap_enc_str_1,     CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_trap_enc_str_1},
    { VOLTA_HWPM_INST_EXECUTED_NO_TRAP,  volta_hwpm_inst_executed_no_trap_enc_str_1,  volta_hwpm_inst_executed_no_trap_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_no_trap_enc_str_1},
    { VOLTA_HWPM_INST_EXECUTED_S0,          volta_hwpm_inst_executed_s0_enc_str_1,       volta_hwpm_inst_executed_s0_enc_str_1,       CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_s0_enc_str_1},

    { VOLTA_HWPM_ACTIVE_CYCLES_TRAP,     volta_hwpm_active_cycles_trap_enc_str_1,     volta_hwpm_active_cycles_trap_enc_str_1,     CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_active_cycles_trap_enc_str_1},
    { VOLTA_HWPM_ACTIVE_CYCLES_NO_TRAP,  volta_hwpm_active_cycles_no_trap_enc_str_1,  volta_hwpm_active_cycles_no_trap_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_active_cycles_no_trap_enc_str_1},
    {VOLTA_HWPMMUX_THREAD_INST_EXECUTED, volta_hwpmmux_thread_inst_executed_enc_str_1, volta_hwpmmux_thread_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpmmux_thread_inst_executed_enc_str_1},
    {VOLTA_HWPMMUX_NPO_THREAD_INST_EXECUTED, volta_hwpmmux_npo_thread_inst_executed_enc_str_1, volta_hwpmmux_npo_thread_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpmmux_npo_thread_inst_executed_enc_str_1},
    {VOLTA_HWPM_THREAD_INST_EXECUTED_0, volta_hwpm_thread_inst_executed_s0_enc_str_1, volta_hwpm_thread_inst_executed_s0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_thread_inst_executed_s0_enc_str_1},
    {VOLTA_HWPM_NPO_THREAD_INST_EXECUTED_0, volta_hwpm_npo_thread_inst_executed_s0_enc_str_1, volta_hwpm_npo_thread_inst_executed_s0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_npo_thread_inst_executed_s0_enc_str_1},
//-----------------------------------NVLINK TL COUNTERS----------------------------------------
    { VOLTA_NVLINK_TL_TX_TOTAL_FLITS, volta_nvlink_tl_tx_total_flits_enc_str_1, volta_nvlink_tl_tx_total_flits_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_tx_total_flits_enc_str_3 },
    { VOLTA_NVLINK_TL_TX_DATA_FLITS, volta_nvlink_tl_tx_data_flits_enc_str_1, volta_nvlink_tl_tx_data_flits_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_tx_data_flits_enc_str_3 },
    { VOLTA_NVLINK_TL_TX_READ_TOTAL_FLITS, volta_nvlink_tl_tx_read_total_flits_enc_str_1, volta_nvlink_tl_tx_read_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_tx_read_total_flits_enc_str_3 },
    { VOLTA_NVLINK_TL_TX_WRITE_TOTAL_FLITS, volta_nvlink_tl_tx_write_total_flits_enc_str_1, volta_nvlink_tl_tx_write_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_tx_write_total_flits_enc_str_1 },
    { VOLTA_NVLINK_TL_TX_RATOM_TOTAL_FLITS, volta_nvlink_tl_tx_ratom_total_flits_enc_str_1, volta_nvlink_tl_tx_ratom_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_tx_ratom_total_flits_enc_str_1 },
    { VOLTA_NVLINK_TL_TX_NRATOM_TOTAL_FLITS, volta_nvlink_tl_tx_nratom_total_flits_enc_str_1, volta_nvlink_tl_tx_nratom_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_tx_nratom_total_flits_enc_str_1 },
    { VOLTA_NVLINK_TL_TX_FLUSH_TOTAL_FLITS, volta_nvlink_tl_tx_flush_total_flits_enc_str_1, volta_nvlink_tl_tx_flush_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_tx_flush_total_flits_enc_str_1 },
    { VOLTA_NVLINK_TL_TX_RESPD_TOTAL_FLITS, volta_nvlink_tl_tx_respd_total_flits_enc_str_1, volta_nvlink_tl_tx_respd_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_tx_respd_total_flits_enc_str_1 },
    { VOLTA_NVLINK_TL_TX_READ_DATA_FLITS, volta_nvlink_tl_tx_read_data_flits_enc_str_1, volta_nvlink_tl_tx_read_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_tx_read_data_flits_enc_str_1 },
    { VOLTA_NVLINK_TL_TX_WRITE_DATA_FLITS, volta_nvlink_tl_tx_write_data_flits_enc_str_1, volta_nvlink_tl_tx_write_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_tx_write_data_flits_enc_str_1 },
    { VOLTA_NVLINK_TL_TX_RATOM_DATA_FLITS, volta_nvlink_tl_tx_ratom_data_flits_enc_str_1, volta_nvlink_tl_tx_ratom_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_tx_ratom_data_flits_enc_str_1 },
    { VOLTA_NVLINK_TL_TX_NRATOM_DATA_FLITS, volta_nvlink_tl_tx_nratom_data_flits_enc_str_1, volta_nvlink_tl_tx_nratom_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_tx_nratom_data_flits_enc_str_1 },
    { VOLTA_NVLINK_TL_TX_FLUSH_DATA_FLITS, volta_nvlink_tl_tx_flush_data_flits_enc_str_1, volta_nvlink_tl_tx_flush_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_tx_flush_data_flits_enc_str_1 },
    { VOLTA_NVLINK_TL_TX_RESPD_DATA_FLITS, volta_nvlink_tl_tx_respd_data_flits_enc_str_1, volta_nvlink_tl_tx_respd_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_tx_respd_data_flits_enc_str_1 },
    { VOLTA_NVLINK_TL_TX_IDLE_FLITS, volta_nvlink_tl_tx_idle_flits_enc_str_1, volta_nvlink_tl_tx_idle_flits_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_tx_idle_flits_enc_str_3 },
    //------------------------------------------------------------------------------------------------------------------------------------------
    { VOLTA_NVLINK_TL_RX_TOTAL_FLITS, volta_nvlink_tl_rx_total_flits_enc_str_1, volta_nvlink_tl_rx_total_flits_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_rx_total_flits_enc_str_3 },
    { VOLTA_NVLINK_TL_RX_DATA_FLITS, volta_nvlink_tl_rx_data_flits_enc_str_1, volta_nvlink_tl_rx_data_flits_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_rx_data_flits_enc_str_3 },
    { VOLTA_NVLINK_TL_RX_READ_TOTAL_FLITS, volta_nvlink_tl_rx_read_total_flits_enc_str_1, volta_nvlink_tl_rx_read_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_rx_read_total_flits_enc_str_3 },
    { VOLTA_NVLINK_TL_RX_WRITE_TOTAL_FLITS, volta_nvlink_tl_rx_write_total_flits_enc_str_1, volta_nvlink_tl_rx_write_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_rx_write_total_flits_enc_str_1 },
    { VOLTA_NVLINK_TL_RX_RATOM_TOTAL_FLITS, volta_nvlink_tl_rx_ratom_total_flits_enc_str_1, volta_nvlink_tl_rx_ratom_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_rx_ratom_total_flits_enc_str_1 },
    { VOLTA_NVLINK_TL_RX_NRATOM_TOTAL_FLITS, volta_nvlink_tl_rx_nratom_total_flits_enc_str_1, volta_nvlink_tl_rx_nratom_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_rx_nratom_total_flits_enc_str_1 },
    { VOLTA_NVLINK_TL_RX_FLUSH_TOTAL_FLITS, volta_nvlink_tl_rx_flush_total_flits_enc_str_1, volta_nvlink_tl_rx_flush_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_rx_flush_total_flits_enc_str_1 },
    { VOLTA_NVLINK_TL_RX_RESPD_TOTAL_FLITS, volta_nvlink_tl_rx_respd_total_flits_enc_str_1, volta_nvlink_tl_rx_respd_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_rx_respd_total_flits_enc_str_1 },
    { VOLTA_NVLINK_TL_RX_READ_DATA_FLITS, volta_nvlink_tl_rx_read_data_flits_enc_str_1, volta_nvlink_tl_rx_read_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_rx_read_data_flits_enc_str_1 },
    { VOLTA_NVLINK_TL_RX_WRITE_DATA_FLITS, volta_nvlink_tl_rx_write_data_flits_enc_str_1, volta_nvlink_tl_rx_write_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_rx_write_data_flits_enc_str_1 },
    { VOLTA_NVLINK_TL_RX_RATOM_DATA_FLITS, volta_nvlink_tl_rx_ratom_data_flits_enc_str_1, volta_nvlink_tl_rx_ratom_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_rx_ratom_data_flits_enc_str_1 },
    { VOLTA_NVLINK_TL_RX_NRATOM_DATA_FLITS, volta_nvlink_tl_rx_nratom_data_flits_enc_str_1, volta_nvlink_tl_rx_nratom_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_rx_nratom_data_flits_enc_str_1 },
    { VOLTA_NVLINK_TL_RX_FLUSH_DATA_FLITS, volta_nvlink_tl_rx_flush_data_flits_enc_str_1, volta_nvlink_tl_rx_flush_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_rx_flush_data_flits_enc_str_1 },
    { VOLTA_NVLINK_TL_RX_RESPD_DATA_FLITS, volta_nvlink_tl_rx_respd_data_flits_enc_str_1, volta_nvlink_tl_rx_respd_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_rx_respd_data_flits_enc_str_1 },
    { VOLTA_NVLINK_TL_RX_IDLE_FLITS, volta_nvlink_tl_rx_idle_flits_enc_str_1, volta_nvlink_tl_rx_idle_flits_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE, volta_nvlink_tl_rx_idle_flits_enc_str_3 },

    { VOLTA_SM_IDC_DIVERGENCE_REPLAY, volta_sm_idc_divergence_replay_enc_str_1, volta_sm_idc_divergence_replay_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_idc_divergence_replay_enc_str_3}, //"idc_divergence_replay" 
    { VOLTA_SM_IDC_DIVERGENT_INSTRUCTION, volta_sm_idc_divergent_instruction_enc_str_1, volta_sm_idc_divergent_instruction_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_idc_divergent_instruction_enc_str_3}, //"idc_divergent_instruction" 
    { VOLTA_SM_MIO_ISBE_WRITE, volta_sm_mio_isbe_write_enc_str_1, volta_sm_mio_isbe_write_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_mio_isbe_write_enc_str_3}, //"mio_isbe_write" 
    { VOLTA_SM_MIO_ISBE_READ, volta_sm_mio_isbe_read_enc_str_1, volta_sm_mio_isbe_read_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_mio_isbe_read_enc_str_3}, //"mio_isbe_read" 
    { VOLTA_SM_PE2MIO_ISBE_READ_REQ, volta_sm_pe2mio_isbe_read_req_enc_str_1, volta_sm_pe2mio_isbe_read_req_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pe2mio_isbe_read_req_enc_str_3}, //"pe2mio_isbe_read_req" 
    { VOLTA_SM_PE2MIO_ISBE_WRITE_REQ, volta_sm_pe2mio_isbe_write_req_enc_str_1, volta_sm_pe2mio_isbe_write_req_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pe2mio_isbe_write_req_enc_str_3}, //"pe2mio_isbe_write_req" 
    { VOLTA_SM_PE2MIO_TRAM_WRITE, volta_sm_pe2mio_tram_write_enc_str_1, volta_sm_pe2mio_tram_write_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_pe2mio_tram_write_enc_str_3}, //"pe2mio_tram_write" 

    {VOLTA_MMU_GPC_LTP0_UTLB_HIT, volta_mmu_gpc_ltp0_utlb_hit_enc_str_1, volta_mmu_gpc_ltp0_utlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp0_utlb_hit_enc_str_1},
    {VOLTA_MMU_GPC_LTP0_UTLB_MISS, volta_mmu_gpc_ltp0_utlb_miss_enc_str_1, volta_mmu_gpc_ltp0_utlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp0_utlb_miss_enc_str_1},
    {VOLTA_MMU_GPC_LTP1_UTLB_HIT, volta_mmu_gpc_ltp1_utlb_hit_enc_str_1, volta_mmu_gpc_ltp1_utlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp1_utlb_hit_enc_str_1},
    {VOLTA_MMU_GPC_LTP1_UTLB_MISS, volta_mmu_gpc_ltp1_utlb_miss_enc_str_1, volta_mmu_gpc_ltp1_utlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp1_utlb_miss_enc_str_1},
    {VOLTA_MMU_GPC_LTP2_UTLB_HIT, volta_mmu_gpc_ltp2_utlb_hit_enc_str_1, volta_mmu_gpc_ltp2_utlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp2_utlb_hit_enc_str_1},
    {VOLTA_MMU_GPC_LTP2_UTLB_MISS, volta_mmu_gpc_ltp2_utlb_miss_enc_str_1, volta_mmu_gpc_ltp2_utlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp2_utlb_miss_enc_str_1},
    {VOLTA_MMU_GPC_LTP3_UTLB_HIT, volta_mmu_gpc_ltp3_utlb_hit_enc_str_1, volta_mmu_gpc_ltp3_utlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp3_utlb_hit_enc_str_1},
    {VOLTA_MMU_GPC_LTP3_UTLB_MISS, volta_mmu_gpc_ltp3_utlb_miss_enc_str_1, volta_mmu_gpc_ltp3_utlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp3_utlb_miss_enc_str_1},
    {VOLTA_MMU_GPC_LTP4_UTLB_HIT, volta_mmu_gpc_ltp4_utlb_hit_enc_str_1, volta_mmu_gpc_ltp4_utlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp4_utlb_hit_enc_str_1},
    {VOLTA_MMU_GPC_LTP4_UTLB_MISS, volta_mmu_gpc_ltp4_utlb_miss_enc_str_1, volta_mmu_gpc_ltp4_utlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp4_utlb_miss_enc_str_1},
    {VOLTA_MMU_GPC_LTP5_UTLB_HIT, volta_mmu_gpc_ltp5_utlb_hit_enc_str_1, volta_mmu_gpc_ltp5_utlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp5_utlb_hit_enc_str_1},
    {VOLTA_MMU_GPC_LTP5_UTLB_MISS, volta_mmu_gpc_ltp5_utlb_miss_enc_str_1, volta_mmu_gpc_ltp5_utlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp5_utlb_miss_enc_str_1},
    {VOLTA_MMU_GPC_LTP6_UTLB_HIT, volta_mmu_gpc_ltp6_utlb_hit_enc_str_1, volta_mmu_gpc_ltp6_utlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp6_utlb_hit_enc_str_1},
    {VOLTA_MMU_GPC_LTP6_UTLB_MISS, volta_mmu_gpc_ltp6_utlb_miss_enc_str_1, volta_mmu_gpc_ltp6_utlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp6_utlb_miss_enc_str_1},
    {VOLTA_MMU_GPC_RGG_UTLB_HIT, volta_mmu_gpc_rgg_utlb_hit_enc_str_1, volta_mmu_gpc_rgg_utlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_rgg_utlb_hit_enc_str_1},
    {VOLTA_MMU_GPC_RGG_UTLB_MISS, volta_mmu_gpc_rgg_utlb_miss_enc_str_1, volta_mmu_gpc_rgg_utlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_rgg_utlb_miss_enc_str_1},
    {VOLTA_MMU_GPC_LTP0_UTLB_HIT_COPY, volta_mmu_gpc_ltp0_utlb_hit_copy_enc_str_1, volta_mmu_gpc_ltp0_utlb_hit_copy_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp0_utlb_hit_copy_enc_str_1},
    {VOLTA_MMU_GPC_LTP0_UTLB_MISS_COPY, volta_mmu_gpc_ltp0_utlb_miss_copy_enc_str_1, volta_mmu_gpc_ltp0_utlb_miss_copy_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp0_utlb_miss_copy_enc_str_1},
    {VOLTA_MMU_GPC_LTP1_UTLB_HIT_COPY, volta_mmu_gpc_ltp1_utlb_hit_copy_enc_str_1, volta_mmu_gpc_ltp1_utlb_hit_copy_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp1_utlb_hit_copy_enc_str_1},
    {VOLTA_MMU_GPC_LTP1_UTLB_MISS_COPY, volta_mmu_gpc_ltp1_utlb_miss_copy_enc_str_1, volta_mmu_gpc_ltp1_utlb_miss_copy_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp1_utlb_miss_copy_enc_str_1},
    {VOLTA_MMU_GPC_LTP2_UTLB_HIT_COPY, volta_mmu_gpc_ltp2_utlb_hit_copy_enc_str_1, volta_mmu_gpc_ltp2_utlb_hit_copy_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp2_utlb_hit_copy_enc_str_1},
    {VOLTA_MMU_GPC_LTP2_UTLB_MISS_COPY, volta_mmu_gpc_ltp2_utlb_miss_copy_enc_str_1, volta_mmu_gpc_ltp2_utlb_miss_copy_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp2_utlb_miss_copy_enc_str_1},
    {VOLTA_MMU_GPC_LTP3_UTLB_HIT_COPY, volta_mmu_gpc_ltp3_utlb_hit_copy_enc_str_1, volta_mmu_gpc_ltp3_utlb_hit_copy_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp3_utlb_hit_copy_enc_str_1},
    {VOLTA_MMU_GPC_LTP3_UTLB_MISS_COPY, volta_mmu_gpc_ltp3_utlb_miss_copy_enc_str_1, volta_mmu_gpc_ltp3_utlb_miss_copy_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp3_utlb_miss_copy_enc_str_1},
    {VOLTA_MMU_GPC_LTP4_UTLB_HIT_COPY, volta_mmu_gpc_ltp4_utlb_hit_copy_enc_str_1, volta_mmu_gpc_ltp4_utlb_hit_copy_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp4_utlb_hit_copy_enc_str_1},
    {VOLTA_MMU_GPC_LTP4_UTLB_MISS_COPY, volta_mmu_gpc_ltp4_utlb_miss_copy_enc_str_1, volta_mmu_gpc_ltp4_utlb_miss_copy_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp4_utlb_miss_copy_enc_str_1},
    {VOLTA_MMU_GPC_LTP5_UTLB_HIT_COPY, volta_mmu_gpc_ltp5_utlb_hit_copy_enc_str_1, volta_mmu_gpc_ltp5_utlb_hit_copy_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp5_utlb_hit_copy_enc_str_1},
    {VOLTA_MMU_GPC_LTP5_UTLB_MISS_COPY, volta_mmu_gpc_ltp5_utlb_miss_copy_enc_str_1, volta_mmu_gpc_ltp5_utlb_miss_copy_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp5_utlb_miss_copy_enc_str_1},
    {VOLTA_MMU_GPC_LTP6_UTLB_HIT_COPY, volta_mmu_gpc_ltp6_utlb_hit_copy_enc_str_1, volta_mmu_gpc_ltp6_utlb_hit_copy_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp6_utlb_hit_copy_enc_str_1},
    {VOLTA_MMU_GPC_LTP6_UTLB_MISS_COPY, volta_mmu_gpc_ltp6_utlb_miss_copy_enc_str_1, volta_mmu_gpc_ltp6_utlb_miss_copy_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_ltp6_utlb_miss_copy_enc_str_1},
    {VOLTA_MMU_GPC_RGG_UTLB_HIT_COPY, volta_mmu_gpc_rgg_utlb_hit_copy_enc_str_1, volta_mmu_gpc_rgg_utlb_hit_copy_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_rgg_utlb_hit_copy_enc_str_1},
    {VOLTA_MMU_GPC_RGG_UTLB_MISS_COPY, volta_mmu_gpc_rgg_utlb_miss_copy_enc_str_1, volta_mmu_gpc_rgg_utlb_miss_copy_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_rgg_utlb_miss_copy_enc_str_1},
    {VOLTA_MMU_GPC_GPCL1_TLB_HIT, volta_mmu_gpc_gpcl1_tlb_hit_enc_str_1, volta_mmu_gpc_gpcl1_tlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_gpcl1_tlb_hit_enc_str_1},
    {VOLTA_MMU_GPC_GPCL1_TLB_MISS, volta_mmu_gpc_gpcl1_tlb_miss_enc_str_1, volta_mmu_gpc_gpcl1_tlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_gpcl1_tlb_miss_enc_str_1},
    {VOLTA_MMU_GPC_GPCL1_TLB_HIT_COPY, volta_mmu_gpc_gpcl1_tlb_hit_copy_enc_str_1, volta_mmu_gpc_gpcl1_tlb_hit_copy_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_gpcl1_tlb_hit_copy_enc_str_1},
    {VOLTA_MMU_GPC_GPCL1_TLB_MISS_COPY, volta_mmu_gpc_gpcl1_tlb_miss_copy_enc_str_1, volta_mmu_gpc_gpcl1_tlb_miss_copy_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_gpcl1_tlb_miss_copy_enc_str_1},

    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_TPC0, volta_mmu_gpc_replayable_fault_tpc0_enc_str_1, volta_mmu_gpc_replayable_fault_tpc0_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_replayable_fault_tpc0_enc_str_1},
    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_TPC1, volta_mmu_gpc_replayable_fault_tpc1_enc_str_1, volta_mmu_gpc_replayable_fault_tpc1_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_replayable_fault_tpc1_enc_str_1},
    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_TPC2, volta_mmu_gpc_replayable_fault_tpc2_enc_str_1, volta_mmu_gpc_replayable_fault_tpc2_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_replayable_fault_tpc2_enc_str_1},
    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_TPC3, volta_mmu_gpc_replayable_fault_tpc3_enc_str_1, volta_mmu_gpc_replayable_fault_tpc3_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_replayable_fault_tpc3_enc_str_1},
    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_TPC4, volta_mmu_gpc_replayable_fault_tpc4_enc_str_1, volta_mmu_gpc_replayable_fault_tpc4_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_replayable_fault_tpc4_enc_str_1},
    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_TPC5, volta_mmu_gpc_replayable_fault_tpc5_enc_str_1, volta_mmu_gpc_replayable_fault_tpc5_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_replayable_fault_tpc5_enc_str_1},
    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_TPC6, volta_mmu_gpc_replayable_fault_tpc6_enc_str_1, volta_mmu_gpc_replayable_fault_tpc6_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_replayable_fault_tpc6_enc_str_1},
    {VOLTA_MMU_GPC_REPLAYABLE_FAULT_RGG,  volta_mmu_gpc_replayable_fault_rgg_enc_str_1,  volta_mmu_gpc_replayable_fault_rgg_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_replayable_fault_rgg_enc_str_1},
    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_TPC0, volta_mmu_gpc_block_non_fatal_fault_tpc0_enc_str_1, volta_mmu_gpc_block_non_fatal_fault_tpc0_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_block_non_fatal_fault_tpc0_enc_str_1},
    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_TPC1, volta_mmu_gpc_block_non_fatal_fault_tpc1_enc_str_1, volta_mmu_gpc_block_non_fatal_fault_tpc1_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_block_non_fatal_fault_tpc1_enc_str_1},
    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_TPC2, volta_mmu_gpc_block_non_fatal_fault_tpc2_enc_str_1, volta_mmu_gpc_block_non_fatal_fault_tpc2_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_block_non_fatal_fault_tpc2_enc_str_1},
    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_TPC3, volta_mmu_gpc_block_non_fatal_fault_tpc3_enc_str_1, volta_mmu_gpc_block_non_fatal_fault_tpc3_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_block_non_fatal_fault_tpc3_enc_str_1},
    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_TPC4, volta_mmu_gpc_block_non_fatal_fault_tpc4_enc_str_1, volta_mmu_gpc_block_non_fatal_fault_tpc4_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_block_non_fatal_fault_tpc4_enc_str_1},
    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_TPC5, volta_mmu_gpc_block_non_fatal_fault_tpc5_enc_str_1, volta_mmu_gpc_block_non_fatal_fault_tpc5_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_block_non_fatal_fault_tpc5_enc_str_1},
    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_TPC6, volta_mmu_gpc_block_non_fatal_fault_tpc6_enc_str_1, volta_mmu_gpc_block_non_fatal_fault_tpc6_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_block_non_fatal_fault_tpc6_enc_str_1},
    {VOLTA_MMU_GPC_BLOCK_NON_FATAL_FAULT_RGG,  volta_mmu_gpc_block_non_fatal_fault_rgg_enc_str_1,  volta_mmu_gpc_block_non_fatal_fault_rgg_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_block_non_fatal_fault_rgg_enc_str_1},
    {VOLTA_MMU_GPC_TOTAL_REPLAYABLE_FAULT, volta_mmu_gpc_total_replayable_fault_enc_str_1, volta_mmu_gpc_total_replayable_fault_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_total_replayable_fault_enc_str_1},
    {VOLTA_MMU_GPC_TOTAL_BLOCK_NON_FATAL_FAULT, volta_mmu_gpc_total_block_non_fatal_fault_enc_str_1, volta_mmu_gpc_total_block_non_fatal_fault_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mmu_gpc_total_replayable_fault_enc_str_1},


#endif /* #if NVCFG(GLOBAL_ARCH_VOLTA) */
#if NVLINK_PM
    { VOLTA_NVLINK0_TL_TX_DATA_FLIT,     volta_nvlink0_tl_tx_data_flit_enc_str_1,     volta_nvlink0_tl_tx_data_flit_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink0_tl_tx_data_flit_enc_str_2},
    { VOLTA_NVLINK1_TL_TX_DATA_FLIT,     volta_nvlink1_tl_tx_data_flit_enc_str_1,     volta_nvlink1_tl_tx_data_flit_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink1_tl_tx_data_flit_enc_str_2},
    { VOLTA_NVLINK2_TL_TX_DATA_FLIT,     volta_nvlink2_tl_tx_data_flit_enc_str_1,     volta_nvlink2_tl_tx_data_flit_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink2_tl_tx_data_flit_enc_str_2},
    { VOLTA_NVLINK3_TL_TX_DATA_FLIT,     volta_nvlink3_tl_tx_data_flit_enc_str_1,     volta_nvlink3_tl_tx_data_flit_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink3_tl_tx_data_flit_enc_str_2},

    { VOLTA_NVLINK0_TL_RX_DATA_FLIT,     volta_nvlink0_tl_rx_data_flit_enc_str_1,     volta_nvlink0_tl_rx_data_flit_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink0_tl_rx_data_flit_enc_str_2},
    { VOLTA_NVLINK1_TL_RX_DATA_FLIT,     volta_nvlink1_tl_rx_data_flit_enc_str_1,     volta_nvlink1_tl_rx_data_flit_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink1_tl_rx_data_flit_enc_str_2},
    { VOLTA_NVLINK2_TL_RX_DATA_FLIT,     volta_nvlink2_tl_rx_data_flit_enc_str_1,     volta_nvlink2_tl_rx_data_flit_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink2_tl_rx_data_flit_enc_str_2},
    { VOLTA_NVLINK3_TL_RX_DATA_FLIT,     volta_nvlink3_tl_rx_data_flit_enc_str_1,     volta_nvlink3_tl_rx_data_flit_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink3_tl_rx_data_flit_enc_str_2},
#endif
#if 0
    {VOLTA_LTC0_LTCX_MC_REQ_RD_SIZE_32B,    volta_ltc0_ltcx_mc_req_rd_size_32b_enc_str_1,     volta_ltc0_ltcx_mc_req_rd_size_32b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc0_ltcx_mc_req_rd_size_32b_enc_str_4},
    {VOLTA_LTC0_LTCX_MC_REQ_RD_SIZE_64B,    volta_ltc0_ltcx_mc_req_rd_size_64b_enc_str_1,     volta_ltc0_ltcx_mc_req_rd_size_64b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc0_ltcx_mc_req_rd_size_64b_enc_str_4},
    {VOLTA_LTC0_LTCX_MC_REQ_WR_SIZE_16B,    volta_ltc0_ltcx_mc_req_wr_size_16b_enc_str_1,     volta_ltc0_ltcx_mc_req_wr_size_16b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc0_ltcx_mc_req_wr_size_16b_enc_str_4},
    {VOLTA_LTC0_LTCX_MC_REQ_WR_SIZE_32B,    volta_ltc0_ltcx_mc_req_wr_size_32b_enc_str_1,     volta_ltc0_ltcx_mc_req_wr_size_32b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc0_ltcx_mc_req_wr_size_32b_enc_str_4},
    {VOLTA_LTC0_LTCX_MC_REQ_WR_SIZE_64B,    volta_ltc0_ltcx_mc_req_wr_size_64b_enc_str_1,     volta_ltc0_ltcx_mc_req_wr_size_64b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc0_ltcx_mc_req_wr_size_64b_enc_str_4},

    {VOLTA_LTC0_LTCX_REQ_RD_SECTOR_COUNT_1, volta_ltc0_ltcx_req_rd_sector_count_1_enc_str_1,  volta_ltc0_ltcx_req_rd_sector_count_1_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc0_ltcx_req_rd_sector_count_1_enc_str_4},
    {VOLTA_LTC0_LTCX_REQ_RD_SECTOR_COUNT_2, volta_ltc0_ltcx_req_rd_sector_count_2_enc_str_1,  volta_ltc0_ltcx_req_rd_sector_count_2_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc0_ltcx_req_rd_sector_count_2_enc_str_4},
    {VOLTA_LTC0_LTCX_REQ_RD_SECTOR_COUNT_3, volta_ltc0_ltcx_req_rd_sector_count_3_enc_str_1,  volta_ltc0_ltcx_req_rd_sector_count_3_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc0_ltcx_req_rd_sector_count_3_enc_str_4},
    {VOLTA_LTC0_LTCX_REQ_RD_SECTOR_COUNT_4, volta_ltc0_ltcx_req_rd_sector_count_4_enc_str_1,  volta_ltc0_ltcx_req_rd_sector_count_4_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc0_ltcx_req_rd_sector_count_4_enc_str_4},

    {VOLTA_LTC0_LTCX_REQ_WR_SECTOR_COUNT_1, volta_ltc0_ltcx_req_wr_sector_count_1_enc_str_1,  volta_ltc0_ltcx_req_wr_sector_count_1_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc0_ltcx_req_wr_sector_count_1_enc_str_4},
    {VOLTA_LTC0_LTCX_REQ_WR_SECTOR_COUNT_2, volta_ltc0_ltcx_req_wr_sector_count_2_enc_str_1,  volta_ltc0_ltcx_req_wr_sector_count_2_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc0_ltcx_req_wr_sector_count_2_enc_str_4},
    {VOLTA_LTC0_LTCX_REQ_WR_SECTOR_COUNT_3, volta_ltc0_ltcx_req_wr_sector_count_3_enc_str_1,  volta_ltc0_ltcx_req_wr_sector_count_3_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc0_ltcx_req_wr_sector_count_3_enc_str_4},
    {VOLTA_LTC0_LTCX_REQ_WR_SECTOR_COUNT_4, volta_ltc0_ltcx_req_wr_sector_count_4_enc_str_1,  volta_ltc0_ltcx_req_wr_sector_count_4_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc0_ltcx_req_wr_sector_count_4_enc_str_4},

    {VOLTA_LTC1_LTCX_MC_REQ_RD_SIZE_32B,    volta_ltc1_ltcx_mc_req_rd_size_32b_enc_str_1,     volta_ltc1_ltcx_mc_req_rd_size_32b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc1_ltcx_mc_req_rd_size_32b_enc_str_4},
    {VOLTA_LTC1_LTCX_MC_REQ_RD_SIZE_64B,    volta_ltc1_ltcx_mc_req_rd_size_64b_enc_str_1,     volta_ltc1_ltcx_mc_req_rd_size_64b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc1_ltcx_mc_req_rd_size_64b_enc_str_4},
    {VOLTA_LTC1_LTCX_MC_REQ_WR_SIZE_16B,    volta_ltc1_ltcx_mc_req_wr_size_16b_enc_str_1,     volta_ltc1_ltcx_mc_req_wr_size_16b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc1_ltcx_mc_req_wr_size_16b_enc_str_4},
    {VOLTA_LTC1_LTCX_MC_REQ_WR_SIZE_32B,    volta_ltc1_ltcx_mc_req_wr_size_32b_enc_str_1,     volta_ltc1_ltcx_mc_req_wr_size_32b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc1_ltcx_mc_req_wr_size_32b_enc_str_4},
    {VOLTA_LTC1_LTCX_MC_REQ_WR_SIZE_64B,    volta_ltc1_ltcx_mc_req_wr_size_64b_enc_str_1,     volta_ltc1_ltcx_mc_req_wr_size_64b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc1_ltcx_mc_req_wr_size_64b_enc_str_4},

    {VOLTA_LTC1_LTCX_REQ_RD_SECTOR_COUNT_1, volta_ltc1_ltcx_req_rd_sector_count_1_enc_str_1,  volta_ltc1_ltcx_req_rd_sector_count_1_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc1_ltcx_req_rd_sector_count_1_enc_str_4},
    {VOLTA_LTC1_LTCX_REQ_RD_SECTOR_COUNT_2, volta_ltc1_ltcx_req_rd_sector_count_2_enc_str_1,  volta_ltc1_ltcx_req_rd_sector_count_2_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc1_ltcx_req_rd_sector_count_2_enc_str_4},
    {VOLTA_LTC1_LTCX_REQ_RD_SECTOR_COUNT_3, volta_ltc1_ltcx_req_rd_sector_count_3_enc_str_1,  volta_ltc1_ltcx_req_rd_sector_count_3_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc1_ltcx_req_rd_sector_count_3_enc_str_4},
    {VOLTA_LTC1_LTCX_REQ_RD_SECTOR_COUNT_4, volta_ltc1_ltcx_req_rd_sector_count_4_enc_str_1,  volta_ltc1_ltcx_req_rd_sector_count_4_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc1_ltcx_req_rd_sector_count_4_enc_str_4},

    {VOLTA_LTC1_LTCX_REQ_WR_SECTOR_COUNT_1, volta_ltc1_ltcx_req_wr_sector_count_1_enc_str_1,  volta_ltc1_ltcx_req_wr_sector_count_1_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc1_ltcx_req_wr_sector_count_1_enc_str_4},
    {VOLTA_LTC1_LTCX_REQ_WR_SECTOR_COUNT_2, volta_ltc1_ltcx_req_wr_sector_count_2_enc_str_1,  volta_ltc1_ltcx_req_wr_sector_count_2_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc1_ltcx_req_wr_sector_count_2_enc_str_4},
    {VOLTA_LTC1_LTCX_REQ_WR_SECTOR_COUNT_3, volta_ltc1_ltcx_req_wr_sector_count_3_enc_str_1,  volta_ltc1_ltcx_req_wr_sector_count_3_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc1_ltcx_req_wr_sector_count_3_enc_str_4},
    {VOLTA_LTC1_LTCX_REQ_WR_SECTOR_COUNT_4, volta_ltc1_ltcx_req_wr_sector_count_4_enc_str_1,  volta_ltc1_ltcx_req_wr_sector_count_4_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_ltc1_ltcx_req_wr_sector_count_4_enc_str_4},
#endif //NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
    {VOLTA_NVLINK_RX_FLIT_ANY, volta_nvlink_rx_flit_any_enc_str_1, volta_nvlink_rx_flit_any_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_flit_any_enc_str_1},    
    {VOLTA_NVLINK_RX_FLIT_DATA, volta_nvlink_rx_flit_data_enc_str_1, volta_nvlink_rx_flit_data_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_flit_data_enc_str_1},
    {VOLTA_NVLINK_TX_FLIT_ANY, volta_nvlink_tx_flit_any_enc_str_1, volta_nvlink_tx_flit_any_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_flit_any_enc_str_1},    
    {VOLTA_NVLINK_TX_FLIT_DATA, volta_nvlink_tx_flit_data_enc_str_1, volta_nvlink_tx_flit_data_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_flit_data_enc_str_1},

    { VOLTA_NVLINK_TX_PKT_REQ_WRITE, volta_nvlink_tx_pkt_req_write_enc_str_1, volta_nvlink_tx_pkt_req_write_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_pkt_req_write_enc_str_1 },
    { VOLTA_NVLINK_TX_PKT_RSP_ALL, volta_nvlink_tx_pkt_rsp_all_enc_str_1, volta_nvlink_tx_pkt_rsp_all_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_pkt_rsp_all_enc_str_1 },
    { VOLTA_NVLINK_TX_PKT_REQ_ATOMIC, volta_nvlink_tx_pkt_req_atomic_enc_str_1, volta_nvlink_tx_pkt_req_atomic_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_pkt_req_atomic_enc_str_1 },
    { VOLTA_NVLINK_TX_PKT_REQ_ATOMIC_NONRED, volta_nvlink_tx_pkt_req_atomic_nonred_enc_str_1, volta_nvlink_tx_pkt_req_atomic_nonred_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_pkt_req_atomic_nonred_enc_str_1 },
    { VOLTA_NVLINK_TX_PKT_REQ_ATOMIC_POSTED_RED, volta_nvlink_tx_pkt_req_atomic_posted_red_enc_str_1, volta_nvlink_tx_pkt_req_atomic_posted_red_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_pkt_req_atomic_posted_red_enc_str_1 },
    { VOLTA_NVLINK_TX_PKT_REQ_ATOMIC_NONPOSTED_RED, volta_nvlink_tx_pkt_req_atomic_nonposted_red_enc_str_1, volta_nvlink_tx_pkt_req_atomic_nonposted_red_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_pkt_req_atomic_nonposted_red_enc_str_1 },
    { VOLTA_NVLINK_TX_PKT_REQ_RMW, volta_nvlink_tx_pkt_req_rmw_enc_str_1, volta_nvlink_tx_pkt_req_rmw_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_pkt_req_rmw_enc_str_1 },
    { VOLTA_NVLINK_TX_STALL_ANY_VC, volta_nvlink_tx_stall_any_vc_enc_str_1, volta_nvlink_tx_stall_any_vc_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_stall_any_vc_enc_str_1 },
    { VOLTA_NVLINK_TX_PKT_REQ_ALL, volta_nvlink_tx_pkt_req_all_enc_str_1, volta_nvlink_tx_pkt_req_all_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_pkt_req_all_enc_str_1 },
    { VOLTA_NVLINK_TX_STALL_ALL_VC, volta_nvlink_tx_stall_all_vc_enc_str_1, volta_nvlink_tx_stall_all_vc_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_stall_all_vc_enc_str_1 },
    { VOLTA_NVLINK_TX_PKT_REQ_READ, volta_nvlink_tx_pkt_req_read_enc_str_1, volta_nvlink_tx_pkt_req_read_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_pkt_req_read_enc_str_1 },
    { VOLTA_NVLINK_TX_FLIT_HEADER, volta_nvlink_tx_flit_header_enc_str_1, volta_nvlink_tx_flit_header_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_flit_header_enc_str_1 },

    { VOLTA_NVLINK_RX_PKT_REQ_WRITE, volta_nvlink_rx_pkt_req_write_enc_str_1, volta_nvlink_rx_pkt_req_write_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_pkt_req_write_enc_str_1 },
    { VOLTA_NVLINK_RX_PKT_RSP_ALL, volta_nvlink_rx_pkt_rsp_all_enc_str_1, volta_nvlink_rx_pkt_rsp_all_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_pkt_rsp_all_enc_str_1 },
    { VOLTA_NVLINK_RX_PKT_REQ_ATOMIC, volta_nvlink_rx_pkt_req_atomic_enc_str_1, volta_nvlink_rx_pkt_req_atomic_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_pkt_req_atomic_enc_str_1 },
    { VOLTA_NVLINK_RX_PKT_REQ_ATOMIC_NONRED, volta_nvlink_rx_pkt_req_atomic_nonred_enc_str_1, volta_nvlink_rx_pkt_req_atomic_nonred_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_pkt_req_atomic_nonred_enc_str_1 },
    { VOLTA_NVLINK_RX_PKT_REQ_ATOMIC_POSTED_RED, volta_nvlink_rx_pkt_req_atomic_posted_red_enc_str_1, volta_nvlink_rx_pkt_req_atomic_posted_red_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_pkt_req_atomic_posted_red_enc_str_1 },
    { VOLTA_NVLINK_RX_PKT_REQ_ATOMIC_NONPOSTED_RED, volta_nvlink_rx_pkt_req_atomic_nonposted_red_enc_str_1, volta_nvlink_rx_pkt_req_atomic_nonposted_red_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_pkt_req_atomic_nonposted_red_enc_str_1 },
    { VOLTA_NVLINK_RX_PKT_REQ_RMW, volta_nvlink_rx_pkt_req_rmw_enc_str_1, volta_nvlink_rx_pkt_req_rmw_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_pkt_req_rmw_enc_str_1 },
    { VOLTA_NVLINK_RX_STALL_ANY_VC, volta_nvlink_rx_stall_any_vc_enc_str_1, volta_nvlink_rx_stall_any_vc_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_stall_any_vc_enc_str_1 },
    { VOLTA_NVLINK_RX_PKT_REQ_ALL, volta_nvlink_rx_pkt_req_all_enc_str_1, volta_nvlink_rx_pkt_req_all_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_pkt_req_all_enc_str_1 },
    { VOLTA_NVLINK_RX_STALL_ALL_VC, volta_nvlink_rx_stall_all_vc_enc_str_1, volta_nvlink_rx_stall_all_vc_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_stall_all_vc_enc_str_1 },
    { VOLTA_NVLINK_RX_PKT_REQ_READ, volta_nvlink_rx_pkt_req_read_enc_str_1, volta_nvlink_rx_pkt_req_read_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_pkt_req_read_enc_str_1 },
    { VOLTA_NVLINK_RX_FLIT_HEADER, volta_nvlink_rx_flit_header_enc_str_1, volta_nvlink_rx_flit_header_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_flit_header_enc_str_1 },

    { VOLTA_NVLINK_TX_WRITE_TOTAL_FLITS, volta_nvlink_tx_write_total_flits_enc_str_1, volta_nvlink_tx_write_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_write_total_flits_enc_str_1 },
    { VOLTA_NVLINK_TX_WRITE_DATA_FLITS, volta_nvlink_tx_write_data_flits_enc_str_1, volta_nvlink_tx_write_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_write_data_flits_enc_str_1 },
    { VOLTA_NVLINK_TX_RSP_TOTAL_FLITS, volta_nvlink_tx_rsp_total_flits_enc_str_1, volta_nvlink_tx_rsp_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_rsp_total_flits_enc_str_1 },
    { VOLTA_NVLINK_TX_RSP_DATA_FLITS, volta_nvlink_tx_rsp_data_flits_enc_str_1, volta_nvlink_tx_rsp_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_rsp_data_flits_enc_str_1 },
    { VOLTA_NVLINK_TX_NRATOM_TOTAL_FLITS, volta_nvlink_tx_nratom_total_flits_enc_str_1, volta_nvlink_tx_nratom_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_nratom_total_flits_enc_str_1 },
    { VOLTA_NVLINK_TX_NRATOM_DATA_FLITS, volta_nvlink_tx_nratom_data_flits_enc_str_1, volta_nvlink_tx_nratom_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_nratom_data_flits_enc_str_1 },
    { VOLTA_NVLINK_TX_RATOM_TOTAL_FLITS, volta_nvlink_tx_ratom_total_flits_enc_str_1, volta_nvlink_tx_ratom_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_ratom_total_flits_enc_str_1 },
    { VOLTA_NVLINK_TX_RATOM_DATA_FLITS, volta_nvlink_tx_ratom_data_flits_enc_str_1, volta_nvlink_tx_ratom_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_ratom_data_flits_enc_str_1 },
    { VOLTA_NVLINK_RX_WRITE_TOTAL_FLITS, volta_nvlink_rx_write_total_flits_enc_str_1, volta_nvlink_rx_write_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_write_total_flits_enc_str_1 },
    { VOLTA_NVLINK_RX_WRITE_DATA_FLITS, volta_nvlink_rx_write_data_flits_enc_str_1, volta_nvlink_rx_write_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_write_data_flits_enc_str_1 },
    { VOLTA_NVLINK_RX_RSP_TOTAL_FLITS, volta_nvlink_rx_rsp_total_flits_enc_str_1, volta_nvlink_rx_rsp_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_rsp_total_flits_enc_str_1 },
    { VOLTA_NVLINK_RX_RSP_DATA_FLITS, volta_nvlink_rx_rsp_data_flits_enc_str_1, volta_nvlink_rx_rsp_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_rsp_data_flits_enc_str_1 },
    { VOLTA_NVLINK_RX_NRATOM_TOTAL_FLITS, volta_nvlink_rx_nratom_total_flits_enc_str_1, volta_nvlink_rx_nratom_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_nratom_total_flits_enc_str_1 },
    { VOLTA_NVLINK_RX_NRATOM_DATA_FLITS, volta_nvlink_rx_nratom_data_flits_enc_str_1, volta_nvlink_rx_nratom_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_nratom_data_flits_enc_str_1 },
    { VOLTA_NVLINK_RX_RATOM_TOTAL_FLITS, volta_nvlink_rx_ratom_total_flits_enc_str_1, volta_nvlink_rx_ratom_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_ratom_total_flits_enc_str_1 },
    { VOLTA_NVLINK_RX_RATOM_DATA_FLITS, volta_nvlink_rx_ratom_data_flits_enc_str_1, volta_nvlink_rx_ratom_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_ratom_data_flits_enc_str_1 },
    { VOLTA_NVLINK_TX_READ_TOTAL_FLITS, volta_nvlink_tx_read_total_flits_enc_str_1, volta_nvlink_tx_read_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_read_total_flits_enc_str_1 },
    { VOLTA_NVLINK_TX_READ_DATA_FLITS, volta_nvlink_tx_read_data_flits_enc_str_1, volta_nvlink_tx_read_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_read_data_flits_enc_str_1 },
    { VOLTA_NVLINK_RX_READ_TOTAL_FLITS, volta_nvlink_rx_read_total_flits_enc_str_1, volta_nvlink_rx_read_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_read_total_flits_enc_str_1 },
    { VOLTA_NVLINK_RX_READ_DATA_FLITS, volta_nvlink_rx_read_data_flits_enc_str_1, volta_nvlink_rx_read_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_read_data_flits_enc_str_1 },

    { VOLTA_NVLINK_RX_THROUGHPUT_CNT0, volta_nvlink_rx_throughput_cnt0_enc_str_1, volta_nvlink_rx_throughput_cnt0_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_throughput_cnt0_enc_str_1 },
    { VOLTA_NVLINK_RX_THROUGHPUT_CNT1, volta_nvlink_rx_throughput_cnt1_enc_str_1, volta_nvlink_rx_throughput_cnt1_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_rx_throughput_cnt1_enc_str_1 },
    { VOLTA_NVLINK_TX_THROUGHPUT_CNT0, volta_nvlink_tx_throughput_cnt0_enc_str_1, volta_nvlink_tx_throughput_cnt0_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_throughput_cnt0_enc_str_1 },
    { VOLTA_NVLINK_TX_THROUGHPUT_CNT1, volta_nvlink_tx_throughput_cnt1_enc_str_1, volta_nvlink_tx_throughput_cnt1_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_nvlink_tx_throughput_cnt1_enc_str_1 },

    { VOLTA_MIO_L1DATA_DATA_CONFLICTS, volta_mio_l1data_data_conflicts_enc_str_1, volta_mio_l1data_data_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1data_data_conflicts_enc_str_1 },
    { VOLTA_MIO_L1DATA_DATA_CONFLICTS_SM_XBAR, volta_mio_l1data_data_conflicts_sm_xbar_enc_str_1, volta_mio_l1data_data_conflicts_sm_xbar_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1data_data_conflicts_sm_xbar_enc_str_1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA, volta_mio_wavefront_count_l1data_enc_str_1, volta_mio_wavefront_count_l1data_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_wavefront_count_l1data_enc_str_1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_LG, volta_mio_wavefront_count_l1data_lg_enc_str_1, volta_mio_wavefront_count_l1data_lg_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_wavefront_count_l1data_lg_enc_str_1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_LG, volta_mio_wavefront_count_l1data_lg_enc_str_1, volta_mio_wavefront_count_l1data_lg_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_wavefront_count_l1data_lg_enc_str_1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_BANK_READS, volta_mio_wavefront_count_l1data_bank_reads_enc_str_1, volta_mio_wavefront_count_l1data_bank_reads_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_wavefront_count_l1data_bank_reads_enc_str_1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_BANK_WRITES, volta_mio_wavefront_count_l1data_bank_writes_enc_str_1, volta_mio_wavefront_count_l1data_bank_writes_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_wavefront_count_l1data_bank_writes_enc_str_1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_READ, volta_mio_wavefront_count_l1data_read_enc_str_1, volta_mio_wavefront_count_l1data_read_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_wavefront_count_l1data_read_enc_str_1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_WRITE, volta_mio_wavefront_count_l1data_write_enc_str_1, volta_mio_wavefront_count_l1data_write_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_wavefront_count_l1data_write_enc_str_1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_SHMEM, volta_mio_wavefront_count_l1data_shmem_enc_str_1, volta_mio_wavefront_count_l1data_shmem_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_wavefront_count_l1data_shmem_enc_str_1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_SURF, volta_mio_wavefront_count_l1data_surf_enc_str_1, volta_mio_wavefront_count_l1data_surf_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_wavefront_count_l1data_surf_enc_str_1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_TEX, volta_mio_wavefront_count_l1data_tex_enc_str_1, volta_mio_wavefront_count_l1data_tex_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_wavefront_count_l1data_tex_enc_str_1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_TO_DSTAGE, volta_mio_wavefront_count_l1data_to_dstage_enc_str_1, volta_mio_wavefront_count_l1data_to_dstage_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_wavefront_count_l1data_to_dstage_enc_str_1 },
    { VOLTA_MIO_WAVEFRONT_COUNT_L1DATA_TO_MIOP_WBB_DATA, volta_mio_wavefront_count_l1data_to_miop_wbb_data_enc_str_1, volta_mio_wavefront_count_l1data_to_miop_wbb_data_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_wavefront_count_l1data_to_miop_wbb_data_enc_str_1 },
    { VOLTA_MIO_L1DATA_SHARED_LD, volta_mio_l1data_shared_ld_enc_str_1, volta_mio_l1data_shared_ld_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1data_shared_ld_enc_str_3 },
    { VOLTA_MIO_L1DATA_SHARED_ST, volta_mio_l1data_shared_st_enc_str_1, volta_mio_l1data_shared_st_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1data_shared_st_enc_str_3 },
    { VOLTA_MIO_L1DATA_SHARED_LD_REQUESTS, volta_mio_l1data_shared_ld_requests_enc_str_1, volta_mio_l1data_shared_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1data_shared_ld_requests_enc_str_1 },
    { VOLTA_MIO_L1DATA_SHARED_ST_REQUESTS, volta_mio_l1data_shared_st_requests_enc_str_1, volta_mio_l1data_shared_st_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1data_shared_st_requests_enc_str_1 },
    { VOLTA_MIO_L1DATA_IPA_LD_REQUESTS, volta_mio_l1data_ipa_ld_requests_enc_str_1, volta_mio_l1data_ipa_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1data_ipa_ld_requests_enc_str_1 },
    { VOLTA_MIO_L1DATA_SURFACE_ATOM_DATA_CONFLICTS, volta_mio_l1data_surface_atom_data_conflicts_enc_str_1, volta_mio_l1data_surface_atom_data_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1data_surface_atom_data_conflicts_enc_str_1 },
    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_1, volta_mio_l1miss_l2_requests_missed_sectors_1_enc_str_1, volta_mio_l1miss_l2_requests_missed_sectors_1_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1miss_l2_requests_missed_sectors_1_enc_str_1 },
    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_2, volta_mio_l1miss_l2_requests_missed_sectors_2_enc_str_1, volta_mio_l1miss_l2_requests_missed_sectors_2_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1miss_l2_requests_missed_sectors_2_enc_str_1 },
    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_3, volta_mio_l1miss_l2_requests_missed_sectors_3_enc_str_1, volta_mio_l1miss_l2_requests_missed_sectors_3_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1miss_l2_requests_missed_sectors_3_enc_str_1 },
    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_4, volta_mio_l1miss_l2_requests_missed_sectors_4_enc_str_1, volta_mio_l1miss_l2_requests_missed_sectors_4_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1miss_l2_requests_missed_sectors_4_enc_str_1 },
    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_5, volta_mio_l1miss_l2_requests_missed_sectors_5_enc_str_1, volta_mio_l1miss_l2_requests_missed_sectors_5_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1miss_l2_requests_missed_sectors_5_enc_str_1 },
    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_6, volta_mio_l1miss_l2_requests_missed_sectors_6_enc_str_1, volta_mio_l1miss_l2_requests_missed_sectors_6_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1miss_l2_requests_missed_sectors_6_enc_str_1 },
    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_7, volta_mio_l1miss_l2_requests_missed_sectors_7_enc_str_1, volta_mio_l1miss_l2_requests_missed_sectors_7_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1miss_l2_requests_missed_sectors_7_enc_str_1 },
    { VOLTA_MIO_L1MISS_L2_REQUESTS_MISSED_SECTORS_8, volta_mio_l1miss_l2_requests_missed_sectors_8_enc_str_1, volta_mio_l1miss_l2_requests_missed_sectors_8_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1miss_l2_requests_missed_sectors_8_enc_str_1 },
    { VOLTA_MIO_L1TAG_REQUESTS_PRECOALESCING, volta_mio_l1tag_requests_precoalescing_enc_str_1, volta_mio_l1tag_requests_precoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_requests_precoalescing_enc_str_1 },
    { VOLTA_MIO_L1TAG_SECTORS_PRECOALESCING, volta_mio_l1tag_sectors_precoalescing_enc_str_1, volta_mio_l1tag_sectors_precoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_sectors_precoalescing_enc_str_1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_REQUESTS_POSTCOALESCING, volta_mio_l1miss_tex2gnic_requests_postcoalescing_enc_str_1, volta_mio_l1miss_tex2gnic_requests_postcoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1miss_tex2gnic_requests_postcoalescing_enc_str_1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_SECTORS_SUM_POSTCOALESCING, volta_mio_l1miss_tex2gnic_sectors_sum_postcoalescing_enc_str_1, volta_mio_l1miss_tex2gnic_sectors_sum_postcoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1miss_tex2gnic_sectors_sum_postcoalescing_enc_str_1 },
    { VOLTA_MIO_L1TAG_CACHE_SECTOR_QUERIES, volta_mio_l1tag_cache_sector_queries_enc_str_1, volta_mio_l1tag_cache_sector_queries_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_cache_sector_queries_enc_str_1 },
    { VOLTA_MIO_IDC_DIVERGENCE_REPLAY, volta_mio_idc_divergence_replay_enc_str_1, volta_mio_idc_divergence_replay_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_idc_divergence_replay_enc_str_1 },
    { VOLTA_MIO_IDC_DIVERGENT_INSTRUCTION, volta_mio_idc_divergent_instruction_enc_str_1, volta_mio_idc_divergent_instruction_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_idc_divergent_instruction_enc_str_1 },
    { VOLTA_MIO_L1TAG_SET_ACCESSES, volta_mio_l1tag_set_accesses_enc_str_1, volta_mio_l1tag_set_accesses_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_set_accesses_enc_str_1 },
    { VOLTA_MIO_L1TAG_SET_CONFLICTS, volta_mio_l1tag_set_conflicts_enc_str_1, volta_mio_l1tag_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_set_conflicts_enc_str_1 },
    { VOLTA_MIO_L1TAG_REQUESTS, volta_mio_l1tag_requests_enc_str_1, volta_mio_l1tag_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_requests_enc_str_1 },
    { VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT, volta_mio_l1tag_sector_tag_hit_data_hit_enc_str_1, volta_mio_l1tag_sector_tag_hit_data_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_sector_tag_hit_data_hit_enc_str_1 },
    { VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_BYPASS_T2D, volta_mio_l1tag_sector_tag_hit_data_hit_bypass_t2d_enc_str_1, volta_mio_l1tag_sector_tag_hit_data_hit_bypass_t2d_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_sector_tag_hit_data_hit_bypass_t2d_enc_str_1 },
    { VOLTA_MIO_L1TAG_SECTOR_TAG_MISS, volta_mio_l1tag_sector_tag_miss_enc_str_1, volta_mio_l1tag_sector_tag_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_sector_tag_miss_enc_str_1 },
    { VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_MISS, volta_mio_l1tag_sector_tag_hit_data_miss_enc_str_1, volta_mio_l1tag_sector_tag_hit_data_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_sector_tag_hit_data_miss_enc_str_1 },
    { VOLTA_TEX_F_TEX2SM_TEX_PVLD, volta_tex_f_tex2sm_tex_pvld_enc_str_1, volta_tex_f_tex2sm_tex_pvld_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_f_tex2sm_tex_pvld_enc_str_1 },
    { VOLTA_TEX_F_TEX2SM_TEX_PRDY, volta_tex_f_tex2sm_tex_prdy_enc_str_1, volta_tex_f_tex2sm_tex_prdy_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_f_tex2sm_tex_prdy_enc_str_1 },
    { VOLTA_TEX_F_SKIPPED_RETURN_BEATS, volta_tex_f_skipped_return_beats_enc_str_1, volta_tex_f_skipped_return_beats_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_f_skipped_return_beats_enc_str_1 },
    { VOLTA_TEX_F_DATA_RETURN_BEATS, volta_tex_f_data_return_beats_enc_str_1, volta_tex_f_data_return_beats_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_f_data_return_beats_enc_str_1 },
    { VOLTA_TEX_SMV2TEX_DATA_PVLD, volta_tex_smv2tex_data_pvld_enc_str_1, volta_tex_smv2tex_data_pvld_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_smv2tex_data_pvld_enc_str_1 },
    { VOLTA_TEX_SMV2TEX_DATA_PRDY, volta_tex_smv2tex_data_prdy_enc_str_1, volta_tex_smv2tex_data_prdy_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_smv2tex_data_prdy_enc_str_1 },
    { VOLTA_TEX_SMV2TEX_REQ_PVLD, volta_tex_smv2tex_req_pvld_enc_str_1, volta_tex_smv2tex_req_pvld_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_smv2tex_req_pvld_enc_str_1 },
    { VOLTA_TEX_SMV2TEX_REQ_PRDY, volta_tex_smv2tex_req_prdy_enc_str_1, volta_tex_smv2tex_req_prdy_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_smv2tex_req_prdy_enc_str_1 },
    { VOLTA_TEX_F_ACCUM_STALL, volta_tex_f_accum_stall_enc_str_1, volta_tex_f_accum_stall_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_f_accum_stall_enc_str_1 },
    { VOLTA_TEX_F_ANY_PVLD, volta_tex_f_any_pvld_enc_str_1, volta_tex_f_any_pvld_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_f_any_pvld_enc_str_1 },
    { VOLTA_TEX_RETURN_PACKET_COUNT, volta_tex_return_packet_count_enc_str_1, volta_tex_return_packet_count_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_return_packet_count_enc_str_1 },
    { VOLTA_TEX_SHARED_LD_DATA_CONFLICTS, volta_tex_shared_ld_data_conflicts_enc_str_1, volta_tex_shared_ld_data_conflicts_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_shared_ld_data_conflicts_enc_str_3 },
    { VOLTA_TEX_SHARED_ST_DATA_CONFLICTS, volta_tex_shared_st_data_conflicts_enc_str_1, volta_tex_shared_st_data_conflicts_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_shared_st_data_conflicts_enc_str_3 },
    { VOLTA_TEX_GLOBAL_LD_DATA_CONFLICTS, volta_tex_global_ld_data_conflicts_enc_str_1, volta_tex_global_ld_data_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_global_ld_data_conflicts_enc_str_1 },
    { VOLTA_TEX_GLOBAL_ST_DATA_CONFLICTS, volta_tex_global_st_data_conflicts_enc_str_1, volta_tex_global_st_data_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_global_st_data_conflicts_enc_str_1 },
    { VOLTA_TEX_ATOM_DATA_CONFLICTS, volta_tex_atom_data_conflicts_enc_str_1, volta_tex_atom_data_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_atom_data_conflicts_enc_str_1 },
    { VOLTA_TEX_GLOBAL_RED_DATA_CONFLICTS, volta_tex_global_red_data_conflicts_enc_str_1, volta_tex_global_red_data_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_global_red_data_conflicts_enc_str_1 },
    { VOLTA_TEX_SURFACE_RED_DATA_CONFLICTS, volta_tex_surface_red_data_conflicts_enc_str_1, volta_tex_surface_red_data_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_surface_red_data_conflicts_enc_str_1 },
    { VOLTA_TEX_SURFACE_ST_DATA_CONFLICTS, volta_tex_surface_st_data_conflicts_enc_str_1, volta_tex_surface_st_data_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_surface_st_data_conflicts_enc_str_1 },
    { VOLTA_MIO_LG_REQUESTS_PRECOALESCING, volta_mio_lg_requests_precoalescing_enc_str_1, volta_mio_lg_requests_precoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_lg_requests_precoalescing_enc_str_1 },
    { VOLTA_MIO_LG_SECTORS_PRECOALESCING, volta_mio_lg_sectors_precoalescing_enc_str_1, volta_mio_lg_sectors_precoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_lg_sectors_precoalescing_enc_str_1 },
    { VOLTA_MIO_SURFACE_REQUESTS_PRECOALESCING, volta_mio_surface_requests_precoalescing_enc_str_1, volta_mio_surface_requests_precoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_requests_precoalescing_enc_str_1 },
    { VOLTA_MIO_SURFACE_SECTORS_PRECOALESCING, volta_mio_surface_sectors_precoalescing_enc_str_1, volta_mio_surface_sectors_precoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_sectors_precoalescing_enc_str_1 },
    { VOLTA_MIO_TEXTURE_REQUESTS_PRECOALESCING, volta_mio_texture_requests_precoalescing_enc_str_1, volta_mio_texture_requests_precoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_texture_requests_precoalescing_enc_str_1 },
    { VOLTA_MIO_TEXTURE_SECTORS_PRECOALESCING, volta_mio_texture_sectors_precoalescing_enc_str_1, volta_mio_texture_sectors_precoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_texture_sectors_precoalescing_enc_str_1 },
    { VOLTA_MIO_LG_READ_REQUESTS_PRECOALESCING, volta_mio_lg_read_requests_precoalescing_enc_str_1, volta_mio_lg_read_requests_precoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_lg_read_requests_precoalescing_enc_str_1 },
    { VOLTA_MIO_LG_READ_SECTORS_PRECOALESCING, volta_mio_lg_read_sectors_precoalescing_enc_str_1, volta_mio_lg_read_sectors_precoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_lg_read_sectors_precoalescing_enc_str_1 },
    { VOLTA_MIO_LG_WRITE_REQUESTS_PRECOALESCING, volta_mio_lg_write_requests_precoalescing_enc_str_1, volta_mio_lg_write_requests_precoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_lg_write_requests_precoalescing_enc_str_1 },
    { VOLTA_MIO_LG_WRITE_SECTORS_PRECOALESCING, volta_mio_lg_write_sectors_precoalescing_enc_str_1, volta_mio_lg_write_sectors_precoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_lg_write_sectors_precoalescing_enc_str_1 },
    { VOLTA_MIO_SURFACE_READ_REQUESTS_PRECOALESCING, volta_mio_surface_read_requests_precoalescing_enc_str_1, volta_mio_surface_read_requests_precoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_read_requests_precoalescing_enc_str_1 },
    { VOLTA_MIO_SURFACE_READ_SECTORS_PRECOALESCING, volta_mio_surface_read_sectors_precoalescing_enc_str_1, volta_mio_surface_read_sectors_precoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_read_sectors_precoalescing_enc_str_1 },
    { VOLTA_MIO_SURFACE_WRITE_REQUESTS_PRECOALESCING, volta_mio_surface_write_requests_precoalescing_enc_str_1, volta_mio_surface_write_requests_precoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_write_requests_precoalescing_enc_str_1 },
    { VOLTA_MIO_SURFACE_WRITE_SECTORS_PRECOALESCING, volta_mio_surface_write_sectors_precoalescing_enc_str_1, volta_mio_surface_write_sectors_precoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_write_sectors_precoalescing_enc_str_1 },
    { VOLTA_MIO_TEXTURE_TEX_REQUESTS_PRECOALESCING, volta_mio_texture_tex_requests_precoalescing_enc_str_1, volta_mio_texture_tex_requests_precoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_texture_tex_requests_precoalescing_enc_str_1 },
    { VOLTA_MIO_TEXTURE_TEX_SECTORS_PRECOALESCING, volta_mio_texture_tex_sectors_precoalescing_enc_str_1, volta_mio_texture_tex_sectors_precoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_texture_tex_sectors_precoalescing_enc_str_1 },
    { VOLTA_MIO_TEXTURE_TLD_REQUESTS_PRECOALESCING, volta_mio_texture_ld_requests_precoalescing_enc_str_1, volta_mio_texture_ld_requests_precoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_texture_ld_requests_precoalescing_enc_str_1 },
    { VOLTA_MIO_TEXTURE_LD_SECTORS_PRECOALESCING, volta_mio_texture_ld_sectors_precoalescing_enc_str_1, volta_mio_texture_ld_sectors_precoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_texture_ld_sectors_precoalescing_enc_str_1 },
    
    { VOLTA_MIO_LG_REQUESTS_POSTCOALESCING, volta_mio_lg_requests_postcoalescing_enc_str_1, volta_mio_lg_requests_postcoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_lg_requests_postcoalescing_enc_str_1 },
    { VOLTA_MIO_LG_SECTORS_POSTCOALESCING, volta_mio_lg_sectors_postcoalescing_enc_str_1, volta_mio_lg_sectors_postcoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_lg_sectors_postcoalescing_enc_str_1 },
    { VOLTA_MIO_SURFACE_REQUESTS_POSTCOALESCING, volta_mio_surface_requests_postcoalescing_enc_str_1, volta_mio_surface_requests_postcoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_requests_postcoalescing_enc_str_1 },
    { VOLTA_MIO_SURFACE_SECTORS_POSTCOALESCING, volta_mio_surface_sectors_postcoalescing_enc_str_1, volta_mio_surface_sectors_postcoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_sectors_postcoalescing_enc_str_1 },
    { VOLTA_MIO_TEXTURE_REQUESTS_POSTCOALESCING, volta_mio_texture_requests_postcoalescing_enc_str_1, volta_mio_texture_requests_postcoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_texture_requests_postcoalescing_enc_str_1 },
    { VOLTA_MIO_TEXTURE_SECTORS_POSTCOALESCING, volta_mio_texture_sectors_postcoalescing_enc_str_1, volta_mio_texture_sectors_postcoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_texture_sectors_postcoalescing_enc_str_1 },
    { VOLTA_MIO_LG_READ_REQUESTS_POSTCOALESCING, volta_mio_lg_read_requests_postcoalescing_enc_str_1, volta_mio_lg_read_requests_postcoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_lg_read_requests_postcoalescing_enc_str_1 },
    { VOLTA_MIO_LG_READ_SECTORS_POSTCOALESCING, volta_mio_lg_read_sectors_postcoalescing_enc_str_1, volta_mio_lg_read_sectors_postcoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_lg_read_sectors_postcoalescing_enc_str_1 },
    { VOLTA_MIO_LG_WRITE_REQUESTS_POSTCOALESCING, volta_mio_lg_write_requests_postcoalescing_enc_str_1, volta_mio_lg_write_requests_postcoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_lg_write_requests_postcoalescing_enc_str_1 },
    { VOLTA_MIO_LG_WRITE_SECTORS_POSTCOALESCING, volta_mio_lg_write_sectors_postcoalescing_enc_str_1, volta_mio_lg_write_sectors_postcoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_lg_write_sectors_postcoalescing_enc_str_1 },
    { VOLTA_MIO_SURFACE_READ_REQUESTS_POSTCOALESCING, volta_mio_surface_read_requests_postcoalescing_enc_str_1, volta_mio_surface_read_requests_postcoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_read_requests_postcoalescing_enc_str_1 },
    { VOLTA_MIO_SURFACE_READ_SECTORS_POSTCOALESCING, volta_mio_surface_read_sectors_postcoalescing_enc_str_1, volta_mio_surface_read_sectors_postcoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_read_sectors_postcoalescing_enc_str_1 },
    { VOLTA_MIO_SURFACE_WRITE_REQUESTS_POSTCOALESCING, volta_mio_surface_write_requests_postcoalescing_enc_str_1, volta_mio_surface_write_requests_postcoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_write_requests_postcoalescing_enc_str_1 },
    { VOLTA_MIO_SURFACE_WRITE_SECTORS_POSTCOALESCING, volta_mio_surface_write_sectors_postcoalescing_enc_str_1, volta_mio_surface_write_sectors_postcoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_write_sectors_postcoalescing_enc_str_1 },
    
    { VOLTA_MIO_GLOBAL_ST_REQUESTS, volta_mio_global_st_requests_enc_str_1, volta_mio_global_st_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_global_st_requests_enc_str_1 },
    { VOLTA_MIO_LOCAL_ST_REQUESTS, volta_mio_local_st_requests_enc_str_1, volta_mio_local_st_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_local_st_requests_enc_str_1 },
    { VOLTA_MIO_MIXED_GENERIC_LD_REQUESTS, volta_mio_mixed_generic_ld_requests_enc_str_1, volta_mio_mixed_generic_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_mixed_generic_ld_requests_enc_str_1 },
    { VOLTA_MIO_MIXED_GENERIC_ST_REQUESTS, volta_mio_mixed_generic_st_requests_enc_str_1, volta_mio_mixed_generic_st_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_mixed_generic_st_requests_enc_str_1 },
    { VOLTA_MIO_SURFACE_ST_REQUESTS, volta_mio_surface_st_requests_enc_str_1, volta_mio_surface_st_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_st_requests_enc_str_1 },
    { VOLTA_MIO_TYPE_1D_REQUESTS, volta_mio_type_1d_requests_enc_str_1, volta_mio_type_1d_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_type_1d_requests_enc_str_1 },
    { VOLTA_MIO_TYPE_1D_BUFFER_REQUESTS, volta_mio_type_1d_buffer_requests_enc_str_1, volta_mio_type_1d_buffer_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_type_1d_buffer_requests_enc_str_1 },
    { VOLTA_MIO_TYPE_2D_REQUESTS, volta_mio_type_2d_requests_enc_str_1, volta_mio_type_2d_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_type_2d_requests_enc_str_1 },
    { VOLTA_MIO_TYPE_3D_REQUESTS, volta_mio_type_3d_requests_enc_str_1, volta_mio_type_3d_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_type_3d_requests_enc_str_1 },
    { VOLTA_MIO_TYPE_CUBEMAP_REQUESTS, volta_mio_type_cubemap_requests_enc_str_1, volta_mio_type_cubemap_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_type_cubemap_requests_enc_str_1 },
    { VOLTA_MIO_TYPE_NO_MIPMAP_REQUESTS, volta_mio_type_no_mipmap_requests_enc_str_1, volta_mio_type_no_mipmap_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_type_no_mipmap_requests_enc_str_1 },
    { VOLTA_MIO_GLOBAL_LD_REQUESTS, volta_mio_global_ld_requests_enc_str_1, volta_mio_global_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_global_ld_requests_enc_str_1 },
    { VOLTA_MIO_LOCAL_LD_REQUESTS, volta_mio_local_ld_requests_enc_str_1, volta_mio_local_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_local_ld_requests_enc_str_1 },
    { VOLTA_MIO_SURFACE_LD_REQUESTS, volta_mio_surface_ld_requests_enc_str_1, volta_mio_surface_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_ld_requests_enc_str_1 },
    { VOLTA_MIO_SURFACE_RED_REQUESTS, volta_mio_surface_red_requests_enc_str_1, volta_mio_surface_red_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_red_requests_enc_str_1 },
    { VOLTA_MIO_SURFACE_ATOM_REQUESTS, volta_mio_surface_atom_requests_enc_str_1, volta_mio_surface_atom_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_atom_requests_enc_str_1 },
    { VOLTA_MIO_TEXTURE_LD_REQUESTS, volta_mio_texture_ld_requests_enc_str_1, volta_mio_texture_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_texture_ld_requests_enc_str_1 },
    { VOLTA_MIO_GLOBAL_RED_REQUESTS, volta_mio_global_red_requests_enc_str_1, volta_mio_global_red_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_global_red_requests_enc_str_1 },
    { VOLTA_MIO_ATOM_REQUESTS, volta_mio_atom_requests_enc_str_1, volta_mio_atom_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_atom_requests_enc_str_1 },
    { VOLTA_MIO_L1TAG_TEXTURE_LD_REQUESTS, volta_mio_l1tag_texture_ld_requests_enc_str_1, volta_mio_l1tag_texture_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_texture_ld_requests_enc_str_1},
    { VOLTA_MIO_L1TAG_TEXTURE_TEX_REQUESTS, volta_mio_l1tag_texture_tex_requests_enc_str_1, volta_mio_l1tag_texture_tex_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_texture_tex_requests_enc_str_1},

    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_RD, volta_mio_l1miss_tex2gnic_fold_rd_enc_str_1, volta_mio_l1miss_tex2gnic_fold_rd_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1miss_tex2gnic_fold_rd_enc_str_1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_PACK_RD, volta_mio_l1miss_tex2gnic_fold_pack_rd_enc_str_1, volta_mio_l1miss_tex2gnic_fold_pack_rd_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1miss_tex2gnic_fold_pack_rd_enc_str_1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_2SECTORS_SUM, volta_mio_l1miss_tex2gnic_fold_2sectors_sum_enc_str_1, volta_mio_l1miss_tex2gnic_fold_2sectors_sum_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1miss_tex2gnic_fold_2sectors_sum_enc_str_1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_WR, volta_mio_l1miss_tex2gnic_fold_wr_enc_str_1, volta_mio_l1miss_tex2gnic_fold_wr_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1miss_tex2gnic_fold_wr_enc_str_1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_WR_BYTES_SUM, volta_mio_l1miss_tex2gnic_fold_wr_bytes_sum_enc_str_1, volta_mio_l1miss_tex2gnic_fold_wr_bytes_sum_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1miss_tex2gnic_fold_wr_bytes_sum_enc_str_1 },
    { VOLTA_MIO_L1TAG_SECTORS_PROMOTED, volta_mio_l1tag_sectors_promoted_enc_str_1, volta_mio_l1tag_sectors_promoted_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_sectors_promoted_enc_str_1 },
    { VOLTA_MIO_L1TAG_SECTOR_READ_REQUESTS, volta_mio_l1tag_sector_read_requests_enc_str_1, volta_mio_l1tag_sector_read_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_sector_read_requests_enc_str_1 },
    { VOLTA_MIO_L1TAG_SECTOR_WRITE_REQUESTS, volta_mio_l1tag_sector_write_requests_enc_str_1, volta_mio_l1tag_sector_write_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_sector_write_requests_enc_str_1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_CONCAT_GATOM, volta_mio_l1miss_tex2gnic_fold_concat_gatom_enc_str_1, volta_mio_l1miss_tex2gnic_fold_concat_gatom_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1miss_tex2gnic_fold_concat_gatom_enc_str_1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_CONCAT_GRED, volta_mio_l1miss_tex2gnic_fold_concat_gred_enc_str_1, volta_mio_l1miss_tex2gnic_fold_concat_gred_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1miss_tex2gnic_fold_concat_gred_enc_str_1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_CONCAT_WR, volta_mio_l1miss_tex2gnic_fold_concat_wr_enc_str_1, volta_mio_l1miss_tex2gnic_fold_concat_wr_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1miss_tex2gnic_fold_concat_wr_enc_str_1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_GATOM, volta_mio_l1miss_tex2gnic_fold_gatom_enc_str_1, volta_mio_l1miss_tex2gnic_fold_gatom_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1miss_tex2gnic_fold_gatom_enc_str_1 },
    { VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_GRED, volta_mio_l1miss_tex2gnic_fold_gred_enc_str_1, volta_mio_l1miss_tex2gnic_fold_gred_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1miss_tex2gnic_fold_gred_enc_str_1 },
    { VOLTA_MIO_L2_SECTOR_RESPONSES_RECEIVED, volta_mio_l2_sector_responses_received_enc_str_1, volta_mio_l2_sector_responses_received_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l2_sector_responses_received_enc_str_1 },

    { VOLTA_MIO_LG_HIT, volta_mio_lg_hit_enc_str_1, volta_mio_lg_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_lg_hit_enc_str_1 },
    { VOLTA_MIO_SURFACE_HIT, volta_mio_surface_hit_enc_str_1, volta_mio_surface_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_hit_enc_str_1 },
    { VOLTA_MIO_TEXTURE_HIT, volta_mio_texture_hit_enc_str_1, volta_mio_texture_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_texture_hit_enc_str_1 },
    { VOLTA_MIO_GLOBAL_LD_HIT, volta_mio_global_ld_hit_enc_str_1, volta_mio_global_ld_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_global_ld_hit_enc_str_1 },
    { VOLTA_MIO_GLOBAL_ST_HIT, volta_mio_global_st_hit_enc_str_1, volta_mio_global_st_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_global_st_hit_enc_str_1 },
    { VOLTA_MIO_GLOBAL_RED_HIT, volta_mio_global_red_hit_enc_str_1, volta_mio_global_red_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_global_red_hit_enc_str_1 },
    { VOLTA_MIO_LG_MISS, volta_mio_lg_miss_enc_str_1, volta_mio_lg_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_lg_miss_enc_str_1 },
    { VOLTA_MIO_SURFACE_MISS, volta_mio_surface_miss_enc_str_1, volta_mio_surface_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_miss_enc_str_1 },
    { VOLTA_MIO_TEXTURE_MISS, volta_mio_texture_miss_enc_str_1, volta_mio_texture_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_texture_miss_enc_str_1 },
    { VOLTA_MIO_GLOBAL_LD_MISS, volta_mio_global_ld_miss_enc_str_1, volta_mio_global_ld_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_global_ld_miss_enc_str_1 },
    { VOLTA_MIO_GLOBAL_ST_MISS, volta_mio_global_st_miss_enc_str_1, volta_mio_global_st_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_global_st_miss_enc_str_1 },
    { VOLTA_MIO_GLOBAL_RED_MISS, volta_mio_global_red_miss_enc_str_1, volta_mio_global_red_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_global_red_miss_enc_str_1 },
    { VOLTA_MIO_ATOM_HIT, volta_mio_atom_hit_enc_str_1, volta_mio_atom_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_atom_hit_enc_str_1 },
    { VOLTA_MIO_LOCAL_LD_HIT, volta_mio_local_ld_hit_enc_str_1, volta_mio_local_ld_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_local_ld_hit_enc_str_1 },
    { VOLTA_MIO_LOCAL_ST_HIT, volta_mio_local_st_hit_enc_str_1, volta_mio_local_st_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_local_st_hit_enc_str_1 },
    { VOLTA_MIO_TEXTURE_LD_HIT, volta_mio_texture_ld_hit_enc_str_1, volta_mio_texture_ld_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_texture_ld_hit_enc_str_1 },
    { VOLTA_MIO_TEXTURE_TEX_HIT, volta_mio_texture_tex_hit_enc_str_1, volta_mio_texture_tex_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_texture_tex_hit_enc_str_1 },
    { VOLTA_MIO_ATOM_MISS, volta_mio_atom_miss_enc_str_1, volta_mio_atom_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_atom_miss_enc_str_1 },
    { VOLTA_MIO_LOCAL_LD_MISS, volta_mio_local_ld_miss_enc_str_1, volta_mio_local_ld_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_local_ld_miss_enc_str_1 },
    { VOLTA_MIO_LOCAL_ST_MISS, volta_mio_local_st_miss_enc_str_1, volta_mio_local_st_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_local_st_miss_enc_str_1 },
    { VOLTA_MIO_TEXTURE_LD_MISS, volta_mio_texture_ld_miss_enc_str_1, volta_mio_texture_ld_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_texture_ld_miss_enc_str_1 },
    { VOLTA_MIO_TEXTURE_TEX_MISS, volta_mio_texture_tex_miss_enc_str_1, volta_mio_texture_tex_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_texture_tex_miss_enc_str_1 },
    { VOLTA_MIO_SURFACE_LD_HIT, volta_mio_surface_ld_hit_enc_str_1, volta_mio_surface_ld_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_ld_hit_enc_str_1 },
    { VOLTA_MIO_SURFACE_ST_HIT, volta_mio_surface_st_hit_enc_str_1, volta_mio_surface_st_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_st_hit_enc_str_1 },
    { VOLTA_MIO_SURFACE_ATOM_HIT, volta_mio_surface_atom_hit_enc_str_1, volta_mio_surface_atom_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_atom_hit_enc_str_1 },
    { VOLTA_MIO_SURFACE_RED_HIT, volta_mio_surface_red_hit_enc_str_1, volta_mio_surface_red_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_red_hit_enc_str_1 },
    { VOLTA_MIO_SURFACE_LD_MISS, volta_mio_surface_ld_miss_enc_str_1, volta_mio_surface_ld_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_ld_miss_enc_str_1 },
    { VOLTA_MIO_SURFACE_ST_MISS, volta_mio_surface_st_miss_enc_str_1, volta_mio_surface_st_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_st_miss_enc_str_1 },
    { VOLTA_MIO_SURFACE_ATOM_MISS, volta_mio_surface_atom_miss_enc_str_1, volta_mio_surface_atom_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_atom_miss_enc_str_1 },
    { VOLTA_MIO_SURFACE_RED_MISS, volta_mio_surface_red_miss_enc_str_1, volta_mio_surface_red_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_surface_red_miss_enc_str_1 },
    { VOLTA_MIO_TYPE_1D_HIT, volta_mio_type_1d_hit_enc_str_1, volta_mio_type_1d_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_type_1d_hit_enc_str_1 },
    { VOLTA_MIO_TYPE_1D_BUFFER_HIT, volta_mio_type_1d_buffer_hit_enc_str_1, volta_mio_type_1d_buffer_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_type_1d_buffer_hit_enc_str_1 },
    { VOLTA_MIO_TYPE_2D_HIT, volta_mio_type_2d_hit_enc_str_1, volta_mio_type_2d_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_type_2d_hit_enc_str_1 },
    { VOLTA_MIO_TYPE_3D_HIT, volta_mio_type_3d_hit_enc_str_1, volta_mio_type_3d_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_type_3d_hit_enc_str_1 },
    { VOLTA_MIO_TYPE_CUBEMAP_HIT, volta_mio_type_cubemap_hit_enc_str_1, volta_mio_type_cubemap_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_type_cubemap_hit_enc_str_1 },
    { VOLTA_MIO_TYPE_NO_MIPMAP_HIT, volta_mio_type_no_mipmap_hit_enc_str_1, volta_mio_type_no_mipmap_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_type_no_mipmap_hit_enc_str_1 },
    { VOLTA_MIO_TYPE_1D_MISS, volta_mio_type_1d_miss_enc_str_1, volta_mio_type_1d_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_type_1d_miss_enc_str_1 },
    { VOLTA_MIO_TYPE_1D_BUFFER_MISS, volta_mio_type_1d_buffer_miss_enc_str_1, volta_mio_type_1d_buffer_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_type_1d_buffer_miss_enc_str_1 },
    { VOLTA_MIO_TYPE_2D_MISS, volta_mio_type_2d_miss_enc_str_1, volta_mio_type_2d_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_type_2d_miss_enc_str_1 },
    { VOLTA_MIO_TYPE_3D_MISS, volta_mio_type_3d_miss_enc_str_1, volta_mio_type_3d_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_type_3d_miss_enc_str_1 },
    { VOLTA_MIO_TYPE_CUBEMAP_MISS, volta_mio_type_cubemap_miss_enc_str_1, volta_mio_type_cubemap_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_type_cubemap_miss_enc_str_1 },
    { VOLTA_MIO_TYPE_NO_MIPMAP_MISS, volta_mio_type_no_mipmap_miss_enc_str_1, volta_mio_type_no_mipmap_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_type_no_mipmap_miss_enc_str_1 },
    { VOLTA_MIO_PREFETCH_REQUESTS_POSTCOALESCING, volta_mio_prefetch_requests_postcoalescing_enc_str_1, volta_mio_prefetch_requests_postcoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_prefetch_requests_postcoalescing_enc_str_1 },
    { VOLTA_MIO_PREFETCH_SECTORS_POSTCOALESCING, volta_mio_prefetch_sectors_postcoalescing_enc_str_1, volta_mio_prefetch_sectors_postcoalescing_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_prefetch_sectors_postcoalescing_enc_str_1 },
    { VOLTA_MIO_L1TAG_LG, volta_mio_l1tag_lg_enc_str_1, volta_mio_l1tag_lg_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_lg_enc_str_1 },
    { VOLTA_MIO_L1TAG_GLOBAL_LD, volta_mio_l1tag_global_ld_enc_str_1, volta_mio_l1tag_global_ld_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_global_ld_enc_str_1 },
    { VOLTA_MIO_L1TAG_GLOBAL_ST, volta_mio_l1tag_global_st_enc_str_1, volta_mio_l1tag_global_st_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_global_st_enc_str_1 },
    { VOLTA_MIO_L1TAG_GLOBAL_RED, volta_mio_l1tag_global_red_enc_str_1, volta_mio_l1tag_global_red_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_global_red_enc_str_1 },
    { VOLTA_MIO_L1TAG_ATOM, volta_mio_l1tag_atom_enc_str_1, volta_mio_l1tag_atom_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_atom_enc_str_1 },
    { VOLTA_MIO_L1TAG_LOCAL_LD, volta_mio_l1tag_local_ld_enc_str_1, volta_mio_l1tag_local_ld_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_local_ld_enc_str_1 },
    { VOLTA_MIO_L1TAG_LOCAL_ST, volta_mio_l1tag_local_st_enc_str_1, volta_mio_l1tag_local_st_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_local_st_enc_str_1 },
    { VOLTA_MIO_L1TAG_TEXTURE, volta_mio_l1tag_texture_enc_str_1, volta_mio_l1tag_texture_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_texture_enc_str_1 },
    { VOLTA_MIO_L1TAG_TEXTURE_LD, volta_mio_l1tag_texture_ld_enc_str_1, volta_mio_l1tag_texture_ld_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_texture_ld_enc_str_1 },
    { VOLTA_MIO_L1TAG_TEXTURE_TEX, volta_mio_l1tag_texture_tex_enc_str_1, volta_mio_l1tag_texture_tex_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_texture_tex_enc_str_1 },
    { VOLTA_MIO_L1TAG_TAG_TYPE_1D, volta_mio_l1tag_tag_type_1d_enc_str_1, volta_mio_l1tag_tag_type_1d_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_tag_type_1d_enc_str_1 },
    { VOLTA_MIO_L1TAG_TAG_TYPE_1D_BUFFER, volta_mio_l1tag_tag_type_1d_buffer_enc_str_1, volta_mio_l1tag_tag_type_1d_buffer_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_tag_type_1d_buffer_enc_str_1 },
    { VOLTA_MIO_L1TAG_TAG_TYPE_2D, volta_mio_l1tag_tag_type_2d_enc_str_1, volta_mio_l1tag_tag_type_2d_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_tag_type_2d_enc_str_1 },
    { VOLTA_MIO_L1TAG_TAG_TYPE_3D, volta_mio_l1tag_tag_type_3d_enc_str_1, volta_mio_l1tag_tag_type_3d_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_tag_type_3d_enc_str_1 },
    { VOLTA_MIO_L1TAG_TAG_TYPE_CUBEMAP, volta_mio_l1tag_tag_type_cubemap_enc_str_1, volta_mio_l1tag_tag_type_cubemap_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_tag_type_cubemap_enc_str_1 },
    { VOLTA_MIO_L1TAG_TAG_TYPE_NO_MIPMAP, volta_mio_l1tag_tag_type_no_mipmap_enc_str_1, volta_mio_l1tag_tag_type_no_mipmap_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_tag_type_no_mipmap_enc_str_1 },
    { VOLTA_MIO_L1TAG_SURFACE, volta_mio_l1tag_surface_enc_str_1, volta_mio_l1tag_surface_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_surface_enc_str_1 },
    { VOLTA_MIO_L1TAG_SURFACE_LD, volta_mio_l1tag_surface_ld_enc_str_1, volta_mio_l1tag_surface_ld_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_surface_ld_enc_str_1 },
    { VOLTA_MIO_L1TAG_SURFACE_ST, volta_mio_l1tag_surface_st_enc_str_1, volta_mio_l1tag_surface_st_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_surface_st_enc_str_1 },
    { VOLTA_MIO_L1TAG_SURFACE_ATOM, volta_mio_l1tag_surface_atom_enc_str_1, volta_mio_l1tag_surface_atom_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_surface_atom_enc_str_1 },
    { VOLTA_MIO_L1TAG_SURFACE_RED, volta_mio_l1tag_surface_red_enc_str_1, volta_mio_l1tag_surface_red_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_surface_red_enc_str_1 },
    { VOLTA_MIO_L1TAG_SECTOR_TAG_HIT_DATA_HIT_GRP_2D, volta_mio_l1tag_sector_tag_hit_data_hit_grp_2d_enc_str_1, volta_mio_l1tag_sector_tag_hit_data_hit_grp_2d_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_sector_tag_hit_data_hit_grp_2d_enc_str_1 },
    { VOLTA_MIO_L1TAG_SECTOR_MISS_GRP_2D, volta_mio_l1tag_sector_miss_grp_2d_enc_str_1, volta_mio_l1tag_sector_miss_grp_2d_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_mio_l1tag_sector_miss_grp_2d_enc_str_1 },
    { VOLTA_HWPM_EXPT_2X2B6I_S0, volta_hwpm_expt_2x2b6i_s0_enc_str_1, volta_hwpm_expt_2x2b6i_s0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_expt_2x2b6i_s0_enc_str_1 },
    { VOLTA_HWPM_EXPT_2X2B6I_S1, volta_hwpm_expt_2x2b6i_s1_enc_str_1, volta_hwpm_expt_2x2b6i_s1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_expt_2x2b6i_s1_enc_str_1 },
    { VOLTA_HWPM_EXPT_2X2B6I_S2, volta_hwpm_expt_2x2b6i_s2_enc_str_1, volta_hwpm_expt_2x2b6i_s2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_expt_2x2b6i_s2_enc_str_1 },
    { VOLTA_HWPM_EXPT_2X2B6I_S3, volta_hwpm_expt_2x2b6i_s3_enc_str_1, volta_hwpm_expt_2x2b6i_s3_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_expt_2x2b6i_s3_enc_str_1 },
    { VOLTA_TEX_GLOBAL_LD_SET_CONFLICTS, volta_tex_global_ld_set_conflicts_enc_str_1, volta_tex_global_ld_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_global_ld_set_conflicts_enc_str_1 },
    { VOLTA_TEX_GLOBAL_ST_SET_CONFLICTS, volta_tex_global_st_set_conflicts_enc_str_1, volta_tex_global_st_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_global_st_set_conflicts_enc_str_1 },
    { VOLTA_TEX_LOCAL_LD_SET_CONFLICTS, volta_tex_local_ld_set_conflicts_enc_str_1, volta_tex_local_ld_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_local_ld_set_conflicts_enc_str_1 },
    { VOLTA_TEX_LOCAL_ST_SET_CONFLICTS, volta_tex_local_st_set_conflicts_enc_str_1, volta_tex_local_st_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_local_st_set_conflicts_enc_str_1 },
    { VOLTA_TEX_TEXTURE_LD_SET_CONFLICTS, volta_tex_texture_ld_set_conflicts_enc_str_1, volta_tex_texture_ld_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_texture_ld_set_conflicts_enc_str_1 },
    { VOLTA_TEX_TEXTURE_TEX_SET_CONFLICTS, volta_tex_texture_tex_set_conflicts_enc_str_1, volta_tex_texture_tex_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_texture_tex_set_conflicts_enc_str_1 },

    { VOLTA_TEX_GLOBAL_LD_SET_ACCESS, volta_tex_global_ld_set_access_enc_str_1, volta_tex_global_ld_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_global_ld_set_access_enc_str_1 },
    { VOLTA_TEX_GLOBAL_ST_SET_ACCESS, volta_tex_global_st_set_access_enc_str_1, volta_tex_global_st_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_global_st_set_access_enc_str_1 },
    { VOLTA_TEX_LOCAL_LD_SET_ACCESS, volta_tex_local_ld_set_access_enc_str_1, volta_tex_local_ld_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_local_ld_set_access_enc_str_1 },
    { VOLTA_TEX_LOCAL_ST_SET_ACCESS, volta_tex_local_st_set_access_enc_str_1, volta_tex_local_st_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_local_st_set_access_enc_str_1 },
    { VOLTA_TEX_TEXTURE_LD_SET_ACCESS, volta_tex_texture_ld_set_access_enc_str_1, volta_tex_texture_ld_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_texture_ld_set_access_enc_str_1 },
    { VOLTA_TEX_TEXTURE_TEX_SET_ACCESS, volta_tex_texture_tex_set_access_enc_str_1, volta_tex_texture_tex_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_texture_tex_set_access_enc_str_1 },

    { VOLTA_TEX_GLOBAL_RED_SET_CONFLICTS, volta_tex_global_red_set_conflicts_enc_str_1, volta_tex_global_red_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_global_red_set_conflicts_enc_str_1 },
    { VOLTA_TEX_ATOM_SET_CONFLICTS, volta_tex_atom_set_conflicts_enc_str_1, volta_tex_atom_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_atom_set_conflicts_enc_str_1 },
    { VOLTA_TEX_SURFACE_LD_SET_CONFLICTS, volta_tex_surface_ld_set_conflicts_enc_str_1, volta_tex_surface_ld_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_surface_ld_set_conflicts_enc_str_1 },
    { VOLTA_TEX_SURFACE_ST_SET_CONFLICTS, volta_tex_surface_st_set_conflicts_enc_str_1, volta_tex_surface_st_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_surface_st_set_conflicts_enc_str_1 },
    { VOLTA_TEX_SURFACE_ATOM_SET_CONFLICTS, volta_tex_surface_atom_set_conflicts_enc_str_1, volta_tex_surface_atom_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_surface_atom_set_conflicts_enc_str_1 },
    { VOLTA_TEX_SURFACE_RED_SET_CONFLICTS, volta_tex_surface_red_set_conflicts_enc_str_1, volta_tex_surface_red_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_surface_red_set_conflicts_enc_str_1 },
    { VOLTA_TEX_LG_SET_CONFLICTS, volta_tex_lg_set_conflicts_enc_str_1, volta_tex_lg_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_lg_set_conflicts_enc_str_1 },
    { VOLTA_TEX_SURFACE_SET_CONFLICTS, volta_tex_surface_set_conflicts_enc_str_1, volta_tex_surface_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_surface_set_conflicts_enc_str_1 },
    { VOLTA_TEX_TEXTURE_SET_CONFLICTS, volta_tex_texture_set_conflicts_enc_str_1, volta_tex_texture_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_texture_set_conflicts_enc_str_1 },

    { VOLTA_TEX_GLOBAL_RED_SET_ACCESS, volta_tex_global_red_set_access_enc_str_1, volta_tex_global_red_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_global_red_set_access_enc_str_1 },
    { VOLTA_TEX_ATOM_SET_ACCESS, volta_tex_atom_set_access_enc_str_1, volta_tex_atom_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_atom_set_access_enc_str_1 },
    { VOLTA_TEX_SURFACE_LD_SET_ACCESS, volta_tex_surface_ld_set_access_enc_str_1, volta_tex_surface_ld_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_surface_ld_set_access_enc_str_1 },
    { VOLTA_TEX_SURFACE_ST_SET_ACCESS, volta_tex_surface_st_set_access_enc_str_1, volta_tex_surface_st_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_surface_st_set_access_enc_str_1 },
    { VOLTA_TEX_SURFACE_ATOM_SET_ACCESS, volta_tex_surface_atom_set_access_enc_str_1, volta_tex_surface_atom_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_surface_atom_set_access_enc_str_1 },
    { VOLTA_TEX_SURFACE_RED_SET_ACCESS, volta_tex_surface_red_set_access_enc_str_1, volta_tex_surface_red_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_surface_red_set_access_enc_str_1 },
    { VOLTA_TEX_LG_SET_ACCESS, volta_tex_lg_set_access_enc_str_1, volta_tex_lg_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_lg_set_access_enc_str_1 },
    { VOLTA_TEX_SURFACE_SET_ACCESS, volta_tex_surface_set_access_enc_str_1, volta_tex_surface_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_surface_set_access_enc_str_1 },
    { VOLTA_TEX_TEXTURE_SET_ACCESS, volta_tex_texture_set_access_enc_str_1, volta_tex_texture_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_texture_set_access_enc_str_1 },
    { VOLTA_PCIE_TX_ACTIVE, volta_pcie_tx_active_enc_str_1, volta_pcie_tx_active_enc_str_2, CUPROF_EVENT_CATEGORY_MEMORY, volta_pcie_tx_active_enc_str_3 },
    { VOLTA_PCIE_TX_IDLE,   volta_pcie_tx_idle_enc_str_1,   volta_pcie_tx_idle_enc_str_1,   CUPROF_EVENT_CATEGORY_MEMORY, volta_pcie_tx_idle_enc_str_1 },
    { VOLTA_PCIE_RX_ACTIVE, volta_pcie_rx_active_enc_str_1, volta_pcie_rx_active_enc_str_2, CUPROF_EVENT_CATEGORY_MEMORY, volta_pcie_rx_active_enc_str_3 },
    { VOLTA_PCIE_RX_IDLE,   volta_pcie_rx_idle_enc_str_1,   volta_pcie_rx_idle_enc_str_1,   CUPROF_EVENT_CATEGORY_MEMORY, volta_pcie_rx_idle_enc_str_1 },

    { VOLTA_HWPMMUX_INST_EXECUTED_HMMA_FP16_OPS, volta_inst_executed_hmma_fp16_ops_enc_str_1, volta_inst_executed_hmma_fp16_ops_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_inst_executed_hmma_fp16_ops_enc_str_1 },
    { VOLTA_HWPMMUX_INST_EXECUTED_HMMA_FP32_OPS, volta_inst_executed_hmma_fp32_ops_enc_str_1, volta_inst_executed_hmma_fp32_ops_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_inst_executed_hmma_fp32_ops_enc_str_1 },
    { VOLTA_HWPMMUX_INST_EXECUTED_HMMA_OPS, volta_inst_executed_hmma_ops_enc_str_1, volta_inst_executed_hmma_ops_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_inst_executed_hmma_ops_enc_str_1 },
    { VOLTA_TEX_TEX_REQ_ACTIVE, volta_tex_tex_req_active_enc_str_1, volta_tex_tex_req_active_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, volta_tex_tex_req_active_enc_str_2 },

    {VOLTA_HWPM_INST_EXECUTED_FFMA_OPS_S0, volta_hwpm_inst_executed_ffma_ops_s0_enc_str_1, volta_hwpm_inst_executed_ffma_ops_s0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_ffma_ops_s0_enc_str_1},
    {VOLTA_HWPM_INST_EXECUTED_FFMA_OPS_S1, volta_hwpm_inst_executed_ffma_ops_s1_enc_str_1, volta_hwpm_inst_executed_ffma_ops_s1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_ffma_ops_s1_enc_str_1},
    {VOLTA_HWPM_INST_EXECUTED_FFMA_OPS_S2, volta_hwpm_inst_executed_ffma_ops_s2_enc_str_1, volta_hwpm_inst_executed_ffma_ops_s2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_ffma_ops_s2_enc_str_1},
    {VOLTA_HWPM_INST_EXECUTED_FFMA_OPS_S3, volta_hwpm_inst_executed_ffma_ops_s3_enc_str_1, volta_hwpm_inst_executed_ffma_ops_s3_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_ffma_ops_s3_enc_str_1},
    {VOLTA_HWPM_INST_EXECUTED_OTHERFP_OPS_S0, volta_hwpm_inst_executed_otherfp_ops_s0_enc_str_1, volta_hwpm_inst_executed_otherfp_ops_s0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_otherfp_ops_s0_enc_str_1},
    {VOLTA_HWPM_INST_EXECUTED_OTHERFP_OPS_S1, volta_hwpm_inst_executed_otherfp_ops_s1_enc_str_1, volta_hwpm_inst_executed_otherfp_ops_s1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_otherfp_ops_s1_enc_str_1},
    {VOLTA_HWPM_INST_EXECUTED_OTHERFP_OPS_S2, volta_hwpm_inst_executed_otherfp_ops_s2_enc_str_1, volta_hwpm_inst_executed_otherfp_ops_s2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_otherfp_ops_s2_enc_str_1},
    {VOLTA_HWPM_INST_EXECUTED_OTHERFP_OPS_S3, volta_hwpm_inst_executed_otherfp_ops_s3_enc_str_1, volta_hwpm_inst_executed_otherfp_ops_s3_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_otherfp_ops_s3_enc_str_1},
    {VOLTA_HWPM_INST_EXECUTED_FP32_OPS_S0, volta_hwpm_inst_executed_fp32_ops_s0_enc_str_1, volta_hwpm_inst_executed_fp32_ops_s0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_fp32_ops_s0_enc_str_1},
    {VOLTA_HWPM_INST_EXECUTED_FP32_OPS_S1, volta_hwpm_inst_executed_fp32_ops_s1_enc_str_1, volta_hwpm_inst_executed_fp32_ops_s1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_fp32_ops_s1_enc_str_1},
    {VOLTA_HWPM_INST_EXECUTED_FP32_OPS_S2, volta_hwpm_inst_executed_fp32_ops_s2_enc_str_1, volta_hwpm_inst_executed_fp32_ops_s2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_fp32_ops_s2_enc_str_1},
    {VOLTA_HWPM_INST_EXECUTED_FP32_OPS_S3, volta_hwpm_inst_executed_fp32_ops_s3_enc_str_1, volta_hwpm_inst_executed_fp32_ops_s3_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_hwpm_inst_executed_fp32_ops_s3_enc_str_1},

    {VOLTA_FE_SYS_GR_IDLE, volta_fe_sys_gr_idle_enc_str_1, volta_fe_sys_gr_idle_enc_str_1, CUPROF_EVENT_CATEGORY_SYS, volta_fe_sys_gr_idle_enc_str_1},
    {VOLTA_FE_SYS_GR_BUSY, volta_fe_sys_gr_busy_enc_str_1, volta_fe_sys_gr_busy_enc_str_1, CUPROF_EVENT_CATEGORY_SYS, volta_fe_sys_gr_busy_enc_str_4},
    {VOLTA_ELAPSED_CYCLES_SYS0, volta_elapsed_cycles_sys0_enc_str_1, volta_elapsed_cycles_sys0_enc_str_1, CUPROF_EVENT_CATEGORY_SYS, volta_elapsed_cycles_sys0_enc_str_4},
    {VOLTA_SKED_STATUS_BIT0_SYS1, volta_sked_status_bit0_sys1_enc_str_1, volta_sked_status_bit0_sys1_enc_str_1, CUPROF_EVENT_CATEGORY_SYS, volta_sked_status_bit0_sys1_enc_str_1},
    {VOLTA_SKED_STATUS_BIT1_SYS1, volta_sked_status_bit1_sys1_enc_str_1, volta_sked_status_bit1_sys1_enc_str_1, CUPROF_EVENT_CATEGORY_SYS, volta_sked_status_bit1_sys1_enc_str_1},
    {VOLTA_SKED_STATUS_BIT2_SYS1, volta_sked_status_bit2_sys1_enc_str_1, volta_sked_status_bit2_sys1_enc_str_1, CUPROF_EVENT_CATEGORY_SYS, volta_sked_status_bit2_sys1_enc_str_1},
    {VOLTA_SKED_IDLE_SYS1, volta_sked_idle_sys1_enc_str_1, volta_sked_idle_sys1_enc_str_1, CUPROF_EVENT_CATEGORY_SYS, volta_sked_idle_sys1_enc_str_1},
    {VOLTA_SKED_BUSY_SYS1, volta_sked_busy_sys1_enc_str_1, volta_sked_busy_sys1_enc_str_1, CUPROF_EVENT_CATEGORY_SYS, volta_sked_busy_sys1_enc_str_1},
    {VOLTA_ELAPSED_CYCLES_SYS1, volta_elapsed_cycles_sys1_enc_str_1, volta_elapsed_cycles_sys1_enc_str_1, CUPROF_EVENT_CATEGORY_SYS, volta_elapsed_cycles_sys1_enc_str_1},
#if NVCFG(GLOBAL_CHIP_T194) || NVCFG(GLOBAL_GPU_IMPL_GV11B)
    { VOLTA_SM_INST_EXECUTED_IMMA_OPS, volta_sm_inst_executed_imma_ops_enc_str_1, volta_sm_inst_executed_imma_ops_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_imma_ops_enc_str_2 },
    { VOLTA_SM_INST_EXECUTED_IMMA_I8_I8_OPS, volta_sm_inst_executed_imma_i8_i8_ops_enc_str_1, volta_sm_inst_executed_imma_i8_i8_ops_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_imma_i8_i8_ops_enc_str_2 },
    { VOLTA_SM_INST_EXECUTED_IMMA_I16_I8_OPS, volta_sm_inst_executed_imma_i16_i8_ops_enc_str_1, volta_sm_inst_executed_imma_i16_i8_ops_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_imma_i16_i8_ops_enc_str_2 },
    { VOLTA_SM_INST_EXECUTED_INTULTRA_PIPE, volta_sm_inst_executed_intultra_pipe_enc_str_1, volta_sm_inst_executed_intultra_pipe_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, volta_sm_inst_executed_intultra_pipe_enc_str_2 },
    { VOLTA_HSHUB_IG_ARB0_VLD_XBAR0, volta_hshub_ig_arb0_vld_xbar0_enc_str_1, volta_hshub_ig_arb0_vld_xbar0_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_hshub_ig_arb0_vld_xbar0_enc_str_1 },
    { VOLTA_HSHUB_IG_ARB0_VLD_XBAR1, volta_hshub_ig_arb0_vld_xbar1_enc_str_1, volta_hshub_ig_arb0_vld_xbar1_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_hshub_ig_arb0_vld_xbar1_enc_str_1 },
    { VOLTA_HSHUB_IG_ARB0_VLD_XBAR2, volta_hshub_ig_arb0_vld_xbar2_enc_str_1, volta_hshub_ig_arb0_vld_xbar2_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_hshub_ig_arb0_vld_xbar2_enc_str_1 },
    { VOLTA_HSHUB_IG_ARB0_VLD_XBAR3, volta_hshub_ig_arb0_vld_xbar3_enc_str_1, volta_hshub_ig_arb0_vld_xbar3_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_hshub_ig_arb0_vld_xbar3_enc_str_1 },
    { VOLTA_HSHUB_EG_ARB0_VLD_XBAR0, volta_hshub_eg_arb0_vld_xbar0_enc_str_1, volta_hshub_eg_arb0_vld_xbar0_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_hshub_eg_arb0_vld_xbar0_enc_str_1 },
    { VOLTA_HSHUB_EG_ARB0_VLD_XBAR1, volta_hshub_eg_arb0_vld_xbar1_enc_str_1, volta_hshub_eg_arb0_vld_xbar1_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_hshub_eg_arb0_vld_xbar1_enc_str_1 },
    { VOLTA_HSHUB_EG_ARB0_VLD_XBAR2, volta_hshub_eg_arb0_vld_xbar2_enc_str_1, volta_hshub_eg_arb0_vld_xbar2_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_hshub_eg_arb0_vld_xbar2_enc_str_1 },
    { VOLTA_HSHUB_EG_ARB0_VLD_XBAR3, volta_hshub_eg_arb0_vld_xbar3_enc_str_1, volta_hshub_eg_arb0_vld_xbar3_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, volta_hshub_eg_arb0_vld_xbar3_enc_str_1 },
    { VOLTA_HSHUB_IG_NVLTL2HSH0_INPUT_PKT_RDAT, volta_hshub_ig_nvltl2hsh0_input_pkt_rdat_enc_str_1, volta_hshub_ig_nvltl2hsh0_input_pkt_rdat_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_hshub_ig_nvltl2hsh0_input_pkt_rdat_enc_str_1 },
    { VOLTA_HSHUB_IG_NVLTL2HSH1_INPUT_PKT_RDAT, volta_hshub_ig_nvltl2hsh1_input_pkt_rdat_enc_str_1, volta_hshub_ig_nvltl2hsh1_input_pkt_rdat_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_hshub_ig_nvltl2hsh1_input_pkt_rdat_enc_str_1 },
    { VOLTA_HSHUB_IG_NVLTL2HSH2_INPUT_PKT_RDAT, volta_hshub_ig_nvltl2hsh2_input_pkt_rdat_enc_str_1, volta_hshub_ig_nvltl2hsh2_input_pkt_rdat_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_hshub_ig_nvltl2hsh2_input_pkt_rdat_enc_str_1 },
    { VOLTA_HSHUB_IG_NVLTL2HSH3_INPUT_PKT_RDAT, volta_hshub_ig_nvltl2hsh3_input_pkt_rdat_enc_str_1, volta_hshub_ig_nvltl2hsh3_input_pkt_rdat_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_hshub_ig_nvltl2hsh3_input_pkt_rdat_enc_str_1 },
    { VOLTA_HSHUB_IG_NVLTL2HSH0_INPUT_PKT_WDAT, volta_hshub_ig_nvltl2hsh0_input_pkt_wdat_enc_str_1, volta_hshub_ig_nvltl2hsh0_input_pkt_wdat_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_hshub_ig_nvltl2hsh0_input_pkt_wdat_enc_str_1 },
    { VOLTA_HSHUB_IG_NVLTL2HSH1_INPUT_PKT_WDAT, volta_hshub_ig_nvltl2hsh1_input_pkt_wdat_enc_str_1, volta_hshub_ig_nvltl2hsh1_input_pkt_wdat_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_hshub_ig_nvltl2hsh1_input_pkt_wdat_enc_str_1 },
    { VOLTA_HSHUB_IG_NVLTL2HSH2_INPUT_PKT_WDAT, volta_hshub_ig_nvltl2hsh2_input_pkt_wdat_enc_str_1, volta_hshub_ig_nvltl2hsh2_input_pkt_wdat_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_hshub_ig_nvltl2hsh2_input_pkt_wdat_enc_str_1 },
    { VOLTA_HSHUB_IG_NVLTL2HSH3_INPUT_PKT_WDAT, volta_hshub_ig_nvltl2hsh3_input_pkt_wdat_enc_str_1, volta_hshub_ig_nvltl2hsh3_input_pkt_wdat_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, volta_hshub_ig_nvltl2hsh3_input_pkt_wdat_enc_str_1 },
#endif
    {INVALID_PM_SIGNAL_NEW, ""}
};

#if NVCFG(GLOBAL_ARCH_VOLTA)
CUdomainInfo domainInfoGV100   = { 18, domainTableGV100, pVoltaSignalDescriptionArray};
#else
CUdomainInfo domainInfoGV100   = { 0,    NULL, pVoltaSignalDescriptionArray};
#endif /*#if NVCFG(GLOBAL_ARCH_VOLTA) */

#if NVCFG(GLOBAL_CHIP_T194) || NVCFG(GLOBAL_GPU_IMPL_GV11B)
CUdomainInfo domainInfoGV11B = { 13, domainTableGV11B, pVoltaSignalDescriptionArray };
#else
CUdomainInfo domainInfoGV11B = { 0, NULL, pVoltaSignalDescriptionArray };
#endif
