/*
* Copyright 1993-2016 by NVIDIA Corporation.  All rights reserved.  All
* information contained herein is proprietary and confidential to NVIDIA
* Corporation.  Any use, reproduction, or disclosure without the written
* permission of NVIDIA Corporation is prohibited.
*/

/******************************************************************************
*
*   Module: volta_perfmon_new.c
*
*   Description:
*       Performance monitor support in compute driver architecture.
*
******************************************************************************/

#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#include "volta_perfmon_new.h"
#include "volta_signals.h"
#include "cuda_internal.h"
#include "cuda_device.h"
#include "cuda_macros.h"
#include "cuos.h"
#include "volta/gv100/dev_perf.h"
#include "volta/gv100/dev_fb.h"
#include "cui/hal/volta/volta.h"
#include "perfmon_common.h"
#include "perfmon_new.h"
#include "tools_shared.h"
#include "tools_shared_hashmap.h"
#include "tools_shared_list.h"
#include "stream_push.h"
#include "volta/gv100/dev_ctxsw_prog.h"
#include "halo_helper.h"

#if cuiPlatformIncludesMrm()
#include "mrm_channel.h"
#include "mrm_device.h"
#endif

#define FALSE_WATCH_BUS_SIGNAL 0xef
#define VOLTA_MAX_SW_COUNTER_PER_EVENTGROUP 4

//TBD collect all scattered register settings for each domain and put in one function
//TBD Set register common function need to be different and should be thread safe
//TBD check all the parameters, pointers etc for validity.

#define VOLTA_NVLINK_MAX_LINKS 6
// Adding support to configure individual links.
#define ENABLE_UNICAST_NVLINK 0
#define PACKET_SIZE 8
#define VOLTA_RECORD_SIZE 32
#ifdef DEBUG
#define ENABLE_SAMPLING_PRINTS
#endif

#define VOLTA_FBPA_PER_FBP 2
#define VOLTA_PERFMONS_PER_ROP_L2 2

#define GENERATE_BINARY_STREAMS 0

// compare function for event group
static NvBool egCompareData(const void *data1, const void *data2) {
    return ( (CUeventGroup*)data1 == (CUeventGroup*)data2 );
}

// compare function for event (signal) Ids
static NvBool eventIdCompareData(const void *data1, const void *data2) {
    return (((CUeventDataBasic*)((CUeventInfo*)data1)->pEventData)->signalId == *(NvU32*)data2 );
}
static int voltaPerfmonPCSamplingReadData(void *userData);
static int voltaPerfmonPCSamplingParseData(void *userData);
static NV_INLINE NvBool voltaIsSoftwareCounterDomain(CUeventDomainID domainId);
static NV_INLINE NvBool voltaIsDeviceLevelCounterDomain(CUeventDomainID domainId);
static CUprofResult voltaDestroyEventGroup(CUeventGroup *pEventGroup);
//TBD : Shift these functions up in the file to get rid of declaration
static CUresult SetupPMRegistersSMInternal(CUeventGroup *pEventGroup);
static CUresult resetPMSMInternal(CUeventGroup *pEventGroup);
static CUresult logPMCountersSMInternal(CUeventGroup *pEventGroup, NvU8 *highValuesQuad, NvU8 *highValuesCore);
static CUresult detectCounterOverflowSMInternal(const CUeventGroup *pEventGroup, NvBool* bIsOverflow, NvU8* overflowValuesQuad, NvU8* overflowValuesCore);
static CUresult setPMEnableRegSM(const CUeventGroup *pEventGroup, NvBool bEnable);
// Broadcast version of SetupPMRegistersSMInternal:
static CUresult SetupPMRegistersSM_bc(CUeventGroup *pEventGroup, NvU32 eventGroupQctl, NvU32 eventGroupCore, 
                                        NvU32* funcQctl, NvU32* funcCore, NvU32 enableQctl, NvU32 enableCore);
// Broadcast version of resetPMSMInternal:
static CUresult resetPMSM_bc(CUeventGroup *pEventGroup, NvU32 *funcQctl, NvU32 *funcCore);
// Unicast version of SetupPMRegistersSMInternal:
static CUresult SetupPMRegistersSM(CUeventGroup *pEventGroup, NvU32 eventGroupQctl, NvU32 eventGroupCore, 
                                    NvU32* funcQctl, NvU32* funcCore, NvU32 enableQctl, NvU32 enableCore);
// Unicast version of resetPMSMInternal:
static CUresult resetPMSM(CUeventGroup *pEventGroup, NvU32 *funcQctl, NvU32 *funcCore);
static CUprofResult PMReleaseModeB(const CUeventGroup *pEventGroup);
static NvU32 getCounterMultiplicationFactor(NvU64 arch, CUeventID eventId);
static NvBool getSplittingInfo(CUeventID eventId, NvU32 *splitWidth);
static CUprofResult voltaPerfmonAddSMCounterEntryForHWPMMux(CUeventGroup *pEventGroup, CUdomainData *pDomainData, CUeventInfo *pEventInfo, NvBool *bAdded, NvU32 *maxSignals);
static CUprofResult getSigConfig(CUeventGroup *pEventGroup, CUdomainData *pDomainData, PerfSignalHwpm *pEventData, signalConfig *tempSignalConfig);

//Pc Sampling
static CUprofResult voltaOnPacket(const uint8_t *pPacketRaw, CUctx *ctx);
static CUprofResult voltaOnRecord(uint8_t *pModeERecord, chiplet *chipInstanceData, CUctx *ctx, uint32_t *totalDroppedBytes);
static inline size_t   incrementRecordOffset(size_t recordOffset);
static inline uint16_t getPerfmonId(const uint8_t *pModeERecord);
static inline uint16_t getDroppedBytes(const uint8_t *pModeERecord);
static inline uint16_t getValidBytes(const uint8_t *pModeERecord);
static inline uint8_t  isStartData(const uint8_t *pModeERecord);
static inline uint64_t getPC(const uint8_t *pPacketRaw);
static inline uint32_t getCIR(const uint8_t *pPacketRaw);

#if 0
static CUresult enableNvLink() {
//Ideally we should read NV_IOCTRL_LINK_CLOCK_GATING and select the nvlink that has clock gating disabled
// or has fastest clocks(there is no reg to read clock freq, will be added in nvlink1)
//and then set that nvlink number in NV_IOCTRL_PERFMON_CLK_CONTROL1_SEL but  nvlink0 doesn't have power
//gating enabled.
//clk_control1 to select clock of 0th nvlink
NV_IOCTRL_PERFMON_CLK_CONTROL1, 0, NV_IOCTRL_PERFMON_CLK_CONTROL1_SEL;
//Enable clocks 
// I think NV_IOCTRL_LINK_CLOCK_CONTROL(i) need not be set, as the value is already 0 for disable.

//Set M1 mux using groups in signal table (total 9 muxes for each TL, DL and IOCTRL)
//select and set groups 
NV_IOCTRL_LINK_CLOCK_CONTRO//Set mode, use from signal table
//NV_IOCTRL_PMCTRL_REG
//NV_IOCTRL_PMCTRL_REG_MODE
0b    Send sample to IOCTRL every cycle
1b    Send a sample to IOCTRL only when the data changes
//NV_IOCTRL_PMCTRL_REG_ENABLE


//How to expose domains? It is possible that we would like to give separate values for each nvlink depending on the topology
//Select required DL or TL using following registers, depends on the countermodeaggregate flag.
//2 counters for TL or DL or 1 counter from TL and DL can be selected such that all nvlinks can be profiled simultaneously.
#define NV_IOCTRL_PERFMON_SELECT(i)                   (0x00a00160+(i)*4) /* RWE4A */
M2Sel3[2:0]        selects
 0000b                 DL0
 0001b                    TL0
 0010b                    DL1
 0011b                    TL1
 0100b                    DL2
 0101b                    TL2
 0110b                    DL3
 0111b                    TL3    
 1000b                    IOCTRL    

Select 
//NV_IOCTRL_PERFMON_CONTROL(i)
//NV_IOCTRL_PERFMON_CONTROL_M4SEL, 0, NV_IOCTRL_PERFMON_CONTROL_M4SEL
00 = Output of M3 Mux
01 = Static value 0 (1234h)
10 = Static value 1 (EDCBh)
11 = Reserved
//NV_IOCTRL_PERFMON_CONTROL_M4MODE
0 = Clear on underflow
1 = Hold on underflot

//NV_IOCTRL_PERFMON_CONTROL_M4ENABLE
//NV_IOCTRL_PERFMON_CONTROL_M3MODE
Mode for M3 mux operation. 
0 = 1:1 mode 
1 = 2:1 mode
}
#endif


/*******************************************************************************
SMPC (SM performance counters) require custom ctxsw ucode to properly disable
counters as early as possible in the save routine and enable the counters as
late as possible in the restore routine. In addition some of the registers are
per QCTL (as opposed to per SM) and need to be saved and restored without
corrupting the QCTL PRI mapping registers.
This Falcon05 method sets the SMPC CTXSW MODE for ensuring the same.
********************************************************************************/
static CUresult setFalcon05Method(CUctx* ctx)
{
    CUresult status = CUDA_SUCCESS;
    CUnvCurrent* nvCurrent = NULL;
    uint32_t data, mask;
    uint32_t headerOffset, headerType, headerIndex, accessHeader;
    int i = 0;

    CU_TRACE_FUNCTION();

    if (ctx->pmNew->flag & CU_PM_FLAG_FALCON_05_METHOD) {
        // falcon05 method is already set
        return CUDA_SUCCESS;
    }

    // https://wiki.nvidia.com/fermi/index.php/Fermi_Firmware_Methods#Class_0x9097.2C_SetFalcon05
    //
    // SetFaclon05              = data access_header
    // SetMmeShadowScratch[0]   = flag register
    // SetMmeShadowScratch[1]   = data
    // SetMmeShadowScratch[2]   = mask

    streamBeginPush(ctx->streamManager, CU_CHANNEL_COMPUTE, ctx->barrierStream, &nvCurrent, NULL);

    data = REF_NUM(NV_CTXSW_MAIN_IMAGE_SMPC_MODE, NV_CTXSW_MAIN_IMAGE_SMPC_MODE_CTXSW);
    mask = DRF_SHIFTMASK(NV_CTXSW_MAIN_IMAGE_SMPC_MODE);
    headerOffset = REF_NUM(NV_CTXSW_MAIN_IMAGE_ACCESS_HEADER_OFFSET, NV_CTXSW_MAIN_IMAGE_PM);
    headerType   = REF_NUM(NV_CTXSW_MAIN_IMAGE_ACCESS_HEADER_TYPE, NV_CTXSW_MAIN_IMAGE_ACCESS_HEADER_TYPE_MAIN);
    headerIndex  = REF_NUM(NV_CTXSW_MAIN_IMAGE_ACCESS_HEADER_INDEX, 0);
    accessHeader = headerOffset | headerType | headerIndex;

    NV_PUSH_1U(C3C0, WAIT_FOR_IDLE,  0);

    NV_PUSH_3U(C3C0, SET_MME_SHADOW_SCRATCH(0), 0,
        SET_MME_SHADOW_SCRATCH(1), data,
        SET_MME_SHADOW_SCRATCH(2), mask);
    NV_PUSH_1U(C3C0, SET_FALCON05, accessHeader);

    for (i  = 0; i < 10; i++) {
        NV_PUSH_1U(C3C0, NO_OPERATION, 0);
    }

    NV_PUSH_1U(C3C0, WAIT_FOR_IDLE,  0);

    streamEndPush(ctx->barrierStream, nvCurrent, NULL);

    // Wait for the write to complete
    status = cuiCtxSynchronize(ctx);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Ctx sync failed following Falcon05 method.\n"));
        return status;
    }

    // set flag
    ctx->pmNew->flag |= CU_PM_FLAG_FALCON_05_METHOD;

    return status;
}

static NvU32 getCounterMultiplicationFactor(NvU64 arch, CUeventID eventId) {
    // see bug 876915 for a complete list of counters
    // which require multiplication factor
    // TODO: current list is valid for GM107/106/110 chips
    // verify for other chips as and when they come
    switch(eventId) {
        case VOLTA_HWPM_ACTIVE_WARPS:
        case VOLTA_HWPMMUX_ACTIVE_WARPS:
        case VOLTA_SM_ACTIVE_WARPS:
        case VOLTA_TENSOR_PIPE_ACTIVE_CYCLES_S0:
        case VOLTA_TENSOR_PIPE_ACTIVE_CYCLES_S1:
        case VOLTA_TENSOR_PIPE_ACTIVE_CYCLES_S2:
        case VOLTA_TENSOR_PIPE_ACTIVE_CYCLES_S3:
            // The warp_cant_issue_* signals will not require a multiplication factor if profiled via HWPM.
            return 2;
        case VOLTA_MIO_L1MISS_TEX2GNIC_FOLD_WR_BYTES_SUM:
            return 4;
        default:
            return 1;
    }

    return 0;
}

static NvBool getSplittingInfo(CUeventID eventId, NvU32 *splitWidth)
{
    switch(eventId) {
        case VOLTA_SM_ACTIVE_WARPS:
            *splitWidth = 2;
            break;
        default:
            *splitWidth = 0;
            return NV_FALSE;
    }
    return NV_TRUE;
}

CUprofResult voltaPerfmonGetInstanceValues(CUdev *dev, CUdomainData *domainData, NvU32 *avail, NvU32 *total)
{
    NvU32 k = 0;
    if(!avail || !total)
        return CUPROF_ERROR_INVALID_PARAMETER;

    *avail = *total = 1;

    switch(domainData->chipletType)
    {
    case PM_CHIPLET_TYPE_GPC:
        *total = 0;
        for(k=0; k<dev->state.limits.numGpcs; k++) {
            *total += dev->state.limits.numTpcsPerGpc[k];
        }
        *total *= dev->state.limits.numSmsPerTpc;
        *avail = *total;
        break;
    case PM_CHIPLET_TYPE_FBP:
        if (dev->dmalType == CU_DMAL_AMODEL) {
            *total = 1;
        } else {
            if(domainData->domainId == VOLTA_CLK_DOMAIN_GV100_LTC0 || domainData->domainId == VOLTA_CLK_DOMAIN_GV11B_LTC0) {
                 // 4 slices/rop_l2 and 2 perfmons so 1 perfmon for 2 slices
                    *total = dev->state.limits.numL2 * VOLTA_PERFMONS_PER_ROP_L2;
            } else {
                //We have 2 fbp perfmons per fb chiplet
                *total = dev->state.limits.numFbps * VOLTA_FBPA_PER_FBP;
            }
        }
        *avail = *total;
        break;
    case PM_CHIPLET_TYPE_SYS:
        if((domainData->domainId == VOLTA_CLK_DOMAIN_GV100_NVLINK_THROUGHPUT_COUNTERS) ||
           (domainData->domainId == VOLTA_CLK_DOMAIN_GV100_NVLTX0) ||
           (domainData->domainId == VOLTA_CLK_DOMAIN_GV100_NVLRX0)) {
            *total = VOLTA_NVLINK_MAX_LINKS;
        }
        else {
            *total = 1;
        }
        *avail = *total;
        break;
    case PM_CHIPLET_TYPE_NONE:
        // We should come here only for CUPTI SW counters
        CU_ASSERT(domainData->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_CUPTI_SW);

        // Setting the instance count to total number of SMs. SW counter are
        // currently collected at SM granuality only. This may change in the
        // future
        *total = 0;
        for(k = 0; k < dev->state.limits.numGpcs; k++) {
            *total += dev->state.limits.numTpcsPerGpc[k];
        }
        *total *= dev->state.limits.numSmsPerTpc;
        *avail = *total;
        break;
    default:
        CU_ASSERT(0);
        break;
    }
    return CUPROF_SUCCESS;
}

CUprofResult voltaPerfmonDeviceInitEventDomainInfo(CUdev *pDev) {
    CUprofResult status = CUPROF_SUCCESS;
    void *pSignalTable = NULL;
    CUdomainData *pDomainData = NULL;
    NvU32 maxInternalSignals = 0;
    NvU32 maxExternalSignals = 0;
    NvU32 numDomains = 0;
    NvU32 numInternalDomains = 0;
    NvU32 i = 0;
    NvU32 sigTableIdx = 0;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pDev);

    if(pDev->state.pDomainInfo == NULL) {
        return CUPROF_ERROR_UNKNOWN;
    }

    if (pDev->state.pDomainInfo->bInit) {
        // domain data is already populated
        return CUPROF_SUCCESS;
    }
    else
    {
        NvBool internalCountersExposed = 0;
        NvU32 signalTableEntrySize = 0;
        unsigned int old = cuosInterlockedExchange(&pDev->state.pDomainInfo->bInitStarted, 1);
        if (old == 0) {
            perfmonDemangleStrings();
            internalCountersExposed = perfmonInternalCountersExposed();
            numDomains = pDev->state.pDomainInfo->numDomains;

            if(!internalCountersExposed) {
                for (i = 0; i < numDomains; i++) {
                    if (!strncmp(pDev->state.pDomainInfo->pDomainTable[i].domainName, PM_INTERNAL_SIGNAL_PREFIX, 2)) {
                        numInternalDomains++;
                    }
                }
                numDomains -= numInternalDomains;
            }

            pDev->state.pDomainInfo->numDomains = numDomains;

            for (i = 0; i < numDomains; i++) {
                maxExternalSignals = maxInternalSignals = 0;
                for(sigTableIdx = 0; sigTableIdx < pDev->state.pDomainInfo->pDomainTable[i].numPerfSignalTables; sigTableIdx++) {
                    perfmonGetSizeOfSignalTableEntry(pDev->state.pDomainInfo->pDomainTable[i].pEventTableInfo[sigTableIdx].signalTableType,
                                                     &signalTableEntrySize);
                    pSignalTable = pDev->state.pDomainInfo->pDomainTable[i].pEventTableInfo[sigTableIdx].pEventData;
                    if (pSignalTable != NULL) {
                        while (((CUeventDataBasic*)pSignalTable)->signalId != INVALID_PM_SIGNAL_NEW) {
                            if (SIG_TYPE_IS_EXPOSED(((CUeventDataBasic*)pSignalTable)->signalId)) {
                                maxExternalSignals++;
                            }
                            else if (!SIG_TYPE_IS_INTERNAL(((CUeventDataBasic*)pSignalTable)->signalId)){
                                maxInternalSignals++;
                            }
                            pSignalTable = (void*)((NvU8*)pSignalTable + signalTableEntrySize);
                        }
                    }
                }
                pDomainData = &pDev->state.pDomainInfo->pDomainTable[i];

                pDomainData->maxExternalEvents = maxExternalSignals;
                pDomainData->maxInternalEvents = maxInternalSignals;

                if(internalCountersExposed) {
                    pDomainData->exposedEvents         = maxExternalSignals + maxInternalSignals;
                }
                else {
                    pDomainData->exposedEvents         = maxExternalSignals;
                }
            }
            cuosInterlockedIncrement(&pDev->state.pDomainInfo->bInit);
        }
        else {
            // Another thread has started initialization, all other threads
            // must wait until it has completed.
            while (pDev->state.pDomainInfo->bInit == 0) {
                cuosThreadYield();
            }
        }
    }

    return status;
}

//Allocate the arch specific eventgroup structure and initialize it
static CUprofResult voltaInitEventGroup(CUeventGroup *pEventGroup)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUvoltaEventGroup *pPascalEg = NULL;

    CU_TRACE_FUNCTION();

    if(pEventGroup->arch.voltaEventGroup == NULL) {
        pPascalEg = (CUvoltaEventGroup*)malloc(sizeof(CUvoltaEventGroup));
        if(!pPascalEg) {
            CU_ERROR_PRINT(("Failed to allocate memory for CUvoltaEventGroup\n"));
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto Error;
        }
        cuosMemset(pPascalEg, 0, sizeof(CUvoltaEventGroup));

        pEventGroup->arch.voltaEventGroup = pPascalEg;

        //TBD allocation of domain specific structures can be delayed until the
        //first event is added, saves memory
        //Following is used only for PM signals
        pPascalEg->pParsedClk = (CUparsedClk*)malloc(sizeof(CUparsedClk));

        if (!pPascalEg->pParsedClk) {
            CU_ERROR_PRINT(("Failed to allocate memory for CUparsedClk\n"));
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto Error;
        }
        cuosMemset(pPascalEg->pParsedClk, 0, sizeof(CUparsedClk));

        //Following is used only for SM counters
        pPascalEg->pSM = (CUSMCtrInfo*)malloc(sizeof(CUSMCtrInfo));

        if (!pPascalEg->pSM) {
            CU_ERROR_PRINT(("Failed to allocate memory for CUSMCtrInfo\n"));
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto Error;
        }
        cuosMemset(pPascalEg->pSM, 0, sizeof(CUSMCtrInfo));

        //Following is used only for NvLink throughput counters
        pPascalEg->nvLinkTCConfig = (nvLinkTCSignalConfig*)malloc(sizeof(nvLinkTCSignalConfig));

        if (!pPascalEg->nvLinkTCConfig) {
            CU_ERROR_PRINT(("Failed to allocate memory for CUSMCtrInfo\n"));
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto Error;
        }
        cuosMemset(pPascalEg->nvLinkTCConfig, 0, sizeof(nvLinkTCSignalConfig));

    }

Error:
    if (status != CUPROF_SUCCESS) {
        voltaDestroyEventGroup(pEventGroup);
    }

    return status;
}

//Destroy the arch specific eventgroup structure
static CUprofResult voltaDestroyEventGroup(CUeventGroup *pEventGroup)
{
    NvU32 idx = 0;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if(pEventGroup->arch.voltaEventGroup)
    {
        if(pEventGroup->arch.voltaEventGroup->pParsedClk)
        {
            // Freeing the extra space as well which is allocated for profiling elapsed_clocks
            for (idx = 0; idx < (CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS * MAX_SIGNALS_PER_EXPERIMENT); idx++) {
                if(pEventGroup->arch.voltaEventGroup->pParsedClk->pParsedUnit[idx])
                {
                    free (pEventGroup->arch.voltaEventGroup->pParsedClk->pParsedUnit[idx]);
                    pEventGroup->arch.voltaEventGroup->pParsedClk->pParsedUnit[idx] = NULL;
                }
            }
            if(pEventGroup->arch.voltaEventGroup->pParsedClk->values) {
                free (pEventGroup->arch.voltaEventGroup->pParsedClk->values);
                pEventGroup->arch.voltaEventGroup->pParsedClk->values = NULL;
            }

            free(pEventGroup->arch.voltaEventGroup->pParsedClk);
            pEventGroup->arch.voltaEventGroup->pParsedClk = NULL;
        }

        if(pEventGroup->arch.voltaEventGroup->pSM)
        {
            NvU32 sig_cnt = 0, smcntr_idx = 0, j = 0;
            CUSMCtrInfo *pSM = NULL;
            pSM=pEventGroup->arch.voltaEventGroup->pSM;
            if(pSM->values) {
                free (pSM->values);
                pSM->values = NULL;
            }
            if(pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_SMPERF) {
                // Free the memory allocated additionally for splitted counters, if any.
                for(sig_cnt=0; sig_cnt < pEventGroup->totalCounters; sig_cnt++)
                {
                    if(pSM->splitParts[sig_cnt] > 1) {
                        for(j=smcntr_idx; j<(smcntr_idx + pSM->splitParts[sig_cnt]); j++) {
                            free(pSM->sigtableInfo[j]->pEventData);
                            free(pSM->sigtableInfo[j]);
                        }
                    }
                    smcntr_idx += pSM->splitParts[sig_cnt];
                }
            }
            if(pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX){
                // Free the memory allocated additionally for splitted counters, if any.
                for(sig_cnt=0; sig_cnt < pEventGroup->totalCounters; sig_cnt++)
                {
                    //SMPC table entry was temporarily created for HWPM mux signals
                    free(pSM->sigtableInfo[sig_cnt]->pEventData);
                    free(pSM->sigtableInfo[sig_cnt]);
                }
            }
            free(pSM);
            pSM = NULL;
        }

        //Following is used only for NvLink throughput counters
        if (pEventGroup->arch.voltaEventGroup->nvLinkTCConfig) {
            free(pEventGroup->arch.voltaEventGroup->nvLinkTCConfig);
            pEventGroup->arch.voltaEventGroup->nvLinkTCConfig = NULL;
        }

        free(pEventGroup->arch.voltaEventGroup);
        pEventGroup->arch.voltaEventGroup = NULL;
    }

    return CUPROF_SUCCESS;
}

CUprofResult voltaPerfmonEventGroupCreate(CUctx *pCtx, CUeventGroup **pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    CUeventGroup *pGroup = NULL;

    CU_TRACE_FUNCTION();

    CU_ASSERT(pEventGroup);
    CU_ASSERT(pCtx);

    pGroup = (CUeventGroup*)malloc(sizeof(CUeventGroup));
    if (pGroup == NULL) {
        CU_DEBUG_PRINT(("Failed to allocate memory to event group\n"));
        return CUPROF_ERROR_OUT_OF_MEMORY;
    }
    cuosMemset(pGroup, 0, sizeof(CUeventGroup));

    pGroup->domainId = INVALID_DOMAIN_ID;
    pGroup->pCtx = pCtx;                 //Context for which eventgroup is created
    pGroup->profileAll = 1;

    // Initializing the profiling scope of the event Group.
    // The scope of the event group will be set by CUPTI based on following:
    //      1. Domain scope of the event
    //      2. Scope of the event which user sets.
    pGroup->eventGroupScope = CU_EVENT_GROUP_SCOPE_FORCE_INT;

    *pEventGroup = pGroup;

    if (pCtx->pmNew == NULL) {
        status = perfmonStructCreate(&pCtx->pmNew);
        if (status != CUPROF_SUCCESS) {
            goto Exit;
        }
    }

    if (pCtx->pmNew->egList == NULL) {
        // event object list hasn't been init yet, do it now
        status = (CUprofResult)listInit(&pCtx->pmNew->egList, NULL, NULL, NULL, egCompareData);
        if (status != CUPROF_SUCCESS) {
            goto Exit;
        }
    }

    // add to the event group list maintained in the context
    listAddToHead(pCtx->pmNew->egList, *pEventGroup);

    pCtx->pmNew->totalEventGroups++;
    return CUPROF_SUCCESS;

Exit:
    //If any error occurs, free allocated memory and return NULL
    voltaDestroyEventGroup(pGroup);
    free(pGroup->values);
    free(pGroup);
    free (pCtx->pmNew);
    pCtx->pmNew = NULL;

    *pEventGroup = NULL;
    CU_ERROR_PRINT(("voltaPerfmonEventGroupCreate Failed\n"));
    return status;
}

CUprofResult voltaPerfmonEventGroupDestroy(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 i = 0;
    CUeventInfo *currEvent = NULL;
    void *eventBase = NULL;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if (pEventGroup->isEnabled) {
        // don't allow destroy for enabled event group
        return CUPROF_ERROR_UNKNOWN;
    }

    // deallocate arch specific eventgroup
    status = voltaDestroyEventGroup(pEventGroup);

    currEvent = (CUeventInfo*)listGetNext(pEventGroup->pEventInfoList, &eventBase);
    for (i = 0; (i < pEventGroup->totalCounters) && currEvent; i++, currEvent = (CUeventInfo*)listGetNext(NULL, &eventBase)) {
        if(currEvent) {
            free(currEvent);
        }
    }

    // destroy event list
    if (pEventGroup->pEventInfoList) {
        listDestroy(pEventGroup->pEventInfoList);
        pEventGroup->pEventInfoList = NULL;
    }
    // deallocate values array
    free (pEventGroup->values);
    pEventGroup->values = NULL;

    // remove event group from list first
    listRemFrom(pEventGroup->pCtx->pmNew->egList, pEventGroup);

    // reduce event group count in context
    pEventGroup->pCtx->pmNew->totalEventGroups--;

    if(pEventGroup->nopTrigSwCounterData) {
        free(pEventGroup->nopTrigSwCounterData);
        pEventGroup->nopTrigSwCounterData = NULL;
    }
    free (pEventGroup);
    pEventGroup = NULL;

    return status;
}

// traverse domain signal table for matching signal
static NV_INLINE CUeventInfo* voltaLookupDomainSignalTable(CUdomainData *pDomainData, const NvU32 eventID)
{
    NvU32 sigTableIdx = 0, signalTableEntrySize = 0;
    CUeventInfo* pEventTableInfo_temp = NULL;
    void* pEventData = NULL;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pDomainData);

    pEventTableInfo_temp = (CUeventInfo*)calloc(1, sizeof(CUeventInfo));
    if (pEventTableInfo_temp == NULL) {
        CU_DEBUG_PRINT(("Failed to allocate memory to pEventTableInfo_temp\n"));
        return NULL;
    }
    for(sigTableIdx = 0; sigTableIdx < pDomainData->numPerfSignalTables; sigTableIdx++) {
        perfmonGetSizeOfSignalTableEntry(pDomainData->pEventTableInfo[sigTableIdx].signalTableType,
                                         &signalTableEntrySize);

        pEventData = pDomainData->pEventTableInfo[sigTableIdx].pEventData;
        while (((CUeventDataBasic*)pEventData)->signalId != INVALID_PM_SIGNAL_NEW) {
            if (eventID == ((CUeventDataBasic*)pEventData)->signalId) {
                pEventTableInfo_temp->signalTableType = pDomainData->pEventTableInfo[sigTableIdx].signalTableType;
                pEventTableInfo_temp->pEventData = pEventData;
                return pEventTableInfo_temp;
            }
            pEventData = (void*)((NvU8*)pEventData + signalTableEntrySize);
        }
    }
    // return NULL if not found
    free(pEventTableInfo_temp);
    return NULL;
}
//*****************************************************************
static CUprofResult getWatchbus(signalConfig *tempSignalConfig, NvU32 startBit, NvU32 partWidth, NvU32 width, NvU32 *out)
{
    NvU32 startWord = 0;
    NvU32 endWord = 0;
    NvU32 startPos = 0;
    NvU32 endPos = 0;
    NvU32 startWatchBus = 0;
    NvU32 endWatchBus = 0;
    NvU32 endBit = (startBit+partWidth-1);

    startWord = startBit >> 2; startPos = startBit & 3;
    endWord = endBit >> 2; endPos = endBit & 3;
    startWatchBus = tempSignalConfig->tempWatchbus[startWord];
    endWatchBus = tempSignalConfig->tempWatchbus[endWord];

    startPos *= 8; endPos = ((endPos + 1) * 8) - 1;
    *out = 0;
    if (startWatchBus == endWatchBus) {
        *out = REF_VAL(endPos:startPos, startWatchBus);
    } else {
        *out |= REF_VAL(31:startPos, startWatchBus);
        *out |= (REF_VAL(endPos:0, endWatchBus)) << (32 - startPos);
        //*out |= startWatchBus >> (startPos * 8);
        //*out |= endWatchBus << ((4 - startPos) * 8);
    }

    if (partWidth < width) {
        //false watchbus signal to avoid garbage values
        startWatchBus = (FALSE_WATCH_BUS_SIGNAL<<24) | (FALSE_WATCH_BUS_SIGNAL<<16) |
                        (FALSE_WATCH_BUS_SIGNAL<<8) | (FALSE_WATCH_BUS_SIGNAL);
        *out |= (REF_VAL((width*8-1):(partWidth*8), startWatchBus)) << (partWidth*8);
    }

    return CUPROF_SUCCESS;
}

static CUprofResult getEventSpec(const CUparsedClk *pTempParsedClk, signalConfig *tempSignalConfig, NvU32 *pEventSpec, NvU32 *pNewMode) {

    NvU32 mode = tempSignalConfig->mode;
    NvU32 busWidth = tempSignalConfig->busWidth;

    CU_TRACE_FUNCTION();

    *pEventSpec = 0;

    // select the right event specification for each counter
    if (pTempParsedClk) {
        //Check mode compatibility first
        //Check if this counter has event available
        //set new mode if everything goes fine
        switch(mode) {
            case NV_PMM_CONTROL_ADDTOCTR_INCR:
                //Don't allow INCR4444 with INCR mode if signal width is 0. INCR4444 doesn't allow counter
                //to be incremented on a logical combination.
                if ((pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_2X4B4I) ||
                    (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_2X2B6I) ||
                    ((pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_4444) && (tempSignalConfig->busWidth == 0))) {
                    return CUPROF_ERROR_NOT_COMPATIBLE;
                }

                if ((pTempParsedClk->eventSpecUsed & NV_PMM_SAMPLE) == 0) {
                    *pEventSpec = NV_PMM_SAMPLE;
                    tempSignalConfig->watchBus[NV_PMM_SAMPLE_BIT_POS] = tempSignalConfig->tempWatchbus[0];
                    tempSignalConfig->partNumber |= (NV_PMM_SAMPLE_BIT_POS + 1);
                }
                else if ((pTempParsedClk->eventSpecUsed & NV_PMM_TRIG0) == 0) {
                    *pEventSpec = NV_PMM_TRIG0;
                    tempSignalConfig->watchBus[NV_PMM_TRIG0_BIT_POS] = tempSignalConfig->tempWatchbus[0];
                    tempSignalConfig->partNumber |= (NV_PMM_TRIG0_BIT_POS + 1);
                }
                //Keep TRIG1 and EVENT at the end so that we can allow the event/TRIG 4/6 modes along with INCR
                else if ((pTempParsedClk->eventSpecUsed & NV_PMM_EVENT) == 0) {
                    *pEventSpec = NV_PMM_EVENT;
                    tempSignalConfig->watchBus[NV_PMM_EVENT_BIT_POS] = tempSignalConfig->tempWatchbus[0];
                    tempSignalConfig->partNumber |= (NV_PMM_EVENT_BIT_POS + 1);
                }
                else if ((pTempParsedClk->eventSpecUsed & NV_PMM_TRIG1) == 0) {
                    *pEventSpec = NV_PMM_TRIG1;
                    tempSignalConfig->watchBus[NV_PMM_TRIG1_BIT_POS] = tempSignalConfig->tempWatchbus[0];
                    tempSignalConfig->partNumber |= (NV_PMM_TRIG1_BIT_POS + 1);
                }
                else
                    //All 4 events are used
                    return CUPROF_ERROR_MAX_LIMIT_REACHED;

                if (pTempParsedClk->mode != (NvU32)-1) {
                    *pNewMode = pTempParsedClk->mode;
                }

                //mode is INCR then set the mode only if mode is not initialized, else it will be subset of some other compatible mode.
                if (pTempParsedClk->mode == (NvU32) -1)
                    *pNewMode = mode;

                break;

            case NV_PMM_CONTROL_ADDTOCTR_EVENT4:
            case NV_PMM_CONTROL_ADDTOCTR_TRIG4:
                CU_ASSERT(busWidth <= 4);

            case NV_PMM_CONTROL_ADDTOCTR_EVENT6:
            case NV_PMM_CONTROL_ADDTOCTR_TRIG6:
                CU_ASSERT(busWidth <= 6);
                if ((pTempParsedClk->mode != NV_PMM_CONTROL_ADDTOCTR_INCR) && (pTempParsedClk->mode != (NvU32) -1))
                    return CUPROF_ERROR_NOT_COMPATIBLE;

                if ((pTempParsedClk->eventSpecUsed & NV_PMM_TRIG1) || (pTempParsedClk->eventSpecUsed & NV_PMM_EVENT))
                    //The events required for the mode are not available
                    return CUPROF_ERROR_NOT_COMPATIBLE;

                if (busWidth == 2) {
                    tempSignalConfig->watchBus[NV_PMM_EVENT_BIT_POS] |= (tempSignalConfig->tempWatchbus[1] & 0x0000ffff);
                } else {
                    tempSignalConfig->watchBus[NV_PMM_TRIG1_BIT_POS] = tempSignalConfig->tempWatchbus[1];
                    tempSignalConfig->watchBus[NV_PMM_EVENT_BIT_POS] |= tempSignalConfig->tempWatchbus[0];
                }

                *pEventSpec = NV_PMM_TRIG1 | NV_PMM_EVENT;

                *pNewMode = mode;
                break;

            case NV_PMM_CONTROL_ADDTOCTR_2X2B6I:
                CU_ASSERT(busWidth <= 6);
                if ((pTempParsedClk->mode != NV_PMM_CONTROL_ADDTOCTR_2X2B6I) && (pTempParsedClk->mode != (NvU32)-1))
                    return CUPROF_ERROR_NOT_COMPATIBLE;

                if (((pTempParsedClk->eventSpecUsed & NV_PMM_TRIG1) == 0) || ((pTempParsedClk->eventSpecUsed & NV_PMM_EVENT) == 0)) {
                    tempSignalConfig->watchBus[NV_PMM_TRIG1_BIT_POS] = tempSignalConfig->tempWatchbus[0];
                    tempSignalConfig->watchBus[NV_PMM_EVENT_BIT_POS] = tempSignalConfig->tempWatchbus[1];


                    *pEventSpec = NV_PMM_TRIG1 | NV_PMM_EVENT;
                } else if (((pTempParsedClk->eventSpecUsed & NV_PMM_TRIG0) == 0) || ((pTempParsedClk->eventSpecUsed & NV_PMM_SAMPLE) == 0)) {
                    tempSignalConfig->watchBus[NV_PMM_SAMPLE_BIT_POS] = tempSignalConfig->tempWatchbus[0];
                    tempSignalConfig->watchBus[NV_PMM_TRIG0_BIT_POS] = tempSignalConfig->tempWatchbus[1];

                    *pEventSpec = NV_PMM_TRIG0 | NV_PMM_SAMPLE;
                } else
                    //The events required for the mode are not available
                    return CUPROF_ERROR_MAX_LIMIT_REACHED;

                *pNewMode = mode;
                break;

            case NV_PMM_CONTROL_ADDTOCTR_2X4B4I:
                if ((pTempParsedClk->mode != NV_PMM_CONTROL_ADDTOCTR_2X4B4I) && (pTempParsedClk->mode != (NvU32) -1))
                    return CUPROF_ERROR_NOT_COMPATIBLE;

                if (((pTempParsedClk->eventSpecUsed & NV_PMM_TRIG1) == 0) || ((pTempParsedClk->eventSpecUsed & NV_PMM_EVENT) == 0)) {
                    tempSignalConfig->watchBus[NV_PMM_TRIG1_BIT_POS] = tempSignalConfig->tempWatchbus[0];
                    tempSignalConfig->watchBus[NV_PMM_EVENT_BIT_POS] |= tempSignalConfig->tempWatchbus[1];

                    *pEventSpec = NV_PMM_TRIG1 | NV_PMM_EVENT;
                }
                else if (((pTempParsedClk->eventSpecUsed & NV_PMM_TRIG0) == 0) || ((pTempParsedClk->eventSpecUsed & NV_PMM_SAMPLE) == 0)) {
                    tempSignalConfig->watchBus[NV_PMM_SAMPLE_BIT_POS] = tempSignalConfig->tempWatchbus[0];
                    tempSignalConfig->watchBus[NV_PMM_TRIG0_BIT_POS] |= tempSignalConfig->tempWatchbus[1];

                    *pEventSpec = NV_PMM_TRIG0 | NV_PMM_SAMPLE;
                }
                else
                    //The events required for the mode are not available
                    return CUPROF_ERROR_MAX_LIMIT_REACHED;

                *pNewMode = mode;
                break;

            case NV_PMM_CONTROL_ADDTOCTR_4444:
            {
                NvU32 counter = 0;
                if ((pTempParsedClk->mode != (NvU32)-1)
                    && (pTempParsedClk->mode != NV_PMM_CONTROL_ADDTOCTR_4444) 
                    && (pTempParsedClk->mode != NV_PMM_CONTROL_ADDTOCTR_INCR)) {
                    return CUPROF_ERROR_NOT_COMPATIBLE;
                }

                if (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_INCR) {
                    //If eventgroup mode is INCR and all previously added counters are
                    //single bit counters, allow promoting mode to 4444.
                    while (counter < pTempParsedClk->totalHardwareCounters) {
                        if (pTempParsedClk->width[counter] == 0 && pTempParsedClk->eventspec[counter] != NV_ELAPSED_CLOCKS) {
                            //Cannot allow 4444 counter with counter in INCR mode that increments on logical commbination
                            return CUPROF_ERROR_NOT_COMPATIBLE;
                        }
                        counter++;
                    }
                }
                {
                    NvU32 partNumber = 0, startPos = 0, partWidth = 0, out = 0, eventSpecUsed = 0, spec = NV_PMM_TRIG0_BIT_POS;
                    eventSpecUsed = pTempParsedClk->eventSpecUsed;
                    while ((busWidth > 0) && (spec <= NV_PMM_SAMPLE_BIT_POS)) {
                        //Keep TRIG1 and EVENT at the end so that we can allow the event/TRIG 4/6 modes along with INCR
                        if ((eventSpecUsed & (1 << spec)) == 0) {
                            eventSpecUsed |= (1 << spec);
                            *pEventSpec |= (1 << spec);
                            partWidth = (busWidth >= 4) ? 4 : busWidth;
                            getWatchbus(tempSignalConfig, startPos, partWidth, 4, &out);
                            //TBD add false signal here at the beginning if busWidth < 4
                            startPos += partWidth;
                            tempSignalConfig->watchBus[spec] = out;
                            busWidth -= partWidth;
                            //Adding + 1 to eventspec position as it can't be 0 becuase then we cannot
                            //distinguish between uninitialized and spec 0.
                            //Can't initialize to 0xff as we need to OR the part numbers (increases complexity)
                            tempSignalConfig->partNumber |= ((spec + 1) << (partNumber * 8));
                            partNumber++;
                        }
                        spec++;
                    }
                    if ((spec > NV_PMM_SAMPLE_BIT_POS) && (busWidth > 0)) {
                        //All 4 events are used
                        return CUPROF_ERROR_MAX_LIMIT_REACHED;
                    }
                }
                *pNewMode = mode;
            }
            break;
        }
    }
    return CUPROF_SUCCESS;
}


#define GETVAL(n, drf) (((n)>>DRF_SHIFT(drf))&DRF_MASK(drf))
#define SETVAL(n, drf) (((n)&DRF_MASK(drf))<<DRF_SHIFT(drf))

#define CHECK_AND_SET_GROUP_ADD(oldAdd, newAdd) \
    do { \
    if ((oldAdd != INVALID_ADDRESS) && (oldAdd != newAdd)) {\
    status = CUPROF_ERROR_NOT_COMPATIBLE; \
    goto EXIT; \
    } else if (oldAdd == INVALID_ADDRESS) { \
    oldAdd = newAdd; \
    } \
    } while(0)

#define CHECK_AND_SET_GROUP_MASK_VAL(oldMask, oldVal, drf, val) \
    do { \
    if((oldMask != 0) && (GETVAL(oldMask, drf)!=0)) {\
    n = GETVAL(oldVal, drf); \
    if (val != n) {\
    status = CUPROF_ERROR_NOT_COMPATIBLE; \
    goto EXIT;  \
    }\
    } else {\
    oldMask = DRF_REPLACE(oldMask, 0xffffffff, endBit:startBit);\
    oldVal  = DRF_REPLACE(oldVal, val, endBit:startBit);\
    }\
    } while(0)

static CUprofResult performUnitCompatibilityCheckNvlink(CUparsedClk *pParsedClk, PerfUnitTable *tempPerfUnitTable, signalConfig *tempSignalConfig, CUeventDataHwpm * pEventData, NvU32 *pGroupId)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 k =0, j = 0, n = 0, i = 0, startBit = 0, endBit = 0, groupId;
    NvU32 foundInTemp = 0, foundInParsedClk = 0, unitId = 0, eventGroup = 0;

    if (!((pEventData->pmUnitId == PM_UNIT_NVTX)  || (pEventData->pmUnitId == PM_UNIT_NVRX))) {
        return CUPROF_SUCCESS;
    }

    unitId = pEventData->pmUnitId;
    eventGroup = pEventData->eventGroup;

    while (tempPerfUnitTable[j].pmUnitId != PM_UNIT_MAX) {
        if (tempPerfUnitTable[j].pmUnitId == unitId) {
            {
                i = 0;
                while (tempSignalConfig->unitInfo[i] && !foundInTemp) {
                    if (tempSignalConfig->unitInfo[i]->unitId == tempPerfUnitTable[j].pmUnitId) {
                        //another signal with same unit has already been added while preparing config for this expt
                        //Should be true only for expt cases
                        NvU32 tempMask = tempSignalConfig->unitInfo[i]->groupSelMask; 
                        NvU32 tempValue = tempSignalConfig->unitInfo[i]->groupSelValue;
                        for (groupId = 0; groupId < 4 && tempMask; groupId++) {
                            NvU32 group = tempValue & 0xff;
                            if (group == pEventData->eventGroup) {
                                foundInTemp = 1;
                                break;
                            }
                            tempMask >>= 8;
                            tempValue >>= 8;
                        }
                        if (foundInTemp) break;
                        if (groupId == 4) {
                            //This means the experiment already added 4 different groups which
                            //ideally shouldn't be taken care of while creating signal table
                            CU_ASSERT(0);
                            return CUPROF_ERROR_NOT_COMPATIBLE;
                        }
                        if (groupId < 4 && !foundInTemp) {
                            //Group for this counter/signal is new so add it in the original signal's group.
                            //Update the first nvlink tx or rx unit encountered so can be found first for later signals as well
                            tempSignalConfig->unitInfo[i]->groupSelValue = (tempSignalConfig->unitInfo[i]->groupSelValue) | (pEventData->eventGroup << (groupId * 8));
                            tempSignalConfig->unitInfo[i]->groupSelMask = (tempSignalConfig->unitInfo[i]->groupSelMask) | (0xff << (groupId * 8));
                            foundInTemp = 1;
                            break;
                        }
                    }
                    i++;
                }

                k = 0;
                while(pParsedClk && pParsedClk->pParsedUnit[k] && !foundInTemp) {
                    //Check if have already added any signal from same unit and same group
                    //if so, assign those values to temp values so that we can check if
                    //we are using same group else return error.
                    if (pParsedClk->pParsedUnit[k]->unitId == tempPerfUnitTable[j].pmUnitId) {
                        NvU32 tempMask = 0, tempValue = 0;

                        tempSignalConfig->unitInfo[i] = (signalUnitConfig *) malloc(sizeof(signalUnitConfig));
                        if (!tempSignalConfig->unitInfo[i]) {
                            status = CUPROF_ERROR_OUT_OF_MEMORY;
                            goto EXIT;
                        }
                        //CU_ASSERT(pParsedClk->pParsedUnit[k]->unitId == tempPerfUnitTable[j].pmUnitId);
                        tempSignalConfig->unitInfo[i]->groupSelAddress = pParsedClk->pParsedUnit[k]->groupSelAddress;
                        tempSignalConfig->unitInfo[i]->groupSelMask = pParsedClk->pParsedUnit[k]->groupSelMask;
                        tempSignalConfig->unitInfo[i]->groupSelValue = pParsedClk->pParsedUnit[k]->groupSelValue;
                        tempSignalConfig->unitInfo[i]->unitId = pParsedClk->pParsedUnit[k]->unitId;
                        
                        tempMask = pParsedClk->pParsedUnit[k]->groupSelMask; 
                        tempValue = pParsedClk->pParsedUnit[k]->groupSelValue;

                        for (groupId = 0; groupId < 4 && tempMask; groupId++) {
                            NvU32 group = tempValue & 0xff;
                            if (group == pEventData->eventGroup) {
                                foundInParsedClk = 1;
                                break;
                            }
                            tempMask >>= 8;
                            tempValue >>= 8;
                        }
                        if (foundInParsedClk) { 
                            //The group already exists in the previous signal 
                            break;
                        }
                        if (groupId == 4) {
                            //This means some counters and/or experiments have already used
                            //all 4 different groups
                            return CUPROF_ERROR_NOT_COMPATIBLE; 
                        }
                        if (groupId < 4 && !foundInParsedClk) {
                            //Group for this counter/signal is new so add it in the original signal's group.
                            //Update the first nvlink tx or rx unit encountered so can be found first for later signals as well
                            pParsedClk->pParsedUnit[k]->groupSelValue = tempSignalConfig->unitInfo[i]->groupSelValue = (pParsedClk->pParsedUnit[k]->groupSelValue) | (pEventData->eventGroup << (groupId * 8));
                            pParsedClk->pParsedUnit[k]->groupSelMask = tempSignalConfig->unitInfo[i]->groupSelMask = (pParsedClk->pParsedUnit[k]->groupSelMask) | (0xff << (groupId * 8));
                            tempSignalConfig->unitInfo[i]->unitId = pParsedClk->pParsedUnit[k]->unitId;
                            foundInParsedClk = 1;
                            break;
                        }
                    }
                    k++;
                }
            }

            if (!foundInParsedClk && !foundInTemp) {
                //This is a new unit
                tempSignalConfig->unitInfo[i] = (signalUnitConfig *) malloc(sizeof(signalUnitConfig));
                if (!tempSignalConfig->unitInfo[i]) {
                    status = CUPROF_ERROR_OUT_OF_MEMORY;
                    goto EXIT;
                }
                memset(tempSignalConfig->unitInfo[i], 0, sizeof(signalUnitConfig));
                tempSignalConfig->unitInfo[i]->groupSelAddress = INVALID_ADDRESS;
                tempSignalConfig->unitInfo[i]->unitId = unitId;
                startBit = 0;
                endBit   = 7;
                //This macro should check if the group is already set, the value shgoudl be equal, if not return error.
                CHECK_AND_SET_GROUP_ADD(tempSignalConfig->unitInfo[i]->groupSelAddress, tempPerfUnitTable[j].pmGroupSelRegInfo.regOffset);
                CHECK_AND_SET_GROUP_MASK_VAL(tempSignalConfig->unitInfo[i]->groupSelMask, tempSignalConfig->unitInfo[i]->groupSelValue, endBit:startBit, eventGroup);
                tempSignalConfig->unitInfo[i]->pPerfUnitTable = &tempPerfUnitTable[j];
                break;
            }
            tempSignalConfig->unitInfo[i]->pPerfUnitTable = &tempPerfUnitTable[j];
        }
        j++;
    }
    *pGroupId = groupId;
EXIT:
    return status;
}

static CUprofResult performUnitCompatibilityCheck(CUparsedClk *pParsedClk, PerfUnitTable *tempPerfUnitTable, signalConfig *tempSignalConfig, CUeventDataHwpm * pEventData)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 k =0, j = 0, n = 0, i = 0, startBit = 0, endBit = 0, unitsReqd = 1, unit = 0;
    NvU32 foundInTemp = 0, foundInParsedClk = 0, unitId = 0, eventGroup = 0;

    for (unit = 0; unit < unitsReqd; unit++) {
        //TBD generalize this
        if (unit == 0) {
            unitId = pEventData->pmUnitId;
            eventGroup = pEventData->eventGroup;
        } else if (unit == 1){
            unitId = pEventData->pmUnitId1;
            eventGroup = pEventData->eventGroup1;
        }
        while (tempPerfUnitTable[j].pmUnitId != PM_UNIT_MAX) {
            if (tempPerfUnitTable[j].pmUnitId == unitId) {

                //if (init)
                {
                    i = 0;
                    while(tempSignalConfig->unitInfo[i]) {
                        //if (tempSignalConfig->unitInfo[i]->groupSelAddress == tempPerfUnitTable[j].pmGroupSelRegInfo.regOffset) {
                        if (tempSignalConfig->unitInfo[i]->unitId == tempPerfUnitTable[j].pmUnitId) {

                            //another signal with same unit has already been added while preparing config for this expt
                            //Should be true only for expt cases
                            foundInTemp = 1;
                            break;
                        }
                        i++;
                    }
                    k = 0;
                    while(pParsedClk && pParsedClk->pParsedUnit[k] && !foundInTemp) {
                        //Check if have already added any signal from same unit and same group
                        //if so, assign those values to temp values so that we can check if
                        //we are using same group else return error.
                        //if (pParsedClk->pParsedUnit[k]->groupSelAddress == tempPerfUnitTable[j].pmGroupSelRegInfo.regOffset) {
                        if (pParsedClk->pParsedUnit[k]->unitId == tempPerfUnitTable[j].pmUnitId) {

                            tempSignalConfig->unitInfo[i] = (signalUnitConfig *) malloc(sizeof(signalUnitConfig));
                            if (!tempSignalConfig->unitInfo[i]) {
                                status = CUPROF_ERROR_OUT_OF_MEMORY;
                                goto EXIT;
                            }
                            //CU_ASSERT(pParsedClk->pParsedUnit[k]->unitId == tempPerfUnitTable[j].pmUnitId);
                            tempSignalConfig->unitInfo[i]->groupSelAddress = pParsedClk->pParsedUnit[k]->groupSelAddress;
                            tempSignalConfig->unitInfo[i]->groupSelMask = pParsedClk->pParsedUnit[k]->groupSelMask;
#if NVLINK_PM
                            tempSignalConfig->unitInfo[i]->groupSelValue = (pParsedClk->pParsedUnit[k]->groupSelValue) << 24 | (pParsedClk->pParsedUnit[k]->groupSelValue) << 16 | (pParsedClk->pParsedUnit[k]->groupSelValue) << 8 | pParsedClk->pParsedUnit[k]->groupSelValue;
#else
                            tempSignalConfig->unitInfo[i]->groupSelValue = pParsedClk->pParsedUnit[k]->groupSelValue;
#endif
                            tempSignalConfig->unitInfo[i]->unitId = pParsedClk->pParsedUnit[k]->unitId;
                            foundInParsedClk = 1;
                            break;
                        }
                        k++;
                    }
                }

                if (!foundInParsedClk && !foundInTemp) {
                    //This is a new unit
                    tempSignalConfig->unitInfo[i] = (signalUnitConfig *) malloc(sizeof(signalUnitConfig));
                    if (!tempSignalConfig->unitInfo[i]) {
                        status = CUPROF_ERROR_OUT_OF_MEMORY;
                        goto EXIT;
                    }
                    memset(tempSignalConfig->unitInfo[i], 0, sizeof(signalUnitConfig));
                    tempSignalConfig->unitInfo[i]->groupSelAddress = INVALID_ADDRESS;
                    tempSignalConfig->unitInfo[i]->unitId = unitId;
                }

                CHECK_AND_SET_GROUP_ADD(tempSignalConfig->unitInfo[i]->groupSelAddress, tempPerfUnitTable[j].pmGroupSelRegInfo.regOffset);
#if NVLINK_PM
                startBit = 0;
                endBit   = 31;
                //This macro should check if the group is already set, the value shgoudl be equal, if not return error.
                CHECK_AND_SET_GROUP_MASK_VAL(tempSignalConfig->unitInfo[i]->groupSelMask, tempSignalConfig->unitInfo[i]->groupSelValue, 31:0, ((eventGroup<<24)|(eventGroup<<16)|(eventGroup<<8)|(eventGroup)));
#else
                startBit = tempPerfUnitTable[j].pmGroupSelRegInfo.firstBit;
                endBit   = startBit + tempPerfUnitTable[j].pmGroupSelRegInfo.subFieldWidth - 1;
                //This macro should check if the group is already set, the value shgoudl be equal, if not return error.
                CHECK_AND_SET_GROUP_MASK_VAL(tempSignalConfig->unitInfo[i]->groupSelMask, tempSignalConfig->unitInfo[i]->groupSelValue, endBit:startBit, eventGroup);
#endif
    #if 0
                //TBD enable this part only of we can remove SetPMEnableReg.
                CU_ASSERT(tempSignalConfig->unitInfo[i]->groupSelAddress == tempPerfUnitTable[j].pPMEnableRegInfo->regOffset)
                    startBit = tempPerfUnitTable[j].pPMEnableRegInfo.firstBit;
                endBit   = startBit + tempPerfUnitTable[j].pPMEnableRegInfo.subFieldWidth - 1;
                CHECK_AND_SET_GROUP_MASK_VAL(tempSignalConfig->unitInfo[i]->groupSelMask, tempSignalConfig->unitInfo[i]->groupSelValue, endBit:startBit, 1);
    #endif
                tempSignalConfig->unitInfo[i]->pPerfUnitTable = &tempPerfUnitTable[j];
                break;
            }
            j++;
        }
    }
EXIT:
    return status;
}

static CUprofResult getExptConfig(CUeventGroup *pEventGroup, CUdomainData *pDomainData, CUeventDataHwpmExpt_v1 *pEventData,
                                  signalConfig *tempSignalConfig)
{
    CUeventDataHwpm *pEventdataTemp[7] = {NULL};
    CUeventInfo *pEventInfoTemp[7] = {NULL};
    CUeventInfo *pEventInfoIncr = NULL;
    NvU32 j = 0, numSignals = 0, validNumSignals = 0, k = 0, busWidthIncrSignal = 0, groupId = 0, watchbus = 0;
    CUprofResult status = CUPROF_SUCCESS;
    CUparsedClk *pParsedClk =  pEventGroup->arch.voltaEventGroup->pParsedClk;

    numSignals = 0;
    validNumSignals = 0;
    //TBD add support for 7 signal combination later
    //while((pEventData->signalId_combination[numSignals] != INVALID_PM_SIGNAL_NEW) && (numSignals < 4))
    while (numSignals < 4)
    {
        if (pEventData->signalId_combination[numSignals] != INVALID_PM_SIGNAL_NEW) {
            pEventInfoTemp[numSignals] = voltaLookupDomainSignalTable(pDomainData, pEventData->signalId_combination[numSignals]);
            if (pEventInfoTemp[numSignals])
            {
                pEventdataTemp[numSignals] = (CUeventDataHwpm*)pEventInfoTemp[numSignals]->pEventData;
                //CU_ASSERT(pEventdataTemp[numSignals]->pmUnitId == pEventData->pmUnitId); //For LTC this assert will not be valid, check for groupreg and mask instead.
                CU_ASSERT(pEventdataTemp[numSignals]->busWidth == 1);

                if ((pEventdataTemp[numSignals]->pmUnitId == PM_UNIT_NVTX) || (pEventdataTemp[numSignals]->pmUnitId == PM_UNIT_NVRX)) {
                    status = performUnitCompatibilityCheckNvlink(pParsedClk, pEventGroup->pCtx->device->state.pPerfUnitTable, tempSignalConfig, pEventdataTemp[numSignals], &groupId);
                    if (status != CUPROF_SUCCESS) {
                        numSignals++;
                        goto EXIT;
                    }
                    //for nvlink each group has 4 signals and the watchbus from 4 groups wil be mapped to watchbus from 0 to 15
                    tempSignalConfig->tempWatchbus[0] |= (((pEventdataTemp[numSignals]->watchBus + (groupId * 4)) & 0xff) << (numSignals * 8));
                }
                else {
                    status = performUnitCompatibilityCheck(pParsedClk, pEventGroup->pCtx->device->state.pPerfUnitTable, tempSignalConfig, pEventdataTemp[numSignals]);
                    if (status != CUPROF_SUCCESS) {
                        numSignals++;
                        goto EXIT;
                    }
                    tempSignalConfig->tempWatchbus[0] |= ((pEventdataTemp[numSignals]->watchBus & 0xff) << (numSignals * 8));
                }
                validNumSignals++;
            }
            else {
                status = CUPROF_ERROR_INVALID_EVENT_ID;
                numSignals++;
                goto EXIT;
            }
        }
        numSignals++;
    }
    if (pEventData->signalId_increment != INVALID_PM_SIGNAL_NEW) {
        pEventInfoIncr = voltaLookupDomainSignalTable(pDomainData, pEventData->signalId_increment);
        if (!pEventInfoIncr) {
            //Increment event not found
            status = CUPROF_ERROR_INVALID_EVENT_ID;
            goto EXIT;
        }
    }
    if ((validNumSignals == 0) && (pEventData->signalId_filter != INVALID_PM_SIGNAL_NEW) && (pEventInfoIncr)) {
       //The expt requires filtering only
       CUeventDataHwpm *eventDataIncr = (CUeventDataHwpm *)pEventInfoIncr->pEventData;
       tempSignalConfig->filterSignal = pEventData->signalId_filter;
       free(pEventInfoIncr);
       return getSigConfig(pEventGroup, pDomainData, eventDataIncr, tempSignalConfig);
    }

    if ((validNumSignals > 4) || (validNumSignals == 0)) {
        //Support upto 7 bit combination later
        //numSignals = 0 so we cannot call this a real expt,
        //in expt, it is assumed that the combination is valid
        CU_ASSERT(0);
        status = CUPROF_ERROR_NOT_COMPATIBLE;
        goto EXIT;
    }
    if (pEventData->signalId_increment != INVALID_PM_SIGNAL_NEW) {
        busWidthIncrSignal = ((CUeventDataHwpm*)pEventInfoIncr->pEventData)->busWidth;
        if (busWidthIncrSignal > 6) {
            //can't use signal > 6bit in expt
            CU_ASSERT(0);
            status = CUPROF_ERROR_NOT_COMPATIBLE;
            goto EXIT;
        }

        if ((validNumSignals > 2) && (busWidthIncrSignal > 4)) {
            //for signals > 4, the combination cannot be > 2 signals
            CU_ASSERT(0);
            status = CUPROF_ERROR_NOT_COMPATIBLE;
            goto EXIT;
        }

        if ((((CUeventDataHwpm *)pEventInfoIncr->pEventData)->pmUnitId == PM_UNIT_NVTX) || (((CUeventDataHwpm *)pEventInfoIncr->pEventData)->pmUnitId == PM_UNIT_NVRX)) {
            NvU32 groupId = 0;
            status = performUnitCompatibilityCheckNvlink(pParsedClk, pEventGroup->pCtx->device->state.pPerfUnitTable, tempSignalConfig, (CUeventDataHwpm*)pEventInfoIncr->pEventData, &groupId);
            if(status != CUPROF_SUCCESS) {
                goto EXIT;
            }
            //for nvlink each group has 4 signals and the watchbus from 4 groups wil be mapped to watchbus from 0 to 15
            watchbus = ((CUeventDataHwpm *)pEventInfoIncr->pEventData)->watchBus + (groupId * 4);
        }
        else {
            status = performUnitCompatibilityCheck(pParsedClk, pEventGroup->pCtx->device->state.pPerfUnitTable, tempSignalConfig, (CUeventDataHwpm*)pEventInfoIncr->pEventData);
            if(status != CUPROF_SUCCESS) {
                goto EXIT;
            }
            watchbus = ((CUeventDataHwpm *)pEventInfoIncr->pEventData)->watchBus;
        }

        //setup watchbus
        for (k = 0; k < 4; k++) {
            //Store watchbus for LSB 4 bits in tempWatchbus[0]
            if (k < busWidthIncrSignal)
                tempSignalConfig->tempWatchbus[1] |= (((watchbus & 0xff) + k) << (k * 8));
            else
                tempSignalConfig->tempWatchbus[1] |= (FALSE_WATCH_BUS_SIGNAL << (k * 8));
        }
        if (busWidthIncrSignal > 4) {
            for (k = 4; k < 6; k++) {
                //Store watchbus for most significant 2 bits in the lower bits of the tempWatchbus[1] for 2X2B6I
                if (k < busWidthIncrSignal)
                    tempSignalConfig->tempWatchbus[0] |= (((watchbus & 0xff) + k) << ((k - 4) * 8));
                else
                    //Add false signal to the vacant space.
                    tempSignalConfig->tempWatchbus[0] |= (FALSE_WATCH_BUS_SIGNAL << ((k - 4) * 8));
            }
        }
    }
    //If we reach here, the groups are compatible, set expected mode for this signal.
    if (tempSignalConfig->mode == 0) {
        //mode is not explicitly set, try to apply generic rules, this might not give optimal combinations
        if (busWidthIncrSignal == 0) {
            tempSignalConfig->mode = NV_PMM_CONTROL_ADDTOCTR_INCR; //incrment by 1 on a logical combination of 4 signals in the table.
        } 
        //No need to use NV_PMM_CONTROL_ADDTOCTR_EVENT4 in volta
        else if (busWidthIncrSignal <= 4) {
            tempSignalConfig->mode = NV_PMM_CONTROL_ADDTOCTR_2X4B4I;
        } else if (busWidthIncrSignal <= 6) {
            //tempSignalConfig->mode = NV_PMM_CONTROL_ADDTOCTR_EVENT6;
            //With 2X2B6I mode 2 signals with 6-bit increment and 2 bit-predicate are possible. So use this volta onwards.
            tempSignalConfig->mode = NV_PMM_CONTROL_ADDTOCTR_2X2B6I;
        }
    }

    tempSignalConfig->busWidth = busWidthIncrSignal;
    tempSignalConfig->function = pEventData->function;
    tempSignalConfig->filterSignal = pEventData->signalId_filter;
    tempSignalConfig->delaySelect = pEventData->dSel;

    // If increment mode is 4444 and increment signal is invalid. Then set the bus width to the number of valid signals
    if (pEventData->mode == NV_PMM_CONTROL_ADDTOCTR_4444 && pEventData->signalId_increment == INVALID_PM_SIGNAL_NEW) {
        tempSignalConfig->busWidth = validNumSignals;
        tempSignalConfig->mode = pEventData->mode;
    }

EXIT:
    for(j = 0; j < numSignals; j++) {
        free(pEventInfoTemp[j]);
    }
    free(pEventInfoIncr);
    return status;
}

static CUprofResult getSigConfig(CUeventGroup *pEventGroup, CUdomainData *pDomainData, PerfSignalHwpm *pEventData, signalConfig *tempSignalConfig)
{
    CUeventInfo *pEventInfo = NULL;
    NvU32 k = 0, busWidthIncrSignal = 0, busWidth = 0, watchbus = 0, groupId = 0;
    CUprofResult status = CUPROF_SUCCESS;
    CUparsedClk *pParsedClk =  pEventGroup->arch.voltaEventGroup->pParsedClk;

    pEventInfo = voltaLookupDomainSignalTable(pDomainData, pEventData->signalId);
    if (!pEventInfo) {
        //Increment event not found
        status = CUPROF_ERROR_INVALID_EVENT_ID;
        goto EXIT;
    }

    if (pEventData->busWidth > 14) {
        //can't use signal > 6bit in expt
        CU_ASSERT(0);
        status = CUPROF_ERROR_NOT_COMPATIBLE;
        goto EXIT;
    }

    if ((pEventData->pmUnitId == PM_UNIT_NVTX) || (pEventData->pmUnitId == PM_UNIT_NVRX)) {
        status = performUnitCompatibilityCheckNvlink(pParsedClk, pEventGroup->pCtx->device->state.pPerfUnitTable, tempSignalConfig, pEventData, &groupId);
        if(status != CUPROF_SUCCESS) {
            goto EXIT;
        }
        //for nvlink each group has 4 signals and the watchbus from 4 groups wil be mapped to watchbus from 0 to 15
        watchbus = pEventData->watchBus + (groupId * 4);
    }
    else {
        status = performUnitCompatibilityCheck(pParsedClk, pEventGroup->pCtx->device->state.pPerfUnitTable, tempSignalConfig, pEventData);
        if(status != CUPROF_SUCCESS)
            goto EXIT;
        watchbus = pEventData->watchBus;
    }
    if(status != CUPROF_SUCCESS)
        goto EXIT;

    //setup watchbus
    busWidth = 0;
    busWidthIncrSignal = pEventData->busWidth;

    if ((busWidthIncrSignal > 0) && (busWidthIncrSignal <= 14)) {
        //TBD write macros for below loops after debugging
        for (k = 0; k < 4; k++) {
            if (busWidth < busWidthIncrSignal) {
                tempSignalConfig->tempWatchbus[0] |= (((watchbus & 0xff) + k) << (k * 8));
                busWidth++;
            } else {
                //Add false signal in vacant space
                tempSignalConfig->tempWatchbus[0] |= ((FALSE_WATCH_BUS_SIGNAL) << (k * 8));
            }
        }
        for (k = 4; k < 8; k++) {
            if (busWidth < busWidthIncrSignal) {
                tempSignalConfig->tempWatchbus[1] |= (((watchbus & 0xff) + k) << ((k-4) * 8));
                busWidth++;
            } else {
                //Add false signal in vacant space
                tempSignalConfig->tempWatchbus[1] |= ((FALSE_WATCH_BUS_SIGNAL) << ((k-4) * 8));
            }
        }
        for (k = 8; k < 12; k++) {
            if (busWidth < busWidthIncrSignal) {
                tempSignalConfig->tempWatchbus[2] |= (((watchbus & 0xff) + k) << ((k-8) * 8));
                busWidth++;
            } else {
                tempSignalConfig->tempWatchbus[2] |= ((FALSE_WATCH_BUS_SIGNAL) << ((k-8) * 8));
            }
        }
        for (k = 12; k < 14; k++) {
            if (busWidth < busWidthIncrSignal) {
                tempSignalConfig->tempWatchbus[3] |= (((watchbus & 0xff) + k) << ((k-12) * 8));
                busWidth++;
            } else {
                tempSignalConfig->tempWatchbus[3] |= ((FALSE_WATCH_BUS_SIGNAL) << ((k-12) * 8));
            }
        }
    }

    tempSignalConfig->busWidth = busWidthIncrSignal;
    tempSignalConfig->function = pEventData->function;

    //If we reach here, the groups are compatible, set expected mode for this signal.
    if (tempSignalConfig->mode == 0) {
        //mode is not explicitly set, try to apply generic rules, this might not give optimal combinations
        if (busWidthIncrSignal == 1) {
            //Increment signals can be profiled along with experiments as well,
            //so use NV_PMM_CONTROL_ADDTOCTR_INCR here
            //It can be promoted to be used with the 2X4B4I and EVENT6 mode
            //It can also be promoted to 4444 mode
            tempSignalConfig->mode = NV_PMM_CONTROL_ADDTOCTR_INCR;
            //When in EVENT6 mode, watch bus is used from slot 1.
            tempSignalConfig->tempWatchbus[1] = tempSignalConfig->tempWatchbus[0];
        }
        else if ((busWidthIncrSignal > 1) && (busWidthIncrSignal <= 14)) {
            tempSignalConfig->mode = NV_PMM_CONTROL_ADDTOCTR_4444;
        } else {
            status = CUPROF_ERROR_NOT_COMPATIBLE;
            goto EXIT;
        }
    }

EXIT:
    free(pEventInfo);
    return status;

}
//*****************************************************************
// We can monitor up to four inc-by-1 experiments per domain in ModeB
// Each chiplet/PMM can be configured individually, so we have. 1x8 domains for sys + 4x1 gpcs + 4x2 gpctpcs
// + 6x2 fbps experiments that can run concurrently on gp100
static CUprofResult canSigBeProfiledModeB(CUeventGroup *pEventGroup, CUdomainData *pDomainData, CUeventInfo *pEventInfo, NvBool *added)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 i = 0, j = 0, k = 0;
    CUparsedClk  *pParsedClk = NULL;
    NvU32 eventSpec = 0, newMode = 0;
    signalConfig tempSignalConfig;

    CU_TRACE_FUNCTION();

    memset(&tempSignalConfig, 0, sizeof(signalConfig));

    pParsedClk = pEventGroup->arch.voltaEventGroup->pParsedClk;
    if(!pParsedClk) {
        return CUPROF_ERROR_UNKNOWN;
    }

    if (pParsedClk->totalHardwareCounters == 0) {
        pParsedClk->eventSpecUsed = 0;
        pParsedClk->mode = (NvU32) -1;
        for (i = 0; i < CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS; i++) {
            pParsedClk->watchBus[i] = 0xefefefef; //Assuming this is false signal TBD check if assumption is still correct.
            pParsedClk->function[i] = 0;          //Assuming this is false signal TBD check if assumption is still correct.
        }
    }

    if ((((CUeventDataHwpm*)pEventInfo->pEventData)->signalId == VOLTA_ELAPSED_CYCLES_SM) ||
            // Adding support for device level counters.
            (((CUeventDataHwpm*)pEventInfo->pEventData)->signalId == VOLTA_ELAPSED_CYCLES_SM_PM)||
            (((CUeventDataHwpm*)pEventInfo->pEventData)->signalId == VOLTA_ELAPSED_CYCLES_SYS0)|| 
            (((CUeventDataHwpm*)pEventInfo->pEventData)->signalId == VOLTA_ELAPSED_CYCLES_SYS1)) {
        if(pParsedClk->isElapsedClocksProfiled) {
            status = CUPROF_ERROR_NOT_COMPATIBLE;
            *added = NV_FALSE;
            return status;
        }
        pParsedClk->eventspec[pParsedClk->totalHardwareCounters] = NV_ELAPSED_CLOCKS;
        pParsedClk->isElapsedClocksProfiled = 1;
        pParsedClk->totalHardwareCounters++;
        *added = NV_TRUE;
        return status;
    }

    tempSignalConfig.filterSignal = INVALID_PM_SIGNAL_NEW;
    if (pParsedClk->eventSpecUsed == (NV_PMM_TRIG1 | NV_PMM_EVENT | NV_PMM_TRIG0 | NV_PMM_SAMPLE))
        return CUPROF_ERROR_MAX_LIMIT_REACHED;

    //HWPM Mux experiments are not supported now.
    if((pEventInfo->signalTableType == PERF_SIG_TABLE_TYPE_HWPM_EXPT) ||
       (pEventInfo->signalTableType == PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1)) {
        status = getExptConfig(pEventGroup, pDomainData, (CUeventDataHwpmExpt_v1 *)(pEventInfo->pEventData), &tempSignalConfig);
        if (status != CUPROF_SUCCESS)
            goto Failed;
    } else {
        status = getSigConfig(pEventGroup, pDomainData, (PerfSignalHwpm *)(pEventInfo->pEventData), &tempSignalConfig);
        if (status != CUPROF_SUCCESS)
            goto Failed;
    }

    //Setup the event mask and in vivel mode, set the partnumbers
    //TBD correctly return the error code if non_compatible or max_limit_reached
    status = getEventSpec(pParsedClk, &tempSignalConfig, &eventSpec, &newMode);
    if (status != CUPROF_SUCCESS)
        goto Failed;

    if (((tempSignalConfig.unitInfo[0]->unitId == PM_UNIT_SMCORE) ||
        (tempSignalConfig.unitInfo[0]->unitId == PM_UNIT_SMQCTL) ||
        (tempSignalConfig.unitInfo[0]->unitId == PM_UNIT_MIO)) &&
        (pEventInfo->signalTableType == PERF_SIG_TABLE_TYPE_HWPMMUX)){
        NvU32 maxSignals;
        NvBool added = 0;
        voltaPerfmonAddSMCounterEntryForHWPMMux(pEventGroup, pDomainData, pEventInfo, &added, &maxSignals);
        CU_ASSERT(added);
    }
    //No error, so add this signal in the parsedClk now
    j = 0;
    while(tempSignalConfig.unitInfo[j]) {
        k = 0;
        while(pParsedClk && pParsedClk->pParsedUnit[k]) {
            //Check if have already added any signal from same unit and same group
            //if so, assign those values to temp values so that we can check if
            //we are using same group else return error.
            //if (pParsedClk->pParsedUnit[k]->groupSelAddress == tempSignalConfig.unitInfo[j]->groupSelAddress) {
            if (pParsedClk->pParsedUnit[k]->unitId == tempSignalConfig.unitInfo[j]->unitId) {
                break;
            }
            k++;
        }

        if(!pParsedClk->pParsedUnit[k]) {
            CU_ASSERT(k < (CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS * MAX_SIGNALS_PER_EXPERIMENT));
            pParsedClk->pParsedUnit[k] = (CUparsedUnit*)malloc(sizeof(CUparsedUnit));
            if(!pParsedClk->pParsedUnit[k]) goto Failed;
            cuosMemset(pParsedClk->pParsedUnit[k], 0, sizeof(CUparsedUnit));
        }

        pParsedClk->pParsedUnit[k]->unitId = tempSignalConfig.unitInfo[j]->unitId;
        pParsedClk->pParsedUnit[k]->groupSelAddress = tempSignalConfig.unitInfo[j]->groupSelAddress;
        pParsedClk->pParsedUnit[k]->groupSelMask = tempSignalConfig.unitInfo[j]->groupSelMask;
        pParsedClk->pParsedUnit[k]->groupSelValue = tempSignalConfig.unitInfo[j]->groupSelValue;

        pParsedClk->pParsedUnit[k]->pPerfUnitTable = tempSignalConfig.unitInfo[j]->pPerfUnitTable;
        j++;
    }

    pParsedClk->mode = newMode;
    pParsedClk->eventspec[pParsedClk->totalHardwareCounters] = eventSpec;
    pParsedClk->eventSpecUsed |= eventSpec;
    pParsedClk->width[pParsedClk->totalHardwareCounters] = tempSignalConfig.busWidth;
    pParsedClk->partNumber[pParsedClk->totalHardwareCounters] = tempSignalConfig.partNumber;

    if(eventSpec & NV_PMM_TRIG0) {
        pParsedClk->watchBus[NV_PMM_TRIG0_BIT_POS] = tempSignalConfig.watchBus[NV_PMM_TRIG0_BIT_POS];
        pParsedClk->function[NV_PMM_TRIG0_BIT_POS] = tempSignalConfig.function;
        pParsedClk->delaySelects[NV_PMM_TRIG0_BIT_POS] = tempSignalConfig.delaySelect;
        if (tempSignalConfig.filterSignal != INVALID_PM_SIGNAL_NEW) {
            pParsedClk->filterConfig = DRF_REPLACE(pParsedClk->filterConfig, tempSignalConfig.filterSignal, NV_PERF_PMMSYS_CONTROLC_FILTERMAP_TRIG0);
            pParsedClk->filterConfig = DRF_REPLACE(pParsedClk->filterConfig, NV_PERF_PMMSYS_CONTROLC_FILTER_TRIG0_ENABLE, NV_PERF_PMMSYS_CONTROLC_FILTER_TRIG0);
        }
        else {
            pParsedClk->filterConfig = DRF_REPLACE(pParsedClk->filterConfig, NV_PERF_PMMSYS_CONTROLC_FILTER_TRIG0_DISABLE, NV_PERF_PMMSYS_CONTROLC_FILTER_TRIG0);
        }
    }
    if(eventSpec & NV_PMM_TRIG1) {
        pParsedClk->watchBus[NV_PMM_TRIG1_BIT_POS] = tempSignalConfig.watchBus[NV_PMM_TRIG1_BIT_POS];
        pParsedClk->function[NV_PMM_TRIG1_BIT_POS] = tempSignalConfig.function;
        pParsedClk->delaySelects[NV_PMM_TRIG1_BIT_POS] = tempSignalConfig.delaySelect;
        if (tempSignalConfig.filterSignal != INVALID_PM_SIGNAL_NEW) {
            pParsedClk->filterConfig = DRF_REPLACE(pParsedClk->filterConfig, tempSignalConfig.filterSignal, NV_PERF_PMMSYS_CONTROLC_FILTERMAP_TRIG1);
            pParsedClk->filterConfig = DRF_REPLACE(pParsedClk->filterConfig, NV_PERF_PMMSYS_CONTROLC_FILTER_TRIG1_ENABLE, NV_PERF_PMMSYS_CONTROLC_FILTER_TRIG1);
        }
        else {
            pParsedClk->filterConfig = DRF_REPLACE(pParsedClk->filterConfig, NV_PERF_PMMSYS_CONTROLC_FILTER_TRIG1_DISABLE, NV_PERF_PMMSYS_CONTROLC_FILTER_TRIG1);
        }
    }
    if(eventSpec & NV_PMM_SAMPLE) {
        pParsedClk->watchBus[NV_PMM_SAMPLE_BIT_POS] = tempSignalConfig.watchBus[NV_PMM_SAMPLE_BIT_POS];
        pParsedClk->function[NV_PMM_SAMPLE_BIT_POS] = tempSignalConfig.function;
        pParsedClk->delaySelects[NV_PMM_SAMPLE_BIT_POS] = tempSignalConfig.delaySelect;
        if (tempSignalConfig.filterSignal != INVALID_PM_SIGNAL_NEW) {
            pParsedClk->filterConfig = DRF_REPLACE(pParsedClk->filterConfig, tempSignalConfig.filterSignal, NV_PERF_PMMSYS_CONTROLC_FILTERMAP_SAMPLE);
            pParsedClk->filterConfig = DRF_REPLACE(pParsedClk->filterConfig, NV_PERF_PMMSYS_CONTROLC_FILTER_SAMPLE_ENABLE, NV_PERF_PMMSYS_CONTROLC_FILTER_SAMPLE);
        }
        else {
            pParsedClk->filterConfig = DRF_REPLACE(pParsedClk->filterConfig, NV_PERF_PMMSYS_CONTROLC_FILTER_SAMPLE_DISABLE, NV_PERF_PMMSYS_CONTROLC_FILTER_SAMPLE);
        }
    }
    if(eventSpec & NV_PMM_EVENT) {
        pParsedClk->watchBus[NV_PMM_EVENT_BIT_POS] = tempSignalConfig.watchBus[NV_PMM_EVENT_BIT_POS];
        pParsedClk->function[NV_PMM_EVENT_BIT_POS] = tempSignalConfig.function;
        pParsedClk->delaySelects[NV_PMM_EVENT_BIT_POS] = tempSignalConfig.delaySelect;
        if (tempSignalConfig.filterSignal != INVALID_PM_SIGNAL_NEW) {
            pParsedClk->filterConfig = DRF_REPLACE(pParsedClk->filterConfig, tempSignalConfig.filterSignal, NV_PERF_PMMSYS_CONTROLC_FILTERMAP_EVENT);
            pParsedClk->filterConfig = DRF_REPLACE(pParsedClk->filterConfig, NV_PERF_PMMSYS_CONTROLC_FILTER_EVENT_ENABLE, NV_PERF_PMMSYS_CONTROLC_FILTER_EVENT);
        }
        else {
            pParsedClk->filterConfig = DRF_REPLACE(pParsedClk->filterConfig, NV_PERF_PMMSYS_CONTROLC_FILTER_EVENT_DISABLE, NV_PERF_PMMSYS_CONTROLC_FILTER_EVENT);
        }
    }

    if ((tempSignalConfig.mode != NV_PMM_CONTROL_ADDTOCTR_INCR) && (tempSignalConfig.mode != NV_PMM_CONTROL_ADDTOCTR_4444)) {
        if ((tempSignalConfig.mode == NV_PMM_CONTROL_ADDTOCTR_EVENT4) || (tempSignalConfig.mode == NV_PMM_CONTROL_ADDTOCTR_EVENT6)) {
            pParsedClk->function[NV_PMM_EVENT_BIT_POS] = tempSignalConfig.function;
            pParsedClk->function[NV_PMM_TRIG1_BIT_POS] = 0xffff;
        } else if ((tempSignalConfig.mode == NV_PMM_CONTROL_ADDTOCTR_TRIG4 || tempSignalConfig.mode == NV_PMM_CONTROL_ADDTOCTR_TRIG6)) {
            pParsedClk->function[NV_PMM_EVENT_BIT_POS] = 0xffff;
            pParsedClk->function[NV_PMM_TRIG1_BIT_POS] = 0xffff;
        } else if ((tempSignalConfig.mode == NV_PMM_CONTROL_ADDTOCTR_2X4B4I) || (tempSignalConfig.mode == NV_PMM_CONTROL_ADDTOCTR_2X2B6I)) {
            pParsedClk->function[NV_PMM_EVENT_BIT_POS] = 0xffff;
            pParsedClk->function[NV_PMM_TRIG0_BIT_POS] = 0xffff;
        }
    }

    *added = NV_TRUE;
    pParsedClk->totalHardwareCounters++;
    return status;

Failed:
    j = 0;
    while(tempSignalConfig.unitInfo[j]) {
        free(tempSignalConfig.unitInfo[j]);
        ++j;
    }

    return status;
}

//TBD get rid of following function. Search if we can use any domain id
static NvU32 getClkIdx(const CUctx *ctx, CUeventDomainID domainId, NvU32 chipletType)
{
    NvU32 clkIdx;
    NvU32 const (*domainIds)[VOLTA_PM_MAX_DOMAIN_PER_CHIPLET] = NULL;

    // GV100 domain Ids
#if NVCFG(GLOBAL_ARCH_VOLTA)
    static const NvU32 gv100_domainIds[VOLTA_PM_MAX_CHIPLET_TYPES][VOLTA_PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        // sys chiplet
        {VOLTA_CLK_DOMAIN_GV100_HOST0, VOLTA_CLK_DOMAIN_GV100_LMSD0, VOLTA_CLK_DOMAIN_GV100_LSYS0, VOLTA_CLK_DOMAIN_GV100_LXBAR0, VOLTA_CLK_DOMAIN_GV100_MSD0, 
         VOLTA_CLK_DOMAIN_GV100_NVLRX0, VOLTA_CLK_DOMAIN_GV100_NVLRX1, VOLTA_CLK_DOMAIN_GV100_NVLRX2, VOLTA_CLK_DOMAIN_GV100_NVLRX3, VOLTA_CLK_DOMAIN_GV100_NVLRX4, VOLTA_CLK_DOMAIN_GV100_NVLRX5,
         VOLTA_CLK_DOMAIN_GV100_NVLTX0, VOLTA_CLK_DOMAIN_GV100_NVLTX1, VOLTA_CLK_DOMAIN_GV100_NVLTX2, VOLTA_CLK_DOMAIN_GV100_NVLTX3, VOLTA_CLK_DOMAIN_GV100_NVLTX4, VOLTA_CLK_DOMAIN_GV100_NVLTX5,
         VOLTA_CLK_DOMAIN_GV100_PCIE0, VOLTA_CLK_DOMAIN_GV100_PWR0, VOLTA_CLK_DOMAIN_GV100_SYS0, VOLTA_CLK_DOMAIN_GV100_SYS1, VOLTA_CLK_DOMAIN_GV100_XBAR0},

        // gpc chiplet
        //TBD : Returning same value for gpctpc0 and gpctpc1 domains.
        //The base values of pmmaddress are adjusted accordingly.
        {VOLTA_CLK_DOMAIN_GV100_GPC0, VOLTA_CLK_DOMAIN_GV100_GPC1, VOLTA_CLK_DOMAIN_GV100_GPCTPC},

        // fbp chiplet
        {VOLTA_CLK_DOMAIN_GV100_FBP0, VOLTA_CLK_DOMAIN_GV100_FBP1, VOLTA_CLK_DOMAIN_GV100_LTC0, VOLTA_CLK_DOMAIN_GV100_LTC1, VOLTA_CLK_DOMAIN_GV100_LTC2, VOLTA_CLK_DOMAIN_GV100_LTC3, VOLTA_CLK_DOMAIN_GV100_ROP0, VOLTA_CLK_DOMAIN_GV100_ROP1}
    };
#if NVCFG(GLOBAL_CHIP_T194) || NVCFG(GLOBAL_GPU_IMPL_GV11B)
    static const NvU32 gv11b_domainIds[VOLTA_PM_MAX_CHIPLET_TYPES][VOLTA_PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        // sys chiplet
        { VOLTA_CLK_DOMAIN_GV11B_ACB0, VOLTA_CLK_DOMAIN_GV11B_MC0, VOLTA_CLK_DOMAIN_GV100_PWR0, VOLTA_CLK_DOMAIN_GV11B_SYS0, VOLTA_CLK_DOMAIN_GV11B_SYS1, VOLTA_CLK_DOMAIN_GV100_XBAR0 },

        // gpc chiplet
        //TBD : Returning same value for gpctpc0 and gpctpc1 domains.
        //The base values of pmmaddress are adjusted accordingly.
        { VOLTA_CLK_DOMAIN_GV11B_GPC0, VOLTA_CLK_DOMAIN_GV11B_GPC1, VOLTA_CLK_DOMAIN_GV11B_GPCTPC },

        // fbp chiplet
        { VOLTA_CLK_DOMAIN_GV100_FBP0, VOLTA_CLK_DOMAIN_GV11B_LTC0, VOLTA_CLK_DOMAIN_GV11B_LTC1, VOLTA_CLK_DOMAIN_GV100_ROP0, VOLTA_CLK_DOMAIN_GV100_ROP1 }
    };
#endif
#endif
    CU_TRACE_FUNCTION();

    if (chipletType >= VOLTA_PM_MAX_CHIPLET_TYPES) {
        CU_ERROR_PRINT(("Invalid chiplet values\n"));
        CU_ASSERT (0);
        return VOLTA_PM_MAX_DOMAIN_PER_CHIPLET;
    }

    if (domainId == VOLTA_CLK_DOMAIN_GV100_HWPMMUX) {
        //Hack hack hack
        //VOLTA_CLK_DOMAIN_GV100_HWPMMUX will be a dummy id that is used to identify the HWPM signals profiled via SMPC.
        //We require this so that we can restrict profiling these signals with pure HWPM or pure SMPC signals
        //Currently there is no way to avoid this except having check at domain level, also it is possible that we will allow pure HWPM signals with pure SMPC.
        //Internally this domain id will be mapped to VOLTA_CLK_DOMAIN_GV100_GPCTPC
        domainId = VOLTA_CLK_DOMAIN_GV100_GPCTPC;
    }

#if NVCFG(GLOBAL_CHIP_T194) || NVCFG(GLOBAL_GPU_IMPL_GV11B)
    if (domainId == VOLTA_CLK_DOMAIN_GV11B_HWPMMUX) {
        //Hack hack hack
        //VOLTA_CLK_DOMAIN_GV11B_HWPMMUX will be a dummy id that is used to identify the HWPM signals profiled via SMPC.
        //We require this so that we can restrict profiling these signals with pure HWPM or pure SMPC signals
        //Currently there is no way to avoid this except having check at domain level, also it is possible that we will allow pure HWPM signals with pure SMPC.
        //Internally this domain id will be mapped to VOLTA_CLK_DOMAIN_GV11B_GPCTPC
        domainId = VOLTA_CLK_DOMAIN_GV11B_GPCTPC;
    }
#endif

    switch(ctx->device->state.chip) {
#if NVCFG(GLOBAL_ARCH_VOLTA)
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GV100):
        domainIds = gv100_domainIds;
        break;
#if NVCFG(GLOBAL_CHIP_T194) || NVCFG(GLOBAL_GPU_IMPL_GV11B)
    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GV11B) :
        domainIds = gv11b_domainIds;
        break;
#endif
#endif //NVCFG(GLOBAL_ARCH_VOLTA)
    default:
        CU_ASSERT(0);
        return (NvU32)-1;
        break;
    }

    for(clkIdx=0; clkIdx<(NvU32)VOLTA_PM_MAX_DOMAIN_PER_CHIPLET; clkIdx++)
    {
        if(domainIds[chipletType][clkIdx] == domainId)
            return clkIdx;
    }
    CU_ASSERT(clkIdx != VOLTA_PM_MAX_DOMAIN_PER_CHIPLET);

    CU_ASSERT(0);
    return VOLTA_PM_MAX_DOMAIN_PER_CHIPLET;
}

static CUprofResult enableFilterSignal(CUctx *ctx, NvU32 enableSlot, NvU32 *value)
{
    /***********************************************************************************
      31:28 - Enable bits to indicate for which counter slot to apply the filter signal
    ************************************************************************************/
    switch(enableSlot)
    {
    case 0:
        *value = DRF_REPLACE(*value, NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_FILTER0_CONTROL_ENABLE0_ENABLE, NV_PGRAPH_PRI_EGPC0_ETPC0_SM_DSM_PERF_COUNTER_FILTER0_CONTROL_ENABLE0);
        break;
    case 1:
        *value = DRF_REPLACE(*value, NV_PGRAPH_PRI_EGPC0_ETPC0_SM_DSM_PERF_COUNTER_FILTER0_CONTROL_ENABLE1_ENABLE, NV_PGRAPH_PRI_EGPC0_ETPC0_SM_DSM_PERF_COUNTER_FILTER0_CONTROL_ENABLE1);
        break;
    case 2:
        *value = DRF_REPLACE(*value, NV_PGRAPH_PRI_EGPC0_ETPC0_SM_DSM_PERF_COUNTER_FILTER0_CONTROL_ENABLE2_ENABLE, NV_PGRAPH_PRI_EGPC0_ETPC0_SM_DSM_PERF_COUNTER_FILTER0_CONTROL_ENABLE2);
        break;
    case 3:
        *value = DRF_REPLACE(*value, NV_PGRAPH_PRI_EGPC0_ETPC0_SM_DSM_PERF_COUNTER_FILTER0_CONTROL_ENABLE3_ENABLE, NV_PGRAPH_PRI_EGPC0_ETPC0_SM_DSM_PERF_COUNTER_FILTER0_CONTROL_ENABLE3);
        break;
    default:
        return CUPROF_ERROR_UNKNOWN;
    }
    return CUPROF_SUCCESS;
}

static uint32_t getProfilerObject(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    CUprofDeviceState *profDevState;
    uint32_t profilerObj = 0;

    profDevState = &pEventGroup->pCtx->device->state.profilerState;
    if(profDevState->profilerObj == 0) {
        status = (CUprofResult)pEventGroup->pCtx->device->dmal.deviceAllocProfilerClass(pEventGroup->pCtx->device, NULL, &profDevState->profilerObj, CU_PROFILER_CLASS_SCOPE_GLOBAL);
        if(status == CUPROF_SUCCESS) {
            profilerObj = profDevState->profilerObj;
            profDevState->pCtx = pEventGroup->pCtx;
        }
        else {
            profilerObj = 0;
        }
    }
    else {
        profilerObj = profDevState->profilerObj;
    }
    return profilerObj;
}

static CUprofResult readCountersNvlinkTc(CUeventGroup *pEventGroup)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUvoltaEventGroup *voltaEventGroup = NULL;
    NvU32 count = 0, count1 = 0;
    NvU32 index = 0, idx = 0, numCountersTxAdded = 0, numCountersRxAdded = 0, nvlinkId = 0, overflow = 0;

    uint64_t valueLo = 0, valueHi = 0, newValue = 0;
    NvU32 *offset = NULL, *value = NULL, *value1 = NULL, *offset1 = NULL;

    CU_TRACE_FUNCTION();

    voltaEventGroup = pEventGroup->arch.voltaEventGroup;

#if ENABLE_UNICAST_NVLINK
    value   = (NvU32 *) calloc(2 * NVLINK_MAX_LINKS, sizeof(NvU32));
    offset  = (NvU32 *) malloc(2 * NVLINK_MAX_LINKS * sizeof(NvU32));
#else
    value   = (NvU32 *) calloc(2, sizeof(NvU32));
    offset  = (NvU32 *) malloc(2 * sizeof(NvU32));
#endif

    value1  = (NvU32 *) calloc(2 * NVLINK_MAX_LINKS * voltaEventGroup->nvLinkTCConfig->nvlinkCountersAdded, sizeof(NvU32));
    offset1 = (NvU32 *) malloc(2 * NVLINK_MAX_LINKS * voltaEventGroup->nvLinkTCConfig->nvlinkCountersAdded * sizeof(NvU32));

    if((value == NULL) || (offset == NULL) || (value1 == NULL) || (offset1 == NULL)) {
        status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

#if ENABLE_UNICAST_NVLINK
    for (nvlinkId = 0; nvlinkId < NVLINK_MAX_LINKS; nvlinkId++) {
        offset[count]   = NV_PNVLTLC_TX0_DEBUG_TP_CNTR_CTRL + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;

        value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_TX0_DEBUG_TP_CNTR_CTRL_ENTX0);
        value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_TX0_DEBUG_TP_CNTR_CTRL_ENTX1);

        value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_TX0_DEBUG_TP_CNTR_CTRL_RESETTX0);
        value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_TX0_DEBUG_TP_CNTR_CTRL_RESETTX1);

        value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_TX0_DEBUG_TP_CNTR_CTRL_CAPTURE0);
        value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_TX0_DEBUG_TP_CNTR_CTRL_CAPTURE1);
        count++;

        offset[count]   = NV_PNVLTLC_RX0_DEBUG_TP_CNTR_CTRL + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;

        value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_RX0_DEBUG_TP_CNTR_CTRL_ENRX0);
        value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_RX0_DEBUG_TP_CNTR_CTRL_ENRX1);

        value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_RX0_DEBUG_TP_CNTR_CTRL_RESETRX0);
        value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_RX0_DEBUG_TP_CNTR_CTRL_RESETRX1);

        value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_RX0_DEBUG_TP_CNTR_CTRL_CAPTURE0);
        value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_RX0_DEBUG_TP_CNTR_CTRL_CAPTURE1);
        count++;
    }
#else
    offset[count]   = NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR_CTRL;

    value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR_CTRL_ENTX0);
    value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR_CTRL_ENTX1);

    value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR_CTRL_RESETTX0);
    value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR_CTRL_RESETTX1);

    value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR_CTRL_CAPTURE0);
    value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR_CTRL_CAPTURE1);
    count++;

    offset[count]   = NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR_CTRL;

    value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR_CTRL_ENRX0);
    value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR_CTRL_ENRX1);

    value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR_CTRL_RESETRX0);
    value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR_CTRL_RESETRX1);

    value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR_CTRL_CAPTURE0);
    value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR_CTRL_CAPTURE1);
    count++;
#endif

    for (nvlinkId = 0; nvlinkId < NVLINK_MAX_LINKS; nvlinkId++) {
        numCountersTxAdded = 0;
        numCountersRxAdded = 0;

        for (index = 0; index < voltaEventGroup->nvLinkTCConfig->nvlinkCountersAdded; index++) {
            if (voltaEventGroup->nvLinkTCConfig->pEventData[index]->direction == CUPROF_NVLINK_DATA_TRANSMIT) {
                switch(numCountersTxAdded) {
                    case 0:
                        offset1[count1++]   = NV_PNVLTLC_TX0_DEBUG_TP_CNTR0_CAPTURE_LO + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                        offset1[count1++]   = NV_PNVLTLC_TX0_DEBUG_TP_CNTR0_CAPTURE_HI + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                        break;

                    case 1:
                        offset1[count1++]   = NV_PNVLTLC_TX0_DEBUG_TP_CNTR1_CAPTURE_LO + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                        offset1[count1++]   = NV_PNVLTLC_TX0_DEBUG_TP_CNTR1_CAPTURE_HI + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                        break;
                }
                numCountersTxAdded++;
            }
            else {
                switch(numCountersRxAdded) {
                    case 0:
                        offset1[count1++]   = NV_PNVLTLC_RX0_DEBUG_TP_CNTR0_CAPTURE_LO + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                        offset1[count1++]   = NV_PNVLTLC_RX0_DEBUG_TP_CNTR0_CAPTURE_HI + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                        break;

                    case 1:
                        offset1[count1++]   = NV_PNVLTLC_RX0_DEBUG_TP_CNTR1_CAPTURE_LO + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                        offset1[count1++]   = NV_PNVLTLC_RX0_DEBUG_TP_CNTR1_CAPTURE_HI + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                        break;
                }
                numCountersRxAdded++;
            }
        }
    }

    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, count, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
    }

    if (CUDA_SUCCESS != PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, count1, offset1, value1, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

    // Check for overflow status
    for (nvlinkId = 0; nvlinkId < NVLINK_MAX_LINKS; nvlinkId++)
    {
        for (index = 0; index < voltaEventGroup->nvLinkTCConfig->nvlinkCountersAdded; index++)
        {
            overflow    = GETVAL(value1[(((nvlinkId * voltaEventGroup->nvLinkTCConfig->nvlinkCountersAdded) + index) * 2) + 1], NV_PNVLTLC_TX0_DEBUG_TP_CNTR0_HI_ROLLOVER);

            // __WAR__ Bug 200306548: Update NVLink TC read APIs to handle badf values in the absence of NVLink in the system.
            if (value1[(((nvlinkId * voltaEventGroup->nvLinkTCConfig->nvlinkCountersAdded) + index) * 2) + 0] >> 16 == 0xbadf) {
                continue;
            }

            if (value1[(((nvlinkId * voltaEventGroup->nvLinkTCConfig->nvlinkCountersAdded) + index) * 2) + 1] >> 16 == 0xbadf) {
                continue;
            }

            valueLo     = value1[(((nvlinkId * voltaEventGroup->nvLinkTCConfig->nvlinkCountersAdded) + index) * 2) + 0];
            valueHi     = value1[(((nvlinkId * voltaEventGroup->nvLinkTCConfig->nvlinkCountersAdded) + index) * 2) + 1];
            newValue    = (valueLo | (valueHi << 32));

            pEventGroup->values[(nvlinkId * voltaEventGroup->nvLinkTCConfig->nvlinkCountersAdded) + index] = overflow ? COUNTER_MAX64BIT : newValue;
        }
    }

EXIT:
    free(value1);
    free(value);
    free(offset1);
    free(offset);
    return status;
}

static CUprofResult setNvlinkEnableRegTC(CUeventGroup *pEventGroup, NvBool bEnable)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 count = 0, *value = NULL, *offset = NULL;
#if ENABLE_UNICAST_NVLINK
    NvU32 nvlinkId = 0;
#endif

    CU_TRACE_FUNCTION();

#if ENABLE_UNICAST_NVLINK
    value   = (NvU32 *)calloc(2 * NVLINK_MAX_LINKS, sizeof(NvU32));
    offset  = (NvU32 *)malloc(2 * NVLINK_MAX_LINKS * sizeof(NvU32));
#else
    value   = (NvU32 *)calloc(2, sizeof(NvU32));
    offset  = (NvU32 *)malloc(2 * sizeof(NvU32));
#endif

    if((value == NULL) || (offset == NULL)) {
        status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

#if ENABLE_UNICAST_NVLINK
    for (nvlinkId = 0; nvlinkId < NVLINK_MAX_LINKS; nvlinkId++) {
        offset[count]       = NV_PNVLTLC_TX0_DEBUG_TP_CNTR_CTRL + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
        // For register access optimization, reset NVLink TC only while enabling them, i.e bEnable = 1.
        if (bEnable) {
            value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_TX0_DEBUG_TP_CNTR_CTRL_RESETTX0);
            value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_TX0_DEBUG_TP_CNTR_CTRL_RESETTX1);
        }

        value[count]        = DRF_REPLACE(value[count], bEnable, NV_PNVLTLC_TX0_DEBUG_TP_CNTR_CTRL_ENTX0);
        value[count]        = DRF_REPLACE(value[count], bEnable, NV_PNVLTLC_TX0_DEBUG_TP_CNTR_CTRL_ENTX1);
        count++;

        offset[count]       = NV_PNVLTLC_RX0_DEBUG_TP_CNTR_CTRL + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
        if (bEnable) {
            value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_RX0_DEBUG_TP_CNTR_CTRL_RESETRX0);
            value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_RX0_DEBUG_TP_CNTR_CTRL_RESETRX1);
        }

        value[count]        = DRF_REPLACE(value[count], bEnable, NV_PNVLTLC_RX0_DEBUG_TP_CNTR_CTRL_ENRX0);
        value[count]        = DRF_REPLACE(value[count], bEnable, NV_PNVLTLC_RX0_DEBUG_TP_CNTR_CTRL_ENRX1);
        count++;
    }
#else
    offset[count]       = NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR_CTRL;
    // For register access optimization, reset NVLink TC only while enabling them, i.e bEnable = 1.
    if (bEnable) {
        value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR_CTRL_RESETTX0);
        value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR_CTRL_RESETTX1);
    }

    value[count]        = DRF_REPLACE(value[count], bEnable, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR_CTRL_ENTX0);
    value[count]        = DRF_REPLACE(value[count], bEnable, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR_CTRL_ENTX1);
    count++;

    offset[count]       = NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR_CTRL;
    if (bEnable) {
        value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR_CTRL_RESETRX0);
        value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR_CTRL_RESETRX1);
    }

    value[count]        = DRF_REPLACE(value[count], bEnable, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR_CTRL_ENRX0);
    value[count]        = DRF_REPLACE(value[count], bEnable, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR_CTRL_ENRX1);
    count++;
#endif

    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, count, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
    }

EXIT:
    free(value);
    free(offset);
    return status;
}

static CUprofResult resetNvlinkCountersTC(CUeventGroup *pEventGroup)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 count = 0, *value = NULL, *offset = NULL;
#if ENABLE_UNICAST_NVLINK
    NvU32 nvlinkId = 0;
#endif
    CU_TRACE_FUNCTION();

#if ENABLE_UNICAST_NVLINK
    value   = (NvU32 *)calloc(2 * NVLINK_MAX_LINKS, sizeof(NvU32));
    offset  = (NvU32 *)malloc(2 * NVLINK_MAX_LINKS * sizeof(NvU32));
#else
    value   = (NvU32 *)calloc(2, sizeof(NvU32));
    offset  = (NvU32 *)malloc(2 * sizeof(NvU32));
#endif

    if((value == NULL) || (offset == NULL)) {
        status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

#if ENABLE_UNICAST_NVLINK
    for (nvlinkId = 0; nvlinkId < NVLINK_MAX_LINKS; nvlinkId++) {
        offset[count]   = NV_PNVLTLC_TX0_DEBUG_TP_CNTR_CTRL + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
        value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_TX0_DEBUG_TP_CNTR_CTRL_RESETTX0);
        value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_TX0_DEBUG_TP_CNTR_CTRL_RESETTX1);
        count++;

        offset[count]   = NV_PNVLTLC_RX0_DEBUG_TP_CNTR_CTRL + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
        value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_RX0_DEBUG_TP_CNTR_CTRL_RESETRX0);
        value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_RX0_DEBUG_TP_CNTR_CTRL_RESETRX1);
        count++;
    }
#else
    offset[count]   = NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR_CTRL;
    value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR_CTRL_RESETTX0);
    value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR_CTRL_RESETTX1);
    count++;

    offset[count]   = NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR_CTRL;
    value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR_CTRL_RESETRX0);
    value[count]    = DRF_REPLACE(value[count], 1, NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR_CTRL_RESETRX1);
    count++;
#endif

    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, count, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
    }

EXIT:
    free(value);
    free(offset);
    return status;
}

static CUprofResult reserveReleaseNvlinkCounters(CUeventGroup *pEventGroup, NvBool bAcquire) {
    CUprofResult status = CUPROF_SUCCESS;
    uint32_t profilerObj;
    CUprofDeviceState *profDevState;

    profDevState = &pEventGroup->pCtx->device->state.profilerState;

    if(bAcquire) {
        if(profDevState->pCtx == NULL) {
            profilerObj = getProfilerObject(pEventGroup);
            
            if(profilerObj == 0) {
                status = CUPROF_ERROR_NOT_COMPATIBLE;
                return status;
            }

            profDevState->pCtx = pEventGroup->pCtx;
            profDevState->refCount = 1;
            status = (CUprofResult)pEventGroup->pCtx->device->dmal.deviceReserveReleaseNvlinkCounter(pEventGroup->pCtx->device, profilerObj, bAcquire);
        }
        else if(profDevState->pCtx == pEventGroup->pCtx) {
            ++(profDevState->refCount);
        }
        else {
            status = CUPROF_ERROR_NOT_COMPATIBLE;
        }
    }
    else {
        if(profDevState->profilerObj != 0) {
            profilerObj = profDevState->profilerObj;
            if(profDevState->refCount > 0) {
                --(profDevState->refCount);
                if (profDevState->refCount == 0) {
                    status = (CUprofResult)pEventGroup->pCtx->device->dmal.deviceReserveReleaseNvlinkCounter(pEventGroup->pCtx->device, profilerObj, bAcquire);
                    profDevState->profilerObj = 0;
                    profDevState->pCtx = NULL;
                }
            }
            else {
                status = CUPROF_ERROR_NOT_COMPATIBLE;
            }
        }
        else {
            status = CUPROF_ERROR_NOT_COMPATIBLE;
        }
    }

    return status;
}

static CUprofResult setupNvlinkEnableConfigRegTC(CUeventGroup *pEventGroup)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUvoltaEventGroup *voltaEventGroup = NULL;
    NvU32 index = 0, *value = NULL, *offset = NULL;
    NvU32 numCountersTxAdded = 0, numCountersRxAdded = 0, count = 0;

#if ENABLE_UNICAST_NVLINK
    NvU32 nvlinkId = 0;
#endif

    CU_TRACE_FUNCTION();
    voltaEventGroup = pEventGroup->arch.voltaEventGroup;

#if ENABLE_UNICAST_NVLINK
    value   = (NvU32 *)calloc(5 * NVLINK_MAX_LINKS * voltaEventGroup->nvLinkTCConfig->nvlinkCountersAdded, sizeof(NvU32));
    offset  = (NvU32 *)malloc(5 * NVLINK_MAX_LINKS * voltaEventGroup->nvLinkTCConfig->nvlinkCountersAdded * sizeof(NvU32));
#else
    value   = (NvU32 *)calloc(6 * voltaEventGroup->nvLinkTCConfig->nvlinkCountersAdded, sizeof(NvU32));
    offset  = (NvU32 *)malloc(6 * voltaEventGroup->nvLinkTCConfig->nvlinkCountersAdded * sizeof(NvU32));
#endif

    if((value == NULL) || (offset == NULL)) {
        status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

#if ENABLE_UNICAST_NVLINK
    for (nvlinkId = 0; nvlinkId < NVLINK_MAX_LINKS; nvlinkId++) {
        numCountersTxAdded = 0;
        numCountersRxAdded = 0;
        for (index = 0; index < voltaEventGroup->nvLinkTCConfig->nvlinkCountersAdded; index++)
        {
            if (voltaEventGroup->nvLinkTCConfig->pEventData[index]->direction == CUPROF_NVLINK_DATA_TRANSMIT)
            {
                switch(numCountersTxAdded)
                {
                case 0:
                    offset[count]   = NV_PNVLTLC_TX0_DEBUG_TP_CNTR0_CTRL_0 + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                    value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->unitOfTraffic,     NV_PNVLTLC_TX0_DEBUG_TP_CNTR0_CTRL_0_UNIT);
                    value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->typeOfFlits,       NV_PNVLTLC_TX0_DEBUG_TP_CNTR0_CTRL_0_FLITFILTER);
                    value[count]    = DRF_REPLACE(value[count], (NV_PNVLTLC_TX0_DEBUG_TP_CNTR0_CTRL_0_VCSETFILTERMODE_VCSET0 | NV_PNVLTLC_TX0_DEBUG_TP_CNTR0_CTRL_0_VCSETFILTERMODE_VCSET1),       NV_PNVLTLC_TX0_DEBUG_TP_CNTR0_CTRL_0_VCSETFILTERMODE);
                    count++;

                    offset[count]   = NV_PNVLTLC_TX0_DEBUG_TP_CNTR0_CTRL_1 + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                    value[count]    = DRF_REPLACE(value[count], NV_PNVLTLC_TX0_DEBUG_TP_CNTR0_CTRL_1_PKTFILTERRSPMODE_BOTHBASEANDCOMPRESSEDRESPONSES,   NV_PNVLTLC_TX0_DEBUG_TP_CNTR0_CTRL_1_PKTFILTERRSPMODE);
                    count++;

                    offset[count]   = NV_PNVLTLC_TX0_DEBUG_TP_CNTR0_REQ_FILTER + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                    value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->transactionType,   NV_PNVLTLC_TX0_DEBUG_TP_CNTR0_REQ_FILTER_REQUESTFILTERMODE);
                    count++;

                    offset[count]   = NV_PNVLTLC_TX0_DEBUG_TP_CNTR0_RSP_FILTER + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                    value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->responseType,      NV_PNVLTLC_TX0_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE);
                    count++;
                    break;

                case 1:
                    offset[count]   = NV_PNVLTLC_TX0_DEBUG_TP_CNTR1_CTRL_0 + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                    value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->unitOfTraffic,     NV_PNVLTLC_TX0_DEBUG_TP_CNTR1_CTRL_0_UNIT);
                    value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->typeOfFlits,       NV_PNVLTLC_TX0_DEBUG_TP_CNTR1_CTRL_0_FLITFILTER);
                    value[count]    = DRF_REPLACE(value[count], (NV_PNVLTLC_TX0_DEBUG_TP_CNTR1_CTRL_0_VCSETFILTERMODE_VCSET0 | NV_PNVLTLC_TX0_DEBUG_TP_CNTR1_CTRL_0_VCSETFILTERMODE_VCSET1),       NV_PNVLTLC_TX0_DEBUG_TP_CNTR1_CTRL_0_VCSETFILTERMODE);
                    count++;

                    offset[count]   = NV_PNVLTLC_TX0_DEBUG_TP_CNTR1_CTRL_1 + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                    value[count]    = DRF_REPLACE(value[count], NV_PNVLTLC_TX0_DEBUG_TP_CNTR1_CTRL_1_PKTFILTERRSPMODE_BOTHBASEANDCOMPRESSEDRESPONSES,   NV_PNVLTLC_TX0_DEBUG_TP_CNTR1_CTRL_1_PKTFILTERRSPMODE);
                    count++;

                    offset[count]   = NV_PNVLTLC_TX0_DEBUG_TP_CNTR1_REQ_FILTER + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                    value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->transactionType,   NV_PNVLTLC_TX0_DEBUG_TP_CNTR1_REQ_FILTER_REQUESTFILTERMODE);
                    count++;

                    offset[count]   = NV_PNVLTLC_TX0_DEBUG_TP_CNTR1_RSP_FILTER + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                    value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->responseType,      NV_PNVLTLC_TX0_DEBUG_TP_CNTR1_RSP_FILTER_RESPONSEFILTERMODE);
                    count++;
                    break;
                }
                numCountersTxAdded++;
            }
            else {
                switch(numCountersRxAdded)
                {
                case 0:
                    offset[count]   = NV_PNVLTLC_RX0_DEBUG_TP_CNTR0_CTRL_0 + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                    value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->unitOfTraffic,     NV_PNVLTLC_RX0_DEBUG_TP_CNTR0_CTRL_0_UNIT);
                    value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->typeOfFlits,       NV_PNVLTLC_RX0_DEBUG_TP_CNTR0_CTRL_0_FLITFILTER);
                    value[count]    = DRF_REPLACE(value[count], (NV_PNVLTLC_RX0_DEBUG_TP_CNTR0_CTRL_0_VCSETFILTERMODE_VCSET0 | NV_PNVLTLC_RX0_DEBUG_TP_CNTR0_CTRL_0_VCSETFILTERMODE_VCSET1),       NV_PNVLTLC_RX0_DEBUG_TP_CNTR0_CTRL_0_VCSETFILTERMODE);
                    count++;

                    offset[count]   = NV_PNVLTLC_RX0_DEBUG_TP_CNTR0_CTRL_1 + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                    value[count]    = DRF_REPLACE(value[count], NV_PNVLTLC_RX0_DEBUG_TP_CNTR0_CTRL_1_PKTFILTERRSPMODE_BOTHBASEANDCOMPRESSEDRESPONSES,   NV_PNVLTLC_RX0_DEBUG_TP_CNTR0_CTRL_1_PKTFILTERRSPMODE);
                    count++;

                    offset[count]   = NV_PNVLTLC_RX0_DEBUG_TP_CNTR0_REQ_FILTER + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                    value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->transactionType,   NV_PNVLTLC_RX0_DEBUG_TP_CNTR0_REQ_FILTER_REQUESTFILTERMODE);
                    count++;

                    offset[count]   = NV_PNVLTLC_RX0_DEBUG_TP_CNTR0_RSP_FILTER + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                    value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->responseType,      NV_PNVLTLC_RX0_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE);
                    count++;
                    break;

                case 1:
                    offset[count]   = NV_PNVLTLC_RX0_DEBUG_TP_CNTR1_CTRL_0 + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                    value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->unitOfTraffic,     NV_PNVLTLC_RX0_DEBUG_TP_CNTR1_CTRL_0_UNIT);
                    value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->typeOfFlits,       NV_PNVLTLC_RX0_DEBUG_TP_CNTR1_CTRL_0_FLITFILTER);
                    value[count]    = DRF_REPLACE(value[count], (NV_PNVLTLC_RX0_DEBUG_TP_CNTR1_CTRL_0_VCSETFILTERMODE_VCSET0 | NV_PNVLTLC_RX0_DEBUG_TP_CNTR1_CTRL_0_VCSETFILTERMODE_VCSET1),       NV_PNVLTLC_RX0_DEBUG_TP_CNTR1_CTRL_0_VCSETFILTERMODE);
                    count++;

                    offset[count]   = NV_PNVLTLC_RX0_DEBUG_TP_CNTR1_CTRL_1 + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                    value[count]    = DRF_REPLACE(value[count], NV_PNVLTLC_RX0_DEBUG_TP_CNTR1_CTRL_1_PKTFILTERRSPMODE_BOTHBASEANDCOMPRESSEDRESPONSES,   NV_PNVLTLC_RX0_DEBUG_TP_CNTR1_CTRL_1_PKTFILTERRSPMODE);
                    count++;

                    offset[count]   = NV_PNVLTLC_RX0_DEBUG_TP_CNTR1_REQ_FILTER + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                    value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->transactionType,   NV_PNVLTLC_RX0_DEBUG_TP_CNTR1_REQ_FILTER_REQUESTFILTERMODE);
                    count++;

                    offset[count]   = NV_PNVLTLC_RX0_DEBUG_TP_CNTR1_RSP_FILTER + nvlinkId * GV100_NVLINK_PRI_REG_OFFSET;
                    value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->responseType,      NV_PNVLTLC_RX0_DEBUG_TP_CNTR1_RSP_FILTER_RESPONSEFILTERMODE);
                    count++;
                    break;
                }
                numCountersRxAdded++;
            }
        }
    }

#else
    // Not needed to configure individual links in Volta if MULTICAST configuration is selected
    offset[count]   = NV_PNVLIPT_CTRL_PRI_MULTICAST;
    value[count]    = DRF_REPLACE(value[count], 0x3f,     NV_PNVLIPT_CTRL_PRI_MULTICAST_DL_ENABLE);
    value[count]    = DRF_REPLACE(value[count], 0x3f,     NV_PNVLIPT_CTRL_PRI_MULTICAST_TL_ENABLE);
    count++;

    for (index = 0; index < voltaEventGroup->nvLinkTCConfig->nvlinkCountersAdded; index++)
    {
        if (voltaEventGroup->nvLinkTCConfig->pEventData[index]->direction == CUPROF_NVLINK_DATA_TRANSMIT)
        {
            switch(numCountersTxAdded)
            {
            case 0:
                offset[count]   = NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0;
                value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->unitOfTraffic,     NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT);
                value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->typeOfFlits,       NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_FLITFILTER);
                value[count]    = DRF_REPLACE(value[count], (NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_VCSETFILTERMODE_VCSET0 | NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_VCSETFILTERMODE_VCSET1),       NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_VCSETFILTERMODE);
                count++;

                offset[count]   = NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_CTRL_1;
                value[count]    = DRF_REPLACE(value[count], NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_CTRL_1_PKTFILTERRSPMODE_BOTHBASEANDCOMPRESSEDRESPONSES,   NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_CTRL_1_PKTFILTERRSPMODE);
                count++;

                offset[count]   = NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_REQ_FILTER;
                value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->transactionType,   NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_REQ_FILTER_REQUESTFILTERMODE);
                count++;

                offset[count]   = NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER;
                value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->responseType,      NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE);
                count++;
                break;

            case 1:
                offset[count]   = NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0;
                value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->unitOfTraffic,     NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_UNIT);
                value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->typeOfFlits,       NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_FLITFILTER);
                value[count]    = DRF_REPLACE(value[count], (NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_VCSETFILTERMODE_VCSET0 | NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_VCSETFILTERMODE_VCSET1),       NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_VCSETFILTERMODE);
                count++;

                offset[count]   = NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR1_CTRL_1;
                value[count]    = DRF_REPLACE(value[count], NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR1_CTRL_1_PKTFILTERRSPMODE_BOTHBASEANDCOMPRESSEDRESPONSES,   NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR1_CTRL_1_PKTFILTERRSPMODE);
                count++;

                offset[count]   = NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR1_REQ_FILTER;
                value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->transactionType,   NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR1_REQ_FILTER_REQUESTFILTERMODE);
                count++;

                offset[count]   = NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR1_RSP_FILTER;
                value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->responseType,      NV_PNVLTLC_TX_MULTICAST_DEBUG_TP_CNTR1_RSP_FILTER_RESPONSEFILTERMODE);
                count++;
                break;
            }
            numCountersTxAdded++;
        }
        else {
            switch(numCountersRxAdded)
            {
            case 0:
                offset[count]   = NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0;
                value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->unitOfTraffic,     NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_UNIT);
                value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->typeOfFlits,       NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_FLITFILTER);
                value[count]    = DRF_REPLACE(value[count], (NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_VCSETFILTERMODE_VCSET0 | NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_VCSETFILTERMODE_VCSET1),       NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_0_VCSETFILTERMODE);
                count++;

                offset[count]   = NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_1;
                value[count]    = DRF_REPLACE(value[count], NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_1_PKTFILTERRSPMODE_BOTHBASEANDCOMPRESSEDRESPONSES,   NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_CTRL_1_PKTFILTERRSPMODE);
                count++;

                offset[count]   = NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_REQ_FILTER;
                value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->transactionType,   NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_REQ_FILTER_REQUESTFILTERMODE);
                count++;

                offset[count]   = NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER;
                value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->responseType,      NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR0_RSP_FILTER_RESPONSEFILTERMODE);
                count++;
                break;

            case 1:
                offset[count]   = NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0;
                value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->unitOfTraffic,     NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_UNIT);
                value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->typeOfFlits,       NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_FLITFILTER);
                value[count]    = DRF_REPLACE(value[count], (NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_VCSETFILTERMODE_VCSET0 | NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_VCSETFILTERMODE_VCSET1),       NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR1_CTRL_0_VCSETFILTERMODE);
                count++;

                offset[count]   = NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR1_CTRL_1;
                value[count]    = DRF_REPLACE(value[count], NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR1_CTRL_1_PKTFILTERRSPMODE_BOTHBASEANDCOMPRESSEDRESPONSES,   NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR1_CTRL_1_PKTFILTERRSPMODE);
                count++;

                offset[count]   = NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR1_REQ_FILTER;
                value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->transactionType,   NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR1_REQ_FILTER_REQUESTFILTERMODE);
                count++;

                offset[count]   = NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR1_RSP_FILTER;
                value[count]    = DRF_REPLACE(value[count], voltaEventGroup->nvLinkTCConfig->pEventData[index]->responseType,      NV_PNVLTLC_RX_MULTICAST_DEBUG_TP_CNTR1_RSP_FILTER_RESPONSEFILTERMODE);
                count++;
                break;
            }
            numCountersRxAdded++;
        }
    }
#endif

    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_GLOBAL, count, offset, value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
    }

EXIT:
    free(offset);
    free(value);
    return status;
}

static CUprofResult tryAddingNvlinkThroughputCounter(CUeventGroup *pEventGroup, CUeventDataNvlinkThroughputCounters *pEventData)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUvoltaEventGroup *voltaEventGroup = NULL;
    CU_TRACE_FUNCTION();

    // Check if the signal can be profiled:
    // Two Tx and Rx signals can be profiled from every NvLink.
    // NOTE: We are configuring all the NvLinks in a similar way
    voltaEventGroup = pEventGroup->arch.voltaEventGroup;
    if (voltaEventGroup->nvLinkTCConfig) {
        if (pEventData->direction == CUPROF_NVLINK_DATA_TRANSMIT) {
            if (voltaEventGroup->nvLinkTCConfig->numCountersTx == MAX_COUNTERS_PER_NVLINK) {
                // Max number of counters added for Tx on this NvLink
                // This counter cannot be profiled in this run
                return CUPROF_ERROR_MAX_LIMIT_REACHED;
            }
            else {
                voltaEventGroup->nvLinkTCConfig->numCountersTx++;
            }
        }
        else {
            if (voltaEventGroup->nvLinkTCConfig->numCountersRx == MAX_COUNTERS_PER_NVLINK) {
                // There is already a signal added for Tx on this NvLink
                // This counter cannot be profiled in this run
                return CUPROF_ERROR_MAX_LIMIT_REACHED;
            }
            else {
                voltaEventGroup->nvLinkTCConfig->numCountersRx++;
            }
        }
    }
    // If the signal can be profiled, store the table entry from signal table in tnvLinkTCConfig->pEventData:
    voltaEventGroup->nvLinkTCConfig->pEventData[voltaEventGroup->nvLinkTCConfig->nvlinkCountersAdded] = pEventData;

    return status;
}

static CUprofResult tryAddingFilterCounter(CUeventGroup *pEventGroup, CUdomainData *pDomainData, CUeventDataSmpc *pEventData, NvU32 mode)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUeventDataSmpc *pEventdataTemp = NULL;
    CUeventInfo *pEventInfoTemp = NULL;
    NvU32 value = 0, setGrpIdx = 0, domIdx = 0;
    CUSMCtrInfo *pSM = NULL;

    pSM = pEventGroup->arch.voltaEventGroup->pSM;

    for (domIdx = 0; domIdx < pEventGroup->pCtx->device->state.pDomainInfo->numDomains; domIdx++) {

        pEventInfoTemp = voltaLookupDomainSignalTable(&pEventGroup->pCtx->device->state.pDomainInfo->pDomainTable[domIdx], pEventData->signalId_filter);
        if(pEventInfoTemp)
        {
            break;
        }
    }

    if(!pEventInfoTemp) {
        CU_ASSERT(0);
        return CUPROF_ERROR_UNKNOWN;
    }

    if(domIdx == pEventGroup->pCtx->device->state.pDomainInfo->numDomains) {
        status = CUPROF_ERROR_INVALID_EVENT_ID;
        goto EXIT;
    }

    pEventdataTemp = (CUeventDataSmpc*)pEventInfoTemp->pEventData;
    switch(pEventdataTemp->pmUnitId)
    {
        case PM_UNIT_SMCORE:
        case PM_UNIT_MIO:
            {
                NvU32 coreIdx = 0;
                // Core filter signal can be used only for core/mio events
                CU_ASSERT(pEventData->pmUnitId == PM_UNIT_MIO || pEventData->pmUnitId == PM_UNIT_SMCORE);
                // Check if the filter signal is already added:
                if(pSM->signalIdFilterCore)
                {
                    if(pSM->signalIdFilterCore != pEventdataTemp->signalId)
                    {
                        // Only one filter signal allowed in a run:
                        status = CUPROF_ERROR_NOT_COMPATIBLE;
                        goto EXIT;
                    }
                    else
                    {
                        // Filter signal is already configured:
                        status = CUPROF_SUCCESS;
                        goto EXIT;
                    }
                }
                // Configure the filter signal
                // Add the group of filter signal to the list of groups as even after adding the filter signal,
                //    only 4 groups for core and quad each are allowed.
                while(coreIdx < pSM->numGroupsCore)
                {
                    if(pEventdataTemp->eventGroup == pSM->groupsCore[coreIdx])
                    {
                        break;
                    }
                    coreIdx++;
                }
                if(coreIdx == pSM->numGroupsCore)
                {
                    if(pSM->numGroupsCore == CU_PROF_SM_CORE_PROFILED_MAX) {
                        status = CUPROF_ERROR_NOT_COMPATIBLE;
                        goto EXIT;
                    }
                    pSM->groupsCore[pSM->numGroupsCore++] = pEventdataTemp->eventGroup;
                }
                setGrpIdx = coreIdx;
            }
            break;
        case PM_UNIT_SMQCTL:
            {
                NvU32 quadIdx = 0;
                // Use quad filter signal only for quad events
                CU_ASSERT(pEventData->pmUnitId == PM_UNIT_SMQCTL);
                // Check if the filter signal is already added:
                if(pSM->signalIdFilterQuad)
                {
                    if(pSM->signalIdFilterQuad != pEventdataTemp->signalId)
                    {
                        // Only one filter signal allowed in a run:
                        status = CUPROF_ERROR_NOT_COMPATIBLE;
                        goto EXIT;
                    }
                    else
                    {
                        // Filter signal is already configured:
                        status = CUPROF_SUCCESS;
                        goto EXIT;
                    }
                }
                // Configure the filter signal:
                while(quadIdx < pSM->numGroupsQuad)
                {
                    if(pEventdataTemp->eventGroup == pSM->groupsQuad[quadIdx])
                    {
                        break;
                    }
                    quadIdx++;
                }
                if(quadIdx == pSM->numGroupsQuad)
                {
                    if(pSM->numGroupsQuad == CU_PROF_SM_QUAD_PROFILED_MAX) {
                        status = CUPROF_ERROR_NOT_COMPATIBLE;
                        goto EXIT;
                    }
                    pSM->groupsQuad[pSM->numGroupsQuad++] = pEventdataTemp->eventGroup;
                }
                setGrpIdx = quadIdx;
            }
            break;
    }

    /***********************************************************************************
      0:1 - Event Group Idx of the filter signal
      2:4 - PerfEvent of the filter signal
    ************************************************************************************/
    value = DRF_REPLACE(value, setGrpIdx, NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_FILTER0_CONTROL_GRP);
    value = DRF_REPLACE(value, pEventdataTemp->perfEvent, NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_FILTER0_CONTROL_SIG);

    if(status == CUPROF_SUCCESS)
    {
        // Store the signalId for future reference while adding any other counter which requires filtering signal:
        if(pEventData->pmUnitId == PM_UNIT_SMQCTL) {
            pSM->signalIdFilterQuad = pEventdataTemp->signalId;
            pSM->signalConfigQuad = value;
        }
        else {
            pSM->signalIdFilterCore = pEventdataTemp->signalId;
            pSM->signalConfigCore = value;
        }
    }
EXIT:
    free(pEventInfoTemp);
    return status;
}

static CUprofResult tryAddingSmpcCounter(CUeventGroup *pEventGroup, CUdomainData *pDomainData, CUeventDataSmpc *pEventData)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 newGroupIdx = 0;
    CUSMCtrInfo *pSM = NULL;

    pSM = pEventGroup->arch.voltaEventGroup->pSM;

    if(((pEventData->pmUnitId == PM_UNIT_SMCORE) || (pEventData->pmUnitId == PM_UNIT_MIO)) && (pSM->coreCount == CU_PROF_SM_CORE_PROFILED_MAX)) {
        return CUPROF_ERROR_NOT_COMPATIBLE;
    }
    else if((pEventData->pmUnitId == PM_UNIT_SMQCTL) && (pSM->qctlCount == CU_PROF_SM_QUAD_PROFILED_MAX)) {
        return CUPROF_ERROR_NOT_COMPATIBLE;
    }
    if(pEventData->signalId_filter) {
        status = tryAddingFilterCounter(pEventGroup, pDomainData, pEventData, NV_SM_DSM_PERF_COUNTER_CONTROL_MODE_COUNT);
        if (status != CUPROF_SUCCESS) {
            CU_ERROR_PRINT(("Failed to add new counter\n"));
            return status;
        }
    }
    switch(pEventData->pmUnitId)
    {
    case PM_UNIT_SMCORE:
    case PM_UNIT_MIO:
        {
            NvU32 coreIdx = 0;
            while(coreIdx < pSM->numGroupsCore)
            {
                if(pEventData->eventGroup == pSM->groupsCore[coreIdx])
                {
                    newGroupIdx = coreIdx;
                    pSM->coreCount++;
                    break;
                }
                coreIdx++;
            }
            if(coreIdx == pSM->numGroupsCore)
            {
                if(pSM->numGroupsCore == CU_PROF_SM_CORE_PROFILED_MAX) {
                    return CUPROF_ERROR_NOT_COMPATIBLE;
                }
                newGroupIdx = pSM->numGroupsCore;
                pSM->groupsCore[pSM->numGroupsCore++] = pEventData->eventGroup;
                pSM->coreCount++;
            }
        }
        break;
    case PM_UNIT_SMQCTL:
        {
            NvU32 quadIdx = 0;
            while(quadIdx < pSM->numGroupsQuad)
            {
                if(pEventData->eventGroup == pSM->groupsQuad[quadIdx])
                {
                    newGroupIdx = quadIdx;
                    pSM->qctlCount++;
                    break;
                }
                quadIdx++;
            }
            if(quadIdx == pSM->numGroupsQuad)
            {
                if(pSM->numGroupsQuad == CU_PROF_SM_QUAD_PROFILED_MAX) {
                    return CUPROF_ERROR_NOT_COMPATIBLE;
                }
                newGroupIdx = pSM->numGroupsQuad;
                pSM->groupsQuad[pSM->numGroupsQuad++] = pEventData->eventGroup;
                pSM->qctlCount++;
            }
        }
        break;
    }

    pSM->function[pSM->SMCountersAdded] = pEventData->function;
    pSM->pmUnitId[pSM->SMCountersAdded] = pEventData->pmUnitId;
    pSM->mode[pSM->SMCountersAdded] = NV_SM_DSM_PERF_COUNTER_CONTROL_MODE_COUNT;

    pSM->perfEventInfo[pSM->SMCountersAdded]  = (newGroupIdx & 3) | (pEventData->perfEvent & 0x00000007) << 2;
    pSM->perfEventInfo[pSM->SMCountersAdded] |= ((newGroupIdx & 3) | ((pEventData->perfEvent & 0x00000070)>>4) << 2) << 5;
    pSM->perfEventInfo[pSM->SMCountersAdded] |= ((newGroupIdx & 3) | ((pEventData->perfEvent & 0x00000700)>>8) << 2) << 10;
    pSM->perfEventInfo[pSM->SMCountersAdded] |= ((newGroupIdx & 3) | ((pEventData->perfEvent & 0x00007000)>>12) << 2) << 15;
    pSM->perfEventInfo[pSM->SMCountersAdded] |= ((newGroupIdx & 3) | ((pEventData->perfEvent & 0x00070000)>>16) << 2) << 20;
    pSM->perfEventInfo[pSM->SMCountersAdded] |= ((newGroupIdx & 3) | ((pEventData->perfEvent & 0x00700000)>>20) << 2) << 25;

    if(pEventData->signalId_filter) {
        status = enableFilterSignal(pEventGroup->pCtx, (pEventData->pmUnitId == PM_UNIT_SMQCTL) ? (pSM->qctlCount - 1) : (pSM->coreCount - 1), 
                                    (pEventData->pmUnitId == PM_UNIT_SMQCTL) ? &pSM->signalConfigQuad : &pSM->signalConfigCore);
    }
    return status;
}

static CUprofResult tryAddingMultiGroupOrLutCounter(CUeventGroup *pEventGroup, CUdomainData *pDomainData, CUeventDataSmpcExpt *pEventData, NvU32 signalTableType)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUeventDataSmpc *pEventdataTemp[6] = {NULL};
    CUeventInfo *pEventInfoTemp[6] = {NULL};
    CUSMCtrInfo *pSM = NULL;
    NvU32 j = 0, newEventGroups = 0, newGroupIds[6] = {0}, newGroupIdx[6] = {0}, numSignals = 0, busWidth[6] = {0};
    NvU32 totalSigWidth, sigWidth, maxSignalsAllowed = 0;

    pSM = pEventGroup->arch.voltaEventGroup->pSM;
    maxSignalsAllowed = (signalTableType == PERF_SIG_TABLE_TYPE_LUT) ? 4 : 6;
    if(((pEventData->pmUnitId == PM_UNIT_SMCORE) || (pEventData->pmUnitId == PM_UNIT_MIO)) && (pSM->coreCount == CU_PROF_SM_CORE_PROFILED_MAX)) {
        return CUPROF_ERROR_NOT_COMPATIBLE;
    }
    else if((pEventData->pmUnitId == PM_UNIT_SMQCTL) && (pSM->qctlCount == CU_PROF_SM_QUAD_PROFILED_MAX)) {
        return CUPROF_ERROR_NOT_COMPATIBLE;
    }
    // Only one array of newGroupIdx is maintained here as the signals can be from any SINGLE unit.
    // Signals with different units cannot combine to form an LUT or multi-group increment signal.
    while(pEventData->signalId_combination[numSignals] != INVALID_PM_SIGNAL_NEW && numSignals < maxSignalsAllowed)
    {
        pEventInfoTemp[numSignals] = voltaLookupDomainSignalTable(pDomainData, pEventData->signalId_combination[numSignals]);
        if(pEventInfoTemp[numSignals])
        {
            pEventdataTemp[numSignals] = (CUeventDataSmpc*)pEventInfoTemp[numSignals]->pEventData;
            CU_ASSERT(pEventdataTemp[numSignals]->pmUnitId == pEventData->pmUnitId);
            // Allow only single bit signal combinations for LUT:
            if(signalTableType == PERF_SIG_TABLE_TYPE_LUT) {
                CU_ASSERT(pEventdataTemp[numSignals]->busWidth == 1);
            }
            busWidth[numSignals] = pEventdataTemp[numSignals]->busWidth;
            switch(pEventData->pmUnitId)
            {
            case PM_UNIT_SMCORE:
            case PM_UNIT_MIO:
                {
                    NvU32 coreIdx = 0;
                    while(coreIdx < pSM->numGroupsCore)
                    {
                        if(pEventdataTemp[numSignals]->eventGroup == pSM->groupsCore[coreIdx])
                        {
                            newGroupIdx[numSignals] = coreIdx;
                            break;
                        }
                        coreIdx++;
                    }
                    if(coreIdx == pSM->numGroupsCore)
                    {
                        for(j = 0; j < newEventGroups; j++) {
                            if(pEventdataTemp[numSignals]->eventGroup == newGroupIds[j])
                            {
                                newGroupIdx[numSignals] = pSM->numGroupsCore + j;
                                break;
                            }
                        }
                        if(j == newEventGroups) {
                            newGroupIds[newEventGroups] = pEventdataTemp[numSignals]->eventGroup;
                            newGroupIdx[numSignals] = newEventGroups + pSM->numGroupsCore;
                            newEventGroups++;
                        }
                    }
                }
                break;
            case PM_UNIT_SMQCTL:
                {
                    NvU32 quadIdx = 0;
                    while(quadIdx < pSM->numGroupsQuad)
                    {
                        if(pEventdataTemp[numSignals]->eventGroup == pSM->groupsQuad[quadIdx])
                        {
                            newGroupIdx[numSignals] = quadIdx;
                            break;
                        }
                        quadIdx++;
                    }
                    if(quadIdx == pSM->numGroupsQuad)
                    {
                        for(j = 0; j < newEventGroups; j++) {
                            if(pEventdataTemp[numSignals]->eventGroup == newGroupIds[j])
                            {
                                newGroupIdx[numSignals] = pSM->numGroupsQuad + j;
                                break;
                            }
                        }
                        if(j == newEventGroups) {
                            newGroupIds[newEventGroups] = pEventdataTemp[numSignals]->eventGroup;
                            newGroupIdx[numSignals] = newEventGroups + pSM->numGroupsQuad;
                            newEventGroups++;
                        }
                    }
                }
                break;
            }
        }
        else
        {
            status = CUPROF_ERROR_INVALID_EVENT_ID;
            goto EXIT;
        }
        numSignals++;
    }
    if ((pEventData->pmUnitId == PM_UNIT_SMCORE) || (pEventData->pmUnitId == PM_UNIT_MIO)) {
        if((pSM->numGroupsCore + newEventGroups) > CU_PROF_SM_CORE_PROFILED_MAX) {
            status = CUPROF_ERROR_NOT_COMPATIBLE;
            goto EXIT;
        }
        for(j = 0; j < newEventGroups; j++)
        {
            pSM->groupsCore[pSM->numGroupsCore++] = newGroupIds[j];
        }
        pSM->coreCount++;
    }
    else {
        if((pSM->numGroupsQuad + newEventGroups) > CU_PROF_SM_QUAD_PROFILED_MAX) {
            status = CUPROF_ERROR_NOT_COMPATIBLE;
            goto EXIT;
        }
        for(j = 0; j < newEventGroups; j++)
        {
            pSM->groupsQuad[pSM->numGroupsQuad++] = newGroupIds[j];
        }
        pSM->qctlCount++;
    }
    // Add the function directly from the signal table for LUT signals:
    if (signalTableType == PERF_SIG_TABLE_TYPE_LUT)
        pSM->function[pSM->SMCountersAdded] = pEventData->function;
    else {
        // Compute the function for multi-group increment signals:
        NvU32 func = 0;
        totalSigWidth = 0;
        for (j = 0; j < numSignals; j++)
        {
            sigWidth = 0;
            while (sigWidth < busWidth[j]) {
                func |= 0x1 << (totalSigWidth + sigWidth);
                sigWidth++;
            }
            totalSigWidth += busWidth[j];
        }
        pSM->function[pSM->SMCountersAdded] = func;
    }
    pSM->pmUnitId[pSM->SMCountersAdded] = pEventData->pmUnitId;
    // Assign the mode based on the signal table type:
    pSM->mode[pSM->SMCountersAdded] = (signalTableType == PERF_SIG_TABLE_TYPE_LUT) ? NV_SM_DSM_PERF_COUNTER_CONTROL_MODE_LUT : NV_SM_DSM_PERF_COUNTER_CONTROL_MODE_COUNT;
    j = 0;
    totalSigWidth = 0;
    while(j < numSignals)
    {
        // sigWidth is specifically for multi-group increment signals as in LUT mode, only single bit signals are allowed in the combination.
        sigWidth = 0;
        while(sigWidth < busWidth[j]) {
            pSM->perfEventInfo[pSM->SMCountersAdded] |= ((newGroupIdx[j] & 3) | ((pEventdataTemp[j]->perfEvent & (0x00000007 << (4 * sigWidth))) >> (4 * sigWidth)) << 2)
                                                         << (5 * (totalSigWidth + sigWidth));
            sigWidth++;
        }
        totalSigWidth += busWidth[j];
        j++;
    }

EXIT:
    for(j = 0; j < numSignals; j++) {
        free(pEventInfoTemp[j]);
    }
    return status;
}

static CUprofResult tryAddingSmpcExpt(CUeventGroup *pEventGroup, CUdomainData *pDomainData, CUeventDataSmpcExpt_v1 *pEventData)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUeventDataSmpc *pEventdataTemp[4] = {NULL};
    CUeventInfo *pEventInfoTemp[6] = {NULL};
    CUSMCtrInfo *pSM = NULL;
    NvU32 j = 0, newEventGroups = 0, newGroupIds[6] = {0}, newGroupIdx[6] = {0}, numSignals = 0, busWidth[6] = {0};
    NvU32 maxSignalsAllowed = 0, signal = 0, coreIdx = 0;

    pSM = pEventGroup->arch.voltaEventGroup->pSM;
    maxSignalsAllowed = 4;
    // This mode is supported only for SMPC Core/MIO counters
    if((pEventData->pmUnitId == PM_UNIT_SMCORE) || (pEventData->pmUnitId == PM_UNIT_MIO)) {
        if ((pSM->coreCount+pEventData->numSignals) > CU_PROF_SM_CORE_PROFILED_MAX) {
            return CUPROF_ERROR_NOT_COMPATIBLE;
        }
    }
    else {
        return CUPROF_ERROR_NOT_COMPATIBLE;
    }
    while((pEventData->signalId_combination[numSignals] != INVALID_PM_SIGNAL_NEW) &&
          (numSignals < maxSignalsAllowed) &&
          (numSignals < pEventData->numSignals))
    {
        pEventInfoTemp[numSignals] = voltaLookupDomainSignalTable(pDomainData, pEventData->signalId_combination[numSignals]);
        if(pEventInfoTemp[numSignals])
        {
            pEventdataTemp[numSignals] = (CUeventDataSmpc*)pEventInfoTemp[numSignals]->pEventData;
            CU_ASSERT(pEventdataTemp[numSignals]->pmUnitId == pEventData->pmUnitId);
            busWidth[numSignals] = pEventdataTemp[numSignals]->busWidth;
            coreIdx = 0;
            while(coreIdx < pSM->numGroupsCore)
            {
                if(pEventdataTemp[numSignals]->eventGroup == pSM->groupsCore[coreIdx])
                {
                    newGroupIdx[numSignals] = coreIdx;
                    break;
                }
                coreIdx++;
            }
            if(coreIdx == pSM->numGroupsCore)
            {
                for(j = 0; j < newEventGroups; j++) {
                    if(pEventdataTemp[numSignals]->eventGroup == newGroupIds[j])
                    {
                        newGroupIdx[numSignals] = pSM->numGroupsCore + j;
                        break;
                    }
                }
                if(j == newEventGroups) {
                    newGroupIds[newEventGroups] = pEventdataTemp[numSignals]->eventGroup;
                    newGroupIdx[numSignals] = newEventGroups + pSM->numGroupsCore;
                    newEventGroups++;
                }
            }
        }
        else
        {
            status = CUPROF_ERROR_INVALID_EVENT_ID;
            goto EXIT;
        }
        numSignals++;
    }
    if((pSM->numGroupsCore + newEventGroups) > CU_PROF_SM_CORE_PROFILED_MAX) {
        status = CUPROF_ERROR_NOT_COMPATIBLE;
        goto EXIT;
    }
    // Add info about the individual signals:
    for (signal = 0; signal < pEventData->numSignals; signal++) {
        status = tryAddingSmpcCounter(pEventGroup, pDomainData, pEventdataTemp[signal]);
        if (status != CUPROF_SUCCESS) {
            CU_ERROR_PRINT(("Failed to add new counter\n"));
            return status;
        }
        if (signal == 0) {
            pSM->numSignalsInExpt[pSM->SMCountersAdded] = pEventData->numSignals;
        }
        pSM->sigtableInfo[pSM->SMCountersAdded] = pEventInfoTemp[signal];
        pSM->SMCountersAdded++;
    }
    if(0 == pEventGroup->totalCounters) {
        pEventGroup->arch.voltaEventGroup->chipletType = pDomainData->chipletType;
    }

EXIT:
    return status;
}

// Volta+ software counters are collected using atomics on global memory. This
// gives a benefit to collect all sw counters from one domain in one-pass. Now 
// each sw counter domain have different count. This function returns the max
// software counters for the domain.
static int getNumberofSwCountersFromDomain(CUdomainData *pDomainData)
{
    int count = 0;
    int eventId;
    CueventCUPTIsw *pEventData;

    CU_ASSERT(pDomainData);
    CU_ASSERT(pDomainData->numPerfSignalTables == 1);

    pEventData = (CueventCUPTIsw *)pDomainData->pEventTableInfo[0].pEventData;

    CU_ASSERT(pDomainData->pEventTableInfo[0].signalTableType == PERF_SIG_TABLE_TYPE_CUPTI_SW);

    do {
        eventId = pEventData[count].signalId;
        count++;
    } while(eventId != INVALID_SW_COUNTER);

    CU_ASSERT(count);
    return count;
}

static CUprofResult voltaPerfmonTryAddingCounterNew(CUeventGroup *pEventGroup, CUdomainData *pDomainData,  CUeventInfo *pEventInfo, NvBool *added, NvU32 *maxSignals)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUSMCtrInfo  *pSM = NULL;

    CU_TRACE_FUNCTION();

    *added = NV_FALSE;
    switch(pDomainData->eventCollectionMethod)
    {
    case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
    case CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX:
        //Try adding PM signal.
        *maxSignals = CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS + CU_PROF_ELAPSED_CLOCK_SLOT;
        if (pEventInfo && pEventInfo->pEventData) {
            status = canSigBeProfiledModeB(pEventGroup, pDomainData, pEventInfo, added);
        }
        if((*added == NV_TRUE) && (!pEventGroup->totalCounters))
        {
            //Store the chiplet type
            pEventGroup->arch.voltaEventGroup->chipletType = pDomainData->chipletType;
            pEventGroup->arch.voltaEventGroup->clkIdx = getClkIdx(pEventGroup->pCtx, pDomainData->domainId, pDomainData->chipletType);
        }
        break;

    case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
        //Try adding SM counter.
        {
            pSM = pEventGroup->arch.voltaEventGroup->pSM;
            if ((pEventInfo->signalTableType == PERF_SIG_TABLE_TYPE_LUT) || (pEventInfo->signalTableType == PERF_SIG_TABLE_TYPE_MULTI_GROUP))
            {
                status = tryAddingMultiGroupOrLutCounter(pEventGroup, pDomainData, (CUeventDataSmpcExpt*)pEventInfo->pEventData, pEventInfo->signalTableType);
                if (status != CUPROF_SUCCESS) {
                    CU_ERROR_PRINT(("Failed to add new counter\n"));
                    return status;
                }
            }
            else if (pEventInfo->signalTableType == PERF_SIG_TABLE_TYPE_SMPC_EXPERIMENT)
            {
                status = tryAddingSmpcExpt(pEventGroup, pDomainData, (CUeventDataSmpcExpt_v1*)pEventInfo->pEventData);
                if (status != CUPROF_SUCCESS) {
                    CU_ERROR_PRINT(("Failed to add new counter\n"));
                    return status;
                }
                *added = NV_TRUE;
            }
            else if (pEventInfo->signalTableType == PERF_SIG_TABLE_TYPE_SMPC)
            {
                status = tryAddingSmpcCounter(pEventGroup, pDomainData, (CUeventDataSmpc*)pEventInfo->pEventData);
                if (status != CUPROF_SUCCESS) {
                    CU_ERROR_PRINT(("Failed to add new counter\n"));
                    return status;
                }
            }

            if (pDomainData->domainId == VOLTA_CLK_DOMAIN_GV100_SM0 || pDomainData->domainId == VOLTA_CLK_DOMAIN_GV11B_SM0) {
                *maxSignals = (CU_PROF_SM_CORE_PROFILED_MAX + CU_PROF_SM_QUAD_PROFILED_MAX);
            }

            if (pEventInfo->signalTableType != PERF_SIG_TABLE_TYPE_SMPC_EXPERIMENT)
            {
                if(pSM->SMCountersAdded < *maxSignals) {
                    *added = NV_TRUE;
                    pSM->sigtableInfo[pSM->SMCountersAdded] = pEventInfo;
                    pSM->numSignalsInExpt[pSM->SMCountersAdded] = 1;
                    if(0 == pEventGroup->totalCounters) {
                        pEventGroup->arch.voltaEventGroup->chipletType = pDomainData->chipletType;
                    }
                    pSM->numSignalsInExpt[pSM->SMCountersAdded] = 1;
                }
                else {
                    return CUPROF_ERROR_MAX_LIMIT_REACHED;
                }
                pSM->SMCountersAdded++;
            }
        }
        break;
    case CUPROF_EVENT_COLLECTION_METHOD_NVLINK_TC:
        status = tryAddingNvlinkThroughputCounter(pEventGroup, (CUeventDataNvlinkThroughputCounters*)pEventInfo->pEventData);
        if (status != CUPROF_SUCCESS) {
            CU_ERROR_PRINT(("Failed to add new counter\n"));
            return status;
        }
        pEventGroup->arch.voltaEventGroup->nvLinkTCConfig->nvlinkCountersAdded++;
        *added = NV_TRUE;
        // 2 TX and 2 RX counters per NVLINK
        *maxSignals = MAX_COUNTERS_PER_NVLINK * 2;
        break;
    case CUPROF_EVENT_COLLECTION_METHOD_CUPTI_SW:
        *maxSignals = getNumberofSwCountersFromDomain(pDomainData);
        *added = NV_TRUE;
        break;
    default:
        break;
    }
    return status;
}

/*****************************************************************
Variables used in the function:
- signalParts: Number of parts into which the signal is divided
- signalWidth: Original width of the signal
- splitWidth : Width of each splitted part of the signal
******************************************************************/
CUprofResult voltaPerfmonAddSplitSignalsSM(CUeventGroup *pEventGroup, CUdomainData *pDomainData, CUeventInfo *pEventInfo, NvBool *bAdded, NvU32 *maxSignals, NvU32 splitWidth)
{
    NvU32 signalParts = 0, startBit, endBit;
    NvU32 func, i, signalWidth, maxSignalsSM = 0;
    CUprofResult status = CUPROF_SUCCESS;
    CUSMCtrInfo  *pSM = NULL;
    CUeventDataSmpc *pEventData = NULL;

    pSM = pEventGroup->arch.voltaEventGroup->pSM;
    pEventData = (CUeventDataSmpc*)pEventInfo->pEventData;
    signalWidth = pEventData->busWidth;

    // Case handled for any signal of odd width
    signalParts = (signalWidth + (splitWidth - 1))/splitWidth;
    maxSignalsSM = (CU_PROF_SM_CORE_PROFILED_MAX + CU_PROF_SM_QUAD_PROFILED_MAX);

    if(pSM->SMCountersAdded < maxSignalsSM) {
        switch(pEventData->pmUnitId)
        {
        case PM_UNIT_SMCORE:
        case PM_UNIT_MIO:
            if (pSM->coreCount + signalParts > CU_PROF_SM_CORE_PROFILED_MAX) {
                return CUPROF_ERROR_NOT_COMPATIBLE;
            }
            break;
        case PM_UNIT_SMQCTL:
            if (pSM->qctlCount + signalParts > CU_PROF_SM_QUAD_PROFILED_MAX) {
                return CUPROF_ERROR_NOT_COMPATIBLE;
            }
            break;
        }
        func = pEventData->function;
        for(i = 0; i < signalParts; i++) {
            CUeventInfo *pEventInfoTemp = NULL;
            CUeventDataSmpc *pEventDataTemp = NULL;
            pEventInfoTemp = (CUeventInfo *) malloc (sizeof(CUeventInfo));
            if(pEventInfoTemp == NULL) {
                return CUPROF_ERROR_OUT_OF_MEMORY;
            }
            pEventDataTemp = (CUeventDataSmpc *) malloc (sizeof(CUeventDataSmpc));
            if(pEventDataTemp == NULL) {
                free(pEventInfoTemp);
                return CUPROF_ERROR_OUT_OF_MEMORY;
            }
            memcpy(pEventDataTemp, pEventData, sizeof(CUeventDataSmpc));
            pEventInfoTemp->signalTableType = pEventInfo->signalTableType;
            pEventInfoTemp->pEventData = (void*)pEventDataTemp;
            pEventDataTemp->perfEvent = 0;
            startBit = i * 4 * splitWidth;
            splitWidth = (signalWidth<splitWidth)?signalWidth:splitWidth;
            endBit = startBit + (splitWidth * 4) -1 ;
            pEventDataTemp->perfEvent = GETFIELD32(pEventData->perfEvent, endBit:startBit);
            pEventDataTemp->function = GETFIELD32(func,(splitWidth - 1):0);
            status = voltaPerfmonTryAddingCounterNew(pEventGroup,
                pDomainData,
                pEventInfoTemp,
                bAdded,
                maxSignals);
            if ((status != CUPROF_SUCCESS) || (*bAdded == NV_FALSE)) {
                CU_ERROR_PRINT(("Failed to add new counter\n"));
                return status;
            }
            CU_ASSERT(*bAdded);
            func = func >> splitWidth;
            signalWidth -= splitWidth;
        }
        pSM->splitParts[pEventGroup->totalCounters] = signalParts;
    }
    else {
        status = CUPROF_ERROR_MAX_LIMIT_REACHED;
        *bAdded = NV_FALSE;
        CU_ERROR_PRINT(("Failed to add new counter\n"));
    }
    return status;
}

#define SMCORE_UPPER_EVENT_GROUP 28
#define SMCORE_LOWER_EVENT_GROUP 29
#define MIO_UPPER_EVENT_GROUP 30
#define MIO_LOWER_EVENT_GROUP 31
#define QUAD_UPPER_EVENT_GROUP 30
#define QUAD_LOWER_EVENT_GROUP 31
#define SMPC_GROUP_WIDTH 16

static CUprofResult voltaPerfmonAddSMCounterEntryForHWPMMux(CUeventGroup *pEventGroup, CUdomainData *pDomainData, CUeventInfo *pEventInfo, NvBool *bAdded, NvU32 *maxSignals)
{
    NvU32 i = 0, startPos = 0;
    CUprofResult status = CUPROF_SUCCESS;
    CUSMCtrInfo  *pSM = NULL;
    CUeventDataHwpmMux *pEventData = NULL;
    CUeventInfo *pEventInfoTemp = NULL;
    CUeventDataSmpc *pEventDataTemp = NULL;
    uint32_t upperEventGroup = 0, lowerEventGroup = 0;

    pSM = pEventGroup->arch.voltaEventGroup->pSM;
    pEventData = (CUeventDataHwpmMux*)pEventInfo->pEventData;

   *maxSignals = (CU_PROF_SM_CORE_PROFILED_MAX + CU_PROF_SM_QUAD_PROFILED_MAX);

    if(pSM->SMCountersAdded < *maxSignals) {
        switch(pEventData->pmUnitId)
        {
        case PM_UNIT_SMCORE:
        case PM_UNIT_MIO:
            if(pSM->numGroupsCore == CU_PROF_SM_CORE_PROFILED_MAX) {
                return CUPROF_ERROR_NOT_COMPATIBLE;
            }
            break;
        case PM_UNIT_SMQCTL:
            if (pSM->qctlCount == CU_PROF_SM_QUAD_PROFILED_MAX) {
                return CUPROF_ERROR_NOT_COMPATIBLE;
            }
            break;
        }
        pEventInfoTemp = (CUeventInfo *) calloc (1, sizeof(CUeventInfo));
        if(pEventInfoTemp == NULL) {
            return CUPROF_ERROR_OUT_OF_MEMORY;
        }
        pEventDataTemp = (CUeventDataSmpc *) calloc (1, sizeof(CUeventDataSmpc));
        if(pEventDataTemp == NULL) {
            free(pEventInfoTemp);
            return CUPROF_ERROR_OUT_OF_MEMORY;
        }

        pEventInfoTemp->signalTableType = PERF_SIG_TABLE_TYPE_SMPC;
        pEventInfoTemp->pEventData = (void*)pEventDataTemp;
        pEventDataTemp->signalId = pEventData->signalId;
        pEventDataTemp->pSignalName = pEventData->pSignalName;
        pEventDataTemp->eventGroup = pEventData->eventGroup;
        pEventDataTemp->pmUnitId = pEventData->pmUnitId;
        pEventDataTemp->busWidth = pEventData->busWidth;
        pEventDataTemp->signalId_filter = 0;
        //Need to get perfevent in pm_programming guide, else difficult to add in the SM events
        //Configure for increment, for HWPM experiments have to consider width of increment signal
        pEventDataTemp->function =  (1<<pEventData->busWidth) - 1;

        switch(pEventData->pmUnitId)
        {
        case PM_UNIT_SMCORE:
            upperEventGroup = SMCORE_UPPER_EVENT_GROUP;
            lowerEventGroup = SMCORE_LOWER_EVENT_GROUP;
            pEventDataTemp->signalId_filter = VOLTA_SM_SM_NOT_IN_TRAP;
            break;
        case PM_UNIT_MIO:
            upperEventGroup = MIO_UPPER_EVENT_GROUP;
            lowerEventGroup = MIO_LOWER_EVENT_GROUP;
            pEventDataTemp->signalId_filter = VOLTA_SM_SM_NOT_IN_TRAP;
            break;
        case PM_UNIT_SMQCTL:
            upperEventGroup = QUAD_UPPER_EVENT_GROUP;
            lowerEventGroup = QUAD_LOWER_EVENT_GROUP;
            pEventDataTemp->signalId_filter = VOLTA_SM_SM_NOT_IN_TRAP_QUAD;
            break;
        }
        startPos = pEventData->startPos; 
        if (pEventData->startPos < (SMPC_GROUP_WIDTH>>1) ) {
            CU_ASSERT((pEventData->startPos + pEventData->busWidth) <= (SMPC_GROUP_WIDTH>>1));
            pEventDataTemp->eventGroup = upperEventGroup;
        }
        else{
            pEventDataTemp->eventGroup = lowerEventGroup;
            startPos = pEventData->startPos - (SMPC_GROUP_WIDTH>>1);
        }

        //TBD perfevent should be derived from width and startpos of signals in SMPC
        pEventDataTemp->perfEvent = 0;
        for(i=0; i<pEventDataTemp->busWidth; i++) {
            pEventDataTemp->perfEvent |= (startPos + i) << (i*4);
        }

        //Try adding SM counter.
        {
            pSM = pEventGroup->arch.voltaEventGroup->pSM;
            //The SM counter setting will always be increment.
            status = tryAddingSmpcCounter(pEventGroup, pDomainData, pEventDataTemp);
            if (status != CUPROF_SUCCESS) {
                CU_ERROR_PRINT(("Failed to add new counter\n"));
                goto EXIT;
            }

            if(pSM->SMCountersAdded < *maxSignals) {
                pSM->splitParts[pSM->SMCountersAdded] = 1;
                pSM->sigtableInfo[pSM->SMCountersAdded] = pEventInfoTemp;
                if(0 == pEventGroup->totalCounters) {
                    pEventGroup->arch.voltaEventGroup->chipletType = pDomainData->chipletType;
                }
            }
            else {
                status = CUPROF_ERROR_MAX_LIMIT_REACHED;
                goto EXIT;
            }
            *bAdded = NV_TRUE;
            pSM->SMCountersAdded++;
        }

        CU_ASSERT(*bAdded);
    }
    else {
        status = CUPROF_ERROR_MAX_LIMIT_REACHED;
        *bAdded = NV_FALSE;
        CU_ERROR_PRINT(("Failed to add new counter\n"));
    }
    return status;
EXIT:
    if (pEventInfoTemp) free (pEventInfoTemp);
    if (pEventDataTemp) free (pEventDataTemp);
    return status;
}

CUprofResult voltaPerfmonEventGroupAddEvent(CUeventGroup *pEventGroup,
                                              NvU32 eventID)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUdomainData *pDomainData = NULL;
    void *pEventData = NULL;
    CUeventInfo *tempEventInfo = NULL;
    CUdev *pDev = NULL;
    NvBool bAdded = NV_FALSE;
    NvU32 numDomains = 0;
    NvU32 i = 0, maxSignals = 0, splitWidth = 0;
    CUSMCtrInfo  *pSM = NULL;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);
    if (pEventGroup->isEnabled) {
        // don't allow addition of events for enabled event group
        return CUPROF_ERROR_INVALID_OPERATION;
    }

    pDev = pEventGroup->pCtx->device;

    if(!pDev->state.pDomainInfo)
        return CUPROF_ERROR_UNKNOWN;

    numDomains = pDev->state.pDomainInfo->numDomains;

    if (pEventGroup->totalCounters == 0) {
        // first signal, search in all domains
        for (i = 0; i < numDomains; i++) {
            pDomainData = &pDev->state.pDomainInfo->pDomainTable[i];
            tempEventInfo = voltaLookupDomainSignalTable(pDomainData, eventID);
            if (tempEventInfo) {
                pEventData = tempEventInfo->pEventData;
                if (!pEventData) {
                    free(tempEventInfo);
                    return CUPROF_ERROR_UNKNOWN;
                }
                break;
            }
        }
        // If lookup succeeds then initialize event group
        if (tempEventInfo != NULL) {
            status = voltaInitEventGroup(pEventGroup);
            if(CUPROF_SUCCESS != status) {
                CU_DEBUG_PRINT(("voltaInitEventGroup Failed\n"));
                free(tempEventInfo);
                return status;
            }
        }
        else {
            return CUPROF_ERROR_INVALID_EVENT_ID;
        }
    }
    else {
        tempEventInfo = voltaLookupDomainSignalTable(pEventGroup->domain, eventID);
        if (tempEventInfo) {
            pEventData = tempEventInfo->pEventData;
            if (!pEventData) {
                free(tempEventInfo);
                return CUPROF_ERROR_UNKNOWN;
            }
            pDomainData = pEventGroup->domain;
        }
        else {
            for (i = 0; i < numDomains; i++) {
                pDomainData = &pDev->state.pDomainInfo->pDomainTable[i];
                tempEventInfo = voltaLookupDomainSignalTable(pDomainData, eventID);
                if (tempEventInfo) {
                    free(tempEventInfo);
                    return CUPROF_ERROR_NOT_COMPATIBLE;
                }
            }

            return CUPROF_ERROR_INVALID_EVENT_ID;
        }
    }

    // return if event is not found or it's a internal only event
    if (pEventData == NULL) {
        free(tempEventInfo);
        return CUPROF_ERROR_INVALID_EVENT_ID;
    }
    else if ((SIG_TYPE_IS_INTERNAL_EXPOSED(((CUeventDataBasic*)pEventData)->signalId)
             && (pDomainData->exposedEvents == pDomainData->maxExternalEvents)) || SIG_TYPE_IS_INTERNAL(((CUeventDataBasic*)pEventData)->signalId)) {
        free(tempEventInfo);
        return CUPROF_ERROR_INVALID_EVENT_ID;
    }
    switch(pDomainData->eventCollectionMethod) {
        case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
        case CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX:
        case CUPROF_EVENT_COLLECTION_METHOD_NVLINK_TC:
        case CUPROF_EVENT_COLLECTION_METHOD_CUPTI_SW:
            status = voltaPerfmonTryAddingCounterNew(pEventGroup,
                pDomainData,
                tempEventInfo,
                &bAdded,
                &maxSignals);
            break;
        case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
            pSM = pEventGroup->arch.voltaEventGroup->pSM;
            if(getSplittingInfo(((CUeventDataSmpc*)pEventData)->signalId, &splitWidth)) {
                status = voltaPerfmonAddSplitSignalsSM(pEventGroup, pDomainData, tempEventInfo, &bAdded, &maxSignals, splitWidth);
            }
            else {
                status = voltaPerfmonTryAddingCounterNew(pEventGroup,
                    pDomainData,
                    tempEventInfo,
                    &bAdded,
                    &maxSignals);
                if(status == CUPROF_SUCCESS) {
                    pSM->splitParts[pEventGroup->totalCounters] = 1;
                }
            }
            break;
        default:
            CU_DEBUG_PRINT(("Invalid domain attribute\n"));
            free(tempEventInfo);
            return CUPROF_ERROR_INVALID_EVENT_DOMAIN_ID;
    }
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("Failed to add new counter\n"));
        free(tempEventInfo);
        return status;
    }
    CU_ASSERT(bAdded);

    if (pEventGroup->totalCounters == 0) {
        pEventGroup->domainId = pDomainData->domainId;
        pEventGroup->domain   = pDomainData;

        voltaPerfmonGetInstanceValues(pDev, pEventGroup->domain,
            &pEventGroup->instanceCountAvail, &pEventGroup->instanceCountTotal);

        if(pEventGroup->values != NULL)
        {
            free(pEventGroup->values);
            pEventGroup->values = NULL;
        }

        if(pEventGroup->values == NULL) {
            pEventGroup->values = (NvU64*)malloc(sizeof(NvU64) * maxSignals * pEventGroup->instanceCountAvail);
            if (pEventGroup->values == NULL) {
                CU_DEBUG_PRINT(("Failed to allocate memory to event group values\n"));
                free(tempEventInfo);
                return CUPROF_ERROR_OUT_OF_MEMORY;
            }
        }
        cuosMemset(pEventGroup->values, 0, sizeof(NvU64) * maxSignals * pEventGroup->instanceCountAvail);
    }

    if (pEventGroup->pEventInfoList == NULL) {
        // event list hasn't been init yet, do it now
        status = (CUprofResult)listInit(&pEventGroup->pEventInfoList, NULL, NULL, NULL, eventIdCompareData);
        if (status != CUPROF_SUCCESS) {
            free(tempEventInfo);
            CU_ERROR_PRINT(("Failed to init linked list\n"));
            return status;
        }
    }
    // add event to the list
    listAddToTail(pEventGroup->pEventInfoList, tempEventInfo);
    pEventGroup->totalCounters++;
    return status;
}

CUprofResult voltaPerfmonEventGroupRemoveEvent(CUeventGroup *pEventGroup, NvU32 eventID) {
    CUprofResult status = CUPROF_SUCCESS;
    CUeventInfo *currEvent = NULL;
    void *eventBase = NULL;
    NvBool bAdded = NV_FALSE;
    void *data = NULL;
    NvU32 i = 0, remainingCounters = 0, maxsignals = 0, splitWidth;
    CUdomainData *pDomainData = NULL;
    CUSMCtrInfo  *pSM = NULL;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if (pEventGroup->totalCounters == 0) {
        return CUPROF_SUCCESS;
    }

    if (pEventGroup->isEnabled) {
        // don't allow removal of events for enabled event group
        return CUPROF_ERROR_INVALID_OPERATION;
    }

    // remove from list
    data = listDataRemFrom(pEventGroup->pEventInfoList, &eventID);
    if (data != NULL) {
        //Do memory cleanup as eventInfoData is a pointer to structure storing the event data and signal type info
        free(data);
        remainingCounters = pEventGroup->totalCounters - 1;

        //Destroy the earlier parsed info and recreate the structure.
        status = voltaDestroyEventGroup(pEventGroup);
        pEventGroup->totalCounters = 0;

        if(remainingCounters)
        {
            status = voltaInitEventGroup(pEventGroup);
            if(status != CUPROF_SUCCESS)
                return status;
            pDomainData = pEventGroup->domain;
            //Add remaining counters back to build the parsed info
            currEvent = (CUeventInfo*)listGetNext(pEventGroup->pEventInfoList, &eventBase);
            for (i = 0; (i < remainingCounters) && currEvent; i++, currEvent = (CUeventInfo*)listGetNext(NULL, &eventBase)) {
                switch(pDomainData->eventCollectionMethod) {
                    case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
                    case CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX:
                    case CUPROF_EVENT_COLLECTION_METHOD_CUPTI_SW:
                        status = voltaPerfmonTryAddingCounterNew(pEventGroup,
                            pEventGroup->domain,
                            currEvent,
                            &bAdded, &maxsignals);
                        break;
                    case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
                        pSM = pEventGroup->arch.voltaEventGroup->pSM;
                        if(getSplittingInfo(((CUeventDataSmpc *)currEvent->pEventData)->signalId, &splitWidth)) {
                            status = voltaPerfmonAddSplitSignalsSM(pEventGroup, pDomainData, currEvent, &bAdded, &maxsignals, splitWidth);
                        }
                        else {
                            status = voltaPerfmonTryAddingCounterNew(pEventGroup,
                                pDomainData,
                                currEvent,
                                &bAdded,
                                &maxsignals);
                            if(status == CUPROF_SUCCESS) {
                                pSM->splitParts[pEventGroup->totalCounters] = 1;
                            }
                        }
                        break;
                    default:
                        CU_DEBUG_PRINT(("Invalid domain attribute\n"));
                        return CUPROF_ERROR_INVALID_EVENT_DOMAIN_ID;
                }
                if ((status != CUPROF_SUCCESS) || (bAdded == NV_FALSE)) {
                    CU_ERROR_PRINT(("Failed to add new counter\n"));
                    return status;
                }
                CU_ASSERT(bAdded);
                pEventGroup->totalCounters++;
            }
        }
        else {
            //Destroy the event list if the removed event was the last one.
            //TBD check if Tesla needs this.
            status = (CUprofResult)listDestroy(pEventGroup->pEventInfoList);
            if (status != CUPROF_SUCCESS) {
                return status;
            }
            pEventGroup->pEventInfoList = NULL;
        }
    }
    else {
        return CUPROF_ERROR_INVALID_EVENT_ID;
    }

    return status;
}

CUprofResult voltaPerfmonEventGroupRemoveAllEvents(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 i = 0;
    void *data = NULL;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if (pEventGroup->totalCounters == 0) {
        //No event is added
        return CUPROF_SUCCESS;
    }

    if (pEventGroup->isEnabled) {
        // don't allow removal of events for enabled event group
        return CUPROF_ERROR_INVALID_OPERATION;
    }

    for (i = 0; i < pEventGroup->totalCounters; i++) {
        status = (CUprofResult)listGenericRemNodeFromHead(pEventGroup->pEventInfoList, &data);
        if (status == CUPROF_SUCCESS) {
            free(data);
        }
        else {
            return CUPROF_ERROR_UNKNOWN;
        }
    }
    CU_ASSERT(listLen(pEventGroup->pEventInfoList) == 0);
    // destroy the event list
    status = (CUprofResult)listDestroy(pEventGroup->pEventInfoList);
    if (status != CUPROF_SUCCESS) {
        return status;
    }
    pEventGroup->pEventInfoList = NULL;

    status = voltaDestroyEventGroup(pEventGroup);

    pEventGroup->totalCounters = 0;
    return status;
}

// function to enable PM module for units
static CUprofResult setPMEnableReg(const CUeventGroup *pEventGroup, NvBool bEnable)
{
    //Function to be changed for new version
    CUresult status = CUDA_SUCCESS;
    NvU32 offset[10] = {0}, value[10] = {0};
#if 0
    //Not used in currently enabled code. It will be removed once the other part is removed completely
    NvU32 count = 0;
#endif
    NvU32 i = 0;
    NvU32 chipIdx = 0, tempUnitId = 0;
    PMEnableRegInfo *pPMEnableRegInfo = NULL;
    CUvoltaEventGroup *voltaEventGroup;
    CUparsedClk *pParsedClk = NULL;

    PerfUnitTable   *pTempPerfUnitTable = NULL;

    CU_TRACE_FUNCTION();
    pParsedClk = pEventGroup->arch.voltaEventGroup->pParsedClk;
    CU_ASSERT(pParsedClk);
    voltaEventGroup = pEventGroup->arch.voltaEventGroup;

#if 1
    i = 0;
    while (pParsedClk && pParsedClk->pParsedUnit[i])
    {
        pTempPerfUnitTable = pParsedClk->pParsedUnit[i]->pPerfUnitTable;
        pPMEnableRegInfo = &pTempPerfUnitTable->pmEnableRegInfo;
        tempUnitId = pParsedClk->pParsedUnit[i]->unitId;
        switch (pEventGroup->arch.voltaEventGroup->chipletType) {
            case PM_CHIPLET_TYPE_FBP: {
                switch (tempUnitId) {
                    case PM_UNIT_FB: {
                        offset[0] = NV_FBPA_PRI_BASE_BROADCAST + pParsedClk->pParsedUnit[i]->groupSelAddress;
                        break;
                    }
                    case PM_UNIT_LTS:
                    case PM_UNIT_LTS1:
                    case PM_UNIT_LTS2:
                    case PM_UNIT_LTS_1:
                    case PM_UNIT_LTS1_1:
                    case PM_UNIT_LTS2_1: {
                        offset[0] = NV_PLTCG_LTCS_LTSS_MISC_LTC_LTS_PM;
                        break;
                    }
                    default: {
                        CU_ASSERT(0);
                    }
                }
                break;
            }
            case PM_CHIPLET_TYPE_GPC: {
                switch (tempUnitId) {
                    case PM_UNIT_MIO:
                    case PM_UNIT_SMCORE:
                    case PM_UNIT_SMQCTL: {
                        offset[0] = NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_CTRL;
                        break;
                    }
                    case PM_UNIT_TEX: {
                        offset[0] = NV_PGRAPH_PRI_GPCS_TPCS_TEX_PM_CTRL;
                        break;
                    }
                    case PM_UNIT_MPC: {
                        offset[0] = NV_PGRAPH_PRI_GPCS_TPCS_MPC_PM_CTRL;
                        break;
                    }
                    case PM_UNIT_GPCMMU:
                    case PM_UNIT_GPCMMU1: {
                        offset[0] = NV_PGRAPH_PRI_GPCS_MMU_PM;
                        break;
                    }
                    default: {
                        CU_ASSERT(0);
                    }
                }
                break;
            }
            case PM_CHIPLET_TYPE_SYS: {
                // TODO: 
                // In future, refactor such that we don't need to manually set enables.
                // These should be derived from single database.
                switch (tempUnitId) {
                    case PM_UNIT_NVTX: {
                        offset[0] = NV_PNVLTLC_TX_MULTICAST_DEBUG_MUX_CTRL;
                        break;
                    }
                    case PM_UNIT_NVRX: {
                        offset[0] = NV_PNVLTLC_RX_MULTICAST_DEBUG_MUX_CTRL;
                        break;
                    }
                    case PM_UNIT_HUBMMU:
                    case PM_UNIT_HUBMMU1: {
                        offset[0] = NV_PFB_PRI_MMU_PM;
                        break;
                    }
                    case PM_UNIT_XVE1:
                    case PM_UNIT_XVE2: {
                        offset[0] = pParsedClk->pParsedUnit[i]->groupSelAddress;
                        break;
                    }
                    case PM_UNIT_HSHUB_IG: {
                        offset[0] = pParsedClk->pParsedUnit[i]->groupSelAddress;
                        break;
                    }
                    case PM_UNIT_HSHUB_EG: {
                        offset[0] = pParsedClk->pParsedUnit[i]->groupSelAddress;
                        break;
                    }
                    case PM_UNIT_FE: {
                        offset[0] = pParsedClk->pParsedUnit[i]->groupSelAddress;
                        break;
                    }
                    case PM_UNIT_SKED: {
                        offset[0] = pParsedClk->pParsedUnit[i]->groupSelAddress;
                        break;
                    }
                    default: {
                        CU_ASSERT(0);
                    }
                }
                break;
            }
        }
        //We can use masked writes but had not used it earlier due to RM bug in masked writes
        // read the registers
        status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, 1, offset, value, 0);
        if (status != CUDA_SUCCESS) {
            return CUPROF_ERROR_HARDWARE;
        }
        //Set the fields
        if (bEnable) {
            value[0] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
        }
        else {
            value[0] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit) << (DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
        }
        //Write back registers
        status = PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, 1, offset, value, 0);
        if (status != CUDA_SUCCESS) {
            return CUPROF_ERROR_HARDWARE;
        }
        i++;
    }
#else
    for (chipIdx = 0; chipIdx < voltaEventGroup->maxChiplets; chipIdx++) {
            pParsedClk = voltaEventGroup->pParsedClk;
            i = 0;
            while(pParsedClk && pParsedClk->pParsedUnit[i]) {
                pTempPerfUnitTable = pParsedClk->pParsedUnit[i]->pPerfUnitTable;
                pPMEnableRegInfo = &pTempPerfUnitTable->pmEnableRegInfo;

                count = 0;
                switch (voltaEventGroup->chipletType) {
                    // Bug 646910 : only one instance can be selected at a time
                    // The selected instance gets the "value" field value assigned while all others instances are zeroed out
                    // TODO: this change is not complete though, refer pm_programming_guide.txt file to derive
                    // the instance type (like INVALID, NONE, TPC, WXBAR_CQ_DAISY, MXBAR_CQ_DAISY etc) and no. of instances

                    case PM_CHIPLET_TYPE_GPC:
                        // count total tpcs within the gpc
                        //TBD remove hack (assumed chipidx pointing to a gpc here. This will not be required if we had 1 perfmon/tpc)
                        //TBD Check how many texture units we have in volta and if we need to change this code.
                        if (pParsedClk->pParsedUnit[i]->unitId == PM_UNIT_MPC) {
                            count = 0;
                            //If not remove the whole if condition here.
                            offset[count++] = voltaEventGroup->priAddress[chipIdx] + pPMEnableRegInfo->regOffset;
                            offset[count++] = NV_PRI_FE_PERFMON;

                            // read _PM registers
                            status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
                            if (status != CUDA_SUCCESS) {
                                return CUPROF_ERROR_HARDWARE;
                            }
                            // set PM_ENABLE bit by ORing the read value for selected instance
                            // disable PM_ENABLE bit by ANDing the read value for all others instances
                            count = 0;
                            if(bEnable)
                            {
                                value[count++] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                                value[count]  = DRF_REPLACE(value[count], NV_PRI_FE_PERFMON_ENABLE_ENABLE, NV_PRI_FE_PERFMON_ENABLE);
                                count++;
                            }
                            else
                            {
                                value[count++] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
                                value[count++] &= ~(DRF_MASK(NV_PRI_FE_PERFMON_ENABLE)<<(DRF_SHIFT(NV_PRI_FE_PERFMON_ENABLE)));
                            }
                        }
                        else {
                            count = 0;
                            offset[count++] = voltaEventGroup->priAddress[chipIdx] + pPMEnableRegInfo->regOffset;
                            offset[count++] = NV_PRI_FE_PERFMON;
                            // read _PM registers
                            status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
                            if (status != CUDA_SUCCESS) {
                                return CUPROF_ERROR_HARDWARE;
                            }
                            count = 0;
                            // set PM_ENABLE bit by ORing the read value for selected instance
                            // disable PM_ENABLE bit by ANDing the read value for all others instances
                            if(bEnable)
                            {
                                value[count++] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                                value[count]  = DRF_REPLACE(value[count], NV_PRI_FE_PERFMON_ENABLE_ENABLE, NV_PRI_FE_PERFMON_ENABLE);
                                count++;
                            }
                            else
                            {
                                value[count++] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
                                value[count++] &= ~(DRF_MASK(NV_PRI_FE_PERFMON_ENABLE)<<(DRF_SHIFT(NV_PRI_FE_PERFMON_ENABLE)));
                            }
                            break;
                        }
                        break;
                    case PM_CHIPLET_TYPE_SYS:
                        if ((pParsedClk->pParsedUnit[i]->unitId == PM_UNIT_NVTX) ||
                            (pParsedClk->pParsedUnit[i]->unitId == PM_UNIT_NVRX)) {
                            //nvlink requires lot of mux configuration
                            count = 0;
                            offset[count] = voltaEventGroup->priAddress[chipIdx] + pPMEnableRegInfo->regOffset;

                            // set PM_ENABLE bit by ORing the read value for selected instance
                            // disable PM_ENABLE bit by ANDing the read value for all others instances
                            if(bEnable) {
                                value[count++] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                            }
                            else {
                                value[count++] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
                            }
                            
                        } else {
                            count = 0;
                            offset[count++] = voltaEventGroup->priAddress[chipIdx] + pPMEnableRegInfo->regOffset;
                            offset[count++] = NV_PRI_FE_PERFMON;

                           // read _PM registers
                           status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
                           if (status != CUDA_SUCCESS) {
                               return CUPROF_ERROR_HARDWARE;
                           }

                            count = 0;
                            // set PM_ENABLE bit by ORing the read value for selected instance
                            // disable PM_ENABLE bit by ANDing the read value for all others instances
                            if(bEnable) {
                                value[count++] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                                value[count]  = DRF_REPLACE(value[count], NV_PRI_FE_PERFMON_ENABLE_ENABLE, NV_PRI_FE_PERFMON_ENABLE);
                                count++;
                            }
                            else {
                                value[count++] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
                                value[count++] &= ~(DRF_MASK(NV_PRI_FE_PERFMON_ENABLE)<<(DRF_SHIFT(NV_PRI_FE_PERFMON_ENABLE)));
                            }
                        }
                        break;
                    case PM_CHIPLET_TYPE_FBP:
                        count = 0;
                        //TBD The changes done for GF108 can be removed as no chip in volta hs 2 FBPA per FBP
                        // everything but fbpa2pm_ltc_fb_perf_muxed_bus/NV_PFB_FBPA_*_PM is floorswept in virtual address space
                        if(pParsedClk->pParsedUnit[i]->unitId == PM_UNIT_FB) {
                            //Use broadcast register to enable PM for FBPA as unicast are giving wrong values
                            //Writing to boardcast register for each chiplet to avoid conditions, otherwise writing
                            //only once is sufficient
                            //This is not needed for GF108 as it has only 1 FB chiplet with 2 FBPA and address of
                            //both FBPAs are different.
                                offset[count++] = NV_FBPA_PRI_BASE_BROADCAST + pPMEnableRegInfo->regOffset;
                                offset[count++] = NV_PRI_FE_PERFMON;
                            // read _PM registers
                            status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
                            if (status != CUDA_SUCCESS) {
                                return CUPROF_ERROR_HARDWARE;
                            }
                                count = 0;
                            // set PM_ENABLE bit by ORing the read value for selected instance
                            // disable PM_ENABLE bit by ANDing the read value for all others instances
                            if(bEnable)
                            {
                                    value[count++] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                                    value[count]  = DRF_REPLACE(value[count], NV_PRI_FE_PERFMON_ENABLE_ENABLE, NV_PRI_FE_PERFMON_ENABLE);
                                    count++;
                            }
                            else
                            {
                                    value[count++] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)
                                    <<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
                                    value[count++] &= ~(DRF_MASK(NV_PRI_FE_PERFMON_ENABLE)<<(DRF_SHIFT(NV_PRI_FE_PERFMON_ENABLE)));
                            }

                        }
                        else {
                            //For LTC units write into the selected unit directly
                            count = 0;
                            // Required for GM20X: Use broadcast registers (Bug 200001628)
                            offset[count++] = NV_PLTCG_LTCS_LTSS_MISC_LTC_LTS_PM;
                            offset[count++] = NV_PRI_FE_PERFMON;

                            status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
                            if (status != CUDA_SUCCESS) {
                                return CUPROF_ERROR_HARDWARE;
                            }
                            //for volta 2nd level mux is removed that required a slice to be chosen
                            count = 0;
                            //In Pascal, all LTS can be enabled simultaneously.
                            if(bEnable) {
                                    value[count++] |= (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
                                    value[count]  = DRF_REPLACE(value[count], NV_PRI_FE_PERFMON_ENABLE_ENABLE, NV_PRI_FE_PERFMON_ENABLE);
                                    count++;
                            }
                            else {
                                    value[count++] &= ~(DRF_MASK(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)<<(DRF_SHIFT(pPMEnableRegInfo->lastBit : pPMEnableRegInfo->firstBit)));
                                    value[count++] &= ~(DRF_MASK(NV_PRI_FE_PERFMON_ENABLE)<<(DRF_SHIFT(NV_PRI_FE_PERFMON_ENABLE)));
                            }
                        }

                        break;
                    default:
                        CU_ERROR_PRINT(("Not a valid chiplet type.\n"));
                        break;
                }
                status = PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
                if (status != CUDA_SUCCESS) {
                    return CUPROF_ERROR_HARDWARE;
                }
                i++;
            }
        }
#endif
    return CUPROF_SUCCESS;
}

#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV100
// no of available ltc units after floorsweep
static CUprofResult getLtcFloorsweeping(CUctx* ctx,
                                        NvU32 **virtualtoPhysicalRopL2UnitIndex,
                                        NvU32 *totalActiveRopL2Count,
                                        NvU32 *ropL2PerFbpCount)
{
    NvU32 activefbp = 0, fbpDisableMask = 0, ropL2DisableMask = 0;
    NvU32 i = 0, maxRopL2Count = 0, ropL2Idx = 0, fsRopL2CountInFbp = 0;

    if (ctx->device->dmalType == CU_DMAL_AMODEL) {
        //For a-model set fbpcount = 1
        *totalActiveRopL2Count = 1;
        virtualtoPhysicalRopL2UnitIndex[0][0] = 0;
        return CUPROF_SUCCESS;
    }

    //Total ROP L2 count
    maxRopL2Count = ctx->device->state.limits.maxFbps *
                    MAX_ROP_L2_UNITS_PER_FBP_GP100_GP10Y;

    fbpDisableMask = ctx->device->state.limits.fbpDisableMask;

    *totalActiveRopL2Count = 0;
    activefbp = 0;
    for (i = 0;
         i < ctx->device->state.limits.maxFbps;
         fbpDisableMask >>= 1, i++) {

        //Following var stores the rop_l2 indes considering floorsweeping
        fsRopL2CountInFbp = 0;
        ropL2DisableMask = ctx->device->state.limits.ropL2DisableMask[i];
        //Get floorswept count for ropL2Idx units
        for (ropL2Idx = 0; ropL2Idx < MAX_ROP_L2_UNITS_PER_FBP_GP100_GP10Y;
             ropL2DisableMask >>= 1, ropL2Idx++) {

            if ((ropL2DisableMask & 1) == 0) {
                //pmm addrses space of rop_l2 unit is not floorswept
                virtualtoPhysicalRopL2UnitIndex[activefbp][fsRopL2CountInFbp] = ropL2Idx; 
                (*totalActiveRopL2Count)++;
                fsRopL2CountInFbp++;
                ropL2PerFbpCount[activefbp]++;
            }
        }
        if ((fbpDisableMask & 1) == 0) {
            activefbp++;
        }
    }
#if 0
    for (i=0; i<ctx->device->state.limits.maxFbps; i++) 
    {
        printf("ROP_L2 in fbp[%d] = %d\n", i, ropL2PerFbpCount[i]);
    }
    printf("activefbp = %d\n", activefbp);
#endif
    CU_ASSERT(*totalActiveRopL2Count <= maxRopL2Count);
    return CUPROF_SUCCESS;
}
#endif

// Index of available TPCs after floorsweep
static CUprofResult getVirtualTpcIdx(CUctx* ctx, NvU32 **virtualtoPhysicalTpcIndex, NvU32 *gpcCount)
{
    NvU32 tpcDisableMask = 0, maxtpcCount = 0, tpcCount = 0;
    NvU32 gpc = 0, tpc = 0;

    maxtpcCount = ctx->device->state.limits.maxTpcsPerGpc;

    if (ctx->device->dmalType == CU_DMAL_AMODEL) {
        //For a-model set gpcmask properly
        for(gpc = 0; gpc < *gpcCount; gpc++) {
            for(tpc = 0; tpc < ctx->device->state.limits.numTpcsPerGpc[gpc]; tpc++) {
                ctx->device->state.limits.gpcTpcMask[gpc] |= 1 << tpc;
            }
        }
    }

    for(gpc = 0; gpc < *gpcCount; gpc++)
    {
        tpcCount = 0;
        //Read floorsweeping status for the engine
        tpcDisableMask = ctx->device->state.limits.gpcTpcMask[gpc];
        CU_DEBUG_PRINT(("GpcTpc Mask for GPC:%d =  0x%.08x\n", gpc,tpcDisableMask));

        for(tpc = 0; tpc < maxtpcCount; tpcDisableMask>>=1, tpc++)
        {
            if((tpcDisableMask & 1) != 0)
            {
                virtualtoPhysicalTpcIndex[gpc][tpcCount] = tpc;
                tpcCount++;
            }
        }
        CU_ASSERT(tpcCount == ctx->device->state.limits.numTpcsPerGpc[gpc]);
    }

    return CUPROF_SUCCESS;
}

//Since SM PMM addresses are required for sampling as well, carving out the function to set
//them considering floorsweeping
static CUprofResult getSMPMMAddress(CUctx *ctx, NvU32 *pmmAddress, NvU32 *maxInstances) {
    NvU32  **virtualtoPhysicalTpcIndex = NULL, gpcCount = ctx->device->state.limits.numGpcs;
    NvU32 gpcId = 0, tpcId = 0, SMIdx = 0, index = 0;
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 currNumTpcs = 0, maxNumTpcs = 0;

    virtualtoPhysicalTpcIndex = (NvU32 **)malloc(sizeof(NvU32 *) * gpcCount);
    if (!virtualtoPhysicalTpcIndex) {
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }
    for (index = 0; index < gpcCount; index++)
    {
        virtualtoPhysicalTpcIndex[index] = (NvU32 *)malloc(sizeof(NvU32)* ctx->device->state.limits.maxTpcsPerGpc);
        if (!virtualtoPhysicalTpcIndex[index]) {
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto EXIT;
        }
    }
    status = getVirtualTpcIdx(ctx, virtualtoPhysicalTpcIndex, &gpcCount);
    if (status != CUPROF_SUCCESS) {
        goto EXIT;
    }
    CU_ASSERT(gpcCount);
    SMIdx = 0;
    maxNumTpcs = ctx->device->state.limits.maxTpcsPerGpc;
    for (gpcId = 0; gpcId < gpcCount; gpcId++) {
        currNumTpcs = ctx->device->state.limits.numTpcsPerGpc[gpcId];
        for (tpcId = 0; tpcId < currNumTpcs; tpcId++) {
            // Volta has 2 SMs per TPC.
            for (index = 0; index < ctx->device->state.limits.numSmsPerTpc; index++) {
                // Note that all gpctpcA PMM offsets precede all gpctpcB ones
                // gpc0tpc0A, gpc0tpc1A, gpc0tpc2A,...   followed by
                // gpct0pc0B, gpc0tpc1B, gpc0tpc2B,...
                pmmAddress[SMIdx] = NV_PERF_PMMGPC_BASE + gpcId * NV_PERF_PMMGPC_CHIPLET_OFFSET + (virtualtoPhysicalTpcIndex[gpcId][tpcId] + (index * maxNumTpcs)) * NV_PMM_DOMAIN_OFFSET;
                SMIdx++;
            }
        }
    }
    *maxInstances = SMIdx;
EXIT:
    if (virtualtoPhysicalTpcIndex) {
        for (index = 0; index < gpcCount; index++) {
            free(virtualtoPhysicalTpcIndex[index]);
        }
        free(virtualtoPhysicalTpcIndex);
    }
    return status;
}

static CUprofResult allocateMemoryForCounterValuesSMPC(const CUeventGroup *pEventGroup)
{
    CUSMCtrInfo  *pSM = NULL;

    pSM = pEventGroup->arch.voltaEventGroup->pSM;

    if ((pSM) && (pSM->SMCountersAdded)) {
        if(pSM->values == NULL) {
            //Allocate memory for max SMPC counters
            pSM->values = (NvU64 *) malloc(pEventGroup->instanceCountAvail     * //no of chiplets
                (CU_PROF_SM_CORE_PROFILED_MAX + CU_PROF_SM_QUAD_PROFILED_MAX)  * //no of counters to be profiled in this domain
                sizeof(NvU64));
            if(pSM->values == NULL)
            {
                return CUPROF_ERROR_OUT_OF_MEMORY;
            }
        }
        cuosMemset(pSM->values, 0, sizeof(NvU64) * pEventGroup->instanceCountAvail * pSM->SMCountersAdded);
    }
    return CUPROF_SUCCESS;
}

static void resetPMTarget(const CUeventGroup *pEventGroup) {
    CUvoltaEventGroup  *voltaEventGroup;
    voltaEventGroup = pEventGroup->arch.voltaEventGroup;

    //It is possible that after eventgroup disable, the user can remove all ids
    //and add id from different domain. So the pmmaddress/priaddress need to be
    //recalculated for that chiplet.
    //Free pmm/pri address pointers otherwise they cause memory leak
    if (voltaEventGroup->pmmAddress) {
        free(voltaEventGroup->pmmAddress);
        voltaEventGroup->pmmAddress = NULL;
    }
    if (voltaEventGroup->priAddress) {
        free(voltaEventGroup->priAddress);
        voltaEventGroup->priAddress = NULL;
    }
}

#define NVLINK_PRI_STRIDE 0x8000
#define NV_PNVLTLC_TX0_START 0x00a16000
#define NV_PNVLTLC_RX0_START 0x00a16800

static CUprofResult setupPMTarget(const CUeventGroup *pEventGroup)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 gpcId = 0, tpcId = 0, gpcCount = 0, tpcCount = 0, maxtpc = 0, totalTPCCount = 0;
    NvU32 i = 0, SMIdx = 0;
    NvU32 fbpCount = 0, tpcSelected = 0, maxtpcCount;
    CUparsedClk  *pParsedClk = NULL;
    CUvoltaEventGroup  *voltaEventGroup;
    NvU32  **virtualtoPhysicalTpcIndex = NULL;

    //For PM signals
    voltaEventGroup = pEventGroup->arch.voltaEventGroup;
    pParsedClk = pEventGroup->arch.voltaEventGroup->pParsedClk;

    CU_TRACE_FUNCTION();

    //Set unitcast and broadcast addresses both as broadcast are used for configuration and
    //unicast are required for reading counter values.
    switch(pEventGroup->arch.voltaEventGroup->chipletType)
    {
        //Allocate structure for chiplets that store the base address for the PRI registers for each chiplet
    case PM_CHIPLET_TYPE_SYS:
        voltaEventGroup->maxChiplets = VOLTA_NVLINK_MAX_LINKS;
        voltaEventGroup->pmmAddress = (NvU32 *) malloc(sizeof(NvU32) * voltaEventGroup->maxChiplets);
        voltaEventGroup->priAddress = (NvU32 *) malloc(sizeof(NvU32) * voltaEventGroup->maxChiplets);
        if (!(voltaEventGroup->pmmAddress && voltaEventGroup->priAddress))
        {
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto EXIT;
        }

        //Apart from nvlink perfmons, no other domain has broadcast by perfmon type enabled 
        //and sys chiplet has only 1 instance so broadcast by perfmon index is not applicable
        voltaEventGroup->broadcastType = BROADCAST_NONE;

        if (pEventGroup->domain->domainId == VOLTA_CLK_DOMAIN_GV100_NVLTX0) {
            voltaEventGroup->broadcastType = BROADCAST_PERFMON_TYPE;
            voltaEventGroup->pmmBroadcastInstances = 1;
            voltaEventGroup->pmmPMMBroadcastAddress[0] = NV_PERF_PMMSYS_SYSGS_NVLTX;

            //Update nvlink addresses
            for (i = 0; i < voltaEventGroup->maxChiplets; i++) {
                voltaEventGroup->priAddress[i] = NV_PNVLTLC_TX0_START + (i * NVLINK_PRI_STRIDE);
                //A hack here to access the multiple domains of nvlinks.
                //The getClkIdx function will return same value for all nvtx0.
                //So we add the domain offset in pmmaddress here else we will have to expose separate
                //domain for each tpc, resulting in multiple signal tables etc.
                voltaEventGroup->pmmAddress[i] = NV_PERF_PMMSYS_BASE + i * NV_PMM_DOMAIN_OFFSET;
            }
        }
        else if (pEventGroup->domain->domainId == VOLTA_CLK_DOMAIN_GV100_NVLRX0) {
            voltaEventGroup->broadcastType = BROADCAST_PERFMON_TYPE;
            voltaEventGroup->pmmBroadcastInstances = 1;
            voltaEventGroup->pmmPMMBroadcastAddress[0] = NV_PERF_PMMSYS_SYSGS_NVLRX;

            for (i = 0; i < voltaEventGroup->maxChiplets; i++) {
                voltaEventGroup->priAddress[i] = NV_PNVLTLC_RX0_START + (i * NVLINK_PRI_STRIDE);
                //A hack here to access the multiple domains of nvlinks.
                //The getClkIdx function will return same value for all nvtx0.
                //So we add the domain offset in pmmaddress here else we will have to expose separate
                //domain for each tpc, resulting in multiple signal tables etc.
                voltaEventGroup->pmmAddress[i] = NV_PERF_PMMSYS_BASE + i * NV_PMM_DOMAIN_OFFSET;
            }
        }
        else {
            voltaEventGroup->maxChiplets = 1;
            // TODO: it seems units under chiplet SYS have absolute address
            // in spec file, thus keeping priAddress = 0. Verify it
            voltaEventGroup->priAddress[0] = 0;
            voltaEventGroup->pmmAddress[0] = NV_PERF_PMMSYS_BASE;
        }
        //sys chiplet has only one instance to perfmon index broadcast is not possible.
        CU_ASSERT(voltaEventGroup->broadcastType != BROADCAST_PERFMON_INDEX);
        break;

    case PM_CHIPLET_TYPE_GPC:
        //TBD Shift the gpc processing related part to a function.

        // handle floor-sweeping case
        // On fermi the floorsweeping has all been abstracted to SW so that we dont worry about what units are swept,
        // we really just care about how many of each unit we have, and access them sequentially from [0-max]
        // the HW deals with mapping them internally
        gpcCount = pEventGroup->pCtx->device->state.limits.numGpcs;   // no. of available GPCs after floorsweep
        maxtpcCount = pEventGroup->pCtx->device->state.limits.maxTpcsPerGpc;
        voltaEventGroup->gpcCount = gpcCount;
        voltaEventGroup->tpcPerGpcCount = pEventGroup->pCtx->device->state.limits.numTpcsPerGpc;

        if((CUPROF_EVENT_COLLECTION_METHOD_HWPM == pEventGroup->domain->eventCollectionMethod) ||
           (CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX == pEventGroup->domain->eventCollectionMethod)) {
            //Default initialize with the perfmon index type which is applicable for any domain
            voltaEventGroup->broadcastType = BROADCAST_PERFMON_INDEX;
            voltaEventGroup->pmmPMMBroadcastAddress[0] = NV_PERF_PMMGPC_GPCS +
                getClkIdx(pEventGroup->pCtx, pEventGroup->domain->domainId, PM_CHIPLET_TYPE_GPC)
                * NV_PMM_DOMAIN_OFFSET;
            voltaEventGroup->pmmBroadcastInstances = 1;
        }

        if ((VOLTA_CLK_DOMAIN_GV100_GPC0 == pEventGroup->domain->domainId) ||
            (VOLTA_CLK_DOMAIN_GV100_GPC1 == pEventGroup->domain->domainId) ||
            (VOLTA_CLK_DOMAIN_GV11B_GPC0 == pEventGroup->domain->domainId) ||
            (VOLTA_CLK_DOMAIN_GV11B_GPC1 == pEventGroup->domain->domainId)) {
            voltaEventGroup->pmmAddress = (NvU32 *) malloc(sizeof(NvU32) * gpcCount);
            voltaEventGroup->priAddress = (NvU32 *) malloc(sizeof(NvU32) * gpcCount);
            if (!(voltaEventGroup->pmmAddress && voltaEventGroup->priAddress))
            {
                status = CUPROF_ERROR_OUT_OF_MEMORY;
                goto EXIT;
            }

            voltaEventGroup->maxChiplets = gpcCount;

            for (gpcId = 0; gpcId < gpcCount; gpcId++) {
                voltaEventGroup->priAddress[gpcId] = NV_GPC_PRI_BASE + gpcId * NV_GPC_PRI_STRIDE;
                voltaEventGroup->pmmAddress[gpcId] = NV_PERF_PMMGPC_BASE + gpcId * NV_PERF_PMMGPC_CHIPLET_OFFSET;
            }

            break;
        }

        //Following is default setup for gpctpc domain.
        voltaEventGroup->maxChiplets = pEventGroup->pCtx->device->state.limits.numGpcs * 
                                       pEventGroup->pCtx->device->state.limits.maxTpcsPerGpc * 
                                       pEventGroup->pCtx->device->state.limits.numSmsPerTpc;
        voltaEventGroup->pmmAddress = (NvU32 *) malloc(sizeof(NvU32) * voltaEventGroup->maxChiplets);
        voltaEventGroup->priAddress = (NvU32 *) malloc(sizeof(NvU32) * voltaEventGroup->maxChiplets);
        if (!(voltaEventGroup->pmmAddress && voltaEventGroup->priAddress))
        {
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto EXIT;
        }

        //pmUnitMask for gpc is set for the selected gpc and tpc 0 will be profiled from the seleced gpc by default
        //this hack will be gone if we have 1 perfmon per tpc in volta

        if((CUPROF_EVENT_COLLECTION_METHOD_HWPM == pEventGroup->domain->eventCollectionMethod) ||
           (CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX == pEventGroup->domain->eventCollectionMethod))//HWPM
        {
            voltaEventGroup->broadcastType = BROADCAST_PERFMON_TYPE;
            //We will have to handle gpctpc case specially as this has 2 types of perfmons for 2 SMs/tpc
            voltaEventGroup->pmmBroadcastInstances = 2;
            voltaEventGroup->pmmPMMBroadcastAddress[0] = NV_PERF_PMMGPC_GPCGS_GPCTPCA;
            voltaEventGroup->pmmPMMBroadcastAddress[1] = NV_PERF_PMMGPC_GPCGS_GPCTPCB;

            //Update voltaEventGroup->maxChiplets with #SMs after floorsweeping 
            getSMPMMAddress(pEventGroup->pCtx, voltaEventGroup->pmmAddress, &voltaEventGroup->maxChiplets);

            //If we are updating PM enable and group functions to use broadcast, we can remove following loop too
            SMIdx = 0;
            for (gpcId = 0; gpcId < gpcCount; gpcId++) {
                for (tpcId = 0; tpcId < pEventGroup->arch.voltaEventGroup->tpcPerGpcCount[gpcId]; tpcId++) {
                    uint32_t index;
                    // Volta has 2 SMs per TPC.
                    for (index = 0; index < pEventGroup->pCtx->device->state.limits.numSmsPerTpc; index++) {
                        //SM_PM_CTRL register is per TPC
                        voltaEventGroup->priAddress[SMIdx] = NV_GPC_PRI_BASE + (NV_GPC_PRI_STRIDE * gpcId) + NV_TPC_IN_GPC_BASE + (NV_TPC_IN_GPC_STRIDE * tpcId);
                        SMIdx++;
                    }
                }
            }
        }
        if(CUPROF_EVENT_COLLECTION_METHOD_HWPM != pEventGroup->domain->eventCollectionMethod)
        {
            //Need for SMPC and HWPMMux both
            SMIdx = 0;
            for (gpcId = 0; gpcId < gpcCount; gpcId++) {
                for (tpcId = 0; tpcId < pEventGroup->arch.voltaEventGroup->tpcPerGpcCount[gpcId]; tpcId++) {
                    uint32_t index;
                    // Volta has 2 SMs per TPC.
                    for (index = 0; index < pEventGroup->pCtx->device->state.limits.numSmsPerTpc; index++) {
                        //SM_PM_CTRL register is per TPC
                        voltaEventGroup->priAddress[SMIdx] = NV_GPC_PRI_BASE + (NV_GPC_PRI_STRIDE * gpcId) + NV_TPC_IN_GPC_BASE + (NV_TPC_IN_GPC_STRIDE * tpcId);
                        SMIdx++;
                    }
                }
            }
            //Update voltaEventGroup->maxChiplets with #SMs after floorsweeping
            voltaEventGroup->maxChiplets = SMIdx;
        }
        break;

    case PM_CHIPLET_TYPE_FBP:
        {
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV100
            NvU32 *ropL2PerFbpCount = NULL, fbpId = 0, ropL2IdInFbp = 0, ropL2Idx = 0, i = 0, fbpaIdx = 0;
            NvU32 **virtualtoPhysicalRopL2UnitIndex = NULL, ropL2Count;
#endif
            fbpCount = pEventGroup->pCtx->device->state.limits.numFbps;

            //Default initialize with the perfmon index type which is applicable for any domain
            voltaEventGroup->broadcastType = BROADCAST_PERFMON_INDEX;
            voltaEventGroup->pmmPMMBroadcastAddress[0] = NV_PERF_PMMFBP_FBPS +
                getClkIdx(pEventGroup->pCtx, pEventGroup->domain->domainId, PM_CHIPLET_TYPE_FBP)
                * NV_PMM_DOMAIN_OFFSET;
            voltaEventGroup->pmmBroadcastInstances = 1;
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV100
            if (VOLTA_CLK_DOMAIN_GV100_LTC0 == pEventGroup->domain->domainId || VOLTA_CLK_DOMAIN_GV11B_LTC0 == pEventGroup->domain->domainId)
            {
                //LTC has perfmon type broadcast, override
                voltaEventGroup->broadcastType = BROADCAST_PERFMON_TYPE;
                voltaEventGroup->pmmPMMBroadcastAddress[0] = NV_PERF_PMMFBP_FBPGS_LTC;
                voltaEventGroup->pmmBroadcastInstances = 1;

                ropL2PerFbpCount = (NvU32 *) calloc (fbpCount, sizeof(NvU32));
                if(ropL2PerFbpCount == NULL) 
                {
                    status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
                    goto CLEANUP_ROP_L2_RESOURCES;
                }

                virtualtoPhysicalRopL2UnitIndex = (NvU32 **) calloc (fbpCount, sizeof(NvU32 *));
                if(virtualtoPhysicalRopL2UnitIndex == NULL) 
                {
                    status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
                    goto CLEANUP_ROP_L2_RESOURCES;
                }
                for (fbpId = 0; fbpId < fbpCount; fbpId++) {
                    virtualtoPhysicalRopL2UnitIndex[fbpId] = (NvU32 *) calloc (MAX_ROP_L2_UNITS_PER_FBP_GP100_GP10Y * sizeof(NvU32), 1);
                    if(virtualtoPhysicalRopL2UnitIndex[fbpId] == NULL) 
                    {
                        status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
                        goto CLEANUP_ROP_L2_RESOURCES;
                    }
                }

                // query active LTC units and its floorsweeping status
                status = getLtcFloorsweeping(pEventGroup->pCtx,
                                            virtualtoPhysicalRopL2UnitIndex,
                                            &ropL2Count, ropL2PerFbpCount);
                CU_ASSERT(ropL2Count);
                if(status != CUPROF_SUCCESS)
                    goto EXIT;

                // TODO: Query Slices per ROP L2 instead of hardcoding the value based on the chip.
                switch(pEventGroup->pCtx->device->state.chip) {
#if NVCFG(GLOBAL_ARCH_VOLTA)
                    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GV100):
                        voltaEventGroup->maxChiplets = ropL2Count * 2;
                        break;
#if NVCFG(GLOBAL_CHIP_T194) || NVCFG(GLOBAL_GPU_IMPL_GV11B)
                    case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GV11B) :
                        voltaEventGroup->maxChiplets = ropL2Count;
                        break;
#endif
#endif //NVCFG(GLOBAL_ARCH_VOLTA)
                    default:
                        CU_ASSERT(0);
                        goto EXIT;
                }

                voltaEventGroup->pmmAddress = (NvU32 *) malloc(sizeof(NvU32) * voltaEventGroup->maxChiplets);
                voltaEventGroup->priAddress = (NvU32 *) malloc(sizeof(NvU32) * voltaEventGroup->maxChiplets);
                if (!(voltaEventGroup->pmmAddress && voltaEventGroup->priAddress))
                {
                    status = CUPROF_ERROR_OUT_OF_MEMORY;
                    goto CLEANUP_ROP_L2_RESOURCES;
                }
                ropL2Idx = 0;
                //Assign the pri and pmm base addreses so that they need not be calcualted again and again
                for (fbpId = 0; fbpId < fbpCount; fbpId++) {
                    for (ropL2IdInFbp = 0; ropL2IdInFbp < ropL2PerFbpCount[fbpId]; ropL2IdInFbp++) {
                        for (i = 0; i < VOLTA_PERFMONS_PER_ROP_L2; i++) {

                            //use broadcast priAddress for enabling PM or selecting group

                            //From GM20x, there are multiple 2 rop_l2 units in each ebp chiplet and they are 
                            //independently floorsweepable. The perfmon unit's address space is not floorswept.
                            //A hack here to access the second domain from the fbp for rop_l2 unit.
                            //The getClkIdx function will return same value for all rop_l2 domain for all rop_l2s.
                            //So we add the domain offset in pmmaddress here. Else we will have to expose separate
                            //domain for each rop_l2, resulting in multiple signal tables etc.
                            if (ropL2PerFbpCount[fbpId] > 0) {
                                voltaEventGroup->pmmAddress[ropL2Idx] = NV_PERF_PMMFBP_BASE + fbpId * NV_PERF_PMMFBP_CHIPLET_OFFSET +
                                    ((virtualtoPhysicalRopL2UnitIndex[fbpId][ropL2IdInFbp]*2)+i) * NV_PMM_DOMAIN_OFFSET;
                            }
                            ropL2Idx++;
                        }
                    }
                }
CLEANUP_ROP_L2_RESOURCES:
                free(ropL2PerFbpCount);
                if (virtualtoPhysicalRopL2UnitIndex) {
                    for (fbpId = 0; fbpId < fbpCount; fbpId++) {
                        free(virtualtoPhysicalRopL2UnitIndex[fbpId]);
                    }
                    free(virtualtoPhysicalRopL2UnitIndex);
                }
                if (status != CUPROF_SUCCESS) {
                    goto EXIT;
                }
            } else {
#endif
                //Thought fbp has 2 domains, it doesn't have perfmon type broadcast, so use perfmon index
                //This will have to be handled as special case in broadcast as we need to acccess 2 perfmon domains 
                voltaEventGroup->broadcastType = BROADCAST_PERFMON_INDEX;
                voltaEventGroup->pmmPMMBroadcastAddress[0] = NV_PERF_PMMFBP_FBPS;
                voltaEventGroup->pmmPMMBroadcastAddress[1] = NV_PERF_PMMFBP_FBPS + NV_PMM_DOMAIN_OFFSET;
                voltaEventGroup->pmmBroadcastInstances = 2;

                voltaEventGroup->maxChiplets = fbpCount*2; //2 FBPA/FBP
                voltaEventGroup->pmmAddress = (NvU32 *) malloc(sizeof(NvU32) * voltaEventGroup->maxChiplets);
                voltaEventGroup->priAddress = (NvU32 *) malloc(sizeof(NvU32) * voltaEventGroup->maxChiplets);
                if (!(voltaEventGroup->pmmAddress && voltaEventGroup->priAddress))
                {
                    status = CUPROF_ERROR_OUT_OF_MEMORY;
                    goto EXIT;
                }

                for (fbpId = 0; fbpId < fbpCount; fbpId++) {
                    for (i = 0; i < VOLTA_FBPA_PER_FBP; i++) {

                        //use broadcast priAddress for enabling PM or selecting group

                        //From GM20x, there are multiple 2 rop_l2 units in each ebp chiplet and they are 
                        //independently floorsweepable. The perfmon unit's address space is not floorswept.
                        //A hack here to access the second domain from the fbp for rop_l2 unit.
                        //The getClkIdx function will return same value for all rop_l2 domain for all rop_l2s.
                        //So we add the domain offset in pmmaddress here. Else we will have to expose separate
                        //domain for each rop_l2, resulting in multiple signal tables etc.
                        voltaEventGroup->pmmAddress[fbpaIdx] = NV_PERF_PMMFBP_BASE + fbpId * NV_PERF_PMMFBP_CHIPLET_OFFSET +
                                                            i * NV_PMM_DOMAIN_OFFSET;
                        fbpaIdx++;
                    }
                }
            }
        }
        break;

    default:
        CU_ASSERT(0);
        break;
    }

    //TBD Shift values to voltaeventgroup structure to remove the following switch
    switch(pEventGroup->domain->eventCollectionMethod)
    {
    case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
        if ((pParsedClk) && (pParsedClk->totalHardwareCounters)) {
            if(pParsedClk->values == NULL) {
                //Allocate memory for max counters + 1 for elapsed_clocks
                pParsedClk->values = (NvU32 *) malloc(voltaEventGroup->maxChiplets     * //no of chiplets
                    (CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS + CU_PROF_ELAPSED_CLOCK_SLOT)  * //no of counters to be profiled in this domain
                    sizeof(NvU32));
                if(pParsedClk->values == NULL)
                {
                    status = CUPROF_ERROR_OUT_OF_MEMORY;
                    goto EXIT;
                }
            }
            cuosMemset(pParsedClk->values, 0, sizeof(NvU32) * voltaEventGroup->maxChiplets * pParsedClk->totalHardwareCounters);
        }
        break;

    case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
    case CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX:
        status = allocateMemoryForCounterValuesSMPC(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            goto EXIT;
        }
        break;

    default:
        break;
    }
#ifdef DEBUG
    {
        char szEnvironment[CUDA_PRI_REG_ENV_LEN];
        if (!(cuosGetEnv("ENABLE_PMM_UNICAST", szEnvironment, CUOS_ENV_VAR_LENGTH))) {
            //Default is broadcast but override with unicast if environment variable 
            //is set, will be used only for debugging
            pEventGroup->arch.voltaEventGroup->broadcastType = BROADCAST_NONE;
        }
    }
#endif
    goto FINAL_EXIT;
EXIT:
    free(pParsedClk->values);
    free(voltaEventGroup->pmmAddress);
    free(voltaEventGroup->priAddress);
FINAL_EXIT:
    if ((CUPROF_EVENT_COLLECTION_METHOD_HWPM == pEventGroup->domain->eventCollectionMethod) ||
        (CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX == pEventGroup->domain->eventCollectionMethod)) {
        if(virtualtoPhysicalTpcIndex) {
            for(i = 0; i < gpcCount; i++) {
                free(virtualtoPhysicalTpcIndex[i]);
            }
            free(virtualtoPhysicalTpcIndex);
        }
    }
    return status;
}
// function to configure event-groups
static CUprofResult setPMGroupReg(const CUeventGroup *pEventGroup)
{
    //Function to be changed for new version
    CUresult status = CUDA_SUCCESS;
    NvU32 offset[2], value[2];
    NvU32 chipIdx = 0, tempUnitId = 0;
    NvU32 i = 0;
    CUvoltaEventGroup *voltaEventGroup;
    CUparsedClk     *pTempParsedClk = NULL;
    CU_TRACE_FUNCTION();

    voltaEventGroup = pEventGroup->arch.voltaEventGroup;
#if 1
    //Use broadcast for all enable/groups to reduce number of register read/writes
    //Currently there is no unit (for signals that we are using) that requires more than
    // 1 mux to be selected so we can split the while loop to collect offset first
    //and then set the values of them
    pTempParsedClk = voltaEventGroup->pParsedClk;
    i = 0;
    //we can have max 4 units in any domain
    while (pTempParsedClk && pTempParsedClk->pParsedUnit[i])
    {
        tempUnitId = pTempParsedClk->pParsedUnit[i]->unitId;
        switch (pEventGroup->arch.voltaEventGroup->chipletType) {
            case PM_CHIPLET_TYPE_FBP: {
                switch (tempUnitId) {
                    case PM_UNIT_FB: {
                        offset[0] = NV_FBPA_PRI_BASE_BROADCAST + pTempParsedClk->pParsedUnit[i]->groupSelAddress;
                        break;
                    }
                    case PM_UNIT_LTS:
                    case PM_UNIT_LTS1:
                    case PM_UNIT_LTS2:
                    case PM_UNIT_LTS_1:
                    case PM_UNIT_LTS1_1:
                    case PM_UNIT_LTS2_1: {
                        offset[0] = NV_PLTCG_LTCS_LTSS_MISC_LTC_LTS_PM;
                        break;
                    }
                    default: {
                        CU_ASSERT(0);
                    }
                }
                break;
            }
            case PM_CHIPLET_TYPE_GPC: {
                switch (tempUnitId) {
                    case PM_UNIT_MIO:
                    case PM_UNIT_SMCORE:
                    case PM_UNIT_SMQCTL: {
                        offset[0] = NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_CTRL;
                        break;
                    }
                    case PM_UNIT_TEX: {
                        offset[0] = NV_PGRAPH_PRI_GPCS_TPCS_TEX_PM_CTRL;
                        break;
                    }
                    case PM_UNIT_MPC: {
                        offset[0] = NV_PGRAPH_PRI_GPCS_TPCS_MPC_PM_CTRL;
                        break;
                    }
                    case PM_UNIT_GPCMMU:
                    case PM_UNIT_GPCMMU1: {
                        offset[0] = NV_PGRAPH_PRI_GPCS_MMU_PM;
                        break;
                    }
                    default: {
                        CU_ASSERT(0);
                    }
                }
                break;
            }
            case PM_CHIPLET_TYPE_SYS: {
                switch (tempUnitId) {
                    case PM_UNIT_NVTX: {
                        offset[0] = NV_PNVLTLC_TX_MULTICAST_DEBUG_MUX_SELECT;
                        break;
                    }
                    case PM_UNIT_NVRX: {
                        offset[0] = NV_PNVLTLC_RX_MULTICAST_DEBUG_MUX_SELECT;
                        break;
                    }
                    case PM_UNIT_HUBMMU:
                    case PM_UNIT_HUBMMU1: {
                        offset[0] = NV_PFB_PRI_MMU_PM;
                        break;
                    }
                    case PM_UNIT_XVE1:
                    case PM_UNIT_XVE2: {
                        offset[0] = pTempParsedClk->pParsedUnit[i]->groupSelAddress;
                        break;
                    }
                    case PM_UNIT_HSHUB_IG: {
                        offset[0] = pTempParsedClk->pParsedUnit[i]->groupSelAddress;
                        break;
                    }
                    case PM_UNIT_HSHUB_EG: {
                        offset[0] = pTempParsedClk->pParsedUnit[i]->groupSelAddress;
                        break;
                    }
                    case PM_UNIT_FE: {
                        offset[0] = pTempParsedClk->pParsedUnit[i]->groupSelAddress;
                        break;
                    }
                    case PM_UNIT_SKED: {
                        offset[0] = pTempParsedClk->pParsedUnit[i]->groupSelAddress;
                        break;
                    }
                    default: {
                        CU_ASSERT(0);
                    }
                }
                break;
            }
        }
        //We can use masked writes but had not used it earlier due to RM bug in masked writes
        // read the registers
        status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, 1, offset, value, 0);
        if (status != CUDA_SUCCESS) {
            return CUPROF_ERROR_HARDWARE;
        }
        //Set the fields
        {
            value[0] &= ~pTempParsedClk->pParsedUnit[i]->groupSelMask;
            value[0] |= (pTempParsedClk->pParsedUnit[i]->groupSelValue & pTempParsedClk->pParsedUnit[i]->groupSelMask);
        }
        //Write back registers
        status = PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, 1, offset, value, 0);
        if (status != CUDA_SUCCESS) {
            return CUPROF_ERROR_HARDWARE;
        }
        i++;
    }
#else
    for (chipIdx = 0; chipIdx < pEventGroup->arch.voltaEventGroup->maxChiplets; chipIdx++) {
            pTempParsedClk = voltaEventGroup->pParsedClk;
            i = 0;
            while(pTempParsedClk && pTempParsedClk->pParsedUnit[i])
            {
                //The earlier design was assuming that there will be only 1 PRI base address for 1 instance of a chiplettype
                //FBP has different base addresses for LTC and FBP, to solve this currently added the pri base address to unit table.
                //This doesn't work directly for GPC as the TPC pri base address are based on gpcid and tpcid both.
                //TBD: Adding hack here, to remove this hack, we will have to add an extra loop for instance in each function.
                tempUnitId = pTempParsedClk->pParsedUnit[i]->unitId;
                if(PM_CHIPLET_TYPE_FBP == pEventGroup->arch.voltaEventGroup->chipletType) {
                    if(tempUnitId == PM_UNIT_FB) {
                        //Use broadcast register to enable PM for FBPA as unicast are giving wrong values
                        //Writing to boardcast register for each chiplet to avoid conditions, otherwise writing
                        //only once is sufficient
                        //This is not needed for GF108 as it has only 1 FB chiplet with 2 FBPA and address of
                        //both FBPAs are different.
                        offset[0] = NV_FBPA_PRI_BASE_BROADCAST + pTempParsedClk->pParsedUnit[i]->groupSelAddress;
                    }
                    else {
                        // Required for GM20X: Use broadcast registers (Bug 200001628)
                        offset[0] = NV_PLTCG_LTCS_LTSS_MISC_LTC_LTS_PM;
                    }
                }
                else {
                    offset[0] = voltaEventGroup->priAddress[chipIdx] + pTempParsedClk->pParsedUnit[i]->groupSelAddress;
                }

                // For volta, the TRM is removed. So we don't have a double layer of group
                //selection for tex.

                // read the register
                status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, 1, offset, value, 0);
                if (status != CUDA_SUCCESS) {
                    return CUPROF_ERROR_HARDWARE;
                }
                {
                    value[0] &= ~pTempParsedClk->pParsedUnit[i]->groupSelMask;
                    value[0] |= (pTempParsedClk->pParsedUnit[i]->groupSelValue & pTempParsedClk->pParsedUnit[i]->groupSelMask);
                }
                status = PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, 1, offset, value, 0);
                if (status != CUDA_SUCCESS) {
                    return CUPROF_ERROR_HARDWARE;
                }
                i++;
            }
        }
#endif
    return CUPROF_SUCCESS;
}

static CUprofResult setupPMRegistersModeB(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *value = NULL;
    NvU32 count = 0, size = 0, numReg = 0, mode = 0;
    NvU32 *domainRegOffset = NULL, maxInstances = 0;
    NvU32 chipIdx = 0, index = 0, instance = 0;
    CUvoltaEventGroup  *voltaEventGroup;
    CUparsedClk *pTempParsedClk;

    CU_TRACE_FUNCTION();

    //For PM signals
    voltaEventGroup = pEventGroup->arch.voltaEventGroup;

    if(!voltaEventGroup)
        return CUPROF_ERROR_UNKNOWN; //TBD check if we can return this error.

    //8 - reset sel+op for all 4 counters
    //8 - set sel+op for all 4 counters
    //2 - PMM_CONTROL and PMM_CONTROL2
    //4*7 - 4 counters, max 7 units/counter (tex has max 7 units)
    //1 - CONTROL3 register for sideband filtering
    //1 - CONTROL4 register for perfmon id MSB
    //TBD: Replace the magic numbers
    maxInstances = ((voltaEventGroup->maxChiplets > voltaEventGroup->pmmBroadcastInstances) ? voltaEventGroup->maxChiplets : voltaEventGroup->pmmBroadcastInstances);
    numReg = (8 + 8 + 2 + 4 * 7 + 1 + 1) * 
             ((voltaEventGroup->maxChiplets > voltaEventGroup->pmmBroadcastInstances) ? voltaEventGroup->maxChiplets : voltaEventGroup->pmmBroadcastInstances);
    size = sizeof(NvU32) * numReg;
    offset = (NvU32*)malloc(size);
    value  = (NvU32*)calloc(size, 1);
    domainRegOffset = (NvU32*)malloc(maxInstances * sizeof(NvU32));
    if (!offset || !value || !domainRegOffset) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset, value and domainRegOffset\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    status = setPMGroupReg(pEventGroup);
    if (CUPROF_SUCCESS != status) {
        goto EXIT;
    }

    if (!voltaEventGroup->pParsedClk || !voltaEventGroup->pParsedClk->totalHardwareCounters) {
        //No need to proceed if no counter is selected
        return CUPROF_SUCCESS;
    }
    pTempParsedClk = voltaEventGroup->pParsedClk;
    if ((pTempParsedClk->mode == -1) && (pTempParsedClk->totalHardwareCounters == 1)) {
          //if elapsed_cycles_sm is the only signal added, then the mode remains -1 which affects the registers below, so just set to 0.
          pTempParsedClk->mode = 0;
    }
    mode = pTempParsedClk->mode;
    if (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_2X2B6I) {
        //2X2B6I is used only in SW for setting purpose, in HW it is still 2X4B4I
        mode = NV_PMM_CONTROL_ADDTOCTR_2X4B4I;
    }

    if (voltaEventGroup->broadcastType == BROADCAST_NONE) {
        maxInstances = voltaEventGroup->maxChiplets;
        for (chipIdx = 0; chipIdx < maxInstances; chipIdx++) {
            domainRegOffset[chipIdx] = voltaEventGroup->pmmAddress[chipIdx] + voltaEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
        }
    }
    else {
        maxInstances = voltaEventGroup->pmmBroadcastInstances;
        for (instance = 0; instance < maxInstances; instance++) {
            domainRegOffset[instance] = voltaEventGroup->pmmPMMBroadcastAddress[instance];
        }
        if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING) {
            for (chipIdx = 0; chipIdx < voltaEventGroup->maxChiplets; chipIdx++) {
                //Since perfmon id is different for different domains, we need to use unicast access for NV_PMM_CONTROL
                offset[count] = voltaEventGroup->pmmAddress[chipIdx] + voltaEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET + NV_PMM_CONTROL;

                NvU16 perfmonid = 0;
                //Assign 11 bit perfmonId as follows:
                //for GPC, LSB ro MSB : 2 bits for chiplet, 2 bits for clkidx and remaining bits for instance (84 instances of gpctpc).
                //for FBP, LSB ro MSB : 2 bits for chiplet, 4 bits for clkidx (7 valid domains) and 5 bits for instances (ltc0 has 4 slices * 8 FBPs). 
                //for SYS, LSB ro MSB : 2 bits for chiplet, 5 bits for clkidx (max 32 domains) and remaining bits for instance.
                switch (pEventGroup->arch.voltaEventGroup->chipletType) {
                case PM_CHIPLET_TYPE_GPC:
                    //There is only 1 instance of sys but it can have max 8 domains so use different encoding
                    perfmonid = (pEventGroup->arch.voltaEventGroup->chipletType & 3) | ((voltaEventGroup->clkIdx & 0x3) << 2) | ((chipIdx & 0x7f) << 4);
                    break;
                case PM_CHIPLET_TYPE_FBP:
                    //TBD On volta check max no of SMs/chip
                    perfmonid = (pEventGroup->arch.voltaEventGroup->chipletType & 3) | ((voltaEventGroup->clkIdx & 0xf) << 2) | ((chipIdx & 0x1f) << 6);
                    break;
                case PM_CHIPLET_TYPE_SYS:
                    perfmonid = (pEventGroup->arch.voltaEventGroup->chipletType & 3) | ((voltaEventGroup->clkIdx & 0x1f) << 2) | ((chipIdx & 0xf) << 7);
                    break;
                default:
                    CU_ASSERT(0);
                    break;
                }
                value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_MODE_E, NV_PERF_PMMSYS_CONTROL_MODE);
                value[count] = DRF_REPLACE(value[count], mode, NV_PERF_PMMSYS_CONTROL_ADDTOCTR);
                value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_CTXSW_MODE_DISABLED, NV_PERF_PMMSYS_CONTROL_CTXSW_MODE);
                value[count] = DRF_REPLACE(value[count], pEventGroup->pCtx->pmNew->samplingPeriod, NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES);
                value[count] = DRF_REPLACE(value[count], (perfmonid & 0xff), NV_PERF_PMMSYS_CONTROL_PERFMONID);
                count++;
                offset[count] = voltaEventGroup->pmmAddress[chipIdx] + voltaEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET + NV_PMM_CONTROL4;
                value[count] = DRF_REPLACE(value[count], ((perfmonid >> 8) & 0x7), NV_PERF_PMMGPC_CONTROLD_PERFMONID_MSB);
                count++;
            }
        }

    }

    for (instance = 0; instance < maxInstances; instance++) {
        if (voltaEventGroup->pParsedClk && voltaEventGroup->pParsedClk->totalHardwareCounters) {

            offset[count] = domainRegOffset[instance] + NV_PMM_CONTROL;
            if ((pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_KERNEL) ||
                (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS)) {
                if (pEventGroup->pCtx->pmNew->isPmCtxswModeEnabled) {
                    value[count++] = (NV_PMM_CONTROL_MODE_B << NV_PMM_CONTROL_MODE__SHIFT) |
                        (mode << NV_PMM_CONTROL_ADDTOCTR__SHIFT) |
                        (NV_PMM_CONTROL_CTXSW_MODE_ENABLED << NV_PMM_CONTROL_CTXSW_MODE__SHIFT);
                }
                else {
                    value[count++] = (NV_PMM_CONTROL_MODE_B << NV_PMM_CONTROL_MODE__SHIFT) |
                        (mode << NV_PMM_CONTROL_ADDTOCTR__SHIFT) |
                        (NV_PMM_CONTROL_CTXSW_MODE_DISABLED << NV_PMM_CONTROL_CTXSW_MODE__SHIFT);
                }
            }
            else if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING){
                offset[count] = domainRegOffset[instance] + NV_PMM_CONTROL2;
                value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROLB_PTIMER_ENABLED, NV_PERF_PMMSYS_CONTROLB_PTIMER);
                count++;
            }

            offset[count] = domainRegOffset[instance] + NV_PMM_TRIG0_SEL;
            value[count++] = 0;
            offset[count] = domainRegOffset[instance] + NV_PMM_TRIG0_OP;
            value[count++] = 0;
            offset[count] = domainRegOffset[instance] + NV_PMM_TRIG1_SEL;
            value[count++] = 0;
            offset[count] = domainRegOffset[instance] + NV_PMM_TRIG1_OP;
            value[count++] = 0;
            offset[count] = domainRegOffset[instance] + NV_PMM_EVENT_SEL;
            value[count++] = 0;
            offset[count] = domainRegOffset[instance] + NV_PMM_EVENT_OP;
            value[count++] = 0;
            offset[count] = domainRegOffset[instance] + NV_PMM_SAMPLE_SEL;
            value[count++] = 0;
            offset[count] = domainRegOffset[instance] + NV_PMM_SAMPLE_OP;
            value[count++] = 0;

            if (pTempParsedClk->eventSpecUsed & NV_PMM_TRIG1) {
                offset[count] = domainRegOffset[instance] + NV_PMM_TRIG1_SEL;
                value[count++] = pTempParsedClk->watchBus[NV_PMM_TRIG1_BIT_POS];
                offset[count] = domainRegOffset[instance] + NV_PMM_TRIG1_OP;
                value[count] = DRF_REPLACE(value[count], pTempParsedClk->function[NV_PMM_TRIG1_BIT_POS], NV_PERF_PMMSYS_TRIG1_OP_FUNC);
                value[count] = DRF_REPLACE(value[count], pTempParsedClk->delaySelects[NV_PMM_TRIG1_BIT_POS], NV_PERF_PMMSYS_DSELS);
                count++;
            }

            if (pTempParsedClk->eventSpecUsed & NV_PMM_TRIG0) {
                offset[count] = domainRegOffset[instance] + NV_PMM_TRIG0_SEL;
                value[count++] = pTempParsedClk->watchBus[NV_PMM_TRIG0_BIT_POS];
                offset[count] = domainRegOffset[instance] + NV_PMM_TRIG0_OP;
                value[count] = DRF_REPLACE(value[count], pTempParsedClk->function[NV_PMM_TRIG0_BIT_POS], NV_PERF_PMMSYS_TRIG0_OP_FUNC);
                value[count] = DRF_REPLACE(value[count], pTempParsedClk->delaySelects[NV_PMM_TRIG0_BIT_POS], NV_PERF_PMMSYS_DSELS);
                count++;
            }

            if (pTempParsedClk->eventSpecUsed & NV_PMM_EVENT) {
                offset[count] = domainRegOffset[instance] + NV_PMM_EVENT_SEL;
                value[count++] = pTempParsedClk->watchBus[NV_PMM_EVENT_BIT_POS];
                offset[count] = domainRegOffset[instance] + NV_PMM_EVENT_OP;
                value[count] = DRF_REPLACE(value[count], pTempParsedClk->function[NV_PMM_EVENT_BIT_POS], NV_PERF_PMMSYS_EVENT_OP_FUNC);
                value[count] = DRF_REPLACE(value[count], pTempParsedClk->delaySelects[NV_PMM_EVENT_BIT_POS], NV_PERF_PMMSYS_DSELS);
                count++;
            }

            if (pTempParsedClk->eventSpecUsed & NV_PMM_SAMPLE) {
                offset[count] = domainRegOffset[instance] + NV_PMM_SAMPLE_SEL;
                value[count++] = pTempParsedClk->watchBus[NV_PMM_SAMPLE_BIT_POS];
                offset[count] = domainRegOffset[instance] + NV_PMM_SAMPLE_OP;
                value[count] = DRF_REPLACE(value[count], pTempParsedClk->function[NV_PMM_SAMPLE_BIT_POS], NV_PERF_PMMSYS_SAMPLE_OP_FUNC);
                value[count] = DRF_REPLACE(value[count], pTempParsedClk->delaySelects[NV_PMM_SAMPLE_BIT_POS], NV_PERF_PMMSYS_DSELS);
                count++;
            }

            //Filter configuration
            offset[count] = domainRegOffset[instance] + NV_PMM_CONTROL3;
            value[count] = pTempParsedClk->filterConfig;
            count++;
        }
    }

    CU_ASSERT(count <= numReg);
    // write signal configuration
    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

EXIT:
    free (offset);
    free (value);
    free(domainRegOffset);

    return status;
}

static CUprofResult setupPMRegistersModeCommon(const CUeventGroup *pEventGroup, NvU32* perfmonTriggerRefCount) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL;
    NvU32 *value  = NULL;
    NvU32 count = 0, chipIdx = 0, instance = 0;
    NvU32 *domainRegOffset = NULL;
    NvU32 numDomains = 0;
    NvU32 size = 0, maxInstances = 0;
    CUvoltaEventGroup  *voltaEventGroup = pEventGroup->arch.voltaEventGroup;

    CU_TRACE_FUNCTION();

    numDomains = VOLTA_PM_MAX_CHIPLET_TYPES * VOLTA_PM_MAX_CHIPLETS_PER_CHIPLET_TYPE * VOLTA_PM_MAX_DOMAIN_PER_CHIPLET;
    size  = sizeof(NvU32) * (numDomains * 6 + 16);
    offset = (NvU32*)malloc(size);
    value  = (NvU32*)calloc(size, 1);

    maxInstances = ((voltaEventGroup->maxChiplets > voltaEventGroup->pmmBroadcastInstances) ? voltaEventGroup->maxChiplets : voltaEventGroup->pmmBroadcastInstances);
    domainRegOffset = (NvU32*)malloc(maxInstances * sizeof(NvU32));
    if (!offset || !value || !domainRegOffset) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset/value/domainRegOffset\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    CU_ASSERT(voltaEventGroup->pParsedClk);
    if (!voltaEventGroup->pParsedClk->totalHardwareCounters) {
        //No need to set any register if no counter is selected
        return CUPROF_SUCCESS;
    }

    if (voltaEventGroup->broadcastType == BROADCAST_NONE) {
        maxInstances = voltaEventGroup->maxChiplets;
        for (chipIdx = 0; chipIdx < maxInstances; chipIdx++) {
            domainRegOffset[chipIdx] = voltaEventGroup->pmmAddress[chipIdx] + voltaEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
        }
    }
    else {
        maxInstances = voltaEventGroup->pmmBroadcastInstances;
        for (instance = 0; instance < maxInstances; instance++) {
            domainRegOffset[instance] = voltaEventGroup->pmmPMMBroadcastAddress[instance];
        }
    }

    // Vivek Gupta suggests disable the safety clamp before you can get pass signals to the performance monitors on net35 and above.
    // This is to prevent us being affected by cdc/async bugs inside units that feed to the monitors
    for (instance = 0; instance < maxInstances; instance++) {
        offset[count] = domainRegOffset[instance] + NV_PMM_CLAMP_CYA_CONTROL;
        value[count++] = NV_PMM_CLAMP_CYA_CONTROL_ENABLECYA_DISABLE;
        offset[count++] = domainRegOffset[instance] + NV_PERF_WBSKEW0;
        offset[count++] = domainRegOffset[instance] + NV_PERF_WBSKEW1;
        offset[count++] = domainRegOffset[instance] + NV_PERF_WBSKEW2;
        offset[count++] = domainRegOffset[instance] + NV_PERF_WBSKEW_CHAIN0;
        offset[count++] = domainRegOffset[instance] + NV_PERF_WBSKEW_CHAIN1;
    }

    if(!(*perfmonTriggerRefCount)) {
        offset[count++]  = NV_PERF_PMASYS_GPC_TRIGGER_STATUS;

        offset[count++]  = NV_PERF_PMASYS_FBP_TRIGGER_STATUS;

        offset[count++]  = NV_PERF_PMASYS_SYS_TRIGGER_STATUS;

        offset[count]  = NV_PERF_PMASYS_CONTROL;
        value[count++] = HWCONST(_PERF_PMASYS, CONTROL, STOPVPMCAPTURE, DOIT);

        offset[count++]  = NV_PERF_PMASYS_CONTROL;

        // setup PMA to push trigger to GPC chiplet
        offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_START_MASK;
        value[count++] = 0xffffffff;

        offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_STOP_MASK;
        value[count++] = 0xffffffff;

        offset[count]  = NV_PERF_PMASYS_SYS_TRIGGER_START_MASK;
        value[count++] = 0xffffffff;

        offset[count]  = NV_PERF_PMASYS_SYS_TRIGGER_STOP_MASK;
        value[count++] = 0xffffffff;

        offset[count]  = NV_PERF_PMASYS_FBP_TRIGGER_START_MASK;
        value[count++] = 0xffffffff;

        offset[count]  = NV_PERF_PMASYS_FBP_TRIGGER_STOP_MASK;
        value[count++] = 0xffffffff;
#if 1
        offset[count]  = NV_PERF_PMASYS_TRIGGER_GLOBAL;
        value[count++] = HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, ENABLE, ENABLED) |
            HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_GPC, ENABLE) |
            HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_FBP, ENABLE) |
            HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_SYS, ENABLE);
#else
        offset[count]  = NV_PERF_PMASYS_TRIGGER_GLOBAL;
        value[count++] = HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, MANUAL_START, PULSE) |
            HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, MANUAL_STOP, PULSE);
#endif
        offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_CONFIG_MIXED_MODE;
        value[count++] = 0xffffffff;
    }
    (*perfmonTriggerRefCount)++;

    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

EXIT:
    free(offset);
    free(value);
    free(domainRegOffset);

    return status;
}

static NvU32 resolveTPulse(const CUctx *ctx, const NvU32 clkIdx, const NvU32 chipletType)
{
    NvU32 const (*tPulse)[VOLTA_PM_MAX_DOMAIN_PER_CHIPLET] = NULL;
    NvU32 numericId = ~0U;

    static const NvU32 nvgv100_t_pulse[VOLTA_PM_MAX_CHIPLET_TYPES][VOLTA_PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        //#defines taken from pm_signals.h
        {GV100_NV_PERF_PMMSYS_HOST0_SIGVAL_T_PULSE, GV100_NV_PERF_PMMSYS_LMSD0_SIGVAL_T_PULSE, GV100_NV_PERF_PMMSYS_LSYS0_SIGVAL_T_PULSE, GV100_NV_PERF_PMMSYS_LXBAR0_SIGVAL_T_PULSE, GV100_NV_PERF_PMMSYS_MSD0_SIGVAL_T_PULSE, 
         GV100_NV_PERF_PMMSYS_NVLRX0_SIGVAL_T_PULSE, GV100_NV_PERF_PMMSYS_NVLRX1_SIGVAL_T_PULSE, GV100_NV_PERF_PMMSYS_NVLRX2_SIGVAL_T_PULSE, GV100_NV_PERF_PMMSYS_NVLRX3_SIGVAL_T_PULSE, GV100_NV_PERF_PMMSYS_NVLRX4_SIGVAL_T_PULSE, GV100_NV_PERF_PMMSYS_NVLRX5_SIGVAL_T_PULSE,
         GV100_NV_PERF_PMMSYS_NVLTX0_SIGVAL_T_PULSE, GV100_NV_PERF_PMMSYS_NVLTX1_SIGVAL_T_PULSE, GV100_NV_PERF_PMMSYS_NVLTX2_SIGVAL_T_PULSE, GV100_NV_PERF_PMMSYS_NVLTX3_SIGVAL_T_PULSE, GV100_NV_PERF_PMMSYS_NVLTX4_SIGVAL_T_PULSE, GV100_NV_PERF_PMMSYS_NVLTX5_SIGVAL_T_PULSE,
         GV100_NV_PERF_PMMSYS_PCIE0_SIGVAL_T_PULSE, GV100_NV_PERF_PMMSYS_PWR0_SIGVAL_T_PULSE, GV100_NV_PERF_PMMSYS_SYS0_SIGVAL_T_PULSE, GV100_NV_PERF_PMMSYS_SYS1_SIGVAL_T_PULSE, GV100_NV_PERF_PMMSYS_XBAR0_SIGVAL_T_PULSE},
        {GV100_NV_PERF_PMMGPC_GPC0_SIGVAL_T_PULSE, GV100_NV_PERF_PMMGPC_GPC1_SIGVAL_T_PULSE, GV100_NV_PERF_PMMGPC_GPCTPCA0_SIGVAL_T_PULSE},
        {GV100_NV_PERF_PMMFBP_FBP0_SIGVAL_T_PULSE, GV100_NV_PERF_PMMFBP_FBP1_SIGVAL_T_PULSE, GV100_NV_PERF_PMMFBP_LTC0_SIGVAL_T_PULSE, GV100_NV_PERF_PMMFBP_LTC1_SIGVAL_T_PULSE, GV100_NV_PERF_PMMFBP_LTC2_SIGVAL_T_PULSE, GV100_NV_PERF_PMMFBP_LTC3_SIGVAL_T_PULSE, GV100_NV_PERF_PMMFBP_ROP0_SIGVAL_T_PULSE, GV100_NV_PERF_PMMFBP_ROP1_SIGVAL_T_PULSE}
    };
    if (chipletType >= VOLTA_PM_MAX_CHIPLET_TYPES || clkIdx >= VOLTA_PM_MAX_DOMAIN_PER_CHIPLET) {
        CU_ERROR_PRINT(("Invalid chiplet/clk values\n"));
        CU_ASSERT (0);
        return numericId;
    }

    CU_TRACE_FUNCTION();

    switch(ctx->device->state.chip) {
#if NVCFG(GLOBAL_ARCH_VOLTA)
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GV100
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GV100:
#endif //NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GV100
        tPulse = nvgv100_t_pulse;
        if (tPulse) {
            numericId = tPulse[chipletType][clkIdx];
        }
        else {
            CU_ASSERT(0); // Throw assert if signal names is NULL
        }
        break;
#if NVCFG(GLOBAL_CHIP_T194) || NVCFG(GLOBAL_GPU_IMPL_GV11B)
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GV11B:
        numericId = GV11B_NV_PERF_SIGVAL_T_PULSE;
        break;
#endif
#endif //NVCFG(GLOBAL_ARCH_VOLTA)
    default:
        CU_ASSERT(0);
        return numericId;
    }
    return numericId;
}

// returns numeric value corresponding to signal name
static NvU32 resolveCoreSignalName(const CUctx *ctx, const NvU32 clkIdx, const NvU32 chipletType)
{
    NvU32 const (*signalNames)[VOLTA_PM_MAX_DOMAIN_PER_CHIPLET] = NULL;
    NvU32 numericId = ~0U;

    static const NvU32 nvgv100_pma_trigger[VOLTA_PM_MAX_CHIPLET_TYPES][VOLTA_PM_MAX_DOMAIN_PER_CHIPLET] =
    {
        //#defines taken from pm_signals.h
        {GV100_NV_PERF_PMMSYS_HOST0_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMSYS_LMSD0_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMSYS_LSYS0_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMSYS_LXBAR0_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMSYS_MSD0_SIGVAL_PMA_TRIGGER, 
         GV100_NV_PERF_PMMSYS_NVLRX0_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMSYS_NVLRX1_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMSYS_NVLRX2_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMSYS_NVLRX3_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMSYS_NVLRX4_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMSYS_NVLRX5_SIGVAL_PMA_TRIGGER,
         GV100_NV_PERF_PMMSYS_NVLTX0_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMSYS_NVLTX1_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMSYS_NVLTX2_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMSYS_NVLTX3_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMSYS_NVLTX4_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMSYS_NVLTX5_SIGVAL_PMA_TRIGGER,
         GV100_NV_PERF_PMMSYS_PCIE0_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMSYS_PWR0_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMSYS_SYS0_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMSYS_SYS1_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMSYS_XBAR0_SIGVAL_PMA_TRIGGER},
        {GV100_NV_PERF_PMMGPC_GPC0_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMGPC_GPC1_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMGPC_GPCTPCA0_SIGVAL_PMA_TRIGGER},
        {GV100_NV_PERF_PMMFBP_FBP0_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMFBP_FBP1_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMFBP_LTC0_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMFBP_LTC1_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMFBP_LTC2_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMFBP_LTC3_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMFBP_ROP0_SIGVAL_PMA_TRIGGER, GV100_NV_PERF_PMMFBP_ROP1_SIGVAL_PMA_TRIGGER}
    };
    if (chipletType >= PM_MAX_CHIPLET_TYPES || clkIdx >= VOLTA_PM_MAX_DOMAIN_PER_CHIPLET) {
        CU_ERROR_PRINT(("Invalid chiplet/clk values\n"));
        CU_ASSERT (0);
        return numericId;
    }

    CU_TRACE_FUNCTION();

    switch(ctx->device->state.chip) {
#if NVCFG(GLOBAL_ARCH_VOLTA)
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GV100
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GV100:
#endif //NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GV100
        signalNames = nvgv100_pma_trigger;
        if (signalNames) {
            numericId = signalNames[chipletType][clkIdx];
        }
        else {
            CU_ASSERT(0); // Throw assert if signal names is NULL
        }
        break;
#if NVCFG(GLOBAL_CHIP_T194) || NVCFG(GLOBAL_GPU_IMPL_GV11B)
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GV11B:
        numericId = GV11B_NV_PERF_SIGVAL_PMA_TRIGGER;
        break;
#endif
#endif //NVCFG(GLOBAL_ARCH_VOLTA)
    default:
        CU_ASSERT(0);
        break;
    }
    return numericId;
}

static CUprofResult AssertEngineModeB(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *value = NULL;
    NvU32 j = 0, size = 0, pmaTriggerSignalIndex = ~0U;
    NvU32 *domainRegOffset = NULL, maxInstances = 0;
    NvU32 chipIdx = 0, instance = 0;
    CUparsedClk  *pParsedClk = NULL;
    CUvoltaEventGroup  *voltaEventGroup;

    CU_TRACE_FUNCTION();

    //For PM signals
    pParsedClk = pEventGroup->arch.voltaEventGroup->pParsedClk;
    voltaEventGroup = pEventGroup->arch.voltaEventGroup;

    CU_ASSERT(pParsedClk);
    CU_ASSERT(voltaEventGroup);

    size = voltaEventGroup->maxChiplets * sizeof(NvU32);

    offset = (NvU32*)malloc(size);
    value = (NvU32*)malloc(size);
    maxInstances = ((voltaEventGroup->maxChiplets > voltaEventGroup->pmmBroadcastInstances) ? voltaEventGroup->maxChiplets : voltaEventGroup->pmmBroadcastInstances);
    domainRegOffset = (NvU32*)malloc(maxInstances * sizeof(NvU32));
    if (!offset || !value || !domainRegOffset) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset/value/domainRegOffset\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    if (voltaEventGroup->broadcastType == BROADCAST_NONE) {
        maxInstances = voltaEventGroup->maxChiplets;
        for (chipIdx = 0; chipIdx < maxInstances; chipIdx++) {
            domainRegOffset[chipIdx] = voltaEventGroup->pmmAddress[chipIdx] + voltaEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
        }
    }
    else {
        maxInstances = voltaEventGroup->pmmBroadcastInstances;
        for (instance = 0; instance < maxInstances; instance++) {
            domainRegOffset[instance] = voltaEventGroup->pmmPMMBroadcastAddress[instance];
        }
    }
    // assert ENGINE
    // set register NV_PERF_PMM[chipletType]_ENGINE_SEL(domain) to NV_PERF_PMM[chipletType]_[domain]_SIGVAL_PMA_TRIGGER
    // for all instances of all chipletTypes
    // like for (GPC#0 + domain GPC0) - NV_PERF_PMMGPC_ENGINE_SEL(VOLTA_CLK_DOMAIN_GPC0) = NV_PERF_PMMGPC_GPC0_SIGVAL_PMA_TRIGGER

    for (instance = 0; instance < maxInstances; instance++) {
        offset[j] = domainRegOffset[instance] + NV_PMM_ENGINE_SEL;
        // lookup the numeric value for the signal
        //TBD, check how we can put this in the domain table and get rid of resolveCoreSignalName function
        //TBD Since gpctpc0 and gpctpc1 are identical, we can safely call this function with gpctpc0 domain name only.
            
        if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING) {
            pmaTriggerSignalIndex = resolveTPulse(pEventGroup->pCtx, voltaEventGroup->clkIdx, pEventGroup->domain->chipletType);
        } else
        {
            pmaTriggerSignalIndex = resolveCoreSignalName(pEventGroup->pCtx, voltaEventGroup->clkIdx, pEventGroup->domain->chipletType);
        }
        CU_ASSERT(pmaTriggerSignalIndex != ~0U);
        value[j++] = pmaTriggerSignalIndex;
    }

    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, j, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

EXIT:
    free (offset);
    free (value);
    free(domainRegOffset);

    return status;
}

static CUprofResult StartExptModeB(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
#if 1
    NvU32 *offset = NULL, *value = NULL;
    NvU32 j = 0, size = 0;
    NvU32 *domainRegOffset = NULL, maxInstances = 0;
    NvU32 chipIdx = 0, instance = 0;
    CUvoltaEventGroup  *voltaEventGroup;

    CU_TRACE_FUNCTION();
    //For PM signals
    voltaEventGroup = pEventGroup->arch.voltaEventGroup;

    CU_ASSERT(voltaEventGroup);

    size = voltaEventGroup->maxChiplets * sizeof(NvU32);

    offset = (NvU32*)malloc(size);
    value = (NvU32*)malloc(size);
    maxInstances = ((voltaEventGroup->maxChiplets > voltaEventGroup->pmmBroadcastInstances) ? voltaEventGroup->maxChiplets : voltaEventGroup->pmmBroadcastInstances);
    domainRegOffset = (NvU32*)malloc(maxInstances * sizeof(NvU32));
    if (!offset || !value || !domainRegOffset) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset/value/domainRegOffset\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    // assert ENGINE
    // set register NV_PERF_PMM[chipletType]_ENGINE_SEL(domain) to NV_PERF_PMM[chipletType]_[domain]_SIGVAL_PMA_TRIGGER
    // for all instances of all chipletTypes
    // like for (GPC#0 + domain GPC0) - NV_PERF_PMMGPC_ENGINE_SEL(VOLTA_CLK_DOMAIN_GPC0) = NV_PERF_PMMGPC_GPC0_SIGVAL_PMA_TRIGGER
    if (voltaEventGroup->broadcastType == BROADCAST_NONE) {
        maxInstances = voltaEventGroup->maxChiplets;
        for (chipIdx = 0; chipIdx < maxInstances; chipIdx++) {
            domainRegOffset[chipIdx] = voltaEventGroup->pmmAddress[chipIdx] + voltaEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
        }
    }
    else {
        maxInstances = voltaEventGroup->pmmBroadcastInstances;
        for (instance = 0; instance < maxInstances; instance++) {
            domainRegOffset[instance] = voltaEventGroup->pmmPMMBroadcastAddress[instance];
        }
    }

    for (instance = 0; instance < maxInstances; instance++) {
            offset[j] = domainRegOffset[instance] + NV_PERF_PMM_STARTEXPERIMENT;
            value[j++] = NV_PERF_PMM_STARTEXPERIMENT_START_DOIT;
        }

    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, j, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

EXIT:
    free (offset);
    free (value);
    free(domainRegOffset);
#endif
    return status;
}

static CUprofResult startStreaming(CUctx *ctx) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *value = NULL;
    NvU32 j = 0, size = 0, regNum = 16;

    CU_TRACE_FUNCTION();
    
    size = sizeof(NvU32) * regNum;

    //If we require to setup only one register here, remove malloc
    offset = (NvU32*)malloc(size);
    value = (NvU32*)calloc(size, 1);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset/value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    if((ctx->device->dmalType != CU_DMAL_MRM)
#if cuiPlatformIncludesMrm()
#if defined(NVGPU_IOCTL_CHANNEL_CYCLE_STATS_SNAPSHOT)
       || !ctx->device->dm.mrm->nvRmGpuDeviceInfo->hasCycleStatsSnapshot
#endif
       || ctx->pmNew->isCSSDisabled
#endif
    ) {
        // For MRM NvRmGpuChannelCycleStatsAttachSnapshot takes care of setting
        // MEM_BYTES/MEM_BUMP
        j = 0;
        offset[j++] = NV_PERF_PMASYS_MEM_BYTES;

        if (CUDA_SUCCESS != PRIREAD32(ctx, CU_PRI_REG_GLOBAL, j, offset, value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }

        //The bytes read from the buffer at the time of startStreaming should be 0
        //In case of non-0, we will need to read from cpuAddrStreamingBuffer + values[0]
        //which is not supported in the code. This means that you have to take care of 
        //disabling mode E at the time of stop streaming.
        //CU_ASSERT(value[0] == 0);
        #ifdef ENABLE_SAMPLING_PRINTS
        printf("**** buffer contains data from previous runs %d bytes ***\n", value[0]);
        #endif
        //Write value read from mem_bytes to mem_bump
        j = 0;
        offset[j++] = NV_PERF_PMASYS_MEM_BUMP;

        if (CUDA_SUCCESS != PRIWRITE32(ctx, CU_PRI_REG_GLOBAL, j, offset, value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }
    }

    // assert ENGINE
    // set register NV_PERF_PMM[chipletType]_ENGINE_SEL(domain) to NV_PERF_PMM[chipletType]_[domain]_SIGVAL_PMA_TRIGGER
    // for all instances of all chipletTypes
    // like for (GPC#0 + domain GPC0) - NV_PERF_PMMGPC_ENGINE_SEL(KEPLER_CLK_DOMAIN_GPC0) = NV_PERF_PMMGPC_GPC0_SIGVAL_PMA_TRIGGER
    if (ctx->pmNew->cpuAddrStreamingBuffer) {
        j = 0;
        if((ctx->device->dmalType != CU_DMAL_MRM)
#if cuiPlatformIncludesMrm()
#if defined(NVGPU_IOCTL_CHANNEL_CYCLE_STATS_SNAPSHOT)
        || !ctx->device->dm.mrm->nvRmGpuDeviceInfo->hasCycleStatsSnapshot
#endif
        || ctx->pmNew->isCSSDisabled
#endif
        ) {
            // For MRM NvRmGpuChannelCycleStatsAttachSnapshot takes care of
            // setting PMASYS_OUTBASE/MEM_OUTBASEUPPER/OUTSIZE
            offset[j]  = NV_PERF_PMASYS_OUTBASE;
            value[j++] = ctx->pmNew->gpuAddrStreamingBuffer & 0xFFFFFFFF;

            offset[j]  = NV_PERF_PMASYS_OUTBASEUPPER;
            value[j++] = (ctx->pmNew->gpuAddrStreamingBuffer >> 32) & 0xff;

            offset[j]  = NV_PERF_PMASYS_OUTSIZE;
            value[j++] = (NvU32)ctx->pmNew->sizeStreamingBuffer;
        }

        offset[j]  = NV_PERF_PMASYS_CONTROL;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_CONTROL_STREAM_ENABLE, NV_PERF_PMASYS_CONTROL_STREAM);
        if (ctx->pmNew->isPmCtxswModeEnabled)
            value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_CONTROL_PMACTXSW_MODE_ENABLE, NV_PERF_PMASYS_CONTROL_PMACTXSW_MODE);
        else
            value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_CONTROL_PMACTXSW_MODE_DISABLE, NV_PERF_PMASYS_CONTROL_PMACTXSW_MODE);

        if((ctx->device->dmalType != CU_DMAL_MRM)
#if cuiPlatformIncludesMrm()
#if defined(NVGPU_IOCTL_CHANNEL_CYCLE_STATS_SNAPSHOT)
        || !ctx->device->dm.mrm->nvRmGpuDeviceInfo->hasCycleStatsSnapshot
#endif
        || ctx->pmNew->isCSSDisabled
#endif
        ) {
            // For MRM NvRmGpuChannelCycleStatsAttachSnapshot takes care of
            // clearing the state
            value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_CONTROL_MEMBUF_CLEAR_STATUS_DOIT, NV_PERF_PMASYS_CONTROL_MEMBUF_CLEAR_STATUS);
        }
        j++;
#if 0
        offset[j]  = NV_PERF_PMASYS_MEM_BLOCK;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_MEM_BLOCK_VALID_TRUE, NV_PERF_PMASYS_MEM_BLOCK_VALID);
        j++;

        offset[j]  = NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
        j++;
        // Set HOLD_* to TRUE
        offset[j]  = NV_PERF_PMMGPCROUTER_GLOBAL_CNTRL;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
        j++;

        offset[j]  = NV_PERF_PMMFBPROUTER_GLOBAL_CNTRL;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
        j++;
        //Then set HOLD_* to FALSE
        offset[j]  = NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_FALSE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_FALSE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
        j++;

        offset[j]  = NV_PERF_PMMGPCROUTER_GLOBAL_CNTRL;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_FALSE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_FALSE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
        j++;

        offset[j]  = NV_PERF_PMMFBPROUTER_GLOBAL_CNTRL;
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_FALSE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_FALSE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
        j++;
#endif

        //Remember to add following so that we don't miss any records
        //If MEM_BYTES = sysmem(NV_PERF_PMA_MEM_BYTES_ADDR), then there are no records
        //  in flight between PMA and system memory.

        CU_ASSERT(j <= regNum); // Used intergers do not exceed the allocated integers.
        if (CUDA_SUCCESS != PRIWRITE32(ctx, ctx->pmNew->regOpType, j, offset, value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }
        
    }
    
EXIT:
    free (offset);
    free (value);
    return status;
}

static CUprofResult stopStreaming(CUctx *ctx) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *value = NULL;
    NvU32 j = 0, size = 0; NvU32 regNum = 4;

    CU_TRACE_FUNCTION();

   size = sizeof(NvU32) * regNum;

    //If we require to setup only one register here, remove malloc
    offset = (NvU32*)malloc(size);
    value = (NvU32*)malloc(size);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset/value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }
    
    // assert ENGINE
    // set register NV_PERF_PMM[chipletType]_ENGINE_SEL(domain) to NV_PERF_PMM[chipletType]_[domain]_SIGVAL_PMA_TRIGGER
    // for all instances of all chipletTypes
    // like for (GPC#0 + domain GPC0) - NV_PERF_PMMGPC_ENGINE_SEL(KEPLER_CLK_DOMAIN_GPC0) = NV_PERF_PMMGPC_GPC0_SIGVAL_PMA_TRIGGER
    
    offset[j]  = NV_PERF_PMASYS_CONTROL;
    value[j] = 0;
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_CONTROL_STREAM_DISABLE, NV_PERF_PMASYS_CONTROL_STREAM);
    if (ctx->pmNew->isPmCtxswModeEnabled)
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_CONTROL_PMACTXSW_MODE_ENABLE, NV_PERF_PMASYS_CONTROL_PMACTXSW_MODE);
    else
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_CONTROL_PMACTXSW_MODE_DISABLE, NV_PERF_PMASYS_CONTROL_PMACTXSW_MODE);

    if((ctx->device->dmalType != CU_DMAL_MRM)
#if cuiPlatformIncludesMrm()
#if defined(NVGPU_IOCTL_CHANNEL_CYCLE_STATS_SNAPSHOT)
    || !ctx->device->dm.mrm->nvRmGpuDeviceInfo->hasCycleStatsSnapshot
#endif
    || ctx->pmNew->isCSSDisabled
#endif
    ) {
       // For MRM NvRmGpuChannelCycleStatsDetachSnapshot takes care of clearing
       // the state
        value[j] = DRF_REPLACE(value[j], NV_PERF_PMASYS_CONTROL_MEMBUF_CLEAR_STATUS_DOIT, NV_PERF_PMASYS_CONTROL_MEMBUF_CLEAR_STATUS);
    }
    j++;
/*
    offset[j]  = NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL;
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
    j++;
    // Set HOLD_* to TRUE
    offset[j]  = NV_PERF_PMMGPCROUTER_GLOBAL_CNTRL;
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
    j++;

    offset[j]  = NV_PERF_PMMFBPROUTER_GLOBAL_CNTRL;
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_MODEC);
    value[j] = DRF_REPLACE(value[j], NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES_TRUE, NV_PERF_PMMSYSROUTER_GLOBAL_CNTRL_HOLD_TIMEBASES);
    j++;
*/

    CU_ASSERT(j <= regNum); // Used intergers do not exceed the allocated integers.
    if (CUDA_SUCCESS != PRIWRITE32(ctx, ctx->pmNew->regOpType, j, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

EXIT:
    free (offset);
    free (value);
    return status;
}

CUprofResult voltaPerfmonEventGroupResetAllEvents(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);
    CU_ASSERT(pEventGroup->pCtx);


    switch(pEventGroup->domain->eventCollectionMethod)
    {
    case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
    case CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX:
        // if event group is enabled, trigger the PM  Otherwise it would have been
        // done in disable event group call
        if (pEventGroup->isEnabled) {
            //status = AssertEngineModeB(pEventGroup);
            status = StartExptModeB(pEventGroup);
        }

        if (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX) {
            if(status != CUPROF_SUCCESS) {
                return status;
            }
            if (pEventGroup->isEnabled) {
                status = (CUprofResult)resetPMSMInternal(pEventGroup);
            }
        }
        break;

    case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
        // configure PM target and SM internal registers
        if (pEventGroup->isEnabled) {
            status = (CUprofResult)resetPMSMInternal(pEventGroup);
        }
        break;
    case CUPROF_EVENT_COLLECTION_METHOD_NVLINK_TC:
        if (pEventGroup->isEnabled) {
            status = resetNvlinkCountersTC(pEventGroup);
        }
        break;
    default:
        break;
    }

    // now reset all values for the event group
    cuosMemset(pEventGroup->values, 0, sizeof(NvU64) * pEventGroup->totalCounters
        * pEventGroup->instanceCountAvail);

    return status;
}

static NV_INLINE NvBool voltaIsSoftwareCounterDomain(CUeventDomainID domainId) {
    if((domainId == VOLTA_SW_DOMAIN_GV100_FLOPS) ||
       (domainId == VOLTA_SW_DOMAIN_GV100_GLOBAL_LOAD_STORE) ||
       (domainId == VOLTA_SW_DOMAIN_GV100_INSTR_CLASS) ||
       (domainId == VOLTA_SW_DOMAIN_GV100_GENERIC_LD_ST_COUNTERS) ||
       (domainId == VOLTA_SW_DOMAIN_GV100_SHARED_LOAD_STORE) ||
       (domainId == VOLTA_SW_DOMAIN_GV100_UNIQUE_GLD_GST)) {
        return NV_TRUE;
    }

    return NV_FALSE;
}

static NV_INLINE NvBool voltaIsDeviceLevelCounterDomain(CUeventDomainID domainId) {
    if((domainId == VOLTA_CLK_DOMAIN_GV100_NVLINK_THROUGHPUT_COUNTERS) ||
       (domainId == VOLTA_CLK_DOMAIN_GV100_PCIE0) ||
       (domainId == VOLTA_CLK_DOMAIN_GV100_NVLTX0) ||
       (domainId == VOLTA_CLK_DOMAIN_GV100_NVLRX0) ||
       (domainId == VOLTA_CLK_DOMAIN_GV11B_SYS1)) {
        return NV_TRUE;
    }

    return NV_FALSE;
}

CUprofResult voltaPerfmonDomainCheckCompatible(CUctx *ctx,
                                                 CUeventDomainID domainId1,
                                                 CUeventDomainID domainId2,
                                                 NvBool *bCompatible) {
    CUprofResult status = CUPROF_SUCCESS;
    CU_TRACE_FUNCTION();

    *bCompatible = NV_TRUE;

    // __HACK_: Allow PCIE and NVLINK counters profilable in one pass with other HW unit's counters.
    // As all device level counters are compatible with each other, given no HW limitation, removing 
    // SW limitation as needed by DCGM team.
    // Note: Domain compatibility check can not be replaced with eventProfilingScope.
    if (!profilingModeDevice()) {
        // Allow device level counter domains only with same or other device level counter domain only
        if ((voltaIsDeviceLevelCounterDomain(domainId1) && !voltaIsDeviceLevelCounterDomain(domainId2)) ||
            (voltaIsDeviceLevelCounterDomain(domainId2) && !voltaIsDeviceLevelCounterDomain(domainId1))) {
                *bCompatible = NV_FALSE;
                return status;
        }
    }

    //The ppaSwCounter domains are not compatible with each other:
    if (voltaIsSoftwareCounterDomain(domainId1) &&
        voltaIsSoftwareCounterDomain(domainId2)) {
        if(domainId1 == domainId2) {
            *bCompatible = NV_TRUE;
        }
        else {
            *bCompatible = NV_FALSE;
        }
        return status;
    }
    // Bug 874703: Mix of signals from SM domain + GPCTPC domain is not working properly
    // Hence updating the DomainCheckCompatible function to avoid profiling these signals together.
    switch(ctx->device->state.chip){
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GV100
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GV100:
            {
                //HWPMMux is not allowed with SMPC or HWPM signals.
                if (((VOLTA_CLK_DOMAIN_GV100_HWPMMUX == domainId2) &&
                    (VOLTA_CLK_DOMAIN_GV100_GPCTPC == domainId1)) ||
                    ((VOLTA_CLK_DOMAIN_GV100_HWPMMUX == domainId1) &&
                    (VOLTA_CLK_DOMAIN_GV100_GPCTPC == domainId2))) {
                        *bCompatible = NV_FALSE;
                        return status;
                }

                if (((domainId2 == VOLTA_CLK_DOMAIN_GV100_HWPMMUX) &&
                    (domainId1 == VOLTA_CLK_DOMAIN_GV100_SM0)) ||
                    ((domainId1 == VOLTA_CLK_DOMAIN_GV100_HWPMMUX) &&
                    (domainId2 == VOLTA_CLK_DOMAIN_GV100_SM0))) {
                        *bCompatible = NV_FALSE;
                        return status;
                }

                if (((domainId1 == VOLTA_CLK_DOMAIN_GV100_GPCTPC) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV100_SM0) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV100_FBP0) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV100_LTC0) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV100_LTC1) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV100_HWPMMUX) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV100_GPC0) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV100_GPC1) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV100_SYS0)) &&
                    (voltaIsSoftwareCounterDomain(domainId2))) {
                        *bCompatible = NV_FALSE;
                        return status;
                }

                if (((domainId2 == VOLTA_CLK_DOMAIN_GV100_GPCTPC) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV100_SM0) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV100_FBP0) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV100_LTC0) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV100_LTC1) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV100_HWPMMUX) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV100_GPC0) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV100_GPC1) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV100_SYS0)) &&
                    (voltaIsSoftwareCounterDomain(domainId1))) {
                        *bCompatible = NV_FALSE;
                        return status;
                }

                // __HACK_: Allow PCIE and NVLINK counters profilable in one pass with other HW unit's counters.
                // As all device level counters are compatible with each other, given no HW limitation, removing 
                // SW limitation as needed by DCGM team.
                // Note: Domain compatibility check can not be replaced with eventProfilingScope.
                if (!profilingModeDevice()) {
                    if (((domainId1 == VOLTA_CLK_DOMAIN_GV100_PCIE0) ||
                        (domainId1 == VOLTA_CLK_DOMAIN_GV100_NVLTX0) ||
                        (domainId1 == VOLTA_CLK_DOMAIN_GV100_NVLRX0)) &&
                        ((domainId2 == VOLTA_CLK_DOMAIN_GV100_GPCTPC) ||
                        (domainId2 == VOLTA_CLK_DOMAIN_GV100_SM0) ||
                        (domainId2 == VOLTA_CLK_DOMAIN_GV100_FBP0) ||
                        (domainId2 == VOLTA_CLK_DOMAIN_GV100_LTC0) ||
                        (domainId2 == VOLTA_CLK_DOMAIN_GV100_LTC1) ||
                        (domainId2 == VOLTA_CLK_DOMAIN_GV100_HWPMMUX) ||
                        (domainId2 == VOLTA_CLK_DOMAIN_GV100_GPC0) ||
                        (domainId2 == VOLTA_CLK_DOMAIN_GV100_GPC1) ||
                        (domainId2 == VOLTA_CLK_DOMAIN_GV100_SYS0) ||
                        (voltaIsSoftwareCounterDomain(domainId2)))) {
                            *bCompatible = NV_FALSE;
                            return status;
                    }

                    if (((domainId2 == VOLTA_CLK_DOMAIN_GV100_PCIE0) ||
                        (domainId2 == VOLTA_CLK_DOMAIN_GV100_NVLTX0) ||
                        (domainId2 == VOLTA_CLK_DOMAIN_GV100_NVLRX0)) &&
                        ((domainId1 == VOLTA_CLK_DOMAIN_GV100_GPCTPC) ||
                        (domainId1 == VOLTA_CLK_DOMAIN_GV100_SM0) ||
                        (domainId1 == VOLTA_CLK_DOMAIN_GV100_FBP0) ||
                        (domainId1 == VOLTA_CLK_DOMAIN_GV100_LTC0) ||
                        (domainId1 == VOLTA_CLK_DOMAIN_GV100_LTC1) ||
                        (domainId1 == VOLTA_CLK_DOMAIN_GV100_HWPMMUX) ||
                        (domainId1 == VOLTA_CLK_DOMAIN_GV100_GPC0) ||
                        (domainId1 == VOLTA_CLK_DOMAIN_GV100_GPC1) ||
                        (domainId1 == VOLTA_CLK_DOMAIN_GV100_SYS0) ||
                        (voltaIsSoftwareCounterDomain(domainId1)))) {
                            *bCompatible = NV_FALSE;
                            return status;
                    }
                }
            }
            break;
#endif
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GV11B
        case (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV110 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GV11B):
            {
                //HWPMMux is not allowed with SMPC or HWPM signals.
                if (((VOLTA_CLK_DOMAIN_GV11B_HWPMMUX == domainId2) &&
                    (VOLTA_CLK_DOMAIN_GV11B_GPCTPC == domainId1)) ||
                    ((VOLTA_CLK_DOMAIN_GV11B_HWPMMUX == domainId1) &&
                    (VOLTA_CLK_DOMAIN_GV11B_GPCTPC == domainId2))) {
                        *bCompatible = NV_FALSE;
                        return status;
                }

                if (((domainId2 == VOLTA_CLK_DOMAIN_GV11B_HWPMMUX) &&
                    (domainId1 == VOLTA_CLK_DOMAIN_GV11B_SM0)) ||
                    ((domainId1 == VOLTA_CLK_DOMAIN_GV11B_HWPMMUX) &&
                    (domainId2 == VOLTA_CLK_DOMAIN_GV11B_SM0))) {
                        *bCompatible = NV_FALSE;
                        return status;
                }

                if (((domainId1 == VOLTA_CLK_DOMAIN_GV11B_GPCTPC) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV11B_SM0) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV100_FBP0) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV11B_LTC0) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV11B_LTC1) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV11B_HWPMMUX) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV11B_GPC0) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV11B_GPC1) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV11B_SYS0) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV11B_SYS1)) &&
                    (voltaIsSoftwareCounterDomain(domainId2))) {
                        *bCompatible = NV_FALSE;
                        return status;
                }

                if (((domainId2 == VOLTA_CLK_DOMAIN_GV11B_GPCTPC) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV11B_SM0) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV100_FBP0) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV11B_LTC0) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV11B_LTC1) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV11B_HWPMMUX) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV11B_GPC0) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV11B_GPC1) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV11B_SYS0) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV11B_SYS1)) &&
                    (voltaIsSoftwareCounterDomain(domainId1))) {
                        *bCompatible = NV_FALSE;
                        return status;
                }

                if (((domainId1 == VOLTA_CLK_DOMAIN_GV100_PCIE0) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV100_NVLTX0) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV100_NVLRX0)) &&
                    ((domainId2 == VOLTA_CLK_DOMAIN_GV11B_GPCTPC) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV11B_SM0) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV100_FBP0) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV11B_LTC0) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV11B_LTC1) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV11B_HWPMMUX) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV11B_GPC0) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV11B_GPC1) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV11B_SYS0) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV11B_SYS1) ||
                    (voltaIsSoftwareCounterDomain(domainId2)))) {
                        *bCompatible = NV_FALSE;
                        return status;
                }

                if (((domainId2 == VOLTA_CLK_DOMAIN_GV100_PCIE0) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV100_NVLTX0) ||
                    (domainId2 == VOLTA_CLK_DOMAIN_GV100_NVLRX0)) &&
                    ((domainId1 == VOLTA_CLK_DOMAIN_GV11B_GPCTPC) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV11B_SM0) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV100_FBP0) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV11B_LTC0) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV11B_LTC1) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV11B_HWPMMUX) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV11B_GPC0) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV11B_GPC1) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV11B_SYS0) ||
                    (domainId1 == VOLTA_CLK_DOMAIN_GV11B_SYS1) ||
                    (voltaIsSoftwareCounterDomain(domainId1)))) {
                        *bCompatible = NV_FALSE;
                        return status;
                }
            }
            break;

#endif
        default:
            CU_ASSERT(0);
            *bCompatible = NV_FALSE;  // Default case should never be encountered
            break;
    }
    return status;
}

// Function to check if domain is already enabled for profiling
static CUprofResult voltaDomainCompatible(CUctx *ctx, CUeventDomainID domainId, NvBool *bCompatible) {
    CUprofResult status = CUPROF_SUCCESS;
    CUeventGroup *currEg = NULL;
    void *eventBase = NULL;
    NvU32 i = 0;

    CU_TRACE_FUNCTION();

    *bCompatible = NV_TRUE;

    currEg = (CUeventGroup*)listGetNext(ctx->pmNew->egList, &eventBase);
    for (i = 0; (i < ctx->pmNew->totalEventGroups) && currEg; i++, currEg = (CUeventGroup*)listGetNext(NULL, &eventBase)) {

        if (currEg->isEnabled) {
            //cannot enable 2 eventgroups from same domain simultaneously
            if (currEg->domainId == domainId) {
                *bCompatible = NV_FALSE;
            }
            else {
                voltaPerfmonDomainCheckCompatible(ctx, domainId, currEg->domainId, bCompatible);
            }
            if (*bCompatible == NV_FALSE) {
                break;
            }
        }
    }

    return status;
}

CUprofResult voltaPerfmonEventGroupEnable(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    CUctx *ctx = NULL;
    NvBool bCompatible = NV_TRUE;
    CUvoltaEventGroup  *voltaEventGroup;
    char szEnvironment[CUOS_ENV_VAR_LENGTH];

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);
    //CU_ASSERT(pEventGroup->domainId < MAX_DOMAINS);

    if (!(cuosGetEnv("SMPC_LEGACY_MODE", szEnvironment, CUOS_ENV_VAR_LENGTH))) {
        pEventGroup->arch.voltaEventGroup->isSMPCLegacyMode = (NvBool)atoi(szEnvironment);
    }
    else {
        // Reverting back to legacy mode due to following bugs:
        // Hardware http://nvbugs/1923152: core snapshot registers can't be written via PRI or bundle, so in context restore, the snapshot registers cannot be restored properly causing garbage values for core counters.
        // http:/nvbugs/200292629: Snapshot has to be simulated when context is not resident else trigger will be missed. This mainly affects continuous mode
        pEventGroup->arch.voltaEventGroup->isSMPCLegacyMode = NV_TRUE;
    }

    ctx = pEventGroup->pCtx;
    // make launch blocking
    //ctx->launchBlocking = 1;
    // Setting profileALl option by default, since we don't support per instance profiling in volta.
    pEventGroup->profileAll = 1;

    status = voltaDomainCompatible(ctx, pEventGroup->domainId, &bCompatible);
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("Failed to check domain enable/disable status\n"));
        return status;
    }
    if (bCompatible == NV_FALSE) {
        CU_ERROR_PRINT(("Profiler allows to monitor only one event group from any domain\n"));
        return CUPROF_ERROR_NOT_COMPATIBLE;
    }

    // If new drive and old CUPTI, pEventGroup->eventGroupScope will be CU_EVENT_GROUP_SCOPE_FORCE_INT.
    // This will handle backward compatibility.
    if (pEventGroup->eventGroupScope == CU_EVENT_GROUP_SCOPE_FORCE_INT) {
        if (!voltaIsDeviceLevelCounterDomain(pEventGroup->domainId) &&
            !voltaIsSoftwareCounterDomain(pEventGroup->domainId)) {

            /********************************************************************************
                Set the PM CtxSw bit here as we want this feature for SM_PM_CTRL registers
                    as well which are used in SMPC signal profiling:
                Nvlink counters are not affeted by PM ctxsw, so we don't change the state
                   of PM ctxsw. If it is on, it will remain on. If it is off, it will
                   remain off.
            ********************************************************************************/
            status = perfmonSetupPMCtxswMode(ctx, NV_TRUE);

        } else {
            status = perfmonSetupPMCtxswMode(ctx, NV_FALSE);
        }
    } else {
        if ((pEventGroup->eventGroupScope == CU_EVENT_GROUP_SCOPE_DEVICE) ||
            (voltaIsSoftwareCounterDomain(pEventGroup->domainId))) {

            status = perfmonSetupPMCtxswMode(ctx, NV_FALSE);
        } else {
            /********************************************************************************
                Set the PM CtxSw bit here as we want this feature for SM_PM_CTRL registers
                    as well which are used in SMPC signal profiling:
                Nvlink counters are not affeted by PM ctxsw, so we don't change the state
                   of PM ctxsw. If it is on, it will remain on. If it is off, it will
                   remain off.
            ********************************************************************************/
            status = perfmonSetupPMCtxswMode(ctx, NV_TRUE);
        }
    }

    if (CUPROF_SUCCESS != status) {
        CU_ERROR_PRINT(("Failed to set the PM Ctxsw bit\n"));
        goto Error;
    }

    // Check if the PM CtxSw bit is enabled and assign the proper regOp type:
    pEventGroup->pCtx->pmNew->regOpType = ctx->pmNew->isPmCtxswModeEnabled ? CU_PRI_REG_CONTEXT : CU_PRI_REG_GLOBAL;

#if NVLINK_PM
    pEventGroup->pCtx->pmNew->eventCollectionMode = CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS;
#endif

    switch(pEventGroup->domain->eventCollectionMethod)
    {
    case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
    case CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX:
        voltaEventGroup = pEventGroup->arch.voltaEventGroup;
        CU_ASSERT(voltaEventGroup);
        status = setupPMTarget(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            goto Error;
        }
        if (pEventGroup->configChanged) {
            // configure PM target and mode B settings
            status = setupPMRegistersModeCommon(pEventGroup,
                &pEventGroup->pCtx->pmNew->perfmonTriggerRefCount);
            if (CUPROF_SUCCESS != status) {
                goto Error;
            }

            status = setupPMRegistersModeB(pEventGroup);
            if (CUPROF_SUCCESS != status) {
                goto Error;
            }
        }
        status = setPMEnableReg(pEventGroup, NV_TRUE);
        if (CUPROF_SUCCESS != status) {
            goto Error;
        }
#ifndef BUG_1259185_FIXED
        if (ctx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING) {
            setupStreamingResources(ctx);
        }
#endif
        status = AssertEngineModeB(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            //Release Mode B in case Assert fail.
            PMReleaseModeB(pEventGroup);
            goto Error;
        }
        if (ctx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING) {
            status = startStreaming(pEventGroup->pCtx);
            if (CUPROF_SUCCESS != status) {
                goto Error;
            }
        }
        if ((ctx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS) ||
            (ctx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING)) {
            status = StartExptModeB(pEventGroup);
            if (CUPROF_SUCCESS != status) {
                goto Error;
            }
        }
        if (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX) {
            //setupPMTarget is already done, so avoid it
            //while configuring SMPC
            status = (CUprofResult)SetupPMRegistersSMInternal(pEventGroup);
            if (CUPROF_SUCCESS != status) {
                goto Error;
            }
            status = (CUprofResult)resetPMSMInternal(pEventGroup);
            if (CUPROF_SUCCESS != status) {
                goto Error;
            }
            if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS){
                voltaPerfmonStartCounters(NULL, pEventGroup);
                status = (CUprofResult)resetPMSMInternal(pEventGroup);
                if (CUPROF_SUCCESS != status) {
                    goto Error;
                }
            }
        }
        break;
    case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
        status = setupPMTarget(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            goto Error;
        }
        if (pEventGroup->configChanged) {
            // configure PM target and SM internal registers
            status = (CUprofResult)SetupPMRegistersSMInternal(pEventGroup);
            if (CUPROF_SUCCESS != status) {
                goto Error;
            }
        }
        status = (CUprofResult)setPMEnableRegSM(pEventGroup, NV_TRUE);
        if (CUPROF_SUCCESS != status) {
            goto Error;
        }
        if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS) {
            voltaPerfmonStartCounters(NULL, pEventGroup);
            status = (CUprofResult)resetPMSMInternal(pEventGroup);
            if (CUPROF_SUCCESS != status) {
                goto Error;
            }
        }
        break;
    case CUPROF_EVENT_COLLECTION_METHOD_NVLINK_TC:
        /****************************************************************************************************
        Due to clock gating, throughput counters may inadvertently count uninitialized state unless either of 
        the following is performed:
            1.Set TL_PMCTRL_REG_ENABLE prior to turning on these counters. This will initialize the required 
                state, and this enable can then immediately be turned off again.
            2.The first time the count is enabled, immediately stop it and reset the count value, and then 
                start the real count. This will also serve to clear the uninitialized state. Counting any 
                one of the four Throughput Counters will serve to reset all four.
        ****************************************************************************************************/
        status = reserveReleaseNvlinkCounters(pEventGroup, NV_TRUE);
        if (CUPROF_SUCCESS != status) {
            goto Error;
        }
        status = setupNvlinkEnableConfigRegTC(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            goto Error;
        }
        status = setNvlinkEnableRegTC(pEventGroup, NV_TRUE);
        if (CUPROF_SUCCESS != status) {
            goto Error;
        }
        if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS) {
            voltaPerfmonStartCounters(NULL, pEventGroup);
        }
        break;
    default:
        //s/w counters do nothing
        break;
    }

    // set enable flags
    pEventGroup->isEnabled = 1;
    setDomainEventGroup(ctx->pmNew->domainEventGroupEnabled, pEventGroup->domainId, 1);

    // reset all counters
    cuosMemset(pEventGroup->values, 0, sizeof(NvU64) * pEventGroup->totalCounters
        * pEventGroup->instanceCountAvail);

    return CUPROF_SUCCESS;

    //release HWPM in case any call fails after perfmonControlHWPM
Error:
#ifndef BUG_1259185_FIXED
    cleanupStreamingResources(ctx);
#endif
    return status;
}

static CUprofResult logPMCountersModeBStreamingMode(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *values = NULL, *currPosInValueArray = NULL;
    NvU32 size = 0;
    NvU32 chipIdx = 0, i = 0, j = 0;
    CUvoltaEventGroup  *voltaEventGroup;
    CUparsedClk *pTempParsedClk = NULL;
    NvU32 memHeadPtr = 0, totalBytes = 0; //memBytes = 0
    NvU32 chipletType, clkIdx;
    NvU16 perfmonId = 0;
    CUprofStreamingRecord *recPtr;
#ifdef PRINT_EVENT_SAMPLING_RECORDS
    FILE *tempfp;
    char filename[CUOS_ENV_VAR_LENGTH+20];
#endif

    CU_TRACE_FUNCTION();
    
    voltaEventGroup = pEventGroup->arch.voltaEventGroup;
    CU_ASSERT(voltaEventGroup);

    //elapsed_clocks is always read
    size  = sizeof(NvU32) * (CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS + CU_PROF_ELAPSED_CLOCK_SLOT);

    offset = (NvU32*)malloc(size);
    values = (NvU32*)malloc(size);
    if (!offset || !values) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    offset[j]  = NV_PERF_PMASYS_MEM_BYTES;
    values[j] = 0;
    j++;
    offset[j]  = NV_PERF_PMASYS_MEM_HEAD;
    values[j] = 0;
    j++;

    // read counter values for all HW counters then populate the values in eventgroup depending on the mode 
    if (CUDA_SUCCESS != PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, j, offset, values, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

    //memBytes = GETVAL(values[0], NV_PERF_PMASYS_MEM_BYTES_NUMBYTES);
    //memHeadPtr = GETVAL(values[1], NV_PERF_PMASYS_MEM_HEAD_PTR);
    memHeadPtr = values[1];

    totalBytes = (NvU32)(memHeadPtr - pEventGroup->pCtx->pmNew->gpuAddrStreamingBuffer);
    pTempParsedClk = voltaEventGroup->pParsedClk;
    if (!pTempParsedClk) {
        free(offset);
        free(values);
        return CUPROF_ERROR_OUT_OF_MEMORY;
    }

    recPtr = (CUprofStreamingRecord *)pEventGroup->pCtx->pmNew->cpuAddrStreamingBuffer;
    if (!recPtr) goto EXIT;

    cuosMemset(pTempParsedClk->values, 0, sizeof(NvU32) * voltaEventGroup->maxChiplets * pTempParsedClk->totalHardwareCounters);

#ifdef PRINT_EVENT_SAMPLING_RECORDS
    strcpy(filename, pEventGroup->pCtx->profiler->logfile);
    strcat(filename, "_event_samples");
    tempfp = fopen(filename, "a");
    if (NULL == tempfp) {
        CU_DEBUG_PRINT(("Failed to open cuda sampling log: %s\n", filename));
        //return CUDA_ERROR_FILE_NOT_FOUND;
    }
#endif

    while(totalBytes) {
        perfmonId = 0;
        perfmonId = recPtr->perfmonId | (((recPtr->smplCnt_ds_sz >> 9) & 0x7) << 8);
        chipletType = perfmonId & 3;
        switch (chipletType) {
            case PM_CHIPLET_TYPE_SYS:
                clkIdx = (perfmonId >> 2) & 0x1f;
                chipIdx = (perfmonId >> 7) & 0xf;
                break;
            case PM_CHIPLET_TYPE_GPC:
                clkIdx = (perfmonId >> 2) & 0x3;
                chipIdx = (perfmonId >> 4) & 0x7f;
                CU_ASSERT(chipIdx < 84);
                break;
            case PM_CHIPLET_TYPE_FBP:
                clkIdx = (perfmonId >> 2) & 0xf;
                chipIdx = (perfmonId >> 6) & 0x1f;
                break;
            default:
                CU_ASSERT(0);
                return CUPROF_ERROR_UNKNOWN;
                break;
        }

        if (clkIdx != voltaEventGroup->clkIdx) {
            recPtr ++;
            totalBytes -= sizeof(CUprofStreamingRecord);
            continue;
        }

#ifdef PRINT_EVENT_SAMPLING_RECORDS
        if(tempfp && (recPtr->eventCnt || recPtr->trigger0Cnt || recPtr->trigger1Cnt || recPtr->sampleCnt)) {
            fprintf(tempfp, "0x%lx,0x%x,0x%x,%lu,%lu,%lu,%lu\n",  (long unsigned int)(((uint64_t)recPtr->timestamp39_32<<32) | recPtr->timestamp00_31), perfmonId, recPtr->smplCnt_ds_sz, (long unsigned int)recPtr->eventCnt, (long unsigned int)recPtr->trigger0Cnt, (long unsigned int)recPtr->trigger1Cnt, (long unsigned int)recPtr->sampleCnt);
        }
#endif
        values[NV_PMM_TRIG0_BIT_POS] = recPtr->trigger0Cnt;
        values[NV_PMM_TRIG1_BIT_POS] = recPtr->trigger1Cnt;
        values[NV_PMM_EVENT_BIT_POS] = recPtr->eventCnt;
        values[NV_PMM_SAMPLE_BIT_POS] = recPtr->sampleCnt;
        //Let's write timestamp in elapsed_clocks for now
        values[NV_PMM_ELAPSED_CLOCKS_BIT_POS] = recPtr->timestamp00_31;

        currPosInValueArray = (pTempParsedClk->values + (pTempParsedClk->totalHardwareCounters * chipIdx));
        for(i=0; i<pTempParsedClk->totalHardwareCounters; i++)
        {
            if (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_4444) {
                if(pTempParsedClk->eventspec[i] == NV_ELAPSED_CLOCKS) {
                    currPosInValueArray[i] += values[NV_PMM_ELAPSED_CLOCKS_BIT_POS];
                } else {
                    NvU32 partNo = 0, spec = 0, width = 0, lshCount = 0, partWidth = 0, tempPartNumber = 0;
                    //currPosInValueArray[i] = 0;
                    tempPartNumber = pTempParsedClk->partNumber[i];
                    width = pTempParsedClk->width[i];
                    while(tempPartNumber) {
                        spec = (tempPartNumber & 0xff);
                        spec--;
                        partWidth = (width >= 4) ? 4 : width;
                        //change values in parsedClk to 64 bit.
                        currPosInValueArray[i] +=  (NvU32)(((NvU64)(values[spec]) << lshCount));
                        lshCount += partWidth;
                        width -= partWidth;
                        partNo++;
                        tempPartNumber >>= 8;
                    }
                    //At the end of while loop the width has to be 0
                    CU_ASSERT(width == 0);
                }
            } else {
                switch(pTempParsedClk->eventspec[i]) {
                    case (NV_PMM_TRIG1 | NV_PMM_EVENT):
                        if ((pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_EVENT4) || 
                            (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_EVENT6) ||
                            (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_2X4B4I)) {
                                currPosInValueArray[i] += values[NV_PMM_EVENT_BIT_POS];
                        }
                        else if ((pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_TRIG4) || (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_TRIG6)) {
                            if ((pTempParsedClk->width[i] == 2) && (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_TRIG6)) {
                                //This case should occur rarely as we will give preference to 4444 mode
                                currPosInValueArray[i] += values[NV_PMM_EVENT_BIT_POS];
                            } else {
                                currPosInValueArray[i] += values[NV_PMM_TRIG1_BIT_POS];
                            }
                        } else if (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_2X2B6I) {
                            currPosInValueArray[i] += (values[NV_PMM_EVENT_BIT_POS] + (values[NV_PMM_TRIG1_BIT_POS] << 4));
                        }
                        break;
                    case (NV_PMM_TRIG0 | NV_PMM_SAMPLE):
                        if (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_2X2B6I) {
                            currPosInValueArray[i] += (values[NV_PMM_TRIG0_BIT_POS] + (values[NV_PMM_SAMPLE_BIT_POS] << 4));
                        } else {
                            currPosInValueArray[i] += values[NV_PMM_TRIG0_BIT_POS];
                        }
                        break;
                    case NV_PMM_TRIG0:
                        currPosInValueArray[i] += values[NV_PMM_TRIG0_BIT_POS];
                        break;
                    case NV_PMM_TRIG1:
                        currPosInValueArray[i] += values[NV_PMM_TRIG1_BIT_POS];
                        break;
                    case NV_PMM_EVENT:
                        currPosInValueArray[i] += values[NV_PMM_EVENT_BIT_POS];
                        break;
                    case NV_PMM_SAMPLE:
                        currPosInValueArray[i] += values[NV_PMM_SAMPLE_BIT_POS];
                        break;
                    case NV_ELAPSED_CLOCKS:
                        currPosInValueArray[i] += values[NV_PMM_ELAPSED_CLOCKS_BIT_POS];
                        break;
                    default:
                        CU_ERROR_PRINT(("Not a valid trigger type.\n"));
                        break;
                }
            }
        }

     recPtr ++;
     totalBytes -= sizeof(CUprofStreamingRecord);
    }

#ifdef PRINT_EVENT_SAMPLING_RECORDS
    if (tempfp) {
        fflush(tempfp);
        fclose(tempfp);
        //return CUDA_ERROR_FILE_NOT_FOUND;
    }
#endif

    j = 0;
    offset[j++] = NV_PERF_PMASYS_MEM_BYTES;

    if (CUDA_SUCCESS != PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, j, offset, values, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }
    //Write value read from mem_bytes to mem_bump
    j = 0;
    offset[j] = NV_PERF_PMASYS_MEM_BUMP;

    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, j, offset, values, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

EXIT:
    free (offset);
    free (values);
    return status;
}

static CUprofResult logPMCountersModeB(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *values = NULL, *currPosInValueArray = NULL;
    NvU32 size = 0, totalSlots = 0;
    NvU32 domainRegOffset = 0, chipIdx = 0, i = 0, idx = 0;
    CUvoltaEventGroup  *voltaEventGroup;
    CUparsedClk *pTempParsedClk = NULL;
    CU_TRACE_FUNCTION();

    voltaEventGroup = pEventGroup->arch.voltaEventGroup;
    CU_ASSERT(voltaEventGroup);

    //elapsed_clocks is always read
    totalSlots = (CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS + CU_PROF_ELAPSED_CLOCK_SLOT);
    size  = sizeof(NvU32) * totalSlots * voltaEventGroup->maxChiplets;

    offset = (NvU32*)malloc(size);
    values = (NvU32*)malloc(size);
    if (!offset || !values) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    pTempParsedClk = pEventGroup->arch.voltaEventGroup->pParsedClk;

    for (chipIdx = 0; chipIdx < voltaEventGroup->maxChiplets; chipIdx++) {
            domainRegOffset = voltaEventGroup->pmmAddress[chipIdx] + voltaEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
            offset[NV_PMM_TRIG0_BIT_POS+(totalSlots*idx)] = domainRegOffset + NV_PMM_TRIGGERCNT;
            offset[NV_PMM_TRIG1_BIT_POS+(totalSlots*idx)] = domainRegOffset + NV_PMM_THRESHCNT;
            offset[NV_PMM_EVENT_BIT_POS+(totalSlots*idx)] = domainRegOffset + NV_PMM_EVENTCNT;
            offset[NV_PMM_SAMPLE_BIT_POS+(totalSlots*idx)] = domainRegOffset + NV_PMM_SAMPLECNT;
            offset[NV_PMM_ELAPSED_CLOCKS_BIT_POS+(totalSlots*idx)] = domainRegOffset + NV_PMM_ELAPSED;
            idx++;
        }
    CU_ASSERT(idx <= totalSlots * voltaEventGroup->maxChiplets);
    // read counter values for all HW counters then populate the values in eventgroup depending on the mode
    if (CUDA_SUCCESS != PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, totalSlots*idx, offset, values, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        pTempParsedClk = NULL;
        goto EXIT;
    }

    idx = 0;
    for (chipIdx = 0; chipIdx < voltaEventGroup->maxChiplets; chipIdx++) {
            if (!pTempParsedClk) {
                status = CUPROF_ERROR_OUT_OF_MEMORY;
                goto EXIT;
            }
            currPosInValueArray = (pTempParsedClk->values + (pTempParsedClk->totalHardwareCounters * chipIdx));
            for(i=0; i<pTempParsedClk->totalHardwareCounters; i++)
            {
                if (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_4444) {
                    if(pTempParsedClk->eventspec[i] == NV_ELAPSED_CLOCKS) {
                        currPosInValueArray[i] = values[NV_PMM_ELAPSED_CLOCKS_BIT_POS+(totalSlots*idx)];
                    } else {
                        NvU32 partNo = 0, spec = 0, width = 0, lshCount = 0, partWidth = 0, tempPartNumber = 0;
                        currPosInValueArray[i] = 0;
                        tempPartNumber = pTempParsedClk->partNumber[i];
                        width = pTempParsedClk->width[i];
                        while(tempPartNumber) {
                            spec = (tempPartNumber & 0xff);
                            spec--;
                            partWidth = (width >= 4) ? 4 : width;
                            //change values in parsedClk to 64 bit.
                            currPosInValueArray[i] +=  (NvU32)(((NvU64)(values[spec+(totalSlots*idx)]) << lshCount));
                            lshCount += partWidth;
                            width -= partWidth;
                            partNo++;
                            tempPartNumber >>= 8;
                        }
                        //At the end of while loop the width has to be 0
                        CU_ASSERT(width == 0);
                    }
                } else {
                    switch(pTempParsedClk->eventspec[i]) {
                    case (NV_PMM_TRIG1 | NV_PMM_EVENT):
                        if ((pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_EVENT4) ||
                            (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_EVENT6) ||
                            (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_2X4B4I)) {
                                currPosInValueArray[i] = values[NV_PMM_EVENT_BIT_POS+(totalSlots*idx)];
                        }
                        else if ((pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_TRIG4) || (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_TRIG6)) {
                            if ((pTempParsedClk->width[i] == 2) && (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_TRIG6)) {
                                //This case should occur rarely as we will give preference to 4444 mode
                                currPosInValueArray[i] = values[NV_PMM_EVENT_BIT_POS+(totalSlots*idx)];
                            } else {
                                currPosInValueArray[i] = values[NV_PMM_TRIG1_BIT_POS+(totalSlots*idx)];
                            }
                        } else if (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_2X2B6I) {
                            currPosInValueArray[i] = (values[NV_PMM_EVENT_BIT_POS + (totalSlots*idx)] + (values[NV_PMM_TRIG1_BIT_POS + (totalSlots*idx)] << 4));
                        }
                        break;
                    case (NV_PMM_TRIG0 | NV_PMM_SAMPLE):
                        if (pTempParsedClk->mode == NV_PMM_CONTROL_ADDTOCTR_2X2B6I) {
                            currPosInValueArray[i] = (values[NV_PMM_TRIG0_BIT_POS + (totalSlots*idx)] + (values[NV_PMM_SAMPLE_BIT_POS + (totalSlots*idx)] << 4));
                        } else {
                            currPosInValueArray[i] = values[NV_PMM_TRIG0_BIT_POS + (totalSlots*idx)];
                        }
                        break;
                    case NV_PMM_TRIG0:
                        currPosInValueArray[i] = values[NV_PMM_TRIG0_BIT_POS+(totalSlots*idx)];
                        break;
                    case NV_PMM_TRIG1:
                        currPosInValueArray[i] = values[NV_PMM_TRIG1_BIT_POS+(totalSlots*idx)];
                        break;
                    case NV_PMM_EVENT:
                        currPosInValueArray[i] = values[NV_PMM_EVENT_BIT_POS+(totalSlots*idx)];
                        break;
                    case NV_PMM_SAMPLE:
                        currPosInValueArray[i] = values[NV_PMM_SAMPLE_BIT_POS+(totalSlots*idx)];
                        break;
                    case NV_ELAPSED_CLOCKS:
                        currPosInValueArray[i] = values[NV_PMM_ELAPSED_CLOCKS_BIT_POS+(totalSlots*idx)];
                        break;
                    default:
                        CU_ERROR_PRINT(("Not a valid trigger type.\n"));
                        break;
                    }
                }
            }
            idx++;
        }

EXIT:
    free (offset);
    free (values);
    return status;
}
// detect if there has been a counter overflow
static CUprofResult detectCounterOverflowModeB(const CUeventGroup *pEventGroup, NvBool* bIsOverflow)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUvoltaEventGroup  *voltaEventGroup;
    CUparsedClk *pTempParsedClk = NULL;
    NvU32 chipIdx = 0, i = 0;

    CU_TRACE_FUNCTION();

    voltaEventGroup = pEventGroup->arch.voltaEventGroup;
    CU_ASSERT(voltaEventGroup);

    // NV_PERF_PMM_CONTROL_SHADOW_STATE_OVERFLOW field has nothing to do with overflowing snapshots (pm_trigger).
    // in mode B the fact that the counter is saturated (0xFFFFFFFF) is enough to assume overflow.
    for (chipIdx = 0; chipIdx < voltaEventGroup->maxChiplets; chipIdx++) {
            pTempParsedClk = pEventGroup->arch.voltaEventGroup->pParsedClk;
            for(i=0; i<pTempParsedClk->totalHardwareCounters; i++) {
                if (COUNTER_MAX32BIT == *(pTempParsedClk->values + (pTempParsedClk->totalHardwareCounters * chipIdx) + i)) {
                    *bIsOverflow = NV_TRUE;
                    return CUPROF_SUCCESS;
                }
            }
        }
    return status;
}
static CUprofResult PMReleaseModeB(const CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *value = NULL;
    NvU32 count = 0, size = 0, *domainRegOffset = NULL;
    NvU32 maxInstances = 0, chipIdx = 0, instance = 0;
    CUvoltaEventGroup  *voltaEventGroup;

    CU_TRACE_FUNCTION();
    voltaEventGroup = pEventGroup->arch.voltaEventGroup;

    size = sizeof(NvU32) * voltaEventGroup->maxChiplets;
    offset = (NvU32*)malloc(size);
    value  = (NvU32*)malloc(size);
    maxInstances = ((voltaEventGroup->maxChiplets > voltaEventGroup->pmmBroadcastInstances) ? voltaEventGroup->maxChiplets : voltaEventGroup->pmmBroadcastInstances);
    domainRegOffset = (NvU32*)malloc(maxInstances * sizeof(NvU32));
    if (!offset || !value || !domainRegOffset) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset, value and domainRegOffset\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    if (voltaEventGroup->broadcastType == BROADCAST_NONE) {
        maxInstances = voltaEventGroup->maxChiplets;
        for (chipIdx = 0; chipIdx < maxInstances; chipIdx++) {
            domainRegOffset[chipIdx] = voltaEventGroup->pmmAddress[chipIdx] + voltaEventGroup->clkIdx * NV_PMM_DOMAIN_OFFSET;
        }
    }
    else {
        maxInstances = voltaEventGroup->pmmBroadcastInstances;
        for (instance = 0; instance < maxInstances; instance++) {
            domainRegOffset[instance] = voltaEventGroup->pmmPMMBroadcastAddress[instance];
        }
    }

    for (instance = 0; instance < maxInstances; instance++) {
            offset[count]  = domainRegOffset[instance] + NV_PERF_PMM_RELEASE;
            value[count++] = NV_PERF_PMM_RELEASE_SHADOWS_DOIT;
        }

    if (CUDA_SUCCESS != PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

EXIT:
    free (offset);
    free (value);
    free(domainRegOffset);

    return status;
}

static CUprofResult voltaPerfmonSampleCountersNew(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvBool bIsOverflow = NV_FALSE;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    if (!pEventGroup->totalCounters) {
        return CUPROF_SUCCESS;
    }

    if ((pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS) 
        ||
        (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING)
        ) {
        status = StartExptModeB(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            goto EXIT;
        }
    }

    if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING) {
        stopStreaming(pEventGroup->pCtx);
        status = logPMCountersModeBStreamingMode(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            goto EXIT;
        }
    } else {
        status = logPMCountersModeB(pEventGroup);
        if (CUPROF_SUCCESS != status) {
            goto EXIT;
        }
        // report overflow if any
        if (CUPROF_SUCCESS != detectCounterOverflowModeB(pEventGroup, &bIsOverflow)) {
            goto EXIT;
        }
        
        if (bIsOverflow) {
            CU_ERROR_PRINT(("One or more counter is overflowing.\n"));
        }
    }

    status = PMReleaseModeB(pEventGroup);
    if (CUPROF_SUCCESS != status) {
        goto EXIT;
    }

EXIT:

    return status;
}

static CUprofResult readCountersDetectOverflowSMPC(CUeventGroup *pEventGroup)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUSMCtrInfo     *pSM = NULL;
    NvBool          bIsOverflow = NV_FALSE;
    CUeventInfo *currEventInfo = NULL;
    void *currEvent = NULL;
    void *eventBase = NULL;
    NvU32 multiplier[CU_PROF_PM_EVENT_GROUP_MAX_COUNTERS] = {0}, splitWidth[CU_PROF_PM_EVENT_GROUP_MAX_COUNTERS] = {0};
    NvU8 overflowValuesQuad[CU_PROF_SM_QUAD_PROFILED_MAX] = {0}, overflowValuesCore[CU_PROF_SM_CORE_PROFILED_MAX] = {0};
    NvU32 i = 0, chipIdx = 0, j = 0, smcntr_idx, lsh_cnt = 0, smIdx = 0, smCntInTpc = 0, sigExpt = 0, sig_cnt = 0;

    currEventInfo = (CUeventInfo*)listGetNext(pEventGroup->pEventInfoList, &eventBase);
    pSM = pEventGroup->arch.voltaEventGroup->pSM;
    for (i = 0; (i < pEventGroup->totalCounters) && currEventInfo; i++, currEventInfo = (CUeventInfo*)listGetNext(NULL, &eventBase)) {
        currEvent = currEventInfo->pEventData;
        // store multiplication factor of each signal in the event group
        multiplier[i] = getCounterMultiplicationFactor(pEventGroup->pCtx->device->state.chip, ((CUeventDataSmpc*)currEvent)->signalId);
        getSplittingInfo(((CUeventDataSmpc*)currEvent)->signalId, &splitWidth[i]);
        pSM->numSignalsInExpt[i] = (pSM->numSignalsInExpt[i] == 0) ? 1 : pSM->numSignalsInExpt[i];
    }
    status = (CUprofResult)logPMCountersSMInternal(pEventGroup, overflowValuesQuad, overflowValuesCore);
    if (CUPROF_SUCCESS != status) {
        return status;
    }
    // report overflow if any
    if (CUDA_SUCCESS != detectCounterOverflowSMInternal(pEventGroup, &bIsOverflow, overflowValuesQuad, overflowValuesCore)) {
        return status;
    }
    if (bIsOverflow) {
        CU_ERROR_PRINT(("One or more counter is overflowing.\n"));
    }

    for (chipIdx = 0; chipIdx < pEventGroup->arch.voltaEventGroup->maxChiplets; chipIdx++) {
        // We cannot floorsweep 1 sm of TPC. We need to floorsweep whole TPC. Hence unitMask is considered per TPC
            NvU32 sig_cnt = 0;
            for(i=0; i<pSM->SMCountersAdded && sig_cnt < pEventGroup->totalCounters; i+=((pSM->splitParts[i]!=0) ? pSM->splitParts[i] : 1), sig_cnt++)
            {
                NvU64 temp_vals = 0;
                lsh_cnt = 0;
                for(smcntr_idx = i ; smcntr_idx < (i + pSM->splitParts[sig_cnt]) ; smcntr_idx++) {
                    //copy linearly in eventgroup in folowing fashion: [instancecount][counter]
                    // As the counterwidth has now changed to 40 bits, we will need to compare with COUNTER_MAX64BIT
                    if ((*(pSM->values + (pSM->SMCountersAdded * chipIdx + smcntr_idx)) != COUNTER_MAX64BIT) &&
                        (temp_vals != COUNTER_MAX64BIT))
                    {
                        temp_vals += *(pSM->values + (pSM->SMCountersAdded * chipIdx + smcntr_idx)) << lsh_cnt;
                    }
                    else {
                        // 32-bit counter is overflowing, set 64-bit out value to max
                        temp_vals = COUNTER_MAX64BIT;
                        break;
                    }
                    lsh_cnt += splitWidth[i];
                }
                if(temp_vals != COUNTER_MAX64BIT){
                    temp_vals *= multiplier[sig_cnt];
                }
                pEventGroup->values[j++] += temp_vals;
            }
        }
    return CUPROF_SUCCESS;
}

// Function to read counters from hardware
static CUprofResult voltaReadCounters(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 i = 0, chipIdx = 0, j = 0;
    CUparsedClk     *pTempParsedClk = NULL;
    CUeventInfo *currEventInfo = NULL;
    void *currEvent = NULL;
    void *eventBase = NULL;
    NvU32 multiplier[CU_PROF_PM_EVENT_GROUP_MAX_COUNTERS] = {0};

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);
    CU_ASSERT(pEventGroup->isEnabled);

    if (!pEventGroup->totalCounters) {
        return CUPROF_SUCCESS;
    }

    switch(pEventGroup->domain->eventCollectionMethod)
    {
    case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
            //sample PM signals
            currEventInfo = (CUeventInfo*)listGetNext(pEventGroup->pEventInfoList, &eventBase);
            for (i = 0; (i < pEventGroup->totalCounters) && currEventInfo; i++, currEventInfo = (CUeventInfo*)listGetNext(NULL, &eventBase)) {
                currEvent = currEventInfo->pEventData;
                // store multiplication factor of each signal in the event group
                multiplier[i] = getCounterMultiplicationFactor(pEventGroup->pCtx->device->state.chip, ((CUeventData*)currEvent)->signalId);
            }

            status = voltaPerfmonSampleCountersNew(pEventGroup);
            if (status != CUPROF_SUCCESS) {
                return status;
            }

            pTempParsedClk = pEventGroup->arch.voltaEventGroup->pParsedClk;

            for (chipIdx = 0; chipIdx < pEventGroup->arch.voltaEventGroup->maxChiplets; chipIdx++) {
                    pTempParsedClk = pEventGroup->arch.voltaEventGroup->pParsedClk;;
                    for (i = 0; i < pEventGroup->totalCounters; i++)
                    {
                        //copy linearly in eventgroup in folowing fashion: [instancecount][counter]
                        if ((*(pTempParsedClk->values + pEventGroup->totalCounters * chipIdx + i) != COUNTER_MAX32BIT) &&
                            (pEventGroup->values[j] != COUNTER_MAX64BIT))
                        {
                            pEventGroup->values[j++] += (NvU64)*(pTempParsedClk->values + pEventGroup->totalCounters * chipIdx + i) * multiplier[i];
                        }
                        else {
                            // 32-bit counter is overflowing, set 64-bit out value to max
                            pEventGroup->values[j++] = COUNTER_MAX64BIT;
                        }
                    }
                }
        break;

    case CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX:
    case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
        {
            status = readCountersDetectOverflowSMPC(pEventGroup);
            if (CUPROF_SUCCESS != status) {
                return status;
            }
        }
        break;
    case CUPROF_EVENT_COLLECTION_METHOD_NVLINK_TC:
        {
           status = readCountersNvlinkTc(pEventGroup);
            if (CUPROF_SUCCESS != status) {
                return status;
            }
        }
        break;
    default:
        break;
    }

    return status;
}

CUprofResult voltaPerfmonEventGroupDisable(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    CUctx *ctx;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);
    //CU_ASSERT(pEventGroup->domainId < MAX_DOMAINS);

    ctx = pEventGroup->pCtx;
    setDomainEventGroup(ctx->pmNew->domainEventGroupEnabled, pEventGroup->domainId, 0);
    pEventGroup->isEnabled = 0;

    switch(pEventGroup->domain->eventCollectionMethod) {
        case CUPROF_EVENT_COLLECTION_METHOD_HWPM:
            if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_EVENT_SAMPLING) {
                stopStreaming(pEventGroup->pCtx);
#ifndef BUG_1259185_FIXED
                cleanupStreamingResources(ctx);
#endif
            }
            // fallthrough
        case CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX:
            // PM_ENABLE bit setting is Global. It will affect counter profiling in a multi-process/multi-ctx scenario
            // Commenting the Code to clear off the PM_ENABLE bit:(Bug 1254320)
            // To do: Re-enable the code when bug 973271 is fixed
#if 0
            status = setPMEnableReg(pEventGroup, NV_FALSE);
            if (CUPROF_SUCCESS != status) {
                CU_ERROR_PRINT(("Failed to disable the PME\n"));
            }
#endif
            if (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX) {
                //TBD since we have already disabled the PM enableBits for HWPM ,
                //we need not disable them again, if we do so guard with refcount
                if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS) {
                    voltaPerfmonStopCounters(NULL, pEventGroup);
                }
            }
            resetPMTarget(pEventGroup);
            break;

        case CUPROF_EVENT_COLLECTION_METHOD_SMPERF:
            if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS) {
                voltaPerfmonStopCounters(NULL, pEventGroup);
            }
            // PM_ENABLE bit setting is Global. It will affect counter profiling in a multi-process/multi-ctx scenario
            // Commenting the Code to clear off the PM_ENABLE bit:(Bug 1254320)
            // To do: Re-enable the code when bug 973271 is fixed
#if 0
            status = setPMEnableRegSM(pEventGroup, NV_FALSE);
            if (CUPROF_SUCCESS != status) {
                CU_ERROR_PRINT(("Failed to disable the SMPERF PMReg\n"));
            }
#endif
            resetPMTarget(pEventGroup);
            break;

        case CUPROF_EVENT_COLLECTION_METHOD_NVLINK_TC:
            if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS) {
                voltaPerfmonStopCounters(NULL, pEventGroup);
            }
            status = reserveReleaseNvlinkCounters(pEventGroup, NV_FALSE);
            if (status != CUPROF_SUCCESS)
                CU_ERROR_PRINT(("\nERROR in releasing nvlink Lock\n"));
            break;

        default:
            //do nothing
            break;
    }

    return status;
}

CUprofResult voltaPerfmonEventGroupReadEvent(CUeventGroup          *pEventGroup,
                                               CUprof_ReadEventFlags flags,
                                               CUprof_EventID        eventID,
                                               size_t                *bufferSizeBytes,
                                               NvU64                 *counterData)
{
    CUprofResult status = CUPROF_SUCCESS;
    void *currEvent = NULL;
    CUeventInfo *currEventInfo = NULL;
    void *eventBase = NULL;
    NvU32 i = 0, j = 0, instanceCount = 0;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    CU_ASSERT(pEventGroup->arch.voltaEventGroup);
    CU_ASSERT(bufferSizeBytes && counterData);

    currEventInfo = (CUeventInfo *)listGetNext(pEventGroup->pEventInfoList, &eventBase);
    for (i = 0; (i < pEventGroup->totalCounters) && currEventInfo; i++, currEventInfo = (CUeventInfo *)listGetNext(NULL, &eventBase)) {
        currEvent = currEventInfo->pEventData;
        if (((CUeventDataBasic*)currEvent)->signalId == eventID) {
            break;
        }
    }

    if (i == pEventGroup->totalCounters) {
        CU_ERROR_PRINT(("Invalid event-id %d\n", (int)eventID));
        return CUPROF_ERROR_INVALID_EVENT_ID;
    }

    // trigger the PM and read counters
    status = voltaReadCounters(pEventGroup);
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read counters or reset pm\n"));
        return status;
    }

    if(pEventGroup->profileAll) {
        instanceCount = pEventGroup->instanceCountAvail;
    }
    else {
        instanceCount = 1;
    }

    //Check how many bytes are allocated for counterData
    instanceCount = MIN(*(NvU32*)bufferSizeBytes / sizeof(NvU64), instanceCount);
    *bufferSizeBytes = instanceCount * sizeof(NvU64);

    for(j = 0; j < instanceCount; j++)
    {
        counterData[j] = pEventGroup->values[i + j*pEventGroup->totalCounters];
        // zero out the stored value, only returned counter values are considered
        pEventGroup->values[i + j*pEventGroup->totalCounters] = 0;
    }

    if ((pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX) ||
        (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_SMPERF)) {
            status = (CUprofResult)resetPMSMInternal(pEventGroup);
    }
    if ((pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_NVLINK_TC) &&
        (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_KERNEL)) {
        status = resetNvlinkCountersTC(pEventGroup);
    }
    if (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_HWPM) {
        status = StartExptModeB(pEventGroup);
    }

    return status;
}

CUprofResult voltaPerfmonEventGroupReadAllEvents(CUeventGroup *pEventGroup,
                                                   CUprof_ReadEventFlags  flags,
                                                   size_t                 *bufferSizeBytes,
                                                   NvU64                  *counterDataBuffer,
                                                   size_t                 *arraySizeBytes,
                                                   CUprof_EventID         *eventIDArray,
                                                   size_t                 *numCountersRead)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUeventInfo *currEventInfo = NULL;
    void *currEvent = NULL;
    void *eventBase = NULL;
    NvU32 numEvents = 0, i = 0, j = 0, totalValues = 0, instanceCount = 0;

    CU_TRACE_FUNCTION();
    CU_ASSERT(pEventGroup);

    CU_ASSERT(pEventGroup->arch.voltaEventGroup);
    CU_ASSERT(bufferSizeBytes && counterDataBuffer);
    CU_ASSERT(numCountersRead);

    // trigger the PM and read counters
    status = voltaReadCounters(pEventGroup);
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read counters or reset pm\n"));
        return status;
    }

    if(pEventGroup->profileAll) {
        instanceCount = pEventGroup->instanceCountAvail;
    }
    else {
        instanceCount = 1;
    }

    //Check how many bytes are allocated for counterData
    totalValues = instanceCount * pEventGroup->totalCounters;
    totalValues = MIN(*(NvU32*)bufferSizeBytes / sizeof(NvU64), totalValues);

    //It makes sense to give all instances of possible number of events
    numEvents = totalValues / instanceCount;

    *bufferSizeBytes = numEvents * instanceCount * sizeof(NvU64);

    for(i = 0; i < instanceCount; i++) {
        for(j = 0; j < numEvents; j++) {
            *(counterDataBuffer+i*numEvents+j) = *(pEventGroup->values + i*pEventGroup->totalCounters + j);
            // zero out the stored value, only returned counter values are considered
            *(pEventGroup->values + i*pEventGroup->totalCounters + j) = 0;
        }
    }

    *numCountersRead = numEvents;

    // assuming eventId params are optional
    if (arraySizeBytes && (*arraySizeBytes > 0) && eventIDArray) {
        numEvents = MIN(*(NvU32*)arraySizeBytes / sizeof(CUprof_EventID), *(NvU32*)numCountersRead);
        currEventInfo = (CUeventInfo*)listGetNext(pEventGroup->pEventInfoList, &eventBase);

        for (i = 0; (i < pEventGroup->totalCounters) && (i < numEvents) && currEventInfo; i++, currEventInfo = (CUeventInfo*)listGetNext(NULL, &eventBase)) {
            currEvent = currEventInfo->pEventData;
            eventIDArray[i] = ((CUeventDataBasic*)currEvent)->signalId;
        }
        *arraySizeBytes = numEvents * sizeof(CUprof_EventID);
    }

    if ((pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX) ||
        (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_SMPERF)) {
            status = (CUprofResult)resetPMSMInternal(pEventGroup);
    }
    if ((pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_NVLINK_TC) &&
        (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_KERNEL)) {
        status = resetNvlinkCountersTC(pEventGroup);
    }

    return status;
}

// this function is not exposed to external users
// it assists internal tools (profiler) to control event group
// based operations
CUprofResult voltaPerfmonEventGroupControl(CUeventGroup *pEventGroup,
                                             CUeventGroupFlag flag,
                                             void *value)
{
    CUprofResult status = CUPROF_SUCCESS;

    CU_TRACE_FUNCTION();

    CU_ASSERT(pEventGroup);

    switch (flag) {
    case CU_EVENT_GROUP_FLAG_SET_PROFILE_ALL_DOMAIN_INSTANCES:
        pEventGroup->profileAll = 1;
        break;
    case CU_EVENT_GROUP_FLAG_GET_CHIP_TYPE_FB:
        if (pEventGroup->domain->chipletType == PM_CHIPLET_TYPE_FBP) {
            *(int*)value = 1;
        }
        else {
            *(int*)value = 0;
        }
        break;
    case CU_EVENT_GROUP_FLAG_GET_UNIT_TYPE_SM:
        if (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_SMPERF) {
                *(int*)value = 1;
        }
        else {
            *(int*)value = 0;
        }
        break;
    default:
        CU_ERROR_PRINT(("Not a valid flag (%d)\n", flag));
        break;
    }

    return status;
}

// detect if there has been a counter overflow
static CUresult detectCounterOverflowSMInternal(const CUeventGroup *pEventGroup, NvBool* bIsOverflow, NvU8* overflowValuesQuad, NvU8* overflowValuesCore)
{
    CUresult status = CUDA_SUCCESS;
    CUvoltaEventGroup  *pVoltaEventGroup = NULL;
    NvU32 gpcId = 0, tpcId = 0, tpcIdx = 0;
    NvU32 i = 0, smIdInTpc = 0;
    CUSMCtrInfo     *pSM = NULL;
    NvU32 idxQctl = 0, idxCore = 0;

    CU_TRACE_FUNCTION();

    pVoltaEventGroup = pEventGroup->arch.voltaEventGroup;
    pSM = pVoltaEventGroup->pSM;

    /*******************************************************************************
    - Now, as the status register will now contain higher 8 bits of counter value,
    we can get these values in from the logPmCountersSMInternal function itself
    when we read the counter values.
    - So we will need to check if the 8 bits have the value 0xFF in them to detect
    overflow case.
    - Bits assigned to each signal:
    0:7 - counter1      8:15 - counter2
    16:23- counter3     24:31 - counter4
    *******************************************************************************/
    // check for overflow

    for(i=0; i<(NvU32)pSM->SMCountersAdded; i++) {
        switch (pSM->pmUnitId[i]) {
        case PM_UNIT_SMQCTL:
            if (overflowValuesQuad[idxQctl] == COUNTER_OVERFLOW_VALUE) {
                // we will be clearing the status registers while clearing off the signals values.
                for(gpcId = 0; gpcId < pVoltaEventGroup->gpcCount; gpcId++)
                {
                    for(tpcId = 0; tpcId < pVoltaEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
                    {
                            for(smIdInTpc = 0; smIdInTpc < pEventGroup->pCtx->device->state.limits.numSmsPerTpc; smIdInTpc++) {
                                *(pSM->values + (pSM->SMCountersAdded * (tpcIdx + smIdInTpc)) + i) = COUNTER_MAX64BIT;
                            }
                        tpcIdx++;
                    }
                }
                *bIsOverflow = NV_TRUE;
                idxQctl++;
            }
            break;
        case PM_UNIT_SMCORE:
        case PM_UNIT_MIO:
            if (overflowValuesCore[idxCore] == COUNTER_OVERFLOW_VALUE) {
                // we will be clearing the status registers while clearing off the signals values.
                for(gpcId = 0; gpcId < pVoltaEventGroup->gpcCount; gpcId++)
                {
                    for(tpcId = 0; tpcId < pVoltaEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
                    {
                            for(smIdInTpc = 0; smIdInTpc < pEventGroup->pCtx->device->state.limits.numSmsPerTpc; smIdInTpc++) {
                                *(pSM->values + (pSM->SMCountersAdded * (tpcIdx + smIdInTpc)) + i) = COUNTER_MAX64BIT;
                            }
                        tpcIdx++;
                    }
                    *bIsOverflow = NV_TRUE;
                }
                idxCore++;
                break;
            }
        }
    }
    return status;
}

static CUresult setPMctrlReg(NvU32 offset, const CUeventGroup *pEventGroup, PMEnableRegInfo *pPMEnableRegInfo, NvBool bEnable)
{
    NvU32 smValue = 0, value = 0, smMask = 0;
    CUresult status = CUDA_SUCCESS;

    // read _PM registers
    status = PRIREAD32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, 1, &offset, &value, 0);
    if (status != CUDA_SUCCESS) {
        return status;
    }

    // set PM_ENABLE bit by ORing the read value for selected instance
    smValue = (pPMEnableRegInfo->value << pPMEnableRegInfo->firstBit);
    smValue |= 0x80;
    smMask  = NV_SM_PM_CTRL_ENABLE_BITS_MASK;
    if(bEnable)
    {
        value |= (smValue & smMask);
    }
    else
    {
        value &= ~(smMask);
    }

    status = PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, 1, &offset, &value, 0);
    if (status != CUDA_SUCCESS) {
        return status;
    }
    return status;
}

static CUresult setPMEnableRegSM(const CUeventGroup *pEventGroup, NvBool bEnable)
{
    //Function to be changed for new version
    CUresult status = CUDA_SUCCESS;
    NvU32 offset;
    NvU32 i = 0, gpcId = 0, tpcId = 0, tpcIdx = 0;
    NvU32 pmUnitIdx = 0;
    PMEnableRegInfo *pPMEnableRegInfo = NULL;
    CUSMCtrInfo     *pSM = NULL;

    CU_TRACE_FUNCTION();

    pSM = pEventGroup->arch.voltaEventGroup->pSM;

    for(i=0; i<(NvU32)pSM->SMCountersAdded; i++) {
        pmUnitIdx = 0;

        //Search the unit table to get the unit.
        //TBD check if we can shift the unit table to domain table
        while (pEventGroup->pCtx->device->state.pPerfUnitTable[pmUnitIdx].pmUnitId != PM_UNIT_MAX) {
            if (pEventGroup->pCtx->device->state.pPerfUnitTable[pmUnitIdx].pmUnitId == pSM->pmUnitId[i]) {
                break;
            }
            pmUnitIdx++;
        }

        if (pEventGroup->pCtx->device->state.pPerfUnitTable[pmUnitIdx].pmUnitId == PM_UNIT_MAX) {
            // perf unit not found
            continue;
        }

        pPMEnableRegInfo = &pEventGroup->pCtx->device->state.pPerfUnitTable[pmUnitIdx].pmEnableRegInfo;

            offset = NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_CTRL;
            status = setPMctrlReg(offset, pEventGroup, pPMEnableRegInfo, bEnable);
            if (status != CUDA_SUCCESS) {
                return status;
            }
            }
    return status;
}

static CUresult SetupPMRegistersSMInternal(CUeventGroup *pEventGroup) {
    CUresult status = CUDA_SUCCESS;
    CUresult (*setupSmpcRegs)(CUeventGroup *pEventGroup, NvU32 eventGroupQctl, NvU32 eventGroupCore, 
                                                    NvU32* funcQctl, NvU32* funcCore, NvU32 enableQctl, NvU32 enableCore);
    NvU32 eventGroupQctl = 0, eventGroupCore = 0;
    NvU32 funcQctl[2] = {0}, funcCore[2] = {0};
    NvU32 idxQctl = 0, idxCore = 0;
    NvU32 enableQctl = 0, enableCore = 0, i = 0, index = 0;
    CUSMCtrInfo     *pSM = NULL;

    CU_TRACE_FUNCTION();

    pSM = pEventGroup->arch.voltaEventGroup->pSM;

    // Select group, edge, func etc
    // first four slots of perf registers are reserved for quad signals
    // while last four are for core/lsu signals

    idxQctl = 0;
    idxCore = 0;

    for(i=0; i<pSM->numGroupsQuad; i++)
    {
        eventGroupQctl |= pSM->groupsQuad[i] << (idxQctl*8);
        idxQctl++;
    }
    for(i=0; i<pSM->numGroupsCore; i++)
    {
        eventGroupCore |= pSM->groupsCore[i] << (idxCore*8);
        idxCore++;
    }

    // function combination
    // FUNC0 - 15:0, FUNC1 - 31:16
    idxCore = 0;
    idxQctl = 0;

    for (index = 0; index < pSM->SMCountersAdded; index++) {
        switch(pSM->pmUnitId[index]) {
        case PM_UNIT_SMQCTL:
            if(idxQctl & 1) {
                funcQctl[idxQctl>>1] |= pSM->function[index] << 16;
            }
            else {
                funcQctl[idxQctl>>1] |= pSM->function[index];
            }
            idxQctl++;
            break;
        case PM_UNIT_SMCORE:
        case PM_UNIT_MIO:
            if(idxCore & 1) {
                funcCore[idxCore>>1] |= pSM->function[index] << 16;
            }
            else {
                funcCore[idxCore>>1] |= pSM->function[index];
            }
            idxCore++;
            break;
        }
    }
    idxQctl = 0;
    idxCore = 0;
    for (index = 0; index < pSM->SMCountersAdded; index++) {
        NvU32 startBit, endBit;
        switch(pSM->pmUnitId[index])
        {
        case PM_UNIT_SMQCTL:
            startBit = (idxQctl * 4) + 1;
            endBit = startBit + 1;
            enableQctl = DRF_REPLACE(enableQctl, pSM->mode[index], endBit:startBit);
            idxQctl++;
            break;
        case PM_UNIT_SMCORE:
        case PM_UNIT_MIO:
            startBit = (idxCore * 4) + 1;
            endBit = startBit + 1;
            enableCore = DRF_REPLACE(enableCore, pSM->mode[index], endBit:startBit);
            idxCore++;
            break;
        }
    }
    // Calling broadcast version since we don't support per instance profiling in volta
        setupSmpcRegs = &SetupPMRegistersSM_bc;

    // Use the new RM Control call for enabling the WAR if it is defined:
    // WAR- Skip calling it on MRM as the corresponding IOCTL is not implemented
    // for HV and the counters exposed through CUPTI don't really require the
    // WAR
#if defined(NV2080_CTRL_CMD_GR_CTXSW_SMPC_MODE)
    if ((pEventGroup->pCtx->device->dmalType != CU_DMAL_MRM) &&
        !pEventGroup->pCtx->pmNew->flag)
    {
        status = pEventGroup->pCtx->device->dmal.deviceSetSMPCCtxswMode(pEventGroup->pCtx, NV_TRUE);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Error setting the CTXSW_SMPC_MODE bit\n"));
            goto EXIT;
        }
        pEventGroup->pCtx->pmNew->flag = 1;
    }
#else
    status = setFalcon05Method(pEventGroup->pCtx);
    if (status != CUDA_SUCCESS) {
        return status;
    }
#endif
    status = (*setupSmpcRegs)(pEventGroup, eventGroupQctl, eventGroupCore, funcQctl, funcCore, enableQctl, enableCore);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Error setting the SMPC configuration registers\n"));
        goto EXIT;
    }
EXIT:
    return status;
}

static CUresult SetupPMRegistersSM(CUeventGroup *pEventGroup, NvU32 eventGroupQctl, NvU32 eventGroupCore, 
                                    NvU32* funcQctl, NvU32* funcCore, NvU32 enableQctl, NvU32 enableCore) {
    CUresult status = CUDA_SUCCESS;
    NvU32 gpcTarget = 0, tpcTarget = 0;
    //TBD Increasing arbitrarity to higher value, later on check exactly how much memory is required
    NvU32 *offset = NULL, gpcId = 0, tpcId = 0;
    NvU32 *value  = NULL;
    NvU32 count = 0, numRegs = 26;
    NvU32 idxQctl = 0, idxCore = 0;
    NvU32 index = 0;
    CUSMCtrInfo     *pSM = NULL;

    CU_TRACE_FUNCTION();

    //Allocate memory of size = (CU_PROF_PM_SM_MAX_COUNTERS * #SMs * sizeof(NvU32))
    offset = (NvU32 *)malloc(numRegs * pEventGroup->instanceCountAvail * sizeof(NvU32));
    value = (NvU32 *)calloc(numRegs * pEventGroup->instanceCountAvail, sizeof(NvU32));

    if(!(offset && value)) {
        CU_ERROR_PRINT(("Error allocating memory for offset-value arrays.\n"));
        status = (CUresult)CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    if (!pEventGroup->arch.voltaEventGroup->isSMPCLegacyMode) {
        offset[count++]  = NV_PERF_PMASYS_GPC_TRIGGER_STATUS;

        offset[count]  = NV_PERF_PMASYS_CONTROL;
        value[count++] = HWCONST(_PERF_PMASYS, CONTROL, STOPVPMCAPTURE, DOIT);

         //setup PMA to push trigger to GPC chiplet
        offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_START_MASK;
        value[count++] = 0xffffffff;

        offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_STOP_MASK;
        value[count++] = 0xffffffff;
    }
    status = PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
    if (status != CUDA_SUCCESS) {
        goto EXIT;
    }
    count = 0;

    pSM = pEventGroup->arch.voltaEventGroup->pSM;
    for(gpcId = 0; gpcId < pEventGroup->arch.voltaEventGroup->gpcCount; gpcId++)
    {
        for(tpcId = 0; tpcId < pEventGroup->arch.voltaEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
        {
            gpcTarget = gpcId;
            tpcTarget = tpcId;

            if (pEventGroup->arch.voltaEventGroup->isSMPCLegacyMode) {
                // Disable the snapshot mode for legacy mode which is enabled by default
                offset[count] = NV_EXTENDED_SM_DSM_PERF_COUNTER_CONTROL(gpcTarget, tpcTarget);
                value[count++]  = 0;
            }

            // Performance Counter Group mux select
            // GRP0 - 7:0,  GRP1 - 15:8, GRP2 - 23:16, GRP3 - 31:24
            offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL_SEL0(gpcTarget, tpcTarget);
            value[count++] = eventGroupQctl;
            offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL_SEL1(gpcTarget, tpcTarget);
            value[count++] = eventGroupCore;

            // function combination
            // FUNC0 - 15:0, FUNC1 - 31:16
            offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL1(gpcTarget, tpcTarget);
            value[count++] = funcQctl[0];
            offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL2(gpcTarget, tpcTarget);
            value[count++] = funcQctl[1];
            offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL3(gpcTarget, tpcTarget);
            value[count++] = funcCore[0];
            offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL4(gpcTarget, tpcTarget);
            value[count++] = funcCore[1];

            // Each perf counter has 4 bits feeding into a function table.  Each bit
            // can be selected from 1 of 8 bits of 1 of the 8 groups (selected via
            // the PERF_COUNTER_CONTROL_SEL* register above).
            // BIT#_GRP selects 1 of 8 groups
            // BIT#_SIG selects 1 of the 8 signals from that selected group

            idxCore = 0;
            idxQctl = 0;

            for (index = 0; index < pSM->SMCountersAdded; index++) {
                switch(pSM->pmUnitId[index]) {
                case PM_UNIT_SMQCTL:
                    switch(idxQctl) {
                case 0:
                    offset[count] = NV_SM_DSM_PERF_COUNTER0_CONTROL(gpcTarget, tpcTarget);
                    break;
                case 1:
                    offset[count] = NV_SM_DSM_PERF_COUNTER1_CONTROL(gpcTarget, tpcTarget);
                    break;
                case 2:
                    offset[count] = NV_SM_DSM_PERF_COUNTER2_CONTROL(gpcTarget, tpcTarget);
                    break;
                case 3:
                    offset[count] = NV_SM_DSM_PERF_COUNTER3_CONTROL(gpcTarget, tpcTarget);
                    break;
                    }
                    idxQctl++;
                    break;

                case PM_UNIT_SMCORE:
                case PM_UNIT_MIO:
                    switch(idxCore) {
                case 0:
                    offset[count] = NV_SM_DSM_PERF_COUNTER4_CONTROL(gpcTarget, tpcTarget);
                    break;
                case 1:
                    offset[count] = NV_SM_DSM_PERF_COUNTER5_CONTROL(gpcTarget, tpcTarget);
                    break;
                case 2:
                    offset[count] = NV_SM_DSM_PERF_COUNTER6_CONTROL(gpcTarget, tpcTarget);
                    break;
                case 3:
                    offset[count] = NV_SM_DSM_PERF_COUNTER7_CONTROL(gpcTarget, tpcTarget);
                    break;
                    }
                    idxCore++;
                    break;
                }
                value[count++]  = pSM->perfEventInfo[index];
            }
            // Performance Counter - edge
            // EDGE0 - 0:0, EDGE1 - 4:4, EDGE2 - 8:8,   EDGE3 - 12:11
            // MODE0 - 2:1, MODE1 - 6:5, MODE2 - 10:9,  MODE3 - 14:13
            // set EDGE = DISABLE and MODE = COUNT

            offset[count] = NV_SM_DSM_PERF_COUNTER_CONTROL0(gpcTarget, tpcTarget);
            value[count++] = enableQctl;
            offset[count] = NV_SM_DSM_PERF_COUNTER_CONTROL5(gpcTarget, tpcTarget);
            value[count++] = enableCore;
            // Filter signal settings:
            offset[count] = NV_SM_DSM_PERF_COUNTER_FILTER0_CONTROL(gpcTarget, tpcTarget);
            value[count++] = (pSM->signalIdFilterQuad) ? pSM->signalConfigQuad : 0;
            offset[count] = NV_SM_DSM_PERF_COUNTER_FILTER4_CONTROL(gpcTarget, tpcTarget);
            value[count++] = (pSM->signalIdFilterCore) ? pSM->signalConfigCore : 0;
        }
    }
    CU_ASSERT(count <= (numRegs * pEventGroup->instanceCountAvail));
    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, count, offset, value, 0);

    if (status != CUDA_SUCCESS) {
        goto EXIT;
    }
EXIT:
    if(offset) {
        free(offset);
    }
    if(value) {
        free(value);
    }
    return status;
}

static CUresult SetupPMRegistersSM_bc(CUeventGroup *pEventGroup, NvU32 eventGroupQctl, NvU32 eventGroupCore, 
                                    NvU32* funcQctl, NvU32* funcCore, NvU32 enableQctl, NvU32 enableCore) {
    CUresult status = CUDA_SUCCESS;
    NvU32 *offset = NULL;
    NvU32 *value  = NULL;
    NvU32 count = 0, numRegs = 22;
    NvU32 idxQctl = 0, idxCore = 0;
    NvU32 index = 0;
    CUSMCtrInfo     *pSM = NULL;

    CU_TRACE_FUNCTION();

    //Allocate memory of size = (CU_PROF_PM_SM_MAX_COUNTERS * sizeof(NvU32))
    offset = (NvU32 *)malloc(numRegs * sizeof(NvU32));
    value = (NvU32 *)calloc(numRegs, sizeof(NvU32));

    if(!(offset && value)) {
        CU_ERROR_PRINT(("Error allocating memory for offset-value arrays.\n"));
        status = (CUresult)CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    if (!pEventGroup->arch.voltaEventGroup->isSMPCLegacyMode) {
        offset[count++]  = NV_PERF_PMASYS_GPC_TRIGGER_STATUS;

        offset[count]  = NV_PERF_PMASYS_CONTROL;
        value[count++] = HWCONST(_PERF_PMASYS, CONTROL, STOPVPMCAPTURE, DOIT);

         //setup PMA to push trigger to GPC chiplet
        offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_START_MASK;
        value[count++] = 0xffffffff;

        offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_STOP_MASK;
        value[count++] = 0xffffffff;

        offset[count]  = NV_PERF_PMASYS_TRIGGER_GLOBAL;
        if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS) {
            value[count++] = HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, ENABLE, ENABLED) |
            HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_GPC, ENABLE) |
            HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, MANUAL_START, PULSE);
        }
        else {
            value[count++] = HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, ENABLE, ENABLED) |
            HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_GPC, ENABLE);
        }
    }
    status = PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
    if (status != CUDA_SUCCESS) {
        goto EXIT;
    }
    count = 0;

    pSM = pEventGroup->arch.voltaEventGroup->pSM;

    if (pEventGroup->arch.voltaEventGroup->isSMPCLegacyMode) {
        // Disable the snapshot mode for legacy mode as it is enabled by default
        offset[count] = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_CONTROL;
        value[count++] = 0;
    }

    // Performance Counter Group mux select
    // GRP0 - 7:0,  GRP1 - 15:8, GRP2 - 23:16, GRP3 - 31:24
    if (pSM->qctlCount) {
        offset[count]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_CONTROL_SEL0;
        value[count++] = eventGroupQctl;
        // function combination
        // FUNC0 - 15:0, FUNC1 - 31:16
        offset[count]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_CONTROL1;
        value[count++] = funcQctl[0];
        offset[count]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_CONTROL2;
        value[count++] = funcQctl[1];
    }
    if (pSM->coreCount) {
        offset[count]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_CONTROL_SEL1;
        value[count++] = eventGroupCore;
        // function combination
        // FUNC0 - 15:0, FUNC1 - 31:16
        offset[count]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_CONTROL3;
        value[count++] = funcCore[0];
        offset[count]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_CONTROL4;
        value[count++] = funcCore[1];
    }
    // Each perf counter has 4 bits feeding into a function table.  Each bit
    // can be selected from 1 of 8 bits of 1 of the 8 groups (selected via
    // the PERF_COUNTER_CONTROL_SEL* register above).
    // BIT#_GRP selects 1 of 8 groups
    // BIT#_SIG selects 1 of the 8 signals from that selected group

    idxCore = 0;
    idxQctl = 0;

    for (index = 0; index < pSM->SMCountersAdded; index++) {
        switch(pSM->pmUnitId[index]) {
        case PM_UNIT_SMQCTL:
            switch(idxQctl) {
        case 0:
            offset[count] = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER0_CONTROL;
            break;
        case 1:
            offset[count] = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER1_CONTROL;
            break;
        case 2:
            offset[count] = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER2_CONTROL;
            break;
        case 3:
            offset[count] = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER3_CONTROL;
            break;
            }
            idxQctl++;
            break;

        case PM_UNIT_SMCORE:
        case PM_UNIT_MIO:
            switch(idxCore) {
        case 0:
            offset[count] = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER4_CONTROL;
            break;
        case 1:
            offset[count] = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER5_CONTROL;
            break;
        case 2:
            offset[count] = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER6_CONTROL;
            break;
        case 3:
            offset[count] = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER7_CONTROL;
            break;
            }
            idxCore++;
            break;
        }
        value[count++]  = pSM->perfEventInfo[index];
    }
    // Performance Counter - edge
    // EDGE0 - 0:0, EDGE1 - 4:4, EDGE2 - 8:8,   EDGE3 - 12:11
    // MODE0 - 2:1, MODE1 - 6:5, MODE2 - 10:9,  MODE3 - 14:13
    // set EDGE = DISABLE and MODE = COUNT
    if (pSM->qctlCount) {
        offset[count] = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_CONTROL0;
        value[count++] = enableQctl;
        // Filter signal settings:
        offset[count] = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_FILTER0_CONTROL;
        value[count++] = (pSM->signalIdFilterQuad) ? pSM->signalConfigQuad : 0;
    }
    if (pSM->coreCount) {
        offset[count] = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_CONTROL5;
        value[count++] = enableCore;
        // Filter signal settings:
        offset[count] = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_FILTER4_CONTROL;
        value[count++] = (pSM->signalIdFilterCore) ? pSM->signalConfigCore : 0;
    }
    CU_ASSERT(count <= numRegs);
    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, count, offset, value, 0);
    if (status != CUDA_SUCCESS) {
        goto EXIT;
    }

EXIT:
    if(offset) {
        free(offset);
    }
    if(value) {
        free(value);
    }
    return status;
}

static CUresult resetPMSMInternal(CUeventGroup *pEventGroup) {
    CUresult status = CUDA_SUCCESS;
    NvU32 funcQctl[2] = {0};
    NvU32 funcCore[2] = {0};
    NvU32 idxQctl = 0, idxCore = 0;
    NvU32 index = 0;
    CUSMCtrInfo     *pSM = NULL;
    CUresult (*resetSmpcRegs)(CUeventGroup *pEventGroup, NvU32 *funcQctl, NvU32 *funcCore);

    CU_TRACE_FUNCTION();

    // calling broadcast version only since we wont be suppporting signle instance profiling in volta
    resetSmpcRegs = &resetPMSM_bc;
    // Compute the function values to be written in the FUNC registers after cleaing the final value registers:
    idxCore = 0;
    idxQctl = 0;
    pSM = pEventGroup->arch.voltaEventGroup->pSM;

    for (index = 0; index < pSM->SMCountersAdded; index++) {
        switch(pSM->pmUnitId[index]) {
        case PM_UNIT_SMQCTL:
            if(idxQctl & 1) {
                funcQctl[idxQctl>>1] |= pSM->function[index] << 16;
            }
            else {
                funcQctl[idxQctl>>1] |= pSM->function[index];
            }
            idxQctl++;
            break;
        case PM_UNIT_SMCORE:
        case PM_UNIT_MIO:
            if(idxCore & 1) {
                funcCore[idxCore>>1] |= pSM->function[index] << 16;
            }
            else {
                funcCore[idxCore>>1] |= pSM->function[index];
            }
            idxCore++;
            break;
        }
    }
    status = (*resetSmpcRegs)(pEventGroup, funcQctl, funcCore);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Error re-setting the SMPC final value registers\n"));
    }
    return status;
}

static CUresult resetPMSM(CUeventGroup *pEventGroup, NvU32 *funcQctl, NvU32 *funcCore) {
    CUresult status = CUDA_SUCCESS;
    NvU32 gpcTarget = 0, tpcTarget = 0, gpcId = 0, tpcId = 0, count = 0, smIdInTpc = 0;
    NvU32 *offset = NULL;
    NvU32 *value = NULL;

    CU_TRACE_FUNCTION();

    //(#quadCounters * 5) : 4 counter values + 1 status register per quad + 2 * numFuncRegisters
    //Allocate memory of size = ((#quadCounters * 5) + #coreCounters + 1 + 2 * numFuncRegisters) * #SMs * sizeof(NvU32))
    offset = (NvU32 *)malloc((CU_PROF_SM_CORE_PROFILED_MAX + 1 + CU_PROF_SM_QUAD_PROFILED_MAX * 5 + 2 * NUM_FUNC_REGISTERS) * pEventGroup->instanceCountAvail * sizeof(NvU32));
    value = (NvU32 *)calloc((CU_PROF_SM_CORE_PROFILED_MAX + 1 + CU_PROF_SM_QUAD_PROFILED_MAX * 5 + 2 * NUM_FUNC_REGISTERS) * pEventGroup->instanceCountAvail, sizeof(NvU32));
    if(!(offset && value)) {
        CU_ERROR_PRINT(("Error allocating memory for offset-value arrays.\n"));
        status = (CUresult)CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }
    if (pEventGroup->arch.voltaEventGroup->pSM->qctlCount) {
        for(gpcId = 0; gpcId < pEventGroup->arch.voltaEventGroup->gpcCount; gpcId++)
        {
            for(tpcId = 0; tpcId < pEventGroup->arch.voltaEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
            {
                gpcTarget = gpcId;
                tpcTarget = tpcId;

                /****************************************************************
                 Clear out the FUNC registers before writing to the
                     final value registers:
                ****************************************************************/
                offset[count++]  = NV_SM_DSM_PERF_COUNTER_CONTROL1(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER_CONTROL2(gpcTarget, tpcTarget);

                for(smIdInTpc = 0; smIdInTpc < pEventGroup->pCtx->device->state.limits.numSmsPerTpc; smIdInTpc++)
                {

                    /****************************************************************
                    As the status registers will now be used to store the higher
                    8 bits of counter values, we will need to clear
                    *****************************************************************/
                    // For qctl counters:ar them off.
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER0_S0(gpcTarget, tpcTarget, smIdInTpc);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER1_S0(gpcTarget, tpcTarget, smIdInTpc);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER2_S0(gpcTarget, tpcTarget, smIdInTpc);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER3_S0(gpcTarget, tpcTarget, smIdInTpc);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER0_S1(gpcTarget, tpcTarget, smIdInTpc);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER1_S1(gpcTarget, tpcTarget, smIdInTpc);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER2_S1(gpcTarget, tpcTarget, smIdInTpc);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER3_S1(gpcTarget, tpcTarget, smIdInTpc);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER0_S2(gpcTarget, tpcTarget, smIdInTpc);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER1_S2(gpcTarget, tpcTarget, smIdInTpc);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER2_S2(gpcTarget, tpcTarget, smIdInTpc);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER3_S2(gpcTarget, tpcTarget, smIdInTpc);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER0_S3(gpcTarget, tpcTarget, smIdInTpc);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER1_S3(gpcTarget, tpcTarget, smIdInTpc);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER2_S3(gpcTarget, tpcTarget, smIdInTpc);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER3_S3(gpcTarget, tpcTarget, smIdInTpc);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER_STATUS_S0(gpcTarget, tpcTarget, smIdInTpc);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER_STATUS_S1(gpcTarget, tpcTarget, smIdInTpc);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER_STATUS_S2(gpcTarget, tpcTarget, smIdInTpc);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER_STATUS_S3(gpcTarget, tpcTarget, smIdInTpc);
                }
                /****************************************************************
                 Set the FUNC registers after writing to the
                     final value registers:
                ****************************************************************/
                offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL1(gpcTarget, tpcTarget);
                value[count++] = funcQctl[0];
                offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL2(gpcTarget, tpcTarget);
                value[count++] = funcQctl[1];
            }
        }
    }
    if (pEventGroup->arch.voltaEventGroup->pSM->coreCount) {
        for(gpcId = 0; gpcId < pEventGroup->arch.voltaEventGroup->gpcCount; gpcId++)
        {
            for(tpcId = 0; tpcId < pEventGroup->arch.voltaEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
            {
                gpcTarget = gpcId;
                tpcTarget = tpcId;

                /****************************************************************
                 Clear out the FUNC registers before writing to the
                     final value registers:
                ****************************************************************/
                offset[count++]  = NV_SM_DSM_PERF_COUNTER_CONTROL3(gpcTarget, tpcTarget);
                offset[count++]  = NV_SM_DSM_PERF_COUNTER_CONTROL4(gpcTarget, tpcTarget);

                /****************************************************************
                As the status registers will now be used to store the higher
                8 bits of counter values, we will need to clear them off.
                ****************************************************************/
                for(smIdInTpc = 0; smIdInTpc < pEventGroup->pCtx->device->state.limits.numSmsPerTpc; smIdInTpc++) 
                {

                    // For core counters:
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER4(gpcTarget, tpcTarget, smIdInTpc);
                    offset[count++] = NV_SM_DSM_PERF_COUNTER_STATUS1(gpcTarget, tpcTarget, smIdInTpc);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER5(gpcTarget, tpcTarget, smIdInTpc);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER6(gpcTarget, tpcTarget, smIdInTpc);
                    offset[count++]  = NV_SM_DSM_PERF_COUNTER7(gpcTarget, tpcTarget, smIdInTpc);
                }
                /****************************************************************
                 Set the FUNC registers after writing to the
                     final value registers:
                ****************************************************************/
                offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL3(gpcTarget, tpcTarget);
                value[count++] = funcCore[0];
                offset[count]  = NV_SM_DSM_PERF_COUNTER_CONTROL4(gpcTarget, tpcTarget);
                value[count++] = funcCore[1];
            }
        }
    }
    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, count, offset, value, 0);
    if (status != CUDA_SUCCESS) {
        goto EXIT;
    }

    free(offset);
    free(value);

    return status;
EXIT:
    if (offset) {
        free (offset);
    }
    if (value) {
        free (value);
    }
    return status;
}

static CUresult resetPMSM_bc(CUeventGroup *pEventGroup, NvU32 *funcQctl, NvU32 *funcCore) {
    CUresult status = CUDA_SUCCESS;
    NvU32 count = 0;
    NvU32 *offset = NULL;
    NvU32 *value = NULL;
    CU_TRACE_FUNCTION();

    //(#quadCounters * 5) : 4 counter values + 1 status register per quad + 2 * numFuncRegisters
    //Allocate memory of size = ((#quadCounters * 5) + #coreCounters + 1 + 2 * numFuncRegisters) * sizeof(NvU32))
    offset = (NvU32 *)malloc((CU_PROF_SM_CORE_PROFILED_MAX + 1 + CU_PROF_SM_QUAD_PROFILED_MAX * 5 + 2 * NUM_FUNC_REGISTERS) * sizeof(NvU32));
    value = (NvU32 *)calloc((CU_PROF_SM_CORE_PROFILED_MAX + 1 + CU_PROF_SM_QUAD_PROFILED_MAX * 5 + 2 * NUM_FUNC_REGISTERS), sizeof(NvU32));
    if(!(offset && value)) {
        CU_ERROR_PRINT(("Error allocating memory for offset-value arrays.\n"));
        status = (CUresult)CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    /****************************************************************
    As the status registers will now be used to store the higher
    8 bits of counter values, we will need to clear them off.
    ****************************************************************/
    if (pEventGroup->arch.voltaEventGroup->pSM->qctlCount) {
        /****************************************************************
            Clear out the FUNC registers before writing to the
                final value registers:
        ****************************************************************/
        offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_CONTROL1;
        offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_CONTROL2;

            // For qctl counters:
        if (pEventGroup->arch.voltaEventGroup->isSMPCLegacyMode) {
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER0_S0;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER1_S0;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER2_S0;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER3_S0;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER0_S1;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER1_S1;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER2_S1;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER3_S1;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER0_S2;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER1_S2;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER2_S2;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER3_S2;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER0_S3;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER1_S3;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER2_S3;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER3_S3;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_STATUS_S0;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_STATUS_S1;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_STATUS_S2;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_STATUS_S3;
        }
        else {
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT0_S0;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT1_S0;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT2_S0;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT3_S0;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT0_S1;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT1_S1;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT2_S1;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT3_S1;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT0_S2;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT1_S2;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT2_S2;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT3_S2;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT0_S3;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT1_S3;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT2_S3;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT3_S3;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT_STATUS_S0;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT_STATUS_S1;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT_STATUS_S2;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT_STATUS_S3;
        }

        /****************************************************************
            Set the FUNC registers after writing to the
                final value registers:
        ****************************************************************/
        offset[count]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_CONTROL1;
        value[count++] = funcQctl[0];
        offset[count]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_CONTROL2;
        value[count++] = funcQctl[1];
    }
    if (pEventGroup->arch.voltaEventGroup->pSM->coreCount) {
        /****************************************************************
            Clear out the FUNC registers before writing to the
                final value registers:
        ****************************************************************/
        offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_CONTROL3;
        offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_CONTROL4;

        // For core counters:
        if (pEventGroup->arch.voltaEventGroup->isSMPCLegacyMode) {
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER4;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER5;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER6;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER7;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_STATUS1;
        }
        else {
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT4;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT5;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT6;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT7;
            offset[count++]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SMS_DSM_PERF_COUNTER_SNAPSHOT_STATUS1;
        }

        /****************************************************************
            Set the FUNC registers after writing to the
                final value registers:
        ****************************************************************/
        offset[count]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_CONTROL3;
        value[count++] = funcCore[0];
        offset[count]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_CONTROL4;
        value[count++] = funcCore[1];
    }
    status = PRIWRITE32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, count, offset, value, 0);
    if (status != CUDA_SUCCESS) {
        goto EXIT;
    }

    free(offset);
    free(value);

    return status;
EXIT:
    if (offset) {
        free (offset);
    }
    if (value) {
        free (value);
    }
    return status;
}

static CUresult logPMCountersSMInternal(CUeventGroup *pEventGroup, NvU8 *highValuesQuad, NvU8 *highValuesCore) {
    CUresult status = CUDA_SUCCESS;
    NvU32 gpcId = 0, tpcId = 0, tpcIdx = 0, smIdInTpc = 0;

    /*********************************************************
    For Quad Counters:
     Per Quad: 
         Status registers:   2
         Counter regsiters:  4
     Total = 6 * 4 = 24

    For Core Counters:
         Status registers:   2
         Counter regsiters:  4
     Total = 6 * 1 = 6

    // Total offsets: 84 (Number of SMs in GV100) * 30 = 2520
    **********************************************************/
    NvU32 offset[2520] = {0};

    NvU64 counterValuesQctl[4] = {0}, counterValuesCore[4] = {0};
    NvU32 counterValues[2520] = {0}, count = 0;
    NvU8 i = 0, j = 0;
    NvU32 idxQctl = 0, idxCore = 0, regIdx = 0;
    CUSMCtrInfo     *pSM = NULL;
    CU_TRACE_FUNCTION();
    pSM = pEventGroup->arch.voltaEventGroup->pSM;

    for(gpcId = 0; gpcId < pEventGroup->arch.voltaEventGroup->gpcCount; gpcId++)
    {
        for(tpcId = 0; tpcId < pEventGroup->arch.voltaEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
        {
            for(smIdInTpc = 0; smIdInTpc < pEventGroup->pCtx->device->state.limits.numSmsPerTpc; smIdInTpc++)
            {
                /*********************************************************************
                The status registers will now contain the higher 8 bits of the
                counter values.
                0:7   - counter 1   8:15 - counter 2
                16:23 - counter 3   24:31 - counter 4
                *********************************************************************/
                if (pSM->qctlCount) {
                    if (pEventGroup->arch.voltaEventGroup->isSMPCLegacyMode) {
                        /*********************
                        Quad 0:
                        *********************/
                        // HI Register:
                        offset[count++] = NV_SM_DSM_PERF_COUNTER_STATUS_S0(gpcId, tpcId, smIdInTpc);
                        // LO Register:
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER0_S0(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER1_S0(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER2_S0(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER3_S0(gpcId, tpcId, smIdInTpc);
                        // HI Register:
                        offset[count++] = NV_SM_DSM_PERF_COUNTER_STATUS_S0(gpcId, tpcId, smIdInTpc);

                        /*********************
                        Quad 1:
                        *********************/
                        // HI Register:
                        offset[count++] = NV_SM_DSM_PERF_COUNTER_STATUS_S1(gpcId, tpcId, smIdInTpc);
                        // LO Register:
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER0_S1(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER1_S1(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER2_S1(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER3_S1(gpcId, tpcId, smIdInTpc);
                        // HI Register:
                        offset[count++] = NV_SM_DSM_PERF_COUNTER_STATUS_S1(gpcId, tpcId, smIdInTpc);

                        /*********************
                        Quad 2:
                        *********************/
                        // HI Register:
                        offset[count++] = NV_SM_DSM_PERF_COUNTER_STATUS_S2(gpcId, tpcId, smIdInTpc);
                        // LO Register:
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER0_S2(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER1_S2(gpcId, tpcId, smIdInTpc);
                        offset[count++] = NV_SM_DSM_PERF_COUNTER2_S2(gpcId, tpcId, smIdInTpc);
                        offset[count++] = NV_SM_DSM_PERF_COUNTER3_S2(gpcId, tpcId, smIdInTpc);
                        // HI Register:
                        offset[count++] = NV_SM_DSM_PERF_COUNTER_STATUS_S2(gpcId, tpcId, smIdInTpc);

                        /*********************
                        Quad 3:
                        *********************/
                        // HI Register:
                        offset[count++] = NV_SM_DSM_PERF_COUNTER_STATUS_S3(gpcId, tpcId, smIdInTpc);
                        // LO Register:
                        offset[count++] = NV_SM_DSM_PERF_COUNTER0_S3(gpcId, tpcId, smIdInTpc);
                        offset[count++] = NV_SM_DSM_PERF_COUNTER1_S3(gpcId, tpcId, smIdInTpc);
                        offset[count++] = NV_SM_DSM_PERF_COUNTER2_S3(gpcId, tpcId, smIdInTpc);
                        offset[count++] = NV_SM_DSM_PERF_COUNTER3_S3(gpcId, tpcId, smIdInTpc);
                        // HI Register:
                        offset[count++] = NV_SM_DSM_PERF_COUNTER_STATUS_S3(gpcId, tpcId, smIdInTpc);
                    }
                    else {
                        // Reading snapshot register 
                        // We dont have to read the high 8 bit of the counter twice with snapshot mode
                        /*********************
                        Quad 0:
                        *********************/
                        // HI Register:
                        offset[count++] = NV_SM_DSM_PERF_COUNTER_SNAPSHOT_STATUS_S0(gpcId, tpcId, smIdInTpc);
                        // LO Register:
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_SNAPSHOT0_S0(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_SNAPSHOT1_S0(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_SNAPSHOT2_S0(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_SNAPSHOT3_S0(gpcId, tpcId, smIdInTpc);

                        /*********************
                        Quad 1:
                        *********************/
                       // HI Register:
                        offset[count++] = NV_SM_DSM_PERF_COUNTER_SNAPSHOT_STATUS_S1(gpcId, tpcId, smIdInTpc);
                        // LO Register:
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_SNAPSHOT0_S1(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_SNAPSHOT1_S1(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_SNAPSHOT2_S1(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_SNAPSHOT3_S1(gpcId, tpcId, smIdInTpc);

                        /*********************
                        Quad 2:
                        *********************/
                       // HI Register:
                        offset[count++] = NV_SM_DSM_PERF_COUNTER_SNAPSHOT_STATUS_S2(gpcId, tpcId, smIdInTpc);
                        // LO Register:
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_SNAPSHOT0_S2(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_SNAPSHOT1_S2(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_SNAPSHOT2_S2(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_SNAPSHOT3_S2(gpcId, tpcId, smIdInTpc);

                        /*********************
                        Quad 3:
                        *********************/
                       // HI Register:
                        offset[count++] = NV_SM_DSM_PERF_COUNTER_SNAPSHOT_STATUS_S3(gpcId, tpcId, smIdInTpc);
                        // LO Register:
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_SNAPSHOT0_S3(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_SNAPSHOT1_S3(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_SNAPSHOT2_S3(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_SNAPSHOT3_S3(gpcId, tpcId, smIdInTpc);
                    }
                }

                if (pSM->coreCount) {
                    if (pEventGroup->arch.voltaEventGroup->isSMPCLegacyMode) {
                        // HI Register:
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_STATUS1(gpcId, tpcId, smIdInTpc);
                        // LO Register:
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER4(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER5(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER6(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER7(gpcId, tpcId, smIdInTpc);
                        // HI Register:
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_STATUS1(gpcId, tpcId, smIdInTpc);
                    }
                    else {
                        // HI register
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_SNAPSHOT_STATUS1(gpcId, tpcId, smIdInTpc);
                        // LO Register:
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_SNAPSHOT4(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_SNAPSHOT5(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_SNAPSHOT6(gpcId, tpcId, smIdInTpc);
                        offset[count++]  = NV_SM_DSM_PERF_COUNTER_SNAPSHOT7(gpcId, tpcId, smIdInTpc);
                    }
                }
            }
        }
    }

    // read back perf counter values:
    status = PRIREAD32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, count, offset, counterValues, 0);
    if (CUDA_SUCCESS != status) {
        goto EXIT;
    }

    count = 0;
    for(gpcId = 0; gpcId < pEventGroup->arch.voltaEventGroup->gpcCount; gpcId++)
    {
        for(tpcId = 0; tpcId < pEventGroup->arch.voltaEventGroup->tpcPerGpcCount[gpcId]; tpcId++)
        {
            for(smIdInTpc = 0; smIdInTpc < pEventGroup->pCtx->device->state.limits.numSmsPerTpc; smIdInTpc++)
            {
                regIdx = 0;

                if (pSM->qctlCount) {
                    NvU8 highValues1[4] = {0};
                    NvU8 highValues2[4] = {0};
                    NvU32 numRegs = 24;
                    NvU64 highValuesTemp[4] = {0};
                    NvU32 shiftIdx = 0, counterValuesTemp[4] = {0};
                    cuosMemset(counterValuesQctl, 0, sizeof(NvU64)*4);
                    /***************************************************************************
                    - The while loop will run four times i.e. once for each quadrant
                    - Each quad will require 6 registers to be read
                    1 hi value register
                    4 registers having lo 32 bit counter values for each of the quad counter
                    1 hi value register again to take into account the wrap around case of
                    the hi value register
                    ***************************************************************************/
                    if (pEventGroup->arch.voltaEventGroup->isSMPCLegacyMode) {
                        numRegs = 24;
                    }
                    else {
                        numRegs = 20;
                    }

                    while (regIdx < numRegs) {
                        /*********************************************************************************
                        - Extract the higher 8 bits of signal value from  the status register
                        - The status register will contain higher 8 bits of all the four quad signals.
                        0-7 : quadSig1       8-15:quadSig2
                        16-23: quadSig3      24-31:quadSig4
                        - Store these 8 bits individually in the temporary array
                        *********************************************************************************/
                        for (j = 0; j < CU_PROF_SM_QUAD_PROFILED_MAX; j++) {
                            shiftIdx = j*8;
                            highValues1[j] = (NvU8)((counterValues[count + regIdx] & (0xFF << shiftIdx)) >> shiftIdx);
                        }
                        regIdx++;
                        /*********************************************************************************
                        - Store the lo 32 bits of the counters
                        *********************************************************************************/
                        for(j = 0; j < CU_PROF_SM_QUAD_PROFILED_MAX; j++) {
                            counterValuesTemp[j] = counterValues[count + regIdx++];
                        }
                        /*********************************************************************************
                        - Extract the higher 8 bits of signal value from  the status register
                        - The status register will contain higher 8 bits of all the four quad signals.
                        0-7 : quadSig1       8-15:quadSig2
                        16-23: quadSig3      24-31:quadSig4
                        - Store these 8 bits individually in the temporary array
                        *********************************************************************************/
                        if (pEventGroup->arch.voltaEventGroup->isSMPCLegacyMode) {
                            for (j = 0; j < CU_PROF_SM_QUAD_PROFILED_MAX; j++) {
                                shiftIdx = j*8;
                                highValues2[j] = (NvU8)((counterValues[count + regIdx] & (0xFF << shiftIdx)) >> shiftIdx);
                            }
                            regIdx++;
                            /*********************************************************************************
                            - As the hi and lo bits for the signal values will be read in different cycles,
                            there is a possibility if the hi bits changing till we read them. Hence,
                            we read them in the order hi-lo-hi.
                            - Convert the lo value into signed integer. Compare the lo value
                            If the lo value is positive, take the hi bits read in the next cycle. Else,
                            take the hi bits read from the previous cycle.
                            *********************************************************************************/
                            for(j = 0; j < CU_PROF_SM_QUAD_PROFILED_MAX; j++) {
                                highValuesTemp[j] = (NvU64)((signed int)counterValuesTemp[j] < 0) ? highValues1[j] : highValues2[j];
                            }
                        }
                        else {
                            // Since we read the high 8bit of counter only once in snapshot mode
                            for(j = 0; j < CU_PROF_SM_QUAD_PROFILED_MAX; j++) {
                                highValuesTemp[j] = highValues1[j];
                            }
                        }
                        /*********************************************************************************
                        - left shift the Hi value by 32 (as these are the higher 8 bits out of the 40
                        bit counter value
                        - OR the hi bits with the lo 32 bits to form the 40 bit counter value.
                        *********************************************************************************/
                        for(j = 0; j < CU_PROF_SM_QUAD_PROFILED_MAX; j++) {
                            counterValuesQctl[j] += (NvU64)(((NvU64)counterValuesTemp[j]) | (highValuesTemp[j] << 32));
                            // Update the array holding the higher 8 bits only if the value is 0xFF:
                            highValuesQuad[j] = ((NvU8)highValuesTemp[j] == COUNTER_OVERFLOW_VALUE) ? COUNTER_OVERFLOW_VALUE : highValuesQuad[j];
                        }
                    }
                }
                if (pSM->coreCount) {
                    NvU8 highValues2[4] = {0};
                    NvU64 highValuesTemp[4] = {0};
                    NvU32 shiftIdx, counterValuesTemp[4] = {0};
                    NvU8 highValues1[4] = {0};
                    if (pEventGroup->arch.voltaEventGroup->isSMPCLegacyMode) {
                        regIdx = pSM->qctlCount ? 24 : 0;
                    }
                    else {
                        regIdx = pSM->qctlCount ? 20 : 0;
                    }

                    for(j = 0;j < CU_PROF_SM_CORE_PROFILED_MAX; j++) {
                        shiftIdx = (j*8);
                        highValues1[j] = (NvU8)((counterValues[count + regIdx] & (0xFF << shiftIdx)) >> shiftIdx);
                    }
                    regIdx++;
                    for (j = 0;j < CU_PROF_SM_CORE_PROFILED_MAX; j++) {
                        counterValuesCore[j] = (NvU64)counterValues[count + regIdx++];
                    }
                    /*********************************************************************************
                    - Extract the higher 8 bits of signal value from  the status register
                    - The status register will contain higher 8 bits of all the four quad signals.
                    0-7 : quadSig1       8-15:quadSig2
                    16-23: quadSig3      24-31:quadSig4
                    - Store these 8 bits individually in the temporary array
                    *********************************************************************************/
                    if (pEventGroup->arch.voltaEventGroup->isSMPCLegacyMode) {
                        for(j = 0;j < CU_PROF_SM_CORE_PROFILED_MAX; j++) {
                            shiftIdx = (j*8);
                            highValues2[j] = (NvU8)((counterValues[count + regIdx] & (0xFF << shiftIdx)) >> shiftIdx);
                        }
                        regIdx++;
                        /*********************************************************************************
                        - As the hi and lo bits for the signal values will be read in different cycles,
                        there is a possibility if the hi bits changing till we read them. Hence,
                        we read them in the order hi-lo-hi.
                        - Convert the lo value into signed integer. Compare the lo value
                        If the lo value is positive, take the hi bits read in the next cycle. Else,
                        take the hi bits read from the previous cycle.
                        *********************************************************************************/
                        for(j = 0; j < CU_PROF_SM_CORE_PROFILED_MAX; j++) {
                            highValuesTemp[j] = (NvU64)((signed int)counterValuesTemp[j] < 0) ? highValues1[j] : highValues2[j];
                        }
                    }
                    else {
                        for(j = 0; j < CU_PROF_SM_QUAD_PROFILED_MAX; j++) {
                            highValuesTemp[j] = highValues1[j];
                        }
                    }
                    /*********************************************************************************
                    - left shift the Hi value by 32 (as these are the higher 8 bits out of the 40
                    bit counter value
                    - OR the hi bits with the lo 32 bits to form the 40 bit counter value.
                    *********************************************************************************/
                    for(j = 0; j < CU_PROF_SM_CORE_PROFILED_MAX; j++) {
                        counterValuesCore[j] += (highValuesTemp[j] << 32);
                        // Update the array holding the higher 8 bits only if the value is 0xFF:
                        highValuesCore[j] = ((NvU8)highValuesTemp[j] == COUNTER_OVERFLOW_VALUE) ? COUNTER_OVERFLOW_VALUE : highValuesCore[j];
                    }
                }
                idxQctl = 0;
                idxCore = 0;

                // rearrange counter values
                for(i=0; i<pSM->SMCountersAdded; i++) {
                    switch (pSM->pmUnitId[i]) {
                    case PM_UNIT_SMQCTL:
                        *(pSM->values + (pSM->SMCountersAdded * (tpcIdx * 2 + smIdInTpc)) + i) = counterValuesQctl[idxQctl];
                        idxQctl++;
                        break;
                    case PM_UNIT_SMCORE:
                    case PM_UNIT_MIO:
                        *(pSM->values + (pSM->SMCountersAdded * (tpcIdx * 2 + smIdInTpc)) + i) = counterValuesCore[idxCore];
                        idxCore++;
                        break;
                    }
                }
                count += regIdx;
            }
            tpcIdx++;
        }
    }

EXIT:
    return status;
}

void voltaPerfmonStartCounters(CUnvCurrent** nvCurrent_temp, CUeventGroup *pEventGroup)
{
    // Set the function values only if domanin = SMPerf
    if ((pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX) ||
        (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_SMPERF)) {
        if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_KERNEL) {
            NvU32 valueA = 0, enableValue = 0;
            NvU32 index;
            CUnvCurrent* nvCurrent = *nvCurrent_temp;

            if(pEventGroup->arch.voltaEventGroup->pSM->qctlCount) {
                for (index = 0; index < CU_PROF_SM_QUAD_PROFILED_MAX; index++) {
                    // Zero out the counter values before starting the counters:
                    valueA = HWVALUE(C3C0, SET_SHADER_PERFORMANCE_COUNTER_VALUE, V, 0);
                    NV_PUSH_1U(C3C0, SET_SHADER_PERFORMANCE_COUNTER_VALUE(index),  valueA);
                    // Zero out the upper 8 bits of the 40-bit SMPC counter.
                    valueA = HWVALUE(C3C0, SET_SHADER_PERFORMANCE_COUNTER_VALUE_UPPER, V, 0);
                    NV_PUSH_1U(C3C0, SET_SHADER_PERFORMANCE_COUNTER_VALUE_UPPER(index),  valueA);
                }
            }
            if(pEventGroup->arch.voltaEventGroup->pSM->coreCount) {
                for (index = CU_PROF_SM_QUAD_PROFILED_MAX; index < (CU_PROF_SM_QUAD_PROFILED_MAX+CU_PROF_SM_CORE_PROFILED_MAX); index++) {
                    // Zero out the counter values before starting the counters:
                    valueA = HWVALUE(C3C0, SET_SHADER_PERFORMANCE_COUNTER_VALUE, V, 0);
                    NV_PUSH_1U(C3C0, SET_SHADER_PERFORMANCE_COUNTER_VALUE(index),  valueA);
                    // Zero out the upper 8 bits of the 40-bit SMPC counter.
                    valueA = HWVALUE(C3C0, SET_SHADER_PERFORMANCE_COUNTER_VALUE_UPPER, V, 0);
                    NV_PUSH_1U(C3C0, SET_SHADER_PERFORMANCE_COUNTER_VALUE_UPPER(index),  valueA);
                }
            }
            // Start the counters by setting the enable bits:
            // Set the enable bits only for those slots where we are profiling counters:
            //  The countermask is 8 bit mask where lsb 4 bits specify mask for quad counters
            //        and upper 4 bits are for core. 
            //        0: Dont enable
            //        1: Enable
            if(pEventGroup->arch.voltaEventGroup->pSM->coreCount) {
                enableValue = NV_SM_DSM_PERF_COUNTER_CONTROL_ENABLE_ENABLE >> (CU_PROF_SM_CORE_PROFILED_MAX - pEventGroup->arch.voltaEventGroup->pSM->coreCount);
                enableValue = enableValue << CU_PROF_SM_QUAD_PROFILED_MAX;
            }
            if(pEventGroup->arch.voltaEventGroup->pSM->qctlCount) {
                enableValue |= NV_SM_DSM_PERF_COUNTER_CONTROL_ENABLE_ENABLE >> (CU_PROF_SM_QUAD_PROFILED_MAX - pEventGroup->arch.voltaEventGroup->pSM->qctlCount);
            }
            valueA = HWVALUE(C3C0, START_SHADER_PERFORMANCE_COUNTER, COUNTER_MASK, enableValue);
            NV_PUSH_1U(C3C0, START_SHADER_PERFORMANCE_COUNTER,  valueA);
            *nvCurrent_temp = nvCurrent;
        } else if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS){
            //Start the counters in continuous mode.
            NvU32 *value  = NULL, *offset = NULL, *writeMask = NULL;
            NvU32 count = 0, gpcId = 0, tpcId = 0, smId = 0, enableValueCore = 0, enableValueQuad = 0;
            CUresult status = CUDA_SUCCESS;

            //Allocate memory of size = (2 * #SMs * sizeof(NvU32))
            offset = (NvU32 *)malloc(2 * pEventGroup->instanceCountAvail * sizeof(NvU32));
            value = (NvU32 *)calloc(2 * pEventGroup->instanceCountAvail, sizeof(NvU32));
            writeMask = (NvU32 *)calloc(2 * pEventGroup->instanceCountAvail, sizeof(NvU32));
            if(!(offset && value && writeMask)) {
                CU_ERROR_PRINT(("Error allocating memory for offset-value arrays.\n"));
                goto EXIT;
            }
            // Set the enable bits only for those slots where we are profiling counters:
            if(pEventGroup->arch.voltaEventGroup->pSM->coreCount) {
                enableValueCore = NV_SM_DSM_PERF_COUNTER_CONTROL_ENABLE_ENABLE >> (CU_PROF_SM_CORE_PROFILED_MAX - pEventGroup->arch.voltaEventGroup->pSM->coreCount);
            }
            if(pEventGroup->arch.voltaEventGroup->pSM->qctlCount) {
                enableValueQuad = NV_SM_DSM_PERF_COUNTER_CONTROL_ENABLE_ENABLE >> (CU_PROF_SM_QUAD_PROFILED_MAX - pEventGroup->arch.voltaEventGroup->pSM->qctlCount);
            }

                if (pEventGroup->arch.voltaEventGroup->pSM->qctlCount) {
                    value[count]  = DRF_REPLACE(value[count], enableValueQuad, NV_SM_DSM_PERF_COUNTER_CONTROL_ENABLE);
                    offset[count]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_CONTROL0;
                    writeMask[count++] = ENABLE_BITS_MASK;
                }
                if (pEventGroup->arch.voltaEventGroup->pSM->coreCount) {
                    value[count]  = DRF_REPLACE(value[count], enableValueCore, NV_SM_DSM_PERF_COUNTER_CONTROL_ENABLE);
                    offset[count]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_CONTROL5;
                    writeMask[count++] = ENABLE_BITS_MASK;
                }

            CU_ASSERT(count <= (2 * pEventGroup->instanceCountAvail));
            status = PRIWRITEMASKED32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, count, offset, value, writeMask, 0);
            CU_ASSERT(status == CUDA_SUCCESS);
EXIT:
            if(offset) {
                free(offset);
            }
            if(value) {
                free(value);
            }
            if(writeMask) {
                free(writeMask);
            }
        }
    }
    else if(pEventGroup->domainId == VOLTA_CLK_DOMAIN_GV100_NVLINK_THROUGHPUT_COUNTERS) {
        CUprofResult status = CUPROF_SUCCESS;
        status = setNvlinkEnableRegTC(pEventGroup, NV_TRUE);
        CU_ASSERT(status == CUPROF_SUCCESS);
    }
}

void voltaPerfmonStopCounters(CUnvCurrent** nvCurrent_temp, CUeventGroup *pEventGroup)
{
    // Reset the function values only if domanin = SMPerf
    if ((pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX) ||
        (pEventGroup->domain->eventCollectionMethod == CUPROF_EVENT_COLLECTION_METHOD_SMPERF)) {
        if (pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_KERNEL) {
            CUnvCurrent* nvCurrent = *nvCurrent_temp;
            NvU32 valueA = 0, disableValue = 0;
            // Set the disable bits only for those slots where we are profiling counters:
            //  The countermask is 8 bit mask where lsb 4 bits specify mask for quad counters
            //        and upper 4 bits are for core. 
            //        0: Dont disable
            //        1: Disable
            if(pEventGroup->arch.voltaEventGroup->pSM->coreCount) {
                disableValue = NV_SM_DSM_PERF_COUNTER_CONTROL_ENABLE_ENABLE >> (CU_PROF_SM_CORE_PROFILED_MAX - pEventGroup->arch.voltaEventGroup->pSM->coreCount);
                disableValue = disableValue << CU_PROF_SM_QUAD_PROFILED_MAX;
            }
            if(pEventGroup->arch.voltaEventGroup->pSM->qctlCount) {
                disableValue |= NV_SM_DSM_PERF_COUNTER_CONTROL_ENABLE_ENABLE >> (CU_PROF_SM_QUAD_PROFILED_MAX - pEventGroup->arch.voltaEventGroup->pSM->qctlCount);
            }
            valueA = HWVALUE(C3C0, STOP_SHADER_PERFORMANCE_COUNTER, COUNTER_MASK, disableValue);
            NV_PUSH_1U(C3C0, STOP_SHADER_PERFORMANCE_COUNTER,  valueA);
            *nvCurrent_temp = nvCurrent;
        } else {
            //Stop the counters in continuous mode. SM counters keep running unless we set the ENABLE bits to 0.
            NvU32 *value  = NULL, *offset = NULL, *writeMask = NULL;
            NvU32 count = 0, gpcId = 0, tpcId = 0, smId = 0;
            CUresult status = CUDA_SUCCESS;

            //Allocate memory of size = (2 * #SMs * sizeof(NvU32))
            offset = (NvU32 *)malloc(2 * pEventGroup->instanceCountAvail * sizeof(NvU32));
            value = (NvU32 *)calloc(2 * pEventGroup->instanceCountAvail, sizeof(NvU32));
            writeMask = (NvU32 *)calloc(2 * pEventGroup->instanceCountAvail, sizeof(NvU32));
            if(!(offset && value && writeMask)) {
                CU_ERROR_PRINT(("Error allocating memory for offset-value arrays.\n"));
                goto EXIT;
            }
            offset[count] = NV_PERF_PMASYS_TRIGGER_GLOBAL;
            value[count++] = HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, MANUAL_STOP, PULSE);
            status = PRIWRITE32(pEventGroup->pCtx, pEventGroup->pCtx->pmNew->regOpType, count, offset, value, 0);
            if(status != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Error while writing register. \n"));
                goto EXIT;
            }
            count = 0;

                if (pEventGroup->arch.voltaEventGroup->pSM->qctlCount) {
                    offset[count] = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_CONTROL0;
                    writeMask[count++] = ENABLE_BITS_MASK;
                }
                if (pEventGroup->arch.voltaEventGroup->pSM->coreCount) {
                    offset[count]  = NV_PGRAPH_PRI_EGPCS_ETPCS_SM_DSM_PERF_COUNTER_CONTROL5;
                    writeMask[count++] = ENABLE_BITS_MASK;
                }

            CU_ASSERT(count <= (2 * pEventGroup->instanceCountAvail));
            status = PRIWRITEMASKED32(pEventGroup->pCtx, CU_PRI_REG_CONTEXT, count, offset, value, writeMask, 0);
            CU_ASSERT(status == CUDA_SUCCESS);
EXIT:
            if(offset) {
                free(offset);
            }
            if(value) {
                free(value);
            }
            if(writeMask) {
                free(writeMask);
            }
        }
    }
    else if(pEventGroup->domainId == VOLTA_CLK_DOMAIN_GV100_NVLINK_THROUGHPUT_COUNTERS) {
        CUprofResult status = CUPROF_SUCCESS;
        status = setNvlinkEnableRegTC(pEventGroup, NV_FALSE);
        CU_ASSERT(status == CUPROF_SUCCESS);
    }
}

static uint32_t getPCSamplingStallReasonDriver(uint32_t cantIssueReason)
{
    // If the environment variable is set to expose all the cant issue reasons
    // from driver, then return the same cant issue reason, if it is valid.
    switch(cantIssueReason) {
    case CUPROF_VOLTA_WARP_CANT_ISSUE_MISC:
         return CUPROF_WARP_CANT_ISSUE_MISC;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_NOT_SELECTED:
         return CUPROF_WARP_CANT_ISSUE_NOT_SELECTED;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_SELECTED:
         return CUPROF_WARP_CANT_ISSUE_SELECTED;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_DISPATCH_STALL:
         return CUPROF_WARP_CANT_ISSUE_DISPATCH_STALL;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_MIO_THROTTLE:
         return CUPROF_WARP_CANT_ISSUE_MIO_THROTTLE;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_LG_THROTTLE:
         return CUPROF_WARP_CANT_ISSUE_LG_THROTTLE;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_TEX_THROTTLE:
         return CUPROF_WARP_CANT_ISSUE_TEX_THROTTLE;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_SHADOW_PIPE_THROTTLE:
         return CUPROF_WARP_CANT_ISSUE_SHADOW_PIPE_THROTTLE;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_NO_INSTRUCTIONS:
         return CUPROF_WARP_CANT_ISSUE_NO_INSTRUCTIONS;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_SHORT_SCOREBOARD:
         return CUPROF_WARP_CANT_ISSUE_ON_DECK_SHORT_SCOREBOARD;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_LONG_SCOREBOARD:
         return CUPROF_WARP_CANT_ISSUE_ON_DECK_LONG_SCOREBOARD;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_WAIT:
         return CUPROF_WARP_CANT_ISSUE_WAIT;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_BRANCH_RESOLVING:
         return CUPROF_WARP_CANT_ISSUE_BRANCH_RESOLVING;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_SLEEPING:
         return CUPROF_WARP_CANT_ISSUE_SLEEPING;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_MEMBAR:
         return CUPROF_WARP_CANT_ISSUE_MEMBAR;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_BARRIER:
         return CUPROF_WARP_CANT_ISSUE_BARRIER;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_IMC_MISS:
         return CUPROF_WARP_CANT_ISSUE_IMC_MISS;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_DRAIN:
         return CUPROF_WARP_CANT_ISSUE_DRAIN;
    default:
         return CUPROF_WARP_CANT_ISSUE_INVALID;
    }
}

static uint32_t getPCSamplingStallReasonCupti(uint32_t cantIssueReason)
{
    // Map the cant issue reason from driver to the proper one which is
    //    exposed in toolkit
    switch(cantIssueReason)
    {
    case CUPROF_VOLTA_WARP_CANT_ISSUE_SELECTED:
        return CUPROF_PC_SAMPLING_STALL_GROUP_NONE;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_NO_INSTRUCTIONS:
#if NVCFG(GLOBAL_ARCH_VOLTA)
    case CUPROF_VOLTA_WARP_CANT_ISSUE_BRANCH_RESOLVING:
#endif
        return CUPROF_PC_SAMPLING_STALL_GROUP_INST_FETCH;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_SHORT_SCOREBOARD:
    case CUPROF_VOLTA_WARP_CANT_ISSUE_WAIT:
        return CUPROF_PC_SAMPLING_STALL_GROUP_EXEC_DEPENDENCY;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_LONG_SCOREBOARD:
        return CUPROF_PC_SAMPLING_STALL_GROUP_MEMORY_DEPENDENCY;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_TEX_THROTTLE:
        return CUPROF_PC_SAMPLING_STALL_GROUP_TEXTURE;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_BARRIER:
    case CUPROF_VOLTA_WARP_CANT_ISSUE_MEMBAR:
        return CUPROF_PC_SAMPLING_STALL_GROUP_SYNC;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_IMC_MISS:
        return CUPROF_PC_SAMPLING_STALL_GROUP_CONSTANT_MEMORY_DEPENDENCY;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_SHADOW_PIPE_THROTTLE:
    case CUPROF_VOLTA_WARP_CANT_ISSUE_MIO_THROTTLE:
        return CUPROF_PC_SAMPLING_STALL_GROUP_PIPE_BUSY;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_DRAIN:
#if NVCFG(GLOBAL_ARCH_VOLTA)
    case CUPROF_VOLTA_WARP_CANT_ISSUE_LG_THROTTLE:
#endif
        return CUPROF_PC_SAMPLING_STALL_GROUP_MEMORY_THROTTLE;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_NOT_SELECTED:
        return CUPROF_PC_SAMPLING_STALL_GROUP_NOT_SELECTED;
    case CUPROF_VOLTA_WARP_CANT_ISSUE_MISC:
    case CUPROF_VOLTA_WARP_CANT_ISSUE_DISPATCH_STALL:
        return CUPROF_PC_SAMPLING_STALL_GROUP_OTHER;
#if NVCFG(GLOBAL_ARCH_VOLTA)
    case CUPROF_VOLTA_WARP_CANT_ISSUE_SLEEPING:
        return CUPROF_PC_SAMPLING_STALL_GROUP_SLEEPING ;
#endif
    default:
        return CUPROF_PC_SAMPLING_STALL_GROUP_INVALID;
    }
}

#define GETVAL(n, drf) (((n)>>DRF_SHIFT(drf))&DRF_MASK(drf))

CUprofResult CUDAAPI voltaPerfmonPCSamplingRegisterReadCallback(CUctx *ctx,
                                                                 CUprofPCSamplingReadDataCallback pfnCallback,
                                                                 void* pUserData) {
    CUprofResult status = CUPROF_SUCCESS;
    if (!ctx->pmNew) {
        return CUPROF_ERROR_UNKNOWN;
    }
    ctx->pmNew->pcSamplingReadDataCallback = pfnCallback;
    ctx->pmNew->userData = pUserData;
    return status;
}

#ifndef NV_MODS
static void deleteBuffNode(void *element, void *param) {
    CUprofBuff *tempBuff;
    tempBuff = (CUprofBuff *) element;
    free(tempBuff->buff);
}
#endif

// tools_shared code is not accessible on mods
#if defined(NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV100) && !defined(NV_MODS)
static CUprofResult PCSamplingHashMapToBuffer(CUctx *ctx, NvU32 **buffer, size_t *bufferSize, NvU32 droppedRecords) {
    tHashMapItr *itr = NULL;
    tHashMapKey_t key;
    CUprofSamplingData *data  = NULL;
    NvU32 numVaildCirs = 0, i = 0, idx = 0, bufferIdx = 0, validCirIndex = 0, totalRecords = 0;
    tHashMap *samplingDataHashMap;
    CUprofResult status = CUPROF_SUCCESS;

    /** Adding Variables for Debugging.
    NvU64 pcOffset = 0, pcOffsetHi;
    **/
    /*******************************************************************************
                                     BUFFER FORMAT:
                       |-----                CIR 1------                  |-----                CIR 2------                  |    |-----                CIR n------                 |
     PC1 #| VALID CIRS#| CIR1 #| SAMPLES#| LATENCY SAMPLES#| INST_ISSUED0#| CIR2 #| SAMPLES#| LATENCY SAMPLES#| INST_ISSUED0#| ...|CIRn #| SAMPLES#| LATENCY SAMPLES#| INST_ISSUED0#|
     PC2 #| VALID CIRS#| CIR1 #| SAMPLES#| LATENCY SAMPLES#| INST_ISSUED0#| CIR2 #| SAMPLES#| LATENCY SAMPLES#| INST_ISSUED0#| ...|CIRn #| SAMPLES#| LATENCY SAMPLES#| INST_ISSUED0#|
     ...
     PCn #| VALID CIRS#| CIR1 #| SAMPLES#| LATENCY SAMPLES#| INST_ISSUED0#| CIR2 #| SAMPLES#| LATENCY SAMPLES#| INST_ISSUED0#| ...|CIRn #| SAMPLES#| LATENCY SAMPLES#| INST_ISSUED0#|
    ********************************************************************************/
    samplingDataHashMap = (tHashMap *) ctx->device->state.profilerState.samplingDataHashMap;

    if (!samplingDataHashMap) {
        status = CUPROF_ERROR_UNKNOWN;
        goto EXIT;
    }

    /* Allocating Size to Buffer
     * The total size will be (total_no_of_pc * sizeof(NvU32) * (MAX_CIR * 3 + 3(storing PC & num_valid_cir for each PC)) 
                                            + (sizeof(NvU32) * 2(storing totalRecords & droppedRecords at the end of the buffer)))
     * The above allocated memory will only be used completely when all the PC's have non zero samples for all stall reasons.
     * In all the other cases the remaining memory is not used
     */
    *buffer = (NvU32 *) malloc(toolsHashMapSize(samplingDataHashMap) * sizeof(NvU32) * (CUPROF_WARP_CANT_ISSUE_MAX_CIR * 3 + 3) + ( sizeof(NvU32) * 2) );

    // Iterate through the hashmap and dump data in required format in the
    //     buffer for passing it to CUPTI:
    itr = toolsHashMapGetIterator(samplingDataHashMap);
    for (; itr; itr = toolsHashMapGetNext(samplingDataHashMap,itr)) {
        numVaildCirs = 0; idx = 0;
        data = (CUprofSamplingData *)toolsHashMapGetEntry(itr);
        key = toolsHashMapGetKey(itr);
        // In Volta, PC is 45 bit, buffer being 32 bit array,
        // (*buffer)[bufferIdx]     = 32 LSB of PC.
        // (*buffer)[bufferIdx + 1] = 32 MSB of PC.
        (*buffer)[bufferIdx++] = ((NvU64)key & 0xffffffff);
        (*buffer)[bufferIdx++] = (((NvU64)key >> 32 ) & 0xffffffff);
        validCirIndex = bufferIdx++;  // This index is recorded in variable validCirIndex and is used later to fill the numValidCirs which is calculated later.
        for(i=CUPROF_WARP_CANT_ISSUE_DRAIN ; i<CUPROF_WARP_CANT_ISSUE_MAX_CIR; i++) {
            if(data[i].totalSamples != 0) {
                numVaildCirs++;
                (*buffer)[bufferIdx++] = i;
                (*buffer)[bufferIdx++] = data[i].totalSamples;
                (*buffer)[bufferIdx++] = data[i].latencySamples;
                totalRecords += data[i].totalSamples;
            }
        }
        free(data);

        (*buffer)[validCirIndex] = numVaildCirs;
    }
    if(bufferIdx == 0) {
        // return from here if there are no samples for the kernel
        goto EXIT;
    }
    (*buffer)[bufferIdx++] = totalRecords + droppedRecords;
    (*buffer)[bufferIdx++] = droppedRecords;
   /*******************************************************************************
    Print the buffer created (Keeping commented for now for debug purposes only):
    i = 0; idx = 0;
    while (i< (bufferIdx - 2)) {
        pcOffset        = (*buffer)[i++];
        pcOffsetHi      = (*buffer)[i++];
        pcOffset        = pcOffset | (pcOffsetHi << 32);
        numVaildCirs    = (*buffer)[i];

        printf("\nPC: 0x%.08llx\t", (unsigned long long)pcOffset);
        printf("NUM PAIRS:%d\t", (*buffer)[i++]);

        for(idx = 0 ; idx<numVaildCirs ; idx++) {
            printf("%d:", (*buffer)[i++]);
            printf("%d\t", (*buffer)[i++]);
            printf("%d\t", (*buffer)[i++]);
        }
    }
    *******************************************************************************/
    *bufferSize = bufferIdx * sizeof(NvU32);
EXIT:
    return status;
}
#else
static CUprofResult PCSamplingHashMapToBuffer(CUctx *ctx, NvU32 **buffer, size_t *bufferSize, NvU32 droppedRecords) {
    return CUPROF_SUCCESS;
}
#endif

CUprofResult voltaConsumePMABuffer(CUctx *ctx) {
    CUprofResult status = CUPROF_SUCCESS;

#ifndef NV_MODS
    ctx->device->state.profilerState.samplingDataHashMap
                      = (void*) toolsHashMapNew(toolsUint32HashFun, toolsUint64EqualFun, 64);
#endif

    status = startStreaming(ctx);
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("Failed to start streaming\n"));
    }

    if(!ctx->device->state.profilerState.samplingThreadReadData) {
        int cuosStatus = CUOS_SUCCESS;
        ctx->device->state.profilerState.totalDroppedRecords = 0;
        ctx->device->state.profilerState.terminateSamplingThread = 0;
        ctx->device->state.profilerState.terminateSamplingParseDataThread = 0;
        // create the readSemaphore to signal the worker thread at the end to flush data
        cuosStatus = cuosSemaphoreCreate(&ctx->device->state.profilerState.readSemaphore, 0);
        if (cuosStatus) {
             CU_ASSERT(0);
             goto EXIT;
        }

        cuiMutexInitialize(&ctx->device->state.profilerState.buffListMutex, CUI_MUTEX_ORDER_TERMINAL, CUI_MUTEX_DEFAULT);
#ifndef NV_MODS
        ctx->device->state.profilerState.buffList = (void *) toolsListNew();
#endif
        if (!ctx->device->state.profilerState.buffList) {
            status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
            goto EXIT;
        }

        cuosStatus = cuosThreadCreate(&ctx->device->state.profilerState.samplingThreadReadData, voltaPerfmonPCSamplingReadData, (void *) ctx);
        if (CUOS_SUCCESS != cuosStatus) {
            CU_ASSERT(0);
            status = CUPROF_ERROR_UNKNOWN;
            goto EXIT;
        }
        cuosStatus = cuosThreadCreate(&ctx->device->state.profilerState.samplingThreadParseData, voltaPerfmonPCSamplingParseData, (void *) ctx);
        if (CUOS_SUCCESS != cuosStatus) {
            CU_ASSERT(0);
            status = CUPROF_ERROR_UNKNOWN;
            goto EXIT;
        }
    }

EXIT:
#ifndef BUG_1259185_FIXED
    if (ctx->device->dmalType != CU_DMAL_AMODEL) {
        if (status != CUPROF_SUCCESS) {
            if(ctx->device->state.profilerState.samplingThreadReadData) {
                int retCode = 0;
                ctx->device->state.profilerState.terminateSamplingThread = 1;
                cuosThreadJoin(ctx->device->state.profilerState.samplingThreadReadData, &retCode);
                if (retCode != 0) {
                    CU_ERROR_PRINT(("Failed to join sampling thread\n"));
                }
                ctx->device->state.profilerState.samplingThreadReadData = NULL;
            }
            if(ctx->device->state.profilerState.samplingThreadParseData) {
                int retCode = 0;
                cuosThreadJoin(ctx->device->state.profilerState.samplingThreadParseData, &retCode);
                if (retCode != 0) {
                    CU_ERROR_PRINT(("Failed to join sampling thread\n"));
                }
                ctx->device->state.profilerState.samplingThreadParseData = NULL;
            }
            cuosSemaphoreDestroy(&ctx->device->state.profilerState.readSemaphore);
            if (ctx->device->state.profilerState.buffList) {
                cuiMutexLock(&ctx->device->state.profilerState.buffListMutex);
#ifndef NV_MODS
                toolsListDelete((tList *) ctx->device->state.profilerState.buffList, deleteBuffNode, NULL);
#endif
                ctx->device->state.profilerState.buffList = NULL;
                cuiMutexUnlock(&ctx->device->state.profilerState.buffListMutex);
            }

            cuiMutexDeinitialize(&ctx->device->state.profilerState.buffListMutex);

        }
    }
#endif
    return status;
}

CUprofResult voltaReadIntermdiateBuffer(CUctx *ctx)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *buffer = NULL;
    size_t bufferSize = 0;

    status = stopStreaming(ctx);
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("Failed to stop streaming\n"));
    }

    if (ctx->device->state.profilerState.samplingThreadReadData) {
        int retCode = 0;
        cuosSemaphoreSignal(&ctx->device->state.profilerState.readSemaphore);
        cuosSleep(SAMPLING_TIMEOUT*2);
        ctx->device->state.profilerState.terminateSamplingThread = 1;

        cuosThreadJoin(ctx->device->state.profilerState.samplingThreadReadData, &retCode);
        if (retCode != 0) {
            CU_ERROR_PRINT(("Failed to join sampling thread\n"));
            status = (CUprofResult)retCode;
        }
        ctx->device->state.profilerState.samplingThreadReadData = NULL;
        if (ctx->device->state.profilerState.samplingThreadParseData) {
            cuosThreadJoin(ctx->device->state.profilerState.samplingThreadParseData, &retCode);
            if (retCode != 0) {
                CU_ERROR_PRINT(("Failed to join sampling thread\n"));
                status = (CUprofResult)retCode;
            }
            ctx->device->state.profilerState.samplingThreadParseData = NULL;
        }

        cuosSemaphoreDestroy(&ctx->device->state.profilerState.readSemaphore);
        if (ctx->device->state.profilerState.buffList) {
            cuiMutexLock(&ctx->device->state.profilerState.buffListMutex);
#ifndef NV_MODS
            toolsListDelete((tList *) ctx->device->state.profilerState.buffList, deleteBuffNode, NULL);
#endif
            ctx->device->state.profilerState.buffList = NULL;
            cuiMutexUnlock(&ctx->device->state.profilerState.buffListMutex);
        }

        cuiMutexDeinitialize(&ctx->device->state.profilerState.buffListMutex);

    }

    // Dump data into compact buffer which can be passed to CUPTI:
    PCSamplingHashMapToBuffer(ctx, &buffer, &bufferSize, ctx->device->state.profilerState.totalDroppedRecords);

    // Call the callBack function registered:
    ctx->pmNew->pcSamplingReadDataCallback(buffer, bufferSize, ctx->pmNew->userData);

    // Free the memory allocated for hashMap and buffer used for reading the sampling records from hardware:
    if (buffer) {
        free(buffer);
    }
    #ifndef NV_MODS
    toolsHashMapDelete((tHashMap*)ctx->device->state.profilerState.samplingDataHashMap, NULL, NULL);
    #endif
    return status;
}

CUprofResult voltaBeginPCSampling(CUctx *ctx)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *value = NULL;
    NvU32 count = 0, size = 0, numReg = 0, pmmBroadcastInstances = 0;
    NvU32 *domainRegOffset = NULL, instance = 0, maxInstances = 0;
    NvU32 perfmonid = 0;
    //Set dummy varaibles for emulation
    //Refactor setupPMTarget to get below values indepdent of eventGroup data structure
    NvU32 clkIdx;
    NvU32 gpcCount = ctx->device->state.limits.numGpcs;
    NvU32 *tpcPerGpcCount = ctx->device->state.limits.numTpcsPerGpc;
    NvU32 *pmmAddress = NULL;
    enum broadcast_enum broadcastType = BROADCAST_NONE;

    CU_TRACE_FUNCTION();

    clkIdx = 2; // 2 perfmon per GPC

    status = perfmonSetupPMCtxswMode(ctx, NV_FALSE);
    if (CUPROF_SUCCESS != status) {
        CU_ERROR_PRINT(("Failed to re-set the PM Ctxsw bit\n"));
        return CUPROF_ERROR_UNKNOWN;
    }
    // Check if the PM CtxSw bit is disabled and assign the proper regOp type:
    ctx->pmNew->regOpType = ctx->pmNew->isPmCtxswModeEnabled ? CU_PRI_REG_CONTEXT : CU_PRI_REG_GLOBAL;

#if cuiPlatformIncludesMrm()
    ctx->pmNew->isCSSDisabled = perfmonCssDisabled();
#endif

    pmmBroadcastInstances = 2;
    maxInstances = ctx->device->state.limits.physicalTpcCount * ctx->device->state.limits.numSmsPerTpc;
    maxInstances = ((maxInstances > pmmBroadcastInstances) ? (maxInstances) : pmmBroadcastInstances);

    pmmAddress = (NvU32*)malloc(maxInstances * sizeof(NvU32));
    domainRegOffset = (NvU32*)malloc(maxInstances * sizeof(NvU32));
    if (!domainRegOffset || !pmmAddress) {
        status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    //8 - reset sel+op for all 4 counters
    //8 - set sel+op for all 4 counters
    //4 - PMM_CONTROL, control2, sampling, sm_pm_ctrl
    numReg = 14 + ((8 + 8 + 10) * maxInstances); //TBD: Replace the magic no
    size = sizeof(NvU32) * numReg;
    offset = (NvU32*)malloc(size);
    value  = (NvU32*)calloc(size, 1);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset and value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    broadcastType = BROADCAST_PERFMON_TYPE;
#ifdef DEBUG
    {
    char szEnvironment[CUDA_PRI_REG_ENV_LEN];
    if (!(cuosGetEnv("ENABLE_PMM_UNICAST", szEnvironment, CUOS_ENV_VAR_LENGTH))) {
        //Default is broadcast but override with unicast if environment variable
        //is set, will be used only for debugging
        broadcastType = BROADCAST_NONE;
    }
    }
#endif
    getSMPMMAddress(ctx, pmmAddress, &maxInstances);
    count = 0;
    //perfmon ID needs to be set in unicast registers
        for (instance = 0; instance < maxInstances; instance++) {
            // TBD : PMM broadcast will be supported in Volta which can be used to optimize PMM config.
            offset[count] = pmmAddress[instance] + clkIdx * NV_PMM_DOMAIN_OFFSET + NV_PMM_CONTROL;
            perfmonid = 0;

            if((ctx->device->dmalType != CU_DMAL_MRM)
#if cuiPlatformIncludesMrm()
#if defined(NVGPU_IOCTL_CHANNEL_CYCLE_STATS_SNAPSHOT)
            || !ctx->device->dm.mrm->nvRmGpuDeviceInfo->hasCycleStatsSnapshot
#endif
            || ctx->pmNew->isCSSDisabled
#endif
            ) {
                //On Volta : perfmonId will be of 11 bits
                perfmonid = instance;
            }
#if cuiPlatformIncludesMrm()
            else {
#if defined(NVGPU_IOCTL_CHANNEL_CYCLE_STATS_SNAPSHOT)
                // Assign perfmonid based on value returned by
                // NvRmGpuChannelCycleStatsAttachSnapshot
                perfmonid = ctx->pmNew->perfmonIdStart + instance;
#endif
            }
#endif
            value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_MODE_E, NV_PERF_PMMSYS_CONTROL_MODE);
            value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_CTXSW_MODE_DISABLED, NV_PERF_PMMSYS_CONTROL_CTXSW_MODE);
            value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES_DISABLED, NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES);
            value[count] = DRF_REPLACE(value[count], perfmonid, NV_PERF_PMMSYS_CONTROL_PERFMONID);
            count++;

            offset[count] = pmmAddress[instance] + clkIdx * NV_PMM_DOMAIN_OFFSET + NV_PMM_CONTROL4;
            value[count] = DRF_REPLACE(value[count], 0x0, NV_PERF_PMMGPC_CONTROLD_PERFMONID_MSB);
            count++;
        }

    if (broadcastType == BROADCAST_PERFMON_TYPE) {
        domainRegOffset[0] = NV_PERF_PMMGPC_GPCGS_GPCTPCA;
        domainRegOffset[1] = NV_PERF_PMMGPC_GPCGS_GPCTPCB;
        maxInstances = 2;
    } else {
        for (instance = 0; instance < maxInstances; instance++) {
            // TBD : PMM broadcast will be supported in Volta which can be used to optimize PMM config.
            domainRegOffset[instance] = pmmAddress[instance] + clkIdx * NV_PMM_DOMAIN_OFFSET;
        }
    }

    //setupPMRegistersModeCommon
    offset[count++]  = NV_PERF_PMASYS_GPC_TRIGGER_STATUS;

    offset[count++]  = NV_PERF_PMASYS_FBP_TRIGGER_STATUS;

    offset[count++]  = NV_PERF_PMASYS_SYS_TRIGGER_STATUS;

    offset[count]  = NV_PERF_PMASYS_CONTROL;
    value[count++] = HWCONST(_PERF_PMASYS, CONTROL, STOPVPMCAPTURE, DOIT);

    offset[count++]  = NV_PERF_PMASYS_CONTROL;

    // setup PMA to push trigger to GPC chiplet
    offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_START_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_STOP_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_SYS_TRIGGER_START_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_SYS_TRIGGER_STOP_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_FBP_TRIGGER_START_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_FBP_TRIGGER_STOP_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_TRIGGER_GLOBAL;
    value[count++] = HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, ENABLE, ENABLED) |
        HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_GPC, ENABLE) |
        HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_FBP, ENABLE) |
        HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_SYS, ENABLE);

    offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_CONFIG_MIXED_MODE;
    value[count++] = 0xffffffff;

    for (instance = 0; instance < maxInstances; instance++) {
        // TBD : PMM broadcast will be supported in Volta which can be used to optimize PMM config.
        {
            //setupPMRegistersModeCommon
            offset[count] = domainRegOffset[instance] + NV_PMM_CLAMP_CYA_CONTROL;
            value[count++] = NV_PMM_CLAMP_CYA_CONTROL_ENABLECYA_DISABLE;
            offset[count++]  = domainRegOffset[instance] + NV_PERF_WBSKEW0;
            offset[count++]  = domainRegOffset[instance] + NV_PERF_WBSKEW1;
            offset[count++]  = domainRegOffset[instance] + NV_PERF_WBSKEW2;
            offset[count++]  = domainRegOffset[instance] + NV_PERF_WBSKEW_CHAIN0;
            offset[count++]  = domainRegOffset[instance] + NV_PERF_WBSKEW_CHAIN1;

            offset[count] = domainRegOffset[instance] + NV_PMM_CONTROL2;
            value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROLB_MODEE_USERDATA_ENABLED, NV_PERF_PMMSYS_CONTROLB_MODEE_USERDATA);
            value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROLB_FLUSH_RECORD_DOIT, NV_PERF_PMMSYS_CONTROLB_FLUSH_RECORD);
            count++;
        }

        offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG0_SEL;
        value[count++] = 0;
        offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG0_OP;
        value[count++] = 0;
        offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG1_SEL;
        value[count++] = 0;
        offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG1_OP;
        value[count++] = 0;
        offset[count]  = domainRegOffset[instance] + NV_PMM_EVENT_SEL;
        value[count++] = 0;
        offset[count]  = domainRegOffset[instance] + NV_PMM_EVENT_OP;
        value[count++] = 0;
        offset[count]  = domainRegOffset[instance] + NV_PMM_SAMPLE_SEL;
        value[count++] = 0;
        offset[count]  = domainRegOffset[instance] + NV_PMM_SAMPLE_OP;
        value[count++] = 0;

#if NVCFG(GLOBAL_CHIP_T194) || NVCFG(GLOBAL_GPU_IMPL_GV11B)
        if (ctx->device->state.chip == (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV110 +
                                NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GV11B)) {
            offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG0_SEL;
            value[count++] = 0x19181716;
            offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG0_OP;
            value[count++] = 0xffff;
            offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG1_SEL;
            value[count++] = 0x1d1c1b1a;
            offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG1_OP;
            value[count++] = 0xffff;
            offset[count]  = domainRegOffset[instance] + NV_PMM_EVENT_SEL;
            value[count++] = 0xef1eef1f;
            offset[count]  = domainRegOffset[instance] + NV_PMM_EVENT_OP;
            value[count++] = TRUTH_TABLE_FUNCTION_BIT_0_TRUE|TRUTH_TABLE_FUNCTION_BIT_2_TRUE;// 0xffff;
            
            //AssertEngineModeB
            offset[count]  = domainRegOffset[instance] + NV_PMM_ENGINE_SEL;
            value[count++] = GV11B_NV_PERF_SIGVAL_PMA_TRIGGER;            
        }
        else
#endif
        {
            offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG0_SEL;
            value[count++] = 0x03020100;
            offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG0_OP;
            value[count++] = 0xffff;
            offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG1_SEL;
            value[count++] = 0x07060504;
            offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG1_OP;
            value[count++] = 0xffff;
            offset[count]  = domainRegOffset[instance] + NV_PMM_EVENT_SEL;
            value[count++] = 0xef08ef09;
            offset[count]  = domainRegOffset[instance] + NV_PMM_EVENT_OP;
            value[count++] = TRUTH_TABLE_FUNCTION_BIT_0_TRUE|TRUTH_TABLE_FUNCTION_BIT_2_TRUE;// 0xffff;

            //AssertEngineModeB
            offset[count]  = domainRegOffset[instance] + NV_PMM_ENGINE_SEL;
            value[count++] = GV100_NV_PERF_PMMGPC_GPCTPCA0_SIGVAL_PMA_TRIGGER;
        }
    }

    CU_ASSERT(count <= numReg);
    // write signal configuration
    if (CUDA_SUCCESS != PRIWRITE32(ctx, ctx->pmNew->regOpType, count, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }
    // Set the SM_PM_SAMP_CTRL register using global access (Bug : 200241963),
    // and SM_PM_CTRL register using per-context access
    {
        count = 0;
        offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_CTRL;
        value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_SEL_PROFILER, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_SEL);
        value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_ENABLE_ENABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_ENABLE);
        value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_QCTL_ENABLE_ENABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_QCTL_ENABLE);
        value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_MIO_ENABLE_ENABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_MIO_ENABLE);
        count++;

        if (CUDA_SUCCESS != PRIWRITE32(ctx, ctx->pmNew->regOpType, count, offset, value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }

        count = 0;
        offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL;
        value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL_ENABLE_ENABLE, NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL_ENABLE);
        value[count]  = DRF_REPLACE(value[count], ctx->pmNew->samplingPeriod, NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL_TIMER);
        count++;

        // write signal configuration
        if (CUDA_SUCCESS != PRIWRITE32(ctx, CU_PRI_REG_CONTEXT, count, offset, value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }
    }
EXIT:
    free (offset);
    free (value);
    free(pmmAddress);
    return status;

}

CUprofResult voltaEndPCSampling(CUctx *ctx)
{
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 pmmBroadcastInstances = 0;
    NvU32 gpcId = 0, tpcId = 0, SMIdx = 0;
    NvU32 *offset = NULL, *value = NULL, allocSize = 0;
    NvU32 count = 0, numReg = 0, clkIdx;
    NvU32 *domainRegOffset = NULL, instance = 0, maxInstances = 0;
    NvU32 *pmmAddress = NULL;
    NvU32 gpcCount = ctx->device->state.limits.numGpcs;
    NvU32 *tpcPerGpcCount = ctx->device->state.limits.numTpcsPerGpc;
    enum broadcast_enum broadcastType = BROADCAST_NONE;

    CU_TRACE_FUNCTION();

    clkIdx = 2;
    pmmBroadcastInstances = 2;
    maxInstances = ctx->device->state.limits.physicalTpcCount * ctx->device->state.limits.numSmsPerTpc;
    maxInstances = ((maxInstances > pmmBroadcastInstances) ? (maxInstances) : pmmBroadcastInstances);

    pmmAddress = (NvU32*)malloc(maxInstances * sizeof(NvU32));
    domainRegOffset = (NvU32*)malloc(maxInstances * sizeof(NvU32));
    if (!domainRegOffset || !pmmAddress) {
        status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }
    broadcastType = BROADCAST_PERFMON_TYPE;
#ifdef DEBUG
    {
    char szEnvironment[CUDA_PRI_REG_ENV_LEN];
    if (!(cuosGetEnv("ENABLE_PMM_UNICAST", szEnvironment, CUOS_ENV_VAR_LENGTH))) {
        //Default is broadcast but override with unicast if environment variable
        //is set, will be used only for debugging
        broadcastType = BROADCAST_NONE;
    }
    }
#endif
    if (broadcastType == BROADCAST_PERFMON_TYPE) {
        domainRegOffset[0] = NV_PERF_PMMGPC_GPCGS_GPCTPCA;
        domainRegOffset[1] = NV_PERF_PMMGPC_GPCGS_GPCTPCB;
        maxInstances = 2;
    }
    else {
        getSMPMMAddress(ctx, pmmAddress, &maxInstances);
        for (instance = 0; instance < maxInstances; instance++) {
            // TBD : PMM broadcast will be supported in Volta which can be used to optimize PMM config.
            domainRegOffset[instance] = pmmAddress[instance] + clkIdx * NV_PMM_DOMAIN_OFFSET;
        }
    }

    //8 - reset sel+op for all 4 counters
    //8 - set sel+op for all 4 counters
    //4 - control, control2, sampling, , sm_pm_ctrl
    numReg = (8 + 8 + 4) * maxInstances; //TBD: Replace the magic no
    allocSize = sizeof(NvU32) * numReg;
    offset = (NvU32*)malloc(allocSize);
    value  = (NvU32*)calloc(allocSize, 1);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset and value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    //Disable sampling:
    for (instance = 0; instance < maxInstances; instance++) {
        offset[count] = domainRegOffset[instance] + NV_PMM_CONTROL;
        value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_MODE_DISABLE, NV_PERF_PMMSYS_CONTROL_MODE);
        value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_CTXSW_MODE_DISABLED, NV_PERF_PMMSYS_CONTROL_CTXSW_MODE);
        count++;

        offset[count] = domainRegOffset[instance] + NV_PMM_CONTROL2;
        value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROLB_MODEE_USERDATA_DISABLED, NV_PERF_PMMSYS_CONTROLB_MODEE_USERDATA);
        count++;
    }
    CU_ASSERT(count <= numReg);

    if (CUDA_SUCCESS != PRIWRITE32(ctx, ctx->pmNew->regOpType, count, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

    // Disable sampling for SM unit :
    // Set the SM_PM_SAMP_CTRL register using global access (Bug : 200241963),
    // and SM_PM_CTRL register using per-context access
    {
        count = 0;
        offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_CTRL;
        value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_ENABLE_DISABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_ENABLE);
        value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_QCTL_ENABLE_DISABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_QCTL_ENABLE);
        value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_MIO_ENABLE_DISABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_MIO_ENABLE);
        count++;

        if (CUDA_SUCCESS != PRIWRITE32(ctx, ctx->pmNew->regOpType, count, offset, value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }

        count = 0;
        offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL;
        value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL_ENABLE_DISABLE, NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL_ENABLE);
        count++;

        if (CUDA_SUCCESS != PRIWRITE32(ctx, CU_PRI_REG_CONTEXT, count, offset, value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }
    }
EXIT:
    free (offset);
    free (value);
    free(pmmAddress);
    return status;
}

CUprofResult voltaPerfmonPCSamplingEnable(CUctx *ctx) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *offset = NULL, *value = NULL;
    NvU32 count = 0, size = 0, numReg = 0, pmmBroadcastInstances = 0;
    NvU32 *domainRegOffset = NULL, instance = 0, maxInstances = 0;
    NvU32 perfmonid = 0;
    //Set dummy varaibles for emulation
    //Refactor setupPMTarget to get below values indepdent of eventGroup data structure
    NvU32 clkIdx;
    NvU32 gpcCount = ctx->device->state.limits.numGpcs;
    NvU32 *tpcPerGpcCount = ctx->device->state.limits.numTpcsPerGpc;
    NvU32 *pmmAddress = NULL;
    enum broadcast_enum broadcastType = BROADCAST_NONE;

    CU_TRACE_FUNCTION();

    clkIdx = 2; // 2 perfmon per GPC

    status = perfmonSetupPMCtxswMode(ctx, NV_FALSE);
    if (CUPROF_SUCCESS != status) {
        CU_ERROR_PRINT(("Failed to re-set the PM Ctxsw bit\n"));
        return CUPROF_ERROR_UNKNOWN;
    }
    // Check if the PM CtxSw bit is disabled and assign the proper regOp type:
    ctx->pmNew->regOpType = ctx->pmNew->isPmCtxswModeEnabled ? CU_PRI_REG_CONTEXT : CU_PRI_REG_GLOBAL;

#if cuiPlatformIncludesMrm()
    ctx->pmNew->isCSSDisabled = perfmonCssDisabled();
#endif

#ifndef BUG_1259185_FIXED
    if (ctx->device->dmalType != CU_DMAL_AMODEL) {
        //G84_PERFBUFFER does not get allocated on amodel
        status = setupStreamingResources(ctx);
        if (status != CUPROF_SUCCESS) {
            CU_ERROR_PRINT(("Failed to setup streaming resources\n"));
            goto EXIT;
        }
    }
#endif

    pmmBroadcastInstances = 2;
    maxInstances = ctx->device->state.limits.physicalTpcCount * ctx->device->state.limits.numSmsPerTpc;
    maxInstances = ((maxInstances > pmmBroadcastInstances) ? (maxInstances) : pmmBroadcastInstances);

    pmmAddress = (NvU32*)malloc(maxInstances * sizeof(NvU32));
    domainRegOffset = (NvU32*)malloc(maxInstances * sizeof(NvU32));
    if (!domainRegOffset || !pmmAddress) {
        status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    //8 - reset sel+op for all 4 counters
    //8 - set sel+op for all 4 counters
    //4 - PMM_CONTROL, control2, sampling, sm_pm_ctrl
    numReg = 14 + ((8 + 8 + 10) * maxInstances); //TBD: Replace the magic no
    size = sizeof(NvU32) * numReg;
    offset = (NvU32*)malloc(size);
    value  = (NvU32*)calloc(size, 1);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset and value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    broadcastType = BROADCAST_PERFMON_TYPE;
#ifdef DEBUG
    {
    char szEnvironment[CUDA_PRI_REG_ENV_LEN];
    if (!(cuosGetEnv("ENABLE_PMM_UNICAST", szEnvironment, CUOS_ENV_VAR_LENGTH))) {
        //Default is broadcast but override with unicast if environment variable
        //is set, will be used only for debugging
        broadcastType = BROADCAST_NONE;
    }
    }
#endif
    getSMPMMAddress(ctx, pmmAddress, &maxInstances);
    count = 0;
    //perfmon ID needs to be set in unicast registers
        for (instance = 0; instance < maxInstances; instance++) {
            // TBD : PMM broadcast will be supported in Volta which can be used to optimize PMM config.
            offset[count] = pmmAddress[instance] + clkIdx * NV_PMM_DOMAIN_OFFSET + NV_PMM_CONTROL;
            perfmonid = 0;

            if((ctx->device->dmalType != CU_DMAL_MRM)
#if cuiPlatformIncludesMrm()
#if defined(NVGPU_IOCTL_CHANNEL_CYCLE_STATS_SNAPSHOT)
            || !ctx->device->dm.mrm->nvRmGpuDeviceInfo->hasCycleStatsSnapshot
#endif
            || ctx->pmNew->isCSSDisabled
#endif
            ) {
                //On Volta : perfmonId will be of 11 bits
                perfmonid = instance;
            }
#if cuiPlatformIncludesMrm()
            else {
#if defined(NVGPU_IOCTL_CHANNEL_CYCLE_STATS_SNAPSHOT)
                // Assign perfmonid based on value returned by
                // NvRmGpuChannelCycleStatsAttachSnapshot
                perfmonid = ctx->pmNew->perfmonIdStart + instance;
#endif
            }
#endif
            value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_MODE_E, NV_PERF_PMMSYS_CONTROL_MODE);
            value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_CTXSW_MODE_DISABLED, NV_PERF_PMMSYS_CONTROL_CTXSW_MODE);
            value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES_DISABLED, NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES);
            value[count] = DRF_REPLACE(value[count], perfmonid, NV_PERF_PMMSYS_CONTROL_PERFMONID);
            count++;

            offset[count] = pmmAddress[instance] + clkIdx * NV_PMM_DOMAIN_OFFSET + NV_PMM_CONTROL4;
            value[count] = DRF_REPLACE(value[count], 0x0, NV_PERF_PMMGPC_CONTROLD_PERFMONID_MSB);
            count++;
        }

    if (broadcastType == BROADCAST_PERFMON_TYPE) {
        domainRegOffset[0] = NV_PERF_PMMGPC_GPCGS_GPCTPCA;
        domainRegOffset[1] = NV_PERF_PMMGPC_GPCGS_GPCTPCB;
        maxInstances = 2;
    } else {
        for (instance = 0; instance < maxInstances; instance++) {
            // TBD : PMM broadcast will be supported in Volta which can be used to optimize PMM config.
            domainRegOffset[instance] = pmmAddress[instance] + clkIdx * NV_PMM_DOMAIN_OFFSET;
        }
    }

    //setupPMRegistersModeCommon
    offset[count++]  = NV_PERF_PMASYS_GPC_TRIGGER_STATUS;

    offset[count++]  = NV_PERF_PMASYS_FBP_TRIGGER_STATUS;

    offset[count++]  = NV_PERF_PMASYS_SYS_TRIGGER_STATUS;

    offset[count]  = NV_PERF_PMASYS_CONTROL;
    value[count++] = HWCONST(_PERF_PMASYS, CONTROL, STOPVPMCAPTURE, DOIT);

    offset[count++]  = NV_PERF_PMASYS_CONTROL;

    // setup PMA to push trigger to GPC chiplet
    offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_START_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_STOP_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_SYS_TRIGGER_START_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_SYS_TRIGGER_STOP_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_FBP_TRIGGER_START_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_FBP_TRIGGER_STOP_MASK;
    value[count++] = 0xffffffff;

    offset[count]  = NV_PERF_PMASYS_TRIGGER_GLOBAL;
    value[count++] = HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, ENABLE, ENABLED) |
        HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_GPC, ENABLE) |
        HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_FBP, ENABLE) |
        HWCONST(_PERF_PMASYS, TRIGGER_GLOBAL, TESLA_TRIGGER_MODE_SYS, ENABLE);

    offset[count]  = NV_PERF_PMASYS_GPC_TRIGGER_CONFIG_MIXED_MODE;
    value[count++] = 0xffffffff;

    for (instance = 0; instance < maxInstances; instance++) {
        // TBD : PMM broadcast will be supported in Volta which can be used to optimize PMM config.
        {
            //setupPMRegistersModeCommon
            offset[count] = domainRegOffset[instance] + NV_PMM_CLAMP_CYA_CONTROL;
            value[count++] = NV_PMM_CLAMP_CYA_CONTROL_ENABLECYA_DISABLE;
            offset[count++]  = domainRegOffset[instance] + NV_PERF_WBSKEW0;
            offset[count++]  = domainRegOffset[instance] + NV_PERF_WBSKEW1;
            offset[count++]  = domainRegOffset[instance] + NV_PERF_WBSKEW2;
            offset[count++]  = domainRegOffset[instance] + NV_PERF_WBSKEW_CHAIN0;
            offset[count++]  = domainRegOffset[instance] + NV_PERF_WBSKEW_CHAIN1;

            offset[count] = domainRegOffset[instance] + NV_PMM_CONTROL2;
            value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROLB_MODEE_USERDATA_ENABLED, NV_PERF_PMMSYS_CONTROLB_MODEE_USERDATA);
            value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROLB_FLUSH_RECORD_DOIT, NV_PERF_PMMSYS_CONTROLB_FLUSH_RECORD);
            count++;
        }

        offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG0_SEL;
        value[count++] = 0;
        offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG0_OP;
        value[count++] = 0;
        offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG1_SEL;
        value[count++] = 0;
        offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG1_OP;
        value[count++] = 0;
        offset[count]  = domainRegOffset[instance] + NV_PMM_EVENT_SEL;
        value[count++] = 0;
        offset[count]  = domainRegOffset[instance] + NV_PMM_EVENT_OP;
        value[count++] = 0;
        offset[count]  = domainRegOffset[instance] + NV_PMM_SAMPLE_SEL;
        value[count++] = 0;
        offset[count]  = domainRegOffset[instance] + NV_PMM_SAMPLE_OP;
        value[count++] = 0;

#if NVCFG(GLOBAL_CHIP_T194) || NVCFG(GLOBAL_GPU_IMPL_GV11B)
        if (ctx->device->state.chip == (NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV110 +
                                NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GV11B)) {
            offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG0_SEL;
            value[count++] = 0x19181716;
            offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG0_OP;
            value[count++] = 0xffff;
            offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG1_SEL;
            value[count++] = 0x1d1c1b1a;
            offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG1_OP;
            value[count++] = 0xffff;
            offset[count]  = domainRegOffset[instance] + NV_PMM_EVENT_SEL;
            value[count++] = 0xef1eef1f;
            offset[count]  = domainRegOffset[instance] + NV_PMM_EVENT_OP;
            value[count++] = TRUTH_TABLE_FUNCTION_BIT_0_TRUE|TRUTH_TABLE_FUNCTION_BIT_2_TRUE;// 0xffff;
            
            //AssertEngineModeB
            offset[count]  = domainRegOffset[instance] + NV_PMM_ENGINE_SEL;
            value[count++] = GV11B_NV_PERF_SIGVAL_PMA_TRIGGER;            
        }
        else
#endif
        {
            offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG0_SEL;
            value[count++] = 0x03020100;
            offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG0_OP;
            value[count++] = 0xffff;
            offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG1_SEL;
            value[count++] = 0x07060504;
            offset[count]  = domainRegOffset[instance] + NV_PMM_TRIG1_OP;
            value[count++] = 0xffff;
            offset[count]  = domainRegOffset[instance] + NV_PMM_EVENT_SEL;
            value[count++] = 0xef08ef09;
            offset[count]  = domainRegOffset[instance] + NV_PMM_EVENT_OP;
            value[count++] = TRUTH_TABLE_FUNCTION_BIT_0_TRUE|TRUTH_TABLE_FUNCTION_BIT_2_TRUE;// 0xffff;

            //AssertEngineModeB
            offset[count]  = domainRegOffset[instance] + NV_PMM_ENGINE_SEL;
            value[count++] = GV100_NV_PERF_PMMGPC_GPCTPCA0_SIGVAL_PMA_TRIGGER;
        }
    }

    CU_ASSERT(count <= numReg);
    // write signal configuration
    if (CUDA_SUCCESS != PRIWRITE32(ctx, ctx->pmNew->regOpType, count, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }
    // Set the SM_PM_SAMP_CTRL register using global access (Bug : 200241963),
    // and SM_PM_CTRL register using per-context access
    {
        count = 0;
        offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_CTRL;
        value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_SEL_PROFILER, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_SEL);
        value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_ENABLE_ENABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_ENABLE);
        value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_QCTL_ENABLE_ENABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_QCTL_ENABLE);
        value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_MIO_ENABLE_ENABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_MIO_ENABLE);
        count++;

        if (CUDA_SUCCESS != PRIWRITE32(ctx, ctx->pmNew->regOpType, count, offset, value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }

        count = 0;
        offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL;
        value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL_ENABLE_ENABLE, NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL_ENABLE);
        value[count]  = DRF_REPLACE(value[count], ctx->pmNew->samplingPeriod, NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL_TIMER);
        count++;

        // write signal configuration
        if (CUDA_SUCCESS != PRIWRITE32(ctx, CU_PRI_REG_CONTEXT, count, offset, value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }
    }
#ifndef NV_MODS
    ctx->device->state.profilerState.samplingDataHashMap
                      = (void*) toolsHashMapNew(toolsUint32HashFun, toolsUint64EqualFun, 64);
#endif

    status = startStreaming(ctx);
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("Failed to start streaming\n"));
    }

    if(!ctx->device->state.profilerState.samplingThreadReadData) {
        int cuosStatus = CUOS_SUCCESS;
        ctx->device->state.profilerState.totalDroppedRecords = 0;
        ctx->device->state.profilerState.terminateSamplingThread = 0;
        ctx->device->state.profilerState.terminateSamplingParseDataThread = 0;
        // create the readSemaphore to signal the worker thread at the end to flush data
        cuosStatus = cuosSemaphoreCreate(&ctx->device->state.profilerState.readSemaphore, 0);
        if (cuosStatus) {
             CU_ASSERT(0);
             goto EXIT;
        }

        cuiMutexInitialize(&ctx->device->state.profilerState.buffListMutex, CUI_MUTEX_ORDER_TERMINAL, CUI_MUTEX_DEFAULT);
#ifndef NV_MODS
        ctx->device->state.profilerState.buffList = (void *) toolsListNew();
#endif
        if (!ctx->device->state.profilerState.buffList) {
            status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
            goto EXIT;
        }

        cuosStatus = cuosThreadCreate(&ctx->device->state.profilerState.samplingThreadReadData, voltaPerfmonPCSamplingReadData, (void *) ctx);
        if (CUOS_SUCCESS != cuosStatus) {
            CU_ASSERT(0);
            status = CUPROF_ERROR_UNKNOWN;
            goto EXIT;
        }
        cuosStatus = cuosThreadCreate(&ctx->device->state.profilerState.samplingThreadParseData, voltaPerfmonPCSamplingParseData, (void *) ctx);
        if (CUOS_SUCCESS != cuosStatus) {
            CU_ASSERT(0);
            status = CUPROF_ERROR_UNKNOWN;
            goto EXIT;
        }
    }

EXIT:
#ifndef BUG_1259185_FIXED
    if (ctx->device->dmalType != CU_DMAL_AMODEL) {
        if (status != CUPROF_SUCCESS) {
            if(ctx->device->state.profilerState.samplingThreadReadData) {
                int retCode = 0;
                ctx->device->state.profilerState.terminateSamplingThread = 1;
                cuosThreadJoin(ctx->device->state.profilerState.samplingThreadReadData, &retCode);
                if (retCode != 0) {
                    CU_ERROR_PRINT(("Failed to join sampling thread\n"));
                }
                ctx->device->state.profilerState.samplingThreadReadData = NULL;
            }
            if(ctx->device->state.profilerState.samplingThreadParseData) {
                int retCode = 0;
                cuosThreadJoin(ctx->device->state.profilerState.samplingThreadParseData, &retCode);
                if (retCode != 0) {
                    CU_ERROR_PRINT(("Failed to join sampling thread\n"));
                }
                ctx->device->state.profilerState.samplingThreadParseData = NULL;
            }
            cuosSemaphoreDestroy(&ctx->device->state.profilerState.readSemaphore);
            if (ctx->device->state.profilerState.buffList) {
                cuiMutexLock(&ctx->device->state.profilerState.buffListMutex);
#ifndef NV_MODS
                toolsListDelete((tList *) ctx->device->state.profilerState.buffList, deleteBuffNode, NULL);
#endif
                ctx->device->state.profilerState.buffList = NULL;
                cuiMutexUnlock(&ctx->device->state.profilerState.buffListMutex);
            }

            cuiMutexDeinitialize(&ctx->device->state.profilerState.buffListMutex);

            cleanupStreamingResources(ctx);
        }
    }
#endif
    free (offset);
    free (value);
    free(pmmAddress);
    return status;
}

CUprofResult voltaPerfmonPCSamplingDisable(CUctx *ctx) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 *buffer = NULL, pmmBroadcastInstances = 0;
    size_t bufferSize = 0;
    NvU32 gpcId = 0, tpcId = 0, SMIdx = 0;
    NvU32 *offset = NULL, *value = NULL, allocSize = 0;
    NvU32 count = 0, numReg = 0, clkIdx;
    NvU32 *domainRegOffset = NULL, instance = 0, maxInstances = 0;
    NvU32 *pmmAddress = NULL;
    NvU32 gpcCount = ctx->device->state.limits.numGpcs;
    NvU32 *tpcPerGpcCount = ctx->device->state.limits.numTpcsPerGpc;
    enum broadcast_enum broadcastType = BROADCAST_NONE;

    CU_TRACE_FUNCTION();

        clkIdx = 2;

    status = stopStreaming(ctx);
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("Failed to stop streaming\n"));
    }

    pmmBroadcastInstances = 2;
    maxInstances = ctx->device->state.limits.physicalTpcCount * ctx->device->state.limits.numSmsPerTpc;
    maxInstances = ((maxInstances > pmmBroadcastInstances) ? (maxInstances) : pmmBroadcastInstances);

    pmmAddress = (NvU32*)malloc(maxInstances * sizeof(NvU32));
    domainRegOffset = (NvU32*)malloc(maxInstances * sizeof(NvU32));
    if (!domainRegOffset || !pmmAddress) {
        status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }
    broadcastType = BROADCAST_PERFMON_TYPE;
#ifdef DEBUG
    {
    char szEnvironment[CUDA_PRI_REG_ENV_LEN];
    if (!(cuosGetEnv("ENABLE_PMM_UNICAST", szEnvironment, CUOS_ENV_VAR_LENGTH))) {
        //Default is broadcast but override with unicast if environment variable
        //is set, will be used only for debugging
        broadcastType = BROADCAST_NONE;
    }
    }
#endif
    if (broadcastType == BROADCAST_PERFMON_TYPE) {
        domainRegOffset[0] = NV_PERF_PMMGPC_GPCGS_GPCTPCA;
        domainRegOffset[1] = NV_PERF_PMMGPC_GPCGS_GPCTPCB;
        maxInstances = 2;
    }
    else {
        getSMPMMAddress(ctx, pmmAddress, &maxInstances);
        for (instance = 0; instance < maxInstances; instance++) {
            // TBD : PMM broadcast will be supported in Volta which can be used to optimize PMM config.
            domainRegOffset[instance] = pmmAddress[instance] + clkIdx * NV_PMM_DOMAIN_OFFSET;
        }
    }

    //8 - reset sel+op for all 4 counters
    //8 - set sel+op for all 4 counters
    //4 - control, control2, sampling, , sm_pm_ctrl
    numReg = (8 + 8 + 4) * maxInstances; //TBD: Replace the magic no
    allocSize = sizeof(NvU32) * numReg;
    offset = (NvU32*)malloc(allocSize);
    value  = (NvU32*)calloc(allocSize, 1);
    if (!offset || !value) {
        CU_ERROR_PRINT(("Failed to allocate memory for offset and value\n"));
        status = CUPROF_ERROR_OUT_OF_MEMORY;
        goto EXIT;
    }

    //Disable sampling:
    for (instance = 0; instance < maxInstances; instance++) {
        offset[count] = domainRegOffset[instance] + NV_PMM_CONTROL;
        value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_MODE_DISABLE, NV_PERF_PMMSYS_CONTROL_MODE);
        value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROL_CTXSW_MODE_DISABLED, NV_PERF_PMMSYS_CONTROL_CTXSW_MODE);
        count++;

        offset[count] = domainRegOffset[instance] + NV_PMM_CONTROL2;
        value[count] = DRF_REPLACE(value[count], NV_PERF_PMMSYS_CONTROLB_MODEE_USERDATA_DISABLED, NV_PERF_PMMSYS_CONTROLB_MODEE_USERDATA);
        count++;
    }
    CU_ASSERT(count <= numReg);

    if (CUDA_SUCCESS != PRIWRITE32(ctx, ctx->pmNew->regOpType, count, offset, value, 0)) {
        status = CUPROF_ERROR_HARDWARE;
        goto EXIT;
    }

    // Disable sampling for SM unit :
    // Set the SM_PM_SAMP_CTRL register using global access (Bug : 200241963),
    // and SM_PM_CTRL register using per-context access
    {
        count = 0;
        offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_CTRL;
        value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_ENABLE_DISABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_ENABLE);
        value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_QCTL_ENABLE_DISABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_QCTL_ENABLE);
        value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_MIO_ENABLE_DISABLE, NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_MIO_ENABLE);
        count++;

        if (CUDA_SUCCESS != PRIWRITE32(ctx, ctx->pmNew->regOpType, count, offset, value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }

        count = 0;
        offset[count] = NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL;
        value[count]  = DRF_REPLACE(value[count], NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL_ENABLE_DISABLE, NV_PGRAPH_PRI_GPCS_TPCS_SM_PM_SAMP_CTRL_ENABLE);
        count++;

        if (CUDA_SUCCESS != PRIWRITE32(ctx, CU_PRI_REG_CONTEXT, count, offset, value, 0)) {
            status = CUPROF_ERROR_HARDWARE;
            goto EXIT;
        }
    }

    if (ctx->device->state.profilerState.samplingThreadReadData) {
        int retCode = 0;
        cuosSemaphoreSignal(&ctx->device->state.profilerState.readSemaphore);
        cuosSleep(SAMPLING_TIMEOUT*2);
        ctx->device->state.profilerState.terminateSamplingThread = 1;

        cuosThreadJoin(ctx->device->state.profilerState.samplingThreadReadData, &retCode);
        if (retCode != 0) {
            CU_ERROR_PRINT(("Failed to join sampling thread\n"));
            status = (CUprofResult)retCode;
        }
        ctx->device->state.profilerState.samplingThreadReadData = NULL;
        if (ctx->device->state.profilerState.samplingThreadParseData) {
            cuosThreadJoin(ctx->device->state.profilerState.samplingThreadParseData, &retCode);
            if (retCode != 0) {
                CU_ERROR_PRINT(("Failed to join sampling thread\n"));
                status = (CUprofResult)retCode;
            }
            ctx->device->state.profilerState.samplingThreadParseData = NULL;
        }

        cuosSemaphoreDestroy(&ctx->device->state.profilerState.readSemaphore);
        if (ctx->device->state.profilerState.buffList) {
            cuiMutexLock(&ctx->device->state.profilerState.buffListMutex);
#ifndef NV_MODS
            toolsListDelete((tList *) ctx->device->state.profilerState.buffList, deleteBuffNode, NULL);
#endif
            ctx->device->state.profilerState.buffList = NULL;
            cuiMutexUnlock(&ctx->device->state.profilerState.buffListMutex);
        }

        cuiMutexDeinitialize(&ctx->device->state.profilerState.buffListMutex);

    }

    // Dump data into compact buffer which can be passed to CUPTI:
    PCSamplingHashMapToBuffer(ctx, &buffer, &bufferSize, ctx->device->state.profilerState.totalDroppedRecords);

    // Call the callBack function registered:
    ctx->pmNew->pcSamplingReadDataCallback(buffer, bufferSize, ctx->pmNew->userData);

    // Free the memory allocated for hashMap and buffer used for reading the sampling records from hardware:
    if (buffer) {
        free(buffer);
    }
#ifndef NV_MODS
    toolsHashMapDelete((tHashMap*)ctx->device->state.profilerState.samplingDataHashMap, NULL, NULL);
#endif
EXIT:
#ifndef BUG_1259185_FIXED
    if (ctx->device->dmalType != CU_DMAL_AMODEL) {
        cleanupStreamingResources(ctx);
    }
#endif
    free (offset);
    free (value);
    free(pmmAddress);
    return status;
}

//Following function reads data from HW buffer and copied data
//to SW buffer to parse in an offline thread
static int voltaPerfmonPCSamplingReadData(void *userData) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 offset[2], values[2];           //2 (mem_bytes+mem+head)
    NvU32 j = 0;
    NvU32 bytesToParse = 0, memBytes = 0;
    NvU8 *recPtr;
    //Set dummy varaibles for emulation
    CUctx *ctx;
    CUprofDeviceState *profDevState;
    int cuosResult = 0;
#if defined(NVGPU_IOCTL_CHANNEL_CYCLE_STATS_SNAPSHOT)
    gk20a_cs_snapshot_fifo *snapshot;
#endif

#if GENERATE_BINARY_STREAMS
    FILE *file = NULL;

    file = fopen("voltaSamplingData", "wb");
#endif

    CU_TRACE_FUNCTION();

    if (!userData)
        return CUPROF_ERROR_NOT_SUPPORTED;

    ctx = (CUctx *) userData;
    profDevState = &ctx->device->state.profilerState;

    if((ctx->device->dmalType != CU_DMAL_MRM)
#if cuiPlatformIncludesMrm()
#if defined(NVGPU_IOCTL_CHANNEL_CYCLE_STATS_SNAPSHOT)
    || !ctx->device->dm.mrm->nvRmGpuDeviceInfo->hasCycleStatsSnapshot
#endif
    || ctx->pmNew->isCSSDisabled
#endif
    ) {
        recPtr = (NvU8 *)ctx->pmNew->cpuAddrStreamingBuffer;
        if (!recPtr) {
            status = CUPROF_ERROR_UNKNOWN;
            goto EXIT;
        }
    }
    else {
#if defined(NVGPU_IOCTL_CHANNEL_CYCLE_STATS_SNAPSHOT)
        snapshot = (gk20a_cs_snapshot_fifo *)ctx->pmNew->cpuAddrStreamingBuffer;
#endif
    }

    while(1) {
        cuosResult = cuosSemaphoreWait(&ctx->device->state.profilerState.readSemaphore, SAMPLING_TIMEOUT);
        if (cuosResult == CUOS_ERROR) {
            CU_ASSERT(0);
        }

        if((ctx->device->dmalType != CU_DMAL_MRM)
#if cuiPlatformIncludesMrm()
#if defined(NVGPU_IOCTL_CHANNEL_CYCLE_STATS_SNAPSHOT)
        || !ctx->device->dm.mrm->nvRmGpuDeviceInfo->hasCycleStatsSnapshot
#endif
        || ctx->pmNew->isCSSDisabled
#endif
        ) {
            j = 0;
            //Loop for reading data from sampling output
            offset[j]  = NV_PERF_PMASYS_MEM_BYTES;
            values[j] = 0;
            j++;

            if (CUDA_SUCCESS != PRIREAD32(ctx, ctx->pmNew->regOpType, j, offset, values, 0)) {
                status = CUPROF_ERROR_HARDWARE;
                goto EXIT;
            }

            memBytes = values[0];
            if ((ctx->device->state.profilerState.terminateSamplingThread) && (!memBytes)) {
                break;
            }

            j = 0;
            offset[j]  = NV_PERF_PMASYS_CONTROL;
            values[j] = 0;
            j++;

            if (CUDA_SUCCESS != PRIREAD32(ctx, ctx->pmNew->regOpType, j, offset, values, 0)) {
                status = CUPROF_ERROR_HARDWARE;
                goto EXIT;
            }

            if(GETVAL(values[0], NV_PERF_PMASYS_CONTROL_MEMBUF_STATUS) == NV_PERF_PMASYS_CONTROL_MEMBUF_STATUS_OVERFLOWED) {
                CU_ERROR_PRINT(("Streaming buffer overflowed.\n"));
                status = CUPROF_ERROR_HARDWARE;
                ctx->device->state.profilerState.terminateSamplingThread = 1;
            }

            bytesToParse = memBytes & ~0x1f;
#ifdef ENABLE_SAMPLING_PRINTS
            printf("totalBytes = %d, membytes = %d\n", bytesToParse, memBytes);
#endif

            if(bytesToParse) {
                if (recPtr == ((uint8_t*)ctx->pmNew->cpuAddrStreamingBuffer + ctx->pmNew->sizeStreamingBuffer)) {
                    recPtr = (NvU8 *)ctx->pmNew->cpuAddrStreamingBuffer;
#ifdef ENABLE_SAMPLING_PRINTS
                    printf("Buffer wrap around next pass\n");
#endif
                }
                //If there is a wraparound, then process the bytes at the end of the buffer first and then process remaining bytes in next pass
                if(((uint64_t)(uintptr_t)recPtr + bytesToParse) >= (uint64_t)(uintptr_t)((uint8_t*)ctx->pmNew->cpuAddrStreamingBuffer + ctx->pmNew->sizeStreamingBuffer)) {
#ifdef ENABLE_SAMPLING_PRINTS
                    printf("Buffer wrap around first pass, bytesToParse before %d\n", bytesToParse);
#endif

                    bytesToParse = (uint32_t)((uint64_t)(uintptr_t)((uint8_t*)ctx->pmNew->cpuAddrStreamingBuffer + ctx->pmNew->sizeStreamingBuffer) - (uint64_t)(uintptr_t)recPtr);
#ifdef ENABLE_SAMPLING_PRINTS
                    printf("Buffer wrap around first pass, bytesToParse after %d\n", bytesToParse);
#endif
                }

                //Skip invalid records by reading backwards.
                {
                    CUprofSamplingRecord *tempPtr = (CUprofSamplingRecord *)(recPtr + bytesToParse - 32);
                    NvU32 bytesToSkip = 0;

                    while (((tempPtr->smplCnt_tm_ds_sz_0_0 & 0xc000) == 0xc000) && (bytesToSkip < bytesToParse)) {
                        bytesToSkip += 32;
                        tempPtr--;
                    }
#ifdef ENABLE_SAMPLING_PRINTS
                    printf("Bytes skipped = %d\n", bytesToSkip);
#endif
                    bytesToParse -= bytesToSkip;
                }

                if(bytesToParse) {
                    //Allocate buffer struct
                    CUprofBuff *tempBuff = NULL;
                    tempBuff = (CUprofBuff*) malloc(sizeof(CUprofBuff));
                    if (!tempBuff) {
                        status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
                        goto EXIT;
                    }
                    //Allocate buffer
                    tempBuff->buff = (NvU32 *) malloc(bytesToParse);
                    if (!tempBuff->buff) {
                        free(tempBuff);
                        status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
                        goto EXIT;
                    }
                    //Copy bytes
                    memcpy(tempBuff->buff, recPtr, bytesToParse);
                    tempBuff->buffSize = bytesToParse;

#if GENERATE_BINARY_STREAMS
                    fwrite(recPtr, bytesToParse, 1, file);
#endif

                    //Add to list
                    cuiMutexLock(&profDevState->buffListMutex);
#ifndef NV_MODS
                    toolsListAppendFront((tList *) profDevState->buffList, (void *)tempBuff);
#endif
                    cuiMutexUnlock(&profDevState->buffListMutex); 
                    recPtr += bytesToParse;

                    //Tell hardware about the data read
                    //Write value read from mem_bytes to mem_bump
                    offset[0] = NV_PERF_PMASYS_MEM_BUMP;
                    values[0] = bytesToParse;

                    memset(recPtr - bytesToParse, 0xFF, bytesToParse);
                    if (CUDA_SUCCESS != PRIWRITE32(ctx, ctx->pmNew->regOpType, 1, offset, values, 0)) {
                        status = CUPROF_ERROR_HARDWARE;
                        goto EXIT;
                    }
                    bytesToParse = 0;
                }
            }
        }
#if cuiPlatformIncludesMrm()
#if defined(NVGPU_IOCTL_CHANNEL_CYCLE_STATS_SNAPSHOT)
        else if(ctx->device->dm.mrm->nvRmGpuDeviceInfo->hasCycleStatsSnapshot) {
            NvError err;
            CUprofSamplingRecord *start, *end, *put, *get;

            // Reset bytesToParse at each iteration
            bytesToParse = 0;

            err = NvRmGpuChannelCycleStatsFlushSnapshot(
                                    ctx->pmNew->channel->dm.mrm->nvRmGpuChannel,
                                    ctx->pmNew->memHandler);
            if(err != NvSuccess) {
                CU_ERROR_PRINT(("NvRmGpuChannelCycleStatsFlushSnapshot "
                                "failed.\n"));
                status = CUPROF_ERROR_UNKNOWN;
                ctx->device->state.profilerState.terminateSamplingThread = 1;
                goto EXIT;
            }

            if(snapshot->hw_overflow_events_occured ||
               snapshot->sw_overflow_events_occured) {
                CU_ERROR_PRINT(("Streaming buffer overflowed.\n"));
                status = CUPROF_ERROR_HARDWARE;
                ctx->device->state.profilerState.terminateSamplingThread = 1;
                goto EXIT;
            }

            start = (CUprofSamplingRecord*)((char*)snapshot + snapshot->start);
            end = (CUprofSamplingRecord*)((char*)snapshot + snapshot->end);
            put = (CUprofSamplingRecord*)((char*)snapshot + snapshot->put);
            get = (CUprofSamplingRecord*)((char*)snapshot + snapshot->get);

            while(get != put) {
                // If there is a wraparound, then process the bytes at the end
                // of the buffer first and then process remaining bytes in next
                // pass
                get++;
                if(get >= end) {
                    get = start;
                    break;
                }
                bytesToParse += sizeof(CUprofSamplingRecord);
            }

            if(bytesToParse) {
                //Allocate buffer struct
                CUprofBuff *tempBuff = NULL;
                tempBuff = (CUprofBuff*)malloc(sizeof(CUprofBuff));
                if(!tempBuff) {
                    status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
                    goto EXIT;
                }

                //Allocate buffer
                tempBuff->buff = (NvU32 *)malloc(bytesToParse);
                if(!tempBuff->buff) {
                    free(tempBuff);
                    status = (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
                    goto EXIT;
                }

                //Copy bytes
                memcpy(tempBuff->buff,
                       (void *)((char*)snapshot + snapshot->get),
                       bytesToParse);

                tempBuff->buffSize = bytesToParse;

                //Add to list
                cuiMutexLock(&profDevState->buffListMutex);
#ifndef NV_MODS
                toolsListAppendFront((tList *)profDevState->buffList,
                                     (void *)tempBuff);
#endif
                cuiMutexUnlock(&profDevState->buffListMutex);
                snapshot->get = (NvU32)((char*)get - (char*)snapshot);
            }

            if(ctx->device->state.profilerState.terminateSamplingThread &&
               !bytesToParse) {
                break;
            }
        }
#endif //defined(NVGPU_IOCTL_CHANNEL_CYCLE_STATS_SNAPSHOT)
#endif
    }
EXIT:
#ifdef ENABLE_SAMPLING_PRINTS
    printf("Exited read thread, tt = %d\n", (int)ctx->device->state.profilerState.terminateSamplingThread);
#endif
    ctx->device->state.profilerState.terminateSamplingParseDataThread = 1;

#if GENERATE_BINARY_STREAMS
    fclose(file);
#endif

    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("voltaPerfmonPCSamplingReadData failed with error %d.\n", status));
    }
    return (int)status;
}

static inline size_t incrementRecordOffset(size_t recordOffset)
{
    uint8_t incAmount[32] = {
        1, 1, 1, 5, 0, 0, 0, 0,
        1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1
    };
    return recordOffset + incAmount[recordOffset];
}

static inline uint16_t getValidBytes(const uint8_t *pModeERecord)
{
    return pModeERecord[4] & 0x1F;
}

static inline uint16_t getPerfmonId(const uint8_t *pModeERecord)
{
    uint16_t smplCnt_tm_ds_sz_0_0 = ((pModeERecord[7] << 8) | pModeERecord[6]);
    return (pModeERecord[5]) | (((smplCnt_tm_ds_sz_0_0) & 0xe00) >> 1);
}

static inline uint8_t isStartData(const uint8_t *pModeERecord)
{
    return ((pModeERecord[7] & 0x10) != 0);
}

static inline uint16_t getDroppedBytes(const uint8_t *pModeERecord)
{
    uint16_t smplCnt_tm_ds_sz_0_0 = ((pModeERecord[7] << 8) | pModeERecord[6]);
    return ((smplCnt_tm_ds_sz_0_0 & 0x1ff) << 3) | ((pModeERecord[4] & 0xe0) >> 5);
}

static inline uint64_t getPC(const uint8_t *pPacketRaw) {
    uint64_t pcLow = 0, pcHi = 0, pc = 0;

    pcLow   = ((uint64_t)pPacketRaw[0] << 3) | ((uint64_t)pPacketRaw[1] << 11) | ((uint64_t)pPacketRaw[2] << 19) | ((uint64_t)pPacketRaw[3] << 27);
    pcHi    = ((uint64_t)pPacketRaw[4]) | ((uint64_t)(pPacketRaw[5] & 0x1f) << 8);
    pc      = (pcLow | (pcHi << 35)) << 1;

    return pc;
}

static inline uint32_t getCIR(const uint8_t *pPacketRaw) {
    return (pPacketRaw[5] >> 5) | ((pPacketRaw[6] & 0x3) << 3);
}

// tools_shared code is not accessible on mods
#if defined(NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV100) && !defined(NV_MODS)
CUprofResult voltaOnPacket(const uint8_t *pPacketRaw, CUctx *ctx) {

    typedef uint32_t (*CUprofPCSamplingGetStallReason)(uint32_t cantIssueReason);
    CUprofPCSamplingGetStallReason pFn = NULL;
    tHashMap *samplingDataHashMap;
    CUprofSamplingData *ptrToData = NULL;
    NvU8 instIssued0QuadMask,warpId;
    uint32_t cant_issue_reason = 0, VEID = 0;
    uint64_t pc = 0;

    if ((ctx->profiler) && (ctx->profiler->dumpAllReasons)) {
        pFn = (CUprofPCSamplingGetStallReason)&getPCSamplingStallReasonDriver;
    }
    else {
        pFn = (CUprofPCSamplingGetStallReason)&getPCSamplingStallReasonCupti;
    }

    /*******************************************************************************
                                     HASHMAP FORMAT:
              |KEY |                VALUE                           |
              PC1 #| CIR1 SAMPLES#|CIR2  SAMPLES#| ...|CIRn SAMPLES#
              PC2 #| CIR1 SAMPLES#|CIR2  SAMPLES#| ...|CIRn SAMPLES#
              ...
              PCn #| CIR1 SAMPLES#|CIR2  SAMPLES#| ...|CIRn SAMPLES#
    ********************************************************************************/

    /*
    Packet format for VOLTA is taken from :
    https://wiki.nvidia.com/gpuhwvolta/index.php/SMV_Perf/PC_Sampler#PC_Sampler_packet_transfer_protocol
    */

    pc = getPC(pPacketRaw);

    cant_issue_reason = getCIR(pPacketRaw);

    warpId = (pPacketRaw[6] >> 2);
    VEID = (pPacketRaw[7] & 0x3f);
    instIssued0QuadMask = ((pPacketRaw[7] >> 6) & 0x1);

    // Assert used to check if the CIR's are invalid
    CU_ASSERT ((cant_issue_reason > 0) && (cant_issue_reason < CUPROF_VOLTA_WARP_CANT_ISSUE_MAX_CIR ));

    // Instruction issued zero assert
    CU_ASSERT ((instIssued0QuadMask) ? ((cant_issue_reason == CUPROF_VOLTA_WARP_CANT_ISSUE_NOT_SELECTED) || (cant_issue_reason == CUPROF_VOLTA_WARP_CANT_ISSUE_SELECTED) ? 0 : 1) : 1);

    // Convert to either raw or group cir
    cant_issue_reason = pFn(cant_issue_reason);

#ifdef ENABLE_SAMPLING_PRINTS
    printf("pc = %llx, cir = %d, warpId = %d, veid = %d, inst = %d\n", (unsigned long long)pc, cant_issue_reason, warpId, VEID, instIssued0QuadMask);
#endif

    samplingDataHashMap = (tHashMap *) ctx->device->state.profilerState.samplingDataHashMap;

    ptrToData = (CUprofSamplingData *)toolsHashMapFind(samplingDataHashMap,
                                                               tHashMapNumToKey(pc));
    if(!ptrToData) {
        //Allocate the data to hold CIR:
        ptrToData = (CUprofSamplingData*)calloc(CUPROF_WARP_CANT_ISSUE_MAX_CIR,
                                   sizeof(CUprofSamplingData));
        if(!ptrToData) {
            CU_ERROR_PRINT(("Error allocating memory.\n"));
            return CUPROF_ERROR_OUT_OF_MEMORY;
        }
        toolsHashMapInsert(samplingDataHashMap, tHashMapNumToKey(pc), (void*)ptrToData);
    }
    ptrToData[cant_issue_reason].totalSamples++;
    if(instIssued0QuadMask) {
        ptrToData[cant_issue_reason].latencySamples++;
    }

    return CUPROF_SUCCESS;
}
#else
CUprofResult voltaOnPacket(const uint8_t *pPacketRaw, CUctx *ctx) {
    return CUPROF_SUCCESS;
}
#endif



CUprofResult voltaOnRecord(uint8_t *pModeERecord, chiplet *chipInstanceData, CUctx *ctx, uint32_t *totalDroppedBytes) {
    
    CUprofResult status = CUPROF_SUCCESS;
    uint16_t validBytes = getValidBytes(pModeERecord);
    size_t recordOffset = 0;
    uint8_t packetSize = 8;                 // PacketSize for Volta is 8 bytes
    uint32_t itr = 0;
    uint8_t bytesDiscarded;
    uint8_t startData = 0;
    uint64_t recordHeader = 4;

#ifdef ENABLE_SAMPLING_PRINTS
    //Enable, only if there is an error in parsing.
    // printf("+++++++++++++++++++++++Start record\n");
    // printf("data0[0] = %x\n",  pModeERecord[0]);
    // printf("data0[1] = %x\n",  pModeERecord[1]);
    // printf("data0[2] = %x\n",  pModeERecord[2]);
    // printf("data0[3] = %x\n",  pModeERecord[3]);
    // printf("perfmonid = %x\n",  pModeERecord[5]);
    // printf("ByteCount = %x\n",  (pModeERecord[4] & 0x1f));
    // printf("smplCnt_tm_ds_sz_0_0 = %x\n",  ((pModeERecord[7] << 8) | pModeERecord[6]) );
    // for (int i = 0; i < 24; i++)
    //     printf("data1[%d] = %x\n", i, pModeERecord[i + 8]);
    // printf("----------------------End record\n");
#endif

#ifdef ENABLE_SAMPLING_PRINTS
    // printf("Dropped: %d\n",chipInstanceData->droppedBytes);
    // printf("numValidBytes:%d\n\n", validBytes);
#endif

    if (chipInstanceData->droppedBytes)
    {

        startData = isStartData(pModeERecord);
        CU_ASSERT(startData);

        *totalDroppedBytes += (NvU32) chipInstanceData->packetOffset + chipInstanceData->droppedBytes;

        bytesDiscarded = (chipInstanceData->droppedBytes + chipInstanceData->packetOffset) % packetSize;
        chipInstanceData->packetOffset = packetSize - (bytesDiscarded ? bytesDiscarded : packetSize);

        while (chipInstanceData->packetOffset)
        {
            chipInstanceData->packetOffset--;
            recordOffset = incrementRecordOffset(recordOffset);
            itr++;
        }
    }

    // In volta the offset will always start from zero (Resync Mechanism)
    CU_ASSERT(itr==0);
    
    for ( ; itr < validBytes; itr++)
    {

        chipInstanceData->packet[chipInstanceData->packetOffset++] = pModeERecord[recordOffset];

        if (chipInstanceData->packetOffset == packetSize) {
            status = voltaOnPacket(chipInstanceData->packet, ctx);
            if (status != CUPROF_SUCCESS) {
                return status;
            }
            chipInstanceData->packetOffset = 0;
        }

        recordOffset = incrementRecordOffset(recordOffset);
    }

#ifdef ENABLE_SAMPLING_PRINTS
    // printf("bytesInPacket: %ld\n",chipInstanceData->packetOffset);
    // printf("sizeofDanglingPacket in current record: %ld\n\n",chipInstanceData->packetOffset);
#endif

    // Get the dropped bytes in the next record
    chipInstanceData->droppedBytes = getDroppedBytes(pModeERecord);

    if (chipInstanceData->droppedBytes == MAX_DROPPED_COUNT)
    {
        CU_ERROR_PRINT(("\nERROR in parsing, too many dropped records to continue parsing!!!\n"));
        return CUPROF_ERROR_UNKNOWN;
    }

    return status;
}

//Following function parses data from SW buffer queue
static int voltaPerfmonPCSamplingParseData(void *userData) {
    CUprofResult status = CUPROF_SUCCESS;
    NvU32 bytesToParse = 0;
    //Set dummy varaibles for emulation
    NvU32 totalSMCount = 0;
    CUctx *ctx;
    uint32_t totalDroppedBytes = 0;
    CUprofDeviceState *profDevState;
    size_t offset = 0, itr = 0;
    uint8_t *pModeERecords;
    uint16_t perfmonId, chipIdx;

    CU_TRACE_FUNCTION();

    if (!userData)
        return CUPROF_ERROR_NOT_SUPPORTED;

    ctx = (CUctx *) userData;
    profDevState = &ctx->device->state.profilerState;

    totalSMCount = ctx->device->state.limits.physicalSmCount;
    chiplet chips[MAXSMCOUNT];

    // Initialize the structure with zero
    for (itr = 0; itr < totalSMCount; ++itr) {
        chips[itr].droppedBytes = 0;
        chips[itr].packetOffset = 0;
    }
    ctx->device->state.profilerState.totalDroppedRecords = 0;


    while(1) {
        if ((!profDevState->buffList) && (!ctx->device->state.profilerState.terminateSamplingParseDataThread)) {
            cuosThreadYield();
        }
#ifndef NV_MODS
        else if ((toolsListSize((tList *) profDevState->buffList) == 0) && (!ctx->device->state.profilerState.terminateSamplingParseDataThread)) {
            cuosThreadYield();
        }
#endif
        else {
            CUprofBuff *tempBuff = NULL;
#ifndef NV_MODS
            tListItr *last = NULL;

            if ((toolsListSize((tList *) profDevState->buffList) == 0) && (ctx->device->state.profilerState.terminateSamplingParseDataThread)) {
                break;
            }
            cuiMutexLock(&profDevState->buffListMutex);
            last = toolsListGetTail((tList *) profDevState->buffList);
            tempBuff = (CUprofBuff *) toolsListGetElem(last);
            toolsListRemove((tList *) profDevState->buffList, tempBuff, NULL, 0);
            cuiMutexUnlock(&profDevState->buffListMutex);
#endif
            pModeERecords = (uint8_t *)tempBuff->buff;
            //The size of buffer is expected to be multiple of 32 bytes as
            //we read data multiple of 32 bytes
            bytesToParse = tempBuff->buffSize;

#ifdef ENABLE_SAMPLING_PRINTS
            printf("bytesToParse = %d\n", bytesToParse);
#endif

            if(bytesToParse) {
#if 0
                //Enable, only if there is an error in parsing.
                fwrite((void*)recPtr, dataSizeof(char), bytesToParse, logfp);
                fflush(logfp);
                fclose(logfp);
#else
                for (offset = 0; offset < bytesToParse; offset += VOLTA_RECORD_SIZE) {
                    uint8_t *pModeERecord = &pModeERecords[offset];
                    CUprofSamplingRecord *recPtr = (CUprofSamplingRecord *)&pModeERecords[offset];
                    perfmonId = getPerfmonId(pModeERecord);

#ifdef ENABLE_SAMPLING_PRINTS
                    printf("**SM = %d\n", perfmonId);
#endif
                    if(ctx->device->dmalType != CU_DMAL_MRM
#if cuiPlatformIncludesMrm()
#if defined(NVGPU_IOCTL_CHANNEL_CYCLE_STATS_SNAPSHOT)
                       || !ctx->device->dm.mrm->nvRmGpuDeviceInfo->hasCycleStatsSnapshot
#endif
                       || ctx->pmNew->isCSSDisabled
#endif
                      ) {
                        chipIdx = perfmonId;
                    }
#if cuiPlatformIncludesMrm()
                    else {
#if defined(NVGPU_IOCTL_CHANNEL_CYCLE_STATS_SNAPSHOT)
                        chipIdx = perfmonId - ctx->pmNew->perfmonIdStart;
#endif
                    }
#endif
                    chiplet *chip = &chips[chipIdx];

                    status = voltaOnRecord(pModeERecord, chip, ctx, &totalDroppedBytes);
                }
                ctx->device->state.profilerState.totalDroppedRecords += (totalDroppedBytes / PACKET_SIZE);
#endif
            }
            free(tempBuff->buff);
            free(tempBuff);
        }
    }
#ifdef ENABLE_SAMPLING_PRINTS
    printf("Exited parsing thread, tt = %d\n", (int)ctx->device->state.profilerState.terminateSamplingParseDataThread);
#endif
    if (status != CUPROF_SUCCESS) {
        CU_ERROR_PRINT(("voltaPerfmonPCSamplingReadData failed with error %d.\n", status));
    }
    return (int)status;
}

CUprofResult voltaPerfmonPCSamplingSetConfig(CUctx *ctx, CUprofSamplingConfig config, NvBool flag) {
    //TBD Hardcoding now, since the period is in cycles, it will vary from gpu to gpu.
    //We can decide after the experiments what is the better value to derive any good
    //conclusion about the kernel code.
    //The actual sampling period will be = 2^(ctx->pmNew->samplingPeriod + 5)
    NvU32 periodCycles = 0,periodLevel = 0, periodLevel2 = 0;
    int clockrate = 0;
    NvU32 units = ctx->device->state.limits.physicalSmCount;

    // Compute the number of units as minimum of blocks and SM count
    if (config.numBlocks) {
        // Do not overwrite the period if user has already specified using 'period2'
        if (ctx->pmNew->isUserPeriod2) {
            return CUPROF_SUCCESS;
        }
        units = (NvU32) MIN(config.numBlocks, (NvU64)ctx->device->state.limits.physicalSmCount);
    }

    if (flag == 1) {      // Flag will be set if period2 is to be used
        /* 
        * This will set the period with user given value
        * Period = (2 ^ config.period)
        * E.G if config.period2 = 10, the sampling period will be (2^10) cycles.
        */
        // Clamp the value in between 5 and 31
        config.period2 = MIN(config.period2, 31);
        config.period2 = MAX(config.period2, 5);

        //The actual sampling period will be = 2^(ctx->pmNew->samplingPeriod + 5)
        ctx->pmNew->samplingPeriod = config.period2 - 5;
        ctx->pmNew->isUserPeriod2 = 1;
    }

    else {
        /*
        * PRI streaming rate is 1 streaming rec(of 32 bytes that has 28 bytes payload) in 48 cycles (actually 24 cycles, but we consider it slower so multiple by 2)
        * We want (clockrate/48) records in 1 sec.
        * At a sampling period SP, it will generate (Clockrate * 5 * #SM)/(SP * 28)  records
        * (clockrate/48) = (Clockrate * 5 * #SM)/(SP * 28)
        * Resolving above equation it gives:
        * SP = (#SM * 5 * 48)/28
        */

        if (config.period) {
            ctx->pmNew->userPeriod = config.period;
            ctx->pmNew->isUserPeriod2 = 0;
        }

        periodCycles = (PACKET_SIZE * units * CLOCKS_PER_STREAMING_RECORD_FROM_ROUTER_TO_PMA_ON_PRI * 2) / SIZE_OF_STREAMING_RECORD_PAYLOAD;
        ROUND_UP_POW2(periodCycles);
        PROF_COMPUTE_LOG2(periodLevel, periodCycles);
        periodLevel = MAX(5, periodLevel);

        /* For Mobile take into consideration CSS Buffer size while calculating PC Sampling frequency
        * Number of records with Sampling period SP = (Clockrate * PACKET_SIZE * #SM)/(SP * 28) per second
        * bufferSize should be >= (#records * 32 bytes(1 record size)) * (34/1000)
        * because it can take upto 34ms in worst case to flush the buffer
        * SP >= (Clockrate * PACKET_SIZE * #SM * 32 * 34)/(28 * 1000 * bufferSize)
        */
#if cuiPlatformIncludesMrm()
#if defined(NVGPU_IOCTL_CHANNEL_CYCLE_STATS_SNAPSHOT)
       if (ctx->device->dm.mrm->nvRmGpuDeviceInfo->hasCycleStatsSnapshot && !ctx->pmNew->isCSSDisabled) {
           cuiDeviceGetAttribute(ctx->device, CU_DEVICE_ATTRIBUTE_CLOCK_RATE, &clockrate);
           periodCycles = ((clockrate * PACKET_SIZE * units * SIZE_OF_STREAMING_RECORD * MAX_PC_SAMPLING_FLUSH_TIME_MS) /
                           (SIZE_OF_STREAMING_RECORD_PAYLOAD * 1000 * ctx->device->dm.mrm->nvRmGpuDeviceInfo->maxCycleStatsSnapshotBufferSize));
           ROUND_UP_POW2(periodCycles);
           PROF_COMPUTE_LOG2(periodLevel2, periodCycles);
           periodLevel = MAX(periodLevel2, periodLevel);
       }
#endif
#endif
        periodLevel -= 5;

        switch(ctx->pmNew->userPeriod) {
        case CUPROF_SAMPLING_PERIOD_MIN:
            ctx->pmNew->samplingPeriod = MIN_SAMPLING_PERIOD;
            break;
        case CUPROF_SAMPLING_PERIOD_LOW:
            ctx->pmNew->samplingPeriod = MIN(MAX_SAMPLING_PERIOD, (MIN_SAMPLING_PERIOD + periodLevel)/2);
            break;
        case CUPROF_SAMPLING_PERIOD_MID:
            ctx->pmNew->samplingPeriod = MIN(MAX_SAMPLING_PERIOD, periodLevel);
            break;
        case CUPROF_SAMPLING_PERIOD_HIGH:
            ctx->pmNew->samplingPeriod = MIN(MAX_SAMPLING_PERIOD, (periodLevel + MAX_SAMPLING_PERIOD)/2);
            break;
        case CUPROF_SAMPLING_PERIOD_MAX:
            ctx->pmNew->samplingPeriod = MAX_SAMPLING_PERIOD;
            break;
        default:
            ctx->pmNew->samplingPeriod = 0;
        }
    }
    return CUPROF_SUCCESS;
}

//TBD change this api to accept device when device level streaming is implemented.
CUprofResult voltaPerfmonEventSamplingSetConfig(CUctx *ctx, CUprofSamplingConfig *config) {
    //TBD Hardcoding now, since the period is in cycles, it will vary from gpu to gpu.
    //We can decide after the experiments what is the better value to derive any good
    //conclusion about app.
    switch(config->period) {
    case CUPROF_SAMPLING_PERIOD_MIN:
        ctx->pmNew->samplingPeriod = NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES_1K;
        break;
    case CUPROF_SAMPLING_PERIOD_LOW:
        ctx->pmNew->samplingPeriod = NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES_4K;
        break;
    case CUPROF_SAMPLING_PERIOD_MID:
        ctx->pmNew->samplingPeriod = NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES_16K;
        break;
    case CUPROF_SAMPLING_PERIOD_HIGH:
        ctx->pmNew->samplingPeriod = NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES_32K;
        break;
    case CUPROF_SAMPLING_PERIOD_MAX:
        ctx->pmNew->samplingPeriod = NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES_64K;
        break;
    default:
        ctx->pmNew->samplingPeriod = NV_PERF_PMMSYS_CONTROL_TIMEBASE_CYCLES_1K;
    }
    return CUPROF_SUCCESS;
}

