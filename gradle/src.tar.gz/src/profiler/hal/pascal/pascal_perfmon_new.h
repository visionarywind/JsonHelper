/*
* Copyright 1993-2009 by NVIDIA Corporation.  All rights reserved.  All
* information contained herein is proprietary and confidential to NVIDIA
* Corporation.  Any use, reproduction, or disclosure without the written
* permission of NVIDIA Corporation is prohibited.
*/

/******************************************************************************
*
*   Module: pascal_perfmon_new.h
*
*   Description:
*       pascal specific perfmon definitions
*
******************************************************************************/
#ifndef __PASCAL_PERFMON_NEW_H__
#define __PASCAL_PERFMON_NEW_H__

#include "cuda_device.h"
#include "pascal/gp100/dev_graphics_nobundle.h"
#include "pascal/gp100/dev_top.h"
#include "class/clb0c0.h"
#include "ctrl/ctrl2080/ctrl2080nvlink.h"
#include "pascal/gp100/dev_ltc.h"
#include "pascal/gp100/dev_nvltl.h"

#define INVALID_ADDRESS 0xFFFFFFFF
#define COUNTER_OVERFLOW_VALUE  0xFF
#define ENABLE_BITS_MASK    0xF0000000
#define NUM_FUNC_REGISTERS  4

// 2 Tx and 2 Rx counters are allowed per NvLink:
#define MAX_COUNTERS_PER_NVLINK   2
#define NVLINK_MAX_LINKS          4

/*
* Copyright 2009 by NVIDIA Corporation.  All rights reserved.  All
* information contained herein is proprietary and confidential to NVIDIA
* Corporation.  Any use, reproduction, or disclosure without the written
* permission of NVIDIA Corporation is prohibited.
*/

/******************************************************************************
*
*   Module: pascal_perfmon.h
*
*   Description:
*       pascal specific perfmon definitions
*
******************************************************************************/

//TBD we may have to give different names below
#define PM_MAX_GPC                              8
#define PM_MAX_TPC                              8
#define PM_MAX_FBP                              8
#define PM_MAX_CHIPLETS_PER_CHIPLET_TYPE        8
#define PM_MAX_DOMAIN_PER_CHIPLET               8

#define CU_PROF_SM_CORE_PROFILED_MAX            4
#define CU_PROF_SM_QUAD_PROFILED_MAX            4

//****************************************************************************************
// Taken from pri_tex.ref
// Bug:878182 - GK107 BU: texture signals (cache_sector_queries/misses) seems to be broken
// With the clock gating change in gk10x onwards, all PM signals that originate in T-stage
//       need TEX_T_PM_PM_ENABLE. So any signals with gpc_t_* in the name will need it.
//       Then t-stage signals go through M-stage perfmux also, so they need
//       TEX_M_PM_PM_ENABLE also, which is already being enabled.
//****************************************************************************************
#define NV_PTPC_PRI_TEX_T_PM                    0x000002B8
#define NV_PTPC_PRI_TEX_T_PM_PM_ENABLE          31:31
#define NV_PTPC_PRI_TEX_T_PM_PM_ENABLE_ON       0x00000001

//****************************************************************************************
// Taken from pri_fe.ref
// Seems that FE_PERFMON_ENABLE is required for the
//****************************************************************************************
#define NV_PRI_FE_PERFMON                 0x0040415C
#define NV_PRI_FE_PERFMON_ENABLE          31:31
#define NV_PRI_FE_PERFMON_ENABLE_ENABLE   0x00000001

//****************************************************************************************
//  ref "pascal PGRAPH Memory Map.xls"
//****************************************************************************************
//TBD check addresses below
#define NV_GPC_PRI_BASE                     0x00500000
#define NV_GPC_PRI_STRIDE                   0x00008000

#define NV_TPC_IN_GPC_BASE                  0x00004000
#define NV_TPC_IN_GPC_STRIDE                0x00000800

#define NV_PRI_TPC_ADDR(gpc, tpc)           (NV_GPC_PRI_BASE+((gpc)*NV_GPC_PRI_STRIDE)+NV_TPC_IN_GPC_BASE+((tpc)*NV_TPC_IN_GPC_STRIDE))

#define NV_PLTCG_BASE                       0x00140000 // dev_ltc.h - NV_PLTCG
#define NV_PLTCG_STRIDE                     0x00002000
#define NV_PLTCG_ADDR(fbp)                  (NV_PLTCG_BASE+fbp*NV_PLTCG_STRIDE)
#define NV_PLTS_BASE                        0x00000400 // dev_ltc.h - NV_PLTCG
#define NV_PLTS_STRIDE                      0x00000200

//Use broadcast register to sent PM_enable for the FBPA counters. This is a workaround as the
//unicast access to FBPA was not working fine for GTX470.
#define NV_FBPA_PRI_BASE_BROADCAST          0x009A0000 // pri_fbpa.ref - NV_PFB_FBPA

#define NV_FBPA_PRI_BASE                    0x00900000 // pri_fbpa.ref - NV_PFB_FBPA_0
#define NV_FBPA_PRI_STRIDE                  0x00004000
#define NV_FBPA_PRI_ADDR(fbp)               (NV_FBP_PA_PRI_BASE+fbp*NV_FBP_PA_PRI_STRIDE)

#define MAX_ROP_L2_UNITS_PER_FBP_GP100_GP10Y 2
// no of available TPCs/ZCULLs in a GPC
// NUM_AVAILABLE_TPCS - 4:0, NUM_AVAILABLE_ZCULLS - 20:16
#define NV_GPCCS_FS_GPC(gpcId)              (NV_PGRAPH_PRI_GPC0_GPCCS_FS_GPC + NV_GPC_PRI_STRIDE * gpcId)

// SM perfmon related defines, refer pascal/gk104/dev_graphics_nobundle.h for details

// PM control register
// please refer \\sw\<branch>\drivers\resman\kernel\inc\pascal\<chip>\dev_graphics_nobundle.h or \\hw\<chip>\manuals\pri_<unit>.ref
// SM Unit
#define NV_SM_PM_CTRL(gpcId, tpcId)                         (NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_PM_CTRL_SEL0                                  NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER_CONTROL_SEL0
#define NV_SM_PM_CTRL_CORE_ENABLE                           NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_ENABLE
#define NV_SM_PM_CTRL_QCTL_ENABLE                           NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_QCTL_ENABLE
#define NV_SM_PM_CTRL_MIO_ENABLE                            NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_MIO_ENABLE
#define NV_SM_PM_CTRL_CORE_ENABLE_ENABLE                    NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_CORE_ENABLE_ENABLE
#define NV_SM_PM_CTRL_QCTL_ENABLE_ENABLE                    NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_QCTL_ENABLE_ENABLE
#define NV_SM_PM_CTRL_MIO_ENABLE_ENABLE                     NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_MIO_ENABLE_ENABLE
#define NV_SM_PM_CTRL_ENABLE_DISABLE                        NV_PGRAPH_PRI_GPC0_TPC0_SM_PM_CTRL_ENABLE_DISABLE

#define NV_SM_PM_CTRL_ENABLE_BITS_MASK                       (  (DRF_MASK(NV_SM_PM_CTRL_CORE_ENABLE)   << DRF_SHIFT(NV_SM_PM_CTRL_CORE_ENABLE))      \
                                                             | (DRF_MASK(NV_SM_PM_CTRL_QCTL_ENABLE)   << DRF_SHIFT(NV_SM_PM_CTRL_QCTL_ENABLE))      \
                                                             | (DRF_MASK(NV_SM_PM_CTRL_MIO_ENABLE)   << DRF_SHIFT(NV_SM_PM_CTRL_MIO_ENABLE)))

#define NV_SM_DSM_PERF_COUNTER_CONTROL_ENABLE                31:28
#define NV_SM_DSM_PERF_COUNTER_CONTROL_ENABLE_ENABLE         0xF
#define NV_SM_DSM_PERF_COUNTER_CONTROL_ENABLE_DISABLE        0x0

// ------------------------------------------------------------------
// Perf counters
// ------------------------------------------------------------------

// Edge,mode selection registers
// EDGE0 - 0:0, MODE0 - 2:1, WINDOWED0 - 3:3, ... EDGE7 - 12:12, MODE7 - 14:13, WINDOWED0 - 15:15
#define NV_SM_DSM_PERF_COUNTER_CONTROL0(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER_CONTROL0 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
//TBD, map to control5 define in dev_graphics_nobundle.h whenever it is available.
#define NV_SM_DSM_PERF_COUNTER_CONTROL5(gpcId, tpcId) (0x00504658 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)

// Function combination selection register
// FUNC0 - 15:0, FUNC1 - 31:16
#define NV_SM_DSM_PERF_COUNTER_CONTROL1(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER_CONTROL1 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER_CONTROL2(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER_CONTROL2 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER_CONTROL3(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER_CONTROL3 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER_CONTROL4(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER_CONTROL4 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)

// Performance Counter Group mux select - group selection registers
// GRP0 - 7:0, GRP1 - 15:8, GRP2 - 23:16, GRP3 - 31:24
#define NV_SM_DSM_PERF_COUNTER_CONTROL_SEL0(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER_CONTROL_SEL0 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER_CONTROL_SEL1(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER_CONTROL_SEL1 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)

#define NV_SM_DEBUG_SFE_CONTROL(gpcId, tpcId)             (NV_PGRAPH_PRI_GPC0_TPC0_SM_DEBUG_SFE_CONTROL + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DEBUG_SFE_CONTROL_READ_HALF_CTL_0           NV_PGRAPH_PRI_GPC0_TPC0_SM_DEBUG_SFE_CONTROL_READ_HALF_CTL_0
#define NV_SM_DEBUG_SFE_CONTROL_READ_HALF_CTL_1           NV_PGRAPH_PRI_GPC0_TPC0_SM_DEBUG_SFE_CONTROL_READ_HALF_CTL_1


#define NV_SM_HALFCTL_CTRL(gpcId, tpcId)                  (NV_PGRAPH_PRI_GPC0_TPC0_SM_HALFCTL_CTRL + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
//NV_PTPC_PRI_SM_HALFCTL_CTRL_SCTL_READ_QUAD_CTL                              4:4 /* RWEVF */
//#define NV_SM_HALFCTL_CTRL_SCTL_READ_QUAD_CTL_0            NV_PGRAPH_PRI_GPC0_TPC0_SM_HALFCTL_CTRL_SCTL_READ_QUAD_CTL_0
//#define NV_SM_HALFCTL_CTRL_SCTL_READ_QUAD_CTL_1            NV_PGRAPH_PRI_GPC0_TPC0_SM_HALFCTL_CTRL_SCTL_READ_QUAD_CTL_1

// ----------------------------------------------------------------------
// Continuation of the performance counter control registers.  These
// registers configures the mux structure of each bit of each counter.
// ----------------------------------------------------------------------
// Each perf counter has 4 bits feeding into a function table.  Each bit
// can be selected from 1 of 8 bits of 1 of the 8 groups (selected via
// the PERF_COUNTER_CONTROL_SEL* register above).
// BIT#_GRP selects 1 of 8 groups
// BIT#_SIG selects 1 of the 8 signals from that selected group
// BIT0_GRP - 3:0, BIT0_SIG - 7:4, ... BIT3_GRP - 27:24, BIT3_SIG - 31:28
#define NV_SM_DSM_PERF_COUNTER0_CONTROL(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER0_CONTROL + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER1_CONTROL(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER1_CONTROL + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER2_CONTROL(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER2_CONTROL + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER3_CONTROL(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER3_CONTROL + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER4_CONTROL(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER4_CONTROL + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER5_CONTROL(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER5_CONTROL + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER6_CONTROL(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER6_CONTROL + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER7_CONTROL(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER7_CONTROL + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)

// Perf counter values themselves
#define NV_SM_DSM_PERF_COUNTER0_S0(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER0_S0 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER1_S0(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER1_S0 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER2_S0(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER2_S0 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER3_S0(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER3_S0 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER0_S1(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER0_S1 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER1_S1(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER1_S1 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER2_S1(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER2_S1 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER3_S1(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER3_S1 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER0_S2(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER0_S2 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER1_S2(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER1_S2 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER2_S2(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER2_S2 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER3_S2(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER3_S2 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER0_S3(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER0_S3 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER1_S3(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER1_S3 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER2_S3(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER2_S3 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER3_S3(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER3_S3 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER4(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER4 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER5(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER5 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER6(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER6 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER7(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER7 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)

// Perf counter status report - counter overflow
#define NV_SM_DSM_PERF_COUNTER_STATUS_S0(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER_STATUS_S0 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER_STATUS_S1(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER_STATUS_S1 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER_STATUS_S2(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER_STATUS_S2 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER_STATUS_S3(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER_STATUS_S3 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER_STATUS1(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER_STATUS1 + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)

// Required for filter signal in SMPC:
#define NV_SM_DSM_PERF_COUNTER_FILTER0_CONTROL(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER_FILTER0_CONTROL + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)
#define NV_SM_DSM_PERF_COUNTER_FILTER4_CONTROL(gpcId, tpcId) (NV_PGRAPH_PRI_GPC0_TPC0_SM_DSM_PERF_COUNTER_FILTER4_CONTROL + NV_GPC_PRI_STRIDE * gpcId + NV_TPC_IN_GPC_STRIDE * tpcId)

#define NV_PTPC_PRI_SM_PM_SAMP_CTRL                                                  0x00000490 /* RW-4R */
#define NV_PTPC_PRI_SM_PM_SAMP_CTRL_ENABLE                                                  0:0 /* RWIVF */
#define NV_PTPC_PRI_SM_PM_SAMP_CTRL_ENABLE_DISABLE                                   0x00000000 /* RWI-V */
#define NV_PTPC_PRI_SM_PM_SAMP_CTRL_ENABLE_ENABLE                                    0x00000001 /* RW--V */
#define NV_PTPC_PRI_SM_PM_SAMP_CTRL_TIMER                                                   5:1 /* RWIVF */
#define NV_PTPC_PRI_SM_PM_SAMP_CTRL_TIMER_INIT                                       0x0000000a /* RWI-V */
#define NV_PERF_PMMSYS_DSELS                                                              20:16 /* RW-4A */

// SM Perf counter MODE enum -
#define NV_SM_DSM_PERF_COUNTER_CONTROL_MODE_LUT          0x00000000
#define NV_SM_DSM_PERF_COUNTER_CONTROL_MODE_COUNT        0x00000001

#define CU_PROF_SW_COUNTERS_MAX         10
#define CU_PROF_PM_GENERAL_START_INDEX  CU_PROF_PM_SM_MAX_COUNTERS
// max counters per event group
#define CU_PROF_PM_EVENT_GROUP_MAX_COUNTERS     8

#define GP100_NV_PERF_PMMFBP_ROP1_SIGVAL_PMA_TRIGGER                                           77
#define GP100_NV_PERF_PMMFBP_ROP0_SIGVAL_PMA_TRIGGER                                           77
#define GP100_NV_PERF_PMMFBP_LTC1_SIGVAL_PMA_TRIGGER                                           109
#define GP100_NV_PERF_PMMFBP_LTC0_SIGVAL_PMA_TRIGGER                                           109
#define GP100_NV_PERF_PMMFBP_FBP0_SIGVAL_PMA_TRIGGER                                           109
#define GP100_NV_PERF_PMMGPC_GPCTPC4_SIGVAL_PMA_TRIGGER                                        205
#define GP100_NV_PERF_PMMGPC_GPCTPC3_SIGVAL_PMA_TRIGGER                                        205
#define GP100_NV_PERF_PMMGPC_GPCTPC2_SIGVAL_PMA_TRIGGER                                        205
#define GP100_NV_PERF_PMMGPC_GPCTPC1_SIGVAL_PMA_TRIGGER                                        205
#define GP100_NV_PERF_PMMGPC_GPCTPC0_SIGVAL_PMA_TRIGGER                                        205
#define GP100_NV_PERF_PMMGPC_GPC1_SIGVAL_PMA_TRIGGER                                           109
#define GP100_NV_PERF_PMMGPC_GPC0_SIGVAL_PMA_TRIGGER                                           205
#define GP100_NV_PERF_PMMSYS_XBAR0_SIGVAL_PMA_TRIGGER                                          45
#define GP100_NV_PERF_PMMSYS_SYS1_SIGVAL_PMA_TRIGGER                                           141
#define GP100_NV_PERF_PMMSYS_SYS0_SIGVAL_PMA_TRIGGER                                           205
#define GP100_NV_PERF_PMMSYS_PWR0_SIGVAL_PMA_TRIGGER                                           77
#define GP100_NV_PERF_PMMSYS_PCIE0_SIGVAL_PMA_TRIGGER                                          77
#define GP100_NV_PERF_PMMSYS_MSD0_SIGVAL_PMA_TRIGGER                                           173
#define GP100_NV_PERF_PMMSYS_HOST0_SIGVAL_PMA_TRIGGER                                          77

#define GP100_NV_PERF_PMMFBP_ROP1_SIGVAL_T_PULSE                                               78
#define GP100_NV_PERF_PMMFBP_ROP0_SIGVAL_T_PULSE                                               78
#define GP100_NV_PERF_PMMFBP_LTC1_SIGVAL_T_PULSE                                               110
#define GP100_NV_PERF_PMMFBP_LTC0_SIGVAL_T_PULSE                                               110
#define GP100_NV_PERF_PMMFBP_FBP0_SIGVAL_T_PULSE                                               110
#define GP100_NV_PERF_PMMGPC_GPCTPC4_SIGVAL_T_PULSE                                            206
#define GP100_NV_PERF_PMMGPC_GPCTPC3_SIGVAL_T_PULSE                                            206
#define GP100_NV_PERF_PMMGPC_GPCTPC2_SIGVAL_T_PULSE                                            206
#define GP100_NV_PERF_PMMGPC_GPCTPC1_SIGVAL_T_PULSE                                            206
#define GP100_NV_PERF_PMMGPC_GPCTPC0_SIGVAL_T_PULSE                                            206
#define GP100_NV_PERF_PMMGPC_GPC1_SIGVAL_T_PULSE                                               110
#define GP100_NV_PERF_PMMGPC_GPC0_SIGVAL_T_PULSE                                               206
#define GP100_NV_PERF_PMMSYS_XBAR0_SIGVAL_T_PULSE                                              46
#define GP100_NV_PERF_PMMSYS_SYS1_SIGVAL_T_PULSE                                               142
#define GP100_NV_PERF_PMMSYS_SYS0_SIGVAL_T_PULSE                                               206
#define GP100_NV_PERF_PMMSYS_PWR0_SIGVAL_T_PULSE                                               78
#define GP100_NV_PERF_PMMSYS_PCIE0_SIGVAL_T_PULSE                                              78
#define GP100_NV_PERF_PMMSYS_MSD0_SIGVAL_T_PULSE                                               174
#define GP100_NV_PERF_PMMSYS_HOST0_SIGVAL_T_PULSE                                              78

#define GP10B_NV_PERF_PMMFBP_FBP0_SIGVAL_PMA_TRIGGER                                           205
#define GP10B_NV_PERF_PMMGPC_GPCTPC1_SIGVAL_PMA_TRIGGER                                        205
#define GP10B_NV_PERF_PMMGPC_GPCTPC0_SIGVAL_PMA_TRIGGER                                        205
#define GP10B_NV_PERF_PMMGPC_GPC0_SIGVAL_PMA_TRIGGER                                           205
#define GP10B_NV_PERF_PMMSYS_SYS0_SIGVAL_PMA_TRIGGER                                           205
#define GP10B_NV_PERF_PMMSYS_PWR0_SIGVAL_PMA_TRIGGER                                           77
#define GP10B_NV_PERF_PMMSYS_MC0_SIGVAL_PMA_TRIGGER                                            45
#define GP10B_NV_PERF_PMMSYS_ACB0_SIGVAL_PMA_TRIGGER                                           45

#define GP10B_NV_PERF_PMMFBP_FBP0_SIGVAL_T_PULSE                                               206
#define GP10B_NV_PERF_PMMGPC_GPCTPC1_SIGVAL_T_PULSE                                            206
#define GP10B_NV_PERF_PMMGPC_GPCTPC0_SIGVAL_T_PULSE                                            206
#define GP10B_NV_PERF_PMMGPC_GPC0_SIGVAL_T_PULSE                                               206
#define GP10B_NV_PERF_PMMSYS_SYS0_SIGVAL_T_PULSE                                               206
#define GP10B_NV_PERF_PMMSYS_PWR0_SIGVAL_T_PULSE                                               78
#define GP10B_NV_PERF_PMMSYS_MC0_SIGVAL_T_PULSE                                                46
#define GP10B_NV_PERF_PMMSYS_ACB0_SIGVAL_T_PULSE                                               46

//same for gp107 and g108
#define GP107_NV_PERF_PMMFBP_ROP1_SIGVAL_PMA_TRIGGER                                           77
#define GP107_NV_PERF_PMMFBP_ROP0_SIGVAL_PMA_TRIGGER                                           77
#define GP107_NV_PERF_PMMFBP_LTC1_SIGVAL_PMA_TRIGGER                                           109
#define GP107_NV_PERF_PMMFBP_LTC0_SIGVAL_PMA_TRIGGER                                           109
#define GP107_NV_PERF_PMMFBP_FBP0_SIGVAL_PMA_TRIGGER                                           109
#define GP107_NV_PERF_PMMGPC_GPCTPC2_SIGVAL_PMA_TRIGGER                                        205
#define GP107_NV_PERF_PMMGPC_GPCTPC1_SIGVAL_PMA_TRIGGER                                        205
#define GP107_NV_PERF_PMMGPC_GPCTPC0_SIGVAL_PMA_TRIGGER                                        205
#define GP107_NV_PERF_PMMGPC_GPC1_SIGVAL_PMA_TRIGGER                                           141
#define GP107_NV_PERF_PMMGPC_GPC0_SIGVAL_PMA_TRIGGER                                           109
#define GP107_NV_PERF_PMMSYS_XBAR0_SIGVAL_PMA_TRIGGER                                          45
#define GP107_NV_PERF_PMMSYS_SYS1_SIGVAL_PMA_TRIGGER                                           77
#define GP107_NV_PERF_PMMSYS_SYS0_SIGVAL_PMA_TRIGGER                                           173
#define GP107_NV_PERF_PMMSYS_PWR0_SIGVAL_PMA_TRIGGER                                           77
#define GP107_NV_PERF_PMMSYS_PCIE0_SIGVAL_PMA_TRIGGER                                          77
#define GP107_NV_PERF_PMMSYS_MSD0_SIGVAL_PMA_TRIGGER                                           109
#define GP107_NV_PERF_PMMSYS_HOST0_SIGVAL_PMA_TRIGGER                                          77

#define GP107_NV_PERF_PMMFBP_ROP1_SIGVAL_T_PULSE                                               78
#define GP107_NV_PERF_PMMFBP_ROP0_SIGVAL_T_PULSE                                               78
#define GP107_NV_PERF_PMMFBP_LTC1_SIGVAL_T_PULSE                                               110
#define GP107_NV_PERF_PMMFBP_LTC0_SIGVAL_T_PULSE                                               110
#define GP107_NV_PERF_PMMFBP_FBP0_SIGVAL_T_PULSE                                               110
#define GP107_NV_PERF_PMMGPC_GPCTPC2_SIGVAL_T_PULSE                                            206
#define GP107_NV_PERF_PMMGPC_GPCTPC1_SIGVAL_T_PULSE                                            206
#define GP107_NV_PERF_PMMGPC_GPCTPC0_SIGVAL_T_PULSE                                            206
#define GP107_NV_PERF_PMMGPC_GPC1_SIGVAL_T_PULSE                                               142
#define GP107_NV_PERF_PMMGPC_GPC0_SIGVAL_T_PULSE                                               110
#define GP107_NV_PERF_PMMSYS_XBAR0_SIGVAL_T_PULSE                                              46
#define GP107_NV_PERF_PMMSYS_SYS1_SIGVAL_T_PULSE                                               78
#define GP107_NV_PERF_PMMSYS_SYS0_SIGVAL_T_PULSE                                               174
#define GP107_NV_PERF_PMMSYS_PWR0_SIGVAL_T_PULSE                                               78
#define GP107_NV_PERF_PMMSYS_PCIE0_SIGVAL_T_PULSE                                              78
#define GP107_NV_PERF_PMMSYS_MSD0_SIGVAL_T_PULSE                                               110
#define GP107_NV_PERF_PMMSYS_HOST0_SIGVAL_T_PULSE                                              78

//same for gp102, gp104 and gp106
#define GP102_NV_PERF_PMMFBP_ROP1_SIGVAL_PMA_TRIGGER                                           77
#define GP102_NV_PERF_PMMFBP_ROP0_SIGVAL_PMA_TRIGGER                                           77
#define GP102_NV_PERF_PMMFBP_LTC1_SIGVAL_PMA_TRIGGER                                           109
#define GP102_NV_PERF_PMMFBP_LTC0_SIGVAL_PMA_TRIGGER                                           109
#define GP102_NV_PERF_PMMFBP_FBP0_SIGVAL_PMA_TRIGGER                                           109
#define GP102_NV_PERF_PMMGPC_GPCTPC4_SIGVAL_PMA_TRIGGER                                        205
#define GP102_NV_PERF_PMMGPC_GPCTPC3_SIGVAL_PMA_TRIGGER                                        205
#define GP102_NV_PERF_PMMGPC_GPCTPC2_SIGVAL_PMA_TRIGGER                                        205
#define GP102_NV_PERF_PMMGPC_GPCTPC1_SIGVAL_PMA_TRIGGER                                        205
#define GP102_NV_PERF_PMMGPC_GPCTPC0_SIGVAL_PMA_TRIGGER                                        205
#define GP102_NV_PERF_PMMGPC_GPC1_SIGVAL_PMA_TRIGGER                                           173
#define GP102_NV_PERF_PMMGPC_GPC0_SIGVAL_PMA_TRIGGER                                           141
#define GP102_NV_PERF_PMMSYS_XBAR0_SIGVAL_PMA_TRIGGER                                          45
#define GP102_NV_PERF_PMMSYS_SYS1_SIGVAL_PMA_TRIGGER                                           77
#define GP102_NV_PERF_PMMSYS_SYS0_SIGVAL_PMA_TRIGGER                                           173
#define GP102_NV_PERF_PMMSYS_PWR0_SIGVAL_PMA_TRIGGER                                           77
#define GP102_NV_PERF_PMMSYS_PCIE0_SIGVAL_PMA_TRIGGER                                          77
#define GP102_NV_PERF_PMMSYS_MSD0_SIGVAL_PMA_TRIGGER                                           141
#define GP102_NV_PERF_PMMSYS_HOST0_SIGVAL_PMA_TRIGGER                                          77

#define GP102_NV_PERF_PMMFBP_ROP1_SIGVAL_T_PULSE                                               78
#define GP102_NV_PERF_PMMFBP_ROP0_SIGVAL_T_PULSE                                               78
#define GP102_NV_PERF_PMMFBP_LTC1_SIGVAL_T_PULSE                                               110
#define GP102_NV_PERF_PMMFBP_LTC0_SIGVAL_T_PULSE                                               110
#define GP102_NV_PERF_PMMFBP_FBP0_SIGVAL_T_PULSE                                               110
#define GP102_NV_PERF_PMMGPC_GPCTPC4_SIGVAL_T_PULSE                                            206
#define GP102_NV_PERF_PMMGPC_GPCTPC3_SIGVAL_T_PULSE                                            206
#define GP102_NV_PERF_PMMGPC_GPCTPC2_SIGVAL_T_PULSE                                            206
#define GP102_NV_PERF_PMMGPC_GPCTPC1_SIGVAL_T_PULSE                                            206
#define GP102_NV_PERF_PMMGPC_GPCTPC0_SIGVAL_T_PULSE                                            206
#define GP102_NV_PERF_PMMGPC_GPC1_SIGVAL_T_PULSE                                               174
#define GP102_NV_PERF_PMMGPC_GPC0_SIGVAL_T_PULSE                                               142
#define GP102_NV_PERF_PMMSYS_XBAR0_SIGVAL_T_PULSE                                              46
#define GP102_NV_PERF_PMMSYS_SYS1_SIGVAL_T_PULSE                                               78
#define GP102_NV_PERF_PMMSYS_SYS0_SIGVAL_T_PULSE                                               174
#define GP102_NV_PERF_PMMSYS_PWR0_SIGVAL_T_PULSE                                               78
#define GP102_NV_PERF_PMMSYS_PCIE0_SIGVAL_T_PULSE                                              78
#define GP102_NV_PERF_PMMSYS_MSD0_SIGVAL_T_PULSE                                               142
#define GP102_NV_PERF_PMMSYS_HOST0_SIGVAL_T_PULSE                                              78

enum PMUnitId_enum {
        PM_UNIT_SM              = 0,
        PM_UNIT_SMQCTL          = 1,
        PM_UNIT_SMCORE          = 2,
        PM_UNIT_MPC             = 3,
        PM_UNIT_MIO             = 4,
        PM_UNIT_LTC             = 5,
        PM_UNIT_LTC1            = 6,
        PM_UNIT_LTC2            = 7,
        PM_UNIT_LTS             = 8,
        PM_UNIT_LTS1            = 9,
        PM_UNIT_LTS2            = 10,
        PM_UNIT_HUBMMU          = 11,
        PM_UNIT_TEX_S           = 12,
        PM_UNIT_TEX_D           = 13,
        PM_UNIT_TEX_M           = 14,
        PM_UNIT_TEX_T           = 15,
        PM_UNIT_TEX_T1          = 16,
        PM_UNIT_TEX_T2          = 17,
        PM_UNIT_TEX_T3          = 18,
        PM_UNIT_FB              = 19,
        PM_UNIT_LTS_1           = 20,
        PM_UNIT_LTS1_1          = 21,
        PM_UNIT_LTS2_1          = 22,
        PM_UNIT_LTS_2           = 23,
        PM_UNIT_LTS1_2          = 24,
        PM_UNIT_LTS2_2          = 25,
        PM_UNIT_LTS_3           = 26,
        PM_UNIT_LTS1_3          = 27,
        PM_UNIT_LTS2_3          = 28,
        PM_UNIT_TEX_M1          = 29,
        PM_UNIT_NVLINK0         = 30,
        PM_UNIT_NVLINK1         = 31,
        PM_UNIT_NVLINK2         = 32,
        PM_UNIT_NVLINK3         = 33,
        PM_UNIT_GPCMMU          = 34,
        PM_UNIT_XVE1            = 35,
        PM_UNIT_XVE2            = 36,
        PM_UNIT_MAX             = 37    // invalid unit
};
#define NV_PMM_TRIG0_BIT_POS        0
#define NV_PMM_TRIG1_BIT_POS        1
#define NV_PMM_EVENT_BIT_POS        2
#define NV_PMM_SAMPLE_BIT_POS       3
#define NV_PMM_ELAPSED_CLOCKS_BIT_POS   4

enum PMMRegisters_enum {
        NV_PMM_TRIG0                = (1 << NV_PMM_TRIG0_BIT_POS),
        NV_PMM_TRIG1                = (1 << NV_PMM_TRIG1_BIT_POS),
        NV_PMM_EVENT                = (1 << NV_PMM_EVENT_BIT_POS),
        NV_PMM_SAMPLE               = (1 << NV_PMM_SAMPLE_BIT_POS),
        NV_ELAPSED_CLOCKS           = (1 << NV_PMM_ELAPSED_CLOCKS_BIT_POS),
        NV_PMM_SIG_MASK             = NV_PMM_TRIG0 | NV_PMM_TRIG1 | NV_PMM_EVENT | NV_PMM_SAMPLE
};
//Most of these fields are from #include "drivers/resman/kernel/inc/pascal/gm107/dev_perf.h"
//TBD change the code to use defines from the above file
enum PM_REGISTERS
{
        // sys chiplet (one chiplet + one instance only)
        NV_PERF_PMMSYS_BASE                                             =   0x1B0000,
        // gpc chiplet (multiple chiplets with multiple instances each)
        NV_PERF_PMMGPC_BASE                                             =   0x180000,
        NV_PERF_PMMGPC_CHIPLET_OFFSET                                   =   0x1000,
        // fbp chiplet (multiple chiplets with multiple instances each)
        NV_PERF_PMMFBP_BASE                                             =   0x1A0000,
        NV_PERF_PMMFBP_CHIPLET_OFFSET                                   =   0x1000,

        // PMM (applies to all perfmon blocks), these are relative offsets per domain
        NV_PMM_TRIG0_SEL                                                =   0x40,
        NV_PMM_TRIG0_OP                                                 =   0x44,
        NV_PMM_TRIG1_SEL                                                =   0x48,
        NV_PMM_TRIG1_OP                                                 =   0x4c,
        NV_PMM_EVENT_SEL                                                =   0x50,
        NV_PMM_EVENT_OP                                                 =   0x54,
        NV_PMM_SAMPLE_SEL                                               =   0x58,
        NV_PMM_SAMPLE_OP                                                =   0x5c,
        NV_PMM_SETFLAG_OP                                               =   0x60,
        NV_PMM_CLRFLAG_OP                                               =   0x64,

        NV_PMM_ENGINE_SEL                                               =   0x6c,

        NV_PMM_ELAPSED                                                  =   0x70,
        NV_PMM_EVENTCNT                                                 =   0x80,
        NV_PMM_THRESHCNT                                                =   0x88,
        NV_PMM_TRIGGERCNT                                               =   0x8c,
        NV_PMM_SAMPLECNT                                                =   0x90,

        NV_PMM_CONTROL                                                  =   0x9c,
        NV_PMM_CONTROL_MODE__SHIFT                                      =   0,
        NV_PMM_CONTROL_MODE__MASK                                       =   7 << NV_PMM_CONTROL_MODE__SHIFT,
        NV_PMM_CONTROL_MODE_DISABLE                                     =   0,
        NV_PMM_CONTROL_MODE_A                                           =   1,
        NV_PMM_CONTROL_MODE_B                                           =   2,
        NV_PMM_CONTROL_MODE_C                                           =   3,
        NV_PMM_CONTROL_MODE_E                                           =   5,
        NV_PMM_CONTROL_ADDTOCTR__SHIFT                                  =   3,
        NV_PMM_CONTROL_ADDTOCTR__MASK                                   =   7 << NV_PMM_CONTROL_ADDTOCTR__SHIFT,
        NV_PMM_CONTROL_ADDTOCTR_INCR                                    =   0,
        NV_PMM_CONTROL_ADDTOCTR_EVENT4                                  =   1,
        NV_PMM_CONTROL_ADDTOCTR_EVENT6                                  =   2,
        NV_PMM_CONTROL_ADDTOCTR_TRIG4                                   =   3,
        NV_PMM_CONTROL_ADDTOCTR_TRIG6                                   =   4,
        NV_PMM_CONTROL_ADDTOCTR_VIVEK                                   =   5,
        NV_PMM_CONTROL_ADDTOCTR_4444                                    =   6,
        NV_PMM_CONTROL_ADDTOCTR_2X4B4I                                  =   7,

        NV_PMM_CONTROL_CTXSW_MODE__SHIFT                                =   18,
        NV_PMM_CONTROL_CTXSW_MODE__MASK                                 =   1 << NV_PMM_CONTROL_CTXSW_MODE__SHIFT,
        NV_PMM_CONTROL_CTXSW_MODE_ENABLED                               =   0,
        NV_PMM_CONTROL_CTXSW_MODE_DISABLED                              =   1,

        //TBD check how to use the following 2 fields effectively using masks. They are defined only for last 8 bits.
        NV_PERF_PMM_RELEASE                                             =   0xA0,
        NV_PERF_PMM_RELEASE_SHADOWS_DOIT                                =   1,

        NV_PERF_PMM_STARTEXPERIMENT                                     =   0xe0,
        NV_PERF_PMM_STARTEXPERIMENT_START_DOIT                          =   1,

        NV_PMM_CLAMP_CYA_CONTROL                                        =   0x100,
        NV_PMM_CLAMP_CYA_CONTROL_ENABLECYA_DISABLE                      =   0,
        NV_PMM_CLAMP_CYA_CONTROL_ENABLECYA_ENABLE                       =   1,

        NV_PERF_WBSKEW0                                                 =   0xcc,
        NV_PERF_WBSKEW1                                                 =   0xd0,
        NV_PERF_WBSKEW2                                                 =   0xd4,
        NV_PERF_WBSKEW_CHAIN0                                           =   0xd8,
        NV_PERF_WBSKEW_CHAIN1                                           =   0xdc,
        NV_PMM_DOMAIN_OFFSET                                            =   0x200,

        NV_PMM_ENGINESTATUS                                             =   0xc8,
        NV_PMM_CONTROL2                                                 =   0x108,
        NV_PMM_CONTROL3                                                 =   0x110,
        NV_PTPC_PRI_SM_PM_CTRL                                          =   0x600
};

typedef struct pascalSignalName2Numeric_st
{
    const char             *name;
    unsigned int           numericId;
} pascalSignalName2Numeric;

typedef struct signalUnitConfig_st {
    NvU32 unitId;
    NvU32 groupSelAddress; //Required group register for this signal.
    NvU32 groupSelMask;    //Required group mask for this signal.
    NvU32 groupSelValue;    //Required group value for this signal.
    //Following are required for tex and ltc units only for setting the
    NvU32 groupSelAddress1; //Required group register for this signal.
    NvU32 groupSelMask1;    //Required group mask for this signal.
    NvU32 groupSelValue1;    //Required group value for this signal.
    PerfUnitTable *pPerfUnitTable; //Store pointer to unit table, required to set pm enable bit properly
} signalUnitConfig;

typedef struct signalConfig_st {
    NvU32 tempWatchbus[4];
    //tempWatchbus[0]: Used for combination signals for 4 or 2 signal combination
                     //upper part of increment signals stored in first half of watchbus.in case of TRIG6
                     //For vivek mode, 14 bit counter 4 bits are valid
    //tempWatchbus[1]: Used for lower 4 bits of increment signals
                     //For vivek mode, 14 bit counter, 4 bits are valid
    //tempWatchbus[2]: Used for VIVEK mode, 14 bit counter, 4 bits are valid
    //tempWatchbus[3]: Used for VIVEK mode, 14 bit counter, lower 2 bits valid
    NvU32 function;  //Function for combination signals
    NvU32 mode;      //Proposed mode, can change later on
    NvU32 busWidth;  //In expt, this is a width for increment signal
    NvU32 partNumber;      //Stores spec for a part in case of vivek mode, lowest 8 bits indicate the first part
    NvU32 watchBus[4];     //watchbus for all specs, use event spec to index into
                           //this watchbus so that it can directly be assigned in
                           //parsedClk structure
    signalUnitConfig *unitInfo[4];
    NvU32 filterSignal;    // Can be one of HWPM_FILTER_SIGNAL* for SM **No other unit has supported sideband filtering yet**
    NvU8 delaySelect;      // Select which signals to delay in HWPM experiments
} signalConfig;

//Following is the complete configuration for nvlink counters.
typedef struct nvLinkSignalConfig_st {
    NvU32 function[4];  //Function for combination signals
    NvU32 mode;         //Proposed mode, can change later on
    NvU32 busWidth[4];  //In expt, this is a width for increment signal
    NvU32 instance[4];  //Stores spec for a part in case of vivek mode, lowest 8 bits indicate the first part
    NvU32 watchBus[4];  //watchbus
    NvU32 group[4];     //NV_IOCTRL_PMMUXSEL_REG_M1SEL0-3
    NvU32 m1Mode[4];    //every cycle or on data change
    NvU32 m3Mode[4];    //1:1 or 2:1
} nvLinkSignalConfig;

typedef struct CUparsedUnit_st {
    NvU32 unitId;
    NvU32 groupSelAddress;     // Should store the group register value (PM_CTRL register address for each unit)
    NvU32 groupSelValue;       // Should store the group value
    NvU32 groupSelMask;        // Should indicate which group is already set
    //In pascal below registers are not used.
    PerfUnitTable *pPerfUnitTable;
} CUparsedUnit;

//Assunming we will profile same signal for all chiplets, I have used having array of values for all chiplets, inside the domain.
//Instead we can have array of chilpet structures for max chiplets.  This way we can profile different signals for different chiplets if required. (There doesn't seem any use case for this)
typedef struct CUparsedClk_st {
    CUparsedUnit *pParsedUnit[CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS+CU_PROF_ELAPSED_CLOCK_SLOT]; // This stores the unique unit-ids and groups. Not one-to-one with the signals
    PerfSignalHwpm *sigtable[CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS+CU_PROF_ELAPSED_CLOCK_SLOT];  // Pointer to current signal from the signal table
    NvU32        eventspec[CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS+CU_PROF_ELAPSED_CLOCK_SLOT];    // Event specifier for PM signals
    NvU32        *values;                                              // Array of values for all the chiplet instances for all the counters selected in this domain
    NvU32        eventSpecUsed;                                        // Used events till now out of the 4: TRIG0, TRIG1, EVENT, SAMPLE
    NvU32        mode;                                                 // Primary mode used for this clk domain. (INCR can be subset of multiple modes but other modes cannot go together)
    NvU32        isElapsedClocksProfiled;
    NvU32        watchBus[CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS];       // watchbus for all 4 counters, indexed by eventspec and not by counter index
    NvU32        function[CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS];       // function to be setup for all 4 counters, indexed by eventspec and not by counter index
    NvU32        partNumber[CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS+CU_PROF_ELAPSED_CLOCK_SLOT];     // Used only for vivek mode to combine the counters.
                                                                       // EventSpec will be stored here, partNumbers 0 is the lowest 8 bit slot
    NvU32        width[CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS+CU_PROF_ELAPSED_CLOCK_SLOT];          // Width of the signal, used in case of vivek mode.
    NvU32        filterConfig;                                         // Combination of all filter signals for counters
    NvU32        totalHardwareCounters;                                // Count of hardware counters/experiments added. The totalCounters in eventgroup structure stands for virtual experiments requested by users
    NvU8         delaySelects[CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS];   // Delay signals for HWPM experiments
} CUparsedClk;


typedef struct CUSMCtrInfo_st {
    CUeventInfo *sigtableInfo[CU_PROF_PM_SM_MAX_COUNTERS];          // Pointer to current signal from the signal table
    //Ideally SM counters can be collected for all TPCs,
    //but if we want to profile the PM singals from gpc0 domain
    //then we need to provide only 4 TPCs else don't allow sm0
    //and gpc0 together.
    //TBD Discuss this behaviour with all
    NvU64        *values;                                              // Array of values for all the chiplet instances for all the counters selected in this domain
    NvU32        splitParts[CU_PROF_PM_SM_MAX_COUNTERS];
    NvU32        SMCountersAdded;
    NvU32        groupsCore[4];
    NvU32        numGroupsCore;
    NvU32        groupsQuad[4];
    NvU32        numGroupsQuad;
    NvU32        perfEventInfo[CU_PROF_PM_SM_MAX_COUNTERS];
    NvU32        function[CU_PROF_PM_SM_MAX_COUNTERS];
    NvU32        pmUnitId[CU_PROF_PM_SM_MAX_COUNTERS];
    NvU32        mode[CU_PROF_PM_SM_MAX_COUNTERS];
    NvU32        coreCount;
    NvU32        qctlCount;
    NvU32        signalIdFilterCore;
    NvU32        signalConfigCore;
    NvU32        signalIdFilterQuad;
    NvU32        signalConfigQuad;
    NvU32        numSignalsInExpt[CU_PROF_PM_SM_MAX_COUNTERS];
} CUSMCtrInfo;

typedef struct nvLinkTCSignalConfig_st {
    NvU32        numCountersTx;                                                 // Two Tx counter per Nvlink can be profiled at a time
    NvU32        numCountersRx;                                                 // Two Rx counter per Nvlink can be profiled at a time
    NvU32        nvlinkCountersAdded;                                           // Number of total NvLink TC added
    NvU32        unitOfTraffic[MAX_COUNTERS_PER_NVLINK * 2];                    // Unit Of Traffic for data transmission
    CUprofNvlinkDataTransferDirection  direction[MAX_COUNTERS_PER_NVLINK * 2];  // Direction data transmission
    NvU32        flitType[MAX_COUNTERS_PER_NVLINK * 2];                         // This can be used only if unit of data is flit
    NvU32        packetType[MAX_COUNTERS_PER_NVLINK * 2];                       // Packet type for data transmission
    NvU64        *prevValues;
}nvLinkTCSignalConfig;

struct CUpascalEventGroup_st {
    NvU32           *pmmAddress;                                       //Store domain address for each chiplet
    NvU32           *priAddress;                                       //Store pri address for each chiplet
    NvU32           maxChiplets;
    NvU32           pmUnitMask;
    NvU32           chipletType;                                       // Chiplet type for this domain
    CUparsedClk     *pParsedClk;                                       //Used for PM signals only
    NvU32           clkIdx;
    //TBD: Check if following can be removed.
    NvU32           gpcCount;
    NvU32           *tpcPerGpcCount;
    NvU32           fbpCount;
    CUSMCtrInfo     *pSM;                                               //Used for SM counters only
    nvLinkTCSignalConfig  *nvLinkTCConfig;
    nvLinkSignalConfig *nvlinkConfig;
    //Below 2 fields are used for SM virtualization
    //Max HW counters possible are 5 (= CU_PROF_PM_PERCLK_MODEB_MAX_COUNTERS + CU_PROF_ELAPSED_CLOCK_SLOT), the event group counters < HW counters.
    CUPerfSignalVirtualValue  flag[5];     //Stores flag whether to repeat values or interleave values
    NvU32        parts[5];    //Repeat - For how many eg counters the HW counter value should be repeated
                              //Interleave - How many HW counter values need to be interleaved to get one eg counter value.
};

// Used for Pc Sampling
typedef struct chiplet_st {
    size_t packetOffset;
    uint16_t droppedBytes;
    uint8_t isDelayed;
    uint8_t packet[5];
} chiplet;

typedef enum CUprofPascalWarpCantIssueReasons_enum {
    CUPROF_PASCAL_WARP_CANT_ISSUE_INVALID                         = 0,
    CUPROF_PASCAL_WARP_CANT_ISSUE_DRAIN                           = 1,
    CUPROF_PASCAL_WARP_CANT_ISSUE_ICACHE_MISS                     = 2,
    CUPROF_PASCAL_WARP_CANT_ISSUE_IMC_MISS                        = 3,
    CUPROF_PASCAL_WARP_CANT_ISSUE_LONG_SCOREBOARD                 = 4,
    CUPROF_PASCAL_WARP_CANT_ISSUE_BARRIER                         = 5,
    CUPROF_PASCAL_WARP_CANT_ISSUE_MEMBAR                          = 6,
    CUPROF_PASCAL_WARP_CANT_ISSUE_OFF_DECK_SHORT_SCOREBOARD       = 7,
    CUPROF_PASCAL_WARP_CANT_ISSUE_TILE_ALLOCATION_STALL           = 8,
    CUPROF_PASCAL_WARP_CANT_ISSUE_ALLOCATION_STALL_NOT_ELIGIBLE   = 9,
    CUPROF_PASCAL_WARP_CANT_ISSUE_ALLOCATION_STALL_NO_SPACE       = 10,
    CUPROF_PASCAL_WARP_CANT_ISSUE_WAIT                            = 11,
    CUPROF_PASCAL_WARP_CANT_ISSUE_ON_DECK_LONG_SCOREBOARD         = 12,
    CUPROF_PASCAL_WARP_CANT_ISSUE_ON_DECK_SHORT_SCOREBOARD        = 13,
    CUPROF_PASCAL_WARP_CANT_ISSUE_NO_INSTRUCTIONS                 = 14,
    CUPROF_PASCAL_WARP_CANT_ISSUE_SHADOW_PIPE_THROTTLE            = 15,
    CUPROF_PASCAL_WARP_CANT_ISSUE_TEX_THROTTLE                    = 16,
    CUPROF_PASCAL_WARP_CANT_ISSUE_MIO_THROTTLE                    = 17,
    CUPROF_PASCAL_WARP_CANT_ISSUE_DISPATCH_STALL                  = 18,
    CUPROF_PASCAL_WARP_CANT_ISSUE_NOT_SELECTED                    = 19,
    CUPROF_PASCAL_WARP_CANT_ISSUE_SELECTED                        = 20,
    CUPROF_PASCAL_WARP_CANT_ISSUE_MISC                            = 21,
    CUPROF_PASCAL_WARP_CANT_ISSUE_ON_DECK_MISC                    = 22,
    CUPROF_PASCAL_WARP_CANT_ISSUE_MAX_CIR                         = 23,
    CUPROF_PASCAL_WARP_CANT_ISSUE_FORCE_INT                       = 0X7FFFFFFF,
} CUprofPascalWarpCantIssueReasons;

extern CUdomainInfo domainInfoGP100;
extern PerfUnitTable PerfUnitTableGP100[];

extern CUdomainInfo domainInfoGP10x;
extern PerfUnitTable PerfUnitTableGP10x[];

extern CUdomainInfo domainInfoGP107;

extern CUdomainInfo domainInfoGP10Y;
extern PerfUnitTable PerfUnitTableGP10Y[];

//  3rd party tool specific specific functions
CUprofResult pascalPerfmonDeviceInitEventDomainInfo(CUdev *pDev);
CUprofResult pascalPerfmonGetInstanceValues(CUdev *dev, CUdomainData *domainData,
                                                 NvU32 *avail, NvU32 *total);
CUprofResult pascalPerfmonEventGroupCreate(CUctx *pCtx, CUeventGroup **pEventGroup);
CUprofResult pascalPerfmonEventGroupDestroy(CUeventGroup *pEventGroup);
CUprofResult pascalPerfmonEventGroupAddEvent(CUeventGroup *pEventGroup, NvU32 eventID);
CUprofResult pascalPerfmonEventGroupRemoveEvent(CUeventGroup *pEventGroup, NvU32 eventID);
CUprofResult pascalPerfmonEventGroupRemoveAllEvents(CUeventGroup *pEventGroup);
CUprofResult pascalPerfmonEventGroupResetAllEvents(CUeventGroup *pEventGroup);
CUprofResult pascalPerfmonEventGroupEnable(CUeventGroup *pEventGroup);
CUprofResult pascalPerfmonEventGroupDisable(CUeventGroup *pEventGroup);
CUprofResult pascalPerfmonEventGroupReadEvent(CUeventGroup          *pEventGroup,
                                             CUprof_ReadEventFlags flags,
                                             CUprof_EventID        eventID,
                                             size_t                *bufferSizeBytes,
                                             NvU64                 *counterData);

CUprofResult pascalPerfmonEventGroupReadAllEvents(CUeventGroup           *pEventGroup,
                                                 CUprof_ReadEventFlags  flags,
                                                 size_t                 *bufferSizeBytes,
                                                 NvU64                  *counterDataBuffer,
                                                 size_t                 *arraySizeBytes,
                                                 CUprof_EventID         *eventIDArray,
                                                 size_t                 *numCountersRead);
CUprofResult pascalPerfmonEventGroupControl(CUeventGroup *pEventGroup,
                                            CUeventGroupFlag flag,
                                            void *value);
CUprofResult pascalPerfmonDomainCheckCompatible(CUctx *ctx,
                                               CUeventDomainID domainId1,
                                               CUeventDomainID domainId2,
                                               NvBool *bCompatible);
CUprofResult pascalPerfmonAddSplitSignalsSM(CUeventGroup *pEventGroup,
                                               CUdomainData *pDomainData,
                                               CUeventInfo *pEventInfo,
                                               NvBool *bAdded,
                                               NvU32 *maxSignals,
                                               NvU32 splitWidth);
void pascalPerfmonStartCounters(CUnvCurrent** nvCurrent, CUeventGroup *pEventGroup);
void pascalPerfmonStopCounters(CUnvCurrent** nvCurrent, CUeventGroup *pEventGroup);
CUprofResult pascalPerfmonPCSamplingDisable(CUctx *ctx);
CUprofResult pascalPerfmonPCSamplingEnable(CUctx *ctx);
CUprofResult pascalPerfmonPCSamplingSetConfig(CUctx *ctx, CUprofSamplingConfig config, NvBool flag);
CUprofResult pascalPerfmonEventSamplingSetConfig(CUctx *ctx, CUprofSamplingConfig *config);
CUprofResult CUDAAPI pascalPerfmonPCSamplingRegisterReadCallback(CUctx *ctx,
                                                                 CUprofPCSamplingReadDataCallback pfnCallback,
                                                                 void* pUserData);
CUprofResult pascalBeginPCSampling(CUctx *ctx);
CUprofResult pascalEndPCSampling(CUctx *ctx);
CUprofResult pascalConsumePMABuffer(CUctx *ctx);
CUprofResult pascalReadIntermdiateBuffer(CUctx *ctx);
#endif // __PASCAL_PERFMON_H__
