/*
* Copyright 1993-2009 by NVIDIA Corporation.  All rights reserved.  All
* information contained herein is proprietary and confidential to NVIDIA
* Corporation.  Any use, reproduction, or disclosure without the written
* permission of NVIDIA Corporation is prohibited.
*/

/******************************************************************************
*
*   Module: kepelr_signals.c
*
*   Description:
*       pascal specific signals information
*
******************************************************************************/

#include "pascal_perfmon_new.h"
#include "perfmon_new.h"
#include "pascal_signals.h"
#include "pascal_signals_strings.h"

//TBD Check for all watchbus and PM ENABLE and group registers
PerfUnitTable PerfUnitTableGP100[] = {
// Unit-name                 PM enable                       GroupSel              maxGroups
//                      register  start end val        register  start end width
#if NVCFG(GLOBAL_GPU_FAMILY_GP10X)
// smquick has different regiser width for group selection
{PM_UNIT_SMCORE,   {0x00000600,   7,  7, 1},       {0x00000600,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
{PM_UNIT_SMQCTL,   {0x00000600,  15, 15, 1},       {0x00000600,  8, 14,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
{PM_UNIT_MIO,      {0x00000600,  23, 23, 1},       {0x00000600, 16, 22,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// SM  - watch buses from 32 to 39 (decimal) are assigned to SMK2PM_GPCTPC#TPC_MUXED_BUS_LOWER_0_#
// SM  - watch buses from 40 to 47 (decimal) are assigned to SMK2PM_GPCTPC#TPC_MUXED_BUS_UPPER_0_#
{PM_UNIT_MPC,      {0x0000040c,  31, 31, 1},       {0x0000040c,  0,  7,  8},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// MPC - watch buses from 32 to 40 (decimal) are assigned to MPC2PM_MUXED_BUS_#
{PM_UNIT_TEX_S,      {0x000002b0,  31, 31, 1},       {0x000002b0,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_T,      {0x000002b8,  31, 31, 1},       {0x000002b8,  0,  2,  3},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_T1,      {0x000002b8,  31, 31, 1},       {0x000002b8,  3,  7,  5},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_T2,      {0x000002b8,  31, 31, 1},       {0x000002b8,  8,  11,  4},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_T3,      {0x000002b8,  31, 31, 1},       {0x000002b8,  12,  18,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_D,      {0x000002bc,  31, 31, 1},       {0x000002bc,  0,  5,  6},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_M,      {0x000002c0,  31, 31, 1},       {0x000002C0,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_M1,      {0x000002c0,  31, 31, 1},       {0x000002C0,  8,  11,  4},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},

//Add unit for each L2 slice, this way we can set each slice independently
{PM_UNIT_LTS,      {0x00000150,   0,  0, 1},       {0x00000150,  1,  3,  3},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE},
{PM_UNIT_LTS1,     {0x00000150,   0,  0, 1},       {0x00000150,  4,  8,  5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE},
{PM_UNIT_LTS2,     {0x00000150,   0,  0, 1},       {0x00000150,  9,  13, 5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE},

{PM_UNIT_LTS_1,      {(0x00000150 + (NV_PLTS_STRIDE *1)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *1)),  1,  3,  3},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},
{PM_UNIT_LTS1_1,     {(0x00000150 + (NV_PLTS_STRIDE *1)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *1)),  4,  8,  5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},
{PM_UNIT_LTS2_1,     {(0x00000150 + (NV_PLTS_STRIDE *1)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *1)),  9,  13, 5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},

{PM_UNIT_LTC,      {0x00000028,   0,  0, 1},       {0x00000028,  1,  2,  2},  1, (NV_PLTCG_BASE),         NV_PLTCG_STRIDE,   0},
// LTC - watch buses from 12 to 15 (decimal) are assigned to LTC2PM_LTC_SECTOR_MUXED_BUS_#
{PM_UNIT_LTC1,     {0x00000028,   0,  0, 1},       {0x00000028,  3,  5,  3},  1, (NV_PLTCG_BASE),         NV_PLTCG_STRIDE,   0},
// LTC1 - watch buses from 17 to 42 (decimal) are assigned to LTC2PM_LTC_MUXED_BUS_#
{PM_UNIT_LTC2,     {0x00000028,   0,  0, 1},       {0x00000028,  6,  7,  2},  1, (NV_PLTCG_BASE),         NV_PLTCG_STRIDE,   0},
// LTC2 - watch buses from 16      (decimal) are assigned to LTC2PM_LTC_SRCUNIT_MUXED_BUS
// LTC5 - watch buses from 32 to 57(decimal) are assigned to LTC2PM_LTC_EXTENDED_MUXED_BUS_#
{PM_UNIT_FB,       {0x00000100,   0,  0, 1},       {0x00000100,   4,  10, 7},      1, NV_FBPA_PRI_BASE,                 NV_FBPA_PRI_STRIDE,0},
//FB - mwatch buses from 15 to 26(decimal) are assigned to FBPA2PM_LTC_FB_PERF_MUXED_BUS_#
{PM_UNIT_HUBMMU,   {0x00100C84,  31, 31, 1},       {0x00100C84,   0,  7, 8},  1, 0, 0, 0},
// HUBMMU - watch buses from 5 to 8(decimal) are assigned to HUBMMU2PM_HUB_MUXED_BUS_#
{PM_UNIT_HUBMMU,   {0x00100C84,  31, 31, 1},       {0x00100C84,   30,  30, 1},  1, 0, 0, 0},
// HUBMMU - watch buses from 5 to 8(decimal) are assigned to HUBMMU2PM_HUB_MUXED_BUS_#
{PM_UNIT_GPCMMU,   {0x00000884,  31, 31, 1},       {0x00000884,   0,  7, 8},  1, 0, 0, 0},

// Units added for PCI counter profiling
{PM_UNIT_XVE1,     {0x000884f4,  31, 31, 1 },      {0x000884f4,  0, 4, 5 },  1, 0, 0, 0 },
{PM_UNIT_XVE2,     {0x000884f4,  31, 31, 1 },      {0x000884f4,  5, 9, 5 },  1, 0, 0, 0 },
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) */
// TODO: add other units here
{PM_UNIT_MAX                                                                          }
};

PerfUnitTable PerfUnitTableGP10x[] = {
// Unit-name                 PM enable                       GroupSel              maxGroups
//                      register  start end val        register  start end width
#if NVCFG(GLOBAL_GPU_FAMILY_GP10X)
// smquick has different regiser width for group selection
{PM_UNIT_SMCORE,   {0x00000600,   7,  7, 1},       {0x00000600,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
{PM_UNIT_SMQCTL,   {0x00000600,  15, 15, 1},       {0x00000600,  8, 14,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
{PM_UNIT_MIO,      {0x00000600,  23, 23, 1},       {0x00000600, 16, 22,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// SM  - watch buses from 32 to 39 (decimal) are assigned to SMK2PM_GPCTPC#TPC_MUXED_BUS_LOWER_0_#
// SM  - watch buses from 40 to 47 (decimal) are assigned to SMK2PM_GPCTPC#TPC_MUXED_BUS_UPPER_0_#
{PM_UNIT_MPC,      {0x0000040c,  31, 31, 1},       {0x0000040c,  0,  7,  8},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// MPC - watch buses from 32 to 40 (decimal) are assigned to MPC2PM_MUXED_BUS_#
{PM_UNIT_TEX_S,      {0x000002b0,  31, 31, 1},       {0x000002b0,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_T,      {0x000002b8,  31, 31, 1},       {0x000002b8,  0,  2,  3},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_T1,      {0x000002b8,  31, 31, 1},       {0x000002b8,  3,  7,  5},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_T2,      {0x000002b8,  31, 31, 1},       {0x000002b8,  8,  11,  4},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_T3,      {0x000002b8,  31, 31, 1},       {0x000002b8,  12,  18,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_D,      {0x000002bc,  31, 31, 1},       {0x000002bc,  0,  5,  6},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_M,      {0x000002c0,  31, 31, 1},       {0x000002C0,  0,  6,  7},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},
// TEX - watch buses from 10 to 19 (decimal) are assigned to TEX2PM_GPC_M_MUXED_BUS_#
{PM_UNIT_TEX_M1,      {0x000002c0,  31, 31, 1},       {0x000002C0,  8,  11,  4},  1, (NV_GPC_PRI_BASE+NV_TPC_IN_GPC_BASE), NV_GPC_PRI_STRIDE, NV_TPC_IN_GPC_STRIDE},

//Add unit for each L2 slice, this way we can set each slice independently
{PM_UNIT_LTS,      {0x00000150,   0,  0, 1},       {0x00000150,  1,  4,  5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE},
{PM_UNIT_LTS1,     {0x00000150,   0,  0, 1},       {0x00000150,  5,  10,  6},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE},
{PM_UNIT_LTS2,     {0x00000150,   0,  0, 1},       {0x00000150,  11,  15, 5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   NV_PLTS_STRIDE},

{PM_UNIT_LTS_1,      {(0x00000150 + (NV_PLTS_STRIDE *1)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *1)),  1,  4,  5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},
{PM_UNIT_LTS1_1,     {(0x00000150 + (NV_PLTS_STRIDE *1)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *1)),  5,  10,  6},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},
{PM_UNIT_LTS2_1,     {(0x00000150 + (NV_PLTS_STRIDE *1)),   0,  0, 1},       {(0x00000150 + (NV_PLTS_STRIDE *1)),  11,  15, 5},  1, (NV_PLTCG_BASE+NV_PLTS_BASE),         NV_PLTCG_STRIDE,   0},

{PM_UNIT_LTC,      {0x00000028,   0,  0, 1},       {0x00000028,  1,  2,  2},  1, (NV_PLTCG_BASE),         NV_PLTCG_STRIDE,   0},
// LTC - watch buses from 12 to 15 (decimal) are assigned to LTC2PM_LTC_SECTOR_MUXED_BUS_#
{PM_UNIT_LTC1,     {0x00000028,   0,  0, 1},       {0x00000028,  3,  5,  3},  1, (NV_PLTCG_BASE),         NV_PLTCG_STRIDE,   0},
// LTC1 - watch buses from 17 to 42 (decimal) are assigned to LTC2PM_LTC_MUXED_BUS_#
{PM_UNIT_LTC2,     {0x00000028,   0,  0, 1},       {0x00000028,  6,  7,  2},  1, (NV_PLTCG_BASE),         NV_PLTCG_STRIDE,   0},
// LTC2 - watch buses from 16      (decimal) are assigned to LTC2PM_LTC_SRCUNIT_MUXED_BUS
// LTC5 - watch buses from 32 to 57(decimal) are assigned to LTC2PM_LTC_EXTENDED_MUXED_BUS_#
{PM_UNIT_FB,       {0x00000100,   0,  0, 1},       {0x00000100,   4,  10, 7},      1, NV_FBPA_PRI_BASE,                 NV_FBPA_PRI_STRIDE,0},
//FB - mwatch buses from 15 to 26(decimal) are assigned to FBPA2PM_LTC_FB_PERF_MUXED_BUS_#
{PM_UNIT_HUBMMU,   {0x00100C84,  31, 31, 1},       {0x00100C84,   0,  7, 8},  1, 0, 0, 0},
// HUBMMU - watch buses from 5 to 8(decimal) are assigned to HUBMMU2PM_HUB_MUXED_BUS_#
{PM_UNIT_HUBMMU,   {0x00100C84,  31, 31, 1},       {0x00100C84,   30,  30, 1},  1, 0, 0, 0},
// NVLINK - watch buses from 0 to 15(decimal) are assigned to nvlink and sequentially DL0, TL0, DL1, TL1, DL2, TL2, DL3, TL3, IOCTRL 
//Taken from dev_nvltl.h NV_PNVLTL_MULTICAST_TL_PMCTRL_REG and NV_PNVLTL_MULTICAST_TL_PMMUXSEL_REG
{PM_UNIT_NVLINK0,   {0x00a16080,  0, 0, 1},       {0x00a16084,    0,   7,  8},  1, 0, 0, 0},
{PM_UNIT_NVLINK1,   {0x00a1e080,  0, 0, 1},       {0x00a1e084,    0,   7,  8},  1, 0, 0, 0},
{PM_UNIT_NVLINK2,   {0x00a26080,  0, 0, 1},       {0x00a26084,    0,   7,  8},  1, 0, 0, 0},
{PM_UNIT_NVLINK3,   {0x00a2e080,  0, 0, 1},       {0x00a2e084,    0,   7,  8},  1, 0, 0, 0},
// HUBMMU - watch buses from 5 to 8(decimal) are assigned to HUBMMU2PM_HUB_MUXED_BUS_#
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) */
// TODO: add other units here
{PM_UNIT_GPCMMU,   {0x00000884,  31, 31, 1},       {0x00000884,   0,  7, 8},  1, 0, 0, 0},

// Units added for PCI counter profiling
{PM_UNIT_XVE1,     {0x000884f4,  31, 31, 1 },      {0x000884f4,  0, 4, 5 },  1, 0, 0, 0 },
{PM_UNIT_XVE2,     {0x000884f4,  31, 31, 1 },      {0x000884f4,  5, 9, 5 },  1, 0, 0, 0 },
{PM_UNIT_MAX                                                                          }
};

// Perf signal table for pascal
// perf-event: signal0 - 2:0, signal1 - 6:4, signal2 - 10:8, signal3 - 14:12
// Some sigmals are commented and not removed so that they can be used for testing purpose in future.
#if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
PerfSignalHwpm PerfSignalTableGP100_gpc0[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type
    {PASCAL_MMU_GPC_LTP0_UTLB_HIT, pascal_mmu_gpc_ltp0_utlb_hit_enc_str_1, 0x3, 0xaaaa, 0x58, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_LTP0_UTLB_MISS_INT, pascal_mmu_gpc_ltp0_utlb_miss_int_enc_str_1, 0x3, 0xaaaa, 0x59, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_LTP1_UTLB_HIT, pascal_mmu_gpc_ltp1_utlb_hit_enc_str_1, 0x4, 0xaaaa, 0x58, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_LTP1_UTLB_MISS_INT, pascal_mmu_gpc_ltp1_utlb_miss_int_enc_str_1, 0x4, 0xaaaa, 0x59, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_LTP2_UTLB_HIT, pascal_mmu_gpc_ltp2_utlb_hit_enc_str_1, 0x5, 0xaaaa, 0x58, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_LTP2_UTLB_MISS_INT, pascal_mmu_gpc_ltp2_utlb_miss_int_enc_str_1, 0x5, 0xaaaa, 0x59, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_LTP3_UTLB_HIT, pascal_mmu_gpc_ltp3_utlb_hit_enc_str_1, 0x6, 0xaaaa, 0x58, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_LTP3_UTLB_MISS_INT, pascal_mmu_gpc_ltp3_utlb_miss_int_enc_str_1, 0x6, 0xaaaa, 0x59, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_LTP4_UTLB_HIT, pascal_mmu_gpc_ltp4_utlb_hit_enc_str_1, 0x40, 0xaaaa, 0x58, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_LTP4_UTLB_MISS_INT, pascal_mmu_gpc_ltp4_utlb_miss_int_enc_str_1, 0x40, 0xaaaa, 0x59, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_RGG_UTLB_HIT, pascal_mmu_gpc_rgg_utlb_hit_enc_str_1, 0x7, 0xaaaa, 0x58, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_RGG_UTLB_MISS_INT, pascal_mmu_gpc_rgg_utlb_miss_int_enc_str_1, 0x7, 0xaaaa, 0x59, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_GPCL1_TLB_HIT, pascal_mmu_gpc_gpcl1_tlb_hit_enc_str_1, 0x9, 0xaaaa, 0x58, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_GPCL1_TLB_MISS_INT, pascal_mmu_gpc_gpcl1_tlb_miss_int_enc_str_1, 0x9, 0xaaaa, 0x59, PM_UNIT_GPCMMU, 1},

    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpm PerfSignalTableGP10x_gpc0[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type
    {PASCAL_MMU_GPC_LTP0_UTLB_HIT, pascal_mmu_gpc_ltp0_utlb_hit_enc_str_1, 0x3, 0xaaaa, 0x50, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_LTP0_UTLB_MISS_INT, pascal_mmu_gpc_ltp0_utlb_miss_int_enc_str_1, 0x3, 0xaaaa, 0x51, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_LTP1_UTLB_HIT, pascal_mmu_gpc_ltp1_utlb_hit_enc_str_1, 0x4, 0xaaaa, 0x50, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_LTP1_UTLB_MISS_INT, pascal_mmu_gpc_ltp1_utlb_miss_int_enc_str_1, 0x4, 0xaaaa, 0x51, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_LTP2_UTLB_HIT, pascal_mmu_gpc_ltp2_utlb_hit_enc_str_1, 0x5, 0xaaaa, 0x50, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_LTP2_UTLB_MISS_INT, pascal_mmu_gpc_ltp2_utlb_miss_int_enc_str_1, 0x5, 0xaaaa, 0x51, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_LTP3_UTLB_HIT, pascal_mmu_gpc_ltp3_utlb_hit_enc_str_1, 0x6, 0xaaaa, 0x50, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_LTP3_UTLB_MISS_INT, pascal_mmu_gpc_ltp3_utlb_miss_int_enc_str_1, 0x6, 0xaaaa, 0x51, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_LTP4_UTLB_HIT, pascal_mmu_gpc_ltp4_utlb_hit_enc_str_1, 0x40, 0xaaaa, 0x50, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_LTP4_UTLB_MISS_INT, pascal_mmu_gpc_ltp4_utlb_miss_int_enc_str_1, 0x40, 0xaaaa, 0x51, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_RGG_UTLB_HIT, pascal_mmu_gpc_rgg_utlb_hit_enc_str_1, 0x7, 0xaaaa, 0x50, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_RGG_UTLB_MISS_INT, pascal_mmu_gpc_rgg_utlb_miss_int_enc_str_1, 0x7, 0xaaaa, 0x51, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_GPCL1_TLB_HIT, pascal_mmu_gpc_gpcl1_tlb_hit_enc_str_1, 0x9, 0xaaaa, 0x50, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_GPCL1_TLB_MISS_INT, pascal_mmu_gpc_gpcl1_tlb_miss_int_enc_str_1, 0x9, 0xaaaa, 0x51, PM_UNIT_GPCMMU, 1},

    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpm PerfSignalTableGP107_gpc0[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type
    {PASCAL_MMU_GPC_LTP0_UTLB_HIT, pascal_mmu_gpc_ltp0_utlb_hit_enc_str_1, 0x3, 0xaaaa, 0x30, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_LTP0_UTLB_MISS_INT, pascal_mmu_gpc_ltp0_utlb_miss_int_enc_str_1, 0x3, 0xaaaa, 0x31, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_LTP1_UTLB_HIT, pascal_mmu_gpc_ltp1_utlb_hit_enc_str_1, 0x4, 0xaaaa, 0x30, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_LTP1_UTLB_MISS_INT, pascal_mmu_gpc_ltp1_utlb_miss_int_enc_str_1, 0x4, 0xaaaa, 0x31, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_LTP2_UTLB_HIT, pascal_mmu_gpc_ltp2_utlb_hit_enc_str_1, 0x5, 0xaaaa, 0x30, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_LTP2_UTLB_MISS_INT, pascal_mmu_gpc_ltp2_utlb_miss_int_enc_str_1, 0x5, 0xaaaa, 0x31, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_RGG_UTLB_HIT, pascal_mmu_gpc_rgg_utlb_hit_enc_str_1, 0x7, 0xaaaa, 0x30, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_RGG_UTLB_MISS_INT, pascal_mmu_gpc_rgg_utlb_miss_int_enc_str_1, 0x7, 0xaaaa, 0x31, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_GPCL1_TLB_HIT, pascal_mmu_gpc_gpcl1_tlb_hit_enc_str_1, 0x9, 0xaaaa, 0x30, PM_UNIT_GPCMMU, 1},
    {PASCAL_MMU_GPC_GPCL1_TLB_MISS_INT, pascal_mmu_gpc_gpcl1_tlb_miss_int_enc_str_1, 0x9, 0xaaaa, 0x31, PM_UNIT_GPCMMU, 1},

    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpm PerfSignalTableGP10y_gpc0[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type
    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpmExpt_v1 PerfSignalTableGP100_gpc0_expt[] = {
    {PASCAL_MMU_GPC_LTP0_UTLB_MISS, pascal_mmu_gpc_ltp0_utlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_MMU_GPC_LTP0_UTLB_HIT, PASCAL_MMU_GPC_LTP0_UTLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {PASCAL_MMU_GPC_LTP1_UTLB_MISS, pascal_mmu_gpc_ltp1_utlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_MMU_GPC_LTP1_UTLB_HIT, PASCAL_MMU_GPC_LTP1_UTLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {PASCAL_MMU_GPC_LTP2_UTLB_MISS, pascal_mmu_gpc_ltp2_utlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_MMU_GPC_LTP2_UTLB_HIT, PASCAL_MMU_GPC_LTP2_UTLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {PASCAL_MMU_GPC_LTP3_UTLB_MISS, pascal_mmu_gpc_ltp3_utlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_MMU_GPC_LTP3_UTLB_HIT, PASCAL_MMU_GPC_LTP3_UTLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {PASCAL_MMU_GPC_LTP4_UTLB_MISS, pascal_mmu_gpc_ltp4_utlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_MMU_GPC_LTP4_UTLB_HIT, PASCAL_MMU_GPC_LTP4_UTLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {PASCAL_MMU_GPC_RGG_UTLB_MISS, pascal_mmu_gpc_rgg_utlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW,   {PASCAL_MMU_GPC_RGG_UTLB_HIT,  PASCAL_MMU_GPC_RGG_UTLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {PASCAL_MMU_GPC_GPCL1_TLB_MISS, pascal_mmu_gpc_gpcl1_tlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_MMU_GPC_GPCL1_TLB_HIT, PASCAL_MMU_GPC_GPCL1_TLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},

    { INVALID_PM_SIGNAL_NEW,     "",                     0xffffffff, 0x00000000, 0x00,     PM_UNIT_MAX,0}
};

PerfSignalHwpmExpt_v1 PerfSignalTableGP107_gpc0_expt[] = {
    {PASCAL_MMU_GPC_LTP0_UTLB_MISS, pascal_mmu_gpc_ltp0_utlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_MMU_GPC_LTP0_UTLB_HIT, PASCAL_MMU_GPC_LTP0_UTLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {PASCAL_MMU_GPC_LTP1_UTLB_MISS, pascal_mmu_gpc_ltp1_utlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_MMU_GPC_LTP1_UTLB_HIT, PASCAL_MMU_GPC_LTP1_UTLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {PASCAL_MMU_GPC_LTP2_UTLB_MISS, pascal_mmu_gpc_ltp2_utlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_MMU_GPC_LTP2_UTLB_HIT, PASCAL_MMU_GPC_LTP2_UTLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {PASCAL_MMU_GPC_RGG_UTLB_MISS, pascal_mmu_gpc_rgg_utlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW,   {PASCAL_MMU_GPC_RGG_UTLB_HIT,  PASCAL_MMU_GPC_RGG_UTLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    {PASCAL_MMU_GPC_GPCL1_TLB_MISS, pascal_mmu_gpc_gpcl1_tlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_MMU_GPC_GPCL1_TLB_HIT, PASCAL_MMU_GPC_GPCL1_TLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},

    { INVALID_PM_SIGNAL_NEW,     "",                     0xffffffff, 0x00000000, 0x00,     PM_UNIT_MAX,0}
};
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B) */

#if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
PerfSignalHwpmMux PerfSignalTableGP100_hwpmmux_coremio[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type

#if CU_PASCAL_PROFILE_SM_SIGNALS_VIA_HWPM
    // ########### SM Unit ###########
    // ***LAUNCHED***
    // sch_warps_launched               SM has launched 1 warp
    // sch_threads_launched             number of threads SM launched this cycle
    //TBD check with latest files, threads_launched watchbus looks incorrect
    {PASCAL_HWPMMUX_ACTIVE_CYCLES, pascal_hwpmmux_active_cycles_enc_str_1, 0x1, 0xaaaa, 0x1, PM_UNIT_SMCORE, 1, 1},
    {PASCAL_HWPMMUX_ACTIVE_WARPS, pascal_hwpmmux_active_warps_enc_str_1, 0x1, 0xffff, 0x2, PM_UNIT_SMCORE, 6, 2},
    {PASCAL_HWPMMUX_CTA_LAUNCHED, pascal_hwpmmux_cta_launched_enc_str_1, 0x6, 0xaaaa, 0x1, PM_UNIT_SMCORE, 1, 1},
    {PASCAL_HWPMMUX_SHARED_LD_MEM_DIVERGENCE_REPLAYS_H0, pascal_hwpmmux_shared_ld_mem_divergence_replays_h0_enc_str_1, 0x0000000c, 0xaaaa, 0x00000050, PM_UNIT_MIO, 1 ,0 },
    {PASCAL_HWPMMUX_SHARED_LD_MEM_DIVERGENCE_REPLAYS_H1, pascal_hwpmmux_shared_ld_mem_divergence_replays_h1_enc_str_1, 0x0000000c, 0xaaaa, 0x00000051, PM_UNIT_MIO, 1 ,1 },
    {PASCAL_HWPMMUX_SHARED_ST_MEM_DIVERGENCE_REPLAYS_H0, pascal_hwpmmux_shared_st_mem_divergence_replays_h0_enc_str_1, 0x0000000c, 0xaaaa, 0x00000052, PM_UNIT_MIO, 1 ,2 },
    {PASCAL_HWPMMUX_SHARED_ST_MEM_DIVERGENCE_REPLAYS_H1, pascal_hwpmmux_shared_st_mem_divergence_replays_h1_enc_str_1, 0x0000000c, 0xaaaa, 0x00000053, PM_UNIT_MIO, 1 ,3 },
    {PASCAL_HWPMMUX_SHARED_LD_TRANSACTIONS_H0,           pascal_hwpmmux_shared_ld_transactions_h0_enc_str_1,           0x0000000c, 0xaaaa, 0x00000054, PM_UNIT_MIO, 1 ,4 },
    {PASCAL_HWPMMUX_SHARED_LD_TRANSACTIONS_H1,           pascal_hwpmmux_shared_ld_transactions_h1_enc_str_1,           0x0000000c, 0xaaaa, 0x00000055, PM_UNIT_MIO, 1 ,5 },
    {PASCAL_HWPMMUX_SHARED_ST_TRANSACTIONS_H0,           pascal_hwpmmux_shared_st_transactions_h0_enc_str_1,           0x0000000c, 0xaaaa, 0x00000056, PM_UNIT_MIO, 1 ,6 },
    {PASCAL_HWPMMUX_SHARED_ST_TRANSACTIONS_H1,           pascal_hwpmmux_shared_st_transactions_h1_enc_str_1,           0x0000000c, 0xaaaa, 0x00000057, PM_UNIT_MIO, 1 ,7 },

#endif
    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B) */

#if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
PerfSignalHwpmMux PerfSignalTableGP100_hwpmmux_quad[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type

#if CU_PASCAL_PROFILE_SM_SIGNALS_VIA_HWPM
    // ########### SM Unit ###########
    // ***LAUNCHED***
    // sch_warps_launched               SM has launched 1 warp
    // sch_threads_launched             number of threads SM launched this cycle
    //TBD check with latest files, threads_launched watchbus looks incorrect
    {PASCAL_HWPMMUX_THREAD_INST_EXECUTED, pascal_hwpmmux_thread_inst_executed_enc_str_1, 0x15, 0xffff, 0x10, PM_UNIT_SMQCTL, 6, 0},
    {PASCAL_HWPMMUX_NPO_THREAD_INST_EXECUTED, pascal_hwpmmux_npo_thread_inst_executed_enc_str_1, 0x15, 0xffff, 0x18, PM_UNIT_SMQCTL, 6, 0},
    {PASCAL_HWPMMUX_WARPS_LAUNCHED, pascal_hwpmmux_warps_launched_enc_str_1, 0x1, 0xaaaa, 0x11, PM_UNIT_SMQCTL, 1, 1},
    {PASCAL_HWPMMUX_THREADS_LAUNCHED, pascal_hwpmmux_threads_launched_enc_str_1, 0x19, 0xffff, 0x10, PM_UNIT_SMQCTL, 6, 0},
    {PASCAL_SMQCTL_INST_EXECUTED_FP16G0_PIPE, pascal_smqctl_inst_executed_fp16g0_pipe_enc_str_1, 0xe, 0xaaaa, 0x1a, PM_UNIT_SMQCTL, 1, 0xa },
    {PASCAL_SMQCTL_INST_EXECUTED_FP16G1_PIPE, pascal_smqctl_inst_executed_fp16g1_pipe_enc_str_1, 0xe, 0xaaaa, 0x1b, PM_UNIT_SMQCTL, 1, 0xb },
    {PASCAL_SMQCTL_INST_EXECUTED_FP16_DECOUPLED_PIPE, pascal_smqctl_inst_executed_fp16_decoupled_pipe_enc_str_1, 0xe, 0xaaaa, 0x1c, PM_UNIT_SMQCTL, 1, 0xc },
    {PASCAL_SMQCTL_INST_EXECUTED_FP16G0_PIPE_HIGHPOWER, pascal_smqctl_inst_executed_fp16g0_pipe_highpower_enc_str_1, 0xe, 0xaaaa, 0x1d, PM_UNIT_SMQCTL, 1, 0xd },
    {PASCAL_SMQCTL_INST_EXECUTED_FP16G1_PIPE_HIGHPOWER, pascal_smqctl_inst_executed_fp16g1_pipe_highpower_enc_str_1, 0xe, 0xaaaa, 0x1e, PM_UNIT_SMQCTL, 1, 0xe },
    {PASCAL_SMQCTL_INST_FP16G0_PIPE_UNIFORM_DATA_QUAD_Q, pascal_smqctl_inst_fp16g0_pipe_uniform_data_quad_q_enc_str_1, 0x55, 0xffff, 0x18, PM_UNIT_SMQCTL, 3, 0x8 },
    {PASCAL_SMQCTL_INST_FP16G1_PIPE_UNIFORM_DATA_QUAD_Q, pascal_smqctl_inst_fp16g1_pipe_uniform_data_quad_q_enc_str_1, 0x55, 0xffff, 0x1b, PM_UNIT_SMQCTL, 3, 0xb },

#endif
    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B) */

// Perf signal table for pascal
// perf-event: signal0 - 2:0, signal1 - 6:4, signal2 - 10:8, signal3 - 14:12
// Some sigmals are commented and not removed so that they can be used for testing purpose in future.
#if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
PerfSignalHwpm PerfSignalTableGP100_gpctpc[] = {
    // Signal ID                        signal-name-CUDA            event-group perf-event  function     watchbus      clk-domain                PM unit         signal-select      sig-type            chiplet-type

#if CU_PASCAL_PROFILE_SM_SIGNALS_VIA_HWPM
    // ########### SM Unit ###########
    // ***LAUNCHED***
    // sch_warps_launched               SM has launched 1 warp
    // sch_threads_launched             number of threads SM launched this cycle
    //TBD check with latest files, threads_launched watchbus looks incorrect
    {PASCAL_HWPM_THREAD_INST_EXECUTED_0, pascal_hwpm_thread_inst_executed_s0_enc_str_1, 0x15, 0xffff, 0x10, PM_UNIT_SMQCTL, 6, 0},
    {PASCAL_HWPM_NPO_THREAD_INST_EXECUTED_0, pascal_hwpm_npo_thread_inst_executed_s0_enc_str_1, 0x15, 0xffff, 0x18, PM_UNIT_SMQCTL, 6, 0},
    {PASCAL_HWPM_INST_EXECUTED_S0, pascal_hwpm_inst_executed_s0_enc_str_1, 0x2, 0xffff, 0x16, PM_UNIT_SMQCTL, 2},
    {PASCAL_HWPM_WARPS_LAUNCHED_0, pascal_hwpm_warps_launched_0_enc_str_1, 0x19, 0xaaaa, 0x17, PM_UNIT_SMQCTL, 1},
    {PASCAL_HWPM_WARPS_LAUNCHED_1, pascal_hwpm_warps_launched_1_enc_str_1, 0x19, 0xaaaa, 0x27, PM_UNIT_SMQCTL, 1},
    {PASCAL_HWPM_WARPS_LAUNCHED_2, pascal_hwpm_warps_launched_2_enc_str_1, 0x19, 0xaaaa, 0x37, PM_UNIT_SMQCTL, 1},
    {PASCAL_HWPM_WARPS_LAUNCHED_3, pascal_hwpm_warps_launched_3_enc_str_1, 0x19, 0xaaaa, 0x47, PM_UNIT_SMQCTL, 1},
    {PASCAL_HWPM_THREADS_LAUNCHED_0, pascal_hwpm_threads_launched_0_enc_str_1, 0x19, 0xffff, 0x10, PM_UNIT_SMQCTL, 6},
    {PASCAL_HWPM_THREADS_LAUNCHED_1, pascal_hwpm_threads_launched_1_enc_str_1, 0x19, 0xffff, 0x20, PM_UNIT_SMQCTL, 6},
    {PASCAL_HWPM_THREADS_LAUNCHED_2, pascal_hwpm_threads_launched_2_enc_str_1, 0x19, 0xffff, 0x30, PM_UNIT_SMQCTL, 6},
    {PASCAL_HWPM_THREADS_LAUNCHED_3, pascal_hwpm_threads_launched_3_enc_str_1, 0x19, 0xffff, 0x40, PM_UNIT_SMQCTL, 6},
    { PASCAL_HWPM_ACTIVE_CYCLES_Q0, pascal_hwpm_active_cycles_q0_enc_str_1, 0x1, 0xffff, 0x10, PM_UNIT_SMQCTL, 1 },
    { PASCAL_HWPM_ACTIVE_CYCLES_Q1, pascal_hwpm_active_cycles_q1_enc_str_1, 0x1, 0xffff, 0x20, PM_UNIT_SMQCTL, 1 },
    { PASCAL_HWPM_ACTIVE_CYCLES_Q2, pascal_hwpm_active_cycles_q2_enc_str_1, 0x1, 0xffff, 0x30, PM_UNIT_SMQCTL, 1 },
    { PASCAL_HWPM_ACTIVE_CYCLES_Q3, pascal_hwpm_active_cycles_q3_enc_str_1, 0x1, 0xffff, 0x40, PM_UNIT_SMQCTL, 1 },
    {PASCAL_HWPM_INST_EXECUTED_TEX_OPS_Q0, pascal_hwpm_inst_executed_tex_ops_q0_enc_str_1, 0x12, 0xaaaa, 0x1e, PM_UNIT_SMQCTL, 1},
    {PASCAL_HWPM_INST_EXECUTED_TEX_OPS_Q1, pascal_hwpm_inst_executed_tex_ops_q1_enc_str_1, 0x12, 0xaaaa, 0x2e, PM_UNIT_SMQCTL, 1},
    {PASCAL_HWPM_INST_EXECUTED_TEX_OPS_Q2, pascal_hwpm_inst_executed_tex_ops_q2_enc_str_1, 0x12, 0xaaaa, 0x3e, PM_UNIT_SMQCTL, 1},
    {PASCAL_HWPM_INST_EXECUTED_TEX_OPS_Q3, pascal_hwpm_inst_executed_tex_ops_q3_enc_str_1, 0x12, 0xaaaa, 0x4e, PM_UNIT_SMQCTL, 1},
    {PASCAL_HWPM_WARPS_RESTORED_0, pascal_hwpm_warps_restored_0_enc_str_1, 0x19, 0xaaaa, 0x16, PM_UNIT_SMQCTL, 1},
    {PASCAL_HWPM_WARPS_RESTORED_1, pascal_hwpm_warps_restored_1_enc_str_1, 0x19, 0xaaaa, 0x26, PM_UNIT_SMQCTL, 1},
    {PASCAL_HWPM_WARPS_RESTORED_2, pascal_hwpm_warps_restored_2_enc_str_1, 0x19, 0xaaaa, 0x36, PM_UNIT_SMQCTL, 1},
    {PASCAL_HWPM_WARPS_RESTORED_3, pascal_hwpm_warps_restored_3_enc_str_1, 0x19, 0xaaaa, 0x46, PM_UNIT_SMQCTL, 1},

    {PASCAL_HWPM_ACTIVE_CYCLES, pascal_hwpm_active_cycles_enc_str_1, 0x1, 0xaaaa, 0x1, PM_UNIT_SMCORE, 1},
    {PASCAL_HWPM_ACTIVE_WARPS, pascal_hwpm_active_warps_enc_str_1, 0x1, 0xffff, 0x2, PM_UNIT_SMCORE, 6},
    {PASCAL_HWPM_CTA_LAUNCHED, pascal_hwpm_cta_launched_enc_str_1, 0x6, 0xaaaa, 0x1, PM_UNIT_SMCORE, 1},
    {PASCAL_HWPM_SHARED_LD_MEM_DIVERGENCE_REPLAYS_H0, pascal_hwpm_shared_ld_mem_divergence_replays_h0_enc_str_1, 0x0000000c, 0xaaaa, 0x00000050, PM_UNIT_MIO, 1},
    {PASCAL_HWPM_SHARED_LD_MEM_DIVERGENCE_REPLAYS_H1, pascal_hwpm_shared_ld_mem_divergence_replays_h1_enc_str_1, 0x0000000c, 0xaaaa, 0x00000051, PM_UNIT_MIO, 1},
    {PASCAL_HWPM_SHARED_ST_MEM_DIVERGENCE_REPLAYS_H0, pascal_hwpm_shared_st_mem_divergence_replays_h0_enc_str_1, 0x0000000c, 0xaaaa, 0x00000052, PM_UNIT_MIO, 1},
    {PASCAL_HWPM_SHARED_ST_MEM_DIVERGENCE_REPLAYS_H1, pascal_hwpm_shared_st_mem_divergence_replays_h1_enc_str_1, 0x0000000c, 0xaaaa, 0x00000053, PM_UNIT_MIO, 1},
    {PASCAL_HWPM_SHARED_LD_TRANSACTIONS_H0,           pascal_hwpm_shared_ld_transactions_h0_enc_str_1,           0x0000000c, 0xaaaa, 0x00000054, PM_UNIT_MIO, 1},
    {PASCAL_HWPM_SHARED_LD_TRANSACTIONS_H1,           pascal_hwpm_shared_ld_transactions_h1_enc_str_1,           0x0000000c, 0xaaaa, 0x00000055, PM_UNIT_MIO, 1},
    {PASCAL_HWPM_SHARED_ST_TRANSACTIONS_H0,           pascal_hwpm_shared_st_transactions_h0_enc_str_1,           0x0000000c, 0xaaaa, 0x00000056, PM_UNIT_MIO, 1},
    {PASCAL_HWPM_SHARED_ST_TRANSACTIONS_H1,           pascal_hwpm_shared_st_transactions_h1_enc_str_1,           0x0000000c, 0xaaaa, 0x00000057, PM_UNIT_MIO, 1},
#endif
    {PASCAL_PROFILER_FIRST,           pascal_profiler_first_enc_str_1,           0x0000000a, 0xaaaa, 0x00000008, PM_UNIT_SMCORE, 1},
    {PASCAL_PROFILER_VALID,           pascal_profiler_valid_enc_str_1,           0x0000000a, 0xaaaa, 0x00000009, PM_UNIT_SMCORE, 1},

    //mpc signals
    //ctas_launched is doubtful. watchbus is 7e? On emulator 7d is working
    {PASCAL_MPC_CTAS_LAUNCHED, pascal_mpc_ctas_launched_enc_str_1, 0x13, 0xaaaa, 0x7e, PM_UNIT_MPC, 1},
    {PASCAL_MPC_THREADS_LAUNCHED, pascal_mpc_threads_launched_enc_str_1, 0x14, 0xffff, 0x77, PM_UNIT_MPC, 6},
    {PASCAL_MPC_WARPS_IN_FLIGHT, pascal_mpc_warps_in_flight_enc_str_1, 0x4f, 0xffff, 0x77, PM_UNIT_MPC, 7},
    {PASCAL_MPC_COMPUTE_CTAS_IN_FLIGHT, pascal_mpc_compute_ctas_in_flight_enc_str_1, 0x4d, 0xffff, 0x77, PM_UNIT_MPC, 5},

    //Tex signals
    // based on experiments - tex_cache_misses_gpc0_tpc0_tex0 and tex_cache_sector_queries_gpc0_tpc0_tex0
    // defined in \\hw\tools\perfalyze\chips\gm107\pml_files\tex.pml
    //tex0_cache_lg_sector_queries  = tex02pm_gpc_t_lg_sector_queries
    //tex0_cache_lg_sector_misses   = tex02pm_gpc_t_lg_missed_sectors
    //tex1_cache_lg_sector_queries = tex12pm_gpc_t_lg_sector_queries
    //tex1_cache_lg_sector_misses  = tex12pm_gpc_t_lg_missed_sectors

    {PASCAL_TEX0_LG_SECTOR_QUERIES, pascal_tex0_lg_sector_queries_enc_str_1, 0x1b, 0xffff, 0x84, PM_UNIT_TEX_M, 4},
    {PASCAL_TEX1_LG_SECTOR_QUERIES, pascal_tex1_lg_sector_queries_enc_str_1, 0x1b, 0xffff, 0x70, PM_UNIT_TEX_M, 4},
    {PASCAL_TEX0_LG_MISSED_SECTORS, pascal_tex0_lg_missed_sectors_enc_str_1, 0x1b, 0xffff, 0x80, PM_UNIT_TEX_M, 4},
    {PASCAL_TEX1_LG_MISSED_SECTORS, pascal_tex1_lg_missed_sectors_enc_str_1, 0x1b, 0xffff, 0x6c, PM_UNIT_TEX_M, 4},

    //tex0_cache_sector_queries  = tex02pm_gpc_t_sector_queries
    //tex0_cache_sector_misses   = tex02pm_gpc_t_missed_sectors
    //tex1_cache_sector_queries = tex12pm_gpc_t_sector_queries
    //tex1_cache_sector_misses  = tex12pm_gpc_t_missed_sectors
    {PASCAL_TEX0_SECTOR_QUERIES, pascal_tex0_sector_queries_enc_str_1, 0x5, 0xffff, 0x84, PM_UNIT_TEX_M, 5},
    {PASCAL_TEX1_SECTOR_QUERIES, pascal_tex1_sector_queries_enc_str_1, 0x5, 0xffff, 0x70, PM_UNIT_TEX_M, 5},
    {PASCAL_TEX0_MISSED_SECTORS, pascal_tex0_missed_sectors_enc_str_1, 0x4, 0xffff, 0x80, PM_UNIT_TEX_M, 5},
    {PASCAL_TEX1_MISSED_SECTORS, pascal_tex1_missed_sectors_enc_str_1, 0x4, 0xffff, 0x6c, PM_UNIT_TEX_M, 5},

    {PASCAL_TEX0_MISSED_SECTORS_ANY, pascal_tex0_missed_sectors_any_enc_str_1, 0x4, 0xaaaa, 0x85, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_MISSED_SECTORS_ANY, pascal_tex1_missed_sectors_any_enc_str_1, 0x4, 0xaaaa, 0x71, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_COALESCED_SECTORS, pascal_tex0_coalesced_sectors_enc_str_1, 0x5, 0xffff, 0x80, PM_UNIT_TEX_M, 4},
    {PASCAL_TEX1_COALESCED_SECTORS, pascal_tex1_coalesced_sectors_enc_str_1, 0x5, 0xffff, 0x6c, PM_UNIT_TEX_M, 4},

    {PASCAL_TEX0_CACHED_GLOBAL_LD_REQUESTS, pascal_tex0_cached_global_ld_requests_enc_str_1, 0x40, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_CACHED_GLOBAL_LD_REQUESTS, pascal_tex1_cached_global_ld_requests_enc_str_1, 0x40, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_GLOBAL_LD_REQUESTS, pascal_tex0_global_ld_requests_enc_str_1, 0x40, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_GLOBAL_LD_REQUESTS, pascal_tex1_global_ld_requests_enc_str_1, 0x40, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_UNCACHED_GLOBAL_LD_REQUESTS, pascal_tex0_uncached_global_ld_requests_enc_str_1, 0x40, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_UNCACHED_GLOBAL_LD_REQUESTS, pascal_tex1_uncached_global_ld_requests_enc_str_1, 0x40, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},

    {PASCAL_TEX0_LOCAL_LD_REQUESTS, pascal_tex0_local_ld_requests_enc_str_1, 0x43, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_LOCAL_LD_REQUESTS, pascal_tex1_local_ld_requests_enc_str_1, 0x43, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_CACHED_LOCAL_LD_REQUESTS, pascal_tex0_cached_local_ld_requests_enc_str_1, 0x43, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_CACHED_LOCAL_LD_REQUESTS, pascal_tex1_cached_local_ld_requests_enc_str_1, 0x43, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_UNCACHED_LOCAL_LD_REQUESTS, pascal_tex0_uncached_local_ld_requests_enc_str_1, 0x43, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_UNCACHED_LOCAL_LD_REQUESTS, pascal_tex1_uncached_local_ld_requests_enc_str_1, 0x43, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},

    {PASCAL_TEX0_CACHED_GLOBAL_LD_HITS, pascal_tex0_cached_global_ld_hits_enc_str_1, 0x12, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_CACHED_GLOBAL_LD_HITS, pascal_tex1_cached_global_ld_hits_enc_str_1, 0x12, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_CACHED_GLOBAL_LD_MISSES, pascal_tex0_cached_global_ld_misses_enc_str_1, 0x12, 0xffff, 0x84, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_CACHED_GLOBAL_LD_MISSES, pascal_tex1_cached_global_ld_misses_enc_str_1, 0x12, 0xffff, 0x70, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {PASCAL_TEX0_UNCACHED_GLOBAL_LD_MISSES, pascal_tex0_uncached_global_ld_misses_enc_str_1, 0x16, 0xffff, 0x84, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_UNCACHED_GLOBAL_LD_MISSES, pascal_tex1_uncached_global_ld_misses_enc_str_1, 0x16, 0xffff, 0x70, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {PASCAL_TEX0_GLOBAL_LD_HITS, pascal_tex0_global_ld_hits_enc_str_1, 0x11, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_GLOBAL_LD_HITS, pascal_tex1_global_ld_hits_enc_str_1, 0x11, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_GLOBAL_LD_MISSES, pascal_tex0_global_ld_misses_enc_str_1, 0x11, 0xffff, 0x84, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_GLOBAL_LD_MISSES, pascal_tex1_global_ld_misses_enc_str_1, 0x11, 0xffff, 0x70, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {PASCAL_TEX0_LOCAL_LD_HITS, pascal_tex0_local_ld_hits_enc_str_1, 0x13, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_LOCAL_LD_HITS, pascal_tex1_local_ld_hits_enc_str_1, 0x13, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_LOCAL_LD_MISSES, pascal_tex0_local_ld_misses_enc_str_1, 0x13, 0xffff, 0x84, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_LOCAL_LD_MISSES, pascal_tex1_local_ld_misses_enc_str_1, 0x13, 0xffff, 0x70, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {PASCAL_TEX0_NUM_32_BIT_T_16, pascal_tex0_num_32_bit_t_16_enc_str_1, 0x16, 0xffff, 0x88, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_NUM_64_BIT_T_16, pascal_tex0_num_64_bit_t_16_enc_str_1, 0x16, 0xffff, 0x89, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_NUM_128_BIT_T_16, pascal_tex0_num_128_bit_t_16_enc_str_1, 0x16, 0xffff, 0x8a, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_NUM_32_BIT_T_16, pascal_tex1_num_32_bit_t_16_enc_str_1, 0x16, 0xffff, 0x74, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_NUM_64_BIT_T_16, pascal_tex1_num_64_bit_t_16_enc_str_1, 0x16, 0xffff, 0x75, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_NUM_128_BIT_T_16, pascal_tex1_num_128_bit_t_16_enc_str_1, 0x16, 0xffff, 0x76, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
/*
From Will Kohut:
I found that the following PM always seems to be 0:
tex2pm_gpc_t_global_cctl_invalidates (this may also apply to the local PM flavor as well)

Seema and I looked at the waves, and it appears that its 0 because the CCTL we use is an IVALL, which doesnt return a hits value (ie: no tag comparison is done, we just go ahead and invalidate everything).  Without a hits value, this PM will never toggle.

The PM spreadsheet defines these two PMs (ie: both global and local versions) as follows:
how many sector hits for the request.
Note,  cache invalidate request is considered as a hit
*/
    //{PASCAL_TEX0_GLOBAL_CCTL_INVALIDATES, "__tex0_global_cctl_invalidates", 0x1d, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    //{PASCAL_TEX1_GLOBAL_CCTL_INVALIDATES, "__tex1_global_cctl_invalidates", 0x1d, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_GLOBAL_LD_SET_CONFLICTS, pascal_tex0_global_ld_set_conflicts_enc_str_1, 0x6, 0xaaaa, 0x86, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_GLOBAL_LD_SET_CONFLICTS, pascal_tex1_global_ld_set_conflicts_enc_str_1, 0x6, 0xaaaa, 0x72, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_CACHED_GLOBAL_LD_SET_CONFLICTS, pascal_tex0_cached_global_ld_set_conflicts_enc_str_1, 0x7, 0xaaaa, 0x86, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_CACHED_GLOBAL_LD_SET_CONFLICTS, pascal_tex1_cached_global_ld_set_conflicts_enc_str_1, 0x7, 0xaaaa, 0x72, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_UNCACHED_GLOBAL_LD_SET_CONFLICTS, pascal_tex0_uncached_global_ld_set_conflicts_enc_str_1, 0x7, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_UNCACHED_GLOBAL_LD_SET_CONFLICTS, pascal_tex1_uncached_global_ld_set_conflicts_enc_str_1, 0x7, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},

    {PASCAL_TEX0_UNCACHED_GLOBAL_LD_COALESCING, pascal_tex0_uncached_global_ld_coalescing_enc_str_1, 0x16, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_UNCACHED_GLOBAL_LD_COALESCING, pascal_tex1_uncached_global_ld_coalescing_enc_str_1, 0x16, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_GLOBAL_LD_COALESCING, pascal_tex0_global_ld_coalescing_enc_str_1, 0x15, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_GLOBAL_LD_COALESCING, pascal_tex1_global_ld_coalescing_enc_str_1, 0x15, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {PASCAL_TEX0_CACHED_LOCAL_LD_HITS, pascal_tex0_cached_local_ld_hits_enc_str_1, 0x14, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_CACHED_LOCAL_LD_HITS, pascal_tex1_cached_local_ld_hits_enc_str_1, 0x14, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_CACHED_LOCAL_LD_MISSES, pascal_tex0_cached_local_ld_misses_enc_str_1, 0x14, 0xffff, 0x84, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_CACHED_LOCAL_LD_MISSES, pascal_tex1_cached_local_ld_misses_enc_str_1, 0x14, 0xffff, 0x70, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_UNCACHED_LOCAL_LD_MISSES, pascal_tex0_uncached_local_ld_misses_enc_str_1, 0x18, 0xffff, 0x84, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_UNCACHED_LOCAL_LD_MISSES, pascal_tex1_uncached_local_ld_misses_enc_str_1, 0x18, 0xffff, 0x70, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {PASCAL_TEX0_CACHED_GLOBAL_LD_SET_ACCESS, pascal_tex0_cached_global_ld_set_access_enc_str_1, 0x7, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_CACHED_GLOBAL_LD_SET_ACCESS, pascal_tex1_cached_global_ld_set_access_enc_str_1, 0x7, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_GLOBAL_LD_SET_ACCESS, pascal_tex0_global_ld_set_access_enc_str_1, 0x6, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_GLOBAL_LD_SET_ACCESS, pascal_tex1_global_ld_set_access_enc_str_1, 0x6, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_UNCACHED_GLOBAL_LD_SET_ACCESS, pascal_tex0_uncached_global_ld_set_access_enc_str_1, 0x7, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_UNCACHED_GLOBAL_LD_SET_ACCESS, pascal_tex1_uncached_global_ld_set_access_enc_str_1, 0x7, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},

    {PASCAL_TEX0_CACHED_LOCAL_LD_SET_ACCESS, pascal_tex0_cached_local_ld_set_access_enc_str_1, 0xb, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_CACHED_LOCAL_LD_SET_ACCESS, pascal_tex1_cached_local_ld_set_access_enc_str_1, 0xb, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_LOCAL_LD_SET_ACCESS, pascal_tex0_local_ld_set_access_enc_str_1, 0xa, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_LOCAL_LD_SET_ACCESS, pascal_tex1_local_ld_set_access_enc_str_1, 0xa, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_UNCACHED_LOCAL_LD_SET_ACCESS, pascal_tex0_uncached_local_ld_set_access_enc_str_1, 0xb, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_UNCACHED_LOCAL_LD_SET_ACCESS, pascal_tex1_uncached_local_ld_set_access_enc_str_1, 0xb, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},

    //{PASCAL_TEX0_LOCAL_CCTL_INVALIDATES, "__tex0_local_cctl_invalidates", 0x1d, 0xffff, 0x84, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    //{PASCAL_TEX1_LOCAL_CCTL_INVALIDATES, "__tex1_local_cctl_invalidates", 0x1d, 0xffff, 0x70, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {PASCAL_TEX0_CACHED_LOCAL_LD_SET_CONFLICTS, pascal_tex0_cached_local_ld_set_conflicts_enc_str_1, 0xb, 0xaaaa, 0x86, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_CACHED_LOCAL_LD_SET_CONFLICTS, pascal_tex1_cached_local_ld_set_conflicts_enc_str_1, 0xb, 0xaaaa, 0x72, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},

    {PASCAL_TEX0_LOCAL_LD_SET_CONFLICTS, pascal_tex0_local_ld_set_conflicts_enc_str_1, 0xa, 0xaaaa, 0x83, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_LOCAL_LD_SET_CONFLICTS, pascal_tex1_local_ld_set_conflicts_enc_str_1, 0xa, 0xaaaa, 0x6f, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},

    {PASCAL_TEX0_UNCACHED_LOCAL_LD_SET_CONFLICTS, pascal_tex0_uncached_local_ld_set_conflicts_enc_str_1, 0xb, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_UNCACHED_LOCAL_LD_SET_CONFLICTS, pascal_tex1_uncached_local_ld_set_conflicts_enc_str_1, 0xb, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},

    {PASCAL_TEX0_LOCAL_LD_COALESCING, pascal_tex0_local_ld_coalescing_enc_str_1, 0x17, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_LOCAL_LD_COALESCING, pascal_tex1_local_ld_coalescing_enc_str_1, 0x17, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {PASCAL_TEX0_UNCACHED_LOCAL_LD_COALESCING, pascal_tex0_uncached_local_ld_coalescing_enc_str_1, 0x18, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_UNCACHED_LOCAL_LD_COALESCING, pascal_tex1_uncached_local_ld_coalescing_enc_str_1, 0x18, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {PASCAL_TEX0_GLOBAL_ST_REQUESTS, pascal_tex0_global_st_requests_enc_str_1, 0x41, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_GLOBAL_ST_REQUESTS, pascal_tex1_global_st_requests_enc_str_1, 0x41, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_LOCAL_ST_REQUESTS, pascal_tex0_local_st_requests_enc_str_1, 0x44, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_LOCAL_ST_REQUESTS, pascal_tex1_local_st_requests_enc_str_1, 0x44, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},

    {PASCAL_TEX0_GLOBAL_ST_SET_ACCESS, pascal_tex0_global_st_set_access_enc_str_1, 0x6, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_GLOBAL_ST_SET_ACCESS, pascal_tex1_global_st_set_access_enc_str_1, 0x6, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_LOCAL_ST_SET_ACCESS, pascal_tex0_local_st_set_access_enc_str_1, 0xc, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_LOCAL_ST_SET_ACCESS, pascal_tex1_local_st_set_access_enc_str_1, 0xc, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},

    {PASCAL_TEX0_GLOBAL_ST_SET_CONFLICTS, pascal_tex0_global_st_set_conflicts_enc_str_1, 0x6, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_GLOBAL_ST_SET_CONFLICTS, pascal_tex1_global_st_set_conflicts_enc_str_1, 0x6, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_LOCAL_ST_SET_CONFLICTS, pascal_tex0_local_st_set_conflicts_enc_str_1, 0xc, 0xaaaa, 0x86, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_LOCAL_ST_SET_CONFLICTS, pascal_tex1_local_st_set_conflicts_enc_str_1, 0xc, 0xaaaa, 0x72, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},

    {PASCAL_TEX0_CACHED_GLOBAL_LD_DATA_CONFLICTS, pascal_tex0_cached_global_ld_data_conflicts_enc_str_1, 0x15, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX0_CACHED_LOCAL_LD_DATA_CONFLICTS, pascal_tex0_cached_local_ld_data_conflicts_enc_str_1, 0x18, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX0_GLOBAL_ATOM_CAS_DATA_CONFLICTS, pascal_tex0_global_atom_cas_data_conflicts_enc_str_1, 0x16, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX0_GLOBAL_ATOM_DATA_CONFLICTS, pascal_tex0_global_atom_data_conflicts_enc_str_1, 0x16, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX0_GLOBAL_LD_DATA_CONFLICTS, pascal_tex0_global_ld_data_conflicts_enc_str_1, 0x14, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX0_LOCAL_LD_DATA_CONFLICTS, pascal_tex0_local_ld_data_conflicts_enc_str_1, 0x17, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX0_SURFACE_ATOM_CAS_DATA_CONFLICTS, pascal_tex0_surface_atom_cas_data_conflicts_enc_str_1, 0x1a, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX0_SURFACE_ATOM_DATA_CONFLICTS, pascal_tex0_surface_atom_data_conflicts_enc_str_1, 0x1a, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX0_SURFACE_LD_DATA_CONFLICTS, pascal_tex0_surface_ld_data_conflicts_enc_str_1, 0x19, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX0_UNCACHED_GLOBAL_LD_DATA_CONFLICTS, pascal_tex0_uncached_global_ld_data_conflicts_enc_str_1, 0x15, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX0_UNCACHED_LOCAL_LD_DATA_CONFLICTS, pascal_tex0_uncached_local_ld_data_conflicts_enc_str_1, 0x18, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_CACHED_GLOBAL_LD_DATA_CONFLICTS, pascal_tex1_cached_global_ld_data_conflicts_enc_str_1, 0x15, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_CACHED_LOCAL_LD_DATA_CONFLICTS, pascal_tex1_cached_local_ld_data_conflicts_enc_str_1, 0x18, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_GLOBAL_ATOM_CAS_DATA_CONFLICTS, pascal_tex1_global_atom_cas_data_conflicts_enc_str_1, 0x16, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_GLOBAL_ATOM_DATA_CONFLICTS, pascal_tex1_global_atom_data_conflicts_enc_str_1, 0x16, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_GLOBAL_LD_DATA_CONFLICTS, pascal_tex1_global_ld_data_conflicts_enc_str_1, 0x14, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_LOCAL_LD_DATA_CONFLICTS, pascal_tex1_local_ld_data_conflicts_enc_str_1, 0x17, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_SURFACE_ATOM_CAS_DATA_CONFLICTS, pascal_tex1_surface_atom_cas_data_conflicts_enc_str_1, 0x1a, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_SURFACE_ATOM_DATA_CONFLICTS, pascal_tex1_surface_atom_data_conflicts_enc_str_1, 0x1a, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_SURFACE_LD_DATA_CONFLICTS, pascal_tex1_surface_ld_data_conflicts_enc_str_1, 0x19, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_UNCACHED_GLOBAL_LD_DATA_CONFLICTS, pascal_tex1_uncached_global_ld_data_conflicts_enc_str_1, 0x15, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_UNCACHED_LOCAL_LD_DATA_CONFLICTS, pascal_tex1_uncached_local_ld_data_conflicts_enc_str_1, 0x18, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX0_CACHED_GLOBAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex0_cached_global_ld_row_column_conflicts_enc_str_1, 0x1c, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX0_CACHED_LOCAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex0_cached_local_ld_row_column_conflicts_enc_str_1, 0x1f, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX0_GLOBAL_ATOM_CAS_ROW_COLUMN_CONFLICTS, pascal_tex0_global_atom_cas_row_column_conflicts_enc_str_1, 0x1d, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX0_GLOBAL_ATOM_ROW_COLUMN_CONFLICTS, pascal_tex0_global_atom_row_column_conflicts_enc_str_1, 0x1d, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX0_GLOBAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex0_global_ld_row_column_conflicts_enc_str_1, 0x1b, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX0_LOCAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex0_local_ld_row_column_conflicts_enc_str_1, 0x1e, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX0_SURFACE_ATOM_CAS_ROW_COLUMN_CONFLICTS, pascal_tex0_surface_atom_cas_row_column_conflicts_enc_str_1, 0x21, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX0_SURFACE_ATOM_ROW_COLUMN_CONFLICTS, pascal_tex0_surface_atom_row_column_conflicts_enc_str_1, 0x21, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX0_SURFACE_LD_ROW_COLUMN_CONFLICTS, pascal_tex0_surface_ld_row_column_conflicts_enc_str_1, 0x20, 0xaaaa, 0xa0, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX0_UNCACHED_GLOBAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex0_uncached_global_ld_row_column_conflicts_enc_str_1, 0x1c, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX0_UNCACHED_LOCAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex0_uncached_local_ld_row_column_conflicts_enc_str_1, 0x1f, 0xaaaa, 0xa1, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_CACHED_GLOBAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex1_cached_global_ld_row_column_conflicts_enc_str_1, 0x1c, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_CACHED_LOCAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex1_cached_local_ld_row_column_conflicts_enc_str_1, 0x1f, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_GLOBAL_ATOM_CAS_ROW_COLUMN_CONFLICTS, pascal_tex1_global_atom_cas_row_column_conflicts_enc_str_1, 0x1d, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_GLOBAL_ATOM_ROW_COLUMN_CONFLICTS, pascal_tex1_global_atom_row_column_conflicts_enc_str_1, 0x1d, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_GLOBAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex1_global_ld_row_column_conflicts_enc_str_1, 0x1b, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_LOCAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex1_local_ld_row_column_conflicts_enc_str_1, 0x1e, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_SURFACE_ATOM_CAS_ROW_COLUMN_CONFLICTS, pascal_tex1_surface_atom_cas_row_column_conflicts_enc_str_1, 0x21, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_SURFACE_ATOM_ROW_COLUMN_CONFLICTS, pascal_tex1_surface_atom_row_column_conflicts_enc_str_1, 0x21, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_SURFACE_LD_ROW_COLUMN_CONFLICTS, pascal_tex1_surface_ld_row_column_conflicts_enc_str_1, 0x20, 0xaaaa, 0x97, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_UNCACHED_GLOBAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex1_uncached_global_ld_row_column_conflicts_enc_str_1, 0x1c, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_UNCACHED_LOCAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex1_uncached_local_ld_row_column_conflicts_enc_str_1, 0x1f, 0xaaaa, 0x98, PM_UNIT_TEX_D, 1},

    {PASCAL_TEX0_GLOBAL_ATOM_REQUESTS, pascal_tex0_global_atom_requests_enc_str_1, 0x42, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_GLOBAL_ATOM_REQUESTS, pascal_tex1_global_atom_requests_enc_str_1, 0x42, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_GLOBAL_ATOM_SET_ACCESS, pascal_tex0_global_atom_set_access_enc_str_1, 0x9, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_GLOBAL_ATOM_SET_ACCESS, pascal_tex1_global_atom_set_access_enc_str_1, 0x9, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_GLOBAL_ATOM_SET_CONFLICTS, pascal_tex0_global_atom_set_conflicts_enc_str_1, 0x9, 0xaaaa, 0x86, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_GLOBAL_ATOM_SET_CONFLICTS, pascal_tex1_global_atom_set_conflicts_enc_str_1, 0x9, 0xaaaa, 0x72, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_GLOBAL_ATOM_CAS_REQUESTS, pascal_tex0_global_atom_cas_requests_enc_str_1, 0x42, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_GLOBAL_ATOM_CAS_REQUESTS, pascal_tex1_global_atom_cas_requests_enc_str_1, 0x42, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_GLOBAL_ATOM_CAS_SET_ACCESS, pascal_tex0_global_atom_cas_set_access_enc_str_1, 0x9, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_GLOBAL_ATOM_CAS_SET_ACCESS, pascal_tex1_global_atom_cas_set_access_enc_str_1, 0x9, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_GLOBAL_ATOM_CAS_SET_CONFLICTS, pascal_tex0_global_atom_cas_set_conflicts_enc_str_1, 0x9, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_GLOBAL_ATOM_CAS_SET_CONFLICTS, pascal_tex1_global_atom_cas_set_conflicts_enc_str_1, 0x9, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_GLOBAL_RED_REQUESTS, pascal_tex0_global_red_requests_enc_str_1, 0x42, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_GLOBAL_RED_REQUESTS, pascal_tex1_global_red_requests_enc_str_1, 0x42, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_GLOBAL_RED_SET_ACCESS, pascal_tex0_global_red_set_access_enc_str_1, 0x8, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_GLOBAL_RED_SET_ACCESS, pascal_tex1_global_red_set_access_enc_str_1, 0x8, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_GLOBAL_RED_SET_CONFLICTS, pascal_tex0_global_red_set_conflicts_enc_str_1, 0x8, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_GLOBAL_RED_SET_CONFLICTS, pascal_tex1_global_red_set_conflicts_enc_str_1, 0x8, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_SURFACE_LD_SET_ACCESS, pascal_tex0_surface_ld_set_access_enc_str_1, 0x29, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_SURFACE_LD_SET_ACCESS, pascal_tex1_surface_ld_set_access_enc_str_1, 0x29, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_SURFACE_LD_SET_CONFLICTS, pascal_tex0_surface_ld_set_conflicts_enc_str_1, 0xd, 0xaaaa, 0x86, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_SURFACE_LD_SET_CONFLICTS, pascal_tex1_surface_ld_set_conflicts_enc_str_1, 0xd, 0xaaaa, 0x72, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_SURFACE_ST_SET_ACCESS, pascal_tex0_surface_st_set_access_enc_str_1, 0xd, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_SURFACE_ST_SET_ACCESS, pascal_tex1_surface_st_set_access_enc_str_1, 0xd, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_SURFACE_ST_SET_CONFLICTS, pascal_tex0_surface_st_set_conflicts_enc_str_1, 0xd, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_SURFACE_ST_SET_CONFLICTS, pascal_tex1_surface_st_set_conflicts_enc_str_1, 0xd, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_SURFACE_RED_SET_ACCESS, pascal_tex0_surface_red_set_access_enc_str_1, 0xe, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_SURFACE_RED_SET_ACCESS, pascal_tex1_surface_red_set_access_enc_str_1, 0xe, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_SURFACE_RED_SET_CONFLICTS, pascal_tex0_surface_red_set_conflicts_enc_str_1, 0xe, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_SURFACE_RED_SET_CONFLICTS, pascal_tex1_surface_red_set_conflicts_enc_str_1, 0xe, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_SURFACE_ATOM_SET_ACCESS, pascal_tex0_surface_atom_set_access_enc_str_1, 0xf, 0xffff, 0x80, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_SURFACE_ATOM_SET_ACCESS, pascal_tex1_surface_atom_set_access_enc_str_1, 0xf, 0xffff, 0x6c, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_SURFACE_ATOM_CAS_SET_ACCESS, pascal_tex0_surface_atom_cas_set_access_enc_str_1, 0xf, 0xffff, 0x83, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_SURFACE_ATOM_CAS_SET_ACCESS, pascal_tex1_surface_atom_cas_set_access_enc_str_1, 0xf, 0xffff, 0x6f, PM_UNIT_TEX_T3, 3, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_SURFACE_ATOM_SET_CONFLICTS, pascal_tex0_surface_atom_set_conflicts_enc_str_1, 0xf, 0xaaaa, 0x86, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_SURFACE_ATOM_SET_CONFLICTS, pascal_tex1_surface_atom_set_conflicts_enc_str_1, 0xf, 0xaaaa, 0x72, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_SURFACE_ATOM_CAS_SET_CONFLICTS, pascal_tex0_surface_atom_cas_set_conflicts_enc_str_1, 0xf, 0xaaaa, 0x87, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_SURFACE_ATOM_CAS_SET_CONFLICTS, pascal_tex1_surface_atom_cas_set_conflicts_enc_str_1, 0xf, 0xaaaa, 0x73, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_SURFACE_LD_REQUESTS, pascal_tex0_surface_ld_requests_enc_str_1, 0x45, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_SURFACE_LD_REQUESTS, pascal_tex1_surface_ld_requests_enc_str_1, 0x45, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_SURFACE_ST_REQUESTS, pascal_tex0_surface_st_requests_enc_str_1, 0x45, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_SURFACE_ST_REQUESTS, pascal_tex1_surface_st_requests_enc_str_1, 0x45, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_SURFACE_RED_REQUESTS, pascal_tex0_surface_red_requests_enc_str_1, 0x46, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_SURFACE_RED_REQUESTS, pascal_tex1_surface_red_requests_enc_str_1, 0x46, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_SURFACE_ATOM_REQUESTS, pascal_tex0_surface_atom_requests_enc_str_1, 0x46, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_SURFACE_ATOM_REQUESTS, pascal_tex1_surface_atom_requests_enc_str_1, 0x46, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_SURFACE_ATOM_CAS_REQUESTS, pascal_tex0_surface_atom_cas_requests_enc_str_1, 0x46, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_SURFACE_ATOM_CAS_REQUESTS, pascal_tex1_surface_atom_cas_requests_enc_str_1, 0x46, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},

    {PASCAL_TEX0_GLOBAL_ATOM_ADDRESS_CONFLICTS, pascal_tex0_global_atom_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x80, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_GLOBAL_ATOM_CAS_ADDRESS_CONFLICTS, pascal_tex0_global_atom_cas_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x81, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_GLOBAL_RED_ADDRESS_CONFLICTS, pascal_tex0_global_red_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x82, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_SURFACE_ATOM_ADDRESS_CONFLICTS, pascal_tex0_surface_atom_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x83, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_SURFACE_ATOM_CAS_ADDRESS_CONFLICTS, pascal_tex0_surface_atom_cas_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x84, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_SURFACE_RED_ADDRESS_CONFLICTS, pascal_tex0_surface_red_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x85, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_GLOBAL_ATOM_ADDRESS_CONFLICTS, pascal_tex1_global_atom_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x6c, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_GLOBAL_ATOM_CAS_ADDRESS_CONFLICTS, pascal_tex1_global_atom_cas_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x6d, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_GLOBAL_RED_ADDRESS_CONFLICTS, pascal_tex1_global_red_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x6e, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_SURFACE_ATOM_ADDRESS_CONFLICTS, pascal_tex1_surface_atom_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x6f, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_SURFACE_ATOM_CAS_ADDRESS_CONFLICTS, pascal_tex1_surface_atom_cas_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x70, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_SURFACE_RED_ADDRESS_CONFLICTS, pascal_tex1_surface_red_address_conflicts_enc_str_1, 0x10, 0xaaaa, 0x71, PM_UNIT_TEX_T3, 1, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_GLOBAL_ST_HITS_IN_WARP, pascal_tex0_global_st_hits_in_warp_enc_str_1, 0x1a, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_LOCAL_ST_HITS_IN_WARP, pascal_tex0_local_st_hits_in_warp_enc_str_1, 0x1b, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_SURFACE_ST_HITS_IN_WARP, pascal_tex0_surface_st_hits_in_warp_enc_str_1, 0x1c, 0xffff, 0x80, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_GLOBAL_ST_HITS_IN_WARP, pascal_tex1_global_st_hits_in_warp_enc_str_1, 0x1a, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_LOCAL_ST_HITS_IN_WARP, pascal_tex1_local_st_hits_in_warp_enc_str_1, 0x1b, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_SURFACE_ST_HITS_IN_WARP, pascal_tex1_surface_st_hits_in_warp_enc_str_1, 0x1c, 0xffff, 0x6c, PM_UNIT_TEX_T3, 4, 23, PM_UNIT_TEX_M},

    {PASCAL_TEX0_SURFACE_LD_MISSES, pascal_tex0_surface_ld_misses_enc_str_1, 0x19, 0xffff, 0x85, PM_UNIT_TEX_T3, 5, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX1_SURFACE_LD_MISSES, pascal_tex1_surface_ld_misses_enc_str_1, 0x19, 0xffff, 0x71, PM_UNIT_TEX_T3, 5, 23, PM_UNIT_TEX_M},
    {PASCAL_TEX0_INPUT_ST_SECTOR_SUM, pascal_tex0_input_st_sector_sum_enc_str_1, 0x1e, 0xffff, 0x82, PM_UNIT_TEX_M, 3},
    {PASCAL_TEX1_INPUT_ST_SECTOR_SUM, pascal_tex1_input_st_sector_sum_enc_str_1, 0x1e, 0xffff, 0x6e, PM_UNIT_TEX_M, 3},
    {PASCAL_TEX0_INPUT_WR_SECTOR_SUM, pascal_tex0_input_wr_sector_sum_enc_str_1, 0x1e, 0xffff, 0x85, PM_UNIT_TEX_M, 3},
    {PASCAL_TEX1_INPUT_WR_SECTOR_SUM, pascal_tex1_input_wr_sector_sum_enc_str_1, 0x1e, 0xffff, 0x71, PM_UNIT_TEX_M, 3},

    {PASCAL_TEX0_OUTPUT_ST_SECTOR_SUM, pascal_tex0_output_st_sector_sum_enc_str_1, 0x35, 0xffff, 0x80, PM_UNIT_TEX_M, 3},
    {PASCAL_TEX1_OUTPUT_ST_SECTOR_SUM, pascal_tex1_output_st_sector_sum_enc_str_1, 0x35, 0xffff, 0x6c, PM_UNIT_TEX_M, 3},
    {PASCAL_TEX0_OUTPUT_WR_SECTOR_SUM, pascal_tex0_output_wr_sector_sum_enc_str_1, 0x35, 0xffff, 0x80, PM_UNIT_TEX_M, 3},
    {PASCAL_TEX1_OUTPUT_WR_SECTOR_SUM, pascal_tex1_output_wr_sector_sum_enc_str_1, 0x35, 0xffff, 0x6c, PM_UNIT_TEX_M, 3},
    {PASCAL_TEX0_MISSES_LG_ST, pascal_tex0_misses_lg_st_enc_str_1, 0x35, 0xffff, 0x83, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_MISSES_LG_ST, pascal_tex1_misses_lg_st_enc_str_1, 0x35, 0xffff, 0x6f, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_OUTPUT_GLOBAL, pascal_tex0_output_global_enc_str_1, 0x35, 0xffff, 0x84, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_OUTPUT_GLOBAL, pascal_tex1_output_global_enc_str_1, 0x35, 0xffff, 0x70, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_OUTPUT_LOCAL, pascal_tex0_output_local_enc_str_1, 0x35, 0xffff, 0x85, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_OUTPUT_LOCAL, pascal_tex1_output_local_enc_str_1, 0x35, 0xffff, 0x71, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_OUTPUT_ATOM, pascal_tex0_output_atom_enc_str_1, 0x35, 0xffff, 0x86, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_OUTPUT_ATOM, pascal_tex1_output_atom_enc_str_1, 0x35, 0xffff, 0x72, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_OUTPUT_ATOM_CAS, pascal_tex0_output_atom_cas_enc_str_1, 0x35, 0xffff, 0x87, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_OUTPUT_ATOM_CAS, pascal_tex1_output_atom_cas_enc_str_1, 0x35, 0xffff, 0x73, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_OUTPUT_RED, pascal_tex0_output_red_enc_str_1, 0x35, 0xffff, 0x88, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_OUTPUT_RED, pascal_tex1_output_red_enc_str_1, 0x35, 0xffff, 0x74, PM_UNIT_TEX_M, 1},

    {PASCAL_TEX0_OUTPUT_WR_SECTOR_SUM_GRP20, pascal_tex0_output_wr_sector_sum_grp20_enc_str_1, 0x20, 0xffff, 0x83, PM_UNIT_TEX_M, 3},
    {PASCAL_TEX1_OUTPUT_WR_SECTOR_SUM_GRP20, pascal_tex1_output_wr_sector_sum_grp20_enc_str_1, 0x20, 0xffff, 0x6f, PM_UNIT_TEX_M, 3},
    {PASCAL_TEX0_OUTPUT_GLOBAL_GRP20, pascal_tex0_output_global_grp20_enc_str_1, 0x20, 0xffff, 0x86, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_OUTPUT_GLOBAL_GRP20, pascal_tex1_output_global_grp20_enc_str_1, 0x20, 0xffff, 0x72, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_OUTPUT_LOCAL_GRP20, pascal_tex0_output_local_grp20_enc_str_1, 0x20, 0xffff, 0x87, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_OUTPUT_LOCAL_GRP20, pascal_tex1_output_local_grp20_enc_str_1, 0x20, 0xffff, 0x73, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_OUTPUT_SUST_GRP20, pascal_tex0_output_sust_grp20_enc_str_1, 0x20, 0xffff, 0x88, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_OUTPUT_SUST_GRP20, pascal_tex1_output_sust_grp20_enc_str_1, 0x20, 0xffff, 0x74, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_OUTPUT_RED_GRP20, pascal_tex0_output_red_grp20_enc_str_1, 0x20, 0xffff, 0x8a, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_OUTPUT_RED_GRP20, pascal_tex1_output_red_grp20_enc_str_1, 0x20, 0xffff, 0x76, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_OUTPUT_ATOM_OR_ATOM_CAS, pascal_tex0_output_atom_or_atom_cas_enc_str_1, 0x20, 0xffff, 0x89, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_OUTPUT_ATOM_OR_ATOM_CAS, pascal_tex1_output_atom_or_atom_cas_enc_str_1, 0x20, 0xffff, 0x75, PM_UNIT_TEX_M, 1},

    {PASCAL_TEX0_TEX2SM_TEX_PRDY, pascal_tex0_tex2sm_tex_prdy_enc_str_1, 0x3, 0xaaaa, 0xa3, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_TEX2SM_TEX_PRDY, pascal_tex1_tex2sm_tex_prdy_enc_str_1, 0x3, 0xaaaa, 0x9a, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX0_TEX2SM_TEX_PVLD, pascal_tex0_tex2sm_tex_pvld_enc_str_1, 0x3, 0xaaaa, 0xa2, PM_UNIT_TEX_D, 1},
    {PASCAL_TEX1_TEX2SM_TEX_PVLD, pascal_tex1_tex2sm_tex_pvld_enc_str_1, 0x3, 0xaaaa, 0x99, PM_UNIT_TEX_D, 1},

    {PASCAL_TEX0_M2_SECTOR_MISSES_READ_SUM_27, pascal_tex0_m2_sector_misses_read_sum_27_enc_str_1, 0x27, 0xffff, 0x80, PM_UNIT_TEX_M, 3},
    {PASCAL_TEX1_M2_SECTOR_MISSES_READ_SUM_27, pascal_tex1_m2_sector_misses_read_sum_27_enc_str_1, 0x27, 0xffff, 0x6c, PM_UNIT_TEX_M, 3},
    {PASCAL_TEX0_M2_MISSES_GLOBAL_27, pascal_tex0_m2_misses_global_27_enc_str_1, 0x27, 0xaaaa, 0x83, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_M2_MISSES_GLOBAL_2d, pascal_tex0_m2_misses_global_2d_enc_str_1, 0x2d, 0xaaaa, 0x83, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_M2_MISSES_GLOBAL_27, pascal_tex1_m2_misses_global_27_enc_str_1, 0x27, 0xaaaa, 0x6f, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_M2_MISSES_GLOBAL_2d, pascal_tex1_m2_misses_global_2d_enc_str_1, 0x2d, 0xaaaa, 0x6f, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_M2_MISSES_LOCAL_27, pascal_tex0_m2_misses_local_27_enc_str_1, 0x27, 0xaaaa, 0x84, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_M2_MISSES_LOCAL_27, pascal_tex1_m2_misses_local_27_enc_str_1, 0x27, 0xaaaa, 0x70, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_M2_MISSES_LOCAL_2d, pascal_tex0_m2_misses_local_2d_enc_str_1, 0x2d, 0xaaaa, 0x84, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_M2_MISSES_LOCAL_2d, pascal_tex1_m2_misses_local_2d_enc_str_1, 0x2d, 0xaaaa, 0x70, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_M2_MISSES_LG_LD_27, pascal_tex0_m2_misses_lg_ld_27_enc_str_1, 0x27, 0xaaaa, 0x85, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_M2_MISSES_LG_LD_27, pascal_tex1_m2_misses_lg_ld_27_enc_str_1, 0x27, 0xaaaa, 0x71, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_M2_MISSES_LG_ATOM_27, pascal_tex0_m2_misses_lg_atom_27_enc_str_1, 0x27, 0xaaaa, 0x86, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_M2_MISSES_LG_ATOM_2d, pascal_tex0_m2_misses_lg_atom_2d_enc_str_1, 0x2d, 0xaaaa, 0x86, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_M2_MISSES_LG_ATOM_CAS_27, pascal_tex0_m2_misses_lg_atom_cas_27_enc_str_1, 0x27, 0xaaaa, 0x87, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_M2_MISSES_LG_ATOM_CAS_2d, pascal_tex0_m2_misses_lg_atom_cas_2d_enc_str_1, 0x2d, 0xaaaa, 0x87, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_M2_MISSES_LG_ATOM_27, pascal_tex1_m2_misses_lg_atom_27_enc_str_1, 0x27, 0xaaaa, 0x72, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_M2_MISSES_LG_ATOM_2d, pascal_tex1_m2_misses_lg_atom_2d_enc_str_1, 0x2d, 0xaaaa, 0x72, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_M2_MISSES_LG_ATOM_CAS_27, pascal_tex1_m2_misses_lg_atom_cas_27_enc_str_1, 0x27, 0xaaaa, 0x73, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_M2_MISSES_LG_ATOM_CAS_2d, pascal_tex1_m2_misses_lg_atom_cas_2d_enc_str_1, 0x2d, 0xaaaa, 0x73, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_M2_MISSES_LG_ST_2d, pascal_tex0_m2_misses_lg_st_2d_enc_str_1, 0x2d, 0xaaaa, 0x85, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_M2_MISSES_LG_ST_2d, pascal_tex1_m2_misses_lg_st_2d_enc_str_1, 0x2d, 0xaaaa, 0x71, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_M2_SECTOR_MISSES_WRITE_SUM_2d, pascal_tex0_m2_sector_misses_write_sum_2d_enc_str_1, 0x2d, 0xffff, 0x80, PM_UNIT_TEX_M, 3},
    {PASCAL_TEX1_M2_SECTOR_MISSES_WRITE_SUM_2d, pascal_tex1_m2_sector_misses_write_sum_2d_enc_str_1, 0x2d, 0xffff, 0x6c, PM_UNIT_TEX_M, 3},
    {PASCAL_TEX0_M2_MISSES_LG_RED_2d, pascal_tex0_m2_misses_lg_red_2d_enc_str_1, 0x2d, 0xaaaa, 0x88, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_M2_MISSES_LG_RED_2d, pascal_tex1_m2_misses_lg_red_2d_enc_str_1, 0x2d, 0xaaaa, 0x74, PM_UNIT_TEX_M, 1},

    {PASCAL_TEX0_OUTPUT_RD_SECTOR_SUM, pascal_tex0_output_rd_sector_sum_enc_str_1, 0x2F, 0xffff, 0x80, PM_UNIT_TEX_M, 3},
    {PASCAL_TEX1_OUTPUT_RD_SECTOR_SUM, pascal_tex1_output_rd_sector_sum_enc_str_1, 0x2F, 0xffff, 0x6c, PM_UNIT_TEX_M, 3},
    {PASCAL_TEX0_OUTPUT_LG_LD, pascal_tex0_output_lg_ld_enc_str_1, 0x2F, 0xaaaa, 0x83, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_OUTPUT_LG_LD, pascal_tex1_output_lg_ld_enc_str_1, 0x2F, 0xaaaa, 0x6f, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_OUTPUT_GLOBAL_GRP_2F, pascal_tex0_output_global_grp_2f_enc_str_1, 0x2F, 0xaaaa, 0x84, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_OUTPUT_GLOBAL_GRP_2F, pascal_tex1_output_global_grp_2f_enc_str_1, 0x2F, 0xaaaa, 0x70, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_OUTPUT_LOCAL_GRP_2F, pascal_tex0_output_local_grp_2f_enc_str_1, 0x2F, 0xaaaa, 0x85, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_OUTPUT_LOCAL_GRP_2F, pascal_tex1_output_local_grp_2f_enc_str_1, 0x2F, 0xaaaa, 0x71, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_OUTPUT_LG_ATOM, pascal_tex0_output_lg_atom_enc_str_1, 0x2F, 0xaaaa, 0x86, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_OUTPUT_LG_ATOM, pascal_tex1_output_lg_atom_enc_str_1, 0x2F, 0xaaaa, 0x72, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX0_OUTPUT_LG_ATOM_CAS, pascal_tex0_output_lg_atom_cas_enc_str_1, 0x2F, 0xaaaa, 0x87, PM_UNIT_TEX_M, 1},
    {PASCAL_TEX1_OUTPUT_LG_ATOM_CAS, pascal_tex1_output_lg_atom_cas_enc_str_1, 0x2F, 0xaaaa, 0x73, PM_UNIT_TEX_M, 1},

    {PASCAL_TEX0_GLOBAL_LD_REQUESTS_4B, pascal_tex0_global_ld_requests_4b_enc_str_1, 0x4b, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_GLOBAL_LD_REQUESTS_4B, pascal_tex1_global_ld_requests_4b_enc_str_1, 0x4b, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_8_BIT_4B, pascal_tex0_num_8_bit_4b_enc_str_1, 0x4b, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_8_BIT_4B, pascal_tex1_num_8_bit_4b_enc_str_1, 0x4b, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_16_BIT_4B, pascal_tex0_num_16_bit_4b_enc_str_1, 0x4b, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_16_BIT_4B, pascal_tex1_num_16_bit_4b_enc_str_1, 0x4b, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_FP16X2_4B, pascal_tex0_num_fp16x2_4b_enc_str_1, 0x4b, 0xaaaa, 0x8e, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_FP16X2_4B, pascal_tex1_num_fp16x2_4b_enc_str_1, 0x4b, 0xaaaa, 0x94, PM_UNIT_TEX_S, 1},

    {PASCAL_TEX0_GLOBAL_LD_REQUESTS_4C, pascal_tex0_global_ld_requests_4c_enc_str_1, 0x4c, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_GLOBAL_LD_REQUESTS_4C, pascal_tex1_global_ld_requests_4c_enc_str_1, 0x4c, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_32_BIT_4C, pascal_tex0_num_32_bit_4c_enc_str_1, 0x4c, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_32_BIT_4C, pascal_tex1_num_32_bit_4c_enc_str_1, 0x4c, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_64_BIT_4C, pascal_tex0_num_64_bit_4c_enc_str_1, 0x4c, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_64_BIT_4C, pascal_tex1_num_64_bit_4c_enc_str_1, 0x4c, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_128_BIT_4C, pascal_tex0_num_128_bit_4c_enc_str_1, 0x4c, 0xaaaa, 0x8e, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_128_BIT_4C, pascal_tex1_num_128_bit_4c_enc_str_1, 0x4c, 0xaaaa, 0x94, PM_UNIT_TEX_S, 1},

    {PASCAL_TEX0_GLOBAL_ST_REQUESTS_51, pascal_tex0_global_st_requests_51_enc_str_1, 0x51, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_GLOBAL_ST_REQUESTS_51, pascal_tex1_global_st_requests_51_enc_str_1, 0x51, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_8_BIT_51, pascal_tex0_num_8_bit_51_enc_str_1, 0x51, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_8_BIT_51, pascal_tex1_num_8_bit_51_enc_str_1, 0x51, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_16_BIT_51, pascal_tex0_num_16_bit_51_enc_str_1, 0x51, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_16_BIT_51, pascal_tex1_num_16_bit_51_enc_str_1, 0x51, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_FP16X2_51, pascal_tex0_num_fp16x2_51_enc_str_1, 0x51, 0xaaaa, 0x8e, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_FP16X2_51, pascal_tex1_num_fp16x2_51_enc_str_1, 0x51, 0xaaaa, 0x94, PM_UNIT_TEX_S, 1},

    {PASCAL_TEX0_GLOBAL_ST_REQUESTS_52, pascal_tex0_global_st_requests_52_enc_str_1, 0x52, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_GLOBAL_ST_REQUESTS_52, pascal_tex1_global_st_requests_52_enc_str_1, 0x52, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_32_BIT_52, pascal_tex0_num_32_bit_52_enc_str_1, 0x52, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_32_BIT_52, pascal_tex1_num_32_bit_52_enc_str_1, 0x52, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_64_BIT_52, pascal_tex0_num_64_bit_52_enc_str_1, 0x52, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_64_BIT_52, pascal_tex1_num_64_bit_52_enc_str_1, 0x52, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_128_BIT_52, pascal_tex0_num_128_bit_52_enc_str_1, 0x52, 0xaaaa, 0x8e, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_128_BIT_52, pascal_tex1_num_128_bit_52_enc_str_1, 0x52, 0xaaaa, 0x94, PM_UNIT_TEX_S, 1},

    {PASCAL_TEX0_GLOBAL_ATOM_REQUESTS_59, pascal_tex0_global_atom_requests_59_enc_str_1, 0x59, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_GLOBAL_ATOM_REQUESTS_59, pascal_tex1_global_atom_requests_59_enc_str_1, 0x59, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_8_BIT_59, pascal_tex0_num_8_bit_59_enc_str_1, 0x59, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_8_BIT_59, pascal_tex1_num_8_bit_59_enc_str_1, 0x59, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_16_BIT_59, pascal_tex0_num_16_bit_59_enc_str_1, 0x59, 0xaaaa, 0x8e, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_16_BIT_59, pascal_tex1_num_16_bit_59_enc_str_1, 0x59, 0xaaaa, 0x94, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_FP16X2_59, pascal_tex0_num_fp16x2_59_enc_str_1, 0x59, 0xaaaa, 0x8f, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_FP16X2_59, pascal_tex1_num_fp16x2_59_enc_str_1, 0x59, 0xaaaa, 0x95, PM_UNIT_TEX_S, 1},

    {PASCAL_TEX0_GLOBAL_ATOM_REQUESTS_5A, pascal_tex0_global_atom_requests_5a_enc_str_1, 0x5a, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_GLOBAL_ATOM_REQUESTS_5A, pascal_tex1_global_atom_requests_5a_enc_str_1, 0x5a, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_32_BIT_5A, pascal_tex0_num_32_bit_5a_enc_str_1, 0x5a, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_32_BIT_5A, pascal_tex1_num_32_bit_5a_enc_str_1, 0x5a, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_64_BIT_5A, pascal_tex0_num_64_bit_5a_enc_str_1, 0x5a, 0xaaaa, 0x8e, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_64_BIT_5A, pascal_tex1_num_64_bit_5a_enc_str_1, 0x5a, 0xaaaa, 0x94, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_128_BIT_5A, pascal_tex0_num_128_bit_5a_enc_str_1, 0x5a, 0xaaaa, 0x8f, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_128_BIT_5A, pascal_tex1_num_128_bit_5a_enc_str_1, 0x5a, 0xaaaa, 0x95, PM_UNIT_TEX_S, 1},

    {PASCAL_TEX0_GLOBAL_ATOM_FP16X2_REQUESTS_5B, pascal_tex0_global_atom_fp16x2_requests_5b_enc_str_1, 0x5b, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_GLOBAL_ATOM_FP16X2_REQUESTS_5B, pascal_tex1_global_atom_fp16x2_requests_5b_enc_str_1, 0x5b, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_8_BIT_5B, pascal_tex0_num_8_bit_5b_enc_str_1, 0x5b, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_8_BIT_5B, pascal_tex1_num_8_bit_5b_enc_str_1, 0x5b, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_16_BIT_5B, pascal_tex0_num_16_bit_5b_enc_str_1, 0x5b, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_16_BIT_5B, pascal_tex1_num_16_bit_5b_enc_str_1, 0x5b, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_FP16X2_5B, pascal_tex0_num_fp16x2_5b_enc_str_1, 0x5b, 0xaaaa, 0x8e, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_FP16X2_5B, pascal_tex1_num_fp16x2_5b_enc_str_1, 0x5b, 0xaaaa, 0x94, PM_UNIT_TEX_S, 1},

    {PASCAL_TEX0_GLOBAL_ATOM_FP16X2_REQUESTS_5C, pascal_tex0_global_atom_fp16x2_requests_5c_enc_str_1, 0x5c, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_GLOBAL_ATOM_FP16X2_REQUESTS_5C, pascal_tex1_global_atom_fp16x2_requests_5c_enc_str_1, 0x5c, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_32_BIT_5C, pascal_tex0_num_32_bit_5c_enc_str_1, 0x5c, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_32_BIT_5C, pascal_tex1_num_32_bit_5c_enc_str_1, 0x5c, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_64_BIT_5C, pascal_tex0_num_64_bit_5c_enc_str_1, 0x5c, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_64_BIT_5C, pascal_tex1_num_64_bit_5c_enc_str_1, 0x5c, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_128_BIT_5C, pascal_tex0_num_128_bit_5c_enc_str_1, 0x5c, 0xaaaa, 0x8e, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_128_BIT_5C, pascal_tex1_num_128_bit_5c_enc_str_1, 0x5c, 0xaaaa, 0x94, PM_UNIT_TEX_S, 1},

    {PASCAL_TEX0_GLOBAL_ATOM_CAS_REQUESTS_5D, pascal_tex0_global_atom_cas_requests_5d_enc_str_1, 0x5d, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_GLOBAL_ATOM_CAS_REQUESTS_5D, pascal_tex1_global_atom_cas_requests_5d_enc_str_1, 0x5d, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_8_BIT_5D, pascal_tex0_num_8_bit_5d_enc_str_1, 0x5d, 0xaaaa, 0x8e, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_8_BIT_5D, pascal_tex1_num_8_bit_5d_enc_str_1, 0x5d, 0xaaaa, 0x94, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_16_BIT_5D, pascal_tex0_num_16_bit_5d_enc_str_1, 0x5d, 0xaaaa, 0x8f, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_16_BIT_5D, pascal_tex1_num_16_bit_5d_enc_str_1, 0x5d, 0xaaaa, 0x95, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_FP16X2_5D, pascal_tex0_num_fp16x2_5d_enc_str_1, 0x5d, 0xaaaa, 0x90, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_FP16X2_5D, pascal_tex1_num_fp16x2_5d_enc_str_1, 0x5d, 0xaaaa, 0x96, PM_UNIT_TEX_S, 1},

    {PASCAL_TEX0_GLOBAL_ATOM_CAS_REQUESTS_5E, pascal_tex0_global_atom_cas_requests_5e_enc_str_1, 0x5e, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_GLOBAL_ATOM_CAS_REQUESTS_5E, pascal_tex1_global_atom_cas_requests_5e_enc_str_1, 0x5e, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_32_BIT_5E, pascal_tex0_num_32_bit_5e_enc_str_1, 0x5e, 0xaaaa, 0x8e, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_32_BIT_5E, pascal_tex1_num_32_bit_5e_enc_str_1, 0x5e, 0xaaaa, 0x94, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_64_BIT_5E, pascal_tex0_num_64_bit_5e_enc_str_1, 0x5e, 0xaaaa, 0x8f, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_64_BIT_5E, pascal_tex1_num_64_bit_5e_enc_str_1, 0x5e, 0xaaaa, 0x95, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_128_BIT_5E, pascal_tex0_num_128_bit_5e_enc_str_1, 0x5e, 0xaaaa, 0x90, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_128_BIT_5E, pascal_tex1_num_128_bit_5e_enc_str_1, 0x5e, 0xaaaa, 0x96, PM_UNIT_TEX_S, 1},

    {PASCAL_TEX0_LOCAL_LD_REQUESTS_5F, pascal_tex0_local_ld_requests_5f_enc_str_1, 0x5f, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_LOCAL_LD_REQUESTS_5F, pascal_tex1_local_ld_requests_5f_enc_str_1, 0x5f, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_8_BIT_5F, pascal_tex0_num_8_bit_5f_enc_str_1, 0x5f, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_8_BIT_5F, pascal_tex1_num_8_bit_5f_enc_str_1, 0x5f, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_16_BIT_5F, pascal_tex0_num_16_bit_5f_enc_str_1, 0x5f, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_16_BIT_5F, pascal_tex1_num_16_bit_5f_enc_str_1, 0x5f, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_FP16X2_5F, pascal_tex0_num_fp16x2_5f_enc_str_1, 0x5f, 0xaaaa, 0x8e, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_FP16X2_5F, pascal_tex1_num_fp16x2_5f_enc_str_1, 0x5f, 0xaaaa, 0x94, PM_UNIT_TEX_S, 1},

    {PASCAL_TEX0_LOCAL_LD_REQUESTS_60, pascal_tex0_local_ld_requests_60_enc_str_1, 0x60, 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_LOCAL_LD_REQUESTS_60, pascal_tex1_local_ld_requests_60_enc_str_1, 0x60, 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_32_BIT_60, pascal_tex0_num_32_bit_60_enc_str_1, 0x60, 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_32_BIT_60, pascal_tex1_num_32_bit_60_enc_str_1, 0x60, 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_64_BIT_60, pascal_tex0_num_64_bit_60_enc_str_1, 0x60, 0xaaaa, 0x8d, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_64_BIT_60, pascal_tex1_num_64_bit_60_enc_str_1, 0x60, 0xaaaa, 0x93, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_NUM_128_BIT_60, pascal_tex0_num_128_bit_60_enc_str_1, 0x60, 0xaaaa, 0x8e, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_NUM_128_BIT_60, pascal_tex1_num_128_bit_60_enc_str_1, 0x60, 0xaaaa, 0x94, PM_UNIT_TEX_S, 1},

    {PASCAL_TEX0_SM2TEX_REQ_PVLD, pascal_tex0_sm2tex_req_pvld_enc_str_1, 0x24 , 0xaaaa, 0x8b, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_SM2TEX_REQ_PVLD, pascal_tex1_sm2tex_req_pvld_enc_str_1, 0x24 , 0xaaaa, 0x91, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_SM2TEX_REQ_PRDY, pascal_tex0_sm2tex_req_prdy_enc_str_1, 0x24 , 0xaaaa, 0x8c, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_SM2TEX_REQ_PRDY, pascal_tex1_sm2tex_req_prdy_enc_str_1, 0x24 , 0xaaaa, 0x92, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX0_C0_IS_TEX, pascal_tex0_c0_is_tex_enc_str_1, 0x24, 0xaaaa, 0x90, PM_UNIT_TEX_S, 1},
    {PASCAL_TEX1_C0_IS_TEX, pascal_tex1_c0_is_tex_enc_str_1, 0x24, 0xaaaa, 0x96, PM_UNIT_TEX_S, 1},

    {PASCAL_HWPM_INST_EXECUTED_FFMA_OPS_S0, pascal_hwpm_inst_executed_ffma_ops_s0_enc_str_1,        0x11, 0xaaaa, 0x16, PM_UNIT_SMQCTL, 1},
    {PASCAL_HWPM_INST_EXECUTED_FFMA_OPS_S1, pascal_hwpm_inst_executed_ffma_ops_s1_enc_str_1,        0x11, 0xaaaa, 0x26, PM_UNIT_SMQCTL, 1},
    {PASCAL_HWPM_INST_EXECUTED_FFMA_OPS_S2, pascal_hwpm_inst_executed_ffma_ops_s2_enc_str_1,        0x11, 0xaaaa, 0x36, PM_UNIT_SMQCTL, 1},
    {PASCAL_HWPM_INST_EXECUTED_FFMA_OPS_S3, pascal_hwpm_inst_executed_ffma_ops_s3_enc_str_1,        0x11, 0xaaaa, 0x46, PM_UNIT_SMQCTL, 1},
    {PASCAL_HWPM_INST_EXECUTED_OTHERFP_OPS_S0, pascal_hwpm_inst_executed_otherfp_ops_s0_enc_str_1,  0x11, 0xaaaa, 0x17, PM_UNIT_SMQCTL, 1},
    {PASCAL_HWPM_INST_EXECUTED_OTHERFP_OPS_S1, pascal_hwpm_inst_executed_otherfp_ops_s1_enc_str_1,  0x11, 0xaaaa, 0x27, PM_UNIT_SMQCTL, 1},
    {PASCAL_HWPM_INST_EXECUTED_OTHERFP_OPS_S2, pascal_hwpm_inst_executed_otherfp_ops_s2_enc_str_1,  0x11, 0xaaaa, 0x37, PM_UNIT_SMQCTL, 1},
    {PASCAL_HWPM_INST_EXECUTED_OTHERFP_OPS_S3, pascal_hwpm_inst_executed_otherfp_ops_s3_enc_str_1,  0x11, 0xaaaa, 0x47, PM_UNIT_SMQCTL, 1},

    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpm PerfSignalTableGP100_gpctpc_extended[] = {
    { PASCAL_ELAPSED_CYCLES_CORE_SM_PHYSICAL,            pascal_elapsed_cycles_core_sm_physical_enc_str_1,          0x00000000, 0x00000000, 0x00000000,    PM_UNIT_SMCORE,0 },
    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpm PerfSignalTableGP10X_gpctpc_extended[] = {
    { PASCAL_ELAPSED_CYCLES_SM,            pascal_elapsed_cycles_sm_enc_str_1,          0x00000000, 0x00000000, 0x00000000,    PM_UNIT_SMCORE,0 },
    { PASCAL_ELAPSED_CYCLES_SM_PM,            pascal_elapsed_cycles_sm_pm_enc_str_1,          0x00000000, 0x00000000, 0x00000000,    PM_UNIT_SMCORE,0 },
    { INVALID_PM_SIGNAL_NEW,                "",                         0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B) */

/*
Filter signals for HWPM
1.      scg_mode_compute
2.      scg_mode_graphics
3.      sm_in_trap
4.      sm_not_in_trap
*/

#if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
PerfSignalHwpmExpt_v1 PerfSignalTableGP100_gpctpc_expt[] = {
    { PASCAL_HWPM_ACTIVE_CYCLES_Q0_Q1,  pascal_hwpm_active_cycles_q0_q1_enc_str_1, INVALID_PM_SIGNAL_NEW,{ PASCAL_HWPM_ACTIVE_CYCLES_Q0, PASCAL_HWPM_ACTIVE_CYCLES_Q1, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE), HWPM_FILTER_SIGNAL_SM_IN_TRAP },
    { PASCAL_HWPM_ACTIVE_CYCLES_Q2_Q3,  pascal_hwpm_active_cycles_q2_q3_enc_str_1, INVALID_PM_SIGNAL_NEW,{ PASCAL_HWPM_ACTIVE_CYCLES_Q2, PASCAL_HWPM_ACTIVE_CYCLES_Q3, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW }, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE), HWPM_FILTER_SIGNAL_SM_IN_TRAP },
    { PASCAL_HWPM_UNIQUE_WARPS_LAUNCHED_Q0, pascal_hwpm_unique_warps_launched_q0_enc_str_1, INVALID_PM_SIGNAL_NEW,{PASCAL_HWPM_WARPS_LAUNCHED_0, PASCAL_HWPM_WARPS_RESTORED_0, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE)), INVALID_PM_SIGNAL_NEW, 0x02},
    { PASCAL_HWPM_UNIQUE_WARPS_LAUNCHED_Q1, pascal_hwpm_unique_warps_launched_q1_enc_str_1, INVALID_PM_SIGNAL_NEW,{PASCAL_HWPM_WARPS_LAUNCHED_1, PASCAL_HWPM_WARPS_RESTORED_1, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE)), INVALID_PM_SIGNAL_NEW, 0x02},
    { PASCAL_HWPM_UNIQUE_WARPS_LAUNCHED_Q2, pascal_hwpm_unique_warps_launched_q2_enc_str_1, INVALID_PM_SIGNAL_NEW,{PASCAL_HWPM_WARPS_LAUNCHED_2, PASCAL_HWPM_WARPS_RESTORED_2, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE)), INVALID_PM_SIGNAL_NEW, 0x02},
    { PASCAL_HWPM_UNIQUE_WARPS_LAUNCHED_Q3, pascal_hwpm_unique_warps_launched_q3_enc_str_1, INVALID_PM_SIGNAL_NEW,{PASCAL_HWPM_WARPS_LAUNCHED_3, PASCAL_HWPM_WARPS_RESTORED_3, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE)), INVALID_PM_SIGNAL_NEW, 0x02},

    { PASCAL_TEX0_RETURN_PACKET_COUNT,    pascal_tex0_return_packet_count_enc_str_1,   INVALID_PM_SIGNAL_NEW, {PASCAL_TEX0_TEX2SM_TEX_PRDY, PASCAL_TEX0_TEX2SM_TEX_PVLD, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_RETURN_PACKET_COUNT,    pascal_tex1_return_packet_count_enc_str_1,   INVALID_PM_SIGNAL_NEW, {PASCAL_TEX1_TEX2SM_TEX_PRDY, PASCAL_TEX1_TEX2SM_TEX_PVLD, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_TEX0_UNCACHED_GLOBAL_LD_MISSES_32, pascal_tex0_uncached_global_ld_misses_32_enc_str_1, PASCAL_TEX0_UNCACHED_GLOBAL_LD_MISSES, {PASCAL_TEX0_NUM_32_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX0_UNCACHED_GLOBAL_LD_MISSES_64, pascal_tex0_uncached_global_ld_misses_64_enc_str_1, PASCAL_TEX0_UNCACHED_GLOBAL_LD_MISSES, {PASCAL_TEX0_NUM_64_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX0_UNCACHED_GLOBAL_LD_MISSES_128, pascal_tex0_uncached_global_ld_misses_128_enc_str_1, PASCAL_TEX0_UNCACHED_GLOBAL_LD_MISSES, {PASCAL_TEX0_NUM_128_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_UNCACHED_GLOBAL_LD_MISSES_32, pascal_tex1_uncached_global_ld_misses_32_enc_str_1, PASCAL_TEX1_UNCACHED_GLOBAL_LD_MISSES, {PASCAL_TEX1_NUM_32_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_UNCACHED_GLOBAL_LD_MISSES_64, pascal_tex1_uncached_global_ld_misses_64_enc_str_1, PASCAL_TEX1_UNCACHED_GLOBAL_LD_MISSES, {PASCAL_TEX1_NUM_64_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_UNCACHED_GLOBAL_LD_MISSES_128, pascal_tex1_uncached_global_ld_misses_128_enc_str_1, PASCAL_TEX1_UNCACHED_GLOBAL_LD_MISSES, {PASCAL_TEX1_NUM_128_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_TEX0_UNCACHED_GLOBAL_LD_COALESCING_32, pascal_tex0_uncached_global_ld_coalescing_32_enc_str_1, PASCAL_TEX0_UNCACHED_GLOBAL_LD_COALESCING, {PASCAL_TEX0_NUM_32_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX0_UNCACHED_GLOBAL_LD_COALESCING_64, pascal_tex0_uncached_global_ld_coalescing_64_enc_str_1, PASCAL_TEX0_UNCACHED_GLOBAL_LD_COALESCING, {PASCAL_TEX0_NUM_64_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX0_UNCACHED_GLOBAL_LD_COALESCING_128, pascal_tex0_uncached_global_ld_coalescing_128_enc_str_1, PASCAL_TEX0_UNCACHED_GLOBAL_LD_COALESCING, {PASCAL_TEX0_NUM_128_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_UNCACHED_GLOBAL_LD_COALESCING_32, pascal_tex1_uncached_global_ld_coalescing_32_enc_str_1, PASCAL_TEX1_UNCACHED_GLOBAL_LD_COALESCING, {PASCAL_TEX1_NUM_32_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_UNCACHED_GLOBAL_LD_COALESCING_64, pascal_tex1_uncached_global_ld_coalescing_64_enc_str_1, PASCAL_TEX1_UNCACHED_GLOBAL_LD_COALESCING, {PASCAL_TEX1_NUM_64_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_UNCACHED_GLOBAL_LD_COALESCING_128, pascal_tex1_uncached_global_ld_coalescing_128_enc_str_1, PASCAL_TEX1_UNCACHED_GLOBAL_LD_COALESCING, {PASCAL_TEX1_NUM_128_BIT_T_16, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_TEX0_STORE_SECTOR_MISSES_GLOBAL,           pascal_tex0_store_sector_misses_global_enc_str_1, PASCAL_TEX0_OUTPUT_WR_SECTOR_SUM, {PASCAL_TEX0_OUTPUT_GLOBAL, PASCAL_TEX0_MISSES_LG_ST, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_STORE_SECTOR_MISSES_GLOBAL,           pascal_tex1_store_sector_misses_global_enc_str_1, PASCAL_TEX1_OUTPUT_WR_SECTOR_SUM, {PASCAL_TEX1_OUTPUT_GLOBAL, PASCAL_TEX1_MISSES_LG_ST, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX0_STORE_SECTOR_MISSES_LOCAL,            pascal_tex0_store_sector_misses_local_enc_str_1,  PASCAL_TEX0_OUTPUT_WR_SECTOR_SUM, {PASCAL_TEX0_OUTPUT_LOCAL, PASCAL_TEX0_MISSES_LG_ST, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_STORE_SECTOR_MISSES_LOCAL,            pascal_tex1_store_sector_misses_local_enc_str_1,  PASCAL_TEX1_OUTPUT_WR_SECTOR_SUM, {PASCAL_TEX1_OUTPUT_LOCAL, PASCAL_TEX1_MISSES_LG_ST, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX0_STORE_SECTOR_MISSES_RED,              pascal_tex0_store_sector_misses_red_enc_str_1, PASCAL_TEX0_OUTPUT_WR_SECTOR_SUM, {PASCAL_TEX0_OUTPUT_RED, PASCAL_TEX0_OUTPUT_LOCAL, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_STORE_SECTOR_MISSES_RED,              pascal_tex1_store_sector_misses_red_enc_str_1, PASCAL_TEX1_OUTPUT_WR_SECTOR_SUM, {PASCAL_TEX1_OUTPUT_RED, PASCAL_TEX1_OUTPUT_LOCAL, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_TEX0_STORE_SECTOR_MISSES_ATOM, pascal_tex0_store_sector_misses_atom_enc_str_1, PASCAL_TEX0_OUTPUT_WR_SECTOR_SUM, {PASCAL_TEX0_OUTPUT_ATOM, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_STORE_SECTOR_MISSES_ATOM, pascal_tex1_store_sector_misses_atom_enc_str_1, PASCAL_TEX1_OUTPUT_WR_SECTOR_SUM, {PASCAL_TEX1_OUTPUT_ATOM, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_TEX0_STORE_SECTOR_MISSES_ATOM_CAS, pascal_tex0_store_sector_misses_atom_cas_enc_str_1, PASCAL_TEX0_OUTPUT_WR_SECTOR_SUM, {PASCAL_TEX0_OUTPUT_ATOM_CAS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_STORE_SECTOR_MISSES_ATOM_CAS, pascal_tex1_store_sector_misses_atom_cas_enc_str_1, PASCAL_TEX1_OUTPUT_WR_SECTOR_SUM, {PASCAL_TEX1_OUTPUT_ATOM_CAS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_TEX0_STORE_SECTOR_MISSES_ATOM_OR_ATOM_CAS, pascal_tex0_store_sector_misses_atom_or_atom_cas_enc_str_1, PASCAL_TEX0_OUTPUT_WR_SECTOR_SUM_GRP20, {PASCAL_TEX0_OUTPUT_ATOM_OR_ATOM_CAS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_STORE_SECTOR_MISSES_ATOM_OR_ATOM_CAS, pascal_tex1_store_sector_misses_atom_or_atom_cas_enc_str_1, PASCAL_TEX1_OUTPUT_WR_SECTOR_SUM_GRP20, {PASCAL_TEX1_OUTPUT_ATOM_OR_ATOM_CAS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_TEX0_STORE_SECTOR_MISSES_SUST_NONATOM, pascal_tex0_store_sector_misses_sust_nonatom_enc_str_1,  PASCAL_TEX0_OUTPUT_WR_SECTOR_SUM_GRP20, {PASCAL_TEX0_OUTPUT_SUST_GRP20, PASCAL_TEX0_OUTPUT_ATOM_OR_ATOM_CAS, PASCAL_TEX0_OUTPUT_RED_GRP20, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_STORE_SECTOR_MISSES_SUST_NONATOM, pascal_tex1_store_sector_misses_sust_nonatom_enc_str_1,  PASCAL_TEX1_OUTPUT_WR_SECTOR_SUM_GRP20, {PASCAL_TEX1_OUTPUT_SUST_GRP20, PASCAL_TEX1_OUTPUT_ATOM_OR_ATOM_CAS, PASCAL_TEX1_OUTPUT_RED_GRP20, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX0_STORE_SECTOR_MISSES_SUST_ATOM_OR_ATOM_CAS, pascal_tex0_store_sector_misses_sust_atom_or_atom_cas_enc_str_1,  PASCAL_TEX0_OUTPUT_WR_SECTOR_SUM_GRP20, {PASCAL_TEX0_OUTPUT_SUST_GRP20, PASCAL_TEX0_OUTPUT_ATOM_OR_ATOM_CAS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_STORE_SECTOR_MISSES_SUST_ATOM_OR_ATOM_CAS, pascal_tex1_store_sector_misses_sust_atom_or_atom_cas_enc_str_1,  PASCAL_TEX1_OUTPUT_WR_SECTOR_SUM_GRP20, {PASCAL_TEX1_OUTPUT_SUST_GRP20, PASCAL_TEX1_OUTPUT_ATOM_OR_ATOM_CAS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX0_STORE_SECTOR_MISSES_SUST_RED, pascal_tex0_store_sector_misses_sust_red_enc_str_1,  PASCAL_TEX0_OUTPUT_WR_SECTOR_SUM_GRP20, {PASCAL_TEX0_OUTPUT_SUST_GRP20, PASCAL_TEX0_OUTPUT_RED_GRP20, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_STORE_SECTOR_MISSES_SUST_RED, pascal_tex1_store_sector_misses_sust_red_enc_str_1,  PASCAL_TEX1_OUTPUT_WR_SECTOR_SUM_GRP20, {PASCAL_TEX1_OUTPUT_SUST_GRP20, PASCAL_TEX1_OUTPUT_RED_GRP20, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_TEX0_WRITE_SECTORS_GLOBAL_NONATOM, pascal_tex0_write_sectors_global_nonatom_enc_str_1, PASCAL_TEX0_OUTPUT_WR_SECTOR_SUM_GRP20, {PASCAL_TEX0_OUTPUT_GLOBAL_GRP20, PASCAL_TEX0_OUTPUT_ATOM_OR_ATOM_CAS, PASCAL_TEX0_OUTPUT_RED_GRP20, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_WRITE_SECTORS_GLOBAL_NONATOM, pascal_tex1_write_sectors_global_nonatom_enc_str_1, PASCAL_TEX1_OUTPUT_WR_SECTOR_SUM_GRP20, {PASCAL_TEX1_OUTPUT_GLOBAL_GRP20, PASCAL_TEX1_OUTPUT_ATOM_OR_ATOM_CAS, PASCAL_TEX1_OUTPUT_RED_GRP20, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX0_WRITE_SECTORS_GLOBAL_ATOM, pascal_tex0_write_sectors_global_atom_enc_str_1, PASCAL_TEX0_OUTPUT_WR_SECTOR_SUM_GRP20, {PASCAL_TEX0_OUTPUT_GLOBAL_GRP20, PASCAL_TEX0_OUTPUT_ATOM_OR_ATOM_CAS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_WRITE_SECTORS_GLOBAL_ATOM, pascal_tex1_write_sectors_global_atom_enc_str_1, PASCAL_TEX1_OUTPUT_WR_SECTOR_SUM_GRP20, {PASCAL_TEX1_OUTPUT_GLOBAL_GRP20, PASCAL_TEX1_OUTPUT_ATOM_OR_ATOM_CAS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX0_WRITE_SECTORS_GLOBAL_RED, pascal_tex0_write_sectors_global_red_enc_str_1, PASCAL_TEX0_OUTPUT_WR_SECTOR_SUM_GRP20, {PASCAL_TEX0_OUTPUT_GLOBAL_GRP20, PASCAL_TEX0_OUTPUT_RED_GRP20, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_WRITE_SECTORS_GLOBAL_RED, pascal_tex1_write_sectors_global_red_enc_str_1, PASCAL_TEX1_OUTPUT_WR_SECTOR_SUM_GRP20, {PASCAL_TEX1_OUTPUT_GLOBAL_GRP20, PASCAL_TEX1_OUTPUT_RED_GRP20, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX0_WRITE_SECTORS_LOCAL_ST, pascal_tex0_write_sectors_local_st_enc_str_1, PASCAL_TEX0_OUTPUT_WR_SECTOR_SUM_GRP20, {PASCAL_TEX0_OUTPUT_LOCAL_GRP20, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_WRITE_SECTORS_LOCAL_ST, pascal_tex1_write_sectors_local_st_enc_str_1, PASCAL_TEX1_OUTPUT_WR_SECTOR_SUM_GRP20, {PASCAL_TEX1_OUTPUT_LOCAL_GRP20, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},

//Store sector queries - misses at m2
    { PASCAL_TEX0_STORE_SECTOR_QURIES_GLOBAL,   pascal_tex0_store_sector_queries_global_enc_str_1, PASCAL_TEX0_M2_SECTOR_MISSES_WRITE_SUM_2d, {PASCAL_TEX0_M2_MISSES_GLOBAL_2d, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_STORE_SECTOR_QURIES_GLOBAL,   pascal_tex1_store_sector_queries_global_enc_str_1, PASCAL_TEX1_M2_SECTOR_MISSES_WRITE_SUM_2d, {PASCAL_TEX1_M2_MISSES_GLOBAL_2d, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX0_STORE_SECTOR_QURIES_LOCAL,    pascal_tex0_store_sector_queries_local_enc_str_1,  PASCAL_TEX0_M2_SECTOR_MISSES_WRITE_SUM_2d, {PASCAL_TEX0_M2_MISSES_LOCAL_2d, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_STORE_SECTOR_QURIES_LOCAL,    pascal_tex1_store_sector_queries_local_enc_str_1,  PASCAL_TEX1_M2_SECTOR_MISSES_WRITE_SUM_2d, {PASCAL_TEX1_M2_MISSES_LOCAL_2d, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX0_STORE_SECTOR_QURIES_ATOM_CAS, pascal_tex0_store_sector_queries_atom_cas_enc_str_1, PASCAL_TEX0_M2_SECTOR_MISSES_WRITE_SUM_2d, {PASCAL_TEX0_M2_MISSES_LG_ATOM_CAS_2d, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_STORE_SECTOR_QURIES_ATOM_CAS, pascal_tex1_store_sector_queries_atom_cas_enc_str_1, PASCAL_TEX1_M2_SECTOR_MISSES_WRITE_SUM_2d, {PASCAL_TEX1_M2_MISSES_LG_ATOM_CAS_2d, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX0_STORE_SECTOR_QURIES_ATOM,     pascal_tex0_store_sector_queries_atom_enc_str_1, PASCAL_TEX0_M2_SECTOR_MISSES_WRITE_SUM_2d, {PASCAL_TEX0_M2_MISSES_LG_ATOM_2d, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_STORE_SECTOR_QURIES_ATOM,     pascal_tex1_store_sector_queries_atom_enc_str_1, PASCAL_TEX1_M2_SECTOR_MISSES_WRITE_SUM_2d, {PASCAL_TEX1_M2_MISSES_LG_ATOM_2d, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX0_STORE_SECTOR_QURIES_RED,     pascal_tex0_store_sector_queries_red_enc_str_1, PASCAL_TEX0_M2_SECTOR_MISSES_WRITE_SUM_2d, {PASCAL_TEX0_M2_MISSES_LG_RED_2d, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_STORE_SECTOR_QURIES_RED,     pascal_tex1_store_sector_queries_red_enc_str_1, PASCAL_TEX1_M2_SECTOR_MISSES_WRITE_SUM_2d, {PASCAL_TEX1_M2_MISSES_LG_RED_2d, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},

//Load sector queries - misses at m2.
    { PASCAL_TEX0_LOAD_SECTOR_QURIES_GLOBAL,   pascal_tex0_load_sector_queries_global_enc_str_1, PASCAL_TEX0_M2_SECTOR_MISSES_READ_SUM_27, {PASCAL_TEX0_M2_MISSES_GLOBAL_27, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_LOAD_SECTOR_QURIES_GLOBAL,   pascal_tex1_load_sector_queries_global_enc_str_1, PASCAL_TEX1_M2_SECTOR_MISSES_READ_SUM_27, {PASCAL_TEX1_M2_MISSES_GLOBAL_27, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX0_LOAD_SECTOR_QURIES_LOCAL,    pascal_tex0_load_sector_queries_local_enc_str_1,  PASCAL_TEX0_M2_SECTOR_MISSES_READ_SUM_27, {PASCAL_TEX0_M2_MISSES_LOCAL_27, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_LOAD_SECTOR_QURIES_LOCAL,    pascal_tex1_load_sector_queries_local_enc_str_1,  PASCAL_TEX1_M2_SECTOR_MISSES_READ_SUM_27, {PASCAL_TEX1_M2_MISSES_LOCAL_27, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX0_LOAD_SECTOR_QURIES_ATOM_CAS, pascal_tex0_load_sector_queries_atom_cas_enc_str_1, PASCAL_TEX0_M2_SECTOR_MISSES_READ_SUM_27, {PASCAL_TEX0_M2_MISSES_LG_ATOM_CAS_27, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_LOAD_SECTOR_QURIES_ATOM_CAS, pascal_tex1_load_sector_queries_atom_cas_enc_str_1, PASCAL_TEX1_M2_SECTOR_MISSES_READ_SUM_27, {PASCAL_TEX1_M2_MISSES_LG_ATOM_CAS_27, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX0_LOAD_SECTOR_QURIES_ATOM,     pascal_tex0_load_sector_queries_atom_enc_str_1, PASCAL_TEX0_M2_SECTOR_MISSES_READ_SUM_27, {PASCAL_TEX0_M2_MISSES_LG_ATOM_27, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_LOAD_SECTOR_QURIES_ATOM,     pascal_tex1_load_sector_queries_atom_enc_str_1, PASCAL_TEX1_M2_SECTOR_MISSES_READ_SUM_27, {PASCAL_TEX1_M2_MISSES_LG_ATOM_27, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},

    //HWPM sideband filtering does not increment the counter when the filter signal is high (truly using signal as filter) (The behaviour is exactly opposite to SMPC sideband filtering)
    { PASCAL_HWPM_INST_EXECUTED_TRAP,     pascal_hwpm_inst_executed_trap_enc_str_1, PASCAL_HWPM_INST_EXECUTED_S0, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0, HWPM_FILTER_SIGNAL_SM_NOT_IN_TRAP},
    { PASCAL_HWPM_INST_EXECUTED_NO_TRAP,  pascal_hwpm_inst_executed_no_trap_enc_str_1, PASCAL_HWPM_INST_EXECUTED_S0, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0, HWPM_FILTER_SIGNAL_SM_IN_TRAP},

    { PASCAL_HWPM_ACTIVE_CYCLES_TRAP,     pascal_hwpm_active_cycles_trap_enc_str_1, PASCAL_HWPM_ACTIVE_CYCLES, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0, HWPM_FILTER_SIGNAL_SM_NOT_IN_TRAP},
    { PASCAL_HWPM_ACTIVE_CYCLES_NO_TRAP,  pascal_hwpm_active_cycles_no_trap_enc_str_1, PASCAL_HWPM_ACTIVE_CYCLES, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0, HWPM_FILTER_SIGNAL_SM_IN_TRAP},

    { PASCAL_TEX0_LOAD_SECTOR_MISSES_GLOBAL,    pascal_tex0_load_sector_misses_global_enc_str_1, PASCAL_TEX0_OUTPUT_RD_SECTOR_SUM, {PASCAL_TEX0_OUTPUT_GLOBAL_GRP_2F, PASCAL_TEX0_OUTPUT_LG_LD, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_LOAD_SECTOR_MISSES_GLOBAL,    pascal_tex1_load_sector_misses_global_enc_str_1, PASCAL_TEX1_OUTPUT_RD_SECTOR_SUM, {PASCAL_TEX1_OUTPUT_GLOBAL_GRP_2F, PASCAL_TEX1_OUTPUT_LG_LD, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_TEX0_LOAD_SECTOR_MISSES_LOCAL,     pascal_tex0_load_sector_misses_local_enc_str_1, PASCAL_TEX0_OUTPUT_RD_SECTOR_SUM, {PASCAL_TEX0_OUTPUT_LOCAL_GRP_2F, PASCAL_TEX0_OUTPUT_LG_LD, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_LOAD_SECTOR_MISSES_LOCAL,     pascal_tex1_load_sector_misses_local_enc_str_1, PASCAL_TEX1_OUTPUT_RD_SECTOR_SUM, {PASCAL_TEX1_OUTPUT_LOCAL_GRP_2F, PASCAL_TEX1_OUTPUT_LG_LD, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_TEX0_LOAD_SECTOR_MISSES_ATOM,      pascal_tex0_load_sector_misses_atom_enc_str_1, PASCAL_TEX0_OUTPUT_RD_SECTOR_SUM, {PASCAL_TEX0_OUTPUT_LG_ATOM , INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_LOAD_SECTOR_MISSES_ATOM,      pascal_tex1_load_sector_misses_atom_enc_str_1, PASCAL_TEX1_OUTPUT_RD_SECTOR_SUM, {PASCAL_TEX1_OUTPUT_LG_ATOM, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_TEX0_LOAD_SECTOR_MISSES_ATOM_CAS,  pascal_tex0_load_sector_misses_atom_cas_enc_str_1, PASCAL_TEX0_OUTPUT_RD_SECTOR_SUM, {PASCAL_TEX0_OUTPUT_LG_ATOM_CAS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_LOAD_SECTOR_MISSES_ATOM_CAS,  pascal_tex1_load_sector_misses_atom_cas_enc_str_1, PASCAL_TEX1_OUTPUT_RD_SECTOR_SUM, {PASCAL_TEX1_OUTPUT_LG_ATOM_CAS, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_TEX0_TEX_QUAD_COUNT, pascal_tex0_tex_quad_count_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_TEX0_SM2TEX_REQ_PVLD, PASCAL_TEX0_SM2TEX_REQ_PRDY, PASCAL_TEX0_C0_IS_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_TEX_QUAD_COUNT, pascal_tex1_tex_quad_count_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_TEX1_SM2TEX_REQ_PVLD, PASCAL_TEX1_SM2TEX_REQ_PRDY, PASCAL_TEX1_C0_IS_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_TEX0_GLOBAL_LD_REQUESTS_8BIT , pascal_tex0_global_ld_requests_8bit_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_TEX0_GLOBAL_LD_REQUESTS_4B, PASCAL_TEX0_NUM_8_BIT_4B, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_GLOBAL_LD_REQUESTS_8BIT , pascal_tex1_global_ld_requests_8bit_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_TEX1_GLOBAL_LD_REQUESTS_4B, PASCAL_TEX1_NUM_8_BIT_4B, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX0_GLOBAL_LD_REQUESTS_16BIT , pascal_tex0_global_ld_requests_16bit_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_TEX0_GLOBAL_LD_REQUESTS_4B, PASCAL_TEX0_NUM_16_BIT_4B, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_GLOBAL_LD_REQUESTS_16BIT , pascal_tex1_global_ld_requests_16bit_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_TEX1_GLOBAL_LD_REQUESTS_4B, PASCAL_TEX1_NUM_16_BIT_4B, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX0_GLOBAL_LD_REQUESTS_FP16X2 , pascal_tex0_global_ld_requests_fp16x2_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_TEX0_GLOBAL_LD_REQUESTS_4B, PASCAL_TEX0_NUM_FP16X2_4B, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_GLOBAL_LD_REQUESTS_FP16X2 , pascal_tex1_global_ld_requests_fp16x2_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_TEX1_GLOBAL_LD_REQUESTS_4B, PASCAL_TEX1_NUM_FP16X2_4B, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX0_GLOBAL_LD_REQUESTS_32BIT , pascal_tex0_global_ld_requests_32bit_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_TEX0_GLOBAL_LD_REQUESTS_4C, PASCAL_TEX0_NUM_32_BIT_4C, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_GLOBAL_LD_REQUESTS_32BIT , pascal_tex1_global_ld_requests_32bit_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_TEX1_GLOBAL_LD_REQUESTS_4C, PASCAL_TEX1_NUM_32_BIT_4C, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX0_GLOBAL_LD_REQUESTS_64BIT , pascal_tex0_global_ld_requests_64bit_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_TEX0_GLOBAL_LD_REQUESTS_4C, PASCAL_TEX0_NUM_64_BIT_4C, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_GLOBAL_LD_REQUESTS_64BIT , pascal_tex1_global_ld_requests_64bit_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_TEX1_GLOBAL_LD_REQUESTS_4C, PASCAL_TEX1_NUM_64_BIT_4C, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX0_GLOBAL_LD_REQUESTS_128BIT , pascal_tex0_global_ld_requests_128bit_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_TEX0_GLOBAL_LD_REQUESTS_4C, PASCAL_TEX0_NUM_128_BIT_4C, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_TEX1_GLOBAL_LD_REQUESTS_128BIT , pascal_tex1_global_ld_requests_128bit_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_TEX1_GLOBAL_LD_REQUESTS_4C, PASCAL_TEX1_NUM_128_BIT_4C, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_HWPM_INST_EXECUTED_FP32_OPS_S0, pascal_hwpm_inst_executed_fp32_ops_s0_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_HWPM_INST_EXECUTED_FFMA_OPS_S0, PASCAL_HWPM_INST_EXECUTED_OTHERFP_OPS_S0, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE), HWPM_FILTER_SIGNAL_SM_IN_TRAP},
    { PASCAL_HWPM_INST_EXECUTED_FP32_OPS_S1, pascal_hwpm_inst_executed_fp32_ops_s1_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_HWPM_INST_EXECUTED_FFMA_OPS_S1, PASCAL_HWPM_INST_EXECUTED_OTHERFP_OPS_S1, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE), HWPM_FILTER_SIGNAL_SM_IN_TRAP},
    { PASCAL_HWPM_INST_EXECUTED_FP32_OPS_S2, pascal_hwpm_inst_executed_fp32_ops_s2_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_HWPM_INST_EXECUTED_FFMA_OPS_S2, PASCAL_HWPM_INST_EXECUTED_OTHERFP_OPS_S2, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE), HWPM_FILTER_SIGNAL_SM_IN_TRAP},
    { PASCAL_HWPM_INST_EXECUTED_FP32_OPS_S3, pascal_hwpm_inst_executed_fp32_ops_s3_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_HWPM_INST_EXECUTED_FFMA_OPS_S3, PASCAL_HWPM_INST_EXECUTED_OTHERFP_OPS_S3, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE), HWPM_FILTER_SIGNAL_SM_IN_TRAP},

    { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000,  INVALID_PM_SIGNAL_NEW},
};

//This is supported ONLY for SM virtualization for gp100. 
//Ideally this table could have been same for core as well as quad but for domain checks we need to categorize it separately for core or quad
PerfSignalHwpmVirtualExpt PerfSignalTableGP100_gpctpc_virtual_expt[] = {
    //Interleave the values of the two halves of the SM to support SM virtualization in gp100 
    { PASCAL_HWPM_ACTIVE_CYCLES_CORE_SM_VIRTUAL,  pascal_sm_active_cycles_enc_str_1, PERF_SIG_VALUES_INTERLEAVE, 2, { PASCAL_HWPM_ACTIVE_CYCLES_Q0_Q1, PASCAL_HWPM_ACTIVE_CYCLES_Q2_Q3 }},
    { PASCAL_HWPM_ELAPSED_CYCLES_CORE_SM_VIRTUAL, pascal_elapsed_cycles_sm_enc_str_1, PERF_SIG_VALUES_REPEAT, 2, { PASCAL_ELAPSED_CYCLES_CORE_SM_PHYSICAL, INVALID_PM_SIGNAL_NEW}},
    { INVALID_PM_SIGNAL_NEW,        "", PERF_SIG_VALUES_INVALID, 0,  { INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}},
};
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B) */

#if NVCFG(GLOBAL_GPU_FAMILY_GP10X)
PerfSignalHwpm PerfSignalTableGP100_fbp0[] = {
    //FBP signals
    { PASCAL_FB_SUBP0_DRAMC_READ,          pascal_fb_subp0_dramc_read_enc_str_1,            0x00000011, 0x0000AAAA,  0x00000020,   PM_UNIT_FB,1 },
    { PASCAL_FB_SUBP1_DRAMC_READ,          pascal_fb_subp1_dramc_read_enc_str_1,            0x00000012, 0x0000AAAA,  0x00000020,   PM_UNIT_FB,1 },
    { PASCAL_FB_SUBP0_DRAMC_WRITE,         pascal_fb_subp0_dramc_write_enc_str_1,           0x00000011, 0x0000AAAA,  0x00000021,   PM_UNIT_FB,1 },
    { PASCAL_FB_SUBP1_DRAMC_WRITE,         pascal_fb_subp1_dramc_write_enc_str_1,           0x00000012, 0x0000AAAA,  0x00000021,   PM_UNIT_FB,1 },

    { PASCAL_FB1_SUBP0_DRAMC_READ,         pascal_fb1_subp0_dramc_read_enc_str_1,           0x00000011, 0x0000AAAA,  0x0000002c,   PM_UNIT_FB,1 },
    { PASCAL_FB1_SUBP1_DRAMC_READ,         pascal_fb1_subp1_dramc_read_enc_str_1,           0x00000012, 0x0000AAAA,  0x0000002c,   PM_UNIT_FB,1 },
    { PASCAL_FB1_SUBP0_DRAMC_WRITE,        pascal_fb1_subp0_dramc_write_enc_str_1,          0x00000011, 0x0000AAAA,  0x0000002d,   PM_UNIT_FB,1 },
    { PASCAL_FB1_SUBP1_DRAMC_WRITE,        pascal_fb1_subp1_dramc_write_enc_str_1,          0x00000012, 0x0000AAAA,  0x0000002d,   PM_UNIT_FB,1 },

    // fb_dram_activates_subp0_fbp0_pa0       = fbpa02pm_subp0_actarb_activate      "Number of bank activates in subpartition-0"
    // fb_dram_activates_subp1_fbp0_pa0       = fbpa02pm_subp1_actarb_activate      "Number of bank activates in subpartition-1"
    { PASCAL_FB_SUBP0_DRAM_ACTIVATES,      pascal_fb_subp0_dram_activates_enc_str_1,             0x00000001, 0x0000AAAA,  0x00000026,   PM_UNIT_FB,1 },
    { PASCAL_FB_SUBP1_DRAM_ACTIVATES,      pascal_fb_subp1_dram_activates_enc_str_1,             0x00000002, 0x0000AAAA,  0x00000026,   PM_UNIT_FB,1 },
    { PASCAL_FB1_SUBP0_DRAM_ACTIVATES,     pascal_fb1_subp0_dram_activates_enc_str_1,            0x00000001, 0x0000AAAA,  0x00000032,   PM_UNIT_FB,1 },
    { PASCAL_FB1_SUBP1_DRAM_ACTIVATES,     pascal_fb1_subp1_dram_activates_enc_str_1,            0x00000002, 0x0000AAAA,  0x00000032,   PM_UNIT_FB,1 },

    { INVALID_PM_SIGNAL_NEW,        "",                                 0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpm PerfSignalTableGP10x_fbp0[] = {
    //FBP signals
    {PASCAL_FB_SUBP0_DRAMC_READ, pascal_fb_subp0_dramc_read_enc_str_1, 0x11, 0xaaaa, 0x20, PM_UNIT_FB, 1},
    {PASCAL_FB_SUBP1_DRAMC_READ, pascal_fb_subp1_dramc_read_enc_str_1, 0x11, 0xaaaa, 0x26, PM_UNIT_FB, 1},

    {PASCAL_FB_SUBP0_DRAMC_WRITE, pascal_fb_subp0_dramc_write_enc_str_1, 0x11, 0xaaaa, 0x21, PM_UNIT_FB, 1},
    {PASCAL_FB_SUBP1_DRAMC_WRITE, pascal_fb_subp1_dramc_write_enc_str_1, 0x11, 0xaaaa, 0x27, PM_UNIT_FB, 1},

    // fb_dram_activates_subp0_fbp0_pa0       = fbpa02pm_subp0_actarb_activate      "Number of bank activates in subpartition-0"
    // fb_dram_activates_subp1_fbp0_pa0       = fbpa02pm_subp1_actarb_activate      "Number of bank activates in subpartition-1"
    {PASCAL_FB_SUBP0_DRAM_ACTIVATES, pascal_fb_subp0_dram_activates_enc_str_1, 0x1, 0xaaaa, 0x26, PM_UNIT_FB, 1},
    {PASCAL_FB_SUBP1_DRAM_ACTIVATES, pascal_fb_subp1_dram_activates_enc_str_1, 0x1, 0xaaaa, 0x2b, PM_UNIT_FB, 1},

    { INVALID_PM_SIGNAL_NEW,        "",                                 0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) */

#if NVCFG(GLOBAL_GPU_FAMILY_GP10X)
//To match the output with pmlsplitter, use perfmon 0 for slice 0 and 2
PerfSignalHwpm PerfSignalTableGP100_ltc0[] = {
    //LTC signals
    // l2_subp0_write_sector_misses = ltc_ltc2fb_dirty_dat0_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 0
    // l2_subp1_write_sector_misses = ltc_ltc2fb_dirty_dat1_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 1
    // l2_subp0_read_sector_misses  = ltc_fb2ltc_rdat0_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 0
    // l2_subp1_read_sector_misses  = ltc_fb2ltc_rdat1_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 1
    // l2_subp0_write_l1_sector_queries = ltc2pm_ltc_lts0_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 0
    // l2_subp1_write_l1_sector_queries = ltc2pm_ltc_lts1_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 1
    // l2_subp0_read_l1_sector_queries  = ltc2pm_ltc_lts0_request_rd_op && ltc2pm_ltc_lts1_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 0
    // l2_subp1_read_l1_sector_queries  = ltc2pm_ltc_lts1_request_rd_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 1

{PASCAL_LTC0_REQUEST_SRC_UNIT_L1, pascal_ltc0_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x40, PM_UNIT_LTS2, 1},
{PASCAL_LTC1_REQUEST_SRC_UNIT_L1, pascal_ltc1_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x41, PM_UNIT_LTS2_1, 1},
{PASCAL_LTC0_REQUEST_SRC_UNIT_TEX, pascal_ltc0_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x40, PM_UNIT_LTS2, 1},
{PASCAL_LTC1_REQUEST_SRC_UNIT_TEX, pascal_ltc1_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x41, PM_UNIT_LTS2_1, 1},
{PASCAL_LTC0_REQUEST_SRC_UNIT_GCC, pascal_ltc0_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x40, PM_UNIT_LTS2, 1},
{PASCAL_LTC1_REQUEST_SRC_UNIT_GCC, pascal_ltc1_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x41, PM_UNIT_LTS2_1, 1},

{PASCAL_LTC0_WRITE_MISS_SECTORS, pascal_ltc0_write_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x28, PM_UNIT_LTS1, 1},
{PASCAL_LTC1_WRITE_MISS_SECTORS, pascal_ltc1_write_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x4, PM_UNIT_LTS1, 1},
{PASCAL_LTC0_READ_MISS_SECTORS, pascal_ltc0_read_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x29, PM_UNIT_LTS1, 1},
{PASCAL_LTC1_READ_MISS_SECTORS, pascal_ltc1_read_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x5, PM_UNIT_LTS1, 1},

{PASCAL_LTC0_HIT_SECTORS, pascal_ltc0_hit_sectors_enc_str_1, 0x1, 0xffff, 0x1c, PM_UNIT_LTS, 4},
{PASCAL_LTC1_HIT_SECTORS, pascal_ltc1_hit_sectors_enc_str_1, 0x1, 0xffff, 0x20, PM_UNIT_LTS_1, 4},
{PASCAL_LTC0_MISS_SECTORS, pascal_ltc0_miss_sectors_enc_str_1, 0x2, 0xffff, 0x1c, PM_UNIT_LTS, 4},
{PASCAL_LTC1_MISS_SECTORS, pascal_ltc1_miss_sectors_enc_str_1, 0x2, 0xffff, 0x20, PM_UNIT_LTS_1, 4},
{PASCAL_LTC0_REQUEST_SECTORS, pascal_ltc0_request_sectors_enc_str_1, 0x0, 0xffff, 0x1c, PM_UNIT_LTS, 4},
{PASCAL_LTC1_REQUEST_SECTORS, pascal_ltc1_request_sectors_enc_str_1, 0x0, 0xffff, 0x20, PM_UNIT_LTS_1, 4},

{PASCAL_LTC0_REQUEST_ACTIVE, pascal_ltc0_request_active_enc_str_1, 0x0, 0xaaaa, 0x25, PM_UNIT_LTS1, 1},
{PASCAL_LTC1_REQUEST_ACTIVE, pascal_ltc1_request_active_enc_str_1, 0x0, 0xaaaa, 0x1, PM_UNIT_LTS1_1, 1},

{PASCAL_LTC0_REQUEST_RD_OP, pascal_ltc0_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x3d, PM_UNIT_LTS1, 1},
{PASCAL_LTC1_REQUEST_RD_OP, pascal_ltc1_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x19, PM_UNIT_LTS1_1, 1},
{PASCAL_LTC0_REQUEST_WR_OP, pascal_ltc0_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x3c, PM_UNIT_LTS1, 1},
{PASCAL_LTC1_REQUEST_WR_OP, pascal_ltc1_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x18, PM_UNIT_LTS1_1, 1},
{PASCAL_LTC0_REQUEST_ATOMIC_OP, pascal_ltc0_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x3b, PM_UNIT_LTS1, 1},
{PASCAL_LTC1_REQUEST_ATOMIC_OP, pascal_ltc1_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x17, PM_UNIT_LTS1_1, 1},
{PASCAL_LTC0_REQUEST_APERTURE_SYSMEM, pascal_ltc0_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x37, PM_UNIT_LTS1, 1},
{PASCAL_LTC1_REQUEST_APERTURE_SYSMEM, pascal_ltc1_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x13, PM_UNIT_LTS1_1, 1},
{PASCAL_LTC0_REQUEST_APERTURE_VIDMEM, pascal_ltc0_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x36, PM_UNIT_LTS1, 1},
{PASCAL_LTC1_REQUEST_APERTURE_VIDMEM, pascal_ltc1_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x12, PM_UNIT_LTS1_1, 1},

{PASCAL_LTC0_HIT, pascal_ltc0_hit_enc_str_1, 0x0, 0xaaaa, 0x2c, PM_UNIT_LTS1, 1},
{PASCAL_LTC1_HIT, pascal_ltc1_hit_enc_str_1, 0x0, 0xaaaa, 0x8, PM_UNIT_LTS1_1, 1},

    { INVALID_PM_SIGNAL_NEW,        "",                                 0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) */

#if NVCFG(GLOBAL_GPU_FAMILY_GP10X)
//To match the output with pmlsplitter, use perfmon 0 for slice 0 and 2
PerfSignalHwpm PerfSignalTableGP10x_ltc0[] = {
    {PASCAL_LTC0_REQUEST_SRC_UNIT_L1, pascal_ltc0_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x8, PM_UNIT_LTS2, 1},
    {PASCAL_LTC1_REQUEST_SRC_UNIT_L1, pascal_ltc1_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x9, PM_UNIT_LTS2_1, 1},
    {PASCAL_LTC0_REQUEST_SRC_UNIT_TEX, pascal_ltc0_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x8, PM_UNIT_LTS2, 1},
    {PASCAL_LTC1_REQUEST_SRC_UNIT_TEX, pascal_ltc1_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x9, PM_UNIT_LTS2_1, 1},
    {PASCAL_LTC0_REQUEST_SRC_UNIT_GCC, pascal_ltc0_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x8, PM_UNIT_LTS2, 1},
    {PASCAL_LTC1_REQUEST_SRC_UNIT_GCC, pascal_ltc1_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x9, PM_UNIT_LTS2_1, 1},

    {PASCAL_LTC0_HIT_SECTORS, pascal_ltc0_hit_sectors_enc_str_1, 0x1, 0xffff, 0x0, PM_UNIT_LTS, 4},
    {PASCAL_LTC1_HIT_SECTORS, pascal_ltc1_hit_sectors_enc_str_1, 0x1, 0xffff, 0x4, PM_UNIT_LTS_1, 4},
    {PASCAL_LTC0_MISS_SECTORS, pascal_ltc0_miss_sectors_enc_str_1, 0x2, 0xffff, 0x0, PM_UNIT_LTS, 4},
    {PASCAL_LTC1_MISS_SECTORS, pascal_ltc1_miss_sectors_enc_str_1, 0x2, 0xffff, 0x4, PM_UNIT_LTS_1, 4},
    {PASCAL_LTC0_REQUEST_SECTORS, pascal_ltc0_request_sectors_enc_str_1, 0x0, 0xffff, 0x0, PM_UNIT_LTS, 4},
    {PASCAL_LTC1_REQUEST_SECTORS, pascal_ltc1_request_sectors_enc_str_1, 0x0, 0xffff, 0x4, PM_UNIT_LTS_1, 4},

    {PASCAL_LTC0_REQUEST_ACTIVE, pascal_ltc0_request_active_enc_str_1, 0x0, 0xaaaa, 0xb, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_REQUEST_ACTIVE, pascal_ltc1_request_active_enc_str_1, 0x0, 0xaaaa, 0x29, PM_UNIT_LTS1_1, 1},

    {PASCAL_LTC0_REQUEST_RD_OP, pascal_ltc0_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x23, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_REQUEST_RD_OP, pascal_ltc1_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x41, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_REQUEST_WR_OP, pascal_ltc0_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x22, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_REQUEST_WR_OP, pascal_ltc1_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x40, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_REQUEST_ATOMIC_OP, pascal_ltc0_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x21, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_REQUEST_ATOMIC_OP, pascal_ltc1_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x3f, PM_UNIT_LTS1_1, 1},

    {PASCAL_LTC0_REQUEST_APERTURE_SYSMEM, pascal_ltc0_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x1d, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_REQUEST_APERTURE_SYSMEM, pascal_ltc1_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x3b, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_REQUEST_APERTURE_VIDMEM, pascal_ltc0_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x1c, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_REQUEST_APERTURE_VIDMEM, pascal_ltc1_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x3a, PM_UNIT_LTS1_1, 1},

    {PASCAL_LTC0_HIT, pascal_ltc0_hit_enc_str_1, 0x0, 0xaaaa, 0x12, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_HIT, pascal_ltc1_hit_enc_str_1, 0x0, 0xaaaa, 0x30, PM_UNIT_LTS1_1, 1},

    {PASCAL_LTC0_REQUEST, pascal_ltc0_request_enc_str_1, 0x0, 0xaaaa, 0xa, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_REQUEST, pascal_ltc1_request_enc_str_1, 0x0, 0xaaaa, 0x28, PM_UNIT_LTS1_1, 1},

    {PASCAL_LTC0_WRITE_MISS_SECTORS, pascal_ltc0_write_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0xe, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_WRITE_MISS_SECTORS, pascal_ltc1_write_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x2c, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_READ_MISS_SECTORS, pascal_ltc0_read_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0xf, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_READ_MISS_SECTORS, pascal_ltc1_read_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x2d, PM_UNIT_LTS1_1, 1},

    { INVALID_PM_SIGNAL_NEW,        "",     0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};
#if defined(NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GP107) || defined(NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GP107)
//To match the output with pmlsplitter, use perfmon 0 for slice 0 and 2
PerfSignalHwpm PerfSignalTableGP107_ltc0[] = {
    {PASCAL_LTC0_REQUEST_SRC_UNIT_L1, pascal_ltc0_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x1e, PM_UNIT_LTS2, 1},
    {PASCAL_LTC0_REQUEST_SRC_UNIT_TEX, pascal_ltc0_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x1e, PM_UNIT_LTS2, 1},
    {PASCAL_LTC0_REQUEST_SRC_UNIT_GCC, pascal_ltc0_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x1e, PM_UNIT_LTS2, 1},
    {PASCAL_LTC1_REQUEST_SRC_UNIT_L1, pascal_ltc1_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x1f, PM_UNIT_LTS2_1, 1},
    {PASCAL_LTC1_REQUEST_SRC_UNIT_TEX, pascal_ltc1_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x1f, PM_UNIT_LTS2_1, 1},
    {PASCAL_LTC1_REQUEST_SRC_UNIT_GCC, pascal_ltc1_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x1f, PM_UNIT_LTS2_1, 1},

    {PASCAL_LTC0_HIT_SECTORS, pascal_ltc0_hit_sectors_enc_str_1, 0x1, 0xffff, 0x20, PM_UNIT_LTS, 4},
    {PASCAL_LTC1_HIT_SECTORS, pascal_ltc1_hit_sectors_enc_str_1, 0x1, 0xffff, 0x1a, PM_UNIT_LTS_1, 4},
    {PASCAL_LTC0_MISS_SECTORS, pascal_ltc0_miss_sectors_enc_str_1, 0x2, 0xffff, 0x20, PM_UNIT_LTS, 4},
    {PASCAL_LTC1_MISS_SECTORS, pascal_ltc1_miss_sectors_enc_str_1, 0x2, 0xffff, 0x1a, PM_UNIT_LTS_1, 4},

    {PASCAL_LTC0_REQUEST_SECTORS, pascal_ltc0_request_sectors_enc_str_1, 0x0, 0xffff, 0x20, PM_UNIT_LTS, 4},
    {PASCAL_LTC1_REQUEST_SECTORS, pascal_ltc1_request_sectors_enc_str_1, 0x0, 0xffff, 0x1a, PM_UNIT_LTS_1, 4},

    {PASCAL_LTC0_REQUEST_ACTIVE, pascal_ltc0_request_active_enc_str_1, 0x0, 0xaaaa, 0x25, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_REQUEST_ACTIVE, pascal_ltc1_request_active_enc_str_1, 0x0, 0xaaaa, 0x1, PM_UNIT_LTS1_1, 1},

    {PASCAL_LTC0_REQUEST_RD_OP, pascal_ltc0_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x39, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_REQUEST_RD_OP, pascal_ltc1_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x15, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_REQUEST_WR_OP, pascal_ltc0_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x38, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_REQUEST_WR_OP, pascal_ltc1_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x14, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_REQUEST_ATOMIC_OP, pascal_ltc0_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x37, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_REQUEST_ATOMIC_OP, pascal_ltc1_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x13, PM_UNIT_LTS1_1, 1},

    {PASCAL_LTC0_REQUEST_APERTURE_SYSMEM, pascal_ltc0_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x33, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_REQUEST_APERTURE_SYSMEM, pascal_ltc1_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0xf, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_REQUEST_APERTURE_VIDMEM, pascal_ltc0_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x32, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_REQUEST_APERTURE_VIDMEM, pascal_ltc1_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0xe, PM_UNIT_LTS1_1, 1},

    {PASCAL_LTC0_HIT, pascal_ltc0_hit_enc_str_1, 0x0, 0xaaaa, 0x2c, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_HIT, pascal_ltc1_hit_enc_str_1, 0x0, 0xaaaa, 0x8, PM_UNIT_LTS1_1, 1},

    {PASCAL_LTC0_REQUEST, pascal_ltc0_request_enc_str_1, 0x0, 0xaaaa, 0x24, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_REQUEST, pascal_ltc1_request_enc_str_1, 0x0, 0xaaaa, 0x0, PM_UNIT_LTS1_1, 1},

    {PASCAL_LTC0_WRITE_MISS_SECTORS, pascal_ltc0_write_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x28, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_WRITE_MISS_SECTORS, pascal_ltc1_write_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x4, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_READ_MISS_SECTORS, pascal_ltc0_read_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x29, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_READ_MISS_SECTORS, pascal_ltc1_read_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x5, PM_UNIT_LTS1_1, 1},

    { INVALID_PM_SIGNAL_NEW,        "",     0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};
#endif
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) */


#if NVCFG(GLOBAL_GPU_FAMILY_GP10X)
PerfSignalHwpmExpt_v1 PerfSignalTableGP100_ltc0_expt[] = {
    //write a combination of the signals.

    // ltc_read_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { PASCAL_LTC0_READ_TEX_SECTORS_FBP, pascal_ltc0_read_tex_sectors_fbp_enc_str_1, PASCAL_LTC0_REQUEST_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_RD_OP, PASCAL_LTC0_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_request_sectors_src_unit_tex_op_atomic_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_request_atomic_op
    { PASCAL_LTC0_ATOMIC_TEX_SECTORS_FBP, pascal_ltc0_atomic_tex_sectors_fbp_enc_str_1, PASCAL_LTC0_REQUEST_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_ATOMIC_OP, PASCAL_LTC0_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_write_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { PASCAL_LTC0_WRITE_TEX_SECTORS_FBP, pascal_ltc0_write_tex_sectors_fbp_enc_str_1, PASCAL_LTC0_REQUEST_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_WR_OP, PASCAL_LTC0_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_read_hit_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_hit
    { PASCAL_LTC0_READ_TEX_HIT_SECTORS_FBP, pascal_ltc0_read_tex_hit_sectors_fbp_enc_str_1,  PASCAL_LTC0_HIT_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_RD_OP, PASCAL_LTC0_REQUEST_SRC_UNIT_TEX, PASCAL_LTC0_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_LTC0_WRITE_TEX_HIT_SECTORS_FBP, pascal_ltc0_write_tex_hit_sectors_fbp_enc_str_1,  PASCAL_LTC0_HIT_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_WR_OP, PASCAL_LTC0_REQUEST_SRC_UNIT_TEX, PASCAL_LTC0_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_LTC0_READ_SYSMEM_SECTORS_FBP, pascal_ltc0_read_sysmem_sectors_fbp_enc_str_1, PASCAL_LTC0_REQUEST_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_RD_OP, PASCAL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_LTC0_WRITE_SYSMEM_SECTORS_FBP, pascal_ltc0_write_sysmem_sectors_fbp_enc_str_1, PASCAL_LTC0_REQUEST_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_WR_OP, PASCAL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { PASCAL_LTC0_TOTAL_READ_SECTORS_FBP, pascal_ltc0_total_read_sectors_fbp_enc_str_1, PASCAL_LTC0_REQUEST_SECTORS, {PASCAL_LTC0_REQUEST_ATOMIC_OP, PASCAL_LTC0_REQUEST_RD_OP, PASCAL_LTC0_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { PASCAL_LTC0_TOTAL_WRITE_SECTORS_FBP, pascal_ltc0_total_write_sectors_fbp_enc_str_1, PASCAL_LTC0_REQUEST_SECTORS, {PASCAL_LTC0_REQUEST_ATOMIC_OP, PASCAL_LTC0_REQUEST_WR_OP, PASCAL_LTC0_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_read_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { PASCAL_LTC0_READ_VIDMEM_SECTORS_FBP,      pascal_ltc0_read_vidmem_sectors_fbp_enc_str_1,    PASCAL_LTC0_REQUEST_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_RD_OP, PASCAL_LTC0_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_write_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { PASCAL_LTC0_WRITE_VIDMEM_SECTORS_FBP,      pascal_ltc0_write_vidmem_sectors_fbp_enc_str_1,    PASCAL_LTC0_REQUEST_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_WR_OP, PASCAL_LTC0_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_LTC0_READ_SYSMEM_HIT_SECTORS_FBP, pascal_ltc0_read_sysmem_hit_sectors_fbp_enc_str_1, PASCAL_LTC0_HIT_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_RD_OP, PASCAL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_LTC0_WRITE_SYSMEM_HIT_SECTORS_FBP, pascal_ltc0_write_sysmem_hit_sectors_fbp_enc_str_1, PASCAL_LTC0_HIT_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_WR_OP, PASCAL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_LTC0_READ_SYSMEM_MISS_SECTORS_FBP, pascal_ltc0_read_sysmem_miss_sectors_fbp_enc_str_1, PASCAL_LTC0_MISS_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_RD_OP, PASCAL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_LTC0_WRITE_SYSMEM_MISS_SECTORS_FBP, pascal_ltc0_write_sysmem_miss_sectors_fbp_enc_str_1, PASCAL_LTC0_MISS_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_WR_OP, PASCAL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_read_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { PASCAL_LTC1_READ_TEX_SECTORS_FBP, pascal_ltc1_read_tex_sectors_fbp_enc_str_1, PASCAL_LTC1_REQUEST_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_RD_OP, PASCAL_LTC1_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_request_sectors_src_unit_tex_op_atomic_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_request_atomic_op
    { PASCAL_LTC1_ATOMIC_TEX_SECTORS_FBP, pascal_ltc1_atomic_tex_sectors_fbp_enc_str_1, PASCAL_LTC1_REQUEST_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_ATOMIC_OP, PASCAL_LTC1_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_write_sectors_tex_fbp0_l2slice1 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { PASCAL_LTC1_WRITE_TEX_SECTORS_FBP, pascal_ltc1_write_tex_sectors_fbp_enc_str_1, PASCAL_LTC1_REQUEST_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_WR_OP, PASCAL_LTC1_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_read_hit_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_hit
    { PASCAL_LTC1_READ_TEX_HIT_SECTORS_FBP, pascal_ltc1_read_tex_hit_sectors_fbp_enc_str_1,  PASCAL_LTC1_HIT_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_RD_OP, PASCAL_LTC1_REQUEST_SRC_UNIT_TEX, PASCAL_LTC1_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_LTC1_WRITE_TEX_HIT_SECTORS_FBP, pascal_ltc1_write_tex_hit_sectors_fbp_enc_str_1,  PASCAL_LTC1_HIT_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_WR_OP, PASCAL_LTC1_REQUEST_SRC_UNIT_TEX, PASCAL_LTC1_HIT}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE & TRUTH_TABLE_FUNCTION_BIT_3_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_LTC1_READ_SYSMEM_SECTORS_FBP, pascal_ltc1_read_sysmem_sectors_fbp_enc_str_1, PASCAL_LTC1_REQUEST_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_RD_OP, PASCAL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_LTC1_WRITE_SYSMEM_SECTORS_FBP, pascal_ltc1_write_sysmem_sectors_fbp_enc_str_1, PASCAL_LTC1_REQUEST_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_WR_OP, PASCAL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { PASCAL_LTC1_TOTAL_READ_SECTORS_FBP, pascal_ltc1_total_read_sectors_fbp_enc_str_1, PASCAL_LTC1_REQUEST_SECTORS, {PASCAL_LTC1_REQUEST_ATOMIC_OP, PASCAL_LTC1_REQUEST_RD_OP, PASCAL_LTC1_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { PASCAL_LTC1_TOTAL_WRITE_SECTORS_FBP, pascal_ltc1_total_write_sectors_fbp_enc_str_1, PASCAL_LTC1_REQUEST_SECTORS, {PASCAL_LTC1_REQUEST_ATOMIC_OP, PASCAL_LTC1_REQUEST_WR_OP, PASCAL_LTC1_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_read_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { PASCAL_LTC1_READ_VIDMEM_SECTORS_FBP,      pascal_ltc1_read_vidmem_sectors_fbp_enc_str_1,    PASCAL_LTC1_REQUEST_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_RD_OP, PASCAL_LTC1_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_write_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { PASCAL_LTC1_WRITE_VIDMEM_SECTORS_FBP,      pascal_ltc1_write_vidmem_sectors_fbp_enc_str_1,    PASCAL_LTC1_REQUEST_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_WR_OP, PASCAL_LTC1_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_LTC1_READ_SYSMEM_HIT_SECTORS_FBP, pascal_ltc1_read_sysmem_hit_sectors_fbp_enc_str_1, PASCAL_LTC1_HIT_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_RD_OP, PASCAL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_LTC1_WRITE_SYSMEM_HIT_SECTORS_FBP, pascal_ltc1_write_sysmem_hit_sectors_fbp_enc_str_1, PASCAL_LTC1_HIT_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_WR_OP, PASCAL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_LTC1_READ_SYSMEM_MISS_SECTORS_FBP, pascal_ltc1_read_sysmem_miss_sectors_fbp_enc_str_1, PASCAL_LTC1_MISS_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_RD_OP, PASCAL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { PASCAL_LTC1_WRITE_SYSMEM_MISS_SECTORS_FBP, pascal_ltc1_write_sysmem_miss_sectors_fbp_enc_str_1, PASCAL_LTC1_MISS_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_WR_OP, PASCAL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000, INVALID_PM_SIGNAL_NEW},
};
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) */

#if NVCFG(GLOBAL_GPU_FAMILY_GP10X)
PerfSignalNvLinkThroughputCounters PerfSignalTableGP100_nvlinkTC[] = {
    // signalId     pSignalName     NvLink      unitOfTraffic       typeOfFlits     transactionType     tranferDirection
    { PASCAL_NVLINK_TL_TX_TOTAL_FLITS, pascal_nvlink_tl_tx_total_flits_enc_str_1, 0x02, 0x0F, 0xFF, CUPROF_NVLINK_DATA_TRANSMIT },
    { PASCAL_NVLINK_TL_TX_DATA_FLITS, pascal_nvlink_tl_tx_data_flits_enc_str_1, 0x02, 0x08, 0xFF, CUPROF_NVLINK_DATA_TRANSMIT },
    { PASCAL_NVLINK_TL_TX_READ_TOTAL_FLITS, pascal_nvlink_tl_tx_read_total_flits_enc_str_1, 0x02, 0x0F, 0x02, CUPROF_NVLINK_DATA_TRANSMIT },
    { PASCAL_NVLINK_TL_TX_WRITE_TOTAL_FLITS, pascal_nvlink_tl_tx_write_total_flits_enc_str_1, 0x02, 0x0F, 0x04, CUPROF_NVLINK_DATA_TRANSMIT },
    { PASCAL_NVLINK_TL_TX_RATOM_TOTAL_FLITS, pascal_nvlink_tl_tx_ratom_total_flits_enc_str_1, 0x02, 0x0F, 0x08, CUPROF_NVLINK_DATA_TRANSMIT },
    { PASCAL_NVLINK_TL_TX_NRATOM_TOTAL_FLITS, pascal_nvlink_tl_tx_nratom_total_flits_enc_str_1, 0x02, 0x0F, 0x10, CUPROF_NVLINK_DATA_TRANSMIT },
    { PASCAL_NVLINK_TL_TX_FLUSH_TOTAL_FLITS, pascal_nvlink_tl_tx_flush_total_flits_enc_str_1, 0x02, 0x0F, 0x20, CUPROF_NVLINK_DATA_TRANSMIT },
    { PASCAL_NVLINK_TL_TX_RESPD_TOTAL_FLITS, pascal_nvlink_tl_tx_respd_total_flits_enc_str_1, 0x02, 0x0F, 0x40, CUPROF_NVLINK_DATA_TRANSMIT },
    { PASCAL_NVLINK_TL_TX_READ_DATA_FLITS, pascal_nvlink_tl_tx_read_data_flits_enc_str_1, 0x02, 0x08, 0x02, CUPROF_NVLINK_DATA_TRANSMIT },
    { PASCAL_NVLINK_TL_TX_WRITE_DATA_FLITS, pascal_nvlink_tl_tx_write_data_flits_enc_str_1, 0x02, 0x08, 0x04, CUPROF_NVLINK_DATA_TRANSMIT },
    { PASCAL_NVLINK_TL_TX_RATOM_DATA_FLITS, pascal_nvlink_tl_tx_ratom_data_flits_enc_str_1, 0x02, 0x08, 0x08, CUPROF_NVLINK_DATA_TRANSMIT },
    { PASCAL_NVLINK_TL_TX_NRATOM_DATA_FLITS, pascal_nvlink_tl_tx_nratom_data_flits_enc_str_1, 0x02, 0x08, 0x10, CUPROF_NVLINK_DATA_TRANSMIT },
    { PASCAL_NVLINK_TL_TX_FLUSH_DATA_FLITS, pascal_nvlink_tl_tx_flush_data_flits_enc_str_1, 0x02, 0x08, 0x20, CUPROF_NVLINK_DATA_TRANSMIT },
    { PASCAL_NVLINK_TL_TX_RESPD_DATA_FLITS, pascal_nvlink_tl_tx_respd_data_flits_enc_str_1, 0x02, 0x08, 0x40, CUPROF_NVLINK_DATA_TRANSMIT },
    //------------------------------------------------------------------------------------------------------------------------------------------
    { PASCAL_NVLINK_TL_RX_TOTAL_FLITS, pascal_nvlink_tl_rx_total_flits_enc_str_1, 0x02, 0x0F, 0xFF, CUPROF_NVLINK_DATA_RECIEVE },
    { PASCAL_NVLINK_TL_RX_DATA_FLITS, pascal_nvlink_tl_rx_data_flits_enc_str_1, 0x02, 0x08, 0xFF, CUPROF_NVLINK_DATA_RECIEVE },
    { PASCAL_NVLINK_TL_RX_READ_TOTAL_FLITS, pascal_nvlink_tl_rx_read_total_flits_enc_str_1, 0x02, 0x0F, 0x02, CUPROF_NVLINK_DATA_RECIEVE },
    { PASCAL_NVLINK_TL_RX_WRITE_TOTAL_FLITS, pascal_nvlink_tl_rx_write_total_flits_enc_str_1, 0x02, 0x0F, 0x04, CUPROF_NVLINK_DATA_RECIEVE },
    { PASCAL_NVLINK_TL_RX_RATOM_TOTAL_FLITS, pascal_nvlink_tl_rx_ratom_total_flits_enc_str_1, 0x02, 0x0F, 0x08, CUPROF_NVLINK_DATA_RECIEVE },
    { PASCAL_NVLINK_TL_RX_NRATOM_TOTAL_FLITS, pascal_nvlink_tl_rx_nratom_total_flits_enc_str_1, 0x02, 0x0F, 0x10, CUPROF_NVLINK_DATA_RECIEVE },
    { PASCAL_NVLINK_TL_RX_FLUSH_TOTAL_FLITS, pascal_nvlink_tl_rx_flush_total_flits_enc_str_1, 0x02, 0x0F, 0x20, CUPROF_NVLINK_DATA_RECIEVE },
    { PASCAL_NVLINK_TL_RX_RESPD_TOTAL_FLITS, pascal_nvlink_tl_rx_respd_total_flits_enc_str_1, 0x02, 0x0F, 0x40, CUPROF_NVLINK_DATA_RECIEVE },
    { PASCAL_NVLINK_TL_RX_READ_DATA_FLITS, pascal_nvlink_tl_rx_read_data_flits_enc_str_1, 0x02, 0x08, 0x02, CUPROF_NVLINK_DATA_RECIEVE },
    { PASCAL_NVLINK_TL_RX_WRITE_DATA_FLITS, pascal_nvlink_tl_rx_write_data_flits_enc_str_1, 0x02, 0x08, 0x04, CUPROF_NVLINK_DATA_RECIEVE },
    { PASCAL_NVLINK_TL_RX_RATOM_DATA_FLITS, pascal_nvlink_tl_rx_ratom_data_flits_enc_str_1, 0x02, 0x08, 0x08, CUPROF_NVLINK_DATA_RECIEVE },
    { PASCAL_NVLINK_TL_RX_NRATOM_DATA_FLITS, pascal_nvlink_tl_rx_nratom_data_flits_enc_str_1, 0x02, 0x08, 0x10, CUPROF_NVLINK_DATA_RECIEVE },
    { PASCAL_NVLINK_TL_RX_FLUSH_DATA_FLITS, pascal_nvlink_tl_rx_flush_data_flits_enc_str_1, 0x02, 0x08, 0x20, CUPROF_NVLINK_DATA_RECIEVE },
    { PASCAL_NVLINK_TL_RX_RESPD_DATA_FLITS, pascal_nvlink_tl_rx_respd_data_flits_enc_str_1, 0x02, 0x08, 0x40, CUPROF_NVLINK_DATA_RECIEVE },
    { INVALID_PM_SIGNAL_NEW,        "",   CUPROF_NVLINK_INVALID, 0xff, 0xff, CUPROF_NVLINK_DATA_INVALID }
};
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) */

#if NVCFG(GLOBAL_GPU_FAMILY_GP10X)
PerfSignalHwpm PerfSignalTableGP100_pcie0[] = {
    {PASCAL_PCIE_TX_ACTIVE, pascal_pcie_tx_active_enc_str_1,    0xb,        0xaaaa,     0x4,    PM_UNIT_XVE1,   1},
    {PASCAL_PCIE_TX_IDLE,   pascal_pcie_tx_idle_enc_str_1,      0xb,        0xaaaa,     0x3,    PM_UNIT_XVE1,   1},
    {PASCAL_PCIE_RX_ACTIVE, pascal_pcie_rx_active_enc_str_1,    0xe,        0xaaaa,     0x1e,   PM_UNIT_XVE2,   1},
    {PASCAL_PCIE_RX_IDLE,   pascal_pcie_rx_idle_enc_str_1,      0xe,        0xaaaa,     0x1d,   PM_UNIT_XVE2,   1},
    {INVALID_PM_SIGNAL_NEW, "",                                 0xffffffff, 0x00000000, 0x00,   PM_UNIT_MAX,    0 }
};
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) */

#if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
PerfSignalSmpc PerfSignalTableGP100_sm0_quad[] = {

    { PASCAL_SM_PMTRIG0, pascal_sm_pmtrig0_enc_str_1, 0x00000000, 0x00000000, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"prof_trigger_00"
    { PASCAL_SM_PMTRIG1, pascal_sm_pmtrig1_enc_str_1, 0x00000000, 0x00000001, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"prof_trigger_01"
    { PASCAL_SM_PMTRIG2, pascal_sm_pmtrig2_enc_str_1, 0x00000000, 0x00000002, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"prof_trigger_02"
    { PASCAL_SM_PMTRIG3, pascal_sm_pmtrig3_enc_str_1, 0x00000000, 0x00000003, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"prof_trigger_03"
    { PASCAL_SM_PMTRIG4, pascal_sm_pmtrig4_enc_str_1, 0x00000000, 0x00000004, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"prof_trigger_04"
    { PASCAL_SM_PMTRIG5, pascal_sm_pmtrig5_enc_str_1, 0x00000000, 0x00000005, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"prof_trigger_05"
    { PASCAL_SM_PMTRIG6, pascal_sm_pmtrig6_enc_str_1, 0x00000000, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"prof_trigger_06"
    { PASCAL_SM_PMTRIG7, pascal_sm_pmtrig7_enc_str_1, 0x00000000, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"prof_trigger_07"
    { PASCAL_SM_PMTRIG8, pascal_sm_pmtrig8_enc_str_1, 0x00000001, 0x00000000, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"pmtrig8"
    { PASCAL_SM_PMTRIG9, pascal_sm_pmtrig9_enc_str_1, 0x00000001, 0x00000001, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"pmtrig9"
    { PASCAL_SM_PMTRIG10, pascal_sm_pmtrig10_enc_str_1, 0x00000001, 0x00000002, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"pmtrig10"
    { PASCAL_SM_PMTRIG11, pascal_sm_pmtrig11_enc_str_1, 0x00000001, 0x00000003, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"pmtrig11"
    { PASCAL_SM_PMTRIG12, pascal_sm_pmtrig12_enc_str_1, 0x00000001, 0x00000004, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"pmtrig12"
    { PASCAL_SM_PMTRIG13, pascal_sm_pmtrig13_enc_str_1, 0x00000001, 0x00000005, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"pmtrig13"
    { PASCAL_SM_PMTRIG14, pascal_sm_pmtrig14_enc_str_1, 0x00000001, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"pmtrig14"
    { PASCAL_SM_PMTRIG15, pascal_sm_pmtrig15_enc_str_1, 0x00000001, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"pmtrig15"
    { PASCAL_SM_ACTIVE_CYCLES_QUAD, pascal_sm_active_cycles_sctl_enc_str_1, 0x00000002, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"active_cycles"
    { PASCAL_SM_WARPS_LAUNCHED, pascal_sm_warps_launched_enc_str_1, 0x00000002, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warps_launched"
    { PASCAL_SM_INST_ISSUED0, pascal_sm_inst_issued0_enc_str_1, 0x00000003, 0x00000000, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_issued0"
    { PASCAL_SM_INST_ISSUED1, pascal_sm_inst_issued1_enc_str_1, 0x00000003, 0x00000001, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_issued1"
    { PASCAL_SM_INST_ISSUED2, pascal_sm_inst_issued2_enc_str_1, 0x00000003, 0x00000002, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_issued2"
    { PASCAL_SM_INST_EXECUTED, pascal_sm_inst_executed_enc_str_1, 0x00000003, 0x00000043, 0x00000003, PM_UNIT_SMQCTL, 2, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed"
    { PASCAL_SM_INST_EXECUTED_IN_TRAP, pascal_sm_inst_executed_in_trap_enc_str_1, 0x00000003, 0x00000043, 0x00000003, PM_UNIT_SMQCTL, 2, PASCAL_SM_TRAP_IN_TRAP_QUAD}, //"inst_executed_in_trap"
    { PASCAL_SM_INST_EXECUTED_OUTSIDE_TRAP, pascal_sm_inst_executed_outside_trap_enc_str_1, 0x00000003, 0x00000043, 0x00000003, PM_UNIT_SMQCTL, 2, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_outside_trap"
    { PASCAL_SM_INST_ROLLBACKED, pascal_sm_inst_rollbacked_enc_str_1, 0x00000003, 0x00000765, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_rollbacked"
    { PASCAL_SM_THREAD_INST_EXECUTED, pascal_sm_thread_inst_executed_enc_str_1, 0x00000004, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"thread_inst_executed"
    { PASCAL_SM_WARPS_MOVED_ON_DECK, pascal_sm_warps_moved_on_deck_enc_str_1, 0x00000004, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warps_moved_on_deck"
    { PASCAL_SM_WARPS_MOVED_OFF_DECK, pascal_sm_warps_moved_off_deck_enc_str_1, 0x00000004, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warps_moved_off_deck"
    { PASCAL_SM_NOT_PREDICATED_OFF_THREAD_INST_EXECUTED, pascal_sm_not_predicated_off_thread_inst_executed_enc_str_1, 0x00000005, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"not_predicated_off_thread_inst_executed"
    { PASCAL_SM_TRAP_IN_TRAP_QUAD, pascal_sm_trap_in_trap_sctl_enc_str_1, 0x00000005, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1}, //"trap_in_trap"
    { PASCAL_SM_NON_IDLE_SCTL, pascal_sm_non_idle_sctl_enc_str_1, 0x00000005, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"non_idle_sctl"
    { PASCAL_SM_WARP_CANT_ISSUE_DRAIN, pascal_sm_warp_cant_issue_drain_enc_str_1, 0x00000006, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_cant_issue_drain"
    { PASCAL_SM_LOCAL_STORE, pascal_sm_local_store_enc_str_1, 0x00000006, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"local_store"
    { PASCAL_SM_LOCAL_LOAD, pascal_sm_local_load_enc_str_1, 0x00000006, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"local_load"
    { PASCAL_SM_WARP_CANT_ISSUE_ICACHE_MISS, pascal_sm_warp_cant_issue_icache_miss_enc_str_1, 0x00000007, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_cant_issue_icache_miss"
    { PASCAL_SM_SHARED_LOAD, pascal_sm_shared_load_enc_str_1, 0x00000007, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"shared_load"
    { PASCAL_SM_SHARED_STORE, pascal_sm_shared_store_enc_str_1, 0x00000007, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"shared_store"
    { PASCAL_SM_WARP_CANT_ISSUE_IMC_MISS, pascal_sm_warp_cant_issue_imc_miss_enc_str_1, 0x00000008, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_cant_issue_imc_miss"
    { PASCAL_SM_SHARED_ATOM_CAS, pascal_sm_shared_atom_cas_enc_str_1, 0x00000008, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"shared_atom_cas"
    { PASCAL_SM_SHARED_ATOM, pascal_sm_shared_atom_enc_str_1, 0x00000008, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"shared_atom"
    { PASCAL_SM_WARP_CANT_ISSUE_LONG_SCOREBOARD, pascal_sm_warp_cant_issue_long_scoreboard_enc_str_1, 0x00000009, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_cant_issue_long_scoreboard"
    { PASCAL_SM_INST_EXECUTED_ATTRIBUTE_ST, pascal_sm_inst_executed_attribute_st_enc_str_1, 0x00000009, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_attribute_st"
    { PASCAL_SM_INST_EXECUTED_ATTRIBUTE_LD, pascal_sm_inst_executed_attribute_ld_enc_str_1, 0x00000009, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_attribute_ld"
    { PASCAL_SM_WARP_CANT_ISSUE_BARRIER, pascal_sm_warp_cant_issue_barrier_enc_str_1, 0x0000000a, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_cant_issue_barrier"
    { PASCAL_SM_GLOBAL_ATOM_CAS, pascal_sm_global_atom_cas_enc_str_1, 0x0000000a, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"global_atom_cas"
    { PASCAL_SM_GLOBAL_ATOM, pascal_sm_global_atom_enc_str_1, 0x0000000a, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"global_atom"
    { PASCAL_SM_WARP_CANT_ISSUE_OFF_DECK_SHORT_SCOREBOARD, pascal_sm_warp_cant_issue_off_deck_short_scoreboard_enc_str_1, 0x0000000b, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_cant_issue_off_deck_short_scoreboard"
    { PASCAL_SM_GLOBAL_LOAD, pascal_sm_global_load_enc_str_1, 0x0000000b, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"global_ld"
    { PASCAL_SM_GLOBAL_STORE, pascal_sm_global_store_enc_str_1, 0x0000000b, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"global_st"
    { PASCAL_SM_WARP_CANT_ISSUE_TILE_ALLOCATION_STALL, pascal_sm_warp_cant_issue_tile_allocation_stall_enc_str_1, 0x0000000c, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_cant_issue_tile_allocation_stall"
    { PASCAL_SM_GENERIC_LOAD, pascal_sm_generic_load_enc_str_1, 0x0000000c, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"generic_ld"
    { PASCAL_SM_GENERIC_STORE, pascal_sm_generic_store_enc_str_1, 0x0000000c, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"generic_st"
    { PASCAL_SM_WARP_CANT_ISSUE_ALLOCATION_STALL_NO_SPACE, pascal_sm_warp_cant_issue_allocation_stall_no_space_enc_str_1, 0x0000000d, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_cant_issue_allocation_stall_no_space"
    { PASCAL_SM_INST_EXECUTED_SURFACE_ATOM, pascal_sm_inst_executed_surface_atom_enc_str_1, 0x0000000d, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_surface_atom"
    { PASCAL_SM_INST_EXECUTED_SURFACE_ATOM_CAS, pascal_sm_inst_executed_surface_atom_cas_enc_str_1, 0x0000000d, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_surface_atom_cas"
    { PASCAL_SM_WARP_CANT_ISSUE_ALLOCATION_STALL_NOT_ELIGIBLE, pascal_sm_warp_cant_issue_allocation_stall_not_eligible_enc_str_1, 0x0000000e, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_cant_issue_allocation_stall_not_eligible"
    { PASCAL_SM_INST_EXECUTED_SURFACE_LD, pascal_sm_inst_executed_surface_ld_enc_str_1, 0x0000000e, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_surface_ld"
    { PASCAL_SM_INST_EXECUTED_SURFACE_ST, pascal_sm_inst_executed_surface_st_enc_str_1, 0x0000000e, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_surface_st"
    { PASCAL_SM_WARP_CANT_ISSUE_MISC, pascal_sm_warp_cant_issue_misc_enc_str_1, 0x0000000f, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_cant_issue_misc"
    { PASCAL_SM_GLOBAL_RED, pascal_sm_global_red_enc_str_1, 0x0000000f, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_global_red"
    { PASCAL_SM_INST_EXECUTED_SURFACE_RED, pascal_sm_inst_executed_surface_red_enc_str_1, 0x0000000f, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_surface_red"
    { PASCAL_SM_WARP_CANT_ISSUE_MEMBAR, pascal_sm_warp_cant_issue_membar_enc_str_1, 0x00000010, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_cant_issue_membar"
    { PASCAL_SM_INST_EXECUTED_ADU_PIPE, pascal_sm_inst_executed_adu_pipe_enc_str_1, 0x00000010, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_adu_pipe"
    { PASCAL_SM_INST_EXECUTED_SU_PIPE, pascal_sm_inst_executed_su_pipe_enc_str_1, 0x00000010, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_su_pipe"
    { PASCAL_SM_WARP_CANT_ISSUE_ON_DECK_SHORT_SCOREBOARD, pascal_sm_warp_cant_issue_on_deck_short_scoreboard_enc_str_1, 0x00000011, 0x00000210, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_cant_issue_on_deck_short_scoreboard"
    { PASCAL_SM_WARP_CANT_ISSUE_WAIT, pascal_sm_warp_cant_issue_wait_enc_str_1, 0x00000011, 0x00000543, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_cant_issue_wait"
    { PASCAL_SM_INST_EXECUTED_LDC_PIPE, pascal_sm_inst_executed_ldc_pipe_enc_str_1, 0x00000011, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_ldc_pipe"
    { PASCAL_SM_INST_EXECUTED_LSU_PIPE, pascal_sm_inst_executed_lsu_pipe_enc_str_1, 0x00000011, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_lsu_pipe"
    { PASCAL_SM_WARP_CANT_ISSUE_NO_INSTRUCTIONS, pascal_sm_warp_cant_issue_no_instructions_enc_str_1, 0x00000012, 0x00000210, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_cant_issue_no_instructions"
    { PASCAL_SM_WARP_CANT_ISSUE_SHADOW_PIPE_THROTTLE, pascal_sm_warp_cant_issue_shadow_pipe_throttle_enc_str_1, 0x00000012, 0x00000543, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_cant_issue_shadow_pipe_throttle"
    { PASCAL_SM_INST_EXECUTED_FMAI_PIPE, pascal_sm_inst_executed_fmai_pipe_enc_str_1, 0x00000012, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_fmai_pipe"
    { PASCAL_SM_INST_EXECUTED_FXU_PIPE, pascal_sm_inst_executed_fxu_pipe_enc_str_1, 0x00000012, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_fxu_pipe"
    { PASCAL_SM_WARP_CANT_ISSUE_TEX_THROTTLE, pascal_sm_warp_cant_issue_tex_throttle_enc_str_1, 0x00000013, 0x00000210, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_cant_issue_tex_throttle"
    { PASCAL_SM_WARP_CANT_ISSUE_MIO_THROTTLE, pascal_sm_warp_cant_issue_mio_throttle_enc_str_1, 0x00000013, 0x00000543, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_cant_issue_mio_throttle"
    { PASCAL_SM_INST_EXECUTED_FE_PIPE, pascal_sm_inst_executed_fe_pipe_enc_str_1, 0x00000013, 0x00000076, 0x00000003, PM_UNIT_SMQCTL, 2, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_fe_pipe"
    { PASCAL_SM_WARP_CANT_ISSUE_DISPATCH_STALL, pascal_sm_warp_cant_issue_dispatch_stall_enc_str_1, 0x00000014, 0x00000210, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_cant_issue_dispatch_stall"
    { PASCAL_SM_WARP_CANT_ISSUE_NOT_SELECTED, pascal_sm_warp_cant_issue_not_selected_enc_str_1, 0x00000014, 0x00000543, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_cant_issue_not_selected"
    { PASCAL_SM_INST_EXECUTED_FMA64LITE_PIPE, pascal_sm_inst_executed_fma64lite_pipe_enc_str_1, 0x00000014, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_fma64lite_pipe"
    { PASCAL_SM_INST_EXECUTED_FMA64PLUS_PIPE, pascal_sm_inst_executed_fma64plus_pipe_enc_str_1, 0x00000014, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_fma64plus_pipe"
    { PASCAL_SM_WARP_CANT_ISSUE_ON_DECK_LONG_SCOREBOARD, pascal_sm_warp_cant_issue_on_deck_long_scoreboard_enc_str_1, 0x00000015, 0x00000210, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_cant_issue_on_deck_long_scoreboard"
    { PASCAL_SM_WARP_CANT_ISSUE_ON_DECK_MISC, pascal_sm_warp_cant_issue_on_deck_misc_enc_str_1, 0x00000015, 0x00000543, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_cant_issue_on_deck_misc"
    { PASCAL_SM_INST_EXECUTED_FMA64PLUSPLUS_PIPE, pascal_sm_inst_executed_fma64plusplus_pipe_enc_str_1, 0x00000015, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_fma64plusplus_pipe"
    { PASCAL_SM_INST_EXECUTED_BAR_PIPE, pascal_sm_inst_executed_bar_pipe_enc_str_1, 0x00000015, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_bar_pipe"
    { PASCAL_SM_WARP_CANT_ISSUE_SELECTED, pascal_sm_warp_cant_issue_selected_enc_str_1, 0x00000016, 0x00000000, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_cant_issue_selected"
    { PASCAL_SM_WARP_ISSUE_ELIGIBLE, pascal_sm_warp_issue_eligible_enc_str_1, 0x00000016, 0x00000321, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_issue_eligible"
    { PASCAL_SM_WARPS_ON_DECK, pascal_sm_warps_on_deck_enc_str_1, 0x00000016, 0x00000654, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warps_on_deck"
    { PASCAL_SM_INST_EXECUTED_XU_PIPE, pascal_sm_inst_executed_xu_pipe_enc_str_1, 0x00000016, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_xu_pipe"
    { PASCAL_SM_INST_EXECUTED_DECOUPLED_PRED_OFF, pascal_sm_inst_executed_decoupled_pred_off_enc_str_1, 0x00000017, 0x00000000, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_decoupled_pred_off"
    { PASCAL_SM_INST_EXECUTED_COUPLED_PRED_OFF, pascal_sm_inst_executed_coupled_pred_off_enc_str_1, 0x00000017, 0x00000001, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_coupled_pred_off"
    { PASCAL_SM_INST_EXECUTED_32B, pascal_sm_inst_executed_32b_enc_str_1, 0x00000017, 0x00000002, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_32b"
    { PASCAL_SM_INST_EXECUTED_64B, pascal_sm_inst_executed_64b_enc_str_1, 0x00000017, 0x00000003, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_64b"
    { PASCAL_SM_INST_EXECUTED_128B, pascal_sm_inst_executed_128b_enc_str_1, 0x00000017, 0x00000004, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_128b"
    { PASCAL_SM_INST_EXECUTED_U128B, pascal_sm_inst_executed_u128b_enc_str_1, 0x00000017, 0x00000005, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_U128b"
    { PASCAL_SM_INST_EXECUTED_LSU_GENERIC_SHARED, pascal_sm_inst_executed_lsu_generic_shared_enc_str_1, 0x00000017, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_lsu_generic_shared"
    { PASCAL_SM_INST_EXECUTED_LSU_GENERIC_TEX, pascal_sm_inst_executed_lsu_generic_tex_enc_str_1, 0x00000017, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_lsu_generic_tex"
    { PASCAL_SM_WARP_CANT_ISSUE_INST_ISSUED_0, pascal_sm_warp_cant_issue_inst_issued0_enc_str_1, 0x00000018, 0x00000000, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"warp_cant_issue_inst_issued0"
    { PASCAL_SM_TEX_WB_REQUESTS_PENDING, pascal_sm_tex_wb_requests_pending_enc_str_1, 0x00000018, 0x00654321, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"tex_wb_requests_pending"
    { PASCAL_SM_TEX_WB_REQUESTS, pascal_sm_tex_wb_requests_enc_str_1, 0x00000018, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"tex_wb_requests"
    { PASCAL_SM_IMC_HIT, pascal_sm_imc_hit_enc_str_1, 0x00000019, 0x00000000, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"imc_hit"
    { PASCAL_SM_IMC_FULL_TAG, pascal_sm_imc_full_tag_enc_str_1, 0x00000019, 0x00000001, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"imc_full_tag"
    { PASCAL_SM_IMC_TRUE_MISS, pascal_sm_imc_true_miss_enc_str_1, 0x00000019, 0x00000002, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"imc_true_miss"
    { PASCAL_SM_IMC_COVERED_MISS, pascal_sm_imc_covered_miss_enc_str_1, 0x00000019, 0x00000003, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"imc_covered_miss"
    { PASCAL_SM_IMC_MISSES_OUTSTANDING, pascal_sm_imc_misses_outstanding_enc_str_1, 0x00000019, 0x00000654, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"imc_misses_outstanding"
    { PASCAL_SM_FET_FETCHED_LINES, pascal_sm_fet_fetched_lines_enc_str_1, 0x00000019, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"fet_fetched_lines"
    { PASCAL_SM_UNWINDING_BR_EXECUTED, pascal_sm_unwinding_br_executed_enc_str_1, 0x0000001a, 0x00000000, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"unwinding_br_executed"
    { PASCAL_SM_DIVERGED_BR_EXECUTED, pascal_sm_diverged_br_executed_enc_str_1, 0x0000001a, 0x00000001, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"diverged_br_executed"
    { PASCAL_SM_UNIQUE_IDX_BR_EXECUTED, pascal_sm_unique_idx_br_executed_enc_str_1, 0x0000001a, 0x00000002, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"unique_idx_br_executed"
    { PASCAL_SM_RVAL_DIV_IDX_BR_EXECUTED, pascal_sm_rval_div_idx_br_executed_enc_str_1, 0x0000001a, 0x00000003, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"rval_div_idx_br_executed"
    { PASCAL_SM_BR_EXECUTED, pascal_sm_br_executed_enc_str_1, 0x0000001a, 0x00000004, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"br_executed"
    { PASCAL_SM_TAKEN_BR_EXECUTED, pascal_sm_taken_br_executed_enc_str_1, 0x0000001a, 0x00000005, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"taken_br_executed"
    { PASCAL_SM_PRED_DIV_IDX_BR_EXECUTED, pascal_sm_pred_div_idx_br_executed_enc_str_1, 0x0000001a, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"pred_div_idx_br_executed"
    { PASCAL_SM_INST_EXECUTED_BRU_PIPE, pascal_sm_inst_executed_bru_pipe_enc_str_1, 0x0000001a, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_bru_pipe"
    { PASCAL_SM_TEX_REQUESTS, pascal_sm_tex_requests_enc_str_1, 0x0000001b, 0x00000000, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"tex_requests"
    { PASCAL_SM_TEX_REQ_ACTIVE, pascal_sm_tex_req_active_enc_str_1, 0x0000001b, 0x00000001, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"tex_req_active"
    { PASCAL_SM_TEX_REQ_STALLED, pascal_sm_tex_req_stalled_enc_str_1, 0x0000001b, 0x00000002, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"tex_req_stalled"
    { PASCAL_SM_TEX_REQ_STARVED, pascal_sm_tex_req_starved_enc_str_1, 0x0000001b, 0x00000003, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"tex_req_starved"
    { PASCAL_SM_TEX_REQ_IDLE, pascal_sm_tex_req_idle_enc_str_1, 0x0000001b, 0x00000004, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"tex_req_idle"
    { PASCAL_SM_SCG_MODE_COMPUTE, pascal_sm_scg_mode_compute_enc_str_1, 0x0000001b, 0x00000005, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"scg_mode_compute"
    { PASCAL_SM_SCG_MODE_GRAPHICS, pascal_sm_scg_mode_graphics_enc_str_1, 0x0000001b, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"scg_mode_graphics"
    { PASCAL_SM_NOT_IN_TRAP_QUAD, pascal_sm_not_in_trap_quad_enc_str_1, 0x0000001b, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1}, //"sm_not_in_trap_quad"
    { PASCAL_SM_LSU_WB_OPS_PENDING, pascal_sm_lsu_wb_ops_pending_enc_str_1, 0x0000001c, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"lsu_wb_ops_pending"
    { PASCAL_SM_INST_EXECUTED_LSU_WB_OPS, pascal_sm_inst_executed_lsu_wb_ops_enc_str_1, 0x0000001c, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_lsu_wb_ops"
    { PASCAL_SM_INST_EXECUTED_VOTE_VTG, pascal_sm_inst_executed_vote_vtg_enc_str_1, 0x0000001c, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_vote_vtg"
    { PASCAL_SM_TEX_INST_PENDING, pascal_sm_tex_inst_pending_enc_str_1, 0x0000001d, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"tex_inst_pending"
    { PASCAL_SM_TEX_WB_INST_EXECUTED, pascal_sm_tex_wb_inst_executed_enc_str_1, 0x0000001d, 0x00000006, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"tex_wb_inst_executed"
    { PASCAL_SM_INST_EXECUTED_TEX_PIPE, pascal_sm_inst_executed_tex_pipe_enc_str_1, 0x0000001d, 0x00000007, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"inst_executed_tex_pipe"
    { PASCAL_SM_SCTL_HW_PM_MUX_LOWER, pascal_sm_sctl_hw_pm_mux_lower_enc_str_1, 0x0000001e, 0x76543210, 0x000000ff, PM_UNIT_SMQCTL, 8}, //"sctl_hw_pm_mux_lower"
    { PASCAL_SM_SCTL_HW_PM_MUX_UPPER, pascal_sm_sctl_hw_pm_mux_upper_enc_str_1, 0x0000001f, 0x76543210, 0x000000ff, PM_UNIT_SMQCTL, 8}, //"sctl_hw_pm_mux_upper"
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_DRAIN, pascal_sm_warp_cant_issue_true_drain_enc_str_1, 0x00000006, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_INST_ISSUED0}, //"warp_cant_issue_drain"
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_ICACHE_MISS, pascal_sm_warp_cant_issue_true_icache_miss_enc_str_1, 0x00000007, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_INST_ISSUED0}, //"warp_cant_issue_icache_miss"
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_IMC_MISS, pascal_sm_warp_cant_issue_true_imc_miss_enc_str_1, 0x00000008, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_INST_ISSUED0}, //"warp_cant_issue_imc_miss"
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_LONG_SCOREBOARD, pascal_sm_warp_cant_issue_true_long_scoreboard_enc_str_1, 0x00000009, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_INST_ISSUED0}, //"warp_cant_issue_long_scoreboard"
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_BARRIER, pascal_sm_warp_cant_issue_true_barrier_enc_str_1, 0x0000000a, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_INST_ISSUED0}, //"warp_cant_issue_barrier"
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_OFF_DECK_SHORT_SCOREBOARD, pascal_sm_warp_cant_issue_true_off_deck_short_scoreboard_enc_str_1, 0x0000000b, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_INST_ISSUED0}, //"warp_cant_issue_off_deck_short_scoreboard"
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_TILE_ALLOCATION_STALL, pascal_sm_warp_cant_issue_true_tile_allocation_stall_enc_str_1, 0x0000000c, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_INST_ISSUED0}, //"warp_cant_issue_tile_allocation_stall"
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_ALLOCATION_STALL_NO_SPACE, pascal_sm_warp_cant_issue_true_allocation_stall_no_space_enc_str_1, 0x0000000d, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_INST_ISSUED0}, //"warp_cant_issue_allocation_stall_no_space"
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_ALLOCATION_STALL_NOT_ELIGIBLE, pascal_sm_warp_cant_issue_true_allocation_stall_not_eligible_enc_str_1, 0x0000000e, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_INST_ISSUED0}, //"warp_cant_issue_allocation_stall_not_eligible"
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_MISC, pascal_sm_warp_cant_issue_true_misc_enc_str_1, 0x0000000f, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_INST_ISSUED0}, //"warp_cant_issue_misc"
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_MEMBAR, pascal_sm_warp_cant_issue_true_membar_enc_str_1, 0x00000010, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_INST_ISSUED0}, //"warp_cant_issue_membar"
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_ON_DECK_SHORT_SCOREBOARD, pascal_sm_warp_cant_issue_true_on_deck_short_scoreboard_enc_str_1, 0x00000011, 0x00000210, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_INST_ISSUED0}, //"warp_cant_issue_on_deck_short_scoreboard"
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_WAIT, pascal_sm_warp_cant_issue_true_wait_enc_str_1, 0x00000011, 0x00000543, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_INST_ISSUED0}, //"warp_cant_issue_wait"
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_NO_INSTRUCTIONS, pascal_sm_warp_cant_issue_true_no_instructions_enc_str_1, 0x00000012, 0x00000210, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_INST_ISSUED0}, //"warp_cant_issue_no_instructions"
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_SHADOW_PIPE_THROTTLE, pascal_sm_warp_cant_issue_true_shadow_pipe_throttle_enc_str_1, 0x00000012, 0x00000543, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_INST_ISSUED0}, //"warp_cant_issue_shadow_pipe_throttle"
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_TEX_THROTTLE, pascal_sm_warp_cant_issue_true_tex_throttle_enc_str_1, 0x00000013, 0x00000210, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_INST_ISSUED0}, //"warp_cant_issue_tex_throttle"
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_MIO_THROTTLE, pascal_sm_warp_cant_issue_true_mio_throttle_enc_str_1, 0x00000013, 0x00000543, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_INST_ISSUED0}, //"warp_cant_issue_mio_throttle"
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_DISPATCH_STALL, pascal_sm_warp_cant_issue_true_dispatch_stall_enc_str_1, 0x00000014, 0x00000210, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_INST_ISSUED0}, //"warp_cant_issue_dispatch_stall"
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_NOT_SELECTED, pascal_sm_warp_cant_issue_true_not_selected_enc_str_1, 0x00000014, 0x00000543, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_INST_ISSUED0}, //"warp_cant_issue_not_selected"
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_ON_DECK_LONG_SCOREBOARD, pascal_sm_warp_cant_issue_true_on_deck_long_scoreboard_enc_str_1, 0x00000015, 0x00000210, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_INST_ISSUED0}, //"warp_cant_issue_on_deck_long_scoreboard"
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_ON_DECK_MISC, pascal_sm_warp_cant_issue_true_on_deck_misc_enc_str_1, 0x00000015, 0x00000543, 0x00000007, PM_UNIT_SMQCTL, 3, PASCAL_SM_INST_ISSUED0}, //"warp_cant_issue_on_deck_misc"
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_SELECTED, pascal_sm_warp_cant_issue_true_selected_enc_str_1, 0x00000016, 0x00000000, 0x00000001, PM_UNIT_SMQCTL, 1, PASCAL_SM_INST_ISSUED0}, //"warp_cant_issue_selected"
    { INVALID_PM_SIGNAL_NEW,            "",                       0xffffffff, 0x00000000, 0x00000000,     PM_UNIT_MAX,0 }
};

PerfSignalSmpc PerfSignalTableGP100_sm0_quad_extended[] = {
    //For SM virtual quad signal can be exposed as active_warps.
    { PASCAL_ACTIVE_WARPS_CORE_SM_VIRTUAL, pascal_sm_active_warps_enc_str_1, 0x00000002, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"active_warps"
    { INVALID_PM_SIGNAL_NEW,            "",                       0xffffffff, 0x00000000, 0x00000000,     PM_UNIT_MAX,0 }
};

PerfSignalSmpc PerfSignalTableGP10X_sm0_quad_extended[] = {
    { PASCAL_SM_ACTIVE_WARPS_QUAD, pascal_sm_active_warps_sctl_enc_str_1, 0x00000002, 0x00543210, 0x0000003f, PM_UNIT_SMQCTL, 6, PASCAL_SM_NOT_IN_TRAP_QUAD}, //"active_warps"
    { INVALID_PM_SIGNAL_NEW,            "",                       0xffffffff, 0x00000000, 0x00000000,     PM_UNIT_MAX,0 }
};

PerfSignalSmpc PerfSignalTableGP100_sm0_coremio[] = {
    //CORE/MIO Signals:
    { PASCAL_SM_NON_IDLE_CORE, pascal_sm_non_idle_core_enc_str_1, 0x00000000, 0x00000000, 0x00000001, PM_UNIT_SMCORE, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"non_idle_core"
    { PASCAL_SM_ACTIVE_CYCLES_CORE_UNFILTERED, pascal_sm_active_cycles_core_unfiltered_enc_str_1, 0x00000000, 0x00000001, 0x00000001, PM_UNIT_SMCORE, 1 }, //"active_cycles_core_unfiltered"
    { PASCAL_SM_ACTIVE_CYCLES_IN_TRAP, pascal_sm_active_cycles_in_trap_enc_str_1, 0x00000000, 0x00000001, 0x00000001, PM_UNIT_SMCORE, 1, PASCAL_SM_TRAP_IN_TRAP_CORE }, //"active_cycles"
    { PASCAL_SM_ACTIVE_CTAS, pascal_sm_active_ctas_enc_str_1, 0x00000001, 0x00543210, 0x0000003f, PM_UNIT_SMCORE, 6, PASCAL_SM_NOT_IN_TRAP_CORE }, //"active_ctas"
    { PASCAL_SM_SM_CTA_LAUNCHED, pascal_sm_sm_cta_launched_enc_str_1, 0x00000001, 0x00000006, 0x00000001, PM_UNIT_SMCORE, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"sm_cta_launched"
    { PASCAL_SM_ACTIVE_WARPS_PS, pascal_sm_active_warps_ps_enc_str_1, 0x00000002, 0x00543210, 0x0000003f, PM_UNIT_SMCORE, 6, PASCAL_SM_NOT_IN_TRAP_CORE }, //"active_warps_ps"
    { PASCAL_SM_ACTIVE_WARPS_VTG, pascal_sm_active_warps_vtg_enc_str_1, 0x00000003, 0x00543210, 0x0000003f, PM_UNIT_SMCORE, 6, PASCAL_SM_NOT_IN_TRAP_CORE }, //"active_warps_vtg"
    { PASCAL_SM_ACTIVE_SUBTILES, pascal_sm_active_subtiles_enc_str_1, 0x00000004, 0x00543210, 0x0000003f, PM_UNIT_SMCORE, 6, PASCAL_SM_NOT_IN_TRAP_CORE }, //"active_subtiles"
    { PASCAL_SM_SUBTILES_LAUNCHED_H0, pascal_sm_subtiles_launched_h0_enc_str_1, 0x00000004, 0x00000006, 0x00000001, PM_UNIT_SMCORE, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"subtiles_launched_h0"
    { PASCAL_SM_SUBTILES_LAUNCHED_H1, pascal_sm_subtiles_launched_h1_enc_str_1, 0x00000004, 0x00000007, 0x00000001, PM_UNIT_SMCORE, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"subtiles_launched_h1"
    { PASCAL_SM_TRAP_COALESCING, pascal_sm_trap_coalescing_enc_str_1, 0x00000005, 0x00000000, 0x00000001, PM_UNIT_SMCORE, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"trap_coalescing"
    { PASCAL_SM_TRAP_COUNT, pascal_sm_trap_count_enc_str_1, 0x00000005, 0x00000001, 0x00000001, PM_UNIT_SMCORE, 1 }, //"trap_count"
    { PASCAL_SM_TRAP_IDLING_FOR_TRAP, pascal_sm_trap_idling_for_trap_enc_str_1, 0x00000005, 0x00000002, 0x00000001, PM_UNIT_SMCORE, 1 }, //"trap_idling_for_trap"
    { PASCAL_SM_TRAP_IN_TRAP_CORE, pascal_sm_trap_in_trap_core_enc_str_1, 0x00000005, 0x00000003, 0x00000001, PM_UNIT_SMCORE, 1 }, //"trap_in_trap"
    { PASCAL_SM_TRAP_CLEARING_IDE, pascal_sm_trap_clearing_ide_enc_str_1, 0x00000005, 0x00000004, 0x00000001, PM_UNIT_SMCORE, 1 }, //"trap_clearing_ide"
    { PASCAL_SM_TRAP_WAITING_FOR_IDE, pascal_sm_trap_waiting_for_ide_enc_str_1, 0x00000005, 0x00000005, 0x00000001, PM_UNIT_SMCORE, 1 }, //"trap_waiting_for_ide"
    { PASCAL_SM_ICC_HIT, pascal_sm_icc_hit_enc_str_1, 0x00000006, 0x00000000, 0x00000001, PM_UNIT_SMCORE, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"icc_hit"
    { PASCAL_SM_ICC_TRUE_MISS, pascal_sm_icc_true_miss_enc_str_1, 0x00000006, 0x00000001, 0x00000001, PM_UNIT_SMCORE, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"icc_true_miss"
    { PASCAL_SM_ICC_COVERED_MISS, pascal_sm_icc_covered_miss_enc_str_1, 0x00000006, 0x00000002, 0x00000001, PM_UNIT_SMCORE, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"icc_covered_miss"
    { PASCAL_SM_ICC_FULL_TAG, pascal_sm_icc_full_tag_enc_str_1, 0x00000006, 0x00000003, 0x00000001, PM_UNIT_SMCORE, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"icc_full_tag"
    { PASCAL_SM_ICC_PREFETCHES, pascal_sm_icc_prefetches_enc_str_1, 0x00000006, 0x00000004, 0x00000001, PM_UNIT_SMCORE, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"icc_prefetches"
    { PASCAL_SM_ICC_UNLOCK_ALL, pascal_sm_icc_unlock_all_enc_str_1, 0x00000006, 0x00000005, 0x00000001, PM_UNIT_SMCORE, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"icc_unlock_all"
    { PASCAL_SM_ICC_MISSES_OUTSTANDING, pascal_sm_icc_misses_outstanding_enc_str_1, 0x00000007, 0x00003210, 0x0000000f, PM_UNIT_SMCORE, 4, PASCAL_SM_NOT_IN_TRAP_CORE }, //"icc_misses_outstanding"
    { PASCAL_SM_SCG_MODE_COMPUTE_CORE, pascal_sm_scg_mode_compute_core_enc_str_1, 0x00000008, 0x00000000, 0x00000001, PM_UNIT_SMCORE, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"scg_mode_compute"
    { PASCAL_SM_SCG_MODE_GRAPHICS_CORE, pascal_sm_scg_mode_graphics_core_enc_str_1, 0x00000008, 0x00000001, 0x00000001, PM_UNIT_SMCORE, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"scg_mode_graphics"
    { PASCAL_SM_NOT_IN_TRAP_CORE, pascal_sm_not_in_trap_core_enc_str_1, 0x00000008, 0x00000002, 0x00000001, PM_UNIT_SMCORE, 1 }, //"sm_not_in_trap"
    { PASCAL_SM_GROUP9_PLACEHOLDER, pascal_sm_group9_placeholder_enc_str_1, 0x00000009, 0x76543210, 0x000000ff, PM_UNIT_SMCORE, 8 }, //"group9_placeholder"
    { PASCAL_SM_CORE_HW_PM_MUX_LOWER, pascal_sm_core_hw_pm_mux_lower_enc_str_1, 0x0000001c, 0x76543210, 0x000000ff, PM_UNIT_SMCORE, 8 }, //"core_hw_pm_mux_lower"
    { PASCAL_SM_CORE_HW_PM_MUX_UPPER, pascal_sm_core_hw_pm_mux_upper_enc_str_1, 0x0000001d, 0x76543210, 0x000000ff, PM_UNIT_SMCORE, 8 }, //"core_hw_pm_mux_upper"
    { PASCAL_SM_IDC_HIT, pascal_sm_idc_hit_enc_str_1, 0x0000000e, 0x00000000, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"idc_hit"
    { PASCAL_SM_IDC_FULL_TAG, pascal_sm_idc_full_tag_enc_str_1, 0x0000000e, 0x00000001, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"idc_full_tag"
    { PASCAL_SM_IDC_TRUE_MISS, pascal_sm_idc_true_miss_enc_str_1, 0x0000000e, 0x00000002, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"idc_true_miss"
    { PASCAL_SM_IDC_COVERED_MISS, pascal_sm_idc_covered_miss_enc_str_1, 0x0000000e, 0x00000003, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"idc_covered_miss"
    { PASCAL_SM_MEMBAR_EXECUTED, pascal_sm_membar_executed_enc_str_1, 0x0000000f, 0x00000000, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"membar_executed"
    { PASCAL_SM_MEMBAR_PENDING, pascal_sm_membar_pending_enc_str_1, 0x0000000f, 0x00000001, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"membar_pending"
    { PASCAL_SM_MEMBAR_SENT_TO_TEX, pascal_sm_membar_sent_to_tex_enc_str_1, 0x0000000f, 0x00000002, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"membar_sent_to_tex"
    { PASCAL_SM_MEMBAR_CTA_SYNTHETIC, pascal_sm_membar_cta_synthetic_enc_str_1, 0x0000000f, 0x00000005, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"membar_cta_synthetic"
    { PASCAL_SM_PIXOUT_QUADS_DRAINED, pascal_sm_pixout_quads_drained_enc_str_1, 0x00000010, 0x00000010, 0x00000003, PM_UNIT_MIO, 2, PASCAL_SM_NOT_IN_TRAP_CORE }, //"pixout_quads_drained"
    { PASCAL_SM_HALF_WARPS_KILLED_BY_SHADER, pascal_sm_half_warps_killed_by_shader_enc_str_1, 0x00000010, 0x00000032, 0x00000003, PM_UNIT_MIO, 2, PASCAL_SM_NOT_IN_TRAP_CORE }, //"half_warps_killed_by_shader"
    { PASCAL_SM_QUADS_KILLED_BY_SHADER, pascal_sm_quads_killed_by_shader_enc_str_1, 0x00000010, 0x00007654, 0x0000000f, PM_UNIT_MIO, 4, PASCAL_SM_NOT_IN_TRAP_CORE }, //"quads_killed_by_shader"
    { PASCAL_SM_WARPS_KILLED_BY_SHADER, pascal_sm_warps_killed_by_shader_enc_str_1, 0x00000011, 0x00000000, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"warps_killed_by_shader"
    { PASCAL_SM_PIXELS_KILLED_SHADERCOVG, pascal_sm_pixels_killed_shadercovg_enc_str_1, 0x00000011, 0x00654321, 0x0000003f, PM_UNIT_MIO, 6, PASCAL_SM_NOT_IN_TRAP_CORE }, //"pixels_killed_shadercovg"
    { PASCAL_SM_SM2GPM_OUTPUT_STALL, pascal_sm_sm2gpm_output_stall_enc_str_1, 0x00000011, 0x00000007, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"sm2gpm_output_stall"
    { PASCAL_SM_IDC_MISSES_OUTSTANDING, pascal_sm_idc_misses_outstanding_enc_str_1, 0x00000016, 0x00000654, 0x00000007, PM_UNIT_MIO, 3, PASCAL_SM_NOT_IN_TRAP_CORE }, //"idc_misses_outstanding"
    { PASCAL_SM_MIO_HW_PM_MUX_LOWER, pascal_sm_mio_hw_pm_mux_lower_enc_str_1, 0x0000001e, 0x76543210, 0x000000ff, PM_UNIT_MIO, 8 }, //"mio_hw_pm_mux_lower"
    { PASCAL_SM_MIO_HW_PM_MUX_UPPER, pascal_sm_mio_hw_pm_mux_upper_enc_str_1, 0x0000001f, 0x76543210, 0x000000ff, PM_UNIT_MIO, 8 }, //"mio_hw_pm_mux_upper"
    { INVALID_PM_SIGNAL_NEW,            "",                       0xffffffff, 0x00000000, 0x00000000,     PM_UNIT_MAX,0 }
};

PerfSignalSmpc PerfSignalTableGP100_sm0_coremio_extended[] = {
    { PASCAL_ACTIVE_CYCLES_CORE_SM_PHYSICAL, pascal_active_cycles_core_sm_physical_enc_str_1, 0x00000000, 0x00000001, 0x00000001, PM_UNIT_SMCORE, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"active_cycles"
    { PASCAL_ACTIVE_WARPS_CORE_SM_PHYSICAL, pascal_active_warps_core_sm_physical_enc_str_1, 0x00000000, 0x00765432, 0x0000003f, PM_UNIT_SMCORE, 6, PASCAL_SM_NOT_IN_TRAP_CORE }, //"active_warps"
    { INVALID_PM_SIGNAL_NEW,            "",                       0xffffffff, 0x00000000, 0x00000000,     PM_UNIT_MAX,0 }
};

PerfSignalSmpc PerfSignalTableGP10X_sm0_coremio_extended[] = {
    { PASCAL_SM_ACTIVE_CYCLES, pascal_sm_active_cycles_enc_str_1, 0x00000000, 0x00000001, 0x00000001, PM_UNIT_SMCORE, 1, PASCAL_SM_NOT_IN_TRAP_CORE }, //"active_cycles"
    { PASCAL_SM_ACTIVE_WARPS, pascal_sm_active_warps_enc_str_1, 0x00000000, 0x00765432, 0x0000003f, PM_UNIT_SMCORE, 6, PASCAL_SM_NOT_IN_TRAP_CORE }, //"active_warps"
    { INVALID_PM_SIGNAL_NEW,            "",                       0xffffffff, 0x00000000, 0x00000000,     PM_UNIT_MAX,0 }
};

PerfSignalSmpc PerfSignalTableGP100_sm0_mio[] = {
    //MIO Signals:
    { PASCAL_SM_SHARED_LD_BANK_CONFLICT_H0, pascal_sm_shared_ld_bank_conflict_h0_enc_str_1, 0x0000000a, 0x00000000, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"shared_ld_bank_conflict_h0"
    { PASCAL_SM_SHARED_ST_BANK_CONFLICT_H0, pascal_sm_shared_st_bank_conflict_h0_enc_str_1, 0x0000000a, 0x00000001, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"shared_st_bank_conflict_h0"
    { PASCAL_SM_SHARED_LOAD_TRANSACTIONS_H0, pascal_sm_shared_ld_transactions_h0_enc_str_1, 0x0000000a, 0x00000002, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"shared_load_transactions_h0"
    { PASCAL_SM_SHARED_STORE_TRANSACTIONS_H0, pascal_sm_shared_st_transactions_h0_enc_str_1, 0x0000000a, 0x00000003, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"shared_store_transactions_h0"
    { PASCAL_SM_PQ_WRITE_Q0, pascal_sm_pq_write_q0_enc_str_1, 0x0000000a, 0x00000004, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_write_q0"
    { PASCAL_SM_PQ_WRITE_Q1, pascal_sm_pq_write_q1_enc_str_1, 0x0000000a, 0x00000005, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_write_q1"
    { PASCAL_SM_ADU_REPLAY_Q0, pascal_sm_adu_replay_q0_enc_str_1, 0x0000000a, 0x00000006, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"adu_replay_q0"
    { PASCAL_SM_ADU_REPLAY_Q1, pascal_sm_adu_replay_q1_enc_str_1, 0x0000000a, 0x00000007, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"adu_replay_q1"
    { PASCAL_SM_SHARED_LD_BANK_CONFLICT_H1, pascal_sm_shared_ld_bank_conflict_h1_enc_str_1, 0x0000000b, 0x00000000, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"shared_ld_bank_conflict_h1"
    { PASCAL_SM_SHARED_ST_BANK_CONFLICT_H1, pascal_sm_shared_st_bank_conflict_h1_enc_str_1, 0x0000000b, 0x00000001, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"shared_st_bank_conflict_h1"
    { PASCAL_SM_SHARED_LOAD_TRANSACTIONS_H1, pascal_sm_shared_ld_transactions_h1_enc_str_1, 0x0000000b, 0x00000002, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"shared_load_h1"
    { PASCAL_SM_SHARED_STORE_TRANSACTIONS_H1, pascal_sm_shared_st_transactions_h1_enc_str_1, 0x0000000b, 0x00000003, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"shared_store_h1"
    { PASCAL_SM_PQ_WRITE_Q2, pascal_sm_pq_write_q2_enc_str_1, 0x0000000b, 0x00000004, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_write_q2"
    { PASCAL_SM_PQ_WRITE_Q3, pascal_sm_pq_write_q3_enc_str_1, 0x0000000b, 0x00000005, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_write_q3"
    { PASCAL_SM_ADU_REPLAY_Q2, pascal_sm_adu_replay_q2_enc_str_1, 0x0000000b, 0x00000006, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"adu_replay_q2"
    { PASCAL_SM_ADU_REPLAY_Q3, pascal_sm_adu_replay_q3_enc_str_1, 0x0000000b, 0x00000007, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"adu_replay_q3"
    { PASCAL_SM_PQ_READS_FOR_SHM_Q0, pascal_sm_pq_reads_for_shm_q0_enc_str_1, 0x0000000c, 0x00000000, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_reads_for_shm_q0"
    { PASCAL_SM_PQ_READS_FOR_PIXOUT_Q0, pascal_sm_pq_reads_for_pixout_q0_enc_str_1, 0x0000000c, 0x00000001, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_reads_for_pixout_q0"
    { PASCAL_SM_PQ_READS_FOR_TEX_Q0, pascal_sm_pq_reads_for_tex_q0_enc_str_1, 0x0000000c, 0x00000002, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_reads_for_tex_q0"
    { PASCAL_SM_PQ_READS_FOR_SHM_STOLEN_Q0, pascal_sm_pq_reads_for_shm_stolen_q0_enc_str_1, 0x0000000c, 0x00000003, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_reads_for_shm_stolen_q0"
    { PASCAL_SM_PQ_READS_FOR_SHM_Q1, pascal_sm_pq_reads_for_shm_q1_enc_str_1, 0x0000000c, 0x00000004, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_reads_for_shm_q1"
    { PASCAL_SM_PQ_READS_FOR_PIXOUT_Q1, pascal_sm_pq_reads_for_pixout_q1_enc_str_1, 0x0000000c, 0x00000005, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_reads_for_pixout_q1"
    { PASCAL_SM_PQ_READS_FOR_TEX_Q1, pascal_sm_pq_reads_for_tex_q1_enc_str_1, 0x0000000c, 0x00000006, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_reads_for_tex_q1"
    { PASCAL_SM_PQ_READS_FOR_SHM_STOLEN_Q1, pascal_sm_pq_reads_for_shm_stolen_q1_enc_str_1, 0x0000000c, 0x00000007, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_reads_for_shm_stolen_q1"
    { PASCAL_SM_PQ_READS_FOR_SHM_Q2, pascal_sm_pq_reads_for_shm_q2_enc_str_1, 0x0000000d, 0x00000000, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_reads_for_shm_q2"
    { PASCAL_SM_PQ_READS_FOR_PIXOUT_Q2, pascal_sm_pq_reads_for_pixout_q2_enc_str_1, 0x0000000d, 0x00000001, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_reads_for_pixout_q2"
    { PASCAL_SM_PQ_READS_FOR_TEX_Q2, pascal_sm_pq_reads_for_tex_q2_enc_str_1, 0x0000000d, 0x00000002, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_reads_for_tex_q2"
    { PASCAL_SM_PQ_READS_FOR_SHM_STOLEN_Q2, pascal_sm_pq_reads_for_shm_stolen_q2_enc_str_1, 0x0000000d, 0x00000003, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_reads_for_shm_stolen_q2"
    { PASCAL_SM_PQ_READS_FOR_SHM_Q3, pascal_sm_pq_reads_for_shm_q3_enc_str_1, 0x0000000d, 0x00000004, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_reads_for_shm_q3"
    { PASCAL_SM_PQ_READS_FOR_PIXOUT_Q3, pascal_sm_pq_reads_for_pixout_q3_enc_str_1, 0x0000000d, 0x00000005, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_reads_for_pixout_q3"
    { PASCAL_SM_PQ_READS_FOR_TEX_Q3, pascal_sm_pq_reads_for_tex_q3_enc_str_1, 0x0000000d, 0x00000006, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_reads_for_tex_q3"
    { PASCAL_SM_PQ_READS_FOR_SHM_STOLEN_Q3, pascal_sm_pq_reads_for_shm_stolen_q3_enc_str_1, 0x0000000d, 0x00000007, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_reads_for_shm_stolen_q3"
    { PASCAL_SM_IDC_DIVERGENCE_REPLAY_Q0, pascal_sm_idc_divergence_replay_q0_enc_str_1, 0x0000000e, 0x00000004, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"idc_divergence_replay_q0"
    { PASCAL_SM_IDC_DIVERGENT_INSTRUCTION_Q0, pascal_sm_idc_divergent_instruction_q0_enc_str_1, 0x0000000e, 0x00000005, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"idc_divergent_instruction_q0"
    { PASCAL_SM_IDC_DIVERGENCE_REPLAY_Q1, pascal_sm_idc_divergence_replay_q1_enc_str_1, 0x0000000e, 0x00000006, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"idc_divergence_replay_q1"
    { PASCAL_SM_IDC_DIVERGENT_INSTRUCTION_Q1, pascal_sm_idc_divergent_instruction_q1_enc_str_1, 0x0000000e, 0x00000007, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"idc_divergent_instruction_q1"
    { PASCAL_SM_MEMBAR_CTA_SENT_TO_TEX_H0, pascal_sm_membar_cta_sent_to_tex_h0_enc_str_1, 0x0000000f, 0x00000003, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"membar_cta_sent_to_tex_h0"
    { PASCAL_SM_MEMBAR_CTA_SENT_TO_TEX_H1, pascal_sm_membar_cta_sent_to_tex_h1_enc_str_1, 0x0000000f, 0x00000004, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"membar_cta_sent_to_tex_h1"
    { PASCAL_SM_LSU_BUSY_H0, pascal_sm_lsu_busy_h0_enc_str_1, 0x0000000f, 0x00000006, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"lsu_busy_h0"
    { PASCAL_SM_LSU_BUSY_H1, pascal_sm_lsu_busy_h1_enc_str_1, 0x0000000f, 0x00000007, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"lsu_busy_h1"
    { PASCAL_SM_MIO_ISBE_WRITE_H0, pascal_sm_mio_isbe_write_h0_enc_str_1, 0x00000012, 0x00000000, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"mio_isbe_write_h0"
    { PASCAL_SM_MIO_ISBE_READ_H0, pascal_sm_mio_isbe_read_h0_enc_str_1, 0x00000012, 0x00000001, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"mio_isbe_read_h0"
    { PASCAL_SM_MIO_SM_STALLED_DUE_TO_PE_Q0, pascal_sm_mio_sm_stalled_due_to_pe_q0_enc_str_1, 0x00000012, 0x00000002, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"mio_sm_stalled_due_to_pe_q0"
    { PASCAL_SM_MIO_SM_STALLED_DUE_TO_PE_Q1, pascal_sm_mio_sm_stalled_due_to_pe_q1_enc_str_1, 0x00000012, 0x00000003, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"mio_sm_stalled_due_to_pe_q1"
    { PASCAL_SM_MIO_ISBE_WRITE_H1, pascal_sm_mio_isbe_write_h1_enc_str_1, 0x00000012, 0x00000004, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"mio_isbe_write_h1"
    { PASCAL_SM_MIO_ISBE_READ_H1, pascal_sm_mio_isbe_read_h1_enc_str_1, 0x00000012, 0x00000005, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"mio_isbe_read_h1"
    { PASCAL_SM_MIO_SM_STALLED_DUE_TO_PE_Q2, pascal_sm_mio_sm_stalled_due_to_pe_q2_enc_str_1, 0x00000012, 0x00000006, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"mio_sm_stalled_due_to_pe_q2"
    { PASCAL_SM_MIO_SM_STALLED_DUE_TO_PE_Q3, pascal_sm_mio_sm_stalled_due_to_pe_q3_enc_str_1, 0x00000012, 0x00000007, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"mio_sm_stalled_due_to_pe_q3"
    { PASCAL_SM_PE2MIO_ISBE_READ_REQ_H0, pascal_sm_pe2mio_isbe_read_req_h0_enc_str_1, 0x00000013, 0x00000000, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pe2mio_isbe_read_req_h0"
    { PASCAL_SM_PE2MIO_ISBE_WRITE_REQ_H0, pascal_sm_pe2mio_isbe_write_req_h0_enc_str_1, 0x00000013, 0x00000001, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pe2mio_isbe_write_req_h0"
    { PASCAL_SM_PE2MIO_TRAM_WRITE_H0, pascal_sm_pe2mio_tram_write_h0_enc_str_1, 0x00000013, 0x00000002, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pe2mio_tram_write_h0"
    { PASCAL_SM_PE_ISBE_WR_DELAYED_DUE_TO_CAMPING_H0, pascal_sm_pe_isbe_wr_delayed_due_to_camping_h0_enc_str_1, 0x00000013, 0x00000003, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pe_isbe_wr_delayed_due_to_camping_h0"
    { PASCAL_SM_PE_TRAM_WR_DELAYED_AND_LOST_THROUGHPUT_H0, pascal_sm_pe_tram_wr_delayed_and_lost_throughput_h0_enc_str_1, 0x00000013, 0x00000004, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pe_tram_wr_delayed_and_lost_throughput_h0"
    { PASCAL_SM_PE_TRAM_WR_DELAYED_DUE_TO_CAMPING_H0, pascal_sm_pe_tram_wr_delayed_due_to_camping_h0_enc_str_1, 0x00000013, 0x00000005, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pe_tram_wr_delayed_due_to_camping_h0"
    { PASCAL_SM_PE2MIO_ISBE_READ_REQ_H1, pascal_sm_pe2mio_isbe_read_req_h1_enc_str_1, 0x00000013, 0x00000006, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pe2mio_isbe_read_req_h1"
    { PASCAL_SM_PE2MIO_ISBE_WRITE_REQ_H1, pascal_sm_pe2mio_isbe_write_req_h1_enc_str_1, 0x00000013, 0x00000007, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pe2mio_isbe_write_req_h1"
    { PASCAL_SM_PE2MIO_TRAM_WRITE_H1, pascal_sm_pe2mio_tram_write_h1_enc_str_1, 0x00000014, 0x00000000, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pe2mio_tram_write_h1"
    { PASCAL_SM_PE_ISBE_WR_DELAYED_DUE_TO_CAMPING_H1, pascal_sm_pe_isbe_wr_delayed_due_to_camping_h1_enc_str_1, 0x00000014, 0x00000001, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pe_isbe_wr_delayed_due_to_camping_h1"
    { PASCAL_SM_PE_TRAM_WR_DELAYED_AND_LOST_THROUGHPUT_H1, pascal_sm_pe_tram_wr_delayed_and_lost_throughput_h1_enc_str_1, 0x00000014, 0x00000002, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pe_tram_wr_delayed_and_lost_throughput_h1"
    { PASCAL_SM_PE_TRAM_WR_DELAYED_DUE_TO_CAMPING_H1, pascal_sm_pe_tram_wr_delayed_due_to_camping_h1_enc_str_1, 0x00000014, 0x00000003, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pe_tram_wr_delayed_due_to_camping_h1"
    { PASCAL_SM_SMM2TEX_DATA_LG_COUNT_H0, pascal_sm_smm2tex_data_lg_count_h0_enc_str_1, 0x00000014, 0x00000004, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"smm2tex_data_lg_count_h0"
    { PASCAL_SM_SMM2TEX_DATA_TEX_COUNT_H0, pascal_sm_smm2tex_data_tex_count_h0_enc_str_1, 0x00000014, 0x00000005, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"smm2tex_data_tex_count_h0"
    { PASCAL_SM_SMM2TEX_DATA_LG_COUNT_H1, pascal_sm_smm2tex_data_lg_count_h1_enc_str_1, 0x00000014, 0x00000006, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"smm2tex_data_lg_count_h1"
    { PASCAL_SM_SMM2TEX_DATA_TEX_COUNT_H1, pascal_sm_smm2tex_data_tex_count_h1_enc_str_1, 0x00000014, 0x00000007, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"smm2tex_data_tex_count_h1"
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_ADU_OVER_SHM_Q0, pascal_sm_mio_cant_dispatch_lsu_adu_over_shm_q0_enc_str_1, 0x00000015, 0x00000000, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"mio_cant_dispatch_lsu_adu_over_shm_q0"
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_ADU_Q0, pascal_sm_mio_cant_dispatch_lsu_pixout_over_adu_q0_enc_str_1, 0x00000015, 0x00000001, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"mio_cant_dispatch_lsu_pixout_over_adu_q0"
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_SHM_Q0, pascal_sm_mio_cant_dispatch_lsu_pixout_over_shm_q0_enc_str_1, 0x00000015, 0x00000002, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"mio_cant_dispatch_lsu_pixout_over_shm_q0"
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_ADU_OVER_SHM_Q1, pascal_sm_mio_cant_dispatch_lsu_adu_over_shm_q1_enc_str_1, 0x00000015, 0x00000003, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"mio_cant_dispatch_lsu_adu_over_shm_q1"
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_ADU_Q1, pascal_sm_mio_cant_dispatch_lsu_pixout_over_adu_q1_enc_str_1, 0x00000015, 0x00000004, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"mio_cant_dispatch_lsu_pixout_over_adu_q1"
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_SHM_Q1, pascal_sm_mio_cant_dispatch_lsu_pixout_over_shm_q1_enc_str_1, 0x00000015, 0x00000005, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"mio_cant_dispatch_lsu_pixout_over_shm_q1"
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_ADU_OVER_SHM_Q2, pascal_sm_mio_cant_dispatch_lsu_adu_over_shm_q2_enc_str_1, 0x00000015, 0x00000006, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"mio_cant_dispatch_lsu_adu_over_shm_q2"
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_ADU_Q2, pascal_sm_mio_cant_dispatch_lsu_pixout_over_adu_q2_enc_str_1, 0x00000015, 0x00000007, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"mio_cant_dispatch_lsu_pixout_over_adu_q2"
    { PASCAL_SM_IDC_DIVERGENCE_REPLAY_Q2, pascal_sm_idc_divergence_replay_q2_enc_str_1, 0x00000016, 0x00000000, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"idc_divergence_replay_q2"
    { PASCAL_SM_IDC_DIVERGENT_INSTRUCTION_Q2, pascal_sm_idc_divergent_instruction_q2_enc_str_1, 0x00000016, 0x00000001, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"idc_divergent_instruction_q2"
    { PASCAL_SM_IDC_DIVERGENCE_REPLAY_Q3, pascal_sm_idc_divergence_replay_q3_enc_str_1, 0x00000016, 0x00000002, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"idc_divergence_replay_q3"
    { PASCAL_SM_IDC_DIVERGENT_INSTRUCTION_Q3, pascal_sm_idc_divergent_instruction_q3_enc_str_1, 0x00000016, 0x00000003, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"idc_divergent_instruction_q3"
    { PASCAL_SM_PQ_FULL_Q0, pascal_sm_pq_full_q0_enc_str_1, 0x00000017, 0x00000000, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_full_q0"
    { PASCAL_SM_PQ_FULL_Q1, pascal_sm_pq_full_q1_enc_str_1, 0x00000017, 0x00000001, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_full_q1"
    { PASCAL_SM_PIX_PQ_FULL_Q0, pascal_sm_pix_pq_full_q0_enc_str_1, 0x00000017, 0x00000002, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pix_pq_full_q0"
    { PASCAL_SM_PIX_PQ_FULL_Q1, pascal_sm_pix_pq_full_q1_enc_str_1, 0x00000017, 0x00000003, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pix_pq_full_q1"
    { PASCAL_SM_SHM_PQ_FULL_Q0, pascal_sm_shm_pq_full_q0_enc_str_1, 0x00000017, 0x00000004, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"shm_pq_full_q0"
    { PASCAL_SM_SHM_PQ_FULL_Q1, pascal_sm_shm_pq_full_q1_enc_str_1, 0x00000017, 0x00000005, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"shm_pq_full_q1"
    { PASCAL_SM_TEX_PQ_FULL_Q0, pascal_sm_tex_pq_full_q0_enc_str_1, 0x00000017, 0x00000006, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"tex_pq_full_q0"
    { PASCAL_SM_TEX_PQ_FULL_Q1, pascal_sm_tex_pq_full_q1_enc_str_1, 0x00000017, 0x00000007, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"tex_pq_full_q1"
    { PASCAL_SM_PQ_FULL_Q2, pascal_sm_pq_full_q2_enc_str_1, 0x00000018, 0x00000000, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_full_q2"
    { PASCAL_SM_PQ_FULL_Q3, pascal_sm_pq_full_q3_enc_str_1, 0x00000018, 0x00000001, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_full_q3"
    { PASCAL_SM_PIX_PQ_FULL_Q2, pascal_sm_pix_pq_full_q2_enc_str_1, 0x00000018, 0x00000002, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pix_pq_full_q2"
    { PASCAL_SM_PIX_PQ_FULL_Q3, pascal_sm_pix_pq_full_q3_enc_str_1, 0x00000018, 0x00000003, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pix_pq_full_q3"
    { PASCAL_SM_SHM_PQ_FULL_Q2, pascal_sm_shm_pq_full_q2_enc_str_1, 0x00000018, 0x00000004, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"shm_pq_full_q2"
    { PASCAL_SM_SHM_PQ_FULL_Q3, pascal_sm_shm_pq_full_q3_enc_str_1, 0x00000018, 0x00000005, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"shm_pq_full_q3"
    { PASCAL_SM_TEX_PQ_FULL_Q2, pascal_sm_tex_pq_full_q2_enc_str_1, 0x00000018, 0x00000006, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"tex_pq_full_q2"
    { PASCAL_SM_TEX_PQ_FULL_Q3, pascal_sm_tex_pq_full_q3_enc_str_1, 0x00000018, 0x00000007, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"tex_pq_full_q3"
    { PASCAL_SM_PQ_WRITE_BACK_LSU_STALL_H0, pascal_sm_pq_write_back_lsu_stall_h0_enc_str_1, 0x00000019, 0x00000000, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_write_back_lsu_stall_h0"
    { PASCAL_SM_PQ_WRITE_BACK_TEX_STALL_H0, pascal_sm_pq_write_back_tex_stall_h0_enc_str_1, 0x00000019, 0x00000001, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_write_back_tex_stall_h0"
    { PASCAL_SM_PQ_WRITE_BACK_LSU_STALL_H1, pascal_sm_pq_write_back_lsu_stall_h1_enc_str_1, 0x00000019, 0x00000002, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_write_back_lsu_stall_h1"
    { PASCAL_SM_PQ_WRITE_BACK_TEX_STALL_H1, pascal_sm_pq_write_back_tex_stall_h1_enc_str_1, 0x00000019, 0x00000003, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pq_write_back_tex_stall_h1"
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_SHM_Q2, pascal_sm_mio_cant_dispatch_lsu_pixout_over_shm_q2_enc_str_1, 0x00000019, 0x00000004, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"mio_cant_dispatch_lsu_pixout_over_shm_q2"
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_ADU_OVER_SHM_Q3, pascal_sm_mio_cant_dispatch_lsu_adu_over_shm_q3_enc_str_1, 0x00000019, 0x00000005, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"mio_cant_dispatch_lsu_adu_over_shm_q3"
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_ADU_Q3, pascal_sm_mio_cant_dispatch_lsu_pixout_over_adu_q3_enc_str_1, 0x00000019, 0x00000006, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"mio_cant_dispatch_lsu_pixout_over_adu_q3"
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_SHM_Q3, pascal_sm_mio_cant_dispatch_lsu_pixout_over_shm_q3_enc_str_1, 0x00000019, 0x00000007, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"mio_cant_dispatch_lsu_pixout_over_shm_q3"
    { PASCAL_SM_LSU_IQ_FIFO_FULL_Q0, pascal_sm_lsu_iq_fifo_full_q0_enc_str_1, 0x0000001a, 0x00000000, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"lsu_iq_fifo_full_q0"
    { PASCAL_SM_TEX_IQ_FIFO_FULL_Q0, pascal_sm_tex_iq_fifo_full_q0_enc_str_1, 0x0000001a, 0x00000001, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"tex_iq_fifo_full_q0"
    { PASCAL_SM_PIX_IQ_FIFO_FULL_Q0, pascal_sm_pix_iq_fifo_full_q0_enc_str_1, 0x0000001a, 0x00000002, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pix_iq_fifo_full_q0"
    { PASCAL_SM_RTY_IQ_FIFO_FULL_Q0, pascal_sm_rty_iq_fifo_full_q0_enc_str_1, 0x0000001a, 0x00000003, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"rty_iq_fifo_full_q0"
    { PASCAL_SM_LSU_IQ_FIFO_FULL_Q1, pascal_sm_lsu_iq_fifo_full_q1_enc_str_1, 0x0000001a, 0x00000004, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"lsu_iq_fifo_full_q1"
    { PASCAL_SM_TEX_IQ_FIFO_FULL_Q1, pascal_sm_tex_iq_fifo_full_q1_enc_str_1, 0x0000001a, 0x00000005, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"tex_iq_fifo_full_q1"
    { PASCAL_SM_PIX_IQ_FIFO_FULL_Q1, pascal_sm_pix_iq_fifo_full_q1_enc_str_1, 0x0000001a, 0x00000006, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pix_iq_fifo_full_q1"
    { PASCAL_SM_RTY_IQ_FIFO_FULL_Q1, pascal_sm_rty_iq_fifo_full_q1_enc_str_1, 0x0000001a, 0x00000007, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"rty_iq_fifo_full_q1"
    { PASCAL_SM_LSU_IQ_FIFO_FULL_Q2, pascal_sm_lsu_iq_fifo_full_q2_enc_str_1, 0x0000001b, 0x00000000, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"lsu_iq_fifo_full_q2"
    { PASCAL_SM_TEX_IQ_FIFO_FULL_Q2, pascal_sm_tex_iq_fifo_full_q2_enc_str_1, 0x0000001b, 0x00000001, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"tex_iq_fifo_full_q2"
    { PASCAL_SM_PIX_IQ_FIFO_FULL_Q2, pascal_sm_pix_iq_fifo_full_q2_enc_str_1, 0x0000001b, 0x00000002, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pix_iq_fifo_full_q2"
    { PASCAL_SM_RTY_IQ_FIFO_FULL_Q2, pascal_sm_rty_iq_fifo_full_q2_enc_str_1, 0x0000001b, 0x00000003, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"rty_iq_fifo_full_q2"
    { PASCAL_SM_LSU_IQ_FIFO_FULL_Q3, pascal_sm_lsu_iq_fifo_full_q3_enc_str_1, 0x0000001b, 0x00000004, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"lsu_iq_fifo_full_q3"
    { PASCAL_SM_TEX_IQ_FIFO_FULL_Q3, pascal_sm_tex_iq_fifo_full_q3_enc_str_1, 0x0000001b, 0x00000005, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"tex_iq_fifo_full_q3"
    { PASCAL_SM_PIX_IQ_FIFO_FULL_Q3, pascal_sm_pix_iq_fifo_full_q3_enc_str_1, 0x0000001b, 0x00000006, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"pix_iq_fifo_full_q3"
    { PASCAL_SM_RTY_IQ_FIFO_FULL_Q3, pascal_sm_rty_iq_fifo_full_q3_enc_str_1, 0x0000001b, 0x00000007, 0x00000001, PM_UNIT_MIO, 1, PASCAL_SM_NOT_IN_TRAP_CORE}, //"rty_iq_fifo_full_q3"
    { PASCAL_SM_NOT_IN_TRAP_CORE, pascal_sm_not_in_trap_core_enc_str_1, 0x00000008, 0x00000002, 0x00000001, PM_UNIT_SMCORE, 1}, //"sm_not_in_trap"
    { INVALID_PM_SIGNAL_NEW,            "",                       0xffffffff, 0x00000000, 0x00000000,     PM_UNIT_MAX,0 }
};
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B) */

#if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
CUeventDataSmpcExpt_v1 PerfSignalTableGP100_miohalf_expt[] = {
    { PASCAL_SM_SHARED_LD_BANK_CONFLICT, pascal_sm_shared_ld_bank_conflict_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_SHARED_LD_BANK_CONFLICT_H0, PASCAL_SM_SHARED_LD_BANK_CONFLICT_H1, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 2},
    { PASCAL_SM_SHARED_ST_BANK_CONFLICT, pascal_sm_shared_st_bank_conflict_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_SHARED_ST_BANK_CONFLICT_H0, PASCAL_SM_SHARED_ST_BANK_CONFLICT_H1, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 2},
    { PASCAL_SM_SHARED_LOAD_TRANSACTIONS, pascal_sm_shared_ld_transactions_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_SHARED_LOAD_TRANSACTIONS_H0, PASCAL_SM_SHARED_LOAD_TRANSACTIONS_H1, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 2},
    { PASCAL_SM_SHARED_STORE_TRANSACTIONS, pascal_sm_shared_st_transactions_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_SHARED_STORE_TRANSACTIONS_H0, PASCAL_SM_SHARED_STORE_TRANSACTIONS_H1, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 2},
    { PASCAL_SM_PQ_WRITE, pascal_sm_pq_write_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_PQ_WRITE_Q0, PASCAL_SM_PQ_WRITE_Q1, PASCAL_SM_PQ_WRITE_Q2, PASCAL_SM_PQ_WRITE_Q3}, 4},
    { PASCAL_SM_ADU_REPLAY, pascal_sm_adu_replay_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_ADU_REPLAY_Q0, PASCAL_SM_ADU_REPLAY_Q1, PASCAL_SM_ADU_REPLAY_Q2, PASCAL_SM_ADU_REPLAY_Q3}, 4},
    { PASCAL_SM_PQ_READS_FOR_SHM, pascal_sm_pq_reads_for_shm_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_PQ_READS_FOR_SHM_Q0, PASCAL_SM_PQ_READS_FOR_SHM_Q1, PASCAL_SM_PQ_READS_FOR_SHM_Q2, PASCAL_SM_PQ_READS_FOR_SHM_Q3}, 4},
    { PASCAL_SM_PQ_READS_FOR_PIXOUT, pascal_sm_pq_reads_for_pixout_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_PQ_READS_FOR_PIXOUT_Q0, PASCAL_SM_PQ_READS_FOR_PIXOUT_Q1, PASCAL_SM_PQ_READS_FOR_PIXOUT_Q2, PASCAL_SM_PQ_READS_FOR_PIXOUT_Q3}, 4},
    { PASCAL_SM_PQ_READS_FOR_TEX, pascal_sm_pq_reads_for_tex_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_PQ_READS_FOR_TEX_Q0, PASCAL_SM_PQ_READS_FOR_TEX_Q1, PASCAL_SM_PQ_READS_FOR_TEX_Q2, PASCAL_SM_PQ_READS_FOR_TEX_Q3}, 4},
    { PASCAL_SM_PQ_READS_FOR_SHM_STOLEN, pascal_sm_pq_reads_for_shm_stolen_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_PQ_READS_FOR_SHM_STOLEN_Q0, PASCAL_SM_PQ_READS_FOR_SHM_STOLEN_Q1, PASCAL_SM_PQ_READS_FOR_SHM_STOLEN_Q2, PASCAL_SM_PQ_READS_FOR_SHM_STOLEN_Q3}, 4},
    { PASCAL_SM_IDC_DIVERGENCE_REPLAY, pascal_sm_idc_divergence_replay_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_IDC_DIVERGENCE_REPLAY_Q0, PASCAL_SM_IDC_DIVERGENCE_REPLAY_Q1, PASCAL_SM_IDC_DIVERGENCE_REPLAY_Q2, PASCAL_SM_IDC_DIVERGENCE_REPLAY_Q3}, 4},
    { PASCAL_SM_IDC_DIVERGENT_INSTRUCTION, pascal_sm_idc_divergent_instruction_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_IDC_DIVERGENT_INSTRUCTION_Q0, PASCAL_SM_IDC_DIVERGENT_INSTRUCTION_Q1, PASCAL_SM_IDC_DIVERGENT_INSTRUCTION_Q2, PASCAL_SM_IDC_DIVERGENT_INSTRUCTION_Q3}, 4},
    { PASCAL_SM_MEMBAR_CTA_SENT_TO_TEX, pascal_sm_membar_cta_sent_to_tex_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_MEMBAR_CTA_SENT_TO_TEX_H0, PASCAL_SM_MEMBAR_CTA_SENT_TO_TEX_H1}, 2},
    { PASCAL_SM_LSU_BUSY, pascal_sm_lsu_busy_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_LSU_BUSY_H0, PASCAL_SM_LSU_BUSY_H1}, 2},
    { PASCAL_SM_MIO_ISBE_WRITE, pascal_sm_mio_isbe_write_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_MIO_ISBE_WRITE_H0, PASCAL_SM_MIO_ISBE_WRITE_H1}, 2},
    { PASCAL_SM_MIO_ISBE_READ, pascal_sm_mio_isbe_read_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_MIO_ISBE_READ_H0, PASCAL_SM_MIO_ISBE_READ_H1}, 2},
    { PASCAL_SM_MIO_SM_STALLED_DUE_TO_PE, pascal_sm_mio_sm_stalled_due_to_pe_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_MIO_SM_STALLED_DUE_TO_PE_Q0, PASCAL_SM_MIO_SM_STALLED_DUE_TO_PE_Q1, PASCAL_SM_MIO_SM_STALLED_DUE_TO_PE_Q2, PASCAL_SM_MIO_SM_STALLED_DUE_TO_PE_Q3}, 4},
    { PASCAL_SM_PE2MIO_ISBE_READ_REQ, pascal_sm_pe2mio_isbe_read_req_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_PE2MIO_ISBE_READ_REQ_H0, PASCAL_SM_PE2MIO_ISBE_READ_REQ_H1}, 2},
    { PASCAL_SM_PE2MIO_ISBE_WRITE_REQ, pascal_sm_pe2mio_isbe_write_req_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_PE2MIO_ISBE_WRITE_REQ_H0, PASCAL_SM_PE2MIO_ISBE_WRITE_REQ_H1}, 2},
    { PASCAL_SM_PE2MIO_TRAM_WRITE, pascal_sm_pe2mio_tram_write_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_PE2MIO_TRAM_WRITE_H0, PASCAL_SM_PE2MIO_TRAM_WRITE_H1}, 2},
    { PASCAL_SM_PE_ISBE_WR_DELAYED_DUE_TO_CAMPING, pascal_sm_pe_isbe_wr_delayed_due_to_camping_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_PE_ISBE_WR_DELAYED_DUE_TO_CAMPING_H0, PASCAL_SM_PE_ISBE_WR_DELAYED_DUE_TO_CAMPING_H1}, 2},
    { PASCAL_SM_PE_TRAM_WR_DELAYED_AND_LOST_THROUGHPUT, pascal_sm_pe_tram_wr_delayed_and_lost_throughput_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_PE_TRAM_WR_DELAYED_AND_LOST_THROUGHPUT_H0, PASCAL_SM_PE_TRAM_WR_DELAYED_AND_LOST_THROUGHPUT_H1}, 2},
    { PASCAL_SM_PE_TRAM_WR_DELAYED_DUE_TO_CAMPING, pascal_sm_pe_tram_wr_delayed_due_to_camping_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_PE_TRAM_WR_DELAYED_DUE_TO_CAMPING_H0, PASCAL_SM_PE_TRAM_WR_DELAYED_DUE_TO_CAMPING_H1}, 2},
    { PASCAL_SM_SMM2TEX_DATA_LG_COUNT, pascal_sm_smm2tex_data_lg_count_enc_str_1, PM_UNIT_MIO, { PASCAL_SM_SMM2TEX_DATA_LG_COUNT_H0, PASCAL_SM_SMM2TEX_DATA_LG_COUNT_H1}, 2},
    { PASCAL_SM_SMM2TEX_DATA_TEX_COUNT, pascal_sm_smm2tex_data_tex_count_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_SMM2TEX_DATA_TEX_COUNT_H0, PASCAL_SM_SMM2TEX_DATA_TEX_COUNT_H1}, 2},
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_ADU_OVER_SHM, pascal_sm_mio_cant_dispatch_lsu_adu_over_shm_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_MIO_CANT_DISPATCH_LSU_ADU_OVER_SHM_Q0, PASCAL_SM_MIO_CANT_DISPATCH_LSU_ADU_OVER_SHM_Q1, PASCAL_SM_MIO_CANT_DISPATCH_LSU_ADU_OVER_SHM_Q2, PASCAL_SM_MIO_CANT_DISPATCH_LSU_ADU_OVER_SHM_Q3}, 4},
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_ADU, pascal_sm_mio_cant_dispatch_lsu_pixout_over_adu_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_ADU_Q0, PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_ADU_Q1, PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_ADU_Q2, PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_ADU_Q3}, 4},
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_SHM, pascal_sm_mio_cant_dispatch_lsu_pixout_over_shm_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_SHM_Q0, PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_SHM_Q1, PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_SHM_Q2, PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_SHM_Q3}, 4},
    { PASCAL_SM_PQ_FULL, pascal_sm_pq_full_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_PQ_FULL_Q0, PASCAL_SM_PQ_FULL_Q1, PASCAL_SM_PQ_FULL_Q2, PASCAL_SM_PQ_FULL_Q3}, 4},
    { PASCAL_SM_PIX_PQ_FULL, pascal_sm_pix_pq_full_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_PIX_PQ_FULL_Q0, PASCAL_SM_PIX_PQ_FULL_Q1, PASCAL_SM_PIX_PQ_FULL_Q2, PASCAL_SM_PIX_PQ_FULL_Q3}, 4},
    { PASCAL_SM_SHM_PQ_FULL, pascal_sm_shm_pq_full_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_SHM_PQ_FULL_Q0, PASCAL_SM_SHM_PQ_FULL_Q1, PASCAL_SM_SHM_PQ_FULL_Q2, PASCAL_SM_SHM_PQ_FULL_Q3}, 4},
    { PASCAL_SM_TEX_PQ_FULL, pascal_sm_tex_pq_full_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_TEX_PQ_FULL_Q0, PASCAL_SM_TEX_PQ_FULL_Q1, PASCAL_SM_TEX_PQ_FULL_Q2, PASCAL_SM_TEX_PQ_FULL_Q3}, 4},
    { PASCAL_SM_PQ_WRITE_BACK_LSU_STALL, pascal_sm_pq_write_back_lsu_stall_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_PQ_WRITE_BACK_LSU_STALL_H0, PASCAL_SM_PQ_WRITE_BACK_LSU_STALL_H1}, 2},
    { PASCAL_SM_PQ_WRITE_BACK_TEX_STALL, pascal_sm_pq_write_back_tex_stall_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_PQ_WRITE_BACK_TEX_STALL_H0, PASCAL_SM_PQ_WRITE_BACK_TEX_STALL_H1}, 2},
    { PASCAL_SM_LSU_IQ_FIFO_FULL, pascal_sm_lsu_iq_fifo_full_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_LSU_IQ_FIFO_FULL_Q0, PASCAL_SM_LSU_IQ_FIFO_FULL_Q1, PASCAL_SM_LSU_IQ_FIFO_FULL_Q2, PASCAL_SM_LSU_IQ_FIFO_FULL_Q3}, 4},
    { PASCAL_SM_TEX_IQ_FIFO_FULL, pascal_sm_tex_iq_fifo_full_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_TEX_IQ_FIFO_FULL_Q0, PASCAL_SM_TEX_IQ_FIFO_FULL_Q1, PASCAL_SM_TEX_IQ_FIFO_FULL_Q2, PASCAL_SM_TEX_IQ_FIFO_FULL_Q3}, 4},
    { PASCAL_SM_PIX_IQ_FIFO_FULL, pascal_sm_pix_iq_fifo_full_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_PIX_IQ_FIFO_FULL_Q0, PASCAL_SM_PIX_IQ_FIFO_FULL_Q1, PASCAL_SM_PIX_IQ_FIFO_FULL_Q2, PASCAL_SM_PIX_IQ_FIFO_FULL_Q3}, 4},
    { PASCAL_SM_RTY_IQ_FIFO_FULL, pascal_sm_rty_iq_fifo_full_enc_str_1, PM_UNIT_MIO, {PASCAL_SM_RTY_IQ_FIFO_FULL_Q0, PASCAL_SM_RTY_IQ_FIFO_FULL_Q1, PASCAL_SM_RTY_IQ_FIFO_FULL_Q2, PASCAL_SM_RTY_IQ_FIFO_FULL_Q3}, 4},
    { INVALID_PM_SIGNAL_NEW,               "", PM_UNIT_MAX, {INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW}, 0}
};
#endif

#if NVCFG(GLOBAL_GPU_FAMILY_GP10X)
PerfSignalHwpm PerfSignalTableGP100_sys0[] = {
    //Hub TLB signals
    //__hub_tlb_hit        = hubmmu2pm_hub_hub_tlb_hit                                      count # of PTE hits in hub TLB
    //__hub_tlb_miss       = (hubmmu2pm_hub_hub_tlb_miss & !hubmmu2pm_hub_hub_tlb_hit)      count # of PTE misses in hub TLB
    { PASCAL_MMU_HUB_TLB_HIT,    pascal_mmu_hub_tlb_hit_enc_str_1,    0x00000004, 0x0000AAAA, 0x4e,    PM_UNIT_HUBMMU, 1 },
    { PASCAL_MMU_HUB_TLB_MISS_INT,   pascal_mmu_hub_tlb_miss_int_enc_str_1,   0x00000004, 0x0000AAAA, 0x4f,    PM_UNIT_HUBMMU, 1 },

    // mmu_fill_pte_hit    = hubmmu2pm_hub_fill_pte_hit                                     "count # of PTE hits in mmu fill unit"
    // mmu_fill_pte_miss   = (hubmmu2pm_hub_fill_pte_miss & !hubmmu2pm_hub_fill_pte_hit)    "count # of PTE misses in mmu fill unit"
    { PASCAL_MMU_FILL_PTE_HIT,   pascal_mmu_fill_pte_hit_enc_str_1,   0x00000006, 0x0000AAAA, 0x4e,    PM_UNIT_HUBMMU, 1 },
    { PASCAL_MMU_FILL_PTE_MISS_INT,  pascal_mmu_fill_pte_miss_int_enc_str_1,  0x00000006, 0x0000AAAA, 0x4f,    PM_UNIT_HUBMMU, 1 },

    // mmu_fill_pde_hit    = hubmmu2pm_hub_fill_pde_hit                                     "count # of PDE hits in mmu fill unit"
    // mmu_fill_pde_miss   = hubmmu2pm_hub_fill_pde_miss                                    "count # of PDE misses in mmu fill unit"
    { PASCAL_MMU_FILL_PDE_HIT,   pascal_mmu_fill_pde_hit_enc_str_1,   0x00000006, 0x0000AAAA, 0x50,    PM_UNIT_HUBMMU,1 },
    { PASCAL_MMU_FILL_PDE_MISS,  pascal_mmu_fill_pde_miss_enc_str_1,  0x00000006, 0x0000AAAA, 0x51,    PM_UNIT_HUBMMU,1 },

    { PASCAL_MMU_GPCL2_TLB_HIT, pascal_mmu_gpcl2_tlb_hit_enc_str_1, 0x3, 0xaaaa, 0x4e, PM_UNIT_HUBMMU, 1},
    { PASCAL_MMU_GPCL2_TLB_MISS_INT, pascal_mmu_gpcl2_tlb_miss_int_enc_str_1, 0x3, 0xaaaa, 0x4f, PM_UNIT_HUBMMU, 1},

    { INVALID_PM_SIGNAL_NEW,     "",                     0xffffffff, 0x00000000, 0x00,     PM_UNIT_MAX,0}
};
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) */

#if 0
//Instance value should be updated as below: taken from dev_nvl_ioctrl.h
#define NV_IOCTRL_PERFMON_SELECT_M2SEL_DL0               0x0 /*       */
#define NV_IOCTRL_PERFMON_SELECT_M2SEL_TL0               0x1 /*       */
#define NV_IOCTRL_PERFMON_SELECT_M2SEL_DL1               0x2 /*       */
#define NV_IOCTRL_PERFMON_SELECT_M2SEL_TL1               0x3 /*       */
#define NV_IOCTRL_PERFMON_SELECT_M2SEL_DL2               0x4 /*       */
#define NV_IOCTRL_PERFMON_SELECT_M2SEL_TL2               0x5 /*       */
#define NV_IOCTRL_PERFMON_SELECT_M2SEL_DL3               0x6 /*       */
#define NV_IOCTRL_PERFMON_SELECT_M2SEL_TL3               0x7 /*       */
#endif 
//signal configuration taken from //hw/nvgpu_gmlit4/defs/perfmon/perfmon_nvltl.spec
PerfSignalHwpm PerfSignalTableGP100_nvlink0[] = {
#if NVLINK_PM
    { PASCAL_NVLINK0_TL_TX_DATA_FLIT,   pascal_nvlink0_tl_tx_data_flit_enc_str_1,   0x00000000, 0x0000AAAA, 0x3,    PM_UNIT_NVLINK0, 1, 1 },
    { PASCAL_NVLINK1_TL_TX_DATA_FLIT,   pascal_nvlink1_tl_tx_data_flit_enc_str_1,   0x00000000, 0x0000AAAA, 0x3,    PM_UNIT_NVLINK1, 1, 3 },

    //{ PASCAL_NVLINK2_TL_TX_DATA_FLIT,   pascal_nvlink2_tl_tx_data_flit_enc_str_1,   0x00000000, 0x0000AAAA, 0x3,    PM_UNIT_NVLINK2, 1, 5 },
    //{ PASCAL_NVLINK3_TL_TX_DATA_FLIT,   pascal_nvlink3_tl_tx_data_flit_enc_str_1,   0x00000000, 0x0000AAAA, 0x3,    PM_UNIT_NVLINK3, 1, 7 },

    { PASCAL_NVLINK0_TL_RX_DATA_FLIT,   pascal_nvlink0_tl_rx_data_flit_enc_str_1,   0x00000004, 0x0000AAAA, 0x3,    PM_UNIT_NVLINK0, 1, 1 },
    { PASCAL_NVLINK1_TL_RX_DATA_FLIT,   pascal_nvlink1_tl_rx_data_flit_enc_str_1,   0x00000004, 0x0000AAAA, 0x3,    PM_UNIT_NVLINK1, 1, 3 },
#endif
    { INVALID_PM_SIGNAL_NEW,     "",                     0xffffffff, 0x00000000, 0x00,     PM_UNIT_MAX,0}
};

PerfSignalHwpm PerfSignalTableGP100_nvlink1[] = {
#if NVLINK_PM
    { PASCAL_NVLINK2_TL_TX_DATA_FLIT,   pascal_nvlink2_tl_tx_data_flit_enc_str_1,   0x00000000, 0x0000AAAA, 0x3,    PM_UNIT_NVLINK2, 1, 5 },
    { PASCAL_NVLINK3_TL_TX_DATA_FLIT,   pascal_nvlink3_tl_tx_data_flit_enc_str_1,   0x00000000, 0x0000AAAA, 0x3,    PM_UNIT_NVLINK3, 1, 7 },

    //{ PASCAL_NVLINK0_TL_RX_DATA_FLIT,   pascal_nvlink0_tl_rx_data_flit_enc_str_1,   0x00000004, 0x0000AAAA, 0x3,    PM_UNIT_NVLINK0, 1, 1 },
    //{ PASCAL_NVLINK1_TL_RX_DATA_FLIT,   pascal_nvlink1_tl_rx_data_flit_enc_str_1,   0x00000004, 0x0000AAAA, 0x3,    PM_UNIT_NVLINK1, 1, 3 },

    { PASCAL_NVLINK2_TL_RX_DATA_FLIT,   pascal_nvlink2_tl_rx_data_flit_enc_str_1,   0x00000004, 0x0000AAAA, 0x3,    PM_UNIT_NVLINK2, 1, 5 },
    { PASCAL_NVLINK3_TL_RX_DATA_FLIT,   pascal_nvlink3_tl_rx_data_flit_enc_str_1,   0x00000004, 0x0000AAAA, 0x3,    PM_UNIT_NVLINK3, 1, 7 },
#endif
    { INVALID_PM_SIGNAL_NEW,     "",                     0xffffffff, 0x00000000, 0x00,     PM_UNIT_MAX,0}
};

#if NVCFG(GLOBAL_GPU_FAMILY_GP10X)
PerfSignalHwpm PerfSignalTableGP10x_sys0[] = {
    //Hub TLB signals
    //__hub_tlb_hit        = hubmmu2pm_hub_hub_tlb_hit                                      count # of PTE hits in hub TLB
    //__hub_tlb_miss       = (hubmmu2pm_hub_hub_tlb_miss & !hubmmu2pm_hub_hub_tlb_hit)      count # of PTE misses in hub TLB
    { PASCAL_MMU_HUB_TLB_HIT,    pascal_mmu_hub_tlb_hit_enc_str_1,    0x00000004, 0x0000AAAA, 0x40,    PM_UNIT_HUBMMU, 1 },
    { PASCAL_MMU_HUB_TLB_MISS_INT,   pascal_mmu_hub_tlb_miss_int_enc_str_1,   0x00000004, 0x0000AAAA, 0x41,    PM_UNIT_HUBMMU, 1 },

    // mmu_fill_pte_hit    = hubmmu2pm_hub_fill_pte_hit                                     "count # of PTE hits in mmu fill unit"
    // mmu_fill_pte_miss   = (hubmmu2pm_hub_fill_pte_miss & !hubmmu2pm_hub_fill_pte_hit)    "count # of PTE misses in mmu fill unit"
    { PASCAL_MMU_FILL_PTE_HIT,   pascal_mmu_fill_pte_hit_enc_str_1,   0x00000006, 0x0000AAAA, 0x40,    PM_UNIT_HUBMMU, 1 },
    { PASCAL_MMU_FILL_PTE_MISS_INT,  pascal_mmu_fill_pte_miss_int_enc_str_1,  0x00000006, 0x0000AAAA, 0x41,    PM_UNIT_HUBMMU, 1 },

    // mmu_fill_pde_hit    = hubmmu2pm_hub_fill_pde_hit                                     "count # of PDE hits in mmu fill unit"
    // mmu_fill_pde_miss   = hubmmu2pm_hub_fill_pde_miss                                    "count # of PDE misses in mmu fill unit"
    { PASCAL_MMU_FILL_PDE_HIT,   pascal_mmu_fill_pde_hit_enc_str_1,   0x00000006, 0x0000AAAA, 0x42,    PM_UNIT_HUBMMU,1 },
    { PASCAL_MMU_FILL_PDE_MISS,  pascal_mmu_fill_pde_miss_enc_str_1,  0x00000006, 0x0000AAAA, 0x43,    PM_UNIT_HUBMMU,1 },

    { PASCAL_MMU_GPCL2_TLB_HIT, pascal_mmu_gpcl2_tlb_hit_enc_str_1, 0x3, 0xaaaa, 0x40, PM_UNIT_HUBMMU, 1},
    { PASCAL_MMU_GPCL2_TLB_MISS_INT, pascal_mmu_gpcl2_tlb_miss_int_enc_str_1, 0x3, 0xaaaa, 0x41, PM_UNIT_HUBMMU, 1},

    { INVALID_PM_SIGNAL_NEW,     "",                     0xffffffff, 0x00000000, 0x00,     PM_UNIT_MAX,0}
};

PerfSignalHwpmExpt_v1 PerfSignalTableGP100_sys0_expt[] = {
    //Hub TLB signals
    //__hub_tlb_miss       = (hubmmu2pm_hub_hub_tlb_miss & !hubmmu2pm_hub_hub_tlb_hit)      count # of PTE misses in hub TLB
    { PASCAL_MMU_HUB_TLB_MISS, pascal_mmu_hub_tlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_MMU_HUB_TLB_HIT, PASCAL_MMU_HUB_TLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW} ,

    // mmu_fill_pte_miss   = (hubmmu2pm_hub_fill_pte_miss & !hubmmu2pm_hub_fill_pte_hit)    "count # of PTE misses in mmu fill unit"
    { PASCAL_MMU_FILL_PTE_MISS, pascal_mmu_fill_pte_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_MMU_FILL_PTE_HIT, PASCAL_MMU_FILL_PTE_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},

    //__hub_gpcl2_tlb_miss = (hubmmu2pm_hub_gpcl2_tlb_miss & !hubmmu2pm_hub_gpcl2_tlb_hit)  count # of PTE misses in gpcl2 TLB
    { PASCAL_MMU_GPCL2_TLB_MISS, pascal_mmu_gpcl2_tlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_MMU_GPCL2_TLB_HIT, PASCAL_MMU_GPCL2_TLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},

   { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000, INVALID_PM_SIGNAL_NEW},
};
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) */

#if NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
PerfSignalHwpm PerfSignalTableGP10Y_sys0[] = {
    //Hub TLB signals
    //__hub_tlb_hit        = hubmmu2pm_hub_hub_tlb_hit                                      count # of PTE hits in hub TLB
    //__hub_tlb_miss       = (hubmmu2pm_hub_hub_tlb_miss & !hubmmu2pm_hub_hub_tlb_hit)      count # of PTE misses in hub TLB
    { PASCAL_MMU_HUB_TLB_HIT,    pascal_mmu_hub_tlb_hit_enc_str_1,    0x00000004, 0x0000AAAA, 0x5c,    PM_UNIT_HUBMMU, 1 },
    { PASCAL_MMU_HUB_TLB_MISS_INT,   pascal_mmu_hub_tlb_miss_int_enc_str_1,   0x00000004, 0x0000AAAA, 0x5d,    PM_UNIT_HUBMMU, 1 },

    // mmu_fill_pte_hit    = hubmmu2pm_hub_fill_pte_hit                                     "count # of PTE hits in mmu fill unit"
    // mmu_fill_pte_miss   = (hubmmu2pm_hub_fill_pte_miss & !hubmmu2pm_hub_fill_pte_hit)    "count # of PTE misses in mmu fill unit"
    { PASCAL_MMU_FILL_PTE_HIT,   pascal_mmu_fill_pte_hit_enc_str_1,   0x00000006, 0x0000AAAA, 0x5c,    PM_UNIT_HUBMMU, 1 },
    { PASCAL_MMU_FILL_PTE_MISS_INT,  pascal_mmu_fill_pte_miss_int_enc_str_1,  0x00000006, 0x0000AAAA, 0x5d,    PM_UNIT_HUBMMU, 1 },

    // mmu_fill_pde_hit    = hubmmu2pm_hub_fill_pde_hit                                     "count # of PDE hits in mmu fill unit"
    // mmu_fill_pde_miss   = hubmmu2pm_hub_fill_pde_miss                                    "count # of PDE misses in mmu fill unit"
    { PASCAL_MMU_FILL_PDE_HIT,   pascal_mmu_fill_pde_hit_enc_str_1,   0x00000006, 0x0000AAAA, 0x5e,    PM_UNIT_HUBMMU,1 },
    { PASCAL_MMU_FILL_PDE_MISS,  pascal_mmu_fill_pde_miss_enc_str_1,  0x00000006, 0x0000AAAA, 0x5f,    PM_UNIT_HUBMMU,1 },

    { INVALID_PM_SIGNAL_NEW,     "",                     0xffffffff, 0x00000000, 0x00,     PM_UNIT_MAX,0}
};

PerfSignalHwpmExpt_v1 PerfSignalTableGP10Y_sys0_expt[] = {
    //Hub TLB signals
    //__hub_tlb_miss       = (hubmmu2pm_hub_hub_tlb_miss & !hubmmu2pm_hub_hub_tlb_hit)      count # of PTE misses in hub TLB
    { PASCAL_MMU_HUB_TLB_MISS, pascal_mmu_hub_tlb_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_MMU_HUB_TLB_HIT, PASCAL_MMU_HUB_TLB_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW} ,

    // mmu_fill_pte_miss   = (hubmmu2pm_hub_fill_pte_miss & !hubmmu2pm_hub_fill_pte_hit)    "count # of PTE misses in mmu fill unit"
    { PASCAL_MMU_FILL_PTE_MISS, pascal_mmu_fill_pte_miss_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_MMU_FILL_PTE_HIT, PASCAL_MMU_FILL_PTE_MISS_INT, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, ((~TRUTH_TABLE_FUNCTION_BIT_0_TRUE) & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), INVALID_PM_SIGNAL_NEW},

    { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000, INVALID_PM_SIGNAL_NEW},
};
#endif /* NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B) */

#if NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
//To match the output with pmlsplitter, use perfmon 0 for slice 0 and 2
PerfSignalHwpm PerfSignalTableGP10Y_ltc0[] = {
    //LTC signals
    // l2_subp0_write_sector_misses = ltc_ltc2fb_dirty_dat0_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 0
    // l2_subp1_write_sector_misses = ltc_ltc2fb_dirty_dat1_pvld           l2 sent dirty data to fb/the number of writes that were written back to fb for slice 1
    // l2_subp0_read_sector_misses  = ltc_fb2ltc_rdat0_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 0
    // l2_subp1_read_sector_misses  = ltc_fb2ltc_rdat1_pvld                fb sent fill data to l2/the number of reads that missed in L2 slice 1
    // l2_subp0_write_l1_sector_queries = ltc2pm_ltc_lts0_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 0
    // l2_subp1_write_l1_sector_queries = ltc2pm_ltc_lts1_request_wr_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for write operation/Total sectors written to L2 slice 1
    // l2_subp0_read_l1_sector_queries  = ltc2pm_ltc_lts0_request_rd_op && ltc2pm_ltc_lts1_request_src_unit_l1 && ltc2pm_ltc_lts0_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 0
    // l2_subp1_read_l1_sector_queries  = ltc2pm_ltc_lts1_request_rd_op && ltc2pm_ltc_lts0_request_src_unit_l1 && ltc2pm_ltc_lts1_request_active
    //                               Valid requets to L2 for read operation/Total sectors read from L2 slice 1

    {PASCAL_LTC0_REQUEST_SRC_UNIT_L1, pascal_ltc0_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x92, PM_UNIT_LTS2, 1},
    {PASCAL_LTC1_REQUEST_SRC_UNIT_L1, pascal_ltc1_request_src_unit_l1_enc_str_1, 0x4, 0xaaaa, 0x93, PM_UNIT_LTS2_1, 1},
    {PASCAL_LTC0_REQUEST_SRC_UNIT_TEX, pascal_ltc0_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x92, PM_UNIT_LTS2, 1},
    {PASCAL_LTC1_REQUEST_SRC_UNIT_TEX, pascal_ltc1_request_src_unit_tex_enc_str_1, 0x3, 0xaaaa, 0x93, PM_UNIT_LTS2_1, 1},
    {PASCAL_LTC0_REQUEST_SRC_UNIT_GCC, pascal_ltc0_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x92, PM_UNIT_LTS2, 1},
    {PASCAL_LTC1_REQUEST_SRC_UNIT_GCC, pascal_ltc1_request_src_unit_gcc_enc_str_1, 0x8, 0xaaaa, 0x93, PM_UNIT_LTS2_1, 1},

    {PASCAL_LTC0_WRITE_MISS_SECTORS, pascal_ltc0_write_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x2c, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_WRITE_MISS_SECTORS, pascal_ltc1_write_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x4c, PM_UNIT_LTS1, 1},
    {PASCAL_LTC0_READ_MISS_SECTORS, pascal_ltc0_read_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x2d, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_READ_MISS_SECTORS, pascal_ltc1_read_miss_sectors_enc_str_1, 0x6, 0xaaaa, 0x4d, PM_UNIT_LTS1, 1},

    {PASCAL_LTC0_HIT_SECTORS, pascal_ltc0_hit_sectors_enc_str_1, 0x1, 0xffff, 0x7c, PM_UNIT_LTS, 4},
    {PASCAL_LTC1_HIT_SECTORS, pascal_ltc1_hit_sectors_enc_str_1, 0x1, 0xffff, 0x8c, PM_UNIT_LTS_1, 4},
    {PASCAL_LTC0_MISS_SECTORS, pascal_ltc0_miss_sectors_enc_str_1, 0x2, 0xffff, 0x7c, PM_UNIT_LTS, 4},
    {PASCAL_LTC1_MISS_SECTORS, pascal_ltc1_miss_sectors_enc_str_1, 0x2, 0xffff, 0x8c, PM_UNIT_LTS_1, 4},

    {PASCAL_LTC0_REQUEST_SECTORS, pascal_ltc0_request_sectors_enc_str_1, 0x0, 0xffff, 0x7c, PM_UNIT_LTS, 4},
    {PASCAL_LTC1_REQUEST_SECTORS, pascal_ltc1_request_sectors_enc_str_1, 0x0, 0xffff, 0x8c, PM_UNIT_LTS_1, 4},

    {PASCAL_LTC0_REQUEST_ACTIVE, pascal_ltc0_request_active_enc_str_1, 0x0, 0xaaaa, 0x29, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_REQUEST_ACTIVE, pascal_ltc1_request_active_enc_str_1, 0x0, 0xaaaa, 0x49, PM_UNIT_LTS1_1, 1},

    {PASCAL_LTC0_REQUEST_RD_OP, pascal_ltc0_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x3c, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_REQUEST_RD_OP, pascal_ltc1_request_rd_op_enc_str_1, 0x0, 0xaaaa, 0x5c, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_REQUEST_WR_OP, pascal_ltc0_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x3b, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_REQUEST_WR_OP, pascal_ltc1_request_wr_op_enc_str_1, 0x0, 0xaaaa, 0x5b, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_REQUEST_ATOMIC_OP, pascal_ltc0_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x3a, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_REQUEST_ATOMIC_OP, pascal_ltc1_request_atomic_op_enc_str_1, 0x0, 0xaaaa, 0x5a, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_REQUEST_APERTURE_SYSMEM, pascal_ltc0_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x36, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_REQUEST_APERTURE_SYSMEM, pascal_ltc1_request_aperture_sysmem_enc_str_1, 0x0, 0xaaaa, 0x56, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_REQUEST_APERTURE_VIDMEM, pascal_ltc0_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x35, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_REQUEST_APERTURE_VIDMEM, pascal_ltc1_request_aperture_vidmem_enc_str_1, 0x0, 0xaaaa, 0x55, PM_UNIT_LTS1_1, 1},

    {PASCAL_LTC0_HIT, pascal_ltc0_hit_enc_str_1, 0x0, 0xaaaa, 0x30, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_HIT, pascal_ltc1_hit_enc_str_1, 0x0, 0xaaaa, 0x50, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_REQUEST, pascal_ltc0_request_enc_str_1, 0x0, 0xaaaa, 0x28, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_REQUEST, pascal_ltc1_request_enc_str_1, 0x0, 0xaaaa, 0x48, PM_UNIT_LTS1_1, 1},

    {PASCAL_LTC0_LTCX_MC_REQ_RD, pascal_ltc0_ltcx_mc_req_rd_enc_str_1, 0x10, 0xaaaa, 0x2f, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_LTCX_MC_REQ_RD, pascal_ltc1_ltcx_mc_req_rd_enc_str_1, 0x10, 0xaaaa, 0x4f, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_LTCX_MC_REQ_RD_SIZE, pascal_ltc0_ltcx_mc_req_rd_size_enc_str_1, 0x10, 0xaaaa, 0x30, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_LTCX_MC_REQ_RD_SIZE, pascal_ltc1_ltcx_mc_req_rd_size_enc_str_1, 0x10, 0xaaaa, 0x50, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_LTCX_MC_REQ_WR, pascal_ltc0_ltcx_mc_req_wr_enc_str_1, 0x10, 0xaaaa, 0x33, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_LTCX_MC_REQ_WR, pascal_ltc1_ltcx_mc_req_wr_enc_str_1, 0x10, 0xaaaa, 0x53, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_LTCX_MC_REQ_WR_SIZE_0, pascal_ltc0_ltcx_mc_req_wr_size_0_enc_str_1, 0x10, 0xaaaa, 0x34, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_LTCX_MC_REQ_WR_SIZE_0, pascal_ltc1_ltcx_mc_req_wr_size_0_enc_str_1, 0x10, 0xaaaa, 0x54, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_LTCX_MC_REQ_WR_SIZE_1, pascal_ltc0_ltcx_mc_req_wr_size_1_enc_str_1, 0x10, 0xaaaa, 0x35, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_LTCX_MC_REQ_WR_SIZE_1, pascal_ltc1_ltcx_mc_req_wr_size_1_enc_str_1, 0x10, 0xaaaa, 0x55, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_LTCX_MC_REQ_WR_PARTIAL, pascal_ltc0_ltcx_mc_req_wr_partial_enc_str_1, 0x10, 0xaaaa, 0x38, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_LTCX_MC_REQ_WR_PARTIAL, pascal_ltc1_ltcx_mc_req_wr_partial_enc_str_1, 0x10, 0xaaaa, 0x58, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_LTCX_REQ_RD, pascal_ltc0_ltcx_req_rd_enc_str_1, 0x10, 0xaaaa, 0x28, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_LTCX_REQ_RD, pascal_ltc1_ltcx_req_rd_enc_str_1, 0x10, 0xaaaa, 0x48, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_LTCX_REQ_RD_SIZE_0, pascal_ltc0_ltcx_req_rd_size_0_enc_str_1, 0x10, 0xaaaa, 0x29, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_LTCX_REQ_RD_SIZE_0, pascal_ltc1_ltcx_req_rd_size_0_enc_str_1, 0x10, 0xaaaa, 0x49, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_LTCX_REQ_RD_SIZE_1, pascal_ltc0_ltcx_req_rd_size_1_enc_str_1, 0x10, 0xaaaa, 0x2a, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_LTCX_REQ_RD_SIZE_1, pascal_ltc1_ltcx_req_rd_size_1_enc_str_1, 0x10, 0xaaaa, 0x4a, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_LTCX_REQ_WR, pascal_ltc0_ltcx_req_wr_enc_str_1, 0x10, 0xaaaa, 0x2b, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_LTCX_REQ_WR, pascal_ltc1_ltcx_req_wr_enc_str_1, 0x10, 0xaaaa, 0x4b, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_LTCX_REQ_WR_SIZE_0, pascal_ltc0_ltcx_req_wr_size_0_enc_str_1, 0x10, 0xaaaa, 0x2c, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_LTCX_REQ_WR_SIZE_0, pascal_ltc1_ltcx_req_wr_size_0_enc_str_1, 0x10, 0xaaaa, 0x4c, PM_UNIT_LTS1_1, 1},
    {PASCAL_LTC0_LTCX_REQ_WR_SIZE_1, pascal_ltc0_ltcx_req_wr_size_1_enc_str_1, 0x10, 0xaaaa, 0x2d, PM_UNIT_LTS1, 1},
    {PASCAL_LTC1_LTCX_REQ_WR_SIZE_1, pascal_ltc1_ltcx_req_wr_size_1_enc_str_1, 0x10, 0xaaaa, 0x4d, PM_UNIT_LTS1_1, 1},

    { INVALID_PM_SIGNAL_NEW,        "",                                 0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};

PerfSignalHwpmExpt PerfSignalTableGP10Y_ltc0_expt[] = {
    //write a combination of the signals.

    // ltc_read_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { PASCAL_LTC0_READ_TEX_SECTORS_FBP, pascal_ltc0_read_tex_sectors_fbp_enc_str_1, PASCAL_LTC0_REQUEST_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_RD_OP, PASCAL_LTC0_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_request_sectors_src_unit_tex_op_atomic_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_request_atomic_op
    { PASCAL_LTC0_ATOMIC_TEX_SECTORS_FBP, pascal_ltc0_atomic_tex_sectors_fbp_enc_str_1, PASCAL_LTC0_REQUEST_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_ATOMIC_OP, PASCAL_LTC0_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { PASCAL_LTC0_WRITE_TEX_SECTORS_FBP, pascal_ltc0_write_tex_sectors_fbp_enc_str_1, PASCAL_LTC0_REQUEST_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_WR_OP, PASCAL_LTC0_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_hit_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_hit
    { PASCAL_LTC0_READ_TEX_HIT_SECTORS_FBP, pascal_ltc0_read_tex_hit_sectors_fbp_enc_str_1,  PASCAL_LTC0_HIT_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_RD_OP, PASCAL_LTC0_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { PASCAL_LTC0_WRITE_TEX_HIT_SECTORS_FBP, pascal_ltc0_write_tex_hit_sectors_fbp_enc_str_1,  PASCAL_LTC0_HIT_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_WR_OP, PASCAL_LTC0_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { PASCAL_LTC0_READ_SYSMEM_SECTORS_FBP, pascal_ltc0_read_sysmem_sectors_fbp_enc_str_1, PASCAL_LTC0_REQUEST_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_RD_OP, PASCAL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { PASCAL_LTC0_WRITE_SYSMEM_SECTORS_FBP, pascal_ltc0_write_sysmem_sectors_fbp_enc_str_1, PASCAL_LTC0_REQUEST_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_WR_OP, PASCAL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { PASCAL_LTC0_TOTAL_READ_SECTORS_FBP, pascal_ltc0_total_read_sectors_fbp_enc_str_1, PASCAL_LTC0_REQUEST_SECTORS, {PASCAL_LTC0_REQUEST_ATOMIC_OP, PASCAL_LTC0_REQUEST_RD_OP, PASCAL_LTC0_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { PASCAL_LTC0_TOTAL_WRITE_SECTORS_FBP, pascal_ltc0_total_write_sectors_fbp_enc_str_1, PASCAL_LTC0_REQUEST_SECTORS, {PASCAL_LTC0_REQUEST_ATOMIC_OP, PASCAL_LTC0_REQUEST_WR_OP, PASCAL_LTC0_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { PASCAL_LTC0_READ_VIDMEM_SECTORS_FBP,      pascal_ltc0_read_vidmem_sectors_fbp_enc_str_1,    PASCAL_LTC0_REQUEST_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_RD_OP, PASCAL_LTC0_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { PASCAL_LTC0_WRITE_VIDMEM_SECTORS_FBP,      pascal_ltc0_write_vidmem_sectors_fbp_enc_str_1,    PASCAL_LTC0_REQUEST_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_WR_OP, PASCAL_LTC0_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { PASCAL_LTC0_LTCX_MC_REQ_RD_SIZE_32B, pascal_ltc0_ltcx_mc_req_rd_size_32b_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC0_LTCX_MC_REQ_RD, PASCAL_LTC0_LTCX_MC_REQ_RD_SIZE, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE)), 0},
    { PASCAL_LTC0_LTCX_MC_REQ_RD_SIZE_64B, pascal_ltc0_ltcx_mc_req_rd_size_64b_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC0_LTCX_MC_REQ_RD, PASCAL_LTC0_LTCX_MC_REQ_RD_SIZE, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { PASCAL_LTC0_LTCX_MC_REQ_WR_SIZE_16B, pascal_ltc0_ltcx_mc_req_wr_size_16b_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC0_LTCX_MC_REQ_WR, PASCAL_LTC0_LTCX_MC_REQ_WR_SIZE_0, PASCAL_LTC0_LTCX_MC_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { PASCAL_LTC0_LTCX_MC_REQ_WR_SIZE_32B, pascal_ltc0_ltcx_mc_req_wr_size_32b_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC0_LTCX_MC_REQ_WR, PASCAL_LTC0_LTCX_MC_REQ_WR_SIZE_0, PASCAL_LTC0_LTCX_MC_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { PASCAL_LTC0_LTCX_MC_REQ_WR_SIZE_64B, pascal_ltc0_ltcx_mc_req_wr_size_64b_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC0_LTCX_MC_REQ_WR, PASCAL_LTC0_LTCX_MC_REQ_WR_SIZE_0, PASCAL_LTC0_LTCX_MC_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { PASCAL_LTC0_LTCX_REQ_RD_SECTOR_COUNT_1, pascal_ltc0_ltcx_req_rd_sector_count_1_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC0_LTCX_REQ_RD, PASCAL_LTC0_LTCX_REQ_RD_SIZE_0, PASCAL_LTC0_LTCX_REQ_RD_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { PASCAL_LTC0_LTCX_REQ_RD_SECTOR_COUNT_2, pascal_ltc0_ltcx_req_rd_sector_count_2_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC0_LTCX_REQ_RD, PASCAL_LTC0_LTCX_REQ_RD_SIZE_0, PASCAL_LTC0_LTCX_REQ_RD_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { PASCAL_LTC0_LTCX_REQ_RD_SECTOR_COUNT_3, pascal_ltc0_ltcx_req_rd_sector_count_3_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC0_LTCX_REQ_RD, PASCAL_LTC0_LTCX_REQ_RD_SIZE_0, PASCAL_LTC0_LTCX_REQ_RD_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { PASCAL_LTC0_LTCX_REQ_RD_SECTOR_COUNT_4, pascal_ltc0_ltcx_req_rd_sector_count_4_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC0_LTCX_REQ_RD, PASCAL_LTC0_LTCX_REQ_RD_SIZE_0, PASCAL_LTC0_LTCX_REQ_RD_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { PASCAL_LTC0_LTCX_REQ_WR_SECTOR_COUNT_1, pascal_ltc0_ltcx_req_wr_sector_count_1_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC0_LTCX_REQ_WR, PASCAL_LTC0_LTCX_REQ_WR_SIZE_0, PASCAL_LTC0_LTCX_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { PASCAL_LTC0_LTCX_REQ_WR_SECTOR_COUNT_2, pascal_ltc0_ltcx_req_wr_sector_count_2_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC0_LTCX_REQ_WR, PASCAL_LTC0_LTCX_REQ_WR_SIZE_0, PASCAL_LTC0_LTCX_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { PASCAL_LTC0_LTCX_REQ_WR_SECTOR_COUNT_3, pascal_ltc0_ltcx_req_wr_sector_count_3_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC0_LTCX_REQ_WR, PASCAL_LTC0_LTCX_REQ_WR_SIZE_0, PASCAL_LTC0_LTCX_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { PASCAL_LTC0_LTCX_REQ_WR_SECTOR_COUNT_4, pascal_ltc0_ltcx_req_wr_sector_count_4_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC0_LTCX_REQ_WR, PASCAL_LTC0_LTCX_REQ_WR_SIZE_0, PASCAL_LTC0_LTCX_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { PASCAL_LTC0_READ_SYSMEM_HIT_SECTORS_FBP, pascal_ltc0_read_sysmem_hit_sectors_fbp_enc_str_1, PASCAL_LTC0_HIT_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_RD_OP, PASCAL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_LTC0_WRITE_SYSMEM_HIT_SECTORS_FBP, pascal_ltc0_write_sysmem_hit_sectors_fbp_enc_str_1, PASCAL_LTC0_HIT_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_WR_OP, PASCAL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_LTC0_READ_SYSMEM_MISS_SECTORS_FBP, pascal_ltc0_read_sysmem_miss_sectors_fbp_enc_str_1, PASCAL_LTC0_MISS_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_RD_OP, PASCAL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_LTC0_WRITE_SYSMEM_MISS_SECTORS_FBP, pascal_ltc0_write_sysmem_miss_sectors_fbp_enc_str_1, PASCAL_LTC0_MISS_SECTORS, {PASCAL_LTC0_REQUEST_ACTIVE, PASCAL_LTC0_REQUEST_WR_OP, PASCAL_LTC0_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    // ltc_read_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { PASCAL_LTC1_READ_TEX_SECTORS_FBP, pascal_ltc1_read_tex_sectors_fbp_enc_str_1, PASCAL_LTC1_REQUEST_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_RD_OP, PASCAL_LTC1_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_request_sectors_src_unit_tex_op_atomic_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_request_atomic_op
    { PASCAL_LTC1_ATOMIC_TEX_SECTORS_FBP, pascal_ltc1_atomic_tex_sectors_fbp_enc_str_1, PASCAL_LTC1_REQUEST_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_ATOMIC_OP, PASCAL_LTC1_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_src_unit_tex
    { PASCAL_LTC1_WRITE_TEX_SECTORS_FBP, pascal_ltc1_write_tex_sectors_fbp_enc_str_1, PASCAL_LTC1_REQUEST_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_WR_OP, PASCAL_LTC1_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_hit_sectors_tex_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_src_unit_tex & ltc2pm_ltc_lts0_hit
    { PASCAL_LTC1_READ_TEX_HIT_SECTORS_FBP, pascal_ltc1_read_tex_hit_sectors_fbp_enc_str_1,  PASCAL_LTC1_HIT_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_RD_OP, PASCAL_LTC1_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { PASCAL_LTC1_WRITE_TEX_HIT_SECTORS_FBP, pascal_ltc1_write_tex_hit_sectors_fbp_enc_str_1,  PASCAL_LTC1_HIT_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_WR_OP, PASCAL_LTC1_REQUEST_SRC_UNIT_TEX, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { PASCAL_LTC1_READ_SYSMEM_SECTORS_FBP, pascal_ltc1_read_sysmem_sectors_fbp_enc_str_1, PASCAL_LTC1_REQUEST_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_RD_OP, PASCAL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { PASCAL_LTC1_WRITE_SYSMEM_SECTORS_FBP, pascal_ltc1_write_sysmem_sectors_fbp_enc_str_1, PASCAL_LTC1_REQUEST_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_WR_OP, PASCAL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { PASCAL_LTC1_TOTAL_READ_SECTORS_FBP, pascal_ltc1_total_read_sectors_fbp_enc_str_1, PASCAL_LTC1_REQUEST_SECTORS, {PASCAL_LTC1_REQUEST_ATOMIC_OP, PASCAL_LTC1_REQUEST_RD_OP, PASCAL_LTC1_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { PASCAL_LTC1_TOTAL_WRITE_SECTORS_FBP, pascal_ltc1_total_write_sectors_fbp_enc_str_1, PASCAL_LTC1_REQUEST_SECTORS, {PASCAL_LTC1_REQUEST_ATOMIC_OP, PASCAL_LTC1_REQUEST_WR_OP, PASCAL_LTC1_REQUEST_ACTIVE, INVALID_PM_SIGNAL_NEW}, ((TRUTH_TABLE_FUNCTION_BIT_0_TRUE | TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_read_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { PASCAL_LTC1_READ_VIDMEM_SECTORS_FBP,      pascal_ltc1_read_vidmem_sectors_fbp_enc_str_1,    PASCAL_LTC1_REQUEST_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_RD_OP, PASCAL_LTC1_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    // ltc_write_vidmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_vidmem
    { PASCAL_LTC1_WRITE_VIDMEM_SECTORS_FBP,      pascal_ltc1_write_vidmem_sectors_fbp_enc_str_1,    PASCAL_LTC1_REQUEST_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_WR_OP, PASCAL_LTC1_REQUEST_APERTURE_VIDMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { PASCAL_LTC1_LTCX_MC_REQ_RD_SIZE_32B, pascal_ltc1_ltcx_mc_req_rd_size_32b_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC1_LTCX_MC_REQ_RD, PASCAL_LTC1_LTCX_MC_REQ_RD_SIZE, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE)), 0},
    { PASCAL_LTC1_LTCX_MC_REQ_RD_SIZE_64B, pascal_ltc1_ltcx_mc_req_rd_size_64b_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC1_LTCX_MC_REQ_RD, PASCAL_LTC1_LTCX_MC_REQ_RD_SIZE, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE), 0},
    { PASCAL_LTC1_LTCX_MC_REQ_WR_SIZE_16B, pascal_ltc1_ltcx_mc_req_wr_size_16b_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC1_LTCX_MC_REQ_WR, PASCAL_LTC1_LTCX_MC_REQ_WR_SIZE_0, PASCAL_LTC1_LTCX_MC_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { PASCAL_LTC1_LTCX_MC_REQ_WR_SIZE_32B, pascal_ltc1_ltcx_mc_req_wr_size_32b_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC1_LTCX_MC_REQ_WR, PASCAL_LTC1_LTCX_MC_REQ_WR_SIZE_0, PASCAL_LTC1_LTCX_MC_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { PASCAL_LTC1_LTCX_MC_REQ_WR_SIZE_64B, pascal_ltc1_ltcx_mc_req_wr_size_64b_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC1_LTCX_MC_REQ_WR, PASCAL_LTC1_LTCX_MC_REQ_WR_SIZE_0, PASCAL_LTC1_LTCX_MC_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { PASCAL_LTC1_LTCX_REQ_RD_SECTOR_COUNT_1, pascal_ltc1_ltcx_req_rd_sector_count_1_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC1_LTCX_REQ_RD, PASCAL_LTC1_LTCX_REQ_RD_SIZE_0, PASCAL_LTC1_LTCX_REQ_RD_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { PASCAL_LTC1_LTCX_REQ_RD_SECTOR_COUNT_2, pascal_ltc1_ltcx_req_rd_sector_count_2_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC1_LTCX_REQ_RD, PASCAL_LTC1_LTCX_REQ_RD_SIZE_0, PASCAL_LTC1_LTCX_REQ_RD_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { PASCAL_LTC1_LTCX_REQ_RD_SECTOR_COUNT_3, pascal_ltc1_ltcx_req_rd_sector_count_3_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC1_LTCX_REQ_RD, PASCAL_LTC1_LTCX_REQ_RD_SIZE_0, PASCAL_LTC1_LTCX_REQ_RD_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { PASCAL_LTC1_LTCX_REQ_RD_SECTOR_COUNT_4, pascal_ltc1_ltcx_req_rd_sector_count_4_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC1_LTCX_REQ_RD, PASCAL_LTC1_LTCX_REQ_RD_SIZE_0, PASCAL_LTC1_LTCX_REQ_RD_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { PASCAL_LTC1_LTCX_REQ_WR_SECTOR_COUNT_1, pascal_ltc1_ltcx_req_wr_sector_count_1_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC1_LTCX_REQ_WR, PASCAL_LTC1_LTCX_REQ_WR_SIZE_0, PASCAL_LTC1_LTCX_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { PASCAL_LTC1_LTCX_REQ_WR_SECTOR_COUNT_2, pascal_ltc1_ltcx_req_wr_sector_count_2_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC1_LTCX_REQ_WR, PASCAL_LTC1_LTCX_REQ_WR_SIZE_0, PASCAL_LTC1_LTCX_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_2_TRUE)), 0},
    { PASCAL_LTC1_LTCX_REQ_WR_SECTOR_COUNT_3, pascal_ltc1_ltcx_req_wr_sector_count_3_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC1_LTCX_REQ_WR, PASCAL_LTC1_LTCX_REQ_WR_SIZE_0, PASCAL_LTC1_LTCX_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & (~TRUTH_TABLE_FUNCTION_BIT_1_TRUE) & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},
    { PASCAL_LTC1_LTCX_REQ_WR_SECTOR_COUNT_4, pascal_ltc1_ltcx_req_wr_sector_count_4_enc_str_1, INVALID_PM_SIGNAL_NEW, {PASCAL_LTC1_LTCX_REQ_WR, PASCAL_LTC1_LTCX_REQ_WR_SIZE_0, PASCAL_LTC1_LTCX_REQ_WR_SIZE_1, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), 0},

    { PASCAL_LTC1_READ_SYSMEM_HIT_SECTORS_FBP, pascal_ltc1_read_sysmem_hit_sectors_fbp_enc_str_1, PASCAL_LTC1_HIT_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_RD_OP, PASCAL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_LTC1_WRITE_SYSMEM_HIT_SECTORS_FBP, pascal_ltc1_write_sysmem_hit_sectors_fbp_enc_str_1, PASCAL_LTC1_HIT_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_WR_OP, PASCAL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_LTC1_READ_SYSMEM_MISS_SECTORS_FBP, pascal_ltc1_read_sysmem_miss_sectors_fbp_enc_str_1, PASCAL_LTC1_MISS_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_RD_OP, PASCAL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},
    { PASCAL_LTC1_WRITE_SYSMEM_MISS_SECTORS_FBP, pascal_ltc1_write_sysmem_miss_sectors_fbp_enc_str_1, PASCAL_LTC1_MISS_SECTORS, {PASCAL_LTC1_REQUEST_ACTIVE, PASCAL_LTC1_REQUEST_WR_OP, PASCAL_LTC1_REQUEST_APERTURE_SYSMEM, INVALID_PM_SIGNAL_NEW}, (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE), INVALID_PM_SIGNAL_NEW},

    { INVALID_PM_SIGNAL_NEW,        "",   INVALID_PM_SIGNAL_NEW, {INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW, INVALID_PM_SIGNAL_NEW}, 0x00000000,  0x00},
};
#endif /* #if NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B) */

#if NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
PerfSignalHwpm PerfSignalTableGP10Y_acb0[] = {

    { INVALID_PM_SIGNAL_NEW,        "",                                 0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};
#endif /* #if NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B) */

#if NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
PerfSignalHwpm PerfSignalTableGP10Y_mc0[] = {

    { INVALID_PM_SIGNAL_NEW,        "",                                 0xffffffff, 0x00000000,  0x00,     PM_UNIT_MAX,0 }
};
#endif /* #if NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B) */

#if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
PerfSignalSmpc PerfSignalTableGPSwCounters_nop_trig_global_load_store[] = {
    // TO DO: Change this table and make it more suitable for sw counters as most of the fields are not used
    { PASCAL_SW_COUNTER_GLD8BIT_INST,    pascal_sw_counter_gld8bit_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_GLD16BIT_INST,   pascal_sw_counter_gld16bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_GLD32BIT_INST,   pascal_sw_counter_gld32bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_GLD64BIT_INST,   pascal_sw_counter_gld64bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_GLD128BIT_INST,  pascal_sw_counter_gld128bit_inst_enc_str_1,  0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_GST8BIT_INST,    pascal_sw_counter_gst8bit_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_GST16BIT_INST,   pascal_sw_counter_gst16bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_GST32BIT_INST,   pascal_sw_counter_gst32bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_GST64BIT_INST,   pascal_sw_counter_gst64bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_GST128BIT_INST,  pascal_sw_counter_gst128bit_inst_enc_str_1,  0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { INVALID_SW_COUNTER,               "",           0xffffffff, 0x00000000, 0x00000000,                   PM_UNIT_MAX,0 }
};
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B) */

#if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
PerfSignalTableNew PerfSignalTableGPSwCounters_nop_trig_shared_load_store[] = {
    // Software counters work for all Maxwell chips
    { PASCAL_SW_COUNTER_SLD8BIT_INST,    pascal_sw_counter_sld8bit_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_SLD16BIT_INST,   pascal_sw_counter_sld16bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_SLD32BIT_INST,   pascal_sw_counter_sld32bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_SLD64BIT_INST,   pascal_sw_counter_sld64bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_SLD128BIT_INST,  pascal_sw_counter_sld128bit_inst_enc_str_1,  0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_SST8BIT_INST,    pascal_sw_counter_sst8bit_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_SST16BIT_INST,   pascal_sw_counter_sst16bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_SST32BIT_INST,   pascal_sw_counter_sst32bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_SST64BIT_INST,   pascal_sw_counter_sst64bit_inst_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_SST128BIT_INST,  pascal_sw_counter_sst128bit_inst_enc_str_1,  0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { INVALID_SW_COUNTER,               "",                                         0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX,0 }
};
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B) */

#if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
PerfSignalSmpc PerfSignalTableGPSwCounters_nop_trig_flops[] = {
    // TO DO: Change this table and make it more suitable for sw counters as most of the fields are not used
    { PASCAL_SW_COUNTER_FADD_INST,  pascal_sw_counter_fadd_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_FMUL_INST,  pascal_sw_counter_fmul_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_FFMA_INST,  pascal_sw_counter_ffma_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_DADD_INST,  pascal_sw_counter_dadd_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_DMUL_INST,  pascal_sw_counter_dmul_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_DFMA_INST,  pascal_sw_counter_dfma_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_COS_INST,   pascal_sw_counter_cos_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_EX2_INST,   pascal_sw_counter_ex2_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_LG2_INST,   pascal_sw_counter_lg2_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_RCP_INST,   pascal_sw_counter_rcp_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_RSQ_INST,   pascal_sw_counter_rsq_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_SIN_INST,   pascal_sw_counter_sin_inst_enc_str_1,     0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_SQRT_INST,  pascal_sw_counter_sqrt_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_HADD_INST,  pascal_sw_counter_hadd_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_HMUL_INST,  pascal_sw_counter_hmul_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },
    { PASCAL_SW_COUNTER_HFMA_INST,  pascal_sw_counter_hfma_inst_enc_str_1,    0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 },

    { INVALID_SW_COUNTER,           "",             0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 }
};
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B) */

#if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
PerfSignalSmpc PerfSignalTableGPSwCounters_instrClass[] = {
    { PASCAL_SW_COUNTER_INSTR_CLASS_FP_32,                       pascal_sw_counter_instr_class_fp_32_enc_str_1                      , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_INSTR_CLASS_FP_64,                       pascal_sw_counter_instr_class_fp_64_enc_str_1                      , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_INSTR_CLASS_INTEGER,                     pascal_sw_counter_instr_class_integer_enc_str_1                    , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_INSTR_CLASS_BIT_CONVERT,                 pascal_sw_counter_instr_class_bit_convert_enc_str_1                , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_INSTR_CLASS_CONTROL,                     pascal_sw_counter_instr_class_control_enc_str_1                    , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_INSTR_CLASS_COMPUTE_LD_ST,               pascal_sw_counter_instr_class_compute_ld_st_enc_str_1              , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_INSTR_CLASS_MISCELLANEOUS,               pascal_sw_counter_instr_class_miscellaneous_enc_str_1              , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_INSTR_CLASS_INTER_THREAD_COMMUNICATION,  pascal_sw_counter_instr_class_inter_thread_communication_enc_str_1 , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_INSTR_CLASS_FP_16,                       pascal_sw_counter_instr_class_fp_16_enc_str_1                      , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { INVALID_SW_COUNTER,           "",             0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 }
};
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B) */

#if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
PerfSignalSmpc PerfSignalTableGPSwCounters_genericLdStCounters[] = {
    { PASCAL_SW_COUNTER_GENERIC_SHARED_LOAD,           pascal_sw_counter_generic_shared_ld_enc_str_1          , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_GENERIC_SHARED_STORE,          pascal_sw_counter_generic_shared_st_enc_str_1          , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_GENERIC_LOCAL_LOAD,            pascal_sw_counter_generic_local_ld_enc_str_1           , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_GENERIC_LOCAL_STORE,           pascal_sw_counter_generic_local_st_enc_str_1           , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_GENERIC_GLOBAL_LOAD,           pascal_sw_counter_generic_global_ld_enc_str_1          , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_GENERIC_GLOBAL_STORE,          pascal_sw_counter_generic_global_st_enc_str_1          , 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { INVALID_SW_COUNTER,           "",             0xffffffff, 0x00000000, 0x00000000,    PM_UNIT_MAX,0 }
};
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B) */

PerfSignalTableNew PerfSignalTableGPSwCounters_unique_gld_gst[] = {
    //Software counters work for all pascal chips 
    { PASCAL_SW_COUNTER_UNIQUE_GLD1BYTE_REQUESTED,    pascal_sw_counter_unique_gld_1byte_requested_enc_str_1,    0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_UNIQUE_GLD4BYTE_REQUESTED,   pascal_sw_counter_unique_gld_4byte_requested_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_UNIQUE_GLD8BYTE_REQUESTED,   pascal_sw_counter_unique_gld_8byte_requested_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_UNIQUE_GLD16BYTE_REQUESTED,  pascal_sw_counter_unique_gld_16byte_requested_enc_str_1,  0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_UNIQUE_GST1BYTE_REQUESTED,    pascal_sw_counter_unique_gst_1byte_requested_enc_str_1,    0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_UNIQUE_GST4BYTE_REQUESTED,   pascal_sw_counter_unique_gst_4byte_requested_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_UNIQUE_GST8BYTE_REQUESTED,   pascal_sw_counter_unique_gst_8byte_requested_enc_str_1,   0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { PASCAL_SW_COUNTER_UNIQUE_GST16BYTE_REQUESTED,  pascal_sw_counter_unique_gst_16byte_requested_enc_str_1,  0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0},
    { INVALID_SW_COUNTER,                       "",                                                 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0}
};

PerfSignalTableNew PerfSignalTableGPSwCounters_unique_sector_access_gld[] = {
    { PASCAL_SW_COUNTER_UNIQUE_SECTOR_ACCESS_GLD,        pascal_sw_counter_unique_sector_access_gld_enc_str_1,         0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX,0 },
    { INVALID_SW_COUNTER,                       "",                                                 0xffffffff, 0x00000000, 0x00000000, PM_UNIT_MAX, 0}
};

#if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
CUeventDataSmpcExpt PerfSignalTableGP100_LutModeCounters[] = {
    { PASCAL_LUT_COUNTER_GLD32BIT_INST,             pascal_lut_counter_gld32bit_inst_enc_str_1,             PM_UNIT_SMQCTL,     {PASCAL_SM_INST_EXECUTED_32B,PASCAL_SM_GENERIC_LOAD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { PASCAL_LUT_COUNTER_GST32BIT_INST,             pascal_lut_counter_gst32bit_inst_enc_str_1,             PM_UNIT_SMQCTL,     {PASCAL_SM_INST_EXECUTED_32B,PASCAL_SM_GENERIC_STORE,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { PASCAL_LUT_COUNTER_GLD64BIT_INST,             pascal_lut_counter_gld64bit_inst_enc_str_1,             PM_UNIT_SMQCTL,     {PASCAL_SM_INST_EXECUTED_64B,PASCAL_SM_GENERIC_LOAD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { PASCAL_LUT_COUNTER_GST64BIT_INST,             pascal_lut_counter_gst64bit_inst_enc_str_1,             PM_UNIT_SMQCTL,     {PASCAL_SM_INST_EXECUTED_64B,PASCAL_SM_GENERIC_STORE,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { PASCAL_LUT_COUNTER_GLD128BIT_INST,            pascal_lut_counter_gld128bit_inst_enc_str_1,            PM_UNIT_SMQCTL,     {PASCAL_SM_INST_EXECUTED_128B,PASCAL_SM_GENERIC_LOAD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { PASCAL_LUT_COUNTER_GST128BIT_INST,            pascal_lut_counter_gst128bit_inst_enc_str_1,            PM_UNIT_SMQCTL,     {PASCAL_SM_INST_EXECUTED_128B,PASCAL_SM_GENERIC_STORE,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},    (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},

    { PASCAL_LUT_COUNTER_SHLD_32BIT_INST,           pascal_lut_counter_shld_32bit_inst_enc_str_1,         PM_UNIT_SMQCTL,     {PASCAL_SM_INST_EXECUTED_32B,PASCAL_SM_SHARED_LOAD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { PASCAL_LUT_COUNTER_SHLD_64BIT_INST,           pascal_lut_counter_shld_64bit_inst_enc_str_1,         PM_UNIT_SMQCTL,     {PASCAL_SM_INST_EXECUTED_64B,PASCAL_SM_SHARED_LOAD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { PASCAL_LUT_COUNTER_SHLD_128BIT_INST,          pascal_lut_counter_shld_128bit_inst_enc_str_1,        PM_UNIT_SMQCTL,     {PASCAL_SM_INST_EXECUTED_128B,PASCAL_SM_SHARED_LOAD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { PASCAL_LUT_COUNTER_SHLD_U128BIT_INST,         pascal_lut_counter_shld_u128bit_inst_enc_str_1,      PM_UNIT_SMQCTL,     {PASCAL_SM_INST_EXECUTED_U128B,PASCAL_SM_SHARED_LOAD,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { PASCAL_LUT_COUNTER_SHST_32BIT_INST,           pascal_lut_counter_shst_32bit_inst_enc_str_1,         PM_UNIT_SMQCTL,     {PASCAL_SM_INST_EXECUTED_32B,PASCAL_SM_SHARED_STORE,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { PASCAL_LUT_COUNTER_SHST_64BIT_INST,           pascal_lut_counter_shst_64bit_inst_enc_str_1,         PM_UNIT_SMQCTL,     {PASCAL_SM_INST_EXECUTED_64B,PASCAL_SM_SHARED_STORE,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { PASCAL_LUT_COUNTER_SHST_128BIT_INST,          pascal_lut_counter_shst_128bit_inst_enc_str_1,        PM_UNIT_SMQCTL,     {PASCAL_SM_INST_EXECUTED_128B,PASCAL_SM_SHARED_STORE,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},

    { PASCAL_LUT_COUNTER_GENERIC_SHARED_LD_INST,    pascal_lut_counter_generic_shared_ld_inst_enc_str_1,     PM_UNIT_SMQCTL,     {PASCAL_SM_GENERIC_LOAD,PASCAL_SM_INST_EXECUTED_LSU_GENERIC_SHARED,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { PASCAL_LUT_COUNTER_GENERIC_SHARED_ST_INST,    pascal_lut_counter_generic_shared_st_inst_enc_str_1,     PM_UNIT_SMQCTL,     {PASCAL_SM_GENERIC_STORE,PASCAL_SM_INST_EXECUTED_LSU_GENERIC_SHARED,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},

    { PASCAL_LUT_COUNTER_GENERIC_SHARED_LD_32BIT_INST,    pascal_lut_counter_generic_shared_ld_32bit_inst_enc_str_1,     PM_UNIT_SMQCTL,     {PASCAL_SM_GENERIC_LOAD,PASCAL_SM_INST_EXECUTED_LSU_GENERIC_SHARED,PASCAL_SM_INST_EXECUTED_32B,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE)},
    { PASCAL_LUT_COUNTER_GENERIC_SHARED_LD_64BIT_INST,    pascal_lut_counter_generic_shared_ld_64bit_inst_enc_str_1,     PM_UNIT_SMQCTL,     {PASCAL_SM_GENERIC_LOAD,PASCAL_SM_INST_EXECUTED_LSU_GENERIC_SHARED,PASCAL_SM_INST_EXECUTED_64B,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE)},
    { PASCAL_LUT_COUNTER_GENERIC_SHARED_LD_128BIT_INST,   pascal_lut_counter_generic_shared_ld_128bit_inst_enc_str_1,    PM_UNIT_SMQCTL,     {PASCAL_SM_GENERIC_LOAD,PASCAL_SM_INST_EXECUTED_LSU_GENERIC_SHARED,PASCAL_SM_INST_EXECUTED_128B,INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE)},

    { PASCAL_LUT_COUNTER_GENERIC_SHARED_ST_32BIT_INST,    pascal_lut_counter_generic_shared_st_32bit_inst_enc_str_1,     PM_UNIT_SMQCTL,     {PASCAL_SM_GENERIC_STORE,PASCAL_SM_INST_EXECUTED_LSU_GENERIC_SHARED,PASCAL_SM_INST_EXECUTED_32B,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE)},
    { PASCAL_LUT_COUNTER_GENERIC_SHARED_ST_64BIT_INST,    pascal_lut_counter_generic_shared_st_64bit_inst_enc_str_1,     PM_UNIT_SMQCTL,     {PASCAL_SM_GENERIC_STORE,PASCAL_SM_INST_EXECUTED_LSU_GENERIC_SHARED,PASCAL_SM_INST_EXECUTED_64B,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE)},
    { PASCAL_LUT_COUNTER_GENERIC_SHARED_ST_128BIT_INST,   pascal_lut_counter_generic_shared_st_128bit_inst_enc_str_1,    PM_UNIT_SMQCTL,     {PASCAL_SM_GENERIC_STORE,PASCAL_SM_INST_EXECUTED_LSU_GENERIC_SHARED,PASCAL_SM_INST_EXECUTED_128B,INVALID_PM_SIGNAL_NEW},     (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE & TRUTH_TABLE_FUNCTION_BIT_2_TRUE)},

    { PASCAL_LUT_COUNTER_SH_ATOM_32BIT_INST,        pascal_lut_counter_sh_atom_32bit_inst_enc_str_1,       PM_UNIT_SMQCTL,     {PASCAL_SM_INST_EXECUTED_32B,PASCAL_SM_SHARED_ATOM,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { PASCAL_LUT_COUNTER_SH_ATOM_64BIT_INST,        pascal_lut_counter_sh_atom_64bit_inst_enc_str_1,       PM_UNIT_SMQCTL,     {PASCAL_SM_INST_EXECUTED_64B,PASCAL_SM_SHARED_ATOM,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { PASCAL_LUT_COUNTER_SH_ATOM_CAS_32BIT_INST,    pascal_lut_counter_sh_atom_cas_32bit_inst_enc_str_1,   PM_UNIT_SMQCTL,     {PASCAL_SM_INST_EXECUTED_32B,PASCAL_SM_SHARED_ATOM_CAS,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},
    { PASCAL_LUT_COUNTER_SH_ATOM_CAS_64BIT_INST,    pascal_lut_counter_sh_atom_cas_64bit_inst_enc_str_1,   PM_UNIT_SMQCTL,     {PASCAL_SM_INST_EXECUTED_64B,PASCAL_SM_SHARED_ATOM_CAS,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW},      (TRUTH_TABLE_FUNCTION_BIT_0_TRUE & TRUTH_TABLE_FUNCTION_BIT_1_TRUE)},

    { INVALID_PM_SIGNAL_NEW,               "", PM_UNIT_MAX, {INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW} , TRUTH_TABLE_FUNCTION_ALL_FALSE}
};
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B) */

#if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
CUeventDataSmpcExpt PerfSignalTableGP100_multiGroup[] = {
    { PASCAL_SM_PMTRIG_MULTI_GROUP,             pascal_multigrp_counter_pmtrig_enc_str_1,             PM_UNIT_SMQCTL,     {PASCAL_SM_PMTRIG0,PASCAL_SM_PMTRIG4,PASCAL_SM_PMTRIG10,PASCAL_SM_PMTRIG15,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW}},

    { INVALID_PM_SIGNAL_NEW,               "", PM_UNIT_MAX, {INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW,INVALID_PM_SIGNAL_NEW} , TRUTH_TABLE_FUNCTION_ALL_FALSE}
};
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B) */

#if NVCFG(GLOBAL_GPU_FAMILY_GP10X)
CUdomainData domainTableGP100[] = {
    {PASCAL_CLK_DOMAIN_GP100_GPCTPC,                       pascal_clk_domain_gp100_gpctpc_enc_str_1,         CUPROF_EVENT_COLLECTION_METHOD_HWPM,     { {(void *)PerfSignalTableGP100_gpctpc, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGP100_gpctpc_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1}, {(void *)PerfSignalTableGP100_gpctpc_extended, PERF_SIG_TABLE_TYPE_HWPM} },    0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 3},
    {PASCAL_CLK_DOMAIN_GP100_GPCTPC_VIRTUAL_CORE,          pascal_clk_domain_gp100_gpctpc_virtual_enc_str_1, CUPROF_EVENT_COLLECTION_METHOD_HWPM,     { {(void *)PerfSignalTableGP100_gpctpc_virtual_expt, PERF_SIG_TABLE_TYPE_HWPM_VIRTUAL_EXPT}},    0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1 },

    //Both ltc0 and ltc1 clock domains will be supported by this external domain
    {PASCAL_CLK_DOMAIN_GP100_FBP0,                         pascal_clk_domain_gp100_fbp0_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGP100_fbp0, PERF_SIG_TABLE_TYPE_HWPM}},                                0,  0,  0,  PM_CHIPLET_TYPE_FBP, 0, 0, 1},
    // Creating separate domain  for sw counters
    // sw counters may also have separate domain types based on type of instrumentation
    {PASCAL_SW_DOMAIN_GP100_PPA_NOPTRIG_GLOBAL_LOAD_STORE, pascal_sw_domain_gp100_ppa_noptrig_global_load_store_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGPSwCounters_nop_trig_global_load_store, PERF_SIG_TABLE_TYPE_SMPC}},   0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_CLK_DOMAIN_GP100_SM_COREMIO,                   pascal_clk_domain_gp100_sm1_enc_str_1,  CUPROF_EVENT_COLLECTION_METHOD_SMPERF,            {{(void *)PerfSignalTableGP100_sm0_coremio, PERF_SIG_TABLE_TYPE_SMPC}, {(void *)PerfSignalTableGP100_sm0_coremio_extended, PERF_SIG_TABLE_TYPE_SMPC}},        0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 2},
    {PASCAL_CLK_DOMAIN_GP100_SM_QUAD,                      pascal_clk_domain_gp100_sm0_enc_str_1,  CUPROF_EVENT_COLLECTION_METHOD_SMPERF,            {{(void *)PerfSignalTableGP100_sm0_quad, PERF_SIG_TABLE_TYPE_SMPC}, {(void *)PerfSignalTableGP100_LutModeCounters, PERF_SIG_TABLE_TYPE_LUT}, {(void *)PerfSignalTableGP100_multiGroup, PERF_SIG_TABLE_TYPE_MULTI_GROUP}, {(void *)PerfSignalTableGP100_sm0_quad_extended, PERF_SIG_TABLE_TYPE_SMPC}},        0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 4},
    {PASCAL_CLK_DOMAIN_GP100_SM_MIO,                       pascal_clk_domain_gp100_sm2_enc_str_1,  CUPROF_EVENT_COLLECTION_METHOD_SMPERF,            {{(void *)PerfSignalTableGP100_sm0_mio, PERF_SIG_TABLE_TYPE_SMPC}, {(void *)PerfSignalTableGP100_miohalf_expt, PERF_SIG_TABLE_TYPE_SMPC_EXPERIMENT}},        0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 2},
    {PASCAL_CLK_DOMAIN_GP100_LTC0,                         pascal_clk_domain_gp100_ltc0_enc_str_1, CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGP100_ltc0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGP100_ltc0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1}},       0,  0,  0,  PM_CHIPLET_TYPE_FBP, 0, 0, 2},
    {PASCAL_SW_DOMAIN_GP100_PPA_NOPTRIG_FLOPS,             pascal_sw_domain_gp100_ppa_noptrig_flops_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGPSwCounters_nop_trig_flops, PERF_SIG_TABLE_TYPE_SMPC}},               0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_SW_DOMAIN_GP100_PPA_NOPTRIG_INSTR_CLASS,       pascal_sw_domain_gp100_ppa_noptrig_instr_class_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGPSwCounters_instrClass, PERF_SIG_TABLE_TYPE_SMPC}},               0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_SW_DOMAIN_GP100_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS,       pascal_sw_domain_gp100_ppa_noptrig_generic_counters_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGPSwCounters_genericLdStCounters, PERF_SIG_TABLE_TYPE_SMPC}},               0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_SW_DOMAIN_GP100_PPA_NOPTRIG_SHARED_LOAD_STORE, pascal_sw_domain_gp100_ppa_noptrig_shared_load_store_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGPSwCounters_nop_trig_shared_load_store, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_CLK_DOMAIN_GP100_NVLINK_THROUGHPUT_COUNTERS, pascal_clk_domain_gp100_nvlink_throughput_counters_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_NVLINK_TC, {{PerfSignalTableGP100_nvlinkTC, PERF_SIG_TABLE_TYPE_NVLINK_THROUGHPUT_CNTR}},      0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 1, CUPROF_EVENT_COLLECTION_SCOPE_DEVICE},
    {PASCAL_SW_DOMAIN_GP100_PPA_NOPTRIG_UNIQUE_GLD_GST,   pascal_sw_domain_gp100_ppa_noptrig_unique_gld_gst_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGPSwCounters_unique_gld_gst, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_SW_DOMAIN_GP100_PPA_NOPTRIG_UNIQUE_SECTOR_ACCESS_GLD,   pascal_sw_domain_gp100_ppa_noptrig_unique_sector_access_gld_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGPSwCounters_unique_sector_access_gld, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    // Keep domains of exposed events and events used in metrics, before domains belong to internal events.
    // Else, such events won't get enumerated.
    {PASCAL_CLK_DOMAIN_GP100_PCIE0,                        pascal_clk_domain_gp100_pcie0_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGP100_pcie0, PERF_SIG_TABLE_TYPE_HWPM}},      0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 1, CUPROF_EVENT_COLLECTION_SCOPE_DEVICE},
    //PASCAL_CLK_DOMAIN_GP100_HWPMMUX will be a dummy id that is used to identify the HWPM signals profiled via SMPC.
    //We require this so that we can restrict profiling these signals with pure HWPM or pure SMPC signals
    //Currently there is no way to avoid this except having check at domain level, also it is possible that we will allow pure HWPM signals with pure SMPC.
    //Internally this domain id will be mapped to PASCAL_CLK_DOMAIN_GP100_GPCTPC
    {PASCAL_CLK_DOMAIN_GP100_HWPMMUX_COREMIO,               pascal_clk_domain_gp100_hwpmmux_coremio_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX,           {{(void *)PerfSignalTableGP100_hwpmmux_coremio, PERF_SIG_TABLE_TYPE_HWPMMUX}},                          0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},

    {PASCAL_CLK_DOMAIN_GP100_HWPMMUX_QUAD,                  pascal_clk_domain_gp100_hwpmmux_quad_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX,              {{(void *)PerfSignalTableGP100_hwpmmux_quad, PERF_SIG_TABLE_TYPE_HWPMMUX}},                          0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_CLK_DOMAIN_GP100_SYS0,                         pascal_clk_domain_gp100_sys0_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGP100_sys0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGP100_sys0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1}, {(void *)PerfSignalTableGP100_nvlink0, PERF_SIG_TABLE_TYPE_NVLINK}},      0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 3},
    {PASCAL_CLK_DOMAIN_GP100_SYS1,                         pascal_clk_domain_gp100_sys1_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGP100_nvlink1, PERF_SIG_TABLE_TYPE_NVLINK}},                          0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 1},
    {PASCAL_CLK_DOMAIN_GP100_GPC0,                         pascal_clk_domain_gp100_gpc0_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGP100_gpc0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGP100_gpc0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1}},                                0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 2},
};

CUdomainData domainTableGP10x[] = {
    {PASCAL_CLK_DOMAIN_GP10X_GPCTPC,                       pascal_clk_domain_gp100_gpctpc_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGP100_gpctpc, PERF_SIG_TABLE_TYPE_HWPM},{(void *)PerfSignalTableGP100_gpctpc_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1}, {(void *)PerfSignalTableGP10X_gpctpc_extended, PERF_SIG_TABLE_TYPE_HWPM}},    0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 3},
    //Both ltc0 and ltc1 clock domains will be supported by this external domain
    {PASCAL_CLK_DOMAIN_GP10X_FBP0,                         pascal_clk_domain_gp100_fbp0_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGP10x_fbp0, PERF_SIG_TABLE_TYPE_HWPM}},                                0,  0,  0,  PM_CHIPLET_TYPE_FBP, 0, 0, 1},
    // Creating separate domain  for sw counters
    // sw counters may also have separate domain types based on type of instrumentation
    {PASCAL_SW_DOMAIN_GP10X_PPA_NOPTRIG_GLOBAL_LOAD_STORE, pascal_sw_domain_gp100_ppa_noptrig_global_load_store_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGPSwCounters_nop_trig_global_load_store, PERF_SIG_TABLE_TYPE_SMPC}},   0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_CLK_DOMAIN_GP10X_SM0,                          pascal_clk_domain_gp100_sm0_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_SMPERF,            {{(void *)PerfSignalTableGP100_sm0_coremio, PERF_SIG_TABLE_TYPE_SMPC}, {(void *)PerfSignalTableGP100_sm0_quad, PERF_SIG_TABLE_TYPE_SMPC}, {(void *)PerfSignalTableGP100_sm0_mio, PERF_SIG_TABLE_TYPE_SMPC}, {(void *)PerfSignalTableGP100_miohalf_expt, PERF_SIG_TABLE_TYPE_SMPC_EXPERIMENT}, {(void *)PerfSignalTableGP100_LutModeCounters, PERF_SIG_TABLE_TYPE_LUT}, {(void *)PerfSignalTableGP100_multiGroup, PERF_SIG_TABLE_TYPE_MULTI_GROUP}, {(void *)PerfSignalTableGP10X_sm0_coremio_extended, PERF_SIG_TABLE_TYPE_SMPC}, {(void *)PerfSignalTableGP10X_sm0_quad_extended, PERF_SIG_TABLE_TYPE_SMPC}},        0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 8},
    {PASCAL_CLK_DOMAIN_GP10X_LTC0,                         pascal_clk_domain_gp100_ltc0_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGP10x_ltc0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGP100_ltc0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1}},       0,  0,  0,  PM_CHIPLET_TYPE_FBP, 0, 0, 2},
    {PASCAL_SW_DOMAIN_GP10X_PPA_NOPTRIG_FLOPS,             pascal_sw_domain_gp100_ppa_noptrig_flops_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGPSwCounters_nop_trig_flops, PERF_SIG_TABLE_TYPE_SMPC}},               0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_SW_DOMAIN_GP10X_PPA_NOPTRIG_INSTR_CLASS,       pascal_sw_domain_gp100_ppa_noptrig_instr_class_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGPSwCounters_instrClass, PERF_SIG_TABLE_TYPE_SMPC}},               0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_SW_DOMAIN_GP10X_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS,       pascal_sw_domain_gp100_ppa_noptrig_generic_counters_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGPSwCounters_genericLdStCounters, PERF_SIG_TABLE_TYPE_SMPC}},               0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_SW_DOMAIN_GP10X_PPA_NOPTRIG_SHARED_LOAD_STORE, pascal_sw_domain_gp100_ppa_noptrig_shared_load_store_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGPSwCounters_nop_trig_shared_load_store, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_SW_DOMAIN_GP10X_PPA_NOPTRIG_UNIQUE_GLD_GST,   pascal_sw_domain_gp100_ppa_noptrig_unique_gld_gst_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGPSwCounters_unique_gld_gst, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_SW_DOMAIN_GP10X_PPA_NOPTRIG_UNIQUE_SECTOR_ACCESS_GLD,   pascal_sw_domain_gp100_ppa_noptrig_unique_sector_access_gld_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGPSwCounters_unique_sector_access_gld, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    // Keep domains of exposed events and events used in metrics, before domains belong to internal events.
    // Else, such events won't get enumerated.
    {PASCAL_CLK_DOMAIN_GP10X_PCIE0,                        pascal_clk_domain_gp100_pcie0_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGP100_pcie0, PERF_SIG_TABLE_TYPE_HWPM}},      0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 1, CUPROF_EVENT_COLLECTION_SCOPE_DEVICE},
    //PASCAL_CLK_DOMAIN_GP100_HWPMMUX will be a dummy id that is used to identify the HWPM signals profiled via SMPC.
    //We require this so that we can restrict profiling these signals with pure HWPM or pure SMPC signals
    //Currently there is no way to avoid this except having check at domain level, also it is possible that we will allow pure HWPM signals with pure SMPC.
    //Internally this domain id will be mapped to PASCAL_CLK_DOMAIN_GP100_GPCTPC
    {PASCAL_CLK_DOMAIN_GP10X_HWPMMUX,                      pascal_clk_domain_gp100_hwpmmux_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX,              {{(void *)PerfSignalTableGP100_hwpmmux_quad, PERF_SIG_TABLE_TYPE_HWPMMUX}, {(void *)PerfSignalTableGP100_hwpmmux_coremio, PERF_SIG_TABLE_TYPE_HWPMMUX}},                          0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 2},
    {PASCAL_CLK_DOMAIN_GP10X_SYS0,                         pascal_clk_domain_gp100_sys0_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGP10x_sys0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGP100_sys0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1}},       0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 2},
    {PASCAL_CLK_DOMAIN_GP100_GPC0,                         pascal_clk_domain_gp100_gpc0_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGP10x_gpc0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGP100_gpc0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1}},                                0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 2},
};

#if defined(NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GP107) || defined(NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GP108)
CUdomainData domainTableGP107[] = {
    {PASCAL_CLK_DOMAIN_GP10X_GPCTPC,                       pascal_clk_domain_gp100_gpctpc_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGP100_gpctpc, PERF_SIG_TABLE_TYPE_HWPM},{(void *)PerfSignalTableGP100_gpctpc_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1}, {(void *)PerfSignalTableGP10X_gpctpc_extended, PERF_SIG_TABLE_TYPE_HWPM}},    0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 3},
    //Both ltc0 and ltc1 clock domains will be supported by this external domain
    {PASCAL_CLK_DOMAIN_GP10X_FBP0,                         pascal_clk_domain_gp100_fbp0_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGP10x_fbp0, PERF_SIG_TABLE_TYPE_HWPM}},                                0,  0,  0,  PM_CHIPLET_TYPE_FBP, 0, 0, 1},
    // Creating separate domain  for sw counters
    // sw counters may also have separate domain types based on type of instrumentation
    {PASCAL_SW_DOMAIN_GP10X_PPA_NOPTRIG_GLOBAL_LOAD_STORE, pascal_sw_domain_gp100_ppa_noptrig_global_load_store_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGPSwCounters_nop_trig_global_load_store, PERF_SIG_TABLE_TYPE_SMPC}},   0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_CLK_DOMAIN_GP10X_SM0,                          pascal_clk_domain_gp100_sm0_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_SMPERF,            {{(void *)PerfSignalTableGP100_sm0_coremio, PERF_SIG_TABLE_TYPE_SMPC}, {(void *)PerfSignalTableGP100_sm0_quad, PERF_SIG_TABLE_TYPE_SMPC}, {(void *)PerfSignalTableGP100_sm0_mio, PERF_SIG_TABLE_TYPE_SMPC}, {(void *)PerfSignalTableGP100_miohalf_expt, PERF_SIG_TABLE_TYPE_SMPC_EXPERIMENT}, {(void *)PerfSignalTableGP100_LutModeCounters, PERF_SIG_TABLE_TYPE_LUT}, {(void *)PerfSignalTableGP100_multiGroup, PERF_SIG_TABLE_TYPE_MULTI_GROUP}, {(void *)PerfSignalTableGP10X_sm0_coremio_extended, PERF_SIG_TABLE_TYPE_SMPC}, {(void *)PerfSignalTableGP10X_sm0_quad_extended, PERF_SIG_TABLE_TYPE_SMPC}},        0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 8},
    {PASCAL_CLK_DOMAIN_GP10X_LTC0,                         pascal_clk_domain_gp100_ltc0_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGP107_ltc0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGP100_ltc0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1}},       0,  0,  0,  PM_CHIPLET_TYPE_FBP, 0, 0, 2},
    {PASCAL_SW_DOMAIN_GP10X_PPA_NOPTRIG_FLOPS,             pascal_sw_domain_gp100_ppa_noptrig_flops_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGPSwCounters_nop_trig_flops, PERF_SIG_TABLE_TYPE_SMPC}},               0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_SW_DOMAIN_GP10X_PPA_NOPTRIG_INSTR_CLASS,       pascal_sw_domain_gp100_ppa_noptrig_instr_class_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGPSwCounters_instrClass, PERF_SIG_TABLE_TYPE_SMPC}},               0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_SW_DOMAIN_GP10X_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS,       pascal_sw_domain_gp100_ppa_noptrig_generic_counters_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGPSwCounters_genericLdStCounters, PERF_SIG_TABLE_TYPE_SMPC}},               0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_SW_DOMAIN_GP10X_PPA_NOPTRIG_SHARED_LOAD_STORE, pascal_sw_domain_gp100_ppa_noptrig_shared_load_store_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGPSwCounters_nop_trig_shared_load_store, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_SW_DOMAIN_GP10X_PPA_NOPTRIG_UNIQUE_GLD_GST,   pascal_sw_domain_gp100_ppa_noptrig_unique_gld_gst_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGPSwCounters_unique_gld_gst, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_SW_DOMAIN_GP10X_PPA_NOPTRIG_UNIQUE_SECTOR_ACCESS_GLD,   pascal_sw_domain_gp100_ppa_noptrig_unique_sector_access_gld_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGPSwCounters_unique_sector_access_gld, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    // Keep domains of exposed events and events used in metrics, before domains belong to internal events.
    // Else, such events won't get enumerated.
    {PASCAL_CLK_DOMAIN_GP10X_PCIE0,                        pascal_clk_domain_gp100_pcie0_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGP100_pcie0, PERF_SIG_TABLE_TYPE_HWPM}},      0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 1, CUPROF_EVENT_COLLECTION_SCOPE_DEVICE},
    //PASCAL_CLK_DOMAIN_GP100_HWPMMUX will be a dummy id that is used to identify the HWPM signals profiled via SMPC.
    //We require this so that we can restrict profiling these signals with pure HWPM or pure SMPC signals
    //Currently there is no way to avoid this except having check at domain level, also it is possible that we will allow pure HWPM signals with pure SMPC.
    //Internally this domain id will be mapped to PASCAL_CLK_DOMAIN_GP100_GPCTPC
    {PASCAL_CLK_DOMAIN_GP10X_HWPMMUX,                      pascal_clk_domain_gp100_hwpmmux_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX,              {{(void *)PerfSignalTableGP100_hwpmmux_quad, PERF_SIG_TABLE_TYPE_HWPMMUX}, {(void *)PerfSignalTableGP100_hwpmmux_coremio, PERF_SIG_TABLE_TYPE_HWPMMUX}},                          0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 2},
    {PASCAL_CLK_DOMAIN_GP10X_SYS0,                         pascal_clk_domain_gp100_sys0_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGP10x_sys0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGP100_sys0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1}},       0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 2},
    {PASCAL_CLK_DOMAIN_GP107_GPC0,                         pascal_clk_domain_gp100_gpc0_enc_str_1,    CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGP107_gpc0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGP107_gpc0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1}},                                0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 2},
};
#endif
#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) */

#if NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
CUdomainData domainTableGP10Y[] = {
    {PASCAL_CLK_DOMAIN_GP10Y_GPCTPC,                       pascal_clk_domain_gp100_gpctpc_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGP100_gpctpc, PERF_SIG_TABLE_TYPE_HWPM},{(void *)PerfSignalTableGP100_gpctpc_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}, {(void *)PerfSignalTableGP10X_gpctpc_extended, PERF_SIG_TABLE_TYPE_HWPM}},    0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 3},
    {PASCAL_CLK_DOMAIN_GP10Y_FBP0,                         pascal_clk_domain_gp100_fbp0_enc_str_1,        CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGP10Y_ltc0, PERF_SIG_TABLE_TYPE_HWPM},{(void *)PerfSignalTableGP10Y_ltc0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}},                                0,  0,  0,  PM_CHIPLET_TYPE_FBP, 0, 0, 2},
    {PASCAL_SW_DOMAIN_GP10X_PPA_NOPTRIG_GLOBAL_LOAD_STORE, pascal_sw_domain_gp100_ppa_noptrig_global_load_store_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGPSwCounters_nop_trig_global_load_store, PERF_SIG_TABLE_TYPE_SMPC}},   0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_CLK_DOMAIN_GP10X_SM0,                          pascal_clk_domain_gp100_sm0_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_SMPERF,            {{(void *)PerfSignalTableGP100_sm0_coremio, PERF_SIG_TABLE_TYPE_SMPC}, {(void *)PerfSignalTableGP100_sm0_quad, PERF_SIG_TABLE_TYPE_SMPC}, {(void *)PerfSignalTableGP100_sm0_mio, PERF_SIG_TABLE_TYPE_SMPC}, {(void *)PerfSignalTableGP100_miohalf_expt, PERF_SIG_TABLE_TYPE_SMPC_EXPERIMENT}, {(void *)PerfSignalTableGP100_LutModeCounters, PERF_SIG_TABLE_TYPE_LUT}, {(void *)PerfSignalTableGP100_multiGroup, PERF_SIG_TABLE_TYPE_MULTI_GROUP}, {(void *)PerfSignalTableGP10X_sm0_coremio_extended, PERF_SIG_TABLE_TYPE_SMPC}, {(void *)PerfSignalTableGP10X_sm0_quad_extended, PERF_SIG_TABLE_TYPE_SMPC}},        0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 8},
    {PASCAL_SW_DOMAIN_GP10X_PPA_NOPTRIG_FLOPS,             pascal_sw_domain_gp100_ppa_noptrig_flops_enc_str_1,        CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGPSwCounters_nop_trig_flops, PERF_SIG_TABLE_TYPE_SMPC}},               0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_SW_DOMAIN_GP10X_PPA_NOPTRIG_INSTR_CLASS,       pascal_sw_domain_gp100_ppa_noptrig_instr_class_enc_str_1,  CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGPSwCounters_instrClass, PERF_SIG_TABLE_TYPE_SMPC}},               0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_SW_DOMAIN_GP10X_PPA_NOPTRIG_GENERIC_LD_ST_COUNTERS,       pascal_sw_domain_gp100_ppa_noptrig_generic_counters_enc_str_1,      CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW,    {{(void *)PerfSignalTableGPSwCounters_genericLdStCounters, PERF_SIG_TABLE_TYPE_SMPC}},               0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_SW_DOMAIN_GP10X_PPA_NOPTRIG_SHARED_LOAD_STORE, pascal_sw_domain_gp100_ppa_noptrig_shared_load_store_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGPSwCounters_nop_trig_shared_load_store, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_SW_DOMAIN_GP10X_PPA_NOPTRIG_UNIQUE_GLD_GST,   pascal_sw_domain_gp100_ppa_noptrig_unique_gld_gst_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGPSwCounters_unique_gld_gst, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    {PASCAL_SW_DOMAIN_GP10X_PPA_NOPTRIG_UNIQUE_SECTOR_ACCESS_GLD,   pascal_sw_domain_gp100_ppa_noptrig_unique_sector_access_gld_enc_str_1,   CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW, {{PerfSignalTableGPSwCounters_unique_sector_access_gld, PERF_SIG_TABLE_TYPE_COMMON}},      0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
    //PASCAL_CLK_DOMAIN_GP10Y_HWPMMUX will be a dummy id that is used to identify the HWPM signals profiled via SMPC.
    //We require this so that we can restrict profiling these signals with pure HWPM or pure SMPC signals
    //Currently there is no way to avoid this except having check at domain level, also it is possible that we will allow pure HWPM signals with pure SMPC.
    //Internally this domain id will be mapped to PASCAL_CLK_DOMAIN_GP10Y_GPCTPC
    {PASCAL_CLK_DOMAIN_GP10Y_HWPMMUX,                      pascal_clk_domain_gp100_hwpmmux_enc_str_1,     CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX,           {{(void *)PerfSignalTableGP100_hwpmmux_quad, PERF_SIG_TABLE_TYPE_HWPMMUX}, {(void *)PerfSignalTableGP100_hwpmmux_coremio, PERF_SIG_TABLE_TYPE_HWPMMUX}},                          0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 2},
    {PASCAL_CLK_DOMAIN_GP10Y_SYS0,                         pascal_clk_domain_gp100_sys0_enc_str_1,        CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGP10Y_sys0, PERF_SIG_TABLE_TYPE_HWPM}, {(void *)PerfSignalTableGP10Y_sys0_expt, PERF_SIG_TABLE_TYPE_HWPM_EXPT}},       0,  0,  0,  PM_CHIPLET_TYPE_SYS, 0, 0, 2},
    {PASCAL_CLK_DOMAIN_GP10Y_GPC0,                         pascal_clk_domain_gp100_gpc0_enc_str_1,        CUPROF_EVENT_COLLECTION_METHOD_HWPM,              {{(void *)PerfSignalTableGP10y_gpc0, PERF_SIG_TABLE_TYPE_HWPM}},                                0,  0,  0,  PM_CHIPLET_TYPE_GPC, 0, 0, 1},
};
#endif /* #if NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B) */

SignalDescriptionTable pPascalSignalDescriptionArray[] = {
#if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
    {PASCAL_TEX0_SECTOR_QUERIES, pascal_tex0_sector_queries_enc_str_1, pascal_tex0_sector_queries_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_sector_queries_enc_str_4},
    {PASCAL_TEX1_SECTOR_QUERIES, pascal_tex1_sector_queries_enc_str_1, pascal_tex1_sector_queries_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_sector_queries_enc_str_4},
    {PASCAL_TEX0_MISSED_SECTORS, pascal_tex0_missed_sectors_enc_str_1, pascal_tex0_missed_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_missed_sectors_enc_str_4},
    {PASCAL_TEX1_MISSED_SECTORS, pascal_tex1_missed_sectors_enc_str_1, pascal_tex1_missed_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_missed_sectors_enc_str_4},
    {PASCAL_TEX0_LG_SECTOR_QUERIES, pascal_tex0_lg_sector_queries_enc_str_1, pascal_tex0_lg_sector_queries_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_lg_sector_queries_enc_str_4},
    {PASCAL_TEX1_LG_SECTOR_QUERIES, pascal_tex1_lg_sector_queries_enc_str_1, pascal_tex1_lg_sector_queries_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_lg_sector_queries_enc_str_4},
    {PASCAL_TEX0_LG_MISSED_SECTORS, pascal_tex0_lg_missed_sectors_enc_str_1, pascal_tex0_lg_missed_sectors_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_lg_missed_sectors_enc_str_4},
    {PASCAL_TEX1_LG_MISSED_SECTORS, pascal_tex1_lg_missed_sectors_enc_str_1, pascal_tex1_lg_missed_sectors_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_lg_missed_sectors_enc_str_4},
    {PASCAL_TEX0_MISSED_SECTORS_ANY, pascal_tex0_missed_sectors_any_enc_str_1, pascal_tex0_missed_sectors_any_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_missed_sectors_any_enc_str_1},
    {PASCAL_TEX1_MISSED_SECTORS_ANY, pascal_tex1_missed_sectors_any_enc_str_1, pascal_tex1_missed_sectors_any_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_missed_sectors_any_enc_str_1},
    {PASCAL_TEX0_COALESCED_SECTORS, pascal_tex0_coalesced_sectors_enc_str_1, pascal_tex0_coalesced_sectors_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_coalesced_sectors_enc_str_1},
    {PASCAL_TEX1_COALESCED_SECTORS, pascal_tex1_coalesced_sectors_enc_str_1, pascal_tex1_coalesced_sectors_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_coalesced_sectors_enc_str_1},

    {PASCAL_TEX0_GLOBAL_LD_HITS,   pascal_tex0_global_ld_hits_enc_str_1,   pascal_tex0_global_ld_hits_enc_str_1,   CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_ld_hits_enc_str_1},
    {PASCAL_TEX1_GLOBAL_LD_HITS,   pascal_tex1_global_ld_hits_enc_str_1,   pascal_tex1_global_ld_hits_enc_str_1,   CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_ld_hits_enc_str_1},
    {PASCAL_TEX0_GLOBAL_LD_MISSES, pascal_tex0_global_ld_misses_enc_str_1, pascal_tex0_global_ld_misses_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_ld_misses_enc_str_1},
    {PASCAL_TEX1_GLOBAL_LD_MISSES, pascal_tex1_global_ld_misses_enc_str_1, pascal_tex1_global_ld_misses_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_ld_misses_enc_str_1},
    {PASCAL_TEX0_LOCAL_LD_HITS,    pascal_tex0_local_ld_hits_enc_str_1,    pascal_tex0_local_ld_hits_enc_str_1,    CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_local_ld_hits_enc_str_1},
    {PASCAL_TEX1_LOCAL_LD_HITS,    pascal_tex1_local_ld_hits_enc_str_1,    pascal_tex1_local_ld_hits_enc_str_1,    CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_local_ld_hits_enc_str_1},
    {PASCAL_TEX0_LOCAL_LD_MISSES,  pascal_tex0_local_ld_misses_enc_str_1,  pascal_tex0_local_ld_misses_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_local_ld_misses_enc_str_1},
    {PASCAL_TEX1_LOCAL_LD_MISSES,  pascal_tex1_local_ld_misses_enc_str_1,  pascal_tex1_local_ld_misses_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_local_ld_misses_enc_str_1},

    {PASCAL_TEX0_CACHED_GLOBAL_LD_HITS, pascal_tex0_cached_global_ld_hits_enc_str_1, pascal_tex0_cached_global_ld_hits_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_cached_global_ld_hits_enc_str_1},
    {PASCAL_TEX1_CACHED_GLOBAL_LD_HITS, pascal_tex1_cached_global_ld_hits_enc_str_1, pascal_tex1_cached_global_ld_hits_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_cached_global_ld_hits_enc_str_1},
    {PASCAL_TEX0_CACHED_GLOBAL_LD_MISSES, pascal_tex0_cached_global_ld_misses_enc_str_1, pascal_tex0_cached_global_ld_misses_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_cached_global_ld_misses_enc_str_1},
    {PASCAL_TEX0_UNCACHED_GLOBAL_LD_MISSES, pascal_tex0_uncached_global_ld_misses_enc_str_1, pascal_tex0_uncached_global_ld_misses_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_uncached_global_ld_misses_enc_str_1},
    {PASCAL_TEX1_CACHED_GLOBAL_LD_MISSES, pascal_tex1_cached_global_ld_misses_enc_str_1, pascal_tex1_cached_global_ld_misses_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_cached_global_ld_misses_enc_str_1},
    {PASCAL_TEX1_UNCACHED_GLOBAL_LD_MISSES, pascal_tex1_uncached_global_ld_misses_enc_str_1, pascal_tex1_uncached_global_ld_misses_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_uncached_global_ld_misses_enc_str_1},
    {PASCAL_TEX0_CACHED_GLOBAL_LD_SET_CONFLICTS, pascal_tex0_cached_global_ld_set_conflicts_enc_str_1, pascal_tex0_cached_global_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_cached_global_ld_set_conflicts_enc_str_1},
    {PASCAL_TEX0_GLOBAL_LD_SET_CONFLICTS, pascal_tex0_global_ld_set_conflicts_enc_str_1, pascal_tex0_global_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_ld_set_conflicts_enc_str_1},
    {PASCAL_TEX0_UNCACHED_GLOBAL_LD_SET_CONFLICTS, pascal_tex0_uncached_global_ld_set_conflicts_enc_str_1, pascal_tex0_uncached_global_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_uncached_global_ld_set_conflicts_enc_str_1},
    {PASCAL_TEX1_CACHED_GLOBAL_LD_SET_CONFLICTS, pascal_tex1_cached_global_ld_set_conflicts_enc_str_1, pascal_tex1_cached_global_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_cached_global_ld_set_conflicts_enc_str_1},
    {PASCAL_TEX1_GLOBAL_LD_SET_CONFLICTS, pascal_tex1_global_ld_set_conflicts_enc_str_1, pascal_tex1_global_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_ld_set_conflicts_enc_str_1},
    {PASCAL_TEX1_UNCACHED_GLOBAL_LD_SET_CONFLICTS, pascal_tex1_uncached_global_ld_set_conflicts_enc_str_1, pascal_tex1_uncached_global_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_uncached_global_ld_set_conflicts_enc_str_1},
    {PASCAL_TEX0_GLOBAL_LD_COALESCING, pascal_tex0_global_ld_coalescing_enc_str_1, pascal_tex0_global_ld_coalescing_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_ld_coalescing_enc_str_1},
    {PASCAL_TEX0_UNCACHED_GLOBAL_LD_COALESCING, pascal_tex0_uncached_global_ld_coalescing_enc_str_1, pascal_tex0_uncached_global_ld_coalescing_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_uncached_global_ld_coalescing_enc_str_1},
    {PASCAL_TEX1_GLOBAL_LD_COALESCING, pascal_tex1_global_ld_coalescing_enc_str_1, pascal_tex1_global_ld_coalescing_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_ld_coalescing_enc_str_1},
    {PASCAL_TEX1_UNCACHED_GLOBAL_LD_COALESCING, pascal_tex1_uncached_global_ld_coalescing_enc_str_1, pascal_tex1_uncached_global_ld_coalescing_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_uncached_global_ld_coalescing_enc_str_1},
    {PASCAL_TEX0_CACHED_LOCAL_LD_HITS, pascal_tex0_cached_local_ld_hits_enc_str_1, pascal_tex0_cached_local_ld_hits_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_cached_local_ld_hits_enc_str_1},
    {PASCAL_TEX1_CACHED_LOCAL_LD_HITS, pascal_tex1_cached_local_ld_hits_enc_str_1, pascal_tex1_cached_local_ld_hits_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_cached_local_ld_hits_enc_str_1},
    {PASCAL_TEX0_CACHED_LOCAL_LD_MISSES, pascal_tex0_cached_local_ld_misses_enc_str_1, pascal_tex0_cached_local_ld_misses_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_cached_local_ld_misses_enc_str_1},
    {PASCAL_TEX0_UNCACHED_LOCAL_LD_MISSES, pascal_tex0_uncached_local_ld_misses_enc_str_1, pascal_tex0_uncached_local_ld_misses_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_uncached_local_ld_misses_enc_str_1},
    {PASCAL_TEX1_CACHED_LOCAL_LD_MISSES, pascal_tex1_cached_local_ld_misses_enc_str_1, pascal_tex1_cached_local_ld_misses_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_cached_local_ld_misses_enc_str_1},
    {PASCAL_TEX1_UNCACHED_LOCAL_LD_MISSES, pascal_tex1_uncached_local_ld_misses_enc_str_1, pascal_tex1_uncached_local_ld_misses_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_uncached_local_ld_misses_enc_str_1},
    {PASCAL_TEX0_CACHED_GLOBAL_LD_SET_ACCESS, pascal_tex0_cached_global_ld_set_access_enc_str_1, pascal_tex0_cached_global_ld_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_cached_global_ld_set_access_enc_str_1},
    {PASCAL_TEX1_CACHED_GLOBAL_LD_SET_ACCESS, pascal_tex1_cached_global_ld_set_access_enc_str_1, pascal_tex1_cached_global_ld_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_cached_global_ld_set_access_enc_str_1},
    {PASCAL_TEX0_GLOBAL_LD_SET_ACCESS, pascal_tex0_global_ld_set_access_enc_str_1, pascal_tex0_global_ld_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_ld_set_access_enc_str_1},
    {PASCAL_TEX1_GLOBAL_LD_SET_ACCESS, pascal_tex1_global_ld_set_access_enc_str_1, pascal_tex1_global_ld_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_ld_set_access_enc_str_1},
    {PASCAL_TEX0_UNCACHED_GLOBAL_LD_SET_ACCESS, pascal_tex0_uncached_global_ld_set_access_enc_str_1, pascal_tex0_uncached_global_ld_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_uncached_global_ld_set_access_enc_str_1},
    {PASCAL_TEX1_UNCACHED_GLOBAL_LD_SET_ACCESS, pascal_tex1_uncached_global_ld_set_access_enc_str_1, pascal_tex1_uncached_global_ld_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_uncached_global_ld_set_access_enc_str_1},
    {PASCAL_TEX0_CACHED_LOCAL_LD_SET_ACCESS, pascal_tex0_cached_local_ld_set_access_enc_str_1, pascal_tex0_cached_local_ld_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_cached_local_ld_set_access_enc_str_1},
    {PASCAL_TEX0_LOCAL_LD_SET_ACCESS, pascal_tex0_local_ld_set_access_enc_str_1, pascal_tex0_local_ld_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_local_ld_set_access_enc_str_1},
    {PASCAL_TEX0_UNCACHED_LOCAL_LD_SET_ACCESS, pascal_tex0_uncached_local_ld_set_access_enc_str_1, pascal_tex0_uncached_local_ld_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_uncached_local_ld_set_access_enc_str_1},
    {PASCAL_TEX1_CACHED_LOCAL_LD_SET_ACCESS, pascal_tex1_cached_local_ld_set_access_enc_str_1, pascal_tex1_cached_local_ld_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_cached_local_ld_set_access_enc_str_1},
    {PASCAL_TEX1_LOCAL_LD_SET_ACCESS, pascal_tex1_local_ld_set_access_enc_str_1, pascal_tex1_local_ld_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_local_ld_set_access_enc_str_1},
    {PASCAL_TEX1_UNCACHED_LOCAL_LD_SET_ACCESS, pascal_tex1_uncached_local_ld_set_access_enc_str_1, pascal_tex1_uncached_local_ld_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_uncached_local_ld_set_access_enc_str_1},
    {PASCAL_TEX0_CACHED_LOCAL_LD_SET_CONFLICTS, pascal_tex0_cached_local_ld_set_conflicts_enc_str_1, pascal_tex0_cached_local_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_cached_local_ld_set_conflicts_enc_str_1},
    {PASCAL_TEX0_LOCAL_LD_SET_CONFLICTS, pascal_tex0_local_ld_set_conflicts_enc_str_1, pascal_tex0_local_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_local_ld_set_conflicts_enc_str_1},
    {PASCAL_TEX0_UNCACHED_LOCAL_LD_SET_CONFLICTS, pascal_tex0_uncached_local_ld_set_conflicts_enc_str_1, pascal_tex0_uncached_local_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_uncached_local_ld_set_conflicts_enc_str_1},
    {PASCAL_TEX1_CACHED_LOCAL_LD_SET_CONFLICTS, pascal_tex1_cached_local_ld_set_conflicts_enc_str_1, pascal_tex1_cached_local_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_cached_local_ld_set_conflicts_enc_str_1},
    {PASCAL_TEX1_LOCAL_LD_SET_CONFLICTS, pascal_tex1_local_ld_set_conflicts_enc_str_1, pascal_tex1_local_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_local_ld_set_conflicts_enc_str_1},
    {PASCAL_TEX1_UNCACHED_LOCAL_LD_SET_CONFLICTS, pascal_tex1_uncached_local_ld_set_conflicts_enc_str_1, pascal_tex1_uncached_local_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_uncached_local_ld_set_conflicts_enc_str_1},
    {PASCAL_TEX0_LOCAL_LD_COALESCING, pascal_tex0_local_ld_coalescing_enc_str_1, pascal_tex0_local_ld_coalescing_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_local_ld_coalescing_enc_str_1},
    {PASCAL_TEX0_UNCACHED_LOCAL_LD_COALESCING, pascal_tex0_uncached_local_ld_coalescing_enc_str_1, pascal_tex0_uncached_local_ld_coalescing_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_uncached_local_ld_coalescing_enc_str_1},
    {PASCAL_TEX1_LOCAL_LD_COALESCING, pascal_tex1_local_ld_coalescing_enc_str_1, pascal_tex1_local_ld_coalescing_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_local_ld_coalescing_enc_str_1},
    {PASCAL_TEX1_UNCACHED_LOCAL_LD_COALESCING, pascal_tex1_uncached_local_ld_coalescing_enc_str_1, pascal_tex1_uncached_local_ld_coalescing_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_uncached_local_ld_coalescing_enc_str_1},
    {PASCAL_TEX0_GLOBAL_ST_REQUESTS, pascal_tex0_global_st_requests_enc_str_1, pascal_tex0_global_st_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_st_requests_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ST_REQUESTS, pascal_tex1_global_st_requests_enc_str_1, pascal_tex1_global_st_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_st_requests_enc_str_1},
    {PASCAL_TEX0_GLOBAL_ST_SET_ACCESS, pascal_tex0_global_st_set_access_enc_str_1, pascal_tex0_global_st_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_st_set_access_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ST_SET_ACCESS, pascal_tex1_global_st_set_access_enc_str_1, pascal_tex1_global_st_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_st_set_access_enc_str_1},
    {PASCAL_TEX0_GLOBAL_ST_SET_CONFLICTS, pascal_tex0_global_st_set_conflicts_enc_str_1, pascal_tex0_global_st_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_st_set_conflicts_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ST_SET_CONFLICTS, pascal_tex1_global_st_set_conflicts_enc_str_1, pascal_tex1_global_st_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_st_set_conflicts_enc_str_1},
    {PASCAL_TEX0_LOCAL_ST_REQUESTS, pascal_tex0_local_st_requests_enc_str_1, pascal_tex0_local_st_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_local_st_requests_enc_str_1},
    {PASCAL_TEX1_LOCAL_ST_REQUESTS, pascal_tex1_local_st_requests_enc_str_1, pascal_tex1_local_st_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_local_st_requests_enc_str_1},
    {PASCAL_TEX0_LOCAL_ST_SET_ACCESS, pascal_tex0_local_st_set_access_enc_str_1, pascal_tex0_local_st_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_local_st_set_access_enc_str_1},
    {PASCAL_TEX1_LOCAL_ST_SET_ACCESS, pascal_tex1_local_st_set_access_enc_str_1, pascal_tex1_local_st_set_access_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_local_st_set_access_enc_str_1},
    {PASCAL_TEX0_LOCAL_ST_SET_CONFLICTS, pascal_tex0_local_st_set_conflicts_enc_str_1, pascal_tex0_local_st_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_local_st_set_conflicts_enc_str_1},
    {PASCAL_TEX1_LOCAL_ST_SET_CONFLICTS, pascal_tex1_local_st_set_conflicts_enc_str_1, pascal_tex1_local_st_set_conflicts_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_local_st_set_conflicts_enc_str_1},

    {PASCAL_TEX0_CACHED_GLOBAL_LD_DATA_CONFLICTS, pascal_tex0_cached_global_ld_data_conflicts_enc_str_1, pascal_tex0_cached_global_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_cached_global_ld_data_conflicts_enc_str_1},
    {PASCAL_TEX0_CACHED_LOCAL_LD_DATA_CONFLICTS, pascal_tex0_cached_local_ld_data_conflicts_enc_str_1, pascal_tex0_cached_local_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_cached_local_ld_data_conflicts_enc_str_1},
    {PASCAL_TEX0_GLOBAL_ATOM_CAS_DATA_CONFLICTS, pascal_tex0_global_atom_cas_data_conflicts_enc_str_1, pascal_tex0_global_atom_cas_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_atom_cas_data_conflicts_enc_str_1},
    {PASCAL_TEX0_GLOBAL_ATOM_DATA_CONFLICTS, pascal_tex0_global_atom_data_conflicts_enc_str_1, pascal_tex0_global_atom_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_atom_data_conflicts_enc_str_1},
    {PASCAL_TEX0_GLOBAL_LD_DATA_CONFLICTS, pascal_tex0_global_ld_data_conflicts_enc_str_1, pascal_tex0_global_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_ld_data_conflicts_enc_str_1},
    {PASCAL_TEX0_LOCAL_LD_DATA_CONFLICTS, pascal_tex0_local_ld_data_conflicts_enc_str_1, pascal_tex0_local_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_local_ld_data_conflicts_enc_str_1},
    {PASCAL_TEX0_SURFACE_ATOM_CAS_DATA_CONFLICTS, pascal_tex0_surface_atom_cas_data_conflicts_enc_str_1, pascal_tex0_surface_atom_cas_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_atom_cas_data_conflicts_enc_str_1},
    {PASCAL_TEX0_SURFACE_ATOM_DATA_CONFLICTS, pascal_tex0_surface_atom_data_conflicts_enc_str_1, pascal_tex0_surface_atom_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_atom_data_conflicts_enc_str_1},
    {PASCAL_TEX0_SURFACE_LD_DATA_CONFLICTS, pascal_tex0_surface_ld_data_conflicts_enc_str_1, pascal_tex0_surface_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_ld_data_conflicts_enc_str_1},
    {PASCAL_TEX0_UNCACHED_GLOBAL_LD_DATA_CONFLICTS, pascal_tex0_uncached_global_ld_data_conflicts_enc_str_1, pascal_tex0_uncached_global_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_uncached_global_ld_data_conflicts_enc_str_1},
    {PASCAL_TEX0_UNCACHED_LOCAL_LD_DATA_CONFLICTS, pascal_tex0_uncached_local_ld_data_conflicts_enc_str_1, pascal_tex0_uncached_local_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_uncached_local_ld_data_conflicts_enc_str_1},
    {PASCAL_TEX1_CACHED_GLOBAL_LD_DATA_CONFLICTS, pascal_tex1_cached_global_ld_data_conflicts_enc_str_1, pascal_tex1_cached_global_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_cached_global_ld_data_conflicts_enc_str_1},
    {PASCAL_TEX1_CACHED_LOCAL_LD_DATA_CONFLICTS, pascal_tex1_cached_local_ld_data_conflicts_enc_str_1, pascal_tex1_cached_local_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_cached_local_ld_data_conflicts_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ATOM_CAS_DATA_CONFLICTS, pascal_tex1_global_atom_cas_data_conflicts_enc_str_1, pascal_tex1_global_atom_cas_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_atom_cas_data_conflicts_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ATOM_DATA_CONFLICTS, pascal_tex1_global_atom_data_conflicts_enc_str_1, pascal_tex1_global_atom_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_atom_data_conflicts_enc_str_1},
    {PASCAL_TEX1_GLOBAL_LD_DATA_CONFLICTS, pascal_tex1_global_ld_data_conflicts_enc_str_1, pascal_tex1_global_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_ld_data_conflicts_enc_str_1},
    {PASCAL_TEX1_LOCAL_LD_DATA_CONFLICTS, pascal_tex1_local_ld_data_conflicts_enc_str_1, pascal_tex1_local_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_local_ld_data_conflicts_enc_str_1},
    {PASCAL_TEX1_SURFACE_ATOM_CAS_DATA_CONFLICTS, pascal_tex1_surface_atom_cas_data_conflicts_enc_str_1, pascal_tex1_surface_atom_cas_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_atom_cas_data_conflicts_enc_str_1},
    {PASCAL_TEX1_SURFACE_ATOM_DATA_CONFLICTS, pascal_tex1_surface_atom_data_conflicts_enc_str_1, pascal_tex1_surface_atom_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_atom_data_conflicts_enc_str_1},
    {PASCAL_TEX1_SURFACE_LD_DATA_CONFLICTS, pascal_tex1_surface_ld_data_conflicts_enc_str_1, pascal_tex1_surface_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_ld_data_conflicts_enc_str_1},
    {PASCAL_TEX1_UNCACHED_GLOBAL_LD_DATA_CONFLICTS, pascal_tex1_uncached_global_ld_data_conflicts_enc_str_1, pascal_tex1_uncached_global_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_uncached_global_ld_data_conflicts_enc_str_1},
    {PASCAL_TEX1_UNCACHED_LOCAL_LD_DATA_CONFLICTS, pascal_tex1_uncached_local_ld_data_conflicts_enc_str_1, pascal_tex1_uncached_local_ld_data_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_uncached_local_ld_data_conflicts_enc_str_1},
    {PASCAL_TEX0_CACHED_GLOBAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex0_cached_global_ld_row_column_conflicts_enc_str_1, pascal_tex0_cached_global_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_cached_global_ld_row_column_conflicts_enc_str_1},
    {PASCAL_TEX0_CACHED_LOCAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex0_cached_local_ld_row_column_conflicts_enc_str_1, pascal_tex0_cached_local_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_cached_local_ld_row_column_conflicts_enc_str_1},
    {PASCAL_TEX0_GLOBAL_ATOM_CAS_ROW_COLUMN_CONFLICTS, pascal_tex0_global_atom_cas_row_column_conflicts_enc_str_1, pascal_tex0_global_atom_cas_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_atom_cas_row_column_conflicts_enc_str_1},
    {PASCAL_TEX0_GLOBAL_ATOM_ROW_COLUMN_CONFLICTS, pascal_tex0_global_atom_row_column_conflicts_enc_str_1, pascal_tex0_global_atom_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_atom_row_column_conflicts_enc_str_1},
    {PASCAL_TEX0_GLOBAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex0_global_ld_row_column_conflicts_enc_str_1, pascal_tex0_global_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_ld_row_column_conflicts_enc_str_1},
    {PASCAL_TEX0_LOCAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex0_local_ld_row_column_conflicts_enc_str_1, pascal_tex0_local_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_local_ld_row_column_conflicts_enc_str_1},
    {PASCAL_TEX0_SURFACE_ATOM_CAS_ROW_COLUMN_CONFLICTS, pascal_tex0_surface_atom_cas_row_column_conflicts_enc_str_1, pascal_tex0_surface_atom_cas_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_atom_cas_row_column_conflicts_enc_str_1},
    {PASCAL_TEX0_SURFACE_ATOM_ROW_COLUMN_CONFLICTS, pascal_tex0_surface_atom_row_column_conflicts_enc_str_1, pascal_tex0_surface_atom_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_atom_row_column_conflicts_enc_str_1},
    {PASCAL_TEX0_SURFACE_LD_ROW_COLUMN_CONFLICTS, pascal_tex0_surface_ld_row_column_conflicts_enc_str_1, pascal_tex0_surface_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_ld_row_column_conflicts_enc_str_1},
    {PASCAL_TEX0_UNCACHED_GLOBAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex0_uncached_global_ld_row_column_conflicts_enc_str_1, pascal_tex0_uncached_global_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_uncached_global_ld_row_column_conflicts_enc_str_1},
    {PASCAL_TEX0_UNCACHED_LOCAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex0_uncached_local_ld_row_column_conflicts_enc_str_1, pascal_tex0_uncached_local_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_uncached_local_ld_row_column_conflicts_enc_str_1},
    {PASCAL_TEX1_CACHED_GLOBAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex1_cached_global_ld_row_column_conflicts_enc_str_1, pascal_tex1_cached_global_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_cached_global_ld_row_column_conflicts_enc_str_1},
    {PASCAL_TEX1_CACHED_LOCAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex1_cached_local_ld_row_column_conflicts_enc_str_1, pascal_tex1_cached_local_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_cached_local_ld_row_column_conflicts_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ATOM_CAS_ROW_COLUMN_CONFLICTS, pascal_tex1_global_atom_cas_row_column_conflicts_enc_str_1, pascal_tex1_global_atom_cas_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_atom_cas_row_column_conflicts_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ATOM_ROW_COLUMN_CONFLICTS, pascal_tex1_global_atom_row_column_conflicts_enc_str_1, pascal_tex1_global_atom_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_atom_row_column_conflicts_enc_str_1},
    {PASCAL_TEX1_GLOBAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex1_global_ld_row_column_conflicts_enc_str_1, pascal_tex1_global_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_ld_row_column_conflicts_enc_str_1},
    {PASCAL_TEX1_LOCAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex1_local_ld_row_column_conflicts_enc_str_1, pascal_tex1_local_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_local_ld_row_column_conflicts_enc_str_1},
    {PASCAL_TEX1_SURFACE_ATOM_CAS_ROW_COLUMN_CONFLICTS, pascal_tex1_surface_atom_cas_row_column_conflicts_enc_str_1, pascal_tex1_surface_atom_cas_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_atom_cas_row_column_conflicts_enc_str_1},
    {PASCAL_TEX1_SURFACE_ATOM_ROW_COLUMN_CONFLICTS, pascal_tex1_surface_atom_row_column_conflicts_enc_str_1, pascal_tex1_surface_atom_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_atom_row_column_conflicts_enc_str_1},
    {PASCAL_TEX1_SURFACE_LD_ROW_COLUMN_CONFLICTS, pascal_tex1_surface_ld_row_column_conflicts_enc_str_1, pascal_tex1_surface_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_ld_row_column_conflicts_enc_str_1},
    {PASCAL_TEX1_UNCACHED_GLOBAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex1_uncached_global_ld_row_column_conflicts_enc_str_1, pascal_tex1_uncached_global_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_uncached_global_ld_row_column_conflicts_enc_str_1},
    {PASCAL_TEX1_UNCACHED_LOCAL_LD_ROW_COLUMN_CONFLICTS, pascal_tex1_uncached_local_ld_row_column_conflicts_enc_str_1, pascal_tex1_uncached_local_ld_row_column_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_uncached_local_ld_row_column_conflicts_enc_str_1},

    {PASCAL_TEX0_LOCAL_LD_REQUESTS, pascal_tex0_local_ld_requests_enc_str_1, pascal_tex0_local_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_local_ld_requests_enc_str_1},
    {PASCAL_TEX1_LOCAL_LD_REQUESTS, pascal_tex1_local_ld_requests_enc_str_1, pascal_tex1_local_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_local_ld_requests_enc_str_1},
    {PASCAL_TEX0_CACHED_LOCAL_LD_REQUESTS, pascal_tex0_cached_local_ld_requests_enc_str_1, pascal_tex0_cached_local_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_cached_local_ld_requests_enc_str_1},
    {PASCAL_TEX1_CACHED_LOCAL_LD_REQUESTS, pascal_tex1_cached_local_ld_requests_enc_str_1, pascal_tex1_cached_local_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_cached_local_ld_requests_enc_str_1},
    {PASCAL_TEX0_UNCACHED_LOCAL_LD_REQUESTS, pascal_tex0_uncached_local_ld_requests_enc_str_1, pascal_tex0_uncached_local_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_uncached_local_ld_requests_enc_str_1},
    {PASCAL_TEX1_UNCACHED_LOCAL_LD_REQUESTS, pascal_tex1_uncached_local_ld_requests_enc_str_1, pascal_tex1_uncached_local_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_uncached_local_ld_requests_enc_str_1},

    {PASCAL_TEX0_CACHED_GLOBAL_LD_REQUESTS, pascal_tex0_cached_global_ld_requests_enc_str_1, pascal_tex0_cached_global_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_cached_global_ld_requests_enc_str_1},
    {PASCAL_TEX1_CACHED_GLOBAL_LD_REQUESTS, pascal_tex1_cached_global_ld_requests_enc_str_1, pascal_tex1_cached_global_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_cached_global_ld_requests_enc_str_1},
    {PASCAL_TEX0_GLOBAL_LD_REQUESTS, pascal_tex0_global_ld_requests_enc_str_1,  pascal_tex0_global_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_ld_requests_enc_str_1},
    {PASCAL_TEX1_GLOBAL_LD_REQUESTS, pascal_tex1_global_ld_requests_enc_str_1,  pascal_tex1_global_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_ld_requests_enc_str_1},
    {PASCAL_TEX0_UNCACHED_GLOBAL_LD_REQUESTS, pascal_tex0_uncached_global_ld_requests_enc_str_1, pascal_tex0_uncached_global_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_uncached_global_ld_requests_enc_str_1},
    {PASCAL_TEX1_UNCACHED_GLOBAL_LD_REQUESTS, pascal_tex1_uncached_global_ld_requests_enc_str_1, pascal_tex1_uncached_global_ld_requests_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_uncached_global_ld_requests_enc_str_1},
    {PASCAL_TEX0_GLOBAL_ATOM_REQUESTS, pascal_tex0_global_atom_requests_enc_str_1, pascal_tex0_global_atom_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_atom_requests_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ATOM_REQUESTS, pascal_tex1_global_atom_requests_enc_str_1, pascal_tex1_global_atom_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_atom_requests_enc_str_1},
    {PASCAL_TEX0_GLOBAL_ATOM_SET_ACCESS, pascal_tex0_global_atom_set_access_enc_str_1, pascal_tex0_global_atom_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_atom_set_access_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ATOM_SET_ACCESS, pascal_tex1_global_atom_set_access_enc_str_1, pascal_tex1_global_atom_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_atom_set_access_enc_str_1},
    {PASCAL_TEX0_GLOBAL_ATOM_SET_CONFLICTS, pascal_tex0_global_atom_set_conflicts_enc_str_1, pascal_tex0_global_atom_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_atom_set_conflicts_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ATOM_SET_CONFLICTS, pascal_tex1_global_atom_set_conflicts_enc_str_1, pascal_tex1_global_atom_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_atom_set_conflicts_enc_str_1},
    {PASCAL_TEX0_GLOBAL_ATOM_CAS_REQUESTS, pascal_tex0_global_atom_cas_requests_enc_str_1, pascal_tex0_global_atom_cas_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_atom_cas_requests_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ATOM_CAS_REQUESTS, pascal_tex1_global_atom_cas_requests_enc_str_1, pascal_tex1_global_atom_cas_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_atom_cas_requests_enc_str_1},
    {PASCAL_TEX0_GLOBAL_ATOM_CAS_SET_ACCESS, pascal_tex0_global_atom_cas_set_access_enc_str_1, pascal_tex0_global_atom_cas_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_atom_cas_set_access_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ATOM_CAS_SET_ACCESS, pascal_tex1_global_atom_cas_set_access_enc_str_1, pascal_tex1_global_atom_cas_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_atom_cas_set_access_enc_str_1},
    {PASCAL_TEX0_GLOBAL_ATOM_CAS_SET_CONFLICTS, pascal_tex0_global_atom_cas_set_conflicts_enc_str_1, pascal_tex0_global_atom_cas_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_atom_cas_set_conflicts_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ATOM_CAS_SET_CONFLICTS, pascal_tex1_global_atom_cas_set_conflicts_enc_str_1, pascal_tex1_global_atom_cas_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_atom_cas_set_conflicts_enc_str_1},
    {PASCAL_TEX0_GLOBAL_RED_REQUESTS, pascal_tex0_global_red_requests_enc_str_1, pascal_tex0_global_red_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_red_requests_enc_str_1},
    {PASCAL_TEX1_GLOBAL_RED_REQUESTS, pascal_tex1_global_red_requests_enc_str_1, pascal_tex1_global_red_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_red_requests_enc_str_1},
    {PASCAL_TEX0_GLOBAL_RED_SET_ACCESS, pascal_tex0_global_red_set_access_enc_str_1, pascal_tex0_global_red_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_red_set_access_enc_str_1},
    {PASCAL_TEX1_GLOBAL_RED_SET_ACCESS, pascal_tex1_global_red_set_access_enc_str_1, pascal_tex1_global_red_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_red_set_access_enc_str_1},
    {PASCAL_TEX0_GLOBAL_RED_SET_CONFLICTS, pascal_tex0_global_red_set_conflicts_enc_str_1, pascal_tex0_global_red_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_red_set_conflicts_enc_str_1},
    {PASCAL_TEX1_GLOBAL_RED_SET_CONFLICTS, pascal_tex1_global_red_set_conflicts_enc_str_1, pascal_tex1_global_red_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_red_set_conflicts_enc_str_1},
    {PASCAL_TEX0_SURFACE_LD_SET_ACCESS, pascal_tex0_surface_ld_set_access_enc_str_1, pascal_tex0_surface_ld_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_ld_set_access_enc_str_1},
    {PASCAL_TEX1_SURFACE_LD_SET_ACCESS, pascal_tex1_surface_ld_set_access_enc_str_1, pascal_tex1_surface_ld_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_ld_set_access_enc_str_1},
    {PASCAL_TEX0_SURFACE_LD_SET_CONFLICTS, pascal_tex0_surface_ld_set_conflicts_enc_str_1, pascal_tex0_surface_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_ld_set_conflicts_enc_str_1},
    {PASCAL_TEX1_SURFACE_LD_SET_CONFLICTS, pascal_tex1_surface_ld_set_conflicts_enc_str_1, pascal_tex1_surface_ld_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_ld_set_conflicts_enc_str_1},
    {PASCAL_TEX0_SURFACE_ST_SET_ACCESS, pascal_tex0_surface_st_set_access_enc_str_1, pascal_tex0_surface_st_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_st_set_access_enc_str_1},
    {PASCAL_TEX1_SURFACE_ST_SET_ACCESS, pascal_tex1_surface_st_set_access_enc_str_1, pascal_tex1_surface_st_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_st_set_access_enc_str_1},
    {PASCAL_TEX0_SURFACE_ST_SET_CONFLICTS, pascal_tex0_surface_st_set_conflicts_enc_str_1, pascal_tex0_surface_st_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_st_set_conflicts_enc_str_1},
    {PASCAL_TEX1_SURFACE_ST_SET_CONFLICTS, pascal_tex1_surface_st_set_conflicts_enc_str_1, pascal_tex1_surface_st_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_st_set_conflicts_enc_str_1},
    {PASCAL_TEX0_SURFACE_RED_SET_ACCESS, pascal_tex0_surface_red_set_access_enc_str_1, pascal_tex0_surface_red_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_red_set_access_enc_str_1},
    {PASCAL_TEX1_SURFACE_RED_SET_ACCESS, pascal_tex1_surface_red_set_access_enc_str_1, pascal_tex1_surface_red_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_red_set_access_enc_str_1},
    {PASCAL_TEX0_SURFACE_RED_SET_CONFLICTS, pascal_tex0_surface_red_set_conflicts_enc_str_1, pascal_tex0_surface_red_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_red_set_conflicts_enc_str_1},
    {PASCAL_TEX1_SURFACE_RED_SET_CONFLICTS, pascal_tex1_surface_red_set_conflicts_enc_str_1, pascal_tex1_surface_red_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_red_set_conflicts_enc_str_1},
    {PASCAL_TEX0_SURFACE_ATOM_SET_ACCESS, pascal_tex0_surface_atom_set_access_enc_str_1, pascal_tex0_surface_atom_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_atom_set_access_enc_str_1},
    {PASCAL_TEX1_SURFACE_ATOM_SET_ACCESS, pascal_tex1_surface_atom_set_access_enc_str_1, pascal_tex1_surface_atom_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_atom_set_access_enc_str_1},
    {PASCAL_TEX0_SURFACE_ATOM_CAS_SET_ACCESS, pascal_tex0_surface_atom_cas_set_access_enc_str_1, pascal_tex0_surface_atom_cas_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_atom_cas_set_access_enc_str_1},
    {PASCAL_TEX1_SURFACE_ATOM_CAS_SET_ACCESS, pascal_tex1_surface_atom_cas_set_access_enc_str_1, pascal_tex1_surface_atom_cas_set_access_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_atom_cas_set_access_enc_str_1},
    {PASCAL_TEX0_SURFACE_ATOM_SET_CONFLICTS, pascal_tex0_surface_atom_set_conflicts_enc_str_1, pascal_tex0_surface_atom_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_atom_set_conflicts_enc_str_1},
    {PASCAL_TEX1_SURFACE_ATOM_SET_CONFLICTS, pascal_tex1_surface_atom_set_conflicts_enc_str_1, pascal_tex1_surface_atom_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_atom_set_conflicts_enc_str_1},
    {PASCAL_TEX0_SURFACE_ATOM_CAS_SET_CONFLICTS, pascal_tex0_surface_atom_cas_set_conflicts_enc_str_1, pascal_tex0_surface_atom_cas_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_atom_cas_set_conflicts_enc_str_1},
    {PASCAL_TEX1_SURFACE_ATOM_CAS_SET_CONFLICTS, pascal_tex1_surface_atom_cas_set_conflicts_enc_str_1, pascal_tex1_surface_atom_cas_set_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_atom_cas_set_conflicts_enc_str_1},
    {PASCAL_TEX0_SURFACE_LD_REQUESTS, pascal_tex0_surface_ld_requests_enc_str_1, pascal_tex0_surface_ld_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_ld_requests_enc_str_1},
    {PASCAL_TEX1_SURFACE_LD_REQUESTS, pascal_tex1_surface_ld_requests_enc_str_1, pascal_tex1_surface_ld_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_ld_requests_enc_str_1},
    {PASCAL_TEX0_SURFACE_ST_REQUESTS, pascal_tex0_surface_st_requests_enc_str_1, pascal_tex0_surface_st_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_st_requests_enc_str_1},
    {PASCAL_TEX1_SURFACE_ST_REQUESTS, pascal_tex1_surface_st_requests_enc_str_1, pascal_tex1_surface_st_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_st_requests_enc_str_1},
    {PASCAL_TEX0_SURFACE_RED_REQUESTS, pascal_tex0_surface_red_requests_enc_str_1, pascal_tex0_surface_red_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_red_requests_enc_str_1},
    {PASCAL_TEX1_SURFACE_RED_REQUESTS, pascal_tex1_surface_red_requests_enc_str_1, pascal_tex1_surface_red_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_red_requests_enc_str_1},
    {PASCAL_TEX0_SURFACE_ATOM_REQUESTS, pascal_tex0_surface_atom_requests_enc_str_1, pascal_tex0_surface_atom_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_atom_requests_enc_str_1},
    {PASCAL_TEX1_SURFACE_ATOM_REQUESTS, pascal_tex1_surface_atom_requests_enc_str_1, pascal_tex1_surface_atom_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_atom_requests_enc_str_1},
    {PASCAL_TEX0_SURFACE_ATOM_CAS_REQUESTS, pascal_tex0_surface_atom_cas_requests_enc_str_1, pascal_tex0_surface_atom_cas_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_atom_cas_requests_enc_str_1},
    {PASCAL_TEX1_SURFACE_ATOM_CAS_REQUESTS, pascal_tex1_surface_atom_cas_requests_enc_str_1, pascal_tex1_surface_atom_cas_requests_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_atom_cas_requests_enc_str_1},

    {PASCAL_TEX0_GLOBAL_ATOM_ADDRESS_CONFLICTS, pascal_tex0_global_atom_address_conflicts_enc_str_1, pascal_tex0_global_atom_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_atom_address_conflicts_enc_str_1},
    {PASCAL_TEX0_GLOBAL_ATOM_CAS_ADDRESS_CONFLICTS, pascal_tex0_global_atom_cas_address_conflicts_enc_str_1, pascal_tex0_global_atom_cas_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_atom_cas_address_conflicts_enc_str_1},
    {PASCAL_TEX0_GLOBAL_RED_ADDRESS_CONFLICTS, pascal_tex0_global_red_address_conflicts_enc_str_1, pascal_tex0_global_red_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_red_address_conflicts_enc_str_1},
    {PASCAL_TEX0_SURFACE_ATOM_ADDRESS_CONFLICTS, pascal_tex0_surface_atom_address_conflicts_enc_str_1, pascal_tex0_surface_atom_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_atom_address_conflicts_enc_str_1},
    {PASCAL_TEX0_SURFACE_ATOM_CAS_ADDRESS_CONFLICTS, pascal_tex0_surface_atom_cas_address_conflicts_enc_str_1, pascal_tex0_surface_atom_cas_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_atom_cas_address_conflicts_enc_str_1},
    {PASCAL_TEX0_SURFACE_RED_ADDRESS_CONFLICTS, pascal_tex0_surface_red_address_conflicts_enc_str_1, pascal_tex0_surface_red_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_red_address_conflicts_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ATOM_ADDRESS_CONFLICTS, pascal_tex1_global_atom_address_conflicts_enc_str_1, pascal_tex1_global_atom_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_atom_address_conflicts_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ATOM_CAS_ADDRESS_CONFLICTS, pascal_tex1_global_atom_cas_address_conflicts_enc_str_1, pascal_tex1_global_atom_cas_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_atom_cas_address_conflicts_enc_str_1},
    {PASCAL_TEX1_GLOBAL_RED_ADDRESS_CONFLICTS, pascal_tex1_global_red_address_conflicts_enc_str_1, pascal_tex1_global_red_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_red_address_conflicts_enc_str_1},
    {PASCAL_TEX1_SURFACE_ATOM_ADDRESS_CONFLICTS, pascal_tex1_surface_atom_address_conflicts_enc_str_1, pascal_tex1_surface_atom_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_atom_address_conflicts_enc_str_1},
    {PASCAL_TEX1_SURFACE_ATOM_CAS_ADDRESS_CONFLICTS, pascal_tex1_surface_atom_cas_address_conflicts_enc_str_1, pascal_tex1_surface_atom_cas_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_atom_cas_address_conflicts_enc_str_1},
    {PASCAL_TEX1_SURFACE_RED_ADDRESS_CONFLICTS, pascal_tex1_surface_red_address_conflicts_enc_str_1, pascal_tex1_surface_red_address_conflicts_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_red_address_conflicts_enc_str_1},
    {PASCAL_TEX0_GLOBAL_ST_HITS_IN_WARP, pascal_tex0_global_st_hits_in_warp_enc_str_1, pascal_tex0_global_st_hits_in_warp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_st_hits_in_warp_enc_str_1},
    {PASCAL_TEX0_LOCAL_ST_HITS_IN_WARP, pascal_tex0_local_st_hits_in_warp_enc_str_1, pascal_tex0_local_st_hits_in_warp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_local_st_hits_in_warp_enc_str_1},
    {PASCAL_TEX0_SURFACE_ST_HITS_IN_WARP, pascal_tex0_surface_st_hits_in_warp_enc_str_1, pascal_tex0_surface_st_hits_in_warp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_st_hits_in_warp_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ST_HITS_IN_WARP, pascal_tex1_global_st_hits_in_warp_enc_str_1, pascal_tex1_global_st_hits_in_warp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_st_hits_in_warp_enc_str_1},
    {PASCAL_TEX1_LOCAL_ST_HITS_IN_WARP, pascal_tex1_local_st_hits_in_warp_enc_str_1, pascal_tex1_local_st_hits_in_warp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_local_st_hits_in_warp_enc_str_1},
    {PASCAL_TEX1_SURFACE_ST_HITS_IN_WARP, pascal_tex1_surface_st_hits_in_warp_enc_str_1, pascal_tex1_surface_st_hits_in_warp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_st_hits_in_warp_enc_str_1},
    {PASCAL_TEX0_SURFACE_LD_MISSES, pascal_tex0_surface_ld_misses_enc_str_1, pascal_tex0_surface_ld_misses_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_surface_ld_misses_enc_str_1},
    {PASCAL_TEX1_SURFACE_LD_MISSES, pascal_tex1_surface_ld_misses_enc_str_1, pascal_tex1_surface_ld_misses_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_surface_ld_misses_enc_str_1},

    { PASCAL_TEX0_UNCACHED_GLOBAL_LD_MISSES_32,  pascal_tex0_uncached_global_ld_misses_32_enc_str_1, pascal_tex0_uncached_global_ld_misses_32_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_uncached_global_ld_misses_32_enc_str_1},
    { PASCAL_TEX0_UNCACHED_GLOBAL_LD_MISSES_64,  pascal_tex0_uncached_global_ld_misses_64_enc_str_1, pascal_tex0_uncached_global_ld_misses_64_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_uncached_global_ld_misses_64_enc_str_1},
    { PASCAL_TEX0_UNCACHED_GLOBAL_LD_MISSES_128, pascal_tex0_uncached_global_ld_misses_128_enc_str_1, pascal_tex0_uncached_global_ld_misses_128_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_uncached_global_ld_misses_128_enc_str_1},
    { PASCAL_TEX1_UNCACHED_GLOBAL_LD_MISSES_32,  pascal_tex1_uncached_global_ld_misses_32_enc_str_1, pascal_tex1_uncached_global_ld_misses_32_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_uncached_global_ld_misses_32_enc_str_1},
    { PASCAL_TEX1_UNCACHED_GLOBAL_LD_MISSES_64,  pascal_tex1_uncached_global_ld_misses_64_enc_str_1, pascal_tex1_uncached_global_ld_misses_64_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_uncached_global_ld_misses_64_enc_str_1},
    { PASCAL_TEX1_UNCACHED_GLOBAL_LD_MISSES_128, pascal_tex1_uncached_global_ld_misses_128_enc_str_1, pascal_tex1_uncached_global_ld_misses_128_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_uncached_global_ld_misses_128_enc_str_1},

    { PASCAL_TEX0_UNCACHED_GLOBAL_LD_COALESCING_32,  pascal_tex0_uncached_global_ld_coalescing_32_enc_str_1, pascal_tex0_uncached_global_ld_coalescing_32_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_uncached_global_ld_coalescing_32_enc_str_1},
    { PASCAL_TEX0_UNCACHED_GLOBAL_LD_COALESCING_64,  pascal_tex0_uncached_global_ld_coalescing_64_enc_str_1, pascal_tex0_uncached_global_ld_coalescing_64_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_uncached_global_ld_coalescing_64_enc_str_1},
    { PASCAL_TEX0_UNCACHED_GLOBAL_LD_COALESCING_128, pascal_tex0_uncached_global_ld_coalescing_128_enc_str_1, pascal_tex0_uncached_global_ld_coalescing_128_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_uncached_global_ld_coalescing_128_enc_str_1},
    { PASCAL_TEX1_UNCACHED_GLOBAL_LD_COALESCING_32,  pascal_tex1_uncached_global_ld_coalescing_32_enc_str_1, pascal_tex1_uncached_global_ld_coalescing_32_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_uncached_global_ld_coalescing_32_enc_str_1},
    { PASCAL_TEX1_UNCACHED_GLOBAL_LD_COALESCING_64,  pascal_tex1_uncached_global_ld_coalescing_64_enc_str_1, pascal_tex1_uncached_global_ld_coalescing_64_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_uncached_global_ld_coalescing_64_enc_str_1},
    { PASCAL_TEX1_UNCACHED_GLOBAL_LD_COALESCING_128, pascal_tex1_uncached_global_ld_coalescing_128_enc_str_1, pascal_tex1_uncached_global_ld_coalescing_128_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_uncached_global_ld_coalescing_128_enc_str_1},

#if CU_PASCAL_PROFILE_SM_SIGNALS_VIA_HWPM
    {PASCAL_HWPM_CTA_LAUNCHED, pascal_hwpm_cta_launched_enc_str_1, pascal_hwpm_cta_launched_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_cta_launched_enc_str_4},
    {PASCAL_HWPM_THREADS_LAUNCHED_0, pascal_hwpm_threads_launched_0_enc_str_1, pascal_hwpm_threads_launched_0_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_threads_launched_0_enc_str_4},
    {PASCAL_HWPM_THREADS_LAUNCHED_1, pascal_hwpm_threads_launched_1_enc_str_1, pascal_hwpm_threads_launched_1_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_threads_launched_1_enc_str_4},
    {PASCAL_HWPM_THREADS_LAUNCHED_2, pascal_hwpm_threads_launched_2_enc_str_1, pascal_hwpm_threads_launched_2_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_threads_launched_2_enc_str_4},
    {PASCAL_HWPM_THREADS_LAUNCHED_3, pascal_hwpm_threads_launched_3_enc_str_1, pascal_hwpm_threads_launched_3_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_threads_launched_3_enc_str_4},
    {PASCAL_HWPM_WARPS_LAUNCHED_0, pascal_hwpm_warps_launched_0_enc_str_1, pascal_hwpm_warps_launched_0_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_warps_launched_0_enc_str_4},
    {PASCAL_HWPM_WARPS_LAUNCHED_1, pascal_hwpm_warps_launched_1_enc_str_1, pascal_hwpm_warps_launched_1_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_warps_launched_1_enc_str_4},
    {PASCAL_HWPM_WARPS_LAUNCHED_2, pascal_hwpm_warps_launched_2_enc_str_1, pascal_hwpm_warps_launched_2_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_warps_launched_2_enc_str_4},
    {PASCAL_HWPM_WARPS_LAUNCHED_3, pascal_hwpm_warps_launched_3_enc_str_1, pascal_hwpm_warps_launched_3_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_warps_launched_3_enc_str_4},
    {PASCAL_HWPM_ACTIVE_CYCLES, pascal_hwpm_active_cycles_enc_str_1, pascal_hwpm_active_cycles_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_active_cycles_enc_str_4},
    {PASCAL_HWPM_ACTIVE_WARPS, pascal_hwpm_active_warps_enc_str_1, pascal_hwpm_active_warps_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_active_warps_enc_str_4},
    {PASCAL_HWPM_SHARED_LD_MEM_DIVERGENCE_REPLAYS_H0, pascal_hwpm_shared_ld_mem_divergence_replays_h0_enc_str_1, pascal_hwpm_shared_ld_mem_divergence_replays_h0_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_hwpm_shared_ld_mem_divergence_replays_h0_enc_str_1},
    {PASCAL_HWPM_SHARED_ST_MEM_DIVERGENCE_REPLAYS_H0, pascal_hwpm_shared_st_mem_divergence_replays_h0_enc_str_1, pascal_hwpm_shared_st_mem_divergence_replays_h0_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_hwpm_shared_st_mem_divergence_replays_h0_enc_str_1},
    {PASCAL_HWPM_SHARED_LD_TRANSACTIONS_H0,           pascal_hwpm_shared_ld_transactions_h0_enc_str_1,           pascal_hwpm_shared_ld_transactions_h0_enc_str_1,           CUPROF_EVENT_CATEGORY_MEMORY, pascal_hwpm_shared_ld_transactions_h0_enc_str_1},
    {PASCAL_HWPM_SHARED_ST_TRANSACTIONS_H0,           pascal_hwpm_shared_st_transactions_h0_enc_str_1,           pascal_hwpm_shared_st_transactions_h0_enc_str_1,           CUPROF_EVENT_CATEGORY_MEMORY, pascal_hwpm_shared_st_transactions_h0_enc_str_1},
    {PASCAL_HWPM_SHARED_LD_MEM_DIVERGENCE_REPLAYS_H1, pascal_hwpm_shared_ld_mem_divergence_replays_h1_enc_str_1, pascal_hwpm_shared_ld_mem_divergence_replays_h1_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_hwpm_shared_ld_mem_divergence_replays_h1_enc_str_1},
    {PASCAL_HWPM_SHARED_ST_MEM_DIVERGENCE_REPLAYS_H1, pascal_hwpm_shared_st_mem_divergence_replays_h1_enc_str_1, pascal_hwpm_shared_st_mem_divergence_replays_h1_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_hwpm_shared_st_mem_divergence_replays_h1_enc_str_1},
    {PASCAL_HWPM_SHARED_LD_TRANSACTIONS_H1,           pascal_hwpm_shared_ld_transactions_h1_enc_str_1,           pascal_hwpm_shared_ld_transactions_h1_enc_str_1,           CUPROF_EVENT_CATEGORY_MEMORY, pascal_hwpm_shared_ld_transactions_h1_enc_str_1},
    {PASCAL_HWPM_SHARED_ST_TRANSACTIONS_H1,           pascal_hwpm_shared_st_transactions_h1_enc_str_1,           pascal_hwpm_shared_st_transactions_h1_enc_str_1,           CUPROF_EVENT_CATEGORY_MEMORY, pascal_hwpm_shared_st_transactions_h1_enc_str_1},

    {PASCAL_HWPMMUX_CTA_LAUNCHED, pascal_hwpmmux_cta_launched_enc_str_1, pascal_hwpmmux_cta_launched_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_cta_launched_enc_str_4},
    {PASCAL_HWPMMUX_THREADS_LAUNCHED, pascal_hwpmmux_threads_launched_enc_str_1, pascal_hwpmmux_threads_launched_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_threads_launched_0_enc_str_4},
    {PASCAL_HWPMMUX_WARPS_LAUNCHED, pascal_hwpmmux_warps_launched_enc_str_1, pascal_hwpmmux_warps_launched_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_warps_launched_0_enc_str_4},
    {PASCAL_HWPMMUX_ACTIVE_CYCLES, pascal_hwpmmux_active_cycles_enc_str_1, pascal_hwpmmux_active_cycles_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_active_cycles_enc_str_4},
    {PASCAL_HWPMMUX_ACTIVE_WARPS, pascal_hwpmmux_active_warps_enc_str_1, pascal_hwpmmux_active_warps_enc_str_3, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_active_warps_enc_str_4},
    {PASCAL_HWPMMUX_SHARED_LD_MEM_DIVERGENCE_REPLAYS_H0, pascal_hwpmmux_shared_ld_mem_divergence_replays_h0_enc_str_1, pascal_hwpmmux_shared_ld_mem_divergence_replays_h0_enc_str_3, CUPROF_EVENT_CATEGORY_MEMORY, pascal_hwpm_shared_ld_mem_divergence_replays_h0_enc_str_1},
    {PASCAL_HWPMMUX_SHARED_ST_MEM_DIVERGENCE_REPLAYS_H0, pascal_hwpmmux_shared_st_mem_divergence_replays_h0_enc_str_1, pascal_hwpmmux_shared_st_mem_divergence_replays_h0_enc_str_3, CUPROF_EVENT_CATEGORY_MEMORY, pascal_hwpm_shared_st_mem_divergence_replays_h0_enc_str_1},
    {PASCAL_HWPMMUX_SHARED_LD_TRANSACTIONS_H0,           pascal_hwpmmux_shared_ld_transactions_h0_enc_str_1,           pascal_hwpmmux_shared_ld_transactions_h0_enc_str_3,           CUPROF_EVENT_CATEGORY_MEMORY, pascal_hwpm_shared_ld_transactions_h0_enc_str_1},
    {PASCAL_HWPMMUX_SHARED_ST_TRANSACTIONS_H0,           pascal_hwpmmux_shared_st_transactions_h0_enc_str_1,           pascal_hwpmmux_shared_st_transactions_h0_enc_str_3,           CUPROF_EVENT_CATEGORY_MEMORY, pascal_hwpm_shared_st_transactions_h0_enc_str_1},
    {PASCAL_HWPMMUX_SHARED_LD_MEM_DIVERGENCE_REPLAYS_H1, pascal_hwpmmux_shared_ld_mem_divergence_replays_h1_enc_str_1, pascal_hwpmmux_shared_ld_mem_divergence_replays_h1_enc_str_3, CUPROF_EVENT_CATEGORY_MEMORY, pascal_hwpm_shared_ld_mem_divergence_replays_h1_enc_str_1},
    {PASCAL_HWPMMUX_SHARED_ST_MEM_DIVERGENCE_REPLAYS_H1, pascal_hwpmmux_shared_st_mem_divergence_replays_h1_enc_str_1, pascal_hwpmmux_shared_st_mem_divergence_replays_h1_enc_str_3, CUPROF_EVENT_CATEGORY_MEMORY, pascal_hwpm_shared_st_mem_divergence_replays_h1_enc_str_1},
    {PASCAL_HWPMMUX_SHARED_LD_TRANSACTIONS_H1,           pascal_hwpmmux_shared_ld_transactions_h1_enc_str_1,           pascal_hwpmmux_shared_ld_transactions_h1_enc_str_3,           CUPROF_EVENT_CATEGORY_MEMORY, pascal_hwpm_shared_ld_transactions_h1_enc_str_1},
    {PASCAL_HWPMMUX_SHARED_ST_TRANSACTIONS_H1,           pascal_hwpmmux_shared_st_transactions_h1_enc_str_1,           pascal_hwpmmux_shared_st_transactions_h1_enc_str_3,           CUPROF_EVENT_CATEGORY_MEMORY, pascal_hwpm_shared_st_transactions_h1_enc_str_1},

    {PASCAL_SMQCTL_INST_EXECUTED_FP16G0_PIPE, pascal_smqctl_inst_executed_fp16g0_pipe_enc_str_1, pascal_smqctl_inst_executed_fp16g0_pipe_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_smqctl_inst_executed_fp16g0_pipe_enc_str_2 },
    {PASCAL_SMQCTL_INST_EXECUTED_FP16G1_PIPE, pascal_smqctl_inst_executed_fp16g1_pipe_enc_str_1, pascal_smqctl_inst_executed_fp16g1_pipe_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_smqctl_inst_executed_fp16g1_pipe_enc_str_2 },
    {PASCAL_SMQCTL_INST_EXECUTED_FP16_DECOUPLED_PIPE, pascal_smqctl_inst_executed_fp16_decoupled_pipe_enc_str_1, pascal_smqctl_inst_executed_fp16_decoupled_pipe_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_smqctl_inst_executed_fp16_decoupled_pipe_enc_str_2 },
    {PASCAL_SMQCTL_INST_EXECUTED_FP16G0_PIPE_HIGHPOWER, pascal_smqctl_inst_executed_fp16g0_pipe_highpower_enc_str_1, pascal_smqctl_inst_executed_fp16g0_pipe_highpower_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_smqctl_inst_executed_fp16g0_pipe_highpower_enc_str_2 },
    {PASCAL_SMQCTL_INST_EXECUTED_FP16G1_PIPE_HIGHPOWER, pascal_smqctl_inst_executed_fp16g1_pipe_highpower_enc_str_1, pascal_smqctl_inst_executed_fp16g1_pipe_highpower_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_smqctl_inst_executed_fp16g1_pipe_highpower_enc_str_2 },
    {PASCAL_SMQCTL_INST_FP16G0_PIPE_UNIFORM_DATA_QUAD_Q, pascal_smqctl_inst_fp16g0_pipe_uniform_data_quad_q_enc_str_1, pascal_smqctl_inst_fp16g0_pipe_uniform_data_quad_q_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_smqctl_inst_fp16g0_pipe_uniform_data_quad_q_enc_str_2 },
    {PASCAL_SMQCTL_INST_FP16G1_PIPE_UNIFORM_DATA_QUAD_Q, pascal_smqctl_inst_fp16g1_pipe_uniform_data_quad_q_enc_str_1, pascal_smqctl_inst_fp16g1_pipe_uniform_data_quad_q_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_smqctl_inst_fp16g1_pipe_uniform_data_quad_q_enc_str_1 },

    {PASCAL_HWPM_INST_EXECUTED_TEX_OPS_Q0, pascal_hwpm_inst_executed_tex_ops_q0_enc_str_1, pascal_hwpm_inst_executed_tex_ops_q0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_inst_executed_tex_ops_q0_enc_str_1},
    {PASCAL_HWPM_INST_EXECUTED_TEX_OPS_Q1, pascal_hwpm_inst_executed_tex_ops_q1_enc_str_1, pascal_hwpm_inst_executed_tex_ops_q1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_inst_executed_tex_ops_q1_enc_str_1},
    {PASCAL_HWPM_INST_EXECUTED_TEX_OPS_Q2, pascal_hwpm_inst_executed_tex_ops_q2_enc_str_1, pascal_hwpm_inst_executed_tex_ops_q2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_inst_executed_tex_ops_q2_enc_str_1},
    {PASCAL_HWPM_INST_EXECUTED_TEX_OPS_Q3, pascal_hwpm_inst_executed_tex_ops_q3_enc_str_1, pascal_hwpm_inst_executed_tex_ops_q3_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_inst_executed_tex_ops_q3_enc_str_1},
#endif

    {PASCAL_FB_SUBP0_DRAMC_READ, pascal_fb_subp0_dramc_read_enc_str_1, pascal_fb_subp0_dramc_read_enc_str_3, CUPROF_EVENT_CATEGORY_MEMORY, pascal_fb_subp0_dramc_read_enc_str_4},
    {PASCAL_FB_SUBP1_DRAMC_READ, pascal_fb_subp1_dramc_read_enc_str_1, pascal_fb_subp1_dramc_read_enc_str_3, CUPROF_EVENT_CATEGORY_MEMORY, pascal_fb_subp1_dramc_read_enc_str_4},
    {PASCAL_FB_SUBP0_DRAMC_WRITE, pascal_fb_subp0_dramc_write_enc_str_1, pascal_fb_subp0_dramc_write_enc_str_3, CUPROF_EVENT_CATEGORY_MEMORY, pascal_fb_subp0_dramc_write_enc_str_4},
    {PASCAL_FB_SUBP1_DRAMC_WRITE, pascal_fb_subp1_dramc_write_enc_str_1, pascal_fb_subp1_dramc_write_enc_str_3, CUPROF_EVENT_CATEGORY_MEMORY, pascal_fb_subp1_dramc_write_enc_str_4},

    {PASCAL_FB1_SUBP0_DRAMC_READ, pascal_fb1_subp0_dramc_read_enc_str_1, pascal_fb1_subp0_dramc_read_enc_str_3, CUPROF_EVENT_CATEGORY_MEMORY, pascal_fb1_subp0_dramc_read_enc_str_4},
    {PASCAL_FB1_SUBP1_DRAMC_READ, pascal_fb1_subp1_dramc_read_enc_str_1, pascal_fb1_subp1_dramc_read_enc_str_3, CUPROF_EVENT_CATEGORY_MEMORY, pascal_fb1_subp1_dramc_read_enc_str_4},
    {PASCAL_FB1_SUBP0_DRAMC_WRITE, pascal_fb1_subp0_dramc_write_enc_str_1, pascal_fb1_subp0_dramc_write_enc_str_3, CUPROF_EVENT_CATEGORY_MEMORY, pascal_fb1_subp0_dramc_write_enc_str_4},
    {PASCAL_FB1_SUBP1_DRAMC_WRITE, pascal_fb1_subp1_dramc_write_enc_str_1, pascal_fb1_subp1_dramc_write_enc_str_3, CUPROF_EVENT_CATEGORY_MEMORY, pascal_fb1_subp1_dramc_write_enc_str_4},

    {PASCAL_LTC0_WRITE_MISS_SECTORS, pascal_ltc0_write_miss_sectors_enc_str_1, pascal_ltc0_write_miss_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_write_miss_sectors_enc_str_4},
    {PASCAL_LTC1_WRITE_MISS_SECTORS, pascal_ltc1_write_miss_sectors_enc_str_1, pascal_ltc1_write_miss_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc1_write_miss_sectors_enc_str_4},
    {PASCAL_LTC2_WRITE_MISS_SECTORS, pascal_ltc2_write_miss_sectors_enc_str_1, pascal_ltc2_write_miss_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc2_write_miss_sectors_enc_str_4},
    {PASCAL_LTC3_WRITE_MISS_SECTORS, pascal_ltc3_write_miss_sectors_enc_str_1, pascal_ltc3_write_miss_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc3_write_miss_sectors_enc_str_4},
    {PASCAL_LTC0_READ_MISS_SECTORS, pascal_ltc0_read_miss_sectors_enc_str_1, pascal_ltc0_read_miss_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_read_miss_sectors_enc_str_4},
    {PASCAL_LTC1_READ_MISS_SECTORS, pascal_ltc1_read_miss_sectors_enc_str_1, pascal_ltc1_read_miss_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc1_read_miss_sectors_enc_str_4},
    {PASCAL_LTC2_READ_MISS_SECTORS, pascal_ltc2_read_miss_sectors_enc_str_1, pascal_ltc2_read_miss_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc2_read_miss_sectors_enc_str_4},
    {PASCAL_LTC3_READ_MISS_SECTORS, pascal_ltc3_read_miss_sectors_enc_str_1, pascal_ltc3_read_miss_sectors_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc3_read_miss_sectors_enc_str_4},

    {PASCAL_LTC0_READ_TEX_SECTORS_FBP, pascal_ltc0_read_tex_sectors_fbp_enc_str_1, pascal_ltc0_read_tex_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_read_tex_sectors_fbp_enc_str_4},
    {PASCAL_LTC1_READ_TEX_SECTORS_FBP, pascal_ltc1_read_tex_sectors_fbp_enc_str_1, pascal_ltc1_read_tex_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc1_read_tex_sectors_fbp_enc_str_4},
    {PASCAL_LTC2_READ_TEX_SECTORS_FBP, pascal_ltc2_read_tex_sectors_fbp_enc_str_1, pascal_ltc2_read_tex_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc2_read_tex_sectors_fbp_enc_str_4},
    {PASCAL_LTC3_READ_TEX_SECTORS_FBP, pascal_ltc3_read_tex_sectors_fbp_enc_str_1, pascal_ltc3_read_tex_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc3_read_tex_sectors_fbp_enc_str_4},

    {PASCAL_LTC0_WRITE_TEX_SECTORS_FBP, pascal_ltc0_write_tex_sectors_fbp_enc_str_1, pascal_ltc0_write_tex_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_write_tex_sectors_fbp_enc_str_4},
    {PASCAL_LTC1_WRITE_TEX_SECTORS_FBP, pascal_ltc1_write_tex_sectors_fbp_enc_str_1, pascal_ltc1_write_tex_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc1_write_tex_sectors_fbp_enc_str_4},
    {PASCAL_LTC2_WRITE_TEX_SECTORS_FBP, pascal_ltc2_write_tex_sectors_fbp_enc_str_1, pascal_ltc2_write_tex_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc2_write_tex_sectors_fbp_enc_str_4},
    {PASCAL_LTC3_WRITE_TEX_SECTORS_FBP, pascal_ltc3_write_tex_sectors_fbp_enc_str_1, pascal_ltc3_write_tex_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc3_write_tex_sectors_fbp_enc_str_4},

    {PASCAL_LTC0_READ_TEX_HIT_SECTORS_FBP, pascal_ltc0_read_tex_hit_sectors_fbp_enc_str_1, pascal_ltc0_read_tex_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_read_tex_hit_sectors_fbp_enc_str_4},
    {PASCAL_LTC1_READ_TEX_HIT_SECTORS_FBP, pascal_ltc1_read_tex_hit_sectors_fbp_enc_str_1, pascal_ltc1_read_tex_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc1_read_tex_hit_sectors_fbp_enc_str_4},
    {PASCAL_LTC2_READ_TEX_HIT_SECTORS_FBP, pascal_ltc2_read_tex_hit_sectors_fbp_enc_str_1, pascal_ltc2_read_tex_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc2_read_tex_hit_sectors_fbp_enc_str_4},
    {PASCAL_LTC3_READ_TEX_HIT_SECTORS_FBP, pascal_ltc3_read_tex_hit_sectors_fbp_enc_str_1, pascal_ltc3_read_tex_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc3_read_tex_hit_sectors_fbp_enc_str_4},

    {PASCAL_LTC0_WRITE_TEX_HIT_SECTORS_FBP, pascal_ltc0_write_tex_hit_sectors_fbp_enc_str_1, pascal_ltc0_write_tex_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_write_tex_hit_sectors_fbp_enc_str_4},
    {PASCAL_LTC1_WRITE_TEX_HIT_SECTORS_FBP, pascal_ltc1_write_tex_hit_sectors_fbp_enc_str_1, pascal_ltc1_write_tex_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc1_write_tex_hit_sectors_fbp_enc_str_4},
    {PASCAL_LTC2_WRITE_TEX_HIT_SECTORS_FBP, pascal_ltc2_write_tex_hit_sectors_fbp_enc_str_1, pascal_ltc2_write_tex_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc2_write_tex_hit_sectors_fbp_enc_str_4},
    {PASCAL_LTC3_WRITE_TEX_HIT_SECTORS_FBP, pascal_ltc3_write_tex_hit_sectors_fbp_enc_str_1, pascal_ltc3_write_tex_hit_sectors_fbp_enc_str_3, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc3_write_tex_hit_sectors_fbp_enc_str_4},

    // ltc_read_sysmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_rd_op & ltc2pm_ltc_lts0_request_aperture_sysmem
    { PASCAL_LTC0_READ_SYSMEM_SECTORS_FBP,      pascal_ltc0_read_sysmem_sectors_fbp_enc_str_1, pascal_ltc0_read_sysmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_read_sysmem_sectors_fbp_enc_str_4},
    { PASCAL_LTC1_READ_SYSMEM_SECTORS_FBP,      pascal_ltc1_read_sysmem_sectors_fbp_enc_str_1, pascal_ltc1_read_sysmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc1_read_sysmem_sectors_fbp_enc_str_4},
    { PASCAL_LTC2_READ_SYSMEM_SECTORS_FBP,      pascal_ltc2_read_sysmem_sectors_fbp_enc_str_1, pascal_ltc2_read_sysmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc2_read_sysmem_sectors_fbp_enc_str_4},
    { PASCAL_LTC3_READ_SYSMEM_SECTORS_FBP,      pascal_ltc3_read_sysmem_sectors_fbp_enc_str_1, pascal_ltc3_read_sysmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc3_read_sysmem_sectors_fbp_enc_str_4},

    // ltc_write_sysmem_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & ltc2pm_ltc_lts0_request_wr_op & ltc2pm_ltc_lts0_request_aperture_sysmem
    { PASCAL_LTC0_WRITE_SYSMEM_SECTORS_FBP,      pascal_ltc0_write_sysmem_sectors_fbp_enc_str_1, pascal_ltc0_write_sysmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_write_sysmem_sectors_fbp_enc_str_4},
    { PASCAL_LTC1_WRITE_SYSMEM_SECTORS_FBP,      pascal_ltc1_write_sysmem_sectors_fbp_enc_str_1, pascal_ltc1_write_sysmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc1_write_sysmem_sectors_fbp_enc_str_4},
    { PASCAL_LTC2_WRITE_SYSMEM_SECTORS_FBP,      pascal_ltc2_write_sysmem_sectors_fbp_enc_str_1, pascal_ltc2_write_sysmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc2_write_sysmem_sectors_fbp_enc_str_4},
    { PASCAL_LTC3_WRITE_SYSMEM_SECTORS_FBP,      pascal_ltc3_write_sysmem_sectors_fbp_enc_str_1, pascal_ltc3_write_sysmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc3_write_sysmem_sectors_fbp_enc_str_4},

    // ltc_read_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_rd_op | ltc2pm_ltc_lts0_request_atomic_op)
    { PASCAL_LTC0_TOTAL_READ_SECTORS_FBP,      pascal_ltc0_total_read_sectors_fbp_enc_str_1, pascal_ltc0_total_read_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_total_read_sectors_fbp_enc_str_4},
    { PASCAL_LTC1_TOTAL_READ_SECTORS_FBP,      pascal_ltc1_total_read_sectors_fbp_enc_str_1, pascal_ltc1_total_read_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc1_total_read_sectors_fbp_enc_str_4},
    { PASCAL_LTC2_TOTAL_READ_SECTORS_FBP,      pascal_ltc2_total_read_sectors_fbp_enc_str_1, pascal_ltc2_total_read_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc2_total_read_sectors_fbp_enc_str_4},
    { PASCAL_LTC3_TOTAL_READ_SECTORS_FBP,      pascal_ltc3_total_read_sectors_fbp_enc_str_1, pascal_ltc3_total_read_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc3_total_read_sectors_fbp_enc_str_4},

    // ltc_write_sectors_fbp0_l2slice0 = ltc2pm_ltc_lts0_request_active & (ltc2pm_ltc_lts0_request_wr_op | ltc2pm_ltc_lts0_request_atomic_op)'
    { PASCAL_LTC0_TOTAL_WRITE_SECTORS_FBP,      pascal_ltc0_total_write_sectors_fbp_enc_str_1, pascal_ltc0_total_write_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_total_write_sectors_fbp_enc_str_4},
    { PASCAL_LTC1_TOTAL_WRITE_SECTORS_FBP,      pascal_ltc1_total_write_sectors_fbp_enc_str_1, pascal_ltc1_total_write_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc1_total_write_sectors_fbp_enc_str_4},
    { PASCAL_LTC2_TOTAL_WRITE_SECTORS_FBP,      pascal_ltc2_total_write_sectors_fbp_enc_str_1, pascal_ltc2_total_write_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc2_total_write_sectors_fbp_enc_str_4},
    { PASCAL_LTC3_TOTAL_WRITE_SECTORS_FBP,      pascal_ltc3_total_write_sectors_fbp_enc_str_1, pascal_ltc3_total_write_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc3_total_write_sectors_fbp_enc_str_4},

    {PASCAL_MMU_HUB_TLB_HIT, pascal_mmu_hub_tlb_hit_enc_str_1, pascal_mmu_hub_tlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_hub_tlb_hit_enc_str_4},
    {PASCAL_MMU_HUB_TLB_MISS, pascal_mmu_hub_tlb_miss_enc_str_1, pascal_mmu_hub_tlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_hub_tlb_miss_enc_str_4},
    {PASCAL_MMU_HUB_TLB_MISS_INT, pascal_mmu_hub_tlb_miss_int_enc_str_1, pascal_mmu_hub_tlb_miss_int_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_fill_pte_miss_int_enc_str_4},
    {PASCAL_MMU_FILL_PTE_HIT, pascal_mmu_fill_pte_hit_enc_str_1, pascal_mmu_fill_pte_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_fill_pte_hit_enc_str_4},
    {PASCAL_MMU_FILL_PTE_MISS, pascal_mmu_fill_pte_miss_enc_str_1, pascal_mmu_fill_pte_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_fill_pte_miss_enc_str_4},
    {PASCAL_MMU_FILL_PTE_MISS_INT, pascal_mmu_fill_pte_miss_int_enc_str_1, pascal_mmu_fill_pte_miss_int_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_fill_pte_miss_int_enc_str_4},
    {PASCAL_MMU_FILL_PDE_HIT, pascal_mmu_fill_pde_hit_enc_str_1, pascal_mmu_fill_pde_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_fill_pde_hit_enc_str_4},
    {PASCAL_MMU_FILL_PDE_MISS, pascal_mmu_fill_pde_miss_enc_str_1, pascal_mmu_fill_pde_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_fill_pde_miss_enc_str_4},

    {PASCAL_FB_SUBP0_DRAM_ACTIVATES, pascal_fb_subp0_dram_activates_enc_str_1, pascal_fb_subp0_dram_activates_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_fb_subp0_dram_activates_enc_str_4},
    {PASCAL_FB_SUBP1_DRAM_ACTIVATES, pascal_fb_subp1_dram_activates_enc_str_1, pascal_fb_subp1_dram_activates_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_fb_subp1_dram_activates_enc_str_4},

    {PASCAL_FB1_SUBP0_DRAM_ACTIVATES, pascal_fb1_subp0_dram_activates_enc_str_1, pascal_fb1_subp0_dram_activates_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_fb1_subp0_dram_activates_enc_str_4},
    {PASCAL_FB1_SUBP1_DRAM_ACTIVATES, pascal_fb1_subp1_dram_activates_enc_str_1, pascal_fb1_subp1_dram_activates_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_fb1_subp1_dram_activates_enc_str_4},

    // Software counters to count ld/st instructions
    {PASCAL_SW_COUNTER_GLD8BIT_INST, pascal_sw_counter_gld8bit_inst_enc_str_1, pascal_sw_counter_gld8bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, pascal_sw_counter_gld8bit_inst_enc_str_4},
    {PASCAL_SW_COUNTER_GLD16BIT_INST, pascal_sw_counter_gld16bit_inst_enc_str_1, pascal_sw_counter_gld16bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, pascal_sw_counter_gld16bit_inst_enc_str_4},
    {PASCAL_SW_COUNTER_GLD32BIT_INST, pascal_sw_counter_gld32bit_inst_enc_str_1, pascal_sw_counter_gld32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_gld32bit_inst_enc_str_4},
    {PASCAL_SW_COUNTER_GLD64BIT_INST, pascal_sw_counter_gld64bit_inst_enc_str_1, pascal_sw_counter_gld64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, pascal_sw_counter_gld64bit_inst_enc_str_4},
    {PASCAL_SW_COUNTER_GLD128BIT_INST, pascal_sw_counter_gld128bit_inst_enc_str_1, pascal_sw_counter_gld128bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, pascal_sw_counter_gld128bit_inst_enc_str_4},
    {PASCAL_SW_COUNTER_GST8BIT_INST, pascal_sw_counter_gst8bit_inst_enc_str_1, pascal_sw_counter_gst8bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, pascal_sw_counter_gst8bit_inst_enc_str_4},
    {PASCAL_SW_COUNTER_GST16BIT_INST, pascal_sw_counter_gst16bit_inst_enc_str_1, pascal_sw_counter_gst16bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, pascal_sw_counter_gst16bit_inst_enc_str_4},
    {PASCAL_SW_COUNTER_GST32BIT_INST, pascal_sw_counter_gst32bit_inst_enc_str_1, pascal_sw_counter_gst32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_gst32bit_inst_enc_str_4},
    {PASCAL_SW_COUNTER_GST64BIT_INST, pascal_sw_counter_gst64bit_inst_enc_str_1, pascal_sw_counter_gst64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_gld64bit_inst_enc_str_4},
    {PASCAL_SW_COUNTER_GST128BIT_INST, pascal_sw_counter_gst128bit_inst_enc_str_1, pascal_sw_counter_gst128bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_gld128bit_inst_enc_str_4},

    // Software counters to count shared load/store instructions
    {PASCAL_SW_COUNTER_SLD8BIT_INST,pascal_sw_counter_sld8bit_inst_enc_str_1, pascal_sw_counter_sld8bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,pascal_sw_counter_sld8bit_inst_enc_str_4},
    {PASCAL_SW_COUNTER_SLD16BIT_INST,pascal_sw_counter_sld16bit_inst_enc_str_1, pascal_sw_counter_sld16bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,pascal_sw_counter_sld16bit_inst_enc_str_4},
    {PASCAL_SW_COUNTER_SLD32BIT_INST,pascal_sw_counter_sld32bit_inst_enc_str_1, pascal_sw_counter_sld32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,pascal_sw_counter_sld32bit_inst_enc_str_4},
    {PASCAL_SW_COUNTER_SLD64BIT_INST,pascal_sw_counter_sld64bit_inst_enc_str_1, pascal_sw_counter_sld64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,pascal_sw_counter_sld64bit_inst_enc_str_4},
    {PASCAL_SW_COUNTER_SLD128BIT_INST,pascal_sw_counter_sld128bit_inst_enc_str_1, pascal_sw_counter_sld128bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,pascal_sw_counter_sld128bit_inst_enc_str_4},
    {PASCAL_SW_COUNTER_SST8BIT_INST,pascal_sw_counter_sst8bit_inst_enc_str_1, pascal_sw_counter_sst8bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,pascal_sw_counter_sst8bit_inst_enc_str_4},
    {PASCAL_SW_COUNTER_SST16BIT_INST,pascal_sw_counter_sst16bit_inst_enc_str_1, pascal_sw_counter_sst16bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,pascal_sw_counter_sst16bit_inst_enc_str_4},
    {PASCAL_SW_COUNTER_SST32BIT_INST,pascal_sw_counter_sst32bit_inst_enc_str_1, pascal_sw_counter_sst32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,pascal_sw_counter_sst32bit_inst_enc_str_4},
    {PASCAL_SW_COUNTER_SST64BIT_INST,pascal_sw_counter_sst64bit_inst_enc_str_1, pascal_sw_counter_sst64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,pascal_sw_counter_sst64bit_inst_enc_str_4},
    {PASCAL_SW_COUNTER_SST128BIT_INST,pascal_sw_counter_sst128bit_inst_enc_str_1, pascal_sw_counter_sst128bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,pascal_sw_counter_sst128bit_inst_enc_str_4},

    // Software counters to count floating point instructions
    {PASCAL_SW_COUNTER_FADD_INST, pascal_sw_counter_fadd_inst_enc_str_1, pascal_sw_counter_fadd_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_fadd_inst_enc_str_4},
    {PASCAL_SW_COUNTER_FMUL_INST, pascal_sw_counter_fmul_inst_enc_str_1, pascal_sw_counter_fmul_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_fmul_inst_enc_str_4},
    {PASCAL_SW_COUNTER_FFMA_INST, pascal_sw_counter_ffma_inst_enc_str_1, pascal_sw_counter_ffma_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_ffma_inst_enc_str_4},
    {PASCAL_SW_COUNTER_DADD_INST, pascal_sw_counter_dadd_inst_enc_str_1, pascal_sw_counter_dadd_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_dadd_inst_enc_str_4},
    {PASCAL_SW_COUNTER_DMUL_INST, pascal_sw_counter_dmul_inst_enc_str_1, pascal_sw_counter_dmul_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_dmul_inst_enc_str_4},
    {PASCAL_SW_COUNTER_DFMA_INST, pascal_sw_counter_dfma_inst_enc_str_1, pascal_sw_counter_dfma_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_dfma_inst_enc_str_4},
    {PASCAL_SW_COUNTER_COS_INST, pascal_sw_counter_cos_inst_enc_str_1, pascal_sw_counter_cos_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_cos_inst_enc_str_4},
    {PASCAL_SW_COUNTER_EX2_INST, pascal_sw_counter_ex2_inst_enc_str_1, pascal_sw_counter_ex2_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_ex2_inst_enc_str_4},
    {PASCAL_SW_COUNTER_LG2_INST, pascal_sw_counter_lg2_inst_enc_str_1, pascal_sw_counter_lg2_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_lg2_inst_enc_str_4},
    {PASCAL_SW_COUNTER_RCP_INST, pascal_sw_counter_rcp_inst_enc_str_1, pascal_sw_counter_rcp_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_rcp_inst_enc_str_4},
    {PASCAL_SW_COUNTER_RSQ_INST, pascal_sw_counter_rsq_inst_enc_str_1, pascal_sw_counter_rsq_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_rsq_inst_enc_str_4},
    {PASCAL_SW_COUNTER_SIN_INST, pascal_sw_counter_sin_inst_enc_str_1, pascal_sw_counter_sin_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_sin_inst_enc_str_4},
    {PASCAL_SW_COUNTER_SQRT_INST, pascal_sw_counter_sqrt_inst_enc_str_1, pascal_sw_counter_sqrt_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_sqrt_inst_enc_str_4},
    {PASCAL_SW_COUNTER_HADD_INST, pascal_sw_counter_hadd_inst_enc_str_1, pascal_sw_counter_hadd_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_hadd_inst_enc_str_4},
    {PASCAL_SW_COUNTER_HMUL_INST, pascal_sw_counter_hmul_inst_enc_str_1, pascal_sw_counter_hmul_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_hmul_inst_enc_str_4},
    {PASCAL_SW_COUNTER_HFMA_INST, pascal_sw_counter_hfma_inst_enc_str_1, pascal_sw_counter_hfma_inst_enc_str_3,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_hfma_inst_enc_str_4},

    // Software counters to count the number of instructions executed from a particular instruction class:
    // Software counters to count the number of instructions executed from a particular instruction class:
    { PASCAL_SW_COUNTER_INSTR_CLASS_FP_16,                       pascal_sw_counter_instr_class_fp_16_enc_str_1                      , pascal_sw_counter_instr_class_fp_16_enc_str_1                      , CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_instr_class_fp_16_enc_str_4},
    { PASCAL_SW_COUNTER_INSTR_CLASS_FP_32,                       pascal_sw_counter_instr_class_fp_32_enc_str_1                      , pascal_sw_counter_instr_class_fp_32_enc_str_1                      , CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_instr_class_fp_32_enc_str_4},
    { PASCAL_SW_COUNTER_INSTR_CLASS_FP_64,                       pascal_sw_counter_instr_class_fp_64_enc_str_1                      , pascal_sw_counter_instr_class_fp_64_enc_str_1                      , CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_instr_class_fp_64_enc_str_4},
    { PASCAL_SW_COUNTER_INSTR_CLASS_INTEGER,                     pascal_sw_counter_instr_class_integer_enc_str_1                    , pascal_sw_counter_instr_class_integer_enc_str_1                    , CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_instr_class_integer_enc_str_4},
    { PASCAL_SW_COUNTER_INSTR_CLASS_BIT_CONVERT,                 pascal_sw_counter_instr_class_bit_convert_enc_str_1                , pascal_sw_counter_instr_class_bit_convert_enc_str_1                , CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_instr_class_bit_convert_enc_str_4},
    { PASCAL_SW_COUNTER_INSTR_CLASS_CONTROL,                     pascal_sw_counter_instr_class_control_enc_str_1                    , pascal_sw_counter_instr_class_control_enc_str_1                    , CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_instr_class_control_enc_str_4},
    { PASCAL_SW_COUNTER_INSTR_CLASS_COMPUTE_LD_ST,               pascal_sw_counter_instr_class_compute_ld_st_enc_str_1              , pascal_sw_counter_instr_class_compute_ld_st_enc_str_1              , CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_instr_class_compute_ld_st_enc_str_4},
    { PASCAL_SW_COUNTER_INSTR_CLASS_MISCELLANEOUS,               pascal_sw_counter_instr_class_miscellaneous_enc_str_1              , pascal_sw_counter_instr_class_miscellaneous_enc_str_1              , CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_instr_class_miscellaneous_enc_str_4},
    { PASCAL_SW_COUNTER_INSTR_CLASS_INTER_THREAD_COMMUNICATION,  pascal_sw_counter_instr_class_inter_thread_communication_enc_str_1 , pascal_sw_counter_instr_class_inter_thread_communication_enc_str_1 , CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_instr_class_inter_thread_communication_enc_str_4},

    // Software counters to count the different load/stores from the generic accesses
    { PASCAL_SW_COUNTER_GENERIC_SHARED_LOAD,                pascal_sw_counter_generic_shared_ld_enc_str_1               , pascal_sw_counter_generic_shared_ld_enc_str_1               , CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_generic_shared_ld_enc_str_4},
    { PASCAL_SW_COUNTER_GENERIC_SHARED_STORE,               pascal_sw_counter_generic_shared_st_enc_str_1               , pascal_sw_counter_generic_shared_st_enc_str_1               , CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_generic_shared_ld_enc_str_4},
    { PASCAL_SW_COUNTER_GENERIC_LOCAL_LOAD,                 pascal_sw_counter_generic_local_ld_enc_str_1                , pascal_sw_counter_generic_local_ld_enc_str_1                , CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_generic_local_ld_enc_str_4},
    { PASCAL_SW_COUNTER_GENERIC_LOCAL_STORE,                pascal_sw_counter_generic_local_st_enc_str_1                , pascal_sw_counter_generic_local_st_enc_str_1                , CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_generic_local_ld_enc_str_4},
    { PASCAL_SW_COUNTER_GENERIC_GLOBAL_LOAD,                pascal_sw_counter_generic_global_ld_enc_str_1               , pascal_sw_counter_generic_global_ld_enc_str_1               , CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_generic_global_ld_enc_str_4},
    { PASCAL_SW_COUNTER_GENERIC_GLOBAL_STORE,               pascal_sw_counter_generic_global_st_enc_str_1               , pascal_sw_counter_generic_global_st_enc_str_1               , CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sw_counter_generic_global_ld_enc_str_4},

    // Software counters to count unique global load/store instructions
    {PASCAL_SW_COUNTER_UNIQUE_GLD1BYTE_REQUESTED,pascal_sw_counter_unique_gld_1byte_requested_enc_str_1, pascal_sw_counter_unique_gld_1byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,pascal_sw_counter_unique_gld_1byte_requested_enc_str_4},
    {PASCAL_SW_COUNTER_UNIQUE_GLD4BYTE_REQUESTED,pascal_sw_counter_unique_gld_4byte_requested_enc_str_1, pascal_sw_counter_unique_gld_4byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,pascal_sw_counter_unique_gld_4byte_requested_enc_str_4},
    {PASCAL_SW_COUNTER_UNIQUE_GLD8BYTE_REQUESTED,pascal_sw_counter_unique_gld_8byte_requested_enc_str_1, pascal_sw_counter_unique_gld_8byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,pascal_sw_counter_unique_gld_8byte_requested_enc_str_4},
    {PASCAL_SW_COUNTER_UNIQUE_GLD16BYTE_REQUESTED,pascal_sw_counter_unique_gld_16byte_requested_enc_str_1, pascal_sw_counter_unique_gld_16byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,pascal_sw_counter_unique_gld_16byte_requested_enc_str_4},
    {PASCAL_SW_COUNTER_UNIQUE_GST1BYTE_REQUESTED,pascal_sw_counter_unique_gst_1byte_requested_enc_str_1, pascal_sw_counter_unique_gst_1byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,pascal_sw_counter_unique_gst_1byte_requested_enc_str_4},
    {PASCAL_SW_COUNTER_UNIQUE_GST4BYTE_REQUESTED,pascal_sw_counter_unique_gst_4byte_requested_enc_str_1, pascal_sw_counter_unique_gst_4byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,pascal_sw_counter_unique_gst_4byte_requested_enc_str_4},
    {PASCAL_SW_COUNTER_UNIQUE_GST8BYTE_REQUESTED,pascal_sw_counter_unique_gst_8byte_requested_enc_str_1, pascal_sw_counter_unique_gst_8byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,pascal_sw_counter_unique_gst_8byte_requested_enc_str_4},
    {PASCAL_SW_COUNTER_UNIQUE_GST16BYTE_REQUESTED,pascal_sw_counter_unique_gst_16byte_requested_enc_str_1, pascal_sw_counter_unique_gst_16byte_requested_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY,pascal_sw_counter_unique_gst_16byte_requested_enc_str_4},
    {PASCAL_SW_COUNTER_UNIQUE_SECTOR_ACCESS_GLD, pascal_sw_counter_unique_sector_access_gld_enc_str_1, pascal_sw_counter_unique_sector_access_gld_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_sw_counter_unique_sector_access_gld_enc_str_4},

    // LDG signals
    { PASCAL_LUT_COUNTER_GLD32BIT_INST,      pascal_lut_counter_gld32bit_inst_enc_str_1,  pascal_lut_counter_gld32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_gld32bit_inst_enc_str_4},
    { PASCAL_LUT_COUNTER_GST32BIT_INST,      pascal_lut_counter_gst32bit_inst_enc_str_1,  pascal_lut_counter_gst32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_gst32bit_inst_enc_str_4},
    { PASCAL_LUT_COUNTER_GLD64BIT_INST,      pascal_lut_counter_gld64bit_inst_enc_str_1,  pascal_lut_counter_gld64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_gld64bit_inst_enc_str_4},
    { PASCAL_LUT_COUNTER_GST64BIT_INST,      pascal_lut_counter_gst64bit_inst_enc_str_1,  pascal_lut_counter_gst64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_gld64bit_inst_enc_str_4},
    { PASCAL_LUT_COUNTER_GLD128BIT_INST,     pascal_lut_counter_gld128bit_inst_enc_str_1, pascal_lut_counter_gld128bit_inst_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_gld128bit_inst_enc_str_4},
    { PASCAL_LUT_COUNTER_GST128BIT_INST,     pascal_lut_counter_gst128bit_inst_enc_str_1, pascal_lut_counter_gst128bit_inst_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_gld128bit_inst_enc_str_4},
    { PASCAL_LUT_COUNTER_SHLD_32BIT_INST,    pascal_lut_counter_shld_32bit_inst_enc_str_1,        pascal_lut_counter_shld_32bit_inst_enc_str_1,        CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_shld_32bit_inst_enc_str_4 },
    { PASCAL_LUT_COUNTER_SHLD_64BIT_INST,    pascal_lut_counter_shld_64bit_inst_enc_str_1,        pascal_lut_counter_shld_64bit_inst_enc_str_1,        CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_shld_64bit_inst_enc_str_4 },
    { PASCAL_LUT_COUNTER_SHLD_128BIT_INST,   pascal_lut_counter_shld_128bit_inst_enc_str_1,       pascal_lut_counter_shld_128bit_inst_enc_str_1,       CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_shld_128bit_inst_enc_str_4 },
    { PASCAL_LUT_COUNTER_SHLD_U128BIT_INST,  pascal_lut_counter_shld_u128bit_inst_enc_str_1,     pascal_lut_counter_shld_u128bit_inst_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_shld_u128bit_inst_enc_str_4 },
    { PASCAL_LUT_COUNTER_SHST_32BIT_INST,    pascal_lut_counter_shst_32bit_inst_enc_str_1,        pascal_lut_counter_shst_32bit_inst_enc_str_1,        CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_shst_32bit_inst_enc_str_4 },
    { PASCAL_LUT_COUNTER_SHST_64BIT_INST,    pascal_lut_counter_shst_64bit_inst_enc_str_1,        pascal_lut_counter_shst_64bit_inst_enc_str_1,        CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_shst_64bit_inst_enc_str_4 },
    { PASCAL_LUT_COUNTER_SHST_128BIT_INST,   pascal_lut_counter_shst_128bit_inst_enc_str_1,       pascal_lut_counter_shst_128bit_inst_enc_str_1,       CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_shst_128bit_inst_enc_str_4 },

    { PASCAL_LUT_COUNTER_GENERIC_SHARED_LD_INST,       pascal_lut_counter_generic_shared_ld_inst_enc_str_1,      pascal_lut_counter_generic_shared_ld_inst_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_generic_shared_ld_inst_enc_str_4},
    { PASCAL_LUT_COUNTER_GENERIC_SHARED_ST_INST,       pascal_lut_counter_generic_shared_st_inst_enc_str_1,      pascal_lut_counter_generic_shared_st_inst_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_generic_shared_st_inst_enc_str_4},

    { PASCAL_LUT_COUNTER_GENERIC_SHARED_LD_32BIT_INST, pascal_lut_counter_generic_shared_ld_32bit_inst_enc_str_1,  pascal_lut_counter_generic_shared_ld_32bit_inst_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_generic_shared_ld_32bit_inst_enc_str_4},
    { PASCAL_LUT_COUNTER_GENERIC_SHARED_LD_64BIT_INST, pascal_lut_counter_generic_shared_ld_64bit_inst_enc_str_1,  pascal_lut_counter_generic_shared_ld_64bit_inst_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_generic_shared_ld_64bit_inst_enc_str_4},
    { PASCAL_LUT_COUNTER_GENERIC_SHARED_LD_128BIT_INST, pascal_lut_counter_generic_shared_ld_128bit_inst_enc_str_1, pascal_lut_counter_generic_shared_ld_128bit_inst_enc_str_1,CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_generic_shared_ld_128bit_inst_enc_str_4},

    { PASCAL_LUT_COUNTER_GENERIC_SHARED_ST_32BIT_INST, pascal_lut_counter_generic_shared_st_32bit_inst_enc_str_1,  pascal_lut_counter_generic_shared_st_32bit_inst_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_generic_shared_st_32bit_inst_enc_str_4},
    { PASCAL_LUT_COUNTER_GENERIC_SHARED_ST_64BIT_INST, pascal_lut_counter_generic_shared_st_64bit_inst_enc_str_1,  pascal_lut_counter_generic_shared_st_64bit_inst_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_generic_shared_st_64bit_inst_enc_str_4},
    { PASCAL_LUT_COUNTER_GENERIC_SHARED_ST_128BIT_INST, pascal_lut_counter_generic_shared_st_128bit_inst_enc_str_1, pascal_lut_counter_generic_shared_st_128bit_inst_enc_str_1,CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_generic_shared_st_128bit_inst_enc_str_4},

    { PASCAL_LUT_COUNTER_SH_ATOM_32BIT_INST,        pascal_lut_counter_sh_atom_32bit_inst_enc_str_1,      pascal_lut_counter_sh_atom_32bit_inst_enc_str_1,      CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_sh_atom_32bit_inst_enc_str_4 },
    { PASCAL_LUT_COUNTER_SH_ATOM_64BIT_INST,        pascal_lut_counter_sh_atom_64bit_inst_enc_str_1,      pascal_lut_counter_sh_atom_64bit_inst_enc_str_1,      CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_sh_atom_64bit_inst_enc_str_4 },
    { PASCAL_LUT_COUNTER_SH_ATOM_CAS_32BIT_INST,    pascal_lut_counter_sh_atom_cas_32bit_inst_enc_str_1,  pascal_lut_counter_sh_atom_cas_32bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_sh_atom_cas_32bit_inst_enc_str_4 },
    { PASCAL_LUT_COUNTER_SH_ATOM_CAS_64BIT_INST,    pascal_lut_counter_sh_atom_cas_64bit_inst_enc_str_1,  pascal_lut_counter_sh_atom_cas_64bit_inst_enc_str_1,  CUPROF_EVENT_CATEGORY_MEMORY, pascal_lut_counter_sh_atom_cas_64bit_inst_enc_str_4 },
    { PASCAL_MPC_CTAS_LAUNCHED, pascal_mpc_ctas_launched_enc_str_1, pascal_mpc_ctas_launched_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_mpc_ctas_launched_enc_str_1},
    { PASCAL_MPC_THREADS_LAUNCHED, pascal_mpc_threads_launched_enc_str_1, pascal_mpc_threads_launched_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_mpc_threads_launched_enc_str_1},
    { PASCAL_MPC_WARPS_IN_FLIGHT, pascal_mpc_warps_in_flight_enc_str_1, pascal_mpc_warps_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_mpc_warps_in_flight_enc_str_1},
    { PASCAL_MPC_COMPUTE_CTAS_IN_FLIGHT, pascal_mpc_compute_ctas_in_flight_enc_str_1, pascal_mpc_compute_ctas_in_flight_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_mpc_compute_ctas_in_flight_enc_str_1},
    { PASCAL_ELAPSED_CYCLES_SM, pascal_elapsed_cycles_sm_enc_str_1, pascal_elapsed_cycles_sm_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_elapsed_cycles_sm_enc_str_4},
    { PASCAL_ELAPSED_CYCLES_SM_PM, pascal_elapsed_cycles_sm_pm_enc_str_1, pascal_elapsed_cycles_sm_pm_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_elapsed_cycles_sm_pm_enc_str_4},
    { PASCAL_LTC0_ATOMIC_TEX_SECTORS_FBP, pascal_ltc0_atomic_tex_sectors_fbp_enc_str_1, pascal_ltc0_atomic_tex_sectors_fbp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_atomic_tex_sectors_fbp_enc_str_4},
    { PASCAL_LTC1_ATOMIC_TEX_SECTORS_FBP, pascal_ltc1_atomic_tex_sectors_fbp_enc_str_1, pascal_ltc1_atomic_tex_sectors_fbp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc1_atomic_tex_sectors_fbp_enc_str_4},
    { PASCAL_LTC2_ATOMIC_TEX_SECTORS_FBP, pascal_ltc2_atomic_tex_sectors_fbp_enc_str_1, pascal_ltc2_atomic_tex_sectors_fbp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc2_atomic_tex_sectors_fbp_enc_str_4},
    { PASCAL_LTC3_ATOMIC_TEX_SECTORS_FBP, pascal_ltc3_atomic_tex_sectors_fbp_enc_str_1, pascal_ltc3_atomic_tex_sectors_fbp_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc3_atomic_tex_sectors_fbp_enc_str_4},

    { PASCAL_LTC0_READ_VIDMEM_SECTORS_FBP,      pascal_ltc0_read_vidmem_sectors_fbp_enc_str_1,   pascal_ltc0_read_vidmem_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_read_vidmem_sectors_fbp_enc_str_4},
    { PASCAL_LTC1_READ_VIDMEM_SECTORS_FBP,      pascal_ltc1_read_vidmem_sectors_fbp_enc_str_1,   pascal_ltc1_read_vidmem_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_read_vidmem_sectors_fbp_enc_str_4},
    { PASCAL_LTC2_READ_VIDMEM_SECTORS_FBP,      pascal_ltc2_read_vidmem_sectors_fbp_enc_str_1,   pascal_ltc2_read_vidmem_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_read_vidmem_sectors_fbp_enc_str_4},
    { PASCAL_LTC3_READ_VIDMEM_SECTORS_FBP,      pascal_ltc3_read_vidmem_sectors_fbp_enc_str_1,   pascal_ltc3_read_vidmem_sectors_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_read_vidmem_sectors_fbp_enc_str_4},

    { PASCAL_LTC0_WRITE_VIDMEM_SECTORS_FBP,      pascal_ltc0_write_vidmem_sectors_fbp_enc_str_1, pascal_ltc0_write_vidmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_write_vidmem_sectors_fbp_enc_str_4},
    { PASCAL_LTC1_WRITE_VIDMEM_SECTORS_FBP,      pascal_ltc1_write_vidmem_sectors_fbp_enc_str_1, pascal_ltc1_write_vidmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_write_vidmem_sectors_fbp_enc_str_4},
    { PASCAL_LTC2_WRITE_VIDMEM_SECTORS_FBP,      pascal_ltc2_write_vidmem_sectors_fbp_enc_str_1, pascal_ltc2_write_vidmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_write_vidmem_sectors_fbp_enc_str_4},
    { PASCAL_LTC3_WRITE_VIDMEM_SECTORS_FBP,      pascal_ltc3_write_vidmem_sectors_fbp_enc_str_1, pascal_ltc3_write_vidmem_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_write_vidmem_sectors_fbp_enc_str_4},

    { PASCAL_LTC0_READ_SYSMEM_HIT_SECTORS_FBP, pascal_ltc0_read_sysmem_hit_sectors_fbp_enc_str_1, pascal_ltc0_read_sysmem_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_read_sysmem_hit_sectors_fbp_enc_str_1},
    { PASCAL_LTC1_READ_SYSMEM_HIT_SECTORS_FBP, pascal_ltc1_read_sysmem_hit_sectors_fbp_enc_str_1, pascal_ltc1_read_sysmem_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc1_read_sysmem_hit_sectors_fbp_enc_str_1},
    { PASCAL_LTC2_READ_SYSMEM_HIT_SECTORS_FBP, pascal_ltc2_read_sysmem_hit_sectors_fbp_enc_str_1, pascal_ltc2_read_sysmem_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc2_read_sysmem_hit_sectors_fbp_enc_str_1},
    { PASCAL_LTC3_READ_SYSMEM_HIT_SECTORS_FBP, pascal_ltc3_read_sysmem_hit_sectors_fbp_enc_str_1, pascal_ltc3_read_sysmem_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc3_read_sysmem_hit_sectors_fbp_enc_str_1},
    { PASCAL_LTC0_WRITE_SYSMEM_HIT_SECTORS_FBP, pascal_ltc0_write_sysmem_hit_sectors_fbp_enc_str_1, pascal_ltc0_write_sysmem_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_write_sysmem_hit_sectors_fbp_enc_str_1},
    { PASCAL_LTC1_WRITE_SYSMEM_HIT_SECTORS_FBP, pascal_ltc1_write_sysmem_hit_sectors_fbp_enc_str_1, pascal_ltc1_write_sysmem_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc1_write_sysmem_hit_sectors_fbp_enc_str_1},
    { PASCAL_LTC2_WRITE_SYSMEM_HIT_SECTORS_FBP, pascal_ltc2_write_sysmem_hit_sectors_fbp_enc_str_1, pascal_ltc2_write_sysmem_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc2_write_sysmem_hit_sectors_fbp_enc_str_1},
    { PASCAL_LTC3_WRITE_SYSMEM_HIT_SECTORS_FBP, pascal_ltc3_write_sysmem_hit_sectors_fbp_enc_str_1, pascal_ltc3_write_sysmem_hit_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc3_write_sysmem_hit_sectors_fbp_enc_str_1},
    { PASCAL_LTC0_READ_SYSMEM_MISS_SECTORS_FBP, pascal_ltc0_read_sysmem_miss_sectors_fbp_enc_str_1, pascal_ltc0_read_sysmem_miss_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_read_sysmem_miss_sectors_fbp_enc_str_1},
    { PASCAL_LTC1_READ_SYSMEM_MISS_SECTORS_FBP, pascal_ltc1_read_sysmem_miss_sectors_fbp_enc_str_1, pascal_ltc1_read_sysmem_miss_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc1_read_sysmem_miss_sectors_fbp_enc_str_1},
    { PASCAL_LTC2_READ_SYSMEM_MISS_SECTORS_FBP, pascal_ltc2_read_sysmem_miss_sectors_fbp_enc_str_1, pascal_ltc2_read_sysmem_miss_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc2_read_sysmem_miss_sectors_fbp_enc_str_1},
    { PASCAL_LTC3_READ_SYSMEM_MISS_SECTORS_FBP, pascal_ltc3_read_sysmem_miss_sectors_fbp_enc_str_1, pascal_ltc3_read_sysmem_miss_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc3_read_sysmem_miss_sectors_fbp_enc_str_1},
    { PASCAL_LTC0_WRITE_SYSMEM_MISS_SECTORS_FBP, pascal_ltc0_write_sysmem_miss_sectors_fbp_enc_str_1, pascal_ltc0_write_sysmem_miss_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_write_sysmem_miss_sectors_fbp_enc_str_1},
    { PASCAL_LTC1_WRITE_SYSMEM_MISS_SECTORS_FBP, pascal_ltc1_write_sysmem_miss_sectors_fbp_enc_str_1, pascal_ltc1_write_sysmem_miss_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc1_write_sysmem_miss_sectors_fbp_enc_str_1},
    { PASCAL_LTC2_WRITE_SYSMEM_MISS_SECTORS_FBP, pascal_ltc2_write_sysmem_miss_sectors_fbp_enc_str_1, pascal_ltc2_write_sysmem_miss_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc2_write_sysmem_miss_sectors_fbp_enc_str_1},
    { PASCAL_LTC3_WRITE_SYSMEM_MISS_SECTORS_FBP, pascal_ltc3_write_sysmem_miss_sectors_fbp_enc_str_1, pascal_ltc3_write_sysmem_miss_sectors_fbp_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc3_write_sysmem_miss_sectors_fbp_enc_str_1},

    { PASCAL_LTC0_PM_REQ_SRC_UNIT_GCC_FBP,      pascal_ltc0_pm_req_src_unit_gcc_fbp_enc_str_1,    pascal_ltc0_pm_req_src_unit_gcc_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_pm_req_src_unit_gcc_fbp_enc_str_4},
    { PASCAL_LTC1_PM_REQ_SRC_UNIT_GCC_FBP,      pascal_ltc1_pm_req_src_unit_gcc_fbp_enc_str_1,    pascal_ltc1_pm_req_src_unit_gcc_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_pm_req_src_unit_gcc_fbp_enc_str_4},
    { PASCAL_LTC2_PM_REQ_SRC_UNIT_GCC_FBP,      pascal_ltc2_pm_req_src_unit_gcc_fbp_enc_str_1,    pascal_ltc2_pm_req_src_unit_gcc_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_pm_req_src_unit_gcc_fbp_enc_str_4},
    { PASCAL_LTC3_PM_REQ_SRC_UNIT_GCC_FBP,      pascal_ltc3_pm_req_src_unit_gcc_fbp_enc_str_1,    pascal_ltc3_pm_req_src_unit_gcc_fbp_enc_str_1,  CUPROF_EVENT_CATEGORY_CACHE, pascal_ltc0_pm_req_src_unit_gcc_fbp_enc_str_4},

    //SMPC
    { PASCAL_SM_PMTRIG0, pascal_sm_pmtrig0_enc_str_1, pascal_sm_pmtrig0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pmtrig0_enc_str_3}, //"prof_trigger_00" 
    { PASCAL_SM_PMTRIG1, pascal_sm_pmtrig1_enc_str_1, pascal_sm_pmtrig1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pmtrig1_enc_str_3}, //"prof_trigger_01" 
    { PASCAL_SM_PMTRIG2, pascal_sm_pmtrig2_enc_str_1, pascal_sm_pmtrig2_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pmtrig2_enc_str_3}, //"prof_trigger_02" 
    { PASCAL_SM_PMTRIG3, pascal_sm_pmtrig3_enc_str_1, pascal_sm_pmtrig3_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pmtrig3_enc_str_3}, //"prof_trigger_03" 
    { PASCAL_SM_PMTRIG4, pascal_sm_pmtrig4_enc_str_1, pascal_sm_pmtrig4_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pmtrig4_enc_str_3}, //"prof_trigger_04" 
    { PASCAL_SM_PMTRIG5, pascal_sm_pmtrig5_enc_str_1, pascal_sm_pmtrig5_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pmtrig5_enc_str_3}, //"prof_trigger_05" 
    { PASCAL_SM_PMTRIG6, pascal_sm_pmtrig6_enc_str_1, pascal_sm_pmtrig6_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pmtrig6_enc_str_3}, //"prof_trigger_06" 
    { PASCAL_SM_PMTRIG7, pascal_sm_pmtrig7_enc_str_1, pascal_sm_pmtrig7_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pmtrig7_enc_str_3}, //"prof_trigger_07" 
    { PASCAL_SM_PMTRIG8, pascal_sm_pmtrig8_enc_str_1, pascal_sm_pmtrig8_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pmtrig8_enc_str_3}, //"pmtrig8" 
    { PASCAL_SM_PMTRIG9, pascal_sm_pmtrig9_enc_str_1, pascal_sm_pmtrig9_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pmtrig9_enc_str_3}, //"pmtrig9" 
    { PASCAL_SM_PMTRIG10, pascal_sm_pmtrig10_enc_str_1, pascal_sm_pmtrig10_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pmtrig10_enc_str_3}, //"pmtrig10" 
    { PASCAL_SM_PMTRIG11, pascal_sm_pmtrig11_enc_str_1, pascal_sm_pmtrig11_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pmtrig11_enc_str_3}, //"pmtrig11" 
    { PASCAL_SM_PMTRIG12, pascal_sm_pmtrig12_enc_str_1, pascal_sm_pmtrig12_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pmtrig12_enc_str_3}, //"pmtrig12" 
    { PASCAL_SM_PMTRIG13, pascal_sm_pmtrig13_enc_str_1, pascal_sm_pmtrig13_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pmtrig13_enc_str_3}, //"pmtrig13" 
    { PASCAL_SM_PMTRIG14, pascal_sm_pmtrig14_enc_str_1, pascal_sm_pmtrig14_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pmtrig14_enc_str_3}, //"pmtrig14" 
    { PASCAL_SM_PMTRIG15, pascal_sm_pmtrig15_enc_str_1, pascal_sm_pmtrig15_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pmtrig15_enc_str_3}, //"pmtrig15" 
    { PASCAL_SM_ACTIVE_WARPS_QUAD, pascal_sm_active_warps_sctl_enc_str_1, pascal_sm_active_warps_sctl_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_active_warps_sctl_enc_str_3}, //"active_warps" 
    { PASCAL_SM_ACTIVE_CYCLES_QUAD, pascal_sm_active_cycles_sctl_enc_str_1, pascal_sm_active_cycles_sctl_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_active_cycles_sctl_enc_str_3}, //"active_cycles" 
    { PASCAL_SM_WARPS_LAUNCHED, pascal_sm_warps_launched_enc_str_1, pascal_sm_warps_launched_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warps_launched_enc_str_3}, //"warps_launched" 
    { PASCAL_SM_INST_ISSUED0, pascal_sm_inst_issued0_enc_str_1, pascal_sm_inst_issued0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_issued0_enc_str_3}, //"inst_issued0" 
    { PASCAL_SM_INST_ISSUED1, pascal_sm_inst_issued1_enc_str_1, pascal_sm_inst_issued1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_issued1_enc_str_3}, //"inst_issued1" 
    { PASCAL_SM_INST_ISSUED2, pascal_sm_inst_issued2_enc_str_1, pascal_sm_inst_issued2_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_issued2_enc_str_3}, //"inst_issued2" 
    { PASCAL_SM_INST_EXECUTED, pascal_sm_inst_executed_enc_str_1, pascal_sm_inst_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_enc_str_3}, //"inst_executed" 
    { PASCAL_SM_INST_EXECUTED_IN_TRAP, pascal_sm_inst_executed_in_trap_enc_str_1, pascal_sm_inst_executed_in_trap_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_in_trap_enc_str_3}, //"inst_executed_in_trap" 
    { PASCAL_SM_INST_EXECUTED_OUTSIDE_TRAP, pascal_sm_inst_executed_outside_trap_enc_str_1, pascal_sm_inst_executed_outside_trap_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_outside_trap_enc_str_3}, //"inst_executed_outside_trap" 
    { PASCAL_SM_INST_ROLLBACKED, pascal_sm_inst_rollbacked_enc_str_1, pascal_sm_inst_rollbacked_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_rollbacked_enc_str_3}, //"inst_rollbacked" 
    { PASCAL_SM_THREAD_INST_EXECUTED, pascal_sm_thread_inst_executed_enc_str_1, pascal_sm_thread_inst_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_thread_inst_executed_enc_str_3}, //"thread_inst_executed" 
    { PASCAL_SM_WARPS_MOVED_ON_DECK, pascal_sm_warps_moved_on_deck_enc_str_1, pascal_sm_warps_moved_on_deck_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warps_moved_on_deck_enc_str_3}, //"warps_moved_on_deck" 
    { PASCAL_SM_WARPS_MOVED_OFF_DECK, pascal_sm_warps_moved_off_deck_enc_str_1, pascal_sm_warps_moved_off_deck_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warps_moved_off_deck_enc_str_3}, //"warps_moved_off_deck" 
    { PASCAL_SM_NOT_PREDICATED_OFF_THREAD_INST_EXECUTED, pascal_sm_not_predicated_off_thread_inst_executed_enc_str_1, pascal_sm_not_predicated_off_thread_inst_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_not_predicated_off_thread_inst_executed_enc_str_3}, //"not_predicated_off_thread_inst_executed" 
    { PASCAL_SM_TRAP_IN_TRAP_QUAD, pascal_sm_trap_in_trap_sctl_enc_str_1, pascal_sm_trap_in_trap_sctl_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_trap_in_trap_sctl_enc_str_3}, //"trap_in_trap" 
    { PASCAL_SM_NON_IDLE_SCTL, pascal_sm_non_idle_sctl_enc_str_1, pascal_sm_non_idle_sctl_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_non_idle_sctl_enc_str_3}, //"non_idle_sctl" 
    { PASCAL_SM_WARP_CANT_ISSUE_DRAIN, pascal_sm_warp_cant_issue_drain_enc_str_1, pascal_sm_warp_cant_issue_drain_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_drain_enc_str_3}, //"warp_cant_issue_drain" 
    { PASCAL_SM_LOCAL_STORE, pascal_sm_local_store_enc_str_1, pascal_sm_local_store_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_local_store_enc_str_3}, //"inst_executed_local_st" 
    { PASCAL_SM_LOCAL_LOAD, pascal_sm_local_load_enc_str_1, pascal_sm_local_load_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_local_load_enc_str_3}, //"inst_executed_local_ld" 
    { PASCAL_SM_WARP_CANT_ISSUE_ICACHE_MISS, pascal_sm_warp_cant_issue_icache_miss_enc_str_1, pascal_sm_warp_cant_issue_icache_miss_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_icache_miss_enc_str_3}, //"warp_cant_issue_icache_miss" 
    { PASCAL_SM_SHARED_LOAD, pascal_sm_shared_load_enc_str_1, pascal_sm_shared_load_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_shared_load_enc_str_3}, //"shared_load" 
    { PASCAL_SM_SHARED_STORE, pascal_sm_shared_store_enc_str_1, pascal_sm_shared_store_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_shared_store_enc_str_3}, //"shared_store" 
    { PASCAL_SM_WARP_CANT_ISSUE_IMC_MISS, pascal_sm_warp_cant_issue_imc_miss_enc_str_1, pascal_sm_warp_cant_issue_imc_miss_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_imc_miss_enc_str_3}, //"warp_cant_issue_imc_miss" 
    { PASCAL_SM_SHARED_ATOM_CAS, pascal_sm_shared_atom_cas_enc_str_1, pascal_sm_shared_atom_cas_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_shared_atom_cas_enc_str_3}, //"inst_executed_shared_atom_cas" 
    { PASCAL_SM_SHARED_ATOM, pascal_sm_shared_atom_enc_str_1, pascal_sm_shared_atom_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_shared_atom_enc_str_3}, //"inst_executed_shared_atom" 
    { PASCAL_SM_WARP_CANT_ISSUE_LONG_SCOREBOARD, pascal_sm_warp_cant_issue_long_scoreboard_enc_str_1, pascal_sm_warp_cant_issue_long_scoreboard_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_long_scoreboard_enc_str_3}, //"warp_cant_issue_long_scoreboard" 
    { PASCAL_SM_INST_EXECUTED_ATTRIBUTE_ST, pascal_sm_inst_executed_attribute_st_enc_str_1, pascal_sm_inst_executed_attribute_st_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_attribute_st_enc_str_3}, //"inst_executed_attribute_st" 
    { PASCAL_SM_INST_EXECUTED_ATTRIBUTE_LD, pascal_sm_inst_executed_attribute_ld_enc_str_1, pascal_sm_inst_executed_attribute_ld_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_attribute_ld_enc_str_3}, //"inst_executed_attribute_ld" 
    { PASCAL_SM_WARP_CANT_ISSUE_BARRIER, pascal_sm_warp_cant_issue_barrier_enc_str_1, pascal_sm_warp_cant_issue_barrier_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_barrier_enc_str_3}, //"warp_cant_issue_barrier" 
    { PASCAL_SM_GLOBAL_ATOM_CAS, pascal_sm_global_atom_cas_enc_str_1, pascal_sm_global_atom_cas_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_global_atom_cas_enc_str_3}, //"inst_executed_global_atom_cas" 
    { PASCAL_SM_GLOBAL_ATOM, pascal_sm_global_atom_enc_str_1, pascal_sm_global_atom_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_global_atom_enc_str_3}, //"inst_executed_global_atom" 
    { PASCAL_SM_WARP_CANT_ISSUE_OFF_DECK_SHORT_SCOREBOARD, pascal_sm_warp_cant_issue_off_deck_short_scoreboard_enc_str_1, pascal_sm_warp_cant_issue_off_deck_short_scoreboard_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_off_deck_short_scoreboard_enc_str_3}, //"warp_cant_issue_off_deck_short_scoreboard" 
    { PASCAL_SM_GLOBAL_LOAD, pascal_sm_global_load_enc_str_1, pascal_sm_global_load_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_global_load_enc_str_3}, //"global_load" 
    { PASCAL_SM_GLOBAL_STORE, pascal_sm_global_store_enc_str_1, pascal_sm_global_store_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_global_store_enc_str_3}, //"global_store" 
    { PASCAL_SM_WARP_CANT_ISSUE_TILE_ALLOCATION_STALL, pascal_sm_warp_cant_issue_tile_allocation_stall_enc_str_1, pascal_sm_warp_cant_issue_tile_allocation_stall_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_tile_allocation_stall_enc_str_3}, //"warp_cant_issue_tile_allocation_stall" 
    { PASCAL_SM_GENERIC_LOAD, pascal_sm_generic_load_enc_str_1, pascal_sm_generic_load_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_generic_load_enc_str_3}, //"generic_load" 
    { PASCAL_SM_GENERIC_STORE, pascal_sm_generic_store_enc_str_1, pascal_sm_generic_store_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_generic_store_enc_str_3}, //"generic_store" 
    { PASCAL_SM_WARP_CANT_ISSUE_ALLOCATION_STALL_NO_SPACE, pascal_sm_warp_cant_issue_allocation_stall_no_space_enc_str_1, pascal_sm_warp_cant_issue_allocation_stall_no_space_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_allocation_stall_no_space_enc_str_3}, //"warp_cant_issue_allocation_stall_no_space" 
    { PASCAL_SM_INST_EXECUTED_SURFACE_ATOM, pascal_sm_inst_executed_surface_atom_enc_str_1, pascal_sm_inst_executed_surface_atom_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_surface_atom_enc_str_3}, //"inst_executed_surface_atom" 
    { PASCAL_SM_INST_EXECUTED_SURFACE_ATOM_CAS, pascal_sm_inst_executed_surface_atom_cas_enc_str_1, pascal_sm_inst_executed_surface_atom_cas_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_surface_atom_cas_enc_str_3}, //"inst_executed_surface_atom_cas" 
    { PASCAL_SM_WARP_CANT_ISSUE_ALLOCATION_STALL_NOT_ELIGIBLE, pascal_sm_warp_cant_issue_allocation_stall_not_eligible_enc_str_1, pascal_sm_warp_cant_issue_allocation_stall_not_eligible_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_allocation_stall_not_eligible_enc_str_3}, //"warp_cant_issue_allocation_stall_not_eligible" 
    { PASCAL_SM_INST_EXECUTED_SURFACE_LD, pascal_sm_inst_executed_surface_ld_enc_str_1, pascal_sm_inst_executed_surface_ld_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_surface_ld_enc_str_3}, //"inst_executed_surface_ld" 
    { PASCAL_SM_INST_EXECUTED_SURFACE_ST, pascal_sm_inst_executed_surface_st_enc_str_1, pascal_sm_inst_executed_surface_st_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_surface_st_enc_str_3}, //"inst_executed_surface_st" 
    { PASCAL_SM_WARP_CANT_ISSUE_MISC, pascal_sm_warp_cant_issue_misc_enc_str_1, pascal_sm_warp_cant_issue_misc_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_misc_enc_str_3}, //"warp_cant_issue_misc" 
    { PASCAL_SM_GLOBAL_RED, pascal_sm_global_red_enc_str_1, pascal_sm_global_red_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_global_red_enc_str_3}, //"global_red" 
    { PASCAL_SM_INST_EXECUTED_SURFACE_RED, pascal_sm_inst_executed_surface_red_enc_str_1, pascal_sm_inst_executed_surface_red_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_surface_red_enc_str_3}, //"inst_executed_surface_red" 
    { PASCAL_SM_WARP_CANT_ISSUE_MEMBAR, pascal_sm_warp_cant_issue_membar_enc_str_1, pascal_sm_warp_cant_issue_membar_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_membar_enc_str_3}, //"warp_cant_issue_membar" 
    { PASCAL_SM_INST_EXECUTED_ADU_PIPE, pascal_sm_inst_executed_adu_pipe_enc_str_1, pascal_sm_inst_executed_adu_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_adu_pipe_enc_str_3}, //"inst_executed_adu_pipe" 
    { PASCAL_SM_INST_EXECUTED_SU_PIPE, pascal_sm_inst_executed_su_pipe_enc_str_1, pascal_sm_inst_executed_su_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_su_pipe_enc_str_3}, //"inst_executed_su_pipe" 
    { PASCAL_SM_WARP_CANT_ISSUE_ON_DECK_SHORT_SCOREBOARD, pascal_sm_warp_cant_issue_on_deck_short_scoreboard_enc_str_1, pascal_sm_warp_cant_issue_on_deck_short_scoreboard_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_on_deck_short_scoreboard_enc_str_3}, //"warp_cant_issue_on_deck_short_scoreboard" 
    { PASCAL_SM_WARP_CANT_ISSUE_WAIT, pascal_sm_warp_cant_issue_wait_enc_str_1, pascal_sm_warp_cant_issue_wait_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_wait_enc_str_3}, //"warp_cant_issue_wait" 
    { PASCAL_SM_INST_EXECUTED_LDC_PIPE, pascal_sm_inst_executed_ldc_pipe_enc_str_1, pascal_sm_inst_executed_ldc_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_ldc_pipe_enc_str_3}, //"inst_executed_ldc_pipe" 
    { PASCAL_SM_INST_EXECUTED_LSU_PIPE, pascal_sm_inst_executed_lsu_pipe_enc_str_1, pascal_sm_inst_executed_lsu_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_lsu_pipe_enc_str_3}, //"inst_executed_lsu_pipe" 
    { PASCAL_SM_WARP_CANT_ISSUE_NO_INSTRUCTIONS, pascal_sm_warp_cant_issue_no_instructions_enc_str_1, pascal_sm_warp_cant_issue_no_instructions_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_no_instructions_enc_str_3}, //"warp_cant_issue_no_instructions" 
    { PASCAL_SM_WARP_CANT_ISSUE_SHADOW_PIPE_THROTTLE, pascal_sm_warp_cant_issue_shadow_pipe_throttle_enc_str_1, pascal_sm_warp_cant_issue_shadow_pipe_throttle_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_shadow_pipe_throttle_enc_str_3}, //"warp_cant_issue_shadow_pipe_throttle" 
    { PASCAL_SM_INST_EXECUTED_FMAI_PIPE, pascal_sm_inst_executed_fmai_pipe_enc_str_1, pascal_sm_inst_executed_fmai_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_fmai_pipe_enc_str_3}, //"inst_executed_fmai_pipe" 
    { PASCAL_SM_INST_EXECUTED_FXU_PIPE, pascal_sm_inst_executed_fxu_pipe_enc_str_1, pascal_sm_inst_executed_fxu_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_fxu_pipe_enc_str_3}, //"inst_executed_fxu_pipe" 
    { PASCAL_SM_WARP_CANT_ISSUE_TEX_THROTTLE, pascal_sm_warp_cant_issue_tex_throttle_enc_str_1, pascal_sm_warp_cant_issue_tex_throttle_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_tex_throttle_enc_str_3}, //"warp_cant_issue_tex_throttle" 
    { PASCAL_SM_WARP_CANT_ISSUE_MIO_THROTTLE, pascal_sm_warp_cant_issue_mio_throttle_enc_str_1, pascal_sm_warp_cant_issue_mio_throttle_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_mio_throttle_enc_str_3}, //"warp_cant_issue_mio_throttle" 
    { PASCAL_SM_INST_EXECUTED_FE_PIPE, pascal_sm_inst_executed_fe_pipe_enc_str_1, pascal_sm_inst_executed_fe_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_fe_pipe_enc_str_3}, //"inst_executed_fe_pipe" 
    { PASCAL_SM_WARP_CANT_ISSUE_DISPATCH_STALL, pascal_sm_warp_cant_issue_dispatch_stall_enc_str_1, pascal_sm_warp_cant_issue_dispatch_stall_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_dispatch_stall_enc_str_3}, //"warp_cant_issue_dispatch_stall" 
    { PASCAL_SM_WARP_CANT_ISSUE_NOT_SELECTED, pascal_sm_warp_cant_issue_not_selected_enc_str_1, pascal_sm_warp_cant_issue_not_selected_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_not_selected_enc_str_3}, //"warp_cant_issue_not_selected" 
    { PASCAL_SM_INST_EXECUTED_FMA64LITE_PIPE, pascal_sm_inst_executed_fma64lite_pipe_enc_str_1, pascal_sm_inst_executed_fma64lite_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_fma64lite_pipe_enc_str_3}, //"inst_executed_fma64lite_pipe" 
    { PASCAL_SM_INST_EXECUTED_FMA64PLUS_PIPE, pascal_sm_inst_executed_fma64plus_pipe_enc_str_1, pascal_sm_inst_executed_fma64plus_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_fma64plus_pipe_enc_str_3}, //"inst_executed_fma64plus_pipe" 
    { PASCAL_SM_WARP_CANT_ISSUE_ON_DECK_LONG_SCOREBOARD, pascal_sm_warp_cant_issue_on_deck_long_scoreboard_enc_str_1, pascal_sm_warp_cant_issue_on_deck_long_scoreboard_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_on_deck_long_scoreboard_enc_str_3}, //"warp_cant_issue_on_deck_long_scoreboard" 
    { PASCAL_SM_WARP_CANT_ISSUE_ON_DECK_MISC, pascal_sm_warp_cant_issue_on_deck_misc_enc_str_1, pascal_sm_warp_cant_issue_on_deck_misc_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_on_deck_misc_enc_str_3}, //"warp_cant_issue_on_deck_misc" 
    { PASCAL_SM_INST_EXECUTED_FMA64PLUSPLUS_PIPE, pascal_sm_inst_executed_fma64plusplus_pipe_enc_str_1, pascal_sm_inst_executed_fma64plusplus_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_fma64plusplus_pipe_enc_str_3}, //"inst_executed_fma64plusplus_pipe" 
    { PASCAL_SM_INST_EXECUTED_BAR_PIPE, pascal_sm_inst_executed_bar_pipe_enc_str_1, pascal_sm_inst_executed_bar_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_bar_pipe_enc_str_3}, //"inst_executed_bar_pipe" 
    { PASCAL_SM_WARP_CANT_ISSUE_SELECTED, pascal_sm_warp_cant_issue_selected_enc_str_1, pascal_sm_warp_cant_issue_selected_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_selected_enc_str_3}, //"warp_cant_issue_selected" 
    { PASCAL_SM_WARP_ISSUE_ELIGIBLE, pascal_sm_warp_issue_eligible_enc_str_1, pascal_sm_warp_issue_eligible_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_issue_eligible_enc_str_3}, //"warp_issue_eligible" 
    { PASCAL_SM_WARPS_ON_DECK, pascal_sm_warps_on_deck_enc_str_1, pascal_sm_warps_on_deck_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warps_on_deck_enc_str_3}, //"warps_on_deck" 
    { PASCAL_SM_INST_EXECUTED_XU_PIPE, pascal_sm_inst_executed_xu_pipe_enc_str_1, pascal_sm_inst_executed_xu_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_xu_pipe_enc_str_3}, //"inst_executed_xu_pipe" 
    { PASCAL_SM_INST_EXECUTED_DECOUPLED_PRED_OFF, pascal_sm_inst_executed_decoupled_pred_off_enc_str_1, pascal_sm_inst_executed_decoupled_pred_off_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_decoupled_pred_off_enc_str_3}, //"inst_executed_decoupled_pred_off" 
    { PASCAL_SM_INST_EXECUTED_COUPLED_PRED_OFF, pascal_sm_inst_executed_coupled_pred_off_enc_str_1, pascal_sm_inst_executed_coupled_pred_off_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_coupled_pred_off_enc_str_3}, //"inst_executed_coupled_pred_off" 
    { PASCAL_SM_INST_EXECUTED_32B, pascal_sm_inst_executed_32b_enc_str_1, pascal_sm_inst_executed_32b_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_32b_enc_str_3}, //"inst_executed_32b" 
    { PASCAL_SM_INST_EXECUTED_64B, pascal_sm_inst_executed_64b_enc_str_1, pascal_sm_inst_executed_64b_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_64b_enc_str_3}, //"inst_executed_64b" 
    { PASCAL_SM_INST_EXECUTED_128B, pascal_sm_inst_executed_128b_enc_str_1, pascal_sm_inst_executed_128b_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_128b_enc_str_3}, //"inst_executed_128b" 
    { PASCAL_SM_INST_EXECUTED_U128B, pascal_sm_inst_executed_u128b_enc_str_1, pascal_sm_inst_executed_u128b_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_u128b_enc_str_3}, //"inst_executed_U128b" 
    { PASCAL_SM_INST_EXECUTED_LSU_GENERIC_SHARED, pascal_sm_inst_executed_lsu_generic_shared_enc_str_1, pascal_sm_inst_executed_lsu_generic_shared_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_lsu_generic_shared_enc_str_3}, //"inst_executed_lsu_generic_shared" 
    { PASCAL_SM_INST_EXECUTED_LSU_GENERIC_TEX, pascal_sm_inst_executed_lsu_generic_tex_enc_str_1, pascal_sm_inst_executed_lsu_generic_tex_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_lsu_generic_tex_enc_str_3}, //"inst_executed_lsu_generic_tex" 
    { PASCAL_SM_WARP_CANT_ISSUE_INST_ISSUED_0, pascal_sm_warp_cant_issue_inst_issued0_enc_str_1, pascal_sm_warp_cant_issue_inst_issued0_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_inst_issued0_enc_str_2}, //"warp_cant_issue_inst_issued0" 
    { PASCAL_SM_TEX_WB_REQUESTS_PENDING, pascal_sm_tex_wb_requests_pending_enc_str_1, pascal_sm_tex_wb_requests_pending_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_tex_wb_requests_pending_enc_str_3}, //"tex_wb_requests_pending" 
    { PASCAL_SM_TEX_WB_REQUESTS, pascal_sm_tex_wb_requests_enc_str_1, pascal_sm_tex_wb_requests_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_tex_wb_requests_enc_str_3}, //"tex_wb_requests" 
    { PASCAL_SM_IMC_HIT, pascal_sm_imc_hit_enc_str_1, pascal_sm_imc_hit_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_imc_hit_enc_str_3}, //"imc_hit" 
    { PASCAL_SM_IMC_FULL_TAG, pascal_sm_imc_full_tag_enc_str_1, pascal_sm_imc_full_tag_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_imc_full_tag_enc_str_3}, //"imc_full_tag" 
    { PASCAL_SM_IMC_TRUE_MISS, pascal_sm_imc_true_miss_enc_str_1, pascal_sm_imc_true_miss_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_imc_true_miss_enc_str_3}, //"imc_true_miss" 
    { PASCAL_SM_IMC_COVERED_MISS, pascal_sm_imc_covered_miss_enc_str_1, pascal_sm_imc_covered_miss_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_imc_covered_miss_enc_str_3}, //"imc_covered_miss" 
    { PASCAL_SM_IMC_MISSES_OUTSTANDING, pascal_sm_imc_misses_outstanding_enc_str_1, pascal_sm_imc_misses_outstanding_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_imc_misses_outstanding_enc_str_3}, //"imc_misses_outstanding" 
    { PASCAL_SM_FET_FETCHED_LINES, pascal_sm_fet_fetched_lines_enc_str_1, pascal_sm_fet_fetched_lines_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_fet_fetched_lines_enc_str_3}, //"fet_fetched_lines" 
    { PASCAL_SM_UNWINDING_BR_EXECUTED, pascal_sm_unwinding_br_executed_enc_str_1, pascal_sm_unwinding_br_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_unwinding_br_executed_enc_str_3}, //"unwinding_br_executed" 
    { PASCAL_SM_DIVERGED_BR_EXECUTED, pascal_sm_diverged_br_executed_enc_str_1, pascal_sm_diverged_br_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_diverged_br_executed_enc_str_3}, //"diverged_br_executed" 
    { PASCAL_SM_UNIQUE_IDX_BR_EXECUTED, pascal_sm_unique_idx_br_executed_enc_str_1, pascal_sm_unique_idx_br_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_unique_idx_br_executed_enc_str_3}, //"unique_idx_br_executed" 
    { PASCAL_SM_RVAL_DIV_IDX_BR_EXECUTED, pascal_sm_rval_div_idx_br_executed_enc_str_1, pascal_sm_rval_div_idx_br_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_rval_div_idx_br_executed_enc_str_3}, //"rval_div_idx_br_executed" 
    { PASCAL_SM_BR_EXECUTED, pascal_sm_br_executed_enc_str_1, pascal_sm_br_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_br_executed_enc_str_3}, //"br_executed" 
    { PASCAL_SM_TAKEN_BR_EXECUTED, pascal_sm_taken_br_executed_enc_str_1, pascal_sm_taken_br_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_taken_br_executed_enc_str_3}, //"taken_br_executed" 
    { PASCAL_SM_PRED_DIV_IDX_BR_EXECUTED, pascal_sm_pred_div_idx_br_executed_enc_str_1, pascal_sm_pred_div_idx_br_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pred_div_idx_br_executed_enc_str_3}, //"pred_div_idx_br_executed" 
    { PASCAL_SM_INST_EXECUTED_BRU_PIPE, pascal_sm_inst_executed_bru_pipe_enc_str_1, pascal_sm_inst_executed_bru_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_bru_pipe_enc_str_3}, //"inst_executed_bru_pipe" 
    { PASCAL_SM_TEX_REQUESTS, pascal_sm_tex_requests_enc_str_1, pascal_sm_tex_requests_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_tex_requests_enc_str_3}, //"tex_requests" 
    { PASCAL_SM_TEX_REQ_ACTIVE, pascal_sm_tex_req_active_enc_str_1, pascal_sm_tex_req_active_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_tex_req_active_enc_str_3}, //"tex_req_active" 
    { PASCAL_SM_TEX_REQ_STALLED, pascal_sm_tex_req_stalled_enc_str_1, pascal_sm_tex_req_stalled_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_tex_req_stalled_enc_str_3}, //"tex_req_stalled" 
    { PASCAL_SM_TEX_REQ_STARVED, pascal_sm_tex_req_starved_enc_str_1, pascal_sm_tex_req_starved_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_tex_req_starved_enc_str_3}, //"tex_req_starved" 
    { PASCAL_SM_TEX_REQ_IDLE, pascal_sm_tex_req_idle_enc_str_1, pascal_sm_tex_req_idle_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_tex_req_idle_enc_str_3}, //"tex_req_idle" 
    { PASCAL_SM_SCG_MODE_COMPUTE, pascal_sm_scg_mode_compute_enc_str_1, pascal_sm_scg_mode_compute_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_scg_mode_compute_enc_str_2}, //"scg_mode_compute" 
    { PASCAL_SM_SCG_MODE_GRAPHICS, pascal_sm_scg_mode_graphics_enc_str_1, pascal_sm_scg_mode_graphics_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_scg_mode_graphics_enc_str_2}, //"scg_mode_graphics" 
    { PASCAL_SM_NOT_IN_TRAP_QUAD, pascal_sm_not_in_trap_quad_enc_str_1, pascal_sm_not_in_trap_quad_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_not_in_trap_quad_enc_str_2}, //"not_in_trap_quad" 
    { PASCAL_SM_SCG_MODE_COMPUTE_CORE, pascal_sm_scg_mode_compute_core_enc_str_1, pascal_sm_scg_mode_compute_core_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_scg_mode_compute_enc_str_2}, //"scg_mode_compute" 
    { PASCAL_SM_SCG_MODE_GRAPHICS_CORE, pascal_sm_scg_mode_graphics_core_enc_str_1, pascal_sm_scg_mode_graphics_core_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_scg_mode_graphics_enc_str_2}, //"scg_mode_graphics" 
    { PASCAL_SM_NOT_IN_TRAP_CORE, pascal_sm_not_in_trap_core_enc_str_1, pascal_sm_not_in_trap_core_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_not_in_trap_quad_enc_str_2}, //"not_in_trap_core" 
    { PASCAL_SM_LSU_WB_OPS_PENDING, pascal_sm_lsu_wb_ops_pending_enc_str_1, pascal_sm_lsu_wb_ops_pending_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_lsu_wb_ops_pending_enc_str_3}, //"lsu_wb_ops_pending" 
    { PASCAL_SM_INST_EXECUTED_LSU_WB_OPS, pascal_sm_inst_executed_lsu_wb_ops_enc_str_1, pascal_sm_inst_executed_lsu_wb_ops_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_lsu_wb_ops_enc_str_3}, //"inst_executed_lsu_wb_ops" 
    { PASCAL_SM_INST_EXECUTED_VOTE_VTG, pascal_sm_inst_executed_vote_vtg_enc_str_1, pascal_sm_inst_executed_vote_vtg_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_vote_vtg_enc_str_3}, //"inst_executed_vote_vtg" 
    { PASCAL_SM_TEX_INST_PENDING, pascal_sm_tex_inst_pending_enc_str_1, pascal_sm_tex_inst_pending_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_tex_inst_pending_enc_str_3}, //"tex_inst_pending" 
    { PASCAL_SM_TEX_WB_INST_EXECUTED, pascal_sm_tex_wb_inst_executed_enc_str_1, pascal_sm_tex_wb_inst_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_tex_wb_inst_executed_enc_str_3}, //"tex_wb_inst_executed" 
    { PASCAL_SM_INST_EXECUTED_TEX_PIPE, pascal_sm_inst_executed_tex_pipe_enc_str_1, pascal_sm_inst_executed_tex_pipe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_inst_executed_tex_pipe_enc_str_3}, //"inst_executed_tex_pipe" 

    { PASCAL_SM_PMTRIG_MULTI_GROUP,  pascal_multigrp_counter_pmtrig_enc_str_1,  pascal_multigrp_counter_pmtrig_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  pascal_multigrp_counter_pmtrig_enc_str_1},
    { PASCAL_SM_NON_IDLE_CORE, pascal_sm_non_idle_core_enc_str_1, pascal_sm_non_idle_core_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_non_idle_core_enc_str_3}, //"non_idle_core" 
    { PASCAL_SM_ACTIVE_CYCLES, pascal_sm_active_cycles_enc_str_1, pascal_sm_active_cycles_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_active_cycles_enc_str_3}, //"active_cycles" 
    { PASCAL_SM_ACTIVE_CYCLES_CORE_UNFILTERED, pascal_sm_active_cycles_core_unfiltered_enc_str_1, pascal_sm_active_cycles_core_unfiltered_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_active_cycles_core_unfiltered_enc_str_3}, //"active_cycles_core_unfiltered" 
    { PASCAL_SM_ACTIVE_CYCLES_IN_TRAP, pascal_sm_active_cycles_in_trap_enc_str_1, pascal_sm_active_cycles_in_trap_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_active_cycles_in_trap_enc_str_3}, //"active_cycles_in_trap" 
    { PASCAL_SM_ACTIVE_WARPS, pascal_sm_active_warps_enc_str_1, pascal_sm_active_warps_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_active_warps_enc_str_3}, //"active_warps" 
    { PASCAL_SM_ACTIVE_CTAS, pascal_sm_active_ctas_enc_str_1, pascal_sm_active_ctas_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_active_ctas_enc_str_3}, //"active_ctas" 
    { PASCAL_SM_SM_CTA_LAUNCHED, pascal_sm_sm_cta_launched_enc_str_1, pascal_sm_sm_cta_launched_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_sm_cta_launched_enc_str_3}, //"sm_cta_launched" 
    { PASCAL_SM_ACTIVE_WARPS_PS, pascal_sm_active_warps_ps_enc_str_1, pascal_sm_active_warps_ps_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_active_warps_ps_enc_str_3}, //"active_warps_ps" 
    { PASCAL_SM_ACTIVE_WARPS_VTG, pascal_sm_active_warps_vtg_enc_str_1, pascal_sm_active_warps_vtg_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_active_warps_vtg_enc_str_3}, //"active_warps_vtg" 
    { PASCAL_SM_ACTIVE_SUBTILES, pascal_sm_active_subtiles_enc_str_1, pascal_sm_active_subtiles_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_active_subtiles_enc_str_3}, //"active_subtiles" 
    { PASCAL_SM_SUBTILES_LAUNCHED_H0, pascal_sm_subtiles_launched_h0_enc_str_1, pascal_sm_subtiles_launched_h0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_subtiles_launched_h0_enc_str_3}, //"subtiles_launched_h0" 
    { PASCAL_SM_SUBTILES_LAUNCHED_H1, pascal_sm_subtiles_launched_h1_enc_str_1, pascal_sm_subtiles_launched_h1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_subtiles_launched_h1_enc_str_3}, //"subtiles_launched_h1" 
    { PASCAL_SM_TRAP_COALESCING, pascal_sm_trap_coalescing_enc_str_1, pascal_sm_trap_coalescing_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_trap_coalescing_enc_str_3}, //"trap_coalescing" 
    { PASCAL_SM_TRAP_COUNT, pascal_sm_trap_count_enc_str_1, pascal_sm_trap_count_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_trap_count_enc_str_3}, //"trap_count" 
    { PASCAL_SM_TRAP_IDLING_FOR_TRAP, pascal_sm_trap_idling_for_trap_enc_str_1, pascal_sm_trap_idling_for_trap_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_trap_idling_for_trap_enc_str_3}, //"trap_idling_for_trap" 
    { PASCAL_SM_TRAP_IN_TRAP_CORE, pascal_sm_trap_in_trap_core_enc_str_1, pascal_sm_trap_in_trap_core_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_trap_in_trap_core_enc_str_3}, //"trap_in_trap_core" 
    { PASCAL_SM_TRAP_CLEARING_IDE, pascal_sm_trap_clearing_ide_enc_str_1, pascal_sm_trap_clearing_ide_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_trap_clearing_ide_enc_str_3}, //"trap_clearing_ide" 
    { PASCAL_SM_TRAP_WAITING_FOR_IDE, pascal_sm_trap_waiting_for_ide_enc_str_1, pascal_sm_trap_waiting_for_ide_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_trap_waiting_for_ide_enc_str_3}, //"trap_waiting_for_ide" 
    { PASCAL_SM_ICC_HIT, pascal_sm_icc_hit_enc_str_1, pascal_sm_icc_hit_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_icc_hit_enc_str_3}, //"icc_hit" 
    { PASCAL_SM_ICC_TRUE_MISS, pascal_sm_icc_true_miss_enc_str_1, pascal_sm_icc_true_miss_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_icc_true_miss_enc_str_3}, //"icc_true_miss" 
    { PASCAL_SM_ICC_COVERED_MISS, pascal_sm_icc_covered_miss_enc_str_1, pascal_sm_icc_covered_miss_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_icc_covered_miss_enc_str_3}, //"icc_covered_miss" 
    { PASCAL_SM_ICC_FULL_TAG, pascal_sm_icc_full_tag_enc_str_1, pascal_sm_icc_full_tag_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_icc_full_tag_enc_str_3}, //"icc_full_tag" 
    { PASCAL_SM_ICC_PREFETCHES, pascal_sm_icc_prefetches_enc_str_1, pascal_sm_icc_prefetches_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_icc_prefetches_enc_str_3}, //"icc_prefetches" 
    { PASCAL_SM_ICC_UNLOCK_ALL, pascal_sm_icc_unlock_all_enc_str_1, pascal_sm_icc_unlock_all_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_icc_unlock_all_enc_str_3}, //"icc_unlock_all" 
    { PASCAL_SM_ICC_MISSES_OUTSTANDING, pascal_sm_icc_misses_outstanding_enc_str_1, pascal_sm_icc_misses_outstanding_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_icc_misses_outstanding_enc_str_3}, //"icc_misses_outstanding" 
    { PASCAL_SM_GROUP9_PLACEHOLDER, pascal_sm_group9_placeholder_enc_str_1, pascal_sm_group9_placeholder_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_group9_placeholder_enc_str_3}, //"group9_placeholder" 
    { PASCAL_SM_SHARED_LD_BANK_CONFLICT, pascal_sm_shared_ld_bank_conflict_enc_str_1, pascal_sm_shared_ld_bank_conflict_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_shared_ld_bank_conflict_enc_str_3}, //"shared_ld_bank_conflict"
    { PASCAL_SM_SHARED_ST_BANK_CONFLICT, pascal_sm_shared_st_bank_conflict_enc_str_1, pascal_sm_shared_st_bank_conflict_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_shared_st_bank_conflict_h0_enc_str_3}, //"shared_st_bank_conflict" 
    { PASCAL_SM_SHARED_LOAD_TRANSACTIONS, pascal_sm_shared_ld_transactions_enc_str_1, pascal_sm_shared_ld_transactions_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_shared_ld_transactions_enc_str_3}, //"shared_load" 
    { PASCAL_SM_SHARED_STORE_TRANSACTIONS, pascal_sm_shared_st_transactions_enc_str_1, pascal_sm_shared_st_transactions_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_shared_st_transactions_enc_str_3}, //"shared_store" 
    { PASCAL_SM_SHARED_LD_BANK_CONFLICT_H0, pascal_sm_shared_ld_bank_conflict_h0_enc_str_1, pascal_sm_shared_ld_bank_conflict_h0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_shared_ld_bank_conflict_h0_enc_str_3}, //"shared_ld_bank_conflict_h0" 
    { PASCAL_SM_SHARED_ST_BANK_CONFLICT_H0, pascal_sm_shared_st_bank_conflict_h0_enc_str_1, pascal_sm_shared_st_bank_conflict_h0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_shared_st_bank_conflict_h0_enc_str_3}, //"shared_st_bank_conflict_h0" 
    { PASCAL_SM_SHARED_LOAD_TRANSACTIONS_H0, pascal_sm_shared_ld_transactions_h0_enc_str_1, pascal_sm_shared_ld_transactions_h0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_shared_ld_transactions_h0_enc_str_3}, //"shared_load_h0" 
    { PASCAL_SM_SHARED_STORE_TRANSACTIONS_H0, pascal_sm_shared_st_transactions_h0_enc_str_1, pascal_sm_shared_st_transactions_h0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_shared_st_transactions_h0_enc_str_3}, //"shared_store_h0" 
    { PASCAL_SM_PQ_WRITE_Q0, pascal_sm_pq_write_q0_enc_str_1, pascal_sm_pq_write_q0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_write_q0_enc_str_3}, //"pq_write_q0" 
    { PASCAL_SM_PQ_WRITE_Q1, pascal_sm_pq_write_q1_enc_str_1, pascal_sm_pq_write_q1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_write_q1_enc_str_3}, //"pq_write_q1" 
    { PASCAL_SM_ADU_REPLAY_Q0, pascal_sm_adu_replay_q0_enc_str_1, pascal_sm_adu_replay_q0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_adu_replay_q0_enc_str_3}, //"adu_replay_q0" 
    { PASCAL_SM_ADU_REPLAY_Q1, pascal_sm_adu_replay_q1_enc_str_1, pascal_sm_adu_replay_q1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_adu_replay_q1_enc_str_3}, //"adu_replay_q1" 
    { PASCAL_SM_SHARED_LD_BANK_CONFLICT_H1, pascal_sm_shared_ld_bank_conflict_h1_enc_str_1, pascal_sm_shared_ld_bank_conflict_h1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_shared_ld_bank_conflict_h1_enc_str_3}, //"shared_ld_bank_conflict_h1" 
    { PASCAL_SM_SHARED_ST_BANK_CONFLICT_H1, pascal_sm_shared_st_bank_conflict_h1_enc_str_1, pascal_sm_shared_st_bank_conflict_h1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_shared_st_bank_conflict_h1_enc_str_3}, //"shared_st_bank_conflict_h1" 
    { PASCAL_SM_SHARED_LOAD_TRANSACTIONS_H1, pascal_sm_shared_ld_transactions_h1_enc_str_1, pascal_sm_shared_ld_transactions_h1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_shared_ld_transactions_h1_enc_str_3}, //"shared_load_h1" 
    { PASCAL_SM_SHARED_STORE_TRANSACTIONS_H1, pascal_sm_shared_st_transactions_h1_enc_str_1, pascal_sm_shared_st_transactions_h1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_shared_st_transactions_h1_enc_str_3}, //"shared_store_h1" 
    { PASCAL_SM_PQ_WRITE_Q2, pascal_sm_pq_write_q2_enc_str_1, pascal_sm_pq_write_q2_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_write_q2_enc_str_3}, //"pq_write_q2" 
    { PASCAL_SM_PQ_WRITE_Q3, pascal_sm_pq_write_q3_enc_str_1, pascal_sm_pq_write_q3_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_write_q3_enc_str_3}, //"pq_write_q3" 
    { PASCAL_SM_ADU_REPLAY_Q2, pascal_sm_adu_replay_q2_enc_str_1, pascal_sm_adu_replay_q2_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_adu_replay_q2_enc_str_3}, //"adu_replay_q2" 
    { PASCAL_SM_ADU_REPLAY_Q3, pascal_sm_adu_replay_q3_enc_str_1, pascal_sm_adu_replay_q3_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_adu_replay_q3_enc_str_3}, //"adu_replay_q3" 
    { PASCAL_SM_PQ_READS_FOR_SHM_Q0, pascal_sm_pq_reads_for_shm_q0_enc_str_1, pascal_sm_pq_reads_for_shm_q0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_reads_for_shm_q0_enc_str_3}, //"pq_reads_for_shm_q0" 
    { PASCAL_SM_PQ_READS_FOR_PIXOUT_Q0, pascal_sm_pq_reads_for_pixout_q0_enc_str_1, pascal_sm_pq_reads_for_pixout_q0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_reads_for_pixout_q0_enc_str_3}, //"pq_reads_for_pixout_q0" 
    { PASCAL_SM_PQ_READS_FOR_TEX_Q0, pascal_sm_pq_reads_for_tex_q0_enc_str_1, pascal_sm_pq_reads_for_tex_q0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_reads_for_tex_q0_enc_str_3}, //"pq_reads_for_tex_q0" 
    { PASCAL_SM_PQ_READS_FOR_SHM_STOLEN_Q0, pascal_sm_pq_reads_for_shm_stolen_q0_enc_str_1, pascal_sm_pq_reads_for_shm_stolen_q0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_reads_for_shm_stolen_q0_enc_str_3}, //"pq_reads_for_shm_stolen_q0" 
    { PASCAL_SM_PQ_READS_FOR_SHM_Q1, pascal_sm_pq_reads_for_shm_q1_enc_str_1, pascal_sm_pq_reads_for_shm_q1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_reads_for_shm_q1_enc_str_3}, //"pq_reads_for_shm_q1" 
    { PASCAL_SM_PQ_READS_FOR_PIXOUT_Q1, pascal_sm_pq_reads_for_pixout_q1_enc_str_1, pascal_sm_pq_reads_for_pixout_q1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_reads_for_pixout_q1_enc_str_3}, //"pq_reads_for_pixout_q1" 
    { PASCAL_SM_PQ_READS_FOR_TEX_Q1, pascal_sm_pq_reads_for_tex_q1_enc_str_1, pascal_sm_pq_reads_for_tex_q1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_reads_for_tex_q1_enc_str_3}, //"pq_reads_for_tex_q1" 
    { PASCAL_SM_PQ_READS_FOR_SHM_STOLEN_Q1, pascal_sm_pq_reads_for_shm_stolen_q1_enc_str_1, pascal_sm_pq_reads_for_shm_stolen_q1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_reads_for_shm_stolen_q1_enc_str_3}, //"pq_reads_for_shm_stolen_q1" 
    { PASCAL_SM_PQ_READS_FOR_SHM_Q2, pascal_sm_pq_reads_for_shm_q2_enc_str_1, pascal_sm_pq_reads_for_shm_q2_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_reads_for_shm_q2_enc_str_3}, //"pq_reads_for_shm_q2" 
    { PASCAL_SM_PQ_READS_FOR_PIXOUT_Q2, pascal_sm_pq_reads_for_pixout_q2_enc_str_1, pascal_sm_pq_reads_for_pixout_q2_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_reads_for_pixout_q2_enc_str_3}, //"pq_reads_for_pixout_q2" 
    { PASCAL_SM_PQ_READS_FOR_TEX_Q2, pascal_sm_pq_reads_for_tex_q2_enc_str_1, pascal_sm_pq_reads_for_tex_q2_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_reads_for_tex_q2_enc_str_3}, //"pq_reads_for_tex_q2" 
    { PASCAL_SM_PQ_READS_FOR_SHM_STOLEN_Q2, pascal_sm_pq_reads_for_shm_stolen_q2_enc_str_1, pascal_sm_pq_reads_for_shm_stolen_q2_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_reads_for_shm_stolen_q2_enc_str_3}, //"pq_reads_for_shm_stolen_q2" 
    { PASCAL_SM_PQ_READS_FOR_SHM_Q3, pascal_sm_pq_reads_for_shm_q3_enc_str_1, pascal_sm_pq_reads_for_shm_q3_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_reads_for_shm_q3_enc_str_3}, //"pq_reads_for_shm_q3" 
    { PASCAL_SM_PQ_READS_FOR_PIXOUT_Q3, pascal_sm_pq_reads_for_pixout_q3_enc_str_1, pascal_sm_pq_reads_for_pixout_q3_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_reads_for_pixout_q3_enc_str_3}, //"pq_reads_for_pixout_q3" 
    { PASCAL_SM_PQ_READS_FOR_TEX_Q3, pascal_sm_pq_reads_for_tex_q3_enc_str_1, pascal_sm_pq_reads_for_tex_q3_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_reads_for_tex_q3_enc_str_3}, //"pq_reads_for_tex_q3" 
    { PASCAL_SM_PQ_READS_FOR_SHM_STOLEN_Q3, pascal_sm_pq_reads_for_shm_stolen_q3_enc_str_1, pascal_sm_pq_reads_for_shm_stolen_q3_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_reads_for_shm_stolen_q3_enc_str_3}, //"pq_reads_for_shm_stolen_q3" 
    { PASCAL_SM_IDC_HIT, pascal_sm_idc_hit_enc_str_1, pascal_sm_idc_hit_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_idc_hit_enc_str_3}, //"idc_hit" 
    { PASCAL_SM_IDC_FULL_TAG, pascal_sm_idc_full_tag_enc_str_1, pascal_sm_idc_full_tag_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_idc_full_tag_enc_str_3}, //"idc_full_tag" 
    { PASCAL_SM_IDC_TRUE_MISS, pascal_sm_idc_true_miss_enc_str_1, pascal_sm_idc_true_miss_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_idc_true_miss_enc_str_3}, //"idc_true_miss" 
    { PASCAL_SM_IDC_COVERED_MISS, pascal_sm_idc_covered_miss_enc_str_1, pascal_sm_idc_covered_miss_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_idc_covered_miss_enc_str_3}, //"idc_covered_miss" 
    { PASCAL_SM_IDC_DIVERGENCE_REPLAY_Q0, pascal_sm_idc_divergence_replay_q0_enc_str_1, pascal_sm_idc_divergence_replay_q0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_idc_divergence_replay_q0_enc_str_3}, //"idc_divergence_replay_q0" 
    { PASCAL_SM_IDC_DIVERGENT_INSTRUCTION_Q0, pascal_sm_idc_divergent_instruction_q0_enc_str_1, pascal_sm_idc_divergent_instruction_q0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_idc_divergent_instruction_q0_enc_str_3}, //"idc_divergent_instruction_q0" 
    { PASCAL_SM_IDC_DIVERGENCE_REPLAY_Q1, pascal_sm_idc_divergence_replay_q1_enc_str_1, pascal_sm_idc_divergence_replay_q1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_idc_divergence_replay_q1_enc_str_3}, //"idc_divergence_replay_q1" 
    { PASCAL_SM_IDC_DIVERGENT_INSTRUCTION_Q1, pascal_sm_idc_divergent_instruction_q1_enc_str_1, pascal_sm_idc_divergent_instruction_q1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_idc_divergent_instruction_q1_enc_str_3}, //"idc_divergent_instruction_q1" 
    { PASCAL_SM_MEMBAR_EXECUTED, pascal_sm_membar_executed_enc_str_1, pascal_sm_membar_executed_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_membar_executed_enc_str_3}, //"membar_executed" 
    { PASCAL_SM_MEMBAR_PENDING, pascal_sm_membar_pending_enc_str_1, pascal_sm_membar_pending_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_membar_pending_enc_str_3}, //"membar_pending" 
    { PASCAL_SM_MEMBAR_SENT_TO_TEX, pascal_sm_membar_sent_to_tex_enc_str_1, pascal_sm_membar_sent_to_tex_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_membar_sent_to_tex_enc_str_3}, //"membar_sent_to_tex" 
    { PASCAL_SM_MEMBAR_CTA_SENT_TO_TEX_H0, pascal_sm_membar_cta_sent_to_tex_h0_enc_str_1, pascal_sm_membar_cta_sent_to_tex_h0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_membar_cta_sent_to_tex_h0_enc_str_3}, //"membar_cta_sent_to_tex_h0" 
    { PASCAL_SM_MEMBAR_CTA_SENT_TO_TEX_H1, pascal_sm_membar_cta_sent_to_tex_h1_enc_str_1, pascal_sm_membar_cta_sent_to_tex_h1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_membar_cta_sent_to_tex_h1_enc_str_3}, //"membar_cta_sent_to_tex_h1" 
    { PASCAL_SM_MEMBAR_CTA_SYNTHETIC, pascal_sm_membar_cta_synthetic_enc_str_1, pascal_sm_membar_cta_synthetic_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_membar_cta_synthetic_enc_str_3}, //"membar_cta_synthetic" 
    { PASCAL_SM_LSU_BUSY_H0, pascal_sm_lsu_busy_h0_enc_str_1, pascal_sm_lsu_busy_h0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_lsu_busy_h0_enc_str_3}, //"lsu_busy_h0" 
    { PASCAL_SM_LSU_BUSY_H1, pascal_sm_lsu_busy_h1_enc_str_1, pascal_sm_lsu_busy_h1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_lsu_busy_h1_enc_str_3}, //"lsu_busy_h1" 
    { PASCAL_SM_PIXOUT_QUADS_DRAINED, pascal_sm_pixout_quads_drained_enc_str_1, pascal_sm_pixout_quads_drained_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pixout_quads_drained_enc_str_3}, //"pixout_quads_drained" 
    { PASCAL_SM_HALF_WARPS_KILLED_BY_SHADER, pascal_sm_half_warps_killed_by_shader_enc_str_1, pascal_sm_half_warps_killed_by_shader_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_half_warps_killed_by_shader_enc_str_3}, //"half_warps_killed_by_shader" 
    { PASCAL_SM_QUADS_KILLED_BY_SHADER, pascal_sm_quads_killed_by_shader_enc_str_1, pascal_sm_quads_killed_by_shader_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_quads_killed_by_shader_enc_str_3}, //"quads_killed_by_shader" 
    { PASCAL_SM_WARPS_KILLED_BY_SHADER, pascal_sm_warps_killed_by_shader_enc_str_1, pascal_sm_warps_killed_by_shader_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warps_killed_by_shader_enc_str_3}, //"warps_killed_by_shader" 
    { PASCAL_SM_PIXELS_KILLED_SHADERCOVG, pascal_sm_pixels_killed_shadercovg_enc_str_1, pascal_sm_pixels_killed_shadercovg_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pixels_killed_shadercovg_enc_str_3}, //"pixels_killed_shadercovg" 
    { PASCAL_SM_SM2GPM_OUTPUT_STALL, pascal_sm_sm2gpm_output_stall_enc_str_1, pascal_sm_sm2gpm_output_stall_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_sm2gpm_output_stall_enc_str_3}, //"sm2gpm_output_stall" 
    { PASCAL_SM_MIO_ISBE_WRITE_H0, pascal_sm_mio_isbe_write_h0_enc_str_1, pascal_sm_mio_isbe_write_h0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_isbe_write_h0_enc_str_3}, //"mio_isbe_write_h0" 
    { PASCAL_SM_MIO_ISBE_READ_H0, pascal_sm_mio_isbe_read_h0_enc_str_1, pascal_sm_mio_isbe_read_h0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_isbe_read_h0_enc_str_3}, //"mio_isbe_read_h0" 
    { PASCAL_SM_MIO_SM_STALLED_DUE_TO_PE_Q0, pascal_sm_mio_sm_stalled_due_to_pe_q0_enc_str_1, pascal_sm_mio_sm_stalled_due_to_pe_q0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_sm_stalled_due_to_pe_q0_enc_str_3}, //"mio_sm_stalled_due_to_pe_q0" 
    { PASCAL_SM_MIO_SM_STALLED_DUE_TO_PE_Q1, pascal_sm_mio_sm_stalled_due_to_pe_q1_enc_str_1, pascal_sm_mio_sm_stalled_due_to_pe_q1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_sm_stalled_due_to_pe_q1_enc_str_3}, //"mio_sm_stalled_due_to_pe_q1" 
    { PASCAL_SM_MIO_ISBE_WRITE_H1, pascal_sm_mio_isbe_write_h1_enc_str_1, pascal_sm_mio_isbe_write_h1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_isbe_write_h1_enc_str_3}, //"mio_isbe_write_h1" 
    { PASCAL_SM_MIO_ISBE_READ_H1, pascal_sm_mio_isbe_read_h1_enc_str_1, pascal_sm_mio_isbe_read_h1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_isbe_read_h1_enc_str_3}, //"mio_isbe_read_h1" 
    { PASCAL_SM_MIO_SM_STALLED_DUE_TO_PE_Q2, pascal_sm_mio_sm_stalled_due_to_pe_q2_enc_str_1, pascal_sm_mio_sm_stalled_due_to_pe_q2_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_sm_stalled_due_to_pe_q2_enc_str_3}, //"mio_sm_stalled_due_to_pe_q2" 
    { PASCAL_SM_MIO_SM_STALLED_DUE_TO_PE_Q3, pascal_sm_mio_sm_stalled_due_to_pe_q3_enc_str_1, pascal_sm_mio_sm_stalled_due_to_pe_q3_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_sm_stalled_due_to_pe_q3_enc_str_3}, //"mio_sm_stalled_due_to_pe_q3" 
    { PASCAL_SM_PE2MIO_ISBE_READ_REQ_H0, pascal_sm_pe2mio_isbe_read_req_h0_enc_str_1, pascal_sm_pe2mio_isbe_read_req_h0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pe2mio_isbe_read_req_h0_enc_str_3}, //"pe2mio_isbe_read_req_h0" 
    { PASCAL_SM_PE2MIO_ISBE_WRITE_REQ_H0, pascal_sm_pe2mio_isbe_write_req_h0_enc_str_1, pascal_sm_pe2mio_isbe_write_req_h0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pe2mio_isbe_write_req_h0_enc_str_3}, //"pe2mio_isbe_write_req_h0" 
    { PASCAL_SM_PE2MIO_TRAM_WRITE_H0, pascal_sm_pe2mio_tram_write_h0_enc_str_1, pascal_sm_pe2mio_tram_write_h0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pe2mio_tram_write_h0_enc_str_3}, //"pe2mio_tram_write_h0" 
    { PASCAL_SM_PE_ISBE_WR_DELAYED_DUE_TO_CAMPING_H0, pascal_sm_pe_isbe_wr_delayed_due_to_camping_h0_enc_str_1, pascal_sm_pe_isbe_wr_delayed_due_to_camping_h0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pe_isbe_wr_delayed_due_to_camping_h0_enc_str_3}, //"pe_isbe_wr_delayed_due_to_camping_h0" 
    { PASCAL_SM_PE_TRAM_WR_DELAYED_AND_LOST_THROUGHPUT_H0, pascal_sm_pe_tram_wr_delayed_and_lost_throughput_h0_enc_str_1, pascal_sm_pe_tram_wr_delayed_and_lost_throughput_h0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pe_tram_wr_delayed_and_lost_throughput_h0_enc_str_3}, //"pe_tram_wr_delayed_and_lost_throughput_h0" 
    { PASCAL_SM_PE_TRAM_WR_DELAYED_DUE_TO_CAMPING_H0, pascal_sm_pe_tram_wr_delayed_due_to_camping_h0_enc_str_1, pascal_sm_pe_tram_wr_delayed_due_to_camping_h0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pe_tram_wr_delayed_due_to_camping_h0_enc_str_3}, //"pe_tram_wr_delayed_due_to_camping_h0" 
    { PASCAL_SM_PE2MIO_ISBE_READ_REQ_H1, pascal_sm_pe2mio_isbe_read_req_h1_enc_str_1, pascal_sm_pe2mio_isbe_read_req_h1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pe2mio_isbe_read_req_h1_enc_str_3}, //"pe2mio_isbe_read_req_h1" 
    { PASCAL_SM_PE2MIO_ISBE_WRITE_REQ_H1, pascal_sm_pe2mio_isbe_write_req_h1_enc_str_1, pascal_sm_pe2mio_isbe_write_req_h1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pe2mio_isbe_write_req_h1_enc_str_3}, //"pe2mio_isbe_write_req_h1" 
    { PASCAL_SM_PE2MIO_TRAM_WRITE_H1, pascal_sm_pe2mio_tram_write_h1_enc_str_1, pascal_sm_pe2mio_tram_write_h1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pe2mio_tram_write_h1_enc_str_3}, //"pe2mio_tram_write_h1" 
    { PASCAL_SM_PE_ISBE_WR_DELAYED_DUE_TO_CAMPING_H1, pascal_sm_pe_isbe_wr_delayed_due_to_camping_h1_enc_str_1, pascal_sm_pe_isbe_wr_delayed_due_to_camping_h1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pe_isbe_wr_delayed_due_to_camping_h1_enc_str_3}, //"pe_isbe_wr_delayed_due_to_camping_h1" 
    { PASCAL_SM_PE_TRAM_WR_DELAYED_AND_LOST_THROUGHPUT_H1, pascal_sm_pe_tram_wr_delayed_and_lost_throughput_h1_enc_str_1, pascal_sm_pe_tram_wr_delayed_and_lost_throughput_h1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pe_tram_wr_delayed_and_lost_throughput_h1_enc_str_3}, //"pe_tram_wr_delayed_and_lost_throughput_h1" 
    { PASCAL_SM_PE_TRAM_WR_DELAYED_DUE_TO_CAMPING_H1, pascal_sm_pe_tram_wr_delayed_due_to_camping_h1_enc_str_1, pascal_sm_pe_tram_wr_delayed_due_to_camping_h1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pe_tram_wr_delayed_due_to_camping_h1_enc_str_3}, //"pe_tram_wr_delayed_due_to_camping_h1" 
    { PASCAL_SM_SMM2TEX_DATA_LG_COUNT_H0, pascal_sm_smm2tex_data_lg_count_h0_enc_str_1, pascal_sm_smm2tex_data_lg_count_h0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_smm2tex_data_lg_count_h0_enc_str_3}, //"smm2tex_data_lg_count_h0" 
    { PASCAL_SM_SMM2TEX_DATA_TEX_COUNT_H0, pascal_sm_smm2tex_data_tex_count_h0_enc_str_1, pascal_sm_smm2tex_data_tex_count_h0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_smm2tex_data_tex_count_h0_enc_str_3}, //"smm2tex_data_tex_count_h0" 
    { PASCAL_SM_SMM2TEX_DATA_LG_COUNT_H1, pascal_sm_smm2tex_data_lg_count_h1_enc_str_1, pascal_sm_smm2tex_data_lg_count_h1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_smm2tex_data_lg_count_h1_enc_str_3}, //"smm2tex_data_lg_count_h1" 
    { PASCAL_SM_SMM2TEX_DATA_TEX_COUNT_H1, pascal_sm_smm2tex_data_tex_count_h1_enc_str_1, pascal_sm_smm2tex_data_tex_count_h1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_smm2tex_data_tex_count_h1_enc_str_3}, //"smm2tex_data_tex_count_h1" 
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_ADU_OVER_SHM_Q0, pascal_sm_mio_cant_dispatch_lsu_adu_over_shm_q0_enc_str_1, pascal_sm_mio_cant_dispatch_lsu_adu_over_shm_q0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_cant_dispatch_lsu_adu_over_shm_q0_enc_str_3}, //"mio_cant_dispatch_lsu_adu_over_shm_q0" 
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_ADU_Q0, pascal_sm_mio_cant_dispatch_lsu_pixout_over_adu_q0_enc_str_1, pascal_sm_mio_cant_dispatch_lsu_pixout_over_adu_q0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_cant_dispatch_lsu_pixout_over_adu_q0_enc_str_3}, //"mio_cant_dispatch_lsu_pixout_over_adu_q0" 
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_SHM_Q0, pascal_sm_mio_cant_dispatch_lsu_pixout_over_shm_q0_enc_str_1, pascal_sm_mio_cant_dispatch_lsu_pixout_over_shm_q0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_cant_dispatch_lsu_pixout_over_shm_q0_enc_str_3}, //"mio_cant_dispatch_lsu_pixout_over_shm_q0" 
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_ADU_OVER_SHM_Q1, pascal_sm_mio_cant_dispatch_lsu_adu_over_shm_q1_enc_str_1, pascal_sm_mio_cant_dispatch_lsu_adu_over_shm_q1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_cant_dispatch_lsu_adu_over_shm_q1_enc_str_3}, //"mio_cant_dispatch_lsu_adu_over_shm_q1" 
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_ADU_Q1, pascal_sm_mio_cant_dispatch_lsu_pixout_over_adu_q1_enc_str_1, pascal_sm_mio_cant_dispatch_lsu_pixout_over_adu_q1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_cant_dispatch_lsu_pixout_over_adu_q1_enc_str_3}, //"mio_cant_dispatch_lsu_pixout_over_adu_q1" 
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_SHM_Q1, pascal_sm_mio_cant_dispatch_lsu_pixout_over_shm_q1_enc_str_1, pascal_sm_mio_cant_dispatch_lsu_pixout_over_shm_q1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_cant_dispatch_lsu_pixout_over_shm_q1_enc_str_3}, //"mio_cant_dispatch_lsu_pixout_over_shm_q1" 
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_ADU_OVER_SHM_Q2, pascal_sm_mio_cant_dispatch_lsu_adu_over_shm_q2_enc_str_1, pascal_sm_mio_cant_dispatch_lsu_adu_over_shm_q2_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_cant_dispatch_lsu_adu_over_shm_q2_enc_str_3}, //"mio_cant_dispatch_lsu_adu_over_shm_q2" 
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_ADU_Q2, pascal_sm_mio_cant_dispatch_lsu_pixout_over_adu_q2_enc_str_1, pascal_sm_mio_cant_dispatch_lsu_pixout_over_adu_q2_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_cant_dispatch_lsu_pixout_over_adu_q2_enc_str_3}, //"mio_cant_dispatch_lsu_pixout_over_adu_q2" 
    { PASCAL_SM_IDC_DIVERGENCE_REPLAY_Q2, pascal_sm_idc_divergence_replay_q2_enc_str_1, pascal_sm_idc_divergence_replay_q2_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_idc_divergence_replay_q2_enc_str_3}, //"idc_divergence_replay_q2" 
    { PASCAL_SM_IDC_DIVERGENT_INSTRUCTION_Q2, pascal_sm_idc_divergent_instruction_q2_enc_str_1, pascal_sm_idc_divergent_instruction_q2_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_idc_divergent_instruction_q2_enc_str_3}, //"idc_divergent_instruction_q2" 
    { PASCAL_SM_IDC_DIVERGENCE_REPLAY_Q3, pascal_sm_idc_divergence_replay_q3_enc_str_1, pascal_sm_idc_divergence_replay_q3_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_idc_divergence_replay_q3_enc_str_3}, //"idc_divergence_replay_q3" 
    { PASCAL_SM_IDC_DIVERGENT_INSTRUCTION_Q3, pascal_sm_idc_divergent_instruction_q3_enc_str_1, pascal_sm_idc_divergent_instruction_q3_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_idc_divergent_instruction_q3_enc_str_3}, //"idc_divergent_instruction_q3" 
    { PASCAL_SM_IDC_MISSES_OUTSTANDING, pascal_sm_idc_misses_outstanding_enc_str_1, pascal_sm_idc_misses_outstanding_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_idc_misses_outstanding_enc_str_3}, //"idc_misses_outstanding" 
    { PASCAL_SM_PQ_FULL_Q0, pascal_sm_pq_full_q0_enc_str_1, pascal_sm_pq_full_q0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_full_q0_enc_str_3}, //"pq_full_q0" 
    { PASCAL_SM_PQ_FULL_Q1, pascal_sm_pq_full_q1_enc_str_1, pascal_sm_pq_full_q1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_full_q1_enc_str_3}, //"pq_full_q1" 
    { PASCAL_SM_PIX_PQ_FULL_Q0, pascal_sm_pix_pq_full_q0_enc_str_1, pascal_sm_pix_pq_full_q0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pix_pq_full_q0_enc_str_3}, //"pix_pq_full_q0" 
    { PASCAL_SM_PIX_PQ_FULL_Q1, pascal_sm_pix_pq_full_q1_enc_str_1, pascal_sm_pix_pq_full_q1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pix_pq_full_q1_enc_str_3}, //"pix_pq_full_q1" 
    { PASCAL_SM_SHM_PQ_FULL_Q0, pascal_sm_shm_pq_full_q0_enc_str_1, pascal_sm_shm_pq_full_q0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_shm_pq_full_q0_enc_str_3}, //"shm_pq_full_q0" 
    { PASCAL_SM_SHM_PQ_FULL_Q1, pascal_sm_shm_pq_full_q1_enc_str_1, pascal_sm_shm_pq_full_q1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_shm_pq_full_q1_enc_str_3}, //"shm_pq_full_q1" 
    { PASCAL_SM_TEX_PQ_FULL_Q0, pascal_sm_tex_pq_full_q0_enc_str_1, pascal_sm_tex_pq_full_q0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_tex_pq_full_q0_enc_str_3}, //"tex_pq_full_q0" 
    { PASCAL_SM_TEX_PQ_FULL_Q1, pascal_sm_tex_pq_full_q1_enc_str_1, pascal_sm_tex_pq_full_q1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_tex_pq_full_q1_enc_str_3}, //"tex_pq_full_q1" 
    { PASCAL_SM_PQ_FULL_Q2, pascal_sm_pq_full_q2_enc_str_1, pascal_sm_pq_full_q2_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_full_q2_enc_str_3}, //"pq_full_q2" 
    { PASCAL_SM_PQ_FULL_Q3, pascal_sm_pq_full_q3_enc_str_1, pascal_sm_pq_full_q3_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_full_q3_enc_str_3}, //"pq_full_q3" 
    { PASCAL_SM_PIX_PQ_FULL_Q2, pascal_sm_pix_pq_full_q2_enc_str_1, pascal_sm_pix_pq_full_q2_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pix_pq_full_q2_enc_str_3}, //"pix_pq_full_q2" 
    { PASCAL_SM_PIX_PQ_FULL_Q3, pascal_sm_pix_pq_full_q3_enc_str_1, pascal_sm_pix_pq_full_q3_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pix_pq_full_q3_enc_str_3}, //"pix_pq_full_q3" 
    { PASCAL_SM_SHM_PQ_FULL_Q2, pascal_sm_shm_pq_full_q2_enc_str_1, pascal_sm_shm_pq_full_q2_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_shm_pq_full_q2_enc_str_3}, //"shm_pq_full_q2" 
    { PASCAL_SM_SHM_PQ_FULL_Q3, pascal_sm_shm_pq_full_q3_enc_str_1, pascal_sm_shm_pq_full_q3_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_shm_pq_full_q3_enc_str_3}, //"shm_pq_full_q3" 
    { PASCAL_SM_TEX_PQ_FULL_Q2, pascal_sm_tex_pq_full_q2_enc_str_1, pascal_sm_tex_pq_full_q2_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_tex_pq_full_q2_enc_str_3}, //"tex_pq_full_q2" 
    { PASCAL_SM_TEX_PQ_FULL_Q3, pascal_sm_tex_pq_full_q3_enc_str_1, pascal_sm_tex_pq_full_q3_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_tex_pq_full_q3_enc_str_3}, //"tex_pq_full_q3" 
    { PASCAL_SM_PQ_WRITE_BACK_LSU_STALL_H0, pascal_sm_pq_write_back_lsu_stall_h0_enc_str_1, pascal_sm_pq_write_back_lsu_stall_h0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_write_back_lsu_stall_h0_enc_str_3}, //"pq_write_back_lsu_stall_h0" 
    { PASCAL_SM_PQ_WRITE_BACK_TEX_STALL_H0, pascal_sm_pq_write_back_tex_stall_h0_enc_str_1, pascal_sm_pq_write_back_tex_stall_h0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_write_back_tex_stall_h0_enc_str_3}, //"pq_write_back_tex_stall_h0" 
    { PASCAL_SM_PQ_WRITE_BACK_LSU_STALL_H1, pascal_sm_pq_write_back_lsu_stall_h1_enc_str_1, pascal_sm_pq_write_back_lsu_stall_h1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_write_back_lsu_stall_h1_enc_str_3}, //"pq_write_back_lsu_stall_h1" 
    { PASCAL_SM_PQ_WRITE_BACK_TEX_STALL_H1, pascal_sm_pq_write_back_tex_stall_h1_enc_str_1, pascal_sm_pq_write_back_tex_stall_h1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_write_back_tex_stall_h1_enc_str_3}, //"pq_write_back_tex_stall_h1" 
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_SHM_Q2, pascal_sm_mio_cant_dispatch_lsu_pixout_over_shm_q2_enc_str_1, pascal_sm_mio_cant_dispatch_lsu_pixout_over_shm_q2_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_cant_dispatch_lsu_pixout_over_shm_q2_enc_str_3}, //"mio_cant_dispatch_lsu_pixout_over_shm_q2" 
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_ADU_OVER_SHM_Q3, pascal_sm_mio_cant_dispatch_lsu_adu_over_shm_q3_enc_str_1, pascal_sm_mio_cant_dispatch_lsu_adu_over_shm_q3_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_cant_dispatch_lsu_adu_over_shm_q3_enc_str_3}, //"mio_cant_dispatch_lsu_adu_over_shm_q3" 
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_ADU_Q3, pascal_sm_mio_cant_dispatch_lsu_pixout_over_adu_q3_enc_str_1, pascal_sm_mio_cant_dispatch_lsu_pixout_over_adu_q3_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_cant_dispatch_lsu_pixout_over_adu_q3_enc_str_3}, //"mio_cant_dispatch_lsu_pixout_over_adu_q3" 
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_SHM_Q3, pascal_sm_mio_cant_dispatch_lsu_pixout_over_shm_q3_enc_str_1, pascal_sm_mio_cant_dispatch_lsu_pixout_over_shm_q3_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_cant_dispatch_lsu_pixout_over_shm_q3_enc_str_3}, //"mio_cant_dispatch_lsu_pixout_over_shm_q3" 
    { PASCAL_SM_LSU_IQ_FIFO_FULL_Q0, pascal_sm_lsu_iq_fifo_full_q0_enc_str_1, pascal_sm_lsu_iq_fifo_full_q0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_lsu_iq_fifo_full_q0_enc_str_3}, //"lsu_iq_fifo_full_q0" 
    { PASCAL_SM_TEX_IQ_FIFO_FULL_Q0, pascal_sm_tex_iq_fifo_full_q0_enc_str_1, pascal_sm_tex_iq_fifo_full_q0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_tex_iq_fifo_full_q0_enc_str_3}, //"tex_iq_fifo_full_q0" 
    { PASCAL_SM_PIX_IQ_FIFO_FULL_Q0, pascal_sm_pix_iq_fifo_full_q0_enc_str_1, pascal_sm_pix_iq_fifo_full_q0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pix_iq_fifo_full_q0_enc_str_3}, //"pix_iq_fifo_full_q0" 
    { PASCAL_SM_RTY_IQ_FIFO_FULL_Q0, pascal_sm_rty_iq_fifo_full_q0_enc_str_1, pascal_sm_rty_iq_fifo_full_q0_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_rty_iq_fifo_full_q0_enc_str_3}, //"rty_iq_fifo_full_q0" 
    { PASCAL_SM_LSU_IQ_FIFO_FULL_Q1, pascal_sm_lsu_iq_fifo_full_q1_enc_str_1, pascal_sm_lsu_iq_fifo_full_q1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_lsu_iq_fifo_full_q1_enc_str_3}, //"lsu_iq_fifo_full_q1" 
    { PASCAL_SM_TEX_IQ_FIFO_FULL_Q1, pascal_sm_tex_iq_fifo_full_q1_enc_str_1, pascal_sm_tex_iq_fifo_full_q1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_tex_iq_fifo_full_q1_enc_str_3}, //"tex_iq_fifo_full_q1" 
    { PASCAL_SM_PIX_IQ_FIFO_FULL_Q1, pascal_sm_pix_iq_fifo_full_q1_enc_str_1, pascal_sm_pix_iq_fifo_full_q1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pix_iq_fifo_full_q1_enc_str_3}, //"pix_iq_fifo_full_q1" 
    { PASCAL_SM_RTY_IQ_FIFO_FULL_Q1, pascal_sm_rty_iq_fifo_full_q1_enc_str_1, pascal_sm_rty_iq_fifo_full_q1_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_rty_iq_fifo_full_q1_enc_str_3}, //"rty_iq_fifo_full_q1" 
    { PASCAL_SM_LSU_IQ_FIFO_FULL_Q2, pascal_sm_lsu_iq_fifo_full_q2_enc_str_1, pascal_sm_lsu_iq_fifo_full_q2_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_lsu_iq_fifo_full_q2_enc_str_3}, //"lsu_iq_fifo_full_q2" 
    { PASCAL_SM_TEX_IQ_FIFO_FULL_Q2, pascal_sm_tex_iq_fifo_full_q2_enc_str_1, pascal_sm_tex_iq_fifo_full_q2_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_tex_iq_fifo_full_q2_enc_str_3}, //"tex_iq_fifo_full_q2" 
    { PASCAL_SM_PIX_IQ_FIFO_FULL_Q2, pascal_sm_pix_iq_fifo_full_q2_enc_str_1, pascal_sm_pix_iq_fifo_full_q2_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pix_iq_fifo_full_q2_enc_str_3}, //"pix_iq_fifo_full_q2" 
    { PASCAL_SM_RTY_IQ_FIFO_FULL_Q2, pascal_sm_rty_iq_fifo_full_q2_enc_str_1, pascal_sm_rty_iq_fifo_full_q2_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_rty_iq_fifo_full_q2_enc_str_3}, //"rty_iq_fifo_full_q2" 
    { PASCAL_SM_LSU_IQ_FIFO_FULL_Q3, pascal_sm_lsu_iq_fifo_full_q3_enc_str_1, pascal_sm_lsu_iq_fifo_full_q3_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_lsu_iq_fifo_full_q3_enc_str_3}, //"lsu_iq_fifo_full_q3" 
    { PASCAL_SM_TEX_IQ_FIFO_FULL_Q3, pascal_sm_tex_iq_fifo_full_q3_enc_str_1, pascal_sm_tex_iq_fifo_full_q3_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_tex_iq_fifo_full_q3_enc_str_3}, //"tex_iq_fifo_full_q3" 
    { PASCAL_SM_PIX_IQ_FIFO_FULL_Q3, pascal_sm_pix_iq_fifo_full_q3_enc_str_1, pascal_sm_pix_iq_fifo_full_q3_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pix_iq_fifo_full_q3_enc_str_3}, //"pix_iq_fifo_full_q3" 
    { PASCAL_SM_RTY_IQ_FIFO_FULL_Q3, pascal_sm_rty_iq_fifo_full_q3_enc_str_1, pascal_sm_rty_iq_fifo_full_q3_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_rty_iq_fifo_full_q3_enc_str_3}, //"rty_iq_fifo_full_q3" 

    { PASCAL_HWPM_UNIQUE_WARPS_LAUNCHED_Q0, pascal_hwpm_unique_warps_launched_q0_enc_str_1, pascal_hwpm_unique_warps_launched_q0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_unique_warps_launched_q0_enc_str_1},
    { PASCAL_HWPM_UNIQUE_WARPS_LAUNCHED_Q1, pascal_hwpm_unique_warps_launched_q1_enc_str_1, pascal_hwpm_unique_warps_launched_q1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_unique_warps_launched_q1_enc_str_1},
    { PASCAL_HWPM_UNIQUE_WARPS_LAUNCHED_Q2, pascal_hwpm_unique_warps_launched_q2_enc_str_1, pascal_hwpm_unique_warps_launched_q2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_unique_warps_launched_q2_enc_str_1},
    { PASCAL_HWPM_UNIQUE_WARPS_LAUNCHED_Q3, pascal_hwpm_unique_warps_launched_q3_enc_str_1, pascal_hwpm_unique_warps_launched_q3_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_unique_warps_launched_q3_enc_str_1},
    { PASCAL_TEX0_STORE_SECTOR_MISSES_GLOBAL,           pascal_tex0_store_sector_misses_global_enc_str_1,           pascal_tex0_store_sector_misses_global_enc_str_1,           CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_store_sector_misses_global_enc_str_1          },
    { PASCAL_TEX1_STORE_SECTOR_MISSES_GLOBAL,           pascal_tex1_store_sector_misses_global_enc_str_1,           pascal_tex1_store_sector_misses_global_enc_str_1,           CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_store_sector_misses_global_enc_str_1          },
    { PASCAL_TEX0_STORE_SECTOR_MISSES_LOCAL,            pascal_tex0_store_sector_misses_local_enc_str_1,            pascal_tex0_store_sector_misses_local_enc_str_1,            CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_store_sector_misses_local_enc_str_1           },
    { PASCAL_TEX1_STORE_SECTOR_MISSES_LOCAL,            pascal_tex1_store_sector_misses_local_enc_str_1,            pascal_tex1_store_sector_misses_local_enc_str_1,            CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_store_sector_misses_local_enc_str_1           },
    { PASCAL_TEX0_STORE_SECTOR_MISSES_SUST,             pascal_tex0_store_sector_misses_sust_enc_str_1,             pascal_tex0_store_sector_misses_sust_enc_str_1,             CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_store_sector_misses_sust_enc_str_1            },
    { PASCAL_TEX1_STORE_SECTOR_MISSES_SUST,             pascal_tex1_store_sector_misses_sust_enc_str_1,             pascal_tex1_store_sector_misses_sust_enc_str_1,             CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_store_sector_misses_sust_enc_str_1            },
    { PASCAL_TEX0_STORE_SECTOR_MISSES_ATOM_OR_ATOM_CAS, pascal_tex0_store_sector_misses_atom_or_atom_cas_enc_str_1, pascal_tex0_store_sector_misses_atom_or_atom_cas_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_store_sector_misses_atom_or_atom_cas_enc_str_1},
    { PASCAL_TEX1_STORE_SECTOR_MISSES_ATOM_OR_ATOM_CAS, pascal_tex1_store_sector_misses_atom_or_atom_cas_enc_str_1, pascal_tex1_store_sector_misses_atom_or_atom_cas_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_store_sector_misses_atom_or_atom_cas_enc_str_1},
    { PASCAL_TEX0_STORE_SECTOR_MISSES_RED,              pascal_tex0_store_sector_misses_red_enc_str_1,              pascal_tex0_store_sector_misses_red_enc_str_1,              CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_store_sector_misses_red_enc_str_1             },
    { PASCAL_TEX1_STORE_SECTOR_MISSES_RED,              pascal_tex1_store_sector_misses_red_enc_str_1,              pascal_tex1_store_sector_misses_red_enc_str_1,              CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_store_sector_misses_red_enc_str_1             },
    { PASCAL_TEX0_STORE_SECTOR_MISSES_SUST_NONATOM,     pascal_tex0_store_sector_misses_sust_nonatom_enc_str_1,     pascal_tex0_store_sector_misses_sust_nonatom_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_store_sector_misses_sust_nonatom_enc_str_1    },
    { PASCAL_TEX1_STORE_SECTOR_MISSES_SUST_NONATOM,     pascal_tex1_store_sector_misses_sust_nonatom_enc_str_1,     pascal_tex1_store_sector_misses_sust_nonatom_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_store_sector_misses_sust_nonatom_enc_str_1    },
    { PASCAL_TEX0_STORE_SECTOR_MISSES_SUST_ATOM_OR_ATOM_CAS,     pascal_tex0_store_sector_misses_sust_atom_or_atom_cas_enc_str_1,     pascal_tex0_store_sector_misses_sust_atom_or_atom_cas_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_store_sector_misses_sust_atom_or_atom_cas_enc_str_1    },
    { PASCAL_TEX1_STORE_SECTOR_MISSES_SUST_ATOM_OR_ATOM_CAS,     pascal_tex1_store_sector_misses_sust_atom_or_atom_cas_enc_str_1,     pascal_tex1_store_sector_misses_sust_atom_or_atom_cas_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_store_sector_misses_sust_atom_or_atom_cas_enc_str_1    },
    { PASCAL_TEX0_STORE_SECTOR_MISSES_SUST_RED,     pascal_tex0_store_sector_misses_sust_red_enc_str_1,     pascal_tex0_store_sector_misses_sust_red_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_store_sector_misses_sust_red_enc_str_1    },
    { PASCAL_TEX1_STORE_SECTOR_MISSES_SUST_RED,     pascal_tex1_store_sector_misses_sust_red_enc_str_1,     pascal_tex1_store_sector_misses_sust_red_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_store_sector_misses_sust_red_enc_str_1    },
    { PASCAL_TEX0_WRITE_SECTORS_GLOBAL_NONATOM, pascal_tex0_write_sectors_global_nonatom_enc_str_1, pascal_tex0_write_sectors_global_nonatom_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_write_sectors_global_nonatom_enc_str_1},
    { PASCAL_TEX1_WRITE_SECTORS_GLOBAL_NONATOM, pascal_tex1_write_sectors_global_nonatom_enc_str_1, pascal_tex1_write_sectors_global_nonatom_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_write_sectors_global_nonatom_enc_str_1},
    { PASCAL_TEX0_WRITE_SECTORS_GLOBAL_ATOM, pascal_tex0_write_sectors_global_atom_enc_str_1, pascal_tex0_write_sectors_global_atom_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_write_sectors_global_atom_enc_str_1},
    { PASCAL_TEX1_WRITE_SECTORS_GLOBAL_ATOM, pascal_tex1_write_sectors_global_atom_enc_str_1, pascal_tex1_write_sectors_global_atom_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_write_sectors_global_atom_enc_str_1},
    { PASCAL_TEX0_WRITE_SECTORS_GLOBAL_RED, pascal_tex0_write_sectors_global_red_enc_str_1, pascal_tex0_write_sectors_global_red_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_write_sectors_global_red_enc_str_1},
    { PASCAL_TEX1_WRITE_SECTORS_GLOBAL_RED, pascal_tex1_write_sectors_global_red_enc_str_1, pascal_tex1_write_sectors_global_red_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_write_sectors_global_red_enc_str_1},
    { PASCAL_TEX0_WRITE_SECTORS_LOCAL_ST, pascal_tex0_write_sectors_local_st_enc_str_1, pascal_tex0_write_sectors_local_st_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_write_sectors_local_st_enc_str_1},
    { PASCAL_TEX1_WRITE_SECTORS_LOCAL_ST, pascal_tex1_write_sectors_local_st_enc_str_1, pascal_tex1_write_sectors_local_st_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_write_sectors_local_st_enc_str_1},


    { PASCAL_TEX0_INPUT_ST_SECTOR_SUM,  pascal_tex0_input_st_sector_sum_enc_str_1, pascal_tex0_input_st_sector_sum_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_input_st_sector_sum_enc_str_1},
    { PASCAL_TEX1_INPUT_ST_SECTOR_SUM,  pascal_tex1_input_st_sector_sum_enc_str_1, pascal_tex1_input_st_sector_sum_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_input_st_sector_sum_enc_str_1},
    { PASCAL_TEX0_INPUT_WR_SECTOR_SUM,  pascal_tex0_input_wr_sector_sum_enc_str_1, pascal_tex0_input_wr_sector_sum_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_input_wr_sector_sum_enc_str_1},
    { PASCAL_TEX1_INPUT_WR_SECTOR_SUM,  pascal_tex1_input_wr_sector_sum_enc_str_1, pascal_tex1_input_wr_sector_sum_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_input_wr_sector_sum_enc_str_1},
    { PASCAL_TEX0_OUTPUT_ST_SECTOR_SUM, pascal_tex0_output_st_sector_sum_enc_str_1, pascal_tex0_output_st_sector_sum_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_output_st_sector_sum_enc_str_1},
    { PASCAL_TEX1_OUTPUT_ST_SECTOR_SUM, pascal_tex1_output_st_sector_sum_enc_str_1, pascal_tex1_output_st_sector_sum_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_output_st_sector_sum_enc_str_1},
    { PASCAL_TEX0_OUTPUT_WR_SECTOR_SUM, pascal_tex0_output_wr_sector_sum_enc_str_1, pascal_tex0_output_wr_sector_sum_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_output_wr_sector_sum_enc_str_1},
    { PASCAL_TEX1_OUTPUT_WR_SECTOR_SUM, pascal_tex1_output_wr_sector_sum_enc_str_1, pascal_tex1_output_wr_sector_sum_enc_str_1,CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_output_wr_sector_sum_enc_str_1},
    { PASCAL_TEX0_RETURN_PACKET_COUNT, pascal_tex0_return_packet_count_enc_str_1, pascal_tex0_return_packet_count_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_return_packet_count_enc_str_4},
    { PASCAL_TEX1_RETURN_PACKET_COUNT, pascal_tex1_return_packet_count_enc_str_1, pascal_tex1_return_packet_count_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_return_packet_count_enc_str_4},
    { PASCAL_MMU_GPCL2_TLB_HIT,  pascal_mmu_gpcl2_tlb_hit_enc_str_1, pascal_mmu_gpcl2_tlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_gpcl2_tlb_hit_enc_str_2},
    { PASCAL_MMU_GPCL2_TLB_MISS,  pascal_mmu_gpcl2_tlb_miss_enc_str_1, pascal_mmu_gpcl2_tlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_gpcl2_tlb_miss_enc_str_2},
    { PASCAL_PROFILER_FIRST,  pascal_profiler_first_enc_str_1, pascal_profiler_first_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_profiler_first_enc_str_2},
    { PASCAL_PROFILER_VALID,  pascal_profiler_valid_enc_str_1, pascal_profiler_valid_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_profiler_valid_enc_str_2},
    { PASCAL_TEX0_STORE_SECTOR_MISSES_ATOM_CAS, pascal_tex0_store_sector_misses_atom_cas_enc_str_1, pascal_tex0_store_sector_misses_atom_cas_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_store_sector_misses_atom_cas_enc_str_1},
    { PASCAL_TEX1_STORE_SECTOR_MISSES_ATOM_CAS, pascal_tex1_store_sector_misses_atom_cas_enc_str_1, pascal_tex1_store_sector_misses_atom_cas_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_store_sector_misses_atom_cas_enc_str_1},
    { PASCAL_TEX0_STORE_SECTOR_MISSES_ATOM, pascal_tex0_store_sector_misses_atom_enc_str_1, pascal_tex0_store_sector_misses_atom_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_store_sector_misses_atom_enc_str_1},
    { PASCAL_TEX1_STORE_SECTOR_MISSES_ATOM, pascal_tex1_store_sector_misses_atom_enc_str_1, pascal_tex1_store_sector_misses_atom_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_store_sector_misses_atom_enc_str_1},
    { PASCAL_TEX0_LOAD_SECTOR_MISSES_GLOBAL, pascal_tex0_load_sector_misses_global_enc_str_1, pascal_tex0_load_sector_misses_global_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_load_sector_misses_global_enc_str_1},
    { PASCAL_TEX1_LOAD_SECTOR_MISSES_GLOBAL, pascal_tex1_load_sector_misses_global_enc_str_1, pascal_tex1_load_sector_misses_global_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_load_sector_misses_global_enc_str_1},
    { PASCAL_TEX0_LOAD_SECTOR_MISSES_LOCAL, pascal_tex0_load_sector_misses_local_enc_str_1, pascal_tex0_load_sector_misses_local_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_load_sector_misses_local_enc_str_1},
    { PASCAL_TEX1_LOAD_SECTOR_MISSES_LOCAL, pascal_tex1_load_sector_misses_local_enc_str_1, pascal_tex1_load_sector_misses_local_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_load_sector_misses_local_enc_str_1},
    { PASCAL_TEX0_LOAD_SECTOR_MISSES_ATOM, pascal_tex0_load_sector_misses_atom_enc_str_1, pascal_tex0_load_sector_misses_atom_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_load_sector_misses_atom_enc_str_1},
    { PASCAL_TEX1_LOAD_SECTOR_MISSES_ATOM, pascal_tex1_load_sector_misses_atom_enc_str_1, pascal_tex1_load_sector_misses_atom_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_load_sector_misses_atom_enc_str_1},
    { PASCAL_TEX0_LOAD_SECTOR_MISSES_ATOM_CAS, pascal_tex0_load_sector_misses_atom_cas_enc_str_1, pascal_tex0_load_sector_misses_atom_cas_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_load_sector_misses_atom_cas_enc_str_1},
    { PASCAL_TEX1_LOAD_SECTOR_MISSES_ATOM_CAS, pascal_tex1_load_sector_misses_atom_cas_enc_str_1, pascal_tex1_load_sector_misses_atom_cas_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_load_sector_misses_atom_cas_enc_str_1},
    { PASCAL_TEX0_OUTPUT_RD_SECTOR_SUM, pascal_tex0_output_rd_sector_sum_enc_str_1, pascal_tex0_output_rd_sector_sum_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_output_rd_sector_sum_enc_str_1},
    { PASCAL_TEX1_OUTPUT_RD_SECTOR_SUM, pascal_tex1_output_rd_sector_sum_enc_str_1, pascal_tex0_output_rd_sector_sum_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_output_rd_sector_sum_enc_str_1},

    {PASCAL_TEX0_GLOBAL_LD_REQUESTS_4B, pascal_tex0_global_ld_requests_4b_enc_str_1, pascal_tex0_global_ld_requests_4b_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_ld_requests_4b_enc_str_1},
    {PASCAL_TEX1_GLOBAL_LD_REQUESTS_4B, pascal_tex1_global_ld_requests_4b_enc_str_1, pascal_tex1_global_ld_requests_4b_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_ld_requests_4b_enc_str_1},
    {PASCAL_TEX0_NUM_8_BIT_4B, pascal_tex0_num_8_bit_4b_enc_str_1, pascal_tex0_num_8_bit_4b_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_8_bit_4b_enc_str_1},
    {PASCAL_TEX1_NUM_8_BIT_4B, pascal_tex1_num_8_bit_4b_enc_str_1, pascal_tex1_num_8_bit_4b_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_8_bit_4b_enc_str_1},
    {PASCAL_TEX0_NUM_16_BIT_4B, pascal_tex0_num_16_bit_4b_enc_str_1, pascal_tex0_num_16_bit_4b_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_16_bit_4b_enc_str_1},
    {PASCAL_TEX1_NUM_16_BIT_4B, pascal_tex1_num_16_bit_4b_enc_str_1, pascal_tex1_num_16_bit_4b_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_16_bit_4b_enc_str_1},
    {PASCAL_TEX0_NUM_FP16X2_4B, pascal_tex0_num_fp16x2_4b_enc_str_1, pascal_tex0_num_fp16x2_4b_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_fp16x2_4b_enc_str_1},
    {PASCAL_TEX1_NUM_FP16X2_4B, pascal_tex1_num_fp16x2_4b_enc_str_1, pascal_tex1_num_fp16x2_4b_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_fp16x2_4b_enc_str_1},

    {PASCAL_TEX0_GLOBAL_LD_REQUESTS_4C, pascal_tex0_global_ld_requests_4c_enc_str_1, pascal_tex0_global_ld_requests_4c_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_ld_requests_4c_enc_str_1},
    {PASCAL_TEX1_GLOBAL_LD_REQUESTS_4C, pascal_tex1_global_ld_requests_4c_enc_str_1, pascal_tex1_global_ld_requests_4c_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_ld_requests_4c_enc_str_1},
    {PASCAL_TEX0_NUM_32_BIT_4C, pascal_tex0_num_32_bit_4c_enc_str_1, pascal_tex0_num_32_bit_4c_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_32_bit_4c_enc_str_1},
    {PASCAL_TEX1_NUM_32_BIT_4C, pascal_tex1_num_32_bit_4c_enc_str_1, pascal_tex1_num_32_bit_4c_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_32_bit_4c_enc_str_1},
    {PASCAL_TEX0_NUM_64_BIT_4C, pascal_tex0_num_64_bit_4c_enc_str_1, pascal_tex0_num_64_bit_4c_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_64_bit_4c_enc_str_1},
    {PASCAL_TEX1_NUM_64_BIT_4C, pascal_tex1_num_64_bit_4c_enc_str_1, pascal_tex1_num_64_bit_4c_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_64_bit_4c_enc_str_1},
    {PASCAL_TEX0_NUM_128_BIT_4C, pascal_tex0_num_128_bit_4c_enc_str_1, pascal_tex0_num_128_bit_4c_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_128_bit_4c_enc_str_1},
    {PASCAL_TEX1_NUM_128_BIT_4C, pascal_tex1_num_128_bit_4c_enc_str_1, pascal_tex1_num_128_bit_4c_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_128_bit_4c_enc_str_1},

    {PASCAL_TEX0_GLOBAL_ST_REQUESTS_51, pascal_tex0_global_st_requests_51_enc_str_1, pascal_tex0_global_st_requests_51_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_st_requests_51_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ST_REQUESTS_51, pascal_tex1_global_st_requests_51_enc_str_1, pascal_tex1_global_st_requests_51_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_st_requests_51_enc_str_1},
    {PASCAL_TEX0_NUM_8_BIT_51, pascal_tex0_num_8_bit_51_enc_str_1, pascal_tex0_num_8_bit_51_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_8_bit_51_enc_str_1},
    {PASCAL_TEX1_NUM_8_BIT_51, pascal_tex1_num_8_bit_51_enc_str_1, pascal_tex1_num_8_bit_51_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_8_bit_51_enc_str_1},
    {PASCAL_TEX0_NUM_16_BIT_51, pascal_tex0_num_16_bit_51_enc_str_1, pascal_tex0_num_16_bit_51_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_16_bit_51_enc_str_1},
    {PASCAL_TEX1_NUM_16_BIT_51, pascal_tex1_num_16_bit_51_enc_str_1, pascal_tex1_num_16_bit_51_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_16_bit_51_enc_str_1},
    {PASCAL_TEX0_NUM_FP16X2_51, pascal_tex0_num_fp16x2_51_enc_str_1, pascal_tex0_num_fp16x2_51_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_fp16x2_51_enc_str_1},
    {PASCAL_TEX1_NUM_FP16X2_51, pascal_tex1_num_fp16x2_51_enc_str_1, pascal_tex1_num_fp16x2_51_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_fp16x2_51_enc_str_1},

    {PASCAL_TEX0_GLOBAL_ST_REQUESTS_52, pascal_tex0_global_st_requests_52_enc_str_1, pascal_tex0_global_st_requests_52_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_st_requests_52_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ST_REQUESTS_52, pascal_tex1_global_st_requests_52_enc_str_1, pascal_tex1_global_st_requests_52_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_st_requests_52_enc_str_1},
    {PASCAL_TEX0_NUM_32_BIT_52, pascal_tex0_num_32_bit_52_enc_str_1, pascal_tex0_num_32_bit_52_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_32_bit_52_enc_str_1},
    {PASCAL_TEX1_NUM_32_BIT_52, pascal_tex1_num_32_bit_52_enc_str_1, pascal_tex1_num_32_bit_52_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_32_bit_52_enc_str_1},
    {PASCAL_TEX0_NUM_64_BIT_52, pascal_tex0_num_64_bit_52_enc_str_1, pascal_tex0_num_64_bit_52_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_64_bit_52_enc_str_1},
    {PASCAL_TEX1_NUM_64_BIT_52, pascal_tex1_num_64_bit_52_enc_str_1, pascal_tex1_num_64_bit_52_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_64_bit_52_enc_str_1},
    {PASCAL_TEX0_NUM_128_BIT_52, pascal_tex0_num_128_bit_52_enc_str_1, pascal_tex0_num_128_bit_52_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_128_bit_52_enc_str_1},
    {PASCAL_TEX1_NUM_128_BIT_52, pascal_tex1_num_128_bit_52_enc_str_1, pascal_tex1_num_128_bit_52_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_128_bit_52_enc_str_1},

    {PASCAL_TEX0_GLOBAL_ATOM_REQUESTS_59, pascal_tex0_global_atom_requests_59_enc_str_1, pascal_tex0_global_atom_requests_59_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_atom_requests_59_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ATOM_REQUESTS_59, pascal_tex1_global_atom_requests_59_enc_str_1, pascal_tex1_global_atom_requests_59_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_atom_requests_59_enc_str_1},
    {PASCAL_TEX0_NUM_8_BIT_59, pascal_tex0_num_8_bit_59_enc_str_1, pascal_tex0_num_8_bit_59_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_8_bit_59_enc_str_1},
    {PASCAL_TEX1_NUM_8_BIT_59, pascal_tex1_num_8_bit_59_enc_str_1, pascal_tex1_num_8_bit_59_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_8_bit_59_enc_str_1},
    {PASCAL_TEX0_NUM_16_BIT_59, pascal_tex0_num_16_bit_59_enc_str_1, pascal_tex0_num_16_bit_59_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_16_bit_59_enc_str_1},
    {PASCAL_TEX1_NUM_16_BIT_59, pascal_tex1_num_16_bit_59_enc_str_1, pascal_tex1_num_16_bit_59_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_16_bit_59_enc_str_1},
    {PASCAL_TEX0_NUM_FP16X2_59, pascal_tex0_num_fp16x2_59_enc_str_1, pascal_tex0_num_fp16x2_59_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_fp16x2_59_enc_str_1},
    {PASCAL_TEX1_NUM_FP16X2_59, pascal_tex1_num_fp16x2_59_enc_str_1, pascal_tex1_num_fp16x2_59_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_fp16x2_59_enc_str_1},

    {PASCAL_TEX0_GLOBAL_ATOM_REQUESTS_5A, pascal_tex0_global_atom_requests_5a_enc_str_1, pascal_tex0_global_atom_requests_5a_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_atom_requests_5a_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ATOM_REQUESTS_5A, pascal_tex1_global_atom_requests_5a_enc_str_1, pascal_tex1_global_atom_requests_5a_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_atom_requests_5a_enc_str_1},
    {PASCAL_TEX0_NUM_32_BIT_5A, pascal_tex0_num_32_bit_5a_enc_str_1, pascal_tex0_num_32_bit_5a_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_32_bit_5a_enc_str_1},
    {PASCAL_TEX1_NUM_32_BIT_5A, pascal_tex1_num_32_bit_5a_enc_str_1, pascal_tex1_num_32_bit_5a_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_32_bit_5a_enc_str_1},
    {PASCAL_TEX0_NUM_64_BIT_5A, pascal_tex0_num_64_bit_5a_enc_str_1, pascal_tex0_num_64_bit_5a_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_64_bit_5a_enc_str_1},
    {PASCAL_TEX1_NUM_64_BIT_5A, pascal_tex1_num_64_bit_5a_enc_str_1, pascal_tex1_num_64_bit_5a_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_64_bit_5a_enc_str_1},
    {PASCAL_TEX0_NUM_128_BIT_5A, pascal_tex0_num_128_bit_5a_enc_str_1, pascal_tex0_num_128_bit_5a_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_128_bit_5a_enc_str_1},
    {PASCAL_TEX1_NUM_128_BIT_5A, pascal_tex1_num_128_bit_5a_enc_str_1, pascal_tex1_num_128_bit_5a_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_128_bit_5a_enc_str_1},

    {PASCAL_TEX0_GLOBAL_ATOM_FP16X2_REQUESTS_5B, pascal_tex0_global_atom_fp16x2_requests_5b_enc_str_1, pascal_tex0_global_atom_fp16x2_requests_5b_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_atom_fp16x2_requests_5b_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ATOM_FP16X2_REQUESTS_5B, pascal_tex1_global_atom_fp16x2_requests_5b_enc_str_1, pascal_tex1_global_atom_fp16x2_requests_5b_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_atom_fp16x2_requests_5b_enc_str_1},
    {PASCAL_TEX0_NUM_8_BIT_5B, pascal_tex0_num_8_bit_5b_enc_str_1, pascal_tex0_num_8_bit_5b_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_8_bit_5b_enc_str_1},
    {PASCAL_TEX1_NUM_8_BIT_5B, pascal_tex1_num_8_bit_5b_enc_str_1, pascal_tex1_num_8_bit_5b_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_8_bit_5b_enc_str_1},
    {PASCAL_TEX0_NUM_16_BIT_5B, pascal_tex0_num_16_bit_5b_enc_str_1, pascal_tex0_num_16_bit_5b_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_16_bit_5b_enc_str_1},
    {PASCAL_TEX1_NUM_16_BIT_5B, pascal_tex1_num_16_bit_5b_enc_str_1, pascal_tex1_num_16_bit_5b_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_16_bit_5b_enc_str_1},
    {PASCAL_TEX0_NUM_FP16X2_5B, pascal_tex0_num_fp16x2_5b_enc_str_1, pascal_tex0_num_fp16x2_5b_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_fp16x2_5b_enc_str_1},
    {PASCAL_TEX1_NUM_FP16X2_5B, pascal_tex1_num_fp16x2_5b_enc_str_1, pascal_tex1_num_fp16x2_5b_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_fp16x2_5b_enc_str_1},

    {PASCAL_TEX0_GLOBAL_ATOM_FP16X2_REQUESTS_5C, pascal_tex0_global_atom_fp16x2_requests_5c_enc_str_1, pascal_tex0_global_atom_fp16x2_requests_5c_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_atom_fp16x2_requests_5c_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ATOM_FP16X2_REQUESTS_5C, pascal_tex1_global_atom_fp16x2_requests_5c_enc_str_1, pascal_tex1_global_atom_fp16x2_requests_5c_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_atom_fp16x2_requests_5c_enc_str_1},
    {PASCAL_TEX0_NUM_32_BIT_5C, pascal_tex0_num_32_bit_5c_enc_str_1, pascal_tex0_num_32_bit_5c_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_32_bit_5c_enc_str_1},
    {PASCAL_TEX1_NUM_32_BIT_5C, pascal_tex1_num_32_bit_5c_enc_str_1, pascal_tex1_num_32_bit_5c_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_32_bit_5c_enc_str_1},
    {PASCAL_TEX0_NUM_64_BIT_5C, pascal_tex0_num_64_bit_5c_enc_str_1, pascal_tex0_num_64_bit_5c_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_64_bit_5c_enc_str_1},
    {PASCAL_TEX1_NUM_64_BIT_5C, pascal_tex1_num_64_bit_5c_enc_str_1, pascal_tex1_num_64_bit_5c_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_64_bit_5c_enc_str_1},
    {PASCAL_TEX0_NUM_128_BIT_5C, pascal_tex0_num_128_bit_5c_enc_str_1, pascal_tex0_num_128_bit_5c_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_128_bit_5c_enc_str_1},
    {PASCAL_TEX1_NUM_128_BIT_5C, pascal_tex1_num_128_bit_5c_enc_str_1, pascal_tex1_num_128_bit_5c_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_128_bit_5c_enc_str_1},

    {PASCAL_TEX0_GLOBAL_ATOM_CAS_REQUESTS_5D, pascal_tex0_global_atom_cas_requests_5d_enc_str_1, pascal_tex0_global_atom_cas_requests_5d_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_atom_cas_requests_5d_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ATOM_CAS_REQUESTS_5D, pascal_tex1_global_atom_cas_requests_5d_enc_str_1, pascal_tex1_global_atom_cas_requests_5d_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_atom_cas_requests_5d_enc_str_1},
    {PASCAL_TEX0_NUM_8_BIT_5D, pascal_tex0_num_8_bit_5d_enc_str_1, pascal_tex0_num_8_bit_5d_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_8_bit_5d_enc_str_1},
    {PASCAL_TEX1_NUM_8_BIT_5D, pascal_tex1_num_8_bit_5d_enc_str_1, pascal_tex1_num_8_bit_5d_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_8_bit_5d_enc_str_1},
    {PASCAL_TEX0_NUM_16_BIT_5D, pascal_tex0_num_16_bit_5d_enc_str_1, pascal_tex0_num_16_bit_5d_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_16_bit_5d_enc_str_1},
    {PASCAL_TEX1_NUM_16_BIT_5D, pascal_tex1_num_16_bit_5d_enc_str_1, pascal_tex1_num_16_bit_5d_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_16_bit_5d_enc_str_1},
    {PASCAL_TEX0_NUM_FP16X2_5D, pascal_tex0_num_fp16x2_5d_enc_str_1, pascal_tex0_num_fp16x2_5d_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_fp16x2_5d_enc_str_1},
    {PASCAL_TEX1_NUM_FP16X2_5D, pascal_tex1_num_fp16x2_5d_enc_str_1, pascal_tex1_num_fp16x2_5d_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_fp16x2_5d_enc_str_1},

    {PASCAL_TEX0_GLOBAL_ATOM_CAS_REQUESTS_5E, pascal_tex0_global_atom_cas_requests_5e_enc_str_1, pascal_tex0_global_atom_cas_requests_5e_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_atom_cas_requests_5e_enc_str_1},
    {PASCAL_TEX1_GLOBAL_ATOM_CAS_REQUESTS_5E, pascal_tex1_global_atom_cas_requests_5e_enc_str_1, pascal_tex1_global_atom_cas_requests_5e_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_atom_cas_requests_5e_enc_str_1},
    {PASCAL_TEX0_NUM_32_BIT_5E, pascal_tex0_num_32_bit_5e_enc_str_1, pascal_tex0_num_32_bit_5e_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_32_bit_5e_enc_str_1},
    {PASCAL_TEX1_NUM_32_BIT_5E, pascal_tex1_num_32_bit_5e_enc_str_1, pascal_tex1_num_32_bit_5e_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_32_bit_5e_enc_str_1},
    {PASCAL_TEX0_NUM_64_BIT_5E, pascal_tex0_num_64_bit_5e_enc_str_1, pascal_tex0_num_64_bit_5e_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_64_bit_5e_enc_str_1},
    {PASCAL_TEX1_NUM_64_BIT_5E, pascal_tex1_num_64_bit_5e_enc_str_1, pascal_tex1_num_64_bit_5e_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_64_bit_5e_enc_str_1},
    {PASCAL_TEX0_NUM_128_BIT_5E, pascal_tex0_num_128_bit_5e_enc_str_1, pascal_tex0_num_128_bit_5e_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_128_bit_5e_enc_str_1},
    {PASCAL_TEX1_NUM_128_BIT_5E, pascal_tex1_num_128_bit_5e_enc_str_1, pascal_tex1_num_128_bit_5e_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_128_bit_5e_enc_str_1},

    {PASCAL_TEX0_LOCAL_LD_REQUESTS_5F, pascal_tex0_local_ld_requests_5f_enc_str_1, pascal_tex0_local_ld_requests_5f_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_local_ld_requests_5f_enc_str_1},
    {PASCAL_TEX1_LOCAL_LD_REQUESTS_5F, pascal_tex1_local_ld_requests_5f_enc_str_1, pascal_tex1_local_ld_requests_5f_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_local_ld_requests_5f_enc_str_1},
    {PASCAL_TEX0_NUM_8_BIT_5F, pascal_tex0_num_8_bit_5f_enc_str_1, pascal_tex0_num_8_bit_5f_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_8_bit_5f_enc_str_1},
    {PASCAL_TEX1_NUM_8_BIT_5F, pascal_tex1_num_8_bit_5f_enc_str_1, pascal_tex1_num_8_bit_5f_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_8_bit_5f_enc_str_1},
    {PASCAL_TEX0_NUM_16_BIT_5F, pascal_tex0_num_16_bit_5f_enc_str_1, pascal_tex0_num_16_bit_5f_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_16_bit_5f_enc_str_1},
    {PASCAL_TEX1_NUM_16_BIT_5F, pascal_tex1_num_16_bit_5f_enc_str_1, pascal_tex1_num_16_bit_5f_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_16_bit_5f_enc_str_1},
    {PASCAL_TEX0_NUM_FP16X2_5F, pascal_tex0_num_fp16x2_5f_enc_str_1, pascal_tex0_num_fp16x2_5f_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_fp16x2_5f_enc_str_1},
    {PASCAL_TEX1_NUM_FP16X2_5F, pascal_tex1_num_fp16x2_5f_enc_str_1, pascal_tex1_num_fp16x2_5f_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_fp16x2_5f_enc_str_1},

    {PASCAL_TEX0_LOCAL_LD_REQUESTS_60, pascal_tex0_local_ld_requests_60_enc_str_1, pascal_tex0_local_ld_requests_60_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_local_ld_requests_60_enc_str_1},
    {PASCAL_TEX1_LOCAL_LD_REQUESTS_60, pascal_tex1_local_ld_requests_60_enc_str_1, pascal_tex1_local_ld_requests_60_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_local_ld_requests_60_enc_str_1},
    {PASCAL_TEX0_NUM_32_BIT_60, pascal_tex0_num_32_bit_60_enc_str_1, pascal_tex0_num_32_bit_60_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_32_bit_60_enc_str_1},
    {PASCAL_TEX1_NUM_32_BIT_60, pascal_tex1_num_32_bit_60_enc_str_1, pascal_tex1_num_32_bit_60_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_32_bit_60_enc_str_1},
    {PASCAL_TEX0_NUM_64_BIT_60, pascal_tex0_num_64_bit_60_enc_str_1, pascal_tex0_num_64_bit_60_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_64_bit_60_enc_str_1},
    {PASCAL_TEX1_NUM_64_BIT_60, pascal_tex1_num_64_bit_60_enc_str_1, pascal_tex1_num_64_bit_60_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_64_bit_60_enc_str_1},
    {PASCAL_TEX0_NUM_128_BIT_60, pascal_tex0_num_128_bit_60_enc_str_1, pascal_tex0_num_128_bit_60_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_num_128_bit_60_enc_str_1},
    {PASCAL_TEX1_NUM_128_BIT_60, pascal_tex1_num_128_bit_60_enc_str_1, pascal_tex1_num_128_bit_60_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_num_128_bit_60_enc_str_1},

    { PASCAL_TEX0_STORE_SECTOR_QURIES_GLOBAL,   pascal_tex0_store_sector_queries_global_enc_str_1,   pascal_tex0_store_sector_queries_global_enc_str_1,   CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_store_sector_queries_global_enc_str_1},
    { PASCAL_TEX1_STORE_SECTOR_QURIES_GLOBAL,   pascal_tex1_store_sector_queries_global_enc_str_1,   pascal_tex1_store_sector_queries_global_enc_str_1,   CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_store_sector_queries_global_enc_str_1},
    { PASCAL_TEX0_STORE_SECTOR_QURIES_LOCAL,    pascal_tex0_store_sector_queries_local_enc_str_1,    pascal_tex0_store_sector_queries_local_enc_str_1,    CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_store_sector_queries_local_enc_str_1},
    { PASCAL_TEX1_STORE_SECTOR_QURIES_LOCAL,    pascal_tex1_store_sector_queries_local_enc_str_1,    pascal_tex1_store_sector_queries_local_enc_str_1,    CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_store_sector_queries_local_enc_str_1},
    { PASCAL_TEX0_STORE_SECTOR_QURIES_ATOM_CAS, pascal_tex0_store_sector_queries_atom_cas_enc_str_1, pascal_tex0_store_sector_queries_atom_cas_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_store_sector_queries_atom_cas_enc_str_1},
    { PASCAL_TEX1_STORE_SECTOR_QURIES_ATOM_CAS, pascal_tex1_store_sector_queries_atom_cas_enc_str_1, pascal_tex1_store_sector_queries_atom_cas_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_store_sector_queries_atom_cas_enc_str_1},
    { PASCAL_TEX0_STORE_SECTOR_QURIES_ATOM,     pascal_tex0_store_sector_queries_atom_enc_str_1,     pascal_tex0_store_sector_queries_atom_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_store_sector_queries_atom_enc_str_1},
    { PASCAL_TEX1_STORE_SECTOR_QURIES_ATOM,     pascal_tex1_store_sector_queries_atom_enc_str_1,     pascal_tex1_store_sector_queries_atom_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_store_sector_queries_atom_enc_str_1},
    { PASCAL_TEX0_STORE_SECTOR_QURIES_RED,     pascal_tex0_store_sector_queries_red_enc_str_1,     pascal_tex0_store_sector_queries_red_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_store_sector_queries_red_enc_str_1},
    { PASCAL_TEX1_STORE_SECTOR_QURIES_RED,     pascal_tex1_store_sector_queries_red_enc_str_1,     pascal_tex1_store_sector_queries_red_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_store_sector_queries_red_enc_str_1},

    { PASCAL_TEX0_LOAD_SECTOR_QURIES_GLOBAL,   pascal_tex0_load_sector_queries_global_enc_str_1,   pascal_tex0_load_sector_queries_global_enc_str_1,   CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_load_sector_queries_global_enc_str_1},
    { PASCAL_TEX1_LOAD_SECTOR_QURIES_GLOBAL,   pascal_tex1_load_sector_queries_global_enc_str_1,   pascal_tex1_load_sector_queries_global_enc_str_1,   CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_load_sector_queries_global_enc_str_1},
    { PASCAL_TEX0_LOAD_SECTOR_QURIES_LOCAL,    pascal_tex0_load_sector_queries_local_enc_str_1,    pascal_tex0_load_sector_queries_local_enc_str_1,    CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_load_sector_queries_local_enc_str_1},
    { PASCAL_TEX1_LOAD_SECTOR_QURIES_LOCAL,    pascal_tex1_load_sector_queries_local_enc_str_1,    pascal_tex1_load_sector_queries_local_enc_str_1,    CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_load_sector_queries_local_enc_str_1},
    { PASCAL_TEX0_LOAD_SECTOR_QURIES_ATOM_CAS, pascal_tex0_load_sector_queries_atom_cas_enc_str_1, pascal_tex0_load_sector_queries_atom_cas_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_load_sector_queries_atom_cas_enc_str_1},
    { PASCAL_TEX1_LOAD_SECTOR_QURIES_ATOM_CAS, pascal_tex1_load_sector_queries_atom_cas_enc_str_1, pascal_tex1_load_sector_queries_atom_cas_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_load_sector_queries_atom_cas_enc_str_1},
    { PASCAL_TEX0_LOAD_SECTOR_QURIES_ATOM,     pascal_tex0_load_sector_queries_atom_enc_str_1,     pascal_tex0_load_sector_queries_atom_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_load_sector_queries_atom_enc_str_1},
    { PASCAL_TEX1_LOAD_SECTOR_QURIES_ATOM,     pascal_tex1_load_sector_queries_atom_enc_str_1,     pascal_tex1_load_sector_queries_atom_enc_str_1,     CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_load_sector_queries_atom_enc_str_1},

    { PASCAL_HWPM_INST_EXECUTED_TRAP,     pascal_hwpm_inst_executed_trap_enc_str_1,     pascal_hwpm_inst_executed_trap_enc_str_1,     CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_inst_executed_trap_enc_str_1},
    { PASCAL_HWPM_INST_EXECUTED_NO_TRAP,  pascal_hwpm_inst_executed_no_trap_enc_str_1,  pascal_hwpm_inst_executed_no_trap_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_inst_executed_no_trap_enc_str_1},
    { PASCAL_HWPM_INST_EXECUTED_S0,          pascal_hwpm_inst_executed_s0_enc_str_1,       pascal_hwpm_inst_executed_s0_enc_str_1,       CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_inst_executed_s0_enc_str_1},
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_DRAIN, pascal_sm_warp_cant_issue_true_drain_enc_str_1, pascal_sm_warp_cant_issue_true_drain_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_true_drain_enc_str_3}, //"warp_cant_issue_drain" 
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_ICACHE_MISS, pascal_sm_warp_cant_issue_true_icache_miss_enc_str_1, pascal_sm_warp_cant_issue_true_icache_miss_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_true_icache_miss_enc_str_3}, //"warp_cant_issue_icache_miss" 
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_IMC_MISS, pascal_sm_warp_cant_issue_true_imc_miss_enc_str_1, pascal_sm_warp_cant_issue_true_imc_miss_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_true_imc_miss_enc_str_3}, //"warp_cant_issue_imc_miss" 
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_LONG_SCOREBOARD, pascal_sm_warp_cant_issue_true_long_scoreboard_enc_str_1, pascal_sm_warp_cant_issue_true_long_scoreboard_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_true_long_scoreboard_enc_str_3}, //"warp_cant_issue_long_scoreboard" 
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_BARRIER, pascal_sm_warp_cant_issue_true_barrier_enc_str_1, pascal_sm_warp_cant_issue_true_barrier_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_true_barrier_enc_str_3}, //"warp_cant_issue_barrier" 
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_OFF_DECK_SHORT_SCOREBOARD, pascal_sm_warp_cant_issue_true_off_deck_short_scoreboard_enc_str_1, pascal_sm_warp_cant_issue_true_off_deck_short_scoreboard_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_true_off_deck_short_scoreboard_enc_str_3}, //"warp_cant_issue_off_deck_short_scoreboard" 
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_TILE_ALLOCATION_STALL, pascal_sm_warp_cant_issue_true_tile_allocation_stall_enc_str_1, pascal_sm_warp_cant_issue_true_tile_allocation_stall_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_true_tile_allocation_stall_enc_str_3}, //"warp_cant_issue_tile_allocation_stall" 
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_ALLOCATION_STALL_NO_SPACE, pascal_sm_warp_cant_issue_true_allocation_stall_no_space_enc_str_1, pascal_sm_warp_cant_issue_true_allocation_stall_no_space_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_true_allocation_stall_no_space_enc_str_3}, //"warp_cant_issue_allocation_stall_no_space" 
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_ALLOCATION_STALL_NOT_ELIGIBLE, pascal_sm_warp_cant_issue_true_allocation_stall_not_eligible_enc_str_1, pascal_sm_warp_cant_issue_true_allocation_stall_not_eligible_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_true_allocation_stall_not_eligible_enc_str_3}, //"warp_cant_issue_allocation_stall_not_eligible" 
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_MISC, pascal_sm_warp_cant_issue_true_misc_enc_str_1, pascal_sm_warp_cant_issue_true_misc_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_true_misc_enc_str_3}, //"warp_cant_issue_misc" 
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_MEMBAR, pascal_sm_warp_cant_issue_true_membar_enc_str_1, pascal_sm_warp_cant_issue_true_membar_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_true_membar_enc_str_3}, //"warp_cant_issue_membar" 
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_ON_DECK_SHORT_SCOREBOARD, pascal_sm_warp_cant_issue_true_on_deck_short_scoreboard_enc_str_1, pascal_sm_warp_cant_issue_true_on_deck_short_scoreboard_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_true_on_deck_short_scoreboard_enc_str_3}, //"warp_cant_issue_on_deck_short_scoreboard" 
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_WAIT, pascal_sm_warp_cant_issue_true_wait_enc_str_1, pascal_sm_warp_cant_issue_true_wait_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_true_wait_enc_str_3}, //"warp_cant_issue_wait" 
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_NO_INSTRUCTIONS, pascal_sm_warp_cant_issue_true_no_instructions_enc_str_1, pascal_sm_warp_cant_issue_true_no_instructions_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_true_no_instructions_enc_str_3}, //"warp_cant_issue_no_instructions" 
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_SHADOW_PIPE_THROTTLE, pascal_sm_warp_cant_issue_true_shadow_pipe_throttle_enc_str_1, pascal_sm_warp_cant_issue_true_shadow_pipe_throttle_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_true_shadow_pipe_throttle_enc_str_3}, //"warp_cant_issue_shadow_pipe_throttle" 
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_TEX_THROTTLE, pascal_sm_warp_cant_issue_true_tex_throttle_enc_str_1, pascal_sm_warp_cant_issue_true_tex_throttle_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_true_tex_throttle_enc_str_3}, //"warp_cant_issue_tex_throttle" 
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_MIO_THROTTLE, pascal_sm_warp_cant_issue_true_mio_throttle_enc_str_1, pascal_sm_warp_cant_issue_true_mio_throttle_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_true_mio_throttle_enc_str_3}, //"warp_cant_issue_mio_throttle" 
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_DISPATCH_STALL, pascal_sm_warp_cant_issue_true_dispatch_stall_enc_str_1, pascal_sm_warp_cant_issue_true_dispatch_stall_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_true_dispatch_stall_enc_str_3}, //"warp_cant_issue_dispatch_stall" 
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_NOT_SELECTED, pascal_sm_warp_cant_issue_true_not_selected_enc_str_1, pascal_sm_warp_cant_issue_true_not_selected_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_true_not_selected_enc_str_3}, //"warp_cant_issue_not_selected" 
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_ON_DECK_LONG_SCOREBOARD, pascal_sm_warp_cant_issue_true_on_deck_long_scoreboard_enc_str_1, pascal_sm_warp_cant_issue_true_on_deck_long_scoreboard_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_true_on_deck_long_scoreboard_enc_str_3}, //"warp_cant_issue_on_deck_long_scoreboard" 
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_ON_DECK_MISC, pascal_sm_warp_cant_issue_true_on_deck_misc_enc_str_1, pascal_sm_warp_cant_issue_true_on_deck_misc_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_true_on_deck_misc_enc_str_3}, //"warp_cant_issue_on_deck_misc" 
    { PASCAL_SM_WARP_CANT_ISSUE_TRUE_SELECTED, pascal_sm_warp_cant_issue_true_selected_enc_str_1, pascal_sm_warp_cant_issue_true_selected_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_warp_cant_issue_true_selected_enc_str_3}, //"warp_cant_issue_selected" 

    { PASCAL_HWPM_ACTIVE_CYCLES_TRAP,     pascal_hwpm_active_cycles_trap_enc_str_1,     pascal_hwpm_active_cycles_trap_enc_str_1,     CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_active_cycles_trap_enc_str_1},
    { PASCAL_HWPM_ACTIVE_CYCLES_NO_TRAP,  pascal_hwpm_active_cycles_no_trap_enc_str_1,  pascal_hwpm_active_cycles_no_trap_enc_str_1,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_active_cycles_no_trap_enc_str_1},
    {PASCAL_HWPMMUX_THREAD_INST_EXECUTED, pascal_hwpmmux_thread_inst_executed_enc_str_1, pascal_hwpmmux_thread_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpmmux_thread_inst_executed_enc_str_1},
    {PASCAL_HWPMMUX_NPO_THREAD_INST_EXECUTED, pascal_hwpmmux_npo_thread_inst_executed_enc_str_1, pascal_hwpmmux_npo_thread_inst_executed_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpmmux_npo_thread_inst_executed_enc_str_1},
    {PASCAL_HWPM_THREAD_INST_EXECUTED_0, pascal_hwpm_thread_inst_executed_s0_enc_str_1, pascal_hwpm_thread_inst_executed_s0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_thread_inst_executed_s0_enc_str_1},
    {PASCAL_HWPM_NPO_THREAD_INST_EXECUTED_0, pascal_hwpm_npo_thread_inst_executed_s0_enc_str_1, pascal_hwpm_npo_thread_inst_executed_s0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_npo_thread_inst_executed_s0_enc_str_1},
//-----------------------------------NVLINK TL COUNTERS----------------------------------------
    { PASCAL_NVLINK_TL_TX_TOTAL_FLITS, pascal_nvlink_tl_tx_total_flits_enc_str_1, pascal_nvlink_tl_tx_total_flits_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_tx_total_flits_enc_str_3 },
    { PASCAL_NVLINK_TL_TX_DATA_FLITS, pascal_nvlink_tl_tx_data_flits_enc_str_1, pascal_nvlink_tl_tx_data_flits_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_tx_data_flits_enc_str_3 },
    { PASCAL_NVLINK_TL_TX_READ_TOTAL_FLITS, pascal_nvlink_tl_tx_read_total_flits_enc_str_1, pascal_nvlink_tl_tx_read_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_tx_read_total_flits_enc_str_3 },
    { PASCAL_NVLINK_TL_TX_WRITE_TOTAL_FLITS, pascal_nvlink_tl_tx_write_total_flits_enc_str_1, pascal_nvlink_tl_tx_write_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_tx_write_total_flits_enc_str_1 },
    { PASCAL_NVLINK_TL_TX_RATOM_TOTAL_FLITS, pascal_nvlink_tl_tx_ratom_total_flits_enc_str_1, pascal_nvlink_tl_tx_ratom_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_tx_ratom_total_flits_enc_str_1 },
    { PASCAL_NVLINK_TL_TX_NRATOM_TOTAL_FLITS, pascal_nvlink_tl_tx_nratom_total_flits_enc_str_1, pascal_nvlink_tl_tx_nratom_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_tx_nratom_total_flits_enc_str_1 },
    { PASCAL_NVLINK_TL_TX_FLUSH_TOTAL_FLITS, pascal_nvlink_tl_tx_flush_total_flits_enc_str_1, pascal_nvlink_tl_tx_flush_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_tx_flush_total_flits_enc_str_1 },
    { PASCAL_NVLINK_TL_TX_RESPD_TOTAL_FLITS, pascal_nvlink_tl_tx_respd_total_flits_enc_str_1, pascal_nvlink_tl_tx_respd_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_tx_respd_total_flits_enc_str_1 },
    { PASCAL_NVLINK_TL_TX_READ_DATA_FLITS, pascal_nvlink_tl_tx_read_data_flits_enc_str_1, pascal_nvlink_tl_tx_read_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_tx_read_data_flits_enc_str_1 },
    { PASCAL_NVLINK_TL_TX_WRITE_DATA_FLITS, pascal_nvlink_tl_tx_write_data_flits_enc_str_1, pascal_nvlink_tl_tx_write_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_tx_write_data_flits_enc_str_1 },
    { PASCAL_NVLINK_TL_TX_RATOM_DATA_FLITS, pascal_nvlink_tl_tx_ratom_data_flits_enc_str_1, pascal_nvlink_tl_tx_ratom_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_tx_ratom_data_flits_enc_str_1 },
    { PASCAL_NVLINK_TL_TX_NRATOM_DATA_FLITS, pascal_nvlink_tl_tx_nratom_data_flits_enc_str_1, pascal_nvlink_tl_tx_nratom_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_tx_nratom_data_flits_enc_str_1 },
    { PASCAL_NVLINK_TL_TX_FLUSH_DATA_FLITS, pascal_nvlink_tl_tx_flush_data_flits_enc_str_1, pascal_nvlink_tl_tx_flush_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_tx_flush_data_flits_enc_str_1 },
    { PASCAL_NVLINK_TL_TX_RESPD_DATA_FLITS, pascal_nvlink_tl_tx_respd_data_flits_enc_str_1, pascal_nvlink_tl_tx_respd_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_tx_respd_data_flits_enc_str_1 },
    //------------------------------------------------------------------------------------------------------------------------------------------
    { PASCAL_NVLINK_TL_RX_TOTAL_FLITS, pascal_nvlink_tl_rx_total_flits_enc_str_1, pascal_nvlink_tl_rx_total_flits_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_rx_total_flits_enc_str_3 },
    { PASCAL_NVLINK_TL_RX_DATA_FLITS, pascal_nvlink_tl_rx_data_flits_enc_str_1, pascal_nvlink_tl_rx_data_flits_enc_str_2, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_rx_data_flits_enc_str_3 },
    { PASCAL_NVLINK_TL_RX_READ_TOTAL_FLITS, pascal_nvlink_tl_rx_read_total_flits_enc_str_1, pascal_nvlink_tl_rx_read_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_rx_read_total_flits_enc_str_3 },
    { PASCAL_NVLINK_TL_RX_WRITE_TOTAL_FLITS, pascal_nvlink_tl_rx_write_total_flits_enc_str_1, pascal_nvlink_tl_rx_write_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_rx_write_total_flits_enc_str_1 },
    { PASCAL_NVLINK_TL_RX_RATOM_TOTAL_FLITS, pascal_nvlink_tl_rx_ratom_total_flits_enc_str_1, pascal_nvlink_tl_rx_ratom_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_rx_ratom_total_flits_enc_str_1 },
    { PASCAL_NVLINK_TL_RX_NRATOM_TOTAL_FLITS, pascal_nvlink_tl_rx_nratom_total_flits_enc_str_1, pascal_nvlink_tl_rx_nratom_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_rx_nratom_total_flits_enc_str_1 },
    { PASCAL_NVLINK_TL_RX_FLUSH_TOTAL_FLITS, pascal_nvlink_tl_rx_flush_total_flits_enc_str_1, pascal_nvlink_tl_rx_flush_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_rx_flush_total_flits_enc_str_1 },
    { PASCAL_NVLINK_TL_RX_RESPD_TOTAL_FLITS, pascal_nvlink_tl_rx_respd_total_flits_enc_str_1, pascal_nvlink_tl_rx_respd_total_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_rx_respd_total_flits_enc_str_1 },
    { PASCAL_NVLINK_TL_RX_READ_DATA_FLITS, pascal_nvlink_tl_rx_read_data_flits_enc_str_1, pascal_nvlink_tl_rx_read_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_rx_read_data_flits_enc_str_1 },
    { PASCAL_NVLINK_TL_RX_WRITE_DATA_FLITS, pascal_nvlink_tl_rx_write_data_flits_enc_str_1, pascal_nvlink_tl_rx_write_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_rx_write_data_flits_enc_str_1 },
    { PASCAL_NVLINK_TL_RX_RATOM_DATA_FLITS, pascal_nvlink_tl_rx_ratom_data_flits_enc_str_1, pascal_nvlink_tl_rx_ratom_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_rx_ratom_data_flits_enc_str_1 },
    { PASCAL_NVLINK_TL_RX_NRATOM_DATA_FLITS, pascal_nvlink_tl_rx_nratom_data_flits_enc_str_1, pascal_nvlink_tl_rx_nratom_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_rx_nratom_data_flits_enc_str_1 },
    { PASCAL_NVLINK_TL_RX_FLUSH_DATA_FLITS, pascal_nvlink_tl_rx_flush_data_flits_enc_str_1, pascal_nvlink_tl_rx_flush_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_rx_flush_data_flits_enc_str_1 },
    { PASCAL_NVLINK_TL_RX_RESPD_DATA_FLITS, pascal_nvlink_tl_rx_respd_data_flits_enc_str_1, pascal_nvlink_tl_rx_respd_data_flits_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_nvlink_tl_rx_respd_data_flits_enc_str_1 },

    { PASCAL_PCIE_TX_ACTIVE, pascal_pcie_tx_active_enc_str_1, pascal_pcie_tx_active_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_pcie_tx_active_enc_str_1 },
    { PASCAL_PCIE_TX_IDLE, pascal_pcie_tx_idle_enc_str_1, pascal_pcie_tx_idle_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_pcie_tx_idle_enc_str_1 },
    { PASCAL_PCIE_RX_ACTIVE, pascal_pcie_rx_active_enc_str_1, pascal_pcie_rx_active_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_pcie_rx_active_enc_str_1 },
    { PASCAL_PCIE_RX_IDLE, pascal_pcie_rx_idle_enc_str_1, pascal_pcie_rx_idle_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_pcie_rx_idle_enc_str_1 },

    { PASCAL_SM_PQ_WRITE, pascal_sm_pq_write_enc_str_1, pascal_sm_pq_write_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_write_enc_str_3}, //"pq_write" 
    { PASCAL_SM_ADU_REPLAY, pascal_sm_adu_replay_enc_str_1, pascal_sm_adu_replay_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_adu_replay_enc_str_3}, //"adu_replay" 
    { PASCAL_SM_PQ_READS_FOR_SHM, pascal_sm_pq_reads_for_shm_enc_str_1, pascal_sm_pq_reads_for_shm_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_reads_for_shm_enc_str_3}, //"pq_reads_for_shm" 
    { PASCAL_SM_PQ_READS_FOR_PIXOUT, pascal_sm_pq_reads_for_pixout_enc_str_1, pascal_sm_pq_reads_for_pixout_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_reads_for_pixout_enc_str_3}, //"pq_reads_for_pixout" 
    { PASCAL_SM_PQ_READS_FOR_TEX, pascal_sm_pq_reads_for_tex_enc_str_1, pascal_sm_pq_reads_for_tex_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_reads_for_tex_enc_str_3}, //"pq_reads_for_tex" 
    { PASCAL_SM_PQ_READS_FOR_SHM_STOLEN, pascal_sm_pq_reads_for_shm_stolen_enc_str_1, pascal_sm_pq_reads_for_shm_stolen_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_reads_for_shm_stolen_enc_str_3}, //"pq_reads_for_shm_stolen" 
    { PASCAL_SM_IDC_DIVERGENCE_REPLAY, pascal_sm_idc_divergence_replay_enc_str_1, pascal_sm_idc_divergence_replay_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_idc_divergence_replay_enc_str_3}, //"idc_divergence_replay" 
    { PASCAL_SM_IDC_DIVERGENT_INSTRUCTION, pascal_sm_idc_divergent_instruction_enc_str_1, pascal_sm_idc_divergent_instruction_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_idc_divergent_instruction_enc_str_3}, //"idc_divergent_instruction" 
    { PASCAL_SM_MEMBAR_CTA_SENT_TO_TEX, pascal_sm_membar_cta_sent_to_tex_enc_str_1, pascal_sm_membar_cta_sent_to_tex_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_membar_cta_sent_to_tex_enc_str_3}, //"membar_cta_sent_to_tex" 
    { PASCAL_SM_LSU_BUSY, pascal_sm_lsu_busy_enc_str_1, pascal_sm_lsu_busy_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_lsu_busy_enc_str_3}, //"lsu_busy" 
    { PASCAL_SM_MIO_ISBE_WRITE, pascal_sm_mio_isbe_write_enc_str_1, pascal_sm_mio_isbe_write_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_isbe_write_enc_str_3}, //"mio_isbe_write" 
    { PASCAL_SM_MIO_ISBE_READ, pascal_sm_mio_isbe_read_enc_str_1, pascal_sm_mio_isbe_read_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_isbe_read_enc_str_3}, //"mio_isbe_read" 
    { PASCAL_SM_MIO_SM_STALLED_DUE_TO_PE, pascal_sm_mio_sm_stalled_due_to_pe_enc_str_1, pascal_sm_mio_sm_stalled_due_to_pe_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_sm_stalled_due_to_pe_enc_str_3}, //"mio_sm_stalled_due_to_pe" 
    { PASCAL_SM_PE2MIO_ISBE_READ_REQ, pascal_sm_pe2mio_isbe_read_req_enc_str_1, pascal_sm_pe2mio_isbe_read_req_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pe2mio_isbe_read_req_enc_str_3}, //"pe2mio_isbe_read_req" 
    { PASCAL_SM_PE2MIO_ISBE_WRITE_REQ, pascal_sm_pe2mio_isbe_write_req_enc_str_1, pascal_sm_pe2mio_isbe_write_req_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pe2mio_isbe_write_req_enc_str_3}, //"pe2mio_isbe_write_req" 
    { PASCAL_SM_PE2MIO_TRAM_WRITE, pascal_sm_pe2mio_tram_write_enc_str_1, pascal_sm_pe2mio_tram_write_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pe2mio_tram_write_enc_str_3}, //"pe2mio_tram_write" 
    { PASCAL_SM_PE_ISBE_WR_DELAYED_DUE_TO_CAMPING, pascal_sm_pe_isbe_wr_delayed_due_to_camping_enc_str_1, pascal_sm_pe_isbe_wr_delayed_due_to_camping_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pe_isbe_wr_delayed_due_to_camping_enc_str_3}, //"pe_isbe_wr_delayed_due_to_camping" 
    { PASCAL_SM_PE_TRAM_WR_DELAYED_AND_LOST_THROUGHPUT, pascal_sm_pe_tram_wr_delayed_and_lost_throughput_enc_str_1, pascal_sm_pe_tram_wr_delayed_and_lost_throughput_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pe_tram_wr_delayed_and_lost_throughput_enc_str_3}, //"pe_tram_wr_delayed_and_lost_throughput" 
    { PASCAL_SM_PE_TRAM_WR_DELAYED_DUE_TO_CAMPING, pascal_sm_pe_tram_wr_delayed_due_to_camping_enc_str_1, pascal_sm_pe_tram_wr_delayed_due_to_camping_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pe_tram_wr_delayed_due_to_camping_enc_str_3}, //"pe_tram_wr_delayed_due_to_camping" 
    { PASCAL_SM_SMM2TEX_DATA_LG_COUNT, pascal_sm_smm2tex_data_lg_count_enc_str_1, pascal_sm_smm2tex_data_lg_count_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_smm2tex_data_lg_count_enc_str_3}, //"smm2tex_data_lg_count" 
    { PASCAL_SM_SMM2TEX_DATA_TEX_COUNT, pascal_sm_smm2tex_data_tex_count_enc_str_1, pascal_sm_smm2tex_data_tex_count_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_smm2tex_data_tex_count_enc_str_3}, //"smm2tex_data_tex_count" 
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_ADU_OVER_SHM, pascal_sm_mio_cant_dispatch_lsu_adu_over_shm_enc_str_1, pascal_sm_mio_cant_dispatch_lsu_adu_over_shm_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_cant_dispatch_lsu_adu_over_shm_enc_str_3}, //"mio_cant_dispatch_lsu_adu_over_shm" 
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_ADU, pascal_sm_mio_cant_dispatch_lsu_pixout_over_adu_enc_str_1, pascal_sm_mio_cant_dispatch_lsu_pixout_over_adu_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_cant_dispatch_lsu_pixout_over_adu_enc_str_3}, //"mio_cant_dispatch_lsu_pixout_over_adu" 
    { PASCAL_SM_MIO_CANT_DISPATCH_LSU_PIXOUT_OVER_SHM, pascal_sm_mio_cant_dispatch_lsu_pixout_over_shm_enc_str_1, pascal_sm_mio_cant_dispatch_lsu_pixout_over_shm_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_mio_cant_dispatch_lsu_pixout_over_shm_enc_str_3}, //"mio_cant_dispatch_lsu_pixout_over_shm" 
    { PASCAL_SM_PQ_FULL, pascal_sm_pq_full_enc_str_1, pascal_sm_pq_full_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_full_enc_str_3}, //"pq_full" 
    { PASCAL_SM_PIX_PQ_FULL, pascal_sm_pix_pq_full_enc_str_1, pascal_sm_pix_pq_full_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pix_pq_full_enc_str_3}, //"pix_pq_full" 
    { PASCAL_SM_SHM_PQ_FULL, pascal_sm_shm_pq_full_enc_str_1, pascal_sm_shm_pq_full_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_shm_pq_full_enc_str_3}, //"shm_pq_full" 
    { PASCAL_SM_TEX_PQ_FULL, pascal_sm_tex_pq_full_enc_str_1, pascal_sm_tex_pq_full_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_tex_pq_full_enc_str_3}, //"tex_pq_full" 
    { PASCAL_SM_PQ_WRITE_BACK_LSU_STALL, pascal_sm_pq_write_back_lsu_stall_enc_str_1, pascal_sm_pq_write_back_lsu_stall_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_write_back_lsu_stall_enc_str_3}, //"pq_write_back_lsu_stall" 
    { PASCAL_SM_PQ_WRITE_BACK_TEX_STALL, pascal_sm_pq_write_back_tex_stall_enc_str_1, pascal_sm_pq_write_back_tex_stall_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pq_write_back_tex_stall_enc_str_3}, //"pq_write_back_tex_stall" 
    { PASCAL_SM_LSU_IQ_FIFO_FULL, pascal_sm_lsu_iq_fifo_full_enc_str_1, pascal_sm_lsu_iq_fifo_full_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_lsu_iq_fifo_full_enc_str_3}, //"lsu_iq_fifo_full" 
    { PASCAL_SM_TEX_IQ_FIFO_FULL, pascal_sm_tex_iq_fifo_full_enc_str_1, pascal_sm_tex_iq_fifo_full_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_tex_iq_fifo_full_enc_str_3}, //"tex_iq_fifo_full" 
    { PASCAL_SM_PIX_IQ_FIFO_FULL, pascal_sm_pix_iq_fifo_full_enc_str_1, pascal_sm_pix_iq_fifo_full_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_pix_iq_fifo_full_enc_str_3}, //"pix_iq_fifo_full" 
    { PASCAL_SM_RTY_IQ_FIFO_FULL, pascal_sm_rty_iq_fifo_full_enc_str_1, pascal_sm_rty_iq_fifo_full_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_rty_iq_fifo_full_enc_str_3}, //"rty_iq_fifo_full" 
    { PASCAL_ACTIVE_CYCLES_CORE_SM_PHYSICAL,  pascal_active_cycles_core_sm_physical_enc_str_1,  pascal_active_cycles_core_sm_physical_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  pascal_active_cycles_core_sm_physical_enc_str_3},
    { PASCAL_ELAPSED_CYCLES_CORE_SM_PHYSICAL, pascal_elapsed_cycles_core_sm_physical_enc_str_1, pascal_elapsed_cycles_core_sm_physical_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION,  pascal_elapsed_cycles_core_sm_physical_enc_str_3},
    { PASCAL_HWPM_ACTIVE_CYCLES_CORE_SM_VIRTUAL, pascal_sm_active_cycles_enc_str_1, pascal_sm_active_cycles_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_active_cycles_enc_str_3 }, //"active_cycles" 
    { PASCAL_HWPM_ELAPSED_CYCLES_CORE_SM_VIRTUAL, pascal_elapsed_cycles_sm_enc_str_1, pascal_elapsed_cycles_sm_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_elapsed_cycles_sm_enc_str_4 },
    { PASCAL_ACTIVE_WARPS_CORE_SM_PHYSICAL, pascal_active_warps_core_sm_physical_enc_str_1, pascal_active_warps_core_sm_physical_enc_str_2, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_active_warps_core_sm_physical_enc_str_3 },
    { PASCAL_ACTIVE_WARPS_CORE_SM_VIRTUAL, pascal_sm_active_warps_enc_str_1, pascal_sm_active_warps_enc_str_2,  CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_sm_active_warps_enc_str_3}, //"active_warps" 

    {PASCAL_MMU_GPC_LTP0_UTLB_HIT, pascal_mmu_gpc_ltp0_utlb_hit_enc_str_1, pascal_mmu_gpc_ltp0_utlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_gpc_ltp0_utlb_hit_enc_str_1},
    {PASCAL_MMU_GPC_LTP0_UTLB_MISS, pascal_mmu_gpc_ltp0_utlb_miss_enc_str_1, pascal_mmu_gpc_ltp0_utlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_gpc_ltp0_utlb_miss_enc_str_1},
    {PASCAL_MMU_GPC_LTP1_UTLB_HIT, pascal_mmu_gpc_ltp1_utlb_hit_enc_str_1, pascal_mmu_gpc_ltp1_utlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_gpc_ltp1_utlb_hit_enc_str_1},
    {PASCAL_MMU_GPC_LTP1_UTLB_MISS, pascal_mmu_gpc_ltp1_utlb_miss_enc_str_1, pascal_mmu_gpc_ltp1_utlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_gpc_ltp1_utlb_miss_enc_str_1},
    {PASCAL_MMU_GPC_LTP2_UTLB_HIT, pascal_mmu_gpc_ltp2_utlb_hit_enc_str_1, pascal_mmu_gpc_ltp2_utlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_gpc_ltp2_utlb_hit_enc_str_1},
    {PASCAL_MMU_GPC_LTP2_UTLB_MISS, pascal_mmu_gpc_ltp2_utlb_miss_enc_str_1, pascal_mmu_gpc_ltp2_utlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_gpc_ltp2_utlb_miss_enc_str_1},
    {PASCAL_MMU_GPC_LTP3_UTLB_HIT, pascal_mmu_gpc_ltp3_utlb_hit_enc_str_1, pascal_mmu_gpc_ltp3_utlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_gpc_ltp3_utlb_hit_enc_str_1},
    {PASCAL_MMU_GPC_LTP3_UTLB_MISS, pascal_mmu_gpc_ltp3_utlb_miss_enc_str_1, pascal_mmu_gpc_ltp3_utlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_gpc_ltp3_utlb_miss_enc_str_1},
    {PASCAL_MMU_GPC_LTP4_UTLB_HIT, pascal_mmu_gpc_ltp4_utlb_hit_enc_str_1, pascal_mmu_gpc_ltp4_utlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_gpc_ltp4_utlb_hit_enc_str_1},
    {PASCAL_MMU_GPC_LTP4_UTLB_MISS, pascal_mmu_gpc_ltp4_utlb_miss_enc_str_1, pascal_mmu_gpc_ltp4_utlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_gpc_ltp4_utlb_miss_enc_str_1},
    {PASCAL_MMU_GPC_RGG_UTLB_HIT, pascal_mmu_gpc_rgg_utlb_hit_enc_str_1, pascal_mmu_gpc_rgg_utlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_gpc_rgg_utlb_hit_enc_str_1},
    {PASCAL_MMU_GPC_RGG_UTLB_MISS, pascal_mmu_gpc_rgg_utlb_miss_enc_str_1, pascal_mmu_gpc_rgg_utlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_gpc_rgg_utlb_miss_enc_str_1},
    {PASCAL_MMU_GPC_GPCL1_TLB_HIT, pascal_mmu_gpc_gpcl1_tlb_hit_enc_str_1, pascal_mmu_gpc_gpcl1_tlb_hit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_gpc_gpcl1_tlb_hit_enc_str_1},
    {PASCAL_MMU_GPC_GPCL1_TLB_MISS, pascal_mmu_gpc_gpcl1_tlb_miss_enc_str_1, pascal_mmu_gpc_gpcl1_tlb_miss_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_mmu_gpc_gpcl1_tlb_miss_enc_str_1},

    {PASCAL_TEX0_TEX_QUAD_COUNT, pascal_tex0_tex_quad_count_enc_str_1, pascal_tex0_tex_quad_count_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_tex_quad_count_enc_str_1},
    {PASCAL_TEX1_TEX_QUAD_COUNT, pascal_tex1_tex_quad_count_enc_str_1, pascal_tex1_tex_quad_count_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_tex_quad_count_enc_str_1},
    {PASCAL_TEX0_GLOBAL_LD_REQUESTS_8BIT , pascal_tex0_global_ld_requests_8bit_enc_str_1, pascal_tex0_global_ld_requests_8bit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_ld_requests_8bit_enc_str_1},
    {PASCAL_TEX1_GLOBAL_LD_REQUESTS_8BIT , pascal_tex1_global_ld_requests_8bit_enc_str_1, pascal_tex1_global_ld_requests_8bit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_ld_requests_8bit_enc_str_1},
    {PASCAL_TEX0_GLOBAL_LD_REQUESTS_16BIT , pascal_tex0_global_ld_requests_16bit_enc_str_1, pascal_tex0_global_ld_requests_16bit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_ld_requests_16bit_enc_str_1},
    {PASCAL_TEX1_GLOBAL_LD_REQUESTS_16BIT , pascal_tex1_global_ld_requests_16bit_enc_str_1, pascal_tex1_global_ld_requests_16bit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_ld_requests_16bit_enc_str_1},
    {PASCAL_TEX0_GLOBAL_LD_REQUESTS_FP16X2 , pascal_tex0_global_ld_requests_fp16x2_enc_str_1, pascal_tex0_global_ld_requests_fp16x2_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_ld_requests_fp16x2_enc_str_1},
    {PASCAL_TEX1_GLOBAL_LD_REQUESTS_FP16X2 , pascal_tex1_global_ld_requests_fp16x2_enc_str_1, pascal_tex1_global_ld_requests_fp16x2_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_ld_requests_fp16x2_enc_str_1},
    {PASCAL_TEX0_GLOBAL_LD_REQUESTS_32BIT , pascal_tex0_global_ld_requests_32bit_enc_str_1, pascal_tex0_global_ld_requests_32bit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_ld_requests_32bit_enc_str_1},
    {PASCAL_TEX1_GLOBAL_LD_REQUESTS_32BIT , pascal_tex1_global_ld_requests_32bit_enc_str_1, pascal_tex1_global_ld_requests_32bit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_ld_requests_32bit_enc_str_1},
    {PASCAL_TEX0_GLOBAL_LD_REQUESTS_64BIT , pascal_tex0_global_ld_requests_64bit_enc_str_1, pascal_tex0_global_ld_requests_64bit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_ld_requests_64bit_enc_str_1},
    {PASCAL_TEX1_GLOBAL_LD_REQUESTS_64BIT , pascal_tex1_global_ld_requests_64bit_enc_str_1, pascal_tex1_global_ld_requests_64bit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_ld_requests_64bit_enc_str_1},
    {PASCAL_TEX0_GLOBAL_LD_REQUESTS_128BIT , pascal_tex0_global_ld_requests_128bit_enc_str_1, pascal_tex0_global_ld_requests_128bit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex0_global_ld_requests_128bit_enc_str_1},
    {PASCAL_TEX1_GLOBAL_LD_REQUESTS_128BIT , pascal_tex1_global_ld_requests_128bit_enc_str_1, pascal_tex1_global_ld_requests_128bit_enc_str_1, CUPROF_EVENT_CATEGORY_CACHE, pascal_tex1_global_ld_requests_128bit_enc_str_1},
    {PASCAL_HWPM_INST_EXECUTED_FFMA_OPS_S0, pascal_hwpm_inst_executed_ffma_ops_s0_enc_str_1, pascal_hwpm_inst_executed_ffma_ops_s0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_inst_executed_ffma_ops_s0_enc_str_1},
    {PASCAL_HWPM_INST_EXECUTED_FFMA_OPS_S1, pascal_hwpm_inst_executed_ffma_ops_s1_enc_str_1, pascal_hwpm_inst_executed_ffma_ops_s1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_inst_executed_ffma_ops_s1_enc_str_1},
    {PASCAL_HWPM_INST_EXECUTED_FFMA_OPS_S2, pascal_hwpm_inst_executed_ffma_ops_s2_enc_str_1, pascal_hwpm_inst_executed_ffma_ops_s2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_inst_executed_ffma_ops_s2_enc_str_1},
    {PASCAL_HWPM_INST_EXECUTED_FFMA_OPS_S3, pascal_hwpm_inst_executed_ffma_ops_s3_enc_str_1, pascal_hwpm_inst_executed_ffma_ops_s3_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_inst_executed_ffma_ops_s3_enc_str_1},
    {PASCAL_HWPM_INST_EXECUTED_OTHERFP_OPS_S0, pascal_hwpm_inst_executed_otherfp_ops_s0_enc_str_1, pascal_hwpm_inst_executed_otherfp_ops_s0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_inst_executed_otherfp_ops_s0_enc_str_1},
    {PASCAL_HWPM_INST_EXECUTED_OTHERFP_OPS_S1, pascal_hwpm_inst_executed_otherfp_ops_s1_enc_str_1, pascal_hwpm_inst_executed_otherfp_ops_s1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_inst_executed_otherfp_ops_s1_enc_str_1},
    {PASCAL_HWPM_INST_EXECUTED_OTHERFP_OPS_S2, pascal_hwpm_inst_executed_otherfp_ops_s2_enc_str_1, pascal_hwpm_inst_executed_otherfp_ops_s2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_inst_executed_otherfp_ops_s2_enc_str_1},
    {PASCAL_HWPM_INST_EXECUTED_OTHERFP_OPS_S3, pascal_hwpm_inst_executed_otherfp_ops_s3_enc_str_1, pascal_hwpm_inst_executed_otherfp_ops_s3_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_inst_executed_otherfp_ops_s3_enc_str_1},
    {PASCAL_HWPM_INST_EXECUTED_FP32_OPS_S0, pascal_hwpm_inst_executed_fp32_ops_s0_enc_str_1, pascal_hwpm_inst_executed_fp32_ops_s0_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_inst_executed_fp32_ops_s0_enc_str_1},
    {PASCAL_HWPM_INST_EXECUTED_FP32_OPS_S1, pascal_hwpm_inst_executed_fp32_ops_s1_enc_str_1, pascal_hwpm_inst_executed_fp32_ops_s1_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_inst_executed_fp32_ops_s1_enc_str_1},
    {PASCAL_HWPM_INST_EXECUTED_FP32_OPS_S2, pascal_hwpm_inst_executed_fp32_ops_s2_enc_str_1, pascal_hwpm_inst_executed_fp32_ops_s2_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_inst_executed_fp32_ops_s2_enc_str_1},
    {PASCAL_HWPM_INST_EXECUTED_FP32_OPS_S3, pascal_hwpm_inst_executed_fp32_ops_s3_enc_str_1, pascal_hwpm_inst_executed_fp32_ops_s3_enc_str_1, CUPROF_EVENT_CATEGORY_INSTRUCTION, pascal_hwpm_inst_executed_fp32_ops_s3_enc_str_1},

#endif /* #if NVCFG(GLOBAL_GPU_FAMILY_GP10X) || NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B) */
#if NVLINK_PM
    { PASCAL_NVLINK0_TL_TX_DATA_FLIT,     pascal_nvlink0_tl_tx_data_flit_enc_str_1,     pascal_nvlink0_tl_tx_data_flit_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, pascal_nvlink0_tl_tx_data_flit_enc_str_2},
    { PASCAL_NVLINK1_TL_TX_DATA_FLIT,     pascal_nvlink1_tl_tx_data_flit_enc_str_1,     pascal_nvlink1_tl_tx_data_flit_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, pascal_nvlink1_tl_tx_data_flit_enc_str_2},
    { PASCAL_NVLINK2_TL_TX_DATA_FLIT,     pascal_nvlink2_tl_tx_data_flit_enc_str_1,     pascal_nvlink2_tl_tx_data_flit_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, pascal_nvlink2_tl_tx_data_flit_enc_str_2},
    { PASCAL_NVLINK3_TL_TX_DATA_FLIT,     pascal_nvlink3_tl_tx_data_flit_enc_str_1,     pascal_nvlink3_tl_tx_data_flit_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, pascal_nvlink3_tl_tx_data_flit_enc_str_2},

    { PASCAL_NVLINK0_TL_RX_DATA_FLIT,     pascal_nvlink0_tl_rx_data_flit_enc_str_1,     pascal_nvlink0_tl_rx_data_flit_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, pascal_nvlink0_tl_rx_data_flit_enc_str_2},
    { PASCAL_NVLINK1_TL_RX_DATA_FLIT,     pascal_nvlink1_tl_rx_data_flit_enc_str_1,     pascal_nvlink1_tl_rx_data_flit_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, pascal_nvlink1_tl_rx_data_flit_enc_str_2},
    { PASCAL_NVLINK2_TL_RX_DATA_FLIT,     pascal_nvlink2_tl_rx_data_flit_enc_str_1,     pascal_nvlink2_tl_rx_data_flit_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, pascal_nvlink2_tl_rx_data_flit_enc_str_2},
    { PASCAL_NVLINK3_TL_RX_DATA_FLIT,     pascal_nvlink3_tl_rx_data_flit_enc_str_1,     pascal_nvlink3_tl_rx_data_flit_enc_str_1,     CUPROF_EVENT_CATEGORY_MEMORY, pascal_nvlink3_tl_rx_data_flit_enc_str_2},
#endif
#if NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
    {PASCAL_LTC0_LTCX_MC_REQ_RD_SIZE_32B,    pascal_ltc0_ltcx_mc_req_rd_size_32b_enc_str_1,     pascal_ltc0_ltcx_mc_req_rd_size_32b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc0_ltcx_mc_req_rd_size_32b_enc_str_4},
    {PASCAL_LTC0_LTCX_MC_REQ_RD_SIZE_64B,    pascal_ltc0_ltcx_mc_req_rd_size_64b_enc_str_1,     pascal_ltc0_ltcx_mc_req_rd_size_64b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc0_ltcx_mc_req_rd_size_64b_enc_str_4},
    {PASCAL_LTC0_LTCX_MC_REQ_WR_SIZE_16B,    pascal_ltc0_ltcx_mc_req_wr_size_16b_enc_str_1,     pascal_ltc0_ltcx_mc_req_wr_size_16b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc0_ltcx_mc_req_wr_size_16b_enc_str_4},
    {PASCAL_LTC0_LTCX_MC_REQ_WR_SIZE_32B,    pascal_ltc0_ltcx_mc_req_wr_size_32b_enc_str_1,     pascal_ltc0_ltcx_mc_req_wr_size_32b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc0_ltcx_mc_req_wr_size_32b_enc_str_4},
    {PASCAL_LTC0_LTCX_MC_REQ_WR_SIZE_64B,    pascal_ltc0_ltcx_mc_req_wr_size_64b_enc_str_1,     pascal_ltc0_ltcx_mc_req_wr_size_64b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc0_ltcx_mc_req_wr_size_64b_enc_str_4},

    {PASCAL_LTC0_LTCX_REQ_RD_SECTOR_COUNT_1, pascal_ltc0_ltcx_req_rd_sector_count_1_enc_str_1,  pascal_ltc0_ltcx_req_rd_sector_count_1_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc0_ltcx_req_rd_sector_count_1_enc_str_4},
    {PASCAL_LTC0_LTCX_REQ_RD_SECTOR_COUNT_2, pascal_ltc0_ltcx_req_rd_sector_count_2_enc_str_1,  pascal_ltc0_ltcx_req_rd_sector_count_2_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc0_ltcx_req_rd_sector_count_2_enc_str_4},
    {PASCAL_LTC0_LTCX_REQ_RD_SECTOR_COUNT_3, pascal_ltc0_ltcx_req_rd_sector_count_3_enc_str_1,  pascal_ltc0_ltcx_req_rd_sector_count_3_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc0_ltcx_req_rd_sector_count_3_enc_str_4},
    {PASCAL_LTC0_LTCX_REQ_RD_SECTOR_COUNT_4, pascal_ltc0_ltcx_req_rd_sector_count_4_enc_str_1,  pascal_ltc0_ltcx_req_rd_sector_count_4_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc0_ltcx_req_rd_sector_count_4_enc_str_4},

    {PASCAL_LTC0_LTCX_REQ_WR_SECTOR_COUNT_1, pascal_ltc0_ltcx_req_wr_sector_count_1_enc_str_1,  pascal_ltc0_ltcx_req_wr_sector_count_1_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc0_ltcx_req_wr_sector_count_1_enc_str_4},
    {PASCAL_LTC0_LTCX_REQ_WR_SECTOR_COUNT_2, pascal_ltc0_ltcx_req_wr_sector_count_2_enc_str_1,  pascal_ltc0_ltcx_req_wr_sector_count_2_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc0_ltcx_req_wr_sector_count_2_enc_str_4},
    {PASCAL_LTC0_LTCX_REQ_WR_SECTOR_COUNT_3, pascal_ltc0_ltcx_req_wr_sector_count_3_enc_str_1,  pascal_ltc0_ltcx_req_wr_sector_count_3_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc0_ltcx_req_wr_sector_count_3_enc_str_4},
    {PASCAL_LTC0_LTCX_REQ_WR_SECTOR_COUNT_4, pascal_ltc0_ltcx_req_wr_sector_count_4_enc_str_1,  pascal_ltc0_ltcx_req_wr_sector_count_4_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc0_ltcx_req_wr_sector_count_4_enc_str_4},

    {PASCAL_LTC1_LTCX_MC_REQ_RD_SIZE_32B,    pascal_ltc1_ltcx_mc_req_rd_size_32b_enc_str_1,     pascal_ltc1_ltcx_mc_req_rd_size_32b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc1_ltcx_mc_req_rd_size_32b_enc_str_4},
    {PASCAL_LTC1_LTCX_MC_REQ_RD_SIZE_64B,    pascal_ltc1_ltcx_mc_req_rd_size_64b_enc_str_1,     pascal_ltc1_ltcx_mc_req_rd_size_64b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc1_ltcx_mc_req_rd_size_64b_enc_str_4},
    {PASCAL_LTC1_LTCX_MC_REQ_WR_SIZE_16B,    pascal_ltc1_ltcx_mc_req_wr_size_16b_enc_str_1,     pascal_ltc1_ltcx_mc_req_wr_size_16b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc1_ltcx_mc_req_wr_size_16b_enc_str_4},
    {PASCAL_LTC1_LTCX_MC_REQ_WR_SIZE_32B,    pascal_ltc1_ltcx_mc_req_wr_size_32b_enc_str_1,     pascal_ltc1_ltcx_mc_req_wr_size_32b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc1_ltcx_mc_req_wr_size_32b_enc_str_4},
    {PASCAL_LTC1_LTCX_MC_REQ_WR_SIZE_64B,    pascal_ltc1_ltcx_mc_req_wr_size_64b_enc_str_1,     pascal_ltc1_ltcx_mc_req_wr_size_64b_enc_str_1,    CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc1_ltcx_mc_req_wr_size_64b_enc_str_4},

    {PASCAL_LTC1_LTCX_REQ_RD_SECTOR_COUNT_1, pascal_ltc1_ltcx_req_rd_sector_count_1_enc_str_1,  pascal_ltc1_ltcx_req_rd_sector_count_1_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc1_ltcx_req_rd_sector_count_1_enc_str_4},
    {PASCAL_LTC1_LTCX_REQ_RD_SECTOR_COUNT_2, pascal_ltc1_ltcx_req_rd_sector_count_2_enc_str_1,  pascal_ltc1_ltcx_req_rd_sector_count_2_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc1_ltcx_req_rd_sector_count_2_enc_str_4},
    {PASCAL_LTC1_LTCX_REQ_RD_SECTOR_COUNT_3, pascal_ltc1_ltcx_req_rd_sector_count_3_enc_str_1,  pascal_ltc1_ltcx_req_rd_sector_count_3_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc1_ltcx_req_rd_sector_count_3_enc_str_4},
    {PASCAL_LTC1_LTCX_REQ_RD_SECTOR_COUNT_4, pascal_ltc1_ltcx_req_rd_sector_count_4_enc_str_1,  pascal_ltc1_ltcx_req_rd_sector_count_4_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc1_ltcx_req_rd_sector_count_4_enc_str_4},

    {PASCAL_LTC1_LTCX_REQ_WR_SECTOR_COUNT_1, pascal_ltc1_ltcx_req_wr_sector_count_1_enc_str_1,  pascal_ltc1_ltcx_req_wr_sector_count_1_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc1_ltcx_req_wr_sector_count_1_enc_str_4},
    {PASCAL_LTC1_LTCX_REQ_WR_SECTOR_COUNT_2, pascal_ltc1_ltcx_req_wr_sector_count_2_enc_str_1,  pascal_ltc1_ltcx_req_wr_sector_count_2_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc1_ltcx_req_wr_sector_count_2_enc_str_4},
    {PASCAL_LTC1_LTCX_REQ_WR_SECTOR_COUNT_3, pascal_ltc1_ltcx_req_wr_sector_count_3_enc_str_1,  pascal_ltc1_ltcx_req_wr_sector_count_3_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc1_ltcx_req_wr_sector_count_3_enc_str_4},
    {PASCAL_LTC1_LTCX_REQ_WR_SECTOR_COUNT_4, pascal_ltc1_ltcx_req_wr_sector_count_4_enc_str_1,  pascal_ltc1_ltcx_req_wr_sector_count_4_enc_str_1, CUPROF_EVENT_CATEGORY_MEMORY, pascal_ltc1_ltcx_req_wr_sector_count_4_enc_str_4},

#endif //NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)

    {INVALID_PM_SIGNAL_NEW, ""}
};

#if NVCFG(GLOBAL_GPU_FAMILY_GP10X)
CUdomainInfo domainInfoGP100   = { 21,    domainTableGP100, pPascalSignalDescriptionArray};
CUdomainInfo domainInfoGP10x   = { 15,    domainTableGP10x, pPascalSignalDescriptionArray};
#if defined(NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GP107) || defined(NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GP107)
CUdomainInfo domainInfoGP107   = { 15,    domainTableGP107, pPascalSignalDescriptionArray};
#endif
#else
CUdomainInfo domainInfoGP100   = { 0,    NULL, pPascalSignalDescriptionArray};
CUdomainInfo domainInfoGP10x   = { 0,    NULL, pPascalSignalDescriptionArray};
CUdomainInfo domainInfoGP107   = { 0,    NULL, pPascalSignalDescriptionArray};
#endif /*#if NVCFG(GLOBAL_GPU_FAMILY_GP10X) */

#if NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
CUdomainInfo domainInfoGP10Y   = { 13,  domainTableGP10Y, pPascalSignalDescriptionArray};
#else
CUdomainInfo domainInfoGP10Y   = { 0,    NULL, pPascalSignalDescriptionArray};
#endif /* #if NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B) */
