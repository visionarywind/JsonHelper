/* hProfilerObjContext
 * Copyright 2010-2011 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

/******************************************************************************
*
*   Module: perfmon_common.c
*
*   Description:
*       perfmon functionality common to all architectures
*
******************************************************************************/

#include "cuda_device.h"
#include "cuda_internal.h"
#include "perfmon_new.h"
#include "perfmon_internals.h"
#include "cuimemset.h"
#include "memobj.h"
#include "perfmon_common.h"
#include "cuprofiler.h"
#include "hal/fermi/fermi_signals.h"
#include "hal/kepler/kepler_signals.h"
#if NVCFG(GLOBAL_ARCH_MAXWELL)
#include "hal/maxwell/maxwell_signals.h"
#endif
#if NVCFG(GLOBAL_ARCH_PASCAL)
#include "hal/pascal/pascal_signals.h"
#endif
#if NVCFG(GLOBAL_ARCH_VOLTA)
#include "hal/volta/volta_signals.h"
#endif

#include "ctrl/ctrl2080.h"
#include "rm_call.h"
#include "rm_device.h"
#include "wddm_device.h"
#include "class/cl844c.h"
#include "ctrl/ctrl0000.h"
#include "class/cl003e.h"

#include "cuda_etbl/tools_profiler.h"

#if cuiPlatformIncludesMrm()
#if defined(__QNX__)
#include "qnx/nvgpu.h"
#include "sys/neutrino.h"
#else
#include "nvgpu.h"
#endif // defined(__QNX__)
#include "mrm_channel.h"
#include "cui/memblock.h"
#include "mrm_device.h"
#include "channel_private.h"
#include "nvos_tegra.h"
#endif // cuiPlatformIncludesMrm()

extern CUprofResult CUDAAPI toolsProfilerClassControlPerfmon(CUdev* device, CUcontext ctx,
                                                     uint32_t profilerObjHandle,
                                                     uint32_t flag);

extern CUprofResult CUDAAPI toolsProfilerClassControlClockGating(CUdev* device, CUcontext ctx,
                                                     uint32_t profilerObjHandle,
                                                     uint32_t controlMask,
                                                     uint32_t *statusMask,
                                                     uint32_t flag);

extern CUprofResult CUDAAPI toolsProfilerClassControlPowerGating(CUdev* device, CUcontext ctx,
                                                     uint32_t profilerObjHandle,
                                                     uint32_t controlMask,
                                                     uint32_t *statusMask,
                                                     uint32_t flag);

extern CUprofResult CUDAAPI toolsProfilerClassControlThermalSettings(CUdev* device, CUcontext ctx,
                                                     uint32_t profilerObjHandle,
                                                     uint32_t controlMask,
                                                     uint32_t *statusMask,
                                                     uint32_t flag);

extern CUprofResult CUDAAPI toolsProfilerClassControlVat(CUdev* device, CUcontext ctx,
                                                     uint32_t profilerObjHandle,
                                                     uint32_t controlMask,
                                                     uint32_t *statusMask,
                                                     uint32_t flag);
#define USE_POWER_API 0

#define BUFFER_INIT_VALUE 0

#if NVCFG(GLOBAL_ARCH_FERMI)
extern CUdomainInfo domainInfoGF100;
extern CUdomainInfo domainInfoGF104;
extern CUdomainInfo domainInfoGF108;
extern CUdomainInfo domainInfoGF119;
extern CUdomainInfo domainInfoGF117;
#endif // NVCFG(GLOBAL_ARCH_FERMI)
#if NVCFG(GLOBAL_ARCH_KEPLER)
extern CUdomainInfo domainInfoGK104;
extern CUdomainInfo domainInfoGK110;
extern CUdomainInfo domainInfoGK208;
extern CUdomainInfo domainInfoGK20A;
#endif // NVCFG(GLOBAL_ARCH_KEPLER)
#if NVCFG(GLOBAL_ARCH_MAXWELL)
extern CUdomainInfo domainInfoGM000;
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200
extern CUdomainInfo domainInfoGM200;
#endif // NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200
#endif // NVCFG(GLOBAL_ARCH_MAXWELL)
#if NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
extern CUdomainInfo domainInfoGM20Y;
#endif // NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
#if NVCFG(GLOBAL_ARCH_PASCAL)
extern CUdomainInfo domainInfoGP100;
extern CUdomainInfo domainInfoGP10x;
#if defined(NVCFG_GLOBAL_GPU_IMPL_GP107) || defined(NVCFG_GLOBAL_GPU_IMPL_GP108)
extern CUdomainInfo domainInfoGP107;
#endif
#endif // NVCFG(GLOBAL_ARCH_PASCAL)
#if NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
extern CUdomainInfo domainInfoGP10Y;
#endif
#if NVCFG(GLOBAL_ARCH_VOLTA)
extern CUdomainInfo domainInfoGV100;
#endif
#if NVCFG(GLOBAL_CHIP_T194) || NVCFG(GLOBAL_GPU_IMPL_GV11B)
extern CUdomainInfo domainInfoGV11B;
#endif

// __TEMP_WAR__ Bug 200347107
#if cuiNvcfgEnabledFermiOrHigher()
extern SignalDescriptionTable pFermiSignalDescriptionArray[];
#endif // NVCFG(GLOBAL_ARCH_FERMI)
#if NVCFG(GLOBAL_ARCH_KEPLER)
extern SignalDescriptionTable pKeplerSignalDescriptionArray[];
#endif // NVCFG(GLOBAL_ARCH_KEPLER)
#if NVCFG(GLOBAL_ARCH_MAXWELL) || NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
extern SignalDescriptionTable pMaxwellSignalDescriptionArray[];
#endif // NVCFG(GLOBAL_ARCH_MAXWELL) || NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
#if NVCFG(GLOBAL_ARCH_PASCAL)
extern SignalDescriptionTable pPascalSignalDescriptionArray[];
#endif // NVCFG(GLOBAL_ARCH_PASCAL)
#if NVCFG(GLOBAL_ARCH_VOLTA)
extern SignalDescriptionTable pVoltaSignalDescriptionArray[];
#endif // NVCFG(GLOBAL_ARCH_Volta)

CUdomainInfo *g_DomainInfo[] = {
#if NVCFG(GLOBAL_ARCH_FERMI)
    &domainInfoGF100,
    &domainInfoGF104,
    &domainInfoGF108,
    &domainInfoGF119,
    &domainInfoGF117,
#endif // NVCFG(GLOBAL_ARCH_FERMI)
#if NVCFG(GLOBAL_ARCH_KEPLER)
    &domainInfoGK104,
    &domainInfoGK110,
    &domainInfoGK208,
    &domainInfoGK20A,
#endif // NVCFG(GLOBAL_ARCH_KEPLER)
#if NVCFG(GLOBAL_ARCH_MAXWELL)
    &domainInfoGM000,
#ifdef NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200
    &domainInfoGM200,
#endif // NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GM200
#endif // NVCFG(GLOBAL_ARCH_MAXWELL)
#if NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
    &domainInfoGM20Y,
#endif // NVCFG(GLOBAL_CHIP_T210) || NVCFG(GLOBAL_GPU_IMPL_GM20B) || NVCFG(GLOBAL_GPU_IMPL_GM21B)
#if NVCFG(GLOBAL_ARCH_PASCAL)
    &domainInfoGP100,
    &domainInfoGP10x,
#if defined(NVCFG_GLOBAL_GPU_IMPL_GP107) || defined(NVCFG_GLOBAL_GPU_IMPL_GP108)
    &domainInfoGP107,
#endif
#endif // NVCFG(GLOBAL_ARCH_PASCAL)
#if NVCFG(GLOBAL_CHIP_T186) || NVCFG(GLOBAL_GPU_IMPL_GP10B)
    &domainInfoGP10Y,
#endif
#if NVCFG(GLOBAL_ARCH_VOLTA)
    &domainInfoGV100,
#endif
#if NVCFG(GLOBAL_CHIP_T194) || NVCFG(GLOBAL_GPU_IMPL_GV11B)
    &domainInfoGV11B
#endif
};

#if defined(__QNX__)
static CUprofResult
qnxProfilerMemGetImportId(NvRmMemHandle nvrmHandle, int nvgpuFd, uint32_t *pImportId)
{
    struct _server_info serverInfo = {};
    NvS32 ret;
    NvError nvErr;
    NvRmMemChInfo chInfo = {};
    NvRmMemHandleParams params = {};
    NvU32 paramSize = (NvU32)sizeof(NvRmMemHandleParams);
    ret = ConnectServerInfo_r(0, nvgpuFd, &serverInfo);
    if (ret < 0)
    {
        CU_ERROR_PRINT(("ConnectServerInfo_r failed %d\n", ret));
        return CUPROF_ERROR_UNKNOWN;
    }

    chInfo.ChId = serverInfo.chid;
    chInfo.pid = serverInfo.pid;
    chInfo.NodeId = serverInfo.nd;

    nvErr = NvRmMemHandleQueryParams(nvrmHandle,
                                     0U,
                                     &params,
                                     paramSize);
    if (nvErr != NvSuccess)
    {
        CU_ERROR_PRINT(("NvRmMemHandleQueryParams failed nvrmHandle %u err %d\n", nvrmHandle, nvErr));
        return CUPROF_ERROR_UNKNOWN;
    }
    nvErr = NvRmMemGetImportId(nvrmHandle,
                               &chInfo,
                               params.AccessFlags,
                               pImportId);
    if (nvErr != NvSuccess)
    {
        CU_ERROR_PRINT(("NvRmMemGetImportId failed hMem %u err %d\n", nvrmHandle, nvErr));
        return CUPROF_ERROR_UNKNOWN;
    }

    return CUPROF_SUCCESS;
}
#endif

CUcontext globalCtx;

CUprofResult setupStreamingResources(CUcontext ctx) {
    CUresult alloc_status = CUDA_SUCCESS;
    CUprofResult cuprof_retval = CUPROF_SUCCESS;

    CU_TRACE_FUNCTION();

    if (ctx->pmNew->sizeStreamingBuffer && ctx->pmNew->gpuAddrStreamingBuffer) {
        //The resources for streaming are already setup.
        return CUPROF_SUCCESS;
    }

    //Allocate 128MB buffer for windows. On windows the wait time is not
    //strictly the same as what we specify here.
    ctx->pmNew->sizeStreamingBuffer = 1024 * 32 * 64 * 2 *
                              sizeof(CUprofStreamingRecord);

#if !cuiPlatformIncludesMrm() && cuiPlatformIncludesRm()
    {
        NvU64 rmDmaOffset = 0;
        void* pAddr = NULL;
        NvU32 rmClient = 0, rmDevice = 0;

#ifdef WINLH
        if ((cuosIsWindowsVistaPlus() && ctx->device->dmalType == CU_DMAL_RM)) {
            rmClient = globals.rmClient;
            rmDevice = deviceGetHandleRM(ctx->device);
        }
        else {
            rmClient = globals.dm.wddm->wddmRmUserModeClient;
            rmDevice = ctx->device->dm.wddm->wddmRmUserModeDevice;
        }
#else 
        rmClient = globals.rmClient;
        rmDevice = deviceGetHandleRM(ctx->device);
#endif
        if (!ctx->pmNew->rmPerfObject) {
            //Allocate the perf object
            ctx->pmNew->rmPerfObject = handlePoolAlloc(globals.handlePool);
            if (!ctx->pmNew->rmPerfObject) {
                CU_ERROR_PRINT(("Failed to allocate handle for rmDevice\n"));
                return (CUprofResult)CUDA_ERROR_OUT_OF_MEMORY;
            }
            alloc_status = (CUresult)CudaRmAlloc(
                rmClient,
                rmDevice,
                ctx->pmNew->rmPerfObject,
                G84_PERFBUFFER,
                NULL);
        }

        if (alloc_status == CUDA_SUCCESS)
        {
            NvU32 flags = DRF_DEF(OS02, _FLAGS, _LOCATION, _PCI) |
                DRF_DEF(OS02, _FLAGS, _PHYSICALITY, _NONCONTIGUOUS) |
#if cuiArchIsARM() 
                // On ARM + dGPU platforms, streaming buffer should be
                // uncached on CPU as platforms aren't I/O coherent.
                // __TEMP_WAR__ for Bug 200201968 till a cleaner way
                // of identifying I/O coherence is found.
                DRF_DEF(OS02, _FLAGS, _COHERENCY, _UNCACHED);
#else
                DRF_DEF(OS02, _FLAGS, _COHERENCY, _CACHED);
#endif

            if (!ctx->pmNew->rmPerfMemory) {
            NvU64 size = ctx->pmNew->sizeStreamingBuffer;
            ctx->pmNew->rmPerfMemory = handlePoolAlloc(globals.handlePool);
            //Allocate system physical and virtual memory
            alloc_status = (CUresult)CudaRmAllocMemory64(
                rmClient,
                rmDevice,
                ctx->pmNew->rmPerfMemory,
                NV01_MEMORY_SYSTEM,
                flags,
                &pAddr,
                &size);
            }

            if (alloc_status == CUDA_SUCCESS)
            {
                ctx->pmNew->cpuAddrStreamingBuffer = pAddr;
                //Map to GPU physical memory
                flags = DRF_DEF(OS46, _FLAGS, _CACHE_SNOOP, _ENABLE);
                alloc_status = (CUresult)CudaRmMapMemoryDma(
                    rmClient,
                    rmDevice,
                    ctx->pmNew->rmPerfObject,
                    ctx->pmNew->rmPerfMemory,
                    (NvU64)0,
                    (NvU64)ctx->pmNew->sizeStreamingBuffer,
                    flags,
                    &rmDmaOffset);

                if (alloc_status != CUDA_SUCCESS) {
                    CU_ERROR_PRINT(("Fail in mapping the buffer for ModeC/ModeE Streaming.\n"));
                    alloc_status = CUDA_ERROR_UNKNOWN;
                    goto EXIT;
                }
                ctx->pmNew->gpuAddrStreamingBuffer = rmDmaOffset;
                CU_DEBUG_PRINT(("Successfully created the buffer object for ModeC/ModeE Streaming.\n"));
            }
            else
            {
                CU_ERROR_PRINT(("Fail in allocating the buffer for ModeC/ModeE Streaming.\n"));
                alloc_status = CUDA_ERROR_UNKNOWN;
                goto EXIT;
            }
        } else if (alloc_status == (CUresult)NV_ERR_INSUFFICIENT_PERMISSIONS) {
            // http://nvbugs/2463217: alloc_status was returned from CudaRmAlloc(G84_PERFBUFFER)
            // with a non-typesafe cast to CUresult.  Its value is in fact an RM error code.
            // As such, we need to cast it here to quiet the compiler.
            //
            // Failure is most likely due to profiler alloc's being unavailable to
            // non-admin users.  So return that error code rather than genericizing
            // the RM failure code.
            cuprof_retval = CUPROF_ERROR_PROFILER_DISABLED;
            goto EXIT;
        }
    }
#elif cuiPlatformIncludesMrm()
    if(!(ctx->pmNew->isCSSDisabled)
#if defined(NVGPU_IOCTL_CHANNEL_CYCLE_STATS_SNAPSHOT)
        && ctx->device->dm.mrm->nvRmGpuDeviceInfo->hasCycleStatsSnapshot
#endif
      ) {
#if defined(NVGPU_IOCTL_CHANNEL_CYCLE_STATS_SNAPSHOT)
        NvError err;
        int i;
        CUnvchannel *channel;
        NVRM_DEFINE_MEM_HANDLE_ATTR(attr);

        CU_ASSERT(ctx->device->dm.mrm->nvRmDeviceHandle);

        if(!ctx->channelManager) {
            alloc_status = CUDA_ERROR_UNKNOWN;
            goto EXIT;
        }

        for(i = 0; i < CU_CHANNEL_COUNT_MAX; i++) {
            channel = ctx->channelManager->channels[i];
            if(channel && channelIsCompute(channel)) {
                break;
            }
        }

        CU_ASSERT(channel->dm.mrm->nvRmGpuChannel);
        ctx->pmNew->channel = channel;

        memset(&attr, 0, sizeof(NvRmMemHandleAttr));
        attr.Size = ctx->pmNew->sizeStreamingBuffer;
        attr.Coherency = NvOsMemAttribute_WriteBack;
        attr.Tags = NvRmMemTags_Cuda;

        err = NvRmMemHandleAllocAttr(ctx->device->dm.mrm->nvRmDeviceHandle,
                                     &attr,
                                     &ctx->pmNew->memHandler);
        if(err != NvSuccess) {
            CU_ERROR_PRINT(("NvRmMemHandleAllocAttr failed.\n"));
            alloc_status = CUDA_ERROR_UNKNOWN;
            goto EXIT;
        }

        err = NvRmMemMap(ctx->pmNew->memHandler,
                         0,
                         ctx->pmNew->sizeStreamingBuffer,
                         NVOS_MEM_READ_WRITE,
                         &ctx->pmNew->cpuAddrStreamingBuffer);
        if(err != NvSuccess) {
            CU_ERROR_PRINT(("NvRmMemMap failed.\n"));
            alloc_status = CUDA_ERROR_UNKNOWN;
            goto EXIT;
        }

        NvU32 numPerfmonIds = ctx->device->state.limits.physicalTpcCount;

        err = NvRmGpuChannelCycleStatsAttachSnapshot(
                                                channel->dm.mrm->nvRmGpuChannel,
                                                ctx->pmNew->memHandler,
                                                numPerfmonIds,
                                                &ctx->pmNew->perfmonIdStart);
        if(err != NvSuccess) {
            CU_ERROR_PRINT(("NvRmGpuChannelCycleStatsAttachSnapshot "
                            "failed.\n"));
            alloc_status = CUDA_ERROR_UNKNOWN;
            goto EXIT;
        }
        if((ctx->pmNew->perfmonIdStart + numPerfmonIds) >=256) {
            // perfmonId field is 8 bit, we can have maximum 0-255 IDs
            CU_ERROR_PRINT(("NvRmGpuChannelCycleStatsAttachSnapshot "
                            "failed.\n"));
            alloc_status = CUDA_ERROR_UNKNOWN;
            goto EXIT;
        }
#endif
    }
#if defined(NVGPU_DBG_GPU_IOCTL_PERFBUF_MAP)
    else {
        // Keep the old path alive in case we want to compare results
        CUmemobj *memobj = NULL;
        CUmemblock *memblock = NULL;
        CUmemdesc memdesc;
        struct nvgpu_dbg_gpu_perfbuf_map_args dbg_gpu_perfbuf_map = {0};
        int iocResult;

        cuosMemset(&memdesc, 0x0, sizeof(memdesc));
        memdesc.flags.type      = CU_MEM_TYPE_GENERIC;
        memdesc.flags.owner     = CU_MEM_OWNER_DRIVER;
        memdesc.flags.location  = CU_MEM_LOCATION_HOST;
        // Force 40 bit VA as perfmon does not support 49 bit addresses
        memdesc.flags.mapDevice = CU_MEM_MAP_DEVICE_PTR_FORCE_40_BIT;
        memdesc.flags.mapHost   = CU_MEM_MAP_HOST_VA; 
        memdesc.flags.cacheHost = CU_MEM_CACHE_ENABLED_IF_COHERENT;

        alloc_status = memobjAlloc(ctx->memmgr,
                                   &memdesc,
                                   ctx->pmNew->sizeStreamingBuffer,
                                   &memobj);
        if(alloc_status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Fail in allocating the buffer for ModeC/ModeE "
                            "Streaming.\n"));
            alloc_status = CUDA_ERROR_UNKNOWN;
            goto EXIT;
        }

        memblock = memobjGetMemblock(memobj);
        if(!memblock) {
            CU_ERROR_PRINT(("memobjGetMemblock Failed\n"));
            goto EXIT;
        }

#if defined(__QNX__)
        cuprof_retval = qnxProfilerMemGetImportId(ctx->pmNew->memHandler, channelGetDebugInterfaceFd(ctx), &dbg_gpu_perfbuf_map.dmabuf_import_id);

        if(cuprof_retval != CUPROF_SUCCESS) {
            CU_ERROR_PRINT(("Failed to convert an NvRmMemHandle to an import id\n"));
            alloc_status = CUDA_ERROR_UNKNOWN;
            goto EXIT;
        }
#else
        memblock->memmgr->dmal.memblockGetMemHandle(memblock, &dbg_gpu_perfbuf_map.dmabuf_fd);
#endif
        dbg_gpu_perfbuf_map.mapping_size = ctx->pmNew->sizeStreamingBuffer;

        iocResult = CU_IOCTL(channelGetDebugInterfaceFd(ctx),
                             (int)NVGPU_DBG_GPU_IOCTL_PERFBUF_MAP,
                             &dbg_gpu_perfbuf_map);
        if(iocResult == -1) {
            CU_ERROR_PRINT(("ioctl NVGPU_DBG_GPU_IOCTL_PERFBUF_MAP failed, "
                            "error: %s\n",
                            strerror(errno)));
            alloc_status = CUDA_ERROR_UNKNOWN;
            goto EXIT;
        }

        if(!dbg_gpu_perfbuf_map.offset) {
            CU_ERROR_PRINT(("NVGPU_DBG_GPU_IOCTL_PERFBUF_MAP VA offset "
                            "returned zero\n"));
            alloc_status = CUDA_ERROR_UNKNOWN;
            goto EXIT;
        }

        ctx->pmNew->cpuAddrStreamingBuffer = memobjGetHostPtr(memobj);
        ctx->pmNew->gpuAddrStreamingBuffer = dbg_gpu_perfbuf_map.offset;

        if(!ctx->pmNew->gpuAddrStreamingBuffer ||
           !ctx->pmNew->cpuAddrStreamingBuffer) {
            CU_ERROR_PRINT(("Fail in mapping the buffer for ModeC/ModeE "
                            "Streaming. HWPM VA 0x%llx, CPU VA 0x%x\n",
                             ctx->pmNew->gpuAddrStreamingBuffer,
                             PTR2UINT(ctx->pmNew->cpuAddrStreamingBuffer)));
            alloc_status = CUDA_ERROR_UNKNOWN;
            goto EXIT;
        }
        memset(ctx->pmNew->cpuAddrStreamingBuffer, 0xFF, ctx->pmNew->sizeStreamingBuffer);
        CU_DEBUG_PRINT(("Successfully created the buffer object for "
                         "ModeC/ModeE Streaming.\n"));
    }
#endif // defined(NVGPU_DBG_GPU_IOCTL_PERFBUF_MAP)
#else
    // avoid label unused warning if neither RM and MRM are compiled in
    goto EXIT;
#endif // cuiPlatformIncludesMrm()
EXIT:
    // If the cuprof_retval wasn't overwritten above, convert alloc_status to a
    // CUPROF result, and return that.
    if (cuprof_retval == CUPROF_SUCCESS) {
        cuprof_retval = convertCuresultsToProfResult(alloc_status);
    }
    return cuprof_retval;
}

CUprofResult cleanupStreamingResources(CUcontext ctx) {
    CUresult free_status = CUDA_SUCCESS;
    CU_TRACE_FUNCTION();

    if(!ctx->pmNew->cpuAddrStreamingBuffer) {
        return CUPROF_SUCCESS;
    }

#if !cuiPlatformIncludesMrm() && cuiPlatformIncludesRm()
    {
        NvU32 rmClient = 0, rmDevice = 0;

#ifdef WINLH
        if ((cuosIsWindowsVistaPlus() && ctx->device->dmalType == CU_DMAL_RM)) {
            rmClient = globals.rmClient;
            rmDevice = deviceGetHandleRM(ctx->device);
        }
        else {
            rmClient = globals.dm.wddm->wddmRmUserModeClient;
            rmDevice = ctx->device->dm.wddm->wddmRmUserModeDevice;
        }
#else 
        rmClient = globals.rmClient;
        rmDevice = deviceGetHandleRM(ctx->device);
#endif

        ctx->pmNew->cpuAddrStreamingBuffer = NULL;

        if (ctx->pmNew->gpuAddrStreamingBuffer) {
            free_status = (CUresult)CudaRmUnmapMemoryDma(
                            rmClient,
                            rmDevice,
                            ctx->pmNew->rmPerfObject,
                            ctx->pmNew->rmPerfMemory,
                            0,
                            ctx->pmNew->gpuAddrStreamingBuffer);
            if (free_status != CUDA_SUCCESS)
            {
                CU_ERROR_PRINT(("Unable to unmap gpu memory.\n"));
            }
        }

        ctx->pmNew->gpuAddrStreamingBuffer = 0;

        if (ctx->pmNew->rmPerfMemory) {
            free_status = (CUresult)CudaRmFree(
                    rmClient,
                    rmDevice,
                    ctx->pmNew->rmPerfMemory);
            if (free_status != CUDA_SUCCESS)
            {
                CU_ERROR_PRINT(("Unable to free the RmPerfMemory.\n"));
            }
            handlePoolFree(globals.handlePool, ctx->pmNew->rmPerfMemory);
            ctx->pmNew->rmPerfMemory = 0;
        }

        if( ctx->pmNew->rmPerfObject) {
            free_status = (CUresult)CudaRmFree(rmClient,
                rmDevice,
                ctx->pmNew->rmPerfObject);
            if (free_status != CUDA_SUCCESS)
            {
                CU_ERROR_PRINT(("Unable to free the RmPerfObject.\n"));
            }
            handlePoolFree(globals.handlePool, ctx->pmNew->rmPerfObject);
            ctx->pmNew->rmPerfObject = 0;
        }
    }
#elif cuiPlatformIncludesMrm()
    if(!(ctx->pmNew->isCSSDisabled)
#if defined(NVGPU_IOCTL_CHANNEL_CYCLE_STATS_SNAPSHOT)
        && ctx->device->dm.mrm->nvRmGpuDeviceInfo->hasCycleStatsSnapshot
#endif
      ) {
#if defined(NVGPU_IOCTL_CHANNEL_CYCLE_STATS_SNAPSHOT)
        NvError err;

        err = NvRmGpuChannelCycleStatsDetachSnapshot(
                                    ctx->pmNew->channel->dm.mrm->nvRmGpuChannel,
                                    ctx->pmNew->memHandler);
        if(err != NvSuccess) {
            CU_ERROR_PRINT(("NvRmGpuChannelCycleStatsDetachSnapshot "
                            "failed.\n"));
            return CUDA_ERROR_UNKNOWN;
        }

        NvRmMemUnmap(ctx->pmNew->memHandler,
                     ctx->pmNew->cpuAddrStreamingBuffer,
                     ctx->pmNew->sizeStreamingBuffer);

        NvRmMemHandleFree(ctx->pmNew->memHandler);
#endif
    }
#if defined(NVGPU_DBG_GPU_IOCTL_PERFBUF_UNMAP)
    else {
        CUmemobj *memobj = NULL;
        struct nvgpu_dbg_gpu_perfbuf_unmap_args dbg_gpu_perfbuf_unmap = {0};
        int iocResult;

        dbg_gpu_perfbuf_unmap.offset = ctx->pmNew->gpuAddrStreamingBuffer;
        iocResult = CU_IOCTL(channelGetDebugInterfaceFd(ctx),
                             (int)NVGPU_DBG_GPU_IOCTL_PERFBUF_UNMAP,
                             &dbg_gpu_perfbuf_unmap);
        if(iocResult == -1) {
            CU_ERROR_PRINT(("ioctl NVGPU_DBG_GPU_IOCTL_PERFBUF_UNMAP failed, "
                            "error: %s\n",
                            strerror(errno)));
            return CUDA_ERROR_UNKNOWN;
        }

        ctx->pmNew->gpuAddrStreamingBuffer = 0;

        memobj = memobjGetByHostPtr(ctx->memmgr,
                                    ctx->pmNew->cpuAddrStreamingBuffer);

        if(!memobj) {
            CU_ERROR_PRINT(("Invalid host pointer (no memobj)\n"));
            return CUDA_ERROR_UNKNOWN;
        }

        memobjFree(&memobj);

        ctx->pmNew->cpuAddrStreamingBuffer = NULL;

        CU_DEBUG_PRINT(("Successfully released the buffer object for "
                         "ModeC/ModeE Streaming.\n"));
    }
#endif // defined(NVGPU_DBG_GPU_IOCTL_PERFBUF_UNMAP)
#endif // cuiPlatformIncludesMrm()
    return (CUprofResult)free_status;
}

static NvBool domainConfigCompareData(const void *data1, const void *data2) {
    if (((CUdomainConfig *)data1)->domainId == ((CUdomainConfig *)data2)->domainId)
        return NV_TRUE;
    return NV_FALSE;
}

static NvBool compareDomainConfig(CUdomainConfig *currConfig, CUdomainConfig *lastConfig) {
    NvU32 i = 0;
    void *currEventBase = NULL, *lastEventBase = NULL;
    CUeventID *currEvent = NULL, *lastEvent = NULL;

    //Error out early if domain id is not matching
    if (currConfig->domainId != lastConfig->domainId)
        return NV_FALSE;

    //Error out early if number of events are not matching.
    //This means at least one event was added or removed.
    if (currConfig->numEvents != lastConfig->numEvents)
        return NV_FALSE;

    //Compare the event ids in the event list
    currEvent = (CUeventID*)listGetNext(currConfig->eventList, &currEventBase);
    lastEvent = (CUeventID*)listGetNext(lastConfig->eventList, &lastEventBase);

    //Compare in strict order. If order/eventid doesn't match, then return error
    while((i < currConfig->numEvents) && (currEvent) && (lastEvent)) {
        if (*lastEvent != *currEvent) {
            //event id is not matching.
            return NV_FALSE;
        }
        currEvent = (CUeventID*)listGetNext(NULL, &currEventBase);
        lastEvent = (CUeventID*)listGetNext(NULL, &lastEventBase);
        i++;
    }
    //could match all events in the last config.
    return NV_TRUE;
}

CUprofResult perfmonStructCreate(CUperfMonNew **pm)
{
    CUprofResult status = CUPROF_SUCCESS;

    CU_TRACE_FUNCTION();

    *pm = (CUperfMonNew*)malloc(sizeof(CUperfMonNew));
    if (*pm == NULL) {
        CU_ERROR_PRINT(("Failed to allocate memory to ctx perfmon\n"));
        return CUPROF_ERROR_OUT_OF_MEMORY;
    }
    cuosMemset(*pm, 0, sizeof(CUperfMonNew));
    status = (CUprofResult)listInit(&((*pm)->lastDomainConfig), NULL, NULL, NULL, domainConfigCompareData);
    // set default event collection mode
    (*pm)->eventCollectionMode = CUPROF_EVENT_COLLECTION_MODE_KERNEL;

    return status;
}

static void destroyEventList(CUlistHeader *eventList) {
    CUeventID *eventId = NULL;

    if (eventList == NULL)
        return;

    while (1) {
        listGenericRemNodeFromHead(eventList, (void**)&eventId);
        if (eventId) {
            free(eventId);
            eventId =  NULL;
        }
        else {
            break;
        }
    }
    listDestroy(eventList);
}

static void removeAllRecordsFromLastConfiglist(CUperfMonNew *pm)
{
    if (pm->lastDomainConfig) {
        CUdomainConfig *config = NULL;
        while (1) {
            listGenericRemNodeFromHead(pm->lastDomainConfig, (void**)&config);
            if (config) {
                destroyEventList(config->eventList);
                free(config);
                config = NULL;
            }
            else {
                break;
            }
        } //while (config != NULL);
    }
}

CUprofResult perfmonStructDestroy(CUperfMonNew *pm)
{
    CUprofResult status = CUPROF_SUCCESS;

    CU_TRACE_FUNCTION();

    if (pm == NULL)
        return status;

    if (pm->egList) {
        status = (CUprofResult)listDestroy(pm->egList);
    }

    removeAllRecordsFromLastConfiglist(pm);
    listDestroy(pm->lastDomainConfig);

    free(pm);
    return status;
}

CUprofResult perfmonEventGroupResetAllEvents(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;
    CUresult result = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    switch(pEventGroup->domain->eventCollectionMethod) {
        case CUPROF_EVENT_COLLECTION_METHOD_SW:
            if (pEventGroup->isEnabled) {
                CUImemsetDesc desc;
                NvU32 bufferSize = pEventGroup->totalCounters*sizeof(NvU32);

                // build memset descriptor
                memset(&desc, 0, sizeof(desc));
                desc.dptr = (CUdeviceptr_v2)pEventGroup->devSwCounterBuffer;
                desc.value = BUFFER_INIT_VALUE;
                desc.elementSize = sizeof(NvU32);
                desc.width = (size_t)(bufferSize) / sizeof(NvU32);
                desc.height = 1;

                // issue memset
                result = cuiMemsetD(pEventGroup->pCtx, &desc, pEventGroup->pCtx->barrierStream, 0);
                if (CUDA_SUCCESS != result) {
                    CU_ERROR_PRINT(("Memory initialization of sw counter data pBufferPtr failed.\n"));
                    cuiMemFree(pEventGroup->pCtx, pEventGroup->devSwCounterBuffer);
                    status = CUPROF_ERROR_DEVICE_MEMORY;
                    return status;
                }
            }
            break;

        default:
            break;
    }
#if TOOLS_ENABLED
    status = pEventGroup->pCtx->device->hal.prof.perfmonEventGroupResetAllEvents(pEventGroup);
#endif
    return status;
}

#define REMOVE_DOMAIN_SHARING_SAME_HARDWARE(domain1, domain2) \
    do { \
        if ((domain1 == pEventGroup->domainId)) { \
            CUdomainConfig *tempConfig = NULL; \
            void *base = NULL; \
            tempConfig = (CUdomainConfig*)listGetNext(ctx->pmNew->lastDomainConfig, &base); \
            for (; tempConfig; tempConfig = (CUdomainConfig*)listGetNext(NULL, &base)) { \
                if (domain2 == tempConfig->domainId) { \
                    if(tempConfig != listDataRemFrom(ctx->pmNew->lastDomainConfig, tempConfig)) { \
                        CU_ASSERT(0); \
                    } \
                    destroyEventList(tempConfig->eventList); \
                    free(tempConfig); \
                } \
            } \
        } \
    } while (0);

CUprofResult perfmonEventGroupEnable(CUeventGroup *pEventGroup)
{
    CUImemsetDesc memsetDesc;
    CUprofResult status = CUPROF_SUCCESS;
    CUresult result = CUDA_SUCCESS;
    NvU32 bufferSize = 0, i = 0;
    CUctx *ctx = pEventGroup->pCtx;
    CUdomainConfig *currentConfig = NULL, *lastConfig = NULL;
    CUeventInfo *currEvent = NULL;
    void *eventBase = NULL;

    CU_TRACE_FUNCTION();

    if (pEventGroup->isEnabled)
        // event group is already enabled
        return status;

    if (!pEventGroup->totalCounters) {
        //TBD check if this error can be returned,
        //Eventgroup does not have any counter, so don't allow to enable it.
        return CUPROF_ERROR_NOT_READY;
    }

    //By default always configure all registers
    pEventGroup->configChanged = 1;

    //Skip optimization for all registers for tesla and MPS.
    if ((pEventGroup->pCtx->device->state.major > 1) && !cuiGlobalsIsMpsServer() && !cuiGlobalsIsLegacyMpsClient() && !cuiGlobalsIsSubctxMpsClientProcess()) {
        //Create current config
        currentConfig = (CUdomainConfig*) calloc(1, sizeof(CUdomainConfig));
        if (!currentConfig) {
            return CUPROF_ERROR_OUT_OF_MEMORY;
        }
        if ((CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW == pEventGroup->domain->eventCollectionMethod) ||
            (CUPROF_EVENT_COLLECTION_METHOD_PPA_NOPTRIG_SW == pEventGroup->domain->eventCollectionMethod)) {
            if (!pEventGroup->nopTrigSwCounterData) {
                CU_ASSERT(0);
                status = CUPROF_ERROR_UNKNOWN;
                goto EXIT;
            }
            //For software counters that use the nop_trig, the domain id should be
            //set to SMPC domain id
            currentConfig->domainId = pEventGroup->nopTrigSwCounterData->nopTrigDomainId;
        } else {
            currentConfig->domainId = pEventGroup->domainId;
        }
        currentConfig->chipletType = pEventGroup->domain->chipletType;
        currentConfig->method = pEventGroup->domain->eventCollectionMethod;

        if (ctx->pmNew->ctxswModeChanged == NV_TRUE) {
            //if ctxsw mode is changed then the pmctxsw buffer is wiped out, so remove all last configs from the list
            removeAllRecordsFromLastConfiglist(ctx->pmNew);
            //reconfigure this eventgroup
            pEventGroup->configChanged = 1;
            //disable the configchanged flag.
            ctx->pmNew->ctxswModeChanged = NV_FALSE;
        } else {
                if (pEventGroup->pCtx->device->state.major >= 5) {
                //Only for maxwell: bug 1258853
                //Event configuration optimization has to take care of hwpmmux. currently it shares the hardware for HWPM and SMPC.
                //So if HWPM mux is profiled in between 2 same HWPM events or 2 same SMPC events, then the second instance will fail.
                if ((CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX == pEventGroup->domain->eventCollectionMethod)) {
                    CUdomainConfig *tempConfig = NULL;
                    void *base = NULL;

                    tempConfig = (CUdomainConfig*)listGetNext(ctx->pmNew->lastDomainConfig, &base);
                    for (; tempConfig; tempConfig = (CUdomainConfig*)listGetNext(NULL, &base)) {
                        if ((PM_CHIPLET_TYPE_GPC == tempConfig->chipletType) &&
                            (CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX != tempConfig->method)) {
                            //Free all the domain that use SMPC or HWPM hardware from gpc or gcptpc domain.
                            //This has a side effect on kepler that though we don't require to delete the gpc
                            //domain config we will still delete it
                            if(tempConfig != listDataRemFrom(ctx->pmNew->lastDomainConfig, tempConfig)) {
                                CU_ASSERT(0);
                            }
                            //Delete data structures
                            destroyEventList(tempConfig->eventList);
                            free(tempConfig);
                        }
                    }
                }

                if ((PM_CHIPLET_TYPE_GPC == pEventGroup->domain->chipletType) &&
                    (CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX != pEventGroup->domain->eventCollectionMethod)) {
                    CUdomainConfig *tempConfig = NULL;
                    void *base = NULL;

                    tempConfig = (CUdomainConfig*)listGetNext(ctx->pmNew->lastDomainConfig, &base);
                    for (; tempConfig; tempConfig = (CUdomainConfig*)listGetNext(NULL, &base)) {
                        if (tempConfig->method == CUPROF_EVENT_COLLECTION_METHOD_HWPMMUX) {
                            //Free all the domain that use SMPC or HWPM hardware from gpc or gcptpc domain.
                            if(tempConfig != listDataRemFrom(ctx->pmNew->lastDomainConfig, tempConfig)) {
                                CU_ASSERT(0);
                            }
                            //Delete data structures
                            destroyEventList(tempConfig->eventList);
                            free(tempConfig);
                            //There can be only one HWPMMUX config in the list
                            break;
                        }
                    }
                }
            }

            if ((pEventGroup->pCtx->device->state.major == 6) && (pEventGroup->pCtx->device->state.minor == 0)) {
                //To support SM virtualization, new domains are added for core that share the HW. So we need
                //to reconfigure if we see a core domain after coremio and vice versa.
#if NVCFG(GLOBAL_ARCH_PASCAL)
                REMOVE_DOMAIN_SHARING_SAME_HARDWARE(PASCAL_CLK_DOMAIN_GP100_SM_COREMIO, PASCAL_CLK_DOMAIN_GP100_SM_MIO);
                REMOVE_DOMAIN_SHARING_SAME_HARDWARE(PASCAL_CLK_DOMAIN_GP100_SM_MIO, PASCAL_CLK_DOMAIN_GP100_SM_COREMIO);
                REMOVE_DOMAIN_SHARING_SAME_HARDWARE(PASCAL_CLK_DOMAIN_GP100_GPCTPC, PASCAL_CLK_DOMAIN_GP100_GPCTPC_VIRTUAL_CORE);
                REMOVE_DOMAIN_SHARING_SAME_HARDWARE(PASCAL_CLK_DOMAIN_GP100_GPCTPC_VIRTUAL_CORE, PASCAL_CLK_DOMAIN_GP100_GPCTPC);
#endif
            }
        }

        currentConfig->numEvents = pEventGroup->totalCounters;
        status = (CUprofResult)listInit(&currentConfig->eventList, NULL, NULL, NULL, NULL);
        if (status != CUPROF_SUCCESS) {
            status = CUPROF_ERROR_OUT_OF_MEMORY;
            goto EXIT;
        }
        if (pEventGroup->totalCounters) {
            currEvent = (CUeventInfo*)listGetNext(pEventGroup->pEventInfoList, &eventBase);
            for (i = 0; (i < pEventGroup->totalCounters) && currEvent; i++, currEvent = (CUeventInfo*)listGetNext(NULL, &eventBase)) {
                CUeventID *eventId = NULL;
                if (currEvent) {
                    eventId = (CUeventID*)malloc(sizeof(CUeventID));
                    if (eventId == NULL) {
                        status = CUPROF_ERROR_OUT_OF_MEMORY;
                        goto EXIT;
                    }
                    *eventId = ((CUeventDataBasic*)(currEvent->pEventData))->signalId;
                    listAddToHead(currentConfig->eventList, eventId);
                }
            }
        }
        pEventGroup->configChanged = 1;
        //If events are added/removed or the eventgroup is newly created don't try to compare with last config
        lastConfig = (CUdomainConfig *)listFind(ctx->pmNew->lastDomainConfig, currentConfig);
        if (lastConfig == NULL) {
            pEventGroup->configChanged = 1;
            //Store current domain config as last domain config
        } else {
            if(compareDomainConfig(currentConfig, lastConfig) == NV_FALSE) {
                pEventGroup->configChanged = 1;
            } else {
                pEventGroup->configChanged = 0;
            }
        }
    }

    switch(pEventGroup->domain->eventCollectionMethod) {
        case CUPROF_EVENT_COLLECTION_METHOD_SW:
            bufferSize = pEventGroup->totalCounters*sizeof(NvU32);
            result = cuiMemAlloc(
                        ctx,
                        bufferSize,
                        &pEventGroup->devSwCounterBuffer,
                        NV_FALSE,
                        CU_MEM_MAP_DEVICE_PTR);
            if (CUDA_SUCCESS != result) {
                CU_ERROR_PRINT(("Memory allocation for sw counters data failed.\n"));
                status = CUPROF_ERROR_DEVICE_MEMORY;
                goto EXIT;
            }

            // build memset descriptor
            memset(&memsetDesc, 0, sizeof(memsetDesc));
            memsetDesc.dptr = (CUdeviceptr_v2)pEventGroup->devSwCounterBuffer;
            memsetDesc.value = BUFFER_INIT_VALUE;
            memsetDesc.elementSize = sizeof(NvU32);
            memsetDesc.width = (size_t)bufferSize / sizeof(NvU32);
            memsetDesc.height = 1;

            // issue memset
            result = cuiMemsetD(ctx, &memsetDesc, ctx->barrierStream, 0);
            if (CUDA_SUCCESS != result) {
                CU_ERROR_PRINT(("Memory initialization of sw counter data pBufferPtr failed.\n"));
                cuiMemFree(ctx, pEventGroup->devSwCounterBuffer);
                status = CUPROF_ERROR_DEVICE_MEMORY;
                goto EXIT;
            }
#if TOOLS_ENABLED
            status = ctx->device->hal.prof.perfmonEventGroupEnable(pEventGroup);
#endif
            if (CUPROF_SUCCESS != status) {
                cuiMemFree(ctx, pEventGroup->devSwCounterBuffer);
                goto EXIT;
            }

            ctx->pmNew->patchFlag = CU_PROF_PATCH_FLAG_SW_COUNTER;
            break;

        case CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW:
#if TOOLS_ENABLED
            status = ctx->device->hal.prof.perfmonEventGroupEnable(pEventGroup);
#endif
            if (CUPROF_SUCCESS != status) {
                goto EXIT;
            }

            ctx->pmNew->patchFlag = CU_PROF_PATCH_FLAG_NOPTRIG_SW_COUNTER;
            break;

        default:
#if TOOLS_ENABLED
            status = ctx->device->hal.prof.perfmonEventGroupEnable(pEventGroup);
#endif
            break;
    }
    if (status == CUPROF_SUCCESS) {
        if ((pEventGroup->configChanged) && (pEventGroup->pCtx->device->state.major > 1)) {
            //current config is not same as the last config so remove lastConfig from list
            //and add currentConfig as lastConfig.
            if (lastConfig) {
                if(lastConfig != listDataRemFrom(ctx->pmNew->lastDomainConfig, lastConfig)) {
                   CU_ASSERT(0);
                }
                //Delete data structures
                destroyEventList(lastConfig->eventList);
                free(lastConfig);
            }
            if (currentConfig) {
                status = (CUprofResult)listAddToTail(ctx->pmNew->lastDomainConfig, currentConfig);
                if (status != CUPROF_SUCCESS) {
                    CU_ASSERT(0);
                    goto EXIT;
                }
            }
            return status;
        }
        else {
            goto EXIT;
        }
    }
EXIT:
    if (currentConfig) {
        destroyEventList(currentConfig->eventList);
        free(currentConfig);
        currentConfig = NULL;
    }
    return status;
}

CUprofResult perfmonEventGroupReadEvent(CUeventGroup          *pEventGroup,
                                         CUprof_ReadEventFlags flags,
                                         CUprof_EventID        eventID,
                                         size_t                *bufferSizeBytes,
                                         NvU64                 *counterData)
{
    CUImemsetDesc memsetDesc;
    CUprofResult status = CUPROF_SUCCESS;
    CUresult result = CUDA_SUCCESS;
    CUtask *pTask = NULL;
    CUmemobj *srcMemobj = NULL;
    NvU64 srcOffsetInMemobj = 0;
    NvU32 bufferSize = 0;
    int *bufferPtr = NULL;
    void *eventBase = NULL;
    NvU32 i = 0, instancesProfiled = 0;
    NvU32 eventVal;

    CU_TRACE_FUNCTION();

    CU_ASSERT(bufferSizeBytes && counterData);

    if (!pEventGroup->isEnabled) {
        // don't allow read-events for disabled event group
        return CUPROF_ERROR_INVALID_OPERATION;
    }

    if ((pEventGroup->totalCounters == 0) || (*bufferSizeBytes < sizeof(NvU64))) {
        *bufferSizeBytes = 0;
        return CUPROF_SUCCESS;
    }

    instancesProfiled = pEventGroup->instanceCountAvail;
    if (!pEventGroup->profileAll) {
        instancesProfiled = 1;
    }
    if (*bufferSizeBytes < (sizeof(uint64_t)* instancesProfiled)) {
        return CUPROF_ERROR_PARAMETER_SIZE_NOT_SUFFICIENT;
    }

    switch(pEventGroup->domain->eventCollectionMethod) {
        case CUPROF_EVENT_COLLECTION_METHOD_SW:
            {
                CUeventInfo *currEvent = NULL;
                void *pEventDataTemp = NULL;
                bufferSize = sizeof(NvU32);
                bufferPtr = (int*)(pEventGroup->devSwCounterBuffer) ;

                currEvent = (CUeventInfo*)listGetNext(pEventGroup->pEventInfoList, &eventBase);
                for (i = 0; (i < pEventGroup->totalCounters) && currEvent; i++, currEvent = (CUeventInfo*)listGetNext(NULL, &eventBase)) {
                    pEventDataTemp = currEvent->pEventData;
                    if (((CUeventDataBasic*)pEventDataTemp)->signalId == eventID) {
                        break;
                    }
                    bufferPtr++;
                }

                if (i == pEventGroup->totalCounters) {
                    CU_ERROR_PRINT(("Invalid event-id %d\n", (int)eventID));
                    return CUPROF_ERROR_INVALID_EVENT_ID;
                }

                srcMemobj = memobjGetByDevicePtrRange(pEventGroup->pCtx->memmgr, (NvU64)(uintptr_t)bufferPtr,
                                                      bufferSize, &srcOffsetInMemobj);
                if (!srcMemobj) {
                    CU_DEBUG_PRINT(("Could not find src memobj\n"));
                    CU_ERROR_PRINT(("Copying buffer from DtoH for sw counters data failed.\n"));
                    cuiMemFree(pEventGroup->pCtx, pEventGroup->devSwCounterBuffer);
                    return CUPROF_ERROR_DEVICE_MEMORY;
                }

                // Reading only one sw counter from device
                // Here eventVal is used because destination buffer is changed to NvU64
                // and source buffer is NvU32. Also, size of memcopy is sizeof(NvU32)
                result = cuiMemcpyDtoH(
                    pEventGroup->pCtx,
                    &eventVal,
                    srcMemobj,
                    srcOffsetInMemobj,
                    (unsigned int)bufferSize,
                    pEventGroup->pCtx->barrierStream,
                    CUI_MEMCPY_SYNCHRONOUS,
                    pTask);
                if (CUDA_SUCCESS != result) {
                    CU_ERROR_PRINT(("Copying buffer from DtoH for sw counters data failed.\n"));
                    cuiMemFree(pEventGroup->pCtx, pEventGroup->devSwCounterBuffer);
                    return CUPROF_ERROR_DEVICE_MEMORY;
                }
                pEventGroup->values[i] = eventVal;

                // build memset descriptor
                memset(&memsetDesc, 0, sizeof(memsetDesc));
                memsetDesc.dptr = (CUdeviceptr_v2)bufferPtr;
                memsetDesc.value = BUFFER_INIT_VALUE;
                memsetDesc.elementSize = sizeof(NvU32);
                memsetDesc.width = (size_t)bufferSize / sizeof(NvU32);
                memsetDesc.height = 1;

                // issue memset
                result = cuiMemsetD(pEventGroup->pCtx, &memsetDesc, pEventGroup->pCtx->barrierStream, 0);
                if (CUDA_SUCCESS != result) {
                    CU_ERROR_PRINT(("Memory initialization of sw counter data pBufferPtr failed.\n"));
                    cuiMemFree(pEventGroup->pCtx, pEventGroup->devSwCounterBuffer);
                    status = CUPROF_ERROR_DEVICE_MEMORY;
                    return status;
                }
                break;
            }
        default:
            break;
    }
#if TOOLS_ENABLED
    status = pEventGroup->pCtx->device->hal.prof.perfmonEventGroupReadEvent(pEventGroup, flags, eventID,
                                                                        bufferSizeBytes, counterData);
#endif
    return status;
}

CUprofResult perfmonEventGroupReadAllEvents(CUeventGroup *pEventGroup,
                                             CUprof_ReadEventFlags  flags,
                                             size_t                 *bufferSizeBytes,
                                             NvU64                  *counterDataBuffer,
                                             size_t                 *arraySizeBytes,
                                             CUprof_EventID         *eventIDArray,
                                             size_t                 *numCountersRead)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUresult result = CUDA_SUCCESS;
    CUtask *pTask = NULL;
    CUmemobj *srcMemobj = NULL;
    CUImemsetDesc memsetDesc;
    NvU64 srcOffsetInMemobj = 0;
    NvU32 bufferSize = 0, instancesProfiled = 0;
    NvU32 *tempBuf;
    NvU32 i;

    CU_TRACE_FUNCTION();

    CU_ASSERT(bufferSizeBytes && counterDataBuffer);
    CU_ASSERT(numCountersRead);

    if (!pEventGroup->isEnabled) {
        // don't allow read-events for disabled event group
        return CUPROF_ERROR_INVALID_OPERATION;
    }

    if ((pEventGroup->totalCounters == 0) || (*bufferSizeBytes < sizeof(NvU64))) {
        *bufferSizeBytes = 0;
        *arraySizeBytes = 0;
        *numCountersRead = 0;
        return CUPROF_SUCCESS;
    }

    instancesProfiled = pEventGroup->instanceCountAvail;
    if (!pEventGroup->profileAll) {
        instancesProfiled = 1;
    }
    if ((*bufferSizeBytes < (sizeof(uint64_t)* pEventGroup->totalCounters * instancesProfiled)) ||
        (*arraySizeBytes < (pEventGroup->totalCounters * sizeof (CUprof_EventID)))) {
        return CUPROF_ERROR_PARAMETER_SIZE_NOT_SUFFICIENT;
    }

    switch(pEventGroup->domain->eventCollectionMethod) {
        case CUPROF_EVENT_COLLECTION_METHOD_SW:
            bufferSize = pEventGroup->totalCounters*sizeof(NvU32);

            srcMemobj = memobjGetByDevicePtrRange(pEventGroup->pCtx->memmgr, (NvU64)(uintptr_t)pEventGroup->devSwCounterBuffer,
                                                  bufferSize, &srcOffsetInMemobj);
            if (!srcMemobj) {
                CU_DEBUG_PRINT(("Could not find src memobj\n"));
                CU_ERROR_PRINT(("Copying buffer from DtoH for sw counters data failed.\n"));
                cuiMemFree(pEventGroup->pCtx, pEventGroup->devSwCounterBuffer);
                return CUPROF_ERROR_DEVICE_MEMORY;
            }

            tempBuf = (NvU32 *)malloc(bufferSize);
            if (tempBuf == NULL) {
                CU_ERROR_PRINT(("Memory allocation for temp buffer failed.\n"));
                cuiMemFree(pEventGroup->pCtx, pEventGroup->devSwCounterBuffer);
                return CUPROF_ERROR_OUT_OF_MEMORY;
            }
            // Here tempBuf is used because destination buffer is changed to NvU64
            // and source buffer is NvU32. Also, size of memcopy is totalCounters*sizeof(NvU32)
            result = cuiMemcpyDtoH(
                pEventGroup->pCtx,
                tempBuf,
                srcMemobj,
                srcOffsetInMemobj,
                (unsigned int)bufferSize,
                pEventGroup->pCtx->barrierStream,
                CUI_MEMCPY_SYNCHRONOUS,
                pTask);
            if (CUDA_SUCCESS != result) {
                CU_ERROR_PRINT(("Copying buffer from DtoH for sw counters data failed.\n"));
                cuiMemFree(pEventGroup->pCtx, pEventGroup->devSwCounterBuffer);
                free(tempBuf);
                return CUPROF_ERROR_DEVICE_MEMORY;
            }
            // Copy 32-bit counter values to 64-bit buffer
            for(i = 0; i < pEventGroup->totalCounters; i++)
                pEventGroup->values[i] = tempBuf[i];
            free(tempBuf);
            if(pEventGroup->pCtx->pmNew->eventCollectionMode == CUPROF_EVENT_COLLECTION_MODE_CONTINUOUS) {
                /***********************************************************************************************
                In case of Kernel mode, the buffer is reset even before patching. Hence, no need to do
                    memset again for kernel mode.
                ***********************************************************************************************/
                // build memset descriptor
                memset(&memsetDesc, 0, sizeof(memsetDesc));
                memsetDesc.dptr = (CUdeviceptr_v2)pEventGroup->devSwCounterBuffer;
                memsetDesc.value = BUFFER_INIT_VALUE;
                memsetDesc.elementSize = sizeof(NvU32);
                memsetDesc.width = (size_t)bufferSize / sizeof(NvU32);
                memsetDesc.height = 1;

                // issue memset
                result = cuiMemsetD(pEventGroup->pCtx, &memsetDesc, pEventGroup->pCtx->barrierStream, 0);
                if (CUDA_SUCCESS != result) {
                    CU_ERROR_PRINT(("Memory initialization of sw counter data pBufferPtr failed.\n"));
                    cuiMemFree(pEventGroup->pCtx, pEventGroup->devSwCounterBuffer);
                    status = CUPROF_ERROR_DEVICE_MEMORY;
                    return status;
                }
            }
            break;

        default:
            break;
    }
#if TOOLS_ENABLED
    status = pEventGroup->pCtx->device->hal.prof.perfmonEventGroupReadAllEvents(pEventGroup,
                                                             CUPROF_READ_EVENT_FLAG_NONE,
                                                             bufferSizeBytes,
                                                             counterDataBuffer,
                                                             arraySizeBytes,
                                                             eventIDArray,
                                                             numCountersRead);
#endif
    return status;
}

CUprofResult perfmonEventGroupDisable(CUeventGroup *pEventGroup) {
    CUprofResult status = CUPROF_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!(pEventGroup->isEnabled)) {
        // event group is already disabled
        return status;
    }
    switch(pEventGroup->domain->eventCollectionMethod) {
        case CUPROF_EVENT_COLLECTION_METHOD_SW:
            cuiMemFree(pEventGroup->pCtx, pEventGroup->devSwCounterBuffer);
            pEventGroup->devSwCounterBuffer = NULL;
            pEventGroup->pCtx->pmNew->patchFlag = 0;
            break;
        case CUPROF_EVENT_COLLECTION_METHOD_NOPTRIG_SW:
            pEventGroup->pCtx->pmNew->patchFlag = 0;
        default:
            break;
    }
#if TOOLS_ENABLED
    status = pEventGroup->pCtx->device->hal.prof.perfmonEventGroupDisable(pEventGroup);
#endif
    return status;
}


CUprofResult
perfmonGetSignalDesc(CUprof_EventID eventId,
                     SignalDescriptionTable **pSignalDesc_out,
                     NvBool *bFound)
{
    CUprofResult status = CUPROF_SUCCESS;
    SignalDescriptionTable *pSignalDesc = NULL;
    NvU32 idx = 0;

    CU_TRACE_FUNCTION();

    perfmonDemangleStrings();

    *bFound = NV_FALSE;

// __TEMP_WAR__ Bug 200347107
#if cuiNvcfgEnabledFermiOrHigher()
    // eventId will always be >= FERMI_FIRST_SIGNAL_ID (as FERMI_FIRST_SIGNAL_ID = 0)
    if (eventId < TESLA_FIRST_SIGNAL_ID  ||
        SIG_DEVICE_ARCH_IS_FERMI(eventId)) {
        pSignalDesc = pFermiSignalDescriptionArray;
    }
#endif
#if NVCFG(GLOBAL_ARCH_KEPLER)
    else if (((eventId >= KEPLER_FIRST_SIGNAL_ID) && (eventId < MAXWELL_FIRST_SIGNAL_ID)) ||
        SIG_DEVICE_ARCH_IS_KEPLER(eventId)) {
            pSignalDesc = pKeplerSignalDescriptionArray;
    }
#endif
#if NVCFG(GLOBAL_ARCH_MAXWELL)
    else if (SIG_DEVICE_ARCH_IS_MAXWELL(eventId)) {
        pSignalDesc = pMaxwellSignalDescriptionArray;
    }
#endif
#if NVCFG(GLOBAL_ARCH_PASCAL)
    else if (SIG_DEVICE_ARCH_IS_PASCAL(eventId)) {
        pSignalDesc = pPascalSignalDescriptionArray;
    }
#endif
#if NVCFG(GLOBAL_ARCH_VOLTA)
    else if (SIG_DEVICE_ARCH_IS_VOLTA(eventId)) {
        pSignalDesc = pVoltaSignalDescriptionArray;
    }
#endif
    if (pSignalDesc == NULL) {
        CU_ERROR_PRINT(("Signal description table not found for event %d\n", eventId));
        return CUPROF_ERROR_UNKNOWN;
    }

    while (pSignalDesc[idx].signalId != INVALID_PM_SIGNAL_NEW) {
        if (pSignalDesc[idx].signalId == eventId) {
            *bFound = NV_TRUE;
            *pSignalDesc_out = &pSignalDesc[idx];
            return status;
        }
        idx++;
    }

    return CUPROF_SUCCESS;
}

CUprofResult
perfmonInitEventDomainData(CUprof_EventDomainID eventDomain)
{
    CUprofResult status = CUPROF_SUCCESS;
    void *pSignal = NULL;
    CUdomainData *pDomainData = NULL;
    NvU32 maxInternalSignals = 0;
    NvU32 maxExternalSignals = 0;
    NvBool internalCountersExposed = 0;
    NvBool bFound = NV_FALSE;
    unsigned int old;
    NvU32 signalTableIdx = 0, signalTableEntrySize = 0;

    CU_TRACE_FUNCTION();

    status = perfmonGetEventDomainData(eventDomain, &pDomainData, &bFound);
    if (status != CUPROF_SUCCESS) {
        return status;
    }

    if (pDomainData->bInit) {
        // domain data is already populated
        return CUPROF_SUCCESS;
    }

    old = cuosInterlockedExchange(&pDomainData->bInitStarted, 1);
    if (old == 0) {

        perfmonDemangleStrings();

        internalCountersExposed = perfmonInternalCountersExposed();

        maxExternalSignals = maxInternalSignals = 0;
        for(signalTableIdx = 0; signalTableIdx < pDomainData->numPerfSignalTables; signalTableIdx++) {

            perfmonGetSizeOfSignalTableEntry(pDomainData->pEventTableInfo[signalTableIdx].signalTableType,
                                             &signalTableEntrySize);

            pSignal = pDomainData->pEventTableInfo[signalTableIdx].pEventData;
            if (pSignal != NULL) {
                while (((CUeventDataBasic*)pSignal)->signalId != INVALID_PM_SIGNAL_NEW) {
                    // Increment for only EXPOSED type of signals:
                    if (SIG_TYPE_IS_EXPOSED(((CUeventDataBasic*)pSignal)->signalId)) {
                        maxExternalSignals++;
                    }
                    // Increment for exposed but internal and internally exposed for testing type signals:
                    else if (!SIG_TYPE_IS_INTERNAL(((CUeventDataBasic*)pSignal)->signalId)) {
                        maxInternalSignals++;
                    }
                    pSignal = (void*)((NvU8*)pSignal + signalTableEntrySize);
                }
            }
        }
        pDomainData->maxExternalEvents = maxExternalSignals;
        pDomainData->maxInternalEvents = maxInternalSignals;

        if(internalCountersExposed) {
            pDomainData->exposedEvents = maxExternalSignals + maxInternalSignals;
        }
        else {
            pDomainData->exposedEvents = maxExternalSignals;
        }
        cuosInterlockedIncrement(&pDomainData->bInit);
    }
    else {
        // Another thread has started initialization, all other threads
        // must wait until it has completed.
        while (pDomainData->bInit == 0) {
            cuosThreadYield();
        }
    }

    return status;
}

CUprofResult
perfmonGetEventDomainData(CUprof_EventDomainID eventDomain,
                          CUdomainData **pDomainData_out,
                          NvBool *bFound)
{
    CUprofResult status = CUPROF_SUCCESS;
    CUdomainInfo *pDomainInfo = NULL;
    CUdomainData *pDomainData = NULL;
    NvU32 domInfoIdx = 0;
    NvU32 domDataIdx = 0;
    NvBool internalDomainsExposed = 0;

    CU_TRACE_FUNCTION();

    *bFound = NV_FALSE;

    perfmonDemangleStrings();

    // check if internal domains are to be exposed
    internalDomainsExposed = perfmonInternalCountersExposed();

    for (domInfoIdx = 0; domInfoIdx < sizeof(g_DomainInfo) / sizeof(g_DomainInfo[0]); domInfoIdx++) {
        pDomainInfo = g_DomainInfo[domInfoIdx];
        for (domDataIdx = 0; domDataIdx < pDomainInfo->numDomains; domDataIdx++) {
            pDomainData = &pDomainInfo->pDomainTable[domDataIdx];
            if (!internalDomainsExposed &&
                !strncmp(pDomainData->domainName, PM_INTERNAL_SIGNAL_PREFIX, 2))
            {
                // skip internal domain
                continue;
            }
            if (pDomainData->domainId == eventDomain) {
                *bFound = NV_TRUE;
                *pDomainData_out = pDomainData;
                return status;
            }
        }
    }

    return CUPROF_ERROR_INVALID_EVENT_DOMAIN_ID;
}

#if USE_POWER_API
CUprofResult perfmonControlPowerState(CUctx *ctx, NvBool bDisable)
{
    CUresult status = CUDA_SUCCESS;
    CUprofResult profStatus = CUPROF_SUCCESS;

    CU_TRACE_FUNCTION();

    cuiMutexLock(&globals.profilerMutex);
    if (bDisable) {
        if (globals.powerStateRefCount[ctx->device->state.deviceIdx] == 0) {
            CU_DEBUG_PRINT(("Disabling Power/Clock Gating\n"));
            status = ctx->device->dmal.deviceChangePowerState( ctx, NV2080_CTRL_GPU_SET_POWER_TARGET_ENGINE_GR, NV2080_CTRL_GPU_SET_POWER_STATE_ENGINE_LEVEL_FULLPOWER);
            if (status != CUDA_SUCCESS) {
                goto Exit;
            }
            globals.powerStateRefCount[ctx->device->state.deviceIdx]++;
        }
        else {
            globals.powerStateRefCount[ctx->device->state.deviceIdx]++;
            CU_DEBUG_PRINT(("Power/Clock Gating is already disabled by some other context.\n"));
            profStatus = CUDA_SUCCESS;
        }
    }
    else {
        globals.powerStateRefCount[ctx->device->state.deviceIdx]--;
        if (globals.powerStateRefCount[ctx->device->state.deviceIdx] == 0) {
            CU_DEBUG_PRINT(("Enabling Power/Clock Gating\n"));
            status = ctx->device->dmal.deviceChangePowerState( ctx, NV2080_CTRL_GPU_SET_POWER_TARGET_ENGINE_GR, NV2080_CTRL_GPU_SET_POWER_STATE_ENGINE_LEVEL_AUTOMATIC);
            if (status != CUDA_SUCCESS) {
                // do nothing
            }
        }
    }

Exit:
    cuiMutexUnlock(&globals.profilerMutex);

    if (status != CUDA_SUCCESS) {
        profStatus = CUPROF_ERROR_HARDWARE;
    }

    return profStatus;
}

#else
// Function to change power state
CUprofResult perfmonControlPowerState(CUctx *ctx, NvBool bDisable)
{
    CUresult status = CUDA_SUCCESS;
    CUprofResult profStatus = CUPROF_SUCCESS;

    CU_TRACE_FUNCTION();

    cuiMutexLock(&globals.profilerMutex);
    if (bDisable) {
        if (ctx->device->state.profilerState.powerStateRefCount == 0) {
            CU_DEBUG_PRINT(("Disabling Power/Clock Gating\n"));
            status = ctx->device->dmal.deviceReservePerfmonHw( ctx, NV_TRUE );
            if (status != CUDA_SUCCESS) {
                goto Exit;
            }
            ctx->device->state.profilerState.powerStateRefCount++;
        }
        else {
            ctx->device->state.profilerState.powerStateRefCount++;
            CU_DEBUG_PRINT(("Power/Clock Gating is already disabled by some other context.\n"));
            profStatus = CUPROF_SUCCESS;
        }
    }
    else {
        ctx->device->state.profilerState.powerStateRefCount--;
        if (ctx->device->state.profilerState.powerStateRefCount == 0) {
            CU_DEBUG_PRINT(("Enabling Power/Clock Gating\n"));
            status = ctx->device->dmal.deviceReservePerfmonHw( ctx, NV_FALSE );
            if (status != CUDA_SUCCESS) {
                // do nothing
            }
        }
    }

Exit:
    cuiMutexUnlock(&globals.profilerMutex);

    if (status != CUDA_SUCCESS) {
        profStatus = CUPROF_ERROR_HARDWARE;
    }

    return profStatus;
}
#endif

// function to acquire/release control of PM HW
// The refcounts used in this function are as follows:
//    perfmonHWReservedRefCount:
//      This is incremented/decremented for any context profiling HWPM signals
//    powerStateRefCount:
//      This is incremented/decremented for any context profiling SMPC signals or concurrent kernel trace
CUprofResult perfmonControl(CUctx *ctx, NvBool bAcquire, NvBool isHWPM)
{
    CUresult status = CUDA_SUCCESS;
    CUprofResult profStatus = CUPROF_SUCCESS;

    CU_TRACE_FUNCTION();

    cuiMutexLock(&globals.profilerMutex);

    // Old perfmon call for reservation does not allow multi-ctx scenario
    // Explicitly disable PM Ctxsw:
    cuosSetEnv("CUDA_ENABLE_PM_CTXSW_MODE", "0");

    // CUPTI controls the HWPM itself. However, this function is used to reserve perfmon HW
    //    in case if Toolkit version < R5.5. Hence, commenting out this part (Bug 1408976)
#if 0
    if (globals.profileMode == CUPROF_PROFILE_MODE_CUPTI) {
        CU_DEBUG_PRINT(("CUPTI is the profiler. Skipping all HWPM control calls.\n"));
        status = CUDA_SUCCESS;
        goto Exit;
    }
#endif

    if (bAcquire) {
        if(isHWPM) {
            if (ctx->device->state.profilerState.ctxHWPMOwner == NULL) {
                CU_DEBUG_PRINT(("Acquiring control of PMHW.\n"));
                if(ctx->device->state.profilerState.powerStateRefCount == 0) {
                    status = ctx->device->dmal.deviceReservePerfmonHw( ctx, NV_TRUE );
                    if (status != CUDA_SUCCESS) {
                        goto Exit;
                    }
                }
                ctx->device->state.profilerState.ctxHWPMOwner = ctx;
                ctx->pmNew->perfmonHWReservedRefCount++;
            }
            else if (ctx == ctx->device->state.profilerState.ctxHWPMOwner) {
                CU_DEBUG_PRINT(("PMHW is already acquired by same context.\n"));
                // increment refcount
                ctx->pmNew->perfmonHWReservedRefCount++;
            }
            else {
                CU_ERROR_PRINT(("PMHW is acquired by some other context.\n"));
                profStatus = CUPROF_ERROR_HARDWARE;
            }
        }
        else {
            if((ctx->device->state.profilerState.powerStateRefCount == 0) && (ctx->device->state.profilerState.ctxHWPMOwner == NULL)) {
                status = ctx->device->dmal.deviceReservePerfmonHw( ctx, NV_TRUE );
                if (status != CUDA_SUCCESS) {
                    //This should not fail ideally unless some other tool has acquired perfmonControl
                    CU_ERROR_PRINT(("PMHW is already acquired by some other process or tool!!!\n"));
                    CU_ASSERT(0);
                    goto Exit;
                }
            }
            ctx->device->state.profilerState.powerStateRefCount++;
        }
    }
    else {
        if(isHWPM) {
            if (ctx->device->state.profilerState.ctxHWPMOwner == ctx) {
                ctx->pmNew->perfmonHWReservedRefCount--;
                // if refcount is zero, release the PM HW
                if (ctx->pmNew->perfmonHWReservedRefCount == 0) {
                    CU_DEBUG_PRINT(("Releasing control of PMHW.\n"));
                    if(ctx->device->state.profilerState.powerStateRefCount == 0) {
                        status = ctx->device->dmal.deviceReservePerfmonHw( ctx, NV_FALSE );
                        if (status != CUDA_SUCCESS) {
                            // do nothing
                        }
                    }
                    ctx->device->state.profilerState.ctxHWPMOwner = NULL;
                }
            }
        }
        else {
            ctx->device->state.profilerState.powerStateRefCount--;
            if((ctx->device->state.profilerState.powerStateRefCount == 0) && (ctx->device->state.profilerState.ctxHWPMOwner == NULL)) {
                status = ctx->device->dmal.deviceReservePerfmonHw( ctx, NV_FALSE );
                if (status != CUDA_SUCCESS) {
                    goto Exit;
                }
            }
        }
    }

Exit:
    cuiMutexUnlock(&globals.profilerMutex);

    if (status != CUDA_SUCCESS) {
        if (status == CUDA_ERROR_PROFILER_DISABLED) {
            profStatus = CUPROF_ERROR_PROFILER_DISABLED;
        } else {
            profStatus = CUPROF_ERROR_HARDWARE;
        }
    }

    return profStatus;
}

CUprofResult perfmonGetSizeOfSignalTableEntry(CUPerfSignalTableType signalTableType,
                                  NvU32 *size)
{
    switch(signalTableType)
    {
    case PERF_SIG_TABLE_TYPE_COMMON:
        *size = sizeof(CUeventData);
        break;
    case PERF_SIG_TABLE_TYPE_HWPM:
        *size = sizeof(CUeventDataHwpm);
        break;
    case PERF_SIG_TABLE_TYPE_NVLINK:
        *size = sizeof(PerfSignalNvLink);
        break;
    case PERF_SIG_TABLE_TYPE_SMPC:
        *size = sizeof(CUeventDataSmpc);
        break;
    case PERF_SIG_TABLE_TYPE_HWPM_EXPT:
        *size = sizeof(CUeventDataHwpmExpt);
        break;
    case PERF_SIG_TABLE_TYPE_HWPM_EXPT_V1:
        *size = sizeof(CUeventDataHwpmExpt_v1);
        break;
    case PERF_SIG_TABLE_TYPE_HWPMMUX:
        *size = sizeof(CUeventDataHwpmMux);
        break;
    case PERF_SIG_TABLE_TYPE_MULTI_GROUP:
    case PERF_SIG_TABLE_TYPE_LUT:
        *size = sizeof(CUeventDataSmpcExpt);
        break;
    case PERF_SIG_TABLE_TYPE_NVLINK_THROUGHPUT_CNTR:
        *size = sizeof(CUeventDataNvlinkThroughputCounters);
        break;
    case PERF_SIG_TABLE_TYPE_SMPC_EXPERIMENT:
        *size = sizeof(CUeventDataSmpcExpt_v1);
        break;
    case PERF_SIG_TABLE_TYPE_HWPM_VIRTUAL_EXPT:
        *size = sizeof(CUeventDataHwpmVirtualExpt);
        break;
    case PERF_SIG_TABLE_TYPE_CUPTI_SW:
        *size = sizeof(PerfSignalCUPTIsw);
        break;
    default:
        CU_ASSERT(0);
        return CUPROF_ERROR_UNKNOWN;
    }
    return CUPROF_SUCCESS;
}

static void perfmonDemangleStringTable (const char *arr[])
{
    int cnt;
    for (cnt=0; arr[cnt] != NULL; cnt++) {
        char *str = (char *)arr[cnt];
        __PERFMON_DEMANGLE_STRING(str, str);
   }

}

#if NVCFG(GLOBAL_ARCH_FERMI)
extern const char *__fermi_signals_strings[];
#endif
#if NVCFG(GLOBAL_ARCH_KEPLER)
extern const char *__kepler_signals_strings[];
#endif
#if NVCFG(GLOBAL_ARCH_MAXWELL)
extern const char *__maxwell_signals_strings[];
#endif
#if NVCFG(GLOBAL_ARCH_PASCAL)
extern const char *__pascal_signals_strings[];
#endif
#if NVCFG(GLOBAL_ARCH_VOLTA)
extern const char *__volta_signals_strings[];
#endif

void perfmonDemangleStrings (void)
{
    static unsigned int volatile initialized = 0;
    int old;

    old = cuosInterlockedExchange(&initialized, 1);

    if (old==1) return;
#if NVCFG(GLOBAL_ARCH_FERMI)
    perfmonDemangleStringTable (__fermi_signals_strings);
#endif
#if NVCFG(GLOBAL_ARCH_KEPLER)
    perfmonDemangleStringTable (__kepler_signals_strings);
#endif
#if NVCFG(GLOBAL_ARCH_MAXWELL)
    perfmonDemangleStringTable (__maxwell_signals_strings);
#endif
#if NVCFG(GLOBAL_ARCH_PASCAL)
    perfmonDemangleStringTable (__pascal_signals_strings);
#endif
#if NVCFG(GLOBAL_ARCH_VOLTA)
    perfmonDemangleStringTable (__volta_signals_strings);
#endif
}

int perfmonInternalCountersExposed (void)
{
    static char mangledInternalsEnvName[]=__MANGLED_CUDA_PROFILER_INTERNAL;
    int rc = 0;
    char internalsEnvName[CUOS_ENV_VAR_LENGTH];
    char envVar[CUOS_ENV_VAR_LENGTH];

    __PERFMON_DEMANGLE_STRING(mangledInternalsEnvName, internalsEnvName);

    if(!cuosGetEnv(internalsEnvName, envVar, CUOS_ENV_VAR_LENGTH))
        rc = atoi(envVar);

    return rc;
}

int perfmonPmCtxswEnabled (void)
{
    static char mangledInternalsEnvName[]=MANGLED_CUDA_ENABLE_PM_CTXSW_MODE;
    int rc = 1;         // The feature is enabled by default
    char internalsEnvName[CUOS_ENV_VAR_LENGTH];
    char envVar[CUOS_ENV_VAR_LENGTH];

    __PERFMON_DEMANGLE_STRING(mangledInternalsEnvName, internalsEnvName);

    if(!cuosGetEnv(internalsEnvName, envVar, CUOS_ENV_VAR_LENGTH))
        rc = atoi(envVar);

    return rc;
}

int perfmonCssDisabled (void)
{
    int rc = 1;         // CSS is disabled by default
#if defined(NVGPU_IOCTL_CHANNEL_CYCLE_STATS_SNAPSHOT)
    static char mangledInternalsEnvName[]=MANGLED_CUDA_DISABLE_CSS;
    char internalsEnvName[CUOS_ENV_VAR_LENGTH];
    char envVar[CUOS_ENV_VAR_LENGTH];

    __PERFMON_DEMANGLE_STRING(mangledInternalsEnvName, internalsEnvName);

    if(!cuosGetEnv(internalsEnvName, envVar, CUOS_ENV_VAR_LENGTH))
        rc = atoi(envVar);
#endif
    return rc;
}

/*
#define DRF_SHIFT(drf)          ((0?drf) % 32)
#define DRF_MASK(drf)           (0xFFFFFFFF>>(31-((1?drf) % 32)+((0?drf) % 32)))
#define DRF_SHIFTMASK(drf)      (DRF_MASK(drf)<<(DRF_SHIFT(drf)))
#define DRF_REPLACE(a, b, drf)  (((a) & ~DRF_SHIFTMASK(drf)) | (((b) & DRF_MASK(drf)) << DRF_SHIFT(drf)))
#define DRF_READV(a, drf)       (((a) >> DRF_SHIFT(drf)) & DRF_MASK(drf))
*/
CUprofResult perfmonControlPowerGatingProfilerClass(CUctx *ctx, NvU32 hProfilerObj, NvBool bDisable)
{
    CUprofResult res;
    uint32_t controlMask, statusMask;
    uint32_t flag;

    if (hProfilerObj == 0) {
        return CUPROF_ERROR_NOT_INITIALIZED;
    }

    controlMask = 0;
    statusMask = 0;
    if (bDisable) {
        controlMask = DRF_REPLACE(controlMask, CU_TOOLS_PROF_CLASS_PG_CONTROL_MASK_ELPG_DISABLE, CU_TOOLS_PROF_CLASS_PG_CONTROL_MASK_ELPG);
        flag = CU_TOOLS_PROF_CLASS_RESERVE;
    } else {
        controlMask = DRF_REPLACE(controlMask, CU_TOOLS_PROF_CLASS_PG_CONTROL_MASK_ELPG_RELEASE, CU_TOOLS_PROF_CLASS_PG_CONTROL_MASK_ELPG);
        flag = CU_TOOLS_PROF_CLASS_RELEASE;
    }

    res = toolsProfilerClassControlPowerGating(ctx->device,
                                              ctx,
                                              hProfilerObj,
                                              controlMask,
                                              &statusMask,
                                              flag);

    if ((res != CUPROF_SUCCESS) && (res != CUPROF_ERROR_NOT_SUPPORTED)) {
        return res;
    }

    if (DRF_READV(statusMask, CU_TOOLS_PROF_CLASS_PG_CONTROL_MASK_ELPG) == CU_TOOLS_PROF_CLASS_PG_CONTROL_MASK_ELPG_REQUEST_REJECTED ||
        DRF_READV(statusMask, CU_TOOLS_PROF_CLASS_PG_CONTROL_MASK_ELPG) == CU_TOOLS_PROF_CLASS_PG_CONTROL_MASK_ELPG_REQUEST_FAILED) {
        return CUPROF_ERROR_IN_USE;
    }

    return CUPROF_SUCCESS;
}

CUprofResult perfmonControlClockGatingProfilerClass(CUctx *ctx, NvU32 hProfilerObj, NvBool bDisable)
{
    CUprofResult res;
    uint32_t controlMask, statusMask;
    uint32_t flag;

    if (hProfilerObj == 0) {
        return CUPROF_ERROR_NOT_INITIALIZED;
    }

    controlMask = 0;
    statusMask = 0;
    if (bDisable) {
        controlMask = DRF_REPLACE(controlMask, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_ELCG_DISABLE, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_ELCG);
        controlMask = DRF_REPLACE(controlMask, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_BLCG_DISABLE, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_BLCG);
        controlMask = DRF_REPLACE(controlMask, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_SLCG_DISABLE, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_SLCG);
        flag = CU_TOOLS_PROF_CLASS_RESERVE;
    } else {
        controlMask = DRF_REPLACE(controlMask, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_ELCG_RELEASE, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_ELCG);
        controlMask = DRF_REPLACE(controlMask, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_BLCG_RELEASE, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_BLCG);
        controlMask = DRF_REPLACE(controlMask, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_SLCG_RELEASE, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_SLCG);
        flag = CU_TOOLS_PROF_CLASS_RELEASE;
    }
    res = toolsProfilerClassControlClockGating(ctx->device,
                                              ctx,
                                              hProfilerObj,
                                              controlMask,
                                              &statusMask,
                                              flag);

    if ((res != CUPROF_SUCCESS) && (res != CUPROF_ERROR_NOT_SUPPORTED)) {
        return res;
    }

    if (DRF_READV(statusMask, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_ELCG) == CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_ELCG_REQUEST_REJECTED ||
        DRF_READV(statusMask, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_ELCG) == CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_ELCG_REQUEST_FAILED ||
        DRF_READV(statusMask, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_BLCG) == CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_BLCG_REQUEST_REJECTED ||
        DRF_READV(statusMask, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_BLCG) == CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_BLCG_REQUEST_FAILED ||
        DRF_READV(statusMask, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_SLCG) == CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_SLCG_REQUEST_REJECTED ||
        DRF_READV(statusMask, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_SLCG) == CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_SLCG_REQUEST_FAILED) {
        return CUPROF_ERROR_IN_USE;
    }

    return CUPROF_SUCCESS;
}

CUprofResult perfmonControlThermalSettingsProfilerClass(CUctx *ctx, NvU32 hProfilerObj, NvBool bDisable)
{
    CUprofResult res;
    uint32_t controlMask, statusMask;
    uint32_t flag;

    if (hProfilerObj == 0) {
        return CUPROF_ERROR_NOT_INITIALIZED;
    }

    controlMask = 0;
    statusMask = 0;
    if (bDisable) {
        controlMask = DRF_REPLACE(controlMask, CU_TOOLS_PROF_CLASS_THERMAL_CONTROL_MASK_IDLE_SLOWDOWN_DISABLE, CU_TOOLS_PROF_CLASS_THERMAL_CONTROL_MASK_IDLE_SLOWDOWN);
        flag = CU_TOOLS_PROF_CLASS_RESERVE;
    } else {
        controlMask = DRF_REPLACE(controlMask, CU_TOOLS_PROF_CLASS_THERMAL_CONTROL_MASK_IDLE_SLOWDOWN_RELEASE, CU_TOOLS_PROF_CLASS_THERMAL_CONTROL_MASK_IDLE_SLOWDOWN);
        flag = CU_TOOLS_PROF_CLASS_RELEASE;
    }
    res = toolsProfilerClassControlThermalSettings(ctx->device,
                                              ctx,
                                              hProfilerObj,
                                              controlMask,
                                              &statusMask,
                                              flag);
    if ((res != CUPROF_SUCCESS) && (res != CUPROF_ERROR_NOT_SUPPORTED)) {
        return res;
    }

    if (DRF_READV(statusMask, CU_TOOLS_PROF_CLASS_THERMAL_CONTROL_MASK_IDLE_SLOWDOWN) == CU_TOOLS_PROF_CLASS_THERMAL_CONTROL_MASK_IDLE_SLOWDOWN_REQUEST_REJECTED ||
        DRF_READV(statusMask, CU_TOOLS_PROF_CLASS_THERMAL_CONTROL_MASK_IDLE_SLOWDOWN) == CU_TOOLS_PROF_CLASS_THERMAL_CONTROL_MASK_IDLE_SLOWDOWN_REQUEST_FAILED) {
        return CUPROF_ERROR_IN_USE;
    }

    return CUPROF_SUCCESS;
}

CUprofResult perfmonControlVatProfilerClass(CUctx *ctx, NvU32 hProfilerObj, NvBool bDisable)
{
    CUprofResult res;
    uint32_t controlMask, statusMask;
    uint32_t flag;

    if (hProfilerObj == 0) {
        return CUPROF_ERROR_NOT_INITIALIZED;
    }

    controlMask = 0;
    statusMask = 0;
    if (bDisable) {
        controlMask = DRF_REPLACE(controlMask, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_VAT_DISABLE, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_VAT);
        flag = CU_TOOLS_PROF_CLASS_RESERVE;
    } else {
        controlMask = DRF_REPLACE(controlMask, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_VAT_RELEASE, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_VAT);
        flag = CU_TOOLS_PROF_CLASS_RELEASE;
    }
    res = toolsProfilerClassControlVat(ctx->device,
                                       ctx,
                                       hProfilerObj,
                                       controlMask,
                                       &statusMask,
                                       flag);
    if ((res != CUPROF_SUCCESS) && (res != CUPROF_ERROR_NOT_SUPPORTED)) {
        return res;
    }

    if (DRF_READV(statusMask, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_VAT) == CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_VAT_REQUEST_REJECTED ||
        DRF_READV(statusMask, CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_VAT) == CU_TOOLS_PROF_CLASS_CG_CONTROL_MASK_VAT_REQUEST_FAILED) {
        return CUPROF_ERROR_IN_USE;
    }

    return CUPROF_SUCCESS;
}

CUprofResult perfmonControlPerfmonHWProfilerClass(CUctx *ctx, NvU32 hProfilerObj, NvBool bAcquire)
{
    NvU32 flag;

    if (hProfilerObj == 0) {
        return CUPROF_ERROR_NOT_INITIALIZED;
    }

    (bAcquire) ? (flag = CU_TOOLS_PROF_CLASS_RESERVE) : (flag = CU_TOOLS_PROF_CLASS_RELEASE);

    return toolsProfilerClassControlPerfmon(ctx->device,
                                          ctx,
                                          hProfilerObj,
                                          flag);

}

// function to set/reset PM context switch bit
CUprofResult perfmonSetupPMCtxswMode(CUctx *ctx, NvBool bEnable)
{
    CUresult status = CUDA_SUCCESS;
    CUprofResult profStatus = CUPROF_SUCCESS;

    CU_TRACE_FUNCTION();
    if (!isPmCtxswSupported(ctx)) {
        return CUPROF_SUCCESS;
    }
    if ((bEnable && !ctx->pmNew->isPmCtxswModeEnabled) || (!bEnable && ctx->pmNew->isPmCtxswModeEnabled)) {
        status = ctx->device->dmal.deviceSetPMCtxswMode( ctx, bEnable);
        if (status == CUDA_SUCCESS) {
            ctx->pmNew->isPmCtxswModeEnabled = bEnable;
            //If the ctxsw mode is changed then the pm ctxsw buffer is wiped out with 0
            ctx->pmNew->ctxswModeChanged = NV_TRUE;
            ctx->pmNew->perfmonTriggerRefCount = 0;
        }
    }
    if (status != CUDA_SUCCESS) {
        profStatus = CUPROF_ERROR_HARDWARE;
    }
    return profStatus;
}

uint8_t profilingModeDevice()
{

    static char mangledInternalsEnvName[] = MANGLED_CUDA_PROFILER_MODE_DEVICE;
    char internalsEnvName[CUOS_ENV_VAR_LENGTH];
    char envVar[CUOS_ENV_VAR_LENGTH];

    // By default, profiling mode device is disabled.
    uint8_t rc = 0;

    // Demangled environment variable is: CUDA_PROFILER_MODE_DEVICE.
    __PERFMON_DEMANGLE_STRING(mangledInternalsEnvName, internalsEnvName);

    if(!(cuosGetEnv(internalsEnvName, envVar, CUOS_ENV_VAR_LENGTH)))
    {
        rc = atoi(envVar);
    }
    return rc;
}

// Function to get profiling scope of an event.
CUprofResult getExposedEventProfilingScope(CUprof_EventID eventID, NvU32 *scope)
{
    CUprofResult profStatus             = CUPROF_SUCCESS;
    CUdomainInfo *pDomainInfo           = NULL;
    CUdomainData *pDomainData           = NULL;
    NvU32 domInfoIdx                    = 0;
    NvU32 domDataIdx                    = 0;
    uint32_t sigTableIdx                = 0;
    uint32_t internalCountersExposed    = 0;
    uint32_t j                          = 0;
    void *tempEventData                 = NULL;
    CUprof_EventID signalId             = 0;
    NvU32 signalTableEntrySize          = 0;

    // Iterate through all chips for domains.
    for (domInfoIdx = 0; domInfoIdx < sizeof(g_DomainInfo) / sizeof(g_DomainInfo[0]); domInfoIdx++) {
        pDomainInfo = g_DomainInfo[domInfoIdx];

        // Iterate through domains in a chip.
        for (domDataIdx = 0; domDataIdx < pDomainInfo->numDomains; domDataIdx++) {
            pDomainData = &pDomainInfo->pDomainTable[domDataIdx];

            // Initialize domain data.
            profStatus = perfmonInitEventDomainData(pDomainData->domainId);
            if(profStatus != CUPROF_SUCCESS) {
            // If domain does not have any event, then,
            // API perfmonInitEventDomainData() returns CUPROF_ERROR_INVALID_EVENT_DOMAIN_ID error.
            // It is safe to by-pass error.
                if (profStatus == CUPROF_ERROR_INVALID_EVENT_DOMAIN_ID) {
                    continue;
                }
                return profStatus;
            }

            internalCountersExposed = perfmonInternalCountersExposed();

            // Iterate through all Signal Tables in a domain
            for(sigTableIdx = 0; sigTableIdx < pDomainData->numPerfSignalTables; sigTableIdx++) {
                perfmonGetSizeOfSignalTableEntry(pDomainData->pEventTableInfo[sigTableIdx].signalTableType,
                                                 &signalTableEntrySize);

                tempEventData = pDomainData->pEventTableInfo[sigTableIdx].pEventData;

                if(internalCountersExposed) {
                    signalId = (CUprof_EventID) ((CUeventDataBasic*)tempEventData)->signalId;
                    while(signalId != INVALID_PM_SIGNAL_NEW)
                    {
                        if(!SIG_TYPE_IS_INTERNAL(signalId)) {
                            if (signalId == eventID) {
                                goto FOUND;
                            }
                        }
                        tempEventData = (void *)((NvU8 *)tempEventData + signalTableEntrySize);
                        signalId = (CUprof_EventID) ((CUeventDataBasic*)tempEventData)->signalId;
                    }
                }
                else {
                    signalId = (CUprof_EventID) ((CUeventDataBasic*)tempEventData)->signalId;
                    while(signalId != INVALID_PM_SIGNAL_NEW)
                    {
                        if(SIG_TYPE_IS_EXPOSED(signalId)) {
                            if (signalId == eventID) {
                                goto FOUND;
                            }
                        }
                        tempEventData = (void *)((NvU8 *)tempEventData + signalTableEntrySize);
                        signalId = (CUprof_EventID) ((CUeventDataBasic*)tempEventData)->signalId;
                    }
                }

            }

        }
    }

    // If couldn't find the domain/signal, return ERROR.
    // Ideally, following statement shouldn't happen for exposed counters.
    return CUPROF_ERROR_INVALID_EVENT_ID;

FOUND:
    *scope = pDomainData->eventCollectionScope;
    return profStatus;
}
