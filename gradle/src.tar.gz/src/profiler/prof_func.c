/*
 * Copyright 1993-2009 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 *
*/

#include "prof_func.h"
#include "cuimemset.h"

// structure to keep track of instr to be patched and
// counted using sw counters
typedef struct CUinstToBeCounted_st {
    NvBool enabled;             // Flag to determine if inst is to be patched and counted
    void *bufferPtr;            // Address of sw counter corresponding to the instr
    NvS32 associatedNopTrig;    // Associated NOP.TRIG with the instruction
    NvU32 patchAddr;            // Relative address where commmon routine is added at end of kernel
    NvBool instPresent;         // Keeps track of whether instruction is present in the kernel or not
}CUinstToBeCounted;

// Function to dump the modified and original SASS in a file
// For debugging purpose
#ifdef DEBUG_SASS
void 
funcPatchDumpSASSpatch(NvU32 *origCode, NvU32 origCodeSize, NvU32 *patchedCode, NvU32 patchedCodeSize) {
    FILE *f, *f1;
    unsigned int i;

    f = fopen ("cubin.txt", "wb");
    f1 = fopen ("cubinOrig.txt", "wb");

    for ( i = 0; i < patchedCodeSize/4; i++)
        fwrite((patchedCode + i), sizeof(NvU32), 1,f );
    fclose(f);

    for ( i = 0; i < origCodeSize/4; i++)
        fwrite((origCode + i), sizeof(NvU32), 1,f1 );
    fclose(f1);
}
#endif

CUresult initProfilerHal(CUctx *ctx, profilerHal** profHal_ptr)
{
    CUresult status = CUDA_SUCCESS;
    profilerHal *profHal = *profHal_ptr;
    unsigned int smVersion;
    smVersion = ctx->device->state.major*10 + ctx->device->state.minor;
    profHal->swCounterTablePtr = NULL;
    profHal->sassInstGenPtr = NULL;

    profHal->patchFlag = ctx->pmNew->patchFlag;

    if(smVersion >= 20) {
        profHal->swCounterTablePtr = (swCounterTable*)calloc(1, sizeof(swCounterTable));
        if (!profHal->swCounterTablePtr) {
            CU_ERROR_PRINT(("Fail to allocate memory for swCounterTablePtr\n"));
            return CUDA_ERROR_OUT_OF_MEMORY;
        }
    }

#if NVCFG(GLOBAL_ARCH_FERMI)
    if((smVersion < 30) && (smVersion >=20)) {
        status = fermiInitProfilerHal(profHal, smVersion);
        if(status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("fermiInitProfilerHal failed.\n"));
        }
    }
#endif
#if NVCFG(GLOBAL_ARCH_KEPLER)
    else if((smVersion <= 37) && (smVersion >=30)) {
        status = keplerInitProfilerHal(profHal, smVersion, ctx->device->state.chip);
        if(status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("keplerInitProfilerHal failed.\n"));
        }
    }
#endif // NVCFG(GLOBAL_ARCH_KEPLER)
    else {
        CU_DEBUG_PRINT(("Invalid SM Version\n"));
        status = CUDA_ERROR_UNKNOWN;
    }
    return status;
}

void destroyProfilerHal(profilerHal** profHal_ptr)
{
    // Call other architecture specific functions 
    // so that HAL can finalize any allocations
    // it may have made as part of its intialization
    profilerHal *profHal = *profHal_ptr;
    if(profHal->swCounterTablePtr) {
        free(profHal->swCounterTablePtr);
        profHal->swCounterTablePtr = NULL;
    }
    free(profHal);
}

// Function that determines instr to be patched and counted based on the sw counters
// selected by the user.
static CUresult getInstToBeCounted(profilerHal *profilerHalPtr, CUeventGroup *pEventGroup, CUinstToBeCounted *instToBeCounted, NvU32 isFermiDevice) {

    unsigned int i = 0, j, maxCountersPerEventGroup;
    int *bufferPtr = NULL;
    CUeventInfo *currEvent = NULL;
    void *pEventDataTemp = NULL;
    void *eventBase = NULL;
    int index;
    swCounterTable *swCounterTablePtr = profilerHalPtr->swCounterTablePtr;

    if(isFermiDevice) {
        maxCountersPerEventGroup = FERMI_MAX_SW_COUNTER_PER_EVENTGROUP;
    }
    else {
        maxCountersPerEventGroup = KEPLER_MAX_SW_COUNTER_PER_EVENTGROUP;
    }


    bufferPtr = (int*)(pEventGroup->devSwCounterBuffer) ;

    currEvent = (CUeventInfo*)listGetNext(pEventGroup->pEventInfoList, &eventBase);
    for (i = 0; (i < pEventGroup->totalCounters) && currEvent; i++, currEvent = (CUeventInfo*)listGetNext(NULL, &eventBase)) {
        pEventDataTemp = currEvent->pEventData;
        switch(currEvent->signalTableType)
        {
        case PERF_SIG_TABLE_TYPE_COMMON:
            index = swCounterTablePtr->getPMSignalsIndex(((CUeventData*)pEventDataTemp)->signalId);
            if(index != -1) {
                instToBeCounted[index].enabled    = NV_TRUE;
                instToBeCounted[index].bufferPtr  = bufferPtr;
                if(profilerHalPtr->patchFlag & CU_PROF_PATCH_FLAG_NOPTRIG_SW_COUNTER) {
                    for(j = 0; j < maxCountersPerEventGroup; j++) {
                        if(((CUeventData*)pEventDataTemp)->signalId == pEventGroup->nopTrigSwCounterData->signalID[j]) {
                            break;
                        }
                    }
                    if(j == maxCountersPerEventGroup) {
                        CU_ERROR_PRINT(("Could not find signalID in nopTrigSwCounterData structure.\n"));
                        return CUDA_ERROR_UNKNOWN;
                    }
                    instToBeCounted[index].associatedNopTrig = j + 8; // + 8 to use internal nop_trig_xx signals starting from 08
                }
            }
            break;
        case PERF_SIG_TABLE_TYPE_SMPC:
            index = swCounterTablePtr->getPMSignalsIndex(((CUeventDataSmpc*)pEventDataTemp)->signalId);
            if(index != -1) {
                instToBeCounted[index].enabled    = NV_TRUE;
                instToBeCounted[index].bufferPtr  = bufferPtr;
                if(profilerHalPtr->patchFlag & CU_PROF_PATCH_FLAG_NOPTRIG_SW_COUNTER) {
                    for(j = 0; j < maxCountersPerEventGroup; j++) {
                        if(((CUeventDataSmpc*)pEventDataTemp)->signalId == pEventGroup->nopTrigSwCounterData->signalID[j]) {
                            break;
                        }
                    }
                    if(j == maxCountersPerEventGroup) {
                        CU_ERROR_PRINT(("Could not find signalID in nopTrigSwCounterData structure.\n"));
                        return CUDA_ERROR_UNKNOWN;
                    }
                    instToBeCounted[index].associatedNopTrig = j + 8; // + 8 to use internal nop_trig_xx signals starting from 08
                }
            }
            break;
        default:
            return CUDA_ERROR_UNKNOWN;
        }
        bufferPtr++;
    }
    return CUDA_SUCCESS;
}

// Function that counts the occurrence of the instrs that need to be patched.
// Based on the occurrence the memory for patched code is allocated.
void static getNumInstOccurrence(profilerHal *profilerHalPtr, CUinstToBeCounted *instToBeCounted, const CUfunc *func, NvU32 *patchSize, int isFermiDevice) {
    int funcCodeSize;
    unsigned int *code;
    NvU64 opcode= 0;
    int i;
    NvBool canUseAddrWindows;
    int index;
    swCounterTable *swCounterTablePtr = profilerHalPtr->swCounterTablePtr;

    funcCodeSize = func->codeSize/4;
    *patchSize = 0;

    code = (unsigned int*)cuiFuncGetCodeData(func, CU_CODE_DATA_MASTER);

    for (i = 0; i < funcCodeSize; ) {
        if(isFermiDevice && CU_FERMI_IS_32B_INSTR(code[i])) {
            // If its 32bit instruction, continue
            i += 1;
        }
        else {
            opcode = ((NvU64)(*(NvU64*)(code+i)));
            index = swCounterTablePtr->getOpcodeIndex(opcode, &canUseAddrWindows);
            if(index != -1) {
                if (instToBeCounted[index].enabled) {
                    if(profilerHalPtr->patchFlag & CU_PROF_PATCH_FLAG_NOPTRIG_SW_COUNTER) {
                        if(!instToBeCounted[index].instPresent) {
                            instToBeCounted[index].instPresent = NV_TRUE;
                             // Append common routine at the end of the kernel if not added before
                            *patchSize += swCounterTablePtr->commonRoutinePatchSize;
                        }
                    }
                    if(canUseAddrWindows == NV_TRUE) {
                        *patchSize += swCounterTablePtr->genericAnyAddrWindowPatchSize;
                    }
                    else {
                        *patchSize += swCounterTablePtr->globalAddrWindowPatchSize;
                    }
                    profilerHalPtr->swCounterTablePtr->numInstPatched++;
                }
            }
            i +=2;
        }
    }

}

// Function that creates the patched code that contains code patches for all the
// sw counters selected by the user.
static 
CUresult createPatchCodeForSwCounters(profilerHal *profilerHalPtr, CUctx* ctx, CUfunc* func, NvU32 *patchSize,
                                      NvU32** patchCode, CUinstToBeCounted *instToBeCounted, int isFermiDevice) {
    CUresult status = CUDA_SUCCESS;
    NvU32 i;
    NvU32 funcCodeSize;
    unsigned int *code;
    NvU64 opcode = 0;
    NvU32 lmemAddress = LMEM_HI_SCRATCH;
    NvU32 codeEnd = 0; // Updated each time instructions are added to patchCode
    NvU32 *pCodeEnd; // Pointer to point at codeEnd
    NvBool canUseAddrWindows;
    int index;
    NvU32 instPatched = 0;
    NvU64 funcStartPC;
    NvU32 numPadInstRequired = 0;

    swCounterTable *swCounterTablePtr = profilerHalPtr->swCounterTablePtr;
    sassInstGen *sassInstGenPtr = profilerHalPtr->sassInstGenPtr;

    code = (unsigned int*)cuiFuncGetCodeData(func, CU_CODE_DATA_MASTER);

    funcCodeSize = func->codeSize/4;

    // The WAR is not on fermi
    if(!isFermiDevice) {
        // Add NOP at the end of the patch to make the size of patch a multiple of 64 bytes
        numPadInstRequired = (CEIL_TO_MULTIPLE_OF_64(*patchSize) - *patchSize)/sizeof(NvU64);

        if(!numPadInstRequired) {
            // Fill the next cache line with BRA + 7NOPS
            *patchSize = *patchSize + sizeof(NvU64)*8;
            numPadInstRequired = 8;
        }
        else {
            *patchSize = CEIL_TO_MULTIPLE_OF_64(*patchSize);
        }
    }

    *patchCode = (NvU32*)malloc((*patchSize));
    if(!(*patchCode)) {
        CU_DEBUG_PRINT(("Failed to allocate storage for patchCode.\n"));
        status = CUDA_ERROR_OUT_OF_MEMORY;
        return status;
    }

    swCounterTablePtr->relocPcPtr = (relocPc*)malloc(swCounterTablePtr->numInstPatched*sizeof(relocPc));
    if(!(swCounterTablePtr->relocPcPtr)) {
        CU_ERROR_PRINT(("Failed to allocate storage for pcMapping Array.\n"));
        status = CUDA_ERROR_OUT_OF_MEMORY;
        return status;
    }

    pCodeEnd = *patchCode;

    // Add common NOP.TRIG routine at start of patch
    if(profilerHalPtr->patchFlag & CU_PROF_PATCH_FLAG_NOPTRIG_SW_COUNTER) {
        for(i = 0; i < TOTAL_INST; i++) {
            if(instToBeCounted[i].enabled && instToBeCounted[i].instPresent) {
                instToBeCounted[i].patchAddr = codeEnd;
                swCounterTablePtr->insertNopTrigBasedPatch(swCounterTablePtr, sassInstGenPtr, pCodeEnd,
                            lmemAddress, NV_TRUE, (int)pow(2, instToBeCounted[i].associatedNopTrig));
                codeEnd += swCounterTablePtr->commonRoutinePatchSize;
                pCodeEnd += (swCounterTablePtr->commonRoutinePatchSize/4);
            }
        }
    }

    funcStartPC = ctx->device->hal.funcGetStartPC(func);

    for (i = 0; i < funcCodeSize; ) {
        if(isFermiDevice && CU_FERMI_IS_32B_INSTR(code[i])) {
            // If its 32bit instruction, increment by 4byte only
            i += 1;
        }
        else {
            opcode = ((NvU64)(*(NvU64*)(code+i)));
            index = swCounterTablePtr->getOpcodeIndex(opcode, &canUseAddrWindows);
            if(index != -1 && instToBeCounted[index].enabled) {
                swCounterTablePtr->relocPcPtr[instPatched].origInstPc = i*sizeof(NvU32);
                swCounterTablePtr->relocPcPtr[instPatched].patchCodeFirstInstPc = codeEnd;
                if(profilerHalPtr->patchFlag & CU_PROF_PATCH_FLAG_SW_COUNTER) {
                    swCounterTablePtr->insertAtomInstBasedPatch(swCounterTablePtr, sassInstGenPtr, code[i], code[i + 1], 
                        instToBeCounted[index].bufferPtr, 
                        lmemAddress, i*sizeof(unsigned int), funcStartPC, pCodeEnd, canUseAddrWindows);
                }
                else {
                    swCounterTablePtr->insertPatchPerInstOccurence(swCounterTablePtr, sassInstGenPtr, 
                        code[i], code[i + 1], lmemAddress, i*sizeof(unsigned int), 
                        codeEnd, funcStartPC, pCodeEnd, instToBeCounted[index].patchAddr, canUseAddrWindows);
                }
                if(canUseAddrWindows == NV_TRUE) {
                    codeEnd += swCounterTablePtr->genericAnyAddrWindowPatchSize;
                    pCodeEnd += (swCounterTablePtr->genericAnyAddrWindowPatchSize/4);
                }
                else {
                    codeEnd += swCounterTablePtr->globalAddrWindowPatchSize;
                    pCodeEnd += (swCounterTablePtr->globalAddrWindowPatchSize/4);
                }
                instPatched++;
            }
            i +=2;
        }
    }

    profilerHalPtr->funcInsertICachePadding(sassInstGenPtr, pCodeEnd, numPadInstRequired);
    pCodeEnd = NULL;

#ifdef DEBUG_SASS
    funcPatchDumpSASSpatch((NvU32 *)cuiFuncGetCodeData(func, CU_CODE_DATA_MASTER), func->codeSize, *patchCode, *patchSize);
#endif

    return status;
}

// Top level Function that modifies code to collect sw counters
CUresult funcCollectSwCounters(CUctx* ctx, CUfunc* func, profilerHal *profilerHalPtr, NvU32** patchCode, NvU32* patchSize)
{
    CUresult status = CUDA_SUCCESS;
    CUeventGroup *pEventGroup = ctx->pmNew->egSwCounters;
    unsigned int i = 0;
    CUinstToBeCounted instToBeCounted[TOTAL_INST];
    int isFermiDevice = 0;
    unsigned int smVersion;
    smVersion = ctx->device->state.major*10 + ctx->device->state.minor;

    // Check if patchSize is a valid pointer:
    if(patchSize == NULL) {
        return CUDA_ERROR_UNKNOWN;
    }

    if(smVersion >=20 && smVersion < 30) {
        isFermiDevice = 1;
    }
    for (i=0 ; i< TOTAL_INST; i++) {
        instToBeCounted[i].enabled = NV_FALSE;
        instToBeCounted[i].bufferPtr = NULL;
        instToBeCounted[i].patchAddr = 0;
        instToBeCounted[i].instPresent = NV_FALSE;
        instToBeCounted[i].associatedNopTrig = -1;
    }

    status = getInstToBeCounted(profilerHalPtr, pEventGroup, instToBeCounted, isFermiDevice);
    if(CUDA_SUCCESS != status) {
        return status;
    }
    getNumInstOccurrence(profilerHalPtr, instToBeCounted, func, patchSize, isFermiDevice);
    if(*patchSize == 0) {
        // Nothing to patch in the kernel
        return CUDA_SUCCESS;
    }
    status = createPatchCodeForSwCounters(profilerHalPtr, ctx, func, patchSize, patchCode, instToBeCounted, isFermiDevice);
    if(CUDA_SUCCESS != status) {
        CU_ERROR_PRINT(("createPatchCodeForSwCounters failed.\n"));
    }
    return status;
}
