/*
* Copyright 1993-2009 by NVIDIA Corporation.  All rights reserved.  All
* information contained herein is proprietary and confidential to NVIDIA
* Corporation.  Any use, reproduction, or disclosure without the written
* permission of NVIDIA Corporation is prohibited.
*/

/******************************************************************************
*
*   Module: utils.h
*
*   Description:
*       utility routines header file
*
******************************************************************************/
#ifndef __UTILS_H__
#define __UTILS_H__

#include <string.h>
#include <cuda.h>
#include <stdio.h>
#include "nvtypes.h"
#include "cuda_stdint.h"

/******************************************************
* Generic linked list declaration
*******************************************************/

typedef struct CUnode_st CUnode;
typedef struct CUlistHeader_st CUlistHeader;

// linked list node
struct CUnode_st {
    void *data;
    struct CUnode_st *next;
};

// linked list header
struct CUlistHeader_st {
    size_t numElements;
    CUnode *head;
    CUnode *tail;
    CUresult (*addToHead)(CUlistHeader *hdr, void *data);
    CUresult (*addToTail)(CUlistHeader *hdr, void *data);
    CUresult (*remFrom)  (CUlistHeader *hdr, void *data);
    NvBool (*compareData)(const void *data1, const void *data2);
};

// linked list routines
CUresult listInit(CUlistHeader **hdr,  
                  CUresult (*addToHead)(CUlistHeader *hdr, void *data),
                  CUresult (*addToTail)(CUlistHeader *hdr, void *data),
                  CUresult (*remFrom)  (CUlistHeader *hdr, void *data),
                  NvBool (*compareData)(const void *data1, const void *data2));
CUresult listRemoveAllNodes(CUlistHeader *hdr);
CUresult listDestroy(CUlistHeader *hdr);
CUresult listAddToHead(CUlistHeader *hdr, void *data);
CUresult listAddToTail(CUlistHeader *hdr, void *data);
static CUresult listGenericAddToHead(CUlistHeader *hdr, void *data);
static CUresult listGenericAddToTail(CUlistHeader *hdr, void *data);
CUresult listRemFrom(CUlistHeader *hdr, void *data);
static CUresult listGenericRemFrom(CUlistHeader *hdr, void *data);
void* listDataRemFrom(CUlistHeader *hdr, void *data);
void* listFind(CUlistHeader *hdr, void *data);
void* listAtIndex(CUlistHeader *hdr, const size_t index);
void* listGetNext(CUlistHeader *hdr, void **nodeBase);
CUresult listGenericRemNodeFromHead(CUlistHeader *hdr, void **data);
size_t listLen(CUlistHeader *hdr);

#endif // __UTILS_H__
