/* 
* Copyright 2011 by NVIDIA Corporation.  All rights reserved.  All
* information contained herein is proprietary and confidential to NVIDIA
* Corporation.  Any use, reproduction, or disclosure without the written
* permission of NVIDIA Corporation is prohibited.
*/

/******************************************************************************
*
*   Module: profiler_common.c
*
*   Description:
*       profiler specific common routines
*
******************************************************************************/

#include "cuda_internal.h"
#include "profiler_common.h"
#include "perfmon_internals.h"

NvBool profModeCompatible(int mode)
{
    // any profiling mode is compatible with the mode itself
    // or no profiling mode is active
    if ((globals.profilerObj.profileMode == mode) ||
        (globals.profilerObj.profileMode == CUPROF_PROFILE_MODE_NONE))
    {
        return NV_TRUE;
    }
    else {
        return NV_FALSE;
    }
}

CUresult setGlobalProfMode(int mode, int value)
{
    cuiMutexLock(&globals.profilerMutex);

    globals.profilerObj.profileMode = mode;

    switch(value) {
        case CUPROF_PROFILE_ENABLE:
            globals.profilerObj.profile = CUPROF_PROFILE_ENABLE;
            break;
        case CUPROF_PROFILE_DISABLE:
            globals.profilerObj.profile = CUPROF_PROFILE_DISABLE;
            break;
        case CUPROF_PROFILE_UNCHANGED:
            // do nothing, keep profiling state unchanged
            break;
        default:
            CU_ASSERT(0);
    }
    cuiMutexUnlock(&globals.profilerMutex);

    return CUDA_SUCCESS;
}

void
setProfilerRequested(void) {
    globals.profilerObj.bProfilerRequested = NV_TRUE;
}

// Return true if any type of profiling is ever requested
// irrespective of the current profiling status (enabled/disabled)
NvBool
isProfilerRequested(void) {
    return globals.profilerObj.bProfilerRequested;
}

NvBool
isInternalEnvVarSet(void) {
    static char mangledInternalsEnvName[]=__MANGLED_CUDA_PROFILER_INTERNAL;
    int rc = 0;
    char internalsEnvName[CUOS_ENV_VAR_LENGTH];
    char envVar[CUOS_ENV_VAR_LENGTH];

    __PERFMON_DEMANGLE_STRING(mangledInternalsEnvName, internalsEnvName);

    if(!cuosGetEnv(internalsEnvName, envVar, CUOS_ENV_VAR_LENGTH))
        rc = atoi(envVar);
    return rc;
}

void globalsProfilerFlagsInit(void)
{
    char val[20];
    globals.profilerObj.profileMode = CUPROF_PROFILE_MODE_NONE;

    if (!cuosGetEnv("CUPTI_PROFILE_MODE", val, 20)) {
        if(1 == atoi(val)) {
            globals.profilerObj.profileMode = CUPROF_PROFILE_MODE_CUPTI;
        }
    }
    globals.profilerObj.profile = 0;
}
