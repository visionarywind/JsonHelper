/*
 * Copyright 1993-2009 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 *
*/

#ifndef PROF_FUNC_H
#define PROF_FUNC_H


#include "cuda_internal.h"
#include "memmgr.h"
#include "memobj.h"
#include <math.h>

#define CU_FERMI_IS_32B_INSTR(instr)                               \
        ((instr & 0x00000008) == 0x00000008) //if 4lsb bit is 1, then 32bit instr else 64bit

#define EXTRACT_HI_WORD(inst)                                      \
        ((NvU32)((inst & 0xffffffff00000000ULL) >> 32))

#define EXTRACT_LO_WORD(inst)                                      \
        ((NvU32)(inst & 0x00000000ffffffffULL))

#define REG_0   0x0
#define REG_1   0x1
#define REG_2   0x2
#define REG_3   0x3
#define REG_4   0x4
#define REG_5   0x5

#define CCC_BITS_CC_T 0x0f
#define P_REG_0  0x0
#define P_REG_1  0x1
#define P_REG_7  0x7
#define P_REG_N0 0x8 // !P0
#define P_REG_N1 0x9 // !P1

#define CMP_F   0x0
#define CMP_LT  0x1
#define CMP_EQ  0x2
#define CMP_LE  0x3
#define CMP_GT  0x4
#define CMP_NE  0x5
#define CMP_GE  0x6
#define CMP_T   0x7

#define BOP_AND 0x0
#define BOP_OR  0x1
#define BOP_XOR 0x2

#define ABC_RRR 0x0 //A source=register B source=register         C source=register
#define ABC_RCR 0x1 //A source=register B source=constant address C source=register
#define ABC_RRC 0x2 //A source=register B source=register         C source=constant address
#define ABC_RIR 0x3 //A source=register B source=#IMM             C source=register

#define PSIGN_A_B_0  0x0 //  A +  B + 0 (no .xm)/Carry(with .xm)
#define PSIGN_A_NB_1 0x1 //  A + ~B + 1 (no .xm)/Carry(with .xm)
#define PSIGN_NA_B_1 0x2 // ~A +  B + 1 (no .xm)/Carry(with .xm)
#define PSIGN_A_B_1  0x3 //  A +  B + 1 (ILLEGAL with .xm)

#define TRIG_FLAG 0x1
#define SYNC_FLAG 0x1
#define XM_FLAG   0x1
#define CC_FLAG   0x1

#define LMEM_OFF_R0 0x0
#define LMEM_OFF_R1 0x4
#define LMEM_OFF_R2 0x8
#define LMEM_OFF_PR 0xc

// Upper 512 byte of Lmem Hi is reserved for debugger.
// which can be used by profiler as scratch space
#define LMEM_HI_SCRATCH 0xfffe00 // 0x1000000 - 0x200 = 0xfffe00

#define CU_PROF_SW_COUNTER_LMEMSIZE 5*sizeof(NvU32)
#define CU_PROF_SW_COUNTER_NUMREGS 4

#define CU_PROF_NOPTRIG_SW_COUNTER_LMEMSIZE 4*sizeof(NvU32)
#define CU_PROF_NOPTRIG_SW_COUNTER_NUMREGS 3

#define CU_PROF_WARP_EVENT_LMEMSIZE 3*sizeof(NvU32)
#define CU_PROF_WARP_EVENT_NUMREGS 11

#define CEIL_TO_MULTIPLE_OF_8(value) ((value + 7) & ~(7))
#define CEIL_TO_MULTIPLE_OF_64(value) ((value + 63) & ~(63))

enum InstType {
    LD_INST_8BIT,
    LD_INST_16BIT,
    LD_INST_32BIT,
    LD_INST_64BIT,
    LD_INST_128BIT,
    ST_INST_8BIT,
    ST_INST_16BIT,
    ST_INST_32BIT,
    ST_INST_64BIT,
    ST_INST_128BIT,
    LDG_INST_8BIT,
    LDG_INST_16BIT,
    LDG_INST_32BIT,
    LDG_INST_64BIT,
    LDG_INST_128BIT,
    TOTAL_INST
};


typedef struct sassInstGen_st sassInstGen;
typedef struct relocPC_st relocPc;
typedef struct swCounterTable_st swCounterTable;
typedef struct profilerHal_st profilerHal;

// Please follow the common format for adding or updating any new instruction.
// void (*INST)(NvU32 *instHi, NvU32 *instLo, NvU32 parameter1,...);
// Instruction parameters can be extended depending on the use case.
struct sassInstGen_st{
    NvU32 regZ;
    NvU32 instSize;
    NvU32 (*getLDExrAddr)(unsigned int origInstHi);
    NvU32 (*getLDAddrReg)(unsigned int origInstLo);
    NvU32 (*getLDImm32)(unsigned int origInstHi, unsigned int origInstLo);
    NvU32 (*createSrcBFieldFromRegister)(NvU32 reg);
    NvU32 (*createSrcBFieldFromConstantAddress)(NvU32 bankNumber, NvU32 bankOffset);
    NvU32 (*getPRegBits)(NvU32 origInstLo);
    NvU32 (*isExitInst)(NvU32 origInstHi, NvU32 origInstLo);
    NvU32 (*getCCCBits)(NvU32 origInstLo);
    NvU32 (*isJcalInst)(NvU32 origInstHi, NvU32 origInstLo);
    NvU32 (*isJmpInst)(NvU32 origInstHi, NvU32 origInstLo);
    NvU32 (*isJmxInst)(NvU32 origInstHi, NvU32 origInstLo);
    NvU32 (*isDirectCall)(const NvU64 *origInst);
    NvU32 (*isIndirectCall)(const NvU64 *origInst, NvU32 offset);
    void (*BRA)(NvU32* instHi, NvU32* instLo, NvU32 PRegBitsVal, NvU32 cccBitsVal, NvU32 branchTarget);
    void (*STL)(NvU32* instHi, NvU32* instLo, NvU32 lmemAddr, NvU32 reg);
    void (*P2R)(NvU32* instHi, NvU32* instLo, NvU32 reg);
    void (*LDL)(NvU32* instHi, NvU32* instLo, NvU32 reg, NvU32 lmemAddr);
    void (*MOV)(NvU32* instHi, NvU32* instLo, NvU32 destReg, NvU32 sourceReg);
    void (*MOV32I)(NvU32* instHi, NvU32* instLo, NvU32 reg, NvU32 value, NvU32 predReg);
    void (*RED)(NvU32* instHi, NvU32* instLo, NvU32 regA, NvU32 regB, NvU32 PRegBits);
    void (*R2P)(NvU32* instHi, NvU32* instLo, NvU32 reg);
    void (*ISETP)(NvU32* instHi, NvU32* instLo, NvU32 cmp, NvU32 bop, NvU32 predSrc, NvU32 abc, NvU32 srcB, 
        NvU32 regA, NvU32 predDest);
    void (*PSETP)(NvU32* instHi, NvU32* instLo, NvU32 bop, NvU32 predSrc1, NvU32 predSrc2, NvU32 predDest);
    void (*LOP)(NvU32* instHi, NvU32* instLo);
    void (*NOP)(NvU32* instHi, NvU32* instLo, NvU32 trigFlag, NvU32 syncFlag, NvU32 mask, NvU32 pred);
    void (*RET)(NvU32* instHi, NvU32* instLo, NvU32 PReg, NvU32 CCCbits);
    void (*CAL)(NvU32* instHi, NvU32* instLo, NvU32 target);
    void (*JCAL)(NvU32* instHi, NvU32* instLo, NvU32 target);
    void (*VOTE)(NvU32* instHi, NvU32* instLo);
    void (*POPC)(NvU32* instHi, NvU32* instLo);
    void (*IMUL32I)(NvU32* instHi, NvU32* instLo);
    void (*BRX)(NvU32* instHi, NvU32* instLo);
    void (*SSY)(NvU32* instHi, NvU32* instLo, NvU32 syncTarget);
    void (*LDC)(NvU32* instHi, NvU32* instLo, NvU32 cBank, NvU32 offset, NvU32 dest, NvU32 PReg);
    void (*LONGJMP)(NvU32* instHi, NvU32* instLo, NvU32 PRegBitsVal, NvU32 cccBitsVal);
    void (*IADD)(NvU32 *instHi, NvU32 *instLo, NvU32 xmFlag, NvU32 psign, NvU32 destReg, NvU32 ccFlag, NvU32 srcReg1, NvU32 srcReg2);
    void (*JMP)(NvU32* instHi, NvU32* instLo, NvU32 target);
    void (*SHINT)(NvU32* instHi, NvU32* instLo, NvU64 hint);
    void (*TEXDEPBAR)(NvU32* instHi, NvU32* instLo);
};

struct relocPC_st{
    NvU32 origInstPc; // PC of original instruction
    NvU32 patchCodeFirstInstPc; // PC of the first instruction of patch corresponding to the original instruction
};

struct swCounterTable_st{
    NvU32 swCountersDomain;
    NvU32 smVersion;
    NvU32 numReg;
    NvU32 lmemSize;
    int commonRoutinePatchSize;
    int globalAddrWindowPatchSize;
    int genericAnyAddrWindowPatchSize;
    int smemWinLo;
    int lmemWinLo;
    relocPc *relocPcPtr;
    NvU32 numInstPatched;
    int (*getPMSignalsIndex)(NvU32);
    int (*getOpcodeIndex)(NvU64, NvBool *);
    void (*insertAtomInstBasedPatch)(swCounterTable*, sassInstGen*, unsigned int, unsigned int, void*,
                              NvU32, NvU32, NvU64, NvU32*, NvBool); // Remove during cleanup.
    void (*insertNopTrigBasedPatch)(swCounterTable*, sassInstGen*, NvU32*, 
                              NvU32, NvBool, NvU32);
    void (*insertPatchPerInstOccurence)(swCounterTable*, sassInstGen*, unsigned int, unsigned int, NvU32,
                              NvU32, NvU32, NvU64, NvU32*, NvU32, NvBool);
    NvBool (*kernelHasJmx)(CUctx*, const CUfunc*, sassInstGen*);
};

struct profilerHal_st{
    NvU32 patchFlag;
    sassInstGen *sassInstGenPtr;
    swCounterTable *swCounterTablePtr;
    CUresult (*funcApplyReloc)(CUctx*, CUfunc*, profilerHal*, NvU32**, NvU32); // Code instrumentation to apply relocations and restore original code
    CUresult (*funcLocateSSYs)(CUctx*, CUfunc*);
    CUresult (*funcPatchNOPTRIGInstructions)(CUctx*, const CUfunc*, NvU32**, NvU32*, CUprofPatchNopTrig*); // NOP Trigger based patching
    CUresult (*funcCountBlockOnSM)(CUctx*, const CUfunc*, NvU32**, NvU32*, CUprofPatchNopTrig*); // Code instrumentation for counting no. of blocks executed on a SM
    CUresult (*funcRecordWarpEvent)(CUctx*, const CUfunc*, NvU32**, NvU32*); // Code instrumentation to record kernel warp events
    CUresult (*funcCollectSwCounters)(CUctx*, CUfunc*, profilerHal*, NvU32**, NvU32*); // Code instrumentation to collect sw counters
    CUresult (*funcPatchConcKernelTraceSyncKernel)(CUctx*, const CUfunc*, NvU32**, NvU32*); // Code instrumentation to patch sync kernel for conckerneltrace
    CUresult (*funcCollectConcKernelTrace)(CUctx*, const CUfunc*, profilerHal*, NvU32**, NvU32*); // Code instrumentation to collect to generate conckerneltrace
    CUresult (*funcInsertICachePadding)(sassInstGen*, NvU32*, NvU32);
};

CUresult initProfilerHal(CUctx*, profilerHal**);
void destroyProfilerHal(profilerHal**);
CUresult funcCollectSwCounters(CUctx*, CUfunc*, profilerHal*, NvU32**, NvU32*);

CUresult teslaInitProfilerHal(profilerHal*, NvU32);

#if cuiNvcfgEnabledFermiOrHigher()
extern CUresult fermiFuncInitializeTables(NvU32, profilerHal*);
extern CUresult fermiFuncApplyReloc(CUctx*, CUfunc*, profilerHal*, NvU32**, NvU32);
#endif
#if NVCFG(GLOBAL_ARCH_FERMI)
CUresult fermiInitProfilerHal(profilerHal*, NvU32);
#endif

#if NVCFG(GLOBAL_ARCH_KEPLER)
CUresult keplerInitProfilerHal(profilerHal*, NvU32, NvU64);
#endif // NVCFG(GLOBAL_ARCH_KEPLER)

// #define DEBUG_SASS 0

// Function to dump the modified and original SASS in a file
// For debugging purpose
#ifdef DEBUG_SASS
void funcPatchDumpSASSpatch(NvU32*, NvU32, NvU32*, NvU32);
#endif

#endif // PROF_FUNC_H
