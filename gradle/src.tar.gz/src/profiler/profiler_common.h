/* 
* Copyright 2011 by NVIDIA Corporation.  All rights reserved.  All
* information contained herein is proprietary and confidential to NVIDIA
* Corporation.  Any use, reproduction, or disclosure without the written
* permission of NVIDIA Corporation is prohibited.
*/

/******************************************************************************
*
*   Module: profiler_common.h
*
*   Description:
*       profiler specific common routines
*
******************************************************************************/

#ifndef __PROFILER_COMMON_H__
#define __PROFILER_COMMON_H__

#include "cuda.h"
#include "cuos.h"
#include "nvtypes.h"

#ifdef __cplusplus
extern "C" {            /* Assume C declarations for C++ */
#endif  /* __cplusplus */

#define CUPROF_PROFILE_MODE_NONE            0   // no profiling mode
#define CUPROF_PROFILE_MODE_CLP             1   // command line profiling
#define CUPROF_PROFILE_MODE_PROF_API        2   // cuProfiler* APIs
#define CUPROF_PROFILE_MODE_CUPTI           3   // CUPTI APIs
#define CUPROF_PROFILE_MODE_SHM             4   // shared memory based profiling
#define CUPROF_PROFILE_MODE_CALLBACKS       5   // callbacks based profiling

#define CUPROF_PROFILE_DISABLE              0
#define CUPROF_PROFILE_ENABLE               1
#define CUPROF_PROFILE_UNCHANGED            2


typedef struct CUprofGlobal_st {
    volatile int profile;              // profile enable/disable flag
    volatile int profileMode;          // profile mode - auto/manual
    NvBool bProfilerRequested;         // gets set whenever profiler req is made (persistent var)
}CUprofGlobals;

NvBool profModeCompatible(int mode);
CUresult setGlobalProfMode(int mode, int value);
void setProfilerRequested(void);
NvBool isProfilerRequested(void);
NvBool isInternalEnvVarSet(void);
void globalsProfilerFlagsInit(void);
CUprofResult convertCuresultsToProfResult(CUresult res);
        
#ifdef __cplusplus
}
#endif  /* __cplusplus */

#endif //__PROFILER_COMMON_H__
