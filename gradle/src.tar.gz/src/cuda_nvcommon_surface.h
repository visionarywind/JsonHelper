#ifndef __cuda_nvcommon_surface_h__
#define __cuda_nvcommon_surface_h__

/* CUDA struct corresponding to the nvcommon struct of EGL to internally store * the surface info
 */

#include "cuda.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    /* Forces setting this value for structure to be usable*/
    CUmemType_Invalid = 0,
    /* TegraRM client */
    CUmemType_TegraRM,
    /* Resman client */
    CUmemType_Resman,
    CUmemType_Force32 = 0x7FFFFFFF
} CUmemType;

typedef enum {
    /* Forces setting this value for structure to be usable */
    CUsurfLayoutInvalid = 0,
    /* Pitch-linear format */
    CUsurfLayoutLinear,
    /* Tegra block-linear format
     *   Requires special shader to use on dGPU */
    CUsurfLayoutBlockLinearTegra,
    /* dGPU block-linear format
     *   Not usable by tegra/iGPU */
    CUsurfLayoutBlockLineardGPU,
    CUsurfLayout_Force32 = 0x7FFFFFFF
} CUsurfLayout;

typedef struct CUcommonSurface_st {
    /* Index into a separate array of vCommonMemory structures */
    NvU32                   memIndex;

    /* Type of memory */
    CUmemType               memType;

    /* Layout of surface */
    CUsurfLayout            layout;

    /* Total size of surface data, including padding and metadata */
    NvU64                   size;

    /* Offset into indexed memory of start of surface */
    NvU64                   offset;

    /* Color format of the pixel data in the surface */
    CUarray_format          colorFormat;
    NvU32                   numChannels;

    /* Usable surface dimensions */
    NvU32                   width;
    NvU32                   height;

    /* Pitch and block-linear settings, as appropriate. 0 when not relevant */
    NvU32                   pitch;
    NvU32                   log2BlockHeight;    /* Tegra */
    NvU32                   log2GobsPerBlockX;  /* dGPU  */
    NvU32                   log2GobsPerBlockY;  /* dGPU  */
} CUcommonSurf;

#ifdef __cplusplus
}
#endif
#endif
