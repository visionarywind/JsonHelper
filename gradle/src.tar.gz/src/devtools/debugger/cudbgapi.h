/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */


#ifndef CUDBG_API_H
#define CUDBG_API_H

#include "cudadebugger.h"

typedef enum {
    TGDB_DBGMSG_INVALID,
    TGDB_DBGMSG_SUSPEND,
    TGDB_DBGMSG_RESUME,
    TGDB_DBGMSG_RESUMEWARPS,
    TGDB_DBGMSG_TERMINATE,
    TGDB_DBGMSG_SSTEPWARP,
    TGDB_DBGMSG_ACK,
    TGDB_DBGMSG_LAST,
} tgdb_dbgmsg_kind_t;

typedef struct {
    uint32_t checkCtxSync;
    uint32_t nsteps;
    CUwarpBitmask warpMask;
} debuggerMessageData_t;

typedef struct {
    tgdb_dbgmsg_kind_t kind;
    uint32_t id;
    uint32_t dev;
    uint32_t vsm;
    uint32_t wp;
    debuggerMessageData_t data;
} debuggerMessage_t;

typedef struct {
    CUDBGResult res;
    uint32_t checkCtxSync;
    CUwarpBitmask warpMask;
} debuggerMessageReply_t;

/* Release Revisions */
#define API_REVISION_3_0    17
#define API_REVISION_3_1    25
#define API_REVISION_3_2    31
#define API_REVISION_4_0    46
#define API_REVISION_4_1    57
#define API_REVISION_4_2    61
#define API_REVISION_5_0    77
#define API_REVISION_5_5_RC 95
#define API_REVISION_5_5    98
#define API_REVISION_6_0    116
#define API_REVISION_6_5    121
#define API_REVISION_7_0    122
#define API_REVISION_7_5    123
#define API_REVISION_LATEST CUDBG_API_VERSION_REVISION

CUDBGResult gpudbgNotifyDebugger(uint32_t tid, bool timeout);
CUDBGResult gpudbgProcessApplicationMessage(void *msgBuffer, bool *requiresDebuggerAck, uint32_t *hostThreadId);
CUDBGResult gpudbgProcessTimeoutEvent(void);
CUDBGResult gpudbgProcessInternalError(CUDBGResult errorType);
CUDBGResult insertBreakpoints(CudbgDevice dev, bool skipExit);
CUDBGResult removeBreakpoints(CudbgDevice dev);
CUDBGResult clearTemporaryBreakpoints(CudbgDevice dev);
CUDBGResult unsetTemporaryBreakpoints(CudbgDevice dev);
CUDBGResult insertTemporaryBreakpoint(Context ctx, uint64_t vaddr, uint64_t pc, Breakpoint *ret);
CUDBGResult gpudbgSendDebuggerMessage(tgdb_dbgmsg_kind_t kind, uint32_t dev, uint32_t vsm, uint32_t wp, debuggerMessageData_t *data, debuggerMessageReply_t *reply);
CUDBGResult gpudbgCreateDynamicGrid(CudbgDevice dev, uint32_t sm, uint32_t wp, uint32_t ln, uint64_t gridId64, uint64_t physPC, CuDim3 gridDim, CuDim3 blockDim, bool *isPostable);
CUDBGResult gpudbgUpdateUnpostedDynamicGrid(CudbgDevice dev, uint32_t sm, uint32_t wp, uint32_t ln, Grid *grid, uint64_t physPC, bool *isPostable);
CUDBGResult gpudbgPostGridEvent(CudbgDevice dev, Context context, Grid grid, DeviceFunction function);
CUDBGResult cudbgSendAttachCompleteEvent(void);
CUDBGResult gpudbgGetResidentContext(Context *residentContext);
CUDBGResult gpudbgInitiateChannelGroupPreemptSave(CudbgDevice dev, bool *allPreempted, bool *ctaPreemptTriggered);
CUDBGResult gpudbgInitiateChannelGroupPreemptRestore(CudbgDevice dev, bool *allPreempted);

bool deviceHasAnyContext(uint32_t devId);

CUDBGResult gpudbgInitializeStaticState(void);
CUDBGResult gpudbgReadVirtualPCInternal(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint64_t *virtualpc);
CUDBGResult gpudbgReadCallDepthInternal(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t *depth);
CUDBGResult gpudbgReadReturnAddressInternal(uint32_t devId, uint32_t sm,
                                            uint32_t wp, uint32_t ln,
                                            uint32_t level, uint64_t *ra,
                                            bool *patchDebug);
CUDBGResult gpudbgReadVirtualReturnAddressInternal(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t level, uint64_t *ra);
CUDBGResult gpudbgReadPredicatesInternal(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t predicates_size, uint32_t *predicates);
CUDBGResult gpudbgReadCCRegisterInternal(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t *val);
CUDBGResult gpudbgReadErrorPCInternal(uint32_t devId, uint32_t sm, uint32_t wp, uint64_t *errorPC, bool *errorPCValid);
CUDBGResult gpudbgReadRegisterRangeInternal(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t regno, uint32_t *registers, uint32_t numRegs);
CUDBGResult gpudbgReadPCInternal(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint64_t *pc);
CUDBGResult gpudbgSetupHaloInitDataFlags(HaloInitData haloInitData);

#endif
