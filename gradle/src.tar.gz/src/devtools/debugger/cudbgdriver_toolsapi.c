/*
 * Copyright 2007-2012 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: cudbgdriver_toolsapi.c
 *
 *   Description:
 *      Tools API Subscriber for Debugger
 *      Purpose of this module is to subscribe from the Tools API using arbiter
 *      interface. Currently debugger subscribes for CUDA_TRACE domains and
 *      processes the return code to report API failures.
 ******************************************************************************/


/*--------------------------------- Includes ---------------------------------*/

#include "cuda_etbl/tools_callbacks.h"
#include "cuda_etbl/tools_callback_arbiter.h"
#include "cuda_etbl/tools_context.h"
#include "cudbgdriver.h"
#include "cudbgdriver_toolsapi.h"
#include "cuistream.h"
#include "cuos_debug.h"
#include "memobj.h"
#include "memblock.h"
#include "cudbgutils.h"

/*-----------------------------Type Definitions-------------------------------*/

typedef struct CudbgToolsApiControl_st CudbgToolsApiControl;

/*---------------------------------Structures -------------------------------*/

// Structure to control whole callback process
struct CudbgToolsApiControl_st {
    const CUetblToolsCallbackArbiter *callbackTable;
    CUtoolsCbFunc callback;
    CUtoolsCbSubscriberHandle subscriberHandle;
};

//*------------------------------Function Protypes----------------------------*/

static CUresult CUDAAPI
cudbgToolsApi_ProcessTrace(
    void *pUserData,
    CUtools_cb_domain domain,
    CUtoolsCbId cbid,
    CUtoolsTraceApiCuda *inParams);

static void CUDAAPI
cudbgToolsApi_CallbackHandler(
    void *pUserData,
    CUtools_cb_domain domain,
    CUtoolsCbId cbid,
    const void *inParams);

//*--------------------------------- Externs ---------------------------------*/
extern const CUetblToolsCallbackArbiter g_etblToolsCallbackArbiter;
extern const CUetblToolsContext         g_etblToolsContext;

//*--------------------------Global/Static Variables--------------------------*/
static CudbgToolsApiControl s_cudbgtoolsApiControl =
{
    &g_etblToolsCallbackArbiter,
    cudbgToolsApi_CallbackHandler,
    0
};
static CudbgToolsApiControl *g_cudbgtoolsApiControl = NULL;
static volatile uint32_t g_cudbgCurrentSessionId = 0U;
static CUOSTLSEntry g_cudbgtoolsApiRtKey;
static volatile uint32_t g_cudbgtoolsApiTlsInitialized = 0U;


//*---------------------------Function Declaration----------------------------*/

static CUresult
cudbgToolsApiControlCleanup(CudbgToolsApiControl *control, CUDBGToolsAPICleanUpType cleanUpType);

/* g_cudbgCurrentSessionId protects against InitInstant()/FinalCleanUp() race:
 * - set during cudbgToolsApiFinalCleanUp function call and indicates that
 *   arbiter allocated during concurent InitInstant() call must be freed immediately.
 * - Consumed inside InitInstant call.
 * - Reset before static InitInstant() call, restored if initialisation failed.
 *
 * I.e. g_cudbgCurrentSessionId is set between CleanupDelayed and ApiInit()
 * calls unless race occurs.
 */

/* Following function is called to initiate the tools api subscription instantneously */
static CUresult
cudbgToolsApiInitInstant(void *pUserData)
{
    CUresult status = CUDA_SUCCESS;
    CudbgToolsApiControl *control = NULL;
    const CUetblToolsCallbackArbiter *arb = NULL;
    uint32_t sessionId = (uint32_t)(uintptr_t)pUserData;

    /* Call does not belong to this sessions */
    if (sessionId != g_cudbgCurrentSessionId) {
        CUDBG_ERROR("%s: mismatch, bailing: saved session id: %d, current session id: %d\n",
                    sessionId, g_cudbgCurrentSessionId);
        return status;
    }

    if (g_cudbgtoolsApiControl)
        return status;

    /* Point to the static arbiter control */
    control = &s_cudbgtoolsApiControl;

    arb = control->callbackTable;

    /* Subscribe to tools API. If there are multiple
       calls to subscribe, this call will return
       CUDA_ERROR_ALREADY_ACQUIRED
     */
    status = arb->Subscribe(&control->subscriberHandle,
                            CU_TOOLS_CBA_CLIENT_DEBUGGER,
                            control->callback,
                            (void *)(uintptr_t)sessionId);
    if (status != CUDA_SUCCESS)
        return status;

    /* Enable API cuda callbacks */
    status = arb->EnableAllCallbacksInDomain(1, control->subscriberHandle,
                                             CU_TOOLS_CB_DOMAIN_TRACE_API_CUDA);
    if (status != CUDA_SUCCESS)
        goto error;

    /* Enable API cuda runtine callbacks */
    status = arb->EnableAllCallbacksInDomain(1, control->subscriberHandle,
                                             CU_TOOLS_CB_DOMAIN_TRACE_API_CUDA_RUNTIME);
    if (status != CUDA_SUCCESS)
        goto error;

    /* Enable all resource internal callbacks */
    status = arb->EnableAllCallbacksInDomain(1, control->subscriberHandle,
                                             CU_TOOLS_CB_DOMAIN_RESOURCE_INTERNAL);
    if (status != CUDA_SUCCESS)
        goto error;

    /* Enable resource callbacks */
    status = arb->EnableAllCallbacksInDomain(1, control->subscriberHandle,
                                             CU_TOOLS_CB_DOMAIN_RESOURCE);
    if (status != CUDA_SUCCESS)
        goto error;

    /* Enable initialization callbacks */
    status = arb->EnableAllCallbacksInDomain(1, control->subscriberHandle,
                                             CU_TOOLS_CB_DOMAIN_INIT);
    if (status != CUDA_SUCCESS)
        goto error;

    /* Enable stream synchronization callback */
    status = arb->EnableCallback(1, control->subscriberHandle,
                                 CU_TOOLS_CB_DOMAIN_SYNCHRONIZE,
                                 CU_TOOLS_CBID_SYNCHRONIZE_STREAM_SYNCHRONIZED);
    if (status != CUDA_SUCCESS)
        goto error;

    /* Create TLS variable for each thread */
    if (cuosInterlockedCompareExchange(&g_cudbgtoolsApiTlsInitialized, 1U, 0U) == 0U)
        g_cudbgtoolsApiRtKey = cuosTlsAlloc(NULL);

    /* Check if arbiter was already allocated */
    if (cuosInterlockedCompareExchangePointer((void *volatile*)&g_cudbgtoolsApiControl, control, 0) != NULL)
        goto error;

    /* The sessionId changed in the middle of this call due to a detach or
     * a reattach, so undo everything. This is prone to a race if another
     * detach + reattach happens. */
    if (sessionId != g_cudbgCurrentSessionId) {
        CUDBG_ERROR("%s: mismatch, cleaning up: saved session id: %d, current session id: %d\n",
                    sessionId, g_cudbgCurrentSessionId);
        cudbgToolsApiFinalCleanUp(CUDBG_TOOLSAPI_CLEANUP_NONDYNAMIC);
    }

    return status;

error:
    cudbgToolsApiControlCleanup(control, CUDBG_TOOLSAPI_CLEANUP_NONDYNAMIC);
    return status;
}

/* Following function is called to initiate the tools API subscription in delayed
 * fashion, it is required in case cuda-gdb is getting attached to a running
 * application. Due to application freeze no memory can be allocated to initiate
 * tools API subscription, this function delays the tools API subscription
 * by calling tools_arbiter function which completes the required memory allocation
 * until application is continued again.
 */

static void
cudbgToolsApiInitDelayed(void *pUserData)
{
    (void)cudbgToolsApiInitInstant(pUserData);
    cudbgToolsApiStateUpdate(CUDBG_APP_TOOLS_API_STATE_READY);
}

CUresult CUDAAPI
cudbgToolsApiInit(CUDBGAttachState attachState)
{
    CUresult status = CUDA_ERROR_INVALID_VALUE;
    uint32_t sessionId = gpudbgGetClientSessionId();
    void *pUserData = (void*)(uintptr_t)sessionId;
    uint32_t needsResume = 0;

    g_cudbgCurrentSessionId = sessionId;

    if ((attachState == CUDBG_STATE_ATTACHING_VIA_RPCD) ||
        (attachState == CUDBG_STATE_ATTACHING_VIA_STUB)) {
        status = s_cudbgtoolsApiControl.callbackTable->CanMakeDynamicCall(CU_TOOLS_CBA_CLIENT_DEBUGGER, &needsResume);
        if (status != CUDA_SUCCESS)
            return status;
    }
    else if (attachState != CUDBG_STATE_NOT_ATTACHING) {
        CU_ERROR_PRINT(("Unknown CUDBGAttachState\n"));
        return CUDA_ERROR_INVALID_VALUE;
    }

    if (!needsResume)
        status = cudbgToolsApiInitInstant(pUserData);
    else {
        cudbgToolsApiStateUpdate(CUDBG_APP_TOOLS_API_STATE_WAITING);
        status = s_cudbgtoolsApiControl.callbackTable->AddPendingAction(cudbgToolsApiInitDelayed, pUserData);
    }
    return status;
}

static CUresult
cudbgToolsApiCleanupInstant(void)
{
    CUresult status = CUDA_SUCCESS;
    const CUetblToolsCallbackArbiter *cbt = s_cudbgtoolsApiControl.callbackTable;

    status = cbt->Unsubscribe(s_cudbgtoolsApiControl.subscriberHandle);
    return status;
}

static void
cudbgToolsApiCleanupDelayed(void *ignored)
{
    (void)cudbgToolsApiCleanupInstant();
    cudbgToolsApiStateUpdate(CUDBG_APP_TOOLS_API_STATE_READY);
}

/* Following function is called to cleanup tools api subscription */
static CUresult
cudbgToolsApiControlCleanup(CudbgToolsApiControl *control, CUDBGToolsAPICleanUpType cleanUpType)
{
    CUresult status = CUDA_SUCCESS;
    uint32_t needsResume = 0;

    /* Unsubscribe to tools Arbiter */
    if (cleanUpType == CUDBG_TOOLSAPI_CLEANUP_DYNAMIC) {
        status = s_cudbgtoolsApiControl.callbackTable->CanMakeDynamicCall(CU_TOOLS_CBA_CLIENT_DEBUGGER, &needsResume);
        if (status != CUDA_SUCCESS)
            return status;
    }

    if (!needsResume)
        status = cudbgToolsApiCleanupInstant();
    else {
        cudbgToolsApiStateUpdate(CUDBG_APP_TOOLS_API_STATE_WAITING);
        status = s_cudbgtoolsApiControl.callbackTable->AddPendingAction(cudbgToolsApiCleanupDelayed, NULL);
    }

    return status;
}

static CUresult
cudbgToolsApi_traceAction(uint32_t apiEnter, uint32_t *status,
                          const char* funcName, uint32_t isRuntime,
                          void* cudartEtbl)
{
    int32_t val = 0;
    /* Since there are multiple possible domains here, the occlusion of errors
       happens using a simple TLS stack approach. On every API entry, the TLS
       value is incremented. On API exit, it is decremented. Only when the
       last call is exited (i.e. TLS decrement is 0) is the API error
       checked.
    */

    if (apiEnter == CU_TOOLS_API_ENTER) {
        val = (int32_t)(uintptr_t)cuosTlsGetValue(g_cudbgtoolsApiRtKey);
        ++val;
        cuosTlsSetValue(g_cudbgtoolsApiRtKey, (void*)(intptr_t)val);
        return CUDA_SUCCESS;
    }
    else {
        val = (int32_t)(uintptr_t)cuosTlsGetValue(g_cudbgtoolsApiRtKey);
        --val;
        if (val >= 0)
            cuosTlsSetValue(g_cudbgtoolsApiRtKey, (void*)(intptr_t)val);

        if ((val == 0) && status)
            return cudbgApiErrorCheck(*status, funcName, isRuntime, cudartEtbl);

        return CUDA_SUCCESS;
    }

    return CUDA_SUCCESS;
}

static CUresult CUDAAPI
cudbgToolsApi_ProcessTraceDriver(const CUtoolsTraceApiCuda *params)
{
    return cudbgToolsApi_traceAction((uint32_t)params->apiEnterOrExit,
                                     (uint32_t*)params->pStatus,
                                     params->functionName, 0, NULL);
}

static CUresult CUDAAPI
cudbgToolsApi_ProcessTraceRuntime(const CUtoolsTraceRuntimeApiCuda *params)
{
    void *fptr = NULL;

    /* Some older CUDARTs may not set this field, so first check that the
       offset of the field is within the specified struct */
    if (offsetof(CUtoolsTraceRuntimeApiCuda, pfnGetExportTable) < params->struct_size) {
        fptr = (void*)params->pfnGetExportTable;
    }

    return cudbgToolsApi_traceAction((uint32_t)params->apiEnterOrExit,
                                     (uint32_t*)params->pStatus,
                                     params->functionName, 1, fptr);
}

static CUresult CUDAAPI
cudbgToolsApi_ProcessTraceRuntimeInternal(const CUtoolsTraceRuntimeInternalInit *params)
{
    return cudbgToolsApi_traceAction((uint32_t)params->apiEnterOrExit,
                                     (uint32_t*)params->pStatus,
                                     params->functionName, 1, NULL);
}

static CUresult
cudbgToolsApi_ProcessMemblockAlloc(const CUtoolsMemBlockAlloc *params,
                                   void *pUserData)
{
    if (gpudbgDebuggerAttached()) {
        cudbgReportMemblockAlloc((CUctx*)params->ctx, (CUmemblock*)params->hMemBlock,
                                 true, (uint32_t)(uintptr_t)pUserData);
    }
    return CUDA_SUCCESS;
}

static CUresult
cudbgToolsApi_ProcessMemblockFree(const CUtoolsMemBlockFree *params, void *pUserData)
{
    if (gpudbgDebuggerAttached()) {
        cudbgReportMemblockFree((CUctx*)params->ctx,
                                (CUmemblock*)params->hMemBlock,
                                ((CUmemblock*)params->hMemBlock)->devvaddr,
                                ((CUmemblock*)params->hMemBlock)->size,
                                true,
                                (uint32_t)(uintptr_t)pUserData);
    }
    return CUDA_SUCCESS;
}

static CUresult
cudbgToolsApi_ProcessHostLmemResize(const CUtoolsHostLocalMemResize *params, void *pUserData)
{
    if (gpudbgDebuggerAttached()) {
        uint64_t devvaddr = 0;

        if (params->hMemObj)
            devvaddr = (uint64_t)memobjGetDeviceVaddr((CUmemobj*)params->hMemObj);

        cudbgReportHostLmemResize((CUctx*)params->ctx, devvaddr, params->totalSize, true,
                                  (uint32_t)(uintptr_t)pUserData);
    }

    return CUDA_SUCCESS;
}

static CUresult
cudbgToolsApi_ContextCreated(const CUtoolsContextCreated *params, void *pUserData)
{
    if (gpudbgDebuggerAttached()) {
        cudbgReportCtxCreate(params->ctx, true, (uint32_t)(uintptr_t)pUserData);
    }
    return CUDA_SUCCESS;
}

static CUresult
cudbgToolsApi_ContextDestroyStarting(const CUtoolsContextDestroyStarting *params, void *pUserData)
{
    if (gpudbgDebuggerAttached()) {
        cudbgReportCtxDestroyBegin(params->ctx, true, (uint32_t)(uintptr_t)pUserData);
    }
    return CUDA_SUCCESS;
}

static CUresult
cudbgToolsApi_ContextDestroyCompleted(const CUtoolsContextDestroyCompleted *params, void *pUserData)
{
    if (gpudbgDebuggerAttached()) {
        cudbgReportCtxDestroyEnd(params->ctx, true, (uint32_t)(uintptr_t)pUserData);
    }
    return CUDA_SUCCESS;
}

static CUresult
cudbgToolsApi_CudaInitialized(void *pUserData)
{
    if (gpudbgDebuggerAttached()) {
        cudbgReportCudaInitialized(true, (uint32_t)(uintptr_t)pUserData);
    }
    return CUDA_SUCCESS;
}

static CUresult
cudbgToolsApi_StreamSynchronized(const CUtoolsStreamSynchronized *params, void *pUserData)
{
    if (gpudbgDebuggerAttached()) {
        CUresult status = CUDA_SUCCESS;
        uint64_t streamId = CUI_STREAM_ID_INVALID;

        if (params->stream != 0) {
            status = g_etblToolsContext.StreamGetIdEx(params->ctx, params->stream, &streamId);
            if (status != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Invalid stream in stream synchronized callback\n"));
                return status;
            }
        }

        cudbgReportStreamSynchronized(params->ctx, streamId, (uint32_t)(uintptr_t)pUserData);
    }
    return CUDA_SUCCESS;
}

static CUresult
cudbgToolsApi_ProcessSystemStackResize(const CUtoolsSystemStackResize *params,
                                       void *pUserData)
{
    if (gpudbgDebuggerAttached()) {
        cudbgReportSystemStackResize((CUctx*)params->ctx,
                                     params->totalSize,
                                     true,
                                     (uint32_t)(uintptr_t)pUserData);
    }

    return CUDA_SUCCESS;
}

static void CUDAAPI
cudbgToolsApi_CallbackHandler(
    void *pUserData,
    CUtools_cb_domain domain,
    CUtoolsCbId cbid,
    const void *inParams)
{
    CUresult status = CUDA_SUCCESS;

    CU_ASSERT(domain);
    CU_ASSERT(cbid);

    if (!g_cudbgtoolsApiControl)
        return;

    switch (domain) {
    case CU_TOOLS_CB_DOMAIN_TRACE_API_CUDA:
        status = cudbgToolsApi_ProcessTraceDriver((const CUtoolsTraceApiCuda*)inParams);
        break;
    case CU_TOOLS_CB_DOMAIN_TRACE_API_CUDA_RUNTIME:
        status = cudbgToolsApi_ProcessTraceRuntime((const CUtoolsTraceRuntimeApiCuda*)inParams);
        break;
    case CU_TOOLS_CB_DOMAIN_CUDA_RUNTIME_INTERNAL:
        switch (cbid) {
        case CU_TOOLS_CBID_CUDA_RUNTIME_INTERNAL_INIT:
            status = cudbgToolsApi_ProcessTraceRuntimeInternal((const CUtoolsTraceRuntimeInternalInit *)inParams);
        default:
            break;
        }
        break;
    case CU_TOOLS_CB_DOMAIN_RESOURCE_INTERNAL:
        switch (cbid) {
        case CU_TOOLS_CBID_RESOURCE_INTERNAL_MEMBLOCK_ALLOC:
            status = cudbgToolsApi_ProcessMemblockAlloc((const CUtoolsMemBlockAlloc *)inParams, pUserData);
            break;
        case CU_TOOLS_CBID_RESOURCE_INTERNAL_MEMBLOCK_FREE:
            status = cudbgToolsApi_ProcessMemblockFree((const CUtoolsMemBlockFree *)inParams, pUserData);
            break;
        case CU_TOOLS_CBID_RESOURCE_INTERNAL_HOST_LOCAL_MEM_RESIZE:
            status = cudbgToolsApi_ProcessHostLmemResize((const CUtoolsHostLocalMemResize *)inParams, pUserData);
            break;
        case CU_TOOLS_CBID_RESOURCE_INTERNAL_SYSTEM_STACK_RESIZE:
            status = cudbgToolsApi_ProcessSystemStackResize((const CUtoolsSystemStackResize *)inParams, pUserData);
            break;
        default:
            break;
        };
        break;
    case CU_TOOLS_CB_DOMAIN_RESOURCE:
        switch (cbid) {
        case CU_TOOLS_CBID_RESOURCE_CONTEXT_DESTROY_STARTING:
            status = cudbgToolsApi_ContextDestroyStarting((const CUtoolsContextDestroyStarting *)inParams, pUserData);
            break;
        case CU_TOOLS_CBID_RESOURCE_CONTEXT_DESTROY_COMPLETED:
            status = cudbgToolsApi_ContextDestroyCompleted((const CUtoolsContextDestroyCompleted *)inParams, pUserData);
            break;
        case CU_TOOLS_CBID_RESOURCE_CONTEXT_CREATED:
            status = cudbgToolsApi_ContextCreated((const CUtoolsContextCreated *)inParams, pUserData);
            break;
        default:
            break;
        }
        break;
    case CU_TOOLS_CB_DOMAIN_INIT:
        switch (cbid) {
        case CU_TOOLS_CBID_INIT_INITIALIZED:
            status = cudbgToolsApi_CudaInitialized(pUserData);
            break;
        default:
            break;
        }
        break;
    case CU_TOOLS_CB_DOMAIN_SYNCHRONIZE:
        switch (cbid) {
        case CU_TOOLS_CBID_SYNCHRONIZE_STREAM_SYNCHRONIZED:
            status = cudbgToolsApi_StreamSynchronized((const CUtoolsStreamSynchronized *)inParams, pUserData);
            break;
        default:
            break;
        }
        break;
    default:
        break;
    };

    // Replace this with a disable all callbacks
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failure in callback. domain:%u cbid:%u status:%u\n", domain, cbid, status));
    }
}

CUresult CUDAAPI
cudbgToolsApiFinalCleanUp(CUDBGToolsAPICleanUpType cleanUpType)
{
    CUresult status = CUDA_SUCCESS;
    CudbgToolsApiControl *control = NULL;

    /* Check CleanUp type */
    if ((cleanUpType <= CUDBG_TOOLSAPI_CLEANUP_INVALID ) ||
        (cleanUpType >= CUDBG_TOOLSAPI_CLEANUP_MAX)) {
        CU_ERROR_PRINT(("Invalid debugger Tools API cleanUp value\n"));
        return CUDA_ERROR_INVALID_VALUE;
    }

    control = g_cudbgtoolsApiControl;
    if (control != cuosInterlockedCompareExchangePointer(
            (void *volatile*)&g_cudbgtoolsApiControl, 0,control)) {
        CU_ERROR_PRINT(("Failed to update the debugger tools API control\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (control)
        status = cudbgToolsApiControlCleanup(control, cleanUpType);

    g_cudbgCurrentSessionId = 0;

    /* Destroy the thread tls */
    if (cuosInterlockedCompareExchange(&g_cudbgtoolsApiTlsInitialized, 0U, 1U) == 1U)
        cuosTlsFree(g_cudbgtoolsApiRtKey);

    return status;
}
