/*
* Copyright 2018 NVIDIA Corporation.  All rights reserved.
*
* NOTICE TO USER:
*
* This source code is subject to NVIDIA ownership rights under U.S. and
* international Copyright laws.  Users and possessors of this source code
* are hereby granted a nonexclusive, royalty-free license to use this code
* in individual and commercial software.
*
* NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
* CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
* IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
* REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
* OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
* OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
* OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
* OR PERFORMANCE OF THIS SOURCE CODE.
*
* U.S. Government End Users.   This source code is a "commercial item" as
* that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
* "commercial computer  software"  and "commercial computer software
* documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
* and is provided to the U.S. Government only as a commercial end item.
* Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
* 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
* source code with only those rights set forth herein.
*
* Any use of this source code in individual and commercial software must
* include, in the user documentation and internal comments to the code,
* the above Disclaimer and U.S. Government End Users Notice.
*/

#include "cudbgunified.h"

#include "cudbgutils.h"
#include "halo.h"
#include "pascal.h"
#include "volta.h"
#include "turing.h"
#if NVCFG(GLOBAL_ARCH_AMPERE)
#include "ampere.h"
#endif

static CUDBGResult
udDecoderGetScratchpadField(HaloScratchpadAccessor accessor, HaloScratchpadField field,
    HaloScratchpadSection section, uint32_t sm,
    uint32_t wp, uint32_t ln, void *value, size_t size)
{
    CUDBGResult res;
    size_t offset = 0;
    size_t fieldWidth;
    UdDecoder decoder = (UdDecoder)accessor->userState;

    CUDBG_VERIFY(value, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    res = decoder->halo.scratchpad.getFieldOffset(field, section, sm, wp, ln, &offset, &fieldWidth);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");

    CUDBG_VERIFY(fieldWidth == size, CUDBG_ERROR_INTERNAL,
        "Mismatch between access size (%d) and field width (%d)\n",
        (uint32_t)size, (uint32_t)fieldWidth);

    memcpy(value, decoder->scratchpad + offset, size);

    return res;
}

static CUDBGResult
udDecoderSetScratchpadField(HaloScratchpadAccessor accessor, HaloScratchpadField field,
    HaloScratchpadSection section, uint32_t sm,
    uint32_t wp, uint32_t ln, void *value, size_t size)
{
    CUDBGResult res;
    size_t offset = 0;
    size_t fieldWidth;
    UdDecoder decoder = (UdDecoder)accessor->userState;

    CUDBG_VERIFY(value, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    res = decoder->halo.scratchpad.getFieldOffset(field, section, sm, wp, ln, &offset, &fieldWidth);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");

    CUDBG_VERIFY(fieldWidth == size, CUDBG_ERROR_INTERNAL,
        "Mismatch between access size (%d) and field width (%d)\n",
        (uint32_t)size, (uint32_t)fieldWidth);

    memcpy(decoder->scratchpad + offset, value, size);

    return res;
}

static CUDBGResult
udDecoderCreateScratchpadAccessor(UdDecoder decoder, HaloScratchpadAccessor *accessor)
{
    HaloScratchpadAccessor outAccessor;

    outAccessor = (HaloScratchpadAccessor)malloc(sizeof(*outAccessor));
    if (!outAccessor) {
        CUDBG_ERROR("Failed to allocate memory for scratchpad accessor\n");
        return CUDBG_ERROR_OS_RESOURCES;
    }
    outAccessor->userState = decoder;
    outAccessor->getField = udDecoderGetScratchpadField;
    outAccessor->setField = udDecoderSetScratchpadField;

    *accessor = outAccessor;

    return CUDBG_SUCCESS;
}

CUDBGResult
udCreateDecoder(const UdDecoderInitParams initParams, UdDecoder *decoder, uint32_t *maxSMVersion)
{
    CUDBGResult result;
    UdDecoder outDecoder;

    CUDBG_VERIFY(initParams && initParams->scratchpad && decoder && maxSMVersion, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

#if NVCFG(GLOBAL_ARCH_AMPERE) && NVCFG(GLOBAL_GPU_FAMILY_GA10X)
    *maxSMVersion = DECODER_SM_VERSION(8, 6);
#elif NVCFG(GLOBAL_ARCH_AMPERE) && NVCFG(GLOBAL_GPU_FAMILY_GA100)
    *maxSMVersion = DECODER_SM_VERSION(8, 0);
#elif NVCFG(GLOBAL_ARCH_TURING)
    *maxSMVersion = DECODER_SM_VERSION(7, 5);
#elif NVCFG(GLOBAL_ARCH_VOLTA)
    *maxSMVersion = DECODER_SM_VERSION(7, 2);
#elif NVCFG(GLOBAL_ARCH_PASCAL)
    *maxSMVersion = DECODER_SM_VERSION(6, 2);
#else
    *maxSMVersion = DECODER_SM_VERSION(0, 0);
#endif

    outDecoder = (UdDecoder)calloc(1, sizeof(*outDecoder));
    CUDBG_VERIFY(outDecoder, CUDBG_ERROR_OS_RESOURCES, "Failed to allocate memory for decoder\n");

    outDecoder->scratchpad = initParams->scratchpad;
    outDecoder->smVersion = initParams->smVersion;
    outDecoder->halo.deviceInfo.preemptionType = initParams->preemptionType;

    if (initParams->smVersion < DECODER_SM_VERSION(6, 0)) {
        free(outDecoder);
        return CUDBG_ERROR_INVALID_DEVICE;
    }
#if NVCFG(GLOBAL_ARCH_PASCAL)
    if (initParams->smVersion <= DECODER_SM_VERSION(6, 2)) {
        haloDeviceInit_gp100(&outDecoder->halo);
    }
#endif
#if NVCFG(GLOBAL_ARCH_VOLTA)
    else if (initParams->smVersion <= DECODER_SM_VERSION(7, 2)) {
        haloDeviceInit_gv100(&outDecoder->halo);
    }
#endif
#if NVCFG(GLOBAL_ARCH_TURING)
    else if (initParams->smVersion <= DECODER_SM_VERSION(7, 5)) {
        haloDeviceInit_tu100(&outDecoder->halo);
    }
#endif
#if NVCFG(GLOBAL_ARCH_AMPERE)
    else if (initParams->smVersion <= DECODER_SM_VERSION(8, 6)) {
        haloDeviceInit_ga100(&outDecoder->halo);
    }
#endif
    else {
        free(outDecoder);
        return CUDBG_ERROR_INVALID_DEVICE;
    }
    
    outDecoder->halo.deviceInfo.smVirtualized = initParams->smVirtualized;
    outDecoder->halo.deviceInfo.numSMsPrTPC = initParams->numSMsPrTPC;
    outDecoder->halo.deviceInfo.numSMs = initParams->numSMs;
    outDecoder->halo.deviceInfo.numWarpsPrSM = initParams->numWarpsPrSM;
    outDecoder->halo.deviceInfo.numWarpsPrTPC = initParams->numWarpsPrTPC;
    outDecoder->halo.deviceInfo.numLanesPrWarp = initParams->numLanesPrWarp;
    outDecoder->halo.deviceInfo.numRegsPrLane = initParams->numRegsPrLane;
    outDecoder->halo.deviceInfo.numPredicatesPrLane = initParams->numPredicatesPrLane;
    outDecoder->halo.deviceInfo.numUniformRegsPrWarp = initParams->numUniformRegsPrWarp;
    outDecoder->halo.deviceInfo.numUniformPredicatesPrWarp = initParams->numUniformPredicatesPrWarp;

    result = udDecoderCreateScratchpadAccessor(outDecoder, &outDecoder->scratchpadAccessor);
    if (result != CUDBG_SUCCESS) {
        return result;
    }

    *decoder = outDecoder;

    return CUDBG_SUCCESS;
}

CUDBGResult
udDestroyDecoder(UdDecoder decoder)
{
    free(decoder);

    return CUDBG_SUCCESS;
}
