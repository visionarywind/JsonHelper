/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/*--------------------------------- Includes ---------------------------------*/

#include "cudadebugger.h"
#include "cuda_device.h"
#include "cuda_structs.h"
#include "cuda_internal.h"
#include "cudbgutils.h"
#include "cudbgtarget.h"
#include <nvelf_reader.h>
#include <nvelf.h>
#include "dwarf_interface.h"
#include "cuos.h"
#include "cudbgelfreloc.h"
#include "cudbgapi.h"
#include "cudbgpipe.h"
#include "cudbgdispatcher.h"
#include "cudbgcoredump.h"
#include "cudbgdriver.h"
#include "halo_state.h"
#include "halo_trace.h"
#include "rpcd/stub.h"
#include "libcudbg_legacy.h"
#include "halo_memmap.h"
#include "cuda_warpbitmask.h"

#include "cuistream.h"
#include "memobj.h"

#include "tools_shared_hashmap.h"
#include "tools_shared_hashset.h"
#include "tools_shared_rangemap.h"

#include "etbl/tools/tools_injection_internal.h"

#if cuosOsIsApple()
#include "cudbgdarwin.h"
#endif

/* Debug Trace */
#define API_TRACE_LEVEL                    haloTraceLevel
#ifndef RELEASE
#define API_TRACE(level, ...)              haloTrace(HALO_TRACE_DOMAIN_API, HALO_TRACE_TYPE_FILE, level, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#define API_TRACE_FUNCTION(level, ...)     haloTrace(HALO_TRACE_DOMAIN_API, (HALO_TRACE_TYPE_FILE | HALO_TRACE_TYPE_FUNCTION), level, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#define API_TRACE_LOCATION(level, ...)     haloTrace(HALO_TRACE_DOMAIN_API, (HALO_TRACE_TYPE_FILE | HALO_TRACE_TYPE_LINE), level, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#define API_TRACE_ELEMENT(level, ...)      haloTrace(HALO_TRACE_DOMAIN_API, HALO_TRACE_TYPE_FILE, level, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#else
#define API_TRACE(level, ...)              ((void)0)
#define API_TRACE_FUNCTION(level, ...)     ((void)0)
#define API_TRACE_LOCATION(level, ...)     ((void)0)
#define API_TRACE_ELEMENT(level, ...)      ((void)0)
#endif

typedef enum {
    CUDBG_API_CHECK_NONE          = 0,
    CUDBG_API_CHECK_INIT          = ( 1 << 0 ),
    CUDBG_API_CHECK_TLS_CB        = ( 1 << 1 ),
    CUDBG_API_CHECK_DEV_ID        = ( 1 << 2 ),
    CUDBG_API_CHECK_DEV_STATUS    = ( 1 << 3 ),
    CUDBG_API_CHECK_DEV_SUSPENDED = ( 1 << 4 ),
    CUDBG_API_CHECK_SM            = ( 1 << 5 ),
    CUDBG_API_CHECK_WP            = ( 1 << 6 ),
    CUDBG_API_CHECK_WP_VALID      = ( 1 << 7 ),
    CUDBG_API_CHECK_LN            = ( 1 << 8 ),
    CUDBG_API_CHECK_LN_VALID      = ( 1 << 9 ),

    CUDBG_API_CHECK_DEV_ACTIVECTX = ( 1 << 10 ),
} cudbgApiCheck_enum;

typedef enum  {
    /* This is not really a check flag, its a dummy value for the fields */
    CUDBG_API_CHECK_DEFAULT         = 0xFFFFFFFFU
} cudbgApiCheckDummy_enum;

#define CUDBG_API_CHECK_GROUP(flag) ( ( ( flag ) << 1 ) - 1 )

#define CUDBG_API_CHECK_PTR_ARG(ptr) CUDBG_VERIFY(ptr, CUDBG_ERROR_INVALID_ARGUMENT, "Invalid argument")

#define CUDBG_API_CHECK(flags, devId, sm, wp, ln) do {                                      \
    CUDBGResult __res##__LINE__ =  cudbgApiCheck(flags, __LINE__, devId, sm, wp, ln);       \
    if (__res##__LINE__ != CUDBG_SUCCESS)                                                   \
        return __res##__LINE__;                                                             \
    } while (0)

static uint32_t clientRevision;
bool cudbgAttachStubAvailable;
static CudbgLaunchState cudbgLaunchNotificationPolicy = CUDBG_NOTIFY_SYNC_ALL;

/* Preemption */

/* State for context traversal */
typedef struct {
    int32_t deviceIdx;
    bool ctaPreemptTriggered;
    bool allPreemptSaved;
    bool allPreemptRestored;
} gpudbgPreemptState;

static CUDBGResult preemptRestoreChannelGroupForContext(Context context, gpudbgPreemptState *preemptState);

/* Events */
typedef struct {
    uint32_t    head;
    uint32_t    tail;
    uint32_t    max;
    uint32_t    numEvents;
    CUDBGEvent *buffer;
} gpudbgEventContainer_t;

typedef enum {
    GPUDBG_EVENT_INVALID,
    GPUDBG_EVENT_SYNC,
    GPUDBG_EVENT_ASYNC,
    GPUDBG_EVENT_MAX,
} gpudbgEventKind_t;

static gpudbgEventContainer_t eventListSync;  /*  Synchronous Events (full rountrip ACKs, etc.) */
static gpudbgEventContainer_t eventListAsync; /*  Asynchronous/Dynamic Events (CNP, etc.) */

#define CUDBG_EVENTS_INITIAL_BUFSIZE 5

static void gpudbgEventsInitialize(gpudbgEventKind_t kind);
static void gpudbgEventsFinalize(gpudbgEventKind_t kind);
static void gpudbgEventsPop(CUDBGEvent **event, gpudbgEventKind_t kind);
static void gpudbgEventsGetAvailable(CUDBGEvent **event, gpudbgEventKind_t kind);

static DeviceModule gpudbgGetModuleByHandle(uint64_t handle);

/* Initialization */
CUDBGResult gpudbgInitialize(void);
CUDBGResult gpudbgFinalize(void);
CUDBGResult gpudbgClearAttachState(void);
CUDBGResult gpudbgRequestCleanupOnDetach55(void);
CUDBGResult gpudbgInitializeAttachStub(void);

/* Device Execution Control */
CUDBGResult gpudbgSuspendDevice(uint32_t dev);
CUDBGResult gpudbgResumeDevice(uint32_t dev);
CUDBGResult gpudbgSingleStepWarp40(uint32_t dev, uint32_t sm, uint32_t wp);

/* Breakpoints */
CUDBGResult gpudbgSetBreakpoint31(uint64_t addr);
CUDBGResult gpudbgUnsetBreakpoint31(uint64_t addr);

/* Device State Inspection */
CUDBGResult gpudbgReadGridId50(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t *gridId);
CUDBGResult gpudbgReadBlockIdx32(uint32_t dev, uint32_t sm, uint32_t wp, CuDim2 *blockIdx);
CUDBGResult gpudbgReadThreadIdx(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t ln, CuDim3 *threadIdx);
CUDBGResult gpudbgReadBrokenWarps(uint32_t dev, uint32_t sm, uint64_t *brokenWarpsMask);
CUDBGResult gpudbgReadValidWarps(uint32_t dev, uint32_t sm, uint64_t *validWarpsMask);
CUDBGResult gpudbgReadValidLanes(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t *validLanesMask);
CUDBGResult gpudbgReadActiveLanes(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t *activeLanesMask);
CUDBGResult gpudbgReadCodeMemory(uint32_t dev, uint64_t addr, void *buf, uint32_t sz);
CUDBGResult gpudbgReadConstMemory(uint32_t dev, uint64_t addr, void *buf, uint32_t sz);
CUDBGResult gpudbgReadGlobalMemory31(uint32_t dev, uint64_t addr, void *buf, uint32_t sz);
CUDBGResult gpudbgReadParamMemory(uint32_t dev, uint32_t sm, uint32_t wp, uint64_t addr, void *buf, uint32_t sz);
CUDBGResult gpudbgReadSharedMemory(uint32_t dev, uint32_t sm, uint32_t wp, uint64_t addr, void *buf, uint32_t sz);
CUDBGResult gpudbgReadLocalMemory(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t ln, uint64_t addr, void *buf, uint32_t sz);
CUDBGResult gpudbgReadRegister(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t regno, uint32_t *val);
CUDBGResult gpudbgReadPC(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t ln, uint64_t *pc);
CUDBGResult gpudbgReadVirtualPC(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint64_t *pc);
CUDBGResult gpudbgReadLaneStatus(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t ln, bool *error);

/* Device State Alteration */
CUDBGResult gpudbgWriteGlobalMemory31(uint32_t dev, uint64_t addr, const void *buf, uint32_t sz);
CUDBGResult gpudbgWriteParamMemory(uint32_t dev, uint32_t sm, uint32_t wp, uint64_t addr, const void *buf, uint32_t sz);
CUDBGResult gpudbgWriteSharedMemory(uint32_t dev, uint32_t sm, uint32_t wp, uint64_t addr, const void *buf, uint32_t sz);
CUDBGResult gpudbgWriteLocalMemory(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t ln, uint64_t addr, const void *buf, uint32_t sz);
CUDBGResult gpudbgWriteRegister(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t regno, uint32_t val);

/* Grid Properties */
CUDBGResult gpudbgGetGridDim32(uint32_t dev, uint32_t sm, uint32_t wp, CuDim2 *gridDim);
CUDBGResult gpudbgGetBlockDim(uint32_t dev, uint32_t sm, uint32_t wp, CuDim3 *blockDim);
CUDBGResult gpudbgGetTID(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t *tid);
CUDBGResult gpudbgGetElfImage32(uint32_t devId, uint32_t sm, uint32_t wp, bool relocated, void **elfImage, uint32_t *size);

/* Device Properties */
CUDBGResult gpudbgGetDeviceType(uint32_t dev, char *buf, uint32_t sz);
CUDBGResult gpudbgGetSmType(uint32_t dev, char *buf, uint32_t sz);
CUDBGResult gpudbgGetNumDevices(uint32_t *numDev);
CUDBGResult gpudbgGetNumSMs(uint32_t dev, uint32_t *numSMs);
CUDBGResult gpudbgGetNumWarps(uint32_t dev, uint32_t *numWarps);
CUDBGResult gpudbgGetNumLanes(uint32_t dev, uint32_t *numLanes);
CUDBGResult gpudbgGetNumRegisters(uint32_t dev, uint32_t *numRegs);

/* DWARF */
CUDBGResult gpudbgGetPhysicalRegister30(uint64_t pc, char *reg, uint32_t *buf, uint32_t sz, uint32_t *numPhysRegs, CUDBGRegClass *regClass);
CUDBGResult gpudbgDisassemble(uint32_t dev, uint64_t address, uint32_t *instSize, char *buf, uint32_t sz);
CUDBGResult gpudbgIsDeviceCodeAddress55(uintptr_t address, bool *isDeviceAddress);
CUDBGResult gpudbgIsDeviceCodeAddress(uintptr_t address, bool *isDeviceAddress);
CUDBGResult gpudbgLookupDeviceCodeSymbol(char *symName, bool *symFound, uintptr_t *symAddr);

/* Events */
CUDBGResult gpudbgSetNotifyNewEventCallback31(CUDBGNotifyNewEventCallback31 callback, void *data);
CUDBGResult gpudbgGetNextEvent30(CUDBGEvent30 *event);
CUDBGResult gpudbgAcknowledgeEvent30(CUDBGEvent30 *event);

/* 3.1 extensions */
CUDBGResult gpudbgGetGridAttribute(uint32_t devId, uint32_t sm, uint32_t wp, CUDBGAttribute attr, uint64_t *value);
CUDBGResult gpudbgGetGridAttributes(uint32_t dev, uint32_t sm, uint32_t wp, CUDBGAttributeValuePair *pairs, uint32_t numPairs);
CUDBGResult gpudbgGetPhysicalRegister40(uint32_t dev, uint32_t sm, uint32_t wp, uint64_t pc, char *reg, uint32_t *buf, uint32_t sz, uint32_t *numPhysRegs, CUDBGRegClass *regClass);
CUDBGResult gpudbgReadLaneException(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t ln, CUDBGException_t *exception);
CUDBGResult gpudbgGetNextEvent32(CUDBGEvent32 *event);
CUDBGResult gpudbgAcknowledgeEvents42(void);

/* 3.1 - ABI */
CUDBGResult gpudbgReadCallDepth32(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t *depth);
CUDBGResult gpudbgReadReturnAddress32(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t level, uint64_t *ra);
CUDBGResult gpudbgReadVirtualReturnAddress32(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t level, uint64_t *ra);

/* 3.2 extensions */
CUDBGResult gpudbgReadGlobalMemory55(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t ln, uint64_t addr, void *buf, uint32_t sz);
CUDBGResult gpudbgWriteGlobalMemory55(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t ln, uint64_t addr, const void *buf, uint32_t sz);
CUDBGResult gpudbgReadPinnedMemory(uint64_t addr, void *buf, uint32_t sz);
CUDBGResult gpudbgWritePinnedMemory(uint64_t addr, const void *buf, uint32_t sz);
CUDBGResult gpudbgSetBreakpoint(uint32_t dev, uint64_t addr);
CUDBGResult gpudbgUnsetBreakpoint(uint32_t dev, uint64_t addr);
CUDBGResult gpudbgSetNotifyNewEventCallback40(CUDBGNotifyNewEventCallback40 callback);

/* 4.0 extensions */
CUDBGResult gpudbgGetNextEvent42(CUDBGEvent42 *event);
CUDBGResult gpudbgReadTextureMemory(uint32_t devId, uint32_t vsm, uint32_t wp, uint32_t id, uint32_t dim, uint32_t *coords, void *buf, uint32_t sz);
CUDBGResult gpudbgReadBlockIdx(uint32_t dev, uint32_t sm, uint32_t wp, CuDim3 *blockIdx);
CUDBGResult gpudbgGetGridDim(uint32_t dev, uint32_t sm, uint32_t wp, CuDim3 *gridDim);
CUDBGResult gpudbgReadCallDepth(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t *depth);
CUDBGResult gpudbgReadReturnAddress(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t level, uint64_t *ra);
CUDBGResult gpudbgReadVirtualReturnAddress(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t level, uint64_t *ra);
CUDBGResult gpudbgGetElfImage(uint32_t devId, uint32_t sm, uint32_t wp, bool relocated, void **elfImage, uint64_t *size);

/* 4.1 extensions */
CUDBGResult gpudbgGetHostAddrFromDeviceAddr(uint32_t devId, uint64_t device_addr, uint64_t *host_addr);
CUDBGResult gpudbgSingleStepWarp41(uint32_t dev, uint32_t sm, uint32_t wp, uint64_t *warpMask);
CUDBGResult gpudbgSetNotifyNewEventCallback(CUDBGNotifyNewEventCallback callback);
CUDBGResult gpudbgReadSyscallCallDepth(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t *depth);

/* 4.2 extensions */
CUDBGResult gpudbgReadTextureMemoryBindless(uint32_t devId, uint32_t vsm, uint32_t wp, uint32_t texSymtabIndex, uint32_t dim, uint32_t *coords, void *buf, uint32_t sz);

/* 5.0 extensions */
CUDBGResult gpudbgAcknowledgeSyncEvents(void);
CUDBGResult gpudbgGetNextSyncEvent50(CUDBGEvent50 *event);
CUDBGResult gpudbgGetNextAsyncEvent50(CUDBGEvent50 *event);
CUDBGResult gpudbgGetGridStatus50(uint32_t devId, uint32_t gridId, CUDBGGridStatus *status);

/* 5.5 extensions */
CUDBGResult gpudbgGetNextSyncEvent55(CUDBGEvent55 *event);
CUDBGResult gpudbgGetNextAsyncEvent55(CUDBGEvent55 *event);
CUDBGResult gpudbgGetGridInfo(uint32_t devId, uint64_t gridId64, CUDBGGridInfo *gridInfo);
CUDBGResult gpudbgReadGridId(uint32_t dev, uint32_t sm, uint32_t wp, uint64_t *gridId64);
CUDBGResult gpudbgGetGridStatus(uint32_t devId, uint64_t gridId64, CUDBGGridStatus *status);
CUDBGResult gpudbgSetKernelLaunchNotificationMode(CUDBGKernelLaunchNotifyMode mode);
CUDBGResult gpudbgGetDevicePCIBusInfo (uint32_t devId, uint32_t *pciBusId, uint32_t *pciDevId);
CUDBGResult gpudbgReadDeviceExceptionState80 (uint32_t devId, uint64_t *exceptionSMMask);

/* 6.0 extensions */
CUDBGResult gpudbgGetAdjustedCodeAddress(uint32_t devId, uint64_t addr, uint64_t *adjustedAddress, CUDBGAdjAddrAction adjAction);
CUDBGResult gpudbgGetElfImageByHandle(uint32_t devId, uint64_t handle, CUDBGElfImageType type, void *elfImage, uint64_t size);
CUDBGResult gpudbgGetNextEvent(CUDBGEventQueueType type, CUDBGEvent *event);
CUDBGResult gpudbgResumeWarpsUntilPC(uint32_t devId, uint32_t sm, uint64_t warpMask, uint64_t virtPC);
CUDBGResult gpudbgReadWarpState (uint32_t devId, uint32_t sm, uint32_t wp, CUDBGWarpState *state);
CUDBGResult gpudbgReadRegisterRange (uint32_t dev, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t index, uint32_t registers_size, uint32_t *registers);
CUDBGResult gpudbgReadGenericMemory(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t ln, uint64_t addr, void *buf, uint32_t sz);
CUDBGResult gpudbgWriteGenericMemory(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t ln, uint64_t addr, const void *buf, uint32_t sz);
CUDBGResult gpudbgReadGlobalMemory(uint64_t addr, void *buf, uint32_t sz);
CUDBGResult gpudbgWriteGlobalMemory(uint64_t addr, const void *buf, uint32_t sz);
CUDBGResult gpudbgGetManagedMemoryRegionInfo (uint64_t startAddress, CUDBGMemoryInfo *memoryInfo,
                                              uint32_t memoryInfo_size, uint32_t *numEntries);
CUDBGResult gpudbgRequestCleanupOnDetach(uint32_t appResumeFlag);

/* 6.5 extensions */
CUDBGResult gpudbgReadPredicates(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t predicates_size, uint32_t *predicates);
CUDBGResult gpudbgWritePredicates(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t predicates_size, const uint32_t *predicates);
CUDBGResult gpudbgGetNumPredicates(uint32_t dev, uint32_t *numPredicates);
CUDBGResult gpudbgReadCCRegister(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t *val);
CUDBGResult gpudbgWriteCCRegister(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t val);

CUDBGResult gpudbgGetDeviceName(uint32_t dev, char *buf, uint32_t sz);
CUDBGResult gpudbgSingleStepWarp(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t nsteps, uint64_t *warpMask);

/* 9.0 extensions */
CUDBGResult gpudbgReadDeviceExceptionState (uint32_t devId, uint64_t *mask, uint32_t numWords);

/* 10.0 extensions */
CUDBGResult gpudbgReadUniformRegisterRange(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t index, uint32_t registers_size, uint32_t *registers);
CUDBGResult gpudbgWriteUniformRegister(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t regno, uint32_t val);
CUDBGResult gpudbgReadUniformPredicates(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t predicates_size, uint32_t *predicates);
CUDBGResult gpudbgWriteUniformPredicates(uint32_t dev, uint32_t sm, uint32_t wp, uint32_t predicates_size, const uint32_t *predicates);
CUDBGResult gpudbgGetNumUniformPredicates(uint32_t devId, uint32_t *numPredicates);


/*----------------------------TLS Functions---------------------------------*/
typedef enum {
    CUDBG_TLS_NOTIFY_CALLBACK_INACTIVE = 0,
    CUDBG_TLS_NOTIFY_CALLBACK_ACTIVE = 1,
} CUDBGTlsCallbackState;

static CUOSTLSEntry g_cudbgTlsKey;
static uint32_t g_cudbgTlsKey_used = 0;

static void cudbgTlsInitialize(void);
static void cudbgTlsFinalize(void);
static CUDBGTlsCallbackState cudbgTlsGetCallbackState(void);
static void cudbgTlsSetCallbackState(CUDBGTlsCallbackState state);

/*---------------- PTX to SASS Register Map Table Declaration --------------*/

/*
 * The PTX to SASS register map table is made of a series of entries,
 * one per function. Each function entry is made of a list of register
 * mappings, from a PTX register to a SASS register. The table size is
 * saved in the first 32 bits.
 *
 *      | table size |
 *      | fct name | size of entries below, in bytes |
 *        | idx | ptxReg | sassReg | start | end |
 *        | idx | ptxReg | sassReg | start | end |
 *        ...
 *        | idx | ptxReg | sassReg | start | end |
 *      | fct name | size of entries below, in bytes |
 *        | idx | ptxReg | sassReg | start | end |
 *        ...
 *      ...
 *
 * A PTX reg is mapped to one more SASS registers. If a PTX register
 * is mapped to more than one SASS register, multiple entries are
 * required and the 'idx' field is incremented by 1 for each one of
 * them. The 'start' and 'end' addresses indicate the physical address
 * between which the mapping is valid.
 */

typedef union {
    char         *byte;
    Dwarf_Word   *word;
    uint32_t     *funcSize;
    uint32_t     *tableSize;
    uint32_t     *idx;
    char         *ptxReg;
    uint32_t     *sassReg;
    uint32_t     *start;
    uint32_t     *end;
} regMapMagicCast_t;

typedef struct {
    char* name;
    uint32_t size;
} regMapFuncEntry_t;

typedef struct {
    uint32_t     idx;
    char        *ptxReg;
    uint32_t     sassReg;
    uint32_t     start;
    uint32_t     end;
} regMapRegEntry_t;

static CUDBGResult       gpudbgRegMapInitialize(elf_t elfImage, char **regMap);
static CUDBGResult       gpudbgRegMapPrint(char *regMap);
static regMapMagicCast_t gpudbgRegMapReadFuncEntry(regMapMagicCast_t regMapPtr, regMapFuncEntry_t *funcEntry);
static regMapMagicCast_t gpudbgRegMapReadRegEntry(regMapMagicCast_t regMapPtr, regMapRegEntry_t *regEntry);
static CUDBGResult       gpudbgRegMapSearch(char *regMap, char *funcName, char *regName, uint64_t addr, uint32_t *buffer, uint32_t size, uint32_t *numRegs, CUDBGRegClass *regClass);

static CUDBGResult
resolvePatchToEntryAddr_common(CudbgDevice dev, uint32_t sm, uint32_t wp, uint32_t ln,
                               uint64_t *pc, bool *patchDebug, bool virt, bool debugPatch);


/*--------------------------- Global Module State ----------------------------*/

static bool                  moduleInitialized;

/*
 * Contexts is a mapping from "handle" to Context (which tracks CUDA
 * contexts). "Handle" is the address of the Ctx structure in the
 * _client_ (eg. CUDA driver) process address space ([XXX
 * multi-context] we could change this to use ctxId from that
 * structure which is safer as it's guaranteed unique even after the
 * original context is released).
 *
 * Context is an aggregation of target layer handle to the gpu,
 * assorted information, and the current executing grid.
 *
 * New contexts are added by the CUDA driver as new contexts are
 * created (cuiCtxCreate).
 */
static tHashMap             *pendingPatches;

static tRangeMap            *virtAddrToFunction;
static tRangeMap            *brokenVirtAddrToFunction;

static void deleteBreakpoint(void *entry, void *data);
static CUDBGResult deleteContext(Context context, bool removeFromMap);
static CUDBGResult deleteContextWrap(Context context, void *data);
static void deleteModule(DeviceModule module, bool removeFromMap);
static void deleteModuleWrap(void *entry, void *data);
static void deleteFunction(DeviceFunction func, bool removeFromMap);
static void deleteFunctionWrap(void *entry, void *data);
static void deleteGrid(Grid grid);
static void deletePatch(void *entry, void *data);
static void deleteMultiEntryPatch(void *entry, void *data);

static CUDBGResult
cudbgApiCheck(uint32_t flags, uint32_t origLine, uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln)
{
    uint32_t verifFlags = flags;
    /* Extra check for the flags
        LN_VALID implies LN, WP_VALID, WP, SM, DEV_SUSPENDED, DEV_STATUS, DEV_ID, TLS, INIT
        LN       implies WP_VALID, WP, SM, DEV_SUSPENDED, DEV_STATUS, DEV_ID, TLS, INIT
        WP_VALID implies WP, SM, DEV_SUSPENDED, DEV_STATUS, DEV_ID, TLS, INIT
        WP       implies SM, DEV_SUSPENDED, DEV_STATUS, DEV_ID, TLS, INIT
        SM       implies DEV_SUSPENDED, DEV_STATUS, DEV_ID, TLS, INIT
        DEV_SUSPENDED implies DEV_ID, DEV_STATUS, TLS, INIT
        DEV_ACTIVECTX implies DEV_SUSPENDED, DEV_STATUS, DEV_ID, TLS, INIT
        DEV_STATUS    implies DEV_ID, TLS, INIT
        DEV_ID        implies TLS, INIT
    */
    if (verifFlags & CUDBG_API_CHECK_LN_VALID)
        verifFlags |= CUDBG_API_CHECK_LN;

    if (verifFlags & CUDBG_API_CHECK_LN)
        verifFlags |= CUDBG_API_CHECK_WP;

    if (verifFlags & CUDBG_API_CHECK_WP_VALID)
        verifFlags |= CUDBG_API_CHECK_WP;

    if (verifFlags & CUDBG_API_CHECK_WP)
        verifFlags |= CUDBG_API_CHECK_SM;

    if (verifFlags & CUDBG_API_CHECK_SM)
        verifFlags |= CUDBG_API_CHECK_DEV_SUSPENDED;

    if (verifFlags & CUDBG_API_CHECK_DEV_ACTIVECTX)
        verifFlags |= CUDBG_API_CHECK_DEV_SUSPENDED;

    if (verifFlags & CUDBG_API_CHECK_DEV_SUSPENDED)
        verifFlags |= CUDBG_API_CHECK_DEV_STATUS;

    if (verifFlags & CUDBG_API_CHECK_DEV_STATUS)
        verifFlags |= CUDBG_API_CHECK_DEV_ID;

    if (verifFlags & CUDBG_API_CHECK_DEV_ID) {
        verifFlags |= CUDBG_API_CHECK_TLS_CB;
        verifFlags |= CUDBG_API_CHECK_INIT;
    }

    /* Check and override flags */
    if ((verifFlags & flags) != verifFlags) {
        CUDBG_ERROR("[%u] Mismatch between verifFlags and flags \n", origLine);
        flags |= verifFlags;
    }

    /* Do the actual checks */

    if (flags & CUDBG_API_CHECK_INIT)
        CUDBG_VERIFY(moduleInitialized,
                     CUDBG_ERROR_UNINITIALIZED,
                     "[%u] Module not initialized.\n", origLine);

    if (flags & CUDBG_API_CHECK_TLS_CB)
        CUDBG_VERIFY(cudbgTlsGetCallbackState() == CUDBG_TLS_NOTIFY_CALLBACK_INACTIVE,
                     CUDBG_ERROR_RECURSIVE_API_CALL, "[%u] Recursive API call\n", origLine);

    if (flags & CUDBG_API_CHECK_DEV_ID) {
        CudbgDevice dev;

        CUDBG_VERIFY(devId < CUDBG_MAX_DEVICES,
                     CUDBG_ERROR_INVALID_DEVICE,
                     "[%u] Invalid device ID : %u.\n", origLine, devId);

        CUDBG_VERIFY(haloGlobals.device[devId],
                     CUDBG_ERROR_INVALID_DEVICE,
                     "[%u] Invalid device. No allocation for devID:%u\n", origLine, devId);

        dev = haloGlobals.device[devId];

        if (flags & CUDBG_API_CHECK_DEV_SUSPENDED) {
            if (clientRevision > API_REVISION_5_5)
                CUDBG_VERIFY(dev->suspended,
                             CUDBG_ERROR_RUNNING_DEVICE,
                             "[%u] Device is still running\n", origLine);
        }

        if (flags & CUDBG_API_CHECK_DEV_STATUS) {
            if (dev->status) {
                CUDBG_ERROR("[%u] Device has pending error status : %u\n",
                            origLine,
                            dev->status);
                return dev->status;
            }
        }

        if (flags & CUDBG_API_CHECK_DEV_ACTIVECTX) {
            CUDBG_VERIFY(dev->activeContext,
                         CUDBG_ERROR_INVALID_CONTEXT,
                         "[%u] Invalid active context.\n", origLine);
        }


        if (flags & CUDBG_API_CHECK_SM) {
            CUDBG_VERIFY(sm < CUDBG_MAX_SMS,
                         CUDBG_ERROR_INVALID_SM,
                         "[%u] Invalid SM (smID:%u exceeds MAX:%u) \n",
                         origLine, sm, CUDBG_MAX_SMS);
            CUDBG_VERIFY(sm < dev->halo.deviceInfo.numSMs,
                         CUDBG_ERROR_INVALID_SM,
                         "[%u] Invalid SM (smID:%u exceeds dev->max:%u\n",
                         origLine, sm, dev->halo.deviceInfo.numSMs);
        }

        if (flags & CUDBG_API_CHECK_WP) {
            CUDBG_VERIFY(wp < CUDBG_MAX_WARPS,
                         CUDBG_ERROR_INVALID_WARP,
                         "[%u] Invalid warp (wp:%u exceeds MAX:%u)\n",
                         origLine, wp, CUDBG_MAX_WARPS);
            CUDBG_VERIFY(wp < dev->halo.deviceInfo.numWarpsPrSM,
                         CUDBG_ERROR_INVALID_WARP,
                         "[%u] Invalid warp. (wp:%u exceeds dev->max:%u\n",
                         origLine, wp, dev->halo.deviceInfo.numWarpsPrSM);

            if (flags & CUDBG_API_CHECK_WP_VALID)
                CUDBG_VERIFY(dev->smState[sm].warp[wp].valid,
                             CUDBG_ERROR_INVALID_WARP,
                             "[%u] Invalid warp.\n", origLine);
        }

        if (flags & CUDBG_API_CHECK_LN) {
            CUDBG_VERIFY(ln < CUDBG_MAX_LANES,
                         CUDBG_ERROR_INVALID_LANE,
                         "[%u] Invalid lane (ln:%u exceeds MAX:%u)\n",
                         origLine, ln, CUDBG_MAX_LANES);
            CUDBG_VERIFY(ln < dev->halo.deviceInfo.numLanesPrWarp,
                         CUDBG_ERROR_INVALID_LANE,
                         "[%u] Invalid lane (ln:%u exceeds dev->max:%u)\n",
                         origLine, ln, dev->halo.deviceInfo.numLanesPrWarp);

            if (flags & CUDBG_API_CHECK_LN_VALID)
                CUDBG_VERIFY(dev->smState[sm].warp[wp].validLanes & (1U << ln),
                             CUDBG_ERROR_INVALID_LANE,
                             "[%u] Invalid lane.\n", origLine);
        }

    }

    return CUDBG_SUCCESS;
}


/*---------------------------TLS Functions------------------------------------*/

static void
cudbgTlsInitialize(void)
{
    if (g_cudbgTlsKey_used)
        return;

    g_cudbgTlsKey = cuosTlsAlloc(NULL);
    g_cudbgTlsKey_used = 1;
}

static void
cudbgTlsFinalize(void)
{
    if (!g_cudbgTlsKey_used)
        return;

    cuosTlsFree(g_cudbgTlsKey);
    g_cudbgTlsKey_used = 0;
}


static CUDBGTlsCallbackState
cudbgTlsGetCallbackState(void)
{
    if (!g_cudbgTlsKey_used)
        return CUDBG_TLS_NOTIFY_CALLBACK_INACTIVE;

    return (CUDBGTlsCallbackState)(uintptr_t)cuosTlsGetValue(g_cudbgTlsKey);
}

static void
cudbgTlsSetCallbackState(CUDBGTlsCallbackState state)
{
    if (!g_cudbgTlsKey_used)
        return;

    cuosTlsSetValue(g_cudbgTlsKey, (void*)(intptr_t)state);
}

/*------------------ PTX to SASS Register Map Table Routines -----------------*/

/*
 * Initialize the register map before use.
 */
static CUDBGResult
gpudbgRegMapInitialize(elf_t elfImage, char **regMap)
{
    const char section[] = ".nv_debug_info_reg_sass";
    char *tableEnd;
    uint32_t *regMapSize;
    uint32_t elf_section_size;
    uint64_t elf_section_offset;
    regMapMagicCast_t regMapPtr;

    /*  sanity */
    CUDBG_VERIFY(elfImage, CUDBG_ERROR_INVALID_ARGS, "ELF image is NULL in gpudbgRegMapInitialize.\n");
    CUDBG_VERIFY(regMap, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in gpudbgRegMapInitialize.\n");

    /*  Handle 32/64-bit ELF Images */
    if (elf_is_64bit(elfImage)) {
        /*  access the .nv_debug_info_reg_sass section */
        const elf64SectionHeader *esh64 = elf64_named_section_header (elfImage, section);
        if (!esh64) {
            /*  If the application was not compiled for debug mode, there will
               not be a .nv_debug_info_reg_sass section in the ELF image
            */
            API_TRACE(3, "Cannot locate regmap section: %s "
                      "(Possibly no debug info)\n", section);
            *regMap = NULL;
            return CUDBG_SUCCESS;
        }
        elf_section_size = (uint32_t)esh64->size;
        elf_section_offset = esh64->offset;
    }
    else {
        const elf32SectionHeader *esh32 = elf32_named_section_header (elfImage, section);
        /*  access the .nv_debug_info_reg_sass section */
        if (!esh32) {
            /* If the application was not compiled for debug mode, there will
               not be a .nv_debug_info_reg_sass section in the ELF image
            */
            API_TRACE(3, "Cannot locate regmap section: %s "
                      "(Possibly no debug info)\n", section);
            *regMap = NULL;
            return CUDBG_SUCCESS;
        }
        elf_section_size = (uint32_t)esh32->size;
        elf_section_offset = esh32->offset;
    }

    /*  copy the whole table as-is after saving its size in the first
       32 bits
    */
    *regMap = (char*) malloc((size_t)elf_section_size + sizeof(uint32_t));
    CUDBG_VERIFY(*regMap != NULL, CUDBG_ERROR_OS_RESOURCES, "Failed to allocate memory!\n");
    regMapPtr.byte = *regMap;
    regMapSize = regMapPtr.funcSize++;
    *regMapSize = elf_section_size;
    memcpy(regMapPtr.byte, ((char*)elfImage) + elf_section_offset, *regMapSize);

    /* Replace the number of entries by the total size of the entries.
       Makes it easier to jump over a whole function.
       Entry size is not fixed because ptxReg length is variable.
       Compiler team agrees replacing numEntries by size would make
       more sense.
    */
    tableEnd = regMapPtr.byte + *regMapSize;
    while (regMapPtr.byte < tableEnd) {
        Dwarf_Word i, numEntry, *funcSize;
        char *funcStart;
        regMapPtr.byte += strlen(regMapPtr.byte)+1;
        funcSize  = regMapPtr.word;
        numEntry  = *regMapPtr.word++;
        funcStart = regMapPtr.byte;
        for (i = 0; i < numEntry; i++) {
            regMapPtr.word += 1;
            regMapPtr.byte += strlen(regMapPtr.byte) + 1;
            regMapPtr.word += 3;
        }
        *funcSize = (Dwarf_Word) (regMapPtr.byte - funcStart);
    }

    return CUDBG_SUCCESS;
}


/*
 * Free all the memory used by the register map before it is to be retired.
 */

/*
 * Read the function entry pointed by regMapPtr.
 */
static regMapMagicCast_t
gpudbgRegMapReadFuncEntry(regMapMagicCast_t regMapPtr, regMapFuncEntry_t *funcEntry)
{
    funcEntry->name = regMapPtr.byte;
    regMapPtr.byte += strlen(regMapPtr.byte)+1;
    funcEntry->size = *regMapPtr.funcSize++;
    return regMapPtr;
}


/*
 * Read the register entry pointed by the regMapPtr.
 */
static regMapMagicCast_t
gpudbgRegMapReadRegEntry(regMapMagicCast_t regMapPtr, regMapRegEntry_t *regEntry)
{
    regEntry->idx     = *regMapPtr.idx++;
    regEntry->ptxReg  = regMapPtr.ptxReg;
    regMapPtr.byte   += strlen(regMapPtr.byte)+1;
    regEntry->sassReg = *regMapPtr.sassReg++;
    regEntry->start   = *regMapPtr.start++;
    regEntry->end     = *regMapPtr.end++;
    return regMapPtr;
}


/*
 * Print the whole register map to stderr (for debugging)
 */
static CUDBGResult
gpudbgRegMapPrint(char *regMap)
{
    regMapFuncEntry_t funcEntry = {0, 0};
    regMapRegEntry_t regEntry   = {0, 0, 0, 0, 0};
    char *tableEnd, *funcEnd;
    regMapMagicCast_t regMapPtr;
    uint32_t regMapSize;

    CUDBG_VERIFY(regMap, CUDBG_ERROR_INVALID_ARGS, "regMap is NULL in gpudbgRegMapPrint.\n");

    regMapPtr.byte = regMap;
    regMapSize = *regMapPtr.tableSize++;
    tableEnd = regMapPtr.byte + regMapSize;
    while (regMapPtr.byte < tableEnd) {
        regMapPtr = gpudbgRegMapReadFuncEntry(regMapPtr, &funcEntry);
        API_TRACE(3, "Function: %s (%d bytes)\n", funcEntry.name, (int) funcEntry.size);
        funcEnd = regMapPtr.byte + funcEntry.size;
        while (regMapPtr.byte < funcEnd) {
            regMapPtr = gpudbgRegMapReadRegEntry(regMapPtr, &regEntry);
            API_TRACE(3, "%d %-5s -> 0x%08x   0x%08x, 0x%08x\n",
                      regEntry.idx, regEntry.ptxReg, regEntry.sassReg, regEntry.start, regEntry.end);
        }
    }
    return CUDBG_SUCCESS;
}


/*
 * Find the mapping for register regName in function funcName.
 * Returns 1 if found, 0 otherwise.
 */
static CUDBGResult
gpudbgRegMapSearch(char *regMap, char *funcName, char *regName, uint64_t addr,
                   uint32_t *buffer, uint32_t size, uint32_t *numRegs, CUDBGRegClass *regClass)
{
    regMapFuncEntry_t funcEntry = {0, 0};
    regMapRegEntry_t regEntry   = {0, 0, 0, 0, 0};
    int funcFound;
    char *tableEnd, *funcEnd;
    uint32_t regMapSize;
    regMapMagicCast_t regMapPtr;
    bool found[2];

    CUDBG_VERIFY(regMap, CUDBG_ERROR_UNINITIALIZED, "Register mapping does not exist.\n");

    /*  find function entry */
    funcFound = 0;
    regMapPtr.byte = regMap;
    regMapSize = *regMapPtr.tableSize++;
    tableEnd = regMapPtr.byte + regMapSize;
    while (regMapPtr.byte < tableEnd) {
        regMapPtr = gpudbgRegMapReadFuncEntry(regMapPtr, &funcEntry);
        funcFound = (strcmp(funcEntry.name, funcName)==0);
        if (funcFound)
            break;
        regMapPtr.byte += funcEntry.size;
    }

    CUDBG_VERIFY(funcFound, CUDBG_ERROR_UNKNOWN_FUNCTION, "Unknown function when looking for register mapping.\n");

    /*  find all the relevant register entries */
    memset(found, 0, sizeof found);
    *numRegs = 0;
    funcEnd = regMapPtr.byte + funcEntry.size;
    while (regMapPtr.byte < funcEnd) {
        regMapPtr = gpudbgRegMapReadRegEntry(regMapPtr, &regEntry);
        if (strcmp(regEntry.ptxReg, regName)==0 &&
            regEntry.start <= addr && addr <= regEntry.end) {
            if (found[regEntry.idx])
                /* that should not happen, but the compiler somehow
                   has duplicate live ranges...
                */
                continue;
            if (*numRegs > 0 && *regClass != regEntry.sassReg >> 24)
                /* that should not happen, but the compiler somehow allows the
                   same variable to be simultaneously live in a register and
                   in the stack sometimes. And their entries can be interleaved...
                */
                continue;
            CUDBG_VERIFY((++*numRegs * sizeof *buffer <= size), CUDBG_ERROR_BUFFER_TOO_SMALL, "Buffer is too small.\n");

            found[regEntry.idx] = true;
            buffer[regEntry.idx] = regEntry.sassReg & 0xffffff;
            *regClass = (CUDBGRegClass)(regEntry.sassReg >> 24);
            if (*numRegs >= 2)
                break; /*  shortcut */
        }
    }

    return CUDBG_SUCCESS;
}

/*----------------------------- Patch Handling -------------------------------*/
static CUDBGResult resolvePatchToEntryAddr(CudbgDevice dev, uint32_t sm, uint32_t wp, uint32_t ln,  uint64_t *pc, bool *patchDebug);

static uint32_t dbgPatchId;
/* Translate the virtual address to a GPU PC and optionally a GPU Device VAddr. This call
   handles patch debugging gracefully for internal builds
*/
static CUDBGResult
translateVirtualAddrToPCAndDevVA(uint64_t virtAddr, Context ctx, uint64_t *physAddr, uint64_t *pDevVAddr)
{
    DebugPatch patch = NULL;
    CUDBGResult res = CUDBG_SUCCESS;
    bool inPatch = false;
    DeviceFunction function;
    uint64_t virtualAddrOffset;
    uint64_t gpuAddr, devVAddr;
    bool hidden;

    CUDBG_VERIFY(physAddr, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in translateVirtualAddrToPCAndDevVA.\n");
    CUDBG_VERIFY(ctx && ctx->virtAddrToPatch, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context in translateVirtualAddrToPCAndDevVA.\n");

    /* This call will always return false on release builds */
    res = haloInPatchRegion(virtAddr, ctx, &patch, CUDBG_PATCH_ALL, &inPatch,
                            true);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to haloInPatchRegion failed in translateVirtualAddrToPCAndDevVA.\n");
        return res;
    }

    if (inPatch && patch && patch->debug) {
        gpuAddr = virtAddr - patch->virtAddr + patch->gpuAddr;
        devVAddr = virtAddr - patch->virtAddr + patch->devVAddr;
        devVAddr = gpuAddr + ctx->funcMemBaseVA;
    }
    else {
        function = (DeviceFunction)toolsRangeMapLookupByAddr(virtAddrToFunction, virtAddr);
        CUDBG_VERIFY(function, CUDBG_ERROR_INVALID_ADDRESS, "Invalid address.\n");

        res = haloInHiddenFunction(function, &hidden);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "error calling haloInHiddenFunction\n");
        CUDBG_VERIFY(!hidden, CUDBG_ERROR_INVALID_ADDRESS, "in hidden function %s\n",
                     function->name);

        virtualAddrOffset = virtAddr - function->virtAddrBase;
        CUDBG_VERIFY(virtualAddrOffset < function->codeSize, CUDBG_ERROR_INVALID_ARGS, "Invalid offset in function.\n");
        gpuAddr = virtualAddrOffset + function->gpuAddrBase;
        devVAddr = virtualAddrOffset + function->devVAddr;
    }

    *physAddr = gpuAddr;

    if (pDevVAddr)
        *pDevVAddr = devVAddr;

    API_TRACE(40, "Translated virtual->physical address 0x%" PRIx64 " -> 0x%" PRIx64 " (VA:0x%" PRIx64 "\n",
              virtAddr, gpuAddr, devVAddr);

    return CUDBG_SUCCESS;
}

static DebugPatch
dbgCreatePatch(uint32_t kind, uint64_t gpuAddr, uint32_t size,
               uint64_t devVAddr, uint64_t virtAddr, uint64_t entryAddr,
               bool isMultiEntry, Context context, uint32_t depth,
               CudbgStepResumeType stepResumeType)
{
    DebugPatch patch;

    patch = (DebugPatch)calloc(1, sizeof(*patch));
    if (!patch)
        return NULL;

    patch->breakPoints = toolsHashMapNew(toolsUint32HashFun, toolsUint64EqualFun, 16);
    if (!patch->breakPoints) {
        free(patch);
        return NULL;
    }

    patch->temporaryBreakPoints = toolsHashMapNew(toolsUint32HashFun, toolsUint64EqualFun, 16);
    if (!patch->temporaryBreakPoints) {
        toolsHashMapDelete(patch->breakPoints, NULL, NULL);
        free(patch);
        return NULL;
    }

    patch->devVAddr = devVAddr;
    patch->gpuAddr = gpuAddr;
    patch->size = size;
    patch->virtAddr = virtAddr;
    patch->entryAddr = entryAddr;
    patch->kind = kind;
    patch->context = context;
    patch->patchId = dbgPatchId++;
    patch->depth = depth;
    patch->stepResumeType = stepResumeType;

    patch->debug = (cudbgEnableMemcheckDebugging && kind == CUDBG_PATCH_MEMCHECK) || (cudbgEnableSyscallDebugging && kind == CUDBG_PATCH_SYSCALL) || (cudbgEnableInternalDebugging);

    patch->multiEntry = isMultiEntry;

    return patch;
}

static void
dbgDestroyPatch(DebugPatch patch)
{
    if (!patch)
        return;

    toolsHashMapDelete(patch->breakPoints, deleteBreakpoint, NULL);
    toolsHashMapDelete(patch->temporaryBreakPoints, deleteBreakpoint, NULL);

    free(patch);
}

static CUDBGResult
dbgAddPatchEntry(uint64_t addr, DebugPatch patch)
{
    TOOLSresult tres = TOOLS_SUCCESS;

    CUDBG_VERIFY(patch && patch->context, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context in dbgAddPatchEntry.\n");

    CUDBG_TRACE(" Added patch (0x%p) entry  at PC: 0x%08x hopsize: %u\n", patch, addr, patch->hopSize);

    tres = toolsHashMapInsert(patch->context->patchEntry, tHashMapNumToKey(addr), (void*)patch);
    CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_UNKNOWN, "Failed to insert patch into patchEntry map. (tres=%u)\n", tres);

    return CUDBG_SUCCESS;
}

static CUDBGResult
dbgAddPatch(DebugPatch patch, bool *inserted)
{
    CUDBGResult res = CUDBG_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;

    if (inserted)
        *inserted = false;

    CUDBG_VERIFY(patch && patch->context, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context in dbgAddPatch.\n");

    res = patch->context->dev->halo.getInstructionSize(patch->origInst[0],
                                                       &patch->hopSize);
    if (res != CUDBG_SUCCESS)
        return res;

    if (patch->size) {
        /* Shared patches may return TOOLS_ERROR_DUPLICATE_KEY here */
        tres = toolsRangeMapInsertByRange(patch->context->gpuAddrToPatch,
                                          patch->gpuAddr, patch->size,
                                          (void*)patch);
        CUDBG_VERIFY(tres == TOOLS_SUCCESS || tres == TOOLS_ERROR_DUPLICATE_KEY,
                     CUDBG_ERROR_UNKNOWN,
                     "Failed to insert into gpuAddrToPatch map (tres=%u)\n", tres);
        if (tres == TOOLS_SUCCESS && inserted)
            *inserted = true;
#ifndef RELEASE
        CUDBG_VERIFY(patch->virtAddr, CUDBG_ERROR_UNKNOWN, "Invalid patch virtAddr\n");
        tres = toolsRangeMapInsertByRange(patch->context->virtAddrToPatch,
                                          patch->virtAddr, patch->size,
                                          (void*)patch);
        CUDBG_VERIFY(tres == TOOLS_SUCCESS || tres == TOOLS_ERROR_DUPLICATE_KEY,
                     CUDBG_ERROR_UNKNOWN,
                     "Failed to insert into virtAddrToPatch map (tres=%u)\n", tres);
        if (tres == TOOLS_SUCCESS && inserted)
            *inserted = true;
#endif
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
dbgRemovePatch(DebugPatch patch)
{
    TOOLSresult tres = TOOLS_SUCCESS;

    if (!patch)
        return CUDBG_SUCCESS;

    CUDBG_VERIFY(patch->context, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context in dbgRemovePatch\n");

    if (patch->size) {
        (void)toolsRangeMapRemoveByAddr(patch->context->gpuAddrToPatch,
                                        patch->gpuAddr);
#ifndef RELEASE
        (void)toolsRangeMapRemoveByAddr(patch->context->virtAddrToPatch,
                                        patch->virtAddr);
#endif
    }

    if (patch->entryAddr) {
        tres = toolsHashMapRemove(patch->context->patchEntry, tHashMapNumToKey(patch->entryAddr), NULL);
        CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_UNKNOWN,
                     "Failed to remove from patchEntry map (tres=%u)\n", tres);
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
dbgAddPendingPatch(DebugPatch patch, uint64_t ctx)
{
    TOOLSresult tres = TOOLS_SUCCESS;
    tList* pl = (tList *)toolsHashMapFind(pendingPatches, tHashMapNumToKey(ctx));

    if (!pl) {
        pl = toolsListNew();
        CUDBG_VERIFY(pl, CUDBG_ERROR_UNKNOWN, "Failed to create new list\n");

        tres = toolsHashMapInsert(pendingPatches, tHashMapNumToKey(ctx), (void*)pl);
        CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_UNKNOWN, "Failed to insert list to pending map (tres=%u)\n", tres);
    }

    tres = toolsListAppend(pl, patch);
    CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_UNKNOWN, "Failed to insert patch into list(tres=%u)\n", tres);
    CUDBG_TRACE(" Added a pending patch for ctx: %p\n", ctx);
    return CUDBG_SUCCESS;
}

static CUDBGResult
dbgRemovePendingPatch(uint64_t ctx, uint64_t patchDevVaddr, DebugPatch *pPatch)
{
    tList *pl = (tList*)toolsHashMapFind(pendingPatches, tHashMapNumToKey(ctx));
    DebugPatch patch, target = NULL;
    tListItr *it;

    // Nothing to do, no pending patch list for ctx
    if (!pl)
        return CUDBG_SUCCESS;

    /* Iterate over the list and look for the patch by devvaddr */
    for (it = toolsListGetIterator(pl);
         it;
         it = toolsListGetNext(it)) {
        patch = (DebugPatch)toolsListGetElem(it);

        if (patch->devVAddr == patchDevVaddr) {
            target = patch;
            break;
        }
    }

    /* If we found the patch, remove it from the pending list and
       destroy it */
    if (target) {
        (void)toolsListRemove(pl, target, NULL, 1);

        *pPatch = target;
        target = NULL;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
dbgDumpPatch(DebugPatch p)
{
    unsigned int i;
    uint64_t inst;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(p->context, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context in dbgDumpPatch.\n");

    CUDBG_DEBUG("Dumping patch: id:%u, size:%u\n",p->patchId, p->size);
    CUDBG_DEBUG("pc  |  Inst\n");
    for (i = 0; i < p->size / 8; ++i) {
        res = p->context->dev->halo.readCodeMemory(p->context, p->gpuAddr+8*i, &inst, 8);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to readCodeMemory failed in dbgDumpPatch.\n");
            return res;
        }
        CUDBG_DEBUG("0x%lx | %016lx\n", p->gpuAddr + 8*i, inst);
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
dbgRelocateSinglePatch(DebugPatch p, Context ctx)
{
    CUDBGResult res = CUDBG_SUCCESS;
    p->context = ctx;
    res = dbgAddPatch(p, NULL);
    if(res != CUDBG_SUCCESS) {
        (void)dbgRemovePatch(p);
        return res;
    }

    res = dbgAddPatchEntry(p->entryAddr, p);
    return res;
}

static CUDBGResult
dbgRelocatePendingPatch(uint64_t cuctx, Context ctx)
{
    TOOLSresult tres = TOOLS_SUCCESS;
    CUDBGResult res = CUDBG_SUCCESS;
    tListItr *itr;
    tList* pl = (tList *)toolsHashMapFind(pendingPatches, tHashMapNumToKey(cuctx));

    if (pl) {
        for (itr = toolsListGetIterator(pl);
             itr;
             itr = toolsListGetNext(itr)) {
            res = dbgRelocateSinglePatch((DebugPatch)toolsListGetElem(itr), ctx);
            if(res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Unable to relocate patch\n");
                return res;
            }
        }

        tres = toolsHashMapRemove(pendingPatches, tHashMapNumToKey(cuctx), NULL);
        CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_UNKNOWN, "Failed to remove list from map. (tres=%u)\n", tres);
        tres = toolsListDelete(pl, NULL, NULL);
        CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_UNKNOWN, "Failed to delete list (tres=%u)\n", tres);
    }

    return CUDBG_SUCCESS;
}

static void
dbgPrintPatch(DebugPatch patch)
{
    if (!patch)
        return;

    API_TRACE_FUNCTION(50, "  Patch Id      : %u  \n", patch->patchId);
    API_TRACE_FUNCTION(50, "  Patch Kind    : %u  \n", patch->kind);
    API_TRACE_FUNCTION(50, "  GPU Address   : 0x%x\n", patch->gpuAddr);
    API_TRACE_FUNCTION(50, "  GPU DevVAddr  : 0x%" PRIx64 "\n", patch->devVAddr);
    API_TRACE_FUNCTION(50, "  Size (bytes)  : %u  \n", patch->size);
    API_TRACE_FUNCTION(50, "  Virt Address  : 0x%x\n", patch->virtAddr);
    API_TRACE_FUNCTION(50, "  Entry Address : 0x%x\n", patch->entryAddr);
    API_TRACE_FUNCTION(50, "  HopSize       : %u  \n", patch->hopSize);
    API_TRACE_FUNCTION(50, "  Resume type   : %u  \n", patch->stepResumeType);
    API_TRACE_FUNCTION(50, "  Original Inst : 0x%016" PRIx64 " 0x%016" PRIx64 "\n", patch->origInst[0], patch->origInst[1]);
}

static TOOLSresult
dbgPrintPatch1(uint64_t addr, uint64_t size, void *entry, void *data)
{
    dbgPrintPatch((DebugPatch)entry);
    return TOOLS_SUCCESS;
}


static void
dbgPrintPatches(Context ctx)
{
    (void)toolsRangeMapApplyFunctor(ctx->gpuAddrToPatch, dbgPrintPatch1, NULL);
}

static CUDBGResult
readRawPC(CudbgDevice dev, uint32_t sm, uint32_t wp, uint32_t ln, uint64_t *pc)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CUDBG_VERIFY(pc, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in readRawPC.\n");

    if (dev->smState[sm].warp[wp].activeMask & (1U << ln))
        res = dev->halo.readPC(dev, sm, wp, pc);
    else
        res = dev->halo.findDivergedCRS_PC(dev, sm, wp, ln, pc);

    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read PC for sm %d wp %d ln %d\n", sm, wp, ln);

    return dev->halo.adjustCodeAddress(*pc, pc, CUDBG_ADJ_CURRENT_ADDRESS);
}

static CUDBGResult
threadInPatch(CudbgDevice dev, uint32_t sm, uint32_t wp, uint32_t ln, DebugPatch *patch, bool *inPatch)
{
    uint64_t pc;
    CUDBGResult res = CUDBG_SUCCESS;

    res = readRawPC(dev, sm, wp, ln, &pc);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to readRawPC failed in threadInPatch.\n");
        return res;
    }

    CUDBG_VERIFY(inPatch, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in threadInPatch.\n");

    res = haloInPatchRegion(pc, dev->activeContext, patch, CUDBG_PATCH_ALL,
                            inPatch, false);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to haloInPatchRegion failed in threadInPatch.\n");
        return res;
    }

    return CUDBG_SUCCESS;
}

/* If the thread is in a patch then some of the registers have been saved to local memory */
static CUDBGResult
readPatchReg(CudbgDevice dev, DebugPatch patch, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t regno, uint32_t *reg)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t lmemspill = 0, lmemreg = 0;

    switch (patch->kind) {
    case CUDBG_PATCH_MEMCHECK:
        res = dev->halo.mcinterop_getPatchReg(dev, sm, wp, ln, regno,
                                              &lmemspill, &lmemreg);
        break;
    case CUDBG_PATCH_MEMBAR_WAR:
        res = dev->halo.membarWAR_getPatchReg(dev, sm, wp, ln, regno,
                                              &lmemspill, &lmemreg);
        break;
    case CUDBG_PATCH_LDC_WAR:
        res = dev->halo.ldcWAR_getPatchReg(dev, sm, wp, ln, regno,
                                           &lmemspill, &lmemreg);
        break;
    default:
        CUDBG_ERROR("Invalid patch type in readPatchReg\n");
        res = CUDBG_ERROR_UNKNOWN;
        break;
    }

    if (res != CUDBG_SUCCESS) {
        API_TRACE(0, "Failed to check patch reg\n");
        return res;
    }

    if (lmemspill) {
        API_TRACE(10, "Reg %u was inside a patch. Returning value from spilled lmem\n", regno);
        *reg = lmemreg;
        return res;
    }

    return dev->halo.readRegisterRange(dev, sm, wp, ln, regno, reg, 1, false);
}

/* If the thread is in a patch then predicates may have been saved to local memory */
static CUDBGResult
readPatchPred(CudbgDevice dev, DebugPatch patch, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t numPredicates, uint32_t *predicates)
{
    CUDBGResult res = CUDBG_SUCCESS;

    switch (patch->kind) {
    case CUDBG_PATCH_MEMCHECK:
        res = dev->halo.mcinterop_getPatchPred(dev, sm, wp, ln, numPredicates, predicates);
        break;
    case CUDBG_PATCH_MEMBAR_WAR:
        res = dev->halo.membarWAR_getPatchPred(dev, sm, wp, ln, numPredicates, predicates);
        break;
    default:
        CUDBG_ERROR("Invalid patch type in readPatchPred\n");
        res = CUDBG_ERROR_UNKNOWN;
        break;
    }

    if (res != CUDBG_SUCCESS) {
        API_TRACE(0, "Failed to check patch predicate\n");
        return res;
    }

    API_TRACE(10, "Predicates were saved inside a patch. Returning value from spilled lmem\n");
    return res;
}

/* If the thread is in a patch then the CC reg may have been saved to local memory */
static CUDBGResult
readPatchCC(CudbgDevice dev, DebugPatch patch, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t *cc)
{
    CUDBGResult res = CUDBG_SUCCESS;

    switch (patch->kind) {
    case CUDBG_PATCH_MEMCHECK:
        res = dev->halo.mcinterop_getPatchCC(dev, sm, wp, ln, cc);
        break;
    case CUDBG_PATCH_MEMBAR_WAR:
        res = dev->halo.membarWAR_getPatchCC(dev, sm, wp, ln, cc);
        break;
    default:
        CUDBG_ERROR("Invalid patch type in readPatchCC\n");
        res = CUDBG_ERROR_UNKNOWN;
        break;
    }

    if (res != CUDBG_SUCCESS) {
        API_TRACE(0, "Failed to check patch CC\n");
        return res;
    }

    API_TRACE(10, "CC register was saved inside a patch. Returning value from spilled lmem\n");
    return res;
}

/* If the thread is in a patch then some of the registers have been saved to local memory */
static CUDBGResult
writePatchReg(CudbgDevice dev, DebugPatch patch, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t regno, const uint32_t *reg)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t lmemspill = 0;

    switch (patch->kind) {
    case CUDBG_PATCH_MEMCHECK:
        res = dev->halo.mcinterop_setPatchReg(dev, sm, wp, ln, regno,
                                              &lmemspill, reg);
        break;
    case CUDBG_PATCH_MEMBAR_WAR:
        res = dev->halo.membarWAR_setPatchReg(dev, sm, wp, ln, regno,
                                              &lmemspill, reg);
        break;
    case CUDBG_PATCH_LDC_WAR:
        res = dev->halo.ldcWAR_setPatchReg(dev, sm, wp, ln, regno,
                                           &lmemspill, reg);
        break;
    default:
        CUDBG_ERROR("Invalid patch type in readPatchReg\n");
        res = CUDBG_ERROR_UNKNOWN;
        break;
    }

    if (res != CUDBG_SUCCESS) {
        API_TRACE(0, "Failed to set patch reg\n");
        return res;
    }

    if (lmemspill) {
        API_TRACE(10, "Reg %u was inside a patch. Wrote value to spilled lmem\n", regno);
        return res;
    }

    return dev->halo.writeRegisterFile(dev, sm, wp, ln, regno * 4, reg, sizeof *reg);
}

/* If the thread is in a patch then predicates may have been saved to local memory */
static CUDBGResult
writePatchPred(CudbgDevice dev, DebugPatch patch, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t numPredicates, const uint32_t *predicates)
{
    CUDBGResult res = CUDBG_SUCCESS;

    switch (patch->kind) {
    case CUDBG_PATCH_MEMCHECK:
        res = dev->halo.mcinterop_setPatchPred(dev, sm, wp, ln, numPredicates, predicates);
        break;
    case CUDBG_PATCH_MEMBAR_WAR:
        res = dev->halo.membarWAR_setPatchPred(dev, sm, wp, ln, numPredicates, predicates);
        break;
    default:
        CUDBG_ERROR("Invalid patch type in readPatchPred\n");
        res = CUDBG_ERROR_UNKNOWN;
        break;
    }

    if (res != CUDBG_SUCCESS) {
        API_TRACE(0, "Failed to set patch predicate\n");
        return res;
    }

    API_TRACE(10, "Predicates were saved inside a patch. Wrote value to spilled lmem\n");
    return res;
}

/* If the thread is in a patch then the CC reg may have been saved to local memory */
static CUDBGResult
writePatchCC(CudbgDevice dev, DebugPatch patch, uint32_t sm, uint32_t wp, uint32_t ln, const uint32_t cc)
{
    CUDBGResult res = CUDBG_SUCCESS;

    switch (patch->kind) {
    case CUDBG_PATCH_MEMCHECK:
        res = dev->halo.mcinterop_setPatchCC(dev, sm, wp, ln, cc);
        break;
    case CUDBG_PATCH_MEMBAR_WAR:
        res = dev->halo.membarWAR_setPatchCC(dev, sm, wp, ln, cc);
        break;
    default:
        CUDBG_ERROR("Invalid patch type in readPatchCC\n");
        res = CUDBG_ERROR_UNKNOWN;
        break;
    }

    if (res != CUDBG_SUCCESS) {
        API_TRACE(0, "Failed to set patch CC\n");
        return res;
    }

    API_TRACE(10, "CC reg was saved inside a patch. Wrote value to spilled lmem\n");
    return res;
}

/*-------------------------------- Functions ---------------------------------*/

typedef struct  dbgBrokenAddrRange_st dbgBrokenAddrRange;

struct dbgBrokenAddrRange_st {
    uint64_t start;
    uint64_t size;
};

static CUDBGResult ctxReadCodeMemory(Context ctx, uint64_t addr, void *buf, uint32_t sz, bool skipPatch);

bool
deviceHasAnyContext(uint32_t devId)
{
    CudbgDevice dev;

    if (devId >= CUDBG_MAX_DEVICES)
        return false;

    dev = haloGlobals.device[devId];

    if (NULL == toolsHashMapGetAnyEntry(dev->contexts))
        return false;

    return true;
}

typedef struct BreakpointFunctorData_st BreakpointFunctorData;

struct BreakpointFunctorData_st {
    CUDBGResult res;
    bool skipExit;
};

static TOOLSresult
insertBreakpoint(tHashMapKey_t key, void *entry, void *data)
{
    Context context;
    Breakpoint bp;
    BreakpointFunctorData *bdata;
    bool isExiting = false;

    bp = (Breakpoint)entry;
    bdata = (BreakpointFunctorData*)data;

    bdata->res = CUDBG_SUCCESS;

    if (!bp) {
        CUDBG_ERROR("Invalid breakpoint in insertBreakpoint.\n");
        bdata->res = CUDBG_ERROR_INVALID_ARGS;
        return TOOLS_ERROR_UNKNOWN;
    }

    if (bp->isSet) {
        API_TRACE_FUNCTION(1, "Breakpoint already inserted at 0x%" PRIx64 ".\n", bp->devVAddr);
        return TOOLS_SUCCESS;
    }

    context = bp->context;

    if (bdata->skipExit) {
        /* Check if the target instruction is an exiting instruction.
           See singleStepSM for details */
        bdata->res = context->dev->halo.isTerminalInstructionAtPC(context, bp->gpuAddr, &isExiting);

        if (bdata->res != CUDBG_SUCCESS) {
            API_TRACE_FUNCTION(1, "Error determining instruction at addr %#" PRIx64
                               " GPUPC:%#" PRIx64 " instruction: %#" PRIx64 "\n",
                               bp->devVAddr, bp->gpuAddr, bp->savedContents);
            return TOOLS_ERROR_UNKNOWN;
        }

        if (isExiting) {
            API_TRACE_FUNCTION(1, "Skip inserting breakpoint at addr %#" PRIx64
                               " GPUPC:%#" PRIx64 " due to exit instruction: %#" PRIx64 "\n",
                               bp->devVAddr, bp->gpuAddr, bp->savedContents);
            return TOOLS_SUCCESS;
        }

    }


    /* This is terrible, but keep this behavior for backward compatibility
       Breakpoint insertion can fail for contexts whose memMaps have not already
       been initialized. In this case, the call will return an error. So, claim
       that there has been success and keep marching on.
     */
    bdata->res = context->dev->halo.insertBreakpoint(context, bp->devVAddr, &bp->savedContents);
    if (bdata->res != CUDBG_SUCCESS) {
        API_TRACE_FUNCTION(1, "Error inserting breakpoint at addr 0x%" PRIx64
                           " GPUPC:0x%" PRIx64 "(res = %d)\n", bp->devVAddr,
                           bp->gpuAddr, bdata->res);
        return TOOLS_SUCCESS;
    }

    bp->isSet = true;

    API_TRACE_FUNCTION(50, "Breakpoint inserted at 0x%" PRIx64 ".\n", bp->devVAddr);

    return TOOLS_SUCCESS;
}

static TOOLSresult
removeBreakpoint(tHashMapKey_t key, void *entry, void *data)
{
    Context context;
    Breakpoint bp;
    CUDBGResult *res;

    bp = (Breakpoint)entry;
    res = (CUDBGResult*)data;

    *res = CUDBG_SUCCESS;

    if (!bp) {
        CUDBG_ERROR("Invalid breakpoint in removeBreakpoint.\n");
        *res = CUDBG_ERROR_INVALID_ARGS;
        return TOOLS_ERROR_UNKNOWN;
    }

    if (!bp->isSet) {
        API_TRACE_FUNCTION(1, "No breakpoint inserted at 0x%" PRIx64 " (PC:0x%" PRIx64 ").\n", bp->devVAddr, bp->gpuAddr);
        return TOOLS_SUCCESS;
    }

    context = bp->context;

    /* This is terrible, but keep this behavior for backward compatibility
       Breakpoint removal can fail for contexts whose memMaps have not already
       been initialized. In this case, the call will return an error. So, claim
       that there has been success and keep marching on.
     */
    *res = context->dev->halo.removeBreakpoint(context, bp->devVAddr, &bp->savedContents);
    if (*res != CUDBG_SUCCESS) {
        API_TRACE_FUNCTION(1, "Error removing breakpoint at addr 0x%" PRIx64 " (res = %d)\n", bp->devVAddr, *res);
        return TOOLS_SUCCESS;
    }

    bp->isSet = false;

    API_TRACE_FUNCTION(50, "Breakpoint removed at 0x%" PRIx64 ".\n", bp->devVAddr);

    return TOOLS_SUCCESS;
}

static TOOLSresult
resetBreakpoint(tHashMapKey_t key, void *entry, void *data)
{
    Breakpoint bp;

    bp = (Breakpoint)entry;

    if (!bp) {
        CUDBG_ERROR("Invalid breakpoint in resetBreakpoint.\n");
        return TOOLS_ERROR_UNKNOWN;
    }

    if (!bp->isSet) {
        API_TRACE_FUNCTION(1, "Not resetting breakpoint at 0x%" PRIx64 " (PC:0x%" PRIx64 ") as it was not inserted\n", bp->devVAddr, bp->gpuAddr);
        return TOOLS_SUCCESS;
    }

    bp->isSet = false;
    return TOOLS_SUCCESS;
}

static CUDBGResult
resetFunctionBreakpoints(DeviceFunction function)
{
    TOOLSresult tres = TOOLS_SUCCESS;

    if (!function) {
        CUDBG_ERROR("Invalid function in resetFunctionBreakpoints.\n");
        return CUDBG_ERROR_UNKNOWN_FUNCTION;
    }

    tres = toolsHashMapApplyFunctor(function->breakPoints, resetBreakpoint, NULL);

    CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_INTERNAL, "Failed in resetBreakpoint functor\n");
    return CUDBG_SUCCESS;
}

static TOOLSresult
insertFunctionBreakpoints(tHashMapKey_t key, void *entry, void *data)
{
    DeviceFunction function;
    BreakpointFunctorData *bdata;

    function = (DeviceFunction)entry;
    bdata = (BreakpointFunctorData*)data;

    if (!function) {
        CUDBG_ERROR("Invalid function in insertFunctionBreakpoints.\n");
        bdata->res = CUDBG_ERROR_UNKNOWN_FUNCTION;
        return TOOLS_ERROR_UNKNOWN;
    }

    return toolsHashMapApplyFunctor(function->breakPoints, insertBreakpoint, data);
}

static TOOLSresult
insertPatchBreakpoints(tHashMapKey_t key, void *entry, void *data)
{
    DebugPatch patch;
    BreakpointFunctorData *bdata;

    patch = (DebugPatch)entry;
    bdata = (BreakpointFunctorData*)data;

    if (!patch) {
        CUDBG_ERROR("Invalid patch in insertPatchBreakpoints.\n");
        bdata->res = CUDBG_ERROR_INTERNAL;
        return TOOLS_ERROR_UNKNOWN;
    }

    return toolsHashMapApplyFunctor(patch->breakPoints, insertBreakpoint, data);
}

static TOOLSresult
insertModuleBreakpoints(tHashMapKey_t key, void *entry, void *data)
{
    DeviceModule module;
    BreakpointFunctorData *bdata;

    module = (DeviceModule)entry;
    bdata = (BreakpointFunctorData*)data;

    if (!module) {
        CUDBG_ERROR("Invalid module in insertModuleBreakpoints.\n");
        bdata->res = CUDBG_ERROR_INVALID_MODULE;
        return TOOLS_ERROR_UNKNOWN;
    }

    return toolsHashMapApplyFunctor(module->functions, insertFunctionBreakpoints, data);
}

static TOOLSresult
insertContextBreakpoints(tHashMapKey_t key, void *entry, void *data)
{
    TOOLSresult tres;
    Context context;
    BreakpointFunctorData *bdata;

    context = (Context)entry;
    bdata = (BreakpointFunctorData*)data;

    if (!context) {
        CUDBG_ERROR("Invalid context in insertContextBreakpoints.\n");
        bdata->res = CUDBG_ERROR_INVALID_CONTEXT;
        return TOOLS_ERROR_UNKNOWN;
    }

    tres = toolsHashMapApplyFunctor(context->modules, insertModuleBreakpoints, data);
    if (tres != TOOLS_SUCCESS) {
        CUDBG_ERROR("Error inserting module breakpoints.\n");
        return tres;
    }

    tres = toolsHashMapApplyFunctor(context->patchEntry, insertPatchBreakpoints, data);
    if (tres != TOOLS_SUCCESS) {
        CUDBG_ERROR("Error inserting patch breakpoints.\n");
        return tres;
    }

    return TOOLS_SUCCESS;
}

static TOOLSresult
removeFunctionBreakpoints(tHashMapKey_t key, void *entry, void *data)
{
    DeviceFunction function;
    CUDBGResult *res;

    function = (DeviceFunction) entry;
    res = (CUDBGResult*)data;

    if (!function) {
        CUDBG_ERROR("Invalid function in removeFunctionBreakpoints.\n");
        *res = CUDBG_ERROR_UNKNOWN_FUNCTION;
        return TOOLS_ERROR_UNKNOWN;
    }

    return toolsHashMapApplyFunctor(function->breakPoints, removeBreakpoint, res);
}

static TOOLSresult
removePatchBreakpoints(tHashMapKey_t key, void *entry, void *data)
{
    DebugPatch patch;
    CUDBGResult *res;

    patch = (DebugPatch) entry;
    res = (CUDBGResult*)data;

    if (!patch) {
        CUDBG_ERROR("Invalid function in removePatchBreakpoints.\n");
        *res = CUDBG_ERROR_UNKNOWN_FUNCTION;
        return TOOLS_ERROR_UNKNOWN;
    }

    return toolsHashMapApplyFunctor(patch->breakPoints, removeBreakpoint, res);
}

static TOOLSresult
removeModuleBreakpoints(tHashMapKey_t key, void *entry, void *data)
{
    DeviceModule module;
    CUDBGResult *res;

    module = (DeviceModule)entry;
    res = (CUDBGResult*)data;

    if (!module) {
        CUDBG_ERROR("Invalid module in removeModuleBreakpoints.\n");
        *res = CUDBG_ERROR_INVALID_MODULE;
        return TOOLS_ERROR_UNKNOWN;
    }
    return toolsHashMapApplyFunctor(module->functions, removeFunctionBreakpoints, res);
}

static TOOLSresult
removeContextBreakpoints(tHashMapKey_t key, void *entry, void *data)
{
    TOOLSresult tres;
    Context context;
    CUDBGResult *res;

    context = (Context)entry;
    res = (CUDBGResult*)data;

    if (!context) {
        CUDBG_ERROR("Invalid context in removeContextBreakpoints.\n");
        *res = CUDBG_ERROR_INVALID_CONTEXT;
        return TOOLS_ERROR_UNKNOWN;
    }

    tres = toolsHashMapApplyFunctor(context->modules, removeModuleBreakpoints, res);
    if (tres != TOOLS_SUCCESS) {
        CUDBG_ERROR("Error removing module breakpoints.\n");
        return tres;
    }

    tres = toolsHashMapApplyFunctor(context->patchEntry, removePatchBreakpoints, res);
    if (tres != TOOLS_SUCCESS) {
        CUDBG_ERROR("Error removing patch breakpoints.\n");
        return tres;
    }

    return TOOLS_SUCCESS;
}

/* Insert or remove all breakpoint instructions on the device. */
CUDBGResult
insertBreakpoints(CudbgDevice dev, bool skipExit)
{
    BreakpointFunctorData data;

    data.res = CUDBG_SUCCESS;
    data.skipExit = skipExit;

    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_DEVICE, "Invalid device in insertBreakpoints.\n");

    (void)toolsHashMapApplyFunctor(dev->contexts, insertContextBreakpoints, (void*)&data);
    return data.res;
}

CUDBGResult
removeBreakpoints(CudbgDevice dev)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_DEVICE, "Invalid device in removeBreakpoints.\n");

    (void)toolsHashMapApplyFunctor(dev->contexts,  removeContextBreakpoints, (void*)&res);
    return res;
}

static TOOLSresult
unsetFunctionTemporaryBreakpoints(tHashMapKey_t key, void *entry, void *data)
{
    DeviceFunction function;
    BreakpointFunctorData *bdata;

    function = (DeviceFunction)entry;
    bdata = (BreakpointFunctorData*)data;

    if (!function) {
        CUDBG_ERROR("Invalid function in unsetFunctionTemporaryBreakpoints.\n");
        bdata->res = CUDBG_ERROR_UNKNOWN_FUNCTION;
        return TOOLS_ERROR_UNKNOWN;
    }

    if (function->temporaryBreakPoints)
        return toolsHashMapApplyFunctor(function->temporaryBreakPoints, removeBreakpoint, &bdata->res);

    return TOOLS_SUCCESS;
}

static TOOLSresult
unsetModuleTemporaryBreakpoints(tHashMapKey_t key, void *entry, void *data)
{
    DeviceModule module;
    BreakpointFunctorData *bdata;

    module = (DeviceModule)entry;
    bdata = (BreakpointFunctorData*)data;

    if (!module) {
        CUDBG_ERROR("Invalid module in unsetModuleTemporaryBreakpoints.\n");
        bdata->res = CUDBG_ERROR_INVALID_MODULE;
        return TOOLS_ERROR_UNKNOWN;
    }

    return toolsHashMapApplyFunctor(module->functions, unsetFunctionTemporaryBreakpoints, data);
}

static TOOLSresult
unsetContextTemporaryBreakpoints(tHashMapKey_t key, void *entry, void *data)
{
    Context context;
    BreakpointFunctorData *bdata;

    context = (Context)entry;
    bdata = (BreakpointFunctorData*)data;

    if (!context) {
        CUDBG_ERROR("Invalid context in unsetContextTemporaryBreakpoints.\n");
        bdata->res = CUDBG_ERROR_INVALID_CONTEXT;
        return TOOLS_ERROR_UNKNOWN;
    }
    return toolsHashMapApplyFunctor(context->modules, unsetModuleTemporaryBreakpoints, data);
}

CUDBGResult
unsetTemporaryBreakpoints(CudbgDevice dev)
{
    BreakpointFunctorData data;

    data.res = CUDBG_SUCCESS;
    data.skipExit = false;

    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_DEVICE, "Invalid device in unsetTemporaryBreakpoints.\n");

    (void)toolsHashMapApplyFunctor(dev->contexts, unsetContextTemporaryBreakpoints, (void*)&data);
    return data.res;
}

static TOOLSresult
clearFunctionTemporaryBreakpoints(tHashMapKey_t key, void *entry, void *data)
{
    TOOLSresult res;
    DeviceFunction function;
    BreakpointFunctorData *bdata;

    function = (DeviceFunction)entry;
    bdata = (BreakpointFunctorData*)data;

    if (!function) {
        CUDBG_ERROR("Invalid function in clearFunctionTemporaryBreakpoints.\n");
        bdata->res = CUDBG_ERROR_UNKNOWN_FUNCTION;
        return TOOLS_ERROR_UNKNOWN;
    }

    if (function->temporaryBreakPoints) {
        res = toolsHashMapApplyFunctor(function->temporaryBreakPoints, removeBreakpoint, &bdata->res);
        if (res != TOOLS_SUCCESS) {
            CUDBG_ERROR("Error removing bp in clearFunctionTemporaryBreakpoints.\n");
            return res;
        }

        res = toolsHashMapDelete(function->temporaryBreakPoints, deleteBreakpoint, bdata);
        function->temporaryBreakPoints = NULL;
        return res;
    }

    return TOOLS_SUCCESS;
}

static TOOLSresult
clearPatchTemporaryBreakpoints(tHashMapKey_t key, void *entry, void *data)
{
    TOOLSresult res;
    DebugPatch patch;
    BreakpointFunctorData *bdata;

    patch = (DebugPatch)entry;
    bdata = (BreakpointFunctorData*)data;

    if (!patch) {
        CUDBG_ERROR("Invalid function in clearPatchTemporaryBreakpoints.\n");
        bdata->res = CUDBG_ERROR_UNKNOWN;
        return TOOLS_ERROR_UNKNOWN;
    }

    if (patch->temporaryBreakPoints) {
        res = toolsHashMapApplyFunctor(patch->temporaryBreakPoints, removeBreakpoint, &bdata->res);
        if (res != TOOLS_SUCCESS) {
            CUDBG_ERROR("Error removing bp in clearPatchTemporaryBreakpoints.\n");
            return res;
        }

        return res;
    }

    return TOOLS_SUCCESS;
}

static TOOLSresult
clearModuleTemporaryBreakpoints(tHashMapKey_t key, void *entry, void *data)
{
    DeviceModule module;
    BreakpointFunctorData *bdata;

    module = (DeviceModule)entry;
    bdata = (BreakpointFunctorData*)data;

    if (!module) {
        CUDBG_ERROR("Invalid module in clearModuleTemporaryBreakpoints.\n");
        bdata->res = CUDBG_ERROR_INVALID_MODULE;
        return TOOLS_ERROR_UNKNOWN;
    }

    return toolsHashMapApplyFunctor(module->functions, clearFunctionTemporaryBreakpoints, data);
}

static TOOLSresult
clearContextTemporaryBreakpoints(tHashMapKey_t key, void *entry, void *data)
{
    TOOLSresult tres;
    Context context;
    BreakpointFunctorData *bdata;

    context = (Context)entry;
    bdata = (BreakpointFunctorData*)data;

    if (!context) {
        CUDBG_ERROR("Invalid context in clearContextTemporaryBreakpoints.\n");
        bdata->res = CUDBG_ERROR_INVALID_CONTEXT;
        return TOOLS_ERROR_UNKNOWN;
    }

    tres = toolsHashMapApplyFunctor(context->modules, clearModuleTemporaryBreakpoints, data);
    if (tres != TOOLS_SUCCESS)
        return tres;

    return toolsHashMapApplyFunctor(context->patchEntry, clearPatchTemporaryBreakpoints, data);
}

CUDBGResult
clearTemporaryBreakpoints(CudbgDevice dev)
{
    BreakpointFunctorData data;

    data.res = CUDBG_SUCCESS;
    data.skipExit = false;

    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_DEVICE, "Invalid device in clearTemporaryBreakpoints.\n");

    (void)toolsHashMapApplyFunctor(dev->contexts, clearContextTemporaryBreakpoints, (void*)&data);
    return data.res;
}

/*
  Allocate a breakpoint in the function->temporaryBreakPoints map.
  Must be cleared by a call to clearTemporaryBreakpoints() [above]
  before return to cudbgdispatcher.c
*/
CUDBGResult
insertTemporaryBreakpoint(Context ctx, uint64_t vaddr, uint64_t pc, Breakpoint *ret)
{
    CudbgDevice dev;
    Breakpoint bp;
    CUDBGResult res;
    TOOLSresult tres;
    DebugPatch patch;
    DeviceFunction function;
    uint64_t offset;

    CUDBG_TRACE("insertTemporaryBreakpoint at vaddr=0x%" PRIx64 " pc=0x%" PRIx64"\n", 
                vaddr, pc);

    CUDBG_VERIFY(ctx, CUDBG_ERROR_INTERNAL, "NULL context passed to insertTemporaryBreakpoint\n");
    dev = ctx->dev;

    function = (DeviceFunction)toolsRangeMapLookupByAddr(ctx->gpuAddrToFunction, pc);
    if (function) {
        if (!function->temporaryBreakPoints)
            function->temporaryBreakPoints = toolsHashMapNew(toolsUint32HashFun, toolsUint64EqualFun, 16);
        CUDBG_VERIFY(function->temporaryBreakPoints, CUDBG_ERROR_UNKNOWN, "Failed to create temporary breakpoint map\n");

        bp = (Breakpoint)calloc(1, sizeof(*bp));
        CUDBG_VERIFY(bp != NULL, CUDBG_ERROR_OS_RESOURCES, "Failed to allocate breakpoint\n");

        bp->isSet = false;
        bp->devVAddr = vaddr;
        bp->gpuAddr = bp->devVAddr - function->devVAddr + function->gpuAddrBase;
        bp->context = function->module->context;

        offset = pc - function->gpuAddrBase;
        tres = toolsHashMapInsert(function->temporaryBreakPoints,
                                  tHashMapNumToKey(offset), bp);
        if (tres != TOOLS_SUCCESS) {
            CUDBG_ERROR("Failed to insert into function->temporaryBreakPoints map (tres=%u)\n", tres);
            free(bp);
            return CUDBG_ERROR_UNKNOWN;
        }

        res = dev->halo.insertBreakpoint(ctx, bp->devVAddr, &bp->savedContents);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to insertBreakpoint failed in insertTemporaryBreakpoint\n");
            toolsHashMapRemove(function->temporaryBreakPoints, tHashMapNumToKey(offset), NULL);
            free(bp);
            return res;
        }

        /* Mark the breakpoint as inserted */
        bp->isSet = true;

        /* Return the breakpoint (if space provided) */
        if (ret)
            *ret = bp;

        return CUDBG_SUCCESS;
    }

    patch = (DebugPatch)toolsRangeMapLookupByAddr(ctx->gpuAddrToPatch, pc);
    if (patch) {
        bp = (Breakpoint)calloc(1, sizeof(*bp));
        CUDBG_VERIFY(bp != NULL, CUDBG_ERROR_OS_RESOURCES, "Failed to allocate breakpoint\n");

        bp->isSet = false;
        bp->devVAddr = vaddr;
        bp->gpuAddr = bp->devVAddr - patch->devVAddr + patch->gpuAddr;
        bp->context = patch->context;

        offset = pc - patch->gpuAddr;
        tres = toolsHashMapInsert(patch->temporaryBreakPoints,
                                  tHashMapNumToKey(offset), bp);
        if (tres != TOOLS_SUCCESS) {
            CUDBG_ERROR("Failed to insert into function->temporaryBreakPoints map (tres=%u)\n", tres);
            free(bp);
            return CUDBG_ERROR_UNKNOWN;
        }

        res = dev->halo.insertBreakpoint(ctx, bp->devVAddr, &bp->savedContents);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to insertBreakpoint failed in insertTemporaryBreakpoint\n");
            toolsHashMapRemove(patch->temporaryBreakPoints, tHashMapNumToKey(offset), NULL);
            free(bp);
            return res;
        }

        /* Mark the breakpoint as inserted */
        bp->isSet = true;

        /* Return the breakpoint (if space provided) */
        if (ret)
            *ret = bp;

        return CUDBG_SUCCESS;
    }

    CUDBG_ERROR("Could not locate patch or function for temporary breakpoint 0x%016" PRIx64 "\n", pc);

    return CUDBG_ERROR_UNKNOWN;
}

static CUDBGResult
gpudbgSendMessageToAttachStub(CUDBGAPIMSG_t *message, uint32_t *result)
{
    CUDBGResult res = CUDBG_SUCCESS;
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()
    bool retry = false;
    uint32_t retryCount = 5;

    if ((res = cudbgPipeMessageAppend(&debugClientToAttachStub, message, sizeof *message)))
        return res;

    if ((res = cudbgPipeMessageSend(&debugClientToAttachStub)))
        return res;

    if ((res = cudbgPipeWaitForData(&attachStubToDebugClient, NULL)))
        return res;

    do {
        if ((res = cudbgPipeMessageRead(&attachStubToDebugClient, &retry)))
            return res;

        if (retry)
            API_TRACE_FUNCTION(10, "Didn't receive message, retrying!\n", retry);
    }
    while (retry && retryCount-- > 0);

    *result = ((CUDBGAPIMSG_t *)attachStubToDebugClient.message[0])->result;
#endif

    return res;
}

/**
 * \fn CUDBGAPI_st::initializeAttachStub
 * \brief Initialize the attach stub.
 *
 * Since CUDA 5.0.
 *
 * \return CUDBG_SUCCESS
 */
CUDBGResult
gpudbgInitializeAttachStub(void)
{
    CUDBGResult res = CUDBG_SUCCESS;
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()
    CUDBGAPIMSG_t message;
    uint32_t result;

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    /* Outgoing pipe */
    if ((res = cudbgPipeInitialize(&debugClientToAttachStub,
                                   CUDBG_PIPE_TYPE_NAMED_WRITE,
                                   CUDBG_PIPE_ENDPOINT_DEBUG_CLIENT,
                                   CUDBG_PIPE_ENDPOINT_ATTACH_STUB)))
        return res;

    /* Incoming pipe */
    if ((res = cudbgPipeInitialize(&attachStubToDebugClient,
                                   CUDBG_PIPE_TYPE_NAMED_READ,
                                   CUDBG_PIPE_ENDPOINT_ATTACH_STUB,
                                   CUDBG_PIPE_ENDPOINT_DEBUG_CLIENT)))
        return res;

    /* Send an initialization message to the attach stub. The blocking read ensures
       that the stub is initialized. */
    message.kind = CUDBGAPIREQ5x_initialize;

    if ((res = gpudbgSendMessageToAttachStub(&message, &result))) {
        API_TRACE_FUNCTION(0, "Failed to send a message to the attach stub!\n");
        return res;
    }

    if (result != CUDBG_SUCCESS) {
        API_TRACE_FUNCTION(0, "Failed to initialize the attach stub (result=%u)\n",
                           message.result);
        res = CUDBG_ERROR_INTERNAL;
    }

    cudbgAttachStubAvailable = true;
#endif

    return res;
}

/*-------------------------------- Functions ---------------------------------*/

CUDBGResult
gpudbgSetupHaloInitDataFlags(HaloInitData haloInitData)
{
    char regopsVal[CUOS_ENV_VAR_LENGTH] = {0};
    char envVar[CUOS_ENV_VAR_LENGTH] = {0};

    CUDBG_VERIFY(haloInitData, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    memset(haloInitData, 0, sizeof *haloInitData);
    haloInitData->haloType = HALO_TYPE_DEBUGGER;

#if !cuosOsIsMods()
    if (g_enableUnifiedDebuggerClient) {
        haloInitData->haloType = HALO_TYPE_UNIFIED_DEBUGGER;
    }
#endif

    /* Enabled by default */
    haloInitData->flags |= HALO_INIT_FLAGS_ENABLE_DEBUG_OBJECT_DEFAULT;
    haloInitData->flags |= HALO_INIT_FLAGS_COLLECT_ACTIVE_CONTEXT;
    haloInitData->flags |= HALO_INIT_FLAGS_ENABLE_SCRATCHPAD_CACHE;
    /* We should always be using regops now */
    haloInitData->flags |= HALO_INIT_FLAGS_FORCE_REGOPS;

    if (haloInitData->haloType != HALO_TYPE_UNIFIED_DEBUGGER)
        haloInitData->flags |= HALO_INIT_FLAGS_ENABLE_INSN_CACHE;

    haloInitData->haloDmalType = HALO_DMAL_TYPE_RM;

    if (!cuosGetEnv("CUDBG_ENABLE_DEBUG_OBJECT", envVar, sizeof(envVar))) {
        if (strlen(envVar) != 1) {
            API_TRACE(0, "Error: Unrecognized value of environment variable\n");
            return CUDBG_ERROR_INVALID_ENVVAR_ARGS;
        }

        if (envVar[0] == '0') {
            /* Not using the debug object may cause intermittent failures. */
            haloInitData->flags &= ~HALO_INIT_FLAGS_ENABLE_DEBUG_OBJECT_DEFAULT;
            API_TRACE(0, "Debug object usage disabled by environment variable\n");
        }
        else if (envVar[0] == '1') {
            haloInitData->flags &= ~HALO_INIT_FLAGS_ENABLE_DEBUG_OBJECT_MEMORY_ACCESS;
            API_TRACE(0, "Debug object interface for memory access disabled by environment variable\n");
        }
        else if (envVar[0] == '2') {
            haloInitData->flags |= HALO_INIT_FLAGS_ENABLE_PER_CONTEXT_DEBUG_OBJECT;
            API_TRACE(0, "Debug object usage restricted to per context by environment variable\n");
        }
        else if (envVar[0] != '3') {
            API_TRACE(0,"Error: Invalid value for environment variable\n");
            return CUDBG_ERROR_INVALID_ENVVAR_ARGS;
        }
    }

    if (!cuosGetEnv("CUDBG_ENABLE_SW_CACHE", envVar, sizeof(envVar))) {
        if (strlen(envVar) != 1) {
            API_TRACE(0, "Error: Unrecognized value of environment variable\n");
            return CUDBG_ERROR_INVALID_ENVVAR_ARGS;
        }

        if (envVar[0] == '0') {
            haloInitData->flags &= ~HALO_INIT_FLAGS_ENABLE_SCRATCHPAD_CACHE;
            API_TRACE(0, "Scratchpad and CRS cache disabled by environment variable\n");
        }
        else if (envVar[0] != '1') {
            API_TRACE(0,"Error: Invalid value for environment variable\n");
            return CUDBG_ERROR_INVALID_ENVVAR_ARGS;
        }
    }

    if (!cuosGetEnv("CUDBG_ENABLE_INSN_CACHE", envVar, sizeof(envVar))) {
        if (strlen(envVar) != 1) {
            API_TRACE(0, "Error: Unrecognized value of environment variable\n");
            return CUDBG_ERROR_INVALID_ENVVAR_ARGS;
        }

        if (envVar[0] == '0') {
            API_TRACE(0, "Insn cache disabled by environment variable\n");
            haloInitData->flags &= ~HALO_INIT_FLAGS_ENABLE_INSN_CACHE;
        }
        else if (envVar[0] == '1') {
            API_TRACE(0, "Insn cache enabled by environment variable\n");
            haloInitData->flags |= HALO_INIT_FLAGS_ENABLE_INSN_CACHE;
        }
        else {
            API_TRACE(0,"Error: Invalid value for environment variable\n");
            return CUDBG_ERROR_INVALID_ENVVAR_ARGS;
        }
    }

    if (!cuosGetEnv("CUDBG_ENABLE_REGOPS", regopsVal, sizeof(regopsVal))) {
        if (strlen(regopsVal) != 1) {
            API_TRACE(0, "Error: Unrecognized value of environment variable\n");
            return CUDBG_ERROR_INVALID_ENVVAR_ARGS;
        }
        if (atoi(regopsVal) != 0) {
            haloInitData->flags |= HALO_INIT_FLAGS_FORCE_REGOPS;
            API_TRACE(0, "Regops forced by environment variable\n");
        }
        else {
            haloInitData->flags &= ~HALO_INIT_FLAGS_FORCE_REGOPS;
            API_TRACE(0, "Regops forcibly disabled by environment variable\n");
        }
    }

    if (!cuosGetEnv("CUDBG_ENABLE_CTX_EVENTS", envVar, sizeof(envVar))) {
        if (strlen(envVar) != 1) {
            API_TRACE(0, "Error: Unrecognized value of environment variable\n");
            return CUDBG_ERROR_INVALID_ENVVAR_ARGS;
        }

        if (atoi(envVar) != 0) {
            haloInitData->flags |= HALO_INIT_FLAGS_ENABLE_CONTEXT_EVENTS;
            API_TRACE(0, "Per-context events enabled by environment variable\n");
        }
        else {
            haloInitData->flags &= ~HALO_INIT_FLAGS_ENABLE_CONTEXT_EVENTS;
            API_TRACE(0, "Per-context events disabled by environment variable\n");
        }
    }

    if (!cuosGetEnv("CUDBG_ERROR_ON_MISSING_DEBUG_FRAME", envVar, sizeof(envVar))) {
        if (strlen(envVar) != 1) {
            API_TRACE(0, "Error: Unrecognized value of environment variable\n");
            return CUDBG_ERROR_INVALID_ENVVAR_ARGS;
        }

        if (atoi(envVar) != 0) {
            haloInitData->flags |= HALO_INIT_FLAGS_ERROR_ON_MISSING_DEBUG_FRAME;
            API_TRACE(0, "Per-context events enabled by environment variable\n");
        }
        else {
            haloInitData->flags &= ~HALO_INIT_FLAGS_ERROR_ON_MISSING_DEBUG_FRAME;
            API_TRACE(0, "Per-context events disabled by environment variable\n");
        }
    }

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::initialize
 * \brief Initialize the API.
 *
 * Since CUDA 3.0.
 *
 * \ingroup INIT
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_UNKNOWN
 *
 * \sa finalize
 */
CUDBGResult
gpudbgInitialize(void)
{
    CUDBGResult res = CUDBG_SUCCESS;
    struct HaloInitData_st haloInitData;
    cudbg_pipe_type_t applicationToDispatcherPipeType;

    API_TRACE_FUNCTION(1, "\n");

    if (moduleInitialized)
        goto success;

    cudbgUtilsInit();

    res = gpudbgSetupHaloInitDataFlags(&haloInitData);
    if (res != CUDBG_SUCCESS)
        goto failure;

    res = haloInit(&haloInitData);
    if (res != CUDBG_SUCCESS && res != CUDBG_ERROR_SOME_DEVICES_WATCHDOGGED)
        goto failure;

    res = gpudbgInitializeStaticState();
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to initialize static state\n");

    /* On ARM, fd's for nvhost, nvmap etc. need to be transferred
       from the application to the debugger process. This requires the
       use of Unix domain sockets. */
    if (cuosOsIsLinux() || cuosOsIsQnx())
        applicationToDispatcherPipeType = CUDBG_PIPE_TYPE_UDS_READ;
    else
        applicationToDispatcherPipeType = CUDBG_PIPE_TYPE_NAMED_READ;

    if ((res = cudbgPipeInitialize(&applicationToDispatcher,
                                   applicationToDispatcherPipeType,
                                   CUDBG_PIPE_ENDPOINT_APPLICATION,
                                   CUDBG_PIPE_ENDPOINT_DISPATCHER)))
        goto failure;
    if ((res = cudbgPipeInitialize(&dispatcherToApplication,
                                   CUDBG_PIPE_TYPE_NAMED_WRITE,
                                   CUDBG_PIPE_ENDPOINT_DISPATCHER,
                                   CUDBG_PIPE_ENDPOINT_APPLICATION)))
        goto failure;

    if ((res = cudbgPipeInitialize(&debuggerToDispatcher,
        CUDBG_PIPE_TYPE_ANONYMOUS,
        CUDBG_PIPE_ENDPOINT_DEBUGGER,
        CUDBG_PIPE_ENDPOINT_DISPATCHER)))
        goto failure;

    if ((res = cudbgPipeInitialize(&dispatcherToDebugger,
        CUDBG_PIPE_TYPE_ANONYMOUS,
        CUDBG_PIPE_ENDPOINT_DISPATCHER,
        CUDBG_PIPE_ENDPOINT_DEBUGGER)))
        goto failure;

    if (cuosThreadCreate(&cudbgDispatcherThreadHandle, cudbgDispatcher, NULL) == -1) {
        res = CUDBG_ERROR_UNKNOWN;
        goto failure;
    }

#if cuosOsIsApple()
    res = cudbgMacCreateEventThread();
    if (res != CUDBG_SUCCESS)
        goto failure;
#endif

    cudbgDriverOptionsInitialize(clientRevision, cudbgLaunchNotificationPolicy != CUDBG_NOTIFY_NONE);

    /* Allocate some space on TLS */
    cudbgTlsInitialize();

    moduleInitialized = true;

success:
    return res;

failure:
    API_TRACE_FUNCTION(0, "failed (result=%u)\n", res);
    return res;
}

/* Initialize file-static state in cudbgapi.c */
CUDBGResult
gpudbgInitializeStaticState(void)
{
    CUDBGResult res = CUDBG_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;

    API_TRACE_FUNCTION(1, "\n");

    if (moduleInitialized)
        goto success;

    pendingPatches = toolsHashMapNew(toolsUint32HashFun, toolsUint64EqualFun, 8);
    if (!pendingPatches) {
        API_TRACE(0, "Error : Failed to allocate pending patches map\n");
        res = CUDBG_ERROR_UNKNOWN;
        goto failure;
    }

    tres = toolsRangeMapCreate(&virtAddrToFunction);
    if (tres != TOOLS_SUCCESS) {
        API_TRACE(0, "Error : Failed to create virtAddrToFunction map\n");
        res = CUDBG_ERROR_UNKNOWN;
        goto failure;
    }

    tres = toolsRangeMapCreate(&brokenVirtAddrToFunction);
    if (tres != TOOLS_SUCCESS) {
        API_TRACE(0, "Error : Failed to create brokenVirtAddrToFunction map\n");
        res = CUDBG_ERROR_UNKNOWN;
        goto failure;
    }

    gpudbgEventsInitialize(GPUDBG_EVENT_SYNC);
    gpudbgEventsInitialize(GPUDBG_EVENT_ASYNC);

    moduleInitialized = true;

    dbgPatchId = 0;
success:
    return res;

failure:
    API_TRACE_FUNCTION(0, "failed (result=%u)\n", res);
    return res;
}

static void
deleteBreakpoint(void *entry, void *data)
{
    Breakpoint bp;

    bp = (Breakpoint)entry;
    free(bp);
}

static CUDBGResult
deleteContext(Context context, bool removeFromMap)
{
    CudbgDevice dev;
    CUDBGResult res = CUDBG_SUCCESS;

    if (!context) {
        CUDBG_ERROR("Invalid context in deleteContext.\n");
        res = CUDBG_ERROR_INVALID_CONTEXT;
        return res;
    }

    if (CUDBG_DEBUG_OBJECT_IS_VALID(context->debugObj)) {
        res = context->dev->dmal->debugObjectFreeEvent(context->dev, context->debugObj,
                                                       &context->event,
                                                       context->hDebugEvent);
        if (res != CUDBG_SUCCESS)
            CUDBG_TRACE("Failed to free debug object for context 0x%" PRIx64 "\n", context->cuCtx);

        if (context->dev->dmal->type == HALO_DMAL_TYPE_WDDM) {
            /* UMD/KMD take care of removing the debug object */
        }
        else {
            res = context->dev->dmal->debugObjectFree(context, &context->debugObj, &context->hComputeObject);
            if (res != CUDBG_SUCCESS)
                CUDBG_TRACE("Failed to free debug object for context 0x%" PRIx64 "\n", context->cuCtx);
        }
    }

    dev = context->dev;

    if (context == dev->memMapContext) {
        res = dev->haloClient->unmapMemory(dev);
        if (res != CUDBG_SUCCESS)
            API_TRACE(10, "Unmapping failed on context : 0x%" PRIx64 "\n", context->cuCtx);
    }

    if (context == dev->activeContext)
        dev->activeContext = NULL;

    if (removeFromMap) {
        res = haloStateRemoveContext(context->cuCtx);
        if (res != CUDBG_SUCCESS) {
            CUDBG_TRACE("Failed to remove context from halo 0x%" PRIx64 "\n", context->cuCtx);
        }
    }

    (void)toolsHashMapDelete(context->modules, deleteModuleWrap, NULL);
    context->modules = NULL;

    (void)toolsRangeMapDestroy(&context->gpuAddrToPatch, deletePatch, NULL);
    context->gpuAddrToPatch = NULL;

    if (context->patchEntry) {
        // 1: the patches that are deleted here were created under `case 
        //    dbgReportPatch` in the same file
        // 2: only the 1st occurence of each multi-entry patch was added to
        //    gpuAddrToPatch
        // 3: all occurences of each multi-entry patch were added to patchEntry
        // 4: deletePatch deletes the 1st occurences in gpuAddrToPatch and 
        //    removes them (without deleting) from patchEntry
        // 5: deleteMultiEntryPatch deletes only 2nd+ occurences from patchEntry
        //    because the 1st occurences were removed by deletePatch
        (void)toolsHashMapDelete(context->patchEntry, deleteMultiEntryPatch, NULL);
        context->patchEntry = NULL;
    }

    haloStateDestroyContext(context);

    return res;
}

static CUDBGResult
deleteContextWrap(Context context, void *data)
{
    return deleteContext(context, false);
}

static CUDBGResult
createGrid(Context context, Grid *pGrid, DeviceFunction function, uint64_t gridId64)
{
    return haloStateCreateGrid(pGrid, function, gridId64);
}

static CUDBGResult
isFuncPostable(DeviceFunction function, bool *isFuncPostable)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(function, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments to isFuncPostable\n");
    CUDBG_VERIFY(isFuncPostable, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments to isFuncPostable\n");

    /* Initialize to false */
    *isFuncPostable = false;

    if (function->type == DEV_FUNC_TYPE_GLOBAL) {
        *isFuncPostable = true;
        return CUDBG_SUCCESS;
    }

    /* When in deferred mode, all grids are marked postable
       as long as they are not in CNP entry/exit code. This
       ensures the rest of the HALO treats the grids as live
       grids and extracts all necessary grid information */
    if (cudbgLaunchNotificationPolicy != CUDBG_NOTIFY_SYNC_ALL &&
        function->type != DEV_FUNC_TYPE_GLOBAL_SYSCALL) {
        *isFuncPostable = true;
        return CUDBG_SUCCESS;
    }

#ifndef RELEASE
    if (cudbgEnableInternalDebugging &&
        function->type == DEV_FUNC_TYPE_GLOBAL_SYSCALL) {
        *isFuncPostable = true;
        return CUDBG_SUCCESS;
    }

#endif

    return res;
}

/* gpudbgPostGridEvent is used to pair kernel launch events with actual device events */
CUDBGResult
gpudbgPostGridEvent(CudbgDevice dev, Context context, Grid grid, DeviceFunction function)
{
    CUDBGEvent *event;

    CUDBG_VERIFY(dev && context && grid && function,
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments to gpudbgPostGridEvent\n");

    if (cudbgLaunchNotificationPolicy != CUDBG_NOTIFY_SYNC_ALL) {
        API_TRACE_FUNCTION(10, "Posting Grid %" PRId64 " %s  deferred by context state \n", (uint64_t) grid->gridId64, function->name);
        grid->state = HALO_GRID_STATE_UNPOSTED;
        return CUDBG_SUCCESS;
    }

    /* Send an *async* event upwards to the debug client */
    if (clientRevision > API_REVISION_4_0 || !function->module->internal) {
        API_TRACE_FUNCTION(10, "Posting Grid %" PRId64 "\n", (int32_t)grid->gridId64);
        gpudbgEventsGetAvailable(&event, GPUDBG_EVENT_ASYNC);
        event->kind = CUDBG_EVENT_KERNEL_READY;
        event->cases.kernelReady.dev = dev->deviceIdx;
        event->cases.kernelReady.gridId = grid->gridId64;
        event->cases.kernelReady.tid = context->hostThreadId;
        event->cases.kernelReady.context = context->cuCtx;
        event->cases.kernelReady.module = function->module->cuModule;
        event->cases.kernelReady.function = function->cuFunction;
        event->cases.kernelReady.functionEntry = function->virtAddrBase;
        event->cases.kernelReady.gridDim = grid->gridDim;
        event->cases.kernelReady.blockDim = grid->blockDim;
        event->cases.kernelReady.type = function->module->internal ? CUDBG_KNL_TYPE_SYSTEM : CUDBG_KNL_TYPE_APPLICATION;
        event->cases.kernelReady.parentGridId = grid->parentGridId64;
        event->cases.kernelReady.origin = grid->origin;
        /* Note:  we explicitly do _not_ send a notification to the
           client (via gpudbgNotifyDebugger), because we are pairing
           it with a device event (exception, breakpoint, trap, etc.).
           This needs to be properly documented in the Debug API. */

        /* Indicate this grid has been posted */
        grid->state = HALO_GRID_STATE_POSTED;
    }

    return CUDBG_SUCCESS;
}

/* gpudbgCreateDynamicGrid is used for dynamically creating grids on the fly
 * (by rebuilding state read from the GPU) */
CUDBGResult
gpudbgCreateDynamicGrid(CudbgDevice dev, uint32_t sm, uint32_t wp, uint32_t ln,
                        uint64_t gridId64, uint64_t physPC,
                        CuDim3 gridDim, CuDim3 blockDim, bool *isPostable)
{
    CUDBGResult res = CUDBG_SUCCESS;
    DeviceFunction function;
    Grid grid;
    Context context;
    bool skipcreate = false;
    bool patchDebug = false;

    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments to gpudbgCreateDynamicGrid\n");

    API_TRACE_FUNCTION(1, "gridid = %" PRId64 ", physPC = 0x%016" PRIx64 ").\n", gridId64, physPC);

    /* Ensure we have an active context */
    context = dev->activeContext;
    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "Device has no active context\n");

#ifndef RELEASE
    if (cudbgEnableInternalDebugging) {
        /* If we're under internal debugging, then trap regions are shown (warps
           inside these regions are not hidden).  Further, normally warps stopped
           in a fallthrough region can be unwound to point to the user grid that
           got them here; however there are some cases when this unwind cannot
           occur (no call tokens are pushed), and all we know about is the trap
           region itself.  So if this is the first time we see this gridId for a
           warp in a trap region, we need to cook the physPC to point to the join
           routine (as this is the only way a warp could stop in this region, and
           it's the only func we have). */
        DebugPatch patch = NULL;
        uintptr_t joinFuncAddr;
        bool joinFuncFound = false, inTrapRegion = false;
        const char *joinFuncName = "cudaDeviceSynchronize";

        res = dev->haloClient->inTrapRegion(dev, physPC, &patch, &inTrapRegion);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to determine if warp is in trap region (res=%d)\n", res);
            return res;
        }
        if (inTrapRegion) {
            res = gpudbgLookupDeviceCodeSymbol((char *)joinFuncName, &joinFuncFound, &joinFuncAddr);
            if (res != CUDBG_SUCCESS || !joinFuncFound) {
                CUDBG_ERROR("Failed to lookup CNP join function address\n");
                return res;
            }
            function = (DeviceFunction)toolsRangeMapLookupByAddr(virtAddrToFunction, joinFuncAddr);
            if (!function) {
                CUDBG_ERROR("Failed to find join function structure\n");
                return CUDBG_ERROR_INTERNAL;
            }
            physPC = function->gpuAddrBase;
        }
    }
#endif

    /* At this point, the physPC could be pointing to a PC inside a patch region.
       We call the resolver to cook the PC back into user code. If the PC is not
       in a patch region, this call will not affect physPC. Note the handling
       of the trap region under patch debugging is already handled by this point. */
    res = resolvePatchToEntryAddr_common(dev, sm, wp, ln, &physPC, &patchDebug, false, false);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Failed to resolve patch to entry.\n");
        return res;
    }

    /* Lookup the function */
    function = (DeviceFunction)toolsRangeMapLookupByAddr(context->gpuAddrToFunction, physPC);
    CUDBG_VERIFY(function, CUDBG_ERROR_INVALID_ADDRESS, "Failed to find function (physPC = 0x%016" PRIx64 ")\n", physPC);

    /* It is possible that we are in an entrypoint syscall.  If so,
       then indicate we shouldn't post this grid yet (eventually
       we will) */
    res = isFuncPostable(function, isPostable);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Error determining if func is postable (res=%d)\n", res);
        return res;
    }

    if (!*isPostable) {
        API_TRACE_FUNCTION(1, "physPC 0x%016" PRIx64 " isn't postable yet (%s)\n",
                           physPC, function->name ? function->name : "NULL");
    }

#ifndef RELEASE
    if (cudbgEnableInternalDebugging) {
        grid = haloStateDeviceGetGrid(dev, gridId64);
        if (grid)
            skipcreate = true;
    }
#endif
    /* Create the grid */
    if (!skipcreate) {
        res = createGrid(context, &grid, function, gridId64);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to create grid\n");
            return res;
        }
        /* Fill in additional per-grid information */
        grid->gridDim = gridDim;
        grid->blockDim = blockDim;
    }

    API_TRACE(1, "Dynamic grid created (gridid = %" PRId64 ", func=%s, "
              "gridDim.x,y,z=%d,%d,%d, blockDim.x,y,z=%d,%d,%d)\n",
              gridId64, function->name ? function->name : "NULL",
              grid->gridDim.x, grid->gridDim.y, grid->gridDim.z,
              grid->blockDim.x, grid->blockDim.y, grid->blockDim.z);

    return CUDBG_SUCCESS;
}

/* gpudbgUpdateDynamicGrid is used to update a grid structure as it moves from
 * system calls into user code */
CUDBGResult
gpudbgUpdateUnpostedDynamicGrid(CudbgDevice dev, uint32_t sm, uint32_t wp, uint32_t ln,
                                Grid *grid, uint64_t physPC, bool *isPostable)
{
    CUDBGResult res = CUDBG_SUCCESS;
    Context context;
    Grid currentGrid;
    DeviceFunction function;
    CuDim3 blockDim, gridDim;
    uint64_t gridId64;
    uint32_t skipverify = 0;
    bool patchDebug = false;
    bool found = false;

    CUDBG_VERIFY(dev && grid && *grid && isPostable,
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments to gpudbgUpdateGrid\n");

    currentGrid = *grid;
#ifndef RELEASE
    if (cudbgEnableInternalDebugging)
        skipverify = 1;
#endif
    if (!skipverify)
        CUDBG_VERIFY(currentGrid->state == HALO_GRID_STATE_INVISIBLE, CUDBG_ERROR_UNKNOWN,
                     "Attempt to update a posted grid.\n");

    context = dev->activeContext;
    *isPostable = false;

    res = dev->halo.readUserEntryFramePC(dev, sm, wp, ln, &found, &physPC);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Error reading user entry frame PC\n");
        return res;
    }

    if (found) {
        /* At this point, the physPC could be pointing to a PC inside a patch region.
           We call the resolver to cook the PC back into user code. If the PC is not
           in a patch region, this call will not affect physPC  */
        res = resolvePatchToEntryAddr(dev, sm, wp, ln, &physPC, &patchDebug);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to resolve patch to entry.\n");
            return res;
        }
    }

    function = (DeviceFunction)toolsRangeMapLookupByAddr(context->gpuAddrToFunction, physPC);

    if (function) {
        /* We determine if this grid needs to be posted by
           checking if the new func is a user-level entrypoint */
        res = isFuncPostable(function, isPostable);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Error determining if func is postable (res = %d)\n", res);
            return res;
        }

        if (*isPostable) {
            API_TRACE_FUNCTION(1, "Grid %" PRId64 " / function %s (currentFunc:%s) is now postable\n",
                               currentGrid->gridId64, function->name ? function->name : "NULL",
                               currentGrid->function->name);
        }

        /* We determine if this grid needs to be updated by
           comparing its current location (lookup the func)
           to what was previously assigned as the function */
        if (function != currentGrid->function &&
            function->type == DEV_FUNC_TYPE_GLOBAL) {
            /* Save off currentGrid information */
            gridId64 = currentGrid->gridId64;
            gridDim = currentGrid->gridDim;
            blockDim = currentGrid->blockDim;

            API_TRACE_FUNCTION(1, "Grid %" PRId64 " function %s -> %s \n",
                               gridId64, currentGrid->function->name, function->name);

            /* Remove the old grid */
            deleteGrid(currentGrid);

            /* Create the updated grid */
            res = createGrid(context, grid, function, gridId64);
            if (res != CUDBG_SUCCESS)
                return res;

            /* Fill in additional per-grid information */
            (*grid)->gridDim = gridDim;
            (*grid)->blockDim = blockDim;
        }
    }

    return res;
}

static void
deleteGrid(Grid grid)
{
    haloStateDestroyGrid(grid);
}

static void
deleteFunction(DeviceFunction function, bool removeFromMap)
{
    DebugPatch patch = NULL;

    if (!function)
        return;

    /* Update global maps */
    (void)toolsRangeMapRemoveByAddr(virtAddrToFunction, function->virtAddrBase);

    /* Remove from the context wide maps */
    (void)toolsRangeMapRemoveByAddr(function->module->context->gpuAddrToFunction, function->gpuAddrBase);

    if (removeFromMap) {
        (void)toolsHashMapRemove(function->module->functions, tHashMapNumToKey(function->cuFunction), NULL);
    }

    /* Delete the internals */
    (void)toolsHashMapDelete(function->breakPoints, deleteBreakpoint, NULL);
    function->breakPoints = NULL;

    if (function->temporaryBreakPoints) {
        (void)toolsHashMapDelete(function->temporaryBreakPoints, deleteBreakpoint, NULL);
        function->temporaryBreakPoints = NULL;
    }

    /* Delete any corresponding syscall patch */
    patch = (DebugPatch)toolsRangeMapLookupByAddr(function->module->context->gpuAddrToPatch,
                                                  tHashMapNumToKey(function->gpuAddrBase));
    if (patch) {
        (void)dbgRemovePatch(patch);
        dbgDestroyPatch(patch);
        patch = NULL;
    }

    if (function->relatedFunction) {
        (void)toolsRangeMapRemoveByAddr(function->module->context->gpuAddrToFunction, function->relatedFunction->gpuAddrBase);
        if (removeFromMap) {
            (void)toolsHashMapRemove(function->module->functions, tHashMapNumToKey(function->relatedFunction->cuFunction), NULL);
        }
        haloStateDestroyFunction(function->relatedFunction);
    }

    haloStateDestroyFunction(function);
}

static void
deleteFunctionWrap(void *entry, void *data)
{
    deleteFunction((DeviceFunction)entry, false);
}

static void
deleteModule(DeviceModule module, bool removeFromMap)
{
    if (!module)
        return;

    /* Tear down the contents */
    (void)toolsHashMapDelete(module->functions, deleteFunctionWrap, NULL);
    module->functions = NULL;

    if (removeFromMap) {
        (void)toolsHashMapRemove(module->context->modules, tHashMapNumToKey(module->cuModule), NULL);
    }

    free(module->stringTable);
    module->stringTable = NULL;
    free(module->nonRelocatedElfImage);
    module->nonRelocatedElfImage = NULL;
    free(module->relocatedElfImage);
    module->relocatedElfImage = NULL;
    free(module->regMap);
    module->regMap = NULL;

    haloStateDestroyModule(module);

}

static void
deleteModuleWrap(void *entry, void *data)
{
    deleteModule((DeviceModule)entry, false);
}

static void
deletePatch(void *entry, void *data)
{
    DebugPatch patch;

    patch = (DebugPatch)entry;
    if (patch) {
        if (patch->entryAddr) {
            // Remove the patch from patchEntry. This ensures the patch is not
            // double free'd when patchEntry hashMap is deleted.
            // Read comments in deleteContext for more details.
            (void)toolsHashMapRemove(patch->context->patchEntry,
                                     tHashMapNumToKey(patch->entryAddr),
                                     NULL);
        }
        dbgDestroyPatch(patch);
        patch = NULL;
    }
}

static void
deleteMultiEntryPatch(void *entry, void *data)
{
    DebugPatch patch;

    patch = (DebugPatch)entry;
    if (patch) {
        dbgDestroyPatch(patch);
        patch = NULL;
    }
}

static void
destroyBrokenAddrRange(void *entry, void *data)
{
    free(entry);
}

/**
 * \fn CUDBGAPI_st::finalize
 * \brief Finalize the API and free all memory.
 *
 * Since CUDA 3.0.
 *
 * \ingroup INIT
 *
 * \return ::CUDBG_SUCCESS,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_COMMUNICATION_FAILURE,
 * \return CUDBG_ERROR_UNKNOWN
 *
 * \sa initialize
 */
CUDBGResult
gpudbgFinalize(void)
{
    int retVal;
    CUDBGResult res;

    API_TRACE_FUNCTION(1, "\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT    |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    /* Ordering is important here:
       (1) Finalize the device
       (2) Terminate all threads/processes spawned by the API
       (3) Cleanup internal data structures
       (4) Finalize internal utilities (tracing; all of the above items depend on this) */

    /* (1) Finalize the device */
    tgdbResetAllDevices();

    /* (2) Terminate all threads/processes spawned by the API */
#if cuosOsIsApple()
    if ((res = terminateMacEventThread())) {
        API_TRACE_FUNCTION(1, "terminating Mac event thread failed\n");
        return res;
    }
#endif

    /* If the stub wasn't cleaned up with a call to gpudbgRequestCleanupOnDetach()
       (can happen if the inferior is killed after an attach), clean it up here */
    if (cudbgAttachStubAvailable) {
        CUDBGAPIMSG_t message;
        uint32_t result;

        message.kind = CUDBGAPIREQ5x_finalize;

        if ((res = gpudbgSendMessageToAttachStub(&message, &result))) {
            API_TRACE_FUNCTION(0, "Failed to send a message to the attach stub to finalize!\n");
            return res;
        }

        if (result != CUDBG_SUCCESS) {
            API_TRACE_FUNCTION(0, "Failed to finalize the attach stub (result=%u)\n",
                               result);
            /* Keep going */
        }

        cudbgAttachStubAvailable = false;
    }

    /* Send a terminate message to the dispatcher and wait for it to exit */
    gpudbgSendDebuggerMessage(TGDB_DBGMSG_TERMINATE, 0, 0, 0, NULL, NULL);
    cuosThreadJoin(cudbgDispatcherThreadHandle, &retVal);
    if (retVal == -1) {
        CUDBG_TRACE("Dispatcher thread returned error (ignored)\n");
    }

    /* (3) Cleanup internal data structures */
    if ((res = cudbgPipeFinalize(&dispatcherToApplication)))
        return res;
    if ((res = cudbgPipeFinalize(&applicationToDispatcher)))
        return res;
    if ((res = cudbgPipeFinalize(&debuggerToDispatcher)))
        return res;
    if ((res = cudbgPipeFinalize(&dispatcherToDebugger)))
        return res;

    gpudbgEventsFinalize(GPUDBG_EVENT_SYNC);
    gpudbgEventsFinalize(GPUDBG_EVENT_ASYNC);

    API_TRACE_FUNCTION(1, "deleting contexts\n");
    res = haloStateDestroyContexts(deleteContextWrap, NULL);
    if (res != CUDBG_SUCCESS)
        CUDBG_TRACE("Call to deleteContext failed in gpudbgFinalize.\n");

    (void)toolsHashMapDelete(pendingPatches, NULL, NULL);
    pendingPatches      = NULL;

    API_TRACE_FUNCTION(1, "deleting rangemaps\n");
    (void)toolsRangeMapDestroy(&virtAddrToFunction, NULL, NULL);
    virtAddrToFunction  = NULL;
    (void)toolsRangeMapDestroy(&brokenVirtAddrToFunction, destroyBrokenAddrRange, NULL);
    brokenVirtAddrToFunction  = NULL;

    res = haloStateDestroyUVM();
    if (res != CUDBG_SUCCESS)
        CUDBG_TRACE("Call to haloStateDestroyUVM failed in gpudbgFinalize. (res=%d)\n", res);

    haloFinalize();

    /* (4) Finalize internal utilities */
    cudbgUtilsFinalize();

    /* (5) Free the TLS key */
    cudbgTlsFinalize();

    moduleInitialized = false;

    API_TRACE_FUNCTION(1, "finished\n");

    return res;
}

/*-------------------------------- Functions ---------------------------------*/

/*
 * The current assumption is that the GPU is
 * exclusively owned by the cuda application
 * being debugged.
 *
 * Resume and suspend are not needed if no
 * launch is currently in progress, but such
 * a launch-in-progress does not mean that the
 * GPU is currently running on behalf of the
 * current app: the launch can still be in the
 * fifo, or it might have terminated. Because
 * the app is the exclusive owner of the GPU,
 * we know that in such case the GPU must be
 * idle. In these cases suspend and resume will
 * not do any harm.
 */


/**
 * \fn CUDBGAPI_st::suspendDevice
 * \brief Suspends a running CUDA device.
 *
 * Since CUDA 3.0.
 *
 * \ingroup EXEC
 *
 * \param dev - device index
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_RUNNING_DEVICE,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa resumeDevice
 * \sa singleStepWarp
 */
CUDBGResult
gpudbgSuspendDevice(uint32_t devId)
{
    CUDBGResult res;

    API_TRACE_FUNCTION(1, "%u\n", devId);

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT    |
                    CUDBG_API_CHECK_TLS_CB  |
                    CUDBG_API_CHECK_DEV_ID,
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    if (haloGlobals.state->attachState == HALO_ATTACH_STATE_DETACHING) {
        /* The device will already be suspended when we're detaching */
        res = CUDBG_SUCCESS;
        goto end;
    }

    res = gpudbgSendDebuggerMessage(TGDB_DBGMSG_SUSPEND, devId, 0, 0, NULL, NULL);

end:
    API_TRACE_FUNCTION(1, " %u - done %u\n", devId, res);
    return res;
}


/**
 * \fn CUDBGAPI_st::resumeDevice
 * \brief Resume a suspended CUDA device.
 *
 * Since CUDA 3.0.
 *
 * \ingroup EXEC
 *
 * \param dev - device index
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_RUNNING_DEVICE,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa suspendDevice
 * \sa singleStepWarp
 */
CUDBGResult
gpudbgResumeDevice(uint32_t devId)
{
    CUDBGResult res;

    API_TRACE_FUNCTION(1, " %u\n", devId);

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_ID),
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    if (haloGlobals.state->attachState == HALO_ATTACH_STATE_DETACHING) {
        /* The device needs to be kept suspended when we're detaching.
           Since we re-enable the driver's trap handlers while detaching, if
           the device resumes and hits a trap, it will cause contention beween
           the debugger's and the driver's trap handlers.
           To avoid this scenario, the device is resumed only from
           tgdbResetDevices() when the API is finalized. */
        res = CUDBG_SUCCESS;
        goto end;
    }

    res = gpudbgSendDebuggerMessage(TGDB_DBGMSG_RESUME, devId, 0, 0, NULL, NULL);

end:
    API_TRACE_FUNCTION(1, " %u - done %u\n", devId, res);
    return res;
}


/**
 * \fn CUDBGAPI_st::singleStepWarp40
 * \brief Single step an individual warp on a suspended CUDA device.
 *
 * Since CUDA 3.0.
 *
 * \deprecated in CUDA 4.1.
 *
 * \ingroup EXEC
 *
 * \param dev - device index
 * \param sm  - SM index
 * \param wp  - warp index
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_RUNNING_DEVICE,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_UNKNOWN,
 * \return CUDBG_ERROR_WARP_RESUME_NOT_POSSIBLE
 *
 * \sa resumeDevice
 * \sa suspendDevice
 * \sa singleStepWarp
 */
CUDBGResult
gpudbgSingleStepWarp40(uint32_t devId, uint32_t sm, uint32_t wp)
{
    uint64_t steppedWarpMask;

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID),
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    return gpudbgSingleStepWarp(devId, sm, wp, 1, &steppedWarpMask);
}

/**
 * \fn CUDBGAPI_st::singleStepWarp41
 * \brief Single step an individual warp on a suspended CUDA device.
 *
 * Since CUDA 4.1.
 *
 * \deprecated in CUDA 7.5.
 *
 * \ingroup EXEC
 *
 * \param dev - device index
 * \param sm  - SM index
 * \param wp  - warp index
 * \param warpMask - the warps that have been single-stepped
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_RUNNING_DEVICE,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_UNKNOWN
 *
 * \sa resumeDevice
 * \sa suspendDevice
 */
CUDBGResult
gpudbgSingleStepWarp41(uint32_t devId, uint32_t sm, uint32_t wp, uint64_t *warpMask)
{
    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID),
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    return gpudbgSingleStepWarp(devId, sm, wp, 1, warpMask);
}

/**
 * \fn CUDBGAPI_st::singleStepWarp
 * \brief Single step an individual warp nsteps times on a suspended CUDA device.
 *        Only the last instruction in a range should be a control flow instruction.
 *
 * Since CUDA 7.5.
 *
 * \ingroup EXEC
 *
 * \param dev - device index
 * \param sm  - SM index
 * \param wp  - warp index
 * \param nsteps   - number of single steps
 * \param warpMask - the warps that have been single-stepped
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_RUNNING_DEVICE,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_UNKNOWN
 *
 * \sa resumeDevice
 * \sa suspendDevice
 */
CUDBGResult
gpudbgSingleStepWarp(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t nsteps, uint64_t *warpMask)
{
    CUDBGResult res;
    debuggerMessageData_t data = { 0U };
    debuggerMessageReply_t reply;
    uint32_t checkCtxSync = 0;
    CUwarpBitmask localWarpMask = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;

    CUDBG_VERIFY(warpMask, CUDBG_ERROR_INVALID_ARGS, "Invalid args in gpudbgSingleStepWarp\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID),
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    API_TRACE_FUNCTION(1, " %u/%u/%u\n", devId, sm, wp);

    if (clientRevision > API_REVISION_5_5) {
        checkCtxSync = 1;
    }

    *warpMask = 0ULL;
    reply.res = CUDBG_ERROR_UNKNOWN;

    warpBitmaskClear(&reply.warpMask);

    /* Fill message data */
    data.checkCtxSync = checkCtxSync;
    data.nsteps = nsteps;
    warpBitmaskAssign(&data.warpMask, &localWarpMask);

    res = gpudbgSendDebuggerMessage(TGDB_DBGMSG_SSTEPWARP, devId, sm, wp, &data, &reply);
    if (res != CUDBG_SUCCESS)
        goto end;

    *warpMask = (uint64_t)warpBitmaskGetBits(&reply.warpMask, 0, 64);

end:
    API_TRACE_FUNCTION(1, " %u/%u/%u - done (res=%u warpMask=0x%" PRIx64 "\n", devId, sm, wp, res, *warpMask);
    return res;
}

/**
 * \fn CUDBGAPI_st::resumeWarpsUntilPC
 * \brief Inserts a temporary breakpoint at the specified virtual PC,
 *        and resumes all warps in the specified bitmask on a given SM.
 *        As compared to CUDBGAPI_st::resumeDevice, CUDBGAPI_st::resumeWarpsUntilPC
 *        provides finer-grain control by resuming a selected set of warps on the
 *        same SM.  The main intended usage is to accelerate the single-stepping
 *        process when the target PC is known in advance.  Instead of single-stepping
 *        each warp individually until the target PC is hit, the client can issue this
 *        API.  When this API is used, errors within CUDA kernels will no longer be
 *        reported precisely.  In the situation where resuming warps is not possible,
 *        this API will return CUDBG_ERROR_WARP_RESUME_NOT_POSSIBLE.  The client
 *        should then fall back to using CUDBGAPI_st::singleStepWarp or
 *        CUDBGAPI_st::resumeDevice.
 *
 * Since CUDA 6.0.
 *
 * \ingroup EXEC
 *
 * \param devId - device index
 * \param sm - the SM index
 * \param warpMask - the bitmask of warps to resume (1 = resume, 0 = do not resume)
 * \param virtPC - the virtual PC where the temporary breakpoint will be inserted
 *
 * \return CUDBG_SUCCESS
 * \return CUDBG_ERROR_INVALID_ARGS
 * \return CUDBG_ERROR_INVALID_DEVICE
 * \return CUDBG_ERROR_INVALID_SM
 * \return CUDBG_ERROR_INVALID_WARP_MASK
 * \return CUDBG_ERROR_WARP_RESUME_NOT_POSSIBLE
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa resumeDevice
 */
CUDBGResult
gpudbgResumeWarpsUntilPC(uint32_t devId, uint32_t sm, uint64_t warpMask, uint64_t virtPC)
{
    CUDBGResult res = CUDBG_SUCCESS, res2 = CUDBG_SUCCESS;
    CudbgDevice dev;
    Grid grid;
    uint32_t wp;
    bool isWarpOnBarrier = false;
    debuggerMessageData_t data = { 0U };
    CUwarpBitmask localWarpMask = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;
    CUwarpBitmask validWarpMask = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;

    API_TRACE_FUNCTION(1, " %u/%u/0x%" PRIx64 "\n", devId, sm, warpMask);

    CUDBG_API_CHECK(CUDBG_API_CHECK_DEV_STATUS      |
                    CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_SM),
                    devId, sm,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    if (!warpMask) {
        res = CUDBG_ERROR_INVALID_WARP_MASK;
        goto end;
    }

    warpBitmaskSetBits(&localWarpMask, 0, 64, warpMask);
    warpBitmaskAnd(&validWarpMask, &localWarpMask, &dev->smState[sm].state.tidValid);

    if (!warpBitmaskEqual(&localWarpMask, &validWarpMask)) {
        res = CUDBG_ERROR_INVALID_WARP_MASK;
        goto end;
    }

    /* Check if any warps in the warp mask can potentially execute
       a call to cudaDeviceSynchronize() or if they might be waiting
       on a barrier.  If so, return an error to the client that
       resumeWarps is not possible. */
    for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; wp++) {
        if (!warpBitmaskGetBits(&localWarpMask, wp, 1))
            continue;

        res = dev->halo.isWarpOnBarrier(dev, sm, wp, &isWarpOnBarrier);
        if (res != CUDBG_SUCCESS)
            goto end;

        if (isWarpOnBarrier) {
            res = CUDBG_ERROR_WARP_RESUME_NOT_POSSIBLE;
            goto end;
        }
        
        grid = haloStateDeviceGetGrid(dev, dev->smState[sm].warp[wp].gridId64);
        if (!grid || !grid->function) {
            res = CUDBG_ERROR_INVALID_WARP_MASK;
            goto end;
        }

        if (grid->function->usesContinuations) {
            res = CUDBG_ERROR_WARP_RESUME_NOT_POSSIBLE;
            goto end;
        }
    }

    /* Insert the breakpoint instruction and save the original instruction. */
    CUDBG_DEBUG(" inserting temporary breakpoint at virt PC 0x%08x\n", virtPC);
    res = gpudbgSetBreakpoint(devId, virtPC);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Failed to insert temporary breakpoint\n");
        goto end;
    }

    warpBitmaskAssign(&data.warpMask, &localWarpMask);

    /* Tell the dispatcher to resume warps.  After this call completes,
       we need to make sure the temporary breakpoint is removed, which
       means we cannot early exit here.  This call can return
       CUDBG_ERROR_WARP_RESUME_NOT_POSSIBLE (which the client will
       use to make fall back decisions), so this means we also have to
       preserve the error code here. */
    res = gpudbgSendDebuggerMessage(TGDB_DBGMSG_RESUMEWARPS, devId, sm, 0, &data, NULL);
    if (res != CUDBG_SUCCESS && res != CUDBG_ERROR_WARP_RESUME_NOT_POSSIBLE)
        CUDBG_ERROR("Failed to resume warps\n");

    /* Remove the breakpoint instruction and restore the original instruction. */
    CUDBG_DEBUG(" removing temporary breakpoint at virt PC 0x%08x\n", virtPC);
    res2 = gpudbgUnsetBreakpoint(devId, virtPC);
    if (res2 != CUDBG_SUCCESS) {
        CUDBG_ERROR("Failed to remove temporary breakpoint\n");
        res = res2; /* Override the return code only if there was an error here */
        goto end;
    }

end:
    API_TRACE_FUNCTION(1, " %u/%u/" CU_WARP_BIT_MASK_FMT_128_STR " - done (res=%u)\n", devId, sm,
                       CU_WARP_BIT_MASK_FMT_128_VAL(&localWarpMask), res);
    return res;
}

/*
  popMessage copies size bytes from *p into a newly allocated
  buffer. *obj is set to the top of this buffer. *p is advanced to
  point to the next object.
*/
static CUDBGResult
popMessage(void **p, void *obj, uint64_t size)
{
    memcpy(obj, *p, (size_t)size);
    *p = (char*)*p + size;
    return CUDBG_SUCCESS;
}

CUDBGResult
gpudbgSendDebuggerMessage(tgdb_dbgmsg_kind_t kind, uint32_t dev, uint32_t vsm, uint32_t wp, debuggerMessageData_t *data, debuggerMessageReply_t *reply)
{
    CUDBGResult res = CUDBG_ERROR_UNKNOWN;
    debuggerMessage_t debuggerMessage;
    debuggerMessageReply_t debuggerMessageReply;
    static debuggerMessageData_t emptyData = { 0U };
    static uint32_t debuggerMessageCounter = 0;
    bool eof = false;

    memset(&debuggerMessage, 0, sizeof(debuggerMessage));
    debuggerMessage.id = debuggerMessageCounter++;
    debuggerMessage.kind = kind;
    debuggerMessage.dev = dev;
    debuggerMessage.vsm = vsm;
    debuggerMessage.wp = wp;
    debuggerMessage.data = data ? *data : emptyData;

    /* We still need a container for the reply, even if the caller does not provide us with one. */
    if (!reply)
        reply = &debuggerMessageReply;

    API_TRACE_FUNCTION(10, "id=%u kind=%d dev=%u vsm=%u wp=%u\n", debuggerMessage.id, kind, dev, vsm, wp);

    if ((res = cudbgPipeWrite(&debuggerToDispatcher, &debuggerMessage, sizeof(debuggerMessage))))
        return res;

    if ((res = cudbgPipeBlockingRead(&dispatcherToDebugger, reply, sizeof(*reply), &eof)))
        return res;

    return reply->res;
}

static Context
gpudbgCreateContext(uint64_t ctx, uint32_t devId, uint32_t tid, bool launchBlocking,
                    bool *requiresDebuggerAck, uint32_t *hostThreadId,
                    uint64_t scratchpadDevVA, uint64_t scratchpadDevPtr,
                    uint32_t hAppClient, uint32_t hComputeObject, uint32_t hChannelGroup,
                    uint32_t *channelList, uint32_t numChannels)
{
    Context context;
    CUDBGEvent *event;
    CUDBGResult res = CUDBG_SUCCESS;

    API_TRACE_FUNCTION(1, "CtxCreation:\n");
    API_TRACE_FUNCTION(3, "    device         : %u\n", devId);
    API_TRACE_FUNCTION(3, "    cuCtx          : 0x%" PRIx64 "\n", ctx);
    API_TRACE_FUNCTION(3, "    host thread id : %u\n", tid);
    API_TRACE_FUNCTION(3, "    blocking       : %s\n", launchBlocking ? "yes" : "no");
    API_TRACE_FUNCTION(3, "    scratchpadDevVA: 0x%" PRIx64 "\n", scratchpadDevVA);

    res = haloStateCreateContext(&context, ctx, devId, scratchpadDevVA,
                                 scratchpadDevPtr,
                                 hAppClient, hComputeObject, hChannelGroup,
                                 channelList, numChannels);
    if (res != CUDBG_SUCCESS)
        return NULL;

    context->hostThreadId = tid;
    context->launchBlocking = launchBlocking;
    context->launchNotifyState = cudbgLaunchNotificationPolicy;
    context->enableEvents = true;

    /*  XXX move somewhere else */
    context->dev->expectingGpuEvent = 1;

    res = haloStateAddContext(ctx, context);
    if (res != CUDBG_SUCCESS)
        return NULL;

    if (clientRevision >= API_REVISION_3_2) {
        gpudbgEventsGetAvailable(&event, GPUDBG_EVENT_SYNC);
        event->kind = CUDBG_EVENT_CTX_CREATE;
        event->cases.contextCreate.dev = context->dev->deviceIdx;
        event->cases.contextCreate.context = context->cuCtx;
        event->cases.contextCreate.tid = context->hostThreadId;
        *requiresDebuggerAck = true;
        *hostThreadId = context->hostThreadId;
    }

    memset(context->fdArray, 0, sizeof context->fdArray);

    return context;
}

static CUDBGResult
updateBrokenVirtAddrMap(DeviceFunction function)
{
    uint64_t rangeStart = 0, rangeEnd = 0;
    uint64_t blockStart = 0, blockEnd = 0;
    tRangeMapItr *itr = NULL;
    dbgBrokenAddrRange *range = NULL, *block = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;

    rangeStart = function->virtAddrBase;
    rangeEnd = function->virtAddrBase + function->codeSize - 1;

    itr = toolsRangeMapGetIteratorByRange(brokenVirtAddrToFunction,
                                          function->virtAddrBase,
                                          function->codeSize);
    while (itr) {
        blockStart = toolsRangeMapGetAddr(itr);
        blockEnd = blockStart + toolsRangeMapGetSize(itr) - 1;

        /* Remove the range */
        block = (dbgBrokenAddrRange *)toolsRangeMapRemoveByAddr(
                brokenVirtAddrToFunction, blockStart);
        destroyBrokenAddrRange(block, NULL);

        /* Union the existing range with the target */
        rangeStart = MIN(rangeStart, blockStart);
        rangeEnd = MAX(rangeEnd, blockEnd);

        itr = toolsRangeMapGetIteratorByRange(brokenVirtAddrToFunction,
                                              function->virtAddrBase,
                                              function->codeSize);
    }

    range = (dbgBrokenAddrRange *)calloc(1, sizeof(*range));
    CUDBG_VERIFY(range, CUDBG_ERROR_UNKNOWN, "Failed to allocate a range for the brokenVirtAddrToFunction map\n");
    range->start = rangeStart;
    range->size  = rangeEnd - rangeStart + 1;

    tres = toolsRangeMapInsertByRange(brokenVirtAddrToFunction, range->start, range->size, (void*)range);
    CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_UNKNOWN, "Failed to insert into brokenVirtAddrToFunction map\n");

    return CUDBG_SUCCESS;
}


static CUDBGResult
gpudbgGetModuleType(CUmodVisibility cuVisibility, DeviceModuleType_t *visibility)
{

    switch (cuVisibility) {
    case CU_MOD_VISIBILITY_VISIBLE                  : *visibility = DEV_MOD_TYPE_USER              ; break;
    case CU_MOD_VISIBILITY_HIDDEN_SYSCALL           : *visibility = DEV_MOD_TYPE_SYSCALL           ; break;
    case CU_MOD_VISIBILITY_HIDDEN_TRAPHANDLER       : *visibility = DEV_MOD_TYPE_TRAPHANDLER       ; break;
    case CU_MOD_VISIBILITY_HIDDEN_TRAMPOLINE        : *visibility = DEV_MOD_TYPE_TRAMPOLINE        ; break;
    case CU_MOD_VISIBILITY_HIDDEN_ATENTRY           : *visibility = DEV_MOD_TYPE_ATENTRY           ; break;
    case CU_MOD_VISIBILITY_HIDDEN_TOOLS             : *visibility = DEV_MOD_TYPE_TOOLS             ; break;
    case CU_MOD_VISIBILITY_HIDDEN_KEPLER_MEMBAR_WAR : *visibility = DEV_MOD_TYPE_MEMBAR_WAR        ; break;
    case CU_MOD_VISIBILITY_HIDDEN_EXITFUNCTION      : *visibility = DEV_MOD_TYPE_EXITFUNCTION      ; break;
    case CU_MOD_VISIBILITY_HIDDEN_USER              : *visibility = DEV_MOD_TYPE_HIDDEN_USER       ; break;
    case CU_MOD_VISIBILITY_HIDDEN_MEMBAR_OPTI_WAR   : *visibility = DEV_MOD_TYPE_MEMBAR_OPTI_WAR   ; break;
    case CU_MOD_VISIBILITY_HIDDEN_BARSYNC_WAR       : *visibility = DEV_MOD_TYPE_BARSYNC_WAR       ; break;
    default:
        *visibility = DEV_MOD_TYPE_INVALID;
        CUDBG_ERROR("Unhanled module type: %d\n", cuVisibility);
        return CUDBG_ERROR_UNKNOWN;
        break;
    }

    return CUDBG_SUCCESS;
}


CUDBGResult
gpudbgProcessApplicationMessage(void *msgBuffer, bool *requiresDebuggerAck, uint32_t *hostThreadId)
{
// __TEMP_WAR__ Bug 200135016
#if !cuosOsIsHos()
    void *p;
    CUDBGcommand *message;
    CUDBGEvent *event;
    CUDBGResult res = CUDBG_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;

    p = msgBuffer;
    message = (CUDBGcommand *)p;
    p = (char*)p + sizeof(CUDBGcommand);
    *requiresDebuggerAck = false;

    switch (message->kind) {
    case dbgCudaInitialized : {
        bool uvmEnabled = false;
        uint64_t uvmhdl = -1;

        uvmEnabled = message->cases.cudaInitialized.uvmEnabled;

        API_TRACE_FUNCTION(1, "CudaInitialized\n");
        API_TRACE_FUNCTION(3, "    uvmEnabled       : %u\n", uvmEnabled);
        if (uvmEnabled)
        {
            // Initialize UVM session
            if (cudbgIsCoredumpInProgress()) {
                res = popMessage(&p, &uvmhdl, sizeof(uvmhdl));
                if (res != CUDBG_SUCCESS) {
                    CUDBG_ERROR("Failed to pop message\n");
                    return res;
                }
            }
            else {
                int *ctrl_msg = NULL;
                res = cudbgPipeControlMessageRead(&applicationToDispatcher, &ctrl_msg);
                if (res != CUDBG_SUCCESS) {
                    CUDBG_ERROR("dbgCudaInitialized: Failed to read control data\n");
                    return res;
                }
                uvmhdl = (uint64_t)*ctrl_msg;
            }
            res = haloStateInitUVM(uvmhdl);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("dbgCudaInitialized: Failed to initialize UVM tools interface!\n");
                return res;
            }
        }

        break;
    }
    case dbgCtxCreation : {
        Context  context;
        uint64_t ctx;
        uint32_t devId, tid;
        bool launchBlocking;
        CudbgDevice dev;
        uint32_t hAppClient, hComputeObject, hChannelGroup, patchRamSize, globalFocusCoordsAllocSize;
        uint64_t scratchpadDVA, patchRamDevVA, scratchpadDptr, globalFocusCoordsAddr;
        uint32_t eventClassType;
        int *fdArray = NULL;
        uint32_t nfds = 0;

        devId          = message->cases.ctxCreation.device;
        ctx            = message->cases.ctxCreation.ctx;
        launchBlocking = message->cases.ctxCreation.launchBlocking;
        tid            = message->cases.ctxCreation.threadId;
        hAppClient     = message->cases.ctxCreation.hAppClient;
        hComputeObject = message->cases.ctxCreation.hComputeObject;
        hChannelGroup  = message->cases.ctxCreation.hChannelGroup;
        scratchpadDVA  = message->cases.ctxCreation.scratchpadDevVA;
        scratchpadDptr = message->cases.ctxCreation.scratchpadDevPtr;
        patchRamDevVA  = message->cases.ctxCreation.patchRamDevVA;
        patchRamSize  = message->cases.ctxCreation.patchRamSize;
        globalFocusCoordsAddr = message->cases.ctxCreation.globalFocusCoordsAddr;
        globalFocusCoordsAllocSize = message->cases.ctxCreation.globalFocusCoordsAllocSize;

        if (globals.numDevices <= devId || !haloGlobals.device[devId]) {
            CUDBG_ERROR("Context creation callback references a device "
                        "that the debugger doesn't know about: %d\n", devId);
            return CUDBG_ERROR_INVALID_DEVICE;
        }

        context = haloStateGetContext(ctx);
        if (!context) {
            context = gpudbgCreateContext(ctx, devId, tid, launchBlocking,
                                          requiresDebuggerAck, hostThreadId,
                                          scratchpadDVA,
                                          scratchpadDptr,
                                          hAppClient,
                                          hComputeObject,
                                          hChannelGroup,
                                          message->cases.ctxCreation.hChannelList,
                                          message->cases.ctxCreation.computeChannelCount);
            if (!context) {
                CUDBG_ERROR("Context creation failed.\n");
                return CUDBG_ERROR_INVALID_CONTEXT;
            }
        }
        else {
            /* If the context was created early, the following were not setup */
            context->patchRamDevVA = patchRamDevVA;
            context->patchRamSize = patchRamSize;
            context->scratchpadDevVA = scratchpadDVA;
            context->scratchpadDevPtr = scratchpadDptr;
            context->hAppClient = hAppClient;
            context->hComputeObject = hComputeObject;
            context->hChannelGroup = hChannelGroup;
            context->numChannels = message->cases.ctxCreation.computeChannelCount;
            context->globalFocusCoordsAddr = globalFocusCoordsAddr;
            context->globalFocusCoordsAllocSize = globalFocusCoordsAllocSize;

            /* Copy the list of channels for this context */
            memcpy(context->hComputeChannelList,
                   message->cases.ctxCreation.hChannelList,
                   context->numChannels * sizeof(*message->cases.ctxCreation.hChannelList));

            API_TRACE_FUNCTION(1, "CtxCreation (finalization)\n");
            API_TRACE_FUNCTION(3, "    device         : %u\n", devId);
            API_TRACE_FUNCTION(3, "    cuCtx          : 0x%" PRIx64 "\n", ctx);
        }

        context->numChannels = message->cases.ctxCreation.computeChannelCount;

        /* At this point, mark the context as active */
        res = haloStateContextSetState(context, HALO_CTX_STATE_ACTIVE);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to set context active\n");

        context->cilpBufferDevVA = message->cases.ctxCreation.cilpBufferDevVA;
        context->shmemWindowDevVA = message->cases.ctxCreation.shmemWindowDevVA;
        context->lmemWindowDevVA = message->cases.ctxCreation.lmemWindowDevVA;
        context->gmemWindowDevVA = message->cases.ctxCreation.gmemWindowDevVA;
        /* WARNING - this lmemSize is not finalized and may change between here
           and the first execution launch. This is mostly here for in-process
           routines like coredumps and memcheck which manage and track the
           lmemSizePerSM themselves */
        context->lmemSizePerSM = message->cases.ctxCreation.lmemSizePerSM;
        context->syscallRcVaddr = message->cases.ctxCreation.syscallRcVaddr;
        context->thCodeVA = message->cases.ctxCreation.thCodeVA;
        context->thCodeSize = message->cases.ctxCreation.thCodeSize;
        context->thRdRegOffset = message->cases.ctxCreation.thRdRegOffset;
        context->thWrRegOffset = message->cases.ctxCreation.thWrRegOffset;
        context->thRdTexMemOffset = message->cases.ctxCreation.thRdTexMemOffset;
        context->texHeaderPoolVA = message->cases.ctxCreation.texHeaderPoolVA;
        context->texSamplerPoolVA = message->cases.ctxCreation.texSamplerPoolVA;
        context->funcMemBaseVA = message->cases.ctxCreation.funcMemBaseVA;
        API_TRACE_FUNCTION(3, "    scratchpadDevVA   : 0x%" PRIx64 "\n", context->scratchpadDevVA);
        API_TRACE_FUNCTION(3, "    scratchpadDevPtr  : 0x%" PRIx64 "\n", context->scratchpadDevPtr);
        API_TRACE_FUNCTION(3, "    syscallRcVaddr    : 0x%" PRIx64 "\n", context->syscallRcVaddr);
        API_TRACE_FUNCTION(3, "    thCodeVA          : 0x%" PRIx64 "\n", context->thCodeVA);
        API_TRACE_FUNCTION(3, "    thCodeSize        : 0x%" PRIx64 "\n", context->thCodeSize);
        API_TRACE_FUNCTION(3, "    thRdRegOffset     : 0x%" PRIx64 "\n", context->thRdRegOffset);
        API_TRACE_FUNCTION(3, "    thWrRegOffset     : 0x%" PRIx64 "\n", context->thWrRegOffset);
        API_TRACE_FUNCTION(3, "    thRdTexMemOffset  : 0x%" PRIx64 "\n", context->thRdTexMemOffset);
        API_TRACE_FUNCTION(3, "    texHeaderPoolVA   : 0x%" PRIx64 "\n", context->texHeaderPoolVA);
        API_TRACE_FUNCTION(3, "    texSamplerPoolVA  : 0x%" PRIx64 "\n", context->texSamplerPoolVA);
        API_TRACE_FUNCTION(3, "    funcMemBaseVA     : 0x%" PRIx64 "\n", context->funcMemBaseVA);
        API_TRACE_FUNCTION(3, "    numFdsTransferred : %d\n", message->cases.ctxCreation.numFdsTransferred);

        /* Set the state of memcheck based on the information from the driver */
        haloSetMemcheckState(haloGlobals.device[devId],
                             message->cases.ctxCreation.memcheckEnabled);
        API_TRACE_FUNCTION(3, "    memcheckEnabled   : %u\n", message->cases.ctxCreation.memcheckEnabled);


        dbgRelocatePendingPatch(ctx, context);
        dbgPrintPatches(context);

        dev = haloGlobals.device[devId];

        /* Set whether preemption debugging is enabled */
        dev->halo.deviceInfo.preemptionType = (HaloPreemptionTypes)message->cases.ctxCreation.preemptionType;
        API_TRACE_FUNCTION(3, "    preemptionType : %u\n", dev->halo.deviceInfo.preemptionType);

        /* If fd's were sent, record them in the ctx */
        if (message->cases.ctxCreation.numFdsTransferred) {
            nfds = message->cases.ctxCreation.numFdsTransferred;
            API_TRACE_FUNCTION(3, "numFdsTransferred: %d\n", message->cases.ctxCreation.numFdsTransferred);
            /* No pipes are used when generating a coredump */
            if (cudbgIsCoredumpInProgress()) {
                fdArray = (int *)malloc(sizeof(int) * nfds);
                if (!fdArray) {
                    CUDBG_ERROR("dbgCtxCreate: Failed to allocate memory for fdArray!\n");
                    return CUDBG_ERROR_UNKNOWN;
                }

                res = popMessage(&p, fdArray, sizeof(int) * nfds);
                if (res != CUDBG_SUCCESS) {
                    CUDBG_ERROR("Failed to pop message\n");
                    return res;
                }
            }
            else {
                res = cudbgPipeControlMessageRead(&applicationToDispatcher, &fdArray);
                if (res != CUDBG_SUCCESS) {
                    CUDBG_ERROR("dbgCtxCreate: Failed to read control data\n");
                    return res;
                }
            }

            API_TRACE_FUNCTION(3, "Completed reading channelfds\n");
            /* First fd is the debugObject, for compat */
            if (dev->dmal->type == HALO_DMAL_TYPE_MRM) {
                context->fdArray[CUDBG_FD_NVHOST_GR3D] = *fdArray++;
                nfds--;
            }
            API_TRACE_FUNCTION(3, "Copying over fds to channelfd nfds=%d\n", nfds);
            memcpy(context->channelfds, fdArray, nfds * sizeof(*fdArray));

            /* For sake of compatibility */
            /* TODO: replace this with the TSG fd */
            if (dev->dmal->type == HALO_DMAL_TYPE_MRM)
                context->hComputeObject = context->fdArray[CUDBG_FD_NVHOST_GR3D];

            // Cleanup
            if (cudbgIsCoredumpInProgress()) {
                fdArray--;
                free(fdArray);
            }
        }

        if (dev->dmal->type == HALO_DMAL_TYPE_WDDM) {
            /* WAR: On WDDM, hAppClient does not exist. However, some code uses this field to check for context validity */
            context->hAppClient = 0xdeadbeef;
            context->debugObj.wddm = message->cases.ctxCreation.hDebugObject;
        }
        else if ((dev->dmal->type == HALO_DMAL_TYPE_RM) &&
                 dev->dmal->debugObjectCanBeAllocatedInProcess()) {
            context->debugObj.rm = (uint32_t)message->cases.ctxCreation.hDebugObject;
            context->debugObj.rmClient = context->hAppClient;
        }
        else {
            /* Allocate the debug object */
            API_TRACE_FUNCTION(3, "Allocating the debug object\n");
            res = dev->dmal->debugObjectAlloc(context, context->hAppClient,
                                              context->hComputeObject,
                                              &context->debugObj);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("dbgCtxCreate: Failed to allocate RM Debug Object"
                            " for ctx 0x%016" PRIx64 " \n", ctx);
                return res;
            }
        }

        eventClassType = (uint32_t)globals.devices[dev->deviceIdx]->hal.getConstant(
            dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_CILP ?
            CU_HAL_CONST_CILP_EVENT_INDEX : CU_HAL_CONST_DEBUG_EVENT_INDEX);

        res = context->dev->dmal->debugObjectAllocEvent(context->dev, context->debugObj,
                                                       eventClassType,
                                                       &context->event,
                                                       &context->hDebugEvent);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("dbgCtxCreate: Failed to allocate a debug event"
                        " for ctx 0x%016" PRIx64 " \n", ctx);
            return res;
        }

        if (dev->dmal->type == HALO_DMAL_TYPE_MRM) {
            context->fdArray[CUDBG_FD_NVHOST_DBG_GPU] = context->debugObj.mrm;
        }

        /* These are not needed when generating coredumps */
        if (!cudbgIsCoredumpInProgress()) {
            /* These calls can only be made once the fds are setup above, otherwise
             * we won't be able to make any regops calls on mobile platforms. */
            res = context->dev->halo.enableMMUDebuggingMode(context);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to enable MMU Debug Mode\n");

            res = context->dev->halo.disablePairingMode(context->dev, context);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to disable pairing mode\n");
        }

        if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_CILP) {
            res = dev->dmal->debugObjectSetNextStopTriggerType(dev, context->debugObj, 2);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                         "Failed to set next stop trigger\n");
        }

        break;
    }

    case dbgCtxDestructionBegin: {
        Context context;
        context = haloStateGetContext(message->cases.ctxDestructionBegin.ctx);

        if (!context) {
            API_TRACE_FUNCTION(1, "dbgCtxDestructionBegin. No match for ctx 0x%016" PRIx64 " "
                               "Possibly tearing down before the context fully initialized.\n",
                               message->cases.ctxDestructionBegin.ctx);
            break;
        }

        /* If preemption is enabled, we need to ensure that the context has its channels
           restored.
        */
        if (context->dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_KILP) {
            gpudbgPreemptState preemptState;
            preemptState.deviceIdx = context->dev->deviceIdx;
            res =  preemptRestoreChannelGroupForContext(context, &preemptState);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to restore channels\n");
        }

        API_TRACE_FUNCTION(1, "dbgCtxDestructionBegin of ctx:0x%016" PRIx64 " (device %x)\n",
                           message->cases.ctxDestructionBegin.ctx,
                           context->dev->deviceIdx);

        res = haloStateContextSetState(context, HALO_CTX_STATE_FINALIZING);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to set context finalizing\n");
    }
    break;
    case dbgCtxDestructionEnd: {
        Context context;
        uint32_t tid = message->cases.ctxDestructionEnd.threadId;

        context = haloStateGetContext(message->cases.ctxDestructionEnd.ctx);

        /* Note:  It is possible to not have a context here.  This can happen if
           the driver tears down in the middle of creating a context.  Simply
           bail here, as there is nothing to report to the client. */
        if (!context) {
            API_TRACE_FUNCTION(1, "dbgCtxDestructionEnd, no match for ctx 0x%016" PRIx64 " "
                               "Possible teardown before full initialization?\n",
                               message->cases.ctxDestructionEnd.ctx);
            break;
        }

        API_TRACE_FUNCTION(1, "dbgCtxDestructionEnd (device %x)\n", context->dev->deviceIdx);

        /* At this point, notify the frontend about the context destroy event.
           This must happen in the DestructionEnd callback as the context
           will be unloading modules and send ELF_IMAGE_UNLOAD events
           in the meantime.
        */
        if (clientRevision >= API_REVISION_3_2) {
            gpudbgEventsGetAvailable(&event, GPUDBG_EVENT_SYNC);
            event->kind = CUDBG_EVENT_CTX_DESTROY;
            event->cases.contextDestroy.dev = context->dev->deviceIdx;
            event->cases.contextDestroy.context = context->cuCtx;
            event->cases.contextDestroy.tid = tid;
            *requiresDebuggerAck = true;
            *hostThreadId = context->hostThreadId;
        }

        res = deleteContext(context, true);
        if (res != CUDBG_SUCCESS)
            CUDBG_TRACE("Call to deleteContext failed when processing dbgCtxDestruction.\n");
        break;
    }

    case dbgCtxPush: {
        Context  context;

        context = haloStateGetContext(message->cases.ctxPush.ctx);
        /* We may see push messages before create messages,
           meaning the context may not be known to us, return
           CUDBG_SUCCESS if this is the case. bug 1807215
        */
        if (context == NULL) {
            CUDBG_TRACE("Invalid context %" PRIx64 " when processing dbgCtxPush, returning SUCCESS.\n", message->cases.ctxPush.ctx);
            return CUDBG_SUCCESS;
        }

        context->hostThreadId = message->cases.ctxPush.threadId;

        API_TRACE_FUNCTION(1, "ctxPush to host thread %" PRIx64 " (device %x)\n",
                           context->hostThreadId, context->dev->deviceIdx);

        if (clientRevision >= API_REVISION_3_2) {
            gpudbgEventsGetAvailable(&event, GPUDBG_EVENT_SYNC);
            event->kind = CUDBG_EVENT_CTX_PUSH;
            event->cases.contextPush.dev = context->dev->deviceIdx;
            event->cases.contextPush.context = context->cuCtx;
            event->cases.contextPush.tid = context->hostThreadId;
            *requiresDebuggerAck = true;
            *hostThreadId = context->hostThreadId;
        }

        break;
    }

    case dbgCtxPop: {
        Context context;

        context = haloStateGetContext(message->cases.ctxPop.ctx);
        CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context when processing dbgCtxPop.\n");

        context->hostThreadId = message->cases.ctxPop.threadId;

        API_TRACE_FUNCTION(1, "ctxPop from host thread %" PRIx64 " (device %x)\n",
                           context->hostThreadId, context->dev->deviceIdx);

        if (clientRevision >= API_REVISION_3_2) {
            gpudbgEventsGetAvailable(&event, GPUDBG_EVENT_SYNC);
            event->kind = CUDBG_EVENT_CTX_POP;
            event->cases.contextPop.dev = context->dev->deviceIdx;
            event->cases.contextPop.context = context->cuCtx;
            event->cases.contextPop.tid = context->hostThreadId;
            *requiresDebuggerAck = true;
            *hostThreadId = context->hostThreadId;
        }

        break;
    }

    case dbgRegisterModule : {
        DeviceModule module;
        uint64_t ctx = message->cases.registerModule.ctx;
        Context context = haloStateGetContext(ctx);
        uint32_t devId = message->cases.registerModule.devId;
        uint32_t tid = message->cases.registerModule.threadId;
        bool internal = message->cases.registerModule.internal;
        CUmodVisibility cuVisibility = (CUmodVisibility)message->cases.registerModule.visibility;
        bool launchBlocking = message->cases.registerModule.launchBlocking;
        bool hidden = !!(cuVisibility);
        DeviceModuleType_t visibility;

        /* If no context yet, create a pending context. The missing information
           will be added later when we received the context creation
           message. */
        if (!context) {
            context = gpudbgCreateContext(ctx, devId, tid, launchBlocking,
                                          requiresDebuggerAck, hostThreadId,
                                          ~0ULL,
                                          ~0ULL,
                                          CUDBG_INVALID_HANDLE,
                                          CUDBG_INVALID_HANDLE,
                                          CUDBG_INVALID_HANDLE,
                                          NULL, 0);
            if (!context) {
                CUDBG_ERROR("Context creation failed.\n");
                return CUDBG_ERROR_INVALID_CONTEXT;
            }
        }
        else {
            module = (DeviceModule)toolsHashMapFind(context->modules, tHashMapNumToKey(message->cases.registerModule.handle));
            if (module) {
                API_TRACE_FUNCTION(1, "RegisterModule\n");
                API_TRACE_FUNCTION(3, "    Skipping duplicate register module for : %s (key:0x%" PRIx64 ")\n",
                                   module->name, message->cases.registerModule.handle);
                break;
            }
        }

        /* Set the abiVersion to zero as it will not be written until later */
        res = haloStateCreateModule(&module, context, message->cases.registerModule.handle, 0);
        if (res != CUDBG_SUCCESS)
            return res;

        module->stringTable = (char *)malloc((size_t)message->cases.registerModule.stringTableSize);
        if (module->stringTable == NULL) {
            CUDBG_ERROR("Failed to allocate string table!\n");
            deleteModule(module, false);
            return CUDBG_ERROR_OS_RESOURCES;
        }

        res = popMessage(&p, (void*)module->stringTable, message->cases.registerModule.stringTableSize);
        if (res != CUDBG_SUCCESS) {
            deleteModule(module, false);
            return res;
        }

        module->functions = toolsHashMapNew(toolsUint32HashFun, toolsUint64EqualFun, 8);
        if (module->functions == NULL) {
            CUDBG_ERROR("Failed to create hash map!\n");
            deleteModule(module, false);
            return CUDBG_ERROR_UNKNOWN;
        }

        module->internal = internal;
        module->hidden = hidden;

        res = gpudbgGetModuleType(cuVisibility, &visibility);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("gpudbgGetModuleType failed\n");
            deleteModule(module, false);
            return res;
        }

        module->visibility = visibility;
        module->name = module->stringTable + message->cases.registerModule.nameIndex;

        tres = toolsHashMapInsert(context->modules, tHashMapNumToKey(module->cuModule), (void*)module);
        if (tres != TOOLS_SUCCESS) {
            CUDBG_ERROR("Failed to insert into context->modules map. (tres=%u)\n", tres);
            deleteModule(module, true);
            return CUDBG_ERROR_UNKNOWN;
        }

        API_TRACE_FUNCTION(1, "RegisterModule %p\n", module);
        API_TRACE_FUNCTION(3, "    module name  : %s\n", module->name);
        API_TRACE_FUNCTION(3, "    device       : %u\n", devId);
        API_TRACE_FUNCTION(3, "    cuCtx        : 0x%" PRIx64 "\n", ctx);
        API_TRACE_FUNCTION(3, "    internal     : %s\n", internal ? "yes" : "no");
        API_TRACE_FUNCTION(3, "    hidden       : %s\n", hidden ? "yes" : "no");
        API_TRACE_FUNCTION(3, "    visibility   : %d\n", module->visibility);
        break;
    }

    case dbgUnregisterModule : {
        DeviceModule module;
        uint64_t ctx = message->cases.unregisterModule.ctx;
        Context context = haloStateGetContext(ctx);

        if (!context) {
            API_TRACE_FUNCTION(1, "UnregisterModule\n");
            API_TRACE_FUNCTION(3, "  No context found. (Likely due to race in attach)\n");
            break;
        }

        module = (DeviceModule)toolsHashMapFind(context->modules, tHashMapNumToKey(message->cases.unregisterModule.module));
        if (!module) {
            API_TRACE_FUNCTION(1, "UnregisterModule\n");
            API_TRACE_FUNCTION(3, "  No module found. (Likely due to race in attach)\n");
            break;
        }

        API_TRACE_FUNCTION(1, "UnregisterModule\n");
        API_TRACE_FUNCTION(3, "    module name  : %s\n", module->name);
        API_TRACE_FUNCTION(3, "    cuCtx        : 0x%" PRIx64 "\n", ctx);
        API_TRACE_FUNCTION(3, "    internal     : %s\n", module->internal ? "yes" : "no");
        API_TRACE_FUNCTION(3, "    hidden       : %s\n", module->hidden ? "yes" : "no");

        deleteModule(module, true);

        break;
    }

    case dbgRegisterFunction : {
        DeviceFunction     function = NULL;
        DeviceModule       module;
        bool               global;
        bool               hidden;
        bool               usesCnp = message->cases.registerFunction.usesCnp;
        bool               usesContinuations = message->cases.registerFunction.usesContinuations;
        bool               isCnpCtxSync = message->cases.registerFunction.isCnpCtxSync;
        bool               needsHostResume = message->cases.registerFunction.needsHostResume;
        DebugPatch         patch;
        uint32_t           patchKind = 0;
        CudbgStepResumeType stepResumeType = CUDBG_STEP_RESUME_TYPE_WARP;
        uint32_t           numTexIdMapEntries = message->cases.registerFunction.numTexIdMapEntries;
        TexIdMap           *texIdMap = NULL;

        uint64_t           ctx = message->cases.registerFunction.ctx;
        Context            context = haloStateGetContext(ctx);

        /* First, read the texture relocs from the pipe/message. Will have to manually
           free on error until haloStateDestroyFunction() can be called.
        */
        if (numTexIdMapEntries > 0) {
            texIdMap = (TexIdMap *)calloc(numTexIdMapEntries, sizeof(TexIdMap));
            if (texIdMap == NULL) {
                CUDBG_ERROR("Failed to allocate texIdMap memory (numTexIdMapEntries=%u)\n", numTexIdMapEntries);
                return CUDBG_ERROR_OS_RESOURCES;
            }
            res = popMessage(&p, texIdMap, numTexIdMapEntries * sizeof(TexIdMap));
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Failed to read texIdMap entries\n");
                free(texIdMap);
                return res;
            }
        }

        if (context == NULL) {
            CUDBG_ERROR("Could not find context in register function\n");
            if (texIdMap != NULL)
                free(texIdMap);
            return CUDBG_ERROR_INVALID_CONTEXT;
        }

        module = (DeviceModule)toolsHashMapFind(context->modules, tHashMapNumToKey(message->cases.registerFunction.module));
        if (module == NULL) {
            CUDBG_ERROR("Invalid module when processing dbgRegisterFunction.\n");
            if (texIdMap != NULL)
                free(texIdMap);
            return CUDBG_ERROR_INVALID_MODULE;
        }

        /* When attaching, the driver can resend notifications for modules and functions
           Instead of preventing these duplicate notifications, we perform an early check here
           to ensure this is a duplicate, and if so, ignore it.
         */
        function = (DeviceFunction)toolsRangeMapLookupByAddr(
                virtAddrToFunction, message->cases.registerFunction.virtAddrBase);
        if (function &&
            function->cuFunction == message->cases.registerFunction.handle) {
            API_TRACE_FUNCTION(1, "RegisterFunction\n");
            API_TRACE_FUNCTION(3, "  Received duplicate notification for function %s.\n",
                               function->name);
            if (texIdMap != NULL)
                free(texIdMap);
            break;
        }

        res = haloStateCreateFunction(&function, module, message->cases.registerFunction.gpuAddrBase,
                                      usesCnp, usesContinuations);
        if (res != CUDBG_SUCCESS) {
            if (texIdMap != NULL)
                free(texIdMap);
            return res;
        }

        if (isCnpCtxSync) {
            stepResumeType = CUDBG_STEP_RESUME_TYPE_DEVICE;
            function->isCnpCtxSync = true;
        }

        function->needsHostResume = needsHostResume;

        global = message->cases.registerFunction.global;
        hidden = message->cases.registerFunction.hidden;

        if (hidden)
            ++module->hiddenFunctionCount;
        else
            ++module->userFunctionCount;

        if (module->hidden) {
            switch (module->visibility) {
                case DEV_MOD_TYPE_MEMBAR_WAR:
                    patchKind = CUDBG_PATCH_MEMBAR_WAR;
                    function->type = DEV_FUNC_TYPE_DRIVER_PATCH;
                    break;
                case DEV_MOD_TYPE_BARSYNC_WAR:
                    patchKind = CUDBG_PATCH_BAR_WAR;
                    function->type = DEV_FUNC_TYPE_DRIVER_PATCH;
                    break;
                case DEV_MOD_TYPE_LDC_WAR:
                    patchKind = CUDBG_PATCH_LDC_WAR;
                    function->type = DEV_FUNC_TYPE_DRIVER_PATCH;
                    break;
                case DEV_MOD_TYPE_HIDDEN_USER:
                    patchKind = 0;
                    function->type = global ? DEV_FUNC_TYPE_GLOBAL : DEV_FUNC_TYPE_DEVICE;
                    break;
                default:
                    if (global) {
                        function->type = DEV_FUNC_TYPE_GLOBAL_SYSCALL;
                        patchKind = CUDBG_PATCH_GLOBAL_SYSCALL;
                    }
                    else {
                        function->type = DEV_FUNC_TYPE_SYSCALL;
                        patchKind = CUDBG_PATCH_SYSCALL;
                    }
                    break;
            }
        }
        else {
            if (global)
                function->type = DEV_FUNC_TYPE_GLOBAL;
            else
                function->type = DEV_FUNC_TYPE_DEVICE;
        }

        function->cuFunction       = message->cases.registerFunction.handle;
        function->virtAddrBase     = message->cases.registerFunction.virtAddrBase;
        function->codeSize         = message->cases.registerFunction.codeSize;
        function->spAssignmentAddr = message->cases.registerFunction.spAssignmentAddr;
        function->nrofRegisters    = message->cases.registerFunction.nrofRegisters;
        function->stackSize        = message->cases.registerFunction.stackSize;
        function->frameSize        = message->cases.registerFunction.frameSize;
        function->localSize        = message->cases.registerFunction.localSize;
        function->sharedSize       = message->cases.registerFunction.sharedSize;
        function->texRefCount      = message->cases.registerFunction.texRefCount;
        function->name             = function->module->stringTable + message->cases.registerFunction.nameIndex;
        function->hidden           = hidden;

        function->numTexIdMapEntries = message->cases.registerFunction.numTexIdMapEntries;
        function->texIdMap           = texIdMap;

        function->relatedFunction  = NULL;
        function->devVAddr         = message->cases.registerFunction.devVAddr;

        tres = toolsHashMapInsert(module->functions, tHashMapNumToKey(function->cuFunction), (void*)function);
        if (tres != TOOLS_SUCCESS) {
            haloStateDestroyFunction(function);
            CUDBG_ERROR("Failed to insert into module->functions (tres=%u)\n", tres);
            return CUDBG_ERROR_UNKNOWN;
        }

        function->breakPoints = toolsHashMapNew(toolsUint32HashFun, toolsUint64EqualFun, 16);
        CUDBG_VERIFY(function->breakPoints, CUDBG_ERROR_UNKNOWN, "Failed to create breakpoint map\n");

        tres = toolsRangeMapInsertByRange(virtAddrToFunction, function->virtAddrBase, function->codeSize, (void*)function);
        CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_UNKNOWN, "Failed to insert into virtAddrToFunction (tres=%u)\n", tres);

        /* For old broken clients, update the old broken map */
        if (clientRevision <= API_REVISION_5_5) {
            res = updateBrokenVirtAddrMap(function);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to update broken map for old client\n");
        }

        /* CNP: The context might not exist already so we would need to create a dummy context */
        CUDBG_VERIFY(module->context, CUDBG_ERROR_INVALID_CONTEXT,
                     "Module doesn't have a context when processing dbgRegisterFunction");
        tres = toolsRangeMapInsertByRange(module->context->gpuAddrToFunction,
                                          function->gpuAddrBase, function->codeSize,
                                          (void*)function);
        CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_UNKNOWN, "Failed to insert function into map. (tres=%u)\n", tres);

        if (message->cases.registerFunction.prologueSize > 0) {
            /* Construct a dummy function for the prologue */
            DeviceFunction prologue;
            uint64_t prologue_start, prologue_size;

            prologue_start  = message->cases.registerFunction.prologueOffset + function->gpuAddrBase;
            prologue_size   = message->cases.registerFunction.prologueSize;

            res = haloStateCreateFunction(&prologue, module, prologue_start, false, false);
            if (res != CUDBG_SUCCESS)
                return res;

            /* The prologue function points to the kernel function.
               The kernel function points to the prologue. */
            prologue->type            = DEV_FUNC_TYPE_PROLOGUE;
            prologue->relatedFunction = function;

            function->relatedFunction = prologue;

            prologue->devVAddr        = message->cases.registerFunction.prologueDevVAddr;

            /* The prologue aliases for all functions within the memblock. So, always check if
               it is already in the map before adding it  */
            if (!toolsRangeMapLookupByAddr(module->context->gpuAddrToFunction, prologue_start)) {
                tres = toolsRangeMapInsertByRange(module->context->gpuAddrToFunction,
                                                  prologue_start,
                                                  prologue_size,
                                                  prologue);
                CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_UNKNOWN, "Failed to insert function into map. (tres=%u)\n", tres);
            }
        }

        API_TRACE_FUNCTION(1, "RegisterFunction %p\n", function);
        API_TRACE_FUNCTION(3, "    function name  : %s\n", function->name);
        API_TRACE_FUNCTION(3, "    module name    : %s (%#" PRIx64 ")\n", module->name, module);
        API_TRACE_FUNCTION(3, "    type           : %d\n", function->type);
        API_TRACE_FUNCTION(3, "    hidden         : %d\n", function->hidden);
        API_TRACE_FUNCTION(3, "    cuFunction     : 0x%" PRIx64 "\n", function->cuFunction);
        API_TRACE_FUNCTION(3, "    gpuAddrBase    : 0x%" PRIx64 "\n", function->gpuAddrBase);
        API_TRACE_FUNCTION(3, "    gpuAddrEnd     : 0x%" PRIx64 "\n", function->gpuAddrBase + function->codeSize);
        API_TRACE_FUNCTION(3, "    virtAddrBase   : 0x%" PRIx64 "\n", function->virtAddrBase);
        API_TRACE_FUNCTION(3, "    codeSize       : 0x%" PRIx64 "\n", function->codeSize);
        API_TRACE_FUNCTION(3, "    spAssignAddr   : 0x%" PRIx64 "\n", function->spAssignmentAddr);
        API_TRACE_FUNCTION(3, "    stackSize      : 0x%08x\n", function->stackSize);
        API_TRACE_FUNCTION(3, "    frameSize      : 0x%08x\n", function->frameSize);

        if (module->hidden) {
            API_TRACE_FUNCTION(3, "    syscall        : global %u codeSize %u gpuAddrBase 0x%08x virtAddrBase 0x%016x\n",
                               global, function->codeSize,
                               function->gpuAddrBase, function->virtAddrBase);
            patch = dbgCreatePatch(patchKind, function->gpuAddrBase,
                                   (uint32_t)function->codeSize,
                                   function->devVAddr,
                                   true,
                                   function->virtAddrBase, 1,
                                   module->context, 0, stepResumeType);

            res = dbgAddPatch(patch, NULL);
            if (res != CUDBG_SUCCESS) {
                (void)dbgRemovePatch(patch);
                dbgDestroyPatch(patch);
                return res;
            }

            API_TRACE_FUNCTION(1, "dbgRegisterFunction: Syscall Patch\n");
            dbgPrintPatch(patch);
        }
        break;
    }

    case dbgUnregisterFunction : {
        DeviceFunction     function = NULL;
        DeviceModule       module;
        uint64_t           ctx = message->cases.unregisterFunction.ctx;
        Context            context = haloStateGetContext(ctx);

        if (!context) {
            API_TRACE_FUNCTION(1, "UnregisterFunction received on unknown context. (Likely race with attach)\n");
            API_TRACE_FUNCTION(3, "    cuFunction     : 0x%" PRIx64 "\n", message->cases.unregisterFunction.function);
            API_TRACE_FUNCTION(3, "    cuMod          : 0x%" PRIx64 "\n", message->cases.unregisterFunction.module);
            API_TRACE_FUNCTION(3, "    cuCtx          : 0x%" PRIx64 "\n", message->cases.unregisterFunction.ctx);
            break;
        }

        module = (DeviceModule)toolsHashMapFind(context->modules, tHashMapNumToKey(message->cases.unregisterFunction.module));
        if (!module) {
            API_TRACE_FUNCTION(1, "UnregisterFunction received on unknown module. (Likely race with attach)\n");
            API_TRACE_FUNCTION(3, "    cuFunction     : 0x%" PRIx64 "\n", message->cases.unregisterFunction.function);
            API_TRACE_FUNCTION(3, "    cuMod          : 0x%" PRIx64 "\n", message->cases.unregisterFunction.module);
            API_TRACE_FUNCTION(3, "    cuCtx          : 0x%" PRIx64 "\n", message->cases.unregisterFunction.ctx);
            break;
        }

        function = (DeviceFunction)toolsHashMapFind(module->functions, tHashMapNumToKey(message->cases.unregisterFunction.function));

        if (!function) {
            API_TRACE_FUNCTION(1, "UnregisterFunction\n");
            API_TRACE_FUNCTION(3, "   Unknown function (possible duplicate removal from detach)\n");
            break;
        }

        API_TRACE_FUNCTION(1, "UnregisterFunction\n");
        API_TRACE_FUNCTION(3, "    function name  : %s\n", function->name);
        API_TRACE_FUNCTION(3, "    module name    : %s\n", module->name);
        API_TRACE_FUNCTION(3, "    cuFunction     : 0x%" PRIx64 "\n", function->cuFunction);
        API_TRACE_FUNCTION(3, "    gpuAddrBase    : 0x%" PRIx64 "\n", function->gpuAddrBase);
        API_TRACE_FUNCTION(3, "    virtAddrBase   : 0x%" PRIx64 "\n", function->virtAddrBase);
        API_TRACE_FUNCTION(3, "    codeSize       : 0x%" PRIx64 "\n", function->codeSize);

        deleteFunction(function, true);
        break;
    }
    case dbgReportDeviceExecutionLaunch : {
        CudbgDevice               dev;
        Context                   context;
        DeviceFunction            function;
        DeviceModule              module;
        Grid                      grid;
        uint64_t                  gridId64;
        bool                      reportLaunch = true;

        gridId64   = message->cases.deviceExecutionLaunch.gridId64;
        context  = haloStateGetContext(message->cases.deviceExecutionLaunch.ctx);

        if (!context) {
            API_TRACE_FUNCTION(1, "ReportDeviceExecutionLaunch on unknown context. (Likely internal kernels from context destroy).\n");
            API_TRACE_FUNCTION(3, "    cuCtx      : 0x%" PRIx64 "\n", message->cases.deviceExecutionLaunch.ctx);
            API_TRACE_FUNCTION(3, "    cuMod      : 0x%" PRIx64 "\n", message->cases.deviceExecutionLaunch.module);
            API_TRACE_FUNCTION(3, "    cuFunc     : 0x%" PRIx64 "\n", message->cases.deviceExecutionLaunch.function);
            API_TRACE_FUNCTION(3, "    gridId     : 0x%" PRIx64 "\n", message->cases.deviceExecutionLaunch.gridId64);

            break;
        }

        CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT,
                     "Invalid context when processing dbgReportDeviceExecutionLaunch\n");

        module = (DeviceModule)toolsHashMapFind(context->modules, tHashMapNumToKey(message->cases.deviceExecutionLaunch.module));
        CUDBG_VERIFY(module, CUDBG_ERROR_INVALID_MODULE,
                     "Invalid module when processing dbgReportDeviceExecutionLaunch\n");

        function = (DeviceFunction)toolsHashMapFind(module->functions,
                                                    tHashMapNumToKey(message->cases.deviceExecutionLaunch.function));
        CUDBG_VERIFY(function,
                     CUDBG_ERROR_UNKNOWN_FUNCTION,
                     "Function not valid when processing dbgReportDeviceExecutionLaunch. Looking for :0x%" PRIx64 "\n", message->cases.deviceExecutionLaunch.function);

        /* bug 608865, save tesla texture WAR parameters in context */
        context->texMem = message->cases.deviceExecutionLaunch.texMem;

        /* save the finalized lmemSizePerSM at this point */
        context->lmemSizePerSM   = message->cases.deviceExecutionLaunch.lmemSizePerSM;

        /* KILP, save addresses to controller data and cta context */
        context->ctaContextIndirectionTableAddr = message->cases.deviceExecutionLaunch.ctaContextIndirectionTableAddr;
        context->kilpControllerDataAddr = message->cases.deviceExecutionLaunch.kilpControllerDataAddr;
        context->kilpCtaIlpEnableTableAddr = message->cases.deviceExecutionLaunch.kilpCtaIlpEnableTableAddr;
        context->kilpCtaStopContinuations = message->cases.deviceExecutionLaunch.kilpCtaStopContinuations;

        CUDBG_VERIFY((context && function->module->context == context),
                     CUDBG_ERROR_INVALID_CONTEXT,
                     "Invalid context when processing dbgReportDeviceExecutionLaunch.\n");

        dev = context->dev;

        if (dev->dmal->type == HALO_DMAL_TYPE_MRM) {
            /* T124_HACK: bug 1435275: This shouldn't be needed here, we already disabled
             * pairing while servicing the context creation callback. But on MRM the context
             * regop at the above site does not seem to be having any effect on pairing state.
             * The call here acts as a WAR till I (mkaushik) figure out why the previous call
             * isn't working. */
            res = context->dev->halo.disablePairingMode(context->dev, context);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to disable pairing mode\n");
        }

        /* If memcheck is turned on, the grid has already been created with a
           dbgReportPatch event. In that case, we only fill up the
           blanks. dbgReportPatch is handled before
           dbgReportDeviceExecutionLaunch because patched code must be handled
           before the insertion of breakpoints (otherwise the breakpoints are
           removed). We should resolve that conundrum when switching to the
           tools API.*/
        grid = haloStateDeviceGetGrid(dev, gridId64);
        if (!grid) {
            res = createGrid(context, &grid, function, gridId64);
            if (res != CUDBG_SUCCESS)
                return res;
        }

        grid->gridDim        = message->cases.deviceExecutionLaunch.gridDim;
        grid->blockDim       = message->cases.deviceExecutionLaunch.blockDim;
        grid->selfQMDdptr    = message->cases.deviceExecutionLaunch.qmdDptr;
        grid->hostStreamId   = message->cases.deviceExecutionLaunch.streamId;

        API_TRACE_FUNCTION(1, "ReportDeviceExecutionLaunch\n");
        API_TRACE_FUNCTION(3, "    kernel name     : %s\n", function->name);
        API_TRACE_FUNCTION(3, "    module name     : %s\n", function->module->name);
        API_TRACE_FUNCTION(3, "    device          : %u\n", context->dev->deviceIdx);
        API_TRACE_FUNCTION(3, "    grid id         : %" PRId64 "\n", grid->gridId64);
        API_TRACE_FUNCTION(3, "    stream id       : %" PRId64 "\n", grid->hostStreamId);
        API_TRACE_FUNCTION(3, "    start offset    : 0x%016" PRIx64 "\n", function->gpuAddrBase);
        API_TRACE_FUNCTION(3, "    scratchpadDevVA : 0x%016" PRIx64 "\n", context->scratchpadDevVA);
        API_TRACE_FUNCTION(3, "    scratchpadDevPtr: 0x%016" PRIx64 "\n", context->scratchpadDevPtr);

        dbgPrintPatches(context);

        context->funcMemBaseVA  = message->cases.deviceExecutionLaunch.funcMemBaseVA;
        context->memMapActive = true;

        dev->haloClient->unmapMemory(dev);

        /* Must have dev->memmap and function->grids up-to-date before inserting breakpoints */
        res = insertBreakpoints(dev, false);
        if (res != CUDBG_SUCCESS)
            CUDBG_TRACE("Call to insertBreakpoints failed when processing gpudbgReportDeviceExecutionLaunch.\n");

        /* Figure out if the launch should be posted */
        reportLaunch = (!function->module->hidden) || cudbgEnableInternalDebugging;

        if ((clientRevision >= API_REVISION_4_0 && reportLaunch) &&
            context->launchNotifyState != CUDBG_NOTIFY_NONE) {
            gpudbgEventKind_t eventKind = GPUDBG_EVENT_SYNC;
            /* If launch notification policy for context kernel is launching in is set to
               ASYNC, put launch notification into async queue, otherwise in sync queue.
               If launchNotifyState is set to SYNC_FIRST then this launch would be report
               synchronously, but all subsequent launches asynchronously */

            gpudbgEventsGetAvailable(&event, eventKind);
            event->kind = CUDBG_EVENT_KERNEL_READY;
            event->cases.kernelReady.dev = dev->deviceIdx;
            event->cases.kernelReady.gridId = grid->gridId64;
            event->cases.kernelReady.tid = context->hostThreadId;
            event->cases.kernelReady.context = context->cuCtx;
            event->cases.kernelReady.module = function->module->cuModule;
            event->cases.kernelReady.function = function->cuFunction;
            event->cases.kernelReady.functionEntry = function->virtAddrBase;
            event->cases.kernelReady.gridDim = grid->gridDim;
            event->cases.kernelReady.blockDim = grid->blockDim;
            event->cases.kernelReady.type = function->module->internal ? CUDBG_KNL_TYPE_SYSTEM : CUDBG_KNL_TYPE_APPLICATION;
            event->cases.kernelReady.parentGridId = grid->parentGridId64;
            event->cases.kernelReady.origin = grid->origin;
            if (eventKind == GPUDBG_EVENT_SYNC) {
                *requiresDebuggerAck = true;
                *hostThreadId = context->hostThreadId;
            }

            if (context->launchNotifyState == CUDBG_NOTIFY_SYNC_FIRST_ONLY)
                context->launchNotifyState = CUDBG_NOTIFY_NONE;
            /* Indicate this grid has been posted */
            grid->state = HALO_GRID_STATE_POSTED;

            API_TRACE_FUNCTION(5, "    Notified frontend. New context->LaunchNotifyState:%u\n", context->launchNotifyState);
        }
        else {
            grid->state = HALO_GRID_STATE_UNPOSTED;
            API_TRACE_FUNCTION(5, "    NOT NOTIFYING frontend. \n");
        }

        break;
    }

    case dbgReportDeviceExecutionStop: {
        DeviceFunction  function;
        DeviceModule module;
        CUDBGEvent *event;
        CudbgDevice dev;
        Context context;
        Grid grid;
        uint64_t gridId64;

        gridId64 = message->cases.deviceExecutionStop.gridId64;

        context  = haloStateGetContext(message->cases.deviceExecutionStop.ctx);
        CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT,
                     "Invalid context when processing dbgReportDeviceExecutionStop\n");

        module = (DeviceModule)toolsHashMapFind(context->modules, tHashMapNumToKey(message->cases.deviceExecutionStop.module));
        CUDBG_VERIFY(module, CUDBG_ERROR_INVALID_MODULE,
                     "Invalid module when processing dbgReportDeviceExecutionStop\n");

        function = (DeviceFunction)toolsHashMapFind(module->functions,
                                                    tHashMapNumToKey(message->cases.deviceExecutionStop.function));

        CUDBG_VERIFY((function && function->module && function->module->context && function->module->context->dev),
                     CUDBG_ERROR_UNKNOWN_FUNCTION,
                     "Function not valid when processing dbgReportDeviceExecutionStop.\n");

        dev     = context->dev;
        grid    = haloStateDeviceGetGrid(dev, gridId64);

        CUDBG_VERIFY(grid, CUDBG_ERROR_INVALID_GRID, "Invalid grid when processing dbgReportDeviceExecutionStop.\n");

        res = removeBreakpoints(dev);
        if (res != CUDBG_SUCCESS)
            CUDBG_TRACE("Call to removeBreakpoints failed when processing gpudbgReportDeviceExecutionStop.\n");

        API_TRACE_FUNCTION(1, "ReportDeviceExecutionStop\n");
        API_TRACE_FUNCTION(3, "    kernel name  : %s\n", function->name);
        API_TRACE_FUNCTION(3, "    device       : %u\n", dev->deviceIdx);
        API_TRACE_FUNCTION(3, "    grid id      : %" PRId64 "\n", gridId64);

        if ((clientRevision >= API_REVISION_4_0 || !function->module->internal) &&
            context->launchNotifyState != CUDBG_NOTIFY_NONE) {
            gpudbgEventKind_t eventKind = GPUDBG_EVENT_SYNC;

            gpudbgEventsGetAvailable(&event, eventKind);
            event->kind = CUDBG_EVENT_KERNEL_FINISHED;
            event->cases.kernelFinished.dev = dev->deviceIdx;
            event->cases.kernelFinished.gridId = grid->gridId64;
            event->cases.kernelFinished.tid = context->hostThreadId;
            event->cases.kernelFinished.context = context->cuCtx;
            event->cases.kernelFinished.module = function->module->cuModule;
            event->cases.kernelFinished.function = function->cuFunction;
            event->cases.kernelFinished.functionEntry = function->virtAddrBase;
            if (eventKind == GPUDBG_EVENT_SYNC) {
                *requiresDebuggerAck = true;
                *hostThreadId = function->module->context->hostThreadId;
            }

            /* Compute next state */
            if (context->launchNotifyState == CUDBG_NOTIFY_SYNC_FIRST_ONLY)
                context->launchNotifyState = CUDBG_NOTIFY_NONE;
        }

        deleteGrid(grid);

        break;
    }

    case dbgUnloadElfImage : {
        DeviceModule mod;
        Context context;
        CUDBGEvent *event;

        if (clientRevision <= API_REVISION_5_5) {
            API_TRACE_FUNCTION(1, "Client too old for UnloadElfImage. (Client:%u need: >%u)\n",
                               clientRevision, API_REVISION_5_5);
            break;
        }

        context = haloStateGetContext(message->cases.unloadElfImage.ctx);
        if (!context) {
            API_TRACE_FUNCTION(1, "UnloadElfImage received on unknown context. (Likely race with attach)\n");
            API_TRACE_FUNCTION(3, "    cuMod        : 0x" PRIx64 "\n", message->cases.unloadElfImage.mod_handle);
            API_TRACE_FUNCTION(3, "    cuCtx        : 0x" PRIx64 "\n", message->cases.unloadElfImage.ctx);
            break;
        }

        CUDBG_VERIFY(context, CUDBG_SUCCESS, "Invalid context when processing unload ELF image\n");

        mod = (DeviceModule)toolsHashMapFind(context->modules, tHashMapNumToKey(message->cases.unloadElfImage.mod_handle));

        /* Sanity */
        CUDBG_VERIFY((mod && mod->context && mod->context->dev),
                     CUDBG_SUCCESS,
                     "Invalid module when processing dbgUnloadElfImage.\n");

        /* Only send unload events for those modules we sent load events for */

        if (!mod->exported) {
            API_TRACE_FUNCTION(20, "Squashing un-exported module in UnloadElfImage\n");
            API_TRACE_FUNCTION(25, "    module name        : %s\n", mod->name);
            API_TRACE_FUNCTION(25, "    device             : %u\n", mod->context->dev->deviceIdx);
            API_TRACE_FUNCTION(25, "    ABI version        : %u\n", mod->abiVersion);
            API_TRACE_FUNCTION(25, "    elf image size     : 0x%" PRIx64 "\n", mod->elfImageSize);
            API_TRACE_FUNCTION(25, "    relocated addr     : 0x%" PRIx64 "\n", mod->relocatedElfImage);
            API_TRACE_FUNCTION(25, "    non-relocated addr : 0x%" PRIx64 "\n", mod->nonRelocatedElfImage);
            break;
        }

        gpudbgEventsGetAvailable(&event, GPUDBG_EVENT_SYNC);
        event->kind = CUDBG_EVENT_ELF_IMAGE_UNLOADED;
        event->cases.elfImageUnloaded.dev = mod->context->dev->deviceIdx;
        event->cases.elfImageUnloaded.context = mod->context->cuCtx;
        event->cases.elfImageUnloaded.module = mod->cuModule;
        event->cases.elfImageUnloaded.handle = mod->cuModule;
        event->cases.elfImageUnloaded.size = mod->elfImageSize;
        *requiresDebuggerAck = true;
        *hostThreadId = mod->context->hostThreadId;

        API_TRACE_FUNCTION(1, "UnloadElfImage\n");
        API_TRACE_FUNCTION(3, "    module name        : %s\n", mod->name);
        API_TRACE_FUNCTION(3, "    device             : %u\n", mod->context->dev->deviceIdx);
        API_TRACE_FUNCTION(3, "    ABI version        : %u\n", mod->abiVersion);
        API_TRACE_FUNCTION(3, "    elf image size     : 0x%" PRIx64 "\n", mod->elfImageSize);
        API_TRACE_FUNCTION(3, "    relocated addr     : 0x%" PRIx64 "\n", mod->relocatedElfImage);
        API_TRACE_FUNCTION(3, "    non-relocated addr : 0x%" PRIx64 "\n", mod->nonRelocatedElfImage);

        break;
    }

    case dbgExportElfImage: {
        DeviceModule mod;
        Context context;
        CUDBGEvent *event;
        elf64FileHeader *efh64;
        elf32FileHeader *efh32;
        uint32_t showInternalModules = 0;
        uint32_t showSyscallModules = 0;
        uint32_t properties = 0;

        context = haloStateGetContext(message->cases.exportElfImage.ctx);
        CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context when processing export ELF image\n");

        mod = (DeviceModule)toolsHashMapFind(context->modules, tHashMapNumToKey(message->cases.exportElfImage.mod_handle));

        /* Sanity */
        CUDBG_VERIFY((mod && mod->context && mod->context->dev),
                     CUDBG_ERROR_INVALID_MODULE,
                     "Invalid module when processing dbgExportElfImage.\n");

        mod->elfImageSize = message->cases.exportElfImage.elf_image_size;

        mod->relocatedElfImage = malloc((size_t)mod->elfImageSize);
        CUDBG_VERIFY(mod->relocatedElfImage != NULL, CUDBG_ERROR_OS_RESOURCES, "Failed to allocate memory!\n");

        res = popMessage(&p, (void*)mod->relocatedElfImage, mod->elfImageSize);
        if (res != CUDBG_SUCCESS)
            return res;

        mod->nonRelocatedElfImage = malloc((size_t)mod->elfImageSize);
        CUDBG_VERIFY(mod->nonRelocatedElfImage != NULL, CUDBG_ERROR_OS_RESOURCES, "Failed to allocate memory!\n");
        res = popMessage(&p, (void*)mod->nonRelocatedElfImage, mod->elfImageSize);
        if (res != CUDBG_SUCCESS)
            return res;

        /* Locate the module this elf image came from and store a pointer to
         * the image on a per module basis.  This can be used for lookup in
         * the cases that we are dealing with multiple elf images. */
        res = gpudbgRegMapInitialize(mod->relocatedElfImage, &mod->regMap);
        if (res != CUDBG_SUCCESS)
            CUDBG_TRACE("Call to gpudbgRegMapInitialize failed when processing dbgExportElfImage.\n");

        if (elf_is_64bit(mod->relocatedElfImage)) {
            const elf64FileHeader *efh64 = elf64_file_header(mod->relocatedElfImage);
            CUDBG_VERIFY(efh64, CUDBG_ERROR_UNKNOWN, "Call to elf64_file_header failed when processing dbgExportElfImage.\n");

            mod->abiVersion = efh64->abiVersion;
        }
        else {
            const elf32FileHeader *efh32 = elf32_file_header(mod->relocatedElfImage);
            CUDBG_VERIFY(efh32, CUDBG_ERROR_UNKNOWN, "Call to elf32_file_header failed when processing dbgExportElfImage.\n");

            mod->abiVersion = efh32->abiVersion;
        }

#ifndef RELEASE
        /* Only show the internal modules if the user requests internal debug */
        showInternalModules = cudbgEnableInternalDebugging;
        /* Any of the internal debug modes will show the syscall modules */
        showSyscallModules  = cudbgEnableMemcheckDebugging  ||
                              cudbgEnableSyscallDebugging   ||
                              cudbgEnableInternalDebugging;
#endif

        /* Do not export internal modules, except the syscalls
           and their trampolines (retaining these for backward
           compatibility), and modules containing non-hidden functions
         */

        if (!showInternalModules &&
            mod->hidden && mod->visibility != DEV_MOD_TYPE_SYSCALL &&
            mod->visibility != DEV_MOD_TYPE_TRAMPOLINE &&
            mod->visibility != DEV_MOD_TYPE_HIDDEN_USER) {
            API_TRACE_FUNCTION(20, "Squashing internal module %p in ExportElfImage\n", mod);
            API_TRACE_FUNCTION(25, "    module name        : %s\n", mod->name);
            API_TRACE_FUNCTION(25, "    device             : %u\n", mod->context->dev->deviceIdx);
            API_TRACE_FUNCTION(25, "    ABI version        : %u\n", mod->abiVersion);
            API_TRACE_FUNCTION(25, "    elf image size     : 0x%" PRIx64 "\n", mod->elfImageSize);
            API_TRACE_FUNCTION(25, "    relocated addr     : 0x%" PRIx64 "\n", mod->relocatedElfImage);
            API_TRACE_FUNCTION(25, "    non-relocated addr : 0x%" PRIx64 "\n", mod->nonRelocatedElfImage);
            break;
        }

        /* Most of the information in the syscall module in 5.0 was wrong
           anyway. Stop exporting it. */
        if (!showSyscallModules &&
            mod->hidden && (mod->visibility == DEV_MOD_TYPE_SYSCALL ||
                            mod->visibility == DEV_MOD_TYPE_TRAMPOLINE)) {
            API_TRACE_FUNCTION(20, "Squashing syscall module %p in ExportElfImage\n", mod);
            API_TRACE_FUNCTION(25, "    module name        : %s\n", mod->name);
            API_TRACE_FUNCTION(25, "    device             : %u\n", mod->context->dev->deviceIdx);
            API_TRACE_FUNCTION(25, "    ABI version        : %u\n", mod->abiVersion);
            API_TRACE_FUNCTION(25, "    elf image size     : 0x%" PRIx64 "\n", mod->elfImageSize);
            API_TRACE_FUNCTION(25, "    relocated addr     : 0x%" PRIx64 "\n", mod->relocatedElfImage);
            API_TRACE_FUNCTION(25, "    non-relocated addr : 0x%" PRIx64 "\n", mod->nonRelocatedElfImage);
            break;
        }

        /* Cook the ABI version of the syscall module for backward compatibility */
        if (mod->hidden && clientRevision <= API_REVISION_4_2) {
            if (elf_is_64bit(mod->relocatedElfImage)) {
                efh64 = (elf64FileHeader*)elf64_file_header(mod->relocatedElfImage);
                efh64->abiVersion = ELFOSABIV_SYSCALL;
                efh64 = (elf64FileHeader*)elf64_file_header(mod->nonRelocatedElfImage);
                efh64->abiVersion = ELFOSABIV_SYSCALL;
            }
            else {
                efh32 = (elf32FileHeader*)elf32_file_header(mod->relocatedElfImage);
                efh32->abiVersion = ELFOSABIV_SYSCALL;
                efh32 = (elf32FileHeader*)elf32_file_header(mod->nonRelocatedElfImage);
                efh32->abiVersion = ELFOSABIV_SYSCALL;
            }
        }

        /* For the memset and memcpy modules, set the ABI version to 1 for maximum compatibility */
        if (!mod->hidden && mod->internal && clientRevision < API_REVISION_5_5) {
            if (elf_is_64bit(mod->relocatedElfImage)) {
                efh64 = (elf64FileHeader*)elf64_file_header(mod->relocatedElfImage);
                efh64->abiVersion = ELFOSABIV_32BIT;
                efh64 = (elf64FileHeader*)elf64_file_header(mod->nonRelocatedElfImage);
                efh64->abiVersion = ELFOSABIV_32BIT;
            }
            else {
                efh32 = (elf32FileHeader*)elf32_file_header(mod->relocatedElfImage);
                efh32->abiVersion = ELFOSABIV_32BIT;
                efh32 = (elf32FileHeader*)elf32_file_header(mod->nonRelocatedElfImage);
                efh32->abiVersion = ELFOSABIV_32BIT;
            }
        }

        if (mod->internal)
            properties |= CUDBG_ELF_IMAGE_PROPERTIES_SYSTEM;

        /* Note that we've exposed the ELF file/cubin to the debugger */
        mod->exported = true;

        gpudbgEventsGetAvailable(&event, GPUDBG_EVENT_SYNC);
        event->kind = CUDBG_EVENT_ELF_IMAGE_LOADED;
        event->cases.elfImageLoaded.dev = mod->context->dev->deviceIdx;
        event->cases.elfImageLoaded.context = mod->context->cuCtx;
        event->cases.elfImageLoaded.module = mod->cuModule;
        event->cases.elfImageLoaded.handle = mod->cuModule;
        event->cases.elfImageLoaded.size = mod->elfImageSize;
        event->cases.elfImageLoaded.properties = properties;
        *requiresDebuggerAck = true;
        *hostThreadId = mod->context->hostThreadId;

        API_TRACE_FUNCTION(1, "ExportElfImage\n");
        API_TRACE_FUNCTION(3, "    module name        : %s\n", mod->name);
        API_TRACE_FUNCTION(3, "    device             : %u\n", mod->context->dev->deviceIdx);
        API_TRACE_FUNCTION(3, "    ABI version        : %u\n", mod->abiVersion);
        API_TRACE_FUNCTION(3, "    elf image size     : 0x%" PRIx64 "\n", mod->elfImageSize);
        API_TRACE_FUNCTION(3, "    relocated addr     : 0x%" PRIx64 "\n", mod->relocatedElfImage);
        API_TRACE_FUNCTION(3, "    non-relocated addr : 0x%" PRIx64 "\n", mod->nonRelocatedElfImage);
    }
    break;

    case dbgReportPatch: {
        uint64_t cuctx;
        uint32_t kind, size, depth;
        uint64_t origInst[2] = {0};
        uint64_t gpuAddr, entryAddr, virtAddr, devVAddr;
        CudbgDevice dev;
        DebugPatch patch;
        Context context;
        CudbgStepResumeType stepResumeType = CUDBG_STEP_RESUME_TYPE_WARP;
        bool isMultiEntry = false;

        cuctx               = message->cases.reportPatch.context;
        kind                = message->cases.reportPatch.kind;
        gpuAddr             = message->cases.reportPatch.gpuPCOffset;
        size                = message->cases.reportPatch.patchSize;
        entryAddr           = message->cases.reportPatch.patchEntryAddr;
        isMultiEntry        = message->cases.reportPatch.isMultiEntry;
        origInst[0]         = message->cases.reportPatch.origInst[0];
        origInst[1]         = message->cases.reportPatch.origInst[1];
        virtAddr            = message->cases.reportPatch.virtAddr;
        depth               = message->cases.reportPatch.depth;
        devVAddr            = message->cases.reportPatch.devVAddr;

        context = haloStateGetContext(cuctx);

        if (kind == CUDBG_PATCH_BAR_WAR)
            stepResumeType = CUDBG_STEP_RESUME_TYPE_DEVICE;

        patch = dbgCreatePatch(kind, gpuAddr, size, devVAddr, virtAddr,
                               entryAddr, isMultiEntry, context, depth,
                               stepResumeType);

        patch->origInst[0] = origInst[0];
        patch->origInst[1] = origInst[1];

        if (context &&
            ((patch->kind == CUDBG_PATCH_MEMCHECK) ||
             HALO_PATCH_IS_HW_WAR(kind))) {
            CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context when processing dbgReportPatch.\n");

            dev = context->dev;
            /* Patch has only one entrance, and we know the instruction
               This is a memcheck function stub specific patch */
            res = dev->halo.getInstructionSize(patch->origInst[0], &patch->hopSize);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Failed querying instruction size (res=%d)\n", res);
                dbgDestroyPatch(patch);
                return res;
            }

            res = dbgAddPatchEntry(patch->entryAddr, patch);
            if (res != CUDBG_SUCCESS)
                CUDBG_TRACE("Call to dbgAddPatchEntry failed when processing dbgReportPatch.\n");

        }

        if (context) {
            res = dbgAddPatch(patch, NULL);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Failed adding patch (res=%d)\n", res);
                (void)dbgRemovePatch(patch);
                dbgDestroyPatch(patch);
                return res;
            }
        }
        else
            dbgAddPendingPatch(patch, cuctx);

        API_TRACE_FUNCTION(1, "dbgReportPatch\n");
        if (patch)
            dbgPrintPatch(patch);
    }
    break;

    case dbgUnreportPatch: {
        uint64_t cuctx;
        uint64_t gpuAddr, devVAddr;
        DebugPatch patch = NULL;
        Context context = NULL;
        bool insidePatch = false;

        cuctx               = message->cases.unreportPatch.context;
        gpuAddr             = message->cases.unreportPatch.gpuPCOffset;
        devVAddr            = message->cases.unreportPatch.devVAddr;

        context = haloStateGetContext(cuctx);
        if (context) {
            /* Remove from active context map */
            res = haloInPatchRegion(gpuAddr, context, &patch, CUDBG_PATCH_ALL,
                                    &insidePatch, false);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                         "Failed to lookup patch in cuctx:0x%" PRIx64 " at DevVA:0x%" PRIx64 "\n",
                         cuctx, devVAddr);
            if (!insidePatch) {
                /* No patch found, nothing to do. Early return */
                API_TRACE_FUNCTION(1, "dbgUnreportPatch. No patch found in ctx.\n");
                API_TRACE_FUNCTION(3, "     cuctx :0x%" PRIx64 "\n", cuctx);
                API_TRACE_FUNCTION(3, "     kind  :0x%x\n", message->cases.unreportPatch.kind);
                API_TRACE_FUNCTION(3, "     PC    :0x%" PRIx64 "\n", gpuAddr);

                break;
            }
            res = dbgRemovePatch(patch);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                         "Failed to remove patch in cuctx:0x%" PRIx64 " at DevVA:0x%" PRIx64 "\n",
                         cuctx, devVAddr);
        }
        else {
            /* Remove from pending context list */
            res = dbgRemovePendingPatch(cuctx, devVAddr, &patch);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                         "Failed to remove pending patch in cuctx:0x%" PRIx64 " at DevVA:0x%" PRIx64 "\n",
                         cuctx, devVAddr);
        }

        if (patch)
            dbgDestroyPatch(patch);
        API_TRACE_FUNCTION(1, "dbgUnreportPatch\n");
        API_TRACE_FUNCTION(3, "     cuctx :0x%" PRIx64 "\n", cuctx);
        API_TRACE_FUNCTION(3, "     kind  :0x%x\n", message->cases.unreportPatch.kind);
        API_TRACE_FUNCTION(3, "     PC    :0x%" PRIx64 "\n", gpuAddr);
        API_TRACE_FUNCTION(3, "     size  :0x%x\n", message->cases.unreportPatch.patchSize);
        API_TRACE_FUNCTION(3, "     entry :0x%x\n", message->cases.unreportPatch.patchEntryAddr);
        API_TRACE_FUNCTION(3, "     devVA :0x%x\n", devVAddr);
    }
    break;

    case dbgResetFunctionBreakpoints : {
        uint64_t cuctx, cufunc, cumod;
        Context context = NULL;
        DeviceFunction function;
        DeviceModule       module;

        cuctx               = message->cases.resetFunctionBreakpoints.context;
        cumod               = message->cases.resetFunctionBreakpoints.module;
        cufunc              = message->cases.resetFunctionBreakpoints.function;

        context = haloStateGetContext(cuctx);
        if (!context) {
            /* Possible under attach. Ignore */
            API_TRACE_FUNCTION(1, "dbgResetFunctionBreakpoints\n");
            API_TRACE_FUNCTION(3, "     Cannot find context 0x%" PRIx64 "\n", cuctx);
            break;
        }

        module = (DeviceModule)toolsHashMapFind(context->modules, tHashMapNumToKey(cumod));
        CUDBG_VERIFY(module, CUDBG_ERROR_INVALID_MODULE, "Invalid module when processing dbgResetFunctionBreakpoints.\n");

        function = (DeviceFunction)toolsHashMapFind(module->functions, tHashMapNumToKey(cufunc));
        CUDBG_VERIFY(function, CUDBG_ERROR_UNKNOWN_FUNCTION, "Invalid function when processing dbgResetFunctionBreakpoints\n");

        /* Reset the host function state */
        res = resetFunctionBreakpoints(function);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to reset function breakpoints for cufunc:0x%" PRIx64 "\n", cufunc);

        res = insertBreakpoints(context->dev, false);
        if (res != CUDBG_SUCCESS) {
            API_TRACE_FUNCTION(5, "  Ignoring error on insert breakpoints\n");
            res = CUDBG_SUCCESS;
        }

        API_TRACE_FUNCTION(1, "dbgResetFunctionBreakpoints\n");
        API_TRACE_FUNCTION(3, "     Context  :  0x%" PRIx64 "\n", cuctx);
        API_TRACE_FUNCTION(3, "     Module   :  0x%" PRIx64 "\n", cumod);
        API_TRACE_FUNCTION(3, "     Function :  0x%" PRIx64 "\n", cufunc);
    }
    break;

    case dbgSetDebuggerAttachState: {
        bool attachInProgress = message->cases.setDebuggerAttachState.attachInProgress;

        /*  This message is only sent at attach start or finish */
        if (attachInProgress)
            haloGlobals.state->attachState = HALO_ATTACH_STATE_IN_PROGRESS;
        else
            haloGlobals.state->attachState = HALO_ATTACH_STATE_COMPLETE;

        if (attachInProgress)
            API_TRACE_FUNCTION(1, "SetDebuggerAttachState: Attach started\n");
        else
            API_TRACE_FUNCTION(1, "SetDebuggerAttachState: Attach complete\n");

        if (!attachInProgress) {
            gpudbgEventsGetAvailable(&event, GPUDBG_EVENT_SYNC);
            event->kind = CUDBG_EVENT_ATTACH_COMPLETE;
            *requiresDebuggerAck = true;
            *hostThreadId = 0;
        }
    }
    break;

    case dbgDetachComplete:
        if (haloGlobals.state->attachState == HALO_ATTACH_STATE_DETACHING) {
            API_TRACE_FUNCTION(1, "dbgDetachComplete\n");

            gpudbgEventsGetAvailable(&event, GPUDBG_EVENT_SYNC);
            event->kind = CUDBG_EVENT_DETACH_COMPLETE;
            *requiresDebuggerAck = true;
            *hostThreadId = 0;
        }
        break;
    case dbgRpcInitEvent:
        API_TRACE_FUNCTION(1, "Sending init event (RPCD)!\n");

        /* The initialization event is simply a timeout event
           (which we also use as a heartbeat). */
        gpudbgEventsGetAvailable(&event, GPUDBG_EVENT_SYNC);
        event->kind = CUDBG_EVENT_TIMEOUT;
        *requiresDebuggerAck = true;
        *hostThreadId = 0;
        break;

    case dbgMemblockAlloc: {
        uint64_t ctx        = message->cases.memblockAlloc.segInfo.ctx;
        uint32_t devId      = message->cases.memblockAlloc.devId;
        uint32_t tid        = message->cases.memblockAlloc.threadId;
        bool launchBlocking = message->cases.memblockAlloc.launchBlocking;
#if cuosOsIsQnx()
        uint32_t memHandleId = message->cases.memblockAlloc.memHandleId;
#endif
        Context context;
        haloMemoryMap *memMap = NULL;
        int32_t parentFd = -1;
        uint32_t newHandle;
        CudbgDevice dev = haloGlobals.device[devId];

        if (ctx) {
            context = haloStateGetContext(ctx);
            if (!context) {
                /* This can legally happen for callbacks from allocations that
                   happen early in the process.
                */
                context = gpudbgCreateContext(ctx, devId, tid, launchBlocking,
                                              requiresDebuggerAck, hostThreadId,
                                              ~0ULL,
                                              ~0ULL,
                                              CUDBG_INVALID_HANDLE,
                                              CUDBG_INVALID_HANDLE,
                                              CUDBG_INVALID_HANDLE,
                                              NULL, 0);
                if (!context) {
                    CUDBG_ERROR("Context creation failed.\n");
                    return CUDBG_ERROR_INVALID_CONTEXT;
                }
            }

            memMap = context->memMap;
        }
        else
            /* This allocation maps to the primary memmgr */
            memMap = haloStateGetGlobalMemMap();

        if (dev->dmal->type == HALO_DMAL_TYPE_MRM) {
            /* No pipes are used with in-process clients */
            if (haloGlobals.initData.flags & HALO_INIT_FLAGS_IN_PROCESS) {
#if !cuosOsIsQnx()
                /* On QNX we should never hit this branch */
                res = popMessage(&p, (void*)&parentFd, sizeof(parentFd));
                if (res != CUDBG_SUCCESS)
                    return res;

                /* Use the allocation's original handle */
                message->cases.memblockAlloc.segInfo.dmalHandle = parentFd;
#endif
            }
            else {
#if cuosOsIsQnx()
                /* On QNX, we use IDs instead of fds to pass memory handles */
                res = dev->dmal->createHandleForMemorySegment(dev, memHandleId, &newHandle);
                if (res != CUDBG_SUCCESS) {
                    CUDBG_ERROR("dbgMemblockAlloc: Failed to dup segment\n");
                    return res;
                }

                message->cases.memblockAlloc.segInfo.dmalHandle = newHandle;
#else
                int *pfd = NULL;
                /* On MRM, the exported fd needs to be used to create a handle
                   for the memory segment */
                res = cudbgPipeControlMessageRead(&applicationToDispatcher, &pfd);
                if (res != CUDBG_SUCCESS) {
                    CUDBG_ERROR("dbgMemblockAlloc: Failed to read control data\n");
                    return res;
                }
                message->cases.memblockAlloc.segInfo.dmalHandle = *pfd;

                if (message->cases.memblockAlloc.segInfo.usesNvmap) {
                    res = dev->dmal->createHandleForMemorySegment(dev, *pfd, &newHandle);
                    if (res != CUDBG_SUCCESS) {
                        CUDBG_ERROR("dbgMemblockAlloc: Failed to dup segment\n");
                        return res;
                    }

                    message->cases.memblockAlloc.segInfo.dmalHandle = newHandle;
                }
#endif
            }
        }

        res = haloMemoryMapAddSegmentFromInfo(memMap, &message->cases.memblockAlloc.segInfo);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to add segment to context\n");

        API_TRACE_FUNCTION(10, "Memblock Alloc  : hostHandle:0x%" PRIx64 " on ctx:0x%" PRIx64 "\n"
                           "    devvaddr     :0x%" PRIx64 "\n"
                           "    size         :0x%" PRIx64 "\n",
                           message->cases.memblockAlloc.segInfo.hostHandle,
                           message->cases.memblockAlloc.segInfo.ctx,
                           message->cases.memblockAlloc.segInfo.devvaddr,
                           message->cases.memblockAlloc.segInfo.size);
    }
    break;

    case dbgMemblockFree: {
        uint64_t ctx        = message->cases.memblockFree.ctx;
        uint64_t devvaddr   = message->cases.memblockFree.devvaddr;
        Context context;
        haloMemoryMap *memMap = NULL;

        if (ctx) {
            context = haloStateGetContext(ctx);
            if (!context) {
                API_TRACE_FUNCTION(5, "No context found in MemblockFree. Bailing early\n");
                return CUDBG_SUCCESS;
            }

            memMap = context->memMap;
        }
        else
            memMap = haloStateGetGlobalMemMap();

        res = haloMemoryMapRemoveSegment(memMap, devvaddr);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to remove segment at 0x%" PRIx64 ". Context=0x%" PRIx64 "\n", devvaddr, ctx);

        API_TRACE_FUNCTION(10, "Memblock Free  : hostHandle:0x%" PRIx64 " on ctx:0x%" PRIx64 "\n"
                           "   devvaddr    : 0x%" PRIx64 "\n"
                           "   size        : 0x%" PRIx64 "\n",
                           message->cases.memblockFree.hostHandle,
                           message->cases.memblockFree.ctx,
                           message->cases.memblockFree.devvaddr,
                           message->cases.memblockFree.size);
        break;
    }
    break;

    case dbgHostLmemResize: {
        uint64_t ctx        = message->cases.hostLmemResize.ctx;
        uint64_t devvaddr   = message->cases.hostLmemResize.devvaddr;
        uint64_t size       = message->cases.hostLmemResize.size;
        Context context;

        context = haloStateGetContext(ctx);
        if (!context) {
            API_TRACE_FUNCTION(5, "No context found in HostLmemResize. Bailing early\n");
            return CUDBG_SUCCESS;
        }

        context->defaultLmemDevVA  = devvaddr;
        context->defaultLmemSize   = size;

        API_TRACE_FUNCTION(1, "HostLmemResize : on ctx:0x%" PRIx64
                           " Setting Lmem to devvaddr:0x%" PRIx64 " Size:0x%" PRIx64 "\n",
                           ctx, devvaddr, size);
        break;
    }
    break;

    case dbgStreamSynchronized: {
        Context context = haloStateGetContext(message->cases.streamSynchronized.context);
        uint64_t streamId = message->cases.streamSynchronized.streamId;
        Grid grid = NULL;
        tList *tmpList = NULL;
        tListItr *tmpItr = NULL;

        CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT,
                     "Invalid context when processing dbgReportStreamSynchronized\n");

        tmpList = toolsHashMapToList(context->grids);
        tmpItr = toolsListGetIterator(tmpList);

        while (tmpItr != NULL) {
            grid = (Grid)toolsListGetElem(tmpItr);

            // Remove the grid if it's a context synchronize (i.e. no streamId)
            // or if it belongs to the stream being synchronized
            if (streamId == CUI_STREAM_ID_INVALID || streamId == grid->hostStreamId)
                deleteGrid(grid);

            tmpItr = toolsListGetNext(tmpItr);
        }

        toolsListDelete(tmpList, NULL, 0);

        break;
    }
    break;

    case dbgSystemStackResize: {
        Context context = haloStateGetContext(message->cases.systemStackResize.context);
        if (!context) {
            API_TRACE_FUNCTION(1, "SystemStackResize received on unknown context. (Likely a race with attach)\n");
            break;
        }
        context->syscallStackSz = (uint32_t)message->cases.systemStackResize.syscallStackSize;
    }
    break;

    default:
        CUDBG_ERROR("Unknown message kind when processing application message.\n");
        return CUDBG_ERROR_UNKNOWN;
    }

#endif
    return CUDBG_SUCCESS;
}

CUDBGResult
gpudbgProcessInternalError(CUDBGResult errorType)
{
    /*  5.0 and later */
    if (clientRevision > API_REVISION_4_2) {
        CUDBGEvent *event;

        gpudbgEventsGetAvailable(&event, GPUDBG_EVENT_SYNC);
        event->kind = CUDBG_EVENT_INTERNAL_ERROR;
        event->cases.internalError.errorType = errorType;

        gpudbgNotifyDebugger(0, false);
    }

    return CUDBG_SUCCESS;
}

/*---------------------------------- Events ---------------------------------*/

static void
gpudbgEventsInitialize(gpudbgEventKind_t kind)
{
    gpudbgEventContainer_t *events = (kind == GPUDBG_EVENT_SYNC) ? &eventListSync : &eventListAsync;
    /* events.head points to the oldest event in the list.
       events.tail points to a free slot in the list.
       The list is empty when events.head == events.tail
       and events.numEvents == 0.
       The list is full when events.head == events.tail and
       events.numEvents != 0. */
    events->max  = CUDBG_EVENTS_INITIAL_BUFSIZE;
    events->head = 0;
    events->tail = 0;
    events->numEvents = 0;
    events->buffer = (CUDBGEvent *)calloc(events->max, sizeof(CUDBGEvent));
}

static void
gpudbgEventsFinalize(gpudbgEventKind_t kind)
{
    gpudbgEventContainer_t *events = (kind == GPUDBG_EVENT_SYNC) ? &eventListSync : &eventListAsync;
    events->max  = 0;
    events->head = 0;
    events->tail = 0;
    events->numEvents = 0;
    free(events->buffer);
}

static void
gpudbgEventsGetAvailable(CUDBGEvent **event, gpudbgEventKind_t kind)
{
    CUDBGEvent *newBuffer;
    uint32_t i, j;
    gpudbgEventContainer_t *events = (kind == GPUDBG_EVENT_SYNC) ? &eventListSync : &eventListAsync;

    /* List full? */
    if ((events->numEvents != 0) && events->tail == events->head) {
        /* Double it in size */
        newBuffer = (CUDBGEvent *)calloc(events->max * 2, sizeof(CUDBGEvent));

        /* Copy the old list to its new home */
        for (i = events->head, j = 0;
             j < events->max;
             i = (i + 1) % events->max, j++) {
            newBuffer[j] = events->buffer[i];
        }

        events->head = 0;
        events->tail = events->max;
        events->max *= 2;
        free(events->buffer);
        events->buffer = newBuffer;
    }

    *event = &events->buffer[events->tail];
    events->tail = (events->tail + 1) % events->max;
    events->numEvents++;
}


static void
gpudbgEventsPop(CUDBGEvent **event, gpudbgEventKind_t kind)
{
    gpudbgEventContainer_t *events = (kind == GPUDBG_EVENT_SYNC) ? &eventListSync : &eventListAsync;

    if (events->numEvents == 0) {
        /* Empty list */
        *event = NULL;
        return;
    }

    *event = &events->buffer[events->head];
    events->head = (events->head + 1) % events->max;
    events->numEvents--;
}

CUDBGResult
gpudbgProcessTimeoutEvent(void)
{
    CUDBGEvent *event;
    if (clientRevision >= API_REVISION_3_2) {
        gpudbgEventsGetAvailable(&event, GPUDBG_EVENT_SYNC);
        event->kind = CUDBG_EVENT_TIMEOUT;
    }
    return CUDBG_SUCCESS;
}

typedef enum {
    CUDBG_CALLBACK_TYPE_NONE,
    CUDBG_CALLBACK_TYPE_31,
    CUDBG_CALLBACK_TYPE_40,
    CUDBG_CALLBACK_TYPE_LATEST
} CUDBGCallbackType;

static struct {
    CUDBGCallbackType type;
    union {
        struct {
            void *data;
            CUDBGNotifyNewEventCallback31 callback;
        } type31;
        struct {
            CUDBGNotifyNewEventCallback40 callback;
        } type40;
        struct {
            CUDBGNotifyNewEventCallback callback;
        } latest;
    } config;
} notifyDebuggerConfig;

CUDBGResult
gpudbgNotifyDebugger(uint32_t tid, bool timeout)
{
    CUDBGEventCallbackData40 data40 = {0};
    CUDBGEventCallbackData   data = {0};

    switch (notifyDebuggerConfig.type) {
    case CUDBG_CALLBACK_TYPE_NONE:
        return CUDBG_ERROR_UNINITIALIZED;
    case CUDBG_CALLBACK_TYPE_31:
        cudbgTlsSetCallbackState(CUDBG_TLS_NOTIFY_CALLBACK_ACTIVE);
        notifyDebuggerConfig.config.type31.callback(notifyDebuggerConfig.config.type31.data);
        cudbgTlsSetCallbackState(CUDBG_TLS_NOTIFY_CALLBACK_INACTIVE);
        return CUDBG_SUCCESS;
    case CUDBG_CALLBACK_TYPE_40:
        data40.tid = tid;
        cudbgTlsSetCallbackState(CUDBG_TLS_NOTIFY_CALLBACK_ACTIVE);
        notifyDebuggerConfig.config.type40.callback(&data40);
        cudbgTlsSetCallbackState(CUDBG_TLS_NOTIFY_CALLBACK_INACTIVE);
        return CUDBG_SUCCESS;
    case CUDBG_CALLBACK_TYPE_LATEST:
        data.tid = tid;
        data.timeout = timeout ? 1 : 0;
        cudbgTlsSetCallbackState(CUDBG_TLS_NOTIFY_CALLBACK_ACTIVE);
        notifyDebuggerConfig.config.latest.callback(&data);
        cudbgTlsSetCallbackState(CUDBG_TLS_NOTIFY_CALLBACK_INACTIVE);
        return CUDBG_SUCCESS;
    }

    return CUDBG_ERROR_INTERNAL;
}

/**
 * \fn CUDBGAPI_st::setNotifyNewEventCallback31
 * \brief Provides the API with the function to call to notify the debugger of a new application or device event.
 *
 * Since CUDA 3.0.
 *
 * \deprecated in CUDA 3.2.
 *
 * \ingroup EVENT
 *
 * \param callback - the callback function
 * \param data - a pointer to be passed to the callback when called
 *
 * \return CUDBG_SUCCESS
 */
CUDBGResult
gpudbgSetNotifyNewEventCallback31(CUDBGNotifyNewEventCallback31 callback, void *data)
{
    CUDBG_API_CHECK(CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    notifyDebuggerConfig.type = CUDBG_CALLBACK_TYPE_31;
    notifyDebuggerConfig.config.type31.data = data;
    notifyDebuggerConfig.config.type31.callback = callback;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::setNotifyNewEventCallback40
 * \brief Provides the API with the function to call to notify the debugger of
 * a new application or device event.
 *
 * Since CUDA 3.2.
 *
 * \deprecated in CUDA 4.1.
 *
 * \ingroup EVENT
 *
 * \param callback - the callback function
 *
 * \return CUDBG_SUCCESS
 */
CUDBGResult
gpudbgSetNotifyNewEventCallback40(CUDBGNotifyNewEventCallback40 callback)
{
    CUDBG_API_CHECK(CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);


    notifyDebuggerConfig.type = CUDBG_CALLBACK_TYPE_40;
    notifyDebuggerConfig.config.type40.callback = callback;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::setNotifyNewEventCallback
 * \brief Provides the API with the function to call to notify the debugger of a new application or device event.
 *
 * Since CUDA 4.1.
 *
 * \ingroup EVENT
 *
 * \param callback - the callback function
 *
 * \return CUDBG_SUCCESS
 */
CUDBGResult
gpudbgSetNotifyNewEventCallback(CUDBGNotifyNewEventCallback callback)
{
    CUDBG_API_CHECK(CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    notifyDebuggerConfig.type = CUDBG_CALLBACK_TYPE_LATEST;
    notifyDebuggerConfig.config.latest.callback = callback;

    return CUDBG_SUCCESS;
}

static CUDBGResult
gpudbgConvertTo55Event(CUDBGEvent *event, CUDBGEvent55 *event55)
{
    DeviceModule mod;

    CUDBG_VERIFY(event55, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    event55->kind = event->kind;
    switch (event->kind) {
    case  CUDBG_EVENT_ELF_IMAGE_LOADED:
        mod = gpudbgGetModuleByHandle(event->cases.elfImageLoaded.handle);
        CUDBG_VERIFY((mod && mod->context && mod->context->dev),
                     CUDBG_ERROR_INTERNAL,
                     "Invalid elf handle.\n");
        event55->cases.elfImageLoaded.relocatedElfImage = (char *)mod->relocatedElfImage;
        event55->cases.elfImageLoaded.nonRelocatedElfImage = (char *)mod->nonRelocatedElfImage;
        event55->cases.elfImageLoaded.size32 = (uint32_t) event->cases.elfImageLoaded.size;
        event55->cases.elfImageLoaded.dev = event->cases.elfImageLoaded.dev;
        event55->cases.elfImageLoaded.context = event->cases.elfImageLoaded.context;
        event55->cases.elfImageLoaded.module = event->cases.elfImageLoaded.module;
        event55->cases.elfImageLoaded.size = event->cases.elfImageLoaded.size;
        break;
    case CUDBG_EVENT_KERNEL_READY:
        event55->cases.kernelReady.dev = event->cases.kernelReady.dev;
        event55->cases.kernelReady.gridId = (uint32_t) event->cases.kernelReady.gridId;
        event55->cases.kernelReady.tid = event->cases.kernelReady.tid;
        event55->cases.kernelReady.context = event->cases.kernelReady.context;
        event55->cases.kernelReady.module = event->cases.kernelReady.module;
        event55->cases.kernelReady.function = event->cases.kernelReady.function;
        event55->cases.kernelReady.functionEntry = event->cases.kernelReady.functionEntry;
        event55->cases.kernelReady.gridDim = event->cases.kernelReady.gridDim;
        event55->cases.kernelReady.blockDim = event->cases.kernelReady.blockDim;
        event55->cases.kernelReady.type = event->cases.kernelReady.type;
        event55->cases.kernelReady.parentGridId = event->cases.kernelReady.parentGridId;
        event55->cases.kernelReady.gridId64 = event->cases.kernelReady.gridId;
        event55->cases.kernelReady.origin = event->cases.kernelReady.origin;
        break;
    case CUDBG_EVENT_KERNEL_FINISHED:
        event55->cases.kernelFinished.dev = event->cases.kernelFinished.dev;
        event55->cases.kernelFinished.gridId = (uint32_t) event->cases.kernelFinished.gridId;
        event55->cases.kernelFinished.tid = event->cases.kernelFinished.tid;
        event55->cases.kernelFinished.context = event->cases.kernelFinished.context;
        event55->cases.kernelFinished.module = event->cases.kernelFinished.module;
        event55->cases.kernelFinished.function = event->cases.kernelFinished.function;
        event55->cases.kernelFinished.functionEntry = event->cases.kernelFinished.functionEntry;
        event55->cases.kernelFinished.gridId64 = event->cases.kernelFinished.gridId;
        break;
    case CUDBG_EVENT_CTX_PUSH:
    case CUDBG_EVENT_CTX_POP:
    case CUDBG_EVENT_CTX_CREATE:
    case CUDBG_EVENT_CTX_DESTROY:
        event55->cases.contextPush.dev = event->cases.contextPush.dev;
        event55->cases.contextPush.tid = event->cases.contextPush.tid;
        event55->cases.contextPush.context = event->cases.contextPush.context;
        break;
    case CUDBG_EVENT_INTERNAL_ERROR:
        event55->cases.internalError.errorType = event->cases.internalError.errorType;
    case CUDBG_EVENT_TIMEOUT:
    case CUDBG_EVENT_ATTACH_COMPLETE:
    case CUDBG_EVENT_DETACH_COMPLETE:
        break;
    default:
        event55->kind = CUDBG_EVENT_INVALID;
        return CUDBG_ERROR_INTERNAL;
    }
    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::getNextEvent30
 * \brief Copies the next available event in the event queue into 'event' and removes it from the queue.
 *
 * Since CUDA 3.0.
 *
 * \deprecated in CUDA 3.1.
 *
 * \ingroup EVENT
 *
 * \param event - pointer to an event container where to copy the event parameters
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_NO_EVENT_AVAILABLE,
 * \return CUDBG_ERROR_INVALID_ARGS
 */
CUDBGResult
gpudbgGetNextEvent30(CUDBGEvent30 *event)
{
    CUDBGEvent55 nextEvent;
    CUDBGResult res;

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    res = gpudbgGetNextSyncEvent55(&nextEvent);
    /*  WARNING: for backward-compatibility with 3.0, the CUDBGEvent is
       truncated to the size of CUDBGEvent30 by the memcpy. This is
       intentional. It works as long as we do not change the order of
       the fields in the data structures.
    */
    memcpy(event, &nextEvent, sizeof(*event));
    return res;
}


/**
 * \fn CUDBGAPI_st::getNextEvent32
 * \brief Copies the next available event in the event queue into 'event' and removes it from the queue.
 *
 * Since CUDA 3.1.
 *
 * \deprecated in CUDA 4.0
 *
 * \ingroup EVENT
 *
 * \param event - pointer to an event container where to copy the event parameters
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_NO_EVENT_AVAILABLE,
 * \return CUDBG_ERROR_INVALID_ARGS
 */
CUDBGResult
gpudbgGetNextEvent32(CUDBGEvent32 *event)
{
    CUDBGEvent55 nextEvent;
    CUDBGResult res;

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    res = gpudbgGetNextSyncEvent55(&nextEvent);
    /* WARNING: for backward-compatibility with 3.2, the CUDBGEvent is
       truncated to the size of CUDBGEvent32 by the memcpy. This is
       intentional. It works as long as we do not change the order of
       the fields in the data structures.
    */
    memcpy(event, &nextEvent, sizeof(*event));
    return res;
}


/**
 * \fn CUDBGAPI_st::acknowledgeEvent30
 * \brief Inform the debugger API that the event has been processed.
 *
 * Since CUDA 3.0.
 *
 * \deprecated in CUDA 3.1.
 *
 * \ingroup EVENT
 *
 * \param event - pointer to the event that has been processed
 *
 * \return CUDBG_SUCCESS
 */
CUDBGResult
gpudbgAcknowledgeEvent30(CUDBGEvent30 *event)
{
    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    return gpudbgAcknowledgeSyncEvents();
}

/**
 * \fn CUDBGAPI_st::getNextEvent42
 * \brief Copies the next available event in the event queue into 'event' and removes it from the queue.
 *
 * Since CUDA 4.0.
 *
 * \deprecated in CUDA 5.0
 *
 * \ingroup EVENT
 *
 * \param event - pointer to an event container where to copy the event parameters
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_NO_EVENT_AVAILABLE,
 * \return CUDBG_ERROR_INVALID_ARGS
 */
CUDBGResult
gpudbgGetNextEvent42(CUDBGEvent42 *event)
{
    CUDBGEvent55 nextEvent;
    CUDBGResult res;

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    res = gpudbgGetNextSyncEvent55(&nextEvent);
    /* WARNING: for backward-compatibility with 4.2, the CUDBGEvent is
       truncated to the size of CUDBGEvent42 by the memcpy. This is
       intentional. It works as long as we do not change the order of
       the fields in the data structures.
    */
    memcpy(event, &nextEvent, sizeof(*event));
    return res;
}

/**
 * \fn CUDBGAPI_st::getNextSyncEvent50
 *
 * Since CUDA 5.0.
 *
 * \deprecated in CUDA 5.5.
 *
 * \ingroup EVENT
 *
 * \param event - pointer to an event container where to copy the event parameters
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_NO_EVENT_AVAILABLE,
 * \return CUDBG_ERROR_INVALID_ARGS
 */
CUDBGResult
gpudbgGetNextSyncEvent50(CUDBGEvent50 *event)
{
    CUDBGEvent55 nextEvent;
    CUDBGResult res;

    CUDBG_VERIFY(event, CUDBG_ERROR_INVALID_ARGS, "No valid event.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    res = gpudbgGetNextSyncEvent55(&nextEvent);
    /* WARNING: for backward-compatibility with 5.0, the CUDBGEvent55 is
       truncated to the size of CUDBGEvent50 by the memcpy. This is
       intentional. It works as long as we do not change the order of
       the fields in the data structures.
    */
    memcpy(event, &nextEvent, sizeof(*event));
    return res;
}

/**
 * \fn CUDBGAPI_st::getNextSyncEvent55
 * \brief Copies the next available event in the synchronous event queue into 'event' and removes it from the queue.
 *
 * Since CUDA 5.5.
 *
 * \ingroup EVENT
 *
 * \param event - pointer to an event container where to copy the event parameters
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_NO_EVENT_AVAILABLE,
 * \return CUDBG_ERROR_INVALID_ARGS
 */
CUDBGResult
gpudbgGetNextSyncEvent55(CUDBGEvent55 *event)
{
    CUDBGEvent nextEvent;
    CUDBGResult res;

    CUDBG_VERIFY(event, CUDBG_ERROR_INVALID_ARGS, "No valid event.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    res = gpudbgGetNextEvent (CUDBG_EVENT_QUEUE_TYPE_SYNC, &nextEvent);
    if (res == CUDBG_ERROR_NO_EVENT_AVAILABLE) {
        event->kind = CUDBG_EVENT_INVALID;
        return res;
    }

    return gpudbgConvertTo55Event(&nextEvent, event);
}


/**
 * \fn CUDBGAPI_st::acknowledgeEvents42
 * \brief Inform the debugger API that synchronous events have been processed.
 *
 * Since CUDA 3.1.
 *
 * \deprecated in CUDA 5.0.
 *
 * \ingroup EVENT
 *
 * \return CUDBG_SUCCESS
 */
CUDBGResult
gpudbgAcknowledgeEvents42(void)
{
    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    return gpudbgAcknowledgeSyncEvents();
}

/**
 * \fn CUDBGAPI_st::acknowledgeSyncEvents
 * \brief Inform the debugger API that synchronous events have been processed.
 *
 * Since CUDA 5.0.
 *
 * \ingroup EVENT
 *
 * \return CUDBG_SUCCESS
 */
CUDBGResult
gpudbgAcknowledgeSyncEvents(void)
{
    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    gpudbgSendDebuggerMessage(TGDB_DBGMSG_ACK, 0, 0, 0, NULL, NULL);
    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::getNextAsyncEvent50
 * \brief Copies the next available event in the asynchronous event queue into 'event' and removes it from the queue.  The asynchronous event queue is held separate from the normal event queue, and does not require acknowledgement from the debug client.
 *
 * Since CUDA 5.0.
 *
 * \deprecated in CUDA 5.5.
 *
 * \ingroup EVENT
 *
 * \param event - pointer to an event container where to copy the event parameters
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_NO_EVENT_AVAILABLE,
 * \return CUDBG_ERROR_INVALID_ARGS
 */
CUDBGResult
gpudbgGetNextAsyncEvent50(CUDBGEvent50 *event)
{
    CUDBGEvent55 nextEvent;
    CUDBGResult res;

    CUDBG_VERIFY(event, CUDBG_ERROR_INVALID_ARGS, "No valid event.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    res = gpudbgGetNextAsyncEvent55(&nextEvent);
    /* WARNING: for backward-compatibility with 5.0, the CUDBGEvent55 is
       truncated to the size of CUDBGEvent50 by the memcpy. This is
       intentional. It works as long as we do not change the order of
       the fields in the data structures.
    */
    memcpy(event, &nextEvent, sizeof(*event));
    return res;
}

/**
 * \fn CUDBGAPI_st::getNextAsyncEvent55
 * \brief Copies the next available event in the asynchronous event queue into 'event' and removes it from the queue.  The asynchronous event queue is held separate from the normal event queue, and does not require acknowledgement from the debug client.
 *
 * Since CUDA 5.5.
 *
 * \ingroup EVENT
 *
 * \param event - pointer to an event container where to copy the event parameters
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_NO_EVENT_AVAILABLE,
 * \return CUDBG_ERROR_INVALID_ARGS
 */
CUDBGResult
gpudbgGetNextAsyncEvent55(CUDBGEvent55 *event)
{
    CUDBGEvent nextEvent;
    CUDBGResult res;

    CUDBG_VERIFY(event, CUDBG_ERROR_INVALID_ARGS, "No valid event.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    res = gpudbgGetNextEvent (CUDBG_EVENT_QUEUE_TYPE_ASYNC, &nextEvent);
    if (res == CUDBG_ERROR_NO_EVENT_AVAILABLE) {
        event->kind = CUDBG_EVENT_INVALID;
        return res;
    }

    return gpudbgConvertTo55Event(&nextEvent, event);
}

/**
 * \fn CUDBGAPI_st::getNextEvent
 * \brief Copies the next available event into 'event' and removes it from the queue.
 *
 * Since CUDA 6.0.
 *
 * \ingroup EVENT
 *
 * \param type  - application event queue type
 * \param event - pointer to an event container where to copy the event parameters
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_NO_EVENT_AVAILABLE,
 * \return CUDBG_ERROR_INVALID_ARGS
 */
CUDBGResult
gpudbgGetNextEvent (CUDBGEventQueueType type, CUDBGEvent *event)
{
    CUDBGEvent *nextEvent;

    CUDBG_VERIFY(event, CUDBG_ERROR_INVALID_ARGS, "No valid event kind.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    switch (type) {
    case CUDBG_EVENT_QUEUE_TYPE_SYNC:
        gpudbgEventsPop(&nextEvent, GPUDBG_EVENT_SYNC);
        break;
    case CUDBG_EVENT_QUEUE_TYPE_ASYNC:
        gpudbgEventsPop(&nextEvent, GPUDBG_EVENT_ASYNC);
        break;
    default:
        CUDBG_ERROR ("Unexpected CUDBGEventQueuType value: %u\n", (unsigned int)type);
        return CUDBG_ERROR_INVALID_ARGS;
    }
    if (!nextEvent) {
        event->kind = CUDBG_EVENT_INVALID;
        return CUDBG_ERROR_NO_EVENT_AVAILABLE;
    }

    memcpy(event, nextEvent, sizeof(*event));
    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::getPhysicalRegister30
 * \brief Get the physical register number(s) assigned to a virtual register name 'reg' at a given PC, if 'reg' is live at that PC.
 *
 * Since CUDA 3.0.
 *
 * \deprecated in CUDA 3.1.
 *
 * \ingroup DWARF
 *
 * \param pc - Program counter
 * \param reg - virtual register index
 * \param buf - physical register name(s)
 * \param sz - the physical register name buffer size
 * \param numPhysRegs - number of physical register names returned
 * \param regClass - the class of the physical registers
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_UKNOWN_FUNCTION,
 * \return CUDBG_ERROR_UNKNOWN
 */
CUDBGResult
gpudbgGetPhysicalRegister30(uint64_t pc, char *reg,
                            uint32_t *buf, uint32_t sz,
                            uint32_t *numPhysRegs, CUDBGRegClass *regClass)
{
    Grid grid;
    DeviceFunction function;
    CudbgDevice dev;
    char *funcName;
    CUDBGResult res;
    uint32_t devId, i;

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);
    /* sanity */
    CUDBG_VERIFY((reg && buf && numPhysRegs && regClass),
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments in gpudbgGetPhysicalRegister30.\n");

    /* find name of the currently active function. This a 3.0 obsolete function.
       At the time, there was no multi-gpu support. Now we just return the first
       function we find that is currently running. */
    function = NULL;
    for (devId = 0; devId < globals.numDevices; ++devId) {
        if (!deviceHasAnyContext(devId))
            continue;
        dev = haloGlobals.device[devId];
        if (haloStateDeviceGetNumGrids(dev) > 0) {
            grid = haloStateDeviceGetAnyGrid(dev);
            function = grid->function;
            break;
        }
    }

    CUDBG_VERIFY(function, CUDBG_ERROR_UNKNOWN_FUNCTION, "Unknown function.\n");

    /* find corresponding SASS register */
    funcName = function->name;
    *numPhysRegs = 0;
    memset(buf, 0, sz);
    res = gpudbgRegMapSearch(function->module->regMap, funcName, reg, pc,
                             buf, sz, numPhysRegs, regClass);
    if (res != CUDBG_SUCCESS)
        return res;

    /* output debug trace */
    API_TRACE(2, "get physical register: ptx=%s regClass=%d ", reg, *regClass);
    for (i = 0; i < *numPhysRegs; ++i)
        API_TRACE_ELEMENT(2, "sass[%u]=%x ", i, buf[i]);
    API_TRACE_ELEMENT(2, "\n");

    return res;
}

/**
 * \fn CUDBGAPI_st::getPhysicalRegister40
 *
 * \brief Get the physical register number(s) assigned to a virtual
 * register name 'reg' at a given PC, if 'reg' is live at that PC.
 *
 * Get the physical register number(s) assigned to a virtual register
 * name 'reg' at a given PC, if 'reg' is live at that PC. If a virtual
 * register name is mapped to more than one physical register, the
 * physical register with the lowest physical register index will
 * contain the highest bits of the virtual register, and the
 * physical register with the highest physical register index will
 * contain the lowest bits.
 *
 * Since CUDA 3.1.
 *
 * \deprecated in CUDA 4.1.
 *
 * \ingroup DWARF
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp indx
 * \param pc - Program counter
 * \param reg - virtual register index
 * \param buf - physical register name(s)
 * \param sz - the physical register name buffer size
 * \param numPhysRegs - number of physical register names returned
 * \param regClass - the class of the physical registers
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_UKNOWN_FUNCTION,
 * \return CUDBG_ERROR_UNKNOWN
 */
CUDBGResult
gpudbgGetPhysicalRegister40(uint32_t devId, uint32_t sm, uint32_t wp,
                            uint64_t pc, char *reg,
                            uint32_t *buf, uint32_t sz,
                            uint32_t *numPhysRegs, CUDBGRegClass *regClass)
{
    DeviceFunction function;
    char *funcName;
    CUDBGResult res;
    uint32_t i;
    uint64_t gridId64;
    Grid grid;

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID),
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    /* sanity */
    CUDBG_VERIFY((reg && buf && numPhysRegs && regClass),
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments in gpudbgGetPhysicalRegister40.\n");

    /* XXX This could possibly be optimized by storing the grid in the
       warp */
    if ((res = gpudbgReadGridId(devId, sm, wp, &gridId64)) != CUDBG_SUCCESS)
        return res;
    grid = haloStateDeviceGetGrid(haloGlobals.device[devId], gridId64);
    CUDBG_VERIFY(grid, CUDBG_ERROR_INVALID_GRID, "Invalid grid in gpudbgGetPhysicalRegister40.\n");

    /* find corresponding SASS register */
    function = grid->function;
    funcName = function->name;
    *numPhysRegs = 0;
    memset(buf, 0, sz);
    res = gpudbgRegMapSearch(function->module->regMap, funcName, reg, pc,
                             buf, sz, numPhysRegs, regClass);
    if (res != CUDBG_SUCCESS)
        return res;

    /* output debug trace */
    API_TRACE_FUNCTION(2, "%s -> regClass=%d ", reg, *regClass);
    for (i = 0; i < *numPhysRegs; ++i)
        API_TRACE_ELEMENT(2, "sass[%u]=R%d ", i, buf[i]);
    API_TRACE_ELEMENT(2, "\n");

    return res;
}

#if cuosOsIsLinux() || cuosOsIsApple()
static void
writeCubin(int tmpFd, uint64_t inst[2], uint32_t instSize, const char *smType)
{
    char buf[CUDBG_UTIL_TMP_BUF_SIZE];
    uint32_t off = 0, i = 0;
    uint32_t *inst32 = (uint32_t*)inst;

    off = snprintf(buf, sizeof(buf),
                   "architecture {%s}\n"
                   "abiversion   {1}\n"
                   "cubinversion {1}\n"
                   "modname      {cubin}\n"
                   "texmode      {texmode_unified}\n"
                   "code {\n"
                   "  name = DISASSEMBLY\n"
                   "  bincode {\n"
                   "     ", smType);
    if (off >= sizeof(buf))
        return;

    for (i = 0; i < instSize / sizeof(uint32_t); i++) {
        off += snprintf(buf + off, sizeof(buf) - off, " 0x%08x", inst32[i]);
        if (off >= sizeof(buf))
            return;
    }
    buf[off++] = '\n';

    if (off >= sizeof(buf))
        return;

    off += snprintf(buf + off, sizeof(buf) - off,
                    "  }\n"
                    "}\n");
    if (off >= sizeof(buf))
        return;

    write(tmpFd, buf, strlen(buf));
}
#endif

typedef enum {
    CUDBG_DISASM_CUOBJDUMP = 0 ,
    CUDBG_DISASM_NVDISASM,
    CUDBG_DISASM_NVDISASM_RAW,

    /* Last element used for sizing */
    CUDBG_DISASM_SIZE
} CudbgDisasmMode;

/* Use the release disassembler unless otherwise specified but ONLY for release */
const char* getDisassemblerCommand() {
    static char cmd[CUDBG_UTIL_TMP_BUF_SIZE] = {0};
#ifndef RELEASE
    if (!cuosGetEnv("CUDBG_DISASSEMBLER", cmd, sizeof(cmd)))
        return cmd;
#endif
    strcpy(cmd, "nvdisasm");
    return cmd;
}

/**
 * \fn CUDBGAPI_st::disassemble
 * \brief Disassemble instruction at instruction address.
 *
 * Since CUDA 3.0.
 *
 * \ingroup DWARF
 *
 * \param dev - device index
 * \param addr - instruction address
 * \param instSize - instruction size (32 or 64 bits)
 * \param buf - disassembled instruction buffer
 * \param sz - disassembled instruction buffer size
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_UNKNOWN
 */
CUDBGResult
gpudbgDisassemble(uint32_t devId, uint64_t address, uint32_t *instSize, char *dis, uint32_t disSize)
{
#if cuosOsIsLinux() || cuosOsIsApple()
    CudbgDevice dev;
    CUDBGResult res;
    uint64_t inst[2];
    char command[CUDBG_UTIL_TMP_BUF_SIZE];
    FILE *f;
    size_t len;
    int tmpFd;
    char tmpFilename[CUDBG_UTIL_TMP_BUF_SIZE];
    char *p, *q;
    char buf[CUDBG_UTIL_TMP_BUF_SIZE];
    bool isInternalInstruction = false;
    const char *blankInternalString = " ";
    uint64_t gpuPC;
    const char *termPath[CUDBG_DISASM_SIZE] = {"*/ \t", "*/", "*/"};
    uint32_t sm_major = 0, sm_minor = 0;
    CudbgDisasmMode mode = CUDBG_DISASM_CUOBJDUMP;
    uint64_t instBuf[64];
    uint32_t instBufSize  = sizeof(instBuf);
    uint32_t instBufWrittenSize = 0;

    CUDBG_VERIFY(instSize && (!disSize || dis), CUDBG_ERROR_INVALID_ARGS, "invalid arguments in gpudbgDisassemble.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_SUSPENDED)   |
                    CUDBG_API_CHECK_DEV_STATUS,
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    /* Setup the mode */
    if (clientRevision > API_REVISION_5_5)
        mode = CUDBG_DISASM_NVDISASM_RAW;
    else if (clientRevision > API_REVISION_5_0)
        mode = CUDBG_DISASM_NVDISASM;

    /* Compute the SM major, minor version that can be fed into nvdisasm */
    sm_major = (uint32_t)globals.devices[devId]->state.major;
    sm_minor = (uint32_t)globals.devices[devId]->state.minor;
    switch (sm_major) {
    case 2:
        /* All SM 2.x map to SM 2.0 */
        sm_minor = 0;
        break;
    case 3:
        /* Forcibly map SM 3.5+ to SM 3.5 */
        sm_minor = (sm_minor > 5) ? 5 : sm_minor;
        break;
    default:
        /* Default, do nothing */
        break;
    }

    CUDBG_VERIFY((mode == CUDBG_DISASM_CUOBJDUMP ||
                  mode == CUDBG_DISASM_NVDISASM  ||
                  mode == CUDBG_DISASM_NVDISASM_RAW),
                 CUDBG_ERROR_INVALID_ARGS, "Unknown mode\n");

    res = translateVirtualAddrToPCAndDevVA(address, dev->activeContext, &gpuPC, NULL);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("call to translateVirtualAddrToPCAndDevVA in gpudbgDisassemble failed\n");
        return res;
    }

    res = gpudbgReadCodeMemory(devId, address, &inst, sizeof inst);
    if (res != CUDBG_SUCCESS)
        return res;

    snprintf(tmpFilename, sizeof(tmpFilename),
             "%sdisassembly-XXXXXX", cudbgGetTempPrefix());

    res = dev->halo.getInstructionSize(inst[0], instSize);
    if (res != CUDBG_SUCCESS || !disSize)
        return res;

#ifndef RELEASE
    /* By default, always detect internal instructions.  However, if
       user is on a debug build and has enabled internal instructions,
       skip the detection. */
    if (!cudbgEnableInternalInsts)
#endif
    {
        res = dev->halo.isInternalInstructionAtPC(dev, inst[0], gpuPC, &isInternalInstruction);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to isInternalInstruction failed (res=%d).\n", res);
            return res;
        }
    }

    if (isInternalInstruction) {
        API_TRACE_FUNCTION(1, "Internal instruction found (hiding).\n");
        strncpy(dis, blankInternalString, disSize);
        return CUDBG_SUCCESS;
    }

    /* Pack an I$ sized buffer. On some architectures,
       we want the backend disassembly to include more information
    */
    res = dev->halo.fillDisassemblyBuffer(dev->activeContext, gpuPC, inst, instBuf, instBufSize,
                                          &instBufWrittenSize);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to fill instruction buffer\n");

    tmpFd = mkstemp(tmpFilename);
    CUDBG_VERIFY(tmpFd != -1, CUDBG_ERROR_UNKNOWN, "Call to mkstemp failed.\n");
    if (mode == CUDBG_DISASM_CUOBJDUMP)
        writeCubin(tmpFd, inst, *instSize, globals.devices[devId]->state.isav);
    else if (mode == CUDBG_DISASM_NVDISASM || mode == CUDBG_DISASM_NVDISASM_RAW)
        write(tmpFd, (void*)instBuf, instBufWrittenSize);

    close(tmpFd);

    if (mode == CUDBG_DISASM_CUOBJDUMP)
        snprintf(command, sizeof(command), "cuobjdump --dump-sass %s", tmpFilename);
    else if (mode == CUDBG_DISASM_NVDISASM)
        snprintf(command, sizeof(command), "%s -b SM%u%u %s",
                 getDisassemblerCommand(), sm_major, sm_minor, tmpFilename);
    else if (mode == CUDBG_DISASM_NVDISASM_RAW)
        snprintf(command, sizeof(command), "%s -ndf -raw -b SM%u%u %s",
                 getDisassemblerCommand(), sm_major, sm_minor, tmpFilename);

    f = popen(command, "r");

    if (!f) {
        unlink(tmpFilename);
        return CUDBG_ERROR_UNKNOWN;
    }

    // Results looks like:
    // "code for sm_13\n"
    // "\t--------------\n"
    // "\t\tFunction : DISASSEMBLY\n"
    // "\t/*0000*/ \tMOV.U16 R1L, g [0x1].U16;\n"
    // "\t\t......................\n"
    // New format is now
    // "\t/*0000*/ \t/*0xlx*/ \tMOV.U16 R1L, g[0x1].U16;\n"
    // Even newer format is : (for nvdisasm)
    // "\t/*0000*/ \t MOV R1, R0 { OPEX/ANNOTATION };\n"

    for (;;) {
        if (!fgets(buf, sizeof buf, f)) {
            pclose(f);
            unlink(tmpFilename);
            return CUDBG_ERROR_UNKNOWN;
        }

        if ((p = strstr(buf, termPath[mode]))) {
            p += 4;
            break;
        }
    }

    pclose(f);
    unlink(tmpFilename);

    len = strlen(p);

    if (mode == CUDBG_DISASM_CUOBJDUMP) {
        /*  Strip out trailing garbage that Arch loves so much */
        while (len && strchr("\n ;", p[len-1]))
            --len;
        p[len] = 0;
    }
    else if (mode == CUDBG_DISASM_NVDISASM ||
             mode == CUDBG_DISASM_NVDISASM_RAW) {
        /* Strip out leading whitespace */
        for (; len && *p == ' '; ++p);

        /*  Strip out trailing junk (everything after ";" ) */
        if ((q = strstr(p, ";")))
            *q = 0;

        /* Recompute length */
        len = strlen(p);
    }

    strncpy(dis, p, disSize);

    return CUDBG_SUCCESS;
#else
    return CUDBG_ERROR_UNKNOWN;
#endif
}

typedef struct {
    char *name;
    uint64_t address;
    bool found;
} symbol_lookup_t;

static TOOLSresult
lookupFunctionName(tHashMapKey_t key, void *entry, void *data)
{
    DeviceFunction function;
    symbol_lookup_t *sym;

    function = (DeviceFunction)entry;
    sym = (symbol_lookup_t*)data;
    if (!strcmp(function->name, sym->name)) {
        sym->address = function->virtAddrBase;
        sym->found = true;
    }

    return TOOLS_SUCCESS;
}

static TOOLSresult
modLookupFunctionName(tHashMapKey_t key, void *entry, void *data)
{
    DeviceModule mod;

    mod = (DeviceModule)entry;

    return toolsHashMapApplyFunctor(mod->functions, lookupFunctionName, data);
}

static CUDBGResult
ctxLookupFunctionName(Context ctx, void *data)
{
    TOOLSresult tres = TOOLS_SUCCESS;

    CUDBG_VERIFY(ctx && data, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    tres = toolsHashMapApplyFunctor(ctx->modules, modLookupFunctionName, data);
    CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_UNKNOWN, "Failed in module iterator (tres=%u)\n", tres);

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::lookupDeviceCodeSymbol
 * \brief Determines whether a symbol represents a function in device code and returns its virtual address.
 *
 * Since CUDA 3.0.
 *
 * \ingroup DWARF
 *
 * \param symName - symbol name
 * \param symFound - set to true if the symbol is found
 * \param symAddr - the symbol virtual address if found
 *
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_SUCCESS
 */
CUDBGResult
gpudbgLookupDeviceCodeSymbol(char *symName, bool *symFound, uintptr_t *symAddr)
{
    symbol_lookup_t sym;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    CUDBG_VERIFY(symName && symAddr, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in gpudbgLookupDeviceCodeSymbol.\n");

    sym.name  = symName;
    sym.found = false;

    res = haloStateTraverseContexts(ctxLookupFunctionName, (void*)&sym);

    *symFound = sym.found;
    *symAddr  = (uintptr_t)sym.address;
    return res;
}

typedef struct ctxPatchData_st ctxPatchData;

struct ctxPatchData_st {
    uint64_t virtAddr;
    bool *inPatch;
};

static CUDBGResult
findAddrInCtxPatch(Context ctx, void *userData)
{
    CUDBGResult res = CUDBG_SUCCESS;
    DebugPatch patch = NULL;
    bool inPatch = false;
    ctxPatchData *data = (ctxPatchData*)userData;

    CUDBG_VERIFY(ctx && data, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    res = haloInPatchRegion(data->virtAddr, ctx, &patch, CUDBG_PATCH_ALL,
                            &inPatch, true);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to haloInPatchRegion failed in gpudbgIsDeviceCodeAddress.\n");
        return res;
    }

    /* Only update this if we have patch debugging enabled */
    if (inPatch && patch && patch->debug)
        (*data->inPatch) |= inPatch;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::isDeviceCodeAddress55
 * \brief Determines whether a virtual address resides within device code. This API is strongly deprecated. Use CUDBGAPI_st::isDeviceCodeAddress instead.
 *
 * Since CUDA 3.0.
 *
 * \deprecated in CUDA 6.0
 *
 * \ingroup DWARF
 *
 * \param addr - virtual address
 * \param isDeviceAddress - true if address resides within device code
 *
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_SUCCESS
 */
CUDBGResult
gpudbgIsDeviceCodeAddress55(uintptr_t address, bool *isDeviceAddress)
{
    bool hidden;
    CUDBGResult res;
    DeviceFunction function;

    CUDBG_VERIFY(isDeviceAddress, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in gpudbgIsDeviceCodeAddress.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    CUDBG_VERIFY(brokenVirtAddrToFunction, CUDBG_ERROR_UNINITIALIZED, "Uninitialized.\n");
    CUDBG_VERIFY(clientRevision <= API_REVISION_5_5, CUDBG_ERROR_INVALID_ARGS, "New client calling broken API.\n");

    *isDeviceAddress = false;

    function = (DeviceFunction)toolsRangeMapLookupByAddr(brokenVirtAddrToFunction, (uint64_t)address);
    if (function) {
        /* Disallow hidden functions */
        res = haloInHiddenFunction(function, &hidden);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "error calling haloInHiddenFunction\n");

        if (!hidden) {
            *isDeviceAddress = true;
            return CUDBG_SUCCESS;
        }
    }

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::isDeviceCodeAddress
 * \brief Determines whether a virtual address resides within device code.
 *
 * Since CUDA 3.0.
 *
 * \ingroup DWARF
 *
 * \param addr - virtual address
 * \param isDeviceAddress - true if address resides within device code
 *
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_SUCCESS
 */
CUDBGResult
gpudbgIsDeviceCodeAddress(uintptr_t address, bool *isDeviceAddress)
{
    bool hidden;
    CUDBGResult res;
    DeviceFunction function;

    CUDBG_VERIFY(isDeviceAddress, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in gpudbgIsDeviceCodeAddress.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    CUDBG_VERIFY(virtAddrToFunction, CUDBG_ERROR_UNINITIALIZED, "Uninitialized.\n");

    *isDeviceAddress = false;

    function = (DeviceFunction)toolsRangeMapLookupByAddr(virtAddrToFunction, (uint64_t)address);

    if (function) {
        /* Disallow hidden functions */
        res = haloInHiddenFunction(function, &hidden);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "error calling haloInHiddenFunction\n");

        if (!hidden) {
            *isDeviceAddress = true;
            return CUDBG_SUCCESS;
        }
    }

#ifndef RELEASE
    if (! *isDeviceAddress) {
        ctxPatchData data = {0};
        CUDBGResult res = CUDBG_SUCCESS;

        data.virtAddr = address;
        data.inPatch = isDeviceAddress;

        res = haloStateTraverseContexts((haloCtxIterFunc)findAddrInCtxPatch, &data);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to traverse contexts failed in gpudbgIsDeviceCodeAddress.\n");
        }
    }
#endif

    return CUDBG_SUCCESS;
}

typedef struct {
    uint32_t devId;
    uint64_t virtAddr;
    bool insertBpOnSet;
} breakpoint_token_t;

typedef struct {
    uint64_t originalVirtAddr;
    uint64_t adjustedVirtAddr;
    CUDBGAdjAddrAction adjAction;
} adjust_address_t;

static CUDBGResult
gpudbgAdjustCodeAddress(CudbgDevice dev, DeviceFunction function, adjust_address_t *token)
{
    bool hidden;
    uint64_t physAddr;
    uint64_t adjustedPhysAddr;
    CUDBGResult res;

    CUDBG_VERIFY(function, CUDBG_ERROR_INTERNAL, "function is NULL\n");

    /* Disallow hidden functions */
    res = haloInHiddenFunction(function, &hidden);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "error calling haloInHiddenFunction\n");
    CUDBG_VERIFY(!hidden, CUDBG_ERROR_INVALID_ADDRESS, "in hidden function %s\n",
                 function->name);

    physAddr = token->originalVirtAddr - function->virtAddrBase;

    if (physAddr >= function->codeSize)
        return CUDBG_SUCCESS;

    res = dev->halo.adjustCodeAddress(physAddr, &adjustedPhysAddr, token->adjAction);
    if (res != CUDBG_SUCCESS) {
        API_TRACE(0, "Failed to get adjusted breakpoint address for 0x" PRIx64 "\n", token->adjustedVirtAddr);
        return res;
    }

    token->adjustedVirtAddr = adjustedPhysAddr + function->virtAddrBase;

    API_TRACE_FUNCTION(3, "Original: %016" PRIxPTR " Adjusted: %016" PRIx64 "\n",
                       token->originalVirtAddr, token->adjustedVirtAddr);
    return CUDBG_SUCCESS;
}

static CUDBGResult
gpudbgSetFunctionBreakpoints(DeviceFunction function, breakpoint_token_t *token)
{
    uint64_t virtAddr;
    uint64_t physAddr;
    Breakpoint bp;
    CudbgDevice dev;
    CUDBGResult res;
    TOOLSresult tres = TOOLS_SUCCESS;

    virtAddr = token->virtAddr;
    physAddr = virtAddr - function->virtAddrBase;
    if (physAddr >= function->codeSize)
        return CUDBG_SUCCESS;

    bp = (Breakpoint)toolsHashMapFind(function->breakPoints, tHashMapNumToKey(physAddr));
    if (bp)
        return CUDBG_SUCCESS;

    dev = function->module->context->dev;
    if (token->devId != (uint32_t)~0 && token->devId != (uint32_t)dev->deviceIdx)
        return CUDBG_SUCCESS;

    bp = (Breakpoint)calloc(1, sizeof(*bp));
    if (!bp) {
        API_TRACE_FUNCTION(0, "Error : Failed to allocate breakpoint\n");
        return CUDBG_ERROR_INTERNAL;
    }

    bp->devVAddr = physAddr + function->devVAddr;
    bp->gpuAddr = physAddr + function->gpuAddrBase;
    bp->isSet = false;
    bp->context = function->module->context;

    tres = toolsHashMapInsert(function->breakPoints, tHashMapNumToKey(physAddr), bp);
    if (tres != TOOLS_SUCCESS) {
        API_TRACE_FUNCTION(0, "Failed to insert into function->breakpoints map (tres=%u)\n", tres);
        return CUDBG_ERROR_UNKNOWN;
    }

    if (token->insertBpOnSet) {
        (void)insertBreakpoint(tHashMapPtrToKey(NULL), (void*)bp, (void*)&res);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to insert breakpoint\n");
    }

    API_TRACE_FUNCTION(3, "%016" PRIxPTR " [DevVA:%016" PRIx64 "] \n", virtAddr, bp->devVAddr);
    return CUDBG_SUCCESS;
}

static CUDBGResult
gpudbgSetPatchBreakpoints(DebugPatch patch, breakpoint_token_t *token)
{
    uint64_t virtAddr;
    uint64_t physAddr;
    Breakpoint bp;
    CudbgDevice dev;
    CUDBGResult res;
    TOOLSresult tres = TOOLS_SUCCESS;

    virtAddr = token->virtAddr;
    physAddr = virtAddr - patch->virtAddr;
    if (physAddr >= patch->size)
        return CUDBG_SUCCESS;

    bp = (Breakpoint)toolsHashMapFind(patch->breakPoints, tHashMapNumToKey(physAddr));
    if (bp)
        return CUDBG_SUCCESS;

    dev = patch->context->dev;
    if (token->devId != (uint32_t)~0 && token->devId != (uint32_t)dev->deviceIdx)
        return CUDBG_SUCCESS;

    bp = (Breakpoint)calloc(1, sizeof(*bp));
    if (!bp) {
        API_TRACE_FUNCTION(0, "Error : Failed to allocate breakpoint\n");
        return CUDBG_ERROR_INTERNAL;
    }

    bp->devVAddr = physAddr + patch->devVAddr;
    bp->gpuAddr = physAddr + patch->gpuAddr;
    bp->isSet = false;
    bp->context = patch->context;

    tres = toolsHashMapInsert(patch->breakPoints, tHashMapNumToKey(physAddr), bp);
    if (tres != TOOLS_SUCCESS) {
        API_TRACE_FUNCTION(0, "Failed to insert into patch->breakpoints map (tres=%u)\n", tres);
        return CUDBG_ERROR_UNKNOWN;
    }

    if (token->insertBpOnSet) {
        (void)insertBreakpoint(tHashMapPtrToKey(NULL), (void*)bp, (void*)&res);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to insert breakpoint\n");
    }

    API_TRACE_FUNCTION(3, "%016" PRIxPTR " [DevVA:%016" PRIx64 "] \n", virtAddr, bp->devVAddr);

    return CUDBG_SUCCESS;
}

static CUDBGResult
gpudbgUnsetFunctionBreakpoints(DeviceFunction function, breakpoint_token_t *token)
{
    uint64_t virtAddr;
    uint64_t physAddr;
    Breakpoint bp;
    CudbgDevice dev;
    CUDBGResult res;
    uint64_t bpDevVAddr = 0;
    TOOLSresult tres = TOOLS_SUCCESS;

    virtAddr = token->virtAddr;
    physAddr = virtAddr - function->virtAddrBase;
    if (physAddr >= function->codeSize)
        return CUDBG_SUCCESS;

    bp = (Breakpoint)toolsHashMapFind(function->breakPoints, tHashMapNumToKey(physAddr));
    if (!bp)
        return CUDBG_SUCCESS;

    dev = function->module->context->dev;
    if (token->devId != (uint32_t)~0 && token->devId != (uint32_t)dev->deviceIdx)
        return CUDBG_SUCCESS;

    /* Actually remove the breakpoint from device memory. */
    (void)removeBreakpoint(tHashMapPtrToKey(NULL), (void*)bp, (void*)&res);
    if (res != CUDBG_SUCCESS) {
        /* Ideally, we should propagate this error out of the API, but since
           it's okay for this to fail in some cases, we can't do that yet. */
        API_TRACE_FUNCTION(1, "Ignoring error removing breakpoint "
                           "(devVAddr=%" PRIx64 ", res=%d)\n",
                           bp->devVAddr, res);
    }

    bpDevVAddr = bp->devVAddr;

    tres = toolsHashMapRemove(function->breakPoints, tHashMapNumToKey(physAddr), deleteBreakpoint);
    if (tres != TOOLS_SUCCESS) {
        API_TRACE_FUNCTION(0, "Failed to remove breakpoint from map (tres=%u)\n", tres);
        return CUDBG_ERROR_UNKNOWN;
    }

    API_TRACE_FUNCTION(3, "%016" PRIxPTR " [%016" PRIx64 "]\n", virtAddr, bpDevVAddr);
    (void)bpDevVAddr;

    return CUDBG_SUCCESS;
}

static CUDBGResult
gpudbgUnsetPatchBreakpoints(DebugPatch patch, breakpoint_token_t *token)
{
    uint64_t virtAddr;
    uint64_t physAddr;
    Breakpoint bp;
    CudbgDevice dev;
    CUDBGResult res;
    TOOLSresult tres = TOOLS_SUCCESS;

    virtAddr = token->virtAddr;
    physAddr = virtAddr - patch->virtAddr;
    if (physAddr >= patch->size)
        return CUDBG_SUCCESS;

    bp = (Breakpoint)toolsHashMapFind(patch->breakPoints, tHashMapNumToKey(physAddr));
    if (!bp)
        return CUDBG_SUCCESS;

    dev = patch->context->dev;
    if (token->devId != (uint32_t)~0 && token->devId != (uint32_t)dev->deviceIdx)
        return CUDBG_SUCCESS;

    /* Actually remove the breakpoint from device memory. */
    (void)removeBreakpoint(tHashMapPtrToKey(NULL), (void*)bp, (void*)&res);
    if (res != CUDBG_SUCCESS) {
        /* Ideally, we should propagate this error out of the API, but since
           it's okay for this to fail in some cases, we can't do that yet. */
        API_TRACE_FUNCTION(1, "Ignoring error removing breakpoint "
                           "(devVAddr=%" PRIx64 ", res=%d)\n",
                           bp->devVAddr, res);
    }

    tres = toolsHashMapRemove(patch->breakPoints, tHashMapNumToKey(physAddr), deleteBreakpoint);
    if (tres != TOOLS_SUCCESS) {
        API_TRACE_FUNCTION(0, "Failed to remove breakpoint from map (tres=%u)\n", tres);
        return CUDBG_ERROR_UNKNOWN;
    }

    API_TRACE_FUNCTION(3, "%016" PRIxPTR " [%016" PRIx64 "]\n", virtAddr, bp->devVAddr);

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::setBreakpoint31
 * \brief Sets a breakpoint at the given instruction address.
 *
 * Since CUDA 3.0.
 *
 * \deprecated in CUDA 3.2.
 *
 * \ingroup BP
 *
 * \param addr - instruction address
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_INVALID_ADDRESS
 *
 * \sa unsetBreakpoint31
 */
CUDBGResult
gpudbgSetBreakpoint31(uint64_t addr)
{
    CUDBGResult res = CUDBG_SUCCESS;
    breakpoint_token_t token;
    DeviceFunction func = NULL;
    bool hidden;

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT    |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    token.devId = ~0;
    token.virtAddr = addr;
    token.insertBpOnSet = false;

    /* Find the function for the requested VA */
    func = (DeviceFunction)toolsRangeMapLookupByAddr(virtAddrToFunction, token.virtAddr);
    if (func) {
        /* Disallow hidden functions */
        res = haloInHiddenFunction(func, &hidden);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "error calling haloInHiddenFunction\n");
        CUDBG_VERIFY(!hidden, CUDBG_ERROR_INVALID_ADDRESS, "in hidden function %s\n",
                     func->name);

        /* Found a function at this va. Set the breakpoint for it */
        res = gpudbgSetFunctionBreakpoints(func, &token);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failure when setting breakpoints for function %s\n", func->name);
    }

    return res;
}


/**
 * \fn CUDBGAPI_st::unsetBreakpoint31
 * \brief Unsets a breakpoint at the given instruction address.
 *
 * Since CUDA 3.0.
 *
 * \deprecated in CUDA 3.2.
 *
 * \ingroup BP
 *
 * \param addr - instruction address
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa setBreakpoint31
 */
CUDBGResult
gpudbgUnsetBreakpoint31(uint64_t addr)
{
    CUDBGResult res = CUDBG_SUCCESS;
    breakpoint_token_t token;
    DeviceFunction func = NULL;

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT    |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    token.devId = ~0;
    token.virtAddr = addr;

    /* Find the function for the requested VA */
    func = (DeviceFunction)toolsRangeMapLookupByAddr(virtAddrToFunction, token.virtAddr);
    if (func) {
        /* Found a function at this va. Unset the breakpoint for it */
        res = gpudbgUnsetFunctionBreakpoints(func, &token);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failure when unsetting breakpoints for function %s\n", func->name);
    }

    return res;
}

/**
 * \fn CUDBGAPI_st::setBreakpoint
 * \brief Sets a breakpoint at the given instruction address for the given device.
 *        Before setting a breakpoint, CUDBGAPI_st::getAdjustedCodeAddress should be
 *        called to get the adjusted breakpoint address.
 *
 * Since CUDA 3.2.
 *
 * \ingroup BP
 *
 * \param dev - the device index
 * \param addr - instruction address
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_INVALID_ADDRESS,
 * \return CUDBG_ERROR_INVALID_DEVICE
 *
 * \sa unsetBreakpoint
 */
CUDBGResult
gpudbgSetBreakpoint(uint32_t devId, uint64_t addr)
{
    CUDBGResult res = CUDBG_SUCCESS;
    breakpoint_token_t token;
    DeviceFunction func = NULL;
    bool hidden;
#ifndef RELEASE
    bool inPatch = false;
    CudbgDevice dev = NULL;
    DebugPatch patch = NULL;
#endif

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_SUSPENDED),
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    API_TRACE_FUNCTION(10, "device %d addr 0x%" PRIx64 "\n", devId, addr);

    token.devId = devId;
    token.virtAddr = addr;
    token.insertBpOnSet = false;

    /* Find the function for the requested VA */
    func = (DeviceFunction)toolsRangeMapLookupByAddr(virtAddrToFunction, token.virtAddr);
    if (func) {
        /* Found a function at this va */

        /* Disallow hidden functions */
        res = haloInHiddenFunction(func, &hidden);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "error calling haloInHiddenFunction\n");
        CUDBG_VERIFY(!hidden, CUDBG_ERROR_INVALID_ADDRESS, "in hidden function %s\n",
                     func->name);

        /* Set the breakpoint for it */
        res = gpudbgSetFunctionBreakpoints(func, &token);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failure when setting breakpoints for function %s\n", func->name);
        return CUDBG_SUCCESS;
    }

#ifndef RELEASE
    /* Find the patch for the requested VA */
    dev = haloGlobals.device[devId];

    if (dev->activeContext) {
        res = haloInPatchRegion(addr, dev->activeContext, &patch,
                                CUDBG_PATCH_ALL, &inPatch, true);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "haloInPatchRegion failed\n");

        if (inPatch && patch && patch->debug) {
            /* Found a patch at this va. Set the breakpoint for it */
            res = gpudbgSetPatchBreakpoints(patch, &token);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failure when setting breakpoints for patch %d\n",
                         patch->patchId);
            return CUDBG_SUCCESS;
        }
    }
#endif

    CUDBG_ERROR("Could not locate code for breakpoint 0x%016" PRIx64 "\n", addr);

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::getAdjustedCodeAddress
 * \brief The client must call this function before inserting a breakpoint, or when the previous
 *        or next code address is needed.
 *        Returns the adjusted code address for a given code address for a given device.
 *
 * Since CUDA 5.5.
 *
 * \ingroup BP
 *
 * \param devId - the device index
 * \param addr - instruction address
 * \param adjustedAddress - adjusted address
 * \param adjAction - whether the adjusted next, previous or current address is needed
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_INVALID_ADDRESS,
 * \return CUDBG_ERROR_INVALID_DEVICE
 *
 * \sa unsetBreakpoint
 */
CUDBGResult
gpudbgGetAdjustedCodeAddress(uint32_t devId, uint64_t addr, uint64_t *adjustedAddress, CUDBGAdjAddrAction adjAction)
{
    CUDBGResult res = CUDBG_SUCCESS;
    adjust_address_t token;
    DeviceFunction func = NULL;
    CudbgDevice dev;

    CUDBG_VERIFY(adjustedAddress, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in gpudbgGetAdjustedCodeAddress.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_SUSPENDED),
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    token.originalVirtAddr = addr;
    token.adjustedVirtAddr = addr;
    token.adjAction = adjAction;

    dev = haloGlobals.device[devId];

    func = (DeviceFunction)toolsRangeMapLookupByAddr(virtAddrToFunction, token.originalVirtAddr);
    if (func) {
        res = gpudbgAdjustCodeAddress(dev, func, &token);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Could not adjust address\n");
    }

    *adjustedAddress = token.adjustedVirtAddr;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::unsetBreakpoint
 * \brief Unsets a breakpoint at the given instruction address for the given device.
 *
 * Since CUDA 3.2.
 *
 * \ingroup BP
 *
 * \param dev - the device index
 * \param addr - instruction address
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_INVALID_ADDRESS,
 * \return CUDBG_ERROR_INVALID_DEVICE
 *
 * \sa setBreakpoint
 */
CUDBGResult
gpudbgUnsetBreakpoint(uint32_t devId, uint64_t addr)
{
    CUDBGResult res = CUDBG_SUCCESS;
    breakpoint_token_t token;
    DeviceFunction func = NULL;
#ifndef RELEASE
    bool inPatch = false;
    CudbgDevice dev = NULL;
    DebugPatch patch = NULL;
#endif

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_SUSPENDED),
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    token.devId = devId;
    token.virtAddr =  addr;

    /* Find the function for the requested VA */
    func = (DeviceFunction)toolsRangeMapLookupByAddr(virtAddrToFunction, token.virtAddr);
    if (func) {
        /* Found a function at this va. Unset the breakpoint for it */
        res = gpudbgUnsetFunctionBreakpoints(func, &token);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failure when unsetting breakpoints for function %s\n", func->name);
        return CUDBG_SUCCESS;
    }

#ifndef RELEASE
    /* Find the patch for the requested VA */
    dev = haloGlobals.device[devId];

    if (dev->activeContext) {
        res = haloInPatchRegion(addr, dev->activeContext, &patch,
                                CUDBG_PATCH_ALL, &inPatch, true);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "haloInPatchRegion failed\n");

        if (inPatch && patch) {
            /* Found a patch at this va. Unset the breakpoint for it */
            res = gpudbgUnsetPatchBreakpoints(patch, &token);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failure when unsetting breakpoints for patch %d\n",
                         patch->patchId);
            return CUDBG_SUCCESS;
        }
    }
#endif

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::readGridId50
 * \brief Reads the CUDA grid index running on a valid warp.
 *
 * Since CUDA 3.0.
 *
 * \deprecated in CUDA 5.5.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param gridId - the returned CUDA grid index
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readBlockIdx
 * \sa readThreadIdx
 * \sa readBrokenWarps
 * \sa readValidWarps
 * \sa readValidLanes
 * \sa readActiveLanes
 */
CUDBGResult
gpudbgReadGridId50(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t *gridId)
{
    uint64_t gridId64 = 0;
    CUDBGResult res;

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT    |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    CUDBG_VERIFY(gridId, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    res = gpudbgReadGridId(devId, sm, wp, &gridId64);

    *gridId = (uint32_t)gridId64;

    return res;
}

/**
 * \fn CUDBGAPI_st::readGridId
 * \brief Reads the 64-bit CUDA grid index running on a valid warp.
 *
 * Since CUDA 5.5.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param gridId - the returned 64-bit CUDA grid index
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readBlockIdx
 * \sa readThreadIdx
 * \sa readBrokenWarps
 * \sa readValidWarps
 * \sa readValidLanes
 * \sa readActiveLanes
 */
CUDBGResult
gpudbgReadGridId(uint32_t devId, uint32_t sm, uint32_t wp, uint64_t *gridId64)
{
    CudbgDevice dev;

    CUDBG_VERIFY(gridId64, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID),
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    *gridId64 = dev->smState[sm].warp[wp].gridId64;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::readBlockIdx32
 * \brief Reads the two-dimensional CUDA block index running on a valid warp.
 *
 * Since CUDA 3.0.
 *
 * \deprecated in CUDA 4.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param blockIdx - the returned CUDA block index
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readGridId
 * \sa readThreadIdx
 * \sa readBrokenWarps
 * \sa readValidWarps
 * \sa readValidLanes
 * \sa readActiveLanes
 */
CUDBGResult
gpudbgReadBlockIdx32(uint32_t devId, uint32_t sm, uint32_t wp, CuDim2 *blockIdx)
{
    CuDim3 blockIdx3;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID),
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    CUDBG_VERIFY(blockIdx, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in gpudbgReadBlockIdx32.\n");

    res = gpudbgReadBlockIdx(devId, sm, wp, &blockIdx3);
    if (res)
        return res;

    blockIdx->x = blockIdx3.x;
    blockIdx->y = blockIdx3.y;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::readBlockIdx
 * \brief Reads the CUDA block index running on a valid warp.
 *
 * Since CUDA 4.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param blockIdx - the returned CUDA block index
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readGridId
 * \sa readThreadIdx
 * \sa readBrokenWarps
 * \sa readValidWarps
 * \sa readValidLanes
 * \sa readActiveLanes
 */
CUDBGResult
gpudbgReadBlockIdx(uint32_t devId, uint32_t sm, uint32_t wp, CuDim3 *blockIdx)
{
    CudbgDevice dev;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(blockIdx, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID),
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    res = dev->halo.read_blockIdx(dev, sm, wp, blockIdx);

    return res;
}

/**
 * \fn CUDBGAPI_st::readThreadIdx
 * \brief Reads the CUDA thread index running on valid lane.
 *
 * Since CUDA 3.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param threadIdx - the returned CUDA thread index
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readGridId
 * \sa readBlockIdx
 * \sa readBrokenWarps
 * \sa readValidWarps
 * \sa readValidLanes
 * \sa readActiveLanes
 */
CUDBGResult
gpudbgReadThreadIdx(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, CuDim3 *threadIdx)
{
    CudbgDevice dev;

    CUDBG_VERIFY(threadIdx, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_LN_VALID),
                    devId, sm, wp, ln);

    dev = haloGlobals.device[devId];

    *threadIdx = dev->smState[sm].warp[wp].threadIdx[ln];

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::readBrokenWarps
 * \brief Reads the bitmask of warps that are at a breakpoint on a given SM.
 *
 * Since CUDA 3.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param brokenWarpsMask - the returned bitmask of broken warps
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readGridId
 * \sa readBlockIdx
 * \sa readThreadIdx
 * \sa readValidWarps
 * \sa readValidLanes
 * \sa readActiveLanes
 */
CUDBGResult
gpudbgReadBrokenWarps(uint32_t devId, uint32_t sm, uint64_t *brokenWarps)
{
    CudbgDevice dev;

    CUDBG_VERIFY(brokenWarps, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_SM),
                    devId, sm,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    *brokenWarps = (uint64_t)warpBitmaskGetBits(&dev->smState[sm].state.brokenwarps, 0, 64);

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::readValidWarps
 * \brief Reads the bitmask of valid warps on a given SM.
 *
 * Since CUDA 3.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param validWarpsMask - the returned bitmask of valid warps
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readGridId
 * \sa readBlockIdx
 * \sa readThreadIdx
 * \sa readBrokenWarps
 * \sa readValidLanes
 * \sa readActiveLanes
 */
CUDBGResult
gpudbgReadValidWarps(uint32_t devId, uint32_t sm, uint64_t *validWarps)
{
    CudbgDevice dev;

    CUDBG_VERIFY(validWarps, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_SM),
                    devId, sm,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    /*  Don't return a valid mask till attach is complete and the frontend is in
        a coherent state. */
    if (haloGlobals.state->attachState != HALO_ATTACH_STATE_IN_PROGRESS)
        *validWarps = (uint64_t)warpBitmaskGetBits(&dev->smState[sm].state.tidValid, 0, 64);
    else
        *validWarps = 0;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::readValidLanes
 * \brief Reads the bitmask of valid lanes on a given warp.
 *
 * Since CUDA 3.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param validLanesMask - the returned bitmask of valid lanes
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readGridId
 * \sa readBlockIdx
 * \sa readThreadIdx
 * \sa readBrokenWarps
 * \sa readValidWarps
 * \sa readActiveLanes
 */
CUDBGResult
gpudbgReadValidLanes(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t *validLanes)
{
    CudbgDevice dev;

    CUDBG_VERIFY(validLanes, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID),
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    *validLanes = dev->smState[sm].warp[wp].validLanes;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::readActiveLanes
 * \brief Reads the bitmask of active lanes on a valid warp.
 *
 * Since CUDA 3.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param activeLanesMask - the returned bitmask of active lanes
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readGridId
 * \sa readBlockIdx
 * \sa readThreadIdx
 * \sa readBrokenWarps
 * \sa readValidWarps
 * \sa readValidLanes
 */
CUDBGResult
gpudbgReadActiveLanes(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t *activeLanes)
{
    CudbgDevice dev;

    CUDBG_VERIFY(activeLanes, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID),
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    *activeLanes = dev->smState[sm].warp[wp].activeMask;

    return CUDBG_SUCCESS;
}



/**
 * \fn CUDBGAPI_st::getDeviceType
 * \brief Get the string description of the device.
 *
 * Since CUDA 3.0.
 *
 * \ingroup DEV
 *
 * \param dev - device index
 * \param buf - the destination buffer
 * \param sz - the size of the buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_BUFFER_TOO_SMALL,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa getSMType
 */
CUDBGResult
gpudbgGetDeviceType(uint32_t devId, char *buf, uint32_t sz)
{
    size_t len;

    CUDBG_VERIFY(buf, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_STATUS),
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    len = strlen(globals.devices[devId]->state.name);
    CUDBG_VERIFY(len < sz, CUDBG_ERROR_BUFFER_TOO_SMALL, "Buffer too small.\n");

    memcpy(buf, globals.devices[devId]->state.name, len+1);

    return CUDBG_SUCCESS;
}


/**
 * \fn CUDBGAPI_st::getSmType
 * \brief Get the SM type of the device.
 *
 * Since CUDA 3.0.
 *
 * \ingroup DEV
 *
 * \param dev - device index
 * \param buf - the destination buffer
 * \param sz - the size of the buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_BUFFER_TOO_SMALL,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa getDeviceType
 */
CUDBGResult
gpudbgGetSmType(uint32_t devId, char *buf, uint32_t sz)
{
    size_t len;

    CUDBG_VERIFY(buf, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_STATUS),
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    len = strlen(globals.devices[devId]->state.isav);
    CUDBG_VERIFY(len < sz, CUDBG_ERROR_BUFFER_TOO_SMALL, "Buffer too small.\n");

    memcpy(buf, globals.devices[devId]->state.isav, len+1);

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::getDeviceName
 * \brief Get the device name string.
 *
 * Since CUDA 6.5.
 *
 * \ingroup DEV
 *
 * \param dev - device index
 * \param buf - the destination buffer
 * \param sz - the size of the buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_BUFFER_TOO_SMALL,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa getSMType
 * \sa getDeviceType
 */
CUDBGResult
gpudbgGetDeviceName(uint32_t devId, char *buf, uint32_t sz)
{
    CUresult rc;

    CUDBG_VERIFY(buf, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_STATUS),
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    CU_ASSERT(globals.devices[devId]->dmal.initialized);

    rc = globals.devices[devId]->dmal.deviceGetName(globals.devices[devId], buf, sz);
    CUDBG_VERIFY( rc == CUDA_SUCCESS, CUDBG_ERROR_BUFFER_TOO_SMALL, "Buffer too small.\n");

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::getNumDevices
 * \brief Get the number of installed CUDA devices.
 *
 * Since CUDA 3.0.
 *
 * \ingroup DEV
 *
 * \param numDev - the returned number of devices
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa getNumSMs
 * \sa getNumWarps
 * \sa getNumLanes
 * \sa getNumRegisters
 */
CUDBGResult
gpudbgGetNumDevices(uint32_t *numDevs)
{
    CUDBG_VERIFY(numDevs, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    *numDevs = globals.numDevices;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::getNumSMs
 * \brief Get the total number of SMs on the device.
 *
 * Since CUDA 3.0.
 *
 * \ingroup DEV
 *
 * \param dev - device index
 * \param numSMs - the returned number of SMs
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa getNumDevices
 * \sa getNumWarps
 * \sa getNumLanes
 * \sa getNumRegisters
 */
CUDBGResult
gpudbgGetNumSMs(uint32_t devId, uint32_t *numSMs)
{
    CUDBG_VERIFY(numSMs, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_STATUS),
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    *numSMs = haloGlobals.device[devId]->halo.deviceInfo.numSMs;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::getNumWarps
 * \brief Get the number of warps per SM on the device.
 *
 * Since CUDA 3.0.
 *
 * \ingroup DEV
 *
 * \param dev - device index
 * \param numWarps - the returned number of warps
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa getNumDevices
 * \sa getNumSMs
 * \sa getNumLanes
 * \sa getNumRegisters
 */
CUDBGResult
gpudbgGetNumWarps(uint32_t devId, uint32_t *numWarps)
{
    CUDBG_VERIFY(numWarps, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_STATUS),
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    *numWarps = haloGlobals.device[devId]->halo.deviceInfo.numWarpsPrSM;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::getNumLanes
 * \brief Get the number of lanes per warp on the device.
 *
 * Since CUDA 3.0.
 *
 * \ingroup DEV
 *
 * \param dev - device index
 * \param numLanes - the returned number of lanes
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa getNumDevices
 * \sa getNumSMs
 * \sa getNumWarps
 * \sa getNumRegisters
 */
CUDBGResult
gpudbgGetNumLanes(uint32_t devId, uint32_t *numLanes)
{
    CUDBG_VERIFY(numLanes, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_STATUS),
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    *numLanes = haloGlobals.device[devId]->halo.deviceInfo.numLanesPrWarp;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::getNumRegisters
 * \brief Get the number of registers per lane on the device.
 *
 * Since CUDA 3.0.
 *
 * \ingroup DEV
 *
 * \param dev - device index
 * \param numRegs - the returned number of registers
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa getNumDevices
 * \sa getNumSMs
 * \sa getNumWarps
 * \sa getNumLanes
 */
CUDBGResult
gpudbgGetNumRegisters(uint32_t devId, uint32_t *numRegs)
{
    CUDBG_VERIFY(numRegs, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_STATUS),
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    *numRegs = haloGlobals.device[devId]->halo.deviceInfo.numRegsPrLane;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::getNumPredicates
 * \brief Get the number of predicate registers per lane on the device.
 *
 * Since CUDA 6.5.
 *
 * \ingroup DEV
 *
 * \param dev - device index
 * \param numPredicates - the returned number of predicate registers
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa getNumDevices
 * \sa getNumSMs
 * \sa getNumWarps
 * \sa getNumLanes
 * \sa getNumRegisters
 */
CUDBGResult
gpudbgGetNumPredicates(uint32_t devId, uint32_t *numPredicates)
{
    CUDBG_VERIFY(numPredicates, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_STATUS),
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    *numPredicates = haloGlobals.device[devId]->halo.deviceInfo.numPredicatesPrLane;

    return CUDBG_SUCCESS;
}
/**
 * \fn CUDBGAPI_st::getGridDim32
 * \brief Get the number of blocks in the given grid.
 *
 * Since CUDA 3.0.
 *
 * \deprecated in CUDA 4.0.
 *
 * \ingroup GRID
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param gridDim - the returned number of blocks in the grid
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_GRID,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa getBlockDim
 */
CUDBGResult
gpudbgGetGridDim32(uint32_t devId, uint32_t sm, uint32_t wp, CuDim2 *gridDim)
{
    CuDim3 gridDim3;
    CUDBGResult res;

    CUDBG_VERIFY(gridDim, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    res = gpudbgGetGridDim(devId, sm, wp, &gridDim3);
    if (res)
        return res;

    gridDim->x = gridDim3.x;
    gridDim->y = gridDim3.y;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::getGridDim
 * \brief Get the number of blocks in the given grid.
 *
 * Since CUDA 4.0.
 *
 * \ingroup GRID
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param gridDim - the returned number of blocks in the grid
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_GRID,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa getBlockDim
 */
CUDBGResult
gpudbgGetGridDim(uint32_t devId, uint32_t sm, uint32_t wp, CuDim3 *gridDim)
{
    Grid grid;
    CUDBGResult res;
    uint64_t gridId64;
    CudbgDevice dev;

    CUDBG_VERIFY(gridDim, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    res = gpudbgReadGridId(devId, sm, wp, &gridId64);
    if (res)
        return res;

    dev = haloGlobals.device[devId];
    if (clientRevision > API_REVISION_5_5)
        CUDBG_VERIFY(dev->suspended, CUDBG_ERROR_RUNNING_DEVICE, "Device is still running\n");

    /* XXX This could possibly be optimized by storing the grid in the
       warp */
    grid = haloStateDeviceGetGrid(dev, gridId64);
    CUDBG_VERIFY(grid, CUDBG_ERROR_INVALID_GRID, "Invalid grid.\n");

    *gridDim = grid->gridDim;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::getBlockDim
 * \brief Get the number of threads in the given block.
 *
 * Since CUDA 3.0.
 *
 * \ingroup GRID
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param blockDim - the returned number of threads in the block
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_GRID,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa getGridDim
 */
CUDBGResult
gpudbgGetBlockDim(uint32_t devId, uint32_t sm, uint32_t wp, CuDim3 *blockDim)
{
    Grid grid;
    CUDBGResult res;
    uint64_t gridId64;

    CUDBG_VERIFY(blockDim, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);


    res = gpudbgReadGridId(devId, sm, wp, &gridId64);
    if (res)
        return res;

    /* XXX This could possibly be optimized by storing the grid in the
       warp */
    grid = haloStateDeviceGetGrid(haloGlobals.device[devId], gridId64);
    CUDBG_VERIFY(grid, CUDBG_ERROR_INVALID_GRID, "Invalid grid.\n");

    *blockDim = grid->blockDim;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::getTID
 * \brief Get the ID of the Linux thread hosting the context of the grid.
 *
 * Since CUDA 3.0.
 *
 * \ingroup GRID
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param tid - the returned thread id
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_GRID,
 * \return CUDBG_ERROR_UNINITIALIZED
 */
CUDBGResult
gpudbgGetTID(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t *tid)
{
    Grid grid;
    CUDBGResult res;
    uint64_t gridId64;

    CUDBG_VERIFY(tid, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    res = gpudbgReadGridId(devId, sm, wp, &gridId64);

    if (res)
        return res;

    /* XXX This could possibly be optimized by storing the grid in the
       warp */
    grid = haloStateDeviceGetGrid(haloGlobals.device[devId], gridId64);
    CUDBG_VERIFY(grid, CUDBG_ERROR_INVALID_GRID, "Invalid grid.\n");

    *tid = grid->function->module->context->hostThreadId;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::getElfImage32
 * \brief Get the relocated or non-relocated ELF image and size for the grid on the given device.
 *
 * Since CUDA 3.0.
 *
 * \deprecated in CUDA 4.0.
 *
 * \ingroup GRID
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param relocated - set to true to specify the relocated ELF image, false otherwise
 * \param *elfImage - pointer to the ELF image
 * \param size - size of the ELF image (32 bits)
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_GRID,
 * \return CUDBG_ERROR_UNINITIALIZED
 */
CUDBGResult
gpudbgGetElfImage32(uint32_t devId, uint32_t sm, uint32_t wp, bool relocated, void **elfImage, uint32_t *size)
{
    uint64_t size64;
    CUDBGResult res;

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    res = gpudbgGetElfImage(devId, sm, wp, relocated, elfImage, &size64);
    if (res != CUDBG_SUCCESS)
        return res;

    *size = (uint32_t) size64;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::getElfImage
 * \brief Get the relocated or non-relocated ELF image and size for the grid on the given device
 *
 * Since CUDA 4.0.
 *
 * \ingroup GRID
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param relocated - set to true to specify the relocated ELF image, false otherwise
 * \param *elfImage - pointer to the ELF image
 * \param size - size of the ELF image (64 bits)
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_GRID,
 * \return CUDBG_ERROR_UNINITIALIZED
 */
CUDBGResult
gpudbgGetElfImage(uint32_t devId, uint32_t sm, uint32_t wp, bool relocated, void **elfImage, uint64_t *size)
{
    Grid grid;
    CUDBGResult res;
    uint64_t gridId64;

    CUDBG_VERIFY(elfImage && size, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID),
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    res = gpudbgReadGridId(devId, sm, wp, &gridId64);
    if (res)
        return res;

    /* XXX This could possibly be optimized by storing the grid in the
       warp */
    grid = haloStateDeviceGetGrid(haloGlobals.device[devId], gridId64);
    CUDBG_VERIFY(grid, CUDBG_ERROR_INVALID_GRID, "Invalid grid.\n");

    if (relocated)
        *elfImage = grid->function->module->relocatedElfImage;
    else
        *elfImage = grid->function->module->nonRelocatedElfImage;

    *size = grid->function->module->elfImageSize;

    return CUDBG_SUCCESS;
}

typedef struct {
    uint64_t handle;
    DeviceModule mod;
} module_lookup_t;

static CUDBGResult
ctxGetModuleByHandle(Context ctx, void *data)
{
    module_lookup_t *token;

    CUDBG_VERIFY(ctx && data, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    token = (module_lookup_t*)data;

    if (!token->mod)
        token->mod = (DeviceModule)toolsHashMapFind(ctx->modules, token->handle);

    return CUDBG_SUCCESS;
}

static DeviceModule
gpudbgGetModuleByHandle(uint64_t handle)
{
    CUDBGResult res = CUDBG_SUCCESS;
    module_lookup_t token;

    token.mod = NULL;
    token.handle = handle;

    res = haloStateTraverseContexts(ctxGetModuleByHandle, &token);
    if (res != CUDBG_SUCCESS)
        return NULL;

    return token.mod;
}

/**
 * \fn CUDBGAPI_st::getElfImageByHandle
 * \brief Get the relocated or non-relocated ELF image for the given handle on the given device
 *
 * The handle is provided in the ELF Image Loaded notification event.
 *
 * Since CUDA 6.0.
 *
 * \ingroup DWARF
 *
 * \param devId - device index
 * \param handle - elf image handle
 * \param type - type of the requested ELF image
 * \param elfImage - pointer to the ELF image
 * \param elfImage_size - size of the ELF image
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_UNINITIALIZED
 */
CUDBGResult
gpudbgGetElfImageByHandle(uint32_t devId, uint64_t handle, CUDBGElfImageType type, void *elfImage, uint64_t size)
{
    DeviceModule mod;

    CUDBG_VERIFY (elfImage, CUDBG_ERROR_INVALID_ARGS, "Invalid arguemtns.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_ID),
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    mod = gpudbgGetModuleByHandle(handle);
    CUDBG_VERIFY((mod && mod->context && mod->context->dev),
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid elf handle.\n");

    CUDBG_VERIFY((mod->elfImageSize == size), CUDBG_ERROR_INVALID_ARGS, "Unexpected elf size.\n");
    if (type == CUDBG_ELF_IMAGE_TYPE_RELOCATED)
        memcpy (elfImage, mod->relocatedElfImage, (size_t)size);
    else if (type == CUDBG_ELF_IMAGE_TYPE_NONRELOCATED)
        memcpy (elfImage, mod->nonRelocatedElfImage, (size_t)size);
    else {
        CUDBG_ERROR ("Unexpected ELF type requested.\n");
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::getGridAttribute
 * \brief Get the value of a grid attribute
 *
 * Since CUDA 3.1.
 *
 * \ingroup GRID
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param attr - the attribute
 * \param value - the returned value of the attribute
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_GRID,
 * \return CUDBG_ERROR_INVALID_ATTRIBUTE,
 * \return CUDBG_ERROR_UNINITIALIZED
 */
CUDBGResult
gpudbgGetGridAttribute(uint32_t devId, uint32_t sm, uint32_t wp, CUDBGAttribute attr, uint64_t *value)
{
    CUDBGAttributeValuePair pair;
    CUDBGResult res;

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID),
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    pair.attribute = attr;

    res = gpudbgGetGridAttributes(devId, sm, wp, &pair, 1);
    if (res != CUDBG_SUCCESS)
        return res;

    *value = pair.value;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::getGridAttributes
 * \brief Get several grid attribute values in a single API call
 *
 * Since CUDA 3.1.
 *
 * \ingroup GRID
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param pairs - array of attribute/value pairs
 * \param numPairs - the number of attribute/values pairs in the array
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_GRID,
 * \return CUDBG_ERROR_INVALID_ATTRIBUTE,
 * \return CUDBG_ERROR_UNINITIALIZED
 */
CUDBGResult
gpudbgGetGridAttributes(uint32_t devId, uint32_t sm, uint32_t wp, CUDBGAttributeValuePair *pairs, uint32_t numPairs)
{
    Grid grid;
    CUDBGResult res;
    uint32_t pairId;
    uint64_t gridId64;
    CudbgDevice dev;

    CUDBG_VERIFY(pairs, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID),
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    res = gpudbgReadGridId(devId, sm, wp, &gridId64);
    if (res != CUDBG_SUCCESS)
        return res;

    dev = haloGlobals.device[devId];

    /* XXX This could possibly be optimized by storing the grid in the
       warp */
    grid = haloStateDeviceGetGrid(dev, gridId64);
    CUDBG_VERIFY(grid, CUDBG_ERROR_INVALID_GRID, "Invalid grid.\n");

    for (pairId = 0; pairId < numPairs; ++pairId) {
        switch (pairs[pairId].attribute) {
        case CUDBG_ATTR_GRID_LAUNCH_BLOCKING:
            pairs[pairId].value = grid->function->module->context->launchBlocking;
            break;
        case CUDBG_ATTR_GRID_TID:
            pairs[pairId].value = grid->function->module->context->hostThreadId;
            break;
        default:
            return CUDBG_ERROR_INVALID_ATTRIBUTE;
        }
    }

    return CUDBG_SUCCESS;
}


/**
 * \fn CUDBGAPI_st::readCodeMemory
 * \brief Reads content at address in the code memory segment.
 *
 * Since CUDA 3.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param addr - memory address
 * \param buf - buffer
 * \param sz - size of the buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_MEMORY_MAPPING_FAILED
 *
 * \sa readConstMemory
 * \sa readGenericMemory
 * \sa readParamMemory
 * \sa readSharedMemory
 * \sa readTextureMemory
 * \sa readLocalMemory
 * \sa readRegister
 * \sa readPC
 */
CUDBGResult
gpudbgReadCodeMemory(uint32_t devId, uint64_t addr, void *buf, uint32_t sz)
{
    CudbgDevice dev;

    CUDBG_VERIFY(buf, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_SUSPENDED) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    return ctxReadCodeMemory(dev->activeContext, addr, buf, sz, false);
}

static CUDBGResult
ctxReadCodeMemory(Context ctx, uint64_t addr, void *buf, uint32_t sz, bool skipPatch)
{
    CudbgDevice dev;
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t gpuPC, scanPC;
    DebugPatch patch;
    bool atEntry = false;
    uint32_t i = 0;
    uint64_t devVAddr;

    CUDBG_VERIFY(ctx && buf, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    dev = ctx->dev;

    res = translateVirtualAddrToPCAndDevVA(addr, ctx, &gpuPC, &devVAddr);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to translateVirtualAddrToPCAndDevVA failed in ctxReadCodeMemory\n");
        return res;
    }

    /* Fill in the requested buffer with the actual contents */
    res = dev->halo.readDeviceMemory(ctx, devVAddr, buf, sz);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to read code memory failed in ctxReadCodeMemory\n");
        return res;
    }

    /* Iterate over the region and replace all patch entry points with the
       original instructions */
    if (!skipPatch) {
        scanPC = gpuPC;
        while (scanPC - gpuPC < sz) {
            atEntry = false;

            res = haloIsPatchEntry(scanPC, ctx, &patch, CUDBG_PATCH_ALL,
                                   &atEntry);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                         "Call to haloIsPatchEntry failed in ctxReadCodeMemory\n");

            if (atEntry && !patch->debug) {
                CUDBG_VERIFY(sz >= patch->hopSize, CUDBG_ERROR_UNKNOWN, "Buffer size too small.\n");

                memcpy((char*)buf + (scanPC - gpuPC) , patch->origInst, patch->hopSize);
            }

            res = dev->halo.adjustCodeAddress(scanPC, &scanPC, CUDBG_ADJ_NEXT_ADDRESS);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get next physical pc\n");
        }
    }
    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::readConstMemory
 * \brief Reads content at address in the constant memory segment.
 *
 * Since CUDA 3.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param addr - memory address
 * \param buf - buffer
 * \param sz - size of the buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_MEMORY_MAPPING_FAILED
 *
 * \sa readCodeMemory
 * \sa readGenericMemory
 * \sa readParamMemory
 * \sa readSharedMemory
 * \sa readTextureMemory
 * \sa readLocalMemory
 * \sa readRegister
 * \sa readPC
 */
CUDBGResult
gpudbgReadConstMemory(uint32_t devId, uint64_t addr, void *buf, uint32_t sz)
{
    CudbgDevice dev;

    CUDBG_VERIFY(buf, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_SUSPENDED) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    return dev->halo.readGenericMemory(dev->activeContext, 0, 0, 0, addr, buf, sz);
}

/**
 * \fn CUDBGAPI_st::readGlobalMemory31
 * \brief Reads content at address in the global memory segment.
 *
 * Since CUDA 3.0.
 *
 * \deprecated in CUDA 3.2.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param addr - memory address
 * \param buf - buffer
 * \param sz - size of the buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_MEMORY_MAPPING_FAILED
 *
 * \sa readCodeMemory
 * \sa readConstMemory
 * \sa readParamMemory
 * \sa readSharedMemory
 * \sa readTextureMemory
 * \sa readLocalMemory
 * \sa readRegister
 * \sa readPC
 */
CUDBGResult
gpudbgReadGlobalMemory31(uint32_t devId, uint64_t addr, void *buf, uint32_t sz)
{
    CudbgDevice dev;

    CUDBG_VERIFY(buf, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_SUSPENDED) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    return dev->halo.readGenericMemory(dev->activeContext, 0, 0, 0, addr, buf, sz);
}

/**
 * \fn CUDBGAPI_st::readGlobalMemory55
 * \brief Reads content at address in the global memory segment (entire 40-bit VA on Fermi+).
 *
 * Since CUDA 3.2.
 *
 * \deprecated in CUDA 6.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param addr - memory address
 * \param buf - buffer
 * \param sz - size of the buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_MEMORY_MAPPING_FAILED,
 * \return CUDBG_ERROR_ADDRESS_NOT_IN_DEVICE_MEM
 *
 * \sa readCodeMemory
 * \sa readConstMemory
 * \sa readParamMemory
 * \sa readSharedMemory
 * \sa readTextureMemory
 * \sa readLocalMemory
 * \sa readRegister
 * \sa readPC
 */
CUDBGResult
gpudbgReadGlobalMemory55(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln,
                         uint64_t addr, void *buf, uint32_t sz)
{
    CUDBG_VERIFY(sz, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_VERIFY(buf, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB          |
                    CUDBG_API_CHECK_DEV_ID          |
                    CUDBG_API_CHECK_DEV_SUSPENDED   |
                    CUDBG_API_CHECK_DEV_STATUS      |
                    CUDBG_API_CHECK_SM              |
                    CUDBG_API_CHECK_WP              |
                    CUDBG_API_CHECK_WP_VALID        |
                    CUDBG_API_CHECK_LN              |
                    CUDBG_API_CHECK_LN_VALID,
                    devId, sm, wp, ln);

    return gpudbgReadGenericMemory(devId, sm, wp, ln, addr, buf, sz);
}

/**
 * \fn CUDBGAPI_st::readGenericMemory
 * \brief Reads content at an address in the generic address space.
 *        This function determines if the given address falls into the local, shared, or global memory window.
 *        It then accesses memory taking into account the hardware co-ordinates provided as inputs.
 *
 * Since CUDA 6.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param addr - memory address
 * \param buf - buffer
 * \param buf_size - size of the buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_MEMORY_MAPPING_FAILED,
 * \return CUDBG_ERROR_ADDRESS_NOT_IN_DEVICE_MEM
 *
 * \sa readCodeMemory
 * \sa readConstMemory
 * \sa readParamMemory
 * \sa readSharedMemory
 * \sa readTextureMemory
 * \sa readLocalMemory
 * \sa readRegister
 * \sa readPC
 */
CUDBGResult
gpudbgReadGenericMemory(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln,
                        uint64_t addr, void *buf, uint32_t sz)
{
    CudbgDevice dev;

    CUDBG_VERIFY(buf, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_LN_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp, ln);

    dev = haloGlobals.device[devId];

    return dev->halo.readGenericMemory(dev->activeContext, sm, wp, ln, addr, buf, sz);
}

/**
 * \fn CUDBGAPI_st::readParamMemory
 * \brief Reads content at address in the param memory segment.
 *
 * Since CUDA 3.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param addr - memory address
 * \param buf - buffer
 * \param sz - size of the buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_MEMORY_MAPPING_FAILED
 *
 * \sa readCodeMemory
 * \sa readConstMemory
 * \sa readGenericMemory
 * \sa readSharedMemory
 * \sa readTextureMemory
 * \sa readLocalMemory
 * \sa readRegister
 * \sa readPC
 */
CUDBGResult
gpudbgReadParamMemory(uint32_t devId, uint32_t sm, uint32_t wp, uint64_t addr, void *buf, uint32_t sz)
{
    CudbgDevice dev;

    CUDBG_VERIFY(buf, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    return dev->halo.readParamMemory(dev, sm, wp, addr, buf, sz);
}

/**
 * \fn CUDBGAPI_st::readSharedMemory
 * \brief Reads content at address in the shared memory segment.
 *
 * Since CUDA 3.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param addr - memory address
 * \param buf - buffer
 * \param sz - size of the buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_MEMORY_MAPPING_FAILED
 *
 * \sa readCodeMemory
 * \sa readConstMemory
 * \sa readGenericMemory
 * \sa readParamMemory
 * \sa readLocalMemory
 * \sa readTextureMemory
 * \sa readRegister
 * \sa readPC
 */
CUDBGResult
gpudbgReadSharedMemory(uint32_t devId, uint32_t sm, uint32_t wp, uint64_t addr, void *buf, uint32_t sz)
{
    CudbgDevice dev;

    CUDBG_VERIFY(buf, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    return dev->halo.readSharedMemory(dev, sm, wp, addr, buf, sz);
}

/**
 * \fn CUDBGAPI_st::readTextureMemory
 * \brief Read the content of texture memory with given id and coords on sm_20 and lower.
 *
 * Read the content of texture memory with given id and coords on sm_20 and lower.
 *
 * On sm_30 and higher, use CUDBGAPI_st::readTextureMemoryBindless instead.
 *
 * Since CUDA 4.0.
 *
 * \ingroup READ
 *
 * \param devId - device index
 * \param vsm - SM index
 * \param wp - warp index
 * \param id - texture id (the value of DW_AT_location attribute in the relocated ELF image)
 * \param dim - texture dimension (1 to 4)
 * \param coords - array of coordinates of size dim
 * \param buf - result buffer
 * \param sz - size of the buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_MEMORY_MAPPING_FAILED
 *
 * \sa readCodeMemory
 * \sa readConstMemory
 * \sa readGenericMemory
 * \sa readParamMemory
 * \sa readSharedMemory
 * \sa readLocalMemory
 * \sa readRegister
 * \sa readPC
 */
CUDBGResult
gpudbgReadTextureMemory(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t id, uint32_t dim, uint32_t *coords, void *buf, uint32_t sz)
{
    CudbgDevice dev;
    CUdev *pDev;

    CUDBG_VERIFY((buf && coords && dim <= CUDBG_TEX_DIM_MAX && dim >= CUDBG_TEX_DIM_MIN),
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];
    pDev = globals.devices[dev->deviceIdx];

    /* Tesla and Fermi only */
    CUDBG_VERIFY((pDev->state.major < 3), CUDBG_ERROR_INVALID_DEVICE, "Invalid device.\n");

    return dev->halo.readTextureMemory(dev, sm, wp, id, dim, coords, buf, sz);
}

/**
 * \fn CUDBGAPI_st::readTextureMemoryBindless
 * \brief Read the content of texture memory with given symtab index and coords on sm_30 and higher.
 *
 * Read the content of texture memory with given symtab index and coords on sm_30 and higher.
 *
 * For sm_20 and lower, use CUDBGAPI_st::readTextureMemory instead.
 *
 * Since CUDA 4.2.
 *
 * \ingroup READ
 *
 * \param devId - device index
 * \param vsm - SM index
 * \param wp - warp index
 * \param texSymtabIndex - global symbol table index of the texture symbol
 * \param dim - texture dimension (1 to 4)
 * \param coords - array of coordinates of size dim
 * \param buf - result buffer
 * \param sz - size of the buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_MEMORY_MAPPING_FAILED
 *
 * \sa readCodeMemory
 * \sa readConstMemory
 * \sa readGenericMemory
 * \sa readParamMemory
 * \sa readSharedMemory
 * \sa readLocalMemory
 * \sa readRegister
 * \sa readPC
 */
CUDBGResult
gpudbgReadTextureMemoryBindless(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t texSymtabIndex, uint32_t dim, uint32_t *coords, void *buf, uint32_t sz)
{
    CudbgDevice dev;
    CUdev *pDev;

    CUDBG_VERIFY((buf && coords && dim <= CUDBG_TEX_DIM_MAX && dim >= CUDBG_TEX_DIM_MIN),
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];
    pDev = globals.devices[dev->deviceIdx];

    /* Kepler and higher only */
    CUDBG_VERIFY((pDev->state.major >= 3), CUDBG_ERROR_INVALID_DEVICE, "Invalid device.\n");

    return dev->halo.readTextureMemory(dev, sm, wp, texSymtabIndex, dim, coords, buf, sz);
}

/**
 * \fn CUDBGAPI_st::readLocalMemory
 * \brief Reads content at address in the local memory segment.
 *
 * Since CUDA 3.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param addr - memory address
 * \param buf - buffer
 * \param sz - size of the buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_MEMORY_MAPPING_FAILED
 *
 * \sa readCodeMemory
 * \sa readConstMemory
 * \sa readGenericMemory
 * \sa readParamMemory
 * \sa readSharedMemory
 * \sa readTextureMemory
 * \sa readRegister
 * \sa readPC
 */
CUDBGResult
gpudbgReadLocalMemory(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln,
                      uint64_t addr, void *buf, uint32_t sz)
{
    CudbgDevice dev;

    CUDBG_VERIFY(buf, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_LN_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp, ln);

    dev = haloGlobals.device[devId];

    return dev->halo.readLocalMemory(dev, sm, wp, ln, addr, buf, sz);
}

/**
 * \fn CUDBGAPI_st::readPinnedMemory
 * \brief Reads content at pinned address in system memory.
 *
 * Since CUDA 3.2.
 *
 * \ingroup READ
 *
 * \param addr - system memory address
 * \param buf - buffer
 * \param sz - size of the buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_MEMORY_MAPPING_FAILED,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readCodeMemory
 * \sa readConstMemory
 * \sa readGenericMemory
 * \sa readParamMemory
 * \sa readSharedMemory
 * \sa readTextureMemory
 * \sa readLocalMemory
 * \sa readRegister
 * \sa readPC
 */
CUDBGResult
gpudbgReadPinnedMemory(uint64_t addr, void *buf, uint32_t sz)
{
    uint32_t i;

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    CUDBG_VERIFY(buf, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    for (i = 0; i < globals.numDevices; i++) {
        CudbgDevice dev;

        CUDBG_VERIFY(haloGlobals.device && haloGlobals.device[i],
                     CUDBG_ERROR_UNINITIALIZED,
                     "HALO not initialized.\n");

        if (!deviceHasAnyContext(i))
            continue;

        dev = haloGlobals.device[i];
        if (dev && !dev->status) {
            /* FIXME:  An active memory map is a huge limitation.  This will
               all need to be addressed when we adjust our driver callback
               mechanism to receive live updates for all memory allocations
               (the Tools API will give us this -- currently we only save off
               memory handles at launch time). */
            if (!dev->halo.readPinnedMemory(dev, addr, buf, sz))
                return CUDBG_SUCCESS;
        }
    }

    /* Only come here if we didn't find anything to map (above) */
    return CUDBG_ERROR_MEMORY_MAPPING_FAILED;
}

CUDBGResult
gpudbgReadRegisterRangeInternal(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t index, uint32_t *registers, uint32_t registers_size)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CudbgDevice dev;
    DebugPatch patch;
    bool inPatch;
    uint32_t regnum;

    dev = haloGlobals.device[devId];

    res = threadInPatch(dev, sm, wp, ln, &patch, &inPatch);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Error when checking if thread is in patch\n");

    if (inPatch &&
        !patch->debug &&
        HALO_PATCH_MODIFIES_REG(patch->kind)) {
        for (regnum = index; regnum < index + registers_size; ++regnum) {
            res = readPatchReg(dev, patch, sm, wp, ln, regnum, &registers[regnum - index]);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Error when reading patch register: %d\n", regnum);
        }
        return CUDBG_SUCCESS;
    }
    else {
        return dev->halo.readRegisterRange(dev, sm, wp, ln, index, registers, registers_size, false);
    }
}

/**
 * \fn CUDBGAPI_st::readRegister
 * \brief Reads content of a hardware register.
 *
 * Since CUDA 3.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param regno - register index
 * \param val - buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readCodeMemory
 * \sa readConstMemory
 * \sa readGenericMemory
 * \sa readParamMemory
 * \sa readSharedMemory
 * \sa readTextureMemory
 * \sa readLocalMemory
 * \sa readPC
 */
CUDBGResult
gpudbgReadRegister(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t regno, uint32_t *val)
{
    CudbgDevice dev;

    CUDBG_VERIFY(val, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_LN_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp, ln);

    dev = haloGlobals.device[devId];

    CUDBG_VERIFY(regno < dev->halo.deviceInfo.numRegsPrLane, CUDBG_ERROR_INVALID_ARGS, "Invalid regno.\n");

    return gpudbgReadRegisterRangeInternal(devId, sm, wp, ln, regno, val, 1);
}

static CUDBGResult
resolvePatchToEntryAddr_common(CudbgDevice dev, uint32_t sm, uint32_t wp, uint32_t ln,
                               uint64_t *pc, bool *patchDebug, bool virt, bool debugPatch)
{
    CUDBGResult res = CUDBG_SUCCESS;
    Context ctx = NULL;
    bool inPatch = false;
    bool resolvePc = true;
    DebugPatch patch = NULL;
    uint64_t toolsDebuggerPC = 0;
    bool inUnifiedDebuggerPatch = false;

    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_ARGS, "Invalid dev in arguments.\n");
    CUDBG_VERIFY(pc, CUDBG_ERROR_INVALID_ARGS, "Invalid pc in arguments.\n");
    CUDBG_VERIFY(patchDebug, CUDBG_ERROR_INVALID_ARGS, "Invalid patchDebug in arguments.\n");

    ctx = dev->activeContext;
    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context.\n");

    *patchDebug = false;

    /* Each step of this loop updates pc to the entry point of the patch the pc
       was in.  Keep resolving the pc until we're either:
       1) Not in a patch
       2) In a patch we can debug */
    while(resolvePc) {
        res = dev->haloClient->inUnifiedDebuggerPatch(dev, *pc, &inUnifiedDebuggerPatch);
        if (res != CUDBG_SUCCESS)
        {
            CUDBG_ERROR("Failed call to inUnifiedDebuggerPatch\n");
            return res;
        }

        if (inUnifiedDebuggerPatch)
        {
            res = dev->haloClient->getUnifiedDebuggerPatchPC(dev, dev->activeContext->cuCtx, *pc, &toolsDebuggerPC);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Failed call to getUnifiedDebuggerPatchPC\n");
                return res;
            }

            CUDBG_TRACE("getUnifiedDebuggerPatchPC remapped pc\n");
            *pc = toolsDebuggerPC;
        }

        res = haloInPatchRegion(*pc, ctx, &patch, CUDBG_PATCH_ALL, &inPatch,
                                false);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to haloInPatchRegion failed in resolvePatchToEntryAddr_common.\n");
            return res;
        }

        /* Not in a patch any more, done */
        if (!inPatch)
            break;

        API_TRACE_FUNCTION(2, "Inside Patch region: PC:0x%x, GPUBase:0x%x, "
                           "size: %u, entry point:0x%x, kind:%x, debug:%u "
                           "VA : 0x%" PRIx64 "\n",
                           *pc, patch->gpuAddr, patch->size, patch->entryAddr,
                           patch->kind, patch->debug, patch->virtAddr);

#ifndef RELEASE
        /* In a patch we can debug, done */
        if (patch->debug && debugPatch) {
            API_TRACE_FUNCTION(2, "Patch debugging enabled\n");
            if (virt) {
                *pc = *pc - patch->gpuAddr + patch->virtAddr;
                API_TRACE_FUNCTION(2, "Returning virtual address, 0x%" PRIx64 "\n", *pc);
            }
            *patchDebug = true;
            return CUDBG_SUCCESS;
        }
#endif

        switch (patch->kind) {
        case CUDBG_PATCH_GLOBAL_SYSCALL:
            /* We can get here in two ways.  (1) Warps that belong to a grid
               that has already been posted, that are just entering the SMs and
               land in atentry code or (2) Warps that have jumped to atexit code.
               Note we should never get here directly from an API entrypoint, but
               rather only when determining information about a newly discovered
               grid (see the dynamic grid routines further along in this file).
               Do not adjust the PC, as it already points to a valid func/mod. */
            resolvePc = false;
            break;

        case CUDBG_PATCH_TRAP_HANDLER:
            /* If we've stopped in the trap handler, then this can only happen
               due to CNP (a fallthrough region).  We do not expose warps that
               have trapped in this region, unless we're under internal debugging
               (in which case we should have hit the patch->debug condition above. */
            CUDBG_ERROR("Warp in trap handler patch, but exposed to API?\n");
            return CUDBG_ERROR_INTERNAL;

        case CUDBG_PATCH_SYSCALL:
            res = dev->halo.findSyscallEntryPoint(dev, sm, wp, ln, pc);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Failed to get the syscall patch pc in resolvePatchToEntryAddr_common.\n");
                return res;
            }
            break;

        case CUDBG_PATCH_MEMCHECK:

            if (!patch->multiEntry) {
                /* Emulate the old behavior */
                *pc = patch->entryAddr;
            }
            else {
                res = dev->halo.mcinterop_getPatchPC(dev, sm, wp, ln, pc);
                if (res != CUDBG_SUCCESS) {
                    CUDBG_ERROR("Failed to get the memcheck patch pc in resolvePatchToEntryAddr_common.\n");
                    return res;
                }
            }
            break;

        case CUDBG_PATCH_MEMBAR_WAR:
            res = dev->halo.membarWAR_getPatchPC(dev, sm, wp, ln, pc, patch);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Failed to get the membar WAR PC in resolvePatchToEntryAddr_common\n");
                return res;
            }
            break;

        case CUDBG_PATCH_BAR_WAR:
            res = dev->halo.barWAR_getPatchPC(dev, sm, wp, ln, pc);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Failed to get the BAR WAR PC in resolvePatchToEntryAddr_common\n");
                return res;
            }
            break;

        case CUDBG_PATCH_LDC_WAR:
            *pc = patch->entryAddr;
            CUDBG_VERIFY(*pc, res, "entryAddr should always be non-zero\n");
            break;

        default:
            /* We should never get here. */
            CUDBG_ERROR("Unknown patch type 0x%x in resolvePatchToEntryAddr_common.\n", patch->kind);
            return CUDBG_ERROR_INTERNAL;
        }
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
resolvePatchToEntryAddr(CudbgDevice dev, uint32_t sm, uint32_t wp, uint32_t ln,
                        uint64_t *pc, bool *patchDebug)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(pc, CUDBG_ERROR_INVALID_ARGS, "Invalid pc in arguments.\n");
    res = resolvePatchToEntryAddr_common(dev, sm, wp, ln, pc, patchDebug, false, true);
    return res;
}

static CUDBGResult
resolvePatchToEntryAddrVirt(CudbgDevice dev, uint32_t sm, uint32_t wp, uint32_t ln,
                            uint64_t *pc, bool *patchDebug)
{
    return resolvePatchToEntryAddr_common(dev, sm, wp, ln, pc, patchDebug, true, true);
}

CUDBGResult
gpudbgReadPCInternal(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint64_t *pc)
{
    CudbgDevice dev;
    DeviceFunction function;
    Context ctx;
    bool patchDebug = false;
    CUDBGResult res;

    dev = haloGlobals.device[devId];

    ctx = dev->activeContext;

    res = readRawPC(dev, sm, wp, ln, pc);
    if (res != CUDBG_SUCCESS)
        return res;

    res = resolvePatchToEntryAddr(dev, sm, wp, ln, pc, &patchDebug);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Unable to unpatch pc in gpudbgReadPC.\n");
        return CUDBG_ERROR_INTERNAL;
    }

#ifndef RELEASE
    if (patchDebug) {
        API_TRACE_FUNCTION(10, "Patch debugging enabled. Using raw PC\n");
        function = (DeviceFunction)toolsRangeMapLookupByAddr(ctx->gpuAddrToFunction, *pc);
    }
    else
#endif
    {
        /*  At this point, *pc is adjusted by the resolve step, so use it */
        function = (DeviceFunction)toolsRangeMapLookupByAddr(ctx->gpuAddrToFunction, *pc);
        CUDBG_VERIFY(function, CUDBG_ERROR_UNKNOWN_FUNCTION, "Unknown function.\n");

        *pc -= function->gpuAddrBase;
    }

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::readPC
 * \brief Reads the PC on the given active lane.
 *
 * Since CUDA 3.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param pc - the returned PC
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNKNOWN_FUNCTION,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readCodeMemory
 * \sa readConstMemory
 * \sa readGenericMemory
 * \sa readParamMemory
 * \sa readSharedMemory
 * \sa readTextureMemory
 * \sa readLocalMemory
 * \sa readRegister
 * \sa readVirtualPC
 */
CUDBGResult
gpudbgReadPC(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint64_t *pc)
{
    CUDBG_VERIFY(pc, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_LN_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp, ln);

    API_TRACE_FUNCTION(10, "\n");

    return gpudbgReadPCInternal(devId, sm, wp, ln, pc);
}

CUDBGResult
gpudbgReadVirtualPCInternal(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint64_t *virtualpc)
{
    CudbgDevice dev;
    Context ctx;
    CUDBGResult res;
    DeviceFunction function;
    bool patchDebug = false;
    uint64_t physPC;

    dev = haloGlobals.device[devId];

    ctx = dev->activeContext;

    res = readRawPC(dev, sm, wp, ln, &physPC);
    if (res != CUDBG_SUCCESS)
        return res;

    res = resolvePatchToEntryAddrVirt(dev, sm, wp, ln, &physPC, &patchDebug);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Unable to resolve entry address of patch pc in gpudbgReadVirtualPC.\n");
        return CUDBG_ERROR_INTERNAL;
    }

#ifndef RELEASE /* Internal debugging of syscalls */
    if (patchDebug) {
        *virtualpc = physPC;
        return CUDBG_SUCCESS;
    }
#endif

    /* CNP: ____at_entry_exit code introduces a SSY and NOP.s pair, so if the
       actual kernel being launched ever diverges, it will end up here.  This
       needs to be handled a bit more properly throughout the API and client,
       but for now this returns a proper virtualized PC.  (Essentially anything
       that uses the kernel start offset as a base would be incorrect -- we
       could cook this PC like we do for memcheck patches, but we may want to
       see this exact PC -- up for debate). */

    function = (DeviceFunction)toolsRangeMapLookupByAddr(ctx->gpuAddrToFunction, physPC);
    if (function) {
        API_TRACE(50, "Found device function: %s\n", function->name ? function->name : "[unknown]");

        if (function->type == DEV_FUNC_TYPE_PROLOGUE) {
            /* Prologue instructions have no corresponding virtual addresses */
            *virtualpc = function->relatedFunction->virtAddrBase;
            return CUDBG_SUCCESS;
        }

        *virtualpc = physPC - function->gpuAddrBase + function->virtAddrBase;
        return CUDBG_SUCCESS;

    }
    else {
        CUDBG_ERROR("Function not found at 0x%lx\n", physPC);
        return CUDBG_ERROR_UNKNOWN_FUNCTION;
    }
}

/**
 * \fn CUDBGAPI_st::readVirtualPC
 * \brief Reads the virtual PC on the given active lane.
 *
 * Since CUDA 3.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param pc - the returned PC
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_UNKNOWN_FUNCTION
 *
 * \sa readPC
 */
CUDBGResult
gpudbgReadVirtualPC(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint64_t *virtualpc)
{
    CUDBG_VERIFY(virtualpc, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_LN_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp, ln);

    return gpudbgReadVirtualPCInternal(devId, sm, wp, ln, virtualpc);
}

/**
 * \fn CUDBGAPI_st::readLaneStatus
 * \brief Reads the status of the given lane.  For specific error values, use readLaneException.
 *
 * Since CUDA 3.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param error - true if there is an error
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 */
CUDBGResult
gpudbgReadLaneStatus(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, bool *error)
{
    CUDBGResult res;
    CUDBGException_t exception;

    CUDBG_VERIFY(error, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_LN_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp, ln);

    /* Initialize error to false */
    *error = false;

    if ((res = gpudbgReadLaneException(devId, sm, wp, ln, &exception)))
        return res;

    *error = !!exception;
    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::readLaneException
 * \brief Reads the exception type for a given lane
 *
 * Since CUDA 3.1.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param exception - the returned exception type
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 */
CUDBGResult
gpudbgReadLaneException(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, CUDBGException_t *exception)
{
    CudbgDevice dev;

    CUDBG_VERIFY(exception, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_LN_VALID),
                    devId, sm, wp, ln);

    dev = haloGlobals.device[devId];

    /* Initialize exception to none */
    *exception = CUDBG_EXCEPTION_NONE;

    /* Report the current exception status for this lane.
       Memcheck exceptions are now gathered using mcinterop*/
    *exception = dev->smState[sm].warp[wp].laneExceptions[ln];
    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::readCallDepth32
 * \brief Reads the call depth (number of calls) for a given warp.
 *
 * Since CUDA 3.1.
 *
 * \deprecated in CUDA 4.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param depth - the returned call depth
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readReturnAddress32
 * \sa readVirtualReturnAddress32
 */
CUDBGResult
gpudbgReadCallDepth32(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t *depth)
{
    CudbgDevice dev;
    CUDBGResult res;
    uint32_t ln;

    CUDBG_VERIFY(depth, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in gpudbgReadCallDepth32.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID),
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    /* Until 4.0, we were missing the lane index. Find any lane that is active
       and use that instead. Bug 784865. */
    res = haloFindAnActiveLane(dev, sm, wp, &ln);
    if (res != CUDBG_SUCCESS)
        return CUDBG_ERROR_INVALID_WARP;

    API_TRACE_FUNCTION(10, "%u/%u/%u/%u\n", devId, sm, wp, ln);

    return gpudbgReadCallDepth(devId, sm, wp, ln, depth);
}

CUDBGResult
gpudbgReadCallDepthInternal(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t *depth)
{
    CudbgDevice dev;
    CUDBGResult res;
    Context ctx;
    DebugPatch patch = NULL;
    bool insidePatch = false;
    uint64_t pc;
#ifndef RELEASE
    uint32_t syscall_depth = 0;
#endif

    API_TRACE_FUNCTION(10, "%u/%u/%u/%u\n", devId, sm, wp, ln);

    dev = haloGlobals.device[devId];

    res = dev->halo.readCallDepth(dev, sm, wp, ln, depth);
    if (res != CUDBG_SUCCESS)
        return res;

    if (dev->smState[sm].warp[wp].activeMask & (1U << ln))
        res = dev->halo.readPC(dev, sm, wp, &pc);
    else
        res = dev->halo.findDivergedCRS_PC(dev, sm, wp, ln, &pc);

    if (res != CUDBG_SUCCESS)
        return res;

    /*  Hide the patch level */
    ctx = dev->activeContext;
    if (ctx) {
        res = haloInPatchRegion(pc, ctx, &patch, CUDBG_PATCH_ALL, &insidePatch,
                                false);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to haloInPatchRegion failed in gpudbgReadCallDepthInternal.\n");
            return res;
        }
    }

    if (insidePatch && patch) {
        uint32_t patch_depth = patch->depth;

        if (patch->kind == CUDBG_PATCH_MEMBAR_WAR) {
            /* The membar WARs have variable depth */
            res = dev->halo.membarWAR_getPatchCallDepth(dev, sm, wp, ln,
                                                        &patch_depth, patch);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Failed to get membar WAR patch depth\n");
                return res;
            }
        }

        *depth -= patch_depth;

#ifndef RELEASE
        API_TRACE(5, "Found inside patch region. "
                  "Patch Depth:%u Current depth:%u\n",
                  patch_depth, *depth);

        if (patch->debug) {
            API_TRACE(5, "Debugging patch region. Not hiding patch. "
                      "Reporting real depth:%u\n",
                      patch_depth + *depth);
            *depth += patch_depth;
        }

        if (patch->kind == CUDBG_PATCH_SYSCALL) {
            res = dev->halo.readSyscallCallDepth(dev, sm, wp, ln, &syscall_depth);
            if (res != CUDBG_SUCCESS) {
                API_TRACE(10,"Call to readSyscallCallDepth failed. Forcing syscall_depth to 0\n");
                syscall_depth = 0;
                res = CUDBG_SUCCESS;
            }
            API_TRACE(10, "Found inside a syscall patch. "
                      "Syscall depth: %u current depth: %u\n",
                      syscall_depth, *depth);
        }
#endif
    }

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::readCallDepth
 * \brief Reads the call depth (number of calls) for a given lane
 *
 * Since CUDA 4.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param depth - the returned call depth
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readReturnAddress
 * \sa readVirtualReturnAddress
 */
CUDBGResult
gpudbgReadCallDepth(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t *depth)
{
    API_TRACE_FUNCTION(10, "%u/%u/%u/%u\n", devId, sm, wp, ln);

    CUDBG_VERIFY(depth, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_LN_VALID),
                    devId, sm, wp, ln);

    return gpudbgReadCallDepthInternal(devId, sm, wp, ln, depth);
}

/**
 * \fn CUDBGAPI_st::readSyscallCallDepth
 * \brief Reads the call depth of syscalls for a given lane
 *
 * Since CUDA 4.1.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param depth - the returned call depth
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readReturnAddress
 * \sa readVirtualReturnAddress
 */
CUDBGResult
gpudbgReadSyscallCallDepth(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t *depth)
{
    CudbgDevice dev;
    CUDBGResult res;

    API_TRACE_FUNCTION(10, "%u/%u/%u/%u\n", devId, sm, wp, ln);

    CUDBG_VERIFY(depth, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_LN_VALID),
                    devId, sm, wp, ln);

    dev = haloGlobals.device[devId];

#ifndef RELEASE
    /* Do not report any syscall call depth under internal debugging.
       The front-end hides syscall frames by default by querying this,
       so reporting a value of 0 will prevent any hiding. */
    if (cudbgEnableInternalDebugging) {
        *depth = 0;
        return CUDBG_SUCCESS;
    }
#endif

    res = dev->halo.readSyscallCallDepth(dev, sm, wp, ln, depth);
    if (res != CUDBG_SUCCESS)
        return res;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::readReturnAddress32
 * \brief Reads the physical return address for a call level.
 *
 * Since CUDA 3.1.
 *
 * \deprecated in CUDA 4.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param level - the specified call level
 * \param ra - the returned return address for level
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_INVALID_GRID,
 * \return CUDBG_ERROR_INVALID_CALL_LEVEL,
 * \return CUDBG_ERROR_ZERO_CALL_DEPTH,
 * \return CUDBG_ERROR_UNKNOWN_FUNCTION,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readCallDepth32
 * \sa readVirtualReturnAddress32
 */
CUDBGResult
gpudbgReadReturnAddress32(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t level, uint64_t *ra)
{
    uint32_t ln;
    CudbgDevice dev;
    CUDBGResult res;

    CUDBG_VERIFY(ra, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in gpudbgReadReturnAddress32.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID),
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    /* Until 4.0, we were missing the lane index. Find any lane that is active
       and use that instead. Bug 784865. */
    res = haloFindAnActiveLane(dev, sm, wp, &ln);
    if (res != CUDBG_SUCCESS)
        return CUDBG_ERROR_INVALID_WARP;

    API_TRACE_FUNCTION(10, "%u/%u/%u/%u level %d\n", devId, sm, wp, ln, level);

    return gpudbgReadReturnAddress(devId, sm, wp, ln, level, ra);
}

/* This function determines the physical return PC based on the level requested.
    This also hides internal patches and syscall unless patch debugging is
    enabled. */
CUDBGResult
gpudbgReadReturnAddressInternal(uint32_t devId, uint32_t sm, uint32_t wp,
                                uint32_t ln, uint32_t level, uint64_t *ra,
                                bool *patchDebug)
{
    uint32_t call_depth;
    CudbgDevice dev;
    CUDBGResult res;
    Context ctx;
    bool insidePatch = false;
    DebugPatch patch = NULL;
    uint32_t patch_depth = 0;
    uint64_t pc;

    dev = haloGlobals.device[devId];

    ctx = dev->activeContext;

    CUDBG_VERIFY(dev->smState[sm].warp[wp].validLanes,
                 CUDBG_ERROR_INVALID_WARP,
                 "Invalid warp.\n");

    if ((res = gpudbgReadCallDepthInternal(devId, sm, wp, ln, &call_depth)))
        return res;

    CUDBG_VERIFY(call_depth, CUDBG_ERROR_ZERO_CALL_DEPTH, "Zero call depth.\n");

    /*  Hide the patch level */
    if (ctx) {
        res = readRawPC(dev, sm, wp, ln, &pc);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to readRawPC failed\n");
            return res;
        }

        res = haloInPatchRegion(pc, ctx, &patch, CUDBG_PATCH_ALL, &insidePatch,
                                false);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to haloInPatchRegion failed in gpudbgReadReturnAddressInternal.\n");
            return res;
        }
        if (insidePatch && patch && patch->kind == CUDBG_PATCH_MEMBAR_WAR && !patch->debug) {
            /* The membar WARs have variable depth */
            res = dev->halo.membarWAR_getPatchCallDepth(dev, sm, wp, ln,
                                                        &patch_depth, patch);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Failed to get membar WAR patch depth\n");
                return res;
            }
            API_TRACE_FUNCTION(3, "Found in membar patch. Call depth: %u Patch Depth:%u\n",
                               level, patch_depth);
            level += patch_depth;
        }
        else if (insidePatch &&
                 patch && 
                 HALO_PATCH_IS_HW_WAR(patch->kind) &&
                 !patch->debug) {
            API_TRACE_FUNCTION(3, "Found in patch(kind=%d). Call depth:%u\n",
                               level, patch->kind);
            level += patch->depth;
        }
    }

    if ((res = dev->halo.readReturnAddress(dev, sm, wp, ln, level, ra)))
        return res;

    /*  Adjust ra if this thread is in the patch code (memcheck / syscall) */
    res = resolvePatchToEntryAddr(dev, sm, wp, ln, ra, patchDebug);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to readPatchRA failed in gpudbgReadReturnAddress.\n");
        return res;
    }

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::readReturnAddress
 * \brief Reads the physical return address for a call level
 *
 * Since CUDA 4.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param level - the specified call level
 * \param ra - the returned return address for level
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_INVALID_GRID,
 * \return CUDBG_ERROR_INVALID_CALL_LEVEL,
 * \return CUDBG_ERROR_ZERO_CALL_DEPTH,
 * \return CUDBG_ERROR_UNKNOWN_FUNCTION,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readCallDepth
 * \sa readVirtualReturnAddress
 */
CUDBGResult
gpudbgReadReturnAddress(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t level, uint64_t *ra)
{
    CudbgDevice dev;
    Context ctx;
    CUDBGResult res = CUDBG_SUCCESS;
    DeviceFunction function;
    bool patchDebug = false;

    API_TRACE_FUNCTION(10, "%u/%u/%u/%u level %d\n", devId, sm, wp, ln, level);

    CUDBG_VERIFY(ra, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_LN_VALID),
                    devId, sm, wp, ln);

    dev = haloGlobals.device[devId];
    ctx = dev->activeContext;

    if ((res = gpudbgReadReturnAddressInternal(devId, sm, wp, ln, level, ra,
                                               &patchDebug)))
        return res;

#ifndef RELEASE
    if (patchDebug) {
        API_TRACE_FUNCTION(2,
                  "Patch debugging enabled. Not hiding patch return address\n");
    }
    else
#endif
    {
        function = (DeviceFunction)toolsRangeMapLookupByAddr(ctx->gpuAddrToFunction,
                                                             *ra);
        CUDBG_VERIFY(function, CUDBG_ERROR_UNKNOWN_FUNCTION,
                     "Unknown function.\n");

        /*  Make this address 0-based (subtract the function start offset) */
        *ra -= function->gpuAddrBase;
    }

    return res;
}

/**
 * \fn CUDBGAPI_st::readVirtualReturnAddress32
 * \brief Reads the virtual return address for a call level.
 *
 * Since CUDA 3.1.
 *
 * \deprecated in CUDA 4.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param level - the specified call level
 * \param ra - the returned virtual return address for level
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_INVALID_GRID,
 * \return CUDBG_ERROR_INVALID_CALL_LEVEL,
 * \return CUDBG_ERROR_ZERO_CALL_DEPTH,
 * \return CUDBG_ERROR_UNKNOWN_FUNCTION,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_INTERNAL
 *
 * \sa readCallDepth32
 * \sa readReturnAddress32
 */
CUDBGResult
gpudbgReadVirtualReturnAddress32(uint32_t devId, uint32_t sm, uint32_t wp,
                                 uint32_t level, uint64_t *ra)
{
    uint32_t ln;
    CudbgDevice dev;
    CUDBGResult res;

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID),
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    /* Until 4.0, we were missing the lane index. Find any lane that is active
       and use that instead. Bug 784865. */
    res = haloFindAnActiveLane(dev, sm, wp, &ln);
    if (res != CUDBG_SUCCESS)
        return CUDBG_ERROR_INVALID_WARP;

    return gpudbgReadVirtualReturnAddress(devId, sm, wp, ln, level, ra);
}

CUDBGResult
gpudbgReadVirtualReturnAddressInternal(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln,
                                       uint32_t level, uint64_t *ra)
{
    CudbgDevice dev;
    Context ctx;
    CUDBGResult res;
    DeviceFunction function;
    bool patchDebug = false;

    if ((res = gpudbgReadReturnAddressInternal(devId, sm, wp, ln, level, ra,
                                               &patchDebug)))
        return res;

    dev = haloGlobals.device[devId];
    ctx = dev->activeContext;

#ifndef RELEASE
    if (patchDebug) {
        API_TRACE_FUNCTION(2, "Patch debugging enabled. Returning raw PC\n");
    }
    else
#endif
    {
        function = (DeviceFunction)toolsRangeMapLookupByAddr(ctx->gpuAddrToFunction,
                                                             *ra);
        CUDBG_VERIFY(function, CUDBG_ERROR_UNKNOWN_FUNCTION,
                     "Unknown function.\n");
        *ra = (*ra - function->gpuAddrBase) + /* subtract function start offset */
              + function->virtAddrBase; /* and add to the function virtual address base */
    }

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::readVirtualReturnAddress
 * \brief Reads the virtual return address for a call level
 *
 * Since CUDA 4.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param level - the specified call level
 * \param ra - the returned virtual return address for level
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_INVALID_GRID,
 * \return CUDBG_ERROR_INVALID_CALL_LEVEL,
 * \return CUDBG_ERROR_ZERO_CALL_DEPTH,
 * \return CUDBG_ERROR_UNKNOWN_FUNCTION,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_INTERNAL
 *
 * \sa readCallDepth
 * \sa readReturnAddress
 */
CUDBGResult
gpudbgReadVirtualReturnAddress(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln,
                               uint32_t level, uint64_t *ra)
{
    CUDBG_VERIFY(ra, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_LN_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp, ln);

    return gpudbgReadVirtualReturnAddressInternal(devId, sm, wp, ln, level, ra);
}

/**
 * \fn CUDBGAPI_st::writeGlobalMemory31
 * \brief Writes content to address in the global memory segment.
 *
 * Since CUDA 3.0.
 *
 * \deprecated in CUDA 3.2.
 *
 * \ingroup WRITE
 *
 * \param dev - device index
 * \param addr - memory address
 * \param buf - buffer
 * \param sz - size of the buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_MEMORY_MAPPING_FAILED
 *
 * \sa writeParamMemory
 * \sa writeSharedMemory
 * \sa writeLocalMemory
 * \sa writeRegister
 */
CUDBGResult
gpudbgWriteGlobalMemory31(uint32_t devId, uint64_t addr, const void *buf, uint32_t sz)
{
    CudbgDevice dev;

    CUDBG_VERIFY(sz, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_VERIFY(buf, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_SUSPENDED) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    return dev->halo.writeGenericMemory(dev->activeContext, 0, 0, 0, addr, buf, sz);
}

/**
 * \fn CUDBGAPI_st::writeGlobalMemory55
 * \brief Writes content to address in the global memory segment (entire 40-bit VA on Fermi+).
 *
 * Since CUDA 3.2.
 *
 * \deprecated in CUDA 6.0.
 *
 * \ingroup WRITE
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param addr - memory address
 * \param buf - buffer
 * \param sz - size of the buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_MEMORY_MAPPING_FAILED,
 * \return CUDBG_ERROR_ADDRESS_NOT_IN_DEVICE_MEM
 *
 * \sa writeParamMemory
 * \sa writeSharedMemory
 * \sa writeLocalMemory
 * \sa writeRegister
 */
CUDBGResult
gpudbgWriteGlobalMemory55(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln,
                          uint64_t addr, const void *buf, uint32_t sz)
{
    CUDBG_VERIFY(sz, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_VERIFY(buf, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_LN_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp, ln);

    return gpudbgWriteGenericMemory(devId, sm, wp, ln, addr, buf, sz);
}

/**
 * \fn CUDBGAPI_st::writeGenericMemory
 * \brief Writes content to an address in the generic address space.
 *        This function determines if the given address falls into the local, shared, or global memory window.
 *        It then accesses memory taking into account the hardware co-ordinates provided as inputs.
 *
 * Since CUDA 6.0.
 *
 * \ingroup WRITE
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param addr - memory address
 * \param[in] buf - buffer
 * \param buf_size - size of the buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_MEMORY_MAPPING_FAILED,
 * \return CUDBG_ERROR_ADDRESS_NOT_IN_DEVICE_MEM
 *
 * \sa writeParamMemory
 * \sa writeSharedMemory
 * \sa writeLocalMemory
 * \sa writeRegister
 */
CUDBGResult
gpudbgWriteGenericMemory(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln,
                         uint64_t addr, const void *buf, uint32_t sz)
{
    CudbgDevice dev;

    CUDBG_VERIFY(sz, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_VERIFY(buf, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_LN_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp, ln);

    dev = haloGlobals.device[devId];

    return dev->halo.writeGenericMemory(dev->activeContext, sm, wp, ln, addr, buf, sz);
}

/**
 * \fn CUDBGAPI_st::writeParamMemory
 * \brief Writes content to address in the param memory segment.
 *
 * Since CUDA 3.0.
 *
 * \ingroup WRITE
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param addr - memory address
 * \param buf - buffer
 * \param sz - size of the buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_MEMORY_MAPPING_FAILED
 *
 * \sa writeGenericMemory
 * \sa writeSharedMemory
 * \sa writeLocalMemory
 * \sa writeRegister
 */
CUDBGResult
gpudbgWriteParamMemory(uint32_t devId, uint32_t sm, uint32_t wp, uint64_t addr, const void *buf, uint32_t sz)
{
    CudbgDevice dev;

    CUDBG_VERIFY(buf, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    return dev->halo.writeParamMemory(dev, sm, wp, addr, buf, sz);
}

/**
 * \fn CUDBGAPI_st::writeSharedMemory
 * \brief Writes content to address in the shared memory segment.
 *
 * Since CUDA 3.0.
 *
 * \ingroup WRITE
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param addr - memory address
 * \param buf - buffer
 * \param sz - size of the buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_MEMORY_MAPPING_FAILED
 *
 * \sa writeGenericMemory
 * \sa writeParamMemory
 * \sa writeLocalMemory
 * \sa writeRegister
 */
CUDBGResult
gpudbgWriteSharedMemory(uint32_t devId, uint32_t sm, uint32_t wp, uint64_t addr, const void *buf, uint32_t sz)
{
    CudbgDevice dev;

    CUDBG_VERIFY(buf, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    return dev->halo.writeSharedMemory(dev, sm, wp, addr, buf, sz);
}

/**
 * \fn CUDBGAPI_st::writeLocalMemory
 * \brief Writes content to address in the local memory segment.
 *
 * Since CUDA 3.0.
 *
 * \ingroup WRITE
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param addr - memory address
 * \param buf - buffer
 * \param sz - size of the buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_MEMORY_MAPPING_FAILED
 *
 * \sa writeGenericMemory
 * \sa writeParamMemory
 * \sa writeSharedMemory
 * \sa writeRegister
 */
CUDBGResult
gpudbgWriteLocalMemory(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln,
                       uint64_t addr, const void *buf, uint32_t sz)
{
    CudbgDevice dev;

    CUDBG_VERIFY(buf, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_LN_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp, ln);

    dev = haloGlobals.device[devId];

    return dev->halo.writeLocalMemory(dev, sm, wp, ln, addr, buf, sz);
}

/**
 * \fn CUDBGAPI_st::writePinnedMemory
 * \brief Writes content to pinned address in system memory.
 *
 * Since CUDA 3.2.
 *
 * \ingroup READ
 *
 * \param addr - system memory address
 * \param buf - buffer
 * \param sz - size of the buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_MEMORY_MAPPING_FAILED,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readCodeMemory
 * \sa readConstMemory
 * \sa readGenericMemory
 * \sa readParamMemory
 * \sa readSharedMemory
 * \sa readLocalMemory
 * \sa readRegister
 * \sa readPC
 */
CUDBGResult
gpudbgWritePinnedMemory(uint64_t addr, const void *buf, uint32_t sz)
{
    uint32_t i;

    CUDBG_VERIFY(buf, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    for (i = 0; i < globals.numDevices; i++) {
        CudbgDevice dev;

        CUDBG_VERIFY(haloGlobals.device && haloGlobals.device[i],
                     CUDBG_ERROR_UNINITIALIZED,
                     "HALO not initialized.\n");

        if (!deviceHasAnyContext(i))
            continue;

        dev = haloGlobals.device[i];
        if (dev && !dev->status) {
            /* FIXME:  An active memory map is a huge limitation.  This will
               all need to be addressed when we adjust our driver callback
               mechanism to receive live updates for all memory allocations
               (the Tools API will give us this -- currently we only save off
               memory handles at launch time). */
            if (!dev->halo.writePinnedMemory(dev, addr, buf, sz))
                return CUDBG_SUCCESS;
        }
    }

    /* Only come here if we didn't find anything to map (above) */
    return CUDBG_ERROR_MEMORY_MAPPING_FAILED;
}

/**
* \fn CUDBGAPI_st::getHostAddrFromDeviceAddr
* \brief given a device virtual address, return a corresponding system memory virtual address.
 *
 * Since CUDA 4.1.
 *
* \ingroup DWARF
*
* \param dev - device index
* \param device_addr - device memory address
* \param host_addr - returned system memory address
*
* \return CUDBG_SUCCESS,
* \return CUDBG_ERROR_INVALID_ARGS,
* \return CUDBG_ERROR_INVALID_DEVICE,
* \return CUDBG_ERROR_INVALID_CONTEXT,
* \return CUDBG_ERROR_INVALID_MEMORY_SEGMENT
*
* \sa readGenericMemory
* \sa writeGenericMemory
* \sa
*/
CUDBGResult
gpudbgGetHostAddrFromDeviceAddr(uint32_t devId, uint64_t device_addr, uint64_t *host_addr)
{
    CudbgDevice dev;

    CUDBG_VERIFY(host_addr, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_SUSPENDED) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    return dev->dmal->getHostAddrFromDevicePtr(dev->activeContext, device_addr, host_addr);
}

/**
 * \fn CUDBGAPI_st::writeRegister
 * \brief Writes content to a hardware register.
 *
 * Since CUDA 3.0.
 *
 * \ingroup WRITE
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param regno - register index
 * \param val - buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa writeGenericMemory
 * \sa writeParamMemory
 * \sa writeSharedMemory
 * \sa writeLocalMemory
 */
CUDBGResult
gpudbgWriteRegister(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t regno, uint32_t val)
{
    CudbgDevice dev;
    DebugPatch patch;
    CUDBGResult res = CUDBG_SUCCESS;
    bool inPatch;

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_LN_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp, ln);

    dev = haloGlobals.device[devId];

    CUDBG_VERIFY(regno < dev->halo.deviceInfo.numRegsPrLane, CUDBG_ERROR_INVALID_ARGS, "Invalid regno.\n");

    res = threadInPatch(dev, sm, wp, ln, &patch, &inPatch);
    if (res != CUDBG_SUCCESS)
        return res;

    if (inPatch &&
        !patch->debug &&
        HALO_PATCH_MODIFIES_REG(patch->kind))
        return writePatchReg(dev, patch, sm, wp, ln, regno, &val);
    else
        return dev->halo.writeRegisterFile(dev, sm, wp, ln, regno * sizeof(uint32_t), &val, sizeof(uint32_t));
}

/**
 * \fn CUDBGAPI_st::clearAttachState
 * \brief Clear attach-specific state prior to detach.
 *
 * Since CUDA 5.0.
 *
 * \return CUDBG_SUCCESS
 */
CUDBGResult
gpudbgClearAttachState(void)
{
#if !cuosOsIsApple()
    uint32_t i;
    uint32_t vsm;
    uint32_t wp;
    CUDBGResult res;

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT    |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    haloGlobals.state->attachState = HALO_ATTACH_STATE_DETACHING;

    /* When detaching, warp state should be cleared so that the frontend
       does not show any broken warps when the final detach event is received.*/
    for (i = 0; i < globals.numDevices; i++) {
        CudbgDevice dev;
        dev = haloGlobals.device[i];
        for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
            for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
                res = dev->halo.clearWarpState (dev, vsm, wp);
                if (res != CUDBG_SUCCESS) {
                    CUDBG_ERROR("Call to clearWarpState failed.\n");
                    return res;
                }
            }
        }
    }
#endif
    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::requestCleanupOnDetach
 * \brief Request for cleanup of driver state when detaching.
 *
 * Since CUDA 6.0.
 *
 * \param appResumeFlag - value of CUDBG_RESUME_FOR_ATTACH_DETACH as read
 *                        from the application's process space.
 *
 * \return CUDBG_SUCCESS
 * \return CUDBG_ERROR_COMMUNICATION_FAILURE
 * \return CUDBG_ERROR_INVALID_ARGS
 * \return CUDBG_ERROR_INTERNAL
 */
CUDBGResult
gpudbgRequestCleanupOnDetach(uint32_t appResumeFlag)
{
#if !cuosOsIsApple()
    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    CUDBG_VERIFY(appResumeFlag != CUDBG_APP_RESUME_REASON_NONE,
                 CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    /* If the only reason for resuming the app is to complete
     * a pending message transmit from the app to the dispatcher,
     * don't signal the detach fd. Since there won't be an inthandler
     * to read the message, it will queue up on the fd and cause
     * the detach handler to fire unexpectedly later. */
    if (appResumeFlag == CUDBG_APP_RESUME_REASON_SEND_MESSAGE)
        return CUDBG_SUCCESS;

    /* The dynamic function call to detach will cause the
       app to close the detach fd if there are no inthandler
       threads. To prevent a SIGPIPE, the backend should
       first check to see if the pipe has a reader.
       For a full explanation, see the comment in
       cudbgApiDetach
    */
    if (!cuosEventIsSafeToSignal(&globals.debuggerDetachEvent)) {
        API_TRACE_FUNCTION(1, "Could not find detach Fd. Returning early\n");
        return CUDBG_SUCCESS;
    }

    if (!cudbgAttachStubAvailable) {
        CUresult drvRes;

        /* Signal the driver to run the detach handler whenever it resumes */
        drvRes = (CUresult)cuosEventSignal(&globals.debuggerDetachEvent);
        if (drvRes != CUDA_SUCCESS) {
            API_TRACE_FUNCTION(0, "Failed to signal detach (res = %d)!\n", drvRes);
            return CUDBG_ERROR_COMMUNICATION_FAILURE;
        }
    }
    else {
        CUDBGResult res = CUDBG_SUCCESS;
        CUDBGAPIMSG_t message;
// Uninitialized value results in error on QNX hence the initialization.
        uint32_t result = 0;

        message.kind = CUDBGAPIREQ5x_requestCleanupOnDetach;

        if ((res = gpudbgSendMessageToAttachStub(&message, &result))) {
            API_TRACE_FUNCTION(0, "Failed to send a message to the attach stub to detach!\n");
            return res;
        }

        if (result != CUDBG_SUCCESS) {
            API_TRACE_FUNCTION(0, "Failed to request a detach event and shutdown the attach stub (result=%u)\n",
                               result);
            res = CUDBG_ERROR_INTERNAL;
            return res;
        }

        cudbgAttachStubAvailable = false;
    }
#endif
    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::requestCleanupOnDetach55
 * \brief Request for cleanup of driver state when detaching.
 *
 * Since CUDA 5.0.
 *
 * \deprecated in CUDA 6.0
 *
 * \return CUDBG_SUCCESS
 * \return CUDBG_ERROR_COMMUNICATION_FAILURE
 * \return CUDBG_ERROR_INVALID_ARGS
 * \return CUDBG_ERROR_INTERNAL
 */
CUDBGResult
gpudbgRequestCleanupOnDetach55(void)
{
    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    return gpudbgRequestCleanupOnDetach(CUDBG_APP_RESUME_REASON_INTHANDLER);
}

/**
 * \fn CUDBGAPI_st::memcheckReadErrorAddress
 * \brief Get the address that memcheck detected an error on.
 *
 * Since CUDA 5.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param address - returned address detected by memcheck
 * \param storage - returned address class of address
 *
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_MEMCHECK_NOT_ENABLED,
 * \return CUDBG_SUCCESS
 */
static CUDBGResult
gpudbgMemcheckReadErrorAddress(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint64_t *address, ptxStorageKind *storage)
{
    CudbgDevice dev;
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t mcEnabled = 0;
    CUDBGException_t exception = CUDBG_EXCEPTION_NONE;
    uint32_t magic = 0;

    CUDBG_VERIFY(address, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");
    CUDBG_VERIFY(storage, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_LN_VALID),
                    devId, sm, wp, ln);

    dev = haloGlobals.device[devId];

    res = dev->halo.mcinterop_memcheckEnabled(dev, &mcEnabled);
    if (res != CUDBG_SUCCESS)
        return res;

    if (!mcEnabled)
        return CUDBG_ERROR_MEMCHECK_NOT_ENABLED;

    res = dev->halo.readLocalMemory(dev, sm, wp, ln,
                                    dev->halo.deviceInfo.lmemHiMemcheckScratch +
                                    dev->halo.deviceInfo.lmemMemcheckMagic,
                                    &magic, sizeof magic);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to readLocalMemory failed in gpudbgMemcheckReadErrorAddress.\n");
        return res;
    }

    res = dev->halo.mcinterop_checkLane(dev, sm, wp, ln, magic, &exception);
    if (res != CUDBG_SUCCESS)
        return res;

    if (exception != CUDBG_EXCEPTION_LANE_ILLEGAL_ADDRESS &&
        exception != CUDBG_EXCEPTION_LANE_INVALID_ATOMSYS)
        return CUDBG_ERROR_INVALID_LANE;

    res = dev->halo.mcinterop_getLDSTTargetAddr(dev, sm, wp, ln, address, storage);
    if (res != CUDBG_SUCCESS)
        return res;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::getGridStatus50
 * \brief Check whether the grid corresponding to the given
 *        gridId is still present on the device.
 *
 * Since CUDA 5.0.
 *
 * \deprecated in CUDA 5.5.
 *
 * \ingroup GRID
 *
 * \param devId  - device index
 * \param gridId - grid ID
 * \param status - enum indicating whether the grid status is INVALID, PENDING, ACTIVE,
 *                 SLEEPING, TERMINATED or UNDETERMINED
 *
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_GRID,
 * \return CUDBG_ERROR_INTERNAL
 */
CUDBGResult
gpudbgGetGridStatus50(uint32_t devId, uint32_t gridId, CUDBGGridStatus *status)
{
    CudbgDevice dev;
    Grid grid;

    CUDBG_VERIFY(status, CUDBG_ERROR_INVALID_ARGS, "Invalid argument!\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_SUSPENDED),
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    /* Sign extend when storing in the 64-bit map */
    grid = haloStateDeviceGetGrid(dev, (int)gridId);
    if (!grid) {
        *status = CUDBG_GRID_STATUS_INVALID;
        return CUDBG_SUCCESS;
    }

    /* Sign extend gridId to 64-bits */
    return dev->halo.getGridStatus(dev, (int)gridId, status);
}

/**
 * \fn CUDBGAPI_st::getGridStatus
 * \brief Check whether the grid corresponding to the given
 *        gridId is still present on the device.
 *
 * Since CUDA 5.5.
 *
 * \ingroup GRID
 *
 * \param devId    - device index
 * \param gridId64 - 64-bit grid ID
 * \param status   - enum indicating whether the grid status is INVALID, PENDING, ACTIVE,
 *                   SLEEPING, TERMINATED or UNDETERMINED
 *
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_GRID,
 * \return CUDBG_ERROR_INTERNAL
 */
CUDBGResult
gpudbgGetGridStatus(uint32_t devId, uint64_t gridId64, CUDBGGridStatus *status)
{
    CudbgDevice dev;
    Grid grid;
    /* Temporary */

    CUDBG_VERIFY(status, CUDBG_ERROR_INVALID_ARGS, "Invalid argument!\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_SUSPENDED),
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    grid = haloStateDeviceGetGrid(dev, gridId64);
    if (!grid) {
        *status = CUDBG_GRID_STATUS_INVALID;
        return CUDBG_SUCCESS;
    }

    return dev->halo.getGridStatus(dev, gridId64, status);
}

/**
 * \fn CUDBGAPI_st::getGridInfo
 * \brief Get information about the specified grid.
 *        If the context of the grid has already been destroyed,
 *        the function will return CUDBG_ERROR_INVALID_GRID,
 *        although the grid id is correct.
 *
 * Since CUDA 5.5.
 *
 * \ingroup GRID
 *
 * \param devId    - device index
 * \param gridId   - grid ID for which information is to be collected
 * \param gridInfo - pointer to a client allocated structure in which grid
 *                   info will be returned.
 *
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_GRID,
 * \return CUDBG_SUCCESS
 *
 */
CUDBGResult
gpudbgGetGridInfo(uint32_t devId, uint64_t gridId64, CUDBGGridInfo *gridInfo)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CudbgDevice dev;
    Grid grid;
    Grid parentGrid;

    CUDBG_VERIFY(gridInfo, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_SUSPENDED),
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    /* The backend should already know about this grid. */
    grid = haloStateDeviceGetGrid(dev, gridId64);
    if (!grid)
        return CUDBG_ERROR_INVALID_GRID;

    memset(gridInfo, 0, sizeof *gridInfo);

    /* Fill up the gridInfo structure */
    gridInfo->dev = dev->deviceIdx;
    gridInfo->gridId64 = grid->gridId64;
    gridInfo->tid = grid->userEntryFunction->module->context->hostThreadId;
    gridInfo->context = grid->userEntryFunction->module->context->cuCtx;
    gridInfo->module = grid->userEntryFunction->module->cuModule;
    gridInfo->function = grid->userEntryFunction->cuFunction;
    gridInfo->functionEntry = grid->userEntryFunction->virtAddrBase;
    gridInfo->gridDim = grid->gridDim;
    gridInfo->blockDim = grid->blockDim;
    gridInfo->type = grid->userEntryFunction->module->internal ? CUDBG_KNL_TYPE_SYSTEM : CUDBG_KNL_TYPE_APPLICATION;
    gridInfo->origin = grid->origin;

    /* No parent info collection needed for CPU-launched grids */
    if (grid->origin == CUDBG_KNL_ORIGIN_CPU) {
        gridInfo->parentGridId = grid->parentGridId64;
        return CUDBG_SUCCESS;
    }

    res = dev->halo.findParentGrid(dev, grid, &parentGrid);
    if (res != CUDBG_SUCCESS) {
        API_TRACE_FUNCTION(0, "Failed to get parent grid info for gridId %" PRId64 " (res = %d)!\n", gridId64, res);
        return res;
    }

    gridInfo->parentGridId = parentGrid->gridId64;

    return res;
}

CUDBGResult
gpudbgReadErrorPCInternal(uint32_t devId, uint32_t sm, uint32_t wp, uint64_t *errorPC, bool *errorPCValid)
{
    CudbgDevice dev;
    CUDBGResult res = CUDBG_SUCCESS;
    DeviceFunction function;
    DebugPatch patch;
    uint64_t physErrorPC = 0;
    bool     physErrorPCValid = false;

    dev = haloGlobals.device[devId];

    *errorPCValid = false;

    res = dev->halo.getSMHwwErrorPC(dev, sm, wp, &physErrorPC, &physErrorPCValid);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Early return if the ESR PC is not valid */
    if (!physErrorPCValid) {
        *errorPCValid = false;
        return CUDBG_SUCCESS;
    }

    /* Lookup the function to convert this to a virtual PC */
    function = (DeviceFunction)toolsRangeMapLookupByAddr(dev->activeContext->gpuAddrToFunction, physErrorPC);
    if (function) {
        CUDBG_DEBUG("Found device function: %s\n", function->name ? function->name : "[unknown]");

        if (function->type == DEV_FUNC_TYPE_PROLOGUE) {
            /* Prologue instructions have no corresponding virtual addresses */
            *errorPC = function->relatedFunction->virtAddrBase;
            *errorPCValid = true;
            return CUDBG_SUCCESS;
        }

        *errorPC = physErrorPC - function->gpuAddrBase + function->virtAddrBase;
        *errorPCValid = true;
        return CUDBG_SUCCESS;
    }

    patch = (DebugPatch)toolsRangeMapLookupByAddr(dev->activeContext->gpuAddrToPatch, physErrorPC);
    if (patch) {
        CUDBG_DEBUG("Found device function: [patch]\n");

        *errorPC = physErrorPC - patch->gpuAddr + patch->virtAddr;
        *errorPCValid = true;

        API_TRACE_FUNCTION(10, "Found device patch: errorPC 0x%" PRIx64 "\n", *errorPC);

        return CUDBG_SUCCESS;
    }

    CUDBG_ERROR("Function not found at 0x%lx\n", physErrorPC);

    return CUDBG_ERROR_UNKNOWN_FUNCTION;
}

/**
 * \fn CUDBGAPI_st::readErrorPC
 * \brief Get the hardware reported error PC if it exists
 *
 * Since CUDA 6.0
 *
 * \ingroup READ
 *
 * \param devId - the device index
 * \param sm - the SM index
 * \param warp - the warp index
 * \param errorPC - PC ofthe exception
 * \param errorPCValid - boolean to indicate that the returned error PC is valid
 *
 * \return CUDBG_SUCCESS
 * \return CUDBG_ERROR_UNINITIALIZED
 * \return CUDBG_ERROR_INVALID_DEVICE
 * \return CUDBG_ERROR_INVALID_SM
 * \return CUDBG_ERROR_INVALID_WARP
 * \return CUDBG_ERROR_INVALID_ARGS
 * \return CUDBG_ERROR_UNKNOWN_FUNCTION
 */
static CUDBGResult
gpudbgReadErrorPC(uint32_t devId, uint32_t sm, uint32_t wp, uint64_t *errorPC, bool *errorPCValid)
{
    CUDBG_VERIFY(errorPCValid && errorPC, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP),
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    return gpudbgReadErrorPCInternal(devId, sm, wp, errorPC, errorPCValid);
}

/**
 * \fn CUDBGAPI_st::getNumUniformRegisters
 * \brief Get the number of uniform registers per warp on the device.
 *
 * Since CUDA 10.0.
 *
 * \ingroup DEV
 *
 * \param dev - device index
 * \param numRegs - the returned number of uniform registers
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa getNumRegisters
 */
CUDBGResult
gpudbgGetNumUniformRegisters(uint32_t devId, uint32_t *numRegs)
{
    CUDBG_VERIFY(numRegs, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_STATUS),
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    *numRegs = haloGlobals.device[devId]->halo.deviceInfo.numUniformRegsPrWarp;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::readUniformRegisterRange
 * \brief Reads a range of uniform registers.
 *
 * Since CUDA 10.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param regno - starting index into uniform register file
 * \param registers_size - number of bytes to read
 * \param registers - pointer to buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readRegister
 */
CUDBGResult
gpudbgReadUniformRegisterRange(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t regno, uint32_t registers_size, uint32_t *registers)
{
    CudbgDevice dev;

    dev = haloGlobals.device[devId];
    return dev->halo.readUniformRegisterFile(dev, sm, wp, regno * sizeof(*registers),
                                             registers, registers_size * sizeof(*registers));
}

/**
 * \fn CUDBGAPI_st::writeUniformRegister
 * \brief Writes content to a uniform register.
 *
 * Since CUDA 10.0.
 *
 * \ingroup WRITE
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param regno - register index
 * \param val - buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa writeRegister
 * \sa readUniformRegisterRange
 */
CUDBGResult
gpudbgWriteUniformRegister(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t regno, uint32_t val)
{
    CudbgDevice dev;

    dev = haloGlobals.device[devId];
    return dev->halo.writeUniformRegisterFile(dev, sm, wp, regno * sizeof(uint32_t), &val, sizeof(uint32_t));
}

/**
 * \fn CUDBGAPI_st::readUniformPredicates
 * \brief Reads contents of uniform predicate registers.
 *
 * Since CUDA 10.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param predicates_size - number of predicate registers to read
 * \param[in] predicates - buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readPredicates
 */
CUDBGResult
gpudbgReadUniformPredicates(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t predicates_size, uint32_t *predicates)
{
    CudbgDevice dev;

    CUDBG_VERIFY(predicates, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    dev = haloGlobals.device[devId];

    CUDBG_VERIFY(predicates_size <= dev->halo.deviceInfo.numUniformPredicatesPrWarp, CUDBG_ERROR_INVALID_ARGS, "Invalid # of predicates\n");

    return dev->halo.readUniformPredicates(dev, sm, wp, predicates_size, predicates);
}

/**
 * \fn CUDBGAPI_st::writeUniformPredicates
 * \brief Writes to uniform predicate registers.
 *
 * Since CUDA 10.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param predicates_size - number of predicate registers to write
 * \param[in] predicates - buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readUniformPredicate
 * \sa writeRegister
 */
CUDBGResult
gpudbgWriteUniformPredicates(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t predicates_size, const uint32_t *predicates)
{
    CudbgDevice dev;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(predicates, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    dev = haloGlobals.device[devId];

    CUDBG_VERIFY(predicates_size <= dev->halo.deviceInfo.numUniformPredicatesPrWarp, CUDBG_ERROR_INVALID_ARGS, "Invalid # of predicates\n");

    return dev->halo.writeUniformPredicates(dev, sm, wp, predicates_size, predicates);
}

/**
 * \fn CUDBGAPI_st::getNumUniformPredicates
 * \brief Get the number of uniform predicate registers per warp on the device.
 *
 * Since CUDA 10.0.
 *
 * \ingroup DEV
 *
 * \param dev - device index
 * \param numPredicates - the returned number of uniform predicate registers
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa getNumUniformPredicates
 */
CUDBGResult
gpudbgGetNumUniformPredicates(uint32_t devId, uint32_t *numPredicates)
{
    CUDBG_VERIFY(numPredicates, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_STATUS),
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    *numPredicates = haloGlobals.device[devId]->halo.deviceInfo.numUniformPredicatesPrWarp;

    return CUDBG_SUCCESS;
}

/*--------------------------------- Exports --------------------------------*/

/*
 * Move out to cuda interface module when things are stable:
 */

static const struct CUDBGAPI_st cudbgCurrentApi = {
    /* Initialization */
    gpudbgInitialize,
    gpudbgFinalize,

    /* Device Execution Contrl */
    gpudbgSuspendDevice,
    gpudbgResumeDevice,
    gpudbgSingleStepWarp40,

    /* Breakpoints */
    gpudbgSetBreakpoint31,
    gpudbgUnsetBreakpoint31,

    /* Device State Inspection */
    gpudbgReadGridId50,
    gpudbgReadBlockIdx32,
    gpudbgReadThreadIdx,
    gpudbgReadBrokenWarps,
    gpudbgReadValidWarps,
    gpudbgReadValidLanes,
    gpudbgReadActiveLanes,
    gpudbgReadCodeMemory,
    gpudbgReadConstMemory,
    gpudbgReadGlobalMemory31,
    gpudbgReadParamMemory,
    gpudbgReadSharedMemory,
    gpudbgReadLocalMemory,
    gpudbgReadRegister,
    gpudbgReadPC,
    gpudbgReadVirtualPC,
    gpudbgReadLaneStatus,

    /* Device State Alteration */
    gpudbgWriteGlobalMemory31,
    gpudbgWriteParamMemory,
    gpudbgWriteSharedMemory,
    gpudbgWriteLocalMemory,
    gpudbgWriteRegister,

    /* Grid Properties */
    gpudbgGetGridDim32,
    gpudbgGetBlockDim,
    gpudbgGetTID,
    gpudbgGetElfImage32,

    /* Device Properties */
    gpudbgGetDeviceType,
    gpudbgGetSmType,
    gpudbgGetNumDevices,
    gpudbgGetNumSMs,
    gpudbgGetNumWarps,
    gpudbgGetNumLanes,
    gpudbgGetNumRegisters,

    /* DWARF */
    gpudbgGetPhysicalRegister30,
    gpudbgDisassemble,
    gpudbgIsDeviceCodeAddress55,
    gpudbgLookupDeviceCodeSymbol,

    /* Callbacks */
    gpudbgSetNotifyNewEventCallback31,
    gpudbgGetNextEvent30,
    gpudbgAcknowledgeEvent30,

    /* 3.1 Extensions */
    gpudbgGetGridAttribute,
    gpudbgGetGridAttributes,
    gpudbgGetPhysicalRegister40,
    gpudbgReadLaneException,
    gpudbgGetNextEvent32,
    gpudbgAcknowledgeEvents42,

    /* 3.1 ABI */
    gpudbgReadCallDepth32,
    gpudbgReadReturnAddress32,
    gpudbgReadVirtualReturnAddress32,

    /* 3.2 Extensions */
    gpudbgReadGlobalMemory55,
    gpudbgWriteGlobalMemory55,
    gpudbgReadPinnedMemory,
    gpudbgWritePinnedMemory,
    gpudbgSetBreakpoint,
    gpudbgUnsetBreakpoint,
    gpudbgSetNotifyNewEventCallback40,

    /* 4.0 Extensions */
    gpudbgGetNextEvent42,
    gpudbgReadTextureMemory,
    gpudbgReadBlockIdx,
    gpudbgGetGridDim,
    gpudbgReadCallDepth,
    gpudbgReadReturnAddress,
    gpudbgReadVirtualReturnAddress,
    gpudbgGetElfImage,

    /* 4.1 Extensions */
    gpudbgGetHostAddrFromDeviceAddr,
    gpudbgSingleStepWarp41,
    gpudbgSetNotifyNewEventCallback,
    gpudbgReadSyscallCallDepth,

    /* 4.2 Extensions */
    gpudbgReadTextureMemoryBindless,

    /* 5.0 Extensions */
    gpudbgClearAttachState,
    gpudbgGetNextSyncEvent50,
    gpudbgMemcheckReadErrorAddress,
    gpudbgAcknowledgeSyncEvents,
    gpudbgGetNextAsyncEvent50,
    gpudbgRequestCleanupOnDetach55,
    gpudbgInitializeAttachStub,
    gpudbgGetGridStatus50,

    /* 5.5 Extensions */
    gpudbgGetNextSyncEvent55,
    gpudbgGetNextAsyncEvent55,
    gpudbgGetGridInfo,
    gpudbgReadGridId,
    gpudbgGetGridStatus,
    gpudbgSetKernelLaunchNotificationMode,
    gpudbgGetDevicePCIBusInfo,
    gpudbgReadDeviceExceptionState80,

    /* 6.0 Extensions */
    gpudbgGetAdjustedCodeAddress,
    gpudbgReadErrorPC,
    gpudbgGetNextEvent,
    gpudbgGetElfImageByHandle,
    gpudbgResumeWarpsUntilPC,
    gpudbgReadWarpState,
    gpudbgReadRegisterRange,
    gpudbgReadGenericMemory,
    gpudbgWriteGenericMemory,
    gpudbgReadGlobalMemory,
    gpudbgWriteGlobalMemory,
    gpudbgGetManagedMemoryRegionInfo,
    gpudbgIsDeviceCodeAddress,
    gpudbgRequestCleanupOnDetach,

    /* 6.5 Extensions */
    gpudbgReadPredicates,
    gpudbgWritePredicates,
    gpudbgGetNumPredicates,
    gpudbgReadCCRegister,
    gpudbgWriteCCRegister,

    gpudbgGetDeviceName,
    gpudbgSingleStepWarp,

    /* 9.0 Extensions */
    gpudbgReadDeviceExceptionState,

    /* 10.0 Extensions */
    gpudbgGetNumUniformRegisters,
    gpudbgReadUniformRegisterRange,
    gpudbgWriteUniformRegister,
    gpudbgGetNumUniformPredicates,
    gpudbgReadUniformPredicates,
    gpudbgWriteUniformPredicates,
};

static CUDBGResult
cudbgGetInjectedAPI(uint32_t major, uint32_t minor, uint32_t rev, CUDBGAPI *api)
{
    typedef CUDBGResult (CUDAAPI *pfnGetCUDADebuggerAPI_t)(uint32_t, uint32_t, uint32_t, CUDBGAPI *);
    pfnGetCUDADebuggerAPI_t pfnGetCUDADebuggerAPI;

    if (cudbgInjectionPath[0] == 0) {
        return CUDBG_ERROR_UNINITIALIZED;
    }

    cudbgInjectionPath[CUDBG_INJECTION_PATH_SIZE - 1] = 0;
    toolsLoadInjectionLibraryCore(cudbgInjectionPath);

    pfnGetCUDADebuggerAPI = (pfnGetCUDADebuggerAPI_t)cuosGetProcAddress(globals.toolsConfig.hInjectionLibrary, "GetCUDADebuggerAPI");
    if (!pfnGetCUDADebuggerAPI) {
        CUDBG_ERROR("No entry point GetDebuggerAPI in the injected tools library\n");
        return CUDBG_ERROR_INTERNAL;
    }

    return pfnGetCUDADebuggerAPI(major, minor, rev, api);
}

/**
 * \brief Get the API associated with the major/minor/revision version numbers.
 *
 * \param major - the major version number
 * \param minor - the minor version number
 * \param rev   - the revision version number
 * \param api - the pointer to the API
 *
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INCOMPATIBLE_API
 *
 * \sa cudbgGetAPIVersion
 */
CUDBGResult
cudbgGetAPI(uint32_t major, uint32_t minor, uint32_t rev, CUDBGAPI *api)
{
    CUDBGResult res;

    CUDBG_VERIFY(api, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    res = cudbgGetInjectedAPI(major, minor, rev, api);
    if (res != CUDBG_ERROR_UNINITIALIZED) {
        return res;
    }

    /* We're not getting a call from the future, are we? */
    CUDBG_VERIFY(rev <= CUDBG_API_VERSION_REVISION,
                 CUDBG_ERROR_INCOMPATIBLE_API,
                 "Incompatible API revision.\n");

    *api = &cudbgCurrentApi;
    clientRevision = rev;

    return CUDBG_SUCCESS;
}

/**
 * \brief Get the API version supported by the CUDA driver.
 *
 * \param major - the major version number
 * \param minor - the minor version number
 * \param rev   - the revision version number
 *
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_SUCCESS
 *
 * \sa cudbgGetAPI
 */
CUDBGResult
cudbgGetAPIVersion(uint32_t *major, uint32_t *minor, uint32_t *rev)
{
    CUDBG_VERIFY(major, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_VERIFY(minor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_VERIFY(rev, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    *major = CUDBG_API_VERSION_MAJOR;
    *minor = CUDBG_API_VERSION_MINOR;
    *rev   = CUDBG_API_VERSION_REVISION;

    return CUDBG_SUCCESS;
}

CUDBGResult
cudbgSendAttachCompleteEvent(void)
{
    CUDBGEvent *event;
    gpudbgEventsGetAvailable(&event, GPUDBG_EVENT_SYNC);
    event->kind = CUDBG_EVENT_ATTACH_COMPLETE;

    return gpudbgNotifyDebugger(0, false);
}

static CUDBGResult
preemptSaveChannelGroupForContext(Context context, gpudbgPreemptState *preemptState)
{
    CUDBGResult res = CUDBG_SUCCESS;
    bool preemptTimedOut = false;

    /* Ensure sanity */
    if (!context || !context->dev) {
        CUDBG_ERROR("Context is invalid when attempting a preempt save\n");
        return CUDBG_ERROR_INTERNAL;
    }

    /* Skip contexts that don't correspond to the device we're looking at */
    if (context->dev->deviceIdx != preemptState->deviceIdx) {
        API_TRACE_FUNCTION(1, "Returning early:  Context %p doesn't correspond to device %d\n",
                           context, preemptState->deviceIdx);
        return CUDBG_SUCCESS;
    }

    /* Skip contexts that are in the middle of being torn down */
    if (!haloStateContextIsActive(context)) {
        API_TRACE_FUNCTION(1, "Returning early: Context %p in the middle of teardown\n",
                           context);
        return CUDBG_SUCCESS;
    }

    /* Skip contexts that don't have a channel group handle */
    if (!context->hChannelGroup || context->hChannelGroup == CUDBG_INVALID_HANDLE) {
        API_TRACE_FUNCTION(1, "Returning early:  No valid channel handle\n");
        return CUDBG_SUCCESS;
    }

    /* This context corresponds to the device in question.  We need to locate
       its corresponding channel group handle, initiate a CTA-level preemption
       call through RM, and see if that gets it off.  If not, then we move
       forward with instruction-level preemption handling. */
    res = context->dev->halo.preemptChannelGroup(context->dev,
                                                 context->hChannelGroup,
                                                 context->hAppClient,
                                                 &preemptTimedOut);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Failed to preempt channel group (dev=%d, cg=0x%08x) (res=%d)\n",
                    context->dev->deviceIdx, context->hChannelGroup, res);
        preemptState->allPreemptSaved = false;
        return res;
    }

    if (preemptTimedOut) {
        preemptState->allPreemptSaved = false;
        preemptState->ctaPreemptTriggered = true;
    }
    else {
        preemptState->ctaPreemptTriggered = true;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
preemptRestoreChannelGroupForContext(Context context, gpudbgPreemptState *preemptState)
{
    CUDBGResult res = CUDBG_SUCCESS;

    /* Ensure sanity */
    if (!context || !context->dev) {
        CUDBG_ERROR("Context is invalid when attempting a preempt save\n");
        return CUDBG_ERROR_INTERNAL;
    }

    /* Skip contexts that don't correspond to the device we're looking at */
    if (context->dev->deviceIdx != preemptState->deviceIdx) {
        API_TRACE_FUNCTION(1, "Returning early:  Context %p doesn't correspond to device %d\n",
                           context, preemptState->deviceIdx);
        return CUDBG_SUCCESS;
    }

    /* Skip contexts that are in the middle of being torn down */
    if (!haloStateContextIsActive(context)) {
        API_TRACE_FUNCTION(1, "Returning early: Context %p in the middle of teardown\n",
                           context);
        return CUDBG_SUCCESS;
    }

    /* Skip contexts that don't yet have a valid channel group handle */
    if (context->hChannelGroup == CUDBG_INVALID_HANDLE) {
        API_TRACE_FUNCTION(1, "Returning early:  No valid channel handle\n");
        return CUDBG_SUCCESS;
    }

    /* This context corresponds to the device in question.  We need to locate
       its corresponding channel group handle, and reenable the channels through RM */
    res = context->dev->halo.scheduleChannelGroup(context->dev, context->hChannelGroup, context->hAppClient);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Failed to schedule channel group (dev=%d, cg=0x%08x) (res=%d)\n", context->dev->deviceIdx, context->hChannelGroup, res);
        preemptState->allPreemptRestored = false;
        return res;
    }

    return CUDBG_SUCCESS;
}

CUDBGResult
gpudbgInitiateChannelGroupPreemptSave(CudbgDevice dev, bool *allPreemptSaved, bool *ctaPreemptTriggered)
{
    CUDBGResult res = CUDBG_SUCCESS;
    gpudbgPreemptState preemptState;

    /* Setup the helper struct, which will be updated
       for each context we iterate over. */
    preemptState.deviceIdx = dev->deviceIdx;
    preemptState.allPreemptSaved = true; /* Assume true, if one context fails, it will update */
    preemptState.ctaPreemptTriggered = false; /* Assume false, if one context does this, it will update */

    res = haloStateTraverseContexts((haloCtxIterFunc)preemptSaveChannelGroupForContext, &preemptState);
    if (res != CUDBG_SUCCESS)
        return res;

    *allPreemptSaved = preemptState.allPreemptSaved;
    *ctaPreemptTriggered = preemptState.ctaPreemptTriggered;
    return CUDBG_SUCCESS;
}

CUDBGResult
gpudbgInitiateChannelGroupPreemptRestore(CudbgDevice dev, bool *allPreemptRestored)
{
    CUDBGResult res = CUDBG_SUCCESS;
    gpudbgPreemptState preemptState;

    /* Setup the helper struct, which will be updated
       for each context we iterate over. */
    preemptState.deviceIdx = dev->deviceIdx;
    preemptState.allPreemptRestored = true;

    res = haloStateTraverseContexts((haloCtxIterFunc)preemptRestoreChannelGroupForContext, &preemptState);
    if (res != CUDBG_SUCCESS)
        return res;

    *allPreemptRestored = preemptState.allPreemptRestored;
    return CUDBG_SUCCESS;
}

static CUDBGResult
setContextLaunchNotifyState(Context context, CudbgLaunchState *state)
{
    if (context && state)
        context->launchNotifyState = *state;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::setKernelLaunchNotificationMode
 * \brief Set the launch notification policy.
 *
 * Since CUDA 5.5.
 *
 * \param mode - mode to deliver kernel launch notifications in
 *
 * \return CUDBG_SUCCESS
 *
 */
CUDBGResult
gpudbgSetKernelLaunchNotificationMode(CUDBGKernelLaunchNotifyMode mode)
{
    CudbgLaunchState state = CUDBG_NOTIFY_SYNC_ALL;

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    0, 0, 0, 0);

    switch (mode) {
    case CUDBG_KNL_LAUNCH_NOTIFY_EVENT:
        state = CUDBG_NOTIFY_SYNC_ALL;
        break;

    case CUDBG_KNL_LAUNCH_NOTIFY_DEFER:
        if (clientRevision <= API_REVISION_5_5)
            state = CUDBG_NOTIFY_SYNC_FIRST_ONLY;
        else
            state = CUDBG_NOTIFY_NONE;
        break;

    default:
        CUDBG_ERROR("Unknown launch notify mode requested : %u\n", mode);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    cudbgLaunchNotificationPolicy = state;
    cudbgDriverOptions.reportKernelLaunches = cudbgLaunchNotificationPolicy != CUDBG_NOTIFY_NONE;
    cudbgDriverOptionsChanged = true;

    /* Propagate notification policy changes to all contexts*/
    return haloStateTraverseContexts((haloCtxIterFunc)setContextLaunchNotifyState, (void *)&state);
}

/**
 * \fn CUDBGAPI_st::getDevicePCIBusInfo
 * \brief Get PCI bus and device ids associated with device devId.
 *
 * \param devId    - the cuda device id
 * \param pciBusId - pointer where corresponding PCI BUS ID would be stored
 * \param pciDevId - pointer where corresponding PCI DEVICE ID would be stored
 *
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_DEVICE
 *
 */
CUDBGResult
gpudbgGetDevicePCIBusInfo (uint32_t devId, uint32_t *pciBusId, uint32_t *pciDevId)
{
    CUDBG_VERIFY(pciBusId, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");
    CUDBG_VERIFY(pciDevId, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_ID),
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    *pciBusId = globals.devices[devId]->state.pciBus;
    *pciDevId = globals.devices[devId]->state.pciDevice;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::readDeviceExceptionState
 * \brief Get the exception state of the SMs on the device
 * 
 * Since CUDA 9.0
 *
 * \param devId - the cuda device id
 * \param mask  - Arbitrarily sized bit field containing a 1 at (1 << i) if SM i hit an exception
 * \param sz    - Size (in bytes) of \p mask (must be large enough to hold a bit for each sm on the device)
 *
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_DEVICE
 *
 * \sa getNumSMs
 *
 */
CUDBGResult
gpudbgReadDeviceExceptionState(uint32_t devId, uint64_t *mask, uint32_t numWords)
{
    CudbgDevice dev;
    uint32_t vsm = 0;
    const uint32_t BIT_STRIDE = sizeof(*mask) * 8;

    CUDBG_VERIFY(mask && numWords > 0, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_DEV_SUSPENDED),
                    devId,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    CUDBG_VERIFY(numWords*BIT_STRIDE >= dev->halo.deviceInfo.numSMs, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    memset(mask, 0, numWords * sizeof(*mask));

    for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
        if (dev->smState[vsm].state.foundException)
            mask[vsm / BIT_STRIDE] |= 1ULL << (vsm % BIT_STRIDE);
    }

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::readDeviceExceptionState80
 * \brief Get the exception state of the SMs on the device
 *
 * Since CUDA 5.5
 *
 * \param devId           - the cuda device id
 * \param exceptionSMMask - Bit field containing a 1 at (1 << i) if SM i hit an exception
 *
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_DEVICE
 *
 */
CUDBGResult
gpudbgReadDeviceExceptionState80(uint32_t devId, uint64_t *exceptionSMMask)
{
    return gpudbgReadDeviceExceptionState(devId, exceptionSMMask, 1);
}

/**
 * \fn CUDBGAPI_st::readWarpState
 * \brief Get state of a given warp
 *
 * Since CUDA 6.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm  - SM index
 * \param wp  - warp index
 * \param state - pointer to structure that contains warp status
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED,
 */
CUDBGResult
gpudbgReadWarpState (uint32_t devId, uint32_t sm, uint32_t wp, CUDBGWarpState *state)
{
    CudbgDevice dev;
    CUDBGResult res;
    uint32_t ln;

    CUDBG_VERIFY(state, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_WP_VALID),
                    devId, sm, wp,
                    CUDBG_API_CHECK_DEFAULT);

    dev = haloGlobals.device[devId];

    memset(state, 0, sizeof(CUDBGWarpState));

    /* Read warp-wide lanes properties */
    res = gpudbgReadGridId(devId, sm, wp, &state->gridId);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read grid id.\n");

    res = gpudbgReadBlockIdx(devId, sm,wp, &state->blockIdx);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read block index.\n");

    res = gpudbgReadErrorPC(devId, sm, wp, &state->errorPC, (bool *)&state->errorPCValid);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read errorPC.\n");

    res = gpudbgReadValidLanes(devId, sm, wp, &state->validLanes);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read valid lanes.\n");

    res = gpudbgReadActiveLanes(devId, sm, wp, &state->activeLanes);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read active lanes.\n");

    for (ln = 0; ln < dev->halo.deviceInfo.numLanesPrWarp; ln++) {
        /* Skip invalid lanes */
        if (!(state->validLanes & (1U<<ln)))
            continue;

        res = gpudbgReadVirtualPC(devId, sm, wp, ln, &state->lane[ln].virtualPC);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read virtual PC.\n");

        res = gpudbgReadThreadIdx(devId, sm, wp, ln, &state->lane[ln].threadIdx);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read thread index.\n");

        res = gpudbgReadLaneException(devId, sm, wp, ln, &state->lane[ln].exception);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read lane exception.\n");
    }

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::readRegisterRange
 * \brief Reads content of a hardware range of hardware registers
 *
 * Since CUDA 6.0.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param index - index of the first register to read
 * \param registers_size - number of registers to read
 * \param registers - buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readCodeMemory
 * \sa readConstMemory
 * \sa readGenericMemory
 * \sa readParamMemory
 * \sa readSharedMemory
 * \sa readTextureMemory
 * \sa readLocalMemory
 * \sa readPC
 * \sa readRegister
 */
CUDBGResult
gpudbgReadRegisterRange(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t index, uint32_t registers_size, uint32_t *registers)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CudbgDevice dev;

    CUDBG_VERIFY (registers, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_LN_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp, ln);

    dev = haloGlobals.device[devId];

    CUDBG_VERIFY(index < dev->halo.deviceInfo.numRegsPrLane , CUDBG_ERROR_INVALID_ARGS, "Invalid regno range .\n");
    CUDBG_VERIFY(index + registers_size <= dev->halo.deviceInfo.numRegsPrLane, CUDBG_ERROR_INVALID_ARGS, "Invalid regno range .\n");

    return gpudbgReadRegisterRangeInternal(devId, sm, wp, ln, index, registers, registers_size);
}

CUDBGResult
gpudbgReadPredicatesInternal(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t predicates_size, uint32_t *predicates)
{
    CudbgDevice dev;
    DebugPatch patch;
    CUDBGResult res = CUDBG_SUCCESS;
    bool inPatch;

    dev = haloGlobals.device[devId];

    res = threadInPatch(dev, sm, wp, ln, &patch, &inPatch);
    if (res != CUDBG_SUCCESS)
        return res;

    if (inPatch &&
        !patch->debug &&
        HALO_PATCH_MODIFIES_PRED(patch->kind))
        return readPatchPred(dev, patch, sm, wp, ln, predicates_size, predicates);
    else
        return dev->halo.readPredicates(dev, sm, wp, ln, predicates_size, predicates);
}

/**
 * \fn CUDBGAPI_st::readPredicates
 * \brief Reads content of hardware predicate registers.
 *
 * Since CUDA 6.5.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param predicates_size - number of predicate registers to read
 * \param predicates - buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readCodeMemory
 * \sa readConstMemory
 * \sa readGenericMemory
 * \sa readGlobalMemory
 * \sa readParamMemory
 * \sa readSharedMemory
 * \sa readTextureMemory
 * \sa readLocalMemory
 * \sa readRegister
 * \sa readPC
 */
CUDBGResult
gpudbgReadPredicates(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t predicates_size, uint32_t *predicates)
{
    CudbgDevice dev;

    CUDBG_VERIFY(predicates, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_LN_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp, ln);

    dev = haloGlobals.device[devId];

    CUDBG_VERIFY(predicates_size <= dev->halo.deviceInfo.numPredicatesPrLane, CUDBG_ERROR_INVALID_ARGS, "Invalid # of predicates\n");

    return gpudbgReadPredicatesInternal(devId, sm, wp, ln, predicates_size, predicates);
}

/**
 * \fn CUDBGAPI_st::writePredicates
 * \brief Writes content to hardware predicate registers.
 *
 * Since CUDA 6.5.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param predicates_size - number of predicate registers to write
 * \param[in] predicates - buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa writeConstMemory
 * \sa writeGenericMemory
 * \sa writeGlobalMemory
 * \sa writeParamMemory
 * \sa writeSharedMemory
 * \sa writeTextureMemory
 * \sa writeLocalMemory
 * \sa writeRegister
 */
CUDBGResult
gpudbgWritePredicates(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t predicates_size, const uint32_t *predicates)
{
    CudbgDevice dev;
    DebugPatch patch;
    CUDBGResult res = CUDBG_SUCCESS;
    bool inPatch;

    CUDBG_VERIFY(predicates, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_LN_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp, ln);

    dev = haloGlobals.device[devId];

    CUDBG_VERIFY(predicates_size <= dev->halo.deviceInfo.numPredicatesPrLane, CUDBG_ERROR_INVALID_ARGS, "Invalid # of predicates\n");

    res = threadInPatch(dev, sm, wp, ln, &patch, &inPatch);
    if (res != CUDBG_SUCCESS)
        return res;

    if (inPatch &&
        !patch->debug &&
        HALO_PATCH_MODIFIES_PRED(patch->kind))
        return writePatchPred(dev, patch, sm, wp, ln, predicates_size, predicates);
    else
        return dev->halo.writePredicates(dev, sm, wp, ln, predicates_size, predicates);
}

CUDBGResult
gpudbgReadCCRegisterInternal(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t *val)
{
    CudbgDevice dev;
    DebugPatch patch;
    CUDBGResult res = CUDBG_SUCCESS;
    bool inPatch;

    dev = haloGlobals.device[devId];

    res = threadInPatch(dev, sm, wp, ln, &patch, &inPatch);
    if (res != CUDBG_SUCCESS)
        return res;

    if (inPatch &&
        !patch->debug &&
        HALO_PATCH_MODIFIES_CC(patch->kind))
        return readPatchCC(dev, patch, sm, wp, ln, val);
    else
        return dev->halo.readCCRegister(dev, sm, wp, ln, val);
}

/**
 * \fn CUDBGAPI_st::readCCRegister
 * \brief Reads the hardware CC register.
 *
 * Since CUDA 6.5.
 *
 * \ingroup READ
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param val - buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa readCodeMemory
 * \sa readConstMemory
 * \sa readGenericMemory
 * \sa readGlobalMemory
 * \sa readParamMemory
 * \sa readSharedMemory
 * \sa readTextureMemory
 * \sa readLocalMemory
 * \sa readRegister
 * \sa readPC
 * \sa readPredicates
 */
CUDBGResult
gpudbgReadCCRegister(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t *val)
{
    CUDBG_VERIFY(val, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_LN_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp, ln);

    return gpudbgReadCCRegisterInternal(devId, sm, wp, ln, val);
}

/**
 * \fn CUDBGAPI_st::writeCCRegister
 * \brief Writes the hardware CC register.
 *
 * Since CUDA 6.5.
 *
 * \ingroup WRITE
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param val - value to write to the CC register
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_INVALID_LANE,
 * \return CUDBG_ERROR_INVALID_SM,
 * \return CUDBG_ERROR_INVALID_WARP,
 * \return CUDBG_ERROR_UNINITIALIZED
 *
 * \sa writeConstMemory
 * \sa writeGenericMemory
 * \sa writeGlobalMemory
 * \sa writeParamMemory
 * \sa writeSharedMemory
 * \sa writeTextureMemory
 * \sa writeLocalMemory
 * \sa writeRegister
 * \sa writePredicates
 */
CUDBGResult
gpudbgWriteCCRegister(uint32_t devId, uint32_t sm, uint32_t wp, uint32_t ln, uint32_t val)
{
    CudbgDevice dev;
    DebugPatch patch;
    CUDBGResult res = CUDBG_SUCCESS;
    bool inPatch;

    CUDBG_API_CHECK(CUDBG_API_CHECK_GROUP(CUDBG_API_CHECK_LN_VALID) |
                    CUDBG_API_CHECK_DEV_ACTIVECTX,
                    devId, sm, wp, ln);

    dev = haloGlobals.device[devId];

    res = threadInPatch(dev, sm, wp, ln, &patch, &inPatch);
    if (res != CUDBG_SUCCESS)
        return res;

    if (inPatch &&
        !patch->debug &&
        HALO_PATCH_MODIFIES_CC(patch->kind))
        return writePatchCC(dev, patch, sm, wp, ln, val);
    else
        return dev->halo.writeCCRegister(dev, sm, wp, ln, val);
}

typedef struct {
    uint64_t devPtr;
    Context parentContext;
    bool foundOnNonUvaDevice;
} SearchContextForDevPtrToken_t;

/* This function handles the following cases:
 * Case 1: UVA is enabled on all devices but peer mapping is disabled. So a
 *         memblock containing a VA should be present only in one context on
 *         one device.
 *
 * Case 2: UVA is enabled on all devices but peer mappings are enabled on some
 *         devices only. Devices with peer-mapping enabled will have memblocks
 *         containing the VA, others will not. The memblocks on peer-mapped
 *         devices will all point to the same sourceMemblock.
 *
 * Case 3: UVA is not enabled on one or more of the devices in use. If the
 *         address is found on more than one device and one of these devices
 *         does not have UVA enabled, an error is returned.
 */
static CUDBGResult
searchContextForDevPtr(Context context, SearchContextForDevPtrToken_t *token)
{
    CUDBGResult res;
    haloMemorySegment *seg = NULL;
    CUdev *pDev;
    bool nonUvaDevice = false;
    bool alreadyFound = (token->parentContext != NULL);

    if (!context->memMapActive)
        return CUDBG_SUCCESS;

    /* Look for a memory segment that contains this devPtr */
    res = haloMemoryMapGetSegmentByDevPtr(context->memMap, token->devPtr, &seg);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Check if this context is on a non-UVA device */
    pDev = globals.devices[context->dev->deviceIdx];
    if (!pDev->state.canDoUva)
        nonUvaDevice = true;

    /* In multi-GPU scenarios with peer mapping enabled, the same devvaddr
     * will be in two segs. Matching the seg's sourceDeviceIdx with the
     * context's gets us the context that originally allocated the devvaddr.
     */
    if (seg && seg->sourceDeviceIdx == (uint32_t)context->dev->deviceIdx) {
        /* If this address was previously found, and if either this device
         * or on the previous device did not have UVA enabled, then there
         * is address alasing. Return an error. */
        if (alreadyFound && (nonUvaDevice || token->foundOnNonUvaDevice))
            return CUDBG_ERROR_AMBIGUOUS_MEMORY_ADDRESS;

        /* Record the fact that the address was found on a non-UVA device */
        token->foundOnNonUvaDevice |= nonUvaDevice;

        if (!alreadyFound)
            token->parentContext = context;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
findParentContextForDevPtr(uint64_t devPtr, Context *parentContext)
{
    CUDBGResult res;
    SearchContextForDevPtrToken_t token = {0};

    CUDBG_VERIFY(parentContext, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    token.devPtr = devPtr;
    token.parentContext = NULL;
    token.foundOnNonUvaDevice = false;

    res = haloStateTraverseContexts((haloCtxIterFunc)searchContextForDevPtr,
                                    &token);
    if (res != CUDBG_SUCCESS)
        return res;

    /* If the parent context was not found, it means a bogus devPtr was passed */
    if (token.parentContext == NULL)
        return CUDBG_ERROR_INVALID_MEMORY_ACCESS;

    API_TRACE_FUNCTION(40, "DevPtr 0x%llx found on device %d\n",
                       devPtr, token.parentContext->dev->deviceIdx);

    *parentContext = token.parentContext;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::readGlobalMemory
 * \brief Reads content at an address in the global address space.
 *        If the address is valid on more than one device and one
 *        of those devices does not support UVA, an error is returned.
 *
 * Since CUDA 6.0.
 *
 * \ingroup READ
 *
 * \param addr - memory address
 * \param[in] buf - buffer
 * \param buf_size - size of the buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_MEMORY_MAPPING_FAILED,
 * \return CUDBG_ERROR_INVALID_MEMORY_ACCESS,
 * \return CUDBG_ERROR_ADDRESS_NOT_IN_DEVICE_MEM
 * \return CUDBG_ERROR_AMBIGUOUS_MEMORY_ADDRESS_
 *
 * \sa readCodeMemory
 * \sa readConstMemory
 * \sa readParamMemory
 * \sa readSharedMemory
 * \sa readTextureMemory
 * \sa readLocalMemory
 * \sa readRegister
 * \sa readPC
 */
CUDBGResult
gpudbgReadGlobalMemory (uint64_t devPtr, void *buf, uint32_t buf_size)
{
    CUDBGResult res;
    Context context;

    CUDBG_VERIFY(buf, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_VERIFY(buf_size, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    res = findParentContextForDevPtr(devPtr, &context);
    CUDBG_VERIFY((res == CUDBG_SUCCESS), res, "Failed to find parent context for devPtr 0x%llx\n", devPtr);

    return context->dev->halo.readGenericMemory(context, 0, 0, 0, devPtr, buf, buf_size);
}

/**
 * \fn CUDBGAPI_st::writeGlobalMemory
 * \brief Writes content to an address in the global address space.
 *        If the address is valid on more than one device and one
 *        of those devices does not support UVA, an error is returned.
 *
 * Since CUDA 6.0.
 *
 * \ingroup WRITE
 *
 * \param dev - device index
 * \param sm - SM index
 * \param wp - warp index
 * \param ln - lane index
 * \param addr - memory address
 * \param[in] buf - buffer
 * \param buf_size - size of the buffer
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_DEVICE,
 * \return CUDBG_ERROR_UNINITIALIZED,
 * \return CUDBG_ERROR_MEMORY_MAPPING_FAILED,
 * \return CUDBG_ERROR_INVALID_MEMORY_ACCESS,
 * \return CUDBG_ERROR_ADDRESS_NOT_IN_DEVICE_MEM
 * \return CUDBG_ERROR_AMBIGUOUS_MEMORY_ADDRESS_
 *
 * \sa writeParamMemory
 * \sa writeSharedMemory
 * \sa writeLocalMemory
 * \sa writeRegister
 */
CUDBGResult
gpudbgWriteGlobalMemory (uint64_t devPtr, const void *buf, uint32_t buf_size)
{
    CUDBGResult res;
    Context context;

    CUDBG_VERIFY(buf, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_VERIFY(buf_size, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    res = findParentContextForDevPtr(devPtr, &context);
    CUDBG_VERIFY((res == CUDBG_SUCCESS), res, "Failed to find parent context for devPtr 0x%llx\n", devPtr);

    return context->dev->halo.writeGenericMemory(context, 0, 0, 0, devPtr, buf, buf_size);
}

typedef struct getManagedRegionInfoToken_st GetManagedRegionInfoToken;
struct getManagedRegionInfoToken_st {
    uint64_t startAddress;
    HaloMemoryRegion *memoryInfo;
    uint32_t numEntriesWritten;
    uint32_t maxEntries;
};

static CUDBGResult
storeManagedRegionExtents(uint64_t address, uint64_t size, void *entry, void* data)
{
    haloMemorySegment *seg = (haloMemorySegment *)entry;
    GetManagedRegionInfoToken *token = (GetManagedRegionInfoToken*)data;

    /* Return early if the buffer is full or this isn't a managed memory block. */
    if (token->numEntriesWritten >= token->maxEntries ||
        haloMemorySegmentGetBlockType(seg) != CU_MEM_TYPE_MANAGED)
        return CUDBG_SUCCESS;

    /* Skip segments that don't lie in the region the user cares about */
    if (token->startAddress > (address + size - 1))
        return CUDBG_SUCCESS;

    token->memoryInfo[token->numEntriesWritten].startAddress = address;
    token->memoryInfo[token->numEntriesWritten].size = size;
    token->numEntriesWritten++;

    return CUDBG_SUCCESS;
}

/**
 * \fn CUDBGAPI_st::getManagedMemoryRegionInfo
 * \brief Returns a sorted list of managed memory regions
 *        The sorted list of memory regions starts from a region containing the
 *        specified starting address. If the starting address is set to 0, a
 *        sorted list of managed memory regions is returned which starts from
 *        the managed memory region with the lowest start address.
 *
 * Since CUDA 6.0.
 *
 * \ingroup READ
 *
 * \param startAddress - The address that the first region in the list must contain.
 *                       If the starting address is set to 0, the list of managed memory regions
 *                       returned starts from the managed memory region with the lowest start address.
 * \param memoryInfo - Client-allocated array of memory region records of type CUDBGMemoryInfo.
 * \param memoryInfo_size - Number of records of type CUDBGMemoryInfo that memoryInfo can hold.
 * \param numEntries - Pointer to a client-allocated variable holding the number of valid
 *                     entries retured in memoryInfo. Valid entries are continguous and start
 *                     from memoryInfo[0].
 *
 * \return CUDBG_SUCCESS,
 * \return CUDBG_ERROR_INVALID_ARGS,
 * \return CUDBG_ERROR_INVALID_ADDRESS,
 * \return CUDBG_ERROR_INTERNAL
 */
CUDBGResult
gpudbgGetManagedMemoryRegionInfo (uint64_t startAddress, CUDBGMemoryInfo *memoryInfo,
                                  uint32_t memoryInfo_size, uint32_t *numEntries)
{
    uint32_t i;
    CUDBGResult res;
    HaloMemoryRegion *haloMemoryInfo = NULL;
    GetManagedRegionInfoToken token = {0};

    CUDBG_VERIFY(memoryInfo && numEntries && memoryInfo_size, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments\n");

    CUDBG_API_CHECK(CUDBG_API_CHECK_INIT            |
                    CUDBG_API_CHECK_TLS_CB,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT,
                    CUDBG_API_CHECK_DEFAULT);

    *numEntries = 0;
    haloMemoryInfo = (HaloMemoryRegion *)calloc(memoryInfo_size, sizeof *haloMemoryInfo);
    CUDBG_VERIFY(haloMemoryInfo != NULL, CUDBG_ERROR_INTERNAL, "Out of memory\n");

    token.startAddress = startAddress;
    token.memoryInfo = haloMemoryInfo;
    token.numEntriesWritten = 0;
    token.maxEntries = memoryInfo_size;

    res = haloMemoryMapTraverseGlobalHostVAMap(storeManagedRegionExtents, &token);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Failed to get managed memory region info\n");
        goto done;
    }

    *numEntries = token.numEntriesWritten;

    for (i = 0; i < *numEntries; i++) {
        memoryInfo[i].startAddress = haloMemoryInfo[i].startAddress;
        memoryInfo[i].size = haloMemoryInfo[i].size;
    }

done:
    free(haloMemoryInfo);

    return res;
}
