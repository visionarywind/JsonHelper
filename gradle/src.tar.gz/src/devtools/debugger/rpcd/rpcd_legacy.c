/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: rpcd_legacy.c
 *
 *   Description:
 *       Implementations of rpcdProcessDebugClientMessage() for legacy clients
 *
 ******************************************************************************/

#include <cuos_platform.h>
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()

#include "rpcd.h"
#include <libcudbg_legacy.h>
#include <cudadebugger.h>
#include <cudbgapi.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

/* Globals from rpcd.c */
extern CUDBGAPI cudbgapi;
extern CUDBGResult cudbgapiInitializationResult;

/* Deprecated after CUDA 5.0.
   Only uses defines/structures/APIs that existed in 5.0. */
CUDBGResult
rpcdProcessDebugClientMessage50(void *msgBuffer, volatile bool *terminate, volatile bool *clientFinalized)
{
    CUDBGResult res;
    CUDBGAPIMSG50_t *message;
    uint64_t messageSize;
    bool dynamicData = false;
    bool resultProcessed = false;

    /* API temporaries */
    uint32_t dev, sm, wp, ln, dim, texid, regno, val, numPairs, level, gridId;
    uint32_t *coords;
    uint64_t addr, pc, sz;
    void *elfImage;
    bool relocated;
    CUDBGAttribute attr;
    CUDBGEvent50 event;

    /* Pointer to dynamic data (after the static message structure) */
    void *p;
    CUDBG_VERIFY(msgBuffer && terminate && clientFinalized,
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments in rpcdProcessDebugClientMessage.\n");

    /* Point to the message */
    message = (CUDBGAPIMSG50_t *)msgBuffer;

    messageSize = sizeof *message;

    /* Point after the static message structure (dynamic data) */
    p = (char *)message + messageSize;

    /* Copy API temporaries */
    dev      = message->apiData.request.dev;
    sm       = message->apiData.request.sm;
    wp       = message->apiData.request.wp;
    ln       = message->apiData.request.ln;
    dim      = message->apiData.request.dim;
    texid    = message->apiData.request.texid;
    addr     = message->apiData.request.addr;
    sz       = message->apiData.request.sz;
    regno    = message->apiData.request.regno;
    level    = message->apiData.request.level;
    val      = message->apiData.request.val;
    pc       = message->apiData.request.pc;
    numPairs = message->apiData.request.numPairs;
    attr     = (CUDBGAttribute)message->apiData.request.attr;
    coords   = message->apiData.request.coords;

    CUDBG_VERIFY(cudbgapi, CUDBG_ERROR_UNINITIALIZED,
                 "API not initialized in rpcdProcessDebugClientMessage.\n");

    /* Decode the client's request.
       Note:  APIs prior to 4.0 are no longer supported through this interface. */
    switch (message->kind) {

        /* Initialization */
    case CUDBGAPIREQ5x_initialize:
        res = rpcdCheckClientVersion(message->client_major,
                                     message->client_minor,
                                     message->client_rev);
        if (res != CUDBG_SUCCESS)
            message->result = res;
        else
            /* The API was initialized before receiving the request. Return
               the result that we had saved back then. */
            message->result = cudbgapiInitializationResult;

        /* Set the clientRevision in the API to the right value by calling
           cudbgGetAPI again, now that we have the correct client revision
           number. */
        res = rpcdGetDebugAPI(message->client_major,
                              message->client_minor,
                              message->client_rev, &cudbgapi);
        if (res != CUDBG_SUCCESS)
            message->result = res;
        break;
    case CUDBGAPIREQ5x_initializeAttachStub:
        message->result = cudbgapi->initializeAttachStub();
        break;
    case CUDBGAPIREQ5x_finalize:
        message->result = cudbgapi->finalize();
        *terminate = *clientFinalized = true;
        break;
    case CUDBGAPIREQ5x_clearAttachState:
        message->result = cudbgapi->clearAttachState();
        break;
    case CUDBGAPIREQ5x_requestCleanupOnDetach:
        message->result = cudbgapi->requestCleanupOnDetach55();
        break;

        /* API Version Query */
    case CUDBGAPIREQ5x_getAPIVersion:
        message->result = cudbgGetAPIVersion(&message->apiData.result.major, &message->apiData.result.minor, &message->apiData.result.rev);
        break;

        /* Device Execution Control */
    case CUDBGAPIREQ5x_suspendDevice:
        message->result = cudbgapi->suspendDevice(dev);
        break;
    case CUDBGAPIREQ5x_resumeDevice:
        message->result = cudbgapi->resumeDevice(dev);
        break;
    case CUDBGAPIREQ5x_singleStepWarp:
        message->result = cudbgapi->singleStepWarp41(dev, sm, wp, &message->apiData.result.value /* hijacked */);
        break;

        /* Breakpoints */
    case CUDBGAPIREQ5x_setBreakpoint:
        message->result = cudbgapi->setBreakpoint(dev, addr);
        break;
    case CUDBGAPIREQ5x_unsetBreakpoint:
        message->result = cudbgapi->unsetBreakpoint(dev, addr);
        break;

        /* Device State Inspection */
    case CUDBGAPIREQ5x_readGridId50:
        message->result = cudbgapi->readGridId50(dev, sm, wp, &message->apiData.result.gridId);
        break;
    case CUDBGAPIREQ5x_readBlockIdx:
        message->result = cudbgapi->readBlockIdx(dev, sm, wp, (CuDim3 *)&message->apiData.result.blockIdx);
        break;
    case CUDBGAPIREQ5x_readThreadIdx:
        message->result = cudbgapi->readThreadIdx(dev, sm, wp, ln, (CuDim3 *)&message->apiData.result.threadIdx);
        break;
    case CUDBGAPIREQ5x_readBrokenWarps:
        message->result = cudbgapi->readBrokenWarps(dev, sm, &message->apiData.result.brokenWarpsMask);
        break;
    case CUDBGAPIREQ5x_readValidWarps:
        message->result = cudbgapi->readValidWarps(dev, sm, &message->apiData.result.validWarpsMask);
        break;
    case CUDBGAPIREQ5x_readValidLanes:
        message->result = cudbgapi->readValidLanes(dev, sm, wp, &message->apiData.result.validLanesMask);
        break;
    case CUDBGAPIREQ5x_readActiveLanes:
        message->result = cudbgapi->readActiveLanes(dev, sm, wp, &message->apiData.result.activeLanesMask);
        break;
    case CUDBGAPIREQ5x_readPinnedMemory:
        message->result = cudbgapi->readPinnedMemory(addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_readCodeMemory:
        message->result = cudbgapi->readCodeMemory(dev, addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_readGlobalMemory:
        message->result = cudbgapi->readGlobalMemory55(dev, sm, wp, ln, addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_readTextureMemory:
        message->result = cudbgapi->readTextureMemory(dev, sm, wp, texid, dim, coords, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_readTextureMemoryBindless:
        message->result = cudbgapi->readTextureMemoryBindless(dev, sm, wp, texid, dim, coords, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_readConstMemory:
        message->result = cudbgapi->readConstMemory(dev, addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_readParamMemory:
        message->result = cudbgapi->readParamMemory(dev, sm, wp, addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_readSharedMemory:
        message->result = cudbgapi->readSharedMemory(dev, sm, wp, addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_readLocalMemory:
        message->result = cudbgapi->readLocalMemory(dev, sm, wp, ln, addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_readRegister:
        message->result = cudbgapi->readRegister(dev, sm, wp, ln, regno, &message->apiData.result.val);
        break;
    case CUDBGAPIREQ5x_readPC:
        message->result = cudbgapi->readPC(dev, sm, wp, ln, &message->apiData.result.pc);
        break;
    case CUDBGAPIREQ5x_readVirtualPC:
        message->result = cudbgapi->readVirtualPC(dev, sm, wp, ln, &message->apiData.result.pc);
        break;
    case CUDBGAPIREQ5x_readLaneStatus:
        message->apiData.result.error = 0;
        message->result = cudbgapi->readLaneStatus(dev, sm, wp, ln, (bool *)&message->apiData.result.error);
        break;
    case CUDBGAPIREQ5x_readLaneException:
        message->result = cudbgapi->readLaneException(dev, sm, wp, ln, (CUDBGException_t *)&message->apiData.result.exception);
        break;
    case CUDBGAPIREQ5x_readCallDepth:
        message->result = cudbgapi->readCallDepth(dev, sm, wp, ln, &message->apiData.result.depth);
        break;
    case CUDBGAPIREQ5x_readSyscallCallDepth:
        message->result = cudbgapi->readSyscallCallDepth(dev, sm, wp, ln, &message->apiData.result.depth);
        break;
    case CUDBGAPIREQ5x_readReturnAddress:
        message->result = cudbgapi->readReturnAddress(dev, sm, wp, ln, level, &message->apiData.result.ra);
        break;
    case CUDBGAPIREQ5x_readVirtualReturnAddress:
        message->result = cudbgapi->readVirtualReturnAddress(dev, sm, wp, ln, level, &message->apiData.result.ra);
        break;

        /* Device State Alteration */
    case CUDBGAPIREQ5x_writePinnedMemory:
        message->result = cudbgapi->writePinnedMemory(addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_writeGlobalMemory:
        message->result = cudbgapi->writeGlobalMemory55(dev, sm, wp, ln, addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_writeParamMemory:
        message->result = cudbgapi->writeParamMemory(dev, sm, wp, addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_writeSharedMemory:
        message->result = cudbgapi->writeSharedMemory(dev, sm, wp, addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_writeLocalMemory:
        message->result = cudbgapi->writeLocalMemory(dev, sm, wp, ln, addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_writeRegister:
        message->result = cudbgapi->writeRegister(dev, sm, wp, ln, regno, val);
        break;

        /* Grid Properties */
    case CUDBGAPIREQ5x_getGridDim:
        message->result = cudbgapi->getGridDim(dev, sm, wp, (CuDim3 *)&message->apiData.result.gridDim);
        break;
    case CUDBGAPIREQ5x_getBlockDim:
        message->result = cudbgapi->getBlockDim(dev, sm, wp, (CuDim3 *)&message->apiData.result.blockDim);
        break;
    case CUDBGAPIREQ5x_getTID:
        message->result = cudbgapi->getTID(dev, sm, wp, &message->apiData.result.tid);
        break;
    case CUDBGAPIREQ5x_getElfImage:
        relocated = message->apiData.request.relocated;
        message->result = cudbgapi->getElfImage(dev, sm, wp, relocated, &elfImage, &message->apiData.result.size);
        p = elfImage; /* Update p -- the client was not able to preallocate this */
        sz = message->apiData.result.size; /* Update sz */
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_getGridAttribute:
        message->result = cudbgapi->getGridAttribute(dev, sm, wp, attr, &message->apiData.result.value);
        break;
    case CUDBGAPIREQ5x_getGridAttributes:
        message->result = cudbgapi->getGridAttributes(dev, sm, wp, (CUDBGAttributeValuePair *)p, numPairs);
        sz = numPairs * sizeof (CUDBGAttributeValuePair); /* Update sz */
        dynamicData = true;
        break;

        /* Device Properties */
    case CUDBGAPIREQ5x_getDeviceType:
        message->result = cudbgapi->getDeviceType(dev, (char *)p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_getSmType:
        message->result = cudbgapi->getSmType(dev, (char *)p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_getNumDevices:
        message->result = cudbgapi->getNumDevices(&message->apiData.result.numDevices);
        break;
    case CUDBGAPIREQ5x_getNumSMs:
        message->result = cudbgapi->getNumSMs(dev, &message->apiData.result.numSMs);
        break;
    case CUDBGAPIREQ5x_getNumWarps:
        message->result = cudbgapi->getNumWarps(dev, &message->apiData.result.numWarps);
        break;
    case CUDBGAPIREQ5x_getNumLanes:
        message->result = cudbgapi->getNumLanes(dev, &message->apiData.result.numLanes);
        break;
    case CUDBGAPIREQ5x_getNumRegisters:
        message->result = cudbgapi->getNumRegisters(dev, &message->apiData.result.numRegs);
        break;

        /* DWARF-related routines */
    case CUDBGAPIREQ5x_getPhysicalRegister40:
        message->result = cudbgapi->getPhysicalRegister40(dev, sm, wp, pc,
                                                          (char *)p, (uint32_t *)((char *)p + strlen((char *)p) + 1),
                                                          sz, &message->apiData.result.numPhysRegs,
                                                          (CUDBGRegClass *)&message->apiData.result.regClass);
        p = (void *)((char *)p + strlen((char *)p) + 1); /* Update p */
        sz = message->apiData.result.numPhysRegs * sizeof (uint32_t); /* Update sz */
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_disassemble:
        message->result = cudbgapi->disassemble(dev, addr, &message->apiData.result.instSize, (char *)p, sz);
        sz = strlen((const char *)p) + 1; /* Update sz */
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_isDeviceCodeAddress:
        message->apiData.result.isDeviceAddress = 0;
        message->result = cudbgapi->isDeviceCodeAddress55(addr, (bool *)&message->apiData.result.isDeviceAddress);
        break;
    case CUDBGAPIREQ5x_lookupDeviceCodeSymbol:
        message->apiData.result.symFound = 0;
        message->result = cudbgapi->lookupDeviceCodeSymbol((char *)p,
                                                           (bool *)&message->apiData.result.symFound,
                                                           (uintptr_t *)&message->apiData.result.symAddr);
        break;

        /* Events */
    case CUDBGAPIREQ5x_setNotifyNewEventCallback:
        message->result = cudbgapi->setNotifyNewEventCallback((CUDBGNotifyNewEventCallback)rpcdNotifyDebugClientCallback);
        break;
    case CUDBGAPIREQ5x_acknowledgeEvents42: /* Deprecated in CUDA 5.0 */
    case CUDBGAPIREQ5x_acknowledgeSyncEvents:
        message->result = cudbgapi->acknowledgeSyncEvents();
        break;
    case CUDBGAPIREQ5x_getHostAddrFromDeviceAddr:
        message->result = cudbgapi->getHostAddrFromDeviceAddr(dev, addr, &message->apiData.result.ra);
        break;
    case CUDBGAPIREQ5x_getNextEvent42: /* Deprecated in CUDA 5.0 */
    case CUDBGAPIREQ5x_getNextSyncEvent50:
    case CUDBGAPIREQ5x_getNextAsyncEvent50:

        if (message->kind == CUDBGAPIREQ5x_getNextAsyncEvent50)
            /* Legacy Event */
            message->result = cudbgapi->getNextAsyncEvent50(&event);
        else
            /* Asynchronous Event */
            message->result = cudbgapi->getNextSyncEvent50(&event);

        /* Each field in the event structure must be copied individually. */

        message->apiData.result.event.kind = event.kind;
        switch (event.kind) {
        case CUDBG_EVENT_ELF_IMAGE_LOADED:
            message->apiData.result.event.cases.elfImageLoaded.relocatedElfImage =
                (uint64_t)(uintptr_t)event.cases.elfImageLoaded.relocatedElfImage;
            message->apiData.result.event.cases.elfImageLoaded.nonRelocatedElfImage =
                (uint64_t)(uintptr_t)event.cases.elfImageLoaded.nonRelocatedElfImage;
            message->apiData.result.event.cases.elfImageLoaded.size32 = (uint32_t)event.cases.elfImageLoaded.size;
            message->apiData.result.event.cases.elfImageLoaded.dev = event.cases.elfImageLoaded.dev;
            message->apiData.result.event.cases.elfImageLoaded.context = event.cases.elfImageLoaded.context;
            message->apiData.result.event.cases.elfImageLoaded.module = event.cases.elfImageLoaded.module;
            message->apiData.result.event.cases.elfImageLoaded.size = event.cases.elfImageLoaded.size;

            res = rpcdPushMessage(message, messageSize);
            if (res != CUDBG_SUCCESS) {
                RPCD_TRACE_FUNCTION(0, "Cannot push message (%d). Terminating. \n", res);
                return res;
            }

            res = rpcdPushMessage((void *)(uintptr_t)message->apiData.result.event.cases.elfImageLoaded.relocatedElfImage,
                                  message->apiData.result.event.cases.elfImageLoaded.size);
            if (res != CUDBG_SUCCESS) {
                RPCD_TRACE_FUNCTION(0, "Cannot push message (%d). Terminating. \n", res);
                return res;
            }

            res = rpcdPushMessage((void *)(uintptr_t)message->apiData.result.event.cases.elfImageLoaded.nonRelocatedElfImage,
                                  message->apiData.result.event.cases.elfImageLoaded.size);
            if (res != CUDBG_SUCCESS) {
                RPCD_TRACE_FUNCTION(0, "Cannot push message (%d). Terminating. \n", res);
                return res;
            }

            resultProcessed = true;
            break;
        case CUDBG_EVENT_KERNEL_READY:
            message->apiData.result.event.cases.kernelReady.dev = event.cases.kernelReady.dev;
            message->apiData.result.event.cases.kernelReady.gridId = event.cases.kernelReady.gridId;
            message->apiData.result.event.cases.kernelReady.tid = event.cases.kernelReady.tid;
            message->apiData.result.event.cases.kernelReady.context = event.cases.kernelReady.context;
            message->apiData.result.event.cases.kernelReady.module = event.cases.kernelReady.module;
            message->apiData.result.event.cases.kernelReady.function = event.cases.kernelReady.function;
            message->apiData.result.event.cases.kernelReady.functionEntry = event.cases.kernelReady.functionEntry;
            message->apiData.result.event.cases.kernelReady.gridDim.x = event.cases.kernelReady.gridDim.x;
            message->apiData.result.event.cases.kernelReady.gridDim.y = event.cases.kernelReady.gridDim.y;
            message->apiData.result.event.cases.kernelReady.gridDim.z = event.cases.kernelReady.gridDim.z;
            message->apiData.result.event.cases.kernelReady.blockDim.x = event.cases.kernelReady.blockDim.x;
            message->apiData.result.event.cases.kernelReady.blockDim.y = event.cases.kernelReady.blockDim.y;
            message->apiData.result.event.cases.kernelReady.blockDim.z = event.cases.kernelReady.blockDim.z;
            message->apiData.result.event.cases.kernelReady.type = event.cases.kernelReady.type;
            break;
        case CUDBG_EVENT_KERNEL_FINISHED:
            message->apiData.result.event.cases.kernelFinished.dev = event.cases.kernelFinished.dev;
            message->apiData.result.event.cases.kernelReady.gridId = event.cases.kernelReady.gridId;
            message->apiData.result.event.cases.kernelFinished.tid = event.cases.kernelFinished.tid;
            message->apiData.result.event.cases.kernelFinished.context = event.cases.kernelFinished.context;
            message->apiData.result.event.cases.kernelFinished.module = event.cases.kernelFinished.module;
            message->apiData.result.event.cases.kernelFinished.function = event.cases.kernelFinished.function;
            message->apiData.result.event.cases.kernelFinished.functionEntry = event.cases.kernelFinished.functionEntry;
            break;
        case CUDBG_EVENT_INTERNAL_ERROR:
            message->apiData.result.event.cases.internalError.errorType = event.cases.internalError.errorType;
            break;
        case CUDBG_EVENT_CTX_PUSH:
            message->apiData.result.event.cases.contextPush.dev = event.cases.contextPush.dev;
            message->apiData.result.event.cases.contextPush.tid = event.cases.contextPush.tid;
            message->apiData.result.event.cases.contextPush.context = event.cases.contextPush.context;
            break;
        case CUDBG_EVENT_CTX_POP:
            message->apiData.result.event.cases.contextPop.dev = event.cases.contextPop.dev;
            message->apiData.result.event.cases.contextPop.tid = event.cases.contextPop.tid;
            message->apiData.result.event.cases.contextPop.context = event.cases.contextPop.context;
            break;
        case CUDBG_EVENT_CTX_CREATE:
            message->apiData.result.event.cases.contextCreate.dev = event.cases.contextCreate.dev;
            message->apiData.result.event.cases.contextCreate.tid = event.cases.contextCreate.tid;
            message->apiData.result.event.cases.contextCreate.context = event.cases.contextCreate.context;
            break;
        case CUDBG_EVENT_CTX_DESTROY:
            message->apiData.result.event.cases.contextDestroy.dev = event.cases.contextDestroy.dev;
            message->apiData.result.event.cases.contextDestroy.tid = event.cases.contextDestroy.tid;
            message->apiData.result.event.cases.contextDestroy.context = event.cases.contextDestroy.context;
            break;
        case CUDBG_EVENT_TIMEOUT:
            break;
        case CUDBG_EVENT_ATTACH_COMPLETE:
            break;
        case CUDBG_EVENT_DETACH_COMPLETE:
            break;
        case CUDBG_EVENT_INVALID:
            break;
        default:
            break;
        }
        break;

        /* Memcheck Related entry points */
    case CUDBGAPIREQ5x_memcheckReadErrorAddress:
        message->result = cudbgapi->memcheckReadErrorAddress(dev, sm, wp, ln, (uint64_t*)&message->apiData.result.ra, (ptxStorageKind *)&message->apiData.result.regClass);
        break;
    case CUDBGAPIREQ5x_getGridStatus50:
        gridId = message->apiData.request.val;
        message->result = cudbgapi->getGridStatus50(dev, gridId, (CUDBGGridStatus *)&message->apiData.result.val);
        break;
    default:
        RPCD_TRACE_FUNCTION(0, "Received unknown message from client debugger (%d)\n", message->kind);
        *terminate = true;
        return CUDBG_ERROR_UNKNOWN;
    }

    /* Send results to debug client */
    if (!resultProcessed) {
        res = rpcdPushMessage(message, messageSize);
        if (res != CUDBG_SUCCESS) {
            RPCD_TRACE_FUNCTION(0, "Cannot push message (%d). Terminating. \n", res);
            *terminate = true;
            return res;
        }

        if (dynamicData) {
            res = rpcdPushMessage(p, sz);
            if (res != CUDBG_SUCCESS) {
                RPCD_TRACE_FUNCTION(0, "Cannot push dynamicData (%d). Terminating. \n", res);
                *terminate = true;
                return res;
            }
        }
    }

    res = rpcdSendMessage();
    if (res != CUDBG_SUCCESS) {
        RPCD_TRACE_FUNCTION(0, "Cannot push send message (%d). Terminating. \n", res);
        *terminate = true;
        return res;
    }

    return CUDBG_SUCCESS;
}
/* Deprecated after CUDA 5.5.
   Only uses defines/structures/APIs that existed in 5.5. */
CUDBGResult
rpcdProcessDebugClientMessage55(void *msgBuffer, volatile bool *terminate, volatile bool *clientFinalized)
{
    CUDBGResult res;
    CUDBGAPIMSG_t *message;
    uint64_t messageSize;
    bool dynamicData = false;
    bool resultProcessed = false;

    /* API temporaries */
    uint32_t dev, sm, wp, ln, dim, texid, regno, val, numPairs, level;
    uint64_t gridId64;
    uint32_t *coords;
    uint64_t addr, pc, sz;
    void *elfImage;
    bool relocated;
    CUDBGAttribute attr;
    CUDBGEvent55 event55;

    /* Pointer to dynamic data (after the static message structure) */
    void *p;
    CUDBG_VERIFY(msgBuffer && terminate && clientFinalized,
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments in rpcdProcessDebugClientMessage55.\n");

    /* Point to the message */
    message = (CUDBGAPIMSG_t *)msgBuffer;

    messageSize = sizeof (CUDBGAPIMSG_t);

    /* Point after the static message structure (dynamic data) */
    p = (char *)message + messageSize;

    /* Copy API temporaries */
    dev      = message->apiData.request.dev;
    sm       = message->apiData.request.sm;
    wp       = message->apiData.request.wp;
    ln       = message->apiData.request.ln;
    dim      = message->apiData.request.dim;
    texid    = message->apiData.request.texid;
    addr     = message->apiData.request.addr;
    sz       = message->apiData.request.sz;
    regno    = message->apiData.request.regno;
    level    = message->apiData.request.level;
    val      = message->apiData.request.val;
    pc       = message->apiData.request.pc;
    numPairs = message->apiData.request.numPairs;
    attr     = (CUDBGAttribute)message->apiData.request.attr;
    coords   = message->apiData.request.coords;
    gridId64 = message->apiData.request.gridId64;

    CUDBG_VERIFY(cudbgapi, CUDBG_ERROR_UNINITIALIZED,
                 "API not initialized in rpcdProcessDebugClientMessage55.\n");

    /* Decode the client's request.
       Note:  APIs prior to 4.0 are no longer supported through this interface. */
    switch (message->kind) {

        /* Initialization */
    case CUDBGAPIREQ5x_initialize:
        res = rpcdCheckClientVersion(message->client_major,
                                     message->client_minor,
                                     message->client_rev);
        if (res != CUDBG_SUCCESS)
            message->result = res;
        else
            /* The API was initialized before receiving the request. Return
               the result that we had saved back then. */
            message->result = cudbgapiInitializationResult;

        /* Set the clientRevision in the API to the right value by calling
           cudbgGetAPI again, now that we have the correct client revision
           number. */
        res = rpcdGetDebugAPI(message->client_major,
                              message->client_minor,
                              message->client_rev, &cudbgapi);
        if (res != CUDBG_SUCCESS)
            message->result = res;
        break;
    case CUDBGAPIREQ5x_initializeAttachStub:
        message->result = cudbgapi->initializeAttachStub();
        break;
    case CUDBGAPIREQ5x_finalize:
        message->result = cudbgapi->finalize();
        *terminate = *clientFinalized = true;
        break;
    case CUDBGAPIREQ5x_clearAttachState:
        message->result = cudbgapi->clearAttachState();
        break;
    case CUDBGAPIREQ5x_requestCleanupOnDetach:
        message->result = cudbgapi->requestCleanupOnDetach55();
        break;

        /* API Version Query */
    case CUDBGAPIREQ5x_getAPIVersion:
        message->result = cudbgGetAPIVersion(&message->apiData.result.major, &message->apiData.result.minor, &message->apiData.result.rev);
        break;

        /* Device Execution Control */
    case CUDBGAPIREQ5x_suspendDevice:
        message->result = cudbgapi->suspendDevice(dev);
        break;
    case CUDBGAPIREQ5x_resumeDevice:
        message->result = cudbgapi->resumeDevice(dev);
        break;
    case CUDBGAPIREQ5x_singleStepWarp:
        message->result = cudbgapi->singleStepWarp41(dev, sm, wp, &message->apiData.result.value /* hijacked */);
        break;

        /* Breakpoints */
    case CUDBGAPIREQ5x_setBreakpoint:
        message->result = cudbgapi->setBreakpoint(dev, addr);
        break;
    case CUDBGAPIREQ5x_unsetBreakpoint:
        message->result = cudbgapi->unsetBreakpoint(dev, addr);
        break;
    case CUDBGAPIREQ5x_getAdjustedCodeAddress:
        message->result = cudbgapi->getAdjustedCodeAddress(dev, addr, &message->apiData.result.value, (CUDBGAdjAddrAction)attr);
        break;

        /* Device State Inspection */
    case CUDBGAPIREQ5x_readGridId:
        message->result = cudbgapi->readGridId(dev, sm, wp, &message->apiData.result.gridId64);
        break;
    case CUDBGAPIREQ5x_readBlockIdx:
        message->result = cudbgapi->readBlockIdx(dev, sm, wp, (CuDim3 *)&message->apiData.result.blockIdx);
        break;
    case CUDBGAPIREQ5x_readThreadIdx:
        message->result = cudbgapi->readThreadIdx(dev, sm, wp, ln, (CuDim3 *)&message->apiData.result.threadIdx);
        break;
    case CUDBGAPIREQ5x_readBrokenWarps:
        message->result = cudbgapi->readBrokenWarps(dev, sm, &message->apiData.result.brokenWarpsMask);
        break;
    case CUDBGAPIREQ5x_readValidWarps:
        message->result = cudbgapi->readValidWarps(dev, sm, &message->apiData.result.validWarpsMask);
        break;
    case CUDBGAPIREQ5x_readValidLanes:
        message->result = cudbgapi->readValidLanes(dev, sm, wp, &message->apiData.result.validLanesMask);
        break;
    case CUDBGAPIREQ5x_readActiveLanes:
        message->result = cudbgapi->readActiveLanes(dev, sm, wp, &message->apiData.result.activeLanesMask);
        break;
    case CUDBGAPIREQ5x_readPinnedMemory:
        message->result = cudbgapi->readPinnedMemory(addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_readCodeMemory:
        message->result = cudbgapi->readCodeMemory(dev, addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_readGlobalMemory:
        message->result = cudbgapi->readGlobalMemory55(dev, sm, wp, ln, addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_readTextureMemory:
        message->result = cudbgapi->readTextureMemory(dev, sm, wp, texid, dim, coords, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_readTextureMemoryBindless:
        message->result = cudbgapi->readTextureMemoryBindless(dev, sm, wp, texid, dim, coords, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_readConstMemory:
        message->result = cudbgapi->readConstMemory(dev, addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_readParamMemory:
        message->result = cudbgapi->readParamMemory(dev, sm, wp, addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_readSharedMemory:
        message->result = cudbgapi->readSharedMemory(dev, sm, wp, addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_readLocalMemory:
        message->result = cudbgapi->readLocalMemory(dev, sm, wp, ln, addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_readRegister:
        message->result = cudbgapi->readRegister(dev, sm, wp, ln, regno, &message->apiData.result.val);
        break;
    case CUDBGAPIREQ5x_readPC:
        message->result = cudbgapi->readPC(dev, sm, wp, ln, &message->apiData.result.pc);
        break;
    case CUDBGAPIREQ5x_readVirtualPC:
        message->result = cudbgapi->readVirtualPC(dev, sm, wp, ln, &message->apiData.result.pc);
        break;
    case CUDBGAPIREQ5x_readLaneStatus:
        message->apiData.result.error = 0;
        message->result = cudbgapi->readLaneStatus(dev, sm, wp, ln, (bool *)&message->apiData.result.error);
        break;
    case CUDBGAPIREQ5x_readLaneException:
        message->result = cudbgapi->readLaneException(dev, sm, wp, ln, (CUDBGException_t *)&message->apiData.result.exception);
        break;
    case CUDBGAPIREQ5x_readCallDepth:
        message->result = cudbgapi->readCallDepth(dev, sm, wp, ln, &message->apiData.result.depth);
        break;
    case CUDBGAPIREQ5x_readSyscallCallDepth:
        message->result = cudbgapi->readSyscallCallDepth(dev, sm, wp, ln, &message->apiData.result.depth);
        break;
    case CUDBGAPIREQ5x_readReturnAddress:
        message->result = cudbgapi->readReturnAddress(dev, sm, wp, ln, level, &message->apiData.result.ra);
        break;
    case CUDBGAPIREQ5x_readVirtualReturnAddress:
        message->result = cudbgapi->readVirtualReturnAddress(dev, sm, wp, ln, level, &message->apiData.result.ra);
        break;

        /* Device State Alteration */
    case CUDBGAPIREQ5x_writePinnedMemory:
        message->result = cudbgapi->writePinnedMemory(addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_writeGlobalMemory:
        message->result = cudbgapi->writeGlobalMemory55(dev, sm, wp, ln, addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_writeParamMemory:
        message->result = cudbgapi->writeParamMemory(dev, sm, wp, addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_writeSharedMemory:
        message->result = cudbgapi->writeSharedMemory(dev, sm, wp, addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_writeLocalMemory:
        message->result = cudbgapi->writeLocalMemory(dev, sm, wp, ln, addr, p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_writeRegister:
        message->result = cudbgapi->writeRegister(dev, sm, wp, ln, regno, val);
        break;

        /* Grid Properties */
    case CUDBGAPIREQ5x_getGridDim:
        message->result = cudbgapi->getGridDim(dev, sm, wp, (CuDim3 *)&message->apiData.result.gridDim);
        break;
    case CUDBGAPIREQ5x_getBlockDim:
        message->result = cudbgapi->getBlockDim(dev, sm, wp, (CuDim3 *)&message->apiData.result.blockDim);
        break;
    case CUDBGAPIREQ5x_getTID:
        message->result = cudbgapi->getTID(dev, sm, wp, &message->apiData.result.tid);
        break;
    case CUDBGAPIREQ5x_getElfImage:
        relocated = message->apiData.request.relocated;
        message->result = cudbgapi->getElfImage(dev, sm, wp, relocated, &elfImage, &message->apiData.result.size);
        p = elfImage; /* Update p -- the client was not able to preallocate this */
        sz = message->apiData.result.size; /* Update sz */
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_getElfImageByHandle:
        relocated = message->apiData.request.relocated;
        message->result = cudbgapi->getElfImageByHandle (dev, /* handle */ pc, relocated ? CUDBG_ELF_IMAGE_TYPE_RELOCATED : CUDBG_ELF_IMAGE_TYPE_NONRELOCATED, (void *)p, sz);
        dynamicData = true;
        break;

    case CUDBGAPIREQ5x_getGridAttribute:
        message->result = cudbgapi->getGridAttribute(dev, sm, wp, attr, &message->apiData.result.value);
        break;
    case CUDBGAPIREQ5x_getGridAttributes:
        message->result = cudbgapi->getGridAttributes(dev, sm, wp, (CUDBGAttributeValuePair *)p, numPairs);
        sz = numPairs * sizeof (CUDBGAttributeValuePair); /* Update sz */
        dynamicData = true;
        break;

        /* Device Properties */
    case CUDBGAPIREQ5x_getDeviceType:
        message->result = cudbgapi->getDeviceType(dev, (char *)p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_getSmType:
        message->result = cudbgapi->getSmType(dev, (char *)p, sz);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_getNumDevices:
        message->result = cudbgapi->getNumDevices(&message->apiData.result.numDevices);
        break;
    case CUDBGAPIREQ5x_getNumSMs:
        message->result = cudbgapi->getNumSMs(dev, &message->apiData.result.numSMs);
        break;
    case CUDBGAPIREQ5x_getNumWarps:
        message->result = cudbgapi->getNumWarps(dev, &message->apiData.result.numWarps);
        break;
    case CUDBGAPIREQ5x_getNumLanes:
        message->result = cudbgapi->getNumLanes(dev, &message->apiData.result.numLanes);
        break;
    case CUDBGAPIREQ5x_getNumRegisters:
        message->result = cudbgapi->getNumRegisters(dev, &message->apiData.result.numRegs);
        break;

        /* DWARF-related routines */
    case CUDBGAPIREQ5x_getPhysicalRegister40:
        message->result = cudbgapi->getPhysicalRegister40(dev, sm, wp, pc,
                                                          (char *)p, (uint32_t *)((char *)p + strlen((char *)p) + 1),
                                                          sz, &message->apiData.result.numPhysRegs,
                                                          (CUDBGRegClass *)&message->apiData.result.regClass);
        p = (void *)((char *)p + strlen((char *)p) + 1); /* Update p */
        sz = message->apiData.result.numPhysRegs * sizeof (uint32_t); /* Update sz */
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_disassemble:
        message->result = cudbgapi->disassemble(dev, addr, &message->apiData.result.instSize, (char *)p, sz);
        sz = strlen((const char *)p) + 1; /* Update sz */
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_isDeviceCodeAddress:
        message->apiData.result.isDeviceAddress = 0;
        message->result = cudbgapi->isDeviceCodeAddress55(addr, (bool *)&message->apiData.result.isDeviceAddress);
        break;
    case CUDBGAPIREQ5x_lookupDeviceCodeSymbol:
        message->apiData.result.symFound = 0;
        message->result = cudbgapi->lookupDeviceCodeSymbol((char *)p,
                                                           (bool *)&message->apiData.result.symFound,
                                                           (uintptr_t *)&message->apiData.result.symAddr);
        break;

        /* Events */
    case CUDBGAPIREQ5x_setNotifyNewEventCallback:
        message->result = cudbgapi->setNotifyNewEventCallback((CUDBGNotifyNewEventCallback)rpcdNotifyDebugClientCallback);
        break;
    case CUDBGAPIREQ5x_acknowledgeEvents42: /* Deprecated in CUDA 5.0 */
    case CUDBGAPIREQ5x_acknowledgeSyncEvents:
        message->result = cudbgapi->acknowledgeSyncEvents();
        break;
    case CUDBGAPIREQ5x_getHostAddrFromDeviceAddr:
        message->result = cudbgapi->getHostAddrFromDeviceAddr(dev, addr, &message->apiData.result.ra);
        break;
    case CUDBGAPIREQ5x_getNextEvent:
        message->result = cudbgapi->getNextEvent((CUDBGEventQueueType)attr, (CUDBGEvent *)p);
        sz = sizeof(CUDBGEvent);
        dynamicData = true;
        break;
    case CUDBGAPIREQ5x_getNextEvent42: /* Deprecated in CUDA 5.0 */
    case CUDBGAPIREQ5x_getNextSyncEvent55: /* Deprecated in CUDA 6.0 */
    case CUDBGAPIREQ5x_getNextAsyncEvent55:/* Deprecated in CUDA 6.0 */

        /* Always use the most recent version of the API call below. */
        if (message->kind == CUDBGAPIREQ5x_getNextAsyncEvent55)
            /* Legacy Event */
            message->result = cudbgapi->getNextAsyncEvent55(&event55);
        else
            /* Asynchronous Event */
            message->result = cudbgapi->getNextSyncEvent55(&event55);

        /* Each field in the event structure must be copied individually. */

        message->apiData.result.event.kind = event55.kind;
        switch (event55.kind) {
        case CUDBG_EVENT_ELF_IMAGE_LOADED:
            message->apiData.result.event.cases.elfImageLoaded.relocatedElfImage =
                (uint64_t)(uintptr_t)event55.cases.elfImageLoaded.relocatedElfImage;
            message->apiData.result.event.cases.elfImageLoaded.nonRelocatedElfImage =
                (uint64_t)(uintptr_t)event55.cases.elfImageLoaded.nonRelocatedElfImage;
            message->apiData.result.event.cases.elfImageLoaded.size32 = (uint32_t)event55.cases.elfImageLoaded.size;
            message->apiData.result.event.cases.elfImageLoaded.dev = event55.cases.elfImageLoaded.dev;
            message->apiData.result.event.cases.elfImageLoaded.context = event55.cases.elfImageLoaded.context;
            message->apiData.result.event.cases.elfImageLoaded.module = event55.cases.elfImageLoaded.module;
            message->apiData.result.event.cases.elfImageLoaded.size = event55.cases.elfImageLoaded.size;

            res = rpcdPushMessage(message, messageSize);
            if (res != CUDBG_SUCCESS) {
                RPCD_TRACE_FUNCTION(0, "Cannot push message (%d). Terminating. \n", res);
                return res;
            }

            res = rpcdPushMessage((void *)(uintptr_t)message->apiData.result.event.cases.elfImageLoaded.relocatedElfImage,
                                  message->apiData.result.event.cases.elfImageLoaded.size);
            if (res != CUDBG_SUCCESS) {
                RPCD_TRACE_FUNCTION(0, "Cannot push message (%d). Terminating. \n", res);
                return res;
            }

            res = rpcdPushMessage((void *)(uintptr_t)message->apiData.result.event.cases.elfImageLoaded.nonRelocatedElfImage,
                                  message->apiData.result.event.cases.elfImageLoaded.size);
            if (res != CUDBG_SUCCESS) {
                RPCD_TRACE_FUNCTION(0, "Cannot push message (%d). Terminating. \n", res);
                return res;
            }

            resultProcessed = true;
            break;
        case CUDBG_EVENT_KERNEL_READY:
            message->apiData.result.event.cases.kernelReady.dev = event55.cases.kernelReady.dev;
            message->apiData.result.event.cases.kernelReady.gridId64 = event55.cases.kernelReady.gridId64;
            message->apiData.result.event.cases.kernelReady.tid = event55.cases.kernelReady.tid;
            message->apiData.result.event.cases.kernelReady.context = event55.cases.kernelReady.context;
            message->apiData.result.event.cases.kernelReady.module = event55.cases.kernelReady.module;
            message->apiData.result.event.cases.kernelReady.function = event55.cases.kernelReady.function;
            message->apiData.result.event.cases.kernelReady.functionEntry = event55.cases.kernelReady.functionEntry;
            message->apiData.result.event.cases.kernelReady.gridDim.x = event55.cases.kernelReady.gridDim.x;
            message->apiData.result.event.cases.kernelReady.gridDim.y = event55.cases.kernelReady.gridDim.y;
            message->apiData.result.event.cases.kernelReady.gridDim.z = event55.cases.kernelReady.gridDim.z;
            message->apiData.result.event.cases.kernelReady.blockDim.x = event55.cases.kernelReady.blockDim.x;
            message->apiData.result.event.cases.kernelReady.blockDim.y = event55.cases.kernelReady.blockDim.y;
            message->apiData.result.event.cases.kernelReady.blockDim.z = event55.cases.kernelReady.blockDim.z;
            message->apiData.result.event.cases.kernelReady.type = event55.cases.kernelReady.type;
            message->apiData.result.event.cases.kernelReady.parentGridId = event55.cases.kernelReady.parentGridId;
            message->apiData.result.event.cases.kernelReady.origin = event55.cases.kernelReady.origin;
            break;
        case CUDBG_EVENT_KERNEL_FINISHED:
            message->apiData.result.event.cases.kernelFinished.dev = event55.cases.kernelFinished.dev;
            message->apiData.result.event.cases.kernelFinished.gridId64 = event55.cases.kernelFinished.gridId64;
            message->apiData.result.event.cases.kernelFinished.tid = event55.cases.kernelFinished.tid;
            message->apiData.result.event.cases.kernelFinished.context = event55.cases.kernelFinished.context;
            message->apiData.result.event.cases.kernelFinished.module = event55.cases.kernelFinished.module;
            message->apiData.result.event.cases.kernelFinished.function = event55.cases.kernelFinished.function;
            message->apiData.result.event.cases.kernelFinished.functionEntry = event55.cases.kernelFinished.functionEntry;
            break;
        case CUDBG_EVENT_INTERNAL_ERROR:
            message->apiData.result.event.cases.internalError.errorType = event55.cases.internalError.errorType;
            break;
        case CUDBG_EVENT_CTX_PUSH:
            message->apiData.result.event.cases.contextPush.dev = event55.cases.contextPush.dev;
            message->apiData.result.event.cases.contextPush.tid = event55.cases.contextPush.tid;
            message->apiData.result.event.cases.contextPush.context = event55.cases.contextPush.context;
            break;
        case CUDBG_EVENT_CTX_POP:
            message->apiData.result.event.cases.contextPop.dev = event55.cases.contextPop.dev;
            message->apiData.result.event.cases.contextPop.tid = event55.cases.contextPop.tid;
            message->apiData.result.event.cases.contextPop.context = event55.cases.contextPop.context;
            break;
        case CUDBG_EVENT_CTX_CREATE:
            message->apiData.result.event.cases.contextCreate.dev = event55.cases.contextCreate.dev;
            message->apiData.result.event.cases.contextCreate.tid = event55.cases.contextCreate.tid;
            message->apiData.result.event.cases.contextCreate.context = event55.cases.contextCreate.context;
            break;
        case CUDBG_EVENT_CTX_DESTROY:
            message->apiData.result.event.cases.contextDestroy.dev = event55.cases.contextDestroy.dev;
            message->apiData.result.event.cases.contextDestroy.tid = event55.cases.contextDestroy.tid;
            message->apiData.result.event.cases.contextDestroy.context = event55.cases.contextDestroy.context;
            break;
        case CUDBG_EVENT_TIMEOUT:
            break;
        case CUDBG_EVENT_ATTACH_COMPLETE:
            break;
        case CUDBG_EVENT_DETACH_COMPLETE:
            break;
        case CUDBG_EVENT_INVALID:
            break;
        default:
            break;
        }
        break;

        /* Memcheck Related entry points */
    case CUDBGAPIREQ5x_memcheckReadErrorAddress:
        message->result = cudbgapi->memcheckReadErrorAddress(dev, sm, wp, ln, (uint64_t*)&message->apiData.result.ra, (ptxStorageKind *)&message->apiData.result.regClass);
        break;
    case CUDBGAPIREQ5x_getGridStatus:
        message->result = cudbgapi->getGridStatus(dev, gridId64, (CUDBGGridStatus *)&message->apiData.result.val);
        break;
    case CUDBGAPIREQ5x_getGridInfo:
        message->result = cudbgapi->getGridInfo(dev, gridId64, (CUDBGGridInfo *)p);
        dynamicData = true;
        break;

        /* Debugger async launch notification policy */
    case CUDBGAPIREQ5x_setKernelLaunchNotificationMode:
        message->result = cudbgapi->setKernelLaunchNotificationMode((CUDBGKernelLaunchNotifyMode)val);
        break;

        /* Get PCI BUS ID */
    case CUDBGAPIREQ5x_getDevicePCIBusInfo:
        message->result = cudbgapi->getDevicePCIBusInfo(dev,
                                                        &message->apiData.result.pciBusId,
                                                        &message->apiData.result.pciDevId );
        break;

        /* Read the SMs that have pending exceptions
           NOTE : Reusing value as this allows us to not change the struct layout */
    case CUDBGAPIREQ5x_readDeviceExceptionState:
        message->result = cudbgapi->readDeviceExceptionState80(dev,
                                                             &message->apiData.result.value);
        break;

        /* Get the PC at which an error occurred */
    case CUDBGAPIREQ5x_readErrorPC:
        message->apiData.result.error = 0;
        message->result = cudbgapi->readErrorPC(dev, sm, wp, &message->apiData.result.pc,
                                                (bool*)&message->apiData.result.error);
        break;

    default:
        RPCD_TRACE_FUNCTION(0, "Received unknown message from client debugger (%d)\n", message->kind);
        *terminate = true;
        return CUDBG_ERROR_UNKNOWN;
    }

    /* Send results to debug client */
    if (!resultProcessed) {
        res = rpcdPushMessage(message, messageSize);
        if (res != CUDBG_SUCCESS) {
            RPCD_TRACE_FUNCTION(0, "Cannot push message (%d). Terminating. \n", res);
            *terminate = true;
            return res;
        }

        if (dynamicData) {
            res = rpcdPushMessage(p, sz);
            if (res != CUDBG_SUCCESS) {
                RPCD_TRACE_FUNCTION(0, "Cannot push dynamicData (%d). Terminating. \n", res);
                *terminate = true;
                return res;
            }
        }
    }

    res = rpcdSendMessage();
    if (res != CUDBG_SUCCESS) {
        RPCD_TRACE_FUNCTION(0, "Cannot push send message (%d). Terminating. \n", res);
        *terminate = true;
        return res;
    }

    return CUDBG_SUCCESS;
}


#endif
