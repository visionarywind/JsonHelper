/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: rpcd.c
 *
 *   Description:
 *       Implementation of the Debugger RPC Daemon.
 *
 ******************************************************************************/

#include <cuos_platform.h>
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()

#include "rpcd.h"
#include "stub.h"
#include <cudadebugger.h>
#include <cudbgpipe.h>
#include <cudbgapi.h>
#include <libcudbg_legacy.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>

/* Globals */
CUDBGAPI cudbgapi = NULL;
static void *rpcdTempBuffer = NULL;
static uint64_t rpcdTempBufferSize = 0;
cudbg_pipe_t rpcdToDebugClient;
cudbg_pipe_t debugClientToRpcd;
cudbg_pipe_t rpcdCBToDebugClient;
CUDBGResult cudbgapiInitializationResult;
static uint32_t saved_client_rev = 0;

static CUDBGResult rpcdInitializeAPI(uint32_t major, uint32_t minor, uint32_t rev);

/* Debug Client Notification Payloads (Terminate, Timeout) */
typedef enum {
    RPCD_NOTIFY_TERMINATE_FALSE,
    RPCD_NOTIFY_TERMINATE_TRUE,
} rpcdNotifyTerminate_t;

typedef enum {
    RPCD_NOTIFY_TIMEOUT_FALSE,
    RPCD_NOTIFY_TIMEOUT_TRUE,
} rpcdNotifyTimeout_t;

static CUDBGResult
rpcdNotifyDebugClientCallbackSendMsg(uint32_t tid, uint32_t terminate, uint32_t timeout)
{
    void *clientCBData;
    uint64_t clientCBDataSize;
    CUDBGResult res = CUDBG_SUCCESS;
    CUDBGCBMSG40_t cbData40;
    CUDBGCBMSG_t cbData;

    /* API_REVISION_4_1 introduced a larger callback structure (for timeout) */
    if (saved_client_rev < API_REVISION_4_1) {

        memset(&cbData40, 0, sizeof cbData40);
        cbData40.tid       = tid;
        cbData40.terminate = terminate;

        clientCBData = &cbData40;
        clientCBDataSize = sizeof cbData40;
    }
    else {
        memset(&cbData, 0, sizeof cbData);
        cbData.tid       = tid;
        cbData.terminate = terminate;
        cbData.timeout   = timeout;

        clientCBData = &cbData;
        clientCBDataSize = sizeof cbData;
    }

    res = cudbgPipeWrite(&rpcdCBToDebugClient, clientCBData, clientCBDataSize);
    if (res != CUDBG_SUCCESS) {
        RPCD_TRACE_FUNCTION(0, "cudbgPipeWrite failed with %d (ignoring)\n", res);
        return res;
    }

    return CUDBG_SUCCESS;
}

CUDBGResult
rpcdNotifyDebugClientCallback(CUDBGEventCallbackData *data)
{
    /* Generic callback; indicate payloads, but never terminate */
    return rpcdNotifyDebugClientCallbackSendMsg(data->tid,
                                                RPCD_NOTIFY_TERMINATE_FALSE,
                                                data->timeout);
}

static CUDBGResult
rpcdNotifyDebugClientCallbackTerminate(void)
{
    /* Only set the terminate field, that's all that's needed */
    return rpcdNotifyDebugClientCallbackSendMsg(0 /* TID not needed */,
                                                RPCD_NOTIFY_TERMINATE_TRUE,
                                                RPCD_NOTIFY_TIMEOUT_FALSE);
}

static CUDBGResult
rpcdNotifyDebugClientCallbackInitFailure(void)
{
    /* Send an empty message -- we only need to wake up the client */
    return rpcdNotifyDebugClientCallbackSendMsg(0 /* TID not needed */,
                                                RPCD_NOTIFY_TERMINATE_FALSE,
                                                RPCD_NOTIFY_TIMEOUT_FALSE);
}

CUDBGResult
rpcdPushMessage(void *obj, uint64_t objSize)
{
    CUDBGResult res;

    /* if nothing to push, don't bother */
    if (!obj || !objSize)
        return CUDBG_SUCCESS;

    /* append object to the message to be sent to the debug client */
    if ((res = cudbgPipeMessageAppend(&rpcdToDebugClient, obj, objSize))) {
        RPCD_TRACE_FUNCTION(0, "Failed to append message (res = %d)\n", res);
        return res;
    }

    return CUDBG_SUCCESS;
}

CUDBGResult
rpcdSendMessage(void)
{
    CUDBGResult res;

    /* send the message */
    if ((res = cudbgPipeMessageSend(&rpcdToDebugClient))) {
        RPCD_TRACE_FUNCTION(0, "Failed to send message (res = %d)\n", res);
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult rpcdWaitForMessage(volatile bool *terminate, volatile bool *clientFinalized)
{
    CUDBGResult res;
    bool retry = false;

    /* Sanity check of the arguments are done in rpcdProcessDebugClientMessage, they are not
       used here anyway */

    if ((res = cudbgPipeWaitForData(&debugClientToRpcd, NULL))) {
        RPCD_TRACE_FUNCTION(0, "Failed to wait for data (res = %d)\n", res);
        return res;
    }

    if ((res = cudbgPipeMessageRead(&debugClientToRpcd, &retry))) {
        RPCD_TRACE_FUNCTION(0, "Failed to read message data (res = %d)\n", res);
        return res;
    }

    if (retry)
        RPCD_TRACE_FUNCTION(10, "rpcdWaitForMessage (retry = %d), didn't receive message!\n", retry);

    /* if retry was set, we must return (maintaining all
       state in the debugClientToRpcd pipe).  We'll
       come back to finish later. */
    if (retry)
        return CUDBG_SUCCESS;
    if (*((uint32_t *)debugClientToRpcd.message[0]) > 5) {
        if ((res = rpcdProcessDebugClientMessage(debugClientToRpcd.message[0], debugClientToRpcd.messageSize[0], terminate, clientFinalized))) {
            RPCD_TRACE_FUNCTION(0, "Error processing debug client message (res = %d)\n", res);
            return res;
        }
    }
    else if (saved_client_rev >= API_REVISION_5_5_RC) {
        if ((res = rpcdProcessDebugClientMessage55(debugClientToRpcd.message[0], terminate, clientFinalized))) {
            RPCD_TRACE_FUNCTION(0, "Error processing debug client message (res = %d)\n", res);
            return res;
        }
    }
    else if ((res = rpcdProcessDebugClientMessage50(debugClientToRpcd.message[0], terminate, clientFinalized))) {
        RPCD_TRACE_FUNCTION(0, "Error processing debug client message (res = %d)\n", res);
        return res;
    }

    return CUDBG_SUCCESS;
}

static void
rpcdHandleFatalSignals(int signo)
{
    CUDBGResult res = CUDBG_SUCCESS;

    RPCD_ERROR("Signal %d received.\n", signo);

    if (cudbgapi) {
        RPCD_TRACE_FUNCTION(0, "Cleaning up device state.\n");
        /* Use the lightweight cleanup mechanism here to ensure
           the devices are not left in a bad state.  We cannot
           issue a full finalize at this point, because it is
           not guaranteed that the receiving thread is still
           alive (that could be the reason we're here!), so
           this one is safe. */
        res = tgdbResetAllDevices();
        (void)res;
        RPCD_TRACE_FUNCTION(0, "Cleanup complete. Result: %d\n", res);
    }
    else
        RPCD_TRACE_FUNCTION(0, "cudbgapi not initialized, no state to cleanup.\n");

    _exit(1);
}

#if cuosOsIsAndroid()
#include <sys/mman.h>

static bool
armIsBreakpointInsn(void *addr)
{
#if cuosArchIsARMv7()
  /* Check for thumb breakpoint*/
  return *(unsigned short *)addr == 0xde01;
#endif
#if cuosArchIsARMv8()
  return *(unsigned long *)addr == 0x00800011;
#endif
  return false;
}

static void
armWriteReturnInstruction(void *addr)
{
#if cuosArchIsARMv7()
    /* Replace thumb breakpoint with "bx lr" */
    *(unsigned short *) addr = 0x4770;
#endif
#if cuosArchIsARMv8()
    /* Replace breakpoint instruction with "ret" */
    *(unsigned long *) addr = 0xd65f03c0;
#endif
}


#if cuosArchIsARMv8()
static void
aarch64CacheFlush(unsigned long from, unsigned long to)
{
    unsigned long addr;

   /* Clear data cache within the specified range  */
    for (addr = from; addr < to; addr += 16)
        __asm __volatile("dc cvau, %0" :: "r"(addr));

    /*Data stream barrier for pending stores */
    __asm__ __volatile("dsb st");

    /* Invalidate instruction cache in the specified range */
    for (addr = from; addr < to; addr += 16)
        __asm __volatile("ic ivau, %0" :: "r"(addr));

    /* Instruction stream barrier*/
    __asm__ __volatile("isb");
}
#endif

static void
rpcdHandleSigtrap (int sig, struct siginfo *info, void *opaque)
{
    void *pageAddr;
    int rc;

    if (info == 0 || info->si_addr == 0) {
        RPCD_ERROR("SIG_TRAP signal received without SIGINFO.\n");
        _exit(1);
    }

    if (!armIsBreakpointInsn(info->si_addr)) {
        RPCD_ERROR("SIG_TRAP signal received at %p, value 0x%x\n", info->si_addr, *(unsigned int *)info->si_addr);
        _exit(1);

    }

    pageAddr = (void *)(((unsigned long)info->si_addr)&~(PAGE_SIZE-1));
    rc = mprotect(pageAddr, PAGE_SIZE, PROT_READ|PROT_WRITE);
    if (rc != 0) {
        RPCD_ERROR("Failed to change memory protection for page %p.", pageAddr);
        _exit(1);
    }
    armWriteReturnInstruction(info->si_addr);
    rc = mprotect (pageAddr, PAGE_SIZE, PROT_READ|PROT_EXEC);
    if (rc != 0) {
        RPCD_ERROR("Failed to change memory protection for page %p.", pageAddr);
        _exit(1);
    }

    /* Flush instruction & data caches for that page */
#if cuosArchIsARMv7()
    /* Use syscall on ARMv7*/
    cacheflush ((long int)pageAddr, (unsigned long int)pageAddr+PAGE_SIZE, 0);
#endif
#if cuosArchIsARMv8()
    /* Use our own implementation of cacheflush on ARMv8 */
    aarch64CacheFlush ((unsigned long)pageAddr, (unsigned long)pageAddr+PAGE_SIZE);
#endif
}
#endif

static CUDBGResult
rpcdHandleSignals(void)
{
#if cuosOsIsAndroid()
    struct sigaction signalAction;
#endif
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()
    sigset_t signalSet;

    /* Create an empty signal set */
    sigemptyset(&signalSet);

    /* Add SIGINT to the signal set */
    sigaddset(&signalSet, SIGINT);

    /* Block SIGINT from this thread (notificationDispatcher).
     * We want GDB to be the _only_ SIGINT recipient. */
    sigprocmask(SIG_BLOCK, &signalSet, NULL);

    signal(SIGPIPE, rpcdHandleFatalSignals);
    signal(SIGSEGV, rpcdHandleFatalSignals);
    signal(SIGHUP, SIG_IGN);
#endif

#if cuosOsIsAndroid()
    memset(&signalAction, 0, sizeof signalAction);

    signalAction.sa_flags = SA_SIGINFO;
    signalAction.sa_sigaction = rpcdHandleSigtrap;
    sigaction (SIGTRAP, &signalAction, NULL);
#endif

    return CUDBG_SUCCESS;
}

CUDBGResult
rpcdGetTempBuffer(void **ptr, uint64_t size)
{
    if (ptr == NULL) {
        RPCD_TRACE_FUNCTION(0, "First argument is NULL\n");
        return CUDBG_ERROR_INVALID_ARGS;
    }

    if (size > rpcdTempBufferSize) {
        void *rc = realloc (rpcdTempBuffer, size);
        if (rc == NULL) {
            RPCD_TRACE_FUNCTION(0, "Failed to allocate %ld bytes\n", (unsigned long) size);
            return CUDBG_ERROR_INTERNAL;
        }

        rpcdTempBuffer = rc;
        rpcdTempBufferSize = size;
    }

    *ptr = rpcdTempBuffer;

    return CUDBG_SUCCESS;
}

static CUDBGResult
rpcdSetup(void)
{
    CUDBGResult res;

    /* Set up the signal mask */
    res = rpcdHandleSignals();
    if (res != CUDBG_SUCCESS) {
        RPCD_TRACE_FUNCTION(0, "Failed to mask SIGINT (res = %d)\n", res);
        return res;
    }

    /* Initialize outgoing pipe */
    res = cudbgPipeInitialize(&rpcdToDebugClient,
                              CUDBG_PIPE_TYPE_NAMED_WRITE,
                              CUDBG_PIPE_ENDPOINT_RPCD,
                              CUDBG_PIPE_ENDPOINT_DEBUG_CLIENT);
    if (res != CUDBG_SUCCESS) {
        RPCD_TRACE_FUNCTION(0, "Failed to initialize write pipe (res = %d)\n", res);
        return res;
    }

    /* Initialize incoming pipe */
    res = cudbgPipeInitialize(&debugClientToRpcd,
                              CUDBG_PIPE_TYPE_NAMED_READ,
                              CUDBG_PIPE_ENDPOINT_DEBUG_CLIENT,
                              CUDBG_PIPE_ENDPOINT_RPCD);
    if (res != CUDBG_SUCCESS) {
        RPCD_TRACE_FUNCTION(0, "Failed to initialize read pipe (res = %d)\n", res);
        return res;
    }

    /* Initialize event pipe */
    res = cudbgPipeInitialize(&rpcdCBToDebugClient,
                              CUDBG_PIPE_TYPE_NAMED_WRITE,
                              CUDBG_PIPE_ENDPOINT_RPCD_CB,
                              CUDBG_PIPE_ENDPOINT_DEBUG_CLIENT_CB);
    if (res != CUDBG_SUCCESS) {
        RPCD_TRACE_FUNCTION(0, "Failed to initialize event (write) pipe (res = %d)\n", res);
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
rpcdTeardown(bool clientFinalized)
{
    CUDBGResult res;

    /* Tell the callback listener we're finished here */
    RPCD_TRACE_FUNCTION(1, "Attempting to notify client to terminate!\n");
    res = rpcdNotifyDebugClientCallbackTerminate();
    if (res != CUDBG_SUCCESS) {
        RPCD_TRACE_FUNCTION(0, "Error notifying callback termination!\n");
        return res;
    }

    /* Finalize all communication */
    RPCD_TRACE_FUNCTION(1, "Finalizing pipes\n");
    res = cudbgPipeFinalize(&rpcdToDebugClient);
    if (res != CUDBG_SUCCESS)
        return res;

    res = cudbgPipeFinalize(&debugClientToRpcd);
    if (res != CUDBG_SUCCESS)
        return res;

    res = cudbgPipeFinalize(&rpcdCBToDebugClient);
    if (res != CUDBG_SUCCESS)
        return res;

    if (rpcdTempBuffer)
        free (rpcdTempBuffer);

    if (!clientFinalized) {
        RPCD_TRACE_FUNCTION(1, "Client didn't cleanly finalize; resetting devices\n");
        res = tgdbResetAllDevices();
        if (res != CUDBG_SUCCESS)
            RPCD_TRACE_FUNCTION(0, "Attempt at resetting devices failed (res=%d)\n", res);
    }

    RPCD_TRACE_FUNCTION(1, "Returning success\n");
    return CUDBG_SUCCESS;
}

CUDBGResult
rpcdGetDebugAPI(uint32_t major, uint32_t minor, uint32_t rev, CUDBGAPI *api)
{
    CUDBGResult res;
    uint32_t api_major = 0, api_minor = 0, api_rev = 0;

    /* The Debugger RPC Daemon queries the actual debug API */
    res = cudbgGetAPI(major, minor, rev, api);

    switch (res) {
    case CUDBG_SUCCESS:
        return res;

    case CUDBG_ERROR_INITIALIZATION_FAILURE:
        RPCD_TRACE_FUNCTION(0,
                            "RPCD failed initializing the Debug API. "
                            "Likely cause is X running on all devices.\n");
        break;
    case CUDBG_ERROR_INCOMPATIBLE_API:
        (void)cudbgGetAPIVersion(&api_major, &api_minor, &api_rev);
        RPCD_TRACE_FUNCTION(0,
                            "RPCD needs CUDA Debugger API version %d.%d.%d, but got %d.%d.%d.\n"
                            "Please check that the correct CUDA driver is in your environment.\n",
                            major, minor, rev, api_major, api_minor, api_rev);
        break;
    default:
        RPCD_TRACE_FUNCTION(0,
                            "RPCD failed intializing the Debug API with error %d.\n",
                            res);
        break;
    }

    return res; /* This is always a point of failure */
}

CUDBGResult
rpcdCheckClientVersion(uint32_t major, uint32_t minor, uint32_t rev)
{
    RPCD_TRACE_FUNCTION(1, "debug client is using version %d.%d.%d\n",
                        major, minor, rev);

    /* Save the client revision for future reference */
    saved_client_rev = rev;

    /* Same version check as in cudbgapi.c:cudbgGetAPI() */
    CUDBG_VERIFY(rev <= CUDBG_API_VERSION_REVISION,
                 CUDBG_ERROR_INCOMPATIBLE_API,
                 "Incompatible API version: client revision %d vs. libcuda revision %d\n",
                 rev, CUDBG_API_VERSION_REVISION);

    return CUDBG_SUCCESS;
}

static CUDBGResult
rpcdInitializeAPI(uint32_t major, uint32_t minor, uint32_t rev)
{
    CUDBGResult res;

    RPCD_TRACE_FUNCTION(1, "initialization with version %d.%d.%d\n",
                        major, minor, rev);

    /* Get the proper API */
    res = rpcdGetDebugAPI(major, minor, rev, &cudbgapi);
    if (res != CUDBG_SUCCESS) {
        RPCD_TRACE_FUNCTION(0, "Error acquiring debug API (res = %d)\n", res);
        return res;
    }

    /* Initialize the API */
    res = cudbgapi->initialize();
    RPCD_TRACE_FUNCTION(1, "RPCD:  cudbgapi->initialize():  %d\n", res);
    if (res != CUDBG_SUCCESS && res != CUDBG_ERROR_SOME_DEVICES_WATCHDOGGED) {
        RPCD_TRACE_FUNCTION(0, "Error initializing debug API (res = %d)\n", res);
        return res;
    }

    /* Set up the event call back routine */
    res = cudbgapi->setNotifyNewEventCallback((CUDBGNotifyNewEventCallback)rpcdNotifyDebugClientCallback);
    RPCD_TRACE_FUNCTION(1, "RPCD:  setNotifyNewEventCallback:  %d\n", res);
    if (res != CUDBG_SUCCESS)
        return res;

    return CUDBG_SUCCESS;
}

CUDBGResult
cudbgMain(int apiClientPid, uint32_t apiClientRevision, int sessionId,
          int attachState, int attachEventInitialized, int writeFd, int detachFd,
          int attachStubInUse, int enablePreemptionDebugging)
{
    CUDBGResult res;
    volatile bool terminate = false;
    volatile bool clientFinalized = false;
    uint32_t major, minor, rev;
    /* Build the attach event from writeFd */
#if !cuosOsIsApple()
    // TODO Add a function to cuos that does this as this is not maintainable
    cuosEvent attachEventCopy = { 0 };
    cuosEvent detachEventCopy = { 0 };

    attachEventCopy.createdByCuos = 1;
    attachEventCopy.ipcEvent = 1;
    attachEventCopy.readFd = 0;
    attachEventCopy.writeFd = writeFd;

    detachEventCopy.createdByCuos = 1;
    detachEventCopy.ipcEvent = 1;
    detachEventCopy.readFd = 0;
    detachEventCopy.writeFd = detachFd;
#endif

    /* RPCD expects these to be initialized */
    CUDBG_APICLIENT_PID = apiClientPid;
    CUDBG_APICLIENT_REVISION = apiClientRevision;
    CUDBG_SESSION_ID = sessionId;
    CUDBG_ENABLE_PREEMPTION_DEBUGGING = enablePreemptionDebugging;

    if (attachState == CUDBG_STATE_ATTACHING_VIA_STUB) {
        res = cudbgAttachStubMain(apiClientPid, apiClientRevision, sessionId,
                                  attachState, attachEventInitialized, writeFd, detachFd);
        return res;
    }

    // Explicitly initialize utils (for tracing) as the first
    // part of RPCD, to allow traces to come through (and more
    // importantly to prevent RPCD from crashing).
    cudbgUtilsInit();

    res = rpcdSetup();
    if (res != CUDBG_SUCCESS) {
        RPCD_TRACE_FUNCTION(0, "Error setting up rpcd (res = %d)\n", res);
        return res;
    }

    /* By default, use libcuda's revision. We will check later that the
       client's revision will work when available. */
    major = CUDBG_API_VERSION_MAJOR;
    minor = CUDBG_API_VERSION_MINOR;
    rev   = CUDBG_API_VERSION_REVISION;

    /* Starting with the 4.1 release, the client will write its revision in
       memory for RPCD. Use it if available. */
    if (CUDBG_APICLIENT_REVISION > 0) {
        cudbgapiInitializationResult = rpcdCheckClientVersion(major, minor, CUDBG_APICLIENT_REVISION);
        if (cudbgapiInitializationResult != CUDBG_SUCCESS) {
            RPCD_TRACE_FUNCTION(0, "Error checking the client revision (res = %d)\n", cudbgapiInitializationResult);
            /* Do not tear RPCD down upon a version check failure.  Store the
               error for the client to see (upon actual initialization). */
            /* Notify debug client of a fatal initialization failure immediately.
               This prevents deadlocks with the application, where it will timeout
               waiting for communication mechanisms to start up (in cudbgpipe.c). */
            res = rpcdNotifyDebugClientCallbackInitFailure();
            if (res != CUDBG_SUCCESS) {
                RPCD_TRACE_FUNCTION(0, "Error notifying callback initialization failure!\n");
                return res;
            }
        }
    }

    /* Initialize the API. Must be done now because there is no guarantee that
       the client will have the opportunity to send an initialization request
       before libcuda starts sending messages to the dispatcher. */
    cudbgapiInitializationResult = rpcdInitializeAPI(major, minor, rev);
    if (cudbgapiInitializationResult != CUDBG_SUCCESS) {
        RPCD_TRACE_FUNCTION(0, "Error initializing the API (res = %d)\n",
                            cudbgapiInitializationResult);
        /* Do not tear RPCD down upon a version check failure.  Store the
           error for the client to see (upon actual initialization). */
        /* Notify debug client of a fatal initialization failure immediately.
           This prevents deadlocks with the application, where it will timeout
           waiting for communication mechanisms to start up (in cudbgpipe.c). */
        res = rpcdNotifyDebugClientCallbackInitFailure();
        if (res != CUDBG_SUCCESS) {
            RPCD_TRACE_FUNCTION(0, "Error notifying callback initialization failure!\n");
            return res;
        }
    }

#if !cuosOsIsApple()
    /* If the attach stub is in use, RPCD must not send the attach event */
    if (CUDBG_STATE_ATTACHING_VIA_RPCD == attachState && !attachStubInUse) {
        if (attachEventInitialized) {
            RPCD_TRACE_FUNCTION(1, "Found attach event in the driver\n");
            res = (CUDBGResult)cuosEventSignal(&attachEventCopy);
            if (res != CUDBG_SUCCESS) {
                RPCD_TRACE_FUNCTION(0, "Failed to initiate attach (res = %d)!\n", res);
                return res;
            }
        }
        else
            /* The attach pipe wasn't setup, nothing more to do */
            RPCD_TRACE_FUNCTION(1, "Attach event not found in the driver\n");
    }

    /* Now that RPCD's copy of the debugger event is initialized, fill
       in globals.debuggerDetachEvent */
    globals.debuggerDetachEvent = detachEventCopy;
#endif

    /* Wait for any API requests from the client debugger.
       Only stop when terminate is set to true, or if we
       have hit an error condition (res != CUDBG_SUCCESS). */
    while (!terminate && res == CUDBG_SUCCESS)
        res = rpcdWaitForMessage(&terminate, &clientFinalized);

    RPCD_TRACE_FUNCTION(1, "Returned from rpcdWaitForMessage, res=%d, "
                        "terminate=%d, clientFinalized=%d, attempting teardown\n",
                        res, terminate, clientFinalized);

    res = rpcdTeardown(clientFinalized);
    if (res != CUDBG_SUCCESS) {
        RPCD_TRACE_FUNCTION(0, "Error tearing down rpcd (res = %d)\n", res);
        return res;
    }

    RPCD_TRACE_FUNCTION(1, "terminating gracefully!\n");
    return CUDBG_SUCCESS;
}

#endif
