/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: stub.c
 *
 *   Description:
 *       A stub that is forked off by the CUDA app. It's sole purpose is to
 *       send attach and detach messages to the CUDA app.
 *
 ******************************************************************************/

#include <cuos_platform.h>
#if cuosOsIsLinux() || cuosOsIsQnx() ||cuosOsIsApple()

#include "rpcd.h"
#include "stub.h"
#include <libcudbg_legacy.h>
#include <cudadebugger.h>
#include <cudbgpipe.h>
#include <cudbgapi.h>
#include <stdio.h>

cudbg_pipe_t debugClientToAttachStub;
cudbg_pipe_t attachStubToDebugClient;

cuosEvent detachEvent;

static CUDBGResult
cudbgAttachStubRequestCleanupOnDetach(void)
{
#if !cuosOsIsApple()
    CUresult drvRes;

    /* Signal the driver to run the detach handler whenever it resumes */
    drvRes = (CUresult)cuosEventSignal(&detachEvent);
    if (drvRes != CUDA_SUCCESS) {
        CUDBG_ERROR("Failed to signal detach (res = %d)!\n", drvRes);
        return CUDBG_ERROR_COMMUNICATION_FAILURE;
    }
#endif
    return CUDBG_SUCCESS;
}

static CUDBGResult
cudbgAttachStubPushMessage(void *obj, uint64_t objSize)
{
    CUDBGResult res;

    /* if nothing to push, don't bother */
    if (!obj || !objSize)
        return CUDBG_SUCCESS;

    /* append object to the message to be sent to the debug client */
    if ((res = cudbgPipeMessageAppend(&attachStubToDebugClient, obj, objSize))) {
        CUDBG_ERROR("Failed to append message (res = %d)\n", res);
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
cudbgAttachStubSendMessage(void)
{
    CUDBGResult res;

    /* send the message */
    if ((res = cudbgPipeMessageSend(&attachStubToDebugClient))) {
        CUDBG_ERROR("Failed to send message (res = %d)\n", res);
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
cudbgAttachStubProcessDebugClientMessage(void *msgBuffer, bool *terminate)
{
    CUDBGResult res;
    CUDBGAPIMSG_t *message;

    CUDBG_VERIFY(msgBuffer && terminate,
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments in cudbgAttachStubProcessDebugClientMessage.\n");

    /* Point to the message */
    message = (CUDBGAPIMSG_t *)msgBuffer;

    /* Decode the client's request. */
    switch (message->kind) {
    case CUDBGAPIREQ5x_initialize:
        /* Nothing to do */
        message->result = CUDBG_SUCCESS;
        break;
    case CUDBGAPIREQ5x_requestCleanupOnDetach:
        /* Once this message is received, the stub must shut down */
        *terminate = true;
        message->result = cudbgAttachStubRequestCleanupOnDetach();
        break;
    case CUDBGAPIREQ5x_finalize:
        message->result = CUDBG_SUCCESS;
        *terminate = true;
        break;
    default:
        CUDBG_ERROR("Received unknown message from client debugger (%d)\n", message->kind);
        message->result = CUDBG_ERROR_INVALID_ARGS;
        *terminate = true;
        return CUDBG_ERROR_UNKNOWN;
    }

    /* Send results to debug client */
    res = cudbgAttachStubPushMessage(message, sizeof *message);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Cannot push message (%d). Terminating. \n", res);
        *terminate = true;
        return res;
    }

    res = cudbgAttachStubSendMessage();
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Cannot push send message (%d). Terminating. \n", res);
        *terminate = true;
        return res;
    }

    return res;
}

static CUDBGResult cudbgAttachStubWaitForMessage(bool *terminate)
{
    CUDBGResult res;
    bool retry = false;

    if ((res = cudbgPipeWaitForData(&debugClientToAttachStub, NULL))) {
        CUDBG_ERROR("Failed to wait for data (res = %d)\n", res);
        return res;
    }

    if ((res = cudbgPipeMessageRead(&debugClientToAttachStub, &retry))) {
        CUDBG_ERROR("Failed to read message data (res = %d)\n", res);
        return res;
    }

    if (retry)
        CUDBG_PRINT(10, "cudbgAttachStubWaitForMessage (retry = %d), didn't receive message!\n", retry);

    /* if retry was set, we must return (maintaining all
       state in the debugClientToAttachStub pipe).  We'll
       come back to finish later. */
    if (retry)
        return CUDBG_SUCCESS;

    if ((res = cudbgAttachStubProcessDebugClientMessage(debugClientToAttachStub.message[0], terminate))) {
        CUDBG_ERROR("Error processing debug client message (res = %d)\n", res);
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
cudbgAttachStubPipesSetup(void)
{
    CUDBGResult res;

    /* Initialize incoming pipe */
    res = cudbgPipeInitialize(&debugClientToAttachStub,
                              CUDBG_PIPE_TYPE_NAMED_READ,
                              CUDBG_PIPE_ENDPOINT_DEBUG_CLIENT,
                              CUDBG_PIPE_ENDPOINT_ATTACH_STUB);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Failed to initialize read pipe (res = %d)\n", res);
        return res;
    }

    /* Initialize outgoing pipe */
    res = cudbgPipeInitialize(&attachStubToDebugClient,
                              CUDBG_PIPE_TYPE_NAMED_WRITE,
                              CUDBG_PIPE_ENDPOINT_ATTACH_STUB,
                              CUDBG_PIPE_ENDPOINT_DEBUG_CLIENT);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Failed to initialize write pipe (res = %d)\n", res);
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
cudbgAttachStubPipesFinalize(void)
{
    CUDBGResult res;

    res = cudbgPipeFinalize(&attachStubToDebugClient);
    if (res != CUDBG_SUCCESS)
        return res;

    res = cudbgPipeFinalize(&debugClientToAttachStub);
    if (res != CUDBG_SUCCESS)
        return res;

    return CUDBG_SUCCESS;
}

int stub;

CUDBGResult
cudbgAttachStubMain(int apiClientPid, uint32_t apiClientRevision, int sessionId,
                    int attachState, int attachEventInitialized, int writeFd, int detachFd)
{
    CUDBGResult res;
    bool terminate = false;
    /* Build the attach event from writeFd */
#if !cuosOsIsApple()
    // TODO Add a function to cuos that does this as this is not maintainable
    cuosEvent attachEventCopy = { 0 };
    cuosEvent detachEventCopy = { 0 };

    attachEventCopy.createdByCuos = 1;
    attachEventCopy.ipcEvent = 1;
    attachEventCopy.readFd = 0;
    attachEventCopy.writeFd = writeFd;

    detachEventCopy.createdByCuos = 1;
    detachEventCopy.ipcEvent = 1;
    detachEventCopy.readFd = 0;
    detachEventCopy.writeFd = detachFd;

    detachEvent = detachEventCopy;
#endif

    stub = 1;

    CUDBG_APICLIENT_PID = apiClientPid;
    CUDBG_SESSION_ID = sessionId;

    cudbgUtilsInit();

    res = cudbgAttachStubPipesSetup();
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Error setting up stub (res = %d)\n", res);
        return res;
    }

    if (attachEventInitialized) {
#if !cuosOsIsApple()
        CUDBG_PRINT(3, "Stub signalling attach event in the driver\n");
        res = (CUDBGResult)cuosEventSignal(&attachEventCopy);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to initiate attach (res = %d)!\n", res);
            return res;
        }
#endif
    }
    else
        /* The attach pipe wasn't setup, nothing more to do */
        CUDBG_PRINT(1, "Attach event not found in the driver\n");

    /* Wait for any API requests from the client debugger.
       Only stop when terminate is set to true, or if we
       have hit an error condition (res != CUDBG_SUCCESS). */
    while (!terminate && res == CUDBG_SUCCESS)
        res = cudbgAttachStubWaitForMessage(&terminate);

    cudbgUtilsFinalize();
    cudbgAttachStubPipesFinalize();

    return res;
}

#endif
