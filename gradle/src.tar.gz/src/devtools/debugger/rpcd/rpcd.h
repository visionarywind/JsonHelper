/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: rpcd.h
 *
 *   Description:
 *       Header file for the Debugger RPC Daemon.
 *
 ******************************************************************************/

#include <cuos_platform.h>
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()

#ifndef CUDBG_RPCD_H
#define CUDBG_RPCD_H 1

#include <cudadebugger.h>
#include "cudbgutils.h"
#include "halo_trace.h"
/* Debug Trace */
#define RPCD_TRACE_LEVEL                    haloTraceLevel
#ifndef RELEASE
#define RPCD_TRACE(level, ...)              haloTrace(HALO_TRACE_DOMAIN_RPCD, HALO_TRACE_TYPE_FILE, level, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#define RPCD_TRACE_FUNCTION(level, ...)     haloTrace(HALO_TRACE_DOMAIN_RPCD, (HALO_TRACE_TYPE_FILE | HALO_TRACE_TYPE_FUNCTION), level, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#define RPCD_TRACE_LOCATION(level, ...)     haloTrace(HALO_TRACE_DOMAIN_RPCD, (HALO_TRACE_TYPE_FILE | HALO_TRACE_TYPE_LINE), level, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#define RPCD_ERROR(...)                     haloTrace(HALO_TRACE_DOMAIN_RPCD, HALO_TRACE_TYPE_FILE, 0, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#else
#define RPCD_TRACE(level, ...)              ((void)0)
#define RPCD_TRACE_FUNCTION(level, ...)     ((void)0)
#define RPCD_TRACE_LOCATION(level, ...)     ((void)0)
#define RPCD_TRACE_ELEMENT(level, ...)      ((void)0)
#define RPCD_ERROR(...)                     ((void)0)
#endif

CUDBGResult rpcdNotifyDebugClientCallback(CUDBGEventCallbackData *data);
CUDBGResult rpcdProcessDebugClientMessage50(void *msgBuffer, volatile bool *terminate, volatile bool *clientFinalized);
CUDBGResult rpcdProcessDebugClientMessage55(void *msgBuffer, volatile bool *terminate, volatile bool *clientFinalized);
CUDBGResult rpcdProcessDebugClientMessage(char *msgBuffer, uint64_t msgSize, volatile bool *terminate, volatile bool *clientFinalized);
CUDBGResult rpcdCheckClientVersion(uint32_t major, uint32_t minor, uint32_t rev);
CUDBGResult rpcdGetDebugAPI(uint32_t major, uint32_t minor, uint32_t rev, CUDBGAPI *api);
CUDBGResult rpcdPushMessage(void *obj, uint64_t objSize);
CUDBGResult rpcdSendMessage(void);
CUDBGResult rpcdGetTempBuffer (void **ptr, uint64_t size);

#endif /* CUDBG_RPCD_H */

#endif
