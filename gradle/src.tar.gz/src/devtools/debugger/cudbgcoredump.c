/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include <cuda.h>
#include <cuda_types.h>
#include <cuda_macros.h>
#include <cuimutex.h>

#include <halo.h>
#include <halo_trace.h>
#include <halo_internal.h>
#include <halo_state.h>
#include <cudbgcoredump.h>
#include <cudbgcoredumpelf.h>
#include <cudbgapi.h>
#include <tools_shared_rangemap.h>

#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <cudbgutils.h>

#define DBG_LEVEL 10

#define DEFAULT_COREDUMP_FILE_NAME "core_%t_%h_%p.nvcudmp"
#define DEFAULT_COREDUMP_PIPE_NAME "corepipe_%h_%p"

#define COREDUMP_CACHE_LMEM
#define COREDUMP_CACHE_CILP_BUFFER

typedef enum {
    COREDUMP_STATE_UNINITIALIZED       = 0,
    COREDUMP_STATE_GLOBALS_INITIALIZED = (1 << 0),
    COREDUMP_STATE_CONTEXTS_SIGNALED   = (1 << 1),
    COREDUMP_STATE_HALO_INITIALIZED    = (1 << 2),
    COREDUMP_STATE_COREDUMP_COMPLETE   = (1 << 3),
    COREDUMP_STATE_FINALIZED           = (1 << 4),
} CudbgCoredumpState;

typedef struct {
    volatile bool coredumpEnabled;
    volatile bool userCoredumpEnabled;
    volatile bool cpuCoredumpDisabled;
    /* Lightweight coredumps are regular coredumps without memory (global,
    shared, local) nor non-relocated ELF image dumps. */
    volatile bool lightweightEnabled;
    volatile bool coredumpInProgress;

    volatile FLAG_SET(CudbgCoredumpState) state;

    void *msg;
    uint64_t msgSize;
    bool msgInitialized;

    volatile unsigned int threadSerial;

    cuosBarrier barrier;
    CudbgCoredumpData coredumpData;
} CudbgCoredumpGlobals;

static CudbgCoredumpGlobals coredumpGlobals = {0};
static char stringBuffer[CUDBG_COREDUMP_STRING_BUFFER_SIZE] = {0};
static char coredumpFileName[CUOS_ENV_VAR_LENGTH] = {0};
static char coredumpPipeName[CUOS_ENV_VAR_LENGTH] = {0};

static void
cudbgCoredumpDestroyModuleData(void* entry, void* data);
static void
cudbgCoredumpDestroyContextData(void* entry, void* data);
static void
cudbgCoredumpDestroyBacktraceData(void* entry, void* data);
static void
cudbgCoredumpDestroyThreadData(void* entry, void* data);
static void
cudbgCoredumpDestroyWarpData(void* entry, void* data);
static void
cudbgCoredumpDestroyCtaData(void* entry, void* data);
static void
cudbgCoredumpDestroySmData(void* entry, void* data);
static void
cudbgCoredumpDestroyGridData(void* entry, void* data);
static void
cudbgCoredumpDestroyDeviceData(void* entry, void* data);
static void
cudbgCoredumpDestroyMemoryData(void* entry, void* data);

static CUDBGResult
cudbgCoredumpInitializeCoredumpData(void)
{
    CUDBGResult res = CUDBG_SUCCESS;

    res = cudbgCoredumpCreateStringTable(&coredumpGlobals.coredumpData.stringTable);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to create string table\n");

    coredumpGlobals.coredumpData.deviceDataList = toolsListNew();
    CUDBG_VERIFY(coredumpGlobals.coredumpData.deviceDataList,
                 CUDBG_ERROR_UNKNOWN, "Failed to create deviceDataList\n");

    return CUDBG_SUCCESS;
}

static void cudbgCoredumpExpandFileNameInternal(char *fileName)
{
    uint64_t i, j;
    uint64_t maxLength, fileNameLength, remainingLength;
    bool splChar = false;

    maxLength = sizeof(stringBuffer) - 1;
    fileNameLength = strlen(fileName);

    for (i = 0, j = 0; i < fileNameLength && j < maxLength; i++) {
        if (!splChar && fileName[i] == '%') {
            splChar = true;
            continue;
        }

        /* Remaining space in stringBuffer */
        remainingLength = maxLength - j;

        switch(fileName[i]) {
        case 'p':
            if (splChar) {
                snprintf(stringBuffer + j, (size_t)remainingLength, "%llu",
                         (unsigned long long)cuosProcessId());

                j += strlen(stringBuffer + j);
                break;
            }
        case 'h':
            if (splChar) {
                if (CUOS_SUCCESS != cuosGetHostname(stringBuffer + j,
                                                    (size_t)remainingLength))
                    snprintf(stringBuffer + j, (size_t)remainingLength, "localhost");

                j += strlen(stringBuffer + j);
                break;
            }
        case 't':
            if (splChar) {
// __TEMP_WAR__ no time() on HOS
#if !cuosOsIsHos()
                snprintf(stringBuffer + j, (size_t)remainingLength, "%" PRId64, (uint64_t)time(NULL));
                j += strlen(stringBuffer + j);
#endif
                break;
            }
        default:
            stringBuffer[j++] = fileName[i];
            break;
        }

        splChar = false;
    }

    /* Ensure there's an ending null character */
    stringBuffer[j] = 0;

    strncpy(fileName, stringBuffer, strlen(stringBuffer) + 1);
}

static CUDBGResult
cudbgCoredumpInitializeGlobals(void)
  TS_NO_THREAD_SAFETY_ANALYSIS // conditional lock
{
    CUDBGResult res = CUDBG_SUCCESS;
    int ret;

    if (globals.initialized != CUDA_GLOBALS_INITIALIZED)
        return CUDBG_ERROR_INTERNAL;

    cuosEnterCriticalSection(&globals.debugger_cs);

    /* Check if globals were already initialized */
    if (coredumpGlobals.state & COREDUMP_STATE_GLOBALS_INITIALIZED) {
        cuosLeaveCriticalSection(&globals.debugger_cs);
        return CUDBG_SUCCESS;
    }

    cudbgUtilsInit();

    /* Grab debuggerAttachMutex, to avoid any more contexts from being added
     * to the globals.activeContexts list. This ensures that the number of
     * active contexts will not change while the coredump is being collected,
     * and helps avoiding many corner cases */
    cuiMutexLock(&globals.debuggerAttachMutex);

    coredumpGlobals.coredumpInProgress = true;

    coredumpGlobals.msgInitialized = false;

    cudbgClearErrors();

    CUDBG_PRINT(DBG_LEVEL, "Found %d context(s)\n", globals.activeContextCount);

    ret = cuosBarrierCreate(&coredumpGlobals.barrier,
                            globals.activeContextCount);
    if (ret != CUOS_SUCCESS) {
        res = CUDBG_ERROR_UNKNOWN;
        CUDBG_PRINT(0, "Failed to initialize barrier\n");
        goto done;
    }

    coredumpGlobals.state |= COREDUMP_STATE_GLOBALS_INITIALIZED;

    coredumpGlobals.threadSerial = 0;

    res = cudbgCoredumpInitializeCoredumpData();
    if (res != CUDBG_SUCCESS) {
        CUDBG_PRINT(0, "Failed to initialize coredump data\n");
        goto done;
    }

done:
    cuosLeaveCriticalSection(&globals.debugger_cs);

    return res;
}

static CUDBGResult
cudbgCoredumpCollectContextState(CUctx *ctx)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CUmod *mod = NULL;
    CudbgDevice dev;

    cuosEnterCriticalSection(&globals.debugger_cs);

    dev = haloGlobals.device[ctx->device->state.deviceIdx];
    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_DEVICE, "Unknown device!\n");

    /* Don't collect any data from watchdogged devices. */
    if (dev->status == CUDBG_ERROR_SOME_DEVICES_WATCHDOGGED)
        goto done;

    /* Context is in the process of dying. Dont bother
       telling the backend about it */
    if (ctx->forbidEnumeration == NV_TRUE) {
        CUDBG_PRINT(DBG_LEVEL, "Coredump: context being finalized. Skipping\n");
        goto done;
    }

    /* Check if we support coredumps on this GPU */
    if (ctx->device->state.arch < NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100) {
        CUDBG_PRINT(DBG_LEVEL, "Coredump: Unsupported GPU found, exiting!\n");
        goto done;
    }

    /* Before we send any state to the HALO, we need to initialize some static
     * state in cudbgapi.c */
    gpudbgInitializeStaticState();

    CUDBG_PRINT(DBG_LEVEL, "Coredump: Registering ctxId %d\n", ctx->ctxId);
    /* Ignore the sessionId since we're not really concerned with toolsAPI callbacks */
    cudbgReportCtxCreate(ctx, false, 0);
    res = cudbgGetLastError();
    if (res != CUDBG_SUCCESS)
        goto done;

    cuiMutexLock(&ctx->moduleMutex);

    for (mod = ctx->modules; mod != NULL; mod = mod->next) {
        CUDBG_PRINT(DBG_LEVEL, "Coredump: Registering module\n");
        cudbgReportModuleLoad(ctx, mod, &mod, "Unknown", (char *)mod->elf_image);
        res = cudbgGetLastError();
        if (res != CUDBG_SUCCESS)
            break;
    }

    cuiMutexUnlock(&ctx->moduleMutex);

done:
    cuosLeaveCriticalSection(&globals.debugger_cs);

    return res;
}

/* Send a wakeup call to all known contexts */
static CUDBGResult
cudbgCoredumpSignalAllContexts(CUctx *self)
{
    CUctx *ctx = NULL;
    CUDBGResult res = CUDBG_SUCCESS;
    int ret;

    cuosEnterCriticalSection(&globals.debugger_cs);

    /* Check if another context already did the signaling. The other context
     * would have signaled every context other than itself. */
    if (coredumpGlobals.state & COREDUMP_STATE_CONTEXTS_SIGNALED)
        goto done;

    for (ctx = globals.activeContexts; ctx != NULL; ctx = ctx->next) {
        if (ctx != self) {
            ret = cuosEventSignal(cuiTrapHandlerGetCoredumpEvent(ctx));
            if (ret != CUOS_SUCCESS) {
                res = CUDBG_ERROR_UNKNOWN;
                CUDBG_PRINT(0, "Failed to signal event (ret=%d)\n", ret);
                goto done;
            }
        }
    }

    coredumpGlobals.state |= COREDUMP_STATE_CONTEXTS_SIGNALED;

done:
    cuosLeaveCriticalSection(&globals.debugger_cs);

    return res;
}

/************** Functions that talk to the HALO **************/

static CUDBGResult
cudbgCoredumpInitializeHalo(CUctx *ctx)
{
    struct HaloInitData_st haloInitData;
    CUDBGResult res = CUDBG_SUCCESS;

    cuosEnterCriticalSection(&globals.debugger_cs);

    /* The debugger client does not like being initialized multiple times. */
    if (coredumpGlobals.state & COREDUMP_STATE_HALO_INITIALIZED)
        goto done;

    CUDBG_PRINT(DBG_LEVEL, "Coredump: Initializing HALO as a debugger client\n");

    res = gpudbgSetupHaloInitDataFlags(&haloInitData);
    if (res != CUDBG_SUCCESS)
        goto done;

    haloInitData.flags |= HALO_INIT_FLAGS_IN_PROCESS;

    res = haloInit(&haloInitData);
    if (res == CUDBG_SUCCESS || res == CUDBG_ERROR_SOME_DEVICES_WATCHDOGGED)
        coredumpGlobals.state |= COREDUMP_STATE_HALO_INITIALIZED;

done:
    cuosLeaveCriticalSection(&globals.debugger_cs);

    return res;
}

/* VOLTA: need syscallStackSize for checking syscall stack pointer */
static CUDBGResult
ctxGetSystemStackSize(Context ctx, void *data)
{
    CUctx *cuCtx = NULL;

    CUDBG_VERIFY(ctx, CUDBG_ERROR_UNKNOWN, "Invalid arguments\n");

    cuCtx = (CUctx*)(uintptr_t)ctx->cuCtx;
    CUDBG_VERIFY(cuCtx, CUDBG_ERROR_UNKNOWN,
                 "Failed to get context from ctx->cuCtx\n");

    ctx->syscallStackSz = cuCtx->systemStackSize;

    return CUDBG_SUCCESS;
}

static CUDBGResult
cudbgCoredumpSuspendDeviceAndCollectState(int devId)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CudbgDevice dev = haloGlobals.device[devId];
    uint32_t hasStopped = 0;
    uint32_t waitForEvent = 0;
    Context residentContext = NULL;

    /* HALO isn't thread safe, so we need to serialize this call. */
    cuosEnterCriticalSection(&globals.debugger_cs);

    /* Don't touch watchdogged devices. */
    if (dev->status == CUDBG_ERROR_SOME_DEVICES_WATCHDOGGED)
        goto done;

    /* Check if another context already suspended this device. */
    if (dev->suspended)
        goto done;

    /* Suspend GPU and collect state */
    res = dev->halo.suspendDevice(dev, &hasStopped, &waitForEvent, &residentContext);
    if (hasStopped && (res == CUDBG_SUCCESS ||
                res == CUDBG_ERROR_INVALID_CONTEXT)) {
        dev->suspended = true;
        dev->expectingGpuEvent = false;
    }

    if (res == CUDBG_ERROR_INVALID_CONTEXT) {
        /* This could happen if we tried to stop when there was no
         * debug object created, or if we stopped after the app has
         * freed its handles. For coredumps, this is relevant when
         * a coredump is triggered on-demand from the debugger. */
        res = dev->halo.clearSMState(dev);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to clearSMState failed\n");
            goto done;
        }
    }
    else if (res != CUDBG_SUCCESS || !dev->suspended) {
        res = CUDBG_ERROR_INTERNAL;
        CUDBG_ERROR("Device not suspended correctly\n");
        goto done;
    }

    res = haloStateTraverseContexts(ctxGetSystemStackSize, NULL);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to haloStateTraverseContexts failed\n");
        goto done;
    }

    res = dev->halo.collectDeviceState(dev, false, NULL);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to collectDeviceState failed\n");
        goto done;
    }

done:
    cuosLeaveCriticalSection(&globals.debugger_cs);

    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to suspend device via HALO\n");

    return res;
}

static CUDBGResult
cudbgCoredumpAddSegmentsToMemoryDataMap(Context context,
                                        CudbgCoredumpData *coredumpData,
                                        tRangeMap *devPtrMap)
{
    CudbgCoredumpMemoryData *memData;
    tRangeMapItr *segItr;
    haloMemorySegment *seg;
    CUDBGResult res = CUDBG_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;
    CudbgDevice dev;

    segItr = toolsRangeMapGetIterator(devPtrMap);

    while (segItr != NULL) {
        seg = (haloMemorySegment *)toolsRangeMapGetEntry(segItr);
        CUDBG_VERIFY(seg, CUDBG_ERROR_UNKNOWN,
                     "Failed to get seg from devPtrMap\n");

        /* If no context is specified, get the dev and context from the seg */
        if (context != NULL)
            dev = context->dev;
        else {
            dev = haloGlobals.device[seg->sourceDeviceIdx];

            context = (Context)toolsHashMapGetAnyEntry(dev->contexts);
            CUDBG_VERIFY(context, CUDBG_ERROR_UNKNOWN,
                    "Failed to read seg from globalMemMap\n");
        }

        segItr = toolsRangeMapGetNext(devPtrMap, segItr);

        if ((seg->apiSource == CU_MEM_API_NOT_VISIBLE && !seg->userOwnsData)
            || seg->uvavaddr == 0)
            continue;

        /* If this seg was already found in another context, skip it */
        if (toolsRangeMapLookupByRange(coredumpData->memoryDataMap, seg->devptr,
                                       seg->size) != NULL)
            continue;

        memData = (CudbgCoredumpMemoryData *)calloc(1, sizeof(CudbgCoredumpMemoryData));
        CUDBG_VERIFY(memData, CUDBG_ERROR_OS_RESOURCES,
                     "Failed to allocate memory\n");

        if (haloMemorySegmentGetBlockType(seg) == CU_MEM_TYPE_MANAGED)
            memData->isManagedMem = true;
        else
            memData->isManagedMem = false;

        memData->memDump = (char *)malloc((size_t)seg->size);
        if (!memData->memDump) {
            CUDBG_ERROR("Failed to allocate memory\n");
            res = CUDBG_ERROR_OS_RESOURCES;
            goto memData_error;
        }

        if (seg->hostvaddr) {
            memcpy(memData->memDump, (void*)(uintptr_t)seg->hostvaddr, (size_t)seg->size);
        }
        else {
            res = dev->halo.readDeviceMemory(context, seg->devvaddr,
                    memData->memDump, (uint32_t)seg->size);

            if (res == CUDBG_ERROR_ADDRESS_NOT_IN_DEVICE_MEM) {
                /* Copy the memory directly from the host */
                memcpy(memData->memDump, (void*)(uintptr_t)seg->hostvaddr, (size_t)seg->size);
            }
            else if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Failed to read device memory\n");
                goto memData_error;
            }
        }

        tres = toolsRangeMapInsertByRange(coredumpData->memoryDataMap, seg->devptr,
                                          seg->size, (void*)memData);
        if (tres != TOOLS_SUCCESS) {
            res = CUDBG_ERROR_UNKNOWN;
            CUDBG_ERROR("Failed to insert memData into coredumpData->memoryDataMap (tres=%u)\n", tres);
            goto memData_error;
        }
    }

    return CUDBG_SUCCESS;
memData_error:
    if (memData) {
        free(memData->memDump);
        free(memData);
    }
    return res;
}

static CUDBGResult
cudbgCoredumpBuildModuleData(Context context, CudbgCoredumpCtxData *ctxData)
{
    CUDBGResult res = CUDBG_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;
    tHashMapItr *modItr = toolsHashMapGetIterator(context->modules);
    DeviceModule module = NULL;
    CudbgCoredumpModuleData* modData = NULL;

    /* Build the module data */
    while (modItr != NULL) {
        module = (DeviceModule)toolsHashMapGetEntry(modItr);
        CUDBG_VERIFY(module, CUDBG_ERROR_UNKNOWN,
                     "Failed to get module from context->modules\n");

        modItr = toolsHashMapGetNext(context->modules, modItr);

        if (!module->exported)
            continue;

        modData = (CudbgCoredumpModuleData *)calloc(1, sizeof(CudbgCoredumpModuleData));
        CUDBG_VERIFY(modData, CUDBG_ERROR_OS_RESOURCES,
                     "Failed to allocate memory\n");

        modData->elfImageSize = module->elfImageSize;
        modData->relocatedElfImage = module->relocatedElfImage;

        /* Ignore non-relocated for lightweight corefiles */
        if (!cudbgIsCoredumpLightweightEnabled())
            modData->elfImage = module->nonRelocatedElfImage;
        else
            modData->elfImage = NULL;

        modData->moduleTableEntry.moduleHandle = module->cuModule;

        CUDBG_PRINT(DBG_LEVEL, "Recorded ctx 0x%llx, module 0x%llx, size 0x%llx, "
                    "elf 0x%llx, relf 0x%llx\n",
                    context->cuCtx, module->cuModule, module->elfImageSize,
                    module->nonRelocatedElfImage, module->relocatedElfImage);

        tres = toolsListAppend(ctxData->moduleList, modData);
        if (tres != TOOLS_SUCCESS)
        {
            CUDBG_ERROR("Failed to insert moduleData into ctxData->moduleList (tres=%u)\n", tres);
            cudbgCoredumpDestroyModuleData(modData, &res);
            return CUDBG_ERROR_UNKNOWN;
        }
    }

    return res;
}

static CUDBGResult
cudbgCoredumpBuildContextData(uint32_t devId, CudbgCoredumpDeviceData *deviceData)
{
    CUDBGResult res = CUDBG_SUCCESS, res2 = CUDBG_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;
    CudbgDevice dev = haloGlobals.device[devId];
    CudbgCoredumpCtxData *ctxData;
    CudbgCoredumpData *coredumpData = &coredumpGlobals.coredumpData;
    Context context;
    tHashMapItr *ctxItr;
    tRangeMap *devPtrMap;
    uint64_t sharedWindowBase;
    uint64_t localWindowBase;
    uint64_t globalWindowBase;

    ctxItr = toolsHashMapGetIterator(dev->contexts);

    while (ctxItr != NULL) {
        context = (Context)toolsHashMapGetEntry(ctxItr);
        CUDBG_VERIFY(context, CUDBG_ERROR_UNKNOWN,
                     "Failed to get context from dev->contexts\n");

        ctxItr = toolsHashMapGetNext(dev->contexts, ctxItr);

        res = dev->halo.getGTASWindowAddresses(context, &sharedWindowBase, NULL,
                                               &localWindowBase, NULL, &globalWindowBase);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to get GTAS window addresses (res = %d)!\n", res);

        ctxData = (CudbgCoredumpCtxData *)calloc(1, sizeof(CudbgCoredumpCtxData));
        CUDBG_VERIFY(ctxData, CUDBG_ERROR_OS_RESOURCES,
                     "Failed to allocate memory\n");

        ctxData->contextTableEntry.contextId = context->cuCtx;
        ctxData->contextTableEntry.deviceIdx = context->dev->deviceIdx;
        ctxData->contextTableEntry.tid = context->hostThreadId;
        ctxData->contextTableEntry.sharedWindowBase = sharedWindowBase;
        ctxData->contextTableEntry.localWindowBase = localWindowBase;
        ctxData->contextTableEntry.globalWindowBase = globalWindowBase;

        /* Build the moduleList and populate it */
        ctxData->moduleList = toolsListNew();
        if (!ctxData->moduleList) {
            CUDBG_ERROR("Failed to create moduleList\n");
            res = CUDBG_ERROR_UNKNOWN;
            goto ctxData_error;
        }

        /* Build the module data */
        res = cudbgCoredumpBuildModuleData(context, ctxData);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to build context module data!\n");
            goto ctxData_error;
        }

        tres = toolsListAppend(deviceData->ctxList, ctxData);
        if (tres != TOOLS_SUCCESS) {
            CUDBG_ERROR("Failed to insert ctxData into deviceData->ctxList (tres=%u)\n", tres);
            res = CUDBG_ERROR_UNKNOWN;
            goto ctxData_error;
        }

        /* Skip memory dump for lightweight corefiles */
        if (cudbgIsCoredumpLightweightEnabled())
            continue;

        /* Add all dptr-mapped memblocks into the global memoryDataMap */
        res = haloMemoryMapGetDptrRangeMap(context->memMap, &devPtrMap);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get devPtrMap\n");

        res = cudbgCoredumpAddSegmentsToMemoryDataMap(context, coredumpData, devPtrMap);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed add segments to memoryDataMap\n");
    }

    /* Skip memory dump for lightweight corefiles */
    if (!cudbgIsCoredumpLightweightEnabled()) {
        /* Add all dptr-mapped memblocks from the globalMemMap into the global
         * memoryDataMap. These memblocks are not associated with any context. */
        res = haloMemoryMapGetDptrRangeMap(haloStateGetGlobalMemMap(), &devPtrMap);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get devPtrMap\n");

        res = cudbgCoredumpAddSegmentsToMemoryDataMap(NULL, coredumpData, devPtrMap);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed add segments to memoryDataMap\n");
    }

    return res;
ctxData_error:
    if (ctxData)
        cudbgCoredumpDestroyContextData(ctxData, &res2);
    return res;
}

static CUDBGResult
cudbgCoredumpBuildGridData(uint32_t devId, tHashMap *gridDataMap)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CudbgDevice dev = haloGlobals.device[devId];
    CudbgCoredumpGridData *gridData;
    Grid grid;
    Grid parentGrid;
    tHashMapItr *itr;
    CUDBGGridStatus gridStatus;
    CUfunc *func;
    TOOLSresult tres = TOOLS_SUCCESS;
    uint64_t paramsOffset;
    uint64_t paramsSize;
    tList *tmpList = toolsHashMapToList(dev->gridIdToGrid);
    tListItr *tmpItr = toolsListGetIterator(tmpList);

    // Before collecting data, enumerate all grids in dev->gridIdToGrid
    while (tmpItr != NULL) {
        grid = (Grid)toolsListGetElem(tmpItr);
        // Iterate through the parent chain, finding the next parent.
        // CPU-origin kernels don't have parents, so stop when we get there.
        while(grid->origin != CUDBG_KNL_ORIGIN_CPU) {
            res = dev->halo.findParentGrid(dev, grid, &parentGrid);  // Inserts into dev->gridIdToGrid
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Failed to get parent grid info for gridId %" PRId64 " (res = %d)!\n",
                            grid->gridId64, res);
                toolsListDelete(tmpList, NULL, 0);
                return res;
            }
            grid = parentGrid;
        }
        tmpItr = toolsListGetNext(tmpItr);
    }

    toolsListDelete(tmpList, NULL, 0);

    for (itr = toolsHashMapGetIterator(dev->gridIdToGrid);
         itr != NULL;
         itr = toolsHashMapGetNext(dev->gridIdToGrid, itr)) {
        grid = (Grid)toolsHashMapGetEntry(itr);
        CUDBG_VERIFY(grid, CUDBG_ERROR_UNKNOWN,
                     "Failed to get grid from dev->gridIdToGrid\n");

        /* Skip grids with no userEntryFunction (grid is exiting
           and not postable) */
        if (!grid->userEntryFunction)
            continue;
        
        func = (CUfunc*)(uintptr_t)grid->userEntryFunction->cuFunction;

        res = cudbgGetUserParamMemoryOffsets(func, &paramsOffset, &paramsSize);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to get user param memory offsets (res = %d)!\n", res);

        res = dev->halo.getGridStatus(dev, grid->gridId64, &gridStatus);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to get grid status for gridId %" PRId64 " (res = %d)!\n",
                     grid->gridId64, res);

        gridData = (CudbgCoredumpGridData *)calloc(1, sizeof(CudbgCoredumpGridData));
        CUDBG_VERIFY(gridData, CUDBG_ERROR_OS_RESOURCES,
                     "Failed to allocate memory\n");

        gridData->gridTableEntry.gridId64 = grid->gridId64;
        gridData->gridTableEntry.contextId = grid->function->module->context->cuCtx;
        gridData->gridTableEntry.function = grid->userEntryFunction->cuFunction;
        gridData->gridTableEntry.functionEntry = grid->userEntryFunction->virtAddrBase;
        gridData->gridTableEntry.moduleHandle = grid->userEntryFunction->module->cuModule;
        gridData->gridTableEntry.gridDimX = grid->gridDim.x;
        gridData->gridTableEntry.gridDimY = grid->gridDim.y;
        gridData->gridTableEntry.gridDimZ = grid->gridDim.z;
        gridData->gridTableEntry.blockDimX = grid->blockDim.x;
        gridData->gridTableEntry.blockDimY = grid->blockDim.y;
        gridData->gridTableEntry.blockDimZ = grid->blockDim.z;
        gridData->gridTableEntry.kernelType =
            grid->userEntryFunction->module->internal ?
            CUDBG_KNL_TYPE_SYSTEM :
            CUDBG_KNL_TYPE_APPLICATION;
        gridData->gridTableEntry.origin = grid->origin;
        gridData->gridTableEntry.paramsOffset = paramsOffset;
        gridData->gridTableEntry.attrLaunchBlocking =
            grid->function->module->context->launchBlocking;
        gridData->gridTableEntry.attrHostTid =
            grid->function->module->context->hostThreadId;

        gridData->paramsSize = paramsSize;

        /* This will be filled during warpData collection */
        gridData->paramsDump = NULL;

        /* Parent grid indices are all enumerated thanks to code above */
        gridData->gridTableEntry.parentGridId64 = grid->parentGridId64;

        gridData->gridTableEntry.gridStatus = gridStatus;

        gridData->gridTableEntry.numRegs = func->finalRegcount;

        /* gridData->gridTableEntry.validWarpsTableIdx is unused outside of MPS */

        tres = toolsHashMapInsert(gridDataMap, tHashMapNumToKey(grid->gridId64),
                                  (void*)gridData);
        if (tres != TOOLS_SUCCESS) {
            CUDBG_ERROR("Failed to insert CudbgGridTableEntry into gridDataMap (tres=%u)\n", tres);
            cudbgCoredumpDestroyGridData(gridData, &res);
            return CUDBG_ERROR_UNKNOWN;
        }
    }

    return res;
}

static CUDBGResult
cudbgCoredumpBuildBacktraceData(uint32_t devId, uint32_t vsm, uint32_t wp,
                                uint32_t ln, CudbgCoredumpThreadData* threadData)
{
    CUDBGResult res = CUDBG_SUCCESS, res2 = CUDBG_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;
    CudbgBacktraceTableEntry *bt = NULL;
    uint32_t level;
    CudbgDevice dev;
    Context ctx;
    DeviceFunction function;
    bool patchDebug = false;
    uint64_t ra = 0;

    dev = haloGlobals.device[devId];
    ctx = dev->activeContext;

    for (level = 0; level < threadData->threadTableEntry.callDepth; level++) {
        bt = (CudbgBacktraceTableEntry *)calloc(1, sizeof(CudbgBacktraceTableEntry));
        CUDBG_VERIFY(bt, CUDBG_ERROR_OS_RESOURCES, "Failed to allocate memory\n");

        bt->level = level;

        res = gpudbgReadReturnAddressInternal(devId, vsm, wp, ln, level, &ra,
                                              &patchDebug);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to read returnAddress for sm %d, wp %d, ln %d, level %d\n",
                        vsm, wp, ln, level);
            goto bt_error;
        }

#ifndef RELEASE
    if (patchDebug) {
        CUDBG_TRACE("Patch debugging enabled. Not hiding patch return address\n");
        bt->returnAddress = ra;
        bt->virtualReturnAddress = ra;
    }
    else
#endif
    {
        function = (DeviceFunction)toolsRangeMapLookupByAddr(ctx->gpuAddrToFunction,
                                                             ra);
        CUDBG_VERIFY(function, CUDBG_ERROR_UNKNOWN_FUNCTION,
                     "Unknown function.\n");

        /*  Make this address 0-based (subtract the function start offset) */
        bt->returnAddress = ra - function->gpuAddrBase;

        bt->virtualReturnAddress = bt->returnAddress + function->virtAddrBase;
    }

        tres = toolsListAppend(threadData->backtrace, bt);
        if (tres != TOOLS_SUCCESS) {
            CUDBG_ERROR("Failed to insert backtrace into threadData->backtrace (tres=%u)\n", tres);
            res = CUDBG_ERROR_UNKNOWN;
            goto bt_error;
        }
    }
    return res;
bt_error:
    cudbgCoredumpDestroyBacktraceData(bt, &res2);
    return res;
}

static CUDBGResult
cudbgCoredumpBuildThreadData(uint32_t devId, uint32_t vsm, uint32_t wp,
                             CudbgCoredumpWarpData *warpData)
{
    CUDBGResult res = CUDBG_SUCCESS, res2 = CUDBG_SUCCESS;
    CudbgDevice dev = haloGlobals.device[devId];
    uint32_t ln;
    uint32_t callDepth;
    TOOLSresult tres = TOOLS_SUCCESS;
    CudbgCoredumpThreadData *threadData;
    uint32_t ccRegister;

#ifdef COREDUMP_CACHE_LMEM
    uint64_t lmemBase = 0;
    uint64_t lmemSize = 0;

    if (haloStateSwCacheEnabled() && dev->activeContext && dev->activeContext->memMap) {
        if (!cudbgIsCoredumpLightweightEnabled()) {

            /* Determine the lmem base */
            if (dev->smState[vsm].warp[wp].lmemSegType == HALO_MEM_SEG_LOCAL_DEFAULT) {
                CUDBG_PRINT(DBG_LEVEL, "Coredump: defaultLmemDevVA\n");
                lmemBase = dev->activeContext->defaultLmemDevVA + warpData->lmemHiOffset;
                lmemSize = warpData->lmemHiSizePerLane * dev->halo.deviceInfo.numLanesPrWarp;
            }
            else {
                CUDBG_PRINT(DBG_LEVEL, "Coredump: per-warp lmemSeg\n");
                lmemBase = dev->smState[vsm].warp[wp].lmemSeg->devvaddr + warpData->lmemHiOffset;
                lmemSize = warpData->lmemHiSizePerLane * dev->halo.deviceInfo.numLanesPrWarp;
            }

            CUDBG_PRINT(DBG_LEVEL, "Coredump: cache dev%d/sm%d/wp%d lmemBase=0x%" PRIx64 " lmemSize=0x%" PRIx64 "\n",
                        devId, vsm, wp, lmemBase, lmemSize);

            /* Pre-load the cache with the local memory of all lanes in the warp */
            res = haloMemoryRangeCacheOp(dev->activeContext->memMap,
                                         lmemBase,
                                         lmemSize,
                                         HALO_MEM_SEG_CACHE_ENABLE);
            if (res != CUDBG_SUCCESS) {
                CUDBG_PRINT(DBG_LEVEL, "Coredump: Failed to cache local memory for dev%d/sm%d/wp%d\n", devId, vsm, wp);
            }
        }
    }
#endif

    for (ln = 0; ln < dev->halo.deviceInfo.numLanesPrWarp; ln++) {
        /* Skip invalid lanes */
        if (((1 << ln) & warpData->warpTableEntry.validLanesMask) == 0)
            continue;

        threadData = (CudbgCoredumpThreadData *)calloc(1, sizeof(CudbgCoredumpThreadData));
        CUDBG_VERIFY(threadData, CUDBG_ERROR_OS_RESOURCES,
                     "Failed to allocate memory\n");

        threadData->threadTableEntry.ln = ln;

        res = gpudbgReadVirtualPCInternal(devId, vsm, wp, ln,
                                          &threadData->threadTableEntry.virtualPC);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to read virtualPC for sm %d, wp %d, ln %d\n",
                        vsm, wp, ln);
            goto threadData_error;
        }

        res = gpudbgReadPCInternal(devId, vsm, wp, ln,
                                          &threadData->threadTableEntry.physPC);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to read physPC for sm %d, wp %d, ln %d\n",
                        vsm, wp, ln);
            goto threadData_error;
        }

        threadData->threadTableEntry.threadIdxX =
            dev->smState[vsm].warp[wp].threadIdx[ln].x;
        threadData->threadTableEntry.threadIdxY =
            dev->smState[vsm].warp[wp].threadIdx[ln].y;
        threadData->threadTableEntry.threadIdxZ =
            dev->smState[vsm].warp[wp].threadIdx[ln].z;

        /* Read predicates */
        threadData->predicates = (uint32_t *)calloc(1, dev->halo.deviceInfo.numPredicatesPrLane * sizeof(uint32_t));

        if (!threadData->predicates) {
            CUDBG_ERROR("Failed to allocate memory\n");
            res = CUDBG_ERROR_OS_RESOURCES;
            goto threadData_error;
        }

        res = gpudbgReadPredicatesInternal(devId, vsm, wp, ln,
                                           dev->halo.deviceInfo.numPredicatesPrLane, threadData->predicates);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to read predicate registers for sm %d, wp %d, ln %d\n",
                        vsm, wp, ln);
            goto threadData_error;
        }

        /* Read CCs */
        res = gpudbgReadCCRegisterInternal(devId, vsm, wp, ln, &ccRegister);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to read CC register for sm %d, wp %d, ln %d\n",
                        vsm, wp, ln);
            goto threadData_error;
        }

        threadData->threadTableEntry.ccRegister = ccRegister;
        threadData->predicatesDumpSize = dev->halo.deviceInfo.numPredicatesPrLane * sizeof(uint32_t);

        if (!cudbgIsCoredumpLightweightEnabled()) {
            /* Copy local memory into a section */
            threadData->lmemHi = (char *)calloc(1, warpData->lmemHiSizePerLane);
            if (!threadData->lmemHi) {
                CUDBG_ERROR("Failed to allocate memory\n");
                res = CUDBG_ERROR_OS_RESOURCES;
                goto threadData_error;
            }

            res = dev->halo.readLocalMemory(dev, vsm, wp, ln, warpData->lmemHiOffset,
                                            threadData->lmemHi, warpData->lmemHiSizePerLane);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Failed to read lmemHi for sm %d, wp %d, ln %d\n",
                            vsm, wp, ln);
                goto threadData_error;
            }
        }
        else {
            threadData->lmemHi = NULL;
        }

        threadData->threadTableEntry.exception =
            dev->smState[vsm].warp[wp].laneExceptions[ln];

        /* Copy registers into a section */
        threadData->regDump = (char *)calloc(1, warpData->numRegsPerLane * sizeof(uint32_t));
        if (!threadData->regDump) {
            CUDBG_ERROR("Failed to allocate memory\n");
            res = CUDBG_ERROR_OS_RESOURCES;
            goto threadData_error;
        }


        res = gpudbgReadRegisterRangeInternal(devId, vsm, wp, ln, 0,
                                              (uint32_t *)(threadData->regDump), warpData->numRegsPerLane);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Error when reading registers on sm %d, wp %d, ln %d\n",
                        vsm, wp, ln);
            goto threadData_error;
        }

        res = dev->halo.readSyscallCallDepth(dev, vsm, wp, ln, &callDepth);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to read syscall calldepth for sm %d, wp %d, ln %d\n",
                        vsm, wp, ln);
            goto threadData_error;
        }

        threadData->threadTableEntry.syscallCallDepth = callDepth;

        res = gpudbgReadCallDepthInternal(devId, vsm, wp, ln, &callDepth);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to read calldepth for sm %d, wp %d, ln %d\n",
                        vsm, wp, ln);
            goto threadData_error;
        }

        threadData->threadTableEntry.callDepth = callDepth;

        /* Build a list of backtrace frames. */
        threadData->backtrace = toolsListNew();
        if (!threadData->backtrace) {
            CUDBG_ERROR("Failed to create backtrace list\n");
            goto threadData_error;
        }

        res = cudbgCoredumpBuildBacktraceData(devId, vsm, wp, ln, threadData);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to build backtrace data for dev%d/vsm%d/wp%d/ln%d\n", devId, vsm, wp, ln);
            goto threadData_error;
        }

        tres = toolsListAppend(warpData->threadDataList, threadData);
        if (tres != TOOLS_SUCCESS) {
            CUDBG_ERROR("Failed to insert threadData into warpData->threadDataList (tres=%u)\n", tres);
            res = CUDBG_ERROR_UNKNOWN;
            goto threadData_error;
        }
    }

    return res;

threadData_error:
    if (threadData)
        cudbgCoredumpDestroyThreadData(threadData, &res2);
    return res;
}

static CUDBGResult
cudbgCoredumpBuildWarpData(uint32_t devId, uint32_t vsm, uint32_t wp,
                           CudbgCoredumpDeviceData *deviceData, CudbgCoredumpCTAData *ctaData)
{
    CUDBGResult res = CUDBG_SUCCESS, res2 = CUDBG_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;
    CudbgDevice dev = haloGlobals.device[devId];
    CudbgWarp_t *warp = &dev->smState[vsm].warp[wp];
    bool errorPCValid = false;
    CudbgCoredumpGridData *gridData;
    CudbgCoredumpWarpData *warpData;
    HaloLmemConfig_t *warpLmem;
    uint64_t errorPC;

    CUDBG_VERIFY(warp->valid, CUDBG_ERROR_INVALID_ARGS, "cudbgCoredumpBuildWarpData called on invalid warp!\n");

    /* Get gridData for this warp */
    gridData = (CudbgCoredumpGridData *)toolsHashMapFind(deviceData->gridDataMap,
                                                         tHashMapNumToKey(warp->gridId64));
    CUDBG_VERIFY(gridData, CUDBG_ERROR_INVALID_GRID,
                 "Could not find gridData for gridId %llu\n", warp->gridId64);

    res = gpudbgReadErrorPCInternal(devId, vsm, wp, &errorPC, &errorPCValid);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to read errorPC sm %d, wp %d\n", vsm, wp);

    warpData = (CudbgCoredumpWarpData *)calloc(1, sizeof(CudbgCoredumpWarpData));
    CUDBG_VERIFY(warpData, CUDBG_ERROR_OS_RESOURCES,
                 "Failed to allocate memory\n");

    warpData->warpTableEntry.warpId = wp;
    warpData->warpTableEntry.validLanesMask = warp->validLanes;
    warpData->warpTableEntry.activeLanesMask = warp->activeMask;
    warpData->warpTableEntry.isWarpBroken = (uint32_t)warpBitmaskGetBits(&dev->smState[vsm].state.brokenwarps, wp, 1);

    /* Get warpLmem parameters */
    warpLmem = &dev->smState[vsm].warp[wp].lmemConfig;
    warpData->lmemHiSizePerLane = (warpLmem->windowSize - warpLmem->lmemHiOff);
    warpData->lmemHiOffset = warpLmem->lmemHiOff;

    warpData->warpTableEntry.errorPCValid = errorPCValid ? 1: 0;
    if (errorPCValid)
        warpData->warpTableEntry.errorPC = errorPC;

    /* Uniform register file and predicates (optional) */
    if (dev->halo.deviceInfo.numUniformRegsPrWarp > 0) {
        warpData->uniformRegDumpSize = dev->halo.deviceInfo.numUniformRegsPrWarp * sizeof(uint32_t);
        warpData->uniformRegDump = (uint32_t *)calloc(1, (size_t)warpData->uniformRegDumpSize);
        if (warpData->uniformRegDump == NULL) {
            CUDBG_ERROR("Failed to allocate uniform register memory\n");
            res = CUDBG_ERROR_OS_RESOURCES;
            goto warpData_error;
        }

        res = dev->halo.readUniformRegisterFile(dev, vsm, wp, 0,
                                                warpData->uniformRegDump,
                                                (uint32_t)warpData->uniformRegDumpSize);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to read uniform register file (res = %d)\n", res);
            goto warpData_error;
        }
    }

    if (dev->halo.deviceInfo.numUniformPredicatesPrWarp > 0) {
        warpData->uniformPredicatesDumpSize = dev->halo.deviceInfo.numUniformPredicatesPrWarp * sizeof(uint32_t);
        warpData->uniformPredicatesDump = (uint32_t *)calloc(1, (size_t)warpData->uniformPredicatesDumpSize);
        if (warpData->uniformPredicatesDump == NULL) {
            CUDBG_ERROR("Failed to allocate uniform predicate memory\n");
            res = CUDBG_ERROR_OS_RESOURCES;
            goto warpData_error;
        }

        res = dev->halo.readUniformPredicates(dev, vsm, wp,
                                              dev->halo.deviceInfo.numUniformPredicatesPrWarp,
                                              warpData->uniformPredicatesDump);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to read uniform predicate registers (res = %d)\n", res);
            goto warpData_error;
        }
    }

    /* Dump parameter memory for this grid */
    if (!gridData->paramsDump && gridData->paramsSize) {
        gridData->paramsDump = (char *)calloc(1, (size_t)gridData->paramsSize);
        if (!gridData->paramsDump) {
            CUDBG_ERROR("Failed to allocate memory\n");
            res = CUDBG_ERROR_OS_RESOURCES;
            goto warpData_error;
        }

        res = dev->halo.readParamMemory(dev, vsm, wp,
                                        gridData->gridTableEntry.paramsOffset, gridData->paramsDump,
                                        (uint32_t)gridData->paramsSize);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to read user params memory (res = %d)!\n", res);
            goto warpData_error;
        }
    }

    /* Store numRegsPerLane so the thread state collection can allocate a large
     * enough buffer. */
    warpData->numRegsPerLane = gridData->gridTableEntry.numRegs;

    /* Create the threadData list and populate it */
    warpData->threadDataList = toolsListNew();
    if (!warpData->threadDataList) {
        CUDBG_ERROR("Failed to create threadDataList\n");
        res = CUDBG_ERROR_UNKNOWN;
        goto warpData_error;
    }

    res = cudbgCoredumpBuildThreadData(devId, vsm, wp, warpData);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Failed to build lane state data structure\n");
        goto warpData_error;
    }

    tres = toolsListAppend(ctaData->warpDataList, warpData);
    if (tres != TOOLS_SUCCESS) {
        CUDBG_ERROR("Failed to insert CudbgWarpStateEntry into smData (tres=%u)\n", tres);
        res = CUDBG_ERROR_UNKNOWN;
    }

    return res;

warpData_error:
    if (warpData)
        cudbgCoredumpDestroyWarpData(warpData, &res2);
    return res;
}

static CUDBGResult
cudbgCoredumpBuildCtaData(uint32_t devId, uint32_t vsm,
                           CudbgCoredumpDeviceData *deviceData, CudbgCoredumpSmData *smData)
{
    CUDBGResult res = CUDBG_SUCCESS, res2 = CUDBG_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;
    CudbgDevice dev = haloGlobals.device[devId];
    CudbgWarp_t *warp;
    CudbgCoredumpCTAData *ctaData;
    CuDim3 blockIdx;
    uint32_t wp;

    for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; wp++) {
        warp = &dev->smState[vsm].warp[wp];

        if (!warp->valid)
            continue;

        ctaData = (CudbgCoredumpCTAData *)toolsHashMapFind(smData->ctaMap,
                                                           tHashMapNumToKey(warp->virtCTAID));

        if (ctaData == NULL) {
            res = dev->halo.read_blockIdx(dev, vsm, wp, &blockIdx);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                         "Failed to read blockIdx (res = %d)!\n", res);

            ctaData = (CudbgCoredumpCTAData *)calloc(1, sizeof(CudbgCoredumpCTAData));
            CUDBG_VERIFY(ctaData, CUDBG_ERROR_OS_RESOURCES,
                         "Failed to allocate memory\n");

            ctaData->ctaTableEntry.gridId64 = warp->gridId64;

            ctaData->ctaTableEntry.blockIdxX = blockIdx.x;
            ctaData->ctaTableEntry.blockIdxY = blockIdx.y;
            ctaData->ctaTableEntry.blockIdxZ = blockIdx.z;

            ctaData->numUniformRegsPrWarp = dev->halo.deviceInfo.numUniformRegsPrWarp;
            ctaData->numUniformPredicatesPrWarp = dev->halo.deviceInfo.numUniformPredicatesPrWarp;

            /* If this warp belongs to a grid that uses shared memory, add a dump
             * of shared memory for the block this warp belongs to, if it hasn't
             * been dumped already. Skip for lightweight coredumps. */
            if (warp->CTASharedSize != 0 && !cudbgIsCoredumpLightweightEnabled()) {
                ctaData->smemDump = (char *)calloc(1, warp->CTASharedSize);
                if (!ctaData->smemDump) {
                  CUDBG_ERROR("Failed to allocate memory\n");
                  res = CUDBG_ERROR_OS_RESOURCES;
                  goto ctaData_error;
                }

                ctaData->smemSize = warp->CTASharedSize;

                res = dev->halo.readSharedMemory(dev, vsm, wp, 0, ctaData->smemDump,
                                                 warp->CTASharedSize);
                if (!ctaData->smemDump) {
                  CUDBG_ERROR("Failed to read shared memory for virtCTAID %u\n", warp->virtCTAID);
                  res = CUDBG_ERROR_OS_RESOURCES;
                  goto ctaData_error;
                }
            }
            else {
                ctaData->smemDump = NULL;
                ctaData->smemSize = 0;
            }

            /* Allocate the warpDataList */
            ctaData->warpDataList = toolsListNew();
            if (!ctaData->warpDataList) {
                CUDBG_ERROR("Failed to create ctaData->warpDataList for sm %d ctaId %d\n", vsm,
                            warp->virtCTAID);
                res = CUDBG_ERROR_UNKNOWN;
                goto ctaData_error;
            }

            tres = toolsHashMapInsert(smData->ctaMap,
                                      tHashMapNumToKey(warp->virtCTAID), (void*)ctaData);
            if (tres != TOOLS_SUCCESS) {
                CUDBG_ERROR("Failed to insert ctaData into ctaMap (tres=%u)\n", tres);
                res = CUDBG_ERROR_UNKNOWN;
                goto ctaData_error;
            }
        }

        res = cudbgCoredumpBuildWarpData(devId, vsm, wp, deviceData, ctaData);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to build warp data for dev%d/vsm%d/wp%d, res=%d\n", devId, vsm, wp, res);
            return res;
        }
    }

    return res;
ctaData_error:
    if (ctaData)
        cudbgCoredumpDestroyCtaData(ctaData, &res2);
    return res;
}

static CUDBGResult
cudbgCoredumpBuildSmData(uint32_t devId, CudbgCoredumpDeviceData *deviceData)
{
    CUDBGResult res = CUDBG_SUCCESS, res2 = CUDBG_SUCCESS;
    uint32_t vsm;
    TOOLSresult tres = TOOLS_SUCCESS;
    CudbgDevice dev = haloGlobals.device[devId];
    CudbgCoredumpSmData *smData = NULL;

    for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; vsm++) {
        smData = (CudbgCoredumpSmData *)calloc(1, sizeof(CudbgCoredumpSmData));
        CUDBG_VERIFY(smData, CUDBG_ERROR_OS_RESOURCES,
                     "Failed to allocate memory\n");

        /* Allocate the ctaMap */
        smData->ctaMap = toolsHashMapNew(toolsUint32HashFun, toolsUint64EqualFun, 16);
        if (!smData->ctaMap) {
            res = CUDBG_ERROR_UNKNOWN;
            CUDBG_ERROR("Failed to create smData->ctaMap for sm %d\n", vsm);
            goto smData_error;
        }

        smData->smTableEntry.smId = vsm;

        /* Build warpData for this SM */
        res = cudbgCoredumpBuildCtaData(devId, vsm, deviceData, smData);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to build warp state data structure\n");
            goto smData_error;
        }

        /* Add smData to the list */
        tres = toolsListAppend(deviceData->smList, smData);
        if (tres != TOOLS_SUCCESS) {
            CUDBG_ERROR("Failed to insert smData into deviceData->smList (tres=%u)\n", tres);
            free(smData);
            return CUDBG_ERROR_UNKNOWN;
        }
    }

    return res;
smData_error:
    if (smData)
        cudbgCoredumpDestroySmData(smData, &res2);
    return res;
}

static void
cudbgCoredumpDestroyModuleData(void* entry, void* data)
{
    CUDBGResult *res = (CUDBGResult*)data;
    CudbgCoredumpModuleData *modData = (CudbgCoredumpModuleData*)entry;

    if (modData == NULL) {
        *res = CUDBG_ERROR_INVALID_ARGS;
        return;
    }

    free(modData);
}

static void
cudbgCoredumpDestroyContextData(void* entry, void* data)
{
    TOOLSresult tres = TOOLS_SUCCESS;
    CUDBGResult *res = (CUDBGResult*)data;
    CudbgCoredumpCtxData *ctxData = (CudbgCoredumpCtxData*)entry;

    if (ctxData == NULL) {
        *res = CUDBG_ERROR_INVALID_ARGS;
        return;
    }

    if (ctxData->moduleList) {
        tres = toolsListDelete(ctxData->moduleList, cudbgCoredumpDestroyModuleData, data);
        if (tres != TOOLS_SUCCESS) {
            *res = CUDBG_ERROR_UNKNOWN;
            return;
        }
        ctxData->moduleList = NULL;
    }

    free(ctxData);
}

static void
cudbgCoredumpDestroyBacktraceData(void* entry, void* data)
{
    CUDBGResult *res = (CUDBGResult*)data;
    CudbgBacktraceTableEntry *bt = (CudbgBacktraceTableEntry*)entry;

    if (bt == NULL) {
        *res = CUDBG_ERROR_INVALID_ARGS;
        return;
    }

    free(bt);
}


static void
cudbgCoredumpDestroyThreadData(void* entry, void* data)
{
    TOOLSresult tres = TOOLS_SUCCESS;
    CUDBGResult *res = (CUDBGResult*)data;
    CudbgCoredumpThreadData *threadData = (CudbgCoredumpThreadData*)entry;
    if (threadData == NULL) {
        *res = CUDBG_ERROR_INVALID_ARGS;
        return;
    }

    if (threadData->backtrace) {
        tres = toolsListDelete(threadData->backtrace, cudbgCoredumpDestroyBacktraceData, data);
        if (tres != TOOLS_SUCCESS) {
            *res = CUDBG_ERROR_UNKNOWN;
            return;
        }
        threadData->backtrace = NULL;
    }

    free(threadData->predicates);
    free(threadData->lmemHi);
    free(threadData->regDump);
    free(threadData);
}

static void
cudbgCoredumpDestroyWarpData(void* entry, void* data)
{
    TOOLSresult tres = TOOLS_SUCCESS;
    CUDBGResult *res = (CUDBGResult*)data;
    CudbgCoredumpWarpData *warpData = (CudbgCoredumpWarpData*)entry;

    if (warpData == NULL) {
        *res = CUDBG_ERROR_INVALID_ARGS;
        return;
    }

    if (warpData->threadDataList) {
        tres = toolsListDelete(warpData->threadDataList, cudbgCoredumpDestroyThreadData, data);
        if (tres != TOOLS_SUCCESS) {
            CUDBG_ERROR("Failed to free threadData\n");
            *res = CUDBG_ERROR_UNKNOWN;
            return;
        }
        warpData->threadDataList = NULL;
    }

    free(warpData->uniformRegDump);
    free(warpData->uniformPredicatesDump);
    free(warpData);
}

static void
cudbgCoredumpDestroyCtaData(void* entry, void* data)
{
    TOOLSresult tres = TOOLS_SUCCESS;
    CUDBGResult *res = (CUDBGResult*)data;
    CudbgCoredumpCTAData *ctaData = (CudbgCoredumpCTAData*)entry;

    if (ctaData == NULL) {
        *res = CUDBG_ERROR_INVALID_ARGS;
        return;
    }

    if (ctaData->warpDataList) {
        tres = toolsListDelete(ctaData->warpDataList, cudbgCoredumpDestroyWarpData, data);
        if (tres != TOOLS_SUCCESS) {
            CUDBG_ERROR("Failed to free warpData\n");
            *res = CUDBG_ERROR_UNKNOWN;
            return;
        }
        ctaData->warpDataList = NULL;
    }

    free(ctaData->smemDump);
    free(ctaData);
}

static void
cudbgCoredumpDestroySmData(void* entry, void* data)
{
    TOOLSresult tres = TOOLS_SUCCESS;
    CUDBGResult *res = (CUDBGResult*)data;
    CudbgCoredumpSmData *smData = (CudbgCoredumpSmData*)entry;

    if (smData == NULL) {
        *res = CUDBG_ERROR_INVALID_ARGS;
        return;
    }

    if (smData->ctaMap) {
        tres = toolsHashMapDelete(smData->ctaMap, cudbgCoredumpDestroyCtaData, data);
        if (tres != TOOLS_SUCCESS) {
            CUDBG_ERROR("Failed to free ctaMap\n");
            *res = CUDBG_ERROR_UNKNOWN;
            return;
        }
        smData->ctaMap = NULL;
    }

    free(smData);
}

static void
cudbgCoredumpDestroyGridData(void* entry, void* data)
{
    CUDBGResult *res = (CUDBGResult*)data;
    CudbgCoredumpGridData *gridData = (CudbgCoredumpGridData*)entry;

    if (gridData == NULL) {
        *res = CUDBG_ERROR_INVALID_ARGS;
        return;
    }

    free(gridData);
}

static void
cudbgCoredumpDestroyDeviceData(void* entry, void* data)
{
    TOOLSresult tres = TOOLS_SUCCESS;
    CUDBGResult *res = (CUDBGResult*)data;
    CudbgCoredumpDeviceData* deviceData = (CudbgCoredumpDeviceData*)entry;

    if (deviceData == NULL) {
        *res = CUDBG_ERROR_INVALID_ARGS;
        return;
    }

    if (deviceData->gridDataMap) {
        tres = toolsHashMapDelete(deviceData->gridDataMap, cudbgCoredumpDestroyGridData, NULL);
        if (tres != TOOLS_SUCCESS) {
            CUDBG_ERROR("Failed to free gridDataMap\n");
            *res = CUDBG_ERROR_UNKNOWN;
            return;
        }
        deviceData->gridDataMap = NULL;
    }

    if (deviceData->smList) {
        tres = toolsListDelete(deviceData->smList, cudbgCoredumpDestroySmData, NULL);
        if (tres != TOOLS_SUCCESS) {
            CUDBG_ERROR("Failed to free smList\n");
            *res = CUDBG_ERROR_UNKNOWN;
            return;
        }
        deviceData->smList = NULL;
    }

    if (deviceData->ctxList) {
        tres = toolsListDelete(deviceData->ctxList, cudbgCoredumpDestroyContextData, NULL);
        if (tres != TOOLS_SUCCESS) {
            CUDBG_ERROR("Failed to free ctxList\n");
            *res = CUDBG_ERROR_UNKNOWN;
            return;
        }
        deviceData->ctxList = NULL;
    }

    free(deviceData);
}

static void
cudbgCoredumpDestroyMemoryData(void* entry, void* data)
{
    CUDBGResult *res = (CUDBGResult*)data;
    CudbgCoredumpMemoryData* memData = (CudbgCoredumpMemoryData*)entry;

    if (memData == NULL) {
        *res = CUDBG_ERROR_UNKNOWN;
        return;
    }

    free(memData->memDump);
    free(memData);
}

static CUDBGResult
cudbgCoredumpDestroyCoredumpData(void)
{
    CUDBGResult res = CUDBG_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;
    CudbgCoredumpData *coredumpData = &coredumpGlobals.coredumpData;
    if (coredumpData->deviceDataList) {
        /* We delete here, but we really just want to clear the list... oh well */
        tres = toolsListDelete(coredumpData->deviceDataList, cudbgCoredumpDestroyDeviceData, (void*)&res);
        CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_UNKNOWN,
                     "Failed to free deviceDataList\n");
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to free deviceDataList\n");
        /* Re-create this list since our build function didn't actually create it. */
        coredumpGlobals.coredumpData.deviceDataList = toolsListNew();
    }

    if (coredumpData->memoryDataMap) {
        toolsRangeMapDestroy(&coredumpData->memoryDataMap, cudbgCoredumpDestroyMemoryData, (void*)&res);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to free memoryDataMap\n");
    }

    return res;
}

static CUDBGResult
cudbgCoredumpBuildDeviceData(tList *deviceDataList)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CUresult status = CUDA_SUCCESS;
    CudbgCoredumpDeviceData *deviceData;
    TOOLSresult tres = TOOLS_SUCCESS;
    uint32_t devId;
    uint64_t stringTableOffset;
    char *stringPtr;
    CudbgDevice dev;
    CudbgCoredumpStringTable *stringTable =
        coredumpGlobals.coredumpData.stringTable;

    for (devId = 0; devId < globals.numDevices; devId++) {
        CUDBG_VERIFY(haloGlobals.device && haloGlobals.device[devId],
                     CUDBG_ERROR_UNINITIALIZED,
                     "HALO not initialized.\n");

        dev = haloGlobals.device[devId];
        CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_DEVICE, "Unknown device!\n");

        deviceData = (CudbgCoredumpDeviceData *)calloc(1, sizeof (CudbgCoredumpDeviceData));
        CUDBG_VERIFY(deviceData, CUDBG_ERROR_OS_RESOURCES,
                     "Failed to allocate memory\n");

        deviceData->deviceTableEntry.devId = devId;
        deviceData->deviceTableEntry.pciBusId = globals.devices[devId]->state.pciBus;
        deviceData->deviceTableEntry.pciDevId = globals.devices[devId]->state.pciDevice;
        deviceData->deviceTableEntry.numSMs = globals.devices[devId]->state.limits.physicalSmCount;
        deviceData->deviceTableEntry.numWarpsPerSM = globals.devices[devId]->state.limits.warpsPerSm;
        deviceData->deviceTableEntry.numLanesPerWarp = globals.devices[devId]->state.limits.warpSize;
        deviceData->deviceTableEntry.instructionSize = globals.devices[devId]->state.limits.instructionSizeInBytes;
        deviceData->deviceTableEntry.smMajor = (uint32_t)globals.devices[devId]->state.major;
        deviceData->deviceTableEntry.smMinor = (uint32_t)globals.devices[devId]->state.minor;
        deviceData->deviceTableEntry.status = dev->status;

        /* The following will be unavailable if the device is watchdogged */
        deviceData->deviceTableEntry.numRegsPerLane = dev->halo.deviceInfo.numRegsPrLane;
        deviceData->deviceTableEntry.numPredicatesPrLane = dev->halo.deviceInfo.numPredicatesPrLane;
        deviceData->deviceTableEntry.numUniformRegsPrWarp = dev->halo.deviceInfo.numUniformRegsPrWarp;
        deviceData->deviceTableEntry.numUniformPredicatesPrWarp = dev->halo.deviceInfo.numUniformPredicatesPrWarp;

        /* Get the smType string */
        stringPtr = globals.devices[devId]->state.isav;

        res = cudbgCoredumpAddToStringTable(stringTable, &stringTableOffset, stringPtr);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to add string %s to string table\n", stringPtr);
            free(deviceData);
            return res;
        }

        deviceData->deviceTableEntry.smType = stringTableOffset;

        /* Get the deviceName string */
        status = globals.devices[devId]->dmal.deviceGetName(globals.devices[devId],
                                                            stringBuffer, sizeof(stringBuffer));
        if (status != CUDA_SUCCESS) {
            CUDBG_ERROR("Failed to get the deviceName string (status=%d).\n", status);
            free(deviceData);
            return CUDBG_ERROR_UNKNOWN;
        }

        res = cudbgCoredumpAddToStringTable(stringTable, &stringTableOffset, stringBuffer);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to add string %s to string table\n", stringBuffer);
            free(deviceData);
            return res;
        }

        deviceData->deviceTableEntry.devName = stringTableOffset;

        /* Get the deviceType string */
        stringPtr = globals.devices[devId]->state.name;

        res = cudbgCoredumpAddToStringTable(stringTable, &stringTableOffset, stringPtr);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to add string %s to string table\n", stringPtr);
            free(deviceData);
            return res;
        }

        deviceData->deviceTableEntry.devType = stringTableOffset;
        tres = toolsListAppend(deviceDataList, deviceData);
        if (tres != TOOLS_SUCCESS) {
            CUDBG_ERROR("Failed to insert deviceData into deviceDataList (tres=%u)\n", tres);
            free(deviceData);
            return CUDBG_ERROR_UNKNOWN;
        }

        /* Pretend there's no work running on watchdogged devices. */
        if (dev->status == CUDBG_ERROR_SOME_DEVICES_WATCHDOGGED)
            continue;

#ifdef COREDUMP_CACHE_CILP_BUFFER
        if (dev->activeContext && dev->activeContext->memMap
            && dev->activeContext->cilpBufferDevVA && dev->halo.deviceInfo.cilpBufferSizePerSM > 0) {

            /* Locally cache the CILP buffer */
            res = haloMemoryRangeCacheOp(dev->activeContext->memMap,
                                         dev->activeContext->cilpBufferDevVA,
                                         dev->halo.deviceInfo.cilpBufferSizePerSM * dev->halo.deviceInfo.numSMs,
                                         HALO_MEM_SEG_CACHE_ENABLE);
            if (res != CUDBG_SUCCESS)
                CUDBG_ERROR("Failed to cache cilp buffer for dev%d\n", devId);
        }
#endif

        /* Create the gridDataMap and populate it */
        deviceData->gridDataMap =
            toolsHashMapNew(toolsUint32HashFun, toolsUint64EqualFun, 16);
        CUDBG_VERIFY(deviceData->gridDataMap,
                     CUDBG_ERROR_UNKNOWN, "Failed to create gridDataMap\n");

        res = cudbgCoredumpBuildGridData(devId, deviceData->gridDataMap);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to build grid state data structure\n");

        /* Allocate the smData list and populate it */
        deviceData->smList = toolsListNew();
        CUDBG_VERIFY(deviceData->smList, CUDBG_ERROR_UNKNOWN,
                     "Failed to create smList\n");

        res = cudbgCoredumpBuildSmData(devId, deviceData);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to build SM data\n");

        /* Allocate the ctxData list and populate it */
        deviceData->ctxList = toolsListNew();
        CUDBG_VERIFY(deviceData->ctxList, CUDBG_ERROR_UNKNOWN,
                     "Failed to create ctxList\n");

        res = cudbgCoredumpBuildContextData(devId, deviceData);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to build context state data structure\n");
    }

    return res;
}

/*************************************************************/


/* Build coredump-specific data structures that will eventually be written to the core file. */
static CUDBGResult
cudbgCoredumpBuildCoredumpData(void)
{
    CUDBGResult res = CUDBG_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;
    CudbgCoredumpData *coredumpData = &coredumpGlobals.coredumpData;
    tList *deviceDataList = coredumpData->deviceDataList;

    /* Build the memoryDataMap and ctxList */
    tres = toolsRangeMapCreate(&coredumpData->memoryDataMap);
    CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_UNKNOWN,
                 "Failed to create memoryDataMap (tres=%u)\n",
                 tres);

    /* Build device data structures for all devices the backend knows about.
     * To parallelize this, fire off a thread for each device the backend knows about.
     */
    res = cudbgCoredumpBuildDeviceData(deviceDataList);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to build device state data structure\n");

    return res;
}

/************** Exported functions **************************/

bool
cudbgIsCoredumpEnabled(void)
{
    return coredumpGlobals.coredumpEnabled;
}

bool
cudbgIsUserCoredumpEnabled(void)
{
    return coredumpGlobals.userCoredumpEnabled;
}

bool
cudbgIsCoredumpInProgress(void)
{
    return coredumpGlobals.coredumpInProgress;
}

bool
cudbgIsCoredumpLightweightEnabled(void)
{
    return coredumpGlobals.lightweightEnabled;
}

void
cudbgCoredumpEnable(const char *fileName)
{
    strncpy(coredumpFileName, fileName ? fileName : DEFAULT_COREDUMP_FILE_NAME, CUDBG_COREDUMP_STRING_BUFFER_SIZE);
    coredumpFileName[CUDBG_COREDUMP_STRING_BUFFER_SIZE - 1] = 0;
    cudbgCoredumpExpandFileNameInternal(coredumpFileName);
    coredumpGlobals.coredumpEnabled = true;
}

void
cudbgUserCoredumpEnable(const char *pipeName)
{
    strncpy(coredumpPipeName, pipeName ? pipeName : DEFAULT_COREDUMP_PIPE_NAME, CUDBG_COREDUMP_STRING_BUFFER_SIZE);
    coredumpPipeName[CUDBG_COREDUMP_STRING_BUFFER_SIZE - 1] = 0;
    cudbgCoredumpExpandFileNameInternal(coredumpPipeName);
    coredumpGlobals.userCoredumpEnabled = true;
}

void
cudbgCpuCoredumpEnable(bool enable)
{
    if (!enable)
        coredumpGlobals.cpuCoredumpDisabled = true;
}

void
cudbgCoredumpLightweightEnable(void)
{
    coredumpGlobals.lightweightEnabled = true;
}

const char *
cudbgCoredumpGetCorePipeName()
{
    return coredumpPipeName;
}

/* The debugger critical section lock is held when these are called. */
CUDBGResult
cudbgCoredumpInitMessage(void)
{
    if (coredumpGlobals.msgInitialized)
        return CUDBG_SUCCESS;

    coredumpGlobals.msg = NULL;
    coredumpGlobals.msgSize = 0;

    coredumpGlobals.msgInitialized = true;

    return CUDBG_SUCCESS;
}

CUDBGResult
cudbgCoredumpFinalizeMessage(void)
{
    return cudbgCoredumpResetMessage();
}

CUDBGResult
cudbgCoredumpResetMessage(void)
{
    free(coredumpGlobals.msg);
    coredumpGlobals.msgSize = 0;
    coredumpGlobals.msgInitialized = false;

    return CUDBG_SUCCESS;
}

CUDBGResult
cudbgCoredumpPushMessage(void *obj, uint64_t objSize)
{
    /* Resize the message buffer to be big enough to hold its current
     * contents + the new object. */
    coredumpGlobals.msg = (char *)realloc(coredumpGlobals.msg,
                                          (size_t)(coredumpGlobals.msgSize + objSize));
    CUDBG_VERIFY(coredumpGlobals.msg, CUDBG_ERROR_COMMUNICATION_FAILURE,
                 "Failed to allocate memory\n");

    /* Append the object to the message buffer */
    memcpy((char*)coredumpGlobals.msg + coredumpGlobals.msgSize, obj, (size_t)objSize);

    /* Update the message size. The size is reset to 0 in cudbgCoredumpSendMessage. */
    coredumpGlobals.msgSize += objSize;

    return CUDBG_SUCCESS;
}

CUDBGResult
cudbgCoredumpSendMessage(void)
{
    uint32_t hostThreadId; /* unused */
    bool requiresDebuggerAck = false; /* unused */
    CUDBGResult res;

    CUDBG_VERIFY(coredumpGlobals.msg != NULL && coredumpGlobals.msgSize != 0,
                 CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    res = gpudbgProcessApplicationMessage(coredumpGlobals.msg,
                                          &requiresDebuggerAck, &hostThreadId);

    /* Reset the message size so new messages can be sent. */
    coredumpGlobals.msgSize = 0;

    return res;
}

void
cudbgCoredumpTriggerCPUCoredump()
{
// __TEMP_WAR__ abort is not verified on HOS yet
#if !cuosOsIsHos()
    CUDBG_PRINT(DBG_LEVEL, "Coredump: triggering CPU coredump\n");
    abort();
#endif

    /* The GPU is in a non-deterministic state now, ensure we don't resume it */
    /* TODO:  Remove this so we don't hold threads and can properly be handled. */
    while (1);
}

CUresult
cudbgCoredumpInitialize(CUctx *ctx)
{
    CUDBGResult res = CUDBG_SUCCESS, res2 = CUDBG_SUCCESS;
    int ret;
    int threadSerial;

    res = cudbgCoredumpInitializeGlobals();
    CUDBG_VERIFY(res == CUDBG_SUCCESS, CUDA_ERROR_UNKNOWN,
                 "Failed to initialize globals (res=%d)\n", res);

    CUDBG_PRINT(DBG_LEVEL, "Context %d initializing coredump\n", ctx->ctxId);

    /* Signal all other contexts to start state collection */
    res = cudbgCoredumpSignalAllContexts(ctx);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, CUDA_ERROR_UNKNOWN,
                 "Failed to signal all contexts (res=%d)\n", res);

    /* Initialize the HALO for this context and its device */
    res = cudbgCoredumpInitializeHalo(ctx);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, CUDA_ERROR_UNKNOWN,
                 "Failed to initialize the HALO (res=%d)\n", res);

    /* Collect state for this context and send it to the debugger backend */
    res = cudbgCoredumpCollectContextState(ctx);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, CUDA_ERROR_UNKNOWN,
                 "Failed to collect state (res=%d)\n", res);

    /* Ensure state for all contexts has been collected before attempting to
     * suspend the device. Otherwise while suspending, the debugger backend
     * might not find the active context in the dev->contexts list.
     * When this barrier is unlocked, it will have been initialized back to
     * its initial state. */
    ret = cuosBarrierWait(&coredumpGlobals.barrier);
    CUDBG_VERIFY(ret == CUOS_SUCCESS, CUDA_ERROR_UNKNOWN,
                 "Failed to wait on barrier (ret=%d)\n", ret);

    /* Suspend this ctx's device, causing HALO to collect HW state.
     * All ctx's needs to do this, since they may be running on different devices */
    res = cudbgCoredumpSuspendDeviceAndCollectState(ctx->device->state.deviceIdx);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, CUDA_ERROR_UNKNOWN,
                 "Failed to suspend device and collect state via HALO (res=%d)\n", res);

    /* Wait till all devices have been suspended and their state has been
     * collected, before writing the core file out, else we'll end up writing
     * incomplete state to the core file.
     * When this barrier is unlocked, it will have been initialized back to
     * its initial state.*/
    ret = cuosBarrierWait(&coredumpGlobals.barrier);
    CUDBG_VERIFY(ret == CUOS_SUCCESS, CUDA_ERROR_UNKNOWN,
            "Failed to wait on barrier (ret=%d)\n", ret);

    /* Randomly pick one of the inthandler threads to create the coredump */
    threadSerial = cuosInterlockedIncrement(&coredumpGlobals.threadSerial);
    if (threadSerial != 1)
        goto wait_for_completion;

    /* Build data structures that will be written out to the coredump */
    res = cudbgCoredumpBuildCoredumpData();
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Failed to build coredump state (res=%d)\n", res);
        goto skip_dump;
    }

    res = cudbgCoredumpCreateCoreFile(coredumpFileName, &coredumpGlobals.coredumpData);
    /* Don't return here.  We need to cleanup and hit the barrier,
       otherwise all other threads could deadlock */
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Failed to dump core file (res=%d)\n", res);
        goto skip_dump;
    }

    /* Remove the user triggered corepipe if it exists. */
    if ((coredumpGlobals.userCoredumpEnabled) &&
        (cuosIpcDestroy((char *) cudbgCoredumpGetCorePipeName()) != CUOS_SUCCESS)) {
        CU_ERROR_PRINT(("Failed to destroy the named pipe\n"));
    }

skip_dump:
    res2 = cudbgCoredumpDestroyCoredumpData();
    if (res2 != CUDBG_SUCCESS) {
        CUDBG_ERROR("Failed to cleanup coredump state (res=%d)\n", res);
        res = res2;
    }

    CUDBG_PRINT(DBG_LEVEL, "Coredump: finished dumping corefile\n");

    coredumpGlobals.state |= COREDUMP_STATE_COREDUMP_COMPLETE;

    CUDBG_PRINT(DBG_LEVEL, "Coredump: resetting GPUs\n");

    (void)tgdbResetAllDevices();

wait_for_completion:
    /* Wait for coredump collection to finish */
    ret = cuosBarrierWait(&coredumpGlobals.barrier);
    CUDBG_VERIFY(ret == CUOS_SUCCESS, CUDA_ERROR_UNKNOWN,
                 "Failed to wait on barrier for coredump collection completion (ret=%d)\n", ret);
    /* Now we can return errors, since we've gotten passed the barrier */
    if (res != CUDBG_SUCCESS)
        return (CUresult)res;

    CUDBG_PRINT(DBG_LEVEL, "Coredump: all threads synced\n");

    if (!coredumpGlobals.cpuCoredumpDisabled && threadSerial == 1 && !cuiCtxIsMpsSubctxClient(ctx)) {
        cudbgCoredumpTriggerCPUCoredump();
    }

    return (CUresult)res;
}

CUresult
cudbgCoredumpFinalize(CUctx *ctx)
  TS_NO_THREAD_SAFETY_ANALYSIS // conditional unlock
{
    CUresult status = CUDA_SUCCESS;
    CUDBGResult res = CUDBG_SUCCESS;

    cuosEnterCriticalSection(&globals.debugger_cs);

    /* Check if state was already finalized */
    if (!(coredumpGlobals.state & COREDUMP_STATE_GLOBALS_INITIALIZED))
        goto done;

    res = cudbgCoredumpDestroyCoredumpData();
    if (res != CUDBG_SUCCESS)
        CUDBG_ERROR("Failed to destroy coredump data\n");

    cuiMutexUnlock(&globals.debuggerAttachMutex);

    coredumpGlobals.state |= COREDUMP_STATE_FINALIZED;

    cuosBarrierDestroy(&coredumpGlobals.barrier);

done:
    cuosLeaveCriticalSection(&globals.debugger_cs);

    return status;
}

