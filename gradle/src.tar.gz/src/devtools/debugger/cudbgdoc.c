/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */



/***************************************************************************

 Dummy repository file for all the Doxygen documentation that should
 have been in cudadebugger.h, but have no purpose appearing in
 cudbgapi.c. Just to keep things clean.

***************************************************************************/


/************************** Files Information *****************************/

/**
 * \file cudadebugger.h
 * \brief Header file for the CUDA debugger API.
 */


/******************************* CUDBGAPI_st ******************************/

/**
 * \struct CUDBGAPI_st
 * \brief The CUDA debugger API routines.
 */

/****************************** CUDBGResult *******************************/

/** \enum CUDBGResult
 * \brief Result values of all the API routines.
 * \ingroup GENERAL */
/** \var CUDBGResult CUDBG_SUCCESS
 *  \brief The API call executed successfully. */
/** \var CUDBGResult CUDBG_ERROR_UNKNOWN
 *  \brief Error type not listed below. */
/** \var CUDBGResult CUDBG_ERROR_BUFFER_TOO_SMALL
 *  \brief Cannot copy all the queried data into the buffer argument. */
/** \var CUDBGResult CUDBG_ERROR_UNKNOWN_FUNCTION
 *  \brief Function cannot be found in the CUDA kernel. */
/** \var CUDBGResult CUDBG_ERROR_INVALID_ARGS
 *  \brief Wrong use of arguments (NULL pointer, illegal value,....). */
/** \var CUDBGResult CUDBG_ERROR_UNINITIALIZED
 *  \brief Debugger API has not yet been properly initialized. */
/** \var CUDBGResult CUDBG_ERROR_INVALID_COORDINATES
 *  \brief Invalid block or thread coordinates were provided. */
/** \var CUDBGResult CUDBG_ERROR_INVALID_MEMORY_SEGMENT
 *  \brief Invalid memory segment requested. */
/** \var CUDBGResult CUDBG_ERROR_INVALID_MEMORY_ACCESS
 *  \brief Requested address (+size) is not within proper segment boundaries. */
/** \var CUDBGResult CUDBG_ERROR_MEMORY_MAPPING_FAILED
 *  \brief Memory is not mapped and cannot be mapped. */
/** \var CUDBGResult CUDBG_ERROR_INTERNAL
 *  \brief A debugger internal error occurred. */
/** \var CUDBGResult CUDBG_ERROR_INVALID_DEVICE
 *  \brief Specified device cannot be found. */
/** \var CUDBGResult CUDBG_ERROR_INVALID_SM
 *  \brief Specified sm cannot be found. */
/** \var CUDBGResult CUDBG_ERROR_INVALID_WARP
 *  \brief Specified warp cannot be found. */
/** \var CUDBGResult CUDBG_ERROR_INVALID_LANE
 *  \brief Specified lane cannot be found. */
/** \var CUDBGResult CUDBG_ERROR_SUSPENDED_DEVICE
 *  \brief The requested operation is not allowed when the device is suspended. */
/** \var CUDBGResult CUDBG_ERROR_RUNNING_DEVICE
 *  \brief Device is running and not suspended. */
/** \var CUDBGResult CUDBG_ERROR_INVALID_ADDRESS
 *  \brief Address is out-of-range. */
/** \var CUDBGResult CUDBG_ERROR_INCOMPATIBLE_API
 *  \brief The requested API is not available. */
/** \var CUDBGResult CUDBG_ERROR_INITIALIZATION_FAILURE
 *  \brief The API could not be initialized. */
/** \var CUDBGResult CUDBG_ERROR_INVALID_GRID
 *  \brief The specified grid is not valid. */
/** \var CUDBGResult CUDBG_ERROR_NO_EVENT_AVAILABLE
 *  \brief The event queue is empty and there is no event left to be processed. */
/** \var CUDBGResult CUDBG_ERROR_SOME_DEVICES_WATCHDOGGED
 *  \brief Some devices were excluded because they have a watchdog associated with them. */
/** \var CUDBGResult CUDBG_ERROR_ALL_DEVICES_WATCHDOGGED
 *  \brief All devices were exclude because they have a watchdog associated with them. */
/** \var CUDBGResult CUDBG_ERROR_INVALID_ATTRIBUTE
 *  \brief Specified attribute does not exist or is incorrect */
/** \var CUDBGResult CUDBG_ERROR_ZERO_CALL_DEPTH
 *  \brief No function calls have been made on the device */
/** \var CUDBGResult CUDBG_ERROR_INVALID_CALL_LEVEL
 *  \brief Specified call level is invalid */
/** \var CUDBGResult CUDBG_ERROR_COMMUNICATION_FAILURE
 *  \brief Communication error between the debugger and the application. */
/** \var CUDBGResult CUDBG_ERROR_INVALID_CONTEXT
 *  \brief Specified context cannot be found. */
/** \var CUDBGResult CUDBG_ERROR_ADDRESS_NOT_IN_DEVICE_MEM
 *  \brief Requested address was not originally allocated from device memory (most likely visible in system memory). */
/** \var CUDBGResult CUDBG_ERROR_MEMORY_UNMAPPING_FAILED
 *  \brief Requested address is not mapped and cannot be unmapped. */
/** \var CUDBGResult CUDBG_ERROR_INCOMPATIBLE_DISPLAY_DRIVER
 *  \brief The display driver is incompatible with the API. */
/** \var CUDBGResult CUDBG_ERROR_INVALID_MODULE
 *  \brief The specified module is not valid */
/** \var CUDBGResult CUDBG_ERROR_LANE_NOT_IN_SYSCALL
 *  \brief The specified lane is not inside a device syscall. */
/** \var CUDBGResult CUDBG_ERROR_MEMCHECK_NOT_ENABLED
 *  \brief Memcheck has not been enabled. */
/** \var CUDBGResult CUDBG_ERROR_INVALID_ENVVAR_ARGS
 *  \brief Some environment variable's value is invalid. */
/** \var CUDBGResult CUDBG_ERROR_OS_RESOURCES
 *  \brief Error while allocating resources from the OS */
/** \var CUDBGResult CUDBG_ERROR_FORK_FAILED
 *  \brief Error while forking the debugger process */
/** \var CUDBGResult CUDBG_ERROR_NO_DEVICE_AVAILABLE
 *  \brief No CUDA capable device was found */
/** \var CUDBGResult CUDBG_ERROR_ATTACH_NOT_POSSIBLE
 *  \brief Attaching to the CUDA program is not possible */
/** \var CUDBGResult CUDBG_ERROR_AMBIGUOUS_MEMORY_ADDRESS
 *  \brief Specified device pointer cannot be resolved to a GPU unambiguously because it is valid on more than one GPU */

/****************************** CUDBGException****************************/

/** \enum CUDBGException_t
 *  \brief Harwdare Exception Types. */
/** \var CUDBGException_t CUDBG_EXCEPTION_UNKNOWN
 * \brief Reported if we do not know what exception the chip has hit (global error) */
/** \var CUDBGException_t CUDBG_EXCEPTION_NONE
 * \brief Reported when there is no exception on the chip (no error) */
/** \var CUDBGException_t CUDBG_EXCEPTION_LANE_ILLEGAL_ADDRESS
 * \brief Reported when memcheck(enabled within cuda-gdb) finds access violations (lane error: precise software generated exception) */
/** \var CUDBGException_t CUDBG_EXCEPTION_LANE_NONMIGRATABLE_ATOMSYS
 * \brief This error is deprecated as of CUDA 9.0 */
/** \var CUDBGException_t CUDBG_EXCEPTION_LANE_INVALID_ATOMSYS
 * \brief Reported when memcheck(enabled within cuda-gdb) finds system-scoped atomic to a location where it's not allowed (lane error: precise software generated exception) */
/** \var CUDBGException_t CUDBG_EXCEPTION_LANE_USER_STACK_OVERFLOW
 * \brief Reported from user (data) stack overflow checks in each function's prologue (lane error: precise software generated exception, ABI-only) */
/** \var CUDBGException_t CUDBG_EXCEPTION_DEVICE_HARDWARE_STACK_OVERFLOW
 * \brief Reported if CRS overflows (global error: the warp that caused this will terminate) */
/** \var CUDBGException_t CUDBG_EXCEPTION_WARP_ILLEGAL_INSTRUCTION
 * \brief Reported when any lane in a warp executes an illegal instruction (warp error: invalid branch target, invalid opcode, misaligned/oor reg, invalid immediates, etc.) */
/** \var CUDBGException_t CUDBG_EXCEPTION_WARP_OUT_OF_RANGE_ADDRESS
 * \brief Reported when any lane in a warp accesses memory that is out of range (warp error: lmem_lo/hi, shared, and 40-bit va accesses) */
/** \var CUDBGException_t CUDBG_EXCEPTION_WARP_MISALIGNED_ADDRESS
 * \brief Reported when any lane in a warp accesses memory that is misaligned (warp error: lmem_lo/hi, shared, and 40-bit va accesses) */
/** \var CUDBGException_t CUDBG_EXCEPTION_WARP_INVALID_ADDRESS_SPACE
 * \brief Reported when any lane in a warp executes an instruction that accesses a memory space that is not permitted for that instruction (warp error) */
/** \var CUDBGException_t CUDBG_EXCEPTION_WARP_INVALID_PC
 * \brief Reported when any lane in a warp advances its PC beyond the valid address space (warp error) */
/** \var CUDBGException_t CUDBG_EXCEPTION_WARP_HARDWARE_STACK_OVERFLOW
 * \brief Reported when any lane in a warp hits (uncommon) stack issues (warp error: stack error or api stack overflow) */
/** \var CUDBGException_t CUDBG_EXCEPTION_DEVICE_ILLEGAL_ADDRESS
 * \brief Reported when MMU detects an error (global error: L1 error status field is set in the global esr -- for the most part this catches errors SM couldn't catch with oor address detection) */
/** \var CUDBGException_t CUDBG_EXCEPTION_LANE_MISALIGNED_ADDRESS
 * \brief Reported when memcheck(enabled within cuda-gdb) finds access violations (lane error: precise software generated exception) */

/***************************** CUDBGAttribute ****************************/

/** \enum CUDBGAttribute
 *  \brief Query attribute. */
/** \var CUDBGAttribute CUDBG_ATTR_GRID_LAUNCH_BLOCKING
 * \brief whether the launch is synchronous or not. */
/** \var CUDBGAttribute CUDBG_ATTR_GRID_TID
 * \brief The id of the host thread that launched the grid. */

/**************************** CUDBGKernelType ****************************/

/** \enum CUDBGKernelType
 *  \brief Kernel types. */
/** \var CUDBGKernelType CUDBG_KNL_TYPE_UNKNOWN
 * \brief Unknown kernel type. Fall-back value. */
/** \var CUDBGKernelType CUDBG_KNL_TYPE_SYSTEM
 * \brief System kernel, launched by the CUDA driver (cudaMemset, ...). */
/** \var CUDBGKernelType CUDBG_KNL_TYPE_APPLICATION
 * \brief Application kernel, launched by the application. */

/************************* Elf Image Properties **************************/

/** \enum CUDBGElfImageProperties
 *  \brief ELF Image Properties. */
/** \var CUDBGElfImageProperties CUDBG_ELF_IMAGE_PROPERTIES_SYSTEM
 * \brief ELF image contains system kernels, launched by the CUDA driver. */

/**************************** CUDBGKernelOrigin **************************/

/** \enum CUDBGKernelOrigin
 *  \brief Kernel origin. */
/** \var CUDBGKernelOrigin CUDBG_KNL_ORIGIN_CPU
 * \brief The kernel was launched from the CPU. */
/** \var CUDBGKernelOrigin CUDBG_KNL_ORIGIN_GPU
 * \brief The kernel was launched from the GPU. */

/**************** CUDBGKernelLaunchNotifyMode  **************************/

/** \enum CUDBGKernelLaunchNotifyMode
 *  \brief Kernel launch notification mode */
/** \var CUDBGKernelLaunchNotifyMode CUDBG_KNL_LAUNCH_NOTIFY_EVENT
 * \brief Kernel launches generate launch notification events */
/** \var CUDBGKernelLaunchNotifyMode CUDBG_KNL_ORIGIN_NOTIFY_DEFER
 * \brief Kernel launches do not generate any notification  */

/**************************** CUDBGAdjAddrAction *************************/

/** \enum CUDBGAdjAddrAction
 *  \brief Describes which adjusted code address is to be returned. */
/** \var CUDBGAdjAddrAction CUDBG_ADJ_PREVIOUS_ADDRESS
 * \brief The adjusted previous code address is to be returned. */
/** \var CUDBGAdjAddrAction CUDBG_ADJ_NEXT_ADDRESS
 * \brief The adjusted next code address is to be returned. */
/** \var CUDBGAdjAddrAction CUDBG_ADJ_CURRENT_ADDRESS
 * \brief The adjusted current code address is to be returned. */

/****************************** CUDBGRegClass ****************************/

/** \enum CUDBGRegClass
 *  \brief Physical register types. */
/** \var CUDBGRegClass REG_CLASS_INVALID
 * \brief The physical register is invalid. */
/** \var CUDBGRegClass REG_CLASS_REG_CC
 * \brief The physical register is a condition code register. Unused. */
/** \var CUDBGRegClass REG_CLASS_REG_PRED
 * \brief The physical register is a predicate register. Unused. */
/** \var CUDBGRegClass REG_CLASS_REG_ADDR
 * \brief The physical register is an address register. Unused. */
/** \var CUDBGRegClass REG_CLASS_REG_HALF
 * \brief The physical register is a 16-bit register. Unused. */
/** \var CUDBGRegClass REG_CLASS_REG_FULL
 * \brief The physical register is a 32-bit register. */
/** \var CUDBGRegClass REG_CLASS_MEM_LOCAL
 * \brief The content of the physical register has been spilled to memory. */
/** \var CUDBGRegClass REG_CLASS_LMEM_REG_OFFSET
 * \brief The content of the physical register has been spilled to the local stack (ABI only). */

/***************************** CUDBGEventKind ****************************/

/** \enum CUDBGEventKind
    \brief CUDA Kernel Events.
    \ingroup EVENT */
/** \var CUDBGEventKind CUDBG_EVENT_INVALID
    \brief Invalid event. */
/** \var CUDBGEventKind CUDBG_EVENT_ELF_IMAGE_LOADED
    \brief The ELF image for a CUDA source module is available. */
/** \var CUDBGEventKind CUDBG_EVENT_KERNEL_READY
    \brief A CUDA kernel is about to be launched. */
/** \var CUDBGEventKind CUDBG_EVENT_INTERNAL_ERROR
    \brief An internal error occur. The debugging framework may be unstable. */
/** \var CUDBGEventKind CUDBG_EVENT_KERNEL_FINISHED
    \brief A CUDA kernel has terminated. */
/** \var CUDBGEventKind CUDBG_EVENT_CTX_PUSH
    \brief A CUDA context was pushed. */
/** \var CUDBGEventKind CUDBG_EVENT_CTX_POP
    \brief A CUDA CTX was popped. */
/** \var CUDBGEventKind CUDBG_EVENT_CTX_CREATE
    \brief A CUDA CTX was created. */
/** \var CUDBGEventKind CUDBG_EVENT_CTX_DESTROY
    \brief A CUDA context was destroyed. */
/** \var CUDBGEventKind CUDBG_EVENT_TIMEOUT
    \brief An timeout event is sent at regular interval. This event can safely ge ignored. */
/** \var CUDBGEventKind CUDBG_EVENT_ATTACH_COMPLETE
    \brief The attach process has completed and debugging of device code may start. */

/******************************* CUDBGEvent ******************************/

/** \struct CUDBGEvent
    \brief Event information container.
    \ingroup EVENT */
/** \var CUDBGEvent::kind
    \brief Event type. */
/** \var CUDBGEvent::cases
    \brief Information for each type of event. */

/** \union CUDBGEvent::cases_st */
/** \var CUDBGEvent::cases_st::elfImageLoaded
    \brief Information about the loaded ELF image. */
/** \var CUDBGEvent::cases_st::kernelReady
    \brief Information about the kernel ready to be launched. */
/** \var CUDBGEvent::cases_st::kernelFinished
    \brief Information about the kernel that just terminated. */
/** \var CUDBGEvent::cases_st::contextPush
    \brief Information about the context being pushed. */
/** \var CUDBGEvent::cases_st::contextPop
    \brief Information about the context being popped. */
/** \var CUDBGEvent::cases_st::contextCreate
    \brief Information about the context being created. */
/** \var CUDBGEvent::cases_st::contextDestroy
    \brief Information about the context being destroyed. */
/** \var CUDBGEvent::cases_st::internalError
    \brief Information about internal erros. */

/** \struct CUDBGEvent::cases_st::elfImageLoaded_st */
/** \var CUDBGEvent::cases_st::elfImageLoaded_st::relocatedElfImage
    \brief pointer to the relocated ELF image for a CUDA source module. */
/** \var CUDBGEvent::cases_st::elfImageLoaded_st::nonRelocatedElfImage
    \brief pointer to the non-relocated ELF image for a CUDA source module. */
/** \var CUDBGEvent::cases_st::elfImageLoaded_st::size32
    \brief size of the ELF image (32-bit).
    \deprecated in CUDA 4.0. */
/** \var CUDBGEvent::cases_st::elfImageLoaded_st::dev
    \brief device index of the kernel. */
/** \var CUDBGEvent::cases_st::elfImageLoaded_st::context
    \brief context of the kernel. */
/** \var CUDBGEvent::cases_st::elfImageLoaded_st::module
    \brief module of the kernel. */
/** \var CUDBGEvent::cases_st::elfImageLoaded_st::size
    \brief size of the ELF image (64-bit). */
/** \var CUDBGEvent::cases_st::elfImageLoaded_st::handle
    \brief ELF image handle */
/** \var CUDBGEvent::cases_st::elfImageLoaded_st::properties
    \brief ELF image properties */

/** \struct CUDBGEvent::cases_st::kernelReady_st */
/** \var CUDBGEvent::cases_st::kernelReady_st::dev
    \brief device index of the kernel. */
/** \var CUDBGEvent::cases_st::kernelReady_st::gridId
    \brief grid index of the kernel. */
/** \var CUDBGEvent::cases_st::kernelReady_st::tid
    \brief host thread id (or LWP id) of the thread hosting the kernel (Linux only). */
/** \var CUDBGEvent::cases_st::kernelReady_st::context
    \brief context of the kernel. */
/** \var CUDBGEvent::cases_st::kernelReady_st::module
    \brief module of the kernel. */
/** \var CUDBGEvent::cases_st::kernelReady_st::function
    \brief function of the kernel. */
/** \var CUDBGEvent::cases_st::kernelReady_st::functionEntry
    \brief entry PC of the kernel. */
/** \var CUDBGEvent::cases_st::kernelReady_st::gridDim
    \brief grid dimensions of the kernel. */
/** \var CUDBGEvent::cases_st::kernelReady_st::blockDim
    \brief block dimensions of the kernel. */
/** \var CUDBGEvent::cases_st::kernelReady_st::type
    \brief the type of the kernel: system or application. */
/** \var CUDBGEvent::cases_st::kernelReady_st::parentGridId
    \brief 64-bit grid index of the parent grid. */
/** \var CUDBGEvent::cases_st::kernelReady_st::gridId64
    \brief 64-bit grid index of the kernel. */

/** \struct CUDBGEvent::cases_st::kernelFinished_st */
/** \var CUDBGEvent::cases_st::kernelFinished_st::dev
    \brief device index of the kernel. */
/** \var CUDBGEvent::cases_st::kernelFinished_st::gridId
    \brief grid index of the kernel. */
/** \var CUDBGEvent::cases_st::kernelFinished_st::tid
    \brief host thread id (or LWP id) of the thread hosting the kernel (Linux only). */
/** \var CUDBGEvent::cases_st::kernelFinished_st::context
    \brief context of the kernel. */
/** \var CUDBGEvent::cases_st::kernelFinished_st::module
    \brief module of the kernel. */
/** \var CUDBGEvent::cases_st::kernelFinished_st::function
    \brief function of the kernel. */
/** \var CUDBGEvent::cases_st::kernelFinished_st::functionEntry
    \brief entry PC of the kernel. */
/** \var CUDBGEvent::cases_st::kernelFinished_st::gridId64
    \brief 64-bit grid index of the kernel. */

/** \struct CUDBGEvent::cases_st::contextPush_st */
/** \var CUDBGEvent::cases_st::contextPush_st::dev
    \brief device index of the context. */
/** \var CUDBGEvent::cases_st::contextPush_st::tid
    \brief host thread id (or LWP id) of the thread hosting the context (Linux only). */
/** \var CUDBGEvent::cases_st::contextPush_st::context
    \brief the context being pushed. */

/** \struct CUDBGEvent::cases_st::contextPop_st */
/** \var CUDBGEvent::cases_st::contextPop_st::dev
    \brief device index of the context. */
/** \var CUDBGEvent::cases_st::contextPop_st::tid
    \brief host thread id (or LWP id) of the thread hosting the context (Linux only). */
/** \var CUDBGEvent::cases_st::contextPop_st::context
    \brief the context being popped. */

/** \struct CUDBGEvent::cases_st::contextCreate_st */
/** \var CUDBGEvent::cases_st::contextCreate_st::dev
    \brief device index of the context. */
/** \var CUDBGEvent::cases_st::contextCreate_st::tid
    \brief host thread id (or LWP id) of the thread hosting the context (Linux only). */
/** \var CUDBGEvent::cases_st::contextCreate_st::context
    \brief the context being created. */

/** \struct CUDBGEvent::cases_st::contextDestroy_st */
/** \var CUDBGEvent::cases_st::contextDestroy_st::dev
    \brief device index of the context. */
/** \var CUDBGEvent::cases_st::contextDestroy_st::tid
    \brief host thread id (or LWP id) of the thread hosting the context (Linux only). */
/** \var CUDBGEvent::cases_st::contextDestroy_st::context
    \brief the context being destroyed. */

/** \struct CUDBGEvent::cases_st::internalError_st */
/** \var CUDBGEvent::cases_st::internalError_st::errorType
    \brief Type of the internal error. */

/****************************** Event Callback ***************************/

/** \typedef CUDBGNotifyNewEventCallback31
    \brief function type of the function called to notify debugger of the presence of a new event in the event queue.
    \deprecated in CUDA 3.2.
    \ingroup EVENT */

/** \typedef CUDBGNotifyNewEventCallback
    \brief function type of the function called to notify debugger of the presence of a new event in the event queue.
    \ingroup EVENT */

/** \struct CUDBGEventCallbackData40
    \brief Event information passed to callback set with setNotifyNewEventCallback function.
    \deprecated in CUDA 4.1.
    \ingroup EVENT */
/** \var CUDBGEventCallbackData40::tid
    \brief Host thread id of the context generating the event. Zero if not available. */

/** \struct CUDBGEventCallbackData
    \brief Event information passed to callback set with setNotifyNewEventCallback function.
    \ingroup EVENT */
/** \var CUDBGEventCallbackData::tid
    \brief Host thread id of the context generating the event. Zero if not available. */
/** \var CUDBGEventCallbackData::timeout
    \brief A boolean notifying the debugger that the debug API timed while waiting for a reponse from the debugger to a previous event.
           It is up to the debugger to decide what to do in response to a timeout. */

/******************************* Section Order ***************************/

/** \defgroup GENERAL General */
/** \defgroup INIT    Initialization */
/** \defgroup EXEC    Device Execution Control */
/** \defgroup BP      Breakpoints */
/** \defgroup READ    Device State Inspection*/
/** \defgroup WRITE   Device State Alteration */
/** \defgroup GRID    Grid Properties */
/** \defgroup DEV     Device Properties */
/** \defgroup DWARF   DWARF Utilities */

/********************************* Events ********************************/

/** \defgroup EVENT Events

One of those events will create a CUDBGEvent:
\arg the elf image of the current kernel has been loaded and the
     addresses within its DWARF sections have been relocated (and can
     now be used to set breakpoints),
\arg a device breakpoint has been hit,
\arg a CUDA kernel is ready to be launched,
\arg a CUDA kernel has terminated.

When a CUDBGEvent is created, the debugger is notified by calling the
callback functions registered with setNotifyNewEventCallback() after
the API struct initialization. It is up to the debugger to decide what
method is best to be notified. The debugger API routines cannot be
called from within the callback function or the routine will return an
error.

Upon notification the debugger is responsible for handling the
CUDBGEvents in the event queue by using CUDBGAPI_st::getNextEvent(), and for
acknowledging the debugger API that the event has been handled by
calling CUDBGAPI_st::acknowledgeEvent(). In the case of an event raised by the
device itself, such as a breakpoint being hit, the event queue will
be empty. It is the responsibility of the debugger to inspect the
hardware any time a CUDBGEvent is received.


Example:
\code
CUDBGEvent event;
CUDBGResult res;
for (res = cudbgAPI->getNextEvent(&event);
     res == CUDBG_SUCCESS && event.kind != CUDBG_EVENT_INVALID;
     res = cudbgAPI->getNextEvent(&event)) {
    switch (event.kind)
        {
        case CUDBG_EVENT_ELF_IMAGE_LOADED:
            //...
            break;
        case CUDBG_EVENT_KERNEL_READY:
            //...
            break;
        case CUDBG_EVENT_KERNEL_FINISHED:
            //...
            break;
        default:
            error(...);
        }
    }
\endcode

See cuda-tdep.c and cuda-linux-nat.c files in the cuda-gdb source code
for a more detailed example on how to use CUDBGEvent.

*/

/******************************* Grid Status ******************************/

/** \enum CUDBGGridStatus
 *  \brief Grid status.
 *  \ingroup GRID */
/** \var CUDBGGridStatus CUDBG_GRID_STATUS_INVALID
 * \brief  An invalid grid ID was passed, or an error occurred during status lookup. */
/** \var CUDBGGridStatus CUDBG_GRID_STATUS_PENDING
 * \brief  The grid was launched but is not running on the HW yet. */
/** \var CUDBGGridStatus CUDBG_GRID_STATUS_ACTIVE
 * \brief  The grid is currently running on the HW. */
/** \var CUDBGGridStatus CUDBG_GRID_STATUS_SLEEPING
 * \brief  The grid is on the device, doing a join. */
/** \var CUDBGGridStatus CUDBG_GRID_STATUS_TERMINATED
 * \brief  The grid has finished executing. */
/** \var CUDBGGridStatus CUDBG_GRID_STATUS_UNDETERMINED
 * \brief  The grid is either QUEUED or TERMINATED. */

/******************************* Grid Info *******************************/

/** \struct CUDBGGridInfo
 *  \brief Grid info.
 *  \ingroup GRID */
/** \var CUDBGGridInfo::dev
 * \brief The index of the device this grid is running on. */
/** \var CUDBGGridInfo::gridId64
 * \brief The 64-bit grid ID of this grid. */
/** \var CUDBGGridInfo::tid
 * \brief The host thread ID that launched this grid. */
/** \var CUDBGGridInfo::context
 * \brief The context this grid belongs to. */
/** \var CUDBGGridInfo::module
 * \brief The module this grid belongs to. */
/** \var CUDBGGridInfo::function
 * \brief The function corresponding to this grid. */
/** \var CUDBGGridInfo::functionEntry
 * \brief The entry address of the function corresponding to this grid. */
/** \var CUDBGGridInfo::gridDim
 * \brief The grid dimensions. */
/** \var CUDBGGridInfo::blockDim
 * \brief The block dimensions. */
/** \var CUDBGGridInfo::type
 * \brief The type of the grid. */
/** \var CUDBGGridInfo::parentGridId
 * \brief The 64-bit grid ID that launched this grid. */
/** \var CUDBGGridInfo::origin
 * \brief The origin of this grid, CPU or GPU. */

/******************************* Main Page ********************************/

/** \mainpage Introduction

This document describes the API for the set routines and data
structures available in the CUDA library to any debugger.

Starting with 3.0, the CUDA debugger API includes several major changes, of
which only few are directly visible to end-users:
\arg Performance is greatly improved, both with respect to
     interactions with the debugger and the performance of
     applications being debugged.
\arg The format of cubins has changed to ELF and, as a consequence,
     most restrictions on debug compilations have been lifted. More
     information about the new object format is included below.

The debugger API has significantly changed, reflected in the CUDA-GDB
sources.

\section API Debugger API

The CUDA Debugger API was developed with the goal of adhering to the following
principles:

\arg Policy free
\arg Explicit
\arg Axiomatic
\arg Extensible
\arg Machine oriented

Being explicit is another way of saying that we minimize the
assumptions we make. As much as possible the API reflects machine
state, not internal state.

There are two major "modes" of the devices: stopped or running. We
switch between these modes explicitly with suspendDevice and
resumeDevice, though the machine may suspend on its own accord, for
example when hitting a breakpoint.

Only when stopped, can we query the machine's state. Warp state
includes which function is it running, which block, which lanes are
valid, etc.

\section ELF ELF and DWARF

CUDA applications are compiled in ELF binary format.

DWARF device information is obtained through a CUDBGEvent of type
CUDBG_EVENT_ELF_IMAGE_LOADED. This means that the information is not available
until runtime, after the CUDA driver has loaded.

DWARF device information contains physical addresses for all
device memory regions except for code memory.  The address class field
(DW_AT_address_class) is set for all device variables, and is used to
indicate the memory segment type (ptxStorageKind).  The physical addresses must be
accessed using several segment-specific API calls:

For memory reads, see:
\arg CUDBGAPI_st::readCodeMemory()
\arg CUDBGAPI_st::readConstMemory()
\arg CUDBGAPI_st::readGenericMemory()
\arg CUDBGAPI_st::readParamMemory()
\arg CUDBGAPI_st::readSharedMemory()
\arg CUDBGAPI_st::readLocalMemory()
\arg CUDBGAPI_st::readTextureMemory()
\arg CUDBGAPI_st::readGlobalMemory()

For memory writes, see:
\arg CUDBGAPI_st::writeGenericMemory()
\arg CUDBGAPI_st::writeParamMemory()
\arg CUDBGAPI_st::writeSharedMemory()
\arg CUDBGAPI_st::writeLocalMemory()
\arg CUDBGAPI_st::writeGlobalMemory()

Access to code memory requires a virtual address. This virtual address is
embedded for all device code sections in the device ELF image. See the API
call:
\arg CUDBGAPI_st::readVirtualPC()

Here is a typical DWARF entry for a device variable located in memory:

\code
<2><321>: Abbrev Number: 18 (DW_TAG_formal_parameter)
     DW_AT_decl_file   : 27
     DW_AT_decl_line   : 5
     DW_AT_name        : res
     DW_AT_type        : <2c6>
     DW_AT_location    : 9 byte block: 3 18 0 0 0 0 0 0 0       (DW_OP_addr: 18)
     DW_AT_address_class: 7
\endcode

The above shows that variable 'res' has an address class of 7
(ptxParamStorage). Its location information shows it is located at
address 18 within the parameter memory segment.

Local variables are no longer spilled to local memory by default. The
DWARF now contains variable-to-register mapping and liveness
information for all variables.  It can be the case that variables are
spilled to local memory, and this is all contained in the DWARF
information which is ULEB128 encoded (as a DW_OP_regx stack operation
in the DW_AT_location attribute).

Here is a typical DWARF entry for a variable located in a local
register:

\code
 <3><359>: Abbrev Number: 20 (DW_TAG_variable)
     DW_AT_decl_file   : 27
     DW_AT_decl_line   : 7
     DW_AT_name        : c
     DW_AT_type        : <1aa>
     DW_AT_location    : 7 byte block: 90 b9 e2 90 b3 d6 4      (DW_OP_regx: 160631632185)
     DW_AT_address_class: 2
\endcode

This shows variable 'c' has address class 2 (ptxRegStorage) and its
location can be found by decoding the ULEB128 value, DW_OP_regx:
160631632185.  See cuda-tdep.c in the cuda-gdb source drop for
information on decoding this value and how to obtain which physical
register holds this variable during a specific device PC range. Access
to physical registers liveness information requires a 0-based physical
PC. See the API call:
\arg CUDBGAPI_st::readPC()

\section abi31 ABI Support

ABI support is handled through the following thread API calls.
\arg CUDBGAPI_st::readCallDepth()
\arg CUDBGAPI_st::readReturnAddress()
\arg CUDBGAPI_st::readVirtualReturnAddress()

The return address is not accessible on the local
stack and the API call must be used to access its value.

For more information, please refer to the ABI documentation titled "Fermi
ABI: Application Binary Interface".

\section exceptions31 Exception Reporting

Some kernel exceptions are reported as device events and accessible via the API
call:
\arg CUDBGAPI_st::readLaneException()

The reported exceptions are listed in the CUDBGException_t enum type.
Each prefix, (Device, Warp, Lane), refers to the precision of the exception.
That is, the lowest known execution unit that is responsible for the origin of
the exception. All lane errors are precise; the exact instruction and lane that
caused the error are known. Warp errors are typically within a few instructions
of where the actual error occurred, but the exact lane within the warp is not
known. On device errors, we _may_ know the _kernel_ that caused it.
Explanations about each exception type can be found in the documentation of the
struct.

Exception reporting is only supported on Fermi (sm_20 or greater).

*/
