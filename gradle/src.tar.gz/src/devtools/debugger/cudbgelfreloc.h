/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/* ELF/DWARF relocator for the CUDA Debugger */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
// __TEMP_WAR__ No stat support on HOS
#ifndef __hos__
#include <sys/stat.h>
#endif
#include "cuda_internal.h"
#include "nvelf_reader.h"
#include "nvelf.h"
#include "cudbgdriver.h"

#define SYM_NAME_LEN(s) (strlen(s) + 1)

#define ELF_REL_PREFIX     ".rel"
#define ELF_REL_PREFIX_LEN (SYM_NAME_LEN(ELF_REL_PREFIX))

#define ELF_RELA_PREFIX     ".rela"
#define ELF_RELA_PREFIX_LEN (SYM_NAME_LEN(ELF_RELA_PREFIX))

#define ELF_TEXT_PREFIX     ".text."
#define ELF_TEXT_PREFIX_LEN (SYM_NAME_LEN(ELF_TEXT_PREFIX))

cudbgElfInfo *cudbgElfXXCreateModule(elf_t image, size_t image_sz);
int cudbgElfXXDestroyModule(cudbgElfInfo *elfInfo);

int cudbgModuleUpdateSymbolByIndex(cudbgElfInfo *elfInfo, uint32_t index, uint64_t val);
int cudbgModuleUpdateFunctionSymbols(cudbgElfInfo *elfInfo, NvU32 fnSymIndex, gpudbgFunction function, uint64_t val);
int cudbgRelocateElfXXImage(elf_t elf_image, cudbgElfInfo *elfInfo);

/*
 * Follow the same method the compiler uses to switch between
 * 32-bit and 64-bit elf decoding functions.
 */
#if defined(__i386__) || defined(_M_IX86) || defined(__arm__)
#define elfXXFileHeader                elf32FileHeader
#define elfXXSectionHeader             elf32SectionHeader
#define elfXXProgramHeader             elf32ProgramHeader
#define elfXXSymbol                    elf32Symbol
#define elfXXOff                       elf32Off
#define elfXXAddr                      elf32Addr
#define elfXXRel                       elf32Rel
#define elfXXRela                      elf32Rela
#define elfXX_file_header              elf32_file_header
#define elfXX_program_header           elf32_program_header
#define elfXX_section_header           elf32_section_header
#define elfXX_named_section_header     elf32_named_section_header
#define elfXX_typed_section_header     elf32_typed_section_header
#define elfXX_offset_section_header    elf32_offset_section_header
#define elfXX_section_name             elf32_section_name
#define elfXX_symbol_name              elf32_symbol_name
#define elfXX_segment_is_loadable      elf32_segment_is_loadable
#define elfXX_segment_is_global        elf32_segment_is_global
#define elfXX_segment_matches_entry    elf32_segment_matches_entry
#define elfXX_segment_is_text          elf32_segment_is_text
#define elfXX_segment_is_data          elf32_segment_is_data
#define elfXX_get_entry_symbol_index   elf32_get_entry_symbol_index
#define elfXX_first_section_in_segment elf32_first_section_in_segment
#define elfXX_next_section_in_segment  elf32_next_section_in_segment
#define elfXX_section_is_in_segment    elf32_section_is_in_segment
#define elfXX_symbol_shndx             elf32_symbol_shndx
#define elfXX_shnum                    elf32_shnum
#define elfXX_section_contents         elf32_section_contents
#define ELFXX_R_SYM                    ELF32_R_SYM
#define ELFXX_R_TYPE                   ELF32_R_TYPE
#elif defined(_WIN64) || defined(__LP64__)
#define elfXXFileHeader                elf64FileHeader
#define elfXXSectionHeader             elf64SectionHeader
#define elfXXProgramHeader             elf64ProgramHeader
#define elfXXSymbol                    elf64Symbol
#define elfXXOff                       elf64Off
#define elfXXAddr                      elf64Addr
#define elfXXRel                       elf64Rel
#define elfXXRela                      elf64Rela
#define elfXX_file_header              elf64_file_header
#define elfXX_program_header           elf64_program_header
#define elfXX_section_header           elf64_section_header
#define elfXX_named_section_header     elf64_named_section_header
#define elfXX_typed_section_header     elf64_typed_section_header
#define elfXX_offset_section_header    elf64_offset_section_header
#define elfXX_section_name             elf64_section_name
#define elfXX_symbol_name              elf64_symbol_name
#define elfXX_segment_is_loadable      elf64_segment_is_loadable
#define elfXX_segment_is_global        elf64_segment_is_global
#define elfXX_segment_matches_entry    elf64_segment_matches_entry
#define elfXX_segment_is_text          elf64_segment_is_text
#define elfXX_segment_is_data          elf64_segment_is_data
#define elfXX_get_entry_symbol_index   elf64_get_entry_symbol_index
#define elfXX_first_section_in_segment elf64_first_section_in_segment
#define elfXX_next_section_in_segment  elf64_next_section_in_segment
#define elfXX_section_is_in_segment    elf64_section_is_in_segment
#define elfXX_symbol_shndx             elf64_symbol_shndx
#define elfXX_shnum                    elf64_shnum
#define elfXX_section_contents         elf64_section_contents
#define ELFXX_R_SYM                    ELF64_R_SYM
#define ELFXX_R_TYPE                   ELF64_R_TYPE
#else
#error "Unknown platform"
#endif


