/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef _CUDBG_UTILS_H
#define _CUDBG_UTILS_H 1

#include "cudadebugger.h"
#include "halo.h"
#include "cudbgtarget.h"
#include "halo_trace.h"

#define CUDBG_UTIL_TMP_BUF_SIZE 1024

/* Some 2.6 kernels have a bug where ERESTART_RESTARTBLOCK gets returned by
 * syscalls interrupted by a signal, instead of EINTR. */
#if cuosOsIsLinux() && !defined(ERESTART_RESTARTBLOCK)
#define ERESTART_RESTARTBLOCK 516
#endif

/*---------------------------------- Trace ----------------------------------*/

#define CUDBG_SIMULATION_TIMEOUT        1500
#define CUDBG_SIMULATION_TIMEOUT_MSEC   1500000

#if !defined(RELEASE)
#define CUDBG_TRACE_LEVEL  haloTraceLevel
#define CUDBG_TIMEOUT      15 //seconds
#define CUDBG_TIMEOUT_MSEC 15000 //milliseconds

#define CUDBG_ERROR(...) haloTrace(HALO_TRACE_DOMAIN_CUDBG, (HALO_TRACE_TYPE_FILE | HALO_TRACE_TYPE_LINE | HALO_TRACE_TYPE_FUNCTION), 0 , __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#define CUDBG_DEBUG(...) haloTrace(HALO_TRACE_DOMAIN_CUDBG, (HALO_TRACE_TYPE_FILE | HALO_TRACE_TYPE_LINE | HALO_TRACE_TYPE_FUNCTION), 10, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#define CUDBG_TRACE(...) haloTrace(HALO_TRACE_DOMAIN_CUDBG, (HALO_TRACE_TYPE_FILE | HALO_TRACE_TYPE_LINE | HALO_TRACE_TYPE_FUNCTION), 20, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#define CUDBG_PRINT(level, ...) haloTrace(HALO_TRACE_DOMAIN_CUDBG, (HALO_TRACE_TYPE_FILE | HALO_TRACE_TYPE_LINE | HALO_TRACE_TYPE_FUNCTION), level, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)

#define CUDBG_VERIFY(condition, error, ...)                                                                          \
    do {                                                                                                             \
        if (!(condition)) {                                                                                          \
            haloTrace(HALO_TRACE_DOMAIN_CUDBG, (HALO_TRACE_TYPE_FILE | HALO_TRACE_TYPE_LINE | HALO_TRACE_TYPE_FUNCTION), 0, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__); \
            return error;                                                                                            \
        } else if (cudbgShouldInjectError((CUDBGResult)error)) {                                                                  \
            haloTrace(HALO_TRACE_DOMAIN_CUDBG, (HALO_TRACE_TYPE_FILE | HALO_TRACE_TYPE_LINE | HALO_TRACE_TYPE_FUNCTION), 0, __FILE__, __LINE__, __FUNCTION__,               \
                       "Injecting error (res=%u)...\n", error);                                                      \
            haloTrace(HALO_TRACE_DOMAIN_CUDBG, (HALO_TRACE_TYPE_FILE | HALO_TRACE_TYPE_LINE | HALO_TRACE_TYPE_FUNCTION), 0, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__); \
            return error;                                                                                            \
        }                                                                                                            \
    } while (0)

#else // RELEASE

#define CUDBG_TRACE_LEVEL     -1
#define CUDBG_TIMEOUT         3 //seconds
#define CUDBG_TIMEOUT_MSEC 3000 //milliseconds

#define CUDBG_ERROR(p, ...)
#define CUDBG_DEBUG(p, ...)
#define CUDBG_TRACE(p, ...)
#define CUDBG_PRINT(p, ...)

#define CUDBG_VERIFY(condition, error, ...)                                 \
    do {                                                                    \
        if (!(condition)) {                                                 \
            return error;                                                   \
        }                                                                   \
    } while (0)

#endif // RELEASE


extern uint32_t cudbgEnableSyscallDebugging;
extern uint32_t cudbgEnableInternalDebugging;
extern uint32_t cudbgEnableMemcheckDebugging;
extern uint32_t cudbgEnableInternalInsts;
extern uint32_t cudbgEnableHiddenFunctionDebugging;
extern void cudbgUtilsInit(void);
extern void cudbgUtilsFinalize(void);
extern bool cudbgShouldInjectError(CUDBGResult res);
extern const char* cudbgGetTempPrefix(void);

/*---------------------------------- Abort ----------------------------------*/

void __abort(void);

#endif // _CUDBG_UTILS_H
