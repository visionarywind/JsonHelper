/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/*--------------------------------- Includes ---------------------------------*/
#define CU_INIT_UUID_STATIC 1
#include "../../../../compiler/gpgpu/export/cuda/tools/cudart/cudart_etbl/tools_runtime_instance.h"
#undef CU_INIT_UUID_STATIC

#include <g_nvconfig.h>

#include <cudbgdriver.h>
#include <tools_shared_hashmap.h>
#include <tools_shared_stringtable.h>
#include <errno.h>

#include <cuda_internal.h>
#include "cuda_device.h"

/* Class files for Compute */
#if NVCFG(GLOBAL_ARCH_FERMI)
#include "class/cl90c0.h"
#endif

#include "cudbgelfreloc.h"
#include "cudbgpipe.h"
#include "cudbgutils.h"
#include "cudbgapi.h"
#include "cudbgdarwin.h"

#include "rpcd/rpcd.h"

#include "cui/memblock.h"
#include "cui/dmal/rm/rm_device.h"
#include "cui/cuisyscall.h"
#include "cui/cuitraphandler.h"
#include "cui/channel_private.h"
#include "cuicnp.h"
#include "cuikilp.h"
#include "cuistream.h"
#include "cuitraphandler.h"
#include "cuisym.h"

#include "cuos.h"

#include "halo_drv.h"
#include "kdapi.h"

#include "memcheck_report.h"
#include "cudbgdriver_toolsapi.h"

#ifdef CUDBG_ENABLE_IFB
#include "rm_call.h"
#endif

#if cuosPlatformIncludesMrm()
#include "mrm_channel.h"
#include "mrm_device.h"
#endif

#include "../../../../compiler/gpgpu/export/cuda/tools/cudart/driver_types.h"
#if !cuosOsIsMods()
#include "cudbgcoredump.h"
#else
#define cudbgIsCoredumpInProgress() 0
#define cudbgCoredumpInitMessage() 0
#define cudbgCoredumpFinalizeMessage() 0
#define cudbgCoredumpResetMessage() 0
#define cudbgCoredumpPushMessage(x, y) 0
#define cudbgCoredumpSendMessage() 0
#endif
/*---------------------- Debugger System Call Interface ----------------------*/

/*
 * The names of the following are recognized by the gpu debugger:
 *
 * CUDBG_IPC_FLAG_NAME:
 *  1) Upon process attach, the debugger will set CUDBG_IPC_FLAG_NAME to a nonzero value
 *  2) The debugger will trap any call of the application to function CUDBG_IPC_CALL_NAME,
 *     and expect a message by the application in variable CUDBG_IPC_ARGS_NAME.
 *
 * CUDBG_RPC_FLAG_NAME:
 *  1) Similar to CUDBG_IPC_FLAG_NAME, this variable is written to by a debugger client to
 *     indicate that the RPC framework needs to be used.
 *
 * CUDBG_APICLIENT_PID:
 *  1) This variable is used to identify the pid of the debugger client process
 *     that is attached to this process
 *
 * CUDBG_I_AM_DEBUGGER:
 *  1) This variable is used to identify a debugger process vs. an application process
 *
 * CUDBG_APICLIENT_REVISION:
 *  1) This variable is used to identify the revision of the debugger client process.
 *  2) This flag is used only if CUDBG_RPC_ENABLED is true.
 *
 * CUDBG_SESSION_ID:
 *  1) This variable is set by the debugger to give a unique id to the current
 *     debug session to distinguish reruns of the app.
 *
 * CUDBG_REPORTED_DRIVER_API_ERROR_CODE:
 *  1) This variable is used by debugger to store the error code of last api call.
 *
 * CUDBG_REPORTED_DRIVER_API_ERROR_FUNC_NAME_SIZE:
 *  1) This variable is used by debugger to store the size of function name in which
 *     last API error occurred.
 *
 * CUDBG_REPORTED_DRIVER_API_ERROR_FUNC_NAME_ADDR:
 *  1) This variable is used by debugger to store the address of function name string
 *     in which last API error occurred.
 *
 * CUDBG_REPORTED_DRIVER_INTERNAL_ERROR_CODE:
 *  1) This variable is used to store the driver internal error codes.
 *  2) We might add some encoding to driver internal error code in the future, so that
 *     we can get more information from it (filename/line number).
 *
 * CUDBG_ATTACH_HANDLER_AVAILABLE
 *  1) If the intHandler thread is available in the cuda driver at the point when
 *     cuda-gdb attaches to a CUDA app, this variable is set to 1. cuda-gdb uses the
 *     value of this variable to decide if it should resume the app to allow the
 *     intHandler thread to collect CUDA state.
 *
 * CUDBG_DETACH_SUSPENDED_DEVICES_MASK
 *  1) This variable is updated by the debug client before detaching, to indicate
 *     which GPUs are suspended. This is needed because the app process does not
 *     have this information, only RPCD does.
 *
 * CUDBG_ENABLE_LAUNCH_BLOCKING
 *  1) This variable is set by a debugger client to ensure that all launches
 *     will be blocking
 *
 * CUDBG_ENABLE_INTEGRATED_MEMCHECK
 *  1) This variable is set by a debugger client to enable integrated cuda-memcheck
 *
 * CUDBG_ENABLE_PREEMPTION_DEBUGGING
 *  1) This variable is set by a debugger client to enable preemption-style debugging
 *     (single-gpu debugging).
 *  2) This variable only takes effect on devices with sm_35 compute capability and
 *     beyond.
 *
 * CUDBG_RESUME_FOR_ATTACH_DETACH
 *  1) This variable is set as a side effect of the cudbgApiAttach/cudbgApiDetach calls.
 *  2) This variable is set to non zero if the app must be resumed as part of the
 *     attach/detach procedure
 *
 * CUDBG_REPORT_DRIVER_API_ERROR_FLAGS
 *  1) This variable is set by a debugger client to change the behavior of API error reporting
 *  2) This variable can be changed any time the client has frozen the application
 */
uint32_t CUDBG_IPC_FLAG_NAME;
uint32_t CUDBG_RPC_ENABLED;
uint32_t CUDBG_APICLIENT_PID;
uint32_t CUDBG_I_AM_DEBUGGER = 0;
uint32_t CUDBG_DEBUGGER_INITIALIZED = 0;
uint32_t CUDBG_APICLIENT_REVISION;
uint32_t CUDBG_SESSION_ID;
uint64_t CUDBG_REPORTED_DRIVER_API_ERROR_CODE;
uint64_t CUDBG_REPORTED_DRIVER_API_ERROR_FUNC_NAME_SIZE;
uint64_t CUDBG_REPORTED_DRIVER_API_ERROR_FUNC_NAME_ADDR;
uint64_t CUDBG_REPORTED_DRIVER_INTERNAL_ERROR_CODE;
uint32_t CUDBG_ATTACH_HANDLER_AVAILABLE = 0;
uint32_t CUDBG_DETACH_SUSPENDED_DEVICES_MASK = 0;
uint32_t CUDBG_ENABLE_LAUNCH_BLOCKING = 0;
uint32_t CUDBG_ENABLE_INTEGRATED_MEMCHECK = 0;
uint32_t CUDBG_ENABLE_PREEMPTION_DEBUGGING = 0;
uint32_t CUDBG_RESUME_FOR_ATTACH_DETACH = 0;
uint32_t CUDBG_REPORT_DRIVER_API_ERROR_FLAGS = CUDBG_REPORT_DRIVER_API_ERROR_FLAGS_NONE;
uint32_t CUDBG_GET_SESSION_FROM_ENV = 0;
path_char_t cudbgInjectionPath[CUDBG_INJECTION_PATH_SIZE];

void (*cudbgReportDriverApiErrorPtr)(void) = &CUDBG_REPORT_DRIVER_API_ERROR;
void (*cudbgReportDriverInternalErrorPtr)(void) = &CUDBG_REPORT_DRIVER_INTERNAL_ERROR;

static uint32_t cudbgReportDriverApiErrorCount;
static uint32_t cudbgReportDriverInternalErrorCount;

static bool cudbgDriverOptionsInitialized = false;
CudbgDriverOptions cudbgDriverOptions = {0};
bool cudbgDriverOptionsChanged = true;

static cuosOnceControl cudbgSessionEnv = CUOS_ONCE_INIT;
static tHashMap *cudbgPatchRamMap = NULL;
static tHashMap *cudbgGlobalFocusCoordsMap = NULL;

/*--------------------------- Forward Declarations ---------------------------*/
static void cudbgRegisterModuleAndFunctions(CUctx *ctx, CUmod *mod, CUmodule *phMod, const char *fb_ident, char *cubin);
static void createPatchMessage(CUDBGcommand *message, void *cuctx,
                               uint32_t kind, uint64_t devvaddr,
                               uint64_t gpuPCOffset, uint32_t patchSize,
                               uint64_t patchEntryAddr, bool isMultiEntry,
                               uint64_t* origInst, uint32_t instSz,
                               uint32_t depth);
static inline CUDBGResult initMessage(void);
static inline CUDBGResult resetMessage(void);
static inline CUDBGResult finiMessage(void);
static CUDBGResult pushMessage(void *obj, uint64_t size);
static CUDBGResult pushControlMessage(void *obj, uint64_t size);
static CUDBGResult sendMessage(void);
static CUDBGResult sendDetachCompletion(void);
static void destroyCode(uint64_t *code);
static void cudbgSetDebuggerAttachState(bool attachInProgress);
static bool cudbgIsDebuggerAttachInProgress(void);
static void cudbgReportAllMemblocks_underLock(CUctx *ctx);
static void resetPipeState(CUDBGAttachState attachState);
static void cudbgResetFrontendResumeFlag(void);
static uint32_t cudbgUpdateFrontendResumeFlag(void);

/* used by dotS patches */
typedef struct SsyInstr_t {
    uint32_t offset;
    uint64_t instr;
    uint32_t target;
    struct SsyInstr_t *next;
} SsyInstr;

/* attach state */
static int cudbgAttachInProgress;
static cuosEvent debuggerDetachEvent = {0};
static bool debuggerDetachEventValid = false;
static bool cudbgAttachStubInUse;

#ifdef CUDBG_ENABLE_IFB
static uint32_t cudbgIfbHandle;
#endif

typedef enum {
    CUDBG_DETACH_FLAG_READY = 0,
    CUDBG_DETACH_FLAG_BUSY  = 1,
    CUDBG_DETACH_FLAG_BEGIN_SIGNAL  = 2,
    CUDBG_DETACH_FLAG_BEGIN_NOSIGNAL = 3,
    CUDBG_DETACH_FLAG_DONE  = 4,
} CUDBGDetachFlag;

static volatile uint32_t cudbgDetachFlag = CUDBG_DETACH_FLAG_READY;

/* The ID of the session when the callback was first subscribed
 * This is used to drop callbacks that may have originated
 * in a different session.
 */
static uint32_t cudbgClientSessionId = 0;

/* */
static volatile uint32_t cudbgToolsApiState = CUDBG_APP_TOOLS_API_STATE_READY;

/*------------------------------ Global Lock ---------------------------------*/

/*
  Function calls from the driver are to be protected by a lock. Following the
   driver's policy, per-context calls do not require a lock though. Any shared
   data between contexts or kernels do. So far the list of objects to protect
   includes: calls to pushMessage (only one user of the pipe at a time).

   These macros need to be robust in the case of detach. The full explanation is
   on bug 1361189, but practically the pipe mechanism needs to be robust to
   receiving a detach while threads are sending a message

*/

#define CUDBG_ENTERCS(id) do {                                                                  \
            uint32_t oldDetachFlag;                                                             \
            goto CUDBG_ENTERCS_DUMMY_LABEL_##id;                                                \
        CUDBG_ENTERCS_DUMMY_LABEL_##id:                                                         \
            cuosEnterCriticalSection(&globals.debugger_cs);                                     \
            oldDetachFlag = cuosInterlockedCompareExchange(&cudbgDetachFlag,                    \
                                                           CUDBG_DETACH_FLAG_BUSY,              \
                                                           CUDBG_DETACH_FLAG_READY);            \
            if (oldDetachFlag != CUDBG_DETACH_FLAG_READY)                                       \
                goto CUDBG_LEAVECS_SKIP_LABEL_##id;                                             \
        } while (0)

#define CUDBG_LEAVECS(id) do {                                                                  \
            uint32_t oldDetachFlag;                                                             \
        CUDBG_LEAVECS_SKIP_LABEL_##id:                                                          \
            oldDetachFlag = cuosInterlockedCompareExchange(&cudbgDetachFlag,                    \
                                                           CUDBG_DETACH_FLAG_READY,             \
                                                           CUDBG_DETACH_FLAG_BUSY);             \
            if (oldDetachFlag == CUDBG_DETACH_FLAG_BEGIN_SIGNAL) {                              \
                sendDetachCompletion();                                                         \
                cudbgDetachFlag = CUDBG_DETACH_FLAG_DONE;                                       \
            } else if (oldDetachFlag == CUDBG_DETACH_FLAG_BEGIN_NOSIGNAL)                       \
                cudbgDetachFlag = CUDBG_DETACH_FLAG_DONE;                                       \
            cuosLeaveCriticalSection(&globals.debugger_cs);                                     \
        } while (0)

/* Jump to the end of a critical section immediately */
#define CUDBG_BREAKCS(id) goto CUDBG_LEAVECS_SKIP_LABEL_##id


/*-------------------------------- Communications ---------------------------------*/

static cudbg_pipe_t applicationToDispatcher;
static cudbg_pipe_t dispatcherToApplication;

static inline CUDBGResult
initMessage(void)
{
    CUDBGResult res;
    cudbg_pipe_type_t applicationToDispatcherPipeType;

    if (cudbgIsCoredumpInProgress()) {
        return cudbgCoredumpInitMessage();
    }

    /* On ARM, fd's for nvhost, nvmap etc. need to be transferred
       from the application to the debugger process. This requires the
       use of Unix domain sockets. */
    if (cuosOsIsLinux() || cuosOsIsQnx())
        applicationToDispatcherPipeType = CUDBG_PIPE_TYPE_UDS_WRITE;
    else
        applicationToDispatcherPipeType = CUDBG_PIPE_TYPE_NAMED_WRITE;

    /* initialize write pipe */
    if (applicationToDispatcher.type == CUDBG_PIPE_TYPE_NONE) {
        res = cudbgPipeInitialize(&applicationToDispatcher,
                                  applicationToDispatcherPipeType,
                                  CUDBG_PIPE_ENDPOINT_APPLICATION,
                                  CUDBG_PIPE_ENDPOINT_DISPATCHER);
        if (res != CUDBG_SUCCESS)
            return res;
    }

    /* initialize ack pipe */
    if (dispatcherToApplication.type == CUDBG_PIPE_TYPE_NONE) {
        res = cudbgPipeInitialize(&dispatcherToApplication,
                                  CUDBG_PIPE_TYPE_NAMED_READ,
                                  CUDBG_PIPE_ENDPOINT_DISPATCHER,
                                  CUDBG_PIPE_ENDPOINT_APPLICATION);
        if (res != CUDBG_SUCCESS)
            return res;
    }

    return CUDBG_SUCCESS;
}

static inline CUDBGResult
finiMessage(void)
{
    CUDBGResult res;

    if (cudbgIsCoredumpInProgress()) {
        return cudbgCoredumpFinalizeMessage();
    }

    /* finalize write pipe */
    if (applicationToDispatcher.type != CUDBG_PIPE_TYPE_NONE) {
        res = cudbgPipeFinalize(&applicationToDispatcher);
        if (res != CUDBG_SUCCESS)
            return res;
    }

    /* finalize ack pipe */
    if (dispatcherToApplication.type != CUDBG_PIPE_TYPE_NONE) {
        res = cudbgPipeFinalize(&dispatcherToApplication);
        if (res != CUDBG_SUCCESS)
            return res;
    }

    return CUDBG_SUCCESS;
}

static inline CUDBGResult
resetMessage(void)
{
    CUDBGResult res;

    if (cudbgIsCoredumpInProgress()) {
        return cudbgCoredumpResetMessage();
    }

    /* reset write pipe */
    if (applicationToDispatcher.type != CUDBG_PIPE_TYPE_NONE) {
        res = cudbgPipeReset(&applicationToDispatcher);
        if (res != CUDBG_SUCCESS)
            return res;
    }

    /* reset ack pipe */
    if (dispatcherToApplication.type != CUDBG_PIPE_TYPE_NONE) {
        res = cudbgPipeReset(&dispatcherToApplication);
        if (res != CUDBG_SUCCESS)
            return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
pushMessage(void *obj, uint64_t objSize)
{
    CUDBGResult res;

    /* if nothing to push, don't bother */
    if (!obj || !objSize)
        return CUDBG_SUCCESS;

    /* initialize if not already done */
    res = initMessage();
    if (res != CUDBG_SUCCESS)
        return res;

    if (cudbgIsCoredumpInProgress()) {
        return cudbgCoredumpPushMessage(obj, objSize);
    }

    /* append object to the message to be sent to the dispatcher thread */
    res = cudbgPipeMessageAppend(&applicationToDispatcher, obj, objSize);

    return res;
}

static CUDBGResult
pushControlMessage(void *obj, uint64_t objSize)
{
    CUDBGResult res;

    /* if nothing to push, don't bother */
    if (!obj || !objSize)
        return CUDBG_SUCCESS;

    /* initialize if not already done */
    res = initMessage();
    if (res != CUDBG_SUCCESS)
        return res;

    /* no pipes used when generating a coredump, so this is a simple push */
    if (cudbgIsCoredumpInProgress()) {
        return cudbgCoredumpPushMessage(obj, objSize);
    }

    /* append object to the message to be sent to the dispatcher thread */
    res = cudbgPipeControlMessageAppend(&applicationToDispatcher, obj, objSize);

    return res;
}

static CUDBGResult
sendMessage(void)
{
    CUDBGResult res;
    uint32_t ack;
    bool eof = false;

    /* initialize if not already done */
    res = initMessage();
    if (res != CUDBG_SUCCESS)
        return res;

    if (cudbgIsCoredumpInProgress()) {
        return cudbgCoredumpSendMessage();
    }

    /* send the message */
    res = cudbgPipeMessageSend(&applicationToDispatcher);
    if (res != CUDBG_SUCCESS)
        return res;

    /* wait for the ack */
    res = cudbgPipeWaitForData(&dispatcherToApplication, NULL);
    if (res != CUDBG_SUCCESS)
        return res;

    /* read the ack */
    res = cudbgPipeBlockingRead(&dispatcherToApplication, (char*)&ack, sizeof(ack), &eof);
    if (res != CUDBG_SUCCESS)
        return res;

    /* If ack > 1, then the pipe also contains some CudbgDriverOptions
       updates. The ack == 1 mechanism (or 0xdeadbeef) must stay in place to
       support 3.2 releases and earlier which did not have CudbgDriverOptions
       yet. */
    if (ack != 1 && ack != 0xdeadbeef) {
        res = cudbgPipeBlockingRead(&dispatcherToApplication,
                                    (char*)&cudbgDriverOptions,
                                    sizeof(cudbgDriverOptions),
                                    &eof);
        if (res != CUDBG_SUCCESS)
            return res;
        CUDBG_TRACE("Client option : blocking launches = %u\n",
                    cudbgDriverOptions.launchBlocking);
        CUDBG_TRACE("Client option : can pin existing memory = %u\n",
                    cudbgDriverOptions.canPinExistingMemory);
    }

    return CUDBG_SUCCESS;
}

/* Send a message to the backend to signal the completion of all pending
   callbacks. */
static CUDBGResult
sendDetachCompletion(void)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CUDBGcommand message;

    message.kind = dbgDetachComplete;

    pushMessage(&message, sizeof message);

    /* Send the message, don't wait for an ack */
    res = cudbgPipeMessageSend(&applicationToDispatcher);

    return res;
}

/*---------------------------------------------------------------------------------*/
uint32_t
gpudbgGetClientSessionId(void)
{
    return cudbgClientSessionId;
}

static void
gpudbgIncrementClientSessionId(void)
{
    (void)cuosInterlockedIncrement((volatile unsigned int*)&cudbgClientSessionId);
}

static void
detachFlagReset(void)
{
    cudbgDetachFlag = CUDBG_DETACH_FLAG_READY;
}

static void
detachFlagSetDetachBeginSignal(void)
{
    cudbgDetachFlag = CUDBG_DETACH_FLAG_BEGIN_SIGNAL;
}

static void
detachFlagSetDetachBeginNosignal(void)
{
    cudbgDetachFlag = CUDBG_DETACH_FLAG_BEGIN_NOSIGNAL;
}

static void
detachFlagSetDetachDone(void)
{
    cudbgDetachFlag = CUDBG_DETACH_FLAG_DONE;
}

static void
resetPipeState(CUDBGAttachState attachState)
{
    detachFlagReset();

    if (attachState != CUDBG_STATE_NOT_ATTACHING) {

        /* Increment the session Id */
        gpudbgIncrementClientSessionId();

        /* The pipes may be stale from a previous attach + detach, refresh them. */
        resetMessage();
    }
}

static uint32_t
cudbgUpdateFrontendResumeFlag(void)
{
    CUDBG_RESUME_FOR_ATTACH_DETACH = CUDBG_APP_RESUME_REASON_NONE;

    /* The backend uses these flags to decide whether to signal the detach
     * event or not. */
    if (CUDBG_ATTACH_HANDLER_AVAILABLE != 0)
        CUDBG_RESUME_FOR_ATTACH_DETACH |= CUDBG_APP_RESUME_REASON_INTHANDLER;

    if (cudbgDetachFlag == CUDBG_DETACH_FLAG_BEGIN_SIGNAL||
        cudbgDetachFlag == CUDBG_DETACH_FLAG_BEGIN_NOSIGNAL)
        CUDBG_RESUME_FOR_ATTACH_DETACH |= CUDBG_APP_RESUME_REASON_SEND_MESSAGE;

    if (cudbgToolsApiState == CUDBG_APP_TOOLS_API_STATE_WAITING ||
        cudbgToolsApiState == CUDBG_APP_TOOLS_API_STATE_NOTIFY_DETACH)
        CUDBG_RESUME_FOR_ATTACH_DETACH |= CUDBG_APP_RESUME_REASON_TOOLSAPI;

    return CUDBG_RESUME_FOR_ATTACH_DETACH;
}

static bool
cudbgIsAttachDetachHandlerAvailable(void)
{
    return (CUDBG_ATTACH_HANDLER_AVAILABLE != 0);
}

#if cuosOsIsWindows()
static
ULONG_PTR cudbgGetParentPid(HANDLE hProcess)
{
    /* Source: https://docs.microsoft.com/en-us/windows/desktop/api/winternl/nf-winternl-ntqueryinformationprocess
       This is an undocumented feature, but it was present in modern Windows systems for a long time. */
    ULONG_PTR processInfo[6];
    ULONG size = 0;
    LONG (WINAPI *NtQueryInformationProcess)(HANDLE, ULONG, PVOID, ULONG, PULONG);
    *(FARPROC *)&NtQueryInformationProcess = GetProcAddress(LoadLibraryA("NTDLL.DLL"), "NtQueryInformationProcess");
    if (NtQueryInformationProcess) {
        if (NtQueryInformationProcess(hProcess, 0, &processInfo, sizeof(processInfo), &size) >= 0) {
            if (size == sizeof(processInfo)) {
                return processInfo[5];
            }
        }
    }
    return (ULONG_PTR)-1;
}

/* This is a WAR for inability to use a direct memory write method of debugger enablement on Windows.
     1. If CUDBG_EXECUTABLE_PATH is not set, consider this process debuggable (for compatibility with older tools).
     2. If process executable path doesn't match the specified one, do not debug it.
     3. If process executable path matches, check all parent processes to avoid cases
        where child processes are instantiated from the same image, in which case we want to debug the parent.
     4. The parents check should end early in most situations since we don't have the rights
        to query information of system processes. This is fine for our purposes and we end the search. */
#define MAX_UNICODE_PATH_LENGTH 32767
static bool
cudbgShouldDebugThisProcess() {
    /* Max filename length on Windows is slightly less than MAX_PATH */
    wchar_t executableName[MAX_PATH];
    wchar_t imageFilePath[MAX_UNICODE_PATH_LENGTH];
    wchar_t *pImageFileName = NULL;
    DWORD size;
    DWORD result;
    HANDLE hProcess = NULL;
    /* True by default since in case of any errors it's safer to assume the process is debuggable */
    bool allowDebuggingThisProcess = true;

    result = GetEnvironmentVariableW(L"CUDBG_EXECUTABLE_NAME", executableName, MAX_UNICODE_PATH_LENGTH);
    if (result == 0 || result > MAX_UNICODE_PATH_LENGTH) {
        /* If env var is not defined or doesn't fit into the buffer,
           allow debugging this process to avoid false negatives. */
        goto exit;
    }
    _wcsupr(executableName);

    hProcess = GetCurrentProcess();
    size = MAX_UNICODE_PATH_LENGTH;
    if (!QueryFullProcessImageNameW(hProcess, 0, imageFilePath, &size)) {
        goto exit;
    }
    pImageFileName = wcsrchr(imageFilePath, L'\\');
    if (!pImageFileName) {
        goto exit;
    }
    _wcsupr(++pImageFileName);

    if (wcscmp(executableName, pImageFileName) != 0) {
        allowDebuggingThisProcess = false;
        goto exit;
    }

    for (DWORD parentPid = (DWORD)cudbgGetParentPid(hProcess); parentPid != (DWORD)-1; parentPid = (DWORD)cudbgGetParentPid(hProcess)) {
        CloseHandle(hProcess);
        hProcess = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, parentPid);
        if (!hProcess) {
            goto exit;
        }

        size = MAX_UNICODE_PATH_LENGTH;
        if (!QueryFullProcessImageNameW(hProcess, 0, imageFilePath, &size)) {
            goto exit;
        }
        pImageFileName = wcsrchr(imageFilePath, L'\\');
        if (!pImageFileName) {
            goto exit;
        }
        _wcsupr(++pImageFileName);

        if (wcscmp(executableName, pImageFileName) == 0) {
            allowDebuggingThisProcess = false;
            goto exit;
        }
    }

exit:
    if (hProcess) {
        CloseHandle(hProcess);
    }
    return allowDebuggingThisProcess;
}
#undef MAX_UNICODE_PATH_LENGTH
#endif

static void
initSessionEnvironment(void)
{
    char envVar[CUOS_ENV_VAR_LENGTH] = {0};
    if (!cuosGetEnv("CUDBG_GET_SESSION_FROM_ENV", envVar, sizeof(envVar))) {
        CUDBG_GET_SESSION_FROM_ENV = atoi(envVar);
    }
#if cuosOsIsWindows()
    /* Until unified debugger supports setting these via memory writes,
       there will be an issue where child processes spawned by the target
       would connect to the debug agent first (if they use CUDA).
       As a WAR verify that this process is the one we want to debug. */
    if (CUDBG_GET_SESSION_FROM_ENV) {
        if (!cudbgShouldDebugThisProcess()) {
            CUDBG_GET_SESSION_FROM_ENV = 0;
            /* If we don't want to debug this process, don't debug its children either. */
            cuosSetEnv("CUDBG_GET_SESSION_FROM_ENV", "0");
        }
    }
#endif
    /* C: Stop gap for unified debugger.  The session information will be setup
       before execution via environment variables rather than direct memory
       writes to exported symbols.  This means we can't support late-attach
       short term. */
    if (CUDBG_GET_SESSION_FROM_ENV) {
        if (!cuosGetEnv("CUDBG_IPC_FLAG_NAME", envVar, sizeof(envVar))) {
            CUDBG_IPC_FLAG_NAME = atoi(envVar);
        }
        if (!cuosGetEnv("CUDBG_APICLIENT_PID", envVar, sizeof(envVar))) {
            CUDBG_APICLIENT_PID = atoi(envVar);
        }
        if (!cuosGetEnv("CUDBG_SESSION_ID", envVar, sizeof(envVar))) {
            CUDBG_SESSION_ID = atoi(envVar);
        }
        if (!cuosGetEnv("CUDBG_APICLIENT_REVISION", envVar, sizeof(envVar))) {
            CUDBG_APICLIENT_REVISION = atoi(envVar);
        }
        /* Don't propagate to children created after this point in time,
           otherwise they will wait for 30s on each reportable CUDA event */
        cuosSetEnv("CUDBG_GET_SESSION_FROM_ENV", "0");
    }
}

/*---------------------------------------------------------------------------------*/

NvBool gpudbgDebuggerAttached(void)
{
    cuosOnce(&cudbgSessionEnv, initSessionEnvironment);
    return (CUDBG_IPC_FLAG_NAME ? NV_TRUE : NV_FALSE);
}

NvBool gpudbgDebuggerNeedsRPC(void)
{
    return (CUDBG_RPC_ENABLED ? NV_TRUE : NV_FALSE);
}

NvBool gpudbgDebuggerProcess(void)
{
    return (CUDBG_I_AM_DEBUGGER ? NV_TRUE : NV_FALSE);
}

uint32_t gpudbgGetApiClientPid(void)
{
    return CUDBG_APICLIENT_PID;
}

NvBool gpudbgDebuggerEnableIntegratedMemcheck(void)
{
    return (CUDBG_ENABLE_INTEGRATED_MEMCHECK ? NV_TRUE : NV_FALSE);
}

NvBool gpudbgDebuggerEnablePreemptionDebugging(void)
{
    return (CUDBG_ENABLE_PREEMPTION_DEBUGGING ? NV_TRUE : NV_FALSE);
}

void gpudbgTryLoadInjectedLibrary(void)
{
    if (cudbgInjectionPath[0] != 0) {
        cudbgInjectionPath[CUDBG_INJECTION_PATH_SIZE - 1] = 0;
        toolsLoadInjectionLibraryCore(cudbgInjectionPath);
    }
}

static cuosOnceControl cudbgInitLockOnce = CUOS_ONCE_INIT;
static CUOSCriticalSection cudbgInitLock;

extern char cudbgTrampolineBinary[];
extern const unsigned int cudbgTrampolineBinarySize;

#define RPCD_ARGS_MAX_LENGTH 256
enum rpcdArgIndices {
    RPCD_ARGS_PROGRAM_NAME = 0,
    RPCD_ARGS_APICLIENT_PID,
    RPCD_ARGS_APICLIENT_REVISION,
    RPCD_ARGS_SESSION_ID,
    RPCD_ARGS_ATTACH_STATE,
    RPCD_ARGS_ATTACH_EVENT_P,
    RPCD_ARGS_ATTACH_EVENT_FD,
    RPCD_ARGS_DETACH_EVENT_FD,
    RPCD_ARGS_ATTACH_STUB_IN_USE,
    RPCD_ARGS_PREEMPTION,
    RPCD_ARGS_NUM_ARGS
};

char rpcdExecArgs[RPCD_ARGS_NUM_ARGS][RPCD_ARGS_MAX_LENGTH];

#define CUDBG_DRV_TMP_BUF_SIZE 256

static int
cudbgDoFork(void)
{
#if !cuosOsIsHos() && (cuosOsIsApple() || cuosOsIsLinux() || cuosOsIsQnx())
    int pid;
    cuosTimer timer;

    cuosResetTimer(&timer);
    do {
#if !defined(SYS_fork)
        pid = fork();
#else
        pid = syscall(SYS_fork);
#endif
    /* Keep trying until we error or we eventually give up */
    } while((pid < 0 && errno == EAGAIN) || cuosGetTimer(&timer) > CUDBG_TIMEOUT_MSEC);

    return pid;
#else
    return -1;
#endif
}

static void
getTrampolineName(CUDBGAttachState attachState, char *trampolineName, size_t size)
{
    /* For backward compatibility reasons cudbgGetTempPrefix returns the full string
       (including all trailing slashes) for the temporary directory. As a result,
       having an extra slash forces the backend to try to create cudbgProcess inside
       a nonexistant directory when running with the 4.0 toolkit. */
    if (attachState == CUDBG_STATE_ATTACHING_VIA_STUB) {
        snprintf(trampolineName, CUDBG_DRV_TMP_BUF_SIZE, "%scudbgstub",
                 cudbgGetTempPrefix());
    }
    else
        snprintf(trampolineName, CUDBG_DRV_TMP_BUF_SIZE, "%scudbgprocess",
                 cudbgGetTempPrefix());
}

/* This function returns only when an error occurs.

    If the environment variable CUDBG_USE_LAUNCHER_SCRIPT is set, the
    backend is launched with the given script name. This path is only
    taken on platforms that call exec().

    The wrapper is expected to be a bash script of the form :

    #!/bin/bash
    valgrind --tool=memcheck $@
*/
static CUDBGResult
cudbgDoExec(CUDBGAttachState attachState)
{
#if !(cuosOsIsWindows() || cuosOsIsHos())
#if !cuosOsIsAndroid()
    int ret;
    char trampolineName[CUDBG_DRV_TMP_BUF_SIZE];
    int oldFdflags;
    char launcherName[CUDBG_DRV_TMP_BUF_SIZE];
    int useLauncherScript = 0;

    getTrampolineName(attachState, trampolineName, sizeof(trampolineName));

#ifndef RELEASE
    if (!cuosGetEnv("CUDBG_USE_LAUNCHER_SCRIPT", launcherName, sizeof(launcherName))) {
        useLauncherScript = 1;
    }
#endif

    if (!useLauncherScript)
        memcpy(launcherName, trampolineName, sizeof(trampolineName));

#if !cuosOsIsApple()
    if (-1 == (oldFdflags = fcntl(debuggerDetachEvent.writeFd, F_GETFD)) ||
        -1 == fcntl(debuggerDetachEvent.writeFd, F_SETFD, oldFdflags & ~FD_CLOEXEC)) {
        CUDBG_ERROR("Failed to prevent detach descriptor from closing on exec\n");
        return CUDBG_ERROR_OS_RESOURCES;
    }

    /* Check to see if an fd exists before modifying flags */
    if (CUDBG_ATTACH_HANDLER_AVAILABLE) {
        if (-1 == (oldFdflags = fcntl(globals.debuggerAttachEvent.writeFd, F_GETFD)) ||
            -1 == fcntl(globals.debuggerAttachEvent.writeFd, F_SETFD, oldFdflags & ~FD_CLOEXEC)) {
            CUDBG_ERROR("Failed to prevent attach descriptor from closing on exec\n");
            return CUDBG_ERROR_OS_RESOURCES;
        }
    }
#endif

    snprintf(rpcdExecArgs[RPCD_ARGS_PROGRAM_NAME],       RPCD_ARGS_MAX_LENGTH, "%s", trampolineName);
    snprintf(rpcdExecArgs[RPCD_ARGS_APICLIENT_PID],      RPCD_ARGS_MAX_LENGTH, "%d", (int)CUDBG_APICLIENT_PID);
    snprintf(rpcdExecArgs[RPCD_ARGS_APICLIENT_REVISION], RPCD_ARGS_MAX_LENGTH, "%d", (int)CUDBG_APICLIENT_REVISION);
    snprintf(rpcdExecArgs[RPCD_ARGS_SESSION_ID],         RPCD_ARGS_MAX_LENGTH, "%d", (int)CUDBG_SESSION_ID);
    snprintf(rpcdExecArgs[RPCD_ARGS_ATTACH_STATE],       RPCD_ARGS_MAX_LENGTH, "%d", (int)attachState);
    snprintf(rpcdExecArgs[RPCD_ARGS_ATTACH_EVENT_P],     RPCD_ARGS_MAX_LENGTH, "%d", (int)CUDBG_ATTACH_HANDLER_AVAILABLE);
#if !cuosOsIsApple()
    snprintf(rpcdExecArgs[RPCD_ARGS_ATTACH_EVENT_FD],    RPCD_ARGS_MAX_LENGTH, "%d", (int)(globals.debuggerAttachEvent.writeFd));
    snprintf(rpcdExecArgs[RPCD_ARGS_DETACH_EVENT_FD],    RPCD_ARGS_MAX_LENGTH, "%d", (int)(debuggerDetachEvent.writeFd));
#else
    snprintf(rpcdExecArgs[RPCD_ARGS_ATTACH_EVENT_FD],    RPCD_ARGS_MAX_LENGTH, "-1");
    snprintf(rpcdExecArgs[RPCD_ARGS_DETACH_EVENT_FD],    RPCD_ARGS_MAX_LENGTH, "-1");
#endif
    snprintf(rpcdExecArgs[RPCD_ARGS_ATTACH_STUB_IN_USE], RPCD_ARGS_MAX_LENGTH, "%d", (int)(cudbgAttachStubInUse));
    snprintf(rpcdExecArgs[RPCD_ARGS_PREEMPTION],         RPCD_ARGS_MAX_LENGTH, "%d", (int)(CUDBG_ENABLE_PREEMPTION_DEBUGGING));

    /*  When launching under the valgrind wrapper, arg[0] must be the launcher name */
    if (useLauncherScript) {
        ret = execl(launcherName,
                    launcherName,
                    rpcdExecArgs[RPCD_ARGS_PROGRAM_NAME],
                    rpcdExecArgs[RPCD_ARGS_APICLIENT_PID],
                    rpcdExecArgs[RPCD_ARGS_APICLIENT_REVISION],
                    rpcdExecArgs[RPCD_ARGS_SESSION_ID],
                    rpcdExecArgs[RPCD_ARGS_ATTACH_STATE],
                    rpcdExecArgs[RPCD_ARGS_ATTACH_EVENT_P],
                    rpcdExecArgs[RPCD_ARGS_ATTACH_EVENT_FD],
                    rpcdExecArgs[RPCD_ARGS_DETACH_EVENT_FD],
                    rpcdExecArgs[RPCD_ARGS_ATTACH_STUB_IN_USE],
                    rpcdExecArgs[RPCD_ARGS_PREEMPTION],
                    (void*) 0);
    }
    else {
        ret = execl(launcherName,
                    rpcdExecArgs[RPCD_ARGS_PROGRAM_NAME],
                    rpcdExecArgs[RPCD_ARGS_APICLIENT_PID],
                    rpcdExecArgs[RPCD_ARGS_APICLIENT_REVISION],
                    rpcdExecArgs[RPCD_ARGS_SESSION_ID],
                    rpcdExecArgs[RPCD_ARGS_ATTACH_STATE],
                    rpcdExecArgs[RPCD_ARGS_ATTACH_EVENT_P],
                    rpcdExecArgs[RPCD_ARGS_ATTACH_EVENT_FD],
                    rpcdExecArgs[RPCD_ARGS_DETACH_EVENT_FD],
                    rpcdExecArgs[RPCD_ARGS_ATTACH_STUB_IN_USE],
                    rpcdExecArgs[RPCD_ARGS_PREEMPTION],
                    (void*) 0);
    }

    if (ret != 0)
        return CUDBG_ERROR_OS_RESOURCES;

    /* This should be unreachable. */
    _exit(1);
#else

    /* Android doesn't use most arguments to cudbgMain, since it does not exec yet */
    if (cudbgMain(CUDBG_APICLIENT_PID, CUDBG_APICLIENT_REVISION, CUDBG_SESSION_ID,
                  attachState, CUDBG_ATTACH_HANDLER_AVAILABLE, 0, 0, 0, 0) != CUDBG_SUCCESS) {
        CUDBG_ERROR("Error with rpcd!\n");
        CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C,
                                          CUDBG_ERROR_INTERNAL,
                                          CUDBG_ERROR_TYPE_CUDBG);
        _exit(1);
    }

    /* Exit cleanly */
    _exit(0);
#endif
#endif

    return CUDBG_SUCCESS;
}

static CUDBGResult
cudbgSetupTrampoline(CUDBGAttachState attachState)
{
#if !cuosOsIsAndroid() && !cuosOsIsWindows() && !cuosOsIsHos()
    char trampolineName[CUDBG_DRV_TMP_BUF_SIZE];
    int trampolineBinary;
    unsigned int bytesWritten;

    getTrampolineName(attachState, trampolineName, sizeof(trampolineName));

    /* Create the debugger binary (with permissions = 0755 that will be exec'd later. */
    trampolineBinary = creat(trampolineName, (S_IRWXU | (S_IRGRP | S_IXGRP) | (S_IROTH | S_IXOTH)));
    if (trampolineBinary < 0) {
        CUDBG_ERROR("Failed to create file %s\n", trampolineName);
        return CUDBG_ERROR_OS_RESOURCES;
    }

    bytesWritten = write(trampolineBinary, cudbgTrampolineBinary, cudbgTrampolineBinarySize);
    if (bytesWritten < cudbgTrampolineBinarySize) {
        CUDBG_ERROR("Wrote only %d bytes instead of %d to %s\n", bytesWritten,
                    cudbgTrampolineBinarySize, trampolineName);
        return CUDBG_ERROR_OS_RESOURCES;
    }

    close(trampolineBinary);
#endif
    return CUDBG_SUCCESS;
}
/* This function waits for specified process to exit without an error
 * Arguments:
 *  pid - process identifier which is about to exit
 *  timeout_ms - timeout in milliseconds routine is allowed to spent
 *  waiting for process to exit
 * On failure or timeout -1 is returned.
 * On success pid is returned.
 */
static int
cudbgWaitPidTimeout(int pid, int timeout_ms)
{
#if !cuosOsIsHos() && (cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple())
    cuosTimer timer;
    int status;
    pid_t ret;

    /* Reset the timer */
    cuosResetTimer(&timer);

    /* Wait for the pid to change its status in tight loop.
       Exit the loop on waitpid() success, error or timeout. */
    do {
        ret = waitpid(pid, &status, WNOHANG);

        /* Return an error on timeout */
        if (cuosGetTimer(&timer) > timeout_ms)
            return -1;
    }
    while (ret == 0);

    if (ret < 0)
        return ret;

    /* Make sure the child returned normally. */
    if (!WIFEXITED(status) || (WEXITSTATUS(status) != 0))
        return -1;

    return pid;
#else
    return -1;
#endif
}
/* This function forks off an intermediate short-lived process (child),
 * which in turn forks off the debugger backend (grandchild). The short-
 * lived child process quickly exits, due to which the grandchild is
 * orphanded and adopted by the init process, and becomes a daemon.
 * The parent then reaps the child process.
 * Return value:
 * On failure, -1 is returned.
 * On success, the grandchild returns 0, and the parent returns the PID
 * of the (exited) child process. The child process does not return.
 */
static int
cudbgCreateDebuggerDaemon(void)
{
#if !cuosOsIsHos()
    int childPid, grandChildPid;

    /* Fork once to create the child process. */
    childPid = cudbgDoFork();
    if (childPid < 0)
        return childPid;

    if (childPid == 0) {
        /* Fork again to create the grandchild. */
        grandChildPid = cudbgDoFork();
        if (grandChildPid < 0)
            _exit(-1);

        /* The grandchild returns 0, and will become the actual debugger
         * process. */
        if (grandChildPid == 0)
            return 0;

        /* The child exits normally, causing the grandchild to
         * become orphaned and be adopted by the init process,
         * thus becoming a daemon. */
        _exit(0);
    }


    /* Zombie slayer: reap the child process. */
    return cudbgWaitPidTimeout (childPid, CUDBG_TIMEOUT_MSEC);
#else
    return -1;
#endif
}

static bool
cudbgAnyDeviceHasWatchdog(void)
{
    uint32_t i;
    CUdev *dev;
    NvBool watchdogOn;
    NvBool hasCilp, isMRM;
    CUresult status = CUDA_SUCCESS;

    for (i = 0; i < globals.numDevices; ++i) {
        dev = globals.devices[i];
        if (!dev)
            continue;

        hasCilp = cuiPreemptionDevicePreemptionMode(dev) == CU_COMPUTE_PREEMPTION_MODE_CILP;
        /* MRM's channel watchdog can (and will) be disabled, so filter those
           devices out */
        isMRM = dev->dmalType == CU_DMAL_MRM;

        status = dev->dmal.deviceIsWatchdogEnabled(dev, &watchdogOn);
        if (status == CUDA_SUCCESS && watchdogOn && !isMRM && !hasCilp) {
            CU_ERROR_PRINT(("While attaching, found non-preemptable watchdog on device:%u\n", i));
            return true;
        }
    }
    return false;
}

static void
destroyDebuggerDetachEvent(void)
{
    if (debuggerDetachEventValid) {
        cuosEventDestroy(&debuggerDetachEvent);
        debuggerDetachEventValid = false;
    }
}

static void initInitLock(void)
{
    cuosInitializeCriticalSection(&cudbgInitLock);
}

void cudbgApiInitInternal(CUDBGAttachState attachState)
{
#if !cuosOsIsHos()
    int pid;
    CUresult status;
    CUDBGResult res = CUDBG_SUCCESS;

    /* Attach is not supported when KILP or MPS is enabled. */
    if (attachState != CUDBG_STATE_NOT_ATTACHING &&
        (CUDBG_ENABLE_PREEMPTION_DEBUGGING || cuiGlobalsIsMpsServer() || cuiGlobalsIsLegacyMpsClient())) {
        CUDBG_REPORTED_DRIVER_INTERNAL_ERROR_CODE = cudbgEncodeErrorCode(CUDBG_ERROR_FILE_CUDBGDRIVER_C,
                                                    __LINE__,
                                                    CUDBG_ERROR_ATTACH_NOT_POSSIBLE,
                                                    CUDBG_ERROR_TYPE_CUDBG);
        return;
    }

    /* Starting the MPS server from inside the debugger is not supported. */
    if (cuiGlobalsIsMpsServer()) {
        CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C,
                                          CUDBG_ERROR_INITIALIZATION_FAILURE,
                                          CUDBG_ERROR_TYPE_CUDBG);
        return;
    }

    /* If attaching and any device has a watchdog set, throw an error */
    if (attachState != CUDBG_STATE_NOT_ATTACHING && cudbgAnyDeviceHasWatchdog()) {
        CUDBG_REPORTED_DRIVER_INTERNAL_ERROR_CODE = cudbgEncodeErrorCode(CUDBG_ERROR_FILE_CUDBGDRIVER_C,
                                                    __LINE__,
                                                    CUDBG_ERROR_SOME_DEVICES_WATCHDOGGED,
                                                    CUDBG_ERROR_TYPE_CUDBG);
        return;
    }

    // Ensure that global CriticalSections have been initialized
    cuiGlobalMutexInitOnce();

    /* Initialize the initLock if we have not done so already */
    cuosOnce(&cudbgInitLockOnce, initInitLock);

    /* Explicitly refresh the internal state that tracks the debug client pid,
       since that may have changed on a reattach. */
    cudbgUtilsInit();

    /* Ready the pipes (reset detach flag, and increment the session id) */
    resetPipeState(attachState);

#ifndef RELEASE
    haloDrvSetupEMU();
#endif

#ifndef RELEASE
    /* The following function uses malloc/free etc, so is not safe
       to call while attaching. */
    if (attachState == CUDBG_STATE_NOT_ATTACHING)
        haloDbgMsgRulesInit();
#endif

    /* Initialize the Tools API subscription, depending on the attach state the
     * delayed or instanenous subscription from tools Arbiter will be made*/
    if (!gpudbgDebuggerProcess()) {
        status = cudbgToolsApiInit(attachState);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to initiate Tools API subscription\n"));
            return;
        }
    }

    if (attachState == CUDBG_STATE_ATTACHING_VIA_STUB && (cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()))
        cudbgAttachStubInUse = true;

    if (!gpudbgDebuggerProcess()) {
        cuosEnterCriticalSection(&cudbgInitLock);
        /* Create the detach event */
        if (!debuggerDetachEventValid) {
            status = (CUresult)cuosEventCreateWithFlags(&debuggerDetachEvent, CUOS_EVENT_CREATE_FORCE_PIPE);
            if (status != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Failed to create debugger detach event\n"));
                goto unlock_and_return;
            }
            CUDBG_PRINT(1, "Created debuggerDetachEvent\n");
            debuggerDetachEventValid = true;
        }
        /* Initialize the hashmap that tracks the patch ram allocations for a context */
        if (!cudbgPatchRamMap) {
            cudbgPatchRamMap = toolsHashMapNew(toolsPointerHashFun, toolsPointerEqualFun, 17);
            if (!cudbgPatchRamMap) {
                CU_ERROR_PRINT(("Failed to create patch ram tracking structure\n"));
                goto unlock_and_return;
            }
        }
        if (!cudbgGlobalFocusCoordsMap) {
            cudbgGlobalFocusCoordsMap = toolsHashMapNew(toolsPointerHashFun, toolsPointerEqualFun, 17);
            if (!cudbgGlobalFocusCoordsMap) {
                CU_ERROR_PRINT(("Failed to create global focus coords tracking structure\n"));
                goto unlock_and_return;
            }
        }
        cuosLeaveCriticalSection(&cudbgInitLock);
    }

    /* Create the RPC daemon process (being careful to only do so if we're are
       in the app process space.  This is only done for debug clients that
       indicate they require this mechanism.
       Note:  ensure _exit(), not exit(), is used by the child process, as
              we need to avoid any installed atexit() handlers, etc. */
    if (!gpudbgDebuggerProcess() && (gpudbgDebuggerNeedsRPC() ||
                                     (attachState == CUDBG_STATE_ATTACHING_VIA_STUB))) {
        if (!(cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple())) {
            CUDBG_ERROR("rpcd not supported on this platform!\n");
            CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C,
                                              CUDBG_ERROR_INTERNAL,
                                              CUDBG_ERROR_TYPE_CUDBG);
        }

        cuosEnterCriticalSection(&cudbgInitLock);
        /* Bail out if this has already been completed */
        if (CUDBG_DEBUGGER_INITIALIZED)
            goto unlock_and_return;


        /* Setup the trampoline and do all the checks here */
        res = cudbgSetupTrampoline(attachState);
        if (res != CUDBG_SUCCESS) {
            CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C,
                                              res, CUDBG_ERROR_TYPE_CUDBG);
            goto unlock_and_return;
        }

        pid = cudbgCreateDebuggerDaemon();

        if (pid == 0) {
            CUDBG_TRACE("RPCD forked!\n");
            res = cudbgDoExec(attachState);
            if (res != CUDBG_SUCCESS) {
                CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C,
                                                  res, CUDBG_ERROR_TYPE_CUDBG);
                _exit(1);
            }
        }
        else if (pid < 0) {
            CUDBG_ERROR("Error forking off RPCD!\n");
            CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C,
                                              CUDBG_ERROR_FORK_FAILED,
                                              CUDBG_ERROR_TYPE_CUDBG);
            _exit(1);
        }

        /* Indicate we've completed the RPC check */
        if (attachState != CUDBG_STATE_ATTACHING_VIA_STUB)
            CUDBG_DEBUGGER_INITIALIZED = 1;

        /* If the attach stub had been created earlier, it would have set this variable.
           Once this variable has been sent to RPCD, it should be reset to keep things
           clean. */
        if (attachState == CUDBG_STATE_ATTACHING_VIA_RPCD)
            cudbgAttachStubInUse = false;

        /* Bug 1054370:  For clients needing RPCD, guarantee initialization
           with between RPCD and the client by invoking an initialization
           callback.  This callback will wait until RPCD has initialized,
           then send a message to it, which will subsequently interrupt
           the debug client and ensure the handshake takes place.  This
           is not executed when attaching late (we cannot send events
           at that time, nor do we want to). */
        if (attachState == CUDBG_STATE_NOT_ATTACHING && gpudbgDebuggerNeedsRPC())
            cudbgRpcInitEvent();

    }
unlock_and_return:
    cuosLeaveCriticalSection(&cudbgInitLock);
    CUDBG_TRACE("Application is continuing\n");

    if (attachState != CUDBG_STATE_NOT_ATTACHING) {
        (void)cudbgUpdateFrontendResumeFlag();
    }
#endif
}

/* Legacy public frontend to cudbgApiInit()
 * Used by TotalView for direct(stub) mode attach
 */
void cudbgApiInit(uint32_t arg)
{
    switch ((CUDBGAttachState)arg) {
    case CUDBG_STATE_ATTACHING_VIA_RPCD:
    case CUDBG_STATE_ATTACHING_VIA_STUB:
        cudbgApiInitInternal((CUDBGAttachState)arg);
        break;

    default:
        CUDBG_ERROR("Invalid value in cudbgApiInit(%d)\n", arg);
        CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C, CUDBG_ERROR_INTERNAL, CUDBG_ERROR_TYPE_CUDBG);
    }
}

/* New frontend to cudbgApiInit() invoked by cuda-gdb dynamically*/
void cudbgApiAttach(void)
{
    cudbgApiInitInternal(CUDBG_STATE_ATTACHING_VIA_RPCD);
}

/* This routine is used to ensure that the initialization handshake between
   the debug client and RPCD occurs immediately.  It sends an event from the
   application to the dispatcher thread (in RPCD), which will then propagate
   the event to the client, which initiates the handshake. */
void cudbgRpcInitEvent(void)
{
    CUDBGcommand message;

    CUDBG_ENTERCS(0);

    CU_TRACE_FUNCTION();

    message.kind = dbgRpcInitEvent;
    pushMessage(&message, sizeof message);
    sendMessage();

    CUDBG_LEAVECS(0);
}

/* This function is called by the frontened via a dynamic function call on
   attaching to a running CUDA process. It collects state from the driver and
   builds up state in the backend.
*/
CUresult cudbgInitDebugger(CUintHandlerServiceRoutineParams *serviceParams)
{
    CUctx *ctx = NULL;
    CUmod *mod = NULL;
    CUfunc *func = NULL;
    CUresult status;

    CUDBG_PRINT(1, "Beginning Attach\n");
    cudbgSetDebuggerAttachState(true);

    /* Spin on the pending tools API completion if any */
    if (cudbgToolsApiState != CUDBG_APP_TOOLS_API_STATE_READY) {
        while (cudbgToolsApiState != CUDBG_APP_TOOLS_API_STATE_READY);
    }

    /* Once this is done, walk through the list of all contexts and tell the
       debugger about it.
    */
    CUDBG_PRINT(1, "Attach: Collecting driver state\n");
    cuiMutexLock(&globals.debuggerAttachMutex);

    cudbgReportCudaInitialized(false, gpudbgGetClientSessionId());

    for (ctx = globals.activeContexts; ctx != NULL; ctx = ctx->next) {
        CU_TRACE_FUNCTION();

        /* Context is in the process of dying. Dont bother
           telling the backend about it */
        if (ctx->forbidEnumeration == NV_TRUE) {
            CUDBG_PRINT(1, "Attach: Context being finalized. Skipping\n");
            continue;
        }

        /* Check if we support attaching to a process on this GPU */
        if (ctx->device->state.arch < NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100) {
            CUDBG_PRINT(1, "Attach: Unsupported GPU found, exiting!\n");
            cuiMutexUnlock(&globals.debuggerAttachMutex);
            CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C, CUDBG_ERROR_INVALID_DEVICE,
                                              CUDBG_ERROR_TYPE_CUDBG);
            /* If the user chooses to continue after the above error,
               return success but don't enable debug notifications.
            */
            return CUDA_SUCCESS;
        }

        CUDBG_PRINT(1, "Attach: Registering ctxId %d\n", ctx->ctxId);
        cudbgReportCtxCreate(ctx, false, gpudbgGetClientSessionId());

        cuiMutexLock(&ctx->moduleMutex);

        cudbgReportSystemStackResize(ctx,
                                     ctx->systemStackSize,
                                     false,
                                     gpudbgGetClientSessionId());

        for (mod = ctx->modules; mod != NULL; mod = mod->next) {
            CUDBG_PRINT(1, "Attach: Registering module\n");
            cudbgReportModuleLoad(ctx, mod, &mod, "Unknown", (char *)mod->elf_image);
        }

        for (mod = ctx->modules; mod != NULL; mod = mod->next) {
            for (func = mod->pFuncList; func; func = func->next) {
                if (func->launchCount) {
                    CUDBG_PRINT(1, "Attach: Registering launch of func %s\n", func->name);
                    gpudbgReportDeviceExecutionLaunch(ctx,
                                                      func,
                                                      func->gridDim,
                                                      func->blockDim,
                                                      func->gridid,
                                                      ctx->device->hal.funcGetFuncMemBase(ctx, func),
                                                      0,
                                                      CUI_STREAM_ID_INVALID);
                }
            }
        }

        cuiMutexUnlock(&ctx->moduleMutex);

        // Let syscalls sensitive to debugger know that debugger is attached
        status = cuiSyscallOnDebuggerAttach(ctx);
        if (CUDA_SUCCESS != status) {
            cuiMutexUnlock(&globals.debuggerAttachMutex);
            CUDBG_PRINT(1, "Failed to handle onDebuggerAttach of syscalls.\n");
            return status;
        }
        // Flush the syscall constants to guarantee they're set up before
        // announcing that debugger is successfully attached.
        cuiCtxUpdateSyscallConstBank(ctx);
    }

    /* While we were collecting driver state, another thread might be blocked
       on debuggerAttachMutex, just before sending a debugger notification. As
       soon as the lock is released below, the other thread could race ahead but
       not send a debugger callback since CUDBG_IPC_FLAG_NAME = 0 at this point,
       causing us to miss a callback. To prevent that, reenable debugger
       notifications before releasing the lock.
    */
    CUDBG_IPC_FLAG_NAME = 1;

    /* Once the floodgates have been opened for all callbacks by setting CUDBG_IPC_FLAG_NAME,
     * the only callbacks not received by the backend would be the ones that were dropped while
     * the debugger was collecting state. To mop up these callbacks, we loop over all known
     * contexts and resend notifications for all known memblocks. */
    for (ctx = globals.activeContexts; ctx != NULL; ctx = ctx->next) {
        CU_TRACE_FUNCTION();

        /* Context is in the process of dying. Dont bother
           telling the backend about it */
        if (ctx->forbidEnumeration == NV_TRUE) {
            CUDBG_PRINT(1, "Attach: Context being finalized. Skipping\n");
            continue;
        }

        /* Resend all the memory notifications for this context to handle races with attach */
        CUDBG_PRINT(1, "Resending all memory notifications for context \n");
        memmgrLock(ctx->memmgr);
        cudbgReportAllMemblocks_underLock(ctx);
        memmgrUnlock(ctx->memmgr);
    }

    cuiMutexUnlock(&globals.debuggerAttachMutex);
    CUDBG_PRINT(1, "Attach complete!\n");

    cudbgSetDebuggerAttachState(false);

    return CUDA_SUCCESS;
}

/* This function is called from cuda-gdb front end through a dynamic funciton call to
 * unsubscribe the tools arbiter */
void
cudbgApiDetach (void)
{
#if !cuosOsIsMods()
    CUresult status = CUDA_SUCCESS;

    /* Always call the tools API cleanup first. If this call doesnt
       immediately take effect, the global flag must be checked */
    status = cudbgToolsApiFinalCleanUp(CUDBG_TOOLSAPI_CLEANUP_DYNAMIC);
    if (status != CUDA_SUCCESS)
        CUDBG_ERROR("Failed to Unsubscribe Tools Arbiter properly\n");

    if (!cudbgIsAttachDetachHandlerAvailable()) {

        /* Unsubscribe with no inthandler, tools API needs a resume and within a critical section
           Issue:
               It is possible (actually quite likely) that at the time of
               detach, the current thread is both within an arbiter callback
               and within a debugger critical section. If so, there might
               be two detach messages sent, one for the deferred callback
               and a different one for the critical section

           Solution:
               When both conditions are met, the arbiter callback will always
               have a larger lifetime than the critical section. So, to handle
               this case correctly, if both are present, the arbiter callback
               is the one responsible for sending the detachCompletion message.
               This is done by not updating the detachFlag if the toolsApi flag
               is set to _NOTIFY_DETACH.
        */

        if (cudbgToolsApiState == CUDBG_APP_TOOLS_API_STATE_WAITING) {
            /* Unsubscribe with no inthandler and the tools API needing a resume
               Issue:
                   When detaching, it is possible that no inthandler threads
                   are present. However, a tools API action could be inflight.
                   In such a case, the frontend must be told to resume,
                   and the backend must wait for the deferred action to finish.

               Solution:
                   This is handled in a very similar way as the existing detach
                   during a critical section. The dynamic detach function call
                   performs the detach action, and if it determines that the
                   function call updated the global flag to _WAITING, it
                   changes the flag to _NOTIFY_DETACH. When the application is
                   resumed, and the callback finishes, it tries to
                   set the flag to _READY. The code that updates the
                   flag checks to see if the transition was from
                   _NOTIFY_DETACH to _READY, and if so, sends a detachCompletion
                   message to the backend.
            */
            CUDBG_PRINT(1, "No inthandler found, and tools API needs resume\n");
            cudbgToolsApiStateUpdate(CUDBG_APP_TOOLS_API_STATE_NOTIFY_DETACH);

            /* Handle Debugger CS at the same time as tools API
               Issue :
                    A tools API callback might be in flight at the same
                    time as when a different thread is in the debugger
                    critical section and a third thread might be stalled
                    on entering the critical section.
                    We require that the third thread not try to
                    perform any of the pipe sends within the section

               Solution:
                    The debugger detach flag is moved to a 5 state flag
                    The flag is initialized to _READY. When a thread
                    enters the debuggerCS, it switches this flag
                    to _BUSY. On exit, the flag is switched back
                    from _BUSY to _READY.
                    On detach, the following conditions are checked:
                    Case 1 : Tools API callback present and a thread in debuggerCS
                        In this case, the tools API will be responsible
                        for sending the detachCompletion message.
                        The flag is moved from _BUSY to _BEGIN_NOSIGNAL
                        When the thread in the debuggerCS exits, it
                        will move the state to _DONE. Any new entrants
                        into the debuggerCS will skip to the end
                        The tools API callback will stall on
                        the transition of the flag to _DONE and will
                        send the detach completion message
                    Case 2 : Tools API callback not present, and a thread in debuggerCS
                        In this case, the thread inside the debuggerCS is
                        responsible for sending the detachCompletion message.
                        The flag is set to _BEGIN_SIGNAL, and when the thread
                        comes to the end of the debugCS, it will send a message
                        and transition the flag to _DONE. At this point, new
                        entrants to the debuggerCS will see the flag is _DONE
                        and will skip the section.
                    Case 3 : Tools API callback not present and thread is not in debuggerCS
                        In this case, the frontend is not going to resume the app.
                        The flag is immediately transitioned to _DONE, which
                        will prevent any new entrants from trying to send a message.
             */
            if (cudbgDetachFlag == CUDBG_DETACH_FLAG_BUSY)
                detachFlagSetDetachBeginNosignal();
            else
                detachFlagSetDetachDone();
        }
        else if (cudbgDetachFlag == CUDBG_DETACH_FLAG_BUSY) {
            /* Change the flag state to indicate that the debugger is detaching,
               so that application threads don't try to send any more pipe
               messages. If a detach handler is available, the detach callback
               is responsible for calling this function. */
            /* We cannot make a common call for the case whether the debugger
             * callback will run and the case where it will not. This call must
             * run only after the detach handler callback has finished all its
             * work, otherwise the detach handler will effectively quit inside
             * CUDBG_ENTERCS() */
            CUDBG_PRINT(1, "No inthandler found, DetachFlag is requesting a resume\n");
            detachFlagSetDetachBeginSignal();
        }
        else {

            /* Set the detach flag to done to prevent any late entrants to the debugger CS
               after the frontend resumes  */
            CUDBG_PRINT(1, "No inthandler, detach flag and tools API dont need a resume\n");
            detachFlagSetDetachDone();
        }

        /* Detach pipe cleanup problem
           Issue:
               From the frontend's perspective, the detach sequence is
                   Dynamic function call of ApiDetach
                   Check the resume flag
                   If resume is !0, call the API cleanupOnDetach
                   Resume application
                   Wait for API state to say detached
               This sequence is a problem when no inthandler thread is present
               as what happens is that a message is queued up on the pipe.
               When a subsequent attach happens, the existing detachFd
               is reused. This causes the inthandler to wake up and
               do a full detach. At the end of detach, the debug
               flag is reset and this effectively
               kills all further callbacks
           Solution:
               To fix this, the dynamic function call does a cuosEventDestroy
               if no inthandlers are found. This function calls close(), which
               is async signal safe. This also resets the static flag that
               ensures a new detachFd is created the next time cudbgInit is
               executed (i.e. on the next reattach).
                On the other side of this handshake, the
               API entry point to do cleanupOnDetach will first call poll
               on the detachFd to make sure the pipe is open on both sides.
               Since the pipe is created by the app before the backend is
               forked, the only way it can be closed at the time the backend
               makes this call is if it was explicitly closed by the app.
               This prevents the backend from dying with a SIGPIPE, by
               trying to write to a closed pipe.
        */

        destroyDebuggerDetachEvent();
    }

    /* This is called as a dynamic function call from the frontend. At this point,
       we tell the frontend to resume iff :
        1. No attach handler is present (i.e. no context is up)
        2. A debugger pipe send is in flight
        3. A tools API callback is in flight
     */
    /* Ordering of the flag updates
        Issue:
           The frontend resume flag needs to be done after the dynamic
           function call to ToolsApiInit/ToolsApiCleanup. In
           addition, the flag check should account for the case
           where the flag has already been updated.
        Solution:
           The frontend resume flag update has been moved to the end
           of the dynamic attach and dynamic detach function. The
           flag update will happen if the ToolsApi flag is set to
           either _WAITING or _NOTIFY_DETACH. Similarly, the
           flag will update if the DetachFlag is either _BUSY or _READY.
     */
    /* This call sets the frontend visible flag and returns the value */
    (void)cudbgUpdateFrontendResumeFlag();
#endif
}

CUresult cudbgDetachDebugger(CUintHandlerServiceRoutineParams *serviceParams)
{
#if !cuosOsIsMods()
    CUctx *ctx;
    CUresult status = CUDA_SUCCESS;

    CUDBG_PRINT(1, "Starting Detach\n");

    if (cudbgToolsApiState != CUDBG_APP_TOOLS_API_STATE_READY)
        while (cudbgToolsApiState != CUDBG_APP_TOOLS_API_STATE_READY);

    /* Backwards compatibility
        Issue:
            The detach dynamic function call might be skipped under some
            scenarios by cuda-gdb's from R5.5 and earlier. This causes the
            toolsAPI cleanup to not be called.
        Solution:
            Call the cleanup again here. This must be done from OUTSIDE the
            critical section, since the unsubscribe from the toolsAPI will
            end up taking a Writer lock.
            Otherwise if we unsubscribe after we have entered the critical
            section, we will deadlock with any callback in flight which has
            already taken the Reader lock, since the callback will get blocked
            on CUDBG_ENTERCS() with the Reader lock held, and we will spin
            waiting to acquire the Writer lock inside the CUDBG CS.
    */
    if (CUDBG_APICLIENT_REVISION <= API_REVISION_5_5) {
        status = cudbgToolsApiFinalCleanUp(CUDBG_TOOLSAPI_CLEANUP_NONDYNAMIC);
        if (status != CUDA_SUCCESS)
            CUDBG_ERROR("Failed to Unsubscribe Tools Arbiter properly\n");
    }

    CUDBG_ENTERCS(0);

    cuiMutexLock(&globals.debuggerAttachMutex);
    for (ctx = globals.activeContexts; ctx != NULL; ctx = ctx->next)
        cuiTrapHandlerChangeServiceRoutineEnabledState(ctx, true);

    CUDBG_PRINT(1, "Detach: Re-enabled all trap handlers\n");

    cuiMutexUnlock(&globals.debuggerAttachMutex);

    /* Set the detach flag to BEGIN. This will cause the CUDBG_LEAVECS()
     * macro to send a detach completion message. */
    detachFlagSetDetachBeginSignal();

    /* Turn off notifications from the driver */
    CUDBG_IPC_FLAG_NAME = 0;

    CUDBG_LEAVECS(0);

    CUDBG_PRINT(1, "Detach: TODO: Disable SM debug mode for contexts that don't need it\n");

    CUDBG_PRINT(1, "Finished Detach\n");
#endif
    return CUDA_SUCCESS;
}

void
cudbgDriverOptionsInitialize(uint32_t clientRevision, bool reportLaunches)
{
    /* Those options are fixed for the whole debugging session. */
    cudbgDriverOptions.launchBlocking = clientRevision <= API_REVISION_3_2;
    cudbgDriverOptions.canPinExistingMemory = clientRevision >= API_REVISION_4_0;
    cudbgDriverOptions.reportKernelLaunches = reportLaunches;
    cudbgDriverOptionsInitialized = true;
}

bool
cudbgLaunchBlocking(CUctx *ctx)
{
    /* CUDA_LAUNCH_BLOCKING = 1 */
    if (ctx->launchBlocking)
        return true;

    /* The client requires blocking launches */
    if (cudbgDriverOptions.launchBlocking)
        return true;

    /* The client can also write to a global variable via ptrace */
    if (CUDBG_ENABLE_LAUNCH_BLOCKING)
        return true;

    return false;
}

bool
cudbgCanPinExistingMemory(void)
{
    /* In CUDA 4.0, we updated cuda-gdb (and informed all Debug API clients)
       to expect a new error code (CUDBG_ERROR_ADDRESS_NOT_IN_DEVICE_MEM)
       when attempting to read global memory.  This happens because it could
       have been allocated on the host (malloc), pinned down using host
       registration routines in the CUDA driver, then mapped into the device
       VA space.  In this case, RM does not own the original allocation, and
       therefore refuses to dup any associated handles into the debugger's
       process space, which causes the mapping to fail (hence the new error
       code).

       Now, the driver has turned on this behavior by default in r280_00.
       This means that older clients (prior to r4.0) cannot read this memory
       because they were never able to handle this new error code.  So, to
       fix this backwards compatibility regression, we will force the driver
       down the old allocation path when running inside of an 'older' debugger. */
    return cudbgDriverOptions.canPinExistingMemory;
}




/* The following calls gettid() directly via a syscall, because
 * the function itself can be found on none of the known Linux
 * installations (as of Aug 2007).  Note that SYS_gettid has been
 * introduced halfway the 2.4 kernel series, so might not be
 * available on all platforms.
 * We already require Linux 2.6 so this is a safe workaround for
 * when this is compiled against older headers. */
#if !defined(SYS_gettid) && cuosArchIsX86()
#  define SYS_gettid 224
#endif

/* Get the os-dependent TID. Return -1 if unknown. It is the responsibility of
   the client to check for that value. We assert in debug mode though. */
uint32_t
cudbgGetTid (void)
{
    uint32_t tid = ~0U;
    /* Android has gettid */
#if cuosOsIsAndroid()
    tid = gettid();
#elif cuosOsIsLinux()
    tid = syscall(SYS_gettid);
#elif cuosOsIsApple()
    tid = cudbgMacGetTID();
    if (tid == ~0U)
        CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C, CUDBG_ERROR_INTERNAL,
                                          CUDBG_ERROR_TYPE_CUDBG);
#else
    tid = cuosProcessId();
#endif

    return tid;
}


bool
cudbgIsDebuggableDevice(CUdev *dev)
{
    NvBool watchdogOn;
    CUresult res;
    bool isAvailable;

    switch (dev->state.arch) {
#if NVCFG(GLOBAL_ARCH_FERMI)
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110:
#endif
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100:
#endif
#if NVCFG(GLOBAL_ARCH_KEPLER)
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_T12X
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_T12X:
#endif
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK200
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK200:
#endif
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110:
#endif
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100:
#endif
#if NVCFG(GLOBAL_ARCH_MAXWELL)
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM000
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM000:
#endif
#if NVCFG(GLOBAL_GPU_FAMILY_GM20X)
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200:
#endif
#endif
#endif
#if NVCFG(GLOBAL_ARCH_PASCAL)
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GP100
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GP100:
#endif
#endif
#if NVCFG(GLOBAL_ARCH_VOLTA)
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV100
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV100:
#endif
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV110
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV110:
#endif
#endif
#if NVCFG(GLOBAL_ARCH_TURING)
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_TU100
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_TU100:
#endif
#endif
#if NVCFG(GLOBAL_ARCH_AMPERE)
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GA100
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GA100:
#endif
#endif
        break;
    default:
        /* SM 1.x is not supported in the debugger */
        return false;
        break;
    }

    res = dev->dmal.deviceIsWatchdogEnabled(dev, &watchdogOn);
    watchdogOn = (watchdogOn && res == CUDA_SUCCESS);
    isAvailable = (gpudbgDebuggerEnablePreemptionDebugging() && dev->state.supportsKilp) ||
                  (cuiPreemptionDevicePreemptionMode(dev) == CU_COMPUTE_PREEMPTION_MODE_CILP) ||
                  (!watchdogOn || dev->dmalType == CU_DMAL_MRM);

    return isAvailable;
}

static bool
isInternalModule(CUmod *mod)
{
    if (!mod)
        return false;

    return ((mod->visibility != CU_MOD_VISIBILITY_VISIBLE) || mod->internal);
}


static void
reportHiddenModules(CUctx *ctx)
{
    CUmod *mod = NULL;

    if (!ctx) {
        CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C, CUDBG_ERROR_INTERNAL,
                                          CUDBG_ERROR_TYPE_CUDBG);
        return;
    }

    for (mod = ctx->modules; mod; mod = mod->next) {
        if (isInternalModule(mod))
            cudbgRegisterModuleAndFunctions(ctx, mod, &mod,
                                            mod->name ?
                                            (char *)mod->name : "hidden",
                                            (char *)mod->elf_image);
    }
}

void
cudbgGetRmCtxHandles(CUctx *ctx, uint32_t *hAppClient, uint32_t *hComputeObject,
                     uint32_t *hChannelGroup, uint32_t *channelList, uint32_t numChannels,
                     uint32_t *numAllocatedChannels)
{
    uint32_t hChannel = 0;
    bool computeObjectSaved = false;
    uint32_t i;
    CUnvchannel *channel;
    uint32_t outix;

    if (!hAppClient || !hComputeObject || !hChannelGroup || !channelList) {
        CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C, CUDBG_ERROR_INTERNAL,
                                          CUDBG_ERROR_TYPE_CUDBG);
        return;
    }

    *hAppClient = globals.rmClient;
    if (numAllocatedChannels)
        *numAllocatedChannels = 0;

    for (i = 0, outix = 0; i < ctx->channelManager->channelCount && outix < numChannels; i++) {
        channel = ctx->channelManager->channels[i];

        if (channelIsCompute(channel)) {
            uint32_t rmClient = 0;

            /* Save out the first compute object */
            if (!computeObjectSaved) {
                *hComputeObject = channel->engines[CU_ENGINE_COMPUTE];
                /* Save the TSG (channel group) handle [sm_35+ only] */
                if (ctx->device->state.supportsTSG) {
                    if (ctx->device->dmalType == CU_DMAL_RM &&
                        channelGetRmChannelGroupHandle(channel, (NvU32 *)hChannelGroup) != CUDA_SUCCESS) {
                        CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C, CUDBG_ERROR_INTERNAL,
                                                          CUDBG_ERROR_TYPE_CUDBG);
                        return;
                    }
                }
                if (ctx->device->dmalType == CU_DMAL_MRM) {
                    /* HACK: give a unique handle for MRM (even if it doesn't support TSG) */
                    *hChannelGroup = handlePoolAlloc(globals.handlePool);
                }
                computeObjectSaved = true;
            }

            channelGetRmHandles(channel, (NvU32 *)&rmClient, (NvU32 *)&hChannel);
            /* Add this channel into the list.  If TSGs are being used,
               there can be many compute channels (32) in the channel group.
            */
            channelList[outix++] = hChannel;
        }
    }

    if (numAllocatedChannels)
        *numAllocatedChannels = outix;
}

void
cudbgGetMRMCtxHandles(CUctx *ctx, int32_t *nvhostdbgfd, int32_t *channelList, uint32_t clistsz, uint32_t *numChannels)
{
#if cuosPlatformIncludesMrm()
    uint32_t i = 0, n = 0;
    CUnvchannel *channel;

    if (!ctx || !channelList)
        return;

    if (ctx->device->dmalType != CU_DMAL_MRM)
        return;

    if (nvhostdbgfd)
        *nvhostdbgfd = -1;

    /* Save all the channel fds so they can be bound to a debug session in the
       backend */
    /* TODO: support TSG fd in BIND_CHANNEL ioctl, thus allowing us to use just
       the one fd */
    for (i = 0; i < ctx->channelManager->channelCount; i++) {
        channel = ctx->channelManager->channels[i];
        if (n < clistsz) {
            channelList[n++] = channel->dm.mrm->channelfd;
        }

        if (nvhostdbgfd && *nvhostdbgfd < 0) {
            if (channelIsCompute(channel)) {
                *nvhostdbgfd = channel->dm.mrm->nvhostdbgfd;
            }
        }
    }

    if (numChannels)
        *numChannels = n;
#endif
}

void cudbgReportCudaInitialized(bool doLateCheck, uint32_t sessionId)
{
#if cuosPlatformHasKernelModeUvm()
    UvmFileDescriptor uvmhdl;
    CUDBGcommand message;
    NV_STATUS status = NV_OK;
    NvU32 isUVM8Supported = 0;

    CUDBG_ENTERCS(0);
    CU_TRACE_FUNCTION();

    if (doLateCheck && !gpudbgDebuggerAttached())
        CUDBG_BREAKCS(0);

    if (sessionId != gpudbgGetClientSessionId())
        CUDBG_BREAKCS(0);

    message.kind = dbgCudaInitialized;
    message.cases.cudaInitialized.uvmEnabled = globals.useUvm8Api;
    pushMessage(&message, sizeof(message));

    if (globals.useUvm8Api) {
        status = UvmGetFileDescriptor(&uvmhdl);
        if (status != NV_OK) {
            CUDBG_ERROR("Failed to get fd for UVM8! status=%d\n", status);
            CUDBG_BREAKCS(0);
        }
        pushControlMessage((void*)&uvmhdl, sizeof(uvmhdl));
    }

    sendMessage();

    CUDBG_LEAVECS(0);
#endif
}

void cudbgReportStreamSynchronized(CUctx *ctx, uint64_t streamId, uint32_t sessionId)
{
    CUDBGcommand message;

    CUDBG_ENTERCS(0);
    CU_TRACE_FUNCTION();

    if (sessionId != gpudbgGetClientSessionId())
        CUDBG_BREAKCS(0);

    message.kind = dbgStreamSynchronized;
    message.cases.streamSynchronized.context = (uint64_t)(uintptr_t)ctx;
    message.cases.streamSynchronized.streamId = streamId;
    pushMessage(&message, sizeof(message));
    sendMessage();

    CUDBG_LEAVECS(0);
}

/*
 * Function        : Register used GPU.
 * Parameters      : ctx                    (I) Identification of context for subsequent operations
 *                 : doLateCheck            (I) Should there  be a secondary check of the debugger flag.
 *                                              This is true for normal calls (i.e. via toolsAPI) and
 *                                              false when called from the attach handler thread
 *                 : sessionId              (I) The ID of the session when the callback was first subscribed
 *                                              This is used to drop callbacks that may have originated
 *                                              in a different session.
 */
void cudbgReportCtxCreate(CUctx *ctx, bool doLateCheck, uint32_t sessionId)
{
    CUmemobj *scratchpadMemobj = NULL, *patchMemobj = NULL;
    uint64_t thCodeVA = 0, thRdRegOffset = 0, thWrRegOffset = 0,
             thRdTexMemOffset = 0, syscallRcVaddr = 0, thCodeSize = 0, globalFocusCoordsAddr = 0;
    CUDBGPreemptionTypes preemptionType = CUDBG_PREEMPTION_TYPE_NONE;
    NvBool thUsesDynamicRegs = NV_FALSE;
    CUDBGcommand message;
    CUresult status;
    CUDBGResult res = CUDBG_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;
    int fdArray[CUDBG_MAX_CHANNELS+1] = {0};
    uint64_t funcMemBaseVA;
    /* Bug 200383439: Don't take the addresses of the fields in the message because they're packed.
     *                Make sure to keep these declarations in sync with cudbgdriver.h */
    uint32_t hAppClient = 0;
    uint32_t hComputeObject = 0;
    uint32_t hChannelGroup = 0;
    uint32_t computeChannelCount = 0;
    uint32_t hChannelList[CUDBG_MAX_CHANNELS] = {0};
    const uint32_t globalFocusCoordsAllocSize = 32;

    /* Dont report context create for OpenCL contexts */
    if (cuiCtxApiIs_OCL(ctx)) {
        return;
    }

    if (!cudbgIsDebuggableDevice(ctx->device)) {
        CUDBG_PRINT(1, "Device not debuggable. Not reporting context creation\n");
        return;
    }

    if (ctx->isGraphicsDummyCtx) {
        CUDBG_PRINT(1, "Graphics dummy context is not debuggable. Not reporting context creation\n");
        return;
    }

    /* This check is here since we may attach/detach multiple times */
    if (!cudbgIsCoredumpInProgress() && !ctx->debuggerDetachServiceRoutine) {
        /* Since this may be called while attaching, disable the wait for completion */
        status = intHandlerRegisterRoutine(ctx->intHandler,
                                           &ctx->debuggerDetachServiceRoutine,
                                           cudbgDetachDebugger,
                                           (void *)ctx,
                                           &debuggerDetachEvent,
                                           0,
                                           CU_INT_HANDLER_REGISTER_FLAGS_NO_COMPLETION_WAIT);
        if (status != CUDA_SUCCESS) {
            /* Non fatal */
            CU_ERROR_PRINT(("Failed to register debugger detach handler service routine\n"));
        }
    }

    CUDBG_ENTERCS(0);
    CU_TRACE_FUNCTION();

    if (doLateCheck && !gpudbgDebuggerAttached())
        CUDBG_BREAKCS(0);

    if (sessionId != gpudbgGetClientSessionId())
        CUDBG_BREAKCS(0);

    /* On fermi and kepler, the driver will detect an attached debugger and
     * turn on debug mode on the context, assemble a trap handler, and write
     * the address of the scratchpad into the debugger const bank.
     */

#if !cuosOsIsMods()
    /* If we attached late, some context could have gone past the trap handler
       activation change but missed being in the list of contexts. We need to
       activate the trap handler for such a context here, but only for GPUs
       that support it.
       Since we know that the debugger is active, we don't need to check for
       cuiTrapHandlerRequired(). It would have incorrectly returned false
       anyway if this codepath is executed during the Attach state collection
       routine where gpudbgDebuggerAttached() hasn't yet been set to 1. */
    if (!cuiTrapHandlerIsActive(ctx->trapHandler)) {
        FLAG_SET(CUtrapHandlerActivate) flags = CU_TRAPHANDLER_ACTIVATE_DO_NOT_REGISTER_ISR | CU_TRAPHANDLER_ACTIVATE_VIA_REGOPS;
        CUDBG_PRINT(1, "Trap handler not active, activating now\n");
        cuiTrapHandlerActivate(ctx->trapHandler, flags);
    }
    else if (!cudbgIsCoredumpInProgress()) {
        /* If the trap handler is already active, disable the trap handler
           service routine. If the debugger attached late, the trap handler
           service routine would be active and would need to be disabled
           explicitly. */
        cuiTrapHandlerChangeServiceRoutineEnabledState(ctx, false);
    }

    /* Get the address for the trap handler scratchpad */
    scratchpadMemobj = cuiTrapHandlerGetScratchpad(ctx->trapHandler);
    if (!scratchpadMemobj) {
        res = CUDBG_ERROR_INTERNAL;
        CUDBG_ERROR("Failed to get the trap handler scratchpad.\n");
        CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C, res,
                                          CUDBG_ERROR_TYPE_DRIVER);
        CUDBG_BREAKCS(0);
    }

    thCodeVA = memobjGetDeviceVaddr(cuiTrapHandlerGetDebuggerFunc(ctx->trapHandler));
    thCodeSize = memobjGetSize(cuiTrapHandlerGetDebuggerFunc(ctx->trapHandler));

    /* Set the preemption type */
    /* Set whether preemption-debugging has been enabled  (sm_35+ only) */
    if (cuiPreemptionGetPreemptionMode(ctx->preemption) == CU_COMPUTE_PREEMPTION_MODE_CILP)
        preemptionType = CUDBG_PREEMPTION_TYPE_CILP;
    else if (ctx->device->state.supportsKilp && gpudbgDebuggerEnablePreemptionDebugging())
        preemptionType = CUDBG_PREEMPTION_TYPE_KILP;


    /* Texture memory is read via a traphandler subroutine now. This label
       points to the offset where a custom TLD instruction will be patched in. */
    if (ctx->device->state.traphandlerIsABICompliant == NV_FALSE) {
        CUresult status;

        status = cuiTrapHandlerGetDebuggerLabel(ctx->trapHandler, (NvU64*) &thRdTexMemOffset,
                                                "READ_TEXTURE_MEMORY_PATCH_LOC");
        if (status != CUDA_SUCCESS) {
            res = CUDBG_ERROR_INTERNAL;
            CUDBG_ERROR("Failed to get debugger label READ_TEXTURE_MEMORY_PATCH_LOC\n");
            CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C, res,
                                              CUDBG_ERROR_TYPE_DRIVER);
            CUDBG_BREAKCS(0);
        }
    }

    /* On (sm_32) and higher, we perform dynamic patching of instructions in the trap handler */
    //TODO:: FIX THIS BY USING THE DRVHAL INSTEAD
    haloDrvThUsesDynamicRegs(ctx, &thUsesDynamicRegs);
    if (ctx->device->state.traphandlerIsABICompliant == NV_FALSE && thUsesDynamicRegs) {
        CUresult status;

        status = cuiTrapHandlerGetDebuggerLabel(ctx->trapHandler, (NvU64*) &thRdRegOffset, "READ_DYNAMIC_REGISTER");
        if (status != CUDA_SUCCESS) {
            res = CUDBG_ERROR_INTERNAL;
            CUDBG_ERROR("Failed to get debugger label READ_DYNAMIC_REGISTER\n");
            CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C, res,
                                              CUDBG_ERROR_TYPE_DRIVER);
            CUDBG_BREAKCS(0);
        }

        status = cuiTrapHandlerGetDebuggerLabel(ctx->trapHandler, (NvU64*) &thWrRegOffset, "WRITE_DYNAMIC_REGISTER");
        if (status != CUDA_SUCCESS) {
            res = CUDBG_ERROR_INTERNAL;
            CUDBG_ERROR("Failed to get debugger label WRITE_DYNAMIC_REGISTER\n");
            CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C, res,
                                              CUDBG_ERROR_TYPE_DRIVER);
            CUDBG_BREAKCS(0);
        }
    }

    patchMemobj = (CUmemobj*)toolsHashMapFind(cudbgPatchRamMap, tHashMapPtrToKey(ctx));
    if (!patchMemobj && cudbgDriverOptions.patchRamSize > 0) {
        status = cuiFuncAlloc(ctx, ctx->api, cudbgDriverOptions.patchRamSize, CU_FUNC_DEFAULT_CODE_ALIGN, &patchMemobj);
        if (status != CUDA_SUCCESS) {
            res = CUDBG_ERROR_INTERNAL;
            CU_ERROR_PRINT(("Failed to allocate patchram\n"));
            CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C, res,
                                              CUDBG_ERROR_TYPE_DRIVER);
            CUDBG_BREAKCS(0);
        }

        tres = toolsHashMapInsert(cudbgPatchRamMap, tHashMapPtrToKey(ctx), patchMemobj);
        if (tres != TOOLS_SUCCESS) {
            res = CUDBG_ERROR_INTERNAL;
            CUDBG_ERROR("Failed to allocate function patch ram for context\n");
            CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C, res,
                                              CUDBG_ERROR_TYPE_DRIVER);
            CUDBG_BREAKCS(0);
        }
    }

    globalFocusCoordsAddr = (uint64_t)(uintptr_t)toolsHashMapFind(cudbgGlobalFocusCoordsMap, tHashMapPtrToKey(ctx));
    if (!globalFocusCoordsAddr && cudbgDriverOptions.patchRamSize) {
        void* focusCoords;
        status = cuiMemAlloc(ctx, globalFocusCoordsAllocSize, &focusCoords, NV_FALSE, CU_MEM_MAP_DEVICE_PTR);
        if (status != CUDA_SUCCESS) {
            res = CUDBG_ERROR_INTERNAL;
            CU_ERROR_PRINT(("Failed to allocate focus coordinates for contxt\n"));
            CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C, res,
                CUDBG_ERROR_TYPE_DRIVER);
            CUDBG_BREAKCS(0);
        }

        globalFocusCoordsAddr = (uint64_t)(uintptr_t)focusCoords;
        tres = toolsHashMapInsert(cudbgGlobalFocusCoordsMap, tHashMapPtrToKey(ctx), focusCoords);
        if (tres != TOOLS_SUCCESS) {
            res = CUDBG_ERROR_INTERNAL;
            CUDBG_ERROR("Failed to allocate focus coordinates for context\n");
            CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C, res,
                CUDBG_ERROR_TYPE_DRIVER);
            CUDBG_BREAKCS(0);
        }
    }

    /* On (sm_35) and higher:
       (1) we need to register the offsets of the arch (continuations) trap handler
       (2) we determine if preemption has been enabled by the debug client */
#endif

    /* Store the address and size of all device system calls */
    /* Explicitly register the hidden module and functions now, as they
       are only final at the time of this callback. */
    reportHiddenModules(ctx);

    /* get prt */
    if (ctx->syslib.prt)
        syscallRcVaddr = (uint64_t)(uintptr_t)memobjGetHostPtr(ctx->syslib.prt);

    haloDrvGetFuncMemBaseVA(ctx, &funcMemBaseVA);

    message.kind = dbgCtxCreation;
    message.cases.ctxCreation.patchRamDevVA = (patchMemobj ? (uint64_t)memobjGetDeviceVaddr(patchMemobj) : 0);
    message.cases.ctxCreation.patchRamSize = (patchMemobj ? (uint32_t)memobjGetSize(patchMemobj) : 0);
    message.cases.ctxCreation.scratchpadDevVA = memobjGetDeviceVaddr(scratchpadMemobj);
    message.cases.ctxCreation.scratchpadDevPtr = memobjGetDevicePtr(scratchpadMemobj);
    message.cases.ctxCreation.threadId = cudbgGetTid();
    message.cases.ctxCreation.ctx = (uint64_t) (uintptr_t)ctx;
    message.cases.ctxCreation.device = ctx->device->state.deviceIdx;
    message.cases.ctxCreation.launchBlocking = (bool)ctx->launchBlocking;
    message.cases.ctxCreation.preemptionType = preemptionType;
    message.cases.ctxCreation.syscallRcVaddr = syscallRcVaddr;
    message.cases.ctxCreation.thCodeVA = thCodeVA;
    message.cases.ctxCreation.thCodeSize = thCodeSize;
    message.cases.ctxCreation.thRdRegOffset = thRdRegOffset;
    message.cases.ctxCreation.thWrRegOffset = thWrRegOffset;
    message.cases.ctxCreation.thRdTexMemOffset = thRdTexMemOffset;
    message.cases.ctxCreation.numFdsTransferred = 0;
    message.cases.ctxCreation.funcMemBaseVA = funcMemBaseVA;
    message.cases.ctxCreation.cilpBufferDevVA = (uint64_t)(uintptr_t)cuiPreemptionGetPreemptionBuffer(ctx->preemption);
    message.cases.ctxCreation.shmemWindowDevVA = ctx->device->hal.getSharedWindowBase(ctx);
    message.cases.ctxCreation.lmemWindowDevVA =  ctx->device->hal.getLocalWindowBase(ctx);
    message.cases.ctxCreation.lmemSizePerSM =  ctx->lmemConfig.sizePerSM;
    message.cases.ctxCreation.gmemWindowDevVA =  ctx->device->hal.getDevicePtrHeapOffset(ctx);
    message.cases.ctxCreation.globalFocusCoordsAddr = (globalFocusCoordsAddr ? globalFocusCoordsAddr : 0);
    message.cases.ctxCreation.globalFocusCoordsAllocSize = globalFocusCoordsAllocSize;

    /* Starting in 285, the driver notifies the debugger backend when
       memcheck is active */
    message.cases.ctxCreation.memcheckEnabled = gpudbgIsMemcheckAttached();

    /* RM Debug Object support */
    cudbgGetRmCtxHandles(ctx, &hAppClient, &hComputeObject, &hChannelGroup,
                         hChannelList, CUDBG_MAX_CHANNELS, &computeChannelCount);

    message.cases.ctxCreation.hAppClient = hAppClient;
    message.cases.ctxCreation.hComputeObject = hComputeObject;
    message.cases.ctxCreation.hChannelGroup = hChannelGroup;
    message.cases.ctxCreation.computeChannelCount = computeChannelCount;
    memcpy(message.cases.ctxCreation.hChannelList, hChannelList, computeChannelCount * sizeof(*hChannelList));

    if (ctx->device->dmalType == CU_DMAL_WDDM) {
        KdDebugObject debugObject;
        
        res = globalKdApi[KDAPI_TYPE_WDDM]->allocDebugObject(ctx, &debugObject);
        if (res == CUDBG_SUCCESS) {
            message.cases.ctxCreation.hDebugObject = debugObject.wddm.handle;
        }
    }
    else if ((ctx->device->dmalType == CU_DMAL_RM) &&
             (globals.dm.rm->rmVersion >= 418)) { /* Bug 2312123 */
        KdDebugObject debugObject;

        res = globalKdApi[KDAPI_TYPE_RM]->allocDebugObject(ctx, &debugObject);
        if (res == CUDBG_SUCCESS) {
            message.cases.ctxCreation.hDebugObject = debugObject.rm.handle;
        }
    }

    /* Texture header/sampler handles */
    {
        NvU64 hdrVA, samplerVA;
        /* The temporaries below are needed to avoid alignment exceptions
           on ARM. The references to the locals are naturally aligned to
           the type size and can be directly dereferenced inside the call.
           The result is then copied into the struct members.
         */
        texHeaderSamplerPoolGetOffsets(ctx->texHeaderSamplerPool,
                                       &hdrVA, &samplerVA);

        message.cases.ctxCreation.texHeaderPoolVA = hdrVA;
        message.cases.ctxCreation.texSamplerPoolVA = samplerVA;
    }

    if (ctx->device->dmalType == CU_DMAL_MRM)  {
        /* Transferring the driver debug object as well */
        uint32_t n = 0;
        cudbgGetMRMCtxHandles(ctx, fdArray, fdArray+1, CUDBG_MAX_CHANNELS, &n);
        message.cases.ctxCreation.numFdsTransferred = n + 1;
    }

    CUDBG_PRINT(1, "Sending %d fds\n", message.cases.ctxCreation.numFdsTransferred);

    pushMessage(&message, sizeof message);

    /* Push the control message only after pushing data. This order only matters
     * for coredumps where we aren't really sending messages over pipes. */
    pushControlMessage(fdArray, message.cases.ctxCreation.numFdsTransferred * sizeof(*fdArray));

    sendMessage();

    CUDBG_LEAVECS(0);

    if (res != CUDBG_SUCCESS)
        return;

    /* There are two places where memblock notifications are re-sent to the
       debugger backend: here and in cudbgInitDebugger(). If there's a call
       to memblockFree between these two iterations over the memblock list,
       the first iteration could have reported a memblock which has since
       been freed (but the notification not sent because CUDBG_IPC_FLAG_NAME
       is not yet set). This opens the possibility of a invalid memory segment
       error due to a stale memblock allocation overlapping with a later one.

       Plug this by testing for debugger attachment before resending memblock
       notifications. If we're in the middle of late attach, this won't be set
       and we'll just depend on the re-sending of the notifications later in
       cudbgInitDebugger().
    */
    if (gpudbgDebuggerAttached() || cudbgIsCoredumpInProgress()) {
        /* Resend all memory notifications.
         * In cases where Attach state collection does not run, this ensures that
         * the backend knows about memblocks that have already been allocated. */
        CUDBG_PRINT(1, "Resending all memory notifications for context ctxId %d\n", ctx->ctxId);
        memmgrLock(ctx->memmgr);
        cudbgReportAllMemblocks_underLock(ctx);
        memmgrUnlock(ctx->memmgr);
    }
}

void
cudbgReportCtxDestroyBegin(CUctx *ctx, bool doLateCheck, uint32_t sessionId)
{
    CUDBGcommand message;

    CUDBG_ENTERCS(0);
    CU_TRACE_FUNCTION();

    if (doLateCheck && !gpudbgDebuggerAttached())
        CUDBG_BREAKCS(0);

    if (sessionId != gpudbgGetClientSessionId())
        CUDBG_BREAKCS(0);

    message.kind = dbgCtxDestructionBegin;
    message.cases.ctxDestructionBegin.ctx = (uint64_t)(uintptr_t)ctx;
    pushMessage(&message, sizeof(message));
    sendMessage();

    CUDBG_LEAVECS(0);
}

void
cudbgReportCtxDestroyEnd(CUctx *ctx, bool doLateCheck, uint32_t sessionId)
{
    CUDBGcommand message;
    TOOLSresult tres = TOOLS_SUCCESS;

    CUDBG_ENTERCS(0);
    CU_TRACE_FUNCTION();

    if (doLateCheck && !gpudbgDebuggerAttached())
        CUDBG_BREAKCS(0);

    if (sessionId != gpudbgGetClientSessionId())
        CUDBG_BREAKCS(0);

    tres = toolsHashMapRemove(cudbgPatchRamMap, tHashMapPtrToKey(ctx), NULL);
    if (tres != TOOLS_SUCCESS)
        CU_ERROR_PRINT(("Failed to remove reference to patch ram, ignoring...\n"));

    tres = toolsHashMapRemove(cudbgGlobalFocusCoordsMap, tHashMapPtrToKey(ctx), NULL);
    if (tres != TOOLS_SUCCESS)
        CU_ERROR_PRINT(("Failed to remove reference to global focus coords, ignoring...\n"));

    message.kind = dbgCtxDestructionEnd;
    message.cases.ctxDestructionEnd.ctx = (uint64_t) (uintptr_t)ctx;
    message.cases.ctxDestructionEnd.threadId = cudbgGetTid();
    pushMessage(&message, sizeof message);
    sendMessage();

    CUDBG_LEAVECS(0);
}

void
cudbgCtxPush(CUctx *ctx)
{
    CUDBGcommand message;

    CUDBG_ENTERCS(0);
    CU_TRACE_FUNCTION();

    message.kind = dbgCtxPush;
    message.cases.ctxPush.ctx = (uint64_t) (uintptr_t)ctx;
    message.cases.ctxPush.threadId = cudbgGetTid();
    pushMessage(&message, sizeof message);
    sendMessage();

    CUDBG_LEAVECS(0);
}

void
cudbgCtxPop(CUctx *ctx, CUctx *newCtx)
{
    CUDBGcommand message;

    CUDBG_ENTERCS(0);
    CU_TRACE_FUNCTION();

    message.kind = dbgCtxPop;
    message.cases.ctxPop.ctx = (uint64_t) (uintptr_t)ctx;
    message.cases.ctxPop.newCtx = (uint64_t) (uintptr_t)newCtx;
    message.cases.ctxPop.threadId = cudbgGetTid();
    pushMessage(&message, sizeof message);
    sendMessage();

    CUDBG_LEAVECS(0);
}


/*-------------------------------- Functions ---------------------------------*/

struct gpudbgModuleRec {
    uint64_t                 ctx;
    uint32_t                 devId;
    tHashMap                *functions;
    unsigned                 nameIndex;
    uintptr_t                handle;
    int                      threadId;
    tStringTable            *stringTable;
    bool                     internal;
    uint32_t                 visibility;
    bool                     launchBlocking;
    cudbgElfInfo            *elfInfo;
};

struct gpudbgFunctionRec {
    uintptr_t                handle;
    uint64_t                 ctx;
    unsigned                 nameIndex;
    gpudbgModule             module;
    bool                     hidden;
    uint64_t                 entry;
    uint64_t                 devvaddr;
    uint64_t                 spAssignmentAddr;
    uint32_t                 nrofRegisters;
    uint32_t                 codeSize;
    uint32_t                 stackSize;
    uint32_t                 frameSize;
    uint32_t                 localSize;
    uint32_t                 sharedSize;
    void                    *virtCodeAddr;
    bool                     global;
    uint32_t                 texRefCount;
    uint32_t                 numTexIdMapEntries;
    TexIdMap                 *texIdMap;
    bool                     usesCnp;
    bool                     usesContinuations;
    bool                     needsHostResume;
    bool                     isCnpCtxSync;
    struct gpudbgFunctionRec *next;
};

static CUDBGResult
gpudbgFindStackpointerAssignment(CUctx *ctx, gpudbgFunction function, CUfunc *func)
{
    uint32_t limit;
    uint64_t inst[2];
    uint64_t offset;
    bool abiCompilation;
    uint32_t assignmentIndex = 0;
    int32_t isStackPointerAssignment = 0;
    const elf64FileHeader *efh64;
    const elf32FileHeader *efh32;
    uint32_t abiVersion;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_ARGS, "Invalid context\n");
    CUDBG_VERIFY(ctx->device, CUDBG_ERROR_INVALID_ARGS, "Invalid device\n");

    CUDBG_VERIFY(function, CUDBG_ERROR_INVALID_ARGS, "Invalid function\n");
    CUDBG_VERIFY(function->module, CUDBG_ERROR_INVALID_ARGS, "Invalid function->module\n");

    CUDBG_VERIFY(func, CUDBG_ERROR_INVALID_ARGS, "Invalid function handle\n");
    CUDBG_VERIFY(func->mod, CUDBG_ERROR_INVALID_ARGS, "Invalid func->mod\n");

    function->spAssignmentAddr = 0;

    if (elf_is_64bit(func->mod->elf_image)) {
        efh64 = elf64_file_header(func->mod->elf_image);
        if (!efh64) {
            CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C,
                                              CUDBG_ERROR_INTERNAL,
                                              CUDBG_ERROR_TYPE_CUDBG);
            return CUDBG_ERROR_INTERNAL;
        }
        abiVersion = efh64->abiVersion;
    }
    else {
        efh32 = elf32_file_header(func->mod->elf_image);
        if (!efh32) {
            CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C,
                                              CUDBG_ERROR_INTERNAL,
                                              CUDBG_ERROR_TYPE_CUDBG);
            return CUDBG_ERROR_INTERNAL;
        }
        abiVersion = efh32->abiVersion;
    }
    abiCompilation = abiVersion >= ELFOSABIV_ABI;

    /* We only analyze ABI functions */
    if (!abiCompilation)
        return CUDBG_SUCCESS;

    /* Scan the function prologue looking for the stack pointer assignment
       Limit to the first 4 Volta instructions */
    limit = MIN(4 * sizeof inst, function->codeSize - 2 * sizeof inst);

    /* On some architectures the instruction address may need to be adjusted
       to account for OpEx's */
    res = haloDrvAdjustCodeAddress(ctx, 0, &offset, CUDBG_ADJ_CURRENT_ADDRESS);
    if (res != CUDBG_SUCCESS) {
        CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C,
                                          CUDBG_ERROR_INTERNAL,
                                          CUDBG_ERROR_TYPE_CUDBG);
        return res;
    }

    while (offset < limit) {
        /* This reads one or two instructions. Some chips may need this in order
           to identify the assignment -- this is handled in isStackPointerAssignment(). */

        res = haloDrvIsStackPointerAssignment(ctx,
                                              (uint64_t *)&((uint8_t *)function->virtCodeAddr)[offset],
                                              &isStackPointerAssignment,
                                              &assignmentIndex);
        if (res != CUDBG_SUCCESS) {
            CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C,
                                              CUDBG_ERROR_INTERNAL,
                                              CUDBG_ERROR_TYPE_CUDBG);
            return res;
        }

        if (isStackPointerAssignment) {
            function->spAssignmentAddr = (uint64_t)(uintptr_t)function->virtCodeAddr
                + offset + assignmentIndex*sizeof(inst[0]);
            break;
        }

        /* On some architectures the instruction address may need to be adjusted
           to account for OpEx's */
        res = haloDrvAdjustCodeAddress(ctx, offset, &offset, CUDBG_ADJ_NEXT_ADDRESS);
        if (res != CUDBG_SUCCESS) { 
            CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C,
                                              CUDBG_ERROR_INTERNAL,
                                              CUDBG_ERROR_TYPE_CUDBG);
            return res;
        }
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
gpudbgAnalyzeFunction(CUctx *ctx, gpudbgFunction function, CUfunc *func)
{
    CUDBGResult res;

    res = gpudbgFindStackpointerAssignment(ctx, function, func);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Error finding stackpointer assignment.\n");
        CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C,
                                          CUDBG_ERROR_INTERNAL, CUDBG_ERROR_TYPE_CUDBG);
        return res;
    }

    return CUDBG_SUCCESS;
}

static gpudbgFunction
gpudbgRegisterFunction(gpudbgModule  tmpmod,
                       char          *name,
                       CUfunc       *handle,
                       bool          hidden,
                       uint64_t      entry,
                       uint64_t      devvaddr,
                       uint32_t      nrofRegisters,
                       uint32_t      stackSize,
                       uint32_t      frameSize,
                       uint32_t      localSize,
                       uint32_t      sharedSize,
                       uint32_t      texRefCount,
                       CUfuncType    type,
                       bool          usesCnp,
                       bool          usesContinuations,
                       bool          needsHostResume,
                       bool          isCnpCtxSync)
{
    /* CUdeviceptrs are 32-bits, so we will intialize to 0. */
    gpudbgFunction result;
    CUDBGResult res;
    CUctx *ctx;

    CU_TRACE_FUNCTION();

    /* Sanity checks */
    if (!handle || !handle->mod) {
        CUDBG_ERROR("Invalid arguments when calling gpudbgRegisterFunction.\n");
        CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C, CUDBG_ERROR_INTERNAL, CUDBG_ERROR_TYPE_CUDBG);
        return NULL;
    }

    /* Obtain the context from the function's module pointer */
    ctx = ((CUmod *)handle->mod)->ctx;
    if (!ctx) {
        CUDBG_ERROR("Invalid context when calling gpudbgRegisterFunction.\n");
        CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C, CUDBG_ERROR_INTERNAL, CUDBG_ERROR_TYPE_CUDBG);
        return NULL;
    }

    if (CUDA_SUCCESS != cuiFuncDuplicateBinaries(handle)) {
        CUDBG_ERROR("Failed to prepare function for the debugger when calling gpudbgRegisterFunction\n");
        CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C, CUDBG_ERROR_INTERNAL, CUDBG_ERROR_TYPE_CUDBG);
        return NULL;
    }

    result = (gpudbgFunction)calloc(1, sizeof(*result));
    result->ctx                 = (uint64_t)(uintptr_t)tmpmod->ctx;
    result->handle              = (uintptr_t)handle;
    result->entry               = entry;
    result->devvaddr            = devvaddr;
    result->module              = tmpmod;
    result->hidden              = hidden;
    result->nrofRegisters       = nrofRegisters;
    result->codeSize            = handle->codeSize;
    result->stackSize           = stackSize;
    result->frameSize           = frameSize;
    result->localSize           = localSize;
    result->sharedSize          = sharedSize;
    result->texRefCount         = texRefCount;
    result->global              = (type == CU_FUNC_TYPE_GLOBAL);
    result->nameIndex           = (unsigned int)toolsStringTableAddString(tmpmod->stringTable, name);
    result->virtCodeAddr        = (void*)cuiFuncGetCodeData(handle, CU_CODE_DATA_MASTER);
    result->numTexIdMapEntries  = 0;
    result->usesCnp             = usesCnp;
    result->usesContinuations   = usesContinuations;
    result->needsHostResume     = needsHostResume;
    result->isCnpCtxSync        = isCnpCtxSync;
    result->next                = NULL;
    toolsHashMapInsert(tmpmod->functions, tHashMapNumToKey(result->devvaddr), (void*)result);

    /* Attempt to analyze the function */

    res = gpudbgAnalyzeFunction((CUctx *)(uintptr_t)tmpmod->ctx, result, handle);
    if (res != CUDBG_SUCCESS)
        CUDBG_ERROR("Could not analyze function (%d)\n", res);

    return result;
}

static void
registerFunction(gpudbgFunction f)
{
    uint64_t prologueOffset, prologueSize, prologueDevVAddr;
    CUDBGcommand message;

    prologueOffset = 0;
    prologueSize = 0;
    prologueDevVAddr = 0;

    message.kind = dbgRegisterFunction;
    message.cases.registerFunction.ctx               = f->module->ctx;
    message.cases.registerFunction.handle            = f->handle;
    message.cases.registerFunction.module            = f->module->handle;
    message.cases.registerFunction.hidden            = f->hidden;
    message.cases.registerFunction.gpuAddrBase       = (uint64_t)(uintptr_t)f->entry;
    message.cases.registerFunction.virtAddrBase      = (uint64_t)(uintptr_t)f->virtCodeAddr;
    message.cases.registerFunction.devVAddr          = f->devvaddr;
    message.cases.registerFunction.prologueOffset    = prologueOffset;
    message.cases.registerFunction.prologueSize      = prologueSize;
    message.cases.registerFunction.prologueDevVAddr  = prologueDevVAddr;
    message.cases.registerFunction.spAssignmentAddr  = f->spAssignmentAddr;
    message.cases.registerFunction.codeSize          = f->codeSize;
    message.cases.registerFunction.stackSize         = f->stackSize;
    message.cases.registerFunction.frameSize         = f->frameSize;
    message.cases.registerFunction.nrofRegisters     = f->nrofRegisters;
    message.cases.registerFunction.texRefCount       = f->texRefCount;
    message.cases.registerFunction.global            = f->global;
    message.cases.registerFunction.nameIndex         = f->nameIndex;
    message.cases.registerFunction.usesCnp           = f->usesCnp;
    message.cases.registerFunction.usesContinuations = f->usesContinuations;
    message.cases.registerFunction.needsHostResume   = f->needsHostResume;
    message.cases.registerFunction.isCnpCtxSync      = f->isCnpCtxSync;
    message.cases.registerFunction.numTexIdMapEntries = f->numTexIdMapEntries;
    pushMessage(&message, sizeof message);
    if (f->numTexIdMapEntries > 0) {
        pushMessage(f->texIdMap, f->numTexIdMapEntries * sizeof(TexIdMap));
    }
    sendMessage();
}

static TOOLSresult
registerFunctionWrap(tHashMapKey_t key, void *entry, void *data)
{
    registerFunction((gpudbgFunction)entry);
    return TOOLS_SUCCESS;
}

static void
deleteFunction(gpudbgFunction function)
{
    if (function->texIdMap)
        free(function->texIdMap);
    free(function);
}

static void
deleteFunctionWrap(void *value, void *functor_data)
{
    deleteFunction((gpudbgFunction)value);
}

/*-------------------------------- Functions ---------------------------------*/


void gpudbgReportDeviceExecutionLaunch(CUctx *               ctx,
                                       CUfunc *              func,
                                       CUdim3                gridDim,
                                       CUdim3                blockDim,
                                       uint64_t              gridId64,
                                       uint64_t              funcMemBaseVA,
                                       uint64_t              qmdDptr,
                                       uint64_t              streamId)
{
    CUDBGcommand message;

    CUDBG_ENTERCS(0);
    CU_TRACE_FUNCTION();

    /* ReportDeviceExecutionLaunch is a fast path callback and should be used
     * sparingly if at all.  Unfortunately, there's still some cases where it is
     * required, namely:
     *  - KILP: need kilp specific addresses not in the scratchpad
     *  - <GK11x: <SM_35 doesn't have GETLMEMBASE, thus lmemSizePrSM needs to be given since global PRI is going away
     *  - launch blocking: need to report launches so rpcd can report it in the api
     */
    if (!(ctx->kilp ||
          cudbgLaunchBlocking(ctx) ||
          !cuiDeviceArchIsKeplerGK11XPlus(ctx->device))) {
        if (!cudbgDriverOptions.reportKernelLaunches) {
            CUDBG_TRACE("Skipping reporting of device execution launch\n");
            goto early_exit;
        }
    }

    /* KILP/CNP:  On architectures that use it, track addresses in global memory
       that point to items such as the cta context and controller data. */
    if (cuiCnpIsSupported(ctx) && ctx->cnp) {
        message.cases.deviceExecutionLaunch.ctaContextIndirectionTableAddr = ctx->cnp->ctaContextIndirectionTable;
        if (ctx->kilp) {
            message.cases.deviceExecutionLaunch.kilpControllerDataAddr = ctx->kilp->kilpControllerData;
            message.cases.deviceExecutionLaunch.kilpCtaIlpEnableTableAddr = ctx->kilp->kilpCtaIlpEnableTable;
            message.cases.deviceExecutionLaunch.kilpCtaStopContinuations = ctx->kilp->kilpCtaStopContinuations;
        }
    }

    message.kind = dbgReportDeviceExecutionLaunch;
    message.cases.deviceExecutionLaunch.ctx            = (uint64_t)(uintptr_t) ctx;
    message.cases.deviceExecutionLaunch.module         = (uint64_t)(uintptr_t)(func->mod);
    message.cases.deviceExecutionLaunch.function       = (uint64_t)(uintptr_t) func;
    message.cases.deviceExecutionLaunch.gridDim.x      = gridDim.x;
    message.cases.deviceExecutionLaunch.gridDim.y      = gridDim.y;
    message.cases.deviceExecutionLaunch.gridDim.z      = gridDim.z;
    message.cases.deviceExecutionLaunch.blockDim.x     = blockDim.x;
    message.cases.deviceExecutionLaunch.blockDim.y     = blockDim.y;
    message.cases.deviceExecutionLaunch.blockDim.z     = blockDim.z;
    message.cases.deviceExecutionLaunch.gridId64       = gridId64;
    message.cases.deviceExecutionLaunch.funcMemBaseVA  = funcMemBaseVA;
    message.cases.deviceExecutionLaunch.qmdDptr        = qmdDptr;
    /* At any point before now, lmemSizePerSM can change (tools, module loads,
       etc).  After launch, the context's lmemConfig is locked until
       waitForIdle.  This also allows us to update the lmemSize each launch. */
    message.cases.deviceExecutionLaunch.lmemSizePerSM  = ctx->lmemConfig.sizePerSM;
    message.cases.deviceExecutionLaunch.streamId       = streamId;

    pushMessage(&message, sizeof message);
    sendMessage();

early_exit:
    CUDBG_LEAVECS(0);
}

void gpudbgReportDeviceExecutionStop(CUctx *ctx, void *function, uint64_t gridId64)
{
    CUfunc *func;
    CUDBGcommand message;

    CUDBG_ENTERCS(0);
    CU_TRACE_FUNCTION();

    func = (CUfunc*) function;

    message.kind = dbgReportDeviceExecutionStop;
    message.cases.deviceExecutionStop.ctx      = (uint64_t)(uintptr_t)ctx;
    message.cases.deviceExecutionStop.module   = (uint64_t)(uintptr_t)(func->mod);
    message.cases.deviceExecutionStop.function = (uint64_t)(uintptr_t)function;
    message.cases.deviceExecutionStop.gridId64 = gridId64;
    pushMessage(&message, sizeof message);
    sendMessage();

    CUDBG_LEAVECS(0);
}

static void
createPatchMessage(CUDBGcommand *message, void *cuctx, uint32_t kind,
                   uint64_t devvaddr, uint64_t gpuPCOffset, uint32_t patchSize,
                   uint64_t patchEntryAddr, bool isMultiEntry,
                   uint64_t* origInst, uint32_t instSz, uint32_t depth)
{
    if (!message)
        return;

    message->kind = dbgReportPatch;
    message->cases.reportPatch.context          = (uint64_t)(uintptr_t)cuctx;
    message->cases.reportPatch.kind             = kind;
    message->cases.reportPatch.devVAddr         = devvaddr;
    message->cases.reportPatch.gpuPCOffset      = gpuPCOffset;
    message->cases.reportPatch.patchSize        = patchSize;
    message->cases.reportPatch.patchEntryAddr   = patchEntryAddr;
    message->cases.reportPatch.isMultiEntry     = isMultiEntry;
    message->cases.reportPatch.depth            = depth;

    if (instSz > sizeof(message->cases.reportPatch.origInst)) {
        CUDBG_ERROR("original instruction size is larger than message buffer!\n");
        CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C, CUDBG_ERROR_INTERNAL, CUDBG_ERROR_TYPE_CUDBG);
        return;
    }

    if (instSz)
        memcpy(message->cases.reportPatch.origInst, origInst, instSz);

#ifndef RELEASE
    if (patchSize)
        message->cases.reportPatch.virtAddr     = (uint64_t)(uintptr_t) malloc(patchSize);
#endif
}

void
gpudbgReportPatch(void *cuctx, uint32_t kind, uint64_t devvaddr,
                  uint64_t gpuPCOffset, uint32_t patchSize,
                  uint64_t patchEntryAddr, bool isMultiEntry,
                  uint64_t* origInst, uint32_t instSz, uint32_t depth)
{
    CUDBGcommand message;

    CUDBG_ENTERCS(0);
    CU_TRACE_FUNCTION();

    memset(&message, 0, sizeof message);
    createPatchMessage(&message, cuctx, kind, devvaddr, gpuPCOffset, patchSize,
                       patchEntryAddr, isMultiEntry, origInst, instSz, depth);

    pushMessage(&message, sizeof message);
    sendMessage();

    CUDBG_LEAVECS(0);
}

void
gpudbgUnreportPatch(void *cuctx, uint32_t kind, uint64_t devvaddr, uint64_t gpuPCOffset, uint32_t patchSize, uint64_t patchEntryAddr)
{
    CUDBGcommand message;

    CUDBG_ENTERCS(0);
    CU_TRACE_FUNCTION();

    memset(&message, 0, sizeof message);
    message.kind = dbgUnreportPatch;
    message.cases.unreportPatch.context          = (uint64_t)(uintptr_t)cuctx;
    message.cases.unreportPatch.kind             = kind;
    message.cases.unreportPatch.devVAddr         = devvaddr;
    message.cases.unreportPatch.gpuPCOffset      = gpuPCOffset;
    message.cases.unreportPatch.patchSize        = patchSize;
    message.cases.unreportPatch.patchEntryAddr   = patchEntryAddr;

    pushMessage(&message, sizeof message);
    sendMessage();

    CUDBG_LEAVECS(0);
}

void
gpudbgResetFunctionBreakpoints(CUctx *cuctx, CUfunc *func)
{
    CUDBGcommand message;

    CUDBG_ENTERCS(0);
    CU_TRACE_FUNCTION();

    memset(&message, 0, sizeof message);
    message.kind = dbgResetFunctionBreakpoints;
    message.cases.resetFunctionBreakpoints.context  = (uint64_t)(uintptr_t)cuctx;
    message.cases.resetFunctionBreakpoints.module   = (uint64_t)(uintptr_t)(func->mod);
    message.cases.resetFunctionBreakpoints.function = (uint64_t)(uintptr_t)func;

    pushMessage(&message, sizeof message);
    sendMessage();

    CUDBG_LEAVECS(0);
}

typedef CUresult (CUDAAPI *cudartGetEtbl)(const void **ppExportTable,
                                          const CUuuid *pExportTableId);

CUresult
cudbgApiErrorCheck(uint32_t status, const char *funcName, uint32_t isRuntime,
                   void* cudartEtbl)
{
    CUresult rStatus;
    uint32_t flags = 0;
    cudaError_t errorNotReady = cudaErrorNotReady;

    if (isRuntime && cudartEtbl) {
        CUresult res = CUDA_SUCCESS;
        cudartGetEtbl pfn = (cudartGetEtbl)cudartEtbl;
        CUetblToolsRuntimeInstance *rtInst = NULL;
        int32_t version;

        res = pfn((const void**)&rtInst, &CU_ETID_ToolsRuntimeInstance);
        if (res != CUDA_SUCCESS) {
            return res;
        }

        res = rtInst->GetVersion(&version);
        if (res != CUDA_SUCCESS) {
            return res;
        }

        if (version < 10010) {
            /* Before CUDA 10.1 cudaErrorNotReady was set to 34. */
            errorNotReady = (cudaError_t)34;
        }
    }

    /* If the error is cudaErrorNotReady and the API is runtime
       or the error is CUDA_ERROR_NOT_READY and API is driver  */

    if ((status == errorNotReady && isRuntime) ||
        (status == (uint32_t)CUDA_ERROR_NOT_READY && !isRuntime))
        flags |= CUDBG_REPORT_DRIVER_API_ERROR_FLAGS_SUPPRESS_NOT_READY;

    rStatus = (CUresult) status;
    CUDBG_RAISE_DRIVER_API_ERROR(rStatus, funcName, flags);

    return CUDA_SUCCESS;
}
/* ----------------------- ELF COMPILATION PATH BELOW ----------------------- */

/*
 * Function        : Internally relocates the ELF image
 * Parameters      : elf_image              (I) The unrelocated ELF image
 *                   elf_image_size         (I) The size of the ELF image
                     relocatedElfImage      (O) Copy of the relocated ELF image
 *                   tmpmod                 (I) The temporary module
 * Function Result : None
 */
static void
gpudbgRelocateElfImage(elf_t elf_image,
                       uint64_t elf_image_size,
                       elf_t relocatedElfImage,
                       gpudbgModule tmpmod)
{
    CU_TRACE_FUNCTION();

    /* Relocate all globals/functions in the ELF image with tagged
     * host addresses, so that the debugger can work with the image.
     * This function will take care of copying the image over */
    cudbgRelocateElfXXImage(relocatedElfImage, tmpmod->elfInfo);
}


/*
 * Function        : Exports the ELF image to the debugger process space
 * Parameters      : elf_image              (I) The unrelocated ELF image
 *                   elf_image_size         (I) The size of the ELF image
                     relocatedElfImage      (I) Copy of the relocated ELF image
                     nonRelocatedElfImage   (I) Copy of the unrelocated ELF image
 *                   tmpmod                 (I) The temporary module
 * Function Result : None
 */
static void
gpudbgExportElfImage(elf_t elf_image,
                     uint64_t elf_image_size,
                     elf_t relocatedElfImage,
                     elf_t nonRelocatedElfImage,
                     gpudbgModule tmpmod)
{
    CUDBGcommand message;

    CU_TRACE_FUNCTION();

    message.kind = dbgExportElfImage;
    message.cases.exportElfImage.ctx            = tmpmod->ctx;
    message.cases.exportElfImage.elf_image_size = elf_image_size;
    message.cases.exportElfImage.mod_handle     = (uint64_t)(uintptr_t)tmpmod->handle;
    pushMessage(&message, sizeof message);
    pushMessage(relocatedElfImage, elf_image_size);
    pushMessage(nonRelocatedElfImage, elf_image_size);
    sendMessage();
}

/*
 * Function        : Register an ELF module (instead of the 'old' cubin w/ptxmap)
 * Parameters      : fatBinary      (I) The aplication's handle to the loaded
 *                                      cubin
 *                   handle         (I) Identification of client for subsequent
 *                                      operations
 * Function Result : Temporary module handle, for use during function registration
 */
static gpudbgModule
gpudbgRegisterElfModule(CUctx *ctx,
                        const char *ident,
                        CUmod *handle,
                        uint32_t devId,
                        bool internal,
                        uint32_t visibility,
                        bool launchBlocking,
                        elf_t elf_image,
                        size_t elf_image_size)
{
    gpudbgModule result = NULL;

    CU_TRACE_FUNCTION();

    result = (gpudbgModule)calloc(1, sizeof(*result));
    result->devId = devId;
    result->threadId = cudbgGetTid();
    result->ctx = (uint64_t)(uintptr_t)ctx;
    result->handle = (uintptr_t)handle;
    result->internal = internal;
    result->visibility = visibility;
    result->functions = toolsHashMapNew(toolsPointerHashFun, toolsPointerEqualFun, 17);
    result->stringTable = toolsStringTableNew(128);
    result->nameIndex = (unsigned int)toolsStringTableAddString(result->stringTable, ident);
    result->launchBlocking = launchBlocking;

    result->elfInfo = cudbgElfXXCreateModule(elf_image, elf_image_size);
    if (!result->elfInfo) {
        CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C, CUDBG_ERROR_INTERNAL, CUDBG_ERROR_TYPE_CUDBG);
        free(result);
        return NULL;
    }

    return result;
}

/*
 * Function        : Zero out sections related to symbols marked as hidden by the compiler
 * Parameters      : elf            (I) The ELF image
 * Function Result : None
 */
static void
gpudbgStripHiddenElfSymbols(void *elf)
{
    if (isELF64((const char *)elf)) {
        toolsElf64StripHiddenSymbols(elf);
    }
    else {
        toolsElf32StripHiddenSymbols(elf);
    }
}

/*
 * Function        : Delete temporary module handle that was used for function
 *                   registration (ELF-specific)
 * Parameters      : tmpmod         (I) Temporary module handle returned by
 *                                      gpudbgRegisterElfModule
 *                   elf_image      (I) The unrelocated ELF image
 *                   elf_image_size (I) The size of the ELF image
 * Function Result : None
 */
static void
gpudbgDeleteElfModuleHandle(gpudbgModule tmpmod,
                            elf_t elf_image,
                            uint64_t elf_image_size)
{
    char *stringTable;
    unsigned int stringTableSize;
    CUDBGcommand message;
    elf_t relocatedElfImage, nonRelocatedElfImage;

    CU_TRACE_FUNCTION();

    stringTable = (char*)toolsStringTableGetTable(tmpmod->stringTable);
    stringTableSize = (unsigned int)toolsStringTableGetSize(tmpmod->stringTable);

    message.kind = dbgRegisterModule;
    message.cases.registerModule.ctx = tmpmod->ctx;
    message.cases.registerModule.handle = tmpmod->handle;
    message.cases.registerModule.threadId = tmpmod->threadId;
    message.cases.registerModule.stringTableSize = stringTableSize;
    message.cases.registerModule.nameIndex = tmpmod->nameIndex;
    message.cases.registerModule.devId = tmpmod->devId;
    message.cases.registerModule.internal = tmpmod->internal;
    message.cases.registerModule.visibility = tmpmod->visibility;
    message.cases.registerModule.launchBlocking = tmpmod->launchBlocking;
    pushMessage(&message, sizeof message);
    pushMessage(stringTable, stringTableSize);
    sendMessage();

    nonRelocatedElfImage = malloc((size_t)elf_image_size);
    if (!nonRelocatedElfImage) {
        return;
    }
    memcpy(nonRelocatedElfImage, elf_image, (size_t)elf_image_size);

    relocatedElfImage = malloc((size_t)elf_image_size);
    if (!relocatedElfImage) {
        free(nonRelocatedElfImage);
        return;
    }
    gpudbgRelocateElfImage(elf_image, elf_image_size,
                           relocatedElfImage,
                           tmpmod);

    toolsHashMapApplyFunctor(tmpmod->functions, registerFunctionWrap, NULL);

    if (tmpmod->visibility == CU_MOD_VISIBILITY_HIDDEN_USER) {
        /* If the module is visible, we need to strip the hidden symbols */
        gpudbgStripHiddenElfSymbols((void *)relocatedElfImage);
        gpudbgStripHiddenElfSymbols((void *)nonRelocatedElfImage);
    }

    /* Pass the relocated elf image to the debugger process */
    gpudbgExportElfImage(elf_image, elf_image_size,
                         relocatedElfImage, nonRelocatedElfImage,
                         tmpmod);

    /* The function is freed when the associated ctx is destroyed */
    free(relocatedElfImage);
    free(nonRelocatedElfImage);
    cudbgElfXXDestroyModule(tmpmod->elfInfo);
    toolsHashMapDelete(tmpmod->functions, deleteFunctionWrap, NULL);
    tmpmod->functions = NULL;
    toolsStringTableDelete(tmpmod->stringTable);
    free(tmpmod);
}

/*
 * Function        : Save off the constant bank offset corresponding to the
 *                   given texId. This is needed only on Kepler for bindless
 *                   textures, where the texture instructions pull the
 *                   texture/sampler header from const memory.
 * Parameters      : func            (I) Temporary function
 *                   texId           (I) Texture id
 *                   constBankOffset (I) Constant bank offset
 * Function Result : None
 */
void
cudbgSaveTexIdToConstBankMap(gpudbgFunction function,
                             uint64_t texId,
                             uint64_t constBankOffset)
{
    if (!function) {
        CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C,
                                          CUDBG_ERROR_INTERNAL,
                                          CUDBG_ERROR_TYPE_CUDBG);
        return;
    }

    uint32_t index = function->numTexIdMapEntries;

    /* Allocate in groups of CUDBG_TEXIDMAP_ALLOC_CHUNK_SIZE */
    if (!(index % CUDBG_TEXIDMAP_ALLOC_CHUNK_SIZE)) {
        uint32_t count = ((index / CUDBG_TEXIDMAP_ALLOC_CHUNK_SIZE) + 1)
            * CUDBG_TEXIDMAP_ALLOC_CHUNK_SIZE;
        /* realloc() acts like malloc() when ptr is NULL */
        function->texIdMap = (TexIdMap *)realloc(function->texIdMap,
                                                    count * sizeof(TexIdMap));
        if (function->texIdMap == NULL) {
            /* Failed to allocate (or re-allocate) the TexIdMap[] */
            CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C,
                                                CUDBG_ERROR_INTERNAL,
                                                CUDBG_ERROR_TYPE_CUDBG);
            return;
        }
        /* Clear the newly allocated indexes */
        memset(&function->texIdMap[index], 0,
                CUDBG_TEXIDMAP_ALLOC_CHUNK_SIZE * sizeof(TexIdMap));
    }

    function->numTexIdMapEntries++;

    function->texIdMap[index].texId = texId;
    function->texIdMap[index].constBankOffset = constBankOffset;
}

/************************  Tools API reporting functions **********************/
void cudbgReportMemblockAlloc(CUctx *context, CUmemblock *memblock,
                              bool doLateCheck, uint32_t sessionId)
{
    CUDBGcommand message;

    if (!memblock || !memblock->memdesc.flags.mapDevice || !memblock->hasBeenMappedForDevice)
        return;

    CUDBG_ENTERCS(0);
    CU_TRACE_FUNCTION();

    if (doLateCheck && !gpudbgDebuggerAttached())
        CUDBG_BREAKCS(0);

    if (sessionId != gpudbgGetClientSessionId())
        CUDBG_BREAKCS(0);

    message.kind = dbgMemblockAlloc;

    message.cases.memblockAlloc.devId       = memblock->memmgr->device->state.deviceIdx;
    message.cases.memblockAlloc.threadId    = cudbgGetTid();
    if (context)
        message.cases.memblockAlloc.launchBlocking = context->launchBlocking;

    /* Fill in the rest of the message */
    cudbgMemblockGetSegInfo(memblock, &message.cases.memblockAlloc.segInfo);

#if cuosOsIsQnx()
    /* On QNX, the dmal handle is not an FD, but some special ID, so it cannot be duplicated
     * by sending over a unix domain socket, which is what happens in the Linux MRM case below.
     * This ID is duplicated later with NvRmMemHandleFromId. For history, see bug 1944624. */
    message.cases.memblockAlloc.memHandleId =
        NvRmMemGetId(message.cases.memblockAlloc.segInfo.dmalHandle);
#endif

    pushMessage(&message, sizeof message);

    /* On MRM (except for QNX) the dmal handle is an FD, so it can be duplicated by sending
     * over a unix domain socket. The control message is pushed only after pushing data.
     * This order only matters for coredumps where we aren't really sending messages over pipes. */

#if !cuosOsIsQnx()
    if (memblock->memmgr->device->dmalType == CU_DMAL_MRM)
        pushControlMessage(&message.cases.memblockAlloc.segInfo.dmalHandle,
                           sizeof message.cases.memblockAlloc.segInfo.dmalHandle);
#endif

    sendMessage();

    CUDBG_LEAVECS(0);
}

void cudbgReportMemblockFree(CUctx *context,
                             CUmemblock *memblock,
                             uint64_t devvaddr,
                             uint64_t size,
                             bool doLateCheck,
                             uint32_t sessionId)
{
    CUDBGcommand message;

    if (!memblock || !memblock->memdesc.flags.mapDevice || !memblock->hasBeenMappedForDevice)
        return;

    CUDBG_ENTERCS(0);
    CU_TRACE_FUNCTION();

    if (doLateCheck && !gpudbgDebuggerAttached())
        CUDBG_BREAKCS(0);

    if (sessionId != gpudbgGetClientSessionId())
        CUDBG_BREAKCS(0);

    message.kind = dbgMemblockFree;

    message.cases.memblockFree.ctx         = (uint64_t)(uintptr_t)context;
    message.cases.memblockFree.hostHandle  = (uint64_t)(uintptr_t)memblock;
    message.cases.memblockFree.devvaddr    = devvaddr;
    message.cases.memblockFree.size        = size;
    
    if (memblock->memdesc.flags.sharing == CU_MEM_SHARING_EXTERNAL_HOST_ADDRESS) {
        message.cases.memblockFree.devvaddr = (uint64_t)(uintptr_t)memblock->memdesc.memshare.orighostvaddr;
        message.cases.memblockFree.size     = (uint64_t)memblock->memdesc.memshare.orighostsize;
    }
    
    pushMessage(&message, sizeof message);
    sendMessage();

    CUDBG_LEAVECS(0);
}

void cudbgReportHostLmemResize(CUctx *context,
                               uint64_t devvaddr,
                               uint64_t size,
                               bool doLateCheck,
                               uint32_t sessionId)
{
    CUDBGcommand message;

    CUDBG_ENTERCS(0);
    CU_TRACE_FUNCTION();

    if (doLateCheck && !gpudbgDebuggerAttached())
        CUDBG_BREAKCS(0);

    if (sessionId != gpudbgGetClientSessionId())
        CUDBG_BREAKCS(0);

    message.kind = dbgHostLmemResize;

    message.cases.hostLmemResize.ctx         = (uint64_t)(uintptr_t)context;
    message.cases.hostLmemResize.devvaddr    = devvaddr;
    message.cases.hostLmemResize.size        = size;
    pushMessage(&message, sizeof message);
    sendMessage();

    CUDBG_LEAVECS(0);
}

void cudbgReportSystemStackResize(CUctx *context,
                                  uint64_t size,
                                  bool doLateCheck,
                                  uint32_t sessionId)
{
    CUDBGcommand message;

    CUDBG_ENTERCS(0);
    CU_TRACE_FUNCTION();

    if (doLateCheck && !gpudbgDebuggerAttached())
        CUDBG_BREAKCS(0);

    if (sessionId != gpudbgGetClientSessionId())
        CUDBG_BREAKCS(0);

    message.kind = dbgSystemStackResize;

    message.cases.systemStackResize.context             = (uint64_t)(uintptr_t)context;
    message.cases.systemStackResize.syscallStackSize    = size;
    pushMessage(&message, sizeof message);
    sendMessage();

    CUDBG_LEAVECS(0);
}

/************************  End of Tools API reporting functions ***************/

void
cudbgMemblockGetSegInfo(CUmemblock *memblock, CUDBGmemory_segment *seg)
{
    CUmemblock *dmalMemblock = NULL;
    uint64_t devptr = 0;
    uint32_t hasDevPtr = 0;
    uint32_t dmalHandle = 0;
    (void)dmalHandle;

    if (!memblock || !seg)
        return;

    seg->rmClient = globals.rmClient;
    dmalMemblock = (memblock->sourceMemblock) ? memblock->sourceMemblock : memblock;
    seg->sourceDeviceIdx = dmalMemblock->memmgr->device->state.deviceIdx;

    switch (dmalMemblock->memmgr->device->dmalType) {
    case CU_DMAL_RM:
        if (!(memmgrVaSpaceIsOwnedByUvm(dmalMemblock->memmgr) &&
              (memflagsIsManagedMem(dmalMemblock->memdesc.flags) || (memblock->memdesc.flags.type == CU_MEM_TYPE_UVM_SEMAPHORE)))) {
            CU_ASSERT(dmalMemblock->dm.rm->memDeviceBlock);
            seg->dmalHandle = dmalMemblock->dm.rm->memDeviceBlock->subblocks[0].rmHandle;
        }
        break;
#if cuosPlatformIncludesMrm()
    case CU_DMAL_MRM:
        /* Take the address of a local variable instead of a packed field. */
        dmalMemblock->memmgr->dmal.memblockGetMemHandle(dmalMemblock, &dmalHandle);
        seg->dmalHandle = dmalHandle;
        /* Somewhat copy and paste from mrm_mem.c, awaiting interface from MRM (bug 1805532) */
        seg->usesNvmap = !(dmalMemblock->memmgr->device->dm.mrm->nvRmGpuDeviceInfo->gpuType == NvRmGpuType_dGPU
                          && dmalMemblock->memdesc.flags.location == CU_MEM_LOCATION_DEVICE
                          && dmalMemblock->memmgr->device->dm.mrm->nvRmGpuDeviceInfo->localVideoMemoryBytes > 0);
        break;
#endif
    case CU_DMAL_MPS:
        seg->dmalHandle = dmalMemblock->dm.mps->rmHandle;
        seg->rmClient = dmalMemblock->dm.mps->rmClient;
        break;
    default:
        break;
    }

    hasDevPtr = (uint32_t)memblock->hasBeenMappedForDevice;
    if (hasDevPtr)
        devptr = (uint64_t)memblock->devvaddr;

    seg->ctx            = (uint64_t)(uintptr_t)memblock->memmgr->ctx;
    seg->hostHandle     = (uint64_t)(uintptr_t)memblock;
    seg->sourceMemblock = (uint64_t)(uintptr_t)memblock->sourceMemblock;
    seg->devvaddr       = (uint64_t)memblock->devvaddr;
    seg->size           = (uint64_t)memblock->size;
    seg->hostvaddr      = (uint64_t)(uintptr_t)memblock->hostvaddr;
    seg->mapDevice      = (uint32_t)memblock->memdesc.flags.mapDevice;
    seg->hasDevPtr      = hasDevPtr;
    seg->devptr         = devptr;
    seg->uvavaddr       = (uint64_t)memblock->uvavaddr;
    seg->type           = (uint32_t)memblock->memdesc.flags.type;
    seg->apiSource      = (uint32_t)memblock->memdesc.flags.apiSource;
    seg->location       = (uint32_t)memblock->memdesc.flags.location;
    seg->owner          = (uint32_t)memblock->memdesc.flags.owner;
    seg->sharing        = (uint32_t)memblock->memdesc.flags.sharing;
    seg->userOwnsData   = (uint32_t)memblock->memdesc.flags.userOwnsData;

    if (seg->sharing == CU_MEM_SHARING_EXTERNAL_HOST_ADDRESS) {
        seg->devvaddr = (uint64_t)(uintptr_t)memblock->memdesc.memshare.orighostvaddr;
        seg->hostvaddr = (uint64_t)(uintptr_t)memblock->memdesc.memshare.orighostvaddr;
        seg->devptr = (uint64_t)(uintptr_t)memblock->memdesc.memshare.orighostvaddr;
        seg->uvavaddr = (uint64_t)(uintptr_t)memblock->memdesc.memshare.orighostvaddr;
        seg->size = (uint64_t)memblock->memdesc.memshare.orighostsize;
    }
}

static void
cudbgReportMemblock_underLock(CUctx *ctx, CUmemblock *memblock)
{
    cudbgReportMemblockAlloc(ctx, memblock,
                             false,
                             gpudbgGetClientSessionId());
}

static void
cudbgReportAllMemblocks_underLock(CUctx *ctx)
{
    CUmemblock *m = NULL;
    uint64_t devvaddr, size;

    /* Report all memblocks */
    for (m = ctx->memmgr->memblocks; m; m = m->next) {
        cudbgReportMemblock_underLock(ctx, m);
    }

    /* Report lmem */
    if (ctx->lmem) {
        devvaddr = (uint64_t)memobjGetDeviceVaddr(ctx->lmem);
        size = (uint64_t)memobjGetSize(ctx->lmem);

        cudbgReportHostLmemResize(ctx, devvaddr, size, false, gpudbgGetClientSessionId());
    }
}

static bool cudbgIsDebuggerAttachInProgress(void)
{
    return cudbgAttachInProgress;
}

static void cudbgSetDebuggerAttachState(bool attachInProgress)
{
    CUDBGcommand message;

    CUDBG_ENTERCS(0);
    CU_TRACE_FUNCTION();

    cudbgAttachInProgress = attachInProgress;

    message.kind = dbgSetDebuggerAttachState;
    message.cases.setDebuggerAttachState.attachInProgress = attachInProgress;

    pushMessage(&message, sizeof message);
    sendMessage();

    CUDBG_LEAVECS(0);
}

typedef struct symFuncData_st symFuncData;
struct symFuncData_st {
    uint32_t isGlobalSymtab;
    gpudbgModule module;
};

static void
cudbgSymFunctor(const char *name, NvU32 index, NvU32 constBank, NvU64 offset, NvU64 dptr, NvU64 size, NvU32 type, NvU32 bind, NvU32 other, void *funcdata)
{
    symFuncData *data = (symFuncData*)funcdata;
    NvU64 val = 0;

    if (!data)
        return;

    val = (data->isGlobalSymtab) ? dptr : offset;
    cudbgModuleUpdateSymbolByIndex(data->module->elfInfo, (uint32_t)index, (uint64_t)val);
}

static void
cudbgModuleUpdateSymtab(gpudbgModule module, cuiSymtable *symtab, uint32_t isModuleSymtab)
{
    symFuncData data = {0};

    if (!module || !symtab)
        return;

    data.isGlobalSymtab = isModuleSymtab;
    data.module = module;

    cuiSymApplyFunctor(symtab, cudbgSymFunctor, &data);
}

static int
cudbgModuleUpdateSymbolsCommon(CUctx *ctx, CUmod *mod, const char *fb_ident, char *cubin, gpudbgModule *pModule)
{
    gpudbgModule module = NULL;

    if (!ctx || !mod) {
        CUDBG_ERROR("Invalid arguments when calling cudbgModuleUpdateSymtab.\n");
        return -1;
    }

    CU_TRACE_FUNCTION();

    if (pModule)
        *pModule = NULL;

    if (cuiBinIsElf(cubin)) {
        if (isInternalModule(mod) && !CUDA_LIST_CONTAINS_NODE(globals.activeContexts, ctx)) {
            return -1;
        }

        module = gpudbgRegisterElfModule(ctx, fb_ident, mod,
                                         ctx->device->state.deviceIdx,
                                         mod->internal, (uint32_t)mod->visibility,
                                         ctx->launchBlocking,
                                         cubin,
                                         elf_size(cubin));
    }

    if (module) {
        CUfunc *f;

        cudbgModuleUpdateSymtab(module, mod->symtable, 1);

        for (f = mod->pFuncList; f; f = f->next) {
            gpudbgFunction function;
            /* Bug 802426:  Do not use memobjGetBlockOffset(f->memobj) to
               obtain the function entry PC, since that only returns the
               block-relative offset, which is not what we want on Fermi
               since large programs will result in multiple func memblocks.
               memobjGetRangeOffset(f->memobj) can do the trick on Fermi,
               but it will not work for Tesla, so we need to find the PC
               by taking the difference of the vaddr for this memobj
               and the vaddr for the base of function memory.
            */
            uint64_t functionEntryPC = memobjGetDeviceVaddr(f->memobj) -
                                       ctx->device->hal.funcGetFuncMemBase(ctx, f);
            bool isCnpCtxSync = false;
            bool needsHostResume = false;

            isCnpCtxSync = (f->syscallId == SYSCALL_ID_CNP_CTX_SYNCHRONIZE &&
                            (mod->visibility == CU_MOD_VISIBILITY_HIDDEN_SYSCALL ||
                             mod->visibility == CU_MOD_VISIBILITY_HIDDEN_TRAMPOLINE));

            if (mod->visibility == CU_MOD_VISIBILITY_HIDDEN_SYSCALL ||
                mod->visibility == CU_MOD_VISIBILITY_HIDDEN_TRAMPOLINE) {
                switch (f->syscallId) {
                case SYSCALL_ID_CNP_CTX_SYNCHRONIZE:
                case SYSCALL_ID_CNP_GET_PARAMETER_BUFFER:
                case SYSCALL_ID_CNP_LAUNCH_DEVICE:
                case SYSCALL_ID_CNP_GET_PARAMETER_BUFFER_V2:
                case SYSCALL_ID_CNP_LAUNCH_DEVICE_V2:
                    needsHostResume = true;
                default:
                    break;
                }
            }

            function = gpudbgRegisterFunction(module, (char*)f->name,
                                              f, f->isHidden, functionEntryPC,
                                              memobjGetDeviceVaddr(f->memobj),
                                              f->finalRegcount,
                                              (uint32_t)f->stackSize,
                                              (uint32_t)f->frameSize,
                                              f->lmemsize, f->smemSize.userStatic,
                                              f->texRefs.count, f->type,
                                              cuiFuncUsesCnp(f) || cuiFuncIsPreemptable(f),
                                              cuiFuncUsesCnpJoin(f),
                                              needsHostResume,
                                              isCnpCtxSync);

            if (!function) {
                CUDBG_ERROR("Failed to register function.\n");
                CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C, CUDBG_ERROR_INTERNAL,
                                                  CUDBG_ERROR_TYPE_CUDBG);
                return -1;
            }

            /* Add the per function symtab entries into the module */
            cudbgModuleUpdateSymtab(module, f->symtable, 0);

            /* Update the function symbol and the text section symbol */
            cudbgModuleUpdateFunctionSymbols(module->elfInfo, (uint32_t)f->symbolIndex,
                                             function,
                                             (uint64_t)(uintptr_t)function->virtCodeAddr);

            if (f->symtable == NULL)
                continue;

        }

        *pModule = module;
    }

    return 0;
}

static
void cudbgRegisterModuleAndFunctions(CUctx *ctx, CUmod *mod, CUmodule *phMod,
                                     const char *fb_ident, char *cubin)
{
    CUresult status;
    int res = 0;
    gpudbgModule module = NULL;

    if (!ctx || !mod) {
        CUDBG_ERROR("Invalid arguments when calling cudbgRegisterModuleAndFunctions.\n");
        CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C, CUDBG_ERROR_INTERNAL, CUDBG_ERROR_TYPE_CUDBG);
        return;
    }

    CU_TRACE_FUNCTION();

    /* Bug 879950:  We found that all function code downloads performed
       by the driver are asynchronous, which presents a race for us if
       we're to read instruction memory over BAR1.  Putting a context
       synchronize after each module load ensures that any outstanding
       function memory copies have completed before we report this
       module as being 'loaded'.
       However, while attaching this should not be done since a long
       running cuda context could be resident.
    */
    if (!cudbgIsDebuggerAttachInProgress() && !cudbgIsCoredumpInProgress()) {
        status = cuiCtxSynchronize(ctx);
        if (status != CUDA_SUCCESS) {
            CUDBG_ERROR("Call to cuiCtxSynchronize failed (%u).\n", status);
            CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGDRIVER_C, CUDBG_ERROR_INTERNAL,
                                              CUDBG_ERROR_TYPE_DRIVER);
            return;
        }
    }

    res = cudbgModuleUpdateSymbolsCommon(ctx, mod, fb_ident, cubin, &module);
    if (res != 0)
        return;

    if (module) {
        gpudbgDeleteElfModuleHandle(module, cubin, elf_size(cubin));
    }
}

void cudbgModuleUpdateSymbols(CUctx *ctx, CUmod *mod, const char *fb_ident, char *cubin)
{
    int res = 0;
    gpudbgModule module = NULL;

    if (!ctx || !mod) {
        CUDBG_ERROR("Invalid arguments when calling cudbgModuleUpdateSymtab.\n");
        return;
    }

    CU_TRACE_FUNCTION();

    res = cudbgModuleUpdateSymbolsCommon(ctx, mod, fb_ident, cubin, &module);
    if (res != 0)
        return;

    if (module) {
        res = cudbgRelocateElfXXImage(cubin, module->elfInfo);
        if (res != 0)
            CUDBG_ERROR("Failed to relocate elf image\n");

        cudbgElfXXDestroyModule(module->elfInfo);
    }
}

void cudbgReportModuleLoad(CUctx *ctx, CUmod *mod, CUmodule *phMod,
                           const char *fb_ident, char *cubin)
{
    CUDBG_ENTERCS(0);
    CU_TRACE_FUNCTION();

    /* Handle debugging setup */
    cudbgRegisterModuleAndFunctions(ctx, mod, phMod, fb_ident, cubin);

    CUDBG_LEAVECS(0);
}

static void
cudbgUnregisterFunction(CUfunc *func)
{
    CUDBGcommand message;

    message.kind = dbgUnregisterFunction;
    message.cases.unregisterFunction.ctx               = (uint64_t)(uintptr_t)func->mod->ctx;
    message.cases.unregisterFunction.module            = (uint64_t)(uintptr_t)func->mod;
    message.cases.unregisterFunction.function          = (uint64_t)(uintptr_t)func;
    pushMessage(&message, sizeof message);
    sendMessage();

}

static void
cudbgUnregisterModule(CUmod *mod)
{
    CUDBGcommand message;

    message.kind = dbgUnregisterModule;
    message.cases.unregisterModule.ctx    =  (uint64_t)(uintptr_t)mod->ctx;
    message.cases.unregisterModule.module =  (uint64_t)(uintptr_t)mod;
    pushMessage(&message, sizeof message);
    sendMessage();
}

static void
cudbgUnloadElfImage(CUmod *mod)
{
    CUDBGcommand message;

    CU_TRACE_FUNCTION();

    message.kind = dbgUnloadElfImage;
    message.cases.unloadElfImage.ctx            = (uint64_t)(uintptr_t)mod->ctx;
    message.cases.unloadElfImage.mod_handle     = (uint64_t)(uintptr_t)mod;
    pushMessage(&message, sizeof message);
    sendMessage();
}

static void
cudbgUnregisterModuleAndFunctions(CUctx *ctx, CUmod *mod)
{
    CUfunc *func;

    if (!ctx || !mod)
        return;

    cudbgUnloadElfImage(mod);

    func = mod->pFuncList;
    for (; func; func = func->next) {
        cudbgUnregisterFunction(func);
    }

    cudbgUnregisterModule(mod);
}

void cudbgReportModuleUnload(CUctx *ctx, CUmod *mod)
{
    CUDBG_ENTERCS(0);
    CU_TRACE_FUNCTION();

    cudbgUnregisterModuleAndFunctions(ctx, mod);

    CUDBG_LEAVECS(0);
}

void CUDBG_REPORT_DRIVER_API_ERROR(void)
{
    /* This function is used by the debug client to set an internal breakpoint */
    ++cudbgReportDriverApiErrorCount;
}

void CUDBG_REPORT_DRIVER_INTERNAL_ERROR(void)
{
    /* This function is used by the debug client to set an internal breakpoint */
    ++cudbgReportDriverInternalErrorCount;
}

/*   3                   2                   1                   0
 * 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
 *+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *|                        Error code                             |
 *+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *| Reserved  | Filename hash |           Line #              | T |
 *+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * T = Error type
 */
uint64_t
cudbgEncodeErrorCode(CUDBGerrorFile filename, int line, uint32_t res, CUDBGErrorType type)
{
    uint64_t errorCode = res;
    errorCode += ((uint64_t)(type & 0x3) << 32);
    errorCode += ((uint64_t)(line & 0xFFFF) << 34);
    errorCode += ((uint64_t)((uint8_t)filename) << 50);
    return errorCode;
}

CUDBGResult
cudbgGetLastError(void)
{
    return (CUDBGResult)CUDBG_REPORTED_DRIVER_INTERNAL_ERROR_CODE;
}

void
cudbgClearErrors(void)
{
    CUDBG_REPORTED_DRIVER_INTERNAL_ERROR_CODE = 0ULL;
}

void
cudbgToolsApiStateUpdate(uint32_t newstate)
{
    uint32_t oldVal = 0;

    oldVal = (uint32_t)cuosInterlockedExchange((volatile unsigned int*)&cudbgToolsApiState,
                                               (unsigned int)newstate);

    if (oldVal == CUDBG_APP_TOOLS_API_STATE_NOTIFY_DETACH) {

        /*  See the comments in the dynamic function call about
            why this is necessary */
        while (cudbgDetachFlag != CUDBG_DETACH_FLAG_DONE);

        /* See the comments in the dynamic function call cudbgApiDetach in the
           case where no inthandler threads are availble to discover why
           this is required.  */
        sendDetachCompletion();
    }
}

/* Returns the size of the parameters provided by the ELF image.
 *
 * This is similar to how cuiLaunchKernel_nonreentrant handles
 * launches from the host.
 */
uint64_t
cudbgElfParamsSize(const CUfunc *fn)
{
    NvU32 i;
    uint64_t numbytes;

    /* XXX: CUDA only supports CUI_FUNC_PARAMETER_TYPE_VALUE.
     *      The other types are available for OpenCL.
     */
    numbytes = 0;
    for (i=0; i<fn->parameterCount; ++i) {
        if (fn->parameters[i].type == CUI_FUNC_PARAMETER_TYPE_VALUE) {
            const NvU32 sz  = fn->parameters[i].val.value.size;
            const NvU32 off = fn->parameters[i].val.value.offset;
            if (numbytes < (sz + off)) {
                numbytes = sz + off;
            }
        }
    }

    return numbytes;
}

CUDBGResult
cudbgGetUserParamMemoryOffsets(CUfunc *func, uint64_t *paramsOffset, uint64_t *paramsSize)
{
    CUDBG_VERIFY(func && paramsOffset && paramsSize, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args\n");

    *paramsOffset = func->paramConstMemobjOffset;

    /* Determine the size of the parameters. */
    if (func->params.numbytesConst > 0) {
        /* For OpenCL */
        *paramsSize = func->params.numbytesConst;
    }
    else if (func->params.numbytes > 0) {
        /* Host launched kernels */
        *paramsSize = func->params.numbytes;
    }
    else {
        /* For device-only launched kernels, sum the parameter sizes provided
         * by the ELF image. This can be the case for device cnp launches.
         */
        *paramsSize = cudbgElfParamsSize(func);
    } 

    return CUDBG_SUCCESS;
}
