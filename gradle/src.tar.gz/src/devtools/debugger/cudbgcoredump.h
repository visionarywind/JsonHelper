/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef __CUDBGCOREDUMP_H__
#define __CUDBGCOREDUMP_H__
#include <cuda.h>
#include <cuda_types.h>
#include <cudacoredump.h>
#include <cudadebugger.h>
#include <tools_shared_rangemap.h>
#include <tools_shared_hashmap.h>

typedef struct {
    /* List of CudbgBacktraceTableEntry entries */
    tList *backtrace;

    /* Dump of lmemHi for this lane */
    char *lmemHi;

    /* Dump of registers for this lane */
    char *regDump;

    /* Dump of predicates for this lane */
    uint32_t *predicates;

    /* Size of predicates dump */
    uint64_t predicatesDumpSize;

    CudbgThreadTableEntry threadTableEntry;
} CudbgCoredumpThreadData;

typedef struct {
    /* List of CudbgCoredumpThreadData entries */
    tList *threadDataList;

    uint32_t lmemHiSizePerLane;
    uint32_t lmemHiOffset;

    uint32_t numRegsPerLane;

    /* Dump of registers for this lane */
    char *regDump;

    /* Dump of predicates for this lane */
    uint32_t *predicates;

    /* Size of predicates dump */
    uint64_t predicatesDumpSize;

    /* Dump of uniform registers for this lane */
    uint32_t *uniformRegDump;

    /* Size of uniform register dump */
    uint64_t uniformRegDumpSize;

    /* Dump of uniform predicates for this lane */
    uint32_t *uniformPredicatesDump;

    /* Size of uniform predicates dump */
    uint64_t uniformPredicatesDumpSize;

    CudbgWarpTableEntry warpTableEntry;
} CudbgCoredumpWarpData;

typedef struct {
    /* List of CudbgCoredumpWarpData that belong to this grid */
    tList *warpDataList;

    /* Index of this gridStateTableEntry in the grid state table */
    uint32_t gridTableIndex;

    /* Dump of parameter memory for the grid. */
    char *paramsDump;
    uint64_t paramsSize;

    CudbgGridTableEntry gridTableEntry;
} CudbgCoredumpGridData;

typedef struct {
    /* Dump of shared memory */
    char *smemDump;

    /* Shared memory size per CTA */
    uint64_t smemSize;

    /* Uniform register and predicate file */
    uint32_t numUniformRegsPrWarp;
    uint32_t numUniformPredicatesPrWarp;

    /* List of CudbgCoredumpWarpData entries */
    tList *warpDataList;

    CudbgCTATableEntry ctaTableEntry;
} CudbgCoredumpCTAData;

typedef struct {
    /* virtCTAID to CudbgCoredumpCTAData map */
    tHashMap *ctaMap;

    CudbgSmTableEntry smTableEntry;
} CudbgCoredumpSmData;

typedef struct {
    elf_t elfImage;
    elf_t relocatedElfImage;
    uint64_t elfImageSize;

    CudbgModuleTableEntry moduleTableEntry;
} CudbgCoredumpModuleData;

typedef struct {
    /* List of CudbgCoredumpModuleTable entries */
    tList *moduleList;

    CudbgContextTableEntry contextTableEntry;
} CudbgCoredumpCtxData;

typedef struct {
    /* Dump of memory corresponding to CudbgMemoryTableEntry */
    char *memDump;

    bool isManagedMem;
} CudbgCoredumpMemoryData;

typedef struct {
    /* gridId to CudbgCoredumpGridData map */
    tHashMap *gridDataMap;

    /* List of CudbgCoredumpSmData entries */
    tList *smList;

    /* List of CudbgCoredumpCtxData entries */
    tList *ctxList;

    CudbgDeviceTableEntry deviceTableEntry;
} CudbgCoredumpDeviceData;

typedef struct {
    tList *table;
    uint64_t tableOffset;
} CudbgCoredumpStringTable;

typedef struct {
    /* List of all CudbgCoredumpDeviceData entries */
    tList *deviceDataList;

    /* Memory range to CudbgCoredumpMemoryData entries */
    tRangeMap *memoryDataMap;

    CudbgCoredumpStringTable *stringTable;
} CudbgCoredumpData;

#define CUDBG_COREDUMP_STRING_BUFFER_SIZE 256

#ifdef __cplusplus
extern "C" { /* Assume C declarations for C++ */
#endif  /* __cplusplus */

bool cudbgIsCoredumpEnabled(void);
bool cudbgIsUserCoredumpEnabled(void);
bool cudbgIsCoredumpInProgress(void);
bool cudbgIsCoredumpLightweightEnabled(void);
void cudbgCoredumpEnable(const char *fileName);
void cudbgUserCoredumpEnable(const char *pipeName);
void cudbgCpuCoredumpEnable(bool enable);
void cudbgCoredumpLightweightEnable(void);
const char* cudbgCoredumpGetCorePipeName();
void cudbgCoredumpTriggerCPUCoredump(void);
CUresult cudbgCoredumpInitialize(CUctx *ctx);
CUresult cudbgCoredumpFinalize(CUctx *ctx);

CUDBGResult cudbgCoredumpInitMessage(void);
CUDBGResult cudbgCoredumpFinalizeMessage(void);
CUDBGResult cudbgCoredumpResetMessage(void);
CUDBGResult cudbgCoredumpPushMessage(void *msg, uint64_t msgSize);
CUDBGResult cudbgCoredumpSendMessage(void);

#ifdef __cplusplus
} /* extern "C" */
#endif  /* __cplusplus */

#endif /* __CUDBGCOREDUMP_H__ */
