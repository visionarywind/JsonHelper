/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/*--------------------------------- Includes --------------------------------*/

#ifndef NVGPUDEBUGCLIENT_H
#define NVGPUDEBUGCLIENT_H

#include <cudadebugger.h>
#include <cuda_types.h>
#include "cuda_platform.h"
#include "nvelf_reader.h"
#include "nvelf.h"
#include "apiprofclient.h"
#include "cuda_syscallid.h"
#include "inthandler.h"
#include <tools_shared_hashmap.h>

#include "cuda_etbl/tools_callbacks.h"
#include "etbl/tools/tools_injection_internal.h"
#include "rm_control_abi.h"

#define CUDBG_RAISE_DRIVER_API_ERROR(errorCode, funcNamePtr, flags)                     \
    do {                                                                                \
        if (errorCode != CUDA_SUCCESS) {                                                \
            CUDBG_ENTERCS(0);                                                           \
            if (flags & CUDBG_REPORT_DRIVER_API_ERROR_FLAGS)                            \
                CUDBG_BREAKCS(0);                                                       \
            CUDBG_REPORTED_DRIVER_API_ERROR_CODE = (uint64_t)(errorCode);               \
            CUDBG_REPORTED_DRIVER_API_ERROR_FUNC_NAME_SIZE = strlen(funcNamePtr)+1;     \
            CUDBG_REPORTED_DRIVER_API_ERROR_FUNC_NAME_ADDR = (uintptr_t)funcNamePtr;    \
            (*cudbgReportDriverApiErrorPtr)();                                          \
            CUDBG_LEAVECS(0);                                                           \
        }                                                                               \
    } while (0)

typedef enum {
    CUDBG_ERROR_FILE_UNKNOWN            = 0,
    CUDBG_ERROR_FILE_CUDBGDRIVER_C      = 1,
    CUDBG_ERROR_FILE_HALO_DRV_C         = 2,
    CUDBG_ERROR_FILE_TESLA_DRV_C        = 3,
    CUDBG_ERROR_FILE_CUDBGPIPE_C        = 4,
} CUDBGerrorFile;

#define CUDBG_RAISE_DRIVER_INTERNAL_ERROR(file, errorCode, errorType)                   \
    do {                                                                                \
        if (errorCode != CUDBG_SUCCESS) {                                               \
            uint64_t encoded = cudbgEncodeErrorCode(file,                               \
                                                    __LINE__,                           \
                                                    errorCode,                          \
                                                    errorType);                         \
            CUDBG_REPORTED_DRIVER_INTERNAL_ERROR_CODE = encoded;                        \
            (*cudbgReportDriverInternalErrorPtr)();                                     \
        }                                                                               \
    } while (0)

#ifdef __cplusplus
extern "C" {
#endif

extern uint32_t CUDBG_IPC_FLAG_NAME;
extern uint32_t CUDBG_RPC_ENABLED;
extern uint32_t CUDBG_APICLIENT_PID;
extern uint32_t CUDBG_I_AM_DEBUGGER;
extern uint32_t CUDBG_APICLIENT_REVISION;
extern uint32_t CUDBG_SESSION_ID;
extern uint64_t CUDBG_REPORTED_DRIVER_API_ERROR_CODE;
extern uint64_t CUDBG_REPORTED_DRIVER_API_ERROR_FUNC_NAME_SIZE;
extern uint64_t CUDBG_REPORTED_DRIVER_API_ERROR_FUNC_NAME_ADDR;
extern uint64_t CUDBG_REPORTED_DRIVER_INTERNAL_ERROR_CODE;
extern uint32_t CUDBG_ATTACH_HANDLER_AVAILABLE;
extern uint32_t CUDBG_ENABLE_LAUNCH_BLOCKING;
extern uint32_t CUDBG_ENABLE_INTEGRATED_MEMCHECK;
extern uint32_t CUDBG_ENABLE_PREEMPTION_DEBUGGING;
/* Note: cudbgInjectionPath will be exposed through cudadebugger.h
   when out-of-driver debugger works and we're ready to release it. */
#define CUDBG_INJECTION_PATH_SIZE 4096
extern path_char_t cudbgInjectionPath[CUDBG_INJECTION_PATH_SIZE];
extern tHashMap *gpudbgTWCtxInitialized;

/*
 * Function for setting an internal breakpoint. When we hit an error in
 * a driver API call, this function should be called (using the MACRO) so
 * that the debugger client can stop and examine the error code contained in
 * CUDBG_REPORTED_DRIVER_API_ERROR_CODE.
 */
extern void CUDBG_REPORT_DRIVER_API_ERROR(void);

/*
 * Function for setting an internal breakpoint. When we hit an internal
 * error in the driver, this function should be called (using the MACRO)
 * so that the debugger client can stop and examine the error code contained
 * in CUDBG_REPORTED_DRIVER_INTERNAL_ERROR_CODE.
 */
extern void CUDBG_REPORT_DRIVER_INTERNAL_ERROR(void);

/*------------------------------ Module Handle -------------------------------*/

/*
 * Temporary application handle to loaded module/function,
 * during module/function registration:
 */
typedef struct gpudbgModuleRec   *gpudbgModule;
typedef struct gpudbgFunctionRec *gpudbgFunction;

typedef struct cudbgElfInfo_st  cudbgElfInfo;
/*---------------------- FatFormat Debug Info Structure ----------------------*/

START_PACKED_ALIGNMENT

typedef struct PACKED_ALIGNMENT CUDBGthread_and_block_coord_st {
    unsigned blockNr;
    unsigned threadNr;
} *CUDBGthread_and_block_coord;

typedef struct PACKED_ALIGNMENT CUDBGcode_table_st {
    uint64_t                     virt;
    uint64_t                     phys;
} *CUDBGcode_table;

typedef struct PACKED_ALIGNMENT CUDBGsection_Table_st {
    uint64_t                     start;
    uint64_t                     end;
} *CUDBGsection_table;

typedef struct PACKED_ALIGNMENT CUDBGphysical_location_st {
    char *                       name;
    unsigned                     bank;
    uint64_t                     offset;
} *CUDBGphysical_location;

typedef struct PACKED_ALIGNMENT CUDBGvirtual_location_st {
    char *                       name;
    uint32_t                     size;
    uint64_t                     address;
} *CUDBGvirtual_location;

typedef struct PACKED_ALIGNMENT CUDBGdebug_info_st {
    uintptr_t                   *locationAddresses;
    CUDBGsection_table           sectionTable;
    CUDBGvirtual_location        variableRangeTable;
} *CUDBGdebug_info;

typedef struct PACKED_ALIGNMENT CUDBGdevice_memory_descriptor_st {
    uint32_t                     bank;
    uint32_t                     size;
    uint64_t                     devicePointer;
    uint64_t                     hostAddress;
} *CUDBGdevice_memory_descriptor;

typedef struct PACKED_ALIGNMENT CUDBGmemory_segment_st {
    uint64_t        ctx;                // CUctx* pointer
    uint64_t        hostHandle;         // CUmemblock* pointer
    uint64_t        sourceMemblock;     // source CUmemblock* pointer
    uint64_t        devvaddr;           // Device VA of memblock
    uint64_t        size;               // Size of memblock
    uint32_t        dmalHandle;         // DMAL appropriate handle (set on RM,MRM,MPS)
    uint32_t        rmClient;           // RM client of owner
    uint32_t        sourceDeviceIdx;    // Source device for memblock (handles mapped memblocks)
    uint64_t        hostvaddr;          // Host VA.
    uint32_t        mapDevice;          // MapDevice flag
    uint32_t        hasDevPtr;          // Has a devptr
    uint32_t        usesNvmap;          // set if this is an nvmap allocation (only MRM)
    uint64_t        devptr;             // Devptr. Only valid if hasDevPtr != 0
    uint64_t        uvavaddr;           // UVA vaddr. Non-zero for UVA-mapped memblocks
    uint32_t        type;               // Type of memblock
    uint32_t        apiSource;          // API source of memblock
    uint32_t        location;           // Location of memblock
    uint32_t        owner;              // Owner of Memblock
    uint32_t        sharing;            // Memblock sharing flags
    uint32_t        userOwnsData;       // Memblock is part of the device heap
} CUDBGmemory_segment;

/*
 * This struct represents the layout of data in the debugger's
 * constant bank, which is used for chips that have a trap
 * handler.  This can be extended.
 */
typedef struct PACKED_ALIGNMENT CUDBGconstant_data_st {
    uint64_t scratchpad;
} CUDBGconstant_data;

/*
 * Message layout used in system calls to debugger.
 * setting up and sending such messages is wrapped by
 * the Debug Client API functions specified below:
 */
typedef enum {
    dbgCtxCreation,
    dbgCtxDestructionBegin,
    dbgCtxDestructionEnd,
    dbgCtxPush,
    dbgCtxPop,
    dbgRegisterModule,
    dbgRegisterFunction,
    dbgRegisterModuleConsts,
    dbgRegisterFunctionConsts,
    dbgReportDeviceExecutionLaunch,
    dbgReportDeviceExecutionStop,
    dbgExportElfImage,
    dbgReportPatch,
    dbgSetDebuggerAttachState,
    dbgDetachComplete,
    dbgRpcInitEvent,
    dbgUnregisterFunction,
    dbgUnregisterModule,
    dbgUnloadElfImage,
    dbgMemblockAlloc,
    dbgMemblockFree,
    dbgHostLmemResize,
    dbgUnreportPatch,
    dbgResetFunctionBreakpoints,
    dbgCudaInitialized,
    dbgStreamSynchronized,
    dbgSystemStackResize,
    dbgForceSizeTo32 = 0xffffffffU,
} CUDBGsyscall_kind;

typedef struct PACKED_ALIGNMENT TextureReaderConfig_t {
    uint32_t dim;
    uint32_t coords[4];
    uint32_t regA;
    uint32_t regD[4];
    uint32_t regC[4];
    uint32_t a1;
    uint32_t gridDim;
    uint32_t loadAddr;
    uint32_t loadData;
    uint32_t saveAddr;
} TextureReaderConfig;

typedef struct PACKED_ALIGNMENT TextureReader_t {
    struct {
        uint64_t offset;        //Program entry points
        uint32_t numInstr;      //Number of instructions in each program
        uint32_t bufferBytes;
    } textureReader, readSharedMemory, writeSharedMemory, readRegisterFile, writeRegisterFile;

    //Instructions to be patched dynamically
    uint64_t textureReaderTEXInstrOffset;

    //Data storages and their sizes
    uint64_t dataOffset;
    uint64_t configBaseOffset;
    uint32_t configBufferBytes;

    //Configuration offsets (absolute offsets)
    uint64_t dimOffset;
    uint64_t coordsOffset;
    uint64_t regAOffset;
    uint64_t regDOffset;
    uint64_t a1Offset;
    uint64_t gridDimOffset;
    uint64_t loadAddrOffset;
    uint64_t loadDataOffset;
    uint64_t saveAddrOffset;
} TextureReader;

#define CUDBG_TEXIDMAP_ALLOC_CHUNK_SIZE  128

typedef struct PACKED_ALIGNMENT {
    uint64_t texId;
    uint64_t constBankOffset;
} TexIdMap;

#define CUDBG_MAX_CHANNELS 32

typedef struct PACKED_ALIGNMENT {
    CUDBGsyscall_kind kind;

    union {
        struct PACKED_ALIGNMENT {
            uint64_t                     ctx;
            uint64_t                     patchRamDevVA;
            uint32_t                     patchRamSize;
            uint64_t                     scratchpadDevVA;
            uint64_t                     scratchpadDevPtr;
            uint32_t                     threadId;
            uint32_t                     device;
            char                         deviceType[32];
            char                         smType[32];
            bool                         launchBlocking;
            bool                         memcheckEnabled;
            uint32_t                     preemptionType;
            uint32_t                     numSyscalls;
            uint64_t                     syscallRcVaddr;
            uint64_t                     thCodeVA;
            uint64_t                     thCodeSize;
            uint64_t                     thRdRegOffset;
            uint64_t                     thWrRegOffset;
            uint64_t                     thRdTexMemOffset;
            uint32_t                     hAppClient;
            uint32_t                     hComputeObject;
            uint32_t                     hChannelGroup;
            uint32_t                     hChannelList[CUDBG_MAX_CHANNELS];
            uint32_t                     computeChannelCount;
            uint64_t                     texHeaderPoolVA;
            uint64_t                     texSamplerPoolVA;
            uint32_t                     numFdsTransferred;
            uint64_t                     funcMemBaseVA;
            uint64_t                     cilpBufferDevVA;
            uint64_t                     shmemWindowDevVA;
            uint64_t                     lmemWindowDevVA;
            uint64_t                     lmemSizePerSM;
            uint64_t                     gmemWindowDevVA;
            uint64_t                     hDebugObject;
            uint64_t                     globalFocusCoordsAddr;
            uint32_t                     globalFocusCoordsAllocSize;
        } ctxCreation;

        struct PACKED_ALIGNMENT {
            bool uvmEnabled;
        } cudaInitialized;

        struct PACKED_ALIGNMENT {
            uint64_t                     ctx;
        } ctxDestructionBegin;

        struct PACKED_ALIGNMENT {
            uint64_t                     ctx;
            uint32_t                     threadId;
        } ctxDestructionEnd;

        struct PACKED_ALIGNMENT {
            uint64_t                     ctx;
            uint32_t                     threadId;
        } ctxPush;

        struct PACKED_ALIGNMENT {
            uint64_t                     ctx;
            uint64_t                     newCtx;
            uint32_t                     threadId;
        } ctxPop;

        struct PACKED_ALIGNMENT {
            uint64_t                     ctx;
            uint64_t                     handle;
            uint32_t                     threadId;
            uint32_t                     fatBinFlags;
            uint32_t                     funcMemHandle;
            uint64_t                     funcMemSize;
            uint32_t                     stringTableSize;
            uint32_t                     nameIndex;
            uint32_t                     devId;
            bool                         internal;
            uint32_t                     visibility;
            bool                         launchBlocking;
        } registerModule;

        struct PACKED_ALIGNMENT {
            uint64_t                     ctx;
            uint64_t                     handle;
            uint64_t                     module;
            uint64_t                     devVAddr;
            uint64_t                     gpuAddrBase;
            uint64_t                     virtAddrBase;
            uint64_t                     prologueOffset;
            uint64_t                     prologueSize;
            uint64_t                     prologueDevVAddr;
            uint64_t                     spAssignmentAddr;
            uint32_t                     codeSize;
            uint32_t                     nrofRegisters;
            uint32_t                     stackSize;
            uint32_t                     frameSize;
            uint32_t                     localSize;
            uint32_t                     sharedSize;
            uint32_t                     texRefCount;
            uint64_t                     stackAddress;
            uint64_t                     localAddress;
            uint64_t                     sharedAddress;
            uint32_t                     nameIndex;
            uint32_t                     numTexIdMapEntries;
            bool                         global;
            bool                         hidden;
            bool                         usesCnp;
            bool                         usesContinuations;
            bool                         needsHostResume;
            bool                         isCnpCtxSync;
        } registerFunction;

        struct PACKED_ALIGNMENT {
            uint64_t                     ctx;
            uint64_t                     module;
            uint64_t                     client;
            uint64_t                     function;
            CuDim3                       gridDim;
            CuDim3                       blockDim;
            uint64_t                     gridId64;
            uint32_t                     numSyscalls;
            TextureReader                texMem;
            uint64_t                     funcMemBaseVA;
            uint64_t                     kilpControllerDataAddr;
            uint64_t                     kilpCtaIlpEnableTableAddr;
            uint64_t                     kilpCtaStopContinuations;
            uint64_t                     ctaContextIndirectionTableAddr;
            uint64_t                     qmdDptr;
            uint64_t                     lmemSizePerSM;
            uint64_t                     streamId;
        } deviceExecutionLaunch;

        struct PACKED_ALIGNMENT {
            uint64_t                     ctx;
            uint64_t                     module;
            uint64_t                     client;
            uint64_t                     function;
            uint64_t                     gridId64;
        } deviceExecutionStop;

        struct PACKED_ALIGNMENT {
            uint64_t  ctx;
            uint64_t  elf_image_size;
            uint64_t  mod_handle;
        } exportElfImage;

        struct PACKED_ALIGNMENT {
            uint64_t  context;
            uint32_t  kind;
            uint64_t  gpuPCOffset;
            uint32_t  patchSize;
            uint64_t  patchEntryAddr;
            bool      isMultiEntry;
            uint64_t  origInst[2];
            uint64_t  virtAddr;
            uint64_t  devVAddr;
            uint32_t  depth;
        } reportPatch;

        struct PACKED_ALIGNMENT {
            bool attachInProgress;
        } setDebuggerAttachState;

        struct PACKED_ALIGNMENT {
            uint64_t                     ctx;
            uint64_t                     module;
        } unregisterModule;

        struct PACKED_ALIGNMENT {
            uint64_t                     ctx;
            uint64_t                     module;
            uint64_t                     function;
        } unregisterFunction;

        struct PACKED_ALIGNMENT {
            uint64_t  ctx;
            uint64_t  mod_handle;
        } unloadElfImage;

        struct PACKED_ALIGNMENT {
            CUDBGmemory_segment segInfo;
            uint32_t devId;
            uint32_t threadId;
            uint32_t launchBlocking;
#if cuosOsIsQnx()
            /* On QNX, we pass the handle via an id, not a fd */
            uint32_t memHandleId;
#endif
        } memblockAlloc;

        struct PACKED_ALIGNMENT {
            uint64_t ctx;
            uint64_t hostHandle;
            uint64_t devvaddr;
            uint64_t size;
        } memblockFree;

        struct PACKED_ALIGNMENT {
            uint64_t ctx;
            uint64_t devvaddr;
            uint64_t size;
        } hostLmemResize;

        struct PACKED_ALIGNMENT {
            uint64_t  context;
            uint32_t  kind;
            uint64_t  gpuPCOffset;
            uint32_t  patchSize;
            uint64_t  patchEntryAddr;
            uint64_t  devVAddr;
        } unreportPatch;

        struct PACKED_ALIGNMENT {
            uint64_t context;
            uint64_t module;
            uint64_t function;
        } resetFunctionBreakpoints;

        struct PACKED_ALIGNMENT {
            uint64_t context;
            uint64_t streamId;
        } streamSynchronized;

        struct PACKED_ALIGNMENT {
            uint64_t context;
            uint64_t syscallStackSize;
        } systemStackResize;

    } cases;
} CUDBGcommand;

typedef struct PACKED_ALIGNMENT {
    bool launchBlocking;
    bool canPinExistingMemory;
    bool reportKernelLaunches;
    uint32_t patchRamSize;
} CudbgDriverOptions;

END_PACKED_ALIGNMENT

/*------------------ Symbol Scope Types (used by relocator) ------------------*/

typedef enum {
    CUDBG_SYMSCOPE_MODULE_FUNCTION,
    CUDBG_SYMSCOPE_MODULE_VARIABLE,
    CUDBG_SYMSCOPE_FUNCTION_VARIABLE,
    CUDBG_SYMSCOPE_INVALID,
} CUDBGsymscope;

/*------------------ Attach support-------------------------------------------*/

typedef enum {
    CUDBG_STATE_NOT_ATTACHING = 0,
    CUDBG_STATE_ATTACHING_VIA_RPCD,
    CUDBG_STATE_ATTACHING_VIA_STUB,
} CUDBGAttachState;

/* Describes why the app needs to be resumed while detaching */
typedef enum {
    CUDBG_APP_RESUME_REASON_NONE         = 0x0,
    CUDBG_APP_RESUME_REASON_INTHANDLER   = 0x1,
    CUDBG_APP_RESUME_REASON_SEND_MESSAGE = 0x2,
    CUDBG_APP_RESUME_REASON_TOOLSAPI     = 0x4,
} CUDBGAppResumeReason;

typedef enum {
    CUDBG_APP_TOOLS_API_STATE_READY             = 0x0,
    CUDBG_APP_TOOLS_API_STATE_WAITING           = 0x1,
    CUDBG_APP_TOOLS_API_STATE_NOTIFY_DETACH     = 0x2,
} CUDBGAppToolsApiState;

/*------------------ Error report types --------------------------------------*/

typedef enum {
    CUDBG_ERROR_TYPE_CUDBG = 0x0,
    CUDBG_ERROR_TYPE_DRIVER = 0x1,
} CUDBGErrorType;

/*------------------------ Constant Bank Information ------------------------*/

// UNCOMMENT THE DEFINE BELOW TO ENABLE THE 'LEGACY' Fermi CONSTBANK ABI
//#define CUDBG_LEGACY_CONSTBANK_ABI 1

#ifdef CUDBG_LEGACY_CONSTBANK_ABI
/* LEGACY ABI:  Constant bank #13 is used for storing launch parameters,
 * which happens on Fermi but not on Tesla (Tesla uses shared mem).  */
#define CUDBG_PARAMETER_CONSTANT_SEGMENT 13
#else
/* ABI:  Constant bank #0 is used for storing launch parameters,
 * which happens on Fermi but not on Tesla (Tesla uses shared mem). */
#define CUDBG_PARAMETER_CONSTANT_SEGMENT 0
#endif

/*------------------------ Defines for FDs created by MRM---------------------*/
typedef enum {
    CUDBG_FD_NVHOST_AS,
    CUDBG_FD_NVHOST_GR3D,
    CUDBG_FD_NVHOST_DBG_GPU,
    CUDBG_FD_NUM_TYPES,
} CUDBGFdTypes;

/*----------------------------CILP Support-----------------------------------*/

typedef enum {
    CUDBG_PREEMPTION_TYPE_NONE,
    CUDBG_PREEMPTION_TYPE_KILP,
    CUDBG_PREEMPTION_TYPE_CILP,
} CUDBGPreemptionTypes;
/*----------------------------- Debug Client API -----------------------------*/

/*
 * The following specifies the application's
 * system call interface to the debugger:
 */


/*
 * Function        : Check if current application is being debugged.
 * Function Result : True iff the debugger is this application is
 *                   currently under control of the debugger.
 */
NvBool gpudbgDebuggerAttached(void);

/*
 * Function        : Check if RPC daemon process needs to be created.
 * Function Result : True iff a debug client indicates it needs RPC.
 *
 */
NvBool gpudbgDebuggerNeedsRPC(void);

/*
 * Function        : Check if current process space belongs to the debugger.
 * Function Result : True iff the debugger is the process calling this function.
 */
NvBool gpudbgDebuggerProcess(void);

/*
 * Function        : Find the process id of the debugger.
 * Function Result : The pid of the API client or 0 if not set.
 */
uint32_t gpudbgGetApiClientPid(void);

/*
 * Function        : Check if integrated memcheck is enabled by debugger client
 * Function Result : True iff the debugger has requested integrated memcheck
 */
NvBool gpudbgDebuggerEnableIntegratedMemcheck(void);

/*
 * Function        : Check if preemption-style debugging is enabled by debugger client
 * Function Result : True iff the debugger has requested preemption-style debugging
 */
NvBool gpudbgDebuggerEnablePreemptionDebugging(void);

/*
 * Function        : Get the client sessionId for the current debug session
 *                 : This is unique for each attached debugger session and is independent
 *                   of the sessionId as written by the frontend. This is incremented
 *                   on each attach.
 * Function Result : Session ID
 */
uint32_t gpudbgGetClientSessionId(void);

/*
 * Function        : Try to load the injected library provided via cudbgInjectionPath
 * Function Result : None, if the library loading fails the old control path will be used
 */
void gpudbgTryLoadInjectedLibrary(void);

/*------------------------------- Driver Properties --------------------------

The behavior of the cudbgDriver in the inferior process is controlled through
the cudbgDriverOptions object. The first time an ack is sent back to the
application, that object is passed too. It is an easy way to communicate from
the debugger to the application without having to write into the memory of the
application (with the exception of IPC_FLAG_NAME, which requires debugger client
memory write infrastructure). */

extern CudbgDriverOptions cudbgDriverOptions;

extern bool cudbgDriverOptionsChanged;

/* Initialize the driver options to be passed to the application as soon as possible (first ack). */
void cudbgDriverOptionsInitialize(uint32_t clientRevision, bool reportLaunches);

/* Returns true if a launch must be made blocking when the debugger is attached. */
bool cudbgLaunchBlocking(CUctx *ctx);

/* Returns true if the debugger client can properly handle the CUDA driver
   pinning down existing host memory allocations.  This is specific to debugger
   clients prior to CUDA 4.0 -- after that, all clients are properly handling
   the new allocation scheme. */
bool cudbgCanPinExistingMemory(void);

/* Register driver entry point initialization */
void cudbgApiInitInternal(CUDBGAttachState attachState);

/* Complete the detach process for driver */
void cudbgApiDetach(void);

bool cudbgIsDebuggableDevice(CUdev *dev);

/*
 * Function        : Register used GPU.
 * Parameters      : ctx                    (I) Identification of client for subsequent operations
 */
void cudbgReportCtxCreate(CUctx *ctx, bool doLateCheck, uint32_t sessionId);
void cudbgReportCtxDestroyBegin(CUctx *ctx, bool doLateCheck, uint32_t sessionId);
void cudbgReportCtxDestroyEnd(CUctx *ctx, bool doLateCheck, uint32_t sessionId);
void cudbgCtxPush(CUctx *ctx);
void cudbgCtxPop(CUctx *ctx, CUctx *newCtx);


/*
 * Function        : Report start of execution launch.
 * Parameters      : ctx                    (I) Launching client
 *                   function               (I) Launched  function
 *                   codeOffset             (I) Offset of launched function's device
 *                                              host memory mapping reported with
 *                                              function RegisterClient.
 *
 */
void gpudbgReportDeviceExecutionLaunch(
    CUctx *               ctx,
    CUfunc *              function,
    CUdim3                gridDim,
    CUdim3                blockDim,
    uint64_t              gridId64,
    uint64_t              funcMemBaseVA,
    uint64_t              qmdDptr,
    uint64_t              streamId);

/*
 * Function        : Register termination of previously launched device function.
 * Parameters      : ctx                    (I) Launching client
 *                   function               (I) Launched  function
 */
void gpudbgReportDeviceExecutionStop(CUctx *ctx, void *function, uint64_t gridId64);


/*
 * Function        : Report a region of patch memory and the PC of the instruction that branches to it.
 * Parameters      : ctx                    (I) Pointer to CUctx_st, see cuictx.h
 *                   kind                   (I) dbg_patch_kind_t, see halo.h
 *                   devvaddr               (I) Virtual device address of the patch, absolute in the context's VA.
 *                   gpuPCOffset            (I) Device address of the patch, relative to the context's function memory base.
 *                   patchSize              (I) Size of the patch, in bytes.
 *                   patchEntryAddr         (I) Address of the instruction that branches to the patch;
 *                                              it's a device address, relative to the context's function memory base.
 *                   isMultiEntry           (I) true for multiple entry patches
 *                   origInst               (I) Pointer to a buffer containing the original instruction at patchEntryAddr.
 *                   instSz                 (I) Number of bytes to copy from origInst.
 *                   depth                  (U) Unused.
 * Assumptions     : Patches do not overlap in memory. In particular, duplicates should not be reported.
 *                   Patches do not overlap with functions (see gpudbgRegisterFunction).
 * Comments        : If origInst is nonzero, then an entry for the hop control will be set in cudbgapi.c
 */
void gpudbgReportPatch(void *ctx, uint32_t kind, uint64_t devvaddr,
                       uint64_t gpuPCOffset, uint32_t patchSize,
                       uint64_t patchEntryAddr, bool isMultiEntry,
                       uint64_t* origInst, uint32_t instSz, uint32_t depth);


/*
 * Removes a patch from the tracking for the debugger
 */
void gpudbgUnreportPatch(void *ctx, uint32_t kind, uint64_t devvaddr, uint64_t gpuPCOffset,
                         uint32_t patchSize, uint64_t patchEntryAddr);


/*
 * Notify the debugger that all outstanding breakpoints must be invalidated and reinserted
 * since memcheck has redownloaded the function code
 */
void gpudbgResetFunctionBreakpoints(CUctx *ctx, CUfunc *func);

/* ------------------------- NEW COMPILER PATH BELOW ------------------------ */

void cudbgSaveTexIdToConstBankMap(gpudbgFunction function,
                                  uint64_t texId,
                                  uint64_t constBankOffset);

void cudbgGetRmCtxHandles(CUctx *ctx, uint32_t *hAppClient, uint32_t *hComputeObject,
                          uint32_t *hChannelGroup, uint32_t *channelList, uint32_t numChannels,
                          uint32_t *numAllocatedChannels);

void cudbgGetMRMCtxHandles(CUctx *ctx, int32_t *nvhostdbgfd, int32_t *channelList, uint32_t clistsz, uint32_t *numChannels);
void cudbgReportCudaInitialized(bool doLateCheck, uint32_t sessionId);

CUresult cudbgInitDebugger(CUintHandlerServiceRoutineParams *serviceParams);
CUresult cudbgDetachDebugger(CUintHandlerServiceRoutineParams *serviceParams);

void cudbgReportModuleLoad(CUctx *ctx, CUmod *mod, CUmodule *phMod, const char *fb_ident, char *cubin);

void cudbgReportModuleUnload(CUctx *ctx, CUmod *mod);

void cudbgReportStreamSynchronized(CUctx *ctx, uint64_t streamId, uint32_t sessionId);

/* It would be ideal to put this function in a utility file. This function
 * cannot be in cudbgutils.h because cudbgutils.h includes cudbgdriver.h and there would
 * be a circular dependency. Since it is only used in cudbgdriver.c today, we can
 * move it to a separate file if we ever need to use it in other files. */
uint64_t cudbgEncodeErrorCode(CUDBGerrorFile filename, int line, uint32_t res, CUDBGErrorType type);

/*
 * Function is used by toolsapi callback handler to report any error occurence while
 * processing the user request in driver.
 */
CUresult cudbgApiErrorCheck(uint32_t status, const char *funcName,
                            uint32_t isRuntime, void* cudartEtbl);

void cudbgRpcInitEvent(void);

void cudbgReportCtxState(CUctx *ctx, bool acquireLock);

CUDBGResult cudbgGetLastError(void);
void cudbgClearErrors(void);

CUDBGResult cudbgGetUserParamMemoryOffsets(CUfunc *func, uint64_t *paramsOffset, uint64_t *paramsSize);

uint32_t cudbgGetTid(void);

/************************  Tools API reporting functions **********************/
void cudbgReportMemblockAlloc(CUctx *context, CUmemblock *memblock,
                              bool doLateCheck,
                              uint32_t sessionId);

void cudbgReportMemblockFree(CUctx *context,
                             CUmemblock *memblock,
                             uint64_t devvaddr,
                             uint64_t size,
                             bool doLateCheck,
                             uint32_t sessionId);

void cudbgReportHostLmemResize(CUctx *context,
                               uint64_t devvaddr,
                               uint64_t size,
                               bool doLateCheck,
                               uint32_t sessionId);

void cudbgReportSystemStackResize(CUctx *context,
                                  uint64_t size,
                                  bool doLateCheck,
                                  uint32_t sessionId);

void cudbgMemblockGetSegInfo(CUmemblock *memblock, CUDBGmemory_segment *seg);

void cudbgToolsApiStateUpdate(uint32_t newstate);

void cudbgModuleUpdateSymbols(CUctx *ctx, CUmod *mod, const char *fb_ident, char *cubin);

#ifdef __cplusplus
}
#endif

#endif
