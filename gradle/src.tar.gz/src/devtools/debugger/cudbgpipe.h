/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef CUDBG_PIPE_H
#define CUDBG_PIPE_H

#include <cudadebugger.h>
#include <libcudbg.h>

typedef enum {
    CUDBG_PIPE_MODE_READ,
    CUDBG_PIPE_MODE_WRITE,
    CUDBG_PIPE_MODE_NUM,
} cudbg_pipe_mode_t;

typedef enum {
    CUDBG_PIPE_TYPE_NONE,
    CUDBG_PIPE_TYPE_ANONYMOUS,
    CUDBG_PIPE_TYPE_NAMED_READ,
    CUDBG_PIPE_TYPE_NAMED_WRITE,
    CUDBG_PIPE_TYPE_UDS_READ,
    CUDBG_PIPE_TYPE_UDS_WRITE,
} cudbg_pipe_type_t;

typedef enum {
    CUDBG_PIPE_ENDPOINT_NONE,
    CUDBG_PIPE_ENDPOINT_DEBUGGER,
    CUDBG_PIPE_ENDPOINT_DISPATCHER,
    CUDBG_PIPE_ENDPOINT_APPLICATION,
    CUDBG_PIPE_ENDPOINT_DEVICE,
    CUDBG_PIPE_ENDPOINT_ATTACH_STUB,
    CUDBG_PIPE_ENDPOINT_RPCD = LIBCUDBG_PIPE_ENDPOINT_RPCD,
    CUDBG_PIPE_ENDPOINT_DEBUG_CLIENT = LIBCUDBG_PIPE_ENDPOINT_DEBUG_CLIENT,
    CUDBG_PIPE_ENDPOINT_RPCD_CB = LIBCUDBG_PIPE_ENDPOINT_RPCD_CB,
    CUDBG_PIPE_ENDPOINT_DEBUG_CLIENT_CB = LIBCUDBG_PIPE_ENDPOINT_DEBUG_CLIENT_CB,
} cudbg_pipe_endpoint_t;

typedef enum {
    CUDBG_PIPE_MSG_READ_STATE_INIT,
    CUDBG_PIPE_MSG_READ_STATE_PREAMBLE,
    CUDBG_PIPE_MSG_READ_STATE_PAYLOAD,
} cudbg_pipe_msg_read_state_t;

typedef struct cudbg_pipe_st {
    cudbg_pipe_type_t type;
    cudbg_pipe_endpoint_t from;
    cudbg_pipe_endpoint_t to;
    cudbg_pipe_msg_read_state_t read_state;     // state machine for cudbgPipeMessageRead
    cuosEvent event;                            // Event triggered when data is ready to be read
#if cuosOsIsWindows()
    void* overlap[CUDBG_PIPE_MODE_NUM];    // Win32 structure
    void* hPipe[CUDBG_PIPE_MODE_NUM];          // Pipe handle
#endif
    char name[256];                             // only used for named pipe, use malloc instead
    
    int  FD[CUDBG_PIPE_MODE_NUM];
    bool initialized[CUDBG_PIPE_MODE_NUM];
    char *message[CUDBG_PIPE_MODE_NUM];
    uint64_t messageSize[CUDBG_PIPE_MODE_NUM];
    uint64_t bytesRead;                         // maintains # of bytes currently read (for non-blocking reads)
    bool pendingFree;                           // true if the payload needs to be freed before reinit
    int64_t (*read)  (struct cudbg_pipe_st *pipe, void *buf, uint64_t size);
    int64_t (*write) (struct cudbg_pipe_st *pipe, void *buf, uint64_t size);
    void *msg;                                  // unix domain sockets, message header
    void *cmsg;                                 // unix domain sockets, control message buffer
    uint64_t messagePreambleSize;               // unix domain sockets, offset to get at message data
    uint64_t maxSendBufferSize;                 // unix domain sockets, max size of send buffer
} cudbg_pipe_t;

#define CUDBG_PIPE_CMSG_MAX_SIZE    512

CUDBGResult cudbgPipeInitialize(cudbg_pipe_t *p, cudbg_pipe_type_t type, cudbg_pipe_endpoint_t from, cudbg_pipe_endpoint_t to);
CUDBGResult cudbgPipeFinalize(cudbg_pipe_t *pipe);
CUDBGResult cudbgPipeReset(cudbg_pipe_t *pipe);
CUDBGResult cudbgPipeBlockingRead(cudbg_pipe_t *pipe, void* buf, uint64_t count, bool *eof);
CUDBGResult cudbgPipeRead(cudbg_pipe_t *pipe, void* buf, uint64_t count, bool *eof, bool *retry);
CUDBGResult cudbgPipeWrite(cudbg_pipe_t *pipe, void *buf, uint64_t count);
CUDBGResult cudbgPipeMessageAppend(cudbg_pipe_t *pipe, void *obj, uint64_t objSize);
CUDBGResult cudbgPipeMessageSend(cudbg_pipe_t *pipe);
CUDBGResult cudbgPipeMessageRead(cudbg_pipe_t *pipe, bool *retry);
CUDBGResult cudbgPipeWaitForData(cudbg_pipe_t *pipe, int *timeout);

CUDBGResult cudbgPipeControlMessageAppend(cudbg_pipe_t *pipe, void *obj, uint64_t objSize);
CUDBGResult cudbgPipeControlMessageRead(cudbg_pipe_t *pipe, int **data);
#endif
