/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/* This file contains all routines used for SW-enabled instruction-level
   preemption (originally called KILP [Kepler Instruction-Level Preemption],
   as it started with GK110/SM_35) */

#include <cudadebugger.h>
#include "cudbgutils.h"
#include "cudbgapi.h"
#include "cudbgpreemption.h"
#include "../../syscalls/debugger/kilp_structs.h"
#include <halo_state.h>

/*------------------------------- Debug Trace -------------------------------*/

#define CUDBG_PREEMPTION_TRACE_LEVEL                    haloTraceLevel
#ifndef RELEASE
#define CUDBG_PREEMPTION_TRACE(level, ...)              haloTrace(HALO_TRACE_DOMAIN_PRMPT, HALO_TRACE_TYPE_FILE, level, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#define CUDBG_PREEMPTION_TRACE_FUNCTION(level, ...)     haloTrace(HALO_TRACE_DOMAIN_PRMPT, (HALO_TRACE_TYPE_FILE | HALO_TRACE_TYPE_FUNCTION), level, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#define CUDBG_PREEMPTION_TRACE_LOCATION(level, ...)     haloTrace(HALO_TRACE_DOMAIN_PRMPT, (HALO_TRACE_TYPE_FILE | HALO_TRACE_TYPE_LINE), level, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#define CUDBG_PREEMPTION_TRACE_ELEMENT(level, ...)      haloTrace(HALO_TRACE_DOMAIN_PRMPT, HALO_TRACE_TYPE_FILE, level, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#else
#define CUDBG_PREEMPTION_TRACE(level, ...)              ((void)0)
#define CUDBG_PREEMPTION_TRACE_FUNCTION(level, ...)     ((void)0)
#define CUDBG_PREEMPTION_TRACE_LOCATION(level, ...)     ((void)0)
#define CUDBG_PREEMPTION_TRACE_ELEMENT(level, ...)      ((void)0)
#endif

static CUDBGResult
handleIlpSave(CudbgDevice dev, uint32_t rebuild_table, bool saveTrapBits)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t currentGrCtxPtr;

    CUDBG_VERIFY(dev->activeContext, CUDBG_ERROR_INTERNAL, "Attempting to preempt an invalid context!\n");

    /* Query the current ctx ptr */
    res = dev->halo.getCurrentGrCtxPtr(dev, &currentGrCtxPtr);
    if (res != CUDBG_SUCCESS) {
        CUDBG_PREEMPTION_TRACE(0, "Failed to query current ctx ptr (res = %d)\n");
        return res;
    }

    /* Build mapping table (as coordinates will change when work is restored).
       Only do this if requested to do so (run control operations must). */
    if (rebuild_table) {
        res = dev->halo.buildMappingTable(dev, saveTrapBits);
        if (res != CUDBG_SUCCESS) {
            CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Failed to build mapping table (res=%d)\n", res);
            return res;
        }
    }

    /* Setup the ILP Save.  This does two things:
         (1) Writes the PREEMPT_SAVE command into the trap handler scratchpad
         (2) Communicates to KILP syscalls that CTAs must SAVE */
    CUDBG_PREEMPTION_TRACE_FUNCTION(10, "Found active context; setting up ILP Save\n");
    res = dev->halo.controllerIlpSetupMode(dev, KILP_CONTROLLER_CMD_PREEMPT);
    if (res != CUDBG_SUCCESS) {
        CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Failed to setup ILP save for KILP (res=%d)\n", res);
        return res;
    }

    /* Resume the device, which will perform the ILP Save */
    CUDBG_PREEMPTION_TRACE_FUNCTION(10, "Resuming the device for ILP Save\n");
    res = tgdbResumeGpu(dev, false);
    if (res != CUDBG_SUCCESS) {
        CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Failed to resume the GPU (res=%d)\n", res);
        return res;
    }

    /* Synchronize on preempt-save completion */
    res = dev->halo.waitForGrCtxSave(dev, currentGrCtxPtr);
    if (res != CUDBG_SUCCESS) {
        CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Error waiting on preempt-save to finish (res=%d)\n", res);
        return res;
    }

    /* Preemption has completed.  Release shared resources.
       Specifically, this will free up any oustanding memory
       mappings over BAR1, and then release RM debug mode so
       the chip can be used by other clients. */
    res = dev->halo.releaseSharedResources(dev);
    if (res != CUDBG_SUCCESS) {
        CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Failed to release shared resources (res=%d)\n", res);
        return res;
    }

    return res;
}

static CUDBGResult
handleIlpRestore(CudbgDevice dev)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t timeout = 0;
    bool timeoutReceived = false;

    res = haloStateGetTimeoutMsec(dev, &timeout);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, CUDBG_ERROR_INTERNAL, "Internal error.\n");

    CUDBG_PREEMPTION_TRACE_FUNCTION(10, "Bringing work back to the SM (resume).\n");

    /* Communicate to KILP syscalls that CTAs must RESTORE */
    res = dev->halo.controllerIlpSetupMode(dev, KILP_CONTROLLER_CMD_RESTORE_ALL);
    if (res != CUDBG_SUCCESS) {
        CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Failed setting controller mode (res=%d)\n", res);
        return res;
    }

    /* The following resume call simply re-enables the channels that were
       previously disabled.  CTAs from the re-eanbled channels will show
       up on the SMs again. */
    res = tgdbResumeGpu(dev, false);
    if (res != CUDBG_SUCCESS) {
        CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Failed to resume the device (res=%d)\n", res);
        return res;
    }

    /* Perform the restore operation (sorts out CTAs that show up on the SM
       and ensures that only the CTAs we're expecting will pause). */
    res = dev->halo.controllerIlpRestore(dev);
    if (res != CUDBG_SUCCESS) {
        CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Failed to setup ILP resume for KILP (res=%d)\n", res);
        return res;
    }

    /* Explicitly wait for a DEVICE_EVENT here.  When we come back from preemption
       we force an event to be triggered so we can sort out the correct focus.
       Only then do we proceed with advancing run control. */
    res = tgdbWaitForDeviceEvent(dev->deviceIdx, -1, false, true, &timeout, &timeoutReceived);
    if (res != CUDBG_SUCCESS)
        return res;

    CUDBG_PREEMPTION_TRACE_FUNCTION(10, "Work has arrived back on the SM.\n");
    CUDBG_PREEMPTION_TRACE_FUNCTION(10, "Suspending and recollecting state.\n");

    res = tgdbSuspendGpu(dev);
    if (res != CUDBG_SUCCESS)
        return res;

    return res;
}

/* handlePreempt{Pre,Post}Hook() are routines that are never called
   by the preemption controller, and are only called as 'reactionary'
   hooks (when a device event occurs, or when there is a debugger
   command to advance run control) */

CUDBGResult
handlePreemptPreHook(CudbgDevice dev, uint32_t *vsm, uint32_t *wp, bool findNewCoords, bool fullDevice)
{
    CUDBGResult res = CUDBG_SUCCESS;

    res = dev->halo.preemptPreHook(dev, fullDevice ? -1 : (int32_t)*vsm);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed device-level hook\n");

    CUDBG_TRACE("handlePreemptPreHook discarding events\n");
    res = tgdbConsumeContextEvents(dev->activeContext);
    if (res != CUDBG_SUCCESS)
        CUDBG_TRACE("handlePreemptPreHook error discarding events (res=%d)\n", res);

    if (dev->halo.deviceInfo.preemptionType != HALO_PREEMPTION_TYPE_KILP) {
        CUDBG_PREEMPTION_TRACE_FUNCTION(100, "Device %d doesn't support KILP preemption, "
                                        "skipping.\n", dev->deviceIdx);
        return CUDBG_SUCCESS;
    }

    /* If we've preempted, we have to bring the CTA in question back onto the SMs, and then
       we can proceed with using HW single-step mode. */
    if (dev->preemptState == CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_PREEMPTED_FOR_DEVICE_EVENT) {
        res = handleIlpRestore(dev);
        if (res != CUDBG_SUCCESS)
            return res;

        /* Remap HW coordinates after preempt restore */
        CUDBG_PREEMPTION_TRACE_FUNCTION(10, "Restoring warp masks\n");
        res = dev->halo.restoreWarpMasks(dev);
        if (res != CUDBG_SUCCESS)
            return res;

        CUDBG_PREEMPTION_TRACE_FUNCTION(10, "Warp masks restored\n");

        if (findNewCoords) {
            res = dev->halo.findNewHWCoords(dev, *vsm, *wp, vsm, wp);
            if (res != CUDBG_SUCCESS)
                return res;

            CUDBG_PREEMPTION_TRACE_FUNCTION(10, "NEW HW COORDS -> vsm %d, wp %d\n", *vsm, *wp);
        }
    }

    return CUDBG_SUCCESS;
}

CUDBGResult
handlePreemptPostHook(CudbgDevice dev, uint32_t vsm, uint32_t rebuild_table, bool saveTrapBits, bool fullDevice)
{
    CUDBGResult res = CUDBG_SUCCESS;

    res = dev->halo.preemptPostHook(dev, fullDevice ? -1 : (int32_t)vsm);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed device-level hook\n");

    CUDBG_TRACE("handlePreemptPostHook discarding events\n");
    if (dev->activeContext) {
        res = tgdbConsumeContextEvents(dev->activeContext);
        if (res != CUDBG_SUCCESS)
            CUDBG_TRACE("handlePreemptPostHook error discarding events (res=%d)\n", res);
    }

    if (dev->halo.deviceInfo.preemptionType != HALO_PREEMPTION_TYPE_KILP) {
        CUDBG_PREEMPTION_TRACE_FUNCTION(100, "Device %d doesn't support preemption, "
                                        "skipping.\n", dev->deviceIdx);
        return CUDBG_SUCCESS;
    }

    if (dev->preemptState == CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_CTA_PREEMPTED_BY_CONTROLLER ||
        dev->preemptState == CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_ILP_PREEMPTED_BY_CONTROLLER) {
        CUDBG_PREEMPTION_TRACE_FUNCTION(100, "Device already preempted by controller, skipping.\n");
        return CUDBG_SUCCESS;
    }

    /* If we have not identified an active context, there's no need to preempt.
       Also, if we do not use the debug object, there is the potential that
       initiating a preempt can be problematic.  In particular, without the
       debug object, we can issue unsafe writes to STOP_TRIGGER (we may write
       to our context while it is INVALID, and then issuing a PREEMPT will cause
       FECS to save out the STOP_TRIGGER -- when the channel is reenabled and
       context-switches back onto GR, STOP_TRIGGER will be unexpectedly set). */
    if (!dev->activeContext || !haloStateContextIsActive(dev->activeContext)) {
        CUDBG_PREEMPTION_TRACE_FUNCTION(100, "No active context, skipping preempt.\n");
        return CUDBG_SUCCESS;
    }

    /* KILP / Experimental

       After we handle any 'pausing' event (bp, single-step, hw exception), we
       need to evict what's currently running then resume the device and
       context-switching so that graphics can come on GR. */
    CUDBG_PREEMPTION_TRACE_FUNCTION(10, "Preemption support enabled, initiating preempt.\n");

    /* 1 - Initiate CTA level preemption */
    res = dev->halo.initiatePreemptionSave(dev, &dev->preemptState);
    if (res != CUDBG_SUCCESS) {
        CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Failed to initiate preempt save for dev %d\n", dev->deviceIdx);
        return res;
    }

    /* 2 - Initiate instruction level preemption */
    if (dev->preemptState == CUDBG_PREEMPTION_STATE_ILP_PENDING) {
        uint32_t savedCount;
        CUDBG_PREEMPTION_TRACE_FUNCTION(10, "CTA Preemption timed out -> starting KILP.\n");

        res = handleIlpSave(dev, rebuild_table, saveTrapBits);
        if (res != CUDBG_SUCCESS) {
            CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Failed to handle ILP save for KILP (res=%d)\n", res);
            return res;
        }

        /* Query the saved count.  This is incremented by KILP
           syscall code after CTAs have been told to save out. */
        res = dev->halo.controllerIlpSavedCount(dev, &savedCount);
        if (res != CUDBG_SUCCESS) {
            CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Failed to read preempt save counter (res=%d)\n", res);
            return res;
        }

        dev->suspended = true; /* This is 'fake', of course. */

        CUDBG_PREEMPTION_TRACE_FUNCTION(20, "Saved %d CTAs\n", savedCount);

        if (savedCount) {
            CUDBG_PREEMPTION_TRACE_FUNCTION(50, "Saved a non-zero amount of CTAs using ILP.\n");
            dev->preemptState = CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_PREEMPTED_FOR_DEVICE_EVENT;
        }
        else {
            CUDBG_PREEMPTION_TRACE_FUNCTION(50, "Saved zero CTAs using ILP, set CTA preempt state\n");
            dev->preemptState = CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_CTA_PREEMPTED;

            /* Communicate to KILP syscalls that CTAs are allowed to RUN */
            res = dev->halo.controllerIlpSetupMode(dev, KILP_CONTROLLER_CMD_RUN);
            if (res != CUDBG_SUCCESS) {
                CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Failed to clear ILP save for KILP (res=%d)\n", res);
                return res;
            }
        }
    }
    else if (dev->preemptState == CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_CTA_PREEMPTED ||
             (dev->preemptState == CUDBG_PREEMPTION_STATE_ILP_PENDING && !dev->activeContext)) {
        /* If we're here, then one of two things has happened:
               1.  All channels were successfully CTA preempted (common case)
               2.  CTA preemption timed out, but nothing was resident on GR.

           Both cases are treated the same way.  The channels in question have
           been disabled, and we just need to make sure the device is properly
           resumed and we've setup state to know that upon restore we only
           require issuing a CTA-level restore (channel enablement). */
        CUDBG_PREEMPTION_TRACE_FUNCTION(10, "Resuming the SMs....channels are ALL disabled.\n");

        dev->preemptState = CUDBG_PREEMPTION_STATE_NOT_PREEMPTED; // Make sure we resume (see resumeDevice)
        res = tgdbResumeGpu(dev, false);
        if (res != CUDBG_SUCCESS) {
            CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Failed to resume the GPU (res=%d)\n", res);
            return res;
        }

        dev->suspended = true; /* This is 'fake', of course. */
        dev->preemptState = CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_CTA_PREEMPTED;
    }

    return CUDBG_SUCCESS;
}

CUDBGResult
findNewWarpMask(CudbgDevice dev, uint32_t *vsm, CUwarpBitmask *warpMask)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t oldVsm, oldWp;
    uint32_t newVsm, newWp;
    CUwarpBitmask newWarpMask = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;
    CUwarpBitmask oldWarpMask = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;
    bool newCoordsFound = false;

    CUDBG_VERIFY(vsm && warpMask, CUDBG_ERROR_INTERNAL, "Invalid args to internal routine");

    oldVsm = *vsm;
    warpBitmaskAssign(&oldWarpMask, warpMask);

    for (oldWp = 0; oldWp < dev->halo.deviceInfo.numWarpsPrSM; oldWp++) {
        if (!warpBitmaskGetBits(&oldWarpMask, oldWp, 1))
            continue;

        res = dev->halo.findNewHWCoords(dev, oldVsm, oldWp, &newVsm, &newWp);
        if (res != CUDBG_SUCCESS) {
            CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Call to findNewHWCoords failed\n");
            return res;
        }

        warpBitmaskSetBits(&newWarpMask, newWp, 1, 1);
        newCoordsFound = true;
    }

    if (!newCoordsFound) {
        CUDBG_PREEMPTION_TRACE_FUNCTION(0, "No new valid coordinates found\n");
        return CUDBG_ERROR_INTERNAL;
    }

    *vsm = newVsm;
    warpBitmaskAssign(warpMask, &newWarpMask);

    return res;
}

CUDBGResult
handlePreemptSuspendState(CudbgDevice dev, bool *preemptHasAlreadySuspended)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(preemptHasAlreadySuspended, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    /* Initialize to false */
    *preemptHasAlreadySuspended = false;

    if (dev->preemptState == CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_PREEMPTED_FOR_DEVICE_EVENT) {
        CUDBG_PREEMPTION_TRACE_FUNCTION(20, "PREEMPTED state detected.  "
                                        "Not suspending/recollecting state\n");
        *preemptHasAlreadySuspended = true;
    }
    else if (dev->preemptState == CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_ILP_PREEMPTED_BY_CONTROLLER) {
        CUDBG_PREEMPTION_TRACE_FUNCTION(20, "Controller ILP PREEMPTED state detected.  "
                                        "Not suspending/recollecting state\n");
        /* If the controller indicates it has ILP'd, then it has already done the work
           for us.  Do not perform an additional suspend, and switch preemption state
           away from the controller. */
        dev->preemptState = CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_PREEMPTED_FOR_DEVICE_EVENT;
        dev->suspended = true;
        *preemptHasAlreadySuspended = true;

    }
    else if (dev->preemptState == CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_CTA_PREEMPTED_BY_CONTROLLER) {
        CUDBG_PREEMPTION_TRACE_FUNCTION(20, "Controller CTA PREEMPTED state detected.  "
                                        "Not suspending/recollecting state\n");
        /* If the controller indicates it has CTA Preempted, then it has already done
           the work for us.  Do not perform an additional suspend, and switch preemption
           state away from the controller.  Note that we must clear SM state at this point
           as there is no work for the frontend to see here. */
        dev->preemptState = CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_CTA_PREEMPTED;
        dev->suspended = true;
        res = dev->halo.clearSMState(dev);
        if (res != CUDBG_SUCCESS)
            return res;
        *preemptHasAlreadySuspended = true;
    }

    return CUDBG_SUCCESS;
}

/* The asynchronous controller will invoke handlePreemptTimeoutEvent
   periodically, which attempts to preempt contexts that are actively
   running on the graphics engine (for GPUs that support preemption).
   The asynchronous controller is the one responsible for handling
   infinite or long-running compute kernels, while the synchronous
   part of the controller is the one that responds to activity on
   the GPU that can lead to lockup conditions (breakpoints, errors).
   We can enable/disable the asynchronous controller with the
   CUDA_GDB_KILP_ASYNC environment variable. */
static bool
useAsyncController(void)
{
    bool ret = true;

#ifndef RELEASE
    char str[CUOS_ENV_VAR_LENGTH];
    if (!cuosGetEnv("CUDA_GDB_KILP_ASYNC", str, sizeof(str)))
        ret = !!(atol(str));
#endif
    return ret;
}

CUDBGResult
handlePreemptTimeoutEvent(uint32_t deviceMask)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CudbgDevice dev;
    uint32_t devId, savedCount;
    bool isKnownDeviceEvent = false;

    // Bail early if required
    if (!useAsyncController()) {
        return CUDBG_SUCCESS;
    }

    for (devId = 0; devId < CUDBG_MAX_DEVICES; ++devId) {
        dev = haloGlobals.device[devId];

        if (!dev || !dev->isDebuggable)
            continue;

        if (dev->suspended) {
            CUDBG_PREEMPTION_TRACE_FUNCTION(100, "Device %d declared suspended, skipping preempt.\n", devId);
            continue;
        }

        if (dev->halo.deviceInfo.preemptionType != HALO_PREEMPTION_TYPE_KILP) {
            CUDBG_PREEMPTION_TRACE_FUNCTION(100, "Device %d doesn't support preemption, skipping.\n", devId);
            continue;
        }

        if (dev->preemptState == CUDBG_PREEMPTION_STATE_NOT_PREEMPTED) {
            CUDBG_PREEMPTION_TRACE_FUNCTION(1, "Initiating preemption save on device %d\n", devId);
            res = dev->halo.initiatePreemptionSave(dev, &dev->preemptState);
            if (res != CUDBG_SUCCESS) {
                CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Failed to initiate preempt save for device %d\n", devId);
                return res;
            }

            /* If we've detected long/indefinite-running compute, initiate ILP */
            if (dev->preemptState == CUDBG_PREEMPTION_STATE_ILP_PENDING) {
                CUDBG_PREEMPTION_TRACE_FUNCTION(10, "CTA Preemption timed out (controller)\n");

                /* Asynchronously suspend the device and collect state */
                res = tgdbSuspendGpu(dev);
                if (res != CUDBG_SUCCESS) {
                    CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Failed to suspend the GPU (res=%d)\n", res);
                    return res;
                }

                /* If we find an active context on the device, preempt it */
                if (dev->activeContext && haloStateContextIsActive(dev->activeContext)) {
                    res = handleIlpSave(dev, 1 /* setup the remap table */, true /* save trap bits */);
                    if (res != CUDBG_SUCCESS) {
                        CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Controller failed to ILP save (res=%d)\n", res);
                        return res;
                    }

                    res = dev->halo.controllerIlpSavedCount(dev, &savedCount);
                    if (res != CUDBG_SUCCESS) {
                        CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Failed to read preempt save counter (res=%d)\n", res);
                        return res;
                    }

                    CUDBG_PREEMPTION_TRACE_FUNCTION(20, "Saved %d CTAs\n", savedCount);

                    if (savedCount) {
                        /* ILP preemption completed, set preemption state accordingly */
                        dev->preemptState = CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_ILP_PREEMPTED_BY_CONTROLLER;

                        res = tgdbIsKnownDeviceEvent(dev, &isKnownDeviceEvent);
                        if (res != CUDBG_SUCCESS)
                            CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Call to tgdbIsKnownDeviceEvent failed.\n");

                        /* If this is a real device event (not due to the async suspend here)
                           then notify the client debugger about it.  We do not want to miss
                           real events that happen to coalesce with the async controller. */
                        if (isKnownDeviceEvent) {
                            CUDBG_PREEMPTION_TRACE_FUNCTION(1, "Aliased device event with async controller"
                                                            "notifying client debugger!\n");
                            gpudbgNotifyDebugger(dev->activeContext->hostThreadId, false);
                        }
                    }
                    else {
                        /* CTA preemption completed, set preemption state accordingly */
                        dev->preemptState = CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_CTA_PREEMPTED_BY_CONTROLLER;

                        /* Communicate to KILP syscalls that CTAs are allowed to RUN */
                        res = dev->halo.controllerIlpSetupMode(dev, KILP_CONTROLLER_CMD_RUN);
                        if (res != CUDBG_SUCCESS) {
                            CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Failed to clear ILP save for KILP (res=%d)\n", res);
                            return res;
                        }
                    }
                }
                else {
                    /* Bugs 1265219 and 1265823:
                       There was no active context despite CTA preemption timing out.
                       This means that we lost the race and warps were about to leave
                       the SM just when CTA preemption timed out.  In this case, make
                       sure the device is fully resumed (it was suspended above) and
                       indicate that we have not preempted.  We'll come back later. */
                    CUDBG_PREEMPTION_TRACE_FUNCTION(1, "Async CTA Preemption timed out, but no activity\n");
                    dev->preemptState = CUDBG_PREEMPTION_STATE_NOT_PREEMPTED; // Make sure we resume
                    res = tgdbResumeGpu(dev, false);
                    if (res != CUDBG_SUCCESS) {
                        CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Failed to resume the GPU (res=%d)\n", res);
                        return res;
                    }
                }
            }
            else {
                /* CTA preemption completed, set preemption state accordingly */
                dev->preemptState = CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_CTA_PREEMPTED_BY_CONTROLLER;
            }
        }
        else if (dev->preemptState == CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_CTA_PREEMPTED_BY_CONTROLLER) {
            CUDBG_PREEMPTION_TRACE_FUNCTION(1, "Initiating (CTA) preemption restore on device %d\n", devId);
            res = dev->halo.initiatePreemptionRestore(dev, &dev->preemptState);
            if (res != CUDBG_SUCCESS) {
                CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Failed to initiate preempt restore for device %d\n", devId);
                return res;
            }
        }
        else if (dev->preemptState == CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_ILP_PREEMPTED_BY_CONTROLLER) {
            CUDBG_PREEMPTION_TRACE_FUNCTION(1, "Initiating (ILP) preemption restore on device %d\n", devId);
            res = handleIlpRestore(dev);
            if (res != CUDBG_SUCCESS) {
                CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Failed to ILP restore (res=%d)\n", res);
                return res;
            }

            /* Communicate to KILP syscalls that CTAs are allowed to RUN */
            res = dev->halo.controllerIlpSetupMode(dev, KILP_CONTROLLER_CMD_RUN);
            if (res != CUDBG_SUCCESS) {
                CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Failed to set KILP RUN mode (res=%d)\n", res);
                return res;
            }

            CUDBG_PREEMPTION_TRACE_FUNCTION(1, "Resuming work on the device %d\n", devId);
            res = tgdbResumeGpu(dev, false);
            if (res != CUDBG_SUCCESS) {
                CUDBG_PREEMPTION_TRACE_FUNCTION(0, "Failed to resume the device (res=%d)\n", res);
                return res;
            }
        }
    }

    return res;
}
