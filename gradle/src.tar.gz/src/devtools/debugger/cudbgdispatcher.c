/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */


/*-------------------------------- Includes ---------------------------------*/

#include "cudadebugger.h"
#include "cudbgtarget.h"
#include "cudbgutils.h"
#include "cudbgpipe.h"
#include "cudbgapi.h"
#include "cudbgdispatcher.h"
#include "cudbgdriver.h"
#include "halo_state.h"
#include "halo_trace.h"
#if cuosOsIsApple()
#include "cudbgdarwin.h"
#endif

#include <cuda.h>
#include <cuda_private.h>

#include <sys/types.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#ifdef __linux__
#include <poll.h>
#endif

#include "../../syscalls/debugger/kilp_structs.h"
#include "cudbgpreemption.h"

cudbg_pipe_t debuggerToDispatcher;
cudbg_pipe_t dispatcherToDebugger;
cudbg_pipe_t applicationToDispatcher;
cudbg_pipe_t dispatcherToApplication;
CUOSthread* cudbgDispatcherThreadHandle;

/*------------------------------- Debug Trace -------------------------------*/

#define CUDBG_DISPATCHER_TRACE_LEVEL                    haloTraceLevel
#ifndef RELEASE
#define CUDBG_DISPATCHER_TRACE(level, ...)              haloTrace(HALO_TRACE_DOMAIN_DISP, HALO_TRACE_TYPE_FILE, level, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#define CUDBG_DISPATCHER_TRACE_FUNCTION(level, ...)     haloTrace(HALO_TRACE_DOMAIN_DISP, (HALO_TRACE_TYPE_FILE | HALO_TRACE_TYPE_FUNCTION), level, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#define CUDBG_DISPATCHER_TRACE_LOCATION(level, ...)     haloTrace(HALO_TRACE_DOMAIN_DISP, (HALO_TRACE_TYPE_FILE | HALO_TRACE_TYPE_LINE), level, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#define CUDBG_DISPATCHER_TRACE_ELEMENT(level, ...)      haloTrace(HALO_TRACE_DOMAIN_DISP, HALO_TRACE_TYPE_FILE, level, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#define TGDB_TIMEOUT                          15 // seconds
#define TGDB_TIMEOUT_MSEC                  15000 // milliseconds
#define TGDB_TIMEOUT_MSEC_KILP                 5 // milliseconds
#else
#define CUDBG_DISPATCHER_TRACE(level, ...)              ((void)0)
#define CUDBG_DISPATCHER_TRACE_FUNCTION(level, ...)     ((void)0)
#define CUDBG_DISPATCHER_TRACE_LOCATION(level, ...)     ((void)0)
#define CUDBG_DISPATCHER_TRACE_ELEMENT(level, ...)      ((void)0)
#define TGDB_TIMEOUT                           3 // seconds
#define TGDB_TIMEOUT_MSEC                   3000 // milliseconds
#define TGDB_TIMEOUT_MSEC_KILP                 5 // milliseconds
#endif

/*----------------------------------- Types ---------------------------------*/

typedef struct {
    uint32_t deviceEventMask;
    uint32_t deviceExceptionMask;
    bool debuggerEvent;
    bool debuggerException;
    bool applicationEvent;
    bool applicationException;
    bool timeout;
    Context context;
} CUDBGDispatcherEvent;

#define CUDBG_NO_EVENT ((CUDBGDispatcherEvent) { 0, 0, false, false, false, false, false, NULL })

/*--------------------------------- Prototypes -------------------------------*/

static CUDBGResult waitForEvent(uint32_t deviceMask, bool application, bool debugger, int timeoutMs, CUDBGDispatcherEvent *event);
static CUDBGResult handleTimeoutEvent(uint32_t deviceMask, uint32_t *deviceEventMask, bool *notifyDebugger, uint32_t *notifyHostThreadId);
static CUDBGResult handleDeviceEvent(CudbgDevice dev, Context triggerCtx, bool *notifyDebugger, uint32_t *notifyHostThreadId, bool timeoutReceived, bool *sendTimeoutNotif);
static CUDBGResult handleDebuggerEvent(bool *terminate, bool *pendingAckToApplication, bool *notifyDebugger, uint32_t *notifyHostThreadId);
static CUDBGResult handleSignals(void);
static CUDBGResult handleApplicationEvent(bool *notifyDebugger, uint32_t *notifyHostThreadId, bool *pendingAckToApplication);
static CUDBGResult ackApplication(void);
static CUDBGResult handleExceptionEvent(CUDBGDispatcherEvent *event,
                                        bool *monitorApplication,
                                        bool *monitorDebugger);

/*-------------------------------- Definitions -------------------------------*/

#define CUDBG_DEVICE_EVENT_TIMEOUT_THRESHOLD 3
unsigned int deviceEventTimeoutsReceived = 0;

int
cudbgDispatcher(void* ignore)
{
    int devId = 0;
    CudbgDevice dev;
    bool terminate = false;
    bool sendTimeoutNotif = false;
    CUDBGDispatcherEvent event;
    uint32_t deviceMask = 0xffffffff; // XXX multi-gpu/multi-gdb: be more fine-grain
    /* If preemption is enabled, we need quicker timeouts */
    int timeout = CUDBG_ENABLE_PREEMPTION_DEBUGGING ? TGDB_TIMEOUT_MSEC_KILP : TGDB_TIMEOUT_MSEC;
    bool monitorApplication = true, monitorDebugger = true, notifyDebugger = false;
    uint32_t notifyHostThreadId;
    bool pendingAckToApplication = false;
    CUDBGResult res;

    CUDBG_DISPATCHER_TRACE_FUNCTION(1, "spawned\n");

    handleSignals();

    while (1) {
        monitorApplication &= applicationToDispatcher.initialized[CUDBG_PIPE_MODE_READ];
        monitorDebugger &= debuggerToDispatcher.initialized[CUDBG_PIPE_MODE_READ];
        notifyDebugger = false;
        sendTimeoutNotif = false;
        notifyHostThreadId = 0;
        memset(&event, 0, sizeof event);

        res = waitForEvent(deviceMask, monitorApplication, monitorDebugger, timeout, &event);
        if (res != CUDBG_SUCCESS) {
            CUDBG_DISPATCHER_TRACE_FUNCTION(0, "failed waiting for event\n");
            gpudbgProcessInternalError(res);
            // continue to the next loop after reporting the error so that we don't call notifyDebugger again
            continue;
        }

        if (event.timeout) {
            /* This is the entrypoint for the preemption controller.  Upon waking
               up, inspect what's running and preempt any contexts that need to
               get off of GR.  Always handle preemption first (for devices which
               support it). */
            if (CUDBG_ENABLE_PREEMPTION_DEBUGGING) {
                res = handlePreemptTimeoutEvent(deviceMask);
                if (res != CUDBG_SUCCESS) {
                    CUDBG_DISPATCHER_TRACE_FUNCTION(0, "failed handling preempt timeout event\n");
                    gpudbgProcessInternalError(res);
                }
                continue;
            }
            else {
                res = handleTimeoutEvent(deviceMask, &event.deviceEventMask, &notifyDebugger, &notifyHostThreadId);
                if (res != CUDBG_SUCCESS) {
                    CUDBG_DISPATCHER_TRACE_FUNCTION(0, "failed handling timeout event\n");
                    gpudbgProcessInternalError(res);
                    continue;
                }
            }
        }

        if (event.deviceExceptionMask || event.debuggerException || event.applicationException)
            handleExceptionEvent(&event, &monitorApplication, &monitorDebugger);

        /* Debugger events must be handled before application events
           because pendingAckToApplication could be set to true at the
           same time as an ack for a timeout event is received from
           the debugger. */
        if (event.debuggerEvent) {
            res = handleDebuggerEvent(&terminate, &pendingAckToApplication, &notifyDebugger, &notifyHostThreadId);
            if (res != CUDBG_SUCCESS) {
                CUDBG_DISPATCHER_TRACE_FUNCTION(0, "failed handling debugger event\n");
                /* Ignoring the error, see comments above handleDebuggerEvent */
                continue;
            }

            if (terminate)
                break;
        }

        if (event.applicationEvent) {
            res = handleApplicationEvent(&notifyDebugger, &notifyHostThreadId, &pendingAckToApplication);
            if (res != CUDBG_SUCCESS) {
                CUDBG_DISPATCHER_TRACE_FUNCTION(0, "failed handling application event\n");
                gpudbgProcessInternalError(res);
                continue;
            }
        }

        if (event.deviceEventMask) {
            for (devId = 0; devId < CUDBG_MAX_DEVICES; ++devId) {
                dev = haloGlobals.device[devId];

                if (!dev || !dev->isDebuggable)
                    continue;

                if (dev && event.deviceEventMask >> devId & 1) {
                    res = handleDeviceEvent(dev, event.context, &notifyDebugger,
                                            &notifyHostThreadId, event.timeout,
                                            &sendTimeoutNotif);
                    if (res != CUDBG_SUCCESS) {
                        CUDBG_DISPATCHER_TRACE_FUNCTION(0, "failed handling device event\n");
                        gpudbgProcessInternalError(res);
                        continue;
                    }
                }
            }
        }

        if (notifyDebugger)
            gpudbgNotifyDebugger(notifyHostThreadId, sendTimeoutNotif);
    }

    CUDBG_DISPATCHER_TRACE_FUNCTION(1, "terminated\n");
    return 0;
}

static CUDBGResult
ackApplication(void)
{
    int ack = 1;
    CUDBGResult res;

    if (cudbgDriverOptionsChanged) {
        /* ack the application and signal that there is more coming. (ack=2) */
        ack = 2;
        if ((res = cudbgPipeWrite(&dispatcherToApplication, &ack, sizeof(ack))))
            return res;

        /* starting after 3.2, pass the driver options to the application using the ack mechanism. */
        if ((res = cudbgPipeWrite(&dispatcherToApplication, &cudbgDriverOptions, sizeof(cudbgDriverOptions))))
            return res;
        cudbgDriverOptionsChanged = false;
    }
    else {
        /* ack the application and signal that there is nothing more coming. (ack=1) */
        ack = 1;
        if ((res = cudbgPipeWrite(&dispatcherToApplication, &ack, sizeof(ack))))
            return res;
    }

    return CUDBG_SUCCESS;
}


static CUDBGResult
getEventArray(uint32_t deviceMask, cuosEvent **eventList, Context *contextList, int *arraySize)
{
    CUDBGResult res = CUDBG_SUCCESS;
    int numEvents = 0, numEventsDevice = 0, devId = 0;
    cuosEvent** eventListPtr = NULL;
    Context *contextListPtr = NULL;
    CudbgDevice dev = NULL;

    CUDBG_VERIFY(arraySize, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    /* Collect the size of the array we need */
    for (devId = 0; devId < CUDBG_MAX_DEVICES; ++devId) {
        dev = haloGlobals.device[devId];
        if (dev == NULL ||
            !dev->isDebuggable ||
            (deviceMask >> devId & 1) == 0 ||
            dev->status != CUDBG_SUCCESS)
            continue;
        res = dev->dmal->getEventListForDevice(dev, NULL, NULL, &numEventsDevice, 0);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get event list size\n");
        numEvents += numEventsDevice;
    }

    eventListPtr = eventList;
    contextListPtr = contextList;
    *arraySize = numEvents;

    /* Not filling up the event array, done. */
    if (!eventList)
        return res;

    /* Fill up the array with the events to wait on */
    for (devId = 0; devId < CUDBG_MAX_DEVICES; ++devId) {
        dev = haloGlobals.device[devId];
        if (dev == NULL ||
            !dev->isDebuggable ||
            (deviceMask >> devId & 1) == 0 ||
            dev->status != CUDBG_SUCCESS)
            continue;
        res = dev->dmal->getEventListForDevice(dev, eventListPtr, contextListPtr, &numEventsDevice, numEvents);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get event list size\n");
        numEvents -= numEventsDevice;
        eventListPtr += numEventsDevice;
        if (contextListPtr)
            contextListPtr += numEventsDevice;
    }

    return res;
}

static CUDBGResult
waitForEvent(uint32_t deviceMask, bool app, bool dbg, int timeoutMs, CUDBGDispatcherEvent *event)
{
    CUDBGResult res = CUDBG_SUCCESS;
    int totalDeviceEvents = 0, totalEvents = 0, i = 0, idx = 0, numEventsTriggered;
    static int *triggeredEventIndex = NULL;
    static cuosEvent **eventList = NULL;
    static Context *contextList = NULL;

    CUDBG_VERIFY(event, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in waitForEvent.\n");

    res = getEventArray(deviceMask, NULL, NULL, &totalDeviceEvents);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get all the device's event list\n");

    eventList = (cuosEvent **)realloc(eventList, (totalDeviceEvents+2) * sizeof(*eventList));
    CUDBG_VERIFY(eventList, CUDBG_ERROR_OS_RESOURCES, "realloc failed\n");

    if (totalDeviceEvents) {
        contextList = (Context *)realloc(contextList, totalDeviceEvents * sizeof(*contextList));
        CUDBG_VERIFY(contextList, CUDBG_ERROR_OS_RESOURCES, "realloc failed\n");
    }

    triggeredEventIndex = (int *)realloc(triggeredEventIndex, (totalDeviceEvents+2) * sizeof(*triggeredEventIndex));
    CUDBG_VERIFY(triggeredEventIndex, CUDBG_ERROR_OS_RESOURCES, "realloc failed\n");

    res = getEventArray(deviceMask, eventList, contextList, &totalDeviceEvents);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get all the device's event list\n");
    totalEvents = totalDeviceEvents;

    if (dbg) {
        eventList[totalEvents] = &debuggerToDispatcher.event;
        totalEvents++;
    }
    if (app) {
        eventList[totalEvents] = &applicationToDispatcher.event;
        totalEvents++;
    }

    CUDBG_DISPATCHER_TRACE_FUNCTION(1, "totalDeviceEvents=%d\n", totalDeviceEvents);

    numEventsTriggered = cuosEventWaitMultiple(eventList, totalEvents, triggeredEventIndex, totalEvents, timeoutMs);
    CUDBG_VERIFY(numEventsTriggered >= 0, CUDBG_ERROR_COMMUNICATION_FAILURE, "cuosEventWaitMultiple failed!\n");

    if (numEventsTriggered == 0)
        event->timeout = true;

    for (i = 0; i < numEventsTriggered; ++i) {
        idx = triggeredEventIndex[i];
        if (idx < totalDeviceEvents) {
            event->deviceEventMask |= 1U << (contextList[idx]->dev->deviceIdx);
            event->context = contextList[idx];
        }
        else if (eventList[idx] == &debuggerToDispatcher.event) {
            event->debuggerEvent = true;
            event->debuggerException = !cuosEventIsSafeToSignal(&debuggerToDispatcher.event);
        }
        else if (eventList[idx] == &applicationToDispatcher.event) {
            event->applicationEvent = true;
            event->debuggerException = !cuosEventIsSafeToSignal(&applicationToDispatcher.event);
        }
        else {
            CUDBG_ERROR("Unknown event triggered! idx=%d\n", idx);
            return CUDBG_ERROR_INTERNAL;
        }
    }

    CUDBG_DISPATCHER_TRACE_FUNCTION(49, "got event = { %08x, %08x, %u, %u, %u, %u, %u, 0x% " PRIx64 " }\n",
                                    event->deviceEventMask, event->deviceExceptionMask,
                                    event->debuggerEvent, event->debuggerException,
                                    event->applicationEvent, event->applicationException,
                                    event->timeout, (event->context ? event->context->cuCtx : 0ULL));
    return CUDBG_SUCCESS;
}

/* This function will send the result/error directly back to the debug client.
   If there's a pipe error while sending the result, we currently rely on a
   SIGPIPE to catch it. */
static CUDBGResult
handleDebuggerEvent(bool *terminate, bool *pendingAckToApplication, bool *notifyDebugger, uint32_t *notifyHostThreadId)
{
    CudbgDevice dev;
    bool eof = false, retry = false, preemptHasAlreadySuspended = false;
    static debuggerMessage_t debuggerMessage;
    debuggerMessageReply_t reply;
    uint32_t vsm, dummyWp;
    CUDBGResult devRes = CUDBG_ERROR_UNKNOWN, devRes2 = CUDBG_ERROR_UNKNOWN;
    CUDBGResult res = CUDBG_ERROR_UNKNOWN;
    bool checkCtxSyncOnStep = false;
    CUwarpBitmask warpMask;

    warpBitmaskFill(&warpMask, 0);
    *terminate = false;
    CUDBG_DISPATCHER_TRACE_FUNCTION(3, "\n");

    if ((res = cudbgPipeRead(&debuggerToDispatcher, &debuggerMessage, sizeof(debuggerMessage), &eof, &retry)))
        return res;

    /* if retry was set, we must return (maintaining all
       state in the debuggerToDispatcher pipe).  We'll
       come back to finish later. */
    if (retry) {
        CUDBG_DISPATCHER_TRACE_FUNCTION(1, "cudbgPipeRead needs to retry\n");
        return CUDBG_SUCCESS;
    }

    if (eof)
        return CUDBG_SUCCESS;

    /* reset the number of bytes read */
    debuggerToDispatcher.bytesRead = 0;

    CUDBG_DISPATCHER_TRACE_FUNCTION(3, "kind=%d dev=%u vsm=%u wp=%u\n",
                                    debuggerMessage.kind, debuggerMessage.dev,
                                    debuggerMessage.vsm, debuggerMessage.wp);

    if (debuggerMessage.dev >= CUDBG_MAX_DEVICES) {
        CUDBG_DISPATCHER_TRACE_FUNCTION(0, "Invalid device.\n");
        devRes = CUDBG_ERROR_INVALID_DEVICE;
        goto finish;
    }
    dev = haloGlobals.device[debuggerMessage.dev];
    if (!dev) {
        CUDBG_DISPATCHER_TRACE_FUNCTION(0, "Invalid device.\n");
        devRes = CUDBG_ERROR_INVALID_DEVICE;
        goto finish;
    }

    switch (debuggerMessage.kind) {
    case TGDB_DBGMSG_SUSPEND:
        if (dev->status != CUDBG_SUCCESS) {
            CUDBG_DISPATCHER_TRACE_FUNCTION(0, "Device error: %u when suspending device.\n", dev->status);
            devRes = dev->status;
            break;
        }

        devRes = handlePreemptSuspendState(dev, &preemptHasAlreadySuspended);
        if (preemptHasAlreadySuspended)
            break;

        devRes = tgdbSuspendGpu(dev);
        removeBreakpoints(dev);
        if (devRes == CUDBG_ERROR_SUSPENDED_DEVICE) {
            CUDBG_DISPATCHER_TRACE_FUNCTION(50, "SuspendGpu failed. Device already suspended (res=%d)\n", devRes);
        }
        else if (devRes != CUDBG_SUCCESS) {
            CUDBG_DISPATCHER_TRACE_FUNCTION(0, "SuspendGpu failed (res=%d)\n", devRes);
        }

        devRes2 = handlePreemptPostHook(dev, debuggerMessage.vsm, 1, true, true);
        if (devRes2 != CUDBG_SUCCESS) {
            CUDBG_DISPATCHER_TRACE_FUNCTION(0, "Preempt post-hook failed (res=%d)\n", devRes2);
            devRes = devRes2;
            break;
        }
        break;

    case TGDB_DBGMSG_RESUME:
        if (dev->status != CUDBG_SUCCESS) {
            CUDBG_DISPATCHER_TRACE_FUNCTION(0, "Device error: %u when resuming device.\n", dev->status);
            devRes = dev->status;
            break;
        }

        devRes = handlePreemptPreHook(dev, &debuggerMessage.vsm, &debuggerMessage.wp, false, true);
        if (devRes != CUDBG_SUCCESS) {
            CUDBG_DISPATCHER_TRACE_FUNCTION(0, "Preempt single-step pre-hook failed (res=%d)\n", devRes);
            break;
        }

        if (haloGlobals.initData.haloType != HALO_TYPE_UNIFIED_DEBUGGER) {
            /* Skip this for unified debugger for now as unified debugger relies
               on PPA for SW stepping */
            devRes = tgdbSingleStepOverBreakpoint(dev);
        }

        if (devRes == CUDBG_ERROR_WARP_RESUME_NOT_POSSIBLE) {
            /* sstepOverBreakpoint will return WARP_RESUME_NOT_POSSIBLE if the gpu
               stepped, but ended up causing an exception to occur.  In this case,
               don't resume the gpu and instead preempt off and notify the debugger */
            devRes = handlePreemptPostHook(dev, debuggerMessage.vsm, 1, true, true);
            if (devRes != CUDBG_SUCCESS) {
                CUDBG_DISPATCHER_TRACE_FUNCTION(0, "Preempt post-hook failed (res=%d)\n", devRes);
                break;
            }

            /* Tell cudbgDispatcher to notify the debugger there's a new pending
               exception */
            dev->expectingGpuEvent = 1;
            *notifyDebugger = true;
            *notifyHostThreadId = dev->activeContext->hostThreadId;

            break;
        }
        else if (devRes != CUDBG_SUCCESS)
            break;

        if (haloGlobals.initData.haloType != HALO_TYPE_UNIFIED_DEBUGGER) {
            /* Skip this for unified debugger for now as unified debugger relies
               on PPA for SW stepping */
            insertBreakpoints(dev, false);
        }

        if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_KILP) {
            /* Communicate to KILP syscalls that CTAs are allowed to RUN */
            devRes = dev->halo.controllerIlpSetupMode(dev, KILP_CONTROLLER_CMD_RUN);
            if (devRes != CUDBG_SUCCESS) {
                CUDBG_DISPATCHER_TRACE_FUNCTION(0, "Failed to setup controller mode (res=%d)\n", devRes);
                break;
            }
        }

        devRes = tgdbResumeGpu(dev, false);
        break;

    case TGDB_DBGMSG_RESUMEWARPS:
        if (dev->status != CUDBG_SUCCESS) {
            CUDBG_DISPATCHER_TRACE_FUNCTION(0, "Device error: %u in resume warps.\n", dev->status);
            devRes = dev->status;
            break;
        }

        devRes = handlePreemptPreHook(dev, &debuggerMessage.vsm, &dummyWp, false, false);
        if (devRes != CUDBG_SUCCESS) {
            CUDBG_DISPATCHER_TRACE_FUNCTION(0, "Preempt resume warps pre-hook failed (res=%d)\n", devRes);
            break;
        }

        /* The warp mask is stored in debuggerMessage.data.warpMask */
        warpBitmaskAssign(&warpMask, &debuggerMessage.data.warpMask);

        /* Need to recompute the entire warp mask and the vsm */
        if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_KILP) {
            devRes = findNewWarpMask(dev, &debuggerMessage.vsm, &warpMask);
            if (devRes != CUDBG_SUCCESS)
                break;
        }

        if (haloGlobals.initData.haloType != HALO_TYPE_UNIFIED_DEBUGGER) {
            /* Insert any breakpoints that have been added to the list.
            (This may include a temporary breakpoint). */
            insertBreakpoints(dev, false);
        }

        /*   If the call to tgdbResumeWarps errors out, do not early exit
           as we must remove the breakpoints inserted beforehand. */
        devRes = tgdbResumeWarps(dev, debuggerMessage.vsm, &warpMask, false);

        if (haloGlobals.initData.haloType != HALO_TYPE_UNIFIED_DEBUGGER) {
            /* Remove any breakpoints */
            removeBreakpoints(dev);
        }

        devRes2 = handlePreemptPostHook(dev, debuggerMessage.vsm, 1, false, false);
        if (devRes2 != CUDBG_SUCCESS) {
            CUDBG_DISPATCHER_TRACE_FUNCTION(0, "Preempt post-hook failed (res=%d)\n", devRes2);
            devRes = devRes2; /* Overwrite devRes if there is an error here */
            break;
        }

        break;

    case TGDB_DBGMSG_SSTEPWARP:
        if (dev->status != CUDBG_SUCCESS) {
            CUDBG_DISPATCHER_TRACE_FUNCTION(0, "Device error: %u in single step warp.\n", dev->status);
            devRes = dev->status;
            break;
        }

        devRes = handlePreemptPreHook(dev, &debuggerMessage.vsm, &debuggerMessage.wp, true, false);
        if (devRes != CUDBG_SUCCESS) {
            CUDBG_DISPATCHER_TRACE_FUNCTION(0, "Preempt single-step pre-hook failed (res=%d)\n", devRes);
            break;
        }

        checkCtxSyncOnStep = !!(debuggerMessage.data.checkCtxSync);

        /* The warp mask is stored in debuggerMessage.data.warpMask */
        warpBitmaskAssign(&warpMask, &debuggerMessage.data.warpMask);

        /* Single stepping a warp can return a non fatal error (CUDBG_ERROR_WARP_RESUME_NOT_POSSIBLE). This
           is to handle EPLB + CNP, where stepping the syscall for a cudaDeviceSynchronize() is illegal.
           The problem here is that the device code cannot make forward progress without the host. The
           debug client needs to set a break point and resume both host and device.
           For the sake of compatibility, this feature is only enabled for 6.0+ clients.
           The debuggerMessage.data.checkCtxSync field contains a 1 if the client is new enough. */
        devRes = tgdbSingleStepWarp(dev, debuggerMessage.vsm, debuggerMessage.wp, debuggerMessage.data.nsteps, checkCtxSyncOnStep, &warpMask);
        if (devRes != CUDBG_SUCCESS && devRes != CUDBG_ERROR_WARP_RESUME_NOT_POSSIBLE)
            break;

        /* If handlePreemptPostHook returns an error, that should be returned from the function. If not,
           the return value from SingleStepWarp should be returned. This allows the debugger to return
           an error correctly on all platforms
        */
        devRes2 = handlePreemptPostHook(dev, debuggerMessage.vsm, 1, false, false);
        if (devRes2 != CUDBG_SUCCESS) {
            CUDBG_DISPATCHER_TRACE_FUNCTION(0, "Preempt post-hook failed (res=%d)\n", devRes2);
            devRes = devRes2;
            break;
        }

        break;

    case TGDB_DBGMSG_TERMINATE:
        if (haloGlobals.state->attachState != HALO_ATTACH_STATE_DETACHING && dev->suspended) {
            /* Don't touch the device on a detach, or if the device isn't already suspended */
            for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
                /* Ensure we disable single-step mode if we haven't already */
                devRes = dev->halo.singleStep(dev, vsm, false);
                if (devRes != CUDBG_SUCCESS)
                    break;
            }
        }
        *terminate = true;
        devRes = CUDBG_SUCCESS;
        break;

    case TGDB_DBGMSG_ACK:
        if (*pendingAckToApplication) {
            if ((devRes = ackApplication()))
                break;
            *pendingAckToApplication = false;
        }
        break;

    default:
        CUDBG_DISPATCHER_TRACE_FUNCTION(0, "Unexpected debugger message kind (kind=%u)\n", debuggerMessage.kind);
        devRes = CUDBG_ERROR_UNKNOWN;
        break;
    }

finish:
    memset(&reply, 0, sizeof(reply));
    reply.res = devRes;
    warpBitmaskAssign(&reply.warpMask, &warpMask);
    CUDBG_DISPATCHER_TRACE_FUNCTION(3, "ack debugger with result=%u\n", devRes);
    if ((res = cudbgPipeWrite(&dispatcherToDebugger, &reply, sizeof(reply))))
        return res;

    return CUDBG_SUCCESS;
}

static CUDBGResult
handleSignals(void)
{
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()
    sigset_t signalSet;

    /* Create an empty signal set */
    sigemptyset(&signalSet);

    /* Add SIGINT to the signal set */
    sigaddset(&signalSet, SIGINT);

    /* Block SIGINT from this thread (notificationDispatcher).
     * We want GDB to be the _only_ SIGINT recipient. */
    sigprocmask(SIG_BLOCK, &signalSet, NULL);
#endif

    return CUDBG_SUCCESS;
}

static CUDBGResult
handleDeviceEvent(CudbgDevice dev, Context triggerCtx, bool *notifyDebugger, uint32_t
                  *notifyHostThreadId, bool timeoutReceived, bool *sendTimeoutNotif)
{
    CUDBGResult res = CUDBG_SUCCESS;
    bool isKnownDeviceEvent = false;
    bool isAnyExceptionSet  = true;

    CUDBG_DISPATCHER_TRACE_FUNCTION(3, "for device %d\n", dev->deviceIdx);

    if (!dev->expectingGpuEvent || dev->finalizing) {
        if (!timeoutReceived) {
            if (triggerCtx && dev->activeContext && triggerCtx != dev->activeContext) {
                CUDBG_DISPATCHER_TRACE_FUNCTION(10, "Masking context event: 0x%" PRIx64 "\n", triggerCtx->cuCtx);
                triggerCtx->enableEvents = false;
            }
            else {
                res = dev->halo.clearEvent(dev, triggerCtx);
                if (res != CUDBG_SUCCESS) {
                    CUDBG_DISPATCHER_TRACE_FUNCTION(10, "Ignoring error (res=%d) to clear device"
                                                    " event; event consumed previously?\n", res);
                    return CUDBG_SUCCESS;
                }
            }
        }

        if (timeoutReceived) {
            if (deviceEventTimeoutsReceived < CUDBG_DEVICE_EVENT_TIMEOUT_THRESHOLD) {
                deviceEventTimeoutsReceived++;
            }
            else {
                /* A timeout was received, and the # of timeouts exceeded the
                   threshold. Resend a notification to the frontend with the
                   "timeout" flag set */
                *notifyDebugger = true;
                *sendTimeoutNotif = true;
                if (dev->activeContext)
                    *notifyHostThreadId = dev->activeContext->hostThreadId;

                CUDBG_DISPATCHER_TRACE_FUNCTION(3, "sending timeout notification to frontend.\n");
            }
        }

        CUDBG_DISPATCHER_TRACE_FUNCTION(3, "ignoring device event "
                                        "(dev->finalizing = %d)\n",
                                        dev->finalizing);
        return CUDBG_SUCCESS;
    }

    res = dev->halo.isAnyExceptionSet(dev, &isAnyExceptionSet);
    if (res != CUDBG_SUCCESS) {
        CUDBG_DISPATCHER_TRACE_FUNCTION(0, "could not determine if any exception is present!\n");
        return res;
    }

    /* XXX T124_HACK: Remove once bug 1228599 is fixed.
       Since Android currently relies on timeouts, and since the Android GPU
       driver does not disable SM exceptions after the first one is observed,
       stub this check out to allow the debugger to detect device events
       after a timeout. */

    /* When the debugger suspends GR, a device event is generated
       which may take a long time to get to the debugger. The delay
       may be large enough that the debugger might have already resumed
       the GPU. In this scenario, when the device event arrives, the
       debugger will discard it as a spurious device event. Currently,
       the debugger suspends GR again before deciding whether the event
       is spurious. This will generate another device event, which might
       get delayed again, thus leading to an infinite loop.
       To prevent this, if the exception tree does not indicate a device
       event should have occurred, just clear the event and return
       before trying to suspend the device.
    */
    if (dev->dmal->type != HALO_DMAL_TYPE_MRM && !timeoutReceived && !isAnyExceptionSet) {
        CUDBG_DISPATCHER_TRACE_FUNCTION(3, "no exception is set, returning early!\n");
        res = dev->halo.clearEvent(dev, NULL);
        return CUDBG_SUCCESS;
    }

    /* For multiple debuggers:  Since we are not subscribing to per-ctx events,
       we must ignore events when we are in a fully preempted state (we cannot
       issue a suspend of either ctxsw or the SMs if the device is undergoing
       activity for another process).  The 'proper' solution here is to switch
       to per-ctx notifiers.  */
    if (dev->preemptState != CUDBG_PREEMPTION_STATE_NOT_PREEMPTED) {
        CUDBG_DISPATCHER_TRACE_FUNCTION(1, "PREEMPTED state detected.  Ignoring device event.\n");
        res = dev->halo.clearEvent(dev, NULL);
        return CUDBG_SUCCESS;
    }

    /* If we get here, and there was no timeout, we have a real device
       event that needs to be evaluated.  Clear associated event data.
       Do this prior to suspending, as that will handle any new events
       that are a direct result of the suspend action. */
    if (!timeoutReceived) {
        res = dev->halo.clearEvent(dev, triggerCtx);
        if (res != CUDBG_SUCCESS)
            return res;
        /* Make sure to focus all efforts on the context that triggered the
           event we cleared -- that is the active context we're working with */
        if (triggerCtx)
            dev->activeContext = triggerCtx;
    }

    res = tgdbSuspendGpu(dev);
    if (res != CUDBG_SUCCESS && res != CUDBG_ERROR_SUSPENDED_DEVICE) {
        CUDBG_DISPATCHER_TRACE_FUNCTION(0, "failed to suspend the device!\n");
        return res;
    }
    removeBreakpoints(dev);

    /* Bug 779607 WAR - See cudbgtarget.c for details. */
    res = tgdbIsKnownDeviceEvent(dev, &isKnownDeviceEvent);
    if (res != CUDBG_SUCCESS)
        CUDBG_DISPATCHER_TRACE_FUNCTION(0, "Call to tgdbIsKnownDeviceEvent failed.\n");

    if (!isKnownDeviceEvent) {
        CUDBG_DISPATCHER_TRACE(0, "Bug 779607 WAR kicked in for device %u.\n",
                               dev->deviceIdx);
        insertBreakpoints(dev, false);
        res = tgdbResumeGpu(dev, false);
        if (res != CUDBG_SUCCESS) {
            CUDBG_DISPATCHER_TRACE(0, "Failed to resume the GPU.\n");
            return res;
        }

        return res;
    }

    /* KILP / Experimental

       If we've hit a known device event, we need to evict what's currently running
       then resume the device and context-switching so that graphics can come on GR. */
    res = handlePreemptPostHook(dev, 0, 1, true, true);
    if (res != CUDBG_SUCCESS) {
        CUDBG_DISPATCHER_TRACE_FUNCTION(0, "Preempt post-hook failed (res=%d)\n", res);
        return res;
    }

    if (!*notifyDebugger) {
        *notifyDebugger = true;

        /* If the device did not trap before reporting an exception, then we
           cannot retrieve an activeContext (we never had a chance to save
           it off).  Basically, we should not assume it can always be accessed.

           One case in particular is:

           PHYSICAL_STACK_OVERFLOW_ERROR  This can silently cause warps to terminate
                                          on GF100 due to a HW bug (no more tokens
                                          can be pushed in the trap handler). */
        if (dev->activeContext)
            *notifyHostThreadId = dev->activeContext->hostThreadId;
        else
            CUDBG_DISPATCHER_TRACE_FUNCTION(0, "No active context set! (Possibly "
                                            "due to an imprecise exception)\n");
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
contextHasAnyException(Context ctx, void *data)
{
    uint32_t *devEventMask = (uint32_t*)data;
    Context tmpCtx = ctx->dev->activeContext;
    CudbgDevice dev = ctx->dev;
    CudbgSMState_t state = {0};
    uint32_t vsm = 0;

    /* Already have an exception on this device, no need to check for another */
    if (*devEventMask & (1 << dev->deviceIdx))
        return CUDBG_SUCCESS;
    /* This context is not active */
    if (!haloStateContextIsActive(ctx))
        return CUDBG_SUCCESS;

    /* Make this context the "active context" temporarily and read the sm state */
    dev->activeContext = ctx;

    for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
        (void)dev->halo.readSMState(dev, vsm, &state);
        if (warpBitmaskAny(&state.bpmask)) {
            *devEventMask |= 1U << dev->deviceIdx;
            CUDBG_DISPATCHER_TRACE_FUNCTION(3, "found breakpoint on dev %d ctx 0x%" PRIx64 "vsm %d: "
                                            "bpmask=" CU_WARP_BIT_MASK_FMT_128_STR "\n",
                                            dev->deviceIdx, ctx->cuCtx, vsm,
                                            CU_WARP_BIT_MASK_FMT_128_VAL(&state.bpmask));
        }
    }

    /* Restore the previous active context (if there was an exception, we'll
       collect it later when we suspend) */
    dev->activeContext = tmpCtx;

    return CUDBG_SUCCESS;
}

/* Timeout event is not to be fully trusted. Let's see if an event
   (breakpoint) has actually happened already. This can happen due to
   bug 579237. */
static CUDBGResult
handleTimeoutEvent(uint32_t deviceMask, uint32_t *deviceEventMask, bool *notifyDebugger, uint32_t *notifyHostThreadId)
{
    uint32_t devId;
    CudbgDevice dev;
    uint32_t devEventMask = 0x00000000;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_DISPATCHER_TRACE_FUNCTION(3, "\n");

    /* Look through every context and build a list of devices that have a pending
       exception waiting to be dealt with.  This could happen if an event is
       lost, clobbered, or never sent and is effectively a safety net for the backend. */
    res = haloStateTraverseContexts(contextHasAnyException, &devEventMask);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to check for a context with an exception! res=%d\n", res);

    *deviceEventMask = devEventMask;

    /* If we have a real timeout event, with no latent event, send a heartbeat
       to the debugger. Sometimes the notification signal is lost and must be
       resent (Bug 685268). */
    if (!devEventMask) {
        if ((res = gpudbgProcessTimeoutEvent()))
            return res;
        if (!*notifyDebugger) {
            *notifyDebugger = true;
            /* Any host thread id from any active context will do */
            for (devId = 0; devId < CUDBG_MAX_DEVICES; ++devId) {
                dev = haloGlobals.device[devId];
                if (deviceMask >> devId & 1 &&
                    dev &&
                    !dev->isDebuggable &&
                    dev->activeContext) {
                    *notifyHostThreadId = dev->activeContext->hostThreadId;
                    break;
                }
            }
        }
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
handleApplicationEvent(bool *notifyDebugger, uint32_t *notifyHostThreadId, bool *pendingAckToApplication)
{
    CUDBGResult res;
    bool requiresDebuggerAck = false, retry = false;

    CUDBG_DISPATCHER_TRACE_FUNCTION(2, "\n");

    /* read the message  */
    if ((res = cudbgPipeMessageRead(&applicationToDispatcher, &retry)))
        return res;

    /* if retry was set, we must return (maintaining all
       state in the applicationToDispatcher pipe).  We'll
       come back to finish later. */
    if (retry) {
        CUDBG_DISPATCHER_TRACE_FUNCTION(1, "cudbgPipeMessageRead needs to retry\n");
        return CUDBG_SUCCESS;
    }

    /* reset the number of bytes read */
    applicationToDispatcher.bytesRead = 0;

    /* when the application closes the pipe, it shows up as an empty message. Do nothing. */
    if (applicationToDispatcher.messageSize[0] == 0)
        return CUDBG_SUCCESS;

    /* process the message */
    if ((res = gpudbgProcessApplicationMessage(applicationToDispatcher.message[0] +
                                               applicationToDispatcher.messagePreambleSize,
                                               &requiresDebuggerAck, notifyHostThreadId)))
        return res;

    /* ack the application right away, unless the debugger is in charge of it */
    if (!requiresDebuggerAck) {
        if ((res = ackApplication()))
            return res;
    }
    else {
        *notifyDebugger = true;
        *pendingAckToApplication = true;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
handleExceptionEvent(CUDBGDispatcherEvent *event,
                     bool *monitorApplication,
                     bool *monitorDebugger)
{
    CUDBG_DISPATCHER_TRACE_FUNCTION(1, "\n");

    /* Once this happens, no use listening to the app anymore */
    if (event->applicationException)
        *monitorApplication = false;

    // XXX notify the debugger

    return CUDBG_SUCCESS;
}
