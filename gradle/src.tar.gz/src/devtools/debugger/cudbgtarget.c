/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/*
 * Description:
 *
 *  This module defines the API between the debugger and the CUDA
 *  driver.
 */

/*--------------------------------- Includes --------------------------------*/

#include "cudadebugger.h"
#include "cudbgtarget.h"
#include "cudbgutils.h"
#include "cudbgpipe.h"
#include "cudbgapi.h"
#include "cudbgdispatcher.h"
#include "halo_state.h"

#include <cuos.h>
#include <cuda.h>
#include <cuda_private.h>
#include "nvRmApi.h"
#include "Nvcm.h"

#include <sys/types.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#ifdef __linux__
#include <poll.h>
#endif

#include <nvVer.h>

#include "../../syscalls/debugger/kilp_structs.h"

#define CUDA_DEVTOOLS_ENABLE_STATS
#include "halo_timing.h"

/*----------------------------------- Types ---------------------------------*/

static CUDBGResult doStepResume(CudbgDevice dev, uint32_t vsm, uint32_t tid,
                                CUwarpBitmask *steppedWarpMask,
                                CUwarpBitmask *rewindMasks);
static CUDBGResult handleTimeoutDeviceEvent(uint32_t devId, uint32_t sstepSM, bool sstep);
static CUDBGResult singleStepSM(CudbgDevice dev, uint32_t vsm, CUwarpBitmask *warpMask, uint32_t nsteps,
                                bool *hitUnsteppable,
                                uint32_t *ran, bool stepOverBreakpoint,
                                CUwarpBitmask *steppedWarpMask, CUwarpBitmask *newBrokenWarpMask, CUwarpBitmask *rewindMasks);
static CUDBGResult clearGpu(CudbgDevice dev);

extern unsigned int deviceEventTimeoutsReceived;

static CUDBGResult
initRewindMasks(CudbgDevice dev, CUwarpBitmask **ret)
{
    uint32_t vsm;
    CUwarpBitmask *rewindMasks;

    CUDBG_VERIFY(ret, CUDBG_ERROR_INTERNAL, "null return parameter in initRewindMasks\n");

    /* For now, this is a scratch space allocated for each iteration of each SM. */
    rewindMasks = (CUwarpBitmask *)calloc(dev->halo.deviceInfo.numSMs, sizeof(*rewindMasks));
    CUDBG_VERIFY(rewindMasks, CUDBG_ERROR_OS_RESOURCES, "Failed to allocate rewindMasks\n");

    /* We will need to rewind any warps that are not on the gpu before we
       sstep.  Further operations will refine this, adding in others that
       may need to be rewound. */
    for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
        if (dev->smState[vsm].valid)
            warpBitmaskNot(&rewindMasks[vsm], &dev->smState[vsm].state.tidValid);
        else
            warpBitmaskFill(&rewindMasks[vsm], 1);
        CUDBG_DEBUG("rewindMasks[vsm%d]=" CU_WARP_BIT_MASK_FMT_128_STR "\n",
                    vsm, CU_WARP_BIT_MASK_FMT_128_VAL(&rewindMasks[vsm]));
    }

    *ret = rewindMasks;

    return CUDBG_SUCCESS;
}

static CUDBGResult
invalidateSMState(CudbgDevice dev)
{
    uint32_t vsm;
    CUDBGResult res;

    CUDBG_TRACE("Invalidating SM state\n");
    for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
        res = dev->halo.invalidateSMState(dev, vsm);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to invalidate vsm%d state\n", vsm);
            return res;
        }
    }
    return CUDBG_SUCCESS;
}

CUDBGResult
tgdbResetAllDevices(void)
{
    uint32_t devId;
    CudbgDevice dev;
    CUDBGResult res, saved_res = CUDBG_SUCCESS;
    bool skipMMUDebugModeDisable = false;
    bool skipResume = false;
    bool skipForceTerminate = false;

    if (!cuosOsIsWindows() && !cuosOsIsApple() &&
        (haloGlobals.state->attachState == HALO_ATTACH_STATE_DETACHING)) {
        char szEnv[CUOS_ENV_VAR_LENGTH];
        if (!cuosGetEnv("CUDA_DEVICE_WAITS_ON_EXCEPTION", szEnv, CUOS_ENV_VAR_LENGTH)
            && atoi(szEnv) == 1)
            skipMMUDebugModeDisable = true;
    }

    for (devId = 0; devId < globals.numDevices; ++devId) {
        skipResume = false;
        skipForceTerminate = false;

        dev = haloGlobals.device[devId];
        if (!dev)
            continue;

        /* Bug 886891:  At the time that we intend to finalize a device
           we must *not* service any more interrupts as it could cause
           the main thread driving the finalize, and the dispatcher
           thread, to go out of sync in the event that an unknown/spurious
           device event arrives as part of the final resume. */
        dev->finalizing = true;

        /* Backwards compatibility check:
           Client versions older than 4.1 suspend/resume all devices in
           the system, irrespective of whether they have valid contexts
           or not. 4.0 clients are safe because of the separate debugger
           process; when the process exits the RM resumes suspended devices.
           To be safe against leaving devices suspended with clients older
           than 4.0, check if the devices is suspended, and if so, resume it. */
        if (!deviceHasAnyContext(devId)) {
            if (dev->suspended) {
                saved_res = tgdbResumeGpu(dev, false);
                if (saved_res != CUDBG_SUCCESS) {
                    CUDBG_ERROR("Resuming device %u failed (saved_res=%u)\n", devId, saved_res);
                    goto force_continue;
                }
            }
            continue;
        }

        if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_CILP) {
            CUDBG_DEBUG("CILP device. Skipping forceTerminate on reset\n");
            /* Skip force termination on cilp (just reset the preempted channel) */
            skipForceTerminate = true;
            /* Skip resume if we're not detaching (cilp doesn't need to clear out of trap) */
            skipResume = haloGlobals.state->attachState != HALO_ATTACH_STATE_DETACHING;
        }

        CUDBG_DEBUG("Reset device %u attachState:%u skipMMUDebugModeDisable:%s skipResume:%s skipForceTerminate:%s\n",
                    devId,
                    haloGlobals.state->attachState,
                    skipMMUDebugModeDisable ? "true" : "false",
                    skipResume ? "true" : "false",
                    skipForceTerminate ? "true" : "false");

        /* Don't saved_reset the GPUs if we're detaching*/
        if (haloGlobals.state->attachState != HALO_ATTACH_STATE_DETACHING &&
            !skipForceTerminate ) {
            saved_res = dev->halo.forceTermination(dev);
            if (saved_res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Forcing termination of device %u failed (saved_res=%d)\n", devId, saved_res);
                goto force_continue;
            }
        }

        saved_res = clearGpu(dev);
        if (saved_res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Clearing device %u failed (saved_res=%u)\n", devId, saved_res);
            goto force_continue;
        }

        if (!skipMMUDebugModeDisable) {
            saved_res = dev->halo.disableMMUDebuggingModeForDevice(dev);
            if (saved_res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Disabling MMU debugging mode on device %u failed (saved_res=%u)\n", devId, saved_res);
                goto force_continue;
            }
        }

        saved_res = removeBreakpoints(dev);
        if (saved_res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Removing the breakpoints on device %u failed (saved_res=%u)\n", devId, saved_res);
            goto force_continue;
        }

force_continue:
        if (skipResume) {
            CUDBG_TRACE("Dev %u has skipResume set. Forcing dev->suspended to false\n", devId);
            dev->suspended = false;
        }

        if (dev->suspended) {
            res = tgdbResumeGpu(dev, false);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Resuming device %u failed (res=%u) (saved_res=%u)\n",
                            devId, res, saved_res);
                if (saved_res == CUDBG_SUCCESS)
                    saved_res = res;
            }
        }

        /* Unmap memory segments - we need to do this explicitly here as this
           function is tied to forcing termination (see above), which means that
           we need to have RM free up any memory that we've mapped before the
           next run.  This was the cause of Bug 645088, where reruns could crash
           on gf100, which has a decreased BAR1 size. */
        res = dev->haloClient->unmapMemory(dev);
        if (res != CUDBG_SUCCESS)
            CUDBG_TRACE("Unmapping memory failed (res=%u)\n", res);
    }

    if (saved_res != CUDBG_SUCCESS)
        return saved_res;

    return CUDBG_SUCCESS;
}

/* Bug 779607 WAR
   We do not know why we sometimes get device events when no trap or
   breakpoint or exception was hit. For now, just recognize those
   situations and hide them from the client. */
CUDBGResult
tgdbIsKnownDeviceEvent(CudbgDevice dev, bool *result)
{
    uint32_t vsm;

    CUDBG_VERIFY(result, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in tgdbIsKnownDeviceEvent.\n");

    for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm)
        if (dev->smState[vsm].state.knownEvent) {
            *result = true;
            return CUDBG_SUCCESS;
        }

    *result = false;
    return CUDBG_SUCCESS;
}

CUDBGResult
tgdbSuspendGpu(CudbgDevice dev)
{
    uint32_t hasStopped = 0;
    uint32_t pause_tries = 0;
    uint32_t numAdditionalEvents = 0;
    uint32_t zeroTimeout = 0; /* poll needs to return immediately */
    bool timeoutReceived = false;
    CUDBGResult res = CUDBG_SUCCESS, res2 = CUDBG_SUCCESS;
    int contexts = 0;
    uint32_t waitForEvent = 0;
    uint32_t timeout = 0;
#if !defined(RELEASE) && defined(CUDA_DEVTOOLS_ENABLE_STATS)
    haloTimer suspendTimer = {0};
#endif

    CUwarpBitmask* rewindMasks = NULL;
    Context residentContext = NULL;

    res = haloStateGetTimeoutMsec(dev, &timeout);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, CUDBG_ERROR_INTERNAL, "Internal error.\n");

    CUDBG_DEBUG("\n");

    if (dev->status)
        return dev->status;

    /* Begin WAR HW Bug 1242244:

       STOP_TRIGGER doesn't prevent warps from executing IDE.DIS
         - Causes starvation of STOP_TRIGGER (can't suspend the device asynchronously)
         - WAR: Write a controller flag to prevent the starvation.
         - SW Instance:  1244936 */
    if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_KILP) {
        uint32_t mode = 1; /* Set the flag */
        res = haloStateTraverseContexts((haloCtxIterFunc)(dev->halo.controllerIlpSuspend), &mode);
        if (res != CUDBG_SUCCESS)
            return res;
    }

    if (dev->suspended) {
        CUDBG_DEBUG("dev->suspended is already set, ignoring suspend.\n");
        return CUDBG_ERROR_SUSPENDED_DEVICE;
    }

    CUDBG_DEBUG("Freezing all SMs:\n");

    if (haloGlobals.state->attachState != HALO_ATTACH_STATE_IN_PROGRESS) {
        res = dev->halo.suspendDevice(dev, &hasStopped, &waitForEvent, &residentContext);
        /* Do the stop setup early to handle all the paths below that expect
           that dev->suspended is correctly set. Always ensure that suspended
           and expectingGpuEvent are consistent. */
        if (hasStopped && (res == CUDBG_SUCCESS ||
                           res == CUDBG_ERROR_INVALID_CONTEXT)) {
            dev->suspended = true;
            dev->expectingGpuEvent = false;
        }

        if (res == CUDBG_ERROR_INVALID_CONTEXT) {
            /* Bug 825163 - OGL interop exposed this - We chose not to
               suspend the device since the global context was not known
               to us. Clear out device state to avoid having debugger
               clients query incorrect information. */

            CUDBG_DEBUG("Context can't be frozen.  Skipping and clearing state.\n");

            return dev->halo.clearSMState(dev);
        }
        else if (res != CUDBG_SUCCESS)
            return res;

        if (waitForEvent) {
            if (residentContext) {
                res = tgdbWaitForContextEvent(residentContext, -1, false, false, &timeout, &timeoutReceived);
                /* Handle events from this context later -- it could have an exception while being suspended */
                if (dev->activeContext && dev->activeContext != residentContext)
                    residentContext->enableEvents = false;
            }
            else
                res = tgdbWaitForDeviceEvent(dev->deviceIdx, -1, false, true, &timeout, &timeoutReceived);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Waiting for suspend to finish. Call to tgdbWaitForDeviceEvent failed in tgdbSuspendDevice (res=%#x).\n", res);
            if (timeoutReceived)
                CUDBG_ERROR("Timeout waiting for device to suspend! Ignoring...\n");
        }

        /* GP10x CILP WAR http://nvbugs/1744064
           We need to continue to force full suspend until *ALL* warps have
           successfully paused.  Unfortunately, the resume allows MPC/CWD to
           continue to drop new warps that must also pause, hence this loop.
           The upper bound is the pathological case every 1 warp CTA lands
           during null unpause.*/
        HALO_TIMER_START(suspendTimer);
        do {
            res = dev->halo.cilpForceFullSuspend(dev, &hasStopped, &waitForEvent);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to do phase 2 suspend with CILP\n");
            CUDBG_TRACE("cilpForceFullSuspend res=%d hasStopped=%d waitForEvent=%d\n", res, (int)hasStopped, (int)waitForEvent);

            if (waitForEvent) {
                CUDBG_DEBUG("Waiting for phase 2 suspend to finish, retried %d times...\n", pause_tries);
                ++pause_tries;
                /* We want to wait on the active context here, as that could be
                   the triggering context and is not necessarily the resident
                   context at the time of suspend (usually is not, though could
                   be due to timeout or ctrl+c) */
                if (dev->activeContext)
                    res = tgdbWaitForContextEvent(dev->activeContext, -1, false, true, &timeout, &timeoutReceived);
                else
                    res = tgdbWaitForDeviceEvent(dev->deviceIdx, -1, false, true, &timeout, &timeoutReceived);
                CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Waiting for phase 2 suspend to finish. Call to tgdbWaitForDeviceEvent failed in tgdbSuspendDevice. (res=%#x)\n", res);
                if (timeoutReceived)
                    CUDBG_ERROR("Timeout waiting for device to fullSuspend! Ignoring...\n");

                /* If cilpForceFullSuspend returns waitForEvent = 1, then the context was resumed inside that function
                   and is expected to be automatically suspended (and to signal the event).
                   On WDDM, we must explicitly suspend a context if it wasn't stopped by calling debugObjectSuspendContext,
                   otherwise KMD will have its state flag as "running" and any debug object calls would fail. */
                if (dev->dmal->type == HALO_DMAL_TYPE_WDDM) {
                    bool wait;

                    CUDBG_DEBUG("WDDM - Force debugObjectSuspendContext\n");

                    res = dev->dmal->debugObjectSuspendContext(dev->activeContext, &wait);
                    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to suspend a context on CILP full suspend (WDDM). res=%d\n", res);
                    if (wait) {
                        res = tgdbWaitForContextEvent(dev->activeContext, -1, false, true, &timeout, &timeoutReceived);
                        if (res != CUDBG_SUCCESS || timeoutReceived) {
                            CUDBG_TRACE("Timed out waiting for context suspend on CILP full suspend (WDDM). res=%d timeoutReceived=%d\n", res, timeoutReceived);
                        }
                    } else  {
                        waitForEvent = false;
                    }
                }
            }
        } while(waitForEvent && pause_tries < dev->halo.deviceInfo.numSMs * dev->halo.deviceInfo.numWarpsPrSM);
        HALO_TIMER_STOP(suspendTimer);
        HALO_TIMER_PRINT(suspendTimer, 20, "tgdbSuspendGpu pause tries %d\n", pause_tries);

        CUDBG_VERIFY(pause_tries < dev->halo.deviceInfo.numSMs * dev->halo.deviceInfo.numWarpsPrSM, CUDBG_ERROR_INTERNAL,
                    "Too many retries to fully suspend the gpu.\n");

        CUDBG_DEBUG("  all frozen.\n");

        CUDBG_VERIFY(dev->suspended, CUDBG_ERROR_INTERNAL, "Device not suspended correctly.\n");

        rewindMasks = (CUwarpBitmask*)malloc(sizeof(*rewindMasks)*dev->halo.deviceInfo.numSMs);
        CUDBG_VERIFY(rewindMasks, CUDBG_ERROR_OS_RESOURCES, "Failsed to allocate rewindMasks\n");

        /* Rewind all warps on all sms */
        memset(rewindMasks, ~0, sizeof(*rewindMasks)*dev->halo.deviceInfo.numSMs);

        res = dev->halo.collectDeviceState(dev, false, rewindMasks);

        free(rewindMasks);

        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to collectDeviceState failed in tgdbSuspendGpu.\n");
            return res;
        }
    }
    else
        dev->suspended = true;

    /* End WAR HW Bug 1242244:

       STOP_TRIGGER doesn't prevent warps from executing IDE.DIS
         - Causes starvation of STOP_TRIGGER (can't suspend the device asynchronously)
         - WAR: Write a controller flag to prevent the starvation.
         - SW Instance:  1244936 */
    if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_KILP) {
        uint32_t mode = 0; /* Clear the flag */
        res = haloStateTraverseContexts((haloCtxIterFunc)(dev->halo.controllerIlpSuspend), &mode);
        if (res != CUDBG_SUCCESS)
            return res;
    }

    /* Consume any additional events that have piled up as a result of us
       suspending all of the SMs.  Do not clobber any return codes stored
       in res (so we use res2 here).  Limit this check to a maximum number
       of events (since RM prevents further interrupts from coming in on
       a per SM basis, bind this to the number of total SMs) to ensure we
       never get stuck here. */
    /* Only do this for devices with known contexts */

    res2 = haloStateNumContextsForDevice(dev, &contexts);
    if (res2 != CUDBG_SUCCESS) {
        CUDBG_TRACE("Failed to get num contexts for device. (res2=%d)\n", res2);
        contexts = 0;
    }

    if (dev->activeContext) {
        res2 = tgdbConsumeContextEvents(dev->activeContext);
        if (res2 != CUDBG_SUCCESS)
            CUDBG_TRACE("Failed to consume additional events for context, ignoring...\n");
    }

    dev->expectingGpuEvent = false;
    deviceEventTimeoutsReceived = 0;

    return res;
}

static CUDBGResult
clearGpu(CudbgDevice dev)
{
    uint32_t vsm;
    CUDBGResult res;
    CUwarpBitmask tmpMask = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;

    for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
        res = dev->halo.writeBreakpointMask(dev, vsm, &tmpMask);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to writeBreakpointMask failed in clearGpu.\n");
            return res;
        }
    }

    return CUDBG_SUCCESS;
}


/* Resume the SM to reach the breakpoint at the saved PC.
 *
 * In rare cases (ex: User hits ^C), a debugger event could occur
 * here.  Passing NULL as the third parameter to waitForDevice Event tells it
 * to postpone checking for such events.
 *
 * Do not report errors right away to leave the device in a consistent
 * state.
 */
static CUDBGResult
doStepResume(CudbgDevice dev, uint32_t vsm, uint32_t tid, CUwarpBitmask *steppedWarpMask, CUwarpBitmask *rewindMasks)
{
    uint64_t pc = dev->smState[vsm].warp[tid].pc;
    CUwarpBitmask tidValid;
    CUwarpBitmask resume_mask = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;
    uint64_t resume_pc = 0;
    uint64_t resumeDevVAddr = 0;
    CUDBGResult res;
    bool isSteppable = false;
    bool requiresExitStep = false;
    uint32_t zeroTimeout = 0;
    uint32_t timeout = 0;
    bool timeoutReceived = true;
    DebugPatch patch;
    Context ctx;
    bool isPatchBegin = false;
    CUwarpBitmask rewindMask = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;
    CUwarpBitmask invResumeMask = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;
    CUwarpBitmask newBpMask = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;
    bool inPatch = false;
    CudbgStepResumeType stepResumeType = CUDBG_STEP_RESUME_TYPE_SM;

    res = haloStateGetTimeoutMsec(dev, &timeout);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, CUDBG_ERROR_INTERNAL, "Internal error.\n");

    warpBitmaskAssign(&tidValid, &dev->smState[vsm].state.tidValid);

    CUDBG_DEBUG("dev=%u vsm=%u pc=0x%" PRIx64 "\n", dev, vsm, pc);
    CUDBG_VERIFY(rewindMasks, CUDBG_ERROR_INTERNAL, "NULL rewindMasks\n");

    ctx = dev->activeContext;
    CUDBG_VERIFY(dev->activeContext, CUDBG_ERROR_INVALID_CONTEXT, "No active context in doStepResume.\n");

    res = haloIsPatchEntry(pc, ctx, &patch, CUDBG_PATCH_ALL, &isPatchBegin);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to haloIsPatchEntry failed in doStepResume.\n");
        return res;
    }

    /* Find the PC where to insert the breakpoint instruction. */
    if (isPatchBegin && !patch->debug && patch->kind != CUDBG_PATCH_BAR_WAR) {
        /* Set all bits to 1 except tid (i.e. current warp id) */
        warpBitmaskFill(&resume_mask, 1);
        warpBitmaskSetBits(&resume_mask, tid, 1, 0);

        /* Memcheck patch */
        resume_pc = pc + patch->hopSize;
        res = dev->halo.adjustCodeAddress(resume_pc, &resume_pc, CUDBG_ADJ_CURRENT_ADDRESS);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to get adjusted instruction address for 0x" PRIx64 "\n", resume_pc);
            return res;
        }
    }
    else {
        res = haloInPatchRegion(pc, ctx, &patch,
                                CUDBG_PATCH_SYSCALL | CUDBG_PATCH_HW_WAR,
                                &inPatch, false);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to haloInPatchRegion failed in doStepResume.\n");
            return res;
        }

        CUDBG_DEBUG("inPatch = %d\n", inPatch);
        if (patch)
            CUDBG_DEBUG("patch->kind = 0x%x patch->debug = %d\n", patch->kind, patch->debug);

        /* Only unwind syscall entrypoints if we're NOT under internal/syscall debug mode.
           We want to fall back to the unsteppable detection in those cases. */
        if (inPatch && patch->kind == CUDBG_PATCH_SYSCALL && !patch->debug) {
            uint32_t depth;
            uint32_t anActiveLn;

            CUDBG_DEBUG("dev=%u vsm=%u pc=0x%x Found in syscall patch. Start:0x%x size:0x%x resumetype:%u \n", dev, vsm, pc, patch->gpuAddr, patch->size, patch->stepResumeType);
            /* Find an active lane */
            res = haloFindAnActiveLane(dev, vsm, tid, &anActiveLn);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Call to haloFindAnActiveLane failed in doStepResume.\n");
                return res;
            }

            /* Ensure we have a call depth */
            res = dev->halo.readSyscallCallDepth(dev, vsm, tid, anActiveLn, &depth);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Call to readCallDepth failed in doStepResume.\n");
                return res;
            }
            CUDBG_VERIFY(depth, CUDBG_ERROR_UNKNOWN,
                         "Invalid syscall depth in doStepResume\n");

            /* For syscalls use the entry address + 8 */
            res = dev->halo.findSyscallEntryPoint(dev, vsm, tid,
                                                  anActiveLn, &resume_pc);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Call to readSyscallCallDepth failed in doStepResume.\n");
                return res;
            }

            res = dev->halo.adjustCodeAddress(resume_pc, &resume_pc, CUDBG_ADJ_NEXT_ADDRESS);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Failed to get adjusted instruction address for 0x" PRIx64 "\n", resume_pc);
                return res;
            }

            /* Set all bits to 1 except tid (i.e. current warp id) */
            warpBitmaskFill(&resume_mask, 1);
            warpBitmaskSetBits(&resume_mask, tid, 1, 0);

            /* When attempting to step a syscall that performs a continuation, the only safe way to make
               forward progress is by setting a temporary breakpoint at the return of the call and then
               resuming the full device. The full device resume is needed as the continuation might
               depend on child work that has launched on other SMs or potentially needs multiple
               SMs to be simultaneously occupied.

               This handling will be invoked by tgdbSingleStepWarp/tgdbSingleStepWarpOverBreakpoint
               when the warp is detected to have landed inside the syscall.

               Currently, the frontend has a change to ensure that the entire device state is invalidated
               when the resume mask changes, so to be safe, the resume mask must be changed here
               to indicate that all warps on the SM are about to be resumed.

               TODO: Shortly, this will change to send out the scope of the resume mask, converting
                     it from a warp resume mask to a device resume mask, which will allow the
                     frontend to be more optimal when invalidating/recollecting state.
            */
            if (patch->stepResumeType == CUDBG_STEP_RESUME_TYPE_DEVICE)
                warpBitmaskClear(&resume_mask);

            stepResumeType = patch->stepResumeType;
        }
        else if (inPatch &&
                  HALO_PATCH_IS_HW_WAR(patch->kind)) {
            uint32_t anActiveLn;

            CUDBG_DEBUG("dev=%u vsm=%u pc=0x%x Found in patch(kind=%d).\n", dev,
                        vsm, pc, patch->kind);
            /* Find an active lane */
            res = haloFindAnActiveLane(dev, vsm, tid, &anActiveLn);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Call to haloFindAnActiveLane failed in doStepResume.\n");
                return res;
            }

            switch (patch->kind) {
                case CUDBG_PATCH_MEMBAR_WAR:
                    res = dev->halo.membarWAR_getPatchPC(dev, vsm, tid,
                                                         anActiveLn, &resume_pc,
                                                         patch);
                    CUDBG_VERIFY((res == CUDBG_SUCCESS), res, 
                                 "Call to membarWAR_getPatchPC failed in doStepResume.\n");
                    break;

                case CUDBG_PATCH_BAR_WAR:
                    res = dev->halo.barWAR_getPatchPC(dev, vsm, tid,
                                                      anActiveLn, &resume_pc);
                    CUDBG_VERIFY((res == CUDBG_SUCCESS), res, 
                                 "Call to barWAR_getPatchPC failed in doStepResume.\n");
                    break;

                case CUDBG_PATCH_LDC_WAR:
                    resume_pc = patch->entryAddr;
                    break;

                default:
                    CUDBG_ERROR("Unhandled patch kind(%d) in doStepResume",
                                patch->kind);
            }

            CUDBG_VERIFY(resume_pc, CUDBG_ERROR_UNKNOWN,
                         "Incorrect resume_pc\n");

            res = dev->halo.adjustCodeAddress(resume_pc, &resume_pc, CUDBG_ADJ_NEXT_ADDRESS);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Failed to get adjusted instruction address for 0x" PRIx64 "\n", resume_pc);
                return res;
            }

            if (patch->stepResumeType == CUDBG_STEP_RESUME_TYPE_WARP) {
                /* Set all bits to 1 except tid (i.e. current warp id) */
                warpBitmaskFill(&resume_mask, 1);
                warpBitmaskSetBits(&resume_mask, tid, 1, 0);
            }
            else {
                warpBitmaskClear(&resume_mask);
            }

            stepResumeType = patch->stepResumeType;
        }
        else {
            res = dev->halo.isSteppable(dev, vsm, tid, pc, inPatch,
                                        &resume_pc, &resume_mask,
                                        &isSteppable, &requiresExitStep);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR(" unable to determine if instruction @ 0x%08x is steppable\n", pc);
                return res;
            }

            CUDBG_VERIFY(!isSteppable, CUDBG_ERROR_UNKNOWN, "Instruction is steppable.\n");
        }
    }

    /* When computing the rewindMask, we should ensure that for currently active
       warps that we are not planning to step should not be rewound.

       It is also possible for the valid mask to have expanded as part of the
       step as new warps on the SM may have become valid (or may have launched, and
       hit the breakpoint we know currently about).

       Thus the two constraints here are :
        1. Any warp that was not going to be stepped before will not be rewound
        2. Any warp that may have appeared after the step will be rewound if it
           sits on a breakpoint

       We can express both these conditions in one mask as follows. We
       AND the current valid mask with the resume_mask to give us a mask of just the
       known warps that will not be rewound, and finally invert this to mark all
       other warps as valid candidates for a rewind.

       Since the rewind logic checks that a warp is not being single stepped and
       that it is in the trap mask, it is guaranteed that the new valid mask will
       be covered by the rewindMask.
       Found during investigation of bug 1023804
    */
    /* This is  rewindMask = ~(resume_mask & tidValid) */
    warpBitmaskAnd(&rewindMask, &resume_mask, &tidValid);
    warpBitmaskNot(&rewindMask, &rewindMask);

    /* This is  *steppedWarpMask = tidValid & ~resume_mask */
    warpBitmaskNot(&invResumeMask, &resume_mask);
    warpBitmaskAnd(steppedWarpMask, &tidValid, &invResumeMask);

    warpBitmaskAnd(&newBpMask, &tidValid, &resume_mask);

    /* Write the breakpoint mask */
    CUDBG_DEBUG("using the following breakpoint mask " CU_WARP_BIT_MASK_FMT_128_STR "\n",
                CU_WARP_BIT_MASK_FMT_128_VAL(&newBpMask));
    res = dev->halo.writeBreakpointMask(dev, vsm, &newBpMask);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to writeBreakpointMask failed in doStepResume.\n");
        return res;
    }

    /* Insert the breakpoint instruction and save the original instruction.
       If we ever come down this path, we are guaranteed that ctx->funcMemBaseVA
       is set and accurate, since state on the device is live.
     */
    resumeDevVAddr = resume_pc + ctx->funcMemBaseVA;
    CUDBG_DEBUG(" setting temporary breakpoint at PC 0x%08x VADDR:0x%" PRIx64 "\n", resume_pc, resumeDevVAddr);

    res = insertTemporaryBreakpoint(ctx, resumeDevVAddr, resume_pc, NULL);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to allocate temporary breakpoint\n");

    if (stepResumeType == CUDBG_STEP_RESUME_TYPE_DEVICE) {
        if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_KILP) {
            /* Communicate to KILP syscalls that CTAs are allowed to RUN */
            res = dev->halo.controllerIlpSetupMode(dev, KILP_CONTROLLER_CMD_RUN);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Failed to setup controller mode (res=%d)\n", res);
                return res;
            }
        }

        /* Resume the gpu to hit the breakpoint we're sure to hit */
        res = tgdbResumeGpu(dev, true);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to resumeGpu failed\n");
            return res;
        }
    }
    else if (stepResumeType == CUDBG_STEP_RESUME_TYPE_WARP ||
             stepResumeType == CUDBG_STEP_RESUME_TYPE_SM   ||
             stepResumeType == CUDBG_STEP_RESUME_TYPE_CTA) {
        /* Resume the SM to hit the breakpoint instruction. */
        res = dev->halo.invalidateSMState(dev, vsm);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to invalidateSMState failed\n");
            return res;
        }

        res = dev->halo.resumeSM(dev, vsm);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to resumeSM failed\n");
            return res;
        }
    }

    /* Wait for the breakpoint instruction to be reached. */
    res = tgdbWaitForContextEvent(dev->activeContext, -1, false, true, &timeout, &timeoutReceived);
    if (res != CUDBG_SUCCESS)
        CUDBG_TRACE("Call to tgdbWaitForDeviceEvent failed in doStepResume.\n");

    if (timeoutReceived)
        CUDBG_TRACE("Timeout waiting for the breakpoint to be hit!  Ignoring...\n");

    if (stepResumeType == CUDBG_STEP_RESUME_TYPE_DEVICE) {
        res = tgdbSuspendGpu(dev);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to suspendGpu failed\n");
            return res;
        }
    }
    else if (stepResumeType == CUDBG_STEP_RESUME_TYPE_WARP ||
             stepResumeType == CUDBG_STEP_RESUME_TYPE_CTA ||
             stepResumeType == CUDBG_STEP_RESUME_TYPE_SM) {
        /* Suspend the SM and update the cached data. */
        res = dev->halo.suspendSM(dev, vsm);
        if (res != CUDBG_SUCCESS)
            CUDBG_TRACE("Call to suspendSM failed in doStepResume.\n");

        /* Clear any extra events RM may generate in response to suspendSM */
        res = tgdbWaitForContextEvent(dev->activeContext, -1, false, true, &zeroTimeout, &timeoutReceived);
        if (res != CUDBG_SUCCESS)
            CUDBG_TRACE("Failed to wait for device event in doStepResume (res=%d)\n", res);

        /* Incrementally update rewindMasks[] for later use */
        warpBitmaskAssign(&rewindMasks[vsm], &rewindMask);

        CUDBG_DEBUG("vsm %d rewind mask " CU_WARP_BIT_MASK_FMT_128_STR "\n",
                    vsm, CU_WARP_BIT_MASK_FMT_128_VAL(&rewindMasks[vsm]));
    }

    /* Remove the breakpoint instruction and restore the original instruction. */

    CUDBG_TRACE("unsetting temporary breakpoints\n");
    res = unsetTemporaryBreakpoints(dev);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Call to unsetTemporaryBreakpoints failed.\n");

    return CUDBG_SUCCESS;
}

CUDBGResult
tgdbSingleStepOverBreakpoint(CudbgDevice dev)
{
    uint32_t vsm, tid;
    uint64_t pc, breakAddr;
    CUwarpBitmask unused2;
    bool hitUnsteppable = false, isSteppable, requiresExitStep;
    uint32_t ran1 = 0;
    uint32_t ranAny = 0;
    CUDBGResult res;
    bool inPatch = false;
    DebugPatch patch = 0;
    CUwarpBitmask steppedWarpMask;
    CUwarpBitmask stepBpMask;
    CUwarpBitmask *rewindMasks = NULL;
#if !defined(RELEASE) && defined(CUDA_DEVTOOLS_ENABLE_STATS)
    haloTimer stepTimer = {0};
    uint32_t singleStepCount = 0;
    uint32_t hitUnsteppableCount = 0;
    uint32_t isSteppableCheckCount = 0;
#endif

    HALO_TIMER_START(stepTimer);

    CUDBG_DEBUG("\n");

    CUDBG_VERIFY(dev->suspended, CUDBG_ERROR_RUNNING_DEVICE, "Device is still running.\n");

    warpBitmaskClear(&steppedWarpMask);
    warpBitmaskClear(&stepBpMask);

    /* For now, this is a scratch space allocated for each iteration of each SM. */
    res = initRewindMasks(dev, &rewindMasks);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "initRewindMasks failed\n");

    for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
        CUwarpBitmask bpmask;

        warpBitmaskClear(&bpmask);

        res = dev->halo.getStepOverBPMask(dev, vsm, &bpmask);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to getStepOverBPMask failed in tgdbSingleStepOverBreakpoint.\n");
            goto done;
        }

        /* Single step the rest of the warps */
        res = singleStepSM(dev, vsm, &bpmask, 1, &hitUnsteppable, &ran1, true, &steppedWarpMask, &stepBpMask, rewindMasks);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to singleStepSM failed in tgdbSingleStepOverBreakpoint.\n");
            goto done;
        }

#if !defined(RELEASE) && defined(CUDA_DEVTOOLS_ENABLE_STATS)
        singleStepCount++;
#endif

        if (ran1) {
            /* Ran an sm, make sure to do a full collect later */
            ranAny = 1;

            /* bpMask is returned from singleStepSM and is from the mask written down
               before the SM was stepped. This ensures that bits in brokenWarps get
               cleared */
            warpBitmaskAnd(&dev->smState[vsm].state.brokenwarps,
                           &dev->smState[vsm].state.brokenwarps,
                           &stepBpMask);
        }

        if (hitUnsteppable) {
#if !defined(RELEASE) && defined(CUDA_DEVTOOLS_ENABLE_STATS)
            hitUnsteppableCount++;
#endif

            CUDBG_DEBUG("hit an unsteppable instruction.\n");

            /* Find any tid on an unsteppable instruction */
            for (tid = 0; tid < dev->halo.deviceInfo.numWarpsPrSM; ++tid) {
                /* Skip invalid warps */
                if (!warpBitmaskGetBits(&dev->smState[vsm].state.tidValid, tid, 1))
                    continue;

                pc = dev->smState[vsm].warp[tid].pc;

                /* This can be called without an active context */
                if (dev->activeContext) {
                    res = haloInPatchRegion(pc, dev->activeContext,
                                            &patch, CUDBG_PATCH_ALL, &inPatch,
                                            false);
                    if (res != CUDBG_SUCCESS) {
                        CUDBG_ERROR("Call to haloInPatchRegion failed in tgdbSingleStepOverBreakpoint.\n");
                        goto done;
                    }
                }
                res = dev->halo.isSteppable(dev, vsm, tid, pc, inPatch,
                                            &breakAddr, &unused2,
                                            &isSteppable, &requiresExitStep);
                if (res != CUDBG_SUCCESS) {
                    CUDBG_ERROR(" unable to determine if instruction @ 0x%08x is steppable\n", pc);
                    goto done;
                }
#if !defined(RELEASE) && defined(CUDA_DEVTOOLS_ENABLE_STATS)
                isSteppableCheckCount++;
#endif

                if (!isSteppable) {
                    res = doStepResume(dev, vsm, tid, &steppedWarpMask, rewindMasks);
                    if (res != CUDBG_SUCCESS) {
                        CUDBG_ERROR("Call to doStepResume failed in tgdbSingleStepOverBreakpoint.\n");
                        goto done;
                    }
                    ranAny = 1;
                    goto next_sm;
                }
            }

            /* Not expected to reach this point */
            res = CUDBG_ERROR_UNKNOWN;
            goto done;
        }

next_sm:
        ;
    }

    /* Only collect data if we stepped any SMs in order to read any new exception state and rewind if necessary */
    if (ranAny) {
        /* [CILP] Invalidate all the SMs before collect, as work can show up at
           any time while sstepping */
        if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_CILP) {
            res = invalidateSMState(dev);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Failed to invalidate sm states\n");
                goto done;
            }
        }

        res = dev->halo.collectDeviceState(dev, true, rewindMasks);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to collectDeviceState after tgdbSingleStepOverBreakpoint\n");
            goto done;
        }

        /* Now, check if any of the SMs we stepped hit an exception and tell the caller. */
        for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
            if (dev->smState[vsm].state.foundException) {
                CUDBG_TRACE("Exception on vsm=%u.  Skipping resume and notifying debugger\n", vsm);
                res = CUDBG_ERROR_WARP_RESUME_NOT_POSSIBLE;
                goto done;
            }
        }
    }

    res = CUDBG_SUCCESS;

    HALO_TIMER_STOP(stepTimer);
    HALO_TIMER_PRINT(stepTimer, 10, "tgdbSingleStepOverBreakpoint singleStepCount %d hitUnsteppableCount %d isSteppableCheckCount %u ranAny %d\n",
                     singleStepCount, hitUnsteppable, isSteppableCheckCount, ranAny);

done:
    clearTemporaryBreakpoints(dev);

    free(rewindMasks);

    return res;
}

typedef struct ContextEventFunctor_t {
    CudbgDevice dev;
    bool hasMasked;
} ContextEventFunctor;

static CUDBGResult
enableAllContextEvents(Context ctx, void *userData)
{
    ContextEventFunctor *contextEventFunctor = (ContextEventFunctor *)userData;
    CudbgDevice dev = contextEventFunctor->dev;
    if (ctx->dev != dev)
        return CUDBG_SUCCESS;

    if (!ctx->enableEvents) {
        HALO_TRACE_FUNCTION(30, "Found a masked context, unmasking! ctx=0x%" PRIx64 "\n", ctx->cuCtx);
        ctx->enableEvents = true;
        contextEventFunctor->hasMasked = true;
    }

    return CUDBG_SUCCESS;
}

CUDBGResult
tgdbResumeGpu(CudbgDevice dev, bool singleStepping)
{
    uint32_t vsm;
    uint32_t hasResumed = 0;
    CUDBGResult res;
    ContextEventFunctor contextEventFunctor = {0};
#if !defined(RELEASE) && defined(CUDA_DEVTOOLS_ENABLE_STATS)
    haloTimer resumeTimer = {0};
#endif

    HALO_TIMER_START(resumeTimer);

    CUDBG_DEBUG("\n");

    if (dev->status)
        return dev->status;

    /* If the device hasn't been suspended, return an error.
       However, in the case of single-gpu debugging (preemption-style), we may
       have preempted work on the GPU and have already resumed the device to do so.
       We need to allow this function to perform a low-level resume in those cases. */
    if (!dev->suspended &&
        (dev->preemptState != CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_CTA_PREEMPTED_BY_CONTROLLER    &&
         dev->preemptState != CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_ILP_PREEMPTED_BY_CONTROLLER    &&
         dev->preemptState != CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_PREEMPTED_FOR_DEVICE_EVENT     &&
         dev->preemptState != CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_CTA_PREEMPTED)) {
        CUDBG_DEBUG("- is already resumed!\n");
        return CUDBG_ERROR_RUNNING_DEVICE;
    }

    res = clearGpu(dev);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to clearGpu failed in tgdbResumeGpu.\n");
        return res;
    }

    CUDBG_DEBUG("Resuming all SMs\n");

    if (haloGlobals.state->attachState == HALO_ATTACH_STATE_DETACHING)
        dev->halo.invalidateICache(dev);

    /* If we aren't single-stepping the active context, we're resuming the
       entire device, so re-enable all masked off contexts so they are available
       to waitForEvent from the dispatcher. */
    if (!singleStepping) {
        contextEventFunctor.dev = dev;
        res = haloStateTraverseContexts(enableAllContextEvents, &contextEventFunctor);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to re-enable all events on contexts\n");
            return res;
        }
    }

    /* Do not try to suspend/resume the GPUs while attaching, since we won't
       have complete CUDA state before attach finishes. While detaching,
       suspend/resume calls are short-circuited at the API level to avoid
       incorrect interactions with the driver's trap service routines. */
    if (haloGlobals.state->attachState != HALO_ATTACH_STATE_IN_PROGRESS) {
        res = dev->halo.resumeDevice(dev, &hasResumed, contextEventFunctor.hasMasked && !singleStepping);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to resumeDevice failed in tgdbResumeGpu.\n");
            return res;
        }

        /* Ensure that suspended and expectingGpuEvent are in a consistent
           state */
        if (hasResumed) {
            dev->suspended = false;
            dev->expectingGpuEvent = true;
        }
    }
    else
        dev->suspended = false;

    /* Invalidate all SM states.
       However, do not do this if we have preempted for a device event. */
    if (dev->preemptState != CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_PREEMPTED_FOR_DEVICE_EVENT) {
        for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
            res = dev->halo.invalidateSMState(dev, vsm);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Failed to invalidate SM state\n");
                return res;
            }
        }
    }

    CUDBG_VERIFY(!dev->suspended, CUDBG_ERROR_INTERNAL, "Device not resumed correctly.\n");

    HALO_TIMER_STOP(resumeTimer);
    HALO_TIMER_PRINT(resumeTimer, 10, "tgdbResumeGpu\n");

    CUDBG_DEBUG("  all resumed\n");
    dev->expectingGpuEvent = true;

    return CUDBG_SUCCESS;
}

CUDBGResult
tgdbResumeWarps(CudbgDevice dev, uint32_t vsm, CUwarpBitmask *warpMask, bool async)
{
    uint32_t hasResumed = 0;
    uint32_t hasStopped = 0;
    uint32_t waitForEvent = 0;
    uint32_t pause_tries = 0;
    bool timeoutReceived = false;
    uint32_t zeroTimeout = 0;
    uint32_t timeout = 0;

    CUDBGResult res;
    CUwarpBitmask *rewindMasks = NULL;
    Context residentContext = NULL;

    res = haloStateGetTimeoutMsec(dev, &timeout);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, CUDBG_ERROR_INTERNAL, "Internal error.\n");

    CUDBG_DEBUG("\n");

    if (dev->status)
        return dev->status;

    CUDBG_DEBUG("Resuming warps (mask=" CU_WARP_BIT_MASK_FMT_128_STR ") on SM %d\n",
                CU_WARP_BIT_MASK_FMT_128_VAL(warpMask), vsm);

    /* In general, on doing a full resume, work can show up on empty warp slots on the SM.
       So,  the rewindmask should actually be :
          rewindMask = warpMask | (~tidValid);
    */

    res = initRewindMasks(dev, &rewindMasks);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "initRewindMasks failed\n");

    warpBitmaskNot(&rewindMasks[vsm], &dev->smState[vsm].state.tidValid);
    warpBitmaskOr(&rewindMasks[vsm], &rewindMasks[vsm], warpMask);

    res = dev->halo.resumeWarps(dev, vsm, warpMask, &hasResumed);
    if (res != CUDBG_SUCCESS)
        goto done;

    if (!hasResumed) {
        CUDBG_ERROR("resumeWarps call did not fail, but it also did not resume!\n");
        res = CUDBG_ERROR_INTERNAL;
        goto done;
    }

    /* Invalidate SM state. */
    (void)dev->halo.invalidateSMState(dev, vsm);

    CUDBG_DEBUG("  Warps resumed\n");

    if (async) {
        CUDBG_TRACE("Using async resume. Skip blocking wait.\n");
        dev->suspended = false;
        dev->expectingGpuEvent = true;
        goto done;
    }

    /* Wait for a context event (restrict it to the targeted vsm, and indicate sstep is true) */
    res = tgdbWaitForContextEvent(dev->activeContext, vsm, true, true, &timeout, &timeoutReceived);
    if (res != CUDBG_SUCCESS)
        CUDBG_TRACE("Call to tgdbWaitForDeviceEvent failed in tgdbResumeWarps. Ignoring.\n");

    if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_CILP) {

        if (timeoutReceived) {
            /* Temporary breakpoint was not hit in time, we need to force a
               suspend on the device and wait for *that* event */
            CUDBG_TRACE("Timeout waiting for event, suspending to inspect state!\n");
            res = dev->halo.suspendDevice(dev, &hasStopped, &waitForEvent, &residentContext);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Failed to suspend on timeout!\n");
                goto done;
            }

            if (waitForEvent) {
                res = tgdbWaitForContextEvent(dev->activeContext, vsm, true, true, &timeout, &timeoutReceived);
                if (res != CUDBG_SUCCESS) {
                    CUDBG_TRACE("Failed to async suspend on timeout!\n");
                    goto done;
                }
                if (timeoutReceived) {
                    CUDBG_ERROR("CILP device isn't sending events that it stopped!\n");
                    res = CUDBG_ERROR_INTERNAL;
                    goto done;
                }
                hasStopped = 1;
            }
        }
        else {
            /* DeviceEvent recieved, CILP preempted, context is stopped */
            hasStopped = 1;
        }

        /* GP10x CILP WAR http://nvbugs/1744064
           We need to continue to force full suspend until *ALL* warps have
           successfully paused.  Unfortunately, the resume allows MPC/CWD to
           continue to drop new warps that must also pause, hence this loop.
           The upper bound is the pathological case every 1 warp CTA lands
           during null unpause.*/
        do {
            res = dev->halo.cilpForceFullSuspend(dev, &hasStopped, &waitForEvent);
            if (res != CUDBG_SUCCESS) {
                CUDBG_TRACE("Failed to do phase 2 suspend with CILP\n");
                goto done;
            }

            if (waitForEvent) {
                CUDBG_DEBUG("Waiting for phase 2 suspend to finish, retried %d times...\n", pause_tries);
                ++pause_tries;
                res = tgdbWaitForContextEvent(dev->activeContext, -1, false, true, &timeout, &timeoutReceived);
                if (res != CUDBG_SUCCESS || timeoutReceived)
                    CUDBG_TRACE("CILP Full suspend failed to finish in time. res=%d timeoutReceived=%d\n", res, timeoutReceived);

                /* If cilpForceFullSuspend returns waitForEvent = 1, then the context was resumed inside that function
                   and is expected to be automatically suspended (and to signal the event).
                   On WDDM, we must explicitly suspend a context if it wasn't stopped by calling debugObjectSuspendContext,
                   otherwise KMD will have its state flag as "running" and any debug object calls would fail. */
                if (dev->dmal->type == HALO_DMAL_TYPE_WDDM) {
                    bool wait;

                    res = dev->dmal->debugObjectSuspendContext(dev->activeContext, &wait);
                    if (res != CUDBG_SUCCESS) {
                        CUDBG_TRACE("Failed to suspend a context on CILP full suspend (WDDM). res=%d\n", res);
                        goto done;
                    }
                    if (wait) {
                        res = tgdbWaitForContextEvent(dev->activeContext, -1, false, true, &timeout, &timeoutReceived);
                        if (res != CUDBG_SUCCESS || timeoutReceived) {
                            CUDBG_TRACE("Timed out waiting for context suspend on CILP full suspend (WDDM). res=%d timeoutReceived=%d\n", res, timeoutReceived);
                        }
                    }
                }
            }
        } while(waitForEvent && pause_tries < dev->halo.deviceInfo.numSMs * dev->halo.deviceInfo.numWarpsPrSM);

        if(pause_tries >= dev->halo.deviceInfo.numSMs * dev->halo.deviceInfo.numWarpsPrSM) {
            CUDBG_ERROR("Too many retries to fully suspend the gpu.\n");
            res = CUDBG_ERROR_INTERNAL;
            goto done;
        }

    }
    else {
        /* Force the resumed SM to lockdown */
        res = dev->halo.suspendSM(dev, vsm);
        if (res != CUDBG_SUCCESS) {
            CUDBG_TRACE("Call to suspendSM failed in tgdbResumeWarps.\n");
            goto done;
        }
        res = tgdbWaitForContextEvent(dev->activeContext, -1, false, true, &zeroTimeout, &timeoutReceived);
        if (res != CUDBG_SUCCESS)
            CUDBG_TRACE("Failed to clean up events in tgdbResumeWarps\n");
    }

    CUDBG_TRACE("  got the event (timeoutReceived=%d)\n", (int)timeoutReceived);

    /* [CILP] Invalidate all the SMs before collect, as work can show up at
       any time while sstepping */
    if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_CILP) {
        res = invalidateSMState(dev);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to invalidate sm states\n");
            goto done;
        }
    }

    res = dev->halo.collectDeviceState(dev, false, rewindMasks);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to collectDeviceState failed in tgdbResumeWarps.\n");
        goto done;
    }

    res = CUDBG_SUCCESS;

done:
    free(rewindMasks);

    return res;
}

static CUDBGResult
singleStepSMInternal(CudbgDevice dev, uint32_t vsm, CUwarpBitmask *warpMask, uint32_t nsteps,
             bool *hitUnsteppable, uint32_t *ran, bool stepOverBreakpoint,
             CUwarpBitmask *steppedWarpMask, CUwarpBitmask *newBrokenWarpMask);

static CUDBGResult
singleStepSMWithStepOverExitWAR(CudbgDevice dev, uint32_t vsm, CUwarpBitmask *warpMask, uint32_t nsteps,
             bool *hitUnsteppable, uint32_t *ran, bool stepOverBreakpoint,
             CUwarpBitmask *steppedWarpMask, CUwarpBitmask *newBrokenWarpMask, CUwarpBitmask *rewindMasks)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t wp;
    bool isExiting = false;
    CUwarpBitmask exitMask, notExitMask, steppedMask, brokenMask, rewindExitMask;

    warpBitmaskClear(&exitMask);
    warpBitmaskClear(&steppedMask);
    warpBitmaskClear(&brokenMask);
    warpBitmaskClear(&rewindExitMask);

    /* Bug 1534812: This is for ensuring we hit breakpoints across exit
       instructions, as exit instructions can potentially cause a warp to step
       over the first instruction from a newly resident warp after the previous
       warp exitted.  To fix this the following steps are used:
       1) Build mask of all valid warps sitting on terminating instruction.
          - Also build mask of all possible warps that *may* need to be rewound
            afterwards. (~valid | exit)
       2) Step all ~exit warps normally (no breakpoints)
       3) Collect SM state to combine later and for error checking (no rewinding)
       4) insert breakpoints (skipping ones that replace exit instructions)
       5) Step all exit warps
       6) Collect SM state and rewind (exit | newly_allocated) warps
       7) remove all breakpoints (putting everything back the way it was)

       * Note: collectDeviceState called at least once after sstep and before returning
               to the caller. */

    /* Step 1 - Build exit mask (nsteps>1, ignore stepping exits) */
    if (nsteps < 2) {
        for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
            if (!warpBitmaskGetBits(warpMask, wp, 1))
                continue;
            res = dev->halo.isTerminalInstructionAtPC(dev->activeContext, dev->smState[vsm].warp[wp].pc, &isExiting);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Failed to read PC=%#" PRIx64 " for sm%d/wp%d\n", dev->smState[vsm].warp[wp].pc, vsm, wp);
                return res;
            }
            if (isExiting)
                warpBitmaskSetBits(&exitMask, wp, 1, 1);
        }
    }

    /* exit = isExit() & warp;  notExit = ~exit & warp; */
    warpBitmaskNot(&notExitMask, &exitMask);
    warpBitmaskAnd(&notExitMask, &notExitMask, warpMask);

    /* rewindExitMask = ~valid | exit; 
       This is to rewind any newly allocated warps should executing the exit
       cause new CTAs to be allocated and hit breakpoints */
    warpBitmaskNot(&rewindExitMask, &dev->smState[vsm].state.tidValid);
    warpBitmaskOr(&rewindExitMask, &rewindExitMask, &exitMask);

    CUDBG_TRACE("warpMask[vsm%d]          =" CU_WARP_BIT_MASK_FMT_128_STR "\n",
                vsm, CU_WARP_BIT_MASK_FMT_128_VAL(warpMask));
    CUDBG_TRACE("exitMask[vsm%d]          =" CU_WARP_BIT_MASK_FMT_128_STR "\n",
                vsm, CU_WARP_BIT_MASK_FMT_128_VAL(&exitMask));
    CUDBG_TRACE("notExitMask[vsm%d]       =" CU_WARP_BIT_MASK_FMT_128_STR "\n",
                vsm, CU_WARP_BIT_MASK_FMT_128_VAL(&notExitMask));
    CUDBG_TRACE("rewindExitMask[vsm%d]    =" CU_WARP_BIT_MASK_FMT_128_STR "\n",
                vsm, CU_WARP_BIT_MASK_FMT_128_VAL(&rewindExitMask));

    /* Step 2 - Step all warps not on exit normally */
    res = singleStepSMInternal(dev, vsm, &notExitMask, nsteps, hitUnsteppable, ran,
                        stepOverBreakpoint, &steppedMask, &brokenMask);
    if (res != CUDBG_SUCCESS) {
        /* This can fail for a number of valid reasons, don't add log output here */
        return res;
    }

    warpBitmaskAssign(steppedWarpMask, &steppedMask);
    warpBitmaskAssign(newBrokenWarpMask, &brokenMask);

    CUDBG_TRACE("steppedWarpMask[vsm%d]   =" CU_WARP_BIT_MASK_FMT_128_STR "\n",
                vsm, CU_WARP_BIT_MASK_FMT_128_VAL(steppedWarpMask));
    CUDBG_TRACE("newBrokenWarpMask[vsm%d] =" CU_WARP_BIT_MASK_FMT_128_STR "\n",
                vsm, CU_WARP_BIT_MASK_FMT_128_VAL(newBrokenWarpMask));

    /* Step 3 - collect state -- deferred */

    if (*hitUnsteppable) {
        CUDBG_DEBUG("Hit unsteppable instruction in hot path, skip stepping exit path\n");
        return CUDBG_SUCCESS;
    }

    /* Single-stepping an exit instruction has an interesting bug.  The warp
       slot becomes free and a new logical warp can take its place and execute
       an additional instruction.  Since breakpoints aren't inserted at this
       time, we'll execute the user instruction rather than the breakpoint and
       notice a breakpoint was hit. This condition handles this case. */

    if (warpBitmaskAny(&exitMask)) {
        CUDBG_DEBUG("Found warps at exit in sstepsm: exitMask=" CU_WARP_BIT_MASK_FMT_128_STR
                    " notExitMask=" CU_WARP_BIT_MASK_FMT_128_STR "\n",
                    CU_WARP_BIT_MASK_FMT_128_VAL(&exitMask),
                    CU_WARP_BIT_MASK_FMT_128_VAL(&notExitMask));

        /* Step 4 - insert bps with targets not at exit instructions */
        res = insertBreakpoints(dev, true);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to insert breakpoints before exit sstep!\n");
            return res;
        }
        res = dev->halo.invalidateICache(dev);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to flush icache before exit sstep!\n");
            return res;
        }

        /* Step 5 - Step all warps on exit */
        res = singleStepSMInternal(dev, vsm, &exitMask, nsteps, hitUnsteppable, ran,
                            stepOverBreakpoint, steppedWarpMask, newBrokenWarpMask);

        if (res != CUDBG_SUCCESS) {
            CUDBG_TRACE("Failed to sstep on exit step!\n");
            return res;
        }

        CUDBG_DEBUG("Exit SSTEP: steppedWarpMask=" CU_WARP_BIT_MASK_FMT_128_STR
                    " newBrokenWarpMask=" CU_WARP_BIT_MASK_FMT_128_STR "\n",
                    CU_WARP_BIT_MASK_FMT_128_VAL(steppedWarpMask),
                    CU_WARP_BIT_MASK_FMT_128_VAL(newBrokenWarpMask));

        /* Add in the exit stepped and broken masks for the second sstep */
        warpBitmaskOr(steppedWarpMask, steppedWarpMask, &steppedMask);
        warpBitmaskOr(newBrokenWarpMask, newBrokenWarpMask, &brokenMask);
        
        /* Step 6 - Update rewindMasks if we ran */
        if (*ran) {
            warpBitmaskAssign(&rewindMasks[vsm], &rewindExitMask);

            CUDBG_TRACE("rewindMasks[vsm%d]=" CU_WARP_BIT_MASK_FMT_128_STR "\n",
                        vsm, CU_WARP_BIT_MASK_FMT_128_VAL(&rewindMasks[vsm]));
        }

        /* Step 7 - remove bps, leaving everything the way it was before we got here. */
        res = removeBreakpoints(dev);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to remove breakpoints after exit sstep!\n");
            return res;
        }
        res = dev->halo.invalidateICache(dev);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to flush icache after exit sstep!\n");
            return res;
        }
    }

    return res;
}

static CUDBGResult
singleStepSM(CudbgDevice dev, uint32_t vsm, CUwarpBitmask *warpMask, uint32_t nsteps,
             bool *hitUnsteppable, uint32_t *ran, bool stepOverBreakpoint,
             CUwarpBitmask *steppedWarpMask, CUwarpBitmask *newBrokenWarpMask, CUwarpBitmask *rewindMasks)
{
    CUDBGResult res = CUDBG_SUCCESS;
    bool skipExitWAR = false;

    res = dev->halo.canSkipSingleStepOverExitWAR(&skipExitWAR);
    if (res != CUDBG_SUCCESS) {
        CUDBG_TRACE("canSkipSingleStepOverExitWAR call failed!\n");
        return res;
    }

    if (skipExitWAR) {
        /* Bug 1820001: In single step mode for Turing+ chips, the SM is
           guaranteed to trap even before the execution of the first
           instruction. This allows us to skip the special handling for the EXIT
           instruction as described below */
        res = singleStepSMInternal(dev, vsm, warpMask, nsteps, hitUnsteppable,
                                   ran, stepOverBreakpoint, steppedWarpMask,
                                   newBrokenWarpMask);
    }
    else {
        res = singleStepSMWithStepOverExitWAR(dev, vsm, warpMask, nsteps,
                                              hitUnsteppable, ran,
                                              stepOverBreakpoint,
                                              steppedWarpMask,
                                              newBrokenWarpMask, rewindMasks);
    }

    /* Note: No longer calls collectDeviceState, the caller will have to do so */

    return res;
}

static CUDBGResult
singleStepSMInternal(CudbgDevice dev, uint32_t vsm, CUwarpBitmask *warpMask, uint32_t nsteps,
             bool *hitUnsteppable, uint32_t *ran, bool stepOverBreakpoint,
             CUwarpBitmask *steppedWarpMask, CUwarpBitmask *newBrokenWarpMask)
{
    uint32_t timeout = 0;
    CUDBGResult res;
    CudbgSMState_t state;
    CUwarpBitmask validMask;
    CUwarpBitmask bpMask;
    uint32_t wp;
    uint64_t pc, breakAddr;
    CUwarpBitmask unused2;
    bool isSteppable = false;
    bool requiresExitStep = false;
    bool timeoutReceived;
    bool inPatch = false;
    DebugPatch patch;
    bool isContextActive;
    CUwarpBitmask validStepMask;
    CUwarpBitmask tmpMask;
    uint32_t nstepsold;
#if !defined(RELEASE) && defined(CUDA_DEVTOOLS_ENABLE_STATS)
    haloTimer stepTimer;
    uint32_t singleStepWarpCount = 0;
#endif

    HALO_TIMER_START(stepTimer);

    res = haloStateGetTimeoutMsec(dev, &timeout);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, CUDBG_ERROR_INTERNAL, "Internal error.\n");

    warpBitmaskAssign(&validMask, &dev->smState[vsm].state.tidValid);
    warpBitmaskClear(&bpMask);

    CUDBG_TRACE("dev %u vsm %u warpMask " CU_WARP_BIT_MASK_FMT_128_STR "\n", dev->deviceIdx, vsm,
                CU_WARP_BIT_MASK_FMT_128_VAL(warpMask));

    CUDBG_VERIFY(nsteps > 0, CUDBG_ERROR_INVALID_ARGS, "Argument 'nsteps' should be greater than 0.\n");

    CUDBG_VERIFY(dev->suspended, CUDBG_ERROR_RUNNING_DEVICE, "Device not suspended when single stepping.\n");

    /* Prevent single-stepping when we are not going to step anything.
       This can happen in the general case that there is no work on
       the SM (warpMask == 0), or when there are hidden warps due to
       a system call (see Bug 1291950). */
    warpBitmaskAnd(&validStepMask, warpMask, &validMask);
    if (!warpBitmaskAny(&validStepMask)) {
        CUDBG_TRACE("skipping vsm%d: no warps to single-step\n", vsm);
        *hitUnsteppable = false;
        *ran = false;
        goto exit;
    }

    for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
        /* Skip invalid warps */
        if (!warpBitmaskGetBits(&dev->smState[vsm].state.tidValid, wp, 1))
            continue;

        /* Skip warps that are not being single stepped */
        if (!warpBitmaskGetBits(warpMask, wp, 1))
            continue;

#if !defined(RELEASE) && defined(CUDA_DEVTOOLS_ENABLE_STATS)
        singleStepWarpCount++;
#endif

        pc = dev->smState[vsm].warp[wp].pc;
        if (dev->activeContext) {
            res = haloInPatchRegion(pc, dev->activeContext, &patch,
                                    CUDBG_PATCH_ALL, &inPatch, false);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Call to haloInPatchRegion failed in singleStepSM.\n");
                return res;
            }
        }
        res = dev->halo.isSteppable(dev, vsm, wp, pc, inPatch,
                                    &breakAddr, &unused2,
                                    &isSteppable, &requiresExitStep);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("unable to determine if instruction @ 0x%08x is steppable\n", pc);
            return res;
        }

        /* Check if we're at an exit, and more processing is required.
           This can only be done for a _single_ warp on the SM.  Issue
           the abstracted function to handle this, then indicate the
           step operation has completed. */
        if (warpBitmaskHasOneBitSet(warpMask) && requiresExitStep) {
            CUDBG_DEBUG("Single stepping an exit point\n");

            res = dev->halo.singleStepExit(dev, vsm, wp);
            if (res != CUDBG_SUCCESS)
                return res;

            *hitUnsteppable = false;
            warpBitmaskClear(steppedWarpMask);
            warpBitmaskSetBits(steppedWarpMask, wp, 1, 1);

            *ran = true;
            return CUDBG_SUCCESS;
        }

        /* Check for unsteppable instructions -- indicate we haven't stepped it */
        if (!isSteppable) {
            CUDBG_DEBUG("Single stepping %08x: unsteppable instruction\n",
                        dev->smState[vsm].warp[wp].pc);
            *hitUnsteppable = true;
            *ran = false;
            goto exit;
        }
    }

    CUDBG_DEBUG("Setting single-step mode for vsm%d \n", vsm);
    /* This is logically    bpMask = validMask & ~warpMask; */
    warpBitmaskNot(&bpMask, warpMask);
    warpBitmaskAnd(&bpMask, &validMask, &bpMask);

    /* This is logically *steppedWarpMask |= validMask & warpMask; */
    warpBitmaskAnd(&tmpMask, &validMask, warpMask);
    warpBitmaskOr(steppedWarpMask, steppedWarpMask, &tmpMask);

    *hitUnsteppable = false;
    *ran = 1;
    res = dev->halo.singleStep(dev, vsm, true);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to singleStep failed in singleStepSM.\n");
        return res;
    }

    CUDBG_VERIFY(dev->suspended, CUDBG_ERROR_RUNNING_DEVICE, "Device not suspended when single stepping.\n");

    res = clearGpu(dev);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to clearGpu failed in singleStepSM.\n");
        return res;
    }

    CUDBG_VERIFY(dev->suspended, CUDBG_ERROR_RUNNING_DEVICE, "Device not suspended when single stepping.\n");

    CUDBG_TRACE("Only single step warps in mask " CU_WARP_BIT_MASK_FMT_128_STR
                "  using bpMask " CU_WARP_BIT_MASK_FMT_128_STR "\n",
                CU_WARP_BIT_MASK_FMT_128_VAL(warpMask),
                CU_WARP_BIT_MASK_FMT_128_VAL(&bpMask));

    if (0 < CUDBG_TRACE_LEVEL) {
        res = dev->halo.readSMState(dev, vsm, &state);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to readSMState failed in singleStepSM.\n");
            return res;
        }

        CUDBG_TRACE("extra check: tidValid=" CU_WARP_BIT_MASK_FMT_128_STR
                    " warpMask=" CU_WARP_BIT_MASK_FMT_128_STR "\n",
                    CU_WARP_BIT_MASK_FMT_128_VAL(&state.tidValid),
                    CU_WARP_BIT_MASK_FMT_128_VAL(warpMask));

        warpBitmaskAnd(&tmpMask, &state.tidValid, warpMask);
        CUDBG_VERIFY(warpBitmaskEqual(&tmpMask, warpMask), CUDBG_ERROR_UNKNOWN, "Warp not valid.\n");
    }

    res = dev->halo.writeBreakpointMask(dev, vsm, &bpMask);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to writeBreakpointMask failed in singleStepSM.\n");
        return res;
    }

    if (10 < CUDBG_TRACE_LEVEL) {
        res = dev->halo.readSMState(dev, vsm, &state);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to readSMState failed in singleStepSM.\n");
            return res;
        }

        CUDBG_TRACE("new bpmask : tidValid=" CU_WARP_BIT_MASK_FMT_128_STR
                    " warpMask=" CU_WARP_BIT_MASK_FMT_128_STR
                    " bpMask=" CU_WARP_BIT_MASK_FMT_128_STR "\n",
                    CU_WARP_BIT_MASK_FMT_128_VAL(&state.tidValid),
                    CU_WARP_BIT_MASK_FMT_128_VAL(warpMask),
                    CU_WARP_BIT_MASK_FMT_128_VAL(&state.bpmask));
    }

    /* If nsteps is greater than 1, this call disables single-step complete
       and BPT.PAUSE interrupts. */
    res = dev->halo.setupSingleStepNsteps(dev, vsm, steppedWarpMask, nsteps, &nstepsold);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to setSingleStepNsteps failed in singleStepSM.\n");
        return res;
    }
    if (nstepsold != 0)
        CUDBG_TRACE("old nsteps value in scratchpad was not 0!\n");

    /* Set the SM state to invalid and resume it */
    res = dev->halo.invalidateSMState(dev, vsm);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to invalidateSMState failed.\n");
        return res;
    }

    res = dev->halo.resumeSM(dev, vsm);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to resumeSM failed in singleStepSM.\n");
        return res;
    }

    CUDBG_TRACE("resumed to activate single step\n");

    if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_CILP ||
        nsteps <= 1) {   /* Default mode - wait for device events */
        CUDBG_DEBUG("waiting for event (nsteps:%u)\n", nsteps);

        /* In rare cases (ex: User hits ^C), a debugger event could occur
         * here.  Passing NULL as the third parameter to tgdbWaitForContextEvent
         * tells it to postpone checking for such events. */
        res = tgdbWaitForContextEvent(dev->activeContext, vsm, true, true, &timeout, &timeoutReceived);
        if (res != CUDBG_SUCCESS || timeoutReceived)
            CUDBG_TRACE("Call to tgdbWaitForContextEvent failed in singleStepSM, ignoring... (res=%u, timeout=%u).\n",
                        res, timeoutReceived);

        CUDBG_DEBUG("got the event\n");
    }
    else {
        CUDBG_DEBUG("waiting for SM LOCKED_DOWN state (nsteps:%u)\n", nsteps);

        res = dev->halo.waitForSMPause(dev, vsm);
        if (res != CUDBG_SUCCESS)
            CUDBG_TRACE("Call to waitForSMPause failed in singleStepSM.\n");

        CUDBG_DEBUG("got SM LOCKED_DOWN\n");
    }

    res = dev->halo.suspendSM(dev, vsm);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to suspendSM failed in singleStepSM.\n");
        return res;
    }

    /* When single stepping over a breakpoint on Fermii/Kepler, clear the active
     * bit from the scratchpad. See bug 643431. */
    if (dev->activeContext && stepOverBreakpoint) {
        CUDBG_DEBUG("refreshing scratchpad\n");
        res = dev->halo.readAndResetContextActiveBit(dev->activeContext, dev, &isContextActive);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to readAndResetContextActiveBit failed in singleStepSM.\n");
            return res;
        }
    }

    /* Turn single-stepping off again */
    res = dev->halo.singleStep(dev, vsm, false);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to singleStep failed in singleStepSM.\n");
        return res;
    }

    /* If activeContext still exists reset singleStepNsteps value and
       re-enable interrupts. */
    if (dev->activeContext) {
        res = dev->halo.setupSingleStepNsteps(dev, vsm, steppedWarpMask, 0, &nstepsold);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to setSingleStepNsteps failed in singleStepSM.\n");
            return res;
        }

        CUDBG_DEBUG("stepped %u out of %u steps\n", nsteps - nstepsold, nsteps);
    }

    /* Update the broken warps mask to lower bits for any warps
       that we've just stepped.  This is actually only necessary
       for Tesla, but until we can carry the stepping mask out
       of this routine, the logic will need to stay here. */
    if (newBrokenWarpMask)
        warpBitmaskAssign(newBrokenWarpMask, &bpMask);

    HALO_TIMER_STOP(stepTimer);
    HALO_TIMER_PRINT(stepTimer, 10, "singleStepSMInternal vsm %u singleStepWarpCount %u\n",
                     vsm, singleStepWarpCount);

exit:
    CUDBG_TRACE("done -  ran=%u hitUnsteppable=%u\n", *ran, *hitUnsteppable);
    return CUDBG_SUCCESS;;
}

CUDBGResult
tgdbSingleStepWarp(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t nsteps, bool checkForHostResume, CUwarpBitmask *steppedWarpMask)
{
    bool hitUnsteppable = false;
    uint32_t ran = 0;
    CUDBGResult res = CUDBG_SUCCESS;
    Context ctx;
    uint64_t pc;
    DebugPatch patch = 0;
    bool isEntry = false;
    bool forceEarlyResume = false;
    bool forceLateResume = false;
    bool inPatch;
    bool anyLaneInContinuation = false;
    bool needsHostResume = false;
    CUwarpBitmask bpMask;
    CUwarpBitmask wpMask;
    CUwarpBitmask *rewindMasks = NULL;

    CUDBG_DEBUG("\n");

    if (dev->status != CUDBG_SUCCESS) {
        CUDBG_ERROR("Device error in tgdbSingleStepWarp.\n");
        return dev->status;
    }

    CUDBG_VERIFY(vsm < dev->halo.deviceInfo.numSMs, CUDBG_ERROR_INVALID_SM, "Invalid SM in tgdbSingleStepWarp.\n");

    CUDBG_VERIFY(wp < dev->halo.deviceInfo.numWarpsPrSM, CUDBG_ERROR_INVALID_WARP, "Invalid warp in tgdbSingleStepWarp.\n");

    CUDBG_VERIFY(dev->smState[vsm].warp[wp].valid, CUDBG_ERROR_INVALID_WARP, "Invalid warp in tgdbSingleStepWarp.\n");

    CUDBG_VERIFY(dev->suspended, CUDBG_ERROR_RUNNING_DEVICE, "Device is not suspended in tgdbSingleStepWarp.\n");

    CUDBG_VERIFY(dev->activeContext, CUDBG_ERROR_INVALID_CONTEXT, "No active context in tgdbSingleStepWarp.\n");

    warpBitmaskClear(&bpMask);
    warpBitmaskClear(&wpMask);
    warpBitmaskSetBits(&wpMask, wp, 1, 1);

    ctx = dev->activeContext;
    pc = dev->smState[vsm].warp[wp].pc;

    /* For 6.0+ clients, when running on SM 3.5+,
       an extra check is necessary. Due to EPLB, it
       is insufficient to try to resume the device
       without the host being resumed. As a result,
       Any attempt to step a warp, whose lanes might
       be in the cudaDeviceSynchronize() syscall will
       return CUDBG_ERROR_WARP_RESUME_NOT_POSSIBLE.
       The frontend will gracefully handle this error
       by using a breakpoint to resume instead.

       A second check is required to see if the warp is present inside
       a syscall that requires host resuming. Since the current
       debugger policy is to resume threads that wind up inside
       a syscall after the step, syscalls that require host interaction
       (such as GetParamBuffer and Launch under EPLB) will return
       the same error (CUDBG_ERROR_WARP_RESUME_NOT_POSSIBLE)
       and will require the frontend to handle this correctly.

       This behavior makes debugging the affected syscalls cumbersome,
       because using stepi inside a syscall would result in continue instead.
       To alleviate this, skip the check under internal debugging,
       even though this can potentially lead to deadlocks.
     */

    if (cudbgEnableInternalDebugging) {
        CUDBG_DEBUG("Skipping checkForHostResume because of internal debugging\n");
        checkForHostResume = false;
    }

    if (checkForHostResume) {
        res = dev->halo.checkAnyLaneInContinuation(dev, vsm, &wpMask, &anyLaneInContinuation);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Unable to check if any lane is in continuation\n");

        if (anyLaneInContinuation) {
            CUDBG_DEBUG(" SStep early check : Found a lane inside continuation. Returning WARP_RESUME_NOT_POSSIBLE\n");
            return CUDBG_ERROR_WARP_RESUME_NOT_POSSIBLE;
        }

        res = dev->halo.checkWarpNeedsHostResume(dev, vsm, wp, &needsHostResume);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Unable to check if warp needs host resume\n");

        if (needsHostResume) {
            CUDBG_DEBUG(" SStep early check : Found vsm:%u/wp%u at pc 0x%x inside host resume syscall. Returning WARP_RESUME_NOT_POSSIBLE\n", vsm, wp, pc);
            return CUDBG_ERROR_WARP_RESUME_NOT_POSSIBLE;
        }
    }

    res = haloIsPatchEntry(pc, ctx, &patch, CUDBG_PATCH_ALL, &isEntry);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to haloIsPatchEntry failed in tgdbSingleStepWarp.\n");
        return res;
    }

    res = initRewindMasks(dev, &rewindMasks);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "initRewindMasks failed\n");    

    CUDBG_DEBUG("forceEarlyResume = %d\n", forceEarlyResume);
    if (forceEarlyResume) {
        res = doStepResume(dev, vsm, wp, steppedWarpMask, rewindMasks);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to doStepResume failed in tgdbSingleStepWarp.\n");
            goto done;
        }
        ran = 1;
    }
    else {
        res = singleStepSM(dev, vsm, &wpMask, nsteps,
                           &hitUnsteppable, &ran, false, steppedWarpMask, &bpMask, rewindMasks);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to singleStepSM failed in tgdbSingleStepWarp.\n");
            goto done;
        }
    }

    if (!dev->suspended) {
        CUDBG_DEBUG("Device not suspended in tgdbSingleStepWarp.\n");
        res = CUDBG_ERROR_RUNNING_DEVICE;
        goto done;
    }

    if (ran) {
        /* [CILP] Invalidate all the SMs before collect, as work can show up at
           any time while sstepping */
        if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_CILP) {
            res = invalidateSMState(dev);
            if (res != CUDBG_SUCCESS) {
                CUDBG_ERROR("Failed to invalidate sm states\n");
                goto done;
            }
        }

        res = dev->halo.collectDeviceState(dev, !forceEarlyResume, rewindMasks);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to collectDeviceState failed.\n");
            goto done;
        }

        if (!dev->smState[vsm].valid) {
            CUDBG_DEBUG("SM is in an invalid state after single-stepping\n");
            res = CUDBG_ERROR_INTERNAL;
            goto done;
        }

        /* bpMask is returned from singleStepSM and is from the mask written down
           before the SM was stepped. This ensures that bits in brokenWarps get
           cleared */
        warpBitmaskAnd(&dev->smState[vsm].state.brokenwarps,
                       &dev->smState[vsm].state.brokenwarps,
                       &bpMask);

        /* Clear temporary breakpoints */
        res = clearTemporaryBreakpoints(dev);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Error clearing temporary breakpoints\n");
            goto done;
        }
    }
    else
        CUDBG_DEBUG(" Didn't run singleStepSM\n");

    pc = dev->smState[vsm].warp[wp].pc;
    ctx = dev->activeContext;
    if (!ctx) {
        CUDBG_DEBUG("Invalid context in tgdbSingleStepWarp.\n");
        res = CUDBG_ERROR_INVALID_CONTEXT;
        goto done;
    }

    /* For 6.0+ clients, when running on SM 3.5+,
       an extra check is necessary. Due to EPLB, it
       is insufficient to try to resume the device
       without the host being resumed. As a result,
       Any attempt to step a warp, whose lanes might
       be in the cudaDeviceSynchronize() syscall will
       return CUDBG_ERROR_WARP_RESUME_NOT_POSSIBLE.
       The frontend will gracefully handle this error
       by using a breakpoint to resume instead.

       A second check is required to see if the warp is present inside
       a syscall that requires host resuming. Since the current
       debugger policy is to resume threads that wind up inside
       a syscall after the step, syscalls that require host interaction
       (such as GetParamBuffer and Launch under EPLB) will return
       the same error (CUDBG_ERROR_WARP_RESUME_NOT_POSSIBLE)
       and will require the frontend to handle this correctly.

       The late check is required in case the step actually moved
       the warp into a syscall that requires EPLB.
     */
    if (checkForHostResume) {
        res = dev->halo.checkAnyLaneInContinuation(dev, vsm, steppedWarpMask, &anyLaneInContinuation);
        if (res != CUDBG_SUCCESS) {
            CUDBG_DEBUG("Unable to check if any lane is in continuation\n");
            goto done;
        }

        if (anyLaneInContinuation) {
            CUDBG_DEBUG(" SStep late check : Found a lane inside continuation. Returning WARP_RESUME_NOT_POSSIBLE\n");
            res = CUDBG_ERROR_WARP_RESUME_NOT_POSSIBLE;
            goto done;
        }

        res = dev->halo.checkWarpNeedsHostResume(dev, vsm, wp, &needsHostResume);
        if (res != CUDBG_SUCCESS) {
            CUDBG_DEBUG("Unable to check if warp needs host resume\n");
            goto done;
        }

        if (needsHostResume) {
            CUDBG_DEBUG(" SStep late check : Found vsm%u/wp%u at pc 0x%x inside host resume syscall. Returning WARP_RESUME_NOT_POSSIBLE\n", vsm, wp, pc);
            res = CUDBG_ERROR_WARP_RESUME_NOT_POSSIBLE;
            goto done;
        }
    }

    res = haloInPatchRegion(pc, ctx, &patch,
                            CUDBG_PATCH_SYSCALL | CUDBG_PATCH_HW_WAR,
                            &inPatch, false);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to haloInPatchRegion failed in tgdbSingleStepWarp.\n");
        goto done;
    }

    if (inPatch) {
        if ((patch->kind == CUDBG_PATCH_SYSCALL) ||
            HALO_PATCH_IS_HW_WAR(patch->kind)) {
#ifndef RELEASE /* Internal debugging of syscalls */
            if (patch->debug) {
                if (!hitUnsteppable) {
                    CUDBG_TRACE(" debugging internal code, not hopping over it.\n");
                    res = CUDBG_SUCCESS;
                    goto done;
                }
                else
                    CUDBG_TRACE(" debugging internal code, but forcing hop (unsteppable instruction)\n");
            }
#endif
            forceLateResume = true;

            if (patch->kind == CUDBG_PATCH_SYSCALL)
                CUDBG_DEBUG(" singleStepSM stepped into a device system call. Forcing resume\n");
            else if (patch->kind == CUDBG_PATCH_GLOBAL_SYSCALL)
                CUDBG_DEBUG(" singleStepSM stepped into a device global system call. Forcing resume\n");
            else if (HALO_PATCH_IS_HW_WAR(patch->kind))
                CUDBG_DEBUG(" singleStepSM stepped into a driver WAR patch(kind = %d). Forcing resume\n", patch->kind);
        }
    }
    else if (hitUnsteppable) {
        CUDBG_DEBUG(" singleStepSM hit an unsteppable instruction. Forcing resume\n");
        forceLateResume = true;
    }

    CUDBG_DEBUG("forceLateResume = %d\n", forceLateResume);
    if (forceLateResume) {
        res = doStepResume(dev, vsm, wp, steppedWarpMask, rewindMasks);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to doStepResume failed in tgdbSingleStepWarp.\n");
            goto done;
        }
    }

    /* [CILP] Invalidate all the SMs before collect, as work can show up at
       any time while sstepping */
    if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_CILP) {
        res = invalidateSMState(dev);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Failed to invalidate sm states\n");
            goto done;
        }
    }

    res = dev->halo.collectDeviceState(dev, true, rewindMasks);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to collectDeviceState failed.\n");
        goto done;
    }

done:
    clearTemporaryBreakpoints(dev);

    free(rewindMasks);

    return res;
}

CUDBGResult
tgdbWaitForContextEvent(Context ctx, uint32_t sm, bool sstep, bool clearEvent, uint32_t *timeoutMs, bool* timeoutReceived)
{
    int numEvents = 1, triggeredEventIdx = -1, numEventsTriggered = -1;
    cuosEvent *eventList[1] = {0};
    CUDBGResult res = CUDBG_SUCCESS;
    unsigned int timeout = timeoutMs ? *timeoutMs : CUOS_INFINITE_TIMEOUT;

    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_ARGS, "Cannot wait on an invalid context\n");

    /* Fallback to the legacy way of doing this if we can't handle per context events */
    if ((haloGlobals.initData.flags & HALO_INIT_FLAGS_ENABLE_CONTEXT_EVENTS) == 0)
        return tgdbWaitForDeviceEvent(ctx->dev->deviceIdx, sm, sstep, clearEvent, timeoutMs, timeoutReceived);

    eventList[0] = &ctx->event;
    numEventsTriggered = cuosEventWaitMultiple(eventList, numEvents, &triggeredEventIdx, 1, timeout);
    CUDBG_VERIFY(numEventsTriggered >= 0, CUDBG_ERROR_COMMUNICATION_FAILURE, "cuosEventWaitMultiple failed!\n");

    if (numEventsTriggered == 0) {
        *timeoutReceived = true;
        return handleTimeoutDeviceEvent(ctx->dev->deviceIdx, sm, sstep);
    }

    *timeoutReceived = false;
    if (clearEvent) {
        res = ctx->dev->halo.clearEvent(ctx->dev, ctx);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to clear event!\n");
    }

    return res;
}

CUDBGResult
tgdbWaitForDeviceEvent(uint32_t devId, uint32_t sm, bool sstep, bool clearEvent, uint32_t *timeoutMs, bool* timeoutReceived)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CudbgDevice dev;
    int numEvents = 0, triggeredEventIdx = -1, numEventsTriggered = -1;
    static int eventListSize = 0;
    static cuosEvent **eventList = NULL;
    static Context* contextList = NULL;
    unsigned int timeout = timeoutMs ? *timeoutMs : CUOS_INFINITE_TIMEOUT;

    CUDBG_VERIFY(timeoutReceived, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    CUDBG_DEBUG("devId=%u\n", devId);
    *timeoutReceived = false;

    dev = haloGlobals.device[devId];
    if (dev->status != CUDBG_SUCCESS) {
        CUDBG_ERROR("Device error in tgdbWaitForDeviceEvent.\n");
        return dev->status;
    }

    res = dev->dmal->getEventListForDevice(dev, NULL, NULL, &numEvents, 0);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get fd list size\n");
    if (numEvents == 0) {
        CUDBG_TRACE("No contexts found, claiming success! timeout=%d\n", *timeoutMs);
        return CUDBG_SUCCESS;
    }

    if (eventListSize < numEvents) {
        eventList = (cuosEvent **)realloc(eventList, numEvents * sizeof(*eventList));
        CUDBG_VERIFY(eventList, CUDBG_ERROR_OS_RESOURCES, "realloc failed\n");
        contextList = (Context *)realloc(contextList, numEvents * sizeof(*contextList));
        CUDBG_VERIFY(contextList, CUDBG_ERROR_OS_RESOURCES, "realloc failed\n");
        eventListSize = numEvents;
    }

    res = dev->dmal->getEventListForDevice(dev, eventList, contextList, &numEvents, eventListSize);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get fd list size\n");

    numEventsTriggered = cuosEventWaitMultiple(eventList, numEvents, &triggeredEventIdx, 1, timeout);
    CUDBG_VERIFY(numEventsTriggered >= 0, CUDBG_ERROR_COMMUNICATION_FAILURE, "cuosEventWaitMultiple failed!\n");

    if (numEventsTriggered == 0) {
        *timeoutReceived = true;
        return handleTimeoutDeviceEvent(devId, sm, sstep);
    }

    *timeoutReceived = false;
    if (clearEvent) {
        res = dev->halo.clearEvent(dev, contextList[triggeredEventIdx]);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to clear event!\n");
    }

    return res;
}

static CUDBGResult
handleTimeoutDeviceEvent(uint32_t devId, uint32_t sstepSM, bool sstep)
{
    CudbgDevice dev;
    CudbgSMState_t state;
    uint32_t vsm;
    CUDBGResult res;

    CUDBG_DEBUG("dev=%u, sstepSm=%u, sstep=%u\n", devId, sstepSM, sstep);

    dev = haloGlobals.device[devId];

    if (dev->status != CUDBG_SUCCESS) {
        CUDBG_ERROR("device error (res=%u)\n", dev->status);
        return dev->status;
    }

    if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_CILP) {
        CUDBG_DEBUG("CILP device at %u, skipping handleTimeoutDeviceEvent\n", devId);
        return CUDBG_SUCCESS;
    }

    for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {

        if (sstep && sstepSM != vsm)
            continue;

        res = dev->halo.readSMState(dev, vsm, &state);
        if (res != CUDBG_SUCCESS) {
            CUDBG_ERROR("Call to readSMState failed in handleTimeoutDeviceEvent.\n");
            return res;
        }

        /* If not single-stepping, report a timeout event for any sm
           that has a set bpmask.  If single-stepping, we shouldn't
           report a timeout even if it comes from an SM that we didn't
           step. */
        if (warpBitmaskAny(&state.bpmask)) {
            CUDBG_DEBUG("found breakpoint on dev %d vsm %d: "
                        "bpmask=" CU_WARP_BIT_MASK_FMT_128_STR " - raising event\n",
                        devId, vsm,
                        CU_WARP_BIT_MASK_FMT_128_VAL(&state.bpmask));
            return CUDBG_SUCCESS;
        }

        /* On Fermi, interrupts are not raised when single-stepping
           the _last_ warp on an sm over an exit instruction.  So, if
           we timeout while waiting for a single-step interrupt, and
           the sm is empty, we report it as a gpuEvent.  This should
           be safe for Tesla as well, although Tesla always sends an
           interrupt for single-stepping an exit instruction in all
           cases. */
        if (sstep && !warpBitmaskAny(&state.tidValid)) {
            CUDBG_DEBUG("found no valid warp on dev %d vsm %d: "
                        "assuming warp has terminated - raising event\n",
                        devId, vsm);
            return CUDBG_SUCCESS;
        }
    }

    CUDBG_DEBUG("no device event found\n");
    return CUDBG_ERROR_COMMUNICATION_FAILURE;
}

CUDBGResult
tgdbConsumeContextEvents(Context ctx)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t zeroTimeout = 0; /* poll needs to return immediately */
    bool timeoutReceived = false;
    uint32_t numAdditionalEvents = 0;

    if (!ctx) return CUDBG_SUCCESS;

    do {
        /* We are using a zero timeout value, so select will peek at the eventFd */
        res = tgdbWaitForContextEvent(ctx, -1, false, true, &zeroTimeout, &timeoutReceived);
        if (res != CUDBG_SUCCESS) {
            CUDBG_TRACE("couldn't peek at device event state (res=%d); returning early.\n", res);
            return res;
        }

        /* timeoutReceived will only be false if the eventFd has a real event on it.
           Clear out the event data associated with it. */
        if (!timeoutReceived) {
            CUDBG_TRACE("additional device event found after suspending; attempting to consume data\n");
            numAdditionalEvents++;
        }
    }
    while (!timeoutReceived && numAdditionalEvents < ctx->dev->halo.deviceInfo.numSMs);

    return CUDBG_SUCCESS;
}

CUDBGResult
tgdbConsumeDeviceEvents(CudbgDevice dev)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t zeroTimeout = 0; /* poll needs to return immediately */
    bool timeoutReceived = false;
    uint32_t numAdditionalEvents = 0;

    do {
        /* We are using a zero timeout value, so select will peek at the eventFd */
        res = tgdbWaitForDeviceEvent(dev->deviceIdx, -1, false, true, &zeroTimeout, &timeoutReceived);
        if (res != CUDBG_SUCCESS) {
            CUDBG_TRACE("couldn't peek at device event state (res=%d); returning early.\n", res);
            return res;
        }

        /* timeoutReceived will only be false if the eventFd has a real event on it.
           Clear out the event data associated with it. */
        if (!timeoutReceived) {
            CUDBG_TRACE("additional device event found after suspending; attempting to consume data\n");
            numAdditionalEvents++;
        }
    }
    while (!timeoutReceived && numAdditionalEvents < dev->halo.deviceInfo.numSMs);

    return CUDBG_SUCCESS;
}
