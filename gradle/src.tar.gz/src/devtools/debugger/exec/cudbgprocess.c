/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <cuos_platform.h>
// __TEMP_WAR__ No dl* support on HOS
#ifndef __hos__
#include <dlfcn.h>
#endif

int main(int argc, char *argv[])
{
    void *handle = NULL;
    char *error;
    int (*cudbgMain)(int apiClientPid, unsigned int apiClientRevision, int sessionId,
                     int attachState, int attachEventInitialized, int writeFd, int detachFd,
                     int attachStubInUse, int enablePreemptionDebugging);
    char *libname;

#if cuosOsIsApple()
    libname = "libcuda.dylib";
#elif cuosOsIsAndroid()
    libname = "libcuda.so";
#else
    libname = "libcuda.so.1";
#endif

    if (argc != 10) {
        fprintf(stderr, "Incorrect number of arguments!\n");
        return 1;
    }

// __TEMP_WAR__ No dl* support on HOS
#ifndef __hos__
    handle = dlopen(libname, RTLD_NOW);
#endif
#if cuosOsIsApple()
    if (!handle)
        handle = dlopen ("@rpath/libcuda.dylib", RTLD_NOW);

    if (handle == NULL & getenv("DYLD_FRAMEWORK_PATH") != NULL) {
        setenv ("DYLD_LIBRARY_PATH", getenv ("DYLD_FRAMEWORK_PATH"), 0);
        handle = dlopen ("libcuda.dylib", RTLD_NOW);
    }

    if (!handle)
        handle = dlopen ("/usr/local/cuda/lib/libcuda.dylib", RTLD_NOW);
#endif
    if (NULL == handle) {
        fprintf(stderr, "dlopen failed!\n");
        return 1;
    }

// __TEMP_WAR__ No dl* support on HOS
#ifndef __hos__
    // clear previous errors
    dlerror();

    *(void **)(&cudbgMain) = dlsym(handle, "cudbgMain");

    if ((error = dlerror()) != NULL)  {
        fprintf(stderr, "%s\n", error);
        return 1;
    }
#endif

    cudbgMain(atoi(argv[1]),
              atoi(argv[2]),
              atoi(argv[3]),
              atoi(argv[4]),
              atoi(argv[5]),
              atoi(argv[6]),
              atoi(argv[7]),
              atoi(argv[8]),
              atoi(argv[9]));

    return 0;
}

