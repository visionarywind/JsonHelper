/*
 * Copyright 2007-2014 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include <stdio.h>

#include <cudbgutils.h>
#include <cudbgcoredump.h>
#include <cudbgcoredumpelf.h>
#include <cudbgelfreloc.h>
#include <tools_shared_internal_nvelf.h>

#define MAX_EFH_SHNUM 0xffff
#ifndef SHN_XINDEX
#define SHN_XINDEX 0xffff
#endif

typedef struct {
    elf64FileHeader *efh;

    FILE *f;

    /* List of elf64SectionHeader's */
    tList *sectionHeaderTable;

    /* Generic string table */
    CudbgCoredumpStringTable *stringTable;

    /* Section header string table */
    CudbgCoredumpStringTable *shStringTable;
} CudbgCoredumpElfGlobals;

static CudbgCoredumpElfGlobals coredumpElfGlobals;
static char stringBuffer[CUDBG_COREDUMP_STRING_BUFFER_SIZE];

#if cuosOsIsHos()
    // __TEMP_WAR__ 200104088 HOS does not supply the errno from stdio
    extern int errno;
#endif

static CUDBGResult
cudbgCoredumpOpenCoreFile(const char *name)
{
    coredumpElfGlobals.f = fopen(name, "wb");
    CUDBG_VERIFY(coredumpElfGlobals.f, CUDBG_ERROR_OS_RESOURCES,
                 "Could not create file %s, errno %d\n", name, errno);

    return CUDBG_SUCCESS;
}

static CUDBGResult
cudbgCoredumpCloseCoreFile(void)
{
    int ret;

    CUDBG_VERIFY(coredumpElfGlobals.f, CUDBG_ERROR_INVALID_ARGS,
                 "Allocate the core file first!\n");

    ret = fclose(coredumpElfGlobals.f);
    CUDBG_VERIFY(ret == 0, CUDBG_ERROR_INTERNAL,
                 "Failed to close core file (errno %d)\n", errno);

    return CUDBG_SUCCESS;
}

static CUDBGResult
cudbgCoredumpWriteToCoreFile(const void *buf, size_t size)
{
    const size_t nmemb = 1;
    size_t written = fwrite(buf, size, nmemb, coredumpElfGlobals.f);
    CUDBG_VERIFY(written == nmemb, CUDBG_ERROR_OS_RESOURCES,
                 "Write failed: requested 0x%llx, written 0x%llx\n",
                 size, written * nmemb);

    return CUDBG_SUCCESS;
}

static CUDBGResult
cudbgCoredumpRewindCoreFile(void)
{
    CUDBG_VERIFY(coredumpElfGlobals.f, CUDBG_ERROR_INVALID_ARGS,
                 "Allocate the core file first!\n");

    rewind(coredumpElfGlobals.f);

    return CUDBG_SUCCESS;
}

static CUDBGResult
cudbgCoredumpGetCurrentFilePosition(uint64_t *offset)
{
    /* ftell is defined as returning long */
    int64_t ret = -1;
    CUDBG_VERIFY(offset, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args!\n");

    CUDBG_VERIFY(coredumpElfGlobals.f, CUDBG_ERROR_INVALID_ARGS,
                 "Allocate the core file first!\n");

    ret = (int64_t)ftell(coredumpElfGlobals.f);
    CUDBG_VERIFY(ret >= 0, CUDBG_ERROR_OS_RESOURCES,
                 "Failed to find the current offset in the core file, errno %d\n",
                 errno);

    *offset = (uint64_t)ret;

    return CUDBG_SUCCESS;
}

CUDBGResult
cudbgCoredumpCreateStringTable(CudbgCoredumpStringTable **stringTable)
{
    CUDBGResult res = CUDBG_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;
    const char *string = "";

    *stringTable = (CudbgCoredumpStringTable *)malloc(sizeof(CudbgCoredumpStringTable));
    CUDBG_VERIFY(*stringTable, CUDBG_ERROR_OS_RESOURCES,
                 "Failed to allocate memory\n");

    (*stringTable)->table = toolsListNew();
    CUDBG_VERIFY((*stringTable)->table, CUDBG_ERROR_UNKNOWN,
                 "Failed to create stringTable\n");

    /* ELF string tables have a NULL at the beginning, so init the
     * offset accordingly. This makes it easier for subsequent code
     * to record offsets into the string table. */
    tres = toolsListAppend((*stringTable)->table, (char *)string);
    CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_INTERNAL,
                 "Failed to insert null string into stringTable (tres=%u)\n", tres);

    (*stringTable)->tableOffset = strlen(string) + 1;

    return res;
}

CUDBGResult
cudbgCoredumpAddToStringTable(CudbgCoredumpStringTable *stringTable,
                              uint64_t *stringTableOffset, const char *string)
{
    CUDBGResult res = CUDBG_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;
    char *buf;
    size_t len;

    CUDBG_VERIFY(stringTable && stringTableOffset, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args\n");

    len = strlen(string) + 1;
    buf = (char *)malloc(len);
    CUDBG_VERIFY(buf, CUDBG_ERROR_OS_RESOURCES,
                 "Failed to allocate memory\n");

    memcpy(buf, string, len);

    /* Offset where the string will be written */
    *stringTableOffset = stringTable->tableOffset;

    /* Add to the string table */
    tres = toolsListAppend(stringTable->table, buf);
    CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_INTERNAL,
                 "Failed to insert string into stringTable (tres=%u)\n", tres);

    /* Update the string table offset */
    stringTable->tableOffset += len;

    return res;
}

CUDBGResult
cudbgCoredumpGetCurrentStringTableOffset(CudbgCoredumpStringTable *stringTable,
                                         uint64_t *stringTableOffset)
{
    CUDBG_VERIFY(stringTable && stringTableOffset, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args\n");

    *stringTableOffset = stringTable->tableOffset;

    return CUDBG_SUCCESS;
}

static CUDBGResult
cudbgCoredumpCreateSectionHeaderTable(void)
{
    TOOLSresult tres = TOOLS_SUCCESS;
    elf64SectionHeader *esh;

    /* Initialize the list holding the section header table */
    coredumpElfGlobals.sectionHeaderTable = toolsListNew();
    CUDBG_VERIFY(coredumpElfGlobals.sectionHeaderTable, CUDBG_ERROR_UNKNOWN,
                 "Failed to create sectionHeaderTable\n");

    /* Add the special 0th entry to the section header table */
    esh = (elf64SectionHeader *)malloc(sizeof(elf64SectionHeader));
    CUDBG_VERIFY(esh, CUDBG_ERROR_OS_RESOURCES,
                 "Failed to allocate memory\n");

    esh->name       = 0;
    esh->type       = SHT_NULL;
    esh->flags      = 0;
    esh->addr       = 0;
    esh->offset     = 0;
    esh->size       = 0;
    esh->link       = SHN_UNDEF;
    esh->info       = 0;
    esh->addralign  = 0;
    esh->entsize    = 0;

    tres = toolsListAppend(coredumpElfGlobals.sectionHeaderTable, esh);
    CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_UNKNOWN,
                 "Failed to insert section header section header table (tres=%u)\n",
                 tres);

    return CUDBG_SUCCESS;
}

/* Description:
 *
 * Adds a section header to the section header table.
 *
 * Arguments:
 *
 * IN  esh      : The section header to write into the section header table.
 * OUT shIndex  : Section header index of esh once it's added to the section
 *                header table.
 */
static CUDBGResult
cudbgCoredumpAddToSectionHeaderTable(elf64SectionHeader *esh, uint64_t *shIndex)
{
    TOOLSresult tres = TOOLS_SUCCESS;
    tList *shTable = coredumpElfGlobals.sectionHeaderTable;

    if (shIndex != NULL) {
        /* Store the index in the section header table where the section header
         * will be written */
        *shIndex = toolsListSize(shTable);
    }

    /* Write the header to the section header list */
    tres = toolsListAppend(shTable, esh);
    CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_INTERNAL,
                 "Failed to insert esh into sectionHeaderTable (tres=%u)\n", tres);

    return CUDBG_SUCCESS;
}

/* Description:
 *
 * Dumps the section header table to the core file.
 *
 * Arguments:
 *
 * OUT shTableFileOffset    : Offset in the core file where the section header is written.
 * OUT shTableNumEntries    : Number of entries in the section header table.
 */
static CUDBGResult
cudbgCoredumpDumpSectionHeaderTable(uint64_t *shStringTableShIndex,
                                    uint64_t *shTableFileOffset,
                                    uint64_t *shTableNumEntries)
{
    CUDBGResult res = CUDBG_SUCCESS;
    tList *shTable = coredumpElfGlobals.sectionHeaderTable;
    elf64SectionHeader *esh;
    tListItr *itr;
    bool patchFirstSectionHeader = false;

    /* Get the file offset at which the section header table will be written */
    res = cudbgCoredumpGetCurrentFilePosition(shTableFileOffset);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to find current sectionOffset\n");

    /* Record the number of entries in the section header table */
    *shTableNumEntries = toolsListSize(shTable);

    /* The elf header only has 16 bits for the number of section headers. So if
     * we have more than MAX_EFH_SHNUM section headers, we need to patch the
     * first section header with the correct section header number. */
    if (*shTableNumEntries > MAX_EFH_SHNUM)
        patchFirstSectionHeader = true;

    /* Write the section header table out to the file */
    itr = toolsListGetIterator(shTable);
    while (itr != NULL) {
        esh = (elf64SectionHeader *)toolsListGetElem(itr);
        CUDBG_VERIFY(esh, CUDBG_ERROR_INTERNAL,
                     "Failed to get section header table element\n");

        /* Patch section header 0 if needed */
        if (patchFirstSectionHeader) {
            esh->size = *shTableNumEntries;
            *shTableNumEntries = 0;

            if (*shStringTableShIndex > MAX_EFH_SHNUM) {
                esh->link = (elfWord)*shStringTableShIndex;
                *shStringTableShIndex = SHN_XINDEX;
            }

            patchFirstSectionHeader = false;
        }

        res = cudbgCoredumpWriteToCoreFile(esh, sizeof(elf64SectionHeader));
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to write section header into corefile\n");

        itr = toolsListGetNext(itr);
    }

    return CUDBG_SUCCESS;
}

/* Description:
 *
 * Dumps a string table, which may either be a generic string table or the
 * section header string table, into the core file.
 *
 * Arguments:
 *
 * IN    stringTable        : The string table to dump.
 * IN    stringTableName    : A string for the string table name.
 * OUT   shtIndex           : Section header table index for the string table.
 *                            Needed for plugging in the section header string
 *                            table's section header index into the elf file header.
 *                            Ignored if NULL is passed in.
 */
static CUDBGResult
cudbgCoredumpDumpStringTable(CudbgCoredumpStringTable *stringTable,
                             const char *stringTableName, uint64_t *shtIndex)
{
    CUDBGResult res = CUDBG_SUCCESS;
    elf64SectionHeader *esh = NULL;
    uint64_t shStringTabOffset;
    uint64_t sectionOffset;
    uint64_t stringTableSize;
    char *sname = NULL;
    tListItr *itr = NULL;

    /* Add the string table's name to the section header string table */
    res = cudbgCoredumpAddToStringTable(coredumpElfGlobals.shStringTable,
                                        &shStringTabOffset, stringTableName);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to add to section header string table\n");

    /* Get the file offset at which the string table will be written */
    res = cudbgCoredumpGetCurrentFilePosition(&sectionOffset);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to find current sectionOffset\n");

    /* Get the size of the string table */
    res = cudbgCoredumpGetCurrentStringTableOffset(stringTable, &stringTableSize);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to get string table size\n");

    /* Write the string table out to the file */
    itr = toolsListGetIterator(stringTable->table);
    while (itr != NULL) {
        sname = (char *)toolsListGetElem(itr);
        CUDBG_VERIFY(sname, CUDBG_ERROR_INTERNAL,
                     "Failed to get string from strtab\n");

        res = cudbgCoredumpWriteToCoreFile(sname, strlen(sname) + 1);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to write string into strtab\n");

        itr = toolsListGetNext(itr);
    }

    esh = (elf64SectionHeader *)calloc(1, sizeof(elf64SectionHeader));
    /* Create a section header for the string table */
    CUDBG_VERIFY(esh, CUDBG_ERROR_OS_RESOURCES,
                 "Failed to allocate memory\n");

    /* Fill out the header */
    esh->name       = (elfWord)shStringTabOffset;
    esh->type       = SHT_STRTAB;
    esh->flags      = SHF_ALLOC;
    esh->addr       = 0;
    esh->offset     = sectionOffset;
    esh->size       = stringTableSize;
    esh->link       = 0;
    esh->info       = 0;
    esh->addralign  = 0;
    esh->entsize    = 0;

    /* Write the header to the section header table */
    res = cudbgCoredumpAddToSectionHeaderTable(esh, shtIndex);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Failed to insert esh into sectionHeaderTable\n");
        free(esh);
        return res;
    }

    return res;
}

static CUDBGResult
cudbgCoredumpDumpBuffer(void *buf, uint64_t address, uint64_t size, uint64_t shType,
                        uint64_t shLink, uint32_t shInfo, char *sname, uint64_t *shIndex)
{
    CUDBGResult res = CUDBG_SUCCESS;
    elf64SectionHeader *esh = NULL;
    uint64_t stringTabOffset;
    uint64_t fileOffset;

    /* Add the name to the section header string table */
    res = cudbgCoredumpAddToStringTable(coredumpElfGlobals.shStringTable,
                                        &stringTabOffset, sname);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to add to string table\n");

    /* Get the offset at which the section will be written */
    res = cudbgCoredumpGetCurrentFilePosition(&fileOffset);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to find current sectionOffset\n");

    /* Write the buffer to the core file */
    res = cudbgCoredumpWriteToCoreFile(buf, (size_t)size);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Could not write buffer to core file\n");

    esh = (elf64SectionHeader *)calloc(1, sizeof(elf64SectionHeader));
    CUDBG_VERIFY(esh, CUDBG_ERROR_OS_RESOURCES,
                 "Failed to allocate memory\n");

    /* Fill out the header */
    esh->name       = (elfWord)stringTabOffset;
    esh->type       = (elfWord)shType;
    esh->flags      = SHF_ALLOC;
    esh->addr       = address;
    esh->offset     = fileOffset;
    esh->size       = size;
    esh->link       = (elfWord)shLink;
    esh->info       = (elfWord)shInfo;
    esh->addralign  = 0;
    esh->entsize    = 0;

    /* Write the header to the section header list */
    res = cudbgCoredumpAddToSectionHeaderTable(esh, shIndex);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Failed to insert esh into sectionHeaderTable\n");
        free(esh);
        return res;
    }

    return res;
}

static CUDBGResult
cudbgCoredumpDumpGlobalMemory(CudbgCoredumpData *coredumpData)
{
    CUDBGResult res = CUDBG_SUCCESS;
    tRangeMapItr *memItr;
    uint32_t instance = 0;
    CudbgCoredumpMemoryData *memoryData;
    uint64_t address;
    uint64_t size;
    uint64_t shType;

    memItr = toolsRangeMapGetIterator(coredumpData->memoryDataMap);

    /* Loop over all memory dumps */
    while (memItr != NULL) {
        /* Get the associated memoryData */
        memoryData = (CudbgCoredumpMemoryData*)toolsRangeMapGetEntry(memItr);
        CUDBG_VERIFY(memoryData, CUDBG_ERROR_INTERNAL,
                     "Failed to read memoryData\n");

        /* Get the extents */
        address = toolsRangeMapGetAddr(memItr);
        size = toolsRangeMapGetSize(memItr);

        /* Pick a name */
        snprintf(stringBuffer, sizeof(stringBuffer), "%s.%d", CUDBG_SHNAME_GLOBAL, instance);

        /* Determine the type field */
        shType = memoryData->isManagedMem ? CUDBG_SHT_MANAGED_MEM: CUDBG_SHT_GLOBAL_MEM;

        res = cudbgCoredumpDumpBuffer(memoryData->memDump, address, size, shType,
                                      0, 0, stringBuffer, NULL);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to dump memory buffer into core file\n");

        instance++;
        memItr = toolsRangeMapGetNext(coredumpData->memoryDataMap, memItr);
    }

    return res;
}

/* Description:
 *
 * Creates a table section and dumps it into the core file. The entries of
 * the table are read out from the elements of a tList.
 *
 * Arguments:
 *
 * IN   table               : The tList whose elements hold the entries to be written out.
 * IN   dataOffsetFromEntry : The offset in bytes from an element of the tList, to
 *                            the data that makes up an entry in the table section.
 * IN   dataSize            : The size of each entry in the table section entry.
 * IN   shType              : The sh_type value of the table section being dumped.
 * IN   shLink              : The sh_link value of the table section being dumped.
 * IN   shInfo              : The sh_info value of the table section being dumped.
 * IN   sname               : A string for the name of the table section being dumped.
 * OUT  shIndex             : The section header table index of the table section that was dumped.
 *                            the data that makes up an entry in the section table.
 */
static CUDBGResult
cudbgCoredumpDumpTableFromList(tList *table, uint64_t dataOffsetFromEntry, uint64_t dataSize,
                               uint64_t shType, uint64_t shLink, uint32_t shInfo, const char *sname, uint64_t *shIndex)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t stringTabOffset;
    elf64SectionHeader *esh;
    uint64_t fileOffset;
    tListItr *itr;
    void *tableEntry;
    void *data;

    /* Get the file offset at which the table will be written. */
    res = cudbgCoredumpGetCurrentFilePosition(&fileOffset);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to find current file offset\n");

    itr = toolsListGetIterator(table);
    while (itr != NULL) {
        tableEntry = toolsListGetElem(itr);
        CUDBG_VERIFY(tableEntry, CUDBG_ERROR_INTERNAL,
                     "Failed to get table entry\n");

        data = ((char*)tableEntry + dataOffsetFromEntry);

        res = cudbgCoredumpWriteToCoreFile(data, (size_t)dataSize);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to write table data into corefile\n");

        itr = toolsListGetNext(itr);
    }

    /* Pick a name and add it to the string table */
    res = cudbgCoredumpAddToStringTable(coredumpElfGlobals.shStringTable,
                                        &stringTabOffset, sname);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to add to string table\n");

    /* Fill out the header */
    esh = (elf64SectionHeader*)malloc(sizeof(elf64SectionHeader));
    CUDBG_VERIFY(esh, CUDBG_ERROR_OS_RESOURCES,
                 "Failed to allocate memory\n");

    esh->name       = (elfWord)stringTabOffset;
    esh->type       = (elfWord)shType;
    esh->flags      = SHF_ALLOC;
    esh->addr       = 0;
    esh->offset     = fileOffset;
    esh->size       = toolsListSize(table) * dataSize;
    esh->link       = (elfWord)shLink;
    esh->info       = (elfWord)shInfo;
    esh->addralign  = 0;
    esh->entsize    = dataSize;

    /* Write the header to the section header list */
    res = cudbgCoredumpAddToSectionHeaderTable(esh, shIndex);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, CUDBG_ERROR_INTERNAL,
                 "Failed to insert esh into sectionHeaderTable\n");

    return res;
}

/* Description:
 *
 * Creates a table section and dumps it into the core file. The entries of
 * the table are read out from the elements of a tHashMap.
 *
 * Arguments:
 *
 * IN   map                 : The tHashMap whose elements hold the entries to be written out.
 * IN   dataOffsetFromEntry : The offset in bytes from an element of the tHashMap, to
 *                            the data that makes up an entry in the table section.
 * IN   dataSize            : The size of each entry in the table section entry.
 * IN   shType              : The sh_type value of the table section being dumped.
 * IN   shLink              : The sh_link value of the table section being dumped.
 * IN   shInfo              : The sh_info value of the table section being dumped.
 * IN   sname               : A string for the name of the table section being dumped.
 * OUT  shIndex             : The section header table index of the table section that was dumped.
 */
static CUDBGResult
cudbgCoredumpDumpTableFromMap(tHashMap *map, uint64_t dataOffsetFromEntry, uint64_t dataSize,
                              uint64_t shType, uint64_t shLink, uint32_t shInfo, char *sname, uint64_t *shIndex)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t stringTabOffset;
    elf64SectionHeader *esh;
    uint64_t fileOffset;
    tHashMapItr *itr;
    void *mapEntry;
    void *data;

    /* Get the file offset at which the table will be written. */
    res = cudbgCoredumpGetCurrentFilePosition(&fileOffset);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to find current file offset\n");

    itr = toolsHashMapGetIterator(map);
    while (itr != NULL) {
        mapEntry = toolsHashMapGetEntry(itr);
        CUDBG_VERIFY(map, CUDBG_ERROR_INTERNAL,
                     "Failed to get map entry\n");

        data = ((char*)mapEntry + dataOffsetFromEntry);

        res = cudbgCoredumpWriteToCoreFile(data, (size_t)dataSize);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to write table data into corefile\n");

        itr = toolsHashMapGetNext(map, itr);
    }

    /* Pick a name and add it to the string table */
    res = cudbgCoredumpAddToStringTable(coredumpElfGlobals.shStringTable,
                                        &stringTabOffset, sname);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to add to string table\n");

    /* Fill out the header */
    esh = (elf64SectionHeader *)malloc(sizeof(elf64SectionHeader));
    CUDBG_VERIFY(esh, CUDBG_ERROR_OS_RESOURCES,
                 "Failed to allocate memory\n");

    esh->name       = (elfWord)stringTabOffset;
    esh->type       = (elfWord)shType;
    esh->flags      = SHF_ALLOC;
    esh->addr       = 0;
    esh->offset     = fileOffset;
    esh->size       = toolsHashMapSize(map) * dataSize;
    esh->link       = (elfWord)shLink;
    esh->info       = (elfWord)shInfo;
    esh->addralign  = 0;
    esh->entsize    = dataSize;

    /* Write the header to the section header list */
    res = cudbgCoredumpAddToSectionHeaderTable(esh, shIndex);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, CUDBG_ERROR_INTERNAL,
                 "Failed to insert esh into sectionHeaderTable\n");

    return res;
}

static CUDBGResult
cudbgCoredumpDumpGridTable(CudbgCoredumpDeviceData *deviceData,
                           uint64_t devTableShIndex, uint32_t devIdx)
{
    CUDBGResult res = CUDBG_SUCCESS;
    tHashMapItr *itr;
    uint64_t gridTableShIndex;
    uint32_t gridIdx = 0;
    CudbgCoredumpGridData *gridData;

    /* Pick a name */
    snprintf(stringBuffer, sizeof(stringBuffer), "%s.dev%d",
             CUDBG_SHNAME_GRIDTABLE, devIdx);

    /* Write the grid table out */
    res = cudbgCoredumpDumpTableFromMap(deviceData->gridDataMap,
                                        offsetof(CudbgCoredumpGridData, gridTableEntry),
                                        sizeof(CudbgGridTableEntry), CUDBG_SHT_GRID_TABLE, devTableShIndex,
                                        devIdx, stringBuffer, &gridTableShIndex);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to dump grid table entries\n");

    /* Dump the related sections */
    itr = toolsHashMapGetIterator(deviceData->gridDataMap);
    while (itr != NULL) {
        gridData = (CudbgCoredumpGridData *)toolsHashMapGetEntry(itr);
        CUDBG_VERIFY(gridData, CUDBG_ERROR_INTERNAL,
                     "Failed to get gridData\n");

        /* Dump the params memory section */
        if (gridData->paramsDump) {
            /* Pick a name */
            snprintf(stringBuffer, sizeof(stringBuffer), "%s.dev%d.grid%d",
                     CUDBG_SHNAME_PARAM, devIdx, gridIdx);

            /* Dump the params buffer into the core file */
            res = cudbgCoredumpDumpBuffer(gridData->paramsDump, 0,
                                          gridData->paramsSize, CUDBG_SHT_PARAM_MEM,
                                          gridTableShIndex, gridIdx, stringBuffer, NULL);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                         "Failed to dump param memory buffer into core file\n");
        }

        gridIdx++;
        itr = toolsHashMapGetNext(deviceData->gridDataMap, itr);
    }

    return res;
}

static CUDBGResult
cudbgCoredumpDumpLaneTable(CudbgCoredumpWarpData *warpData, uint64_t warpTableShIndex,
                           uint32_t devIdx, uint32_t smIdx, uint32_t ctaIdx, uint32_t warpIdx)
{
    CUDBGResult res = CUDBG_SUCCESS;
    tListItr *itr;
    uint32_t laneIdx = 0;
    CudbgCoredumpThreadData *threadData;
    uint64_t threadTableShIndex;

    /* Pick a name */
    snprintf(stringBuffer, sizeof(stringBuffer), "%s.dev%d.sm%d.cta%d.wp%d",
             CUDBG_SHNAME_LNTABLE, devIdx, smIdx, ctaIdx, warpIdx);

    /* Write the thread table out */
    res = cudbgCoredumpDumpTableFromList(warpData->threadDataList,
                                         offsetof(CudbgCoredumpThreadData, threadTableEntry),
                                         sizeof(CudbgThreadTableEntry), CUDBG_SHT_LN_TABLE, warpTableShIndex,
                                         warpIdx, stringBuffer, &threadTableShIndex);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to dump thread table entries\n");

    /* Dump the related sections */
    itr = toolsListGetIterator(warpData->threadDataList);
    while (itr != NULL) {
        threadData = (CudbgCoredumpThreadData *)toolsListGetElem(itr);
        CUDBG_VERIFY(threadData, CUDBG_ERROR_INTERNAL,
                     "Failed to get threadData\n");

        /* This can be NULL (lightweight corefiles) */
        if (threadData->lmemHi) {
            /* Pick a name for lmemDump */
            snprintf(stringBuffer, sizeof(stringBuffer),
                     "%s.dev%d.sm%d.cta%d.wp%d.ln%d",
                     CUDBG_SHNAME_LOCAL, devIdx, smIdx, ctaIdx, warpIdx, laneIdx);

            /* Dump the lmem buffer into the core file */
            res = cudbgCoredumpDumpBuffer(threadData->lmemHi, warpData->lmemHiOffset,
                                          warpData->lmemHiSizePerLane, CUDBG_SHT_LOCAL_MEM,
                                          threadTableShIndex, laneIdx, stringBuffer, NULL);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                         "Failed to dump local memory buffer into core file\n");
        }

        /* Pick a name for the backtrace table */
        snprintf(stringBuffer, sizeof(stringBuffer),
                 "%s.dev%d.sm%d.cta%d.wp%d.ln%d",
                 CUDBG_SHNAME_BT, devIdx, smIdx, ctaIdx, warpIdx, laneIdx);

        /* Dump the backtrace buffer into the core file */
        res = cudbgCoredumpDumpTableFromList(threadData->backtrace, 0,
                                             sizeof(CudbgBacktraceTableEntry), CUDBG_SHT_BT, threadTableShIndex,
                                             laneIdx, stringBuffer, NULL);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to dump backtrace entries\n");

        /* Pick a name for regDump */
        snprintf(stringBuffer, sizeof(stringBuffer),
                 "%s.dev%d.sm%d.cta%d.wp%d.ln%d",
                 CUDBG_SHNAME_REGS, devIdx, smIdx, ctaIdx, warpIdx, laneIdx);

        /* Dump the reg buffer into the core file */
        res = cudbgCoredumpDumpBuffer(threadData->regDump, 0,
                                      warpData->numRegsPerLane * sizeof(uint32_t), CUDBG_SHT_DEV_REGS,
                                      threadTableShIndex, laneIdx, stringBuffer, NULL);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to dump register buffer into core file\n");

        /* Pick a name for predicates */
        snprintf(stringBuffer, sizeof(stringBuffer),
                 "%s.dev%d.sm%d.cta%d.wp%d.ln%d",
                 CUDBG_SHNAME_PRED, devIdx, smIdx, ctaIdx, warpIdx, laneIdx);

        /* Dump the predicates buffer into the core file */
        res = cudbgCoredumpDumpBuffer(threadData->predicates, 0,
                                      threadData->predicatesDumpSize, CUDBG_SHT_DEV_PRED,
                                      threadTableShIndex, laneIdx, stringBuffer, NULL);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to dump predicate buffer into core file\n");

        itr = toolsListGetNext(itr);
        laneIdx++;
    }

    return res;
}

static CUDBGResult
cudbgCoredumpDumpWarpTable(CudbgCoredumpCTAData *ctaData, uint64_t ctaTableShIndex,
                           uint32_t devIdx, uint32_t smIdx, uint32_t ctaIdx)
{
    CUDBGResult res = CUDBG_SUCCESS;
    tListItr *itr;
    uint32_t warpIdx = 0;
    CudbgCoredumpWarpData *warpData;
    uint64_t warpTableShIndex;

    /* Pick a name */
    snprintf(stringBuffer, sizeof(stringBuffer), "%s.dev%d.sm%d.cta%d",
             CUDBG_SHNAME_WPTABLE, devIdx, smIdx, ctaIdx);

    /* Write the warp table out */
    res = cudbgCoredumpDumpTableFromList(ctaData->warpDataList,
                                         offsetof(CudbgCoredumpWarpData, warpTableEntry),
                                         sizeof(CudbgWarpTableEntry), CUDBG_SHT_WP_TABLE, ctaTableShIndex,
                                         ctaIdx, stringBuffer, &warpTableShIndex);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to dump warp table entries\n");

    /* Dump the related sections */
    itr = toolsListGetIterator(ctaData->warpDataList);
    while (itr != NULL) {
        warpData = (CudbgCoredumpWarpData *)toolsListGetElem(itr);
        CUDBG_VERIFY(warpData, CUDBG_ERROR_INTERNAL,
                     "Failed to get warpData\n");

        if (ctaData->numUniformRegsPrWarp > 0) {
            CUDBG_VERIFY(warpData->uniformRegDump, CUDBG_ERROR_INTERNAL,
                         "NULL uniformRegDump in warpData\n");

            /* Pick a name for uniformRegDump */
            snprintf(stringBuffer, sizeof(stringBuffer),
                     "%s.dev%d.sm%d.cta%d.wp%d",
                     CUDBG_SHNAME_UREGS, devIdx, smIdx, ctaIdx, warpIdx);

            /* Dump the uniform reg buffer into the core file */
            res = cudbgCoredumpDumpBuffer(warpData->uniformRegDump, 0,
                                          ctaData->numUniformRegsPrWarp * sizeof(uint32_t), CUDBG_SHT_DEV_UREGS,
                                          warpTableShIndex, warpIdx, stringBuffer, NULL);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                         "Failed to dump uniform register buffer into core file\n");
        }

        if (ctaData->numUniformPredicatesPrWarp > 0) {
            CUDBG_VERIFY(warpData->uniformPredicatesDump, CUDBG_ERROR_INTERNAL,
                         "NULL uniformPredicatesDump in warpData\n");

            /* Pick a name for uniform predicates */
            snprintf(stringBuffer, sizeof(stringBuffer),
                     "%s.dev%d.sm%d.cta%d.wp%d",
                     CUDBG_SHNAME_UPRED, devIdx, smIdx, ctaIdx, warpIdx);

            /* Dump the uniform predicates buffer into the core file */
            res = cudbgCoredumpDumpBuffer(warpData->uniformPredicatesDump, 0,
                                          warpData->uniformPredicatesDumpSize, CUDBG_SHT_DEV_UPRED,
                                          warpTableShIndex, warpIdx, stringBuffer, NULL);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                         "Failed to dump uniform predicate buffer into core file\n");
        }

        /* Dump the lane table */
        res = cudbgCoredumpDumpLaneTable(warpData, warpTableShIndex, devIdx,
                                         smIdx, ctaIdx, warpIdx);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to dump lane table\n");

        itr = toolsListGetNext(itr);
        warpIdx++;
    }

    return res;
}

static CUDBGResult
cudbgCoredumpDumpCtaTable(CudbgCoredumpSmData *smData,
                          uint64_t smTableShIndex, uint32_t devIdx, uint32_t smIdx)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t ctaTableShIndex;
    tHashMapItr *itr;
    uint32_t ctaIdx = 0;
    CudbgCoredumpCTAData *ctaData;

    /* Pick a name */
    snprintf(stringBuffer, sizeof(stringBuffer), "%s.dev%d.sm%d",
             CUDBG_SHNAME_CTATABLE, devIdx, smIdx);

    /* Write the cta table out */
    res = cudbgCoredumpDumpTableFromMap(smData->ctaMap,
                                        offsetof(CudbgCoredumpCTAData, ctaTableEntry),
                                        sizeof(CudbgCTATableEntry), CUDBG_SHT_CTA_TABLE, smTableShIndex,
                                        smIdx, stringBuffer, &ctaTableShIndex);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to dump grid table entries\n");

    /* Dump the related sections */
    itr = toolsHashMapGetIterator(smData->ctaMap);
    while (itr != NULL) {
        ctaData = (CudbgCoredumpCTAData *)toolsHashMapGetEntry(itr);
        CUDBG_VERIFY(ctaData, CUDBG_ERROR_INTERNAL,
                     "Failed to get ctaData\n");

        /* Dump the shared memory section, if any */
        if (ctaData->smemDump) {
            /* Pick a name */
            snprintf(stringBuffer, sizeof(stringBuffer), "%s.dev%d.sm%d.cta%d",
                     CUDBG_SHNAME_SHARED, devIdx, smIdx, ctaIdx);

            /* Dump the smem buffer into the core file */
            res = cudbgCoredumpDumpBuffer(ctaData->smemDump, 0,
                                          ctaData->smemSize, CUDBG_SHT_SHARED_MEM,
                                          ctaTableShIndex, ctaIdx, stringBuffer, NULL);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                         "Failed to dump shared memory buffer into core file\n");
        }

        /* Dump the warp table */
        res = cudbgCoredumpDumpWarpTable(ctaData, ctaTableShIndex, devIdx,
                                         smIdx, ctaIdx);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to dump warp table\n");

        ctaIdx++;
        itr = toolsHashMapGetNext(smData->ctaMap, itr);
    }

    return res;
}

static CUDBGResult
cudbgCoredumpDumpSmTable(CudbgCoredumpDeviceData *deviceData,
                         uint64_t devTableShIndex, uint32_t devIdx)
{
    CUDBGResult res = CUDBG_SUCCESS;
    tListItr *itr;
    uint32_t smIdx = 0;
    CudbgCoredumpSmData *smData;
    uint64_t smTableShIndex;

    /* Pick a name */
    snprintf(stringBuffer, sizeof(stringBuffer), "%s.dev%d",
             CUDBG_SHNAME_SMTABLE, devIdx);

    /* Write the SM table out */
    res = cudbgCoredumpDumpTableFromList(deviceData->smList,
                                         offsetof(CudbgCoredumpSmData, smTableEntry),
                                         sizeof(CudbgSmTableEntry), CUDBG_SHT_SM_TABLE, devTableShIndex,
                                         devIdx, stringBuffer,
                                         &smTableShIndex);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to dump SM table entries\n");

    /* Dump the related sections */
    itr = toolsListGetIterator(deviceData->smList);
    while (itr != NULL) {
        smData = (CudbgCoredumpSmData *)toolsListGetElem(itr);
        CUDBG_VERIFY(smData, CUDBG_ERROR_INTERNAL,
                     "Failed to get smData\n");

        /* Dump the cta table */
        res = cudbgCoredumpDumpCtaTable(smData, smTableShIndex, devIdx, smIdx);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to dump CTA table\n");

        itr = toolsListGetNext(itr);
        smIdx++;
    }

    return res;
}

static CUDBGResult
cudbgCoredumpDumpModuleTable(CudbgCoredumpCtxData *ctxData,
                             uint64_t ctxTableShIndex, uint32_t devIdx, uint32_t ctxIdx)
{
    CUDBGResult res = CUDBG_SUCCESS;
    tListItr *itr;
    uint32_t modIdx = 0;
    CudbgCoredumpModuleData *modData;
    uint64_t modTableShIndex;

    /* Pick a name */
    snprintf(stringBuffer, sizeof(stringBuffer), "%s.dev%d.ctx%d",
             CUDBG_SHNAME_MODTABLE, devIdx, ctxIdx);

    /* Write the module table out */
    res = cudbgCoredumpDumpTableFromList(ctxData->moduleList,
                                         offsetof(CudbgCoredumpModuleData, moduleTableEntry),
                                         sizeof(CudbgModuleTableEntry), CUDBG_SHT_MOD_TABLE, ctxTableShIndex,
                                         ctxIdx, stringBuffer, &modTableShIndex);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to dump module table entries\n");

    /* Dump the related sections */
    itr = toolsListGetIterator(ctxData->moduleList);
    while (itr != NULL) {
        modData = (CudbgCoredumpModuleData *)toolsListGetElem(itr);
        CUDBG_VERIFY(modData, CUDBG_ERROR_INTERNAL,
                     "Failed to get modData\n");

        /* This can be NULL (lightweight corefiles) */
        if (modData->elfImage) {
            /* Pick a name for the non-relocated image dump */
            snprintf(stringBuffer, sizeof(stringBuffer),
                     "%s.dev%d.ctx%d",
                     CUDBG_SHNAME_ELFIMG, devIdx, ctxIdx);

            /* Dump the non-relocated elf image into the core file */
            res = cudbgCoredumpDumpBuffer(modData->elfImage, 0,
                                          modData->elfImageSize, CUDBG_SHT_ELF_IMG,
                                          modTableShIndex, modIdx, stringBuffer, NULL);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                         "Failed to dump non-relocated elf image into core file\n");
        }

        /* Pick a name for the relocated image dump */
        snprintf(stringBuffer, sizeof(stringBuffer),
                 "%s.dev%d.ctx%d",
                 CUDBG_SHNAME_RELFIMG, devIdx, ctxIdx);

        /* Dump the relocated elf image into the core file */
        res = cudbgCoredumpDumpBuffer(modData->relocatedElfImage, 0,
                                      modData->elfImageSize, CUDBG_SHT_RELF_IMG,
                                      modTableShIndex, modIdx, stringBuffer, NULL);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to dump relocated elf image into core file\n");

        itr = toolsListGetNext(itr);
        modIdx++;
    }

    return res;
}

static CUDBGResult
cudbgCoredumpDumpContextTable(CudbgCoredumpDeviceData *deviceData,
                              uint64_t devTableShIndex, uint32_t devIdx)
{
    CUDBGResult res = CUDBG_SUCCESS;
    tListItr *itr;
    uint32_t ctxIdx = 0;
    CudbgCoredumpCtxData *ctxData;
    uint64_t ctxTableShIndex;

    /* Pick a name */
    snprintf(stringBuffer, sizeof(stringBuffer), "%s.dev%d",
             CUDBG_SHNAME_CTXTABLE, devIdx);

    /* Write the context table out */
    res = cudbgCoredumpDumpTableFromList(deviceData->ctxList,
                                         offsetof(CudbgCoredumpCtxData, contextTableEntry),
                                         sizeof(CudbgContextTableEntry), CUDBG_SHT_CTX_TABLE, devTableShIndex,
                                         devIdx, stringBuffer, &ctxTableShIndex);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to dump context table entries\n");

    /* Dump the related sections */
    itr = toolsListGetIterator(deviceData->ctxList);
    while (itr != NULL) {
        ctxData = (CudbgCoredumpCtxData *)toolsListGetElem(itr);
        CUDBG_VERIFY(ctxData, CUDBG_ERROR_INTERNAL,
                     "Failed to get ctxData\n");

        /* Dump the module table */
        res = cudbgCoredumpDumpModuleTable(ctxData, ctxTableShIndex, devIdx, ctxIdx);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to dump module table\n");

        itr = toolsListGetNext(itr);
        ctxIdx++;
    }

    return res;
}

static CUDBGResult
cudbgCoredumpDumpDeviceTable(CudbgCoredumpData *coredumpData)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t devTableShIndex;
    CudbgCoredumpDeviceData *deviceData;
    tListItr *itr;
    uint32_t devIdx = 0;

    /* Write the device table out */
    res = cudbgCoredumpDumpTableFromList(coredumpData->deviceDataList,
                                         offsetof(CudbgCoredumpDeviceData, deviceTableEntry),
                                         sizeof(CudbgDeviceTableEntry), CUDBG_SHT_DEV_TABLE, 0, 0, CUDBG_SHNAME_DEVTABLE,
                                         &devTableShIndex);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to dump grid table entries\n");

    /* Dump all related sections */
    itr = toolsListGetIterator(coredumpData->deviceDataList);
    while (itr != NULL) {
        deviceData = (CudbgCoredumpDeviceData *)toolsListGetElem(itr);
        CUDBG_VERIFY(deviceData, CUDBG_ERROR_INTERNAL,
                     "Failed to get deviceData\n");

        /* Dump the context table */
        res = cudbgCoredumpDumpContextTable(deviceData, devTableShIndex, devIdx);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to dump context table\n");

        /* Dump the grid table */
        res = cudbgCoredumpDumpGridTable(deviceData, devTableShIndex, devIdx);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to dump grid table\n");

        /* Dump the SM table */
        res = cudbgCoredumpDumpSmTable(deviceData, devTableShIndex, devIdx);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to dump SM table\n");

        itr = toolsListGetNext(itr);
        devIdx++;
    }

    return res;
}

static CUDBGResult
cudbgCoredumpInitializeCoreFile(const char* name, CudbgCoredumpData *coredumpData)
{
    CUDBGResult res = CUDBG_SUCCESS;
    elf64FileHeader *efh;

    res = cudbgCoredumpOpenCoreFile(name);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Could not create core file\n");

    coredumpElfGlobals.efh = (elf64FileHeader *)malloc(sizeof(elf64FileHeader));
    CUDBG_VERIFY(coredumpElfGlobals.efh, CUDBG_ERROR_OS_RESOURCES,
                 "Failed to allocate memory\n");

    efh = coredumpElfGlobals.efh;

    efh->magic          = ELFMAGIC_LSB;
    efh->oclass         = ELFCLASS64;
    efh->data           = ELFDATA2LSB;
    efh->formatVersion  = 1;
    efh->abi            = ELFOSABI_CUDA;
    efh->abiVersion     = ELFOSABIV_LATEST;
    efh->type           = ET_CORE;
    efh->machine        = EM_CUDA;
    efh->version        = EV_CURRENT;
    efh->entry          = 0;
    efh->phoff          = 0;
    efh->flags          = 0;
    efh->ehsize         = sizeof(elf64FileHeader);
    efh->phentsize      = 0;
    efh->phnum          = 0;
    efh->shoff          = 0; /* Filled in later */
    efh->shentsize      = sizeof(elf64SectionHeader);
    efh->shnum          = 0; /* Filled in later */
    efh->shstrndx       = 0; /* Filled in later */

    /* Write out the partially filled header. The section header
     * offset/entrySize and the string table offset aren't available
     * yet, they will be patched into the header right at the end. */
    res = cudbgCoredumpWriteToCoreFile(efh, sizeof(elf64FileHeader));
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Could not write elf header\n");

    res = cudbgCoredumpCreateSectionHeaderTable();
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to create section header table\n");

    /* Track the generic stringTable */
    coredumpElfGlobals.stringTable = coredumpData->stringTable;

    /* Create the section header string table. */
    res = cudbgCoredumpCreateStringTable(&coredumpElfGlobals.shStringTable);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to create section header string table\n");

    return res;
}

static CUDBGResult
cudbgCoredumpFinalizeCoreFile(void)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t shStringTableShIndex = 0;
    uint64_t shTableFileOffset = 0;
    uint64_t shTableNumEntries = 0;
    elf64FileHeader *efh = coredumpElfGlobals.efh;

    /* Dump the generic string table. */
    res = cudbgCoredumpDumpStringTable(coredumpElfGlobals.stringTable,
                                       SHNAME_STRTAB, NULL);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to dump generic string table\n");

    /* Dump the section header string table */
    res = cudbgCoredumpDumpStringTable(coredumpElfGlobals.shStringTable,
                                       SHNAME_SHSTRTAB, &shStringTableShIndex);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to dump generic string table\n");

    /* Dump the section header table */
    res = cudbgCoredumpDumpSectionHeaderTable(&shStringTableShIndex,
                                              &shTableFileOffset,
                                              &shTableNumEntries);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to dump section header table\n");

    /* Patch the elf file header with the section header table offset and
     * the shStringTable section header index. */
    efh->shoff      = shTableFileOffset;
    efh->shnum      = (elfHalf)shTableNumEntries;
    efh->shstrndx   = (elfHalf)shStringTableShIndex;

    res = cudbgCoredumpRewindCoreFile();
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Could not rewind core file\n");

    res = cudbgCoredumpWriteToCoreFile(coredumpElfGlobals.efh,
                                       sizeof(elf64FileHeader));
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Could not write elf header\n");

    res = cudbgCoredumpCloseCoreFile();
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Could not close core file\n");

    return CUDBG_SUCCESS;
}

CUDBGResult
cudbgCoredumpCreateCoreFile(const char* name, CudbgCoredumpData *coredumpData)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(name && coredumpData, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    res = cudbgCoredumpInitializeCoreFile(name, coredumpData);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to initialize core file\n");

    /* Dump the memory sections */
    res = cudbgCoredumpDumpGlobalMemory(coredumpData);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                "Failed to dump global memory\n");

    /* Dump the remaining sections, starting with the device table */
    res = cudbgCoredumpDumpDeviceTable(coredumpData);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to dump device table\n");

    res = cudbgCoredumpFinalizeCoreFile();
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to finish creation the core file\n");

    return res;
}

