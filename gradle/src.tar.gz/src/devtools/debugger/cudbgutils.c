/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/*
 * Description:
 *
 *  Utility routines and variables used by all the debugger components
 *  of the CUDA driver.
 */


#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <cuda.h>
#include "cuos.h"
#include "cudbgutils.h"
#include "cudbgapi.h"
#include "halo_internal.h"
#include "halo_trace.h"

uint32_t cudbgEnableSyscallDebugging  = 0;
uint32_t cudbgEnableMemcheckDebugging = 0;
uint32_t cudbgEnableInternalDebugging = 0;
uint32_t cudbgEnableHiddenFunctionDebugging = 0;
uint32_t cudbgEnableInternalInsts     = 0;
#ifndef RELEASE

// XXX Default error injection threshold. This is somewhat arbitrary.
// We can fine tune this when testing error injection.
#define CUDBG_INJECT_ERROR_THRESHOLD_RANGE 150

static struct cudbgInjectError_st {
    uint32_t initialized;
    uint32_t errorType;
    uint32_t threshold;
    uint32_t count;
} cudbgInjectError;
#endif
static char cudbgTempPrefix[CUDBG_UTIL_TMP_BUF_SIZE];

static void cudbgMsgRulesCleanup(void);

//linear congruential random number generator with similar functionality to rand_r (no locking, takes state as argument)
static uint32_t
cudbgLCGRand32(uint32_t state)
{
    uint64_t x = state;
    x = (x * 22695477 + 1) % 4294967296;
    return (uint32_t)x;
}

static void
cudbgInjectErrorInit(void)
{
#ifndef RELEASE
// __TEMP_WAR__ Bug 200135016
#if !cuosOsIsHos()
    char errorTypeStr[CUOS_ENV_VAR_LENGTH];
    char errorThresholdStr[CUOS_ENV_VAR_LENGTH];
    if (!cudbgInjectError.initialized) {
        // CUDA_GDB_INJECT_ERROR_TYPE controls which type of error we inject.
        // Use 0 to inject any type randomly (because CUDBG_SUCCESS is 0)
        if (!cuosGetEnv("CUDA_GDB_INJECT_ERROR_TYPE", errorTypeStr, sizeof errorTypeStr)) {
            cudbgInjectError.errorType = atoi(errorTypeStr);
            cudbgInjectError.initialized = 1;
        }
        else
            cudbgInjectError.initialized = 0;

        // CUDA_GDB_INJECT_ERROR_THRESHOLD controls when it injects the error.
        // It does that when the count reaches the threshold.
        // If it's not specified, it's randomly picked from within the range of 0 and
        // CUDBG_INJECT_ERROR_THRESHOLD_RANGE
        if (!cuosGetEnv("CUDA_GDB_INJECT_ERROR_THRESHOLD", errorThresholdStr, sizeof errorThresholdStr)) {
            cudbgInjectError.threshold = atoi(errorThresholdStr);
        }
        else {
            //Note: time(time_t*) will surely not aquire locks if it's argument is NULL. If not, you're on your own.
            cudbgInjectError.threshold = cudbgLCGRand32((uint32_t)time(NULL)) % CUDBG_INJECT_ERROR_THRESHOLD_RANGE;
        }
        cudbgInjectError.count = 0;
    }
#endif // !cuosOsIsHos()
#endif
    return;
}

static void
cudbgSyscallDebugInit(void)
{
#ifndef RELEASE
    char debugSyscallsStr[CUOS_ENV_VAR_LENGTH];
    if (!cuosGetEnv("CUDA_GDB_DEBUG_SYSCALLS", debugSyscallsStr, sizeof debugSyscallsStr))
        cudbgEnableSyscallDebugging = 1;
#endif
    return;
}


static void
cudbgMemcheckDebugInit(void)
{
#ifndef RELEASE
    char debugMemchecksStr[CUOS_ENV_VAR_LENGTH];
    if (!cuosGetEnv("CUDA_GDB_DEBUG_MEMCHECK", debugMemchecksStr, sizeof debugMemchecksStr))
        cudbgEnableMemcheckDebugging = 1;
#endif
}

static void
cudbgInternalInstsInit(void)
{
#ifndef RELEASE
    /* The following environment variable is shared with
       the disassembler (when the disassembler shows
       internal instructions, so will the debugger). */
    char showInternalInstsStr[CUOS_ENV_VAR_LENGTH];
    if (!cuosGetEnv("NVIDIA_SHOW_INTERNAL_INSTS", showInternalInstsStr, sizeof showInternalInstsStr)) {
        cudbgEnableInternalInsts = 1;
    }
#endif
}

static void
cudbgHiddenFunctionDebugInit(void)
{
#ifndef RELEASE
    char debugHiddenFunctionStr[CUOS_ENV_VAR_LENGTH];
    if (!cuosGetEnv("CUDA_GDB_DEBUG_HIDDEN_FUNCTIONS", debugHiddenFunctionStr, sizeof debugHiddenFunctionStr))
        cudbgEnableHiddenFunctionDebugging = 1;
#endif
}

static void
cudbgInternalDebugInit(void)
{
#ifndef RELEASE
    char debugInternalsStr[CUOS_ENV_VAR_LENGTH];
    if (!cuosGetEnv("CUDA_GDB_DEBUG_INTERNAL", debugInternalsStr, sizeof debugInternalsStr)) {
        cudbgEnableInternalDebugging = 1;
        cudbgEnableMemcheckDebugging = 1;
        cudbgEnableSyscallDebugging  = 1;
        cudbgEnableHiddenFunctionDebugging = 1;
    }

    cudbgMemcheckDebugInit();
    cudbgSyscallDebugInit();
    cudbgHiddenFunctionDebugInit();
    cudbgInternalInstsInit();
#endif
}

static void
cudbgFindPrefix(const char* fileName, char prefix[6])
{
    *prefix = 0;

    if (!fileName)
        return;

#ifndef RELEASE
    if (strstr(fileName, "cudbgapi.c"))
        sprintf(prefix, "API");
    else if (strstr(fileName, "cudbgdriver.c"))
        sprintf(prefix, "DRV");
    else if (strstr(fileName, "cudbgtarget.c"))
        sprintf(prefix, "GTA");
    else if (strstr(fileName, "cudbgdispatcher.c"))
        sprintf(prefix, "DISP");
    else if (strstr(fileName, "cudbgpreemption.c"))
        sprintf(prefix, "PRMP");
    else if (strstr(fileName, "cudbgpipe.c"))
        sprintf(prefix, "PIPE");
    else if (strstr(fileName, "cudbgutils.c"))
        sprintf(prefix, "UTIL");
    else if (strstr(fileName, "rpcd.c"))
        sprintf(prefix, "RPCD");
    else if (strstr(fileName, "cudbgcoredump.c"))
        sprintf(prefix, "CDMP");
    else
        haloFindPrefix(fileName, prefix);
#endif

    return;
}

void
cudbgUtilsInit(void)
{
    haloTraceInit(cudbgFindPrefix);
    cudbgInjectErrorInit();
    cudbgInternalDebugInit();

    // Since we may have reattached, reset cudbgTempPrefix.
    memset(cudbgTempPrefix, 0, sizeof cudbgTempPrefix);
}

void
cudbgUtilsFinalize(void)
{
    memset(cudbgTempPrefix, 0, sizeof cudbgTempPrefix);
#ifndef RELEASE
    cudbgInjectError.initialized = 0;
    haloTraceFinalize();
#endif
}

bool
cudbgShouldInjectError(CUDBGResult res)
{
    bool inject = false;
#ifndef RELEASE
    // Don't inject error until initialized
    if (!cudbgInjectError.initialized)
        return false;
    if (res == CUDBG_SUCCESS)
        return false;
    // Inject the error when the error types match or when
    // CUDA_GDB_INJECT_ERROR_TYPE is 0
    if (res == cudbgInjectError.errorType || cudbgInjectError.errorType == 0) {
        if (cudbgInjectError.count == cudbgInjectError.threshold) {
            // Print out some info so we know how to repro.
            fprintf(stderr, "Injection point (count=%u, type=%u): ",
                    cudbgInjectError.count, cudbgInjectError.errorType);
            inject = true;
        }
        ++cudbgInjectError.count;
    }
#endif
    return inject;
}

const char*
cudbgGetTempPrefix(void)
{
    if (!cudbgTempPrefix[0]) {
        char tmpdir[CUOS_ENV_VAR_LENGTH] = {0};

        /* This must include the trailing slash */
        if (gpudbgGetApiClientPid()) {
            /* For CUDA 4.1+, we create a /proc like hierarchy under
               $TMPDIR/cuda-dbg/$PID/ . This folder contains all the
               per instance temp files etc*/
            if (cuosGetEnv("TMPDIR", tmpdir, sizeof tmpdir))
                snprintf(tmpdir, sizeof tmpdir,  "/tmp");

            /* Backwards compatibility */
            if (cudbgApiClientRevision < API_REVISION_4_2)
                snprintf(cudbgTempPrefix, sizeof(cudbgTempPrefix), "%s/cuda-dbg/%u/",
                         tmpdir, gpudbgGetApiClientPid());
            else
                snprintf(cudbgTempPrefix, sizeof(cudbgTempPrefix), "%s/cuda-dbg/%u/session%d/",
                         tmpdir, gpudbgGetApiClientPid(), cudbgSessionId);
        }
        else
            /* This is legacy behavior. For CUDA 4.0, the temporary
               files, such as communication pipes are located in /tmp
               and have a prefix of cuda-gdb.*/
            snprintf(cudbgTempPrefix, sizeof(cudbgTempPrefix), "/tmp/cuda-gdb.");
    }
    return cudbgTempPrefix;
}
