/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/*--------------------------------- Includes --------------------------------*/

#include "cudadebugger.h"
#include "cudbgdriver.h"
#include "cudbgpipe.h"
#include <sys/types.h>
// __TEMP_WAR__  No stat/fcntl support on HOS
#ifndef __hos__
#include <sys/stat.h>
#include <fcntl.h>
#endif
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <limits.h>
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()
#include <poll.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/time.h>
#endif
#include "cuos.h"



#ifndef SSIZE_MAX
#define SSIZE_MAX (LLONG_MAX)
#endif

#if cuosOsIsWindows()
#define DEFAULT_WRITE_READ_TIMEOUT_MILLISECONDS     INFINITE // milliseconds (move to infinite now)
#define PIPE_PREFIX_NAME_LENGTH                     64
#endif

/*------------------------------- Externs ----------------------------------*/

/* For triggering internal error breakpoints within the application */
extern void (*cudbgReportDriverInternalErrorPtr)(void);

/*------------------------------- Debug Trace ------------------------------*/
#include "cudbgutils.h"
#include "halo_trace.h"
#define CUDBG_PIPE_TRACE_LEVEL                    haloTraceLevel
#ifndef RELEASE
#define CUDBG_PIPE_TRACE(level, ...)             haloTrace(HALO_TRACE_DOMAIN_PIPE, HALO_TRACE_TYPE_FILE, level, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#define CUDBG_PIPE_TRACE_FUNCTION(level, ...)    haloTrace(HALO_TRACE_DOMAIN_PIPE, (HALO_TRACE_TYPE_FILE | HALO_TRACE_TYPE_FUNCTION), level, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#define CUDBG_PIPE_TRACE_LOCATION(level, ...)    haloTrace(HALO_TRACE_DOMAIN_PIPE, (HALO_TRACE_TYPE_FILE | HALO_TRACE_TYPE_LINE), level, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#define CUDBG_PIPE_TRACE_ELEMENT(level, ...)     haloTrace(HALO_TRACE_DOMAIN_PIPE, HALO_TRACE_TYPE_FILE, level, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#define CUDBG_PIPE_ERROR(...)                    haloTrace(HALO_TRACE_DOMAIN_PIPE, HALO_TRACE_TYPE_FILE, 0, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#else
#define CUDBG_PIPE_TRACE(level, ...)              ((void)0)
#define CUDBG_PIPE_TRACE_FUNCTION(level, ...)     ((void)0)
#define CUDBG_PIPE_TRACE_LOCATION(level, ...)     ((void)0)
#define CUDBG_PIPE_TRACE_ELEMENT(level, ...)      ((void)0)
#define CUDBG_PIPE_ERROR(...)                     ((void)0)
#endif

/* ERESTART_RESTARTBLOCK is Linux specific */
#if cuosOsIsLinux()
# define errnoIsRestartBlock(errno) ((errno) == ERESTART_RESTARTBLOCK)
#elif cuosOsIsQnx()
# define errnoIsRestartBlock(errno) (0)
#endif

static int64_t cudbgPipeReadFromSocket(cudbg_pipe_t *pipe, void *buf, uint64_t size);
static int64_t cudbgPipeWriteToSocket(cudbg_pipe_t *pipe, void *buf, uint64_t size);

/*----------------------------- Helper Routines ----------------------------*/

static CUDBGResult
cudbgInitializeEvent(cudbg_pipe_t *p)
{
    CUDBGResult res = CUDBG_SUCCESS;

#if cuosOsIsLinux() || cuosOsIsQnx()
    memset(&p->event, 0, sizeof(p->event));

    p->event.readFd = p->FD[CUDBG_PIPE_MODE_READ];
    p->event.writeFd = -1;
    p->event.createdByCuos = 0;

    return res;
#elif cuosOsIsApple()
    /* This event is signaled by the darwin event thread.
     * See cudbgdarwin.c for details. */
    memset(&p->event, 0, sizeof(p->event));

    if (cuosEventCreate(&p->event) != CUOS_SUCCESS)
        return CUDBG_ERROR_COMMUNICATION_FAILURE;

    return res;
#elif cuosOsIsWindows()
    int ret = CUOS_SUCCESS;

    CUDBG_VERIFY(p, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");
    if (CUDBG_PIPE_TYPE_NAMED_READ == p->type) {
        ret = cuosEventCreate(&p->event);
        if (ret != CUOS_SUCCESS) {
            res = CUDBG_ERROR_COMMUNICATION_FAILURE;
            goto done;
        }

        p->overlap[CUDBG_PIPE_MODE_READ] = (OVERLAPPED*)malloc(sizeof(OVERLAPPED));

        if (NULL == p->overlap[CUDBG_PIPE_MODE_READ]) {
            res = CUDBG_ERROR_OS_RESOURCES;
            goto done;
        }

        memset(p->overlap[CUDBG_PIPE_MODE_READ], 0, sizeof(OVERLAPPED));
        CloseHandle(p->event.hEvent);
        p->event.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

        ((OVERLAPPED*)p->overlap[CUDBG_PIPE_MODE_READ])->hEvent = p->event.hEvent;
    }
    else {
        p->overlap[CUDBG_PIPE_MODE_WRITE] = (OVERLAPPED*)malloc(sizeof(OVERLAPPED));

        if (NULL == p->overlap[CUDBG_PIPE_MODE_WRITE]) {
            res = CUDBG_ERROR_OS_RESOURCES;
            goto done;
        }

        memset(p->overlap[CUDBG_PIPE_MODE_WRITE], 0, sizeof(OVERLAPPED));
        ((OVERLAPPED*)p->overlap[CUDBG_PIPE_MODE_WRITE])->hEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
    }
done:
    return res;
#else
    return CUDBG_ERROR_COMMUNICATION_FAILURE;
#endif
    return res;
}

static bool
cudbgPipeWaitExists(cudbg_pipe_t *p, uint32_t timeout)
{
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()
    const uint32_t access_sleep_time = 500;
    uint32_t access_timeout_counter = 0;

    CUDBG_VERIFY(p, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    while(access(p->name, F_OK) == -1 && access_timeout_counter < timeout) {
        usleep(access_sleep_time);
        access_timeout_counter += access_sleep_time;
    }

    return access_timeout_counter < timeout;
#elif cuosOsIsWindows()
    BOOL waitResult = FALSE;
    DWORD startTime = GetTickCount();
    DWORD windowsTimeout = timeout;

    CUDBG_VERIFY(p, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    do
    {
        waitResult = WaitNamedPipe(p->name, windowsTimeout);
    } while (waitResult != TRUE && GetTickCount() - startTime < windowsTimeout);

   return waitResult == TRUE;
#endif
   return false;
}

static const char*
cudbgPipeGetPrefix(void)
{
#if cuosOsIsWindows()
    static char PipePrefixName[PIPE_PREFIX_NAME_LENGTH];

    if (0 == CUDBG_SESSION_ID) {
        CUDBG_ERROR("Session id (CUDBG_SESSION_ID) is 0. Pipe connection could be broken\n");
    }

    if (0 == CUDBG_APICLIENT_PID) {
        CUDBG_ERROR("Application id (CUDBG_APICLIENT_PID) is 0. Pipe connection could be broken\n");
    }

    snprintf(PipePrefixName, PIPE_PREFIX_NAME_LENGTH, "\\\\.\\pipe\\cuda_dbg.%d_%d", CUDBG_SESSION_ID, CUDBG_APICLIENT_PID);
    return PipePrefixName;
#endif

    return cudbgGetTempPrefix();
}

static CUDBGResult
cudbgPipePipe(cudbg_pipe_t *p)
{
    CUDBGResult res = CUDBG_SUCCESS;
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()
    if (pipe(p->FD) != 0) {
        CUDBG_ERROR("Pipe initialization failure (from=%u, to=%u, errno=%u)\n", p->from, p->to, errno);
        res = CUDBG_ERROR_COMMUNICATION_FAILURE;
        goto done;
    }
done:
#endif
    return res;
}

static CUDBGResult
cudbgPipeMkFifo(cudbg_pipe_t *pipe)
{
    CUDBGResult res = CUDBG_SUCCESS;
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()
    CUDBG_VERIFY(pipe != NULL && pipe->name != NULL, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in cudbgPipeMkFifo.\n");

    if (mkfifo(pipe->name, S_IRGRP | S_IWGRP | S_IRUSR | S_IWUSR) != 0 && errno != EEXIST) {
        CUDBG_ERROR("Pipe creation failure (from=%u, to=%u, file=%s, errno=%d)\n",
                    pipe->from, pipe->to, pipe->name, errno);
        res = CUDBG_ERROR_COMMUNICATION_FAILURE;
        goto done;
    }
done:
#endif
    return res;
}

static CUDBGResult
cudbgPipeCreateSocket(cudbg_pipe_t *pipe, cudbg_pipe_mode_t mode)
{
    CUDBGResult res = CUDBG_SUCCESS;
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()
    struct msghdr *msg;
    struct iovec *iov;
    struct sockaddr_un *sockAddr;
    int ret;

    CUDBG_VERIFY(pipe != NULL && pipe->name != NULL, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in %s.\n", __FUNCTION__);

    /* Open a Unix Domain datagram socket */
    pipe->FD[mode] = socket(AF_UNIX, SOCK_DGRAM, 0);
    if (pipe->FD[mode] == -1) {
        res = CUDBG_ERROR_COMMUNICATION_FAILURE;
        CUDBG_ERROR("Socket opening failure (from=%u, to=%u, mode=%u, file=%s, errno=%d): %s\n",
                    pipe->from, pipe->to, mode, pipe->name, errno, strerror(errno));
        goto done;
    }

    /* Set nonblocking mode on the socket */
    ret = fcntl(pipe->FD[mode], F_SETFL, O_NONBLOCK);
    if (ret < 0) {
        res = CUDBG_ERROR_UNKNOWN;
        CUDBG_ERROR("Failed to set socket to nonblocking %s\n", strerror(errno));
        goto done;
    }

    /* Message header */
    msg = (struct msghdr*)pipe->msg;
    CUDBG_VERIFY(msg != NULL, CUDBG_ERROR_INTERNAL, "UDS message was not allocated prior to creating socket!\n");

    /* Scatter-gather list */
    iov = (struct iovec *)calloc(1, sizeof *iov);
    if (!iov) {
        res = CUDBG_ERROR_OS_RESOURCES;
        CUDBG_ERROR("Failed to allocate memory\n");
        goto done;
    }
    /* The message buffer plugs in here */
    iov->iov_base = NULL;
    iov->iov_len = 0;

    /* Prepare the socket address */
    sockAddr = (struct sockaddr_un *)calloc(1, sizeof *sockAddr);
    if (!sockAddr) {
        res = CUDBG_ERROR_OS_RESOURCES;
        CUDBG_ERROR("Failed to allocate memory\n");
        goto done;
    }
    if (strlen(pipe->name) + 1 > sizeof(sockAddr->sun_path)) {
        res = CUDBG_ERROR_INVALID_ARGS;
        CUDBG_ERROR("Socket name is too long\n");
        goto done;
    }
    sockAddr->sun_family = AF_UNIX;
    strcpy(sockAddr->sun_path, pipe->name);

    CUDBG_VERIFY(pipe->cmsg != NULL, CUDBG_ERROR_INTERNAL, "Control message was not allocated prior to creating socket\n");

    pipe->read  = cudbgPipeReadFromSocket;
    pipe->write = cudbgPipeWriteToSocket;

    if (mode == CUDBG_PIPE_MODE_WRITE) {
        uint64_t sendBufferSize = 0;
        uint64_t recvBufferSize = 0;
        uint64_t size = 0;
        socklen_t sizeofSendVar = sizeof(sendBufferSize);
        socklen_t sizeofRecvVar = sizeof(recvBufferSize);
        /* Destination address */
        msg->msg_name = sockAddr;
        msg->msg_namelen = sizeof *sockAddr;

        /* Get the max allowed size of the send buffer.
         * It will be used for packet fragmentation later on. */
        ret = getsockopt(pipe->FD[CUDBG_PIPE_MODE_WRITE], SOL_SOCKET, SO_SNDBUF,
                         &sendBufferSize, &sizeofSendVar);
        if (ret < 0) {
            CUDBG_ERROR("Could not get max datagram size\n");
            return (CUDBGResult)ret;
        }
        /* Chop off the higher 32 bits, getsockopt() does not zero them out. */
        if ((size_t)sizeofSendVar < sizeof(uint64_t))
            sendBufferSize = (uint32_t)sendBufferSize;
        size = sendBufferSize;

#if cuosOsIsQnx()
        /* On QNX, messages have to fit in the receiving buffer, too. */
        ret = getsockopt(pipe->FD[CUDBG_PIPE_MODE_WRITE], SOL_SOCKET, SO_RCVBUF,
                         &recvBufferSize, &sizeofRecvVar);
        if (ret < 0) {
            CUDBG_ERROR("Could not get max datagram size\n");
            return (CUDBGResult)ret;
        }

        if ((size_t)sizeofRecvVar < sizeof(uint64_t))
            recvBufferSize = (uint32_t)recvBufferSize;

        if (recvBufferSize < size)
          size = recvBufferSize;

        /* This is terrible, but we don't know why this magical /= 2 is needed on QNX.
         * Quentin's guess is that it's related to the kernel reporting the value doubled:
         * http://elixir.free-electrons.com/linux/latest/source/net/core/sock.c#L770
         * It's even documented in the docs for socket(7), look for SO_RCVBUF.
         * This theory allows us to argue that we're dividing by two to get the real value,
         * and would make sense if it wasn't based on the implementation of a different OS.
         * There is no mention of the doubling in the QNX docs for getsockopt,
         * but communication over the pipes hangs without this line. */
        size /= 2;
#else
        /* unused, silence the warning */
        (void)recvBufferSize;
        (void)sizeofRecvVar;
#endif
        /* 32 bytes of the buffer are used up by the OS for metadata, be conservative */
        if (size > 100)
            size -= 100;

        pipe->maxSendBufferSize = size;
    }
    else {
        /* The receiver can get the name from the sender,
           but we don't need it. */
        msg->msg_name = NULL;
        msg->msg_namelen = 0;

        /* Bind the socket fd to its address */
        ret = bind(pipe->FD[mode], (struct sockaddr *)sockAddr, sizeof *sockAddr);
        if (ret < 0) {
            res = CUDBG_ERROR_UNKNOWN;
            CUDBG_ERROR("Failed to bind socket to address memory: %s\n",
                        strerror(errno));
            goto done;
        }

        /* The receiver needs to be able to receive a control buffer */
        msg->msg_control = pipe->cmsg;
        msg->msg_controllen = CUDBG_PIPE_CMSG_MAX_SIZE;
    }

    pipe->messagePreambleSize = sizeof(pipe->messageSize[mode]);

    msg->msg_iov = iov;
    msg->msg_iovlen = 1;        /* Use only 1 entry in the scatter-gather list */

done:
#endif
    return res;
}

static CUDBGResult
cudbgPipeUnlink(cudbg_pipe_t *pipe)
{
    CUDBGResult res = CUDBG_SUCCESS;
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()
    CUDBG_VERIFY(pipe != NULL && pipe->name != NULL, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in cudbgPipeUnlink.\n");

    /* not an error if file does not exist */
    if (unlink(pipe->name) != 0 && errno != ENOENT) {
        CUDBG_ERROR("Cannot unlink pipe (from=%u, to=%u, file=%s, errno=%d)\n",
                    pipe->from, pipe->to, pipe->name, errno);
        res = CUDBG_ERROR_COMMUNICATION_FAILURE;
        goto done;
    }
done:
#endif
    return res;
}

static CUDBGResult
cudbgPipeOpen(cudbg_pipe_t *pipe, cudbg_pipe_mode_t mode)
{
    CUDBGResult res = CUDBG_SUCCESS;

#if cuosOsIsQnx()
    // Initialize read pipe as read-write to avoid having it be always readable in select and poll
    static const int flags[CUDBG_PIPE_MODE_NUM] = { O_RDWR | O_NONBLOCK, O_WRONLY };
#elif cuosOsIsLinux() || cuosOsIsApple()
    static const int flags[CUDBG_PIPE_MODE_NUM] = { O_RDONLY | O_NONBLOCK, O_WRONLY };
#endif

#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()
    CUDBG_VERIFY(pipe != NULL && pipe->name != NULL, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in cudbgPipeOpen.\n");

    if (pipe->type == CUDBG_PIPE_TYPE_UDS_READ || pipe->type == CUDBG_PIPE_TYPE_UDS_WRITE)
        return cudbgPipeCreateSocket(pipe, mode);

    pipe->FD[mode] = open(pipe->name, flags[mode]);
    if (pipe->FD[mode] == -1) {
        res = CUDBG_ERROR_COMMUNICATION_FAILURE;
        CUDBG_ERROR("Pipe opening failure (from=%u, to=%u, mode=%u, file=%s, errno=%d)\n",
                    pipe->from, pipe->to, mode, pipe->name, errno);
        goto done;
    }
#elif cuosOsIsWindows()
    DWORD dwWaitResult = WAIT_OBJECT_0;
    DWORD dwLastError = 0;
    bool success = true;

    res = cudbgInitializeEvent(pipe);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Failed to create event. (from=%u, to=%u, mode=%u, file=%s, errno=%d)\n",
                    pipe->from, pipe->to, mode, pipe->name, errno);
        goto done;
    }

    if (CUDBG_PIPE_MODE_READ == mode) {
        pipe->hPipe[mode] = CreateNamedPipe(
            pipe->name,
            PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED,
            PIPE_READMODE_BYTE  | PIPE_WAIT,
            1, (DWORD)pipe->maxSendBufferSize, (DWORD)pipe->maxSendBufferSize,
            INFINITE, NULL);

        if (INVALID_HANDLE_VALUE != pipe->hPipe) {
            success = ConnectNamedPipe(pipe->hPipe[mode], (LPOVERLAPPED)pipe->overlap[mode]);
            dwLastError = GetLastError();

            /* See https://msdn.microsoft.com/en-us/library/windows/desktop/aa365146(v=vs.85).aspx
            * ERROR_PIPE_CONNECTED may be returned if client connects between call to CreateNamedPipe and ConnectNamedPipe
            */
            if (!success) {
                if (dwLastError == ERROR_PIPE_CONNECTED) {
                    CUDBG_PIPE_TRACE(40, "PID: %d ERROR_PIPE_CONNECTED - Read pipe connected to %s. Handle: 0x%x\n", GetCurrentProcessId(), pipe->name, pipe->hPipe[mode]);
                    SetEvent(((OVERLAPPED*)pipe->overlap[CUDBG_PIPE_MODE_READ])->hEvent);
                }
                else if (dwLastError == ERROR_IO_PENDING) {
                    CUDBG_PIPE_TRACE(40, "PID: %d ERROR_IO_PENDING - Read pipe connected to %s. Handle: 0x%x\n", GetCurrentProcessId(), pipe->name, pipe->hPipe[mode]);
                }
                else {
                    CUDBG_ERROR("Failed to connect to server side pipe. Error: %d\n", dwLastError);
                    return CUDBG_ERROR_COMMUNICATION_FAILURE;
                }
            }
            else
            {
               CUDBG_PIPE_TRACE(60, "PID: %d Read pipe connected to %s. Handle: 0x%x\n", GetCurrentProcessId(), pipe->name, pipe->hPipe[mode]);
            }
        }
    }
    else {
        /*
        Have to wait for ConnectNamedPipe on second process before write pipe open
        */
        if (FALSE == WaitNamedPipe(pipe->name, NMPWAIT_USE_DEFAULT_WAIT)) {
            CUDBG_ERROR("Named pipe was not open by other side. Pipe name: %s. Error: %d\n", pipe->name, GetLastError());

            return CUDBG_ERROR_COMMUNICATION_FAILURE;
        }

        pipe->hPipe[mode] = CreateFile(pipe->name, GENERIC_READ |  GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, NULL);

        if (INVALID_HANDLE_VALUE == pipe->hPipe[mode]) {
            CUDBG_ERROR("Failed to open client side pipe. Error: %d\n", GetLastError());

            return CUDBG_ERROR_COMMUNICATION_FAILURE;
        }
        else {
            ((OVERLAPPED*)pipe->overlap[mode])->hEvent = CreateEvent(NULL, FALSE, FALSE, NULL);

            if (INVALID_HANDLE_VALUE == ((OVERLAPPED*)pipe->overlap[mode])->hEvent) {
                CUDBG_ERROR("CreateEvent failed. Error: %d\n", GetLastError());

                return CUDBG_ERROR_COMMUNICATION_FAILURE;
            }

            CUDBG_PIPE_TRACE(60, "Write pipe connected to %s. Handle: 0x%x\n", pipe->name, pipe->hPipe[mode]);
        }
    }
#endif
done:
    return res;
}

static CUDBGResult
cudbgPipeClose(cudbg_pipe_t *pipe, cudbg_pipe_mode_t mode)
{
    CUDBGResult res = CUDBG_SUCCESS;
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()
    CUDBG_VERIFY(pipe, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in cudbgPipeClose.\n");

    if (close(pipe->FD[mode]) == -1) {
        res = CUDBG_ERROR_COMMUNICATION_FAILURE;
        CUDBG_ERROR("Pipe closing failure (from=%u, to=%u, read=%d, errno=%u)\n",
                    pipe->from, pipe->to, mode, errno);
        goto done;
    }
done:
#elif cuosOsIsWindows()
    LPOVERLAPPED pipeOverlappedStruct = (LPOVERLAPPED)pipe->overlap[mode];

    CUDBG_VERIFY(pipe, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in cudbgPipeClose.\n");
    
    if (CUDBG_PIPE_MODE_READ == mode) {
        DisconnectNamedPipe(pipe->hPipe[mode]);
    }

    if (INVALID_HANDLE_VALUE != pipe->hPipe[mode]) {
        CloseHandle(pipe->hPipe[mode]);
        pipe->hPipe[mode] = INVALID_HANDLE_VALUE;
    }

    if (NULL != pipeOverlappedStruct) {
        if (INVALID_HANDLE_VALUE != pipeOverlappedStruct->hEvent) {
            CloseHandle(pipeOverlappedStruct->hEvent);
            pipeOverlappedStruct->hEvent = INVALID_HANDLE_VALUE;
        }
    }
    CUDBG_PIPE_TRACE(60, "Pipe closed. Handle: 0x%x", pipe->hPipe[mode]);
#endif
    return res;
}

static CUDBGResult
cudbgPipeModeInitialized(cudbg_pipe_t *pipe, cudbg_pipe_mode_t mode)
{
    CUDBGResult res = CUDBG_SUCCESS;
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()
    CUDBG_VERIFY(pipe, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in cudbgPipeModeInitialized.\n");

    if (!(pipe->initialized[mode])) {
        res = CUDBG_ERROR_COMMUNICATION_FAILURE;
        CUDBG_ERROR("Pipes not initialized for access (from=%u, to=%u, mode=%u)\n",
                    pipe->from, pipe->to, mode);
        goto done;
    }
done:
#endif
    return res;
}

static void
cudbgPipeFreeBuffers(cudbg_pipe_t *pipe, cudbg_pipe_mode_t mode)
{
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()
    free(pipe->message[mode]);
    if (pipe->msg)
        free(pipe->msg);
    if (pipe->cmsg)
        free(pipe->cmsg);
    pipe->msg = NULL;
    pipe->cmsg = NULL;
    pipe->message[mode] = NULL;
    pipe->messageSize[mode] = 0;
#endif
}

static int64_t
cudbgPipeWriteToFifo(cudbg_pipe_t *pipe, void *buf, uint64_t size)
{
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()
    return write(pipe->FD[CUDBG_PIPE_MODE_WRITE], buf, size);
#elif cuosOsIsWindows()
    int32_t bytesWritten = 0;
    bool success = true;
    DWORD dwLastError = 0;
    DWORD dwStatus = 0;

    success = WriteFile(pipe->hPipe[CUDBG_PIPE_MODE_WRITE], buf, (DWORD)size, NULL, (LPOVERLAPPED)pipe->overlap[CUDBG_PIPE_MODE_WRITE]);
    /*
        We're not waiting for the completion of the write operation because there won't be a new write operation until we receive acknowledgement 
        for the previous write.This guarantees that the previous write operation is completed before a new one begins
    */

    bytesWritten = (DWORD)size;

    if (FALSE == success) {
        dwLastError = GetLastError();

        if (ERROR_IO_PENDING != dwLastError) {
            CUDBG_ERROR("Write to pipe failed Error: %d. Pipe name: %s, Buf: 0x%x, Size: %d. Handle: 0x%x. Event handle: 0x%x\n", dwLastError, pipe->name, buf, size, pipe->hPipe[CUDBG_PIPE_MODE_WRITE],
                ((LPOVERLAPPED)pipe->overlap[CUDBG_PIPE_MODE_WRITE])->hEvent);

            bytesWritten = -1;
        }
    }

    return bytesWritten;
#else
    return 0;
#endif
}

static int64_t
cudbgPipeWriteToSocket(cudbg_pipe_t *pipe, void *buf, uint64_t size)
{
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()
    struct msghdr *msg;
    struct iovec *iov;
    int64_t ret;

    msg = (struct msghdr *)pipe->msg;
    iov = msg->msg_iov;
    iov->iov_base = buf;
    iov->iov_len = size;

    if (pipe->maxSendBufferSize < size)
        iov->iov_len = pipe->maxSendBufferSize;

    ret = sendmsg(pipe->FD[CUDBG_PIPE_MODE_WRITE], msg, 0);

    return ret;
#else
    return 0;
#endif
}

static int64_t
cudbgPipeReadFromFifo(cudbg_pipe_t *pipe, void *buf, uint64_t size)
{
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()
    return read(pipe->FD[CUDBG_PIPE_MODE_READ], buf, size);
#elif cuosOsIsWindows()
    int32_t bytesRead = 0;
    bool success = true;
    DWORD dwLastError = 0;
    DWORD dwStatus = 0;
    int timeout = DEFAULT_WRITE_READ_TIMEOUT_MILLISECONDS;

    cudbgPipeWaitForData(pipe, &timeout);

    ResetEvent(((OVERLAPPED*)pipe->overlap[CUDBG_PIPE_MODE_READ])->hEvent);

    success = ReadFile(pipe->hPipe[CUDBG_PIPE_MODE_READ], buf, (DWORD)size, NULL, (LPOVERLAPPED)pipe->overlap[CUDBG_PIPE_MODE_READ]);

    if (FALSE == success) {
        dwLastError = GetLastError();

        if (ERROR_IO_PENDING == dwLastError) {
            dwStatus = WaitForSingleObject(((OVERLAPPED*)pipe->overlap[CUDBG_PIPE_MODE_READ])->hEvent, DEFAULT_WRITE_READ_TIMEOUT_MILLISECONDS);

            if (WAIT_OBJECT_0 == dwStatus) {
                success = GetOverlappedResult(pipe->hPipe[CUDBG_PIPE_MODE_READ], (LPOVERLAPPED)pipe->overlap[CUDBG_PIPE_MODE_READ], (DWORD*)&bytesRead, TRUE);

                if (FALSE == success) {
                    CUDBG_ERROR("Read to pipe failed Error: %d. Handle: 0x%x\n", dwLastError, pipe->hPipe[CUDBG_PIPE_MODE_READ]);
                    bytesRead = -1;
                }
            }
            else {
                CUDBG_ERROR("Read pipe operation timeout. Handle: 0x%x\n", pipe->hPipe[CUDBG_PIPE_MODE_READ]);
                bytesRead = -1;
            }
        }
        else {
            CUDBG_ERROR("Read to pipe failed Error: %d. Handle: 0x%x\n", dwLastError, pipe->hPipe[CUDBG_PIPE_MODE_READ]);

            bytesRead = -1;
        }
    }
    else {
        bytesRead = (int32_t)size;
    }

    return bytesRead;
#else
    return 0;
#endif
}

static int64_t
cudbgPipeReadFromSocket(cudbg_pipe_t *pipe, void *buf, uint64_t size)
{
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()
    struct iovec *iov;
    struct msghdr *msg;
    int64_t ret = 0;

    msg = (struct msghdr *)pipe->msg;
    iov = msg->msg_iov;
    iov->iov_base = buf;
    iov->iov_len = size;

    /* With datagram sockets, the full message is delivered at once. If the
       reader's buffer is insufficiently sized, the remaining bytes are
       discarded, unlike stream sockets and pipes. To avoid this, we use
       MSG_PEEK to determine the message size without actually reading the
       full message, and resize the receiver's buffer if necessary. */
    if (pipe->read_state == CUDBG_PIPE_MSG_READ_STATE_PREAMBLE) {
#if !cuosOsIsQnx()
        /* Surprise: peeking at the control message causes a file descriptor to be transferred!
           That would result in leaking the FD, so don't accept control messages with MSG_PEEK. */
        msg->msg_controllen = 0;
#else
        /* WAR for bug 2411146: QNX doesn't handle recvmsg(MSG_PEEK) with msg_controllen=0
         * correctly, so just leak the FD here until that bug is fixed. It's not a problem
         * because on QNX we don't use FDs to transfer memory handles, so we'll leak only
         * a handful of FDs and stay well under the limit of 1024 FDs per process. */
        msg->msg_controllen = CUDBG_PIPE_CMSG_MAX_SIZE;
#endif
        ret = recvmsg(pipe->FD[CUDBG_PIPE_MODE_READ], msg, MSG_PEEK);
    }
    else {
        /* The control buffer is statically sized, msg_controllen is an in/out
           parameter which gets set to the received control buffer size. */
        msg->msg_controllen = CUDBG_PIPE_CMSG_MAX_SIZE;
        ret = recvmsg(pipe->FD[CUDBG_PIPE_MODE_READ], msg, 0);
    }
    return ret;
#else
    return 0;
#endif
}

/*----------------------------Exported Routines ----------------------------*/

CUDBGResult
cudbgPipeInitialize(cudbg_pipe_t *pipe,
                    cudbg_pipe_type_t type,
                    cudbg_pipe_endpoint_t from,
                    cudbg_pipe_endpoint_t to)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t i;
    bool initialize_message[CUDBG_PIPE_MODE_NUM] = {false, false};
#if cuosOsIsWindows()
    char pipe_name[256];
    char internal_pipe_uniq_name[256];
#endif

    CUDBG_VERIFY(pipe, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in cudbgPipeInitialize.\n");

    /* check pipe is not already initialized */
    CUDBG_VERIFY(pipe->type == CUDBG_PIPE_TYPE_NONE,
                 CUDBG_ERROR_COMMUNICATION_FAILURE,
                 "Pipe already initialized (from=%u, to=%u)\n", from, to);

    /* set up default pipe parameters */
    pipe->type = type;
    pipe->from = from;
    pipe->to = to;
    pipe->read_state = CUDBG_PIPE_MSG_READ_STATE_INIT;
#if !cuosOsIsWindows()
    pipe->name[CUDBG_PIPE_MODE_READ] = 0;
#else
    memset(&pipe_name, 0, 256);
    if (0 != strlen(pipe->name))
        strcpy(pipe_name, pipe->name);
    else
        memset(&pipe->name[0], 0, 256);
#endif
    pipe->bytesRead = 0;
    pipe->messagePreambleSize = 0;
    pipe->read = cudbgPipeReadFromFifo;
    pipe->write = cudbgPipeWriteToFifo;

#if !cuosOsIsWindows()
    for (i = 0; i < CUDBG_PIPE_MODE_NUM; i++) {
        pipe->FD[i] = -1;
        pipe->initialized[i] = false;
        cudbgPipeFreeBuffers(pipe, (cudbg_pipe_mode_t)i);
    }
#endif

    pipe->pendingFree = false;

    /* open the pipe(s) and build list of remaining actions */
    switch (type) {

    case CUDBG_PIPE_TYPE_ANONYMOUS:
#if cuosOsIsWindows()
        _itoa(cuosProcessId(), internal_pipe_uniq_name, 10);
        strcpy(pipe->name, internal_pipe_uniq_name);

        pipe->type = CUDBG_PIPE_TYPE_NONE;
        if ((res = cudbgPipeInitialize(pipe,
            CUDBG_PIPE_TYPE_NAMED_READ,
            from,
            to)))
            goto done;

        strcpy(pipe->name, internal_pipe_uniq_name);
        pipe->type = CUDBG_PIPE_TYPE_NONE;

        if ((res = cudbgPipeInitialize(pipe,
            CUDBG_PIPE_TYPE_NAMED_WRITE,
            from,
            to)))
            goto done;

        pipe->initialized[CUDBG_PIPE_MODE_READ] = true;
#else
        if ((res = cudbgPipePipe(pipe)))
            goto done;

        pipe->initialized[CUDBG_PIPE_MODE_READ] = pipe->initialized[CUDBG_PIPE_MODE_WRITE] = true;
#endif

        initialize_message[CUDBG_PIPE_MODE_READ] = initialize_message[CUDBG_PIPE_MODE_WRITE] = true;
        break;
    case CUDBG_PIPE_TYPE_NAMED_READ:
        snprintf(pipe->name, sizeof(pipe->name),
                 "%spipe.%d.%d", cudbgPipeGetPrefix(), from, to);

#if cuosOsIsWindows()
        if (0 != strlen(pipe_name)) {
            strcat(pipe->name, pipe_name);
        }
#endif

        if ((res = cudbgPipeMkFifo(pipe)))
            goto done;

        if ((res = cudbgPipeOpen(pipe, CUDBG_PIPE_MODE_READ)))
            goto done;

        pipe->initialized[CUDBG_PIPE_MODE_READ] = true;
        initialize_message[CUDBG_PIPE_MODE_READ] = true;
        break;
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()
    case CUDBG_PIPE_TYPE_UDS_READ:
        /* sockets are full-duplex, but we pretend here that they have separate read/write
           ends since the cudbgpipe framework is fifo centric. */
        snprintf(pipe->name, sizeof(pipe->name),
                 "%spipe.%d.%d", cudbgPipeGetPrefix(), from, to);

        /* Initialize internal data structures for UDS read socket */
        pipe->msg = (struct msghdr *)calloc(1, sizeof(struct msghdr));
        if (!pipe->msg) {
            res = CUDBG_ERROR_OS_RESOURCES;
            CUDBG_ERROR("Memory allocation failure\n");
            goto done;
        }

        pipe->cmsg = calloc(1,CUDBG_PIPE_CMSG_MAX_SIZE);
        if (!pipe->cmsg) {
            res = CUDBG_ERROR_OS_RESOURCES;
            CUDBG_ERROR("Memory allocation failure\n");
            goto done;
        }

        if ((res = cudbgPipeOpen(pipe, CUDBG_PIPE_MODE_READ)))
            goto done;

        pipe->initialized[CUDBG_PIPE_MODE_READ] = true;
        initialize_message[CUDBG_PIPE_MODE_READ] = true;
        break;

    case CUDBG_PIPE_TYPE_UDS_WRITE:
        /* Initialize internal data structures for UDS write socket */
        pipe->msg = (struct msghdr *)calloc(1, sizeof(struct msghdr));
        if (!pipe->msg) {
            res = CUDBG_ERROR_OS_RESOURCES;
            CUDBG_ERROR("Memory allocation failure\n");
            goto done;
        }

        pipe->cmsg = calloc(1, CUDBG_PIPE_CMSG_MAX_SIZE);
        if (!pipe->cmsg) {
            res = CUDBG_ERROR_OS_RESOURCES;
            CUDBG_ERROR("Memory allocation failure\n");
            goto done;
        }

        /* Continue on to initialize rest of pipe */
#endif

    case CUDBG_PIPE_TYPE_NAMED_WRITE:
        snprintf(pipe->name, sizeof(pipe->name),
                 "%spipe.%d.%d", cudbgPipeGetPrefix(), from, to);

#if cuosOsIsWindows()
        if (0 != strlen(pipe_name)) {
            strcat(pipe->name, pipe_name);
        }
#endif

        /* write sockets or named pipes are initialized at the first actual write to avoid deadlocks */
        initialize_message[CUDBG_PIPE_MODE_WRITE] = true;
        break;

    default:
        CUDBG_PIPE_TRACE_FUNCTION(0, "Unexpected pipe type value (type=%u)\n", type);
        res = CUDBG_ERROR_INTERNAL;
        goto done;
    }

    /* set up message handling parameters */
    for (i = 0; i < CUDBG_PIPE_MODE_NUM; i++)
        if (initialize_message[i]) {
            pipe->messageSize[i] = sizeof(pipe->messageSize[i]);
            pipe->message[i] = (char *)malloc((size_t)pipe->messageSize[i]);
        }
    /* Finally, create the event object we wait on */
#if !cuosOsIsWindows()
    if ((res = cudbgInitializeEvent(pipe)))
        goto done;
#endif
done:
    return res;
}

CUDBGResult
cudbgPipeReset(cudbg_pipe_t *pipe)
{
    CUDBGResult res = CUDBG_SUCCESS;
    bool close_pipe[CUDBG_PIPE_MODE_NUM] = {false, false};
    bool unlink_pipe = false;
    int32_t mode;

    CUDBG_VERIFY(pipe, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in cudbgPipeReset.\n");

    /* check pipe is initialized */
    if (pipe->type == CUDBG_PIPE_TYPE_NONE) {
        CUDBG_PIPE_TRACE_FUNCTION(5, "Multiple attempt to close the pipe.\n");
        res = CUDBG_SUCCESS;
        goto done;
    }

    /* build list of actions */
    switch (pipe->type) {
    case CUDBG_PIPE_TYPE_ANONYMOUS:
        close_pipe[CUDBG_PIPE_MODE_READ] = true;
        close_pipe[CUDBG_PIPE_MODE_WRITE] = true;
        break;
    case CUDBG_PIPE_TYPE_NAMED_READ:
    case CUDBG_PIPE_TYPE_UDS_READ:
        close_pipe[CUDBG_PIPE_MODE_READ]= true;
#if cuosOsIsWindows()
        close_pipe[CUDBG_PIPE_MODE_WRITE] = true;
#endif
        unlink_pipe = true;
        break;
    case CUDBG_PIPE_TYPE_NAMED_WRITE:
    case CUDBG_PIPE_TYPE_UDS_WRITE:
        close_pipe[CUDBG_PIPE_MODE_WRITE] = true;
#if cuosOsIsWindows()
        close_pipe[CUDBG_PIPE_MODE_READ] = true;
#endif
        unlink_pipe = true;
        break;
    default:
        CUDBG_PIPE_TRACE_FUNCTION(0, "Unexpected pipe type value (type=%u)\n", pipe->type);
        res = CUDBG_ERROR_INTERNAL;
        goto done;
    }

    /* close pipe (ignore errors) */
    for (mode = 0; mode < CUDBG_PIPE_MODE_NUM; mode++)
        if (close_pipe[mode] && pipe->initialized[mode])
            cudbgPipeClose(pipe, (cudbg_pipe_mode_t)mode);

    /* delete named pipe (ignore errors) */
    if (unlink_pipe)
        cudbgPipeUnlink(pipe);

    /* reset pipe parameters */
    pipe->type = CUDBG_PIPE_TYPE_NONE;
    pipe->from = CUDBG_PIPE_ENDPOINT_NONE;
    pipe->to = CUDBG_PIPE_ENDPOINT_NONE;
    pipe->name[CUDBG_PIPE_MODE_READ] = 0;
    for (mode = 0; mode < CUDBG_PIPE_MODE_NUM; mode++) {
        pipe->FD[mode] = -1;
        pipe->initialized[mode] = false;
    }

    /* if the pipe gets initialized again before it is
       finalized (due to a detach + reattach), we must
       remember to free the payload. */
    pipe->pendingFree = true;
done:
    return res;
}

CUDBGResult
cudbgPipeFinalize(cudbg_pipe_t *pipe)
{
    CUDBGResult res = CUDBG_SUCCESS;
    int32_t mode;

    if ((res = cudbgPipeReset(pipe)) != CUDBG_SUCCESS)
        return res;

    for (mode = 0; mode < CUDBG_PIPE_MODE_NUM; mode++)
        cudbgPipeFreeBuffers(pipe, (cudbg_pipe_mode_t)mode);

    pipe->pendingFree = false;

    return res;
}

CUDBGResult
cudbgPipeBlockingRead(cudbg_pipe_t *pipe, void* buf, uint64_t count, bool *eof)
{
    CUDBGResult res = CUDBG_SUCCESS;
    int64_t readCount = 0;
    uint64_t offset = 0;

    CUDBG_VERIFY((pipe && buf && eof && count < SSIZE_MAX),
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments in cudbgPipeBlockingRead.\n");

    /* check pipe is initialized */
    if ((res = cudbgPipeModeInitialized(pipe, CUDBG_PIPE_MODE_READ)))
        goto done;

    /* do the read. Close pipe if EOF reached. */
    *eof = false;
    for (offset = 0; offset < count; offset += readCount) {
        readCount = pipe->read(pipe, (char*)buf + offset, count - offset);
        if (readCount == 0) {
            *eof = true;
            res = cudbgPipeFinalize(pipe);
            goto done;
        }
        if (readCount < 0) {
            if (errno != EAGAIN && errno != EINTR) {
                CUDBG_ERROR("Pipe read error (from=%u, to=%u, count=%u, offset=%u, errno=%d)\n",
                            pipe->from, pipe->to, count, offset, errno);
                res = CUDBG_ERROR_COMMUNICATION_FAILURE;
                goto done;
            }
            readCount = 0;
        }
    }
done:
    return res;
}

CUDBGResult
cudbgPipeRead(cudbg_pipe_t *pipe, void* buf, uint64_t count, bool *eof, bool *retry)
{
    CUDBGResult res = CUDBG_SUCCESS;
    int64_t readCount = 0;
    uint64_t offset = 0;

    CUDBG_VERIFY((pipe && buf && eof && retry && count < SSIZE_MAX),
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments in cudbgPipeRead.\n");

    /* check pipe is initialized */
    if ((res = cudbgPipeModeInitialized(pipe, CUDBG_PIPE_MODE_READ)))
        goto done;

    /* do the read. Close pipe if EOF reached. */
    *eof = false;
    for (offset = pipe->bytesRead; offset < count; offset += readCount) {
        readCount = pipe->read(pipe, (char*)buf + offset, count - offset);

        if (readCount == 0) {
            *eof = true;
            res = cudbgPipeFinalize(pipe);
            goto done;
        }
        if (readCount < 0) {
            if (errno != EAGAIN && errno != EINTR) {
                CUDBG_ERROR("Pipe read error (from=%u, to=%u, count=%u, offset=%u, errno=%d)\n",
                            pipe->from, pipe->to, count, offset, errno);
                res = CUDBG_ERROR_COMMUNICATION_FAILURE;
                goto done;
            }

            /* we need to retry later.  Save off the current offset as
               the number of bytes read and indicate we need to retry. */
            CUDBG_PIPE_TRACE_FUNCTION(100, "Pipe read returned %d and errno %d (EAGAIN or EINTR), leaving function\n", readCount, errno);
            pipe->bytesRead = offset;
            *retry = true;
            res = CUDBG_SUCCESS;
            goto done;
        }
    }

done:

#if cuosOsIsWindows()
    /*
    Have to init read operation on pipe for set overlapped pipe event to signaled state on new data.
    */
    ResetEvent(pipe->event.hEvent);
    ReadFile(pipe->hPipe[CUDBG_PIPE_MODE_READ], NULL, 0, NULL, (LPOVERLAPPED)pipe->overlap[CUDBG_PIPE_MODE_READ]);
#endif
    return res;
}

CUDBGResult
cudbgPipeWrite(cudbg_pipe_t *pipe, void *buf, uint64_t count)
{
    CUDBGResult res = CUDBG_SUCCESS;
#if cuosOsIsWindows()
    const uint32_t accessTimeoutSeconds = 30000; // 30 seconds
#else
    const uint32_t accessTimeoutSeconds = 30000000; // 30 seconds
#endif

    int64_t writeCount = 0;
    uint64_t offset = 0;

    CUDBG_VERIFY((pipe && buf && count < SSIZE_MAX),
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments in cudbgPipeWrite.\n");

    /* initialize named write pipe if not done already (at the last
       second to avoid deadlocks). The pipe can then be deleted to
       avoid hanging if reused by some other process. */
    if ((pipe->type == CUDBG_PIPE_TYPE_NAMED_WRITE || pipe->type == CUDBG_PIPE_TYPE_UDS_WRITE)
        && !pipe->initialized[CUDBG_PIPE_MODE_WRITE]) {
        /* Need to wait until the pipe is initialized by the other side.
             (1) Without RPCD, this is always completed prior to getting to this point.
             (2) With RPCD, this is timing dependent as the appplication may reach this
                 point before RPCD completed initialization.  */
        if (!cudbgPipeWaitExists(pipe, accessTimeoutSeconds)) {
            CUDBG_ERROR("Pipe write couldn't access file %s\n", pipe->name);
            res = CUDBG_ERROR_COMMUNICATION_FAILURE;

            /* Error handling here is special, as the pipe routines are
               utilized by a variety of processes and threads.  If the
               application being debugged is waiting here (in the cuda
               driver's process space), we must trigger an error breakpoint */
            if (!gpudbgDebuggerProcess())
                CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_CUDBGPIPE_C, res, CUDBG_ERROR_TYPE_CUDBG);

            /* If a client resumes, the error is returned by this routine in 'res' */
            goto done;
        }
        if ((res = cudbgPipeOpen(pipe, CUDBG_PIPE_MODE_WRITE)))
            goto done;
        /* Datagram sockets are connectionless so should not be unlinked. */
        if (pipe->type != CUDBG_PIPE_TYPE_UDS_WRITE)
            if ((res = cudbgPipeUnlink(pipe)))
                goto done;
        pipe->initialized[CUDBG_PIPE_MODE_WRITE] = true;
    }

    /* check pipe is initialized */
    if ((res = cudbgPipeModeInitialized(pipe, CUDBG_PIPE_MODE_WRITE)))
        goto done;

    /* do the write */
    for (offset = 0, writeCount = 0; offset < count; offset += writeCount) {
        writeCount = pipe->write(pipe, (char*)buf + offset, count - offset);

        if (writeCount < 0) {
            /* ENOBUFS indicates transient congestion in OS buffers */
            if (errno != EAGAIN && errno != EINTR && errno != ENOBUFS) {
                res = CUDBG_ERROR_COMMUNICATION_FAILURE;
                CUDBG_ERROR("Pipe write error (from=%u, to=%u, count=%u, offset=%u, errno(%d): %s)\n",
                            pipe->from, pipe->to, count, offset, errno, strerror(errno));
                goto done;
            }
            writeCount = 0;
        }
    }
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()
    /* Reset the control message fields. If a new control message needs to be
       sent later, the length will be setup again. If this isn't done, Linux
       and Mac OSs complain in different ways. */
    if (pipe->type == CUDBG_PIPE_TYPE_UDS_WRITE) {
        struct msghdr *msg = (struct msghdr *)pipe->msg;
        msg->msg_control = NULL;
        msg->msg_controllen = 0;
    }
#endif
done:
    return res;
}

CUDBGResult
cudbgPipeWaitForData(cudbg_pipe_t *pipe, int *timeout)
{
    CUDBGResult res = CUDBG_SUCCESS;
#if cuosOsIsWindows()
    cuosEvent* events[1] = { 0 };
    int triggered = -1, ret = CUOS_SUCCESS;
    DWORD dwLastError = 0;

    CUDBG_VERIFY(pipe, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in cudbgPipeWaitForData.\n");

    if ((res = cudbgPipeModeInitialized(pipe, CUDBG_PIPE_MODE_READ))) {
        goto done;
    }

    /*
    For still not connecteded pipe have to wait for connection.
    */
    do
    {
        if (!ReadFile(pipe->hPipe[CUDBG_PIPE_MODE_READ], NULL, 0, NULL, (LPOVERLAPPED)pipe->overlap[CUDBG_PIPE_MODE_READ])) {
            dwLastError = GetLastError();
        }
        else {
            goto done;
        }
    } while (dwLastError == ERROR_PIPE_LISTENING);

    if (dwLastError == ERROR_IO_PENDING) {

        /*Now that read request is in a pending state, actually wait for the data to arrive via the event */

        events[0] = &pipe->event;
        ret = cuosEventWaitMultiple(events, 1, &triggered, 1, timeout ? *timeout : CUOS_INFINITE_TIMEOUT);
        if (ret < 1) {
            CUDBG_ERROR("Failed to wait for data\n");
            res = CUDBG_ERROR_COMMUNICATION_FAILURE;
            goto done;
        }
    } 
    else {
        CUDBG_ERROR("Pipe waiting data error. Error: %d\n", dwLastError);
        res = CUDBG_ERROR_COMMUNICATION_FAILURE;
        goto done;
    } 

done:
#elif cuosOsIsLinux() || cuosOsIsQnx()
    int ret;
    struct pollfd pollfdStruct;
    int timeoutMs = 0;
    int revents;

    CUDBG_VERIFY(pipe, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in cudbgPipeWaitForData.\n");

    /* check pipe is initialized */
    if ((res = cudbgPipeModeInitialized(pipe, CUDBG_PIPE_MODE_READ)))
        goto done;

    /* wait for data to be available for reading */
    pollfdStruct.fd = pipe->FD[CUDBG_PIPE_MODE_READ];
    pollfdStruct.events = POLLIN;
    pollfdStruct.revents = 0;

    do {
        /* Block if timeout == NULL */
        if (timeout != NULL)
            timeoutMs = *timeout;
        else
            timeoutMs = -1;

        ret = poll(&pollfdStruct, 1, timeoutMs);
    }
    while (ret == -1 && (errno == EINTR || errnoIsRestartBlock(errno)));

    if (ret == -1) {
        CUDBG_ERROR("poll() error (from=%u, to=%u, errno=%u)\n", pipe->from, pipe->to, errno);
        res =  CUDBG_ERROR_COMMUNICATION_FAILURE;
        goto done;
    }

    revents = pollfdStruct.revents;

    if (revents != 0 && !(revents & POLLIN)) {
        res = CUDBG_ERROR_COMMUNICATION_FAILURE;
        CUDBG_ERROR("Pipe error raised during poll() (from=%u, to=%u, revents=%u)\n",
                    pipe->from, pipe->to, revents);
        goto done;
    }
done:
#endif
#if cuosOsIsApple()
    struct timeval tv;
    int ret;
    fd_set rfds, efds;

    CUDBG_VERIFY(pipe, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in cudbgPipeWaitForData.\n");

    /* check pipe is initialized */
    res = cudbgPipeModeInitialized(pipe, CUDBG_PIPE_MODE_READ);
    if (res != CUDBG_SUCCESS)
        return res;

    /* set up tv and bit masks for select() */
    FD_ZERO(&rfds);
    FD_ZERO(&efds);
    FD_SET(pipe->FD[CUDBG_PIPE_MODE_READ], &rfds);
    FD_SET(pipe->FD[CUDBG_PIPE_MODE_READ], &efds);
    if (timeout) {
        tv.tv_sec = *timeout / 1000;
        tv.tv_usec = (*timeout % 1000) * 1000;
    }

    /* wait for data using select() */
    do {
       ret = select(pipe->FD[CUDBG_PIPE_MODE_READ] + 1, &rfds, NULL, &efds, timeout ? &tv : NULL);
    } while (ret == -1 && errno == EINTR);

    if (ret == -1) {
        CUDBG_ERROR("select() error (from=%u, to=%u, errno=%u)\n", pipe->from, pipe->to, errno);
        return CUDBG_ERROR_COMMUNICATION_FAILURE;
    }

    if (FD_ISSET (pipe->FD[CUDBG_PIPE_MODE_READ], &efds)) {
        CUDBG_ERROR("Pipe error raised during select() (from=%u, to=%u, errno=%u)\n",
                    pipe->from, pipe->to, errno);
        return CUDBG_ERROR_COMMUNICATION_FAILURE;
    }
#endif
    return res;
}

CUDBGResult
cudbgPipeMessageAppend(cudbg_pipe_t *pipe, void *obj, uint64_t objSize)
{
    CUDBGResult res = CUDBG_SUCCESS;
    char    *msg;
    uint64_t msgSize;

    CUDBG_VERIFY((pipe && obj && objSize > 0),
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments in cudbgPipeMessageAppend.\n");

    /* allocate space for the new object and the message size if not done yet */
    msgSize = pipe->messageSize[CUDBG_PIPE_MODE_WRITE] + objSize;
    if (!(msg = (char *)realloc(pipe->message[CUDBG_PIPE_MODE_WRITE], (size_t)msgSize))) {
        CUDBG_ERROR("Memory allocation failure\n");
        res = CUDBG_ERROR_COMMUNICATION_FAILURE;
        goto done;
    }
    /* append the object to the message */
    memcpy(msg + pipe->messageSize[CUDBG_PIPE_MODE_WRITE], obj, (size_t)objSize);

    /* update message parameters */
    pipe->message[CUDBG_PIPE_MODE_WRITE] = msg;
    pipe->messageSize[CUDBG_PIPE_MODE_WRITE] = msgSize;
done:
    return res;
}

CUDBGResult
cudbgPipeControlMessageAppend(cudbg_pipe_t *pipe, void *obj, uint64_t objSize)
{
    CUDBGResult res = CUDBG_SUCCESS;
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()
    struct cmsghdr *cmsg;
    struct msghdr *msg;
    uint64_t cmsgLength;
    uint64_t cmsgSpace;

    CUDBG_VERIFY((pipe && obj && objSize > 0 &&
                  pipe->type == CUDBG_PIPE_TYPE_UDS_WRITE),
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments in cudbgPipeControlMessageAppend.\n");
    CUDBG_VERIFY(pipe->msg && pipe->cmsg,
                    CUDBG_ERROR_INTERNAL,
                    "Pipe not initialized properly\n");

    /* Length of the cmsg header + payload */
    cmsgLength = CMSG_LEN(objSize);

    /* Length of the control message + padding */
    cmsgSpace = CMSG_SPACE(objSize);

    if (cmsgSpace > CUDBG_PIPE_CMSG_MAX_SIZE) {
        CUDBG_ERROR("Control message size %d is greater than max size "
                    "supported %d\n", cmsgSpace, CUDBG_PIPE_CMSG_MAX_SIZE);
        res = CUDBG_ERROR_INVALID_ARGS;
        goto done;
    }

    msg = (struct msghdr *)pipe->msg;
    cmsg = (struct cmsghdr *)pipe->cmsg;

    cmsg->cmsg_level = SOL_SOCKET;
    cmsg->cmsg_type = SCM_RIGHTS;
    cmsg->cmsg_len = cmsgLength;

    memcpy(CMSG_DATA(cmsg), obj, objSize);

    msg->msg_control = cmsg;
#if cuosOsIsQnx()
    msg->msg_controllen = cmsgLength; // Padding not accepted on QNX
#else
    msg->msg_controllen = cmsgSpace;
#endif

done:
#endif
    return res;
}

CUDBGResult
cudbgPipeControlMessageRead(cudbg_pipe_t *pipe, int **data)
{
    CUDBGResult res = CUDBG_SUCCESS;
#if cuosOsIsLinux() || cuosOsIsQnx() || cuosOsIsApple()
    struct msghdr *msg;
    struct cmsghdr *cmsg;

    CUDBG_VERIFY((pipe && data && pipe->type == CUDBG_PIPE_TYPE_UDS_READ),
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments in cudbgPipeControlMessageRead.\n");

    *data = NULL;
    msg = (struct msghdr *)pipe->msg;

    if (!msg->msg_controllen) {
        /* This can happen when we reach the per-process FD limit. If you ran into this error,
         * check ulimit and see bug 200336544, it's possible that we're leaking FDs again. */
        CUDBG_ERROR("No control data!\n");
        res = CUDBG_ERROR_COMMUNICATION_FAILURE;
        goto done;
    }

    cmsg = CMSG_FIRSTHDR(msg);
    if (!cmsg) {
        CUDBG_ERROR("Control message header is NULL!\n");
        res = CUDBG_ERROR_COMMUNICATION_FAILURE;
        goto done;
    }

    if (cmsg->cmsg_level != SOL_SOCKET || cmsg->cmsg_type != SCM_RIGHTS) {
        CUDBG_ERROR("Malformed control message!\n");
        res = CUDBG_ERROR_COMMUNICATION_FAILURE;
        goto done;
    }

    *data = (int *)CMSG_DATA(cmsg);
    if (!*data) {
        CUDBG_ERROR("Control message data is NULL!\n");
        res = CUDBG_ERROR_COMMUNICATION_FAILURE;
        goto done;
    }

done:
#endif
    return res;
}

CUDBGResult
cudbgPipeMessageSend(cudbg_pipe_t *pipe)
{
    CUDBGResult res = CUDBG_SUCCESS;
    cudbg_pipe_mode_t mode = CUDBG_PIPE_MODE_WRITE;

    CUDBG_VERIFY(pipe, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in cudbgPipeMessageSend.\n");

    /* write the final message size info in the message preamble */
    memcpy(pipe->message[mode], (char*)&pipe->messageSize[mode], sizeof(pipe->messageSize[mode]));

    /* do the write*/
    if ((res = cudbgPipeWrite(pipe, pipe->message[mode], pipe->messageSize[mode])))
        goto done;

    pipe->messageSize[mode] = sizeof(pipe->messageSize[mode]);  // for the message preamble
done:
    return res;
}

CUDBGResult
cudbgPipeMessageRead(cudbg_pipe_t *pipe, bool *retry)
{
    CUDBGResult res = CUDBG_SUCCESS;
    bool eof = false;
    cudbg_pipe_mode_t mode = CUDBG_PIPE_MODE_READ;
    uint64_t bytesToRead;

    CUDBG_VERIFY(pipe && retry, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in cudbgPipeMessageRead.\n");

    if (pipe->read_state == CUDBG_PIPE_MSG_READ_STATE_INIT) {
        CUDBG_PIPE_TRACE_FUNCTION(100, "transitioning to read the preamble\n");
        pipe->read_state = CUDBG_PIPE_MSG_READ_STATE_PREAMBLE;
    }

    if (pipe->read_state == CUDBG_PIPE_MSG_READ_STATE_PREAMBLE) {
        /* read the message preamble (message size) */
        if ((res = cudbgPipeRead(pipe, &pipe->messageSize[mode], sizeof(pipe->messageSize[mode]), &eof, retry)))
            goto done;

        /* If retry was set, we must return (maintaining all
           state in 'pipe' as well as 'read_state').  We'll
           come back to finish later. */
        if (*retry) {
            CUDBG_PIPE_TRACE_FUNCTION(100, "reading preamble needs to retry\n");
            res = CUDBG_SUCCESS;
            goto done;
        }

        /* false alarm if EOF */
        if (eof) {
            pipe->messageSize[mode] = 0;
            res = CUDBG_SUCCESS;
            goto done;
        }

        /* allocate memory for the application message */
        if (!(pipe->message[mode] = (char *)realloc(pipe->message[mode], (size_t)pipe->messageSize[mode]))) {
            CUDBG_ERROR("Memory reallocation failed\n");
            res = CUDBG_ERROR_COMMUNICATION_FAILURE;
            goto done;
        }

        /* transition to payload state */
        CUDBG_PIPE_TRACE_FUNCTION(100, "transitioning to read the payload\n");
        pipe->bytesRead = 0;
        pipe->read_state = CUDBG_PIPE_MSG_READ_STATE_PAYLOAD;
    }

    if (pipe->read_state == CUDBG_PIPE_MSG_READ_STATE_PAYLOAD) {
        /* read the message payload */
        CUDBG_PIPE_TRACE_FUNCTION(100, "reading message payload!\n");
        if (pipe->type == CUDBG_PIPE_TYPE_UDS_READ)
            /* we didn't modify the message during the preamble state */
            bytesToRead = pipe->messageSize[mode];
        else
            bytesToRead = pipe->messageSize[mode] - sizeof(pipe->messageSize[mode]);

        if ((res = cudbgPipeRead(pipe, pipe->message[mode], bytesToRead, &eof, retry)))
            goto done;

        /* If retry was set, we must return (maintaining all
           state in 'pipe' as well as 'read_state').  We'll
           come back to finish later. */
        if (*retry) {
            CUDBG_PIPE_TRACE_FUNCTION(100, "reading payload needs to retry\n");
            res = CUDBG_SUCCESS;
            goto done;
        }

        /* could happen if empty message (ack) */
        if (eof) {
            pipe->messageSize[mode] = 0;
            res = CUDBG_SUCCESS;
            goto done;
        }

        /* transition back to initial state */
        CUDBG_PIPE_TRACE_FUNCTION(100, "transitioning to initial state\n");
        pipe->bytesRead = 0;
        pipe->read_state = CUDBG_PIPE_MSG_READ_STATE_INIT;
    }
done:
    return res;
}
