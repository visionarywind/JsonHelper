/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "cudbgdarwin.h"
#include "cuos_platform.h"
#include "halo.h"
#include "cudbgutils.h"
#include <mach/mach_interface.h>
#include <mach/mach_init.h>
#include <mach/task_info.h>
#include <mach-o/dyld_images.h>
#include <sys/mman.h>

extern cudbg_pipe_t debuggerToDispatcher;
extern cudbg_pipe_t applicationToDispatcher;
cudbg_pipe_t cudbgMacTerminationPipe;
CUOSthread* cudbgMacEventThreadHandle;

/* This is strictly to allow us to use cuosEvent on darwin.  We need to translate
   file descriptor events from our communication pipes to cuosEvents which use
   mach-ports. */
int cudbgMacPipeThread(void *ignore)
{
    int maxfd, fd, ret;
    fd_set rfds, efds;

    while (1) {
        maxfd = -1;
        FD_ZERO(&rfds);
        FD_ZERO(&efds);

        fd = debuggerToDispatcher.FD[CUDBG_PIPE_MODE_READ];
        FD_SET(fd, &rfds);
        FD_SET(fd, &efds);
        maxfd = MAX(fd, maxfd);

        fd = applicationToDispatcher.FD[CUDBG_PIPE_MODE_READ];
        FD_SET(fd, &rfds);
        FD_SET(fd, &efds);
        maxfd = MAX(fd, maxfd);

        fd = cudbgMacTerminationPipe.FD[CUDBG_PIPE_MODE_READ];
        FD_SET(fd, &rfds);
        FD_SET(fd, &efds);
        maxfd = MAX(fd, maxfd);

        /* darwin has problems with poll, so don't use poll */
        ret = select(maxfd + 1, &rfds, NULL, &efds, NULL);

        /* failed to select... */
        if (ret < 0 && errno == EINTR) {
            CUDBG_DEBUG("select failed: %s\n", strerror(errno));
            break;
        }

        /* No events triggered */
        if (ret == 0)
            continue;

        /* Main thread says die */
        if (FD_ISSET(cudbgMacTerminationPipe.FD[CUDBG_PIPE_MODE_READ], &rfds)) {
            ret = 0;
            break;
        }
        if (FD_ISSET(cudbgMacTerminationPipe.FD[CUDBG_PIPE_MODE_READ], &efds)) {
            ret = -1;
            break;
        }
        /* Check each fd, signal it's corresponding event */
        if (FD_ISSET(debuggerToDispatcher.FD[CUDBG_PIPE_MODE_READ], &rfds))
            cuosEventSignal(&debuggerToDispatcher.event);
        if (FD_ISSET(debuggerToDispatcher.FD[CUDBG_PIPE_MODE_READ], &efds))
            cuosEventSignal(&debuggerToDispatcher.event);
        if (FD_ISSET(applicationToDispatcher.FD[CUDBG_PIPE_MODE_READ], &rfds))
            cuosEventSignal(&applicationToDispatcher.event);
        if (FD_ISSET(applicationToDispatcher.FD[CUDBG_PIPE_MODE_READ], &efds))
            cuosEventSignal(&applicationToDispatcher.event);
    }
    CUDBG_DEBUG("Tearing down event handling thread, ret=%d\n", ret);
    return ret;
}

CUDBGResult
cudbgMacCreateEventThread(void)
{
    CUDBGResult res = CUDBG_SUCCESS;

    if ((res = createTerminationEvent()))
        goto failure;

    if (cuosThreadCreate(&cudbgMacEventThreadHandle, cudbgMacPipeThread, NULL) == -1) {
        res = CUDBG_ERROR_UNKNOWN;
        goto failure;
    }

failure:
    return res;
}

CUDBGResult
createTerminationEvent(void)
{
    CUDBGResult res = CUDBG_SUCCESS;
    res = cudbgPipeInitialize(&cudbgMacTerminationPipe,
                             CUDBG_PIPE_TYPE_ANONYMOUS,
                             CUDBG_PIPE_ENDPOINT_NONE,
                             CUDBG_PIPE_ENDPOINT_NONE);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Pipe initialization failed.\n");
        return res;
    }

    /* Set the eventFd as non-blocking, to avoid any hard hangs when clearing events */
    if (fcntl(cudbgMacTerminationPipe.FD[CUDBG_PIPE_MODE_READ], F_SETFL, O_NONBLOCK) == -1) {
        CUDBG_ERROR("Failed to set terminationPipe as non-blocking for darwin!\n");
        return CUDBG_ERROR_UNKNOWN;
    }

    return res;
}

CUDBGResult
terminateMacEventThread(void)
{
    CUDBGResult res = CUDBG_SUCCESS;
    int retVal = 0;
    char msg = 0xdb;

    res = cudbgPipeWrite(&cudbgMacTerminationPipe, &msg, 1);
    if (res != CUDBG_SUCCESS) {
        CUDBG_TRACE("Can't send termination event!\n");
        return res;
    }

    /* Wait for the thread to terminate */
    cuosThreadJoin(cudbgMacEventThreadHandle, &retVal);
    if (retVal == -1) {
        CUDBG_TRACE("Mac event thread returned error (ignored)\n");
    }

    res = cudbgPipeFinalize(&cudbgMacTerminationPipe);
    if (res != CUDBG_SUCCESS) {
        CUDBG_TRACE("Failed to tear down termination pipe (ignored)\n");
        res = CUDBG_SUCCESS;
    }

    return res;
}

uint32_t
cudbgMacGetTID(void)
{
#ifdef THREAD_IDENTIFIER_INFO_COUNT
    uint32_t i, nthreads, count = THREAD_IDENTIFIER_INFO_COUNT;
    thread_flavor_t tflavor = THREAD_IDENTIFIER_INFO;
    thread_identifier_info_data_t tinfo;
    thread_array_t threads = NULL;
    kern_return_t kret;
    pthread_t pthread = pthread_self();
    uint64_t pthread_threadid = 0ULL;

    /* Get the number of threads in this process */
    kret = task_threads(mach_task_self(), &threads, &nthreads);
    if (kret != KERN_SUCCESS)
        return ~0U;

    /* Get the pthread thread id (64-bit) */
    if (pthread_threadid_np(pthread, &pthread_threadid))
        return ~0U;

    /* Find the entry for this thread and return it */
    for (i = 0; i < nthreads; ++i) {
        kret = thread_info(threads[i], tflavor, (thread_info_t)&tinfo, &count);
        if (kret != KERN_SUCCESS)
            return ~0U;

        if (tinfo.thread_id == pthread_threadid)
            /* We would like to return the pthread threadid directly, but it's
            a 64-bit value and the API returns a 32-bit value. We have no
            guarantee that the lower 32 bits will be unique. But we do have
            that guarantee with the 32-bit threads[i]. We return that value
               for now until the API gets updated. */
            return threads[i];
    }
#endif

    /* We have no thread information, ~0 to be caught by the client debugger */
    return ~0U;
}

/* Retrieve a pointer to task_dyld_info for current task */
static struct dyld_all_image_infos *
cudbgGetSelfDYLDAllImageInfos(void)
{
    kern_return_t rc;
    task_dyld_info_data_t  dyld_info;
    mach_msg_type_number_t dyld_info_size = TASK_DYLD_INFO_COUNT;

    rc = task_info(mach_task_self(), TASK_DYLD_INFO, (task_info_t)&dyld_info, &dyld_info_size);

    if (rc != KERN_SUCCESS || dyld_info_size != TASK_DYLD_INFO_COUNT)
        return NULL;

    return (struct dyld_all_image_infos *)dyld_info.all_image_info_addr;
}

/*
 * __TEMP_WAR__
 * Remove breakpoint set by [cuda-]gdb in library callback notifier
 * This function could be removed when CUDA.framework on Darwin will
 * be able to spawn new cudadebugger process the same way as it is 
 * done on Linux.
 */

void
cudbgCleanupStaleImageNotifierBreakpoint(void)
{
#if cuosArchIsX86() || cuosArchIsX86_64()
    /* Unmodified gdb_image_notifier functions looks as follows:
     * gdb_image_notifier+0: push   %rbp
     * gdb_image_notifier+1: mov    %rsp,%rbp
     * gdb_image_notifier+4: pop    %rbp
     * gdb_image_notifier+5: retq
     */
#if __amd64__
    static unsigned char patched_image_notifier[6] = {
                            0xcc,             /* int 3 */
                            0x48, 0x89, 0xe5, /* mov %rsp, %rbp */
                            0x5d,             /* pop %rbp */
                            0xc3              /* retq */
                          };
#else
    static unsigned char patched_image_notifier[5] = {
                            0xcc,       /* int 3 */
                            0x89, 0xe5, /* mov %rsp, %rbp */
                            0x5d,       /* pop %rbp */
                            0xc3        /* retq */
                          };
#endif
    struct dyld_all_image_infos *allInfos;
    unsigned char *code;
    int rc;

    allInfos = cudbgGetSelfDYLDAllImageInfos();
    if (allInfos == NULL) {
        CUDBG_DEBUG("Failed to get pointer to dyld_all_image_infos.");
        return;
    }

    code = (unsigned char *)allInfos->notification;

    /* Return immediately if code doesn't look the way it is supposed to */
    if (memcmp (code, patched_image_notifier, sizeof(patched_image_notifier)) != 0) {
        return;
    }

    rc = mprotect((void *)mach_vm_trunc_page(code), PAGE_SIZE, PROT_READ|PROT_WRITE);
    if (rc != 0) {
        CUDBG_DEBUG("Failed to change memory protection for page %p.",
                    (void *)mach_vm_trunc_page(code));
        return;
    }

    /* Replace int3 with standard function prologue "push rbp" */
    *code = 0x55;

    /* From Intel's software developer's manual, volume 2a, chapter 3-157:
     *  CPUID can be executed at any privilege level to serialize instruction
     *  execution. Serializing instruction execution guarantees that any
     *  modifications to flags, registers, and memory for previous instructions
     *  are completed before the next instruction is fetched and executed. */
    __asm__ volatile("cpuid" ::: "memory");

    rc = mprotect((void *)mach_vm_trunc_page(code), PAGE_SIZE, PROT_READ|PROT_EXEC);
    if (rc != 0) {
        CUDBG_DEBUG("Failed to revert memory protection changes for page %p.",
                    (void *)mach_vm_trunc_page(code));
    }
#endif
}
