/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/* ELF/DWARF relocator for the CUDA Debugger */

#include "cudbgelfreloc.h"

/* This is the new relocation code for ELF modules. The goal here
 * is to trade off memory space for time and to try to keep module
 * relocation to as close to linear time as possible.
 *
 * The code here is meant to be called from cudbgdriver
 * (referred to as the caller). A pointer to the module's elfInfo is
 * maintained by cudbgdriver, however it cannot directly dereference it.
 *
 * The code flow is as follows:
 * MODULE CREATION:
 * When a module is first encountered, it creates an elfInfo structure
 * and stashes the returned pointer in the gpudbgModule.
 * The creation of the elfInfo structure creates pointers to the input image
 * as well as the section header symbol lookup and the reloc symbol table.
 * The reloc symbol table is a copy of the symbol table into which concrete
 * values are filled in. This is maintained in memory as an array sized to
 * the number of entries in the table.
 * The section header symbol lookup is an array of pointers, which can be indexed
 * by the section index. Each element is a pointer to the symbol in the value
 * symbol table that corresponds to the section header (i.e. the symbol with
 * STT_SECTION whose shndx is the section header). This table is used for a
 * fast reverse lookup.
 * The function lookup is an array of pointers, indexed by the symbol index
 * that point back to a gpudbgFunction. These are used for texture relocs.
 *
 * GLOBAL SYMBOLS:
 * The calling code will then iterate over all global symbols. For each global
 * symbol, the caller will call cudbgModuleUpdateSymbolAtIndex. This
 * will set the value of the symbol at the given index in the reloc symbol table
 *
 * FUNCTION SYMBOLS:
 * For each function, cudbgdriver does the following:
 *  1. The function's symbol index (read from the CUfunc) is used to update
 *     the function symbol in the reloc symbol table by calling
 *     cudbgModuleUpdateSymbolAtIndex
 *  2. For the text section symbol corresponding to the function symbol, the
 *     code looks up the symbol's shndx to get the related section index and
 *     then uses the section header symbol lookup array to get the symbol.
 *     This symbol's value is updated in the reloc symbol table.
 *  3. The gpudbgFunction pointer is added into the function lookup table
 *     at the function symbol offset.
 *
 * FUNCTION SCOPE SYMBOLS:
 * For each symbol in the function's symbol table, the caller will call
 * cudbgModuleUpdateSymbolAtIndex.
 *
 * ELF RELOCATION:
 * Cudbgdriver will malloc a target of the same size as the elf image
 * and passes it in. The code here does the following :
 * 1. Copy the ELF from the unrelocated to the relocated version
 * 2. Copy the reloc symbol table into the target
 * 3. Iterate over all section headers
 *  3.1 If the section header entry in the section header symbol lookup array is
 *      non NULL, update the sh_addr with the value present
 *  3.2 If the type of the section header is not SHT_REL or SHT_RELA, skip to
 *      the next section header.
 *  3.3 For REL/RELA sections, do a full relocation of known symbols.
 *
 * MODULE DESTRUCTION:
 * Destroy the elfInfo structure, the reloc symbol table and the section header
 * lookup array.
 *
 * */

struct cudbgElfInfo_st {
    elf_t  elf;
    size_t elfSize;
    elfXXSymbol *relocSymtab;
    elfWord *relocSymtab_shndx;
    elfXXSymbol **shLookup;
    gpudbgFunction *funcLookup;
    size_t symtabEntSize;
    size_t symtabNumEnt;
};

typedef union {
    char *c;
    elfWord *eW;
    elfXXAddr *eA;
    elfByte *eB;
    elfHalf *eH;
    const elfXXSymbol *eS;
    elfXXRel *eR;
    elfXXRela *eRa;
} elfMagicCast_t;

#if defined(CU_ENABLE_MESSAGES)
static const char *
nvRelocName(uint64_t relocType)
{
    switch (relocType) {
    case R_CUDA_NONE:
        return "R_CUDA_NONE";
    case R_CUDA_32:
        return "R_CUDA_32";
    case R_CUDA_64:
        return "R_CUDA_64";
    case R_CUDA_G32:
        return "R_CUDA_G32";
    case R_CUDA_G64:
        return "R_CUDA_G64";
    default:
        return "UNKNOWN REL TYPE";
    }
}
#endif

/* cudbgGetShndx
 * Helper function for accessing the shndx of a symbol with a given symtab{,_shndx}
 */
static elfWord
cudbgGetShndx(const elfXXSymbol *symtab, const elfWord *symtab_shndx, const unsigned int symix)
{
    if (symtab_shndx && symtab[symix].shndx == SHN_XINDEX)
        /* Use extended table */
        return symtab_shndx[symix];
    /* Use index from symbol */
    return symtab[symix].shndx;
}

/* cudbgSetShndx
 * Helper function for setting the shndx of a symbol with a given symtab{,_shndx}
 */
static void
cudbgSetShndx(elfXXSymbol *symtab, elfWord *symtab_shndx, const unsigned int symix, elfWord shndx)
{
    if (symtab_shndx && shndx > (elfWord)SHN_XINDEX) {
        /* Use extended table */
        symtab_shndx[symix] = shndx;
        shndx = SHN_XINDEX;
    }
    /* Use index from symbol */
    symtab[symix].shndx = shndx;
}

/* cudbgGetSectionByName
 * General helper function to get the start, entry size and the number of entries
 * of a section by its name.
 * In the worst case, this performs a linear integer compare over all entries in the
 * section header table.
 */
static int
cudbgGetSymtab(const elf_t elf_image,
               const elfXXSectionHeader **elf_symtab_sh,
               char **start,
               size_t *entsize,
               size_t *nument)
{
    const elfXXSectionHeader *elf_sh = NULL;

    elf_sh = elfXX_typed_section_header(elf_image, SHT_SYMTAB);

    if (!elf_sh) {
        CU_DEBUG_PRINT(("No section of type SHT_SYMTAB!\n"));
        return -1;
    }
    else {
        if (elf_symtab_sh)
            *elf_symtab_sh = elf_sh;
        if (start)
            *start = (char *)elf_image + elf_sh->offset;
        if (entsize)
            *entsize = (size_t)elf_sh->entsize;
        if (nument)
            *nument = (size_t)elf_sh->size / (size_t)elf_sh->entsize;
    }

    return 0;
}


static const elfByte*
cudbgGetSectionContents(const elf_t e, const elfXXSectionHeader* esh)
{
    return elfXX_section_contents(e, esh);
}

static uint64_t
cudbgSymbolGetIndex(cudbgElfInfo *elfInfo, const elfXXSymbol *symbol)
{
    if (!elfInfo || !symbol)
        return 0;

    if (!elfInfo->relocSymtab)
        return 0;

    return (uint64_t)(((uintptr_t)symbol - (uintptr_t)elfInfo->relocSymtab)/sizeof(elfInfo->relocSymtab[0]));
}

/* cudbgApplyReloc
 * Given a section and a relocation section, this applies the relocations.
 * As one might imagine, this is performance sensitive. As a result the general
 * case is that the lookup should be O(1) for each symbol, and linear with the
 * number of relocations present in the reloc section.
 * Note : The one exception to the linear lookup is in the case of STT_CUDA_TEXTURE
 * type of relocs. In that case, two extra string compares crop up.
 */
static void
cudbgApplyReloc(elf_t elf_image,
                const elfXXSymbol *symtab,
                elfWord *symtab_shndx,
                const elfXXSectionHeader *symtab_sh,
                cudbgElfInfo *elfInfo,
                const elfXXSectionHeader *reloc_sh,
                const char *reloc_section_name,
                bool is_rela)
{
    elfMagicCast_t elfSectionTrav;
    char *elfSectionEndRange;
    const elfXXSectionHeader *elf_target_sh;

    CU_DEBUG_PRINT(("Reloc Section:  %s, "
                    "Section Offset: %p, "
                    "Section Size: 0x%x\n",
                    reloc_section_name, reloc_sh->offset, reloc_sh->size));

    /* Locate the target section of this relocation section */
    elf_target_sh = elfXX_section_header(elf_image, reloc_sh->info);
    if (!elf_target_sh) {
        /* We need a target section for the reloc */
        return;
    }

    CU_DEBUG_PRINT(("Target Section:  %s, "
                    "Section Offset: %p, "
                    "Section Size: 0x%x\n",
                    elfXX_section_name(elf_image, elf_target_sh),
                    reloc_sh->offset, reloc_sh->size));

    /* Setup section ptr and end range */
    elfSectionTrav.c = (char *)elf_image + reloc_sh->offset;
    elfSectionEndRange = (char *)elf_image + reloc_sh->offset + reloc_sh->size;

    /* Walk through the entire reloc section */
    while (elfSectionTrav.c < elfSectionEndRange) {
        uint64_t symIndex;
        uint64_t relocType;

        elfXXAddr reloc_offset;
        uint64_t  reloc_addend;
        elfXXAddr *target_value_offset;

        elfXXAddr relocAddress = (elfXXAddr)0;

        if (is_rela) {
            /* Obtain the relocator struct */
            elfXXRela rela = *elfSectionTrav.eRa++;

            /* Obtain the relocation type and its symbol index */
            relocType = ELFXX_R_TYPE(&rela);
            symIndex = ELFXX_R_SYM(&rela);

            /* Obtain the current value for this relocation */
            target_value_offset = (elfXXAddr *)((char *)elf_image +
                                                elf_target_sh->offset +
                                                rela.offset);

            /* Obtain the values of the relocation data */
            reloc_offset = rela.offset;
            reloc_addend = rela.addend;
        }
        else {
            /* Obtain the relocator struct */
            elfXXRel rel = *elfSectionTrav.eR++;

            /* Obtain the relocation type and its symbol index */
            relocType = ELFXX_R_TYPE(&rel);
            symIndex = ELFXX_R_SYM(&rel);

            /* Obtain the current value for this relocation */
            target_value_offset = (elfXXAddr *)((char *)elf_image +
                                                elf_target_sh->offset +
                                                rel.offset);

            /* Obtain the values of the relocation data */
            reloc_offset = rel.offset;
            reloc_addend = *target_value_offset;
        }

        /* At this point, the reloc value can be computed from the symbol */
        relocAddress = (elfXXAddr)(symtab[symIndex].value + reloc_addend);

        /* Test if this is a section reloc or a symbol reloc */
        if ((symtab[symIndex].info & 0xf) == STT_SECTION) {
            const elfXXSectionHeader *elf_reloc_sh;
            elfWord shndx = cudbgGetShndx(symtab, symtab_shndx,
                                          (const unsigned int)symIndex);

            elf_reloc_sh = elfXX_section_header(elf_image, shndx);
            if (!elf_reloc_sh) {
                /* The section should always be found */
                CU_DEBUG_PRINT(("\tReloc Section (Index %d) does not exist!\n",
                                shndx));
                continue;
            }

            CU_DEBUG_PRINT(("\t(Section) Reloc Found -> name: %s, type: %s,"
                            " offset: %p, index: 0x%" PRIx64 ", value: %p\n",
                            elfXX_section_name(elf_image, elf_reloc_sh),
                            nvRelocName(relocType),
                            reloc_offset, symIndex, reloc_addend));

        }
        else {

            CU_DEBUG_PRINT(("\t(Symbol) Reloc Found -> name: %s, type: %s,"
                            " offset: %p, index: 0x%" PRIx64 ", value: %p\n",
                            elfXX_symbol_name(elf_image, symtab_sh, (const unsigned int)symIndex),
                            nvRelocName(relocType),
                            reloc_offset, symIndex, reloc_addend));

            /* For textures, put the symbol table index into the address field */
            if (ELF_ST_TYPE(&symtab[symIndex]) == STT_CUDA_TEXTURE) {
                relocAddress = (elfXXAddr)symIndex;
                if (strstr(reloc_section_name, ".constant0")) {
                    uint64_t targetSymIndex;
                    uint64_t texFuncSHIndex;
                    const elfXXSymbol *texFunSymbol;

                    /* This lookup is slightly awkward. The logic here is:
                       1. Follow the target_sh->info to get the section header
                          for the actual function symbol.
                       2. Lookup the symbol for the function in the section header
                          symbol lookup table. Note that the symbol is in the
                          reloc symbol table.
                       3. Compute the symbol index by finding the offset from
                          the start of the reloc symbol table
                       4. Finally find the gpudbgFunction by looking up the symbol
                          in the function lookup table.
                       However, all of this is a constant time lookup.
                    */
                    texFuncSHIndex = (uint64_t)elf_target_sh->info;
                    if (elfInfo->shLookup[texFuncSHIndex]) {
                        texFunSymbol = elfInfo->shLookup[texFuncSHIndex];
                        targetSymIndex = cudbgSymbolGetIndex(elfInfo, texFunSymbol);
                        CU_DEBUG_PRINT(("\t\t(Tex) Reloc targetting : TexFuncSHindex:0x%x, Fun Symbol:%u gpudbgFun:%p\n",
                                        texFuncSHIndex, targetSymIndex, elfInfo->funcLookup[targetSymIndex]));

                        cudbgSaveTexIdToConstBankMap(elfInfo->funcLookup[targetSymIndex],
                                                     (uint64_t)symIndex,
                                                     reloc_offset);
                    }
                }
            }
        }
        /* This symbol was found in the driver's symbol table */
        switch (relocType) {
        case R_CUDA_32:
        case R_CUDA_G32:
            *(uint32_t *)target_value_offset = (uint32_t)relocAddress;
            CU_DEBUG_PRINT(("\t\t(32) Relocated symbol %s to 0x%x\n",
                            elfXX_symbol_name(elf_image, symtab_sh, (const unsigned int)symIndex),
                            *(uint32_t *)target_value_offset));
            break;
        case R_CUDA_64:
        case R_CUDA_G64:
            *(uint64_t *)target_value_offset = (uint64_t)relocAddress;
            CU_DEBUG_PRINT(("\t\t(64) Relocated symbol %s to 0x%lx\n",
                            elfXX_symbol_name(elf_image, symtab_sh, (const unsigned int)symIndex),
                            *(uint64_t *)target_value_offset));
            break;
        default:
            CU_DEBUG_PRINT(("\t\tRelocation type (%d) is not supported,"
                            " skipping.\n", relocType));
            break;
        }
    }
    CU_DEBUG_PRINT(("\n"));
}

/* cudbgElfXXCreateModule
 * Creates the elfInfo structure. This looks up the symbol table and
 * uses the parameters to create a reloc symbol table. This table is the
 * one in which symbol values are updated. This is done to ensure the
 * original image is held without modification
 * This also creates the section header symbol lookup array. Every
 * element in the array is a pointer to the symbol corresponding to
 * the section at that index
 */
cudbgElfInfo*
cudbgElfXXCreateModule(const elf_t image, size_t image_sz)
{
    cudbgElfInfo *elfInfo = NULL;
    uint32_t i = 0;
    const char *psymtab = NULL;
    const elfXXFileHeader *elf_fh;
    const elfXXSectionHeader *elf_sh;
    const elfXXSectionHeader *symtab_shndx_sh = NULL;
    elfWord* symtab_shndx = NULL;

    /* We need an elf image */
    if (!image) {
        CU_DEBUG_PRINT(("No elf image!\n"));
        return NULL;
    }

    elfInfo = (cudbgElfInfo *)calloc(1, sizeof(*elfInfo));
    if (!elfInfo)
        return NULL;

    elfInfo->elf = (elf_t)image;
    elfInfo->elfSize = image_sz;

    /* Decode the symbol and section string tables */
    if (cudbgGetSymtab(image,
                       NULL,
                       (char**)&psymtab,
                       &elfInfo->symtabEntSize,
                       &elfInfo->symtabNumEnt)) {
        CU_DEBUG_PRINT(("Error getting .symtab section!\n"));
        goto error;
    }

    /* Grab the optional symtab_shndx */
    symtab_shndx_sh = elfXX_typed_section_header(image, SHT_SYMTAB_SHNDX);
    if (symtab_shndx_sh)
        symtab_shndx = (elfWord*)cudbgGetSectionContents(image, symtab_shndx_sh);

    elf_fh = elfXX_file_header(image);
    if (!elf_fh) {
        CU_DEBUG_PRINT(("Error locating elf file header!\n"));
        goto error;
    }

    /* Allocate the section header lookup array */
    elfInfo->shLookup = (elfXXSymbol**)calloc(elfXX_shnum(image), sizeof(*elfInfo->shLookup));
    if (!elfInfo->shLookup) {
        CU_DEBUG_PRINT(("Unable to allocate sh lookup\n"));
        goto error;
    }

    /* Allocate the reloc symbol table */
    elfInfo->relocSymtab = (elfXXSymbol *)calloc((elfInfo->symtabNumEnt), sizeof(*elfInfo->relocSymtab));
    if (!elfInfo->relocSymtab) {
        CU_DEBUG_PRINT(("Unable to allocate temporary symtab\n"));
        goto error;
    }

    /* Allocate the reloc extended symbol header index table */
    if (symtab_shndx) {
        elfInfo->relocSymtab_shndx = (elfWord *)calloc((elfInfo->symtabNumEnt), sizeof(*elfInfo->relocSymtab_shndx));
        if (!elfInfo->relocSymtab_shndx) {
            CU_DEBUG_PRINT(("Unable to allocate temporary symtab_shndx\n"));
            goto error;
        }
    }

    /* Allocate the function lookup */
    elfInfo->funcLookup = (gpudbgFunction*)calloc(elfInfo->symtabNumEnt, sizeof(*elfInfo->funcLookup));
    if (!elfInfo->funcLookup) {
        CU_DEBUG_PRINT(("Unable to allocate function lookup\n"));
        goto error;
    }

    /* Initialize the reloc symbol table and the section header lookup array */
    for (i = 0;
         i < elfInfo->symtabNumEnt;
         ++i, psymtab += elfInfo->symtabEntSize) {

        elfWord shndx = elfXX_symbol_shndx(image, (elfXXSymbol*)psymtab, (const unsigned int)i);

        /* Copy the symbol over */
        memcpy(&elfInfo->relocSymtab[i], psymtab, sizeof(*elfInfo->relocSymtab));

        /* Copy over the symbol header index for this symbol */
        if (symtab_shndx)
            elfInfo->relocSymtab_shndx[i] = symtab_shndx[i];

        /* Get the index of the related section */
        elf_sh = elfXX_section_header(image, shndx);
        if (elf_sh && (ELF_ST_TYPE(&elfInfo->relocSymtab[i]) == STT_SECTION)) {
            /* If this symbol is the name of the related section, add it to the array */
            elfInfo->shLookup[shndx] = &elfInfo->relocSymtab[i];
        }
    }

    return elfInfo;

error:
    (void) cudbgElfXXDestroyModule(elfInfo);
    return NULL;
}

/* cudbgElfXXDestroyModule
 *  Cleans up the elfInfo struct, the reloc symbol table and the section header lookup array
 */
int
cudbgElfXXDestroyModule(cudbgElfInfo *elfInfo)
{

    if (!elfInfo)
        return 0;

    if (elfInfo->funcLookup) {
        free(elfInfo->funcLookup);
        elfInfo->funcLookup = NULL;
    }

    if (elfInfo->shLookup) {
        free(elfInfo->shLookup);
        elfInfo->shLookup = NULL;
    }

    if (elfInfo->relocSymtab) {
        free(elfInfo->relocSymtab);
        elfInfo->relocSymtab = NULL;
    }
    
    if (elfInfo->relocSymtab_shndx) {
        free(elfInfo->relocSymtab_shndx);
        elfInfo->relocSymtab_shndx = NULL;
    }

    free(elfInfo);
    elfInfo = NULL;

    return 0;
}

/* cudbgModuleUpdateSymbolByIndex
 *  Updates the symbol in the reloc symbol table at the given index with the value
 *  provided
 */
int
cudbgModuleUpdateSymbolByIndex(cudbgElfInfo *elfInfo, uint32_t index, uint64_t val)
{
    elfXXSymbol *symtab = NULL;

    if (!elfInfo)
        return -1;

    if (index > elfInfo->symtabNumEnt)
        return -1;

    if (!elfInfo->relocSymtab)
        return -1;

    symtab = (elfXXSymbol*)elfInfo->relocSymtab;
    symtab[index].value = (elfXXAddr)val;

    return 0;
}

/* cudbgModuleUpdateFunctionSymbols
 *  Updates all symbols related to a function at index fnSymIndex. In order, this function
 *  does the following:
 *
 *  1.  This function will find the related section header for the symbol in the reloc
 *      symbol table at the provided index. It will then try to loookup the symbol
 *      corresponding to the section in the section header symbol lookup array. If
 *      a symbol exists, the value will be updated.
 *
 *  2.  Updates the symbol at the function index with the given value.
 *  3.  Create an entry in the function lookup array with the provided gpudbgFunction pointer
 */
int
cudbgModuleUpdateFunctionSymbols(cudbgElfInfo *elfInfo, NvU32 fnSymIndex, gpudbgFunction function, uint64_t val)
{
    elfXXSymbol *relSymbol = NULL;
    elfWord shndx;

    if (!elfInfo)
        return -1;

    if (fnSymIndex > elfInfo->symtabNumEnt)
        return -1;

    if (!elfInfo->relocSymtab)
        return -1;

    shndx = cudbgGetShndx(elfInfo->relocSymtab, elfInfo->relocSymtab_shndx,
                          (const unsigned int)fnSymIndex);

    relSymbol = elfInfo->shLookup[shndx];

    if (relSymbol)
        relSymbol->value = (elfXXAddr)val;

    if (cudbgModuleUpdateSymbolByIndex(elfInfo, (uint32_t)fnSymIndex, val))
        return -1;

    /* Adds the gpudbgFunction into lookup at the index of the function symbol (i.e. _ZxFunc) */
    elfInfo->funcLookup[fnSymIndex] = function;

    /* Also, add the gpudbgFunction into the index of the symbol of the text section (i.e. .text._ZxFunc) */
    if (relSymbol)
        elfInfo->funcLookup[cudbgSymbolGetIndex(elfInfo, relSymbol)] = function;

    return 0;
}

/*
 * Function        : cudbgRelocateElfImage - Relocate all global vars and
 *                   functions in the elf image with driver-determined
 *                   addresses - the debugger will read the relocated image.
 * Parameters      :  elf_image (O) Pointer to the beginning of an elf object
                      elfInfo (I) Pointer to module's elf info
 * Function Result :  0 on success (relocated elf image), -1 otherwise (failure)
 */
int
cudbgRelocateElfXXImage(elf_t elf_image,
                        cudbgElfInfo *elfInfo)
{
    elfXXSectionHeader *elf_sh;
    const elfXXSectionHeader *elf_symtab_sh;
    const elfXXSectionHeader *elf_symtab_shndx_sh;
    const elfXXFileHeader *elf_fh;
    elfXXSymbol *cudbg_symbol_table = NULL;
    elfWord *cudbg_symbol_shndx = NULL;
    char *cudbg_symtab = NULL;
    uint32_t i;

    /* We need an elf image */
    if (!elf_image) {
        CU_DEBUG_PRINT(("No elf image!\n"));
        return -1;
    }

    /* Copy from the existing cubin into the new one*/
    memcpy(elf_image, elfInfo->elf, elfInfo->elfSize);

    /* Override the symtab from the value copy */
    if (cudbgGetSymtab(elf_image,
                       &elf_symtab_sh,
                       &cudbg_symtab,
                       NULL,
                       NULL)) {
        CU_DEBUG_PRINT(("Error getting .symtab section!\n"));
        return -1;
    }

    /* Grab the optional symtab_shndx_sh */
    elf_symtab_shndx_sh = elfXX_typed_section_header(elf_image, SHT_SYMTAB_SHNDX);
    if (elf_symtab_shndx_sh)
        cudbg_symbol_shndx = (elfWord*)cudbgGetSectionContents(elf_image, elf_symtab_shndx_sh);

    cudbg_symbol_table = (elfXXSymbol*)cudbg_symtab;
    for (i = 0 ; i < elfInfo->symtabNumEnt; ++i) {
        cudbg_symbol_table[i].value = elfInfo->relocSymtab[i].value;
    }

    /* Point to the elf file header */
    elf_fh = elfXX_file_header(elf_image);
    if (!elf_fh) {
        CU_DEBUG_PRINT(("Error locating elf file header!\n"));
        return -1;
    }

    /* Iterate over each section in the original elf
     * image, relocating each entry as needed */
    for (i = 0; i < elfXX_shnum(elf_image); ++i) {
        bool isRela = false;
        const char *elf_section_name = NULL;

        elf_sh = (elfXXSectionHeader*)elfXX_section_header(elf_image, i);

        /* If the section header lookup points at a symbol, use its
           value as address */
        if (elfInfo->shLookup[i]) {
            elf_sh->addr = (elfXXAddr)(elfInfo->shLookup[i]->value);
        }

        /* Skip non reloc sections */
        if (elf_sh->type != SHT_RELA &&
            elf_sh->type != SHT_REL)
            continue;

        isRela = (elf_sh->type == SHT_RELA);
        elf_section_name = elfXX_section_name(elf_image, elf_sh);

        cudbgApplyReloc(elf_image,
                        cudbg_symbol_table,
                        cudbg_symbol_shndx,
                        elf_symtab_sh,
                        elfInfo,
                        elf_sh,
                        elf_section_name,
                        isRela);
    }

    return 0;
}
