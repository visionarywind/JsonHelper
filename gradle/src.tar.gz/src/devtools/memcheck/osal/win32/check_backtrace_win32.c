/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: check_backtrace_win32.c
 *
 *   Description:
 *       Windows specific functions for generating a backtrace
 *
 ******************************************************************************/

#include "check_osal.h"
#include "cuda_structs.h"
#include "cuos_debug.h"

#include "cuos.h"
#include <windows.h>
#include <Dbghelp.h>

/* Typedefs */
typedef struct BTHGlobalData_win32_st BTHGlobalData;

typedef bool (WINAPI *psymFromAddr)(HANDLE, DWORD64, PDWORD64, PSYMBOL_INFO);
typedef BOOL (WINAPI *psymInit)(HANDLE, PCTSTR, BOOL);
typedef DWORD (WINAPI *psymSetOpt)(DWORD);
typedef BOOL (WINAPI *psymFin)(HANDLE);
typedef USHORT (WINAPI *pcaptureBT)(ULONG, ULONG, PVOID*, PULONG);

/* Struct defs */
struct BTHGlobalData_win32_st {
    HANDLE hProcess;
    psymFromAddr getSymAddr;
    psymInit     symInit;
    psymFin      symFin;
    psymSetOpt   symSetOpt;
    CUOSLibrary dbgHelp;
};

/* Capture a maxdepth frames of backtrace into the given buffer
    Parameters :
        **buffer  : pointer to an allocated array of return addresses
        maxDepth  : maximum depth to capture
        *captured : pointer containing number of frames
*/
CUresult
osalBacktraceCapture(void **buffer, uint32_t maxDepth, uint32_t *captured)
{
#if cuosOsIsWindows()
    USHORT ret = 0;
    ULONG frameSkip = 0;
    ULONG frameCapture = 0;
    CUresult res = CUDA_SUCCESS;

    if (!buffer || !captured || !maxDepth) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    frameCapture = maxDepth;

    if (frameSkip + frameCapture >= 61) {
        CU_TRACE_PRINT(("Limited to 61 frames on windows\n"));
        frameCapture = 61 - frameSkip;
    }

    ret = CaptureStackBackTrace(frameSkip, frameCapture, buffer, NULL);
    *captured = (uint32_t)ret;

    return res;

#else
    CU_ERROR_PRINT(("Invalid OS\n"));
    return CUDA_ERROR_UNKNOWN;

#endif
}

/*  Initialize internal state for loading frame info. Needed on windows
*/
CUresult osalBacktraceFrameInfoInitialize(void **osData)
{
#if cuosOsIsWindows()
    BTHGlobalData *data = NULL;
    DWORD error;

    if (!osData) {
        CU_ERROR_PRINT(("Invalid argument\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *osData = NULL;

    data = calloc(1, sizeof(*data));
    if (!data) {
        CU_ERROR_PRINT(("Failed to allocate OS data\n"));
        return CUDA_ERROR_OUT_OF_MEMORY;
    }

    data->hProcess = GetCurrentProcess();
    data->dbgHelp = cuosLoadLibrary("dbghelp.dll");
    if (!data->dbgHelp) {

        // This means no extra information on a backtrace
        // Exit early
        free(data);
        return CUDA_SUCCESS;
    }

    data->symInit = (psymInit)cuosGetProcAddress(data->dbgHelp, "SymInitialize");
    data->symSetOpt = (psymSetOpt)cuosGetProcAddress(data->dbgHelp, "SymSetOptions");
    data->symFin = (psymFin)cuosGetProcAddress(data->dbgHelp, "SymCleanup");
    data->getSymAddr = (psymFromAddr)cuosGetProcAddress(data->dbgHelp, "SymFromAddr");

    if (!data->symSetOpt || !data->symInit || !data->symFin ||
        !data->getSymAddr) {
        CU_ERROR_PRINT(("Cannot initialize or set options\n"));
        data->symInit = NULL;
        data->symSetOpt = NULL;
        data->symFin = NULL;
        data->getSymAddr = NULL;
    }

    if (data->symSetOpt && data->symInit) {
        data->symSetOpt(SYMOPT_UNDNAME | SYMOPT_DEFERRED_LOADS);
        if (data->symInit(data->hProcess, NULL, TRUE) == FALSE) {
            error = GetLastError();
            CU_ERROR_PRINT(("Failed to initialize symbols\n"));
            goto error;
        }
    }

    *osData = data;

    return CUDA_SUCCESS;

error:
    data->getSymAddr = NULL;
    // Unload the library and return a fail.
    cuosFreeLibrary(data->dbgHelp);
    data->dbgHelp = NULL;
    return CUDA_ERROR_UNKNOWN;

#else
    CU_ERROR_PRINT(("Invalid OS\n"));
    return CUDA_ERROR_UNKNOWN;
#endif
}

/* Finalize internal state for loading frame info. Needed on windows
*/
CUresult osalBacktraceFrameInfoFinalize(void **osData)
{
#if cuosOsIsWindows()
    BTHGlobalData *data = NULL;

    if (!osData) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    data = (BTHGlobalData*)(*osData);

    if (!data)
        return CUDA_SUCCESS;

    if (data->dbgHelp) {
        if (data->symFin)
            data->symFin(data->hProcess);
        cuosFreeLibrary(data->dbgHelp);
    }

    free(data);
    *osData = NULL;

    return CUDA_SUCCESS;
#else
    CU_ERROR_PRINT(("Invalid OS\n"));
    return CUDA_ERROR_UNKNOWN;
#endif
}

/*  Given an element of the raw buffer (return address), produce information
    about the frame.
    Parameters :
        *osData     : Pointer to OS data. Only used on windows
        *addr       : Return address pointer (single element of backtrace)
        **pLibName  : Pointer to a buffer containing the name of the library
                      This is malloc'd by this function and must be freed
                      in destroyBacktrace
        *pLibAddr   : Base address the library is loaded at
        **pFuncName : Pointer to buffer containing the name of the function
                      This is malloc'd by this function and must be freed
                      in destroyBacktrace
        *pFuncAddr  : Base address of the containing function.
        *isLibcuda  : Returns 1 if the frame is in libcuda, 0 otherwise
*/
CUresult osalGetFrameInfo(void *osData, void *addr, char **pLibName,
                          uint64_t *pLibAddr, char **pFuncName, uint64_t *pFuncAddr,
                          uint32_t *isLibcuda)
{
#if cuosOsIsWindows()
    BTHGlobalData *data = NULL;
    char *buf = NULL;
    size_t bufSize = 0;
    PSYMBOL_INFO pSymbol = NULL;
    char modName[1024] = {0};
    DWORD modSize = 0;
    DWORD64 dwaddr = 0;
    const char *libcuda = "nvcuda.dll";
    HMODULE hcudamod = NULL, hmod = NULL;
    bool gothmod = false;

    if (!addr) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!osData) {
        CU_TRACE_PRINT(("OS data not initialized. Frame info is empty\n"));
        return CUDA_SUCCESS;
    }

    data = (BTHGlobalData*)osData;

    dwaddr = (DWORD64)(uint64_t)(uintptr_t)addr;

    hcudamod = GetModuleHandle(libcuda);
    /* Ensure UNCHANGED_REFCOUNT is set so that the library refcount
       is not increased */
    gothmod = GetModuleHandleEx(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                                GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                                (LPCTSTR)addr, &hmod);
    if (isLibcuda) {
        *isLibcuda = 0;
        if (gothmod && hcudamod == hmod)
            *isLibcuda = 1;
    }

    if (pLibName && gothmod) {
        modSize = GetModuleFileName(hmod, modName, sizeof(modName));
        if (modSize >= sizeof(modName)) {
            modSize = sizeof(modName) - 1;
        }
        /* Force explicit string termination */
        modName[modSize] = '\0';
        *pLibName = calloc(1, modSize + 1);
        if (!(*pLibName)) {
            CU_ERROR_PRINT(("Cannot allocate string for name\n"));
            return CUDA_ERROR_OUT_OF_MEMORY;
        }
        memcpy(*pLibName, modName, modSize + 1);
    }

    /* Take first stab at library address */
    if (pLibAddr && gothmod)
        *pLibAddr = (uint64_t)hmod;

    /* Fall to dbghelp.dll for function symbols */
    if (!data->getSymAddr) {
        CU_TRACE_PRINT(("No symbol access function. Skipping\n"));
        return CUDA_SUCCESS;
    }

    bufSize = (size_t)(sizeof(SYMBOL_INFO) + MAX_SYM_NAME * sizeof(TCHAR));
    buf = calloc(1, bufSize);
    if (!buf) {
        CU_ERROR_PRINT(("Cannot allocate symbol buffer\n"));
        return CUDA_ERROR_OUT_OF_MEMORY;
    }
    pSymbol = (PSYMBOL_INFO)buf;

    pSymbol->SizeOfStruct = sizeof(SYMBOL_INFO);
    pSymbol->MaxNameLen = MAX_SYM_NAME;

    if (data->getSymAddr(data->hProcess, dwaddr,
                         NULL, pSymbol) == FALSE) {
        CU_TRACE_PRINT(("No symbol info found\n"));
        free(buf);
        return CUDA_SUCCESS;
    }

    if (pLibAddr && !gothmod)
        *pLibAddr = (uint64_t)pSymbol->ModBase;

    if (pFuncName) {
        *pFuncName = calloc(1, strlen(pSymbol->Name) + 1);
        if (!(*pFuncName)) {
            CU_ERROR_PRINT(("Failed to allocate memory\n"));
            free(buf);
            return CUDA_ERROR_OUT_OF_MEMORY;
        }

        memcpy(*pFuncName, pSymbol->Name, strlen(pSymbol->Name));
    }

    if (pFuncAddr)
        *pFuncAddr = (uint64_t)pSymbol->Address;

    free(buf);
    buf = NULL;

    return CUDA_SUCCESS;
#else
    CU_ERROR_PRINT(("Invalid OS\n"));
    return CUDA_ERROR_UNKNOWN;
#endif
}

