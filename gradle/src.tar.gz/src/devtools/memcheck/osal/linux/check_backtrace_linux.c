/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: check_backtrace_linux.c
 *
 *   Description:
 *       Linux specific functions for generating a backtrace
 *
 ******************************************************************************/

#include <cuos_platform.h>
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <dlfcn.h>
#if !cuosOsIsAndroid()
#include <execinfo.h>
#endif
#include "cuda_structs.h"
#include "cuos_debug.h"

#include "check_osal.h"

/*  Initialize internal state for loading frame info. On posix platforms,
    this function will fill the base address of libcuda.so into the
    osData pointer. This will be used in subsequent frame generation calls
    to identify whether the frame in question is inside libcuda.
*/
CUresult osalBacktraceFrameInfoInitialize(void **osData)
{
#if (cuosOsIsLinux() && !cuosOsIsAndroid())
    Dl_info info = {0};
    uint32_t captured = 0;
    void *frame = NULL;

    if (!osData) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *osData = NULL;

    captured = backtrace(&frame, 1);
    if (!captured) {
        CU_TRACE_PRINT(("No frames present\n"));
        return CUDA_SUCCESS;
    }

    if (!dladdr(frame, &info))
        return CUDA_SUCCESS;

    if (!info.dli_fbase)
        return CUDA_SUCCESS;

    *osData = (void*)info.dli_fbase;

    return CUDA_SUCCESS;
#else
    CU_ERROR_PRINT(("Invalid OS\n"));
    return CUDA_ERROR_UNKNOWN;
#endif
}

/*  Given an element of the raw buffer (return address), produce information
    about the frame.
    Parameters :
        *osData     : Pointer to OS data. Only used on windows
        *addr       : Return address pointer (single element of backtrace)
        **pLibName  : Pointer to a buffer containing the name of the library
                      This is malloc'd by this function and must be freed
                      in destroyBacktrace
        *pLibAddr   : Base address the library is loaded at
        **pFuncName : Pointer to buffer containing the name of the function
                      This is malloc'd by this function and must be freed
                      in destroyBacktrace
        *pFuncAddr  : Base address of the containing function.
        *isLibcuda  : Returns 1 if the frame is in libcuda, 0 otherwise
*/
CUresult osalGetFrameInfo(void *osData, void *addr, char **pLibName,
                          uint64_t *pLibAddr, char **pFuncName, uint64_t *pFuncAddr,
                          uint32_t *isLibcuda)
{
#if cuosOsIsLinux()
    Dl_info info = {0};
    void *libbase = NULL;

    if (!addr) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    libbase = osData;

    if (!dladdr(addr, &info)) {
        // If dladdr failed, we have no information, we return early
        return CUDA_SUCCESS;
    }

    if (isLibcuda)
        *isLibcuda = 0;

    if (isLibcuda && libbase == info.dli_fbase)
        *isLibcuda = 1;

    if (pLibName) {
        *pLibName = NULL;

        if (info.dli_fname && strlen(info.dli_fname)) {
            *pLibName = (char *)calloc(1, strlen(info.dli_fname) + 1);
            if (!(*pLibName)) {
                CU_ERROR_PRINT(("Failed to allocate memory\n"));
                return CUDA_ERROR_OUT_OF_MEMORY;
            }

            memcpy(*pLibName, info.dli_fname, strlen(info.dli_fname));
        }
    }

    if (pLibAddr)
        *pLibAddr = (uint64_t)(uintptr_t)info.dli_fbase;

    if (pFuncName) {
        *pFuncName = NULL;

        if (info.dli_sname && strlen(info.dli_sname)) {
            *pFuncName = (char *)calloc(1, strlen(info.dli_sname) + 1);
            if (!(*pFuncName)) {
                CU_ERROR_PRINT(("Failed to allocate memory\n"));
                return CUDA_ERROR_OUT_OF_MEMORY;
            }

            memcpy(*pFuncName, info.dli_sname, strlen(info.dli_sname));
        }
    }

    if (pFuncAddr)
        *pFuncAddr = (uint64_t)(uintptr_t)info.dli_saddr;

    return CUDA_SUCCESS;
#else
    CU_ERROR_PRINT(("Invalid OS\n"));
    return CUDA_ERROR_UNKNOWN;
#endif
}
