/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */
/******************************************************************************
 *
 *   Module: check_patch_core.h
 *
 *   Description:
 *       Handling of core patching related behavior, such as scoping
 *       and state management
 *
 ******************************************************************************/

#ifndef _CHECK_PATCH_CORE_H
#define _CHECK_PATCH_CORE_H

#include "cuda.h"
#include "cuda_types.h"
#include "cuda_inttypes.h"
#include "cui/hash.h"

#include "tools_shared_hashmap.h"
#include "check_core.h"
/* Management of patch scoping. This is to handle multiple behaviors:
    1. Under GK11x this is used to force patching of all funcs in a module
    2. Under separate compilation, the callgraph will be used to find scope (FUTURE)
    The smallest scope unit is a MCfunc* as the core patching happens for a function
*/

/* Typedefs */
typedef struct CCpatchScopeUnit_st CCpatchScopeUnit;
typedef struct CCpatchScope_st CCpatchScope;
typedef struct CCpatchScopeCallbacks_st CCpatchScopeCallbacks;

typedef CUresult (*MCscopeCBFunc)(MCcontext *mcctx, MCfunc *start, MCfunc *func, void* data);

/* CCpatchScopeUnit
   A scope unit for patching. This is for a single scope unit.
   Since patches are generated per function, the scope unit will track
   an MCfunc. This is separate as finer granularity scope resolution will
   be implemented.
*/
struct CCpatchScopeUnit_st {
    MCfunc *func;
};

typedef enum {
    CC_PATCH_SCOPE_NONE,        // Do not patch
    CC_PATCH_SCOPE_PER_KERNEL,  // Patch every CUfunc (must be global) (DEFAULT)
    CC_PATCH_SCOPE_MODULE,      // Patch all CUfuncs in module
    CC_PATCH_SCOPE_CALLGRAPH,   // Patch all CUfuncs in callgraph
} CCpatchScopeTypes;

/* CCpatchScope
    A scope object. Internally, this contains a list of scopeUnits. The
    patcher must generate a patch for each scopeUnit. The cases struct
    is present for additional information.
*/
struct CCpatchScope_st {
    CCpatchScopeTypes type; // Type of this scope
    uint32_t refCount;      // The ref count

    CCpatchScopeMgr *mgr;
    tHashMap        *unitMap;    // Map from MCfunc* -> CCpatchScopeUnit
    union {
        MCfunc *kernel;
        MCmod  *module;
    } cases;

};

typedef enum {
    CC_PATCH_SCOPE_MANAGER_NONE = 0,    // Default, not ready
    CC_PATCH_SCOPE_MANAGER_BUSY,
    CC_PATCH_SCOPE_MANAGER_READY,       // Scope generation complete
} CCpatchScopeMgrStates;

/* CCpatchScopeMgr
    The patch scope manager. This holds a map of all patch scopes.
    On every module load, the scopes for that module are generated.
*/
struct CCpatchScopeMgr_st {
    CCpatchScopeMgrStates state;    // Manager state
    MCcontext *mcctx;               // Shortcut to context
    tHashMap  *funcMap;             // MCfunc -> CCpatchScope*
};

struct CCpatchScopeCallbacks_st {
    CUresult (*preLoop) (MCmod *mod, CCpatchScopeMgr *mgr, void **data);
    CUresult (*functorGetScope) (CCpatchScopeMgr *mgr, MCfunc *func, CCpatchScope **pScope, void **data);
    CUresult (*postLoop) (MCmod *mod, CCpatchScopeMgr *mgr, void **data);
};

/* Callback based patcher core */
typedef struct CCinstIterCBState_st CCinstIterCBState;
typedef struct CCinstIterCallbacks_st CCinstIterCallbacks;

typedef enum {
    CC_INST_ITER_MODE_NONE = 0,
    CC_INST_ITER_MODE_PROLOGUE,
    CC_INST_ITER_MODE_EPILOGUE,
    CC_INST_ITER_MODE_TARGET,
} CCinstIterCBMode;

struct CCinstIterCBState_st {
    CCinstIterCBMode mode;  // Callback mode
    uint64_t *start;        // Start of function
    uint64_t size;          // In bytes
    uint64_t *cur;          // Current pointer (start <= cur < start + size)
    uint64_t offset;        // Current offset in bytes from start
    uint32_t target;        // Return value from isTarget
    void *customData;
};

struct CCinstIterCallbacks_st {
    // Callback for prologue patch creation
    CUresult   (*prologue) (CCinstIterCBState *state);
    // Callback for each instruction that is a valid target
    CUresult   (*perInstruction)(CCinstIterCBState *state);
    // Callback for epilogue patch creation
    CUresult   (*epilogue) (CCinstIterCBState *state);
    // Test if an instruction is a valid target.
    // The check should be 0 if its not a target
    // and non zero if it is a target
    // The value of the test is written into the callbackstate
    uint32_t    (*isTarget) (uint64_t inst);
};

/* Scope manager functions */
CUresult initializeScopeManager(MCcontext *mcctx);
CUresult finalizeScopeManager(MCcontext *mcctx);
CUresult generateModuleScopes(MCcontext *mcctx, MCmod *mod);

/* Scope unit iterator */
CUresult scopeFunctor(MCcontext *mcctx, MCfunc *start, MCscopeCBFunc cbfunc, void *data);

/* Instruction iterator  */
CUresult instIterate(uint64_t *buf, uint64_t size, CCinstIterCallbacks *cb);


#endif
