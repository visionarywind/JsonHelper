/*
 * Copyright 2016-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "memcheck_types.h"
#include "check_mc_context.h"
#include "check_mc_module.h"
#include "check_mc_func.h"
#include "check_filter.h"

#include "halo.h"
#include "halo_state.h"
#include "cuicnp.h"
#include "tools_shared.h"
#include "cudbgdriver.h"
#include "memcheck_error.h"

static uint32_t
getAbiVersion(const char *image)
{
    if (!image)
        return 0;

    if (isELF(image)) {
        if (isELF64(image))
            return toolsElf64GetAbiVersion(image);
        else
            return toolsElf32GetAbiVersion(image);
    }

    return 0;
}

static void
destroyHaloMod(DeviceModule haloMod)
{
    if (haloMod) {
        free(haloMod->relocatedElfImage);
        if (haloMod->functions)
            toolsHashMapDelete(haloMod->functions, NULL, NULL);
        haloStateDestroyModule(haloMod);
    }
}

static CUresult
createHaloMod(MCcontext *context, CUmod *cumod, uint32_t abiVersion, DeviceModule *pHaloMod, const void *pimage, size_t image_sz)
{
    CUresult res = CUDA_SUCCESS;
    CUDBGResult dbgRes = CUDBG_SUCCESS;
    cudbgElfInfo *dbgElfInfo = NULL;
    DeviceModule haloMod = NULL;
    Context haloContext = NULL;

    dbgRes = haloStateCreateModule(pHaloMod,
                                   context->haloContext,
                                   (uint64_t)(uintptr_t)(cumod),
                                   abiVersion);
    if (dbgRes != CUDBG_SUCCESS)
        return CUDA_ERROR_OUT_OF_MEMORY;

    haloMod = *pHaloMod;

    haloMod->cuModule = (uint64_t)(uintptr_t)(cumod);
    haloMod->context = context->haloContext;
    haloMod->abiVersion = abiVersion;
    haloMod->hidden = (cumod->visibility != CU_MOD_VISIBILITY_VISIBLE);
    haloMod->visibility = (DeviceModuleType_t)(cumod->visibility);
    haloMod->name = (char*)cumod->name;

    haloMod->functions = toolsHashMapNew(toolsUint32HashFun, toolsUint64EqualFun, 8);
    if (!haloMod->functions) {
        CU_ERROR_PRINT(("Failed to allocate hash map\n"));
        res = CUDA_ERROR_OUT_OF_MEMORY;
        goto error;
    }

    /* On Volta+, relocated elf image is required by HALO for stack unwinding */
    if (getArchFromSmVer(context->sm_version) >= MC_TOOL_MODE_ARCH_SM70) {
        haloMod->elfImageSize = image_sz;

        haloMod->relocatedElfImage = (elf_t)malloc(image_sz);
        if (!haloMod->relocatedElfImage) {
            CU_ERROR_PRINT(("Failed to allocate relocated elf image\n"));
            res = CUDA_ERROR_OUT_OF_MEMORY;
            goto error;
        }
        memcpy(haloMod->relocatedElfImage, pimage, image_sz);

        cudbgModuleUpdateSymbols(context->cuctx, cumod, "Unknown",
                                 (char*)haloMod->relocatedElfImage);
    }

    return CUDA_SUCCESS;

error:
    CU_ERROR_PRINT(("Failed to create halo mod\n"));
    destroyHaloMod(haloMod);

    return res;
}

static CUresult
createModFunctions(MCmod *mod, MCcontext *context)
{
    TOOLSresult tres = TOOLS_SUCCESS;
    CUfunc *fptr = NULL;
    CUresult res = CUDA_SUCCESS;
    MCfunc *lastfunc = NULL;

    CU_TRACE_FUNCTION();

    if (!mod) {
        CU_ERROR_PRINT(("Invalid Arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    lastfunc = NULL;
    for (fptr = mod->cumod->pFuncList; fptr; fptr = fptr->next) {
        MCfunc *mcfunc = NULL;

        res = mcFuncCreate(mod, fptr, &mcfunc);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to create memcheck function\n"));
            return res;
        }

        mcContextAddFuncToMap(context, mcfunc);

        toolsHashMapInsert(mod->funcs, tHashMapPtrToKey(fptr), (void*)(mcfunc));
        if (mcfunc->funcName)
            toolsHashMapInsert(mod->funcNames, tHashMapPtrToKey(mcfunc->funcName), (void*)mcfunc);

        res = CCfilterMgrMatchOnLoad(context->filterMgr, mcfunc, &mcfunc->filterMatch);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to setup filter on load\n"));
            return res;
        }

        if (!lastfunc)
            mod->funcList = mcfunc;
        else
            lastfunc->next = mcfunc;
        lastfunc = mcfunc;
    }

    return CUDA_SUCCESS;
}

CUresult
mcModuleCreate(MCcontext *context, CUmod *cumod, MCmod **pmod,
               const void *pimage, size_t imageSz)
{
    char memcheck_flags[CUOS_ENV_VAR_LENGTH];
    MCmod *mod = NULL;
    uint32_t abiVersion = 0;
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!context || !cumod || !pmod) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Setup the default
    *pmod = NULL;

    mod = (MCmod*) calloc(1, sizeof(MCmod));
    if (!mod) {
        CU_ERROR_PRINT(("Could not allocate module\n"));
        return CUDA_ERROR_OUT_OF_MEMORY;
    }

    mod->context = context;
    mod->cumod = cumod;
    mod->funcs = toolsHashMapNew(toolsPointerHashFun, toolsPointerEqualFun, 17);
    if (!mod->funcs) {
        res = CUDA_ERROR_OUT_OF_MEMORY;
        goto error;
    }
    mod->funcNames = toolsHashMapNew(toolsStringHashFun, toolsStringEqualFun, 17);
    if (!mod->funcNames) {
        res = CUDA_ERROR_OUT_OF_MEMORY;
        goto error;
    }

    if (context->sm_version >= 305)
        mod->modOpts.usesCnp = cuiModuleUsesCnp(cumod);

    mod->modOpts.defaultScope = CC_PATCH_SCOPE_CALLGRAPH;
    /* If no filters are defined, and the module uses CNP,
       patch all functions in the module */
    if (mod->modOpts.usesCnp &&
        CCfilterMgrGetCount(context->filterMgr) == 0 )
        mod->modOpts.defaultScope = CC_PATCH_SCOPE_MODULE;

    if (!cuosGetEnv("CUDA_MEMCHECK_PATCH_MODULE", memcheck_flags, CUOS_ENV_VAR_LENGTH))
        mod->modOpts.defaultScope = CC_PATCH_SCOPE_MODULE;

    if (cumod->visibility == CU_MOD_VISIBILITY_HIDDEN_SYSCALL ||
        cumod->visibility == CU_MOD_VISIBILITY_HIDDEN_TRAMPOLINE ||
        cumod->visibility == CU_MOD_VISIBILITY_HIDDEN_ATENTRY)
        mod->type = MC_MOD_TYPE_SYSCALL;
    else if (cumod->visibility)
        mod->type = MC_MOD_TYPE_INTERNAL;
    else
        mod->type = MC_MOD_TYPE_USER;

    if (pimage) {
        mod->image = malloc(imageSz);
        if (!mod->image) {
            CU_ERROR_PRINT(("Could not allocate image\n"));
            res = CUDA_ERROR_OUT_OF_MEMORY;
            goto error;
        }

        memcpy(mod->image, pimage, imageSz);
        abiVersion = getAbiVersion((const char *)mod->image);
    }
    else if (mod->type == MC_MOD_TYPE_SYSCALL)  {
        // For syscalls, we can assume the abiVersion
        abiVersion = ELFOSABIV_ABI;
    }

    mod->abiVersion = abiVersion;

    if (NULL != context->haloContext) {
        res = createHaloMod(context, cumod, abiVersion, &mod->haloMod, pimage, imageSz);
        if (res != CUDA_SUCCESS)
            goto error;
    }

    // Create the functions
    res = createModFunctions(mod, context);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to create module functions\n"));
        goto error;
    }

    *pmod = mod;

    CU_TRACE_PRINT(("Module created\n"));

    return CUDA_SUCCESS;

error:
    CU_ERROR_PRINT(("Failed to create module. Res:%u\n", res));
    if (mod) {
        mcModuleDestroy(mod);
        mod = NULL;
    }
    return res;
}

static void
funcCleanupFunctor(void *value, void *functor_data)
{
    MCfunc *func = (MCfunc *)value;
    mcContextRemoveFuncFromMap(func->context, func);
    mcFuncDestroy(func);
    func = NULL;
}

CUresult
mcModuleDestroy(MCmod *mod)
{
    CUresult res = CUDA_SUCCESS;

    if (!mod) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (mod->funcs) {
        toolsHashMapDelete(mod->funcs, funcCleanupFunctor, NULL);
        mod->funcs = NULL;
    }

    if (mod->funcNames) {
        toolsHashMapDelete(mod->funcNames, NULL, NULL);
        mod->funcNames = NULL;
    }

    destroyHaloMod(mod->haloMod);

    free(mod->image);
    free(mod);

    return CUDA_SUCCESS;
}

MCfunc *
mcModuleGetFuncByName(MCmod *mod, const char *name)
{
    if (!mod || !name)
        return NULL;

    if (!mod->funcNames)
        return NULL;

    return (MCfunc*)toolsHashMapFind(mod->funcNames, tHashMapPtrToKey(name));
}

