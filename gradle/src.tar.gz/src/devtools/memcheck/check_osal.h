/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: check_osal.h
 *
 *   Description:
 *       OS abstraction layer for memcheck
 *
 ******************************************************************************/

#ifndef _CHECK_OSAL_H
#define _CHECK_OSAL_H

#include "cuda.h"
#include "cudamemcheck.h"

/* OS specific Backtrace functions */
/* Capture a maxdepth frames of backtrace into the given buffer
    Parameters :
        **buffer  : pointer to an allocated array of return addresses
        maxDepth  : maximum depth to capture
        *captured : pointer containing number of frames
*/
CUresult osalBacktraceCapture(void **buffer, uint32_t maxDepth, uint32_t *captured);

/*  Initialize internal state for loading frame info. Needed on windows
*/
CUresult osalBacktraceFrameInfoInitialize(void **osData);

/* Finalize internal state for loading frame info. Needed on windows
*/
CUresult osalBacktraceFrameInfoFinalize(void **osData);

/*  Given an element of the raw buffer (return address), produce information
    about the frame.
    Parameters :
        *osData     : Pointer to OS specific data. Used on windows
        *addr       : Return address pointer (single element of backtrace)
        **pLibName  : Pointer to a buffer containing the name of the library
                      This is malloc'd by this function and must be freed
                      in destroyBacktrace
        *pLibAddr   : Base address the library is loaded at
        **pFuncName : Pointer to buffer containing the name of the function
                      This is malloc'd by this function and must be freed
                      in destroyBacktrace
        *pFuncAddr  : Base address of the containing function.
*/
CUresult osalGetFrameInfo(void *osData, void *addr, char **pLibName,
                          uint64_t *pLibAddr, char **pFuncName, uint64_t *pFuncAddr,
                          uint32_t *isLibcuda);

#endif
