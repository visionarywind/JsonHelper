/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: check_alloc.h
 *
 *   Description:
 *       Allocation tracking
 *
 ******************************************************************************/

#ifndef _CHECK_ALLOC_H
#define _CHECK_ALLOC_H

#include "check_core.h"
#include "memcheck_types.h"

typedef enum {
    CC_ALLOC_FLAG_NONE              = 0,
    CC_ALLOC_FLAG_INTERNAL          = 0x001,    /* Allocation is internal to driver */
    CC_ALLOC_FLAG_NAMED             = 0x002,    /* Allocation has a name */
    CC_ALLOC_FLAG_HEAP              = 0x004,    /* Allocation is the heap */
    CC_ALLOC_FLAG_MODULE            = 0x008,    /* Allocation is static scoped to a module */
    CC_ALLOC_FLAG_PARAM_BANK        = 0x010,    /* Allocation is the CNP param bank */
    CC_ALLOC_FLAG_MANAGED           = 0x020,    /* Allocation is UVM managed */
    CC_ALLOC_FLAG_HOST_MAPPED       = 0x040,    /* Allocation is host accessible */
    CC_ALLOC_FLAG_GL_INTEROP        = 0x080,    /* Allocation came from a GL interop call */
    CC_ALLOC_FLAG_HOST_REGISTERED   = 0x100,    /* cudaHostRegister has been called on the allocation */
    CC_ALLOC_FLAG_HOST_PINNED       = 0x200,    /* Allocation is pinned on the host */
    CC_ALLOC_FLAG_PEER              = 0x400,    /* Allocation is located on a peer GPU */
    CC_ALLOC_FLAG_PEER_ATOMIC       = 0x800,    /* Allocation is located on a peer GPU supporting native atomic */
} CCallocFlags;

typedef enum {
    CC_ALLOC_TABLE_FLAG_NONE                = 0,
    CC_ALLOC_TABLE_FLAG_READ_ONLY           = (1 << 0), /* Allocation table is read only */
    CC_ALLOC_TABLE_FLAG_COALESCE            = (1 << 1), /* Allocation table is coalesced */
    CC_ALLOC_TABLE_FLAG_EXTERNAL            = (1 << 2), /* Skip internal allocations */
    CC_ALLOC_TABLE_FLAG_STREAM_VISIBLE      = (1 << 3), /* Merge allocations matching given stream */
} CCallocTableFlags;

typedef enum {
    CC_ALLOC_VISIBILITY_CTX     = 0,    /* Default visibility context wide */
    CC_ALLOC_VISIBILITY_STREAM  = 1,    /* Visible only to one stream  */
    CC_ALLOC_VISIBILITY_NONE    = 2,    /* Visible to nobody */
} CCallocVisibility;

typedef struct CCallocTableProperties_st CCallocTableProperties;

struct CCallocTableProperties_st {
    FLAG_SET(CCallocTableFlags) flags;
    uint64_t          streamHandle; /* Only used under UVM-Lite */
};

/* Table functions */

/* Create an allocation table
 *  pTable : Pointer to returned allocated table
 */
CUresult CCallocTableCreate(CCallocTable **pTable, CCallocTableProperties *props);

/* Destroy an allocation table
 *  pTable : Pointer to table
 */
CUresult CCallocTableDestroy(CCallocTable **pTable);

/* Copy an allocation table (pDst will contain a full copy of every element in pSrc).
 *  pDst  : Pointer to allocated table
 *  src   : Source table
 *  props : Properties to set on the new table
 */
CUresult CCallocTableCopy(CCallocTable **pDst, CCallocTable *src, CCallocTableProperties *props);

/* Append all entries in pDst to pSrc
 *  dst  : Table to append to
 *  src  : Source table to add
 */
CUresult CCallocTableAppend(CCallocTable *dst, CCallocTable *src);

/* Apply a functor to the table
 *  table : Allocation Table to use
 *  fn    : Function pointer to apply
 *  data  : User provided data that is passed into the functor
 */
CUresult CCallocTableApplyFunctor(CCallocTable *table, CCallocTableFunctor fn, void *data);

/* Find allocation by address
 *  table : Allocation table to search in
 *  addr  : Address to search for
 *  pAlloc : Pointer to returned allocation. NULL if not found.
 */
CUresult CCallocTableFindByAddr(CCallocTable *table, uint64_t addr, CCalloc **pAlloc);

/* Add an allocation
 *  table : Allocation table
 *  alloc : Allocation to be added. (Will fail if an allocation overlaps existing maps)
 *  isAdded : Boolean, returns true if the allocation was added to the table
 */
CUresult CCallocTableAddAlloc(CCallocTable *table, CCalloc *alloc, bool *isAdded);

/* Remove an allocation
 *  table : Allocaton table
 *  addr  : Address to remove allocation at
 *  pAlloc : Pointer to allocation that has been removed
*/
CUresult CCallocTableRemoveAlloc(CCallocTable *table, uint64_t addr, CCalloc **pAlloc);

/* Check if a contiguous region [addr, addr + size - 1] has any allocations in it
 *  table : Allocation table
 *  addr  : Starting Address of region to test
 *  size  : Size of the region
 *  isClear : Boolean, returns true if no allocations exist in the table in that region
 */
CUresult CCallocTableRegionIsClear(CCallocTable *table, uint64_t addr, uint64_t size, bool *isClear);

/* Get the size of the allocation table
 *  table : Allocation table
 */
uint32_t CCallocTableGetSize(CCallocTable *table);

/* Dump allocation table. Only works on debug builds
 *  table : Allocation table
*/
void CCallocTableDump(CCallocTable *table);

/* Check if an allocation is using a compressed table
 *  table : Allocation table
 */
bool CCallocTableIsCoalesced(CCallocTable *table);

/* Check if an allocation table is read only
 *  table : Allocation table
 */
bool CCallocTableIsReadOnly(CCallocTable *table);

/* Check if an allocation table is external only
 *  table : Allocation table
 */
bool CCallocTableIsExternal(CCallocTable *table);

/* Allocation  functions */

/* Create an allocation
 *  pAlloc : pointer to created allocation
 *  addr   : start address
 *  size   : size of allocation
 *  flags  : bitmask of CC_ALLOC * flags
 *  name   : Name for named allocation (NULL for nonnamed)
 */
CUresult CCallocCreate(CCalloc **pAlloc, uint64_t addr, uint64_t size, uint32_t flags, const char *name);

/* Destroy an allocation
 *  pAlloc : Pointer to allocation to be destroyed
 */
CUresult CCallocDestroy(CCalloc **pAlloc);

/* Copy an allocation
 *  pDst : Pointer to cloned allocation
 *  src  : Source for the copy
 */
CUresult CCallocCopy(CCalloc **pDst, CCalloc *src);

/* Captures a host backtrace. */
CUresult CCallocCaptureHostBacktrace(CCalloc *alloc, CCBacktraceOptions *opts);

/* Set the flag bitmask
 *  This overwrites the old flag mask
 */
CUresult CCallocSetFlags(CCalloc *alloc, uint32_t flags);

/* Get the flag bitmask
 *  This overwrites the old flag mask
 */
uint32_t CCallocGetFlags(CCalloc *alloc);

/* Get the size of an allocation
 */
uint64_t CCallocGetSize(CCalloc *alloc);

/* Get the starting address of an allocation
 */
uint64_t CCallocGetStart(CCalloc *alloc);

/* Get the ending address of an allocation
 */
uint64_t CCallocGetEnd(CCalloc *alloc);

/* Get the name of an allocation
 */
const char* CCallocGetName(CCalloc *alloc);

/* Get the backtrace
 */
CCBacktrace* CCallocGetBacktrace(CCalloc *alloc);

/*  Set the visibility of an allocation
 */
CUresult CCallocSetVisibility(CCalloc *alloc, CCallocVisibility visType, uint64_t streamHandle);

/* Flag tests  */
bool CCallocIsNamed(CCalloc *alloc);
bool CCallocIsHeap(CCalloc *alloc);
bool CCallocIsInternal(CCalloc *alloc);
bool CCallocIsVisible(CCalloc *alloc, uint64_t streamHandle);
bool CCallocIsHostMapped(CCalloc *alloc);
bool CCallocIsManaged(CCalloc *alloc);
bool CCallocIsGlInterop(CCalloc *alloc);
bool CCallocIsHostRegistered(CCalloc *alloc);
bool CCallocIsHostPinned(CCalloc *alloc);
bool CCallocIsPeer(CCalloc *alloc);
bool CCallocIsPeerAtomic(CCalloc *alloc);

/* Check if an alloc contains a range fully */
bool CCallocContainsRange(CCalloc *alloc, uint64_t start, uint64_t size);

#endif
