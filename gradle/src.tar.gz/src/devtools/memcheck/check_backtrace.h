/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: check_backtrace.h
 *
 *   Description:
 *       Functions for generating a backtrace
 *
 ******************************************************************************/

#ifndef _CHECK_BACKTRACE_H
#define _CHECK_BACKTRACE_H

#include "cuda.h"
#include "cudamemcheck.h"
#include "check_core.h"
#include "halo.h"
#include "check_osal.h"

typedef enum {
    CC_BT_TYPE_NONE = 0,
    CC_BT_TYPE_HOST = (1 << 0),
    CC_BT_TYPE_DEVICE = (1 << 1),
} CCBacktraceTypes;

typedef enum {
    CC_BT_HOST_STATE_NONE = 0,
    CC_BT_HOST_STATE_INITIALIZED,
    CC_BT_HOST_STATE_CAPTURED,
    CC_BT_HOST_STATE_FRAMES_GENERATED,
} CCBacktraceHostStates;

typedef enum {
    CC_BT_DEV_STATE_NONE = 0,
    CC_BT_DEV_STATE_INITIALIZED,
    CC_BT_DEV_STATE_CAPTURING,
    CC_BT_DEV_STATE_CAPTURED,
    CC_BT_DEV_STATE_FRAMES_GENERATED,
} CCBacktraceDevStates;

typedef enum {
    CC_BT_FRAME_TYPE_NONE = 0,
    CC_BT_FRAME_TYPE_HOST,
    CC_BT_FRAME_TYPE_DEV,
} CCBacktraceFrameTypes;

typedef enum {
    CC_BT_FRAME_FLAG_NONE = 0,
    // Frame is in libcuda/libcudart
    CC_BT_FRAME_FLAG_CUDALIB   = (1 << 0),
    // Frame is a new module (entry frame)
    CC_BT_FRAME_FLAG_ENTRY     = (1 << 1),
    // Frame is inside a syscall
    CC_BT_FRAME_FLAG_SYSCALL   = (1 << 2),
    // Frame has debug info
    CC_BT_FRAME_FLAG_DEBUGINFO = (1 << 3),
    // Frame is junk, hide it
    CC_BT_FRAME_FLAG_CORRUPT   = (1 << 4),

    CC_BT_FRAME_FLAG_FORCE_SIZE = 0xFFFFFFFFU,
} CCBacktraceFrameFlags;

typedef struct CCBacktraceFrameDevice_st CCBacktraceFrameDevice;
typedef struct CCBacktraceFrameHost_st CCBacktraceFrameHost;
typedef struct CCBacktraceFrame_st CCBacktraceFrame;
typedef struct CCBacktraceHost_st CCBacktraceHost;
typedef struct CCBacktraceDevice_st CCBacktraceDevice;
typedef void* CCBacktraceStateHandle;

struct CCBacktraceFrameDevice_st {
    char *entryKernelName;
    uint64_t entryKernelAddr;

    char *moduleName;

    /* Debug info. Host frames get this from the frontend */
    char        *fileName;
    uint32_t    line;
};

struct CCBacktraceFrameHost_st {
    char        *libName;
    uint64_t    libBaseAddr;
};

struct CCBacktraceFrame_st {
    CCBacktraceFrameTypes type;
    CCBacktraceFrame *next;
    CCBacktrace *bt;
    FLAG_SET(CCBacktraceFrameFlags) flags;

    uint32_t frameDepth;
    uint32_t totalDepth;

    uint64_t addr;

    union {
        CCBacktraceFrameHost host;
        CCBacktraceFrameDevice dev;
    } cases;

    char        *funcName;
    uint64_t    funcBaseAddr;
};

struct CCBacktraceHost_st {
    CCBacktraceHostStates state;

    void **rawBuf;

    uint32_t depth;
    uint32_t maxDepth;

    uint64_t threadId;

    uint32_t refCount;

    CCBacktraceFrame *frameHead;
};

struct CCBacktraceDevice_st {
    CCBacktraceDevStates state;
    uint32_t depth;
    uint32_t maxDepth;
    uint32_t syscallDepth;

    MCcontext *mcctx;

    uint32_t devId;
    uint32_t vsm;
    uint32_t wp;
    uint32_t ln;

    uint32_t threadIdxX, threadIdxY, threadIdxZ;
    uint32_t blockIdxX, blockIdxY, blockIdxZ;

    uint64_t *rawBuf;

    uint32_t refCount;

    CCBacktraceFrame *frameHead;
};

struct CCBacktraceOptions_st {
    uint32_t maxHostDepth;
    uint32_t maxDevDepth;

    uint32_t enableHostBacktrace;
    uint32_t enableDevBacktrace;
};

struct CCBacktrace_st {
    CCBacktraceOptions opts;

    CCBacktraceDevice *dev;
    CCBacktraceHost *host;
};

/* Creates a backtrace object */
CUresult createBacktrace(CCBacktrace **ccbt, CCBacktraceOptions *opts);

/* Destroys a backtrace object */
CUresult destroyBacktrace(CCBacktrace **ccbt);

/* Capture a host backtrace */
CUresult captureHostBacktrace(CCBacktrace *ccbt);

/* Capture a device backtrace */
CUresult captureDeviceBacktrace(CCBacktrace *ccbt, MCcontext *mcctx, CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln);

/* Initialize flatten state */
CUresult initializeFrameGenerator(CCBacktraceStateHandle *pHandle);

/* Finalize flatten state */
CUresult finalizeFrameGenerator(CCBacktraceStateHandle *pHandle);

/* Generate the frames for the backtrace */
CUresult generateFrames(CCBacktrace *ccbt, CCBacktraceStateHandle handle);

/* To clone a backtrace's host component */
CUresult cloneBacktraceHost(CCBacktrace **pdst, CCBacktrace *src);

/* Debug functions */
void dumpBacktrace(CCBacktrace *ccbt);


#endif
