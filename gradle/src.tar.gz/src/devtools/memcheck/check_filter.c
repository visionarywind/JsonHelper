/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "check_filter.h"
#include "memcheck_types.h"
#include "halo.h"
#include "tools_shared_list.h"

typedef struct CCfilterData_st CCfilterData;

typedef enum {
    CC_FILTER_PHASE_NONE        = 0,
    CC_FILTER_PHASE_ON_LOAD     = 1,
    CC_FILTER_PHASE_ON_LAUNCH   = 2,

    /* Add new phases before this. Also update
       CCfilterMgrCheckPhaseMaskDone (and callers)
     */
    CC_FILTER_PHASE_SIZE,
} CCfilterPhase;

struct CCfilter_st {
    CCfilterDesc desc;
};

struct CCfilterMgr_st {
    tList *filters;
    uint32_t phaseMask;     /* Bitmask of phases (1 << CCfilterPhase) */
};

struct CCfilterData_st {
    MCfunc *func;
    MCrec *rec;
};

/* Globals */

/* Mask to determine which phase a filter flag falls into */
static uint32_t g_filterPhaseMasks[CC_FILTER_PHASE_SIZE] = { 0,
    CC_FILTER_FLAGS_KERNEL_NAME | CC_FILTER_FLAGS_KERNEL_NAME_EXACT,
    0
    };

/* Forward refs */
/* Filter handling */
static CUresult CCfilterClone(CCfilter **pDst, CCfilter *pSrc);
static CUresult CCfilterCreate(CCfilter **pFilter, CCfilterDesc *desc);
static CUresult CCfilterDestroy(CCfilter *filter);
static CUresult CCfilterTest(CCfilter *filter, uint32_t tests, CCfilterData *data, CCfilterMatch *match);

/* Filter Manager common functions */
static CUresult CCfilterMgrAddFilter(CCfilterMgr *filterMgr, CCfilter *filter);
static CUresult CCfilterMgrTest(CCfilterMgr *filterMgr, uint32_t tests, CCfilterData *data, CCfilterMatch *match);

/* Helpers */
static bool CCfilterMgrCheckPhaseMaskDone(CCfilterMgr *filterMgr, uint32_t phaseMask);

static void deleteFilterWrap(void *data, void *ignore)
{
    (void)CCfilterDestroy((CCfilter*)data);
}

static CUresult
CCfilterClone(CCfilter **pDst, CCfilter *src)
{
    CCfilter *dst = NULL;
    CUresult status = CUDA_SUCCESS;

    if (!pDst || !src) {
        CU_ERROR_PRINT(("Invalid params\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *pDst = NULL;

    status = CCfilterCreate(&dst, &src->desc);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to create filter\n"));
        return status;
    }

    *pDst = dst;

    return CUDA_SUCCESS;
}

static CUresult
CCfilterCreate(CCfilter **pDst, CCfilterDesc *desc)
{
    CCfilter *dst = NULL;

    if (!pDst || !desc) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    dst = (CCfilter*)calloc(1, sizeof(*dst));
    if (!dst) {
        CU_ERROR_PRINT(("Could not allocate dst filter\n"));
        return CUDA_ERROR_OUT_OF_MEMORY;
    }

    /* First do a blind copy */
    memcpy(&dst->desc, desc, sizeof(*desc));

    /* Now deep copy the pointers */
    if (desc->entryName) {
        dst->desc.entryName = (char *)malloc(desc->entryNameLen + 1);
        if (!dst->desc.entryName) {
            CU_ERROR_PRINT(("Failed to alloc entry name\n"));
            free(dst);
            return CUDA_ERROR_UNKNOWN;
        }
        memcpy(dst->desc.entryName, desc->entryName, desc->entryNameLen + 1);
    }

    *pDst = dst;

    return CUDA_SUCCESS;
}

static CUresult
CCfilterDestroy(CCfilter *filter)
{
    if (!filter)
        return CUDA_SUCCESS;

    free(filter->desc.entryName);
    filter->desc.entryNameLen = 0;
    free(filter);

    return CUDA_SUCCESS;
}


static CUresult
CCfilterMgrAddFilter(CCfilterMgr *filterMgr, CCfilter *filter)
{
    TOOLSresult tres = TOOLS_SUCCESS;
    uint32_t i = 0;

    if (!filterMgr || !filter) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    tres = toolsListAppend(filterMgr->filters, filter);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to add filter to list (tres=%u)\n", tres));
        return CUDA_ERROR_UNKNOWN;
    }

    /* Update the filter manager's phase masks */
    for (i = 0; i < CC_FILTER_PHASE_SIZE; ++i) {
        if (g_filterPhaseMasks[i] & filter->desc.flags) {
            filterMgr->phaseMask |= (1U << i);
        }
    }

    return CUDA_SUCCESS;
}

CUresult
CCfilterMgrCreate(CCfilterMgr **pFilterMgr)
{
    CCfilterMgr *mgr = NULL;

    CU_TRACE_FUNCTION();

    if (!pFilterMgr) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *pFilterMgr = NULL;

    mgr = (CCfilterMgr *)calloc(1, sizeof(*mgr));
    if (!mgr) {
        CU_ERROR_PRINT(("Cannot allocate filter mgr\n"));
        return CUDA_ERROR_OUT_OF_MEMORY;
    }

    mgr->filters = toolsListNew();
    if (!mgr->filters) {
        CU_ERROR_PRINT(("Failed to allocate filter list\n"));
        free(mgr);
        return CUDA_ERROR_OUT_OF_MEMORY;
    }

    *pFilterMgr = mgr;
    return CUDA_SUCCESS;
}

CUresult
CCfilterMgrDestroy(CCfilterMgr **pFilterMgr)
{
    CCfilterMgr *mgr = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!pFilterMgr) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    mgr = *pFilterMgr;

    if (!mgr)
        return CUDA_SUCCESS;

    tres = toolsListDelete(mgr->filters, deleteFilterWrap, NULL);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Tools list delete failed (tres=%u)\n", tres));
        return CUDA_ERROR_UNKNOWN;
    }

    free(mgr);
    *pFilterMgr = NULL;

    return CUDA_SUCCESS;
}

/* Does a deep copy */
CUresult
CCfilterMgrClone(CCfilterMgr **pDst, CCfilterMgr *src)
{
    CCfilterMgr *dstMgr = NULL;
    CUresult status = CUDA_SUCCESS;
    CCfilter *srcFilter, *dstFilter;
    tListItr *itr;

    CU_TRACE_FUNCTION();

    if (!pDst) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!src) {
        *pDst = src;
        return CUDA_SUCCESS;
    }

    status = CCfilterMgrCreate(&dstMgr);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to create dest filter manager\n"));
        return status;
    }

    for (itr = toolsListGetIterator(src->filters);
         itr;
         itr = toolsListGetNext(itr)) {
        srcFilter = (CCfilter*)toolsListGetElem(itr);

        status = CCfilterClone(&dstFilter, srcFilter);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to clone a filter\n"));
            break;
        }

        status = CCfilterMgrAddFilter(dstMgr, dstFilter);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to add new filter\n"));
            break;
        }
    }

    if (status != CUDA_SUCCESS)
        (void)CCfilterMgrDestroy(&dstMgr);
    else
        *pDst = dstMgr;

    return status;
}

uint64_t
CCfilterMgrGetCount(CCfilterMgr *filterMgr)
{
    if (!filterMgr)
        return 0;

    return (uint64_t)toolsListSize(filterMgr->filters);
}

CUresult
CCfilterMgrAddFilterByDesc(CCfilterMgr *filterMgr, CCfilterDesc *desc)
{
    CCfilter *filter;
    CUresult status = CUDA_SUCCESS;

    if (!filterMgr || !desc) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    status = CCfilterCreate(&filter, desc);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Invalid filter\n"));
        return status;
    }

    status = CCfilterMgrAddFilter(filterMgr, filter);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Unable to add filter\n"));
        return status;
    }

    return CUDA_SUCCESS;
}

static CUresult
CCfilterTest(CCfilter *filter, uint32_t tests, CCfilterData *data, CCfilterMatch *match)
{
    uint32_t i, ctr;

    if (!filter || !data || !match) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    for (i = 1, ctr = 0; i <= tests  && ctr < 31 ; i <<= 1, ctr++) {
        if (!(i & tests))
            continue;

        if (!(i & filter->desc.flags))
            continue;

        switch (i) {
        case CC_FILTER_FLAGS_KERNEL_NAME:
            if (!data->func) {
                CU_ERROR_PRINT(("Need func for FLAGS_NAME\n"));
                continue;
            }

            if (strstr(data->func->funcName, filter->desc.entryName) != NULL)
                *match = CC_FILTER_MATCH_ACCEPT;
            break;
        case CC_FILTER_FLAGS_KERNEL_NAME_EXACT:
            if (!data->func) {
                CU_ERROR_PRINT(("Need func for FLAGS_NAME_EXACT\n"));
                continue;
            }

            if (strlen(data->func->funcName) != filter->desc.entryNameLen)
                continue;

            if (strncmp(data->func->funcName, filter->desc.entryName, filter->desc.entryNameLen) == 0)
                *match = CC_FILTER_MATCH_ACCEPT;
            break;
        default:
            break;
        }
    }

    return CUDA_SUCCESS;
}

static CUresult
CCfilterMgrTest(CCfilterMgr *filterMgr, uint32_t tests, CCfilterData *data, CCfilterMatch *match)
{
    tListItr *itr;
    CCfilter *filter;
    CUresult status = CUDA_SUCCESS;

    if (!filterMgr || !data || !match) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* Trivial accept if no filters are present */
    if (toolsListSize(filterMgr->filters) == 0) {
        *match = CC_FILTER_MATCH_ACCEPT;
        return CUDA_SUCCESS;
    }

    for (itr = toolsListGetIterator(filterMgr->filters);
         itr;
         itr = toolsListGetNext(itr)) {
        filter = (CCfilter*)toolsListGetElem(itr);

        status = CCfilterTest(filter, tests, data, match);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Unable to test filter\n"));
            return status;
        }

        if (*match != CC_FILTER_MATCH_TEST) {
            return status;
        }
    }

    return CUDA_SUCCESS;
}

static bool
CCfilterMgrCheckPhaseMaskDone(CCfilterMgr *filterMgr, uint32_t phaseMask)
{
    if (!filterMgr)
        return 0;

    /* Check if any bits other than the ones in phaseMask are set.
       If not, the phaseMask is complete */
    return ((filterMgr->phaseMask & (~(phaseMask))) == 0);
}

CUresult
CCfilterMgrMatchOnLoad(CCfilterMgr *filterMgr, MCfunc *func, CCfilterMatch *match)
{
    CUresult status = CUDA_SUCCESS;
    CCfilterData data = {0};
    uint32_t flags = 0;

    if (!filterMgr || !func || !match) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *match = CC_FILTER_MATCH_TEST;

    /* Setup data */
    data.func = func;
    flags = CC_FILTER_FLAGS_KERNEL_NAME | CC_FILTER_FLAGS_KERNEL_NAME_EXACT;

    /* Load time tests (Ctx Id and function name) */
    status = CCfilterMgrTest(filterMgr, flags, &data, match);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed in filter tests\n"));
        return status;
    }

    /* If no other phase remains, and match is still test, set it to done */
    if (*match == CC_FILTER_MATCH_TEST &&
        CCfilterMgrCheckPhaseMaskDone(filterMgr, CC_FILTER_PHASE_ON_LOAD)) {
        *match = CC_FILTER_MATCH_REJECT;
        CU_DEBUG_PRINT(("Onload filter reject for %s.\n", func->funcName));
    }

    return CUDA_SUCCESS;
}

CUresult
CCfilterMgrMatchOnLaunch(CCfilterMgr *filterMgr, MCrec *rec, CCfilterMatch *match)
{
    CUresult status = CUDA_SUCCESS;
    CCfilterData data = {0};
    uint32_t flags = 0;

    if (!filterMgr || !rec || !match) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *match = CC_FILTER_MATCH_TEST;

    /* Setup data */
    data.func = rec->func;
    data.rec = rec;
    flags = CC_FILTER_FLAGS_NONE;;

    /* Run time tests (streamId and invocation count) */
    status = CCfilterMgrTest(filterMgr, flags, &data, match);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed in filter tests\n"));
        return status;
    }

    /* If the filter is still in match, and no other phase remains  */
    if (*match == CC_FILTER_MATCH_TEST &&
        CCfilterMgrCheckPhaseMaskDone(filterMgr, CC_FILTER_PHASE_ON_LOAD | CC_FILTER_PHASE_ON_LAUNCH)) {
        *match = CC_FILTER_MATCH_REJECT;
        CU_DEBUG_PRINT(("OnLaunch filter reject for %s.\n", rec->func->funcName));
    }

    return CUDA_SUCCESS;
}

