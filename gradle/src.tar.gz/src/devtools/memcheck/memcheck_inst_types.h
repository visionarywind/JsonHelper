/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: memcheck_inst_types.h
 *
 *   Description:
 *       Patchable instruction types for memcheck
 *
 ******************************************************************************/

#ifndef _MEMCHECK_INST_TYPES_H
#define _MEMCHECK_INST_TYPES_H

#include "cuda_etbl/tools_module.h"
#include "cudamemcheck.h"
#include "check_ir.h"

// Typedefs
typedef struct MCinstOpState_st         MCinstOpState;
typedef struct MCcheckTypeState_st      MCcheckTypeState;
typedef struct MCinstManagerState_st    MCinstManagerState;
typedef struct MCcheckType_st           MCcheckType;
typedef struct MCinstOp_st              MCinstOp;

typedef enum {
    // MC_CHECK_TYPE_NONE must always be 0 and the first element
    MC_CHECK_TYPE_NONE       = 0,
    MC_CHECK_TYPE_GLOBAL,
    MC_CHECK_TYPE_SHARED,
    MC_CHECK_TYPE_LOCAL,
    MC_CHECK_TYPE_RACE,
    MC_CHECK_TYPE_BARCHECK,
    MC_CHECK_TYPE_INITCHECK,

    // Add new patch types before this line
    MC_CHECK_TYPE_SIZE,
    MC_CHECK_TYPE_FORCE_SIZE    = 0xFFFFFFFFU,
} MCcheckTypes;

// State structs

struct MCinstOpState_st {
    MCcheckType     *checkType;    // Pointer to the type
};

struct MCcheckTypeState_st {
    uint32_t        toolOpMask;    // Mask of instOps from tool
    uint32_t        minLmem;       // Local mem usage for this patch
    uint32_t        minRegs;       // Minimum number of registers needed
    uint32_t        minBarriers;   // Minimum number of barriers needed
    uint32_t        minSharedMem;  // Minimum Shared memory
    MCcheckTypes    type;          // Of type MCcheckType
    uint32_t        enableAbi;     // For dynamic memcheck
    uint32_t        prologueSize;  // Prologue patch size

    // Array containing all the opcodes for this type
    MCinstOp   *instOps[CCIR_INST_OPCODE_SIZE];

    // Pointers to other structures
    MCinstManager   *manager;      // Pointer to the manager structure
};

struct MCinstManagerState_st {
    uint32_t        toolTypeMask;   // Mask of checkTypes from tool
    uint32_t        enabledTypes;   // Enabled inst types (mask of 1 << type)
    uint32_t        sm_version;     // Architecture for this manager
    MCcheckType     *checkTypes[MC_CHECK_TYPE_SIZE]; // All initialized types
    uint32_t        errorEntrySize; // Size of an error record

    // Parent context
    MCcontext       *mcctx;         // Pointer to the context
};

// HAL structures

struct MCinstManager_st {
    // State
    MCinstManagerState  state;

    // Initialization
    CUresult    (*initialize)           (MCinstManager *instMgr);
    CUresult    (*finalize)             (MCinstManager *instMgr);

    // Read back the new lmem and reg usage for all patches
    uint32_t    (*getMinLmem)           (MCinstManager *instMgr);
    uint32_t    (*getMinRegs)           (MCinstManager *instMgr);

    // Get size (common + per inst patches)
    uint32_t    (*getPatchSize)         (MCinstManager *instMgr, MCrec *rec);

    // Get the size of the error entries
    uint32_t    (*getErrorEntrySize)    (MCinstManager *instMgr, MCrec *rec);

    // Call to change the state, based on ABI enable flag
    CUresult    (*updateState)          (MCinstManager *instMgr, uint32_t enableAbi);

    // Patch the whole function
    CUresult    (*createPatch)          (MCinstManager *instMgr, MCrec *rec);

    // Create Host allocations (check table etc)
    CUresult    (*createAllocs)         (MCinstManager *instMgr, MCrec *rec);

    // Cleanup Host allocations
    CUresult    (*destroyAllocs)        (MCinstManager *instMgr, MCrec *rec);

    // Increase the local memory for patch/minimum number of registers
    CUresult    (*updateLaunchConfig)   (MCinstManager *instMgr, CUtoolsFunctionLaunchConfig *config);

    // Parse the error entry
    CUresult    (*parseErrorEntry)      (MCinstManager *instMgr, MCrec *rec, CUmemcheck_record *err, uint32_t *hasError);

    CUresult    (*printCubin)           (MCinstManager *instMgr, char *name, const uint64_t *code, uint64_t size);
};

struct MCcheckType_st {
    // State for the type
    MCcheckTypeState state;

    // Initialize/finalize
    // This will point to arch specific initialization
    CUresult    (*initialize)           (MCcheckType *checkType);
    CUresult    (*finalize)             (MCcheckType *checkType);

    // Query functions to return information directly from the state
    uint32_t    (*getMinLmem)           (MCcheckType *checkType);
    uint32_t    (*getMinRegs)           (MCcheckType *checkType);

    // Check if the instruction is a target for this patch type
    // Will call the target function for each InstOp
    CCIRinstOpcodes   (*isInstructionTarget)  (MCcheckType *checkType, const uint64_t *op);

    // Increase the local memory for patch/minimum number of registers
    CUresult    (*updateLaunchConfig)   (MCcheckType *checkType, CUtoolsFunctionLaunchConfig *config);

    CUresult    (*printCubin)           (MCcheckType *checkType, char *name, const uint64_t *code, uint64_t size);

    // Create Host allocations (check table etc)
    CUresult    (*createAllocs)         (MCcheckType *checkType, MCrec *rec);

    // Cleanup Host allocations
    CUresult    (*destroyAllocs)        (MCcheckType *checkType, MCrec *rec);

    // ARCH specific

    // Call to change the state, based on ABI enable flag
    // Mainly used on Fermi+ to enable dynamic memcheck
    CUresult    (*updateState)          (MCcheckType *checkType, uint32_t enableAbi);

    // Size of the patch for the whole function for this patchtype
    uint32_t    (*getPatchSize)         (MCcheckType *checkType, MCrec *rec);

    // Per instruction patch generation (i.e. per LD/ST stub)
    CUresult    (*createPatch)          (MCcheckType *checkType, MCrec *rec);

    // Parse the error entry
    CUresult    (*parseErrorEntry)      (MCcheckType *checkType, MCrec *rec, CUmemcheck_record *err, uint32_t *hasError);

    union toolMode_checkType_st {
        struct memcheck_checkType_st {
            /* Memcheck specific checkType functions */
            uint64_t*   (*genRangeCheck)        (MCcheckType *checkType,
                                                 MCrec *rec, uint64_t *patchCode);
            uint32_t    (*getRangeCheckSize)    (MCcheckType *checkType, MCrec *rec);
            uint32_t    (*getCheckEntryOffset)  (MCcheckType *checkType,
                                                 CCIRinstOpcodes type, MCrec *rec);
            uint64_t*   (*genStubJcal)          (MCcheckType *checkType, MCrec *rec,
                                                 CCIRinstOpcodes instType,
                                                 uint64_t *patchCode,
                                                 uint32_t checkTarget,
                                                 uint32_t instrAddr);
            uint32_t    (*getStubJcalSize)      (MCcheckType *checkType, MCrec *rec,
                                                 CCIRinstOpcodes instType);
            uint64_t*   (*genAlignCheck)        (MCcheckType *checkType, MCrec *rec,
                                                 uint64_t *patchCode,
                                                 uint64_t *patchStart);
            uint32_t    (*getAlignCheckSize)    (MCcheckType *checkType, MCrec *rec);
            uint64_t*   (*genFinalizeCheck)     (MCcheckType *checkType, MCrec *rec,
                                                 uint64_t *patchCode,
                                                 uint64_t *patchStart);
            uint32_t    (*getFinalizeCheckSize) (MCcheckType *checkType, MCrec *rec);
        } mem;
    } tm;

};

struct MCinstOp_st {
    // State for the op
    MCinstOpState state;

    // Check if the instruction is a target for this patch type
    bool        (*isInstructionTarget)  (const uint64_t *inst);
};

// Functions for bootstrapping initialization
CUresult initializeTypeManager(MCcontext *mcctx, MCinstManager **pInstManager);
CUresult finalizeTypeManager(MCcontext *mcctx, MCinstManager **pInstManager);

// Default initializations
CUresult default_initTypeManager(MCcontext *mcctx, MCinstManager *instManager);
CUresult default_initCheckType(MCinstManager *instMgr, MCcheckType *type, MCcheckTypes typeEnum);

// Function to tie the instops to the hal
MCinstOp *createInstOp(MCcheckType *checkType, CCIRinstOpcodes instType);

#endif

