/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef SCHEME_GLOBALLOCK_CU
#define SCHEME_GLOBALLOCK_CU

#define SCHEME_GLOBALLOCK_PREFIX __cuda_syscall_mc_dyn_globallock_

#include "schemes_globallock.cuh"

/* The globallock scheme.
    New scheme for memory checking. Uses 1 bit per byte of heap space.
    This scheme is meant to provide comprehensive Valgrind like checking.
    This is done by maintaining an extra tracking array, in which each bit
    represents one byte of the device heap. A value of 0 in the tracking
    array represents that the corresponding byte has not been allocated.
    Similarly, a value of 1 represents that the corresponding byte has
    been allocated.

    At the time of heap creation, the state of the entire array is marked
    unallocated. At each malloc() call, the internal call to malloc is made.
    The returned range is then marked allocated in the tracking vector. Finally
    control is returned. Similarly at every free, the corresponding bit range is
    marked free before free is called. On every access, the bits for the access
    are checked.

    To handle race conditions from multiple threads accessing the backing tracking
    structure, the entire structure can be accessed by only one thread, which grabs
    a global lock before any access. Technically, assuming that the malloc can
    handle multiple threads, the locking is only needed on free. The lock
    contention depends solely on the number of simultaneous calls to free.


    Assumptions:
    1. Activate is called by the heap created callback, before any launch.
    2. Any allocation returned by malloc is preceeded by at least one byte of
      tracking data, which remains invisible to the malloc() call.

    Caveats:
    1. Global lock : Incredibly slow.
    2. Needs a large amount of device memory (1/8th size of heap + 32 bytes)

    Future Features (Currently disabled):

    1. This scheme also supports malloc/free error reporting.
    On every malloc/free, errors in the allocator such as double free are reported.
    As some host side work is also needed, this is currently disabled.

    2. Leak checking. Since every allocation is known at a byte accurate level
    it becomes possible to track the number of bytes that have been leaked.

    3. Host side checking. We could update the structure in a lock free manner
    from the host to handle cases where the driver supports cudaMemcpy'ing
    directly into the heap.


 */

#define WORD_SIZE_IN_BITS 32U
#define WORD_SIZE_LOG2 5U
#define WORD_SIZE_BYTE_LOG2 2U
#define FULL_WORD_MASK 0xFFFFFFFFU

__constant__ globalLockDevData *globalLockDevDataPtr;

__device__ static MCSCresult
mallocCheck(uint32_t trackWord, uint32_t mask)
{
    if (!mask)
        return MC_SC_ERROR_NONE;

    /* Do all the malloc checks here */
    if (trackWord & mask) {
        /* In this case, malloc has returned a pointer to already
           initialized data. Most likely due to heap state corruption.
           The macro will write the reason code and trap. */
        return MC_SC_ERROR_HEAP_CORRUPTION;
    }

    return MC_SC_ERROR_NONE;
}

__device__ static MCSCresult
freeCheck(uint32_t trackWord, uint32_t mask)
{
    /* Mask can be 0 here, which is a double free case */

    /* Do the free checks here */
    if ((trackWord & mask) == 0) {
        /* Already freed */
        return MC_SC_ERROR_DOUBLE_FREE;
    }
    else if ((trackWord & mask) != mask) {
        /* Most likely heap corruption */
        return MC_SC_ERROR_HEAP_CORRUPTION;
    }

    return MC_SC_ERROR_NONE;
}

__device__ static MCSCresult
earlyFreeCheck(uint32_t *tracker, uint64_t wd_off, uint32_t bit_off)
{
    uint32_t mask = 0;

    if (!bit_off && !wd_off) {
        /* Should be impossible, (no padding) */
        return MC_SC_ERROR_FREE_BAD_PTR;
    }

    /* Check 1 : Does the pointer point to an initialized byte */
    if ((tracker[wd_off] & (1U << bit_off)) == 0) {
        /* Either pointer is invalid or already freed */
        return MC_SC_ERROR_DOUBLE_FREE;
    }

    if (!bit_off) {
        /* Roll into previous word */
        --wd_off;
        bit_off = WORD_SIZE_IN_BITS - 1;
    }
    else
        --bit_off;

    mask = 1U << (bit_off);

    /* Check 2 : Was the initialized byte preceeded by a free byte */
    if (tracker[wd_off] & mask) {
        /* Pad bit is missing. Means the pointer to free was in the
           middle of an allocation */
        return MC_SC_ERROR_FREE_BAD_PTR;
    }

    return MC_SC_ERROR_NONE;
}

/*  The below flag enables header padding at compile time.
    This causes each allocation to be preceeded by a header pad
    that contains the size of the allocation. This allows the scheme to:
    1. Force the separation of allocations by at least 1 byte
    2. Allow free() to know the size of the allocation.

    Currently this flag is disabled.
*/
#define GLOBALLOCK_PAD_SIZE 16 /* in bytes. Must be 16: alignment requirement */

#ifdef GLOBALLOCK_USE_HEAP_PAD

__device__ static uint32_t
getFreeSize(void *ptr)
{
    /* Roll pointer back 4 bytes */
    char *cptr =(char*)ptr;
    uint32_t ret = 0;

    if (!cptr)
        return 0;

    if (!(cptr-1) || !(cptr-2) || !(cptr-3) || !(cptr-4))
        return 0;

    /* Ptr may not be aligned */
    switch (GLOBALLOCK_PAD_SIZE){
        default :
        case 4: ret |= ((*(cptr - 4)) << 24);
        case 3: ret |= ((*(cptr - 3)) << 16);
        case 2: ret |= ((*(cptr - 2)) << 8);
        case 1: ret |= (*(cptr - 1));
            break;
        case 0: break;
    };
    return ret;
}

__device__ void*
writePad(void *ptr, uint32_t size)
{
    char *cptr = ptr;
    void *endptr = (void*)((char*)ptr + GLOBALLOCK_PAD_SIZE);

    /* Just write in the pad and move on */
    if (!cptr)
        return;

    switch (GLOBALLOCK_PAD_SIZE) {
        default :
        case 4: *cptr++ = (size >> 24) & 0xFF;
        case 3: *cptr++ = (size >> 16) & 0xFF;
        case 2: *cptr++ = (size >> 8) & 0xFF;
        case 1: *cptr++ = (size & 0xFF);
            break;
        case 0: break;
    };

    return endptr;
}

#endif

/* getFreeMask is invoked when free is called without a known size.
    In this case, the tracking bitvector is walked one word at a time.
    Every allocation in the bitvector can be thought of as a bit string
    ordered from LSB to MSB consisting of continuous 1's. Neighboring
    allocations are separated by at least one byte (which shows up as a
    0). A word sized bit mask is applied to the tracking bitvector
    to ensure that only relevant words are being read.

    The purpose of getFreeMask is to return the actual mask that
    needs to be used by looking at the value of the tracking vector.
    The getFreeMask function is called for each word of the tracking
    vector being scanned, with two parameters : The word from the
    tracker and the mask that updateTracker has estimated.
    Given these two inputs, the function will return the mask
    that should be applied to the tracking bitvector.

    It needs to consider 4 cases :
    1. The mask the first tracking word for an allocation
    2. The mask is a middle tracking word for an allocation
    3. The mask is the final tracking word for an allocation
    4. The mask is only one word long and is both the first
       and last tracking word for the allocation. This is a special case.

    The first word mask is unique in that the tracker can generate
    it without having to call getFreeMask (except in the single word case).
    The final word mask is the mask that we want the function to generate.
    The middle masks are cases we want to handle quickly for performance.
    In the particular case that the allocation is only one word long, the
    first and last word masks need to computed in such a way that the
    function will return the correct mask.

    For any allocation, there will always be only exactly one
    first and final word masks. There may be any number of middle word masks.

    Consider the following illustrative example:

    Example I : (handling cases 1, 2, 3)
    A 64 byte allocation would look as follows in the tracking vector.

               MSB                          LSB
               Word 2        Word 1      Word 0
    tracker    xxx0FFFF    FFFFFFFF    FFFF0000

    In this case, Word 0 is the starting word of the allocation.
    Word 1 is the middle word of an allocation and Word 2 is the
    ending word.

    In the bit vector above - represents bits that we do not know
    about, that may be 1 or 0.

    Iteration 0 : Word 0
    --------------------

    When looking at word 0, the updateTracker function will seed this
    with a starting word mask of: 0xFFFF0000. The starting word
    mask is given as the oldMask input.

    In this case, the getFreeMask function will return the bit
    mask using the early return.

               MSB                          LSB
               Word 2        Word 1      Word 0
    tracker    xxx0FFFF    FFFFFFFF    FFFF0000
    oldMask                            FFFF0000
    -------------------------------------------
    return:                            FFFF0000


    Iteration 1 : Word 1
    --------------------

    Word 1 is a middle word. Again, due to the early evaluation,
    the function will return the same mask. This time around, the
    updateTracker function will present the default mask of all 1's
    as the input oldMask

               MSB                          LSB
               Word 2        Word 1      Word 0
    tracker    xxx0FFFF    FFFFFFFF    FFFF0000
    oldMask                FFFFFFFF    FFFF0000
    -------------------------------------------
    return:                FFFFFFFF    FFFF0000

    Iteration 3 : Word 2
    --------------------

    Word 2 is the final word. This is the case where a bulk of the
    computation will happen. The oldMask input is the default mask
    containing all 1's.

    Since the early evaluation fails, we continue to do computation.
    We first compute newVal to handle the case where the oldMask is
    not the default mask. For the sake of clarity, the below is using
    the full bit representation of the tracker word 2.

    The main computation here is :
                tmpVal = ((~newVal) ^ ((~newVal) - 1));

    This provides us a bitmask where only the run of ones in the LSB
    remain. In other words, it allows us to ignore the bits that are
    x's in the MSB of the final word, as they belong to a different
    allocation.


    tracker         xxxx xxxx xxxx 0000 1111 1111 1111 1111
    -------------------------------------------------------
    ~tracker        yyyy yyyy yyyy 1111 0000 0000 0000 0000  (where y = x')
    ~tracker - 1    yyyy yyyy yyyy 1110 1111 1111 1111 1111
    -------------------------------------------------------
    tmpVal          0000 0000 0000 0001 1111 1111 1111 1111
    -------------------------------------------------------

    The next computation that needs to be performed is that the leading bit
    of tmpVal must be cropped off as it was not in the original mask.

                  return = tracker & tmpVal

    tmpVal          0000 0000 0000 0001 1111 1111 1111 1111
    tracker         xxxx xxxx xxxx 0000 1111 1111 1111 1111
    -------------------------------------------------------
    return          0000 0000 0000 0000 1111 1111 1111 1111

    At this point, we have a bit mask that has only the bits corresponding
    to the current allocation set. To fill that into the table, we get :

               MSB                          LSB
               Word 2        Word 1      Word 0
    tracker    xxx0FFFF    FFFFFFFF    FFFF0000
    oldMask    FFFFFFFF    FFFFFFFF    FFFF0000
    -------------------------------------------
    return:    0000FFFF    FFFFFFFF    FFFF0000


    Example II : Covering case 4
    ----------------------------

    There are special circumstances when the affected word is both the
    first and the final word in the tracking vector. In this case, since
    the first word mask is known, we use that to convert the input into
    case 3 (i.e. the final word of a mask). This transformation is then
    inverted as a final step.

    Consider, if we had the following inputs. For the sake of convenience
    this is shown in bit representation. The alphabets x and u represent
    bits that we do not know about that may belong to other allocations.

    tracker         xxxx xxxx xxxx 0000 1111 1111 1100 uuuu
    oldMask         1111 1111 1111 1111 1111 1111 1100 0000

    We first transform this to case 3 by applying :

                newVal = tracker | (~oldMask)

    oldMask         1111 1111 1111 1111 1111 1111 1100 0000
    -------------------------------------------------------
    ~oldMask        0000 0000 0000 0000 0000 0000 0011 1111
    tracker         xxxx xxxx xxxx 0000 1111 1111 1100 uuuu
    -------------------------------------------------------
    newVal          xxxx xxxx xxxx 0000 1111 1111 1111 1111

        Now, we compute the mask as in case 3 :

                tmpVal = (~newVal) ^ (~newVal - 1)

    newVal          xxxx xxxx xxxx 0000 1111 1111 1111 1111
    -------------------------------------------------------
    ~newVal         yyyy yyyy yyyy 1111 0000 0000 0000 0000  (where y = x')
    ~newVal - 1     yyyy yyyy yyyy 1110 1111 1111 1111 1111
    -------------------------------------------------------
    tmpVal          0000 0000 0000 0001 1111 1111 1111 1111

                mask = newVal & tmpVal
    tmpVal          0000 0000 0000 0001 1111 1111 1111 1111
    newVal          xxxx xxxx xxxx 0000 1111 1111 1111 1111
    -------------------------------------------------------
    mask            0000 0000 0000 0000 1111 1111 1111 1111


    As a final step, we need to undo the transformation that
    was performed to make case 4 into case 3, thereby making
    sure the final mask to be returned includes information
    about the start offset that was presented as input.

                return = mask & oldMask

    mask            0000 0000 0000 0000 1111 1111 1111 1111
    oldMask         1111 1111 1111 1111 1111 1111 1100 0000
    -------------------------------------------------------
    return          0000 0000 0000 0000 1111 1111 1100 0000


*/
__device__ static uint32_t
getFreeMask(uint32_t tracker, uint32_t oldMask)
{
    uint32_t newMask = oldMask;
    uint32_t newVal = 0;
    uint32_t tmpVal = 0;

    /* Early return for case 1 and case 2 above (starting word
       and a middle word mask). In the case that the allocation
       happens to align to a tracking word boundary (i.e.
       is aligned to 32 bytes), this will also be the return
       for case 3. Case 4 may also return here if the allocation
       is 32 bytes long and is aligned on a 32 byte boundary. */
    if ((tracker & oldMask) == oldMask)
        return oldMask;

    /* Case 3 and Case 4 drop in here : */
    /* This step will convert case 4 into case 3, or,
       it will make sure that the word is such that low bits that
       do not matter are all set to 1.

       It is only needed for case 4, but since case 4
       will be common for small allocations, the cost of adding
       a compare and jump was judged to not be worth it. */

    newVal = tracker | (~oldMask);

    /* This is needed for both case 3 and 4 and computes the mask such that
       all bits above the first 0 (from the LSB) are cleared.
       As discussed before, tmpVal will contain one extra bit set.
       In more technical terms, the next statement will generate a
       bitmask where the lowest N + 1 contiguous bits are set as long
       as that was the case in the masked value.
       Consider the logic as follows :
       For a run of N 1's in the LSB, the corresponding N+1 bits in the
       complement will be 1 followed by N zeros.
       When one is subtracted from the complement, the lower N+1 bits
       will become identical to the  N+1 bits of the original value
       However, the upper bits (i.e. 32 - N+1) of the complement and
       the complement - 1 are the same. XOR'ing these will nuke these
       bits and therefore, all thats left are the bottom N bits of
       the original, and one extra bit (the N+1'th bit).
    */
    tmpVal = ((~newVal) ^ ((~newVal) - 1));

    /* The next line is performing two computations at once.
       The first one is the removal of the extra bit in the tmpVal
       mask using the original word. This is needed for both case 3
       and case 4. This computation is :
             newMask = (tmpVal & newVal);

       The second part of the computation performs the inverse
       of the transformation for converting case 3 into case 4.
       This can be expanded as :
            newMask = newMask & oldMask;
    */
    newMask = (tmpVal & newVal) & oldMask;

    return newMask;
}

__device__ static MCSCresult
updateTracker(void *malloc_ptr, uint64_t size, uint8_t set)
{
    uint64_t start_word_offset = 0;
    uint32_t start_bit_offset = 0;
    uint32_t end_bit_offset_r = 0;
    uint32_t start_word_mask = FULL_WORD_MASK;
    uint32_t end_word_mask = FULL_WORD_MASK;

    uint64_t num_words = 0;
    uint32_t mask = FULL_WORD_MASK;

    uint64_t heap_base = 0;
    uint64_t malloc_addr = 0;
    uint64_t malloc_offset = 0;

    uint32_t *tracker = NULL;
    uint64_t tracker_size = 0;
    uint64_t i = 0;
    uint32_t old_val = 0;
    MCSCresult res = MC_SC_ERROR_NONE;

    heap_base = globalLockDevDataPtr->heapDptr;
    tracker = (uint32_t*)(uintptr_t)globalLockDevDataPtr->trackDptr;
    tracker_size = globalLockDevDataPtr->trackSize;

    malloc_addr = (uint64_t)(uintptr_t)malloc_ptr;
    malloc_offset = malloc_addr - heap_base;

    /* The section below is to compute the number of bytes to reset
       Conceptually, the setting code can be thought of as follows:
       for (i = 0; i < num_words; ++i) {
         mask = ~0U;
         if (i == 0)
           mask = start_mask;
         if (i == num_bytes - 1)
           mask = end_mask
         if (set)
           tracker[i] |= (mask);
         else
           tracker[i] &= (uint32_t)(~mask);
        }

        Where:
          num_words is the number of affected bytes in the tracker
          start_mask is the mask of affected bits in the first word
          end_mask is the mask of affected bits in the last word
          set is a boolean (when 1, tracking bits are set, when 0 they are cleared)

        This means that the primary complexity is in computing the affected
        bytes of the tracker.

        Affected word computation:
        We compute affected word as follows (32 == word size):
        num_words = (start_bit_offset + len) / 32
        if ((start_bit_offset + len ) % 32) ++num_words
        if (start_bit_offset) -> needs start mask
        if ((start_bit_offset + len) % 32) -> needs end mask

        Illustrative example:
        Consider the degenerate case, where an allocation of is 34 bytes long,
        and starts at an address that is 31 bytes in. In this scenario, the
        tracking vector looks as below:

            Word 0 : 0x80000000 // MSB
            Word 1 : 0xFFFFFFFF
            Word 2 : 0x00000001 // LSB
        This affects 3 words, and the begin and end words need a mask.
    */

    /* start_word_offset = malloc_offset / 32 */
    start_word_offset = (malloc_offset >> WORD_SIZE_LOG2);

    /* start_bit_offset = malloc_offset % 32 */
    start_bit_offset = (uint32_t)(malloc_offset & (WORD_SIZE_IN_BITS - 1));

    /* An early check for frees */
    if (set == 0) {
        /* Do an early check for frees */
        res = earlyFreeCheck(tracker, start_word_offset, start_bit_offset);
        if (res != MC_SC_ERROR_NONE)
            return res;
#ifdef  GLOBALLOCK_USE_HEAP_PAD
        size = getFreeSize(malloc_ptr);
#endif
    }

    if (size) {
        /* For this bit, we need to know the size we are checking.
           This means, either we are in a malloc (size is known)
           or this was called by a free that has the pad writing
           enabled. We can use the size information to compute
           the end word mask and the number of affected words */
        /* end_bit_offset_r = (start_bit_offset + size) % 32 */
        end_bit_offset_r = (uint32_t)((start_bit_offset + size) & (WORD_SIZE_IN_BITS - 1));

        /* Generate end mask */
        end_word_mask = (uint32_t)(~(FULL_WORD_MASK << end_bit_offset_r));

        /* Compute the number of affected words. We will affect at least
           one word. Above that, we will affect at least "size" bits (as
           1 byte affects 1 bit). To compute the words this contributes
           add the size to the starting bit offset and divide by the
           tracking vector word size  */
        num_words = 1 + ((start_bit_offset + size) >> WORD_SIZE_LOG2);

    }
    else {
        /* The size is unknown. This is hit by free() with the heap padding
           disabled. In this case, the number of affected words is assumed to
           be the worst case maximum (till the end of the tracker). Since
           tracker_size is in bytes, we need to compute the number of words
           of interest */
        num_words = (tracker_size >> WORD_SIZE_BYTE_LOG2) - start_word_offset;
    }

    /* Generate the start mask */
    start_word_mask = (uint32_t)(FULL_WORD_MASK << start_bit_offset);

    /* The main set/reset loop */
    for (i = 0; i < num_words; ++i) {
        mask = FULL_WORD_MASK;
        if (i == 0)
            mask &= start_word_mask;

        /* Note the below will AND into the mask to do single word accesses.
           This only works when size is known (i.e. malloc, padded heap) */
        if (size && (i == num_words - 1))
            mask &= end_word_mask;

        if (set) {
            /* Handle the malloc checks and update */
            old_val = atomicOr(&tracker[i + start_word_offset],  mask);
            res = mallocCheck(old_val, mask);
            if (res != MC_SC_ERROR_NONE)
                return res;
        }
        else {
            /* Note : There is a race here, which is why we need to lock on free()
               Between the time the freeMask is read and the time the tracker is
               actually reset, another thread could have done the same free. In
               this case, we report an incorrect double free without the lock  */
            if (!size) {
                /* For a non padded free, we need to find the new
                   mask by adjusting the existing mask and looking
                   for runs of 1 */
                mask = getFreeMask(tracker[i + start_word_offset], mask);

                /* Done when we run out of valid masks. This can happen
                   when the allocation ended on a 32 byte aligned boundary
                   This will cause the final mask to have its high bit set.
                   The query for the mask on the next word will fail
                   as its lowest bit is a 0. */
                if (!mask)
                    break;
            }
            /* Handle the free checks and updates */
            old_val = atomicAnd(&tracker[i + start_word_offset], ~mask);
            res = freeCheck(old_val, mask);
            if (res != MC_SC_ERROR_NONE)
                return res;

            /* If the size of the allocation is not known on doing a free
               and if the MSB of the current mask is not set, then this word
               is the last word for the allocation. */
            if (!size && (!(mask & (1U << (WORD_SIZE_IN_BITS - 1)))))
                break;
        }
    }
    return MC_SC_ERROR_NONE;
}

/* This declaration expands to
void *mc_dyn_globallock_malloc(size_t len)
*/
MALLOC_DECL(SCHEME_GLOBALLOCK_PREFIX)
{
#if defined(__CUDA_ARCH__)
    void *malloc_ptr = NULL;
    size_t size = 0;
    uint64_t len64 = 0;
    uint64_t ptr64 = 0;
    MCSCresult res = MC_SC_ERROR_NONE;

    if (!len) {
        return NULL;
    }

    if (!globalLockDevDataPtr) {
        return NULL;
    }

    size = len;
    len64 = (uint64_t)len;

    /*
     * We want to add the pad even if we don't intend to use it to track allocations.
     * This is to fix cuda-memcheck issues with the new HMA device-side allocator.
     */
    size += GLOBALLOCK_PAD_SIZE;

    /* The real malloc */
    malloc_ptr = malloc(size);

    if (!malloc_ptr)
        return NULL;

#ifdef GLOBALLOCK_USE_HEAP_PAD
    malloc_ptr = writePad(malloc_ptr, len64);
#endif

    ptr64 = (uint64_t)(uintptr_t)malloc_ptr;

    mc_dyn_ide_di();
    res = updateTracker(malloc_ptr, len64, 1);
    mc_dyn_ide_en();

    if (res != MC_SC_ERROR_NONE) {
        MEMCHECK_SYSCALL_REPORT(res, ptr64, len64);
    }

    return malloc_ptr;
#else
    return NULL;
#endif
}

/* This declaration expands to
void mc_dyn_globallock_free(void *ptr)
*/
FREE_DECL(SCHEME_GLOBALLOCK_PREFIX)
{
#if defined(__CUDA_ARCH__)
    MCSCresult res = MC_SC_ERROR_NONE;
    uint64_t ptr64 = 0;
    volatile uint32_t *atomLoc = NULL;
    uint32_t oldLock = 0;
    uint32_t wp_mask = 0;
    uint32_t t_mask = 0;
    bool lockDone = false;

    if (!ptr)
        return;

    atomLoc = &globalLockDevDataPtr->lock;
    wp_mask = __activemask();
    do {
        if (!lockDone) {
            oldLock = atomicAdd((unsigned int*)atomLoc, 1);
            if (!oldLock) {
                /* begin critical section */
                res = updateTracker(ptr, 0, 0);
                /* end critical section */
                lockDone = true;
            } else {
                lockDone = lockDone;
            }
            (*atomLoc) = 0;
        } else {
            lockDone = true;
        }
        t_mask = __ballot_sync(wp_mask, lockDone);
    } while(t_mask != wp_mask);

    if (res != MC_SC_ERROR_NONE) {
        ptr64 = (uint64_t)(uintptr_t)ptr;
        MEMCHECK_SYSCALL_REPORT(res, ptr64, 0);
    }

#ifdef GLOBALLOCK_USE_HEAP_PAD
    ptr = (void*)((char*)ptr - GLOBALLOCK_PAD_SIZE);
#endif

    free(ptr);
#else
#endif
}

/* Check function : Called for every heap access by the memcheck
   patch code, when dynamic memcheck is active.

   Parameters : addr : 64 bit address being accessed.
                        This address is guarenteed to be inside the
                        heap allocation (so accesses are legal)
                iaddr : 64 bit address of the original instruction
                amask : 32 bit mask to check alignment of access.
                        This is the access_size - 1

   Return value : uint32_t : This function will return 0 if the
                             access is safe. A non zero return
                             value will cause memcheck to report
                             an error.


This declaration expands to
uint32_t mc_dyn_globallock_check(uint64_t addr, uint64_t iaddr, uint32_t amask)
*/
CHECK_DECL(SCHEME_GLOBALLOCK_PREFIX)
{
#if defined(__CUDA_ARCH__)

    uint64_t heap_base = 0;
    uint64_t heap_offset = 0;
    volatile uint32_t *tracker = NULL;
    uint64_t word_offset = 0;
    uint32_t bit_offset = 0;
    uint32_t track_mask = 0;
    uint32_t track_val = 0;

    heap_base = globalLockDevDataPtr->heapDptr;
    tracker = (volatile uint32_t*)(uintptr_t)globalLockDevDataPtr->trackDptr;

    heap_offset = addr - heap_base;

    /* word_offset = heap_offset / 32 */
    word_offset = heap_offset >> WORD_SIZE_LOG2;

    /* bit_offset = heap_offset % 32 */
    bit_offset = (uint32_t)((heap_offset) & (WORD_SIZE_IN_BITS - 1));

    /* The tracking data structure in this scheme tracks each heap byte
        with one bit. This data structure is itself accessed one word
        (32 bits) at a time. In effect, each time we read a word in
        the tracking data structure, we are reading the state of 32 bytes.
        Since the maximum access size is 16 bytes (128 bits) we
        need to compute a bitmask on the tracking structure that
        give us the interesting bits for the access.
    */

    /* Compute the tracking vector bit mask, based on the access size.
        This will need to be shifted to the left by the bit offset
        Amask is the access size - 1. In current architectures,
        access size is always a power of 2 bytes (1, 2, 4, 8, 16)
        So, we can compute the bitmask as (2^(Amask + 1) - 1)
    */
    track_mask = (1U << (amask + 1)) - 1;

    /* Shift the track_mask by the bit offset */
    track_mask = track_mask << bit_offset;

    /* Dont need to lock here as any read will happen as one op */
    track_val = tracker[word_offset] & track_mask;

    if (track_val == track_mask) {
        /* Access is fine (all bits expected are set) */
        return 0;
    }
    else {
        /* Unexpected bits are 0. Report an error */
        return 1;
    }

#else
    return 0;
#endif
}

#undef LOCK_START
#undef LOCK_DONE
#undef WORD_SIZE_IN_BITS
#undef WORD_SIZE_LOG2
#undef WORD_SIZE_BYTE_LOG2
#undef FULL_WORD_MASK

#undef SCHEME_GLOBALLOCK_PREFIX


#endif
