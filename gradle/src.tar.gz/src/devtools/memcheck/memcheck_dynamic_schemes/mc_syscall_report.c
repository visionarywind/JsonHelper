/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "cudamemcheck.h"
#include "memcheck_types.h"
#include "memcheck_dynamic.h"
#include "memcheck_dynamic_schemes/mc_syscall_report.h"
#include "memcheck_dynamic_schemes/mc_syscall_report.cuh"

/* Enable syscall error reporting (Should only be called inside a scheme) */
CUresult
MCSCenableReport(MCcontext *mcctx, CCmemHandle *syscallData)
{
    CUresult res = CUDA_SUCCESS;
    MCSCdevData *devData = NULL;
    void *ptr = NULL;

    CU_TRACE_FUNCTION();

    if (!syscallData || !mcctx) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    syscallData->size = sizeof(MCSCdevData);
    syscallData->mcctx = mcctx;
    syscallData->devseg = HALO_MEM_SEG_PINNED_SYSMEM;

    res = CCallocateDevice(syscallData, NULL);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to allocate syscall report data on device\n"));
        return CUDA_ERROR_OUT_OF_MEMORY;
    }

    devData = (MCSCdevData*)syscallData->dev.hPtr;
    memset(devData, 0, (size_t)syscallData->size);

    if (mcctx->ctxOpts.launchMode == MC_CONTEXT_OPTION_LAUNCH_NONBLOCKING ||
        mcctx->gvars->options.debuggerAttached)
        devData->enabled = MC_SC_REPORT_ENABLE_TRAP;
    else
        devData->enabled = MC_SC_REPORT_ENABLE;

    // At this point, cast it into a dummy pointer to convert
    // this to a platform specific size, as the storage in the
    // const bank depends on the architecture
    ptr = (void*)(uintptr_t)syscallData->dev.dPtr;

    res = MCWriteSyscallConstBank(mcctx,
                                  mcctx->dynamic->mod->cumod,
                                  "MCSCdevDataPtr",
                                  &ptr,
                                  sizeof(ptr));
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to enable syscall reporting\n"));
        return res;
    }

    return res;
}

/* Disable syscall error reporting (Should only be called inside a scheme) */
CUresult MCSCdisableReport(MCcontext *mcctx, CCmemHandle *syscallData)
{
    CUresult res = CUDA_SUCCESS;
    void *nullDptr = NULL;

    CU_TRACE_FUNCTION();

    if (!syscallData || !mcctx) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    res = MCWriteSyscallConstBank(mcctx,
                                  mcctx->dynamic->mod->cumod,
                                  "MCSCdevDataPtr",
                                  &nullDptr,
                                  sizeof(nullDptr));
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to enable syscall reporting\n"));
        return res;
    }

    CCfreeDevice(syscallData, NULL);

    return res;
}

/* Parse for a syscall error */
CUresult
MCSCparseError(MCcontext *mcctx, CCmemHandle *syscallData,
               CUmemcheck_record *rec, uint32_t *hasError)
{
    MCSCdevData *devData = NULL;
    uint32_t enabled = 0;
    CUmemcheck_error_record *err = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !syscallData || !rec || !hasError) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    err = &rec->cases.error;

    devData = (MCSCdevData *)syscallData->dev.hPtr;
    *hasError = 0;

    if (!devData) {
        CU_ERROR_PRINT(("Syscall error reporting not enabled\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!devData->enabled) {
        CU_TRACE_PRINT(("Syscall reporting not enabled\n"));
        return CUDA_SUCCESS;
    }

    if (devData->lock) {
        err->errortype = CU_MEMCHECK_RECORD_MEM_SYSCALL;
        err->cases.memSyscall.type = devData->type;
        err->cases.memSyscall.threadIdxX = devData->threadIdxX;
        err->cases.memSyscall.threadIdxY = devData->threadIdxY;
        err->cases.memSyscall.threadIdxZ = devData->threadIdxZ;
        err->cases.memSyscall.blockIdxX = devData->blockIdxX;
        err->cases.memSyscall.blockIdxY = devData->blockIdxY;
        err->cases.memSyscall.blockIdxZ = devData->blockIdxZ;
        err->cases.memSyscall.address = devData->ptr;
        err->cases.memSyscall.size = devData->len;

        enabled = devData->enabled;
        memset(devData, 0, (size_t)syscallData->size);
        devData->enabled = enabled;

        CU_TRACE_PRINT(("Found a syscall error \n"));
        *hasError = 1;
    }

    return CUDA_SUCCESS;
}
