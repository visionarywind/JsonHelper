/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef SCHEME_OOB_CU
#define SCHEME_OOB_CU

#define SCHEME_OOB_PREFIX __cuda_syscall_mc_dyn_oob_

#include "schemes_oob.cuh"

/* OOB scheme
    This scheme is meant to provide low overhead out of bound checking, but
    has limitation in terms of features (such as leak detection, double free)

    This scheme uses an extra pad space of 36 bytes allocated with every
    mallocd region. This pad space consists of a 16 byte aligned header and
    a 20 byte tail. The header contains the size of the allocation in bytes
    as an 8 byte unsigned int, followed by 2 repetitions of the magic number.
    The tail contains 16 bytes that are aligned on
    a 32 bit boundary that contain 4 repetitions of a magic number.
    Given the nature of the existing minimalloc and normal malloc, the
    minimum allocation size is 64 bytes for any allocation. Thus, the impact
    of adding 36 bytes should not affect small allocations (<32 bytes).
    For larger allocations, this scheme will be sufficient as it does not
    scale with the allocation.

    On malloc, each allocation is cleaned, the size of the malloc
    is written to the first 8 bytes and the next 8 bytes are filled
    with the magic number. The next length bytes are set as the user
    allocation and are reset to zeros. Finally, 16 bytes starting
    at a word boundary are filled with the magic number.

    On free, the pointer is unwound 16 bytes. If the head structure exists
    then the size is extracted from the head. This size is explicitly reset
    to the magic number. Finally the real head is passed into free.

    At every check, the access size is used to determine how far ahead to
    scan, then at every aligned access address within the access size,
    the memory is read in and compared to the magic number. This read is
    safe as the jump into this call implicitly means that the address
    falls within the device heap and therefore can be accessed.

    Caveats :
    1. The biggest caveat of this scheme is that it can only detect bad
       access that hit a region initialized to the magic number. It cannot
       detect all random accesses, nor can it detect accesses to the record
       keeping structures that the allocator uses. The precision of this
       scheme is low.
*/

/* Size of the padding for the header.
   This contents are as follows :
    Bytes       |   Content
    0 - 3       |   Padding for alignment
    A0, 3       |   Magic number
    A4, 7       |   Size of allocation as uint32_t
    A8, 11      |   Magic number
    A12 - 24    |   If this is 4 bytes, then Magic number, else, padding

    Bytes prefixed with A are aligned to a word (4 byte) boundary.
    The last entry is variable. If the allocation's start was aligned
    then these 4 bytes are used to contain another instance of the magic
    number. If not, they are indeterminate.
*/
#define OOB_CHECK_HEAD_PAD 16

/* Size of padding for the tail
   The contents are :
    Bytes       |   Content
    0 - 3       |   Padding for alignment
    A0, 3       |   Magic number
    A4 - 7      |   If this is 4 bytes, then magic number

    Bytes prefixed with A are aligned to a word (4 byte) boundary.
    The last entry is variable as it will contain the magic number
    only if the allocation ended at a word aligned boundary
*/
#define OOB_CHECK_TAIL_PAD 8

/* Total size of padding */
#define OOB_CHECK_PAD (OOB_CHECK_HEAD_PAD + OOB_CHECK_TAIL_PAD)

/* Check function : Called for every heap access by the memcheck
   patch code, when dynamic memcheck is active.

   Parameters : addr : 64 bit address that the access is going to
                        This address is guaranteed to lie in the
                        heap allocation (so accesses are legal)
                iaddr : 64 bit address of the original instruction
                amask : 32 bit mask to check alignment of access.
                        This is the access_size - 1

   Return value : uint32_t : This function will return 0 if the
                             access is safe. A non zero return
                             value will cause memcheck to report
                             an error.

This declaration expands to
uint32_t mc_dyn_oob_check(uint64_t addr, uint64_t iaddr, uint32_t amask)
*/
CHECK_DECL(SCHEME_OOB_PREFIX)
{
#if defined(__CUDA_ARCH__)
    char* dptr;
    uint32_t found = 0;
    uint32_t bytectr = 0;
    uint32_t mask32 = 0x3;
    uint32_t bytectrmax = 8;
    uint32_t aligned32 = 0;
    uint32_t checkVal = 0;

    dptr = (char*)(uintptr_t)addr;

    //amask the alignment mask for the access. This is passed in as a
    //parameter to the check function. This mask is access size - 1
    //The allowed values are :
    // Amask    | Size  | SASS sz
    //  0       | 1     | .8
    //  1       | 2     | .16
    //  3       | 4     | .32
    //  7       | 8     | .64
    // 15       | 16    | .128
    //To find the max extent the byte counter should use, we increment
    //amask to get the size. Then we round it up to the nearest multiple
    //of 4 as the magic number is 4bytes long and is on a 4 byte boundary
    //This allows the scanning to happen at all aligned sections
    //within the access size
    bytectrmax = (amask + 4) & ~0x3;

    //If the access is less than one word, we need to rewind the dptr
    //by one word to ensure the current word will be checked. This is
    //safe as the start of the malloc heap is word aligned and this
    //access falls inside the malloc heap.
    if (amask < mask32)
        dptr = (char*)(uintptr_t)(addr & ~0x3ULL);

    //Outer compare see if any consecutive 4 bytes in next access are magic
    for (bytectr = 0; bytectr < bytectrmax && dptr; ++bytectr, ++dptr) {
        //Ensure the alignment is correct for a 32bit read
        aligned32 = !((uint32_t)(uintptr_t)dptr & mask32);
        if (!aligned32)
            continue;
        checkVal = (uint32_t)(*(uint32_t*)dptr);

        if(checkVal == OOB_MAGIC) {
            found = 1;
        }
    }

    return found;
#else
    return 0;
#endif
}

/* This declaration expands to
void *mc_dyn_oob_malloc(size_t len)
*/
MALLOC_DECL(SCHEME_OOB_PREFIX)
{
#if defined(__CUDA_ARCH__)
    void *head;
    char *tail;
    uint64_t addr_tail, addr_head;
    uint64_t aligned_addr_tail, aligned_addr_head;
    uint32_t *aligned_tail;
    uint32_t *aligned_head;
    uint32_t size_lo;

    //Allocate an extra 24 bytes for checking
    //The header contains an aligned entry, with the first 0-3  bytes containing
    //the padding. The next 4 bytes contain the magic number, followed by 4 bytes
    //containing the length of the allocation. Then there is another 4 bytes of
    //magic number. Finally, if the allocation was aligned, there are another
    //4 bytes containing the magic number.
    //For the tail, the first 0 - 3 bytes will contain a variable length padding
    //The next 4 bytes will contain the magic number starting on
    //a word aligned boundary. If the tail was aligned, there will be another
    //copy of the magic number in the last 4 bytes.
    head = malloc(len + OOB_CHECK_PAD);
    if (!head)
        return NULL;

    memset(head, 0, len + OOB_CHECK_PAD);

    //Write information for the head
    size_lo = (uint32_t)len;

    //Get the raw pointer for the head
    addr_head = (uint64_t)(uintptr_t)head;
    //Align the head pointer by rounding up to nearest 4 byte boundary
    aligned_addr_head = (addr_head + 3) & ~(0x3ULL);

    //Write the header sequence, containing the size
    //surrounded by two instances of the magic word
    aligned_head = (uint32_t*)(uintptr_t)aligned_addr_head;
    *(aligned_head) = OOB_MAGIC;
    *(aligned_head + 1) = size_lo;
    *(aligned_head + 2) = OOB_MAGIC;

    //If the alignment was correct, fill in the last word
    if (head == (char*)aligned_head)
        *(aligned_head + 3) = OOB_MAGIC;

    //Advance the head pointer
    head = (char*)head + OOB_CHECK_HEAD_PAD;

    //The magic number is located at the end of the allocation,
    //so advance tail to that point
    tail = (char*)head + len;

    //Pull out the raw pointer for the tail
    addr_tail = (uint64_t)(uintptr_t)tail;
    //Align the actual pointer address for tail by rounding up
    //to the nearest 4 byte boundary
    aligned_addr_tail = (addr_tail + 3) & ~(0x3ULL);

    //Finally, cast this new address back into a pointer
    aligned_tail = (uint32_t*)(uintptr_t)aligned_addr_tail;

    //Now aligned_tail is the aligned pointer to the tail
    //we can fill in the copy of the magic number
    *(aligned_tail) = OOB_MAGIC;

    //If tail was already aligned, fill in the last word
    if (tail == (char*)aligned_tail)
        *(aligned_tail + 1) = OOB_MAGIC;

    return head;
#else
    return NULL;
#endif
}

/* This declaration expands to
void mc_dyn_oob_free(void *ptr)
*/
FREE_DECL(SCHEME_OOB_PREFIX)
{
#if defined(__CUDA_ARCH__)
    void *real_ptr = NULL;
    uint32_t len = 0, ctr;
    uint64_t addr_head;
    uint64_t aligned_addr_head;
    uint32_t *aligned_head;

    if (!ptr)
        return;

    //Roll the pointer back by 16 bytes. This is to
    //read information from the header
    real_ptr = ((char*)ptr) - OOB_CHECK_HEAD_PAD;

    //Get the raw address of the header
    addr_head = (uint64_t)(uintptr_t)real_ptr;

    //Create an aligned head pointer
    aligned_addr_head = (addr_head + 3) & ~(0x3ULL);

    //Attempt to read the header information
    aligned_head = (uint32_t*)(uintptr_t)aligned_addr_head;

    if (*(aligned_head) == OOB_MAGIC &&
        *(aligned_head + 2) == OOB_MAGIC)
        len = (*(aligned_head + 1));

    //Increase the size to compensate for padding. Currently at
    //24 bytes (16 header and 8 tail). This should only happen
    //if len was successfully read.
    if (len)
        len += OOB_CHECK_PAD;

    //Reset the buffer. This will be skipped if we could not
    //read the header correctly
    for (ctr = 0; ctr < len / sizeof(*aligned_head); ++ctr, ++aligned_head)
        *(aligned_head) = OOB_MAGIC;

    //Do the actual free
    free(real_ptr);
#else

#endif
}

#endif
