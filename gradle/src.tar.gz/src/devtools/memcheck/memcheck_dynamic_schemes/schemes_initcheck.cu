/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef SCHEME_INITCHECK_CU
#define SCHEME_INITCHECK_CU
#include "devtools/memcheck/initcheck/initcheck_structs.h"

/* Initcheck scheme */
#define SCHEME_INITCHECK_PREFIX __cuda_syscall_mc_dyn_initcheck_

__constant__ uint64_t MCICglobalDevDataPtr;

__device__ static __forceinline__ ICdevGlobalData*
getGlobalData(void)
{
    return (ICdevGlobalData*)(uintptr_t)(MCICglobalDevDataPtr);
}

__device__ static __forceinline__ void
clearTable(volatile uint32_t *trackingTable, uint64_t offset, uint32_t size)
{
    /* If offset is not aligned to 32byte boundary, we need some extra hackery */
    uint32_t beginOffset = (offset & 0x1f);
    uint32_t beginWord = offset >> 5;
    const uint32_t defaultWordMask = 0xffffffff;
    uint32_t beginMask = defaultWordMask << beginOffset;
    uint32_t finalSize = (beginOffset + size);
    uint32_t finalOffset = (finalSize & 0x1f);
    uint32_t finalMask = (1U << finalOffset) - 1;
    uint32_t wordCtr = ((finalSize + 31) >> 5);
    uint32_t wordMask = defaultWordMask;
    uint32_t i;

    for (i = 0; i < wordCtr; ++i) {
        /* Start each word mask at the default */
        wordMask = defaultWordMask;

        /* When on the first word, if there is a begin
           offset, clip down to the begin mask */
        if (i == 0 && beginOffset)
            wordMask &= beginMask;

        /* If on the last word, and there is a finalOffset,
           the mask in finalMask will clip out the high bits  */
        if ((i == wordCtr - 1) && finalOffset)
            wordMask &= finalMask;

        atomicAnd((unsigned int*)&trackingTable[i + beginWord], ~wordMask);
    }
}

/* This declaration expands to
void *mc_dyn_initcheck_malloc(size_t size)
*/
MALLOC_DECL(SCHEME_INITCHECK_PREFIX)
{
#if defined(__CUDA_ARCH__)
    void *ptr = malloc(len);
    ICdevGlobalData *glob = getGlobalData();
    ICdevAllocTableEntry *entry = (ICdevAllocTableEntry*)(uintptr_t)(glob->allocTablePtr);
    uint64_t offset;
    uint32_t heapIx = glob->heapAllocIndex;

    if (ptr && glob->hasHeapAlloc && heapIx < glob->numAllocs) {
        offset = (uint64_t)(uintptr_t)ptr - entry[heapIx].begin;
        clearTable((volatile uint32_t*)entry[heapIx].trackingTablePtr, offset, (uint32_t)len);
    }

    return ptr;
#else
    return NULL;
#endif
}

/* This declaration expands to
void mc_dyn_initcheck_free(void *ptr)
*/
FREE_DECL(SCHEME_INITCHECK_PREFIX)
{
#if defined(__CUDA_ARCH__)
    free(ptr);
#else
#endif
}

/* This declaration expands to
uint32_t mc_dyn_initcheck_check(uint64_t addr, uint64_t iaddr, uint32_t amask)
*/
CHECK_DECL(SCHEME_INITCHECK_PREFIX)
{
#if defined(__CUDA_ARCH__)
    return 0;
#else
    return 0;
#endif
}

#undef SCHEME_INITCHECK_PREFIX

#endif
