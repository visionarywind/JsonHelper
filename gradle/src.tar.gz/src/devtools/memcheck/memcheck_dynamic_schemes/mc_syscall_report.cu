/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef MC_SYSCALL_REPORT_CU
#define MC_SYSCALL_REPORT_CU

#include "mc_syscall_report.cuh"

__constant__ MCSCdevData* MCSCdevDataPtr;

static __inline__ __device__ void
writeLmemHi32(uint32_t offset, uint32_t data)
{
    uint32_t lmem_offset = FERMI_LMEM_HI_MEMCHECK_SCRATCH + offset;
    asm volatile ("{ \n"
                  ".reg .u32 l_off; \n"
                  ".reg .u64 a0, a1; \n"
                  ".reg .u32 t1; \n"
                  "mov.u32 l_off, %0; \n"
                  "cvt.u64.u32 a0, l_off; \n"
                  "cvta.local.u64 a1, a0; \n"
                  "mov.u32 t1, %1; \n"
                  "st.volatile.u32 [a1], t1;\n"
                  "} \n" ::
                  "r"(lmem_offset), "r"(data) :
                  "memory");

}

static __inline__ __device__ void
writeLmemHi64(uint32_t offset, uint64_t data)
{
    uint32_t lmem_offset = FERMI_LMEM_HI_MEMCHECK_SCRATCH + offset;
    asm volatile ("{ \n"
                  ".reg .u32 l_off; \n"
                  ".reg .u64 a0, a1; \n"
                  ".reg .u64 t1; \n"
                  "mov.u32 l_off, %0; \n"
                  "cvt.u64.u32 a0, l_off; \n"
                  "cvta.local.u64 a1, a0; \n"
                  "mov.u64 t1, %1; \n"
                  "st.volatile.u64 [a1], t1;\n"
                  "} \n" ::
                  "r"(lmem_offset), "l"(data) :
                  "memory");

}

static __device__ void mc_dyn_syscall_report(uint32_t id, uint64_t ptr, uint64_t len)
{
    uint32_t magic = FERMI_MEMCHECK_WHITEMAGIC;
    uint32_t magic_offset =  FERMI_LMEM_MEMCHECK_MAGIC;
    uint32_t ptr_offset =  FERMI_LMEM_MEMCHECK_ADDR;
    uint32_t len_offset = FERMI_LMEM_MEMCHECK_PC;
    uint32_t oldVal = 0;
    uint32_t *atomLoc = NULL;
    uint32_t warp_threads = 0, div_threads = 0;

    if (!id || !MCSCdevDataPtr || !MCSCdevDataPtr->enabled)
        return;

    warp_threads = __activemask();

    // For blocking launches we save the errors off into a
    // buffer. This will be cleared out when read.
    atomLoc = &MCSCdevDataPtr->lock;

    do {
        div_threads = 0;
        oldVal = atomicAdd(atomLoc, 1);
        if (oldVal == 0) {
            MCSCdevDataPtr->threadIdxX = threadIdx.x;
            MCSCdevDataPtr->threadIdxY = threadIdx.y;
            MCSCdevDataPtr->threadIdxZ = threadIdx.z;
            MCSCdevDataPtr->blockIdxX = blockIdx.x;
            MCSCdevDataPtr->blockIdxY = blockIdx.y;
            MCSCdevDataPtr->blockIdxZ = blockIdx.z;
            MCSCdevDataPtr->type = id;
            MCSCdevDataPtr->ptr = ptr;
            MCSCdevDataPtr->len  = len;
            div_threads = __activemask();
        }
        else
            div_threads = __activemask();

        warp_threads &= ~div_threads;
    } while (warp_threads);

    /* Construct a packed magic number. The lowest 2 bits of the magic
        number indicate the address space. The next two bits indicate
        the id of the syscall error. The upper 28bits are the magic number
        Need the one at the end to indicate a global address.
    */

    /* Construct the upper 28 bits of the magic number  */
    magic = magic & FERMI_MEMCHECK_WHITEMAGIC_MASK;
    /* Add the bits for the syscall id type  */
    magic |= ((id << 2) & FERMI_MEMCHECK_SYSCALL_MASK);
    /* Finally, add the bits for the address type. The one is to mark
       it as a global */
    magic |= (1 & FERMI_MEMCHECK_ADDR_MASK);

    /* Force the save to the magic location
        The compiler tends to remove the asm directive below unless the access
        to lmem is going through GTAS.
    */
    writeLmemHi32(magic_offset, magic);
    writeLmemHi64(ptr_offset, ptr);
    writeLmemHi64(len_offset, len);

    __threadfence_system();
    if (MCSCdevDataPtr->enabled == MC_SC_REPORT_ENABLE_TRAP)
        __trap();
    asm volatile ("exit;" ::: "memory" );
}

#endif
