/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
*
*   Module: schemes_oob.c
*
*   Description:
*       Implementation of a basic dynamic scheme. This scheme uses magic
*       guard numbers to detect out of bounds accesses.
*
*
******************************************************************************/
#include "schemes_oob.h"

#include "cudamemcheck.h"
#include "memcheck_types.h"
#include "memcheck_dynamic.h"

#include "cui/memobj.h"
#include "cui/memobj_private.h"
#include "cuda_types.h"
#include "cuda_mem.h"

#include "schemes_oob.cuh"
#include "check_alloc.h"

/* Initial value for the heap */
#define OOB_HEAP_INIT_VAL OOB_MAGIC

static CUresult
schemeInitialize_oob(MCDynamicScheme *scheme)
{
    return CUDA_SUCCESS;
}

static CUresult
schemeFinalize_oob(MCDynamicScheme *scheme)
{
    return CUDA_SUCCESS;
}

static CUresult
schemeActivate_oob(MCDynamicScheme *scheme, MCcontext *mcctx, CUtoolsStreamHandle stream)
{
    // Grab the heapAlloc and fill it with the initial value
    // The current implementation is to allocate a host side
    // shadow copy of the heapAlloc, reset it and
    // download it to the device
    CUresult res = CUDA_SUCCESS;
    CUmemobj *heapObj = NULL;
    void *heapCopy = NULL;
    uint32_t *heapInit = NULL;
    uint64_t heapSize = 0;
    uint64_t heapDptr = 0;
    uint64_t heapInitWords = 0;

    CU_TRACE_FUNCTION();

    if (!scheme || !mcctx) {
        CU_ERROR_PRINT(("Bad args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!mcctx->heapAlloc) {
        CU_ERROR_PRINT(("Heap alloc not present\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    heapDptr = CCallocGetStart(mcctx->heapAlloc);
    heapSize = CCallocGetSize(mcctx->heapAlloc);

    if (!heapSize) {
        CU_ERROR_PRINT(("Heap size is zero\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    heapObj = memobjGetByDevicePtr(mcctx->cuctx->memmgr,
                                   (NvU64)heapDptr);
    if (!heapObj) {
        CU_ERROR_PRINT(("Could not read device pointer. Disabling\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    heapCopy = (char*) malloc((size_t)heapSize);
    if (!heapCopy) {
        CU_ERROR_PRINT(("Failed to allocate temporary shadow heap\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    heapInit = (uint32_t*)heapCopy;

    for (heapInitWords = 0;
         heapInitWords < (heapSize / sizeof(*heapInit));
         ++heapInit, ++heapInitWords)
        *heapInit = OOB_HEAP_INIT_VAL;

    res = cuiMemcpyHtoD(mcctx->cuctx,
                        heapObj,
                        0,
                        heapCopy,
                        heapSize,
                        mcctx->cuctx->barrierStream,
                        CUI_MEMCPY_SYNCHRONOUS,
                        NULL);

    // Free the heap copy before checking errors
    free(heapCopy);

    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to reset heap\n"));
        return res;
    }

    CU_TRACE_PRINT(("Activate done for OOB\n"));
    return CUDA_SUCCESS;
}

static CUresult
schemeDeactivate_oob(MCDynamicScheme *scheme, MCcontext *mcctx, CUtoolsStreamHandle stream)
{
    return CUDA_SUCCESS;
}


static CUresult
schemeParseSyscallError_oob(MCDynamicScheme *scheme, MCcontext *mcctx, CUmemcheck_record *err, uint32_t *hasError)
{
    return CUDA_SUCCESS;
}

static CUresult
schemeAddLeaks_oob(MCDynamicScheme *scheme, MCcontext *mcctx, CUtoolsStreamHandle stream)
{
    return CUDA_SUCCESS;
}

static CUresult
schemeCheckAccess_oob(MCDynamicScheme *scheme, MCcontext *mcctx, CUtoolsStreamHandle stream,  uint64_t addr, uint64_t size, CCmemAccessError *err)
{
    return CUDA_SUCCESS;
}

CUresult
MCDynamicSchemeRegister_oob(MCDynamicScheme *scheme)
{
    scheme->type        = MC_DYNAMIC_SCHEME_OOB;
    scheme->prefix      = "__cuda_syscall_mc_dyn_oob_";
    scheme->name        = "OOB";
    scheme->initialize  = &schemeInitialize_oob;
    scheme->finalize    = &schemeFinalize_oob;
    scheme->activate    = &schemeActivate_oob;
    scheme->deactivate  = &schemeDeactivate_oob;
    scheme->parseSyscallError = &schemeParseSyscallError_oob;
    scheme->addLeaks    = &schemeAddLeaks_oob;
    scheme->checkAccess = &schemeCheckAccess_oob;

    return CUDA_SUCCESS;
}
