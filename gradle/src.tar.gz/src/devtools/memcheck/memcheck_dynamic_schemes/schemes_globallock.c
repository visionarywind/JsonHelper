/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
*
*   Module: schemes_globallock.c
*
*   Description:
*       Bit for byte based scheme that uses a global lock
*
*
******************************************************************************/

#include "mc_syscall_report.h"
#include "schemes_globallock.h"
#include "schemes_globallock.cuh"
#include "check_mem.h"
#include "memcheck_error.h"

#include "check_alloc.h"

typedef struct globalLockHostData_st globalLockHostData;
struct globalLockHostData_st {
    /* Heap allocation info */
    uint64_t heapDptr;
    uint64_t heapSize;

    /* Tracking allocation */
    CCmemHandle track;

    /* Device data  */
    CCmemHandle devData;

    /* Syscall error reporting */
    CCmemHandle syscallData;
};

static CUresult
schemeInitialize_globallock(MCDynamicScheme *scheme)
{

    CU_TRACE_FUNCTION();

    scheme->customData = calloc(1, sizeof(globalLockHostData));
    if (!scheme->customData) {
        CU_ERROR_PRINT(("Failed to allocate custom data\n"));
        return CUDA_ERROR_OUT_OF_MEMORY;
    }

    return CUDA_SUCCESS;
}

static CUresult
schemeFinalize_globallock(MCDynamicScheme *scheme)
{
    CU_TRACE_FUNCTION();

    if (scheme->customData) {
        free(scheme->customData);
        scheme->customData = NULL;
    }

    return CUDA_SUCCESS;
}

static CUresult
schemeActivate_globallock(MCDynamicScheme *scheme, MCcontext *mcctx, CUtoolsStreamHandle stream)
{
    CUresult res = CUDA_SUCCESS;

    globalLockHostData *hostData = NULL;
    globalLockDevData *devData = NULL;
    void *ptr = NULL;

    CU_TRACE_FUNCTION();

    if (!scheme || !mcctx) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!mcctx->heapAlloc) {
        CU_ERROR_PRINT(("Heap alloc not present\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Explicitly reset to 0 here as the scheme may be reinitialized
    hostData = (globalLockHostData*)scheme->customData;
    memset(hostData, 0, sizeof(*hostData));

    hostData->heapDptr = CCallocGetStart(mcctx->heapAlloc);
    hostData->heapSize = CCallocGetSize(mcctx->heapAlloc);

    if (!hostData->heapSize) {
        CU_ERROR_PRINT(("Heap size is zero\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!hostData->heapSize) {
        CU_TRACE_PRINT(("Tracking is of 0 size\n"));
    }

    /* The tracker has one bit for every byte on the heap.
       However it is always accessed using 4 byte words.
       As a result, the minimum allocation is 1 word and
       the allocation must be rounded up to the next
       multiple of 4 */
    hostData->track.size = (hostData->heapSize / 8) + 1;

    // Round up to next word
    hostData->track.size = (hostData->track.size + 3) & (~0x3ULL);

    hostData->track.mcctx = mcctx;
    hostData->track.devseg = HALO_MEM_SEG_GLOBAL;

    res = CCallocateDevice(&hostData->track, NULL);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to allocate tracker\n"));
        return CUDA_ERROR_OUT_OF_MEMORY;
    }

    res = CCallocateHost(&hostData->track);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to allocate host copy of tracker\n"));
        return CUDA_ERROR_OUT_OF_MEMORY;
    }

    // Reset the tracking vector
    memset(hostData->track.host.ptr, 0, (size_t)hostData->track.size);
    res = CCmemShadowHtoDStream(&hostData->track, &hostData->track, stream, CC_MEM_SHADOW_ACTION_MEMCPY);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to reset tracker\n"));
        return res;
    }

    hostData->devData.mcctx = mcctx;
    hostData->devData.devseg = HALO_MEM_SEG_GLOBAL;
    hostData->devData.size  = sizeof(*devData);

    res = CCallocateHost(&hostData->devData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to allocate host copy of devData\n"));
        return res;
    }

    res = CCallocateDevice(&hostData->devData, NULL);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to allocate device copy of devData\n"));
        return res;
    }

    devData = (globalLockDevData*)(hostData->devData.host.ptr);
    devData->heapSize = hostData->heapSize;
    devData->heapDptr = hostData->heapDptr;
    devData->trackSize = hostData->track.size;
    devData->trackDptr = hostData->track.dev.dPtr;
    devData->lock  = 0;

    CU_TRACE_PRINT(("Writing device data at 0x%" PRIx64 "\n"
                    "    heapSize : 0x%" PRIx64 "\n"
                    "    heapDptr : 0x%" PRIx64 "\n"
                    "    trackSize : 0x%" PRIx64 "\n"
                    "    trackDptr : 0x%" PRIx64 "\n",
                    hostData->devData.dev.dPtr,
                    devData->heapSize, devData->heapDptr,
                    devData->trackSize, devData->trackDptr));

    res = CCmemShadowHtoDStream(&hostData->devData, &hostData->devData, stream, CC_MEM_SHADOW_ACTION_MEMCPY);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to copy devData to device\n"));
        return res;
    }

    // The value in the const bank is for a pointer, as a result
    // the size will vary between 32 and 64 bit versions. To
    // handle this, we cast the dPtr into a dummy copy that
    // is set as a void* and thus has the correct size based
    // on the platform
    ptr = (void*)(uintptr_t)(hostData->devData.dev.dPtr);
    res = MCWriteSyscallConstBank(mcctx,
                                  mcctx->dynamic->mod->cumod,
                                  "globalLockDevDataPtr",
                                  &ptr,
                                  sizeof(ptr));
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to download const data\n"));
        return res;
    }

    res = MCSCenableReport(mcctx, &hostData->syscallData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to enable syscall error reporting\n"));
        return res;
    }

    CU_TRACE_PRINT(("Activate done for global lock\n"));
    return CUDA_SUCCESS;
}

static CUresult
schemeDeactivate_globallock(MCDynamicScheme *scheme, MCcontext *mcctx, CUtoolsStreamHandle stream)
{
    CUresult res = CUDA_SUCCESS;
    globalLockHostData *hostData = NULL;

    if (!scheme || !mcctx) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    hostData = (globalLockHostData*)scheme->customData;

    if (!hostData) {
        CU_TRACE_PRINT(("Couldnt find custom data\n"));
        return CUDA_SUCCESS;
    }

    res = MCSCdisableReport(mcctx, &hostData->syscallData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to disable syscall error reporting. Soldiering on\n"));
    }

    CCfreeHost(&hostData->track);
    CCfreeDevice(&hostData->track, NULL);

    CCfreeHost(&hostData->devData);
    CCfreeDevice(&hostData->devData, NULL);

    free(hostData);
    scheme->customData = NULL;

    return CUDA_SUCCESS;
}

static CUresult
schemeParseSyscallError_globallock(MCDynamicScheme *scheme, MCcontext *mcctx, CUmemcheck_record *err, uint32_t *hasError)
{
    CUresult res = CUDA_SUCCESS;
    globalLockHostData *hostData = NULL;

    if (!scheme || !err || !hasError || !mcctx) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    hostData = (globalLockHostData*)scheme->customData;

    if (!hostData) {
        CU_TRACE_PRINT(("Couldnt find custom data\n"));
        return CUDA_SUCCESS;
    }

    if (!hostData->syscallData.size) {
        CU_TRACE_PRINT(("Syscall error not allocated\n"));
        return CUDA_SUCCESS;
    }

    res = MCSCparseError(mcctx, &hostData->syscallData, err, hasError);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to parse for syscaall errors.\n"));
        return res;
    }

    return res;
}

static CUresult
schemeAddLeaks_globallock(MCDynamicScheme *scheme, MCcontext *mcctx, CUtoolsStreamHandle stream)
{
    CUresult res = CUDA_SUCCESS;
    globalLockHostData *hostData = NULL;
    unsigned char *ptr = NULL, *start_ptr = NULL, *end_ptr = NULL;
    uint64_t alloc_start = 0;
    uint64_t alloc_size = 0;
    unsigned char cur = 0;
    uint32_t ix = 0;

    if (!scheme || !mcctx) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    hostData = (globalLockHostData*)scheme->customData;

    /* If hostData is not set, the scheme was deactivated early */
    if (!hostData) {
        CU_TRACE_PRINT(("Couldnt find custom data\n"));
        return CUDA_SUCCESS;
    }

    /* Try to copy the tracker back to the host. Note that this can fail if there
       was a pending error on the context (e.g. blocking mode). In this case,
       we want to handle this gracefully and continue onwards.
       An error on synchronize would imply a launch error that will be reported
       by the error handling in memcheck. Memcheck will not report leaks if the
       context has hit an error.
    */
    res = CCmemShadowDtoHStream(&hostData->track, &hostData->track, stream, CC_MEM_SHADOW_ACTION_MEMCPY);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to download tracker\n"));
        return CUDA_SUCCESS;
    }

    /* In the tracker, we represent allocations as continuous strings of 1, with each 1
       corresponding to a byte. The goal is to count the number, size and starting address
       of leaks (i.e. strings of 1 in the tracker).
       Now, walk the entire tracker, one byte at a time. When we encounter a 1 at a bit
       position, we start the allocation, and continue till we hit a zero.

       Below is a simple 1 bit state machine to do the counting. It has two state
       registers - alloc_start and alloc_size. The internal state is tracked as
       the boolean condition of alloc_start, i.e. State = !!(alloc_start);
       It starts by assuming alloc_start and alloc_size are 0. The subsequent input
       to the state machine is the bit in the tracker. The logic is the following :

        State | Input | Action
        0     | 0     | None
        0     | 1     | A new allocation has started.
              |       | Update the alloc_start and reset alloc_size
        1     | 0     | An allocation has ended. Add a new allocation with
              |       | the values of alloc_start and alloc_size
        1     | 1     | Inside an allocation, increment size by 1
    */

    start_ptr = (unsigned char*)hostData->track.host.ptr;
    end_ptr = start_ptr + (size_t)hostData->track.size;
    ptr = start_ptr;
    alloc_start = 0;
    alloc_size = 0;
    for (; ptr < end_ptr; ++ptr) {
        cur = *ptr;
        for (ix = 0; ix < 8; ++ix) {
            if (alloc_start &&  (cur & (1 << ix)))
                ++alloc_size;
            else if (alloc_start) {
                // Allocation ended, so push it and finish
                res = addLeakRecord(mcctx, alloc_start, alloc_size,
                                    CU_MEMCHECK_ALLOC_DEVHEAP, NULL, NULL);
                if (res != CUDA_SUCCESS) {
                    CU_ERROR_PRINT(("Failed to add leak record\n"));
                    return res;
                }
                // Success, reset the allocation start state
                alloc_start = 0;
            }
            else if (cur & (1 << ix)) {
                // Start of a new allocation
                alloc_start = hostData->heapDptr + (uint64_t)(ptr - start_ptr) + ix;
                alloc_size = 1;
            }
        }
    }

    return CUDA_SUCCESS;
}

static CUresult
schemeCheckAccess_globallock(MCDynamicScheme *scheme, MCcontext *mcctx, CUtoolsStreamHandle stream, uint64_t addr, uint64_t size, CCmemAccessError *err)
{
    CUresult res = CUDA_SUCCESS;
    globalLockHostData *hostData = NULL;
    uint64_t offset_word_mask, start_word_offset, end_word_offset;
    uint64_t start_bit_offset, end_bit_offset;
    unsigned char start_word_mask, end_word_mask;
    unsigned char *start_word_ptr, *end_word_ptr, *word_ptr;

    if (!scheme || !mcctx) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    hostData = (globalLockHostData*)scheme->customData;

    /* If hostData is not set, the scheme was deactivated early */
    if (!hostData) {
        CU_TRACE_PRINT(("Couldnt find custom data\n"));
        return CUDA_SUCCESS;
    }

    /* Try to copy the tracker back to the host. Note that this can fail if there
       was a pending error on the context (e.g. blocking mode). In this case,
       we want to handle this gracefully and continue onwards.
       An error on synchronize would imply a launch error that will be reported
       by the error handling in memcheck. Memcheck will not report leaks if the
       context has hit an error.
    */
    res = CCmemShadowDtoHStream(&hostData->track, &hostData->track, stream, CC_MEM_SHADOW_ACTION_MEMCPY);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to download tracker\n"));
        return CUDA_SUCCESS;
    }

    /* In the tracker, we represent allocations as continuous strings of 1, with each 1
       corresponding to a byte. The goal is to count the number, size and starting address
       of leaks (i.e. strings of 1 in the tracker).
       Now, walk the entire tracker, one byte at a time. When we encounter a 1 at a bit
       position, we start the allocation, and continue till we hit a zero.

       Below is a simple 1 bit state machine to do the counting. It has two state
       registers - alloc_start and alloc_size. The internal state is tracked as
       the boolean condition of alloc_start, i.e. State = !!(alloc_start);
       It starts by assuming alloc_start and alloc_size are 0. The subsequent input
       to the state machine is the bit in the tracker. The logic is the following :

        State | Input | Action
        0     | 0     | None
        0     | 1     | A new allocation has started.
              |       | Update the alloc_start and reset alloc_size
        1     | 0     | An allocation has ended. Add a new allocation with
              |       | the values of alloc_start and alloc_size
        1     | 1     | Inside an allocation, increment size by 1
    */

    /* Get the full offset of the base word of the tracker */
    offset_word_mask = ~((uint64_t)(sizeof(*word_ptr) - 1));

    start_word_offset = ((addr - hostData->heapDptr) >> 3) & offset_word_mask;
    start_bit_offset  = ((addr - hostData->heapDptr) >> 3)  & (~offset_word_mask);

    end_word_offset = ((addr + size - 1 - hostData->heapDptr) >> 3) & offset_word_mask;
    end_bit_offset  = ((addr + size - 1 - hostData->heapDptr) >> 3) & (~offset_word_mask);

    /* Compute the beginning and end word masks.
       Since everything is little endian, the inital word
       mask has the MSB set and the final word mask has the LSB set */
    start_word_mask = (~0U) << start_bit_offset;
    end_word_mask   = (~0U) ^ ((~0U) << end_bit_offset);

    /* Compute the word pointers for the start and the end */
    start_word_ptr = ((unsigned char*)hostData->track.host.ptr + start_word_offset);
    end_word_ptr = ((unsigned char*)hostData->track.host.ptr + end_word_offset);

    /* Loop over every word, from the start, to (and including the end) */
    for (word_ptr = start_word_ptr; word_ptr <= end_word_ptr; ++word_ptr) {
        unsigned char word_mask = (~0);

        if (word_ptr == start_word_ptr)
            word_mask &= start_word_mask;

        if (word_ptr == end_word_ptr)
            word_mask &= end_word_mask;

        if (((*word_ptr) & word_mask) != ((~0U) & word_mask)) {
            /* All bits are not set, this means we are writing to unallocated memory */
            err->type = CC_MEM_ACCESS_ERROR_HEAP_CORRUPTION;

            err->foundNear = true;
            err->badAddr = (((uint64_t)(uintptr_t)((word_ptr) - (start_word_ptr))) << 3) + hostData->heapDptr;
            return CUDA_SUCCESS;
        }
    }

    return CUDA_SUCCESS;
}

CUresult
MCDynamicSchemeRegister_globallock(MCDynamicScheme *scheme)
{
    scheme->type        = MC_DYNAMIC_SCHEME_GLOBALLOCK;
    scheme->prefix      = "__cuda_syscall_mc_dyn_globallock_";
    scheme->name        = "GlobalLock";
    scheme->initialize  = &schemeInitialize_globallock;
    scheme->finalize    = &schemeFinalize_globallock;
    scheme->activate    = &schemeActivate_globallock;
    scheme->deactivate  = &schemeDeactivate_globallock;
    scheme->parseSyscallError = &schemeParseSyscallError_globallock;
    scheme->addLeaks    = &schemeAddLeaks_globallock;
    scheme->checkAccess = &schemeCheckAccess_globallock;

    return CUDA_SUCCESS;
}
