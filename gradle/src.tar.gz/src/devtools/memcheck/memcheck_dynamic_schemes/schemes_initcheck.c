/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
*
*   Module: schemes_initcheck.c
*
*   Description:
*       Implementation of a basic dummy scheme. This scheme does no work
*       and exists for testing of the dynamic memcheck mechanism.
*
*
******************************************************************************/

#include "schemes_initcheck.h"
#include "devtools/memcheck/initcheck/initcheck.h"

static CUresult
schemeInitialize_initcheck(MCDynamicScheme *scheme)
{
    return CUDA_SUCCESS;
}

static CUresult
schemeFinalize_initcheck(MCDynamicScheme *scheme)
{
    return CUDA_SUCCESS;
}

static CUresult
schemeActivate_initcheck(MCDynamicScheme *scheme, MCcontext *mcctx, CUtoolsStreamHandle stream)
{
    uint64_t globalData;
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    res = initcheckGetGlobalsDptr(mcctx, &globalData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to get globals information\n"));
        return res;
    }
    CU_TRACE_PRINT(("Writing syscall pointer to initcheck globals\n"));
    res = MCWriteSyscallConstBank(mcctx,
                                  mcctx->dynamic->mod->cumod,
                                  "MCICglobalDevDataPtr",
                                  &globalData,
                                  sizeof(globalData));
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to download const data\n"));
        return res;
    }


    CU_TRACE_PRINT(("Activate done for initcheck heap check\n"));

    return res;
}

static CUresult
schemeDeactivate_initcheck(MCDynamicScheme *scheme, MCcontext *mcctx, CUtoolsStreamHandle stream)
{
    CU_TRACE_FUNCTION();

    return CUDA_SUCCESS;
}

static CUresult
schemeParseSyscallError_initcheck(MCDynamicScheme *scheme, MCcontext *mcctx, CUmemcheck_record *err, uint32_t *hasError)
{
    return CUDA_SUCCESS;
}

static CUresult
schemeAddLeaks_initcheck(MCDynamicScheme *scheme, MCcontext *mcctx, CUtoolsStreamHandle stream)
{
    return CUDA_SUCCESS;
}

static CUresult
schemeCheckAccess_initcheck(MCDynamicScheme *scheme, MCcontext *mcctx, CUtoolsStreamHandle stream, uint64_t addr, uint64_t size, CCmemAccessError *err)
{
    return CUDA_SUCCESS;
}

CUresult
MCDynamicSchemeRegister_initcheck(MCDynamicScheme *scheme)
{
    scheme->type        = MC_DYNAMIC_SCHEME_NONE;
    scheme->prefix      = "__cuda_syscall_mc_dyn_initcheck_";
    scheme->name        = "None";
    scheme->initialize  = &schemeInitialize_initcheck;
    scheme->finalize    = &schemeFinalize_initcheck;
    scheme->activate    = &schemeActivate_initcheck;
    scheme->deactivate  = &schemeDeactivate_initcheck;
    scheme->parseSyscallError = &schemeParseSyscallError_initcheck;
    scheme->addLeaks    = &schemeAddLeaks_initcheck;
    scheme->checkAccess = &schemeCheckAccess_initcheck;

    return CUDA_SUCCESS;
}
