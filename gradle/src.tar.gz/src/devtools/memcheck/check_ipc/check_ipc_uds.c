/*
 * Copyright 2007-2015 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: check_ipc_uds.c
 *
 *   Description:
 *       Implementation of IPC using unix domain sockets
 *
 ******************************************************************************/

#ifdef UNIX_DOMAIN_SOCKETS

// Needed for struct ucred and SCM_CREDENTIALS in cuos.h
#define _GNU_SOURCE

/* Implementation of IPC using unix domain sockets
 *
 */
#include <stdlib.h>
#include <stddef.h>
#include <errno.h>
#include <unistd.h>
#include <poll.h>
#include <sys/socket.h>
#include <sys/un.h>

#include "cuda_stdint.h"
#include "cuos_platform_os.h"
#include "check_ipc.h"
#include "check_ipc_uds.h"
#include "check_ipc_utils.h"
#include "check_ipc_channel_event.h"

/* It seems we can't send a message (msghdr) without any payload (iov).
   So we send/recv an int which we can be used for additional verification. */
#define FD_CTRL_MAGIC 42

/* On QNX sending a message that's too big causes send(...) to be blocking.
 * By limiting the size to 1024 we ensure that send(...) never blocks.  */
#define QNX_MAX_SEND_SIZE 1024

typedef int32_t UnixSocket;
typedef struct sockaddr_un UnixSocketAddr;
typedef struct pollfd PollInfo;
typedef struct CCIPCudsChannel_st CCIPCudsChannel;
typedef struct CCIPCudsMsgHeader_st CCIPCudsMsgHeader;

typedef enum {
    CHANNEL_STATE_UNINITIALIZED = 0,
    CHANNEL_STATE_INITIALIZED,
    CHANNEL_STATE_CONNECTED
} CCIPCudsChannelState;

#pragma pack(push, 1)
struct CCIPCudsChannel_st {
    CCIPCudsChannelState state;
    UnixSocket sock;
    UnixSocket remoteSock;
    UnixSocketAddr addr;
    socklen_t addrSize;
    PollInfo pollInfo;
};

#pragma pack(pop)

static CCIPCresult
CCIPCudsHandleCreate(CCIPChandle *handle, const char *sendIpcName, const char *recvIpcName)
{
    const size_t pathMaxLen = sizeof(UnixSocketAddr) - offsetof(UnixSocketAddr, sun_path);

    CCIPC_TRACE_FUNCTION();

    CCIPC_DEBUG_PRINT("Creating UDS handle (send = %s, recv = %s)\n", sendIpcName, recvIpcName);

    /* Do some input error checking, but we don't need to create any
       actual UDS handle right now */

    if (!handle) {
        CCIPC_ERROR_PRINT("Invalid UDS handle\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    if (!sendIpcName || !recvIpcName ||
        strlen(sendIpcName) >= pathMaxLen ||
        strlen(recvIpcName) >= pathMaxLen) {
        CCIPC_ERROR_PRINT("Invalid socket name\n");
        return CCIPC_ERROR_INVALID_IPC_NAME;
    }

    /* Setup the implementation specific data pointer */
    handle->implementationData = NULL;

    return CCIPC_SUCCESS;
}

/* CCIPCudsHandleDestroy
 */
static CCIPCresult
CCIPCudsHandleDestroy(CCIPChandle *handle)
{
    CCIPC_TRACE_FUNCTION();

    if (!handle) {
        CCIPC_ERROR_PRINT("Invalid UDS handle\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    return CCIPC_SUCCESS;
}

/* CCIPCudsHandleForceCleanup
*/
static CCIPCresult
CCIPCudsHandleForceCleanup(const char *sendIpcName, const char *recvIpcName)
{
    /* unlink send and receive file paths */
    if (sendIpcName)
        unlink(sendIpcName);
    if (recvIpcName)
        unlink(recvIpcName);

    return CCIPC_SUCCESS;
}


/* CCIPCudsChannelCreate
*/
static CCIPCresult
CCIPCudsChannelCreate(CCIPCchannel *channel, const char *ipcName)
{
    CCIPCresult res = CCIPC_SUCCESS;
    CCIPCudsChannel *udsChannel = NULL;
    const size_t pathMaxLen = sizeof(UnixSocketAddr) - offsetof(UnixSocketAddr, sun_path);

    CCIPC_TRACE_FUNCTION();

    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!ipcName || (strlen(ipcName) >= pathMaxLen)) {
        CCIPC_ERROR_PRINT("Invalid argument\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    channel->implementation = NULL;

    udsChannel = (CCIPCudsChannel*)calloc(1, sizeof(*udsChannel));
    if (!udsChannel) {
        CCIPC_ERROR_PRINT("Failed to allocate udsChannel\n");
        return CCIPC_ERROR_OUT_OF_MEMORY;
    }

    /* fill socket path name with passed ipc name */
    udsChannel->addr.sun_family = AF_UNIX;
    strcpy(udsChannel->addr.sun_path, ipcName);
    udsChannel->addrSize = sizeof(udsChannel->addr.sun_family) + strlen(udsChannel->addr.sun_path);

    /* If ipcName starts with '#', the frontend expects an abstract name.
       Abstract names are supported on Linux only and start with the null byte. */
    if (udsChannel->addr.sun_path[0] == '#')
        udsChannel->addr.sun_path[0] = '\0';

    /* create the socket */
    udsChannel->sock = socket(AF_UNIX, SOCK_STREAM, 0);
    if (udsChannel->sock == -1) {
        CCIPC_ERROR_PRINT("Failed to open socket (errno = %d)\n", errno);
        res = CCIPC_ERROR_INTERNAL;
        goto Error;
    }

    /* for receiving/server channel, bind the socket to the provided ipc address/path */
    if (channel->type == CCIPC_CHANNEL_TYPE_RECEIVE) {
        if (bind(udsChannel->sock,
                 (struct sockaddr*)&(udsChannel->addr),
                 udsChannel->addrSize) == -1) {
            CCIPC_ERROR_PRINT("Failed to bind socket (errno = %d)\n", errno);
            res = CCIPC_ERROR_INTERNAL;
            goto Error;
        }

        if (listen(udsChannel->sock, 1) == -1) {
            CCIPC_ERROR_PRINT("Failed to listen on socket (errno = %d)\n", errno);
            res = CCIPC_ERROR_INTERNAL;
            goto Error;
        }

        /* setup poll info for this channel */
        udsChannel->pollInfo.events = POLLIN;
    } else {
        /* setup poll info for this channel */
        udsChannel->pollInfo.events = POLLOUT;
    }

    udsChannel->state = CHANNEL_STATE_INITIALIZED;

    channel->implementation = udsChannel;

    return CCIPC_SUCCESS;

Error:
    if (udsChannel) {
        free(udsChannel);
        udsChannel = NULL;
    }

    return res;
}

static CCIPCresult
CCIPCudsChannelDestroy(CCIPCchannel *channel)
{
    CCIPC_TRACE_FUNCTION();

    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!channel->implementation) {
        CCIPC_DEBUG_PRINT("Channel already free\n");
        return CCIPC_SUCCESS;
    }

    free(channel->implementation);
    channel->implementation = NULL;

    return CCIPC_SUCCESS;
}

/* CCIPCudsChannelInitialize
    This is called by the IAL to initialize a channel for uds channels.
*/
static CCIPCresult
CCIPCudsChannelInitialize(void *implementation, const char *name)
{
    /* Nothing to do here */
    return CCIPC_SUCCESS;
}

/* CCIPCudsChannelFinalize
    This is called by the IAL to finalize a channel.
*/
static CCIPCresult
CCIPCudsChannelFinalize(void *implementation)
{
    CCIPCudsChannel *udsChannel = NULL;

    CCIPC_TRACE_FUNCTION();

    if (!implementation) {
        CCIPC_ERROR_PRINT("Invalid channel handle\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    udsChannel = (CCIPCudsChannel*)implementation;

    if (udsChannel->sock) {
        close(udsChannel->sock);
        udsChannel->sock = 0;
    }

    return CCIPC_SUCCESS;
}

static CCIPCresult
pollChannel(CCIPCudsChannel *udsChannel, uint32_t timeoutMs)
{
    int32_t pollRes;
    cuosTimer timer;
    uint32_t remainingTimeoutMs = timeoutMs;

    cuosResetTimer(&timer);

    do {
        pollRes = poll(&(udsChannel->pollInfo), 1, remainingTimeoutMs);

        if ((pollRes == -1) && (errno == EINTR)) {
            /* after interrupt, retry with updated timeout */
            uint32_t currentTimer = cuosGetTimer(&timer);
            remainingTimeoutMs = (currentTimer >= timeoutMs) ? 0 : (timeoutMs - currentTimer);
        }
    } while ((pollRes == -1) && (errno == EINTR));

    switch (pollRes) {
    case -1:
        CCIPC_ERROR_PRINT("Error while polling on socket (errno = %d)\n", errno);
        return CCIPC_ERROR_INTERNAL;
    case 0:
        CCIPC_ERROR_PRINT("Timeout in reader. Waited for %u ms.\n", timeoutMs);
        return CCIPC_ERROR_TIMEOUT;
    default:
        return CCIPC_SUCCESS;
    }
}

static CCIPCresult
connectReadChannel(CCIPCudsChannel *udsChannel)
{
    UnixSocket remoteSock = 0;

    remoteSock = accept(udsChannel->sock, NULL, NULL);
    if (remoteSock == -1) {
        CCIPC_ERROR_PRINT("Failed to accept socket (errno = %d)\n", errno);
        return CCIPC_ERROR_INTERNAL;
    }

    udsChannel->remoteSock = remoteSock;
    udsChannel->pollInfo.fd = remoteSock;
    udsChannel->state = CHANNEL_STATE_CONNECTED;

    return CCIPC_SUCCESS;
}

static CCIPCresult
connectWriteChannel(CCIPCudsChannel *udsChannel)
{
    if (connect(udsChannel->sock,
                (struct sockaddr*)&(udsChannel->addr),
                udsChannel->addrSize) == -1) {
        CCIPC_ERROR_PRINT("Failed to connect socket (errno = %d)\n", errno);
        return CCIPC_ERROR_INTERNAL;
    }

    udsChannel->pollInfo.fd = udsChannel->sock;
    udsChannel->state = CHANNEL_STATE_CONNECTED;

    return CCIPC_SUCCESS;
}

/* CCIPCudsChannelRead
*/
static CCIPCresult
CCIPCudsChannelRead(void *implementation, void *buf, size_t bufSize, size_t *readSize, uint32_t timeoutMs)
{
    CCIPCudsChannel *udsChannel = NULL;
    CCIPCresult res;
    ssize_t bytesReceived = 0;

    CCIPC_TRACE_FUNCTION();

    if (!implementation) {
        CCIPC_ERROR_PRINT("Invalid channel handle\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!buf || !readSize) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    udsChannel = (CCIPCudsChannel*)implementation;

    if (udsChannel->state == CHANNEL_STATE_INITIALIZED) {
        res = connectReadChannel(udsChannel);
        if (res != CCIPC_SUCCESS)
            CCIPC_ERROR_PRINT("Failed to connect read channel\n");
        return res;
    }

    *readSize = 0;

    res = pollChannel(udsChannel, timeoutMs);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to poll channel\n");
        return res;
    }

    bytesReceived = recv(udsChannel->remoteSock,
                         buf,
                         bufSize,
                         0);

    if (bytesReceived == -1) {
        CCIPC_ERROR_PRINT("Error while receiving (errno = %d)\n", errno);
        return CCIPC_ERROR_INTERNAL;
    }

    *readSize = bytesReceived;

    return CCIPC_SUCCESS;
}

static CCIPCresult
CCIPCudsChannelWrite(void *implementation, void *buf, size_t bufSize, size_t *writeSize, uint32_t timeoutMs)
{
    CCIPCudsChannel *udsChannel = NULL;
    CCIPCresult res;
    ssize_t bytesSent = 0;

    CCIPC_TRACE_FUNCTION();

    if (!implementation) {
        CCIPC_ERROR_PRINT("Invalid channel handle\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!buf || !writeSize) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    udsChannel = (CCIPCudsChannel*)implementation;

    if (udsChannel->state == CHANNEL_STATE_INITIALIZED) {
        res = connectWriteChannel(udsChannel);
        if (res != CCIPC_SUCCESS)
            CCIPC_ERROR_PRINT("Failed to connect write channel\n");
        return res;
    }

    *writeSize = 0;

    res = pollChannel(udsChannel, timeoutMs);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to poll channel\n");
        return res;
    }

    // send() of large buffer causes QNX to block.
    if (cuosOsIsQnx() && bufSize >= QNX_MAX_SEND_SIZE) {
        bufSize = QNX_MAX_SEND_SIZE;
    }
    bytesSent = send(udsChannel->sock,
                     buf,
                     bufSize,
                     0);

    if (bytesSent == -1) {
        CCIPC_ERROR_PRINT("Error while sending (errno = %d)\n", errno);
        return CCIPC_ERROR_INTERNAL;
    }

    *writeSize = bytesSent;

    return CCIPC_SUCCESS;
}

static CCIPCresult
CCIPCudsChannelReadFd(void *implementation, CCIPCfd *fd, uint32_t timeoutMs)
{
    CCIPCudsChannel *udsChannel = NULL;
    CCIPCresult res;

    struct msghdr msg = {0};
    struct iovec iov = {0};
    int recvFd = 0;
    union {
        /* ancillary data buffer, union for alignment */
        char buf[CMSG_SPACE(sizeof(recvFd))];
        struct cmsghdr align;
    } cmsgUnion;
    struct cmsghdr *cmsg;
    int ctrl = 0;

    CCIPC_TRACE_FUNCTION();

    if (!implementation) {
        CCIPC_ERROR_PRINT("Invalid channel handle\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!fd) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    udsChannel = (CCIPCudsChannel*)implementation;

    if (udsChannel->state == CHANNEL_STATE_INITIALIZED) {
        res = connectReadChannel(udsChannel);
        if (res != CCIPC_SUCCESS)
            CCIPC_ERROR_PRINT("Failed to connect read channel\n");
        return res;
    }

    /* Ensure the sender is ready */
    res = pollChannel(udsChannel, timeoutMs);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to poll channel\n");
        return res;
    }

    /* Prepare the receive buffer */
    iov.iov_base = &ctrl;
    iov.iov_len  = sizeof(ctrl);

    msg.msg_iov        = &iov;
    msg.msg_iovlen     = 1;
    msg.msg_control    = cmsgUnion.buf;
    msg.msg_controllen = sizeof(cmsgUnion.buf);

    if (recvmsg(udsChannel->remoteSock, &msg, 0) == -1) {
        CCIPC_ERROR_PRINT("recvmsg failed (error = %d)\n", errno);
        return CCIPC_ERROR_INTERNAL;
    }

    cmsg = CMSG_FIRSTHDR(&msg);
    if (!cmsg) {
        CCIPC_ERROR_PRINT("Received message header is invalid\n");
        return CCIPC_ERROR_INTERNAL;
    }

    if (cmsg->cmsg_len != CMSG_LEN(sizeof(recvFd)) ||
        cmsg->cmsg_type != SCM_RIGHTS ||
        ctrl != FD_CTRL_MAGIC) {
        CCIPC_ERROR_PRINT("Received message is invalid\n");
        return CCIPC_ERROR_INTERNAL;
    }

    memcpy(&recvFd, CMSG_DATA(cmsg), sizeof(recvFd));
    fd->handle = (uint64_t)recvFd;

    return CCIPC_SUCCESS;
}

static CCIPCresult
CCIPCudsChannelWriteFd(void *implementation, CCIPCfd *fd, uint32_t timeoutMs)
{
    CCIPCudsChannel *udsChannel = NULL;
    CCIPCresult res;

    struct msghdr msg = {0};
    struct iovec iov = {0};
    const int sendFd = (int)fd->handle;
    union {
        /* ancillary data buffer, union for alignment */
        char buf[CMSG_SPACE(sizeof(sendFd))];
        struct cmsghdr align;
    } cmsgUnion;
    struct cmsghdr *cmsg = NULL;
    int ctrl = FD_CTRL_MAGIC;

    CCIPC_TRACE_FUNCTION();

    if (!implementation) {
        CCIPC_ERROR_PRINT("Invalid channel handle\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!fd) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    memset(&cmsgUnion.buf, 0, sizeof(cmsgUnion));
    udsChannel = (CCIPCudsChannel*)implementation;

    if (udsChannel->state == CHANNEL_STATE_INITIALIZED) {
        res = connectWriteChannel(udsChannel);
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to connect write channel\n");
            return res;
        }
    }

    /* Ensure the receiver is ready */
    res = pollChannel(udsChannel, timeoutMs);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to poll channel\n");
        return res;
    }

    /* Prepare the message to send, which includes the file descriptor */
    /* Technically, we don't need message payload (iov), but receive
       seems to fail otherwise. */
    iov.iov_base = &ctrl;
    iov.iov_len  = sizeof(ctrl);

    msg.msg_iov        = &iov;
    msg.msg_iovlen     = 1;
    msg.msg_control    = cmsgUnion.buf;
    msg.msg_controllen = sizeof(cmsgUnion.buf);

    cmsg = CMSG_FIRSTHDR(&msg);
    cmsg->cmsg_level = SOL_SOCKET;
    cmsg->cmsg_type  = SCM_RIGHTS;
    cmsg->cmsg_len   = CMSG_LEN(sizeof(sendFd));

    memcpy(CMSG_DATA(cmsg), &sendFd, sizeof(sendFd));

    /* Send message and check return code */
    if (sendmsg(udsChannel->sock, &msg, 0) == -1) {
        CCIPC_ERROR_PRINT("sendmsg failed to send fd (error = %d)\n", errno);
        return CCIPC_ERROR_INTERNAL;
    }

    return CCIPC_SUCCESS;
}

static CCIPCresult
CCIPCudsChannelForceCleanup(const char *ipcName)
{
    CCIPC_TRACE_FUNCTION();

    unlink(ipcName);

    return CCIPC_SUCCESS;
}

#else // ifdef UNIX_DOMAIN_SOCKETS

/* Implementation of IPC using unix domain sockets
 * on unsupported platforms (e.g. Windows)
 */
#include "check_ipc.h"
#include "check_ipc_uds.h"
#include "check_ipc_utils.h"
#include "check_ipc_channel_event.h"

static CCIPCresult
CCIPCudsHandleCreate(CCIPChandle *handle, const char *sendIpcName, const char *recvIpcName)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}

/* CCIPCudsHandleDestroy
 */
static CCIPCresult
CCIPCudsHandleDestroy(CCIPChandle *handle)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}

/* CCIPCudsHandleForceCleanup
*/
static CCIPCresult
CCIPCudsHandleForceCleanup(const char *sendIpcName, const char *recvIpcName)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}


/* CCIPCudsChannelCreate
*/
static CCIPCresult
CCIPCudsChannelCreate(CCIPCchannel *channel, const char *ipcName)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}

static CCIPCresult
CCIPCudsChannelDestroy(CCIPCchannel *channel)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}

/* CCIPCudsChannelInitialize
    This is called by the IAL to initialize a channel for uds channels.
*/
static CCIPCresult
CCIPCudsChannelInitialize(void *implementation, const char *name)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}

/* CCIPCudsChannelFinalize
    This is called by the IAL to finalize a channel.
*/
static CCIPCresult
CCIPCudsChannelFinalize(void *implementation)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}

/* CCIPCudsChannelRead
*/
static CCIPCresult
CCIPCudsChannelRead(void *implementation, void *buf, size_t bufSize, size_t *readSize, uint32_t timeoutMs)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}

static CCIPCresult
CCIPCudsChannelWrite(void *implementation, void *buf, size_t bufSize, size_t *writeSize, uint32_t timeoutMs)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}

static CCIPCresult
CCIPCudsChannelReadFd(void *implementation, CCIPCfd *fd, uint32_t timeoutMs)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}

static CCIPCresult
CCIPCudsChannelWriteFd(void *implementation, CCIPCfd *fd, uint32_t timeoutMs)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}

static CCIPCresult
CCIPCudsChannelForceCleanup(const char *ipcName)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}

#endif // ifdef UNIX_DOMAIN_SOCKETS

CCIPCresult
CCIPCudsGetIAL(CCIPCIAL *ial)
{
    if (!ial) {
        CCIPC_ERROR_PRINT("Invalid IAL pointer\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    ial->handleCreate           = CCIPCudsHandleCreate;
    ial->handleDestroy          = CCIPCudsHandleDestroy;
    ial->handleForceCleanup     = CCIPCudsHandleForceCleanup;
    ial->channelCreate          = CCIPCudsChannelCreate;
    ial->channelDestroy         = CCIPCudsChannelDestroy;
    ial->channelInitialize      = CCIPCudsChannelInitialize;
    ial->channelFinalize        = CCIPCudsChannelFinalize;
    ial->channelRead            = CCIPCudsChannelRead;
    ial->channelReadFd          = CCIPCudsChannelReadFd;
    ial->channelWrite           = CCIPCudsChannelWrite;
    ial->channelWriteFd         = CCIPCudsChannelWriteFd;
    ial->channelForceCleanup    = CCIPCudsChannelForceCleanup;

    ial->channelEventCreate     = CCIPCcommonChannelEventCreate;
    ial->channelEventSignal     = CCIPCcommonChannelEventSignal;
    ial->channelEventDestroy    = CCIPCcommonChannelEventDestroy;
    ial->channelEventIpcCreate  = CCIPCcommonChannelEventIpcCreate;
    ial->channelEventIpcDestroy = CCIPCcommonChannelEventIpcDestroy;
    ial->channelEventForceCleanup = CCIPCcommonChannelEventForceCleanup;
    ial->channelEventGetCuosEvent = CCIPCcommonChannelEventGetCuosEvent;

    CCIPC_DEBUG_PRINT("UDS IAL created\n");

    return CCIPC_SUCCESS;
}
