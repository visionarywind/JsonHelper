/*
* Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
*
* NOTICE TO USER:
*
* This source code is subject to NVIDIA ownership rights under U.S. and
* international Copyright laws.  Users and possessors of this source code
* are hereby granted a nonexclusive, royalty-free license to use this code
* in individual and commercial software.
*
* NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
* CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
* IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
* REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
* OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
* OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
* OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
* OR PERFORMANCE OF THIS SOURCE CODE.
*
* U.S. Government End Users.   This source code is a "commercial item" as
* that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
* "commercial computer  software"  and "commercial computer software
* documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
* and is provided to the U.S. Government only as a commercial end item.
* Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
* 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
* source code with only those rights set forth herein.
*
* Any use of this source code in individual and commercial software must
* include, in the user documentation and internal comments to the code,
* the above Disclaimer and U.S. Government End Users Notice.
*/

/******************************************************************************
*
*   Module: check_ipc_wnp.c
*
*   Description:
*       Implementation of IPC using Windows Named Pipes
*
******************************************************************************/

#ifdef WINDOWS_NAMED_PIPES

#include <stdlib.h>
#include <assert.h>
#include <windows.h>

#include "cuos.h"
#include "cuda_stdint.h"
#include "check_ipc.h"
#include "check_ipc_wnp.h"
#include "check_ipc_utils.h"
#include "check_ipc_channel_event.h"

#define BUFFER_SIZE (4 * 1024)

#define MAX_PIPE_NAME_LEN 256

#define FD_SRC_PROC_HANDLE_IDX 0
#define FD_SRC_HANDLE_IDX      1

typedef struct CCIPCwnpChannel_st CCIPCwnpChannel;

typedef enum {
    CHANNEL_STATE_UNINITIALIZED = 0,
    CHANNEL_STATE_INITIALIZED,
    CHANNEL_STATE_CONNECTED
} CCIPCwnpChannelState;

#pragma pack(push, 1)
struct CCIPCwnpChannel_st {
    CCIPCwnpChannelState state;
    char *pipeName;
    HANDLE hPipe;
    HANDLE hEvent;
    OVERLAPPED overlapped;
};
#pragma pack(pop)

static CCIPCresult
getWindowsPipeName(const char *suffix, char **dst)
{
    const DWORD maxNameLen = MAX_PATH <= MAX_PIPE_NAME_LEN ? MAX_PATH : MAX_PIPE_NAME_LEN;

    if (!suffix || !dst) {
        CCIPC_ERROR_PRINT("Invalid argument\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    *dst = calloc(1, maxNameLen);
    if (!*dst) {
        CCIPC_ERROR_PRINT("Failed to allocate pipe name\n");
        return CCIPC_ERROR_OUT_OF_MEMORY;
    }

    snprintf(*dst, maxNameLen - 1, "\\\\.\\pipe\\com.cuda.%s", suffix);

    return CCIPC_SUCCESS;
}

static HANDLE
wnpCreateEvent(void)
{
    HANDLE hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
    if (hEvent == NULL) {
        CCIPC_ERROR_PRINT("Failed to create event (error = %d)\n", GetLastError());
    }
    return hEvent;
}

static int32_t
wnpWaitForEvent(HANDLE hEvent, DWORD timeoutMs)
{
    switch (WaitForSingleObject(hEvent, timeoutMs)) {
    case WAIT_OBJECT_0:
        /* Event signaled */
        return 1;
    case WAIT_TIMEOUT:
        CCIPC_ERROR_PRINT("Timeout waiting for event, waited %d ms", timeoutMs);
        return 0;
    default:
        CCIPC_ERROR_PRINT("Error waiting for event (error = %d)\n", GetLastError());
        return 0;
    }
}

static CCIPCresult
CCIPCwnpHandleCreate(CCIPChandle *handle, const char *sendIpcName, const char *recvIpcName)
{
    CCIPCresult res = CCIPC_SUCCESS;
    const DWORD maxNameLen = MAX_PATH <= MAX_PIPE_NAME_LEN ? MAX_PATH : MAX_PIPE_NAME_LEN;

    CCIPC_TRACE_FUNCTION();

    if (!handle) {
        CCIPC_ERROR_PRINT("Invalid IPC handle\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    if (!sendIpcName || !recvIpcName ||
        strlen(sendIpcName) >= maxNameLen ||
        strlen(recvIpcName) >= maxNameLen) {
        CCIPC_ERROR_PRINT("Invalid WNP IPC name\n");
        return CCIPC_ERROR_INVALID_IPC_NAME;
    }

    CCIPC_DEBUG_PRINT("Using WNP IPC suffixes: %s and %s\n", sendIpcName, recvIpcName);

    /* Setup the implementation specific data pointer */
    handle->implementationData = NULL;

    return CCIPC_SUCCESS;
}

/* CCIPCwnpHandleDestroy
*/
static CCIPCresult
CCIPCwnpHandleDestroy(CCIPChandle *handle)
{
    CCIPC_TRACE_FUNCTION();

    if (!handle) {
        CCIPC_ERROR_PRINT("Invalid IPC handle\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    handle->implementationData = NULL;

    return CCIPC_SUCCESS;
}

/* CCIPCwnpHandleForceCleanup
*/
static CCIPCresult
CCIPCwnpHandleForceCleanup(const char *sendIpcName, const char *recvIpcName)
{
    return CCIPC_SUCCESS;
}

/* CCIPCwnpChannelCreate
*/
static CCIPCresult
CCIPCwnpChannelCreate(CCIPCchannel *channel, const char *ipcName)
{
    CCIPCresult res;
    CCIPCwnpChannel *wnpChannel = NULL;

    CCIPC_TRACE_FUNCTION();

    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!channel->handle) {
        CCIPC_ERROR_PRINT("Invalid handle\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    wnpChannel = (CCIPCwnpChannel*)calloc(1, sizeof(*wnpChannel));
    if (!wnpChannel) {
        CCIPC_ERROR_PRINT("Failed to allocate wnpChannel\n");
        return CCIPC_ERROR_OUT_OF_MEMORY;
    }

    res = getWindowsPipeName(ipcName, &wnpChannel->pipeName);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to get windows pipe name\n");
        goto Error;
    }

    wnpChannel->hEvent = wnpCreateEvent();
    if (NULL == wnpChannel->hEvent) {
        res = CCIPC_ERROR_INTERNAL;
        goto Error;
    }
    wnpChannel->overlapped.hEvent = wnpChannel->hEvent;

    /* Create the named pipe (on the server side). Actual connecting the pipes
    happens once the first write/read request on this pipe is issued.
    */
    if (channel->type == CCIPC_CHANNEL_TYPE_RECEIVE) {
        /* WNP server */
        wnpChannel->hPipe = CreateNamedPipe(
                                            wnpChannel->pipeName,
                                            PIPE_ACCESS_INBOUND | FILE_FLAG_OVERLAPPED,
                                            PIPE_TYPE_BYTE | PIPE_READMODE_BYTE | PIPE_REJECT_REMOTE_CLIENTS,
                                            1,            /* allow one instance */
                                            BUFFER_SIZE,  /* 0 outgoing buffer size */
                                            BUFFER_SIZE,  /* 0 incoming buffer size */
                                            0,            /* no timeout */
                                            NULL          /* default security attributes */);

        if (wnpChannel->hPipe == INVALID_HANDLE_VALUE) {
            CCIPC_ERROR_PRINT("Failed to create named pipe (error = %d)\n", GetLastError());
            res = CCIPC_ERROR_INTERNAL;
            goto Error;
        }

        CCIPC_DEBUG_PRINT("CreateNamedPipe successful\n");
    }

    channel->implementation = wnpChannel;
    wnpChannel->state = CHANNEL_STATE_INITIALIZED;

    CCIPC_DEBUG_PRINT("Channel %s created\n", ipcName);

    return CCIPC_SUCCESS;

Error:
    if (wnpChannel) {
        free(wnpChannel->pipeName);
        free(wnpChannel);
        wnpChannel = NULL;
    }
    return res;
}

/* CCIPCwnpChannelDestroy
*/
static CCIPCresult
CCIPCwnpChannelDestroy(CCIPCchannel *channel)
{
    CCIPCwnpChannel *wnpChannel = NULL;

    CCIPC_TRACE_FUNCTION();

    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!channel->implementation) {
        CCIPC_DEBUG_PRINT("Channel already free\n");
        return CCIPC_SUCCESS;
    }

    wnpChannel = (CCIPCwnpChannel*)channel->implementation;

    if (wnpChannel->hPipe) {
        if (channel->type == CCIPC_CHANNEL_TYPE_SEND) {
            /* Disconnect server end of named pipe from client process */
            if (FALSE == DisconnectNamedPipe(wnpChannel->hPipe)) {
                CCIPC_ERROR_PRINT("Failed to disconnect pipe\n");
            }
        }

        CloseHandle(wnpChannel->hPipe);
        wnpChannel->hPipe = 0;
        CCIPC_DEBUG_PRINT("Closed pipe for %s\n", wnpChannel->pipeName);
    }

    if (wnpChannel->hEvent) {
        CloseHandle(wnpChannel->hEvent);
        wnpChannel->hEvent = 0;
    }

    free(wnpChannel->pipeName);

    wnpChannel->state = CHANNEL_STATE_UNINITIALIZED;

    free(channel->implementation);
    channel->implementation = NULL;

    return CCIPC_SUCCESS;
}

/* CCIPCwnpChannelInitialize
This is called by the IAL to initialize a channel.
*/
static CCIPCresult
CCIPCwnpChannelInitialize(void *implementation, const char *name)
{
    /* Nothing to do here */
    return CCIPC_SUCCESS;
}

/* CCIPCwnpChannelFinalize
This is called by the IAL to finalize a channel.
*/
static CCIPCresult
CCIPCwnpChannelFinalize(void *implementation)
{
    /* Nothing to do here */
    return CCIPC_SUCCESS;
}

static CCIPCresult
wnpConnectReadChannel(CCIPCwnpChannel *wnpChannel, uint32_t timeoutMs)
{
    BOOL fConnected = FALSE;
    OVERLAPPED overlapped;
    HANDLE hEvent;

    /* Create event and initialize overlapped structure for connect */
    hEvent = wnpCreateEvent();
    if (NULL == hEvent) {
        return CCIPC_ERROR_INTERNAL;
    }
    memset(&overlapped, 0, sizeof(overlapped));
    overlapped.hEvent = hEvent;

    /* Asynchronously connect to client */
    fConnected = ConnectNamedPipe(wnpChannel->hPipe, &overlapped);

    if (!fConnected && GetLastError() == ERROR_PIPE_CONNECTED) {
        CCIPC_DEBUG_PRINT("Pipe already connected\n");
        fConnected = TRUE;
    }

    if (!fConnected && GetLastError() == ERROR_IO_PENDING) {
        if (!(wnpWaitForEvent(overlapped.hEvent, timeoutMs) &&
              GetOverlappedResult(
                                  wnpChannel->hPipe,
                                  &overlapped,
                                  NULL,
                                  FALSE))) {
            CCIPC_ERROR_PRINT("Failed to connect to pipe (1) (error = %d)", GetLastError());
            CloseHandle(hEvent);
            hEvent = 0;
            return CCIPC_ERROR_INTERNAL;
        }

        fConnected = TRUE;
    }

    CloseHandle(hEvent);
    hEvent = 0;

    if (!fConnected) {
        CCIPC_ERROR_PRINT("Failed to connect to pipe (2) (error = %d)", GetLastError());
        return CCIPC_ERROR_INTERNAL;
    }

    wnpChannel->state = CHANNEL_STATE_CONNECTED;

    return CCIPC_SUCCESS;
}

/* CCIPCwnpChannelRead
*/
static CCIPCresult
CCIPCwnpChannelRead(void *implementation, void *buf, size_t bufSize, size_t *readSize, uint32_t timeoutMs)
{
    CCIPCwnpChannel *wnpChannel = NULL;
    BOOL fSuccess = FALSE;
    DWORD bytesRead = 0;

    CCIPC_TRACE_FUNCTION();

    /* Some initial checks */
    if (!implementation) {
        CCIPC_ERROR_PRINT("Invalid channel handle\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!buf || !readSize) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    wnpChannel = (CCIPCwnpChannel*)implementation;
    *readSize = 0;

    if (wnpChannel->state == CHANNEL_STATE_UNINITIALIZED) {
        CCIPC_ERROR_PRINT("Read channel has not been initialized\n");
        return CCIPC_ERROR_INTERNAL;
    }

    if (wnpChannel->state == CHANNEL_STATE_INITIALIZED) {
        /* Channel is initialized but not yet connected to client */
        CCIPCresult res;

        res = wnpConnectReadChannel(wnpChannel, timeoutMs);
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to connect read channel %s\n", wnpChannel->pipeName);
            return res;
        }
    }

    /* Reset overlapped structure */
    if (!ResetEvent(wnpChannel->hEvent)) {
        CCIPC_ERROR_PRINT("Failed to reset event (error = %d)", GetLastError());
        return CCIPC_ERROR_INTERNAL;
    }
    memset(&(wnpChannel->overlapped), 0, sizeof(wnpChannel->overlapped));
    wnpChannel->overlapped.hEvent = wnpChannel->hEvent;

    /* Limit read/write size to the maximum size allocated for WNP.
     * The caller is responsible for retrying the read/write for remaining data. */
    if (bufSize > BUFFER_SIZE)
        bufSize = BUFFER_SIZE;

    /* Asynchronously read from pipe and wait for result event to be signalled */
    fSuccess = ReadFile(
                        wnpChannel->hPipe,
                        buf,
                        (DWORD)bufSize,
                        &bytesRead,
                        &(wnpChannel->overlapped));

    if (!fSuccess && GetLastError() != ERROR_IO_PENDING) {
        CCIPC_ERROR_PRINT("ReadFile failed (error = %d)\n", GetLastError());
        return CCIPC_ERROR_INTERNAL;
    }

    /* If not yet completed in ReadFile, wait for the event (or until timeout) */
    if (!fSuccess &&
        !(wnpWaitForEvent(wnpChannel->overlapped.hEvent, timeoutMs) &&
          GetOverlappedResult(
                              wnpChannel->hPipe,
                              &(wnpChannel->overlapped),
                              &bytesRead,
                              FALSE))) {
        CCIPC_ERROR_PRINT("Failed to read (error = %d)\n", GetLastError());
        return CCIPC_ERROR_INTERNAL;
    }

    CCIPC_DEBUG_PRINT("Read %d bytes from %s\n", bytesRead, wnpChannel->pipeName);

    *readSize = bytesRead;

    return CCIPC_SUCCESS;
}

static CCIPCresult
wnpConnectWriteChannel(CCIPCwnpChannel *wnpChannel)
{
    wnpChannel->hPipe = CreateFile(
                                   wnpChannel->pipeName,
                                   GENERIC_WRITE,
                                   0,                      /* no sharing */
                                   NULL,                   /* default security attributes */
                                   OPEN_EXISTING,          /* opens existing pipe */
                                   FILE_FLAG_OVERLAPPED,   /* overlapped mode */
                                   NULL                    /* no template file */);

    if (wnpChannel->hPipe == INVALID_HANDLE_VALUE) {
        CCIPC_ERROR_PRINT("Failed to create file (error = %d)", GetLastError());
        return CCIPC_ERROR_INTERNAL;
    }

    wnpChannel->state = CHANNEL_STATE_CONNECTED;
    return CCIPC_SUCCESS;
}

/* CCIPCwnpChannelWrite
*/
static CCIPCresult
CCIPCwnpChannelWrite(void *implementation, void *buf, size_t bufSize, size_t *writeSize, uint32_t timeoutMs)
{
    CCIPCwnpChannel *wnpChannel = NULL;
    BOOL fSuccess = FALSE;
    DWORD bytesWritten = 0;

    CCIPC_TRACE_FUNCTION();

    /* Some initial checks */
    if (!implementation) {
        CCIPC_ERROR_PRINT("Invalid channel handle\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!buf || !writeSize) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    if (!bufSize) {
        CCIPC_ERROR_PRINT("0 size write\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    wnpChannel = (CCIPCwnpChannel*)implementation;
    *writeSize = 0;

    if (wnpChannel->state == CHANNEL_STATE_UNINITIALIZED) {
        CCIPC_ERROR_PRINT("Write channel has not been initialized\n");
        return CCIPC_ERROR_INTERNAL;
    }

    if (wnpChannel->state == CHANNEL_STATE_INITIALIZED) {
        /* Channel is initialized but not yet connected to server */
        CCIPCresult res;

        res = wnpConnectWriteChannel(wnpChannel);
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to connect write channel %s\n", wnpChannel->pipeName);
            return res;
        }
    }

    /* Reset overlapped structure */
    if (!ResetEvent(wnpChannel->hEvent)) {
        CCIPC_ERROR_PRINT("Failed to reset event (error = %d)", GetLastError());
        return CCIPC_ERROR_INTERNAL;
    }
    memset(&(wnpChannel->overlapped), 0, sizeof(wnpChannel->overlapped));
    wnpChannel->overlapped.hEvent = wnpChannel->hEvent;

    /* Limit read/write size to the maximum size allocated for WNP.
     * The caller is responsible for retrying the read/write for remaining data. */
    if (bufSize > BUFFER_SIZE)
        bufSize = BUFFER_SIZE;

    /* Asynchronously write to pipe and wait for result */
    fSuccess = WriteFile(
                         wnpChannel->hPipe,
                         buf,
                         (DWORD)bufSize,
                         &bytesWritten,
                         &(wnpChannel->overlapped));

    if (!fSuccess && GetLastError() != ERROR_IO_PENDING) {
        CCIPC_ERROR_PRINT("WriteFile failed (error = %d)", GetLastError());
        return CCIPC_ERROR_INTERNAL;
    }

    /* If not yet completed in WriteFile, wait for the event (or until timeout) */
    if (!fSuccess &&
        !(wnpWaitForEvent(wnpChannel->overlapped.hEvent, timeoutMs) &&
          GetOverlappedResult(
                              wnpChannel->hPipe,
                              &(wnpChannel->overlapped),
                              &bytesWritten,
                              FALSE))) {
        CCIPC_ERROR_PRINT("Failed to write (error = %d)", GetLastError());
        return CCIPC_ERROR_INTERNAL;
    }

    *writeSize = bytesWritten;

    CCIPC_DEBUG_PRINT("Wrote %d bytes on %s\n", bytesWritten, wnpChannel->pipeName);

    return CCIPC_SUCCESS;
}

static CCIPCresult
CCIPCwnpChannelReadFd(void *implementation, CCIPCfd *fd, uint32_t timeoutMs)
{
    CCIPCresult res;
    HANDLE handles[2] = {0};
    HANDLE duplicateHandle = 0;
    size_t totalReadSize = 0;

    CCIPC_TRACE_FUNCTION();

    if (!implementation) {
        CCIPC_ERROR_PRINT("Invalid channel handle\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!fd) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    /* Read from pipe until we read two HANDLEs */
    while (totalReadSize < sizeof(handles)) {
        const size_t remainingBytes = sizeof(handles) - totalReadSize;
        size_t readSize = 0;

        res = CCIPCwnpChannelRead(implementation, ((uint8_t*)handles) + totalReadSize,
                                  remainingBytes, &readSize, timeoutMs);

        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to read fd handles from pipe\n");
            return res;
        }

        totalReadSize += readSize;
    }

    /* Duplicate source handles */
    if (DuplicateHandle(handles[FD_SRC_PROC_HANDLE_IDX],
                        handles[FD_SRC_HANDLE_IDX],
                        GetCurrentProcess(),
                        &duplicateHandle,
                        0,
                        FALSE,
                        DUPLICATE_SAME_ACCESS) == FALSE) {
        CCIPC_ERROR_PRINT("Failed to duplicate handle\n");
        return CCIPC_ERROR_INTERNAL;
    }

    fd->handle = (uint64_t)duplicateHandle;

    return CCIPC_SUCCESS;
}

static CCIPCresult
CCIPCwnpChannelWriteFd(void *implementation, CCIPCfd *fd, uint32_t timeoutMs)
{
    CCIPCresult res;
    HANDLE handles[2] = {0};
    size_t totalWriteSize = 0;

    CCIPC_TRACE_FUNCTION();

    if (!implementation) {
        CCIPC_ERROR_PRINT("Invalid channel handle\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!fd) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    handles[FD_SRC_PROC_HANDLE_IDX] = GetCurrentProcess();
    handles[FD_SRC_HANDLE_IDX] = (HANDLE)fd->handle;

    /* Send source handles over the pipe */
    while (totalWriteSize < sizeof(handles)) {
        const size_t remainingBytes = sizeof(handles) - totalWriteSize;
        size_t writeSize = 0;

        res = CCIPCwnpChannelWrite(implementation, ((uint8_t*)handles) + totalWriteSize,
                                   remainingBytes, &writeSize, timeoutMs);
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to write handles to pipe\n");
            return res;
        }

        totalWriteSize += writeSize;
    }

    return CCIPC_SUCCESS;
}

static CCIPCresult
CCIPCwnpChannelForceCleanup(const char *ipcName)
{
    /* Nothing to do here */
    return CCIPC_SUCCESS;
}

#else // WINDOWS_NAMED_PIPES

/* Implementation of IPC using windows named pipes
* on unsupported platforms (e.g. Linux)
*/
#include "check_ipc.h"
#include "check_ipc_wnp.h"
#include "check_ipc_utils.h"
#include "check_ipc_channel_event.h"

static CCIPCresult
CCIPCwnpHandleCreate(CCIPChandle *handle, const char *sendIpcName, const char *recvIpcName)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}

/* CCIPCwnpHandleDestroy
*/
static CCIPCresult
CCIPCwnpHandleDestroy(CCIPChandle *handle)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}

/* CCIPCwnpHandleForceCleanup
*/
static CCIPCresult
CCIPCwnpHandleForceCleanup(const char *sendIpcName, const char *recvIpcName)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}

/* CCIPCwnpChannelCreate
*/
static CCIPCresult
CCIPCwnpChannelCreate(CCIPCchannel *channel, const char *ipcName)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}

/* CCIPCwnpChannelDestroy
*/
static CCIPCresult
CCIPCwnpChannelDestroy(CCIPCchannel *channel)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}

/* CCIPCwnpChannelInitialize
This is called by the IAL to initialize a channel.
*/
static CCIPCresult
CCIPCwnpChannelInitialize(void *implementation, const char *name)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}

/* CCIPCwnpChannelFinalize
This is called by the IAL to finalize a channel.
*/
static CCIPCresult
CCIPCwnpChannelFinalize(void *implementation)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}

/* CCIPCwnpChannelRead
*/
static CCIPCresult
CCIPCwnpChannelRead(void *implementation, void *buf, size_t bufSize, size_t *readSize, uint32_t timeoutMs)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}

/* CCIPCwnpChannelWrite
*/
static CCIPCresult
CCIPCwnpChannelWrite(void *implementation, void *buf, size_t bufSize, size_t *writeSize, uint32_t timeoutMs)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}

static CCIPCresult
CCIPCwnpChannelReadFd(void *implementation, CCIPCfd *fd, uint32_t timeoutMs)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}

static CCIPCresult
CCIPCwnpChannelWriteFd(void *implementation, CCIPCfd *fd, uint32_t timeoutMs)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}

static CCIPCresult
CCIPCwnpChannelForceCleanup(const char *ipcName)
{
    return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;
}

#endif // WINDOWS_NAMED_PIPES

CCIPCresult
CCIPCwnpGetIAL(CCIPCIAL *ial)
{
    if (!ial) {
        CCIPC_ERROR_PRINT("Invalid IAL pointer\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    ial->handleCreate = CCIPCwnpHandleCreate;
    ial->handleDestroy = CCIPCwnpHandleDestroy;
    ial->handleForceCleanup = CCIPCwnpHandleForceCleanup;
    ial->channelCreate = CCIPCwnpChannelCreate;
    ial->channelDestroy = CCIPCwnpChannelDestroy;
    ial->channelInitialize = CCIPCwnpChannelInitialize;
    ial->channelFinalize = CCIPCwnpChannelFinalize;
    ial->channelRead = CCIPCwnpChannelRead;
    ial->channelReadFd = CCIPCwnpChannelReadFd;
    ial->channelWrite = CCIPCwnpChannelWrite;
    ial->channelWriteFd = CCIPCwnpChannelWriteFd;
    ial->channelForceCleanup = CCIPCwnpChannelForceCleanup;

    ial->channelEventCreate = CCIPCcommonChannelEventCreate;
    ial->channelEventSignal = CCIPCcommonChannelEventSignal;
    ial->channelEventDestroy = CCIPCcommonChannelEventDestroy;
    ial->channelEventIpcCreate = CCIPCcommonChannelEventIpcCreate;
    ial->channelEventIpcDestroy = CCIPCcommonChannelEventIpcDestroy;
    ial->channelEventForceCleanup = CCIPCcommonChannelEventForceCleanup;
    ial->channelEventGetCuosEvent = CCIPCcommonChannelEventGetCuosEvent;

    CCIPC_DEBUG_PRINT("WNP IAL created\n");

    return CCIPC_SUCCESS;
}
