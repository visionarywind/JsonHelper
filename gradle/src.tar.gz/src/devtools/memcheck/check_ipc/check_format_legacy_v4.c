/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: check_format_legacy_v4.h
 *
 *   Description:
 *      Functions to use the legacy format (record version = 4)
 *
 ******************************************************************************/
#include "cudamemcheck.h"
#include "check_format.h"
#include "check_format_internal.h"
#include "check_format_legacy.h"

#define CUDA_MEMCHECK_MAGIC_v4 "cuda-memcheck error record3"

typedef struct {
    char magic[28];
    CUDBGException_t type;
    uint64_t addr;
    uint32_t pc;             /* ~0 signifies unknown */
    uint32_t size;           /* Transfer size in bytes, 0 if unknown */
    uint32_t write;
    uint32_t blockIdxX, blockIdxY, blockIdxZ;
    uint32_t threadIdxX, threadIdxY, threadIdxZ;
    uint32_t lineno;        /* 0 if unknown */
    uint32_t padding;       /* See bug 710232 */
    uint32_t funcnamesize;
    uint32_t pathnamesize;
    uint32_t padding2;
    /* Conceptually
    char funcname[funcnamesize];
    char pathname[pathnamesize];
    */
} MCerror_v4;

uint64_t
getLegacyRecordSize_v4(CUmemcheck_record *rec)
{
    uint64_t sizectr = 0;
    CUmemcheck_record_string* head = NULL;
    strTracker *tracker = NULL;
    CUmemcheck_error_record *err = NULL;

    if (!rec)
        return 0;

    if (rec->recordclass != CU_MEMCHECK_RECORD_CLASS_ERROR)
        return 0;

    err = &rec->cases.error;

    if (err->errortype == CU_MEMCHECK_RECORD_INVALID)
        return 0;

    if (err->errortype == CU_MEMCHECK_RECORD_MEM_PRECISE ||
        err->errortype == CU_MEMCHECK_RECORD_MEM_IMPRECISE) {
        sizectr += sizeof(MCerror_v4);
        tracker = (strTracker*) rec->strings;
        for (head = tracker->list; head; head = head->next) {
            if ((head->flags & CU_MEMCHECK_RECORD_STRING_NAME) |
                (head->flags & CU_MEMCHECK_RECORD_STRING_PATH))
                sizectr += head->sz;
        }
        return sizectr;
    }

    return sizectr;
}

CCIPCresult
writeLegacyRecord_v4(CUmemcheck_record *rec, void *buf, uint64_t size)
{
    CUmemcheck_record_string *head = NULL;
    MCerror_v4 olderror;
    char *funcname = NULL;
    char *pathname = NULL;
    strTracker *tracker = NULL;
    char *curptr = NULL;
    uint64_t sizectr = 0;
    CUmemcheck_error_record *err = NULL;

    if (!rec || !buf || !size)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    if (rec->recordclass != CU_MEMCHECK_RECORD_CLASS_ERROR)
        return CCIPC_SUCCESS;

    err = &rec->cases.error;

    if (err->errortype == CU_MEMCHECK_RECORD_INVALID)
        return CCIPC_SUCCESS;

    curptr = (char*)buf;

    memset(&olderror, 0, sizeof olderror);

    if (err->errortype == CU_MEMCHECK_RECORD_MEM_PRECISE) {
        sizectr += sizeof(olderror);
        (void) strcpy(olderror.magic, CUDA_MEMCHECK_MAGIC_v4);
        olderror.type       = err->cases.memPrecise.exception;
        olderror.addr       = err->cases.memPrecise.address;
        olderror.pc         = err->cases.memPrecise.pc;
        olderror.size       = err->cases.memPrecise.size;
        olderror.write      = err->cases.memPrecise.write;
        olderror.blockIdxX  = err->cases.memPrecise.blockIdxX;
        olderror.blockIdxY  = err->cases.memPrecise.blockIdxY;
        olderror.blockIdxZ  = err->cases.memPrecise.blockIdxZ;
        olderror.threadIdxX = err->cases.memPrecise.threadIdxX;
        olderror.threadIdxY = err->cases.memPrecise.threadIdxY;
        olderror.threadIdxZ = err->cases.memPrecise.threadIdxZ;
        olderror.lineno     = err->cases.memPrecise.lineno;

        olderror.funcnamesize = 0;
        olderror.pathnamesize = 0;
        tracker = (strTracker*) rec->strings;
        for (head = tracker->list; head; head = head->next) {
            if (head->flags & CU_MEMCHECK_RECORD_STRING_NAME) {
                olderror.funcnamesize = head->sz;
                funcname = head->str;
                sizectr += head->sz;
            }
            if (head->flags & CU_MEMCHECK_RECORD_STRING_PATH) {
                olderror.pathnamesize = head->sz;
                pathname = head->str;
                sizectr += head->sz;
            }
        }

        if (size < sizectr)
            return CCIPC_ERROR_FORMAT_UNDERSIZED_BUFFER;

        memcpy((void*)curptr, (void*)&olderror, sizeof(olderror));
        curptr += sizeof(olderror);

        if (funcname) {
            memcpy((void*)curptr, (void*)funcname, olderror.funcnamesize);
            curptr += olderror.funcnamesize;
        }

        if (pathname) {
            memcpy((void*)curptr, (void*)pathname, olderror.pathnamesize);
            curptr += olderror.pathnamesize;
        }

    }
    else if (err->errortype == CU_MEMCHECK_RECORD_MEM_IMPRECISE) {
        sizectr += sizeof(olderror);
        (void) strcpy(olderror.magic, CUDA_MEMCHECK_MAGIC_v4);
        olderror.type       = err->cases.memImprecise.exception;
        olderror.addr       = err->cases.memImprecise.address;
        olderror.pc         = err->cases.memImprecise.pc;
        olderror.size       = 0;
        olderror.write      = 0;
        olderror.blockIdxX  = err->cases.memImprecise.blockIdxX;
        olderror.blockIdxY  = err->cases.memImprecise.blockIdxY;
        olderror.blockIdxZ  = err->cases.memImprecise.blockIdxZ;
        olderror.threadIdxX = err->cases.memImprecise.threadIdxX;
        olderror.threadIdxY = err->cases.memImprecise.threadIdxY;
        olderror.threadIdxZ = err->cases.memImprecise.threadIdxZ;
        olderror.lineno     = 0;

        olderror.funcnamesize = 0;
        olderror.pathnamesize = 0;
        tracker = (strTracker*) rec->strings;
        for (head = tracker->list; head; head = head->next) {
            if (head->flags & CU_MEMCHECK_RECORD_STRING_NAME) {
                olderror.funcnamesize = head->sz;
                funcname = head->str;
                sizectr += head->sz;
            }
            if (head->flags & CU_MEMCHECK_RECORD_STRING_PATH) {
                olderror.pathnamesize = head->sz;
                pathname = head->str;
                sizectr += head->sz;
            }
        }

        if (size < sizectr)
            return CCIPC_ERROR_FORMAT_UNDERSIZED_BUFFER;

        memcpy((void*)curptr, (void*)&olderror, sizeof(olderror));
        curptr += sizeof(olderror);

        if (funcname) {
            memcpy((void*)curptr, (void*)funcname, olderror.funcnamesize);
            curptr += olderror.funcnamesize;
        }

        if (pathname) {
            memcpy((void*)curptr, (void*)pathname, olderror.pathnamesize);
            curptr += olderror.pathnamesize;
        }
    }

    return CCIPC_SUCCESS;
}
