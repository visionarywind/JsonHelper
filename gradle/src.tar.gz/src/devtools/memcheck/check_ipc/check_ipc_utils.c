/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "check_ipc_utils.h"
#include "cuos.h"

#include <stdlib.h>

#ifdef DEBUG

#define MAX_MSG 4096

static int haslevel = 0;
static unsigned int envlevel = 0;

static const char*
fileGetDomain(const char *file)
{
    if (!file)
        return "";

    if (strstr(file, "check_format"))
        return "FMT:";
    if (strstr(file, "check_ipc"))
        return "IPC:";

    return "";
}

void CCIPCdebugPrint(const char *file, int line, CCIPCdebugLevel level, const char *msg, ...)
{
    char *ipc_message = NULL;
    va_list marker;
    char *pfx = NULL;

    if (!haslevel) {
        char env_var[CUOS_ENV_VAR_LENGTH] = {0};
        if (!cuosGetEnv("CCIPC_TRACE_LEVEL", env_var, CUOS_ENV_VAR_LENGTH))
            envlevel = atoi(env_var);
        haslevel = 1;
    }

    if (envlevel <= (unsigned int)level)
        return;

    switch (level) {
    case CCIPC_DEBUG_LEVEL_ERROR:
        pfx = "EE:";
        break;
    case CCIPC_DEBUG_LEVEL_DEBUG:
        pfx = "DD:";
        break;
    case CCIPC_DEBUG_LEVEL_TRACE:
        pfx = "TT:";
        break;
    default:
        pfx = "XX:";
        break;
    }

    ipc_message = (char*)calloc(1, MAX_MSG);
    va_start(marker, msg);
    vsnprintf(ipc_message, MAX_MSG, msg, marker);
    va_end(marker);
    fprintf(stderr, "%s:[%s](%u):%s:%d:%s\n",
            pfx,
            fileGetDomain(file),
            (unsigned int)(cuosProcessId()),
            file,
            line,
            ipc_message);
    free(ipc_message);
}
#endif
