/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: check_ipc_shm_align.c
 *
 *   Description:
 *       Implementation of IPC using shared memory
 *
 ******************************************************************************/

/* Implementation of IPC using shared memory
   This implementation guarantees that atomic accesses will happen to aligned
   memory locations.

    The basic implementation is similar to that in check_ipc_shm.c (so see
    comments there). Each shm channel is implemented using a pair of circular
    buffers. Each buffer is aligned to a 32 byte address in VA.

    Fundamentally, each channel is represented by a circular buffer
    with 4 pointers. These are the rules for the pointers:

    1. writeOuter is always beyond writeInner. The space between
       writeOuter and writeInner is actively being written

    2. readOuter is always beyond readInner. The space between
       readOuter and readInner is being actively read

    3. writeInner is always beyond readOuter. The space between
       readOuter to writeInner are the records that are still
       to be read.

    4. writeOuter is always beyond readInner. The space between
       writeOuter and readInner is the free space in the circular buffer.


    Based on these, we can come up with the following invariants:

    1. Writer side:
        1.1 Space in the buffer is calculated as:
            sz = (writeOuter >= readInner) ? BUF_SZ - (writeOuter - readInner) : (readInner - writeOuter);

        1.2 If space >= size of the message, atomically increment writeOuter
        1.3 Start writing at old value of writeOuter.
        1.4 Wait until writeInner is at old writeOuter.
        1.5 Atomically increment writeInner by size of message.

    2. Reader Side:
        2.1 Compute size to read as :
            sz = (writeInner >= readOuter) ? writeInner - readOuter : BUF_SZ - readOuter + writeInner;
        2.2 Atomically increment readOuter
        2.3 Start reading at old value of readOuter
        2.4 Wait until readInner is at old value of readOuter
        2.5 Atomically increment readInner by size of read

           readInner       readOuter
               |              |
               V              V
         |-------------------------------------------------------|
         |     |RRRRRRRRRRRRRR|++++++++|WWWWWWWWWWWWWWWW|        |
         |-------------------------------------------------------|
                                       ^                ^
                                       |                |
                                   writeInner         writeOuter

        In the picture above, R : bytes being read
                              + : bytes ready to read
                              W : bytes being written

 */
#include <stdlib.h>
#include "cuos.h"
#include "cuda_stdint.h"
#include "check_ipc.h"
#include "check_ipc_shm_align.h"
#include "check_ipc_utils.h"
#include "check_ipc_channel_event.h"

#define BUFFER_SIZE (128 * 1024)
#define NUM_CHANNELS 2

typedef struct CCIPCshmAlignHandle_st CCIPCshmAlignHandle;
typedef struct CCIPCshmAlignChannelPair_st CCIPCshmAlignChannelPair;
typedef struct CCIPCshmAlignChannel_st CCIPCshmAlignChannel;
typedef struct CCIPCshmAlignChannelHeader_st CCIPCshmAlignChannelHeader;

#pragma pack(push, 1)
struct CCIPCshmAlignChannelHeader_st {
    volatile uint32_t readOuter;
    volatile uint32_t readInner;
    volatile uint32_t writeOuter;
    volatile uint32_t writeInner;
};

struct CCIPCshmAlignChannel_st {
    CCIPCshmAlignChannelHeader header;
    char buffer[BUFFER_SIZE];
};

struct CCIPCshmAlignChannelPair_st {
    CCIPCshmAlignChannel channels[NUM_CHANNELS];
};

struct CCIPCshmAlignHandle_st {
    cuosShmInfoEx *info;
};
#pragma pack(pop)


/* Create a shmem allocation. This will use the handle of the abstract
   channel passed in at CCIPChandle. This function will do the following:
    1. Allocate the implementation data (of type CCIPCshmHandle)
    2. Try to open the shmem at the given name.
       Note : name contains the PID of the frontend
    3. If the open at step 2 fails, then this will first create a new shmem region
       with the given name. It will then attempt to open this handle.
    4. Assign the raw channels in the handle structure to point to the correct
       shmem region. Depending on the endpoint, this will swizzle the regions
       so that the two endpoints will actually use the appropriate channels
       as their senders/receivers
    5. Fill in the implementation data in the handle with the shmem info pointer
*/
static CCIPCresult
CCIPCshmAlignHandleCreate(CCIPChandle *handle, const char *sendIpcName, const char *recvIpcName)
{
    CCIPCresult res = CCIPC_SUCCESS;
    CCIPCshmAlignHandle *shmAlignHandle = NULL;
    size_t shmAlignSize = 0;
    int cuosret = 0;

    CCIPC_TRACE_FUNCTION();

    if (!handle) {
        CCIPC_ERROR_PRINT("Invalid IPC handle\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    if (!sendIpcName) {
        CCIPC_ERROR_PRINT("Invalid SHMEM name\n");
        return CCIPC_ERROR_INVALID_IPC_NAME;
    }

    CCIPC_DEBUG_PRINT("Using SHMEM name:%s\n", sendIpcName);

    /* shmAlignHandle contains the shmAlign specific implementation info */
    shmAlignHandle = (CCIPCshmAlignHandle*)calloc(1, sizeof(*shmAlignHandle));
    if (!shmAlignHandle) {
        CCIPC_ERROR_PRINT("Failed to allocate shmAlignHandle\n");
        res = CCIPC_ERROR_OUT_OF_MEMORY;
        goto Error;
    }

    shmAlignSize = sizeof(CCIPCshmAlignChannelPair);

    /* If the shmAlign can be directly opened, try that */
    cuosret = cuosShmOpenNamedEx(NULL, sendIpcName, shmAlignSize, &shmAlignHandle->info);
    if (cuosret != CUOS_SUCCESS) {
        CCIPC_DEBUG_PRINT("Failed on first try to open shmAlignem handle\n");
        /* Failed to open the shmAlignem handle. Try creating it instead. */
        cuosret = cuosShmCreateNamedEx(NULL, sendIpcName, shmAlignSize, &shmAlignHandle->info);
        if (cuosret != CUOS_SUCCESS) {
            CCIPC_DEBUG_PRINT("Failed to create shmAlignem region. Src:%u Dst:%u. Name:%s\n",
                              handle->src, handle->dst, sendIpcName);
            /* At this point, there can be a failure if the endpoints
               are racing between each other on create. If so, the
               next line will throw an error.
            */
        }

        /* Now open the shmAlignem that was just created */
        cuosret = cuosShmOpenNamedEx(NULL, sendIpcName, shmAlignSize, &shmAlignHandle->info);
        if (cuosret != CUOS_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to open shmAlignem region after creation.");
            res = CCIPC_ERROR_FAILED_IPC_SETUP;
            goto Error;
        }
    }

    /* At this point, shmAlignHandle->info->addr contains the base address of the pair */
    if (!shmAlignHandle->info->addr) {
        CCIPC_ERROR_PRINT("Failed to get pointer to shmAlignem region\n");
        /* Something went wrong */
        res = CCIPC_ERROR_FAILED_IPC_SETUP;
        goto Error;
    }

    /* Setup the implementation specific data pointer */
    handle->implementationData = shmAlignHandle;

    return CCIPC_SUCCESS;

Error:
    if (shmAlignHandle) {
        if (shmAlignHandle->info) {
            cuosShmCloseEx(shmAlignHandle->info, CUOS_VIRTUAL_FREE_RELEASE, 1);
            shmAlignHandle->info = NULL;
        }

        free(shmAlignHandle);
        shmAlignHandle = NULL;
        handle->implementationData = NULL;
    }
    return res;
}

/* CCIPCshmAlignHandleDestroy
    Unmap the shared memory, destroy it if no channel is still in use.
 */
static CCIPCresult
CCIPCshmAlignHandleDestroy(CCIPChandle *handle)
{
    CCIPCshmAlignHandle *shmAlignHandle = NULL;
    uint32_t do_unlink = 0;

    CCIPC_TRACE_FUNCTION();

    if (!handle) {
        CCIPC_ERROR_PRINT("Invalid IPC handle\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    shmAlignHandle = (CCIPCshmAlignHandle*)handle->implementationData;

    /* Only unlink the shmAlign from the handle where src < dst  */
    if (handle->src < handle->dst)
        do_unlink = 1;

    if (shmAlignHandle->info) {
        cuosShmCloseEx(shmAlignHandle->info, CUOS_VIRTUAL_FREE_RELEASE, do_unlink);
        shmAlignHandle->info = NULL;
    }

    free(handle->implementationData);
    handle->implementationData = NULL;

    return CCIPC_SUCCESS;
}

/* CCIPCshmAlignHandleForceCleanup
*/
static CCIPCresult
CCIPCshmAlignHandleForceCleanup(const char *sendIpcName, const char *recvIpcName)
{
    cuosShmInfoEx *info;
    size_t shmAlignSize = 0;
    int cuosret = 0;

    shmAlignSize = sizeof(CCIPCshmAlignChannelPair);

    cuosret = cuosShmOpenNamedEx(NULL, sendIpcName, shmAlignSize, &info);
    /* If shmAlign_open fails, the segment does not exist. */
    if (cuosret != CUOS_SUCCESS)
        return CCIPC_SUCCESS;

    /* Close the shmAlign handle */
    cuosShmCloseEx(info, CUOS_VIRTUAL_FREE_RELEASE, 1);

    return CCIPC_SUCCESS;
}


/* CCIPCshmAlignChannelCreate
    This handles the shmAlignem channel swizzle
*/
static CCIPCresult
CCIPCshmAlignChannelCreate(CCIPCchannel *channel, const char *ipcName)
{
    CCIPCshmAlignHandle *shmAlignHandle = NULL;
    CCIPCshmAlignChannelPair *shmAlignPair = NULL;

    /* Setup the endpoints. Swizzle as appropriate. The goal here is the following
       The shmAlignem region that has been setup is a pair of channels. So

                ------------------------------
             -> |   shmAlignChannel[SEND]    | ->
        C1      ------------------------------   C2
             <- |   shmAlignChannel[RECV]    | <-
                ------------------------------

        From the perspective of C1, the src and dst are :
            SEND (C1, C2) => shmAlignChannel[SEND]
            RECV (C2, C1) => shmAlignChannel[RECV]
        and similarly for C2, the src and dst are :
            SEND (C2, C1) => shmAlignChannel[RECV]
            RECV (C1, C2) => shmAlignChannel[SEND]

        Thus, we want to ensure that when creating the handles to the channel
        in C1 we treat shmAlignChannel[SEND] as the sender, but when doing the same
        for C2, we treat shmAlignChannel[RECV] as the sender.

        To make this logic work for any pair of unique endpoints, we instead use
        the following logic:

        for Client (where C1 < C2)
            Client[SEND] = shmAlignChannel[SEND];
            Client[RECV] = shmAlignChannel[RECV];
        and Client (where C2 > C1)
            Client[SEND] = shmAlignChannel[RECV];
            Client[RECV] = shmAlignChannel[SEND];
    */

    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!channel->handle) {
        CCIPC_ERROR_PRINT("Invalid handle\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    shmAlignHandle = (CCIPCshmAlignHandle*)channel->handle->implementationData;
    if (!shmAlignHandle) {
        CCIPC_ERROR_PRINT("Could not find SHM handle\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    shmAlignPair = (CCIPCshmAlignChannelPair*)shmAlignHandle->info->addr;
    if (!shmAlignPair) {
        CCIPC_ERROR_PRINT("Shm handles not open\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    if (channel->handle->src < channel->handle->dst) {
        /* Do a normal assignment */
        channel->implementation = &shmAlignPair->channels[channel->type];
    }
    else if (channel->handle->src > channel->handle->dst) {
        /* Flip the two channels  */
        channel->implementation =
            &shmAlignPair->channels[CCIPC_CHANNEL_TYPE_SIZE - channel->type - 1];
    }
    else {
        CCIPC_ERROR_PRINT("Encountered identical endpoints : %u\n", channel->handle->src);
        return CCIPC_ERROR_INVALID_ENDPOINT;
    }

    return CCIPC_SUCCESS;
}

static CCIPCresult
CCIPCshmAlignChannelDestroy(CCIPCchannel *channel)
{
    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    channel->implementation = NULL;
    return CCIPC_SUCCESS;
}

/* CCIPCshmAlignChannelInitialize
    This is called by the IAL to initialize a channel for shmAlign channels.
*/
static CCIPCresult
CCIPCshmAlignChannelInitialize(void *implementation, const char *name)
{
    CCIPCshmAlignChannel *shmAlignChannel = NULL;

    CCIPC_TRACE_FUNCTION();

    if (!implementation) {
        CCIPC_ERROR_PRINT("Invalid channel handle\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    shmAlignChannel = (CCIPCshmAlignChannel*)implementation;

    memset(shmAlignChannel, 0, sizeof(*shmAlignChannel));
    return CCIPC_SUCCESS;
}

/* CCIPCshmAlignChannelFinalize
    This is called by the IAL to finalize a channel.
*/
static CCIPCresult
CCIPCshmAlignChannelFinalize(void *implementation)
{
    CCIPCshmAlignChannel *shmAlignChannel = NULL;

    CCIPC_TRACE_FUNCTION();

    if (!implementation) {
        CCIPC_ERROR_PRINT("Invalid channel handle\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    shmAlignChannel = (CCIPCshmAlignChannel*)implementation;

    memset(&shmAlignChannel->header, 0, sizeof (shmAlignChannel->header));
    return CCIPC_SUCCESS;
}

/* CCIPCshmAlignChannelRead
    Actual read implmentation. See the description at the start of this file
    for an explanation of the full protocol.

    Reader Side:
    1 Compute size to read as :
        sz = (writeInner >= readOuter) ? writeInner - readOuter : BUF_SZ - readOuter + writeInner;
    2 Atomically increment readOuter
    3 Start reading at old value of readOuter
    4 Wait until readInner is at old value of readOuter
    5 Atomically increment readInner by size of read
*/
static CCIPCresult
CCIPCshmAlignChannelRead(void *implementation, void *buf, size_t bufSize, size_t *readSize, uint32_t timeoutMs)
{
    uint32_t readOuter, targetSize = 0, writeInner, readInner, oldReadOuter;
    volatile CCIPCshmAlignChannel *channel = NULL;
    uint32_t channelBufferSize = 0;
    cuosTimer timer;

    CCIPC_TRACE_FUNCTION();

    /* Some initial checks */
    if (!implementation) {
        CCIPC_ERROR_PRINT("Invalid channel handle\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!buf || !readSize) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    channel = (volatile CCIPCshmAlignChannel*)implementation;
    channelBufferSize = (uint32_t)sizeof(channel->buffer);

    /* Snap a value of writeInner. It does not matter if
       writeInner advances after this point, as long
       as writeInner does not cross readOuter */
    writeInner = channel->header.writeInner;

    /* Compute a stable size to read */
    cuosResetTimer(&timer);
    do {
        /* Always refetch readOuter, since the loop requires it */
        readOuter = channel->header.readOuter;

        /* Compute the maximal read, accounting for wraparound */
        targetSize = (writeInner >= readOuter) ? writeInner - readOuter :
                     (channelBufferSize - readOuter + writeInner);

        if (targetSize > bufSize) {
            CCIPC_DEBUG_PRINT("Receive message too large (%u bytes). Only reading %u bytes", targetSize, bufSize);
            targetSize = (uint32_t)bufSize;
        }

        oldReadOuter = cuosInterlockedCompareExchange(&channel->header.readOuter,
                                                      (readOuter + targetSize) % channelBufferSize,
                                                      readOuter);
        if (cuosGetTimer(&timer) > timeoutMs && oldReadOuter != readOuter) {
            CCIPC_ERROR_PRINT("Timeout  in reader. Waited for %u ms for readOuter\n",
                              timeoutMs);
            return CCIPC_ERROR_TIMEOUT;
        }
    } while (oldReadOuter != readOuter);


    /* A message of targetSize can be read from oldReadOuter.
       There are two cases to be dealt with :
       Case 1 : no wraparound - It is sufficient to simply memcpy targetSize bytes
       Case 2 : wraparound - if there is wraparound, make two reads
     */
    if (oldReadOuter + targetSize < channelBufferSize)
        memcpy(buf, (char*)(channel->buffer + oldReadOuter), targetSize);
    else {
        uint32_t tailSize = channelBufferSize - oldReadOuter;
        memcpy(buf, (char*)(channel->buffer + oldReadOuter), tailSize);
        memcpy((char*)buf + tailSize, (char*)channel->buffer, targetSize - tailSize);
    }

    /* Wait until readInner catches up and update it. This is required
       as it will prevent the writer from clobbering it unless readInner
       is updated */
    readInner = channel->header.readInner;
    cuosResetTimer(&timer);
    do {
        readInner = cuosInterlockedCompareExchange(&channel->header.readInner,
                                                   (oldReadOuter + targetSize) % channelBufferSize,
                                                   readInner);
        if (cuosGetTimer(&timer) > timeoutMs && oldReadOuter != readInner) {
            CCIPC_ERROR_PRINT("Timeout  in reader. Waited for %u ms for readInner to update\n",
                              timeoutMs);
            return CCIPC_ERROR_TIMEOUT;
        }
    } while (oldReadOuter != readInner);

    *readSize = targetSize;
    return CCIPC_SUCCESS;
}

/* CCIPCshmAlignChannelWrite
    Actual write implmentation. See the description at the start of this file
    for an explanation of the full protocol.

    Writer side:
    1 Space in the buffer is calculated as:
        sz = (writeOuter >= readInner) ? BUF_SZ - (writeOuter - readInner) : (readInner - writeOuter);

    2 If space >= size of the message, atomically increment writeOuter
    3 Start writing at old value of writeOuter.
    4 Wait until writeInner is at old writeOuter.
    5 Atomically increment writeInner by size of message.
 */
static CCIPCresult
CCIPCshmAlignChannelWrite(void *implementation, void *buf, size_t bufSize, size_t *writeSize, uint32_t timeoutMs)
{
    uint32_t readInner, targetSize = 0, writeOuter, writeInner;
    uint32_t oldWriteOuter;
    uint32_t numBytes = 0;
    volatile CCIPCshmAlignChannel *channel = NULL;
    uint32_t channelBufferSize = 0;
    cuosTimer timer;

    CCIPC_TRACE_FUNCTION();

    /* Some initial checks */
    if (!implementation) {
        CCIPC_ERROR_PRINT("Invalid channel handle\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!buf || !writeSize) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    if (!bufSize) {
        CCIPC_ERROR_PRINT("0 size write\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    channel = (volatile CCIPCshmAlignChannel*)implementation;
    channelBufferSize = (uint32_t)sizeof(channel->buffer);

    numBytes = (uint32_t)bufSize;
    if (bufSize >= channelBufferSize) {
        CCIPC_DEBUG_PRINT("Send message too large (%u bytes). Only sending %u bytes", bufSize, channelBufferSize);
        numBytes = channelBufferSize;
    }

    /* Compute amount of space available */
    oldWriteOuter = 0;
    cuosResetTimer(&timer);
    do {
        /* Always refetch readInner and writeOuter, since the loop requires it */
        readInner = channel->header.readInner;
        writeOuter = channel->header.writeOuter;
        oldWriteOuter = (writeOuter + 1) % channelBufferSize;

        /* Compute the available size, accounting for wraparound */
        targetSize = (writeOuter >= readInner) ? channelBufferSize - writeOuter + readInner :
                                                 readInner - writeOuter;
        if (targetSize >= numBytes) {
            oldWriteOuter = cuosInterlockedCompareExchange(&channel->header.writeOuter,
                                                          (writeOuter + numBytes) % channelBufferSize,
                                                          writeOuter);
        }
        if (cuosGetTimer(&timer) > timeoutMs && oldWriteOuter != writeOuter) {
            CCIPC_ERROR_PRINT("Timeout  in writer. Waited for %u ms for writeOuter\n",
                              timeoutMs);
            return CCIPC_ERROR_TIMEOUT;
        }
    } while (oldWriteOuter != writeOuter);

    /* A message of numBytes can be written at oldWriteOuter.
       There are two cases to be dealt with:
       Case 1 : No wraparound : Can simply do a single memcpy
       Case 2 : Wraparound : Split the memcpys
    */
    if (oldWriteOuter + numBytes <= channelBufferSize)
        memcpy((char*)channel->buffer + oldWriteOuter, buf, numBytes);
    else {
        uint32_t tailSize = channelBufferSize - oldWriteOuter;
        memcpy((char*)(channel->buffer + oldWriteOuter), buf, tailSize);
        memcpy((char*)channel->buffer, (char*)buf + tailSize, numBytes - tailSize);
    }

    /* Wait until writeInner catches up and update it. This is required
       as it will prevent the reader from trying to read partial records */
    writeInner = channel->header.writeInner;
    cuosResetTimer(&timer);
    do {
        writeInner = cuosInterlockedCompareExchange(&channel->header.writeInner,
                                                    (oldWriteOuter + numBytes) % channelBufferSize,
                                                    writeInner);
        if (cuosGetTimer(&timer) > timeoutMs && oldWriteOuter != writeInner) {
            CCIPC_ERROR_PRINT("Timeout  in writer. Waited for %u ms for writeInner to update\n",
                              timeoutMs);
            return CCIPC_ERROR_TIMEOUT;
        }
    } while (oldWriteOuter != writeInner);

    *writeSize = numBytes;

    return CCIPC_SUCCESS;
}

static CCIPCresult
CCIPCshmAlignChannelForceCleanup(const char *ipcName)
{
    return CCIPC_SUCCESS;
}

CCIPCresult
CCIPCshmAlignGetIAL(CCIPCIAL *ial)
{
    if (!ial) {
        CCIPC_ERROR_PRINT("Invalid IAL pointer\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    ial->handleCreate           = CCIPCshmAlignHandleCreate;
    ial->handleDestroy          = CCIPCshmAlignHandleDestroy;
    ial->handleForceCleanup     = CCIPCshmAlignHandleForceCleanup;
    ial->channelCreate          = CCIPCshmAlignChannelCreate;
    ial->channelDestroy         = CCIPCshmAlignChannelDestroy;
    ial->channelInitialize      = CCIPCshmAlignChannelInitialize;
    ial->channelFinalize        = CCIPCshmAlignChannelFinalize;
    ial->channelRead            = CCIPCshmAlignChannelRead;
    ial->channelWrite           = CCIPCshmAlignChannelWrite;
    ial->channelForceCleanup    = CCIPCshmAlignChannelForceCleanup;

    ial->channelEventCreate     = CCIPCcommonChannelEventCreate;
    ial->channelEventSignal     = CCIPCcommonChannelEventSignal;
    ial->channelEventDestroy    = CCIPCcommonChannelEventDestroy;
    ial->channelEventIpcCreate  = CCIPCcommonChannelEventIpcCreate;
    ial->channelEventIpcDestroy = CCIPCcommonChannelEventIpcDestroy;
    ial->channelEventForceCleanup = CCIPCcommonChannelEventForceCleanup;
    ial->channelEventGetCuosEvent = CCIPCcommonChannelEventGetCuosEvent;

    CCIPC_DEBUG_PRINT("Shmem-Align IAL created\n");

    return CCIPC_SUCCESS;
}
