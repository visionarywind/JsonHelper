/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: check_format_writer.c
 *
 *   Description:
 *      Can write all the formats known by memcheck
 *
 ******************************************************************************/
#include "cudamemcheck.h"
#include "cuda_stdint.h"
#include "check_format.h"
#include "check_format_internal.h"
#include "check_format_legacy.h"
#include "check_ipc_utils.h"
#include <stddef.h>

/* The magic number and version for the current error records */
#define CUDA_MEMCHECK_MAGIC      0xE38F83E152BB11C7ULL

/* For unique record ids */
static uint32_t recordid = 1;

/* Version tracking. Every structure has a version */
#define CCDR_VERSION_INVALID 0
#define CCDR_MINCLIENT_DEFAULT CUDA_MEMCHECK_TK_VERSION_NEWFORMAT
#define CCDR_SH_VERSION 1
#define CCDR_SHEXTERR_VERSION_DEFAULT   1

#define CCDR_SHEXTIPC_VERSION_DEFAULT   1
#define CCDR_SHEXTIPC_VERSION_IPC_REPLY 2

#define CCDR_MINCLIENT_RACE_ANALYSIS 22
#define CCDR_MINCLIENT_MEM_ACCESS    29
#define CCDR_MINCLIENT_BAR_VIOLATION 38
#define CCDR_MINCLIENT_MEM_INIT      39
#define CCDR_MINCLIENT_UVM_FATAL_FAULT 41
#define CCDR_MINCLIENT_MEM_UNUSED      41
#define CCDR_MINCLIENT_DRV_WARNING     46
#define CCDR_MINCLIENT_IPC           CUDA_MEMCHECK_TK_VERSION_IPC
#define CCDR_MINCLIENT_IPC_REPLY     CUDA_MEMCHECK_TK_VERSION_IPC_REPLY
#define CCDR_MINCLIENT_ADD_FILTER    CUDA_MEMCHECK_TK_VERSION_ADD_FILTER

/* Versioning information for backtrace section */
#define CCDR_SHBACKTRACE_MINCLIENT CUDA_MEMCHECK_TK_VERSION_BACKTRACE

const static uint32_t
CCDR_shExtErrrecVersions[CU_MEMCHECK_RECORD_SIZE] = {
    CCDR_VERSION_INVALID,
    CCDR_SHEXTERR_VERSION_DEFAULT,     // MEM_PRECISE version,
    CCDR_SHEXTERR_VERSION_DEFAULT,     // MEM_IMPRECISE version,
    CCDR_SHEXTERR_VERSION_DEFAULT,     // MEM_HINT version,
    CCDR_SHEXTERR_VERSION_DEFAULT,     // MEM_LEAK version,
    CCDR_SHEXTERR_VERSION_DEFAULT,     // DRV_ERROR version,
    CCDR_SHEXTERR_VERSION_DEFAULT,     // SHMEM_HAZARD version,
    CCDR_SHEXTERR_VERSION_DEFAULT,     // API_ERROR version,
    CCDR_SHEXTERR_VERSION_DEFAULT,     // MEM_SYSCALL version,
    CCDR_SHEXTERR_VERSION_DEFAULT,     // RACE_ANALYSIS version,
    CCDR_SHEXTERR_VERSION_DEFAULT,     // MEM_ACCESS version
    CCDR_SHEXTERR_VERSION_DEFAULT,     // BAR_VIOLATION version
    CCDR_SHEXTERR_VERSION_DEFAULT,     // MEM_INIT version
    CCDR_SHEXTERR_VERSION_DEFAULT,     // UVM_FATAL_FAULT version
    CCDR_SHEXTERR_VERSION_DEFAULT,     // MEM_UNUSED version
    CCDR_SHEXTERR_VERSION_DEFAULT,     // DRV_WARNING version
};

const static uint32_t
CCDR_shExtErrrecMinClients[CU_MEMCHECK_RECORD_SIZE] = {
    CCDR_MINCLIENT_DEFAULT,
    CCDR_MINCLIENT_DEFAULT, // MEM_PRECISE_MINCLIENT,
    CCDR_MINCLIENT_DEFAULT, // MEM_IMPRECISE_MINCLIENT,
    CCDR_MINCLIENT_DEFAULT, // MEM_HINT_MINCLIENT,
    CCDR_MINCLIENT_DEFAULT, // MEM_LEAK_MINCLIENT,
    CCDR_MINCLIENT_DEFAULT, // DRV_ERROR_MINCLIENT,
    CCDR_MINCLIENT_DEFAULT, // SHMEM_HAZARD_MINCLIENT,
    CCDR_MINCLIENT_DEFAULT, // API_ERROR_MINCLIENT,
    CCDR_MINCLIENT_DEFAULT, // MEM_SYSCALL_MINCLIENT,
    CCDR_MINCLIENT_RACE_ANALYSIS, // RACE_ANALYSIS_MINCLIENT
    CCDR_MINCLIENT_MEM_ACCESS, // MEM_ACCESS_MINCLIENT
    CCDR_MINCLIENT_BAR_VIOLATION, // BAR_VIOLATION_MINCLIENT
    CCDR_MINCLIENT_MEM_INIT, // MEM_INIT_MINCLIENT
    CCDR_MINCLIENT_UVM_FATAL_FAULT, // UVM_FATAL_FAULT_MINCLIENT
    CCDR_MINCLIENT_MEM_UNUSED,      // MEM_UNUSED_MINCLIENT
    CCDR_MINCLIENT_DRV_WARNING,     // DRV_WARNING_MINCLIENT
};

const static uint32_t
CCDR_shExtIPCrecVersions[CU_MEMCHECK_IPC_MSG_SIZE] = {
    CCDR_VERSION_INVALID,
    CCDR_SHEXTIPC_VERSION_DEFAULT,     // INIT version,
    CCDR_SHEXTIPC_VERSION_DEFAULT,     // INIT_ACK version,
    CCDR_SHEXTIPC_VERSION_DEFAULT,     // INIT_NAK version,
    CCDR_SHEXTIPC_VERSION_DEFAULT,     // SET_OPTIONS version,
    CCDR_SHEXTIPC_VERSION_DEFAULT,     // RUN_ASYNC version,
    CCDR_SHEXTIPC_VERSION_IPC_REPLY,   // GET_PID version
    CCDR_SHEXTIPC_VERSION_IPC_REPLY,   // REPLY_DATA version
    CCDR_SHEXTIPC_VERSION_DEFAULT,     // ADD_FILTER version
};

const static uint32_t
CCDR_shExtIPCrecMinClients[CU_MEMCHECK_IPC_MSG_SIZE] = {
    CCDR_MINCLIENT_IPC,
    CCDR_MINCLIENT_IPC,       // INIT minclient
    CCDR_MINCLIENT_IPC,       // INIT_ACK minclient
    CCDR_MINCLIENT_IPC,       // INIT_NAK minclient
    CCDR_MINCLIENT_IPC,       // SET_OPTIONS minclient
    CCDR_MINCLIENT_IPC,       // RUN_ASYNC minclient
    CCDR_MINCLIENT_IPC_REPLY, // GET_PID minclient
    CCDR_MINCLIENT_IPC_REPLY, // REPLY_DATA minclient
    CCDR_MINCLIENT_ADD_FILTER, // ADD_FILTER minclient
};

/* Header types for new format */
typedef enum {
    CCDR_HT_NONE = 0,
    CCDR_HT_DRV_OUT = 1,
    CCDR_HT_IPC_DRV_OUT = 2,
    CCDR_HT_IPC_DRV_IN  = 3,

    /* Add new entries before this */
    CCDR_HT_SIZE,
} CCDR_header_types;

typedef enum {
    CCDR_SHT_NONE   = 0,
    CCDR_SHT_STRTAB = 1,
    CCDR_SHT_ERRREC = 2,
    CCDR_SHT_BACKTRACE = 3,
    CCDR_SHT_IPCREC = 4,

    /* Add new entries before this */
} CCDR_section_header_types;

/* Typedefs for backtrace section records */
typedef struct CCDR_section_backtrace_hostFrame_st      CCDR_section_backtrace_hostFrame;
typedef struct CCDR_section_backtrace_devFrame_st       CCDR_section_backtrace_devFrame;
typedef struct CCDR_section_backtrace_host_st           CCDR_section_backtrace_host;
typedef struct CCDR_section_backtrace_dev_st            CCDR_section_backtrace_dev;
typedef struct CCDR_section_backtrace_start_st          CCDR_section_backtrace_start;

/* Typedefs for all the error types */
typedef struct CCDR_header_st                           CCDR_header;
typedef struct CCDR_header_ext_st                       CCDR_header_ext;
typedef struct CCDR_section_header_st                   CCDR_section_header;
typedef struct CCDR_section_header_ext_errrec_st        CCDR_section_header_ext_errrec;
typedef struct CCDR_section_header_ext_ipcrec_st        CCDR_section_header_ext_ipcrec;
typedef struct CCDR_section_header_ext_shmemHazard_st   CCDR_section_header_ext_shmemHazard;
typedef struct CCDR_section_header_ext_raceAnalysis_st  CCDR_section_header_ext_raceAnalysis;
typedef struct CCDR_section_header_ext_backtrace_st     CCDR_section_header_ext_backtrace;

/* Typedefs for the struct versions of each type */
typedef struct CCDR_record_type_memPrecise_st           CCDR_record_type_memPrecise;
typedef struct CCDR_record_type_memImprecise_st         CCDR_record_type_memImprecise;
typedef struct CCDR_record_type_memLeak_st              CCDR_record_type_memLeak;
typedef struct CCDR_record_type_memSyscall_st           CCDR_record_type_memSyscall;
typedef struct CCDR_record_type_driverError_st          CCDR_record_type_driverError;
typedef struct CCDR_record_type_shmemHazard_st          CCDR_record_type_shmemHazard;
typedef struct CCDR_record_type_hazardThreadInfo_st     CCDR_record_type_hazardThreadInfo;
typedef struct CCDR_record_type_hazardCommonInfo_st     CCDR_record_type_hazardCommonInfo;
typedef struct CCDR_record_type_apiError_st             CCDR_record_type_apiError;
typedef struct CCDR_record_type_raceAnalysisCommon_st   CCDR_record_type_raceAnalysisCommon;
typedef struct CCDR_record_type_raceAnalysisVertex_st   CCDR_record_type_raceAnalysisVertex;
typedef struct CCDR_record_type_memAccess_st            CCDR_record_type_memAccess;
typedef struct CCDR_record_type_memUnused_st            CCDR_record_type_memUnused;
typedef struct CCDR_record_type_barViolation_st         CCDR_record_type_barViolation;
typedef struct CCDR_record_type_memInit_st              CCDR_record_type_memInit;
typedef struct CCDR_record_type_uvmFatalFault_st        CCDR_record_type_uvmFatalFault;

typedef struct CCDR_ipcmsg_type_init_st                 CCDR_ipcmsg_type_init;
typedef struct CCDR_ipcmsg_type_setOption_st            CCDR_ipcmsg_type_setOption;
typedef struct CCDR_ipcmsg_type_replyDataHeader_st      CCDR_ipcmsg_type_replyDataHeader;
typedef struct CCDR_ipcmsg_type_replyDataPid_st         CCDR_ipcmsg_type_replyDataPid;
typedef struct CCDR_ipcmsg_type_addFilter_st            CCDR_ipcmsg_type_addFilter;
typedef struct CCDR_ipcmsg_type_uvmInfo_st              CCDR_ipcmsg_type_uvmInfo;

/*****************************************************************
 *                      Packed region start                      *
 *****************************************************************/
/* The entire region below is packed using pragma push/pop.
   Windows 32- and 64-bit, GCC and LLVM all support using pragma push/pop.
*/
#pragma pack(push,1)
/*  Payload definitions. These are payload records that are present
    in an error struct. When placed on disk, each logical record
    is packed as a payload_header followed by the actual record.
*/
/* On disk error record

    The output file consists of series of memcheck error records.
    To handle the cases where the application may terminate suddenly
    each error record is completely self contained. Additionally,
    to maintain forwards and backwards compatibility the error record
    itself and sections of the error record are preceeded by fixed headers.
    These headers encode information about the size of the record and version
    information so that clients can skip ahead as needed.

    A memcheck error record now consists of a unique header, followed
    by a list of sections. A client should be able to (using the fixed
    section header information) skip unknown sections. Within a section,
    a client should be able to read only the data it knows about. Failing
    all else, the client can skip entire records.

    Versioning
    ----------
    To handle this level of granularity, each record (and section) contains two
    separate pieces of version information.
        1. Record version (version field) : version of the record/struct
        2. Minimum client (minclient field) : minimum version of a compatible client
    The check when reading is based on two factors - the toolkit's client version
    (TK_version) and the toolkit's per struct version (TK_struct_version)

    For any read there are 3 cases possible :

    Case 1 :
        TK_version >= minclient && TK_struct_version == version
    This implies the toolkit is new and the struct has not changed.
    In this case, the toolkit can read the entire struct.

    Case 2 :
        TK_version >= minClient && TK_struct_version < version
    This implies that the toolkit is not as new as the driver. Even
    though the record is supported, it has undergone some change.
    As a result, information being read is partial. For the sake
    of sanity, before reading, the client should also ensure that
    the toolkit struct size is smaller than the payload that
    is present. In this case, the toolkit can read partial information.
    This should also cause a warning to appear.

    Case 3 :
        TK_version < minClient
    This implies that the record has changed in a fundamental way. As
    a result, the client cannot attempt to read it. Instead, it should
    skip the record and proceed forward.

    Record Layout
    -------------

    1. A fixed size CCDR_header record that contains the size of the complete
       record, as well as the format version and a magic number. In case of
       mismatch, the reader can skip the entire record. The header also
       contains information about the number of sections that follow, the
       offset of the starting section from the start of the header, and
       the offset of the header information.
    2. The header is followed by a CCDR_header_ext structure that contains
       additional data that applies to the entire record, such as the recordid
       the parent record's id, the number of children and the level of the
       record.
    3. The header information is followed by a CCDR_section_header. This
       structure contains the type of the section, as well as version
       information to allow an older client to skip past an unknown
       section. The section header also points at a section specific
       header that follows it. This section will contain fields at
       fixed locations so that subsequent clients can read it back
       correctly.
    4. The section specific header CCDR_section_header_ext_* varies
       based on the section type. In general, it will contain information
       about the payload that will immediately follow it. Currently
       the CCDR_section_header_ext section is only present for
       CCDR_SHT_ERRREC sections.

        ---------------------------------  0
        | CCDR_header                   |
        |                               |
        --------------------------------- header->dataoffset
        | CCDR_header_ext               |
        --------------------------------- header->shoffset
        | CCDR_section_header (sh0)     |
        --------------------------------- sh0 + sh0->dataoffset
        | String Table                  |
        |                               |
        |                               |
        --------------------------------- sh0 + sh0->size
        | CCDR_section_header (sh1)     |
        --------------------------------- sh1 + sh1->extoffset
        | CCDR_section_header_ext_error |
        --------------------------------- sh1 + sh1->dataoffset
        | CCDR_record_type_*            |
        |                               |
        --------------------------------- header->size
*/

struct CCDR_header_st {
    /**** Fixed header start *****/
    uint64_t    size;           /* Size of entire record */
    uint64_t    magic;          /* Magic number */
    uint32_t    version;        /* Version of record */
    uint32_t    minclient;      /* Minimum client that can read this */
    uint32_t    headertype;     /* From CCDR_header_types */
    uint32_t    shoffset;       /* Bytes from record start to first section */
    uint32_t    extoffset;      /* Bytes from record start to header_ext */
    /***** Fixed header end ******/
};

struct CCDR_header_ext_st {
    uint32_t    recordid;       /* ID of record */
    uint32_t    parentid;       /* ID of parent */
    uint32_t    numchildren;    /* Number of child records */
    uint32_t    level;          /* Print level */
    /* New fields should be added to the end  */
};

struct CCDR_section_header_st {
    /*** Fixed section header start ***/
    uint64_t    size;           /* Size of entire section */
    uint32_t    version;        /* Version of section header */
    uint32_t    minclient;      /* Minimum compatible client */
    uint32_t    type;           /* From CCDR_section_header_types */
    uint32_t    dataoffset;     /* Byte offset to actual section data */
    uint32_t    extoffset;      /* Byte offset to section_header_ext_* extension */
    /*** Fixed section header end ***/
};

struct CCDR_section_header_ext_errrec_st {
    /*** Fixed error record section header start ***/
    uint64_t    recordsize;     /* Size of the record data that follows */
    uint32_t    version;        /* Version of target record */
    uint32_t    minclient;      /* Minimum compatible client */
    uint32_t    errortype;      /* Type of target record */
    /*** Fixed error record section header end ***/
};

struct CCDR_section_header_ext_ipcrec_st {
    /*** Fixed error record section header start ***/
    uint64_t    recordsize;     /* Size of the record data that follows */
    uint32_t    version;        /* Version of target record */
    uint32_t    minclient;      /* Minimum compatible client */
    uint32_t    ipctype;        /* Type of target record */
    /*** Fixed error record section header end ***/
};

struct CCDR_section_header_ext_shmemHazard_st {
    /*** Fixed error record section header start ***/
    uint32_t commonsize;
    uint32_t threadinfosize;
    /*** Fixed error record section header end ***/
};

struct CCDR_section_header_ext_raceAnalysis_st {
    /*** Fixed error record section header start ***/
    uint32_t headerextsize;
    uint32_t commonsize;
    uint32_t vertexsize;
    /*** Fixed error record section header end ***/
};

struct CCDR_section_header_ext_backtrace_st {
    /*** Fixed error record section header start ***/
    uint64_t    btsize;         /* Size of the backtrace data that follows */
    uint32_t    dataoffset;     /* Offset to first start record */
    uint32_t    startsize;      /* Size of CCDR_section_backtrace_start */
    uint32_t    hostsize;       /* Size of CCDR_section_backtrace_host */
    uint32_t    devsize;        /* Size of CCDR_section_backtrace_dev */
    uint32_t    hostframesize;  /* Size of CCDR_section_backtrace_hostFrame */
    uint32_t    devframesize;   /* Size of CCDR_section_backtrace_devFrame */
    /*** Fixed error record section header end ***/
};

struct CCDR_section_backtrace_hostFrame_st {
    uint32_t flags;         /* Of frameFlags type */
    uint32_t depth;         /* Depth of this frame */
    uint64_t addr;          /* Return address of the frame */
    uint32_t funcNameIx;    /* Index for function name string */
    uint64_t funcOffset;    /* Offset of function */
    uint32_t libNameIx;     /* Index of library name string  */
    uint64_t libBaseAddr;   /* Base address of library */
    uint32_t fileNameIx;    /* File name (debug_info) */
    uint32_t lineno;        /* Line number (debug_info) */
};

struct CCDR_section_backtrace_devFrame_st {
    uint32_t flags;         /* Of frameFlags type */
    uint32_t depth;         /* Depth of this frame */
    uint64_t addr;          /* Return address of this frame */
    uint32_t funcNameIx;    /* Index of function name string */
    uint64_t funcOffset;    /* Offset of function */
    uint32_t kernelNameIx;  /* Index of kernel name string */
    uint64_t kernelAddr;    /* Base address of kernel */
    uint32_t moduleNameIx;  /* Index of module name string */
    uint32_t fileNameIx;    /* Index of file name string (debug info) */
    uint32_t lineno;        /* Line number in file (debug info) */
};

struct CCDR_section_backtrace_host_st {
    uint64_t threadId;      /* Host thread index */
};

struct CCDR_section_backtrace_dev_st {
    uint32_t threadIdxX;
    uint32_t threadIdxY;
    uint32_t threadIdxZ;
    uint32_t blockIdxX;
    uint32_t blockIdxY;
    uint32_t blockIdxZ;
    uint32_t entryKernelNameIx;
};

struct CCDR_section_backtrace_start_st {
    uint64_t size;          /* Total size of backtrace */
    uint32_t type;          /* Of type CUmemcheck_backtrace_types */
    uint32_t maxDepth;      /* Informational */
    uint32_t totalDepth;    /* Number of frames that follow */
    uint32_t dataOffset;    /* Offset to data */
    uint32_t frameOffset;   /* Offset to start of frames */
};

/*  Error type struct definitions
    Each struct corresponds to a particular error type.
    These must always be packed as the driver uses memcpy to fill
    them in from the memory version of the error record
 */
struct CCDR_record_type_memPrecise_st {
    uint64_t address;
    uint32_t pc;             /* ~0 signifies unknown */
    uint32_t size;           /* Transfer size in bytes, 0 if unknown */
    uint32_t write;
    uint32_t blockIdxX, blockIdxY, blockIdxZ;
    uint32_t threadIdxX, threadIdxY, threadIdxZ;
    uint32_t lineno;        /* 0 if unknown */
    uint32_t type;
    CUDBGException_t exception;
    uint32_t funcNameIx;
    uint32_t fileNameIx;
};

struct CCDR_record_type_memImprecise_st {
    uint64_t address;
    uint32_t pc;             /* ~0 signifies unknown */
    uint32_t blockIdxX, blockIdxY, blockIdxZ;
    uint32_t threadIdxX, threadIdxY, threadIdxZ;
    uint32_t lineno;
    CUDBGException_t exception;
    uint32_t funcNameIx;
    uint32_t fileNameIx;
};

struct CCDR_record_type_memLeak_st {
    uint64_t size;          /* Size of leak */
    uint64_t address;       /* Device address of leak */
    uint32_t flags;         /* flags for allocation. Internal Use*/
    uint32_t nameIx;        /* Name for a named allocation */
};

struct CCDR_record_type_driverError_st {
    uint32_t error;         /* The type of the error */
    uint32_t internal;      /* Boolean flag, 1 means internal */
    uint32_t stringIx;      /* Index of error string */
};

struct CCDR_record_type_hazardThreadInfo_st {
    uint32_t write;            /* Set to true for write */
    uint32_t threadIdxX, threadIdxY, threadIdxZ; /* ThreadId */
    uint32_t pc;               /* PC of the original access */
    uint32_t line;             /* Line number of the source file */
    uint32_t fileNameIx;       /* File name for source file */
    uint32_t funcNameIx;       /* Function name for PC */
};

struct CCDR_record_type_hazardCommonInfo_st {
    uint64_t gridid;        /* Grid id, used by frontend to do clustering */
    uint32_t hazardType;    /* Type of hazard (CUracecheck_hazard_types) */
    uint32_t address;       /* Address in shared memory  */
    uint32_t blockIdxX, blockIdxY,blockIdxZ;
    uint32_t readData;      /* This is the value at the shared memory address */
    uint32_t writeData;     /* The value that was in flight at the last write */
    uint32_t filterType;    /* The actual filter condition used */
    uint32_t kernelNameIx;  /* Function name for kernel  */
};

struct CCDR_record_type_shmemHazard_st {
    CCDR_record_type_hazardCommonInfo common;
    CCDR_record_type_hazardThreadInfo thread0;
    CCDR_record_type_hazardThreadInfo thread1;
};

struct CCDR_record_type_apiError_st {
    uint32_t apiType;
    uint32_t apiResult;
    uint64_t contextID;
    uint64_t apiCallID;
    uint32_t stringIx;
    uint32_t errorNameStringIx;
    uint32_t errorMsgStringIx;
};

struct CCDR_record_type_memSyscall_st {
    uint32_t type;  /* Type of syscall error (CUmemcheck_syscallError_types) */
    uint32_t blockIdxX, blockIdxY, blockIdxZ;
    uint32_t threadIdxX, threadIdxY, threadIdxZ;
    uint32_t pc;        /* Currently will be the PC inside the syscall */
    uint32_t lineno;    /* Line in the code corresponding to the PC */
    uint64_t address;   /* Pointer value */
    uint64_t size;      /* Length of allocation */
    uint32_t fileNameIx;
    uint32_t funcNameIx;
};

struct CCDR_record_type_raceAnalysisVertex_st {
    uint32_t pc;            /* Offset in the function */
    uint32_t write;         /* This location is a write */
    uint32_t funcNameIx;    /* Name of function */
    uint32_t fileNameIx;    /* File name if available */
    uint32_t line;          /* Line number if available */
    uint32_t hazardTypeMask;    /* Only valid for a dest : type of hazard */
    uint32_t weight;            /* Only valid for a dest : Weight of the hazard */
    uint32_t count;             /* Only valid for a dest : number of hazards */
};

struct CCDR_record_type_raceAnalysisCommon_st {
    uint32_t numDests;
};

struct CCDR_record_type_memAccess_st {
    uint32_t accessType;    /* Type of access (CUmemcheck_memAccess_types) */
    uint32_t errorType;     /* Type of error (CUmemcheck_memAccessError_types) */
    uint64_t accessAddress; /* Address of attempted access*/
    uint64_t accessSize;    /* Size of access  */
    uint64_t errorAddress;  /* Address of first bad access */
};

struct CCDR_record_type_memUnused_st {
    uint32_t errorType;     /* Type of error (CUmemcheck_memUnusedError_types) */
    uint64_t allocAddress;  /* Address of allocated block */
    uint64_t allocSize;     /* Size of allocated block */
    uint64_t unusedSize;    /* Amount of unused data */
    uint64_t blockAddress;  /* Address of page in the block, relative to allocAddress */
    uint64_t blockSize;     /* Size of block */
};

struct CCDR_record_type_barViolation_st {
    uint32_t type;          /* Type of violation data (CUbarcheck_barViolation_type) */
    uint32_t barIndex;      /* Index of barrier */
    uint32_t pc;            /* PC of location (i.e. of barrier instruction) */
    uint32_t funcNameIx;    /* Function name */
    uint32_t fileNameIx;    /* File name */
    uint32_t line;          /* Line number */
    uint32_t blockIdxX, blockIdxY, blockIdxZ;
    uint32_t threadIdxX, threadIdxY, threadIdxZ;
};

struct CCDR_record_type_memInit_st {
    uint64_t address;
    uint32_t pc;             /* ~0 signifies unknown */
    uint32_t size;           /* Transfer size in bytes, 0 if unknown */
    uint32_t blockIdxX, blockIdxY, blockIdxZ;
    uint32_t threadIdxX, threadIdxY, threadIdxZ;
    uint32_t lineno;        /* 0 if unknown */
    uint32_t type;
    uint32_t accessType;
    uint32_t funcNameIx;
    uint32_t fileNameIx;
};

struct CCDR_record_type_uvmFatalFault_st {
    CUDBGUvmFaultType_t        faultType;
    CUDBGUvmMemoryAccessType_t accessType;
    CUDBGUvmFatalReason_t      reason;
    uint32_t                   processorIndex;
    uint64_t                   address;
    uint64_t                   timeStamp;
};

struct CCDR_ipcmsg_type_replyDataPid_st {
    uint32_t pid;               /* Sender process ID */
};

struct CCDR_ipcmsg_type_init_st {
    uint32_t handshakeVersion;  /* Version of the handshake */
    uint32_t minVersion;        /* Minimum toolkit version */
    uint32_t maxVersion;        /* Maximum toolkit version */
};

struct CCDR_ipcmsg_type_setOption_st {
    uint32_t recordVersion;
    uint32_t flags;
};

struct CCDR_ipcmsg_type_replyDataHeader_st {
    uint32_t replySize;         /* Size of the replyData message (including this header) */
    uint32_t dataOffset;        /* Offset of the data from the start of this header */
    uint32_t type;              /* Reply type */
};

struct CCDR_ipcmsg_type_addFilter_st {
    uint32_t flags;             /* Flags */
    uint32_t entryNameIx;       /* String index of name */
};

struct CCDR_ipcmsg_type_uvmInfo_st {
    CUmemcheck_uvm_version version;    /* UVM Version */
    uint32_t numHandles;               /* Number of handles to be sent */
};
#pragma pack(pop)
/* End of packed region  */
/*****************************************************************
 *                      Packed region end                        *
 *****************************************************************/

/* Some helper macros */
#define RAW_BUF_PUSH(curptr, srcptr, sz) do { memcpy(curptr, ( srcptr ) , ( sz ));\
                                              curptr += ( sz ); } while(0)
#define RAW_BUF_PUSH_STRUCT(curptr, srcptr) RAW_BUF_PUSH(curptr, srcptr, sizeof(*( srcptr )))

#define DISK2MEM(memrec, ptr, size, type, field) do { if (offsetof(type, field) < size) (memrec)->field = ((type *)(ptr))->field; } while(0)

#define MEM2DISK(memrec, ptr, size, type, field) do { if (offsetof(type, field) < size) ((type*)(ptr))->field = (memrec)->field; } while(0)

/* Added for backward compatible records */
#define CUDA_MEMCHECK_MAGIC_50TMP  0xB38F0E3296A5E38EULL

static CUmemcheck_record_class
getRecordClassFromHeaderType(CCDR_header_types ht)
{
    switch (ht) {
    case CCDR_HT_DRV_OUT:
        return CU_MEMCHECK_RECORD_CLASS_ERROR;
    case CCDR_HT_IPC_DRV_OUT:
        return CU_MEMCHECK_RECORD_CLASS_IPC;
    case CCDR_HT_IPC_DRV_IN:
        return CU_MEMCHECK_RECORD_CLASS_IPC;
    default:
        return CU_MEMCHECK_RECORD_CLASS_INVALID;
    }
    return CU_MEMCHECK_RECORD_CLASS_INVALID;
}

static CCDR_header_types
getEndpointOutputHeaderType(CCIPCendpoint writer, CUmemcheck_record_class type)
{
    // Decode the writer
    switch (writer) {
    case CCIPC_ENDPOINT_DRIVER:
        switch (type) {
        case CU_MEMCHECK_RECORD_CLASS_ERROR:
            return CCDR_HT_DRV_OUT;
        case CU_MEMCHECK_RECORD_CLASS_IPC:
            return CCDR_HT_IPC_DRV_OUT;
        default:
            break;
        }
        break;
    case CCIPC_ENDPOINT_FRONTEND:
        switch (type) {
        case CU_MEMCHECK_RECORD_CLASS_IPC:
            return CCDR_HT_IPC_DRV_IN;
        default:
            break;
        }
        break;
    default:
        break;
    }

    return CCDR_HT_NONE;
}

/* Check if an endpoint can read a record based on the header type */
static bool
canEndpointReadRecord(CCIPCendpoint endpoint, CCDR_header_types ht)
{
    switch (ht) {
    case CCDR_HT_DRV_OUT:
        if (endpoint == CCIPC_ENDPOINT_FRONTEND)
            return true;
        break;
    case CCDR_HT_IPC_DRV_OUT:
        if (endpoint == CCIPC_ENDPOINT_FRONTEND)
            return true;
        break;
    case CCDR_HT_IPC_DRV_IN:
        if (endpoint == CCIPC_ENDPOINT_DRIVER)
            return true;
        break;
    default:
        break;
    }

    return false;
}

static uint32_t
getStrTabSize(CUmemcheck_record *err)
{
    uint32_t numStr = 0;
    uint32_t sizectr = 0;
    CUmemcheck_record_string* head = NULL;
    strTracker *tracker = NULL;

    if (!err)
        return 0;

    tracker = (strTracker*)err->strings;
    // Some sanity checking
    head = tracker->list;
    for (; head; head = head->next)
        if (head->sz) {
            sizectr += head->sz;
            ++numStr;
        }

    if (numStr) {
        // Allow an extra entry for the index 0 string
        sizectr += 1;
    }

    return sizectr;
}

static uint32_t
getErrorRecVersion(CUmemcheck_record *err)
{
    if (!err)
        return CCDR_VERSION_INVALID;

    if (err->cases.error.errortype >= CU_MEMCHECK_RECORD_SIZE)
        return CCDR_VERSION_INVALID;

    return CCDR_shExtErrrecVersions[err->cases.error.errortype];
}

static uint32_t
getErrorRecMinclient(CUmemcheck_record *err)
{
    if (!err)
        return CCDR_MINCLIENT_DEFAULT;

    if (err->cases.error.errortype >= CU_MEMCHECK_RECORD_SIZE)
        return CCDR_MINCLIENT_DEFAULT;

    return CCDR_shExtErrrecMinClients[err->cases.error.errortype];
}

static uint32_t
getIPCRecVersion(CUmemcheck_record *err)
{
    if (!err)
        return CCDR_VERSION_INVALID;

    if (err->cases.ipc.type >= CU_MEMCHECK_IPC_MSG_SIZE)
        return CCDR_VERSION_INVALID;

    return CCDR_shExtIPCrecVersions[err->cases.ipc.type];
}

static uint32_t
getIPCRecMinclient(CUmemcheck_record *err)
{
    if (!err)
        return CCDR_MINCLIENT_DEFAULT;

    if (err->cases.ipc.type >= CU_MEMCHECK_IPC_MSG_SIZE)
        return CCDR_MINCLIENT_DEFAULT;

    return CCDR_shExtIPCrecMinClients[err->cases.ipc.type];
}


static uint32_t
getErrorRecSize_raceAnalysis(CUmemcheck_record *err)
{
    uint32_t sz = 0;

    if (!err || err->cases.error.errortype != CU_MEMCHECK_RECORD_RACE_ANALYSIS)
        return 0;

    /* Start with the fixed component - extended header + common */
    sz = sizeof(CCDR_section_header_ext_raceAnalysis) +
         sizeof(CCDR_record_type_raceAnalysisCommon);

    /* Account for size of vertex infos Add 1 for source  */
    sz += sizeof(CCDR_record_type_raceAnalysisVertex) * (1 + err->cases.error.cases.raceAnalysis.common.numDests);

    return sz;
}

static uint32_t
getErrorRecSize_barViolation(CUmemcheck_record *err)
{
    uint32_t sz = 0;

    if (!err || err->cases.error.errortype != CU_MEMCHECK_RECORD_BAR_VIOLATION)
        return 0;

    sz = sizeof(CCDR_record_type_barViolation);

    return sz;
}

static uint32_t
getErrorRecSize(CUmemcheck_record *err)
{
    if (!err)
        return 0;

    switch (err->cases.error.errortype) {
    case CU_MEMCHECK_RECORD_MEM_PRECISE:
        return (sizeof(CCDR_record_type_memPrecise));
    case CU_MEMCHECK_RECORD_MEM_IMPRECISE:
        return (sizeof(CCDR_record_type_memImprecise));
    case CU_MEMCHECK_RECORD_MEM_LEAK:
        return (sizeof(CCDR_record_type_memLeak));
    case CU_MEMCHECK_RECORD_MEM_SYSCALL:
        return (sizeof(CCDR_record_type_memSyscall));
    case CU_MEMCHECK_RECORD_DRV_ERROR:
        /* fallthrough */
    case CU_MEMCHECK_RECORD_DRV_WARNING:
        return (sizeof(CCDR_record_type_driverError));
    case CU_MEMCHECK_RECORD_API_ERROR:
        return (sizeof(CCDR_record_type_apiError));
    case CU_MEMCHECK_RECORD_SHMEM_HAZARD:
        return (sizeof(CCDR_record_type_shmemHazard) +
                sizeof(CCDR_section_header_ext_shmemHazard));
    case CU_MEMCHECK_RECORD_RACE_ANALYSIS:
        return (getErrorRecSize_raceAnalysis(err));
    case CU_MEMCHECK_RECORD_MEM_ACCESS:
        return (sizeof(CCDR_record_type_memAccess));
    case CU_MEMCHECK_RECORD_MEM_UNUSED:
        return (sizeof(CCDR_record_type_memUnused));
    case CU_MEMCHECK_RECORD_BAR_VIOLATION:
        return (getErrorRecSize_barViolation(err));
    case CU_MEMCHECK_RECORD_MEM_INIT:
        return (sizeof(CCDR_record_type_memInit));
    case CU_MEMCHECK_RECORD_UVM_FATAL_FAULT:
        return (sizeof(CCDR_record_type_uvmFatalFault));
    default :
        return 0;
    };

    return 0;
}

static uint32_t
getIPCRecSize_replyData(CCipcmsg_type_replyData *err)
{
    uint32_t replysize = sizeof(CCDR_ipcmsg_type_replyDataHeader);

    switch (err->type) {
    case CU_MEMCHECK_IPC_REPLY_PID:
        replysize += sizeof(CCDR_ipcmsg_type_replyDataPid);
        break;
    default:
        return replysize;
    }

    return replysize;
}

static uint32_t
getIPCRecSize(CUmemcheck_record *err)
{
    if (!err)
        return 0;

    switch (err->cases.ipc.type) {
    case CU_MEMCHECK_IPC_MSG_INIT:
        return (sizeof(CCDR_ipcmsg_type_init));
    case CU_MEMCHECK_IPC_MSG_INIT_ACK:
        return 0;
    case CU_MEMCHECK_IPC_MSG_INIT_NAK:
        return 0;
    case CU_MEMCHECK_IPC_MSG_SET_OPTION:
        return (sizeof(CCDR_ipcmsg_type_setOption));
    case CU_MEMCHECK_IPC_MSG_GET_PID:
        return 0;
    case CU_MEMCHECK_IPC_MSG_RUN_ASYNC:
        return 0;
    case CU_MEMCHECK_IPC_MSG_REPLY_DATA:
        return getIPCRecSize_replyData(&err->cases.ipc.cases.replyData);
    case CU_MEMCHECK_IPC_MSG_ADD_FILTER:
        return (sizeof(CCDR_ipcmsg_type_addFilter));
    case CU_MEMCHECK_IPC_MSG_UVM_INFO:
        return (sizeof(CCDR_ipcmsg_type_uvmInfo));
    default :
        return 0;
    };

    return 0;
}


static CCIPCresult
writePackedRecordType_memPrecise(CUmemcheck_record *rec,char *bufptr, size_t bufsize, char **endptr)
{
    CUmemcheck_record_type_memPrecise *memrec = NULL;
    CCDR_record_type_memPrecise diskrec = {0};
    CUmemcheck_error_record *err = NULL;

    if (!rec || !endptr)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;

    memrec = &err->cases.memPrecise;
    *endptr = bufptr;

    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memPrecise, address);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memPrecise, type);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memPrecise, pc);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memPrecise, size);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memPrecise, write);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memPrecise, blockIdxX);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memPrecise, blockIdxY);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memPrecise, blockIdxZ);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memPrecise, threadIdxX);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memPrecise, threadIdxY);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memPrecise, threadIdxZ);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memPrecise, lineno);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memPrecise, exception);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memPrecise, funcNameIx);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memPrecise, fileNameIx);

    RAW_BUF_PUSH_STRUCT(bufptr, &diskrec);
    *endptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
writePackedRecordType_memImprecise(CUmemcheck_record *rec, char *bufptr, size_t bufsize, char **endptr)
{
    CUmemcheck_record_type_memImprecise *memrec = NULL;
    CCDR_record_type_memImprecise diskrec = {0};
    CUmemcheck_error_record *err = NULL;

    if (!rec || !endptr)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;

    memrec = &err->cases.memImprecise;
    *endptr = bufptr;

    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memImprecise, address);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memImprecise, pc);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memImprecise, blockIdxX);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memImprecise, blockIdxY);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memImprecise, blockIdxZ);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memImprecise, threadIdxX);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memImprecise, threadIdxY);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memImprecise, threadIdxZ);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memImprecise, lineno);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memImprecise, exception);

    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memImprecise, funcNameIx);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memImprecise, fileNameIx);

    RAW_BUF_PUSH_STRUCT(bufptr, &diskrec);
    *endptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
writePackedRecordType_memLeak(CUmemcheck_record *rec, char *bufptr, size_t bufsize, char **endptr)
{
    CUmemcheck_record_type_memLeak *memrec = NULL;
    CCDR_record_type_memLeak diskrec = {0};
    CUmemcheck_error_record *err = NULL;

    if (!rec || !endptr)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;

    memrec = &err->cases.memLeak;
    *endptr = bufptr;

    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memLeak, address);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memLeak, size);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memLeak, flags);

    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memLeak, nameIx);

    RAW_BUF_PUSH_STRUCT(bufptr, &diskrec);
    *endptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
writePackedRecordType_driverError(CUmemcheck_record *rec, char *bufptr, size_t bufsize, char **endptr)
{
    CUmemcheck_record_type_driverError *memrec = NULL;
    CCDR_record_type_driverError diskrec = {0};
    CUmemcheck_error_record *err = NULL;

    if (!rec || !endptr)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;

    memrec = &err->cases.driverError;
    *endptr = bufptr;

    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_driverError, error);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_driverError, internal);

    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_driverError, stringIx);

    RAW_BUF_PUSH_STRUCT(bufptr, &diskrec);
    *endptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
writePackedRecordType_apiError(CUmemcheck_record *rec, char *bufptr, size_t bufsize, char **endptr)
{
    CUmemcheck_record_type_apiError *memrec = NULL;
    CCDR_record_type_apiError diskrec = {0};
    CUmemcheck_error_record *err = NULL;

    if (!rec || !endptr)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;

    memrec = &err->cases.apiError;
    *endptr = bufptr;

    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_apiError, apiType);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_apiError, apiResult);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_apiError, contextID);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_apiError, apiCallID);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_apiError, stringIx);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_apiError, errorNameStringIx);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_apiError, errorMsgStringIx);

    RAW_BUF_PUSH_STRUCT(bufptr, &diskrec);
    *endptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
writePackedRecordType_memSyscall(CUmemcheck_record *rec, char *bufptr, size_t bufsize, char **endptr)
{
    CUmemcheck_record_type_memSyscall *memrec = NULL;
    CCDR_record_type_memSyscall diskrec = {0};
    CUmemcheck_error_record *err = NULL;

    if (!rec || !endptr)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;

    memrec = &err->cases.memSyscall;
    *endptr = bufptr;

    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memSyscall, type);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memSyscall, blockIdxX);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memSyscall, blockIdxY);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memSyscall, blockIdxZ);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memSyscall, threadIdxX);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memSyscall, threadIdxY);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memSyscall, threadIdxZ);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memSyscall, pc);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memSyscall, lineno);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memSyscall, address);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memSyscall, size);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memSyscall, fileNameIx);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memSyscall, funcNameIx);

    RAW_BUF_PUSH_STRUCT(bufptr, &diskrec);
    *endptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
writePackedRecordType_shmemHazard(CUmemcheck_record *rec, char *bufptr, size_t bufsize, char **endptr)
{
    CUmemcheck_record_type_shmemHazard *memrec = NULL;
    CUmemcheck_record_type_hazardCommonInfo *memcommon = NULL;
    CUmemcheck_record_type_hazardThreadInfo *memt0 = NULL, *memt1 = NULL;
    CCDR_record_type_shmemHazard diskrec = {{0}};
    CCDR_section_header_ext_shmemHazard shmem = {0};
    CCDR_record_type_hazardThreadInfo *diskt0 = NULL, *diskt1 = NULL;
    CCDR_record_type_hazardCommonInfo *diskcommon = NULL;
    CUmemcheck_error_record *err = NULL;

    if (!rec || !endptr)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;

    memrec      = &err->cases.shmemHazard;
    memcommon   = &memrec->common;
    memt0       = &memrec->thread0;
    memt1       = &memrec->thread1;

    diskcommon  = &(diskrec.common);
    diskt0      = &(diskrec.thread0);
    diskt1      = &(diskrec.thread1);

    *endptr = bufptr;

    /* Common */
    MEM2DISK(memcommon, diskcommon, bufsize,
             CCDR_record_type_hazardCommonInfo, gridid);
    MEM2DISK(memcommon, diskcommon, bufsize,
             CCDR_record_type_hazardCommonInfo, hazardType);
    MEM2DISK(memcommon, diskcommon, bufsize,
             CCDR_record_type_hazardCommonInfo, address);
    MEM2DISK(memcommon, diskcommon, bufsize,
             CCDR_record_type_hazardCommonInfo, blockIdxX);
    MEM2DISK(memcommon, diskcommon, bufsize,
             CCDR_record_type_hazardCommonInfo, blockIdxY);
    MEM2DISK(memcommon, diskcommon, bufsize,
             CCDR_record_type_hazardCommonInfo, blockIdxZ);
    MEM2DISK(memcommon, diskcommon, bufsize,
             CCDR_record_type_hazardCommonInfo, readData);
    MEM2DISK(memcommon, diskcommon, bufsize,
             CCDR_record_type_hazardCommonInfo, writeData);
    MEM2DISK(memcommon, diskcommon, bufsize,
             CCDR_record_type_hazardCommonInfo, filterType);
    MEM2DISK(memcommon, diskcommon, bufsize,
             CCDR_record_type_hazardCommonInfo, kernelNameIx);

    /* Thread 0 */
    MEM2DISK(memt0, diskt0, bufsize,
             CCDR_record_type_hazardThreadInfo, write);
    MEM2DISK(memt0, diskt0, bufsize,
             CCDR_record_type_hazardThreadInfo, threadIdxX);
    MEM2DISK(memt0, diskt0, bufsize,
             CCDR_record_type_hazardThreadInfo, threadIdxY);
    MEM2DISK(memt0, diskt0, bufsize,
             CCDR_record_type_hazardThreadInfo, threadIdxZ);
    MEM2DISK(memt0, diskt0, bufsize,
             CCDR_record_type_hazardThreadInfo, pc);
    MEM2DISK(memt0, diskt0, bufsize,
             CCDR_record_type_hazardThreadInfo, line);
    MEM2DISK(memt0, diskt0, bufsize,
             CCDR_record_type_hazardThreadInfo, fileNameIx);
    MEM2DISK(memt0, diskt0, bufsize,
             CCDR_record_type_hazardThreadInfo, funcNameIx);

    /* Thread 1 */
    MEM2DISK(memt1, diskt1, bufsize,
             CCDR_record_type_hazardThreadInfo, write);
    MEM2DISK(memt1, diskt1, bufsize,
             CCDR_record_type_hazardThreadInfo, threadIdxX);
    MEM2DISK(memt1, diskt1, bufsize,
             CCDR_record_type_hazardThreadInfo, threadIdxY);
    MEM2DISK(memt1, diskt1, bufsize,
             CCDR_record_type_hazardThreadInfo, threadIdxZ);
    MEM2DISK(memt1, diskt1, bufsize,
             CCDR_record_type_hazardThreadInfo, pc);
    MEM2DISK(memt1, diskt1, bufsize,
             CCDR_record_type_hazardThreadInfo, line);
    MEM2DISK(memt1, diskt1, bufsize,
             CCDR_record_type_hazardThreadInfo, fileNameIx);
    MEM2DISK(memt1, diskt1, bufsize,
             CCDR_record_type_hazardThreadInfo, funcNameIx);

    /* For the shmem record, we must first push the extension */
    shmem.commonsize = sizeof(*diskcommon);
    shmem.threadinfosize = sizeof(*diskt0);

    RAW_BUF_PUSH_STRUCT(bufptr, &shmem);

    RAW_BUF_PUSH_STRUCT(bufptr, &diskrec);
    *endptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
writePackedRecordType_raceAnalysisVertex(CUmemcheck_record_type_raceAnalysisVertex *memvtx, char *bufptr, size_t bufsize, char **endptr)
{
    CCDR_record_type_raceAnalysisVertex diskvtx = {0};

    if (!memvtx || !bufptr || !endptr)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    *endptr = bufptr;

    MEM2DISK(memvtx, &diskvtx, bufsize,
             CCDR_record_type_raceAnalysisVertex, pc);
    MEM2DISK(memvtx, &diskvtx, bufsize,
             CCDR_record_type_raceAnalysisVertex, write);
    MEM2DISK(memvtx, &diskvtx, bufsize,
             CCDR_record_type_raceAnalysisVertex, funcNameIx);
    MEM2DISK(memvtx, &diskvtx, bufsize,
             CCDR_record_type_raceAnalysisVertex, fileNameIx);
    MEM2DISK(memvtx, &diskvtx, bufsize,
             CCDR_record_type_raceAnalysisVertex, line);
    MEM2DISK(memvtx, &diskvtx, bufsize,
             CCDR_record_type_raceAnalysisVertex, hazardTypeMask);
    MEM2DISK(memvtx, &diskvtx, bufsize,
             CCDR_record_type_raceAnalysisVertex, weight);
    MEM2DISK(memvtx, &diskvtx, bufsize,
             CCDR_record_type_raceAnalysisVertex, count);

    RAW_BUF_PUSH_STRUCT(bufptr, &diskvtx);
    *endptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
writePackedRecordType_raceAnalysis(CUmemcheck_record *rec, char *bufptr, size_t bufsize, char **endptr)
{
    CUmemcheck_record_type_raceAnalysis *memrec = NULL;
    CUmemcheck_record_type_raceAnalysisCommon *memcommon = NULL;
    CUmemcheck_record_type_raceAnalysisVertex *memsrc = NULL, *memdst = NULL;
    CCDR_section_header_ext_raceAnalysis racehdr = {0};
    CCDR_record_type_raceAnalysisCommon diskcommon = {0};
    CCIPCresult res = CCIPC_SUCCESS;
    uint32_t i, numDests = 0;
    CUmemcheck_error_record *err = NULL;

    if (!rec || !endptr)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;

    memrec      = &err->cases.raceAnalysis;
    memcommon   = &memrec->common;
    memsrc      = &memrec->source;
    memdst      = memrec->dests;
    numDests    = memcommon->numDests;

    *endptr = bufptr;

    /* For the raceAnalysis record, we must first push the header extension */
    racehdr.headerextsize   = sizeof(racehdr);
    racehdr.commonsize      = sizeof(diskcommon);
    racehdr.vertexsize      = sizeof(CCDR_record_type_raceAnalysisVertex);

    RAW_BUF_PUSH_STRUCT(bufptr, &racehdr);

    /* Common */
    MEM2DISK(memcommon, &diskcommon, bufsize,
             CCDR_record_type_raceAnalysisCommon, numDests);

    RAW_BUF_PUSH_STRUCT(bufptr, &diskcommon);

    /* Source vertex */
    res = writePackedRecordType_raceAnalysisVertex(memsrc, bufptr, bufsize, &bufptr);
    if (res != CCIPC_SUCCESS)
        return res;

    for (i = 0; i < numDests; ++i) {
        memdst = &memrec->dests[i];
        res = writePackedRecordType_raceAnalysisVertex(memdst, bufptr, bufsize, &bufptr);
        if (res != CCIPC_SUCCESS)
            return res;
    }

    *endptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
writePackedRecordType_memAccess(CUmemcheck_record *rec, char *bufptr, size_t bufsize, char **endptr)
{
    CUmemcheck_record_type_memAccess *memrec = NULL;
    CCDR_record_type_memAccess diskrec = {0};
    CUmemcheck_error_record *err = NULL;

    if (!rec || !endptr)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;

    memrec = &err->cases.memAccess;
    *endptr = bufptr;

    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memAccess, accessType);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memAccess, errorType);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memAccess, accessAddress);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memAccess, accessSize);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memAccess, errorAddress);

    RAW_BUF_PUSH_STRUCT(bufptr, &diskrec);
    *endptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
writePackedRecordType_memUnused(CUmemcheck_record *rec, char *bufptr, size_t bufsize, char **endptr)
{
    CUmemcheck_record_type_memUnused *memrec = NULL;
    CCDR_record_type_memUnused diskrec = {0};
    CUmemcheck_error_record *err = NULL;

    if (!rec || !endptr)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;

    memrec = &err->cases.memUnused;
    *endptr = bufptr;

    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memUnused, errorType);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memUnused, allocAddress);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memUnused, allocSize);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memUnused, unusedSize);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memUnused, blockAddress);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memUnused, blockSize);

    RAW_BUF_PUSH_STRUCT(bufptr, &diskrec);
    *endptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
writePackedRecordType_barViolation(CUmemcheck_record *rec, char *bufptr, size_t bufsize, char **endptr)
{
    CUmemcheck_record_type_barViolation *memrec = NULL;
    CCDR_record_type_barViolation diskrec = {0};
    CUmemcheck_error_record *err = NULL;

    if (!rec || !endptr)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;

    memrec   = &err->cases.barViolation;

    *endptr = bufptr;

    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_barViolation, type);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_barViolation, barIndex);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_barViolation, pc);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_barViolation, funcNameIx);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_barViolation, fileNameIx);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_barViolation, line);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_barViolation, blockIdxX);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_barViolation, blockIdxY);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_barViolation, blockIdxZ);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_barViolation, threadIdxX);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_barViolation, threadIdxY);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_barViolation, threadIdxZ);

    RAW_BUF_PUSH_STRUCT(bufptr, &diskrec);

    *endptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
writePackedRecordType_memInit(CUmemcheck_record *rec,char *bufptr, size_t bufsize, char **endptr)
{
    CUmemcheck_record_type_memInit *memrec = NULL;
    CCDR_record_type_memInit diskrec = {0};
    CUmemcheck_error_record *err = NULL;

    if (!rec || !endptr)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;

    memrec = &err->cases.memInit;
    *endptr = bufptr;

    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memInit, address);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memInit, type);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memInit, accessType);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memInit, pc);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memInit, size);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memInit, blockIdxX);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memInit, blockIdxY);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memInit, blockIdxZ);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memInit, threadIdxX);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memInit, threadIdxY);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memInit, threadIdxZ);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memInit, lineno);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memInit, funcNameIx);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_record_type_memInit, fileNameIx);

    RAW_BUF_PUSH_STRUCT(bufptr, &diskrec);
    *endptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
writePackedRecordType_uvmFatalFault(CUmemcheck_record *rec,char *bufptr, size_t bufsize, char **endptr)
{
    CUmemcheck_record_type_uvmFatalFault *uvmrec = NULL;
    CCDR_record_type_uvmFatalFault diskrec = {0};
    CUmemcheck_error_record *err = NULL;

    if (!rec || !endptr)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;

    uvmrec = &err->cases.uvmFatalFault;
    *endptr = bufptr;

    MEM2DISK(uvmrec, &diskrec, bufsize, CCDR_record_type_uvmFatalFault, faultType);
    MEM2DISK(uvmrec, &diskrec, bufsize, CCDR_record_type_uvmFatalFault, accessType);
    MEM2DISK(uvmrec, &diskrec, bufsize, CCDR_record_type_uvmFatalFault, reason);
    MEM2DISK(uvmrec, &diskrec, bufsize, CCDR_record_type_uvmFatalFault, processorIndex);
    MEM2DISK(uvmrec, &diskrec, bufsize, CCDR_record_type_uvmFatalFault, address);
    MEM2DISK(uvmrec, &diskrec, bufsize, CCDR_record_type_uvmFatalFault, timeStamp);

    RAW_BUF_PUSH_STRUCT(bufptr, &diskrec);
    *endptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
writePackedRecordTypeError(CUmemcheck_record *rec, char *bufptr, size_t bufsize, char **endptr)
{
    if (!rec || !bufptr)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    if (!bufsize)
        return CCIPC_ERROR_FORMAT_UNDERSIZED_BUFFER;

    if (rec->recordclass != CU_MEMCHECK_RECORD_CLASS_ERROR)
        return CCIPC_ERROR_FORMAT_INVALID_RECORD_CLASS;

    switch (rec->cases.error.errortype) {
    case CU_MEMCHECK_RECORD_MEM_PRECISE:
        return writePackedRecordType_memPrecise(rec, bufptr, bufsize, endptr);
    case CU_MEMCHECK_RECORD_MEM_IMPRECISE:
        return writePackedRecordType_memImprecise(rec, bufptr, bufsize, endptr);
    case CU_MEMCHECK_RECORD_MEM_LEAK:
        return writePackedRecordType_memLeak(rec, bufptr, bufsize, endptr);
    case CU_MEMCHECK_RECORD_MEM_SYSCALL:
        return writePackedRecordType_memSyscall(rec, bufptr, bufsize, endptr);
    case CU_MEMCHECK_RECORD_DRV_ERROR:
        /* fallthrough */
    case CU_MEMCHECK_RECORD_DRV_WARNING:
        return writePackedRecordType_driverError(rec, bufptr, bufsize, endptr);
    case CU_MEMCHECK_RECORD_API_ERROR:
        return writePackedRecordType_apiError(rec, bufptr, bufsize, endptr);
    case CU_MEMCHECK_RECORD_SHMEM_HAZARD:
        return writePackedRecordType_shmemHazard(rec, bufptr, bufsize, endptr);
    case CU_MEMCHECK_RECORD_RACE_ANALYSIS:
        return writePackedRecordType_raceAnalysis(rec, bufptr, bufsize, endptr);
    case CU_MEMCHECK_RECORD_MEM_ACCESS:
        return writePackedRecordType_memAccess(rec, bufptr, bufsize, endptr);
    case CU_MEMCHECK_RECORD_MEM_UNUSED:
        return writePackedRecordType_memUnused(rec, bufptr, bufsize, endptr);
    case CU_MEMCHECK_RECORD_BAR_VIOLATION:
        return writePackedRecordType_barViolation(rec, bufptr, bufsize, endptr);
    case CU_MEMCHECK_RECORD_MEM_INIT:
        return writePackedRecordType_memInit(rec, bufptr, bufsize, endptr);
    case CU_MEMCHECK_RECORD_UVM_FATAL_FAULT:
        return writePackedRecordType_uvmFatalFault(rec, bufptr, bufsize, endptr);
    default :
        return CCIPC_ERROR_FORMAT_UNKNOWN_RECORD_TYPE;
    };

    return CCIPC_SUCCESS;
}

static CCIPCresult
writePackedRecordTypeIPC_init(CUmemcheck_record *rec, char *bufptr, size_t bufsize, char **endptr)
{
    CCipcmsg_type_init *memrec = NULL;
    CCDR_ipcmsg_type_init diskrec = {0};
    CUmemcheck_ipc_record *ipc = NULL;

    if (!rec || !endptr)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    if (!bufsize)
        return CCIPC_ERROR_FORMAT_UNDERSIZED_BUFFER;

    ipc = &rec->cases.ipc;
    memrec = &ipc->cases.init;

    *endptr = bufptr;

    MEM2DISK(memrec, &diskrec, bufsize, CCDR_ipcmsg_type_init, handshakeVersion);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_ipcmsg_type_init, minVersion);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_ipcmsg_type_init, maxVersion);

    RAW_BUF_PUSH_STRUCT(bufptr, &diskrec);
    *endptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
writePackedRecordTypeIPC_setOption(CUmemcheck_record *rec, char *bufptr, size_t bufsize, char **endptr)
{
    CCipcmsg_type_setOption *memrec = NULL;
    CCDR_ipcmsg_type_setOption diskrec = {0};
    CUmemcheck_ipc_record *ipc = NULL;

    if (!rec || !endptr)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    if (!bufsize)
        return CCIPC_ERROR_FORMAT_UNDERSIZED_BUFFER;

    ipc = &rec->cases.ipc;
    memrec = &ipc->cases.setOption;

    *endptr = bufptr;

    MEM2DISK(memrec, &diskrec, bufsize, CCDR_ipcmsg_type_setOption, recordVersion);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_ipcmsg_type_setOption, flags);

    RAW_BUF_PUSH_STRUCT(bufptr, &diskrec);
    *endptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
writePackedRecordTypeIPC_replyDataPid(CCipcmsg_type_replyDataPid *memrec, char *bufptr, size_t bufsize, char **endptr)
{
    CCDR_ipcmsg_type_replyDataPid diskrec = {0};

    if (!memrec || !endptr)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    if (!bufsize)
        return CCIPC_ERROR_FORMAT_UNDERSIZED_BUFFER;

    *endptr = bufptr;

    MEM2DISK(memrec, &diskrec, bufsize, CCDR_ipcmsg_type_replyDataPid, pid);

    RAW_BUF_PUSH_STRUCT(bufptr, &diskrec);
    *endptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
writePackedRecordTypeIPC_replyData(CUmemcheck_record *rec, char *bufptr, size_t bufsize, char **endptr)
{
    CCipcmsg_type_replyData *memrec = NULL;
    CCDR_ipcmsg_type_replyDataHeader diskrec = {0};
    CUmemcheck_ipc_record *ipc = NULL;
    CCIPCresult res = CCIPC_SUCCESS;

    if (!rec || !endptr)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    if (!bufsize)
        return CCIPC_ERROR_FORMAT_UNDERSIZED_BUFFER;

    ipc = &rec->cases.ipc;
    memrec = &ipc->cases.replyData;

    *endptr = bufptr;

    diskrec.replySize = getIPCRecSize(rec);
    diskrec.dataOffset = sizeof(diskrec);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_ipcmsg_type_replyDataHeader, type);
    RAW_BUF_PUSH_STRUCT(bufptr, &diskrec);

    switch (memrec->type) {
    case CU_MEMCHECK_IPC_REPLY_PID:
        res = writePackedRecordTypeIPC_replyDataPid(&memrec->cases.pid, bufptr, bufsize, endptr);
        break;
    default:
        return CCIPC_ERROR_FORMAT_UNKNOWN_RECORD_TYPE;
    }

    if (res != CCIPC_SUCCESS)
        return res;

    *endptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
writePackedRecordTypeIPC_addFilter(CUmemcheck_record *rec, char *bufptr, size_t bufsize, char **endptr)
{
    CCipcmsg_type_addFilter *memrec = NULL;
    CCDR_ipcmsg_type_addFilter diskrec = {0};
    CUmemcheck_ipc_record *ipc = NULL;

    if (!rec || !endptr)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    if (!bufsize)
        return CCIPC_ERROR_FORMAT_UNDERSIZED_BUFFER;

    ipc = &rec->cases.ipc;
    memrec = &ipc->cases.addFilter;

    *endptr = bufptr;

    MEM2DISK(memrec, &diskrec, bufsize, CCDR_ipcmsg_type_addFilter, flags);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_ipcmsg_type_addFilter, entryNameIx);

    RAW_BUF_PUSH_STRUCT(bufptr, &diskrec);
    *endptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
writePackedRecordTypeIPC_uvmInfo(CUmemcheck_record *rec, char *bufptr, size_t bufsize, char **endptr)
{
    CCipcmsg_type_uvmInfo *memrec = NULL;
    CCDR_ipcmsg_type_uvmInfo diskrec = {0};
    CUmemcheck_ipc_record *ipc = NULL;

    if (!rec || !endptr)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    if (!bufsize)
        return CCIPC_ERROR_FORMAT_UNDERSIZED_BUFFER;

    ipc = &rec->cases.ipc;
    memrec = &ipc->cases.uvmInfo;

    *endptr = bufptr;

    MEM2DISK(memrec, &diskrec, bufsize, CCDR_ipcmsg_type_uvmInfo, version);
    MEM2DISK(memrec, &diskrec, bufsize, CCDR_ipcmsg_type_uvmInfo, numHandles);

    RAW_BUF_PUSH_STRUCT(bufptr, &diskrec);
    *endptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
writePackedRecordTypeIPC(CUmemcheck_record *rec, char *bufptr, size_t bufsize, char **endptr)
{
    if (!rec || !bufptr)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    if (rec->recordclass != CU_MEMCHECK_RECORD_CLASS_IPC)
        return CCIPC_ERROR_FORMAT_INVALID_RECORD_CLASS;

    switch (rec->cases.ipc.type) {
    case CU_MEMCHECK_IPC_MSG_INIT:
        return writePackedRecordTypeIPC_init(rec, bufptr, bufsize, endptr);
    case CU_MEMCHECK_IPC_MSG_INIT_ACK:
        return CCIPC_SUCCESS;
    case CU_MEMCHECK_IPC_MSG_INIT_NAK:
        return CCIPC_SUCCESS;
    case CU_MEMCHECK_IPC_MSG_SET_OPTION:
        return writePackedRecordTypeIPC_setOption(rec, bufptr, bufsize, endptr);
    case CU_MEMCHECK_IPC_MSG_GET_PID:
        return CCIPC_SUCCESS;
    case CU_MEMCHECK_IPC_MSG_RUN_ASYNC:
        return CCIPC_SUCCESS;
    case CU_MEMCHECK_IPC_MSG_REPLY_DATA:
        return writePackedRecordTypeIPC_replyData(rec, bufptr, bufsize, endptr);
    case CU_MEMCHECK_IPC_MSG_ADD_FILTER:
        return writePackedRecordTypeIPC_addFilter(rec, bufptr, bufsize, endptr);
    case CU_MEMCHECK_IPC_MSG_UVM_INFO:
        return writePackedRecordTypeIPC_uvmInfo(rec, bufptr, bufsize, endptr);
    default :
        return CCIPC_ERROR_FORMAT_UNKNOWN_RECORD_TYPE;
    };

    return CCIPC_SUCCESS;
}

static uint64_t
getBacktraceSize(CUmemcheck_record *rec)
{
    CUmemcheck_backtrace *recbt = NULL;
    uint64_t size = 0;

    if (!rec) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return 0;
    }

    if (!rec->backtrace) {
        CCIPC_DEBUG_PRINT("No backtrace present\n");
        return 0;
    }

    recbt = (CUmemcheck_backtrace*)rec->backtrace;

    if (recbt->hostDepth) {
        size += (recbt->hostDepth *
                 sizeof(CCDR_section_backtrace_hostFrame));
        size += sizeof(CCDR_section_backtrace_host);
        size += sizeof(CCDR_section_backtrace_start);
    }

    if (recbt->devDepth) {
        size += (recbt->devDepth *
                 sizeof(CCDR_section_backtrace_devFrame));
        size += sizeof(CCDR_section_backtrace_dev);
        size += sizeof(CCDR_section_backtrace_start);
    }

    if (!size)
        CCIPC_DEBUG_PRINT("No backtrace found.\n");

    return size;
}

static uint64_t
getRecordClassSize(CUmemcheck_record *rec)
{
    uint64_t sizectr = 0;

    switch (rec->recordclass) {
    case CU_MEMCHECK_RECORD_CLASS_ERROR:
        if (rec->cases.error.errortype == CU_MEMCHECK_RECORD_INVALID)
            return 0;
        sizectr += getErrorRecSize(rec);
        sizectr += sizeof(CCDR_section_header_ext_errrec);
        break;
    case CU_MEMCHECK_RECORD_CLASS_IPC:
        if (rec->cases.ipc.type == CU_MEMCHECK_IPC_MSG_INVALID ||
            rec->cases.ipc.type >= CU_MEMCHECK_IPC_MSG_SIZE)
            return 0;
        sizectr += getIPCRecSize(rec);
        sizectr += sizeof(CCDR_section_header_ext_ipcrec);
        break;
    default :
        break;
    }

    return sizectr;
}

static uint64_t
getPackedRecordSize_single(CUmemcheck_record *rec)
{
    uint64_t sizectr = 0;
    uint32_t strtab = 0;
    uint64_t btsize = 0;
    uint64_t clsize = 0;

    if (rec->recordclass == CU_MEMCHECK_RECORD_CLASS_INVALID ||
        rec->recordclass >= CU_MEMCHECK_RECORD_CLASS_SIZE)
        return 0;

    /* Check for type mismatches */
    if (rec->recordclass == CU_MEMCHECK_RECORD_CLASS_ERROR &&
        rec->cases.error.errortype == CU_MEMCHECK_RECORD_INVALID)
        return 0;

    if (rec->recordclass == CU_MEMCHECK_RECORD_CLASS_IPC &&
        rec->cases.ipc.type == CU_MEMCHECK_IPC_MSG_INVALID)
        return 0;

    sizectr += sizeof(CCDR_header);
    sizectr += sizeof(CCDR_header_ext);

    strtab = getStrTabSize(rec);
    if (strtab) {
        sizectr += strtab;
        sizectr += sizeof(CCDR_section_header);
    }

    clsize = getRecordClassSize(rec);
    if (clsize) {
        sizectr += clsize;
        sizectr += sizeof(CCDR_section_header);
    }

    btsize = getBacktraceSize(rec);
    if (btsize) {
        sizectr += btsize;
        sizectr += sizeof(CCDR_section_header);
        sizectr += sizeof(CCDR_section_header_ext_backtrace);
    }

    return sizectr;
}

static uint64_t
getPackedRecordSize(CUmemcheck_record *err)
{
    uint32_t childcount = 0;
    uint64_t size = 0;
    CUmemcheck_record *child = NULL;

    if (!err)
        return 0;

    size = getPackedRecordSize_single(err);
    childcount = err->numchildren;
    if (!childcount)
        return size;

    for (child = err->children[0];
         child <= err->children[childcount - 1];
         ++child) {
        size += getPackedRecordSize(child);
    }

    return size;
}

uint64_t
getRecordWriteSize(CUmemcheck_record *err, uint32_t recordVersion)
{
    if (!err)
        return 0;

    switch (recordVersion) {
    case 9:
        return getPackedRecordSize(err);
        break;
    case 8:
    case 7:
    case 6:
    case 5:
        return getLegacyRecordSize_v5(err);
        break;
    case 4:
        return getLegacyRecordSize_v4(err);
        break;
    case 3:
        return getLegacyRecordSize_v3(err);
        break;
    default:
        /* Should not happen */
        return 0;
    }

    /* Should never happen */
    return 0;
}

static CCIPCresult
getPackedRecordSectionStrtab(char *bufptr, uint64_t size, char **endptr,
                             CUmemcheck_record *err)
{
    CCDR_section_header shstrtab = {0};
    uint32_t strtabsize = 0;
    unsigned char nullstr = 0;
    CUmemcheck_record_string* head = NULL;

    if (!bufptr || !size || !endptr || !err)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    *endptr = bufptr;

    strtabsize = getStrTabSize(err);

    // Generate the strtab section header
    if (strtabsize) {
        shstrtab.size = sizeof(shstrtab) + strtabsize;
        shstrtab.version = CCDR_SH_VERSION;
        shstrtab.minclient = CCDR_MINCLIENT_DEFAULT;
        shstrtab.type = CCDR_SHT_STRTAB;
        shstrtab.dataoffset = sizeof(shstrtab);
        shstrtab.extoffset = sizeof(shstrtab);

        // Write the string table section header
        RAW_BUF_PUSH_STRUCT(bufptr, &shstrtab);

        // Write the null string
        RAW_BUF_PUSH_STRUCT(bufptr, &nullstr);

        // Write all the strings
        head = ((strTracker*)err->strings)->list;
        for (; head; head = head->next)
            if (head->sz) {
                RAW_BUF_PUSH(bufptr, head->str, head->sz);
            }
    }

    *endptr = bufptr;
    return CCIPC_SUCCESS;
}

static CCIPCresult
getPackedRecordSectionErrrec(char *bufptr, uint64_t size, char **endptr,
                             CUmemcheck_record *err)
{
    CCDR_section_header sherrrec = {0};
    CCDR_section_header_ext_errrec shexterr = {0};
    uint32_t recsize = 0;
    CCIPCresult res = CCIPC_SUCCESS;

    if (!bufptr || !size || !endptr || !err) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    *endptr = bufptr;

    if (err->recordclass != CU_MEMCHECK_RECORD_CLASS_ERROR)
        return CCIPC_SUCCESS;

    if (err->cases.error.errortype == CU_MEMCHECK_RECORD_INVALID)
        return CCIPC_SUCCESS;

    recsize = getErrorRecSize(err);

    // Generate the section header extension for the error record
    shexterr.recordsize = recsize;
    shexterr.version = getErrorRecVersion(err);
    shexterr.minclient = getErrorRecMinclient(err);
    shexterr.errortype = err->cases.error.errortype;

    // Generate the section header for the error record
    sherrrec.size = sizeof(sherrrec) + sizeof(shexterr) + shexterr.recordsize;
    sherrrec.version = CCDR_SH_VERSION;
    sherrrec.minclient = CCDR_MINCLIENT_DEFAULT;
    sherrrec.type = CCDR_SHT_ERRREC;
    sherrrec.dataoffset = sizeof(sherrrec) + sizeof(shexterr);
    sherrrec.extoffset = sizeof(sherrrec);

    // Write the error record section header
    RAW_BUF_PUSH_STRUCT(bufptr, &sherrrec);

    // Write the section header extension
    RAW_BUF_PUSH_STRUCT(bufptr, &shexterr);

    // Write the error record (This may push extra headers in case of hazard records)
    // There can be several failures, but the main type of failures are usually
    // due to mismatches between the size from getErrorRecSize and the actual
    // data being written
    res = writePackedRecordTypeError(err, bufptr, recsize, &bufptr);

    *endptr = bufptr;

    return res;
}

static CCIPCresult
getPackedRecordSectionIPCrec(char *bufptr, uint64_t size, char **endptr,
                             CUmemcheck_record *err)
{
    CCDR_section_header shipcrec = {0};
    CCDR_section_header_ext_ipcrec shextipc = {0};
    uint32_t recsize = 0;
    CCIPCresult res = CCIPC_SUCCESS;

    if (!bufptr || !size || !endptr || !err) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    *endptr = bufptr;

    if (err->recordclass != CU_MEMCHECK_RECORD_CLASS_IPC)
        return CCIPC_SUCCESS;

    if (err->cases.ipc.type == CU_MEMCHECK_IPC_MSG_INVALID)
        return CCIPC_SUCCESS;

    recsize = getIPCRecSize(err);

    // Generate the section header extension for the IPC record
    shextipc.recordsize = recsize;
    shextipc.version = getIPCRecVersion(err);
    shextipc.minclient = getIPCRecMinclient(err);
    shextipc.ipctype = err->cases.ipc.type;

    // Generate the section header for the IPC record
    shipcrec.size = sizeof(shipcrec) + sizeof(shextipc) + shextipc.recordsize;
    shipcrec.version = CCDR_SH_VERSION;
    shipcrec.minclient = CCDR_MINCLIENT_DEFAULT;
    shipcrec.type = CCDR_SHT_IPCREC;
    shipcrec.dataoffset = sizeof(shipcrec) + sizeof(shextipc);
    shipcrec.extoffset = sizeof(shipcrec);

    // Write the IPC record section header
    RAW_BUF_PUSH_STRUCT(bufptr, &shipcrec);

    // Write the section header extension
    RAW_BUF_PUSH_STRUCT(bufptr, &shextipc);

    // Write the IPC record
    res = writePackedRecordTypeIPC(err, bufptr, recsize, &bufptr);

    *endptr = bufptr;

    return res;
}

static CCIPCresult
getPackedBacktraceHost(char *bufptr, uint64_t size, char **endptr,
                       CUmemcheck_record *err)
{
    CCDR_section_backtrace_start start = {0};
    CCDR_section_backtrace_host  host  = {0};
    CCDR_section_backtrace_hostFrame hostFrame = {0};
    CUmemcheck_backtrace *recbt = NULL;
    uint32_t i = 0;

    if (!bufptr || !size || !endptr || !err) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    *endptr = bufptr;

    recbt = err->backtrace;
    if (!recbt || !recbt->hostDepth)
        return CCIPC_SUCCESS;

    // Generate the start header
    start.size = sizeof(start) + sizeof(host) +
                 (recbt->hostDepth * sizeof(hostFrame));
    start.type = CU_MEMCHECK_BACKTRACE_TYPE_HOST;
    start.maxDepth = recbt->maxHostDepth;
    start.totalDepth = recbt->hostDepth;
    start.dataOffset = sizeof(start);
    start.frameOffset = sizeof(start) + sizeof(host);

    // Write the start header
    RAW_BUF_PUSH_STRUCT(bufptr, &start);

    // Write the host data
    host.threadId = recbt->host.threadId;
    RAW_BUF_PUSH_STRUCT(bufptr, &host);

    // Copy the full list of frames
    for (i = 0; i < recbt->hostDepth; ++i) {
        memset(&hostFrame, 0, sizeof(hostFrame));
        hostFrame.flags = recbt->hostFrames[i].flags;
        hostFrame.depth = recbt->hostFrames[i].depth;
        hostFrame.addr = recbt->hostFrames[i].addr;
        hostFrame.funcNameIx = recbt->hostFrames[i].funcNameIx;
        hostFrame.funcOffset = recbt->hostFrames[i].funcOffset;
        hostFrame.libNameIx = recbt->hostFrames[i].libNameIx;
        hostFrame.libBaseAddr = recbt->hostFrames[i].libBaseAddr;
        hostFrame.fileNameIx = recbt->hostFrames[i].fileNameIx;
        hostFrame.lineno = recbt->hostFrames[i].lineno;
        RAW_BUF_PUSH_STRUCT(bufptr, &hostFrame);
    }

    *endptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
getPackedBacktraceDev(char *bufptr, uint64_t size, char **endptr,
                      CUmemcheck_record *err)
{
    CCDR_section_backtrace_start start = {0};
    CCDR_section_backtrace_dev   dev   = {0};
    CCDR_section_backtrace_devFrame devFrame = {0};
    CUmemcheck_backtrace *recbt = NULL;
    uint32_t i = 0;

    if (!bufptr || !size || !endptr || !err) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    *endptr = bufptr;

    recbt = err->backtrace;
    if (!recbt || !recbt->devDepth)
        return CCIPC_SUCCESS;

    // Generate the start header
    start.size = sizeof(start) + sizeof(dev) +
                 (recbt->devDepth * sizeof(devFrame));
    start.type = CU_MEMCHECK_BACKTRACE_TYPE_DEVICE;
    start.maxDepth = recbt->maxDevDepth;
    start.totalDepth = recbt->devDepth;
    start.dataOffset = sizeof(start);
    start.frameOffset = sizeof(start) + sizeof(dev);

    // Write the start header
    RAW_BUF_PUSH_STRUCT(bufptr, &start);

    // Write the dev data
    dev.threadIdxX  = recbt->dev.threadIdxX;
    dev.threadIdxY  = recbt->dev.threadIdxY;
    dev.threadIdxZ  = recbt->dev.threadIdxZ;
    dev.blockIdxX   = recbt->dev.blockIdxX;
    dev.blockIdxY   = recbt->dev.blockIdxY;
    dev.blockIdxZ   = recbt->dev.blockIdxZ;
    dev.entryKernelNameIx  = recbt->dev.entryKernelNameIx;

    RAW_BUF_PUSH_STRUCT(bufptr, &dev);

    // Copy the full list of frames
    for (i = 0; i < recbt->devDepth; ++i) {
        memset(&devFrame, 0, sizeof(devFrame));
        devFrame.flags = recbt->devFrames[i].flags;
        devFrame.depth = recbt->devFrames[i].depth;
        devFrame.addr = recbt->devFrames[i].addr;
        devFrame.funcNameIx = recbt->devFrames[i].funcNameIx;
        devFrame.funcOffset = recbt->devFrames[i].funcOffset;
        devFrame.kernelNameIx = recbt->devFrames[i].kernelNameIx;
        devFrame.kernelAddr = recbt->devFrames[i].kernelAddr;
        devFrame.moduleNameIx = recbt->devFrames[i].moduleNameIx;
        devFrame.fileNameIx = recbt->devFrames[i].fileNameIx;
        devFrame.lineno = recbt->devFrames[i].lineno;
        RAW_BUF_PUSH_STRUCT(bufptr, &devFrame);
    }

    *endptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
getPackedRecordSectionBacktrace(char *bufptr, uint64_t size, char **endptr,
                                CUmemcheck_record *err)
{
    CCDR_section_header shbt = {0};
    CCDR_section_header_ext_backtrace shextbt = {0};
    uint64_t sectionsize = 0;
    CCIPCresult res = CCIPC_SUCCESS;

    if (!bufptr || !size || !endptr || !err) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    *endptr = bufptr;

    sectionsize = getBacktraceSize(err);

    if (!sectionsize)
        return CCIPC_SUCCESS;

    // Generate the extended section header
    shextbt.btsize  = sectionsize;
    shextbt.startsize = sizeof(CCDR_section_backtrace_start);
    shextbt.hostsize = sizeof(CCDR_section_backtrace_host);
    shextbt.devsize = sizeof(CCDR_section_backtrace_dev);
    shextbt.hostframesize = sizeof(CCDR_section_backtrace_hostFrame);
    shextbt.devframesize = sizeof(CCDR_section_backtrace_devFrame);
    shextbt.dataoffset = sizeof(shextbt);

    // Generate the section header for the error record
    shbt.size = sizeof(shbt) + sizeof(shextbt) + shextbt.btsize;
    shbt.version = CCDR_SH_VERSION;
    shbt.minclient = CCDR_SHBACKTRACE_MINCLIENT;
    shbt.type = CCDR_SHT_BACKTRACE;
    shbt.dataoffset = sizeof(shbt) + sizeof(shextbt);
    shbt.extoffset = sizeof(shbt);

    // Write the section header
    RAW_BUF_PUSH_STRUCT(bufptr, &shbt);

    // Write the section header extension
    RAW_BUF_PUSH_STRUCT(bufptr, &shextbt);

    // Write the actual traces, first the host
    res = getPackedBacktraceHost(bufptr, size, &bufptr, err);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to generate a host backtrace\n");
        return res;
    }

    // Write the device trace
    res = getPackedBacktraceDev(bufptr, size, &bufptr, err);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to generate a device backtrace\n");
        return res;
    }

    *endptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
getPackedRecord_single(CUmemcheck_record *rec,
                       void *buf, uint64_t size,
                       CCIPCendpoint writer, void **endptr,
                       uint32_t *selfid, uint32_t parentid)
{
    char *bufptr = NULL;
    uint64_t sizectr = 0;
    CCDR_header hdr = {0};
    CCDR_header_ext hdr_ext = {0};
    CCIPCresult res = CCIPC_SUCCESS;
    CCDR_header_types htype = CCDR_HT_NONE;

    if (!rec || !buf || !selfid || !endptr) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    if (rec->recordclass == CU_MEMCHECK_RECORD_CLASS_ERROR &&
        rec->cases.error.errortype == CU_MEMCHECK_RECORD_INVALID)
        return CCIPC_SUCCESS;

    if (rec->recordclass == CU_MEMCHECK_RECORD_CLASS_IPC &&
        rec->cases.ipc.type == CU_MEMCHECK_IPC_MSG_INVALID)
        return CCIPC_SUCCESS;

    bufptr = (char*)buf;

    sizectr = getPackedRecordSize_single(rec);
    if (size < sizectr) {
        CCIPC_ERROR_PRINT("Did not allocate enough memory in buffer\n");
        return CCIPC_ERROR_OUT_OF_MEMORY;
    }

    htype = getEndpointOutputHeaderType(writer, rec->recordclass);

    // Generate the header extension
    hdr_ext.recordid = ++recordid;
    if (rec->parent)
        hdr_ext.parentid = parentid;
    hdr_ext.numchildren = rec->numchildren;
    hdr_ext.level = (uint32_t)rec->level;


    // Generate the header
    hdr.size = sizectr;
    hdr.magic = CUDA_MEMCHECK_MAGIC;
    hdr.version = CUDA_MEMCHECK_RECORD_VERSION;
    hdr.minclient = CCDR_MINCLIENT_DEFAULT;
    hdr.headertype = htype;
    hdr.shoffset = sizeof(hdr) + sizeof(hdr_ext);
    hdr.extoffset = sizeof(hdr);

    // Update self id for parent records
    *selfid = recordid;

    // Start writing the records.
    // 1. Write the header.
    RAW_BUF_PUSH_STRUCT(bufptr, &hdr);

    // 2. Write the header extension
    RAW_BUF_PUSH_STRUCT(bufptr, &hdr_ext);

    // Write the string table if needed
    res = getPackedRecordSectionStrtab(bufptr, size, &bufptr, rec);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("String table output failed\n");
        return res;
    }

    if (rec->recordclass == CU_MEMCHECK_RECORD_CLASS_ERROR) {
        // Write the error record
        res = getPackedRecordSectionErrrec(bufptr, size, &bufptr, rec);
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Error record output failed\n");
            return res;
        }
    }
    else if (rec->recordclass == CU_MEMCHECK_RECORD_CLASS_IPC) {
        // Write the IPC message
        res = getPackedRecordSectionIPCrec(bufptr, size, &bufptr, rec);
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Error record output failed\n");
            return res;
        }
    }
    else {
        CCIPC_ERROR_PRINT(("Unknown record class\n"));
        return CCIPC_ERROR_FORMAT_INVALID_RECORD_CLASS;
    }

    // Write the backtrace
    res = getPackedRecordSectionBacktrace(bufptr, size, &bufptr, rec);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Backtrace output failed\n");
        return res;
    }

    // Update the end pointer
    *endptr = (void*)bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
getPackedRecord_r(CUmemcheck_record *err,
                  void *buf, uint64_t size, CCIPCendpoint writer,
                  uint32_t parentid)
{
    CCIPCresult res = CCIPC_SUCCESS;
    uint32_t childcount = 0;
    void *curptr = NULL;
    uint32_t selfid = 0;
    CUmemcheck_record *child = NULL;
    uint64_t child_size = 0;

    if (!err || !buf) {
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    res = getPackedRecord_single(err, buf, size, writer, &curptr, &selfid, parentid);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed at record : %p \n", err);
        return res;
    }

    child_size = (uint64_t)((char*)curptr - (char*)buf);

    childcount = err->numchildren;
    if (!childcount)
        return CCIPC_SUCCESS;

    for (child = err->children[0];
         child <= err->children[childcount - 1];
         ++child) {
        res = getPackedRecord_r(err, curptr, child_size, writer, selfid);
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to write child record\n");
            return res;
        }
    }

    return CCIPC_SUCCESS;
}

static CCIPCresult
getPackedRecord(CUmemcheck_record *err, void *buf, uint64_t size, CCIPCendpoint writer)
{
    // When filling in the top level record, the id parameter is overridden
    return getPackedRecord_r(err, buf, size, writer, 0);
}

CCIPCresult
generateRecord(CUmemcheck_record *err, void *buf, uint64_t size, CCIPCendpoint writer, uint32_t recordVersion)
{
    if (!err || !buf)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    switch (recordVersion) {
    case 9:
        return getPackedRecord(err, buf, size, writer);
        break;
    case 8:
    case 7:
    case 6:
    case 5:
        return writeLegacyRecord_v5(err, buf, size);
        break;
    case 4:
        return writeLegacyRecord_v4(err, buf, size);
        break;
    case 3:
        return writeLegacyRecord_v3(err, buf, size);
        break;
    default:
        return CCIPC_ERROR_FORMAT_INVALID_VERSION;
    }

    return CCIPC_SUCCESS;
}

/* Record reading code */
static CCIPCresult
parseHeaderExtInfo(char *bufstart, uint64_t bufsize,
                   CCDR_header *header,
                   CUmemcheck_record *err,
                   CCIPCreaderProps *readerProps,
                   CCIPCrecordProps *recordProps)
{
    char *phdrext = NULL;
    char *psecstart = NULL;
    CCDR_header_ext headerext = {0};
    size_t extsz = 0;

    if (!bufstart || !bufsize || !header || !err)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    phdrext = bufstart + header->extoffset;
    psecstart = bufstart + header->shoffset;

    if ((phdrext + sizeof(headerext)) <= psecstart)
        extsz = sizeof(headerext);
    else
        /* Do a partial copy */
        extsz = (size_t)((uintptr_t)psecstart - (uintptr_t)phdrext);

    memcpy(&headerext, phdrext, extsz);

    recordProps->payload.recordid = headerext.recordid;
    recordProps->payload.parentid = headerext.parentid;
    err->level = (uint64_t)headerext.level;
    err->numchildren = headerext.numchildren;

    return CCIPC_SUCCESS;
}

static CCIPCresult
parseSectionStrTab(CUmemcheck_record *err, CCDR_section_header *sh, char *pdata, CCIPCreaderProps *readerProps, CCIPCrecordProps *recordProps)
{
    char *str = NULL;
    uint32_t sz = 0;
    uint32_t ix = 0, len = 0;
    CCIPCresult res = CCIPC_SUCCESS;

    if (!err || !sh || !pdata) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    sz = (uint32_t)(sh->size - sizeof(*sh));
    str = pdata;

    for (ix = 0; ix < sz; ++ix) {
        str = pdata + ix;
        if (! *str)
            continue;

        len = (uint32_t)strlen(str);
        res = addStringToErrorRecordByIndex(err, str, ix, 0);
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to add string %s at %u (Error:%u)\n",
                              str, ix, res);
            return res;
        }

        ix += len;
    }

    return CCIPC_SUCCESS;
}

static CCIPCresult
readPackedRecordType_memPrecise(CUmemcheck_record *rec,char *bufptr, uint64_t bufsize)
{
    CUmemcheck_record_type_memPrecise *memrec = NULL;
    CUmemcheck_error_record *err = NULL;

    if (!rec)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;
    memrec = &err->cases.memPrecise;

    memset(memrec, 0, sizeof(*memrec));

    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memPrecise, address);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memPrecise, pc);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memPrecise, size);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memPrecise, write);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memPrecise, blockIdxX);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memPrecise, blockIdxY);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memPrecise, blockIdxZ);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memPrecise, threadIdxX);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memPrecise, threadIdxY);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memPrecise, threadIdxZ);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memPrecise, lineno);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memPrecise, type);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memPrecise, exception);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memPrecise, funcNameIx);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memPrecise, fileNameIx);

    return CCIPC_SUCCESS;
}

static CCIPCresult
readPackedRecordType_memImprecise(CUmemcheck_record *rec,char *bufptr, uint64_t bufsize)
{
    CUmemcheck_record_type_memImprecise *memrec = NULL;
    CUmemcheck_error_record *err = NULL;

    if (!rec)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;
    memrec = &err->cases.memImprecise;

    memset(memrec, 0, sizeof(*memrec));

    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memImprecise, address);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memImprecise, pc);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memImprecise, blockIdxX);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memImprecise, blockIdxY);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memImprecise, blockIdxZ);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memImprecise, threadIdxX);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memImprecise, threadIdxY);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memImprecise, threadIdxZ);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memImprecise, lineno);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memImprecise, exception);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memImprecise, funcNameIx);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memImprecise, fileNameIx);

    return CCIPC_SUCCESS;
}

static CCIPCresult
readPackedRecordType_memLeak(CUmemcheck_record *rec,char *bufptr, uint64_t bufsize)
{
    CUmemcheck_record_type_memLeak *memrec = NULL;
    CUmemcheck_error_record *err = NULL;

    if (!rec)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;
    memrec = &err->cases.memLeak;

    memset(memrec, 0, sizeof(*memrec));

    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memLeak, address);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memLeak, size);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memLeak, flags);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memLeak, nameIx);

    return CCIPC_SUCCESS;
}

static CCIPCresult
readPackedRecordType_driverError(CUmemcheck_record *rec,char *bufptr, uint64_t bufsize)
{
    CUmemcheck_record_type_driverError *memrec = NULL;
    CUmemcheck_error_record *err = NULL;

    if (!rec)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;
    memrec = &err->cases.driverError;

    memset(memrec, 0, sizeof(*memrec));

    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_driverError, error);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_driverError, internal);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_driverError, stringIx);

    return CCIPC_SUCCESS;
}

static CCIPCresult
readPackedRecordType_memApiError(CUmemcheck_record *rec,char *bufptr, uint64_t bufsize)
{
    CUmemcheck_record_type_apiError *memrec = NULL;
    CUmemcheck_error_record *err = NULL;

    if (!rec)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;
    memrec = &err->cases.apiError;

    memset(memrec, 0, sizeof(*memrec));

    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_apiError, apiType);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_apiError, apiResult);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_apiError, contextID);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_apiError, apiCallID);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_apiError, stringIx);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_apiError, errorNameStringIx);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_apiError, errorMsgStringIx);

    return CCIPC_SUCCESS;
}

static CCIPCresult
readPackedRecordType_memSyscall(CUmemcheck_record *rec,char *bufptr, uint64_t bufsize)
{
    CUmemcheck_record_type_memSyscall *memrec = NULL;
    CUmemcheck_error_record *err = NULL;

    if (!rec)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;
    memrec = &err->cases.memSyscall;

    memset(memrec, 0, sizeof(*memrec));

    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memSyscall, type);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memSyscall, blockIdxX);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memSyscall, blockIdxY);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memSyscall, blockIdxZ);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memSyscall, threadIdxX);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memSyscall, threadIdxY);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memSyscall, threadIdxZ);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memSyscall, pc);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memSyscall, lineno);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memSyscall, address);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memSyscall, size);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memSyscall, fileNameIx);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memSyscall, funcNameIx);

    return CCIPC_SUCCESS;
}

static CCIPCresult
readPackedRecordType_shmemHazard(CUmemcheck_record *rec,char *bufptr, uint64_t bufsize)
{
    CUmemcheck_record_type_hazardCommonInfo *memcommon = NULL;
    CUmemcheck_record_type_hazardThreadInfo *memt0 = NULL;
    CUmemcheck_record_type_hazardThreadInfo *memt1 = NULL;
    char *diskcommon = NULL;
    char *diskt0 = NULL;
    char *diskt1 = NULL;
    CCDR_section_header_ext_shmemHazard *shmem = NULL;
    CUmemcheck_error_record *err = NULL;

    if (!rec)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;
    shmem = (CCDR_section_header_ext_shmemHazard*)bufptr;
    diskcommon = bufptr + sizeof(*shmem);
    diskt0 = bufptr + sizeof (*shmem) + shmem->commonsize;
    diskt1 = bufptr + sizeof (*shmem) + shmem->commonsize + shmem->threadinfosize;

    memset(&err->cases.shmemHazard, 0, sizeof(err->cases.shmemHazard));
    memcommon = &err->cases.shmemHazard.common;
    memt0 = &err->cases.shmemHazard.thread0;
    memt1 = &err->cases.shmemHazard.thread1;

    /* Read the common data */
    DISK2MEM(memcommon, diskcommon, shmem->commonsize,
             CCDR_record_type_hazardCommonInfo, gridid);
    DISK2MEM(memcommon, diskcommon, shmem->commonsize,
             CCDR_record_type_hazardCommonInfo, hazardType);
    DISK2MEM(memcommon, diskcommon, shmem->commonsize,
             CCDR_record_type_hazardCommonInfo, address);
    DISK2MEM(memcommon, diskcommon, shmem->commonsize,
             CCDR_record_type_hazardCommonInfo, blockIdxX);
    DISK2MEM(memcommon, diskcommon, shmem->commonsize,
             CCDR_record_type_hazardCommonInfo, blockIdxY);
    DISK2MEM(memcommon, diskcommon, shmem->commonsize,
             CCDR_record_type_hazardCommonInfo, blockIdxZ);
    DISK2MEM(memcommon, diskcommon, shmem->commonsize,
             CCDR_record_type_hazardCommonInfo, readData);
    DISK2MEM(memcommon, diskcommon, shmem->commonsize,
             CCDR_record_type_hazardCommonInfo, writeData);
    DISK2MEM(memcommon, diskcommon, shmem->commonsize,
             CCDR_record_type_hazardCommonInfo, filterType);
    DISK2MEM(memcommon, diskcommon, shmem->commonsize,
             CCDR_record_type_hazardCommonInfo, kernelNameIx);

    /* Read the t0 data */
    DISK2MEM(memt0, diskt0, shmem->threadinfosize,
             CCDR_record_type_hazardThreadInfo, write);
    DISK2MEM(memt0, diskt0, shmem->threadinfosize,
             CCDR_record_type_hazardThreadInfo, threadIdxX);
    DISK2MEM(memt0, diskt0, shmem->threadinfosize,
             CCDR_record_type_hazardThreadInfo, threadIdxY);
    DISK2MEM(memt0, diskt0, shmem->threadinfosize,
             CCDR_record_type_hazardThreadInfo, threadIdxZ);
    DISK2MEM(memt0, diskt0, shmem->threadinfosize,
             CCDR_record_type_hazardThreadInfo, pc);
    DISK2MEM(memt0, diskt0, shmem->threadinfosize,
             CCDR_record_type_hazardThreadInfo, line);
    DISK2MEM(memt0, diskt0, shmem->threadinfosize,
             CCDR_record_type_hazardThreadInfo, fileNameIx);
    DISK2MEM(memt0, diskt0, shmem->threadinfosize,
             CCDR_record_type_hazardThreadInfo, funcNameIx);

    /* Read the t1 data */
    DISK2MEM(memt1, diskt1, shmem->threadinfosize,
             CCDR_record_type_hazardThreadInfo, write);
    DISK2MEM(memt1, diskt1, shmem->threadinfosize,
             CCDR_record_type_hazardThreadInfo, threadIdxX);
    DISK2MEM(memt1, diskt1, shmem->threadinfosize,
             CCDR_record_type_hazardThreadInfo, threadIdxY);
    DISK2MEM(memt1, diskt1, shmem->threadinfosize,
             CCDR_record_type_hazardThreadInfo, threadIdxZ);
    DISK2MEM(memt1, diskt1, shmem->threadinfosize,
             CCDR_record_type_hazardThreadInfo, pc);
    DISK2MEM(memt1, diskt1, shmem->threadinfosize,
             CCDR_record_type_hazardThreadInfo, line);
    DISK2MEM(memt1, diskt1, shmem->threadinfosize,
             CCDR_record_type_hazardThreadInfo, fileNameIx);
    DISK2MEM(memt1, diskt1, shmem->threadinfosize,
             CCDR_record_type_hazardThreadInfo, funcNameIx);

    return CCIPC_SUCCESS;
}

static CCIPCresult
readPackedRecordType_raceAnalysisVertex(CUmemcheck_record_type_raceAnalysisVertex *memvtx, char *diskvtx, uint64_t disksize)
{
    if (!memvtx || !diskvtx)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    DISK2MEM(memvtx, diskvtx, disksize,
             CCDR_record_type_raceAnalysisVertex, pc);
    DISK2MEM(memvtx, diskvtx, disksize,
             CCDR_record_type_raceAnalysisVertex, write);
    DISK2MEM(memvtx, diskvtx, disksize,
             CCDR_record_type_raceAnalysisVertex, funcNameIx);
    DISK2MEM(memvtx, diskvtx, disksize,
             CCDR_record_type_raceAnalysisVertex, fileNameIx);
    DISK2MEM(memvtx, diskvtx, disksize,
             CCDR_record_type_raceAnalysisVertex, line);
    DISK2MEM(memvtx, diskvtx, disksize,
             CCDR_record_type_raceAnalysisVertex, hazardTypeMask);
    DISK2MEM(memvtx, diskvtx, disksize,
             CCDR_record_type_raceAnalysisVertex, weight);
    DISK2MEM(memvtx, diskvtx, disksize,
             CCDR_record_type_raceAnalysisVertex, count);

    return CCIPC_SUCCESS;
}

static CCIPCresult
readPackedRecordType_raceAnalysis(CUmemcheck_record *rec,char *bufptr, uint64_t bufsize)
{
    CUmemcheck_record_type_raceAnalysisCommon *memcommon = NULL;
    CUmemcheck_record_type_raceAnalysisVertex *memsrc = NULL;
    CUmemcheck_record_type_raceAnalysisVertex *memdst = NULL;
    CUmemcheck_record_type_raceAnalysisVertex *destArray = NULL;
    char *diskcommon = NULL;
    char *disksrc = NULL;
    char *diskdst = NULL;
    CCDR_section_header_ext_raceAnalysis *race = NULL;
    size_t vertexSize = 0;
    uint32_t i, destCount = 0;
    CCIPCresult res = CCIPC_SUCCESS;
    CUmemcheck_error_record *err = NULL;

    if (!rec)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;
    race = (CCDR_section_header_ext_raceAnalysis*)bufptr;
    diskcommon = bufptr + race->headerextsize;
    disksrc = bufptr + race->headerextsize + race->commonsize;
    diskdst = bufptr + race->headerextsize + race->commonsize + race->vertexsize;

    vertexSize = race->vertexsize;

    memset(&err->cases.raceAnalysis, 0, sizeof(err->cases.raceAnalysis));
    memcommon = &err->cases.raceAnalysis.common;
    memsrc = &err->cases.raceAnalysis.source;
    memdst = err->cases.raceAnalysis.dests;

    /* Read the common data */
    DISK2MEM(memcommon, diskcommon, race->commonsize,
             CCDR_record_type_raceAnalysisCommon, numDests);

    /* Read the source vertex (always present) */
    res = readPackedRecordType_raceAnalysisVertex(memsrc, disksrc, vertexSize);
    if (res != CCIPC_SUCCESS)
        return res;

    /* Create the dest array */
    destCount = err->cases.raceAnalysis.common.numDests;
    destArray = calloc(destCount, sizeof(*destArray));
    if (!destArray)
        return CCIPC_ERROR_OUT_OF_MEMORY;

    for (i = 0; i < destCount; ++i) {
        memdst = &destArray[i];

        res = readPackedRecordType_raceAnalysisVertex(memdst, diskdst, vertexSize);
        if (res != CCIPC_SUCCESS) {
            free(destArray);
            return res;
        }

        diskdst += vertexSize;
    }

    err->cases.raceAnalysis.dests = destArray;

    return CCIPC_SUCCESS;
}

static CCIPCresult
readPackedRecordType_memAccess(CUmemcheck_record *rec,char *bufptr, uint64_t bufsize)
{
    CUmemcheck_record_type_memAccess *memrec = NULL;
    CUmemcheck_error_record *err = NULL;

    if (!rec)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;
    memrec = &err->cases.memAccess;

    memset(memrec, 0, sizeof(*memrec));

    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memAccess, accessType);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memAccess, errorType);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memAccess, accessAddress);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memAccess, accessSize);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memAccess, errorAddress);

    return CCIPC_SUCCESS;
}

static CCIPCresult
readPackedRecordType_memUnused(CUmemcheck_record *rec,char *bufptr, uint64_t bufsize)
{
    CUmemcheck_record_type_memUnused *memrec = NULL;
    CUmemcheck_error_record *err = NULL;

    if (!rec)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;
    memrec = &err->cases.memUnused;

    memset(memrec, 0, sizeof(*memrec));

    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memUnused, errorType);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memUnused, allocAddress);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memUnused, allocSize);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memUnused, unusedSize);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memUnused, blockAddress);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memUnused, blockSize);

    return CCIPC_SUCCESS;
}

static CCIPCresult
readPackedRecordType_barViolation(CUmemcheck_record *rec,char *bufptr, uint64_t bufsize)
{
    CUmemcheck_record_type_barViolation *memrec = NULL;
    CUmemcheck_error_record *err = NULL;

    if (!rec)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;
    memrec = &err->cases.barViolation;

    memset(memrec, 0, sizeof(*memrec));

    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_barViolation, type);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_barViolation, barIndex);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_barViolation, pc);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_barViolation, funcNameIx);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_barViolation, fileNameIx);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_barViolation, line);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_barViolation, blockIdxX);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_barViolation, blockIdxY);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_barViolation, blockIdxZ);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_barViolation, threadIdxX);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_barViolation, threadIdxY);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_barViolation, threadIdxZ);

    return CCIPC_SUCCESS;
}

static CCIPCresult
readPackedRecordType_memInit(CUmemcheck_record *rec,char *bufptr, uint64_t bufsize)
{
    CUmemcheck_record_type_memInit *memrec = NULL;
    CUmemcheck_error_record *err = NULL;

    if (!rec)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;
    memrec = &err->cases.memInit;

    memset(memrec, 0, sizeof(*memrec));

    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memInit, address);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memInit, pc);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memInit, size);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memInit, blockIdxX);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memInit, blockIdxY);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memInit, blockIdxZ);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memInit, threadIdxX);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memInit, threadIdxY);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memInit, threadIdxZ);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memInit, lineno);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memInit, type);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memInit, accessType);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memInit, funcNameIx);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_record_type_memInit, fileNameIx);

    return CCIPC_SUCCESS;
}

static CCIPCresult
readPackedRecordType_uvmFatalFault(CUmemcheck_record *rec,char *bufptr, uint64_t bufsize)
{
    CUmemcheck_record_type_uvmFatalFault *uvmrec = NULL;
    CUmemcheck_error_record *err = NULL;

    if (!rec)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    err = &rec->cases.error;
    uvmrec = &err->cases.uvmFatalFault;

    memset(uvmrec, 0, sizeof(*uvmrec));

    DISK2MEM(uvmrec, bufptr, bufsize, CCDR_record_type_uvmFatalFault, faultType);
    DISK2MEM(uvmrec, bufptr, bufsize, CCDR_record_type_uvmFatalFault, accessType);
    DISK2MEM(uvmrec, bufptr, bufsize, CCDR_record_type_uvmFatalFault, reason);
    DISK2MEM(uvmrec, bufptr, bufsize, CCDR_record_type_uvmFatalFault, processorIndex);
    DISK2MEM(uvmrec, bufptr, bufsize, CCDR_record_type_uvmFatalFault, address);
    DISK2MEM(uvmrec, bufptr, bufsize, CCDR_record_type_uvmFatalFault, timeStamp);

    return CCIPC_SUCCESS;
}

static CCIPCresult
readPackedRecordTypeError(CUmemcheck_record *err, uint32_t errortype,
                          char *pdata, uint64_t size)
{

    switch (errortype) {
    case CU_MEMCHECK_RECORD_MEM_PRECISE:
        return readPackedRecordType_memPrecise(err, pdata, size);
    case CU_MEMCHECK_RECORD_MEM_IMPRECISE:
        return readPackedRecordType_memImprecise(err, pdata, size);
    case CU_MEMCHECK_RECORD_MEM_LEAK:
        return readPackedRecordType_memLeak(err, pdata, size);
    case CU_MEMCHECK_RECORD_DRV_ERROR:
        /* fallthrough */
    case CU_MEMCHECK_RECORD_DRV_WARNING:
        return readPackedRecordType_driverError(err, pdata, size);
    case CU_MEMCHECK_RECORD_SHMEM_HAZARD:
        return readPackedRecordType_shmemHazard(err, pdata, size);
    case CU_MEMCHECK_RECORD_API_ERROR:
        return readPackedRecordType_memApiError(err, pdata, size);
    case CU_MEMCHECK_RECORD_MEM_SYSCALL:
        return readPackedRecordType_memSyscall(err, pdata, size);
    case CU_MEMCHECK_RECORD_RACE_ANALYSIS:
        return readPackedRecordType_raceAnalysis(err, pdata, size);
    case CU_MEMCHECK_RECORD_MEM_ACCESS:
        return readPackedRecordType_memAccess(err, pdata, size);
    case CU_MEMCHECK_RECORD_MEM_UNUSED:
        return readPackedRecordType_memUnused(err, pdata, size);
    case CU_MEMCHECK_RECORD_BAR_VIOLATION:
        return readPackedRecordType_barViolation(err, pdata, size);
    case CU_MEMCHECK_RECORD_MEM_INIT:
        return readPackedRecordType_memInit(err, pdata, size);
    case CU_MEMCHECK_RECORD_UVM_FATAL_FAULT:
        return readPackedRecordType_uvmFatalFault(err, pdata, size);
    default:
        return CCIPC_ERROR_FORMAT_UNKNOWN_RECORD_TYPE;
    };

    /* Never happens */
    return CCIPC_ERROR_FORMAT_UNKNOWN_RECORD_TYPE;
}

static CCIPCresult
parseSectionErrRec(CUmemcheck_record *err, CCDR_section_header *sh, char *pdata, char *pext, CCIPCreaderProps *readerProps, CCIPCrecordProps *recordProps)
{
    CCDR_section_header_ext_errrec ext = {0};
    size_t extsz = 0;
    CCIPCresult res = CCIPC_SUCCESS;

    if (!err || !sh || !pext || !pdata) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    /* Compute the smallest valid read */
    if (sizeof(ext) <= (size_t)((uintptr_t)pdata - (uintptr_t)pext))
        extsz = sizeof(ext);
    else
        extsz = (size_t)((uintptr_t)pdata - (uintptr_t)pext);

    memcpy(&ext, pext, extsz);

    if (ext.minclient > readerProps->clientVersion) {
        CCIPC_DEBUG_PRINT("Skipping the error as minclient:%u exceeds client version %u\n",
                          ext.minclient, readerProps->clientVersion);
        return CCIPC_SUCCESS;
    }

    if (ext.version > CCDR_SHEXTERR_VERSION_DEFAULT) {
        CCIPC_DEBUG_PRINT("Warning : Potential error version mismatch."
                          "ext.version:%u known:%u\n",
                          ext.version, CCDR_SHEXTERR_VERSION_DEFAULT);
        ++recordProps->header.possibleMismatch;
    }

    if (ext.errortype == CU_MEMCHECK_RECORD_INVALID ||
        ext.errortype >= CU_MEMCHECK_RECORD_SIZE) {
        return CCIPC_ERROR_FORMAT_UNKNOWN_RECORD_TYPE;
    }

    /* Update the error record type */
    err->cases.error.errortype = ext.errortype;

    /* Special handling for some records goes here. */
    res = readPackedRecordTypeError(err, ext.errortype, pdata, ext.recordsize);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to read packed record of type:%u, size:%u bytes (res=%u)\n",
                          ext.errortype, ext.recordsize, res);
        return res;
    }

    return res;
}

static CCIPCresult
readPackedRecordTypeIPC_init(CUmemcheck_record *rec, char *bufptr, uint64_t bufsize)
{
    CUmemcheck_ipc_record *ipc = NULL;
    CCipcmsg_type_init *memrec = NULL;

    if (!rec)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    ipc = &rec->cases.ipc;
    memrec = &ipc->cases.init;

    memset(memrec, 0, sizeof(*memrec));

    DISK2MEM(memrec, bufptr, bufsize, CCDR_ipcmsg_type_init, handshakeVersion);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_ipcmsg_type_init, minVersion);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_ipcmsg_type_init, maxVersion);

    return CCIPC_SUCCESS;
}

static CCIPCresult
readPackedRecordTypeIPC_setOption(CUmemcheck_record *rec, char *bufptr, uint64_t bufsize)
{
    CUmemcheck_ipc_record *ipc = NULL;
    CCipcmsg_type_setOption *memrec = NULL;

    if (!rec)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    ipc = &rec->cases.ipc;
    memrec = &ipc->cases.setOption;

    memset(memrec, 0, sizeof(*memrec));

    DISK2MEM(memrec, bufptr, bufsize, CCDR_ipcmsg_type_setOption, recordVersion);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_ipcmsg_type_setOption, flags);

    return CCIPC_SUCCESS;
}

static CCIPCresult
readPackedRecordTypeIPC_replyDataPid(CCipcmsg_type_replyDataPid *memrec, char *diskrecptr, uint64_t diskrecsize)
{
    if (!memrec)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    memset(memrec, 0, sizeof(*memrec));

    DISK2MEM(memrec, diskrecptr, diskrecsize, CCDR_ipcmsg_type_replyDataPid, pid);

    return CCIPC_SUCCESS;
}

static CCIPCresult
readPackedRecordTypeIPC_replyData(CUmemcheck_record *rec, char *bufptr, uint64_t bufsize)
{
    CUmemcheck_ipc_record *ipc = NULL;
    CCDR_ipcmsg_type_replyDataHeader diskHeader = {0};
    char* replyData = NULL;
    uint64_t replyDataSize = 0;
    CCipcmsg_type_replyData *memrec = NULL;
    CCIPCresult res = CCIPC_SUCCESS;

    if (!rec)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    ipc = &rec->cases.ipc;
    memrec = &ipc->cases.replyData;

    memset(memrec, 0, sizeof(*memrec));

    DISK2MEM(&diskHeader, bufptr, bufsize, CCDR_ipcmsg_type_replyDataHeader, replySize);
    DISK2MEM(&diskHeader, bufptr, bufsize, CCDR_ipcmsg_type_replyDataHeader, dataOffset);
    DISK2MEM(&diskHeader, bufptr, bufsize, CCDR_ipcmsg_type_replyDataHeader, type);

    memrec->type = diskHeader.type;

    if (diskHeader.replySize > bufsize ||
        diskHeader.dataOffset > diskHeader.replySize)
        return CCIPC_ERROR_FORMAT_CORRUPT_RECORD;

    replyData = bufptr + diskHeader.dataOffset;
    replyDataSize = diskHeader.replySize - diskHeader.dataOffset;

    switch (memrec->type) {
    case CU_MEMCHECK_IPC_REPLY_PID:
        res = readPackedRecordTypeIPC_replyDataPid(&memrec->cases.pid, replyData, replyDataSize);
        break;
    default:
        CCIPC_DEBUG_PRINT("Unknown replyData message type: %u\n", (uint32_t)memrec->type);
    }

    return res;
}

static CCIPCresult
readPackedRecordTypeIPC_addFilter(CUmemcheck_record *rec, char *bufptr, uint64_t bufsize)
{
    CUmemcheck_ipc_record *ipc = NULL;
    CCipcmsg_type_addFilter *memrec = NULL;

    if (!rec)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    ipc = &rec->cases.ipc;
    memrec = &ipc->cases.addFilter;

    memset(memrec, 0, sizeof(*memrec));

    DISK2MEM(memrec, bufptr, bufsize, CCDR_ipcmsg_type_addFilter, flags);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_ipcmsg_type_addFilter, entryNameIx);

    return CCIPC_SUCCESS;
}

static CCIPCresult
readPackedRecordTypeIPC_uvmInfo(CUmemcheck_record *rec, char *bufptr, uint64_t bufsize)
{
    CUmemcheck_ipc_record *ipc = NULL;
    CCipcmsg_type_uvmInfo *memrec = NULL;

    if (!rec)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    ipc = &rec->cases.ipc;
    memrec = &ipc->cases.uvmInfo;

    memset(memrec, 0, sizeof(*memrec));

    DISK2MEM(memrec, bufptr, bufsize, CCDR_ipcmsg_type_uvmInfo, version);
    DISK2MEM(memrec, bufptr, bufsize, CCDR_ipcmsg_type_uvmInfo, numHandles);

    return CCIPC_SUCCESS;
}

static CCIPCresult
readPackedRecordTypeIPC(CUmemcheck_record *rec, uint32_t msgtype,
                        char *pdata, uint64_t size)
{

    switch (msgtype) {
    case CU_MEMCHECK_IPC_MSG_INIT:
        return readPackedRecordTypeIPC_init(rec, pdata, size);
    case CU_MEMCHECK_IPC_MSG_INIT_ACK:
        return CCIPC_SUCCESS;
    case CU_MEMCHECK_IPC_MSG_INIT_NAK:
        return CCIPC_SUCCESS;
    case CU_MEMCHECK_IPC_MSG_SET_OPTION:
        return readPackedRecordTypeIPC_setOption(rec, pdata, size);
    case CU_MEMCHECK_IPC_MSG_GET_PID:
        return CCIPC_SUCCESS;
    case CU_MEMCHECK_IPC_MSG_RUN_ASYNC:
        return CCIPC_SUCCESS;
    case CU_MEMCHECK_IPC_MSG_REPLY_DATA:
        return readPackedRecordTypeIPC_replyData(rec, pdata, size);
    case CU_MEMCHECK_IPC_MSG_ADD_FILTER:
        return readPackedRecordTypeIPC_addFilter(rec, pdata, size);
    case CU_MEMCHECK_IPC_MSG_UVM_INFO:
        return readPackedRecordTypeIPC_uvmInfo(rec, pdata, size);
    default:
        return CCIPC_ERROR_FORMAT_UNKNOWN_RECORD_TYPE;
    };

    /* Never happens */
    return CCIPC_ERROR_FORMAT_UNKNOWN_RECORD_TYPE;
}

static CCIPCresult
parseSectionIPCRec(CUmemcheck_record *rec, CCDR_section_header *sh, char *pdata, char *pext, CCIPCreaderProps *readerProps, CCIPCrecordProps *recordProps)
{
    CCDR_section_header_ext_ipcrec ext = {0};
    size_t extsz = 0;
    CCIPCresult res = CCIPC_SUCCESS;

    if (!rec || !sh || !pext || !pdata) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    /* Compute the smallest valid read */
    if (sizeof(ext) <= (size_t)((uintptr_t)pdata - (uintptr_t)pext))
        extsz = sizeof(ext);
    else
        extsz = (size_t)((uintptr_t)pdata - (uintptr_t)pext);

    memcpy(&ext, pext, extsz);

    if (ext.minclient > readerProps->clientVersion) {
        CCIPC_DEBUG_PRINT("Skipping the error as minclient:%u exceeds client version %u\n",
                          ext.minclient, readerProps->clientVersion);
        return CCIPC_SUCCESS;
    }

    if (ext.version > CCDR_SHEXTIPC_VERSION_IPC_REPLY) {
        CCIPC_DEBUG_PRINT("Warning : Potential error version mismatch."
                          "ext.version:%u known:%u\n",
                          ext.version, CCDR_SHEXTIPC_VERSION_IPC_REPLY);
        ++recordProps->header.possibleMismatch;
    }

    if (ext.ipctype == CU_MEMCHECK_IPC_MSG_INVALID ||
        ext.ipctype >= CU_MEMCHECK_IPC_MSG_SIZE) {
        return CCIPC_ERROR_FORMAT_UNKNOWN_RECORD_TYPE;
    }

    /* Update the error record type */
    rec->cases.ipc.type = ext.ipctype;

    /* Special handling for some records goes here. */
    res = readPackedRecordTypeIPC(rec, ext.ipctype, pdata, ext.recordsize);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to read packed IPC record of type:%u, size:%u bytes (res=%u)\n",
                          ext.ipctype, ext.recordsize, res);
        return res;
    }

    return res;
}

static CCIPCresult
parseBacktraceFrameHost(CUmemcheck_backtrace_frame_host *hostFrame, char *buf, uint32_t size)
{
    CCDR_section_backtrace_hostFrame *diskFrame = NULL;

    if (!hostFrame)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    diskFrame = (CCDR_section_backtrace_hostFrame*)buf;

    DISK2MEM(hostFrame, diskFrame, size, CCDR_section_backtrace_hostFrame, flags);
    DISK2MEM(hostFrame, diskFrame, size, CCDR_section_backtrace_hostFrame, depth);
    DISK2MEM(hostFrame, diskFrame, size, CCDR_section_backtrace_hostFrame, addr);
    DISK2MEM(hostFrame, diskFrame, size, CCDR_section_backtrace_hostFrame, funcNameIx);
    DISK2MEM(hostFrame, diskFrame, size, CCDR_section_backtrace_hostFrame, funcOffset);
    DISK2MEM(hostFrame, diskFrame, size, CCDR_section_backtrace_hostFrame, libNameIx);
    DISK2MEM(hostFrame, diskFrame, size, CCDR_section_backtrace_hostFrame, libBaseAddr);
    DISK2MEM(hostFrame, diskFrame, size, CCDR_section_backtrace_hostFrame, fileNameIx);
    DISK2MEM(hostFrame, diskFrame, size, CCDR_section_backtrace_hostFrame, lineno);

    return CCIPC_SUCCESS;
}

static CCIPCresult
parseBacktraceFrameDev(CUmemcheck_backtrace_frame_dev *devFrame, char *buf, uint32_t size)
{
    CCDR_section_backtrace_devFrame *diskFrame = NULL;

    if (!devFrame)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    diskFrame = (CCDR_section_backtrace_devFrame*)buf;

    DISK2MEM(devFrame, diskFrame, size, CCDR_section_backtrace_devFrame, flags);
    DISK2MEM(devFrame, diskFrame, size, CCDR_section_backtrace_devFrame, depth);
    DISK2MEM(devFrame, diskFrame, size, CCDR_section_backtrace_devFrame, addr);
    DISK2MEM(devFrame, diskFrame, size, CCDR_section_backtrace_devFrame, funcNameIx);
    DISK2MEM(devFrame, diskFrame, size, CCDR_section_backtrace_devFrame, funcOffset);
    DISK2MEM(devFrame, diskFrame, size, CCDR_section_backtrace_devFrame, kernelNameIx);
    DISK2MEM(devFrame, diskFrame, size, CCDR_section_backtrace_devFrame, kernelAddr);
    DISK2MEM(devFrame, diskFrame, size, CCDR_section_backtrace_devFrame, moduleNameIx);
    DISK2MEM(devFrame, diskFrame, size, CCDR_section_backtrace_devFrame, fileNameIx);
    DISK2MEM(devFrame, diskFrame, size, CCDR_section_backtrace_devFrame, lineno);

    return CCIPC_SUCCESS;
}

static CCIPCresult
parseOneBacktrace(CUmemcheck_record *err, char **pbufptr, char *secend, CCDR_section_header_ext_backtrace *ext)
{
    char *bufptr = NULL;
    char *btstartptr = NULL;
    CCDR_section_backtrace_start *start = NULL;
    CCDR_section_backtrace_dev *dev = NULL;
    CCDR_section_backtrace_host *host = NULL;
    CUmemcheck_backtrace *mcbt = NULL;
    uint32_t num_frames = 0;
    uint32_t disk_frame_size = 0;
    uint32_t i = 0;
    CCIPCresult res = CCIPC_SUCCESS;

    if (!err || !pbufptr || !ext) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    bufptr = *pbufptr;

    if (!bufptr) {
        CCIPC_ERROR_PRINT("Invalid read location\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    /* Nothing to do here */
    if (bufptr >= secend)
        return CCIPC_SUCCESS;

    /* Read the start size */
    btstartptr = bufptr;
    start = (CCDR_section_backtrace_start*)bufptr;
    bufptr += (size_t)ext->dataoffset;

    if (!start->size)
        return CCIPC_ERROR_FORMAT_INVALID_SECTION_SIZE;

    mcbt = err->backtrace;
    if (!mcbt) {
        CCIPC_ERROR_PRINT("Backtrace missing\n");
        return CCIPC_ERROR_FORMAT_INVALID_BACKTRACE;
    }

    if (start->type == CU_MEMCHECK_BACKTRACE_TYPE_HOST) {
        host = (CCDR_section_backtrace_host*)bufptr;
        /* Nuke the memory copy of the host */
        memset(&mcbt->host, 0, sizeof(mcbt->host));

        /* Copy the host info by field to account for potentially different sizes */
        DISK2MEM(&mcbt->host, host, ext->hostsize, CCDR_section_backtrace_host, threadId);

        /* Setup top level properties */
        mcbt->hostDepth = start->totalDepth;
        mcbt->maxHostDepth = start->maxDepth;

        /* Setup the frame sizing state */
        num_frames = start->totalDepth;
        disk_frame_size = ext->hostframesize;

        /* Allocate the record frame list */
        mcbt->hostFrames = calloc(num_frames, sizeof(*mcbt->hostFrames));
        if (!mcbt->hostFrames)
            return CCIPC_ERROR_OUT_OF_MEMORY;

        /* Skip to start of frame info */
        bufptr = btstartptr + start->frameOffset;
    }
    else if (start->type == CU_MEMCHECK_BACKTRACE_TYPE_DEVICE) {
        dev = (CCDR_section_backtrace_dev*)bufptr;
        /* Nuke the memory copy of the dev */
        memset(&mcbt->dev, 0, sizeof(mcbt->dev));

        /* Copy the host info by field to account for potentially different sizes */
        DISK2MEM(&mcbt->dev, dev, ext->devsize, CCDR_section_backtrace_dev, threadIdxX);
        DISK2MEM(&mcbt->dev, dev, ext->devsize, CCDR_section_backtrace_dev, threadIdxY);
        DISK2MEM(&mcbt->dev, dev, ext->devsize, CCDR_section_backtrace_dev, threadIdxZ);
        DISK2MEM(&mcbt->dev, dev, ext->devsize, CCDR_section_backtrace_dev, blockIdxX);
        DISK2MEM(&mcbt->dev, dev, ext->devsize, CCDR_section_backtrace_dev, blockIdxY);
        DISK2MEM(&mcbt->dev, dev, ext->devsize, CCDR_section_backtrace_dev, blockIdxZ);
        DISK2MEM(&mcbt->dev, dev, ext->devsize, CCDR_section_backtrace_dev, entryKernelNameIx);

        /* Setup top level properties */
        mcbt->devDepth = start->totalDepth;
        mcbt->maxDevDepth = start->maxDepth;

        /* Setup the frame sizing state */
        num_frames = start->totalDepth;
        disk_frame_size = ext->devframesize;

        /* Allocate the record frame list */
        mcbt->devFrames = calloc(num_frames, sizeof(*mcbt->devFrames));
        if (!mcbt->devFrames)
            return CCIPC_ERROR_OUT_OF_MEMORY;

        /* Skip to start of frame info */
        bufptr = btstartptr + start->frameOffset;
    }

    /* Sanity check. Unknown backtrace */
    if (!dev && !host) {
        bufptr += (size_t)start->size;
        *pbufptr = bufptr;
        return CCIPC_SUCCESS;
    }

    /* Consistency checks before starting the frame read */
    if (!disk_frame_size || !num_frames) {
        bufptr += (size_t)start->size;
        *pbufptr = bufptr;
        return CCIPC_ERROR_FORMAT_INVALID_BACKTRACE;
    }

    /* Read all the frames. Handle the increments independently
       as the record sizes may vary between the driver output
       and the struct in the toolkit. */
    for (i = 0; i < num_frames ; ++i) {
        switch (start->type) {
        case CU_MEMCHECK_BACKTRACE_TYPE_HOST:
            res = parseBacktraceFrameHost(&mcbt->hostFrames[i],
                                          bufptr, disk_frame_size);
            break;
        case CU_MEMCHECK_BACKTRACE_TYPE_DEVICE:
            res = parseBacktraceFrameDev(&mcbt->devFrames[i],
                                         bufptr, disk_frame_size);
            break;
        default:
            CCIPC_ERROR_PRINT("Unhandled backtrace type:%u while unwinding frames"
                              "Should have skipped the entire subsection\n",
                              start->type);
            return CCIPC_ERROR_FORMAT_INVALID_BACKTRACE;
        }

        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to unwind frames at %u for type:%u\n",
                              i, start->type);
            return res;
        }
        bufptr += disk_frame_size;
    }

    *pbufptr = bufptr;

    return CCIPC_SUCCESS;
}

static CCIPCresult
parseSectionBacktrace(CUmemcheck_record *err, CCDR_section_header *sh, char *bufend, char *pdata, char *pext, CCIPCreaderProps *readerProps, CCIPCrecordProps *recordProps)
{
    CCDR_section_header_ext_backtrace ext = {0};
    size_t extsz = 0;
    char *btstart = NULL;
    char *btend = NULL;
    CCIPCresult res = CCIPC_SUCCESS;

    if (!err || !sh || !pext || !pdata || !bufend)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    /* Compute the smallest valid read */
    if (sizeof(ext) <= (size_t)((uintptr_t)pdata - (uintptr_t)pext))
        extsz = sizeof(ext);
    else
        extsz = (size_t)((uintptr_t)pdata - (uintptr_t)pext);

    memcpy(&ext, pext, extsz);

    if (!err->backtrace) {
        CCIPC_ERROR_PRINT("Failed to find a backtrace struct\n");
        return CCIPC_ERROR_FORMAT_INVALID_BACKTRACE;
    }

    /* Consistency checks. The following fields can never be 0 */
    if (!ext.btsize         ||
        !ext.startsize      ||
        !ext.hostsize       ||
        !ext.devsize        ||
        !ext.hostframesize  ||
        !ext.devframesize   ||
        !ext.dataoffset      ) {
        CCIPC_ERROR_PRINT("Consistency checks failed on backtrace header\n");
        return CCIPC_ERROR_FORMAT_CORRUPT_SECTION;
    }

    /* If the section size exceeds the end of the record, something is terribly wrong */
    if (pext + ext.btsize >= bufend) {
        CCIPC_ERROR_PRINT("Backtrace size %u exceeds record \n", ext.btsize);
        return CCIPC_ERROR_FORMAT_CORRUPT_RECORD;
    }

    btstart = pext + ext.dataoffset;
    btend = pext + ext.btsize;

    do {
        if (!btstart)
            break;

        /* Any parse failure is fatal (no rewind capability) */
        res = parseOneBacktrace(err, &btstart, btend, &ext);
        if (res !=  CCIPC_SUCCESS)
            return res;
    }
    while (btstart < btend);

    return res;
}

static CCIPCresult
parseSection(char *secstart, char *bufend, CUmemcheck_record *err, char **nextsec, CCIPCreaderProps *readerProps, CCIPCrecordProps *recordProps)
{
    CCDR_section_header *sh = NULL;
    char *pext = NULL;
    char *pdata = NULL;
    uint64_t secsize = 0;
    CCIPCresult res = CCIPC_SUCCESS;

    /* Initialize next section to NULL */
    *nextsec = NULL;

    /* Check if we are at the end of the buffer */
    if (secstart == bufend)
        return CCIPC_SUCCESS;

    /* Early check to see if we can read */
    if (secstart + sizeof(sh) >= bufend) {
        return CCIPC_SUCCESS;
    }

    /* Read the section header */
    sh = (CCDR_section_header*)secstart;

    /* If the section size exceeds the record, something is wrong */
    if (secstart + sh->size > bufend) {
        CCIPC_ERROR_PRINT("Section size exceeds record\n");
        return CCIPC_ERROR_FORMAT_INVALID_SECTION_SIZE;
    }

    /* Set the next section pointer early */
    *nextsec = secstart + sh->size;
    secsize = sh->size;

    /* Consistency check. If size if 0, skip the record */
    if (!secsize) {
        CCIPC_ERROR_PRINT("Section size 0. Error\n");
        return CCIPC_ERROR_FORMAT_INVALID_SECTION_SIZE;
    }

    /* Version checks */
    if (sh->minclient > readerProps->clientVersion) {
        CCIPC_DEBUG_PRINT("Skipping the section as minclient:%u exceeds client version %u\n",
                          sh->minclient, readerProps->clientVersion);
        ++recordProps->payload.skippedSections;
        return CCIPC_SUCCESS;
    }

    if (sh->version > readerProps->clientVersion) {
        /* Warn on a version mismatch */
        CCIPC_DEBUG_PRINT("Warning : Potential mismatch. sh->version:%u client:%u\n",
                          sh->version, readerProps->clientVersion);
        ++recordProps->header.possibleMismatch;
    }

    pext = secstart + sh->extoffset;
    pdata = secstart + sh->dataoffset;

    switch (sh->type) {
    case CCDR_SHT_STRTAB:
        res = parseSectionStrTab(err, sh, pdata, readerProps, recordProps);
        break;
    case CCDR_SHT_ERRREC:
        res = parseSectionErrRec(err, sh, pdata, pext, readerProps, recordProps);
        break;
    case CCDR_SHT_BACKTRACE:
        res = parseSectionBacktrace(err, sh, bufend, pdata, pext, readerProps, recordProps);
        break;
    case CCDR_SHT_IPCREC:
        res = parseSectionIPCRec(err, sh, pdata, pext, readerProps, recordProps);
        break;
    default :
        /* Unknown section. Skip it */
        CCIPC_DEBUG_PRINT("Warning : Skipping unknown section %u\n", sh->type);
        res = CCIPC_SUCCESS;
        break;
    };

    return res;
}

static CCIPCresult
parseSections(char *bufstart, uint64_t bufsize,
              CCDR_header *header,
              CUmemcheck_record *err,
              CCIPCreaderProps *readerProps,
              CCIPCrecordProps *recordProps)
{
    char *psecstart = NULL;
    char *bufend = NULL;
    char *nextsec = NULL;
    CCIPCresult res = CCIPC_SUCCESS;

    psecstart = bufstart + header->shoffset;

    bufend = bufstart + bufsize;
    res = parseSection(psecstart, bufend, err, &nextsec, readerProps, recordProps);
    /* Parse section can fail, hit errors, or force the reader
       to skip the entire record. */
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to parse first section. (Error:%u)\n", res);
        return res;
    }

    ++recordProps->payload.parsedSections;

    while (nextsec) {
        psecstart = nextsec;
        res = parseSection(psecstart, bufend, err, &nextsec, readerProps, recordProps);
        /* Parse section can fail, hit errors, or force the reader
           to skip. */
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to parse section : (Error:%u)\n", res);
            return res;
        }
        ++recordProps->payload.parsedSections;
    };

    return CCIPC_SUCCESS;
}

static uint64_t
getPackedRecordHeaderSize(uint32_t recordVersion)
{
    /* Size of the smallest header. This can never change in size */
    return sizeof(CCDR_header);
}

uint64_t
getRecordReadHeaderSize(CCIPCreaderProps *props)
{
    if (!props) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return 0;
    }

    switch (props->recordVersion) {
    case 9:
        return getPackedRecordHeaderSize(props->recordVersion);
        break;
    default:
        /* Should not happen */
        CCIPC_ERROR_PRINT("Invalid recordVersion to read :%u\n", props->recordVersion);
        return 0;
    }

    return 0;
}

static CCIPCresult
parsePackedRecordHeaderInternal(CCDR_header *header, CCIPCreaderProps *readerProps, CCIPCrecordProps *recordProps)
{
    if (!header || !readerProps || !recordProps) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    /* Check 1 : the size check */
    if (!header->size) {
        CCIPC_ERROR_PRINT("Record is probably corrupt (0 size)\n");
        return CCIPC_ERROR_FORMAT_CORRUPT_RECORD;
    }

    /* At this point, the remaining checks can cause a skip, so the record size
       *must* be populated
    */
    recordProps->header.recordSize  = header->size;
    recordProps->header.headerRecordVersion = header->version;
    recordProps->header.recordClass = getRecordClassFromHeaderType(header->headertype);

    /* CHECK 2 : magic number. Indicates a breaking change to the
       rest of the format. */
    if (header->magic != CUDA_MEMCHECK_MAGIC) {
        CCIPC_ERROR_PRINT("Magic number mismatch! "
                          "Found : 0x%" PRIx64 " Expecting : 0x%" PRIx64 "\n",
                          header->magic, CUDA_MEMCHECK_MAGIC);
        recordProps->header.skipRecord = 1;
        return CCIPC_ERROR_FORMAT_CORRUPT_RECORD;
    }

    /* CHECK 3 : minimum client. Skip the record if the minimum client required
       is newer than the reader */
    if (header->minclient > readerProps->clientVersion) {
        CCIPC_ERROR_PRINT("Record minimum version %u exceeds client version %u\n",
                          header->minclient, readerProps->clientVersion);
        recordProps->header.possibleMismatch = 1;
        recordProps->header.skipRecord = 1;
        return CCIPC_SUCCESS;
    }

    /* CHECK 4 : Complain if the version is newer than expected */
    if (header->version > CUDA_MEMCHECK_RECORD_VERSION) {
        CCIPC_DEBUG_PRINT("Warning: Encountered error record from newer driver."
                          " Record version : %u, known version:%u\n",
                          header->version, CUDA_MEMCHECK_RECORD_VERSION);
        recordProps->header.possibleMismatch = 1;
        /* Not fatal */
    }

    /* CHECK 5 : Skip unknown header types */
    if (header->headertype == CCDR_HT_NONE ||
        header->headertype >= CCDR_HT_SIZE) {
        CCIPC_DEBUG_PRINT("Endpoint %u saw unknown header type : %u\n",
                          readerProps->reader, header->headertype);
        recordProps->header.skipRecord = 1;
        return CCIPC_SUCCESS;
    }

    /* CHECK 6 : Check the intended reader can read this record  */
    if (!canEndpointReadRecord(readerProps->reader, header->headertype)) {
        CCIPC_DEBUG_PRINT("Endpoint %u cannot read header type : %u\n",
                          readerProps->reader, header->headertype);
        recordProps->header.skipRecord = 1;
        return CCIPC_SUCCESS;
    }

    /* All done */
    return CCIPC_SUCCESS;
}

static CCIPCresult
parsePackedRecordHeader(void *buf, uint64_t size, CCIPCreaderProps *readerProps, CCIPCrecordProps *recordProps)
{
    CCIPCresult res = CCIPC_SUCCESS;
    CCDR_header *header = NULL;

    if (!buf || !size || !readerProps || !recordProps) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    /* Clobber the output structs early */
    memset((void*)&recordProps->header, 0, sizeof(recordProps->header));

    if (sizeof(header) > size) {
        /* Did getHeaderSize not get respected ? */
        CCIPC_ERROR_PRINT("Header struct is smaller than buffer\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    header = (CCDR_header*)buf;

    /* Now do all the header checks. */
    res = parsePackedRecordHeaderInternal(header, readerProps, recordProps);

    return res;
}

CCIPCresult
parseHeader(void *buf, uint64_t size, CCIPCreaderProps *readerProps, CCIPCrecordProps *recordProps)
{
    CCIPCresult res = CCIPC_SUCCESS;

    if (!readerProps || !recordProps || !buf || !size) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    switch (readerProps->recordVersion) {
    case 9:
        res = parsePackedRecordHeader(buf, size, readerProps, recordProps);
        break;
    default:
        CCIPC_ERROR_PRINT("Invalid record version %u\n",
                          readerProps->recordVersion);
        res = CCIPC_ERROR_FORMAT_INVALID_VERSION;
        break;
    }

    return res;
}

static CCIPCresult
parsePackedRecord(void *buf, uint64_t size, CCIPCreaderProps *readerProps, CCIPCrecordProps *recordProps, CUmemcheck_record *rec)
{
    CCIPCresult res = CCIPC_SUCCESS;
    CCDR_header *header = NULL;

    if (!readerProps || !recordProps || !buf || !size || !rec) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    header = (CCDR_header*)buf;

    res = parsePackedRecordHeader(buf, size, readerProps, recordProps);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to parse header. (Error:%u)\n", res);
        return res;
    }

    if (size < recordProps->header.recordSize) {
        CCIPC_ERROR_PRINT("Mismatch between given buffer and recsize. "
                          "size : 0x%" PRIx64 " header.recordSize: 0x%" PRIx64 "\n",
                          size, recordProps->header.recordSize);
        return CCIPC_ERROR_FORMAT_CORRUPT_RECORD;
    }

    res = createNewRecord(rec);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to initialize memory record\n");
        return res;
    }

    /* Set the rec class */
    rec->recordclass = recordProps->header.recordClass;

    res = parseHeaderExtInfo(buf, size, header, rec, readerProps, recordProps);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to parse extended header info\n");
        return res;
    }

    res = parseSections(buf, size, header, rec, readerProps, recordProps);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to parse sections. (Error:%u)\n", res);
        return res;
    }

    if (rec->recordclass == CU_MEMCHECK_RECORD_CLASS_ERROR &&
        !rec->cases.error.errortype) {
        CCIPC_DEBUG_PRINT("Error record skipped.\n");
    }

    return CCIPC_SUCCESS;
}

CCIPCresult
parseRecord(void *buf, uint64_t size, CCIPCreaderProps *readerProps, CCIPCrecordProps *recordProps, CUmemcheck_record *rec)
{
    CCIPCresult res = CCIPC_SUCCESS;

    if (!readerProps || !recordProps || !buf || !size || !rec) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    switch (readerProps->recordVersion) {
    case 9:
        res = parsePackedRecord(buf, size, readerProps, recordProps, rec);
        break;
    default:
        CCIPC_ERROR_PRINT("Invalid record version %u\n",
                          readerProps->recordVersion);
        break;
    }

    return res;
}
