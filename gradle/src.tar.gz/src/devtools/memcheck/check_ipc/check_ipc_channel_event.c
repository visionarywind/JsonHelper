/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "check_ipc_channel_event.h"
#include "cuos.h"
#include "cuos_platform.h"
#include "check_ipc.h"
#include "check_ipc_utils.h"
#include "check_ipc_channel.h"
#include <stdio.h>
#include <stdlib.h>

#ifdef _WIN32
#define snprintf _snprintf
#endif

#define MAX_SUFFIX_LEN 16

static CCIPCresult
channelCreateEventName(char **pOut, const char *eventName, CCIPCchannelType type, CCIPCendpoint src, CCIPCendpoint dst)
{
    char *temp = NULL;
    size_t tempLength = 0;
    char *eventPath = NULL;
    size_t eventPathLength = 0;
    CCIPCresult res = CCIPC_SUCCESS;
    uint32_t suffix = 0;

    CCIPC_TRACE_FUNCTION();

    if (!pOut || !eventName) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    /* The event name actually depends on the direction of the channel.
       Receiving channels use the destination as the event name, and sending
       channels use the source. The upshot of this is that both the source
       and destination of a channel will refer to the event by the same name.
     */
    switch (type) {
    case CCIPC_CHANNEL_TYPE_RECEIVE:
        suffix = (uint32_t)dst;
        break;
    case CCIPC_CHANNEL_TYPE_SEND:
        suffix = (uint32_t)src;
        break;
    default:
        CCIPC_ERROR_PRINT("Unknown channel type : %u\n", type);
        res = CCIPC_ERROR_INVALID_CHANNEL_TYPE;
        goto error;
    }

    tempLength = strlen(eventName) + MAX_SUFFIX_LEN;
    temp = (char*)calloc(1, tempLength + 1);
    if (!temp) {
        CCIPC_ERROR_PRINT("Failed to alloc event name");
        return CCIPC_ERROR_OUT_OF_MEMORY;
    }
    snprintf(temp, tempLength + 1, "%s.%u", eventName, suffix);

    /* On linux, actualEventName is prepended with "/tmp" or $TMPDIR,
       on mac, with "com.cuda.",
       on windows, with "Global\".
       The CUOS_ENV_VAR_LENGTH tries to account for this.
     */
    eventPathLength = tempLength + CUOS_ENV_VAR_LENGTH  + 2;
    eventPath = (char*)calloc(1, eventPathLength);
    if (!eventPath) {
        CCIPC_ERROR_PRINT("Failed to alloc eventPath");
        res = CCIPC_ERROR_OUT_OF_MEMORY;
        goto error;
    }

    if (cuosIpcMakeName(eventPath, temp, eventPathLength) != CUOS_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to make the IPC name\n");
        res = CCIPC_ERROR_INVALID_EVENT_NAME;
        goto error;
    }

    /* Cleanup the temp */
    if (temp) {
        free(temp);
        temp = NULL;
    }

    *pOut = eventPath;

    return CCIPC_SUCCESS;

error:

    if (eventPath) {
        free(eventPath);
        eventPath = NULL;
    }

    /* Cleanup the temp */
    if (temp) {
        free(temp);
        temp = NULL;
    }
    return res;
}

CCIPCresult
CCIPCcommonChannelEventIpcDestroy(CCIPCchannel *channel)
{
    CCIPC_TRACE_FUNCTION();

    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    /* Receive channels always create the IPC, and so must tear it down */
    if (channel->type == CCIPC_CHANNEL_TYPE_RECEIVE && channel->eventPath)
        cuosIpcDestroy(channel->eventPath);

    if (channel->eventPath)
        free(channel->eventPath);

    channel->eventPath = NULL;

    return CCIPC_SUCCESS;
}

CCIPCresult
CCIPCcommonChannelEventForceCleanup(const char *eventName, CCIPCendpoint src, CCIPCendpoint dst)
{
    CCIPCresult res = CCIPC_SUCCESS;
    char *eventPath = NULL;

    CCIPC_TRACE_FUNCTION();

    /* Always blindly call with type SEND, as the upper level calls this twice
       with src and dst swapped */
    res = channelCreateEventName(&eventPath, eventName, CCIPC_CHANNEL_TYPE_SEND, src, dst);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Could not create event path for event:%s\n", eventName);
    }

    if (eventPath) {
        CCIPC_DEBUG_PRINT("Cleaning up event at :%s\n", eventPath);
        cuosIpcDestroy(eventPath);
        free(eventPath);
        eventPath = NULL;
    }

    return res;
}

CCIPCresult
CCIPCcommonChannelEventIpcCreate(CCIPCchannel *channel, const char *eventName, CCIPCendpoint src, CCIPCendpoint dst)
{
    CCIPCresult res = CCIPC_SUCCESS;
    char *eventPath = NULL;
    int32_t cuosRet;

    CCIPC_TRACE_FUNCTION();

    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!eventName) {
        CCIPC_ERROR_PRINT("Invalid event name\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    /* Set up the events for the communication. Each party is responsible for
       creating the IPC object that it will wait on. The events themshelves are
       ceated lazily at the first send and the first receive.
       After the front end sends a message, it signals driverEvent, and
       when it wants to receive a message, it waits on frontEvent, and vice
       versa. */

    res = channelCreateEventName(&eventPath, eventName, channel->type, src, dst);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to create channel event name. EventName:%s, type:%u\n",
                          eventName, channel->type);
        return res;
    }

    channel->eventPath = eventPath;
    channel->eventReady = 0;
    channel->forceWakeUp = 0;

    /* At this point, the channel has a valid event name. The event has not been created.
       For receiving channels, go ahead and create the event. This does the equivalent
       of mkfifo on linux and will ensure that a subsequent attempt to open the
       event will not fail.

       Since the event creation is global, the event being created will become visible
       to both the source and the destination.
    */
    if (channel->type == CCIPC_CHANNEL_TYPE_RECEIVE) {
        cuosRet = (int32_t)cuosIpcCreate(eventPath);
        if (cuosRet != CUOS_SUCCESS) {
            CCIPC_ERROR_PRINT("cuosIpcCreate failed. Eventpath:%s", eventPath);
            res = CCIPC_ERROR_FAILED_CREATE_EVENT;
        }
    }

    return res;
}

#if !cuosOsIsWindows()

// common implementation for anything but Windows

CCIPCresult
CCIPCcommonChannelEventCreate(CCIPCchannel *channel)
{
    CCIPCresult res = CCIPC_SUCCESS;
    cuosEventMode_t mode = 0;
    int32_t cuosRet = 0;

    CCIPC_TRACE_FUNCTION();

    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!channel->eventPath) {
        CCIPC_ERROR_PRINT("Channel doesnt have a eventPath. IPCcreate was not called!\n");
        return CCIPC_ERROR_INTERNAL;
    }

    if (channel->type == CCIPC_CHANNEL_TYPE_SEND)
        mode = CUOS_EVENT_SIGNAL_MODE;
    else if (channel->type == CCIPC_CHANNEL_TYPE_RECEIVE)
        mode = CUOS_EVENT_WAIT_MODE;

    cuosRet = (int32_t)cuosEventIpcCreate(&channel->event,
                                          channel->eventPath,
                                          mode);
    if (cuosRet != CUOS_SUCCESS) {
        CCIPC_ERROR_PRINT("Event creation failed. Path = %s, mode = %u (Error:%u)\n",
                          channel->eventPath, mode, cuosRet);
        res = CCIPC_ERROR_FAILED_CREATE_EVENT;
    }

    return res;
}

CCIPCresult
CCIPCcommonChannelEventSignal(CCIPCchannel *channel)
{
    CCIPC_TRACE_FUNCTION();

    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!channel->eventReady) {
        CCIPC_ERROR_PRINT("Channel event not ready !\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    cuosEventSignal(&channel->event);

    return CCIPC_SUCCESS;
}

CCIPCresult
CCIPCcommonChannelEventDestroy(CCIPCchannel *channel)
{
    CCIPC_TRACE_FUNCTION();

    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    cuosEventDestroy(&channel->event);
    return CCIPC_SUCCESS;
}

CCIPCresult
CCIPCcommonChannelEventGetCuosEvent(CCIPCchannel *channel, cuosEvent *pEvent)
{
    CCIPC_TRACE_FUNCTION();

    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!pEvent) {
        CCIPC_ERROR_PRINT("Missing pEvent\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    memcpy(pEvent, &channel->event, sizeof(channel->event));
    return CCIPC_SUCCESS;
}

#else

// common implementation part for windows based on semaphores

CCIPCresult
CCIPCcommonChannelEventCreate(CCIPCchannel *channel)
{
    HANDLE hSemaphore = 0;

    CCIPC_TRACE_FUNCTION();

    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!channel->eventPath) {
        CCIPC_ERROR_PRINT("Channel doesnt have a eventPath. IPCcreate was not called!\n");
        return CCIPC_ERROR_INTERNAL;
    }

    /* Create named, unsignaled semaphore with maximum number allowed signals */
    hSemaphore = CreateSemaphore(NULL, 0, LONG_MAX, channel->eventPath);
    if (!hSemaphore) {
        CCIPC_ERROR_PRINT("Sempahore creation failed. Path = %s, (Error:%d)\n",
                          channel->eventPath, GetLastError());
        return CCIPC_ERROR_FAILED_CREATE_EVENT;
    }

    /* Avoid that cuos accidentally cleans this up */
    channel->event.createdByCuos = 0;
    /* Stick this semaphore in the channel's cuosEvent, so it can wait on it
       along with user-provided events */
    channel->event.hEvent = hSemaphore;

    return CCIPC_SUCCESS;
}

CCIPCresult
CCIPCcommonChannelEventDestroy(CCIPCchannel *channel)
{
    CCIPC_TRACE_FUNCTION();

    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    CloseHandle(channel->event.hEvent);
    return CCIPC_SUCCESS;
}

CCIPCresult
CCIPCcommonChannelEventSignal(CCIPCchannel *channel)
{
    CCIPC_TRACE_FUNCTION();

    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!channel->eventReady) {
        CCIPC_ERROR_PRINT("Channel event not ready !\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    /* Increase semaphore slots by 1 */
    if (ReleaseSemaphore(channel->event.hEvent, 1, NULL) == FALSE) {
        CCIPC_ERROR_PRINT("Failed to release semaphore (error = %d)\n", GetLastError());
        return CCIPC_ERROR_INTERNAL;
    }

    return CCIPC_SUCCESS;
}

CCIPCresult
CCIPCcommonChannelEventGetCuosEvent(CCIPCchannel *channel, cuosEvent *pEvent)
{
    CCIPC_TRACE_FUNCTION();

    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!pEvent) {
        CCIPC_ERROR_PRINT("Missing pEvent\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    pEvent->createdByCuos = channel->event.createdByCuos;
    pEvent->hEvent = channel->event.hEvent;

    return CCIPC_SUCCESS;
}

#endif
