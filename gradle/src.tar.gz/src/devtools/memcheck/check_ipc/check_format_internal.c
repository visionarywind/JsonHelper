/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: check_format_internal.c
 *
 *   Description:
 *      Internal handling of common functions
 *
 ******************************************************************************/
#include "cudamemcheck.h"
#include "cuda_stdint.h"
#include "check_format.h"
#include "check_format_internal.h"
#include "check_ipc_utils.h"
#include "tools_shared_hashmap.h"


/* String tracking functions */
static void addStringToList(CUmemcheck_record_string *strHead, const char *str, uint32_t flags, char **newstr);
static void destroyStringList(CUmemcheck_record_string *strHead);
static CCIPCresult createStringTracker(strTracker **track);
static CCIPCresult destroyStringTracker(strTracker **track);
static CCIPCresult addStringToTracker(strTracker *track, const char *str, uint32_t *index, uint32_t flags);
static const char* getStringByIndex(const strTracker *track, const uint32_t index);
static uint32_t getIndexByString(strTracker *track, const char *str);
static uint32_t getOrAddStringIndex(strTracker *track, const char *str, uint32_t flags);
static CCIPCresult addStringByIndex(strTracker *track, const char *str, uint32_t flags, uint32_t index);

static CCIPCresult
createRecBacktrace(CUmemcheck_backtrace **precbt)
{
    CUmemcheck_backtrace *recbt = NULL;

    if (!precbt) {
        CCIPC_ERROR_PRINT("Invalid backtrace\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    *precbt = NULL;

    recbt = (CUmemcheck_backtrace *)calloc(1, sizeof(*recbt));
    if (!recbt) {
        CCIPC_ERROR_PRINT("Failed to alloc memory\n");
        return CCIPC_ERROR_OUT_OF_MEMORY;
    }

    *precbt = recbt;

    return CCIPC_SUCCESS;
}

static CCIPCresult
destroyRecBacktrace(CUmemcheck_backtrace **precbt)
{
    CUmemcheck_backtrace *recbt = NULL;

    if (!precbt) {
        CCIPC_ERROR_PRINT("Invalid argument\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    recbt = *precbt;
    if (!recbt)
        return CCIPC_SUCCESS;

    if (recbt->hostFrames) {
        free(recbt->hostFrames);
        recbt->hostFrames = NULL;
    }

    if (recbt->devFrames) {
        free(recbt->devFrames);
        recbt->devFrames = NULL;
    }

    free(recbt);

    *precbt = NULL;

    return CCIPC_SUCCESS;
}

static CCIPCresult
createStringTracker(strTracker **ptrack)
{
    CCIPCresult status = CCIPC_SUCCESS;
    strTracker *track = NULL;

    if (!ptrack) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    *ptrack = NULL;

    track = (strTracker *)calloc(1, sizeof(*track));
    if (!track) {
        CCIPC_ERROR_PRINT("Failed to create strTracker\n");
        status = CCIPC_ERROR_OUT_OF_MEMORY;
        goto Error;
    }

    track->strHash = toolsHashMapNew(toolsStringHashFun, toolsStringEqualFun, 16);
    if (!track->strHash) {
        CCIPC_ERROR_PRINT("Failed to create strhash\n");
        status =  CCIPC_ERROR_OUT_OF_MEMORY;
        goto Error;
    }

    track->numHash = toolsHashMapNew(toolsUint32HashFun, toolsUint32EqualFun, 16);
    if (!track->numHash) {
        CCIPC_ERROR_PRINT("Failed to create numhash\n");
        status = CCIPC_ERROR_OUT_OF_MEMORY;
        goto Error;
    }

    track->list = (CUmemcheck_record_string *)calloc(1, sizeof(*track->list));
    if (!track->list) {
        CCIPC_ERROR_PRINT("Failed to create strlist\n");
        status = CCIPC_ERROR_OUT_OF_MEMORY;
        goto Error;
    }

    track->nextIndex = 1;

    *ptrack = track;

    return CCIPC_SUCCESS;

Error:
    if (track) {
        if (track->list) {
            free(track->list);
            track->list = NULL;
        }

        if (track->numHash) {
            (void)toolsHashMapDelete(track->numHash, NULL, NULL);
            track->numHash = NULL;
        }

        if (track->strHash) {
            (void)toolsHashMapDelete(track->strHash, NULL, NULL);
            track->strHash = NULL;
        }

        free(track);
    }
    return status;
}

static CCIPCresult
destroyStringTracker(strTracker **ptrack)
{
    strTracker *track = NULL;

    if (!ptrack) {
        CCIPC_ERROR_PRINT("Invalid argument\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    track = *ptrack;
    if (!track)
        return CCIPC_SUCCESS;

    if (track->numHash) {
        (void)toolsHashMapDelete(track->numHash, NULL, NULL);
        track->numHash = NULL;
    }

    if (track->strHash) {
        (void)toolsHashMapDelete(track->strHash, NULL, NULL);
        track->strHash = NULL;
    }

    if (track->list) {
        destroyStringList(track->list);
        track->list = NULL;
    }

    free(track);
    *ptrack = NULL;

    return CCIPC_SUCCESS;
}

static void
addStringToList(CUmemcheck_record_string *strHead, const char *str, uint32_t flags, char **newstr)
{
    CUmemcheck_record_string* head = NULL;
    uint32_t len = 0;

    if (!str || !newstr)
        return;

    len = (uint32_t)(strlen(str) + 1);
    if (!len)
        return;

    head = strHead;

    while (head->next)
        head = head->next;

    head->next = (CUmemcheck_record_string *)calloc(1, sizeof *head->next);
    if (!head->next)
        return;
    head = head->next;
    head->sz = len;
    head->flags = flags;
    head->str = (char *)calloc(len, sizeof *head->str);
    if (!head->str)
        return;
    strncpy(head->str, str, len);
    *newstr = head->str;
}

static void
destroyStringList(CUmemcheck_record_string *strHead)
{
    CUmemcheck_record_string* head = NULL;
    CUmemcheck_record_string* next = NULL;

    head = strHead;
    for (; head; head = next) {
        next = head->next;
        if (head->str)
            free(head->str);
        free(head);
    }
}

static CCIPCresult
addStringToTracker(strTracker *track, const char *str, uint32_t *index, uint32_t flags)
{
    uint32_t len = 0;
    char *newstr = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;

    if (!track || !index) {
        CCIPC_ERROR_PRINT("Invalid argument\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    // For NULL or empty strings, claim success
    if (!str || !strlen(str)) {
        *index = 0;
        return CCIPC_SUCCESS;
    }

    len = (uint32_t)(strlen(str) + 1);

    if (!track->nextIndex) {
        CCIPC_ERROR_PRINT("Index cannot be 0\n");
        return CCIPC_ERROR_FORMAT_INVALID_NEXT_INDEX;
    }

    addStringToList(track->list, str, flags, &newstr);
    tres = toolsHashMapInsert(track->numHash,
                              tHashMapNumToKey(track->nextIndex),
                              (void*)newstr);
    if (tres != TOOLS_SUCCESS)
        goto fail;

    tres = toolsHashMapInsert(track->strHash, tHashMapPtrToKey(newstr),
                              (void*)(uintptr_t)track->nextIndex);
    if (tres != TOOLS_SUCCESS)
        goto fail;

    *index = track->nextIndex;
    track->nextIndex += len;

    return CCIPC_SUCCESS;

fail:

    return CCIPC_ERROR_FORMAT_FAILED_STRING_INSERT;
}

static CCIPCresult
addStringToTrackerAtIndex(strTracker *track, const char *str, uint32_t index, uint32_t flags)
{
    uint32_t len = 0;
    char *newstr = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;

    if (!track || !index) {
        CCIPC_ERROR_PRINT("Invalid argument\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    // For NULL or empty strings, claim success
    if (!str || !strlen(str)) {
        return CCIPC_SUCCESS;
    }

    len = (uint32_t)(strlen(str) + 1);

    addStringToList(track->list, str, flags, &newstr);
    tres = toolsHashMapInsert(track->numHash,
                              tHashMapNumToKey(index),
                              (void*)newstr);
    if (tres != TOOLS_SUCCESS)
        goto fail;

    tres = toolsHashMapInsert(track->strHash, tHashMapPtrToKey(newstr),
                              (void*)(uintptr_t)index);
    if (tres != TOOLS_SUCCESS)
        goto fail;

    if (index + len > track->nextIndex)
        track->nextIndex = index + len;

    return CCIPC_SUCCESS;

fail:

    return CCIPC_ERROR_FORMAT_FAILED_STRING_INSERT;
}

static const char*
getStringByIndex(const strTracker *track, const uint32_t index)
{
    char *tmp = NULL;

    if (!track) {
        CCIPC_ERROR_PRINT("Invalid argument\n");
        return NULL;
    }

    if (!index)
        return NULL;

    tmp = (char*)toolsHashMapFind(track->numHash, tHashMapNumToKey(index));

    return tmp;
}

static uint32_t
getIndexByString(strTracker *track, const char *str)
{
    uint32_t tmp = 0;

    if (!track)
        return 0;

    if (!str || !strlen(str))
        return 0;

    tmp = (uint32_t)(uintptr_t)toolsHashMapFind(track->strHash, tHashMapPtrToKey(str));
    return tmp;
}

static uint32_t
getOrAddStringIndex(strTracker *track, const char *str, uint32_t flags)
{
    uint32_t ix = 0;
    CCIPCresult res = CCIPC_SUCCESS;

    if (!track)
        return 0;

    if (!str || !strlen(str))
        return 0;

    ix = getIndexByString(track, str);
    if (!ix) {
        res = addStringToTracker(track, str, &ix, flags);
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to add string : %s\n", str);
            return 0;
        }
    }

    return ix;
}

static CCIPCresult
addStringByIndex(strTracker *track, const char *str, uint32_t flags, uint32_t index)
{
    CCIPCresult res = CCIPC_SUCCESS;
    const char *newstr = NULL;

    if (!track)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    /* Adding a NULL/empty string */
    if (!str || !strlen(str))
        return CCIPC_SUCCESS;

    /* Adding a string at index 0 */
    if (!index)
        return CCIPC_SUCCESS;

    newstr = getStringByIndex(track, index);
    if (!newstr) {
        res = addStringToTrackerAtIndex(track, str, index, flags);
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to add string : %s at %u\n", str, index);
            return res;
        }
    }

    return CCIPC_SUCCESS;
}

/** Error record handling **/
CCIPCresult
createNewRecord(CUmemcheck_record *err)
{
    strTracker *tracker = NULL;
    CUmemcheck_backtrace *recbt = NULL;
    CCIPCresult res = CCIPC_SUCCESS;

    if (!err)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    memset(err, 0, sizeof *err);

    res = createStringTracker(&tracker);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to create string tracker\n");
        return res;
    }

    res = createRecBacktrace(&recbt);
    if (res != CCIPC_SUCCESS) {
        if (destroyStringTracker(&tracker) != CCIPC_SUCCESS)
            CCIPC_ERROR_PRINT("Failed to destroy string tracker\n");

        return res;
    }

    err->strings = (void*)tracker;
    err->numchildren = 0;
    err->parent = NULL;
    err->children = NULL;
    err->backtrace = recbt;

    return CCIPC_SUCCESS;
}

uint32_t
createNewErrorRecord(uint32_t type, CUmemcheck_record *rec)
{
    CUmemcheck_error_record *err = NULL;

    if (!rec)
        return 0;

    if (createNewRecord(rec) != CCIPC_SUCCESS)
        return 0;

    rec->recordclass = CU_MEMCHECK_RECORD_CLASS_ERROR;

    err = &rec->cases.error;
    err->errortype = type;

    switch (type) {
    case CU_MEMCHECK_RECORD_MEM_PRECISE:
        err->cases.memPrecise.pc = ~0U;
        break;
    case CU_MEMCHECK_RECORD_MEM_IMPRECISE:
        err->cases.memImprecise.pc = ~0U;
        break;
    case CU_MEMCHECK_RECORD_MEM_LEAK:
        break;
    case CU_MEMCHECK_RECORD_DRV_ERROR:
        break;
    case CU_MEMCHECK_RECORD_SHMEM_HAZARD:
        break;
    case CU_MEMCHECK_RECORD_API_ERROR:
        break;
    case CU_MEMCHECK_RECORD_MEM_SYSCALL:
        err->cases.memSyscall.pc = ~0U;
        break;
    case CU_MEMCHECK_RECORD_RACE_ANALYSIS:
        break;
    case CU_MEMCHECK_RECORD_MEM_ACCESS:
        break;
    case CU_MEMCHECK_RECORD_MEM_UNUSED:
        break;
    case CU_MEMCHECK_RECORD_BAR_VIOLATION:
        err->cases.barViolation.pc = ~0U;
        break;
    case CU_MEMCHECK_RECORD_MEM_INIT:
        err->cases.memInit.pc = ~0U;
        break;
    case CU_MEMCHECK_RECORD_UVM_FATAL_FAULT:
        break;
    case CU_MEMCHECK_RECORD_DRV_WARNING:
        break;
    default:
        return 0;
    };

    return 1;
}

uint32_t
createNewIPCMsgRecord(uint32_t type, CUmemcheck_record *rec)
{
    CUmemcheck_ipc_record *ipc = NULL;

    if (!rec)
        return 0;

    if (createNewRecord(rec) != CCIPC_SUCCESS)
        return 0;

    rec->recordclass = CU_MEMCHECK_RECORD_CLASS_IPC;

    ipc = &rec->cases.ipc;
    ipc->type = type;

    switch (type) {
    case CU_MEMCHECK_IPC_MSG_INIT:
    case CU_MEMCHECK_IPC_MSG_INIT_ACK:
    case CU_MEMCHECK_IPC_MSG_INIT_NAK:
    case CU_MEMCHECK_IPC_MSG_SET_OPTION:
    case CU_MEMCHECK_IPC_MSG_GET_PID:
    case CU_MEMCHECK_IPC_MSG_RUN_ASYNC:
    case CU_MEMCHECK_IPC_MSG_REPLY_DATA:
    case CU_MEMCHECK_IPC_MSG_ADD_FILTER:
    case CU_MEMCHECK_IPC_MSG_UVM_INFO:
        break;
    default:
        return 0;
    };

    return 1;
}

static void
addChildRecord(CUmemcheck_record *parent, CUmemcheck_record *child)
{
    CUmemcheck_record **children = NULL;

    if (!parent || !child)
        return;

    children = (CUmemcheck_record **)calloc(parent->numchildren + 1, sizeof(*children));
    if (!children)
        return;

    if (parent->children) {
        memcpy(children, parent->children, parent->numchildren * sizeof(*children));
        free(parent->children);
        parent->children = NULL;
    }

    parent->children = children;
    child->parent = parent;
}

uint32_t
addStringToErrorRecord(CUmemcheck_record *err, const char *str, uint32_t flags)
{
    strTracker *tracker = NULL;

    if (!err)
        return 0;

    tracker = (strTracker*)err->strings;

    return getOrAddStringIndex(tracker, str, flags);
}

CCIPCresult
addStringToErrorRecordByIndex(CUmemcheck_record *err, const char *str, uint32_t index, uint32_t flags)
{
    strTracker *tracker = NULL;

    if (!err)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    tracker = (strTracker*)err->strings;

    return addStringByIndex(tracker, str, flags, index);
}

const char*
getStringInRecordByIndex(const CUmemcheck_record *err, const uint32_t index)
{
    strTracker *tracker = NULL;

    if (!err)
        return NULL;

    tracker = (strTracker*)err->strings;
    return getStringByIndex(tracker, index);
}

static void
cleanupStrings(CUmemcheck_record *err)
{

    if (!err)
        return;

    destroyStringTracker((strTracker**)&err->strings);
    err->strings = NULL;
}

void
cleanupErrorRecord(CUmemcheck_record *err)
{
    uint32_t childcount = 0;
    CUmemcheck_record *child = NULL;

    cleanupStrings(err);
    destroyRecBacktrace(&err->backtrace);

    err->parent = NULL;

    childcount = err->numchildren;
    if (!childcount)
        return;

    for (child = err->children[0];
         child <= err->children[childcount - 1];
         ++child) {
        cleanupErrorRecord(child);
    }

    err->numchildren = 0;
    free(err->children);
    err->children = NULL;
    return;
}

