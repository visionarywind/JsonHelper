/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: check_ipc.c
 *
 *   Description:
 *       Implementation of IPC
 *
 ******************************************************************************/

#include <stdlib.h>
#include <assert.h>
#include "check_ipc.h"
#include "check_ipc_internal.h"
#include "check_ipc_channel.h"
#include "check_ipc_shm.h"
#include "check_ipc_shm_align.h"
#include "check_ipc_file.h"
#include "check_ipc_uds.h"
#include "check_ipc_wnp.h"
#include "check_ipc_utils.h"

static CCIPCresult CCIPCreceiveWaitReplyData(CCIPChandle *handle, void **pbuf, size_t *size,
                                             cuosEvent **userEvents, uint32_t numUserEvents, int *userEventIndex,
                                             uint32_t timeoutMs, CCIPCackFunctionPointers *ackFunctionPointers,
                                             void *userData);

CCIPCresult CCIPClibraryInitialize(void)
{
    return CCIPC_SUCCESS;
}

CCIPCresult CCIPClibraryFinalize(void)
{
    return CCIPC_SUCCESS;
}

static CCIPCresult
getIAL(CCIPCtype type, CCIPCIAL *ial)
{
    CCIPCresult res = CCIPC_SUCCESS;

    switch (type) {
    case CCIPC_TYPE_SHMEM_ALIGN:
        res = CCIPCshmAlignGetIAL(ial);
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to initialize ShmemAligned IAL\n");
            return res;
        }
        break;
    case CCIPC_TYPE_SHMEM:
        res = CCIPCshmGetIAL(ial);
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to initialize Shmem IAL\n");
            return res;
        }
        break;
    case CCIPC_TYPE_FILE:
        res = CCIPCfileGetIAL(ial);
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to initialize File IAL\n");
            return res;
        }
        break;
    case CCIPC_TYPE_UDS:
        res = CCIPCudsGetIAL(ial);
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to initialize UDS IAL\n");
            return res;
        }
        break;
    case CCIPC_TYPE_WNP:
        res = CCIPCwnpGetIAL(ial);
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to initialize WNP IAL\n");
            return res;
        }
        break;

    default:
        CCIPC_ERROR_PRINT("Invalid IPC type.");
        return CCIPC_ERROR_INVALID_TYPE;
    }
    return CCIPC_SUCCESS;
}

/* Allocate an IPC handle and initialize the sending end. All parties must
   agree on a common name and type.
 */
CCIPCresult
CCIPCcreate(CCIPChandle **phandle, CCIPCendpoint src, CCIPCendpoint dst, CCIPCtype type,
            uint32_t timeoutMs, const char *sendIpcName, const char *recvIpcName,
            const char *eventName)
{
    CCIPChandle *handle = NULL;
    CCIPCresult res = CCIPC_SUCCESS;

    CCIPC_TRACE_FUNCTION();

    if (!phandle || !eventName) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    if (src == dst) {
        CCIPC_ERROR_PRINT("Both endpoints are the same. %u\n", src);
        return CCIPC_ERROR_INVALID_ENDPOINT;
    }

    handle = (CCIPChandle*)calloc(1, sizeof(CCIPChandle));
    if (!handle) {
        CCIPC_ERROR_PRINT("calloc failed");
        return CCIPC_ERROR_OUT_OF_MEMORY;
    }

    handle->timeoutMs = timeoutMs;
    handle->type = type;
    handle->src = src;
    handle->dst = dst;
    cuosInitializeCriticalSection(&handle->mutex);

    handle->type = type;

    res = getIAL(type, &handle->ial);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to create IAL for %u\n", type);
        goto error;
    }

    /* Create Handles based on ial */
    res = handle->ial.handleCreate(handle, sendIpcName, recvIpcName);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to create handle for %u\n", type);
        goto error;
    }

    /* Each party is responsible for initializing the channel it will send
       messages through.
     */
    res = CCIPCchannelInitialize(&handle->channels[CCIPC_CHANNEL_TYPE_RECEIVE],
                                 eventName,
                                 src,
                                 dst,
                                 recvIpcName,
                                 CCIPC_CHANNEL_TYPE_RECEIVE,
                                 handle);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to initialize receive channel\n");
        goto error;
    }

    res = CCIPCchannelInitialize(&handle->channels[CCIPC_CHANNEL_TYPE_SEND],
                                 eventName,
                                 src,
                                 dst,
                                 sendIpcName,
                                 CCIPC_CHANNEL_TYPE_SEND,
                                 handle);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to initialize sending channel\n");
        goto error;
    }

    (*phandle) = handle;
    return CCIPC_SUCCESS;

error:
    if (handle) {
        free(handle);
        handle = NULL;
    }
    return res;
}

/* Deallocate the handle and clean up the receiving end.
 */
CCIPCresult
CCIPCdestroy(CCIPChandle **phandle)
{
    CCIPCresult res = CCIPC_SUCCESS;
    CCIPChandle *handle = NULL;

    CCIPC_TRACE_FUNCTION();

    if (!phandle) {
        CCIPC_ERROR_PRINT("Invalid handle passed to destroy\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    handle = *phandle;

    if (!handle) {
        CCIPC_DEBUG_PRINT("Nothing to destroy\n");
        return CCIPC_SUCCESS;
    }

    res = CCIPCchannelFinalize(&handle->channels[CCIPC_CHANNEL_TYPE_RECEIVE]);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to finalize receive channel. Error:%u\n", res);
    }

    res = CCIPCchannelFinalize(&handle->channels[CCIPC_CHANNEL_TYPE_SEND]);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to finalize send channel. Error:%u\n", res);
    }

    handle->ial.handleDestroy(handle);
    free(handle);
    *phandle = NULL;

    return res;
}

/* Force cleanup on a channel from another party, clean up anything
   This can be called when no IPC handle has been created, and so must
   work by regenerating any items needed.
 */
CCIPCresult
CCIPCforceCleanup(CCIPCtype type, CCIPCendpoint src, CCIPCendpoint dst,
                  const char *sendIpcName, const char *recvIpcName, const char *eventName)
{
    CCIPCresult res = CCIPC_SUCCESS;
    CCIPCIAL ial = {0};

    CCIPC_TRACE_FUNCTION();

    res = getIAL(type, &ial);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to get IAL for type :%u\n", type);
    }

    res = CCIPCchannelForceCleanup(&ial, src, dst, sendIpcName, eventName);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Force cleanup failed for src->dst name:%s. (ressend=%u)\n",
                          sendIpcName, res);
    }

    /* Swap dst and src */
    res = CCIPCchannelForceCleanup(&ial, dst, src, recvIpcName, eventName);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Force cleanup failed for dst->src name:%s (ressend=%u)\n",
                          recvIpcName, res);
    }

    /* Finally, cleanup the top level */
    if (ial.handleForceCleanup) {
        res = ial.handleForceCleanup(sendIpcName, recvIpcName);
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Force cleanup failed for handle send:%s recv:%s\n",
                              sendIpcName, recvIpcName);
        }
    }

    return CCIPC_SUCCESS;
}

/* Send 'size' bytes from a buffer.
 */
CCIPCresult
CCIPCsend(CCIPChandle *handle, void *buf, size_t size)
{
    CCIPCresult res = CCIPC_SUCCESS;

    CCIPC_TRACE_FUNCTION();

    if (!handle) {
        CCIPC_ERROR_PRINT("Invalid handle\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    if (!buf) {
        CCIPC_ERROR_PRINT("Invalid buffer\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    if (size == 0) {
        CCIPC_DEBUG_PRINT("Send size 0. Skipping send.\n");
        return CCIPC_SUCCESS;
    }

    cuosEnterCriticalSection(&handle->mutex);

    res = internalSend(handle, buf, size, CCIPC_MSG_TYPE_DATA);

    cuosLeaveCriticalSection(&handle->mutex);

    return res;
}

/* Send a message, but only returns if the message is been received
   (receiver acknowledges the message).
 */
CCIPCresult
CCIPCsendBlocking(CCIPChandle *handle, void *buf, size_t size)
{
    CCIPC_TRACE_FUNCTION();

    return CCIPCsendBlockingWithDataReply(handle, buf, size, NULL, NULL);
}

/* Send a message, but only returns if the message has been received (receiver acknowledges the message).
   *pDataReply will be set to a pointer to the buffer with the additional reply data contained in the ackowledgement.
   *pDataReply will be set to NULL, when there is no additional reply data in the ackowledgement.
 */
CCIPCresult
CCIPCsendBlockingWithDataReply(CCIPChandle *handle, void *buf, size_t size, void **pDataReply, size_t *pDataReplySize)
{
    const size_t replyMsgHeaderSize = sizeof(uint32_t);
    CCIPCmessageHeader *replyHeader = NULL;
    CCIPCresult res = CCIPC_SUCCESS;
    uint32_t id = 0;
    uint32_t *replyPayload = NULL;
    void *dataReply = NULL;
    size_t dataReplySize = 0;

    CCIPC_TRACE_FUNCTION();

    if (!handle) {
        CCIPC_ERROR_PRINT("Invalid handle\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    if (!buf) {
        CCIPC_ERROR_PRINT("Invalid buffer\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    if (size == 0) {
        CCIPC_DEBUG_PRINT("Send size 0. Skipping send.\n");
        return CCIPC_SUCCESS;
    }

    cuosEnterCriticalSection(&handle->mutex);

    /* Send message of type CCIPC_MSG_TYPE_DATA_ACK and wait for a reply, verify
       that the reply is a proper acknowledgement.
     */
    id = handle->messageCount;
    res = internalSend(handle, buf, size, CCIPC_MSG_TYPE_DATA_ACK);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed in internal send\n");
        goto error;
    }

    /* Receive the ack message */
    res = internalRecv(handle, &replyHeader, (void*)&replyPayload,
                       NULL, 0, NULL, handle->timeoutMs);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed when waiting for ACK\n");
        goto error;
    }

    if (replyHeader->size < replyMsgHeaderSize) {
        CCIPC_ERROR_PRINT("Received invalid message!\n");
        res = CCIPC_ERROR_PROTOCOL;
        goto error;
    }

    /* check received message */
    if ((replyHeader->msgType != CCIPC_MSG_TYPE_ACK && replyHeader->msgType != CCIPC_MSG_TYPE_ACK_DATA) ||
        (*replyPayload) != id) {
        CCIPC_ERROR_PRINT("Received message is not an ACK!\n");
        res = CCIPC_ERROR_PROTOCOL;
        goto error;
    }

    /* copy reply data */
    if (replyHeader->msgType == CCIPC_MSG_TYPE_ACK_DATA &&
        replyHeader->size > replyMsgHeaderSize) {
        dataReplySize = (size_t)(replyHeader->size - replyMsgHeaderSize);

        dataReply = (void*)calloc(dataReplySize, 1);
        if (!dataReply) {
            CCIPC_ERROR_PRINT("Failed to allocate buffer");
            res = CCIPC_ERROR_OUT_OF_MEMORY;
            goto error;
        }

        memcpy(dataReply, (void*)(((char*)replyPayload) + replyMsgHeaderSize), dataReplySize);
    }
    else {
        /* No reply data */
        dataReply = NULL;
        dataReplySize = 0;
    }

    /* set pDataReply pointer */
    if (pDataReply && pDataReplySize) {
        *pDataReply = dataReply;
        *pDataReplySize = dataReplySize;
    }
    else if (dataReply) {
        free(dataReply);
        dataReply = NULL;
        dataReplySize = 0;
    }

error:
    if (replyHeader) {
        free(replyHeader);
        replyHeader = NULL;
    }
    if (replyPayload) {
        free(replyPayload);
        replyPayload = NULL;
    }
    cuosLeaveCriticalSection(&handle->mutex);
    return res;
}

/* Receive message into an allocated buffer and return it. The buffer needs to
   be freed by the user.
 */
CCIPCresult
CCIPCreceive(CCIPChandle *handle, void **pbuf, size_t *size)
{
    CCIPC_TRACE_FUNCTION();

    if (!handle) {
        CCIPC_ERROR_PRINT("Invalid handle\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    if (!pbuf || !size) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    return CCIPCreceiveWait(handle, pbuf, size, NULL, 0, NULL, handle->timeoutMs);
}

/* Receive message into an allocated buffer and return it. The buffer needs to be freed by the user.
   If ackFunctionPointers is set, the functions will be called to prepare acknowledgement data for the received message.
 */
CCIPCresult
CCIPCreceiveReplyData(CCIPChandle *handle, void **pbuf, size_t *size, CCIPCackFunctionPointers *ackFunctionPointers, void *userData)
{
    CCIPC_TRACE_FUNCTION();

    if (!handle) {
        CCIPC_ERROR_PRINT("Invalid handle\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    if (!pbuf || !size) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    return CCIPCreceiveWaitReplyData(handle, pbuf, size, NULL, 0, NULL, handle->timeoutMs, ackFunctionPointers, userData);
}

CCIPCresult
CCIPCreceiveWaitBlocking(CCIPChandle *handle, void **pbuf, size_t *size, cuosEvent **userEvents, uint32_t numUserEvents, int *userEventIndex)
{
    CCIPC_TRACE_FUNCTION();

    if (!handle) {
        CCIPC_ERROR_PRINT("Invalid handle\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    if (!pbuf || !size) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    return CCIPCreceiveWait(handle, pbuf, size, userEvents,
                            numUserEvents, userEventIndex,
                            CUOS_INFINITE_TIMEOUT);
}


CCIPCresult
CCIPCreceiveWait(CCIPChandle *handle, void **pbuf, size_t *size, cuosEvent **userEvents, uint32_t numUserEvents, int *userEventIndex, uint32_t timeoutMs)
{
    CCIPC_TRACE_FUNCTION();

    if (!handle) {
        CCIPC_ERROR_PRINT("Invalid handle\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    if (!pbuf || !size) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    return CCIPCreceiveWaitReplyData(handle, pbuf, size, userEvents,
                                     numUserEvents, userEventIndex,
                                     timeoutMs, NULL, NULL);
}

CCIPCresult
CCIPCsendFd(CCIPChandle *handle, CCIPCfd *fd, uint32_t timeoutMs)
{
    CCIPC_TRACE_FUNCTION();

    if (!handle) {
        CCIPC_ERROR_PRINT("Invalid handle\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    if (!fd) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    return CCIPCchannelSendFd(&handle->channels[CCIPC_CHANNEL_TYPE_SEND], fd, timeoutMs);
}

CCIPCresult
CCIPCreceiveFd(CCIPChandle *handle, CCIPCfd *fd, uint32_t timeoutMs)
{
    CCIPC_TRACE_FUNCTION();

    if (!handle) {
        CCIPC_ERROR_PRINT("Invalid handle\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    if (!fd) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    return CCIPCchannelReceiveFd(&handle->channels[CCIPC_CHANNEL_TYPE_RECEIVE], fd, timeoutMs);
}

/* CCIPCreceiveWaitReplyData()
   Receive a message and send a reply.

    * CCIPC_MSG_TYPE_ACK layout:

      ackBuf:
        -----------------------------------  0
        | Received message id (uint32_t)  |
        |                                 |
        ----------------------------------- sizeof(id) == ackBufSize


    * CCIPC_MSG_TYPE_ACK_DATA layout:

      ackBuf:
        -----------------------------------  0
        | Received message id (uint32_t)  |
        |                                 |
        ----------------------------------- sizeof(id)
        | Reply data                      |
        |                                 |
        |                                 |
        ----------------------------------- ackBufSize

 */
static CCIPCresult
CCIPCreceiveWaitReplyData(CCIPChandle *handle, void **pbuf, size_t *size, cuosEvent **userEvents, uint32_t numUserEvents,
                          int *userEventIndex, uint32_t timeoutMs, CCIPCackFunctionPointers *ackFunctionPointers, void *userData)
{
    CCIPCmessageHeader *header = NULL;
    void *buf = NULL;
    uint32_t id = 0;
    CCIPCresult res = CCIPC_SUCCESS;

    uint32_t correlationId = 0;
    size_t dataReplySize = 0;

    CCIPCmsgType ackMsgType = CCIPC_MSG_TYPE_INVALID;
    void *ackBuf = NULL;
    size_t ackBufSize = 0;

    CCIPC_TRACE_FUNCTION();

    if (!handle) {
        CCIPC_ERROR_PRINT("Invalid handle\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    if (!pbuf || !size) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    if (ackFunctionPointers &&
        (!ackFunctionPointers->getAckDataSize || !ackFunctionPointers->writeAckDataBuffer)) {
        CCIPC_ERROR_PRINT("Invalid getAckDataSize/writeAckDataBuffer\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    cuosEnterCriticalSection(&handle->mutex);

    /* Receive the message */
    res = internalRecv(handle, &header, &buf, userEvents, numUserEvents,
                       userEventIndex, timeoutMs);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed in internal receive\n");
        goto error;
    }

    *size = (size_t)header->size;
    *pbuf = buf;

    /* Send an acknowledgement if needed. */
    if (header->msgType == CCIPC_MSG_TYPE_DATA_ACK) {
        id = header->id;
        ackMsgType = CCIPC_MSG_TYPE_ACK;

        /* determine whether a reply data will also be included */
        if (ackFunctionPointers) {
            res = ackFunctionPointers->getAckDataSize(handle, *pbuf, *size, userData, &correlationId, &dataReplySize);
            if (res != CCIPC_SUCCESS) {
                CCIPC_ERROR_PRINT("SetAckReplyData callback failed\n");
                goto error;
            }

            if (dataReplySize) {
                if (dataReplySize + sizeof(id) <= dataReplySize) {
                    CCIPC_ERROR_PRINT("Invalid dataReplySize\n");
                    res = CCIPC_ERROR_INVALID_ARGUMENTS;
                    goto error;
                }

                ackMsgType = CCIPC_MSG_TYPE_ACK_DATA;
            }
        }

        /* write acknowledgement buffer */
        if (ackMsgType == CCIPC_MSG_TYPE_ACK) {
            ackBuf = &id;
            ackBufSize = sizeof(id);
        }
        else if (ackMsgType == CCIPC_MSG_TYPE_ACK_DATA) {
            ackBufSize = dataReplySize + sizeof(id);
            ackBuf = (void*)calloc(ackBufSize, 1);
            if (!ackBuf) {
                CCIPC_ERROR_PRINT("Failed to allocate buffer");
                res = CCIPC_ERROR_OUT_OF_MEMORY;
                goto error;
            }

            /* write id */
            *((uint32_t*)ackBuf) = id;

            /* write data */
            res = ackFunctionPointers->writeAckDataBuffer((void*)(((char*)ackBuf) + sizeof(id)),
                                                          dataReplySize, userData, correlationId);
            if (res != CCIPC_SUCCESS) {
                CCIPC_ERROR_PRINT("WriteAckBuffer callback failed\n");
                goto error;
            }
        }

        /* Send an acknowledgement */
        res = internalSend(handle, ackBuf, ackBufSize, ackMsgType);
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Error while sending an acknowledgement\n");
            goto error;
        }
    }

error:
    cuosLeaveCriticalSection(&handle->mutex);

    if (header) {
        free(header);
        header = NULL;
    }

    if (res != CCIPC_SUCCESS && buf) {
        free(buf);
        buf = NULL;
        *pbuf = NULL;
        *size = 0;
    }

    if (ackMsgType == CCIPC_MSG_TYPE_ACK_DATA && ackBuf) {
        free(ackBuf);
        ackBuf = NULL;
    }

    return res;
}

/* Internal send loop
    Loop over channel send until size bytes are all sent
 */
static CCIPCresult
internalSendLoop(CCIPCchannel *channel, void* buf, size_t size, uint32_t timeoutMs)
{
    size_t remainingBytes = 0;
    size_t sentBytes = 0;
    char *curptr = NULL;
    CCIPCresult res = CCIPC_SUCCESS;

    CCIPC_TRACE_FUNCTION();

    /* Setup the pointers */
    curptr = (char*)buf;
    remainingBytes = size;

    while (remainingBytes > 0) {
        sentBytes = 0;

        res = CCIPCchannelSend(channel,
                               (void*)curptr,
                               remainingBytes,
                               &sentBytes,
                               timeoutMs);
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to send data header\n");
            return res;
        }

        if (sentBytes > remainingBytes) {
            CCIPC_ERROR_PRINT("Sent more bytes(%u) than expected(%u)\n",
                              sentBytes, remainingBytes);
            return CCIPC_ERROR_PROTOCOL;
        }

        remainingBytes -= sentBytes;
        curptr += sentBytes;
    }

    return res;
}

/* Help routine for sending messages. Takes a buffer, add a message header to
   it, and send it through the appropriate channel.
 */
static CCIPCresult
internalSend(CCIPChandle *handle, void *buf, size_t size, CCIPCmsgType msgType)
{
    CCIPCresult res = CCIPC_SUCCESS;
    CCIPCmessageHeader header = {0};

    CCIPC_TRACE_FUNCTION();

    /* Setup the header */
    header.id = handle->messageCount++; /* Increment protected by lock */
    header.size = size;
    header.msgType = msgType;

    /* First Send the header */
    res = internalSendLoop(&handle->channels[CCIPC_CHANNEL_TYPE_SEND],
                           &header, sizeof(header),
                           handle->timeoutMs);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to send header\n");
        return res;
    }

    /* Now send the body */
    res = internalSendLoop(&handle->channels[CCIPC_CHANNEL_TYPE_SEND],
                           buf,
                           size,
                           handle->timeoutMs);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to send body\n");
        return res;
    }

    return res;
}

/* Internal receive loop
    Loop over receive until at least size bytes are read from the channel
 */
static CCIPCresult
internalRecvLoop(CCIPCchannel *channel, void *buf, size_t size,
                 cuosEvent **userEvents, uint32_t numUserEvents,
                 int *userEventIndex, uint32_t timeoutMs)
{
    size_t recvBytes = 0;
    char *curptr = NULL;
    size_t remainingBytes = 0;
    CCIPCresult res = CCIPC_SUCCESS;

    curptr = (char*)buf;
    remainingBytes = size;

    while (remainingBytes > 0) {
        recvBytes = 0;

        res = CCIPCchannelReceive(channel,
                                  (void*)curptr,
                                  remainingBytes,
                                  &recvBytes,
                                  timeoutMs,
                                  userEvents,
                                  numUserEvents,
                                  userEventIndex);
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Error in channel receive loop\n");
            return res;
        }

        if (recvBytes > remainingBytes) {
            CCIPC_ERROR_PRINT("Received more bytes (%u) than expected(%u)\n",
                              recvBytes, remainingBytes);
            return CCIPC_ERROR_PROTOCOL;
        }

        remainingBytes -= recvBytes;
        curptr = curptr + recvBytes;
    }

    return res;
}

static CCIPCresult
internalRecv(CCIPChandle *handle, CCIPCmessageHeader **pHeader, void **pBuf,
             cuosEvent **userEvents, uint32_t numUserEvents,
             int *userEventIndex, uint32_t timeoutMs)
{
    CCIPCmessageHeader *header = NULL;
    void *buf = NULL;
    CCIPCresult res = CCIPC_SUCCESS;
    char *curptr = NULL;
    size_t remainingBytes = 0;

    header = (CCIPCmessageHeader*)calloc(1, sizeof(*header));
    if (!header) {
        CCIPC_ERROR_PRINT("Failed to allocate header\n");
        return CCIPC_ERROR_OUT_OF_MEMORY;
    }

    /* 2 Phase receive. First receive the header.
       Then receive as many bytes as needed for the body
     */

    /* Initialize the buffer pointer and size */
    curptr = (char*)header;
    remainingBytes = sizeof(*header);

    res = internalRecvLoop(&handle->channels[CCIPC_CHANNEL_TYPE_RECEIVE],
                           curptr,
                           remainingBytes,
                           userEvents,
                           numUserEvents,
                           userEventIndex,
                           timeoutMs);
    if (res != CCIPC_SUCCESS) {
        free(header);
        CCIPC_ERROR_PRINT("Failed to receive rest of header\n");
        return res;
    }

    /* Create the buffer */
    buf = (void*)calloc(1, (size_t)header->size);
    if (!buf) {
        free(header);
        CCIPC_ERROR_PRINT("Failed to allocate buffer");
        return CCIPC_ERROR_OUT_OF_MEMORY;
    }

    /* Go into the receive loop */
    res = internalRecvLoop(&handle->channels[CCIPC_CHANNEL_TYPE_RECEIVE],
                           buf,
                           (size_t)header->size,
                           NULL,
                           0,
                           NULL,
                           timeoutMs);
    if (res != CCIPC_SUCCESS) {
        free(header);
        free(buf);
        CCIPC_ERROR_PRINT("Failed to receive rest of header\n");
        return res;
    }

    *pBuf = buf;
    *pHeader = header;

    return CCIPC_SUCCESS;
}
