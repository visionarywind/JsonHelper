/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: check_ipc_file.c
 *
 *   Description:
 *       Implementation of IPC using files
 *
 ******************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include "cuos.h"
#include "cuda_stdint.h"
#include "check_ipc.h"
#include "check_ipc_file.h"
#include "check_ipc_utils.h"
#include "check_ipc_channel_event.h"

#define TIME_INCREMENT 250

typedef struct CCIPCfileChannel_st CCIPCfileChannel;

typedef enum {
    CCIPC_FILE_STATE_NONE = 0,
    CCIPC_FILE_STATE_ERROR,
    CCIPC_FILE_STATE_CLOSED,
    CCIPC_FILE_STATE_OPEN
} CCIPCfileState;

struct CCIPCfileChannel_st {
    FILE *file;
    char *name;
    char mode[6];
    CCIPCfileState state;
};

/* Forward declaration */
static CCIPCresult CCIPCfileChannelFinalize(void *implementation);

static CCIPCresult
CCIPCfileHandleCreate(CCIPChandle *handle, const char *sendIpcName, const char *recvIpcName)
{
    CCIPC_TRACE_FUNCTION();
    /* Do nothing */
    return CCIPC_SUCCESS;
}

static CCIPCresult
CCIPCfileHandleForceCleanup(const char *sendIpcName, const char *recvIpcName)
{
    CCIPC_TRACE_FUNCTION();
    /* Do nothing */
    return CCIPC_SUCCESS;
}

/* CCIPCfileHandleDestroy
 */
static CCIPCresult
CCIPCfileHandleDestroy(CCIPChandle *handle)
{
    CCIPC_TRACE_FUNCTION();
    /* Do nothing */
    return CCIPC_SUCCESS;
}

/* CCIPCfileChannelCreate
*/
static CCIPCresult
CCIPCfileChannelCreate(CCIPCchannel *channel, const char *ipcName)
{
    CCIPCfileChannel *fileInfo = NULL;
    char *fileName = NULL;
    size_t fileNameLen = 0;
    CCIPCresult res = CCIPC_SUCCESS;
    const char writeMode[3] = "wb";
    const char readMode[3]  = "rb";

    CCIPC_TRACE_FUNCTION();

    /* Sanity checks */
    if (!channel || !ipcName || !strlen(ipcName)) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    if (channel->implementation) {
        CCIPC_DEBUG_PRINT("Channel implementation already initialized\n");
        return CCIPC_SUCCESS;
    }

    /* Allocate the internal structures */
    fileNameLen = strlen(ipcName) + 1;

    fileName = calloc(fileNameLen, sizeof(*fileName));
    if (!fileName) {
        CCIPC_ERROR_PRINT("Out of memory\n");
        res = CCIPC_ERROR_OUT_OF_MEMORY;
        goto error;
    }

    /* Copy the fileName from the input */
    memcpy(fileName, ipcName, fileNameLen);

    fileInfo = calloc(1, sizeof(*fileInfo));
    if (!fileInfo) {
        CCIPC_ERROR_PRINT("Out of memory\n");
        res = CCIPC_ERROR_OUT_OF_MEMORY;
        goto error;
    }

    /* Setup the internal handle data */
    fileInfo->name  = fileName;
    if (channel->type == CCIPC_CHANNEL_TYPE_SEND)
        memcpy(fileInfo->mode, writeMode, sizeof(writeMode));
    else
        memcpy(fileInfo->mode, readMode, sizeof(readMode));

    fileInfo->state = CCIPC_FILE_STATE_CLOSED;

    /* Everything succeeded, assign the channel */
    channel->implementation = (void*)fileInfo;

    CCIPC_DEBUG_PRINT("Successfully initialized channel %u for type FILE (%s)\n",
                      channel->type, fileName);

    return res;

error:
    if (fileName) {
        free(fileName);
        fileName = NULL;
    }

    /* Intentional dead-logic for maintenance */
    if (fileInfo) {
        free(fileInfo);
        fileInfo = NULL;
    }

    return res;
}

static CCIPCresult
CCIPCfileChannelDestroy(CCIPCchannel *channel)
{
    CCIPCresult ipcres = CCIPC_SUCCESS;
    CCIPCfileChannel *fileInfo = NULL;

    CCIPC_TRACE_FUNCTION();

    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!channel->implementation) {
        CCIPC_DEBUG_PRINT("Channel already free\n");
        return CCIPC_SUCCESS;
    }

    fileInfo = (CCIPCfileChannel*)channel->implementation;

    ipcres = CCIPCfileChannelFinalize(channel->implementation);
    if (ipcres != CCIPC_SUCCESS) {
        CCIPC_DEBUG_PRINT("Failed to finalize channel. Marching on\n");
        ipcres = CCIPC_SUCCESS;
    }

    /* Free the structures */
    if (fileInfo->name) {
        free(fileInfo->name);
        fileInfo->name = NULL;
    }

    free(fileInfo);
    fileInfo = NULL;

    channel->implementation = NULL;
    return CCIPC_SUCCESS;
}

static CCIPCresult
CCIPCfileChannelForceCleanup(const char *ipcName)
{
    int ret = 0;

    CCIPC_TRACE_FUNCTION();

    if (!ipcName)
        return CCIPC_SUCCESS;

    ret = cuosRm(ipcName);

    if (ret)
        return CCIPC_ERROR_FAILED_FORCE_CLEANUP;

    return CCIPC_SUCCESS;
}

/* CCIPCfileChannelInitialize
*/
static CCIPCresult
CCIPCfileChannelInitialize(void *implementation, const char *name)
{
    CCIPCfileChannel *fileInfo = NULL;

    CCIPC_TRACE_FUNCTION();

    if (!implementation) {
        CCIPC_ERROR_PRINT("Invalid channel handle\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    fileInfo = (CCIPCfileChannel*)implementation;

    if (fileInfo->state != CCIPC_FILE_STATE_CLOSED) {
        CCIPC_ERROR_PRINT("File state unexpected : %u\n",
                          fileInfo->state);
        fileInfo->state = CCIPC_FILE_STATE_ERROR;
        return CCIPC_ERROR_PROTOCOL;
    }

    /* Try to open the file  */
    fileInfo->file = fopen(fileInfo->name, fileInfo->mode);
    if (!fileInfo->file) {
        CCIPC_ERROR_PRINT("Failed to open file :%s in mode:%s\n",
                          fileInfo->name, fileInfo->mode);
        fileInfo->state = CCIPC_FILE_STATE_ERROR;
        return CCIPC_ERROR_PROTOCOL;
    }

    fileInfo->state = CCIPC_FILE_STATE_OPEN;

    return CCIPC_SUCCESS;
}

/* CCIPCfileChannelFinalize
    This is called by the IAL to finalize a channel.
*/
static CCIPCresult
CCIPCfileChannelFinalize(void *implementation)
{
    CCIPCfileChannel *fileInfo = NULL;

    if (!implementation) {
        CCIPC_ERROR_PRINT("Invalid channel handle\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    fileInfo = (CCIPCfileChannel*)implementation;

    if (fileInfo->state != CCIPC_FILE_STATE_OPEN) {
        CCIPC_DEBUG_PRINT("File state not open : %u\n",
                          fileInfo->state);
        return CCIPC_SUCCESS;
    }

    if (fileInfo->file) {
        /* Flush out any pending writes */
        fflush(fileInfo->file);
        fclose(fileInfo->file);
        fileInfo->file = NULL;
    }

    fileInfo->state = CCIPC_FILE_STATE_CLOSED;

    return CCIPC_SUCCESS;
}

/* CCIPCfileChannelRead
*/
static CCIPCresult
CCIPCfileChannelRead(void *implementation, void *buf, size_t bufSize, size_t *readSize, uint32_t timeoutMs)
{
    CCIPCfileChannel *fileInfo = NULL;
    cuosTimer timer;
    size_t read = 0;
    uint32_t timeIncrement = TIME_INCREMENT;
    CCIPCresult ipcres = CCIPC_SUCCESS;

    CCIPC_TRACE_FUNCTION();

    /* Some initial checks */
    if (!implementation) {
        CCIPC_ERROR_PRINT("Invalid channel handle\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!buf || !readSize) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    fileInfo = (CCIPCfileChannel*)implementation;
    if (fileInfo->state != CCIPC_FILE_STATE_OPEN || !fileInfo->file) {
        CCIPC_DEBUG_PRINT("File handle missing. Doing late init of receiver\n");
        ipcres = CCIPCfileChannelInitialize((void*)fileInfo, NULL);
        if (ipcres != CCIPC_SUCCESS || !fileInfo->file) {
            CCIPC_ERROR_PRINT("File is not valid.\n");
            return CCIPC_ERROR_PROTOCOL;
        }
    }

    *readSize = 0;

    /* Keep trying to read the element, only break out on error */
    cuosResetTimer(&timer);

    for (; cuosGetTimer(&timer) < timeoutMs;) {
        read = fread(buf, bufSize, 1, fileInfo->file);
        if (read == 1)
            break;

        if (ferror(fileInfo->file)) {
            CCIPC_ERROR_PRINT("Error %u when reading file :%s\n",
                              ferror(fileInfo->file), fileInfo->name);
            return CCIPC_ERROR_PROTOCOL;
        }

        cuosSleep(timeIncrement);
    }

    if (cuosGetTimer(&timer) > timeoutMs) {
        CCIPC_ERROR_PRINT("Timeout  in reader. Waited for %u ms\n",
                          timeoutMs);
        return CCIPC_ERROR_TIMEOUT;
    }

    if (!read) {
        CCIPC_ERROR_PRINT("Failed to read message. Unknown reason\n");
        return CCIPC_ERROR_PROTOCOL;
    }

    *readSize = bufSize;

    return CCIPC_SUCCESS;
}

static CCIPCresult
CCIPCfileChannelWrite(void *implementation, void *buf, size_t bufSize, size_t *writeSize, uint32_t timeoutMs)
{
    CCIPCfileChannel *fileInfo = NULL;
    cuosTimer timer;
    size_t write = 0;
    uint32_t timeIncrement = TIME_INCREMENT;

    CCIPC_TRACE_FUNCTION();

    /* Some initial checks */
    if (!implementation) {
        CCIPC_ERROR_PRINT("Invalid channel handle\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!buf || !writeSize) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    fileInfo = (CCIPCfileChannel*)implementation;
    if (!fileInfo->file) {
        CCIPC_ERROR_PRINT("File is not valid.\n");
        return CCIPC_ERROR_PROTOCOL;
    }

    *writeSize = 0;

    /* Keep trying to write the element, only break out on error */
    cuosResetTimer(&timer);

    for (; cuosGetTimer(&timer) < timeoutMs;) {
        write = fwrite(buf, bufSize, 1, fileInfo->file);
        if (write == 1)
            break;

        if (ferror(fileInfo->file)) {
            CCIPC_ERROR_PRINT("Error %u when writing file :%s\n",
                              ferror(fileInfo->file), fileInfo->name);
            return CCIPC_ERROR_PROTOCOL;
        }

        cuosSleep(timeIncrement);
    }

    if (cuosGetTimer(&timer) > timeoutMs) {
        CCIPC_ERROR_PRINT("Timeout  in writer. Waited for %u ms\n",
                          timeoutMs);
        return CCIPC_ERROR_TIMEOUT;
    }

    if (!write) {
        CCIPC_ERROR_PRINT("Failed to write message. Unknown reason\n");
        return CCIPC_ERROR_PROTOCOL;
    }

    /* The write was successful. Flush it */
    if (fflush(fileInfo->file) != 0) {
        CCIPC_ERROR_PRINT("Failed to flush message\n");
        return CCIPC_ERROR_PROTOCOL;
    }

    *writeSize = bufSize;

    return CCIPC_SUCCESS;
}

CCIPCresult
CCIPCfileGetIAL(CCIPCIAL *ial)
{
    if (!ial) {
        CCIPC_ERROR_PRINT("Invalid IAL pointer\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    ial->handleCreate           = CCIPCfileHandleCreate;
    ial->handleDestroy          = CCIPCfileHandleDestroy;
    ial->handleForceCleanup     = CCIPCfileHandleForceCleanup;
    ial->channelCreate          = CCIPCfileChannelCreate;
    ial->channelDestroy         = CCIPCfileChannelDestroy;
    ial->channelInitialize      = CCIPCfileChannelInitialize;
    ial->channelFinalize        = CCIPCfileChannelFinalize;
    ial->channelRead            = CCIPCfileChannelRead;
    ial->channelWrite           = CCIPCfileChannelWrite;
    ial->channelForceCleanup    = CCIPCfileChannelForceCleanup;

    /* Use the standard channel events */
    ial->channelEventCreate     = CCIPCcommonChannelEventCreate;
    ial->channelEventSignal     = CCIPCcommonChannelEventSignal;
    ial->channelEventDestroy    = CCIPCcommonChannelEventDestroy;
    ial->channelEventIpcCreate  = CCIPCcommonChannelEventIpcCreate;
    ial->channelEventIpcDestroy = CCIPCcommonChannelEventIpcDestroy;
    ial->channelEventForceCleanup = CCIPCcommonChannelEventForceCleanup;
    ial->channelEventGetCuosEvent = CCIPCcommonChannelEventGetCuosEvent;

    CCIPC_DEBUG_PRINT("File IAL created\n");

    return CCIPC_SUCCESS;
}
