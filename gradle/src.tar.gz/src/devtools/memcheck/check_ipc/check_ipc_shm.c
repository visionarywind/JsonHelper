/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: check_ipc_shm.c
 *
 *   Description:
 *       Implementation of IPC using shared memory
 *
 ******************************************************************************/

/* Implementation of IPC using shared memory

   A piece of shared memory is created and divided into channels (circular
   buffers). Within a channel, we store variables readOffset and writeOffset,
   which keep track of the offset which the next message is to be read from or
   write to. Messages can be of variable size and are packed. Each message has
   an internal header in which we store the status and the size of the message.
   A message can be in state EMPTY = 0, WRITING, COMPLETE and READING.

   When trying to read a message, the reader goes to the memory location
   indexed by readOffset, waits until the status becomes COMPLETE, sets the
   status to READING, performs the actual read, zeroes out the message body,
   changes the status to EMPTY, and updates readOffet for the next read.

   When trying to write a message, the writer goes to the memory location
   indexed by writeOffset, waits until the status becomes EMPTY and enough
   space is available (determined by looking at readOffset), automatically
   changes the status to WRITING, perform the write, changes the status to
   COMPLETE and updates writeOffset.

   Notice that reader follows the footprints of the writer, it is assured that
   a message header has been set up at readOffset. However, it is not the case
   for the writer. The writer can start writing at any offset, as this only
   depends on the size of the previous write. Thus, we make the status EMPTY =
   0 and the reader wipe out the message once it has read it.

   To solve the full/empty distinction problem of the circular buffer, we keep
   track of if the writer has wraped around or not. If so, writeOffset is
   required to be strictly less than readOffset (we don't allow the writer to
   catch up the reader). Once the reader also wraps around, the flag is reset.
   Thus we ensure proper synchronization when the writer finds out that
   writeOffset == readOffset: the writer is allowed to proceed only if it has
   not wrapped around.

   State of a message:

                         writer
                         waiting
                           |----> EMPTY -----|
                           |                 |
                           |                 V
                        READING           WRITING
                           ^                 |
                           |                 |
                           |---- COMPLETE <--|
                                          reader
                                          waiting
 */
#include <stdlib.h>
#include "cuos.h"
#include "cuda_stdint.h"
#include "check_ipc.h"
#include "check_ipc_shm.h"
#include "check_ipc_utils.h"
#include "check_ipc_channel_event.h"

#define BUFFER_SIZE (128 * 1024)
#define NUM_CHANNELS 2

typedef enum {
    CCIPC_CHANNEL_INVALID_STATE = 0,
    CCIPC_CHANNEL_INITIALIZED,
    CCIPC_CHANNEL_UNINITIALIZED,
} CCIPCshmChannelState;

typedef struct CCIPCshmHandle_st CCIPCshmHandle;
typedef struct CCIPCshmChannelPair_st CCIPCshmChannelPair;
typedef struct CCIPCshmChannel_st CCIPCshmChannel;
typedef struct CCIPCshmChannelHeader_st CCIPCshmChannelHeader;
typedef struct CCIPCshmMsgHeader_st CCIPCshmMsgHeader;

#pragma pack(push, 1)
struct CCIPCshmChannelHeader_st {
    volatile uint32_t readOffset;
    volatile uint32_t writeOffset;
    volatile uint32_t wrapAround;   /* indicates if the writer is behind the reader
                                       (writer has wrapped around but not the reader)
                                     */
    volatile int32_t state;         /* initialized or uninitialized */
};

struct CCIPCshmMsgHeader_st {
    volatile uint32_t status;
    volatile uint32_t size;
};

struct CCIPCshmChannel_st {
    CCIPCshmChannelHeader header;
    char buffer[BUFFER_SIZE];
};

struct CCIPCshmChannelPair_st {
    CCIPCshmChannel channels[NUM_CHANNELS];
};

struct CCIPCshmHandle_st {
    cuosShmInfoEx *info;
};
#pragma pack(pop)

/* Possible states that a message can be in.
 */
enum {
    EMPTY = 0,
    WRITING,
    COMPLETE,
    READING
};

#ifndef RELEASE
static const char *status2str(int32_t status)
{
    switch (status) {
    case EMPTY:
        return "EMPTY";
        break;
    case COMPLETE:
        return "COMPLETE";
        break;
    case READING:
        return "READING";
        break;
    case WRITING:
        return "WRITING";
        break;
    default:
        return "UNKNOWN";
        break;
    }
}
#endif

/* Create a shmem allocation. This will use the handle of the abstract
   channel passed in at CCIPChandle. This function will do the following:
    1. Allocate the implementation data (of type CCIPCshmHandle)
    2. Try to open the shmem at the given name.
       Note : name contains the PID of the frontend
    3. If the open at step 2 fails, then this will first create a new shmem region
       with the given name. It will then attempt to open this handle.
    4. Assign the raw channels in the handle structure to point to the correct
       shmem region. Depending on the endpoint, this will swizzle the regions
       so that the two endpoints will actually use the appropriate channels
       as their senders/receivers
    5. Fill in the implementation data in the handle with the shmem info pointer
*/
static CCIPCresult
CCIPCshmHandleCreate(CCIPChandle *handle, const char *sendIpcName, const char *recvIpcName)
{
    CCIPCresult res = CCIPC_SUCCESS;
    CCIPCshmHandle *shmHandle = NULL;
    size_t shmSize = 0;
    int cuosret = 0;
    CCIPCshmChannelPair *shmPair = NULL;

    CCIPC_TRACE_FUNCTION();

    if (!handle) {
        CCIPC_ERROR_PRINT("Invalid IPC handle\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    if (!sendIpcName) {
        CCIPC_ERROR_PRINT("Invalid SHMEM name\n");
        return CCIPC_ERROR_INVALID_IPC_NAME;
    }

    CCIPC_DEBUG_PRINT("Using SHMEM name:%s\n", sendIpcName);

    /* shmHandle contains the shm specific implementation info */
    shmHandle = (CCIPCshmHandle*)calloc(1, sizeof(*shmHandle));
    if (!shmHandle) {
        CCIPC_ERROR_PRINT("Failed to allocate shmHandle\n");
        res = CCIPC_ERROR_OUT_OF_MEMORY;
        goto Error;
    }

    shmSize = sizeof(*shmPair);

    /* If the shm can be directly opened, try that */
    cuosret = cuosShmOpenNamedEx(NULL, sendIpcName, shmSize, &shmHandle->info);
    if (cuosret != CUOS_SUCCESS) {
        CCIPC_DEBUG_PRINT("Failed on first try to open shmem handle\n");
        /* Failed to open the shmem handle. Try creating it instead. */
        cuosret = cuosShmCreateNamedEx(NULL, sendIpcName, shmSize, &shmHandle->info);
        if (cuosret != CUOS_SUCCESS) {
            CCIPC_DEBUG_PRINT("Failed to create shmem region. Src:%u Dst:%u. Name:%s\n",
                              handle->src, handle->dst, sendIpcName);
            /* At this point, there can be a failure if the endpoints
               are racing between each other on create. If so, the
               next line will throw an error.
            */
        }

        /* Now open the shmem that was just created */
        cuosret = cuosShmOpenNamedEx(NULL, sendIpcName, shmSize, &shmHandle->info);
        if (cuosret != CUOS_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to open shmem region after creation.");
            res = CCIPC_ERROR_FAILED_IPC_SETUP;
            goto Error;
        }
    }

    /* At this point, shmHandle->info->addr contains the base address of the pair */
    shmPair = (CCIPCshmChannelPair*)shmHandle->info->addr;
    if (!shmPair) {
        CCIPC_ERROR_PRINT("Failed to get pointer to shmem region\n");
        /* Something went wrong */
        res = CCIPC_ERROR_FAILED_IPC_SETUP;
        goto Error;
    }

    /* Setup the implementation specific data pointer */
    handle->implementationData = shmHandle;

    return CCIPC_SUCCESS;

Error:
    if (shmHandle) {
        if (shmHandle->info) {
            cuosShmCloseEx(shmHandle->info, CUOS_VIRTUAL_FREE_RELEASE, 1);
            shmHandle->info = NULL;
        }

        free(shmHandle);
        shmHandle = NULL;
        handle->implementationData = NULL;
    }
    return res;
}

/* CCIPCshmHandleDestroy
    Unmap the shared memory, destroy it if no channel is still in use.
 */
static CCIPCresult
CCIPCshmHandleDestroy(CCIPChandle *handle)
{
    CCIPCshmHandle *shmHandle = NULL;
    uint32_t do_unlink = 0;

    CCIPC_TRACE_FUNCTION();

    if (!handle) {
        CCIPC_ERROR_PRINT("Invalid IPC handle\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    shmHandle = (CCIPCshmHandle*)handle->implementationData;

    /* Only unlink the shm from the handle where src < dst  */
    if (handle->src < handle->dst)
        do_unlink = 1;

    if (shmHandle->info) {
        cuosShmCloseEx(shmHandle->info, CUOS_VIRTUAL_FREE_RELEASE, do_unlink);
        shmHandle->info = NULL;
    }

    free(handle->implementationData);
    handle->implementationData = NULL;

    return CCIPC_SUCCESS;
}

/* CCIPCshmHandleForceCleanup
*/
static CCIPCresult
CCIPCshmHandleForceCleanup(const char *sendIpcName, const char *recvIpcName)
{
    cuosShmInfoEx *info;
    size_t shmSize = 0;
    int cuosret = 0;

    shmSize = sizeof(CCIPCshmChannelPair);

    cuosret = cuosShmOpenNamedEx(NULL, sendIpcName, shmSize, &info);
    /* If shm_open fails, the segment does not exist. */
    if (cuosret != CUOS_SUCCESS)
        return CCIPC_SUCCESS;

    /* Close the shm handle */
    cuosShmCloseEx(info, CUOS_VIRTUAL_FREE_RELEASE, 1);

    return CCIPC_SUCCESS;
}


/* CCIPCshmChannelCreate
    This handles the shmem channel swizzle
*/
static CCIPCresult
CCIPCshmChannelCreate(CCIPCchannel *channel, const char *ipcName)
{
    CCIPCshmHandle *shmHandle = NULL;
    CCIPCshmChannelPair *shmPair = NULL;

    /* Setup the endpoints. Swizzle as appropriate. The goal here is the following
       The shmem region that has been setup is a pair of channels. So

                -------------------------
             -> |   shmChannel[SEND]    | ->
        C1      ------------------------       C2
             <- |   shmChannel[RECV]    | <-
                ------------------------

        From the perspective of C1, the src and dst are :
            SEND (C1, C2) => shmChannel[SEND]
            RECV (C2, C1) => shmChannel[RECV]
        and similarly for C2, the src and dst are :
            SEND (C2, C1) => shmChannel[RECV]
            RECV (C1, C2) => shmChannel[SEND]

        Thus, we want to ensure that when creating the handles to the channel
        in C1 we treat shmChannel[SEND] as the sender, but when doing the same
        for C2, we treat shmChannel[RECV] as the sender.

        To make this logic work for any pair of unique endpoints, we instead use
        the following logic:

        for Client (where C1 < C2)
            Client[SEND] = shmChannel[SEND];
            Client[RECV] = shmChannel[RECV];
        and Client (where C2 > C1)
            Client[SEND] = shmChannel[RECV];
            Client[RECV] = shmChannel[SEND];
    */

    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!channel->handle) {
        CCIPC_ERROR_PRINT("Invalid handle\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    shmHandle = (CCIPCshmHandle*)channel->handle->implementationData;
    if (!shmHandle) {
        CCIPC_ERROR_PRINT("Could not find SHM handle\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    shmPair = (CCIPCshmChannelPair*)shmHandle->info->addr;
    if (!shmPair) {
        CCIPC_ERROR_PRINT("Shm handles not open\n");
        return CCIPC_ERROR_INVALID_HANDLE;
    }

    if (channel->handle->src < channel->handle->dst) {
        /* Do a normal assignment */
        channel->implementation = &shmPair->channels[channel->type];
    }
    else if (channel->handle->src > channel->handle->dst) {
        /* Flip the two channels  */
        channel->implementation =
            &shmPair->channels[CCIPC_CHANNEL_TYPE_SIZE - channel->type - 1];
    }
    else {
        CCIPC_ERROR_PRINT("Encountered identical endpoints : %u\n", channel->handle->src);
        return CCIPC_ERROR_INVALID_ENDPOINT;
    }

    return CCIPC_SUCCESS;
}

static CCIPCresult
CCIPCshmChannelDestroy(CCIPCchannel *channel)
{
    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    channel->implementation = NULL;
    return CCIPC_SUCCESS;
}

/* CCIPCshmChannelInitialize
    This is called by the IAL to initialize a channel for shm channels.
*/
static CCIPCresult
CCIPCshmChannelInitialize(void *implementation, const char *name)
{
    CCIPCshmChannel *shmChannel = NULL;

    CCIPC_TRACE_FUNCTION();

    if (!implementation) {
        CCIPC_ERROR_PRINT("Invalid channel handle\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    shmChannel = (CCIPCshmChannel*)implementation;

    memset(shmChannel, 0, sizeof(*shmChannel));
    shmChannel->header.state = CCIPC_CHANNEL_INITIALIZED;
    return CCIPC_SUCCESS;
}

/* CCIPCshmChannelFinalize
    This is called by the IAL to finalize a channel.
*/
static CCIPCresult
CCIPCshmChannelFinalize(void *implementation)
{
    CCIPCshmChannel *shmChannel = NULL;

    CCIPC_TRACE_FUNCTION();

    if (!implementation) {
        CCIPC_ERROR_PRINT("Invalid channel handle\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    shmChannel = (CCIPCshmChannel*)implementation;

    shmChannel->header.state = CCIPC_CHANNEL_UNINITIALIZED;
    return CCIPC_SUCCESS;
}

/* CCIPCshmChannelRead
    Actual read implmentation. See the description at the start of this file
    for an explanation of the full protocol.

    Basically, this function will try to read the buffer. It will block waiting
    for the message header at the read pointer to indicate that the
    message is ready to be read. Once it finds a valid state, it will
    allocate a buffer, read the data from the shmem region into the buffer, zero
    out the shmem region and advance the read pointer.

    Note: the blocking wait here is actually not wasteful as this will only
    be called if the abstract layer received a notification on a cuosEvent
    that a message was actually ready to be read.
*/
static CCIPCresult
CCIPCshmChannelRead(void *implementation, void *buf, size_t bufSize, size_t *readSize, uint32_t timeoutMs)
{
    uint32_t readOffset, nextReadOffset, msgOffset, remaining, size;
    volatile CCIPCshmMsgHeader *msgHeader;
    cuosTimer timer;
    volatile CCIPCshmChannel *shmChannel = NULL;
    uint32_t shmBufferSize = 0;
    size_t   bufWriteSize = 0;

    CCIPC_TRACE_FUNCTION();

    /* Some initial checks */
    if (!implementation) {
        CCIPC_ERROR_PRINT("Invalid channel handle\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!buf || !readSize) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    shmChannel = (volatile CCIPCshmChannel*)implementation;
    shmBufferSize = sizeof(shmChannel->buffer);

    readOffset = shmChannel->header.readOffset;
    msgOffset = readOffset + sizeof(CCIPCshmMsgHeader);
    if (msgOffset >= shmBufferSize) {
        msgOffset = 0;
    }
    remaining = shmBufferSize - msgOffset;
    msgHeader = (volatile CCIPCshmMsgHeader *)
                (&shmChannel->buffer[readOffset]);
    /* wait until the message has been completely writen down */
    cuosResetTimer(&timer);
    while (cuosInterlockedCompareExchange(&msgHeader->status, READING, COMPLETE) != COMPLETE) {
        if (cuosGetTimer(&timer) > timeoutMs) {
            CCIPC_ERROR_PRINT("Timeout  in reader. Waited for %u ms\n",
                              timeoutMs);
            return CCIPC_ERROR_TIMEOUT;
        }
        cuosThreadYield();
    }
    size = msgHeader->size;
    *readSize = size;

    /* Calculate the next readOffset, we always make sure that we have enough
       space left in the buffer for a CCIPCshmMsgHeader, otherwise we force a
       wrap around
     */
    nextReadOffset = (msgOffset + size) % shmBufferSize;
    if (shmBufferSize - nextReadOffset < sizeof(CCIPCshmMsgHeader)) {
        nextReadOffset = 0;
    }


    if (remaining >= size) {
        /* the message completely fit in what's left in the buffer */
        bufWriteSize = (bufSize < size) ? bufSize : size;
        memcpy(buf, (char*)&shmChannel->buffer[msgOffset], bufWriteSize);
        memset((char*)&shmChannel->buffer[msgOffset], 0, size);
    }
    else {
        /* otherwise, read all of the remaining buffer */
        bufWriteSize = (remaining < bufSize) ? remaining : bufSize;
        memcpy(buf,
               (char*)&shmChannel->buffer[msgOffset],
               bufWriteSize);

        /* and wrap around */
        bufWriteSize = ((size - remaining) < (bufSize - remaining)) ?
                       (size - remaining) : (bufSize - remaining);

        if (remaining < bufSize) {
            memcpy((char*)buf + remaining,
                   (char*)&shmChannel->buffer[0],
                   bufWriteSize);
        }
        /* Zero out the payload */
        memset((char*)&shmChannel->buffer[msgOffset], 0, remaining);
        memset((char*)&shmChannel->buffer[0], 0, size - remaining);
    }
    /* Also need to zero out the header */
    msgHeader->size = 0;
    /* We neet to first update the status then the readOffset. Imagine the
       following:

          writeOffset    readOffset
               |              |
               V              V
         |-------------------------------------------------|
         |-------------------------------------------------|
                                   ^                ^
                                   |                |
                            nextWriteOffset   nextReadOffset

       If readOffset is updated first and the writer sees it, the write can go
       ahead and write down the message, after which the readly comes back,
       update the status at the old readOffset and effectively corrupt the
       message that the writer just wrote down.
     */
    if (cuosInterlockedCompareExchange(&msgHeader->status, EMPTY, READING) != READING) {
        CCIPC_ERROR_PRINT("Unexpected message status, expecting status READING");
        return CCIPC_ERROR_PROTOCOL;
    }
    if (cuosInterlockedCompareExchange(&shmChannel->header.readOffset,
                                       nextReadOffset,
                                       readOffset) != readOffset) {
        CCIPC_ERROR_PRINT("Corrupted readOffset");
        return CCIPC_ERROR_PROTOCOL;
    }
    /* The the update of wrap around flag, the reader does it last, and the
       writer does it first as the writer is always ahead of the reader.
     */
    if (nextReadOffset < readOffset) {
        (void)cuosInterlockedCompareExchange(&shmChannel->header.wrapAround, 0, 1);
    }

    return CCIPC_SUCCESS;
}

static CCIPCresult
CCIPCshmChannelWrite(void *implementation, void *buf, size_t bufSize, size_t *writeSize, uint32_t timeoutMs)
{
    volatile CCIPCshmMsgHeader *msgHeader;
    uint32_t writeOffset, nextWriteOffset, readOffset, readOffset2, remaining, msgOffset;
    uint32_t wrap, wrap2;
    int32_t res;
    cuosTimer timer;
    volatile CCIPCshmChannel *shmChannel = NULL;
    uint32_t shmBufferSize = 0;
    size_t size = 0;

    CCIPC_TRACE_FUNCTION();

    if (!implementation) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!buf || !writeSize) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    shmChannel = (volatile CCIPCshmChannel*) implementation;
    shmBufferSize = sizeof(shmChannel->buffer);

    size = bufSize;
    if (size + sizeof(CCIPCshmMsgHeader) > shmBufferSize) {
        CCIPC_DEBUG_PRINT("Oversized message %u. Clamping size to %u", size, (shmBufferSize >> 1));
        size = shmBufferSize >> 1;
    }

    writeOffset = *(volatile uint32_t*)&shmChannel->header.writeOffset;
    msgHeader = (volatile CCIPCshmMsgHeader *)
                (&shmChannel->buffer[writeOffset]);
    msgOffset = writeOffset + sizeof(CCIPCshmMsgHeader);
    if (msgOffset >= shmBufferSize) {
        msgOffset = 0;
    }
    nextWriteOffset = (msgOffset + (uint32_t)size) % shmBufferSize;
    if (shmBufferSize - nextWriteOffset < sizeof(CCIPCshmMsgHeader)) {
        nextWriteOffset = 0;
    }
    remaining = shmBufferSize - msgOffset;
    /* wait until the current message is consumed. */
    cuosResetTimer(&timer);
    while (cuosInterlockedCompareExchange(&msgHeader->status, WRITING, EMPTY) != EMPTY) {
        if (cuosGetTimer(&timer) > timeoutMs) {
            CCIPC_ERROR_PRINT("Timeout in writer. Waited for %u ms\n", timeoutMs);
            return CCIPC_ERROR_TIMEOUT;
        }
        cuosThreadYield();
    }

    /* Wait until enough space is available */
    cuosResetTimer(&timer);
    while (1) {
        /* The two flags below can be simultaneously modified from both processes.
           So, poll each one until the values stabilize */
        do {
            readOffset = *(volatile uint32_t*)&shmChannel->header.readOffset;
            readOffset2 = *(volatile uint32_t*)&shmChannel->header.readOffset;
        }
        while (readOffset != readOffset2);
        do {
            wrap = *(volatile uint32_t*)&shmChannel->header.wrapAround;
            wrap2 = *(volatile uint32_t*)&shmChannel->header.wrapAround;
        }
        while (wrap != wrap2);

        if (writeOffset == readOffset && !wrap) {
            /* If writeOffset == readOffset, either:
               - The reader catches up to the writer (by consuming all messages).
               - The writer catches up to the reader (the buffer is full).
               We don't want the writer to start wrting if we are in the 2nd
               case, we do so by keeping a flag 'wrap', initially set to false.
               Whenever the writer wraps around, we set it to true, and
               whenever the reader wraps around we set it to false. Note that
               in the first case above, 'wrap' must be false, and in the second
               case, 'wrap' must be true.
             */
            break;
        }
        else if (writeOffset > readOffset) {
            if (nextWriteOffset > writeOffset || nextWriteOffset < readOffset) {
                /*
                              readOffset      writeOffset
                                   |                |
                                   V                V
                  |-------------------------------------------------|
                  |                |unread messages|                |
                  |-------------------------------------------------|
                            ^                                ^
                            |                                |
                          legal                            legal
                     nextWriteOffset                  nextWriteOffset
                 */
                break;
            }
        }
        else if (writeOffset < readOffset) {
            if (nextWriteOffset > writeOffset && nextWriteOffset < readOffset) {
                /*
                              writeOffset      readOffset
                                   |                |
                                   V                V
                  |-------------------------------------------------|
                  |unread messages|                 |unread messages|
                  |-------------------------------------------------|
                                          ^
                                          |
                                        legal
                                   nextWriteOffset
                 */
                break;
            }
        }

        /* Under any other case, hope that the reader has freed up some space
           in the buffer by consuming messages. Loop back to poll read offset */
        if (cuosGetTimer(&timer) > timeoutMs) {
            CCIPC_ERROR_PRINT("Timeout while waiting for nextWriteOffset to stabilize\n");
            return CCIPC_ERROR_TIMEOUT;
        }

        cuosThreadYield();
    }

    if (remaining >= size) {
        memcpy((char*)&shmChannel->buffer[msgOffset], buf, size);
    }
    else {
        memcpy((char*)&shmChannel->buffer[msgOffset],
               buf,
               remaining);
        memcpy((char*)&shmChannel->buffer[0],
               (char *)buf + remaining,
               size - remaining);
    }
    msgHeader->size = (uint32_t)size;
    /* The the update of wrap around flag, the reader does it last, and the
       writer does it first as the writer is always ahead of the reader.
     */
    if (nextWriteOffset < writeOffset) {
        (void)cuosInterlockedCompareExchange(&shmChannel->header.wrapAround, 1, 0);
    }
    if (cuosInterlockedCompareExchange(&shmChannel->header.writeOffset,
                                       nextWriteOffset,
                                       writeOffset) != writeOffset) {
        CCIPC_ERROR_PRINT("Corrupted writeOffset");
        return CCIPC_ERROR_PROTOCOL;
    }
    if ((res = cuosInterlockedCompareExchange(&msgHeader->status, COMPLETE, WRITING))
        != WRITING) {
        CCIPC_ERROR_PRINT("Unexpected message status, expecting status WRITING");
        return CCIPC_ERROR_PROTOCOL;
    }

    *writeSize = size;

    return CCIPC_SUCCESS;
}

static CCIPCresult
CCIPCshmChannelForceCleanup(const char *ipcName)
{
    return CCIPC_SUCCESS;
}

CCIPCresult
CCIPCshmGetIAL(CCIPCIAL *ial)
{
    if (!ial) {
        CCIPC_ERROR_PRINT("Invalid IAL pointer\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    ial->handleCreate           = CCIPCshmHandleCreate;
    ial->handleDestroy          = CCIPCshmHandleDestroy;
    ial->handleForceCleanup     = CCIPCshmHandleForceCleanup;
    ial->channelCreate          = CCIPCshmChannelCreate;
    ial->channelDestroy         = CCIPCshmChannelDestroy;
    ial->channelInitialize      = CCIPCshmChannelInitialize;
    ial->channelFinalize        = CCIPCshmChannelFinalize;
    ial->channelRead            = CCIPCshmChannelRead;
    ial->channelWrite           = CCIPCshmChannelWrite;
    ial->channelForceCleanup    = CCIPCshmChannelForceCleanup;

    ial->channelEventCreate     = CCIPCcommonChannelEventCreate;
    ial->channelEventSignal     = CCIPCcommonChannelEventSignal;
    ial->channelEventDestroy    = CCIPCcommonChannelEventDestroy;
    ial->channelEventIpcCreate  = CCIPCcommonChannelEventIpcCreate;
    ial->channelEventIpcDestroy = CCIPCcommonChannelEventIpcDestroy;
    ial->channelEventForceCleanup = CCIPCcommonChannelEventForceCleanup;
    ial->channelEventGetCuosEvent = CCIPCcommonChannelEventGetCuosEvent;

    CCIPC_DEBUG_PRINT("Shmem IAL created\n");

    return CCIPC_SUCCESS;
}
