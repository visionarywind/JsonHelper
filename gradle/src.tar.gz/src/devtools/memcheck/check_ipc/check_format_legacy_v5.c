/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: check_format_legacy_v5.h
 *
 *   Description:
 *      Functions to use the legacy format (record version = 5)
 *
 ******************************************************************************/
#include "cudamemcheck.h"
#include "check_format.h"
#include "check_format_internal.h"
#include "check_format_legacy.h"

#define CUDA_MEMCHECK_MAGIC_v5 0x59F7A55A

#define CUDA_MEMCHECK_VERSION_v5 1

/* For unique record ids */
static uint32_t recordid = 1;

#pragma pack(push,1)
typedef struct {
    uint64_t    recordsize;
    uint64_t    magic;
    uint32_t    version;
    uint32_t    errortype;
    uint32_t    recordid;
    union {
        struct {
            CUDBGException_t exception;
            uint64_t address;
            uint32_t pc;             /* ~0 signifies unknown */
            uint32_t size;           /* Transfer size in bytes, 0 if unknown */
            uint32_t write;
            uint32_t blockIdxX, blockIdxY, blockIdxZ;
            uint32_t threadIdxX, threadIdxY, threadIdxZ;
            uint32_t lineno;        /* 0 if unknown */
        } memPrecise;
        struct {
            CUDBGException_t exception;
            uint64_t address;
            uint32_t pc;             /* ~0 signifies unknown */
            uint32_t blockIdxX, blockIdxY, blockIdxZ;
            uint32_t threadIdxX, threadIdxY, threadIdxZ;
            uint32_t numHints;      /* Number of hints that follow*/
            uint32_t lineno;
        } memImprecise;
        struct {
            CUDBGException_t exception;
            uint64_t address;
            uint32_t pc;             /* ~0 signifies unknown */
            uint32_t size;           /* Transfer size in bytes, 0 if unknown */
            uint32_t write;
            uint32_t blockIdxX, blockIdxY, blockIdxZ;
            uint32_t threadIdxX, threadIdxY, threadIdxZ;
            uint32_t lineno;        /* 0 if unknown */
            uint32_t parentrecord;      /* Number of hints that follow*/
        } memHint;
        struct {
            uint64_t size;          /* Size of leak */
            uint64_t address;       /* Device address of leak */
            uint32_t flags;         /* flags for allocation. Internal Use*/
        } memLeak;
        struct {
            uint32_t error;         /* The type of the error */
            uint32_t internal;      /* Boolean flag, 1 means internal */
        } driverError;
    } cases;

    /* Set in the memory version of the error record */
    CUmemcheck_record*        next;
    CUmemcheck_record*        prev;

    uint32_t    stringflags;
    uint32_t    numstrings;
    /* Strings are organized as follows:
       In memory :
         a linked list where each element is a CUmemcheck_record_string
       On disk :
        A table of 64bit uints, where
            the top 32 bits of each entry is the length of the string
            the lower 32 bits are the flags of the string
        This is followed by a table of strings.
        uint64_t sizes_and_flags[numstrings]
        char *strings[numstrings]
    */
    CUmemcheck_record_string*       strings;
} MCerror_v5;
#pragma pack(pop)

uint64_t
getLegacyRecordSize_v5(CUmemcheck_record *rec)
{
    uint64_t sizectr = 0;
    CUmemcheck_record_string* head = NULL;
    strTracker *tracker = NULL;
    CUmemcheck_error_record *err = NULL;

    if (!rec)
        return 0;

    if (rec->recordclass != CU_MEMCHECK_RECORD_CLASS_ERROR)
        return 0;

    err = &rec->cases.error;

    if (err->errortype == CU_MEMCHECK_RECORD_INVALID)
        return 0;

    // Compute size
    sizectr += sizeof(MCerror_v5);
    tracker = (strTracker*)rec->strings;
    head = tracker->list;
    for (; head; head = head->next) {
        if (head->sz)
            sizectr += head->sz + sizeof(head->sz) + sizeof (head->flags);
    }

    return sizectr;
}

CCIPCresult
writeLegacyRecord_v5(CUmemcheck_record *rec, void *buf, uint64_t size)
{
    uint32_t i = 0;
    uint32_t flags = 0;
    uint32_t sizectr = 0;
    CUmemcheck_record_string* head = NULL;
    CUmemcheck_record_string* oldhead = NULL;
    MCerror_v5  olderror = {0};
    strTracker *tracker = NULL;
    char *curptr = NULL;
    CUmemcheck_error_record *err = NULL;

    if (!rec || !buf || !size)
        return CCIPC_ERROR_INVALID_ARGUMENTS;

    if (rec->recordclass != CU_MEMCHECK_RECORD_CLASS_ERROR)
        return CCIPC_SUCCESS;

    err = &rec->cases.error;

    if (err->errortype == CU_MEMCHECK_RECORD_INVALID)
        return CCIPC_SUCCESS;

    curptr = (char*)buf;

    memset(&olderror, 0, sizeof(olderror));
    olderror.magic   = CUDA_MEMCHECK_MAGIC_v5;
    olderror.version = CUDA_MEMCHECK_VERSION_v5;
    olderror.errortype = err->errortype;
    olderror.recordid = ++recordid;

    // Compute size
    sizectr = sizeof(olderror);
    tracker = (strTracker*)rec->strings;
    oldhead = head = tracker->list;
    for (; head; head = head->next)
        if (head->sz) {
            i += 1;
            sizectr += head->sz + sizeof(head->sz) + sizeof (head->flags);
            flags |= head->flags;
        }

    // Check the size
    if (size < sizectr)
        return CCIPC_ERROR_FORMAT_UNDERSIZED_BUFFER;

    // Write the header
    olderror.numstrings = i;
    olderror.recordsize = sizectr;
    olderror.stringflags = flags;

    // Per type copy
    if (olderror.errortype == CU_MEMCHECK_RECORD_MEM_PRECISE) {
        olderror.cases.memPrecise.exception = err->cases.memPrecise.exception;
        olderror.cases.memPrecise.address = err->cases.memPrecise.address;
        olderror.cases.memPrecise.pc  = err->cases.memPrecise.pc;
        olderror.cases.memPrecise.size = err->cases.memPrecise.size;
        olderror.cases.memPrecise.write = err->cases.memPrecise.write;
        olderror.cases.memPrecise.blockIdxX = err->cases.memPrecise.blockIdxX;
        olderror.cases.memPrecise.blockIdxY = err->cases.memPrecise.blockIdxY;
        olderror.cases.memPrecise.blockIdxZ = err->cases.memPrecise.blockIdxZ;
        olderror.cases.memPrecise.threadIdxX = err->cases.memPrecise.threadIdxX;
        olderror.cases.memPrecise.threadIdxY = err->cases.memPrecise.threadIdxY;
        olderror.cases.memPrecise.threadIdxZ = err->cases.memPrecise.threadIdxZ;
        olderror.cases.memPrecise.lineno = err->cases.memPrecise.lineno;
    }
    else if (olderror.errortype == CU_MEMCHECK_RECORD_MEM_IMPRECISE) {
        olderror.cases.memImprecise.exception = err->cases.memImprecise.exception;
        olderror.cases.memImprecise.address = err->cases.memImprecise.address;
        olderror.cases.memImprecise.pc  = err->cases.memImprecise.pc;
        olderror.cases.memImprecise.blockIdxX = err->cases.memImprecise.blockIdxX;
        olderror.cases.memImprecise.blockIdxY = err->cases.memImprecise.blockIdxY;
        olderror.cases.memImprecise.blockIdxZ = err->cases.memImprecise.blockIdxZ;
        olderror.cases.memImprecise.threadIdxX = err->cases.memImprecise.threadIdxX;
        olderror.cases.memImprecise.threadIdxY = err->cases.memImprecise.threadIdxY;
        olderror.cases.memImprecise.threadIdxZ = err->cases.memImprecise.threadIdxZ;
        olderror.cases.memImprecise.lineno = err->cases.memImprecise.lineno;
    }
    else if (olderror.errortype == CU_MEMCHECK_RECORD_MEM_LEAK) {
        olderror.cases.memLeak.size =  err->cases.memLeak.size;
        olderror.cases.memLeak.address = err->cases.memLeak.address;
        olderror.cases.memLeak.flags = err->cases.memLeak.flags;
    }
    else if (olderror.errortype == CU_MEMCHECK_RECORD_DRV_ERROR) {
        olderror.cases.driverError.error = err->cases.driverError.error;
        olderror.cases.driverError.internal = err->cases.driverError.internal;
    }

    memcpy((void*)curptr, (void*)&olderror, sizeof(olderror));
    curptr += sizeof(olderror);

    // Write the size table
    for (head = oldhead; head; head = head->next)
        if (head->sz) {
            memcpy((void*)curptr, (void*)&head->sz, sizeof(head->sz));
            curptr += sizeof(head->sz);
            memcpy((void*)curptr, (void*)&head->flags, sizeof(head->flags));
            curptr += sizeof(head->flags);
        }


    // Write the string table
    for (head = oldhead; head; head = head->next)
        if (head->sz) {
            memcpy((void*)curptr, (void*)head->str, head->sz);
            curptr += sizeof(head->sz);
        }

    return CCIPC_SUCCESS;
}
