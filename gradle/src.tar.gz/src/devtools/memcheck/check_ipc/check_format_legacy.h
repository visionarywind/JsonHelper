/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: check_format_legacy.h
 *
 *   Description:
 *      Contains functions that can read and write memcheck legacy format
 *      files. The general usage is that error records are created and
 *      packaged at this level
 *      Writing is the conversion of the in-memory form to the on-disk form.
 *      Reading is the conversion of the on-disk form to the in-memory form.
 *
 ******************************************************************************/
#ifndef CHECK_FORMAT_LEGACY_H
#define CHECK_FORMAT_LEGACY_H

#include "cuda_stdint.h"
#include "cudamemcheck.h"
#include "check_ipc.h"

/* For Toolkit 4.1 */
uint64_t getLegacyRecordSize_v5(CUmemcheck_record *err);
CCIPCresult writeLegacyRecord_v5(CUmemcheck_record *err, void *buf, uint64_t size);

/* For Toolkit 4.0 */
uint64_t getLegacyRecordSize_v4(CUmemcheck_record *err);
CCIPCresult writeLegacyRecord_v4(CUmemcheck_record *err, void *buf, uint64_t size);

/* For Toolkit 3.2 */
uint64_t getLegacyRecordSize_v3(CUmemcheck_record *err);
CCIPCresult writeLegacyRecord_v3(CUmemcheck_record *err, void *buf, uint64_t size);

#endif

