/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: check_ipc_channel.c
 *
 *   Description:
 *       Implementation of IPC abstract channels
 *
 ******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "cuos.h"
#include "cuos_platform.h"
#include "check_ipc.h"
#include "check_ipc_utils.h"
#include "check_ipc_channel.h"

CCIPCresult
CCIPCchannelInitialize(CCIPCchannel *channel,
                       const char *eventName,
                       CCIPCendpoint src,
                       CCIPCendpoint dst,
                       const char *ipcName,
                       CCIPCchannelType type,
                       CCIPChandle *handle)
{
    CCIPCresult res = CCIPC_SUCCESS;
    CCIPCresult res_bypass = CCIPC_SUCCESS;

    CCIPC_TRACE_FUNCTION();

    if (!channel || !eventName) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    /* Setup the type of the channel according to the initialization arguments  */
    channel->type = type;

    /* Setup the IAL */
    channel->ial = &handle->ial;

    /* Setup the parent */
    channel->handle = handle;

    /* Create the channel if needed by the IAL */
    res = channel->ial->channelCreate(channel, ipcName);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to create channel of type:%u (src:%u, dst:%u)\n",
                          type, src, dst);
        goto error;
    }

    /* Create the channel's IPC event. For receive events, this
       will actually do the event creation. At minimum, this will
       populate the eventPath.
     */
    res = channel->ial->channelEventIpcCreate(channel, eventName, src, dst);
    if (res != CCIPC_SUCCESS)
        goto error;

    if (channel->type == CCIPC_CHANNEL_TYPE_RECEIVE) {
#if cuosOsIsWindows()
        if (!channel->eventReady) {
            res = channel->ial->channelEventCreate(channel);
            if (res != CCIPC_SUCCESS)
                goto error;
            channel->eventReady = 1;
        }
#endif
    }

    /* Each party is responsible for initializing the channel it will send
       messages through.
     */
    if (channel->type == CCIPC_CHANNEL_TYPE_SEND) {
        /* Initialize the channel */
        res = channel->ial->channelInitialize(channel->implementation, ipcName);
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to initialize send channel\n");
            goto error;
        }
    }

    return CCIPC_SUCCESS;

error:

    if (type == CCIPC_CHANNEL_TYPE_SEND) {
        res_bypass = channel->ial->channelFinalize(channel->implementation);
        if (res_bypass != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to finalize channel. (Error :%u)\n", res_bypass);
        }
    }

    /* Destroy the channel */
    res_bypass = channel->ial->channelDestroy(channel);
    if (res_bypass != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to destroy channel in IAL. (Error :%u)\n", res_bypass);
    }

    if (channel->eventReady) {
        res_bypass = channel->ial->channelEventDestroy(channel);
        if (res_bypass != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to destroy channelEvent. (Error:%u)\n", res_bypass);
        }
    }

    res_bypass = channel->ial->channelEventIpcDestroy(channel);
    if (res_bypass != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to teardown channelEvent IPC. (Error:%u)\n", res_bypass);
    }
    return res;
}

CCIPCresult
CCIPCchannelFinalize(CCIPCchannel *channel)
{
    CCIPCresult res = CCIPC_SUCCESS;
    CCIPCresult res_bypass = CCIPC_SUCCESS;

    CCIPC_TRACE_FUNCTION();

    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    /* Cleans up the event that it listens to, so that other parties will get
       an error trying sending messages to the current party. On the other
       hand, we still want the messages sent by the current party to be
       received after the current party exits (if they have not been yet
       received).
     */

    if (channel->eventReady) {
        res = channel->ial->channelEventDestroy(channel);
        if (res != CCIPC_SUCCESS)
            CCIPC_DEBUG_PRINT("Failed to destroy channel event. (Error:%u)\n", res);
        channel->eventReady = 0;
    }

    if (channel->type == CCIPC_CHANNEL_TYPE_RECEIVE) {
        res = channel->ial->channelFinalize(channel->implementation);
        if (res != CCIPC_SUCCESS)
            CCIPC_DEBUG_PRINT("Failed to finalize channel. (Error:%u)\n", res);
    }

    /* Release any global event data  */
    res = channel->ial->channelEventIpcDestroy(channel);
    if (res != CCIPC_SUCCESS) {
        CCIPC_DEBUG_PRINT("Failed to destroy channel IPC event. (Error:%u)\n", res);
    }

    /* Destroy the channel */
    res_bypass = channel->ial->channelDestroy(channel);
    if (res_bypass != CCIPC_SUCCESS) {
        CCIPC_DEBUG_PRINT("Failed to destroy channel in IAL. Ignoring (Error :%u)\n", res_bypass);
    }

    return res;
}

/* Force cleanup on a channel from another party, clean up anything
   CCIPCchannelFinalize does clean up.
   When invoked, this will cause the IPC event to be destroyed even
   for channels that have not created them. This needs to be used
   with caution.
 */
CCIPCresult
CCIPCchannelForceCleanup(CCIPCIAL *ial, CCIPCendpoint src, CCIPCendpoint dst,
                         const char *ipcName, const char *eventName)
{
    CCIPCresult res = CCIPC_SUCCESS;

    CCIPC_TRACE_FUNCTION();

    if (ial && ial->channelEventForceCleanup) {
        res = ial->channelEventForceCleanup(eventName, src, dst);
        if (res != CCIPC_SUCCESS) {
            CCIPC_DEBUG_PRINT("Failed to force cleanup. (Error:%u)\n", res);
        }
    }

    if (ial && ial->channelForceCleanup) {
        res = ial->channelForceCleanup(ipcName);
        if (res != CCIPC_SUCCESS) {
            CCIPC_DEBUG_PRINT("Failed to finalize channel in IAL. Ignoring (Error :%u)\n", res);
        }
    }

    return res;
}

CCIPCresult
CCIPCchannelSend(CCIPCchannel *channel, void *buf, size_t bufsize, size_t *sendsize, uint32_t timeoutMs)
{
    CCIPCresult res;

    CCIPC_TRACE_FUNCTION();

    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!buf || !sendsize) {
        CCIPC_ERROR_PRINT("Invalid args\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    if (!channel->eventReady) {
        res = channel->ial->channelEventCreate(channel);
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to create channel event (Error:%u)\n", res);
            res = CCIPC_ERROR_FAILED_CREATE_EVENT;
            return res;
        }
        channel->eventReady = 1;
    }

    res = channel->ial->channelWrite(channel->implementation, buf, bufsize, sendsize, timeoutMs);
    if (res == CCIPC_SUCCESS) {
        res = channel->ial->channelEventSignal(channel);
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to signal the channelEvent! (Error:%u)\n", res);
        }
    }
    else {
        CCIPC_ERROR_PRINT("Failed to send the message. Not signalling\n");
    }

    return res;
}

CCIPCresult
CCIPCchannelReceive(CCIPCchannel *channel, void *buf, size_t bufsize, size_t *recvsize, uint32_t timeoutMs, cuosEvent **userEvents, uint32_t numUserEvents, int *userEventIndex)
{
    cuosEvent **waitEvents = NULL;
    uint32_t  numWaitEvents = 0;
    CCIPCresult res = CCIPC_SUCCESS;
    int signaledIndex = -1;
    int count = 0;
    int waitEventIndex = 0;
    cuosEvent channelEvent = {0};

    CCIPC_TRACE_FUNCTION();

    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!buf || !recvsize) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    /* Handle the case where no user events are specified */
    if (!userEvents)
        numUserEvents = 0;

    numWaitEvents = numUserEvents + 1;
    waitEventIndex = numUserEvents;

    waitEvents = (cuosEvent**)calloc(numWaitEvents, sizeof(cuosEvent *));
    if (!waitEvents) {
        CCIPC_ERROR_PRINT("Failed to allocate waitEvents\n");
        return CCIPC_ERROR_OUT_OF_MEMORY;
    }

    /* Check if the channel event is ready. If not, create it here. */
    if (!channel->eventReady) {
        res = channel->ial->channelEventCreate(channel);
        if (res != CCIPC_SUCCESS) {
            CCIPC_ERROR_PRINT("Failed to create channel event (Error:%u)\n", res);
            res = CCIPC_ERROR_FAILED_CREATE_EVENT;
            goto done;
        }
        channel->eventReady = 1;
    }

    /* Construct the list of events to wait on */
    if (userEvents && numUserEvents > 0)
        memcpy(waitEvents, userEvents, numUserEvents * sizeof(cuosEvent *));

    /* Finally, push the channel's event on the waitEvent list */
    res = channel->ial->channelEventGetCuosEvent(channel, &channelEvent);
    if (res != CCIPC_SUCCESS) {
        CCIPC_ERROR_PRINT("Failed to get a cuosEvent for the channel event\n");
        res = CCIPC_ERROR_FAILED_CREATE_EVENT;
        goto done;
    }

    waitEvents[waitEventIndex] = &channelEvent;

    count = cuosEventWait(waitEvents, numWaitEvents, &signaledIndex, timeoutMs);

    /* There are a few cases to handle here :
       1 : Timeout. In this case, the wait exceeded timeoutMs. In this case, count = 0.
       2 : Error. There was an error while waiting. In this case count = -1.
       3 : Forced wakeup. An event was read as expected, however the
           forceWakeup flag was set on the channel. In this case, count = 1. The force
           wakeup flag is set.
       4 : User event. An event was read as expected. The signaled index points
           to one of the user events specified, rather than the channel wait event.
           In this case, count = 1 and signaledIndex < numUserEvents.
       5 : Channel event. An event was read on the channel event. In this case, the IAL
           must be called to do a read from the channel.
       6 : Unknown event. This should really never happen, but it implies an event was
           signaled which was neither a userEvent, nor the channel event.
    */
    if (count == 0) {
        /* Case 1 : Timeout hit while waiting */
        res = CCIPC_ERROR_TIMEOUT;
        CCIPC_ERROR_PRINT("Hit timeout\n");
        goto done;
    }
    else if (count == -1) {
        /* Case 2 : Error while waiting on the event */
        res = CCIPC_ERROR_ON_WAIT;
        CCIPC_ERROR_PRINT("Internal error while waiting\n");
        goto done;
    }

    if (channel->forceWakeUp) {
        /* Case 3 : Forced wakeup through the IPC library */
        channel->forceWakeUp = 0;
        res = CCIPC_ERROR_FORCE_WAKEUP;
        CCIPC_DEBUG_PRINT("Forced wakeup\n");
        goto done;
    }

    if ((uint32_t)signaledIndex < numUserEvents) {
        /* Case 4 : User event signaled */
        if (userEventIndex)
            *userEventIndex = signaledIndex;

        res = CCIPC_ERROR_USER_EVENT_SIGNALED;
        CCIPC_DEBUG_PRINT("User event signaled\n");
        goto done;
    }

    if (signaledIndex == waitEventIndex) {
        /* Case 5 : Channel event has been signaled and thus a message is ready */
        res = channel->ial->channelRead(channel->implementation, buf, bufsize, recvsize, timeoutMs);
        CCIPC_DEBUG_PRINT("Channel read\n");
        goto done;
    }

    /* Case 6 : Unknown event. */
    res = CCIPC_ERROR_UNKNOWN_EVENT;
    CCIPC_ERROR_PRINT("Unknown event!\n");

done:
    if (waitEvents) {
        free(waitEvents);
        waitEvents = NULL;
    }

    return res;
}

CCIPCresult
CCIPCchannelSendFd(CCIPCchannel *channel, CCIPCfd *fd, uint32_t timeoutMs)
{
    CCIPC_TRACE_FUNCTION();

    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!fd) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    if (!channel->ial->channelWriteFd)
        return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;

    return channel->ial->channelWriteFd(channel->implementation, fd, timeoutMs);
}

CCIPCresult
CCIPCchannelReceiveFd(CCIPCchannel *channel, CCIPCfd *fd, uint32_t timeoutMs)
{
    CCIPC_TRACE_FUNCTION();

    if (!channel) {
        CCIPC_ERROR_PRINT("Invalid channel\n");
        return CCIPC_ERROR_INVALID_CHANNEL;
    }

    if (!fd) {
        CCIPC_ERROR_PRINT("Invalid arguments\n");
        return CCIPC_ERROR_INVALID_ARGUMENTS;
    }

    if (!channel->ial->channelReadFd)
        return CCIPC_ERROR_UNSUPPORTED_IPC_TYPE;

    return channel->ial->channelReadFd(channel->implementation, fd, timeoutMs);
}

