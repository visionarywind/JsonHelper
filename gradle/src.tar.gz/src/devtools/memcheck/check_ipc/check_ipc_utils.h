/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef CHECK_IPC_UTILS_H
#define CHECK_IPC_UTILS_H

#include "cuos.h"

typedef enum {
    CCIPC_DEBUG_LEVEL_ERROR = 0,
    CCIPC_DEBUG_LEVEL_DEBUG = 20,
    CCIPC_DEBUG_LEVEL_TRACE = 40,

} CCIPCdebugLevel;

#ifdef DEBUG
void CCIPCdebugPrint(const char *file, int line, CCIPCdebugLevel level, const char *msg, ...);
#define CCIPC_DEBUG_PRINT( msg, ... ) CCIPCdebugPrint(__FILE__, __LINE__, CCIPC_DEBUG_LEVEL_DEBUG, msg, ##__VA_ARGS__ )
#define CCIPC_ERROR_PRINT( msg, ... ) CCIPCdebugPrint(__FILE__, __LINE__, CCIPC_DEBUG_LEVEL_ERROR, msg, ##__VA_ARGS__ )
#define CCIPC_TRACE_FUNCTION() CCIPCdebugPrint(__FILE__, __LINE__, CCIPC_DEBUG_LEVEL_TRACE, __FUNCTION__)
#else
#define CCIPC_DEBUG_PRINT(msg, ... )
#define CCIPC_ERROR_PRINT(msg, ... )
#define CCIPC_TRACE_FUNCTION()
#endif

#endif
