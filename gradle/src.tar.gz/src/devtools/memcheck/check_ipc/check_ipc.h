/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: check_ipc.h
 *
 *   Description:
 *       Implementation of IPC
 *
 ******************************************************************************/

/* Interprocess Communication (IPC) Library
 *
 * Overview:
 *
 * The IPC library consists of three layers: the IPC layer, the channel layer,
 * and the underlying implementation layer. The IPC layer is intended to be
 * exposed to the user and is implemented in check_ipc.c, the channel layer is
 * implemented in check_ipc_channel.c, and the underlying implementation layer
 * is implemented in check_ipc_*.c where the wildcard can be any
 * implementation, currently we have check_ipc_shm.c implemented using shared
 * memory provided by cuos.
 *
 * The IPC layer manages a number of abstract, unidirectional channels between
 * communication parties (currently we have two channels for two parties). The
 * channel layer works with individual channels. The actual operations such as
 * create/destroy of the communication resources and the read/sent are provided
 * by the underlying implementation layers in forms of structs of function
 * pointers (see CCIPCIAL).
 *
 * Extending and Reusing the IPC library:
 *
 * To incorperate or parties in communication, one can add more endpoints to
 * CCIPCendpoint, add corresponding channels to CCIPChandle and make the
 * changes in send/receive routines of the IPC layer. The creation/destruction
 * interface of the underlying implementation layer should also be updated to
 * work with more channels.
 */
#ifndef CHECK_IPC_H
#define CHECK_IPC_H

#include "cuda_stdint.h"
#include "cuos.h"

/* Default timeout for internal message waits (5 sec)*/
#define CCIPC_DEFAULT_TIMEOUT 5000

#ifdef __cplusplus
extern "C" {
#endif

/* Return codes of the IPC library.
 */
typedef enum {
    CCIPC_SUCCESS                                   =   0,
    CCIPC_ERROR_TIMEOUT                             =   1,
    CCIPC_ERROR_OUT_OF_MEMORY                       =   2,
    CCIPC_ERROR_INVALID_TYPE                        =   3,
    CCIPC_ERROR_UNEXPECTED_MESSAGE                  =   4,
    CCIPC_ERROR_PROTOCOL                            =   5,
    CCIPC_ERROR_INVALID_ENDPOINT                    =   6,
    CCIPC_ERROR_INTERNAL                            =   7,
    CCIPC_ERROR_FORCE_WAKEUP                        =   8,
    CCIPC_ERROR_USER_EVENT_SIGNALED                 =   9,
    CCIPC_ERROR_INVALID_ARGUMENTS                   =  10,
    CCIPC_ERROR_INVALID_HANDLE                      =  11,
    CCIPC_ERROR_INVALID_CHANNEL                     =  12,
    CCIPC_ERROR_INVALID_CHANNEL_TYPE                =  13,
    CCIPC_ERROR_INVALID_EVENT_NAME                  =  14,
    CCIPC_ERROR_FAILED_CREATE_EVENT                 =  15,
    CCIPC_ERROR_UNKNOWN_EVENT                       =  16,
    CCIPC_ERROR_INVALID_IPC_NAME                    =  17,
    CCIPC_ERROR_FAILED_IPC_SETUP                    =  18,
    CCIPC_ERROR_FAILED_FORCE_CLEANUP                =  19,
    CCIPC_ERROR_ON_WAIT                             =  20,
    CCIPC_ERROR_FRONTEND_KILL                       =  21,
    CCIPC_ERROR_INVALID_FILTER                      =  22,
    CCIPC_ERROR_UNSUPPORTED_IPC_TYPE                =  23,

    /* Format reading/writing errors */
    CCIPC_ERROR_FORMAT_INVALID_VERSION              = 128,
    CCIPC_ERROR_FORMAT_UNDERSIZED_BUFFER            = 129,
    CCIPC_ERROR_FORMAT_UNKNOWN_RECORD_TYPE          = 130,
    CCIPC_ERROR_FORMAT_INVALID_NEXT_INDEX           = 131,
    CCIPC_ERROR_FORMAT_FAILED_STRING_INSERT         = 132,
    CCIPC_ERROR_FORMAT_UNSUPPORTED_CLIENT           = 133,
    CCIPC_ERROR_FORMAT_UNKNOWN_SECTION              = 134,
    CCIPC_ERROR_FORMAT_DEPRECATED_CLIENT_VERSION    = 135,
    CCIPC_ERROR_FORMAT_INVALID_SECTION_SIZE         = 136,
    CCIPC_ERROR_FORMAT_INVALID_BACKTRACE            = 137,
    CCIPC_ERROR_FORMAT_CORRUPT_SECTION              = 138,
    CCIPC_ERROR_FORMAT_CORRUPT_RECORD               = 139,
    CCIPC_ERROR_FORMAT_INVALID_RECORD_CLASS         = 140,

} CCIPCresult;

/* List of possible underlying implementations.
 */
typedef enum {
    CCIPC_TYPE_NONE = 0,
    CCIPC_TYPE_LEGACY,
    CCIPC_TYPE_SHMEM,
    CCIPC_TYPE_FILE,
    CCIPC_TYPE_SHMEM_ALIGN,
    CCIPC_TYPE_UDS,
    CCIPC_TYPE_WNP,

    /* Epilogue for size */
    CCIPC_TYPE_SIZE,
} CCIPCtype;

typedef enum {
    CCIPC_PROP_NONE = 0,
    CCIPC_PROP_OUT_FILE = 1,
    CCIPC_PROP_IN_FILE = 2,
    CCIPC_PROP_TOOLKIT_PID = 3,
    CCIPC_PROP_EVENT_NAME = 4,

    /* Epilogue for size */
    CCIPC_PROP_SIZE
} CCIPCprops;

/* Endpoints in the communication.
 */
typedef enum {
    CCIPC_ENDPOINT_INVALID = 0,
    CCIPC_ENDPOINT_FRONTEND,
    CCIPC_ENDPOINT_DRIVER
} CCIPCendpoint;

typedef enum {
    CCIPC_CHANNEL_TYPE_SEND = 0,
    CCIPC_CHANNEL_TYPE_RECEIVE,
    CCIPC_CHANNEL_TYPE_SIZE
} CCIPCchannelType;

typedef struct CCIPChandle_st CCIPChandle;
typedef struct CCIPCchannel_st CCIPCchannel;
typedef struct CCIPCIAL_st CCIPCIAL;
typedef struct CCIPCackFunctionPointers_st CCIPCackFunctionPointers;
typedef struct CCIPCfd_st CCIPCfd;

/* The abstraction layer provided by the underlying implementation for creation
 * and destruction of the IPC resource.
 */
struct CCIPCIAL_st {
    CCIPCresult (*handleCreate)         (CCIPChandle *handle,
                                         const char *sendName, const char *recvName);
    CCIPCresult (*handleDestroy)        (CCIPChandle *handle);
    CCIPCresult (*handleForceCleanup)   (const char *sendName, const char *recvName);
    CCIPCresult (*channelCreate)        (CCIPCchannel *channel, const char *ipcName);
    CCIPCresult (*channelDestroy)       (CCIPCchannel *channel);
    CCIPCresult (*channelInitialize)    (void *implementation, const char *name);
    CCIPCresult (*channelFinalize)      (void *implementation);
    CCIPCresult (*channelRead)          (void *implementation, void *buf, size_t bufsize,
                                         size_t *readsize, uint32_t timeoutMs);
    CCIPCresult (*channelWrite)         (void *implementation, void *buf, size_t bufsize,
                                         size_t *writesize, uint32_t timeoutMs);
    CCIPCresult (*channelReadFd)        (void *implementation, CCIPCfd *fd, uint32_t timeoutMs);
    CCIPCresult (*channelWriteFd)       (void *implementation, CCIPCfd *fd, uint32_t timeoutMs);
    CCIPCresult (*channelForceCleanup)  (const char *ipcName);

    /* Channel event handling */
    CCIPCresult (*channelEventCreate)       (CCIPCchannel *channel);
    CCIPCresult (*channelEventSignal)       (CCIPCchannel *channel);
    CCIPCresult (*channelEventDestroy)      (CCIPCchannel *channel);
    CCIPCresult (*channelEventIpcCreate)    (CCIPCchannel *channel, const char *eventName, CCIPCendpoint src, CCIPCendpoint dst);
    CCIPCresult (*channelEventIpcDestroy)   (CCIPCchannel *channel);
    CCIPCresult (*channelEventForceCleanup) (const char *eventName, CCIPCendpoint src, CCIPCendpoint dst);
    CCIPCresult (*channelEventGetCuosEvent) (CCIPCchannel *channel, cuosEvent *pEvent);
};

/* Internal representation of an abstract, unidirectional communication
 * channel.
 */
struct CCIPCchannel_st {
    void *implementation;         /* The actual channel implementation. */
    CCIPCIAL* ial;
    char *eventPath;
    cuosEvent event;
    uint32_t eventReady;
    uint32_t forceWakeUp;
    CCIPCchannelType type;
    CCIPChandle *handle;
};

/* A handle for the communication, the only struct a user would deal with.
 * Internally, it consists of two abstract, unidirectional channel which is
 * managed by the channel layer. More channels can be added to accomodate more
 * parties.
 */
struct CCIPChandle_st {
    CCIPCtype type;
    CCIPCendpoint src;
    CCIPCendpoint dst;
    CCIPCIAL ial;
    uint32_t timeoutMs;
    uint32_t messageCount;       /* Used to give unique ID to messages sent by the current endpoint */
    void *implementationData;
    CCIPCchannel channels[CCIPC_CHANNEL_TYPE_SIZE];
    CUOSCriticalSection mutex;
};

/* Structure for passing unix file descriptors/windows handles.
 */
struct CCIPCfd_st {
    uint64_t handle;  /* file descriptor/source handle */
};

/* If pDataReplySize is greater than zero after the function call, the data will be send in the ackowledgement message
   (CCIPCWriteAckBufferFunctionPointer will be called to write pDataReply buffer in this case).
   The correlationId can be set by CCIPCGetAckDataSizeFunction and will be passed to the CCIPCWriteAckDataBufferFunction.
 */
typedef CCIPCresult (*CCIPCGetAckDataSizeFunctionPointer)(CCIPChandle *handle, void *pbuf, size_t size, void *userData,
                                                          uint32_t *correlationId, size_t *pDataReplySize);
typedef CCIPCresult (*CCIPCWriteAckDataBufferFunctionPointer)(void *pDataReply, size_t dataReplySize, void *userData,
                                                              uint32_t correlationId);

struct CCIPCackFunctionPointers_st {
    CCIPCGetAckDataSizeFunctionPointer     getAckDataSize;
    CCIPCWriteAckDataBufferFunctionPointer writeAckDataBuffer;
};

/* Initialize the IPC library, to be called before any other IPC library
 * function.
 */
CCIPCresult
CCIPClibraryInitialize(void);

/* Finalize the IPC library, to be called before the program exits.
 */
CCIPCresult
CCIPClibraryFinalize(void);

/* Allocate an IPC handle and initialize the sending end. All parties must
   agree on a common name and type.
 */
CCIPCresult
CCIPCcreate(CCIPChandle **handle, CCIPCendpoint src, CCIPCendpoint dst, CCIPCtype type,
            uint32_t timeoutMs, const char *sendIpcName, const char *recvIpcName,
            const char *eventName);

/* Deallocate the handle and clean up the receiving end.
 */
CCIPCresult
CCIPCdestroy(CCIPChandle **handle);

CCIPCresult
CCIPCforceCleanup(CCIPCtype type, CCIPCendpoint src, CCIPCendpoint dst,
                  const char *sendIpcName, const char *recvIpcName, const char *eventName);

/* Send 'size' bytes from a buffer.
 */
CCIPCresult
CCIPCsend(CCIPChandle *handle, void *buf, size_t size);

/* Send a message, but only returns if the message has been received
 * (receiver acknowledges the message).
 */
CCIPCresult
CCIPCsendBlocking(CCIPChandle *handle, void *buf, size_t size);

/* Send a message, but only returns if the message has been received (receiver acknowledges the message).
   *pDataReply will be set to a pointer to the buffer with the additional reply data contained in the ackowledgement.
   *pDataReply will be set to NULL, when there is no additional reply data in the ackowledgement.
 */
CCIPCresult
CCIPCsendBlockingWithDataReply(CCIPChandle *handle, void *buf, size_t size, void **pDataReply, size_t *pDataReplySize);

/* Receive message into an allocated buffer and return it. The buffer needs to
   be freed by the user.
 */
CCIPCresult
CCIPCreceive(CCIPChandle *handle, void **pbuf, size_t *size);

/* Send a file descriptor. fd must be a pointer to a valid CCIPCfd structure with
   the file descriptor to be send.
 */
CCIPCresult
CCIPCsendFd(CCIPChandle *handle, CCIPCfd *fd, uint32_t timeoutMs);

/* Receive a file descriptor. fd must be a pointer to a valid CCIPCfd structure and
   contains the received file descriptor after this function returns successfully.
 */
CCIPCresult
CCIPCreceiveFd(CCIPChandle *handle, CCIPCfd *fd, uint32_t timeoutMs);

/* Receive message into an allocated buffer and return it. The buffer needs to be freed by the user.
   If ackFunctionPointers is set, the functions will be called to prepare acknowledgement data for the received message.
 */
CCIPCresult
CCIPCreceiveReplyData(CCIPChandle *handle, void **pbuf, size_t *size, CCIPCackFunctionPointers *ackFunctionPointers, void *userData);

/* Receive message into a buffer that will be allocated. It remains the user's resposibility
   to free this. This variant can also handle an arbitrary array of user defined cuosEvents to
   wait on in addition to the channel event.

   The timeout value contains the time (in ms) to wait for the first event. If 0, this
   will wait forever. Note, secondary events (such as the send of acknowledge messages)
   will retain the original handle timeout.
 */
CCIPCresult
CCIPCreceiveWait(CCIPChandle *handle, void **pbuf, size_t *size, cuosEvent **userEvents, uint32_t numUserEvents, int *userEventIndex, uint32_t timeoutMs);

/* This is similar to Wait, but has an infinite timeout
 */
CCIPCresult
CCIPCreceiveWaitBlocking(CCIPChandle *handle, void **pbuf, size_t *size, cuosEvent **userEvents, uint32_t numUserEvents, int *userEventIndex);

#ifdef __cplusplus
}
#endif

#endif
