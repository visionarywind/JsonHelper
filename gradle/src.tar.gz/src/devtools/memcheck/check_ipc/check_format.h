/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: check_format.h
 *
 *   Description:
 *      Contains functions that can read and write memcheck format
 *      files. The general usage is that error records are created and
 *      packaged at this level
 *      Writing is the conversion of the in-memory form to the on-disk form.
 *      Reading is the conversion of the on-disk form to the in-memory form.
 *
 ******************************************************************************/
#ifndef CHECK_FORMAT_H
#define CHECK_FORMAT_H

#include "cuda_stdint.h"
#include "cudamemcheck.h"
#include "check_ipc.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Struct Typedefs */
typedef struct CCIPCreaderProps_st CCIPCreaderProps;
typedef struct CCIPCrecordHeaderProps_st CCIPCrecordHeaderProps;
typedef struct CCIPCrecordPayloadProps_st CCIPCrecordPayloadProps;
typedef struct CCIPCrecordProps_st CCIPCrecordProps;

/* Flags that are set for error record string to denote their usage */
typedef enum {
    CU_MEMCHECK_RECORD_STRING_NONE      = 0,
    CU_MEMCHECK_RECORD_STRING_PATH      = 0x0001,
    CU_MEMCHECK_RECORD_STRING_NAME      = 0x0002,
    CU_MEMCHECK_RECORD_STRING_ERROR     = 0x0004,
    CU_MEMCHECK_RECORD_STRING_PATH_T0   = 0x0008,
    CU_MEMCHECK_RECORD_STRING_PATH_T1   = 0x0010,
    CU_MEMCHECK_RECORD_STRING_NAME_T0   = 0x0020,
    CU_MEMCHECK_RECORD_STRING_NAME_T1   = 0x0040,

    CU_MEMCHECK_RECORD_STRING_FORCE_SIZE = 0xFFFFFFFFU,
} CUmemcheck_record_string_flags;

typedef enum {
    CCIPC_RECORD_PROPS_NONE = 0,
    CCIPC_RECORD_PROPS_HEADER_DONE = 1,
    CCIPC_RECORD_PROPS_PAYLOAD_DONE = 2,
} CCIPCrecordPropStates;

/* CCIPCreaderProps_st
    Reader properties
*/
struct CCIPCreaderProps_st {
    /* Writen by client before API call */
    CCIPCendpoint   reader;
    uint32_t        clientVersion;
    uint32_t        recordVersion;
};

struct CCIPCrecordHeaderProps_st {
    /* Set after the parseHeader call */
    uint64_t recordSize;
    uint32_t headerRecordVersion;
    uint32_t skipRecord;
    uint32_t possibleMismatch;
    CUmemcheck_record_class recordClass;
};

struct CCIPCrecordPayloadProps_st {
    /* Set after the parseRecord call */
    uint32_t recordid;
    uint32_t parentid;
    uint32_t skippedSections;
    uint32_t parsedSections;
};

/* CCIPCrecordProps_st
    Record properties. The client eneds to be aware of this as fields
    are updated by the API call
*/
struct CCIPCrecordProps_st {
    CCIPCrecordPropStates state;

    /* Set after the parseHeader call */
    CCIPCrecordHeaderProps header;

    /* Set after the parseRecord call */
    CCIPCrecordPayloadProps payload;
};

/** Error record handling  **/
/* Creates a raw record */
CCIPCresult createNewRecord(CUmemcheck_record *err);

/* Creates a new error record of a given type*/
uint32_t createNewErrorRecord(uint32_t type, CUmemcheck_record *err);

/* Creates a new IPC message record of a given type*/
uint32_t createNewIPCMsgRecord(uint32_t type, CUmemcheck_record *err);

/* Get a string by index */
const char*
getStringInRecordByIndex(const CUmemcheck_record *err, const uint32_t index);

/* Cleans up an error record */
void cleanupErrorRecord(CUmemcheck_record *err);

/* Add a string to the record. There are some arbitrary string additions */
uint32_t addStringToErrorRecord(CUmemcheck_record *err, const char *str, uint32_t flags);

/* Add a string to the record at a given index. There are some arbitrary string additions */
CCIPCresult addStringToErrorRecordByIndex(CUmemcheck_record *err, const char *str, uint32_t index, uint32_t flags);

/* Usually this is called as a pair, the first call to get the size of the parameter
 * the second to actually fill it in.
 */

/* getRecordWriteSize
    Returns the size in bytes that the ondisk representation of
    a given record requires. This requires the record version that the write will use
*/
uint64_t getRecordWriteSize(CUmemcheck_record *err, uint32_t recordVersion);

/* generateRecord
    This will fill in a disk record into the buffer at buf. The writer provides
    an memory version of the record, the version of the record to write as well as the
    end point actually doing the writing.
*/
CCIPCresult generateRecord(CUmemcheck_record *err, void *buf, uint64_t size, CCIPCendpoint writer, uint32_t recordVersion);

/* getRecordReadHeaderSize
    Returns the size of the header. This is used by the read clients to determine how
    many bytes to read initially.
 */
uint64_t getRecordReadHeaderSize(CCIPCreaderProps *props);

/* parseHeader
    This parses the basic header at the start of a memcheck error record. The caller
    passes in a buffer containing the raw data of the requested header size.
    The caller also passes in its own version, the version of the record format and the
    expected endpoint for the message.
    The parse call also returns by reference the size in bytes of the following record
    as well as the version of the headerRecord.

    Note recordSize includes the size of the header, so it remains the clients'
    responsibility to read the full thing. This is because the readRecord call
    requires the *entire* record (header + payload)
 */
CCIPCresult parseHeader(void *buf, uint64_t size, CCIPCreaderProps *readerProps, CCIPCrecordProps *recordProps);

/* parseRecord
    This will populate the entire in memory version of the record.
    The caller provides a buffer containing the entire record (header + payload), the expected
    source of the record, its own version, as well as the record format version.
    The caller also provides an allocated but empty memory record structure that is filled up.
    The function returns the id of the record and the id of its parent by reference. This
    gets used to build the parent map.
*/
CCIPCresult parseRecord(void *buf, uint64_t size, CCIPCreaderProps *readerProps, CCIPCrecordProps *recordProps, CUmemcheck_record *err);

#ifdef __cplusplus
}
#endif

#endif

