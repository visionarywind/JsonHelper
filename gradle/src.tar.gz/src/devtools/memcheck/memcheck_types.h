/*
 * Copyright 2007-2014 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: memcheck_types.h
 *
 *   Description:
 *       Shared types
 *
 ******************************************************************************/

#ifndef _MEMCHECK_TYPES_H
#define _MEMCHECK_TYPES_H

/* MCclientVersion
    This is the enum of possible client versions. This is set up
    on the basis of environment variables. This will be used to
    gate backward compatibility for items like printing of error
    records.
*/
typedef enum {
    MC_CLIENT_VERSION_UNKNOWN = 0,  /* Default, cannot recognize client */
    MC_CLIENT_VERSION_DBG,          /* Set if using debugger */
    MC_CLIENT_VERSION_DEPRECATED,   /* 3.1 and older, deprecated */
    MC_CLIENT_VERSION_32,           /* 3.2 Toolkit */
    MC_CLIENT_VERSION_40,           /* 4.0 Toolkit */
    MC_CLIENT_VERSION_41,           /* 4.1 Toolkit */
    MC_CLIENT_VERSION_42,           /* 4.2 Toolkit */
    MC_CLIENT_VERSION_50,           /* 5.0 Toolkit */
    MC_CLIENT_VERSION_55,           /* 5.5 Toolkit */
    MC_CLIENT_VERSION_60,           /* 6.0 Toolkit */
    MC_CLIENT_VERSION_65,           /* 6.5 Toolkit */
    MC_CLIENT_VERSION_70,           /* 7.0 Toolkit */
    MC_CLIENT_VERSION_LATEST,       /* Latest */
} MCclientVersion;

/* RCreportMode
    Racecheck report generation mode
*/
typedef enum {
    RC_REPORT_MODE_NONE = 0,
    RC_REPORT_MODE_HAZARD_ONLY,
    RC_REPORT_MODE_ANALYSIS_ONLY,
    RC_REPORT_MODE_ALL,
} RCreportMode;

typedef enum {
    MC_OUTPUT_TYPE_NONE = 0,
    MC_OUTPUT_TYPE_FILE = 1,
    MC_OUTPUT_TYPE_IPC  = 2,

    MC_OUTPUT_TYPE_SIZE,
} MCoutputTypes;

typedef enum {
    MC_OUTPUT_TYPE_STATE_UNINITIALIZED  = 0,
    MC_OUTPUT_TYPE_STATE_INIT_FAILED,
    MC_OUTPUT_TYPE_STATE_READY,
    MC_OUTPUT_TYPE_STATE_FINALIZED,
} MCoutputTypeStates;

typedef enum {
    MC_MOD_TYPE_NONE = 0,
    MC_MOD_TYPE_USER,
    MC_MOD_TYPE_SYSCALL,
    MC_MOD_TYPE_INTERNAL,
} MCmodType;

typedef enum {
    MC_CONTEXT_STATE_NONE,          //Set after early context init callback
    MC_CONTEXT_STATE_INITIALIZED,   //After context create
    MC_CONTEXT_STATE_CLEAN,         //No new allocations, can reuse existing patches
    MC_CONTEXT_STATE_DIRTY,         //New allocation. Must sync on pending launches
    MC_CONTEXT_STATE_DEINITIALIZED, //Context destroy starting
} MCcontextState;

typedef enum {
    MC_CONTEXT_OPTION_LAUNCH_BLOCKING = 0, // Blocking Launches
    MC_CONTEXT_OPTION_LAUNCH_NONBLOCKING,  // Nonblocking Launches (default on Fermi+)
} MCcontextLaunchMode;

typedef enum {
    MC_DEVICE_TYPE_DGPU = 0,
    MC_DEVICE_TYPE_SOC,
} MCdeviceType;

/* Type enum contains a packed bitfield.
   bit 0 - initialized
   bit 1 - 0 = device function, 1 = entry point
   bit 2 - 0 = user, 1 = syscall
*/
typedef enum {
    MC_FUNC_TYPE_MASK_INIT      = 0x01,
    MC_FUNC_TYPE_MASK_ENTRY     = 0x02,
    MC_FUNC_TYPE_MASK_SYSCALL   = 0x04,
} MCfuncTypeMasks;

typedef enum {
    MC_PATCH_STATE_NONE,        // Default, no state
    MC_PATCH_STATE_INITIALIZED, // Patch basic setup has been done (lmem/reg sizing)
    MC_PATCH_STATE_ACTIVE,      // Patch created and is active
    MC_PATCH_STATE_DIRTY,       // Patch is dirty, must redo creation
    MC_PATCH_STATE_DIRTY_SYNC,  // Patch is dirty and must be syncd first
    MC_PATCH_STATE_FAILED,      // Patch has an internal failure
    MC_PATCH_STATE_LAUNCH_ERROR,  // Patch has a launcherror
    MC_PATCH_STATE_LAUNCH_DONE, // Patch has finished
} MCpatchState;

typedef enum {
    MC_LAUNCH_STATE_NONE = 0,
    MC_LAUNCH_STATE_INITIALIZED = (1 << 0),
    MC_LAUNCH_STATE_ACTIVE      = (1 << 1),
    MC_LAUNCH_STATE_FORCE_SIZE = 0xFFFFFFFFU,
} MClaunchState;

typedef enum {
    MC_INSTR_INFO_NONE = 0,
    MC_INSTR_INFO_ATOMSYS         = (1 << 0),
    MC_INSTR_INFO_COOP_GROUPS     = (1 << 1),
    MC_INSTR_INFO_LEGACY_ATOM_F16 = (1 << 2),
    MC_INSTR_INFO_ATOM16          = (1 << 3),
    MC_INSTR_INFO_WARP_WIDE       = (1 << 4),
} MCinstrInfoFlags;

typedef enum {
    MC_INSTR_INFO_DTYPE_NONE = 0,
    MC_INSTR_INFO_DTYPE_REGID = (1 << 0),
} MCinstrInfoDataType;

/* Memory access checking

 */
typedef enum {
    CC_MEM_ACCESS_ERROR_NONE = 0,
    CC_MEM_ACCESS_ERROR_INVALID_RANGE,
    CC_MEM_ACCESS_ERROR_HEAP_CORRUPTION,
    CC_MEM_ACCESS_ERROR_INVALID_START,
    CC_MEM_ACCESS_ERROR_INVALID_END,
    CC_MEM_ACCESS_ERROR_INTERNAL_ALLOC,
    CC_MEM_ACCESS_ERROR_OVERFLOW,
    CC_MEM_ACCESS_ERROR_UNDERFLOW,
    CC_MEM_ACCESS_ERROR_UNINITIALIZED_DEVICE_DATA
} CCmemAccessErrorType;

typedef enum {
    CC_MEM_UNUSED_ERROR_NONE = 0,
    CC_MEM_UNUSED_ERROR_NOT_WRITTEN,
} CCmemUnusedErrorType;

typedef enum CCmemAccessType_enum {
    CC_MEM_ACCESS_TYPE_INVALID = 0,
    CC_MEM_ACCESS_TYPE_MEMCPY_SRC,
    CC_MEM_ACCESS_TYPE_MEMCPY_DST,
    CC_MEM_ACCESS_TYPE_MEMSET,
    CC_MEM_ACCESS_TYPE_STREAM_WRITE,
} CCmemAccessType;

typedef enum {
    CC_CLEANUP_MODE_HOST_AND_DEVICE = 0,
    CC_CLEANUP_MODE_HOST_ONLY       = 1,
} CCcleanupMode;

typedef enum {
    MC_INST_ADDR_SPACE_NONE = 0,
    MC_INST_ADDR_SPACE_GENERIC,
    MC_INST_ADDR_SPACE_GLOBAL,
    MC_INST_ADDR_SPACE_SHARED,
    MC_INST_ADDR_SPACE_LOCAL,
} MCinstAddrSpace;

typedef enum {
    MC_ATOM_SCOPE_NONE = 0,
    MC_ATOM_SCOPE_CTA,
    MC_ATOM_SCOPE_SM,
    MC_ATOM_SCOPE_VC,
    MC_ATOM_SCOPE_GPU = MC_ATOM_SCOPE_VC,
    MC_ATOM_SCOPE_SYS,
} MCatomScope;

typedef enum {
    MC_INST_SOURCE_TYPE_UNKNOWN                = 0,
    MC_INST_SOURCE_TYPE_REGISTER               = (1 << 0),
    MC_INST_SOURCE_TYPE_IMMEDIATE              = (1 << 1),
    MC_INST_SOURCE_TYPE_CBANK                  = (1 << 2),
    MC_INST_SOURCE_TYPE_UNIFORM_REGISTER       = (1 << 3),
    MC_INST_SOURCE_TYPE_CBANK_UNIFORM_REGISTER = (1 << 4),
} MCinstSourceType;

#include "check_core.h"
#include "cuda.h"
#include "memobj.h"
#include "cuda_etbl/tools_callbacks.h"
#include "cuda_etbl/tools_callback_arbiter.h"
#include "cuda_etbl/tools_device.h"
#include "cuda_etbl/tools_memory.h"
#include "cuda_etbl/tools_context.h"
#include "cuda_etbl/tools_link.h"
#include "cuda_etbl/tools_module.h"
#include "cuda_etbl/tools_memcopy.h"
#include "cuda_etbl/tools_pushbuffer.h"
#include "cuda_etbl/tools_trap_handler.h"
#include "cuda_etbl/tools_uvm8_events.h"
#include "cuda_etbl/tools_graph.h"
#include "nvtypes.h"
#include <string.h>
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>

#include "hash.h"
#include "cudamemcheck.h"
#include "cudbgdriver.h"
#include "halo.h"
#include "memcheck_tool_modes.h"
#include "cuimutex.h"
#include "memcheck_dynamic.h"
#include "check_mem.h"

#include "check_patch_core.h"
#include "check_backtrace.h"
#include "check_ipc.h"
#include <check_dbg_interop.h>

#include "tools_shared_list.h"
#include "tools_shared_hashmap.h"
#include "tools_shared_rwlock.h"
#include "check_filter.h"

/*
  memcheck: CUDA memory access checker

  This tool binary patches every kernel launch to compare every global
  load and store address with a table of global memory allocations. If
  an address is found to be unallocated this tool dumps the offending
  address and some corresponding information to a file.

  This tool is initialized during cuiinit(). memcheckinit() registers
  for the Tools API callbacks and obtains the Tools API export tables.

  When a new context is created this tool initializes the list of
  global memory allocations and opens an output file. Any subsequently
  encountered context is ignored.

  The globalAlloc and globalFree callbacks update the list of global
  memory allocations.

  Most of the work is performed just before and after a kernel
  launch. Preceeding each launch (beforeFunctionSetup()) this tool
  allocates all of the device memory it needs. This includes memory
  for the global memory allocation table, for reporting error
  information, and for function patches. It also allocates additional
  host memory as a staging area. The only state that is persistent
  between launches is the global memory allocation table residing on
  the host.

  beforeFunctionSetup() also creates a patched copy of the function
  and the patches themselves.

  At this point the function in device memory has still been
  unaltered. During beforeGridLaunched() this tool downloads the
  patched function and sets a new start offset, thus enabling the
  address checking.

  During afterGridLaunched() this tool restores everything to its
  prelaunch condition. If any error information was written to device
  memroy it is then dumped to the output file.
*/

// TODO: Can do something fancy with 2D allocations where we track each row separately

/* MCtools_st
   Function tables used to access the driver through the Tools API
*/
struct MCtools_st {
    CUtoolsCbSubscriberHandle          subscriberHandle;
    const CUetblToolsCallbackArbiter  *callbacks;
    const CUetblToolsDevice           *device;
    const CUetblToolsMemory           *memory;
    const CUetblToolsContext          *context;
    const CUetblToolsModule           *module;
    const CUetblToolsMemCopy          *memcpy;
    const CUetblToolsPushBufferHal    *pushBufferHal;
    const CUetblToolsTrapHandler      *trap;
    const CUetblToolsCnp              *cnp;
    const CUetblToolsUvm8Events       *uvm8;
    const CUetblToolsLink             *link;
    const CUetblToolsGraph            *graph;
};

/* Hardware Abstraction Layer */

struct MChal_st {
    MCtoolModeArchs arch;
    uint64_t   maxJumpOffset;
    uint32_t   savedSPAddr;         // Address of saved stack pointer
    uint32_t   cnpReservedLmemStart; // Starting address in LMEM of reserved space
    uint32_t   cnpReservedLmemSize; // Size of cnp reservation
    uint32_t   gridParamsConstBank;
    uint32_t   gridParamsUserStackTopOffset;
    uint32_t   gridParamsSWinLoOffset;
    uint32_t   driverInternalParamsConstBank;
    uint32_t   driverInternalParamsShmemSizeOffset;

    uint32_t (*getInstSize)(void);
    uint32_t (*getRz)      (void);
    uint32_t (*getURz)     (void);

    bool     (*isGtasLd)   (const uint64_t *op);
    bool     (*isGtasSt)   (const uint64_t *op);
    bool     (*isLdg)      (const uint64_t *op);
    bool     (*isStg)      (const uint64_t *op);
    bool     (*isLds)      (const uint64_t *op);
    bool     (*isSts)      (const uint64_t *op);
    bool     (*isLdl)      (const uint64_t *op);
    bool     (*isStl)      (const uint64_t *op);
    bool     (*isRed)      (const uint64_t *op);
    bool     (*isAtom)     (const uint64_t *op);
    bool     (*isAtomS)    (const uint64_t *op);
    bool     (*isAtomG)    (const uint64_t *op);
    bool     (*isAbsoluteCall) (const uint64_t *op);
    bool     (*isRelativeCall) (const uint64_t *op);
    bool     (*isIndirectCall) (const uint64_t *op);
    bool     (*isSynchronizingBarrier)  (const uint64_t *op);
    bool     (*isWarpSync) (const uint64_t *op);
    bool     (*isShfl    ) (const uint64_t *op);
    bool     (*isExit)     (const uint64_t *op);
    bool     (*isRet)      (const uint64_t *op);
    bool     (*isJmx)      (const uint64_t *op);
    bool     (*isNop)      (const uint64_t *op);
    bool     (*isWrite)    (const uint64_t *op);

    bool     (*hasPlg)     (const uint64_t *op);
    bool     (*hasUniformRegister) (const uint64_t *op);

    void (*genAbsoluteCall) (uint64_t addr, bool callDepth, uint32_t ra, uint64_t *out);
    void (*genRet)     (uint64_t addr, bool callDepth, uint32_t ra, uint64_t *out);
    void (*genMov)     (uint32_t rdest, uint32_t rsrc, uint64_t *out);
    void (*genMovFromImm) (uint32_t rdest, uint32_t imm, uint64_t *out);
    void (*genMovFromUR) (uint32_t rdest, uint32_t rsrc, uint64_t *out);
    void (*genMovCBank)(uint32_t rdest, uint32_t cBank, uint32_t cOffset, uint64_t *out);
    void (*genMovCBankUR)(uint32_t rdest, uint32_t urb, uint32_t offset, uint64_t *out);
    void (*genJmp)     (uint64_t addr, uint64_t *out);
    void (*genLongJmpWithPredCC) (const uint64_t *op, uint64_t *out);
    void (*genRetWithPredCC)     (const uint64_t *op, uint64_t *out);
    void (*genPlgRawInv)         (const uint64_t *op, uint64_t *out);
    void (*genCsetp)             (uint32_t test, uint32_t pred, uint64_t *out);

    uint32_t (*getRa)           (const uint64_t *op);
    uint32_t (*getRb)           (const uint64_t *op);
    uint32_t (*getURb)          (const uint64_t *op);
    uint32_t (*getCcTest)       (const uint64_t *op);
    uint64_t (*getPredRawInv)   (const uint64_t *op);
    uint64_t (*getPredMask)     (const uint64_t *op);
    uint32_t (*getPredWithInv)  (const uint64_t *op);
    uint32_t (*getPnzInvAsPgMask) (const uint64_t *op);
    bool     (*getExtended)     (const uint64_t *op);
    bool     (*getU64)          (const uint64_t *op);
    uint32_t (*getOffset)       (const uint64_t *op);
    uint32_t (*getCBank)        (const uint64_t *op, uint32_t *bank, uint32_t *offset);
    uint32_t (*getMemAccessSize)(const uint64_t *op, const MCfunc *func, const uint64_t pc);
    MCatomScope (*getAtomScope) (const uint64_t *op);
    uint64_t (*getControlFlowImm)   (const uint64_t *op, bool *isSigned);
    bool     (*getControlFlowDepth) (const uint64_t *op);
    bool     (*getRetIsAbs)     (const uint64_t *op);
    uint32_t (*getInstSourceType) (const uint64_t *op);
    uint32_t (*getStrideShift)  (const uint64_t *op);

    bool     (*barHasThreadCount)   (const uint64_t *op);
    uint32_t (*barGetNameReg)       (const uint64_t *op);
    uint32_t (*barGetNameImm)       (const uint64_t *op);
    uint32_t (*barGetCountReg)      (const uint64_t *op);
    uint32_t (*barGetCountImm)      (const uint64_t *op);

    void     (*genLmemHiSpill)          (uint32_t lmemHiOff, uint32_t asize, uint32_t regb, uint64_t *out);
    void     (*genLmemHiRead)           (uint32_t lmemHiOff, uint32_t asize, uint32_t regd, uint64_t *out);
    void     (*genBreakInstruction)     (MCrec* rec, uint64_t *out);
    void     (*genTexDrainInstruction)  (MCrec* rec, uint64_t *out);
    CUresult (*patchTrampoline)         (CCmemHandle *mem, uint64_t targetAddr, MCcontext *mcctx);
    bool     (*isPcInRange)             (uint64_t patchPC, MCrec *rec);

    uint32_t (*isDirectCall)    (const uint64_t *op);
    CUresult (*prescanFunction) (MCfunc *func, MCcontext *mcctx);
    bool     (*isValidCodeAddr) (uint64_t addr);
    CUresult (*patchJumpPoint)  (MCcontext *mcctx, CCmemHandle *mem, uint64_t instOffset, uint64_t targetAddr);
    CUresult (*patchAbsoluteCallPoint) (MCcontext *mcctx, CCmemHandle *mem, uint64_t instOffset, uint64_t targetAddr);
    CUresult (*patchLongjmp)    (MCcontext *mcctx, CCmemHandle *mem, uint64_t instOffset);

    MCinstAddrSpace (*getOpcodeMemcheckAddrSpace) (CCIRinstOpcodes opcode);

    void     (*setRegCountInQmd)(NvU32 *qmdData, unsigned int regCount);

    uint64_t (*getInputPredRawInv)  (const uint64_t *op);
    uint64_t (*getInputPredMask)    (const uint64_t *op);
    uint32_t (*getInputPredWithInv) (const uint64_t *op);

};

/* MCclientOptions_st
    Client options
*/
struct MCclientOptions_st {
    MCclientVersion     version;
    uint32_t            recordVersion;
    uint32_t            build;
    bool                flushToDisk:1; /* Used only by legacy path */
    uint32_t            outputTypeMask;
    char                outputFileName[CUOS_ENV_VAR_LENGTH];
    uint32_t            ipcType;
    char                ipcToolkitPid[CUOS_ENV_VAR_LENGTH];
    char                eventName[CUOS_ENV_VAR_LENGTH];
    char                ipcInputFileName[CUOS_ENV_VAR_LENGTH];
    char                ipcOutputFileName[CUOS_ENV_VAR_LENGTH];
    CCfilterMgr         *filterMgr;  /* Manages Filters */
};

/* MCoptions_st
   Stores the options set for memcheck
*/
struct MCoptions_st {
    /************* Client options ***************/
    MCclientOptions client;

    /************ User set options **************/

    // Set if cuda-memcheck should stop on first error.
    // Unset if --continue option was specified
    bool forceError:1;
    // Set if the output format should be binary file
    // This option is always set
    bool rawOutput:1;
    // Set when memcheck is spawned by the debugger.
    // This flag implies that reportHWErrors must be disabled
    bool debuggerAttached:1;
    // Set if memcheck should report hardware errors on Fermi and above
    // This is set by default on CUDA 3.2+
    bool reportHWErrors:1;
    // Set if memcheck should allow nonblocking launches. Only set on Fermi and above
    bool nonblockingLaunch:1;
    // Set if user has requested dynamic memcheck
    bool requestedDynamic:1;
    // Set by the user about which scheme is requested
    uint32_t requestedScheme;

    // Host side leak info
    bool enableCudaMallocLeakInfo:1;
    // Device heap leak info
    bool enableDevHeapLeakInfo:1;

    // Enable host backtraces for : Precise errors, Leaks, API errors
    bool enableHostBacktrace:1;
    // Enable device backtraces for precise errors
    // NOTE - REQUIRES nonblocking launches with traphandler
    bool enableDeviceBacktrace:1;
    // Maximum host depth. On windows, limited to 61
    uint32_t backtraceMaxHostDepth;
    // Maximum device depth. Default is infinite
    uint32_t backtraceMaxDevDepth;

    // Enable SASS patching
    bool enableSassPatching:1;
    // Check memcopies/memsets. Note that when dynamic memcheck is
    // requested, this will automatically enable heap memcopy
    // checking
    bool checkMemcpyMemset:1;

    // Report errors on FatBinary loads by the runtime.
    // Note, this also requires that API error checking be enabled
    bool reportFatBinaryLoadErrors:1;
    // Enable UVM support for the frontend
    bool frontendRequiresUvm:1;
    // Enable checks for deprecated instructions
    bool checkDeprecatedInstr:1;

    /*********  Internal modes and options ******/
    MCtoolModeType toolModeType;

    // Racecheck reporting mode
    RCreportMode raceReportMode;

    // Global map mode
    CCmemMapMode memMapMode;

    // Set if the HALO should be used
    // This is set by default on standalone
    // This is cleared on AMODEL and integrated
    // The memMapMode can be either _HALO or _FORCED (WDDM)
    bool useHalo:1;

    // Set if the API error checking is enabled
    bool enableApiCheck:1;

    // Enable memcheck on internal kernels (memset, syscalls)
    bool debugInternals:1;
    // Dump SASS code for the original function, patched function and patch
    bool printCubins:1;
    // Is running on an AMODEL gpu
    bool isAmodel:1;
    // Enable texdepbar
    bool forceTexDrain:1;

    // Force flush to write through to disk
    // (or at least tell the OS to make the attempt)
    bool flushToDisk:1;

    // Enable unused memory test
    bool enableUnusedMemory:1;
};

#define mcLock(gvars) cuiMutexLock(&(gvars)->globalsMutex)
#define mcUnlock(gvars) cuiMutexUnlock(&(gvars)->globalsMutex)

/* MCoutputType_st
    Per output type structure
*/
struct MCoutputType_st {
    MCoutputTypes type;
    MCoutputTypeStates state;
    uint32_t recordVersion;
    CUImutex outMutex;
    union {
        struct {
            FILE *outputFile;
            char *filename;
            bool flushToDisk;
        } file;
        struct {
            CCIPChandle *handle;
            CCIPCendpoint src;
            CCIPCendpoint dst;
            CCIPCtype     type;
            char    *srcName;
            char    *dstName;
            char    *eventName;
        } ipc;
    } cases;
};

/* MCoutput_st
    Output modes and per mode information
*/
struct MCoutput_st {
    uint32_t enabledMask;
    MCglobals *globals;
    MCoutputType types[MC_OUTPUT_TYPE_SIZE];
};

/* MCglobals_st
   Global memcheck state
*/
struct MCglobals_st {
    CUOSTLSEntry tlsEntry;
    CUImutex    globalsMutex;
    tHashMap *contexts;
    MCoutput output;
    MCtools tools;
    MCoptions options;
    uint32_t initialized;
    uint32_t haloInitialized;
    uint32_t uvm8Supported;
    bool modUnsupportedWarned;
    bool modUsesLegacyAtomF16Warned;
    bool racecheckOverflowDetected;
    MCtoolMode toolMode;
};

struct MCmodOptions_st {
    CCpatchScopeTypes defaultScope;     // Default patch scope
    uint32_t    usesCnp;
    bool        usesCooperativeGroups;
    bool        usesLegacyAtomF16;
    bool        usesAtom16;
    bool        usesWarpWideInstructions;
};

/* MCmod_st
   Holds the debug ELF image passed from the driver
*/
struct MCmod_st {
    tHashMap    *funcs;       // Functions (CUfunc*->MCfunc*)
    tHashMap    *funcNames;   // Function Name->MCfunc
    CUmod       *cumod;       // CUmod
    void        *image;
    MCcontext   *context;
    uint32_t    abiVersion;
    MCfunc      *funcList;
    MCmodType   type;       // Type of module
    MCmodOptions   modOpts;

    /* HALO interop */
    DeviceModule    haloMod;
};

struct MCcontextOptions_st {
    MCcontextLaunchMode launchMode;
    CCBacktraceOptions  btopts; // Backtrace options
    MCdeviceType        deviceType;
    tList               *filters;   // Filters
};

/* MCcontext_st
   Holds the context specific data */
struct MCcontext_st {
    MCcontextOptions ctxOpts;   // Context wide options
    MCglobals   *gvars;         // Pointer to gvars
    CUctx       *cuctx;         // CU context
    uint32_t    sm_version;     // SM version : major * 100 + minor
    tHashMap    *launches;      // grid id->Launch
    tHashMap    *patches;       // cufunc->rec
    tHashMap    *mods;          // Modules
    CudbgDevice dev;            // Device
    CUImutex    ctxMutex;       // Mutex for context
    volatile toolsRWLock rwlock;// Reader/Writer lock
    MCcontextState state;       // State of context
    CUmap       patchMemMap;    // Map from dptr->patch
    CUmap       funcMemMap;     // Map from dptr->mcfunc
    CUmap       syscallMemMap;  // Map of syscalls
    tHashMap    *internalMods;  // Internal modules Hash (CUmod* -> MCmod*)
    MCDynamic   *dynamic;       // Pointer to dynamic structures
    MCrec       *patchList;     // Pointer to list of patches
    MClaunch    *launchList;    // List of launches
    MChal       hal;            // The memcheck hal
    MCinstManager *instMgr;     // Patch abstractions
    CCpatchScopeMgr *scopeMgr;  // Patch scope manager
    CCfilterMgr *filterMgr;     // Filter Manager
    tList       *streamList;    // List of deferred streams
    bool supportsHostNativeAtomic:1; // True if coherent atomic to host memory is supported (NVLINK2+)
    CCallocTable *ctxAllocs;    // List of allocations in context
    CCalloc     *heapAlloc;     /* This is context global */
    CCalloc     *cnpParamAlloc;     /* This is context global */
    CUmemcheck_record *errList;

    CUmemcheck_record *hazardList;
    CUmemcheck_record *analysisList;

    MCtoolModeCtxData tm;      // Tool mode Context data

    /* WAR bug 1806445 */
    tHashMap    *bug1806445Map; // map<CUmod -> map<PC -> originalInstruction> >

    tList *trampolinePcs;       // List of trampoline PCs

    /* HALO interop */
    Context     haloContext;
};

/* MCinstrInfoData_st
   Common base for all instr info data structs.
   Use type field to cast to concrete struct. */
struct MCinstrInfoData_st {
    MCinstrInfoDataType type;
    struct MCinstrInfoData_st *next;
};

/*
 * MCinstrInfoDataRegId_st
 * Variant of MCinstrInfo_st with type == MC_INSTR_INFO_DTYPE_REGID.
 */
struct MCinstrInfoDataRegId_st {
    MCinstrInfoDataType type;
    struct MCinstrInfoData_st *next;
    uint16_t regId;
};

/* MCinstrInfo_st
   Holds instr/pc-specific data
 */
struct MCinstrInfo_st {
    uint64_t pc;            // fully-qualified program counter
    uint32_t flags;         // Bitwise-or combination of MCinstrInfoFlags
    MCinstrInfoData *data;  // single-linked list of misc associated data
};

/* MCfunc_st
   Holds the function specific data
*/
struct MCfunc_st {
    CUfunc      *cufunc;        // CUfunc
    MCcontext   *context;       // Context
    MCmod       *mod;           // Module
    const char  *funcName;      // Function name
    CCmemHandle mem;            // MemHandles
    MemBlockHandle  memblock;   // Memblock
    CCfilterMatch filterMatch;  // Store the filter matching state.
    tHashMap *instrInfo;        // Additional information per pc (uint64_t -> MCinstrInfo*)

    uint32_t    type;           // Type of function
    uint32_t    hasTextures;
    uint32_t    usesCnp;
    uint32_t    usesCnpJoin;
    uint32_t    patchLongjmpToExit;

    uint32_t    numIndirectCalls;    // Number of indirect calls (JMX, CALL.ABS Rx on Volta+)
    uint32_t    hasElidedAtomSys;    // Has at least one elided system-scoped atomic instr offset
    uint32_t    hasCoopGroupOffsets; // Has at least one instr offset related to cooperative groups (e.g. elided warpsync)
    uint32_t    hasLegacyAtomF16Offsets; // Has at least one legacy instr offset related to atomic operation on f16
    uint32_t    hasAtom16RegMap;     // Has a map of offset -> register id for 16-bit atomic operations
    uint32_t    hasWarpWideOffsets;  // Has at least one warp wide instr offset

    uint32_t    usesMalloc;     // Uses malloc()
    uint32_t    usesFree;       // Uses free()


    MCfunc *next;               // Next func in module

    /* HALO interop */
    DeviceFunction  haloFunc;
};

/* MCrec_st
   Records the state of a CUDA context
   Most of these fields are handles to data structures that memcheck creates before
   each kernel launch to enable memory address checking.
*/
struct MCrec_st {
    MCglobals *gvars; // Convenient pointer to the globals

    CudbgDevice dev;  // Pointer to the device. Set up at launch
    MCtools *tools;

    MCoptions options;

    // Pointer to function
    MCfunc      *func;

    // Pointer to context
    MCcontext   *context;

    // Global memory allocation linked list copy
    CCallocTable *globalAllocs;

    // Device global memory allocation table (Used in Memcheck + Racecheck)
    CCmemHandle deviceTable;

    // Error entry (Zero copy memory)
    CCmemHandle errorEntry;

    // Host copies of function
    CCmemHandle funcBuffer;

    // Patch memory
    CCmemHandle patchBuffer;

    // Internal per patch persistent state, used while patching
    // patchBufferPtr - current pointer inside the patch buffer
    uint64_t    *patchBufferPtr;
    // Pointer to the checkType that generates the prologue
    MCcheckType *prologueType;
    // Offsets of all the checkTypes in the patch buffer
    uint32_t patchOffsets[MC_CHECK_TYPE_SIZE];

    // Setup to modify the entry point
    uint32_t patchOffset;
    uint64_t patchEntry;

    // State
    MCpatchState state;

    // Cache the launch config info
    CUtoolsFunctionLaunchConfig config;
    CUtoolsFunctionLaunchConfig origConfig;

    uint64_t origPC;

    // Pointer to next patch on the list
    MCrec *next;
    MCrec *prev;

    // refcount of outstanding launches
    uint32_t launchCount;

    // Toolmode specific data
    MCtoolModeRecData tm;

    /* Interop patch list */
    CCdbgInteropPatch *interopPatchList;

    /* Stash of the previous stream id */
    uint64_t previousStreamId;
};

/* MClaunch_st
   Stores per launch state
*/
struct MClaunch_st {
    uint64_t gridid;    // Grid id of the current launch
    uint64_t streamid;  // Stream id of the current launch
    MCrec    *rec;      // Rec for this launch
    MCfunc   *func;     // Function corresponding to launch
    MClaunchState state;    // State of Launch

    MClaunch *next;     // Next in list of launches
    MClaunch *prev;     // Prev in list of launches

    CCBacktrace *bt;    // For host backtrace support
    /* HALO interop */
    Grid    haloGrid;
};

struct CCmemAccessError_st {
    CCmemAccessErrorType type;
    uint64_t addr;
    uint64_t size;
    bool foundNear;
    uint64_t allocAddr;
    uint64_t allocSize;
    uint64_t badAddr;
};

void memcheckInitHal_common(MChal *hal, MCtoolModeArchs arch);

#if cuiNvcfgEnabledFermiOrHigher()
void memcheckInitHal_fermi(MChal *hal, MCtoolModeArchs arch);
#endif

#if NVCFG(GLOBAL_ARCH_KEPLER)
void memcheckInitHal_kepler_gk10x(MChal *hal, MCtoolModeArchs arch);
void memcheckInitHal_kepler_gk11x(MChal *hal, MCtoolModeArchs arch);
#endif

#if NVCFG(GLOBAL_ARCH_MAXWELL)
void memcheckInitHal_maxwell_gm10x(MChal *hal, MCtoolModeArchs arch);
void memcheckInitHal_maxwell_gm20x(MChal *hal, MCtoolModeArchs arch);
#endif

#if NVCFG(GLOBAL_ARCH_PASCAL)
#if NVCFG(GLOBAL_GPU_FAMILY_GP10X)
void memcheckInitHal_pascal_gp10x(MChal *hal, MCtoolModeArchs arch);
#endif
#endif

#if NVCFG(GLOBAL_ARCH_VOLTA)
#if NVCFG(GLOBAL_GPU_FAMILY_GV10X) || NVCFG(GLOBAL_GPU_FAMILY_GV11X)
void memcheckInitHal_volta_gv10x(MChal *hal, MCtoolModeArchs arch);
#endif
#endif

#if NVCFG(GLOBAL_ARCH_TURING)
void memcheckInitHal_turing_tu10x(MChal *hal, MCtoolModeArchs arch);
#endif

#if NVCFG(GLOBAL_ARCH_AMPERE)
void memcheckInitHal_ampere_ga10x(MChal *hal, MCtoolModeArchs arch);
#endif

CUresult haloCheckTrapStateInitialize(MCcontext *mcctx);
void     haloCheckTrapStateFinalize(MCcontext *mcctx);
#endif
