/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: memcheck.c
 *
 *   Description:
 *       When enabled, patches CUDA functions to perform
 *       memory access checking
 *
 ******************************************************************************/
#include "check_core.h"
#include "memcheck.h"
#include "memcheck_types.h"
#include "memcheck_error.h"
#include "memcheck_tool_modes.h"
#include "halo.h"
#include "halo_client_memcheck.h"
#include "halo_state.h"
#include "cuictx.h"

#include "memmgr.h"
#include "cuda_types.h"
#include "memblock.h"

#include "tools_shared.h"
#include "memcheck_halo.h"

#include "memcheck_inst_types.h"
#include "check_alloc.h"
#include "check_mc_context.h"
#include "check_mc_func.h"
#include "check_mc_module.h"
#include "check_tool_common.h"
#include "memcheck/memcheck_structs.h"
#include "fermi_mcinterop.h"
#include "volta_mcinterop.h"

CCmemcheckCtxData*
memcheckGetCtxData(MCcontext *mcctx)
{
    return (CCmemcheckCtxData*)mcctx->tm.ptr[MC_TOOL_MODE_MEMCHECK];
}

CCmemcheckRecData*
memcheckGetRecData(MCrec *rec)
{
    return (CCmemcheckRecData*)rec->tm.ptr[MC_TOOL_MODE_MEMCHECK];
}

static CUresult
memcheckGetInternalModules(MCrec *rec, tList **mods)
{
    CCmemcheckRecData *recData = NULL;

    if (!rec || !mods) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = memcheckGetRecData(rec);
    if (!recData)
        *mods = NULL;
    else
        *mods = recData->internalModules;

    return CUDA_SUCCESS;
}

static CUresult
memcheckGetExceptionType(uint32_t magic, CUDBGException_t *exception)
{
    if ((magic & FERMI_MEMCHECK_WHITEMAGIC_MASK) == FERMI_MEMCHECK_WHITEMAGIC) {
        if (magic & FERMI_MEMCHECK_SYSCALL_MASK)
            *exception = CUDBG_EXCEPTION_LANE_SYSCALL_ERROR;
        else {
            if (magic & FERMI_MEMCHECK_ATOMSYS_MASK)
                *exception = CUDBG_EXCEPTION_LANE_INVALID_ATOMSYS;
            else
                *exception = CUDBG_EXCEPTION_LANE_ILLEGAL_ADDRESS;
        }
    }

    return CUDA_SUCCESS;
}

/* Allocates host memory for the error entry and maps it on the
   device. It is allocated on host in case a launch failure tears down
   the context */
static CUresult
createDeviceErrorEntry(MCrec *rec)
{
    CUresult r = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    rec->errorEntry.size = rec->context->instMgr->getErrorEntrySize(rec->context->instMgr, rec);
    if (rec->errorEntry.size == 0) {
        CU_ERROR_PRINT(("Failed to get error entry size\n"));
        return CUDA_ERROR_UNKNOWN;
    }
    rec->errorEntry.mcctx = rec->context;
    rec->errorEntry.devseg = HALO_MEM_SEG_PINNED_SYSMEM;

    r = CCallocateDevice(&rec->errorEntry, NULL);
    if (r != CUDA_SUCCESS) {
        printInternalError(CU_MEMCHECK_ERROR_OUT_OF_DEVICE_MEMORY,
                           rec->gvars);

        CU_ERROR_PRINT(("\n"));
        return r;
    }

    memset(rec->errorEntry.dev.hPtr, 0, (size_t)rec->errorEntry.size);

    return r;
}

/* Allocates space on the device for the global memory allocation
   table. Each entry consists of the start address and the end address
   for that allocation. The list is null-terminated */
static CUresult
createDeviceTable(MCrec *rec)
{
    CUresult r;
    uint32_t size = 0;

    CU_TRACE_FUNCTION();
    CU_ASSERT(rec);
    CU_ASSERT(rec->globalAllocs);

    size += CCallocTableGetSize(rec->globalAllocs);

    // The patch code uses a fixed-size of 4 bytes for each value, plus one extra *null* entry
    rec->deviceTable.size = (size+1) * 2 * 4;
    rec->deviceTable.mcctx = rec->context;
    rec->deviceTable.devseg = HALO_MEM_SEG_GLOBAL;

    r = CCallocateDevice(&rec->deviceTable, NULL);
    if (r != CUDA_SUCCESS) {
        printInternalError(CU_MEMCHECK_ERROR_OUT_OF_DEVICE_MEMORY,
                           rec->gvars);

        CU_ERROR_PRINT(("\n"));
    }

    return r;
}

typedef struct fillFunctorData_st fillFunctorData;
struct fillFunctorData_st {
    uint32_t *offset;
};

static CUresult
fillTableHost(CCallocTable *table, CCalloc *alloc, void *data)
{
    fillFunctorData *fd = NULL;

    if (!alloc || !data) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    fd = (fillFunctorData*)data;

    *fd->offset++ = (uint32_t)CCallocGetStart(alloc);
    *fd->offset++ = (uint32_t)CCallocGetEnd(alloc);

    return CUDA_SUCCESS;
}

/* Copy each entry from the global memory allocation linked list to the array on the device */
static CUresult
downloadTable(MCrec *rec, CUtoolsStreamHandle stream)
{
    CUresult res = CUDA_SUCCESS;
    uint32_t *offset; // XXX Yeah, this is broken on 64-bit, but we don't use the table there
    fillFunctorData fd;

    CU_TRACE_FUNCTION();

    CU_ASSERT(rec->globalAllocs);

    if (rec->deviceTable.dev.state != CC_MEM_STATE_ALLOCATED)
        return CUDA_ERROR_UNKNOWN;

    res = CCallocateHost(&rec->deviceTable);
    if (res != CUDA_SUCCESS) {
        printInternalError(CU_MEMCHECK_ERROR_OUT_OF_HOST_MEMORY,
                           rec->gvars);

        return res;
    }

    offset = (uint32_t*)rec->deviceTable.host.ptr;
    fd.offset = offset;
    memset(rec->deviceTable.host.ptr, 0, (size_t)rec->deviceTable.size);

    res = CCallocTableApplyFunctor(rec->globalAllocs, fillTableHost, &fd);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to fill host version of table\n"));
        return res;
    }
    offset = fd.offset;

    /* Last NULL entry (already zero but make explicit the need for it */
    *offset = 0;

    res = rec->tools->memcpy->MemcpyInlineHtoD(rec->context->cuctx, stream,
                                               rec->deviceTable.dev.memobj, 0,
                                               (const void*) rec->deviceTable.host.ptr,
                                               (size_t)rec->deviceTable.size);
    if (res != CUDA_SUCCESS) {
        printInternalError(CU_MEMCHECK_ERROR_DEVICE_MEM_ACCESS_FAILED,
                           rec->gvars);

        CU_ERROR_PRINT(("\n"));
    }

    CCfreeHost(&rec->deviceTable);

    return res;
}

typedef struct {
    MCdevAlloc **allocTableRef;
    uint64_t lastStart;
} CopyAllocEntryData;

static CUresult copyAllocEntry(CCallocTable *table, CCalloc *alloc, void *data)
{
    CopyAllocEntryData *copyData = (CopyAllocEntryData*)data;
    MCdevAlloc **allocTableRef = copyData->allocTableRef;
    MCdevAlloc *allocTable = NULL;
    if (!allocTableRef)
        return CUDA_ERROR_UNKNOWN;

    allocTable = ++(*allocTableRef);
    allocTable->start = CCallocGetStart(alloc);
    allocTable->size = CCallocGetSize(alloc);

    if (CCallocIsManaged(alloc))
        allocTable->flags |= MC_DEVALLOC_MANAGED;

    if (CCallocIsHostPinned(alloc))
        allocTable->flags |= MC_DEVALLOC_HOST_PINNED;

    if (CCallocIsPeer(alloc))
        allocTable->flags |= MC_DEVALLOC_PEER;

    if (CCallocIsPeerAtomic(alloc))
        allocTable->flags |= MC_DEVALLOC_PEER_ATOMIC;

    if (copyData->lastStart && allocTable->start <= copyData->lastStart) {
        CU_ERROR_PRINT(("Alloc table is not sorted ascending\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    copyData->lastStart = allocTable->start;

    CU_DEBUG_PRINT(("alloc: 0x%" PRIx64 " size 0x%" PRIx64"\n", allocTable->start, allocTable->size));

    return CUDA_SUCCESS;
}

static CUresult
createDevAllocTable(MCrec *rec, CCmemcheckRecData *recData, CUtoolsStreamHandle stream)
{
    CUresult res = CUDA_SUCCESS;
    uint64_t numAllocs = CCallocTableGetSize(rec->globalAllocs);
    MCdevAlloc *devAllocTable = NULL;
    CopyAllocEntryData copyData = {0};

    // allocate host copy of device allocation table
    recData->globalAllocDevBuffer.size = (numAllocs + 1) * sizeof(MCdevAlloc);
    recData->globalAllocDevBuffer.mcctx = rec->context;
    res = CCallocateHost(&recData->globalAllocDevBuffer);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to allocate device allocation list on host\n"));
        return res;
    }

    devAllocTable = (MCdevAlloc*)recData->globalAllocDevBuffer.host.ptr;

    // fill first table element with number of entries
    memset(devAllocTable, 0, sizeof(MCdevAlloc));
    devAllocTable->numEntries = numAllocs;

    copyData.allocTableRef = &devAllocTable;
    copyData.lastStart = 0;

    // fill remaining table with actual entries
    res = CCallocTableApplyFunctor(rec->globalAllocs, copyAllocEntry, &copyData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to copy globalAllocs to device table\n"));
        return res;
    }

    // allocate device copy
    // WAR bug 2288039: allocate it in pinned sysmem on Windows
    if (rec->options.memMapMode == CC_MEM_MAP_MODE_FORCED)
        recData->globalAllocDevBuffer.devseg = HALO_MEM_SEG_PINNED_SYSMEM;
    else
        recData->globalAllocDevBuffer.devseg = HALO_MEM_SEG_GLOBAL;

    res = CCallocateDevice(&recData->globalAllocDevBuffer, NULL);
    if (res != CUDA_SUCCESS) {
         CU_ERROR_PRINT(("Failed to allocate device allocation list on device\n"));
        return res;
    }

    CU_DEBUG_PRINT(("Alloc table 0x%" PRIx64" with %lu entries\n", recData->globalAllocDevBuffer.dev.dPtr, numAllocs));
    CU_DEBUG_PRINT(("Allocated device allocation table with %lu+1 entries\n", numAllocs));

    res = CCmemShadowHtoDStream(&recData->globalAllocDevBuffer,
                                &recData->globalAllocDevBuffer,
                                stream,
                                CC_MEM_SHADOW_ACTION_MEMCPY);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to download global device allocation table\n"));
        return res;
    }

    return CUDA_SUCCESS;
}

static CUresult
destroyDevAllocTable(CCmemcheckRecData *recData, CCmemCleanup *cleanup)
{
    if (!recData)
        return CUDA_SUCCESS;

    CCfreeHost(&recData->globalAllocDevBuffer);
    CCfreeDevice(&recData->globalAllocDevBuffer, cleanup);
    recData->globalAllocDevBuffer.size = 0;

    CU_DEBUG_PRINT(("Destroyed device allocation table\n"));

    return CUDA_SUCCESS;
}

static CUresult
memcheckCreatePatchHelpers(MCcontext *mcctx, MCrec *rec,
                           CUtoolsStreamHandle stream)
{
    CUresult status = CUDA_SUCCESS;
    CCmemcheckRecData *recData = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !rec || !stream) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    status = createDeviceErrorEntry(rec);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("createDeviceErrorentry failed\n"));
        return status;
    }

    if (getArchFromSmVer(rec->context->sm_version) < MC_TOOL_MODE_ARCH_SM60) {
        status = createDeviceTable(rec);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("createDeviceTable failed\n"));
            return status;
        }

        status = downloadTable(rec, stream);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("downloadTable failed\n"));
            return status;
        }
    } else {
        recData = (CCmemcheckRecData*)calloc(1, sizeof(*recData));
        if (!recData) {
            CU_ERROR_PRINT(("Failed to allocate rec data\n"));
            return CUDA_ERROR_OUT_OF_MEMORY;
        }

        status = createDevAllocTable(rec, recData, stream);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to create device alloc table\n"));
            free(recData);
            return status;
        }

        recData->internalModules = toolsListNew();
        if (!recData->internalModules) {
            CU_ERROR_PRINT(("Failed to create module list\n"));
            destroyDevAllocTable(recData, NULL);
            free(recData);
            return CUDA_ERROR_OUT_OF_MEMORY;
        }

        rec->tm.ptr[MC_TOOL_MODE_MEMCHECK] = (void*)recData;
    }

    return status;
}

static CUresult
destroyDeviceTable(MCrec *rec, CCmemCleanup *cleanup)
{
    CU_ASSERT(rec);

    CCfreeDevice(&rec->deviceTable, cleanup);
    return CUDA_SUCCESS;
}

static CUresult
destroyDeviceErrorEntry(MCrec *rec, CCmemCleanup *cleanup)
{
    CU_ASSERT(rec);

    CCfreeDevice(&rec->errorEntry, cleanup);
    return CUDA_SUCCESS;
}

static void
destroyModuleFunctor(void *value, void *data)
{
    CUresult res = CUDA_SUCCESS;
    MCmod *mod = (MCmod*)value;
    CUmod *cumod = NULL;

    // Store the CUmod and destroy the internal module structures
    // before actually unloading the CUmod. This ensures that all
    // module related objects (e.g. functions) are removed from
    // their respective maps before freeing their device memory.
    // Otherwise, the driver might re-assign the device memory
    // while we track the device address with a to-be-destroyed
    // function object.
    cumod = mod->cumod;
    mod->cumod = NULL;

    res = mcModuleDestroy(mod);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to destroy internal module\n"));
    }

    res = cuiModuleUnload(cumod);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to unload internal memcheck module\n"));
    }
}

static CUresult
memcheckDestroyPatchHelpers(MCcontext *mcctx, MCrec *rec, CCmemCleanup *cleanup)
{
    CUresult status = CUDA_SUCCESS;
    CCmemcheckRecData **pMcData = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !rec) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    status = destroyDeviceErrorEntry(rec, cleanup);
    if (status != CUDA_SUCCESS)
        return status;

    if (getArchFromSmVer(rec->context->sm_version) < MC_TOOL_MODE_ARCH_SM60) {
        status = destroyDeviceTable(rec, cleanup);
        if (status != CUDA_SUCCESS)
            return status;
    } else {
        pMcData = (CCmemcheckRecData**)&rec->tm.ptr[MC_TOOL_MODE_MEMCHECK];

        status = destroyDevAllocTable(*pMcData, cleanup);
        if (status != CUDA_SUCCESS)
            return status;

        if (*pMcData) {
            toolsListDelete((*pMcData)->internalModules, destroyModuleFunctor, NULL);

            free(*pMcData);
            *pMcData = NULL;
        }
    }

    return status;
}

static bool
memcheckHasPrologue(MCcontext *mcctx)
{
    if (!mcctx || !mcctx->gvars)
        return false;

    return (!mcctx->gvars->options.debuggerAttached);
}

static bool
memcheckUsesTrapHandler(MCoptions *options)
{
    if (!options)
        return false;

    return (!options->isAmodel && (options->reportHWErrors || options->nonblockingLaunch));
}

static CUresult
memcheckModuleLoaded(MCcontext *mcctx, MCmod *mod)
{
    CUresult res = CUDA_SUCCESS;
    MCDynamicSchemeConfig schemeConfig = {0};

    CU_TRACE_FUNCTION();

    if (!mcctx || !mod) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    CU_TRACE_PRINT(("Initializing Dynamic Memcheck\n"));
    res = MCDynamicInitialize(mcctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to initialize dynamic memcheck\n"));
        return res;
    }

    if (mcctx->dynamic->dynState.state == MC_DYN_INITIALIZED) {
        //Force the HAL to go into ABI mode
        res = MCDynamicGetSchemeConfig(mcctx,
                                       mcctx->gvars->options.requestedScheme,
                                       &schemeConfig);
        if (res != CUDA_SUCCESS || !schemeConfig.check) {
            CU_ERROR_PRINT(("Failure to read schemeConfig for scheme : %u\n",
                            mcctx->gvars->options.requestedScheme));
            return res;
        }

        mcCtxLock(mcctx);
        res = mcctx->instMgr->updateState(mcctx->instMgr,
                                          schemeConfig.check->regcount);
        mcCtxUnlock(mcctx);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Error while updating instMgr state\n"));
            return res;
        }
    }
    return res;
}

static CUresult
memcheckModuleUnloaded(MCcontext *mcctx, MCmod *mod)
{
    return CUDA_SUCCESS;
}

static CUresult
memcheckContextDestroyStart(MCcontext *mcctx)
{
    CUresult status = CUDA_SUCCESS;
    CCmemcheckCtxData *ctxData = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx)
        return CUDA_ERROR_UNKNOWN;

    if (mcctx->gvars->options.enableDevHeapLeakInfo) {
        MCDynamicAddLeaks(mcctx);
        flushRecords(mcctx, &mcctx->gvars->output);
    }
    MCDynamicFinalize(mcctx);

    ctxData = memcheckGetCtxData(mcctx);
    if (ctxData && ctxData->mod) {
        status = cuiModuleUnload(ctxData->mod->cumod);
        if (status != CUDA_SUCCESS)
            CU_ERROR_PRINT(("Failed to unload memcheck ctxData module\n"));

        ctxData->mod = NULL;
    }

    return CUDA_SUCCESS;
}

static CUresult
memcheckContextDestroyEnd(MCcontext *mcctx)
{
    CCmemcheckCtxData **ctxData = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx)
        return CUDA_ERROR_UNKNOWN;

    if (mcctx->gvars->options.enableCudaMallocLeakInfo)
        addLeakRecords(mcctx);

    /* Always flush at context destroy, just to be sure */
    flushRecords(mcctx, &mcctx->gvars->output);

    /* Cleanup */
    ctxData = (CCmemcheckCtxData**)&mcctx->tm.ptr[MC_TOOL_MODE_MEMCHECK];
    if (*ctxData) {
        free(*ctxData);
        *ctxData = NULL;
    }

    return CUDA_SUCCESS;
}

static CUresult
memcheckHeapSelected(MCcontext *mcctx, CCalloc *heap)
{
    CUresult status = CUDA_SUCCESS;
    CUtoolsStreamHandle stream;

    CU_TRACE_FUNCTION();

    if (!mcctx || !heap)
        return CUDA_ERROR_UNKNOWN;

    if (mcctx->dynamic &&
        mcctx->dynamic->dynState.state == MC_DYN_INITIALIZED) {

        /* Grab the barrier stream and use it to initialize and push down internal
           tracking structures */
        status = mcctx->gvars->tools.context->CtxGetBarrierStream(mcctx->cuctx, &stream);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to get barrier stream\n"));
            printInternalError(CU_MEMCHECK_ERROR_DYNAMIC_INIT_FAILED,
                               mcctx->gvars);
            return status;
        }

        status = MCDynamicActivateScheme(mcctx,
                                         stream,
                                         mcctx->gvars->options.requestedScheme);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to activate dynamic memcheck\n"));
            printInternalError(CU_MEMCHECK_ERROR_DYNAMIC_INIT_FAILED,
                               mcctx->gvars);
            return status;
        }
    }
    return status;
}

static CUresult
memcheckCtxSync(MCcontext *mcctx)
{
    return CUDA_SUCCESS;
}

static bool
memcheckEnableApiCheck(MCoptions *options)
{
    if (!options)
        return false;

    return (options->client.version > MC_CLIENT_VERSION_41 &&
            options->enableApiCheck);
}

static CUresult
memcheckHandlePatchCompletion(MCcontext *mcctx, MCrec *rec, MClaunch *launch)
{
    CUmemcheck_record err  = {0};
    uint32_t hasError = 0;
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!mcctx || !rec || !launch) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!createNewErrorRecord(CU_MEMCHECK_RECORD_MEM_SYSCALL, &err)) {
        CU_ERROR_PRINT(("Failed to create error record\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    res = MCDynamicParseErrorEntry(mcctx, &err, &hasError);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to parse dynamic errors\n"));
        return res;
    }

    if (!hasError)
        return CUDA_SUCCESS;

    res = addMemRecord(mcctx, &err, rec->func, launch->bt);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to add mem record\n"));
        return res;
    }

    return res;
}

static CUresult
memcheckIsArchSupported(MCtoolMode *toolMode, MCtoolModeArchs arch, uint32_t *supported)
{
    if (!toolMode || !supported) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *supported = 0;

    if (arch >= MC_TOOL_MODE_ARCH_SM30 && arch <= MC_TOOL_MODE_ARCH_SM80)
        *supported = 1;

    return CUDA_SUCCESS;
}

static CUresult
memcheckIsOsSupported(MCtoolMode *toolMode, uint32_t *supported)
{
    if (!toolMode || !supported) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *supported = 1;

    return CUDA_SUCCESS;
}

static CUresult
memcheckIsModuleSupported(MCcontext *mcctx, MCmod *mod, CUmemcheck_error_types *modSupportedError)
{
    if (!mcctx || !mod || !modSupportedError) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (mod->modOpts.usesLegacyAtomF16 &&
        !mcctx->gvars->modUsesLegacyAtomF16Warned) {
        // Warn once if we detect unsupported atom f16 instructions
        printInternalWarning(CU_MEMCHECK_WARNING_USES_LEGACY_ATOM_F16, mcctx->gvars);
        mcctx->gvars->modUsesLegacyAtomF16Warned = true;
    }

    *modSupportedError = CU_MEMCHECK_ERROR_NONE;

    return CUDA_SUCCESS;
}

static CUresult
memcheckUpdateLaunchConfig(MCcontext *mcctx, MCfunc *func, CUtoolsFunctionLaunchConfig *config)
{
    CUresult res = CUDA_SUCCESS;
    uint32_t maxReg = 0;
    uint32_t maxCRS = 0;
    uint32_t maxSys = 0; // system stack size
    uint32_t currentSystemStackSize = 0;
    MCDynamicSchemeConfig schemeConfig = {0};
    const CUetblToolsModule *tmod;

    CU_TRACE_FUNCTION();

    if (!mcctx || !func || !config) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    tmod = mcctx->gvars->tools.module;

    if (mcctx->dynamic &&
        (mcctx->dynamic->dynState.state == MC_DYN_INITIALIZED ||
         mcctx->dynamic->dynState.state == MC_DYN_ACTIVE)) {
        res = MCDynamicGetSchemeConfig(mcctx,
                                       mcctx->gvars->options.requestedScheme,
                                       &schemeConfig);
        if (res != CUDA_SUCCESS || !schemeConfig.check) {
            CU_ERROR_PRINT(("Failure to read config for scheme : %u\n",
                            mcctx->gvars->options.requestedScheme));
            return res;
        }

        maxSys = schemeConfig.check->systemStackSize;

        if (func->usesMalloc && schemeConfig.malloc) {
            maxReg = (maxReg > schemeConfig.malloc->regcount) ?
                     maxReg :
                     schemeConfig.malloc->regcount;

            maxCRS = (maxCRS > schemeConfig.malloc->crssize) ?
                     maxCRS :
                     schemeConfig.malloc->crssize;

            maxSys = (maxSys > schemeConfig.malloc->systemStackSize) ?
                     maxSys :
                     schemeConfig.malloc->systemStackSize;
        }

        if (func->usesFree && schemeConfig.free) {
            maxReg = (maxReg > schemeConfig.free->regcount) ?
                     maxReg :
                     schemeConfig.free->regcount;

            maxCRS = (maxCRS > schemeConfig.free->crssize) ?
                     maxCRS :
                     schemeConfig.free->crssize;

            maxSys = (maxSys > schemeConfig.free->systemStackSize) ?
                     maxSys :
                     schemeConfig.free->systemStackSize;
        }
    }

    if (config->localRegistersPerThread < maxReg) {
        CU_TRACE_PRINT(("Updating register count for toolmode from : %u to : %u\n",
                        config->localRegistersPerThread, maxReg));
        config->localRegistersPerThread = maxReg;
    }

    if (config->syncStackSizeLaunch < maxCRS + config->syncStackSizeCompiler) {
        CU_TRACE_PRINT(("Updating CRS size for toolmode from : %u to %u\n",
                        config->syncStackSizeLaunch,
                        maxCRS + config->syncStackSizeCompiler));
        config->syncStackSizeLaunch = maxCRS + config->syncStackSizeCompiler;
    }

    tmod->CtxGetSystemStackSize(mcctx->cuctx, &currentSystemStackSize);

    if (currentSystemStackSize < maxSys)
        tmod->CtxSetSystemStackSize(mcctx->cuctx, maxSys);

    return CUDA_SUCCESS;
}

static CUresult
loadMemcheckCtxModules(MCcontext *mcctx, CCmemcheckCtxData *ctxData)
{
    CUresult res = CUDA_SUCCESS;
    MCfunc *globalLdStFunc = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !ctxData) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* In the case of memcheck, we want to load up the module
       which contains all the per context stuff. This module is in CUDA-C
       and has no SASS level relocs to be applied
     */
    res = loadModuleFromCubinCommon(&ctxData->mod, mcctx, allCubins_memcheck, NULL, 0, false, false);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load module. \n"));
        return res;
    }

    globalLdStFunc = mcModuleGetFuncByName(ctxData->mod, "MCMCPerGlobalLdSt");
    if (!globalLdStFunc) {
        CU_ERROR_PRINT(("Could not get MCMCPerGlobalLdSt common function\n"));
        return CUDA_ERROR_UNKNOWN;
    }
    ctxData->commonPerGlobalLdSt = globalLdStFunc->mem.dev.dPtr;


    return CUDA_SUCCESS;
}

static CUresult
memcheckContextCreatedCallback(MCcontext *mcctx)
{
    CUresult res = CUDA_SUCCESS;
    CCmemcheckCtxData *ctxData = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = (CCmemcheckCtxData*)calloc(1, sizeof(*ctxData));
    if (!ctxData) {
        CU_ERROR_PRINT(("Failed to allocate ctx data\n"));
        return CUDA_ERROR_OUT_OF_MEMORY;
    }

    /* Load modules */
    res = loadMemcheckCtxModules(mcctx, ctxData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load required modules\n"));
        goto error;
    }

    mcctx->tm.ptr[MC_TOOL_MODE_MEMCHECK] = (void*)ctxData;

    return CUDA_SUCCESS;

error:
    if (ctxData) {
        free(ctxData);
        ctxData = NULL;
    }

    return res;
}

static bool
memcheckEnableMemAccessCheck (MCoptions *options)
{
    if (!options)
        return false;

    return (options->checkMemcpyMemset);
}

static CUresult
memcheckCheckMemAccessDevAddr(MCcontext *mcctx, uint64_t addr, uint64_t size, CUtoolsStreamHandle stream, CCmemAccessType accessType)
{
    CCalloc *allocStart = NULL, *allocEnd = NULL;
    CUresult res = CUDA_SUCCESS;
    uint64_t start, end;
    CCmemAccessError err = {(CCmemAccessErrorType)0};

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    start = addr;
    end = addr + size - 1;

    /* Default to no error */
    err.type = CC_MEM_ACCESS_ERROR_NONE;

    err.addr = addr;
    err.size = size;

    /* Do this next part while holding the context lock */
    mcCtxLock(mcctx);

    res = CCallocTableFindByAddr(mcctx->ctxAllocs, start, &allocStart);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to find alloc at 0x%" PRIx64 "\n", start));
        goto unlock;
    }

    res = CCallocTableFindByAddr(mcctx->ctxAllocs, end, &allocEnd);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to find end alloc at 0x%" PRIx64 "\n", end));
        goto unlock;
    }

    /* The heap allocation is not part of the allocTable, so we do a secondary check here for it */
    if ((!allocStart && !allocEnd) && mcctx->heapAlloc) {
        if (CCallocContainsRange(mcctx->heapAlloc, start, size)) {
            allocStart = mcctx->heapAlloc;
            allocEnd = mcctx->heapAlloc;
        }
    }

unlock:
    /* Release the context lock */
    mcCtxUnlock(mcctx);

    /* If any of the the functions within the context lock failed, then return early */
    if (res != CUDA_SUCCESS)
        return res;

    if (!allocStart  || !allocEnd) {
        CU_ERROR_PRINT(("Failed to find alloc for [0x%" PRIx64 ":0x%" PRIx64 "] start:%p end:%p\n",
                        start, end, allocStart, allocEnd));
        // Return a memory access error here. Specifically, that we could not find
        // a starting or ending allocation
        if (!allocStart)
            err.type = CC_MEM_ACCESS_ERROR_INVALID_START;
        else
            err.type = CC_MEM_ACCESS_ERROR_INVALID_END;

        if (allocStart) {
            err.foundNear = 1;
            err.allocAddr = CCallocGetStart(allocStart);
            err.allocSize = CCallocGetSize(allocStart);
        }
        else if (allocEnd) {
            err.foundNear = 1;
            err.allocAddr = CCallocGetStart(allocEnd);
            err.allocSize = CCallocGetSize(allocEnd);
        }
    }
    else if (allocStart != allocEnd) {
        /* Start and end belong to different allocations */
        CU_ERROR_PRINT(("Start and end do not match\n"));

        err.type = CC_MEM_ACCESS_ERROR_INVALID_RANGE;
        err.foundNear = 1;
        err.allocAddr = CCallocGetStart(allocStart);
        err.allocSize = CCallocGetSize(allocStart);
    }
    else if (CCallocIsInternal(allocStart)) {
        /* The allocation is an internal one */
        CU_ERROR_PRINT(("Write to an internal allocation\n"));
        err.type = CC_MEM_ACCESS_ERROR_INTERNAL_ALLOC;
        err.foundNear = 1;
        err.allocAddr = CCallocGetStart(allocStart);
        err.allocSize = CCallocGetSize(allocStart);
    }
    else if (mcctx->gvars->options.requestedDynamic &&
             mcctx->heapAlloc                       &&
             (mcctx->heapAlloc == allocStart)) {
        /* Check dynamic allocations */
        res = MCDynamicCheckAccess(mcctx, stream, addr, size, &err);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed in MCDynamicCheckHeapAccess\n"));
            return res;
        }
    }

    /* If there is an error, print it */
    if (err.type != CC_MEM_ACCESS_ERROR_NONE) {
        res = addMemAccessError(mcctx, &err, accessType,
                                addr, size);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to print a mem access error\n"));
            return res;
        }

        flushRecords(mcctx, &mcctx->gvars->output);
    }

    return CUDA_SUCCESS;
}

static CUresult
memcheckInitEndCallback(MCglobals *gvars)
{
    CU_TRACE_FUNCTION();

    return CUDA_SUCCESS;
}

static CUresult
memcheckAddAllocCallback(MCcontext *mcctx, CCalloc *alloc)
{
    return CUDA_SUCCESS;
}

static CUresult
memcheckRemoveAllocCallback(MCcontext *mcctx, CCalloc *alloc)
{
    return CUDA_SUCCESS;
}

static CUresult
generateLDSTFlagsSymbol(MCrec *rec, uint64_t asize, bool isAtomSys, NvU64 *symVal)
{
    if (!rec || !symVal)
        return CUDA_ERROR_UNKNOWN;

    *symVal  = FERMI_MEMCHECK_ASIZE_FLAG_NONE;
    if (isAtomSys)
        *symVal |= FERMI_MEMCHECK_ASIZE_FLAG_ATOMSYS;
    if (rec->func->mod->abiVersion >= ELFOSABIV_ABI)
        *symVal |= FERMI_MEMCHECK_ASIZE_FLAG_ABI;
    if (rec->context->supportsHostNativeAtomic)
        *symVal |= FERMI_MEMCHECK_ASIZE_FLAG_HOST_ATOMIC_SUPPORTED;

    // access size is stored in same entry as flags
    *symVal = (*symVal) << FERMI_MEMCHECK_ASIZE_SIZE_BITS;
    *symVal |= asize;
    if ((asize >> FERMI_MEMCHECK_ASIZE_SIZE_BITS) > 0) {
        CU_ERROR_PRINT(("Access size %llu is larger than %d bits.\n",
                       (long long unsigned)asize, FERMI_MEMCHECK_ASIZE_SIZE_BITS));
        return CUDA_ERROR_UNKNOWN;
    }

    return CUDA_SUCCESS;
}

static bool
hasInstrAtomSysSemantics(MCrec *rec, const uint64_t *inst, uint64_t pc)
{
    bool atomSys = false;

    if (!rec || !inst)
        return false;

    if (rec->func->hasElidedAtomSys) {
        MCinstrInfo *instrInfo = (MCinstrInfo*)toolsHashMapFind(rec->func->instrInfo, tHashMapNumToKey(pc));
        atomSys = instrInfo && (instrInfo->flags & MC_INSTR_INFO_ATOMSYS);
    }

    atomSys |= (rec->context->hal.getAtomScope(inst) == MC_ATOM_SCOPE_SYS);

    return atomSys;
}

CUresult
memcheckLoadLDSTStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, uint64_t patchPC,
                     CCIRinstOpcodes instType, bool mcDynEnableAbi, MCfunc **stubFunc)
{
    CCmemcheckRecData *recData = NULL;
    CCmemcheckCtxData *ctxData = NULL;
    CCsymbol sym[26] = {{0}};
    CUresult res = CUDA_SUCCESS;
    MCmod *mod = NULL;
    MCfunc *func = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;
    uint32_t asize = 0;
    uint32_t ra_lo, ra_hi = 0;
    uint32_t isAtomSys = 0;
    uint64_t heapCheckAddr = 0;
    bool voltaPlus = false;
    bool turingPlus = false;
    bool hasUniformRegister = false;

    CU_TRACE_FUNCTION();

    if (!rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = memcheckGetRecData(rec);
    if (!recData) {
        CU_ERROR_PRINT(("Invalid MC rec data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = memcheckGetCtxData(rec->context);
    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid MC ctx data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    isAtomSys = (uint32_t)hasInstrAtomSysSemantics(rec, inst, patchPC);
    hasUniformRegister = rec->context->hal.hasUniformRegister(inst);
    asize = rec->context->hal.getMemAccessSize(inst, rec->func, patchPC);
    ra_lo = rec->context->hal.getRa(inst);

    // The logic of using RA_HI depends on URF:
    // - If No URF, this is set by the extended bit
    // - If URF, this is set by U64 bit
    if (ra_lo != rec->context->hal.getRz()) {
        if (hasUniformRegister) {
            if (rec->context->hal.getU64(inst))
                ra_hi = ra_lo + 1;
        }
        else {
            if (rec->context->hal.getExtended(inst))
                ra_hi = ra_lo + 1;
        }
    }

    // If this was part of a 16b atomic sequence, override ra_lo
    if (asize == sizeof(uint16_t)) {
        uint16_t regId;
        if (mcFuncIsInstructionAtom16(rec->func, patchPC, &regId)) {
            ra_lo = regId;
        }
    }

    voltaPlus  = getArchFromSmVer(rec->context->sm_version) >= MC_TOOL_MODE_ARCH_SM70;
    turingPlus = getArchFromSmVer(rec->context->sm_version) >= MC_TOOL_MODE_ARCH_SM75;

    // branch to bypass label if orig pred is false
    //  TODO: update this to set a 128bit mask.
    //  this only works on Volta because Pg happens
    //  to be in lo word which is also inst[0]
    sym[0].name     = "MC_STUB_GL_LDST_BYPASS_BRANCH";
    sym[0].type     = CC_SYMBOL_TYPE_MASKED;
    sym[0].val      = rec->context->hal.getPredRawInv(inst);
    sym[0].mask     = rec->context->hal.getPredMask(inst);
    if (voltaPlus) {
        sym[0].size = CC_SYMBOL_SIZE_128;
        sym[0].masks[1] = 0;
    }

    // Pre-Volta: MOV R4, Ra_lo;
    // Volta+:    STL[LMEM_Ra_lo], Ra_lo;
    sym[1].name     = "MC_STUB_GL_LDST_MOV_RA_LO";
    if (voltaPlus)
        rec->context->hal.genLmemHiSpill(VOLTA_LMEM_MEMCHECK_RA_LO, sizeof(uint32_t), ra_lo, (uint64_t*)&(sym[1].val));
    else
        rec->context->hal.genMov(4, ra_lo, (uint64_t*)&(sym[1].val));
    setSymbolSize(rec->context, &sym[1]);

    if (ra_hi) {
        // Pre-Volta: MOV R5, Ra_hi;
        // Volta+:    STL[LMEM_Ra_hi], Ra_hi;
        sym[2].name     = "MC_STUB_GL_LDST_MOV_RA_HI";
        if (voltaPlus)
            rec->context->hal.genLmemHiSpill(VOLTA_LMEM_MEMCHECK_RA_HI, sizeof(uint32_t), ra_hi, (uint64_t*)&(sym[2].val));
        else
            rec->context->hal.genMov(5, ra_hi, (uint64_t*)&(sym[2].val));
        setSymbolSize(rec->context, &sym[2]);
    }

    // original instruction (full inst reloc)
    sym[3].name     = "MC_STUB_GL_LDST_ORIG_INST";
    res = assignInstSymbol(rec->context, &sym[3], inst);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to assign inst symbol\n"));
        return res;
    }

    // the patched PC (32/64bit), depending on arch
    sym[4].name     = "MC_STUB_GL_LDST_PC";
    sym[4].val      = patchPC;

    // return address in user code after patch completion
    sym[5].name     = "MC_STUB_GL_LDST_JUMP_RETURN";
    sym[5].val      = returnTarget;

    // immediate addr offset of original instruction
    sym[6].name     = "MC_STUB_GL_LDST_OFFSET";
    sym[6].val      = rec->context->hal.getOffset(inst);

    // device addr of the allocation table
    sym[7].name     = "MC_STUB_GL_LDST_ALLOC_TBL";
    sym[7].val      = recData->globalAllocDevBuffer.dev.dPtr;

    if (!voltaPlus) {
        // replace Pg with inverse of the orig instr Plg
        // branches to smem checks if Plg is false
        /* Plg exists only before Volta */
        sym[8].name     = "MC_STUB_GL_LDST_PLG_BRANCH";
        sym[8].type     = CC_SYMBOL_TYPE_MASKED;
        rec->context->hal.genPlgRawInv(inst, (uint64_t*)&(sym[8].val));
        sym[8].mask     = rec->context->hal.getPredMask(inst);
    }

    // device address of the common check function for global allocations
    sym[9].name     = "MCMCPerGlobalLdSt";
    sym[9].val      = ctxData->commonPerGlobalLdSt;

    // memory access size (in bytes) of the orig instruction
    sym[10].name    = "MC_STUB_GL_LDST_ASIZE";
    sym[10].val     = asize;

    // base value to be written into lmem MAGIC entry when signalling errors
    // contains information to be passed to the traphandler callback
    sym[11].name    = "MC_STUB_GL_LDST_MAGIC_BASE";
    sym[11].val     = getAddressSpace(instType);
    if (isAtomSys)
        sym[11].val |= FERMI_MEMCHECK_ATOMSYS_MASK;

    // misc flags about the orig instruction
    sym[12].name    = "MC_STUB_GL_LDST_FLAGS";
    res = generateLDSTFlagsSymbol(rec, asize, isAtomSys, &(sym[12].val));
    if (res != CUDA_SUCCESS)
        return res;

    // These values are hardcoded on Volta because of bug 2047393
    if (getArchFromSmVer(rec->context->sm_version) != MC_TOOL_MODE_ARCH_SM70) {
        // offset of shared memory size in constant memory, bank 0
        sym[13].name    = "MC_STUB_GL_LDST_SMEM_SIZE_OFFSET";
        sym[13].val     = rec->context->hal.driverInternalParamsShmemSizeOffset;

        // offset of stack top addr in constant memory, bank 0
        sym[14].name    = "MC_STUB_GL_LDST_STACK_TOP_OFFSET";
        sym[14].val     = rec->context->hal.gridParamsUserStackTopOffset;
    }

    // function stack size
    sym[15].name    = "MC_STUB_GL_LDST_FUNC_STACK_SIZE";
    sym[15].val     = rec->func->cufunc->stackSize;

    // BPT.TRAP 1 or NOP-equivalent (full instr reloc)
    sym[16].name    = "MC_STUB_GL_LDST_TRAP_INST";
    setSymbolSize(rec->context, &sym[16]);
    if (rec->options.debuggerAttached   ||
        rec->options.forceError         ||
        rec->options.nonblockingLaunch) {
        rec->context->hal.genBreakInstruction(rec, (uint64_t*)&(sym[16].val));
    } else
        rec->context->hal.genMov(0, 0, (uint64_t*)&(sym[16].val));

    // device address of memcheck error buffer
    sym[17].name    = "MC_STUB_GL_LDST_ERR_BFR";
    sym[17].val     = rec->errorEntry.dev.dPtr;

    // heap device address and size (or 0 if not applicable)
    sym[18].name    = "MC_STUB_GL_LDST_HEAP_ADDR";
    sym[19].name    = "MC_STUB_GL_LDST_HEAP_SIZE";

    if (rec->context->heapAlloc && CCallocGetSize(rec->context->heapAlloc)) {
        if (rec->context->dynamic && mcDynEnableAbi) {
            res = MCDynamicGetCheckFuncAddress(rec->context, &heapCheckAddr);
            if (res != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Failed to read heapcheck func address\n"));
                return res;
            }
        }

        sym[18].val = CCallocGetStart(rec->context->heapAlloc);
        sym[19].val = CCallocGetSize(rec->context->heapAlloc);
    } else {
        sym[18].val = 0;
        sym[19].val = 0;
    }

    // device address of the heap check function
    sym[20].name    = "MC_STUB_GL_LDST_HEAPCHECK_ADDR";
    sym[20].val     = heapCheckAddr;

    // jcal/call to heap check function (full instr reloc)
    sym[21].name    = "MC_STUB_GL_LDST_HEAPCHECK_JCAL";
    rec->context->hal.genAbsoluteCall(heapCheckAddr, true, rec->context->hal.getRz(), (uint64_t*)&(sym[21].val));
    setSymbolSize(rec->context, &sym[21]);

    // local memory lo size
    sym[22].name    = "MC_STUB_GL_LDST_LMEM_LO_SIZE";
    sym[22].val     = rec->config.lmemLoSize;

    // URF source
    if (hasUniformRegister) {
        uint32_t urb_lo = rec->context->hal.getURb(inst);
        uint32_t urb_hi = rec->context->hal.getURz();

        if (rec->context->hal.getExtended(inst)) {
            urb_hi = urb_lo + 1;
        }

        // MOV R6, URb
        sym[23].name = "MC_STUB_GL_LDST_MOV_URB_LO";
        rec->context->hal.genMovFromUR(6, urb_lo, (uint64_t*)(&sym[23].val));
        setSymbolSize(rec->context, &sym[23]);

        // MOV R7, Urb+1
        sym[24].name = "MC_STUB_GL_LDST_MOV_URB_HI";
        rec->context->hal.genMovFromUR(7, urb_hi, (uint64_t*)(&sym[24].val));
        setSymbolSize(rec->context, &sym[24]);
    }

    // Pnz
    if (turingPlus) {
        sym[25].name     = "MC_STUB_GL_LDST_BYPASS_BRANCH_PNZ";
        sym[25].type     = CC_SYMBOL_TYPE_MASKED;
        sym[25].val      = rec->context->hal.getPnzInvAsPgMask(inst);
        sym[25].masks[0] = rec->context->hal.getPredMask(inst);
        sym[25].masks[1] = 0;
        sym[25].size     = CC_SYMBOL_SIZE_128;
    }

    res = loadModuleFromCubin(&mod, rec->context, allCubins_memcheck_stub_ldst, sym,
                              sizeof(sym)/sizeof(sym[0]));
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load cubins\n"));
        return res;
    }

    func = mcModuleGetFuncByName(mod, "memcheckStubLDST");
    if (!func) {
        CU_ERROR_PRINT(("Could not get stub function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    tres = toolsListAppend(recData->internalModules, mod);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to append module to list. (tres=%u)\n", tres));
        return CUDA_ERROR_UNKNOWN;
    }

    if (stubFunc) {
        CU_DEBUG_PRINT(("Returning generic ldst stub entry at : 0x%" PRIx64 "\n",
                        func->mem.dev.dPtr));
        *stubFunc = func;
    }

    return res;
}

CUresult
memcheckLoadGlobalLDSTStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, uint64_t patchPC,
                           CCIRinstOpcodes instType, bool mcDynEnableAbi, MCfunc **stubFunc)
{
    CCmemcheckRecData *recData = NULL;
    CCmemcheckCtxData *ctxData = NULL;
    CCsymbol sym[21] = {{0}};
    CUresult res = CUDA_SUCCESS;
    MCmod *mod = NULL;
    MCfunc *func = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;
    uint32_t asize = 0;
    uint32_t ra_lo, ra_hi = 0;
    uint32_t isAtomSys = 0;
    uint64_t heapCheckAddr = 0;
    bool voltaPlus = false;
    bool turingPlus = false;
    bool hasUniformRegister = false;

    CU_TRACE_FUNCTION();

    if (!rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = memcheckGetRecData(rec);
    if (!recData) {
        CU_ERROR_PRINT(("Invalid MC rec data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = memcheckGetCtxData(rec->context);
    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid MC ctx data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    isAtomSys = (uint32_t)hasInstrAtomSysSemantics(rec, inst, patchPC);
    hasUniformRegister = rec->context->hal.hasUniformRegister(inst);
    asize = rec->context->hal.getMemAccessSize(inst, rec->func, patchPC);
    ra_lo = rec->context->hal.getRa(inst);

    // The logic of using RA_HI depends on URF:
    // - If No URF, this is set by the extended bit
    // - If URF, this is set by U64 bit
    if (ra_lo != rec->context->hal.getRz()) {
        if (hasUniformRegister) {
            if (rec->context->hal.getU64(inst))
                ra_hi = ra_lo + 1;
        }
        else {
            if (rec->context->hal.getExtended(inst))
                ra_hi = ra_lo + 1;
        }
    }

    // If this was part of a 16b atomic sequence, override ra_lo
    if (asize == sizeof(uint16_t)) {
        uint16_t regId;
        if (mcFuncIsInstructionAtom16(rec->func, patchPC, &regId)) {
            ra_lo = regId;
        }
    }

    voltaPlus  = getArchFromSmVer(rec->context->sm_version) >= MC_TOOL_MODE_ARCH_SM70;
    turingPlus = getArchFromSmVer(rec->context->sm_version) >= MC_TOOL_MODE_ARCH_SM75;

    // branch to bypass label if orig pred is false
    sym[0].name     = "MC_STUB_GL_LDST_BYPASS_BRANCH";
    sym[0].type     = CC_SYMBOL_TYPE_MASKED;
    sym[0].val      = rec->context->hal.getPredRawInv(inst);
    sym[0].mask     = rec->context->hal.getPredMask(inst);
    if (voltaPlus) {
        sym[0].size = CC_SYMBOL_SIZE_128;
        sym[0].masks[1] = 0;
    }

    // Pre-Volta: MOV R4, Ra_lo;
    // Volta+:    STL[LMEM_Ra_lo], Ra_lo;
    sym[1].name     = "MC_STUB_GL_LDST_MOV_RA_LO";
    if (voltaPlus)
        rec->context->hal.genLmemHiSpill(VOLTA_LMEM_MEMCHECK_RA_LO, sizeof(uint32_t), ra_lo, (uint64_t*)&(sym[1].val));
    else
        rec->context->hal.genMov(4, ra_lo, (uint64_t*)&(sym[1].val));
    setSymbolSize(rec->context, &sym[1]);

    if (ra_hi) {
        // Pre-Volta: MOV R5, Ra_hi;
        // Volta+:    STL[LMEM_Ra_hi], Ra_hi;
        sym[2].name     = "MC_STUB_GL_LDST_MOV_RA_HI";
        if (voltaPlus)
            rec->context->hal.genLmemHiSpill(VOLTA_LMEM_MEMCHECK_RA_HI, sizeof(uint32_t), ra_hi, (uint64_t*)&(sym[2].val));
        else
            rec->context->hal.genMov(5, ra_hi, (uint64_t*)&(sym[2].val));
        setSymbolSize(rec->context, &sym[2]);
    }

    // original instruction (full inst reloc)
    sym[3].name     = "MC_STUB_GL_LDST_ORIG_INST";
    res = assignInstSymbol(rec->context, &sym[3], inst);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to assign inst symbol\n"));
        return res;
    }

    // the patched PC (32/64bit), depending on arch
    sym[4].name     = "MC_STUB_GL_LDST_PC";
    sym[4].val      = patchPC;

    // return address in user code after patch completion
    sym[5].name     = "MC_STUB_GL_LDST_JUMP_RETURN";
    sym[5].val      = returnTarget;

    // immediate addr offset of original instruction
    sym[6].name     = "MC_STUB_GL_LDST_OFFSET";
    sym[6].val      = rec->context->hal.getOffset(inst);

    // device addr of the allocation table
    sym[7].name     = "MC_STUB_GL_LDST_ALLOC_TBL";
    sym[7].val      = recData->globalAllocDevBuffer.dev.dPtr;

    // device address of the common check function for global allocations
    sym[8].name     = "MCMCPerGlobalLdSt";
    sym[8].val      = ctxData->commonPerGlobalLdSt;

    // memory access size (in bytes) of the orig instruction
    sym[9].name    = "MC_STUB_GL_LDST_ASIZE";
    sym[9].val     = asize;

    // base value to be written into lmem MAGIC entry when signalling errors
    // contains information to be passed to the traphandler callback
    sym[10].name    = "MC_STUB_GL_LDST_MAGIC_BASE";
    sym[10].val     = getAddressSpace(instType);
    if (isAtomSys)
        sym[10].val |= FERMI_MEMCHECK_ATOMSYS_MASK;

    // misc flags about the orig instruction
    sym[11].name    = "MC_STUB_GL_LDST_FLAGS";
    res = generateLDSTFlagsSymbol(rec, asize, isAtomSys, &(sym[11].val));
    if (res != CUDA_SUCCESS)
        return res;

    // BPT.TRAP 1 or NOP-equivalent (full instr reloc)
    sym[12].name    = "MC_STUB_GL_LDST_TRAP_INST";
    setSymbolSize(rec->context, &sym[12]);
    if (rec->options.debuggerAttached   ||
        rec->options.forceError         ||
        rec->options.nonblockingLaunch) {
        rec->context->hal.genBreakInstruction(rec, (uint64_t*)&(sym[12].val));
    } else
        rec->context->hal.genMov(0, 0, (uint64_t*)&(sym[12].val));

    // device address of memcheck error buffer
    sym[13].name    = "MC_STUB_GL_LDST_ERR_BFR";
    sym[13].val     = rec->errorEntry.dev.dPtr;

    // heap device address and size (or 0 if not applicable)
    sym[14].name    = "MC_STUB_GL_LDST_HEAP_ADDR";
    sym[15].name    = "MC_STUB_GL_LDST_HEAP_SIZE";

    if (rec->context->heapAlloc && CCallocGetSize(rec->context->heapAlloc)) {
        if (rec->context->dynamic && mcDynEnableAbi) {
            res = MCDynamicGetCheckFuncAddress(rec->context, &heapCheckAddr);
            if (res != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Failed to read heapcheck func address\n"));
                return res;
            }
        }

        sym[14].val = CCallocGetStart(rec->context->heapAlloc);
        sym[15].val = CCallocGetSize(rec->context->heapAlloc);
    } else {
        sym[14].val = 0;
        sym[15].val = 0;
    }

    // device address of the heap check function
    sym[16].name    = "MC_STUB_GL_LDST_HEAPCHECK_ADDR";
    sym[16].val     = heapCheckAddr;

    // jcal/call to heap check function (full instr reloc)
    sym[17].name    = "MC_STUB_GL_LDST_HEAPCHECK_JCAL";
    rec->context->hal.genAbsoluteCall(heapCheckAddr, true, rec->context->hal.getRz(), (uint64_t*)&(sym[17].val));
    setSymbolSize(rec->context, &sym[17]);

    // URF source
    if (hasUniformRegister) {
        uint32_t urb_lo = rec->context->hal.getURb(inst);
        uint32_t urb_hi = rec->context->hal.getURz();

        if (rec->context->hal.getExtended(inst)) {
            urb_hi = urb_lo + 1;
        }

        // MOV R6, URb
        sym[18].name = "MC_STUB_GL_LDST_MOV_URB_LO";
        rec->context->hal.genMovFromUR(6, urb_lo, (uint64_t*)(&sym[18].val));
        setSymbolSize(rec->context, &sym[18]);

        // MOV R7, Urb+1
        sym[19].name = "MC_STUB_GL_LDST_MOV_URB_HI";
        rec->context->hal.genMovFromUR(7, urb_hi, (uint64_t*)(&sym[19].val));
        setSymbolSize(rec->context, &sym[19]);
    }

    // Pnz
    if (turingPlus) {
        sym[20].name     = "MC_STUB_GL_LDST_BYPASS_BRANCH_PNZ";
        sym[20].type     = CC_SYMBOL_TYPE_MASKED;
        sym[20].val      = rec->context->hal.getPnzInvAsPgMask(inst);
        sym[20].masks[0] = rec->context->hal.getPredMask(inst);
        sym[20].masks[1] = 0;
        sym[20].size     = CC_SYMBOL_SIZE_128;
    }

    res = loadModuleFromCubin(&mod, rec->context, allCubins_memcheck_stub_global_ldst, sym,
                              sizeof(sym)/sizeof(sym[0]));
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load cubins\n"));
        return res;
    }

    func = mcModuleGetFuncByName(mod, "memcheckStubGlobalLDST");
    if (!func) {
        CU_ERROR_PRINT(("Could not get stub function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    tres = toolsListAppend(recData->internalModules, mod);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to append module to list. (tres=%u)\n", tres));
        return CUDA_ERROR_UNKNOWN;
    }

    if (stubFunc) {
        CU_DEBUG_PRINT(("Returning global ldst stub entry at : 0x%" PRIx64 "\n",
                        func->mem.dev.dPtr));
        *stubFunc = func;
    }

    return res;
}

CUresult
memcheckLoadSharedLDSTStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, uint64_t patchPC, MCfunc **stubFunc)
{
    CCmemcheckRecData *recData = NULL;
    CCmemcheckCtxData *ctxData = NULL;
    CCsymbol sym[13] = {{0}};
    CUresult res = CUDA_SUCCESS;
    MCmod *mod = NULL;
    MCfunc *func = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;
    uint32_t asize = 0;
    uint32_t ra = 0;
    bool voltaPlus = false, turingPlus = false;
    bool hasUniformRegister = false;

    CU_TRACE_FUNCTION();

    if (!rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = memcheckGetRecData(rec);
    if (!recData) {
        CU_ERROR_PRINT(("Invalid MC rec data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = memcheckGetCtxData(rec->context);
    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid MC ctx data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    asize = rec->context->hal.getMemAccessSize(inst, rec->func, patchPC);
    ra    = rec->context->hal.getRa(inst);

    // If this was part of a 16b atomic sequence, override ra
    if (asize == sizeof(uint16_t)) {
        uint16_t regId;
        if (mcFuncIsInstructionAtom16(rec->func, patchPC, &regId)) {
            ra = regId;
        }
    }

    voltaPlus = getArchFromSmVer(rec->context->sm_version) >= MC_TOOL_MODE_ARCH_SM70;
    turingPlus = getArchFromSmVer(rec->context->sm_version) >= MC_TOOL_MODE_ARCH_SM75;
    hasUniformRegister = rec->context->hal.hasUniformRegister(inst);

    // branch to bypass label if orig pred is false
    sym[0].name     = "MC_STUB_SH_LDST_BYPASS_BRANCH";
    sym[0].type     = CC_SYMBOL_TYPE_MASKED;
    sym[0].val      = rec->context->hal.getPredRawInv(inst);
    sym[0].mask     = rec->context->hal.getPredMask(inst);
    if (voltaPlus) {
        sym[0].size = CC_SYMBOL_SIZE_128;
        sym[0].masks[1] = 0;
    }

    // Pre-Volta: MOV R4, Ra;
    // Volta+:    STL[LMEM_Ra], Ra;
    sym[1].name     = "MC_STUB_SH_LDST_MOV_RA";
    if (voltaPlus)
        rec->context->hal.genLmemHiSpill(VOLTA_LMEM_MEMCHECK_RA_LO, sizeof(uint32_t), ra, (uint64_t*)&(sym[1].val));
    else
        rec->context->hal.genMov(4, ra, (uint64_t*)&(sym[1].val));
    setSymbolSize(rec->context, &sym[1]);

    // original instruction (full inst reloc)
    sym[2].name     = "MC_STUB_SH_LDST_ORIG_INST";
    res = assignInstSymbol(rec->context, &sym[2], inst);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to assign inst symbol\n"));
        return res;
    }

    // the patched PC (32/64bit), depending on arch
    sym[3].name     = "MC_STUB_SH_LDST_PC";
    sym[3].val      = patchPC;

    // return address in user code after patch completion
    sym[4].name     = "MC_STUB_SH_LDST_JUMP_RETURN";
    sym[4].val      = returnTarget;

    // immediate addr offset of original instruction
    sym[5].name     = "MC_STUB_SH_LDST_OFFSET";
    sym[5].val      = rec->context->hal.getOffset(inst);

    // memory access size (in bytes) of the orig instruction
    sym[6].name    = "MC_STUB_SH_LDST_ASIZE";
    sym[6].val     = asize;

    // base value to be written into lmem MAGIC entry when signalling errors
    // contains information to be passed to the traphandler callback
    sym[7].name    = "MC_STUB_SH_LDST_MAGIC_BASE";
    sym[7].val     = CU_MEMCHECK_ADDR_TYPE_SHARED;

    // This value is hardcoded on Volta because of bug 2047393
    if (getArchFromSmVer(rec->context->sm_version) != MC_TOOL_MODE_ARCH_SM70) {
        // offset of shared memory size in constant memory, bank 0
        sym[8].name    = "MC_STUB_SH_LDST_SMEM_SIZE_OFFSET";
        sym[8].val     = rec->context->hal.driverInternalParamsShmemSizeOffset;
    }

    // BPT.TRAP 1 or NOP-equivalent (full instr reloc)
    sym[9].name    = "MC_STUB_SH_LDST_TRAP_INST";
    setSymbolSize(rec->context, &sym[9]);
    if (rec->options.debuggerAttached   ||
        rec->options.forceError         ||
        rec->options.nonblockingLaunch) {
        rec->context->hal.genBreakInstruction(rec, (uint64_t*)&(sym[9].val));
    } else
        rec->context->hal.genMov(0, 0, (uint64_t*)&(sym[9].val));

    // device address of memcheck error buffer
    sym[10].name    = "MC_STUB_SH_LDST_ERR_BFR";
    sym[10].val     = rec->errorEntry.dev.dPtr;

    // URF source
    if (hasUniformRegister) {
        uint32_t urb = rec->context->hal.getURb(inst);

        // MOV R6, Urb
        sym[11].name = "MC_STUB_SH_LDST_MOV_URB";
        rec->context->hal.genMovFromUR(6, urb, (uint64_t*)(&sym[11].val));
        setSymbolSize(rec->context, &sym[11]);
    }

    // SHF.L.U32 source register by strideShit bits
    if (turingPlus) {
        uint32_t strideShift = rec->context->hal.getStrideShift(inst);

        sym[12].name = "MC_STUB_SH_LDST_STRIDE";
        sym[12].val  = strideShift;
    }

    res = loadModuleFromCubin(&mod, rec->context, allCubins_memcheck_stub_shared_ldst, sym,
                              sizeof(sym)/sizeof(sym[0]));
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load cubins\n"));
        return res;
    }

    func = mcModuleGetFuncByName(mod, "memcheckStubSharedLDST");
    if (!func) {
        CU_ERROR_PRINT(("Could not get stub function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    tres = toolsListAppend(recData->internalModules, mod);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to append module to list. (tres=%u)\n", tres));
        return CUDA_ERROR_UNKNOWN;
    }

    if (stubFunc) {
        CU_DEBUG_PRINT(("Returning shared ldst stub entry at : 0x%" PRIx64 "\n",
                        func->mem.dev.dPtr));
        *stubFunc = func;
    }

    return CUDA_SUCCESS;
}

CUresult
memcheckLoadLocalLDSTStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, uint64_t patchPC,
                          bool mcDynEnableAbi, MCfunc **stubFunc)
{
    CCmemcheckRecData *recData = NULL;
    CCmemcheckCtxData *ctxData = NULL;
    CCsymbol sym[17] = {{0}};
    CUresult res = CUDA_SUCCESS;
    MCmod *mod = NULL;
    MCfunc *func = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;
    uint32_t asize = 0;
    uint32_t ra = 0;
    bool voltaPlus = false;
    bool hasUniformRegister = false;

    CU_TRACE_FUNCTION();

    if (!rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = memcheckGetRecData(rec);
    if (!recData) {
        CU_ERROR_PRINT(("Invalid MC rec data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = memcheckGetCtxData(rec->context);
    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid MC ctx data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    asize = rec->context->hal.getMemAccessSize(inst, rec->func, patchPC);
    ra = rec->context->hal.getRa(inst);

    // If this was part of a 16b atomic sequence, override ra
    if (asize == sizeof(uint16_t)) {
        uint16_t regId;
        if (mcFuncIsInstructionAtom16(rec->func, patchPC, &regId)) {
            ra = regId;
        }
    }

    voltaPlus = getArchFromSmVer(rec->context->sm_version) >= MC_TOOL_MODE_ARCH_SM70;
    hasUniformRegister = rec->context->hal.hasUniformRegister(inst);

    // branch to bypass label if orig pred is fals
    sym[0].name     = "MC_STUB_LMEM_LDST_BYPASS_BRANCH";
    sym[0].type     = CC_SYMBOL_TYPE_MASKED;
    sym[0].val      = rec->context->hal.getPredRawInv(inst);
    sym[0].mask     = rec->context->hal.getPredMask(inst);
    if (voltaPlus) {
        sym[0].size = CC_SYMBOL_SIZE_128;
        sym[0].masks[1] = 0;
    }

    // Pre-Volta: MOV R4, Ra;
    // Volta+:    STL[LMEM_Ra], Ra;
    sym[1].name     = "MC_STUB_LMEM_LDST_MOV_RA";
    if (voltaPlus)
        rec->context->hal.genLmemHiSpill(VOLTA_LMEM_MEMCHECK_RA_LO, sizeof(uint32_t), ra, (uint64_t*)&(sym[1].val));
    else
        rec->context->hal.genMov(4, ra, (uint64_t*)&(sym[1].val));
    setSymbolSize(rec->context, &sym[1]);

    // original instruction (full inst reloc)
    sym[2].name     = "MC_STUB_LMEM_LDST_ORIG_INST";
    res = assignInstSymbol(rec->context, &sym[2], inst);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to assign inst symbol\n"));
        return res;
    }

    // the patched PC (32/64bit), depending on arch
    sym[3].name     = "MC_STUB_LMEM_LDST_PC";
    sym[3].val      = patchPC;

    // return address in user code after patch completion
    sym[4].name     = "MC_STUB_LMEM_LDST_JUMP_RETURN";
    sym[4].val      = returnTarget;

    // immediate addr offset of original instruction
    sym[5].name     = "MC_STUB_LMEM_LDST_OFFSET";
    sym[5].val      = rec->context->hal.getOffset(inst);

    // memory access size (in bytes) of the orig instruction
    sym[6].name    = "MC_STUB_LMEM_LDST_ASIZE";
    sym[6].val     = asize;

    // base value to be written into lmem MAGIC entry when signalling errors
    // contains information to be passed to the traphandler callback
    sym[7].name    = "MC_STUB_LMEM_LDST_MAGIC_BASE";
    sym[7].val     = CU_MEMCHECK_ADDR_TYPE_LOCAL;

    // misc flags about the orig instruction
    sym[8].name    = "MC_STUB_LMEM_LDST_FLAGS";
    res = generateLDSTFlagsSymbol(rec, asize, false, &(sym[8].val));
    if (res != CUDA_SUCCESS)
        return res;

    // This value is hardcoded on Volta because of bug 2047393
    if (getArchFromSmVer(rec->context->sm_version) != MC_TOOL_MODE_ARCH_SM70) {
        // offset of stack top addr in constant memory, bank 0
        sym[9].name    = "MC_STUB_LMEM_LDST_STACK_TOP_OFFSET";
        sym[9].val     = rec->context->hal.gridParamsUserStackTopOffset;
    }

    // function stack size
    sym[10].name    = "MC_STUB_LMEM_LDST_FUNC_STACK_SIZE";
    sym[10].val     = rec->func->cufunc->stackSize;

    // BPT.TRAP 1 or NOP-equivalent (full instr reloc)
    sym[11].name    = "MC_STUB_LMEM_LDST_TRAP_INST";
    setSymbolSize(rec->context, &sym[11]);
    if (rec->options.debuggerAttached   ||
        rec->options.forceError         ||
        rec->options.nonblockingLaunch) {
        rec->context->hal.genBreakInstruction(rec, (uint64_t*)&(sym[11].val));
    } else
        rec->context->hal.genMov(0, 0, (uint64_t*)&(sym[11].val));

    // device address of memcheck error buffer
    sym[12].name    = "MC_STUB_LMEM_LDST_ERR_BFR";
    sym[12].val     = rec->errorEntry.dev.dPtr;

    // local memory lo size
    sym[13].name    = "MC_STUB_LMEM_LDST_LMEM_LO_SIZE";
    sym[13].val     = rec->config.lmemLoSize;

    // cnp local memory address and size (if applicable)
    sym[14].name    = "MC_STUB_LMEM_LDST_CNP_LMEM_START";
    sym[15].name    = "MC_STUB_LMEM_LDST_CNP_LMEM_SIZE";

    if (rec->func->usesCnp) {
        sym[14].val     = rec->context->hal.cnpReservedLmemStart;
        sym[15].val     = rec->context->hal.cnpReservedLmemSize;
    } else {
        sym[14].val     = 0;
        sym[15].val     = 0;
    }

    // URF source
    if (hasUniformRegister) {
        uint32_t urb = rec->context->hal.getURb(inst);

        // MOV R6, Urb
        sym[16].name = "MC_STUB_LMEM_LDST_MOV_URB";
        rec->context->hal.genMovFromUR(6, urb, (uint64_t*)(&sym[16].val));
        setSymbolSize(rec->context, &sym[16]);
    }


    res = loadModuleFromCubin(&mod, rec->context, allCubins_memcheck_stub_lmem_ldst, sym,
                              sizeof(sym)/sizeof(sym[0]));
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load cubins\n"));
        return res;
    }

    func = mcModuleGetFuncByName(mod, "memcheckStubLocalLDST");
    if (!func) {
        CU_ERROR_PRINT(("Could not get stub function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    tres = toolsListAppend(recData->internalModules, mod);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to append module to list. (tres=%u)\n", tres));
        return CUDA_ERROR_UNKNOWN;
    }

    if (stubFunc) {
        CU_DEBUG_PRINT(("Returning global ldst stub entry at : 0x%" PRIx64 "\n",
                        func->mem.dev.dPtr));
        *stubFunc = func;
    }

    return res;
}
CUresult
memcheck_toolModeInitialize(MCoptions *options, MCtoolMode *toolMode)
{
    MCtoolModeArchState *arch_sm30 = NULL;
    MCtoolModeArchState *arch_sm35 = NULL;
    MCtoolModeArchState *arch_sm50 = NULL;
    MCtoolModeArchState *arch_sm52 = NULL;
    MCtoolModeArchState *arch_sm60 = NULL;
    MCtoolModeArchState *arch_sm70 = NULL;
    MCtoolModeArchState *arch_sm75 = NULL;
    MCtoolModeArchState *arch_sm80 = NULL;

    CU_TRACE_FUNCTION();

    if (!toolMode)
        return CUDA_ERROR_UNKNOWN;

    // Raw table initialization
    arch_sm30 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM30];
    arch_sm35 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM35];
    arch_sm50 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM50];
    arch_sm52 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM52];
    arch_sm60 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM60];
    arch_sm70 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM70];
    arch_sm75 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM75];
    arch_sm80 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM80];

    if (options->enableSassPatching) {
        // Initialize global checking.

        // Kepler 10x Init
        arch_sm30->checkMask = TO_CHECKTYPE_MASK(GLOBAL);
        arch_sm30->opMask[MC_CHECK_TYPE_GLOBAL] = TO_INST_MASK(GENERIC_ST) |
                                                  TO_INST_MASK(GENERIC_LD);

        // Kepler 11x Init
        arch_sm35->checkMask = TO_CHECKTYPE_MASK(GLOBAL);
        arch_sm35->opMask[MC_CHECK_TYPE_GLOBAL] = TO_INST_MASK(GENERIC_ST) |
                                                  TO_INST_MASK(GENERIC_LD) |
                                                  TO_INST_MASK(GLOBAL_LD) ;


        // For newer clients enable local and shared
        if (options->client.version >= MC_CLIENT_VERSION_50 ||
            options->client.version == MC_CLIENT_VERSION_DBG) {
            // Kepler 10x init
            arch_sm30->checkMask |= TO_CHECKTYPE_MASK(SHARED) |
                                    TO_CHECKTYPE_MASK(LOCAL) ;
            arch_sm30->opMask[MC_CHECK_TYPE_GLOBAL] = TO_INST_MASK(GENERIC_LD) |
                                                      TO_INST_MASK(GENERIC_ST) |
                                                      TO_INST_MASK(ATOM)       |
                                                      TO_INST_MASK(RED) ;
            arch_sm30->opMask[MC_CHECK_TYPE_SHARED] = TO_INST_MASK(SHARED_ST) |
                                                      TO_INST_MASK(SHARED_LD) ;
            arch_sm30->opMask[MC_CHECK_TYPE_LOCAL]  = TO_INST_MASK(LOCAL_ST) |
                                                      TO_INST_MASK(LOCAL_LD) ;

            // Kepler 11x init
            arch_sm35->checkMask |= TO_CHECKTYPE_MASK(SHARED) |
                                    TO_CHECKTYPE_MASK(LOCAL) ;
            arch_sm35->opMask[MC_CHECK_TYPE_GLOBAL] = TO_INST_MASK(GENERIC_LD)  |
                                                      TO_INST_MASK(GENERIC_ST)  |
                                                      TO_INST_MASK(GLOBAL_LD)   |
                                                      TO_INST_MASK(ATOM)        |
                                                      TO_INST_MASK(RED)         ;
            arch_sm35->opMask[MC_CHECK_TYPE_SHARED] = TO_INST_MASK(SHARED_ST) |
                                                      TO_INST_MASK(SHARED_LD) ;
            arch_sm35->opMask[MC_CHECK_TYPE_LOCAL]  = TO_INST_MASK(LOCAL_ST) |
                                                      TO_INST_MASK(LOCAL_LD) ;

            // Maxwell GM10x init
            arch_sm50->checkMask = TO_CHECKTYPE_MASK(GLOBAL) |
                                   TO_CHECKTYPE_MASK(SHARED) |
                                   TO_CHECKTYPE_MASK(LOCAL) ;

            arch_sm50->opMask[MC_CHECK_TYPE_GLOBAL] = TO_INST_MASK(GENERIC_LD)  |
                                                      TO_INST_MASK(GENERIC_ST)  |
                                                      TO_INST_MASK(GLOBAL_ST)   |
                                                      TO_INST_MASK(GLOBAL_LD)   |
                                                      TO_INST_MASK(ATOM)        |
                                                      TO_INST_MASK(RED);

            arch_sm50->opMask[MC_CHECK_TYPE_SHARED] = TO_INST_MASK(SHARED_ST) |
                                                      TO_INST_MASK(SHARED_LD) |
                                                      TO_INST_MASK(ATOM_SHARED);
            arch_sm50->opMask[MC_CHECK_TYPE_LOCAL]  = TO_INST_MASK(LOCAL_ST) |
                                                      TO_INST_MASK(LOCAL_LD) ;

            // Maxwell GM20x init
            arch_sm52->checkMask = TO_CHECKTYPE_MASK(GLOBAL) |
                                   TO_CHECKTYPE_MASK(SHARED) |
                                   TO_CHECKTYPE_MASK(LOCAL) ;

            arch_sm52->opMask[MC_CHECK_TYPE_GLOBAL] = TO_INST_MASK(GENERIC_LD)  |
                                                      TO_INST_MASK(GENERIC_ST)  |
                                                      TO_INST_MASK(GLOBAL_ST)   |
                                                      TO_INST_MASK(GLOBAL_LD)   |
                                                      TO_INST_MASK(ATOM)        |
                                                      TO_INST_MASK(RED);

            arch_sm52->opMask[MC_CHECK_TYPE_SHARED] = TO_INST_MASK(SHARED_ST) |
                                                      TO_INST_MASK(SHARED_LD) |
                                                      TO_INST_MASK(ATOM_SHARED);
            arch_sm52->opMask[MC_CHECK_TYPE_LOCAL]  = TO_INST_MASK(LOCAL_ST) |
                                                      TO_INST_MASK(LOCAL_LD) ;
            // Pascal GP10x init
            arch_sm60->checkMask = TO_CHECKTYPE_MASK(GLOBAL) |
                                   TO_CHECKTYPE_MASK(SHARED) |
                                   TO_CHECKTYPE_MASK(LOCAL) ;

            arch_sm60->opMask[MC_CHECK_TYPE_GLOBAL] = TO_INST_MASK(GENERIC_LD)  |
                                                      TO_INST_MASK(GENERIC_ST)  |
                                                      TO_INST_MASK(GLOBAL_ST)   |
                                                      TO_INST_MASK(GLOBAL_LD)   |
                                                      TO_INST_MASK(ATOM)        |
                                                      TO_INST_MASK(RED);

            arch_sm60->opMask[MC_CHECK_TYPE_SHARED] = TO_INST_MASK(SHARED_ST) |
                                                      TO_INST_MASK(SHARED_LD) |
                                                      TO_INST_MASK(ATOM_SHARED);
            arch_sm60->opMask[MC_CHECK_TYPE_LOCAL]  = TO_INST_MASK(LOCAL_ST) |
                                                      TO_INST_MASK(LOCAL_LD) ;

            // Volta GV10x init
            arch_sm70->checkMask = TO_CHECKTYPE_MASK(GLOBAL) |
                                   TO_CHECKTYPE_MASK(SHARED) |
                                   TO_CHECKTYPE_MASK(LOCAL);

            arch_sm70->opMask[MC_CHECK_TYPE_GLOBAL] = TO_INST_MASK(GENERIC_LD)  |
                                                      TO_INST_MASK(GENERIC_ST)  |
                                                      TO_INST_MASK(GLOBAL_ST)   |
                                                      TO_INST_MASK(GLOBAL_LD)   |
                                                      TO_INST_MASK(ATOM)        |
                                                      TO_INST_MASK(ATOM_GLOBAL) |
                                                      TO_INST_MASK(RED);

            arch_sm70->opMask[MC_CHECK_TYPE_SHARED] = TO_INST_MASK(SHARED_ST) |
                                                      TO_INST_MASK(SHARED_LD) |
                                                      TO_INST_MASK(ATOM_SHARED);
            arch_sm70->opMask[MC_CHECK_TYPE_LOCAL]  = TO_INST_MASK(LOCAL_ST) |
                                                      TO_INST_MASK(LOCAL_LD) ;

            // Turing TU10x init
            arch_sm75->checkMask = TO_CHECKTYPE_MASK(GLOBAL) |
                                   TO_CHECKTYPE_MASK(SHARED) |
                                   TO_CHECKTYPE_MASK(LOCAL);

            arch_sm75->opMask[MC_CHECK_TYPE_GLOBAL] = TO_INST_MASK(GENERIC_LD)  |
                                                      TO_INST_MASK(GENERIC_ST)  |
                                                      TO_INST_MASK(GLOBAL_ST)   |
                                                      TO_INST_MASK(GLOBAL_LD)   |
                                                      TO_INST_MASK(ATOM)        |
                                                      TO_INST_MASK(ATOM_GLOBAL) |
                                                      TO_INST_MASK(RED);

            arch_sm75->opMask[MC_CHECK_TYPE_SHARED] = TO_INST_MASK(SHARED_ST) |
                                                      TO_INST_MASK(SHARED_LD) |
                                                      TO_INST_MASK(ATOM_SHARED);
            arch_sm75->opMask[MC_CHECK_TYPE_LOCAL]  = TO_INST_MASK(LOCAL_ST) |
                                                      TO_INST_MASK(LOCAL_LD) ;

            // Ampere GA10x init
            arch_sm80->checkMask = TO_CHECKTYPE_MASK(GLOBAL) |
                                   TO_CHECKTYPE_MASK(SHARED) |
                                   TO_CHECKTYPE_MASK(LOCAL);

            arch_sm80->opMask[MC_CHECK_TYPE_GLOBAL] = TO_INST_MASK(GENERIC_LD)  |
                                                      TO_INST_MASK(GENERIC_ST)  |
                                                      TO_INST_MASK(GLOBAL_ST)   |
                                                      TO_INST_MASK(GLOBAL_LD)   |
                                                      TO_INST_MASK(ATOM)        |
                                                      TO_INST_MASK(ATOM_GLOBAL) |
                                                      TO_INST_MASK(RED);

            arch_sm80->opMask[MC_CHECK_TYPE_SHARED] = TO_INST_MASK(SHARED_ST) |
                                                      TO_INST_MASK(SHARED_LD) |
                                                      TO_INST_MASK(ATOM_SHARED);
            arch_sm80->opMask[MC_CHECK_TYPE_LOCAL]  = TO_INST_MASK(LOCAL_ST) |
                                                      TO_INST_MASK(LOCAL_LD) ;
        }
    }
    // Initialize functions
    toolMode->createPatchHelpers = memcheckCreatePatchHelpers;
    toolMode->destroyPatchHelpers = memcheckDestroyPatchHelpers;
    toolMode->hasPrologue = memcheckHasPrologue;
    toolMode->usesTrapHandler = memcheckUsesTrapHandler;
    toolMode->isArchSupported = memcheckIsArchSupported;
    toolMode->isOsSupported = memcheckIsOsSupported;
    toolMode->isModuleSupported = memcheckIsModuleSupported;
    toolMode->enableMemAccessCheck = memcheckEnableMemAccessCheck;
    toolMode->checkMemAccessDevAddr = memcheckCheckMemAccessDevAddr;

    toolMode->moduleLoadedCallback = memcheckModuleLoaded;
    toolMode->moduleUnloadedCallback = memcheckModuleUnloaded;
    toolMode->contextDestroyStartCallback = memcheckContextDestroyStart;
    toolMode->contextDestroyEndCallback = memcheckContextDestroyEnd;
    toolMode->heapSelectedCallback = memcheckHeapSelected;
    toolMode->ctxSyncCallback = memcheckCtxSync;
    toolMode->enableApiCheck = memcheckEnableApiCheck;
    toolMode->handlePatchCompletion = memcheckHandlePatchCompletion;
    toolMode->updateLaunchConfig = memcheckUpdateLaunchConfig;
    toolMode->contextCreatedCallback = memcheckContextCreatedCallback;
    toolMode->trapHandlerCallback = memcheckTrapHandlerCallback;
    toolMode->trapHandlerEndCallback = memcheckTrapHandlerEndCallback;
    toolMode->initEndCallback = memcheckInitEndCallback;

    toolMode->addAllocCallback = memcheckAddAllocCallback;
    toolMode->removeAllocCallback = memcheckRemoveAllocCallback;

    toolMode->getInternalModules = memcheckGetInternalModules;

    toolMode->getExceptionType = memcheckGetExceptionType;

    return CUDA_SUCCESS;
}
