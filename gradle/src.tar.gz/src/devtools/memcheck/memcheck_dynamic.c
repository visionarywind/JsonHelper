/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
*
*   Module: memcheck_dynamic.c
*
*   Description:
*       Structures and definitions for interface to dynamic checking schemes
*
******************************************************************************/

#include "memcheck.h"
#include "check_tool_common.h"
#include "cudamemcheck.h"
#include "memcheck_dynamic.h"
#include "memcheck_types.h"
#include "memcheck_error.h"
#include "memcheck_dynamic_schemes.h"

#include "cuisyscall.h"
#include "bikernels.h"
#include "cuisym.h"
#include "check_mc_context.h"

#define CU_MEMCHECK_FUNC_LENGTH 1024

/* Corresponds to MCDynamicFuncTypes */
const char* syscallFuncNames[] = {
    "check",
    "malloc",
    "free"
};

static CUresult loadSyscallTrampolines(MCDynamicState *state, MCcontext *mcctx);
/* Initializes dynamic module, including
    Allocating memory for module,
    Allocating memory for schemes,
    Calling the initialization function for each scheme
    Finally calling the callback for each scheme
*/

static CUresult
MCDynamicInitSchemes(MCcontext *mcctx)
{
    uint32_t i = 0;
    CUresult status =  CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_ERROR_PRINT(("Unknown context\n"));
        return CUDA_ERROR_INVALID_CONTEXT;
    }

    if (!mcctx->dynamic) {
        CU_ERROR_PRINT(("Cannot find dynamic structure\n"));
        status = CUDA_ERROR_UNKNOWN;
        goto error;
    }

    mcctx->dynamic->context = mcctx;
    mcctx->dynamic->numschemes = MC_DYNAMIC_SCHEMES_MAX;

    mcctx->dynamic->schemes = (MCDynamicScheme **)calloc(MC_DYNAMIC_SCHEMES_MAX,
                                                         sizeof *mcctx->dynamic->schemes);
    if (!mcctx->dynamic->schemes) {
        CU_ERROR_PRINT(("Cannot allocate schemes structure\n"));
        status = CUDA_ERROR_OUT_OF_MEMORY;
        goto error;
    }

    //Iterate over each scheme, calling its register function
    for (i = 0; i < MC_DYNAMIC_SCHEMES_MAX; ++i) {
        mcctx->dynamic->schemes[i] = (MCDynamicScheme *)calloc(1, sizeof (*mcctx->dynamic->schemes[i]));
        status = MCDynamicSchemeRegister[i](mcctx->dynamic->schemes[i]);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to register scheme \n"));
            goto error;
        }
    }

    return CUDA_SUCCESS;

error:

    if (mcctx->dynamic && mcctx->dynamic->schemes) {
        for (i = 0; i < MC_DYNAMIC_SCHEMES_MAX; ++i)
            if (mcctx->dynamic->schemes[i])
                free(mcctx->dynamic->schemes[i]);

        free(mcctx->dynamic->schemes);
    }

    return status;
}

/* Helper function to populate a dynamic function given the type */
static CUresult
loadFunc(MCDynamicScheme *scheme, MCcontext *mcctx, MCDynamicFunc *func, uint32_t type)
{
    CUresult status = CUDA_SUCCESS;
    char fname[CU_MEMCHECK_FUNC_LENGTH];

    CU_TRACE_FUNCTION();

    if (type >= MC_DYNAMIC_FUNC_MAX || !scheme || !func || !mcctx)
        return CUDA_ERROR_UNKNOWN;

    snprintf(fname, sizeof fname, "%s%s", scheme->prefix, syscallFuncNames[type]);
    status = cuiFuncGetByName(scheme->cumod, fname, &func->cufunc);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load function :%s\n", fname));
        return status;
    }

    func->funcDptr = mcctx->cuctx->device->hal.memobjGetPc(mcctx->cuctx, func->cufunc->memobj);
    func->config.regcount = func->cufunc->finalRegcount;
    func->config.crssize = func->cufunc->syncStackSize.launch;
    func->config.systemStackSize = (uint32_t)func->cufunc->stackSize;
    func->type = type;

    CU_TRACE_PRINT(("Loaded function : %s\n", fname));

    return status;
}

/* Function to walk through and populate all device functions for all schemes
    Each scheme that succeeds is marked initialized
    This function is called after cuiModuleLoadDataEx is called on
    the memcheck module. The device functions for each registered scheme
    are found and added in the funcs array. When this completes successfully
    the initialized bit in the scheme is set.
*/
static CUresult
MCDynamicLoadDeviceFunctions(MCcontext *mcctx, CUmod* cumod)
{
    uint32_t i = 0, ftype = 0;
    MCDynamicScheme *scheme = NULL;
    MCDynamicFunc *func = NULL;
    CUresult status = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!cumod || !mcctx) {
        CU_ERROR_PRINT(("Invalid context or module\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /*  Initialize() must be called before this, and so
        dynamic and schemes must already be allocated  */

    if (!mcctx->dynamic)
        return CUDA_SUCCESS;

    if (!mcctx->dynamic->schemes) {
        CU_ERROR_PRINT(("Dynamic memcheck not initialized\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    for (i = 0; i < MC_DYNAMIC_SCHEMES_MAX; ++i) {
        //Finish the rest of the setup for this scheme
        scheme = mcctx->dynamic->schemes[i];

        if (!scheme)
            return CUDA_ERROR_UNKNOWN;  //Should not happen

        scheme->cumod = cumod;

        status = CUDA_SUCCESS;
        memset(scheme->funcs, MC_DYNAMIC_FUNC_MAX, sizeof *scheme->funcs);

        for (ftype = 0; ftype < MC_DYNAMIC_FUNC_MAX; ++ftype) {
            func = (MCDynamicFunc *)calloc(1, sizeof *func);
            status = loadFunc(scheme, mcctx, func, ftype);
            if (status != CUDA_SUCCESS) {
                free(func);
                func = NULL;
                break;
            }
            scheme->funcs[ftype] = func;
        }

        //If any function failed, skip
        if (status != CUDA_SUCCESS)
            continue;

        //Run the callback to initialize anything that
        //might be scheme dependent
        scheme->initialize(scheme);

        scheme->initialized = 1;
        CU_TRACE_PRINT(("Scheme %u is ready. Name:%s\n", i, scheme->name));
    }

    return CUDA_SUCCESS;
}

static bool
ctxUsesMalloc(MCcontext *mcctx)
{
    CUctx *ctx = NULL;

    if (!mcctx) {
        CU_TRACE_PRINT(("Invalid context\n"));
        return false;
    }

    ctx = mcctx->cuctx;

    //For the context, find the syscall module
    if (!ctx || !ctx->syslib.mod) {
        CU_TRACE_PRINT(("No syscall module found\n"));
        return false;
    }

    //Check to ensure malloc and free exist
    if (!(ctx->syslib.activeSyscalls & (1ULL << SYSCALL_ID_MALLOC)) &&
        !(ctx->syslib.activeSyscalls & (1ULL << SYSCALL_ID_FREE))) {
        CU_TRACE_PRINT(("Could not find malloc and free\n"));
        return false;
    }
    return true;
}

/*  Main initialization function.
    This will load and initialize the dynamic checker
    and set the appropriate state in MCDynState in gvars

    This function is called from the context created callback.
    What we do here is the following :
    0. Determine if dynamic memcheck should be enabled (i.e. the
       use is requested and the app has malloc and free)
    1. Initialize the memcheck dynamic internal structures
    2. Load the trampolines for malloc and free
        This involves loading the malloc & the ***orig_malloc functions
        and the same for free and ***orig_free
        The devptr of malloc is extracted.
    3. Load the built in cubin containing memcheck code.
        This cubin is loaded so that it bypasses the trampolines
        this is essential to ensure there are no circular calls
    4. Initialize all the schemes in the cubin.
    5. Set the state of the dynamic checker to initialized.

*/
CUresult
MCDynamicInitialize(MCcontext *mcctx)
{
    CUresult res = CUDA_SUCCESS;
    CUmod *cumod = NULL;
    NvU8 savedConstData[CU_SYSCALL_MAX_CONST_SIZE];

    CU_TRACE_FUNCTION();

    if (!mcctx || !mcctx->dynamic) {
        CU_ERROR_PRINT(("Unknown context or dynamic structures not initialized\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    //Early exit if dynamic checker is not requested / needed
    if (!mcctx->gvars->options.requestedDynamic) {
        CU_TRACE_PRINT(("Dynamic memcheck not requested.\n"));
        mcctx->dynamic->dynState.state = MC_DYN_DISABLED;
        return CUDA_SUCCESS;
    }

    //If the context doesnt use malloc/free, dont use dynamic memcheck
    if (!ctxUsesMalloc(mcctx)) {
        CU_TRACE_PRINT(("Context does not need dynamic memcheck\n"));
        mcctx->dynamic->dynState.state = MC_DYN_DISABLED;
        return CUDA_SUCCESS;
    }

    //Set the state to initializing
    mcctx->dynamic->dynState.state = MC_DYN_INITIALIZING;

    //Initialize internal structures
    res = MCDynamicInitSchemes(mcctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Dynamic memcheck initialization failed\n"));
        goto error;
    }

    // WAR bug 2321221: save driver syscall const data before loading
    // memcheck syscall module
    memcpy(savedConstData,
           mcctx->cuctx->syslib.constData,
           sizeof(savedConstData));

    // Load memcheck syscalls module
    res = loadModuleFromCubinCommon(&mcctx->dynamic->mod,
                                    mcctx,
                                    allCubins_memcheck_syscalls,
                                    NULL,       // relsymbols
                                    0,          // numsyms
                                    true,       // bypassDebugger
                                    true);      // bypassTrampoline
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load syscall checker module\n"));
        goto error;
    }

    // WAR bug 2321221: restore driver syscall const data
    memcpy(mcctx->cuctx->syslib.constData,
           savedConstData,
           sizeof(savedConstData));

    //Load up the syscall trampolines
    res = loadSyscallTrampolines(&mcctx->dynamic->dynState, mcctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load trampoline functions\n"));
        goto error;
    }

    //Load all the schemes
    res = MCDynamicLoadDeviceFunctions(mcctx, mcctx->dynamic->mod->cumod);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load memcheck schemes\n"));
        goto error;
    }

    //Finally, set the state of the checker
    mcctx->dynamic->dynState.state = MC_DYN_INITIALIZED;
    return res;

error:

    mcctx->dynamic->dynState.state = MC_DYN_DISABLED;
    printInternalError(CU_MEMCHECK_ERROR_DYNAMIC_INIT_FAILED,
                       mcctx->gvars);
    return res;
}

static void
finalizeScheme(MCDynamicScheme *scheme)
{
    uint32_t i = 0;

    CU_TRACE_FUNCTION();

    if (!scheme->initialized)
        return;

    scheme->initialized = 0;

    //Do a finalize callback
    scheme->finalize(scheme);

    for (i = 0; i < MC_DYNAMIC_FUNC_MAX; ++i)
        free(scheme->funcs[i]);
}

/*  Main finalization function
    This will cleanup all the state in dynamic memcheck
 */
CUresult
MCDynamicFinalize(MCcontext *mcctx)
{
    uint32_t i = 0;

    CU_TRACE_FUNCTION();

    if (!mcctx || !mcctx->dynamic)
        return CUDA_SUCCESS;

    if (mcctx->dynamic->schemes) {
        for (i = 0; i < MC_DYNAMIC_SCHEMES_MAX; ++i) {
            finalizeScheme(mcctx->dynamic->schemes[i]);
            free(mcctx->dynamic->schemes[i]);
        }
        free(mcctx->dynamic->schemes);
    }

    return CUDA_SUCCESS;
}

/*  Get a scheme by the type
    This will return NULL if the context is not ready,
    or if the type exceeds the MAX_SCHEMES
*/
MCDynamicScheme*
getDynamicSchemeByType(MCcontext *mcctx, uint32_t schemetype)
{
    if (!mcctx || !mcctx->dynamic ||
        schemetype >= MC_DYNAMIC_SCHEMES_MAX)
        return NULL;

    return (mcctx->dynamic->schemes[schemetype]);
}

/*  Loads the data for a single trampoline.
    This will get the original function, the trampoline function
    and the device pointer for the original function.
*/
static CUresult
loadTrampoline(MCTrampolineState *trampoline, CUctx *cuctx, const char* name)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!trampoline || !cuctx || !name)
        return res;

    //Find the trampoline function
    res = cuiSyscallGetFuncByName(cuctx, name, &trampoline->trampFunc);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to find trampoline function : %s\n", name));
        return res;
    }

    //Find the original function
    res = cuiSyscallGetOrigFuncByName(cuctx, name, &trampoline->origFunc);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to find original function :%s\n", name));
        return res;
    }

    if (!trampoline->origFunc || !trampoline->origFunc->memobj) {
        CU_ERROR_PRINT(("Failed to read original function : %s\n", name));
        return CUDA_ERROR_UNKNOWN;
    }

    //Save off the original entry point
    trampoline->origDptr = cuctx->device->hal.memobjGetPc(cuctx, trampoline->origFunc->memobj);
    CU_TRACE_PRINT(("Found %s trampoline at 0x%" PRIx64 ", pointing at 0x%" PRIx64 "\n",
                    name, (uint64_t)cuctx->device->hal.memobjGetPc(cuctx, trampoline->trampFunc->memobj),
                    trampoline->origDptr));

    return res;
}

/*  Loads the information for the trampolines for malloc and free
*/
static CUresult
loadSyscallTrampolines(MCDynamicState *state, MCcontext *mcctx)
{
    CUresult res = CUDA_SUCCESS;
    CUctx *ctx = NULL;

    CU_TRACE_FUNCTION();

    if (!state || !mcctx)
        return CUDA_ERROR_UNKNOWN;

    if (state->state != MC_DYN_INITIALIZING)
        return CUDA_SUCCESS;

    ctx = mcctx->cuctx;

    //Ensure the context uses malloc
    if (!ctxUsesMalloc(mcctx)) {
        CU_ERROR_PRINT(("Trampoline load called in context that doesnt use syscalls\n"));
        state->state = MC_DYN_DISABLED;
        return CUDA_ERROR_UNKNOWN;
    }

    //Create memory for trampolines
    state->trampolines = (MCTrampolineState *)calloc(MC_DYNAMIC_FUNC_MAX, sizeof *(state->trampolines));

    //Load the trampoline data for the malloc syscall
    res = loadTrampoline(&state->trampolines[MC_DYNAMIC_FUNC_MALLOC], ctx,
                         syscallFuncNames[MC_DYNAMIC_FUNC_MALLOC]);

    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load malloc trampoline. Disabling dynamic memcheck\n"));
        state->state = MC_DYN_FAILED;
        return res;
    }

    //Load the trampoline data for the free syscall
    res = loadTrampoline(&state->trampolines[MC_DYNAMIC_FUNC_FREE], ctx,
                         syscallFuncNames[MC_DYNAMIC_FUNC_FREE]);

    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load free trampoline. Disabling dynamic memcheck\n"));
        state->state = MC_DYN_FAILED;
        return res;
    }

    if (!state->trampolines[MC_DYNAMIC_FUNC_MALLOC].origFunc ||
        !state->trampolines[MC_DYNAMIC_FUNC_FREE].origFunc) {
        CU_ERROR_PRINT(("Failed to locate malloc/free functions\n"));
        state->state = MC_DYN_FAILED;
        return CUDA_ERROR_UNKNOWN;
    }

    return res;
}

/*  Patch a trampoline
    This will call into the memcheck HAL and use it to patch the trampoline
    This will also mark the trampoline as patched
 */
static CUresult
patchTrampoline(MCcontext *mcctx, CUtoolsStreamHandle stream, MCTrampolineState *trampoline, MCDynamicFunc *target)
{
    CUresult res = CUDA_SUCCESS;
    MCfunc *mcfunc = NULL;
    NvU64 trampolinePc = 0;

    CU_TRACE_FUNCTION();

    if (!mcctx || !trampoline || !target)
        return CUDA_ERROR_UNKNOWN;

    // Get the MC func
    trampolinePc = mcctx->cuctx->device->hal.memobjGetPc(mcctx->cuctx, trampoline->trampFunc->memobj);
    mcfunc = mcContextGetFuncByAddr(mcctx, trampolinePc);
    if (!mcfunc) {
        CU_ERROR_PRINT(("Could not find trampoline's function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Call into MC hal to patch trampoline
    res = mcctx->hal.patchTrampoline(&mcfunc->mem,
                                     target->funcDptr, mcctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Trampoline patching failed\n"));
        return res;
    }

    CU_TRACE_PRINT(("Patched %s trampoline at 0x%" PRIx64 " to 0x%" PRIx64 "\n",
                    mcfunc->funcName, mcfunc->mem.dev.dPtr, target->funcDptr));

    // Download patch to device
    res = CCmemShadowHtoDStream(&mcfunc->mem, &mcfunc->mem, stream, CC_MEM_SHADOW_ACTION_MEMCPY);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to upload new trampoline\n"));
        return res;
    }

    // Update the state of the trampoline
    trampoline->isPatched = 1;
    trampoline->newFunc = target->cufunc;

    return res;
}

/*  Unpatch a trampoline
    This will call into the memcheck HAL and use it to patch the trampoline
    with the original target device pointer.
    This will also mark the trampoline as unpatched
*/
static CUresult
unpatchTrampoline(MCcontext *mcctx, CUtoolsStreamHandle stream, MCTrampolineState *trampoline)
{
    CUresult res = CUDA_SUCCESS;
    MCfunc *mcfunc = NULL;
    NvU64 trampolinePc = 0;

    CU_TRACE_FUNCTION();

    if (!mcctx || !trampoline)
        return CUDA_ERROR_UNKNOWN;

    //Early exit
    if (!trampoline->isPatched) {
        CU_TRACE_PRINT(("Trampoline not patched\n"));
        return CUDA_SUCCESS;
    }

    // Get the MC func
    trampolinePc = mcctx->cuctx->device->hal.memobjGetPc(mcctx->cuctx, trampoline->trampFunc->memobj);
    mcfunc = mcContextGetFuncByAddr(mcctx, trampolinePc);
    if (!mcfunc) {
        CU_ERROR_PRINT(("Could not find trampoline's function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    //Patch in the original device ptr
    res = mcctx->hal.patchTrampoline(&mcfunc->mem,
                                     trampoline->origDptr, mcctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Restore trampoline failed \n"));
        return res;
    }

    // Download patch to device
    res = CCmemShadowHtoDStream(&mcfunc->mem, &mcfunc->mem, stream, CC_MEM_SHADOW_ACTION_MEMCPY);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to upload new trampoline\n"));
        return res;
    }

    //Reset the status
    trampoline->isPatched = 0;
    trampoline->newFunc = NULL;

    return res;
}

/*  Patches the malloc and free syscall trampolines to use a particular scheme */
static CUresult
patchSyscalls(MCcontext *mcctx, CUtoolsStreamHandle stream, MCDynamicScheme *scheme)
{
    CUresult res = CUDA_SUCCESS;
    MCDynamicState *dynState = NULL;
    MCTrampolineState *malloc_trampoline = NULL;
    MCTrampolineState *free_trampoline = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !mcctx->dynamic ||
        !scheme)
        return CUDA_ERROR_UNKNOWN;

    dynState = &mcctx->dynamic->dynState;

    //Early exit if the checker is not ready
    if (dynState->state != MC_DYN_INITIALIZED &&
        dynState->state != MC_DYN_ACTIVE) {
        CU_TRACE_PRINT(("Dynamic checker not ready\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    malloc_trampoline = &dynState->trampolines[MC_DYNAMIC_FUNC_MALLOC];
    //Patch the trampoline for the malloc function
    res = patchTrampoline(mcctx, stream, malloc_trampoline,
                          scheme->funcs[MC_DYNAMIC_FUNC_MALLOC]);

    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed patching on malloc function :%s\n", malloc_trampoline->name));
        return res;
    }

    free_trampoline = &dynState->trampolines[MC_DYNAMIC_FUNC_FREE];
    //Patch the trampoline for the free function
    res = patchTrampoline(mcctx, stream, free_trampoline,
                          scheme->funcs[MC_DYNAMIC_FUNC_FREE]);

    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed patching on free function :%s\n", free_trampoline->name));
        return res;
    }

    return CUDA_SUCCESS;
}

/*  Removes the syscall patches that may be present */
static CUresult
unpatchSyscalls(MCcontext *mcctx, CUtoolsStreamHandle stream)
{
    CUresult res = CUDA_SUCCESS;
    MCDynamicState *dynState = NULL;
    MCTrampolineState *malloc_trampoline = NULL;
    MCTrampolineState *free_trampoline = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !mcctx->dynamic)
        return CUDA_ERROR_UNKNOWN;

    dynState = &mcctx->dynamic->dynState;

    //Early exit
    if (dynState->state != MC_DYN_INITIALIZED &&
        dynState->state != MC_DYN_ACTIVE) {
        CU_TRACE_PRINT(("Dynamic checker not ready\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    malloc_trampoline = &dynState->trampolines[MC_DYNAMIC_FUNC_MALLOC];
    //Remove the patches and reset the trampoline
    res = unpatchTrampoline(mcctx, stream, malloc_trampoline);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed unpatching on malloc function :%s\n",
                        malloc_trampoline->name));
        return res;
    }

    free_trampoline = &dynState->trampolines[MC_DYNAMIC_FUNC_FREE];
    //Remove the patches and reset the trampoline
    res = unpatchTrampoline(mcctx, stream, free_trampoline);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed unpatching on free function :%s\n",
                        free_trampoline->name));
        return res;
    }

    return CUDA_SUCCESS;
}

/*  Activates a particular scheme
    1. Checks if schemetype is valid and initialized
    2. If selectedScheme is set, deactivate the existing scheme
    3. Activate the scheme by patching it in and calling its beforeLaunch function
    4. Set the dynamic state to enabled
    5. Set it as the active scheme
*/
CUresult
MCDynamicActivateScheme(MCcontext *mcctx, CUtoolsStreamHandle stream, uint32_t schemetype)
{
    MCDynamicScheme *cand = NULL;
    CUresult res = CUDA_SUCCESS;
    MCDynamicState *dynState = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !mcctx->dynamic ||
        schemetype >= MC_DYNAMIC_SCHEMES_MAX) {
        CU_ERROR_PRINT(("Bad args to activate scheme %u\n", schemetype));
        return CUDA_ERROR_UNKNOWN;
    }

    if (mcctx->dynamic->dynState.state != MC_DYN_INITIALIZED &&
        mcctx->dynamic->dynState.state != MC_DYN_ACTIVE) {
        CU_TRACE_PRINT(("Dynamic memcheck is not activated\n"));
        return CUDA_SUCCESS;
    }

    dynState = &mcctx->dynamic->dynState;

    //Check if a scheme is already active
    if (dynState->activeScheme) {
        //If this is a redundant activation, early exit
        if (dynState->activeScheme->type == schemetype) {
            CU_TRACE_PRINT(("Scheme %u is already active \n", schemetype));
            return CUDA_SUCCESS;
        }
        //Deactivate the previous scheme
        CU_TRACE_PRINT(("Found active scheme. Deactivating\n"));
        MCDynamicDeactivateScheme(mcctx, stream);
    }

    //Locate the requested scheme
    cand = getDynamicSchemeByType(mcctx, schemetype);
    if (!cand) {
        CU_ERROR_PRINT(("Failed to find scheme %u\n", schemetype));
        return CUDA_ERROR_UNKNOWN;
    }

    //If the scheme failed to load, exit
    if (!cand->initialized) {
        CU_ERROR_PRINT(("Scheme found, but uninitialized. \n"));
        return CUDA_ERROR_UNKNOWN;
    }

    //This is the active scheme, do the activation
    //1. Call MCHal to perform trampoline patching
    //2. Call the scheme's beforeRun
    res = patchSyscalls(mcctx, stream, cand);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Patching syscalls failed\n"));
        return res;
    }

    //Do the scheme's beforeRun
    res = cand->activate(cand, mcctx, stream);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Activating scheme %u failed\n", schemetype));
        return res;
    }

    //Set the state of the checker
    dynState->activeScheme = cand;
    dynState->state = MC_DYN_ACTIVE;

    return CUDA_SUCCESS;
}

/*  Deactivates a particular scheme
    1. If the schemetype is not the currently active scheme, return
    2. Else, call the scheme afterLaunch function
    3. unset the active scheme pointer
    4. Set the state back to initialized
*/
CUresult
MCDynamicDeactivateScheme(MCcontext *mcctx, CUtoolsStreamHandle stream)
{
    CUresult res = CUDA_SUCCESS;
    MCDynamicState *dynState;

    if (!mcctx || !mcctx->dynamic) {
        CU_ERROR_PRINT(("Bad args to deactivate scheme \n"));
        return CUDA_ERROR_UNKNOWN;
    }

    dynState = &mcctx->dynamic->dynState;

    //Early exits if nothing is active
    if (dynState->state != MC_DYN_ACTIVE) {
        CU_TRACE_PRINT(("Dynamic checker not active\n"));
        return CUDA_SUCCESS;
    }

    if (!dynState->activeScheme) {
        CU_TRACE_PRINT(("No scheme active.\n"));
        return CUDA_SUCCESS;
    }

    //Do the uninitialization
    //1. Call the scheme's afterRun
    //2. Unpatch the trampoline
    res = dynState->activeScheme->deactivate(dynState->activeScheme, mcctx, stream);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Deactivation failed on scheme :%u\n",
                        dynState->activeScheme->type));
        dynState->state = MC_DYN_FAILED;
        return res;
    }

    res = unpatchSyscalls(mcctx, stream);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Unpatching syscalls failed. Must force immediate app termination\n"));
        dynState->state = MC_DYN_FAILED;
        return res;
    }

    //Reset the dynamic checker state
    dynState->activeScheme = NULL;
    dynState->state = MC_DYN_INITIALIZED;
    return CUDA_SUCCESS;
}

/* Copies data into the syscall const bank for dynamic memcheck host->device
   communication. This is borrowed from syscalls/scutils.c */
CUresult MCWriteSyscallConstBank(MCcontext *mcctx, CUmod *mod, const char *name, const void *data, size_t size)
{
    CUresult status;
    uint64_t offset;
    CUdev *device;
    NvU64 sizeCheck;
    NvU32 const_bank;
    NvU64 const_offset;

    if (!mcctx || !mcctx->cuctx || !mod ||
        !name || !data || size <= 0)
        return CUDA_ERROR_INVALID_VALUE;

    device = mcctx->cuctx->device;

    status = cuiSymGetByName(mod->symtable, name, &const_bank,
                             &const_offset, NULL, &sizeCheck,
                             NULL);

    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("cuiSymGetByName look up failed with constant %s\n", name));
        return status;
    }
    if (size != sizeCheck) {
        CU_ERROR_PRINT(("Host/device size mismatch with constant %s\n", name));
        return CUDA_ERROR_INVALID_VALUE;
    }
    if (const_bank != device->state.abiConstBanks.syscall) {
        CU_ERROR_PRINT(("Bad syscall const bank for constant %s (got %d, "
                        "expected %d)\n", name, const_bank,
                        device->state.abiConstBanks.syscall));
        return CUDA_ERROR_INVALID_VALUE;
    }
    if (const_offset < device->state.abiConstBanks.syscallOffset) {
        CU_ERROR_PRINT(("Syscall constant offset too low for %s\n", name));
        return CUDA_ERROR_INVALID_VALUE;
    }
    if (const_offset+size > device->state.abiConstBanks.syscallOffset+CU_SYSCALL_MAX_CONST_SIZE) {
        CU_ERROR_PRINT(("Syscall constant too large for %s (should "
                        "CU_SYSCALL_MAX_CONST_SIZE be increased?)\n", name));
        return CUDA_ERROR_INVALID_VALUE;
    }

    offset = (uint64_t)const_offset;

    memcpy(mcctx->cuctx->syslib.constData + offset -
           device->state.abiConstBanks.syscallOffset, data, size);

    return CUDA_SUCCESS;
}

CUresult
MCDynamicGetCheckFuncAddress(MCcontext *mcctx, uint64_t *jumpaddr)
{
    CU_TRACE_FUNCTION();

    if (!mcctx || !jumpaddr) {
        CU_ERROR_PRINT(("Bad params\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!mcctx->dynamic) {
        CU_ERROR_PRINT(("Dynamic memcheck not enabled\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (mcctx->dynamic->dynState.state != MC_DYN_ACTIVE) {
        CU_ERROR_PRINT(("Dynamic memcheck not active\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!mcctx->dynamic->dynState.activeScheme) {
        CU_ERROR_PRINT(("Active scheme not set\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!mcctx->dynamic->dynState.activeScheme->funcs[MC_DYNAMIC_FUNC_CHECK]) {
        CU_ERROR_PRINT(("Failed to read Check function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *jumpaddr = mcctx->dynamic->dynState.activeScheme->funcs[MC_DYNAMIC_FUNC_CHECK]->funcDptr;
    return CUDA_SUCCESS;
}

CUresult
MCDynamicParseErrorEntry(MCcontext *mcctx, CUmemcheck_record *err, uint32_t *hasError)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!mcctx || !err || !hasError) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *hasError = 0;

    if (!mcctx->dynamic) {
        CU_TRACE_PRINT(("Dynamic memcheck not enabled\n"));
        return CUDA_SUCCESS;
    }

    if (mcctx->dynamic->dynState.state != MC_DYN_ACTIVE) {
        CU_TRACE_PRINT(("Dynamic memcheck not active\n"));
        return CUDA_SUCCESS;
    }

    if (!mcctx->dynamic->dynState.activeScheme) {
        CU_TRACE_PRINT(("Active scheme not set\n"));
        return CUDA_SUCCESS;
    }

    res = mcctx->dynamic->dynState.activeScheme->parseSyscallError(mcctx->dynamic->dynState.activeScheme, mcctx, err, hasError);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to parse syscall error entry\n"));
        return res;
    }

    return CUDA_SUCCESS;
}

CUresult
MCDynamicAddLeaks(MCcontext *mcctx)
{
    CUresult res = CUDA_SUCCESS;
    CUtoolsStreamHandle stream;

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!mcctx->dynamic) {
        CU_TRACE_PRINT(("Dynamic memcheck not enabled\n"));
        return CUDA_SUCCESS;
    }

    if (mcctx->dynamic->dynState.state != MC_DYN_ACTIVE) {
        CU_TRACE_PRINT(("Dynamic memcheck not active\n"));
        return CUDA_SUCCESS;
    }

    if (!mcctx->dynamic->dynState.activeScheme) {
        CU_TRACE_PRINT(("Active scheme not set\n"));
        return CUDA_SUCCESS;
    }

    res = mcctx->gvars->tools.context->CtxGetBarrierStream(mcctx->cuctx, &stream);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to get the barrier stream\n"));
        return res;
    }

    res = mcctx->dynamic->dynState.activeScheme->addLeaks(mcctx->dynamic->dynState.activeScheme, mcctx, stream);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to parse syscall error entry\n"));
        return res;
    }

    return res;
}

CUresult
MCDynamicCheckAccess(MCcontext *mcctx, CUtoolsStreamHandle stream, uint64_t addr, uint64_t size, CCmemAccessError *err)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!mcctx || !err) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!mcctx->dynamic) {
        CU_TRACE_PRINT(("Dynamic memcheck not enabled\n"));
        return CUDA_SUCCESS;
    }

    if (mcctx->dynamic->dynState.state != MC_DYN_ACTIVE) {
        CU_TRACE_PRINT(("Dynamic memcheck not active\n"));
        return CUDA_SUCCESS;
    }

    if (!mcctx->dynamic->dynState.activeScheme) {
        CU_TRACE_PRINT(("Active scheme not set\n"));
        return CUDA_SUCCESS;
    }

    res = mcctx->dynamic->dynState.activeScheme->checkAccess(mcctx->dynamic->dynState.activeScheme,
                                                             mcctx, stream, addr, size, err);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to check access\n"));
        return res;
    }

    return res;
}

/*  Query a particular scheme
    * Checks if schemetype is valid and initialized
    * If it is, populate the config with pointer to the malloc, free and check function config
*/
CUresult
MCDynamicGetSchemeConfig(MCcontext *mcctx, uint32_t schemetype, MCDynamicSchemeConfig *schemeConfig)
{
    MCDynamicScheme *cand = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !mcctx->dynamic ||
        schemetype >= MC_DYNAMIC_SCHEMES_MAX ||
        !schemeConfig) {
        CU_ERROR_PRINT(("Bad args to activate scheme %u\n", schemetype));
        return CUDA_ERROR_UNKNOWN;
    }

    if (mcctx->dynamic->dynState.state != MC_DYN_INITIALIZED &&
        mcctx->dynamic->dynState.state != MC_DYN_ACTIVE) {
        CU_TRACE_PRINT(("Dynamic memcheck is not activated\n"));
        return CUDA_SUCCESS;
    }

    //Locate the requested scheme
    cand = getDynamicSchemeByType(mcctx, schemetype);
    if (!cand) {
        CU_ERROR_PRINT(("Failed to find scheme %u\n", schemetype));
        return CUDA_ERROR_UNKNOWN;
    }

    //If the scheme failed to load, exit
    if (!cand->initialized) {
        CU_ERROR_PRINT(("Scheme found, but uninitialized. \n"));
        return CUDA_ERROR_UNKNOWN;
    }

    //Populate the structure
    schemeConfig->malloc = &cand->funcs[MC_DYNAMIC_FUNC_MALLOC]->config;
    schemeConfig->free   = &cand->funcs[MC_DYNAMIC_FUNC_FREE]->config;
    schemeConfig->check  = &cand->funcs[MC_DYNAMIC_FUNC_CHECK]->config;

    return CUDA_SUCCESS;
}
