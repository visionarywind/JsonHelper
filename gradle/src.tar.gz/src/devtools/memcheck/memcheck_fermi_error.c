/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: memcheck_fermi_error.c
 *
 *   Description:
 *       The trap handler callback function
 *
 ******************************************************************************/

#include "memcheck_types.h"
#include "halo.h"
#include "halo_internal.h"
#include "memcheck_error.h"
#include "cudadebugger.h"
#include "check_mc_context.h"
#include "check_mc_launch.h"

#include "rm_call.h"
CUresult
haloGenerateFullBacktrace(MCcontext *mcctx, uint32_t vsm, uint32_t wp,
                          uint32_t ln, CCBacktrace **ccbt)
{
    MClaunch *launch = NULL;
    CUresult res = CUDA_SUCCESS;

    if (!mcctx || !ccbt) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    launch = mcLaunchGetInContext(mcctx, mcctx->dev->smState[vsm].warp[wp].gridId64);

    if (launch) {
        res = cloneBacktraceHost(ccbt, launch->bt);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to create backtrace. Disabling\n"));
            *ccbt = NULL;
            return res;
        }

        if (mcctx->ctxOpts.btopts.enableDevBacktrace) {
            res = captureDeviceBacktrace((*ccbt), mcctx, mcctx->dev, vsm, wp, ln);
            if (res != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Failed to capture device backtrace. Disabling\n"));
                *ccbt = NULL;
                return res;
            }
        }
    }

    return CUDA_SUCCESS;
}

static CUresult
reportPreciseError(MCcontext *mcctx, uint32_t vsm, uint32_t wp,
                   uint32_t ln, CUDBGException_t laneException, uint64_t *errPc)
{
    uint32_t threadIdxX;
    uint32_t threadIdxY;
    uint32_t threadIdxZ;
    CuDim3   blockIdx;
    MCfunc *mcfunc = NULL;
    CUmemcheck_record rec = {0};
    CUmemcheck_error_record *err = NULL;
    CUDBGResult dbgRes = CUDBG_SUCCESS;
    ptxStorageKind storage = ptxUNSPECIFIEDStorage;
    CCBacktrace *ccbt = NULL;
    CUresult res = CUDA_SUCCESS;
    uint64_t pc = 0;

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid context\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Read the blockIdx
    dbgRes = mcctx->dev->halo.read_blockIdx(mcctx->dev, vsm, wp, &blockIdx);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read block index\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Read threadIdx from HALO
    dbgRes = mcctx->dev->halo.read_threadIdx(mcctx->dev, vsm, wp, ln,
                                             0,
                                             &threadIdxX,
                                             &threadIdxY,
                                             &threadIdxZ);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read threadIdx for sm:%u wp:%u ln:%u\n",
                        vsm, wp, ln));
        return CUDA_ERROR_UNKNOWN;
    }

    // Create an error record
    if (!createNewErrorRecord(CU_MEMCHECK_RECORD_MEM_PRECISE, &rec)) {
        CU_ERROR_PRINT(("Failed to create error record\n"));
        goto error;
    }

    err = &rec.cases.error;

    // Use the HALO to read the original PC
    dbgRes = mcctx->dev->halo.mcinterop_getPatchPC(mcctx->dev,
                                                   vsm, wp, ln,
                                                   &pc);

    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read original PC on sm:%u wp:%u ln:%u\n",
                        vsm, wp, ln));
        goto error;
    }

    *errPc = pc;
    mcfunc = mcContextGetFuncByAddr(mcctx, pc);

    if (mcfunc)
        err->cases.memPrecise.pc = (uint32_t)(uintptr_t)(pc - mcfunc->mem.dev.dPtr);
    else {
        CU_DEBUG_PRINT(("Failed to find function for pc 0x%" PRIx64 "\n", (uint64_t)pc));
        err->cases.memPrecise.pc = (uint32_t)pc;
    }

    // Use the HALO to read the target address
    dbgRes = mcctx->dev->halo.mcinterop_getLDSTTargetAddr(mcctx->dev,
                                                          vsm, wp, ln,
                                                          &err->cases.memPrecise.address,
                                                          &storage);

    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read target address on sm:%u wp:%u ln:%u\n", vsm, wp, ln));
        goto error;
    }

    // Populate the error record
    err->cases.memPrecise.exception = laneException;
    err->cases.memPrecise.blockIdxX = blockIdx.x;
    err->cases.memPrecise.blockIdxY = blockIdx.y;
    err->cases.memPrecise.blockIdxZ = blockIdx.z;
    err->cases.memPrecise.threadIdxX = threadIdxX;
    err->cases.memPrecise.threadIdxY = threadIdxY;
    err->cases.memPrecise.threadIdxZ = threadIdxZ;

    err->cases.memPrecise.type = CU_MEMCHECK_ADDR_TYPE_NONE;
    // Get the type
    switch (storage) {
    case ptxGlobalStorage:
        err->cases.memPrecise.type = CU_MEMCHECK_ADDR_TYPE_GLOBAL;
        break;
    case ptxLocalStorage:
        err->cases.memPrecise.type = CU_MEMCHECK_ADDR_TYPE_LOCAL;
        break;
    case ptxSharedStorage:
        err->cases.memPrecise.type = CU_MEMCHECK_ADDR_TYPE_SHARED;
        break;
    default:
        break;
    };

    CU_TRACE_PRINT(("Found precise error at sm:%u wp:%u ln:%u block: (%u,%u,%u) thread:(%u,%u,%u) address:0x%" PRIx64 " pc:0x%x func:%s\n",
                    vsm, wp, ln,
                    err->cases.memPrecise.blockIdxX,
                    err->cases.memPrecise.blockIdxY,
                    err->cases.memPrecise.blockIdxZ,
                    err->cases.memPrecise.threadIdxX,
                    err->cases.memPrecise.threadIdxY,
                    err->cases.memPrecise.threadIdxZ,
                    err->cases.memPrecise.address,
                    err->cases.memPrecise.pc,
                    mcfunc ? mcfunc->funcName : "UNKNOWN"));

    res = haloGenerateFullBacktrace(mcctx, vsm, wp, ln, &ccbt);
    if (res != CUDA_SUCCESS) {
        CU_TRACE_PRINT(("Backtrace capture failed. Soldiering on\n"));
        ccbt = NULL;
    }

    // Add to record
    return addMemRecord(mcctx, &rec, mcfunc, ccbt);

error:
    return CUDA_ERROR_UNKNOWN;
}

static CUresult
reportSyscallError(MCcontext *mcctx, uint32_t vsm, uint32_t wp,
                   uint32_t ln)
{
    uint32_t threadIdxX;
    uint32_t threadIdxY;
    uint32_t threadIdxZ;
    CuDim3   blockIdx;
    uint32_t syscallError = 0;
    MCfunc *mcfunc = NULL;
    CUmemcheck_record rec = {0};
    CUmemcheck_error_record *err = NULL;
    CUDBGResult dbgRes = CUDBG_SUCCESS;
    CCBacktrace *ccbt = NULL;
    CUresult res = CUDA_SUCCESS;
    uint64_t pc = 0;

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid context\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Try to read the syscall error type
    dbgRes = mcctx->dev->halo.mcinterop_getSyscallError(mcctx->dev,
                                                        vsm, wp, ln,
                                                        &syscallError);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read syscall error\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Read the blockIdx
    dbgRes = mcctx->dev->halo.read_blockIdx(mcctx->dev, vsm, wp, &blockIdx);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read block index\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Read threadIdx from HALO
    dbgRes = mcctx->dev->halo.read_threadIdx(mcctx->dev, vsm, wp, ln,
                                             0,
                                             &threadIdxX,
                                             &threadIdxY,
                                             &threadIdxZ);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read threadIdx for sm:%u wp:%u ln:%u\n",
                        vsm, wp, ln));
        return CUDA_ERROR_UNKNOWN;
    }

    // Create an error record
    if (!createNewErrorRecord(CU_MEMCHECK_RECORD_MEM_SYSCALL, &rec)) {
        CU_ERROR_PRINT(("Failed to create error record\n"));
        goto error;
    }

    err = &rec.cases.error;

    // Read the PC from the HALO
    dbgRes = mcctx->dev->halo.readPC(mcctx->dev, vsm, wp, &pc);
    if (dbgRes != CUDBG_SUCCESS)
        return CUDA_ERROR_UNKNOWN;

    mcfunc = mcContextGetFuncByAddr(mcctx, pc);
    if (mcfunc)
        err->cases.memSyscall.pc = (uint32_t)(uintptr_t)(pc - mcfunc->mem.dev.dPtr);
    else {
        CU_DEBUG_PRINT(("Failed to find function for pc 0x%" PRIx64 "\n", (uint64_t)pc));
        err->cases.memSyscall.pc = (uint32_t)pc;
    }

    // Use the HALO to read the target address and size
    dbgRes = mcctx->dev->halo.mcinterop_getSyscallErrorData(mcctx->dev,
                                                            vsm, wp, ln,
                                                            &err->cases.memSyscall.address,
                                                            &err->cases.memSyscall.size);

    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read target address on sm:%u wp:%u ln:%u\n", vsm, wp, ln));
        goto error;
    }

    // Populate the error record
    err->cases.memSyscall.type = syscallError;
    err->cases.memSyscall.blockIdxX = blockIdx.x;
    err->cases.memSyscall.blockIdxY = blockIdx.y;
    err->cases.memSyscall.blockIdxZ = blockIdx.z;
    err->cases.memSyscall.threadIdxX = threadIdxX;
    err->cases.memSyscall.threadIdxY = threadIdxY;
    err->cases.memSyscall.threadIdxZ = threadIdxZ;

    CU_TRACE_PRINT(("Found precise error at sm:%u wp:%u ln:%u block: (%u,%u,%u) thread:(%u,%u,%u) address:0x%" PRIx64 " size:0x%" PRIx64 " pc:0x%u func:%s\n",
                    vsm, wp, ln,
                    err->cases.memSyscall.blockIdxX,
                    err->cases.memSyscall.blockIdxY,
                    err->cases.memSyscall.blockIdxZ,
                    err->cases.memSyscall.threadIdxX,
                    err->cases.memSyscall.threadIdxY,
                    err->cases.memSyscall.threadIdxZ,
                    err->cases.memSyscall.address,
                    err->cases.memSyscall.size,
                    err->cases.memSyscall.pc,
                    mcfunc ? mcfunc->funcName : "UNKNOWN"));


    res = haloGenerateFullBacktrace(mcctx, vsm, wp, ln, &ccbt);
    if (res != CUDA_SUCCESS) {
        CU_TRACE_PRINT(("Backtrace capture failed. Soldiering on\n"));
        ccbt = NULL;
    }

    // Add to record
    return addMemRecord(mcctx, &rec, mcfunc, ccbt);

error:
    return CUDA_ERROR_UNKNOWN;
}

static CUresult
populateImpreciseError(MCcontext *mcctx, uint32_t vsm, uint32_t wp, uint32_t ln,
                       CUDBGException_t laneException, CUmemcheck_record *rec, uint64_t *errPc)
{
    uint32_t threadIdxX;
    uint32_t threadIdxY;
    uint32_t threadIdxZ;
    CuDim3   blockIdx;
    CUDBGResult dbgRes = CUDBG_SUCCESS;
    CUmemcheck_error_record *err = NULL;
    uint64_t pc = 0, esrPc = 0;
    bool esrPcValid = false;
    MCfunc *mcfunc = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid context\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!rec) {
        CU_ERROR_PRINT(("Invalid error\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    err = &rec->cases.error;

    if (!createNewErrorRecord(CU_MEMCHECK_RECORD_MEM_IMPRECISE, rec)) {
        CU_ERROR_PRINT(("Failed to create error record\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Read the blockIdx
    dbgRes = mcctx->dev->halo.read_blockIdx(mcctx->dev, vsm, wp, &blockIdx);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read block index\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Read threadIdx from HALO
    dbgRes = mcctx->dev->halo.read_threadIdx(mcctx->dev, vsm, wp, ln,
                                             0,
                                             &threadIdxX,
                                             &threadIdxY,
                                             &threadIdxZ);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read threadIdx for sm:%u wp:%u ln:%u\n",
                        vsm, wp, ln));
        return CUDA_ERROR_UNKNOWN;
    }

    dbgRes = mcctx->dev->halo.getSMHwwErrorPC(mcctx->dev, vsm, wp, &esrPc, &esrPcValid);
    if (dbgRes != CUDBG_SUCCESS)
        return CUDA_ERROR_UNKNOWN;

    if (esrPcValid) {
        pc = esrPc;
    }
    else {
        dbgRes = mcctx->dev->halo.readPC(mcctx->dev, vsm, wp, &pc);
        if (dbgRes != CUDBG_SUCCESS)
            return CUDA_ERROR_UNKNOWN;
    }

    if (pc != 0) {
        *errPc = pc;

        mcfunc = mcContextGetFuncByAddr(mcctx, pc);
        if (mcfunc)
            err->cases.memImprecise.pc = (uint32_t)(uintptr_t)(pc - mcfunc->mem.dev.dPtr);
        else {
            CU_DEBUG_PRINT(("Failed to find function for pc 0x%" PRIx64 "\n", (uint64_t)pc));
            err->cases.memImprecise.pc = (uint32_t)pc;
        }
    } else
        err->cases.memImprecise.pc = ~0U;

    err->errortype = CU_MEMCHECK_RECORD_MEM_IMPRECISE;

    // Write the hardware error record
    err->cases.memImprecise.exception = laneException;
    err->cases.memImprecise.address = 0; // Don't know

    err->cases.memImprecise.blockIdxX = blockIdx.x;
    err->cases.memImprecise.blockIdxY = blockIdx.y;
    err->cases.memImprecise.blockIdxZ = blockIdx.z;
    err->cases.memImprecise.threadIdxX = threadIdxX;
    err->cases.memImprecise.threadIdxY = threadIdxY;
    err->cases.memImprecise.threadIdxZ = threadIdxZ;

    return CUDA_SUCCESS;
}

CUresult
memcheckTrapHandlerCallback(MCcontext *mcctx, CUmemobj* scratchpadMemobj, uint32_t smError)
{
#if NVCFG(GLOBAL_ARCH_FERMI)
    CUDBGResult dbgRes;
    CUresult res = CUDA_SUCCESS;
    uint32_t wp;
    uint32_t ln;
    CUDBGException_t laneException = (CUDBGException_t)0;
    CUwarpBitmask validWarps;
    uint32_t vsm;
    MCfunc *mcfunc = NULL;
    uint32_t numPrecise = 0;
    CUmemcheck_record *err = NULL;
    CCBacktrace *ccbt = NULL;
    uint32_t anyLaneHasException;
    uint64_t pc = 0;

    CU_ASSERT(mcctx);
    CU_ASSERT(scratchpadMemobj);

    CU_ASSERT(mcctx->dev);
    CU_ASSERT(mcctx->gvars);

    CU_TRACE_FUNCTION();

    if (!mcctx->gvars->haloInitialized)
        return CUDA_ERROR_UNKNOWN;

    CU_TRACE_PRINT(("Trap handler callback : nonblocking:%u smerror:%u\n",
                    mcctx->ctxOpts.launchMode, smError));

    /*  Main hardware state examining function
        There are two modes under which the function below does work
        either memcheck is in blocking launch mode, and has encountered
        a hardware exception, or memcheck was in nonblocking launch mode
        and hit a precise error.
        In nonblocking mode, this function is responsible for
        1. Printing error records (per lane) of all memcheck precise
           errors.
        2. Resetting the channel as necessary (based on --continue
           flag)
        3. Printing a hardware error record (only one) with details
           of the hardware exception

        In blocking mode, this function is responsible for
        1. Populating (not printing) the context hardware error record
           on a hardware exception.
        2. Always forcing a channel reset if a breakpoint was
           observed

        The order of events here is as follows:
        0. Early exit if no smerror was encountered and memcheck
           was in blocking launch mode.
        1. Setup the device state to what the HALO expects
        2. Collect the device state. This will mark lanes that
           have hardware exceptions. This will also set the exception
           state of lanes that have hit a memcheck precise error.
        3. Iterate over <sms, wp, lanes>, skipping invalid sms,
           invalid warps and lanes without exceptions
        4. For a lane, first check if memcheck was in nonblocking launch
           mode and hit a memcheck precise error. If this is the case,
           read data using the halo mcinterop and print an error record.
        5. If the lane has hit a memcheck precise error, but the launch
           was in blocking mode, set the channel reset flag. The scan
           should continue as a different warp/sm may have hit a hardware
           exception.
        6. If the lane has some other exception, and it is the first one,
           then populate the error record.
        7. If all loops are completed, and there are no memcheck precise
           errors or hardware exceptions, create an unknown exception entry
        8. Finally, if memcheck precise errors were encountered, set
           the channel reset flag to the forceError option.
        9. If this was launched in nonblocking mode, and hardware
           exceptions were reported, print the hardware error.
    */

    // If we are not in nonblocking mode, and there was
    // no smerror, do an early exit
    if (!smError &&
        mcctx->ctxOpts.launchMode == MC_CONTEXT_OPTION_LAUNCH_BLOCKING) {
        CU_TRACE_PRINT(("In blocking mode entered trap handler without smError\n"));
        mcctx->gvars->tools.trap->SetTrapAckAction(mcctx->cuctx, CU_TOOLS_TRAP_ACK_RESET);
    }

    res = mcContextHaloCheckTrapStateInitialize(mcctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to initialize trap state in HALO\n"));
        return res;
    }

    mcctx->dev->halo.clearSMState(mcctx->dev);
    dbgRes = mcctx->dev->halo.collectDeviceState(mcctx->dev, false, NULL);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to collect device state\n"));
        res =  CUDA_ERROR_UNKNOWN;
        goto cleanup_and_return;
    }

    for (vsm = 0; vsm < mcctx->dev->halo.deviceInfo.numSMs; ++vsm) {
        // only examine sm's with valid warps
        if (!warpBitmaskAny(&mcctx->dev->smState[vsm].state.tidValid))
            continue;

        warpBitmaskAssign(&validWarps, &mcctx->dev->smState[vsm].state.tidValid);
        for (wp = 0; wp < mcctx->dev->halo.deviceInfo.numWarpsPrSM;
             ++wp) {
            laneException = (CUDBGException_t)0;
            anyLaneHasException = 0;

            // examine only valid warps on sm
            if (!warpBitmaskGetBits(&validWarps, wp, 1))
                continue;

            for (ln = 0; ln < 32; ++ln) {
                laneException = mcctx->dev->smState[vsm].warp[wp].laneExceptions[ln];

                // examine only lanes with a valid exception
                if (!laneException)
                    continue;

                // This is a precise memcheck error in nonblocking mode
                if ((laneException == CUDBG_EXCEPTION_LANE_ILLEGAL_ADDRESS ||
                     laneException == CUDBG_EXCEPTION_LANE_INVALID_ATOMSYS ||
                     laneException == CUDBG_EXCEPTION_LANE_SYSCALL_ERROR)  &&
                    mcctx->ctxOpts.launchMode == MC_CONTEXT_OPTION_LAUNCH_NONBLOCKING) {
                    CU_TRACE_PRINT(("Hit a precise memcheck error at sm:%u wp:%u ln:%u\n", vsm, wp, ln));

                    if (laneException == CUDBG_EXCEPTION_LANE_SYSCALL_ERROR) {
                        res = reportSyscallError(mcctx, vsm, wp, ln);
                        if (res != CUDA_SUCCESS) {
                            CU_ERROR_PRINT(("Failed to report syscall error at "
                                            "sm:%u wp:%u ln:%u\n",
                                            vsm, wp, ln));
                            goto cleanup_and_return;
                        }
                    }
                    else {
                        res = reportPreciseError(mcctx, vsm, wp, ln, laneException, &pc);
                        if (res != CUDA_SUCCESS) {
                            CU_ERROR_PRINT(("Failed to report precise error at "
                                            "sm:%u wp:%u ln:%u\n", vsm, wp, ln));
                            goto cleanup_and_return;
                        }
                    }

                    anyLaneHasException = 1;
                    // Done with this lane
                    ++numPrecise;
                    continue;
                }
                else if (laneException == CUDBG_EXCEPTION_LANE_SYSCALL_ERROR) {
                    // Hit a breakpoint on a blocking launch.
                    CU_TRACE_PRINT(("Hit a memcheck syscall error in blocking mode. "
                                    "Deferring a forced reset. \n"));
                    mcctx->gvars->tools.trap->SetSMHandledSingleWarp(mcctx->cuctx, vsm, wp);
                    mcctx->gvars->tools.trap->SetTrapAckAction(mcctx->cuctx,
                                                               CU_TOOLS_TRAP_ACK_RESET);
                    anyLaneHasException = 1;
                    ++numPrecise;
                    continue;
                }
                else if (laneException == CUDBG_EXCEPTION_LANE_ILLEGAL_ADDRESS ||
                         laneException == CUDBG_EXCEPTION_LANE_INVALID_ATOMSYS) {
                    // Hit a breakpoint on a blocking launch.
                    CU_TRACE_PRINT(("Hit a memcheck precise error in blocking mode. "
                                    "Deferring a forced channel reset. \n"));
                    mcctx->gvars->tools.trap->SetTrapAckAction(mcctx->cuctx,
                                                               CU_TOOLS_TRAP_ACK_RESET);
                    anyLaneHasException = 1;
                    ++numPrecise;
                    continue;
                }

                // Lane has an exception, and its the first one
                if (!err) {
                    err = (CUmemcheck_record *)calloc(1, sizeof(*err));
                    if (!err) {
                        CU_ERROR_PRINT(("Failed to allocate error record\n"));
                        res = CUDA_ERROR_OUT_OF_MEMORY;
                        goto cleanup_and_return;
                    }
                    res = populateImpreciseError(mcctx, vsm, wp, ln, laneException, err, &pc);
                    if (res != CUDA_SUCCESS) {
                        CU_ERROR_PRINT(("Failed to read hardware exception\n"));
                        goto cleanup_and_return;
                    }

                    res = haloGenerateFullBacktrace(mcctx, vsm, wp, ln, &ccbt);
                    if (res != CUDA_SUCCESS) {
                        CU_TRACE_PRINT(("Backtrace capture failed. Soldiering on\n"));
                        ccbt = NULL;
                    }
                }
            }

            if (anyLaneHasException) {
                CU_TRACE_PRINT(("Setting warp handled due to memcheck precise error (vsm%u/wp%u)\n",
                                vsm, wp));
                mcctx->gvars->tools.trap->SetSMHandledSingleWarp(mcctx->cuctx, vsm, wp);
            }
        }
    }

    // Fall through. If no precise error was hit, then there is an unknown
    // hardware exception here
    if (!numPrecise && !err && !cuiGlobalsIsLegacyMpsClient()) {
        err = (CUmemcheck_record *)calloc(1, sizeof(*err));
        if (!err) {
            CU_ERROR_PRINT(("Failed to allocate error record\n"));
            res = CUDA_ERROR_OUT_OF_MEMORY;
            goto cleanup_and_return;
        }
        if (!createNewErrorRecord(CU_MEMCHECK_RECORD_MEM_IMPRECISE, err)) {
            CU_ERROR_PRINT(("Failed to create error record\n"));
            res = CUDA_ERROR_UNKNOWN;
            goto cleanup_and_return;
        }

        err->cases.error.errortype = CU_MEMCHECK_RECORD_MEM_IMPRECISE;
        err->cases.error.cases.memImprecise.exception = CUDBG_EXCEPTION_UNKNOWN;
        err->cases.error.cases.memImprecise.pc = ~0U;
        err->cases.error.cases.memImprecise.blockIdxX = 0;
        err->cases.error.cases.memImprecise.blockIdxY = 0;
        err->cases.error.cases.memImprecise.blockIdxZ = 0;
        err->cases.error.cases.memImprecise.threadIdxX = 0;
        err->cases.error.cases.memImprecise.threadIdxY = 0;
        err->cases.error.cases.memImprecise.threadIdxZ = 0;
    }

    // If precise errors were hit, use the forceError flag to determine
    // if we should reset the channel
    if (mcctx->gvars->options.nonblockingLaunch) {
        if (numPrecise) {
            if (!mcctx->gvars->options.forceError) {
                CU_TRACE_PRINT(("Found at least one precise error and resuming GPU.\n"));
                mcctx->gvars->tools.trap->SetTrapAckAction(mcctx->cuctx,
                                                           CU_TOOLS_TRAP_ACK_CONTINUE);
            }
            else {
                CU_TRACE_PRINT(("Found precise errors without continue. "
                                "Resetting channel.\n"));
                mcctx->gvars->tools.trap->SetTrapAckAction(mcctx->cuctx,
                                                           CU_TOOLS_TRAP_ACK_RESET);
            }
        }
    }

    // If there was a hardware error, add it into the context
    if (err) {
        if (pc)
            mcfunc = mcContextGetFuncByAddr(mcctx, pc);

        res = addMemRecord(mcctx, err, mcfunc, ccbt);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to add imprecise error\n"));
            goto cleanup_and_return;
        }
    }

    // Nonblocking mode, and no precise errors were hit. Print the
    // hardware exception
    if (mcctx->ctxOpts.launchMode == MC_CONTEXT_OPTION_LAUNCH_NONBLOCKING) {
        res = flushRecords(mcctx, &mcctx->gvars->output);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to flush output.\n"));
            goto cleanup_and_return;
        }
    }

cleanup_and_return:
    dbgRes = mcctx->dev->haloClient->unmapMemory(mcctx->dev);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to  unmap memory\n"));
    }

    mcContextHaloCheckTrapStateFinalize(mcctx);

    if (err)
        free(err);
    err = NULL;

    if (ccbt)
        free(ccbt);
    ccbt = NULL;

    return res;
#endif
    return CUDA_SUCCESS;
}

CUresult
memcheckTrapHandlerEndCallback(MCcontext *mcctx, CUmemobj* scratchpadMemobj, uint32_t smError)
{
    CUwarpBitmask validWarps;
    uint32_t vsm;
    CUwarpBitmask unhandledWarps;
    uint32_t wp;

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid context in callback\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    CU_TRACE_PRINT(("In End callback : smError:%u\n", smError));

    for (vsm = 0; vsm < mcctx->dev->halo.deviceInfo.numSMs; ++vsm) {
        // only examine sm's with valid warps
        if (!warpBitmaskAny(&mcctx->dev->smState[vsm].state.tidValid))
            continue;

        warpBitmaskAssign(&validWarps, &mcctx->dev->smState[vsm].state.tidValid);
        warpBitmaskNot(&unhandledWarps, &mcctx->dev->smState[vsm].state.brokenwarps);
        warpBitmaskAnd(&unhandledWarps, &mcctx->dev->smState[vsm].state.bptrapmask, &unhandledWarps);

        if (warpBitmaskAny(&validWarps) && warpBitmaskAny(&unhandledWarps)) {
            CU_TRACE_PRINT(("Setting additional handled warps on vsm:%d "
                            "(validWarps :" CU_WARP_BIT_MASK_FMT_128_STR
                             " handled warps:" CU_WARP_BIT_MASK_FMT_128_STR ")\n",
                            vsm,
                            CU_WARP_BIT_MASK_FMT_128_VAL(&validWarps),
                            CU_WARP_BIT_MASK_FMT_128_VAL(&unhandledWarps)));
            for (wp = 0; wp < mcctx->dev->halo.deviceInfo.numWarpsPrSM;  ++wp) {
                if (warpBitmaskGetBits(&unhandledWarps, wp, 1))
                    mcctx->gvars->tools.trap->SetSMHandledSingleWarp(mcctx->cuctx, vsm, wp);
            }
        }
    }
    return CUDA_SUCCESS;
}

