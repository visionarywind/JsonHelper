/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef BARCHECK_STRUCTS_H
#define BARCHECK_STRUCTS_H

#include "volta_barcheck_lmem.h"

#define BARCHECK_MAX_BAR_PER_CTA 16
#define BARCHECK_MAX_WARPS_PER_CTA 32

typedef struct BCdevBarEntry_st BCdevBarEntry;
typedef struct BCdevCtaEntry_st BCdevCtaEntry;
typedef struct BCdevBarEntryVolta_st BCdevBarEntryVolta;
typedef struct BCdevCtaEntryVolta_st BCdevCtaEntryVolta;

typedef struct BCdevGlobalData_st BCdevGlobalData;

typedef enum {
    BARCHECK_CTA_FLAG_USE_GMEM_SCRATCH = 1 << 0,
} BCdevCtaFlags;

typedef enum {
    BARCHECK_BARRIER_FLAG_CRS_SNAPPED  = 1 << 0,
} BCdevBarFlags;

typedef enum {
    BARCHECK_SUCCESS = 0,
    BARCHECK_ERROR_CRS_MISMATCH                 = 1,
    BARCHECK_ERROR_INTRA_WARP_DIVERGENCE        = 2,
    BARCHECK_ERROR_INSUFFICIENT_LIVE_THREADS    = 3,
    BARCHECK_ERROR_UNKNOWN                      = 4,
    BARCHECK_ERROR_INVALID_ARGUMENTS            = 5,
    BARCHECK_ERROR_DEPRECATED_INSTRUCTION       = 6,
} BCresult;

typedef enum {
    BARCHECK_CHECK_NONE        = 0,
    BARCHECK_CHECK_INTRA_WARP  = 1 << 1,
    BARCHECK_CHECK_COMPARE_CRS = 1 << 2,
    BARCHECK_CHECK_EARLY_EXIT  = 1 << 3,
} BCcheckFlags;

typedef enum {
    BARCHECK_CTA_NONE                    = 0,
    BARCHECK_CTA_USES_COOPERATIVE_GROUPS = 1 << 0,
    BARCHECK_CTA_HAS_EARLY_EXIT          = 1 << 1,
} BCctaFlags;

typedef enum {
    BARCHECK_PER_BAR_NONE                = 0,
    BARCHECK_PER_BAR_CG_INSTR            = 1 << 0
} BCperBarFlags;

#pragma pack(push,4)
struct BCdevGlobalData_st {
    uint64_t ctaBitpoolHeader;
    uint64_t ctaDatapool;
    uint64_t ctaDataEntrySize;

    // Use on pre-Volta only
    uint64_t defaultLmemBase;
    uint32_t lmemSizePerSm;
    uint32_t lmemSizePerWarp;

    uint32_t numCtaPerSm;
    uint32_t crsMaxTokens;
};

struct BCdevBarEntry_st {
    uint64_t crsPtr;        /* Pointer to the CRS */
    uint32_t logicalWarpId; /* Logical warp that was snapped */
    uint32_t expectedThreadCount; /* Expected number of threads */
    uint32_t arrivedThreadCount;
    uint32_t flags;
};

struct BCdevCtaEntry_st {
    uint32_t totalThreadCount;
    uint32_t freeThreadCount;
    uint32_t slotIndex;
    uint32_t ctaFlags;
    BCdevBarEntry barriers[BARCHECK_MAX_BAR_PER_CTA];
    uint32_t activeMasks[BARCHECK_MAX_WARPS_PER_CTA];
};

struct BCdevBarEntryVolta_st {
    uint32_t logicalWarpId;         /* Logical warp that was snapped */
    uint32_t expectedThreadCount;   /* Expected number of threads */
    uint32_t arrivedThreadCount;
    uint32_t flags;
    uint64_t pc;
    uint32_t swCrsNumTokens;        /* Number of valid entries in swCrs */
    uint64_t swCrs[BARCHECK_VOLTA_LMEM_STACK_MAX]; /* SW CRS */
};

struct BCdevCtaEntryVolta_st {
    uint32_t totalThreadCount;
    uint32_t freeThreadCount;
    uint32_t slotIndex;
    uint32_t ctaFlags;
    uint32_t activeMasks[BARCHECK_MAX_WARPS_PER_CTA];
    BCdevBarEntryVolta barriers[BARCHECK_MAX_BAR_PER_CTA];
};

#pragma pack(pop)

#endif
