/*
 * Copyright 2007-2014 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "barcheck/barcheck.h"
#include "check_core.h"
#include "memcheck_types.h"
#include "memcheck_inst_types.h"
#include "memcheck_error.h"
#include "fermi_mcinterop.h"

#include "bikernels.h"
#include "tools_shared_list.h"

#include "check_tool_common.h"
#include "check_bitpool.h"
#include "check_mc_module.h"
#include "barcheck/barcheck_structs.h"

CCbarcheckCtxData*
barcheckGetContextData(MCcontext *mcctx)
{
    return (CCbarcheckCtxData*)mcctx->tm.ptr[MC_TOOL_MODE_BARCHECK];
}

CCbarcheckRecData*
barcheckGetRecData(MCrec *rec)
{
    return (CCbarcheckRecData*)rec->tm.ptr[MC_TOOL_MODE_BARCHECK];
}

static CUresult
barcheckGetInternalModules(MCrec *rec, tList **mods)
{
    CCbarcheckRecData *recData = NULL;

    if (!rec || !mods) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = barcheckGetRecData(rec);
    if (!recData)
        *mods = NULL;
    else
        *mods = recData->internalModules;

    return CUDA_SUCCESS;
}

static CUresult
barcheckGetExceptionType(uint32_t magic, CUDBGException_t *exception)
{
    if ((magic & FERMI_MEMCHECK_WHITEMAGIC_MASK) == FERMI_MEMCHECK_WHITEMAGIC) {
        *exception = CUDBG_EXCEPTION_LANE_ILLEGAL_ADDRESS;
    }

    return CUDA_SUCCESS;
}

static CUresult
updateGlobalData(MCcontext *mcctx, CCbarcheckCtxData *ctxData)
{
    CUresult res = CUDA_SUCCESS;
    CUtoolsStreamHandle stream;
    BCdevGlobalData *hostData = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !ctxData) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    hostData = (BCdevGlobalData*)ctxData->globalData.host.ptr;

    hostData->defaultLmemBase = ctxData->defaultLmemBase;
    hostData->lmemSizePerSm = ctxData->lmemSizePerSm;
    hostData->lmemSizePerWarp = ctxData->lmemSizePerWarp;

    hostData->numCtaPerSm = ctxData->numCtaPerSm;
    hostData->crsMaxTokens = ctxData->crsTokensPerWarp;

    /* Grab the barrier stream and use it to initialize and push down internal
       tracking structures */
    res = mcctx->gvars->tools.context->CtxGetBarrierStream(mcctx->cuctx, &stream);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to get barrier stream\n"));
        printInternalError(CU_MEMCHECK_ERROR_DYNAMIC_INIT_FAILED,
                           mcctx->gvars);
        return res;
    }

    /* Push it down to the device */
    res = CCmemShadowHtoDStream(&ctxData->globalData, &ctxData->globalData,
                                stream, CC_MEM_SHADOW_ACTION_MEMCPY);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to copy shadow to device\n"));
        return res;
    }

    return res;
}

static CUresult
createCtaTrackingBitpool(MCcontext *mcctx, CCbarcheckCtxData *ctxData)
{
    CUresult res = CUDA_SUCCESS;
    CUtoolsStreamHandle stream;

    CU_TRACE_FUNCTION();
    CU_ASSERT(mcctx);

    if (!mcctx || !ctxData) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* Grab the barrier stream and use it to initialize and push down internal
       tracking structures */
    res = mcctx->gvars->tools.context->CtxGetBarrierStream(mcctx->cuctx, &stream);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to get barrier stream\n"));
        return res;
    }

    res = CCbitpoolInitialize(&ctxData->ctaBitpool, mcctx, ctxData->numSlots, stream);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to initialize bitpool\n"));
        return res;
    }

    ctxData->ctaBitpoolData.size = ctxData->numSlots * ctxData->ctaDataEntrySize;
    ctxData->ctaBitpoolData.mcctx = mcctx;
    ctxData->ctaBitpoolData.devseg = HALO_MEM_SEG_GLOBAL;

    CU_TRACE_PRINT(("Trying to allocate cta data pool : %u bytes"
                    "Bytes per entry : %u "
                    "Num SMs:%u, CTA per SM:%u, Depth:%u\n",
                    ctxData->ctaBitpoolData.size,
                    ctxData->ctaDataEntrySize,
                    ctxData->numSm,
                    ctxData->numCtaPerSm,
                    ctxData->maxDepth));

    res = CCallocateDevice(&ctxData->ctaBitpoolData, NULL);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("\n"));
        return res;
    }

    res = CCallocateHost(&ctxData->ctaBitpoolData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT((" Failed to alloc host shadow\n"));
        return res;
    }


    /* Reset the host shadow */
    memset(ctxData->ctaBitpoolData.host.ptr, 0, (size_t)ctxData->ctaBitpoolData.size);

    /* Push it down to the device */
    res = CCmemShadowHtoDStream(&ctxData->ctaBitpoolData, &ctxData->ctaBitpoolData,
                                stream, CC_MEM_SHADOW_ACTION_MEMCPY);

    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to copy shadow to device\n"));
        return res;
    }

    res = CCbitpoolGetHeaderDevPtr(ctxData->ctaBitpool, &ctxData->ctaBitpoolHeaderPtr);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to get pointer to bit pool header\n"));
        return res;
    }

    return res;
}

static CUresult
createGlobalData(MCcontext *mcctx, CCbarcheckCtxData *ctxData )
{
    CUresult res = CUDA_SUCCESS;
    BCdevGlobalData *hostData = NULL;

    CU_TRACE_FUNCTION();
    CU_ASSERT(mcctx);

    if (!mcctx || !ctxData) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData->globalData.size = sizeof(BCdevGlobalData);
    ctxData->globalData.mcctx = mcctx;
    ctxData->globalData.devseg = HALO_MEM_SEG_GLOBAL;

    CU_TRACE_PRINT(("Trying to allocate GlobalData : %u bytes\n",
                    ctxData->globalData.size));

    res = CCallocateDevice(&ctxData->globalData, NULL);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("\n"));
        return res;
    }

    res = CCallocateHost(&ctxData->globalData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("\n"));
        return res;
    }

    /* Reset the host shadow */
    hostData = (BCdevGlobalData*)ctxData->globalData.host.ptr;
    memset(ctxData->globalData.host.ptr, 0, (size_t)ctxData->globalData.size);

    /* Fill in the host copy */
    hostData->ctaBitpoolHeader = ctxData->ctaBitpoolHeaderPtr;
    hostData->ctaDatapool = ctxData->ctaBitpoolData.dev.dPtr;
    hostData->ctaDataEntrySize = ctxData->ctaDataEntrySize;

    /* Update global data will do the memcpy down to the device */
    return updateGlobalData(mcctx, ctxData);
}

static CUresult
createDeviceTables(MCcontext *mcctx, CCbarcheckCtxData *ctxData)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!mcctx || !ctxData) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    res = createCtaTrackingBitpool(mcctx, ctxData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to create tracking table\n"));
        return res;
    }

    res = createGlobalData(mcctx, ctxData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to create error buffer\n"));
        return res;
    }

    return res;
}

static CUresult
loadFuncByName(MCcontext *mcctx, CCbarcheckCtxData *ctxData, const char *name, uint64_t *dstPtr)
{
    MCfunc *func = NULL;

    func = mcModuleGetFuncByName(ctxData->mod, name);
    if (!func) {
        CU_ERROR_PRINT(("Could not get %s common function\n", name));
        return CUDA_ERROR_UNKNOWN;
    }

    *dstPtr = func->mem.dev.dPtr;
    return CUDA_SUCCESS;
}

static CUresult
loadBarcheckCtxModules(MCcontext *mcctx, CCbarcheckCtxData *ctxData)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!mcctx || !ctxData) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* In the case of barcheck, we want to load up the barcheck module
       which contains all the per context stuff. This module is in CUDA-C
       and has no SASS level relocs to be applied
     */
    res = loadModuleFromCubinCommon(&ctxData->mod, mcctx, allCubins_memcheck, NULL, 0, false, false);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load module. \n"));
        return res;
    }

    res = loadFuncByName(mcctx, ctxData, "MCBCperBar", &ctxData->commonPerBar);
    if (res != CUDA_SUCCESS) {
        return res;
    }

    res = loadFuncByName(mcctx, ctxData, "MCBCOnCtaEntry", &ctxData->commonCtaEntry);
    if (res != CUDA_SUCCESS) {
        return res;
    }

    res = loadFuncByName(mcctx, ctxData, "MCBCOnThreadExit", &ctxData->commonPerThreadExit);
    if (res != CUDA_SUCCESS) {
        return res;
    }

    if (getArchFromSmVer(mcctx->sm_version) < MC_TOOL_MODE_ARCH_SM70) {
        res = loadFuncByName(mcctx, ctxData, "MCBCOnCtaExit", &ctxData->commonCtaExit);
        if (res != CUDA_SUCCESS) {
            return res;
        }

        res = loadFuncByName(mcctx, ctxData, "MCBCOnThreadRet", &ctxData->commonPerThreadRet);
        if (res != CUDA_SUCCESS) {
            return res;
        }
    }

    return CUDA_SUCCESS;
}

CUresult
barcheckLoadEntryExit(MCrec *rec, MCfunc **stubFunc)
{
    CCbarcheckRecData *recData = NULL;
    CCbarcheckCtxData *ctxData = NULL;
    CCsymbol sym[4] = {{0}};
    CUresult res = CUDA_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;
    MCfunc *func = NULL;

    CU_TRACE_FUNCTION();

    /* In here to load an entry exit module */
    if (!rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = barcheckGetRecData(rec);
    if (!recData) {
        CU_ERROR_PRINT(("Invalid RC data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = barcheckGetContextData(rec->context);
    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid context data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // device address of global checker state
    sym[0].name = "BC_PROLOGUE_GLOBAL_DATA_ADDR";
    sym[0].val = ctxData->globalData.dev.dPtr;

    // device address of user code
    sym[1].name = "BC_PROLOGUE_USER_CODE";
    sym[1].val = rec->func->mem.dev.dPtr;

    // device address of common CTA entry patch function
    sym[2].name = "MCBCOnCtaEntry";
    sym[2].val = ctxData->commonCtaEntry;

    // Volta+ doesn't return to entry_exit patch stub from user code
    if (getArchFromSmVer(rec->context->sm_version) < MC_TOOL_MODE_ARCH_SM70) {
        // device address of common CTA exit patch function
        sym[3].name = "MCBCOnCtaExit";
        sym[3].val = ctxData->commonCtaExit;
    }

    res = loadModuleFromCubin(&recData->entryExitMod, rec->context,
                              allCubins_barcheck_entry_exit,
                              sym, sizeof(sym)/sizeof(sym[0]));
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load cubins\n"));
        return res;
    }

    tres = toolsListAppend(recData->internalModules, recData->entryExitMod);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to append module to list. (tres=%u)\n", tres));
        return CUDA_ERROR_UNKNOWN;
    }

    func = mcModuleGetFuncByName(recData->entryExitMod, "barcheckEntryExitPatch");
    if (!func) {
        CU_ERROR_PRINT(("Could not get stub function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (stubFunc) {
        *stubFunc = func;
    }

    /* Set the prologue entry address */
    rec->patchEntry = func->mem.dev.dPtr;

    return CUDA_SUCCESS;
}

CUresult
barcheckLoadBarrierStub(MCrec *rec, uint64_t *inst, uint64_t patchPC, bool isCGInstr, MCfunc **stubFunc)
{
    CCbarcheckRecData *recData = NULL;
    CCbarcheckCtxData *ctxData = NULL;
    CCsymbol sym[16] = {{0}};
    CUresult res = CUDA_SUCCESS;
    MCmod *mod = NULL;
    MCfunc *func = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;
    uint32_t barNameReg, barNameImm;
    uint32_t barCountReg, barCountImm;
    uint32_t pred;
    uint32_t instSourceType;
    uint32_t deviceArch;

    CU_TRACE_FUNCTION();

    /* In here to load an entry exit module */
    if (!rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = barcheckGetRecData(rec);
    if (!recData) {
        CU_ERROR_PRINT(("Invalid RC data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = barcheckGetContextData(rec->context);
    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid context data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    deviceArch = getArchFromSmVer(rec->context->sm_version);

    instSourceType = rec->context->hal.getInstSourceType(inst);

    barNameReg = rec->context->hal.barGetNameReg(inst);
    barNameImm = rec->context->hal.barGetNameImm(inst);

    barCountReg = rec->context->hal.barGetCountReg(inst);
    barCountImm = rec->context->hal.barGetCountImm(inst);

    pred = rec->context->hal.getPredWithInv(inst);

    // mov barrier idx from barNameReg to R6 (full instr reloc)
    sym[0].name = "BC_STUB_BAR_BARIDX_REG";
    rec->context->hal.genMov(6, barNameReg, (uint64_t*)&(sym[0].val));
    setSymbolSize(rec->context, &sym[0]);

    // barrier idx immediate
    sym[1].name = "BC_STUB_BAR_BARIDX_IMM";
    sym[1].val = barNameImm;

    // mov barrier count from barCountReg to R7 (full instr reloc)
    sym[2].name = "BC_STUB_BAR_BARCNT_REG";
    rec->context->hal.genMov(7, barCountReg, (uint64_t*)&(sym[2].val));
    setSymbolSize(rec->context, &sym[2]);

    // barrier count immediate
    sym[3].name = "BC_STUB_BAR_BARCNT_IMM";
    sym[3].val = barCountImm;

    if (deviceArch < MC_TOOL_MODE_ARCH_SM70) {
        /* Extract the predicate */
        sym[4].name = "BC_STUB_BAR_BFE_VAL";
        /* This should probably be halified if the BFE instruction changes !! */
        sym[4].val = 0x0100 | (pred & 0x7);

        // inverse of barrier predicate
        sym[5].name = "BC_STUB_BAR_PRED_INV";
        sym[5].val = (pred <= 7) ? 0 : 1;

        // stub start PC
        sym[6].name = "BC_STUB_BAR_STUB_BASE_PC";
        sym[6].type = CC_SYMBOL_TYPE_SELF_PC;
    }

    // device adress of global checker state
    sym[7].name = "BC_STUB_BAR_GLOBAL_DATA_ADDR";
    sym[7].val = ctxData->globalData.dev.dPtr;

    // the patched PC (32/64bit), depending on arch
    sym[8].name = "BC_STUB_BAR_PC";
    sym[8].val = patchPC;

    // original instruction (full inst reloc)
    sym[9].name = "BC_STUB_BAR_ORIG_BAR";
    res = assignInstSymbol(rec->context, &sym[9], inst);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to assign inst symbol\n"));
        return res;
    }

    // device address of common per-barrier function
    sym[10].name = "MCBCperBar";
    sym[10].val = ctxData->commonPerBar;

    // default error value
    sym[11].name = "BC_STUB_BAR_WARP_ERROR";
    sym[11].val = BARCHECK_ERROR_CRS_MISMATCH;

    if (deviceArch >= MC_TOOL_MODE_ARCH_SM70) {
        sym[12].name     = "BC_STUB_BAR_BYPASS_BRANCH";
        sym[12].type     = CC_SYMBOL_TYPE_MASKED;
        sym[12].val      = rec->context->hal.getPredRawInv(inst);
        sym[12].mask     = rec->context->hal.getPredMask(inst);
        sym[12].size     = CC_SYMBOL_SIZE_128;
        sym[12].masks[1] = 0;

        sym[13].name = "BC_STUB_BAR_RET_PC";
        sym[13].val  = patchPC + rec->context->hal.getInstSize();
    }

    sym[14].name = "BC_STUB_BAR_IS_REG_REG";
    sym[14].val = (instSourceType == MC_INST_SOURCE_TYPE_REGISTER);

    if (deviceArch >= MC_TOOL_MODE_ARCH_SM70) {
        sym[15].name = "BC_STUB_BAR_FLAGS";
        sym[15].val = 0;
        if (isCGInstr)
            sym[15].val |= BARCHECK_PER_BAR_CG_INSTR;
    }

    res = loadModuleFromCubin(&mod, rec->context, allCubins_barcheck_stub_bar,
                              sym, sizeof(sym)/sizeof(sym[0]));
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load cubins\n"));
        return res;
    }

    func = mcModuleGetFuncByName(mod, "barcheckStubBarPatch");
    if (!func) {
        CU_ERROR_PRINT(("Could not get stub function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    tres = toolsListAppend(recData->internalModules, mod);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to append module to list. (tres=%u)\n", tres));
        return CUDA_ERROR_UNKNOWN;
    }

    if (stubFunc) {
        CU_DEBUG_PRINT(("Returning barrier stub entry at : 0x%" PRIx64 "\n",
                        func->mem.dev.dPtr));
        *stubFunc = func;
    }

    return CUDA_SUCCESS;
}

CUresult
barcheckLoadExitStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, MCfunc **stubFunc)
{
    CCbarcheckRecData *recData = NULL;
    CCbarcheckCtxData *ctxData = NULL;
    CCsymbol sym[9] = {{0}};
    CUresult res = CUDA_SUCCESS;
    MCmod *mod = NULL;
    MCfunc *func = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;
    uint32_t pred = 0;
    uint32_t ccTest = 0;
    bool voltaPlus = false;

    CU_TRACE_FUNCTION();

    /* In here to load an entry exit module */
    if (!rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = barcheckGetRecData(rec);
    if (!recData) {
        CU_ERROR_PRINT(("Invalid RC data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = barcheckGetContextData(rec->context);
    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid context data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    voltaPlus = getArchFromSmVer(rec->context->sm_version) >= MC_TOOL_MODE_ARCH_SM70;

    if (!voltaPlus) {
        /* Get predicate register and CC.test encoding of original instruction */
        pred = rec->context->hal.getPredWithInv(inst);
        ccTest = rec->context->hal.getCcTest(inst);

        /* Extract the predicate */
        sym[0].name = "BC_STUB_EXIT_BFE_VAL";
        /* This should probably be halified if the BFE instruction changes !! */
        sym[0].val = 0x0100 | (pred & 0x7);

        sym[1].name = "BC_STUB_EXIT_PRED_INV";
        sym[1].val = (pred <= 7) ? 0 : 1;

        /* Create a CSETP with the CC.test encoding of the original instruction */
        sym[2].name = "BC_STUB_EXIT_CSETP";
        rec->context->hal.genCsetp(ccTest, 1, (uint64_t*)&(sym[2].val));
    }

    // device address of common thread exit function
    sym[3].name = "MCBCOnThreadExit";
    sym[3].val = ctxData->commonPerThreadExit;

    /* Create a copy of the original EXIT instruction */
    sym[4].name = "BC_STUB_EXIT_EXIT";
    res = assignInstSymbol(rec->context, &sym[4], inst);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to assign inst symbol\n"));
        return res;
    }

    if (voltaPlus) {
        sym[5].name     = "BC_STUB_EXIT_BYPASS_BRANCH";
        sym[5].type     = CC_SYMBOL_TYPE_MASKED;
        sym[5].val      = rec->context->hal.getPredRawInv(inst);
        sym[5].mask     = rec->context->hal.getPredMask(inst);
        sym[5].size     = CC_SYMBOL_SIZE_128;
        sym[5].masks[1] = 0;

        sym[6].name     = "BC_STUB_EXIT_INPUT_BYPASS_BRANCH";
        sym[6].type     = CC_SYMBOL_TYPE_MASKED;
        sym[6].val      = rec->context->hal.getInputPredRawInv(inst);
        sym[6].masks[1] = rec->context->hal.getInputPredMask(inst);
        sym[6].size     = CC_SYMBOL_SIZE_128;
        sym[6].masks[0] = 0;

        sym[7].name = "BC_STUB_EXIT_PC";
        sym[7].val  = returnTarget;
    }

    // device adress of global checker state
    sym[8].name = "BC_STUB_EXIT_GLOBAL_DATA_ADDR";
    sym[8].val = ctxData->globalData.dev.dPtr;

    res = loadModuleFromCubin(&mod, rec->context, allCubins_barcheck_stub_exit,
                              sym, sizeof(sym)/sizeof(sym[0]));
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load cubins\n"));
        return res;
    }

    func = mcModuleGetFuncByName(mod, "barcheckStubExitPatch");
    if (!func) {
        CU_ERROR_PRINT(("Could not get stub function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    tres = toolsListAppend(recData->internalModules, mod);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to append module to list. (tres=%u)\n", tres));
        return CUDA_ERROR_UNKNOWN;
    }

    if (stubFunc) {
        CU_DEBUG_PRINT(("Returning exit stub entry at : 0x%" PRIx64 "\n",
                        func->mem.dev.dPtr));
        *stubFunc = func;
    }

    return CUDA_SUCCESS;
}

static CUresult
loadRetStubKepler(MCrec *rec, uint64_t *inst, uint64_t returnTarget, MCfunc **stubFunc)
{
    CCbarcheckRecData *recData = NULL;
    CCbarcheckCtxData *ctxData = NULL;
    CCsymbol sym[8] = {{0}};
    CUresult res = CUDA_SUCCESS;
    MCmod *mod = NULL;
    MCfunc *func = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;
    uint32_t pred = 0;
    uint32_t ccTest = 0;

    CU_TRACE_FUNCTION();

    recData = barcheckGetRecData(rec);
    if (!recData) {
        CU_ERROR_PRINT(("Invalid BC data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = barcheckGetContextData(rec->context);
    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid context data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* Get predicate register and CC.test encoding of original instruction */
    pred = rec->context->hal.getPredWithInv(inst);
    ccTest = rec->context->hal.getCcTest(inst);

    /* Extract the predicate */
    sym[0].name = "BC_STUB_RET_BFE_VAL";
    /* This should probably be halified if the BFE instruction changes !! */
    sym[0].val = 0x0100 | (pred & 0x7);

    // inverse of instruction predicate
    sym[1].name = "BC_STUB_RET_PRED_INV";
    sym[1].val = (pred <= 7) ? 0 : 1;

    /* Create a CSETP with the CC.test encoding of the original instruction */
    sym[2].name = "BC_STUB_RET_CSETP";
    rec->context->hal.genCsetp(ccTest, 1, (uint64_t*)&(sym[2].val));

    // device addrsss of common thread ret function
    sym[3].name = "MCBCOnThreadRet";
    sym[3].val = ctxData->commonPerThreadRet;

    /* Create a copy of the original RET instruction */
    sym[4].name = "BC_STUB_RET_RET";
    res = assignInstSymbol(rec->context, &sym[4], inst);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to assign inst symbol\n"));
        return res;
    }

    // device address of global checker state
    sym[5].name = "BC_STUB_RET_GLOBAL_DATA_ADDR";
    sym[5].val = ctxData->globalData.dev.dPtr;

    // start PC of patch stub
    sym[6].name = "BC_STUB_RET_STUB_BASE_PC";
    sym[6].type = CC_SYMBOL_TYPE_SELF_PC;

    // return address in user code after patch completion
    sym[7].name = "BC_STUB_RET_PC";
    sym[7].val = returnTarget;

    res = loadModuleFromCubin(&mod, rec->context, allCubins_barcheck_stub_ret,
                              sym, sizeof(sym)/sizeof(sym[0]));
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load cubins\n"));
        return res;
    }

    func = mcModuleGetFuncByName(mod, "barcheckStubRetPatch");
    if (!func) {
        CU_ERROR_PRINT(("Could not get stub function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    tres = toolsListAppend(recData->internalModules, mod);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to append module to list. (tres=%u)\n", tres));
        return CUDA_ERROR_UNKNOWN;
    }

    if (stubFunc) {
        CU_DEBUG_PRINT(("Returning ret stub entry at : 0x%" PRIx64 "\n",
                        func->mem.dev.dPtr));
        *stubFunc = func;
    }

    return CUDA_SUCCESS;
}

static CUresult
loadRetStubVolta(MCrec *rec, uint64_t *inst, uint64_t returnTarget, MCfunc **stubFunc)
{
    CCbarcheckRecData *recData = NULL;
    CCbarcheckCtxData *ctxData = NULL;
    CCsymbol sym[3] = {{0}};
    CUresult res = CUDA_SUCCESS;
    MCmod *mod = NULL;
    MCfunc *func = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;
    bool isAbsRet = false;

    CU_TRACE_FUNCTION();

    recData = barcheckGetRecData(rec);
    if (!recData) {
        CU_ERROR_PRINT(("Invalid BC data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = barcheckGetContextData(rec->context);
    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid context data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // detect if RET is absolute or relative
    isAbsRet = rec->context->hal.getRetIsAbs(inst);

    // branch to bypass label if orig pred is false
    //  TODO: update this to set a 128bit mask.
    //  this only works on Volta because Pg happens
    //  to be in lo word which is also inst[0]
    sym[0].name     = "BC_STUB_RET_BYPASS_BRANCH";
    sym[0].type     = CC_SYMBOL_TYPE_MASKED;
    sym[0].val      = rec->context->hal.getPredRawInv(inst);
    sym[0].mask     = rec->context->hal.getPredMask(inst);
    sym[0].size     = CC_SYMBOL_SIZE_128;
    sym[0].masks[1] = 0;

    sym[1].name = "BC_STUB_RET_ORIG_RET";
    if (isAbsRet) {
        // Replace with original instruction (absolute return)
        res = assignInstSymbol(rec->context, &sym[1], inst);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to assign inst symbol\n"));
            return res;
        }
    } else {
        // Replace relative return with absolute return, compute original 'relative' address
        uint32_t ra_lo = 0;
        uint64_t immOffset = 0;
        int64_t retTargetAddr = returnTarget;
        bool immSigned = false;
        bool retDepth = rec->context->hal.getControlFlowDepth(inst);

        immOffset += rec->context->hal.getControlFlowImm(inst, &immSigned);
        retTargetAddr += immSigned ? (int64_t)immOffset : immOffset;

        ra_lo = rec->context->hal.getRa(inst);
        rec->context->hal.genRet(retTargetAddr, retDepth, ra_lo, (uint64_t*)&(sym[1].val));
        setSymbolSize(rec->context, &sym[1]);
    }

    // return address in user code after patch completion
    sym[2].name = "BC_STUB_RET_PC";
    sym[2].val  = returnTarget;

    res = loadModuleFromCubin(&mod, rec->context, allCubins_barcheck_stub_ret,
                              sym, sizeof(sym)/sizeof(sym[0]));
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load cubins\n"));
        return res;
    }

    func = mcModuleGetFuncByName(mod, "barcheckStubRetPatch");
    if (!func) {
        CU_ERROR_PRINT(("Could not get stub function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    tres = toolsListAppend(recData->internalModules, mod);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to append module to list. (tres=%u)\n", tres));
        return CUDA_ERROR_UNKNOWN;
    }

    if (stubFunc) {
        CU_DEBUG_PRINT(("Returning ret stub entry at : 0x%" PRIx64 "\n",
                        func->mem.dev.dPtr));
        *stubFunc = func;
    }

    return CUDA_SUCCESS;
}

CUresult
barcheckLoadRetStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, MCfunc **stubFunc)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (getArchFromSmVer(rec->context->sm_version) >= MC_TOOL_MODE_ARCH_SM70) {
        res = loadRetStubVolta(rec, inst, returnTarget, stubFunc);
    } else {
        res = loadRetStubKepler(rec, inst, returnTarget, stubFunc);
    }

    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load ret stub\n"));
        return res;
    }

    return CUDA_SUCCESS;
}

CUresult
barcheckLoadCallStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, bool isCGInstr, MCfunc **stubFunc)
{
    CCbarcheckRecData *recData = NULL;
    CCbarcheckCtxData *ctxData = NULL;
    CCsymbol sym[4] = {{0}};
    CUresult res = CUDA_SUCCESS;
    MCmod *mod = NULL;
    MCfunc *func = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;
    uint32_t instSourceType;
    uint32_t ra_lo = rec->context->hal.getRz();

    CU_TRACE_FUNCTION();

    /* In here to load an entry exit module */
    if (!rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = barcheckGetRecData(rec);
    if (!recData) {
        CU_ERROR_PRINT(("Invalid BC data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = barcheckGetContextData(rec->context);
    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid context data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (getArchFromSmVer(rec->context->sm_version) < MC_TOOL_MODE_ARCH_SM70) {
        return CUDA_ERROR_NOT_SUPPORTED;
    }

    instSourceType = rec->context->hal.getInstSourceType(inst);

    // branch to bypass label if orig pred is false
    //  TODO: update this to set a 128bit mask.
    //  this only works on Volta because Pg happens
    //  to be in lo word which is also inst[0]
    sym[0].name     = "BC_STUB_CALL_BYPASS_BRANCH";
    sym[0].type     = CC_SYMBOL_TYPE_MASKED;
    sym[0].val      = rec->context->hal.getPredRawInv(inst);
    sym[0].masks[0] = rec->context->hal.getPredMask(inst);
    sym[0].size     = CC_SYMBOL_SIZE_128;
    sym[0].masks[1] = 0;

    sym[1].name = "BC_STUB_CALL_ORIG_JCAL";

    if (rec->context->hal.isRelativeCall(inst)) {
        // Replace relative call with absolute call, compute 'relative' call target address
        uint64_t immOffset = 0;
        int64_t absoluteTargetAddr = returnTarget;
        bool immSigned = false;
        bool calDepth = rec->context->hal.getControlFlowDepth(inst);

        if (instSourceType & MC_INST_SOURCE_TYPE_REGISTER)
            ra_lo = rec->context->hal.getRa(inst);

        immOffset += rec->context->hal.getControlFlowImm(inst, &immSigned);
        absoluteTargetAddr += immSigned ? (int64_t)immOffset : immOffset;

        rec->context->hal.genAbsoluteCall(absoluteTargetAddr, calDepth, ra_lo, (uint64_t*)&(sym[1].val));
        setSymbolSize(rec->context, &sym[1]);
    } else {
        // Replace with original instruction (absolute call)
        res = assignInstSymbol(rec->context, &sym[1], inst);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to assign inst symbol\n"));
            return res;
        }
    }

    // return address in user code after patch completion
    sym[2].name = "BC_STUB_CALL_RET_PC";
    sym[2].val = returnTarget;

    sym[3].name = "BC_STUB_CALL_CG_CALL";
    sym[3].val = isCGInstr ? 1 : 0;

#if NVCFG(GLOBAL_ARCH_VOLTA)
    res = loadModuleFromCubin(&mod, rec->context, allCubins_barcheck_stub_call,
                              sym, sizeof(sym)/sizeof(sym[0]));
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load cubins\n"));
        return res;
    }
#endif

    func = mcModuleGetFuncByName(mod, "barcheckStubCallPatch");
    if (!func) {
        CU_ERROR_PRINT(("Could not get stub function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    tres = toolsListAppend(recData->internalModules, mod);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to append module to list. (tres=%u)\n", tres));
        return CUDA_ERROR_UNKNOWN;
    }

    if (stubFunc) {
        CU_DEBUG_PRINT(("Returning call stub entry at : 0x%" PRIx64 "\n",
                        func->mem.dev.dPtr));
        *stubFunc = func;
    }

    return CUDA_SUCCESS;
}

CUresult
barcheckLoadWarpsyncStub(MCrec *rec, uint64_t *inst, uint64_t patchPC, MCfunc **stubFunc)
{
    CCbarcheckRecData *recData = NULL;
    CCbarcheckCtxData *ctxData = NULL;
    CCsymbol sym[7] = {{0}};
    CUresult res = CUDA_SUCCESS;
    MCmod *mod = NULL;
    MCfunc *func = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;
    uint32_t instSourceType;
    uint32_t rb;

    CU_TRACE_FUNCTION();

    if (!rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = barcheckGetRecData(rec);
    if (!recData) {
        CU_ERROR_PRINT(("Invalid BC data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = barcheckGetContextData(rec->context);
    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid context data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (getArchFromSmVer(rec->context->sm_version) < MC_TOOL_MODE_ARCH_SM70) {
        return CUDA_ERROR_NOT_SUPPORTED;
    }

    instSourceType = rec->context->hal.getInstSourceType(inst);
    rb = rec->context->hal.getRz();

    if (instSourceType & MC_INST_SOURCE_TYPE_REGISTER)
        rb = rec->context->hal.getRb(inst);

    // branch to bypass label if orig pred is false
    //  TODO: update this to set a 128bit mask.
    //  this only works on Volta because Pg happens
    //  to be in lo word which is also inst[0]
    sym[0].name     = "BC_STUB_WARPSYNC_BYPASS_BRANCH";
    sym[0].type     = CC_SYMBOL_TYPE_MASKED;
    sym[0].val      = rec->context->hal.getPredRawInv(inst);
    sym[0].masks[0] = rec->context->hal.getPredMask(inst);
    sym[0].size     = CC_SYMBOL_SIZE_128;
    sym[0].masks[1] = 0;

    // Replace with original instruction
    sym[1].name = "BC_STUB_WARPSYNC_ORIG_INST";
    res = assignInstSymbol(rec->context, &sym[1], inst);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to assign inst symbol\n"));
        return res;
    }

    // return address in user code after patch completion
    sym[2].name = "BC_STUB_WARPSYNC_JUMP_RETURN";
    sym[2].val = patchPC + rec->context->hal.getInstSize();

    // patch pc
    sym[3].name = "BC_STUB_WARPSYNC_PC";
    sym[3].val = patchPC;

    sym[4].name = "BC_STUB_WARPSYNC_REG";
    rec->context->hal.genLmemHiSpill(BARCHECK_LMEM_RB, sizeof(uint32_t), rb, (uint64_t*)&(sym[4].val));
    setSymbolSize(rec->context, &sym[4]);

    sym[5].name = "BC_STUB_WARPSYNC_LOAD_MASK";
    if (instSourceType & MC_INST_SOURCE_TYPE_REGISTER) {
        // LDL R4, [`(LMEM_HI_MEMCHECK_SCRATCH + BARCHECK_LMEM_RB)];
        rec->context->hal.genLmemHiRead(BARCHECK_LMEM_RB, sizeof(uint32_t), 4, (uint64_t*)&(sym[5].val));
    }
    else if (instSourceType & MC_INST_SOURCE_TYPE_IMMEDIATE) {
        uint32_t imm = rec->context->hal.getOffset(inst);

        // MOV32I R4, ImmU32;
        rec->context->hal.genMovFromImm(4, imm, (uint64_t*)&(sym[5].val));
    }
    else if (instSourceType & MC_INST_SOURCE_TYPE_CBANK) {
        uint32_t cBank = 0, cOffset = 0;

        // Returns the full cbank bits as well, but not needed here
        (void)rec->context->hal.getCBank(inst, &cBank, &cOffset);

        // MOV R4, c[bnk][offs];
        rec->context->hal.genMovCBank(4, cBank, cOffset, (uint64_t*)&(sym[5].val));
    }
    else if (instSourceType & MC_INST_SOURCE_TYPE_UNIFORM_REGISTER) {
        uint32_t urb = rec->context->hal.getURb(inst);

        // MOV R4, Urb;
        rec->context->hal.genMovFromUR(4, urb, (uint64_t*)&(sym[5].val));
    }
    else if (instSourceType & MC_INST_SOURCE_TYPE_CBANK_UNIFORM_REGISTER) {
        uint32_t urb = rec->context->hal.getURb(inst);
        uint32_t offset = rec->context->hal.getOffset(inst);

        // MOV R4, cx[URb][immU16];
        rec->context->hal.genMovCBankUR(4, urb, offset, (uint64_t*)&(sym[5].val));
    }
    setSymbolSize(rec->context, &sym[5]);

    sym[6].name = "BC_STUB_WARPSYNC_FROM_REGISTER";
    sym[6].val = (instSourceType & MC_INST_SOURCE_TYPE_REGISTER);

#if NVCFG(GLOBAL_ARCH_VOLTA)
    res = loadModuleFromCubin(&mod, rec->context, allCubins_barcheck_stub_warpsync,
                              sym, sizeof(sym)/sizeof(sym[0]));
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load cubins\n"));
        return res;
    }
#endif

    func = mcModuleGetFuncByName(mod, "barcheckStubWarpsyncPatch");
    if (!func) {
        CU_ERROR_PRINT(("Could not get stub function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    tres = toolsListAppend(recData->internalModules, mod);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to append module to list. (tres=%u)\n", tres));
        return CUDA_ERROR_UNKNOWN;
    }

    if (stubFunc) {
        CU_DEBUG_PRINT(("Returning warpsync stub entry at : 0x%" PRIx64 "\n",
                        func->mem.dev.dPtr));
        *stubFunc = func;
    }

    return CUDA_SUCCESS;
}

CUresult
barcheckLoadShflStub(MCrec *rec, uint64_t *inst, uint64_t patchPC, MCfunc **stubFunc)
{
    CCbarcheckRecData *recData = NULL;
    CCbarcheckCtxData *ctxData = NULL;
    CCsymbol sym[5] = {{0}};
    CUresult res = CUDA_SUCCESS;
    MCmod *mod = NULL;
    MCfunc *func = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = barcheckGetRecData(rec);
    if (!recData) {
        CU_ERROR_PRINT(("Invalid BC data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = barcheckGetContextData(rec->context);
    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid context data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (getArchFromSmVer(rec->context->sm_version) < MC_TOOL_MODE_ARCH_SM70) {
        return CUDA_ERROR_NOT_SUPPORTED;
    }

    // branch to bypass label if orig pred is false
    //  TODO: update this to set a 128bit mask.
    //  this only works on Volta because Pg happens
    //  to be in lo word which is also inst[0]
    sym[0].name     = "BC_STUB_SHFL_BYPASS_BRANCH";
    sym[0].type     = CC_SYMBOL_TYPE_MASKED;
    sym[0].val      = rec->context->hal.getPredRawInv(inst);
    sym[0].masks[0] = rec->context->hal.getPredMask(inst);
    sym[0].size     = CC_SYMBOL_SIZE_128;
    sym[0].masks[1] = 0;

    // Replace with original instruction
    sym[1].name = "BC_STUB_SHFL_ORIG_INST";
    res = assignInstSymbol(rec->context, &sym[1], inst);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to assign inst symbol\n"));
        return res;
    }

    // return address in user code after patch completion
    sym[2].name = "BC_STUB_SHFL_JUMP_RETURN";
    sym[2].val = patchPC + rec->context->hal.getInstSize();

    // patch pc
    sym[3].name = "BC_STUB_SHFL_PC";
    sym[3].val = patchPC;

    // flag if we should check for deprecated instructions
    sym[4].name = "BC_STUB_SHFL_CHECK_DEPRECATED";
    sym[4].val = rec->context->gvars->options.checkDeprecatedInstr ? 1 : 0;

#if NVCFG(GLOBAL_ARCH_VOLTA)
    res = loadModuleFromCubin(&mod, rec->context, allCubins_barcheck_stub_shfl,
                              sym, sizeof(sym)/sizeof(sym[0]));
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load cubins\n"));
        return res;
    }
#endif

    func = mcModuleGetFuncByName(mod, "barcheckStubShflPatch");
    if (!func) {
        CU_ERROR_PRINT(("Could not get stub function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    tres = toolsListAppend(recData->internalModules, mod);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to append module to list. (tres=%u)\n", tres));
        return CUDA_ERROR_UNKNOWN;
    }

    if (stubFunc) {
        CU_DEBUG_PRINT(("Returning shfl stub entry at : 0x%" PRIx64 "\n",
                        func->mem.dev.dPtr));
        *stubFunc = func;
    }

    return CUDA_SUCCESS;
}

static CUresult
barcheckCreatePatchHelpers(MCcontext *mcctx, MCrec *rec,
                            CUtoolsStreamHandle stream)
{
    CUresult status = CUDA_SUCCESS;
    CCbarcheckRecData *recData = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !rec || !stream) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = (CCbarcheckRecData*)calloc(1, sizeof(*recData));
    if (!recData) {
        CU_ERROR_PRINT(("Failed to allocate rec data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData->internalModules = toolsListNew();
    if (!recData->internalModules) {
        CU_ERROR_PRINT(("Failed to create module list\n"));
        free(recData);
        return CUDA_ERROR_UNKNOWN;
    }

    rec->tm.ptr[MC_TOOL_MODE_BARCHECK] = (void*)recData;

    return status;
}

static CUresult
destroyGlobalData(CCbarcheckCtxData *ctxData, CCmemCleanup *cleanup)
{
    CU_TRACE_FUNCTION();

    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    CCfreeDevice(&ctxData->globalData, cleanup);
    CCfreeHost(&ctxData->globalData);
    return CUDA_SUCCESS;
}

static CUresult
destroyCtaTrackingBitpool(CCbarcheckCtxData *ctxData, CCmemCleanup *cleanup)
{
    CU_TRACE_FUNCTION();

    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    CCbitpoolFinalize(&ctxData->ctaBitpool, cleanup);
    CCfreeDevice(&ctxData->ctaBitpoolData, cleanup);
    CCfreeHost(&ctxData->ctaBitpoolData);
    return CUDA_SUCCESS;
}

static CUresult
destroyDeviceTables(CCbarcheckCtxData *ctxData, CCmemCleanup *cleanup)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    res = destroyCtaTrackingBitpool(ctxData, cleanup);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to destroy tracking tables\n"));
        return res;
    }

    res = destroyGlobalData(ctxData, cleanup);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to destroy indirection table\n"));
        return res;
    }

    return CUDA_SUCCESS;
}

static CUresult
barcheckDestroyPatchHelpers(MCcontext *mcctx, MCrec *rec, CCmemCleanup *cleanup)
{
    CUresult status = CUDA_SUCCESS;
    CCbarcheckRecData **pRcData = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !rec) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    pRcData = (CCbarcheckRecData**)&rec->tm.ptr[MC_TOOL_MODE_BARCHECK];
    if (*pRcData) {
        toolsListDelete((*pRcData)->internalModules, NULL, NULL);
        (*pRcData)->internalModules = NULL;

        free(*pRcData);
        *pRcData = NULL;
    }
    return status;
}


static bool
barcheckHasPrologue(MCcontext *mcctx)
{
    return true;
}

static bool
barcheckUsesTrapHandler(MCoptions *options)
{
    return true;
}

static bool
barcheckEnableMemAccessCheck (MCoptions *options)
{
    return false;
}

static CUresult
barcheckModuleLoaded(MCcontext *mcctx, MCmod *mod)
{
    return CUDA_SUCCESS;
}

static CUresult
barcheckModuleUnloaded(MCcontext *mcctx, MCmod *mod)
{
    return CUDA_SUCCESS;
}

static CUresult
barcheckContextDestroyStart(MCcontext *mcctx)
{
    CCbarcheckCtxData *ctxData = NULL;

    if (!mcctx) {
        CU_DEBUG_PRINT(("No context\n"));
        return CUDA_SUCCESS;
    }

    ctxData = barcheckGetContextData(mcctx);

    if (!ctxData) {
        CU_DEBUG_PRINT(("RC data already freed\n"));
        return CUDA_SUCCESS;
    }

    /* Free the allocations */
    destroyDeviceTables(ctxData, NULL);

    /* Free the structure */
    free(ctxData);

    /* Reset the pointer */
    mcctx->tm.ptr[MC_TOOL_MODE_BARCHECK] = NULL;

    return CUDA_SUCCESS;
}

static CUresult
barcheckContextDestroyEnd(MCcontext *mcctx)
{
    return CUDA_SUCCESS;
}

static CUresult
barcheckHandlePatchCompletion(MCcontext *mcctx, MCrec *rec, MClaunch *launch)
{
    return CUDA_SUCCESS;
}

static CUresult
barcheckHeapSelected(MCcontext *mcctx, CCalloc *heap)
{
    return CUDA_SUCCESS;
}

static CUresult
barcheckContextSync(MCcontext *mcctx)
{
    return CUDA_SUCCESS;
}

static bool
barcheckEnableApiCheck(MCoptions *options)
{
    return false;
}

static CUresult
barcheckIsArchSupported(MCtoolMode *toolMode, MCtoolModeArchs arch, uint32_t *supported)
{
    if (!toolMode || !supported) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *supported = 0;

    /* Only support SM 3.5+ for now */
    if (arch >= MC_TOOL_MODE_ARCH_SM35 && arch <= MC_TOOL_MODE_ARCH_SM80)
        *supported = 1;

    return CUDA_SUCCESS;
}

static CUresult
barcheckIsOsSupported(MCtoolMode *toolMode, uint32_t *supported)
{
    if (!toolMode || !supported) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *supported = 1;

    return CUDA_SUCCESS;
}

static CUresult
barcheckIsModuleSupported(MCcontext *mcctx, MCmod *mod, CUmemcheck_error_types *modSupportedError)
{
    if (!mcctx || !mod || !modSupportedError) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *modSupportedError = CU_MEMCHECK_ERROR_NONE;

    if (mod->modOpts.usesCnp)
        *modSupportedError = CU_MEMCHECK_ERROR_UNSUPPORTED_CNP;

    return CUDA_SUCCESS;
}

static CUresult
barcheckUpdateLaunchConfig(MCcontext *mcctx, MCfunc *func, CUtoolsFunctionLaunchConfig *config)
{
    uint32_t minCRS = 0;
    CCbarcheckCtxData *ctxData = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !func || !config) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = barcheckGetContextData(mcctx);
    if (!ctxData) {
        CU_DEBUG_PRINT(("RC data already freed\n"));
        return CUDA_SUCCESS;
    }

    minCRS = ctxData->minCRS + 4;

    /* Update CRS to account for the max of the various context functions + 4 for the stub */
    if (config->syncStackSizeLaunch < minCRS + config->syncStackSizeCompiler + config->syncStackSizeDriver) {
        CU_TRACE_PRINT(("Updating CRS size for toolmode from : %u to %u\n",
                        config->syncStackSizeLaunch,
                        minCRS + config->syncStackSizeCompiler + config->syncStackSizeDriver));
        config->syncStackSizeLaunch = minCRS + config->syncStackSizeCompiler + config->syncStackSizeDriver;
    }

    return CUDA_SUCCESS;
}

static CUresult
barcheckCheckMemAccessDevAddr(MCcontext *mcctx, uint64_t addr, uint64_t size, CUtoolsStreamHandle stream, CCmemAccessType accessType)
{
    return CUDA_SUCCESS;
}

static CUresult
barcheckContextCreatedCallback(MCcontext *mcctx)
{
    CUresult res = CUDA_SUCCESS;
    CCbarcheckCtxData *ctxData = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = (CCbarcheckCtxData*) calloc(1, sizeof(*ctxData));
    if (!ctxData) {
        CU_ERROR_PRINT(("Out of memory\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* Every CTA needs to write a slot */
    ctxData->numSm = mcctx->cuctx->device->state.limits.physicalSmCount;
    ctxData->numCtaPerSm = mcctx->cuctx->device->state.limits.maxCtaPerSm;
    ctxData->maxDepth = 63; /* TODO: Query dynamically. Need a tools API Callback on resize */
    if (getArchFromSmVer(mcctx->sm_version) < MC_TOOL_MODE_ARCH_SM70) {
        ctxData->crsTokensPerWarp = 512;
        ctxData->ctaDataEntrySize = sizeof(BCdevCtaEntry);
    } else {
        ctxData->crsTokensPerWarp = BARCHECK_VOLTA_LMEM_STACK_MAX;
        ctxData->ctaDataEntrySize = sizeof(BCdevCtaEntryVolta);
    }

    /* Computed entries */
    ctxData->numSlots = ctxData->numSm * ctxData->numCtaPerSm * ctxData->maxDepth;
    // Round up to 32
    ctxData->numSlots = (ctxData->numSlots + 31) & (~31U);

    /* Create tables */
    res = createDeviceTables(mcctx, ctxData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to create device tables !!!\n"));
        goto error;
    }

    /* Load modules */
    res = loadBarcheckCtxModules(mcctx, ctxData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load required modules\n"));
        goto error;
    }

    /* Assign the pointer */
    mcctx->tm.ptr[MC_TOOL_MODE_BARCHECK] = (void*)ctxData;

    return CUDA_SUCCESS;

error:
    if (ctxData) {
        free(ctxData);
        ctxData = NULL;
    }

    return res;
}

static CUresult
barcheckInitEndCallback(MCglobals *gvars)
{
    gvars->tools.memory->ForceLMemMapInDevicePtr(1);
    return CUDA_SUCCESS;
}

static CUresult
barcheckAddAllocCallback(MCcontext *mcctx, CCalloc *alloc)
{
    return CUDA_SUCCESS;
}

static CUresult
barcheckRemoveAllocCallback(MCcontext *mcctx, CCalloc *alloc)
{
    return CUDA_SUCCESS;
}

CUresult
barcheck_toolModeInitialize(MCoptions *options, MCtoolMode *toolMode)
{
#if 0
    MCtoolModeArchState *arch_sm30 = NULL;
#endif
    MCtoolModeArchState *arch_sm35 = NULL;
    MCtoolModeArchState *arch_sm50 = NULL;
    MCtoolModeArchState *arch_sm52 = NULL;
    MCtoolModeArchState *arch_sm60 = NULL;
    MCtoolModeArchState *arch_sm70 = NULL;
    MCtoolModeArchState *arch_sm75 = NULL;
    MCtoolModeArchState *arch_sm80 = NULL;

    CU_TRACE_FUNCTION();

    if (!toolMode)
        return CUDA_ERROR_UNKNOWN;

    // Raw table initialization
#if 0
    arch_sm30 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM30];
#endif
    arch_sm35 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM35];
    arch_sm50 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM50];
    arch_sm52 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM52];
    arch_sm60 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM60];
    arch_sm70 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM70];
    arch_sm75 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM75];
    arch_sm80 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM80];

    // Select instructions to patch for every arch
    if (options->enableSassPatching) {
#if 0
        /* Kepler GK10x doesnt work right now */
        arch_sm30->checkMask = TO_CHECKTYPE_MASK(BAR);
        arch_sm30->opMask[MC_CHECK_TYPE_BAR] =  TO_INST_MASK(SYNC_BARRIER)  |
                                                TO_INST_MASK(EXIT);
#endif
        arch_sm35->checkMask = TO_CHECKTYPE_MASK(BARCHECK);
        arch_sm35->opMask[MC_CHECK_TYPE_BARCHECK] =  TO_INST_MASK(SYNC_BARRIER)  |
                                                     TO_INST_MASK(RET)           |
                                                     TO_INST_MASK(EXIT)          |
                                                     TO_INST_MASK(SHFL);

        arch_sm50->checkMask = TO_CHECKTYPE_MASK(BARCHECK);
        arch_sm50->opMask[MC_CHECK_TYPE_BARCHECK] =  TO_INST_MASK(SYNC_BARRIER) |
                                                     TO_INST_MASK(RET)          |
                                                     TO_INST_MASK(EXIT)         |
                                                     TO_INST_MASK(SHFL);

        arch_sm52->checkMask = TO_CHECKTYPE_MASK(BARCHECK);
        arch_sm52->opMask[MC_CHECK_TYPE_BARCHECK] =  TO_INST_MASK(SYNC_BARRIER) |
                                                     TO_INST_MASK(RET)          |
                                                     TO_INST_MASK(EXIT)         |
                                                     TO_INST_MASK(SHFL);

        arch_sm60->checkMask = TO_CHECKTYPE_MASK(BARCHECK);
        arch_sm60->opMask[MC_CHECK_TYPE_BARCHECK] =  TO_INST_MASK(SYNC_BARRIER) |
                                                     TO_INST_MASK(RET)          |
                                                     TO_INST_MASK(EXIT)         |
                                                     TO_INST_MASK(SHFL);

        arch_sm70->checkMask = TO_CHECKTYPE_MASK(BARCHECK);
        arch_sm70->opMask[MC_CHECK_TYPE_BARCHECK] =  TO_INST_MASK(SYNC_BARRIER) |
                                                     TO_INST_MASK(RET)          |
                                                     TO_INST_MASK(EXIT)         |
                                                     TO_INST_MASK(WARPSYNC)     |
                                                     TO_INST_MASK(ABS_CALL)     |
                                                     TO_INST_MASK(REL_CALL)     |
                                                     TO_INST_MASK(SHFL);

        arch_sm75->checkMask = TO_CHECKTYPE_MASK(BARCHECK);
        arch_sm75->opMask[MC_CHECK_TYPE_BARCHECK] =  TO_INST_MASK(SYNC_BARRIER) |
                                                     TO_INST_MASK(RET)          |
                                                     TO_INST_MASK(EXIT)         |
                                                     TO_INST_MASK(WARPSYNC)     |
                                                     TO_INST_MASK(ABS_CALL)     |
                                                     TO_INST_MASK(REL_CALL)     |
                                                     TO_INST_MASK(SHFL);

        /* Ampere GA10x */
        arch_sm80->checkMask = TO_CHECKTYPE_MASK(BARCHECK);
        arch_sm80->opMask[MC_CHECK_TYPE_BARCHECK] =  TO_INST_MASK(SYNC_BARRIER) |
                                                     TO_INST_MASK(RET)          |
                                                     TO_INST_MASK(EXIT)         |
                                                     TO_INST_MASK(WARPSYNC)     |
                                                     TO_INST_MASK(ABS_CALL)     |
                                                     TO_INST_MASK(REL_CALL)     |
                                                     TO_INST_MASK(SHFL);
    }

    toolMode->createPatchHelpers = barcheckCreatePatchHelpers;
    toolMode->destroyPatchHelpers = barcheckDestroyPatchHelpers;
    toolMode->hasPrologue = barcheckHasPrologue;
    toolMode->usesTrapHandler = barcheckUsesTrapHandler;
    toolMode->moduleLoadedCallback = barcheckModuleLoaded;
    toolMode->moduleUnloadedCallback = barcheckModuleUnloaded;
    toolMode->contextDestroyStartCallback = barcheckContextDestroyStart;
    toolMode->contextDestroyEndCallback = barcheckContextDestroyEnd;
    toolMode->heapSelectedCallback = barcheckHeapSelected;
    toolMode->ctxSyncCallback  = barcheckContextSync;
    toolMode->enableApiCheck = barcheckEnableApiCheck;
    toolMode->handlePatchCompletion = barcheckHandlePatchCompletion;
    toolMode->isArchSupported = barcheckIsArchSupported;
    toolMode->isOsSupported = barcheckIsOsSupported;
    toolMode->isModuleSupported = barcheckIsModuleSupported;
    toolMode->updateLaunchConfig = barcheckUpdateLaunchConfig;

    toolMode->contextCreatedCallback = barcheckContextCreatedCallback;
    toolMode->enableMemAccessCheck = barcheckEnableMemAccessCheck;
    toolMode->checkMemAccessDevAddr = barcheckCheckMemAccessDevAddr;
    toolMode->trapHandlerCallback = barcheckTrapHandlerCallback;
    toolMode->trapHandlerEndCallback = barcheckTrapHandlerEndCallback;
    toolMode->initEndCallback = barcheckInitEndCallback;
    toolMode->addAllocCallback = barcheckAddAllocCallback;
    toolMode->removeAllocCallback = barcheckRemoveAllocCallback;

    toolMode->getInternalModules = barcheckGetInternalModules;

    toolMode->getExceptionType = barcheckGetExceptionType;

    return CUDA_SUCCESS;
}
