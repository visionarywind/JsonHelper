/*
 * Copyright 2007-2014 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "barcheck/barcheck.h"
#include "check_core.h"
#include "memcheck_types.h"
#include "memcheck_inst_types.h"
#include "memcheck_error.h"

#include "halo.h"
#include "halo_internal.h"

#include "bikernels.h"
#include "tools_shared_list.h"

#include "check_tool_common.h"
#include "check_bitpool.h"
#include "check_mc_context.h"
#include "barcheck/barcheck_structs.h"
#include "devtools/common/halo/inc/fermi/fermi_mcinterop.h"
#include "devtools/common/halo/inc/fermi/fermi_barcheck_lmem.h"

static CUresult
dumpBarcheckError(MCcontext *mcctx, uint32_t vsm, uint32_t wp, uint32_t ln)
{
    uint32_t threadIdxX;
    uint32_t threadIdxY;
    uint32_t threadIdxZ;
    uint64_t pc;
    uint32_t violType = 0;
    uint32_t magic = 0;
    CuDim3   blockIdx;
    MCfunc *mcfunc = NULL;
    CUDBGResult dbgRes = CUDBG_SUCCESS;
    CCBacktrace *ccbt = NULL;
    CUresult res = CUDA_SUCCESS;
    CUmemcheck_record rec = {0};
    CUmemcheck_error_record *err = NULL;
    CUbarcheck_barViolation_types type;

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid context\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Read the blockIdx
    dbgRes = mcctx->dev->halo.read_blockIdx(mcctx->dev, vsm, wp, &blockIdx);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read block index\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Read threadIdx from HALO
    dbgRes = mcctx->dev->halo.read_threadIdx(mcctx->dev, vsm, wp, ln,
                                             0,
                                             &threadIdxX,
                                             &threadIdxY,
                                             &threadIdxZ);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read threadIdx for sm:%u wp:%u ln:%u\n",
                        vsm, wp, ln));
        goto error;
    }

    // Use the HALO to read the original PC
    dbgRes = mcctx->dev->halo.readLocalMemory(mcctx->dev, vsm, wp, ln,
                                    FERMI_LMEM_HI_MEMCHECK_SCRATCH +
                                    BARCHECK_LMEM_PC, &pc, sizeof pc);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read original PC on sm:%u wp:%u ln:%u\n",
                        vsm, wp, ln));
        goto error;
    }

    // on pre-Volta, clear hi bits
    if (getArchFromSmVer(mcctx->sm_version) < MC_TOOL_MODE_ARCH_SM70)
        pc &= 0x00000000ffffffff;

    // Use the HALO to read the error value (embedded in MAGIC)
    dbgRes = mcctx->dev->halo.readLocalMemory(mcctx->dev, vsm, wp, ln,
                                    FERMI_LMEM_HI_MEMCHECK_SCRATCH +
                                    BARCHECK_LMEM_MAGIC, &magic, sizeof magic);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read magic on sm:%u wp:%u ln:%u\n",
                        vsm, wp, ln));
        goto error;
    }

    // extract error code from magic value
    violType = magic & (~FERMI_MEMCHECK_WHITEMAGIC_MASK);

    if (violType == BARCHECK_SUCCESS) {
        CU_ERROR_PRINT(("Trapped with error bits set to SUCCESS (ignoring)\n"));
        return CUDA_SUCCESS;
    }

    // Create an error record
    if (!createNewErrorRecord(CU_MEMCHECK_RECORD_BAR_VIOLATION, &rec)) {
        CU_ERROR_PRINT(("Failed to create error record\n"));
        goto error;
    }

    err = &rec.cases.error;

    mcfunc = mcContextGetFuncByAddr(mcctx, pc);
    if (!mcfunc) {
        CU_DEBUG_PRINT(("Could not find function for pc 0x%" PRIx64 "\n", pc));
    }

    // Populate the error record
    err->cases.barViolation.blockIdxX = blockIdx.x;
    err->cases.barViolation.blockIdxY = blockIdx.y;
    err->cases.barViolation.blockIdxZ = blockIdx.z;
    err->cases.barViolation.threadIdxX = threadIdxX;
    err->cases.barViolation.threadIdxY = threadIdxY;
    err->cases.barViolation.threadIdxZ = threadIdxZ;
    if (mcfunc)
        err->cases.barViolation.pc = (uint32_t)(uintptr_t)(pc - mcfunc->mem.dev.dPtr);
    else
        err->cases.barViolation.pc = (uint32_t)pc;
    err->cases.barViolation.barIndex = 0;

    switch (violType) {
    case BARCHECK_ERROR_CRS_MISMATCH:
        type = CU_BARCHECK_BAR_VIOLATION_STACK_DIVERGENCE;
        break;
    case BARCHECK_ERROR_INTRA_WARP_DIVERGENCE:
        type = CU_BARCHECK_BAR_VIOLATION_INTRA_WARP_DIVERGENCE;
        break;
    case BARCHECK_ERROR_INSUFFICIENT_LIVE_THREADS:
        type = CU_BARCHECK_BAR_VIOLATION_INSUFFICIENT_LIVE_THREADS;
        break;
    case BARCHECK_ERROR_UNKNOWN:
        type = CU_BARCHECK_BAR_VIOLATION_UNKNOWN;
        break;
    case BARCHECK_ERROR_INVALID_ARGUMENTS:
        type = CU_BARCHECK_BAR_VIOLATION_INVALID_ARGUMENTS;
        break;
    case BARCHECK_ERROR_DEPRECATED_INSTRUCTION:
        type = CU_BARCHECK_BAR_VIOLATION_DEPRECATED_INSTRUCTION;
        break;
    default:
        type = CU_BARCHECK_BAR_VIOLATION_UNKNOWN;
        break;
    }

    err->cases.barViolation.type = type;
    CU_TRACE_PRINT(("Found barrier violation error %u at sm:%u wp:%u ln:%u "
                    "block: (%u,%u,%u) thread:(%u,%u,%u) pc:0x%" PRIx64 " func:%s\n",
                    violType,
                    vsm, wp, ln,
                    blockIdx.x,
                    blockIdx.y,
                    blockIdx.z,
                    threadIdxX,
                    threadIdxY,
                    threadIdxZ,
                    pc,
                    (mcfunc) ? mcfunc->funcName: "UNKNOWN"));

    res = haloGenerateFullBacktrace(mcctx, vsm, wp, ln, &ccbt);
    if (res != CUDA_SUCCESS) {
        CU_TRACE_PRINT(("Backtrace capture failed. Soldiering on\n"));
        ccbt = NULL;
    }

    // Add to record
    return addBarRecord(mcctx, &rec, mcfunc, ccbt);

error:
    return CUDA_ERROR_UNKNOWN;
}

CUresult
barcheckTrapHandlerCallback(MCcontext *mcctx, CUmemobj *scratchpad, uint32_t smError)
{
    CUDBGResult dbgRes = CUDBG_SUCCESS;
    uint32_t vsm, wp, ln;
    CUwarpBitmask validWarps;
    CUwarpBitmask brokenWarps;
    CUDBGException_t laneException = (CUDBGException_t)0;
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    res = mcContextHaloCheckTrapStateInitialize(mcctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to initialize trap state in HALO\n"));
        return res;
    }

    mcctx->dev->halo.clearSMState(mcctx->dev);

    dbgRes = mcctx->dev->halo.collectDeviceState(mcctx->dev, false, NULL);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to collect device state\n"));
        res = CUDA_ERROR_UNKNOWN;
        goto cleanup_and_return;
    }

    for (vsm = 0 ; vsm < mcctx->dev->halo.deviceInfo.numSMs; ++vsm) {
        if (!warpBitmaskAny(&mcctx->dev->smState[vsm].state.tidValid))
            continue;

        warpBitmaskAssign(&validWarps, &mcctx->dev->smState[vsm].state.tidValid);
        warpBitmaskAssign(&brokenWarps, &mcctx->dev->smState[vsm].state.brokenwarps);

        for (wp = 0; wp < mcctx->dev->halo.deviceInfo.numWarpsPrSM; ++wp) {

            // Skip invalid warps
            if (!warpBitmaskGetBits(&validWarps, wp, 1))
                continue;

            if (warpBitmaskGetBits(&brokenWarps, wp, 1)) {
                mcctx->gvars->tools.trap->SetSMHandledSingleWarp(mcctx->cuctx, vsm, wp);
            }

            for (ln = 0; ln < 32; ++ln) {
                laneException = mcctx->dev->smState[vsm].warp[wp].laneExceptions[ln];

                // examine only lanes with a valid exception
                if (laneException != CUDBG_EXCEPTION_LANE_ILLEGAL_ADDRESS)
                    continue;

                CU_TRACE_PRINT(("Barcheck error at vsm%u/wp%u/ln%u\n", vsm, wp, ln));
                res = dumpBarcheckError(mcctx, vsm, wp, ln);
                if (res != CUDA_SUCCESS) {
                    CU_ERROR_PRINT(("Failed to dump barcheck error at vsm:%u/wp%u/ln%u (res=%u)\n",
                                   vsm, wp, ln, res));
                }
            }
        }
    }

    res = flushRecords(mcctx, &mcctx->gvars->output);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to flush output\n"));
        goto cleanup_and_return;
    }


    CU_TRACE_PRINT(("Setting action to continue\n"));
    mcctx->gvars->tools.trap->SetTrapAckAction(mcctx->cuctx,
                                               CU_TOOLS_TRAP_ACK_CONTINUE);

cleanup_and_return:

    mcContextHaloCheckTrapStateFinalize(mcctx);

    return res;

}

CUresult
barcheckTrapHandlerEndCallback(MCcontext *mcctx, CUmemobj *scratchpad, uint32_t smError)
{

    /* TODO : UNDER CNP, set BPT.TRAP2 handled here */
    return CUDA_SUCCESS;
}
