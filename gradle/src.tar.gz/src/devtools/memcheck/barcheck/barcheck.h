/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef CHECK_BARCHECK_H
#define CHECK_BARCHECK_H

#include "cudamemcheck.h"
#include "memcheck_types.h"
#include "memcheck_tool_modes.h"
#include "memcheck_inst_types.h"
#include "barcheck/barcheck_structs.h"
#include "check_bitpool.h"

/* The barcheck data that we care about from the host side is mainly tracking of state*/

typedef struct CCbarcheckCtxData_st CCbarcheckCtxData;
typedef struct CCbarcheckRecData_st CCbarcheckRecData;

struct CCbarcheckCtxData_st {

    /* Cached vals for lookup */
    /* Hardware values */
    uint32_t numSm;
    uint32_t numCtaPerSm;
    /* Depth of maximum CNP join */
    uint32_t maxDepth;

    /* Number of Slots (i.e. max CTAs) */
    uint32_t numSlots;

    /* Size of each entry in ctaData */
    uint64_t ctaDataEntrySize;

    /* Local memory data */
    uint64_t defaultLmemBase;
    uint32_t lmemSizePerSm;
    uint32_t lmemSizePerWarp;
    uint32_t crsTokensPerWarp;

    /* Device pointer to bitpool tracker */
    uint64_t ctaBitpoolHeaderPtr;

    /* Global data */
    CCmemHandle globalData;

    /* Bitpool for the CTA data */
    CCbitpool *ctaBitpool;

    /* Actual per CTA data */
    CCmemHandle ctaBitpoolData;

    /* Main CudaC module */
    MCmod *mod;

    /* Context common entry points */
    uint64_t commonCtaEntry;
    uint64_t commonCtaExit;
    uint64_t commonPerBar;
    uint64_t commonPerThreadExit;
    uint64_t commonPerThreadRet;

    /* Global config options */
    uint32_t minCRS;
    uint32_t maxStack;
};

struct CCbarcheckRecData_st {
    /* Mainly for cleanup /repatching */
    tList   *internalModules;

    /* Entry exit module */
    MCmod *entryExitMod;
};

CUresult barcheck_toolModeInitialize(MCoptions *options, MCtoolMode *toolMode);

CUresult barcheckTrapHandlerCallback(MCcontext *mcctx, CUmemobj *scratchpad, uint32_t smError);
CUresult barcheckTrapHandlerEndCallback(MCcontext *mcctx, CUmemobj *scratchpad, uint32_t smError);

CCbarcheckCtxData* barcheckGetContextData(MCcontext *mcctx);
CCbarcheckRecData* barcheckGetRecData(MCrec *rec);

CUresult barcheckLoadEntryExit(MCrec *rec, MCfunc **stubFunc);
CUresult barcheckLoadBarrierStub(MCrec *rec, uint64_t *inst, uint64_t patchPC, bool isCGInstr, MCfunc **stubFunc);
CUresult barcheckLoadExitStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, MCfunc **stubFunc);
CUresult barcheckLoadRetStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, MCfunc **stubFunc);
CUresult barcheckLoadCallStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, bool isCGInstr, MCfunc **stubFunc);
CUresult barcheckLoadWarpsyncStub(MCrec *rec, uint64_t *inst, uint64_t patchPC, MCfunc **stubFunc);
CUresult barcheckLoadShflStub(MCrec *rec, uint64_t *inst, uint64_t patchPC, MCfunc **stubFunc);
#endif

