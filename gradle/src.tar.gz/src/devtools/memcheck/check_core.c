/*
 * Copyright 2007-2014 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: check_core.c
 *
 *   Description:
 *       When enabled, patches CUDA functions to perform
 *       checking
 *
 ******************************************************************************/

#define CU_INIT_UUID_STATIC 1
#include "../../../../compiler/gpgpu/export/cuda/tools/cudart/cudart_etbl/tools_runtime_instance.h"
#undef CU_INIT_UUID_STATIC

#include "check_core.h"
#include "check_filter.h"

#include "memcheck.h"
#include "memcheck_types.h"
#include "memcheck_error.h"
#include "memcheck_tool_modes.h"
#include "halo_drv.h"
#include "halo.h"
#include "halo_client_memcheck.h"
#include "halo_state.h"
#include "halo_internal.h"
#include "halo_trace.h"
#include "cuictx.h"
#include "stream_push.h"

#include "memmgr.h"
#include "cuda_types.h"
#include "memblock.h"

#include "tools_shared.h"
#include "tools_safety.h"
#include "memcheck_halo.h"

#include "memcheck_inst_types.h"
#include "cuda_etbl/tools_callback_arbiter.h"

#include "cudbgapi.h"
#include "cudbgdriver.h"
#include "check_ipc.h"

#include "tools_shared_hashmap.h"

#include "check_alloc.h"
#include "check_mc_context.h"
#include "check_mc_module.h"
#include "check_mc_func.h"
#include "check_mc_rec.h"
#include "check_mc_launch.h"
#include "cuicnp.h"
#include "cuievent.h"
#include "cuimemops.h"

#include "etbl/tools/tools_injection_internal.h"

// for cudaError_t enum values
#include "../../../../compiler/gpgpu/export/cuda/tools/cudart/driver_types.h"

#if defined(CUDA_DEVTOOLS_ENABLE_STATS)
#include "halo_timing.h"
#endif

typedef struct MCtlsEntry_st {
    int32_t  val;
    uint32_t launchStack;     // number of recursively called launchBegin callbacks
} MCtlsEntry;

// Performance test timers log file
#if defined(CUDA_DEVTOOLS_ENABLE_STATS)
static FILE * timersLogFile = NULL;
#endif

#if defined(CUDA_DEVTOOLS_ENABLE_STATS)

// Initialize timers output file
static void
haloTimersInit(void)
{
    char envVar[CUOS_ENV_VAR_LENGTH];

    CU_TRACE_FUNCTION();

    if (timersLogFile)
        return;

    if (!cuosGetEnv("HALO_TIMER_LOG_FILE", envVar, CUOS_ENV_VAR_LENGTH)) {
        FILE *fp = fopen(envVar, "wt");
        if(fp) {
            timersLogFile = fp;
            CU_DEBUG_PRINT(("Performance Test: Timers logging enabled\n"));
            fprintf(timersLogFile, "# Performance Test\n");
            fprintf(timersLogFile, "# Tools API callbacks timers\n");
            fprintf(timersLogFile, "type,domain_id,callback_id,time_nsec\n");
            fflush(timersLogFile);
        }
        else {
            CU_ERROR_PRINT(("Performance Test: Error opening timers log file. Timers logging disabled\n"));
        }
    }
    else {
        CU_DEBUG_PRINT(("Performance Test: HALO_TIMER_LOG_FILE not specified. Timers logging disabled\n"));
    }
}

// Print callback elapsed time
static void
haloTimerPrintCallback(haloTimer timer, uint32_t domain_id, uint32_t callback_id)
{
    int64_t total_elapsed_nsec = haloTimerGetTotalElapsedNsec(timer);

    if (!timersLogFile)
        return;

    fprintf(timersLogFile, "cb,%u,%u,%" PRId64 "\n",
            domain_id, callback_id, total_elapsed_nsec);
    fflush(timersLogFile);
}

#endif


typedef struct scopeLaunchProps_st scopeLaunchProps;
struct scopeLaunchProps_st {
    uint32_t shmem;
    MCpatchState state;
    uint32_t isActive;
};

static void CUDAAPI memcheckCallbackHandler(
    void *pUserData,
    CUtools_cb_domain domain,
    CUtoolsCbId cbid,
    const void *pParams);

static CUresult memcheckCleanup(MCglobals *gvars, CCcleanupMode mode);

static void
enableOutputMask(MCoptions *options)
{
    if (!options)
        return;

    if (options->client.ipcType == CCIPC_TYPE_NONE) {
        CU_DEBUG_PRINT(("Null IPC type. no output\n"));
        return;
    }

    if (options->client.ipcType != CCIPC_TYPE_LEGACY)
        options->client.outputTypeMask |= (1U << MC_OUTPUT_TYPE_IPC);
    else if (options->client.ipcType == CCIPC_TYPE_LEGACY) {
        /* Set up the file output */
        if (strlen(options->client.outputFileName)) {
            /* Output file name was given using an envvar */
            options->client.outputTypeMask |= (1U << MC_OUTPUT_TYPE_FILE);
        }
    }

    CU_DEBUG_PRINT(("Final output Type mask:0x%x\n", options->client.outputTypeMask));
}

static void
getOutputFile_v1(MCoptions *options)
{
    if (!options)
        return;

    /* For everything 5.5+ the output file name is set earlier  */
    if (options->client.version >= MC_CLIENT_VERSION_55) {
        return;
    }

    if (options->client.version == MC_CLIENT_VERSION_UNKNOWN ||
        !options->client.recordVersion) {
        /* If record version is 0 (i.e. debugger is present), or the client
           version cannot be determined, there is no point in file output */
        CU_TRACE_PRINT(("Unknown client, record version too old,"
                        " or debugger present. Output is disabled\n"));
        return;
    }

    /* Output file name was given using an envvar */
    (void)cuosGetEnv(CUDA_MEMCHECK_ENV_OUTPUT, options->client.outputFileName,
                     CUOS_ENV_VAR_LENGTH);
    enableOutputMask(options);
}

static CCIPCtype
getClientIPCType(MCoptions *options)
{
    char ipctype[CUOS_ENV_VAR_LENGTH] = {0};
    char *word = NULL;
    char *props[CCIPC_PROP_SIZE] = {0};
    uint32_t name = 0;
    char *val;
    size_t len = 0;

    options->client.ipcType = CCIPC_TYPE_NONE;

    /*  Pre 5.0 clients */
    if (options->client.version <= MC_CLIENT_VERSION_50) {
        CU_TRACE_PRINT(("5.0 or earlier client. Using v1 of CUDA_MEMCHECK_OUTPUT\n"));
        options->client.ipcType = CCIPC_TYPE_LEGACY;
        getOutputFile_v1(options);
        return (CCIPCtype)options->client.ipcType;
    }

    CU_TRACE_PRINT(("Found 5.5+ client. Using v2 of CUDA_MEMCHECK_OUTPUT\n"));

    /* Post 5.0 clients */
    if (!cuosGetEnv(CUDA_MEMCHECK_ENV_OUTPUT, ipctype, CUOS_ENV_VAR_LENGTH)) {
        CU_TRACE_PRINT(("Parsing line : %s\n", ipctype));
        /* The first token is the IPC type */
        word = strtok(&ipctype[0], ":");
        if (word)
            options->client.ipcType = atol(word);

        /* Capture the options */
        for (word = strtok(NULL, "="); word; word = strtok(NULL, "=")) {
            name = atol(word);
            // Skip unknown props
            if (name >= CCIPC_PROP_SIZE || name <= CCIPC_PROP_NONE) {
                strtok(NULL, ",");
                continue;
            }
            val = strtok(NULL, ",");
            props[name] = val;
        }
    }

    switch (options->client.ipcType) {
    case CCIPC_TYPE_LEGACY :
        if (props[CCIPC_PROP_OUT_FILE])
            memcpy(options->client.outputFileName, props[CCIPC_PROP_OUT_FILE],
                   strlen(props[CCIPC_PROP_OUT_FILE]));
        break;
    case CCIPC_TYPE_FILE:
    case CCIPC_TYPE_UDS:
    case CCIPC_TYPE_WNP:
    case CCIPC_TYPE_SHMEM :
    case CCIPC_TYPE_SHMEM_ALIGN:
        if (props[CCIPC_PROP_OUT_FILE]) {
            len = strlen((char*)props[CCIPC_PROP_OUT_FILE]) + 1;
            memcpy(options->client.ipcOutputFileName, (char*)props[CCIPC_PROP_OUT_FILE],
                   len);
        }
        if (props[CCIPC_PROP_IN_FILE]) {
            len = strlen((char*)props[CCIPC_PROP_IN_FILE]) + 1;
            memcpy(options->client.ipcInputFileName, (char*)props[CCIPC_PROP_IN_FILE],
                   len);
        }

        if (props[CCIPC_PROP_TOOLKIT_PID]) {
            len = strlen((char*)props[CCIPC_PROP_TOOLKIT_PID]) + 1;
            memcpy(options->client.ipcToolkitPid, (char*)props[CCIPC_PROP_TOOLKIT_PID],
                   len);
        }

        if (props[CCIPC_PROP_EVENT_NAME]) {
            len = strlen((char*)props[CCIPC_PROP_EVENT_NAME]) + 1;
            memcpy(options->client.eventName, (char*)props[CCIPC_PROP_EVENT_NAME],
                   len);
        }

        break;
    default:
        CU_ERROR_PRINT(("Unimplemented type :%u\n", options->client.ipcType));
        break;
    };

    enableOutputMask(options);

    return (CCIPCtype)options->client.ipcType;
}

static MCclientVersion
getClientVersion(MCoptions *options)
{
    char memcheck_recver[CUOS_ENV_VAR_LENGTH];
    char memcheck_flags[CUOS_ENV_VAR_LENGTH];
    char memcheck_enable[CUOS_ENV_VAR_LENGTH];
    uint32_t recver = 0;

    if (!options)
        return MC_CLIENT_VERSION_UNKNOWN;

    options->client.version = MC_CLIENT_VERSION_UNKNOWN;
    options->client.build = 0;

    /* Hide all the ugliness needed to figure out what client version
       is communicating to the driver.

       The logic tree is pretty awful.
       if CUDA_MEMCHECK_ENV_ENABLE != 1 (4.1 +)
       else if (CUDA_MEMCHECK_ENV_RECVER == 4) -> 4.0
       else if (CUDA_MEMCHECK_ERROR_FLAG) -> 3.2
       else if (CUDA_MEMCHECK_ENV_FLAG) -> old (deprecated)
       else unknown

       for 5.0, recordFormatVersion = (from env var) (8)
       for 4.1, recordFormatVersion = (from env var) (7,6,5)
       for 4.0, recordFormatVersion = (from env var) (4)
       for 3.2, recordFormatVersion = 3

    */
    if (!cuosGetEnv(CUDA_MEMCHECK_ENV_ENABLE, memcheck_enable, CUOS_ENV_VAR_LENGTH))
        options->client.build = atoi(memcheck_enable);

    if (!cuosGetEnv(CUDA_MEMCHECK_ENV_RECVER, memcheck_recver, CUOS_ENV_VAR_LENGTH))
        recver = atoi(memcheck_recver);
    else
        recver = 0;

    /* New style clients expose the version number */
    if (options->client.build > CUDA_MEMCHECK_TK_VERSION_4_0) {
        if (options->client.build > CUDA_MEMCHECK_TK_VERSION_7_0 &&
            options->client.build <= CUDA_MEMCHECK_TK_VERSION_BUILD) {
            options->client.version = MC_CLIENT_VERSION_LATEST;
        }
        else if (options->client.build > CUDA_MEMCHECK_TK_VERSION_6_5 &&
            options->client.build <= CUDA_MEMCHECK_TK_VERSION_7_0) {
            options->client.version = MC_CLIENT_VERSION_70;
        }
        else if (options->client.build > CUDA_MEMCHECK_TK_VERSION_6_0 &&
            options->client.build <= CUDA_MEMCHECK_TK_VERSION_6_5) {
            options->client.version = MC_CLIENT_VERSION_65;
        }
        else if (options->client.build > CUDA_MEMCHECK_TK_VERSION_5_5 &&
                 options->client.build <= CUDA_MEMCHECK_TK_VERSION_6_0) {
            options->client.version = MC_CLIENT_VERSION_60;
        }
        else if (options->client.build > CUDA_MEMCHECK_TK_VERSION_5_0 &&
                 options->client.build <= CUDA_MEMCHECK_TK_VERSION_5_5) {
            options->client.version = MC_CLIENT_VERSION_55;
        }
        else if (options->client.build > CUDA_MEMCHECK_TK_VERSION_4_2 &&
                 options->client.build <= CUDA_MEMCHECK_TK_VERSION_5_0) {
            options->client.version = MC_CLIENT_VERSION_50;
        }
        else if (options->client.build > CUDA_MEMCHECK_TK_VERSION_4_1 &&
                 options->client.build <= CUDA_MEMCHECK_TK_VERSION_4_2) {
            options->client.version = MC_CLIENT_VERSION_42;
        }
        else if (options->client.build > CUDA_MEMCHECK_TK_VERSION_4_0 &&
                 options->client.build <= CUDA_MEMCHECK_TK_VERSION_4_1) {
            options->client.version = MC_CLIENT_VERSION_41;
        }

        options->client.recordVersion = recver;

        return  options->client.version;
    }

    /* The recver based checks (for 4.0 and older clients) */
    /* If we are here, then CUDA_MEMCHECK=1 (i.e. no client provided version) */
    if (recver > 4) {
        /* Only possible if using an EA build of toolkit */
        CU_TRACE_PRINT(("Bad combination of recver and client ver."
                        "Guessing this is a prerelease version of 4.1\n"));
        options->client.version = MC_CLIENT_VERSION_41;
        options->client.recordVersion = recver;
    }
    /* 4.0 is special cased */
    else if (recver == 4) {
        options->client.version = MC_CLIENT_VERSION_40;
        options->client.recordVersion = 4;
    }

    if (recver >= 4)
        return options->client.version;

    /* Handle the odd cases (3.2, debugger) */
    if (!cuosGetEnv(CUDA_MEMCHECK_ENV_FLAGS, memcheck_flags,
                    CUOS_ENV_VAR_LENGTH) &&
        (atoi(memcheck_flags) & CU_MEMCHECK_FLAG_ERRORS)) {
        options->client.version = MC_CLIENT_VERSION_32;
        options->client.recordVersion = 3;
    }
    else if (gpudbgDebuggerAttached() ||
             gpudbgDebuggerEnableIntegratedMemcheck()) {
        /* Test for legacy debugger (sets only the env var) */
        options->client.version = MC_CLIENT_VERSION_DBG;
        /* Does not matter */
        options->client.recordVersion = 0;
        /* Force client to 1 */
        options->client.build = 1;
    }
    else {
        CU_ERROR_PRINT(("Failed to find client version\n"));
        options->client.version = MC_CLIENT_VERSION_UNKNOWN;
    }

    return options->client.version;
}

CUresult
optionsAddFilter(MCoptions *options, CCfilterDesc *filterDesc)
{
    CUresult status = CUDA_SUCCESS;

    if (!options || !filterDesc)
        return CUDA_ERROR_UNKNOWN;

    status = CCfilterMgrAddFilterByDesc(options->client.filterMgr, filterDesc);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to add filter\n"));
        return status;
    }

    return CUDA_SUCCESS;
}

CUresult
flagsSetOptions(MCoptions *options, uint32_t flags)
{
    if (!options)
        return CUDA_ERROR_UNKNOWN;

    if (flags & CU_RACECHECK_FLAG_ENABLE) {
        CU_TRACE_PRINT(("!! RACE CHECKING ENABLED. MEMCHECK DISABLED\n"));
        options->toolModeType = MC_TOOL_MODE_RACECHECK;
        options->nonblockingLaunch = 1;

        options->raceReportMode = RC_REPORT_MODE_HAZARD_ONLY;

        if (flags & CU_RACECHECK_FLAG_ANALYSIS) {
            if (flags & CU_RACECHECK_FLAG_ANALYSIS_ONLY)
                options->raceReportMode = RC_REPORT_MODE_ANALYSIS_ONLY;
            else
                options->raceReportMode = RC_REPORT_MODE_ALL;
        }
    }

    if (flags & CU_BARCHECK_FLAG_ENABLE) {
        CU_TRACE_PRINT(("!! BARRIER CHECKING ENABLED. OTHER TOOLS DISABLED\n"));
        options->toolModeType = MC_TOOL_MODE_BARCHECK;
        options->nonblockingLaunch = 1;
    }

    if (flags & CU_INITCHECK_FLAG_ENABLE) {
        CU_TRACE_PRINT(("!! INITCHECK ENABLED. OTHER TOOLS DISABLED\n"));
        options->toolModeType = MC_TOOL_MODE_INITCHECK;
    }

    if (flags & CU_MEMCHECK_FLAG_FORCE_ERROR)
        options->forceError = 1;

    if (flags & CU_MEMCHECK_FLAG_API_CHECK)
        options->enableApiCheck = 1;

    if (flags & CU_MEMCHECK_FLAG_RAW_OUTPUT)
        options->rawOutput = 1;

    if (flags & CU_MEMCHECK_FLAG_NONBLOCKING)
        options->nonblockingLaunch = 1;

    if (flags & CU_MEMCHECK_FLAG_FLUSH_TO_DISK)
        options->flushToDisk = 1;

    if (flags & CU_MEMCHECK_FLAG_GLOBAL_LEAK)
        options->enableCudaMallocLeakInfo = 1;

    if (flags & CU_MEMCHECK_FLAG_DEVHEAP_LEAK)
        options->enableDevHeapLeakInfo = 1;

    if (flags & CU_MEMCHECK_FLAG_BACKTRACE_HOST)
        options->enableHostBacktrace = 1;

    if (flags & CU_MEMCHECK_FLAG_BACKTRACE_DEV)
        options->enableDeviceBacktrace = 1;

    if (flags & CU_MEMCHECK_FLAG_ERRORS)
        options->reportHWErrors = 1;

    if (flags & CU_MEMCHECK_FLAG_DEBUGGER)
        options->debuggerAttached = 1;

    if (flags & CU_MEMCHECK_FLAG_DYNAMIC) {
        options->requestedDynamic = 1;
        // If a particular scheme was not requested, use GLOB
        options->requestedScheme = 2;
    }

    if (flags & CU_MEMCHECK_FLAG_DISABLE_PATCHING) {
        options->enableSassPatching = false;
    }
    if (flags & CU_MEMCHECK_FLAG_CHECK_MEMACCESS) {
        options->checkMemcpyMemset = 1;
    }

    if (flags & CU_MEMCHECK_FLAG_REPORT_FATBIN_LOAD_ERROR) {
        options->reportFatBinaryLoadErrors = 1;
    }

    if (flags & CU_MEMCHECK_FLAG_UVM) {
        options->frontendRequiresUvm = 1;
    }

    if (flags & CU_INITCHECK_FLAG_UNUSED_MEMORY) {
        options->enableUnusedMemory = 1;
    }

    if (flags & CU_MEMCHECK_FLAG_CHECK_DEPRECATED) {
        options->checkDeprecatedInstr = 1;
    }

    return CUDA_SUCCESS;
}

static void
setOptions_legacy(MCoptions *options)
{
    char memcheck_flags[CUOS_ENV_VAR_LENGTH];
    uint32_t flags = 0;

    if (!options)
        return;

    // Do some client specific overrides. Both 4.1 and 4.2 expect
    // leak information to always be present for cudaMallocs
    if (options->client.version == MC_CLIENT_VERSION_41 ||
        options->client.version == MC_CLIENT_VERSION_42)
        options->enableCudaMallocLeakInfo = 1;

    if (!cuosGetEnv(CUDA_MEMCHECK_ENV_FLAGS, memcheck_flags, CUOS_ENV_VAR_LENGTH))
        flags = atoi(memcheck_flags);

    flagsSetOptions(options, flags);
}

static void
setOptions_defaults(MCoptions *options)
{
    if (!options)
        return;

    // Setup memcheck defaults
    options->toolModeType = MC_TOOL_MODE_MEMCHECK;
    options->memMapMode = CC_MEM_MAP_MODE_HALO;
    options->useHalo = 1;
    options->flushToDisk = 0;
    options->backtraceMaxHostDepth = 61;
    options->backtraceMaxDevDepth = 256;
    options->enableSassPatching = true;

    (void)CCfilterMgrCreate(&options->client.filterMgr);
}

static void
setOptions_finalize(MCoptions *options)
{
#ifndef RELEASE
    char memcheck_flags[CUOS_ENV_VAR_LENGTH];
    char dynamic_scheme[CUOS_ENV_VAR_LENGTH];
#endif

    if (!options)
        return;

#ifndef RELEASE
    // Start reading the environment variables
    if (!cuosGetEnv("CUDA_AMODEL_GPU", memcheck_flags, CUOS_ENV_VAR_LENGTH))
        options->isAmodel = 1;
#endif

#ifndef RELEASE
    if (!cuosGetEnv("CUDA_MEMCHECK_PRINT_CUBINS", memcheck_flags, CUOS_ENV_VAR_LENGTH))
        options->printCubins = 1;
#endif

#ifndef RELEASE
    if (!cuosGetEnv("CUDA_MEMCHECK_TOOL_MODE", memcheck_flags, CUOS_ENV_VAR_LENGTH)) {
        if (strcmp(memcheck_flags, "memcheck") == 0)
            options->toolModeType = MC_TOOL_MODE_MEMCHECK;
        else
        if (strcmp(memcheck_flags, "barcheck") == 0)
            options->toolModeType = MC_TOOL_MODE_BARCHECK;
        else
        if (strcmp(memcheck_flags, "racecheck") == 0)
            options->toolModeType = MC_TOOL_MODE_RACECHECK;
        else
        if (strcmp(memcheck_flags, "initcheck") == 0)
            options->toolModeType = MC_TOOL_MODE_INITCHECK;
        else
            CU_ERROR_PRINT(("Unknown value for CUDA_MEMCHECK_TOOL_MODE\n"));
    }
#endif

    if (gpudbgDebuggerAttached() ||
        options->debuggerAttached) {
        options->debuggerAttached = 1;
        options->reportHWErrors = 0;
        CU_TRACE_PRINT(("Warning : Disabling HALO when debugger is enabled\n"));
        options->useHalo = 0;
        options->memMapMode = CC_MEM_MAP_MODE_MEMOBJ;

        if (CUDBG_APICLIENT_REVISION >= API_REVISION_5_0) {
            options->requestedDynamic   = 1;
            options->requestedScheme    = 2;
        }
    }
    else if (options->reportHWErrors)
        options->debuggerAttached = 0;

    // Clobber all unallowed options on amodel:
    // No host side trap handling, so no nonblocking launch (except for racecheck which does not need trap handling)
    // and no hw exception reporting
    // Another side effect is that the HALO is disabled
    if (options->isAmodel) {
        if (options->nonblockingLaunch && options->toolModeType != MC_TOOL_MODE_RACECHECK) {
            CU_TRACE_PRINT(("Warning : Found Amodel GPU: Disabling nonblocking launches\n"));
            options->nonblockingLaunch = 0;
        }
        if (options->reportHWErrors) {
            CU_TRACE_PRINT(("Warning : Found Amodel GPU: Disabling HW exception reporting\n"));
            options->reportHWErrors = 0;
        }
        if (options->useHalo) {
            CU_TRACE_PRINT(("Warning : Found Amodel GPU: Disabling HALO\n"));
            options->useHalo = 0;
        }
        if (options->memMapMode == CC_MEM_MAP_MODE_HALO) {
            CU_TRACE_PRINT(("Warning : Found Amodel GPU: Disabling HALO mappings\n"));
            options->memMapMode = CC_MEM_MAP_MODE_MEMOBJ;
        }
        if (options->forceError) {
            CU_TRACE_PRINT(("Warning : Found Amodel GPU: Disabling forced errors\n"));
            options->forceError = 0;
        }
    }

#if cuosOsIsWindows()
    options->memMapMode = CC_MEM_MAP_MODE_FORCED;
#endif

#if cuosOsIsAndroid()
    if (options->enableHostBacktrace) {
        CU_TRACE_PRINT(("Warning : Host backtraces not supported on Android. Disabling\n"));
        options->enableHostBacktrace = 0;
    }
#endif

#if cuosOsIsQnx()
    if (options->enableHostBacktrace) {
        CU_TRACE_PRINT(("Warning : Host backtraces not supported on QNX. Disabling\n"));
        options->enableHostBacktrace = 0;
    }
#endif

#ifndef RELEASE
    if (!cuosGetEnv("CUDA_MEMCHECK_MAP_MODE", memcheck_flags, CUOS_ENV_VAR_LENGTH)) {
        if (!strcmp(memcheck_flags,"MEMOBJ")) {
            options->memMapMode = CC_MEM_MAP_MODE_MEMOBJ;
        }
        else if (!strcmp(memcheck_flags, "FORCED")) {
            options->memMapMode = CC_MEM_MAP_MODE_FORCED;
        }
        else if (!strcmp(memcheck_flags, "HALO")) {
            options->memMapMode = CC_MEM_MAP_MODE_HALO;
        }
    }
    if (!cuosGetEnv("CUDA_MEMCHECK_USE_HALO", memcheck_flags, CUOS_ENV_VAR_LENGTH)) {
        options->useHalo =  !!(atol(memcheck_flags));
    }
#endif

#ifndef RELEASE
    if (options->requestedDynamic) {
        // In 4.1 / r285 this variable will not be set
        if (!cuosGetEnv(CUDA_MEMCHECK_ENV_DYNSCHEME,
                        dynamic_scheme,
                        CUOS_ENV_VAR_LENGTH)) {
            // Check the user provided scheme
            if (!strcmp(dynamic_scheme, "NONE"))
                options->requestedScheme = 0;
            else if (!strcmp(dynamic_scheme, "OOB"))
                options->requestedScheme = 1;
            else if (!strcmp(dynamic_scheme, "GLOB"))
                options->requestedScheme = 2;
            else
                // A bad request goes back to default (GLOB)
                options->requestedScheme = 2;
        }
    }
#endif

}

static CUresult
setupClient(MCoptions *options)
{
    CCIPCtype ipcType = CCIPC_TYPE_NONE;

    if (!options)
        return CUDA_ERROR_UNKNOWN;

    memset(options, 0, sizeof *options);
    setOptions_defaults(options);

    // As the very first step, get the client version
    getClientVersion(options);

    ipcType = getClientIPCType(options);

    switch (ipcType) {
    case CCIPC_TYPE_NONE:
        CU_ERROR_PRINT(("Invalid ipc type\n"));
        return CUDA_ERROR_UNKNOWN;

    case CCIPC_TYPE_FILE:
        CU_DEBUG_PRINT(("Client is IPC type: FILE\n", ipcType));
        break;

    case CCIPC_TYPE_UDS:
        CU_DEBUG_PRINT(("Client is IPC type: UDS\n", ipcType));
        break;

    case CCIPC_TYPE_WNP:
        CU_DEBUG_PRINT(("Client is IPC type: WNP\n", ipcType));
        break;

    case CCIPC_TYPE_SHMEM:
        CU_DEBUG_PRINT(("Client is IPC type: SHMEM\n", ipcType));
        break;

    case CCIPC_TYPE_SHMEM_ALIGN:
        CU_DEBUG_PRINT(("Client is IPC type: SHMEM_ALIGN\n", ipcType));
        break;

    case CCIPC_TYPE_LEGACY:
        CU_DEBUG_PRINT(("Client is legacy\n"));
        break;

    default:
        CU_ERROR_PRINT(("Invalid ipc type (type:%u)\n", ipcType));
        return CUDA_ERROR_UNKNOWN;
    };

    return CUDA_SUCCESS;
}

static CUresult
setOptions(MCoutput *output, MCoptions *options)
{
    if (!options || !output)
        return CUDA_ERROR_UNKNOWN;

    switch (options->client.ipcType) {
    case CCIPC_TYPE_NONE:
        CU_ERROR_PRINT(("Invalid ipc type\n"));
        return CUDA_ERROR_UNKNOWN;

    case CCIPC_TYPE_FILE:
    case CCIPC_TYPE_UDS:
    case CCIPC_TYPE_WNP:
    case CCIPC_TYPE_SHMEM:
    case CCIPC_TYPE_SHMEM_ALIGN:
        CU_TRACE_PRINT(("IPC is already setup\n"));
        break;

    case CCIPC_TYPE_LEGACY:
        setOptions_legacy(options);
        break;

    default:
        CU_ERROR_PRINT(("Invalid ipc type (type:%u)\n",
                        options->client.ipcType));
        return CUDA_ERROR_UNKNOWN;
    };

    setOptions_finalize(options);

    return CUDA_SUCCESS;
}

#define CC_ENABLE_CB(dom,cbid) do {                                                               \
        CUresult status = CUDA_SUCCESS;                                                         \
        status = gvars->tools.callbacks->EnableCallback(1,                                      \
                                                        gvars->tools.subscriberHandle,          \
                                                        CU_TOOLS_CB_DOMAIN_##dom,               \
                                                        CU_TOOLS_CBID_##dom##_##cbid);          \
        if (status != CUDA_SUCCESS) {                                                           \
            CU_ERROR_PRINT(("Failed to subscribe to callback dom:%s cbid:%s. (Status:%d)\n",    \
                            #dom, #cbid, status));         \
            return CU_MEMCHECK_ERROR_FAILED_INITIALIZATION;                                     \
        }                                                                                       \
    } while(0)

#define CC_ENABLE_CB_DOMAIN(dom) do {                                                                       \
        CUresult status = CUDA_SUCCESS;                                                                     \
        status = gvars->tools.callbacks->EnableAllCallbacksInDomain(1,                                      \
                                                                    gvars->tools.subscriberHandle,          \
                                                                    CU_TOOLS_CB_DOMAIN_##dom);              \
        if (status != CUDA_SUCCESS) {                                                                       \
            CU_ERROR_PRINT(("Failed to subscribe to callback dom:%s. (Status:%d)\n",                        \
                            #dom, status));                                                                 \
            return CU_MEMCHECK_ERROR_FAILED_INITIALIZATION;                                                 \
        }                                                                                                   \
    } while(0)

static CUmemcheck_error_types
enableToolsApiCallbacks(MCglobals *gvars)
{
    CU_TRACE_FUNCTION();

    if (!gvars)
        return CU_MEMCHECK_ERROR_FAILED_INITIALIZATION;

    /* Resource callbacks */
    CC_ENABLE_CB(RESOURCE, DEVICE_MEM_ALLOC);
    CC_ENABLE_CB(RESOURCE, DEVICE_MEM_FREE);
    CC_ENABLE_CB(RESOURCE, HOST_MEM_ALLOC);
    CC_ENABLE_CB(RESOURCE, HOST_MEM_FREE);
    CC_ENABLE_CB(RESOURCE, MODULE_LOADED);
    CC_ENABLE_CB(RESOURCE, MODULE_UNLOAD_STARTING);
    CC_ENABLE_CB(RESOURCE, CONTEXT_INITIALIZE_STARTING);
    CC_ENABLE_CB(RESOURCE, CONTEXT_CREATED);
    CC_ENABLE_CB(RESOURCE, CONTEXT_DESTROY_STARTING);
    CC_ENABLE_CB(RESOURCE, CONTEXT_DESTROY_COMPLETED);
    CC_ENABLE_CB(RESOURCE, DEVICE_HEAP_SELECTED);
    CC_ENABLE_CB(RESOURCE, CNP_UPDATE_CONSTANTS);
    CC_ENABLE_CB(RESOURCE, SURF_OBJECT_CREATED);
    CC_ENABLE_CB(RESOURCE, SURF_OBJECT_DESTROY);
    CC_ENABLE_CB(RESOURCE, STREAM_CREATED);
    CC_ENABLE_CB(RESOURCE, STREAM_DESTROY_STARTING);
    CC_ENABLE_CB(RESOURCE, FUNCTION_PATCHED);
    CC_ENABLE_CB(RESOURCE, GRAPHEXEC_CREATING);

    /* Launch callbacks */
    CC_ENABLE_CB(LAUNCH, BEGIN);
    CC_ENABLE_CB(LAUNCH, END);
    CC_ENABLE_CB(LAUNCH, AFTER_SYSCALL_SETUP);
    CC_ENABLE_CB(LAUNCH, BEFORE_LAUNCH_PUSHED);
    CC_ENABLE_CB(LAUNCH, AFTER_GRID_LAUNCHED);

    /* Trap callbacks */
    CC_ENABLE_CB(TRAP, BEGIN);
    CC_ENABLE_CB(TRAP, END);

    /* QMD callbacks */
    CC_ENABLE_CB(QMD, BEFORE_LAUNCH);

    /* Synchronize callback */
    CC_ENABLE_CB(SYNCHRONIZE, STREAM_SYNCHRONIZED);

    /* Memcpy */
    CC_ENABLE_CB(MEMCPY, BEGIN);
    CC_ENABLE_CB(MEMCPY, END);

    /* Memset */
    CC_ENABLE_CB(MEMSET, SETUP_INIT);

    /* UVM lite */
    CC_ENABLE_CB(UVM_LITE, STREAM_ENQUEUE_BEGIN);
    CC_ENABLE_CB(UVM_LITE, STREAM_ENQUEUE_END);

    /* Graphs */
    CC_ENABLE_CB(GRAPH, LAUNCH_NODE_BEGIN);
    CC_ENABLE_CB(GRAPH, LAUNCH_NODE_END);

    /* Internal */
    CC_ENABLE_CB(RESOURCE_INTERNAL, MEMBLOCK_ALLOC);
    CC_ENABLE_CB(RESOURCE_INTERNAL, MEMBLOCK_FREE);
    CC_ENABLE_CB(RESOURCE_INTERNAL, HOST_LOCAL_MEM_RESIZE);

    /* Enable everything in trace */
    CC_ENABLE_CB_DOMAIN(TRACE_API_CUDA);

    /* Enable everything in trace runtime */
    CC_ENABLE_CB_DOMAIN(TRACE_API_CUDA_RUNTIME);

    /* Enable this to get the runtime's internal init */
    CC_ENABLE_CB(CUDA_RUNTIME_INTERNAL, INIT);

    /* Enable this to get the module load */
    CC_ENABLE_CB(TRACE_API_CUDA_ETBL, ModuleLoadFatBinary);

    /* Enable stream write in batch memop */
    CC_ENABLE_CB(BATCH_MEMOP, WRITE);

    return CU_MEMCHECK_ERROR_NONE;
}
#undef CC_ENABLE_CB_DOMAIN
#undef CC_ENABLE_CB

static CUresult
checkIncompatibleTools(uint32_t *toolPresent)
{

    CU_TRACE_FUNCTION();

    if (!toolPresent) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *toolPresent = 0;

    if (toolsInjectionLibraryRequested()) {
        CU_ERROR_PRINT(("Detected another tools API client present. Failing initialization\n"));
        *toolPresent = 1;
    }

    return CUDA_SUCCESS;
}

void memcheckInit(void)
{
#if TOOLS_ENABLED /* WAR to make it compile under the safety flavor until tools file are excluded */
    CUresult status;
    MCglobals *gvars = NULL;
    char memcheck_enable[CUOS_ENV_VAR_LENGTH];
    CUmemcheck_error_types errorType = CU_MEMCHECK_ERROR_NONE;
    uint32_t osSupported = 0;
    uint32_t toolPresent = 0;

    if (cuosGetEnv(CUDA_MEMCHECK_ENV_ENABLE, memcheck_enable, CUOS_ENV_VAR_LENGTH) &&
        !gpudbgDebuggerEnableIntegratedMemcheck())
        return;

#if defined(CUDA_DEVTOOLS_ENABLE_STATS)
    haloTimersInit();
#endif

    gvars = (MCglobals*) calloc(1, sizeof *gvars);
    if (!gvars) {
        errorType = CU_MEMCHECK_ERROR_OUT_OF_HOST_MEMORY;
        CU_ERROR_PRINT(("\n"));
        return;
    }

    memset(gvars, 0, sizeof *gvars);
    cuiMutexInitialize(&gvars->globalsMutex, CUI_MUTEX_ORDER_TERMINAL, CUI_MUTEX_DEFAULT);
    gvars->contexts = toolsHashMapNew(toolsUint32HashFun, toolsUint64EqualFun, 17);
    if (!gvars->contexts) {
        CU_ERROR_PRINT(("Failed to allocate context hash map (Status:%d)\n"));
        goto error;
    }

    gvars->tlsEntry = cuosTlsAlloc(NULL);

    status = setupClient(&gvars->options);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to setup client. (Status:%d)\n", status));
        goto error;
    }

    status = initializeOutput(&gvars->output, &gvars->options, gvars);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to initialize output. (Status:%d)\n", status));
        goto error;
    }

    status = setOptions(&gvars->output, &gvars->options);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to setup options. (Status:%d)\n", status));
        goto error;
    }

    status = toolModeInitialize(gvars->options.toolModeType, &gvars->options, &gvars->toolMode);
    if (status != CUDA_SUCCESS) {
        errorType = CU_MEMCHECK_ERROR_FAILED_INITIALIZATION;
        CU_ERROR_PRINT(("Failed to initialize tool mode. (Status:%d)\n", status));
        goto error;
    }

    status = gvars->toolMode.isOsSupported(&gvars->toolMode, &osSupported);
    if (status != CUDA_SUCCESS) {
        errorType = CU_MEMCHECK_ERROR_FAILED_INITIALIZATION;
        CU_ERROR_PRINT(("Failed to query supported OS for tool mode. (Status:%d)\n", status));
        goto error;
    }

    if (!osSupported) {
        errorType = CU_MEMCHECK_ERROR_UNSUPPORTED_OS;
        CU_ERROR_PRINT(("Unsupported OS for tool mode\n"));
        goto error;
    }

    status = checkIncompatibleTools(&toolPresent);
    if (status != CUDA_SUCCESS) {
        errorType = CU_MEMCHECK_ERROR_FAILED_INITIALIZATION;
        CU_ERROR_PRINT(("Failed to query state of other attached tools (Status:%d)\n", status));
        goto error;
    }

    if (toolPresent) {
        errorType = CU_MEMCHECK_ERROR_TOOL_ATTACHED;
        CU_ERROR_PRINT(("Unsupported tool attached\n"));
        goto error;
    }

    status = cuGetExportTable((const void**)&gvars->tools.callbacks, &CU_ETID_ToolsCallbackArbiter);
    if (status != CUDA_SUCCESS) {
        errorType = CU_MEMCHECK_ERROR_FAILED_INITIALIZATION;
        CU_ERROR_PRINT(("Failed to find ETBL : Callback. (Status:%d)\n", status));
        goto error;
    }
    status = cuGetExportTable((const void**)&gvars->tools.context, &CU_ETID_ToolsContext);
    if (status != CUDA_SUCCESS) {
        errorType = CU_MEMCHECK_ERROR_FAILED_INITIALIZATION;
        CU_ERROR_PRINT(("Failed to find ETBL : Context. (Status:%d)\n", status));
        goto error;
    }
    status = cuGetExportTable((const void**)&gvars->tools.device, &CU_ETID_ToolsDevice);
    if (status != CUDA_SUCCESS) {
        errorType = CU_MEMCHECK_ERROR_FAILED_INITIALIZATION;
        CU_ERROR_PRINT(("Failed to find ETBL : Device. (Status:%d)\n", status));
        goto error;
    }
    status = cuGetExportTable((const void**)&gvars->tools.module, &CU_ETID_ToolsModule);
    if (status != CUDA_SUCCESS) {
        errorType = CU_MEMCHECK_ERROR_FAILED_INITIALIZATION;
        CU_ERROR_PRINT(("Failed to find ETBL : Module. (Status:%d)\n", status));
        goto error;
    }
    status = cuGetExportTable((const void**)&gvars->tools.memory, &CU_ETID_ToolsMemory);
    if (status != CUDA_SUCCESS) {
        errorType = CU_MEMCHECK_ERROR_FAILED_INITIALIZATION;
        CU_ERROR_PRINT(("Failed to find ETBL : Memory. (Status:%d)\n", status));
        goto error;
    }
    status = cuGetExportTable((const void**)&gvars->tools.memcpy, &CU_ETID_ToolsMemCopy);
    if (status != CUDA_SUCCESS) {
        errorType = CU_MEMCHECK_ERROR_FAILED_INITIALIZATION;
        CU_ERROR_PRINT(("Failed to find ETBL : Memcpy. (Status:%d)\n", status));
        goto error;
    }
    status = cuGetExportTable((const void**)&gvars->tools.pushBufferHal, &CU_ETID_ToolsPushBufferHal);
    if (status != CUDA_SUCCESS) {
        errorType = CU_MEMCHECK_ERROR_FAILED_INITIALIZATION;
        CU_ERROR_PRINT(("Failed to find ETBL : PushBuffer. (Status:%d)\n", status));
        goto error;
    }
    status = cuGetExportTable((const void**)&gvars->tools.trap, &CU_ETID_ToolsTrapHandler);
    if (status != CUDA_SUCCESS) {
        errorType = CU_MEMCHECK_ERROR_FAILED_INITIALIZATION;
        CU_ERROR_PRINT(("Failed to find ETBL : TrapHandler. (Status:%d)\n", status));
        goto error;
    }
    status = cuGetExportTable((const void**)&gvars->tools.cnp, &CU_ETID_ToolsCnp);
    if (status != CUDA_SUCCESS) {
        errorType = CU_MEMCHECK_ERROR_FAILED_INITIALIZATION;
        CU_ERROR_PRINT(("Failed to find ETBL : CNP. (Status:%d)\n", status));
        goto error;
    }

#if cuosPlatformHasKernelModeUvm()
    status = cuGetExportTable((const void**)&gvars->tools.uvm8, &CU_ETID_ToolsUvm8Events);
    if (status != CUDA_SUCCESS) {
        errorType = CU_MEMCHECK_ERROR_FAILED_INITIALIZATION;
        CU_ERROR_PRINT(("Failed to find ETBL : UVM8. (Status:%d)\n", status));
        goto error;
    }
#endif

    status = cuGetExportTable((const void**)&gvars->tools.link, &CU_ETID_ToolsLink);
    if (status != CUDA_SUCCESS) {
        errorType = CU_MEMCHECK_ERROR_FAILED_INITIALIZATION;
        CU_ERROR_PRINT(("Failed to find ETBL : Link. (Status:%d)\n", status));
        goto error;
    }

    status = cuGetExportTable((const void**)&gvars->tools.graph, &CU_ETID_ToolsGraph);
    if (status != CUDA_SUCCESS) {
        errorType = CU_MEMCHECK_ERROR_FAILED_INITIALIZATION;
        CU_ERROR_PRINT(("Failed to find ETBL : Graphs. (Status:%d)\n", status));
        goto error;
    }

    status = gvars->tools.callbacks->Subscribe(&gvars->tools.subscriberHandle, CU_TOOLS_CBA_CLIENT_MEMCHECK,
                                               memcheckCallbackHandler, gvars);
    if (status != CUDA_SUCCESS) {
        errorType = CU_MEMCHECK_ERROR_FAILED_INITIALIZATION;
        CU_ERROR_PRINT(("Failed to Subscribe to arbiter. (Status:%d)\n", status));
        goto error;
    }

    /* Callbacks to enable: */
    errorType = enableToolsApiCallbacks(gvars);
    if (errorType != CU_MEMCHECK_ERROR_NONE) {
        CU_ERROR_PRINT(("Faield to enable callbacks\n"));
        goto error;
    }

    if (gvars->options.debuggerAttached)
        CU_DEBUG_PRINT(("cuda-memcheck runs in debugger mode\n"));
    else {
        if (gvars->options.memMapMode == CC_MEM_MAP_MODE_FORCED) {
            gvars->tools.memory->ForceInstructionAllocInSysMem(1);
            gvars->tools.memory->ForceLMemAllocInSysMem(1);
            gvars->tools.memory->ForceCrsStackAllocInSysMem(1);
            gvars->tools.memory->ForceCnpDataInSysmem(1);
            gvars->tools.memory->ForcePreemptionBufferAllocInSysMem(1);
        }

        /* Halo init needs to do PRI reads. On WDDM, this cannot happen
           unless the context is initialized, which is not true at this point.
           Thus, we defer the Halo initialization until we receive the first
           context create callback.
         */
#ifndef RELEASE
        /* Used for emulation */
        haloDrvSetupEMU();
#endif
    }

    /* Force the driver to initialize the device trap handler and spawn
       a debug event handler thread on any created contexts */
    if (gvars->toolMode.usesTrapHandler(&gvars->options)) {
        gvars->tools.trap->EnableTrapHandler(1);
    }

    status = initializeUvm(&gvars->output, &gvars->options, gvars);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to initialize UVM. (Status:%d)\n", status));
        goto error;
    }

    status = gvars->toolMode.initEndCallback(gvars);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed in initEnd callback for toolmode. (Status:%d)\n", status));
        goto error;
    }

    gvars->initialized = 1;

    CU_DEBUG_PRINT(("cuda-memcheck is active\n"));

    return;

error:
    CU_ERROR_PRINT(("cuda-memcheck failed to initialize\n"));

    printInternalError(errorType, gvars);

    memcheckCleanup(gvars, CC_CLEANUP_MODE_HOST_AND_DEVICE);

    if (gvars) {
        free(gvars);
        gvars = NULL;
    }
#endif
}

static void
contextCleanupFunctor(void *value, void *functor_data)
{
    CUresult res = CUDA_SUCCESS;
    MCcontext *mcctx = (MCcontext*)value;
    CCcleanupMode mode = (CCcleanupMode)(uintptr_t)functor_data;

    if (!mcctx)
        return;

    res = mcLaunchRemoveAll(mcctx);
    if (res != CUDA_SUCCESS)
        CU_ERROR_PRINT(("Failed to remove all launched\n"));

    res = mcContextRemoveAllPatches(mcctx, mode);
    if (res != CUDA_SUCCESS)
        CU_ERROR_PRINT(("Failed to remove all patches\n"));

    res = mcContextCleanupState(mcctx);
    if (res != CUDA_SUCCESS)
        CU_ERROR_PRINT(("Failed to cleanup state\n"));

    if (mode == CC_CLEANUP_MODE_HOST_AND_DEVICE) {
        res = mcContextCleanupDevice(mcctx);
        if (res != CUDA_SUCCESS)
            CU_ERROR_PRINT(("Failed to cleanup device\n"));
    }

    res = mcContextDestroy(mcctx);
    if (res != CUDA_SUCCESS)
        CU_ERROR_PRINT(("Failed to destroy context\n"));
}

static CUresult
memcheckCleanup(MCglobals *gvars, CCcleanupMode mode)
{
    /* Should shutdown Tools API callbacks here, if it worked */
    // Dont need to grab the globals mutex lock here as at this point, everything is
    // being destroyed
    MCtlsEntry *tlsData = NULL;
    CUresult res = CUDA_SUCCESS;

    if (!gvars)
        return CUDA_SUCCESS;

    if (gvars->tools.callbacks)
        (void)gvars->tools.callbacks->EnableAllCallbacks(0, gvars->tools.subscriberHandle);

    if (gvars->contexts) {
        toolsHashMapDelete(gvars->contexts, contextCleanupFunctor, (void*)(uintptr_t)mode);
        gvars->contexts = NULL;
    }

    res = finalizeUvm(gvars);
    if (res != CUDA_SUCCESS)
        CU_ERROR_PRINT(("Failed to finalize UVM (err = %d)\n", res));

    if (gvars->haloInitialized) {
        haloFinalize();
        gvars->haloInitialized = 0;
    }

    tlsData = (MCtlsEntry*)cuosTlsGetValue(gvars->tlsEntry);
    if (tlsData) {
        free(tlsData);
    }
    cuosTlsFree(gvars->tlsEntry);

    finalizeOutput(&gvars->output);

    cuiMutexDeinitialize(&gvars->globalsMutex);

    // For now just do the unsubscribe. We cant free(gvars) until the
    // trap handler callback also moves to the tools API
    gvars->initialized = 0;

    return CUDA_SUCCESS;
}

/******************** Implementation *****************************/

static void CUDAAPI
addGlobalVarCallback(void *data, CUtoolsGlobalVariableProperties *props)
{
    CUresult res;
    MCmod *mod = (MCmod*) data;
    uint32_t flags = 0;

    CU_TRACE_FUNCTION();

    if (props->pName)
        flags |= CC_ALLOC_FLAG_NAMED;

    flags |= CC_ALLOC_FLAG_MODULE;

    if (props->isUVMManaged)
        flags |= CC_ALLOC_FLAG_MANAGED;

    res = mcContextAddGlobalAllocation(mod->context, (uint64_t)(uintptr_t)props->devptr,
                                       props->sizeInBytes, flags, CC_ALLOC_VISIBILITY_CTX, props->pName);
    if (res != CUDA_SUCCESS)
        CU_ERROR_PRINT(("Failed to add global allocation\n"));
}

static CUresult
addGlobalVariables(MCmod *mod, CUmodule cumod)
{
    CU_ASSERT(mod);

    CU_TRACE_FUNCTION();

    mod->context->gvars->tools.module->ModuleEnumerateGlobalVariables(mod->context->cuctx, cumod, &addGlobalVarCallback, mod);

    return CUDA_SUCCESS;
}

static void CUDAAPI
removeGlobalVarCallback(void *data, CUtoolsGlobalVariableProperties *props)
{
    MCmod *mod = (MCmod*)data;
    CUresult status = CUDA_SUCCESS;

    status = mcContextRemoveGlobalAllocation(mod->context, (uint64_t)(uintptr_t) props->devptr);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to remove global allocation\n"));
    }
}

static CUresult
removeGlobalVariables(MCmod *mod, CUmodule cumod)
{
    CU_ASSERT(mod);

    mod->context->gvars->tools.module->ModuleEnumerateGlobalVariables(mod->context->cuctx, cumod, &removeGlobalVarCallback, mod);

    return CUDA_SUCCESS;
}

CUDBGResult
memcheckFindInSyscall(uint64_t physPC, CUctx *cuctx, void *pgvars, bool *found)
{
    MCglobals *gvars = NULL;
    MCcontext *mcctx = NULL;
    MCfunc *func = NULL;

    if (!cuctx || !pgvars || !found) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDBG_ERROR_UNKNOWN;
    }

    gvars = (MCglobals*)pgvars;
    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(cuctx));
    mcUnlock(gvars);

    if (!mcctx) {
        CU_ERROR_PRINT(("Cannot find mc context\n"));
        return CUDBG_ERROR_INVALID_CONTEXT;
    }

    *found = !!(mcContextGetSyscallByAddr(mcctx, physPC));

    return CUDBG_SUCCESS;
}

CUDBGResult
memcheckFindInMemcheckPatch(uint64_t physPC, CUctx *cuctx, void *pgvars, bool *found)
{
    MCglobals *gvars = NULL;
    MCcontext *mcctx = NULL;
    MCrec *rec = NULL;

    if (!cuctx || !pgvars || !found) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDBG_ERROR_UNKNOWN;
    }

    gvars = (MCglobals*)pgvars;
    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(cuctx));
    mcUnlock(gvars);

    if (!mcctx) {
        CU_ERROR_PRINT(("Cannot find mc context\n"));
        return CUDBG_ERROR_INVALID_CONTEXT;
    }

    rec = mcContextGetPatchByAddr(mcctx, physPC);

    *found = !!(rec);

    return CUDBG_SUCCESS;
}

CUDBGResult
memcheckCreateDynamicGrid(CudbgDevice dev, uint32_t sm, uint32_t wp, uint32_t ln,
                          uint64_t gridId64, uint64_t physPC,
                          CuDim3 gridDim, CuDim3 blockDim, bool *isPostable)
{
    CUDBGResult res = CUDBG_SUCCESS;
    DeviceFunction function;
    MCfunc *mcfunc;
    Grid grid;
    Context context;
    MCcontext *mcctx = NULL;
    MCglobals *gvars = NULL;
    MCrec *tmprec = NULL;

    CU_TRACE_FUNCTION();
    CU_TRACE_PRINT(( "gridid = %" PRId64 ", physPC = 0x%016" PRIx64 ".\n", gridId64, physPC));

    /* Ensure we have an active context */
    context = dev->activeContext;
    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "Device has no active context\n");

    /* Lookup the function */
    gvars = (MCglobals *)haloGlobals.initData.cases.memcheck.gvars;
    if (!gvars) {
        CU_ERROR_PRINT(("Invalid gvars. Bad initialization?\n"));
        return CUDBG_ERROR_UNKNOWN;
    }
    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(context->cuCtx));
    mcUnlock(gvars);

    if (!mcctx) {
        CU_ERROR_PRINT(("Unable to find context\n"));
        return CUDBG_ERROR_INVALID_CONTEXT;
    }

    mcfunc = mcContextGetFuncByAddr(mcctx, physPC);
    if (!mcfunc) {
        CU_ERROR_PRINT(("Failed to find function. Trying patch map\n"));
        tmprec = mcContextGetPatchByAddr(mcctx, physPC);
        if (!tmprec) {
            CU_ERROR_PRINT(("Failed to find function in patch map\n"));
            return CUDBG_ERROR_UNKNOWN_FUNCTION;
        }
        else
            mcfunc = tmprec->func;
    }

    function = mcfunc->haloFunc;
    CUDBG_VERIFY(function, CUDBG_ERROR_INVALID_ADDRESS, "Failed to find function (physPC = 0x%016" PRIx64 ")\n", physPC);

    /* Create the grid */
    mcCtxLock(mcfunc->mod->context);
    res = haloStateCreateGrid(&grid, function, gridId64);
    mcCtxUnlock(mcfunc->mod->context);
    if (res != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(( "Failed to create grid\n"));
        return res;
    }

    /* Fill in additional per-grid information */
    grid->gridDim = gridDim;
    grid->blockDim = blockDim;

    /* Follow the same logic as the debugger here. Immediately
       post all grids except those that are syscall entry points */
    if (mcFuncIsSyscallFuncType(mcfunc) && mcFuncIsEntryFuncType(mcfunc))
        *isPostable = false;
    else
        *isPostable = true;

    CU_TRACE_PRINT(( "Dynamic grid created (gridid = %" PRId64 ", func=%s, "
                     "gridDim.x,y,z=%d,%d,%d, blockDim.x,y,z=%d,%d,%d)"
                     " post:%u\n",
                     gridId64, mcfunc->funcName,
                     grid->gridDim.x, grid->gridDim.y, grid->gridDim.z,
                     grid->blockDim.x, grid->blockDim.y, grid->blockDim.z,
                     *isPostable));

    return CUDBG_SUCCESS;
}

CUDBGResult
memcheckUpdateUnpostedDynamicGrid(CudbgDevice dev, uint32_t sm, uint32_t wp,
                                  uint32_t ln, Grid *grid, uint64_t physPC,
                                  bool *isPostable)
{
    CUDBGResult res = CUDBG_SUCCESS;
    DeviceFunction function;
    MCfunc *mcfunc = NULL;
    MCcontext *mcctx = NULL;
    MCglobals *gvars = NULL;
    Grid newgrid;
    Context context;
    CuDim3 blockDim, gridDim;
    uint64_t gridId64;

    CU_TRACE_FUNCTION();

    CUDBG_VERIFY(dev && grid && isPostable,
                 CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CU_TRACE_PRINT(( "gridid = %" PRId64 ", physPC = 0x%016" PRIx64 ".\n", (*grid)->gridId64, physPC));

    /* Ensure we have an active context */
    context = dev->activeContext;
    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "Device has no active context\n");

    /* Lookup the function */
    gvars = (MCglobals *)haloGlobals.initData.cases.memcheck.gvars;
    if (!gvars) {
        CU_ERROR_PRINT(("Invalid gvars. Bad initialization?\n"));
        return CUDBG_ERROR_UNKNOWN;
    }
    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(context->cuCtx));
    mcUnlock(gvars);

    if (!mcctx) {
        CU_ERROR_PRINT(("Unable to find context\n"));
        return CUDBG_ERROR_INVALID_CONTEXT;
    }

    mcfunc = mcContextGetFuncByAddr(mcctx, physPC);
    if (!mcfunc) {
        CU_ERROR_PRINT(("Unable to lookup function\n"));
        /* __TEMP_WAR__ 1421862 : Not all functions can be found, since internal modules are not fully handled.
           For now, we will early return here when this is the case. This is always safe, since memcheck
           precise errors cannot come from internal code. Once bug 1421862 is fixed, this hack should be able to go away.
          */
        *isPostable = false;
        return CUDBG_SUCCESS;
    }

    function = mcfunc->haloFunc;
    CUDBG_VERIFY(function, CUDBG_ERROR_INVALID_ADDRESS, "Failed to find function (physPC = 0x%016" PRIx64 ")\n", physPC);

    /* Reset isPostable */
    *isPostable = false;

    if ((*grid)->state != HALO_GRID_STATE_INVISIBLE) {
        CU_ERROR_PRINT(("Updating posted grid\n"));
        return CUDBG_ERROR_UNKNOWN;
    }

    if (!mcFuncIsSyscallFuncType(mcfunc)) {
        CU_TRACE_PRINT(("Unposted grid has become postable\n"));
        *isPostable = true;
    }

    if (function != (*grid)->function) {
        gridId64 = (*grid)->gridId64;
        gridDim = (*grid)->gridDim;
        blockDim = (*grid)->blockDim;

        /* Destroy old grid */
        haloStateDestroyGrid(*grid);

        /* Create the new grid */
        res = haloStateCreateGrid(&newgrid, function, gridId64);
        if (res != CUDBG_SUCCESS) {
            CU_ERROR_PRINT(( "Failed to create grid\n"));
            return res;
        }

        /* Fill in additional per-grid information */
        newgrid->gridDim = gridDim;
        newgrid->blockDim = blockDim;

        *grid = newgrid;
    }

    return CUDBG_SUCCESS;
}

CUDBGResult
memcheckPostGridEvent(CudbgDevice dev, Context context, Grid grid, DeviceFunction function)
{
    CUDBG_VERIFY(dev && context && grid && function,
                 CUDBG_ERROR_INVALID_CONTEXT, "Invalid arguments\n");

    grid->state = HALO_GRID_STATE_POSTED;

    return CUDBG_SUCCESS;
}

CUDBGResult
memcheckInitiateChannelGroupPreemptSave(CudbgDevice dev, bool *allPreempted, bool *ctaPreemptTriggered)
{
    // Stubbed out for memcheck
    return CUDBG_SUCCESS;
}

CUDBGResult
memcheckInitiateChannelGroupPreemptRestore(CudbgDevice dev, bool *allPreempted)
{
    // Stubbed out for memcheck
    return CUDBG_SUCCESS;
}

CUDBGResult
memcheckGetExceptionFromMagic(CudbgDevice dev, uint32_t magic, CUDBGException_t *exception)
{
    CUresult status = CUDA_SUCCESS;
    MCglobals *gvars = NULL;

    CU_TRACE_FUNCTION();

    CUDBG_VERIFY(dev && exception, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments");

    *exception = CUDBG_EXCEPTION_NONE;

    gvars = (MCglobals *)haloGlobals.initData.cases.memcheck.gvars;
    if (!gvars) {
        CU_ERROR_PRINT(("Invalid gvars. Bad initialization?\n"));
        return CUDBG_ERROR_UNKNOWN;
    }

    status = gvars->toolMode.getExceptionType(magic, exception);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to query exception type from tool mode\n"));
        return CUDBG_ERROR_UNKNOWN;
    }

    return CUDBG_SUCCESS;
}

/*********** CUDA Driver callbacks from Tools API ***********/

/* Save the context handle, open the output file, and create the table of global memory allocations */
static CUresult
contextInitializeStarting(MCglobals *gvars,
                          const CUtoolsContextInitializeStarting *params)
{
    CUresult status = CUDA_SUCCESS;
    CUmemcheck_error_types errorType = CU_MEMCHECK_ERROR_NONE;
    MCcontext *mcctx = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;

    CU_ASSERT(gvars);
    CU_ASSERT(params);

    CU_TRACE_FUNCTION();

    /* In the world of CNP, we could potentially be performing kernel launches
       before we get the official context created callback. So we use this
       early callback to create the context and track any contexts that
       are in flight. What we cant do here :
       1. HALO initialization (context cannot do reg reads yet)
       2. MCHal initialization (device may not be initialized)
       3. Trap handler installation
    */

    status = mcContextCreate(gvars, params, &mcctx);
    if (status != CUDA_SUCCESS)
        goto error;

    mcLock(gvars);
    tres = toolsHashMapInsert(gvars->contexts, tHashMapPtrToKey(params->ctx), (void*)(mcctx));
    mcUnlock(gvars);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to insert context to map\n"));
        status = CUDA_ERROR_UNKNOWN;
        printInternalError(CU_MEMCHECK_ERROR_FAILED_INITIALIZATION, gvars);
        goto error;
    }

    return CUDA_SUCCESS;

error:
    mcLock(gvars);
    toolsHashMapRemove(gvars->contexts, tHashMapPtrToKey(params->ctx), NULL);
    mcUnlock(gvars);
    if (mcctx) {
        mcContextDestroy(mcctx);
    }
    return status;
}

static CUresult
contextCreated(MCglobals *gvars, const CUtoolsContextCreated *params)
{
    CUresult status = CUDA_SUCCESS;
    MCcontext *mcctx = NULL;
    CUmemcheck_error_types errorType = CU_MEMCHECK_ERROR_NONE;
    uint32_t archSupport = 0;

    CU_ASSERT(gvars);
    CU_ASSERT(params);

    CU_TRACE_FUNCTION();

    /* If the profiler is up, memcheck will print a message and die */
#if !defined(CUDA_DEVTOOLS_ENABLE_STATS)
    if (isProfilerRequested()) {
        printInternalError(CU_MEMCHECK_ERROR_PROFILER_ATTACHED, gvars);
        return CUDA_ERROR_UNKNOWN;
    }
#endif

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(params->ctx));
    mcUnlock(gvars);

    if (!mcctx) {
        CU_ERROR_PRINT(("Unknown context.\n"));
        printInternalError(CU_MEMCHECK_ERROR_FAILED_INITIALIZATION, gvars);
        return CUDA_ERROR_UNKNOWN;
    }

    status = mcContextOnCuCtxCreated(mcctx, gvars, params);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("mcContextOnCuCtxCreated callback failed\n"));
        printInternalError(CU_MEMCHECK_ERROR_FAILED_INITIALIZATION, gvars);
        return status;
    }

    return CUDA_SUCCESS;
}

/* Clean up any remaining resources allocated by memcheck. Two tools
   API callbacks bracket the cuiCtxDestroy. We can't use the late one
   for everything as the memory manager is gone by then so we can't
   free device resources (was bug 683608). However, if we do
   everything from the early one, then we remove knowledge of the
   context while it's still in use. The solution is to do device (and
   host) clean up early, and leave the rest for
   contextDestroyCompleted. */
static CUresult
contextDestroyStarting(MCglobals *gvars, const CUtoolsContextDestroyStarting *params)
{
    MCcontext *mcctx;
    CUresult res = CUDA_SUCCESS;

    CU_ASSERT(gvars);
    CU_ASSERT(params);

    CU_TRACE_FUNCTION();

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(params->ctx));
    mcUnlock(gvars);

    if (!mcctx) {
        CU_ERROR_PRINT(("Beginning to destroy a context we don't know\n"));
        return CUDA_ERROR_INVALID_CONTEXT;
    }

    if (!mcContextIsActive(mcctx)) {
        CU_TRACE_PRINT(("Context is not yet initialized\n"));
        return CUDA_SUCCESS;
    }

    res = mcctx->gvars->toolMode.contextDestroyStartCallback(mcctx);
    if (res != CUDA_SUCCESS) {
        /* Context is going down, so keep soldiering on */
        CU_ERROR_PRINT(("Failure in toolMode callback for context destroy start\n"));
    }

    res = mcContextCleanupState(mcctx);
    if (res != CUDA_SUCCESS)
        CU_ERROR_PRINT(("Failed to cleanup state\n"));

    res = mcContextCleanupDevice(mcctx);
    if (res != CUDA_SUCCESS)
        CU_ERROR_PRINT(("Failed to cleanup state\n"));

    return CUDA_SUCCESS;
}

/* This is the rest of contextDestroy; we're done with the context and
   can get rid of it. */
static CUresult
contextDestroyCompleted(MCglobals *gvars, const CUtoolsContextDestroyCompleted *params)
{
    CUresult res = CUDA_SUCCESS;
    MCcontext *mcctx = NULL;

    CU_ASSERT(gvars);
    CU_ASSERT(params);

    CU_TRACE_FUNCTION();

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(params->ctx));
    if (mcctx)
        toolsHashMapRemove(gvars->contexts, tHashMapPtrToKey(params->ctx), NULL);
    mcUnlock(gvars);
    if (!mcctx) {
        CU_ERROR_PRINT(("Destroying a context we don't know\n"));
        return CUDA_ERROR_INVALID_CONTEXT;
    }

    res = mcctx->gvars->toolMode.contextDestroyEndCallback(mcctx);
    if (res != CUDA_SUCCESS) {
        /* Context is going down, so keep soldiering on */
        CU_ERROR_PRINT(("Failure in toolMode callback for context destroy completed\n"));
    }

    res = mcContextDestroy(mcctx);
    if (res != CUDA_SUCCESS)
        CU_ERROR_PRINT(("Failed to destroy context\n"));

    /* Return CUDA_SUCCESS even for issues when destroying context */
    return CUDA_SUCCESS;
}

/* Handle a context or stream synchronization. Ideally, this should only be done
 * as part of a tools callback, but some CUDA APIs are making implicit synchronization
 * (cudaFree, cudaMemcpy) without any synchronization callback. */
static CUresult
handleSynchronization(MCglobals *gvars, MCcontext *mcctx, CUtoolsStreamHandle streamHandle)
{
    CUresult res = CUDA_SUCCESS;
    TOOLSresult toolsResult = TOOLS_SUCCESS;
    MCrec *removedRecs = NULL;
    uint64_t streamId = CUI_STREAM_ID_INVALID;

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid context.\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (streamHandle != 0) {
        res = mcctx->gvars->tools.context->StreamGetIdEx(mcctx->cuctx, streamHandle, &streamId);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Invalid stream handle.\n"));
            return res;
        }
    }

    /* Acquire writer lock to serialize with concurrent launch sequences.
       We have to call the appropriate sync again while holding the ctx rwlock
       to prevent against concurrent launches. Otherwise, the following sequence
       is possible, since the driver doesn't hold any lock in the tools callback.
       T1                           T2
       (ctx sync API call)
         driverCtxSync
                                    launchBegin
                                      lock(rwlock)
                                      createLaunch X
                                      launch
                                    launchEnd
                                      unlock(rwlock)
         ctxSyncCallback (no lock)
           handleSynchronization
             lock(rwlock)
             removeLaunches
               remove launch X      X still running
    */

    toolsResult = toolsRWLockAcquireWriteBlocking(&mcctx->rwlock);
    if (TOOLS_SUCCESS != toolsResult) {
        CU_ERROR_PRINT(("Failed to acquire ctx rwlock\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (streamId == CUI_STREAM_ID_INVALID) {
        // this will call our internal context sync per-tool callback implicitly
        res = mcContextSynchronize(mcctx);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("mcContextSynchronize failed\n"));
            goto unlock;
        }
    } else {
        res = mcContextStreamSynchronize(mcctx, streamHandle);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("mcContextStreamSynchronize failed\n"));
            goto unlock;
        }
    }

    res = mcLaunchRemove(mcctx, streamId, MC_LAUNCH_STATE_ACTIVE);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to retire all outstanding launches\n"));
        goto unlock;
    }

    /* Remove all complete patches as the context has syncd. mcLaunchRemove
       will mark some patches as complete.
       To save device memory we remove these as soon as we sync */
    res = mcContextRemoveLaunchedPatches(mcctx, &removedRecs);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to clear outstanding patches\n"));
        goto unlock;
    }

unlock:
    toolsResult = toolsRWLockReleaseWrite(&mcctx->rwlock);
    if (TOOLS_SUCCESS != toolsResult) {
        CU_ERROR_PRINT(("Failed to release ctx writer lock\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* run deferred cleanups, which can't be done under ctx locks */
    res = mcContextRunDeferredPatchCleanup(removedRecs);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to run deferred cleanups for recs\n"));
        return res;
    }

    return res;
}

static CUresult
loadAtomSysInstrOffsets(MCcontext *mcctx, MCmod *mod)
{
    CUresult res = CUDA_SUCCESS;
    MCfunc *func = NULL;
    uint32_t *offsets = NULL;
    uint32_t offsets_sz = 256 * sizeof(*offsets);

    if (!mcctx || !mod)
        return CUDA_ERROR_INVALID_VALUE;

    if (!mod->funcList)
        return CUDA_SUCCESS;

    offsets = (uint32_t*)calloc(1, offsets_sz);
    if (!offsets)
        return CUDA_ERROR_OUT_OF_MEMORY;

    for (func = mod->funcList; func;) {
        TOOLSresult toolsResult = TOOLS_SUCCESS;
        uint32_t real_offsets_sz = 0;

        if (isELF64((const char*)mod->image))
            toolsResult = toolsElf64GetAtomSysInstrOffsets(mod->image,
                                                           func->funcName,
                                                           offsets,
                                                           offsets_sz,
                                                           &real_offsets_sz);
        else
            toolsResult = toolsElf32GetAtomSysInstrOffsets(mod->image,
                                                           func->funcName,
                                                           offsets,
                                                           offsets_sz,
                                                           &real_offsets_sz);

        if (toolsResult == TOOLS_ERROR_OUT_OF_MEMORY) {
            /* Reallocate buffer and try again with same function */
            free(offsets);
            offsets = NULL;
            offsets = (uint32_t*)calloc(1, real_offsets_sz);
            if (!offsets)
                return CUDA_ERROR_OUT_OF_MEMORY;

            offsets_sz = real_offsets_sz;
            continue;
        }

        /* For TOOLS_ERROR_SECTION_NOT_FOUND just continue with next function */
        if (toolsResult != TOOLS_ERROR_SECTION_NOT_FOUND) {
            uint32_t num_offsets = 0;
            uint32_t i = 0;

            if (toolsResult != TOOLS_SUCCESS) {
                CU_ERROR_PRINT(("Failed to get atomsys instr offsets for %s (error = %d)\n", func->funcName, toolsResult));
                res = CUDA_ERROR_UNKNOWN;
                goto cleanup;
            }

            /* Found some instr offsets */
            num_offsets = real_offsets_sz / sizeof(*offsets);
            func->hasElidedAtomSys = 1;

            res = mcFuncFlagInstrAtOffsets(func, offsets, num_offsets, MC_INSTR_INFO_ATOMSYS);
            if (res != CUDA_SUCCESS)
                goto cleanup;
        }

        func = func->next;
    }

cleanup:
    free(offsets);
    offsets = NULL;

    return res;
}

static CUresult
loadCoopGroupsInstrOffsets(MCcontext *mcctx, MCmod *mod)
{
    CUresult res = CUDA_SUCCESS;
    MCfunc *func = NULL;
    uint8_t elfIs64Bit = 0;
    uint32_t *offsets = NULL;
    uint32_t offsets_sz = 256 * sizeof(*offsets);

    if (!mcctx || !mod)
        return CUDA_ERROR_INVALID_VALUE;

    if (!mod->funcList)
        return CUDA_SUCCESS;

    offsets = (uint32_t*)calloc(1, offsets_sz);
    if (!offsets) {
        res = CUDA_ERROR_OUT_OF_MEMORY;
        goto cleanup;
    }

    elfIs64Bit = isELF64((const char*)mod->image);

    for (func = mod->funcList; func;) {
        TOOLSresult toolsResult = TOOLS_SUCCESS;
        uint32_t real_offsets_sz = 0;

        if (elfIs64Bit)
            toolsResult = toolsElf64GetCoopGroupInstrOffsets(mod->image,
                                                             func->funcName,
                                                             offsets,
                                                             offsets_sz,
                                                             &real_offsets_sz);
        else
            toolsResult = toolsElf32GetCoopGroupInstrOffsets(mod->image,
                                                             func->funcName,
                                                             offsets,
                                                             offsets_sz,
                                                             &real_offsets_sz);

        if (toolsResult == TOOLS_ERROR_OUT_OF_MEMORY) {
            /* Reallocate buffer and try again with same function */
            free(offsets);
            offsets = NULL;
            offsets = (uint32_t*)calloc(1, real_offsets_sz);
            if (!offsets) {
                res = CUDA_ERROR_OUT_OF_MEMORY;
                goto cleanup;
            }

            offsets_sz = real_offsets_sz;

            continue;
        }

        /* For TOOLS_ERROR_SECTION_NOT_FOUND just continue with next function */
        if (toolsResult != TOOLS_ERROR_SECTION_NOT_FOUND) {
            uint32_t num_offsets = 0;
            uint32_t i = 0;

            if (toolsResult != TOOLS_SUCCESS) {
                CU_ERROR_PRINT(("Failed to get cooperative groups instruction offsets for %s (error = %d)\n", func->funcName, toolsResult));
                res = CUDA_ERROR_UNKNOWN;
                goto cleanup;
            }

            /* Found some instr offsets */
            num_offsets = real_offsets_sz / sizeof(*offsets);

            if (num_offsets > 0) {
                func->hasCoopGroupOffsets = 1;

                // TODO: figure out a better way to detect CG usage
                mod->modOpts.usesCooperativeGroups = true;

                res = mcFuncFlagInstrAtOffsets(func, offsets, num_offsets, MC_INSTR_INFO_COOP_GROUPS);
                if (res != CUDA_SUCCESS)
                    goto cleanup;
            }
        }

        func = func->next;
    }

cleanup:
    free(offsets);
    offsets = NULL;

    return res;
}

static CUresult
loadAtomF16InstrLegacyOffsets(MCcontext *mcctx, MCmod *mod)
{
    CUresult res = CUDA_SUCCESS;
    MCfunc *func = NULL;
    uint8_t elfIs64Bit = 0;
    uint32_t *offsets = NULL;
    uint32_t offsets_sz = 256 * sizeof(*offsets);

    if (!mcctx || !mod)
        return CUDA_ERROR_INVALID_VALUE;

    if (!mod->funcList)
        return CUDA_SUCCESS;

    offsets = (uint32_t*)calloc(1, offsets_sz);
    if (!offsets) {
        res = CUDA_ERROR_OUT_OF_MEMORY;
        goto cleanup;
    }

    elfIs64Bit = isELF64((const char*)mod->image);

    for (func = mod->funcList; func;) {
        TOOLSresult toolsResult = TOOLS_SUCCESS;
        uint32_t real_offsets_sz = 0;

        if (elfIs64Bit)
            toolsResult = toolsElf64GetAtomF16InstrOffsets(mod->image,
                                                           func->funcName,
                                                           offsets,
                                                           offsets_sz,
                                                           &real_offsets_sz);
        else
            toolsResult = toolsElf32GetAtomF16InstrOffsets(mod->image,
                                                           func->funcName,
                                                           offsets,
                                                           offsets_sz,
                                                           &real_offsets_sz);

        if (toolsResult == TOOLS_ERROR_OUT_OF_MEMORY) {
            /* Reallocate buffer and try again with same function */
            free(offsets);
            offsets = NULL;
            offsets = (uint32_t*)calloc(1, real_offsets_sz);
            if (!offsets) {
                res = CUDA_ERROR_OUT_OF_MEMORY;
                goto cleanup;
            }

            offsets_sz = real_offsets_sz;

            continue;
        }

        /* For TOOLS_ERROR_SECTION_NOT_FOUND just continue with next function */
        if (toolsResult != TOOLS_ERROR_SECTION_NOT_FOUND) {
            uint32_t num_offsets = 0;
            uint32_t i = 0;

            if (toolsResult != TOOLS_SUCCESS) {
                CU_ERROR_PRINT(("Failed to get atom f16 emulated instruction legacy offsets for %s (error = %d)\n", func->funcName, toolsResult));
                res = CUDA_ERROR_UNKNOWN;
                goto cleanup;
            }

            /* Found some instr offsets */
            num_offsets = real_offsets_sz / sizeof(*offsets);

            if (num_offsets > 0) {
                func->hasLegacyAtomF16Offsets = 1;
                mod->modOpts.usesLegacyAtomF16 = true;

                res = mcFuncFlagInstrAtOffsets(func, offsets, num_offsets, MC_INSTR_INFO_LEGACY_ATOM_F16);
                if (res != CUDA_SUCCESS)
                    goto cleanup;
            }
        }

        func = func->next;
    }

cleanup:
    free(offsets);
    offsets = NULL;

    return res;
}

static CUresult
loadAtomF16InstrRegMap(MCcontext *mcctx, MCmod *mod)
{
    CUresult res = CUDA_SUCCESS;
    MCfunc *func = NULL;
    uint8_t elfIs64Bit = 0;
    uint32_t *offsets = NULL;
    uint32_t *regIds = NULL;
    uint32_t offsets_sz = 256 * sizeof(*offsets);

    // Use offsets_sz for both offsets and regIds since they have the same size

    if (!mcctx || !mod)
        return CUDA_ERROR_INVALID_VALUE;

    if (!mod->funcList)
        return CUDA_SUCCESS;

    offsets = (uint32_t*)calloc(1, offsets_sz);
    regIds = (uint32_t*)calloc(1, offsets_sz);
    if (!offsets || !regIds) {
        res = CUDA_ERROR_OUT_OF_MEMORY;
        goto cleanup;
    }

    elfIs64Bit = isELF64((const char*)mod->image);

    for (func = mod->funcList; func;) {
        TOOLSresult toolsResult = TOOLS_SUCCESS;
        uint32_t real_offsets_sz = 0;

        if (elfIs64Bit)
            toolsResult = toolsElf64GetAtomF16RegMap(mod->image,
                                                     func->funcName,
                                                     offsets,
                                                     regIds,
                                                     offsets_sz,
                                                     &real_offsets_sz);
        else
            toolsResult = toolsElf32GetAtomF16RegMap(mod->image,
                                                     func->funcName,
                                                     offsets,
                                                     regIds,
                                                     offsets_sz,
                                                     &real_offsets_sz);

        if (toolsResult == TOOLS_ERROR_OUT_OF_MEMORY) {
            /* Reallocate buffer and try again with same function */
            free(offsets);
            free(regIds);

            offsets = (uint32_t*)calloc(1, real_offsets_sz);
            regIds = (uint32_t*)calloc(1, real_offsets_sz);
            if (!offsets || !regIds) {
                res = CUDA_ERROR_OUT_OF_MEMORY;
                goto cleanup;
            }

            offsets_sz = real_offsets_sz;

            continue;
        }

        /* For TOOLS_ERROR_SECTION_NOT_FOUND just continue with next function */
        if (toolsResult != TOOLS_ERROR_SECTION_NOT_FOUND) {
            uint32_t num_offsets = 0;
            uint32_t i = 0;

            if (toolsResult != TOOLS_SUCCESS) {
                CU_ERROR_PRINT(("Failed to get atom f16 emulated instruction reg map for %s (error = %d)\n", func->funcName, toolsResult));
                res = CUDA_ERROR_UNKNOWN;
                goto cleanup;
            }

            /* Found some instr offsets */
            num_offsets = real_offsets_sz / sizeof(*offsets);

            if (num_offsets > 0) {
                func->hasAtom16RegMap = 1;
                mod->modOpts.usesAtom16 = true;

                res = mcFuncFlagInstrAtOffsets(func, offsets, num_offsets, MC_INSTR_INFO_ATOM16);
                if (res != CUDA_SUCCESS)
                    goto cleanup;

                res = mcFuncAssignRegIds(func, offsets, num_offsets, regIds);
                if (res != CUDA_SUCCESS)
                    goto cleanup;
            }
        }

        func = func->next;
    }

cleanup:
    free(offsets);
    free(regIds);

    return res;
}

static CUresult
loadWarpWideInstrOffsets(MCcontext *mcctx, MCmod *mod)
{
    CUresult res = CUDA_SUCCESS;
    MCfunc *func = NULL;
    uint8_t elfIs64Bit = 0;
    uint32_t *offsets = NULL;
    uint32_t offsets_sz = 256 * sizeof(*offsets);

    if (!mcctx || !mod)
        return CUDA_ERROR_INVALID_VALUE;

    if (!mod->funcList)
        return CUDA_SUCCESS;

    offsets = (uint32_t*)calloc(1, offsets_sz);
    if (!offsets) {
        res = CUDA_ERROR_OUT_OF_MEMORY;
        goto cleanup;
    }

    elfIs64Bit = isELF64((const char*)mod->image);

    for (func = mod->funcList; func;) {
        TOOLSresult toolsResult = TOOLS_SUCCESS;
        uint32_t real_offsets_sz = 0;

        if (elfIs64Bit)
            toolsResult = toolsElf64GetWarpWideInstrOffsets(mod->image,
                                                            func->funcName,
                                                            offsets,
                                                            offsets_sz,
                                                            &real_offsets_sz);
        else
            toolsResult = toolsElf32GetWarpWideInstrOffsets(mod->image,
                                                            func->funcName,
                                                            offsets,
                                                            offsets_sz,
                                                            &real_offsets_sz);

        if (toolsResult == TOOLS_ERROR_OUT_OF_MEMORY) {
            /* Reallocate buffer and try again with same function */
            free(offsets);
            offsets = NULL;
            offsets = (uint32_t*)calloc(1, real_offsets_sz);
            if (!offsets) {
                res = CUDA_ERROR_OUT_OF_MEMORY;
                goto cleanup;
            }

            offsets_sz = real_offsets_sz;

            continue;
        }

        /* For TOOLS_ERROR_SECTION_NOT_FOUND just continue with next function */
        if (toolsResult != TOOLS_ERROR_SECTION_NOT_FOUND) {
            uint32_t num_offsets = 0;
            uint32_t i = 0;

            if (toolsResult != TOOLS_SUCCESS) {
                CU_ERROR_PRINT(("Failed to get warp wide offsets for %s (error = %d)\n", func->funcName, toolsResult));
                res = CUDA_ERROR_UNKNOWN;
                goto cleanup;
            }

            /* Found some instr offsets */
            num_offsets = real_offsets_sz / sizeof(*offsets);

            if (num_offsets > 0) {
                func->hasWarpWideOffsets = 1;
                mod->modOpts.usesWarpWideInstructions = true;

                res = mcFuncFlagInstrAtOffsets(func, offsets, num_offsets, MC_INSTR_INFO_WARP_WIDE);
                if (res != CUDA_SUCCESS)
                    goto cleanup;
            }
        }

        func = func->next;
    }

cleanup:
    free(offsets);
    offsets = NULL;

    return res;
}

static CUresult
scopeUnitUpdateCnpUsageInfo(MCcontext *mcctx, MCfunc *start, MCfunc *func, void *data)
{
    MCrec *rec = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !func || !start) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // A function 'uses' cnp in memcheck's terms
    // if itself or any of it's callers uses cnp
    start->usesCnp |= func->usesCnp;

    return CUDA_SUCCESS;
}

static CUresult
updateCnpUsageInfo(MCcontext *mcctx, MCmod *mod)
{
    CUresult res = CUDA_SUCCESS;
    MCfunc *func = NULL;

    CU_ASSERT(mcctx);
    CU_ASSERT(mod);

    // Skip internal modules
    if (!mcctx->gvars->options.debugInternals && mod->cumod->internal) {
        return CUDA_SUCCESS;
    }

    // Traverse the module's function list and double-check all that
    // don't have cnp usage set yet
    if (mod->funcList) {
        func = mod->funcList;
        while (func) {
            if (!func->usesCnp) {
                res = scopeFunctor(mcctx, func, &scopeUnitUpdateCnpUsageInfo, NULL);
                if (res != CUDA_SUCCESS) {
                    CU_ERROR_PRINT(("Failed to traverse scope for updating cnp usage info\n"));
                    return res;
                }
            }

            func = func->next;
        }
    }

    return CUDA_SUCCESS;
}

static CUresult
moduleLoadedTrampoline(MCglobals *gvars, const CUtoolsModuleLoaded *params)
{
    MCcontext *mcctx = NULL;
    CUresult res = CUDA_SUCCESS;

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(params->ctx));
    mcUnlock(gvars);

    res = mcContextAddTrampolinePcs(mcctx, params->mod);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to add trampolines PCs to context\n"));
        return res;
    }

    return CUDA_SUCCESS;
}

/* Save the module image (for line information) */
static CUresult
moduleLoaded(MCglobals *gvars, const CUtoolsModuleLoaded *params)
{
    MCcontext *mcctx = NULL;
    MCmod *mod = NULL;
    uint32_t size = (uint32_t) params->cubinSize;
    CUresult res = CUDA_SUCCESS;
    CUmemcheck_error_types modSupportedError = CU_MEMCHECK_ERROR_NONE;

    CU_ASSERT(gvars);
    CU_ASSERT(params);

    CU_TRACE_FUNCTION();

    if (params->moduleVisibility == CU_TOOLS_MODULE_VISIBILITY_HIDDEN_TRAMPOLINE)
        return moduleLoadedTrampoline(gvars, params);

    if (size == ~0U)
        return CUDA_SUCCESS;

    if (params->mod &&
        (params->mod->visibility == CU_MOD_VISIBILITY_HIDDEN_TOOLS)) {
        /* Ignore modules loaded by tools- memcheck in this case. This is to
           avoid registering the functions for internal tools module twice */
        return CUDA_SUCCESS;
    }

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(params->ctx));
    mcUnlock(gvars);

    if (!mcctx) {
        CU_ERROR_PRINT(("we don't know this context\n"));
        return CUDA_ERROR_INVALID_CONTEXT;
    }

    if (!mcContextIsActive(mcctx)) {
        CU_TRACE_PRINT(("Context is not yet initialized\n"));
        return CUDA_SUCCESS;
    }

    if (mcctx->dynamic && mcctx->dynamic->dynState.state == MC_DYN_INITIALIZING) {
        CU_TRACE_PRINT(("Loading the memcheck module\n"));
        return CUDA_SUCCESS;
    }

    res = mcModuleCreate(mcctx, params->mod, &mod, (const void*)params->pCubin, size);
    if (res != CUDA_SUCCESS || !mod) {
        CU_ERROR_PRINT(("Failed to create module\n"));
        goto error;
    }

    res = mcContextAddModule(mcctx, mod);
    if (res != CUDA_SUCCESS || !mod) {
        CU_ERROR_PRINT(("Failed to add module to context\n"));
        goto error;
    }

    // Generate allocation list
    res = addGlobalVariables(mod, params->mod);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("addGlobalVariables failed\n"));
        goto error;
    }

    // Generate the scoping for patching
    res = generateModuleScopes(mcctx, mod);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to generate module scope\n"));
        goto error;
    }

    // Load the list of system-scoped atomic instructions
    res = loadAtomSysInstrOffsets(mcctx, mod);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load system-scoped atom instr offsets\n"));
        goto error;
    }

    // Load the list of cooperative groups instructions
    res = loadCoopGroupsInstrOffsets(mcctx, mod);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load cooperative groups instr offsets\n"));
        goto error;
    }

    // Load the list of legacy atom f16 instructions
    res = loadAtomF16InstrLegacyOffsets(mcctx, mod);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load legacy atom f16 instr offsets\n"));
        goto error;
    }

    // Load the reg map for atom16 instructions
    res = loadAtomF16InstrRegMap(mcctx, mod);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load reg map for atom16 instructions\n"));
        goto error;
    }

    // Load the list of warp wide instructions
    res = loadWarpWideInstrOffsets(mcctx, mod);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load warp wide instr offsets\n"));
        goto error;
    }

    // For user modules that reference CNP, force the R1 usage to be disabled
    if (mod->modOpts.usesCnp) {
        CUtoolsCnpOptions cnpOptions = {0};

        cnpOptions.struct_size = sizeof(cnpOptions);
        cnpOptions.r1HoldsUserStackPointer = CU_TOOLS_CNP_OPTION_DISABLE;

        res = mcctx->gvars->tools.cnp->SetCnpOptions(mcctx->cuctx, &cnpOptions);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to set CNP options\n"));
            goto error;
        }

    }

    // For modules that reference CNP, update the per-function CNP usage info
    if (mod->modOpts.usesCnp) {
        res = updateCnpUsageInfo(mcctx, mod);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to update the cnp usage info\n"));
            goto error;
        }
    }

    // Check if this module is supported by current tool
    res = mcctx->gvars->toolMode.isModuleSupported(mcctx, mod, &modSupportedError);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to do isModuleSupported for toolMode\n"));
        goto error;
    }

    if (CU_MEMCHECK_ERROR_NONE == modSupportedError) {
        res = mcctx->gvars->toolMode.moduleLoadedCallback(mcctx, mod);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to do moduleLoaded for toolMode\n"));
            goto error;
        }
    }
    else {
        // if not, print an error (but only once)
        if (!mcctx->gvars->modUnsupportedWarned) {
            printInternalError(modSupportedError, mcctx->gvars);
            mcctx->gvars->modUnsupportedWarned = true;
        }
    }

    return CUDA_SUCCESS;

error:
    printInternalError(CU_MEMCHECK_ERROR_FAILED_INITIALIZATION, gvars);
    return res;
}

/* Remove the global variables */
static CUresult
moduleUnloadStarting(MCglobals *gvars, const CUtoolsModuleUnloadStarting *params)
{
    CUresult res = CUDA_SUCCESS;
    MCcontext *mcctx;
    MCmod *mod = NULL;

    CU_ASSERT(gvars);
    CU_ASSERT(params);

    CU_TRACE_FUNCTION();

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(params->ctx));
    mcUnlock(gvars);
    if (!mcctx) {
        CU_ERROR_PRINT(("we don't know this context\n"));
        return CUDA_ERROR_INVALID_CONTEXT;
    }

    if (!mcContextIsActive(mcctx)) {
        CU_TRACE_PRINT(("Context is not yet initialized\n"));
        return CUDA_SUCCESS;
    }

    mod = (MCmod *)toolsHashMapFind(mcctx->mods, tHashMapPtrToKey(params->mod));
    if (!mod) {
        // Non-debug compilations will have no module -- return success
        return CUDA_SUCCESS;
    }

    toolsHashMapRemove(mcctx->mods, tHashMapPtrToKey(params->mod), NULL);

    res = mcctx->gvars->toolMode.moduleUnloadedCallback(mcctx, mod);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed in moduleUnloaded callback to toolMode\n"));
        return res;
    }

    // This is only required if the module destroy is initiated by the user.
    // Internally, we only destroy the module if
    // (1) the context is destroyed
    // (2) the context was synchronized and we can cleanup records and
    //     their internal modules
    // (3) if module creation failed
    res = handleSynchronization(mcctx->gvars, mcctx, 0);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to handle ctx synchronization\n"));
        return res;
    }

    res = mcModuleDestroy(mod);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to destroy module\n"));
        return res;
    }

    return CUDA_SUCCESS;
}

static CUresult
globalAllocSetP2PFlags(MCglobals *gvars, CUcontext ctx, uint64_t devvaddr, uint32_t *flags)
{
    CUresult status = CUDA_SUCCESS;
    CUtoolsMemObjHandle hMemObj;
    uint32_t sourceDeviceIdx, allocationDeviceIdx;
    CUdevice sourceDevice, allocationDevice;
    CUtoolsLinkDesc linkDesc;

    status = gvars->tools.memory->MemObjFindByDeviceVAddr(&hMemObj, ctx, devvaddr);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("MemObjFindByDeviceVaddR failed with error code %d\n", status));
        return status;
    }

    status = gvars->tools.memory->MemObjGetSourceDevice(hMemObj, &sourceDeviceIdx);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("MemObjGetSourceDevice failed with error code %d\n", status));
        return status;
    }

    status = gvars->tools.context->CtxGetDevice(ctx, &allocationDeviceIdx);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("CtxGetDevice failed with error code %d\n", status));
        return status;
    }

    /* Early exit if it's not a p2p allocation */
    if (allocationDeviceIdx == sourceDeviceIdx)
        return CUDA_SUCCESS;

    *flags |= CC_ALLOC_FLAG_PEER;

    status = gvars->tools.device->DeviceGet(&sourceDevice, sourceDeviceIdx);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("DeviceGet failed with error code %d\n", status));
        return status;
    }

    status = gvars->tools.device->DeviceGet(&allocationDevice, allocationDeviceIdx);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("DeviceGet failed with error code %d\n", status));
        return status;
    }

    linkDesc.struct_size = sizeof(linkDesc);
    status = gvars->tools.link->GetGpuToGpuLinkDescriptor(allocationDevice, sourceDevice, &linkDesc);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("DeviceGet failed with error code %d\n", status));
        return status;
    }

    if (linkDesc.atomicSupported)
        *flags |= CC_ALLOC_FLAG_PEER_ATOMIC;

    return CUDA_SUCCESS;
}

static CUresult
globalAlloc(MCglobals *gvars, const CUtoolsDeviceMemAlloc *params)
{
    MCcontext *mcctx;
    CUresult status;
    uint32_t flags = 0;
    CCallocVisibility vis = CC_ALLOC_VISIBILITY_CTX;

    CU_ASSERT(gvars);
    CU_ASSERT(params);

    CU_TRACE_FUNCTION();

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(params->ctx));
    mcUnlock(gvars);
    if (!mcctx) {
        CU_ERROR_PRINT(("we don't know this context\n"));
        return CUDA_ERROR_INVALID_CONTEXT;
    }

    if (params->pAllocationDescriptor->ownedByDriver &&
        params->pAllocationDescriptor->allocationName != CU_TOOLS_ALLOCATION_NAME_USER &&
        params->pAllocationDescriptor->allocationName != CU_TOOLS_ALLOCATION_NAME_CNP_LAUNCH_QUEUE_HEAD &&
        params->pAllocationDescriptor->allocationName != CU_TOOLS_ALLOCATION_NAME_GL_INTEROP)
        flags |= CC_ALLOC_FLAG_INTERNAL;

    if (params->pAllocationDescriptor->allocationName == CU_TOOLS_ALLOCATION_NAME_GL_INTEROP)
        flags |= CC_ALLOC_FLAG_GL_INTEROP;

    if (params->pAllocationDescriptor->isUVMManaged)
        flags |= CC_ALLOC_FLAG_MANAGED;

    if (params->pAllocationDescriptor->allocationLocation == CU_MEMORYTYPE_UNIFIED)
        flags |= CC_ALLOC_FLAG_HOST_MAPPED;

    // e.g. on mobile, allocation might reside in sysmem without being host-mapped
    if (params->pAllocationDescriptor->allocationLocation == CU_MEMORYTYPE_HOST &&
        !(params->pAllocationDescriptor->memHostAllocFlags & CU_MEMHOSTALLOC_DEVICEMAP))
        flags |= CC_ALLOC_FLAG_HOST_MAPPED;

    if (params->pAllocationDescriptor->uvmLiteOwnerType == CU_TOOLS_UVM_LITE_OWNER_TYPE_NO_STREAM)
        vis = CC_ALLOC_VISIBILITY_NONE;

    status = globalAllocSetP2PFlags(gvars, params->ctx, params->address, &flags);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to set allocation P2P flags\n"));
        return status;
    }

    status = mcContextAddGlobalAllocation(mcctx, params->address, params->sizeRequested,
                                          flags, vis, NULL);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to add global allocation\n"));
        return status;
    }

    return status;
}

static CUresult
surfObjectCreated(MCglobals *gvars, const CUtoolsSurfObjectCreated *params)
{
    MCcontext *mcctx;
    CUresult status;
    uint32_t flags = 0;

    CU_ASSERT(gvars);
    CU_ASSERT(params);

    CU_TRACE_FUNCTION();

    if (!params->bDirectAccess) {
        CU_TRACE_PRINT(("No direct dptr access\n"));
        return CUDA_SUCCESS;
    }

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(params->ctx));
    mcUnlock(gvars);
    if (!mcctx) {
        CU_ERROR_PRINT(("we don't know this context\n"));
        return CUDA_ERROR_INVALID_CONTEXT;
    }

    status = mcContextAddGlobalAllocation(mcctx, params->dPtr, params->size,
                                          flags, CC_ALLOC_VISIBILITY_CTX, NULL);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to add global allocation\n"));
        return status;
    }

    return status;
}


/* When a stream is created, check for whether the context is active.  If it is,
   then add bindless surface memory to the white list.  If there is no active
   context at the time, then add the stream to a deferred list that will be looked
   at after context is created. */
static CUresult
streamCreated(MCglobals *gvars, const CUtoolsStreamCreated *params)
{
    MCcontext *mcctx;
    TOOLSresult tres = TOOLS_SUCCESS;
    CUresult status = CUDA_SUCCESS;

    CU_ASSERT(gvars);
    CU_ASSERT(params);
    CU_TRACE_FUNCTION();

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(params->ctx));
    mcUnlock(gvars);

    if (!mcctx) {
        CU_ERROR_PRINT(("we don't know this context\n"));
        return CUDA_ERROR_INVALID_CONTEXT;
    }

    /* If context is not active, save away stream which will get examined
       when context creation is complete. */
    if (!mcContextIsActive(mcctx)) {
        if (!mcctx->streamList) {
            mcctx->streamList = toolsListNew();
            if (!mcctx->streamList) {
                CU_ERROR_PRINT(("Failed to create stream list\n"));
                return CUDA_ERROR_OUT_OF_MEMORY;
            }
        }
        tres = toolsListAppend(mcctx->streamList, params->stream);
        if (tres != TOOLS_SUCCESS) {
            CU_ERROR_PRINT(("Failed when appending cloned handle to list\n"));
            return CUDA_ERROR_UNKNOWN;
        }
        CU_TRACE_PRINT(("Added stream=%p to streamList, size now=%d, state=%d\n",
                        params->stream, toolsListSize(mcctx->streamList), mcctx->state));
        return CUDA_SUCCESS;
    }

    status = mcContextAddSurfaceMemory(mcctx, params->stream);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to add surface memory to white list\n"));
        return status;
    }

    return CUDA_SUCCESS;

}

static CUresult
streamDestroyStarting(MCglobals *gvars, const CUtoolsStreamDestroyStarting *params)
{
    MCcontext *mcctx = NULL;
    CUresult status = CUDA_SUCCESS;

    CU_ASSERT(gvars);
    CU_ASSERT(params);
    CU_TRACE_FUNCTION();

    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(params->ctx));
    if (!mcctx) {
        CU_ERROR_PRINT(("we don't know this context\n"));
        return CUDA_ERROR_INVALID_CONTEXT;
    }

    // Ignore contexts we don't manage (such as graphics dummy contexts)
    if (!mcContextIsValid(mcctx))
        return CUDA_SUCCESS;
   
    status = mcContextRemoveSurfaceMemory(mcctx, params->stream);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to remove surface memory from white list\n"));
        return status;
    }

    return CUDA_SUCCESS;
}


static CUresult
globalFree(MCglobals *gvars, const CUtoolsDeviceMemFree *params)
{
    MCcontext *mcctx;
    CUresult status;

    CU_ASSERT(gvars);
    CU_ASSERT(params);

    CU_TRACE_FUNCTION();

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(params->ctx));
    mcUnlock(gvars);
    if (!mcctx) {
        CU_ERROR_PRINT(("we don't know this context\n"));
        return CUDA_ERROR_INVALID_CONTEXT;
    }

    status = mcContextRemoveGlobalAllocation(mcctx, params->address);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to remove global allocation\n"));
        return status;
    }

    return status;
}

static CUresult
surfObjectDestroy(MCglobals *gvars, const CUtoolsSurfObjectDestroy *params)
{
    MCcontext *mcctx;
    CUresult status;

    CU_ASSERT(gvars);
    CU_ASSERT(params);

    CU_TRACE_FUNCTION();

    if (!params->bDirectAccess) {
        CU_TRACE_PRINT(("No direct dptr access\n"));
        return CUDA_SUCCESS;
    }

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(params->ctx));
    mcUnlock(gvars);
    if (!mcctx) {
        CU_ERROR_PRINT(("we don't know this context\n"));
        return CUDA_ERROR_INVALID_CONTEXT;
    }

    status = mcContextRemoveGlobalAllocation(mcctx, params->dPtr);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to remove global allocation\n"));
        return status;
    }

    return status;
}

static CUresult
hostAlloc(MCglobals *gvars, const CUtoolsHostMemAlloc *params)
{
    MCcontext *mcctx;
    CUresult status;
    void *devptr;
    uint32_t flags = 0;
    CCallocVisibility vis = CC_ALLOC_VISIBILITY_CTX;

    CU_ASSERT(gvars);
    CU_ASSERT(params);

    CU_TRACE_FUNCTION();

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(params->ctx));
    mcUnlock(gvars);
    if (!mcctx) {
        CU_DEBUG_PRINT(("Ignoring allocations from unknown contexts (syscall?)\n"));
        /* Unfortunately, syscall loads modules as part of context
           creation before we have gotten the callback from
           cuiCtxCreate(). The simplest fix for now is to ignore
           these.

           Was return CUDA_ERROR_INVALID_CONTEXT; */
        return CUDA_SUCCESS;
    }

    // Return if host allocation is not device-mapped
    if (!(params->pAllocationDescriptor->memHostAllocFlags & CU_MEMHOSTALLOC_DEVICEMAP)) {
        return CUDA_SUCCESS;
    }

    if (!params->address)
        return CUDA_SUCCESS;

    status = mcctx->gvars->tools.memory->MemHostGetDevicePointer(mcctx->cuctx, UINT2PTR(params->address), &devptr);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("\n"));
        printInternalError(CU_MEMCHECK_ERROR_DEVICE_MEM_ACCESS_FAILED,
                           gvars);
        return CUDA_ERROR_UNKNOWN;
    }

    flags |= CC_ALLOC_FLAG_HOST_PINNED;

    if (params->pAllocationDescriptor->allocationLocation == CU_MEMORYTYPE_HOST ||
        params->pAllocationDescriptor->allocationLocation == CU_MEMORYTYPE_UNIFIED)
        flags |= CC_ALLOC_FLAG_HOST_MAPPED;

    if (params->pAllocationDescriptor->allocationName == CU_TOOLS_ALLOCATION_NAME_GL_INTEROP)
        flags |= CC_ALLOC_FLAG_GL_INTEROP;

    if (params->pAllocationDescriptor->ownedByDriver &&
        params->pAllocationDescriptor->allocationName != CU_TOOLS_ALLOCATION_NAME_USER &&
        params->pAllocationDescriptor->allocationName != CU_TOOLS_ALLOCATION_NAME_CNP_LAUNCH_QUEUE_HEAD &&
        params->pAllocationDescriptor->allocationName != CU_TOOLS_ALLOCATION_NAME_GL_INTEROP)
        flags |= CC_ALLOC_FLAG_INTERNAL;

    if (params->pAllocationDescriptor->isUVMManaged)
        flags |= CC_ALLOC_FLAG_MANAGED;

    if (params->pAllocationDescriptor->allocationLocation == CU_MEMORYTYPE_HOST &&
        (uint64_t)(uintptr_t)devptr != params->address)
        flags |= CC_ALLOC_FLAG_HOST_REGISTERED;

    if (params->pAllocationDescriptor->uvmLiteOwnerType == CU_TOOLS_UVM_LITE_OWNER_TYPE_NO_STREAM)
        vis = CC_ALLOC_VISIBILITY_NONE;

    status = mcContextAddGlobalAllocation(mcctx, (uint64_t)(uintptr_t)devptr,
                                          params->sizeRequested, flags, vis, NULL);
    if (status != CUDA_SUCCESS)
        CU_ERROR_PRINT(("Failed to add global allocation\n"));

    return status;
}

static CUresult
hostFree(MCglobals *gvars, const CUtoolsHostMemFree *params)
{
    MCcontext *mcctx;
    CUresult status;
    void *devptr;

    CU_ASSERT(gvars);
    CU_ASSERT(params);

    CU_TRACE_FUNCTION();

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(params->ctx));
    mcUnlock(gvars);
    if (!mcctx) {
        CU_ERROR_PRINT(("we don't know this context\n"));
        return CUDA_ERROR_INVALID_CONTEXT;
    }

    // Return if host allocation is not device-mapped
    if (!(params->memHostAllocFlags & CU_MEMHOSTALLOC_DEVICEMAP))
        return CUDA_SUCCESS;

    if (!params->address)
        return CUDA_SUCCESS;

    status = gvars->tools.memory->MemHostGetDevicePointer(mcctx->cuctx, UINT2PTR(params->address), &devptr);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("\n"));
        printInternalError(CU_MEMCHECK_ERROR_DEVICE_MEM_ACCESS_FAILED,
                           gvars);
        return CUDA_ERROR_UNKNOWN;
    }

    status = mcContextRemoveGlobalAllocation(mcctx, (uint64_t)(uintptr_t)devptr);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to remove global allocation\n"));
        return status;
    }

    return status;
}

static CUresult
invalICache(CUctx* ctx)
{
    CUnvCurrent *nvCurrent = NULL;

    CU_TRACE_FUNCTION();

    if (!ctx)
        return CUDA_SUCCESS;

    // invalidate the icache
    streamBeginPush(ctx->streamManager, CU_CHANNEL_COMPUTE,
                    ctx->barrierStream, &nvCurrent, NULL);

    nvCurrent = ctx->device->hal.invalCachesNoWfi(nvCurrent, CU_MEM_FLAGS_CACHE_TYPE_INSTRUCTIONS);

    streamEndPush(ctx->barrierStream, nvCurrent, NULL);

    return CUDA_SUCCESS;
}

typedef struct CCSUpatchCreateData_st CCSUpatchCreateData;

struct CCSUpatchCreateData_st {
    uint64_t streamId;
    CUtoolsStreamHandle stream;
    MCrec *outRec;
};

static CUresult
scopeUnitPatchCreate(MCcontext *mcctx, MCfunc *start, MCfunc *func, void *data)
{
    CUresult status = CUDA_SUCCESS;
    MCrec *rec = NULL;
    CCSUpatchCreateData *d = (CCSUpatchCreateData *)data;
    MCrec **prec = &d->outRec;
    uint64_t streamId = d->streamId;

    CU_TRACE_FUNCTION();

    if (!mcctx || !func || !prec || !start) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    rec = mcContextGetPatchByFunc(mcctx, func);

    if (!rec) {
        /* Skip internal kernels. */
        if (!mcctx->gvars->options.debugInternals && func->cufunc->mod->internal) {
            CU_DEBUG_PRINT(("Skipping internal kernels\n"));
            return CUDA_SUCCESS;
        }

        status = mcRecCreate(mcctx, func, d->stream, streamId, &rec);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("createPatchEntry failed\n"));
            goto error;
        }

        mcContextAddPatch(mcctx, rec);
        rec->state = MC_PATCH_STATE_INITIALIZED;
    }
    else
        CU_TRACE_PRINT(("Found existing patch for function : %s\n",
                        rec->func->funcName));

    if (func == start)
        *prec = rec;

    return status;

error:
    CU_ERROR_PRINT(("Failed to create patch for : %s\n", func->funcName));
    return status;
}

static CUresult
scopePatchCreate(MCcontext *mcctx, MCfunc *func, CUtoolsStreamHandle stream, uint64_t streamId, MCrec **pRec)
{
    CUresult res = CUDA_SUCCESS;
    CCSUpatchCreateData d = {0};

    d.streamId = streamId;
    d.stream = stream;
    d.outRec = NULL;

    if (!pRec) {
        CU_TRACE_PRINT(("Invalid args. Nothing to do\n"));
        return CUDA_SUCCESS;
    }

    res = scopeFunctor(mcctx, func, &scopeUnitPatchCreate, (void*)&d);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed in creating scope unit patches\n"));
        return res;
    }

    *pRec = d.outRec;
    return CUDA_SUCCESS;
}

static CUresult
createPatchAndLaunch(MCcontext *mcctx, MCfunc *func, uint64_t gridid, CUtoolsStreamHandle stream, uint64_t streamId)
{
    CUresult status = CUDA_SUCCESS;
    MCrec *rec = NULL;
    MClaunch *launch = NULL;

    launch = mcLaunchGetInContext(mcctx, gridid);

    if (launch) {
        CU_TRACE_PRINT(("Found existing launch for gridid:%llu\n", gridid));
        return CUDA_SUCCESS;
    }

    status = scopePatchCreate(mcctx, func, stream, streamId, &rec);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("scopePatchCreate failed\n"));
        return status;
    }

    if (!rec) {
        CU_TRACE_PRINT(("No rec returned. Most likely internal launch. Skipping\n"));
        return CUDA_SUCCESS;
    }

    status = mcLaunchCreate(rec, gridid, streamId, &launch);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("createLaunchEntry failed\n"));
        return status;
    }
    mcLaunchAddToContext(mcctx, launch);

    /* Do the halo memMap update early as from this point on
       we may do calls to do mapping  */
    if (NULL != mcctx->haloContext) {
        /* Nuke the old mappings */
        mcctx->dev->haloClient->unmapMemory(mcctx->dev);
    }

    return status;
}

/* Prepare for a function launch by allocating data structures on device and patching instructions */
static CUresult
OnLaunchBegin(MCglobals *gvars,
              CUcontext ctx,
              CUtoolsStreamHandle stream,
              CUfunction func,
              uint64_t gridId)
{
    MCcontext *mcctx;
    CUresult status = CUDA_SUCCESS;
    TOOLSresult toolsResult = TOOLS_SUCCESS;
    MClaunch *launch = NULL;
    MCmod *mod = NULL;
    MCfunc *mcfunc = NULL;
    MCtlsEntry *tlsData = NULL;
    uint64_t streamId = 0;

    CU_ASSERT(gvars);

    CU_TRACE_FUNCTION();

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(ctx));
    mcUnlock(gvars);
    if (!mcctx) {
        CU_ERROR_PRINT(("we don't know this context\n"));
        status = CUDA_ERROR_INVALID_CONTEXT;
        goto error;
    }

    tlsData = (MCtlsEntry*)cuosTlsGetValue(gvars->tlsEntry);
    if (!tlsData) {
        CU_ERROR_PRINT(("Missing tlsData\n"));
        status = CUDA_ERROR_UNKNOWN;
        goto error;
    }

    /* Acquire writer lock at start of launch callback sequence */
    if (tlsData->launchStack == 0) {
        toolsResult = toolsRWLockAcquireWriteBlocking(&mcctx->rwlock);
        if (TOOLS_SUCCESS != toolsResult) {
            CU_ERROR_PRINT(("Failed to acquire ctx rwlock\n"));
            status = CUDA_ERROR_UNKNOWN;
            goto error;
        }
    }

    /* Increase number of recursive launches once we have the lock */
    ++tlsData->launchStack;

    if (!mcContextIsActive(mcctx)) {
        CU_TRACE_PRINT(("Context is not yet initialized\n"));
        return CUDA_SUCCESS;
    }

    launch = mcLaunchGetInContext(mcctx, gridId);

    if (launch) {
        CU_TRACE_PRINT(("Found existing launch for gridid:%llu\n", gridId));
        return CUDA_SUCCESS;
    }

    if (!mcctx->gvars->options.debugInternals && func->mod->internal) {
        CU_DEBUG_PRINT(("Skipping internal kernels\n"));
        return CUDA_SUCCESS;
    }

    mod = (MCmod *)toolsHashMapFind(mcctx->mods, tHashMapPtrToKey(func->mod));
    if (!mod) {
        CU_ERROR_PRINT(("Cannot find module for launch\n"));
        status = CUDA_ERROR_UNKNOWN;
        goto error;
    }

    mcfunc = (MCfunc *)toolsHashMapFind(mod->funcs, tHashMapPtrToKey(func));
    if (!mcfunc) {
        CU_ERROR_PRINT(("Cannot get mcfunc for launch\n"));
        status = CUDA_ERROR_UNKNOWN;
        goto error;
    }

    status = mcctx->gvars->tools.context->StreamGetIdEx(mcctx->cuctx, stream, &streamId);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Cannot get streamId for launch stream\n"));
        status = CUDA_ERROR_UNKNOWN;
        goto error;
    }

    status = createPatchAndLaunch(mcctx, mcfunc, gridId, stream, streamId);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("createPatchAndLaunch failed\n"));
        goto error;
    }

    return status;

error:
    CU_ERROR_PRINT(("memcheck: function setup failed (%d)\n", status));
    return status;
}

static CUresult
launchBeginCallback(MCglobals *gvars,
                    const CUtoolsLaunchBegin *params)
{
    CU_ASSERT(params);

    CU_TRACE_FUNCTION();

    return OnLaunchBegin(gvars, params->ctx, params->stream, params->func, params->gridId);
}

static CUresult
OnLaunchEnd(MCglobals *gvars,
            CUcontext ctx)
{
    MCcontext *mcctx = NULL;
    MCtlsEntry *tlsData = NULL;
    TOOLSresult toolsResult = TOOLS_SUCCESS;

    CU_ASSERT(gvars);

    CU_TRACE_FUNCTION();

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(ctx));
    mcUnlock(gvars);

    if (!mcctx) {
        CU_ERROR_PRINT(("we don't know this context\n"));
        return CUDA_ERROR_INVALID_CONTEXT;
    }

    tlsData = (MCtlsEntry*)cuosTlsGetValue(gvars->tlsEntry);
    if (!tlsData) {
        CU_ERROR_PRINT(("Missing tlsData\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* Decrement recursive launch count */
    --tlsData->launchStack;

    /* Release writer lock at end of launch callback sequence */
    if (tlsData->launchStack == 0) {
        toolsResult = toolsRWLockReleaseWrite(&mcctx->rwlock);
        if (TOOLS_SUCCESS != toolsResult) {
            CU_ERROR_PRINT(("Failed to release ctx writer lock\n"));
            return CUDA_ERROR_UNKNOWN;
        }
    }

    return CUDA_SUCCESS;
}

static CUresult
launchEndCallback(MCglobals *gvars,
                  const CUtoolsLaunchEnd *params)
{
    CU_ASSERT(params);

    CU_TRACE_FUNCTION();

    return OnLaunchEnd(gvars, params->ctx);
}

typedef struct CCSUpatchClearData_st CCSUpatchClearData;
struct CCSUpatchClearData_st {
    uint64_t streamId;
    uint32_t resetFuncFlags;
    CUtoolsStreamHandle stream;
};

static CUresult
scopeUnitPatchClear(MCcontext *mcctx, MCfunc *start, MCfunc *func, void *data)
{
    MCrec *rec = NULL;
    CCSUpatchClearData *d = (CCSUpatchClearData*)data;

    if (!mcctx)
        return CUDA_ERROR_UNKNOWN;

    if (!func)
        return CUDA_SUCCESS;

    rec = mcContextGetPatchByFunc(mcctx, func);
    return mcRecClearPatch(rec, d->stream, d->streamId, d->resetFuncFlags);
}

static CUresult
scopePatchClear(MCcontext *mcctx, MCfunc *func, CUtoolsStreamHandle stream, uint64_t streamId, uint32_t resetFuncFlags)
{
    CCSUpatchClearData data = {0};

    data.streamId = streamId;
    data.resetFuncFlags = resetFuncFlags;
    data.stream = stream;

    return scopeFunctor(mcctx, func, &scopeUnitPatchClear, (void*)&data);
}

static CUresult
markAllPatchesDirty(MCcontext *mcctx)
{
    MCrec *rec = NULL;
    CU_TRACE_FUNCTION();
    mcCtxLock(mcctx);
    for (rec = mcctx->patchList; rec; rec = rec->next) {
        rec->state = MC_PATCH_STATE_DIRTY;
    }
    mcCtxUnlock(mcctx);
    return CUDA_SUCCESS;
}

static CUresult
queryLaunchChanged(MCrec *rec, scopeLaunchProps *props)
{
    CUresult res = CUDA_SUCCESS;
    CUtoolsFunctionLaunchConfig config;

    if (!rec || !props) {
        CU_ERROR_PRINT(("Invalid argument\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    config.struct_size = sizeof(config);

    if (rec->state == MC_PATCH_STATE_DIRTY ||
        rec->state == MC_PATCH_STATE_DIRTY_SYNC) {
        CU_TRACE_PRINT(("Patch already marked dirty\n"));
        props->state = MC_PATCH_STATE_DIRTY_SYNC;
        return CUDA_SUCCESS;
    }

    if (rec->state != MC_PATCH_STATE_INITIALIZED &&
        rec->state != MC_PATCH_STATE_ACTIVE) {
        CU_TRACE_PRINT(("Patch is inactive. Skipping shmem update check\n"));
        return CUDA_SUCCESS;
    }

    res = rec->tools->module->FunctionGetLaunchConfig(rec->func->cufunc, &config);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read Launch Config\n"));
        return res;
    }

    if (config.totalSharedMemPerBlock != rec->config.totalSharedMemPerBlock) {
        CU_TRACE_PRINT(("Shared memory changed. Resetting launch parameters\n"));
        rec->config.totalSharedMemPerBlock = config.totalSharedMemPerBlock;
        if (rec->state == MC_PATCH_STATE_ACTIVE) {
            rec->state = MC_PATCH_STATE_DIRTY_SYNC;
            props->state = MC_PATCH_STATE_DIRTY_SYNC;
        }
        else if (rec->state != MC_PATCH_STATE_INITIALIZED) {
            rec->state = MC_PATCH_STATE_DIRTY;
            props->state = MC_PATCH_STATE_DIRTY_SYNC;
        }
    }

    if (rec->config.totalSharedMemPerBlock < props->shmem) {
        CU_TRACE_PRINT(("Shared memory changed at entry."
                        "Resetting launch parameters\n"));
        rec->config.totalSharedMemPerBlock = props->shmem;
        if (props->isActive)
            props->state = MC_PATCH_STATE_DIRTY_SYNC;
        else
            props->state = MC_PATCH_STATE_DIRTY;

        if (rec->state != MC_PATCH_STATE_INITIALIZED)
            rec->state = MC_PATCH_STATE_DIRTY;
    }

    return res;
}

static CUresult
scopeUnitQueryLaunchChanged(MCcontext *mcctx, MCfunc *start, MCfunc *func, void *data)
{
    scopeLaunchProps *props = NULL;
    MCrec *scope = NULL;

    if (!mcctx || !func || !data)
        return CUDA_ERROR_UNKNOWN;

    props = (scopeLaunchProps*)data;
    scope = mcContextGetPatchByFunc(mcctx, func);
    if (!scope) {
        CU_ERROR_PRINT(("No patch found for :%s\n", func->funcName));
        return CUDA_ERROR_UNKNOWN;
    }

    return queryLaunchChanged(scope, props);
}

static CUresult
scopeQueryLaunchChanged(MCrec *rec)
{
    scopeLaunchProps props = {0};
    CUresult res = CUDA_SUCCESS;
    CUtoolsFunctionLaunchConfig config;

    CU_TRACE_FUNCTION();

    if (!rec) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    props.state = rec->state;
    props.isActive = !!(rec->state == MC_PATCH_STATE_ACTIVE ||
                        rec->state == MC_PATCH_STATE_DIRTY_SYNC);

    /* Do a special query for the first one. */
    config.struct_size = sizeof(config);
    res = rec->tools->module->FunctionGetLaunchConfig(rec->func->cufunc, &config);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read Launch Config\n"));
        return res;
    }

    props.shmem = config.totalSharedMemPerBlock;

    if (props.shmem != rec->config.totalSharedMemPerBlock) {
        CU_TRACE_PRINT(("Shared memory changed. Resetting launch parameters\n"));
        rec->config.totalSharedMemPerBlock = config.totalSharedMemPerBlock;
        if (rec->state == MC_PATCH_STATE_ACTIVE) {
            rec->state = MC_PATCH_STATE_DIRTY_SYNC;
            props.state = MC_PATCH_STATE_DIRTY_SYNC;
        }
        else if (rec->state != MC_PATCH_STATE_INITIALIZED) {
            rec->state = MC_PATCH_STATE_DIRTY;
            props.state = MC_PATCH_STATE_DIRTY_SYNC;
        }
    }

    res = scopeFunctor(rec->context, rec->func, &scopeUnitQueryLaunchChanged, &props);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Scope query failed \n"));
        return res;
    }

    if (rec->state != MC_PATCH_STATE_DIRTY_SYNC && rec->state != MC_PATCH_STATE_INITIALIZED)
        rec->state = props.state;

    return CUDA_SUCCESS;
}

static CUresult
resetLmem(MCcontext *mcctx)
{
    CUresult res = CUDA_SUCCESS;
    void *lmemHost = NULL;
    size_t lmemSize = 0;

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Zero-out lmem in case debugger is running. This was bug 896398.
    // Cant use the mapping anymore as the size of lmem has gone up
    // So, instead we do a slow memcopy of the shadow lmem
    lmemSize = (size_t)memobjGetSize(mcctx->cuctx->lmem);
    lmemHost = calloc (1, lmemSize);
    res = cuiMemcpyHtoD(mcctx->cuctx,
                        mcctx->cuctx->lmem,
                        0,
                        lmemHost,
                        lmemSize,
                        mcctx->cuctx->barrierStream,
                        CUI_MEMCPY_SYNCHRONOUS,
                        NULL);
    free(lmemHost);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to reset lmem\n"));
    }
    return res;
}

static CUresult
scopeUnitRecomputeLaunch(MCcontext *mcctx, MCfunc *start, MCfunc *func, void *data)
{
    scopeLaunchProps *props = NULL;
    MCrec *rec = NULL;

    if (!mcctx || !func || !data)
        return CUDA_ERROR_UNKNOWN;

    props = (scopeLaunchProps*)data;
    rec = mcContextGetPatchByFunc(mcctx, func);
    if (!rec) {
        CU_ERROR_PRINT(("No patch found for :%s\n", func->funcName));
        return CUDA_ERROR_UNKNOWN;
    }

    if (rec->config.totalSharedMemPerBlock < props->shmem) {
        CU_DEBUG_PRINT(("Bumping shmem to :%u from %u for %s\n",
                        props->shmem, rec->config.totalSharedMemPerBlock,
                        rec->func->funcName));
        rec->config.totalSharedMemPerBlock = props->shmem;
    }

    return CUDA_SUCCESS;
}

static CUresult
scopePatchRecomputeLaunch(MCcontext *mcctx, MCrec *rec)
{
    scopeLaunchProps props = {0};
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!rec) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    props.state = rec->state;
    props.isActive = !!(rec->state == MC_PATCH_STATE_ACTIVE || rec->state == MC_PATCH_STATE_DIRTY_SYNC);
    props.shmem = rec->config.totalSharedMemPerBlock;

    res = scopeFunctor(rec->context, rec->func, &scopeUnitRecomputeLaunch, &props);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Scope functor to recompute launches failed \n"));
        return res;
    }

    return CUDA_SUCCESS;
}

static CUresult
scopeUnitPatchSetup(MCcontext *mcctx, MCfunc *start, MCfunc *func, void *data)
{
    CUresult status = CUDA_SUCCESS;
    CUtoolsStreamHandle stream = NULL;
    MCrec *rec = NULL;

    if (!mcctx || !func || !data) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    rec = mcContextGetPatchByFunc(mcctx, func);
    if (!rec) {
        CU_ERROR_PRINT(("Function doesn't have patch setup.\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (rec->state == MC_PATCH_STATE_ACTIVE) {
        CU_TRACE_PRINT(("Patch is already active\n"));
        return CUDA_SUCCESS;
    }

    if (rec->state != MC_PATCH_STATE_INITIALIZED) {
        CU_ERROR_PRINT(("Trying to patch an active patch\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    stream = (CUtoolsStreamHandle)data;

    status = mcRecCreateHostFuncCopy(rec);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("createHostFuncCopy failed\n"));
        goto error;
    }
    status = mcctx->instMgr->createAllocs(mcctx->instMgr, rec);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("createAllocs failed\n"));
        goto error;
    }
    status = mcRecCreateDevicePatch(rec);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("createDevicePatch failed\n"));
        goto error;
    }

    status = mcctx->gvars->toolMode.createPatchHelpers(mcctx, rec, stream);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("createPatchHelpers failed\n"));
        goto error;
    }
    status = mcctx->instMgr->createPatch(mcctx->instMgr, rec);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("createPatch failed\n"));
        goto error;
    }

    status = mcRecDownloadPatch(rec, stream);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("downloadPatch failed\n"));
        goto error;
    }

    status = mcRecDownloadFunc(rec, stream);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("downloadFunc failed\n"));
        goto error;
    }

    status = mcContextAddPatchToMap(rec->context, rec);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("mcContextAddPatchToMap failed\n"));
        goto error;
    }

    if (rec->patchEntry && rec->gvars->toolMode.hasPrologue(rec->context)) {
        CU_TRACE_PRINT(("Prologue found. Updating launch PC to :0x%" PRIx64 "\n",
                        rec->patchEntry));
        status = rec->tools->module->FunctionSetLaunchPcHostAndDevice(rec->func->cufunc,
                 rec->patchEntry);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to update launch  PC\n"));
            return status;
        }
    }

    rec->state = MC_PATCH_STATE_ACTIVE;

    CU_TRACE_PRINT(("patch setup complete for %s\n", rec->func->funcName));

    return status;

error:
    CU_ERROR_PRINT(("Failed to create patch for %s\n", rec->func->funcName));
    return status;
}

static CUresult
scopePatchSetup(MCcontext *mcctx, MCfunc *start, CUtoolsStreamHandle stream)
{
    return scopeFunctor(mcctx, start, &scopeUnitPatchSetup, stream);
}

static CUresult
scopeUnitNeedsSync(MCcontext *mcctx, MCfunc *first, MCfunc *func, void *data)
{
    MCrec *rec = NULL;
    uint32_t *needsSync = NULL;

    if (!mcctx || !func || !data)
        return CUDA_ERROR_UNKNOWN;

    rec = mcContextGetPatchByFunc(mcctx, func);
    if (!rec) {
        CU_ERROR_PRINT(("Could not find patch for :%s\n", func->funcName));
        return CUDA_ERROR_UNKNOWN;
    }

    needsSync = (uint32_t*)data;

    if (rec->state == MC_PATCH_STATE_DIRTY ||
        rec->state == MC_PATCH_STATE_DIRTY_SYNC)
        (*needsSync)++;

    return CUDA_SUCCESS;
}

static uint32_t
scopeNeedsSync(MCrec *rec)
{
    CUresult res = CUDA_SUCCESS;
    uint32_t needsSync = 0;

    CU_TRACE_FUNCTION();

    if (!rec) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return 0;
    }

    res = scopeFunctor(rec->context, rec->func, &scopeUnitNeedsSync, &needsSync);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to find sync information in scope for :%s\n", rec->func->funcName));
        return 0;
    }

    if (needsSync) {
        CU_TRACE_PRINT(("In scope for %s, found %u recs needing sync\n",
                        rec->func->funcName, needsSync));
    }

    return needsSync;
}

static CUresult
scopeUnitHasActive(MCcontext *mcctx, MCfunc *first, MCfunc *func, void *data)
{
    MCrec *rec = NULL;
    uint32_t *hasActive = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !func || !data)
        return CUDA_ERROR_UNKNOWN;

    rec = mcContextGetPatchByFunc(mcctx, func);
    if (!rec) {
        CU_ERROR_PRINT(("Could not find patch for :%s\n", func->funcName));
        return CUDA_ERROR_UNKNOWN;
    }

    hasActive = (uint32_t*)data;

    if (rec->state == MC_PATCH_STATE_ACTIVE)
        (*hasActive)++;

    return CUDA_SUCCESS;
}

static uint32_t
scopeHasActive(MCrec *rec)
{
    CUresult res = CUDA_SUCCESS;
    uint32_t hasActive = 0;

    CU_TRACE_FUNCTION();

    if (!rec) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    res = scopeFunctor(rec->context, rec->func, &scopeUnitHasActive, &hasActive);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to find has active in scope for :%s\n", rec->func->funcName));
        return 0;
    }

    if (hasActive) {
        CU_TRACE_PRINT(("In scope for %s found %u active recs\n",
                        rec->func->funcName, hasActive));
    }

    return hasActive;
}

static CUresult
scopeUnitNeedsPatchClear(MCcontext *mcctx, MCfunc *first, MCfunc *func, void *data)
{
    MCrec *rec = NULL;
    uint32_t *needsPatchClear = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !func || !data)
        return CUDA_ERROR_UNKNOWN;

    needsPatchClear = (uint32_t*)data;

    rec = mcContextGetPatchByFunc(mcctx, func);
    if (!rec) {
        (*needsPatchClear)++;
        return CUDA_SUCCESS;
    }

    if (rec->state != MC_PATCH_STATE_ACTIVE &&
        rec->state != MC_PATCH_STATE_INITIALIZED)
        (*needsPatchClear)++;

    return CUDA_SUCCESS;
}

static uint32_t
scopeNeedsPatchClear(MCrec *rec)
{
    CUresult res = CUDA_SUCCESS;
    uint32_t needsPatchClear = 0;

    CU_TRACE_FUNCTION();

    if (!rec) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return 0;
    }

    res = scopeFunctor(rec->context, rec->func, &scopeUnitNeedsPatchClear, &needsPatchClear);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to find has active in scope for :%s\n", rec->func->funcName));
        return 0;
    }

    if (needsPatchClear) {
        CU_TRACE_PRINT(("In scope for %s found %u recs needing a regen",
                        rec->func->funcName, needsPatchClear));
    }

    return needsPatchClear;
}

static CUresult
scopeUnitNeedsPatchGen(MCcontext *mcctx, MCfunc *first, MCfunc *func, void *data)
{
    MCrec *rec = NULL;
    uint32_t *needsPatchGen = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !func || !data)
        return CUDA_ERROR_UNKNOWN;

    needsPatchGen = (uint32_t*)data;

    rec = mcContextGetPatchByFunc(mcctx, func);
    if (!rec) {
        CU_ERROR_PRINT(("Failed to find patch\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (rec->state == MC_PATCH_STATE_INITIALIZED)
        (*needsPatchGen)++;

    return CUDA_SUCCESS;
}

static uint32_t
scopeNeedsPatchGen(MCrec *rec)
{
    CUresult res = CUDA_SUCCESS;
    uint32_t needsPatchGen = 0;

    CU_TRACE_FUNCTION();

    if (!rec) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return 0;
    }

    res = scopeFunctor(rec->context, rec->func, &scopeUnitNeedsPatchGen, &needsPatchGen);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to find has active in scope for :%s\n", rec->func->funcName));
        return 0;
    }

    if (needsPatchGen) {
        CU_TRACE_PRINT(("In scope for %s found %u recs needing a regen",
                        rec->func->funcName, needsPatchGen));
    }

    return needsPatchGen;
}

static CUresult
OnAfterSyscallSetup(MCglobals *gvars,
                    CUcontext ctx,
                    CUtoolsStreamHandle stream,
                    uint64_t gridId)
{
    MCcontext *mcctx;
    MCrec     *rec;
    CUresult status = CUDA_SUCCESS;
    MClaunch *launch;
    uint32_t scopeDirty = 0;
    uint32_t scopeActive = 0;
    uint32_t scopeRegen = 0;
    uint32_t scopeClear = 0;
    MCcontextState ctxState = MC_CONTEXT_STATE_NONE;
    uint64_t streamId = 0;
    CCfilterMatch filterMatch = CC_FILTER_MATCH_TEST;
    uint32_t resetFuncFlags = 0;

    CU_ASSERT(gvars);

    CU_TRACE_FUNCTION();

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(ctx));
    mcUnlock(gvars);
    if (!mcctx) {
        CU_ERROR_PRINT(("we don't know this context\n"));
        return CUDA_ERROR_INVALID_CONTEXT;
    }

    if (!mcContextIsActive(mcctx)) {
        CU_TRACE_PRINT(("Context is not yet initialized\n"));
        return CUDA_SUCCESS;
    }

    launch = mcLaunchGetInContext(mcctx, gridId);

    if (!launch || !launch->rec) {
        CU_DEBUG_PRINT(("No launch scheduled for this pointer\n"));
        return CUDA_SUCCESS;
    }

    status = mcctx->gvars->tools.context->StreamGetIdEx(mcctx->cuctx, stream, &streamId);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to get stream id\n"));
        goto error;
    }

    mcCtxLock(mcctx);
    ctxState = mcctx->state;
    mcCtxUnlock(mcctx);

    rec = launch->rec;
    status = scopeQueryLaunchChanged(rec);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to query if launch changed\n"));
        goto error;
    }

    /* Need to mark context dirty if there are deferred streams */
    if (ctxState == MC_CONTEXT_STATE_CLEAN &&
        rec->previousStreamId != streamId) {
        CU_TRACE_PRINT(("Context has streams and launch changed streams. Forcing context to dirty\n"));
        ctxState = MC_CONTEXT_STATE_DIRTY;
    }

    filterMatch = rec->func->filterMatch;

    /* If we still need to do a runtime test */
    if (filterMatch == CC_FILTER_MATCH_TEST) {
        status = CCfilterMgrMatchOnLaunch(mcctx->filterMgr, rec, &filterMatch);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed when matching filter on launch\n"));
            goto error;
        }
    }

    /* At this point, filterMatch can only be one of _ACCEPT or _REJECT */
    if (filterMatch != CC_FILTER_MATCH_ACCEPT &&
        filterMatch != CC_FILTER_MATCH_REJECT) {
        CU_ERROR_PRINT(("Unexpected value for filterMatch (%u)\n"));
    }

    // Early exit if there is no need to regenerate the patch
    if ((ctxState == MC_CONTEXT_STATE_CLEAN ||
         ctxState == MC_CONTEXT_STATE_INITIALIZED) &&
        rec->state == MC_PATCH_STATE_ACTIVE &&
        filterMatch == CC_FILTER_MATCH_ACCEPT) {
        CU_TRACE_PRINT(("Existing patch is correct\n"));
        return CUDA_SUCCESS;
    }

    if (rec->state == MC_PATCH_STATE_NONE)
        return CUDA_SUCCESS;

    scopeDirty = scopeNeedsSync(rec);
    scopeActive = scopeHasActive(rec);

    /* Setup resetFunc flags so that clearPatch will also reset the function */
    resetFuncFlags = (filterMatch == CC_FILTER_MATCH_REJECT && (scopeActive || scopeDirty)) ? 1 : 0;

    CU_TRACE_PRINT(("Launching %s, resetFuncFlags :%u filterMatch:%u scopeActive:%u scopeDirty:%u\n",
                    rec->func->funcName, resetFuncFlags, filterMatch, scopeActive, scopeDirty));

    if (((ctxState == MC_CONTEXT_STATE_DIRTY ||
          filterMatch == CC_FILTER_MATCH_REJECT) &&
         scopeActive)                           ||
        scopeDirty                              ||
        rec->state == MC_PATCH_STATE_DIRTY_SYNC) {
        // Save off the function

        if (ctxState == MC_CONTEXT_STATE_DIRTY)
            CU_TRACE_PRINT(("Found a patch on a dirty context\n"));
        else if (filterMatch == CC_FILTER_MATCH_REJECT)
            CU_TRACE_PRINT(("Patching was rejected by filter on an active ctx\n"));
        else if (rec->state == MC_PATCH_STATE_DIRTY_SYNC)
            CU_TRACE_PRINT(("Patch is dirty and must be syncd first\n"));
        else if (scopeDirty)
            CU_TRACE_PRINT(("Scope needs sync\n"));

        status = mcContextSynchronize(mcctx);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("mcContextSynchronize hit an error\n"));
            goto error;
        }
    }

    // Reset the context state if dirty. Always reset the state of
    // all patches in the context when marking a context clean
    if (ctxState == MC_CONTEXT_STATE_DIRTY ||
        (filterMatch == CC_FILTER_MATCH_REJECT && scopeActive)) {
        status = markAllPatchesDirty(mcctx);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to mark all patches on context\n"));
            status = CUDA_ERROR_UNKNOWN;
            goto error;
        }
        mcCtxLock(mcctx);
        mcctx->state = MC_CONTEXT_STATE_CLEAN;
        ctxState = mcctx->state;
        mcCtxUnlock(mcctx);
    }

    // We now do a late check. At this point, patch states can be :
    //  initialized (brand new patches),
    //  active (patches that need no changes)
    //  dirty  (patches that may have just gotten syncd)
    //  launch_done (patches that were flushed as part of this sync)
    // In the case of active and initialized patches, we dont need to do anything
    // but in all other cases, we need to clear out the existing patch.
    // Also, if any patch needs this, we must do it over the entire scope
    // ResetFunc is set only if the scope was active and patching has been rejected by the filter
    scopeClear = scopeNeedsPatchClear(rec);
    if (scopeClear) {
        CU_TRACE_PRINT(("Dirty scope encountered for %s. Clearing.. resetFuncFlags:%u\n",
                        rec->func->funcName, resetFuncFlags));
        status = scopePatchClear(mcctx, rec->func, stream, streamId, resetFuncFlags);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Could not clear dirty patch on func:%s\n", rec->func->funcName));
            goto error;
        }
    }

    if (rec->state == MC_PATCH_STATE_FAILED) {
        CU_ERROR_PRINT(("Patch has hit a failure \n"));
        status = CUDA_ERROR_UNKNOWN;
        goto error;
    }

    /* At this point, bail if the launch was rejected by the
       filter
    */
    if (filterMatch == CC_FILTER_MATCH_REJECT) {
        CU_TRACE_PRINT(("Launch patching rejected by filter\n"));
        status = invalICache(ctx);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("invalICache failed for rejected filter\n"));
        }

        return CUDA_SUCCESS;
    }

    // By this point, either we came in on a brand new patch
    // and everything in scope was just initialized
    // or we came in a dirty scope that got sync'd
    // Either way, at this point the rec->state must be set
    // to initialized if a new patch must be generated
    scopeRegen = scopeNeedsPatchGen(rec);
    if (scopeRegen) {
        status = scopePatchRecomputeLaunch(mcctx, rec);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Scope patch compute launch failed\n"));
            goto error;
        }

        status = scopePatchSetup(mcctx, rec->func, stream);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("scope patch setup failed\n"));
            goto error;
        }
    }

    if (rec->options.debuggerAttached) {
        status = resetLmem(mcctx);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("LMEM reset failed\n"));
            goto error;
        }
    }

    status = invalICache(ctx);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("invalICache failed\n"));
        goto error;
    }

    /* Be sure to invalidate the instruction cache before the launch,
       this was bug 678486 and bug 687852. */
    mcctx->cuctx->invalICache = NV_TRUE;

    /* Set the previous stream Id to this stream */
    rec->previousStreamId = streamId;

    CU_TRACE_PRINT(("patch setup complete\n"));

    return status;

error:
    CU_DEBUG_PRINT(("memcheck: function setup2 failed (%d)\n", status));
    return status;
}

static CUresult
afterSyscallSetupCallback(MCglobals *gvars,
                          const CUtoolsAfterSyscallSetup *params)
{
    CU_ASSERT(params);

    CU_TRACE_FUNCTION();

    return OnAfterSyscallSetup(gvars, params->ctx, params->stream, params->gridId);
}

/* Copy the patched function and push the new start offset */
static CUresult
beforeLaunchPushed(MCglobals *gvars, const CUtoolsBeforeLaunchPushed *params)
{
    MCcontext *mcctx;
    MCrec *rec;
    CUresult status = CUDA_SUCCESS;
    MClaunch *launch;

    CU_ASSERT(gvars);
    CU_ASSERT(params);

    CU_TRACE_FUNCTION();

    if (!gvars->options.debugInternals && params->func->mod->internal) {
        CU_DEBUG_PRINT(("Skipping internal kernels\n"));
        return CUDA_SUCCESS;
    }

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(params->ctx));
    mcUnlock(gvars);
    if (!mcctx) {
        CU_ERROR_PRINT(("we don't know this context\n"));
        return CUDA_ERROR_INVALID_CONTEXT;
    }

    if (!mcContextIsActive(mcctx)) {
        CU_TRACE_PRINT(("Context is not yet initialized\n"));
        return CUDA_SUCCESS;
    }

    if (mcctx->haloContext) {
        /* Snap the latest lmemSizePerSM information for halo */
        mcctx->haloContext->lmemSizePerSM = params->ctx->lmemConfig.sizePerSM;
    }

    launch = mcLaunchGetInContext(mcctx, params->gridId);

    if (!launch || !launch->rec) {
        CU_ERROR_PRINT(("No launch scheduled for this pointer\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    rec = launch->rec;

    if (rec->state != MC_PATCH_STATE_ACTIVE)
        return CUDA_SUCCESS;

    status = scopeIncrementLaunchCount(mcctx, rec->func);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("scopeIncrementLaunchCount failed\n"));
        goto error;
    }

    launch->state = MC_LAUNCH_STATE_ACTIVE;

    return status;

error:
    CU_DEBUG_PRINT(("memcheck: function prelaunch failed (%d)\n", status));
    return status;
}

static CUresult
scopeUnitHandlePatchCompletion(MCcontext *mcctx, MCfunc *first, MCfunc *func, void *data)
{
    MCrec *rec = NULL;
    MClaunch *launch = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !func || !data)
        return CUDA_ERROR_UNKNOWN;

    launch = (MClaunch*)data;

    rec = mcContextGetPatchByFunc(mcctx, func);
    if (!rec) {
        CU_ERROR_PRINT(("Failed to find patch\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    mcRecHandlePatchCompletion(rec, launch);

    return CUDA_SUCCESS;
}

static CUresult
scopeHandlePatchCompletion(MClaunch *launch)
{
    CUresult res = CUDA_SUCCESS;
    MCrec *rec = NULL;

    CU_TRACE_FUNCTION();

    if (!launch) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    rec = launch->rec;

    if (!rec) {
        CU_ERROR_PRINT(("Invalid patch\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    res = scopeFunctor(rec->context, rec->func, &scopeUnitHandlePatchCompletion, launch);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to find handle patch completion in scope for :%s\n", rec->func->funcName));
        return CUDA_ERROR_UNKNOWN;
    }

    return CUDA_ERROR_UNKNOWN;
}

static TOOLSresult
handleLaunchCompletionFunctor(tHashMapKey_t key, void *value, void *functor_data)
{
    MClaunch *launch = (MClaunch*)value;

    scopeHandlePatchCompletion(launch);

    return TOOLS_SUCCESS;
}

/* Restore everything to pre-launch state */
static CUresult
afterGridLaunched(MCglobals *gvars, const CUtoolsAfterGridLaunched *params)
{
    CUresult res = CUDA_SUCCESS;
    MCcontext *mcctx;

    CU_ASSERT(gvars);
    CU_ASSERT(params);

    CU_TRACE_FUNCTION();

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(params->ctx));
    mcUnlock(gvars);
    if (!mcctx) {
        CU_ERROR_PRINT(("we don't know this context\n"));
        return CUDA_ERROR_INVALID_CONTEXT;
    }

    if (!mcContextIsActive(mcctx)) {
        CU_TRACE_PRINT(("Context is not yet initialized\n"));
        return CUDA_SUCCESS;
    }

    if (!gvars->options.debugInternals && params->func->mod->internal) {
        CU_DEBUG_PRINT(("Skipping internal kernels\n"));
        return CUDA_SUCCESS;
    }

    /* On Fermi and above, if nonblocking launches are enabled, we handle checking
       in the memcheck callback and do lazy cleanup. So we only do the sync if
       the tool is old, and does not push nonblockingLaunch */
    if (mcctx->ctxOpts.launchMode == MC_CONTEXT_OPTION_LAUNCH_BLOCKING) {
        /*The synchronize causes a  check of the RM channel error status.
         Thus, the return value of the call can be either the sticky'd error
         or the actual error in synchronize. */
        (void)mcContextStreamSynchronize(mcctx, params->stream);
        toolsHashMapApplyFunctor(mcctx->launches, handleLaunchCompletionFunctor, NULL);

        res = flushRecords(mcctx, &mcctx->gvars->output);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to flush errors\n"));
            return res;
        }

        // Cleanup
        res = mcLaunchRemoveAll(mcctx);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed in cleanup launches in blocking mode\n"));
            return res;
        }

        res = mcContextRemoveAllPatches(mcctx, CC_CLEANUP_MODE_HOST_AND_DEVICE);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to cleanup patches in blocking mode\n"));
            return res;
        }
    }
    return CUDA_SUCCESS;
}

static CUresult
deviceHeapSelected(MCglobals *gvars, const CUtoolsDeviceHeapSelected *inParams)
{
    CUresult res = CUDA_SUCCESS;
    MCcontext* mcctx = NULL;
    uint64_t heapAddr = inParams->address;
    CCalloc *heapAlloc = NULL;
    CCalloc *foundAlloc = NULL;
    uint32_t flags = 0;
    const char *name = NULL;

    CU_TRACE_FUNCTION();

    // Walk the alloc list to find the matching alloc
    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(inParams->ctx));
    mcUnlock(gvars);

    if (!mcctx) {
        CU_ERROR_PRINT(("Could not find valid context\n"));
        return CUDA_ERROR_INVALID_CONTEXT;
    }

    if (!mcContextIsActive(mcctx)) {
        CU_TRACE_PRINT(("Context is not yet initialized\n"));
        return CUDA_SUCCESS;
    }

    mcCtxLock(mcctx);
    res = CCallocTableRemoveAlloc(mcctx->ctxAllocs, heapAddr, &foundAlloc);
    mcCtxUnlock(mcctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Error when looking for heap at 0x" PRIx64 "\n", heapAddr));
        return res;
    }

    if (foundAlloc) {
        CU_DEBUG_PRINT(("Removed heap alloc at 0x%" PRIx64 " from table\n", heapAddr));
        flags = CCallocGetFlags(foundAlloc);
        name = CCallocGetName(foundAlloc);
        res = CCallocDestroy(&foundAlloc);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to delete allocation\n"));
            return res;
        }
    }

    // Create the heap allocation
    res = CCallocCreate(&heapAlloc,
                        inParams->address,
                        inParams->sizeRequested,
                        flags | CC_ALLOC_FLAG_HEAP,
                        name);

    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to create heap\n"));
        return res;
    }

    // Capture a backtrace
    res = CCallocCaptureHostBacktrace(heapAlloc, &mcctx->ctxOpts.btopts);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to capture host backtrace\n"));
        (void)CCallocDestroy(&heapAlloc);
        return res;
    }

    // Add to the context
    mcCtxLock(mcctx);
    if (mcctx->heapAlloc)
        res = CCallocDestroy(&mcctx->heapAlloc);
    mcctx->heapAlloc = heapAlloc;
    mcCtxUnlock(mcctx);

    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to destroy allocation. Squashing as this is nonfatal\n"));
        res = CUDA_SUCCESS;
    }

    res = mcctx->gvars->toolMode.heapSelectedCallback(mcctx, heapAlloc);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed in toolMode callback to heapSelected\n"));
        return res;
    }

    res = invalICache(mcctx->cuctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to reset Icache\n"));
        return res;
    }

    return res;
}

static CUresult
cnpUpdateConstants(MCglobals *gvars, const CUtoolsCnpUpdateConstants *inParams)
{
    CUresult res = CUDA_SUCCESS;
    MCcontext* mcctx = NULL;
    CCalloc *foundAlloc = NULL;
    uint32_t flags = 0;
    uint64_t addr = 0;

    CU_TRACE_FUNCTION();

    // Walk the alloc list to find the matching alloc
    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(inParams->ctx));
    mcUnlock(gvars);

    if (!mcctx) {
        CU_ERROR_PRINT(("Could not find valid context\n"));
        return CUDA_ERROR_INVALID_CONTEXT;
    }

    if (!mcContextIsActive(mcctx)) {
        CU_TRACE_PRINT(("Context is not yet initialized\n"));
        return CUDA_SUCCESS;
    }

    addr = inParams->paramBankPoolBase;

    mcCtxLock(mcctx);
    res = CCallocTableFindByAddr(mcctx->ctxAllocs, addr, &foundAlloc);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to find alloc\n"));
        goto unlock_and_return;
    }

    /* If this is already the cnpParamAlloc, nothing is left to be done */
    if (foundAlloc == mcctx->cnpParamAlloc)
        goto unlock_and_return;

    /* Otherwise, unset the internal flag on the found allocation*/
    if (foundAlloc) {
        flags = CCallocGetFlags(foundAlloc);
        flags &= ~CC_ALLOC_FLAG_INTERNAL;
        flags |= CC_ALLOC_FLAG_PARAM_BANK;
        res = CCallocSetFlags(foundAlloc, flags);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Error when setting flags on found alloc\n"));
            goto unlock_and_return;
        }
    }

    /* Reset the internal flag on the old allocation */
    if (mcctx->cnpParamAlloc) {
        flags = CCallocGetFlags(mcctx->cnpParamAlloc);
        flags &= ~CC_ALLOC_FLAG_PARAM_BANK;
        flags |= CC_ALLOC_FLAG_INTERNAL;
        res = CCallocSetFlags(mcctx->cnpParamAlloc, flags);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Error when setting flags on existing param alloc\n"));
            goto unlock_and_return;
        }
    }

    /* Set the new cnpParamAlloc */
    mcctx->cnpParamAlloc = foundAlloc;

unlock_and_return:
    mcCtxUnlock(mcctx);
    return res;
}

static CUresult
trapEvent(MCglobals *gvars, const CUtoolsTrap *inParams)
{
    CUresult res = CUDA_SUCCESS;
    MCcontext *mcctx = NULL;

    CU_TRACE_FUNCTION();

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(inParams->ctx));
    mcUnlock(gvars);

    if (mcctx) {
        res = gvars->toolMode.trapHandlerCallback(mcctx,
                                                  (CUmemobj*)inParams->scratchPad,
                                                  (uint32_t)inParams->smError);
    }
    else {
        CU_ERROR_PRINT(("Invalid context.\n"));
        res = CUDA_ERROR_UNKNOWN;
    }

    return res;
}

static CUresult
trapEndEvent(MCglobals *gvars, const CUtoolsTrap *inParams)
{
    CUresult res = CUDA_SUCCESS;
    MCcontext *mcctx = NULL;

    CU_TRACE_FUNCTION();

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(inParams->ctx));
    mcUnlock(gvars);

    if (mcctx) {
        res = gvars->toolMode.trapHandlerEndCallback(mcctx,
                                                     (CUmemobj*)inParams->scratchPad,
                                                     (uint32_t)inParams->smError);
    }
    else {
        CU_ERROR_PRINT(("Invalid context.\n"));
        res = CUDA_ERROR_UNKNOWN;
    }

    return res;
}

static CUresult
streamSynchronized(MCglobals *gvars, const CUtoolsStreamSynchronized *inParams)
{
    CUresult res = CUDA_SUCCESS;
    MCcontext *mcctx = NULL;

    CU_TRACE_FUNCTION();

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(inParams->ctx));
    mcUnlock(gvars);

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid context.\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    res = handleSynchronization(gvars, mcctx, inParams->stream);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Error when handling context/stream synchronization\n"));
        return res;
    }

    return CUDA_SUCCESS;
}

static CUresult
checkApiSynchronizeIfNeeded(MCglobals *gvars, const CUtoolsCbId cbid, bool isRuntime)
{
    CUresult status;
    CUItlsThreadData *threadData = NULL;
    CUresult res = CUDA_SUCCESS;
    MCcontext *mcctx = NULL;
    CUctx *ctx = NULL;
    bool isSynchronizingApi = false;

    /* Only make the check for driver API : the runtime API will call into the driver one */
    if (isRuntime)
        return CUDA_SUCCESS;

    status = cuiTlsGetCurrentThreadData(&threadData);
    if (status != CUDA_SUCCESS) {
        CU_DEBUG_PRINT(("Failed get TLS data\n"));
        return status;
    }

    isSynchronizingApi = (cbid == CU_TOOLS_CBID_TRACE_API_CUDA_cuMemFree    ||
                          cbid == CU_TOOLS_CBID_TRACE_API_CUDA_cuMemFree_v2 ||
                          cbid == CU_TOOLS_CBID_TRACE_API_CUDA_cuMemFreeHost);

    if (!isSynchronizingApi)
        return CUDA_SUCCESS;

    ctx = cuiTlsGetCurrentContext(threadData);

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(ctx));
    mcUnlock(gvars);

    res = handleSynchronization(gvars, mcctx, 0);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Error when handling API implicit synchronization.\n"));
        return res;
    }

    return CUDA_SUCCESS;
}

typedef CUresult (CUDAAPI *cudartGetEtbl)(const void **ppExportTable,
                                          const CUuuid *pExportTableId);

static CUresult
checkApiCallCounter(MCglobals *gvars, const CUtoolsCbId cbid, uint32_t apiEnterOrExit, uint32_t *const pStatus, const char* functionName, const uint64_t contextId, uint32_t type, void* cudartEtbl)
{
    bool isEntry = false;
    bool isOuter = false;
    bool isRuntime = false;
    int32_t val = 0;
    MCtlsEntry *tlsData = NULL;
    cudaError_t errorNotReady = cudaErrorNotReady;

    CU_TRACE_FUNCTION();

    if (!gvars)
        return CUDA_ERROR_UNKNOWN;

    if (!gvars->toolMode.enableApiCheck(&gvars->options))
        return CUDA_SUCCESS;

    isEntry = (apiEnterOrExit == CU_TOOLS_API_ENTER);
    isRuntime = (type == CU_MEMCHECK_API_TYPE_RUNTIME);

    tlsData = (MCtlsEntry*)cuosTlsGetValue(gvars->tlsEntry);
    if (!tlsData) {
        CU_ERROR_PRINT(("Missing tlsData\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* For API entry points, increment the value in the TLS */
    if (isEntry) {
        ++tlsData->val;
        /* Skip the rest for all API entry calls */
        return CUDA_SUCCESS;
    }

    /* At this point, we know this is an API exit call.
       Decrement the TLS */
    val = tlsData->val;
    --val;
    if (val >= 0)
        tlsData->val = val;

    /* Skip successful calls */
    if (!pStatus || *pStatus == CUDA_SUCCESS) {
        CUresult res = CUDA_SUCCESS;

        /* handle potential synchronization implicit to this API call */
        res = checkApiSynchronizeIfNeeded(gvars, cbid, isRuntime);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Handling of potential implicit API synchronization failed\n"));
            return res;
        }

        return CUDA_SUCCESS;
    }

    if (isRuntime && cudartEtbl) {
        CUresult res = CUDA_SUCCESS;
        cudartGetEtbl pfn = (cudartGetEtbl)cudartEtbl;
        CUetblToolsRuntimeInstance *rtInst = NULL;
        int32_t version;

        res = pfn((const void**)&rtInst, &CU_ETID_ToolsRuntimeInstance);
        if (res != CUDA_SUCCESS) {
            return res;
        }

        res = rtInst->GetVersion(&version);
        if (res != CUDA_SUCCESS) {
            return res;
        }

        if (version < 10010) {
            /* Before CUDA 10.1 cudaErrorNotReady was set to 34. */
            errorNotReady = (cudaError_t)34;
        }
    }

    /* Skip reporting cudaErrorNotReady from cudaStreamQuery/cudaEventQuery and
       CUDA_ERROR_NOT_READY (=600) from cuStreamQuery/cuEventQuery */
    /* Driver's and runtime's errcodes were aligned at some point,
       therefore only one check here would be sufficient.
       However, doing two is more proof to potential errcode changes of the cuda runtime. */
    if ((isRuntime && pStatus && *pStatus == errorNotReady) ||
        (!isRuntime && pStatus && *pStatus == CUDA_ERROR_NOT_READY))
        return CUDA_SUCCESS;

    /* Here, we know that this is an API exit call and there has been
       an error. Make a late decision about whether or not to report
       this */

    isOuter = (val == 0);

    /* Only report errors if this is the outermost API call */
    if (isOuter)
        printApiError(gvars, (CUresult)*pStatus, functionName,
                      contextId, type, cudartEtbl);

    return CUDA_SUCCESS;
}

static CUresult
checkDriverApiCall(MCglobals *gvars, const CUtoolsCbId cbid, const CUtoolsTraceApiCuda *inParams, uint32_t type)
{
    return checkApiCallCounter(gvars, cbid, (uint32_t)inParams->apiEnterOrExit, (uint32_t*)inParams->pStatus,
                               inParams->functionName, inParams->contextId, type, NULL);
}

static CUresult
checkRuntimeApiCall(MCglobals *gvars, const CUtoolsCbId cbid, const CUtoolsTraceRuntimeApiCuda *inParams, uint32_t type)
{
    void *fptr = NULL;

    /* Some older CUDARTs may not set this field, so first check that the
       offset of the field is within the specified struct */
    if (offsetof(CUtoolsTraceRuntimeApiCuda, pfnGetExportTable) < inParams->struct_size)
        fptr = (void*)inParams->pfnGetExportTable;

    return checkApiCallCounter(gvars, cbid, (uint32_t)inParams->apiEnterOrExit, (uint32_t*)inParams->pStatus,
                               inParams->functionName, inParams->contextId, type, fptr);
}

static CUresult
checkApiCallCudartInternalInit(MCglobals *gvars, const CUtoolsCbId cbid, const CUtoolsTraceRuntimeInternalInit *inParams)
{
    return checkApiCallCounter(gvars, cbid, (uint32_t)inParams->apiEnterOrExit, (uint32_t*)inParams->pStatus,
                               inParams->functionName, 0, CU_MEMCHECK_API_TYPE_RUNTIME, NULL);
}

static CUresult
checkApiCallCudartEtbl_ModuleLoadFatBinary(MCglobals *gvars, const CUtoolsTraceApiCudaEtbl *inParams)
{
    const etblModuleLoadFatBinary_params *fp;
    CUresult res = CUDA_SUCCESS;

    if (!gvars->toolMode.enableApiCheck(&gvars->options))
        return CUDA_SUCCESS;

    if (!gvars->options.reportFatBinaryLoadErrors)
        return CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    /* ModuleLoadFatBinary is special  */
    fp = (const etblModuleLoadFatBinary_params*)inParams->functionParams;
    if (inParams->apiEnterOrExit == CU_TOOLS_API_EXIT) {
        if (fp && fp->status != CUDA_SUCCESS) {
            printApiError(gvars, fp->status, "load binary via CUDA runtime",
                          0, CU_MEMCHECK_API_TYPE_DRIVER, NULL);
        }
    }
    return res;
}

static CUresult
memcpyBegin(MCglobals *gvars, const CUtoolsMemcpyBegin *inParams)
{
    CUresult res = CUDA_SUCCESS;
    uint64_t srcaddr = 0, dstaddr = 0, size = 0;
    MCcontext *srcctx = NULL, *dstctx = NULL;

    CU_TRACE_FUNCTION();

    /* Check the arguments */
    if (!gvars || !inParams) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* Check if memory access checking is enabled */
    if (!gvars->toolMode.enableMemAccessCheck(&gvars->options))
        return CUDA_SUCCESS;

    /* Early return for internal memcopies  */
    if (!inParams->isApiRequested) {
        CU_TRACE_PRINT(("Skipping internal allocation\n"));
        return CUDA_SUCCESS;
    }

    /* Grab the context of the destination object and the source object. For
       P2H2P, the source and destination contexts do not need to match */
    mcLock(gvars);
    dstctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(inParams->ctx));
    mcUnlock(gvars);

    mcLock(gvars);
    srcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(inParams->srcCtx));
    mcUnlock(gvars);

    /* Get the size of the transfer */
    size = inParams->bytes;

    /* Since we only support device allocation memcopies (not surface), check
       the allocation type.
       TODO : Note that in the case of host pinned allocations on UVA
       the driver has received the callback and therefore this is actually being
       tracked.
    */
    if (inParams->srcType == CU_TOOLS_MEMCPY_OBJECT_TYPE_DEVICE) {
        /* Get the address */
        res = gvars->tools.memory->TranslateVAtoDevicePtr(inParams->srcCtx,
                                                          inParams->srcVaddr,
                                                          &srcaddr);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed when translating VA to Dptr. (VA:0x%" PRIx64 "\n",
                            inParams->srcVaddr));
            return res;
        }

        res = gvars->toolMode.checkMemAccessDevAddr(srcctx, srcaddr, size,
                                                    inParams->stream,
                                                    CC_MEM_ACCESS_TYPE_MEMCPY_SRC);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to check memcopy dev addr\n"));
            return res;
        }
    }

    if (inParams->dstType == CU_TOOLS_MEMCPY_OBJECT_TYPE_DEVICE) {
        res = gvars->tools.memory->TranslateVAtoDevicePtr(inParams->ctx,
                                                          inParams->dstVaddr,
                                                          &dstaddr);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed when translating VA to Dptr. (VA:0x%" PRIx64 "\n",
                            inParams->dstVaddr));
            return res;
        }
        res = gvars->toolMode.checkMemAccessDevAddr(dstctx, dstaddr, size,
                                                    inParams->stream,
                                                    CC_MEM_ACCESS_TYPE_MEMCPY_DST);
    }

    return res;
}

static CUresult
memcpyEnd(MCglobals *gvars, const CUtoolsMemcpyEnd *inParams)
{
    CUresult res = CUDA_SUCCESS;
    MCcontext *mcctx = NULL;
    CUtoolsMemcpyDir dir;
    NvU8 isBarrierStream = 0;
    NvU8 isNullStream = 0;

    CU_TRACE_FUNCTION();

    /* In the case of user initiated, synchronous DtoH memcpy
       we need to check if the memcpy is on the barrier stream.
       If so, issue the context sync callback to allow other
       tools to flush any context wide buffers.
    */
    if (!inParams->isApiRequested)
        return CUDA_SUCCESS;

    if (inParams->isAsync)
        return CUDA_SUCCESS;

    dir = (CUtoolsMemcpyDir) inParams->direction;

    if (dir != CU_TOOLS_MEMCPY_DIR_D_TO_H)
        return CUDA_SUCCESS;

    CU_TRACE_PRINT(("Found a synchronous user initiated DtoH memcpy\n"));

    res = gvars->tools.context->StreamIsBarrierStream(inParams->ctx, inParams->stream, &isBarrierStream);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed when testing for barrier stream\n"));
        return res;
    }

    res = gvars->tools.context->StreamIsNullStream(inParams->ctx, inParams->stream, &isNullStream);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed when testing for NULL stream\n"));
        return res;
    }

    if (!isBarrierStream && !isNullStream) {
        CU_TRACE_PRINT(("Stream is not barrier or NULL stream. No action\n"));
        return res;
    }

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(inParams->ctx));
    mcUnlock(gvars);

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid context.\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    res = handleSynchronization(gvars, mcctx, 0);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed in toolmode callback\n"));
        return res;
    }

    return res;
}

static CUresult
memsetSetupInit(MCglobals *gvars, const CUtoolsMemsetSetupInit *inParams)
{
    CUresult res = CUDA_SUCCESS;
    uint64_t addr = 0, size = 0;
    MCcontext *mcctx = NULL;
    uint64_t i;

    CU_TRACE_FUNCTION();

    /* Check the arguments */
    if (!gvars || !inParams) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* Return if memory access checking is disabled */
    if (!gvars->toolMode.enableMemAccessCheck(&gvars->options))
        return CUDA_SUCCESS;

    /* Early return for internal memcopies  */
    if (!inParams->isApiRequested) {
        CU_TRACE_PRINT(("Skipping internal allocation\n"));
        return CUDA_SUCCESS;
    }

    /* Grab the context */
    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(inParams->ctx));
    mcUnlock(gvars);

    /* Get the size of the memset for an individual row */
    size = inParams->width * inParams->elementSize;

    /* Get the address */
    addr = inParams->devicePointer;

    for (i = 0; i < inParams->height; ++i) {
        res = gvars->toolMode.checkMemAccessDevAddr(mcctx,
                                                    addr + (i * inParams->pitch),
                                                    size,
                                                    inParams->stream,
                                                    CC_MEM_ACCESS_TYPE_MEMSET);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to check memory access of size %llu for memset at address 0x%" PRIx64 "\n",
                            size, addr + (i * inParams->pitch)));
            return res;
        }
    }

    return res;
}

/* Register count is usually set by FunctionSetLaunchConfig, but in the case of CUDA graphs stream capture,
 * the QMD gets created before memcheck backend update its register count, so we need to refresh manually
 * the register count */
static CUresult
qmdBeforeLaunch(MCglobals *gvars, const CUtoolsQmdBeforeLaunch *params)
{
    MCcontext *mcctx = NULL;
    CNPqmdLaunch *hostQmdStaging = NULL;
    NvU32 *qmdData = NULL;

    CU_ASSERT(params);

    CU_TRACE_FUNCTION();

    /* Grab the context */
    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(params->ctx));
    mcUnlock(gvars);

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid context.\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* Get the QMD data buffer */
    hostQmdStaging = (CNPqmdLaunch *)params->qmd;
    qmdData = (NvU32*)hostQmdStaging->GridQMD;

    mcctx->hal.setRegCountInQmd(qmdData, (params->func->finalRegcount == 0) ? 1 : params->func->finalRegcount);

    return CUDA_SUCCESS;
}

static CUresult
uvmLiteStreamEnqueueBegin(MCglobals *gvars, const CUtoolsUvmLiteStreamOwnerChange* inParams)
{
    CUresult res = CUDA_SUCCESS;
    MCcontext *mcctx = NULL;

    CU_TRACE_FUNCTION();

    /* Check the arguments */
    if (!gvars || !inParams) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* Grab the context */
    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(inParams->ctx));
    mcUnlock(gvars);

    if (!mcctx) {
        CU_ERROR_PRINT(("Unknown context\n"));
        return CUDA_SUCCESS;
    }

    /* Need to context sync here to
       drain outstanding work due to
       race conditions. See bug 1361161
     */
    res = mcContextSynchronize(mcctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("mcContextSynchronize failed\n"));
        return res;
    }

    return res;
}

static CUresult
uvmLiteStreamEnqueueEnd(MCglobals *gvars, const CUtoolsUvmLiteStreamOwnerChange* inParams)
{
    CUresult res = CUDA_SUCCESS;
    uint64_t size = 0, addr = 0;
    MCcontext *mcctx = NULL;
    CCalloc *alloc = NULL;
    CCallocVisibility newVis = CC_ALLOC_VISIBILITY_CTX;
    uint64_t targetStream;

    CU_TRACE_FUNCTION();

    /* Check the arguments */
    if (!gvars || !inParams) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* Grab the context */
    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(inParams->ctx));
    mcUnlock(gvars);

    if (!mcctx) {
        CU_ERROR_PRINT(("Unknown context\n"));
        return CUDA_SUCCESS;
    }

    /* Force a sync on the context to flush out the stream callback */
    res = mcContextSynchronize(mcctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("mcContextSynchronize failed\n"));
        return res;
    }

    addr = inParams->address;
    size = inParams->size;

    switch (inParams->targetType) {
    case CU_TOOLS_UVM_LITE_OWNER_TYPE_ALL_STREAMS:
        newVis = CC_ALLOC_VISIBILITY_CTX;
        break;
    case CU_TOOLS_UVM_LITE_OWNER_TYPE_ONE_STREAM:
        newVis = CC_ALLOC_VISIBILITY_STREAM;
        break;
    case CU_TOOLS_UVM_LITE_OWNER_TYPE_NO_STREAM:
        newVis = CC_ALLOC_VISIBILITY_NONE;
        break;
    default:
        newVis = CC_ALLOC_VISIBILITY_CTX;
        break;
    }

    targetStream = inParams->targetStreamId;

    mcCtxLock(mcctx);
    res = CCallocTableFindByAddr(mcctx->ctxAllocs, addr, &alloc);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed calling CCallocTableFindByAddr\n"));
        goto unlock_and_return;
    }

    if (!alloc) {
        CU_ERROR_PRINT(("Alloc not found\n"));
        res =  CUDA_ERROR_UNKNOWN;
        goto unlock_and_return;
    }

     /* The driver currently does not support region based binding of
       allocations. And memcheck doesnt support it. So add a check for
       now.
    */
    if (size != CCallocGetSize(alloc)) {
        CU_ERROR_PRINT(("Reservation size does not match. Region size:0x%" PRIx64 " Alloc Size:0x%" PRIx64 " \n",
                        size, CCallocGetSize(alloc)));
        res = CUDA_ERROR_UNKNOWN;
        goto unlock_and_return;
    }

    res = CCallocSetVisibility(alloc, newVis, targetStream);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to set visibility\n"));
        goto unlock_and_return;
    }

    mcctx->state = MC_CONTEXT_STATE_DIRTY;

unlock_and_return:
    mcCtxUnlock(mcctx);

    if (res != CUDA_SUCCESS)
        return res;

    /* Need to context sync here to
       drain outstanding work due to
       race conditions. See bug 1361161
     */
    res = mcContextSynchronize(mcctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("mcContextSynchronize failed\n"));
        return res;
    }

    return res;
}

static CUresult
internalMemblockAlloc(MCglobals *gvars, const CUtoolsMemBlockAlloc *params)
{
    MCcontext *mcctx = NULL;
    CUDBGResult dbgRes = CUDBG_SUCCESS;

    CU_TRACE_FUNCTION();


    if (params->ctx) {
        mcLock(gvars);
        mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(params->ctx));
        mcUnlock(gvars);

        if (!mcctx) {
            CU_ERROR_PRINT(("Unknown context.\n"));
            return CUDA_SUCCESS;
        }
    }

    /* If halo has not been initialized */
    if (!gvars->haloInitialized)
        return CUDA_SUCCESS;

    if (mcctx && !mcctx->haloContext)
        return CUDA_SUCCESS;

    /* Skip allocations that have no device VAs */
    if (params->desc->hasDevPtr == 0 ||
        params->desc->mapDevice == CU_TOOLS_MEM_MAP_DEVICE_NONE ||
        params->desc->mapDevice == CU_TOOLS_MEM_MAP_DEVICE_SPECIAL_NO_VA)
        return CUDA_SUCCESS;

    if (mcctx) {
        mcCtxLock(mcctx);
        dbgRes = haloMemcheckAddMemblock(params->ctx, (CUmemblock*)params->hMemBlock);
        mcCtxUnlock(mcctx);
    }
    else {
        mcLock(gvars);
        dbgRes = haloMemcheckAddGlobalMemblock((CUmemblock*)params->hMemBlock);
        mcUnlock(gvars);
    }
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Error when adding memblock (dbgRes=%u)\n",dbgRes));
        return CUDA_ERROR_UNKNOWN;
    }

    return CUDA_SUCCESS;
}

static CUresult
internalMemblockFree(MCglobals *gvars, const CUtoolsMemBlockFree *params)
{
    MCcontext *mcctx = NULL;
    CUDBGResult dbgRes = CUDBG_SUCCESS;

    CU_TRACE_FUNCTION();

    if (params->ctx) {
        mcLock(gvars);
        mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(params->ctx));
        mcUnlock(gvars);

        if (!mcctx) {
            CU_ERROR_PRINT(("Unknown context.\n"));
            return CUDA_SUCCESS;
        }
    }

    /* If halo has not been initialized */
    if (!gvars->haloInitialized)
        return CUDA_SUCCESS;

    if (mcctx && !mcctx->haloContext)
        return CUDA_SUCCESS;

    /* Skip allocations that have no device VAs */
    if (params->desc->hasDevPtr == 0 ||
        params->desc->mapDevice == CU_TOOLS_MEM_MAP_DEVICE_NONE ||
        params->desc->mapDevice == CU_TOOLS_MEM_MAP_DEVICE_SPECIAL_NO_VA)
        return CUDA_SUCCESS;

    if (mcctx) {
        mcCtxLock(mcctx);
        dbgRes = haloMemcheckRemoveMemblock(params->ctx, (CUmemblock*)params->hMemBlock);
        mcCtxUnlock(mcctx);
    }
    else {
        mcLock(gvars);
        dbgRes = haloMemcheckRemoveGlobalMemblock((CUmemblock*)params->hMemBlock);
        mcUnlock(gvars);
    }
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Error when removing memblock (dbgRes=%u)\n",dbgRes));
        return CUDA_ERROR_UNKNOWN;
    }

    return CUDA_SUCCESS;
}

static CUresult
internalHostLmemResize(MCglobals *gvars, const CUtoolsHostLocalMemResize *params)
{
    MCcontext *mcctx = NULL;
    CUDBGResult dbgRes = CUDBG_SUCCESS;
    uint64_t devvaddr = 0, size = 0;
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(params->ctx));
    mcUnlock(gvars);

    if (!mcctx) {
        CU_ERROR_PRINT(("Unknown context.\n"));
        return CUDA_SUCCESS;
    }

    /* If halo has not been initialized */
    if (!gvars->haloInitialized) {
        return CUDA_SUCCESS;
    }

    if (!mcctx->haloContext) {
        return CUDA_SUCCESS;
    }

    res = gvars->tools.memory->MemObjGetDeviceVAddr(params->hMemObj, &devvaddr);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to get devvaddr for lmem memobj\n"));
        return res;
    }
    size  = params->totalSize;

    mcCtxLock(mcctx);
    dbgRes = haloMemcheckUpdateHostLmem(params->ctx, devvaddr, size);
    mcCtxUnlock(mcctx);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Error when removing memblock (dbgRes=%u)\n",dbgRes));
        return CUDA_ERROR_UNKNOWN;
    }

    return CUDA_SUCCESS;
}

static CUresult
batchMemopWrite(MCglobals *gvars, const CUtoolsBatchMemop *params)
{
    MCcontext *mcctx = NULL;
    CUtoolsStreamBatchMemOpParams *memOpParams;
    CUresult res = CUDA_SUCCESS;
    size_t size = 0;
    uint64_t destAddr = 0;

    CU_TRACE_FUNCTION();

    mcLock(gvars);
    mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(params->ctx));
    mcUnlock(gvars);

    /* Return if memory access checking is disabled */
    if (!gvars->toolMode.enableMemAccessCheck(&gvars->options))
        return CUDA_SUCCESS;

    if (!mcctx) {
        CU_ERROR_PRINT(("Unknown context.\n"));
        return CUDA_SUCCESS;
    }

    memOpParams = &params->params[params->index];
    if (memOpParams->params.operation == CU_STREAM_MEM_OP_WRITE_VALUE_32) {
        size = 4;
        destAddr = memOpParams->params.writeValue.address;
    }
    else if (memOpParams->params.operation == CU_STREAM_MEM_OP_WRITE_VALUE_64) {
        size = 8;
        destAddr = memOpParams->params.writeValue.address;
    }
    else if (memOpParams->params.operation == CU_STREAM_MEM_OP_WRITE_MEMORY) {
        size = memOpParams->params.writeMemory.byteCount;
        destAddr = memOpParams->params.writeMemory.dst;
    }
    else {
        return CUDA_ERROR_INVALID_VALUE;
    }

    res = gvars->toolMode.checkMemAccessDevAddr(mcctx,
                                                destAddr,
                                                size,
                                                params->stream,
                                                CC_MEM_ACCESS_TYPE_STREAM_WRITE);

    return res;
}

static CUresult
functionPatched(MCglobals *gvars, const CUtoolsFunctionPatched *params)
{
    CU_TRACE_FUNCTION();

    if (params->patchType == CU_TOOLS_PATCH_TYPE_BAR_BUG1806445)
    {
        MCcontext *mcctx = NULL;
        TOOLSresult tres = TOOLS_SUCCESS;
        uint64_t *pOriginalInstruction = NULL;
        tHashMap *originalInstructionsMap = NULL;

        mcLock(gvars);
        mcctx = (MCcontext *)toolsHashMapFind(gvars->contexts, tHashMapPtrToKey(params->ctx));
        mcUnlock(gvars);

        if (!mcctx) {
            CU_ERROR_PRINT(("Unknown context.\n"));
            return CUDA_SUCCESS;
        }

        CU_ASSERT(mcctx->sm_version < 700);
        CU_ASSERT(mcctx->bug1806445Map);

        originalInstructionsMap = (tHashMap *)toolsHashMapFind(mcctx->bug1806445Map, tHashMapPtrToKey(params->mod));

        // If not found, create it
        if (!originalInstructionsMap) {
            originalInstructionsMap = toolsHashMapNew(toolsPointerHashFun, toolsUint64EqualFun, 8);
            if (!originalInstructionsMap) {
                CU_ERROR_PRINT(("Failed to create bug 1806445 map for module %p\n", params->mod));
                return CUDA_ERROR_UNKNOWN;
            }

            tres = toolsHashMapInsert(mcctx->bug1806445Map, tHashMapPtrToKey(params->mod), originalInstructionsMap);
            if (tres != TOOLS_SUCCESS) {
                CU_ERROR_PRINT(("Failed to add bug 1806445 map for module %p\n", params->mod));
                return CUDA_ERROR_UNKNOWN;
            }
        }

        pOriginalInstruction = (uint64_t *)malloc(sizeof(uint64_t));
        if (!pOriginalInstruction) {
            CU_ERROR_PRINT(("Failed to allocated memory\n"));
            return CUDA_ERROR_OUT_OF_MEMORY;
        }

        if (mcctx->sm_version < 500)
            *pOriginalInstruction = params->originalInst.kepler.inst;
        else
            *pOriginalInstruction = params->originalInst.maxwell.inst;

        tres = toolsHashMapInsert(originalInstructionsMap, params->srcPC, pOriginalInstruction);
        if (tres != TOOLS_SUCCESS) {
            CU_ERROR_PRINT(("Failed to add original instruction to originalInstructionsMap\n"));
            return CUDA_ERROR_UNKNOWN;
        }
    }

    return CUDA_SUCCESS;
}

static CUresult
graphLaunchNodeBegin(MCglobals *gvars, const CUtoolsGraphLaunchNodeBegin *params)
{
    CUresult status = CUDA_SUCCESS;
    CUtoolsKernelNodeInfo kernelNodeInfo;

    CU_ASSERT(gvars);
    CU_ASSERT(params);

    CU_TRACE_FUNCTION();

    if (params->nodeType != CU_GRAPH_NODE_TYPE_KERNEL)
        return CUDA_SUCCESS;

    kernelNodeInfo.struct_size = sizeof(kernelNodeInfo);
    status = gvars->tools.graph->GraphKernelNodeGetInfo(
         params->node,
         &kernelNodeInfo);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to get info for graph node %p\n", params->node));
        return status;
    }

    status = OnLaunchBegin(
        gvars,
        kernelNodeInfo.ctx,
        kernelNodeInfo.stream,
        kernelNodeInfo.func,
        kernelNodeInfo.gridId);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("OnLaunchBegin failed with error code %d\n", status));
        return status;
    }

    status = OnAfterSyscallSetup(
        gvars,
        kernelNodeInfo.ctx,
        kernelNodeInfo.stream,
        kernelNodeInfo.gridId);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("OnAfterSyscallSetup failed with error code %d\n", status));
        return status;
    }

    return CUDA_SUCCESS;
}

static CUresult
graphLaunchNodeEnd(MCglobals *gvars, const CUtoolsGraphLaunchNodeEnd *params)
{
    CUresult status = CUDA_SUCCESS;
    CUtoolsKernelNodeInfo kernelNodeInfo;

    CU_ASSERT(gvars);
    CU_ASSERT(params);

    CU_TRACE_FUNCTION();

    if (params->nodeType != CU_GRAPH_NODE_TYPE_KERNEL)
        return CUDA_SUCCESS;

    kernelNodeInfo.struct_size = sizeof(kernelNodeInfo);
    status = gvars->tools.graph->GraphKernelNodeGetInfo(
         params->node,
         &kernelNodeInfo);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to get info for graph node %p\n", params->node));
        return status;
    }

    status = OnLaunchEnd(gvars, kernelNodeInfo.ctx);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("OnLaunchEnd failed with error code %d\n", status));
        return status;
    }

    return CUDA_SUCCESS;
}

static CUresult
graphexecCreating(MCglobals *gvars, const CUtoolsGraphExecCreating *params)
{
    CUresult status = CUDA_SUCCESS;

    CU_ASSERT(params);

    CU_TRACE_FUNCTION();

    const uint8_t isQmdChaining = 0;
    status = gvars->tools.graph->GraphSetIsQmdChaining(
        params->graphExec,
        isQmdChaining);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to disable QMD chaining\n"));
        return status;
    }

    return CUDA_SUCCESS;
}

static void CUDAAPI
memcheckCallbackHandler(
    void *pUserData,
    CUtools_cb_domain domain,
    CUtoolsCbId cbid,
    const void *inParams)
{
    CUresult status = CUDA_SUCCESS;
    MCglobals *gvars = (MCglobals*) pUserData;
    MCtlsEntry *tlsData = NULL;
    CCcleanupMode mode = CC_CLEANUP_MODE_HOST_AND_DEVICE;

#if defined(CUDA_DEVTOOLS_ENABLE_STATS)
    haloTimer timer;
#endif

    CU_ASSERT(pUserData);
    CU_ASSERT(domain);
    CU_ASSERT(cbid);

    if (!gvars->initialized)
        return;

#if defined(CUDA_DEVTOOLS_ENABLE_STATS)
        HALO_TIMER_START(timer);
#endif

    /* Create tls data is necessary */
    tlsData = (MCtlsEntry*)cuosTlsGetValue(gvars->tlsEntry);
    if (!tlsData) {
        tlsData = (MCtlsEntry*)calloc(1, sizeof(*tlsData));
        if (!tlsData) {
            CU_ERROR_PRINT(("Failed to allocate tlsData\n"));
            memcheckCleanup(gvars, mode);
            return;
        }
        cuosTlsSetValue(gvars->tlsEntry, tlsData);
    }

    switch (domain) {
    case CU_TOOLS_CB_DOMAIN_RESOURCE:
        switch (cbid) {
        case CU_TOOLS_CBID_RESOURCE_DEVICE_MEM_ALLOC:
            status = globalAlloc(gvars, (const CUtoolsDeviceMemAlloc*) inParams);
            break;
        case CU_TOOLS_CBID_RESOURCE_DEVICE_MEM_FREE:
            status = globalFree(gvars, (const CUtoolsDeviceMemFree*) inParams);
            break;
        case CU_TOOLS_CBID_RESOURCE_HOST_MEM_ALLOC:
            status = hostAlloc(gvars, (const CUtoolsHostMemAlloc*) inParams);
            break;
        case CU_TOOLS_CBID_RESOURCE_HOST_MEM_FREE:
            status = hostFree(gvars, (const CUtoolsHostMemFree*) inParams);
            break;
        case CU_TOOLS_CBID_RESOURCE_MODULE_LOADED:
            status = moduleLoaded(gvars, (const CUtoolsModuleLoaded*) inParams);
            break;
        case CU_TOOLS_CBID_RESOURCE_MODULE_UNLOAD_STARTING:
            status = moduleUnloadStarting(gvars, (const CUtoolsModuleUnloadStarting*) inParams);
            break;
        case CU_TOOLS_CBID_RESOURCE_CONTEXT_INITIALIZE_STARTING:
            status = contextInitializeStarting(gvars, (const CUtoolsContextInitializeStarting*) inParams);
            break;
        case CU_TOOLS_CBID_RESOURCE_CONTEXT_CREATED:
            status = contextCreated(gvars, (const CUtoolsContextCreated*) inParams);
            break;
        case CU_TOOLS_CBID_RESOURCE_CONTEXT_DESTROY_STARTING:
            status = contextDestroyStarting(gvars, (const CUtoolsContextDestroyStarting*) inParams);
            break;
        case CU_TOOLS_CBID_RESOURCE_CONTEXT_DESTROY_COMPLETED:
            status = contextDestroyCompleted(gvars, (const CUtoolsContextDestroyCompleted*) inParams);
            break;
        case CU_TOOLS_CBID_RESOURCE_DEVICE_HEAP_SELECTED:
            status = deviceHeapSelected(gvars, (const CUtoolsDeviceHeapSelected*) inParams);
            break;
        case CU_TOOLS_CBID_RESOURCE_CNP_UPDATE_CONSTANTS:
            status = cnpUpdateConstants(gvars, (const CUtoolsCnpUpdateConstants*) inParams);
            break;
        case CU_TOOLS_CBID_RESOURCE_SURF_OBJECT_CREATED:
            status = surfObjectCreated(gvars, (const CUtoolsSurfObjectCreated*)inParams);
            break;
        case CU_TOOLS_CBID_RESOURCE_SURF_OBJECT_DESTROY:
            status = surfObjectDestroy(gvars, (const CUtoolsSurfObjectDestroy*)inParams);
            break;
        case CU_TOOLS_CBID_RESOURCE_STREAM_CREATED:
            status = streamCreated(gvars, (const CUtoolsStreamCreated*) inParams);
            break;
        case CU_TOOLS_CBID_RESOURCE_STREAM_DESTROY_STARTING:
            status = streamDestroyStarting(gvars, (const CUtoolsStreamDestroyStarting*) inParams);
            break;
        case CU_TOOLS_CBID_RESOURCE_FUNCTION_PATCHED:
            status = functionPatched(gvars, (const CUtoolsFunctionPatched*) inParams);
            break;
        case CU_TOOLS_CBID_RESOURCE_GRAPHEXEC_CREATING:
            status = graphexecCreating(gvars, (const CUtoolsGraphExecCreating*) inParams);
            break;
        default:
            break;
        };
        break;
    case CU_TOOLS_CB_DOMAIN_LAUNCH:
        switch (cbid) {
        case CU_TOOLS_CBID_LAUNCH_BEGIN:
            status = launchBeginCallback(gvars, (const CUtoolsLaunchBegin*) inParams);
            break;
        case CU_TOOLS_CBID_LAUNCH_AFTER_SYSCALL_SETUP:
            status = afterSyscallSetupCallback(gvars, (const CUtoolsAfterSyscallSetup*) inParams);
            break;
        case CU_TOOLS_CBID_LAUNCH_BEFORE_LAUNCH_PUSHED:
            status = beforeLaunchPushed(gvars, (const CUtoolsBeforeLaunchPushed*) inParams);
            break;
        case CU_TOOLS_CBID_LAUNCH_AFTER_GRID_LAUNCHED:
            status = afterGridLaunched(gvars, (const CUtoolsAfterGridLaunched*) inParams);
            break;
        case CU_TOOLS_CBID_LAUNCH_END:
            status = launchEndCallback(gvars, (const CUtoolsLaunchEnd*) inParams);
            break;
        default:
            break;
        };
        break;
    case CU_TOOLS_CB_DOMAIN_TRAP:
        switch (cbid) {
        case CU_TOOLS_CBID_TRAP_BEGIN:
            status = trapEvent(gvars, (const CUtoolsTrap*) inParams);
            if (status != CUDA_SUCCESS)
                mode = CC_CLEANUP_MODE_HOST_ONLY;
            break;
        case CU_TOOLS_CBID_TRAP_END:
            status = trapEndEvent(gvars, (const CUtoolsTrap*) inParams);
            if (status != CUDA_SUCCESS)
                mode = CC_CLEANUP_MODE_HOST_ONLY;
            break;
        default:
            break;
        }
        break;
    case CU_TOOLS_CB_DOMAIN_SYNCHRONIZE:
        switch (cbid) {
        case CU_TOOLS_CBID_SYNCHRONIZE_STREAM_SYNCHRONIZED:
            status = streamSynchronized(gvars, (const CUtoolsStreamSynchronized*) inParams);
            break;
        default:
            break;
        }
        break;
    case CU_TOOLS_CB_DOMAIN_MEMCPY:
        switch (cbid) {
        case CU_TOOLS_CBID_MEMCPY_BEGIN:
            status = memcpyBegin(gvars, (const CUtoolsMemcpyBegin*)inParams);
            break;
        case CU_TOOLS_CBID_MEMCPY_END:
            status = memcpyEnd(gvars, (const CUtoolsMemcpyEnd*)inParams);
            break;
        default:
            break;
        }
        break;
    case CU_TOOLS_CB_DOMAIN_MEMSET:
        switch (cbid) {
        case CU_TOOLS_CBID_MEMSET_SETUP_INIT:
            status = memsetSetupInit(gvars, (const CUtoolsMemsetSetupInit*)inParams);
            break;
        default:
            break;
        }
        break;
    case CU_TOOLS_CB_DOMAIN_QMD:
        switch (cbid) {
        case CU_TOOLS_CBID_QMD_BEFORE_LAUNCH:
            status = qmdBeforeLaunch(gvars, (const CUtoolsQmdBeforeLaunch*)inParams);
            break;
        default:
            break;
        }
        break;
    case CU_TOOLS_CB_DOMAIN_TRACE_API_CUDA:
        if (cbid > 0 && cbid < CU_TOOLS_CBID_TRACE_API_CUDA_SIZE) {
            status = checkDriverApiCall(gvars, cbid, (const CUtoolsTraceApiCuda*) inParams,
                                        CU_MEMCHECK_API_TYPE_DRIVER);
        }
        break;
    case CU_TOOLS_CB_DOMAIN_TRACE_API_CUDA_RUNTIME:
        status = checkRuntimeApiCall(gvars, cbid, (const CUtoolsTraceRuntimeApiCuda*)inParams,
                                     CU_MEMCHECK_API_TYPE_RUNTIME);
        break;
    case CU_TOOLS_CB_DOMAIN_CUDA_RUNTIME_INTERNAL:
        status = checkApiCallCudartInternalInit(gvars, cbid, (const CUtoolsTraceRuntimeInternalInit *)inParams);
        break;
    case CU_TOOLS_CB_DOMAIN_TRACE_API_CUDA_ETBL:
        switch (cbid) {
        case CU_TOOLS_CBID_TRACE_API_CUDA_ETBL_ModuleLoadFatBinary:
            status = checkApiCallCudartEtbl_ModuleLoadFatBinary(gvars, (const CUtoolsTraceApiCudaEtbl *)inParams);
            break;
        default:
            break;
        }
        break;
    case CU_TOOLS_CB_DOMAIN_UVM_LITE:
        switch (cbid) {
        case CU_TOOLS_CBID_UVM_LITE_STREAM_ENQUEUE_BEGIN:
            status = uvmLiteStreamEnqueueBegin(gvars, (const CUtoolsUvmLiteStreamOwnerChange *)inParams);
            break;
        case CU_TOOLS_CBID_UVM_LITE_STREAM_ENQUEUE_END:
            status = uvmLiteStreamEnqueueEnd(gvars, (const CUtoolsUvmLiteStreamOwnerChange *)inParams);
            break;
        default:
            break;
        }
        break;
    case CU_TOOLS_CB_DOMAIN_GRAPH:
        switch (cbid) {
        case CU_TOOLS_CBID_GRAPH_LAUNCH_NODE_BEGIN:
            status = graphLaunchNodeBegin(gvars, (const CUtoolsGraphLaunchNodeBegin *)inParams);
            break;
        case CU_TOOLS_CBID_GRAPH_LAUNCH_NODE_END:
            status = graphLaunchNodeEnd(gvars, (const CUtoolsGraphLaunchNodeEnd *)inParams);
            break;
        default:
            break;
        }
        break;
    case CU_TOOLS_CB_DOMAIN_RESOURCE_INTERNAL:
        switch (cbid) {
        case CU_TOOLS_CBID_RESOURCE_INTERNAL_MEMBLOCK_ALLOC:
            status = internalMemblockAlloc(gvars, (const CUtoolsMemBlockAlloc *)inParams);
            break;
        case CU_TOOLS_CBID_RESOURCE_INTERNAL_MEMBLOCK_FREE:
            status = internalMemblockFree(gvars, (const CUtoolsMemBlockFree *)inParams);
            break;
        case CU_TOOLS_CBID_RESOURCE_INTERNAL_HOST_LOCAL_MEM_RESIZE:
            status = internalHostLmemResize(gvars, (const CUtoolsHostLocalMemResize *)inParams);
            break;
        }
        break;
    case CU_TOOLS_CB_DOMAIN_BATCH_MEMOP:
        switch (cbid) {
        case CU_TOOLS_CBID_BATCH_MEMOP_WRITE:
            status = batchMemopWrite(gvars, (const CUtoolsBatchMemop *)inParams);
            break;
        default:
            break;
        }
        break;
    default:
        break;
    };

    /* On any errors: clean up and don't try again */
    /* WAR for bug 1835384: don't cleanup if we're inside the traphandler since
     * that includes device cleanup (even if mode is HOST_ONLY). Long term fix
     * will be to delay device cleanup until it can be done from the main thread */
    if (status != CUDA_SUCCESS && domain != CU_TOOLS_CB_DOMAIN_TRAP) {
        memcheckCleanup(gvars, mode);
    }
#if defined(CUDA_DEVTOOLS_ENABLE_STATS)
        HALO_TIMER_STOP(timer);
        haloTimerPrintCallback(timer, domain, cbid);
#endif
}
