/*
 * Copyright 2007-2014 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: memcheck_tool_modes.c
 *
 *   Description:
 *       Modes for the backend
 *
 ******************************************************************************/

#include "cudamemcheck.h"
#include "check_ir.h"
#include "memcheck_inst_types.h"
#include "memcheck_types.h"
#include "memcheck.h"
#include "racecheck/racecheck.h"
#include "barcheck/barcheck.h"
#include "initcheck/initcheck.h"
#include "memcheck_tool_modes.h"

// In C++ inline cannot be used for symbols with global visibility
#ifndef __cplusplus
inline
#endif
MCtoolModeArchs
getArchFromSmVer(uint32_t sm_version)
{
#if NVCFG(GLOBAL_ARCH_KEPLER)
#if NVCFG(GLOBAL_GPU_FAMILY_GK10X)
    if (sm_version >= 300 && sm_version < 302)
        return MC_TOOL_MODE_ARCH_SM30;
#endif
#if NVCFG(GLOBAL_GPU_FAMILY_GK11X) || NVCFG(GLOBAL_GPU_FAMILY_GK20X)
    else if (sm_version >= 302 && sm_version < 400)
        return MC_TOOL_MODE_ARCH_SM35;
#endif
#endif
#if NVCFG(GLOBAL_ARCH_MAXWELL)
#if NVCFG(GLOBAL_GPU_FAMILY_GM10X)
    else if (sm_version >= 400 && sm_version < 502)
        return MC_TOOL_MODE_ARCH_SM50;
#endif
#if NVCFG(GLOBAL_GPU_FAMILY_GM20X)
    else if (sm_version >= 502 && sm_version < 504)
        return MC_TOOL_MODE_ARCH_SM52;
#endif
#endif
#if NVCFG(GLOBAL_ARCH_PASCAL)
#if NVCFG(GLOBAL_GPU_FAMILY_GP10X)
    else if (sm_version >= 504 && sm_version < 603)
        return MC_TOOL_MODE_ARCH_SM60;
#endif
#endif
#if NVCFG(GLOBAL_ARCH_VOLTA)
// no differentiation between GV10X (SM70) and GV11X (SM72) at the moment
#if NVCFG(GLOBAL_GPU_FAMILY_GV10X) || NVCFG(GLOBAL_GPU_FAMILY_GV11X)
    else if (sm_version >= 700 && sm_version < 703)
        return MC_TOOL_MODE_ARCH_SM70;
#endif
#endif
#if NVCFG(GLOBAL_ARCH_TURING)
    else if (sm_version >= 705 && sm_version < 800)
        return MC_TOOL_MODE_ARCH_SM75;
#endif
#if NVCFG(GLOBAL_ARCH_AMPERE)
    else if (sm_version >= 800 && sm_version < 900)
        return MC_TOOL_MODE_ARCH_SM80;
#endif
    else
        return MC_TOOL_MODE_ARCH_NONE;
}


static CUresult
getCheckTypeMask(MCtoolMode *toolMode, uint32_t sm_version,
                 uint32_t *mask)
{
    MCtoolModeArchs arch;
    CU_TRACE_FUNCTION();

    if (!toolMode || !mask) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    arch = getArchFromSmVer(sm_version);
    if (arch == MC_TOOL_MODE_ARCH_NONE) {
        CU_ERROR_PRINT(("Invalid arch : %u\n", sm_version));
        return CUDA_ERROR_UNKNOWN;
    }

    *mask = toolMode->state.arch[arch].checkMask;

    return CUDA_SUCCESS;
}

static CUresult
getOpTypeMask(MCtoolMode *toolMode, uint32_t sm_version,
              MCcheckTypes type, uint32_t *mask)
{
    MCtoolModeArchs arch;
    CU_TRACE_FUNCTION();

    if (!toolMode || !mask) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    arch = getArchFromSmVer(sm_version);
    if (arch == MC_TOOL_MODE_ARCH_NONE) {
        CU_ERROR_PRINT(("Invalid arch : %u\n", sm_version));
        return CUDA_ERROR_UNKNOWN;
    }

    if (type >= MC_CHECK_TYPE_SIZE) {
        CU_ERROR_PRINT(("Invalid checkType : %u\n", (uint32_t)type));
        return CUDA_ERROR_UNKNOWN;
    }

    *mask = toolMode->state.arch[arch].opMask[type];

    return CUDA_SUCCESS;
}

CUresult
toolModeInitialize(MCtoolModeType type, MCoptions *options, MCtoolMode *toolMode)
{
    CU_TRACE_FUNCTION();

    if (!toolMode || !options) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    memset(toolMode, 0, sizeof(*toolMode));

    // Common state
    toolMode->state.type  = type;

    // Common functions
    toolMode->getCheckTypeMask = getCheckTypeMask;
    toolMode->getOpTypeMask = getOpTypeMask;

    if (type == MC_TOOL_MODE_MEMCHECK) {
        return memcheck_toolModeInitialize(options, toolMode);
    }
    else if (type == MC_TOOL_MODE_RACECHECK) {
        return racecheck_toolModeInitialize(options, toolMode);
    }
    else if (type == MC_TOOL_MODE_BARCHECK) {
        return barcheck_toolModeInitialize(options, toolMode);
    }
    else if (type == MC_TOOL_MODE_INITCHECK) {
        return initcheck_toolModeInitialize(options, toolMode);
    }

    CU_TRACE_PRINT(("No tool mode found \n"));
    return CUDA_SUCCESS;
}

CUresult
toolModeFinalize(MCtoolMode *toolMode)
{
    CU_TRACE_FUNCTION();

    if (!toolMode) {
        CU_ERROR_PRINT(("Invalid Args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    return CUDA_SUCCESS;
}
