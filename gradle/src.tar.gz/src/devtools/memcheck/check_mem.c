/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: memcheck.c
 *
 *   Description:
 *       When enabled, patches CUDA functions to perform
 *       memory access checking
 *
 ******************************************************************************/

#include "check_core.h"
#include "check_mem.h"
#include "memcheck_types.h"
#include "cuda.h"

#include "memobj.h"
#include "halo.h"

/* Wrapped mapping functions for memcheck
   The mapper has the following semantics:
    1. Check the memMapMode
    1.a For HALO mapping,
        If the memseg is funcmem,
            va = memobjGetPc(ctx, memobj)
            return from HALO mapper
        Other memsegs currently unsupported (shouldnt matter anyway)
    1.b For MEMOBJ mapping
        Call memobjMapHost
        and return from GetHost

    1.c For FORCED mapping
        return from GetHost

    Unmapper does the inverse.
*/
static uint64_t
getFuncMemBase(MCcontext *mcctx, CUmemobj *memobj)
{
    if (!mcctx || !memobj)
        return 0;

    return (uint64_t)memrangeGetVaddr(mcctx->cuctx->memmgr->funcMemRange);
}

CUresult
CCMapMemory(MCcontext *mcctx,
            CUmemobj *memobj,
            haloMemorySegmentType memseg,
            void **hostPtr)
{
    CCmemMapMode memMapMode = CC_MEM_MAP_MODE_NONE;
    CUresult status = CUDA_SUCCESS;
    CUDBGResult dbgRes = CUDBG_SUCCESS;
    uint64_t va = 0;
    uint64_t size = 0;

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid Context\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!hostPtr) {
        CU_ERROR_PRINT(("Invalid host ptr\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!memobj) {
        CU_ERROR_PRINT(("Invalid memobj\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    memMapMode = mcctx->gvars->options.memMapMode;

    if (memMapMode == CC_MEM_MAP_MODE_HALO) {
        // Trying to map using the HALO
        size = (uint64_t)memobjGetSize(memobj);
        va = (uint64_t)mcctx->cuctx->device->hal.memobjGetPc(mcctx->cuctx, memobj);

        // Sanity checks, need a size
        if (!size) {
            CU_ERROR_PRINT(("No size for HALO mapping\n"));
            return CUDA_ERROR_UNKNOWN;
        }

        if (memseg == HALO_MEM_SEG_FUNC) {
            va += getFuncMemBase(mcctx, memobj);
            if (!va) {
                CU_ERROR_PRINT(("No va for HALO mapping\n"));
                return CUDA_ERROR_UNKNOWN;
            }
            dbgRes = mcctx->dev->haloClient->mapMemory(mcctx->haloContext,
                                                       va, size,
                                                       (char**)hostPtr);
            return (dbgRes == CUDBG_SUCCESS)? CUDA_SUCCESS: CUDA_ERROR_UNKNOWN;
        }
        else {
            CU_ERROR_PRINT(("Unsupported memory segment type \n"));
            return CUDA_ERROR_UNKNOWN;
        }
    }
    else if (memMapMode == CC_MEM_MAP_MODE_MEMOBJ ||
             memMapMode == CC_MEM_MAP_MODE_FORCED) {

        if (memMapMode == CC_MEM_MAP_MODE_MEMOBJ) {
            status = memobjMapHost(memobj);
            if (status != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Failed to map memobj\n"));
                return status;
            }
        }

        *hostPtr = memobjGetHostPtr(memobj);
        if (!(*hostPtr)) {
            CU_ERROR_PRINT(("Null host pointer returned\n"));
            return CUDA_ERROR_UNKNOWN;
        }

        return status;
    }
    else {
        CU_ERROR_PRINT(("Unknown map mode :%u\n", memMapMode));
        return CUDA_ERROR_UNKNOWN;
    }

    return CUDA_ERROR_UNKNOWN;
}

CUresult
CCUnmapMemory(MCcontext *mcctx, CUmemobj *memobj)
{
    CCmemMapMode memMapMode = CC_MEM_MAP_MODE_NONE;
    CUDBGResult dbgRes = CUDBG_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid context\n"));
        return CUDA_ERROR_UNKNOWN;
    }
    if (!memobj) {
        CU_ERROR_PRINT(("Invalid memobj\n"));
        return CUDA_ERROR_UNKNOWN;
    }


    memMapMode = mcctx->gvars->options.memMapMode;

    if (memMapMode == CC_MEM_MAP_MODE_HALO) {
        dbgRes= mcctx->dev->haloClient->unmapMemory(mcctx->dev);
        if (dbgRes != CUDBG_SUCCESS) {
            CU_ERROR_PRINT(("Failed to unmap memory\n"));
            return CUDA_ERROR_UNKNOWN;
        }

        return CUDA_SUCCESS;
    }
    else if (memMapMode == CC_MEM_MAP_MODE_MEMOBJ) {
        memobjUnmapHost(memobj);
        return CUDA_SUCCESS;
    }
    else if (memMapMode == CC_MEM_MAP_MODE_FORCED) {
        return CUDA_SUCCESS;
    }
    else {
        CU_ERROR_PRINT(("Unknown mem map mode : %u\n", memMapMode));
        return CUDA_ERROR_UNKNOWN;
    }

    return CUDA_ERROR_UNKNOWN;
}

static CUresult
allocDevFuncMem(CCmemHandle *mem, CUtoolsMemBlockHandle memblock)
{
    CUresult r = CUDA_SUCCESS;

    if (!mem || !mem->mcctx)
        return CUDA_ERROR_UNKNOWN;

    r = mem->mcctx->gvars->tools.memory->DriverAllocInstructionRam(
            mem->mcctx->cuctx,
            memblock,
            mem->size,
            &mem->dev.memobj,
            &mem->dev.dPtr);

    if (r != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to allocate instruction mem\n"));
        return r;
    }

    r = mem->mcctx->gvars->tools.memory->MemObjGetDeviceVAddr(
            mem->dev.memobj,
            &mem->dev.devVaddr);

    return r;
}

static CUresult
allocDevGlobalMem(CCmemHandle *mem)
{
    CUresult status = CUDA_SUCCESS;
    CUtoolsMemAllocOptions options;

    if (!mem || !mem->mcctx)
        return CUDA_ERROR_UNKNOWN;

    options.struct_size = sizeof(options);
    options.type = CU_TOOLS_MEM_ALLOC_TYPE_DEVICE;
    options.purpose = CU_TOOLS_MEM_ALLOC_PURPOSE_GENERIC;

    status = mem->mcctx->gvars->tools.memory->MemAlloc(
            mem->mcctx->cuctx,
            (size_t)mem->size,
            &options,
            NULL,
            (void**)&mem->dev.dPtr,
            &mem->dev.memobj);

    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to allocate device memory\n"));
        return status;
    }

    status = mem->mcctx->gvars->tools.memory->MemObjGetDeviceVAddr(
            mem->dev.memobj,
            &mem->dev.devVaddr);

    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to get the device VA of memobj\n"));
        return status;
    }

    return CUDA_SUCCESS;
}

static CUresult
allocDevZerocopyMem(CCmemHandle *mem)
{
    CUresult r = CUDA_SUCCESS;

    if (!mem || !mem->mcctx)
        return CUDA_ERROR_UNKNOWN;

    r = mem->mcctx->gvars->tools.memory->MemHostAllocDeviceMapped(
            mem->mcctx->cuctx,
            (size_t)mem->size,
            (void**)&mem->dev.hPtr,
            (void**)&mem->dev.dPtr,
            &mem->dev.memobj);

    if (r != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to allocate zerocopy memory\n"));
        return r;
    }

    r = mem->mcctx->gvars->tools.memory->MemObjGetDeviceVAddr(
            mem->dev.memobj,
            &mem->dev.devVaddr);
    return r;
}

CUresult
CCallocateDevice(CCmemHandle *mem, CUtoolsMemBlockHandle memblock)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();
    if (!mem) {
        CU_ERROR_PRINT(("Invalid CCmemHandle\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!mem->size) {
        CU_ERROR_PRINT(("Size is 0\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!mem->mcctx) {
        CU_ERROR_PRINT(("Invalid context\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    switch (mem->devseg) {
    case HALO_MEM_SEG_FUNC:
        res = allocDevFuncMem(mem, memblock);
        break;
    case HALO_MEM_SEG_GLOBAL:
        res = allocDevGlobalMem(mem);
        break;
    case HALO_MEM_SEG_PINNED_SYSMEM:
        res = allocDevZerocopyMem(mem);
        break;
    default:
        res = CUDA_ERROR_UNKNOWN;
        break;
    }

    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to allocate memory.\n"));
        memset(&mem->dev, 0, sizeof(mem->dev));
    }
    else
        mem->dev.state = CC_MEM_STATE_ALLOCATED;

    return res;
}

CUresult
CCallocateHost(CCmemHandle *mem)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();
    if (!mem) {
        CU_ERROR_PRINT(("Invalid CCmemHandle\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!mem->size) {
        CU_ERROR_PRINT(("Size is 0\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    mem->host.ptr = calloc(1, (size_t)mem->size);
    if (!mem->host.ptr) {
        CU_ERROR_PRINT(("Failed to allocate memory.\n"));
        res = CUDA_ERROR_OUT_OF_MEMORY;
        memset(&mem->host, 0, sizeof(mem->host));
    }
    else
        mem->host.state = CC_MEM_STATE_ALLOCATED;

    return res;
}

void
CCfreeHost(CCmemHandle *mem)
{

    CU_TRACE_FUNCTION();
    if (!mem) {
        CU_ERROR_PRINT(("Invalid CCmemHandle\n"));
        return;
    }

    // Early return
    if (mem->host.state == CC_MEM_STATE_NONE)
        return;

    if (!mem->size)
        return;

    // Only free what if allocated
    if (mem->host.state == CC_MEM_STATE_ALLOCATED)
        free(mem->host.ptr);
    memset(&mem->host, 0, sizeof(mem->host));
}

static void
freeDevFuncMem(CCmemHandle *mem)
{
    CU_TRACE_FUNCTION();

    if (!mem || !mem->mcctx)
        return;

    if (mem->dev.state != CC_MEM_STATE_ALLOCATED)
        return;

    mem->mcctx->gvars->tools.memory->DriverFreeInstructionRam(
        mem->mcctx->cuctx,
        mem->dev.memobj);
}


static void
freeDevGlobalMem(CCmemHandle *mem)
{
    CU_TRACE_FUNCTION();

    if (!mem || !mem->mcctx)
        return;

    if (mem->dev.state != CC_MEM_STATE_ALLOCATED)
        return;

    mem->mcctx->gvars->tools.memory->MemDeviceFree(
        mem->mcctx->cuctx,
        (void*)(uintptr_t)mem->dev.dPtr);
}

static void
freeDevZerocopyMem(CCmemHandle *mem)
{
    CU_TRACE_FUNCTION();

    if (!mem || !mem->mcctx)
        return;

    if (mem->dev.state != CC_MEM_STATE_ALLOCATED)
        return;

    mem->mcctx->gvars->tools.memory->MemHostFree(
        mem->mcctx->cuctx,
        (void*)(uintptr_t)mem->dev.hPtr);
}

static void
CCfreeDeviceInternal(CCmemHandle *mem)
{

    CU_TRACE_FUNCTION();
    if (!mem) {
        CU_ERROR_PRINT(("Invalid CCmemHandle\n"));
        return;
    }

    // Early return
    if (mem->dev.state == CC_MEM_STATE_NONE)
        return;

    if (!mem->size)
        return;

    if (!mem->mcctx) {
        CU_ERROR_PRINT(("Invalid context\n"));
        return;
    }

    // Only free if this was allocated
    if (mem->dev.state == CC_MEM_STATE_ALLOCATED) {
        switch (mem->devseg) {
        case HALO_MEM_SEG_FUNC:
            freeDevFuncMem(mem);
            break;
        case HALO_MEM_SEG_GLOBAL:
            freeDevGlobalMem(mem);
            break;
        case HALO_MEM_SEG_PINNED_SYSMEM:
            freeDevZerocopyMem(mem);
            break;
        default:
            break;
        }
    }
    memset(&mem->dev, 0, sizeof(mem->dev));
}

static uint32_t
isDeferredDevCleanup(CCmemCleanup *cleanup)
{
    if (!cleanup)
        return 0;

    return !!(cleanup->opts & CC_MEM_CLEANUP_OPTIONS_DEV_DEFERRED);
}

void
CCfreeDevice(CCmemHandle *mem, CCmemCleanup *cleanup)
{
    CCmemHandle *clone = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;

    if (!cleanup || !isDeferredDevCleanup(cleanup)) {
        /* Early checks. If the cleanup structure is not defined
           or if we are not doing a deferred cleanup, clean this up
           immediately */
        CCfreeDeviceInternal(mem);
        return;
    }
    else if (isDeferredDevCleanup(cleanup)) {
        /* The cleanup has requested deferral. Usually, this means
           that the cleanup was called under a memcheck lock that prevents
           us from calling into the driver and acquiring the driver's lock */
        clone = (CCmemHandle *)calloc(1, sizeof(*clone));
        if (!clone) {
            CU_ERROR_PRINT(("Failed to clone memhandle\n"));
            return;
        }
        /* Copy the data into the clone, as we normally store the memhandles
           in a struct that might be gone when the deferred cleanup gets called */
        memcpy(clone, mem, sizeof(*clone));

        /* Reset the original pointer. To the higher levels, this will mimic
           a free */
        memset(&mem->dev, 0, sizeof(mem->dev));

        /* If the deferred cleanup list has not been initialized, create it */
        if (!cleanup->devDeferredList) {
            cleanup->devDeferredList = toolsListNew();
            if (!cleanup->devDeferredList) {
                CU_ERROR_PRINT(("Failed to create deferred list\n"));
                free(clone);
                return;
            }
        }
        tres = toolsListAppend(cleanup->devDeferredList, clone);
        if (tres != TOOLS_SUCCESS) {
            CU_ERROR_PRINT(("Failed when appending cloned handle to list\n"));
            free(clone);
            return;
        }
    }
}

CUresult
CCinitFromCufuncStream(CCmemHandle *mem, CUfunc* cufunc, MCcontext *mcctx, CUtoolsStreamHandle stream, CCmemShadowAction action)
{
    CUresult status = CUDA_SUCCESS;
    MCglobals *gvars = NULL;
    CUtoolsFunctionMemObjHandles handles;

    CU_TRACE_FUNCTION();

    if (!mem || !cufunc || !mcctx || action == CC_MEM_SHADOW_ACTION_NONE) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    gvars = mcctx->gvars;

    memset(mem, 0, sizeof(*mem));
    mem->mcctx  = mcctx;
    mem->devseg = HALO_MEM_SEG_FUNC;

    handles.struct_size = sizeof(handles);
    status = gvars->tools.module->FunctionGetMemObjHandles(cufunc, &handles);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("FunctionGetMemObjHandles failed\n"));
        return status;
    }

    /* Read directly from the memobj */
    mem->dev.memobj = handles.hMemObjInstructions;
    mem->size = memobjGetSize((CUmemobj*)mem->dev.memobj);

    /* Fill in the device information */
    status = gvars->tools.module->FunctionGetLaunchPc(cufunc, &mem->dev.dPtr);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to get device launch PC\n"));
        return status;
    }
    mem->dev.state = CC_MEM_STATE_PREINITIALIZED;

    status = mem->mcctx->gvars->tools.memory->MemObjGetDeviceVAddr(
                mem->dev.memobj,
                &mem->dev.devVaddr);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to assign devVaddr for mem obj\n"));
        return status;
    }

    if (action == CC_MEM_SHADOW_ACTION_MAP ||
        action == CC_MEM_SHADOW_ACTION_MEMCPY ||
        action == CC_MEM_SHADOW_ACTION_TOOLSAPI_QUERY_BUFFER) {
        status = CCallocateHost(mem);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to allocate function copy\n"));
            return status;
        }
    }

    /* Use the action to do some work */
    if (action == CC_MEM_SHADOW_ACTION_MAP ||
        action == CC_MEM_SHADOW_ACTION_MEMCPY) {
        status = CCmemShadowDtoHStream(mem, mem, stream, action);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to read function from device using :%u\n", action));
            return status;
        }
    }
    else if (action == CC_MEM_SHADOW_ACTION_TOOLSAPI_QUERY) {
        status = gvars->tools.module->FunctionGetInstructions(mcctx->cuctx,
                                                              cufunc, 1,
                                                              (const void**)&mem->host.ptr,
                                                              (uint32_t*)&mem->size);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to read function from device using toolsapi\n"));
            return status;
        }
        mem->host.state = CC_MEM_STATE_PREINITIALIZED;
    }
    else if (action == CC_MEM_SHADOW_ACTION_TOOLSAPI_QUERY_BUFFER) {
        char* hostPtr;

        status = gvars->tools.module->FunctionGetInstructions(mcctx->cuctx,
                                                              cufunc, 1,
                                                              (const void**)&hostPtr,
                                                              (uint32_t*)&mem->size);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to read function from device using toolsapi\n"));
            return status;
        }

        /* Copy into the buffer */
        memcpy((char*)mem->host.ptr, hostPtr, (size_t)mem->size);
    }

    return status;
}

CUresult
CCmemShadowHtoDStream(CCmemHandle *srcMem, CCmemHandle *dstMem, CUtoolsStreamHandle stream, CCmemShadowAction action)
{
    CUresult status = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!srcMem || !dstMem || action == CC_MEM_SHADOW_ACTION_NONE) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!dstMem->mcctx || !srcMem->mcctx) {
        CU_ERROR_PRINT(("Invalid context\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!srcMem->size || !dstMem->size) {
        CU_ERROR_PRINT(("MemHandle of 0 size\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (srcMem->size > dstMem->size) {
        CU_ERROR_PRINT(("Source is too large for destination\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!srcMem->host.ptr || srcMem->host.state == CC_MEM_STATE_NONE) {
        CU_ERROR_PRINT(("Invalid host pointer\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!dstMem->dev.memobj ||
        dstMem->dev.state == CC_MEM_STATE_NONE) {
        CU_ERROR_PRINT(("Invalid device Dptr\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (action == CC_MEM_SHADOW_ACTION_MAP) {
        /* Ensure mapMemory+memcpy is atomic */
        cuosEnterCriticalSection(&haloGlobals.mapMemory_cs);

        status = CCMapMemory(dstMem->mcctx,
                             (CUmemobj*)dstMem->dev.memobj,
                             dstMem->devseg,
                             &dstMem->dev.hPtr);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to map device buffer.\n"));
            cuosLeaveCriticalSection(&haloGlobals.mapMemory_cs);
            return status;
        }

        haloMemcpy(dstMem->dev.hPtr, srcMem->host.ptr, (size_t)srcMem->size);

        status = CCUnmapMemory(dstMem->mcctx, (CUmemobj*)dstMem->dev.memobj);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to unmap device buffer.\n"));
            cuosLeaveCriticalSection(&haloGlobals.mapMemory_cs);
            return status;
        }

        cuosLeaveCriticalSection(&haloGlobals.mapMemory_cs);
    }
    else if (action == CC_MEM_SHADOW_ACTION_MEMCPY) {
        status = cuiMemcpyHtoD(dstMem->mcctx->cuctx,
                               (CUmemobj*)dstMem->dev.memobj,
                               0,
                               srcMem->host.ptr,
                               srcMem->size,
                               (CUIstream*)stream,
                               CUI_MEMCPY_SYNCHRONOUS,
                               NULL);

        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to copy from host to device\n"));
            return status;
        }
    }

    return status;
}

CUresult
CCmemShadowDtoHStream(CCmemHandle *srcMem, CCmemHandle *dstMem, CUtoolsStreamHandle stream, CCmemShadowAction action)
{
    CUresult status = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!srcMem || !dstMem || action == CC_MEM_SHADOW_ACTION_NONE) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!dstMem->mcctx || !srcMem->mcctx) {
        CU_ERROR_PRINT(("Invalid context\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!srcMem->size || !dstMem->size) {
        CU_ERROR_PRINT(("MemHandle of 0 size\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (srcMem->size > dstMem->size) {
        CU_ERROR_PRINT(("Source is too large for destination\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!dstMem->host.ptr || dstMem->host.state == CC_MEM_STATE_NONE) {
        CU_ERROR_PRINT(("Invalid host pointer\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!srcMem->dev.memobj ||
        srcMem->dev.state == CC_MEM_STATE_NONE) {
        CU_ERROR_PRINT(("Invalid device Dptr\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (action == CC_MEM_SHADOW_ACTION_MAP) {
        /* Ensure mapMemory+memcpy is atomic */
        cuosEnterCriticalSection(&haloGlobals.mapMemory_cs);

        status = CCMapMemory(srcMem->mcctx,
                             (CUmemobj*)srcMem->dev.memobj,
                             srcMem->devseg,
                             &srcMem->dev.hPtr);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to map device buffer.\n"));
            cuosLeaveCriticalSection(&haloGlobals.mapMemory_cs);
            return status;
        }

        haloMemcpy(dstMem->host.ptr, srcMem->dev.hPtr, (size_t)srcMem->size);

        status = CCUnmapMemory(srcMem->mcctx, (CUmemobj*)srcMem->dev.memobj);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to unmap device buffer.\n"));
            cuosLeaveCriticalSection(&haloGlobals.mapMemory_cs);
            return status;
        }

        cuosLeaveCriticalSection(&haloGlobals.mapMemory_cs);
    }
    else if (action == CC_MEM_SHADOW_ACTION_MEMCPY) {
        status = cuiMemcpyDtoH(srcMem->mcctx->cuctx,
                               dstMem->host.ptr,
                               (CUmemobj*)srcMem->dev.memobj,
                               0,
                               srcMem->size,
                               (CUIstream*)stream,
                               CUI_MEMCPY_SYNCHRONOUS,
                               NULL);

        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to copy from host to device\n"));
            return status;
        }
    }

    return status;
}

CUresult
CCrunDeferredCleanups(CCmemCleanup *cleanup)
{
    tListItr *li = NULL;
    CCmemHandle *mh = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!cleanup) {
        CU_TRACE_PRINT(("Nothing to cleanup. Cleanup handle was NULL\n"));
        return CUDA_SUCCESS;
    }

    if (!toolsListSize(cleanup->devDeferredList)) {
        CU_TRACE_PRINT(("Nothing to cleanup. No deferred entries found\n"));
        return CUDA_SUCCESS;
    }

    for (li = toolsListGetIterator(cleanup->devDeferredList);
         li;
         li = toolsListGetNext(li)) {
        mh = (CCmemHandle*)toolsListGetElem(li);
        if (mh) {
            CCfreeDeviceInternal(mh);
            free(mh);
        }
    }

    tres = toolsListDelete(cleanup->devDeferredList, NULL, NULL);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to delete deferred list\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    memset(cleanup, 0, sizeof(*cleanup));

    return CUDA_SUCCESS;
}

