/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: kepler_gk10x_hal.c
 *
 *   Description:
 *       The HAL implementation for Kepler GK10X
 *
 ******************************************************************************/
#include "memcheck_types.h"

// Include this for the system stack limit and the DCI offset
#include "cui/hal/kepler/kepler_structs.h"

#define KEPLER_BREAKPT64 0xd00000000400c007ULL
#define KEPLER_GK10X_TEXDEPBAR 0xF000000000001C06ULL

#include "fermi_opcodes.h"

#include "class/cla0c0qmd.h"

static void
kepler_getBreakInstruction(MCrec *rec, uint64_t *out)
{
    //From debugger/halo/kepler_gk104.c
    *out = KEPLER_BREAKPT64;
}

static void
kepler_getTexDepBar(MCrec *rec, uint64_t *out)
{
    *out = KEPLER_GK10X_TEXDEPBAR;
}

static bool
is_gtas_ld(const uint64_t *inst)
{
    uint64_t tmp = *inst;

    if (IS_NARROW(tmp)) {
        // We can't handle narrow instructions yet
        return false;
    }

    tmp &= FERMI64_MASK;

    if (tmp == LD)
        return true;

    return false;
}

static void
kepler_gk10x_setRegCountInQmd(NvU32 *qmdData, unsigned int regCount)
{
    ASSIGN_HWVALUE_MW(qmdData, A0C0, QMDV00_06, REGISTER_COUNT, regCount);
}

void memcheckInitHal_kepler_gk10x(MChal *hal, MCtoolModeArchs arch)
{
    memcheckInitHal_fermi(hal, arch);
    hal->savedSPAddr        = CU_KEPLER_THREAD_STATE_OFFSET(savedUserStackPointer);
    hal->isGtasLd         = is_gtas_ld;

    hal->genBreakInstruction = kepler_getBreakInstruction;
    hal->genTexDrainInstruction = kepler_getTexDepBar;
    hal->cnpReservedLmemStart = CU_KEPLER_THREAD_STATE_POINTER;
    hal->cnpReservedLmemSize  = CU_KEPLER_LMEM_THREAD_STATE_SIZE;

    hal->gridParamsConstBank = CU_KEPLER_PARAM_CONST_SEGMENT;
    hal->gridParamsUserStackTopOffset = CU_KEPLER_DCI_OFFSET(userStackPointer);

    hal->setRegCountInQmd   = kepler_gk10x_setRegCountInQmd;
}
