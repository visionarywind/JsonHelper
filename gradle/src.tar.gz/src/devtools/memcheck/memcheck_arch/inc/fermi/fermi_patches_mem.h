/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: fermi_patches_mem.h
 *
 *   Description:
 *      Common across all memcheck patch types
 *
 ******************************************************************************/

#ifndef _FERMI_PATCHES_MEM_H
#define _FERMI_PATCHES_MEM_H

#include "cuda_inttypes.h"
#include "cudamemcheck.h"
#include "memcheck.h"
#include "memcheck_inst_types.h"

#include "fermi_opcodes.h"
#include "fermi_mcinterop.h"

static uint64_t memcheckPatchCheck[] = {
    LDL128(R12, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+48),
    LDL128(R8, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+32),
#define PATCH_OK_ENTRY_LO 2
    /* The epilogue from the checker. It's here to put it in a known
       location before the variable part of the checker.

     Ok:
        restore predicates and CC
        restore R0-R7
        ret */

    LDL(R7, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+84),
    R2P(R7),
    LDL128(R4, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+16),
    LDL128(R0, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH),
    RET,

#define PATCH_FAIL_ENTRY 7
    /* This patch does not use ST_E_128 anymore due to bug 712753 */

    /* Fail:

       Needs to grab the lock
       if (winner) {
          write blockIdx.x
          write blockIdx.y
          write blockIdx.z
          write threadIdx.xyz
          write pc into R6

          write memaddr
       }

       <<<optional Break>>>

       goto Ok;

       In Fermi SASS:

       struct {
          uint64_t memaddr;
          uint32_t lockbit;
          uint32_t pc;

          uint32_t threadIdx_xyz;
          uint32_t blockIdx_x;
          uint32_t blockIdx_y;
          uint32_t blockIdx_z;
       } fermi_error;

         mov32i           r4=address_lo
         mov32i           r5=address_hi
         mov32i           r2=1
         atom.e.or        r6=[r4+28], r2        // atomicOr(p,1)
         isetp.eq.u32.and p0=pt, r6, rz, pt
     @p0 st32.e          [r4]=r0
     @p0 st32.e          [r4+4]=r1
     @p0 st32.e          [r4+8]=r2
     @p0 st32.e          [r4+12]=r3
         s2r              r0=sr32
     @p0 st32.e          [r4+16]=r0
         s2r              r0=sr37
     @p0 st32.e          [r4+20]=r0
         s2r              r0=sr38
     @p0 st32.e          [r4+24]=r0
         s2r              r0=sr39
     @p0 st32.e          [r4+28]=r0
         bra              Ok
        */
    LDL(R2, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH + FERMI_LMEM_MEMCHECK_MAGIC),
    OR32I(R2, R2, FERMI_MEMCHECK_WHITEMAGIC),
    STL(RZ,FERMI_LMEM_HI_MEMCHECK_SCRATCH+FERMI_LMEM_MEMCHECK_MAGIC,R2),
#define PATCH_FAIL_ERROR_LOC 10
    MOV32I(R4,0x76543210),
    MOV32I(R5,0xFEDCBA98),
    ATOM_E_OR_U32(R6,R4,28,R2),
    ISETP_U32_AND(CC_EQ, P0, R6, RZ),
    PRED(P0,ST_E32(R4,0,R0)),
    PRED(P0,ST_E32(R4,4,R1)),
    PRED(P0,ST_E32(R4,8,R2)),
    PRED(P0,ST_E32(R4,12,R3)),
    S2R(R0,32),
    PRED(P0,ST_E32(R4,16,R0)),
    S2R(R0,37),
    PRED(P0,ST_E32(R4,20,R0)),
    S2R(R0,38),
    PRED(P0,ST_E32(R4,24,R0)),
    S2R(R0,39),
    PRED(P0,ST_E32(R4,28,R0)),
#define PATCH_FAIL_BREAK 26

    EXIT,      // Will be patched to BPT.TRAP if nonblocking is on
    EXIT,      // This will be hit on a continue
#define PATCH_OK_BRA 28
    BRA(/*Ok*/-27 * 8),


    /* Check:  // R0.R1 = memaddr, R2 = alignment mask, R3 = pc, R7 = pred/cc */
#define PATCH_CHECK_ENTRY 29

    /* The rest of the checker is dynamically generated */
};

static uint64_t
memcheckPatchCheckAlign[] = {
    /*  check the mask (Remember, this whole operation is a no-op if !P0) */

    AND_CC(R2, R2, R0),
    PRED(P0,CC(CC_NE,BRA(/*Fail*/ -24 * 8))),
};

/* A draft of the worst-case stub. The _actual_ stub is complete
   generated on the fly by patchInstructions, so only the size of
   memcheckPatchStub matters, not it's contents. */

static uint64_t memcheckPatchStubWithAbi[] = {
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH,0),
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+4,1),
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+8,2),
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+12,3),
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+16,4),
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+20,5),
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+24,6),
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+28,7),
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+32,8),    //Only added if ABI enabled
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+36,9),    //Only added if ABI enabled
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+40,10),   //Only added if ABI enabled
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+44,11),   //Only added if ABI enabled
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+48,12),   //Only added if ABI enabled
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+52,13),   //Only added if ABI enabled
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+56,14),   //Only added if ABI enabled
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+60,15),   //Only added if ABI enabled
    MOV(R0, R4),
    MOV(R1, R5),
    P2R(R7),
    IADD32I_CC(R0, R0, 1234),
    IADD32I_X(R1, R1, (int64_t) 1234 >> 32),
    MOV32I(R2,  69),
    MOV32I(R3,   7),
    ISETP_U32_FULL(CC_EQ, P0, PT, RZ, RZ, P5), // Copy the predicate
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+64,0),    //Spill AddressLo
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+68,1),    //Spill AddressHi
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+72,3),    //Spill InstAddrLo
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+76,4),    //Spill InstAddrHi
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+80,2),    //Spill Alignment
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+84,7),    //Spill saved predicate
    MOV32I(5, 0),                                   // Move the address type
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+92,5),    // Save the address type
    JCAL(0), // Call the check routine
    0, // The original load
    JMP_ABS(0), // The jump back
};

static uint64_t memcheckPatchStubWithoutAbi[] = {
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH,0),
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+4,1),
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+8,2),
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+12,3),
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+16,4),
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+20,5),
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+24,6),
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+28,7),
    MOV(R0, R4),
    MOV(R1, R5),
    P2R(R7),
    IADD32I_CC(R0, R0, 1234),
    IADD32I_X(R1, R1, (int64_t) 1234 >> 32),
    MOV32I(R2,  69),
    MOV32I(R3,   7),
    ISETP_U32_FULL(CC_EQ, P0, PT, RZ, RZ, P5), // Copy the predicate
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+64,0),    //Spill AddressLo
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+68,1),    //Spill AddressHi
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+72,3),    //Spill InstAddrLo
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+76,4),    //Spill InstAddrHi
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+80,2),    //Spill Alignment
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+84,7),    //Spill saved predicate
    MOV32I(5, 0),                                   // Move the address type
    STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+92,5),    // Save the address type
    JCAL(0), // Call the check routine
    0, // The original load
    JMP_ABS(0), // The jump back
};

static uint64_t memcheckRangeCheckEnd[] = {
    /* If we reach the end, we deem it an illegal access.

     VERY IMPORTANT: in general, memcheck must not use predicated
     branches as it can create control flow divergence and lead to
     changing program semantics (this was bug 687852). However, here
     we are ready to abandon the execution anyway, so it doesn't
     really matter. This is yet another reasons why the --error flag
     doesn't really work in practice and should only be used
     internally. */
    PRED(P0,BRA(0)),

    /* Branch back to the restore portion of the stub. When ABI support is
       enabled, we need to restore R0..R15. This means the jump must be
       to the top of the check stub. If not, we jump to two instructions
       after the top, and restore only R0..R7 */

    BRA(8)
};



#endif
