/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: fermi_patches.h
 *
 *   Description:
 *       Main code for fermi patch types. This defines the fermi specific
 *       type manager initialization function. This is used to change
 *       the default initialization pointer to a particular check type
 *
 ******************************************************************************/

#ifndef _FERMI_PATCHES_H
#define _FERMI_PATCHES_H

#include "memcheck_inst_types.h"
#include "memcheck_types.h"
#include "memcheck.h"

// Initialization bootstrap for inst manager
CUresult fermi_initTypeManager(MCcontext *mcctx, MCinstManager *mgr);

CUresult fermi_global_checkType_bootstrap(MCinstManager *instMgr, MCcheckType *type);
CUresult fermi_shared_checkType_bootstrap(MCinstManager *instMgr, MCcheckType *type);
CUresult fermi_local_checkType_bootstrap(MCinstManager *instMgr, MCcheckType *type);

// Bootstrap for race checktype
CUresult fermi_race_checkType_bootstrap(MCinstManager *instMgr, MCcheckType *type);

// Bootstrap for barcheck checktype
CUresult fermi_barcheck_checkType_bootstrap(MCinstManager *instMgr, MCcheckType *type);

// Bootstrap for initcheck checktype
CUresult fermi_initcheck_checkType_bootstrap(MCinstManager *instMgr, MCcheckType *type);

// Bootstrap for common memchecktypes
CUresult fermi_mem_bootstrap(MCinstManager *instMgr, MCcheckType *type);

// Generate the stub jcal for memcheck checktypes
uint64_t* fermi_mem_genStubJcal(MCcheckType *checkType, MCrec *rec,
                                CCIRinstOpcodes instType,
                                uint64_t *patchCode,
                                uint32_t checkTarget,
                                uint32_t instrAddr);

#endif
