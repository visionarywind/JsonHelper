/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: maxwell_gm10x_patches_common.h
 *
 *   Description:
 *      Common for patch types
 *
 ******************************************************************************/

#ifndef _MAXWELL_PATCHES_COMMON_H
#define _MAXWELL_PATCHES_COMMON_H

#include "cuda_inttypes.h"
#include "devtools/common/assembler/gm10x_sass.h"

/* More duplication */

enum gm10x_sass_reg {  R0,   R1,   R2,   R3,   R4,   R5,   R6,   R7,
                       R8,   R9,  R10,  R11,  R12,  R13,  R14,  R15,
                       R16,  R17,  R18,  R19,  R20,  R21,  R22,  R23,
                       R24,  R25,  R26,  R27,  R28,  R29,  R30,  R31,
                       R32,  R33,  R34,  R35,  R36,  R37,  R38,  R39,
                       R40,  R41,  R42,  R43,  R44,  R45,  R46,  R47,
                       R48,  R49,  R50,  R51,  R52,  R53,  R54,  R55,
                       R56,  R57,  R58,  R59,  R60,  R61,  R62,  R63,
                       R64,  R65,  R66,  R67,  R68,  R69,  R70,  R71,
                       R72,  R73,  R74,  R75,  R76,  R77,  R78,  R79,
                       R80,  R81,  R82,  R83,  R84,  R85,  R86,  R87,
                       R88,  R89,  R90,  R91,  R92,  R93,  R94,  R95,
                       R96,  R97,  R98,  R99, R100, R101, R102, R103,
                       R104, R105, R106, R107, R108, R109, R110, R111,
                       R112, R113, R114, R115, R116, R117, R118, R119,
                       R120, R121, R122, R123, R124, R125, R126, R127,
                       R128, R129, R130, R131, R132, R133, R134, R135,
                       R136, R137, R138, R139, R140, R141, R142, R143,
                       R144, R145, R146, R147, R148, R149, R150, R151,
                       R152, R153, R154, R155, R156, R157, R158, R159,
                       R160, R161, R162, R163, R164, R165, R166, R167,
                       R168, R169, R170, R171, R172, R173, R174, R175,
                       R176, R177, R178, R179, R180, R181, R182, R183,
                       R184, R185, R186, R187, R188, R189, R190, R191,
                       R192, R193, R194, R195, R196, R197, R198, R199,
                       R200, R201, R202, R203, R204, R205, R206, R207,
                       R208, R209, R210, R211, R212, R213, R214, R215,
                       R216, R217, R218, R219, R220, R221, R222, R223,
                       R224, R225, R226, R227, R228, R229, R230, R231,
                       R232, R233, R234, R235, R236, R237, R238, R239,
                       R240, R241, R242, R243, R244, R245, R246, R247,
                       R248, R249, R250, R251, R252, R253, R254, R255,
                       RZ = 255
                    };

enum gm10x_sass_pred {P0, P1, P2, P3, P4, P5, P6, P7,
                      NOT_P0, NOT_P1, NOT_P2, NOT_P3, NOT_P4, NOT_P5, NOT_P6, NOT_P7,

                      // Aliases
                      PT = P7,
                      NOT_PT = NOT_P7
                     };

enum gm10x_sass_icmp {
    CMP_EQ = GM10X_KEYWORD_ICMPALL_EQ,
    CMP_F  = GM10X_KEYWORD_ICMPALL_F,
    CMP_GE = GM10X_KEYWORD_ICMPALL_GE,
    CMP_GT = GM10X_KEYWORD_ICMPALL_GT,
    CMP_LE = GM10X_KEYWORD_ICMPALL_LE,
    CMP_LT = GM10X_KEYWORD_ICMPALL_LT,
    CMP_NE = GM10X_KEYWORD_ICMPALL_NE,
    CMP_T  = GM10X_KEYWORD_ICMPALL_T,
};

enum gm10x_sass_test {
    TEST_F   = GM10X_KEYWORD_TEST_F,
    TEST_LT  = GM10X_KEYWORD_TEST_LT,
    TEST_EQ  = GM10X_KEYWORD_TEST_EQ,
    TEST_GT  = GM10X_KEYWORD_TEST_GT,
    TEST_NE  = GM10X_KEYWORD_TEST_NE,
    TEST_GE  = GM10X_KEYWORD_TEST_GE,
    TEST_LEG = GM10X_KEYWORD_TEST_LEG,
    TEST_NAN = GM10X_KEYWORD_TEST_NAN,
    TEST_LTU = GM10X_KEYWORD_TEST_LTU,
    TEST_EQU = GM10X_KEYWORD_TEST_EQU,
    TEST_LEU = GM10X_KEYWORD_TEST_LEU,
    TEST_GTU = GM10X_KEYWORD_TEST_GTU,
    TEST_NEU = GM10X_KEYWORD_TEST_NEU,
    TEST_GEU = GM10X_KEYWORD_TEST_GEU,
    TEST_T   = GM10X_KEYWORD_TEST_T,

};

enum gm10x_sass_lop {
    LOP_AND = GM10X_KEYWORD_LOP_AND,
    LOP_OR  = GM10X_KEYWORD_LOP_OR,
    LOP_XOR = GM10X_KEYWORD_LOP_XOR,
};

#define GM10X_PRED(pg, inst) ( ((inst) & ~(BF_MASK(GM10X_FIELD_Pred) | BF_MASK(GM10X_FIELD_PredNot))) | (BF_FLDV(GM10X_FIELD_Pred,pg) | BF_FLDV(GM10X_FIELD_PredNot, pg>>3)))

/* Some op definitions to speed up dev */
#define GM10X_LDL128(Rd, Ra, Imm) ( GM10X_INST_LDL_ALL(PT, GM10X_KEYWORD_LLOADCACHEOP_CA, GM10X_KEYWORD_CINTEGER_128, Rd, Ra, Imm) )
#define GM10X_LDL(Rd, Ra, Imm) ( GM10X_INST_LDL_ALL(PT, GM10X_KEYWORD_LLOADCACHEOP_CA, GM10X_KEYWORD_CINTEGER_32, Rd, Ra, Imm) )
#define GM10X_R2P(Ra) ( GM10X_INST_R2P_IMM(GM10X_KEYWORD_CCPR_PR, Ra) )
#define GM10X_R2C(Ra) ( GM10X_INST_R2P_IMM_ALL(PT, GM10X_KEYWORD_CCPR_CC, Ra, GM10X_KEYWORD_B3B0_B3, 0xFFU) )

#define GM10X_P2R(Rd, Ra) ( GM10X_INST_P2R_IMM(Rd, GM10X_KEYWORD_CCPR_PR, Ra, 0xFFU))
#define GM10X_C2R(Rd, Ra) ( GM10X_INST_P2R_IMM_ALL(PT, GM10X_KEYWORD_B3B0_B3, Rd, GM10X_KEYWORD_CCPR_CC, Ra, 0xFFU) )

#define GM10X_STL(Ra, Imm, Rb) ( GM10X_INST_STL_ALL(PT, GM10X_KEYWORD_STORECACHEOP_WB, GM10X_KEYWORD_CINTEGER_32, Ra, Imm, Rb) )
#define GM10X_STL64(Ra, Imm, Rb) ( GM10X_INST_STL_ALL(PT, GM10X_KEYWORD_STORECACHEOP_WB, GM10X_KEYWORD_CINTEGER_64, Ra, Imm, Rb) )
#define GM10X_STL128(Ra, Imm, Rb) ( GM10X_INST_STL_ALL(PT, GM10X_KEYWORD_STORECACHEOP_WB, GM10X_KEYWORD_CINTEGER_128, Ra, Imm, Rb) )

#define GM10X_ATOM32_X_OR(Rd, Ra, Imm, Rb) ( GM10X_INST_ATOM_ALL(PT, GM10X_KEYWORD_E_E, GM10X_KEYWORD_ATOMOP_OR , GM10X_KEYWORD_SQINTEGER_U32, Rd, Ra, Imm, Rb) )

#define GM10X_ISETP(op, Pd, Ra, Rb) ( GM10X_INST_ISETP_ALL(PT, op, GM10X_KEYWORD_X_NOX, GM10X_KEYWORD_BOP_AND, Pd, PT, Ra, Rb, PT, 0) )
#define GM10X_ISETP_AND(op, Pd, Ra, Rb, Ps) ( GM10X_INST_ISETP_ALL(PT, op, GM10X_KEYWORD_X_NOX, GM10X_KEYWORD_BOP_AND, Pd, PT, Ra, Rb, Ps, (Ps >> 3) ) )
#define GM10X_ISETP_AND_PV(op, Pu, Pv, Ra, Rb, Ps) ( GM10X_INST_ISETP_ALL(PT, op, GM10X_KEYWORD_X_NOX, GM10X_KEYWORD_BOP_AND, Pu, Pv, Ra, Rb, Ps, (Ps >> 3)) )
#define GM10X_ISETP_AND_S32(op, Pd, Ra, Rb, Ps) (( GM10X_INST_ISETP_ALL(PT, op, GM10X_KEYWORD_X_NOX, GM10X_KEYWORD_BOP_AND, Pd, PT, Ra, Rb, Ps, (Ps >> 3) ) ) | GM10X_SET_FIELD_nA7(1))
#define GM10X_ISETP_AND_U32(op, Pd, Ra, Rb, Ps) (( GM10X_INST_ISETP_ALL(PT, op, GM10X_KEYWORD_X_NOX, GM10X_KEYWORD_BOP_AND, Pd, PT, Ra, Rb, Ps, (Ps >> 3) ) ) | GM10X_SET_FIELD_nA7(0))
#define GM10X_ISETP_AND_PV_S32(op, Pu, Pv, Ra, Rb, Ps) (( GM10X_INST_ISETP_ALL(PT, op, GM10X_KEYWORD_X_NOX, GM10X_KEYWORD_BOP_AND, Pu, Pv, Ra, Rb, Ps, (Ps >> 3)) ) | GM10X_SET_FIELD_nA7(1))
#define GM10X_ISETP_X(op, Pd, Ra, Rb) ( GM10X_INST_ISETP_ALL(PT, op, GM10X_KEYWORD_X_X, GM10X_KEYWORD_BOP_AND, Pd, PT, Ra, Rb, PT, 0) )

#define GM10X_ISET(op, Rd, Ra, Rb) ( GM10X_INST_ISET(op, GM10X_KEYWORD_BOP_AND, Rd, Ra, Rb, PT, 0) )

#define GM10X_STG32_X(Ra, Imm, Rb) ( GM10X_INST_STG_ALL(PT, GM10X_KEYWORD_E_E, GM10X_KEYWORD_STORECACHEOP_WB, GM10X_KEYWORD_CINTEGER_32, Ra, (Imm), Rb) )

#define GM10X_LOP_CC(op, Rd, Ra, Rb) ( GM10X_INST_LOP_ALL(PT,op,GM10X_KEYWORD_X_NOX, GM10X_KEYWORD_POP_F, PT, Rd, GM10X_KEYWORD_OPTCC_CC, Ra, GM10X_KEYWORD_UNARYINV_NOINV, Rb, GM10X_KEYWORD_UNARYINV_NOINV)  )

#define GM10X_BRA_CC(cctest, imm) ( GM10X_INST_BRA_ALL(PT, GM10X_KEYWORD_U_NOU, GM10X_KEYWORD_LMT_NOLMT, cctest, imm) )

#define GM10X_BRA_U(pred, imm) ( GM10X_INST_BRA_ALL(pred, GM10X_KEYWORD_U_U, GM10X_KEYWORD_LMT_NOLMT, GM10X_KEYWORD_TEST_T, imm) )

#define GM10X_IADD32I_CC(Rd, Ra, Imm) ( GM10X_INST_IADD32I_ALL(PT, GM10X_KEYWORD_SAT_NOSAT, GM10X_KEYWORD_X_NOX, Rd, GM10X_KEYWORD_OPTCC_CC, Ra, Imm) )

#define GM10X_IADD32I_X(Rd, Ra, Imm) ( GM10X_INST_IADD32I_ALL(PT, GM10X_KEYWORD_SAT_NOSAT, GM10X_KEYWORD_X_X, Rd, GM10X_KEYWORD_OPTCC_NOCC, Ra, Imm) )

#define GM10X_LOP(lop, Rd, Ra, Rb) ( GM10X_INST_LOP(lop, Rd, Ra, GM10X_KEYWORD_UNARYINV_NOINV, Rb, GM10X_KEYWORD_UNARYINV_NOINV) )

#define GM10X_LOP32I(lop, Rd, Ra, Imm) ( GM10X_INST_LOP32I(lop, Rd, Ra, GM10X_KEYWORD_UNARYINV_NOINV, Imm) )

#define GM10X_IADD_NEGB_CC(Rd, Ra, Rb) ( GM10X_INST_IADD(Rd, Ra, Rb) | GM10X_SET_FIELD_WriteCC(1) |  GM10X_SET_FIELD_PSign(1) )
#define GM10X_IADD_NEGB_X(Rd, Ra, Rb)  ( GM10X_INST_IADD(Rd, Ra, Rb) | GM10X_SET_FIELD_Xm(1)      |  GM10X_SET_FIELD_PSign(1) )

#define GM10X_LDC(Rd, cbank, off) ( GM10X_INST_LDC_I_ALL(PT, GM10X_KEYWORD_CINTEGER_N64_N128_32, GM10X_KEYWORD_ADMODE_IA, Rd, cbank, RZ, off) )

/* Default OPEX. This corresponds to an ?OFF_DECK_DRAIN for all 3 instructions in
   the I$ half line. This uses the new unified format for OPEXes. */
#define GM10X_DEFAULT_OPEX 0x001F8000FC0007E0ULL


#endif
