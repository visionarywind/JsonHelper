/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: maxwell_gm10x_patches_mem.h
 *
 *   Description:
 *       SASS-level patches used in memcheck module for GK11x
 *
 ******************************************************************************/

#ifndef _MAXWELL_PATCHES_MEM_H
#define _MAXWELL_PATCHES_MEM_H

#include "devtools/common/assembler/gm10x_sass.h"
#include "fermi_mcinterop.h"
#include "memcheck_arch/inc/maxwell_gm10x/maxwell_gm10x_patches_common.h"

/* Fermi memcheck doesn't need local memory (at least not local_lo) */
#define MAXWELL_GM10X_GLOBAL_PATCH_LOCAL_MEM 0

static uint64_t memcheckPatchCheck[] = {
    GM10X_DEFAULT_OPEX,

#define PATCH_OK_ENTRY_HI 1
    GM10X_LDL128(R12, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+48),
    GM10X_LDL128(R8, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+32),
    GM10X_INST_NOP,
    /* The epilogue from the checker. It's here to put it in a known
       location before the variable part of the checker.

     Ok:
        restore predicates and CC
        restore R0-R7
        ret */
    GM10X_DEFAULT_OPEX,

#define PATCH_OK_ENTRY_LO 5
    GM10X_LDL(R7, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+84),
    GM10X_R2P(R7),
    GM10X_R2C(R7),

    GM10X_DEFAULT_OPEX,

    GM10X_LDL128(R4, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+16),
    GM10X_LDL128(R0, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH),
    GM10X_INST_RET,

    GM10X_DEFAULT_OPEX,

#define PATCH_FAIL_ENTRY 13
    /* This patch does not use ST_E_128 anymore due to bug 712753 */

    /* Fail:

       Needs to grab the lock
       if (winner) {
          write blockIdx.x
          write blockIdx.y
          write blockIdx.z
          write threadIdx.xyz
          write pc into R6

          write memaddr
       }

       <<<optional Break>>>

       goto Ok;

       In Fermi SASS:

       struct {
          uint64_t memaddr;
          uint32_t lockbit;
          uint32_t pc;

          uint32_t threadIdx_xyz;
          uint32_t blockIdx_x;
          uint32_t blockIdx_y;
          uint32_t blockIdx_z;
       } fermi_error;

         mov32i           r4=address_lo
         mov32i           r5=address_hi
         mov32i           r2=1
         atom.e.or        r6=[r4+28], r2        // atomicOr(p,1)
         isetp.eq.u32.and p0=pt, r6, rz, pt
     @p0 st32.e          [r4]=r0
     @p0 st32.e          [r4+4]=r1
     @p0 st32.e          [r4+8]=r2
     @p0 st32.e          [r4+12]=r3
         s2r              r0=sr32
     @p0 st32.e          [r4+16]=r0
         s2r              r0=sr37
     @p0 st32.e          [r4+20]=r0
         s2r              r0=sr38
     @p0 st32.e          [r4+24]=r0
         s2r              r0=sr39
     @p0 st32.e          [r4+28]=r0
         bra              Ok
        */

    GM10X_LDL(R2, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH + FERMI_LMEM_MEMCHECK_MAGIC),
    GM10X_LOP32I(LOP_OR, R2, R2, FERMI_MEMCHECK_WHITEMAGIC),
    GM10X_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH + FERMI_LMEM_MEMCHECK_MAGIC, R2),

    GM10X_DEFAULT_OPEX,

#define PATCH_FAIL_ERROR_LOC 17
    GM10X_INST_MOV32I(R4, 0x76543210),
    GM10X_INST_MOV32I(R5, 0xFEDCBA98),
    GM10X_ATOM32_X_OR(R6, R4, 28, R2),

    GM10X_DEFAULT_OPEX,

    GM10X_ISETP(CMP_EQ, P0, R6, RZ),
    GM10X_PRED(P0, GM10X_STG32_X(R4,  0, R0)),
    GM10X_PRED(P0, GM10X_STG32_X(R4,  4, R1)),

    GM10X_DEFAULT_OPEX,

    GM10X_PRED(P0, GM10X_STG32_X(R4,  8, R2)),
    GM10X_PRED(P0, GM10X_STG32_X(R4, 12, R3)),
    GM10X_INST_S2R(R0, 32),

    GM10X_DEFAULT_OPEX,

    GM10X_PRED(P0, GM10X_STG32_X(R4, 16, R0)),
    GM10X_INST_S2R(R0, 37),
    GM10X_PRED(P0, GM10X_STG32_X(R4, 20, R0)),

    GM10X_DEFAULT_OPEX,

    GM10X_INST_S2R(R0, 38),
    GM10X_PRED(P0, GM10X_STG32_X(R4, 24, R0)),
    GM10X_INST_S2R(R0, 39),

    GM10X_DEFAULT_OPEX,

    GM10X_PRED(P0, GM10X_STG32_X(R4, 28, R0)),
#define PATCH_FAIL_BREAK 38

    GM10X_INST_EXIT,      // Will be patched to BPT.TRAP if nonblocking is on
    GM10X_INST_EXIT,      // This will be hit on a continue
    /* The rest of the checker is dynamically generated */
};

static uint64_t
memcheckPatchAlignCheck[] = {
    GM10X_DEFAULT_OPEX,

    /* Check:  // R0.R1 = memaddr, R2 = alignment mask, R3 = pc, R7 = pred/cc */
    GM10X_LOP_CC(LOP_AND,R2, R2, R0),
#define PATCH_ALIGN_CHECK_BRA 2
    GM10X_PRED(P0, GM10X_BRA_CC(TEST_NE, 0/*Fail entry*/)),
    GM10X_INST_NOP,
};

/* A draft of the worst-case stub. The _actual_ stub is complete
   generated on the fly by patchInstructions, so only the size of
   memcheckPatchStub matters, not it's contents. */

static uint64_t memcheckPatchStubWithAbi[] = {
    /* The first two instructions in patch code must be NOP ?OFF_DECK_DRAIN.
       This is due to bug 1267433
    */
    GM10X_DEFAULT_OPEX,

    GM10X_INST_NOP,
    GM10X_INST_NOP,
    GM10X_INST_NOP,

    GM10X_DEFAULT_OPEX,

    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH,0),
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+4,1),
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+8,2),

    GM10X_DEFAULT_OPEX,

    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+12,3),
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+16,4),
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+20,5),

    GM10X_DEFAULT_OPEX,

    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+24,6),
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+28,7),
    GM10X_INST_NOP,


    GM10X_DEFAULT_OPEX,
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+32,8),    // Only added if ABI enabled
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+36,9),    // Only added if ABI enabled
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+40,10),   // Only added if ABI enabled

    GM10X_DEFAULT_OPEX,

    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+44,11),   // Only added if ABI enabled
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+48,12),   // Only added if ABI enabled
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+52,13),   // Only added if ABI enabled

    GM10X_DEFAULT_OPEX,

    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+56,14),   // Only added if ABI enabled
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+60,15),   // Only added if ABI enabled
    GM10X_INST_NOP,

    GM10X_DEFAULT_OPEX,

    GM10X_INST_NOP,
    GM10X_INST_MOV(R0, R4),
    GM10X_INST_MOV(R1, R5),

    GM10X_DEFAULT_OPEX,

    GM10X_P2R(R7, RZ),
    GM10X_C2R(R7, R7),
    GM10X_IADD32I_CC(R0, R0, 1234),

    GM10X_DEFAULT_OPEX,

    GM10X_IADD32I_X(R1, R1, (int64_t) 1234 >> 32),
    GM10X_INST_MOV32I(R2,  69),
    GM10X_INST_MOV32I(R3,   7),


    GM10X_DEFAULT_OPEX,

    GM10X_LOP32I(LOP_OR, R7, R7, 0x80),
    GM10X_LOP32I(LOP_AND, R6, R7, 0x80),         // Set R6 = PR & ( 1 << Plg)
    GM10X_ISETP_AND(CMP_NE, P3, R6, RZ, PT), // Copy the Plg predicate to P3

    GM10X_DEFAULT_OPEX,

    GM10X_LOP32I(LOP_AND, R6, R7, 0x80),         // Set R6 = PR & ( 1 << Pg)
    GM10X_ISETP_AND(CMP_NE, P0, R6, RZ, PT), // Copy the predicate
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+64,0),    // Spill AddressLo

    GM10X_DEFAULT_OPEX,

    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+68,1),    // Spill AddressHi
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+72,3),    // Spill InstAddrLo
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+76,4),    // Spill InstAddrHi

    GM10X_DEFAULT_OPEX,

    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+80,2),    // Spill Alignment
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+84,7),    // Spill saved predicate
    GM10X_PRED(P3, GM10X_INST_MOV32I(R5,  0)),            // Push global if Plg set

    GM10X_DEFAULT_OPEX,

    GM10X_PRED(NOT_P3, GM10X_INST_MOV32I(R5, 0)),         // Push shared if Plg is clear
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+92,5),    // Spill address type
    GM10X_INST_SSY(7 *8),                                 // Push SSY

    GM10X_DEFAULT_OPEX,

    GM10X_PRED(NOT_P3, GM10X_INST_BRA(3 * 8)),            // Skip the global check
    GM10X_INST_JCAL(0), // Call the global check routine
    GM10X_INST_BRA(2 * 8),

    GM10X_DEFAULT_OPEX,

    GM10X_INST_JCAL(0), // Call the shared check routine
    GM10X_INST_SYNC,
    GM10X_INST_NOP,

    GM10X_DEFAULT_OPEX, // This must be ?OFF_DECK_DRAIN on the original instruction.

    0, // The original load
    GM10X_INST_JMP(0), // The jump back
    GM10X_INST_NOP,
};

static uint64_t memcheckPatchStubWithoutAbi[] = {
    /* The first two instructions in patch code must be NOP ?OFF_DECK_DRAIN.
       This is due to bug 1267433
    */
    GM10X_DEFAULT_OPEX,

    GM10X_INST_NOP,
    GM10X_INST_NOP,
    GM10X_INST_NOP,

    GM10X_DEFAULT_OPEX,

    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH,0),
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+4,1),
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+8,2),

    GM10X_DEFAULT_OPEX,

    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+12,3),
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+16,4),
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+20,5),

    GM10X_DEFAULT_OPEX,

    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+24,6),
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+28,7),
    GM10X_INST_NOP,

    GM10X_DEFAULT_OPEX,

    GM10X_INST_NOP,
    GM10X_INST_MOV(R0, R4),
    GM10X_INST_MOV(R1, R5),

    GM10X_DEFAULT_OPEX,

    GM10X_P2R(R7, RZ),
    GM10X_C2R(R7, R7),
    GM10X_IADD32I_CC(R0, R0, 1234),

    GM10X_DEFAULT_OPEX,

    GM10X_IADD32I_X(R1, R1, (int64_t) 1234 >> 32),
    GM10X_INST_MOV32I(R2,  69),
    GM10X_INST_MOV32I(R3,   7),


    GM10X_DEFAULT_OPEX,

    GM10X_LOP32I(LOP_OR, R7, R7, 0x80),
    GM10X_LOP32I(LOP_AND, R6, R7, 0x80),         // Set R6 = PR & ( 1 << Plg)
    GM10X_ISETP_AND(CMP_NE, P3, R6, RZ, PT), // Copy the Plg predicate to P3

    GM10X_DEFAULT_OPEX,

    GM10X_LOP32I(LOP_AND, R6, R7, 0x80),         // Set R6 = PR & ( 1 << Pg)
    GM10X_ISETP_AND(CMP_NE, P0, R6, RZ, PT), // Copy the predicate
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+64,0),    // Spill AddressLo


    GM10X_DEFAULT_OPEX,

    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+68,1),    // Spill AddressHi
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+72,3),    // Spill InstAddrLo
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+76,4),    // Spill InstAddrHi

    GM10X_DEFAULT_OPEX,

    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+80,2),    // Spill Alignment
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+84,7),    // Spill saved predicate
    GM10X_PRED(P3, GM10X_INST_MOV32I(R5,  0)),            // Push global if Plg set

    GM10X_DEFAULT_OPEX,

    GM10X_PRED(NOT_P3, GM10X_INST_MOV32I(R5, 0)),         // Push shared if Plg is clear
    GM10X_STL(63,FERMI_LMEM_HI_MEMCHECK_SCRATCH+92,5),    // Spill address type
    GM10X_INST_SSY(6 *8),                                 // Push SSY

    GM10X_DEFAULT_OPEX,

    GM10X_PRED(NOT_P3, GM10X_INST_BRA(3 * 8)),            // Skip the global check
    GM10X_INST_JCAL(0), // Call the global check routine
    GM10X_INST_BRA(2 * 8),

    GM10X_DEFAULT_OPEX,

    GM10X_INST_JCAL(0), // Call the shared check routine
    GM10X_INST_SYNC,
    GM10X_INST_NOP,

    GM10X_DEFAULT_OPEX, // This must be ?OFF_DECK_DRAIN on the original instruction.

    0, // The original load
    GM10X_INST_JMP(0), // The jump back
    GM10X_INST_NOP,
};

static uint64_t endOfCheck[] = {
    GM10X_DEFAULT_OPEX,
    GM10X_PRED(P0,GM10X_INST_BRA(0)), //This will be patched
    GM10X_INST_BRA(0),           //This will be patched
    GM10X_INST_NOP,
};



#endif
