/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: maxwell_gm10x_patches_local.h
 *
 *   Description:
 *       SASS-level patches used in memcheck module, Fermi style
 *
 ******************************************************************************/

#ifndef _MAXWELL_PATCHES_LOCAL_H
#define _MAXWELL_PATCHES_LOCAL_H

#include "fermi_mcinterop.h"
#include "memcheck_arch/inc/maxwell_gm10x/maxwell_gm10x_patches_common.h"

static uint64_t lmemLoCheck[] = {
    GM10X_DEFAULT_OPEX,
    GM10X_PRED(P0, GM10X_IADD32I_CC(R4, R0, 0)), //this line will be patched
    GM10X_PRED(P0, GM10X_ISETP_X(CMP_GT, P0, RZ, RZ)),
    GM10X_INST_NOP,
};

/* This check will only kick in if LmemHi will be used
    The check is as follows:
    LMEM_HI_USER_MAX > addr > LMEM_HI_MIN
    Where LMEM_HI_USER_MAX is given as the start of the user
    stack. (i.e. 16MB - 512 (debugger) - SystemStackSize)
    LMEM_HI_MIN is MAX(SR_LMemHiOff, func->stackSize, r1)
    The func->stackSize check is generated only
    if there is a stack size.
    The r1 check is only generated if recursion is possible
*/
static uint64_t lmemHiDynamicCheck[] = {
    GM10X_DEFAULT_OPEX,

    GM10X_PRED(P0, GM10X_INST_LDC_I(R4, 0)),           // LMEM_HI_USER_MAX comes from bank 0 slot 0x20
    GM10X_PRED(P0, GM10X_INST_S2R(R5, 55)),            // Move the LmemHiOff into R5
    GM10X_INST_NOP,                                    // Pad to fill Icache half line

    // The next 8 instructions are generated if there is
    // recursion. Basically, these move the stack pointer into
    // R6, and place the maximum of R6 and R5 into R5
    GM10X_DEFAULT_OPEX,                                 // Push a new opex
    GM10X_PRED(P0, GM10X_LDL(R5, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+4)),     // Load Stack pointer
    GM10X_PRED(P0, GM10X_INST_MOV(R7, RZ)),                      // Reset R7
    GM10X_PRED(P0, GM10X_ISET(CMP_GT, R7, R5, R6)),             // If R5 > R6, set R7

    GM10X_DEFAULT_OPEX,

    GM10X_PRED(P0, GM10X_INST_ICMP(CMP_NE, R5, R5, R6, R7)),  // R5 = Max(SP, SRLmemHiOff)
    GM10X_INST_NOP,                                           // Pad to fill I$ line
    GM10X_INST_NOP,                                           // Pad to fill I$ line

    // The next 8 instructions are generated if there is
    // a valid stack size. These will move the stack size
    // into R6 and place the maximum of R5 and R6 into R5

    GM10X_DEFAULT_OPEX,

    GM10X_PRED(P0, GM10X_INST_IADD32I(R6, R4, 0)), // Load stack size in R6
    GM10X_PRED(P0, GM10X_INST_MOV(R7, RZ)),                      // Reset R7
    GM10X_PRED(P0, GM10X_ISET(CMP_GT, R7, R5, R6)),             // If R5 > R6, set R7

    GM10X_DEFAULT_OPEX,

    GM10X_PRED(P0, GM10X_INST_ICMP(CMP_NE, R5, R5, R6, R7)),  // R5 = Max(StackSize, R5)
    GM10X_INST_NOP,
    GM10X_INST_NOP,

    // This part is common. This is the actual bounds check
    // The address is in R0. We compare whether the address
    // is less than LMEM_HI_USER_MAX and greater or equal to
    // LMEM_HI_MIN (stored in R5)

    GM10X_DEFAULT_OPEX,

    GM10X_PRED(P0, GM10X_ISET(CMP_GT, R4, R4, R0)),        // addr < LMEM_HI_USER_MAX
    GM10X_PRED(P0, GM10X_ISET(CMP_GE, R5, R0, R5)),        // addr >= LMEM_HI_LO
    GM10X_PRED(P0, GM10X_LOP(LOP_AND, R4, R4, R5)),        // check if both are satisfied

    GM10X_DEFAULT_OPEX,

    GM10X_PRED(P0, GM10X_ISETP(CMP_EQ, P0, RZ, R4)),       // P0 = 0 if satisfied
    GM10X_INST_NOP,
    GM10X_INST_NOP,
};

/* Check to allow LMEM reads to the thread index. Under CNP, the driver converts
   S2Rs to LDL's from this region. This check is only for LDL and not for writes
 */
static uint64_t lmemHiCnpCheck[] = {
    GM10X_DEFAULT_OPEX,
    GM10X_PRED(P0, GM10X_IADD32I_CC(R4, R0, 0)),
    GM10X_PRED(P0, GM10X_ISETP_AND(CMP_GT, P1, R4, RZ, P0)),
    GM10X_PRED(P0, GM10X_IADD32I_CC(R4, R4, 0)),
    GM10X_DEFAULT_OPEX,
    GM10X_PRED(P0, GM10X_ISETP_AND_PV(CMP_LT, PT, P0, R4, RZ, P1)),
    GM10X_INST_NOP,
    GM10X_INST_NOP,
};
#endif
