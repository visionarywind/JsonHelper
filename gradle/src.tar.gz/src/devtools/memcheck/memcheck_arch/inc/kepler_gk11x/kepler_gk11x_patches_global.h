/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: kepler_gk11x_patches_global.h
 *
 *   Description:
 *       SASS-level patches used in memcheck module for GK11x
 *
 ******************************************************************************/

#ifndef _KEPLER_GK11X_PATCHES_GLOBAL_H
#define _KEPLER_GK11X_PATCHES_GLOBAL_H

#include "devtools/common/assembler/gk11x_sass.h"
#include "fermi_mcinterop.h"
#include "memcheck_arch/inc/kepler_gk11x/kepler_gk11x_patches_common.h"

#define KEPLER_GK110_GLOBAL_LMEM_START 0x03000000U

/* A draft of the worst-case per allocation checking. This is only use
   for sizing the patch buffer and must match genMemRangeLookup. */
static uint64_t memcheckPatchCheckAllocation[] = {
    GK110SASS_INST_PRED(P0, GK110SASS_INST_IADD32I_CC(R4, R0, -0x60000000)),
    GK110SASS_INST_PRED(P0, GK110SASS_INST_IADD32I_X(R5, R1, -(int64_t)0x60000000 >> 32)),
    GK110SASS_INST_PRED(P0, GK110SASS_INST_IADD32I_CC(RZ, R4, -512 + 1)),
    GK110SASS_INST_PRED(P0, GK110SASS_INST_ISETP_FULL(GT, AND, 1, P0, R5, RZ, PT)),
};

/* A draft of the worst-case shmem allocation checking. This is always generated */
static uint64_t memcheckPatchCheckShmem[] = {
    GK110SASS_INST_PRED(P0, GK110SASS_INST_LDC(R4, 0, 0)),
    GK110SASS_INST_PRED(P0, GK110SASS_INST_LDC(R6, 0, 0)),
    GK110SASS_INST_PRED(P0, GK110SASS_INST_IADD32I_CC(R4, R0, -0x60000000)),
    GK110SASS_INST_PRED(P0, GK110SASS_INST_IADD32I_X(R5, R1, -(int64_t)0x60000000 >> 32)),
    GK110SASS_INST_PRED(P0, GK110SASS_INST_IADD32I_CC(RZ, R4, -512 + 1)),
    GK110SASS_INST_PRED(P0, GK110SASS_INST_ISETP_FULL(GT, AND, 1, P0, R5, RZ, PT)),
};

/* This check will only kick in if LmemHi will be used
    The check is as follows:
    LMEM_HI_USER_MAX > addr > LMEM_HI_MIN
    Where LMEM_HI_USER_MAX is given as the start of the user
    stack. (i.e. 16MB - 512 (debugger) - SystemStackSize)
    LMEM_HI_MIN is MAX(SR_LMemHiOff, func->stackSize, r1)
    The func->stackSize check is generated only
    if there is a stack size.
    The r1 check is only generated if recursion is possible
*/
static uint64_t memcheckPatchCheckLmemHi_prologue[] = {
    GK110SASS_INST_PRED(P0, GK110SASS_INST_LDC(R4, 0, 0)),         // LMEM_HI_USER_MAX comes from bank 0 slot 0x44
    GK110SASS_INST_PRED(P0, GK110SASS_INST_S2R(R5, 55)),           // Move the LmemHiOff into R5
};

static uint64_t memcheckPatchCheckLmemHi_r1Check[] = {
    // The next 4 instructions are generated if there is
    // recursion. Basically, these move the stack pointer into
    // R6, and place the maximum of R6 and R5 into R5
    GK110SASS_INST_PRED(P0, GK110SASS_INST_LDL(R5, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+4)),     // Load Stack pointer
    GK110SASS_INST_PRED(P0, GK110SASS_INST_MOV(R7, RZ)),                      // Reset R7
    GK110SASS_INST_PRED(P0, GK110SASS_INST_ISET(GT, R7, R5, R6)),             // If R5 > R6, set R7
    GK110SASS_INST_PRED(P0, GK110SASS_INST_ICMP(NE, R5, R5, R6, R7)),  // R5 = Max(SP, SRLmemHiOff)
};

static uint64_t memcheckPatchCheckLmemHi_stackCheck[] = {
    // The next 4 instructions are generated if there is
    // a valid stack size. These will move the stack size
    // into R6 and place the maximum of R5 and R6 into R5
    GK110SASS_INST_PRED(P0, GK110SASS_INST_IADD32I(R6, R4, 0)), // Load stack size in R6
    GK110SASS_INST_PRED(P0, GK110SASS_INST_MOV(R7, RZ)),                      // Reset R7
    GK110SASS_INST_PRED(P0, GK110SASS_INST_ISET(GT, R7, R5, R6)),             // If R5 > R6, set R7
    GK110SASS_INST_PRED(P0, GK110SASS_INST_ICMP(NE, R5, R5, R6, R7)),  // R5 = Max(StackSize, R5)
};

static uint64_t memcheckPatchCheckLmemHi_epilogue[] = {
    // This part is common. This is the actual bounds check
    // The address is in R0. We compare whether the address
    // is less than LMEM_HI_USER_MAX and greater or equal to
    // LMEM_HI_MIN (stored in R5)
    GK110SASS_INST_PRED(P0, GK110SASS_INST_IADD32I(R4, R4, KEPLER_GK110_GLOBAL_LMEM_START)),
    GK110SASS_INST_PRED(P0, GK110SASS_INST_IADD32I(R5, R5, KEPLER_GK110_GLOBAL_LMEM_START)),
    GK110SASS_INST_PRED(P0, GK110SASS_INST_ISET(GT, R4, R4, R0)),                       // addr < LMEM_HI_USER_MAX
    GK110SASS_INST_PRED(P0, GK110SASS_INST_ISET(GE, R5, R0, R5)),                       // addr >= LMEM_HI_LO
    GK110SASS_INST_PRED(P0, GK110SASS_INST_LOP(AND, R4, R4, R5)),                  // check if both are satisfied
    GK110SASS_INST_PRED(P0, GK110SASS_INST_ISETP_FULL(EQ, AND, 0, P0, RZ, R4, PT))                   // P0 = 0 if satisfied
};

/*  Draft for preparation before the syscall jump. This
    must conform to the Fermi ABI so that it works.
    Arguments go to R4..R15. R1 is restored to the original
    programs value. The predicates are preserved across the
    call in R3.

    The declaration of the mccheck call is :
    uint32_t mccheck(uint64_t addr, uint64_t instaddr, uint32_t amask);
    Parameters are :
        r5,r4 : addr
        r7,r6 : instaddr
        r8    : alignment mask (amask)
    Return value is :
        r4 : boolean, 0 if fine, 1 if not
    Logic :
        1. Clear P1
        2. Set P1 = 1 if this is a heap allocation & P0
        3. Set up arguments into registers
        4. Set the SSY to point to the predicate restore
        5. Bypass the JCAL if the P1 is not set
        6. Else, save predicates into LMEM
        7. Do the JCAL to the function
        8. Restore predicates from LMEM. (Restores P0 and P1)
        9. Do the necessary resyncing
        10. Restore R0-R3
        11. Do the checks for new P0:
        If P1 == 1 && R4 == 0 => The check was clean and this was in the
        heap. So, if P0 was true, it must be set to false. If either
        condition is not true, then, P0 = P0.
        12. Continue to the predicated Fail/Restore logic
    Assumptions:
        1. This patch is expected to be the last in the chain as
           it clobbers registers and predicates. The only guarentee
           made is that the predicate register P0 is set up as expected.
*/
#define PATCH_ABI_TARGET_SSY 21
#define PATCH_ABI_TARGET_BYPASS 20
static uint64_t memcheckPatchAbiJump[] = {
    // Step 1 : Clear P1
    // Reset the P1 predicate to 0
    GK110SASS_INST_ISETP_FULL(NE, AND, 0, P1, RZ, RZ, PT),

    // Step 2 : Set P1 if this is in the heap
    // Perform a standard in range check on the heap address
    // Set P1. P1 = 1 if in heap, P1 = 0 if not in heap
#define PATCH_ABI_HEAP_ADDR 1
    GK110SASS_INST_PRED(P0,GK110SASS_INST_IADD32I_CC(R4, R0, -0x60000000)),
    GK110SASS_INST_PRED(P0,GK110SASS_INST_IADD32I_X(R5, R1, -(int64_t)0x60000000 >> 32)),
#define PATCH_ABI_HEAP_SIZE 3
    GK110SASS_INST_PRED(P0,GK110SASS_INST_IADD32I_CC(RZ, R4, -512 + 1)),
    GK110SASS_INST_PRED(P0,GK110SASS_INST_ISETP_FULL(LT, AND, 1, P1, R5, RZ, PT)),

    // Step 3 : Parameter setup for function call
    GK110SASS_INST_MOV(R4, R0),  // Address Lo
    GK110SASS_INST_MOV(R5, R1),  // Address Hi
    GK110SASS_INST_MOV(R6, R3),  // InstAddr Lo
    GK110SASS_INST_MOV(R7, RZ),  // InstAddr Hi
    GK110SASS_INST_MOV(R8, R2),  // Alignment mask

    // Stack pointer setup (This must be in R1. Use the SP
    // that was previously saved in R1)
    GK110SASS_INST_LDL(R1, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+4),

    // Reset the frame pointer. (For now, use 0)
    GK110SASS_INST_MOV(R2, RZ),

    // Step 4 : Setup the sync target. On Fermi, this should
    // point to the instruction after the .S. There are two
    // divergent paths. Threads making accesses into the heap
    // will have P1 set and will make the JCAL. Threads that
    // are not accessing the heap will have P1 clear and will
    // jump the call into the check routine. The target of the
    // SSY will be the first instruction after the divergent code
    // which corresponds to the register restoring code.
#define PATCH_ABI_INST_SSY_COUNT 12
    GK110SASS_INST_SSY((PATCH_ABI_TARGET_SSY - PATCH_ABI_INST_SSY_COUNT - 1)*8),

    // NOTE: After the next instruction, lanes can diverge.

    // Step 5 : Bypass JCAL for accesses that are not in the heap
    // See previous comments about divergence. The instruction
    // at the target address will force a resync of all accesses
    // that skipped the function call
#define PATCH_ABI_INST_BYPASS_COUNT 13
    GK110SASS_INST_PRED(NOT_P1, GK110SASS_INST_BRA((PATCH_ABI_TARGET_BYPASS - PATCH_ABI_INST_BYPASS_COUNT - 1)*8)),

    // Step 6 : Save predicates (not done in the bypass path)
    // Use R3 as scratch.
    GK110SASS_INST_P2R(R3),        // Save the current predicate
    GK110SASS_INST_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+88, R3),

    // Step 7 : The JCAL. Use the macro offset to patch in
    // the correct address
#define PATCH_ABI_JUMP 16
    GK110SASS_INST_JCAL(0),        // Address of syscall

    // Step 8 : Restore predicates from LMEM (not done in bypass path)
    GK110SASS_INST_LDL(R3, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+88),   // Scratch predicate
    GK110SASS_INST_R2P(R3),        // Restore predicate

    // Step 9 : Resync the divergent paths. The first resync will
    // force the lanes that made the JCAL to sync. The second resync
    // will force all other lanes to resync. Note : The second resync
    // is the target of the bypass branch in step 5.
    GK110SASS_INST_NOP(0),
    GK110SASS_INST_NOP(1), // Target for branch at step 5

    // NOTE : At this point all lanes should be back in sync.

    // Step 10 : Restore registers. These registers are read in
    // the failure entry point and need to be saved.
    // Restoration of R0..R3 (only ones that matter)
#define PATCH_ABI_TARGET_SSY 21
    GK110SASS_INST_LDL(R0, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+64),   // AddressLo
    GK110SASS_INST_LDL(R1, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+68),   // AddressHi
    GK110SASS_INST_LDL(R2, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+80),   // AlignMask
    GK110SASS_INST_LDL(R3, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+72),   // InstAddrLo

    // Step 11 : Compute the new P0
    // Set P0 to 0 if found, otherwise P0 = 1. This will chain
    // Here, P1       -> is this in heap allocation
    //     (R4 == 0) -> was this allocation safe?
    // Iff P1 = 1 and R4 == 0 => P0 1-> 0 (i.e safe)
    GK110SASS_INST_PRED(P1, GK110SASS_INST_ISETP_FULL(EQ, AND, 0, P1, R4, RZ, P1)),
    // At this point P1 == 1 iff, P0 == 1 (i.e. original instruction
    // would have executed and was not found in any static allocation)
    // P1 == 1 (previously, i.e. the access was in the large heap allocation)
    // and R4 ==0 (i.e. the check was successful)
    GK110SASS_INST_PRED(P0, GK110SASS_INST_ISETP_FULL(EQ, AND, 0, P0, RZ, RZ, NOT_P1)),
    // At this point, P0 = 0 if, P0 was 0 (i.e. the original instruction
    // was predicated, or found in another allocation) or P0 was 1 and
    // P1 was 1 in the previous check (i.e. instruction would be executed,
    // was in the heap allocation and the check passed successfully).
    // P0 = 1 if the instruction would be executed and the check failed.

    // Step 12 : Continue to Fail/Restore stubs. The restore code expects
    // R7 to be setup correctly, so do that here.
    GK110SASS_INST_LDL(R7, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+84),     // Original predicate
};

#endif
