/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: kepler_gk11x_patches_shared.c
 *
 *   Description:
 *       Global load/store patches for kepler_gk11x
 *
 ******************************************************************************/

#include "memcheck_types.h"
#include "memcheck_error.h"
#include "memcheck_arch/inc/kepler_gk11x/kepler_gk11x_patches_common.h"
#include "memcheck_arch/inc/kepler_gk11x/kepler_gk11x_patches.h"
#include "halo.h"
#include "devtools/common/assembler/gk11x_sass.h"
#include "memcheck_arch/inc/fermi/fermi_patches_common.h"

// Need this for the lmem system stack limit
#include "cui/hal/kepler/kepler.h"

/*
   Strategy: since we don't try to insert instructions into the
   middle, we follow the cuda-memcheck/Tesla stategy of replacing all
   checked instructions with a branch to the stub, which then invokes
   the checker.

   It's critical to not introduce divergence that wasn't in the
   original code (this was bug 687852), so we copy the patched
   instruction's predicate into P0 and predicate everything by
   that. The only divergence we will allow is when errors are found at
   which point we are about to crash anyway, so who cares :)

   what was:

        00e8    mov r3, r3
        00f0    (pred) ld.e r1, [r2]
        00f8    imul.hi r2, r1, 0x4

   becomes:

        00e8    mov r3, r3;
        00f0    jmp stub_00f0
        resumepoint:
        00f8    imul.hi r2, r1, 0x4


        stub_00f0:
                ..... save off registers and predicates
                set up parameters to check
                P0 = (pred)
                call check

                (pred) ld.e r1, [r2]
                jmp resumepoint

 */


static uint64_t sharedRangeCheck[] = {
    GK110SASS_INST_PRED(P0,GK110SASS_INST_LDC(R6, 0, 0)),
    GK110SASS_INST_PRED(P0,GK110SASS_INST_NOP(0)),
    GK110SASS_INST_PRED(P0,GK110SASS_INST_ISETP_FULL_FMT(GE, GK110SASS_ISETP_FMT__U32, AND, 0, P0, R0, R6, PT))
};

static uint64_t*
kepler_gk11x_shared_genRangeCheck(MCcheckType *checkType, MCrec *rec, uint64_t *patchCode)
{
    MChal *hal = &rec->context->hal;

    /* This check will kick in if there is any shared memory
       being used. The amount of shared memory being used
       is written into the const bank.

       The basic logic here is the following:

        if (ShmemSize &&
            SR_SWinLo <= Addr < SR_SWinLo + ShmemSize)
            stop checks;

        This can be shrunken down to
        @P0 LDC R6 c [0] [`ShmemSize];  // Gets the usable shmem size from the driver internal constbank

        @P0 NOP;
        @P0 ISETP.GE.U32.AND P0, pt, R0, R6, PT;

    */

    *patchCode++ = GK110SASS_INST_PRED(P0, GK110SASS_INST_LDC(R6, hal->driverInternalParamsConstBank, hal->driverInternalParamsShmemSizeOffset));

    *patchCode++ = GK110SASS_INST_PRED(P0, GK110SASS_INST_NOP(0));
    *patchCode++ = GK110SASS_INST_PRED(P0, GK110SASS_INST_ISETP_FULL_FMT(GE, GK110SASS_ISETP_FMT__U32, AND, 0, P0, R0, R6, PT));

    return patchCode;
}

static uint32_t
kepler_gk11x_shared_getRangeCheckSize(MCcheckType *checkType, MCrec *rec)
{
    /* Add space for the virtual mapping */
    return sizeof sharedRangeCheck;
}

CUresult
kepler_gk11x_shared_checkType_bootstrap(MCinstManager *instMgr, MCcheckType *type)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!instMgr || !type) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Override for kepler_gk11x_global variants. These are in kepler_gk11x_shared.[hc]
    type->tm.mem.genRangeCheck     =   kepler_gk11x_shared_genRangeCheck;
    type->tm.mem.getRangeCheckSize =   kepler_gk11x_shared_getRangeCheckSize;

    return res;
}
