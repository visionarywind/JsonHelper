/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: kepler_gk11x_hal.c
 *
 *   Description:
 *       The HAL implementation for Kepler GK11x
 *
 ******************************************************************************/

#include "memcheck_types.h"
#include "memcheck_error.h"

#include "halo.h"

// Include this for the system stack limit and the DCI offset
#include "cui/hal/kepler/kepler_structs.h"

#include "devtools/common/assembler/gk11x_sass.h"

#include "devtools/common/halo/inc/fermi/fermi_mcinterop.h"

#include "class/cla1c0qmd.h"

#define SIGN_EXT(x, N) ( ((x) << N) >> N )


enum {
    RZ = 255,
};

enum {
    PT = 7,
};

static bool stub (const uint64_t *inst)
{
    return false;
}

static uint32_t
get_rz(void)
{
    return RZ;
}

static bool
is_nop(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    tmp = tmp & (BF_MASK(63:54) | BF_MASK(1:0));

    if (tmp == GK110SASS_INST7_5(MISC2, NO_OP))
        return true;

    return false;
}

static bool
is_gtas_ld(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    tmp = tmp & (BF_MASK(63:61) | BF_MASK(1:0));

    if (tmp == GK110SASS_INST5(GK110SASS_OPCODE5__LD))
        return true;

    return false;
}

static bool
is_gtas_st(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    tmp = tmp & (BF_MASK(63:61) | BF_MASK(1:0));

    if (tmp == GK110SASS_INST5(GK110SASS_OPCODE5__ST))
        return true;

    return false;
}

static bool
is_sld(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    tmp = tmp & (BF_MASK(63:54) | BF_MASK(1:0));

    if (tmp == GK110SASS_INST7_5(MISC1, LDS))
        return true;

    return false;
}

static bool
is_sst(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    tmp = tmp & (BF_MASK(63:54) | BF_MASK(1:0));

    if (tmp == GK110SASS_INST7_5(MISC1, STS))
        return true;

    return false;
}

static bool
is_lld(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    tmp = tmp & (BF_MASK(63:54) | BF_MASK(1:0));

    if (tmp == GK110SASS_INST7_5(MISC1, OP_LDL))
        return true;

    return false;
}

static bool
is_lst(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    tmp = tmp & (BF_MASK(63:54) | BF_MASK(1:0));

    if (tmp == GK110SASS_INST7_5(MISC1, STL))
        return true;

    return false;
}

static bool
is_bar(const uint64_t inst, uint32_t *barmode)
{
    uint64_t masked;

    masked = inst & (GK110SASS_INST7_5_MASK);

    if (masked == GK110SASS_INST7_5(MISC2, BAR)) {
        if (barmode)
            *barmode = BF_GET(GK110SASS_BARMODE, inst);
        return true;
    }
    return false;
}

static bool
is_synchronizing_barrier(const uint64_t *inst)
{
    uint32_t barmode = 0;

    if (!is_bar(*inst, &barmode))
        return false;

    // Check the sub variants (BAR.SYNC, BAR.RED)
    // BAR.SYNCALL is illegal in user code
    return (barmode == GK110SASS_BARMODE__SYNC ||
            barmode == GK110SASS_BARMODE__RED ||
            barmode == GK110SASS_BARMODE__SYNCALL);
}

static bool
is_atom(const uint64_t *inst)
{
    uint64_t inst1 = *inst & (BF_MASK(63:59) | BF_MASK(1:0));
    uint64_t inst2 = *inst & (BF_MASK(58:55));


    if (inst1 == GK110SASS_INST7(GK110SASS_OPCODE7__ATOM))
        return true;

    if (inst1 == GK110SASS_INST7(GK110SASS_OPCODE7__MISC0) &&
        inst2 == GK110SASS_OPCODE7SUB4__ATOM_CAS)
        return true;

    return false;
}

static bool
is_red(const uint64_t *inst)
{
    /* On SM35, RED is encoded as ATOM RZ,...
       See : Bullet 8 in https://p4viewer.nvidia.com/get/hw/doc/gpu/kepler/kepler/design/IAS/SML1/ISA/opcodes/IAS_Visible_ISA_1_Kepler.htm#SM_SMKeplerLPDifferences
     */
    if (is_atom(inst)) {
        if (BF_GET(GK110SASS_REGDEST, *inst) == 255)
            return true;
        else
            return false;
    }
    return false;
}

static bool
is_jcal(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    //Mask for JCAL (upper 9 bits, bottom 2 bits)
    tmp &= BF_MASK(63:55) + BF_MASK(1:0);
    return (tmp == GK110SASS_INST5_6(CTRL,JCAL));
}

static bool
is_jmp(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    //Mask for JMP (upper 9 bits, bottom 2 bits)
    tmp &= BF_MASK(63:55) + BF_MASK(1:0);
    return (tmp == GK110SASS_INST5_6(CTRL,JMP));
}

static bool
is_jmx(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    //Mask for JMX (upper 9 bits, bottom 2 bits)
    tmp &= BF_MASK(63:55) + BF_MASK(1:0);
    return (tmp == GK110SASS_INST5_6(CTRL,JMX));

}

static bool
is_shfl(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    //Mask for SHFL (upper 10 bits, bottom 2 bits)
    tmp &= BF_MASK(63:54) + BF_MASK(1:0);
    return (tmp == GK110SASS_INST7_5(MISC1,SHFL));

}

static bool
is_cal(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    //Mask for CAL (upper 9 bits, bottom 2 bits)
    tmp &= BF_MASK(63:55) + BF_MASK(1:0);
    return (tmp == GK110SASS_INST5_6(CTRL,CAL));
}

static bool
is_exit(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    tmp &= GK110SASS_INST_EXIT_MASK;

    return (tmp == GK110SASS_INST5_6(CTRL, OP_EXIT));
}

static bool
is_ret(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    tmp &= GK110SASS_INST_RET_MASK;

    return (tmp == GK110SASS_INST5_6(CTRL, RET));
}

static int32_t
get_tex_index(const uint64_t *inst)
{
    uint64_t masked;
    uint32_t index = ~0U;
    uint64_t tmp = *inst;
    // Test TEX
    masked = tmp & (BF_MASK(63:60) + BF_MASK(1:0));
    if (masked == GK110SASS_INST6(GK110SASS_OPCODE6__TEX)) {
        // Test the index
        index = BF_GET(GK110SASS_TEX_TSPTRIDXU13, tmp);
        return index;
    }

    // Test TLD
    masked = tmp & (BF_MASK(63:58) + BF_MASK(1:0));
    if (masked == GK110SASS_INST7_1(MISC0, TLD)) {
        // Test the index
        index = BF_GET(GK110SASS_TLD_TSPTRIDXU13, tmp);
        return index;
    }

    return index;
}

static bool
is_gld(const uint64_t *inst)
{
    uint32_t index = 0;
    // LDG is a pseudo instruction
    // This can be encoded as either a TEX or a TLD
    // with the tsPtrIdxU13 field encoded as 0 - 6
    // (7 is CCTL, which we dont care about)

    // The get_tex_index function will return the index
    // from the index field (or ~0U if the instruction is
    // not a TEX/TLD instruction)

    index = get_tex_index(inst);
    return (index < 0x7);
}

static bool
getExtended(const uint64_t *inst)
{
    if (is_lst(inst) || is_lld(inst) || is_sst(inst) || is_sld(inst))
        return false;

    if (is_gtas_ld(inst) || is_gtas_st(inst))
        return (BF_GET(GK110SASS_LDST_X, *inst) != 0);

    if (is_atom(inst))
        return (BF_GET(51:51, *inst) != 0);

    if (is_gld(inst)) {
        // ParamA is set to 2D for Extended
        if (BF_GET(GK110SASS_TEX_PARAMA, *inst) == GK110SASS_TEX_PARAMA__2D)
            return true;
        else
            return false;
    }

    CU_ASSERT(0);
    return false;
}

static uint32_t
getOffset(const uint64_t *inst)
{
    int32_t rawVal = 0;

    if (is_lst(inst) || is_lld(inst) ||
        is_sst(inst) || is_sld(inst)) {
        rawVal = BF_GET(GK110SASS_IMM24, *inst);
        // When Ra is not RZ (i.e. 255), the offset
        // is signed. Otherwise its unsigned.
        if (BF_GET(GK110SASS_REGA, *inst) != 255)
            // Signed
            rawVal = SIGN_EXT(rawVal, 8);
        return (uint32_t)rawVal;
    }

    if (is_gtas_ld(inst) || is_gtas_st(inst)) {
        return BF_GET(GK110SASS_IMM32, *inst);
    }

    if (is_atom(inst)) {
        rawVal = BF_GET(GK110SASS_ATOM_IMM20, *inst);
        // When Ra is not RZ (i.e. 255), the offset
        // is signed. Otherwise its unsigned.
        if (BF_GET(GK110SASS_REGA, *inst) != 255) {
            rawVal = SIGN_EXT(rawVal, 12);
        }
        return (uint32_t) rawVal;
    }

    if (is_gld(inst)) {
        // LDG doesnt allow for an offset
        return 0;
    }

    CU_ASSERT(0);
    return 0;
}

static bool
is_write(const uint64_t *inst)
{
    if (is_gtas_st(inst) || is_sst(inst) ||
        is_lst(inst) || is_red(inst))
        return true;

    return false;
}

/* Returns the size in bytes of a GLD or GST instruction */
static uint32_t
getMemAccessSize(const uint64_t *inst, const MCfunc *func, const uint64_t pc)
{
    const static uint32_t sizes[8] = {1, 1, 2, 2, 4, 8, 16, 16};

    if (is_lst(inst) || is_lld(inst) || is_sst(inst) || is_sld(inst))
        return sizes[BF_GET(GK110SASS_SIZE3, *inst)];

    if (is_gtas_ld(inst) || is_gtas_st(inst))
        return sizes[BF_GET(GK110SASS_INST5_SIZE3, *inst)];

    if (is_atom(inst)) {
        uint64_t inst1 = *inst & (BF_MASK(63:59) | BF_MASK(1:0));
        if (inst1 == GK110SASS_INST7(GK110SASS_OPCODE7__ATOM)) {
            //This is generated based on output of fatdis35
            const static uint32_t aSizes[8] = {4, 4, 8, 4, 16, 8, 1, 1};
            return aSizes[BF_GET(GK110SASS_ATOM_SIZERA, *inst)];
        }
        else {
            CU_ASSERT(0); //TODO: this is a placeholder for ATOMIC_CAS
        }
    }

    if (is_gld(inst)) {
        uint32_t index = 0;
        index = get_tex_index(inst);
        if (index > 0x6) {
            // This is an error
            CU_ASSERT(0);
            return 0;
        }
        return sizes[index];
    }

    CU_ASSERT(0);

    return 0;
}

static void
kepler_gk11x_getBreakInstruction(MCrec *rec, uint64_t *out)
{
    //GK11x BPT.TRAP
    uint64_t bpt = 0x0000000000800300ULL;
    *out = bpt;
}

static void
gen_jcal(uint64_t addr, bool callDepth, uint32_t ra, uint64_t *out)
{
    if (callDepth)
        *out = GK110SASS_INST_JCAL((uint32_t)addr);
    else
        *out = GK110SASS_INST_JCAL_NOINC((uint32_t)addr);
}

static void
gen_ret(uint64_t addr, bool callDepth, uint32_t ra, uint64_t *out)
{
    *out = GK110SASS_INST_RET;
}

static void
gen_csetp(uint32_t test, uint32_t pred, uint64_t *out)
{
    *out = GK110SASS_INST_CSETP(pred, test);
}

static void
gen_mov(uint32_t rdest, uint32_t rsrc, uint64_t *out)
{
    *out = GK110SASS_INST_MOV(rdest, rsrc);
}

static void
gen_movFromImm(uint32_t rdest, uint32_t imm, uint64_t *out)
{
    *out = GK110SASS_INST_MOV32I(rdest, imm);
}

static void
gen_jmp(uint64_t addr, uint64_t *out)
{
    *out = GK110SASS_INST_JMP_ABS((uint32_t)addr);
}

static void
gen_longjmpWithPredCC(const uint64_t *inst, uint64_t *out)
{
    uint32_t pred = BF_GET(GK110SASS_PRED, *inst);
    uint32_t cc = BF_GET(GK110SASS_CCC, *inst);

    if (is_exit(inst))
        *out = (GK110SASS_INST5_6(CTRL, LONGJMP) + BF_FLDV(GK110SASS_CCC, cc) + BF_FLDV(GK110SASS_PRED, pred));
    else
        *out = GK110SASS_INST_LONGJMP;
}

static void
gen_retWithPredCC(const uint64_t *inst, uint64_t *out)
{
    uint32_t pred = BF_GET(GK110SASS_PRED, *inst);
    uint32_t cc = BF_GET(GK110SASS_CCC, *inst);

    if (is_exit(inst))
        *out = (GK110SASS_INST5_6(CTRL, RET) + BF_FLDV(GK110SASS_CCC, cc) + BF_FLDV(GK110SASS_PRED, pred));
    else
        *out =GK110SASS_INST_RET;
}

static void
kepler_getTexDepBar(MCrec *rec, uint64_t *out)
{
    *out = GK110SASS_INST_TEXDEPBAR;
}

static uint32_t
kepler_gk11x_isDirectCall(const uint64_t *inst)
{
    return (is_jcal(inst) || is_jmp(inst));
}

static bool
has_plg(const uint64_t *inst)
{
    return false;
}

static bool
barHasThreadCount(const uint64_t *inst)
{
    uint32_t barsrcmode = 0;
    uint32_t count = 0;

    if (!is_synchronizing_barrier(inst)) {
        CU_ERROR_PRINT(("Not a barrier\n"));
        return false;
    }

    count = BF_GET(34:23, *inst);
    barsrcmode = BF_GET(GK110SASS_BARSRCMODE, *inst);
    switch (barsrcmode) {
    case GK110SASS_BARSRCMODE__REGNAME_REGCOUNT:
    case GK110SASS_BARSRCMODE__IMMNAME_REGCOUNT:
        /* R255 is RZ */
        if (count != 255) {
            CU_ERROR_PRINT(("Got a non zero register count\n"));
            return true;
        }
        return false;
        break;
    case GK110SASS_BARSRCMODE__REGNAME_IMMCOUNT:
    case GK110SASS_BARSRCMODE__IMMNAME_IMMCOUNT:
        if (count != 0) {
            CU_ERROR_PRINT(("Got a non zero immediate count\n"));
            return true;
        }
        return false;
        break;
    default:
        CU_ERROR_PRINT(("Invalid barsrcmode\n"));
        return false;
    }

    return false;
}

static uint32_t
barGetNameReg(const uint64_t *inst)
{
    uint32_t barsrcmode = 0;

    if (!is_synchronizing_barrier(inst)) {
        CU_ERROR_PRINT(("Not a barrier\n"));
        return RZ;
    }

    barsrcmode = BF_GET(GK110SASS_BARSRCMODE, *inst);
    switch (barsrcmode) {
    case GK110SASS_BARSRCMODE__REGNAME_REGCOUNT:
    case GK110SASS_BARSRCMODE__REGNAME_IMMCOUNT:
        /* Register name */
        return (uint32_t)BF_GET(17:10, *inst);

    case GK110SASS_BARSRCMODE__IMMNAME_REGCOUNT:
    case GK110SASS_BARSRCMODE__IMMNAME_IMMCOUNT:
        return RZ;

    default:
        CU_ERROR_PRINT(("Invalid barsrcmode\n"));
        return RZ;
    }

    return RZ;
}

static uint32_t
barGetNameImm(const uint64_t *inst)
{
    uint32_t barsrcmode = 0;

    if (!is_synchronizing_barrier(inst)) {
        CU_ERROR_PRINT(("Not a sync barrier\n"));
        return 0;
    }

    barsrcmode = BF_GET(GK110SASS_BARSRCMODE, *inst);
    switch (barsrcmode) {
    case GK110SASS_BARSRCMODE__REGNAME_REGCOUNT:
    case GK110SASS_BARSRCMODE__REGNAME_IMMCOUNT:
        /* Register name */
        return 0;

    case GK110SASS_BARSRCMODE__IMMNAME_REGCOUNT:
    case GK110SASS_BARSRCMODE__IMMNAME_IMMCOUNT:
        return (uint32_t)(BF_GET(17:10, *inst) & 0xf);

    default:
        CU_ERROR_PRINT(("Invalid barsrcmode\n"));
        return 0;
    }

    return 0;
}

static uint32_t
barGetCountReg(const uint64_t *inst)
{
    uint32_t barsrcmode = 0;

    if (!is_synchronizing_barrier(inst)) {
        CU_ERROR_PRINT(("Not a barrier\n"));
        return RZ;
    }

    barsrcmode = BF_GET(GK110SASS_BARSRCMODE, *inst);
    switch (barsrcmode) {
    case GK110SASS_BARSRCMODE__REGNAME_REGCOUNT:
    case GK110SASS_BARSRCMODE__IMMNAME_REGCOUNT:
        /* Register count */
        return (uint32_t)BF_GET(34:23, *inst);

    case GK110SASS_BARSRCMODE__REGNAME_IMMCOUNT:
    case GK110SASS_BARSRCMODE__IMMNAME_IMMCOUNT:
        return RZ;

    default:
        CU_ERROR_PRINT(("Invalid barsrcmode\n"));
        return RZ;
    }

    return RZ;
}

static uint32_t
barGetCountImm(const uint64_t *inst)
{
    uint32_t barsrcmode = 0;

    if (!is_synchronizing_barrier(inst)) {
        CU_ERROR_PRINT(("Not a sync barrier\n"));
        return 0;
    }

    barsrcmode = BF_GET(GK110SASS_BARSRCMODE, *inst);
    switch (barsrcmode) {
    case GK110SASS_BARSRCMODE__REGNAME_REGCOUNT:
    case GK110SASS_BARSRCMODE__IMMNAME_REGCOUNT:
        /* Register count */
        return 0;

    case GK110SASS_BARSRCMODE__REGNAME_IMMCOUNT:
    case GK110SASS_BARSRCMODE__IMMNAME_IMMCOUNT:
        return (uint32_t)(BF_GET(34:23, *inst) & 0x0fff);

    default:
        CU_ERROR_PRINT(("Invalid barsrcmode\n"));
        return 0;
    }

    return 0;
}

static void
genLmemHiSpill(uint32_t lmemHiOffset, uint32_t asize, uint32_t regb, uint64_t *out)
{
    if (asize <= 4)
        *out = GK110SASS_INST_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH + lmemHiOffset, regb);
    else if (asize == 8)
        *out = GK110SASS_INST_STL64(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH + lmemHiOffset, regb);
    else if (asize == 16)
        *out = GK110SASS_INST_STL128(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH + lmemHiOffset, regb);
    else {
        CU_ERROR_PRINT(("Invalid asize : %u\n", asize));
        *out = GK110SASS_INST_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH + lmemHiOffset, regb);
    }

}

static void
gen_lmemHiRead(uint32_t lmemHiOffset, uint32_t asize, uint32_t regd, uint64_t *out)
{
    if (asize <= 4)
        *out = GK110SASS_INST_LDL(regd, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH + lmemHiOffset);
    else if (asize == 16)
        *out = GK110SASS_INST_LDL128(regd, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH + lmemHiOffset);
    else {
        CU_ERROR_PRINT(("Invalid asize: %u\n", asize));
        *out = GK110SASS_INST_LDL(regd, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH + lmemHiOffset);
    }
}

static uint32_t
get_ra(const uint64_t *inst)
{
    if (is_gtas_ld(inst) || is_gtas_st(inst) ||
        is_sld(inst) || is_sst(inst) ||
        is_atom(inst) || is_red(inst) ||
        is_gld(inst) )
        return BF_GET(GK110SASS_REGA, *inst);
    else
        return RZ;
}

static uint32_t
get_rb(const uint64_t *inst)
{
    if (is_gtas_st(inst) || is_sst(inst) || is_lst(inst))
        return BF_GET(GK110SASS_REGDEST, *inst);
    else if (is_atom(inst))
        return BF_GET(GK110SASS_REGB, *inst);
    else
        return RZ;
}

static uint32_t
get_ccTest(const uint64_t *inst)
{
    if (is_exit(inst) ||
        is_ret(inst) ||
        is_jmp(inst) ||
        is_jmx(inst)) {
        return BF_GET(GK110SASS_CCC, *inst);
    } else {
        CU_ERROR_PRINT(("Invalid instruction for ccTest\n"));
        return 0;
    }
}

#define PRED_MASK BF_FLDV(21:18, ~0ULL)
#define PRED_INV_MASK BF_FLDV(21:21, ~0ULL)

static uint64_t
get_predRawInv(const uint64_t *inst)
{
    return ((*inst ^ PRED_INV_MASK) & PRED_MASK);
}

static uint64_t
get_predMask(const uint64_t *inst)
{
    return (PRED_MASK);
}

static uint32_t
get_predWithInv(const uint64_t *inst)
{
    return (uint32_t)(((*inst & PRED_MASK) >> 18) & 0xf);
}

static bool
kepler_gk11x_isValidCodeAddr(uint64_t addr)
{
    return true;
}

static uint32_t
get_instSourceType(const uint64_t *inst)
{
    if (is_synchronizing_barrier(inst)) {
        uint32_t barsrcmode = BF_GET(GK110SASS_BARSRCMODE, *inst);

        switch (barsrcmode) {
        case GK110SASS_BARSRCMODE__REGNAME_REGCOUNT:
            return MC_INST_SOURCE_TYPE_REGISTER;
        case GK110SASS_BARSRCMODE__IMMNAME_REGCOUNT:
        case GK110SASS_BARSRCMODE__REGNAME_IMMCOUNT:
            return MC_INST_SOURCE_TYPE_REGISTER | MC_INST_SOURCE_TYPE_IMMEDIATE;
        case GK110SASS_BARSRCMODE__IMMNAME_IMMCOUNT:
            return MC_INST_SOURCE_TYPE_IMMEDIATE;
        default:
            CU_ERROR_PRINT(("Invalid barsrcmode\n"));
            break;
        }
    }

    return MC_INST_SOURCE_TYPE_UNKNOWN;
}

static void
kepler_gk11x_setRegCountInQmd(NvU32 *qmdData, unsigned int regCount)
{
    ASSIGN_HWVALUE_MW(qmdData, A1C0, QMDV01_07, REGISTER_COUNT, regCount);
}

void
memcheckInitHal_kepler_gk11x(MChal *hal, MCtoolModeArchs arch)
{
    memcheckInitHal_common(hal, arch);

    hal->maxJumpOffset      = 1ULL << 32;  //32 bits
    hal->savedSPAddr        = CU_KEPLER_THREAD_STATE_OFFSET(savedUserStackPointer);
    hal->cnpReservedLmemStart = CU_KEPLER_THREAD_STATE_POINTER;
    hal->cnpReservedLmemSize  = CU_KEPLER_LMEM_THREAD_STATE_SIZE;
    hal->genTexDrainInstruction = kepler_getTexDepBar;

    hal->gridParamsConstBank = CU_KEPLER_PARAM_CONST_SEGMENT;
    hal->gridParamsUserStackTopOffset = CU_KEPLER_DCI_OFFSET(userStackPointer);
    hal->gridParamsSWinLoOffset = CU_KEPLER_DCI_OFFSET(sharedWindowBase);
    hal->driverInternalParamsConstBank = CU_KEPLER_PARAM_CONST_SEGMENT;
    hal->driverInternalParamsShmemSizeOffset = CNP_GRID_PARAM_OFFSET(totalShmemSize);

    hal->getRz             = get_rz;

    hal->isNop             = is_nop;
    hal->isGtasLd          = is_gtas_ld;
    hal->isGtasSt          = is_gtas_st;
    hal->isLds             = is_sld;
    hal->isSts             = is_sst;
    hal->isLdl             = is_lld;
    hal->isStl             = is_lst;
    hal->isRed             = is_red;
    hal->isAtom            = is_atom;
    hal->isAbsoluteCall    = is_jcal;
    hal->isRelativeCall    = is_cal;
    hal->isSynchronizingBarrier = is_synchronizing_barrier;
    hal->isExit            = is_exit;
    hal->isRet             = is_ret;
    hal->isJmx             = is_jmx;
    hal->isLdg             = is_gld;
    hal->isStg             = stub;
    hal->isShfl            = is_shfl;

    hal->hasPlg            = has_plg;

    hal->genAbsoluteCall   = gen_jcal;
    hal->genRet            = gen_ret;
    hal->genMov            = gen_mov;
    hal->genMovFromImm     = gen_movFromImm;
    hal->genJmp            = gen_jmp;
    hal->genLongJmpWithPredCC = gen_longjmpWithPredCC;
    hal->genRetWithPredCC  = gen_retWithPredCC;
    hal->genCsetp          = gen_csetp;

    hal->getRa             = get_ra;
    hal->getRb             = get_rb;
    hal->getCcTest         = get_ccTest;
    hal->getPredRawInv     = get_predRawInv;
    hal->getPredMask       = get_predMask;
    hal->getPredWithInv    = get_predWithInv;

    hal->getMemAccessSize   = getMemAccessSize;
    hal->getExtended        = getExtended;
    hal->getOffset          = getOffset;
    hal->isWrite            = is_write;

    hal->barHasThreadCount  = barHasThreadCount;
    hal->barGetNameReg      = barGetNameReg;
    hal->barGetNameImm      = barGetNameImm;
    hal->barGetCountReg     = barGetCountReg;
    hal->barGetCountImm     = barGetCountImm;

    hal->genLmemHiSpill     = genLmemHiSpill;
    hal->genLmemHiRead      = gen_lmemHiRead;
    hal->genBreakInstruction = kepler_gk11x_getBreakInstruction;
    hal->isDirectCall        = kepler_gk11x_isDirectCall;
    hal->isIndirectCall      = is_jmx;
    hal->isValidCodeAddr     = kepler_gk11x_isValidCodeAddr;
    hal->getInstSourceType   = get_instSourceType;

    hal->setRegCountInQmd   = kepler_gk11x_setRegCountInQmd;
}
