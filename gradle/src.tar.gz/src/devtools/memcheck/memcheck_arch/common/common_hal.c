/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: common_hal.c
 *
 *   Description:
 *       The Common HAL functions
 *
 ******************************************************************************/

#include "memcheck_types.h"

#include "halo.h"

static uint32_t
hal_getInstSize(void)
{
    return 8;
}

static bool
hal_isValidCodeAddr(uint64_t addr)
{
    return true;
}

static bool
hal_isPcInRange(uint64_t patchPC, MCrec *rec)
{
    if (!rec || !rec->context)
        return false;

    /* The patchPC needs to be an absolute 32 bit address */
    if (patchPC < rec->context->hal.maxJumpOffset)
        return true;

    return false;
}

static CUresult
hal_patchTrampoline(CCmemHandle *mem, uint64_t targetAddr, MCcontext *mcctx)
{
    uint64_t *hostPtr = NULL;
    uint32_t size = 0;
    uint64_t patchInst = 0;
    uint32_t ctr = 0;

    CU_TRACE_FUNCTION();

    if (!mem || !mcctx)
        return CUDA_ERROR_UNKNOWN;

    hostPtr = (uint64_t*)mem->host.ptr;
    size = (uint32_t)mem->size;

    if (!hostPtr || !size) {
        CU_ERROR_PRINT(("Function not loaded correctly\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    for (ctr = 0; ctr < size; ctr += sizeof(*hostPtr), ++hostPtr) {
        if (!mcctx->hal.isValidCodeAddr(ctr + mem->dev.dPtr))
            continue;

        if (mcctx->hal.isAbsoluteCall(hostPtr)) {
            mcctx->hal.genAbsoluteCall(targetAddr, true, mcctx->hal.getRz(), &patchInst);
            CU_TRACE_PRINT(("Patching original instruction 0x%" PRIx64 " with 0x%" PRIx64 "\n",
                            *hostPtr, patchInst));
            *hostPtr = patchInst;
        }
    }

    return CUDA_SUCCESS;
}

static CUresult
hal_prescanFunction(MCfunc *mcfunc, MCcontext *mcctx)
{
    uint32_t i = 0;
    uint64_t *instptr = NULL;

    CU_TRACE_FUNCTION();

    if (!mcfunc || !mcctx) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    instptr = (uint64_t*)mcfunc->mem.host.ptr;
    mcfunc->numIndirectCalls = 0;

    for (i = 0; i < mcfunc->mem.size / sizeof(uint64_t); i += mcctx->hal.getInstSize() / sizeof(uint64_t)) {
        if (!mcctx->hal.isValidCodeAddr((i * mcctx->hal.getInstSize()) + mcfunc->mem.dev.dPtr))
            continue;

        if (mcctx->hal.isIndirectCall(instptr + i))
            ++mcfunc->numIndirectCalls;
    }

    CU_TRACE_PRINT(("Loaded function : %s with %u indirect calls\n",
                    mcfunc->funcName, mcfunc->numIndirectCalls));

    return CUDA_SUCCESS;
}

static CUresult
hal_patchJumpPointCommon(MCcontext *mcctx, CCmemHandle *mem, uint64_t instOffset, uint64_t targetAddr, uint32_t isAbsoluteCall)
{
    char *cp = NULL;
    uint64_t jmpWord;

    if (!mcctx || !mem) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    cp = (char*)mem->host.ptr + instOffset;

    if (isAbsoluteCall)
        mcctx->hal.genAbsoluteCall(targetAddr, true, mcctx->hal.getRz(), &jmpWord);
    else
        mcctx->hal.genJmp(targetAddr, &jmpWord);
    memcpy(cp, (char*)&jmpWord, sizeof(jmpWord));

    return CUDA_SUCCESS;
}

static CUresult
hal_patchJumpPoint(MCcontext *mcctx, CCmemHandle *mem, uint64_t instOffset, uint64_t targetAddr)
{
    return hal_patchJumpPointCommon(mcctx, mem, instOffset, targetAddr, 0);
}

static CUresult
hal_patchAbsoluteCallPoint(MCcontext *mcctx, CCmemHandle *mem, uint64_t instOffset, uint64_t targetAddr)
{
    return hal_patchJumpPointCommon(mcctx, mem, instOffset, targetAddr, 1);
}

static CUresult
hal_patchLongjmp(MCcontext *mcctx, CCmemHandle *mem, uint64_t instOffset)
{
    char *cp = NULL;
    uint64_t jmpWord, oldWord;

    if (!mcctx || !mem) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    cp = (char*)mem->host.ptr + instOffset;

    memcpy(&oldWord, cp, sizeof(oldWord));

    mcctx->hal.genLongJmpWithPredCC(&oldWord, &jmpWord);
    memcpy(cp, (char*)&jmpWord, sizeof(jmpWord));

    return CUDA_SUCCESS;
}

static bool
hal_isAtomS(const uint64_t *inst)
{
    return false;
}

static bool
hal_isAtomG(const uint64_t *inst)
{
    return false;
}

static bool
hal_isWarpsync(const uint64_t *inst)
{
    return false;
}

static bool
hal_isShfl(const uint64_t *inst)
{
    return false;
}

static bool
hal_hasPlg(const uint64_t *inst)
{
    return false;
}

static void
hal_genPlgRawInv(const uint64_t *op, uint64_t *out)
{
    CU_ASSERT(0);
}

static MCatomScope
hal_getAtomScope(const uint64_t *inst)
{
    return MC_ATOM_SCOPE_NONE;
}

static uint64_t
hal_getControlFlowImm(const uint64_t *inst, bool *isSigned)
{
    return 0;
}

static bool
hal_getControlFlowDepth(const uint64_t *inst)
{
    return false;
}

static bool
hal_getRetIsAbs(const uint64_t *inst)
{
    return false;
}

static uint32_t
hal_getInstSourceType(const uint64_t *inst)
{
    return MC_INST_SOURCE_TYPE_UNKNOWN;
}

static uint32_t
hal_getCBank(const uint64_t *inst, uint32_t *bank, uint32_t *offset)
{
    return 0;
}

static void
hal_genMovCBank(uint32_t rdest, uint32_t cBank, uint32_t cOffset, uint64_t *out)
{
}

static bool
hal_hasUniformRegister(const uint64_t *inst)
{
    return false;
}

static bool
hal_getU64(const uint64_t *inst)
{
    return false;
}

static uint32_t
hal_getURz(void)
{
    return 0;
}

static uint32_t
hal_getURb(const uint64_t *inst)
{
    return 0;
}

static void
hal_genMovFromUR(uint32_t rdest, uint32_t rsrc, uint64_t *out)
{
    CU_ASSERT(0);
}

static void
hal_genMovCBankUR(uint32_t rdest, uint32_t urb, uint32_t offset, uint64_t *out)
{
    CU_ASSERT(0);
}

static uint32_t
hal_getStrideShift(const uint64_t *inst)
{
    CU_ASSERT(0);
    return 0;
}

static uint32_t
hal_getPnzInvAsPgMask(const uint64_t *inst)
{
    CU_ASSERT(0);
    return 0;
}

static uint64_t
hal_getInputPredRawInv(const uint64_t *inst)
{
    // Implement if needed
    CU_ASSERT(0);
    return 0;
}

static uint64_t
hal_getInputPredMask(const uint64_t *inst)
{
    // Implement if needed
    CU_ASSERT(0);
    return 0;
}

static uint32_t
hal_getInputPredWithInv(const uint64_t *inst)
{
    // Implement if needed
    CU_ASSERT(0);
    return 0;
}

void
memcheckInitHal_common(MChal *hal, MCtoolModeArchs arch)
{
    hal->arch               = arch;
    hal->getInstSize        = hal_getInstSize;
    hal->isValidCodeAddr    = hal_isValidCodeAddr;
    hal->isPcInRange        = hal_isPcInRange;
    hal->patchTrampoline    = hal_patchTrampoline;
    hal->prescanFunction    = hal_prescanFunction;
    hal->patchJumpPoint     = hal_patchJumpPoint;
    hal->patchAbsoluteCallPoint = hal_patchAbsoluteCallPoint;
    hal->patchLongjmp       = hal_patchLongjmp;
    hal->isAtomS            = hal_isAtomS;
    hal->isAtomG            = hal_isAtomG;
    hal->isWarpSync         = hal_isWarpsync;
    hal->isShfl             = hal_isShfl;
    hal->hasPlg             = hal_hasPlg;
    hal->genPlgRawInv       = hal_genPlgRawInv;
    hal->getAtomScope       = hal_getAtomScope;
    hal->getControlFlowImm  = hal_getControlFlowImm;
    hal->getControlFlowDepth  = hal_getControlFlowDepth;
    hal->getRetIsAbs        = hal_getRetIsAbs;
    hal->getInstSourceType  = hal_getInstSourceType;
    hal->getCBank           = hal_getCBank;
    hal->genMovCBank        = hal_genMovCBank;
    hal->genMovCBankUR      = hal_genMovCBankUR;
    hal->hasUniformRegister = hal_hasUniformRegister;
    hal->getU64             = hal_getU64;
    hal->getURz             = hal_getURz;
    hal->getURb             = hal_getURb;
    hal->genMovFromUR       = hal_genMovFromUR;
    hal->getStrideShift     = hal_getStrideShift;
    hal->getPnzInvAsPgMask  = hal_getPnzInvAsPgMask;

    hal->getInputPredRawInv  = hal_getInputPredRawInv;
    hal->getInputPredMask    = hal_getInputPredMask;
    hal->getInputPredWithInv = hal_getInputPredWithInv;
}
