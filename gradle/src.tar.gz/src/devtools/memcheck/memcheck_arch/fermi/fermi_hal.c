/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: fermi_hal.c
 *
 *   Description:
 *       The HAL implementation for Fermi
 *
 ******************************************************************************/

#include "memcheck_types.h"
#include "memcheck_error.h"

#include "halo.h"
#include "fermi_opcodes.h"

#define SIGN_EXT(x, N) ( ((x) << N) >> N )

#define PRED_MASK MSK ( FERMI_PRED )
#define PRED_INV_MASK ( PRED_MASK & ( PRED_MASK << 3U ) )

static uint32_t
get_rz(void)
{
    return RZ;
}

static bool
is_nop(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    if (IS_NARROW(tmp)) {
        // We can't handle narrow instructions yet
        return false;
    }

    tmp &= FERMI64_MASK6;

    if (tmp == (NOP & FERMI64_MASK6))
        return true;

    return false;
}

static bool
is_gtas_ld(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    if (IS_NARROW(tmp)) {
        // We can't handle narrow instructions yet
        return false;
    }

    tmp &= FERMI64_MASK;

    if (tmp == LD || tmp == LDU)
        return true;

    return false;
}

static bool
is_gtas_st(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    if (IS_NARROW(tmp)) {
        // We can't handle narrow instructions yet
        return false;
    }

    tmp &= FERMI64_MASK;

    if (tmp == ST)
        return true;

    return false;
}

static bool
is_sld(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    if (IS_NARROW(tmp)) {
        // We can't handle narrow instructions yet
        return false;
    }

    tmp &= FERMI64_MASK8;

    if (tmp == INST_LDS)
        return true;

    return false;
}

static bool
is_sst(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    if (IS_NARROW(tmp)) {
        // We can't handle narrow instructions yet
        return false;
    }

    tmp &= FERMI64_MASK8;

    if (tmp == INST_STS)
        return true;

    return false;
}

static bool
is_lld(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    if (IS_NARROW(tmp)) {
        // We can't handle narrow instructions yet
        return false;
    }

    tmp &= FERMI64_MASK8;

    if (tmp == INST_LDL)
        return true;

    return false;
}

static bool
is_lst(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    if (IS_NARROW(tmp)) {
        // We can't handle narrow instructions yet
        return false;
    }

    tmp &= FERMI64_MASK8;

    if (tmp == INST_STL)
        return true;

    return false;
}

static bool
is_atom(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    if (IS_NARROW(tmp)) {
        // We can't handle narrow instructions yet
        return false;
    }

    tmp &= FERMI64_MASK2;

    if (tmp == INST_ATOM)
        return true;

    return false;
}

static bool
is_red(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    if (IS_NARROW(tmp)) {
        // We can't handle narrow instructions yet
        return false;
    }

    tmp &= FERMI64_MASK2;

    if (tmp == INST_RED)
        return true;

    return false;
}

static bool
is_jcal(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    if (IS_NARROW(tmp)) {
        return false;
    }

    tmp &= 0xf800000000000007ULL;
    return (tmp == FERMI64_INST(JCAL, CTF));
}

static bool
is_jmx(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    if (IS_NARROW(tmp)) {
        return false;
    }

    tmp &= 0xf800000000000007ULL;
    return (tmp == FERMI64_INST(JMX, CTF));
}

static bool
is_jmp(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    if (IS_NARROW(tmp))
        return false;

    tmp &= 0xf800000000000007ULL;
    return (tmp == FERMI64_INST(JMP, CTF));
}

static bool
is_cal(const uint64_t *inst)
{
    uint64_t tmp = *inst;
    if (IS_NARROW(tmp)) {
        // We can't handle narrow instructions yet
        return false;
    }

    tmp &= 0xf800000000000007ULL;
    return (tmp == FERMI64_INST(CAL, CTF));
}

// Kepler definitions for barmode
// From //hw/doc/gpu/kepler/kepler/design/IAS/SML1/ISA/opcodes/IAS_Visible_ISA_Kepler.vsd
// TODO: Merge into GK10x
#define KEPLER_GK10X_BARMODE_SYNC 0
#define KEPLER_GK10X_BARMODE_RED  2

static bool
is_bar(const uint64_t inst, uint32_t *barmode)
{
    uint64_t masked;

    masked = inst & (FERMI64_MASK6);

    if (masked == INST_BAR) {
        if (barmode) {
            // Hack: this has only been tested on GK10x and should be moved
            // to that HAL. However, since GK10x is essentially derived from Fermi
            // and that we don't support Fermi anymore, let's allow some Kepler-specific
            // code here. TODO: Merge Fermi layer into GK10x and remove redundant code.
            *barmode = (uint32_t)((inst & 0x380ULL) >> 7);
        }
        return true;
    }
    return false;
}

static bool
is_synchronizing_barrier(const uint64_t *inst)
{
    uint32_t barmode = 0;

    if (!is_bar(*inst, &barmode))
        return false;

    // Only count BAR.SYNC or BAR.RED, which imply a sync
    return (barmode == KEPLER_GK10X_BARMODE_SYNC || barmode == KEPLER_GK10X_BARMODE_RED);
}

static bool
is_exit(const uint64_t *inst)
{
    return ((*inst & FERMI64_MASK) == (EXIT & FERMI64_MASK));
}

static bool
is_ret(const uint64_t *inst)
{
    return ((*inst & FERMI64_MASK) == (RET & FERMI64_MASK));
}

static bool
getExtended(const uint64_t *inst)
{
    uint64_t masked;
    uint64_t tmp = *inst;

    if (IS_NARROW(tmp)) {
        // We can't handle narrow instructions yet
        return false;
    }

    masked = tmp & FERMI64_MASK;
    if (masked == LD || masked == LDU || masked == ST)
        return (GET(FERMI64_LDST_A64, tmp) != 0);

    masked = tmp & FERMI64_MASK8;
    if (masked == INST_LDL || masked == INST_LDS || masked == INST_STL || masked == INST_STS)
        return false;

    masked = tmp & FERMI64_MASK2;
    if (masked == INST_ATOM  || masked == INST_RED)
        return (GET(FERMI64_LDST_A64, tmp) != 0);

    CU_ASSERT(0);
    return false;
}

static uint32_t
getOffset(const uint64_t *inst)
{
    uint64_t masked;
    int32_t rawVal = 0;
    uint64_t tmp = *inst;

    if (IS_NARROW(tmp)) {
        // We can't handle narrow instructions yet
        return 0;
    }

    masked = tmp & FERMI64_MASK;
    if (masked == LD || masked == LDU || masked == ST)
        return GET(FERMI64_IMM32, tmp);

    masked = tmp & FERMI64_MASK8;
    if (masked == INST_LDL || masked == INST_LDS ||
        masked == INST_STL || masked == INST_STS) {
        rawVal = GET(FERMI64_IMM24, tmp);
        if (GET(FERMI_REGA, tmp) != RZ)
            // Sign extended
            rawVal = SIGN_EXT(rawVal, 8);
        return (uint32_t) rawVal;
    }

    masked = tmp & FERMI64_MASK2;
    if (masked == INST_ATOM) {
        rawVal = GET(FERMI64_IMM17, tmp);
        rawVal += GET(FERMI64_ICOMP3, tmp) << 17;
        if (GET(FERMI_REGA, tmp) != RZ)
            // Sign extended
            rawVal = SIGN_EXT(rawVal, 12);
        return (uint32_t) rawVal;
    }

    if (masked == INST_RED)
        return GET(FERMI64_IMM32, tmp);

    return 0;
}

static bool
is_write(const uint64_t *inst)
{
    if (is_gtas_st(inst) || is_sst(inst) || is_lst(inst) ||
        is_red(inst))
        return true;

    return false;
}

/* Returns the size in bytes of a memory access instruction */
static uint32_t
getMemAccessSize(const uint64_t *inst, const MCfunc *func, const uint64_t pc)
{
    // Commented out is SIZE3 encoding. SIZERA is SIZE3 only expanded
    // const static uint32_t sizes[8] = {1, 1, 2, 2, 4, 8, 16, 4};
    const static uint32_t sizes[16] = {1, 1, 2, 2, 4, 8, 16, 4, 8, 16, 2, 4, 8, 0, 0, 0};
    uint64_t masked;
    uint64_t tmp = *inst;

    if (IS_NARROW(tmp)) {
        // We can't handle narrow instructions yet
        return 4;
    }

    masked = tmp & FERMI64_MASK;
    if (masked == LD || masked == LDU || masked == ST)
        return sizes[GET(FERMI64_SIZE3, tmp)];

    masked = tmp & FERMI64_MASK8;
    if (masked == INST_LDL || masked == INST_LDS || masked == INST_STL || masked == INST_STS)
        return sizes[GET(FERMI64_SIZE3, tmp)];

    //XXX: RED encoding is not according to fermi visio bitfields!
    masked = tmp & FERMI64_MASK2;
    if (masked == INST_ATOM || masked == INST_RED) {
        uint32_t size = (GET(FERMI64_TOP5, tmp) & 0x7) << 1;
        size += GET(9:9, tmp);
        return sizes[size];
    }

    CU_ASSERT(0);

    return 0;
}

static void
fermi_getBreakInstruction(MCrec *rec, uint64_t *out)
{
    *out = PAIR(BREAKPT_N, NOP_N);
}

static void
fermi_getTexDrainInstruction(MCrec *rec, uint64_t *out)
{
    // No explicit texture drain, put a nop
    *out = MOV(RZ, RZ);
}

static uint32_t
fermi_isDirectCall(const uint64_t *inst)
{
    return (is_jcal(inst) || is_jmp(inst));
}

static bool
has_plg(const uint64_t *inst)
{
    return false;
}

static bool
is_gld(const uint64_t *inst)
{
    return false;
}

static bool
is_gst(const uint64_t *inst)
{
    return false;
}

static void
gen_jcal(uint64_t addr, bool callDepth, uint32_t ra, uint64_t *out)
{
    *out = JCAL((uint32_t)addr);
}

static void
gen_ret(uint64_t addr, bool callDepth, uint32_t ra, uint64_t *out)
{
    *out = RET;
}

static void
gen_jmp(uint64_t addr, uint64_t *out)
{
    *out = JMP_ABS((uint32_t)addr);
}

static void
gen_longjmpPredCC(const uint64_t *inst, uint64_t *out)
{
    uint32_t pred = GET(FERMI_PRED, *inst);
    uint32_t cc = GET(FERMI64_CC, *inst);

    if (is_exit(inst))
        *out = PRED(pred, CC(cc, LONGJMP));
    else
        *out = LONGJMP;
}

static void
gen_mov(uint32_t rdest, uint32_t rsrc, uint64_t *out)
{
    *out = MOV(rdest, rsrc);
}

static void
gen_movFromImm(uint32_t rdest, uint32_t imm, uint64_t *out)
{
    *out = MOV32I(rdest, imm);
}

static void
gen_retPredCC(const uint64_t *inst, uint64_t *out)
{
    uint32_t pred = GET(FERMI_PRED, *inst);
    uint32_t cc = GET(FERMI64_CC, *inst);

    if (is_exit(inst))
        *out = PRED(pred, CC(cc, RET));
    else
        *out = RET;
}

static uint32_t
get_ra(const uint64_t *inst)
{
    if (IS_NARROW(*inst)) {
        CU_DEBUG_PRINT(("Got a narrow inst\n"));
        return RZ; // Return RZ
    }

    return (GET(FERMI_REGA, *inst));
}

static uint32_t
get_rb(const uint64_t *inst)
{
    if (IS_NARROW(*inst)) {
        CU_DEBUG_PRINT(("Got a narrow\n"));
        return RZ; // Return RZ;
    }

    return (GET(FERMI_REGB, *inst));
}

static uint64_t
get_predRawInv(const uint64_t *inst)
{
    if (IS_NARROW(*inst)) {
        CU_ERROR_PRINT(("Got a narrow\n"));
        return PRED_MASK;
    }

    return ((PRED_MASK & (*inst)) ^ PRED_INV_MASK);
}

static uint64_t
get_predMask(const uint64_t *inst)
{
    return PRED_MASK;
}

static uint32_t
get_predWithInv(const uint64_t *inst)
{
    return (uint32_t)((PRED_MASK & (*inst) >> (BF_LO(FERMI_PRED))) & 0xf);
}

static void
genLmemHiSpill(uint32_t lmemHiOff, uint32_t asize, uint32_t regb, uint64_t *out)
{
    if (asize <= 4)
        *out = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH + lmemHiOff, regb);
    else if (asize == 8)
        *out = STL64(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH + lmemHiOff, regb);
    else if (asize == 16)
        *out = STL128(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH + lmemHiOff, regb);
    else {
        CU_ERROR_PRINT(("Unknown asize : %u\n", asize));
        *out = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH + lmemHiOff, regb);
    }
}

static void
gen_lmemHiRead(uint32_t lmemHiOff, uint32_t asize, uint32_t regd, uint64_t *out)
{
    if (asize <=  4)
        *out = LDL(regd, FERMI_LMEM_HI_MEMCHECK_SCRATCH + lmemHiOff, RZ);
    else if (asize == 16)
        *out = LDL128(regd, FERMI_LMEM_HI_MEMCHECK_SCRATCH + lmemHiOff, RZ);
    else {
        CU_ERROR_PRINT(("Unknown asize: %u\n", asize));
        *out = LDL(regd, FERMI_LMEM_HI_MEMCHECK_SCRATCH + lmemHiOff, RZ);
    }
}

static bool
barHasThreadCount(const uint64_t *inst)
{
    uint32_t type = 0;

    if (!is_synchronizing_barrier(inst)) {
        CU_ERROR_PRINT(("Not a bar inst\n"));
        return false;
    }

    type = GET(FERMI64_ABC,*inst);
    if (type == 3 && GET(FERMI64_IMM12, *inst) != 0) {
        CU_ERROR_PRINT(("Barrier has a threadcount!! failing\n"));
        return true;
    }
    else if (type == 0 && GET(FERMI64_REG6, *inst) != RZ) {
        CU_ERROR_PRINT(("Barrier has a register. Possibly a nonzero thread count\n"));
        return true;
    }
    return false;
}

static uint32_t
barGetNameReg(const uint64_t *inst)
{
    uint32_t type = 0;

    if (!is_synchronizing_barrier(inst)) {
        CU_ERROR_PRINT(("Not a sync bar inst\n"));
        return RZ;
    }

    type = GET(FERMI64_ABC, *inst);
    /* If the A field is 1, then the barname is an immediate */
    if (type & 0x2) {
        return RZ;
    }
    else {
        return (uint32_t)GET(FERMI_REGA, *inst);
    }
}

static uint32_t
barGetNameImm(const uint64_t *inst)
{
    uint32_t type = 0;

    if (!is_synchronizing_barrier(inst)) {
        CU_ERROR_PRINT(("Not a sync bar inst\n"));
        return 0;
    }

    type = GET(FERMI64_ABC, *inst);
    /* If the A field is 1, then the barname is an immediate */
    if (type & 0x2) {
        return GET(23:20, *inst);
    }
    else {
        return 0;
    }
}

static uint32_t
barGetCountReg(const uint64_t *inst)
{
    uint32_t type = 0;

    if (!is_synchronizing_barrier(inst)) {
        CU_ERROR_PRINT(("Not a sync bar inst\n"));
        return RZ;
    }

    type = GET(FERMI64_ABC, *inst);
    /* If the B field is 1, then the barcount is an immediate */
    if (type & 0x1) {
        return RZ;
    }
    else {
        return (uint32_t)GET(31:26, *inst);
    }
}

static uint32_t
barGetCountImm(const uint64_t *inst)
{
    uint32_t type = 0;

    if (!is_synchronizing_barrier(inst)) {
        CU_ERROR_PRINT(("Not a sync bar inst\n"));
        return 0;
    }

    type = GET(FERMI64_ABC, *inst);
    /* If the B field is 1, then the barcount is an immediate */
    if (type & 0x1) {
        return GET(37:26, *inst);
    }
    else {
        return 0;
    }
}

static bool
fermi_isValidCodeAddr(uint64_t addr)
{
    return true;
}

static uint32_t
get_instSourceType(const uint64_t *inst)
{
    if (is_synchronizing_barrier(inst)) {
        uint32_t abc = GET(FERMI64_ABC, *inst);
        uint32_t sourceType = 0;

        /* If the A field is 1, then the barname is an immediate */
        if (abc & 0x2)
            sourceType |= MC_INST_SOURCE_TYPE_IMMEDIATE;
        else
            sourceType |= MC_INST_SOURCE_TYPE_REGISTER;

        /* If the B field is 1, then the barcount is an immediate */
        if (abc & 0x1)
            sourceType |= MC_INST_SOURCE_TYPE_IMMEDIATE;
        else
            sourceType |= MC_INST_SOURCE_TYPE_REGISTER;

        return sourceType;
    }

    return MC_INST_SOURCE_TYPE_UNKNOWN;
}

void
memcheckInitHal_fermi(MChal *hal, MCtoolModeArchs arch)
{
    memcheckInitHal_common(hal, arch);

    hal->maxJumpOffset      = 1ULL << 32;   //32 bits
    hal->savedSPAddr        = CU_FERMI_THREAD_STATE_OFFSET(savedUserStackPointer);
    hal->cnpReservedLmemStart = 0U; // No CNP reservation on Fermi
    hal->cnpReservedLmemSize  = 0U; // No CNP reservation on Fermi

    hal->gridParamsConstBank  = CU_FERMI_ENV_CONST_SEGMENT;
    hal->gridParamsUserStackTopOffset  = CU_FERMI_DCI_OFFSET(stackPointer);

    hal->getRz             = get_rz;

    hal->isNop             = is_nop;
    hal->isGtasLd          = is_gtas_ld;
    hal->isGtasSt          = is_gtas_st;
    hal->isLds             = is_sld;
    hal->isSts             = is_sst;
    hal->isLdl             = is_lld;
    hal->isStl             = is_lst;
    hal->isRed             = is_red;
    hal->isAtom            = is_atom;
    hal->isAbsoluteCall    = is_jcal;
    hal->isRelativeCall    = is_cal;
    hal->isSynchronizingBarrier = is_synchronizing_barrier;
    hal->isExit            = is_exit;
    hal->isRet             = is_ret;
    hal->isJmx             = is_jmx;
    hal->isLdg             = is_gld;
    hal->isStg             = is_gst;

    hal->hasPlg            = has_plg;

    hal->genAbsoluteCall   = gen_jcal;
    hal->genRet            = gen_ret;
    hal->genJmp            = gen_jmp;
    hal->genLongJmpWithPredCC  = gen_longjmpPredCC;
    hal->genMov            = gen_mov;
    hal->genMovFromImm     = gen_movFromImm;
    hal->genRetWithPredCC  = gen_retPredCC;

    hal->getRa             = get_ra;
    hal->getRb             = get_rb;
    hal->getPredRawInv     = get_predRawInv;
    hal->getPredMask       = get_predMask;
    hal->getPredWithInv    = get_predWithInv;

    hal->getExtended        = getExtended;
    hal->getOffset          = getOffset;
    hal->getMemAccessSize   = getMemAccessSize;
    hal->isWrite            = is_write;

    hal->barHasThreadCount  = barHasThreadCount;
    hal->barGetNameReg      = barGetNameReg;
    hal->barGetNameImm      = barGetNameImm;
    hal->barGetCountReg     = barGetCountReg;
    hal->barGetCountImm     = barGetCountImm;

    hal->genLmemHiSpill     = genLmemHiSpill;
    hal->genLmemHiRead      = gen_lmemHiRead;
    hal->genBreakInstruction = fermi_getBreakInstruction;
    hal->genTexDrainInstruction = fermi_getTexDrainInstruction;
    hal->isDirectCall        = fermi_isDirectCall;
    hal->isIndirectCall      = is_jmx;
    hal->isValidCodeAddr     = fermi_isValidCodeAddr;
    hal->getInstSourceType   = get_instSourceType;
}
