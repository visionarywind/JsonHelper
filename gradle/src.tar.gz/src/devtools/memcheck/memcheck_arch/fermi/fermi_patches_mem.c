/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: fermi_patches_mem.c
 *
 *   Description:
 *       Common code for fermi memcheck patches
 *
 ******************************************************************************/

#include "memcheck_types.h"
#include "memcheck_error.h"
#include "memcheck_arch/inc/fermi/fermi_patches_mem.h"
#include "memcheck_arch/inc/fermi/fermi_patches_common.h"
#include "memcheck_arch/inc/fermi/fermi_patches.h"
#include "halo.h"
#include "fermi_opcodes.h"
#include "check_mc_context.h"

static CUresult
fermi_checkType_initialize(MCcheckType *checkType)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();
    if (!checkType) {
        CU_ERROR_PRINT(("Failed to initialize\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Setup the state
    checkType->state.enableAbi  = 0;
    checkType->state.minLmem    = 0;
    checkType->state.minRegs    = 8;
    checkType->state.prologueSize = 0;

    return res;
}

static uint32_t
fermi_getPatchSize(MCcheckType *checkType, MCrec *rec)
{
    uint64_t *funcBegin = NULL;
    uint64_t *funcEnd = NULL;
    uint64_t *cp = NULL;
    uint32_t size = 0;
    CCIRinstOpcodes instType = CCIR_INST_OPCODE_NONE;

    CU_TRACE_FUNCTION();

    if (!checkType || !rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return 0;
    }

    CU_ASSERT(rec->funcBuffer.size);
    CU_ASSERT(rec->funcBuffer.host.ptr);

    funcBegin = (uint64_t *)rec->funcBuffer.host.ptr;
    funcEnd = funcBegin + rec->funcBuffer.size / sizeof(uint64_t);

    /* Fixed portion */
    size = sizeof memcheckPatchCheck;
    size += checkType->tm.mem.getAlignCheckSize(checkType, rec);

    /* Pr load/store portion */
    for (cp = funcBegin; cp < funcEnd; ++cp) {
        instType = checkType->isInstructionTarget(checkType, cp);
        if (instType != CCIR_INST_OPCODE_NONE) {
            if (checkType->state.enableAbi)
                size += sizeof memcheckPatchStubWithAbi;
            else
                size += sizeof memcheckPatchStubWithoutAbi;

            if (rec->options.forceTexDrain)
                size += 8;

            size += checkType->tm.mem.getStubJcalSize(checkType, rec, instType);
        }
    }

    /* Add the size of allocation checking */
    size += checkType->tm.mem.getRangeCheckSize (checkType, rec);
    size += checkType->tm.mem.getFinalizeCheckSize(checkType, rec);

    return size;
}

CUresult
fermi_parseErrorEntry(MCcheckType *checkType, MCrec *rec,
                      CUmemcheck_record *outrec,
                      uint32_t *hasError)
{
    fermiMCerror_entry *deverr = NULL;
    uint32_t *p = NULL;
    bool valid = 0;
    uint32_t i = 0;
    uint64_t pc = 0;
    CUmemcheck_error_record *err = NULL;
    MCfunc *mcfunc = NULL;

    CU_TRACE_FUNCTION();

    if (!checkType || !rec || !outrec || !hasError) {
        CU_ERROR_PRINT(("Invalid Args\n"));
        return CUDA_ERROR_UNKNOWN;
    }
    err = &outrec->cases.error;

    deverr = (fermiMCerror_entry *)rec->errorEntry.dev.hPtr;
    p = (uint32_t *)deverr;
    valid = ((deverr->valid & FERMI_MEMCHECK_WHITEMAGIC_MASK) == FERMI_MEMCHECK_WHITEMAGIC);

    CU_DEBUG_PRINT(("err @ dptr %" PRIx64 "/%p: %08x %08x %08x %08x %08x %08x %08x %08x\n",
                    rec->errorEntry.dev.dPtr, rec->errorEntry.dev.hPtr,
                    p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7]));

    if (valid) {
        err->errortype = CU_MEMCHECK_RECORD_MEM_PRECISE;

        pc = (uint64_t)deverr->pc;
        mcfunc = mcContextGetFuncByAddr(rec->context, pc);
        if (mcfunc)
            err->cases.memPrecise.pc     = (uint32_t)(uintptr_t)(pc - mcfunc->mem.dev.dPtr);
        else {
            CU_DEBUG_PRINT(("Failed to find function for pc 0x%" PRIx64 "\n", pc));
            err->cases.memPrecise.pc     = (uint32_t)pc;
        }

        err->cases.memPrecise.type       = valid & FERMI_MEMCHECK_ADDR_MASK;
        err->cases.memPrecise.address    = deverr->addr;
        err->cases.memPrecise.blockIdxX  = deverr->blockIdx_x & 0xFFFF;
        err->cases.memPrecise.blockIdxY  = deverr->blockIdx_y & 0xFFFF;
        err->cases.memPrecise.blockIdxZ  = deverr->blockIdx_z & 0xFFFF;
        err->cases.memPrecise.threadIdxX = deverr->threadIdx_xyz & 0xFFFF;
        err->cases.memPrecise.threadIdxY = (deverr->threadIdx_xyz >> 16) & 0x3FF;
        err->cases.memPrecise.threadIdxZ = deverr->threadIdx_xyz >> 26;

        for (i = 0; i < 8; ++i)
            p[i] = 0xDEADBEEF;
        *hasError = valid;
    }
    return CUDA_SUCCESS;
}

static uint32_t
fermi_getAlignCheckSize(MCcheckType *checkType, MCrec *rec)
{
    return sizeof memcheckPatchCheckAlign;
}

static uint64_t*
fermi_genAlignCheck(MCcheckType *checkType, MCrec *rec, uint64_t *patchCode, uint64_t *patchStart)
{
    *patchCode++ = AND_CC(R2, R2, R0);
    *patchCode = PRED(P0,CC(CC_NE,BRA((char *) patchStart
                                      + PATCH_FAIL_ENTRY*8
                                      - ((char *) patchCode + 8))));
    ++patchCode;
    return patchCode;
}

static uint32_t
fermi_getFinalizeCheckSize(MCcheckType *checkType, MCrec *rec)
{
    return sizeof memcheckRangeCheckEnd;
}

static uint64_t *
fermi_genFinalizeRangeCheck(MCcheckType *checkType, MCrec *rec, uint64_t *patchCode, uint64_t *patchStart)
{
    /* If we reach the end, we deem it an illegal access.

       VERY IMPORTANT: in general, memcheck must not use predicated
       branches as it can create control flow divergence and lead to
       changing program semantics (this was bug 687852). However, here
       we are ready to abandon the execution anyway, so it doesn't
       really matter. This is yet another reasons why the --error flag
       doesn't really work in practice and should only be used
       internally. */
    *patchCode = PRED(P0,BRA((char *) patchStart
                             + PATCH_FAIL_ENTRY*8
                             - ((char *) patchCode + 8)));
    ++patchCode;

    /* Branch back to the restore portion of the stub. When ABI support is
       enabled, we need to restore R0..R15. This means the jump must be
       to the top of the check stub. If not, we jump to two instructions
       after the top, and restore only R0..R7 */
    if (checkType->state.enableAbi)
        *patchCode = BRA(/*Ok*/ (char *) patchStart - ((char *) patchCode + 8));
    else
        *patchCode = BRA(/*Ok*/ (char *) patchStart - ((char *) patchCode + 8) + (PATCH_OK_ENTRY_LO * 8));

    ++patchCode;

    return patchCode;
}

static uint64_t*
genStub(MCcheckType *checkType, MCrec *rec, uint64_t *patchCode,
        uint64_t *inst, uint32_t instAddr, CCIRinstOpcodes type,
        uint32_t checkTarget)
{
    //These are specific for every load store
    bool a64       = rec->context->hal.getExtended(inst);
    int32_t offset = rec->context->hal.getOffset(inst);
    //This are generic for all LD/ST instructions
    uint32_t pred  = GET(FERMI_PRED, *inst);
    uint32_t ra    = GET(FERMI_REGA, *inst);
    uint32_t ra_lo = ra;
    uint32_t ra_hi = a64 ? ra_lo + 1 : RZ;
    uint32_t asize = rec->context->hal.getMemAccessSize(inst, rec->func, instAddr);

    /* Stub:

       Note, this can be improved, but for the first version I don't
       want too many special cases so it's overly expensive.

       STL        [LMEM_HI_SCRATCH], R0
       STL        [LMEM_HI_SCRATCH+4], R1
       STL        [LMEM_HI_SCRATCH+8], R2
       STL        [LMEM_HI_SCRATCH+12], R3
       STL        [LMEM_HI_SCRATCH+16], R4
       STL        [LMEM_HI_SCRATCH+20], R5
       STL        [LMEM_HI_SCRATCH+24], R6
       STL        [LMEM_HI_SCRATCH+28], R7

       MOV        R0, <<< ld/st addr register lo >>>
       MOV        R1, <<< ld/st addr register hi (or RZ for 32-bit addresses) >>>

       P2R        R7

       IADD32I    R0.CC, R0, <<< ld/st offset >>>
       IADD32I.X  R1, R1, RZ
       MOV32I     R2, <<< alignment mask >>>
       MOV32I     R3, <<< address of ld/st >>>
       JCAL       check
       <<< orig ld/st instruction >>>
       JMP        <<< address of ld/st + 8 >>>

       The original instruction doesn't need to strip the
       predicates as they must have been satisfied to get
       here for non ABI. For ABI, the predicates are
       restored by this point.)

       Note, check takes care of restoring R0-R15 before returning. */

    CU_DEBUG_PRINT(("stub at %08" PRIx64 " for instruction %08x:%016" PRIx64 " (size %d)\n",
                    (char*)patchCode - (char*)rec->patchBuffer.host.ptr + rec->patchOffset,
                    instAddr,
                    *inst, asize));

    if (rec->options.forceTexDrain) {
        uint64_t texDrain = 0;
        rec->context->hal.genTexDrainInstruction(rec, &texDrain);
        *patchCode++ = texDrain;
    }
    *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH, R0);
    *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+4, R1);
    *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+8, R2);
    *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+12, R3);
    *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+16, R4);
    *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+20, R5);
    *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+24, R6);
    *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+28, R7);

    //For ABI function call support, spill more registers
    if (checkType->state.enableAbi) {
        *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+32, R8);
        *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+36, R9);
        *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+40, R10);
        *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+44, R11);
        *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+48, R12);
        *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+52, R13);
        *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+56, R14);
        *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+60, R15);
    }

    if (ra_lo != R0)
        *patchCode++ = MOV(R0, ra_lo);

    if (ra_hi != R1)
        *patchCode++ = MOV(R1, ra_hi);

    *patchCode++ = P2R(R7);

    if (offset) {
        *patchCode++ = IADD32I_CC(R0, R0, offset);
        if (a64)
            // 32-bit mode wraps around, so only apply this for extended addr
            *patchCode++ = IADD32I_X(R1, R1, (int64_t) offset >> 32);
    }

    *patchCode++ = MOV32I(R2, asize - 1); // memaddr_mask
    *patchCode++ = MOV32I(R3, instAddr);

    if (pred != P0)
        *patchCode++ = ISETP_U32_FULL(CC_EQ, P0, PT, RZ, RZ, pred); // Copy the predicate

    /* For interop always write the data to LMEM_HI*/
    *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH +
                       FERMI_LMEM_MEMCHECK_ADDR, R0);
    if (a64)
        *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH +
                           FERMI_LMEM_MEMCHECK_ADDR_HI, R1);
    else
        *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH +
                           FERMI_LMEM_MEMCHECK_ADDR_HI, RZ);

    //For now, only write the low bits of the PC.
    *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+
                       FERMI_LMEM_MEMCHECK_PC, R3);
    *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+76, RZ);

    *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+80, R2);
    *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+84, R7);

    *patchCode++ = MOV32I(R5, getAddressSpace(type));
    *patchCode++ = STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+92, R5);

    patchCode = checkType->tm.mem.genStubJcal(checkType, rec, type, patchCode, checkTarget, instAddr);

    return patchCode;
}

static CUresult
patchInstructions(MCcheckType *checkType, MCrec *rec)
{
    uint8_t  *funcCode         = (uint8_t *) rec->funcBuffer.host.ptr;
    uint64_t *patchBase        = (uint64_t *) rec->patchBuffer.host.ptr;
    uint64_t *patchTypeBase    = patchBase + rec->patchOffsets[checkType->state.type] / sizeof (uint64_t);
    uint64_t *patchCode        = patchTypeBase;
    uint64_t *patchCodeLimit   = patchBase + rec->patchOffsets[checkType->state.type + 1] / sizeof (uint64_t);
    uint32_t  patchCheckOffset = (uint32_t) (rec->patchOffset + rec->patchOffsets[checkType->state.type]);
    uint64_t  errorBufAddr     = rec->errorEntry.dev.dPtr;
    uint8_t  *cp;
    size_t    patchActualSize;
    uint64_t *patchCheckStart;
    char name[999];
    static uint32_t number = 99;
    CCIRinstOpcodes type = CCIR_INST_OPCODE_NONE;

    (void) patchCodeLimit; //quell compiler in release mode
    rec->patchEntry = 0;

    patchCheckStart = patchCode;
    /* Check Function */
    memcpy(patchCode, memcheckPatchCheck, sizeof memcheckPatchCheck);

    SETFLDV(patchCode[PATCH_FAIL_ERROR_LOC],   FERMI64_IMM32, errorBufAddr);
    SETFLDV(patchCode[PATCH_FAIL_ERROR_LOC+1], FERMI64_IMM32, errorBufAddr >> 32);

    if (rec->options.debuggerAttached   ||
        rec->options.forceError         ||
        rec->options.nonblockingLaunch)
        rec->context->hal.genBreakInstruction(rec, &(patchCode[PATCH_FAIL_BREAK]));

    if (checkType->state.enableAbi) {
        patchCode[PATCH_OK_BRA] = BRA(-8 * (PATCH_OK_BRA + 1));
    }
    patchCode += sizeof memcheckPatchCheck / 8;

    patchCode = checkType->tm.mem.genAlignCheck(checkType, rec, patchCode, patchTypeBase);
    patchCode = checkType->tm.mem.genRangeCheck(checkType, rec, patchCode);
    patchCode = checkType->tm.mem.genFinalizeCheck(checkType, rec, patchCode,
                                                   patchTypeBase);
    CU_ASSERT(patchCode <= patchCodeLimit);

    /* Report the memcheck patch */
    CCdbgInteropAddStandalonePatch(rec,
                                   (char*)patchCheckStart - (char*)(char*)patchBase + rec->patchBuffer.dev.devVaddr,
                                   (char*)patchCheckStart - (char*)(char*)patchBase + rec->patchBuffer.dev.dPtr,
                                   (uint32_t) (patchCode - patchCheckStart)*8);

    /* Stub -- function-specific setup -- one per global load/store */
    for (cp = funcCode; cp < funcCode + rec->funcBuffer.size; cp += 8) {
        uint64_t inst = *(uint64_t *)cp;

        type = checkType->isInstructionTarget(checkType, &inst);
        if (type) {
            uint64_t stubEntry = (char*)patchCode
                                 - (char*)rec->patchBuffer.host.ptr
                                 + rec->patchOffset;
            uint64_t stubEntryDevVaddr = (char*)patchCode
                                         - (char*)rec->patchBuffer.host.ptr
                                         + rec->patchBuffer.dev.devVaddr;
            uint32_t patchSize = 0;
            uint32_t patchCheckEntry = patchCheckOffset + PATCH_CHECK_ENTRY * 8;

            /* We must be 64-bit aligned */
            CU_ASSERT(((uintptr_t)cp & 7) == 0);

            /* Unconditional JMP to stub */
            *(uint64_t *)cp = JMP_ABS(stubEntry);

            patchCode = genStub(checkType, rec, patchCode, &inst, (uint32_t) (cp - funcCode + rec->func->mem.dev.dPtr), type, patchCheckEntry);
            *patchCode++ = inst;
            *patchCode++ = JMP_ABS(cp - funcCode + 8 + rec->func->mem.dev.dPtr);

            patchSize = (uint32_t)((char*)patchCode - (char*)rec->patchBuffer.host.ptr + rec->patchOffset - stubEntry);
            CU_ASSERT(patchCode <= patchCodeLimit);

            /* Report patch */
            CCdbgInteropAddTrampolinePatch(rec,
                                           stubEntryDevVaddr,
                                           stubEntry,
                                           patchSize,
                                           (cp - funcCode + rec->func->mem.dev.dPtr),
                                           inst);
        }
    }

    // Don't delete the following line until I have had a change to look at improvements.
    //printf("Allocated %"PRIdPTR" bytes more than needed\n", 8*(patchCodeLimit - patchCode));

    patchActualSize = (char *) patchCode - (char *) patchCheckStart;

    if (rec->options.printCubins) {
        snprintf(name, sizeof name, "patch-%d.cubin", ++number);
        checkType->printCubin(checkType, name, patchCheckStart, (uint32_t) patchActualSize);
    }

    /* If the debugger is enabled, the patch will hit a breakpoint on
       detected errors.  The debugger thus needs to know about these
       code patches so it can translate the breakpoint address to the
       address of the patched instruction and maintain the illusion of
       running the originally unpatched program. */

    return CUDA_SUCCESS;
}

static CUresult
fermi_createPatch(MCcheckType *checkType, MCrec *rec)
{
    CU_TRACE_FUNCTION();
    if (!checkType || !rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    return patchInstructions(checkType, rec);
}

uint64_t*
fermi_mem_genStubJcal(MCcheckType *checkType, MCrec *rec,
                      CCIRinstOpcodes instType,
                      uint64_t *patchCode,
                      uint32_t checkTarget,
                      uint32_t instrAddr)
{
    *patchCode++ = JCAL(checkTarget);
    return patchCode;
}

static uint32_t
fermi_getStubJcalSize(MCcheckType *checkType, MCrec *rec,
                      CCIRinstOpcodes instType)
{
    return 8;
}

CUresult
fermi_mem_bootstrap(MCinstManager *instMgr, MCcheckType *type)
{

    CU_TRACE_FUNCTION();
    if (!instMgr || !type) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    type->initialize      = fermi_checkType_initialize;
    type->getPatchSize    = fermi_getPatchSize;
    type->createPatch     = fermi_createPatch;
    type->parseErrorEntry = fermi_parseErrorEntry;
    type->tm.mem.genStubJcal = fermi_mem_genStubJcal;
    type->tm.mem.getStubJcalSize = fermi_getStubJcalSize;
    type->tm.mem.genAlignCheck = fermi_genAlignCheck;
    type->tm.mem.genFinalizeCheck = fermi_genFinalizeRangeCheck;
    type->tm.mem.getAlignCheckSize = fermi_getAlignCheckSize;
    type->tm.mem.getFinalizeCheckSize = fermi_getFinalizeCheckSize;


    return CUDA_SUCCESS;
}

