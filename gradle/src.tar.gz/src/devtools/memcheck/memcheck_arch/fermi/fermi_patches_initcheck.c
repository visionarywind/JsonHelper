/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: fermi_patches_initcheck.c
 *
 *   Description:
 *       Race patches for fermi (and beyond)
 *
 ******************************************************************************/

#include "memcheck_types.h"
#include "memcheck_error.h"
#include "memcheck_arch/inc/fermi/fermi_patches.h"
#include "halo.h"
#include "initcheck/initcheck.h"
#include "bikernels.h"
#include "check_mc_func.h"

typedef struct {
    uint64_t pc;
    uint64_t returnTarget;
    uint64_t *inst;
    MCfunc   *stubFunc;
} stubInfo;

static CUresult
genGlobalLDSTStub(MCcheckType *checkType, MCrec *rec, stubInfo *info)
{
    CUresult res = CUDA_SUCCESS;

    res = initcheckLoadGlobalLDSTStub(rec, info->inst, info->returnTarget, info->pc, &info->stubFunc);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load global ldst stub\n"));
        return res;
    }

    return CUDA_SUCCESS;
}
static CUresult
patchInstructions(MCcheckType *checkType, MCrec *rec, CUfunction func)
{
    uint8_t  *funcCode         = (uint8_t *) rec->funcBuffer.host.ptr;
    uint8_t  *cp;
    uint32_t instSize = rec->context->hal.getInstSize();
    stubInfo pstate = {0};
    CCIRinstOpcodes op;
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    /* Stub -- function-specific setup -- one per global load/store */
    for (cp = funcCode; cp < funcCode + rec->funcBuffer.size; cp += instSize) {
        CCmemHandle *patchMem = NULL;
        uint64_t *inst = (uint64_t *)cp;
        uint64_t pc = (uint64_t)(uintptr_t)(cp - funcCode + rec->func->mem.dev.dPtr);
        uint64_t inst_offset = (uint64_t)(uintptr_t)(cp - funcCode);

        /* We must be 64-bit aligned */
        CU_ASSERT(((uintptr_t)cp & 7) == 0);

        /* Skip OPEXT/SHINT */
        if (!rec->context->hal.isValidCodeAddr(pc)) {
            CU_TRACE_PRINT(("PC(%p) is not a valid code address.  Skipping patch\n", (void *)(uintptr_t)pc));
            continue;
        }

        /* Unsupported legacy emulated atomic F16 sequence instruction, skip it */
        if (mcFuncIsInstructionLegacyEmulF16(rec->func, pc)) {
            CU_TRACE_PRINT(("Skipping legacy emul f16 instruction at pc %p\n", (void *)(uintptr_t)pc));
            continue;
        }

        op = checkType->isInstructionTarget(checkType, inst);
        if (op == CCIR_INST_OPCODE_GENERIC_LD ||
            op == CCIR_INST_OPCODE_GLOBAL_LD ||
            op == CCIR_INST_OPCODE_GENERIC_ST ||
            op == CCIR_INST_OPCODE_GLOBAL_ST ||
            op == CCIR_INST_OPCODE_ATOM ||
            op == CCIR_INST_OPCODE_ATOM_GLOBAL ||
            op == CCIR_INST_OPCODE_RED) {
            memset(&pstate, 0, sizeof(pstate));
            pstate.inst = inst;
            pstate.pc = pc;
            pstate.returnTarget = pc + instSize;

            res = genGlobalLDSTStub(checkType, rec, &pstate);
            if (res != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Failed to load global ldst stub\n"));
                continue;
            }

            patchMem = &pstate.stubFunc->mem;

            /* Unconditional JMP to stub */
            res = rec->context->hal.patchJumpPoint(rec->context, &rec->funcBuffer, inst_offset, patchMem->dev.dPtr);
            if (res != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Failed to patch jump point\n"));
                return res;
            }

            /* The debugger needs to know about these
               code patches for internal debugging */
            res = CCdbgInteropAddTrampolinePatchCommon(rec,
                                                       patchMem->dev.devVaddr,
                                                       patchMem->dev.dPtr,
                                                       patchMem->size,
                                                       pc,
                                                       inst,
                                                       instSize / sizeof(*inst));
            if (res != CUDA_SUCCESS) {
                // log, but continue with other instructions
                CU_ERROR_PRINT(("Failed to report patch for instruction at offset 0x%" PRIx64 " to the debugger\n", inst_offset));
                res = CUDA_SUCCESS;
            }
        }
    }

    // Don't delete the following line until I have had a change to look at improvements.
    //printf("Allocated %"PRIdPTR" bytes more than needed\n", 8*(patchCodeLimit - patchCode));

    return CUDA_SUCCESS;
}

static CUresult
fermi_initcheck_initialize(MCcheckType *checkType)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();
    if (!checkType) {
        CU_ERROR_PRINT(("Failed to initialize\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Setup the state
    checkType->state.enableAbi  = 1;
    checkType->state.minLmem    = 0;
    checkType->state.minRegs    = 16;
    checkType->state.prologueSize = 0;
    checkType->state.minBarriers = 0;
    checkType->state.minSharedMem = 0;

    return res;
}

static CUresult
fermi_initcheck_updateState(MCcheckType *checkType, uint32_t enableAbi)
{
    CU_TRACE_FUNCTION();

    if (!checkType) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Does nothing

    return CUDA_SUCCESS;
}

static uint32_t
fermi_initcheck_getPatchSize(MCcheckType *checkType, MCrec *rec)
{
    uint32_t size = 0;

    CU_TRACE_FUNCTION();

    if (!checkType || !rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return 0;
    }

    CU_ASSERT(rec->funcBuffer.size);
    CU_ASSERT(rec->funcBuffer.host.ptr);

    size = 0;

    return size;
}

static CUresult
fermi_initcheck_createPatch(MCcheckType *checkType, MCrec *rec)
{
    CU_TRACE_FUNCTION();
    if (!checkType || !rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }
    return patchInstructions(checkType, rec, rec->func->cufunc);
}

static CUresult
fermi_parseErrorEntry(MCcheckType *checkType, MCrec *rec,
                      CUmemcheck_record *err,
                      uint32_t *hasError)
{
    CU_TRACE_FUNCTION();

    if (!checkType || !rec || !err || !hasError) {
        CU_ERROR_PRINT(("Invalid Args\n"));
        return CUDA_ERROR_UNKNOWN;
    }
    // Do nothing

    return CUDA_SUCCESS;
}

CUresult
fermi_initcheck_checkType_bootstrap(MCinstManager *instMgr, MCcheckType *type)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!instMgr || !type) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Override for fermi_global variants. These are in fermi_global.[hc]
    type->initialize        =   fermi_initcheck_initialize;
    type->getPatchSize      =   fermi_initcheck_getPatchSize;
    type->createPatch       =   fermi_initcheck_createPatch;
    type->updateState       =   fermi_initcheck_updateState;
    type->parseErrorEntry   =   fermi_parseErrorEntry;

    return res;
}
