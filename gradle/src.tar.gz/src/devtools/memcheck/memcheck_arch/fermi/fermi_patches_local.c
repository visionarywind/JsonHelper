/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: fermi_patches_local.c
 *
 *   Description:
 *       Global load/store patches for fermi
 *
 ******************************************************************************/

#include "memcheck_types.h"
#include "memcheck_error.h"
#include "memcheck_arch/inc/fermi/fermi_patches_local.h"
#include "memcheck_arch/inc/fermi/fermi_patches_common.h"
#include "memcheck_arch/inc/fermi/fermi_patches.h"
#include "halo.h"
#include "fermi_opcodes.h"

/*
   Strategy: since we don't try to insert instructions into the
   middle, we follow the cuda-memcheck/Tesla stategy of replacing all
   checked instructions with a branch to the stub, which then invokes
   the checker.

   It's critical to not introduce divergence that wasn't in the
   original code (this was bug 687852), so we copy the patched
   instruction's predicate into P0 and predicate everything by
   that. The only divergence we will allow is when errors are found at
   which point we are about to crash anyway, so who cares :)

   what was:

        00e8    mov r3, r3
        00f0    (pred) ld.e r1, [r2]
        00f8    imul.hi r2, r1, 0x4

   becomes:

        00e8    mov r3, r3;
        00f0    jmp stub_00f0
        resumepoint:
        00f8    imul.hi r2, r1, 0x4


        stub_00f0:
                ..... save off registers and predicates
                set up parameters to check
                P0 = (pred)
                call check

                (pred) ld.e r1, [r2]
                jmp resumepoint

 */

/*
    Stack layout on Fermi
    Shamelessly stolen from cuda_a/drivers/gpgpu/cuda/src/cui/hal/fermi/fermi_common.c
    ---------------------

    Starting stack pointer is the upper address of local mem minus
    the space occupied by the debugger and system stack.

    Although the starting stack pointer only begins in the user
    stack, kernel calls will transition smoothly to the system
    stack via trampoline functions set up by the driver during
    syscall initialization. These trampolines save off the
    current stack pointer (R1) using the top of the system stack.
    Next, the stack pointer is replaced with the base system
    stack pointer and a call is made the actual syscall function.
    On return from the actual syscall, the trampoline function
    restores the original user stack pointer and finally returns
    control back to the calling user device function.

                                            16MB (upper local address)
               _  __________________________  _
              /  |                          |  \
             /   |  Debugger Usage          |   > Debugger space (512B)
            /    |__________________________| _/
           /     |                          |  \
          /      |  System Stack            |   > System stack space (512B)
  LmemHi /       |__________________________| _/
          \      |                          |  \
           \     |                | start   |   \
            \    |  User Stack    |         |    > ABI User Stack space (default 1KB)
             \   |                V grows   |   /
              \_ |__________________________| _/
                 |                          |
                 |  ILLEGAL (empty VA)      |
               _ |__________________________|
              /  |                          |
      LmemLo <   |  Local memory (non-ABI)  |
              \_ |__________________________|

                 0 (lowest local address)

 */

static uint64_t*
fermi_local_genRangeCheck(MCcheckType *checkType, MCrec *rec, uint64_t *patchCode)
{
    uint32_t hasAbi = 0;
    MChal *hal = &rec->context->hal;
    /* Check if access falls into LMEM LO */
    if (rec->config.lmemLoSize) {
        *patchCode++ = PRED(P0,IADD32I_CC(R4, R0, -(int64_t)rec->config.lmemLoSize));
        *patchCode++ = PRED(P0,ISETP_U32_X_AND(CC_GT, P0, RZ, RZ));
    }

    hasAbi = rec->func->mod->abiVersion >= ELFOSABIV_ABI;

    /* This check will only kick in if LmemHi will be used
        The check is as follows:
        LMEM_HI_USER_MAX > addr > LMEM_HI_MIN
        Where LMEM_HI_USER_MAX is given as the start of the user
        stack. (i.e. 16MB - 512 (debugger) - SystemStackSize)
        LMEM_HI_MIN is MAX(SR_LMemHiOff, func->stackSize, r1)
        The func->stackSize check is generated only
        if there is a stack size.
        The r1 check is only generated if recursion is possible
    */
    if (hasAbi || rec->config.funcDataStackSize) {
        *patchCode++ = PRED(P0,LDC_32(R4, hal->gridParamsConstBank, hal->gridParamsUserStackTopOffset));
        *patchCode++ = PRED(P0,S2R(R5, 55));
        if (hasAbi) {
            *patchCode++ = PRED(P0,LDL(R6, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+4));
            *patchCode++ = PRED(P0,MOV(R7, RZ));
            *patchCode++ = PRED(P0,ISET_U32(CC_GT, R7, R5, R6));
            *patchCode++ = PRED(P0,ICMP_U32(CC_NE, R5, R5, R6, R7));
        }
        if (rec->config.funcDataStackSize) {
            *patchCode++ = PRED(P0,IADD32I(R6, R4, -((int32_t)rec->func->cufunc->stackSize)));
            *patchCode++ = PRED(P0,MOV(R7, RZ));
            *patchCode++ = PRED(P0,ISET_U32(CC_GT, R7, R5, R6));
            *patchCode++ = PRED(P0,ICMP_U32(CC_NE, R5, R5, R6, R7));
        }
        *patchCode++ = PRED(P0,ISET_U32(CC_GT, R4, R4, R0));
        *patchCode++ = PRED(P0,ISET_U32(CC_GE, R5, R0, R5));
        *patchCode++ = PRED(P0,LOP32(FERMI_LOP_AND, R4, R4, R5));
        *patchCode++ = PRED(P0,ISETP_U32_AND(CC_EQ, P0, RZ, R4));
    }

    return patchCode;
}

static uint32_t
fermi_local_getRangeCheckSize (MCcheckType *checkType, MCrec *rec)
{
    uint32_t size = 0;

    /* Add space for the virtual mapping */
    size += sizeof lmemLoCheck;
    size += sizeof lmemHiDynamicCheck;

    return size;
}

CUresult
fermi_local_checkType_bootstrap(MCinstManager *instMgr, MCcheckType *type)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!instMgr || !type) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Override for fermi_global variants. These are in fermi_local.[hc]
    type->tm.mem.genRangeCheck     =   fermi_local_genRangeCheck;
    type->tm.mem.getRangeCheckSize =   fermi_local_getRangeCheckSize;

    return res;
}
