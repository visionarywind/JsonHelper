/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: fermi_patches_barcheck.c
 *
 *   Description:
 *       Race patches for fermi (and beyond)
 *
 ******************************************************************************/

#include "memcheck_types.h"
#include "memcheck_error.h"
#include "memcheck_arch/inc/fermi/fermi_patches.h"
#include "halo.h"
#include "barcheck/barcheck.h"
#include "bikernels.h"
#include "check_mc_context.h"
#include "check_mc_func.h"

typedef struct {
    uint64_t pc;
    uint64_t returnTarget;
    uint64_t *inst;
    MCfunc  *stubFunc;
    uint8_t  useJmp;
} stubInfo;

static CUresult
testForCGInstrInfo(MCrec *rec, stubInfo *info, bool *isCGInstr)
{
    *isCGInstr = false;

    if (rec->func->hasCoopGroupOffsets) {
        CUresult res;
        MCinstrInfo *instrInfo = NULL;

        res = mcFuncGetInstrInfo(rec->func, info->pc, &instrInfo);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to get instr info for pc 0x%" PRIx64 "\n", info->pc));
            return res;
        }

        if (instrInfo && (instrInfo->flags & MC_INSTR_INFO_COOP_GROUPS)) {
            *isCGInstr = true;
        }
    }

    return CUDA_SUCCESS;
}

static CUresult
genBarStub(MCcheckType *checkType, MCrec *rec, stubInfo *info)
{
    CUresult res = CUDA_SUCCESS;
    bool isCGBar = false;

    CU_TRACE_FUNCTION();

    res = testForCGInstrInfo(rec, info, &isCGBar);
    if (res != CUDA_SUCCESS)
        return res;

    if (rec->context->hal.barHasThreadCount(info->inst)) {
        CU_ERROR_PRINT(("Barrier has thread count\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    res = barcheckLoadBarrierStub(rec, info->inst, info->pc, isCGBar, &info->stubFunc);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load bar stub\n"));
        return res;
    }

    return CUDA_SUCCESS;
}

static CUresult
genExitStub(MCcheckType *checkType, MCrec *rec, stubInfo *info)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    res = barcheckLoadExitStub(rec, info->inst, info->returnTarget, &info->stubFunc);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load exit stub\n"));
        return res;
    }

    return CUDA_SUCCESS;
}

static CUresult
genRetStub(MCcheckType *checkType, MCrec *rec, stubInfo *info)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    res = barcheckLoadRetStub(rec, info->inst, info->returnTarget, &info->stubFunc);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load ret stub\n"));
        return res;
    }

    return CUDA_SUCCESS;
}

static CUresult
genCallStub(MCcheckType *checkType, MCrec *rec, stubInfo *info)
{
    CUresult res = CUDA_SUCCESS;
    bool isCGCall = false;

    CU_TRACE_FUNCTION();

    res = testForCGInstrInfo(rec, info, &isCGCall);
    if (res != CUDA_SUCCESS)
        return res;

    res = barcheckLoadCallStub(rec, info->inst, info->returnTarget, isCGCall, &info->stubFunc);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load call stub\n"));
        return res;
    }

    return CUDA_SUCCESS;
}

static CUresult
genWarpsyncStub(MCcheckType *checkType, MCrec *rec, stubInfo *info)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    res = barcheckLoadWarpsyncStub(rec, info->inst, info->pc, &info->stubFunc);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load warpsync stub\n"));
        return res;
    }

    return CUDA_SUCCESS;
}

static CUresult
genShflStub(MCcheckType *checkType, MCrec *rec, stubInfo *info)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    res = barcheckLoadShflStub(rec, info->inst, info->pc, &info->stubFunc);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load shfl stub\n"));
        return res;
    }

    return CUDA_SUCCESS;
}

static CUresult
shouldPatchShfl(MCrec *rec, uint64_t pc, bool *shouldPatch)
{
    CUresult status = CUDA_SUCCESS;
    MCinstrInfo *info = NULL;
    bool isCoopInstr = false;
    bool isWarpWide = false;

    CU_ASSERT(rec);
    CU_ASSERT(shouldPatch);

    *shouldPatch = true;

    if (pc == rec->func->cufunc->launchPc) {
        *shouldPatch = false;
        return CUDA_SUCCESS;
    }

    status = mcFuncGetInstrInfo(rec->func, pc, &info);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to get instr info for pc 0x%" PRIx64 "\n", pc));
        return status;
    }

    isCoopInstr = (info && ((info->flags & MC_INSTR_INFO_COOP_GROUPS) != 0));
    isWarpWide  = (info && ((info->flags & MC_INSTR_INFO_WARP_WIDE) != 0));

    if (isCoopInstr || isWarpWide) {
        *shouldPatch = false;
    }

    if (getArchFromSmVer(rec->context->sm_version) < MC_TOOL_MODE_ARCH_SM70) {
        // We only need asm patches for SHFL on Volta+, but we need to check
        // SHFL instructions on all archs to detect deprecated instr usage.
        *shouldPatch = false;

        if (!isCoopInstr && rec->context->gvars->options.checkDeprecatedInstr) {
            CUmemcheck_record errRec = {0};
            CUmemcheck_error_record *errCase = NULL;

            if (!createNewErrorRecord(CU_MEMCHECK_RECORD_BAR_VIOLATION, &errRec)) {
                CU_ERROR_PRINT(("Failed to create new deprecated instr error record\n"));
                return CUDA_ERROR_UNKNOWN;
            }

            errCase = &errRec.cases.error;
            errCase->cases.barViolation.pc = (uint32_t)(uintptr_t)(pc - rec->func->mem.dev.dPtr);
            errCase->cases.barViolation.type = CU_BARCHECK_BAR_VIOLATION_DEPRECATED_INSTRUCTION;

            status = addBarRecord(rec->context, &errRec, rec->func, NULL);
        }
    }

    return status;
}

static bool
shouldPatchCall(MCrec *rec, uint64_t *inst, CCIRinstOpcodes opcode)
{
    uint32_t instSourceType;
    uint64_t targetPc;
    bool isSigned, isTrampolinePc;

    // We only need to track CALL/RET on Volta+
    if (getArchFromSmVer(rec->context->sm_version) < MC_TOOL_MODE_ARCH_SM70)
        return false;

    if (opcode == CCIR_INST_OPCODE_REL_CALL)
        return true;

    instSourceType = rec->context->hal.getInstSourceType(inst);
    if (instSourceType != MC_INST_SOURCE_TYPE_IMMEDIATE)
        return true;

    targetPc = rec->context->hal.getControlFlowImm(inst, &isSigned);

    isTrampolinePc = mcContextIsTrampolinePc(rec->context, targetPc);

    return !isTrampolinePc;
}

static CUresult
patchInstructions(MCcheckType *checkType, MCrec *rec, CUfunction func)
{
    uint8_t  *funcCode         = (uint8_t *) rec->funcBuffer.host.ptr;
    uint8_t  *cp;
    uint32_t instSize = rec->context->hal.getInstSize();
    CCIRinstOpcodes op;
    CUresult res = CUDA_SUCCESS;
    stubInfo pstate = {0};
    tHashMap *originalInstructionsMap = NULL;

    CU_TRACE_FUNCTION();

    if (rec->context->sm_version < 700) {
        originalInstructionsMap = (tHashMap *)toolsHashMapFind(rec->context->bug1806445Map,
                                                               tHashMapPtrToKey(rec->func->mod->cumod));
        if (!originalInstructionsMap) {
            CU_WARNING(("No original instructions map found. Assuming there was no instruction patched\n"));
        }
    }

    /* Prologue patch */
    res = barcheckLoadEntryExit(rec, &pstate.stubFunc);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load up the entry exit wrapper \n"));
        return res;
    }

    if (pstate.stubFunc) {
        CCmemHandle *patchMem = &pstate.stubFunc->mem;

        /* The debugger needs to know about these
           code patches for internal debugging */
        CCdbgInteropAddTrampolinePatchCommon(rec,
                                             patchMem->dev.devVaddr,
                                             patchMem->dev.dPtr,
                                             patchMem->size,
                                             rec->func->mem.dev.dPtr,
                                             (uint64_t*)funcCode,
                                             instSize / sizeof(uint64_t));
    }

    /* Stub -- function-specific setup -- one per global load/store */
    for (cp = funcCode; cp < funcCode + rec->funcBuffer.size; cp += instSize) {
        CCmemHandle *patchMem = NULL;
        uint64_t *inst = (uint64_t *)cp;
        uint64_t pc = (uint64_t)(uintptr_t)(cp - funcCode + rec->func->mem.dev.dPtr);
        uint64_t inst_offset = (uint64_t)(uintptr_t)(cp - funcCode);

        /* We must be 64-bit aligned */
        CU_ASSERT(((uintptr_t)cp & 7) == 0);

        /* Skip OPEXT/SHINT */
        if (!rec->context->hal.isValidCodeAddr(pc)) {
            CU_TRACE_PRINT(("PC(%p) is not a valid code address.  Skipping patch\n", (void *)(uintptr_t)pc));
            continue;
        }

        /* Lookup if this PC has been patched by the driver. If so, replace inst by the original instruction */
        if (originalInstructionsMap) {
            uint64_t *original_instruction = (uint64_t *)toolsHashMapFind(originalInstructionsMap, pc);
            if (original_instruction)
                inst = original_instruction;
        }

        op = checkType->isInstructionTarget(checkType, inst);
        if (op == CCIR_INST_OPCODE_SYNC_BARRIER ||
            op == CCIR_INST_OPCODE_EXIT ||
            op == CCIR_INST_OPCODE_RET ||
            op == CCIR_INST_OPCODE_WARPSYNC ||
            op == CCIR_INST_OPCODE_ABS_CALL ||
            op == CCIR_INST_OPCODE_REL_CALL ||
            op == CCIR_INST_OPCODE_SHFL) {

            memset(&pstate, 0, sizeof(pstate));
            pstate.inst = inst;
            pstate.pc = pc;
            pstate.returnTarget = pc + instSize;

            switch (op) {
            case CCIR_INST_OPCODE_SYNC_BARRIER:
                if (getArchFromSmVer(rec->context->sm_version) >= MC_TOOL_MODE_ARCH_SM70)
                    pstate.useJmp = 1;
                res = genBarStub(checkType, rec, &pstate);
                break;
            case CCIR_INST_OPCODE_EXIT:
                if (getArchFromSmVer(rec->context->sm_version) >= MC_TOOL_MODE_ARCH_SM70)
                    pstate.useJmp = 1;
                res = genExitStub(checkType, rec, &pstate);
                break;
            case CCIR_INST_OPCODE_RET:
                pstate.useJmp = 1;
                res = genRetStub(checkType, rec, &pstate);
                break;
            case CCIR_INST_OPCODE_ABS_CALL:
            case CCIR_INST_OPCODE_REL_CALL:
                {
                    bool shouldPatch = shouldPatchCall(rec, inst, op);

                    if (!shouldPatch) {
                        continue;
                    }

                    pstate.useJmp = 1;
                    res = genCallStub(checkType, rec, &pstate);
                    break;
                }
            case CCIR_INST_OPCODE_WARPSYNC:
                pstate.useJmp = 1;
                res = genWarpsyncStub(checkType, rec, &pstate);
                break;
            case CCIR_INST_OPCODE_SHFL:
                {
                    bool shouldPatch = false;
                    res = shouldPatchShfl(rec, pc, &shouldPatch);
                    if (res != CUDA_SUCCESS) {
                        return res;
                    }

                    if (!shouldPatch) {
                        continue;
                    }

                    pstate.useJmp = 1;
                    res = genShflStub(checkType, rec, &pstate);
                }
                break;
            default:
                CU_ERROR_PRINT(("opcode not handled\n"));
                return CUDA_ERROR_UNKNOWN;
            }

            if (res != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Failed to gen call stub\n"));
                return res;
            }

            patchMem = &pstate.stubFunc->mem;

            /* JCAL/JMP to stub (if any) */
            if (pstate.useJmp)
                res = rec->context->hal.patchJumpPoint(rec->context, &rec->funcBuffer, inst_offset, patchMem->dev.dPtr);
            else
                res = rec->context->hal.patchAbsoluteCallPoint(rec->context, &rec->funcBuffer, inst_offset, patchMem->dev.dPtr);

            if (res != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Failed to patch jump point\n"));
                return res;
            }

            /* The debugger needs to know about these
               code patches for internal debugging */
            res = CCdbgInteropAddTrampolinePatchCommon(rec,
                                                       patchMem->dev.devVaddr,
                                                       patchMem->dev.dPtr,
                                                       patchMem->size,
                                                       pc,
                                                       inst,
                                                       instSize / sizeof(*inst));
            if (res != CUDA_SUCCESS) {
                // log, but continue with other instructions
                CU_ERROR_PRINT(("Failed to report patch for instruction at offset 0x%" PRIx64 " to the debugger\n", inst_offset));
                res = CUDA_SUCCESS;
            }
        }
    }

    // flush errors here already, since we might have created records
    // e.g. for deprecated SHFL instructions during patching
    res = flushRecords(rec->context, &rec->context->gvars->output);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to flush output\n"));
        return res;
    }

    // Don't delete the following line until I have had a change to look at improvements.
    //printf("Allocated %"PRIdPTR" bytes more than needed\n", 8*(patchCodeLimit - patchCode));

    return CUDA_SUCCESS;
}

static CUresult
fermi_barcheck_initialize(MCcheckType *checkType)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();
    if (!checkType) {
        CU_ERROR_PRINT(("Failed to initialize\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Setup the state
    checkType->state.enableAbi  = 1;
    checkType->state.minLmem    = 0;
    checkType->state.minRegs    = 16;
    checkType->state.prologueSize = 0;
    checkType->state.minBarriers = 1;
    checkType->state.minSharedMem = 8;

    return res;
}

static CUresult
fermi_barcheck_updateState(MCcheckType *checkType, uint32_t enableAbi)
{
    CU_TRACE_FUNCTION();

    if (!checkType) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Does nothing

    return CUDA_SUCCESS;
}

static uint32_t
fermi_barcheck_getPatchSize(MCcheckType *checkType, MCrec *rec)
{
    uint32_t size = 0;

    CU_TRACE_FUNCTION();

    if (!checkType || !rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return 0;
    }

    CU_ASSERT(rec->funcBuffer.size);
    CU_ASSERT(rec->funcBuffer.host.ptr);

    size = 0;

    return size;
}

static CUresult
fermi_barcheck_createPatch(MCcheckType *checkType, MCrec *rec)
{
    CU_TRACE_FUNCTION();
    if (!checkType || !rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }
    return patchInstructions(checkType, rec, rec->func->cufunc);
}

static CUresult
fermi_parseErrorEntry(MCcheckType *checkType, MCrec *rec,
                      CUmemcheck_record *err,
                      uint32_t *hasError)
{
    CU_TRACE_FUNCTION();

    if (!checkType || !rec || !err || !hasError) {
        CU_ERROR_PRINT(("Invalid Args\n"));
        return CUDA_ERROR_UNKNOWN;
    }
    // Do nothing

    return CUDA_SUCCESS;
}

CUresult
fermi_barcheck_checkType_bootstrap(MCinstManager *instMgr, MCcheckType *type)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!instMgr || !type) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Override for fermi_global variants. These are in fermi_global.[hc]
    type->initialize        =   fermi_barcheck_initialize;
    type->getPatchSize      =   fermi_barcheck_getPatchSize;
    type->createPatch       =   fermi_barcheck_createPatch;
    type->updateState       =   fermi_barcheck_updateState;
    type->parseErrorEntry   =   fermi_parseErrorEntry;

    return res;
}
