/*
 * Copyright 2007-2016 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: volta_gv10x_patches.c
 *
 *   Description:
 *       Main code for volta gv10x patch types. This defines the volta gv10x
 *       specific type manager initialization function. This includes the overridden
 *       initialization for check types
 *
 ******************************************************************************/

#include "memcheck_arch/inc/volta_gv10x/volta_gv10x_patches.h"
#include "memcheck_arch/inc/volta_gv10x/volta_gv10x_patches_common.h"
#include "memcheck_types.h"
#include "memcheck.h"

static CUresult
volta_gv10x_instMgr_initialize(MCinstManager *instMgr)
{
    CUresult res = CUDA_SUCCESS;
    uint32_t i = 0;
    MCcheckType *type = NULL;

    CU_TRACE_FUNCTION();

    if (!instMgr) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    instMgr->state.enabledTypes = 0;
    instMgr->state.errorEntrySize = sizeof(voltaMCerror_entry);

    for (i = MC_CHECK_TYPE_NONE; i < MC_CHECK_TYPE_SIZE; ++i) {
        // Clear out the type pointer
        type = instMgr->state.checkTypes[i];

        // Ignore the empty patch type
        if (!type)
            continue;

        // Create a type check structure for each known type
        switch (i) {
        case MC_CHECK_TYPE_GLOBAL:
        case MC_CHECK_TYPE_SHARED:
        case MC_CHECK_TYPE_LOCAL:
            res = volta_gv10x_mem_checkType_bootstrap(instMgr, type);
            break;
        case MC_CHECK_TYPE_RACE:
            res = volta_gv10x_race_checkType_bootstrap(instMgr, type);
            break;
        case MC_CHECK_TYPE_BARCHECK:
            res = volta_gv10x_barcheck_checkType_bootstrap(instMgr, type);
            break;
        case MC_CHECK_TYPE_INITCHECK:
            res = volta_gv10x_initcheck_checkType_bootstrap(instMgr, type);
            break;

        default :
            type = NULL;
            CU_TRACE_PRINT(("Not initializing type %u on Volta GV10x\n", i));
            break;
        }

        // If bootstraping failed, bail out
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to initialize checktype :%i on Volta GV10x\n", i));
            return res;
        }

        if (type) {
            // Call the type initialization
            res = type->initialize(type);
            if (res != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Failed to initialize type : %u on Volta GV10x\n", i));
                return CUDA_ERROR_UNKNOWN;
            }

            instMgr->state.enabledTypes |= (1U << i);
        }
    }

    return res;
}

CUresult
volta_gv10x_initTypeManager(MCcontext *mcctx, MCinstManager *instMgr)
{
    CU_TRACE_FUNCTION();

    if (!instMgr) {
        CU_ERROR_PRINT(("Invalid argument\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Defaults are already set up. Do the volta_gv10x specific overrides here
    // Setup function pointers
    instMgr->initialize         =   volta_gv10x_instMgr_initialize;

    CU_TRACE_PRINT(("Volta GV10x type manager init done\n"));
    return CUDA_SUCCESS;
}
