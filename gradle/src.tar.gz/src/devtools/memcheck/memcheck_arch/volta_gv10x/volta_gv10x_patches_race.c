/*
 * Copyright 2016 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: volta_gv10x_patches_race.c
 *
 *   Description:
 *       Race patches for volta_gv10x (and beyond)
 *
 ******************************************************************************/

#include "memcheck_types.h"
#include "racecheck/racecheck.h"
#include "memcheck_arch/inc/pascal_gp10x/pascal_gp10x_patches.h"
#include "memcheck_arch/inc/volta_gv10x/volta_gv10x_patches.h"

static CUresult
volta_gv10x_race_initialize(MCcheckType *checkType)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();
    if (!checkType) {
        CU_ERROR_PRINT(("Failed to initialize\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Setup the state
    checkType->state.enableAbi    = 0;
    checkType->state.minLmem      = 0;
    checkType->state.minRegs      = 14;
    checkType->state.prologueSize = 0;
    checkType->state.minBarriers  = 1;

    return res;
}

CUresult
volta_gv10x_race_checkType_bootstrap(MCinstManager *instMgr, MCcheckType *type)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!instMgr || !type) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Initialize from Pascal
    res = pascal_gp10x_race_checkType_bootstrap(instMgr, type);

    // Overrides for Volta
    type->initialize = volta_gv10x_race_initialize;

    return res;
}

