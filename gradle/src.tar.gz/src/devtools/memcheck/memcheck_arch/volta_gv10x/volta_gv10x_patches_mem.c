/*
 * Copyright 2007-2016 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: volta_gv10x_patches_mem.c
 *
 *   Description:
 *       The common memcheck patch code for Volta GV10x
 *
 ******************************************************************************/

#include "memcheck.h"
#include "memcheck_types.h"
#include "memcheck_inst_types.h"
#include "memcheck_error.h"
#include "fermi_mcinterop.h"
#include "memcheck_arch/inc/volta_gv10x/volta_gv10x_patches.h"
#include "memcheck_arch/inc/volta_gv10x/volta_gv10x_patches_common.h"
#include "memcheck_arch/inc/pascal_gp10x/pascal_gp10x_patches.h"
#include "halo.h"
#include "check_mc_context.h"

// Include this for the system stack limit
#include "cui/hal/volta/volta.h"

#define VOLTA_GV10X_GLOBAL_PATCH_LOCAL_MEM 0

CUresult
volta_gv10x_parseErrorEntry(MCcheckType *checkType, MCrec *rec,
                            CUmemcheck_record *outrec,
                            uint32_t *hasError)
{
    voltaMCerror_entry *deverr = NULL;
    uint32_t *p = NULL;
    bool valid = 0;
    uint32_t i = 0;
    CUmemcheck_error_record *err = NULL;
    MCfunc *mcfunc = NULL;

    CU_TRACE_FUNCTION();

    if (!checkType || !rec || !outrec || !hasError) {
        CU_ERROR_PRINT(("Invalid Args\n"));
        return CUDA_ERROR_UNKNOWN;
    }
    err = &outrec->cases.error;

    deverr = (voltaMCerror_entry *)rec->errorEntry.dev.hPtr;
    p = (uint32_t *)deverr;
    valid = ((deverr->valid & FERMI_MEMCHECK_WHITEMAGIC_MASK) == FERMI_MEMCHECK_WHITEMAGIC);

    if (valid) {
        err->errortype = CU_MEMCHECK_RECORD_MEM_PRECISE;

        mcfunc = mcContextGetFuncByAddr(rec->context, deverr->pc);
        if (mcfunc)
            err->cases.memPrecise.pc     = (uint32_t)(uintptr_t)(deverr->pc - mcfunc->mem.dev.dPtr);
        else
            err->cases.memPrecise.pc     = (uint32_t)deverr->pc;
        err->cases.memPrecise.type       = valid & FERMI_MEMCHECK_ADDR_MASK;
        err->cases.memPrecise.address    = deverr->addr;
        err->cases.memPrecise.blockIdxX  = deverr->blockIdx_x & 0xFFFF;
        err->cases.memPrecise.blockIdxY  = deverr->blockIdx_y & 0xFFFF;
        err->cases.memPrecise.blockIdxZ  = deverr->blockIdx_z & 0xFFFF;
        err->cases.memPrecise.threadIdxX = deverr->threadIdx_xyz & 0xFFFF;
        err->cases.memPrecise.threadIdxY = (deverr->threadIdx_xyz >> 16) & 0x3FF;
        err->cases.memPrecise.threadIdxZ = deverr->threadIdx_xyz >> 26;

        for (i = 0; i < sizeof(*deverr) / sizeof(*p); ++i)
            p[i] = 0xDEADBEEF;
        *hasError = valid;
    }
    return CUDA_SUCCESS;
}

static CUresult
volta_gv10x_checkType_initialize(MCcheckType *checkType)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();
    if (!checkType) {
        CU_ERROR_PRINT(("Failed to initialize\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Setup the state
    checkType->state.enableAbi  = 0;
    checkType->state.minLmem    = VOLTA_GV10X_GLOBAL_PATCH_LOCAL_MEM;
    checkType->state.minRegs    = 24;
    checkType->state.prologueSize = 0;

    return res;
}

static CUresult
volta_gv10x_updateState(MCcheckType *checkType, uint32_t enableAbi)
{
    CU_TRACE_FUNCTION();

    if (!checkType) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (enableAbi) {
        checkType->state.minRegs = 24;
        checkType->state.enableAbi = 1;
    }
    else {
        checkType->state.minRegs = 24;
        checkType->state.enableAbi = 0;
    }

    return CUDA_SUCCESS;
}

CUresult
volta_gv10x_mem_checkType_bootstrap(MCinstManager *instMgr, MCcheckType *type)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!instMgr || !type) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* same bootstrap as Pascal */
    res = pascal_gp10x_mem_checkType_bootstrap(instMgr, type);

    /* overrides for Volta */
    type->initialize         =   volta_gv10x_checkType_initialize;
    type->updateState        =   volta_gv10x_updateState;
    type->parseErrorEntry    =   volta_gv10x_parseErrorEntry;

    return res;
}
