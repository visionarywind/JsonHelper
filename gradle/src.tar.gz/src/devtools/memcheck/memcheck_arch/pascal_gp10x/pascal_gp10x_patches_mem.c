/*
 * Copyright 2007-2016 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: pascal_gp10x_patches_mem.c
 *
 *   Description:
 *       The common memcheck patch code for Pascal GP10x
 *
 ******************************************************************************/

#include "memcheck.h"
#include "memcheck_types.h"
#include "memcheck_inst_types.h"
#include "memcheck_error.h"
#include "memcheck_arch/inc/pascal_gp10x/pascal_gp10x_patches_mem.h"
#include "memcheck_arch/inc/maxwell_gm10x/maxwell_gm10x_patches_common.h"
#include "memcheck_arch/inc/pascal_gp10x/pascal_gp10x_patches.h"
#include "halo.h"
#include "memcheck_arch/inc/fermi/fermi_patches_common.h"
#include "check_mc_func.h"

// Include this for the system stack limit
#include "cui/hal/pascal/pascal.h"

typedef struct {
    uint64_t pc;
    uint64_t returnTarget;
    uint64_t *inst;
    CCIRinstOpcodes type;
    MCfunc  *stubFunc;
    bool     mcDynEnableAbi;
} stubInfo;

static CUresult
genLDSTStub(MCcheckType *checkType, MCrec *rec, stubInfo *info)
{
    CUresult res = CUDA_SUCCESS;

    res = memcheckLoadLDSTStub(rec, info->inst, info->returnTarget, info->pc, info->type, info->mcDynEnableAbi, &info->stubFunc);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load generic ldst stub\n"));
        return res;
    }

    return CUDA_SUCCESS;
}

static CUresult
genGlobalLDSTStub(MCcheckType *checkType, MCrec *rec, stubInfo *info)
{
    CUresult res = CUDA_SUCCESS;

    res = memcheckLoadGlobalLDSTStub(rec, info->inst, info->returnTarget, info->pc, info->type, info->mcDynEnableAbi, &info->stubFunc);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load global ldst stub\n"));
        return res;
    }

    return CUDA_SUCCESS;
}

static CUresult
genSharedLDSTStub(MCcheckType *checkType, MCrec *rec, stubInfo *info)
{
    CUresult res = CUDA_SUCCESS;

    res = memcheckLoadSharedLDSTStub(rec, info->inst, info->returnTarget, info->pc, &info->stubFunc);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load shared ldst stub\n"));
        return res;
    }

    return CUDA_SUCCESS;
}

static CUresult
genLocalLDSTStub(MCcheckType *checkType, MCrec *rec, stubInfo *info)
{
    CUresult res = CUDA_SUCCESS;

    res = memcheckLoadLocalLDSTStub(rec, info->inst, info->returnTarget, info->pc, info->mcDynEnableAbi, &info->stubFunc);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load local ldst stub\n"));
        return res;
    }

    return CUDA_SUCCESS;
}

static CUresult
patchInstructions(MCcheckType *checkType, MCrec *rec)
{
    CUresult res = CUDA_SUCCESS;
    CCIRinstOpcodes type = CCIR_INST_OPCODE_NONE;
    uint8_t *funcCode = (uint8_t *) rec->funcBuffer.host.ptr;
    uint64_t errorBufAddr = rec->errorEntry.dev.dPtr;
    uint8_t *cp = NULL;
    uint32_t ctr = 0;
    const uint32_t instSize = rec->context->hal.getInstSize();

    rec->patchEntry = 0;

    for (ctr = 0, cp = funcCode; cp < funcCode + rec->funcBuffer.size; cp += instSize, ++ctr) {
        uint64_t *inst = (uint64_t *)cp;
        uint64_t pc = (uint64_t)(uintptr_t)(cp - funcCode + rec->func->mem.dev.dPtr);
        uint64_t inst_offset = (uint64_t)(uintptr_t)(cp - funcCode);
        uint64_t stubDevAddr = 0;
        uint64_t patchSize = 0;
        stubInfo pstate = {0};
        CCmemHandle *patchMem = NULL;

        /* Skip opexes */
        if (!rec->context->hal.isValidCodeAddr(pc))
            continue;

        /* Unsupport emulated atomic F16 sequence instruction, skip it */
        if (mcFuncIsInstructionLegacyEmulF16(rec->func, pc)) {
            CU_TRACE_PRINT(("Skipping legacy emul f16 instruction at pc %p\n", (void *)(uintptr_t)pc));
            continue;
        }

        type = checkType->isInstructionTarget(checkType, inst);
        if (!type)
            continue;

        pstate.inst = inst;
        pstate.pc = pc;
        pstate.returnTarget = pc + instSize;
        pstate.type = type;
        pstate.mcDynEnableAbi = (bool)checkType->state.enableAbi;

        switch (rec->context->hal.getOpcodeMemcheckAddrSpace(type)) {
        case MC_INST_ADDR_SPACE_GENERIC:
            res = genLDSTStub(checkType, rec, &pstate);
            if (res != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Failed to load generic ldst stub\n"));
                continue;
            }

            break;
        case MC_INST_ADDR_SPACE_GLOBAL:
            res = genGlobalLDSTStub(checkType, rec, &pstate);
            if (res != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Failed to load global ldst stub\n"));
                continue;
            }

            break;

        case MC_INST_ADDR_SPACE_SHARED:
            res = genSharedLDSTStub(checkType, rec, &pstate);
            if (res != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Failed to load shared ldst stub\n"));
                continue;
            }

            break;

        case MC_INST_ADDR_SPACE_LOCAL:
            res = genLocalLDSTStub(checkType, rec, &pstate);
            if (res != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Failed to load local ldst stub\n"));
                continue;
            }

            break;

        default:
            CU_ERROR_PRINT(("unhandled address space for inst at offset 0x%" PRIx64 "\n", inst_offset));
            CU_ASSERT(0);
            continue;
        }

        patchMem = &pstate.stubFunc->mem;

        /* Unconditional JMP to stub */
        res = rec->context->hal.patchJumpPoint(rec->context, &rec->funcBuffer, inst_offset, patchMem->dev.dPtr);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to patch jump point\n"));
            return res;
        }

        /* If the debugger is enabled, the patch will hit a breakpoint on
           detected errors.  The debugger thus needs to know about these
           code patches so it can translate the breakpoint address to the
           address of the patched instruction and maintain the illusion of
           running the originally unpatched program. */
        res = CCdbgInteropAddTrampolinePatchCommon(rec,
                                       patchMem->dev.devVaddr,
                                       patchMem->dev.dPtr,
                                       patchMem->size,
                                       pc,
                                       inst,
                                       instSize / sizeof(*inst));
        if (res != CUDA_SUCCESS) {
            // log, but continue with other instructions
            CU_ERROR_PRINT(("Failed to report patch for instruction at offset 0x%" PRIx64 " to the debugger\n", inst_offset));
            res = CUDA_SUCCESS;
        }
    }

    return CUDA_SUCCESS;
}


static CUresult
pascal_gp10x_checkType_initialize(MCcheckType *checkType)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();
    if (!checkType) {
        CU_ERROR_PRINT(("Failed to initialize\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Setup the state
    checkType->state.enableAbi  = 0;
    checkType->state.minLmem    = PASCAL_GP10X_GLOBAL_PATCH_LOCAL_MEM;
    checkType->state.minRegs    = 16;
    checkType->state.prologueSize = 0;

    return res;
}

static uint32_t
pascal_gp10x_getPatchSize(MCcheckType *checkType, MCrec *rec)
{
    uint32_t size = 0;

    CU_TRACE_FUNCTION();

    if (!checkType || !rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return 0;
    }

    CU_ASSERT(rec->funcBuffer.size);
    CU_ASSERT(rec->funcBuffer.host.ptr);

    return size;
}

static CUresult
pascal_gp10x_createPatch(MCcheckType *checkType, MCrec *rec)
{
    CU_TRACE_FUNCTION();

    if (!checkType || !rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    return patchInstructions(checkType, rec);
}

static CUresult
pascal_gp10x_updateState(MCcheckType *checkType, uint32_t enableAbi)
{
    CU_TRACE_FUNCTION();

    if (!checkType) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (enableAbi) {
        checkType->state.minRegs = 16;
        checkType->state.enableAbi = 1;
    }
    else {
        checkType->state.minRegs = 16;
        checkType->state.enableAbi = 0;
    }

    return CUDA_SUCCESS;
}

CUresult
pascal_gp10x_mem_checkType_bootstrap(MCinstManager *instMgr, MCcheckType *type)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!instMgr || !type) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    type->initialize                    =   pascal_gp10x_checkType_initialize;
    type->getPatchSize                  =   pascal_gp10x_getPatchSize;
    type->createPatch                   =   pascal_gp10x_createPatch;
    type->updateState                   =   pascal_gp10x_updateState;
    type->parseErrorEntry               =   fermi_parseErrorEntry;
    memset(&(type->tm.mem), 0, sizeof(type->tm.mem));

    return res;
}
