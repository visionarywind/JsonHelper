/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: pascal_gp10x_hal.c
 *
 *   Description:
 *       The HAL implementation for Pascal GP10x
 *
 ******************************************************************************/
#include "memcheck_types.h"

#include "halo.h"

#include "devtools/common/assembler/gm10x_sass.h"

#include "class/clc0c0qmd.h"

static bool
is_gtas_ld(const uint64_t *inst)
{
    uint64_t gld_mask = 0xe000000000000000ULL;
    return ((*inst & gld_mask) == GM10X_OPCODE_LDMIO_PIPE);
}

static bool
is_gtas_st(const uint64_t *inst)
{
    uint64_t gst_mask = 0xe000000000000000ULL;
    return ((*inst & gst_mask) == GM10X_OPCODE_STMIO_PIPE);
}

static bool
is_sld(const uint64_t *inst)
{
    uint64_t sld_mask = 0xfff8000000000000ULL;
    return ((*inst & sld_mask) == GM10X_OPCODE_LDSMIO_PIPE);
}

static bool
is_sst(const uint64_t *inst)
{
    uint64_t sst_mask = 0xfff8000000000000ULL;
    return ((*inst & sst_mask) == GM10X_OPCODE_STSMIO_PIPE);
}

static bool
is_lld(const uint64_t *inst)
{
    uint64_t lld_mask = 0xfff8000000000000ULL;
    return ((*inst & lld_mask) == GM10X_OPCODE_LDLMIO_PIPE);
}

static bool
is_lst(const uint64_t *inst)
{
    uint64_t lst_mask = 0xfff8000000000000ULL;
    return ((*inst & lst_mask) == GM10X_OPCODE_STLMIO_PIPE);
}

static bool
is_gld(const uint64_t *inst)
{
    uint64_t ldg_mask = 0xfff8000000000000ULL;
    return ((*inst & ldg_mask) == GM10X_OPCODE_LDGMIO_PIPE);
}

static bool
is_gst(const uint64_t *inst)
{
    uint64_t stg_mask = 0xfff8000000000000ULL;
    return ((*inst & stg_mask) == GM10X_OPCODE_STGMIO_PIPE);
}

static bool
is_red(const uint64_t *inst)
{
    uint64_t red_mask = 0xfff8000000000000ULL;
    return ((*inst & red_mask) == GM10X_OPCODE_REDMIO_PIPE);
}

static bool
is_atom_cas(const uint64_t *inst)
{
    uint64_t atom_cas_mask = 0xfff0000000000000ULL;
    return ((*inst & atom_cas_mask) == GM10X_OPCODE_ATOMMIO_PIPE_CAS);
}

static bool
is_atom_other(const uint64_t *inst)
{
    uint64_t atom_mask = 0xff00000000000000ULL;
    return ((*inst & atom_mask) == GM10X_OPCODE_ATOMMIO_PIPE);
}

static bool
is_atom_shared_cas(const uint64_t *inst)
{
    uint64_t atom_shared_cas_mask = 0xffe0000000000000ULL;
    return ((*inst & atom_shared_cas_mask) == GM10X_OPCODE_ATOMSMIO_PIPE_CAS);
}

static bool
is_atom_shared_other(const uint64_t *inst)
{
    uint64_t atom_shared_mask = 0xff00000000000000ULL;
    return ((*inst & atom_shared_mask) == GM10X_OPCODE_ATOMSMIO_PIPE);
}

/* Returns the access size in bytes of an instruction */
static uint32_t
getMemAccessSize(const uint64_t *inst, const MCfunc *func, const uint64_t pc)
{
    const uint32_t sizes[] = {1, 1, 2, 2, 4, 8, 16, 16};
    const uint32_t redsizes[] = {4/*U32*/,       4/*S32*/,  8/*U64*/,    4/*F32.FTZ.RN*/,
                                 4/*F16x2.RN*/,  8/*S64*/,  8/*F64.RN*/, 1/*INVALID*/};
    uint32_t sz = 0;

    if (is_gtas_ld(inst) || is_gtas_st(inst)) {
        sz = BF_GET(GM10X_FIELD_LSSize, *inst);
        return sizes[sz];
    }

    if (is_lld(inst) || is_lst(inst) ||
        is_sld(inst) || is_sst(inst) ||
        is_gld(inst) || is_gst(inst)) {
        sz = BF_GET(GM10X_FIELD_LSSize2, *inst);
        return sizes[sz];
    }

    if (is_red(inst)) {
        sz = BF_GET(GM10X_FIELD_RedSize, *inst);
        if (sz > 6) {
            CU_ASSERT(0);
        }
        return redsizes[sz];
    }

    if (is_atom_other(inst)) {
        sz = BF_GET(GM10X_FIELD_AtomSize, *inst);
        if (sz > 6) {
            CU_ASSERT(0);
        }
        return redsizes[sz];
    }

    if (is_atom_cas(inst)) {
        sz = BF_GET(GM10X_FIELD_AtomSize1, *inst);
        if (sz)
            return 8;
        else
            return 4;
    }

    if (is_atom_shared_other(inst)) {
        sz = BF_GET(GM10X_FIELD_AtomsSize ,*inst);
        if (sz < 2)
            return 4;
        else
            return 8;
    }

    if (is_atom_shared_cas(inst)) {
        sz = BF_GET(GM10X_FIELD_AtomsSize1 ,*inst);
        if (sz)
            return 8;
        else
            return 4;
    }

    return 0;
}

static MCinstAddrSpace
getOpcodeMemcheckAddrSpace(CCIRinstOpcodes instType)
{
    switch (instType) {
    case CCIR_INST_OPCODE_GENERIC_LD:
    case CCIR_INST_OPCODE_GENERIC_ST:
        return MC_INST_ADDR_SPACE_GENERIC;
    case CCIR_INST_OPCODE_GLOBAL_LD:
    case CCIR_INST_OPCODE_GLOBAL_LDU:
    case CCIR_INST_OPCODE_GLOBAL_ST:
    case CCIR_INST_OPCODE_ATOM:
    case CCIR_INST_OPCODE_RED:
        return MC_INST_ADDR_SPACE_GLOBAL;
    case CCIR_INST_OPCODE_SHARED_LD:
    case CCIR_INST_OPCODE_SHARED_ST:
    case CCIR_INST_OPCODE_ATOM_SHARED:
        return MC_INST_ADDR_SPACE_SHARED;
    case CCIR_INST_OPCODE_LOCAL_LD:
    case CCIR_INST_OPCODE_LOCAL_ST:
        return MC_INST_ADDR_SPACE_LOCAL;
    default:
        return MC_INST_ADDR_SPACE_NONE;
    }
}

static void
pascal_gp10x_setRegCountInQmd(NvU32 *qmdData, unsigned int regCount)
{
    ASSIGN_HWVALUE_MW(qmdData, C0C0, QMDV02_01, REGISTER_COUNT, regCount);
}

void memcheckInitHal_pascal_gp10x(MChal *hal, MCtoolModeArchs arch)
{
    /* Share GM20x initialization */
    memcheckInitHal_maxwell_gm20x(hal, arch);

    /* Overrides for GP10x */
    hal->isLdg             = is_gld;
    hal->isStg             = is_gst;
    hal->isGtasLd          = is_gtas_ld;
    hal->isGtasSt          = is_gtas_st;
    hal->isLds             = is_sld;
    hal->isSts             = is_sst;
    hal->isLdl             = is_lld;
    hal->isStl             = is_lst;
    hal->isRed             = is_red;

    hal->getMemAccessSize   = getMemAccessSize;
    hal->getOpcodeMemcheckAddrSpace = getOpcodeMemcheckAddrSpace;

    hal->setRegCountInQmd  = pascal_gp10x_setRegCountInQmd;
}
