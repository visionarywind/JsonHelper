/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: maxwell_gm10x_hal.c
 *
 *   Description:
 *       The HAL implementation for Kepler GK11x
 *
 ******************************************************************************/

#include "memcheck_types.h"
#include "memcheck_error.h"

#include "halo.h"

// Include this for the system stack limit and the DCI offset
#include "cui/hal/maxwell/maxwell_structs.h"

#include "devtools/common/assembler/gm10x_sass.h"

#include "devtools/common/halo/inc/fermi/fermi_mcinterop.h"

#include "class/clb0c0qmd.h"

#define PRED_MASK (BF_MASK(GM10X_FIELD_Pred) | BF_MASK(GM10X_FIELD_PredNot) )
#define PRED_INV_MASK (BF_MASK(GM10X_FIELD_PredNot) )

#define SIGN_EXT(x, N) ( ((x) << N) >> N )

static bool stub (uint64_t inst)
{
    return false;
}

static uint32_t
get_rz(void)
{
    return GM10X_RZ;
}

static bool
is_nop(const uint64_t *inst)
{
    uint64_t nop_mask = 0xfff8000000000000ULL;
    return ((*inst & nop_mask) == GM10X_OPCODE_NOP);
}

static bool
is_gtas_ld(const uint64_t *inst)
{
    uint64_t gld_mask = 0xe000000000000000ULL;
    return ((*inst & gld_mask) == GM10X_OPCODE_LDMIO_PIPE);
}

static bool
is_gtas_st(const uint64_t *inst)
{
    uint64_t gst_mask = 0xe000000000000000ULL;
    return ((*inst & gst_mask) == GM10X_OPCODE_STMIO_PIPE);
}

static bool
is_sld(const uint64_t *inst)
{
    uint64_t sld_mask = 0xfff8000000000000ULL;
    return ((*inst & sld_mask) == GM10X_OPCODE_LDSMIO_PIPE);
}

static bool
is_sst(const uint64_t *inst)
{
    uint64_t sst_mask = 0xfff8000000000000ULL;
    return ((*inst & sst_mask) == GM10X_OPCODE_STSMIO_PIPE);
}

static bool
is_lld(const uint64_t *inst)
{
    uint64_t lld_mask = 0xfff8000000000000ULL;
    return ((*inst & lld_mask) == GM10X_OPCODE_LDLMIO_PIPE);
}

static bool
is_lst(const uint64_t *inst)
{
    uint64_t lst_mask = 0xfff8000000000000ULL;
    return ((*inst & lst_mask) == GM10X_OPCODE_STLMIO_PIPE);
}

static bool
is_jcal(const uint64_t *inst)
{
    uint64_t jcal_mask = 0xfff0000000000000ULL;
    return ((*inst & jcal_mask) == GM10X_OPCODE_JCALBRU_PIPE);
}

static bool
is_jmp(const uint64_t *inst)
{
    uint64_t jmp_mask = 0xfff0000000000000ULL;
    return ((*inst & jmp_mask) == GM10X_OPCODE_JMPBRU_PIPE);
}

static bool
is_cal(const uint64_t *inst)
{
    uint64_t cal_mask = 0xfff0000000000000ULL;
    return ((*inst & cal_mask) == GM10X_OPCODE_CALBRU_PIPE);
}

static bool
is_gld(const uint64_t *inst)
{
    uint64_t ldg_mask = 0xfff8000000000000ULL;
    return ((*inst & ldg_mask) == GM10X_OPCODE_LDGMIO_PIPE);
}

static bool
is_gst(const uint64_t *inst)
{
    uint64_t stg_mask = 0xfff8000000000000ULL;
    return ((*inst & stg_mask) == GM10X_OPCODE_STGMIO_PIPE);
}

static bool
is_jmx(const uint64_t *inst)
{
    uint64_t jmx_mask = 0xfff0000000000000ULL;
    return ((*inst & jmx_mask) == GM10X_OPCODE_JMXBRU_PIPE);
}

static bool
is_shfl(const uint64_t *inst)
{
    uint64_t shfl_mask = 0xfff0000000000000ULL;
    return ((*inst & shfl_mask) == GM10X_OPCODE_SHFLMIO_PIPE);
}

static bool
is_red(const uint64_t *inst)
{
    uint64_t red_mask = 0xfff8000000000000ULL;
    return ((*inst & red_mask) == GM10X_OPCODE_REDMIO_PIPE);
}

static bool
is_atom_cas(const uint64_t *inst)
{
    uint64_t atom_cas_mask = 0xfff0000000000000ULL;
    return ((*inst & atom_cas_mask) == GM10X_OPCODE_ATOMMIO_PIPE_CAS);
}

static bool
is_atom_other(const uint64_t *inst)
{
    uint64_t atom_mask = 0xff00000000000000ULL;
    return ((*inst & atom_mask) == GM10X_OPCODE_ATOMMIO_PIPE);
}

static bool
is_atom(const uint64_t *inst)
{
    return (is_atom_cas(inst) || is_atom_other(inst));
}

static bool
is_atom_shared_cas(const uint64_t *inst)
{
    uint64_t atom_shared_cas_mask = 0xffe0000000000000ULL;
    return ((*inst & atom_shared_cas_mask) == GM10X_OPCODE_ATOMSMIO_PIPE_CAS);
}

static bool
is_atom_shared_other(const uint64_t *inst)
{
    uint64_t atom_shared_mask = 0xff00000000000000ULL;
    return ((*inst & atom_shared_mask) == GM10X_OPCODE_ATOMSMIO_PIPE);
}

static bool
is_atom_shared(const uint64_t *inst)
{
    return (is_atom_shared_cas(inst) || is_atom_shared_other(inst));
}

static bool
is_bar(const uint64_t inst, uint32_t *barmode)
{
    uint64_t bar_mask = 0xfff8000000000000ULL;
    if ((inst & bar_mask) == GM10X_OPCODE_BARMIO_PIPE_SYNC) {
        if (barmode)
            *barmode = BF_GET(GM10X_FIELD_BarOp, inst);
        return true;
    }
    return false;
}

static bool
is_synchronizing_barrier(const uint64_t *inst)
{
    uint32_t barmode = 0;

    if (!is_bar(*inst, &barmode))
        return false;

    return (barmode == GM10X_KEYWORD_BARSYNC_SYNC ||
            barmode == GM10X_KEYWORD_BARRED_RED);
}

static bool
is_exit(const uint64_t *inst)
{
    uint64_t exit_mask = 0xfff0000000000000ULL;
    return ((*inst & exit_mask) == GM10X_OPCODE_EXITBRU_PIPE);
}

static bool
is_ret(const uint64_t *inst)
{
    uint64_t ret_mask = 0xfff0000000000000ULL;
    return ((*inst & ret_mask) == GM10X_OPCODE_RETBRU_PIPE);
}

static uint32_t
get_ra(const uint64_t *inst)
{
    if (is_gtas_ld(inst) || is_gtas_st(inst) ||
        is_sld(inst) || is_sst(inst) ||
        is_lld(inst) || is_lst(inst) ||
        is_atom(inst) || is_red(inst) ||
        is_gld(inst) || is_gst(inst) ||
        is_atom_shared(inst))
        return BF_GET(GM10X_FIELD_RegA, *inst);
    else
        return GM10X_RZ;
}

static uint32_t
get_rb(const uint64_t *inst)
{
    if (is_gtas_st(inst) || is_sld(inst) ||
        is_sst(inst) || is_lst(inst) ||
        is_red(inst) || is_gst(inst))
        return BF_GET(GM10X_FIELD_Dest, *inst);
    else if (is_atom(inst) || is_atom_shared(inst))
        return BF_GET(GM10X_FIELD_RegB, *inst);
    else
        return GM10X_RZ;
}

static uint32_t
get_ccTest(const uint64_t *inst)
{
    if (is_exit(inst) ||
        is_ret(inst) ||
        is_jmp(inst) ||
        is_jmx(inst)) {
        return BF_GET(GM10X_FIELD_CCC_1, *inst);
    } else {
        CU_ERROR_PRINT(("Invalid instruction for ccTest\n"));
        return 0;
    }
}

static uint64_t
get_predRawInv(const uint64_t *inst)
{
    return (((*inst) ^ PRED_INV_MASK) & PRED_MASK);
}

static uint64_t
get_predMask(const uint64_t *inst)
{
    return (PRED_MASK);
}

static uint32_t
get_predWithInv(const uint64_t *inst)
{
    return (uint32_t)((((*inst) & PRED_MASK) >> BF_LO(GM10X_FIELD_Pred)) & 0xf );
}

static bool
getExtended(const uint64_t *inst)
{
    if (is_gtas_ld(inst)  || is_gtas_st(inst))
        return (BF_GET(GM10X_FIELD_E, *inst) == GM10X_KEYWORD_E_E);

    if (is_gld(inst) || is_gst(inst))
        return (BF_GET(GM10X_FIELD_E2, *inst) == GM10X_KEYWORD_E_E);

    if (is_atom(inst) || is_red(inst))
        return (BF_GET(GM10X_FIELD_AtomE, *inst) == GM10X_KEYWORD_E_E);

    return false;
}

static uint32_t
getOffset(const uint64_t *inst)
{
    int32_t rawVal = 0;
    bool signExt = true;

    signExt = (BF_GET(GM10X_FIELD_RegA, *inst) != 255);

    if (is_lst(inst) || is_lld(inst) ||
        is_sst(inst) || is_sld(inst) ||
        is_gld(inst) || is_gst(inst) ) {
        rawVal = BF_GET(GM10X_FIELD_Imm24, *inst);
        if (signExt)
            rawVal = SIGN_EXT(rawVal, 8);
        return (uint32_t)rawVal;
    }

    if (is_gtas_ld(inst) || is_gtas_st(inst))
        return (uint32_t)(BF_GET(GM10X_FIELD_Imm32, *inst));

    if (is_red(inst) || is_atom(inst)) {
        rawVal = BF_GET(GM10X_FIELD_Imm20a, *inst);
        if (signExt)
            rawVal = SIGN_EXT(rawVal, 12);
        return (uint32_t)rawVal;
    }

    if (is_atom_shared(inst)) {
        rawVal = BF_GET(GM10X_FIELD_Imm22atoms, *inst);
        // offset is only 22 bits out of 24 for ATOMS, so it needs to be zero-extended
        rawVal <<= 2;
        if (signExt)
            rawVal = SIGN_EXT(rawVal, 8);
        return (uint32_t)rawVal;
    }

    return 0;
}

static bool
is_write(const uint64_t *inst)
{
    if (is_lst(inst)      || is_sst(inst) ||
        is_gtas_st(inst)  || is_gst(inst) ||
        is_red(inst))
        return true;

    return false;
}

/* Returns the size in bytes of a GLD or GST instruction */
static uint32_t
getMemAccessSize(const uint64_t *inst, const MCfunc *func, const uint64_t pc)
{
    const uint32_t sizes[] = {1, 1, 2, 2, 4, 8, 16, 16};
    const uint32_t redsizes[] = {4/*U32*/,            4/*S32*/, 8/*U64*/,     4/*F32.FTZ.RN*/,
                                 4/*F16x2.FTZ.RN*/,   8/*S64*/, 1/*INVALID*/, 1/*INVALID*/};
    /* Note: redsizes[4] == F16x2.FTZ.RN is valid only on sm52+ and invalid on sm50 */
    uint32_t sz = 0;

    if (is_gtas_ld(inst) || is_gtas_st(inst)) {
        sz = BF_GET(GM10X_FIELD_LSSize, *inst);
        return sizes[sz];
    }

    if (is_lld(inst) || is_lst(inst) ||
        is_sld(inst) || is_sst(inst) ||
        is_gld(inst) || is_gst(inst)) {
        sz = BF_GET(GM10X_FIELD_LSSize2, *inst);
        return sizes[sz];
    }

    if (is_red(inst)) {
        sz = BF_GET(GM10X_FIELD_RedSize, *inst);
        if (sz > 5) {
            CU_ASSERT(0);
        }
        return redsizes[sz];
    }

    if (is_atom_other(inst)) {
        sz = BF_GET(GM10X_FIELD_AtomSize, *inst);
        if (sz > 5) {
            CU_ASSERT(0);
        }
        return redsizes[sz];
    }

    if (is_atom_cas(inst)) {
        sz = BF_GET(GM10X_FIELD_AtomSize1, *inst);
        if (sz)
            return 8;
        else
            return 4;
    }

    if (is_atom_shared_other(inst)) {
        sz = BF_GET(GM10X_FIELD_AtomsSize ,*inst);
        if (sz < 2)
            return 4;
        else
            return 8;
    }

    if (is_atom_shared_cas(inst)) {
        sz = BF_GET(GM10X_FIELD_AtomsSize1 ,*inst);
        if (sz)
            return 8;
        else
            return 4;
    }

    return 0;
}

static void
maxwell_gm10x_getBreakInstruction(MCrec *rec, uint64_t *out)
{
    /*  BPT.TRAP 1 */
    *out = GM10X_INST_BPT_ALL(GM10X_KEYWORD_BPTMODE_TRAP, 1);
}

static void
maxwell_gm10x_getTexDepBar(MCrec *rec, uint64_t *out)
{
    *out = GM10X_INST_DEPBAR;
}

static uint32_t
maxwell_gm10x_isDirectCall(const uint64_t *inst)
{
    return (is_jcal(inst) || is_jmp(inst));
}

static bool
has_plg(const uint64_t *inst)
{
    if (is_gtas_ld(inst) || is_gtas_st(inst))
        return true;

    return false;
}

static void
gen_jcal(uint64_t addr, bool callDepth, uint32_t ra, uint64_t *out)
{
    const uint32_t inc = callDepth ? GM10X_KEYWORD_INC_INC : GM10X_KEYWORD_INC_NOINC;

    *out = GM10X_INST_JCAL_ALL(inc, (uint32_t)addr);
}

static void
gen_ret(uint64_t addr, bool callDepth, uint32_t ra, uint64_t *out)
{
    *out = GM10X_INST_RET;
}

static void
gen_plgRawInv(const uint64_t *inst, uint64_t *out)
{
    uint32_t predlg = GM10X_KEYWORD_PREDICATE_PT;
    if (has_plg(inst))
        predlg = BF_GET(GM10X_FIELD_PredSrcldst, *inst);

    *out = (predlg << BF_LO(GM10X_FIELD_Pred)) ^ PRED_INV_MASK;
}

static uint64_t
get_controlFlowImm(const uint64_t *inst, bool *isSigned)
{
    uint32_t target = 0;

    if (is_cal(inst)) {
        int32_t rawVal = 0;
        rawVal = BF_GET(GM10X_FIELD_Imm24, *inst);
        target = SIGN_EXT(rawVal, 8);
        *isSigned = true;
    } else
    if (is_jcal(inst)) {
        target = BF_GET(GM10X_FIELD_Imm32, *inst);
        *isSigned = false;
    }

    return (uint64_t)target;
}

static bool
get_controlFlowDepth(const uint64_t *inst)
{
    bool inc = false;

    if (is_cal(inst) || is_jcal(inst)) {
        uint32_t rawVal = 0;
        rawVal = BF_GET(GM10X_FIELD_INC, *inst);
        inc = (rawVal == GM10X_KEYWORD_INC_INC);
    }

    return inc;
}

static bool
maxwell_gm10x_isValidCodeAddress(uint64_t dptr)
{
    // Instructions at 32 byte multiples are OPEXes !
    if (!(dptr & 31))
        return false;

    return true;
}

static void
genLmemHiSpill(uint32_t lmemHiOffset, uint32_t asize, uint32_t regb, uint64_t *out)
{
    if (asize <= 4)
        *out = GM10X_INST_STL_ALL(GM10X_KEYWORD_PREDICATE_PT, GM10X_KEYWORD_STORECACHEOP_WT, GM10X_KEYWORD_CINTEGER_32, GM10X_RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH + lmemHiOffset, regb);
    else if (asize == 8)
        *out = GM10X_INST_STL_ALL(GM10X_KEYWORD_PREDICATE_PT, GM10X_KEYWORD_STORECACHEOP_WT, GM10X_KEYWORD_CINTEGER_64, GM10X_RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH + lmemHiOffset, regb);
    else if (asize == 16)
        *out = GM10X_INST_STL_ALL(GM10X_KEYWORD_PREDICATE_PT, GM10X_KEYWORD_STORECACHEOP_WT, GM10X_KEYWORD_CINTEGER_128, GM10X_RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH + lmemHiOffset, regb);
    else {
        CU_ERROR_PRINT(("Invalid asize : %u\n", asize));
        *out = GM10X_INST_STL_ALL(GM10X_KEYWORD_PREDICATE_PT, GM10X_KEYWORD_STORECACHEOP_WT, GM10X_KEYWORD_CINTEGER_32, GM10X_RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH + lmemHiOffset, regb);
    }
}

static void
gen_lmemHiRead(uint32_t lmemHiOffset, uint32_t asize, uint32_t regd, uint64_t *out)
{
    if (asize <= 4)
        *out = GM10X_INST_LDL_ALL(GM10X_KEYWORD_PREDICATE_PT, GM10X_KEYWORD_STORECACHEOP_WT, GM10X_KEYWORD_CINTEGER_32, regd, GM10X_RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH + lmemHiOffset);
    else if (asize == 8)
        *out = GM10X_INST_LDL_ALL(GM10X_KEYWORD_PREDICATE_PT, GM10X_KEYWORD_STORECACHEOP_WT, GM10X_KEYWORD_CINTEGER_64, regd, GM10X_RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH + lmemHiOffset);
    else if (asize == 16)
        *out = GM10X_INST_LDL_ALL(GM10X_KEYWORD_PREDICATE_PT, GM10X_KEYWORD_STORECACHEOP_WT, GM10X_KEYWORD_CINTEGER_128, regd, GM10X_RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH + lmemHiOffset);
    else {
        CU_ERROR_PRINT(("Invalid asize: %u\n", asize));
        *out = GM10X_INST_LDL_ALL(GM10X_KEYWORD_PREDICATE_PT, GM10X_KEYWORD_STORECACHEOP_WT, GM10X_KEYWORD_CINTEGER_32, regd, GM10X_RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH + lmemHiOffset);
    }
}

static bool
barHasThreadCount(const uint64_t *inst)
{
    uint32_t count = 0;
    uint32_t asrc = 0, bsrc = 0;
    uint32_t reg_a;

    if (!is_synchronizing_barrier(inst)) {
        CU_ERROR_PRINT(("Not a barrier\n"));
        return false;
    }

    asrc = BF_GET(GM10X_FIELD_AFix_BAR, *inst);
    bsrc = BF_GET(GM10X_FIELD_BFix_BAR, *inst);
    count = BF_GET(GM10X_FIELD_Imm12, *inst);
    reg_a = get_ra(inst);

    if (bsrc == 1) {
        /* If BarB mode is from immediate, just check Imm20 */
        return (count != 0);
    }

    /* bsrc != 0 (i.e. B from reg), need to check either ra, or imm20 as rb */
    if (asrc == 1)
        return ((count & 0x0ff) != GM10X_RZ);

    /* asrc == 0, bsrc == 0, use rega */
    return (reg_a != GM10X_RZ);
}

static uint32_t
barGetNameReg(const uint64_t *inst)
{
    uint32_t asrc = 0;
    uint32_t reg_a;

    if (!is_synchronizing_barrier(inst)) {
        CU_ERROR_PRINT(("Not a barrier\n"));
        return GM10X_RZ;
    }

    asrc = BF_GET(GM10X_FIELD_AFix_BAR, *inst);
    reg_a = BF_GET(GM10X_FIELD_RegA, *inst);

    /* If A isfrom an immediate return GM10X_RZ */
    if (asrc == 1)
        return GM10X_RZ;

    return reg_a;
}

static uint32_t
barGetNameImm(const uint64_t *inst)
{
    uint32_t asrc = 0;
    uint32_t reg_a;

    if (!is_synchronizing_barrier(inst)) {
        CU_ERROR_PRINT(("Not a barrier\n"));
        return 0;
    }

    asrc = BF_GET(GM10X_FIELD_AFix_BAR, *inst);
    reg_a = BF_GET(GM10X_FIELD_RegA, *inst);

    /* If A isfrom an immediate return the value.
       Since the rega field overlaps the immediate,
       we can use that to read the ImmU4 back */
    if (asrc == 1)
        return (uint32_t) (reg_a & 0xf);

    return 0;
}

static uint32_t
barGetCountReg(const uint64_t *inst)
{
    uint32_t bsrc = 0;
    uint32_t reg_b;

    if (!is_synchronizing_barrier(inst)) {
        CU_ERROR_PRINT(("Not a barrier\n"));
        return GM10X_RZ;
    }

    bsrc = BF_GET(GM10X_FIELD_BFix_BAR, *inst);
    reg_b = BF_GET(GM10X_FIELD_RegB, *inst);

    /* If B isfrom an immediate return GM10X_RZ */
    if (bsrc == 1)
        return GM10X_RZ;

    return reg_b;
}

static uint32_t
barGetCountImm(const uint64_t *inst)
{
    uint32_t bsrc = 0;
    uint32_t count = 0;

    if (!is_synchronizing_barrier(inst)) {
        CU_ERROR_PRINT(("Not a barrier\n"));
        return 0;
    }

    bsrc = BF_GET(GM10X_FIELD_BFix_BAR, *inst);
    count = BF_GET(GM10X_FIELD_Imm12, *inst);

    /* If B is from an immediate, return count */
    if (bsrc == 1)
        return (uint32_t) (count & 0x0fff);

    return 0;
}

static void
gen_csetp(uint32_t test, uint32_t pred, uint64_t *out)
{
   *out = GM10X_INST_CSETP(test,                        // .test
                           GM10X_KEYWORD_BOP_AND,       // .bop
                           pred,                        // Pu
                           GM10X_KEYWORD_PREDICATE_PT,  // Pv
                           GM10X_KEYWORD_PREDICATE_PT,  // Pp
                           0);                          // {!}Pp
}

static void
gen_mov(uint32_t rdest, uint32_t rsrc, uint64_t *out)
{
    *out = GM10X_INST_MOV(rdest, rsrc);
}

static void
gen_movFromImm(uint32_t rdest, uint32_t imm, uint64_t *out)
{
    *out = GM10X_INST_MOV32I(rdest, imm);
}

static void
gen_jmp(uint64_t addr, uint64_t *out)
{
    *out = GM10X_INST_JMP((uint32_t)addr);
}

static void
gen_retWithPredCC(const uint64_t *inst, uint64_t *out)
{
    uint32_t pred = BF_GET(GM10X_FIELD_Pred, *inst);
    uint32_t pnot = BF_GET(GM10X_FIELD_PredNot, *inst);
    uint32_t cc = BF_GET(GM10X_FIELD_CCC_1, *inst);

    if (is_exit(inst))
        *out = GM10X_INST_RET_ALL(pred, cc) | BF_FLDV(GM10X_FIELD_PredNot, pnot);
    else
        *out = GM10X_INST_RET;
}

static void
gen_longjmpWithPredCC(const uint64_t *inst, uint64_t *out)
{
    uint32_t pred = BF_GET(GM10X_FIELD_Pred, *inst);
    uint32_t pnot = BF_GET(GM10X_FIELD_PredNot, *inst);
    uint32_t cc = BF_GET(GM10X_FIELD_CCC_1, *inst);

    if (is_exit(inst))
        *out = GM10X_INST_LONGJMP_ALL(pred, cc) | BF_FLDV(GM10X_FIELD_PredNot, pnot);
    else
        *out = GM10X_INST_LONGJMP;
}

static CUresult
maxwell_gm10x_patchJumpPointCommon(MCcontext *mcctx, CCmemHandle *mem, uint64_t instOffset, uint64_t targetAddr, uint8_t isJcal)
{
    uint64_t opexOffset;
    uint32_t opexShift;
    uint64_t opexMask;
    char *cp, *opexAddr;
    uint64_t opexWord, jmpWord;

    if (!mcctx || !mem) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!mem->host.ptr) {
        CU_ERROR_PRINT(("Invalid host pointer\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    opexOffset = (instOffset - (instOffset & (~0x1fULL)));
    opexShift = (uint32_t)(((opexOffset >> 3) - 1) * 21) ;
    opexMask = 0x1fffffULL << (opexShift) ;
    cp = (char*)mem->host.ptr + instOffset;
    opexAddr = (char*)(cp - opexOffset);

    /* Write the OPEX */
    memcpy((char*)&opexWord, opexAddr, sizeof(opexWord));
    opexWord = ((opexWord) & (~opexMask)) | ((0x7f5ULL << opexShift) & opexMask);
    memcpy(opexAddr, (char*)&opexWord, sizeof(opexWord));

    /* Write the jump/jcal */
    if (isJcal)
        mcctx->hal.genAbsoluteCall(targetAddr, false, get_rz(), &jmpWord);
    else
        mcctx->hal.genJmp(targetAddr, &jmpWord);
    memcpy(cp, (char*)&jmpWord, sizeof(jmpWord));

    return CUDA_SUCCESS;
}

static CUresult
maxwell_gm10x_patchJumpPoint(MCcontext *mcctx, CCmemHandle *mem, uint64_t instOffset, uint64_t targetAddr)
{
    return maxwell_gm10x_patchJumpPointCommon(mcctx, mem, instOffset, targetAddr, 0);
}

static CUresult
maxwell_gm10x_patchJcalPoint(MCcontext *mcctx, CCmemHandle *mem, uint64_t instOffset, uint64_t targetAddr)
{
    return maxwell_gm10x_patchJumpPointCommon(mcctx, mem, instOffset, targetAddr, 1);
}

static uint32_t
get_instSourceType(const uint64_t *inst)
{
    if (is_synchronizing_barrier(inst)) {
        uint32_t sourceType = 0;
        uint32_t barModeA = BF_GET(GM10X_FIELD_AFix_BAR, *inst);
        uint32_t barModeB = BF_GET(GM10X_FIELD_BFix_BAR, *inst);

        if (barModeA)
            sourceType |= MC_INST_SOURCE_TYPE_IMMEDIATE;
        else
            sourceType |= MC_INST_SOURCE_TYPE_REGISTER;

        if (barModeB)
            sourceType |= MC_INST_SOURCE_TYPE_IMMEDIATE;
        else
            sourceType |= MC_INST_SOURCE_TYPE_REGISTER;

        return sourceType;
    }

    return MC_INST_SOURCE_TYPE_UNKNOWN;
}

static void
maxwell_gm10x_setRegCountInQmd(NvU32 *qmdData, unsigned int regCount)
{
    ASSIGN_HWVALUE_MW(qmdData, B0C0, QMDV01_07, REGISTER_COUNT, regCount);
}

void
memcheckInitHal_maxwell_gm10x(MChal *hal, MCtoolModeArchs arch)
{
    memcheckInitHal_common(hal, arch);

    hal->maxJumpOffset      = 1ULL << 32;  //32 bits
    hal->savedSPAddr        = CU_MAXWELL_THREAD_STATE_OFFSET(savedUserStackPointer);
    hal->cnpReservedLmemStart = CU_MAXWELL_THREAD_STATE_POINTER;
    hal->cnpReservedLmemSize  = CU_MAXWELL_LMEM_THREAD_STATE_SIZE;
    hal->genTexDrainInstruction = maxwell_gm10x_getTexDepBar;

    hal->gridParamsConstBank  = CU_MAXWELL_PARAM_CONST_SEGMENT;
    hal->gridParamsUserStackTopOffset  = CU_MAXWELL_DCI_OFFSET(userStackPointer);
    hal->gridParamsSWinLoOffset = CU_MAXWELL_DCI_OFFSET(sharedWindowBase);
    hal->driverInternalParamsConstBank = CU_MAXWELL_PARAM_CONST_SEGMENT;
    hal->driverInternalParamsShmemSizeOffset = CNP_GRID_PARAM_OFFSET(totalShmemSize);

    hal->getRz             = get_rz;

    hal->isNop             = is_nop;
    hal->isLdg             = is_gld;
    hal->isStg             = is_gst;
    hal->isGtasLd          = is_gtas_ld;
    hal->isGtasSt          = is_gtas_st;
    hal->isLds             = is_sld;
    hal->isSts             = is_sst;
    hal->isLdl             = is_lld;
    hal->isStl             = is_lst;
    hal->isRed             = is_red;
    hal->isAtom            = is_atom;
    hal->isAtomS           = is_atom_shared;
    hal->isAbsoluteCall    = is_jcal;
    hal->isRelativeCall    = is_cal;
    hal->isSynchronizingBarrier = is_synchronizing_barrier;
    hal->isExit            = is_exit;
    hal->isRet             = is_ret;
    hal->isJmx             = is_jmx;
    hal->isShfl            = is_shfl;
    hal->hasPlg            = has_plg;

    hal->genAbsoluteCall   = gen_jcal;
    hal->genRet            = gen_ret;
    hal->genMov            = gen_mov;
    hal->genMovFromImm     = gen_movFromImm;
    hal->genRetWithPredCC  = gen_retWithPredCC;
    hal->genLongJmpWithPredCC = gen_longjmpWithPredCC;
    hal->genJmp            = gen_jmp;
    hal->genCsetp          = gen_csetp;

    hal->getMemAccessSize   = getMemAccessSize;
    hal->getExtended        = getExtended;
    hal->getOffset          = getOffset;
    hal->isWrite            = is_write;

    hal->genBreakInstruction = maxwell_gm10x_getBreakInstruction;
    hal->isDirectCall        = maxwell_gm10x_isDirectCall;
    hal->isIndirectCall      = is_jmx;
    hal->isValidCodeAddr     = maxwell_gm10x_isValidCodeAddress;

    hal->genLmemHiSpill     = genLmemHiSpill;
    hal->genLmemHiRead      = gen_lmemHiRead;
    hal->barHasThreadCount  = barHasThreadCount;
    hal->barGetNameReg      = barGetNameReg;
    hal->barGetNameImm      = barGetNameImm;
    hal->barGetCountReg     = barGetCountReg;
    hal->barGetCountImm     = barGetCountImm;

    hal->getRa             = get_ra;
    hal->getRb             = get_rb;
    hal->getCcTest         = get_ccTest;
    hal->getPredRawInv     = get_predRawInv;
    hal->getPredMask       = get_predMask;
    hal->getPredWithInv    = get_predWithInv;
    hal->genPlgRawInv      = gen_plgRawInv;
    hal->getControlFlowImm = get_controlFlowImm;
    hal->getControlFlowDepth = get_controlFlowDepth;
    hal->getInstSourceType = get_instSourceType;

    hal->patchJumpPoint    = maxwell_gm10x_patchJumpPoint;
    hal->patchAbsoluteCallPoint = maxwell_gm10x_patchJcalPoint;

    hal->setRegCountInQmd  = maxwell_gm10x_setRegCountInQmd;
}
