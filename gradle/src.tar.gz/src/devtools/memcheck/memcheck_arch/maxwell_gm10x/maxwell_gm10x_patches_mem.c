/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: maxwell_gm10x_patches_mem.c
 *
 *   Description:
 *       The common memcheck patch code for Maxwell GM10x
 *
 ******************************************************************************/

#include "memcheck_types.h"
#include "memcheck_error.h"
#include "memcheck_arch/inc/maxwell_gm10x/maxwell_gm10x_patches_mem.h"
#include "memcheck_arch/inc/maxwell_gm10x/maxwell_gm10x_patches_common.h"
#include "memcheck_arch/inc/maxwell_gm10x/maxwell_gm10x_patches.h"
#include "halo.h"
#include "memcheck_arch/inc/fermi/fermi_patches_common.h"

// Include this for the system stack limit
#include "cui/hal/maxwell/maxwell.h"

static uint64_t *
maxwell_gm10x_genAlignCheck(MCcheckType *checkType, MCrec *rec,
                            uint64_t *patchCode, uint64_t *patchStart)
{
    // Check the alignment of some memcheck region
    memcpy(patchCode, memcheckPatchAlignCheck, sizeof(memcheckPatchAlignCheck));

    patchCode[PATCH_ALIGN_CHECK_BRA] = GM10X_PRED(P0, GM10X_BRA_CC(TEST_NE,
                                                  (char*)patchStart +
                                                  PATCH_FAIL_ENTRY *8 -
                                                  ((char*)patchCode + 8 +
                                                   PATCH_ALIGN_CHECK_BRA*8)));

    patchCode += sizeof(memcheckPatchAlignCheck)/sizeof(*patchCode);

    return patchCode;
}

static uint32_t
maxwell_gm10x_getAlignCheckSize(MCcheckType *checkType, MCrec *rec)
{
    return sizeof(memcheckPatchAlignCheck);
}

static uint64_t *
maxwell_gm10x_genFinalizeCheck(MCcheckType *checkType, MCrec *rec,
                               uint64_t *patchCode, uint64_t *patchStart)
{
    /* If we reach the end, we deem it an illegal access.

       VERY IMPORTANT: in general, memcheck must not use predicated
       branches as it can create control flow divergence and lead to
       changing program semantics (this was bug 687852). However, here
       we are ready to abandon the execution anyway, so it doesn't
       really matter. This is yet another reasons why the --error flag
       doesn't really work in practice and should only be used
       internally. */

    *patchCode++ = GM10X_DEFAULT_OPEX; /* Need the maxwell OPEX */

    *patchCode = GM10X_PRED(P0, GM10X_INST_BRA((char *) patchStart
                                               + PATCH_FAIL_ENTRY*8
                                               - ((char *) patchCode + 8)));
    ++patchCode;

    /* Branch back to the restore portion of the stub. When ABI support is
       enabled, we need to restore R0..R15. This means the jump must be
       to the top of the check stub. If not, we jump to two instructions
       after the top, and restore only R0..R7 */
    if (checkType->state.enableAbi)
        *patchCode = GM10X_INST_BRA(/*Ok*/ (char *) patchStart -
                                           ((char *) patchCode + 8) + (PATCH_OK_ENTRY_HI * 8));
    else
        *patchCode = GM10X_INST_BRA(/*Ok*/ (char *) patchStart -
                                           ((char *) patchCode + 8) + (PATCH_OK_ENTRY_LO * 8));

    ++patchCode;

    *patchCode++ = GM10X_INST_NOP; /* Pad out the I$ half line */

    return patchCode;
}

static uint32_t
maxwell_gm10x_getFinalizeCheckSize(MCcheckType *checkType, MCrec *rec)
{
    return sizeof(endOfCheck);
}


static uint64_t*
genStub(MCcheckType *checkType, MCrec *rec, uint64_t *patchCode,
        uint64_t *inst, uint32_t instAddr, CCIRinstOpcodes type,
        uint32_t checkTarget)
{
    //These are specific for every load store
    bool extended  = rec->context->hal.getExtended(inst);
    int32_t offset = rec->context->hal.getOffset(inst);
    //This are generic for all LD/ST instructions
    uint32_t pred  = BF_GET(GM10X_FIELD_Pred, *inst) | (BF_GET(GM10X_FIELD_PredNot, *inst) << 3);
    uint32_t ra    = BF_GET(GM10X_FIELD_RegA, *inst);
    uint32_t ra_lo = ra;
    uint32_t ra_hi = extended ? ra_lo + 1 : RZ;
    bool hasplg =  rec->context->hal.hasPlg(inst);
    uint32_t predlg = BF_GET(GM10X_FIELD_PredSrcldst, *inst);
    uint32_t asize = rec->context->hal.getMemAccessSize(inst, rec->func, instAddr);
    /* Stub:

       Note, this can be improved, but for the first version I don't
       want too many special cases so it's overly expensive.

       STL        [LMEM_HI_SCRATCH], R0
       STL        [LMEM_HI_SCRATCH+4], R1
       STL        [LMEM_HI_SCRATCH+8], R2
       STL        [LMEM_HI_SCRATCH+12], R3
       STL        [LMEM_HI_SCRATCH+16], R4
       STL        [LMEM_HI_SCRATCH+20], R5
       STL        [LMEM_HI_SCRATCH+24], R6
       STL        [LMEM_HI_SCRATCH+28], R7

       MOV        R0, <<< ld/st addr register lo >>>
       MOV        R1, <<< ld/st addr register hi (or RZ for 32-bit addresses) >>>

       P2R        R7

       IADD32I    R0.CC, R0, <<< ld/st offset >>>
       IADD32I.X  R1, R1, RZ
       MOV32I     R2, <<< alignment mask >>>
       MOV32I     R3, <<< address of ld/st >>>
       JCAL       check
       <<< orig ld/st instruction >>>
       JMP        <<< address of ld/st + 8 >>>

       The original instruction doesn't need to strip the
       predicates as they must have been satisfied to get
       here for non ABI. For ABI, the predicates are
       restored by this point.)

       Note, check takes care of restoring R0-R15 before returning. */

    CU_DEBUG_PRINT(("stub at %08" PRIx64 " for instruction %08x:%016" PRIx64 " (size %d)\n",
                    (char*)patchCode - (char*)rec->patchBuffer.host.ptr + rec->patchOffset,
                    instAddr,
                    *inst, asize));

    /* The first two instructions in patch code must be NOP ?OFF_DECK_DRAIN.
       This is due to bug 1267433
    */
    *patchCode++ = GM10X_DEFAULT_OPEX;
    *patchCode++ = GM10X_INST_NOP;
    *patchCode++ = GM10X_INST_NOP;
    *patchCode++ = GM10X_INST_NOP;

    *patchCode++ = GM10X_DEFAULT_OPEX;

    *patchCode++ = GM10X_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH, R0);
    *patchCode++ = GM10X_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+4, R1);
    *patchCode++ = GM10X_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+8, R2);

    *patchCode++ = GM10X_DEFAULT_OPEX;


    *patchCode++ = GM10X_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+12, R3);
    *patchCode++ = GM10X_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+16, R4);
    *patchCode++ = GM10X_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+20, R5);

    *patchCode++ = GM10X_DEFAULT_OPEX;

    *patchCode++ = GM10X_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+24, R6);
    *patchCode++ = GM10X_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+28, R7);
    *patchCode++ = GM10X_INST_NOP;

    //For ABI function call support, spill more registers
    if (checkType->state.enableAbi) {

        *patchCode++ = GM10X_DEFAULT_OPEX;
        *patchCode++ = GM10X_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+32, R8);
        *patchCode++ = GM10X_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+36, R9);
        *patchCode++ = GM10X_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+40, R10);

        *patchCode++ = GM10X_DEFAULT_OPEX;

        *patchCode++ = GM10X_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+44, R11);
        *patchCode++ = GM10X_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+48, R12);
        *patchCode++ = GM10X_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+52, R13);

        *patchCode++ = GM10X_DEFAULT_OPEX;

        *patchCode++ = GM10X_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+56, R14);
        *patchCode++ = GM10X_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+60, R15);
        *patchCode++ = GM10X_INST_NOP;
    }

    *patchCode++ = GM10X_DEFAULT_OPEX;
    *patchCode++ = GM10X_INST_NOP;
    *patchCode++ = GM10X_INST_MOV(R0, ra_lo);
    *patchCode++ = GM10X_INST_MOV(R1, ra_hi);

    *patchCode++ = GM10X_DEFAULT_OPEX;
    *patchCode++ = GM10X_P2R(R7, RZ);
    *patchCode++ = GM10X_C2R(R7, R7);
    *patchCode++ = GM10X_IADD32I_CC(R0, R0, offset);

    // 32-bit mode wraps around, so only need this for extended addr
    *patchCode++ = GM10X_DEFAULT_OPEX;
    *patchCode++ = GM10X_IADD32I_X(R1, R1, (int64_t) offset >> 32);
    *patchCode++ = GM10X_INST_MOV32I(R2, asize - 1); // memaddr_mask
    *patchCode++ = GM10X_INST_MOV32I(R3, instAddr);

    *patchCode++ = GM10X_DEFAULT_OPEX;

    /* Force P7 to true */
    *patchCode++ = GM10X_LOP32I(LOP_OR, R7, R7, 0x80);

    if (hasplg) {
        *patchCode++ = GM10X_LOP32I(LOP_AND, R6, R7, (1U << predlg));        // Set R6 = PR & ( 1 << Plg)
        *patchCode++ = GM10X_ISETP_AND(CMP_NE, P3, R6, RZ, PT); // Copy Plg
    }
    else {
        *patchCode++ = GM10X_INST_NOP; // NOP this out
        *patchCode++ = GM10X_INST_NOP; // NOP this out
    }

    *patchCode++ = GM10X_DEFAULT_OPEX;

    *patchCode++ = GM10X_LOP32I(LOP_AND, R6, R7, (1U << (pred & 0x7)));

    if (pred & 0x8)
        *patchCode++ = GM10X_ISETP_AND(CMP_EQ, P0, R6, RZ, PT); // Copy predicate
    else
        *patchCode++ = GM10X_ISETP_AND(CMP_NE, P0, R6, RZ, PT); // Copy predicate

    /* Always store the PC and address into LMEM */
    *patchCode++ = GM10X_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH +
                             FERMI_LMEM_MEMCHECK_ADDR, R0);

    *patchCode++ = GM10X_DEFAULT_OPEX;
    *patchCode++ = GM10X_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH +
                             FERMI_LMEM_MEMCHECK_ADDR_HI, R1);
    //For now, only write the low bits of the PC.
    *patchCode++ = GM10X_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+
                             FERMI_LMEM_MEMCHECK_PC, R3);
    *patchCode++ = GM10X_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+80, R2);

    *patchCode++ = GM10X_DEFAULT_OPEX;
    *patchCode++ = GM10X_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+84, R7);
    *patchCode++ = GM10X_INST_MOV32I(R5, getAddressSpace(type));
    *patchCode++ = GM10X_STL(RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+92, R5);

    /* Globals have different call stubs to handle the plg (multiple targets) */
    return checkType->tm.mem.genStubJcal(checkType, rec, type, patchCode, checkTarget, instAddr);
}

static CUresult
patchInstructions(MCcheckType *checkType, MCrec *rec)
{
    uint8_t  *funcCode         = (uint8_t *) rec->funcBuffer.host.ptr;
    uint64_t *patchBase        = (uint64_t *) rec->patchBuffer.host.ptr;
    uint64_t *patchTypeBase    = patchBase + rec->patchOffsets[checkType->state.type] / sizeof (uint64_t);
    uint64_t *patchCode        = patchTypeBase;
    uint64_t *patchCodeLimit   = patchBase + rec->patchOffsets[checkType->state.type + 1] / sizeof (uint64_t);
    uint32_t  patchCheckOffset = (uint32_t) (rec->patchOffset + rec->patchOffsets[checkType->state.type]);
    uint64_t  errorBufAddr     = rec->errorEntry.dev.dPtr;
    uint8_t  *cp;
    size_t    patchActualSize;
    uint64_t *patchCheckStart;
    char name[999];
    static uint32_t number=100;
    CCIRinstOpcodes type = CCIR_INST_OPCODE_NONE;
    uint32_t ctr = 0;

    (void) patchCodeLimit; // Quell a complaint from gcc
    rec->patchEntry = 0;

    patchCheckStart = patchCode;
    /* Check Function */
    memcpy(patchCode, memcheckPatchCheck, sizeof memcheckPatchCheck);

    patchCode[PATCH_FAIL_ERROR_LOC] = GM10X_INST_MOV32I(R4, (uint32_t)errorBufAddr);
    patchCode[PATCH_FAIL_ERROR_LOC+1] = GM10X_INST_MOV32I(R5, (uint32_t)(errorBufAddr >> 32));

    if (rec->options.debuggerAttached   ||
        rec->options.forceError         ||
        rec->options.nonblockingLaunch)
        rec->context->hal.genBreakInstruction(rec, &(patchCode[PATCH_FAIL_BREAK]));

    patchCode += sizeof memcheckPatchCheck / 8;

    patchCode = checkType->tm.mem.genAlignCheck(checkType, rec, patchCode,
                                                (uint64_t*)patchTypeBase);
    patchCode = checkType->tm.mem.genRangeCheck(checkType, rec, patchCode);
    patchCode = checkType->tm.mem.genFinalizeCheck(checkType, rec, patchCode,
                                                   (uint64_t *)patchTypeBase);

    CU_ASSERT(patchCode <= patchCodeLimit);

    /* Report the memcheck patch */
    CCdbgInteropAddStandalonePatch(rec,
                                   (char*)patchCheckStart - (char*)patchBase + rec->patchBuffer.dev.devVaddr,
                                   (char*)patchCheckStart - (char*)patchBase + rec->patchBuffer.dev.dPtr,
                                   (uint64_t) (patchCode - patchCheckStart)*8);

    /* Stub -- function-specific setup -- one per global load/store */
    for (ctr = 0, cp = funcCode; cp < funcCode + rec->funcBuffer.size; cp += 8, ++ctr) {
        uint64_t inst = *(uint64_t *)cp;
        /* Skip opexes */
        if (! rec->context->hal.isValidCodeAddr(ctr *8 + rec->funcBuffer.dev.dPtr))
            continue;

        type = checkType->isInstructionTarget(checkType, &inst);
        if (type) {
            uint64_t *opexword = NULL;
            uint32_t opexshift = 0;
            uint64_t opexmask  = 0x1ffffULL;
            uint64_t stubEntry = (char*)patchCode
                                 - (char*)rec->patchBuffer.host.ptr
                                 + rec->patchOffset;
            uint64_t stubEntryDevVaddr = (char*)patchCode
                                         - (char*)rec->patchBuffer.host.ptr
                                         + rec->patchBuffer.dev.devVaddr;
            uint32_t patchSize = 0;
            uint32_t checkTarget = 0;

            /* We must be 64-bit aligned */
            CU_ASSERT(((uintptr_t)cp & 7) == 0);

            /* The first two instructions in patch code must be NOP ?OFF_DECK_DRAIN.
               and the entry to patch code must be a JMP ?WAIT5. This is due to bug 1267433

                A JMP ?WAIT5 is sufficient to prevent a lookback in code patching, so long as
                the patch code (i.e. the target of the JMP) is constructed correctly.

                These are the assumptions for the scenarios being considered :

                1.  The original program is free of the bug.
                2.  A patching program is replacing selected instructions with JMP to
                    patch code, where the patch code is being generated by the program.
                3.  The instruction being patched is at an arbitrary location
                4.    In the snippets below
                a.    The previous instruction is a PC modifying instruction
                      (so the bug could be introduced by the opex modification due to patching)
                b.    the instruction to be patched is STL [R0], R0;

                The patching strategy is as follows:
                1. Replace the instruction to be patched with a JMP ?WAIT5 to patch code
                2. The patch code contains two NOP ?OFF_DECK_DRAINs at the start of the patch.
                  The double ?OFF_DECK_DRAIN instructions can mitigate the problem
                  (as explained below in Scenario 2).
                3. The patch handles predication on the original instruction by predicating the
                   return from patch code, instead of a conditional jump into patch code.
                4. The final instruction in the patch is a JMP with an ?OFF_DECK_DRAIN, which
                   returns to the instruction after the entry point.
                5. An example patch looks like this (It just executes the original instruction
                   after spill/filling R0-R3) :
                    NOP ?OFF_DECK_DRAIN;
                    NOP ?OFF_DECK_DRAIN;
                    @!Px JMP `PatchSiteReturn ?OFF_DECK_DRAIN;
                    STL.128 [0xfffe00], R0 &rd = {0}?WAIT4;
                    LDL.128 R0, [0xfffe00] &wr={0} &req = {0} ?WAIT4;
                    STL [R0], R0 &req={0} ?WAIT4;
                    JMP `PatchSiteReturn ?OFF_DECK_DRAIN;

                Now consider the following scenarios:

                Scenario 1: Previous Instruction has ?OFF_DECK_DRAIN,
                            Next instruction does not have ?OFF_DECK_DRAIN.
                Original code:
                 SYNC ?OFF_DECK_DRAIN;
                 STL [R0], R0 &req={0} ?WAIT2;
                 MOV R1, R0 ? WAIT5;

                Patched code:
                  SYNC ?OFF_DECK_DRAIN;
                  JMP `PatchCode ?WAIT5;
                  MOV R1, R0 ?WAIT5;

                In this case, the bug is not triggered as the fallthrough does not
                have an OFF_DECK_DRAIN

                Scenario 2 : Previous Instruction has an ?OFF_DECK_DRAIN,
                             Next instruction has an ?OFF_DECK_DRAIN
                Original code:
                 SYNC ?OFF_DECK_DRAIN;
                 STL [R0], R0 &req={0} ?WAIT2;
                 MOV R1, R0 ?OFF_DECK_DRAIN;

                Patched code:
                  SYNC ?OFF_DECK_DRAIN;
                  JMP `PatchCode ?WAIT5;
                  MOV R1, R0 ?OFF_DECK_DRAIN;

                In this case, the bug is triggered. The pre-drain happens early, but the
                branch to patch code is made anyway. However, there are two ?OFF_DECK_DRAIN
                instructions in the start of patch code. The first one will bypass the
                pre-drain check, and do the post drain. This will reset the state machine,
                so when the  second ?OFF_DECK_DRAIN issues, it will perform both pre and post
                drains correctly. At this point, the patch state is consistent with what the
                tool expects (all outstanding scoreboards are drained,
                in flight accesses are complete, and the patch can reuse scoreboards internally.).

                Scenario 3 : Previous Instruction does not have an ?OFF_DECK_DRAIN
                             Next instruction has an ?OFF_DECK_DRAIN
                Original code:
                 SYNC ?WAIT5;
                 STL [R0], R0 &req={0} ?WAIT2;
                 MOV R1, R0 ?OFF_DECK_DRAIN;

                Patched code:
                  SYNC ?WAIT5;
                  JMP `PatchCode ?WAIT5;
                  MOV R1, R0 ?OFF_DECK_DRAIN;

                In this case, if the JMP for the patch had an ?OFF_DECK_DRAIN, this would introduce
                the problem of having to look back into the original code, patching potentially all
                prior PC-changing instructions to ?OFF_DECK_DRAIN. Instead since the JMP has a ?WAIT5,
                the insertion cannot cause the bug for a previous instruction. For the remainder,
                this becomes the same as Scenario 2.
            */
            /* Find the opex word and compute the mask */
            opexword = (uint64_t*)((char*)rec->funcBuffer.host.ptr + (ctr & ~3ULL) *8);
            opexshift = (uint32_t)(21 *((ctr & 3UL) - 1));
            opexmask = opexmask << opexshift;

            /* New OPEX - WAIT5 */
            *opexword = ((*opexword) & (~opexmask)) | ((0x7f5ULL << opexshift) & opexmask);

            /* Unconditional JMP to stub */
            *(uint64_t *)cp = GM10X_INST_JMP(stubEntry);
            /* The entry to the check is after the main body of the check.
               Add an extra 8 bytes to jump past the OPEX on the alignment check */
            checkTarget = patchCheckOffset + sizeof(memcheckPatchCheck) + 8;


            patchCode = genStub(checkType, rec, patchCode, &inst, (uint32_t) (cp - funcCode + rec->func->mem.dev.dPtr), type, checkTarget);

            *patchCode++ = GM10X_DEFAULT_OPEX; /* MUST BE OFF_DECK_DRAIN for inst */
            *patchCode++ = inst;
            *patchCode++ = GM10X_INST_JMP(cp - funcCode + 8 + rec->func->mem.dev.dPtr);

            *patchCode++ = GM10X_INST_NOP;
            patchSize = (uint32_t)((char*)patchCode - (char*)rec->patchBuffer.host.ptr + rec->patchOffset - stubEntry);
            CU_ASSERT(patchCode <= patchCodeLimit);
            CCdbgInteropAddTrampolinePatch(rec,
                                           stubEntryDevVaddr,
                                           stubEntry,
                                           patchSize,
                                           (cp - funcCode + rec->func->mem.dev.dPtr),
                                           inst);
        }
    }

    // Don't delete the following line until I have had a change to look at improvements.
    //printf("Allocated %"PRIdPTR" bytes more than needed\n", 8*(patchCodeLimit - patchCode));

    patchActualSize = (char *) patchCode - (char *) patchCheckStart;

    if (rec->options.printCubins) {
        snprintf(name , sizeof name, "patch-%d.cubin", number++);
        checkType->printCubin(checkType, name, patchCheckStart, (uint32_t) patchActualSize);
    }

    /* If the debugger is enabled, the patch will hit a breakpoint on
       detected errors.  The debugger thus needs to know about these
       code patches so it can translate the breakpoint address to the
       address of the patched instruction and maintain the illusion of
       running the originally unpatched program. */

    return CUDA_SUCCESS;
}


static CUresult
maxwell_gm10x_checkType_initialize(MCcheckType *checkType)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();
    if (!checkType) {
        CU_ERROR_PRINT(("Failed to initialize\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Setup the state
    checkType->state.enableAbi  = 0;
    checkType->state.minLmem    = MAXWELL_GM10X_GLOBAL_PATCH_LOCAL_MEM;
    checkType->state.minRegs    = 8;
    checkType->state.prologueSize = 0;

    return res;
}

static uint32_t
maxwell_gm10x_getPatchSize(MCcheckType *checkType, MCrec *rec)
{
    uint64_t *funcBegin = NULL;
    uint64_t *funcEnd = NULL;
    uint64_t  *cp = NULL;
    uint32_t size = 0;
    uint32_t ctr = 0;
    CCIRinstOpcodes instType = CCIR_INST_OPCODE_NONE;

    CU_TRACE_FUNCTION();

    if (!checkType || !rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return 0;
    }

    CU_ASSERT(rec->funcBuffer.size);
    CU_ASSERT(rec->funcBuffer.host.ptr);

    funcBegin = (uint64_t *)rec->funcBuffer.host.ptr;
    funcEnd = funcBegin + rec->funcBuffer.size / sizeof(uint64_t);

    /* Fixed portion */
    size = sizeof memcheckPatchCheck;
    size += checkType->tm.mem.getAlignCheckSize(checkType, rec);

    /* Add the size of allocation checking */
    size += checkType->tm.mem.getRangeCheckSize (checkType, rec);
    size += checkType->tm.mem.getFinalizeCheckSize(checkType, rec);

    /* Pr load/store portion */
    for (ctr = 0, cp = funcBegin; cp < funcEnd; ++cp, ++ctr) {
        /* Skip OPEXes */
        if (! rec->context->hal.isValidCodeAddr(ctr*8 + rec->funcBuffer.dev.dPtr))
            continue;

        instType = checkType->isInstructionTarget(checkType, cp);
        if (instType != CCIR_INST_OPCODE_NONE) {
            if (checkType->state.enableAbi)
                size += sizeof memcheckPatchStubWithAbi;
            else
                size += sizeof memcheckPatchStubWithoutAbi;

            size += checkType->tm.mem.getStubJcalSize(checkType, rec, instType);
        }

    }

    return size;
}

static CUresult
maxwell_gm10x_createPatch(MCcheckType *checkType, MCrec *rec)
{
    CU_TRACE_FUNCTION();

    if (!checkType || !rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    return patchInstructions(checkType, rec);
}

uint64_t*
maxwell_gm10x_mem_genStubJcal(MCcheckType *checkType, MCrec *rec,
                              CCIRinstOpcodes instType,
                              uint64_t *patchCode,
                              uint32_t checkTarget,
                              uint32_t instrAddr)
{
    *patchCode++ = GM10X_DEFAULT_OPEX;
    *patchCode++ = GM10X_INST_JCAL(checkTarget);
    *patchCode++ = GM10X_INST_NOP;
    *patchCode++ = GM10X_INST_NOP;
    return patchCode;
}

uint32_t
maxwell_gm10x_mem_getStubJcalSize(MCcheckType *checkType, MCrec *rec, CCIRinstOpcodes instType)
{
    return 8 * 4;
}


CUresult
maxwell_gm10x_mem_bootstrap(MCinstManager *instMgr, MCcheckType *type)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!instMgr || !type) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    type->initialize                    =   maxwell_gm10x_checkType_initialize;
    type->getPatchSize                  =   maxwell_gm10x_getPatchSize;
    type->createPatch                   =   maxwell_gm10x_createPatch;
    type->parseErrorEntry               =   fermi_parseErrorEntry;
    type->tm.mem.genStubJcal            =   maxwell_gm10x_mem_genStubJcal;
    type->tm.mem.getStubJcalSize        =   maxwell_gm10x_mem_getStubJcalSize;
    type->tm.mem.genAlignCheck          =   maxwell_gm10x_genAlignCheck;
    type->tm.mem.genFinalizeCheck       =   maxwell_gm10x_genFinalizeCheck;
    type->tm.mem.getAlignCheckSize      =   maxwell_gm10x_getAlignCheckSize;
    type->tm.mem.getFinalizeCheckSize   =   maxwell_gm10x_getFinalizeCheckSize;

    return res;
}
