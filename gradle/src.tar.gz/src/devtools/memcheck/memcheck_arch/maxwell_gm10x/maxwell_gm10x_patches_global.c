/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: maxwell_gm10x_patches_global.c
 *
 *   Description:
 *       The HAL implementation for Maxwell GM10x
 *
 ******************************************************************************/

#include "memcheck_types.h"
#include "memcheck_error.h"
#include "memcheck_arch/inc/maxwell_gm10x/maxwell_gm10x_patches_global.h"
#include "memcheck_arch/inc/maxwell_gm10x/maxwell_gm10x_patches_common.h"
#include "memcheck_arch/inc/maxwell_gm10x/maxwell_gm10x_patches.h"
#include "halo.h"
#include "memcheck_arch/inc/fermi/fermi_patches_common.h"

#include "check_alloc.h"

/*
   Strategy: since we don't try to insert instructions into the
   middle, we follow the cuda-memcheck/Tesla stategy of replacing all
   checked instructions with a branch to the stub, which then invokes
   the checker.

   It's critical to not introduce divergence that wasn't in the
   original code (this was bug 687852), so we copy the patched
   instruction's predicate into P0 and predicate everything by
   that. The only divergence we will allow is when errors are found at
   which point we are about to crash anyway, so who cares :)

   what was:

        00e8    mov r3, r3
        00f0    (pred) ld.e r1, [r2]
        00f8    imul.hi r2, r1, 0x4

   becomes:

        00e8    mov r3, r3;
        00f0    jmp stub_00f0
        resumepoint:
        00f8    imul.hi r2, r1, 0x4


        stub_00f0:
                ..... save off registers and predicates
                set up parameters to check
                P0 = (pred)
                call check

                (pred) ld.e r1, [r2]
                jmp resumepoint

 */

/* Generate the check for one allocation. The result is chained with
   though predicate P0. */
static uint64_t*
gen1MemRangeCheck(MCrec *rec,
                  uint64_t m_addr,
                  uint64_t m_size,
                  uint64_t *patchCode)
{
    uint64_t size = m_size - 1;

    CU_DEBUG_PRINT(("[%08" PRIx64 "; %08" PRIx64 ")\n",
                    m_addr, m_addr + m_size));

    *patchCode++ = GM10X_DEFAULT_OPEX;

    // R5R4 = addr - m.base
    *patchCode++ = GM10X_PRED(P0,GM10X_IADD32I_CC(R4, R0, -(int64_t)m_addr));
    *patchCode++ = GM10X_PRED(P0,GM10X_IADD32I_X(R5, R1, -(int64_t)m_addr >> 32));

    // @P0 IADD            RZ.CC, R4, LO(-size+1)
    // @P0 ISETP.GT.U32.X.AND P0, pt, R5, RZ, pt;
    *patchCode++ = GM10X_PRED(P0,GM10X_IADD32I_CC(RZ, R4, -(int64_t)size));

    *patchCode++ = GM10X_DEFAULT_OPEX;

    *patchCode++ = GM10X_PRED(P0,GM10X_INST_MOV32I(R6, size >> 32));
    *patchCode++ = GM10X_PRED(P0,GM10X_ISETP_X(CMP_GT, P0, R5, R6));
    *patchCode++ = GM10X_INST_NOP;

    /* P0 == Haven't found a match yet, !P0 == Found a match (or
       instruction was never executed in the first place). */

    return patchCode;
}

/* This generates the ABI compatible jump and the heap check.
   The heap address is directly read from the global variable. The
   target address for the check routine is provided as a parameter */
static uint64_t*
genAbiJumpHeapCheck(MCrec *rec,
                    uint64_t jumpaddr,
                    uint64_t *patchCode)
{
    uint64_t addr;
    uint64_t size;

    CU_TRACE_FUNCTION();
    addr = CCallocGetStart(rec->context->heapAlloc);
    size = CCallocGetSize(rec->context->heapAlloc);
    memcpy(patchCode, memcheckPatchAbiJump, sizeof (memcheckPatchAbiJump));


    patchCode[PATCH_ABI_HEAP_ADDR] = GM10X_PRED(P0, GM10X_IADD32I_CC(R4, R0, -(int64_t)addr));
    patchCode[PATCH_ABI_HEAP_ADDR+1] = GM10X_PRED(P0, GM10X_IADD32I_X(R5, R1,-(int64_t)addr >> 32));
    patchCode[PATCH_ABI_HEAP_SIZE] = GM10X_PRED(P0, GM10X_IADD32I_CC(RZ, R4, -(int64_t)size + 1));
    patchCode[PATCH_ABI_HEAP_SIZE + 1] = GM10X_PRED(P0, GM10X_INST_MOV32I(R6, size >> 32));
    patchCode[PATCH_ABI_JUMP] = GM10X_INST_JCAL(jumpaddr);
    patchCode += sizeof (memcheckPatchAbiJump) / 8;

    return patchCode;
}

static uint64_t*
genShmemCheck(MCrec *rec, uint64_t *patchCode)
{
    MChal *hal = &rec->context->hal;

    /* This check will kick in if there is any shared memory
       being used. The amount of shared memory being used
       is written into the const bank.

       The basic logic here is the following:

        if (ShmemSize &&
            SR_SWinLo <= Addr < SR_SWinLo + ShmemSize)
            stop checks;

        This can be shrunken down to
        OPEX
        @P0 LDC R4 c [0] [`SR_SWinLo];  // Gets the base address of smem window from DCI
        @P0 LDC R5 c [0] [`ShmemSize];  // Gets the usable shmem size from the driver internal constbank
        @P0 IADD R4, R0, -R4;           // Use a subtract operation

        OPEX
        @P0 IADD32I R5, R1, 0xffffffff; // Top 32 bits of shmem addresses are always clear
        @P0 IADD RZ.CC, R4, -R6;        // Use a subtract operation
        @P0 ISETP.GT.U32.X.AND P0, pt, R5, RZ, PT;

    */

    *patchCode++ = GM10X_DEFAULT_OPEX;
    *patchCode++ = GM10X_PRED(P0, GM10X_LDC(R4, hal->gridParamsConstBank, hal->gridParamsSWinLoOffset));
    *patchCode++ = GM10X_PRED(P0, GM10X_LDC(R6, hal->driverInternalParamsConstBank, hal->driverInternalParamsShmemSizeOffset));

    *patchCode++ = GM10X_PRED(P0, GM10X_IADD_NEGB_CC(R4, R0, R4));

    *patchCode++ = GM10X_DEFAULT_OPEX;
    *patchCode++ = GM10X_PRED(P0,GM10X_IADD32I_X(R5, R1, 0xffffffff));

    *patchCode++ = GM10X_PRED(P0, GM10X_IADD_NEGB_CC(RZ, R4, R6));
    *patchCode++ = GM10X_PRED(P0,GM10X_ISETP_X(CMP_GT, P0, R5, RZ));

    return patchCode;
}

static uint64_t*
genLmemHiCheck(MCrec *rec, uint64_t *patchCode)
{
    uint32_t hasAbi = 0;
    uint32_t lmemHiOff = MAXWELL_GM10X_GLOBAL_LMEM_START; // Start of Lmem window
    MChal *hal = &rec->context->hal;

    hasAbi = (rec->func->mod->abiVersion >= ELFOSABIV_ABI);

    /* This check will only kick in if LmemHi will be used
        The check is as follows:
        LMEM_HI_USER_MAX > addr > LMEM_HI_MIN
        Where LMEM_HI_USER_MAX is given as the start of the user
        stack. (i.e. 16MB - 512 (debugger) - SystemStackSize - CnpStackSize)
        LMEM_HI_MIN is MAX(SR_LMemHiOff, func->stackSize, r1)
        The func->stackSize check is generated only
        if there is a stack size.
        The r1 check is only generated if recursion is possible
    */
    if (hasAbi || rec->config.funcDataStackSize) {
        *patchCode++ = GM10X_DEFAULT_OPEX;
        *patchCode++ = GM10X_PRED(P0, GM10X_INST_LDC_I(R4, hal->gridParamsUserStackTopOffset));
        *patchCode++ = GM10X_PRED(P0, GM10X_INST_S2R(R5, 55));
        *patchCode++ = GM10X_INST_NOP;
        if (hasAbi) {
            *patchCode++ = GM10X_DEFAULT_OPEX;
            *patchCode++ = GM10X_PRED(P0, GM10X_LDL(R6, RZ, FERMI_LMEM_HI_MEMCHECK_SCRATCH+4));
            *patchCode++ = GM10X_PRED(P0, GM10X_INST_MOV(R7, RZ));
            *patchCode++ = GM10X_PRED(P0, GM10X_ISET(CMP_GT, R7, R5, R6));
            *patchCode++ = GM10X_DEFAULT_OPEX;
            *patchCode++ = GM10X_PRED(P0, GM10X_INST_ICMP(CMP_NE, R5, R5, R6, R7));
            *patchCode++ = GM10X_INST_NOP;
            *patchCode++ = GM10X_INST_NOP;
        }
        if (rec->config.funcDataStackSize) {
            *patchCode++ = GM10X_DEFAULT_OPEX;
            *patchCode++ = GM10X_PRED(P0, GM10X_INST_IADD32I(R6, R4, -((int32_t)rec->func->cufunc->stackSize)));
            *patchCode++ = GM10X_PRED(P0, GM10X_INST_MOV(R7, RZ));
            *patchCode++ = GM10X_PRED(P0, GM10X_ISET(CMP_GT, R7, R5, R6));
            *patchCode++ = GM10X_DEFAULT_OPEX;
            *patchCode++ = GM10X_PRED(P0, GM10X_INST_ICMP(CMP_NE, R5, R5, R6, R7));
            *patchCode++ = GM10X_INST_NOP;
            *patchCode++ = GM10X_INST_NOP;
        }
        *patchCode++ = GM10X_DEFAULT_OPEX;
        *patchCode++ = GM10X_PRED(P0, GM10X_INST_IADD32I(R4, R4, lmemHiOff));
        *patchCode++ = GM10X_PRED(P0, GM10X_INST_IADD32I(R5, R5, lmemHiOff));
        *patchCode++ = GM10X_PRED(P0, GM10X_ISET(CMP_GT, R4, R4, R0));
        *patchCode++ = GM10X_DEFAULT_OPEX;
        *patchCode++ = GM10X_PRED(P0, GM10X_ISET(CMP_GE, R5, R0, R5));
        *patchCode++ = GM10X_PRED(P0, GM10X_LOP(LOP_AND, R4, R4, R5));
        *patchCode++ = GM10X_PRED(P0, GM10X_ISETP(CMP_EQ, P0, RZ, R4));
    }

    return patchCode;
}

typedef struct allocFunctorData_st allocFunctorData;
struct allocFunctorData_st {
    MCrec *rec;
    uint64_t *patchCode;
};

static CUresult
genAllocPatch(CCallocTable *tbl, CCalloc *alloc, void* data)
{
    allocFunctorData *d = (allocFunctorData*)data;

    uint64_t m_addr = CCallocGetStart(alloc);
    uint64_t m_size = CCallocGetSize(alloc);

    d->patchCode = gen1MemRangeCheck(d->rec, m_addr, m_size, d->patchCode);

    return CUDA_SUCCESS;
}

static uint64_t*
maxwell_gm10x_global_genRangeCheck(MCcheckType *checkType, MCrec *rec, uint64_t *patchCode)
{
    allocFunctorData d;
    CUresult res = CUDA_SUCCESS;
    /* XXX Tools API doesn't have access to this yet (bug 686401), so
       overestimate */
    uint64_t jumpaddr = 0;

    /* Auto generate the memory mapping lookups which is a sequence of

       if (addr - m1.base < m1.size) goto Ok;

       IADD32I             R4.CC, R0, LO(-m1.base)
       IADD32I.X           R5,    R1, HI(-m1.base)
    */

    /* Check region layout for global checks:
               RESTORE ------------------
               | Restore  16reg         |
               | Restore  8 reg         |
               | RET                    |
               FAIL     -----------------
               | Write Error            |
               |                        |
               |   TRAP/EXIT            |
               CHECK_START_SMEM----------
               |  test alignment        |
               |  goto FAIL             |
               |  shared window  check  |
               |  Finalize Check        |
               CHECK_START_LMEM----------
               |  test alignment        |
               |  goto FAIL             |
               |  lmem lo/hi check      |
               CHECK_START_GMEM----------
               |  test alignment        |
               |  goto FAIL             |
               |  range checks          |
               |  Finalize check        |
               --------------------------

        When Plg = true, then stub goes to CHECK_START_LMEM
        When Plg = false, then stub goes to CHECK_START_SMEM

        Atomics are special cased, and will directly go to
        CHECK_START_GMEM (this is why a second alignment check
        is present).
    */

    patchCode = genShmemCheck(rec, patchCode);

    /* This is the finalize for SMEM checks */
    patchCode = checkType->tm.mem.genFinalizeCheck(checkType, rec, patchCode,
                                                   (uint64_t *) rec->patchBuffer.host.ptr
                                                   + rec->patchOffsets[checkType->state.type] / sizeof (uint64_t));


    /* The align check for the lmem entry */
    patchCode = checkType->tm.mem.genAlignCheck(checkType, rec, patchCode,
                                                (uint64_t*)rec->patchBuffer.host.ptr +
                                                rec->patchOffsets[checkType->state.type] / sizeof(uint64_t));
    if (rec->config.lmemLoSize)
        patchCode = gen1MemRangeCheck(rec, 0x03000000, rec->config.lmemLoSize, patchCode);

    patchCode = genLmemHiCheck(rec, patchCode);

    patchCode = checkType->tm.mem.genAlignCheck(checkType, rec, patchCode,
                                                (uint64_t*)rec->patchBuffer.host.ptr +
                                                rec->patchOffsets[checkType->state.type] / sizeof(uint64_t));
    d.rec = rec;
    d.patchCode = patchCode;

    res = CCallocTableApplyFunctor(rec->globalAllocs, genAllocPatch, &d);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to generate alloc patches\n"));
    }
    patchCode = d.patchCode;

    /* Allow for access to the virtualized lmem and share memory region.

       Fermi introduced a "uniform address space" which allows access
       to shared and local memory though general pointers. The magic
       holes in the address space are given by
       CU_FERMI_SHARED_WINDOW_BASE and CU_FERMI_LMEM_WINDOW_BASE which
       are defined in

         //sw/dev/gpu_drv/cuda_a/drivers/gpgpu/cuda/src/cui/hal/fermi/fermi.h

       Currently (and for the foreseeable future), these are fixed at
       0x01000000 and 0x03000000 respectively. The hardware defines
       these as 16 MiB windows, but the actual backing store behind
       them is much smaller, depending on how much shared, LMEM_LO,
       and LMEM_HI memory is allocated.

          [0x01000000; 0x01000000+shmemSize)
          [0x03000000; 0x03000000+lmemLoSize)
          [0x04000000-lmemHiSize; 0x04000000)

       FWIW, global device memory starts at 0x05000000.
    */

    if (rec->context->heapAlloc) {
        if (rec->context->dynamic) {
            res = MCDynamicGetCheckFuncAddress(rec->context, &jumpaddr);
            if (res != CUDA_SUCCESS)
                CU_ERROR_PRINT(("Failed to read check func address\n"));
            else
                CU_TRACE_PRINT(("Got active check jump addr:0x%" PRIx64 "\n",
                                jumpaddr));
        }
        // Generate the dynamic checker function call
        if (checkType->state.enableAbi && jumpaddr)
            patchCode = genAbiJumpHeapCheck(rec, jumpaddr, patchCode);
        else
            patchCode = gen1MemRangeCheck(rec,
                                          CCallocGetStart(rec->context->heapAlloc),
                                          CCallocGetSize(rec->context->heapAlloc),
                                          patchCode);

    }
    return patchCode;
}

static uint32_t
getLmemCheckOffset(MCcheckType *checkType, MCrec *rec)
{
    uint32_t sz = 0;

    sz += checkType->tm.mem.getAlignCheckSize(checkType, rec);
    sz += checkType->tm.mem.getFinalizeCheckSize(checkType, rec);

    sz += sizeof(memcheckPatchCheckShmem);

    return sz;
}

static uint32_t
getGmemCheckOffset(MCcheckType *checkType, MCrec *rec)
{
    uint32_t sz = 0;
    uint32_t hasAbi = 0;

    hasAbi = (rec->func->mod->abiVersion >= ELFOSABIV_ABI);

    sz += checkType->tm.mem.getAlignCheckSize(checkType, rec);

    if (rec->config.lmemLoSize)
        sz += sizeof(memcheckPatchCheckAllocation);

    if (hasAbi || rec->config.funcDataStackSize) {
        sz += sizeof(memcheckPatchCheckLmemHi_prologue);
        sz += sizeof(memcheckPatchCheckLmemHi_epilogue);
        if (hasAbi)
            sz += sizeof(memcheckPatchCheckLmemHi_r1Check);
        if (rec->config.funcDataStackSize)
            sz += sizeof(memcheckPatchCheckLmemHi_stackCheck);
    }

    return sz;
}


static uint32_t
maxwell_gm10x_global_getRangeCheckSize (MCcheckType *checkType, MCrec *rec)
{
    uint32_t size = 0;
    uint32_t numAllocs = 0;

    /* Add in the ABI check stub */
    if (checkType->state.enableAbi)
        size += sizeof memcheckPatchAbiJump;

    /* Pr allocation portion */
    numAllocs = CCallocTableGetSize(rec->globalAllocs);
    size += sizeof(memcheckPatchCheckAllocation) * numAllocs;

    /* Add space for the window checks */
    size += getLmemCheckOffset(checkType, rec) + getGmemCheckOffset(checkType, rec);

    return size;
}


static CUresult
maxwell_gm10x_global_updateState(MCcheckType *checkType, uint32_t enableAbi)
{
    CU_TRACE_FUNCTION();

    if (!checkType) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (enableAbi) {
        checkType->state.minRegs = 16;
        checkType->state.enableAbi = 1;
    }
    else {
        checkType->state.minRegs = 8;
        checkType->state.enableAbi = 0;
    }

    return CUDA_SUCCESS;
}

static uint64_t*
maxwell_gm10x_global_genStubJcal(MCcheckType *checkType, MCrec *rec,
                                 CCIRinstOpcodes instType,
                                 uint64_t *patchCode,
                                 uint32_t checkTarget,
                                 uint32_t instrAddr)
{
    uint32_t checkEntry = checkTarget;

    if (!checkType || !rec || !patchCode || !instrAddr) {
        CU_ASSERT(0);
        return patchCode;
    }

    if (instType == CCIR_INST_OPCODE_GENERIC_LD ||
        instType == CCIR_INST_OPCODE_GENERIC_ST) {
        /* generics need to be able to go to either shared or local/global checks */
        checkEntry = checkTarget + getLmemCheckOffset(checkType, rec);

        *patchCode++ = GM10X_DEFAULT_OPEX;
        *patchCode++ = GM10X_INST_SSY(7 * 8);
        *patchCode++ = GM10X_PRED(NOT_P3, GM10X_INST_BRA(3*8));
        *patchCode++ = GM10X_INST_JCAL(checkEntry); // Global + local
        *patchCode++ = GM10X_DEFAULT_OPEX;
        *patchCode++ = GM10X_INST_BRA(1*8);
        *patchCode++ = GM10X_INST_JCAL(checkTarget);        // Shared
        *patchCode++ = GM10X_INST_SYNC;

        return patchCode;
    }
    else {
        /* For all other globals, skip directly to the global checks */
        checkEntry = checkTarget + getLmemCheckOffset(checkType, rec) + getGmemCheckOffset(checkType, rec);
        return maxwell_gm10x_mem_genStubJcal(checkType, rec, instType, patchCode, checkEntry, instrAddr);
    }
}

static uint32_t
maxwell_gm10x_global_getStubJcalSize(MCcheckType *checkType, MCrec *rec, CCIRinstOpcodes instType)
{
    if (instType == CCIR_INST_OPCODE_GENERIC_LD ||
        instType == CCIR_INST_OPCODE_GENERIC_ST)
        return sizeof(memcheckGlobalStubJcalPlg);
    else
        return maxwell_gm10x_mem_getStubJcalSize(checkType, rec, instType);
}

CUresult
maxwell_gm10x_global_checkType_bootstrap(MCinstManager *instMgr, MCcheckType *type)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!instMgr || !type) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Override for maxwell_gm10x_global variants. These are in maxwell_gm10x_global.[hc]
    type->updateState               =   maxwell_gm10x_global_updateState;
    type->tm.mem.genRangeCheck      =   maxwell_gm10x_global_genRangeCheck;
    type->tm.mem.getRangeCheckSize  =   maxwell_gm10x_global_getRangeCheckSize;
    type->tm.mem.genStubJcal        =   maxwell_gm10x_global_genStubJcal;
    type->tm.mem.getStubJcalSize    =   maxwell_gm10x_global_getStubJcalSize;
    return res;
}
