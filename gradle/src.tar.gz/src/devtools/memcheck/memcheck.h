/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: memcheck.h
 *
 *   Description:
 *       Function declarations for memcheck module
 *
 ******************************************************************************/

#ifndef _MEMCHECK_H
#define _MEMCHECK_H

/*
  Known limitations:
  Does not support SM_10 (WNF)
  Will not perform any checking if too many functions are loaded (~16MB -- fixable)

  Ideas for moving forward:
  Create a new function structure and migrate some fields from MCrec to it.
  Create a map from CUfunction -> MCfunc
  Relocate .debug_line once per function and save just that section to MCfunc
  readelf stuff in general could use a lot of cleanup (and there are bugs)
*/

#include "cudamemcheck.h"
#include "memcheck_types.h"
#include "memcheck_tool_modes.h"

typedef struct CCmemcheckCtxData_st CCmemcheckCtxData;
typedef struct CCmemcheckRecData_st CCmemcheckRecData;

struct CCmemcheckCtxData_st {
    /* Main module */
    MCmod *mod;

    // Ptr to common checker function in C
    uint64_t commonPerGlobalLdSt;
};

struct CCmemcheckRecData_st {
    tList *internalModules;
    // Array of type MCdevAlloc
    CCmemHandle globalAllocDevBuffer;
};

CUresult memcheck_toolModeInitialize(MCoptions *options, MCtoolMode *toolMode);
CUresult memcheckTrapHandlerCallback(MCcontext *mcctx,
                                     CUmemobj* scratchpadMemobj,
                                     uint32_t smError);

CUresult memcheckTrapHandlerEndCallback(MCcontext *mcctx,
                                        CUmemobj* scratchpadMemobj,
                                        uint32_t smError);

CCmemcheckCtxData *memcheckGetCtxData(MCcontext *mcctx);
CCmemcheckRecData *memcheckGetRecData(MCrec *rec);

CUresult memcheckLoadLDSTStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, uint64_t patchPC,
                              CCIRinstOpcodes instType, bool mcDynEnableAbi, MCfunc **stubFunc);
CUresult memcheckLoadGlobalLDSTStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, uint64_t patchPC,
                                    CCIRinstOpcodes instType, bool mcDynEnableAbi, MCfunc **stubFunc);
CUresult memcheckLoadSharedLDSTStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, uint64_t patchPC,
                                    MCfunc **stubFunc);
CUresult memcheckLoadLocalLDSTStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, uint64_t patchPC,
                                   bool mcDynEnableAbi, MCfunc **stubFunc);
#endif
