#include "check_tool_common.h"
#include "memcheck_types.h"
#include "check_core.h"
#include "check_mc_module.h"
#include "check_mc_context.h"
#include "bikernels.h"

CUresult
setSymbolSize(MCcontext *mcctx, CCsymbol *sym)
{
    if (!mcctx || !sym) {
        CU_ERROR_PRINT(("Invalid argument\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (getArchFromSmVer(mcctx->sm_version) < MC_TOOL_MODE_ARCH_SM70) {
        sym->size = CC_SYMBOL_SIZE_64;
    } else {
        sym->size = CC_SYMBOL_SIZE_128;
    }

    return CUDA_SUCCESS;
}

CUresult
assignInstSymbol(MCcontext *mcctx, CCsymbol *sym, uint64_t *inst)
{
    CUresult res;

    if (!mcctx || !sym || !inst) {
        CU_ERROR_PRINT(("Invalid argument\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    res = setSymbolSize(mcctx, sym);
    if (res != CUDA_SUCCESS)
        return res;

    if (sym->size == CC_SYMBOL_SIZE_64) {
        sym->val  = inst[0];
    } else {
        sym->vals[0] = inst[0];
        sym->vals[1] = inst[1];
    }

    return CUDA_SUCCESS;
}

CUresult
loadModuleFromCubin(MCmod **pmod,
                    MCcontext *mcctx,
                    const BIKernel *bikernel,
                    CCsymbol *relsymbols,
                    uint32_t numsym)
{
    return loadModuleFromCubinCommon(pmod,
                                     mcctx,
                                     bikernel,
                                     relsymbols, 
                                     numsym,
                                     true, // bypass debugger
                                     false); // bypass trampoline
}

CUresult
loadModuleFromCubinCommon(MCmod **pmod,
                          MCcontext *mcctx,
                          const BIKernel *bikernel,
                          CCsymbol *relsymbols,
                          uint32_t numsym,
                          bool bypassDebugger,
                          bool bypassTrampoline)
{
    CUmoduleLoadOptions loadOptions = {0};
    CUresult res = CUDA_SUCCESS;
    CUfunc *func = NULL;
    CCsymbol *sym = NULL;
    CUjitCompileData jitData = {{0}};
    uint32_t i;
    CUmod *cumod = NULL;
    void *code = NULL;
    size_t code_sz = 0;
    unsigned char *funcCodePtr = NULL;

    loadOptions.isInternal = NV_TRUE;
    loadOptions.visibility = CU_MOD_VISIBILITY_HIDDEN_TOOLS;
    loadOptions.relocOptions.allowUnresolvedExterns = NV_TRUE;
    loadOptions.bypassDebugger = bypassDebugger ? NV_TRUE : NV_FALSE;
    loadOptions.bypassTrampoline = bypassTrampoline ? NV_TRUE : NV_FALSE;

    code = (void*)cuiGetBIKCubin(bikernel,
                                 mcctx->sm_version / 100,
                                 mcctx->sm_version % 100);
    if (!code) {
        CU_ERROR_PRINT(("Failed to find BIK cubin\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    code_sz = cuiGetBIKCubinSize(bikernel,
                                 mcctx->sm_version / 100,
                                 mcctx->sm_version % 100);

    if (!code_sz) {
        CU_ERROR_PRINT(("Failed to find BIK cubin size\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    cuiCtxLock(mcctx->cuctx);
    res = cuiModuleLoadDataEx(mcctx->cuctx, &cumod, code, NULL, &jitData, &loadOptions, CUI_API_CUDA);
    cuiCtxUnlock(mcctx->cuctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load module\n"));
        return res;
    }

    func = cumod->pFuncList;
    for (; func; func = func->next) {
        res = cuiFuncDuplicateBinaries(func);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to duplicate function binaries\n"));
            return res;
        }
        if (relsymbols) {
            /* apply symbol relocs */
            for (i = 0; i < numsym; ++i) {
                NvU64 patchVal[2] = {0};
                NvU32 numVals = 1;
                NvU32 j;

                sym = &relsymbols[i];

                /* skip unnamed symbols */
                if (!sym->name)
                    continue;

                if (sym->size == CC_SYMBOL_SIZE_128)
                    numVals = 2;

                for (j = 0; j < numVals; ++j)
                    patchVal[j] = sym->vals[j];

                switch (sym->type) {
                /* apply mask(s) to symbol values before patching */
                case CC_SYMBOL_TYPE_MASKED: {
                        uint64_t offset;

                        res = cuiFuncGetExternRelocOffset(func, sym->name, (NvU64*)&offset);
                        if (res != CUDA_SUCCESS) {
                            CU_DEBUG_PRINT(("Failed to get reloc offset for :%s in func:%s\n",
                                            sym->name, func->name));
                            continue;
                        }
                        funcCodePtr = cuiFuncGetCodeData(func, CU_CODE_DATA_MASTER);

                        for (j = 0; j < numVals; ++j) {
                            uint64_t inst;
                            memcpy(&inst, (void*)(funcCodePtr + offset + (j * sizeof(inst))), sizeof(inst));
                            patchVal[j] = (inst & (~sym->masks[j])) | ((sym->val) & sym->masks[j]);
                        }
                    }
                    break;

                /* replace patch value with launch pc */
                case CC_SYMBOL_TYPE_SELF_PC:
                    if (sym->size != CC_SYMBOL_SIZE_64) {
                        CU_ERROR_PRINT(("Symbol type SELF_PC requires 64bit symbol\n"));
                        return CUDA_ERROR_UNKNOWN;
                    }

                    res = cuiFuncGetLaunchPc(func, (NvU64*)&(patchVal[0]));
                    if (res != CUDA_SUCCESS) {
                        CU_DEBUG_PRINT(("Failed to get launch PC for func:%s\n", func->name));
                        continue;
                    }
                    break;

                /* nothing to do here */
                default:
                    break;
                }

                /* patch this symbol */
                res = cuiFuncPatchExternEx(func, sym->name, patchVal, numVals);
                if (res != CUDA_SUCCESS) {
                    CU_ERROR_PRINT(("Failed when patching reloc for %s with 0x%" PRIx64 ".%" PRIx64 " in func:%s\n",
                                    sym->name, patchVal[0], patchVal[1], func->name));
                    return res;
                }
            }
        }

        res = cuiFuncDownload(mcctx->cuctx, func);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to download func:%s\n", func->name));
            return res;
        }

#ifndef RELEASE
        if (mcctx->gvars->options.printCubins) {
            // Dump the cubins
            FILE *f;
            char name[2048];
            NvU64 launchPc;

            (void)cuiFuncGetLaunchPc(func, &launchPc);
            snprintf(name, sizeof(name), "%s.0x%08x.%p.cubin",
                     func->name,
                     (uint32_t)launchPc,
                     func);
            f = fopen(name, "w");
            fwrite((void*)cuiFuncGetCodeData(func, CU_CODE_DATA_MASTER), (size_t)func->codeSize, 1, f);
            fflush(f);
            fclose(f);
        }
#endif
    }

    res = mcModuleCreate(mcctx, cumod, pmod, code, code_sz);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to create memcheck module\n"));
        return res;
    }

    res = mcContextAddModule(mcctx, *pmod);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to add module to context\n"));
        return res;
    }

    return CUDA_SUCCESS;
}
