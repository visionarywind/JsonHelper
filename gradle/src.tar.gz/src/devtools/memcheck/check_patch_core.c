/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */
/******************************************************************************
 *
 *   Module: check_patch_core.c
 *
 *   Description:
 *       Handling of core patching related behavior, such as scoping
 *       and state management
 *
 ******************************************************************************/
#include "memcheck_types.h"
#include "check_core.h"
#include "tools_shared.h"
#include "check_patch_core.h"
#include "check_mc_context.h"
#include "check_mc_module.h"

#include "tools_shared_hashmap.h"

typedef struct scopeUnitCallbackFunctorData_st scopeUnitCallbackFunctorData;
typedef struct scopeScanData_st scopeScanData;
typedef struct scopeScanGlobalData_st scopeScanGlobalData;

struct scopeUnitCallbackFunctorData_st {
    MCcontext *mcctx;
    MCfunc *start;
    MCscopeCBFunc cbfunc;
    void *user_data;
    CUresult res;
};

struct scopeScanGlobalData_st {
    CUresult        res;
    CCpatchScopeMgr *scopeMgr;
    MCfunc          *func;
    CCpatchScope    *parent;
    tHashMap        *visitedScopes;
};

struct scopeScanData_st {
    scopeScanGlobalData *glob;
    tHashMap       *nextScopes;
    tHashMap       *clonedUnits;
    uint32_t        nextScopesSize;
};


static CUresult
createScopeUnit(MCfunc *func, CCpatchScopeUnit **scopeUnit)
{
    CCpatchScopeUnit *unit = NULL;

    if (!scopeUnit || !func)
        return CUDA_ERROR_UNKNOWN;

    *scopeUnit = unit;

    unit = (CCpatchScopeUnit *)calloc(1, sizeof(*unit));
    if (!unit)
        return CUDA_ERROR_OUT_OF_MEMORY;

    unit->func = func;

    *scopeUnit = unit;

    return CUDA_SUCCESS;
}

static CUresult
destroyScopeUnit(CCpatchScopeUnit *scopeUnit)
{
    if (!scopeUnit)
        return CUDA_ERROR_UNKNOWN;

    free(scopeUnit);
    scopeUnit = NULL;

    return CUDA_SUCCESS;
}

static CCpatchScopeUnit*
findUnitInScope(CCpatchScope *scope, MCfunc *func)
{
    CCpatchScopeUnit *unit = NULL;

    if (!scope || !func)
        return NULL;

    unit = (CCpatchScopeUnit*)toolsHashMapFind(scope->unitMap, tHashMapPtrToKey(func));

    return unit;
}

static CUresult
addUnitToScope(CCpatchScope *scope, MCfunc *func)
{
    CCpatchScopeUnit *unit = NULL;
    CUresult res = CUDA_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;

    if (!scope || !func)
        return CUDA_ERROR_UNKNOWN;

    unit = findUnitInScope(scope, func);
    if (unit)
        return CUDA_SUCCESS;

    res = createScopeUnit(func, &unit);
    if (res != CUDA_SUCCESS)
        return res;

    tres = toolsHashMapInsert(scope->unitMap, tHashMapPtrToKey(func), (void*)(unit));
    if (tres != TOOLS_SUCCESS)
        res = CUDA_ERROR_UNKNOWN;

    return res;
}

static CUresult
removeUnitFromScope(CCpatchScope *scope, MCfunc *func)
{
    CCpatchScopeUnit *unit = NULL;

    if (!scope || !func)
        return CUDA_ERROR_UNKNOWN;

    unit = findUnitInScope(scope, func);
    if (!unit)
        return CUDA_ERROR_UNKNOWN;

    toolsHashMapRemove(scope->unitMap, tHashMapPtrToKey(func), NULL);

    return destroyScopeUnit(unit);
}

static CUresult
createScope(CCpatchScopeMgr *mgr, CCpatchScope **patchScope)
{
    CCpatchScope *scope = NULL;

    CU_TRACE_FUNCTION();

    if (!mgr || !patchScope)
        return CUDA_ERROR_UNKNOWN;

    *patchScope = scope;

    scope = (CCpatchScope *)calloc(1, sizeof(*scope));
    if (!scope)
        return CUDA_ERROR_UNKNOWN;

    scope->type = CC_PATCH_SCOPE_NONE;
    scope->mgr = mgr;
    scope->refCount = 0;

    scope->unitMap = toolsHashMapNew(toolsPointerHashFun, toolsPointerEqualFun, 17);
    if (!scope->unitMap) {
        free(scope);
        return CUDA_ERROR_UNKNOWN;
    }

    *patchScope = scope;

    return CUDA_SUCCESS;
}

static void
destroyScopeUnitFunctor(void *value, void *functor_data)
{
    CUresult res = CUDA_SUCCESS;

    res = destroyScopeUnit((CCpatchScopeUnit*)value);
    if (res != CUDA_SUCCESS)
        CU_ERROR_PRINT(("Failed to destroy scope unit\n"));
}

static CUresult
destroyScope(CCpatchScope *scope)
{
    CUresult res = CUDA_SUCCESS;

    if (!scope)
        return CUDA_ERROR_UNKNOWN;

    if (scope->refCount > 1) {
        --scope->refCount;
        return CUDA_SUCCESS;
    }

    toolsHashMapDelete(scope->unitMap, destroyScopeUnitFunctor, NULL);
    scope->unitMap = NULL;

    free(scope);

    return res;
}

CUresult
initializeScopeManager(MCcontext *mcctx)
{
    CCpatchScopeMgr *mgr = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid argument\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (mcctx->scopeMgr) {
        CU_TRACE_PRINT(("Using existing scope manager\n"));
        return CUDA_SUCCESS;
    }

    mgr = (CCpatchScopeMgr *)calloc(1, sizeof(*mgr));
    if (!mgr) {
        CU_ERROR_PRINT(("Failed to allocate scope manager\n"));
        return CUDA_ERROR_OUT_OF_MEMORY;
    }

    mgr->funcMap = toolsHashMapNew(toolsPointerHashFun, toolsPointerEqualFun, 17);
    if (!mgr->funcMap) {
        CU_ERROR_PRINT(("Failed to allocate funcmap\n"));
        goto error;
    }

    mgr->state = CC_PATCH_SCOPE_MANAGER_READY;

    mcCtxLock(mcctx);
    mcctx->scopeMgr = mgr;
    mcCtxUnlock(mcctx);

    return CUDA_SUCCESS;

error:
    if (mgr->funcMap) {
        toolsHashMapDelete(mgr->funcMap, NULL, NULL);
        mgr->funcMap = NULL;
    }
    free(mgr);
    mcctx->scopeMgr = NULL;
    return CUDA_ERROR_UNKNOWN;
}

static void
deleteScopeFunctor(void *value, void *functor_data)
{
    (void)destroyScope((CCpatchScope*)value);
}

CUresult
finalizeScopeManager(MCcontext *mcctx)
{
    CCpatchScopeMgr *mgr = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !mcctx->scopeMgr)
        return CUDA_SUCCESS;

    mgr = mcctx->scopeMgr;

    mcCtxLock(mcctx);
    mcctx->scopeMgr = NULL;
    mcCtxUnlock(mcctx);

    toolsHashMapDelete(mgr->funcMap, deleteScopeFunctor, NULL);
    free(mgr);

    return CUDA_SUCCESS;
}

static CCpatchScope*
getFuncScope(CCpatchScopeMgr *mgr, MCfunc *func)
{
    CCpatchScope *scope = NULL;

    if (!mgr || !func)
        return NULL;

    scope = (CCpatchScope *)toolsHashMapFind(mgr->funcMap, tHashMapPtrToKey(func));

    return scope;
}

static CUresult
addScope(CCpatchScopeMgr *mgr, MCfunc *func, CCpatchScope *scope)
{
    if (!mgr || !func || !func || !scope)
        return CUDA_ERROR_UNKNOWN;

    toolsHashMapInsert(mgr->funcMap, tHashMapPtrToKey(func), (void*)(scope));
    ++scope->refCount;

    return CUDA_SUCCESS;
}

static CUresult
removeScope(CCpatchScopeMgr *mgr, MCfunc *func, CCpatchScope **delScope)
{
    CCpatchScope *scope = NULL;

    if (!mgr || !func)
        return CUDA_ERROR_UNKNOWN;

    scope = (CCpatchScope *)toolsHashMapFind(mgr->funcMap, tHashMapPtrToKey(func));

    if (!scope)
        return CUDA_SUCCESS;

    toolsHashMapRemove(mgr->funcMap, tHashMapPtrToKey(func), NULL);

    --scope->refCount;

    if (delScope)
        *delScope = scope;


    return CUDA_SUCCESS;
}

static CUresult
default_preLoop(MCmod *mod, CCpatchScopeMgr *mgr, void **cbData)
{
    return CUDA_SUCCESS;
}

static CUresult
default_postLoop(MCmod *mod, CCpatchScopeMgr *mgr, void **cbData)
{
    return CUDA_SUCCESS;
}

#ifndef RELEASE

static void
dumpScopeUnits(CCpatchScopeUnit *unit)
{
    if (!unit)
        return;

    CU_TRACE_PRINT(("\t FUNC: %s\n", unit->func->funcName));
}

static TOOLSresult
dumpScopeUnitsFunctor(tHashMapKey_t key, void *value, void *functor_data)
{
    dumpScopeUnits((CCpatchScopeUnit*)value);
    return TOOLS_SUCCESS;
}

static void
dumpScope(CCpatchScope *scope)
{
    const char *type;

    if (!scope)
        return;

    switch (scope->type) {
    case CC_PATCH_SCOPE_MODULE :
        type = "MODULE";
        break;
    case CC_PATCH_SCOPE_PER_KERNEL:
        type = "PER KERNEL";
        break;
    case CC_PATCH_SCOPE_CALLGRAPH:
        type = "CALLGRAPH";
        break;
    default:
        type = "UNKNOWN";
    };

    CU_TRACE_PRINT(("Scope start: Type:%s (%u)\n", type, scope->type));
    (void)type;
    toolsHashMapApplyFunctor(scope->unitMap, dumpScopeUnitsFunctor, NULL);
}

static TOOLSresult
dumpScopeFunctor(tHashMapKey_t key, void *value, void *functor_data)
{
    dumpScope((CCpatchScope*)value);
    return TOOLS_SUCCESS;
}

static CUresult
dump_postLoop(MCmod *mod, CCpatchScopeMgr *mgr, void **cbData)
{
    if (!mod || !mgr)
        return CUDA_ERROR_UNKNOWN;

    toolsHashMapApplyFunctor(mgr->funcMap, dumpScopeFunctor, NULL);

    return CUDA_SUCCESS;
}
#endif

static CUresult
perKernel_functorGetScope(CCpatchScopeMgr *mgr, MCfunc *func, CCpatchScope **pScope, void **cbData)
{
    CUresult res = CUDA_SUCCESS;
    CCpatchScope *scope = NULL;

    CU_TRACE_FUNCTION();

    if (!mgr || !func || !pScope) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    res = createScope(mgr, &scope);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Faileed to create scope\n"));
        return res;
    }

    scope->type = CC_PATCH_SCOPE_PER_KERNEL;
    scope->cases.kernel = func;

    *pScope = scope;

    return CUDA_SUCCESS;
}

static CUresult
module_preLoop(MCmod *mod, CCpatchScopeMgr *mgr, void **data)
{
    CUresult res = CUDA_SUCCESS;
    CCpatchScope *module_scope = NULL;

    if (!mod || !mgr || !data) {
        CU_ERROR_PRINT(("Invalid Arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    res = createScope(mgr, &module_scope);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to create module scope\n"));
    }

    module_scope->type = CC_PATCH_SCOPE_MODULE;
    module_scope->cases.module = mod;

    *data = module_scope;

    return CUDA_SUCCESS;
}

static CUresult
module_functorGetScope(CCpatchScopeMgr *mgr, MCfunc *func, CCpatchScope **pScope, void **data)
{
    if (!mgr || !func || !pScope || !data) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!data || !*data) {
        CU_ERROR_PRINT(("Invalid payload. Module scope was not set\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *pScope = (CCpatchScope*)(*data);
    return CUDA_SUCCESS;
}

#define CALLGRAPH_MAX_DEPS 2048
static CUresult
callgraph_functorGetScope(CCpatchScopeMgr *mgr, MCfunc *func, CCpatchScope **pScope, void **data)
{
    CUresult res = CUDA_SUCCESS;
    CCpatchScope *scope = NULL;
    MCfunc *fptr = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;
    char **depFuncNames = NULL;
    uint32_t numDeps = 0, i;
    uint32_t instSize = 0;

    if (!mgr || !func || !pScope) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    depFuncNames = (char **)calloc(CALLGRAPH_MAX_DEPS, sizeof(*depFuncNames));
    if (!depFuncNames) {
        CU_ERROR_PRINT(("Failed to allocate space for dep func names\n"));
        return CUDA_ERROR_OUT_OF_MEMORY;
    }

    instSize = func->context->hal.getInstSize();

    // 1. Generate callgraph
    if (isELF64((const char *)func->mod->image)) {
        tres = toolsElf64GetRelatedFuncs(func->mod->image,
                                         func->funcName,
                                         func->numIndirectCalls,
                                         depFuncNames,
                                         CALLGRAPH_MAX_DEPS,
                                         &numDeps,
                                         (toolsDirectInstTestFun)func->context->hal.isDirectCall,
                                         instSize);
    }
    else {
        tres = toolsElf32GetRelatedFuncs(func->mod->image,
                                         func->funcName,
                                         func->numIndirectCalls,
                                         depFuncNames,
                                         CALLGRAPH_MAX_DEPS,
                                         &numDeps,
                                         (toolsDirectInstTestFun)func->context->hal.isDirectCall,
                                         instSize);
    }

    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to get related funcs. Error code %d\n", tres));
        res = CUDA_ERROR_UNKNOWN;
        goto error;
    }

    // 2. Create scope
    res = createScope(mgr, &scope);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to create scope. Error code %d\n", res));
        goto error;
    }
    scope->type = CC_PATCH_SCOPE_CALLGRAPH;

    // 3. Iterate over all dependent functions
    // adding unitsToScope (dont add self) as
    // that will happen later
    for (i = 0; i < numDeps; ++i) {
        fptr = mcModuleGetFuncByName(func->mod, depFuncNames[i]);
        if (!fptr || fptr == func)
            continue;

        res = addUnitToScope(scope, fptr);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed in pre populating scope. Error code %d\n", res));
            goto error;
        }
    }

    if (depFuncNames)
        free(depFuncNames);

    *pScope = scope;

    return CUDA_SUCCESS;

error :
    CU_ERROR_PRINT(("Failed in creating callgraph scope\n"));

    if (scope) {
        destroyScope(scope);
        scope = NULL;
    }

    if (depFuncNames)
        free(depFuncNames);

    return res;
}

static CUresult
addVisitedScopeUnit(CCpatchScopeUnit *unit, scopeScanData *data)
{
    CUresult res = CUDA_SUCCESS;
    CCpatchScope *scope = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;

    if (!unit || !data) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    scope = getFuncScope(data->glob->scopeMgr, unit->func);
    if (!scope) {
        CU_ERROR_PRINT(("Failed to get scope\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!toolsHashMapFind(data->glob->visitedScopes, tHashMapPtrToKey(scope))) {
        if (scope != data->glob->parent) {
            res = addUnitToScope(data->glob->parent, unit->func);
            if (res != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Failed to add scope : %s \n", unit->func->funcName));
                return res;
            }
        }

        tres = toolsHashMapInsert(data->nextScopes,
                                  tHashMapPtrToKey(unit->func),
                                  (void*)(scope));
        if (tres != TOOLS_SUCCESS) {
            CU_ERROR_PRINT(("Failed to add function : %s to next scope\n",
                            unit->func->funcName));
            return CUDA_ERROR_UNKNOWN;
        }

        ++data->nextScopesSize;
    }

    return CUDA_SUCCESS;
}

static TOOLSresult
addVisitedScopeUnitFunctor(tHashMapKey_t key, void *value, void *functor_data)
{
    CUresult res = CUDA_SUCCESS;
    scopeScanData *data = NULL;

    data = (scopeScanData*)functor_data;
    if (!data)
        return TOOLS_ERROR_INVALID_VALUE;

    res = addVisitedScopeUnit((CCpatchScopeUnit*)value, data);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed in functor when at scope unit\n"));
        data->glob->res = res;
        return TOOLS_ERROR_UNKNOWN;
    }

    return TOOLS_SUCCESS;
}

static CUresult
scopeClosure(CCpatchScope *scope, scopeScanGlobalData *glob);

static TOOLSresult
scopeClosureFunctor(tHashMapKey_t key, void *value, void *functor_data)
{
    CUresult res = CUDA_SUCCESS;
    scopeScanGlobalData *data = (scopeScanGlobalData*)functor_data;

    if (!data)
        return TOOLS_ERROR_INVALID_VALUE;

    res = scopeClosure((CCpatchScope*)value, data);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed in scope functor\n"));
        data->res = res;
        /* Return unknown error */
        return TOOLS_ERROR_UNKNOWN;
    }
    return TOOLS_SUCCESS;
}

static CUresult
cloneScopeUnit(CCpatchScopeUnit *unit, scopeScanData *data)
{
    TOOLSresult tres = TOOLS_SUCCESS;

    if (!unit || !data)
        return CUDA_ERROR_UNKNOWN;

    tres = toolsHashMapInsert(data->clonedUnits, tHashMapPtrToKey(unit), (void*)(unit));
    if (tres != TOOLS_SUCCESS)
        return CUDA_ERROR_UNKNOWN;

    return CUDA_SUCCESS;
}

static TOOLSresult
cloneScopeUnitFunctor(tHashMapKey_t key, void *value, void *functor_data)
{
    CUresult res = CUDA_SUCCESS;
    scopeScanData *data = (scopeScanData*)functor_data;

    if (!data)
        return TOOLS_ERROR_INVALID_VALUE;

    res = cloneScopeUnit((CCpatchScopeUnit*)value, data);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed in scope functor\n"));
        data->glob->res = res;
        return TOOLS_ERROR_UNKNOWN;
    }

    return TOOLS_SUCCESS;
}

static CUresult
scopeClosure(CCpatchScope *scope, scopeScanGlobalData *glob)
{
    scopeScanData data = {0};
    CUresult res = CUDA_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;

    if (!scope || !glob) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Setup the local data
    data.glob = glob;
    data.nextScopesSize = 0;
    data.nextScopes = toolsHashMapNew(toolsPointerHashFun, toolsPointerEqualFun, 17);
    if (!data.nextScopes) {
        CU_ERROR_PRINT(("Failed to allocate next scopes\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    data.clonedUnits = toolsHashMapNew(toolsPointerHashFun, toolsPointerEqualFun, 17);
    if (!data.clonedUnits) {
        CU_ERROR_PRINT(("Failed to allocate cloned units\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Add this scope to the seen scope list
    if (!toolsHashMapFind(data.glob->visitedScopes, tHashMapPtrToKey(scope))) {
        tres = toolsHashMapInsert(data.glob->visitedScopes, tHashMapPtrToKey(scope),
                                  (void*)(scope));
        if (tres != TOOLS_SUCCESS)
            return CUDA_ERROR_UNKNOWN;
    }

    // Duplicate the unitmap into a local hash map
    // Note, this hash map is actually a set (i.e. key = value)
    // This is slightly wasteful, but is required to prevent the driver's
    // locking mechanism from interfering
    tres = toolsHashMapApplyFunctor(scope->unitMap, cloneScopeUnitFunctor, &data);
    res = data.glob->res;
    if (tres != TOOLS_SUCCESS || res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to clone unit list\n"));
        return res;
    }

    // Iterate over the units, adding them to the hash. At the same
    // time, for every scope unit, get its scope and if its not seen
    // add it to the nextScope map
    tres = toolsHashMapApplyFunctor(data.clonedUnits, addVisitedScopeUnitFunctor, &data);
    res = data.glob->res;
    if (tres != TOOLS_SUCCESS || res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to add visited scope units \n"));
        return res;
    }

    // Iterate over the new scopes
    tres = toolsHashMapApplyFunctor(data.nextScopes, scopeClosureFunctor, glob);
    res = data.glob->res;
    if (tres != TOOLS_SUCCESS || res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to generate scopes from a scope unit\n"));
        return res;
    }

    // Destroy the local hash map
    toolsHashMapDelete(data.nextScopes, NULL, NULL);
    toolsHashMapDelete(data.clonedUnits, NULL, NULL);

    return res;
}

static CUresult
genScopeClosure(CCpatchScopeMgr* scopeMgr, MCfunc *func, CCpatchScope *parent)
{
    CUresult res = CUDA_SUCCESS;
    scopeScanGlobalData glob = {(CUresult)0};

    if (!scopeMgr || !func || !parent) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    glob.scopeMgr = scopeMgr;
    glob.func = func;
    glob.parent = parent;
    glob.visitedScopes = toolsHashMapNew(toolsPointerHashFun, toolsPointerEqualFun, 17);
    if (!glob.visitedScopes) {
        CU_ERROR_PRINT(("Failed to create visit hash\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    res = scopeClosure(parent, &glob);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed in outer scopeClosure\n"));
        return res;
    }

    toolsHashMapDelete(glob.visitedScopes, NULL, NULL);

    return res;
}

static CUresult
callgraph_postLoop(MCmod *mod, CCpatchScopeMgr *mgr, void **cbData)
{
    CUresult res = CUDA_SUCCESS;
    CCpatchScope *scope = NULL;
    MCfunc *fptr = NULL;

    if (!mgr || !mod) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    for (fptr = mod->funcList; fptr; fptr = fptr->next) {
        // Iterate over every scope unit doing the final transitive closure
        scope = getFuncScope(mod->context->scopeMgr, fptr);
        if (!scope) {
            CU_ERROR_PRINT(("Failed to find scope for %s\n", fptr->funcName));
            return CUDA_ERROR_UNKNOWN;
        }

        // Perform the full closure for just this scope
        res = genScopeClosure(mod->context->scopeMgr, fptr, scope);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to generate scope for %s\n", fptr->funcName));
            return res;
        }
    }

#ifndef RELEASE
    res = dump_postLoop(mod, mgr, cbData);
#endif

    return res;
}

static CUresult
getScopeCallbacks(CCpatchScopeTypes type, CCpatchScopeCallbacks *cb)
{
    if (!cb) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    switch (type) {
    case CC_PATCH_SCOPE_PER_KERNEL:
        cb->preLoop = default_preLoop;
        cb->functorGetScope = perKernel_functorGetScope;
        cb->postLoop = default_postLoop;
#ifndef RELEASE
        cb->postLoop = dump_postLoop;
#endif
        break;
    case CC_PATCH_SCOPE_MODULE:
        cb->preLoop = module_preLoop;
        cb->functorGetScope = module_functorGetScope;
        cb->postLoop = default_postLoop;
#ifndef RELEASE
        cb->postLoop = dump_postLoop;
#endif
        break;
    case CC_PATCH_SCOPE_CALLGRAPH:
        cb->preLoop = default_preLoop;
        cb->functorGetScope = callgraph_functorGetScope;
        cb->postLoop = callgraph_postLoop;
        break;
    case CC_PATCH_SCOPE_NONE:
        break;
    default:
        CU_ERROR_PRINT(("Unknown scope type:%u\n", type));
        return CUDA_ERROR_UNKNOWN;
    };
    return CUDA_SUCCESS;
}


CUresult
generateModuleScopes(MCcontext *mcctx, MCmod *mod)
{
    CUresult res = CUDA_SUCCESS;
    CCpatchScope *scope = NULL;
    CCpatchScopeTypes scopetype = CC_PATCH_SCOPE_NONE;
    MCfunc *fptr = NULL;
    CCpatchScopeCallbacks cb = {0};
    void *cbData = NULL;

    CU_TRACE_FUNCTION();

    if (!mod || !mcctx) {
        CU_ERROR_PRINT(("Invalid args \n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!mcctx->scopeMgr) {
        CU_ERROR_PRINT(("Scope manager is not ready\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // After this point, we need to grab the context lock
    mcCtxLock(mcctx);

    scopetype = mod->modOpts.defaultScope;

    // Get the callbacks for a given scope type
    res = getScopeCallbacks(scopetype, &cb);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to get scope callbacks\n"));
        goto scope_done;
    }

    if (!cb.functorGetScope) {
        CU_TRACE_PRINT(("No scope callbacks. Early exit\n"));
        goto scope_done;
    }

    // Do the preloop callback.
    res = cb.preLoop(mod, mcctx->scopeMgr, &cbData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to do pre loop work\n"));
        goto scope_done;
    }

    for (fptr = mod->funcList; fptr; fptr = fptr->next) {

        // For each entry, do the scope callback. This callback
        // will get the scope that should be associated to this entry.
        // For module scoping, this will return the module scope
        // For per kernel scoping, this will create a scope object for this entry
        // TODO : For separate compilation, a scope will be returned only for
        //        a new entry.
        res = cb.functorGetScope(mcctx->scopeMgr, fptr, &scope, &cbData);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed in functor for %s\n", fptr->funcName));
            goto scope_done;
        }

        // Continue to next element if no scope found
        if (scope == NULL) {
            CU_TRACE_PRINT(("Functor returned a NULL SCOPE for this function.Skipping\n"));
            continue;
        }

        // This function is always a part of the scope list for itself
        res = addUnitToScope(scope, fptr);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed in pre populating scope\n"));
            goto scope_done;
        }

        // Push the scope relationship and increment the scope reference count
        res = addScope(mcctx->scopeMgr, fptr, scope);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to add scope\n"));
            goto scope_done;
        }
    }

    // Do the post loop finalization
    res = cb.postLoop(mod, mcctx->scopeMgr, &cbData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failure in post loop\n"));
        goto scope_done;
    }

    CU_TRACE_PRINT(("Scope generation done for module\n"));

scope_done:
    mcCtxUnlock(mcctx);
    return res;
}

static TOOLSresult
scopeUnitCallbackFunctor(tHashMapKey_t key, void *value, void *functor_data)
{
    CCpatchScopeUnit *unit = NULL;
    scopeUnitCallbackFunctorData *data = NULL;
    CUresult res = CUDA_SUCCESS;

    unit = (CCpatchScopeUnit*)value;
    data = (scopeUnitCallbackFunctorData*)functor_data;

    if (!unit || !data)
        return TOOLS_ERROR_INVALID_VALUE;

    res = (*data->cbfunc)(data->mcctx, data->start, unit->func, data->user_data);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Error in callback for unit :%s\n", unit->func->funcName));
        data->res = res;
        return TOOLS_ERROR_UNKNOWN;
    }

    return TOOLS_SUCCESS;
}

CUresult
scopeFunctor(MCcontext *mcctx, MCfunc *start, MCscopeCBFunc cbfunc, void *data)
{
    CCpatchScope *scope = NULL;
    CUresult res = CUDA_SUCCESS;
    scopeUnitCallbackFunctorData cbdata = {0};
    TOOLSresult tres = TOOLS_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!mcctx || !start || !cbfunc) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    scope = getFuncScope(mcctx->scopeMgr, start);

    cbdata.start = start;
    cbdata.cbfunc = cbfunc;
    cbdata.user_data = data;
    cbdata.mcctx = mcctx;
    cbdata.res = CUDA_SUCCESS;

    tres = toolsHashMapApplyFunctor(scope->unitMap, scopeUnitCallbackFunctor, &cbdata);
    res = cbdata.res;

    CU_TRACE_PRINT(("Scope functor done\n"));

    /* If there was a functor error, return it */
    if (tres != TOOLS_SUCCESS && res == CUDA_SUCCESS)
        res = CUDA_ERROR_UNKNOWN;

    return res;
}

/* Instruction iterator */
CUresult
instIterate(uint64_t *buf, uint64_t size, CCinstIterCallbacks *cb)
{
    char *start = NULL;
    char *cur = NULL;
    CCinstIterCBState state;
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!buf || !size || !cb) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Reset the state before starting
    memset(&state, 0, sizeof(state));

    start = (char*)buf;
    cur = start;

    // Setup the initial state values
    state.start = buf;
    state.size = size;
    state.cur = buf;
    state.offset = 0;

    // Issue a prologue callback
    if (cb->prologue) {
        state.mode = CC_INST_ITER_MODE_PROLOGUE;
        res = cb->prologue(&state);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Error in prologue callback\n"));
            return res;
        }
    }

    if (cb->perInstruction && cb->isTarget) {
        for (; cur && cur < start + size; cur += sizeof(*state.cur)) {
            state.cur = (uint64_t*)cur;
            state.offset = (uint64_t)(cur - start);
            state.mode = CC_INST_ITER_MODE_NONE;
            state.target = cb->isTarget(*state.cur);
            if (!state.target)
                continue;

            state.mode = CC_INST_ITER_MODE_TARGET;
            res = cb->perInstruction(&state);
            if (res != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Error in instruction callback at : offset :%u\n",
                                state.offset));
                return res;
            }
        }
    }

    // Setup epilogue values
    state.start = buf;
    state.size = size;
    state.cur = (uint64_t*)(start + size);
    state.offset = size;
    state.target = 0;

    if (cb->epilogue) {
        state.mode = CC_INST_ITER_MODE_EPILOGUE;
        res = cb->epilogue(&state);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Error in epilogue callback\n"));
            return res;
        }
    }

    return res;
}

