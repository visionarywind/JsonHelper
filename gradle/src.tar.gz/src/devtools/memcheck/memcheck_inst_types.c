/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "memcheck_inst_types.h"
#include "memcheck.h"
#include "memcheck_types.h"
#include "memcheck_tool_modes.h"
#include "check_patch_core.h"
#include "check_ir.h"

#if NVCFG(GLOBAL_ARCH_FERMI)
#include "memcheck_arch/inc/fermi/fermi_patches.h"
#endif

#if NVCFG(GLOBAL_ARCH_KEPLER)
#include "memcheck_arch/inc/kepler_gk10x/kepler_gk10x_patches.h"
#include "memcheck_arch/inc/kepler_gk11x/kepler_gk11x_patches.h"
#endif

#if NVCFG(GLOBAL_ARCH_MAXWELL)
#include "memcheck_arch/inc/maxwell_gm10x/maxwell_gm10x_patches.h"
#if NVCFG(GLOBAL_GPU_FAMILY_GM20X)
#include "memcheck_arch/inc/maxwell_gm20x/maxwell_gm20x_patches.h"
#endif
#endif

#if NVCFG(GLOBAL_ARCH_PASCAL)
#include "memcheck_arch/inc/pascal_gp10x/pascal_gp10x_patches.h"
#endif

#if NVCFG(GLOBAL_ARCH_VOLTA)
#include "memcheck_arch/inc/volta_gv10x/volta_gv10x_patches.h"
#endif

#if NVCFG(GLOBAL_ARCH_TURING)
#include "memcheck_arch/inc/turing_tu10x/turing_tu10x_patches.h"
#endif

#if NVCFG(GLOBAL_ARCH_AMPERE)
#include "memcheck_arch/inc/ampere_ga10x/ampere_ga10x_patches.h"
#endif

/* MCcheckType Functions  */

static CUresult
checkType_initialize(MCcheckType *checkType)
{
    // Overridden for arch specific
    CU_TRACE_FUNCTION();
    CU_ERROR_PRINT(("Should not be called\n"));
    return CUDA_ERROR_UNKNOWN;
}

static CUresult
checkType_finalize(MCcheckType *checkType)
{
    int32_t i = CCIR_INST_OPCODE_NONE;

    CU_TRACE_FUNCTION();

    if (!checkType) {
        CU_ERROR_PRINT(("Invalid Args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    for (i = CCIR_INST_OPCODE_NONE; i < CCIR_INST_OPCODE_SIZE; ++i) {
        if (!checkType->state.instOps[i])
            continue;

        free(checkType->state.instOps[i]);
        checkType->state.instOps[i] = NULL;
    }

    return CUDA_SUCCESS;
}

static CUresult
checkType_updateState(MCcheckType *checkType, uint32_t enableAbi)
{
    //Overridden on Fermi+
    CU_TRACE_FUNCTION();
    return CUDA_SUCCESS;
}

static uint32_t
checkType_getMinRegs(MCcheckType *checkType)
{
    CU_TRACE_FUNCTION();

    if (!checkType)
        return 0;

    return checkType->state.minRegs;
}

static uint32_t
checkType_getMinLmem(MCcheckType *checkType)
{
    CU_TRACE_FUNCTION();

    if (!checkType)
        return 0;

    return checkType->state.minLmem;
}

static CCIRinstOpcodes
checkType_isInstructionTarget(MCcheckType *checkType, const uint64_t *op)
{
    int32_t i = CCIR_INST_OPCODE_NONE;

    if (!checkType)
        return CCIR_INST_OPCODE_NONE;

    for (i = CCIR_INST_OPCODE_NONE; i < CCIR_INST_OPCODE_SIZE; ++i) {
        if (!checkType->state.instOps[i])
            continue;

        if (checkType->state.instOps[i]->isInstructionTarget(op)) {
            CU_TRACE_PRINT(("Found target at op:%u\n", i));
            return (CCIRinstOpcodes)i;
        }
    }
    return CCIR_INST_OPCODE_NONE;
}

static CUresult
checkType_updateLaunchConfig(MCcheckType *checkType, CUtoolsFunctionLaunchConfig *config)
{
    uint32_t alignedLmem = 0;

    CU_TRACE_FUNCTION();

    if (!checkType || !config) {
        CU_ERROR_PRINT(("Invalid Arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // A quick check to see if the struct was initialized
    if (!config->struct_size) {
        CU_ERROR_PRINT(("Config struct size not set. Possibly not initialized\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Update the register usage
    if (config->localRegistersPerThread < checkType->state.minRegs)
        config->localRegistersPerThread = checkType->state.minRegs;

    // Update the Lmem usage if needed
    alignedLmem = (uint32_t)((config->lmemLoSize + 3) & ~0x3);
    if (config->lmemLoSize < alignedLmem + checkType->state.minLmem)
        config->lmemLoSize = (uint32_t)(alignedLmem + checkType->state.minLmem);

    // Update the barrier count
    if (config->barrierCount < checkType->state.minBarriers)
        config->barrierCount = checkType->state.minBarriers;

    if (config->totalSharedMemPerBlock < checkType->state.minSharedMem)
        config->dynamicSharedMemPerBlock = checkType->state.minSharedMem;

    return CUDA_SUCCESS;
}

static uint32_t
checkType_getPatchSize(MCcheckType *checkType, MCrec *rec)
{
    // Always overridden
    CU_TRACE_FUNCTION();
    CU_ERROR_PRINT(("Should not be called\n"));
    return 0;
}

static CUresult
checkType_createPatch(MCcheckType *checkType, MCrec *rec)
{
    // Always overridden
    CU_TRACE_FUNCTION();
    CU_ERROR_PRINT(("Should not be called\n"));
    return CUDA_ERROR_UNKNOWN;
}

static CUresult
checkType_parseErrorEntry(MCcheckType *checkType, MCrec *rec,
                          CUmemcheck_record *err, uint32_t *hasError)
{
    // Always Overridden
    CU_TRACE_FUNCTION();
    CU_ERROR_PRINT(("Should not be called\n"));
    return CUDA_ERROR_UNKNOWN;
}

static CUresult
checkType_printCubin(MCcheckType *checkType, char *name, const uint64_t *code, uint64_t size)
{
    if (!checkType)
        return CUDA_ERROR_UNKNOWN;

    return checkType->state.manager->printCubin(checkType->state.manager, name, code, size);
}

static CUresult
checkType_createAllocs(MCcheckType *checkType, MCrec *rec)
{
    // Default, do nothing
    return CUDA_SUCCESS;
}

static CUresult
checkType_destroyAllocs(MCcheckType *checkType, MCrec *rec)
{
    // Default, do nothing
    return CUDA_SUCCESS;
}

static uint64_t*
checkType_genRangeCheck(MCcheckType *checkType, MCrec *rec, uint64_t *patchCode)
{
    // Always Overridden
    CU_TRACE_FUNCTION();
    CU_ERROR_PRINT(("Should not be called\n"));
    return NULL;
}

static uint32_t
checkType_getRangeCheckSize(MCcheckType *checkType, MCrec *rec)
{
    // Always Overridden
    CU_TRACE_FUNCTION();
    CU_ERROR_PRINT(("Should not be called\n"));
    return CUDA_ERROR_UNKNOWN;
}

CUresult
default_initCheckType(MCinstManager *instMgr, MCcheckType *type, MCcheckTypes typeEnum)
{
    CUresult res = CUDA_SUCCESS;
    MCtoolMode *toolMode = NULL;
    MCinstOp *op = NULL;
    int32_t i = CCIR_INST_OPCODE_NONE;

    CU_TRACE_FUNCTION();

    if (!instMgr || !type) {
        CU_ERROR_PRINT(("Invalid Arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    memset(&type->state, 0, sizeof(type->state));
    type->state.manager = instMgr;
    type->state.type = typeEnum;

    // now do a query to get the tool mask
    toolMode = &instMgr->state.mcctx->gvars->toolMode;
    res = toolMode->getOpTypeMask(toolMode, instMgr->state.sm_version,
                                  typeEnum, &type->state.toolOpMask);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("failed to query enabled check type mask\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    type->initialize            =   checkType_initialize;
    type->finalize              =   checkType_finalize;
    type->updateState           =   checkType_updateState;
    type->getMinLmem            =   checkType_getMinLmem;
    type->getMinRegs            =   checkType_getMinRegs;
    type->isInstructionTarget   =   checkType_isInstructionTarget;
    type->getPatchSize          =   checkType_getPatchSize;
    type->createPatch           =   checkType_createPatch;
    type->updateLaunchConfig    =   checkType_updateLaunchConfig;
    type->parseErrorEntry       =   checkType_parseErrorEntry;
    type->printCubin            =   checkType_printCubin;
    type->createAllocs          =   checkType_createAllocs;
    type->destroyAllocs         =   checkType_destroyAllocs;
    /* Memcheck toolmode specific */
    type->tm.mem.genRangeCheck         =   checkType_genRangeCheck;
    type->tm.mem.getRangeCheckSize     =   checkType_getRangeCheckSize;

    // Preinitialize the instOps
    for (i = CCIR_INST_OPCODE_NONE; i < CCIR_INST_OPCODE_SIZE; ++i) {
        type->state.instOps[i] = NULL;
        op = NULL;

        if (!(type->state.toolOpMask & (1U << i)))
            continue;

        op = createInstOp(type, (CCIRinstOpcodes)i);

        if (!op) {
            CU_ERROR_PRINT(("Failed to initialize op:%u\n", i));
            return CUDA_ERROR_UNKNOWN;
        }


        type->state.instOps[i] = op;
    }

    return CUDA_SUCCESS;
}

/* MCinstManager Functions */

static CUresult
instMgr_initialize(MCinstManager *instMgr)
{
    // Overridden by arch specific code
    CU_TRACE_FUNCTION();
    CU_ERROR_PRINT(("Should not be called\n"));
    return CUDA_ERROR_UNKNOWN;
}

static CUresult
instMgr_finalize(MCinstManager *instMgr)
{
    uint32_t i = 0;
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!instMgr)
        return CUDA_SUCCESS;

    for (i = 0; i < MC_CHECK_TYPE_SIZE; ++i) {
        if (instMgr->state.checkTypes[i]) {
            res = instMgr->state.checkTypes[i]->finalize(instMgr->state.checkTypes[i]);
            if (res != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Failed to finalize check type :%u\n", i));
                return res;
            }

            free(instMgr->state.checkTypes[i]);
            instMgr->state.checkTypes[i] = NULL;
        }
    }

    return CUDA_SUCCESS;
}

static uint32_t
instMgr_getMinLmem(MCinstManager *instMgr)
{
    uint32_t maxLmem = 0;
    uint32_t curLmem = 0;
    int32_t i = 0;

    CU_TRACE_FUNCTION();

    if (!instMgr)
        return 0;

    for (i = MC_CHECK_TYPE_NONE; i < MC_CHECK_TYPE_SIZE; ++i) {
        if (!instMgr->state.checkTypes[i])
            continue;

        curLmem = instMgr->state.checkTypes[i]->getMinLmem(instMgr->state.checkTypes[i]);
        if (curLmem > maxLmem)
            maxLmem = curLmem;
    }

    return maxLmem;
}

static uint32_t
instMgr_getMinRegs(MCinstManager *instMgr)
{
    uint32_t maxRegs = 0;
    uint32_t curRegs = 0;
    int32_t i = 0;

    CU_TRACE_FUNCTION();

    if (!instMgr)
        return 0;

    for (i = MC_CHECK_TYPE_NONE; i < MC_CHECK_TYPE_SIZE; ++i) {
        if (!instMgr->state.checkTypes[i])
            continue;

        curRegs = instMgr->state.checkTypes[i]->getMinRegs(instMgr->state.checkTypes[i]);
        if (curRegs > maxRegs)
            maxRegs = curRegs;
    }

    return maxRegs;
}

static uint32_t
instMgr_getPatchSize(MCinstManager *instMgr, MCrec *rec)
{
    uint32_t totalSize = 0;
    int32_t i;

    CU_TRACE_FUNCTION();

    if (!instMgr || !rec)
        return 0;

    for (i = MC_CHECK_TYPE_NONE; i < MC_CHECK_TYPE_SIZE; ++i) {
        if (!instMgr->state.checkTypes[i])
            continue;

        totalSize += instMgr->state.checkTypes[i]->getPatchSize(instMgr->state.checkTypes[i], rec);
    }

    return totalSize;
}

static CUresult
instMgr_updateState(MCinstManager *instMgr, uint32_t enableAbi)
{
    CUresult res = CUDA_SUCCESS;
    int32_t i;

    CU_TRACE_FUNCTION();

    if (!instMgr) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    for (i = MC_CHECK_TYPE_NONE; i < MC_CHECK_TYPE_SIZE; ++i) {
        if (!instMgr->state.checkTypes[i])
            continue;

        res = instMgr->state.checkTypes[i]->updateState(instMgr->state.checkTypes[i], enableAbi);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to create patch for type %u-\n", i));
            return res;
        }
    }
    return res;
}

static CUresult
instMgr_createPatch(MCinstManager *instMgr, MCrec *rec)
{
    CUresult res = CUDA_SUCCESS;
    int32_t i;
    char name[100];
    static int number = 99;

    CU_TRACE_FUNCTION();

    if (!instMgr || !rec)
        return CUDA_ERROR_UNKNOWN;

    if (rec->options.printCubins) {
        ++number;
        snprintf(name, sizeof name, "prepatchfunc-%d.cubin", number);
        instMgr->printCubin(instMgr, name, (const uint64_t *)rec->funcBuffer.host.ptr, rec->funcBuffer.size);
    }

    for (i = MC_CHECK_TYPE_NONE; i < MC_CHECK_TYPE_SIZE; ++i) {
        if (!instMgr->state.checkTypes[i])
            continue;

        res = instMgr->state.checkTypes[i]->createPatch(instMgr->state.checkTypes[i], rec);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to create patch for type %u-\n", i));
            return res;
        }
    }

    if (rec->options.printCubins) {
        snprintf(name, sizeof name, "postpatchfunc-%d.cubin", number);
        instMgr->printCubin(instMgr, name, (const uint64_t *)rec->funcBuffer.host.ptr, rec->funcBuffer.size);
    }

    return res;
}

static CUresult
instMgr_createAllocs(MCinstManager *instMgr, MCrec *rec)
{
    CUresult res = CUDA_SUCCESS;
    int32_t i;
    uint32_t curOffset = 0;

    CU_TRACE_FUNCTION();

    if (!instMgr || !rec)
        return CUDA_ERROR_UNKNOWN;

    // Figure out offsets and sizes
    rec->patchBuffer.size = 0;
    rec->patchBuffer.mcctx = rec->context;

    memset(rec->patchOffsets, 0, sizeof(rec->patchOffsets));
    for (i = MC_CHECK_TYPE_NONE; i < MC_CHECK_TYPE_SIZE; ++i) {
        // patchOffsets[i] is being set for quick size checking
        rec->patchOffsets[i] = curOffset;

        if (!instMgr->state.checkTypes[i])
            continue;

        curOffset += instMgr->state.checkTypes[i]->getPatchSize(instMgr->state.checkTypes[i], rec);
        res = instMgr->state.checkTypes[i]->createAllocs(instMgr->state.checkTypes[i], rec);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed when creating allocs for type :%u\n", i));
            return res;
        }
    }

    // Create the host allocation for the patch
    rec->patchBuffer.size = curOffset;
    if (rec->patchBuffer.size == 0)
        return CUDA_SUCCESS;

    res = CCallocateHost(&rec->patchBuffer);
    return res;
}

static CUresult
instMgr_destroyAllocs(MCinstManager *instMgr, MCrec *rec)
{
    CUresult res = CUDA_SUCCESS;
    int32_t i;

    CU_TRACE_FUNCTION();

    if (!instMgr || !rec)
        return CUDA_ERROR_UNKNOWN;


    for (i = MC_CHECK_TYPE_NONE; i < MC_CHECK_TYPE_SIZE; ++i) {

        if (!instMgr->state.checkTypes[i])
            continue;

        res = instMgr->state.checkTypes[i]->destroyAllocs(instMgr->state.checkTypes[i], rec);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed when creating allocs for type :%u\n", i));
            return res;
        }
    }

    CCfreeHost(&rec->patchBuffer);
    memset(rec->patchOffsets, 0, sizeof(rec->patchOffsets));

    return CUDA_SUCCESS;
}

static uint32_t
instMgr_getErrorEntrySize(MCinstManager *instMgr, MCrec *rec)
{
    CU_TRACE_FUNCTION();

    if (!instMgr || !rec)
        return CUDA_ERROR_UNKNOWN;

    return instMgr->state.errorEntrySize;
}

static CUresult
instMgr_updateLaunchConfig(MCinstManager *instMgr, CUtoolsFunctionLaunchConfig *config)
{
    CUresult res = CUDA_SUCCESS;
    uint32_t origLmemLoSize = 0;
    int32_t i;

    CU_TRACE_FUNCTION();

    if (!instMgr || !config)
        return CUDA_ERROR_UNKNOWN;

    if (!config->struct_size) {
        CU_ERROR_PRINT(("Struct size invalid. Config not loaded ? \n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Cache the original lmem usage and reset it
    origLmemLoSize = config->lmemLoSize;
    config->lmemLoSize = 0;

    for (i = MC_CHECK_TYPE_NONE; i < MC_CHECK_TYPE_SIZE; ++i) {
        if (!instMgr->state.checkTypes[i])
            continue;

        res = instMgr->state.checkTypes[i]->updateLaunchConfig(instMgr->state.checkTypes[i],
                                                               config);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to update launch config for type %u-\n", i));
            return res;
        }
    }

    config->lmemLoSize += origLmemLoSize;

    return res;
}

static CUresult
instMgr_parseErrorEntry(MCinstManager *instMgr, MCrec *rec, CUmemcheck_record *err, uint32_t *hasError)
{
    CUresult res = CUDA_SUCCESS;
    int32_t i;

    CU_TRACE_FUNCTION();

    if (!instMgr || !rec || !err || !hasError)
        return CUDA_ERROR_UNKNOWN;

    *hasError = 0;

    for (i = MC_CHECK_TYPE_NONE; i < MC_CHECK_TYPE_SIZE; ++i) {
        if (!instMgr->state.checkTypes[i])
            continue;

        res = instMgr->state.checkTypes[i]->parseErrorEntry(instMgr->state.checkTypes[i], rec, err, hasError);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to parse error entry for type %u-\n", i));
            return res;
        }

        if (*hasError) {
            CU_TRACE_PRINT(("Found valid error entry for checktype : %i\n"));
            return res;
        }
    }

    return res;
}

static CUresult
instMgr_printCubin(MCinstManager *instMgr, char *name, const uint64_t *code, uint64_t size)
{
#ifndef RELEASE
    FILE *f;
    uint32_t i;
    uint32_t mode = 4;
    uint32_t *u32 = (uint32_t*)code;
    char *c = (char*)code;
    uint64_t *u64 = (uint64_t*)code;
    char arch_line[30];
    uint32_t major = 0, minor = 0;
    static char cubin[] = "abiversion   {1}\n"
                          "cubinversion {1}\n"
                          "modname      {cubin}\n"
                          "texmode      {texmode_unified}\n"
                          "code {\n"
                          "       name = kernel\n"
                          "       lmem = 0\n"
                          "       smem = 24\n"
                          "       reg  = 1\n"
                          "       bar  = 0\n"
                          "       ctaidZUsed  = 0\n"
                          "       params_SMEM {\n"
                          "               0x00000000 0x00000004 \n"
                          "       }\n"
                          "       bincode {\n"
                          ;

    major = instMgr->state.sm_version / 100;
    minor = instMgr->state.sm_version % 100;
    snprintf(arch_line, sizeof(arch_line), "architecture {sm_%1u%1u}\n",
             major, minor);

    f = fopen(name,"w");
    if (!f)
        return CUDA_ERROR_FILE_NOT_FOUND;
    if (mode == 0) {
        fprintf(f,"%s", arch_line);
        fprintf(f,"%s",cubin);
        for (i=0; i < size/sizeof(*u32); i+=2) {
            fprintf(f, "%#.8x %#.8x\n", u32[i], u32[i+1]);
        }
        fprintf(f,"}}\n");
    }
    else if (mode == 1) {
        for (i = 0; i < size/sizeof(*c); ++i) {
            fprintf(f, "0x%x\n", c[i]);
        }
    }
    else if (mode == 2) {
        for (i = 0; i < size/sizeof(*u64); ++i) {
            fprintf(f, "0x%" PRIx64 "\n", u64[i]);
        }
    }
    else if (mode == 3) {
        (void)fwrite((void*)code, (size_t)size, 1, f);
    }
    else if (mode == 4) {
        (void)fwrite((void*)u64, sizeof(*u64), ((size_t)size)/sizeof(*u64), f);
    }
    fclose(f);
#endif

    return CUDA_SUCCESS;
}

CUresult
default_initTypeManager(MCcontext *mcctx, MCinstManager *instMgr)
{
    CUresult res = CUDA_SUCCESS;
    MCtoolMode *toolMode = NULL;
    int32_t i = MC_CHECK_TYPE_NONE;
    MCcheckType *type = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !instMgr) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    memset(&instMgr->state, 0, sizeof(instMgr->state));
    instMgr->state.sm_version   = mcctx->sm_version;
    instMgr->state.mcctx        = mcctx;

    // now do a query to get the tool check type mask
    toolMode = &mcctx->gvars->toolMode;
    res = toolMode->getCheckTypeMask(toolMode, mcctx->sm_version,
                                     &instMgr->state.toolTypeMask);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("failed to query enabled check type mask\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    instMgr->initialize         =   instMgr_initialize;
    instMgr->finalize           =   instMgr_finalize;
    instMgr->getMinLmem         =   instMgr_getMinLmem;
    instMgr->getMinRegs         =   instMgr_getMinRegs;
    instMgr->getPatchSize       =   instMgr_getPatchSize;
    instMgr->updateState        =   instMgr_updateState;
    instMgr->createPatch        =   instMgr_createPatch;
    instMgr->createAllocs       =   instMgr_createAllocs;
    instMgr->destroyAllocs      =   instMgr_destroyAllocs;
    instMgr->getErrorEntrySize  =   instMgr_getErrorEntrySize;
    instMgr->updateLaunchConfig =   instMgr_updateLaunchConfig;
    instMgr->parseErrorEntry    =   instMgr_parseErrorEntry;
    instMgr->printCubin         =   instMgr_printCubin;

    // Pre initialize all check types to their defaults
    for (i = MC_CHECK_TYPE_NONE; i < MC_CHECK_TYPE_SIZE; ++i) {
        // Clear out the type pointer
        type = NULL;
        instMgr->state.checkTypes[i] = NULL;

        // Ignore patches that are not marked
        if (!(instMgr->state.toolTypeMask & (1U << i)))
            continue;

        type = (MCcheckType *)calloc(1, sizeof(*type));
        if (!type)
            return CUDA_ERROR_UNKNOWN;

        // Setup defaults
        res = default_initCheckType(instMgr, type, (MCcheckTypes)i);
        if (res != CUDA_SUCCESS) {
            CU_TRACE_PRINT(("Failed to set defaults for type:%u\n", i));
            free(type);
            return CUDA_ERROR_UNKNOWN;
        }

        instMgr->state.checkTypes[i] = type;
    }

    return CUDA_SUCCESS;
}

CUresult
initializeTypeManager(MCcontext *mcctx, MCinstManager **pInstManager)
{
    CUresult res = CUDA_SUCCESS;
    MCinstManager *instManager = NULL;
    MCtoolModeArchs arch = MC_TOOL_MODE_ARCH_NONE;

    CU_TRACE_FUNCTION();

    if (!mcctx || !pInstManager) {
        CU_ERROR_PRINT(("Bad arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    arch = getArchFromSmVer(mcctx->sm_version);
    if (arch == MC_TOOL_MODE_ARCH_NONE) {
        CU_ERROR_PRINT(("Invalid architecture\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    instManager = (MCinstManager *)calloc(1, sizeof(*instManager));
    if (!instManager) {
        CU_ERROR_PRINT(("Could not allocate manager\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Initialize the defaults, can be overridden
    res = default_initTypeManager(mcctx, instManager);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to initialize defaults for type manager\n"));
        goto error;
    }

    // Do the per arch initialization. These will always
    // override the initialization function with something better
    switch (arch) {
#if NVCFG(GLOBAL_ARCH_KEPLER)
#if NVCFG(GLOBAL_GPU_FAMILY_GK10X)
    case MC_TOOL_MODE_ARCH_SM30:
        res = kepler_gk10x_initTypeManager(mcctx,instManager);
        break;
#endif
#if NVCFG(GLOBAL_GPU_FAMILY_GK11X) || NVCFG(GLOBAL_GPU_FAMILY_GK20X)
    case MC_TOOL_MODE_ARCH_SM35:
        res = kepler_gk11x_initTypeManager(mcctx, instManager);
        break;
#endif
#endif
#if NVCFG(GLOBAL_ARCH_MAXWELL)
    case MC_TOOL_MODE_ARCH_SM50:
        res = maxwell_gm10x_initTypeManager(mcctx, instManager);
        break;
#if NVCFG(GLOBAL_GPU_FAMILY_GM20X)
    case MC_TOOL_MODE_ARCH_SM52:
        res = maxwell_gm20x_initTypeManager(mcctx, instManager);
        break;
#endif
#endif
#if NVCFG(GLOBAL_ARCH_PASCAL)
    case MC_TOOL_MODE_ARCH_SM60:
        res = pascal_gp10x_initTypeManager(mcctx, instManager);
        break;
#endif
#if NVCFG(GLOBAL_ARCH_VOLTA)
    case MC_TOOL_MODE_ARCH_SM70:
        res = volta_gv10x_initTypeManager(mcctx, instManager);
        break;
#endif
#if NVCFG(GLOBAL_ARCH_TURING)
    case MC_TOOL_MODE_ARCH_SM75:
        res = turing_tu10x_initTypeManager(mcctx, instManager);
        break;
#endif
#if NVCFG(GLOBAL_ARCH_AMPERE)
    case MC_TOOL_MODE_ARCH_SM80:
        res = ampere_ga10x_initTypeManager(mcctx, instManager);
        break;
#endif
    default :
        CU_ERROR_PRINT(("Invalid sm version on context : %u\n", mcctx->sm_version));
        res = CUDA_ERROR_UNKNOWN;
    }

    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed bootstrap initialization\n"));
        goto error;
    }

    // Call into the type manager to do the initialization
    res = instManager->initialize(instManager);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed call to initialize\n"));
        goto error;
    }

    *pInstManager = instManager;
    return res;

error:
    free(instManager);
    instManager = NULL;
    *pInstManager = NULL;
    return res;
}

CUresult
finalizeTypeManager(MCcontext *mcctx, MCinstManager **pInstManager)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!mcctx || !pInstManager) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!*pInstManager) {
        CU_TRACE_PRINT(("Already freed instManager\n"));
        return CUDA_SUCCESS;
    }

    res = (*pInstManager)->finalize(*pInstManager);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to finalize instManager\n"));
        return res;
    }
    free(*pInstManager);
    *pInstManager = NULL;

    return CUDA_SUCCESS;
}

MCinstOp*
createInstOp(MCcheckType *checkType, CCIRinstOpcodes instType)
{
    MCcontext *mcctx = NULL;
    MCinstOp *instOp = NULL;

    CU_TRACE_FUNCTION();

    if (!checkType) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return NULL;
    }

    if (instType <= CCIR_INST_OPCODE_NONE || instType >= CCIR_INST_OPCODE_SIZE) {
        CU_ERROR_PRINT(("Invalid inst op type: %u\n", instType));
        return NULL;
    }

    mcctx = checkType->state.manager->state.mcctx;

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid context\n"));
        return NULL;
    }

    instOp = (MCinstOp *)calloc(1, sizeof(*instOp));
    if (!instOp) {
        CU_ERROR_PRINT(("Failed to alloc inst op\n"));
        return NULL;
    }

    instOp->state.checkType = checkType;
    instOp->isInstructionTarget = getInstScanFunction(mcctx, instType);

    if (!instOp->isInstructionTarget)
        CU_TRACE_PRINT(("Unsupported inst op : %u\n", instType));

    return instOp;
}

