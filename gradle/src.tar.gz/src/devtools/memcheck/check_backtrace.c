/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: check_backtrace.c
 *
 *   Description:
 *       Functions for generating and managing a backtrace
 *
 ******************************************************************************/

#include "cuda.h"
#include "cudamemcheck.h"
#include "check_core.h"
#include "check_mc_context.h"
#include "check_backtrace.h"
#include "memcheck_types.h"
#include "tools_shared.h"

/* Handling list of frames */
static CUresult
createFrame(CCBacktraceFrame **pframe)
{
    CCBacktraceFrame *frame = NULL;

    if (!pframe) {
        CU_ERROR_PRINT(("Invalid argument\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *pframe = NULL;

    frame = (CCBacktraceFrame *)calloc(1, sizeof(*frame));
    if (!frame) {
        CU_ERROR_PRINT(("Cannot allocate frame\n"));
        return CUDA_ERROR_OUT_OF_MEMORY;
    }

    *pframe = frame;

    return CUDA_SUCCESS;
}

static CUresult
destroyFrame(CCBacktraceFrame **pframe)
{
    CCBacktraceFrame *frame;

    if (!pframe) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!(*pframe))
        return CUDA_SUCCESS;

    frame = *pframe;

    if (frame->type == CC_BT_FRAME_TYPE_HOST) {
        if (frame->cases.host.libName) {
            free(frame->cases.host.libName);
            frame->cases.host.libName = NULL;
        }
    }

    if (frame->funcName) {
        free(frame->funcName);
        frame->funcName = NULL;
    }

    free(frame);
    *pframe = NULL;

    return CUDA_SUCCESS;
}

static CUresult
destroyFrameList(CCBacktraceFrame **pframeHead)
{
    CCBacktraceFrame *frame = NULL, *next = NULL;
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!pframeHead) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Early exit
    if (!(*pframeHead))
        return CUDA_SUCCESS;

    frame = *pframeHead;
    next = (frame) ? frame : NULL;

    for (; frame; frame = next) {
        next = frame->next;
        res = destroyFrame(&frame);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to destroy frame\n"));
            return res;
        }
    }

    *pframeHead = NULL;

    return CUDA_SUCCESS;
}

static void
printFrame(CCBacktraceFrame *frame)
{
#ifndef RELEASE
    const char *type = "";
    char extra[1024] = {0};

    switch (frame->type) {
    case CC_BT_FRAME_TYPE_HOST:
        type = "Host";
        snprintf(extra, 1024, " lib:%s(0x%" PRIx64 ")",
                 frame->cases.host.libName, frame->cases.host.libBaseAddr);
        break;
    case CC_BT_FRAME_TYPE_DEV:
        type = "Device";
        snprintf(extra, 1024, " kernel:%s(0x%" PRIx64 ") module:%s",
                 frame->cases.dev.entryKernelName,
                 frame->cases.dev.entryKernelAddr,
                 frame->cases.dev.moduleName);
        break;
    default:
        break;
    };

    fprintf(stderr, "%s frame (%u of %u): RA : 0x%" PRIx64 "%s\n",
            type, frame->frameDepth + 1, frame->totalDepth, frame->addr,
            extra);
    if (frame->funcName)
        fprintf(stderr, "\t\tfunc:%s (0x%" PRIx64 ")\n",
                frame->funcName, frame->funcBaseAddr);
#endif
}

static void
printFrameList(CCBacktraceFrame *head)
{
#ifndef RELEASE
    CCBacktraceFrame *cur = NULL;

    for (cur = head; cur; cur = cur->next)
        printFrame(cur);
#endif
}

static CUresult
createBacktraceHost(CCBacktrace *ccbt)
{
    CCBacktraceHost *bth = NULL;

    CU_TRACE_FUNCTION();

    if (!ccbt) {
        CU_ERROR_PRINT(("Invalid argument\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ccbt->host = NULL;

    if (!ccbt->opts.enableHostBacktrace || !ccbt->opts.maxHostDepth) {
        CU_TRACE_PRINT(("Host backtrace is disabled\n"));
        return CUDA_SUCCESS;
    }

    bth = (CCBacktraceHost *)calloc(1, sizeof(*bth));
    if (!bth) {
        CU_ERROR_PRINT(("Out of host memory\n"));
        return CUDA_ERROR_OUT_OF_MEMORY;
    }

    bth->maxDepth = ccbt->opts.maxHostDepth;

    bth->state = CC_BT_HOST_STATE_INITIALIZED;
    bth->refCount = 1;

    ccbt->host = bth;

    return CUDA_SUCCESS;
}

static CUresult
destroyBacktraceHost(CCBacktrace *ccbt)
{
    CUresult res = CUDA_SUCCESS;
    CCBacktraceHost *bth = NULL;

    CU_TRACE_FUNCTION();

    if (!ccbt) {
        CU_ERROR_PRINT(("Invalid argument\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    bth = ccbt->host;

    /* Early exit conditions */

    /* Host object doesnt exist */
    if (!bth)
        return CUDA_SUCCESS;

    /* Refcount check */
    --bth->refCount;

    if (bth->refCount)
        return CUDA_SUCCESS;

    if (bth->state == CC_BT_HOST_STATE_FRAMES_GENERATED) {
        res = destroyFrameList(&bth->frameHead);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to destroy frame list\n"));
            return res;
        }
    }

    if (bth->rawBuf) {
        free(bth->rawBuf);
        bth->rawBuf = NULL;
    }

    bth->state = CC_BT_HOST_STATE_NONE;
    free(bth);
    ccbt->host = NULL;

    return CUDA_SUCCESS;
}

static CUresult
createBacktraceDev(CCBacktrace *ccbt)
{
    CCBacktraceDevice *btd = NULL;

    CU_TRACE_FUNCTION();

    if (!ccbt) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ccbt->dev = NULL;

    if (!ccbt->opts.enableDevBacktrace || !ccbt->opts.maxDevDepth) {
        CU_TRACE_PRINT(("Dev backtrace is disabled\n"));
        return CUDA_SUCCESS;
    }

    btd = (CCBacktraceDevice *)calloc(1, sizeof(*btd));
    if (!btd) {
        CU_ERROR_PRINT(("Out of memory\n"));
        return CUDA_ERROR_OUT_OF_MEMORY;
    }

    btd->state = CC_BT_DEV_STATE_INITIALIZED;
    btd->maxDepth = ccbt->opts.maxDevDepth;
    btd->refCount = 1;

    ccbt->dev = btd;
    return CUDA_SUCCESS;
}

static CUresult
destroyBacktraceDev(CCBacktrace *ccbt)
{
    CUresult res = CUDA_SUCCESS;
    CCBacktraceDevice *btd = NULL;

    CU_TRACE_FUNCTION();

    if (!ccbt) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    btd = ccbt->dev;

    if (!btd)
        return CUDA_SUCCESS;

    --btd->refCount;

    if (btd->refCount)
        return CUDA_SUCCESS;

    /* Early return */
    if (btd->state == CC_BT_DEV_STATE_NONE)
        return CUDA_SUCCESS;

    if (btd->state == CC_BT_DEV_STATE_FRAMES_GENERATED) {
        res = destroyFrameList(&btd->frameHead);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to destroy frame list\n"));
            return res;
        }
    }

    btd->state = CC_BT_DEV_STATE_NONE;
    free(btd);
    ccbt->dev = NULL;

    return CUDA_SUCCESS;
}

CUresult
cloneBacktraceHost(CCBacktrace **pdst, CCBacktrace *src)
{
    CUresult res = CUDA_SUCCESS;
    CCBacktrace *dst = NULL;

    CU_TRACE_FUNCTION();

    if (!pdst || !src) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    dst = (CCBacktrace *)calloc(1, sizeof(*dst));
    if (!dst) {
        CU_ERROR_PRINT(("Failed to create clone\n"));
        return CUDA_ERROR_OUT_OF_MEMORY;
    }

    // Copy all the properties
    memcpy(dst, src, sizeof(*dst));

    // Clobber the device pointer
    dst->dev = NULL;

    // Update refcounts
    if (dst->host)
        ++dst->host->refCount;

    res = createBacktraceDev(dst);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to create device component of clone\n"));
        free(dst);
        return CUDA_ERROR_UNKNOWN;
    }

    *pdst = dst;

    return CUDA_SUCCESS;
}

/* Creates a backtrace object */
CUresult
createBacktrace(CCBacktrace **ccbt, CCBacktraceOptions *opts)
{
    CCBacktrace *bt = NULL;
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!ccbt || !opts) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *ccbt = NULL;

    bt = (CCBacktrace *)calloc(1, sizeof(*bt));
    if (!bt) {
        CU_ERROR_PRINT(("Out of host memory\n"));
        return CUDA_ERROR_OUT_OF_MEMORY;
    }

    memcpy(&bt->opts, opts, sizeof(*opts));

    res = createBacktraceHost(bt);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to create host backtrace\n"));
        free(bt);
        return res;
    }

    res = createBacktraceDev(bt);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to create device backtrace\n"));
        free(bt);
        return res;
    }

    *ccbt = bt;

    return CUDA_SUCCESS;
}

/* Destroys a backtrace object */
CUresult
destroyBacktrace(CCBacktrace **ccbt)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!ccbt) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!*ccbt) {
        CU_TRACE_PRINT(("Already NULL\n"));
        return CUDA_SUCCESS;
    }

    res = destroyBacktraceHost(*ccbt);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to destroy host backtrace\n"));
        return res;
    }

    res = destroyBacktraceDev(*ccbt);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to destroy device backtrace\n"));
        return res;
    }

    free(*ccbt);
    *ccbt = NULL;

    return CUDA_SUCCESS;
}

/* Capture a host backtrace */
CUresult
captureHostBacktrace(CCBacktrace *ccbt)
{
    CUresult res = CUDA_SUCCESS;
    CCBacktraceHost *bth = NULL;

    CU_TRACE_FUNCTION();

    if (!ccbt) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    bth = ccbt->host;

    if (!bth) {
        CU_TRACE_PRINT(("Disabled host capture\n"));
        return CUDA_SUCCESS;
    }

    if (bth->state == CC_BT_HOST_STATE_FRAMES_GENERATED ||
        bth->state == CC_BT_HOST_STATE_CAPTURED) {
        CU_TRACE_PRINT(("Nothing to do\n"));
        return CUDA_SUCCESS;
    }

    if (bth->state != CC_BT_HOST_STATE_INITIALIZED) {
        CU_ERROR_PRINT(("Host backtrace in unexpected state.\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    bth->rawBuf = (void **)calloc(bth->maxDepth, sizeof(*bth->rawBuf));
    if (!bth->rawBuf) {
        CU_ERROR_PRINT(("Failed to allocate buffer\n"));
        return CUDA_ERROR_OUT_OF_MEMORY;
    }

    res = osalBacktraceCapture(bth->rawBuf, bth->maxDepth, &bth->depth);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Invalid backtrace.\n"));
        return res;
    }

    bth->state = CC_BT_HOST_STATE_CAPTURED;

    CU_TRACE_PRINT(("Captured %u host frames\n", bth->depth));

    return CUDA_SUCCESS;
}

static CUresult
haloBacktraceCapture(CudbgDevice dev, uint32_t vsm, uint32_t  wp,
                     uint32_t ln, CCBacktraceDevice *btd)
{
    uint32_t i;
    CUDBGResult dbgRes = CUDBG_SUCCESS;
    uint32_t threadIdxX;
    uint32_t threadIdxY;
    uint32_t threadIdxZ;
    CuDim3   blockIdx;

    if (!dev || !btd) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    dbgRes = dev->halo.readCallDepth(dev, vsm, wp, ln, &btd->depth);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read call depth\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!btd->depth) {
        CU_TRACE_PRINT(("No backtrace\n"));
        return CUDA_SUCCESS;
    }

    btd->rawBuf = (uint64_t *)calloc(btd->depth, sizeof(*btd->rawBuf));
    if (!btd->rawBuf) {
        CU_ERROR_PRINT(("Failed to allocate backtrace buffer\n"));
        return CUDA_ERROR_OUT_OF_MEMORY;
    }

    // Cache properties in btd
    btd->devId = dev->deviceIdx;
    btd->vsm   = vsm;
    btd->wp    = wp;
    btd->ln    = ln;

    // Read thread/block coordinates
    dbgRes = dev->halo.read_blockIdx(dev, vsm, wp, &blockIdx);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read block index\n"));
        return CUDA_ERROR_UNKNOWN;
    }
    btd->blockIdxX = blockIdx.x;
    btd->blockIdxY = blockIdx.y;
    btd->blockIdxZ = blockIdx.z;

    // Read threadIdx from HALO
    dbgRes = dev->halo.read_threadIdx(dev, vsm, wp, ln,
                                      0,
                                      &threadIdxX,
                                      &threadIdxY,
                                      &threadIdxZ);
    btd->threadIdxX = threadIdxX;
    btd->threadIdxY = threadIdxY;
    btd->threadIdxZ = threadIdxZ;

    dbgRes = dev->halo.readSyscallCallDepth(dev, vsm, wp, ln, &btd->syscallDepth);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read syscall call depth\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* Push the rest of the return addresses */
    for (i = 0; i < btd->depth; ++i) {
        dbgRes = dev->halo.readReturnAddress(dev, vsm, wp, ln, i, &btd->rawBuf[i]);
        if (dbgRes != CUDBG_SUCCESS) {
            CU_TRACE_PRINT(("Failed to read return address\n"));
        }
    }

    return CUDA_SUCCESS;
}

/* Capture a device backtrace */
CUresult
captureDeviceBacktrace(CCBacktrace *ccbt, MCcontext *mcctx, CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln)
{
    CUresult res = CUDA_SUCCESS;
    CCBacktraceDevice *btd = NULL;

    CU_TRACE_FUNCTION();

    if (!ccbt || !dev) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    btd = ccbt->dev;

    if (!btd) {
        CU_TRACE_PRINT(("Disabled device backtrace\n"));
        return CUDA_SUCCESS;
    }

    if (btd->state == CC_BT_DEV_STATE_CAPTURED ||
        btd->state == CC_BT_DEV_STATE_FRAMES_GENERATED) {
        CU_TRACE_PRINT(("Nothing to do\n"));
        return CUDA_SUCCESS;
    }

    if (btd->state != CC_BT_DEV_STATE_INITIALIZED) {
        CU_ERROR_PRINT(("Device backtrace in unexpected state. \n"));
        return CUDA_ERROR_UNKNOWN;
    }

    btd->state = CC_BT_DEV_STATE_CAPTURING;

    btd->mcctx = mcctx;

    res = haloBacktraceCapture(dev, vsm, wp, ln, btd);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to capture backtrace from halo\n"));
        return res;
    }

    btd->state = CC_BT_DEV_STATE_CAPTURED;

    CU_TRACE_PRINT(("Captured %u device frames\n", btd->depth));
    return CUDA_SUCCESS;
}

/* Generate frames for the host portion of a backtrace */
static CUresult
generateFramesHost(CCBacktrace *ccbt, CCBacktraceStateHandle handle)
{
    CCBacktraceHost *bth = NULL;
    CUresult res = CUDA_SUCCESS;
    uint32_t i = 0;
    CCBacktraceFrame *cur = NULL, *head = NULL, *tail = NULL;
    CCBacktraceFrame *prev = NULL;
    uint32_t islibcuda;

    if (!ccbt) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    bth = ccbt->host;

    if (!bth) {
        CU_TRACE_PRINT(("Host trace disabled\n"));
        return CUDA_SUCCESS;
    }

    // Early exit if flat backtrace is already present
    if (bth->state == CC_BT_HOST_STATE_FRAMES_GENERATED)
        return CUDA_SUCCESS;
    else if (bth->state != CC_BT_HOST_STATE_CAPTURED) {
        // Any state other than CAPTURED or FRAMES_GENERATED is an error
        CU_ERROR_PRINT(("Unexpected state : %u\n", bth->state));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!bth->rawBuf || !bth->depth) {
        CU_ERROR_PRINT(("Buffer missing or 0 depth\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    prev = NULL;
    for (i = 0; i < bth->depth; ++i) {
        cur = (CCBacktraceFrame *)calloc(1, sizeof(*cur));
        if (!cur) {
            CU_ERROR_PRINT(("Failed to allocate frame\n"));
            res =  CUDA_ERROR_OUT_OF_MEMORY;
            goto error;
        }

        if (!head)
            head = cur;
        if (tail)
            tail->next = cur;
        prev = tail;
        tail = cur;

        cur->type = CC_BT_FRAME_TYPE_HOST;
        cur->next = NULL;
        cur->bt = ccbt;
        cur->frameDepth = i;
        cur->totalDepth = bth->depth;
        cur->addr = (uint64_t)(uintptr_t)bth->rawBuf[i];
        islibcuda = 0U;
        // This happens on windows XP 64 bit
        if (!cur->addr) {
            cur->flags |= CC_BT_FRAME_FLAG_CORRUPT;
            continue;
        }

        res = osalGetFrameInfo(handle, bth->rawBuf[i],
                               &cur->cases.host.libName,
                               &cur->cases.host.libBaseAddr,
                               &cur->funcName, &cur->funcBaseAddr,
                               &islibcuda);

        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to get frame info\n"));
            goto error;
        }

        if (islibcuda)
            cur->flags |= CC_BT_FRAME_FLAG_CUDALIB;

        if (prev && cur &&
            prev->cases.host.libBaseAddr != cur->cases.host.libBaseAddr)
            prev->flags |= CC_BT_FRAME_FLAG_ENTRY;
    }

    bth->frameHead = head;
    bth->state = CC_BT_HOST_STATE_FRAMES_GENERATED;

    return res;

error:
    cur = head;

    for (i = 0; i < bth->depth && head; ++i) {
        cur = head->next;
        free(head);
        head = cur;
    }

    head = NULL;
    tail = NULL;
    return res;
}

/* Generate frames for the device portion of a backtrace */
static CUresult
generateFramesDev(CCBacktrace *ccbt)
{
    CCBacktraceDevice *btd = NULL;
    uint32_t i = 0;
    CCBacktraceFrame *cur = NULL, *head = NULL, *tail = NULL;
    MCfunc *mcfunc = NULL;
    size_t modNameSize, kernNameSize;
    uint32_t tmpOffset;
    char *tmpName;
    TOOLSresult tr = TOOLS_SUCCESS;
    uint32_t offset_pc;
    CUresult res = CUDA_SUCCESS;

    if (!ccbt) {
        CU_ERROR_PRINT(("Invalid argument\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    btd = ccbt->dev;

    if (!btd) {
        CU_TRACE_PRINT(("Device trace disabled\n"));
        return CUDA_SUCCESS;
    }

    // Early exit if flat backtrace is already present
    if (btd->state == CC_BT_DEV_STATE_FRAMES_GENERATED)
        return CUDA_SUCCESS;
    else if (btd->state != CC_BT_DEV_STATE_CAPTURED) {
        // Any state other than CAPTURED or FRAMES_GENERATED is an error
        CU_ERROR_PRINT(("Unexpected state : %u\n", btd->state));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!btd->rawBuf || !btd->depth) {
        CU_ERROR_PRINT(("Buffer missing or 0 depth\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    for (i = 0; i < btd->depth; ++i) {
        cur = (CCBacktraceFrame *)calloc(1, sizeof(*cur));
        if (!cur) {
            CU_ERROR_PRINT(("Failed to allocate frame\n"));
            res =  CUDA_ERROR_OUT_OF_MEMORY;
            goto error;
        }

        if (!head)
            head = cur;
        if (tail)
            tail->next = cur;
        tail = cur;

        cur->type = CC_BT_FRAME_TYPE_DEV;
        cur->next = NULL;
        cur->bt = ccbt;
        cur->frameDepth = i;
        cur->totalDepth = btd->depth;
        cur->addr = btd->rawBuf[i];
        mcfunc = mcContextGetFuncByAddr(btd->mcctx, btd->rawBuf[i]);
        if (!mcfunc) {
            CU_TRACE_PRINT(("No extra information for frame : %u\n", i));
            continue;
        }

        modNameSize = 0;
        if (mcfunc->mod && mcfunc->mod->cumod && mcfunc->mod->cumod->name)
            modNameSize = strlen((char*)mcfunc->mod->cumod->name);
        if (modNameSize) {
            cur->cases.dev.moduleName = (char *)calloc(1, modNameSize + 1);
            memcpy(cur->cases.dev.moduleName, mcfunc->mod->cumod->name, modNameSize);
        }

        kernNameSize = strlen(mcfunc->funcName);
        cur->cases.dev.entryKernelName = (char *)calloc(1, kernNameSize + 1);
        memcpy(cur->cases.dev.entryKernelName, mcfunc->funcName, kernNameSize);
        cur->cases.dev.entryKernelAddr = mcfunc->mem.dev.dPtr;

        tmpOffset = 0;
        tmpName = NULL;
        offset_pc = (uint32_t)(btd->rawBuf[i] - mcfunc->mem.dev.dPtr);

        if (!mcfunc->mod || !mcfunc->mod->image)  {
            CU_TRACE_PRINT(("Cant get module binary. Skipping\n"));
            continue;
        }

        if (isELF64((const char *)mcfunc->mod->image))
            tr = toolsElf64GetContainerFunc(mcfunc->mod->image,
                                            mcfunc->funcName, offset_pc,
                                            &tmpName, &tmpOffset);
        else
            tr = toolsElf32GetContainerFunc(mcfunc->mod->image,
                                            mcfunc->funcName, offset_pc,
                                            &tmpName, &tmpOffset);

        if (tr != TOOLS_SUCCESS) {
            CU_TRACE_PRINT(("Failed to get nearest function. Skipping name\n"));
            continue;
        }

        if (tmpName && strlen(tmpName)) {
            cur->funcName = (char *)calloc(1, strlen(tmpName) + 1);
            memcpy(cur->funcName, tmpName, strlen(tmpName));
        }

        if (tmpOffset != ~0U)
            cur->funcBaseAddr = mcfunc->mem.dev.dPtr + tmpOffset;
    }

    btd->frameHead = head;
    btd->state = CC_BT_DEV_STATE_FRAMES_GENERATED;

    return CUDA_SUCCESS;

error:
    cur = head;

    for (i = 0; i < btd->depth && head; ++i) {
        cur = head->next;
        free(head);
        head = cur;
    }

    head = NULL;
    tail = NULL;
    return res;
}

CUresult
initializeFrameGenerator(CCBacktraceStateHandle *pHandle)
{
    CU_TRACE_FUNCTION();

    if (!pHandle) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    return osalBacktraceFrameInfoInitialize((void**)pHandle);
}

CUresult
finalizeFrameGenerator(CCBacktraceStateHandle *pHandle)
{
    CU_TRACE_FUNCTION();

    if (!pHandle) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    return osalBacktraceFrameInfoFinalize((void**)pHandle);
}

/* Generate frames for the backtrace */
CUresult
generateFrames(CCBacktrace *ccbt, CCBacktraceStateHandle handle)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    res = generateFramesHost(ccbt, handle);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to generate frames for host backtrace\n"));
        return CUDA_SUCCESS;
    }

    res = generateFramesDev(ccbt);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to generate frames device backtrace\n"));
        return CUDA_SUCCESS;
    }

    return res;
}

static void
dumpBacktraceHost(CCBacktrace *ccbt)
{
#ifndef RELEASE
    CCBacktraceHost *bth = NULL;

    if (!ccbt || !ccbt->host)
        return;

    bth = ccbt->host;

    fprintf(stderr, "Host backtrace. State:%u Max Depth:%u",
            bth->state, bth->maxDepth);
    if (bth->state == CC_BT_HOST_STATE_CAPTURED ||
        bth->state == CC_BT_HOST_STATE_FRAMES_GENERATED)
        fprintf(stderr, " Depth:%u", bth->depth);

    fprintf(stderr, "\n");

    if (bth->state == CC_BT_HOST_STATE_FRAMES_GENERATED)
        printFrameList(bth->frameHead);

#endif
}

static void
dumpBacktraceDev(CCBacktrace *ccbt)
{
#ifndef RELEASE
    CCBacktraceDevice *btd = NULL;

    if (!ccbt || !ccbt->dev)
        return;

    btd = ccbt->dev;

    fprintf(stderr, "Device backtrace. State:%u Max Depth:%u",
            btd->state, btd->maxDepth);
    if (btd->state == CC_BT_DEV_STATE_CAPTURED ||
        btd->state == CC_BT_DEV_STATE_FRAMES_GENERATED)
        fprintf(stderr, " Depth:%u", btd->depth);

    fprintf(stderr, "\n");

    if (btd->state == CC_BT_DEV_STATE_FRAMES_GENERATED)
        printFrameList(btd->frameHead);

#endif
}

void
dumpBacktrace(CCBacktrace *ccbt)
{
#ifndef RELEASE
    if (!ccbt)
        return;

    dumpBacktraceHost(ccbt);
    dumpBacktraceDev(ccbt);
#endif
}

