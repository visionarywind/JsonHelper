/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef _RACECHECK_H
#define _RACECHECK_H

#include "cudamemcheck.h"
#include "memcheck_types.h"
#include "memcheck_tool_modes.h"

// This is purposely 1 less than pow(2) to allow for the header
#define RC_DEV_BUFFER_ENTRIES (32*1024 - 1)

typedef struct RCEntry_st RCEntry;
typedef struct RCRaceHazard_st RCRaceHazard;

// Device Side structures
typedef struct RCdevBufferHeader_st RCdevBufferHeader;
typedef struct RCdevBufferEntry_st RCdevBufferEntry;

// Occupies 16 Bytes at the start
struct RCdevBufferHeader_st {
    uint32_t next_offset;
    uint32_t entry_size;
    uint32_t buffer_size;
    uint32_t header_size;
};

// Occupies 40 bytes in total
struct RCdevBufferEntry_st {
    uint32_t address;
    uint16_t blockIdxZ;
    uint16_t blockIdxY;
    uint32_t blockIdxX;
    uint16_t flags;
    uint8_t  data0;
    uint8_t  data1;
    uint32_t pc0;
    uint32_t pc0_hi;
    uint32_t tid_state0;
    uint32_t pc1;
    uint32_t pc1_hi;
    uint32_t tid_state1;
    uint64_t gridId;
};

typedef struct RCdevTableEntry_st RCdevTableEntry;
struct RCdevTableEntry_st {
    uint32_t tid_state;
    uint32_t pc;
};

typedef struct RCdevTableEntry2_st RCdevTableEntry2;
struct RCdevTableEntry2_st {
    uint32_t tid_state;
    uint32_t pc;
    uint32_t pc_hi; // used by Volta+
    uint32_t padding;
};

typedef struct RCdevTableEntry_st RCdevTableEntryCommon;

#define ENTRY_STATE_MASK            0x0000F800U
#define ENTRY_STATE_STATUS_MASK     0x00003000U
#define ENTRY_STATE_RW_MASK         0x00001000U
#define ENTRY_STATE_LOCKBIT_MASK    0x00000800U
typedef enum {
    ENTRY_STATE_NONE        = 0,
    ENTRY_STATE_READ        = 0x00002000,
    ENTRY_STATE_WRITE       = 0x00003000,
    ENTRY_STATE_MULTI_READ  = 0x00006000,
    ENTRY_STATE_LOCKED      = 0x00000800, // Only informational
} RCEntryStates;

typedef enum {
    RACE_HAZARD_TYPE_NONE = 0,
    RACE_HAZARD_TYPE_WAW  = 1,
    RACE_HAZARD_TYPE_RAW  = 2,
    RACE_HAZARD_TYPE_WAR  = 3,
} RCRaceHazardTypes;

struct RCEntry_st {
    RCEntryStates state;
    uint32_t    threadIdxX;
    uint32_t    threadIdxY;
    uint32_t    threadIdxZ;
    uint32_t    pc;
};

struct RCRaceHazard_st {
    RCRaceHazardTypes   type;       // Type of hazard
    uint32_t            address;    // Address of access
    uint32_t            blockIdxX;
    uint32_t            blockIdxY;
    uint32_t            blockIdxZ;
    uint8_t             old_data;
    uint8_t             new_data;
    RCEntry             prev,cur;   // Previous and current values
};

typedef struct CCracecheckCtxData_st CCracecheckCtxData;
typedef struct CCracecheckRecData_st CCracecheckRecData;

struct CCracecheckCtxData_st {
    CUmod   *racecheckMod;
    CUmod   *prologueMod;
    CUfunc  *prologueFunc;
    CUfunc  *commonPatchFunc;
    CUfunc  *commonBarrierPatchFunc;
    CUfunc  *bufferWriter;

    /* Cached vals for lookup */
    /* Hardware values */
    uint32_t numSm;
    uint32_t numCtaPerSM;
    uint32_t maxShmemPerCta;
    uint32_t perSMErrorEntrySize;

    /* Depth of maximum CNP join */
    uint32_t maxDepth;

    /* Error entry (Zero copy memory) */
    CCmemHandle errorEntry;

    /* Main module */
    MCmod *mod;

    /* Entry points */
    uint64_t barCommon;
    uint64_t ldstCommon;
    uint64_t wsCommon;
};

struct CCracecheckRecData_st {
    /* Mainly for cleanup /repatching */
    tList   *internalModules;

    /* Separate functions */
    MCmod *entryExitMod;

    /* All tracking tables for racecheck */
    CCmemHandle trackingTable;
};

CUresult racecheck_toolModeInitialize(MCoptions *options, MCtoolMode *toolMode);

CUresult racecheckTrapHandlerCallback(MCcontext *mcctx, CUmemobj *scratchpad, uint32_t smError);
CUresult racecheckTrapHandlerEndCallback(MCcontext *mcctx, CUmemobj *scratchpad, uint32_t smError);

CUresult racecheckDrainBuffer(MCcontext *mcctx);

CCracecheckCtxData* racecheckGetContextData(MCcontext *mcctx);
CCracecheckRecData* racecheckGetRecData(MCrec *rec);
CCracecheckRecData* racecheckGetRecDataFromTrackingTablePtr(MCcontext *mcctx, const uint64_t dptr);

CUresult racecheckLoadEntryExit(MCrec *rec, MCfunc **stubFunc);
CUresult racecheckLoadBarrierStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, MCfunc **stubFunc);
CUresult racecheckLoadWarpsyncStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, MCfunc **stubFunc);
CUresult racecheckLoadSharedLDSTStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, uint64_t patchPC, MCfunc **stubFunc);
CUresult racecheckLoadGlobalLDSTStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, uint64_t patchPC, MCfunc **stubFunc);

uint32_t getRCdevTableEntrySize(MCcontext *mcctx);
CUresult getRCdevTableEntryPc(MCcontext *mcctx, RCdevTableEntryCommon *entry, uint64_t *pc);
#endif

