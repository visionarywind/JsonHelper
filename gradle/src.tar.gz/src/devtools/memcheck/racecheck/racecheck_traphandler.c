/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "memcheck.h"
#include "memcheck_types.h"
#include "memcheck_inst_types.h"
#include "memcheck_tool_modes.h"
#include "racecheck.h"
#include "memcheck_error.h"
#include "fermi_mcinterop.h"
#include "fermi_racecheck_lmem.h"

#include "halo.h"
#include "halo_internal.h"
#include "halo_state.h"
#include "check_mc_context.h"
#include "check_mc_launch.h"

#ifndef RELEASE
static void
printEntry(CUmemcheck_record_type_hazardThreadInfo *entry)
{
    if (!entry)
        return;

    fprintf(stderr, " PC : 0x%x", entry->pc);
    fprintf(stderr, " ThreadId: (%u,%u,%u)\n", entry->threadIdxX,
            entry->threadIdxY, entry->threadIdxZ);
}

static CUresult
printRaceRecord(CUmemcheck_record_type_shmemHazard *race)
{
    CU_TRACE_FUNCTION();

    if (!race) {
        return CUDA_ERROR_UNKNOWN;
    }

    fprintf(stderr, "Hazard Detected ");
    fprintf(stderr, " type : %s (%u) ", (race->common.hazardType == CU_RACECHECK_HAZARD_WAW ? "WAW" :
                                         race->common.hazardType == CU_RACECHECK_HAZARD_RAW ? "RAW" :
                                         race->common.hazardType == CU_RACECHECK_HAZARD_WAR ? "WAR" :
                                         "UNK"), race->common.hazardType);
    fprintf(stderr, " in BlockId: (%u,%u,%u) ", race->common.blockIdxX,
            race->common.blockIdxY, race->common.blockIdxZ);
    fprintf(stderr, "@ Address : 0x%x\n", race->common.address);

    // The new data, old data only makes sense if the most recent access was a write
    // TODO: Add support to get this even when doing a partial read (deferring to
    //       after the parse code is pushed into instMgr)
    if (race->common.hazardType == CU_RACECHECK_HAZARD_WAW ||
        race->common.hazardType == CU_RACECHECK_HAZARD_WAR)
        fprintf(stderr, "\tRead data : 0x%x, Write data : 0x%x\n",
                race->common.readData, race->common.writeData);
    else
        fprintf(stderr, "\tRead data : 0x%x\n", race->common.readData);

    fprintf(stderr, "\tThread0 :");
    printEntry(&race->thread0);
    fprintf(stderr, "\tThread1 :");
    printEntry(&race->thread1);

    return CUDA_SUCCESS;
}
#endif

static bool
warpIsSame(CUmemcheck_record_type_hazardThreadInfo *t0,
           CUmemcheck_record_type_hazardThreadInfo *t1,
           uint32_t blockDimX,
           uint32_t blockDimY,
           uint32_t blockDimZ)
{
    uint64_t wt0, wt1;
    uint64_t dimx, dimy;

    if (!t0 || !t1)
        return false;

    /*
    This uses the same threadid computation algorithm as the fermi/kepler MPC.
    Fermi:
        //hw/doc/gpu/fermi/fermi/design/IAS/SPM/IAS_MPC_SecX_Compute.doc
    Kepler:
        //hw/doc/gpu/kepler/kepler/design/IAS/IAS_MPC_SecX_Compute.doc

    In the code, wt = weighted thread index, this produces a linearized
    threadindex for a thread in the launch, using the hardware's threadid
    computation algorithm. Two threads are in the same warp if their
    weighted id / 32 are the same. (As 32 threads are grouped into a warp)
    */

    /* Ensure no 32bit overflow by forcing at least one operand in each
       operation to 64bit */
    dimx = (uint64_t)blockDimX;
    dimy = (uint64_t)blockDimY;

    wt0  = (uint64_t)(t0->threadIdxX + dimx * t0->threadIdxY + t0->threadIdxZ * dimx * dimy);
    wt1  = (uint64_t)(t1->threadIdxX + dimx * t1->threadIdxY + t1->threadIdxZ * dimx * dimy);

    return ( (wt0 >> 5) == ( wt1 >> 5 ));
}

static CUresult
updateFilterState(CUmemcheck_record *rec, uint32_t blockDimX, uint32_t blockDimY, uint32_t blockDimZ)
{
    CUmemcheck_error_record *err = NULL;

    if (!rec)
        return CUDA_ERROR_UNKNOWN;

    err = &rec->cases.error;

    err->cases.shmemHazard.common.filterType = CU_RACECHECK_FILTER_NONE;

    /* For entries in the same warp, its possible that the race is false
       as warp accesses are weak ordered due to hardware. However,
       this may be invalid if the user is not doing warp level programming,
       in which case this may be hiding some real hazards. */
    if (warpIsSame(&err->cases.shmemHazard.thread0,
                   &err->cases.shmemHazard.thread1,
                   blockDimX,
                   blockDimY,
                   blockDimZ) &&
        err->cases.shmemHazard.thread0.rawPC != err->cases.shmemHazard.thread1.rawPC)
        err->cases.shmemHazard.common.filterType |= CU_RACECHECK_FILTER_WARP_PROG;

    /* If the threadIdx are the same, suppress it */
    if (err->cases.shmemHazard.thread0.threadIdxX == err->cases.shmemHazard.thread1.threadIdxX &&
        err->cases.shmemHazard.thread0.threadIdxY == err->cases.shmemHazard.thread1.threadIdxY &&
        err->cases.shmemHazard.thread0.threadIdxZ == err->cases.shmemHazard.thread1.threadIdxZ)
        err->cases.shmemHazard.common.filterType |= CU_RACECHECK_FILTER_SAME_THREAD;


    /* For WAW records, if the data are identical, suppress it */
    if (err->cases.shmemHazard.common.hazardType == CU_RACECHECK_HAZARD_WAW &&
        err->cases.shmemHazard.common.readData == err->cases.shmemHazard.common.writeData)
        err->cases.shmemHazard.common.filterType |= CU_RACECHECK_FILTER_SAME_DATA;

    return CUDA_SUCCESS;
}

static CUresult
convertToHostRecord(MCcontext *mcctx, RCdevBufferEntry *buf, CUmemcheck_record *rec)
{
    uint32_t t0state = 0;
    uint32_t t1state = 0;
    uint32_t flags = 0;
    CUmemcheck_error_record *err = NULL;
    MCfunc *mcfunc0 = NULL;
    MCfunc *mcfunc1 = NULL;
    uint64_t pc0 = 0;
    uint64_t pc1 = 0;

    if (!mcctx || !buf || !rec)
        return CUDA_ERROR_UNKNOWN;

    // Safety check for partially written records
    if (!(buf->flags & CU_RACECHECK_FILTER_RECORD_VALID)) {
        CU_WARNING(("Detected invalid record\n"));
        return CUDA_ERROR_LAUNCH_OUT_OF_RESOURCES;
    }

    if (!createNewErrorRecord(CU_MEMCHECK_RECORD_SHMEM_HAZARD, rec)) {
        CU_ERROR_PRINT(("Failed to initialize error type\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    err = &rec->cases.error;

    err->cases.shmemHazard.common.gridid = (uint64_t)buf->gridId;
    err->cases.shmemHazard.common.blockIdxX = buf->blockIdxX;
    err->cases.shmemHazard.common.blockIdxY = buf->blockIdxY;
    err->cases.shmemHazard.common.blockIdxZ = buf->blockIdxZ;
    err->cases.shmemHazard.common.address   = buf->address;
    err->cases.shmemHazard.common.readData  = buf->data0;
    err->cases.shmemHazard.common.writeData = buf->data1;

    if (getArchFromSmVer(mcctx->sm_version) < MC_TOOL_MODE_ARCH_SM70) {
        /* Pre-volta has 32bit PCs and we don't set the HI field in some cases */
        buf->pc0_hi = 0;
        buf->pc1_hi = 0;
    }

    /* Fill the rawPC and the function-local pc for thread0 */
    pc0 = ((uint64_t)buf->pc0_hi << 32) | (uint64_t)buf->pc0;
    err->cases.shmemHazard.thread0.rawPC = pc0;
    mcfunc0 = mcContextGetFuncByAddr(mcctx, pc0);
    if (mcfunc0)
        pc0 -= mcfunc0->mem.dev.dPtr;
    else
        CU_DEBUG_PRINT(("Could not find function for pc 0x%" PRIx64 "\n", pc0));

    err->cases.shmemHazard.thread0.pc = (uint32_t)pc0;

    t0state = buf->tid_state0 & ENTRY_STATE_STATUS_MASK;
    err->cases.shmemHazard.thread0.threadIdxX = buf->tid_state0 & 0x07ff;
    err->cases.shmemHazard.thread0.threadIdxY = (buf->tid_state0 >> 16) & 0x03ff;
    err->cases.shmemHazard.thread0.threadIdxZ = (buf->tid_state0 >> 26) & 0x003f;
    err->cases.shmemHazard.thread0.write = (t0state == ENTRY_STATE_WRITE) ? 1 : 0;

    /* Fill the rawPC and the function-local pc for thread1 */
    pc1 = ((uint64_t)buf->pc1_hi << 32) | (uint64_t)buf->pc1;
    err->cases.shmemHazard.thread1.rawPC = pc1;
    mcfunc1 = mcContextGetFuncByAddr(mcctx, pc1);
    if (mcfunc1)
        pc1 -= mcfunc1->mem.dev.dPtr;
    else
        CU_DEBUG_PRINT(("Could not find function for pc 0x%" PRIx64 "\n", pc1));

    err->cases.shmemHazard.thread1.pc = (uint32_t)pc1;

    t1state = buf->tid_state1 & ENTRY_STATE_STATUS_MASK;
    err->cases.shmemHazard.thread1.threadIdxX = buf->tid_state1 & 0x07ff;
    err->cases.shmemHazard.thread1.threadIdxY = (buf->tid_state1 >> 16) & 0x03ff;
    err->cases.shmemHazard.thread1.threadIdxZ = (buf->tid_state1 >> 26) & 0x003f;
    err->cases.shmemHazard.thread1.write = (t1state == ENTRY_STATE_WRITE) ? 1 : 0;

    if (t0state == ENTRY_STATE_WRITE &&
        t1state == ENTRY_STATE_WRITE)
        err->cases.shmemHazard.common.hazardType = CU_RACECHECK_HAZARD_WAW;
    else if (t0state == ENTRY_STATE_WRITE &&
             t1state == ENTRY_STATE_READ)
        err->cases.shmemHazard.common.hazardType = CU_RACECHECK_HAZARD_RAW;
    else if (t0state == ENTRY_STATE_READ &&
             t1state == ENTRY_STATE_WRITE)
        err->cases.shmemHazard.common.hazardType = CU_RACECHECK_HAZARD_WAR;

    if (err->cases.shmemHazard.common.hazardType == CU_RACECHECK_HAZARD_NONE) {
        CU_ERROR_PRINT(("Hazard type is invalid\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* Some filters are setup on the device. Check the pad region for these */
    flags = (uint32_t) buf->flags;

    /* Update these filters */
    err->cases.shmemHazard.common.filterType = CU_RACECHECK_FILTER_NONE;

    if ((flags & CU_RACECHECK_FILTER_WARP_PROG) &&
        err->cases.shmemHazard.thread0.rawPC != err->cases.shmemHazard.thread1.rawPC)
        err->cases.shmemHazard.common.filterType |= CU_RACECHECK_FILTER_WARP_PROG;

    if (flags & CU_RACECHECK_FILTER_SAME_THREAD)
        err->cases.shmemHazard.common.filterType |= CU_RACECHECK_FILTER_SAME_THREAD;

    if ((flags & CU_RACECHECK_FILTER_SAME_DATA) &&
        err->cases.shmemHazard.common.hazardType == CU_RACECHECK_HAZARD_WAW)
        err->cases.shmemHazard.common.filterType |= CU_RACECHECK_FILTER_SAME_DATA;

    return CUDA_SUCCESS;
}

static CUresult
drainSMBuffer(MCcontext *mcctx, uint32_t vsm)
{
    CUresult res = CUDA_SUCCESS;
    RCdevBufferHeader *hdr;
    RCdevBufferEntry *entry;
    uint32_t hdrSize = 0;
    uint32_t perSMSize = 0;
    char *entry_end = NULL;
    CUmemcheck_record rec;
    CUmemcheck_error_record *err = NULL;
    CCBacktrace *ccbt = NULL;
    MClaunch *launch = NULL;
    CCracecheckCtxData *rcData = NULL;
    MCfunc *entryFunc = NULL;
    bool hasIncompleteRecords = false;

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    rcData = racecheckGetContextData(mcctx);
    if (!rcData) {
        CU_ERROR_PRINT(("Invalid rcdata\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    hdrSize = sizeof(RCdevBufferHeader);

    perSMSize = (RC_DEV_BUFFER_ENTRIES * sizeof(RCdevBufferEntry) + hdrSize);

    hdr = (RCdevBufferHeader*)((char*)rcData->errorEntry.dev.hPtr + vsm*perSMSize);
    if (hdr->next_offset < perSMSize)
        entry_end = (char*)hdr + hdr->next_offset;
    else
        entry_end = (char*)hdr + perSMSize;

    CU_DEBUG_PRINT(("Header read for vsm:%u. header_size:0x%x, next_offset:0x%x\n",
                    vsm, hdr->header_size, hdr->next_offset));

    entry = (RCdevBufferEntry*)((char*)hdr + hdr->header_size);
    for (; (char*)entry < entry_end; ++entry) {
        if (!entry->tid_state0 || !entry->tid_state1)
            continue;

        memset(&rec, 0, sizeof(rec));
        res = convertToHostRecord(mcctx, entry, &rec);
        if (res == CUDA_ERROR_LAUNCH_OUT_OF_RESOURCES) {
            hasIncompleteRecords = true;
            continue;
        }
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to convert to host record\n"));
            continue;
        }

        err = &rec.cases.error;

        if (!err->cases.shmemHazard.thread0.rawPC ||
            !err->cases.shmemHazard.thread1.rawPC) {
            CU_ERROR_PRINT(("Record is probably bad. Skipping\n"));
            continue;
        }

#ifndef RELEASE
        if (mcctx->gvars->options.rawOutput) {
            printRaceRecord(&err->cases.shmemHazard);
        }
#endif
        launch = mcLaunchGetInContext(mcctx, entry->gridId);
        if (launch) {
            ccbt = launch->bt;
            entryFunc = launch->rec->func;
        }

        res = addHazardRecord(mcctx, &rec, entryFunc, ccbt);
        if (res != CUDA_SUCCESS)
            CU_ERROR_PRINT(("Failed to add record. Soldiering on\n"));
    }

    if (hasIncompleteRecords &&
        !mcctx->gvars->racecheckOverflowDetected) {
        printInternalError(CU_MEMCHECK_WARNING_RACECHECK_OVERFLOW, mcctx->gvars);
        mcctx->gvars->racecheckOverflowDetected = true;
    }

    // Nuke the entries. Partially written entries will be flushed later
    memset((char*)entry, 0, (size_t)(entry_end - (char*)entry));

    hdr->next_offset = hdr->header_size;
    return CUDA_SUCCESS;
}

CUresult
racecheckDrainBuffer(MCcontext *mcctx)
{
    CUresult res = CUDA_SUCCESS;
    uint32_t vsm;
    uint32_t numSm = 0;
    CCracecheckCtxData *ctxData = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid argument\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = racecheckGetContextData(mcctx);
    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid rc data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    numSm = ctxData->numSm;
    for (vsm = 0 ; vsm < numSm; ++vsm) {
        res = drainSMBuffer(mcctx, vsm);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to drain buffer for sm:%u\n", vsm));
            return res;
        }
    }

    res = finalizeRaceRecords(mcctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to add race error records\n"));
        return res;
    }

    res = flushRecords(mcctx, &mcctx->gvars->output);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to flush output\n"));
        return res;
    }
    return res;
}

static CUresult
drainPartialBufferEntry(MCcontext *mcctx, uint32_t vsm, uint32_t wp, uint32_t ln)
{
    CudbgDevice dev;
    CUresult res = CUDA_SUCCESS;
    CUDBGResult dbgRes = CUDBG_SUCCESS;
    RCdevTableEntryCommon *devTableEntry = NULL;
    RCdevTableEntryCommon localDevTableEntry = {0};
    uint32_t devTblEntrySize = 0;
    CuDim3   blockIdx;
    uint32_t addr_lo, addr_hi;
    uint64_t addr = 0;
    uint64_t tableDptr = 0;
    char *tableHostPtr = NULL;
    uint32_t t0state = 0;
    uint32_t t1state = 0;
    uint32_t aword, asize, actr, awordoff;
    CUmemcheck_record err = {0};
    CUmemcheck_record_type_shmemHazard *haz = NULL;
    MClaunch *launch = NULL;
    CCBacktrace *ccbt = NULL;
    CCracecheckCtxData *ctxData = NULL;
    CCracecheckRecData *recData = NULL;
    MCfunc *entryFunc = NULL;
    Grid grid;
    bool tableIsPinned = false;
    uint64_t thread0Pc = 0;
    uint64_t thread1Pc = 0;
    MCfunc *mcfunc = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid context\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    devTblEntrySize = getRCdevTableEntrySize(mcctx);
    ctxData = racecheckGetContextData(mcctx);

    if (!createNewErrorRecord(CU_MEMCHECK_RECORD_SHMEM_HAZARD, &err)) {
        CU_ERROR_PRINT(("Failed to initialize error type\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    haz = &err.cases.error.cases.shmemHazard;
    dev = mcctx->dev;

    // Get the grid
    grid = haloStateDeviceGetGrid(dev, dev->smState[vsm].warp[wp].gridId64);
    if (!grid) {
        CU_ERROR_PRINT(("Failed to find grid\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Read the PC
    dbgRes = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                       FERMI_LMEM_HI_MEMCHECK_SCRATCH +
                                       RACE_LMEM_PC,
                                       &thread1Pc,
                                       sizeof(thread1Pc));

    if (getArchFromSmVer(mcctx->sm_version) < MC_TOOL_MODE_ARCH_SM70) {
        /* Pre-volta has 32bit PCs and we don't set the HI field in some cases */
        thread1Pc &= 0x00000000ffffffff;
    }

    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read pc from lmem\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    mcfunc = mcContextGetFuncByAddr(mcctx, thread1Pc);
    if (!mcfunc) {
        CU_DEBUG_PRINT(("Could not find function for pc 0x%" PRIx64 "\n", thread1Pc));
    }

    haz->thread1.rawPC = thread1Pc;
    if (mcfunc)
        haz->thread1.pc = (uint32_t)(uintptr_t)(thread1Pc - mcfunc->mem.dev.dPtr);
    else
        haz->thread1.pc = (uint32_t)thread1Pc;

    // Read the cur state
    dbgRes = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                       FERMI_LMEM_HI_MEMCHECK_SCRATCH +
                                       RACE_LMEM_CUR_STATE,
                                       &t1state,
                                       sizeof(t1state));
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read pc from lmem\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    t1state &= ENTRY_STATE_STATUS_MASK;

    // Read the block id
    dbgRes = dev->halo.read_blockIdx(dev, vsm, wp, &blockIdx);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read block index\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    haz->common.blockIdxX = blockIdx.x;
    haz->common.blockIdxY = blockIdx.y;
    haz->common.blockIdxZ = blockIdx.z;

    // Read the thread id
    dbgRes = dev->halo.read_threadIdx(dev, vsm, wp, ln,
                                      0,
                                      &haz->thread1.threadIdxX,
                                      &haz->thread1.threadIdxY,
                                      &haz->thread1.threadIdxZ);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read threadIdx for sm:%u wp:%u ln:%u\n",
                        vsm, wp, ln));
        return CUDA_ERROR_UNKNOWN;
    }

    // Read the address from reg R2 and R3
    dbgRes = dev->halo.readRegisterRange(dev, vsm, wp, ln, 2, &addr_lo, 1, false);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read register R2 for sm:%u wp:%u ln:%u\n",
                        vsm, wp, ln));
        return CUDA_ERROR_UNKNOWN;
    }

    dbgRes = dev->halo.readRegisterRange(dev, vsm, wp, ln, 3, &addr_hi, 1, false);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read register R3 for sm:%u wp:%u ln:%u\n",
                        vsm, wp, ln));
        return CUDA_ERROR_UNKNOWN;
    }

    // Read the table dptr from lmem
    dbgRes = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                       FERMI_LMEM_HI_MEMCHECK_SCRATCH +
                                       RACE_LMEM_TABLE_LO,
                                       &tableDptr,
                                       sizeof(tableDptr));
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read table dptr from lmem\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = racecheckGetRecDataFromTrackingTablePtr(mcctx, tableDptr);
    if (recData == NULL) {
        CU_ERROR_PRINT(("Failed to find the tracking table for address 0x%" PRIx64 "\n", tableDptr));
        return CUDA_ERROR_UNKNOWN;
    }

    tableHostPtr = (char *)recData->trackingTable.dev.hPtr;
    if (recData->trackingTable.devseg == HALO_MEM_SEG_PINNED_SYSMEM) {
        tableIsPinned = true;
    }
    else {
        tableIsPinned = false;
        devTableEntry = &localDevTableEntry;
    }

    // Calculate pointer
    addr = (((uint64_t)addr_hi << 32) | addr_lo);
    haz->common.address = (uint32_t)((addr - tableDptr) / devTblEntrySize);

    // If the table is pinned sysmem, just deref the host pointer
    // If its in device memory, read it using BAR1
    if (tableIsPinned) {
        // Renormalize addr to host
        addr = addr - tableDptr + (uint64_t)(uintptr_t)(tableHostPtr);

        devTableEntry = (RCdevTableEntryCommon*)((uintptr_t)addr);
        res = getRCdevTableEntryPc(mcctx, devTableEntry, &thread0Pc);
    } else {
        uint8_t *entryBfr = NULL;

        entryBfr = (uint8_t*)calloc(1, devTblEntrySize);
        if (!entryBfr)
            return CUDA_ERROR_OUT_OF_MEMORY;

        dbgRes = dev->halo.readGenericMemory(dev->activeContext, vsm, wp, ln,
                                             addr, entryBfr, devTblEntrySize);
        if (dbgRes != CUDBG_SUCCESS) {
            CU_ERROR_PRINT(("Failed to read devTableEntry. dbgRes=%u\n", dbgRes));
            free(entryBfr);
            return CUDA_ERROR_UNKNOWN;
        }

        res = getRCdevTableEntryPc(mcctx, (RCdevTableEntryCommon*)entryBfr, &thread0Pc);
        memcpy(devTableEntry, entryBfr, sizeof(*devTableEntry));

        free(entryBfr);
    }

    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to get dev table entry pc.\n"));
        return res;
    }

    mcfunc = mcContextGetFuncByAddr(mcctx, thread0Pc);
    if (!mcfunc) {
        CU_DEBUG_PRINT(("Could not find function for pc 0x%" PRIx64 "\n", thread0Pc));
    }

    // Read the same for the old entry
    haz->thread0.rawPC = thread0Pc;
    if (mcfunc)
        haz->thread0.pc = (uint32_t)(uintptr_t)(thread0Pc - mcfunc->mem.dev.dPtr);
    else
        haz->thread0.pc = (uint32_t)thread0Pc;

    t0state = devTableEntry->tid_state & ENTRY_STATE_STATUS_MASK;
    haz->thread0.threadIdxX = devTableEntry->tid_state & 0x07ff;
    haz->thread0.threadIdxY = (devTableEntry->tid_state >> 16) & 0x03ff;
    haz->thread0.threadIdxZ = (devTableEntry->tid_state >> 26) & 0x003f;

    // Handle the read and write data
    // Read the current value
    dbgRes = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                       FERMI_LMEM_HI_MEMCHECK_SCRATCH +
                                       RACE_LMEM_CUR_VALUE,
                                       &haz->common.readData,
                                       sizeof(haz->common.readData));
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read cur value from lmem \n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // Read the asize (combined in PRED/ASIZE entry)
    dbgRes = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                       FERMI_LMEM_HI_MEMCHECK_SCRATCH +
                                       RACE_LMEM_ASIZE,
                                       &asize,
                                       sizeof(asize));
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read asize from lmem\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    asize = asize >> RACE_LMEM_ASIZE_SHIFT_BITS;

    dbgRes = dev->halo.readRegisterRange(dev, vsm, wp, ln, 1, &actr, 1, false);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read register R1 for sm:%u wp:%u ln:%u\n",
                        vsm, wp, ln));
        return CUDA_ERROR_UNKNOWN;
    }
    awordoff = (asize - actr) & ~0x3;

    dbgRes = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                       FERMI_LMEM_HI_MEMCHECK_SCRATCH +
                                       RACE_LMEM_WRITE_0 +
                                       awordoff,
                                       &aword,
                                       sizeof(aword));
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to read aword from lmem (offset:%u)\n", awordoff));
        return CUDA_ERROR_UNKNOWN;
    }

    aword >>= (asize - actr) & 0x3;
    aword &= 0xff;

    haz->common.writeData = aword;

    if (t0state == ENTRY_STATE_WRITE &&
        t1state == ENTRY_STATE_WRITE)
        haz->common.hazardType = CU_RACECHECK_HAZARD_WAW;
    else if (t0state == ENTRY_STATE_WRITE &&
             t1state == ENTRY_STATE_READ)
        haz->common.hazardType = CU_RACECHECK_HAZARD_RAW;
    else if (t0state == ENTRY_STATE_READ &&
             t1state == ENTRY_STATE_WRITE)
        haz->common.hazardType = CU_RACECHECK_HAZARD_WAR;

    if (haz->common.hazardType == CU_RACECHECK_HAZARD_NONE) {
        CU_ERROR_PRINT(("Hazard type is invalid, ignoring\n"));
        return CUDA_SUCCESS;
    }

    haz->thread0.write = (t0state == ENTRY_STATE_WRITE) ? 1 : 0;
    haz->thread1.write = (t1state == ENTRY_STATE_WRITE) ? 1 : 0;

    // Write the gridid
    haz->common.gridid = dev->smState[vsm].warp[wp].gridId64;

    // For the backtrace
    launch = mcLaunchGetInContext(mcctx, dev->smState[vsm].warp[wp].gridId64);
    if (launch) {
        ccbt = launch->bt;
        entryFunc = launch->rec->func;
    }

    /* Note : For CNP support, we need to do some hackery at this point */

    /* Update the filter flags */
    res = updateFilterState(&err, 0, 0, 0);
    if (res != CUDA_SUCCESS)
        CU_ERROR_PRINT(("Failed to update error state\n"));

    res = addHazardRecord(mcctx, &err, entryFunc, ccbt);
    if (res != CUDA_SUCCESS)
        CU_ERROR_PRINT(("Failed to add record.\n"));

    return res;
}

CUresult
racecheckTrapHandlerCallback(MCcontext *mcctx, CUmemobj *scratchpad, uint32_t smError)
{
    CUDBGResult dbgRes = CUDBG_SUCCESS;
    uint32_t vsm, wp, ln;
    CUwarpBitmask validWarps;
    CUwarpBitmask brokenWarps;
    CUDBGException_t laneException = (CUDBGException_t)0;
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    res = mcContextHaloCheckTrapStateInitialize(mcctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to initialize trap state in HALO\n"));
        return res;
    }

    mcctx->dev->halo.clearSMState(mcctx->dev);

    dbgRes = mcctx->dev->halo.collectDeviceState(mcctx->dev, false, NULL);
    if (dbgRes != CUDBG_SUCCESS) {
        CU_ERROR_PRINT(("Failed to collect device state\n"));
        res = CUDA_ERROR_UNKNOWN;
        goto cleanup_and_return;
    }


    for (vsm = 0 ; vsm < mcctx->dev->halo.deviceInfo.numSMs; ++vsm) {
        res = drainSMBuffer(mcctx, vsm);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to drain buffer for SM : %s\n"));
            return res;
        }

        if (!warpBitmaskAny(&mcctx->dev->smState[vsm].state.tidValid))
            continue;

        warpBitmaskAssign(&validWarps,&mcctx->dev->smState[vsm].state.tidValid);
        warpBitmaskAssign(&brokenWarps, &mcctx->dev->smState[vsm].state.brokenwarps);
        for (wp = 0; wp < mcctx->dev->halo.deviceInfo.numWarpsPrSM;
             ++wp) {

            // examine only valid warps on sm
            if (!warpBitmaskGetBits(&validWarps, wp, 1))
                continue;

            if (warpBitmaskGetBits(&brokenWarps, wp, 1) &&
                !mcctx->gvars->racecheckOverflowDetected) {
                mcctx->gvars->tools.trap->SetSMHandledSingleWarp(mcctx->cuctx, vsm, wp);
            }

            for (ln = 0; ln < 32; ++ln) {
                laneException = mcctx->dev->smState[vsm].warp[wp].laneExceptions[ln];

                // examine only lanes with a valid exception
                if (laneException != CUDBG_EXCEPTION_LANE_ILLEGAL_ADDRESS)
                    continue;

                CU_TRACE_PRINT(("Partial buffer at : vsm/wp/ln %u/%u/%u\n",vsm, wp, ln));
                res = drainPartialBufferEntry(mcctx, vsm, wp, ln);
                if (res != CUDA_SUCCESS) {
                    CU_ERROR_PRINT(("Failed to drain partial entry. Soldiering on\n"));
                }
            }

        }
    }

    res = finalizeRaceRecords(mcctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to add records to context\n"));
        return res;
    }

    res = flushRecords(mcctx, &mcctx->gvars->output);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to flush output\n"));
        goto cleanup_and_return;
    }

    CU_TRACE_PRINT(("Setting action to continue\n"));
    mcctx->gvars->tools.trap->SetTrapAckAction(mcctx->cuctx,
                                               CU_TOOLS_TRAP_ACK_CONTINUE);

cleanup_and_return:

    mcContextHaloCheckTrapStateFinalize(mcctx);

    return res;

}

CUresult
racecheckTrapHandlerEndCallback(MCcontext *mcctx, CUmemobj *scratchpad, uint32_t smError)
{
    /* Do nothing for now. In the future, for CNP + racecheck support, this will need to ensure
       that BPT.TRAP2 are set as handled */

    return CUDA_SUCCESS;
}
