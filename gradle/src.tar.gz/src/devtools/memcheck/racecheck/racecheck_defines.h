/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef RACECHECK_DEFINES_H
#define RACECHECK_DEFINES_H

#define ENTRY_STATE_MASK            0x0000F800
#define ENTRY_STATE_MASKINV         0xFFFF07FF
#define ENTRY_STATE_STATUS_MASK     0x00003000
#define ENTRY_STATE_RW_MASK         0x00001000
#define ENTRY_STATE_LOCKBIT_MASK    0x00000800
#define ENTRY_STATE_LOCKBIT_MASKINV 0xFFFFF7FF

#define ENTRY_STATE_NONE            0
#define ENTRY_STATE_READ            0x00002000
#define ENTRY_STATE_WRITE           0x00003000
#define ENTRY_STATE_MULTI_WARP      0x00006000
#define ENTRY_STATE_WARPSYNC        0x00008000
#define ENTRY_STATE_LOCKED          0x00000800
#define ENTRY_STATE_WARPSYNC_MASKINV 0xFFFF7FFF

#define FERMI_SMEM_MASK_INV         0xFF000000
#define FERMI_SMEM_MASK             0x00FFFFFF
#define FERMI_SMEM_WIN_BASE         0x01000000

#define FILTER_SAME_THREAD         0x00000001
#define FILTER_SAME_DATA           0x00000002
#define FILTER_WARP_PROG           0x00000004
#define FILTER_RECORD_VALID        0x00000008

#endif
