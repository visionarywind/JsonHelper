/*
 * Copyright 2007-2012 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: racecheck_group.h
 *
 *   Description:
 *       Function declarations for Racecheck group analysis
 *
 ******************************************************************************/

#ifndef _RACECHECK_GROUP_H
#define _RACECHECK_GROUP_H

#include "cudamemcheck.h"
#include "memcheck_types.h"
#include "memcheck_tool_modes.h"

#include "tools_shared_graph.h"

typedef enum {
    RG_WEIGHT_NONE      = 0,
    RG_WEIGHT_INFO      = 10,
    RG_WEIGHT_WARNING   = 20,
    RG_WEIGHT_ERROR     = 30,
} RaceGroupWeight;

CUresult generateGroupRecords(CUmemcheck_record *listHead, MCcontext *mcctx);

/* Accessor functions for record output */
uint32_t       rcgvGetPC(toolsGraphVertex *gvtx);
const char*    rcgvGetFuncName(toolsGraphVertex *gvtx);
const char*    rcgvGetFileName(toolsGraphVertex *gvtx);
uint32_t       rcgvGetLine(toolsGraphVertex *gvtx);
uint32_t       rcgvGetWrite(toolsGraphVertex *gvtx);
uint32_t       rcgeGetCount(toolsGraphEdge *gedge);
uint32_t       rcgeGetHazardMask(toolsGraphEdge *gedge);
RaceGroupWeight rcgeGetWeight(toolsGraphEdge *gedge);
#endif
