/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef RACECHECK_STRUCT_LAYOUTS_H
#define RACECHECK_STRUCT_LAYOUTS_H


/* RCdevBufferEntry_st
    struct RCdevBufferEntry_st {
        uint32_t address;
        uint16_t blockIdxZ;
        uint16_t blockIdxY;
        uint32_t blockIdxX;
        uint16_t flags;
        uint8_t  data0;
        uint8_t  data1;
        uint32_t pc0;
        uint32_t pc0_hi;
        uint32_t tid_state0;
        uint32_t pc1;
        uint32_t pc1_hi;
        uint32_t tid_state1;
        union {
            uint64_t gridId;
            struct{
                uint32_t gridIdLo;
                uint32_t gridIdHi;
            };
        }
    };
*/

#define offset_RCdevBufferEntry_address     0x00
#define offset_RCdevBufferEntry_blockIdxZ   0x04
#define offset_RCdevBufferEntry_blockIdxY   0x06
#define offset_RCdevBufferEntry_blockIdxX   0x08
#define offset_RCdevBufferEntry_flags       0x0c
#define offset_RCdevBufferEntry_data0       0x0e
#define offset_RCdevBufferEntry_data1       0x0f
#define offset_RCdevBufferEntry_pc0         0x10
#define offset_RCdevBufferEntry_pc0_hi      0x14
#define offset_RCdevBufferEntry_tid_state0  0x18
#define offset_RCdevBufferEntry_pc1         0x1c
#define offset_RCdevBufferEntry_pc1_hi      0x20
#define offset_RCdevBufferEntry_tid_state1  0x24
#define offset_RCdevBufferEntry_gridId_Lo   0x28
#define offset_RCdevBufferEntry_gridId_Hi   0x2c

#define sizeof_RCdevBufferEntry             0x30

/* RCdevBufferHeader_st
    struct RCdevBufferHeader_st {
        uint32_t next_offset;
        uint32_t entry_size;
        uint32_t buffer_size;
        uint32_t header_size;
    };
*/
#define offset_RCdevBufferHeader_next_offset 0x00
#define offset_RCdevBufferHeader_entry_size  0x04
#define offset_RCdevBufferHeader_buffer_size 0x08
#define offset_RCdevBufferHeader_header_size 0x0c

#define sizeof_RCdevBufferHeader             0x10

/* RCdevTableEntry_st

    struct RCdevTableEntry_st {
        uint32_t tid_state;
        uint32_t pc;
    };
*/
#define offset_RCdevTableEntry_tid_state 0x00
#define offset_RCdevTableEntry_pc        0x04

#define sizeof_RCdevTableEntry           0x08

/* RCdevTableEntry2_st (for Volta+)

    struct RCdevTableEntry2_st {
        uint32_t tid_state;
        uint32_t pc;
        uint32_t pc_hi;
        uint32_t padding;
    };
*/
#define offset_RCdevTableEntry2_tid_state 0x00
#define offset_RCdevTableEntry2_pc        0x04
#define offset_RCdevTableEntry2_pc_hi     0x08
#define offset_RCdevTableEntry2_padding   0x0c

#define sizeof_RCdevTableEntry2           0x10

#endif
