/*
 * Copyright 2007-2012 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: racecheck_group.c
 *
 *   Description:
 *       Function definitions for Racecheck group analysis
 *
 ******************************************************************************/

#include "cudamemcheck.h"
#include "memcheck_types.h"
#include "memcheck_inst_types.h"
#include "memcheck_tool_modes.h"
#include "racecheck_group.h"
#include "check_core.h"

#include "tools_shared_list.h"
#include "tools_shared_hashmap.h"
#include "tools_shared_graph.h"
#include "cuda_macros.h"

#include "check_format.h"
#include "memcheck_error.h"

typedef struct raceGroup_st raceGroup;
typedef struct raceGraph_st raceGraph;
typedef struct raceEdgeData_st raceEdgeData;
typedef struct raceVertexData_st raceVertexData;


struct raceGroup_st {
    /* Parent graph */
    raceGraph *graph;

    /* List of components */
    tList *componentList;
};

struct raceGraph_st {
    /* PC -> vertex map */
    tHashMap *pcToVertex;

    /* Extra Properties */

    /* Unique grid Id */
    uint64_t gridId;

    /* Function name */
    const char *kernelName;

    /* Parent group */
    raceGroup *group;

    /* Graph pointer */
    toolsGraph *tGraph;
};

struct raceVertexData_st {
    /* PC of access, also primary key */
    uint64_t rawPC;

    /* Offset in the function */
    uint32_t offset;

    /* Whether this location is a write */
    uint32_t write;

    /* Function name */
    const char *funcName;

    /* File and line number */
    const char *fileName;
    uint32_t line;

    /* Graph Vertex */
    toolsGraphVertex *tVtx;
};

struct raceEdgeData_st {
    /* Weight assigned by heuristic */
    RaceGroupWeight weight;

    /* Types of hazards seen */
    uint32_t hazardTypeMask;

    /* Address Set of collisions */
    tHashSet *addressSet;

    tHashSet *gridIdSet;

    uint32_t count;
};

/* Forward declarations */

static CUresult addVertexToGraph(raceGraph *graph, uint64_t addr, uint32_t offset, const char *funcName, const char *fileName, uint32_t line, uint32_t write);
static CUresult addEdgeToGraph(raceGraph *graph, uint64_t srcaddr, uint64_t dstaddr, uint32_t hazardType, uint32_t hazardFlags, uint32_t shmemaddress, uint64_t gridid);


/* Functions */
static CUresult
edgeDataAddHazard(raceEdgeData *edgeData, uint32_t hazardType, uint32_t shmemAddress, uint64_t gridid)
{
    TOOLSresult tres = TOOLS_SUCCESS;

    if (!edgeData) {
        CU_ERROR_PRINT(("Invalid edgeData\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (!edgeData->addressSet) {
        CU_ERROR_PRINT(("Missing address set\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    tres = toolsHashSetInsert(edgeData->addressSet, (void*)(uintptr_t)shmemAddress);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to insert data : 0x%x\n", shmemAddress));
        return CUDA_ERROR_UNKNOWN;
    }

    tres = toolsHashSetInsert(edgeData->gridIdSet, (void*)(uintptr_t)gridid);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to insert gridid\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    edgeData->hazardTypeMask |= (1U << hazardType);

    return CUDA_SUCCESS;
}

static void
destroyEdgeData(raceEdgeData* edgeData)
{
    if (!edgeData)
        return;

    if (edgeData->gridIdSet) {
        toolsHashSetDelete(edgeData->gridIdSet, NULL, NULL);
        edgeData->gridIdSet = NULL;
    }

    if (edgeData->addressSet) {
        toolsHashSetDelete(edgeData->addressSet, NULL, NULL);
        edgeData->addressSet = NULL;
    }

    free(edgeData);

    return;
}

static raceEdgeData*
createEdgeData(RaceGroupWeight start_wt, uint32_t hazardType, uint32_t shmemAddress, uint64_t gridid)
{
    raceEdgeData *edgeData = NULL;
    CUresult res = CUDA_SUCCESS;

    edgeData = (raceEdgeData *)calloc(1, sizeof(*edgeData));
    if (!edgeData)
        return NULL;

    edgeData->addressSet = toolsHashSetNew(toolsUint32HashFun, toolsUint32EqualFun,16);
    if (!edgeData->addressSet)
        goto error;

    edgeData->gridIdSet = toolsHashSetNew(toolsUint32HashFun, toolsUint32EqualFun,16);
    if (!edgeData->gridIdSet)
        goto error;

    edgeData->weight     = start_wt;
    res = edgeDataAddHazard(edgeData, hazardType, shmemAddress, gridid);
    if (res != CUDA_SUCCESS)
        goto error;

    return edgeData;

error:

    destroyEdgeData(edgeData);
    return NULL;
}

static void
destroyVertexData(raceVertexData *vtxData)
{
    if (!vtxData)
        return;

    free(vtxData);
}

static raceVertexData*
createVertexData(uint64_t rawpc, uint32_t offset, const char *funcName, const char *fileName, uint32_t line, uint32_t write)
{
    raceVertexData *vtxData = NULL;

    vtxData = (raceVertexData *)calloc(1, sizeof(*vtxData));
    if (!vtxData)
        return NULL;

    /* Line number only matters if we have a file */
    vtxData->funcName = funcName;
    vtxData->fileName = fileName;
    vtxData->line = line;
    vtxData->write = write;

    vtxData->offset = offset;
    vtxData->rawPC = rawpc;

    return vtxData;
}

static void
destroyGraphData(raceGraph* data)
{
    if (!data)
        return;

    if (data->pcToVertex) {
        /* There are 2 cases where this can be called :
           Case 1 : Failure to create data, in which case there are no vertices to delete
           Case 2 : As part of final delete, in which case, the vertex iterator has already destroyed the vertices  */
        toolsHashMapDelete(data->pcToVertex, NULL, NULL);
        data->pcToVertex = NULL;
    }

    free(data);
}

static raceGraph*
createGraphData(uint64_t gridId, raceGroup *group)
{
    raceGraph *graphData = NULL;

    graphData = (raceGraph *)calloc(1, sizeof(*graphData));
    if (!graphData)
        return NULL;

    graphData->pcToVertex = toolsHashMapNew(toolsUint32HashFun, toolsUint64EqualFun, 16);
    if (!graphData->pcToVertex)
        goto error;

    graphData->gridId = gridId;
    graphData->group  = group;

    return graphData;

error:
    destroyGraphData(graphData);
    return NULL;
}

/*****/

/*****/
static CUresult
destroyGraph(raceGraph *graph)
{
    CUresult res = CUDA_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!graph)
        return CUDA_SUCCESS;

    if (graph->tGraph) {
        tres = toolsGraphDestroy(graph->tGraph,
                                 (tSingleFun)destroyGraphData, NULL,
                                 (tSingleFun)destroyVertexData, NULL,
                                 (tSingleFun)destroyEdgeData, NULL);
        if (tres != TOOLS_SUCCESS) {
            CU_ERROR_PRINT(("Failed to destroy graph\n"));
            res = CUDA_ERROR_UNKNOWN;
        }
    }
    else
        destroyGraphData(graph);

    return res;
}

static raceGraph*
createGraph(raceGroup *group, uint64_t gridId)
{
    raceGraph *gd = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;

    gd = createGraphData(gridId, group);
    if (!gd) {
        CU_ERROR_PRINT(("Failed to create graph data\n"));
        return NULL;
    }

    tres = toolsGraphCreate(&gd->tGraph, gd);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to create graph\n"));
        destroyGraphData(gd);
        return NULL;
    }

    if (group) {
        group->graph = gd;
    }

    return gd;
}

static raceVertexData*
getVertexByAddr(raceGraph *graph, uint64_t addr)
{
    if (!graph || !addr)
        return NULL;

    return (raceVertexData*)toolsHashMapFind(graph->pcToVertex, tHashMapNumToKey(addr));
}

static CUresult
addVertexToGraph(raceGraph *graph, uint64_t rawpc, uint32_t offset, const char *funcName, const char *fileName, uint32_t line, uint32_t write)
{
    raceVertexData *vtxData = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;

    if (!graph || !graph->tGraph) {
        return CUDA_ERROR_UNKNOWN;
    }

    if (getVertexByAddr(graph, rawpc))
        return CUDA_SUCCESS;

    /* New vertex */
    vtxData = createVertexData(rawpc, offset, funcName, fileName, line, write);
    if (!vtxData)
        return CUDA_ERROR_UNKNOWN;

    tres = toolsGraphCreateVertex(graph->tGraph, vtxData, &vtxData->tVtx);
    if (tres != TOOLS_SUCCESS)
        goto error;

    tres = toolsHashMapInsert(graph->pcToVertex, tHashMapNumToKey(rawpc), (void*)vtxData);
    if (tres != TOOLS_SUCCESS)
        goto error;

    return CUDA_SUCCESS;

error:
    destroyVertexData(vtxData);
    return CUDA_ERROR_UNKNOWN;
}

static raceEdgeData*
getEdgeByAddr(raceGraph *graph, uint64_t srcaddr, uint64_t dstaddr)
{
    raceVertexData *srcVtx = NULL, *dstVtx = NULL;
    toolsGraphEdge *tEdge = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;

    if (!graph || !graph->tGraph)
        return NULL;

    srcVtx = getVertexByAddr(graph, srcaddr);
    dstVtx = getVertexByAddr(graph, dstaddr);

    if (!srcVtx || !dstVtx)
        return NULL;

    tres = toolsGraphFindEdge(graph->tGraph, srcVtx->tVtx, dstVtx->tVtx, &tEdge);
    if (tres != TOOLS_SUCCESS)
        return NULL;

    return (raceEdgeData*)(toolsGraphEdgeGetData(tEdge));
}

typedef enum {
    DEFAULT_WT = 100,
    NEW_ADDRESS_WT = 20,
    MULTI_TYPE_FACTOR = 5,
    WARP_LEVEL_WT = 40,
    SAME_DATA_WT = 30,
    SAME_THREAD_WT = 0,
} edgeWeights;

static CUresult
reweightEdge(raceEdgeData *edge, uint32_t hazardType, uint32_t hazardFlags, uint32_t shmemAddress, uint64_t gridid)
{
    CUresult res = CUDA_SUCCESS;

    if (!edge)
        return CUDA_ERROR_UNKNOWN;

    if ((edge->weight <= RG_WEIGHT_INFO) &&
        ((hazardFlags & CU_RACECHECK_FILTER_SAME_DATA) ||
         (hazardFlags & CU_RACECHECK_FILTER_SAME_THREAD)))
        edge->weight = RG_WEIGHT_INFO;
    else
        if ((edge->weight <= RG_WEIGHT_WARNING) &&
            (hazardFlags & CU_RACECHECK_FILTER_WARP_PROG))
            edge->weight = RG_WEIGHT_WARNING;
        else
            edge->weight = RG_WEIGHT_ERROR;

    res = edgeDataAddHazard(edge, hazardType, shmemAddress, gridid);
    return res;
}

static CUresult
addEdgeToGraph(raceGraph *graph, uint64_t srcaddr, uint64_t dstaddr, uint32_t hazardType, uint32_t hazardFlags, uint32_t shmemaddress, uint64_t gridId)
{
    raceEdgeData *edge = NULL;
    raceVertexData *srcVtx = NULL, *dstVtx = NULL;
    CUresult res = CUDA_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;
    toolsGraphEdge *tEdge = NULL;

    if (!graph || !graph->tGraph)
        return CUDA_ERROR_UNKNOWN;

    edge = getEdgeByAddr(graph, srcaddr, dstaddr);

    /* Need to create an edge  */
    if (!edge) {
        edge = createEdgeData(RG_WEIGHT_NONE, hazardType, shmemaddress, gridId);
        if (!edge)
            return CUDA_ERROR_UNKNOWN;

        srcVtx = getVertexByAddr(graph, srcaddr);
        dstVtx = getVertexByAddr(graph, dstaddr);

        if (!srcVtx || !dstVtx) {
            destroyEdgeData(edge);
            return CUDA_ERROR_UNKNOWN;
        }

        tres = toolsGraphCreateEdge(graph->tGraph, srcVtx->tVtx, dstVtx->tVtx, edge, &tEdge);
        if (tres != TOOLS_SUCCESS) {
            destroyEdgeData(edge);
            return CUDA_ERROR_UNKNOWN;
        }
    }

    ++edge->count;

    /* Now, we have an edge, and must call the reweighting function. This adds the address
       and updates the edge weight */
    res = reweightEdge(edge, hazardType, hazardFlags, shmemaddress, gridId);
    if (res != CUDA_SUCCESS)
        return res;

    return res;
}

static CUresult
createGroup(raceGroup **pGroup)
{
    raceGroup *group = NULL;

    if (!pGroup) {
        CU_ERROR_PRINT(("Invalid group\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    group = (raceGroup *)calloc(1, sizeof(*group));
    if (!group) {
        CU_ERROR_PRINT(("Invalid group\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *pGroup = group;
    return CUDA_SUCCESS;
}

static CUresult
destroyGroup(raceGroup **pGroup)
{
    raceGroup *group = NULL;
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!pGroup) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    group = *pGroup;
    if (!group) {
        CU_DEBUG_PRINT(("Nothing to do\n"));
        return CUDA_SUCCESS;
    }

    if (group->graph) {
        res = destroyGraph(group->graph);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to destroy graph \n"));
            return res;
        }
    }
    return CUDA_SUCCESS;
}

static CUresult
addThreadInfo(raceGraph *graph, CUmemcheck_record *rec, CUmemcheck_record_type_hazardThreadInfo *thread)
{
    const char *funcName = NULL, *fileName = NULL;
    uint32_t line = 0;
    CUresult res = CUDA_SUCCESS;

    if (!graph || !rec || !thread)
        return CUDA_ERROR_UNKNOWN;

    funcName = getStringInRecordByIndex(rec, thread->funcNameIx);
    fileName = getStringInRecordByIndex(rec, thread->fileNameIx);
    line     = thread->line;

    res = addVertexToGraph(graph,
                           thread->rawPC,
                           thread->pc,
                           funcName,
                           fileName,
                           line,
                           thread->write);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to add record\n"));
        return res;
    }

    return res;
}

static CUresult
addHazard(raceGroup *group, CUmemcheck_record *rec)
{
    raceGraph *graph = NULL;
    CUresult res = CUDA_SUCCESS;
    CUmemcheck_error_record *err = NULL;

    CU_TRACE_FUNCTION();

    if (!group || !rec)
        return CUDA_ERROR_UNKNOWN;

    err = &rec->cases.error;

    graph = group->graph;
    if (!graph) {
        graph = createGraph(group, err->cases.shmemHazard.common.gridid);
        if (!graph)
            return CUDA_ERROR_UNKNOWN;
    }

    /* Convert the hazard into graph information */
    res = addThreadInfo(graph, rec, &err->cases.shmemHazard.thread0);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to add thread0\n"));
        return res;
    }

    res = addThreadInfo(graph, rec, &err->cases.shmemHazard.thread1);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to add thread 1 \n"));
        return res;
    }

    res = addEdgeToGraph(graph,
                         err->cases.shmemHazard.thread0.rawPC,
                         err->cases.shmemHazard.thread1.rawPC,
                         err->cases.shmemHazard.common.hazardType,
                         err->cases.shmemHazard.common.filterType,
                         err->cases.shmemHazard.common.address,
                         err->cases.shmemHazard.common.gridid);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to add edge to graph\n"));
        return res;
    }

    return res;
}

static CUresult
parseRecordList(raceGroup *group, CUmemcheck_record *head)
{
    CUmemcheck_record *cur = NULL;
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    for (cur = head; cur; cur = cur->next) {
        if (cur->recordclass == CU_MEMCHECK_RECORD_CLASS_ERROR &&
            cur->cases.error.errortype == CU_MEMCHECK_RECORD_SHMEM_HAZARD) {
            res = addHazard(group, cur);
            if (res != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Failed to add hazard\n"));
                return res;
            }
        }
    }

    return CUDA_SUCCESS;
}

#ifndef RELEASE

static void
dumpVert(toolsGraphVertex *gvtx)
{
    raceVertexData *vtx = NULL;

    if (!gvtx)
        return;
    vtx = (raceVertexData*) toolsGraphVertexGetData(gvtx);
    if (!vtx)
        return;

    fprintf(stderr, "\tPC: 0x%" PRIx64 " func:%s offset:%u file:%s line:%d\n",
            vtx->rawPC, vtx->funcName, vtx->offset, vtx->fileName, vtx->line);
}

static void
dumpVerts(toolsGraph *graph)
{
    toolsGraphVertexItr *vtxItr = NULL;
    toolsGraphVertex *gvtx = NULL;

    if (!graph)
        return;

    vtxItr = toolsGraphGetVertexIterator(graph);
    for (; vtxItr;
         vtxItr = toolsGraphGetVertexNext(graph, vtxItr)) {
        gvtx = toolsGraphIteratorGetVertex(vtxItr);
        dumpVert(gvtx);

    }
    return;
}

static void
dumpEdge(toolsGraphEdge *gedge)
{
    raceEdgeData *edge = NULL;
    toolsGraphVertex *gsrc = NULL, *gdst = NULL;
    raceVertexData *src = NULL, *dst = NULL;

    if (!gedge)
        return;

    gsrc = toolsGraphEdgeGetSource(gedge);
    gdst = toolsGraphEdgeGetDest(gedge);

    edge = (raceEdgeData*) toolsGraphEdgeGetData(gedge);
    if (!edge)
        return;

    src = (raceVertexData*) toolsGraphVertexGetData(gsrc);
    dst = (raceVertexData*) toolsGraphVertexGetData(gdst);

    if (!src || !dst) {
        fprintf(stderr, "source or dest is NULL!. src:%p dst:%p\n", src, dst);
        return;
    }

    fprintf(stderr, "\tEdge 0x%" PRIx64 "->0x%" PRIx64 " Weight:%u TypeMask:0x%x\n",
            src->rawPC, dst->rawPC, edge->weight, edge->hazardTypeMask);
}

static void
dumpEdges(toolsGraph *graph)
{
    toolsGraphEdgeItr *edgeItr = NULL;
    toolsGraphEdge *gedge = NULL;

    if (!graph)
        return;

    edgeItr = toolsGraphGetEdgeIterator(graph);
    for (; edgeItr;
         edgeItr = toolsGraphGetEdgeNext(graph, edgeItr)) {
        gedge = toolsGraphIteratorGetEdge(edgeItr);

        dumpEdge(gedge);
    }
    return;
}


static void
dumpGraph(toolsGraph *graph)
{
    if (!graph)
        return;

    fprintf(stderr, "**************GRAPH START*********\n");
    dumpVerts(graph);

    dumpEdges(graph);
    fprintf(stderr, "**************GRAPH DONE*********\n");
}
#endif

static CUresult
reportSelfLoops(toolsGraph *graph, MCcontext *mcctx)
{
    tList *edgeList = NULL;
    tListItr *li = NULL;
    toolsGraphEdgeItr *edgeItr = NULL;
    toolsGraphEdge *gedge = NULL;
    toolsGraphVertex *gsrc = NULL, *gdst = NULL;
    raceVertexData *src = NULL, *dst = NULL;
    raceEdgeData *edge = NULL;
    CUresult res = CUDA_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;

    if (!graph)
        return CUDA_ERROR_UNKNOWN;

    edgeList = toolsListNew();
    if (!edgeList)
        return CUDA_ERROR_OUT_OF_MEMORY;

    edgeItr = toolsGraphGetEdgeIterator(graph);
    for (; edgeItr;
         edgeItr = toolsGraphGetEdgeNext(graph, edgeItr)) {
        gedge = toolsGraphIteratorGetEdge(edgeItr);

        if (!gedge)
            continue;

        gsrc = toolsGraphEdgeGetSource(gedge);
        gdst = toolsGraphEdgeGetDest(gedge);

        edge = (raceEdgeData*) toolsGraphEdgeGetData(gedge);
        if (!edge) {
            CU_ERROR_PRINT(("Got null edge. Skipping\n"));
            continue;
        }

        src = (raceVertexData*) toolsGraphVertexGetData(gsrc);
        dst = (raceVertexData*) toolsGraphVertexGetData(gdst);

        if (!src || !dst) {
            CU_ERROR_PRINT(("Got null source or dest. Skipping\n"));
            continue;
        }

        if (src != dst)
            continue;

        CU_TRACE_PRINT(("Found self loop at PC : 0x%" PRIx64 "\n", src->rawPC));
        res = generateAnalysisRecord(graph, gsrc, mcctx);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to generate self loop record\n"));
            goto error;
        }

        /* Add it to the deletion list */
        tres = toolsListAppend(edgeList, gedge);
        if (tres != TOOLS_SUCCESS) {
            CU_ERROR_PRINT(("Failed to append to deletion list\n"));
            res = CUDA_ERROR_UNKNOWN;
            goto error;
        }
    }

    /* Now walk the deletion list, removing them from the graph component.
        Note : this does not free the edge data as the top level graph retains it
    */
    for (li = toolsListGetIterator(edgeList);
         li;
         li = toolsListGetNext(li)) {
        gedge = (toolsGraphEdge*)toolsListGetElem(li);

        if (!gedge)
            continue;

        tres = toolsGraphDestroyEdge(graph, gedge, NULL, NULL);
        if (tres != TOOLS_SUCCESS) {
            CU_ERROR_PRINT(("Failed to destroy edge\n"));
            res = CUDA_ERROR_UNKNOWN;
            goto error;
        }
    }

    if (edgeList) {
        toolsListDelete(edgeList, NULL, NULL);
        edgeList = NULL;
    }
    return CUDA_SUCCESS;

error:
    if (edgeList) {
        toolsListDelete(edgeList, NULL, NULL);
        edgeList = NULL;
    }

    return res;
}

static void
destroyComponent(toolsGraph *component)
{
    (void)toolsGraphDestroy(component, NULL, NULL, NULL, NULL, NULL, NULL);
}

static CUresult
breakComponents(toolsGraph *graph, MCcontext *mcctx);

static void
reweightVertex(tHashMap *wtmap, toolsGraphVertex *gvtx, RaceGroupWeight newweight, RaceGroupWeight *maxwt, toolsGraphVertex **maxvtx)
{
    RaceGroupWeight weight = RG_WEIGHT_NONE;

    weight = (RaceGroupWeight)(uintptr_t)(toolsHashMapFind(wtmap, tHashMapPtrToKey(gvtx)));
    if (newweight > weight) {
        weight = newweight;

        if (weight > *maxwt) {
            *maxwt = weight;
            *maxvtx = gvtx;
        }
    }

    toolsHashMapInsert(wtmap, tHashMapPtrToKey(gvtx), (void*)(uintptr_t)weight);
}

static toolsGraphVertex*
getMaxWeightVertex(toolsGraph *graph)
{
    tHashMap *vtxWt = NULL;
    toolsGraphVertex *maxvtx = NULL;
    RaceGroupWeight maxwt = RG_WEIGHT_NONE;
    toolsGraphEdgeItr *edgeItr = NULL;
    toolsGraphEdge *gedge = NULL;
    raceEdgeData *edge = NULL;
    toolsGraphVertex *gvtx = NULL;

    vtxWt = toolsHashMapNew(toolsPointerHashFun, toolsPointerEqualFun, 17);
    if (!vtxWt)
        return NULL;

    edgeItr = toolsGraphGetEdgeIterator(graph);
    for (; edgeItr;
         edgeItr = toolsGraphGetEdgeNext(graph, edgeItr)) {
        gedge = (toolsGraphEdge*)toolsGraphIteratorGetEdge(edgeItr);
        edge = (raceEdgeData*)toolsGraphEdgeGetData(gedge);

        gvtx = toolsGraphEdgeGetSource(gedge);

        reweightVertex(vtxWt, gvtx, edge->weight, &maxwt, &maxvtx);
    }

    toolsHashMapDelete(vtxWt, NULL, NULL);

    return maxvtx;
}

static CUresult
vertexRemove(toolsGraph *graph, MCcontext *mcctx)
{
    toolsGraphVertex *gvtx = NULL;
    CUresult res = CUDA_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;

    /* The algorithm does the following
        1. Bail early if trivial graph
        2. Find the vertex with the highest weighted degree
        3. Generate a report for it
        4. Remove it from the graph
        5. Recurse (i.e. find components)
    */

    /* Return early on trivial graph */
    if (toolsGraphGetVertexCount(graph) <= 1)
        return CUDA_SUCCESS;

    gvtx = getMaxWeightVertex(graph);
    if (!gvtx)
        return CUDA_SUCCESS;

    res = generateAnalysisRecord(graph, gvtx, mcctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to generate self loop record\n"));
        return res;
    }

    tres = toolsGraphDestroyVertex(graph, gvtx, NULL, NULL, NULL, NULL);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to remove vertex\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* Recurse */
    return breakComponents(graph, mcctx);
}

static CUresult
breakComponents(toolsGraph *graph, MCcontext *mcctx)
{
    tList *components = NULL;
    tListItr *li = NULL;
    toolsGraph *component = NULL;
    CUresult res = CUDA_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;

    if (!graph || !mcctx)
        return CUDA_ERROR_UNKNOWN;

    /* Return early on trivial graph */
    if (toolsGraphGetVertexCount(graph) <= 1)
        return res;

    components = toolsGraphGetConnectedComponents(graph);
    if (!components)
        return CUDA_SUCCESS;

    for (li = toolsListGetIterator(components);
         li;
         li = toolsListGetNext(li)) {
        component = (toolsGraph*)toolsListGetElem(li);
        res = vertexRemove(component, mcctx);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed on graph vertex removal\n"));
            return res;
        }
    }

    tres = toolsListDelete(components, (tSingleFun)destroyComponent, NULL);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to destroy list\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    return CUDA_SUCCESS;
}

static CUresult
analyseComponent(toolsGraph *graph, MCcontext *mcctx)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    /* Converting a graph to an error record is straightforward:
       1. create a new error record of RACE_ANALYSIS type
       2. There are two cases that generate information
          2.1 Self loops must always be broken (where srcpc == dstpc)
          2.2 For any component (not including self loops), compute the minset of edges that will
              result in a disconnected graph.
              To compute this the algorithm does the following:
              1. Remove edges from 3.1 from graph
              2. Run the component analysis to break the graph into components
              3. For each connected component (that is not a trivial component), do:
                  Pick the vertex of max weight (computed as sum over edge wts).
                  Print this vertex, all its neighbors.
                  Delete the vertex from the component
                  Rerun 3 on the remaining vertices
                For trivial component, do nothing.

    */

    res = reportSelfLoops(graph, mcctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to report self loops\n"));
        return res;
    }

    /* Early bail for trivial graphs*/
    if (toolsGraphGetVertexCount(graph) <= 1)
        return CUDA_SUCCESS;

    res = breakComponents(graph, mcctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to break components\n"));
        return res;
    }

    return CUDA_SUCCESS;
}

static CUresult
generateComponents(raceGroup *group, MCcontext *mcctx)
{
    tList *componentList = NULL;
    tListItr *li;
    toolsGraph *graph = NULL;
    CUresult res = CUDA_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;

    if (!group || !mcctx)
        return CUDA_ERROR_UNKNOWN;

    if (!group->graph || !group->graph->tGraph)
        return CUDA_ERROR_UNKNOWN;

    componentList = toolsGraphGetConnectedComponents(group->graph->tGraph);
    if (!componentList) {
        CU_ERROR_PRINT(("Failed to find components\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    for (li = toolsListGetIterator(componentList);
         li;
         li = toolsListGetNext(li)) {
        graph = (toolsGraph*)toolsListGetElem(li);

        res = analyseComponent(graph, mcctx);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to write graph\n"));
            return res;
        }
    }

    tres = toolsListDelete(componentList, (tSingleFun)destroyComponent, NULL);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to destroy list\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    return CUDA_SUCCESS;
}

CUresult
generateGroupRecords(CUmemcheck_record *listHead, MCcontext *mcctx)
{
    CUresult res = CUDA_SUCCESS;
    raceGroup *group = NULL;

    CU_TRACE_FUNCTION();

    if (!listHead || !mcctx) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    res = createGroup(&group);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to create group\n"));
        return res;
    }

    res = parseRecordList(group, listHead);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to parseRecords\n"));
        return res;
    }

    res = generateComponents(group, mcctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to generate components\n"));
        return res;
    }

    res = destroyGroup(&group);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to destroy group\n"));
        return res;
    }

    return res;
}

uint32_t
rcgvGetPC(toolsGraphVertex *gvtx)
{
    raceVertexData *vtx = NULL;
    vtx = (raceVertexData*)toolsGraphVertexGetData(gvtx);
    if (!vtx)
        return 0;

    return vtx->offset;
}

const char*
rcgvGetFuncName(toolsGraphVertex *gvtx)
{
    raceVertexData *vtx = NULL;
    vtx = (raceVertexData*)toolsGraphVertexGetData(gvtx);
    if (!vtx)
        return NULL;

    return vtx->funcName;
}

const char*
rcgvGetFileName(toolsGraphVertex *gvtx)
{
    raceVertexData *vtx = NULL;
    vtx = (raceVertexData*)toolsGraphVertexGetData(gvtx);
    if (!vtx)
        return NULL;

    return vtx->fileName;
}

uint32_t
rcgvGetLine(toolsGraphVertex *gvtx)
{
    raceVertexData *vtx = NULL;
    vtx = (raceVertexData*)toolsGraphVertexGetData(gvtx);
    if (!vtx)
        return 0;

    return vtx->line;
}

uint32_t
rcgvGetWrite(toolsGraphVertex *gvtx)
{
    raceVertexData *vtx = NULL;
    vtx = (raceVertexData*)toolsGraphVertexGetData(gvtx);
    if (!vtx)
        return 0;

    return vtx->write;
}

uint32_t
rcgeGetCount(toolsGraphEdge *gedge)
{
    raceEdgeData *edge = NULL;
    edge = (raceEdgeData*)toolsGraphEdgeGetData(gedge);
    if (!edge)
        return 0;

    return edge->count;
}

uint32_t
rcgeGetHazardMask(toolsGraphEdge *gedge)
{
    raceEdgeData *edge = NULL;
    edge = (raceEdgeData*)toolsGraphEdgeGetData(gedge);
    if (!edge)
        return 0;

    return edge->hazardTypeMask;
}

RaceGroupWeight
rcgeGetWeight(toolsGraphEdge *gedge)
{
    raceEdgeData *edge = NULL;
    edge = (raceEdgeData*)toolsGraphEdgeGetData(gedge);
    if (!edge)
        return RG_WEIGHT_NONE;

    return edge->weight;
}
