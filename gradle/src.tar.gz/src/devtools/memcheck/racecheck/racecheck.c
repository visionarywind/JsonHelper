/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "racecheck.h"
#include "check_core.h"
#include "memcheck_types.h"
#include "memcheck_inst_types.h"
#include "memcheck_error.h"
#include "fermi_racecheck_lmem.h"
#include "volta_racecheck_lmem.h"
#include "fermi_mcinterop.h"

#include "bikernels.h"
#include "tools_shared_list.h"
#include "check_tool_common.h"
#include "check_mc_module.h"

CCracecheckCtxData*
racecheckGetContextData(MCcontext *mcctx)
{
    return (CCracecheckCtxData*)mcctx->tm.ptr[MC_TOOL_MODE_RACECHECK];
}

CCracecheckRecData*
racecheckGetRecData(MCrec *rec)
{
    return (CCracecheckRecData*)rec->tm.ptr[MC_TOOL_MODE_RACECHECK];
}

static CUresult
racecheckGetInternalModules(MCrec *rec, tList **mods)
{
    CCracecheckRecData *recData = NULL;

    if (!rec || !mods) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = racecheckGetRecData(rec);
    if (!recData)
        *mods = NULL;
    else
        *mods = recData->internalModules;

    return CUDA_SUCCESS;
}

static CUresult
racecheckGetExceptionType(uint32_t magic, CUDBGException_t *exception)
{
    if ((magic & FERMI_MEMCHECK_WHITEMAGIC_MASK) == FERMI_MEMCHECK_WHITEMAGIC) {
        *exception = CUDBG_EXCEPTION_LANE_ILLEGAL_ADDRESS;
    }

    return CUDA_SUCCESS;
}

uint32_t
getRCdevTableEntrySize(MCcontext *mcctx)
{
    if (getArchFromSmVer(mcctx->sm_version) < MC_TOOL_MODE_ARCH_SM70)
        return sizeof(RCdevTableEntry);
    else
        return sizeof(RCdevTableEntry2);
}

CUresult
getRCdevTableEntryPc(MCcontext *mcctx, RCdevTableEntryCommon *entry, uint64_t *pc)
{
    if (!mcctx || !entry || !pc) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (getArchFromSmVer(mcctx->sm_version) < MC_TOOL_MODE_ARCH_SM70)
        *pc = (uint64_t)((RCdevTableEntry*)entry)->pc;
    else
        *pc = (((uint64_t)((RCdevTableEntry2*)entry)->pc_hi) << 32) | ((RCdevTableEntry2*)entry)->pc;

    return CUDA_SUCCESS;
}

static uint64_t
getTrackingTableSize(MCcontext *mcctx, MCrec *rec)
{
    CU_ASSERT(mcctx);
    CU_ASSERT(rec);

    return (uint64_t)rec->config.totalSharedMemPerBlock *
        rec->config.gridDimX *
        rec->config.gridDimY *
        rec->config.gridDimZ *
        getRCdevTableEntrySize(mcctx);
}

CCracecheckRecData*
racecheckGetRecDataFromTrackingTablePtr(MCcontext *mcctx, const uint64_t dptr)
{
    MCrec *rec = NULL;
    MCrec *next = NULL;
    CCracecheckRecData *recData = NULL;

    CU_ASSERT(mcctx);

    for (rec = mcctx->patchList; rec != NULL; rec = next) {
        uint64_t trackingTableSize = 0;
        next = rec->next;

        recData = racecheckGetRecData(rec);

        // Skip this launch if there is no record data
        if (!recData)
            continue;

        trackingTableSize = getTrackingTableSize(mcctx, rec);

        if (dptr >= recData->trackingTable.dev.dPtr &&
            dptr < (recData->trackingTable.dev.dPtr + trackingTableSize))
            return recData;
    }

    return NULL;
}

static CUresult
createTrackingTable(MCcontext *mcctx, MCrec *rec, CCracecheckRecData *recData)
{
    CUresult res = CUDA_SUCCESS;
    CUtoolsStreamHandle stream;
    uint64_t trackingTableSize = 0;

    CU_TRACE_FUNCTION();
    CU_ASSERT(mcctx);
    CU_ASSERT(rec);
    CU_ASSERT(recData);

    // Early exit for __device__ functions. Is there a better way to detect these?
    if (rec->config.gridDimX == 0 ||
        rec->config.gridDimY == 0 ||
        rec->config.gridDimZ == 0) {
        return CUDA_SUCCESS;
    }

    trackingTableSize = getTrackingTableSize(mcctx, rec);
    // Early exit if there is nothing to allocate
    if (trackingTableSize == 0) {
        CU_WARNING(("TrackingTableSize == 0. Skipping its allocation\n"));
        return CUDA_SUCCESS;
    }

    recData->trackingTable.size = trackingTableSize;
    recData->trackingTable.mcctx = mcctx;
    recData->trackingTable.devseg = HALO_MEM_SEG_GLOBAL;

    if (cuosOsIsWindows()) {
        recData->trackingTable.devseg = HALO_MEM_SEG_PINNED_SYSMEM;
    }

    res = CCallocateDevice(&recData->trackingTable, NULL);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to allocate tracking table\n"));
        return res;
    }

    res = CCallocateHost(&recData->trackingTable);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to allocate host memory for tracking table\n"));
        return res;
    }

    /* Grab the barrier stream and use it to initialize and push down internal
       tracking structures */
    res = mcctx->gvars->tools.context->CtxGetBarrierStream(mcctx->cuctx, &stream);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to get barrier stream\n"));
        printInternalError(CU_MEMCHECK_ERROR_DYNAMIC_INIT_FAILED,
                           mcctx->gvars);
        return res;
    }

    /* Reset the host shadow */
    memset(recData->trackingTable.host.ptr, 0, (size_t)recData->trackingTable.size);

    /* Push it down to the device */
    res = CCmemShadowHtoDStream(&recData->trackingTable, &recData->trackingTable,
                                stream, CC_MEM_SHADOW_ACTION_MEMCPY);

    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to copy shadow to device\n"));
        return res;
    }

    return res;
}

static CUresult
createErrorBuffer(MCcontext *mcctx, CCracecheckCtxData *ctxData)
{
    CUresult res;
    uint32_t bufSize = 0;
    uint32_t i = 0;
    RCdevBufferHeader *hdr = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !ctxData) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    bufSize = ctxData->perSMErrorEntrySize * ctxData->numSm;

    // Alloc a table of the right size (4k buffer entries + 16B header per entry per SM)
    ctxData->errorEntry.size = bufSize;
    ctxData->errorEntry.mcctx = mcctx;
    ctxData->errorEntry.devseg = HALO_MEM_SEG_PINNED_SYSMEM;

    CU_TRACE_PRINT(("Trying to allocate %u bytes (%u bytes per entry)"
                    "Tblsize : %u\n",
                    ctxData->errorEntry.size, sizeof(RCdevBufferEntry),
                    bufSize));

    res = CCallocateDevice(&ctxData->errorEntry, NULL);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("\n"));
        return res;
    }

    memset(ctxData->errorEntry.dev.hPtr, 0, (size_t)ctxData->errorEntry.size);

    CU_ASSERT(sizeof(RCdevBufferEntry) == 48);

    // Initialize all the per SM headers constants.
    for (i = 0; i < ctxData->numSm; ++i) {
        hdr = (RCdevBufferHeader*)((char*)(ctxData->errorEntry.dev.hPtr) + i * ctxData->perSMErrorEntrySize);
        hdr->entry_size = sizeof(RCdevBufferEntry);
        hdr->buffer_size = ctxData->perSMErrorEntrySize;
        hdr->header_size = sizeof(RCdevBufferHeader);
        hdr->next_offset = sizeof(RCdevBufferHeader);
    }

    return res;
}

static CUresult
createDeviceTables(MCcontext *mcctx, CCracecheckCtxData *ctxData)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!mcctx || !ctxData) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    res = createErrorBuffer(mcctx, ctxData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to create error buffer\n"));
        return res;
    }

    return res;
}

static CUresult
loadRacecheckCtxModules(MCcontext *mcctx, CCracecheckCtxData *ctxData)
{
    CUresult res = CUDA_SUCCESS;
    CCsymbol sym[3] = {{0}};
    MCfunc *ldstFunc = NULL, *barFunc = NULL, *wsFunc = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !ctxData) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* In the case of racecheck, we want to load up the racecheck module
       which contains all the per context stuff
     */

    // device address for error buffer
    sym[0].name = "RC_BUFW_PATCH_ERROR_BUF_ADDR";
    sym[0].val = ctxData->errorEntry.dev.dPtr;

    // size of per-SM error storage
    sym[1].name = "RC_BUFW_PATCH_ERROR_PER_SM";
    sym[1].val = ctxData->perSMErrorEntrySize;

    // replaces NOP with BPT.TRAP for traphandler callback-based error draining
    sym[2].name = "RC_BUFW_PATCH_ERROR_TRAP";
    mcctx->hal.genBreakInstruction(NULL, (uint64_t*)&(sym[2].val));
    setSymbolSize(mcctx, &sym[2]);

    res = loadModuleFromCubin(&ctxData->mod, mcctx, allCubins_racecheck,
                              sym, sizeof(sym)/sizeof(sym[0]));
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load module. \n"));
        return res;
    }

    ldstFunc = mcModuleGetFuncByName(ctxData->mod, "racecheckPatchCommon");
    if (!ldstFunc) {
        CU_ERROR_PRINT(("Could not get ldst common function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData->ldstCommon = ldstFunc->mem.dev.dPtr;

    barFunc = mcModuleGetFuncByName(ctxData->mod, "racecheckBarrierPatchCommon");
    if (!barFunc) {
        CU_ERROR_PRINT(("Could not get barrier common function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData->barCommon = barFunc->mem.dev.dPtr;

    wsFunc = mcModuleGetFuncByName(ctxData->mod, "racecheckWarpsyncCommon");
    if (!wsFunc) {
        CU_ERROR_PRINT(("Could not get warpsync common function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData->wsCommon = wsFunc->mem.dev.dPtr;

    return CUDA_SUCCESS;
}

CUresult
racecheckLoadEntryExit(MCrec *rec, MCfunc **stubFunc)
{
    CCracecheckRecData *recData = NULL;
    CCracecheckCtxData *ctxData = NULL;
    CCsymbol sym[7] = {{0}};
    CUresult res = CUDA_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;
    MCfunc *func = NULL;

    CU_TRACE_FUNCTION();

    /* In here to load an entry exit module */
    if (!rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = racecheckGetRecData(rec);
    if (!recData) {
        CU_ERROR_PRINT(("Invalid RC data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = racecheckGetContextData(rec->context);
    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid context data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // tracking table device address
    sym[0].name = "RC_PROLOGUE_PATCH_ADDR";
    sym[0].val = recData->trackingTable.dev.dPtr;

    // user code start address
    sym[1].name = "RC_PROLOGUE_PATCH_CALL_KERNEL_START";
    sym[1].val = rec->func->mem.dev.dPtr;

    // device address of table clear function
    sym[2].name = "RC_PROLOGUE_PATCH_CALL_TBL_CLEAR";
    sym[2].val = ctxData->barCommon;

    // shared memory per cta
    sym[3].name = "RC_PROLOGUE_PATCH_PER_CTA_SHMEM_SIZE";
    sym[3].val = rec->config.totalSharedMemPerBlock;

    // size of one device tracking table entry in bytes
    sym[4].name = "RC_PROLOGUE_PATCH_PER_CTA_ENTRY_SIZE";
    sym[4].val = getRCdevTableEntrySize(rec->context);

    // gridDim.x
    sym[5].name = "RC_PROLOGUE_PATCH_GRID_DIM_X";
    sym[5].val = rec->config.gridDimX;

    // gridDim.y
    sym[6].name = "RC_PROLOGUE_PATCH_GRID_DIM_Y";
    sym[6].val = rec->config.gridDimY;

    res = loadModuleFromCubin(&recData->entryExitMod, rec->context, allCubins_racecheck_entry_exit,
                              sym, sizeof(sym)/sizeof(sym[0]));
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load cubins\n"));
        return res;
    }

    tres = toolsListAppend(recData->internalModules, recData->entryExitMod);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to append module to list. (tres=%u)\n", tres));
        return CUDA_ERROR_UNKNOWN;
    }

    func = mcModuleGetFuncByName(recData->entryExitMod, "racecheckEntryExitPatch");
    if (!func) {
        CU_ERROR_PRINT(("Could not get stub function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (stubFunc) {
        *stubFunc = func;
    }

    /* Set the prologue entry address */
    rec->patchEntry = func->mem.dev.dPtr;

    return CUDA_SUCCESS;
}

CUresult
racecheckLoadBarrierStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, MCfunc **stubFunc)
{
    CCracecheckRecData *recData = NULL;
    CCracecheckCtxData *ctxData = NULL;
    CCsymbol sym[5] = {{0}};
    CUresult res = CUDA_SUCCESS;
    MCmod *mod = NULL;
    MCfunc *func = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;

    CU_TRACE_FUNCTION();

    /* In here to load an entry exit module */
    if (!rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = racecheckGetRecData(rec);
    if (!recData) {
        CU_ERROR_PRINT(("Invalid RC data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = racecheckGetContextData(rec->context);
    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid context data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // patch symbol with original bar instruction (full instr reloc)
    sym[0].name = "RC_STUB_BAR_INIT_BAR";
    res = assignInstSymbol(rec->context, &sym[0], inst);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to assign inst symbol\n"));
        return res;
    }

    // patch symbol with original bar instruction (full instr reloc)
    sym[1].name = "RC_STUB_BAR_FINAL_BAR";
    res = assignInstSymbol(rec->context, &sym[1], inst);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to assign inst symbol\n"));
        return res;
    }

    // device address of common barrier stub
    sym[2].name = "RC_STUB_BAR_JUMP_BARCOMMON";
    sym[2].val = ctxData->barCommon;

    // return address in user code after stub finishes
    sym[3].name = "RC_STUB_BAR_JUMP_RETURN";
    sym[3].val = returnTarget;

    sym[4].name = "RC_STUB_BAR_BYPASS_BRANCH";
    sym[4].type = CC_SYMBOL_TYPE_MASKED;
    sym[4].val  = rec->context->hal.getPredRawInv(inst);
    sym[4].mask = rec->context->hal.getPredMask(inst);
    if (getArchFromSmVer(rec->context->sm_version) >= MC_TOOL_MODE_ARCH_SM70) {
        sym[4].size = CC_SYMBOL_SIZE_128;
        sym[4].masks[1] = 0;
    }

    res = loadModuleFromCubin(&mod, rec->context, allCubins_racecheck_stub_bar,
                              sym, sizeof(sym)/sizeof(sym[0]));
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load cubins\n"));
        return res;
    }

    func = mcModuleGetFuncByName(mod, "racecheckStubBar");
    if (!func) {
        CU_ERROR_PRINT(("Could not get stub function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    tres = toolsListAppend(recData->internalModules, mod);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to append module to list. (tres=%u)\n", tres));
        return CUDA_ERROR_UNKNOWN;
    }

    if (stubFunc) {
        CU_DEBUG_PRINT(("Returning barrier stub entry at : 0x%" PRIx64 "\n",
                        func->mem.dev.dPtr));
        *stubFunc = func;
    }

    return CUDA_SUCCESS;
}

CUresult
racecheckLoadWarpsyncStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, MCfunc **stubFunc)
{
    CCracecheckRecData *recData = NULL;
    CCracecheckCtxData *ctxData = NULL;
    CCsymbol sym[4] = {{0}};
    CUresult res = CUDA_SUCCESS;
    MCmod *mod = NULL;
    MCfunc *func = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = racecheckGetRecData(rec);
    if (!recData) {
        CU_ERROR_PRINT(("Invalid RC data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = racecheckGetContextData(rec->context);
    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid context data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    // branch to bypass label if orig pred is false
    sym[0].name     = "RC_STUB_WARPSYNC_BYPASS_BRANCH";
    sym[0].type     = CC_SYMBOL_TYPE_MASKED;
    sym[0].val      = rec->context->hal.getPredRawInv(inst);
    sym[0].mask     = rec->context->hal.getPredMask(inst);
    if (getArchFromSmVer(rec->context->sm_version) >= MC_TOOL_MODE_ARCH_SM70) {
        sym[0].size = CC_SYMBOL_SIZE_128;
        sym[0].masks[1] = 0;
    }

    // return address in user code after stub finishes
    sym[1].name = "RC_STUB_WARPSYNC_JUMP_RETURN";
    sym[1].val = returnTarget;

    // device address of bar.warp.sync checker function
    sym[2].name = "RC_STUB_WARPSYNC_PATCH_COMMON";
    sym[2].val = ctxData->wsCommon;

    // original instruction
    sym[3].name = "RC_STUB_WARPSYNC_ORIG_INST";
    res = assignInstSymbol(rec->context, &sym[3], inst);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to assign inst symbol\n"));
        return res;
    }

    res = loadModuleFromCubin(&mod, rec->context, allCubins_racecheck_stub_warpsync,
                              sym, sizeof(sym)/sizeof(sym[0]));
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load cubins\n"));
        return res;
    }

    func = mcModuleGetFuncByName(mod, "racecheckStubWarpsync");
    if (!func) {
        CU_ERROR_PRINT(("Could not get stub function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    tres = toolsListAppend(recData->internalModules, mod);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to append module to list. (tres=%u)\n", tres));
        return CUDA_ERROR_UNKNOWN;
    }

    if (stubFunc) {
        CU_DEBUG_PRINT(("Returning warpsync stub entry at : 0x%" PRIx64 "\n",
                        func->mem.dev.dPtr));
        *stubFunc = func;
    }
    return CUDA_SUCCESS;
}

CUresult
racecheckLoadSharedLDSTStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, uint64_t patchPC, MCfunc **stubFunc)
{
    CCracecheckRecData *recData = NULL;
    CCracecheckCtxData *ctxData = NULL;
    CCsymbol sym[13] = {{0}};
    CUresult res = CUDA_SUCCESS;
    MCmod *mod = NULL;
    MCfunc *func = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;
    uint32_t asize = 0;
    uint32_t ra, rb, type = 0;
    bool voltaPlus = false, turingPlus = false;
    bool hasUniformRegister = false;

    CU_TRACE_FUNCTION();

    /* In here to load an entry exit module */
    if (!rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = racecheckGetRecData(rec);
    if (!recData) {
        CU_ERROR_PRINT(("Invalid RC data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = racecheckGetContextData(rec->context);
    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid context data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* Basic sanity. Inst MUST be a shared load or store */
    if (!rec->context->hal.isLds(inst) &&
        !rec->context->hal.isSts(inst)) {
        CU_ERROR_PRINT(("Not a shared load/store in sharedLDST loader Or decoder missing\n"));
        CU_ASSERT(0);
        return CUDA_ERROR_UNKNOWN;
    }

    asize = rec->context->hal.getMemAccessSize(inst, rec->func, patchPC);
    rb    = rec->context->hal.getRb(inst);
    ra    = rec->context->hal.getRa(inst);
    type  = rec->context->hal.isLds(inst) ? ENTRY_STATE_READ : ENTRY_STATE_WRITE;
    voltaPlus = getArchFromSmVer(rec->context->sm_version) >= MC_TOOL_MODE_ARCH_SM70;
    turingPlus = getArchFromSmVer(rec->context->sm_version) >= MC_TOOL_MODE_ARCH_SM75;
    hasUniformRegister = rec->context->hal.hasUniformRegister(inst);

    // branch to bypass label if orig pred is false
    sym[0].name     = "RC_STUB_SH_LDST_BYPASS_BRANCH";
    sym[0].type     = CC_SYMBOL_TYPE_MASKED;
    sym[0].val      = rec->context->hal.getPredRawInv(inst);
    sym[0].mask     = rec->context->hal.getPredMask(inst);
    if (getArchFromSmVer(rec->context->sm_version) >= MC_TOOL_MODE_ARCH_SM70) {
        sym[0].size = CC_SYMBOL_SIZE_128;
        sym[0].masks[1] = 0;
    }

    // Kepler-Pascal: mov addr reg to R1 (full inst reloc)
    // Volta+       : spill Ra in lmem
    sym[1].name     = "RC_STUB_SH_LDST_MOV_RA";
    if (voltaPlus)
        rec->context->hal.genLmemHiSpill(RACE_LMEM_RA_LO, sizeof(uint32_t), ra, (uint64_t*)&(sym[1].val));
    else
        rec->context->hal.genMov(1, ra, (uint64_t*)&sym[1].val);
    setSymbolSize(rec->context, &sym[1]);

    // original instruction (full inst reloc)
    sym[2].name     = "RC_STUB_SH_LDST_ORIG_INST";
    res = assignInstSymbol(rec->context, &sym[2], inst);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to assign inst symbol\n"));
        return res;
    }

    // generates an STL of the to-be-written value to local memory
    sym[3].name     = "RC_STUB_SH_LDST_WRITE_0";
    rec->context->hal.genLmemHiSpill(RACE_LMEM_WRITE_0, asize, rb, (uint64_t*)&(sym[3].val));
    setSymbolSize(rec->context, &sym[3]);

    // memory access size (in bytes) of the orig instruction
    sym[4].name     = "RC_STUB_SH_LDST_ASIZE";
    sym[4].val      = asize;

    // size of one tracking table entry in bytes
    sym[5].name     = "RC_STUB_SH_LDST_ENTRY_SIZE";
    sym[5].val      = getRCdevTableEntrySize(rec->context);

    // device address of common patch stub
    sym[6].name     = "RC_STUB_SH_LDST_JUMP_COMMON";
    sym[6].val      = ctxData->ldstCommon;

    // return address in user code after stub finishes
    sym[7].name     = "RC_STUB_SH_LDST_JUMP_RETURN";
    sym[7].val      = returnTarget;

    // // immediate addr offset of original instruction
    sym[8].name     = "RC_STUB_SH_LDST_OFFSET";
    sym[8].val      = rec->context->hal.getOffset(inst);

    // the patched PC (32/64bit), depending on arch
    sym[9].name     = "RC_STUB_SH_LDST_PC";
    sym[9].val      = patchPC;

    // type of patched instruction (read or write)
    sym[10].name    = "RC_STUB_SH_LDST_TYPE";
    sym[10].val     = type;

    // URF source
    if (hasUniformRegister) {
        uint32_t urb = rec->context->hal.getURb(inst);

        // MOV R0, Urb
        sym[11].name = "RC_STUB_SH_LDST_MOV_URB";
        rec->context->hal.genMovFromUR(0, urb, (uint64_t*)(&sym[11].val));
        setSymbolSize(rec->context, &sym[11]);
    }

    // SHF.L.U32 source register by strideShift bits
    if (turingPlus) {
        uint32_t strideShift = rec->context->hal.getStrideShift(inst);

        sym[12].name = "RC_STUB_SH_LDST_STRIDE";
        sym[12].val  = strideShift;
    }

    res = loadModuleFromCubin(&mod, rec->context, allCubins_racecheck_stub_sharedldst,
                              sym, sizeof(sym)/sizeof(sym[0]));
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load cubins\n"));
        return res;
    }

    func = mcModuleGetFuncByName(mod, "racecheckStubSharedLDST");
    if (!func) {
        CU_ERROR_PRINT(("Could not get stub function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    tres = toolsListAppend(recData->internalModules, mod);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to append module to list. (tres=%u)\n", tres));
        return CUDA_ERROR_UNKNOWN;
    }

    if (stubFunc) {
        CU_DEBUG_PRINT(("Returning shared ldst stub entry at : 0x%" PRIx64 "\n",
                        func->mem.dev.dPtr));
        *stubFunc = func;
    }

    return CUDA_SUCCESS;
}

CUresult
racecheckLoadGlobalLDSTStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, uint64_t patchPC, MCfunc **stubFunc)
{
    CCracecheckRecData *recData = NULL;
    CCracecheckCtxData *ctxData = NULL;
    CCsymbol sym[14] = {{0}};
    CUresult res = CUDA_SUCCESS;
    MCmod *mod = NULL;
    MCfunc *func = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;
    uint32_t asize = 0;
    uint32_t ra_lo, ra_hi = 0, rb, type = 0;
    bool voltaPlus = false;
    bool hasUniformRegister = false;

    CU_TRACE_FUNCTION();

    /* In here to load an entry exit module */
    if (!rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = racecheckGetRecData(rec);
    if (!recData) {
        CU_ERROR_PRINT(("Invalid RC data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = racecheckGetContextData(rec->context);
    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid context data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* Basic sanity. Inst MUST be a GTAS load or store */
    if (!rec->context->hal.isGtasLd(inst) &&
        !rec->context->hal.isGtasSt(inst)) {
        CU_ERROR_PRINT(("Not a GTAS load/store in globalLDST loader Or decoder missing\n"));
        CU_ASSERT(0);
        return CUDA_ERROR_UNKNOWN;
    }

    asize = rec->context->hal.getMemAccessSize(inst, rec->func, patchPC);
    rb    = rec->context->hal.getRb(inst);
    ra_lo = rec->context->hal.getRa(inst);

    type  = rec->context->hal.isGtasLd(inst) ? ENTRY_STATE_READ : ENTRY_STATE_WRITE;
    voltaPlus = getArchFromSmVer(rec->context->sm_version) >= MC_TOOL_MODE_ARCH_SM70;
    hasUniformRegister = rec->context->hal.hasUniformRegister(inst);

    // The logic of using RA_HI depends on URF:
    // - If No URF, this is set by the extended bit
    // - If URF, this is set by U64 bit
    if (ra_lo != rec->context->hal.getRz()) {
        if (hasUniformRegister) {
            if (rec->context->hal.getU64(inst))
                ra_hi = ra_lo + 1;
        }
        else {
            if (rec->context->hal.getExtended(inst))
                ra_hi = ra_lo + 1;
        }
    }

    sym[0].name     = "RC_STUB_GL_LDST_BYPASS_BRANCH";
    sym[0].type     = CC_SYMBOL_TYPE_MASKED;
    sym[0].val      = rec->context->hal.getPredRawInv(inst);
    sym[0].mask     = rec->context->hal.getPredMask(inst);
    if (voltaPlus) {
        sym[0].size = CC_SYMBOL_SIZE_128;
        sym[0].masks[1] = 0;
    }

    // Kepler-Pascal: mov lo addr reg to R0 (full inst reloc)
    // Volta+       : spill lo Ra in lmem
    sym[1].name     = "RC_STUB_GL_LDST_MOV_RA_LO";
    if (voltaPlus)
        rec->context->hal.genLmemHiSpill(RACE_LMEM_RA_LO, sizeof(uint32_t), ra_lo, (uint64_t*)&(sym[1].val));
    else
        rec->context->hal.genMov(0, ra_lo, (uint64_t*)&(sym[1].val));
    setSymbolSize(rec->context, &sym[1]);

    if (ra_hi) {
        // Kepler-Pascal: mov hi addr reg to R1 (full inst reloc)
        // Volta+       : spill hi Ra in lmem
        sym[2].name     = "RC_STUB_GL_LDST_MOV_RA_HI";
        if (voltaPlus)
            rec->context->hal.genLmemHiSpill(RACE_LMEM_RA_HI, sizeof(uint32_t), ra_hi, (uint64_t*)&(sym[2].val));
        else
            rec->context->hal.genMov(1, ra_hi, (uint64_t*)&(sym[2].val));
        setSymbolSize(rec->context, &sym[2]);
    }

    // original instruction (full inst reloc)
    sym[3].name     = "RC_STUB_GL_LDST_ORIG_INST";
    res = assignInstSymbol(rec->context, &sym[3], inst);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to assign inst symbol\n"));
        return res;
    }

    // generates an STL of the to-be-written value to local memory
    sym[4].name     = "RC_STUB_GL_LDST_WRITE_0";
    rec->context->hal.genLmemHiSpill(RACE_LMEM_WRITE_0, asize, rb, (uint64_t*)&(sym[4].val));
    setSymbolSize(rec->context, &sym[4]);

    // memory access size (in bytes) of the orig instruction
    sym[5].name     = "RC_STUB_GL_LDST_ASIZE";
    sym[5].val      = asize;

    // size of one tracking table entry in bytes
    sym[6].name     = "RC_STUB_GL_LDST_ENTRY_SIZE";
    sym[6].val      = getRCdevTableEntrySize(rec->context);

    // device address of common patch stub
    sym[7].name     = "RC_STUB_GL_LDST_JUMP_COMMON";
    sym[7].val      = ctxData->ldstCommon;

    // return address in user code after patch completion
    sym[8].name     = "RC_STUB_GL_LDST_JUMP_RETURN";
    sym[8].val      = returnTarget;

    // immediate addr offset of original instruction
    sym[9].name     = "RC_STUB_GL_LDST_OFFSET";
    sym[9].val      = rec->context->hal.getOffset(inst);

    // the patched PC (32/64bit), depending on arch
    sym[10].name     = "RC_STUB_GL_LDST_PC";
    sym[10].val      = patchPC;

    // type of patched instruction (read or write)
    sym[11].name    = "RC_STUB_GL_LDST_TYPE";
    sym[11].val     = type;

    // URF source
    if (hasUniformRegister) {
        uint32_t urb_lo = rec->context->hal.getURb(inst);
        uint32_t urb_hi = rec->context->hal.getURz();

        if (rec->context->hal.getExtended(inst)) {
            urb_hi = urb_lo + 1;
        }

        // MOV R8, URb
        sym[12].name = "RC_STUB_GL_LDST_MOV_URB_LO";
        rec->context->hal.genMovFromUR(8, urb_lo, (uint64_t*)(&sym[12].val));
        setSymbolSize(rec->context, &sym[12]);

        // MOV R9, Urb+1
        sym[13].name = "RC_STUB_GL_LDST_MOV_URB_HI";
        rec->context->hal.genMovFromUR(9, urb_hi, (uint64_t*)(&sym[13].val));
        setSymbolSize(rec->context, &sym[13]);
    }

    res = loadModuleFromCubin(&mod, rec->context, allCubins_racecheck_stub_globalldst,
                              sym, sizeof(sym)/sizeof(sym[0]));
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load cubins\n"));
        return res;
    }

    func = mcModuleGetFuncByName(mod, "racecheckStubGlobalLDST");
    if (!func) {
        CU_ERROR_PRINT(("Could not get stub function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    tres = toolsListAppend(recData->internalModules, mod);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to append module to list. (tres=%u)\n", tres));
        return CUDA_ERROR_UNKNOWN;
    }

    if (stubFunc) {
        CU_DEBUG_PRINT(("Returning global ldst stub entry at : 0x%" PRIx64 "\n",
                        func->mem.dev.dPtr));
        *stubFunc = func;
    }

    return CUDA_SUCCESS;
}

static CUresult
destroyTrackingTable(CCracecheckRecData *recData, CCmemCleanup *cleanup)
{
    CU_TRACE_FUNCTION();
    CU_ASSERT(recData);

    CCfreeDevice(&recData->trackingTable, cleanup);
    CCfreeHost(&recData->trackingTable);
    return CUDA_SUCCESS;
}

static CUresult
racecheckCreatePatchHelpers(MCcontext *mcctx, MCrec *rec,
                            CUtoolsStreamHandle stream)
{
    CUresult status = CUDA_SUCCESS;
    CCracecheckRecData *recData = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !rec || !stream) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = (CCracecheckRecData*)calloc(1, sizeof(*recData));
    if (!recData) {
        CU_ERROR_PRINT(("Failed to allocate rec data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    status = createTrackingTable(mcctx, rec, recData);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("failed to create tracking table\n"));
        goto error;
    }

    recData->internalModules = toolsListNew();
    if (!recData->internalModules) {
        CU_ERROR_PRINT(("Failed to create module list\n"));
        status = CUDA_ERROR_UNKNOWN;
        goto error;
    }

    rec->tm.ptr[MC_TOOL_MODE_RACECHECK] = (void*)recData;

    return status;

error:
    destroyTrackingTable(recData, NULL);
    if (recData)
        free(recData);

    return status;
}

static CUresult
destroyErrorBuffer(CCracecheckCtxData *ctxData, CCmemCleanup *cleanup)
{
    CU_TRACE_FUNCTION();

    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    CCfreeDevice(&ctxData->errorEntry, cleanup);
    return CUDA_SUCCESS;
}

static CUresult
destroyDeviceTables(CCracecheckCtxData *ctxData, CCmemCleanup *cleanup)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    res = destroyErrorBuffer(ctxData, cleanup);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to destroy error entry\n"));
        return res;
    }

    return CUDA_SUCCESS;
}

static CUresult
racecheckDestroyPatchHelpers(MCcontext *mcctx, MCrec *rec, CCmemCleanup *cleanup)
{
    CUresult status = CUDA_SUCCESS;
    CCracecheckRecData **pRecData = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !rec) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    pRecData = (CCracecheckRecData**)&rec->tm.ptr[MC_TOOL_MODE_RACECHECK];
    if (*pRecData) {
        status = destroyTrackingTable(*pRecData, cleanup);
        if (status != CUDA_SUCCESS) {
            // print error, but continue clean up
            CU_ERROR_PRINT(("Failed to destroy tracking table"));
        }

        toolsListDelete((*pRecData)->internalModules, NULL, NULL);
        (*pRecData)->internalModules = NULL;

        free(*pRecData);
        *pRecData = NULL;
    }
    return status;
}

static CUresult
racecheckDrainContext(MCcontext *mcctx)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid context\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    res = racecheckDrainBuffer(mcctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to drain buffer\n"));
        return res;
    }

    flushRecords(mcctx, &mcctx->gvars->output);

    return res;
}

static bool
racecheckHasPrologue(MCcontext *mcctx)
{
    return true;
}

static bool
racecheckUsesTrapHandler(MCoptions *options)
{
    return true;
}

static bool
racecheckEnableMemAccessCheck (MCoptions *options)
{
    return false;
}

static CUresult
racecheckModuleLoaded(MCcontext *mcctx, MCmod *mod)
{
    return CUDA_SUCCESS;
}

static CUresult
racecheckModuleUnloaded(MCcontext *mcctx, MCmod *mod)
{
    return racecheckDrainContext(mcctx);
}

static CUresult
racecheckContextDestroyStart(MCcontext *mcctx)
{
    CUresult res = CUDA_SUCCESS;
    CCracecheckCtxData *ctxData = NULL;

    if (!mcctx) {
        CU_DEBUG_PRINT(("No context\n"));
        return CUDA_SUCCESS;
    }

    res =  racecheckDrainContext(mcctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to drain context\n"));
        return res;
    }

    ctxData = racecheckGetContextData(mcctx);

    if (!ctxData) {
        CU_DEBUG_PRINT(("RC data already freed\n"));
        return CUDA_SUCCESS;
    }

    /* Free the allocations */
    destroyDeviceTables(ctxData, NULL);

    /* Free the structure */
    free(ctxData);
    ctxData = NULL;

    /* Reset the pointer */
    mcctx->tm.ptr[MC_TOOL_MODE_RACECHECK] = NULL;

    return CUDA_SUCCESS;
}

static CUresult
racecheckContextDestroyEnd(MCcontext *mcctx)
{
    return CUDA_SUCCESS;
}

static CUresult
racecheckHandlePatchCompletion(MCcontext *mcctx, MCrec *rec, MClaunch *launch)
{
    return racecheckDrainContext(mcctx);
}

static CUresult
racecheckHeapSelected(MCcontext *mcctx, CCalloc *heap)
{
    return CUDA_SUCCESS;
}

static CUresult
racecheckContextSync(MCcontext *mcctx)
{
    return racecheckDrainContext(mcctx);
}

static bool
racecheckEnableApiCheck(MCoptions *options)
{
    return false;
}

static CUresult
racecheckIsArchSupported(MCtoolMode *toolMode, MCtoolModeArchs arch, uint32_t *supported)
{
    if (!toolMode || !supported) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *supported = 0;

    if (arch >= MC_TOOL_MODE_ARCH_SM30 && arch <= MC_TOOL_MODE_ARCH_SM80)
        *supported = 1;

    return CUDA_SUCCESS;
}

static CUresult
racecheckIsOsSupported(MCtoolMode *toolMode, uint32_t *supported)
{
    if (!toolMode || !supported) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *supported = 1;

    return CUDA_SUCCESS;
}

static CUresult
racecheckIsModuleSupported(MCcontext *mcctx, MCmod *mod, CUmemcheck_error_types *modSupportedError)
{
    if (!mcctx || !mod || !modSupportedError) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *modSupportedError = CU_MEMCHECK_ERROR_NONE;

    if (mod->modOpts.usesCnp)
        *modSupportedError = CU_MEMCHECK_ERROR_UNSUPPORTED_CNP;

    return CUDA_SUCCESS;
}

static CUresult
racecheckUpdateLaunchConfig(MCcontext *mcctx, MCfunc *func, CUtoolsFunctionLaunchConfig *config)
{
    return CUDA_SUCCESS;
}

static CUresult
racecheckCheckMemAccessDevAddr(MCcontext *mcctx, uint64_t addr, uint64_t size, CUtoolsStreamHandle stream, CCmemAccessType accessType)
{
    return CUDA_SUCCESS;
}

static CUresult
racecheckContextCreatedCallback(MCcontext *mcctx)
{
    CUresult res = CUDA_SUCCESS;
    CCracecheckCtxData *ctxData = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* Enable MMU debug mode: this forces the traphandler to be called
     * in case the kernel causes some HW error (such as illegal memory
     * access) and allows racecheck to drain its internal buffer.
     * On Windows, this is not needed since the runtime will reset the
     * context during app shutdown */
    if (!cuosOsIsWindows()) {
        res = mcctx->gvars->tools.context->CtxSetMmuDebugMode(mcctx->cuctx, 1);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to enable MMU debug mode\n"));
            return res;
        }
    }

    ctxData = (CCracecheckCtxData*) calloc(1, sizeof(*ctxData));
    if (!ctxData) {
        CU_ERROR_PRINT(("Out of memory\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* Every warp needs to be able to write to a wpid indexed slot + 4 bytes for header */
    ctxData->numSm = mcctx->cuctx->device->state.limits.physicalSmCount;
    ctxData->numCtaPerSM = mcctx->cuctx->device->state.limits.maxCtaPerSm;
    ctxData->maxShmemPerCta = mcctx->cuctx->device->state.limits.maxSharedMemSizePerBlockOptin;

    ctxData->maxDepth = 63; /* TODO: Query dynamically. Need a tools API Callback on resize */

    ctxData->perSMErrorEntrySize = (RC_DEV_BUFFER_ENTRIES * sizeof(RCdevBufferEntry) + sizeof(RCdevBufferHeader));
    /* Create tables */
    res = createDeviceTables(mcctx, ctxData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to create device tables !!!\n"));
        goto error;
    }

    /* Load modules */
    res = loadRacecheckCtxModules(mcctx, ctxData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load required modules\n"));
        goto error;
    }

    /* Assign the pointer */
    mcctx->tm.ptr[MC_TOOL_MODE_RACECHECK] = (void*)ctxData;

    return CUDA_SUCCESS;

error:
    if (ctxData) {
        free(ctxData);
        ctxData = NULL;
    }

    return res;
}

static CUresult
racecheckInitEndCallback(MCglobals *gvars)
{
    CU_TRACE_FUNCTION();

    return CUDA_SUCCESS;
}

static CUresult
racecheckAddAllocCallback(MCcontext *mcctx, CCalloc *alloc)
{
    return CUDA_SUCCESS;
}

static CUresult
racecheckRemoveAllocCallback(MCcontext *mcctx, CCalloc *alloc)
{
    return CUDA_SUCCESS;
}

CUresult
racecheck_toolModeInitialize(MCoptions *options, MCtoolMode *toolMode)
{
    MCtoolModeArchState *arch_sm30 = NULL;
    MCtoolModeArchState *arch_sm35 = NULL;
    MCtoolModeArchState *arch_sm50 = NULL;
    MCtoolModeArchState *arch_sm52 = NULL;
    MCtoolModeArchState *arch_sm60 = NULL;
    MCtoolModeArchState *arch_sm70 = NULL;
    MCtoolModeArchState *arch_sm75 = NULL;
    MCtoolModeArchState *arch_sm80 = NULL;

    CU_TRACE_FUNCTION();

    if (!toolMode)
        return CUDA_ERROR_UNKNOWN;

    // Raw table initialization
    arch_sm30 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM30];
    arch_sm35 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM35];
    arch_sm50 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM50];
    arch_sm52 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM52];
    arch_sm60 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM60];
    arch_sm70 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM70];
    arch_sm75 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM75];
    arch_sm80 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM80];

    // Select instructions to patch for every arch
    if (options->enableSassPatching) {
        arch_sm30->checkMask = TO_CHECKTYPE_MASK(RACE);
        arch_sm30->opMask[MC_CHECK_TYPE_RACE] = TO_INST_MASK(SHARED_ST)     |
                                                TO_INST_MASK(SHARED_LD)     |
                                                TO_INST_MASK(GENERIC_ST)    |
                                                TO_INST_MASK(GENERIC_LD)    |
                                                TO_INST_MASK(SYNC_BARRIER)  |
                                                TO_INST_MASK(EXIT)          |
                                                TO_INST_MASK(NOP);

        arch_sm35->checkMask = TO_CHECKTYPE_MASK(RACE);
        arch_sm35->opMask[MC_CHECK_TYPE_RACE] = TO_INST_MASK(SHARED_ST)     |
                                                TO_INST_MASK(SHARED_LD)     |
                                                TO_INST_MASK(GENERIC_ST)    |
                                                TO_INST_MASK(GENERIC_LD)    |
                                                TO_INST_MASK(SYNC_BARRIER)  |
                                                TO_INST_MASK(EXIT)          |
                                                TO_INST_MASK(NOP);

        arch_sm50->checkMask = TO_CHECKTYPE_MASK(RACE);
        arch_sm50->opMask[MC_CHECK_TYPE_RACE] = TO_INST_MASK(SHARED_ST)     |
                                                TO_INST_MASK(SHARED_LD)     |
                                                TO_INST_MASK(GENERIC_ST)    |
                                                TO_INST_MASK(GENERIC_LD)    |
                                                TO_INST_MASK(SYNC_BARRIER)  |
                                                TO_INST_MASK(NOP);

        arch_sm52->checkMask = TO_CHECKTYPE_MASK(RACE);
        arch_sm52->opMask[MC_CHECK_TYPE_RACE] = TO_INST_MASK(SHARED_ST)     |
                                                TO_INST_MASK(SHARED_LD)     |
                                                TO_INST_MASK(GENERIC_ST)    |
                                                TO_INST_MASK(GENERIC_LD)    |
                                                TO_INST_MASK(SYNC_BARRIER)  |
                                                TO_INST_MASK(NOP);

        arch_sm60->checkMask = TO_CHECKTYPE_MASK(RACE);
        arch_sm60->opMask[MC_CHECK_TYPE_RACE] = TO_INST_MASK(SHARED_ST)     |
                                                TO_INST_MASK(SHARED_LD)     |
                                                TO_INST_MASK(GENERIC_ST)    |
                                                TO_INST_MASK(GENERIC_LD)    |
                                                TO_INST_MASK(SYNC_BARRIER)  |
                                                TO_INST_MASK(NOP);

        arch_sm70->checkMask = TO_CHECKTYPE_MASK(RACE);
        arch_sm70->opMask[MC_CHECK_TYPE_RACE] = TO_INST_MASK(SHARED_ST)     |
                                                TO_INST_MASK(SHARED_LD)     |
                                                TO_INST_MASK(GENERIC_ST)    |
                                                TO_INST_MASK(GENERIC_LD)    |
                                                TO_INST_MASK(SYNC_BARRIER)  |
                                                TO_INST_MASK(NOP);

        arch_sm75->checkMask = TO_CHECKTYPE_MASK(RACE);
        arch_sm75->opMask[MC_CHECK_TYPE_RACE] = TO_INST_MASK(SHARED_ST)     |
                                                TO_INST_MASK(SHARED_LD)     |
                                                TO_INST_MASK(GENERIC_ST)    |
                                                TO_INST_MASK(GENERIC_LD)    |
                                                TO_INST_MASK(SYNC_BARRIER)  |
                                                TO_INST_MASK(NOP);

        /* Ampere GA10x */
        arch_sm80->checkMask = TO_CHECKTYPE_MASK(RACE);
        arch_sm80->opMask[MC_CHECK_TYPE_RACE] = TO_INST_MASK(SHARED_ST)     |
                                                TO_INST_MASK(SHARED_LD)     |
                                                TO_INST_MASK(GENERIC_ST)    |
                                                TO_INST_MASK(GENERIC_LD)    |
                                                TO_INST_MASK(SYNC_BARRIER)  |
                                                TO_INST_MASK(NOP);
    }
    toolMode->createPatchHelpers = racecheckCreatePatchHelpers;
    toolMode->destroyPatchHelpers = racecheckDestroyPatchHelpers;
    toolMode->hasPrologue = racecheckHasPrologue;
    toolMode->usesTrapHandler = racecheckUsesTrapHandler;
    toolMode->moduleLoadedCallback = racecheckModuleLoaded;
    toolMode->moduleUnloadedCallback = racecheckModuleUnloaded;
    toolMode->contextDestroyStartCallback = racecheckContextDestroyStart;
    toolMode->contextDestroyEndCallback = racecheckContextDestroyEnd;
    toolMode->heapSelectedCallback = racecheckHeapSelected;
    toolMode->ctxSyncCallback  = racecheckContextSync;
    toolMode->enableApiCheck = racecheckEnableApiCheck;
    toolMode->handlePatchCompletion = racecheckHandlePatchCompletion;
    toolMode->isArchSupported = racecheckIsArchSupported;
    toolMode->isOsSupported = racecheckIsOsSupported;
    toolMode->isModuleSupported = racecheckIsModuleSupported;
    toolMode->updateLaunchConfig = racecheckUpdateLaunchConfig;

    toolMode->contextCreatedCallback = racecheckContextCreatedCallback;
    toolMode->enableMemAccessCheck = racecheckEnableMemAccessCheck;
    toolMode->checkMemAccessDevAddr = racecheckCheckMemAccessDevAddr;
    toolMode->trapHandlerCallback = racecheckTrapHandlerCallback;
    toolMode->trapHandlerEndCallback = racecheckTrapHandlerEndCallback;
    toolMode->initEndCallback = racecheckInitEndCallback;

    toolMode->addAllocCallback = racecheckAddAllocCallback;
    toolMode->removeAllocCallback = racecheckRemoveAllocCallback;

    toolMode->getInternalModules = racecheckGetInternalModules;

    toolMode->getExceptionType = racecheckGetExceptionType;

    return CUDA_SUCCESS;
}
