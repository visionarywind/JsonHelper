/*
 * Copyright 2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "check_mc_launch.h"
#include "check_mc_context.h"
#include "halo_state.h"
#include "cuistream.h"

MClaunch*
mcLaunchGetInContext(MCcontext *mcctx, uint64_t gridId)
{
    MClaunch* launch = NULL;

    if (!mcctx)
        return NULL;

    mcCtxLock(mcctx);
    launch = (MClaunch *)toolsHashMapFind(mcctx->launches, tHashMapNumToKey(gridId));
    mcCtxUnlock(mcctx);

    return launch;
}

void
mcLaunchAddToContext(MCcontext *mcctx, MClaunch *launch)
{
    CU_TRACE_FUNCTION();

    if (!mcctx || !launch)
        return;

    mcCtxLock(mcctx);
    toolsHashMapInsert(mcctx->launches, tHashMapNumToKey(launch->gridid),
                       (void*)(launch));
    launch->prev = NULL;
    launch->next = mcctx->launchList;
    if (mcctx->launchList)
        mcctx->launchList->prev = launch;
    mcctx->launchList = launch;
    mcCtxUnlock(mcctx);
}

CUresult
mcLaunchCreate(MCrec *rec, uint64_t gridid64, uint64_t streamId, MClaunch **pLaunch)
{
    MClaunch *launch = NULL;
    CUDBGResult dbgRes = CUDBG_SUCCESS;
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!rec || !pLaunch)
        return CUDA_ERROR_UNKNOWN;

    launch = (MClaunch *)calloc(1, sizeof(*launch));
    if (!launch) {
        CU_ERROR_PRINT(("Failed to alloc launch\n"));
        return CUDA_ERROR_OUT_OF_MEMORY;
    }

    launch->rec = rec;
    launch->gridid = gridid64;
    launch->streamid = streamId;
    if (NULL != rec->context->haloContext) {
        mcCtxLock(rec->context);
        dbgRes = haloStateCreateGrid(&launch->haloGrid,
                                     rec->func->haloFunc,
                                     launch->gridid);
        mcCtxUnlock(rec->context);
        if (dbgRes != CUDBG_SUCCESS) {
            CU_ERROR_PRINT(("Failed to create HALO grid\n"));
            res =  CUDA_ERROR_UNKNOWN;
            goto error;
        }
        // For memcheck, set CPU launched grids to posted
        launch->haloGrid->state = HALO_GRID_STATE_POSTED;
        launch->haloGrid->hostStreamId = streamId;
    }

    res = createBacktrace(&launch->bt, &rec->context->ctxOpts.btopts);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to create backtrace. Disabling\n"));
        launch->bt = NULL;
    }

    if (rec->context->ctxOpts.btopts.enableHostBacktrace) {
        res = captureHostBacktrace(launch->bt);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to capture host backtrace\n"));
            goto error;
        }
    }

    launch->state = MC_LAUNCH_STATE_INITIALIZED;
    *pLaunch = launch;

    return CUDA_SUCCESS;

error:

    if (launch) {
        if (launch->haloGrid) {
            mcCtxLock(rec->context);
            haloStateDestroyGrid(launch->haloGrid);
            mcCtxUnlock(rec->context);
            launch->haloGrid = NULL;
        }

        if (launch->bt) {
            (void)destroyBacktrace(&launch->bt);
        }

        free(launch);
        launch = NULL;
    }

    return res;
}

static CUresult
scopeUnitIncrementLaunchCount(MCcontext *mcctx, MCfunc *start, MCfunc *func, void *data)
{
    MCrec *rec = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !func || !start) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    rec = mcContextGetPatchByFunc(mcctx, func);
    if (!rec) {
        CU_TRACE_PRINT(("Patch not created yet\n"));
        return CUDA_SUCCESS;
    }

    (void)cuosInterlockedIncrement((volatile unsigned int*)&rec->launchCount);

    return CUDA_SUCCESS;
}

CUresult
scopeIncrementLaunchCount(MCcontext *mcctx, MCfunc *func)
{
    return scopeFunctor(mcctx, func, &scopeUnitIncrementLaunchCount, NULL);
}

static CUresult
scopeUnitDecrementLaunchCountUnderLock(MCcontext *mcctx, MCfunc *start, MCfunc *func, void *data)
{
    MCrec *rec = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !func || !start) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* Is being called under context lock */
    rec = (MCrec *)toolsHashMapFind(mcctx->patches, tHashMapPtrToKey(func->cufunc));
    if (!rec) {
        CU_TRACE_PRINT(("Patch not created yet\n"));
        return CUDA_SUCCESS;
    }

    (void)cuosInterlockedDecrement((volatile unsigned int*)&rec->launchCount);

    return CUDA_SUCCESS;
}

static CUresult
scopeDecrementLaunchCountUnderLock(MCcontext *mcctx, MCfunc *func)
{
    return scopeFunctor(mcctx, func, &scopeUnitDecrementLaunchCountUnderLock, NULL);
}

static bool
shouldRemoveLaunch(MClaunch *launch, uint64_t streamId, MClaunchState filter)
{
    CU_ASSERT(launch);

    if (!(launch->state & filter))
        return false;

    if (streamId == CUI_STREAM_ID_INVALID)
        return true;
    else
        return streamId == launch->streamid;
}

static MClaunch*
removeLaunchFromContextUnderLock(MCcontext *mcctx, uint64_t gridid)
{
    MClaunch *launch = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx)
        return NULL;

    launch = (MClaunch *)toolsHashMapFind(mcctx->launches, tHashMapNumToKey(gridid));
    if (launch) {
        toolsHashMapRemove(mcctx->launches, tHashMapNumToKey(gridid), NULL);

        if (launch == mcctx->launchList)
            mcctx->launchList = launch->next;
        if (launch->prev)
            launch->prev->next = launch->next;
        if (launch->next)
            launch->next->prev = launch->prev;
        launch->next = NULL;
        launch->prev = NULL;
    }
    return launch;
}

static CUresult
destroyLaunchEntryUnderLock(MClaunch *launch)
{
    CUresult res = CUDA_SUCCESS;

    if (!launch)
        return CUDA_ERROR_UNKNOWN;

    if (!launch->rec)
        goto delete_entry;

    if (launch->rec->state == MC_PATCH_STATE_NONE)
        goto delete_entry;

    if (launch->bt) {
        res = destroyBacktrace(&launch->bt);
        if (res != CUDA_SUCCESS)
            goto delete_entry;
    }

    if (launch->rec->gvars->haloInitialized)
        haloStateDestroyGrid(launch->haloGrid);

delete_entry:
    free(launch);

    return res;
}

CUresult
mcLaunchRemove(MCcontext *mcctx, uint64_t streamId, MClaunchState filter)
{
    MClaunch *launch = NULL;
    MClaunch *next = NULL;
    MClaunch *newListHead = NULL;
    MClaunch *newListTail = NULL;
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!mcctx)
        return CUDA_SUCCESS;

    mcCtxLock(mcctx);
    launch = mcctx->launchList;
    mcctx->launchList = NULL;

    for (; launch; launch = next) {
        next = launch->next;
        if (!shouldRemoveLaunch(launch, streamId, filter)) {
            launch->prev = newListTail;
            launch->next = NULL;
            if (newListTail)
                newListTail->next = launch;
            if (!newListHead)
                newListHead = launch;
            newListTail = launch;
            continue;
        }

        if (launch->rec) {
            res = scopeDecrementLaunchCountUnderLock(mcctx, launch->rec->func);
            if (res != CUDA_SUCCESS) {
                CU_ERROR_PRINT(("Failed to decrement scope refcounts\n"));
                goto unlock_and_return;
            }
        }

        if (!removeLaunchFromContextUnderLock(mcctx, launch->gridid)) {
            CU_ERROR_PRINT(("Failed to remove launch from context\n"));
            res = CUDA_ERROR_UNKNOWN;
            goto unlock_and_return;
        }
        res = destroyLaunchEntryUnderLock(launch);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to retire a launch\n"));
            goto unlock_and_return;
        }
    }

    if (newListHead) {
        newListTail->next = mcctx->launchList;
        if (mcctx->launchList)
            mcctx->launchList->prev = newListTail;
        mcctx->launchList = newListHead;
    }

unlock_and_return:
    mcCtxUnlock(mcctx);

    return res;
}

CUresult
mcLaunchRemoveAll(MCcontext *mcctx)
{
    CU_TRACE_FUNCTION();

    // Remove all possible launches
    return mcLaunchRemove(mcctx, CUI_STREAM_ID_INVALID, MC_LAUNCH_STATE_FORCE_SIZE);
}
