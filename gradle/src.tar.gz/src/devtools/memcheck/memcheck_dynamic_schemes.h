/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
*
*   Module: memcheck_dynamic_schemes.h
*
*   Description:
*       The main header to track schemes for dynamic memcheck. All schemes
*       must be added here. This file must be included by the host side
*       setup source file of each scheme
*
******************************************************************************/
#ifndef MEMCHECK_DYNAMIC_SCHEMES_H
#define MEMCHECK_DYNAMIC_SCHEMES_H

#include "memcheck.h"
#include "memcheck_types.h"
#include "cudamemcheck.h"
#include "memcheck_dynamic.h"

/* To add a new scheme :
1. Add the type of scheme to SchemeTypes
2. Add the prototype of registration function
3. Add the registration function to the array
*/

typedef CUresult (*MCDynamicSchemeFptr)(MCDynamicScheme*);

/* Types of schemes
Schemes should also always be strictly added.
If a scheme is to be removed, replace it with _NONE
Last entry must always be MC_DYNAMIC_SCHEMES_MAX
*/
enum MCDynamicSchemeTypes {
    MC_DYNAMIC_SCHEME_NONE,
    MC_DYNAMIC_SCHEME_OOB,
    MC_DYNAMIC_SCHEME_GLOBALLOCK,
    MC_DYNAMIC_SCHEME_INITCHECK,
    MC_DYNAMIC_SCHEMES_MAX
};

/* Prototypes of initialization functions */
extern CUresult MCDynamicSchemeRegister_none(MCDynamicScheme* scheme);
extern CUresult MCDynamicSchemeRegister_oob(MCDynamicScheme* scheme);
extern CUresult MCDynamicSchemeRegister_globallock(MCDynamicScheme* scheme);
extern CUresult MCDynamicSchemeRegister_initcheck(MCDynamicScheme* scheme);

/* Function pointers to the registration functions
   The registration functions basically fill in the host side function
   pointers and the basic options.
   Allocation/memory management should be done in the per scheme initialize
   function which will be called once the scheme is registered

   NOTE : This array should be in the same order as the
          MCDynamicSchemeType enum before. */
static const MCDynamicSchemeFptr MCDynamicSchemeRegister[] = {
    &MCDynamicSchemeRegister_none,
    &MCDynamicSchemeRegister_oob,
    &MCDynamicSchemeRegister_globallock,
    &MCDynamicSchemeRegister_initcheck
};

#endif

