/*
 * Copyright 2007-2014 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "initcheck/initcheck.h"
#include "check_core.h"
#include "memcheck_types.h"
#include "memcheck_inst_types.h"
#include "memcheck_error.h"
#include "volta_initcheck_lmem.h"
#include "fermi_mcinterop.h"

#include "bikernels.h"
#include "tools_shared_list.h"

#include "check_tool_common.h"
#include "check_bitpool.h"
#include "check_mc_context.h"
#include "check_mc_func.h"
#include "check_mc_module.h"
#include "initcheck/initcheck_structs.h"
#include "memcheck_tool_modes.h"
#include "memcheck_dynamic_schemes.h"

typedef struct CCICallocData_st CCICallocData;

struct CCICallocData_st {
    CCmemHandle mem;
    CCalloc     *alloc;
};

CCinitcheckCtxData*
initcheckGetContextData(MCcontext *mcctx)
{
    return (CCinitcheckCtxData*)mcctx->tm.ptr[MC_TOOL_MODE_INITCHECK];
}

CCinitcheckRecData*
initcheckGetRecData(MCrec *rec)
{
    return (CCinitcheckRecData*)rec->tm.ptr[MC_TOOL_MODE_INITCHECK];
}

static CUresult
initcheckGetInternalModules(MCrec *rec, tList **mods)
{
    CCinitcheckRecData *recData = NULL;

    if (!rec || !mods) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = initcheckGetRecData(rec);
    if (!recData)
        *mods = NULL;
    else
        *mods = recData->internalModules;

    return CUDA_SUCCESS;
}

static CUresult
initcheckGetExceptionType(uint32_t magic, CUDBGException_t *exception)
{
    if ((magic & FERMI_MEMCHECK_WHITEMAGIC_MASK) == FERMI_MEMCHECK_WHITEMAGIC) {
        *exception = CUDBG_EXCEPTION_LANE_ILLEGAL_ADDRESS;
    }

    return CUDA_SUCCESS;
}

static uint64_t getTrackingSizeInBytes(uint64_t size)
{
    /* Tracking table uses 1 bit for each byte in the original
       allocation. Thus, the number of bytes in the tracking
       table can be given as : ceil(AllocationSize / (8))

    */
    uint64_t track = ((size + 7) >> 3);
    if (!track)
        track = 1;
    return track;
}

static unsigned char
countUnsetBitsUint32(uint32_t x)
{
    /*
     * Count the number of SET bits in x. Kernighan's method (http://graphics.stanford.edu/~seander/bithacks.html#CountBitsSetKernighan)
     */
    unsigned char result;
    for (result = 0; x; ++result) {
        x &= x - 1; // clear the least significant bit set
    }
    /*
     * Reverse the number to get unset bits
     */
    return 32 - result;
}

static char
findFirstUnsetBitUint32(uint32_t x)
{
    /*
     * Find the index of the first unset bit, starting from LSB. (http://graphics.stanford.edu/~seander/bithacks.html#IntegerLogDeBruijn)
     * 0b00000000 0
     * 0b11111111 -1
     * 0b01111111 7
     * 0b11111110 0
     * 0b01111110 0
     */
    if (x == 0xffffffff) {
        return -1;
    }
    x = ~x;
    static const int multiplyDeBruijnBitPosition[32] =
    {
        0, 1, 28, 2, 29, 14, 24, 3, 30, 22, 20, 15, 25, 17, 4, 8,
        31, 27, 13, 23, 21, 19, 16, 7, 26, 12, 18, 6, 11, 5, 10, 9
    };
    return multiplyDeBruijnBitPosition[((uint32_t)((x & -(int32_t)x) * 0x077CB531U)) >> 27];
}

static char
findFirstUnsetBitUint32Reverse(uint32_t x)
{
    /*
     * Find the index of the first unset bit, starting from MSB. (https://graphics.stanford.edu/~seander/bithacks.html#ZerosOnRightBinSearch)
     * 0b00000000 7
     * 0b11111111 -1
     * 0b01111111 7
     * 0b11111110 0
     * 0b01111110 7
     */
    char c = 31;
    if ((x & 0xffff0000) == 0xffff0000) {
        x <<= 16;
        c -= 16;
    }
    if ((x & 0xff000000) == 0xff000000) {
        x <<= 8;
        c -= 8;
    }
    if ((x & 0xf0000000) == 0xf0000000) {
        x <<= 4;
        c -= 4;
    }
    if ((x & 0xc0000000) == 0xc0000000) {
        x <<= 2;
        c -= 2;
    }
    c -= (x & 0x80000000) == 0x80000000;
    return c;
}

typedef enum {
    TABLE_WALKER_TYPE_MEM_CHECK_ACCESS,
    TABLE_WALKER_TYPE_MEM_CHECK_MODE_TEST,
    TABLE_WALKER_TYPE_MEM_CHECK_UNUSED
} tableWalkerType;

typedef struct tableWalkerData_st tableWalkerData;
struct tableWalkerData_st {
    union {
        struct {
            MCcontext *mcctx;
            CCmemAccessType accessType;
        } test;
        struct {
            uint8_t valid;
        } set;
    } cases;
};

static CUresult
tableWalker(CCICallocData *data, uint64_t d_ptr, uint64_t size, tableWalkerType type, tableWalkerData *wd)
{
    CUresult res = CUDA_SUCCESS;
    /* 32bit words */
    const uint32_t defaultWordMask = 0xffffffff;
    /* Offset of the variable within the allocation in bytes */
    uint64_t offset = d_ptr - CCallocGetStart(data->alloc);
    /* Offset from word boundary */
    uint32_t beginOffset = ((uint32_t)offset & IC_ADDRESS_MASK);
    /* Index of word to start checking with */
    uint64_t beginWord = offset >> IC_ADDRESS_SHIFT;
    /* Size to check from beginWord boundary to end of variable */
    uint64_t finalSize = (beginOffset + size);
    /* Offset of enf of variable from last checked word boundary */
    uint32_t finalOffset = ((uint32_t)finalSize & IC_ADDRESS_MASK);
    /* Number of words to check within the allocation */
    uint64_t wordCtr = ((finalSize + IC_ADDRESS_MASK) >> IC_ADDRESS_SHIFT);
    /* Mask for checking first word */
    uint32_t beginMask = defaultWordMask << beginOffset;
    /* Mask for checking last word */
    uint32_t finalMask = (1U << finalOffset) - 1;
    /* Mask for checking in-between words */
    uint32_t wordMask = defaultWordMask;
    /* First error address (type == TABLE_WALKER_TYPE_MEM_CHECK_UNUSED) */
    uint64_t firstError = -1;
    /* Last error address (type == TABLE_WALKER_TYPE_MEM_CHECK_UNUSED) */
    uint64_t lastError = -1;
    /* Amount of unused memory (type == TABLE_WALKER_TYPE_MEM_CHECK_UNUSED) */
    uint64_t allocUnused = 0;
    uint64_t i;
    uint32_t oldWord;
    uint32_t *trackingTable = (uint32_t*)data->mem.host.ptr;

    /* Test that all (relevant) bits in the tracker are set to 'initialized' */
    for (i = 0; i < wordCtr; ++i) {
        /* Start each word mask at the default */
        wordMask = defaultWordMask;

        /* When on the first word, if there is a begin
           offset, clip down to the begin mask */
        if (i == 0 && beginOffset)
            wordMask &= beginMask;

        /* If on the last word, and there is a finalOffset,
           the mask in finalMask will clip out the high bits  */
        if ((i == wordCtr - 1) && finalOffset)
            wordMask &= finalMask;

        if (type == TABLE_WALKER_TYPE_MEM_CHECK_UNUSED) {
            uint32_t masked = trackingTable[i] | ~wordMask;
            uint32_t unused = countUnsetBitsUint32(masked);
            if (unused) {
                if (firstError == -1) {
                    firstError = i * (8 * sizeof(defaultWordMask)) + findFirstUnsetBitUint32(masked);
                }
                lastError = i * (8 * sizeof(defaultWordMask)) + findFirstUnsetBitUint32Reverse(masked);
                allocUnused += unused;
            }
        }
        else if (type == TABLE_WALKER_TYPE_MEM_CHECK_MODE_TEST) {
            CCmemAccessError err = {(CCmemAccessErrorType)0};

            oldWord = trackingTable[i + beginWord];
            if ((oldWord & wordMask) != wordMask) {

                err.addr = d_ptr;
                err.size = size;
                err.type = CC_MEM_ACCESS_ERROR_UNINITIALIZED_DEVICE_DATA;
                /* Unininitialized access at this address. Run the expansion backwards */
                err.badAddr = CCallocGetStart(data->alloc) + ((i + beginWord) << IC_ADDRESS_SHIFT);
                res = addMemAccessError(wd->cases.test.mcctx, &err, wd->cases.test.accessType, d_ptr, size);
                if (res != CUDA_SUCCESS) {
                    CU_ERROR_PRINT(("Failed to print a add access error\n"));
                    return res;
                }
                flushRecords(wd->cases.test.mcctx, &wd->cases.test.mcctx->gvars->output);
            }
        }
        else if (type == TABLE_WALKER_TYPE_MEM_CHECK_ACCESS) {
            if (wd->cases.set.valid)
                trackingTable[i + beginWord] |= wordMask;
            else
                trackingTable[i + beginWord] &= ~wordMask;
        }
    }

    if (type == TABLE_WALKER_TYPE_MEM_CHECK_UNUSED && allocUnused) {
        CCBacktrace* allocBt = CCallocGetBacktrace(data->alloc);
        res = addMemUnusedError(wd->cases.test.mcctx, CC_MEM_UNUSED_ERROR_NOT_WRITTEN, d_ptr, size,
                                allocUnused, firstError, lastError - firstError + 1, allocBt);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to add a mem unused error\n"));
            return res;
        }
        flushRecords(wd->cases.test.mcctx, &wd->cases.test.mcctx->gvars->output);
    }

    return CUDA_SUCCESS;
}

static CUresult
checkUnusedMemory(MCcontext *mcctx, CCalloc *alloc, CCinitcheckCtxData *ctxData)
{
    uint64_t allocStart = CCallocGetStart(alloc);
    uint64_t allocSize = CCallocGetSize(alloc);
    CCICallocData *data = (CCICallocData*)toolsRangeMapLookupByRange(ctxData->allocTrackingTables, allocStart, allocSize);
    tableWalkerData wd;

    wd.cases.test.mcctx = mcctx;

    return tableWalker(data, allocStart, allocSize, TABLE_WALKER_TYPE_MEM_CHECK_UNUSED, &wd);
};

static CUresult
setAllocTracking(MCcontext *mcctx, CCinitcheckCtxData *ctxData, CUtoolsStreamHandle stream, uint64_t d_ptr, uint64_t size, bool initialized)
{
    CCICallocData *data = NULL;
    CUresult res = CUDA_SUCCESS;
    tableWalkerData wd;

    data = (CCICallocData*)toolsRangeMapLookupByRange(ctxData->allocTrackingTables, d_ptr, size);
    if (!data) {
        CU_ERROR_PRINT(("Failed to find global at 0x%" PRIx64 "!!\n", d_ptr));
        return CUDA_ERROR_UNKNOWN;
    }

    wd.cases.set.valid = (initialized) ? 1 : 0;
    res = tableWalker(data, d_ptr, size, TABLE_WALKER_TYPE_MEM_CHECK_ACCESS, &wd);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to set values\n"));
        return res;
    }

    res = CCmemShadowHtoDStream(&data->mem, &data->mem,
                                stream, CC_MEM_SHADOW_ACTION_MEMCPY);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to update table\n"));
        return res;
    }

    CU_TRACE_PRINT(("Marked allocation at [0x%" PRIx64 ":0x%" PRIx64 "] "
                    " as %s\n",
                    d_ptr, d_ptr + size,
                    (initialized) ? "initialized":"uninitialized"));

    return CUDA_SUCCESS;
}

static CUresult
checkAllocTracking(MCcontext *mcctx, CCinitcheckCtxData *ctxData, CUtoolsStreamHandle stream, uint64_t d_ptr, uint64_t size, CCmemAccessType accessType)
{
    CCICallocData *data = NULL;
    CUresult res = CUDA_SUCCESS;
    tableWalkerData wd;

    /*  Find the allocation corresponding to this host */
    data = (CCICallocData*)toolsRangeMapLookupByRange(ctxData->allocTrackingTables,
                                                      d_ptr, size);
    if (!data) {
        CU_ERROR_PRINT(("Allocation tracking table not found !!\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* Pull the device side data back to the host */
    res = CCmemShadowDtoHStream(&data->mem, &data->mem,
                                stream, CC_MEM_SHADOW_ACTION_MEMCPY);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to shadow table to host\n"));
        return res;
    }

    wd.cases.test.mcctx = mcctx;
    wd.cases.test.accessType = accessType;

    res = tableWalker(data, d_ptr, size, TABLE_WALKER_TYPE_MEM_CHECK_MODE_TEST, &wd);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to check table\n"));
        return res;
    }

    return res;
}

static void
deleteAllocTracking(CCICallocData *data, CCmemCleanup *cleanup);

static CUresult
createAllocTracking(MCcontext *mcctx, CCinitcheckCtxData *ctxData, CCalloc *alloc)
{
    CCICallocData *data = NULL;
    uint64_t size;
    CUresult res = CUDA_SUCCESS;
    CUtoolsStreamHandle stream;
    TOOLSresult tres = TOOLS_SUCCESS;

    data = (CCICallocData *)calloc(1, sizeof(*data));
    if (!data) {
        CU_ERROR_PRINT(("Failed to allocate data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    size = CCallocGetSize(alloc);

    /* Get the tracking table size */
    size = getTrackingSizeInBytes(size);

    /* Since the tracking table is always accessed by 4 byte words,
       allocations must be rounded up to the nearest 4byte boundary  */
    size = (size + 3) & (~3ULL);

    data->mem.size = size;
    data->mem.mcctx = mcctx;
    data->mem.devseg = HALO_MEM_SEG_GLOBAL;

    data->alloc = alloc;

    res = CCallocateHost(&data->mem);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to allocate host tracking table\n"));
        goto error;
    }

    /* Clear the tracking */
    memset(data->mem.host.ptr, 0, (size_t)data->mem.size);

    res = CCallocateDevice(&data->mem, NULL);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to allocate tracking table on GPU\n"));
        goto error;
    }

    tres = toolsRangeMapInsertByRange(ctxData->allocTrackingTables,
                                      CCallocGetStart(alloc),
                                      CCallocGetSize(alloc),
                                      (void*)data);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to insert into map. (tres=%u)\n", tres));
        res = CUDA_ERROR_UNKNOWN;
        goto error;
    }

    res = mcctx->gvars->tools.context->CtxGetBarrierStream(mcctx->cuctx, &stream);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to get barrier stream\n"));
        printInternalError(CU_MEMCHECK_ERROR_DYNAMIC_INIT_FAILED,
                           mcctx->gvars);
        return res;
    }

    res = CCmemShadowHtoDStream(&data->mem, &data->mem,
                                stream, CC_MEM_SHADOW_ACTION_MEMCPY);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to update table\n"));
        return res;
    }

    CU_DEBUG_PRINT(("Allocated tracking table for alloc 0x%" PRIx64 " size:0x%" PRIx64
                    "Table dptr: 0x%" PRIx64 " Table size : 0x%" PRIx64 "\n",
                    CCallocGetStart(alloc),
                    CCallocGetSize(alloc),
                    data->mem.dev.dPtr,
                    data->mem.size));

    return res;

error:
    deleteAllocTracking(data, NULL);
    return res;
}

static void
deleteAllocTracking(CCICallocData *data, CCmemCleanup *cleanup)
{
    CCfreeHost(&data->mem);
    CCfreeDevice(&data->mem, cleanup);
    free(data);
}

static CUresult
destroyAllocTracking(CCalloc *alloc, CCinitcheckCtxData *ctxData)
{
    CCICallocData *data = NULL;

    data = (CCICallocData *)toolsRangeMapRemoveByAddr(ctxData->allocTrackingTables, CCallocGetStart(alloc));
    if (!data) {
        CU_ERROR_PRINT(("Allocation not found\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    deleteAllocTracking(data, NULL);
    return CUDA_SUCCESS;
}

static void
deleteAllocTrackingWrap(void *entry, void *data)
{
    CCICallocData *handle = (CCICallocData*)entry;

    if (!handle)
        return;

    deleteAllocTracking(handle, (CCmemCleanup*)data);
}

static CUresult
destroyAllocTrackingTables(CCinitcheckCtxData *ctxData, CCmemCleanup *cleanup)
{
    CU_TRACE_FUNCTION();

    if (ctxData->allocTrackingTables)
        toolsRangeMapDestroy(&ctxData->allocTrackingTables, deleteAllocTrackingWrap, cleanup);

    return CUDA_SUCCESS;
}

static CUresult
destroyAllocTable(CCinitcheckCtxData *ctxData, CCmemCleanup *cleanup)
{
    CU_TRACE_FUNCTION();

    if (ctxData->allocTable.size) {
        CCfreeDevice(&ctxData->allocTable, cleanup);
        CCfreeHost(&ctxData->allocTable);
        ctxData->allocTable.size = 0;
    }

    return CUDA_SUCCESS;
}

static CUresult
updateHostAllocTracking(CCinitcheckCtxData *ctxData, CUtoolsStreamHandle stream, uint64_t addr)
{
    CUresult res = CUDA_SUCCESS;
    CCICallocData *allocData = NULL;

    CU_TRACE_FUNCTION();

    /*  Check if the allocation is tracked. */
    allocData = (CCICallocData *)toolsRangeMapLookupByAddr(ctxData->allocTrackingTables, addr);
    if (!allocData) {
        CU_TRACE_PRINT(("Alloc not tracked\n"));
        return CUDA_SUCCESS;
    }

    /* Pull the device side data back to the host */
    res = CCmemShadowDtoHStream(&allocData->mem, &allocData->mem,
                                stream, CC_MEM_SHADOW_ACTION_MEMCPY);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to shadow table to host\n"));
        return res;
    }

    return CUDA_SUCCESS;
}

static CUresult
updateAllocTable(MCcontext *mcctx, CCinitcheckCtxData *ctxData, CUtoolsStreamHandle stream)
{
    CUresult res = CUDA_SUCCESS;
    ICdevAllocTableEntry *hostEntry;
    tRangeMapItr *it;
    uint32_t i = 0;

    CU_TRACE_FUNCTION();

    if (!ctxData->regenerateAllocTable)
        return CUDA_SUCCESS;

    res = destroyAllocTable(ctxData, NULL);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to destroy table\n"));
        return res;
    }

    /* Early bypass if there are 0 allocations */
    if (!ctxData->numAllocs)
        return CUDA_SUCCESS;

    ctxData->allocTable.size = ctxData->numAllocs * sizeof(ICdevAllocTableEntry);
    ctxData->allocTable.mcctx = mcctx;
    ctxData->allocTable.devseg = HALO_MEM_SEG_GLOBAL;

    /* Allocate the new table */
    res = CCallocateDevice(&ctxData->allocTable, NULL);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to allocate table on device\n"));
        return res;
    }

    res = CCallocateHost(&ctxData->allocTable);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to allocate table on host\n"));
        return res;
    }

    hostEntry = (ICdevAllocTableEntry*)ctxData->allocTable.host.ptr;
    for (i = 0, it = toolsRangeMapGetIterator(ctxData->allocTrackingTables);
         it;
         it = toolsRangeMapGetNext(ctxData->allocTrackingTables, it), hostEntry++, ++i) {
        CCICallocData *allocData = (CCICallocData*)toolsRangeMapGetEntry(it);
        hostEntry->begin = CCallocGetStart(allocData->alloc);
        hostEntry->end   = CCallocGetEnd(allocData->alloc);
        hostEntry->trackingTablePtr = allocData->mem.dev.dPtr;
        hostEntry->offset = 0;
        if (ctxData->hasHeap && ctxData->heapDptr == hostEntry->begin)
            ctxData->heapAllocIndex = i;
    }

    res = CCmemShadowHtoDStream(&ctxData->allocTable, &ctxData->allocTable,
                                stream, CC_MEM_SHADOW_ACTION_MEMCPY);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to update table\n"));
        return res;
    }

    ctxData->regenerateAllocTable = 0;

    return res;
}

static CUresult
updateGlobalData(MCcontext *mcctx)
{
    CUresult res = CUDA_SUCCESS;
    CUtoolsStreamHandle stream;
    ICdevGlobalData *hostData = NULL;
    CCinitcheckCtxData *ctxData = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = initcheckGetContextData(mcctx);
    if (!ctxData) {
        CU_DEBUG_PRINT(("Context not yet created\n"));
        return CUDA_SUCCESS;
    }

    hostData = (ICdevGlobalData*)ctxData->globalData.host.ptr;

    /* Grab the barrier stream and use it to initialize and push down internal
       tracking structures */
    res = mcctx->gvars->tools.context->CtxGetBarrierStream(mcctx->cuctx, &stream);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to get barrier stream\n"));
        printInternalError(CU_MEMCHECK_ERROR_DYNAMIC_INIT_FAILED,
                           mcctx->gvars);
        return res;
    }

    res = updateAllocTable(mcctx, ctxData, stream);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to update alloc table\n"));
        return res;
    }

    hostData->numAllocs = (uint32_t)ctxData->numAllocs;
    hostData->allocTablePtr = ctxData->allocTable.dev.dPtr;
    hostData->hasHeapAlloc = ctxData->hasHeap;
    hostData->heapAllocIndex = ctxData->heapAllocIndex;

    /* Push it down to the device */
    res = CCmemShadowHtoDStream(&ctxData->globalData, &ctxData->globalData,
                                stream, CC_MEM_SHADOW_ACTION_MEMCPY);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to copy shadow to device\n"));
        return res;
    }

    return res;
}

static CUresult
createGlobalData(MCcontext *mcctx, CCinitcheckCtxData *ctxData)
{
    CUresult res = CUDA_SUCCESS;
    ICdevGlobalData *hostData = NULL;

    CU_TRACE_FUNCTION();
    CU_ASSERT(mcctx);

    if (!mcctx || !ctxData) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData->globalData.size = sizeof(ICdevGlobalData);
    ctxData->globalData.mcctx = mcctx;
    ctxData->globalData.devseg = HALO_MEM_SEG_GLOBAL;

    CU_TRACE_PRINT(("Trying to allocate GlobalData : %u bytes\n",
                    ctxData->globalData.size));

    res = CCallocateDevice(&ctxData->globalData, NULL);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("\n"));
        return res;
    }

    res = CCallocateHost(&ctxData->globalData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("\n"));
        return res;
    }

    /* Reset the host shadow */
    hostData = (ICdevGlobalData*)ctxData->globalData.host.ptr;
    memset(hostData, 0, sizeof(*hostData));

    /* Update global data will do the memcpy down to the device */
    return updateGlobalData(mcctx);
}

static CUresult
createAllocTrackingTable(MCcontext *mcctx, CCinitcheckCtxData *ctxData)
{
    TOOLSresult tres = TOOLS_SUCCESS;

    tres = toolsRangeMapCreate(&ctxData->allocTrackingTables);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to create rangemap. (tres=%u)\n", tres));
        return CUDA_ERROR_UNKNOWN;
    }
    return CUDA_SUCCESS;
}

static CUresult
createDeviceTables(MCcontext *mcctx, CCinitcheckCtxData *ctxData)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!mcctx || !ctxData) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    res = createAllocTrackingTable(mcctx, ctxData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to create rangemap\n"));
        return res;
    }

    res = createGlobalData(mcctx, ctxData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to create error buffer\n"));
        return res;
    }

    return res;
}

static CUresult
loadInitcheckCtxModules(MCcontext *mcctx, CCinitcheckCtxData *ctxData)
{
    CUresult res = CUDA_SUCCESS;
    MCfunc *ldstFunc = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !ctxData) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* In the case of initcheck, we want to load up the initcheck module
       which contains all the per context stuff. This module is in CUDA-C
       and has no SASS level relocs to be applied
     */
    res = loadModuleFromCubinCommon(&ctxData->mod, mcctx, allCubins_memcheck, NULL, 0, false, false);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load module. \n"));
        return res;
    }

    ldstFunc = mcModuleGetFuncByName(ctxData->mod, "MCICperAccess");
    if (!ldstFunc) {
        CU_ERROR_PRINT(("Could not get MCICperAccess common function\n"));
        return CUDA_ERROR_UNKNOWN;
    }
    ctxData->commonPerLdst = ldstFunc->mem.dev.dPtr;


    return CUDA_SUCCESS;
}

CUresult
initcheckLoadGlobalLDSTStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, uint64_t patchPC, MCfunc **stubFunc)
{
    CCinitcheckRecData *recData = NULL;
    CCinitcheckCtxData *ctxData = NULL;
    CCsymbol sym[15] = {{0}};
    CUresult res = CUDA_SUCCESS;
    MCmod *mod = NULL;
    MCfunc *func = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;
    uint32_t asize = 0;
    uint32_t ra_lo, ra_hi = 0, type = 0;
    bool voltaPlus = false;
    bool turingPlus = false;
    bool hasUniformRegister = false;

    CU_TRACE_FUNCTION();

    /* In here to load an entry exit module */
    if (!rec) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = initcheckGetRecData(rec);
    if (!recData) {
        CU_ERROR_PRINT(("Invalid RC data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = initcheckGetContextData(rec->context);
    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid context data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    hasUniformRegister = rec->context->hal.hasUniformRegister(inst);
    asize = rec->context->hal.getMemAccessSize(inst, rec->func, patchPC);
    ra_lo = rec->context->hal.getRa(inst);

    // The logic of using RA_HI depends on URF:
    // - If No URF, this is set by the extended bit
    // - If URF, this is set by U64 bit
    if (ra_lo != rec->context->hal.getRz()) {
        if (hasUniformRegister) {
            if (rec->context->hal.getU64(inst))
                ra_hi = ra_lo + 1;
        }
        else {
            if (rec->context->hal.getExtended(inst))
                ra_hi = ra_lo + 1;
        }
    }

    // If this was part of a 16b atomic sequence, override ra_lo
    if (asize == sizeof(uint16_t)) {
        uint16_t regId;
        if (mcFuncIsInstructionAtom16(rec->func, patchPC, &regId)) {
            ra_lo = regId;
        }
    }

    if (rec->context->hal.isGtasLd(inst) ||
        rec->context->hal.isLdg(inst))
        type = IC_DEV_ACCESS_TYPE_READ;
    else if (rec->context->hal.isGtasSt(inst) ||
        rec->context->hal.isStg(inst))
        type = IC_DEV_ACCESS_TYPE_WRITE;
    else if (rec->context->hal.isAtom(inst) ||
        rec->context->hal.isAtomG(inst) ||
        rec->context->hal.isRed(inst))
        type = IC_DEV_ACCESS_TYPE_ATOM;

    voltaPlus  = getArchFromSmVer(rec->context->sm_version) >= MC_TOOL_MODE_ARCH_SM70;
    turingPlus = getArchFromSmVer(rec->context->sm_version) >= MC_TOOL_MODE_ARCH_SM75;

    // branch to bypass label if orig pred is false
    sym[0].name     = "IC_STUB_GL_LDST_BYPASS_BRANCH";
    sym[0].type     = CC_SYMBOL_TYPE_MASKED;
    sym[0].val      = rec->context->hal.getPredRawInv(inst);
    sym[0].mask     = rec->context->hal.getPredMask(inst);
    if (getArchFromSmVer(rec->context->sm_version) >= MC_TOOL_MODE_ARCH_SM70) {
        sym[0].size = CC_SYMBOL_SIZE_128;
        sym[0].masks[1] = 0;
    }

    // Kepler-Pascal: mov lo addr reg to R4 (full inst reloc)
    // Volta+       : spill lo addr reg into lmem
    sym[1].name     = "IC_STUB_GL_LDST_MOV_RA_LO";
    if (voltaPlus)
        rec->context->hal.genLmemHiSpill(INITCHECK_LMEM_RA_LO, sizeof(uint32_t), ra_lo, (uint64_t*)&(sym[1].val));
    else
        rec->context->hal.genMov(4, ra_lo, (uint64_t*)&(sym[1].val));
    setSymbolSize(rec->context, &sym[1]);

    if (ra_hi) {
        // Kepler-Pascal: mov hi addr reg to R5 (full inst reloc)
        // Volta+       : spill hi addr reg into lmem
        sym[2].name     = "IC_STUB_GL_LDST_MOV_RA_HI";
        if (voltaPlus)
            rec->context->hal.genLmemHiSpill(INITCHECK_LMEM_RA_HI, sizeof(uint32_t), ra_hi, (uint64_t*)&(sym[2].val));
        else
            rec->context->hal.genMov(5, ra_hi, (uint64_t*)&(sym[2].val));
        setSymbolSize(rec->context, &sym[2]);
    }

    // original instruction (full inst reloc)
    sym[3].name     = "IC_STUB_GL_LDST_ORIG_INST";
    res = assignInstSymbol(rec->context, &sym[3], inst);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to assign inst symbol\n"));
        return res;
    }

    // memory access size (in bytes) of the orig instruction
    sym[4].name     = "IC_STUB_GL_LDST_ASIZE";
    sym[4].val      = asize;

    // device address of common checker function
    sym[5].name     = "IC_STUB_GL_LDST_CHECK";
    sym[5].val      = ctxData->commonPerLdst;

    // return address in user code after patch completion
    sym[6].name     = "IC_STUB_GL_LDST_JUMP_RETURN";
    sym[6].val      = returnTarget;

    // immediate addr offset of original instruction
    sym[7].name     = "IC_STUB_GL_LDST_OFFSET";
    sym[7].val      = rec->context->hal.getOffset(inst);

    // the patched PC (32/64bit), depending on arch
    sym[8].name     = "IC_STUB_GL_LDST_PC";
    sym[8].val      = patchPC;

    // type of original instruction (read, write, atom)
    sym[9].name     = "IC_STUB_GL_LDST_TYPE";
    sym[9].val      = type;

    // device address of global checker state
    sym[10].name    = "IC_STUB_GL_LDST_GLOBAL_ADDR";
    sym[10].val     = ctxData->globalData.dev.dPtr;

    if (getArchFromSmVer(rec->context->sm_version) >= MC_TOOL_MODE_ARCH_SM50 &&
        getArchFromSmVer(rec->context->sm_version) <  MC_TOOL_MODE_ARCH_SM70) {
        // replace Pg with inverse of the orig instr Plg
        // Plg exists only on Maxwell/Pascal
        sym[11].name = "IC_STUB_GL_LDST_PLG_BRANCH";
        sym[11].type = CC_SYMBOL_TYPE_MASKED;
        rec->context->hal.genPlgRawInv(inst, (uint64_t *)&sym[11].val);
        sym[11].mask = rec->context->hal.getPredMask(inst);
    }

    // URF source
    if (hasUniformRegister) {
        uint32_t urb_lo = rec->context->hal.getURb(inst);
        uint32_t urb_hi = rec->context->hal.getURz();

        if (rec->context->hal.getExtended(inst)) {
            urb_hi = urb_lo + 1;
        }

        // MOV R6, URb
        sym[12].name = "IC_STUB_GL_LDST_MOV_URB_LO";
        rec->context->hal.genMovFromUR(6, urb_lo, (uint64_t*)(&sym[12].val));
        setSymbolSize(rec->context, &sym[12]);

        // MOV R7, Urb+1
        sym[13].name = "IC_STUB_GL_LDST_MOV_URB_HI";
        rec->context->hal.genMovFromUR(7, urb_hi, (uint64_t*)(&sym[13].val));
        setSymbolSize(rec->context, &sym[13]);
    }

    // Pnz
    if (turingPlus) {
        sym[14].name     = "IC_STUB_GL_LDST_BYPASS_BRANCH_PNZ";
        sym[14].type     = CC_SYMBOL_TYPE_MASKED;
        sym[14].val      = rec->context->hal.getPnzInvAsPgMask(inst);
        sym[14].masks[0] = rec->context->hal.getPredMask(inst);
        sym[14].masks[1] = 0;
        sym[14].size     = CC_SYMBOL_SIZE_128;
    }

    res = loadModuleFromCubin(&mod, rec->context, allCubins_initcheck_stub_globalldst, sym,
                              sizeof(sym)/sizeof(sym[0]));
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load cubins\n"));
        return res;
    }

    func = mcModuleGetFuncByName(mod, "initcheckStubGlobalLDST");
    if (!func) {
        CU_ERROR_PRINT(("Could not get stub function\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    tres = toolsListAppend(recData->internalModules, mod);
    if (tres != TOOLS_SUCCESS) {
        CU_ERROR_PRINT(("Failed to append module to list. (tres=%u)\n", tres));
        return CUDA_ERROR_UNKNOWN;
    }

    if (stubFunc) {
        CU_DEBUG_PRINT(("Returning global ldst stub entry at : 0x%" PRIx64 "\n",
                        func->mem.dev.dPtr));
        *stubFunc = func;
    }

    return CUDA_SUCCESS;
}

static CUresult
initcheckCreatePatchHelpers(MCcontext *mcctx, MCrec *rec,
                            CUtoolsStreamHandle stream)
{
    CUresult status = CUDA_SUCCESS;
    CCinitcheckRecData *recData = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !rec || !stream) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData = (CCinitcheckRecData*)calloc(1, sizeof(*recData));
    if (!recData) {
        CU_ERROR_PRINT(("Failed to allocate rec data\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    recData->internalModules = toolsListNew();
    if (!recData->internalModules) {
        CU_ERROR_PRINT(("Failed to create module list\n"));
        free(recData);
        return CUDA_ERROR_UNKNOWN;
    }

    rec->tm.ptr[MC_TOOL_MODE_INITCHECK] = (void*)recData;

    status = updateGlobalData(mcctx);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to update global data\n"));
        return status;
    }

    return status;
}

CUresult
initcheckGetGlobalsDptr(MCcontext *mcctx, uint64_t *dptr)
{
    CUresult res = CUDA_SUCCESS;
    CCinitcheckCtxData *ctxData = NULL;

    if (!mcctx || !dptr) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return res;
    }

    ctxData = initcheckGetContextData(mcctx);

    if (!ctxData) {
        CU_ERROR_PRINT(("RC data already freed\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *dptr = ctxData->globalData.dev.dPtr;
    return CUDA_SUCCESS;
}

static CUresult
destroyGlobalData(CCinitcheckCtxData *ctxData, CCmemCleanup *cleanup)
{
    CU_TRACE_FUNCTION();

    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    CCfreeDevice(&ctxData->globalData, cleanup);
    CCfreeHost(&ctxData->globalData);
    return CUDA_SUCCESS;
}

static CUresult
destroyDeviceTables(CCinitcheckCtxData *ctxData, CCmemCleanup *cleanup)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!ctxData) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }


    res = destroyAllocTrackingTables(ctxData, cleanup);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to destroy alloc tracking tables\n"));
        return res;
    }

    res = destroyAllocTable(ctxData, cleanup);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to destroy alloc table\n"));
        return res;
    }

    res = destroyGlobalData(ctxData, cleanup);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to destroy global data\n"));
        return res;
    }

    return CUDA_SUCCESS;
}

static CUresult
initcheckDestroyPatchHelpers(MCcontext *mcctx, MCrec *rec, CCmemCleanup *cleanup)
{
    CUresult status = CUDA_SUCCESS;
    CCinitcheckRecData **pRcData = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !rec) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    pRcData = (CCinitcheckRecData**)&rec->tm.ptr[MC_TOOL_MODE_INITCHECK];
    if (*pRcData) {
        toolsListDelete((*pRcData)->internalModules, NULL, NULL);
        (*pRcData)->internalModules = NULL;

        free(*pRcData);
        *pRcData = NULL;
    }
    return status;
}


static bool
initcheckHasPrologue(MCcontext *mcctx)
{
    return true;
}

static bool
initcheckUsesTrapHandler(MCoptions *options)
{
    return true;
}

static void CUDAAPI
setGlobalVarInitCallback(void *data, CUtoolsGlobalVariableProperties *props)
{
    MCmod *mod = (MCmod*)data;
    CUresult res = CUDA_SUCCESS;
    CCinitcheckCtxData *ctxData = NULL;
    CUtoolsStreamHandle stream;

    ctxData = initcheckGetContextData(mod->context);

    if (!ctxData) {
        CU_ERROR_PRINT(("No context data\n"));
        return;
    }

    res = mod->context->gvars->tools.context->CtxGetBarrierStream(mod->context->cuctx, &stream);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to get barrier stream\n"));
        return;
    }

    res = setAllocTracking(mod->context,
                           ctxData,
                           stream,
                           (uint64_t)(uintptr_t) props->devptr,
                           props->sizeInBytes,
                           true);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to set alloc initialized\n"));
        return;
    }
}

static CUresult
moduleSetGlobalsInitialized(MCcontext *mcctx, MCmod *mod)
{
    mod->context->gvars->tools.module->ModuleEnumerateGlobalVariables(mod->context->cuctx,
                                                                      mod->cumod,
                                                                      &setGlobalVarInitCallback,
                                                                      mod);

    return CUDA_SUCCESS;
}

static CUresult
initcheckModuleLoaded(MCcontext *mcctx, MCmod *mod)
{
    CUresult res = CUDA_SUCCESS;
    MCDynamicSchemeConfig schemeConfig = {0};

    CU_TRACE_FUNCTION();

    if (!mcctx || !mod) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    CU_TRACE_PRINT(("Initializing Dynamic Memcheck\n"));
    res = MCDynamicInitialize(mcctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to initialize dynamic memcheck\n"));
        return res;
    }

    if (mcctx->dynamic->dynState.state == MC_DYN_INITIALIZED) {
        //Force the HAL to go into ABI mode
        res = MCDynamicGetSchemeConfig(mcctx,
                                       MC_DYNAMIC_SCHEME_INITCHECK,
                                       &schemeConfig);
        if (res != CUDA_SUCCESS || !schemeConfig.check) {
            CU_ERROR_PRINT(("Failure to read schemeConfig for scheme : %u\n",
                            MC_DYNAMIC_SCHEME_INITCHECK));
            return res;
        }

        mcCtxLock(mcctx);
        res = mcctx->instMgr->updateState(mcctx->instMgr,
                                          schemeConfig.check->regcount);
        mcCtxUnlock(mcctx);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Error while updating instMgr state\n"));
            return res;
        }
    }

    /* Set the global variables as initialized
       Per C/C++ spec, global variables are always
       considered to be initialized to their default
       values, unless an explicit initializer is present */
    res = moduleSetGlobalsInitialized(mcctx, mod);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to set globals loaded\n"));
        return res;
    }

    return res;
}

static CUresult
initcheckModuleUnloaded(MCcontext *mcctx, MCmod *mod)
{
    return CUDA_SUCCESS;
}

static CUresult
initcheckContextDestroyStart(MCcontext *mcctx)
{
    CCinitcheckCtxData *ctxData = NULL;
    tRangeMapItr *it;

    if (!mcctx) {
        CU_DEBUG_PRINT(("No context\n"));
        return CUDA_SUCCESS;
    }

    MCDynamicFinalize(mcctx);

    ctxData = initcheckGetContextData(mcctx);

    if (!ctxData) {
        CU_DEBUG_PRINT(("RC data already freed\n"));
        return CUDA_SUCCESS;
    }

    if (mcctx->gvars->options.enableUnusedMemory) {
        for (it = toolsRangeMapGetIterator(ctxData->allocTrackingTables);
             it;
             it = toolsRangeMapGetNext(ctxData->allocTrackingTables, it)) {
            CCICallocData *allocData = (CCICallocData *) toolsRangeMapGetEntry(it);
            checkUnusedMemory(mcctx, allocData->alloc, ctxData);
        }
    }

    /* Free the allocations */
    destroyDeviceTables(ctxData, NULL);

    /* Free the structure */
    free(ctxData);

    /* Reset the pointer */
    mcctx->tm.ptr[MC_TOOL_MODE_INITCHECK] = NULL;

    return CUDA_SUCCESS;
}

static CUresult
initcheckContextDestroyEnd(MCcontext *mcctx)
{
    return CUDA_SUCCESS;
}

static CUresult
initcheckHandlePatchCompletion(MCcontext *mcctx, MCrec *rec, MClaunch *launch)
{
    return CUDA_SUCCESS;
}

static CUresult
initcheckHeapSelected(MCcontext *mcctx, CCalloc *heap)
{
    CUresult res = CUDA_SUCCESS;
    CCinitcheckCtxData *ctxData = NULL;
    uint64_t allocSize;
    CUtoolsStreamHandle stream;

    CU_TRACE_FUNCTION();

    if (!mcctx || !heap) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = initcheckGetContextData(mcctx);
    if (!ctxData) {
        CU_DEBUG_PRINT(("Context not yet created\n"));
        return CUDA_SUCCESS;
    }

    /* If we already have a heap alloc, remove it. It needs to be directly
       removed since the ctxAllocs table no longer contains it
    */

    res = destroyAllocTracking(heap, ctxData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Old heap not found. Marching on\n"));
    }
    else {
        --ctxData->numAllocs;
        ctxData->regenerateAllocTable = 1;
    }

    /* Add the heap */
    allocSize = CCallocGetSize(heap);
    if (!allocSize) {
        CU_DEBUG_PRINT(("Empty heap\n"));
        return CUDA_SUCCESS;
    }

    res = createAllocTracking(mcctx, ctxData, heap);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to allocate tracking\n"));
        return res;
    }

    ++ctxData->numAllocs;
    ctxData->hasHeap = 1;
    ctxData->heapDptr = CCallocGetStart(heap);
    ctxData->regenerateAllocTable = 1;

    if (mcctx->dynamic &&
        mcctx->dynamic->dynState.state == MC_DYN_INITIALIZED) {

        /* Grab the barrier stream and use it to initialize and push down internal
           tracking structures */
        res = mcctx->gvars->tools.context->CtxGetBarrierStream(mcctx->cuctx, &stream);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to get barrier stream\n"));
            printInternalError(CU_MEMCHECK_ERROR_DYNAMIC_INIT_FAILED,
                               mcctx->gvars);
            return res;
        }

        res = MCDynamicActivateScheme(mcctx,
                                      stream,
                                      MC_DYNAMIC_SCHEME_INITCHECK);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to activate dynamic memcheck\n"));
            printInternalError(CU_MEMCHECK_ERROR_DYNAMIC_INIT_FAILED,
                               mcctx->gvars);
            return res;
        }
    }

    res = updateGlobalData(mcctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to update global data\n"));
        return res;
    }

    return CUDA_SUCCESS;
}

static CUresult
initcheckContextSync(MCcontext *mcctx)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_DEBUG_PRINT(("No context\n"));
        return CUDA_SUCCESS;
    }

    res = updateGlobalData(mcctx);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to update global data\n"));
        return res;
    }

    return res;
}

static bool
initcheckEnableApiCheck(MCoptions *options)
{
    return false;
}

static CUresult
initcheckIsArchSupported(MCtoolMode *toolMode, MCtoolModeArchs arch, uint32_t *supported)
{
    if (!toolMode || !supported) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *supported = 0;

    if (arch >= MC_TOOL_MODE_ARCH_SM30 && arch <= MC_TOOL_MODE_ARCH_SM80)
        *supported = 1;

    return CUDA_SUCCESS;
}

static CUresult
initcheckIsOsSupported(MCtoolMode *toolMode, uint32_t *supported)
{
    if (!toolMode || !supported) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *supported = 1;

    return CUDA_SUCCESS;
}

static CUresult
initcheckIsModuleSupported(MCcontext *mcctx, MCmod *mod, CUmemcheck_error_types *modSupportedError)
{
    if (!mcctx || !mod || !modSupportedError) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    if (mod->modOpts.usesLegacyAtomF16 &&
        !mcctx->gvars->modUsesLegacyAtomF16Warned) {
        // Warn once if we detect unsupported atom f16 instructions
        printInternalWarning(CU_MEMCHECK_WARNING_USES_LEGACY_ATOM_F16, mcctx->gvars);
        mcctx->gvars->modUsesLegacyAtomF16Warned = true;
    }

    *modSupportedError = CU_MEMCHECK_ERROR_NONE;

    if (mod->modOpts.usesCnp)
        *modSupportedError = CU_MEMCHECK_ERROR_UNSUPPORTED_CNP;

    return CUDA_SUCCESS;
}

static CUresult
initcheckUpdateLaunchConfig(MCcontext *mcctx, MCfunc *func, CUtoolsFunctionLaunchConfig *config)
{
    uint32_t minCRS = 0;
    CCinitcheckCtxData *ctxData = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx || !func || !config) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = initcheckGetContextData(mcctx);
    if (!ctxData) {
        CU_DEBUG_PRINT(("RC data already freed\n"));
        return CUDA_SUCCESS;
    }

    minCRS = ctxData->minCRS + 4;

    /* Update CRS to account for the max of the various context functions + 4 for the stub */
    if (config->syncStackSizeLaunch < minCRS + config->syncStackSizeCompiler + config->syncStackSizeDriver) {
        CU_TRACE_PRINT(("Updating CRS size for toolmode from : %u to %u\n",
                        config->syncStackSizeLaunch,
                        minCRS + config->syncStackSizeCompiler + config->syncStackSizeDriver));
        config->syncStackSizeLaunch = minCRS + config->syncStackSizeCompiler + config->syncStackSizeDriver;
    }

    return CUDA_SUCCESS;
}

static bool
initcheckEnableMemAccessCheck (MCoptions *options)
{
    if (!options)
        return false;

    return (options->checkMemcpyMemset);
}

static CUresult
initcheckCheckMemAccessDevAddr(MCcontext *mcctx, uint64_t addr, uint64_t size, CUtoolsStreamHandle stream, CCmemAccessType accessType)
{
    CUresult res = CUDA_SUCCESS;
    CCalloc *alloc = NULL;
    CCinitcheckCtxData *ctxData = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid args\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = initcheckGetContextData(mcctx);
    if (!ctxData) {
        CU_DEBUG_PRINT(("RC data already freed\n"));
        return CUDA_SUCCESS;
    }

    /* Need to do this bit under the context lock */
    mcCtxLock(mcctx);
    res =  CCallocTableFindByAddr(mcctx->ctxAllocs, addr, &alloc);

    if (!alloc && mcctx->heapAlloc && CCallocContainsRange(mcctx->heapAlloc, addr, size))
        alloc = mcctx->heapAlloc;

    mcCtxUnlock(mcctx);

    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to find alloc\n"));
        return res;
    }

    if (!alloc) {
        CU_ERROR_PRINT(("No alloc found\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* Before overriding device tracking table later, pull latest device-side
       changes to the host. Needs to be run before updateAllocTable to avoid
       pulling uninitialized values for new allocs. */
    switch (accessType) {
    case CC_MEM_ACCESS_TYPE_MEMCPY_DST:
    case CC_MEM_ACCESS_TYPE_MEMSET:
    case CC_MEM_ACCESS_TYPE_STREAM_WRITE:
        res = updateHostAllocTracking(ctxData, stream, addr);
        break;
    default:
        break;
    }

    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to update host alloc tracking copy\n"));
    }

    res = updateAllocTable(mcctx, ctxData, stream);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to update alloc table\n"));
        return res;
    }

    /*  Check if the allocation is tracked. Not all are... */
    if (!toolsRangeMapLookupByAddr(ctxData->allocTrackingTables, addr)) {
        CU_TRACE_PRINT(("Alloc not tracked\n"));
        return CUDA_SUCCESS;
    }

    /* For memset/Memcpy_dest, set the bits.
       For memcpy_src, check the bits */
    switch(accessType) {
    case CC_MEM_ACCESS_TYPE_MEMCPY_SRC:
        res = checkAllocTracking(mcctx, ctxData, stream, addr, size, accessType);
        break;
    case CC_MEM_ACCESS_TYPE_MEMCPY_DST:
    case CC_MEM_ACCESS_TYPE_MEMSET:
    case CC_MEM_ACCESS_TYPE_STREAM_WRITE:
        res = setAllocTracking(mcctx, ctxData, stream, addr, size, true);
        break;
    default:
        break;
    }
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed in the action for accessType:%u\n", accessType));
    }

    return res;
}

static CUresult
initcheckContextCreatedCallback(MCcontext *mcctx)
{
    CUresult res = CUDA_SUCCESS;
    CCinitcheckCtxData *ctxData = NULL;

    CU_TRACE_FUNCTION();

    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = (CCinitcheckCtxData*) calloc(1, sizeof(*ctxData));
    if (!ctxData) {
        CU_ERROR_PRINT(("Out of memory\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    /* Create tables */
    res = createDeviceTables(mcctx, ctxData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to create device tables !!!\n"));
        goto error;
    }

    /* Load modules */
    res = loadInitcheckCtxModules(mcctx, ctxData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to load required modules\n"));
        goto error;
    }

    /* Assign the pointer */
    mcctx->tm.ptr[MC_TOOL_MODE_INITCHECK] = (void*)ctxData;

    return CUDA_SUCCESS;

error:
    if (ctxData) {
        free(ctxData);
        ctxData = NULL;
    }

    return res;
}

static CUresult
initcheckInitEndCallback(MCglobals *gvars)
{
    return CUDA_SUCCESS;
}

static CUresult
initcheckAddAllocCallback(MCcontext *mcctx, CCalloc *alloc)
{
    CCinitcheckCtxData *ctxData = NULL;
    uint64_t allocSize;
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!mcctx || !alloc) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = initcheckGetContextData(mcctx);
    if (!ctxData) {
        CU_DEBUG_PRINT(("Context not yet created\n"));
        return CUDA_SUCCESS;
    }

    if (CCallocIsHostMapped(alloc)) {
        CU_DEBUG_PRINT(("Allocation is host mapped\n"));
        return CUDA_SUCCESS;
    }

    if (CCallocIsGlInterop(alloc)) {
        CU_DEBUG_PRINT(("Allocation is GL interop\n"));
        return CUDA_SUCCESS;
    }

    if (CCallocIsManaged(alloc)) {
        CU_DEBUG_PRINT(("Allocation is Managed\n"));
        return CUDA_SUCCESS;
    }

    allocSize = CCallocGetSize(alloc);
    if (!allocSize) {
        CU_DEBUG_PRINT(("Empty alloc\n"));
        return CUDA_SUCCESS;
    }

    res = createAllocTracking(mcctx, ctxData, alloc);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to allocate tracking\n"));
        return res;
    }

    ++ctxData->numAllocs;
    ctxData->regenerateAllocTable = 1;

    return res;
}

static CUresult
initcheckRemoveAllocCallback(MCcontext *mcctx, CCalloc *alloc)
{
    CCinitcheckCtxData *ctxData = NULL;
    uint64_t allocSize;
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!mcctx || !alloc) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    ctxData = initcheckGetContextData(mcctx);
    if (!ctxData) {
        CU_DEBUG_PRINT(("Context not yet created\n"));
        return CUDA_SUCCESS;
    }

    if (CCallocIsHostMapped(alloc)) {
        CU_DEBUG_PRINT(("Allocation is host mapped\n"));
        return CUDA_SUCCESS;
    }

    if (CCallocIsGlInterop(alloc)) {
        CU_DEBUG_PRINT(("Allocation is GL interop\n"));
        return CUDA_SUCCESS;
    }

    if (CCallocIsManaged(alloc)) {
        CU_DEBUG_PRINT(("Allocation is Managed\n"));
        return CUDA_SUCCESS;
    }

    allocSize = CCallocGetSize(alloc);
    if (!allocSize) {
        CU_DEBUG_PRINT(("Empty alloc\n"));
        return CUDA_SUCCESS;
    }

    if (mcctx->gvars->options.enableUnusedMemory) {
        res = checkUnusedMemory(mcctx, alloc, ctxData);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to check unused memory\n"));
            return res;
        }
    }

    res = destroyAllocTracking(alloc, ctxData);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to release alloc tracking\n"));
        return res;
    }

    --ctxData->numAllocs;
    ctxData->regenerateAllocTable = 1;

    return res;
}

CUresult
initcheck_toolModeInitialize(MCoptions *options, MCtoolMode *toolMode)
{
    MCtoolModeArchState *arch_sm30 = NULL;
    MCtoolModeArchState *arch_sm35 = NULL;
    MCtoolModeArchState *arch_sm50 = NULL;
    MCtoolModeArchState *arch_sm52 = NULL;
    MCtoolModeArchState *arch_sm60 = NULL;
    MCtoolModeArchState *arch_sm70 = NULL;
    MCtoolModeArchState *arch_sm75 = NULL;
    MCtoolModeArchState *arch_sm80 = NULL;

    CU_TRACE_FUNCTION();

    if (!toolMode)
        return CUDA_ERROR_UNKNOWN;

    // Raw table initialization
    arch_sm30 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM30];
    arch_sm35 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM35];
    arch_sm50 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM50];
    arch_sm52 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM52];
    arch_sm60 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM60];
    arch_sm70 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM70];
    arch_sm75 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM75];
    arch_sm80 = &toolMode->state.arch[MC_TOOL_MODE_ARCH_SM80];

    // Select instructions to patch for every arch
    if (options->enableSassPatching) {
        arch_sm30->checkMask = TO_CHECKTYPE_MASK(INITCHECK);
        arch_sm30->opMask[MC_CHECK_TYPE_INITCHECK] =  TO_INST_MASK(GENERIC_ST)  |
                                                     TO_INST_MASK(GENERIC_LD)  |
                                                     TO_INST_MASK(GLOBAL_LD)   |
                                                     TO_INST_MASK(GLOBAL_ST)   |
                                                     TO_INST_MASK(ATOM)        |
                                                     TO_INST_MASK(RED);

        arch_sm35->checkMask = TO_CHECKTYPE_MASK(INITCHECK);
        arch_sm35->opMask[MC_CHECK_TYPE_INITCHECK] =  TO_INST_MASK(GENERIC_ST)  |
                                                     TO_INST_MASK(GENERIC_LD)  |
                                                     TO_INST_MASK(GLOBAL_LD)   |
                                                     TO_INST_MASK(GLOBAL_ST)   |
                                                     TO_INST_MASK(ATOM)        |
                                                     TO_INST_MASK(RED);

        arch_sm50->checkMask = TO_CHECKTYPE_MASK(INITCHECK);
        arch_sm50->opMask[MC_CHECK_TYPE_INITCHECK] =  TO_INST_MASK(GENERIC_ST)  |
                                                     TO_INST_MASK(GENERIC_LD)  |
                                                     TO_INST_MASK(GLOBAL_LD)   |
                                                     TO_INST_MASK(GLOBAL_ST)   |
                                                     TO_INST_MASK(ATOM)        |
                                                     TO_INST_MASK(RED);

        arch_sm52->checkMask = TO_CHECKTYPE_MASK(INITCHECK);
        arch_sm52->opMask[MC_CHECK_TYPE_INITCHECK] =  TO_INST_MASK(GENERIC_ST)  |
                                                     TO_INST_MASK(GENERIC_LD)  |
                                                     TO_INST_MASK(GLOBAL_LD)   |
                                                     TO_INST_MASK(GLOBAL_ST)   |
                                                     TO_INST_MASK(ATOM)        |
                                                     TO_INST_MASK(RED);

        arch_sm60->checkMask = TO_CHECKTYPE_MASK(INITCHECK);
        arch_sm60->opMask[MC_CHECK_TYPE_INITCHECK] =  TO_INST_MASK(GENERIC_ST)  |
                                                     TO_INST_MASK(GENERIC_LD)  |
                                                     TO_INST_MASK(GLOBAL_LD)   |
                                                     TO_INST_MASK(GLOBAL_ST)   |
                                                     TO_INST_MASK(ATOM)        |
                                                     TO_INST_MASK(RED);

        arch_sm70->checkMask = TO_CHECKTYPE_MASK(INITCHECK);
        arch_sm70->opMask[MC_CHECK_TYPE_INITCHECK] =  TO_INST_MASK(GENERIC_ST)  |
                                                     TO_INST_MASK(GENERIC_LD)  |
                                                     TO_INST_MASK(GLOBAL_LD)   |
                                                     TO_INST_MASK(GLOBAL_ST)   |
                                                     TO_INST_MASK(ATOM)        |
                                                     TO_INST_MASK(ATOM_GLOBAL) |
                                                     TO_INST_MASK(RED);

        arch_sm75->checkMask = TO_CHECKTYPE_MASK(INITCHECK);
        arch_sm75->opMask[MC_CHECK_TYPE_INITCHECK] =  TO_INST_MASK(GENERIC_ST)  |
                                                     TO_INST_MASK(GENERIC_LD)  |
                                                     TO_INST_MASK(GLOBAL_LD)   |
                                                     TO_INST_MASK(GLOBAL_ST)   |
                                                     TO_INST_MASK(ATOM)        |
                                                     TO_INST_MASK(ATOM_GLOBAL) |
                                                     TO_INST_MASK(RED);

        /* Ampere GA10x */
        arch_sm80->checkMask = TO_CHECKTYPE_MASK(INITCHECK);
        arch_sm80->opMask[MC_CHECK_TYPE_INITCHECK] =  TO_INST_MASK(GENERIC_ST)  |
                                                     TO_INST_MASK(GENERIC_LD)  |
                                                     TO_INST_MASK(GLOBAL_LD)   |
                                                     TO_INST_MASK(GLOBAL_ST)   |
                                                     TO_INST_MASK(ATOM)        |
                                                     TO_INST_MASK(ATOM_GLOBAL) |
                                                     TO_INST_MASK(RED);
    }
    toolMode->createPatchHelpers = initcheckCreatePatchHelpers;
    toolMode->destroyPatchHelpers = initcheckDestroyPatchHelpers;
    toolMode->hasPrologue = initcheckHasPrologue;
    toolMode->usesTrapHandler = initcheckUsesTrapHandler;
    toolMode->moduleLoadedCallback = initcheckModuleLoaded;
    toolMode->moduleUnloadedCallback = initcheckModuleUnloaded;
    toolMode->contextDestroyStartCallback = initcheckContextDestroyStart;
    toolMode->contextDestroyEndCallback = initcheckContextDestroyEnd;
    toolMode->heapSelectedCallback = initcheckHeapSelected;
    toolMode->ctxSyncCallback  = initcheckContextSync;
    toolMode->enableApiCheck = initcheckEnableApiCheck;
    toolMode->handlePatchCompletion = initcheckHandlePatchCompletion;
    toolMode->isArchSupported = initcheckIsArchSupported;
    toolMode->isOsSupported = initcheckIsOsSupported;
    toolMode->isModuleSupported = initcheckIsModuleSupported;
    toolMode->updateLaunchConfig = initcheckUpdateLaunchConfig;

    toolMode->contextCreatedCallback = initcheckContextCreatedCallback;
    toolMode->enableMemAccessCheck = initcheckEnableMemAccessCheck;
    toolMode->checkMemAccessDevAddr = initcheckCheckMemAccessDevAddr;
    toolMode->trapHandlerCallback = initcheckTrapHandlerCallback;
    toolMode->trapHandlerEndCallback = initcheckTrapHandlerEndCallback;
    toolMode->initEndCallback = initcheckInitEndCallback;
    toolMode->addAllocCallback = initcheckAddAllocCallback;
    toolMode->removeAllocCallback = initcheckRemoveAllocCallback;

    toolMode->getInternalModules = initcheckGetInternalModules;

    toolMode->getExceptionType = initcheckGetExceptionType;

    return CUDA_SUCCESS;
}
