/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef CHECK_INITCHECK_H
#define CHECK_INITCHECK_H

#include "cudamemcheck.h"
#include "memcheck_types.h"
#include "memcheck_tool_modes.h"
#include "memcheck_inst_types.h"
#include "initcheck/initcheck_structs.h"
#include "check_bitpool.h"
#include "tools_shared_rangemap.h"
#include "cuos.h"

/* The initcheck data that we care about from the host side is mainly tracking of state*/

typedef struct CCinitcheckCtxData_st CCinitcheckCtxData;
typedef struct CCinitcheckRecData_st CCinitcheckRecData;

struct CCinitcheckCtxData_st {

    /* Global data */
    CCmemHandle globalData;

    /* Allocation Table */
    CCmemHandle allocTable;

    /* Main CudaC module */
    MCmod *mod;

    /* Context common entry points */
    uint64_t commonPerLdst;

    /* Global config options */
    uint32_t minCRS;
    uint32_t maxStack;

    /* Rangemap to hold the tracking tables */
    tRangeMap *allocTrackingTables;

    uint32_t regenerateAllocTable;
    size_t numAllocs;
    uint32_t hasHeap;
    uint64_t heapDptr;
    uint32_t heapAllocIndex;
};

struct CCinitcheckRecData_st {
    /* Mainly for cleanup /repatching */
    tList   *internalModules;

};

CUresult initcheck_toolModeInitialize(MCoptions *options, MCtoolMode *toolMode);

CUresult initcheckTrapHandlerCallback(MCcontext *mcctx, CUmemobj *scratchpad, uint32_t smError);
CUresult initcheckTrapHandlerEndCallback(MCcontext *mcctx, CUmemobj *scratchpad, uint32_t smError);

CCinitcheckCtxData* initcheckGetContextData(MCcontext *mcctx);
CCinitcheckRecData* initcheckGetRecData(MCrec *rec);

CUresult initcheckLoadGlobalLDSTStub(MCrec *rec, uint64_t *inst, uint64_t returnTarget, uint64_t patchPC, MCfunc **stubFunc);

CUresult initcheckGetGlobalsDptr(MCcontext *mcctx, uint64_t *dptr);
#endif

