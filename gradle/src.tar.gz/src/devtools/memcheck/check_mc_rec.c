#include "memcheck_types.h"
#include "check_mc_rec.h"
#include "check_mc_context.h"
#include "check_mc_module.h"
#include "check_mc_func.h"
#include "memcheck_error.h"

#include "memmgr.h"
#include "memblock.h"

#include "halo.h"
#include "cuicnp.h"
#include "tools_shared.h"
#include "cudbgdriver.h"
#include "check_alloc.h"
#include "check_mem.h"

typedef struct CUmemblockList_st CUmemblockList;
struct CUmemblockList_st {
    CUmemblock *memblock;
    CUmemblockList *next;
};

static CUresult
setFunctionSetup(MCrec *rec, CUfunction cufunc)
{
    CUresult status;
    uint64_t launchPC = 0;
    MCinstManager *instMgr = NULL;

    rec->config.struct_size = sizeof(rec->config);
    instMgr = rec->context->instMgr;

    status = rec->tools->module->FunctionGetLaunchConfig(cufunc, &rec->config);
    if (status != CUDA_SUCCESS) {
        printInternalError(CU_MEMCHECK_ERROR_FAILED_INITIALIZATION,
                           rec->gvars);

        CU_ERROR_PRINT(("\n"));
        return status;
    }

    /* Only save to origConfig if has not been written to */
    if (!rec->origConfig.struct_size) {
        status = rec->tools->module->FunctionGetLaunchPc(cufunc, &launchPC);
        if (status != CUDA_SUCCESS) {
            printInternalError(CU_MEMCHECK_ERROR_FAILED_INITIALIZATION,
                               rec->gvars);

            CU_ERROR_PRINT(("\n"));
            return status;
        }

        memcpy(&rec->origConfig, &rec->config, sizeof (rec->origConfig));
        rec->origPC = launchPC;
    }

    status = instMgr->updateLaunchConfig(instMgr, &rec->config);

    if (status == CUDA_ERROR_OUT_OF_MEMORY) {
        printInternalError(CU_MEMCHECK_ERROR_OUT_OF_DEVICE_MEMORY,
                           rec->gvars);

        CU_ERROR_PRINT(("Insufficient device memory for patch\n"));
        return status;
    }
    else if (status != CUDA_SUCCESS) {
        printInternalError(CU_MEMCHECK_ERROR_FAILED_INITIALIZATION,
                           rec->gvars);
        CU_ERROR_PRINT(("Failed to update launch config\n"));
        return status;
    }

    status = rec->gvars->toolMode.updateLaunchConfig(rec->context, rec->func, &rec->config);
    if (status != CUDA_SUCCESS) {
        printInternalError(CU_MEMCHECK_ERROR_FAILED_INITIALIZATION,
                           rec->gvars);
        CU_ERROR_PRINT(("Failed to update launch config for toolmode\n"));
        return status;
    }

    status = rec->tools->module->FunctionSetLaunchConfigHostAndDevice(cufunc, &rec->config);
    if (status != CUDA_SUCCESS) {
        printInternalError(CU_MEMCHECK_ERROR_FAILED_INITIALIZATION,
                           rec->gvars);

        CU_ERROR_PRINT(("Failed to set launch config\n"));
        return status;
    }

    return CUDA_SUCCESS;
}

static CUresult
resetFunc(MCrec *rec, CUtoolsStreamHandle stream)
{
    CUresult status = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    status = CCmemShadowHtoDStream(&rec->func->mem, &rec->func->mem,
                                   stream,
                                   CC_MEM_SHADOW_ACTION_MEMCPY);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to reset function\n"));
        return status;
    }

    /* Make sure the above memcpy makes it to the device so the
     * debugger can re-insert function breakpoints as needed */
    if (rec->options.debuggerAttached) {
        status = mcContextStreamSynchronize(rec->context, stream);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to synchronize reset function\n"));
            return status;
        }
    }

    CCdbgInteropResetFunction(rec);

    return status;
}

static CUresult
resetPatch(MCrec *rec, MCcontext *mcctx, MCfunc *func, CUtoolsStreamHandle stream,
           uint64_t streamHandle, uint64_t previousStreamId, uint32_t resetFuncFlags)
{
    CUresult status = CUDA_SUCCESS;
    CCallocTableProperties props = {0};
    MCglobals *gvars = NULL;
    CUfunc *cufunc = NULL;

    CU_TRACE_FUNCTION();

    if (!rec || !mcctx || !func)
        return CUDA_ERROR_UNKNOWN;

    gvars = mcctx->gvars;
    cufunc = func->cufunc;

    rec->gvars = gvars;
    rec->context = mcctx;
    rec->func = func;
    rec->tools = &gvars->tools;
    rec->previousStreamId = previousStreamId;

    memcpy(&rec->options, &gvars->options, sizeof gvars->options);
    // Certain options are overridden by the context
    rec->options.nonblockingLaunch = (mcctx->ctxOpts.launchMode ==
                                      MC_CONTEXT_OPTION_LAUNCH_NONBLOCKING);

    /* On Keplers, we must always drain texture loads in the patch.
       On SM 3.2+, the LDG instruction actually uses the texture pipeline
       If its being used, we need to ensure the stubs drain all texture loads */
    if (mcctx->sm_version >= 300 && mcctx->sm_version < 400)
        rec->options.forceTexDrain = true;

    rec->funcBuffer.size = func->mem.size;

    props.flags = CC_ALLOC_TABLE_FLAG_READ_ONLY |
                  CC_ALLOC_TABLE_FLAG_COALESCE  |
                  CC_ALLOC_TABLE_FLAG_EXTERNAL  |
                  CC_ALLOC_TABLE_FLAG_STREAM_VISIBLE;
    props.streamHandle = streamHandle;

    mcCtxLock(mcctx);
    status = CCallocTableCopy(&rec->globalAllocs, mcctx->ctxAllocs, &props);
    mcCtxUnlock(mcctx);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to duplicate host allocation table\n"));
        return status;
    }

    CU_TRACE_PRINT(("Coalesce reduced allocs from %u to %u\n",
                    CCallocTableGetSize(mcctx->ctxAllocs),
                    CCallocTableGetSize(rec->globalAllocs)));

    if (NULL != mcctx->haloContext) {
        mcCtxLock(mcctx);
        mcctx->haloContext->funcMemBaseVA = mcctx->cuctx->device->hal.funcGetFuncMemBase(mcctx->cuctx, cufunc);
        mcCtxUnlock(mcctx);
    }

    status = setFunctionSetup(rec, cufunc);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("setFunctionSetup failed\n"));
        return status;
    }

    if (resetFuncFlags) {
        status = resetFunc(rec, stream);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to reset func\n"));
            return status;
        }
        status = mcRecRestoreFunctionSetup(rec, CC_CLEANUP_MODE_HOST_AND_DEVICE);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to cleanup host and device state\n"));
            return status;
        }
    }

    return CUDA_SUCCESS;
}

static CUresult
destroyDevicePatch(MCrec *rec, CCmemCleanup *cleanup)
{
    CU_ASSERT(rec);

    rec->patchOffset = 0;

    if (!rec->patchBuffer.size) {
        CU_DEBUG_PRINT(("Empty patch buffer\n"));
        return CUDA_SUCCESS;
    }

    CCfreeDevice(&rec->patchBuffer, cleanup);

    return CUDA_SUCCESS;
}

static CUresult
destroyHostFunc(MCrec *rec)
{
    CU_ASSERT(rec);

    CCfreeHost(&rec->funcBuffer);

    return CUDA_SUCCESS;
}

CUresult
mcRecCleanupPatchHost(MCrec *rec)
{
    CUresult status;

    CU_TRACE_FUNCTION();

    CU_ASSERT(rec);

    status = CCallocTableDestroy(&rec->globalAllocs);
    if (status != CUDA_SUCCESS)
        goto error;

    status = destroyHostFunc(rec);
    if (status != CUDA_SUCCESS)
        goto error;

    status = rec->context->instMgr->destroyAllocs(rec->context->instMgr, rec);
    if (status != CUDA_SUCCESS)
        goto error;

    return CUDA_SUCCESS;

error:
    printInternalError(CU_MEMCHECK_ERROR_FAILED_CLEANUP, rec->gvars);

    return status;
}

CUresult
mcRecCleanupPatchDevice(MCrec *rec, CCmemCleanup *cleanup)
{
    CUresult status;

    CU_TRACE_FUNCTION();

    CU_ASSERT(rec);

    status = rec->gvars->toolMode.destroyPatchHelpers(rec->context, rec, cleanup);
    if (status != CUDA_SUCCESS)
        goto error;

    status = destroyDevicePatch(rec, cleanup);
    if (status != CUDA_SUCCESS)
        goto error;

    return CUDA_SUCCESS;

error:
    printInternalError(CU_MEMCHECK_ERROR_FAILED_CLEANUP,
                       rec->gvars);

    return status;
}

CUresult
mcRecCleanup(MCrec *rec, CCmemCleanup *cleanup)
{
    CUresult status = CUDA_SUCCESS;

    // Destroy interop patch list
    CCdbgInteropRemovePatches(rec);

    status = mcRecCleanupPatchDevice(rec, cleanup);
    if (status != CUDA_SUCCESS)
        goto error;
    status = mcRecCleanupPatchHost(rec);
    if (status != CUDA_SUCCESS)
        goto error;

    return CUDA_SUCCESS;

error:
    CU_DEBUG_PRINT(("memcheck: function teardown failed (%d)\n", status));
    printInternalError(CU_MEMCHECK_ERROR_FAILED_CLEANUP, rec->gvars);

    return status;
}

CUresult
mcRecCreate(MCcontext *context, MCfunc *func, CUtoolsStreamHandle stream, uint64_t streamId, MCrec **pRec)
{
    MCrec *patch;
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!context || !func || !pRec)
        return CUDA_ERROR_UNKNOWN;

    patch = (MCrec *)calloc (1, sizeof *patch);
    if (!patch) {
        CU_ERROR_PRINT(("Failed to allocate patch entry\n"));
        return CUDA_ERROR_OUT_OF_MEMORY;
    }

    res = resetPatch(patch, context, func, stream, streamId, 0, 0);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to reset patch\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    *pRec = patch;

    return CUDA_SUCCESS;
}

CUresult
mcRecDestroy(MCrec *rec)
{
    CUresult res = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!rec)
        return CUDA_ERROR_UNKNOWN;

    res = rec->tools->module->FunctionSetLaunchPcHostAndDevice(
        rec->func->cufunc,
        rec->origPC);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to restore original launch PC for %s\n",
                        rec->func->funcName));
    }

    free(rec);

    return res;
}

CUresult
mcRecRestoreFunctionSetup(MCrec *rec, CCcleanupMode mode)
{
    CUresult status;
    MCfunc *func = NULL;

    CU_ASSERT(rec);

    func = rec->func;

    if (!rec->origConfig.struct_size)
        return CUDA_SUCCESS;

    if (mode == CC_CLEANUP_MODE_HOST_AND_DEVICE) {
        status = rec->tools->module->FunctionSetLaunchPcHostAndDevice(func->cufunc, rec->origPC);
        if (status != CUDA_SUCCESS) {
            printInternalError(CU_MEMCHECK_ERROR_FAILED_CLEANUP,
                               rec->gvars);

            CU_ERROR_PRINT(("\n"));
            return CUDA_ERROR_UNKNOWN;
        }

        status = rec->tools->module->FunctionSetLaunchConfigHostAndDevice(func->cufunc, &rec->origConfig);
        if (status != CUDA_SUCCESS) {
            printInternalError(CU_MEMCHECK_ERROR_FAILED_CLEANUP,
                               rec->gvars);

            CU_ERROR_PRINT(("\n"));
            return CUDA_ERROR_UNKNOWN;
        }
    }

    memset(&rec->origConfig, 0, sizeof(rec->origConfig));

    return CUDA_SUCCESS;
}

CUresult
mcRecClearPatch(MCrec *rec, CUtoolsStreamHandle stream, uint64_t streamId,
                uint32_t resetFuncFlags)
{
    CUresult res = CUDA_SUCCESS;
    MCcontext *mcctx = NULL;
    MCfunc *mcfunc = NULL;
    uint64_t previousStreamId = 0;

    if (!rec) {
        CU_TRACE_PRINT(("Null patch. Entry was stale\n"));
        return CUDA_SUCCESS;
    }

    if (rec->state == MC_PATCH_STATE_INITIALIZED) {
        CU_TRACE_PRINT(("Nothing to clear\n"));
        return CUDA_SUCCESS;
    }

    CU_TRACE_PRINT(("Clearing patch %p for func: %s\n", rec, rec->func->funcName));

    // Cache the context and function
    mcctx = rec->context;
    mcfunc = rec->func;
    previousStreamId = rec->previousStreamId;

    // Remove patch buffer from the context map if it exists
    if (rec->patchBuffer.size) {
        res = mcContextRemovePatchFromMap(mcctx, rec);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to remove patch from context map\n"));
            goto error;
        }
    }

    // Force deallocation of all device and host side buffers
    res = mcRecCleanup(rec, NULL);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to do patch cleanup\n"));
        goto error;
    }

    // Copy all the relevant data back into patch and reset
    // the allocation list
    res = resetPatch(rec, mcctx, mcfunc, stream, streamId, previousStreamId, resetFuncFlags);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to reset patch\n"));
        goto error;
    }

    // Clear all relevant internal state
    rec->state = MC_PATCH_STATE_INITIALIZED;

    return CUDA_SUCCESS;

error:
    rec->state = MC_PATCH_STATE_FAILED;
    return res;
}

CUresult
mcRecHandlePatchCompletion(MCrec *rec, MClaunch *launch)
{
    CUmemcheck_record err;
    uint32_t hasError = 0;
    CUresult res = CUDA_SUCCESS;
    MCcontext *context = NULL;

    CU_TRACE_FUNCTION();

    if (!rec || !launch)
        return CUDA_ERROR_UNKNOWN;

    // Patch was not set
    if (rec->state != MC_PATCH_STATE_ACTIVE)
        return CUDA_ERROR_UNKNOWN;

    CU_TRACE_PRINT(("Found a valid launch. Completing\n"));

    if (!createNewErrorRecord(CU_MEMCHECK_RECORD_MEM_PRECISE, &err)) {
        res = CUDA_ERROR_UNKNOWN;
        goto error;
    }

    res = rec->context->instMgr->parseErrorEntry(rec->context->instMgr,
                                                 rec, &err,
                                                 &hasError);

    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to parse error record\n"));
        goto error;
    }

    if (hasError) {
        res = addMemRecord(rec->context, &err, rec->func, launch->bt);
        if (res != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to add precise error\n"));
            goto error;
        }
        rec->state = MC_PATCH_STATE_LAUNCH_ERROR;
    }

    res = rec->context->gvars->toolMode.handlePatchCompletion(rec->context, rec, launch);
    if (res != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed in toolMode callback to handlePatchCompletion\n"));
        goto error;
    }

    return res;

error:
    CU_DEBUG_PRINT(("Failed to handle completion\n"));
    printInternalError(CU_MEMCHECK_ERROR_FAILED_CLEANUP,
                       rec->gvars);
    return res;
}

static void
createMemBlockList(CUctx *ctx, CUmemblockList *head)
{
    CUmemblockList *tmp;
    CUmemblock *m;

    if (!head || !ctx)
        return;

    memset(head, 0, sizeof *head);

    tmp = head;
    memmgrLock(ctx->memmgr);
    for (m = ctx->memmgr->memblocks; m; m = m->next) {
        if (m->memdesc.flags.type == CU_MEM_TYPE_FUNCTION) {
            tmp->next = (CUmemblockList *)calloc(1, sizeof *tmp);
            tmp = tmp->next;
            tmp->memblock = m;
        }
    }
    memmgrUnlock(ctx->memmgr);
}

static void
destroyMemBlockList(CUmemblockList *head)
{
    CUmemblockList *cur = NULL, *next = NULL;

    if (!head)
        return;

    cur = head->next;

    for (; cur; cur = next) {
        next = cur->next;
        free(cur);
    }
}

/* Suballocate space in the current function memblock for patch memory */
CUresult
mcRecCreateDevicePatch(MCrec *rec)
{
    CUresult status;
    CUtoolsMemBlockHandle memblock;
    CUmemblockList mblist, *m;
    uint32_t offsetExceeded = 0;

    CU_TRACE_FUNCTION();
    CU_ASSERT(rec);
    CU_ASSERT(rec->func->mem.dev.memobj);

    if (!rec->patchBuffer.size) {
        CU_DEBUG_PRINT(("Empty patch\n"));
        return CUDA_SUCCESS;
    }

    status = rec->tools->memory->MemObjGetMemBlock(rec->func->mem.dev.memobj, &memblock);
    if (status != CUDA_SUCCESS) {
        printInternalError(CU_MEMCHECK_ERROR_OUT_OF_DEVICE_MEMORY,
                           rec->gvars);

        CU_ERROR_PRINT(("\n"));
        return status;
    }

    rec->patchBuffer.devseg = HALO_MEM_SEG_FUNC;
    rec->patchBuffer.mcctx = rec->context;

    /* Try the nearest first */
    status = CCallocateDevice(&rec->patchBuffer, memblock);
    if (status == CUDA_SUCCESS) {
        if (rec->context->hal.isPcInRange(rec->patchBuffer.dev.dPtr, rec)) {
            rec->patchOffset = (uint32_t) rec->patchBuffer.dev.dPtr;
            return status;
        }
        else {
            CCfreeDevice(&rec->patchBuffer, NULL);
            offsetExceeded = 1;
        }
    }

    /* If we are here, the allocation within the memblock of the function has failed.
       Try to allocate a block inside a known memblock */
    createMemBlockList(rec->context->cuctx, &mblist);

    for (m = mblist.next; m; m = m->next) {
        status = CCallocateDevice(&rec->patchBuffer,(CUtoolsMemBlockHandle) m->memblock);
        if (status == CUDA_SUCCESS) {
            if (rec->context->hal.isPcInRange(rec->patchBuffer.dev.dPtr, rec)) {
                rec->patchOffset = (uint32_t) rec->patchBuffer.dev.dPtr;
                destroyMemBlockList(&mblist);
                return status;
            }
            else {
                CCfreeDevice(&rec->patchBuffer, NULL);
                offsetExceeded = 1;
            }
        }
    }

    destroyMemBlockList(&mblist);

    /* Final fallback, generate a new memblock for the patch.
       When NULL is passed in as the memblock parameter, the allocation
       mechanism will do a full cuiFuncAlloc. On Fermi and higher,
       this is acceptable. The patch code may wind up in its own
       memblock, so the offset may be large */
    status = CCallocateDevice(&rec->patchBuffer,NULL);
    if (status == CUDA_SUCCESS) {
        if (rec->context->hal.isPcInRange(rec->patchBuffer.dev.dPtr, rec)) {
            rec->patchOffset = (uint32_t) rec->patchBuffer.dev.dPtr;
            return status;
        }
        else {
            CCfreeDevice(&rec->patchBuffer, NULL);
            offsetExceeded = 1;
        }
    }

    /* If we are here, there is a failure in allocation */
    if (offsetExceeded) {
        printInternalError(CU_MEMCHECK_ERROR_LAUNCH_SIZE_TOO_LARGE,
                           rec->gvars);
        CU_ERROR_PRINT(("Launch exceeded max jump offset\n"));
    }
    else {
        printInternalError(CU_MEMCHECK_ERROR_OUT_OF_DEVICE_MEMORY,
                           rec->gvars);

        CU_ERROR_PRINT(("Patch allocation failed\n"));
    }
    return CUDA_ERROR_UNKNOWN;
}

/* Download the patch itself (can't use MemcpyInlineHtoD here as the
   patch can be more than 64 KiB */
CUresult
mcRecDownloadPatch(MCrec *rec, CUtoolsStreamHandle stream)
{
    CUresult status = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    if (!rec->patchBuffer.size) {
        CU_DEBUG_PRINT(("Empty patch. Skipping download\n"));
        return CUDA_SUCCESS;
    }

    status = CCmemShadowHtoDStream(&rec->patchBuffer, &rec->patchBuffer,
                                   stream,
                                   CC_MEM_SHADOW_ACTION_MEMCPY);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to download patch\n"));
        return status;
    }

    return status;
}

/* Download the patched instructions using a memcopy */
CUresult
mcRecDownloadFunc(MCrec *rec, CUtoolsStreamHandle stream)
{
    CUresult status = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    status = CCmemShadowHtoDStream(&rec->funcBuffer,
                                   &rec->func->mem,
                                   stream,
                                   CC_MEM_SHADOW_ACTION_MEMCPY);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("Failed to update function\n"));
        return status;
    }

    /* Make sure the above memcpy makes it to the device so the
     * debugger can re-insert function breakpoints as needed */
    if (rec->options.debuggerAttached) {
        status = mcContextStreamSynchronize(rec->context, stream);
        if (status != CUDA_SUCCESS) {
            CU_ERROR_PRINT(("Failed to synchronize download function\n"));
            return status;
        }
    }

    CCdbgInteropResetFunction(rec);

    return status;
}

/*
   Creates:  hostFuncBuffer
*/
/* The host funcBuffer has already been created on module load, so now
   we copy the instructions from the func pointer, to create the patched
   version
*/
CUresult
mcRecCreateHostFuncCopy(MCrec *rec)
{
    CUresult status = CUDA_SUCCESS;

    CU_TRACE_FUNCTION();

    rec->funcBuffer.size = rec->func->mem.size;
    rec->funcBuffer.mcctx = rec->context;

    status = CCallocateHost(&rec->funcBuffer);
    if (status != CUDA_SUCCESS) {
        CU_ERROR_PRINT(("\n"));
        status = CUDA_ERROR_OUT_OF_MEMORY;
        goto error;
    }
    memcpy(rec->funcBuffer.host.ptr, rec->func->mem.host.ptr, (size_t)rec->func->mem.size);

    return CUDA_SUCCESS;

error:
    CCfreeHost(&rec->funcBuffer);

    if (status == CUDA_ERROR_OUT_OF_MEMORY)
        printInternalError(CU_MEMCHECK_ERROR_OUT_OF_HOST_MEMORY,
                           rec->gvars);
    return status;
}

