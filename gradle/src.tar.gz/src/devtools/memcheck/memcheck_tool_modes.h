/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: memcheck_tool_modes.h
 *
 *   Description:
 *       Modes for the backend
 *
 ******************************************************************************/

#ifndef _MEMCHECK_TOOL_MODES_H
#define _MEMCHECK_TOOL_MODES_H

#include "check_core.h"
#include "check_ir.h"
#include "check_alloc.h"
#include "memcheck_types.h"
#include "memcheck_inst_types.h"
#include "cuda_etbl/tools_common_types.h"

/* Helper Macros */
#define TO_INST_MASK(field)      (1U << CCIR_INST_OPCODE_##field)
#define TO_CHECKTYPE_MASK(field) (1U << MC_CHECK_TYPE_##field)

typedef struct MCtoolModeState_st MCtoolModeState;
typedef struct MCtoolModeArchState_st MCtoolModeArchState;

typedef enum {
    MC_TOOL_MODE_NONE = 0,
    MC_TOOL_MODE_MEMCHECK ,
    MC_TOOL_MODE_RACECHECK,
    MC_TOOL_MODE_BARCHECK,
    MC_TOOL_MODE_INITCHECK,

    /* Add tool modes before this line */
    MC_TOOL_MODE_SIZE,
} MCtoolModeType;

typedef enum {
    MC_TOOL_MODE_ARCH_NONE = 0,
    MC_TOOL_MODE_ARCH_SM30,
    MC_TOOL_MODE_ARCH_SM35,
    MC_TOOL_MODE_ARCH_SM50,
    MC_TOOL_MODE_ARCH_SM52,
    MC_TOOL_MODE_ARCH_SM60,
  /*MC_TOOL_MODE_ARCH_SM62,*/
    MC_TOOL_MODE_ARCH_SM70,
    MC_TOOL_MODE_ARCH_SM75,
    MC_TOOL_MODE_ARCH_SM80,

    MC_TOOL_MODE_ARCH_SIZE,
    MC_TOOL_MODE_ARCH_FORCE_SIZE = 0xFFFFFFFFU,
} MCtoolModeArchs;

/* MCmodeArchState_st
    State for per arch setup
*/
struct MCtoolModeArchState_st {
    // Bitmask of supported check types for this arch
    uint32_t    checkMask;

    // Each element is a bitmask of supported op types
    // for this arch, for this op
    uint32_t    opMask[MC_CHECK_TYPE_SIZE];
};

/* MCmodeState_st
    State for MCtoolMode
*/
struct MCtoolModeState_st {
    MCtoolModeType  type;
    MCtoolModeArchState arch[MC_TOOL_MODE_ARCH_SIZE];
};

/* MCtoolModeCtxData_st
*/
struct MCtoolModeCtxData_st {
    void *ptr[MC_TOOL_MODE_SIZE];
};

/* MCtoolModeRecData_st
*/
struct MCtoolModeRecData_st {
    void *ptr[MC_TOOL_MODE_SIZE];
};

/* MCtoolMode_st
    Backend mode
*/
struct MCtoolMode_st {
    MCtoolModeState state;

    CUresult (*createPatchHelpers)  (MCcontext *mcctx, MCrec *rec, CUtoolsStreamHandle stream);
    CUresult (*destroyPatchHelpers) (MCcontext *mcctx, MCrec *rec, CCmemCleanup *cleanup);

    // Options
    bool (*hasPrologue) (MCcontext *mcctx);
    bool (*usesTrapHandler) (MCoptions *options);
    bool (*enableApiCheck) (MCoptions *options);
    bool (*enableMemAccessCheck) (MCoptions *options);

    // Some simple query functions
    CUresult (*getCheckTypeMask) (MCtoolMode *toolMode, uint32_t sm_version,
                                  uint32_t *mask);
    CUresult (*getOpTypeMask) (MCtoolMode *toolMode, uint32_t sm_version,
                               MCcheckTypes type, uint32_t *mask);

    CUresult (*isArchSupported) (MCtoolMode *toolMode, MCtoolModeArchs arch,
                                 uint32_t *supported);
    CUresult (*isOsSupported) (MCtoolMode *toolMode, uint32_t *supported);

    CUresult (*isModuleSupported) (MCcontext *mcctx, MCmod *mod, CUmemcheck_error_types *modSupportedError);

    CUresult (*checkMemAccessDevAddr) (MCcontext *mcctx, uint64_t addr, uint64_t size, CUtoolsStreamHandle stream, CCmemAccessType accessType);
    // Callbacks
    CUresult (*moduleLoadedCallback) (MCcontext *mcctx, MCmod *mod);
    CUresult (*moduleUnloadedCallback) (MCcontext *mcctx, MCmod *mod);
    CUresult (*contextDestroyStartCallback) (MCcontext *mcctx);
    CUresult (*contextDestroyEndCallback) (MCcontext *mcctx);
    CUresult (*heapSelectedCallback) (MCcontext *mcctx, CCalloc *heap);
    CUresult (*ctxSyncCallback) (MCcontext *mcctx);
    CUresult (*handlePatchCompletion) (MCcontext *mcctx, MCrec *rec, MClaunch *launch);
    CUresult (*updateLaunchConfig) (MCcontext *mcctx, MCfunc *func, CUtoolsFunctionLaunchConfig *config);
    CUresult (*contextCreatedCallback) (MCcontext *mcctx);
    CUresult (*trapHandlerCallback) (MCcontext *mcctx, CUmemobj* scratchpadMemobj, uint32_t smError);
    CUresult (*trapHandlerEndCallback) (MCcontext *mcctx, CUmemobj* scratchpadMemobj, uint32_t smError);
    CUresult (*initEndCallback) (MCglobals *gvars);
    CUresult (*addAllocCallback) (MCcontext *mcctx, CCalloc *alloc);
    CUresult (*removeAllocCallback) (MCcontext *mcctx, CCalloc *alloc);

    CUresult (*getInternalModules) (MCrec *rec, tList **mods);

    CUresult (*getExceptionType) (uint32_t magic, CUDBGException_t *exception);
};

CUresult toolModeInitialize(MCtoolModeType type, MCoptions *options, MCtoolMode *toolMode);
CUresult toolModeFinalize(MCtoolMode *toolMode);

MCtoolModeArchs getArchFromSmVer(uint32_t sm_version);

#endif

