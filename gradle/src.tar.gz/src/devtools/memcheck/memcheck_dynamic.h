/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
*
*   Module: memcheck_dynamic.h
*
*   Description:
*       Structures and definitions for interface to dynamic checking schemes
*
******************************************************************************/
#ifndef MEMCHECK_DYNAMIC_H
#define MEMCHECK_DYNAMIC_H

#include "memcheck_types.h"
#include "cudamemcheck.h"
#include "cuda_structs.h"
#include "cuda.h"

/* Memcheck side of the dynamic checker.
    The main information it needs are the device addresses
    for the malloc, free and check functions*/

typedef struct MCDynamic_st             MCDynamic;
typedef struct MCDynamicSchemeConfig_st MCDynamicSchemeConfig;
typedef struct MCDynamicFuncConfig_st   MCDynamicFuncConfig;
typedef struct MCDynamicFunc_st         MCDynamicFunc;
typedef struct MCDynamicScheme_st       MCDynamicScheme;
typedef struct MCDynamicState_st        MCDynamicState;
typedef struct MCTrampolineState_st     MCTrampolineState;

/* Structure to hold the per function configuration
*/
struct MCDynamicFuncConfig_st {
    uint32_t regcount;
    uint32_t crssize;
    uint32_t systemStackSize;
};

/* Enumeration of the device side functions expected
*/
enum MCDynamicFuncTypes {
    MC_DYNAMIC_FUNC_CHECK,
    MC_DYNAMIC_FUNC_MALLOC,
    MC_DYNAMIC_FUNC_FREE,
    MC_DYNAMIC_FUNC_MAX,    //Maximum number of functions
};

/* Structure to hold information about a device side function
*/
struct MCDynamicFunc_st {
    CUfunc      *cufunc;
    uint64_t    funcDptr;
    MCDynamicFuncConfig config;
    uint32_t    type;           //as MCDynamicFuncType
};

/* Structure to hold the entire scheme wide configuration. This structure
    can be directly queried by the core when setting launch bounds
*/
struct MCDynamicSchemeConfig_st {
    MCDynamicFuncConfig *malloc;
    MCDynamicFuncConfig *free;
    MCDynamicFuncConfig *check;
};

/* Structure to hold information about a given scheme.
    Each scheme consists of two parts :
        host side functions   (in ${SCHEME}.c/h file)
    and device side functions (in ${SCHEME}.cu/cuh file)

    Schemes have 4 main host side functions that are called.
    initialize() : called by MCDynamicInitialize().
    finalize()   : called by MCDynamicFinalize().
    beforeRun()  : called before a launch by beforeFunctionSetup()
    afterRun()   : called after a launch by afterGridLaunched()

    Also, schemes have 3 device side functions
    ${PREFIX}_malloc : malloc() replacement
    ${PREFIX}_free   : free() replacement
    ${PREFIX}_check  : checker function

    These device functions will be called on the device when
    the user program is executing.

    Schemes are initialized in 3 phases by MCDynamicInitialize/LoadDeviceFunctions
    1. Registration : The register function in memcheck_dynamic_syscalls.h
       is called to populate the scheme struct fields
    2. Host Side initialization : This is handled by calling the
       scheme->initialize() function after registration
    3. Device Side registration : After the memcheck cubin has been loaded
       the 3 function types for each scheme are loaded in.
*/
struct MCDynamicScheme_st {
    CUmod*          cumod;          //Module containing all memcheck cubins
    uint32_t        type;           //Type of scheme. See : MCDynamicSchemeTypes
    const char*     prefix;         //Prefix of the scheme
    const char*     name;           //Name of the scheme
    uint32_t        initialized;    //Set after all device functions are loaded
    void*           customData;     // Custom data for each scheme

    /* Each dynamic checker must contain
       3 device side functions : malloc, free, and check
    */
    MCDynamicFunc   *funcs[MC_DYNAMIC_FUNC_MAX];

    /* Host side functions for the scheme */
    /* Scheme control */
    CUresult    (*initialize)           (MCDynamicScheme* scheme);
    CUresult    (*finalize)             (MCDynamicScheme* scheme);
    CUresult    (*activate)             (MCDynamicScheme* scheme, MCcontext *mcctx, CUtoolsStreamHandle stream);
    CUresult    (*deactivate)           (MCDynamicScheme* scheme, MCcontext *mcctx, CUtoolsStreamHandle stream);

    /* State examination */
    CUresult    (*parseSyscallError)    (MCDynamicScheme* scheme, MCcontext *mcctx,
                                         CUmemcheck_record *err, uint32_t *hasError);
    CUresult    (*addLeaks)             (MCDynamicScheme* scheme, MCcontext *mcctx, CUtoolsStreamHandle stream);
    CUresult    (*checkAccess)          (MCDynamicScheme* scheme, MCcontext *mcctx, CUtoolsStreamHandle stream,
                                         uint64_t addr, uint64_t size,
                                         CCmemAccessError *err);
};

/* Enum to describe the state of Dynamic memcheck
*/
enum MCdynStateEnum {
    MC_DYN_NONE,            //Default
    MC_DYN_DISABLED,        //Set if the context doesnt use malloc/free
    MC_DYN_FAILED,          //Set if the initialization failed
    MC_DYN_INITIALIZING,    //Set while loading the memcheck module
    MC_DYN_INITIALIZED,     //Set if the module loaded
    MC_DYN_ACTIVE,          //Set when dynamic is being actively used
};

/* Struct to track the state of syscall trampolines
*/
struct MCTrampolineState_st {
    CUfunc *origFunc;       //Original function (i.e. the real malloc)
    CUfunc *newFunc;        //Malloc replacement (from scheme)
    CUfunc *trampFunc;      //Trampoline function (the SASS version)
    uint64_t origDptr;      //Original Dptr
    const char* name;       //Name of trampoline function
    uint32_t isPatched;     //To track the state of the trampoline
};

/* Struct to track the state of dynamic memcheck
*/
struct MCDynamicState_st {
    uint32_t            state;          //of type MCdynStateEnum
    MCDynamicScheme     *activeScheme;  //Active scheme
    MCTrampolineState   *trampolines;   //Pointer to trampolines
};

/* Struct for the entire dynamic memcheck
    This struct exists as the memcheck module load
    happens without a known context. This also
    tracks all the dynamic state needed
*/
struct MCDynamic_st {
    MCcontext       *context;
    MCDynamicScheme **schemes;
    uint32_t        numschemes;
    MCmod*          mod;
    MCDynamicState  dynState;
};

/*  Initialize the memcheck side for Dynamic Checker
    This function will allocate scMod will be set to point to the module
    This function will also initialize structures for all known schemes
    We need the CUctx to be able to load the memcheck module
*/
CUresult MCDynamicInitialize(MCcontext *mcctx);

//Returns a scheme by type
MCDynamicScheme* getDynamicSchemeByType(MCcontext *mcctx, uint32_t schemetype);

//Finalize and free all allocations
CUresult MCDynamicFinalize(MCcontext *mcctx);

//Activate a scheme
CUresult MCDynamicActivateScheme(MCcontext *mcctx, CUtoolsStreamHandle stream, uint32_t schemetype);

//Deactivate active scheme
CUresult MCDynamicDeactivateScheme(MCcontext *mcctx, CUtoolsStreamHandle stream);

//Use the syscall const bank to push data to the device side
CUresult MCWriteSyscallConstBank(MCcontext *mcctx, CUmod *mod, const char *name, const void *data, size_t size);

//Find the jump address for the check function
CUresult MCDynamicGetCheckFuncAddress(MCcontext *mcctx, uint64_t *jumpaddr);

// Parse a syscall error
CUresult MCDynamicParseErrorEntry(MCcontext *mcctx, CUmemcheck_record *err, uint32_t *hasError);

// Get leak information
CUresult MCDynamicAddLeaks(MCcontext *mcctx);

// Query Register usage / CRSSize
CUresult MCDynamicGetSchemeConfig(MCcontext *mcctx, uint32_t schemetype, MCDynamicSchemeConfig *schemeConfig);

// Check the device access
CUresult MCDynamicCheckAccess(MCcontext *mcctx, CUtoolsStreamHandle stream, uint64_t addr, uint64_t size,  CCmemAccessError *err);

#endif
