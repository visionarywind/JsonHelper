#ifndef _CHECK_DBG_INTEROP_H
#define _CHECK_DBG_INTEROP_H

#include <memcheck_types.h>
#include <check_core.h>
#include <cudamemcheck.h>

void CCdbgInteropAddTrampolinePatch(MCrec *rec,
                                    uint64_t devvaddr,
                                    uint64_t pc,
                                    uint64_t size,
                                    uint64_t entryPc,
                                    uint64_t origInst);

CUresult CCdbgInteropAddTrampolinePatchCommon(MCrec *rec,
                                    uint64_t devvaddr,
                                    uint64_t pc,
                                    uint64_t size,
                                    uint64_t entryPc,
                                    uint64_t *origInst,
                                    uint32_t numInst);

void CCdbgInteropAddStandalonePatch(MCrec *rec,
                                    uint64_t devvaddr,
                                    uint64_t pc,
                                    uint64_t size);

void CCdbgInteropRemovePatches(MCrec *rec);

void CCdbgInteropResetFunction(MCrec *rec);

#endif
