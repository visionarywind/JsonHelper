/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef CHECK_IR_H
#define CHECK_IR_H

#include "cuda.h"
#include "cudamemcheck.h"
#include "check_core.h"
#include "tools_shared_list.h"

/* Scan function pointer */
typedef bool (*pScanInst) (const uint64_t *inst);

/* Basic Check IR */
typedef struct CCIRop_st               CCIRop;
typedef struct CCIRinstModifierLDST_st CCIRinstModifierLDST;
typedef struct CCIRinstModifierATOM_st CCIRinstModifierATOM;
typedef struct CCIRinstModifierBAR_st  CCIRinstModifierBAR;
typedef struct CCIRinstModifier_st     CCIRinstModifier;
typedef struct CCIRinst_st             CCIRinst;
typedef struct CCIRblock_st            CCIRblock;
typedef struct CCIRprogram_st          CCIRprogram;

/* Enums */

/* CCIRinstOpcodes
    Opcode enum. Meant to only require a subset of all instructions in the
    ISA.
*/
typedef enum {
    // CCIR_INST_OPCODE_NONE must always be 0 and the first element
    CCIR_INST_OPCODE_NONE  = 0,
    CCIR_INST_OPCODE_GENERIC_LD,
    CCIR_INST_OPCODE_GENERIC_ST,
    CCIR_INST_OPCODE_GLOBAL_LD,
    CCIR_INST_OPCODE_GLOBAL_LDU,
    CCIR_INST_OPCODE_GLOBAL_ST,
    CCIR_INST_OPCODE_SHARED_LD,
    CCIR_INST_OPCODE_SHARED_ST,
    CCIR_INST_OPCODE_LOCAL_LD,
    CCIR_INST_OPCODE_LOCAL_ST,
    CCIR_INST_OPCODE_SYNC_BARRIER,
    CCIR_INST_OPCODE_ATOM,
    CCIR_INST_OPCODE_ATOM_SHARED,
    CCIR_INST_OPCODE_ATOM_GLOBAL,
    CCIR_INST_OPCODE_RED,
    CCIR_INST_OPCODE_EXIT,
    CCIR_INST_OPCODE_LDG,
    CCIR_INST_OPCODE_RET,
    CCIR_INST_OPCODE_NOP,
    CCIR_INST_OPCODE_WARPSYNC,
    CCIR_INST_OPCODE_ABS_CALL,
    CCIR_INST_OPCODE_REL_CALL,
    CCIR_INST_OPCODE_SHFL,

    // Add new instructions before this line
    CCIR_INST_OPCODE_SIZE,
    CCIR_INST_OPCODE_FORCE_SIZE  = 0xFFFFFFFFU,
} CCIRinstOpcodes;

/* CCIRopTypes
    Operand types. Type of storage an operand is
*/
typedef enum {
    CCIR_OP_TYPE_NONE = 0,
    CCIR_OP_TYPE_REG,        /* Register */
    CCIR_OP_TYPE_IMM,        /* Immediate (absolute immediate) */
    CCIR_OP_TYPE_ADDEND,     /* Addend (immediate which needs to be added) */
    CCIR_OP_TYPE_IMM_REL,    /* Relative Immediate (only on control flow instructions) */
    CCIR_OP_TYPE_CONSTBANK,  /* Bank number in const bank */
    CCIR_OP_TYPE_CONSTBANKOFFSET, /* Offset in const bank */
    CCIR_OP_TYPE_PREDICATE,  /* Predicate */
} CCIRopTypes;

/* CCIRopLabels
    Label of the operand. Usually these correspond to the
    name in the insturciotn mnemonic.
*/
typedef enum {
    CCIR_OP_LABEL_NONE = 0,
    CCIR_OP_LABEL_RA,
    CCIR_OP_LABEL_RB,
    CCIR_OP_LABEL_RD,
    CCIR_OP_LABEL_IMM32,
    CCIR_OP_LABEL_IMM24,
    CCIR_OP_LABEL_IMM16,
    CCIR_OP_LABEL_PU,
    CCIR_OP_LABEL_PV,
    CCIR_OP_LABEL_BARNAME,
} CCIRopLabels;


/* CCIRop_st
    Operand representation for the IR. This contains the entire description of 1
    concrete instruction operand.
*/
struct CCIRop_st {
    CCIRopTypes type;
    CCIRopLabels label;
    uint32_t value;
};

/* Special per-instruction types  */

/* CCIRinstModLDSTCop
    Cache op enum for Load/Store. Note, not all specifiers are supported over
    all archs
*/
typedef enum {
    CCIR_LDST_COP_DEFAULT,
    CCIR_LDST_COP_CA,
    CCIR_LDST_COP_CG,
    CCIR_LDST_COP_LU,
    CCIR_LDST_COP_CV,
    CCIR_LDST_COP_VS,
} CCIRinstModLDSTCop;

/* CCIRinstModifierLDST_st
    Holds the modifiers of a Load/Store op
*/
struct CCIRinstModifierLDST_st {
    CCIRinstModLDSTCop cop;
    uint32_t size;
    uint32_t isE;
    uint32_t windowShared;
    uint32_t windowLocal;
    uint32_t windowGlobal;
};

/* CCIRinstModATOMOps
    Enum for all atomic operations
*/
typedef enum {
    CCIR_ATOM_ADD,
    CCIR_ATOM_MIN,
    CCIR_ATOM_MAX,
    CCIR_ATOM_INC,
    CCIR_ATOM_DEC,
    CCIR_ATOM_AND,
    CCIR_ATOM_OR,
    CCIR_ATOM_XOR,
    CCIR_ATOM_EXCH,
    CCIR_ATOM_SAFEADD,
    CCIR_ATOM_CAS
} CCIRinstModATOMOps;

/* CCIRinstModifierATOM_st
    Modifiers for an ATOM instruction
*/
struct CCIRinstModifierATOM_st {
    uint32_t isE;
    uint32_t size;
    uint32_t isSigned;
    CCIRinstModATOMOps op;
};

/* CCIRinstModBARTypes
    Types of BAR instruction
*/
typedef enum {
    CCIR_BAR_TYPE_SYNC,
    CCIR_BAR_TYPE_ARV,
    CCIR_BAR_TYPE_RED,
    CCIR_BAR_TYPE_SCAN,
    CCIR_BAR_TYPE_SYNCALL,
} CCIRinstModBARTypes;

/* CCIRinstModBAROps
    Operations a BAR can do. Usually this is restricted
    to BAR.RED (arch dependent)
*/
typedef enum {
    CCIR_BAR_OP_POPC,
    CCIR_BAR_OP_AND,
    CCIR_BAR_OP_OR,
} CCIRinstModBAROps;

/* CCIRinstModifierBAR_st
    Modifiers for a BAR instruction
*/
struct CCIRinstModifierBAR_st {
    uint32_t barname;
    uint32_t barcount;
    CCIRinstModBAROps op;
    CCIRinstModBARTypes type;
};

/* CCIRinstModifierTypes
    Enum containing type of modifiers
*/
typedef enum {
    CCIR_INST_MODIFIER_TYPE_NONE = 0,
    CCIR_INST_MODIFIER_TYPE_LDST,
    CCIR_INST_MODIFIER_TYPE_ATOM,
    CCIR_INST_MODIFIER_TYPE_BAR,
} CCIRinstModifierTypes;

/* CCIRinstModifier_st
    Generic instruction modifier struct.
    This contains a union of all types of modifiers.
*/
struct CCIRinstModifier_st {
    CCIRinstModifierTypes type;
    union {
        CCIRinstModifierLDST ldst;
        CCIRinstModifierATOM atom;
        CCIRinstModifierBAR  bar;
    } cases;
};

/* CCIRinst_st
    The core of the IR. This is an abstract representation
    of an y instruction.
*/
struct CCIRinst_st {
    CCIRinstOpcodes opcode; /* Instruction opcode */
    tList *mods;            /* List of CCIRinstModifiers */
    tList *inputs;          /* List of CCIRop for input operands */
    tList *outputs;         /* List of CCIRop for output operands */
    uint32_t hasPredicate;  /* Instruction has predicate */
    CCIRop predicate;       /* Operand for predicate */
};

/* CCIRblock_st
    List of instructions. This is used to allow ranges of instructions that
    bypass scanning.
*/
struct CCIRblock_st {
    uint32_t translated;    /* Are all the instructions translated or raw */
    tList *insts;           /* List of CCIRinst instructions making up the block */
};

/* CCIRprogram_st
    Top level object. Contains a list of blocks.
*/
struct CCIRprogram_st {
    uint32_t sm_major;      /* SM version major */
    uint32_t sm_minor;      /* SM version minor */
    tList *blocks;          /* List of CCIRblock blocks making up the program */
};

// Function to get the address space of an opcode
CUmemcheck_addrType_types getAddressSpace(CCIRinstOpcodes opcode);

// Function to scan if the instruction is the targeted one
pScanInst getInstScanFunction(MCcontext *mcctx, CCIRinstOpcodes opcode);

// Check if a type is only accessing the global window
uint32_t isGlobalOnly(CCIRinstOpcodes opcode);

#endif

