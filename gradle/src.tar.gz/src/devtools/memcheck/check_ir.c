/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "cuda.h"
#include "cudamemcheck.h"
#include "check_ir.h"
#include "memcheck_types.h"

CUmemcheck_addrType_types
getAddressSpace(CCIRinstOpcodes opcode)
{
    if (opcode == CCIR_INST_OPCODE_GENERIC_LD   ||
        opcode == CCIR_INST_OPCODE_GENERIC_ST   ||
        opcode == CCIR_INST_OPCODE_GLOBAL_LD    ||
        opcode == CCIR_INST_OPCODE_GLOBAL_ST    ||
        opcode == CCIR_INST_OPCODE_ATOM         ||
        opcode == CCIR_INST_OPCODE_ATOM_GLOBAL  ||
        opcode == CCIR_INST_OPCODE_RED)
        return CU_MEMCHECK_ADDR_TYPE_GLOBAL;
    else if (opcode == CCIR_INST_OPCODE_SHARED_LD ||
             opcode == CCIR_INST_OPCODE_SHARED_ST ||
             opcode == CCIR_INST_OPCODE_ATOM_SHARED)
        return CU_MEMCHECK_ADDR_TYPE_SHARED;
    else if (opcode == CCIR_INST_OPCODE_LOCAL_LD ||
             opcode == CCIR_INST_OPCODE_LOCAL_ST)
        return CU_MEMCHECK_ADDR_TYPE_LOCAL;

    return CU_MEMCHECK_ADDR_TYPE_NONE;
}

pScanInst
getInstScanFunction(MCcontext *mcctx, CCIRinstOpcodes opcode)
{
    if (!mcctx) {
        CU_ERROR_PRINT(("Invalid arguments\n"));
        return NULL;
    }

    if (opcode <= CCIR_INST_OPCODE_NONE || opcode >= CCIR_INST_OPCODE_SIZE) {
        CU_ERROR_PRINT(("Invalid inst op type: %u\n",opcode));
        return NULL;
    }

    switch (opcode) {
    case CCIR_INST_OPCODE_GENERIC_LD:
        return mcctx->hal.isGtasLd;
    case CCIR_INST_OPCODE_GENERIC_ST:
        return mcctx->hal.isGtasSt;
    case CCIR_INST_OPCODE_GLOBAL_LD:
        return mcctx->hal.isLdg;
    case CCIR_INST_OPCODE_GLOBAL_ST:
        return mcctx->hal.isStg;
    case CCIR_INST_OPCODE_SHARED_LD:
        return mcctx->hal.isLds;
    case CCIR_INST_OPCODE_SHARED_ST:
        return mcctx->hal.isSts;
    case CCIR_INST_OPCODE_LOCAL_LD:
        return mcctx->hal.isLdl;
    case CCIR_INST_OPCODE_LOCAL_ST:
        return mcctx->hal.isStl;
    case CCIR_INST_OPCODE_SYNC_BARRIER:
        return mcctx->hal.isSynchronizingBarrier;
    case CCIR_INST_OPCODE_EXIT:
        return mcctx->hal.isExit;
    case CCIR_INST_OPCODE_RET:
        return mcctx->hal.isRet;
    case CCIR_INST_OPCODE_ATOM:
        return mcctx->hal.isAtom;
    case CCIR_INST_OPCODE_ATOM_SHARED:
        return mcctx->hal.isAtomS;
    case CCIR_INST_OPCODE_ATOM_GLOBAL:
        return mcctx->hal.isAtomG;
    case CCIR_INST_OPCODE_RED:
        return mcctx->hal.isRed;
    case CCIR_INST_OPCODE_NOP:
        return mcctx->hal.isNop;
    case CCIR_INST_OPCODE_WARPSYNC:
        return mcctx->hal.isWarpSync;
    case CCIR_INST_OPCODE_ABS_CALL:
        return mcctx->hal.isAbsoluteCall;
    case CCIR_INST_OPCODE_REL_CALL:
        return mcctx->hal.isRelativeCall;
    case CCIR_INST_OPCODE_SHFL:
        return mcctx->hal.isShfl;
    default:
        CU_TRACE_PRINT(("Unsupported inst op : %u\n", opcode));
        return NULL;
    };

    return NULL;
}

uint32_t
isGlobalOnly(CCIRinstOpcodes opcode)
{
    if (opcode == CCIR_INST_OPCODE_GLOBAL_LD ||
        opcode == CCIR_INST_OPCODE_GLOBAL_ST ||
        opcode == CCIR_INST_OPCODE_ATOM      ||
        opcode == CCIR_INST_OPCODE_ATOM_GLOBAL ||
        opcode == CCIR_INST_OPCODE_RED)
        return 1;

    return 0;
}

