/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <cuda.h>
#include "halo_internal.h"

void
haloFindPrefix(const char* fileName, char prefix[6])
{
    *prefix = 0;

    if (!fileName)
        return;

#ifndef RELEASE
    if (strstr(fileName, "halo.c")                  ||
        strstr(fileName, "halo_linux.c")            ||
        strstr(fileName, "halo_darwin.c")           ||
        strstr(fileName, "halo_state.c")            ||
        strstr(fileName, "halo_internal.c"))
        sprintf(prefix, "HALO");
    else if (strstr(fileName, "halo_memmap.c"))
        sprintf(prefix, "HMMAP");
    else if (strstr(fileName, "halo_client.c"))
        sprintf(prefix, "HALCL");
    else if (strstr(fileName, "halo_client_memcheck.c"))
        sprintf(prefix, "HALMC");
    else if (strstr(fileName, "halo_client_debugger.c"))
        sprintf(prefix, "HALDB");
    else if (strstr(fileName, "halo_dmal_mrm.c"))
        sprintf(prefix, "HDMRM");
    else if (strstr(fileName, "halo_dmal_rm.c"))
        sprintf(prefix, "HDRM");
    else if (strstr(fileName, "halo_dmal_wddm.c"))
        sprintf(prefix, "HDWLH");
    else if (strstr(fileName, "halo_dmal_wddm_legacy.c"))
        sprintf(prefix, "HDWLG");
    else if (strstr(fileName, "halo_dmal.c"))
        sprintf(prefix, "HDMAL");
    else if (strstr(fileName, "kdapi_mrm.c"))
        sprintf(prefix, "KDMRM");
    else if (strstr(fileName, "kdapi_rm.c"))
        sprintf(prefix, "KDRM");
    else if (strstr(fileName, "kdapi_wddm.c"))
        sprintf(prefix, "KDWLH");
    else if (strstr(fileName, "fermi.c")  ||
             strstr(fileName, "fermi_texture.c"))
        sprintf(prefix, "GF1XX");
#if NVCFG(GLOBAL_ARCH_KEPLER)
    else if (strstr(fileName, "kepler.c"))
        sprintf(prefix, "GK1XX");
    else if (strstr(fileName, "kepler_gk10x.c"))
        sprintf(prefix, "GK10X");
    else if (strstr(fileName, "kepler_gk11x.c"))
        sprintf(prefix, "GK11X");
    else if (strstr(fileName, "kepler_gk11x_kilp.c"))
        sprintf(prefix, "KILP");
#endif
#if NVCFG(GLOBAL_ARCH_MAXWELL)
    else if (strstr(fileName, "maxwell.c"))
        sprintf(prefix, "GMXXX");
    else if (strstr(fileName, "maxwell_gm10x.c") ||
             strstr(fileName, "maxwell_gm10x_kilp.c"))
        sprintf(prefix, "GM10X");
#endif
#if NVCFG(GLOBAL_ARCH_PASCAL)
    else if (strstr(fileName, "pascal_gp10x.c") ||
             strstr(fileName, "pascal_gp10x_cilp.c"))
        sprintf(prefix, "GP10x");
#endif
#if NVCFG(GLOBAL_ARCH_VOLTA)
    else if (strstr(fileName, "volta_gv10x.c") ||
             strstr(fileName, "volta_gv10x_cilp.c"))
        sprintf(prefix, "GV10x");
#endif
#if NVCFG(GLOBAL_ARCH_TURING)
    else if (strstr(fileName, "turing_tu10x.c") ||
             strstr(fileName, "turing_tu10x_cilp.c"))
        sprintf(prefix, "TU10x");
#endif
    else
        sprintf(prefix, "?????");
#endif

    return;
}

static CUDBGResult
haloTraceInstruction(CudbgDevice dev, uint64_t pc, bool warpValid, const char *file, const uint32_t line, const char *function, int32_t level)
{
#ifndef RELEASE
    /* Instruction size from Fermi to Volta ranges from 4 to 16 bytes. Since
       this is a debug function don't worry about perf. Read 16 bytes and deal
       with it */
    uint64_t inst[2] = {0};
    uint32_t instSize = 0;
    CUDBGResult res;
    /* Make sure, though the pc may be in the middle of a 32 bit instruction,
       to read from the top of the instruction pair (align to 64bits) in order
       for getInstructionSize to work properly. */
    const uint64_t PC_ALIGN_MASK = 0x7;

    if (!warpValid) {
        /* Just print 0 for invalid warps -- we don't want to
           potentially read from invalid code memory. */
        haloTrace(HALO_TRACE_DOMAIN_HALO, HALO_TRACE_TYPE_SKIP_LEVEL, level,
                  file, line, function, "%016" PRIx64 " ", inst[0]);
        return CUDBG_SUCCESS;
    }

    res = dev->halo.readCodeMemory(dev->activeContext, pc & ~PC_ALIGN_MASK, inst, sizeof inst);
    if (res != CUDBG_SUCCESS)
        return res;

    res = dev->halo.getInstructionSize(inst[0], &instSize);
    if (res != CUDBG_SUCCESS)
        return res;

    if (instSize == 4)
        haloTrace(HALO_TRACE_DOMAIN_HALO, HALO_TRACE_TYPE_SKIP_LEVEL, level,
                  file, line, function, "%08x ",
                  (uint32_t)(pc&PC_ALIGN_MASK ? inst[0] : inst[0] >> 32));
    else if (instSize == 8)
        haloTrace(HALO_TRACE_DOMAIN_HALO, HALO_TRACE_TYPE_SKIP_LEVEL, level,
                  file, line, function, "%016" PRIx64 " ", inst[0]);
    else if (instSize == 16)
        haloTrace(HALO_TRACE_DOMAIN_HALO, HALO_TRACE_TYPE_SKIP_LEVEL, level,
                  file, line, function, "%016" PRIx64 " %016" PRIx64 " ",
                  inst[0], inst[1]);

#endif
    return CUDBG_SUCCESS;
}

CUDBGResult
haloTraceWarpPCs(int32_t level, const char *file, const uint32_t line, const char* function, CudbgDevice dev, uint32_t vsm)
{
#ifndef RELEASE
    CudbgWarp_t *warp;
    uint32_t wp;
    CUDBGResult res = CUDBG_SUCCESS;

    haloTrace(HALO_TRACE_DOMAIN_HALO, HALO_TRACE_TYPE_FUNCTION, level, file, line, function,  "PCs (vsm%u):", vsm);
    for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
        warp = &dev->smState[vsm].warp[wp];
        if (wp % 8 == 0)
            haloTrace(HALO_TRACE_DOMAIN_HALO, HALO_TRACE_TYPE_NEWLINE | HALO_TRACE_TYPE_FUNCTION, level, file, line, function,  "    ", vsm);
        haloTrace(HALO_TRACE_DOMAIN_HALO, HALO_TRACE_TYPE_SKIP_LEVEL, level, file, line, function, "%04" PRIx64 "%c ", warp->pc, warp->valid["! "]);
    }
    haloTrace(HALO_TRACE_DOMAIN_HALO, HALO_TRACE_TYPE_NEWLINE|HALO_TRACE_TYPE_FUNCTION, level, file, line, function,  "\n");

    haloTrace(HALO_TRACE_DOMAIN_HALO, HALO_TRACE_TYPE_FUNCTION, level, file, line, function,  "  Instructions (vsm%u): ", vsm);
    for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
        warp = &dev->smState[vsm].warp[wp];
        if (wp % 8 == 0)
            haloTrace(HALO_TRACE_DOMAIN_HALO, HALO_TRACE_TYPE_NEWLINE | HALO_TRACE_TYPE_FUNCTION, level, file, 0, function,  "    ", vsm);
        res = haloTraceInstruction(dev, warp->pc, warp->valid, file, line, function, level);
        if (res != CUDBG_SUCCESS)
            return res;
    }
    haloTrace(HALO_TRACE_DOMAIN_HALO, HALO_TRACE_TYPE_NEWLINE|HALO_TRACE_TYPE_FUNCTION, level, file, line, function,  "\n");
#endif
    return CUDBG_SUCCESS;
}
