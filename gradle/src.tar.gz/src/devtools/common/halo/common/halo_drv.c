/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "cuda_types.h"
#include "cudadebugger.h"
#include "cudbgutils.h"
#include "cudbgdriver.h"
#include "halo_drv.h"
#include "fermi_drv.h"
#include "kepler_drv.h"
#include "maxwell_drv.h"
#include "pascal_drv.h"
#include "volta_drv.h"
#include "cuda_internal.h"

// Macro for calling a stateless HALO HAL function.
#define HALO_DRV_CALL(version, funcName, ...)                               \
{                                                                           \
    CUDBGResult _res;                                                       \
    struct HaloDrvFuncPtrs funcPtrs;                                        \
                                                                            \
    if (gpudbgDebuggerProcess()) {                                          \
        CUDBG_ERROR("Stateless HALO function should not be called from "    \
                    " the debugger's process\n");                           \
        return CUDBG_ERROR_INTERNAL;                                        \
    }                                                                       \
                                                                            \
    _res = haloGetDrvFuncPtrs(version, &funcPtrs);                          \
    if (_res != CUDBG_SUCCESS) {                                            \
        CUDBG_ERROR(" Invalid HW version: %d\n", version);                  \
        return CUDBG_ERROR_INTERNAL;                                        \
    }                                                                       \
                                                                            \
    return funcPtrs.funcName(__VA_ARGS__);                                  \
}

extern void (*cudbgReportDriverInternalErrorPtr)(void);

CUDBGResult haloGetDrvFuncPtrs(NvU32 version, struct HaloDrvFuncPtrs *ptrs)
{
#if NVCFG(GLOBAL_ARCH_VOLTA)
    if (version >= 70)
        return getHaloDrvFuncPtrs_volta(ptrs);
#endif
#if NVCFG(GLOBAL_ARCH_PASCAL)
    if (version >= 60)
        return getHaloDrvFuncPtrs_pascal(ptrs);
#endif
#if NVCFG(GLOBAL_ARCH_MAXWELL)
    if (version >= 50)
        return getHaloDrvFuncPtrs_maxwell(ptrs);
#endif
#if NVCFG(GLOBAL_ARCH_KEPLER)
    if (version >= 35)
        return getHaloDrvFuncPtrs_gk11x(ptrs);
    if (version >= 30)
        return getHaloDrvFuncPtrs_gk10x(ptrs);
#endif
#if NVCFG(GLOBAL_ARCH_FERMI)
    if (version >= 20 && version < 30)
        return getHaloDrvFuncPtrs_fermi(ptrs);
#endif
    return CUDBG_ERROR_INTERNAL;
}

void
haloDrvSetupEMU(void)
{
#ifndef RELEASE
    /*
    On emulation, the debugger and memcheck receive a huge speedup
    by enabling host caching of commonly accessed data, particularly
    LMEM, CRS, and CNP LMEM and QMD data.

    This environment variable is only exposed in debug builds, and is primarily
    meant for emulation. This can control the internal driver state to force
    local memory and CRS to be allocated in host memory.

    This variable is used by setting it to a comma separated list of what to force
    EMU_FORCE_SYSMEM=OPTION1,OPTION2,...
    where OPTION = LMEM,CRS,INTERNAL

     */

    char sysmem[CUOS_ENV_VAR_LENGTH];
    if (!cuosGetEnv("EMU_FORCE_SYSMEM", sysmem, CUOS_ENV_VAR_LENGTH)) {
        if (strstr(sysmem, "CRS"))
            globals.toolsConfig.defaultToolsContextConfig.forceCrsStackAllocInSysmem = NV_TRUE;

        if (strstr(sysmem, "LMEM"))
            globals.toolsConfig.defaultToolsContextConfig.forceLMemAllocInSysmem = NV_TRUE;

        if (strstr(sysmem, "INTERNAL"))
            globals.toolsConfig.defaultToolsContextConfig.forceInternalAllocInSysmem = NV_TRUE;
    }
#endif
}

CUDBGResult
haloDrvThUsesDynamicRegs(CUctx *ctx, NvBool *usesDynamicRegs)
{
    CUDBGResult res;

    if (!ctx || !usesDynamicRegs) {
        CUDBG_ERROR("Invalid arguments when calling %s.\n", __FUNCTION__);
        CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_HALO_DRV_C, CUDBG_ERROR_INTERNAL, CUDBG_ERROR_TYPE_CUDBG);
        res = CUDBG_ERROR_INTERNAL;
        return res;
    }

    HALO_DRV_CALL(ctx->device->state.major * 10 + ctx->device->state.minor,
                  thUsesDynamicRegs,
                  ctx,
                  usesDynamicRegs);
}

CUDBGResult
haloDrvGetFuncMemBaseVA(CUctx *ctx, uint64_t *funcMemBaseVA)
{
    if (!ctx|| !funcMemBaseVA) {
        CUDBG_ERROR("Invalid arguments when calling %s.\n", __FUNCTION__);
        CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_HALO_DRV_C, CUDBG_ERROR_INTERNAL, CUDBG_ERROR_TYPE_CUDBG);
        return CUDBG_ERROR_INTERNAL;
    }

    HALO_DRV_CALL(ctx->device->state.major * 10 + ctx->device->state.minor,
                  getFuncMemBaseVA,
                  ctx,
                  funcMemBaseVA);
}

CUDBGResult
haloDrvAdjustCodeAddress(CUctx *ctx,
                         uint64_t physaddr,
                         uint64_t *adjustedPhysAddr,
                         CUDBGAdjAddrAction adjAction)
{
    if (!ctx || !adjustedPhysAddr) {
        CUDBG_ERROR("Invalid arguments when calling %s.\n", __FUNCTION__);
        CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_HALO_DRV_C, CUDBG_ERROR_INTERNAL, CUDBG_ERROR_TYPE_CUDBG);
        return CUDBG_ERROR_INTERNAL;
    }

    HALO_DRV_CALL(ctx->device->state.major * 10 + ctx->device->state.minor,
                  adjustCodeAddress,
                  physaddr,
                  adjustedPhysAddr,
                  adjAction);
}

CUDBGResult
haloDrvIsStackPointerAssignment(CUctx *ctx, uint64_t instruction[2],
                                int32_t *res, uint32_t *assignmentIdx)
{
    if (!ctx || !res || !assignmentIdx) {
        CUDBG_ERROR("Invalid arguments when calling %s.\n", __FUNCTION__);
        CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_HALO_DRV_C, CUDBG_ERROR_INTERNAL, CUDBG_ERROR_TYPE_CUDBG);
        return CUDBG_ERROR_INTERNAL;
    }

    HALO_DRV_CALL(ctx->device->state.major * 10 + ctx->device->state.minor,
                  isStackPointerAssignment,
                  instruction,
                  res,
                  assignmentIdx);
}

CUDBGResult
haloDrvGetInstructionSize(CUctx *ctx, uint64_t instruction, uint32_t *instSize)
{
    if (!instSize) {
        CUDBG_ERROR("Invalid arguments when calling %s.\n", __FUNCTION__);
        CUDBG_RAISE_DRIVER_INTERNAL_ERROR(CUDBG_ERROR_FILE_HALO_DRV_C, CUDBG_ERROR_INTERNAL, CUDBG_ERROR_TYPE_CUDBG);
        return CUDBG_ERROR_INTERNAL;
    }

    HALO_DRV_CALL(ctx->device->state.major * 10 + ctx->device->state.minor,
                  getInstructionSize,
                  instruction,
                  instSize);
}

