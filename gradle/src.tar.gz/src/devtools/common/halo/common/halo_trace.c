/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/*
 * Description:
 *
 * Debug message functionality implementation.
 *
 */
#include <ctype.h>
#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include "cuda_stdint.h"
#include "cuda_defines.h"
#include "cuos.h"
#include "halo_trace.h"
#include "cudadebugger.h"
#include "cuda_macros.h"

#define TRACE_TMP_BUF_SIZE 1024

int32_t haloTraceLevel = -1;
FILE *haloTraceOutStream;

#ifndef RELEASE
static uint32_t haloTraceInitialized = 0;
static cuosTimer haloTraceTimer;
static float haloTraceTimerLast;
static bool anyRulePrintDeltaTimestamp;
static bool haloTraceShowTime = false;
#endif

typedef struct haloDbgMsgRule_st {
    char     *fname;
    int32_t startLine;
    int32_t endLine;
    int32_t level;
    bool     printFileName;
    bool     printLineNum;
    bool     printFunction;
    bool     printTimestamp;
    bool     printDeltaTimestamp;
    struct haloDbgMsgRule_st *next;
} haloDbgMsgRule;

haloDbgMsgRule *haloDbgMsgRules;
FindPrefix haloTraceFindPrefix;

#ifndef RELEASE
static void haloDbgMsgRulesCleanup(void);
#endif

#ifndef RELEASE
/*
 * Given a valid string, this replaces the following in the string and put the new string into out
 *  - %p with current pid
 *  - %% with %
 *  - everything else is left unchanged
 * out is allocated by caller. If out is not large enough, the string will be cut off
 */
static void haloTraceFileNameSubst(const char *original, char *out, int size)
{
    int i = 0, j = 0;
    int length = (int)strlen(original);

    while (i < length && j < size - 1) {
        if (original[i] == '%') {
            ++i;
            switch (original[i]) {
            case 'p':
                j += snprintf(out + j, size - j, "%d",
#if !cuosOsIsHos() // no getpid on HOS
                        cuosProcessId()
#else
                        0
#endif // !cuosOsIsHos()
                     );
                ++i;
                break;
            case '%':
                out[j] = '%';
                ++j;
                ++i;
                break;
            default:
                out[j] = '%';
                ++j;
                break;
            }
        }
        else {
            out[j] = original[i];
            ++i;
            ++j;
        }
    }
    out[MIN(j, size - 1)] = '\0';
}
#endif

void
haloTraceInit(FindPrefix findPrefix)
{
#ifndef RELEASE
    char traceLevelStr[CUOS_ENV_VAR_LENGTH];
    char traceFileStr[CUOS_ENV_VAR_LENGTH];
    char traceShowTimeStr[CUOS_ENV_VAR_LENGTH];

    haloTraceFindPrefix = findPrefix;

    if (!haloTraceInitialized) {
        haloTraceOutStream = stderr;

        if (!cuosGetEnv("CUDA_GDB_TRACE_LEVEL", traceLevelStr, sizeof traceLevelStr) ||
            !cuosGetEnv("CUDA_GDB_ERROR_LEVEL", traceLevelStr, sizeof traceLevelStr)) {
            haloTraceLevel = atoi(traceLevelStr);
        }

        if (!cuosGetEnv("CUDA_GDB_TRACE_FILE", traceFileStr, sizeof traceFileStr)) {
            char traceFileStrSubst[CUOS_ENV_VAR_LENGTH];
            haloTraceFileNameSubst(traceFileStr, traceFileStrSubst, sizeof traceFileStrSubst);
            haloTraceOutStream = fopen(traceFileStrSubst, "w");
            if (!haloTraceOutStream)
                haloTraceOutStream = stderr;
        }

        /* Re-use enabling env variable from CUDA for drv.out/halo.out correlation */
        if (!cuosGetEnv("CUDA_ERROR_SHOWTIME", traceShowTimeStr, sizeof traceShowTimeStr)) {
            haloTraceShowTime = atoi(traceShowTimeStr);
        }

        cuosResetTimer(&haloTraceTimer);

        haloTraceInitialized = 1;
    }
#endif
    return;
}

void
haloTraceFinalize(void)
{
#ifndef RELEASE
    if (haloTraceInitialized) {
        if (haloTraceOutStream && haloTraceOutStream != stderr) {
            fclose(haloTraceOutStream);
        }
    }
    haloTraceInitialized = 0;
    haloDbgMsgRulesCleanup();
#endif
    return;
}

static bool
haloDbgMsgShouldPrint(int32_t level, const char *file, const int32_t line,
                      const char *function, bool *printFileName,
                      bool *printLineNum, bool *printFunction,
                      bool *printTimestamp, bool *printDeltaTimestamp)
{
    haloDbgMsgRule *rule;
    bool shouldPrint = false;
    bool isExclusion;
    bool ruleMatched;
    char *p;

    for (rule = haloDbgMsgRules; rule; rule = rule->next) {
        p = NULL;
        isExclusion = false;
        ruleMatched = false;

        if (rule->fname) {
            p = rule->fname;

            if (p[0] == '!') {
                isExclusion = true;
                p++;
            }
        }

        /* If the rule specifies a filename, we should have a file
           or function name to compare it with */
        if (p && *p != '\0')
            if ((!file || !strstr(p, file)) &&
                (!function || !strstr(p, function)))
                goto done;

        if (line < rule->startLine || line > rule->endLine)
            goto done;

        if (level > rule->level)
            goto done;

        ruleMatched = true;

done:
        if (!ruleMatched) {
            /* Try the next rule */
            continue;
        }

        if (ruleMatched && isExclusion) {
            shouldPrint = false;
            break;
        }

        shouldPrint = true;
        *printFileName = rule->printFileName;
        *printLineNum = rule->printLineNum;
        *printFunction = rule->printFunction;
        *printTimestamp = rule->printTimestamp;
        *printDeltaTimestamp = rule->printDeltaTimestamp;
        break;
    }

    return shouldPrint;
}

static const char *
haloBasename(const char *str)
{
    if (NULL == str) {
        return NULL;
    }

    uint32_t len = (uint32_t)strlen(str);
    const char *p = str + len - 1;
    while (len > 0 && p && *p != '\\' && *p != '/') {
        p--;
        len--;
    }

    return (str + len);
}

void
haloTrace(uint32_t domain, uint32_t printOptions, int32_t level, const char *file, const int32_t line,
          const char *function, const char *format,  ...)
{
#ifndef RELEASE
    va_list ap;
    char buffer[TRACE_TMP_BUF_SIZE];
    char prefix[6];
    int num = 0;
    bool printFileName, printLineNum, printFunction;
    bool printTimestamp, printDeltaTimestamp;
    float now;
    float elapsed;
    cuosLocalTime localTime;

    if (!haloTraceInitialized)
        // Can't trace before init or after deinit.
        // TODO: assert and remove all the traces that hit this
        return;

    now = cuosGetTimer(&haloTraceTimer);

    /* Errors are always printed. Otherwise if debug msg printing rules are set,
       they override CUDA_GDB_ERROR_LEVEL settings */
    if (level != 0 && haloDbgMsgRules) {
        if (haloDbgMsgShouldPrint(level, haloBasename(file), line, function,
                                  &printFileName,
                                  &printLineNum,
                                  &printFunction,
                                  &printTimestamp,
                                  &printDeltaTimestamp)) {
            if (printTimestamp)
                num += snprintf(buffer + num, 128, "%.2f ", now);
            if (printDeltaTimestamp) {
                elapsed = now - haloTraceTimerLast;
                num += snprintf(buffer + num, 128, "+%8.2f ", elapsed);
                haloTraceTimerLast = now;
            }
            else if (anyRulePrintDeltaTimestamp)
                num += snprintf(buffer + num, 128, "         ");
            if (printFileName)
                num += snprintf(buffer + num, 128, "%s:", haloBasename(file));
            if (printLineNum)
                num += snprintf(buffer + num, 128, "%u ", line);
            if (printFunction)
                num += snprintf(buffer + num, 128, "%s ", function);
        }
        else
            /* This message is filtered out */
            return;
    }
    else if (level != 0 && level > haloTraceLevel)
        return;

    if (haloTraceShowTime) {
        cuosGetLocalTime(&localTime);
        num += snprintf(buffer + num, 128,
                        "[%.2u:%.2u:%.2u.%.3u] ",
                        localTime.hour,
                        localTime.min,
                        localTime.sec,
                        localTime.msec);
    }

    if (printOptions & HALO_TRACE_TYPE_NEWLINE)
        num += snprintf(buffer + num, 128, "\n");

    if (!(printOptions & HALO_TRACE_TYPE_SKIP_LEVEL))
        num += snprintf(buffer + num, 128, "%03u ", level);

    if (printOptions & HALO_TRACE_TYPE_FILE) {
        haloTraceFindPrefix(file, prefix);
        num += snprintf(buffer + num, 128, "%5s ", prefix);
    }

    if (printOptions & HALO_TRACE_TYPE_LINE)
        num += snprintf(buffer + num, 128, "%u ", line);

    if (printOptions & HALO_TRACE_TYPE_FUNCTION)
        num += snprintf(buffer + num, 128, "%-20s ", function);

    va_start(ap, format);
    vsnprintf(buffer + num, 640, format, ap);
    va_end(ap);

    fprintf(haloTraceOutStream, "%s", buffer);
    fflush(haloTraceOutStream);
#endif
}

/*  [!][file|function][:startline][-endline][@level][^prefix]

    Description:
     !         - makes this rule an exclusion rule instead of an inclusion rule
     file      - a string matching all or part of the filename
     function  - a string matching all or part of a function
     startline - a single line number or the start of a line range with endline
     endline   - the end of an line range
     level     - suppress messages < level. Level is the integer value for DBG_LEVEL_*.
     prefix    - prefix more stuff like timestamps, filename etc. to the print
        Format: file line function timestamp
            '*' Enable all
            'n' Enable filename
            'l' Enable line number
            'f' Enable function
            't' Enable timestamp
            'T' Enable delta timestamp

    All components are optional and a rule may be partially or fully stated.
    The result is cumulative, so a later rule may negate a previously specified rule.
*/
#ifndef RELEASE
static void
haloDbgMsgRulesAddRule(haloDbgMsgRule *rule)
{
    haloDbgMsgRule *newRule = (haloDbgMsgRule *)calloc(1, sizeof(haloDbgMsgRule));

    newRule->fname          = rule->fname;
    newRule->startLine      = rule->startLine;
    newRule->endLine        = rule->endLine;
    newRule->level          = rule->level;
    newRule->printFileName  = rule->printFileName;
    newRule->printLineNum   = rule->printLineNum;
    newRule->printFunction  = rule->printFunction;
    newRule->printTimestamp = rule->printTimestamp;
    newRule->printDeltaTimestamp = rule->printDeltaTimestamp;

    if (NULL == haloDbgMsgRules)
        haloDbgMsgRules = newRule;
    else {
        newRule->next = haloDbgMsgRules;
        haloDbgMsgRules = newRule;
    }
}

static void
haloDbgMsgRulesCleanup(void)
{
    haloDbgMsgRule *rule = haloDbgMsgRules;
    while (haloDbgMsgRules) {
        rule = haloDbgMsgRules;
        haloDbgMsgRules = haloDbgMsgRules->next;
        free(rule->fname);
        free(rule);
    }
}

static void
haloDbgMsgRulesInitRule(haloDbgMsgRule *rule)
{
    memset(rule, 0, sizeof *rule);
    rule->startLine = 0;
    rule->endLine = 0x7fffffff;
    rule->level = 200;
    rule->next = NULL;
}

static bool
haloDbgMsgIsDelimiter(char c)
{
    uint32_t i;
    const char delimiters[] = {":-@^,"};

    for (i = 0; i < strlen(delimiters); i++)
        if (delimiters[i] == c)
            return true;

    return false;
}

void
haloDbgMsgRulesInit(void)
{
    char *p = getenv("CUDA_GDB_DEBUG_MSG_FORMAT");
    char tokenType;
    char *tokenStart;
    uint32_t tokenLength;
    char *tokenBuffer;
    char *prefixOptions;
    haloDbgMsgRule rule = {0};
    bool ruleValid = false;

    haloDbgMsgRulesInitRule(&rule);

    while (p) {
        tokenType = *p;
        tokenBuffer = NULL;

        if (*p == ',' || *p == '\0') {
            if (ruleValid) {
                /* Submit rule */
                haloDbgMsgRulesAddRule(&rule);
            }

            /* Finished rule parsing? */
            if (*p == '\0')
                break;

            /* More rules to parse */
            ruleValid = false;
            haloDbgMsgRulesInitRule(&rule);
            p++;
            continue;
        }

        /* Skip over tokenType unless it's a file/function name */
        if (haloDbgMsgIsDelimiter(tokenType))
            p++;

        /* Extact the token. '*' and '!' are allowed characters in tokens, besides
           alphanumerics. */
        tokenStart = p;
        while (*p && !haloDbgMsgIsDelimiter(*p))
            p++;
        tokenLength = (uint32_t)(p - tokenStart);

        if (tokenLength) {
            tokenBuffer = (char *)malloc(tokenLength + 1);
            strncpy(tokenBuffer, tokenStart, tokenLength);
            tokenBuffer[tokenLength] = '\0';
        }

        /* Store the token in the rule struct */
        switch (tokenType) {
        case ':':
            if (tokenLength) {
                rule.startLine = atoi(tokenBuffer);
                ruleValid = true;
                free(tokenBuffer);
            }
            break;
        case '-':
            if (tokenLength) {
                rule.endLine = atoi(tokenBuffer);
                ruleValid = true;
                free(tokenBuffer);
            }
            break;
        case '@':
            if (tokenLength) {
                rule.level = atoi(tokenBuffer);
                ruleValid = true;
                free(tokenBuffer);
            }
            break;
        case '^':
            if (tokenLength) {
                /* Extract prefixes */
                prefixOptions = tokenBuffer;

                while (*prefixOptions != '\0') {
                    switch (*prefixOptions) {
                    case '*':
                        ruleValid = true;
                        rule.printFileName = true;
                        rule.printLineNum = true;
                        rule.printFunction = true;
                        rule.printTimestamp = true;
                        rule.printDeltaTimestamp = true;
                        break;
                    case 'n':
                        ruleValid = true;
                        rule.printFileName = true;
                        break;
                    case 'l':
                        ruleValid = true;
                        rule.printLineNum = true;
                        break;
                    case 'f':
                        ruleValid = true;
                        rule.printFunction = true;
                        break;
                    case 't':
                        ruleValid = true;
                        rule.printTimestamp = true;
                        break;
                    case 'T':
                        ruleValid = true;
                        rule.printDeltaTimestamp = true;
                        break;
                    default:
                        /* Support custom prefixes  */
                        break;
                    }

                    if (rule.printDeltaTimestamp)
                        anyRulePrintDeltaTimestamp = true;

                    prefixOptions++;
                }
                free(tokenBuffer);
            }
            break;
        default:
            /* Discard junk tokens */
            if (!isalnum(tokenType) && tokenType != '!') {
                p++;
                break;
            }
            ruleValid = true;
            rule.fname = tokenBuffer;
        }
    }
}
#endif
