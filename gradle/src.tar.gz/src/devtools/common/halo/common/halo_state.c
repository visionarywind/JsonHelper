/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: halo_state.c
 *
 *   Description:
 *       Contains functions to track the state of the halo. All functions here
 *       must be address space agnostic, and can be used by either halo type
 *
 ******************************************************************************/
#include "cuda_types.h"
#include "halo.h"
#include "halo_internal.h"
#include "halo_state.h"
#include "halo_memmap.h"

#ifndef CLASS_CL83DE_H_MISSING
#include "class/cl83de.h"
#include "ctrl/ctrl83de.h"
#endif

/* Used for grid deletion */
typedef enum {
    HALO_GRID_MAP_FILTER_NONE     =        0,
    HALO_GRID_MAP_FILTER_FUNCTION = (1 << 0),
    HALO_GRID_MAP_FILTER_CONTEXT  = (1 << 1),
    HALO_GRID_MAP_FILTER_DEV      = (1 << 2),

    HALO_GRID_MAP_FILTER_ALL      = 0xFFFFFFFFU,
} HaloGridMapFilters;

/* Used for storing instruction info */
typedef struct InsnInfo_st *InsnInfo;

struct InsnInfo_st {
    uint64_t insn[2];    /* max insn size is 16 bytes */
    bool     insnValid;
};

/* Forward declarations */
static void haloStateDestroyGridInternal(Grid grid, FLAG_SET(HaloGridMapFilters) filter);

CUDBGResult
haloStateInit(void)
{
    CUDBGResult res;
    TOOLSresult tres = TOOLS_SUCCESS;

    if (haloGlobals.state)
        return CUDBG_SUCCESS;

    haloGlobals.state = (struct haloState_st *)calloc(1, sizeof *haloGlobals.state);

    if (!haloGlobals.state)
        return CUDBG_ERROR_INITIALIZATION_FAILURE;

    haloGlobals.state->contexts    = toolsHashMapNew(toolsUint32HashFun, toolsUint64EqualFun, 8);
    haloGlobals.state->devices     = toolsHashMapNew(toolsUint32HashFun, toolsUint64EqualFun, 8);

    res = haloMemoryMapCreate(&haloGlobals.globalMemMap, NULL);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to create global memMap\n");

    tres = toolsRangeMapCreate(&haloGlobals.globalHostVAMap);
    if (tres != TOOLS_SUCCESS) {
        HALO_ERROR("Failed to create globalHostVAMap. (Tres=%u)\n", tres);
        res = CUDBG_ERROR_UNKNOWN;
        return res;
    }

    return CUDBG_SUCCESS;
}

CUDBGResult
haloStateInitUVM(uint64_t uvmhdl)
{
#if cuosPlatformHasKernelModeUvm()
    NV_STATUS status = NV_OK;
    CUDBG_VERIFY(globals.enableUvm, CUDBG_ERROR_INTERNAL, "UVM not enabled in debugger session\n");

    if (!globals.useUvm8Api)    /* UVM8 api not enabled, skip this */
        return CUDBG_SUCCESS;

    if (haloGlobals.uvmSession) /* Already initialized */
        return CUDBG_SUCCESS;

    HALO_TRACE_FUNCTION(10, "Creating uvm session with uvmhdl=%d\n", uvmhdl);

    status = UvmToolsCreateSession((UvmFileDescriptor)uvmhdl, &haloGlobals.uvmSession);
    CUDBG_VERIFY(status == NV_OK, CUDBG_ERROR_INTERNAL, "Unable to create uvm8 session (status=%#x)\n", status);
#endif

    return CUDBG_SUCCESS;
}

CUDBGResult
haloStateDestroyUVM(void)
{
#if cuosPlatformHasKernelModeUvm()
    NV_STATUS status = NV_OK;

    if (!haloGlobals.uvmSession)
        return CUDBG_SUCCESS;

    CUDBG_VERIFY(globals.enableUvm, CUDBG_ERROR_INTERNAL, "UVM8 not enabled in debugger session\n");

    status = UvmToolsDestroySession(haloGlobals.uvmSession);

    CUDBG_VERIFY(status == NV_OK, CUDBG_ERROR_INTERNAL, "Unable to destroy uvm8 session (status=%#x)\n", status);
#endif

    return CUDBG_SUCCESS;
}

void
haloStateDestroy(void)
{
    if (!haloGlobals.state)
        return;

    if (haloGlobals.state->contexts) {
        (void)toolsHashMapDelete(haloGlobals.state->contexts, NULL, NULL);
        haloGlobals.state->contexts = NULL;
    }

    if (haloGlobals.state->devices) {
        (void)toolsHashMapDelete(haloGlobals.state->devices, NULL, NULL);
        haloGlobals.state->devices = NULL;
    }

    free(haloGlobals.state);
    haloGlobals.state = NULL;

    toolsRangeMapDestroy(&haloGlobals.globalHostVAMap, NULL, NULL);
    haloGlobals.globalHostVAMap = NULL;

    (void)haloMemoryMapDestroy(haloGlobals.globalMemMap);
    haloGlobals.globalMemMap = NULL;
}

haloMemoryMap*
haloStateGetGlobalMemMap(void)
{
    return haloGlobals.globalMemMap;
}

tRangeMap*
haloStateGetGlobalHostVAMap(void)
{
    return haloGlobals.globalHostVAMap;
}

bool haloStateContextIsActive(Context ctx)
{
    if (!ctx)
        return false;

    return (ctx->state == HALO_CTX_STATE_ACTIVE);
}

CUDBGResult
haloStateContextSetState(Context ctx, HaloCtxState state)
{
    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    ctx->state = state;

    return CUDBG_SUCCESS;
}

CUDBGResult
haloStateContextFillScratchpadCache(Context ctx)
{
    CUDBGResult res;
    
    if (ctx->scratchpadCache && !ctx->scratchpadCacheValid && ctx->scratchpadDevVA != ~0ULL) {
        HALO_TRACE_FUNCTION(49, "filling context scratchpad cache\n");

        /* load the entire scratchpad into the context cache */
        res = ctx->dev->halo.readDeviceMemory(ctx,
                                              ctx->scratchpadDevVA,
                                              ctx->scratchpadCache,
                                              (uint32_t)ctx->dev->halo.deviceInfo.scratchpadSize);
        if (res != CUDBG_SUCCESS)
            return res;

        ctx->scratchpadCacheValid = true;
    }

    return CUDBG_SUCCESS;
}

CUDBGResult
haloStateContextScratchpadCacheOp(Context ctx, HaloMemorySegmentCacheOp op)
{
    CUDBGResult res;
    
    /* Context cache is read-only, so FLUSH is a no-op */
    if (op == HALO_MEM_SEG_CACHE_ENABLE) {
        if (!ctx->scratchpadCacheValid) {
            res = haloStateContextFillScratchpadCache(ctx);
            if (res != CUDBG_SUCCESS)
                return res;
        }
    }
    else if (op == HALO_MEM_SEG_CACHE_DISABLE
             || op == HALO_MEM_SEG_CACHE_INVALIDATE) {
        HALO_TRACE_FUNCTION(49, "invalidating contextAccessor scratchpad cache\n");
        ctx->scratchpadCacheValid = false;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloStateContextGetScratchpadField(HaloScratchpadAccessor accessor, HaloScratchpadField field,
                                   HaloScratchpadSection section, uint32_t sm,
                                   uint32_t wp, uint32_t ln, void *value, size_t size)
{
    CUDBGResult res;
    size_t offset = 0;
    size_t fieldWidth;
    Context ctx = (Context)accessor->userState;
    
    if (!ctx->scratchpadCacheValid) {
        res = haloStateContextFillScratchpadCache(ctx);
        if (res != CUDBG_SUCCESS)
            return res;
    }
    
    if (ctx->scratchpadCacheValid) {
        HALO_TRACE_FUNCTION(60, "using scratchpad cache\n");

        res = ctx->dev->halo.scratchpad.getFieldOffset(field, section, sm, wp, ln, &offset, &fieldWidth);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");

        CUDBG_VERIFY(fieldWidth == size, CUDBG_ERROR_INTERNAL,
                     "Mismatch between access size (%d) and field width (%d)\n",
                     (uint32_t)size, (uint32_t)fieldWidth);

        memcpy(value, ((uint8_t *)ctx->scratchpadCache) + (uint32_t)offset, size);

        return CUDBG_SUCCESS;
    }

    HALO_TRACE_FUNCTION(60, "using scratchpad direct access\n");
    return haloScratchpadGetField((Context)accessor->userState, field, section, sm, wp, ln, value, size);
}

static CUDBGResult
haloStateContextSetScratchpadField(HaloScratchpadAccessor accessor, HaloScratchpadField field,
                                   HaloScratchpadSection section, uint32_t sm,
                                   uint32_t wp, uint32_t ln, void *value, size_t size)
{
    CUDBGResult res;
    size_t offset = 0;
    size_t fieldWidth;
    Context ctx = (Context)accessor->userState;

    /* Insert into context scratchpad cache */
    if (ctx->scratchpadCacheValid) {
        res = ctx->dev->halo.scratchpad.getFieldOffset(field, section, sm, wp, ln, &offset, &fieldWidth);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");

        CUDBG_VERIFY(fieldWidth == size, CUDBG_ERROR_INTERNAL,
                     "Mismatch between access size (%d) and field width (%d)\n",
                     (uint32_t)size, (uint32_t)fieldWidth);

        memcpy(((uint8_t *)ctx->scratchpadCache) + (uint32_t)offset, value, size);
    }

    /* Update the scratchpad itself */
    return haloScratchpadSetField((Context)accessor->userState, field, section, sm, wp, ln, value, size);
}

static CUDBGResult
haloStateContextCreateScratchpadAccessor(Context context, HaloScratchpadAccessor *accessor)
{
    HaloScratchpadAccessor outAccessor;

    CUDBG_VERIFY(context && accessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    outAccessor = (HaloScratchpadAccessor)malloc(sizeof(*outAccessor));
    if (!outAccessor) {
        HALO_ERROR("Failed to allocate memory for scratchpad accessor\n");
        return CUDBG_ERROR_OS_RESOURCES;
    }
    outAccessor->userState = context;
    outAccessor->getField = haloStateContextGetScratchpadField;
    outAccessor->setField = haloStateContextSetScratchpadField;

    *accessor = outAccessor;

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloStateContextGetPreemptionBufferField(HaloPreemptionBufferAccessor accessor, HaloPreemptionBufferField field,
                                         HaloPreemptionBufferSection section, uint32_t sm, uint32_t cta,
                                         uint32_t wp, uint32_t ln, void *value, size_t size)
{
    return haloPreemptionBufferGetField((Context)accessor->userState, field, section, sm, cta, wp, ln, value, size);
}

static CUDBGResult
haloStateContextSetPreemptionBufferField(HaloPreemptionBufferAccessor accessor, HaloPreemptionBufferField field,
                                         HaloPreemptionBufferSection section, uint32_t sm, uint32_t cta,
                                         uint32_t wp, uint32_t ln, void *value, size_t size)
{
    return haloCilpBufferSetField((Context)accessor->userState, field, section, sm, cta, wp, ln, value, size);
}

static CUDBGResult
haloStateContextCreatePreemptionBufferAccessor(Context context, HaloPreemptionBufferAccessor *accessor)
{
    HaloPreemptionBufferAccessor outAccessor;

    CUDBG_VERIFY(context && accessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    outAccessor = (HaloPreemptionBufferAccessor)malloc(sizeof(*outAccessor));
    if (!outAccessor) {
        HALO_ERROR("Failed to allocate memory for scratchpad accessor\n");
        return CUDBG_ERROR_OS_RESOURCES;
    }
    outAccessor->userState = context;
    outAccessor->getField = haloStateContextGetPreemptionBufferField;
    outAccessor->setField = haloStateContextSetPreemptionBufferField;

    *accessor = outAccessor;

    return CUDBG_SUCCESS;
}

bool
haloStateInsnCacheEnabled(void)
{
    return !!(haloGlobals.initData.flags & HALO_INIT_FLAGS_ENABLE_INSN_CACHE);
}

static void
destroyInsnInfoCallback(void *data, void *unused)
{
    free(data);
}

CUDBGResult
haloStateContextInsnInfoCacheOp(Context ctx, HaloMemorySegmentCacheOp op)
{
    if (!haloStateInsnCacheEnabled())
        return CUDBG_SUCCESS;

    /* instruction info cache is read-only, so FLUSH/ENABLE is a no-op */
    if (ctx->insnInfoCache && (op == HALO_MEM_SEG_CACHE_DISABLE
                               || op == HALO_MEM_SEG_CACHE_INVALIDATE)) {
        HALO_TRACE_FUNCTION(40, "invalidating instruction info cache\n");
        (void)toolsHashMapDelete(ctx->insnInfoCache, destroyInsnInfoCallback, NULL);
        ctx->insnInfoCache = NULL;
    }

    return CUDBG_SUCCESS;
}

CUDBGResult
haloStateContextReadInsnCache(Context ctx, uint64_t pc, void *buf, uint32_t sz)
{
    InsnInfo info;

    if (!haloStateInsnCacheEnabled())
        return CUDBG_ERROR_MISSING_DATA;

    if (ctx->insnInfoCache && sz <= sizeof(info->insn)) {
        info = (InsnInfo) toolsHashMapFind(ctx->insnInfoCache, pc);
        if (info && info->insnValid) {
            memcpy(buf, info->insn, sz);
            return CUDBG_SUCCESS;
        }
    }

    return CUDBG_ERROR_MISSING_DATA;
}

CUDBGResult
haloStateContextWriteInsnCache(Context ctx, uint64_t pc, const void *buf, uint32_t sz)
{
    InsnInfo info;
    CUDBGResult res;
    TOOLSresult tres;

    if (!haloStateInsnCacheEnabled())
        return CUDBG_SUCCESS;

    if (sz <= sizeof(info->insn)) {
        if (!ctx->insnInfoCache) {
            ctx->insnInfoCache = toolsHashMapNew(toolsPointerHashFun, toolsUint64EqualFun, 64);
            CUDBG_VERIFY(ctx->insnInfoCache, CUDBG_ERROR_OS_RESOURCES, "Failed to allocate insnInfoCache\n");
        }

        info = (InsnInfo) toolsHashMapFind(ctx->insnInfoCache, pc);
        if (!info) {
            info = (InsnInfo)calloc(1, sizeof(*info));
            CUDBG_VERIFY(info, CUDBG_ERROR_OS_RESOURCES, "Failed to allocate InsnInfo\n");

            tres = toolsHashMapInsert(ctx->insnInfoCache, tHashMapNumToKey(pc), info);
            CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_UNKNOWN, "Failed to insert info into insnInfoCache map\n");
        }

        memcpy(info->insn, buf, sz);
        info->insnValid = true;
    }
    else if (ctx->insnInfoCache) {
        /* large write to code memory - invalidate cache */
        HALO_TRACE_FUNCTION(40, "invalidating instruction info cache due to large write\n");
        res = haloStateContextInsnInfoCacheOp(ctx, HALO_MEM_SEG_CACHE_INVALIDATE);
        if (res != CUDBG_SUCCESS) {
            HALO_TRACE_FUNCTION(40, "error invalidating instruction info cache due to large write\n");
            return res;
        }
    }

    return CUDBG_SUCCESS;
}

CUDBGResult
haloStateCreateContext(Context *pCtx, uint64_t cuctx, uint32_t devId, uint64_t scratchpadDevVA,
                       uint64_t scratchpadDevPtr, uint32_t hAppClient, uint32_t hComputeObject,
                       uint32_t hChannelGroup, uint32_t *channelList,  uint32_t numChannels)
{
    Context context;
    uint32_t i = 0;
    TOOLSresult tres = TOOLS_SUCCESS;
    CUDBGResult res = CUDBG_SUCCESS;
    CUdev *pDev;
    haloMemoryMap *parentMap;

    CUDBG_VERIFY(pCtx, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_VERIFY(cuctx, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context.\n");

    CUDBG_VERIFY((numChannels * sizeof(*channelList)) <= sizeof(context->hComputeChannelList), CUDBG_ERROR_INVALID_ARGS, "Channel list too large\n");

    CUDBG_VERIFY(globals.devices[devId], CUDBG_ERROR_INVALID_DEVICE, "Invalid device\n");

    context = (Context)calloc(1, sizeof(*context));
    CUDBG_VERIFY(context, CUDBG_ERROR_INTERNAL, "Failed to create context structure\n");

    context->cuCtx = cuctx;
    context->dev = haloGlobals.device[devId];
    context->scratchpadDevVA = scratchpadDevVA;
    context->scratchpadDevPtr = scratchpadDevPtr;

    CUDBG_VERIFY(context->dev->halo.deviceInfo.scratchpadSize > 0, CUDBG_ERROR_INTERNAL, "scratchpad size of 0\n");

    context->scratchpadCache = malloc((size_t)context->dev->halo.deviceInfo.scratchpadSize);
    if (!context->scratchpadCache) {
        HALO_ERROR("Failed to allocate memory for scratchpad cache\n");
        free(context);
        return CUDBG_ERROR_OS_RESOURCES;
    }
    context->scratchpadCacheValid = false;

    context->insnInfoCache = NULL;

    context->state = HALO_CTX_STATE_INVALID;
    context->enableEvents = true;

    context->modules = toolsHashMapNew(toolsUint32HashFun, toolsUint64EqualFun, 64);
    context->grids = toolsHashMapNew(toolsUint32HashFun, toolsUint64EqualFun, 64);

    tres = toolsRangeMapCreate(&context->gpuAddrToPatch);
    if (tres != TOOLS_SUCCESS) {
        HALO_ERROR("Failed to create gpuAddrToPatch map\n");
        free(context->scratchpadCache);
        free(context);
        return CUDBG_ERROR_UNKNOWN;
    }

    tres = toolsRangeMapCreate(&context->virtAddrToPatch);
    if (tres != TOOLS_SUCCESS) {
        HALO_ERROR("Failed to create virtAddrToPatch map\n");
        free(context->scratchpadCache);
        free(context);
        return CUDBG_ERROR_UNKNOWN;
    }

    tres = toolsRangeMapCreate(&context->gpuAddrToFunction);
    if (tres != TOOLS_SUCCESS) {
        HALO_ERROR("Failed to create gpuAddrToFunction map\n");
        free(context->scratchpadCache);
        free(context);
        return CUDBG_ERROR_UNKNOWN;
    }

    context->patchEntry = toolsHashMapNew(toolsUint32HashFun, toolsUint64EqualFun, 8);

    memset(&context->debugObj, 0, sizeof(DebugObject));

    context->hAppClient = hAppClient;
    context->hComputeObject = hComputeObject;
    context->hChannelGroup = hChannelGroup;

    /* Non-UVA devices cannot do peer accesses of memory, so they cannot access
     * any memory that's in the global memory map. */
    pDev = globals.devices[devId];
    if (pDev->state.canDoUva)
        parentMap = haloGlobals.globalMemMap;
    else
        parentMap = NULL;

    res = haloMemoryMapCreate(&context->memMap, parentMap);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Error creating memMap (res=%d)\n", res);
        free(context->scratchpadCache);
        free(context);
        return res;
    }

    context->memMapActive = true;

    for (i = 0; i < CUDBG_MAX_CHANNELS ; ++i) {
        context->hComputeChannelList[i] = CUDBG_INVALID_HANDLE;
        context->channelfds[i] = -1;
    }

    context->numChannels = numChannels;

    if (channelList && numChannels)
        memcpy(context->hComputeChannelList,
               channelList,
               numChannels * sizeof(*channelList));

    res = haloStateContextCreateScratchpadAccessor(context, &context->scratchpadAccessor);
    if (res != CUDBG_SUCCESS) {
        free(context->scratchpadCache);
        free(context);
        return res;
    }

    res = haloStateContextCreatePreemptionBufferAccessor(context, &context->preemptionBufferAccessor);
    if (res != CUDBG_SUCCESS) {
        free(context->scratchpadCache);
        free(context);
        return res;
    }

    *pCtx = context;

    return CUDBG_SUCCESS;
}

static void
destroyGridListCallback(void *data, void *unused)
{
    Grid grid = (Grid)data;
    haloStateDestroyGridInternal(grid, HALO_GRID_MAP_FILTER_DEV | HALO_GRID_MAP_FILTER_CONTEXT);
}

static void
removeAllGrids(tHashMap *thisMap)
{
    toolsHashMapDelete(thisMap, destroyGridListCallback, NULL);
}

void
haloStateDestroyContext(Context context)
{
    if (!context)
        return;

    context->memMapActive = false;

    if (context->memMap) {
        (void)haloMemoryMapDestroy(context->memMap);
        context->memMap = NULL;
    }

    if (context->modules) {
        (void)toolsHashMapDelete(context->modules, NULL, NULL);
        context->modules = NULL;
    }

    if (context->insnInfoCache) {
        (void)toolsHashMapDelete(context->insnInfoCache, destroyInsnInfoCallback, NULL);
        context->insnInfoCache = NULL;
    }

    (void)toolsRangeMapDestroy(&context->gpuAddrToFunction, NULL, NULL);
    (void)toolsRangeMapDestroy(&context->gpuAddrToPatch, NULL, NULL);
    (void)toolsRangeMapDestroy(&context->virtAddrToPatch, NULL, NULL);

    /* The actual entries in context->grids are freed when the function
       is destroyed */
    if (context->grids) {
        toolsHashMapDelete(context->grids, NULL, NULL);
        context->grids = NULL;
    }

    free(context->scratchpadAccessor);
    free(context->preemptionBufferAccessor);

    free(context);
}

Context
haloStateGetContext(uint64_t cuctx)
{
    if (!haloGlobals.state)
        return NULL;

    return (Context)toolsHashMapFind(haloGlobals.state->contexts,tHashMapNumToKey(cuctx));
}

CUDBGResult
haloStateAddContext(uint64_t cuctx, Context context)
{
    TOOLSresult tres = TOOLS_SUCCESS;

    CUDBG_VERIFY(context->dev, CUDBG_ERROR_INVALID_DEVICE, "Invalid device.\n");

    if (!haloGlobals.state)
        haloStateInit();

    tres = toolsHashMapInsert(haloGlobals.state->contexts, tHashMapNumToKey(cuctx), context);
    CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_UNKNOWN, "Failed to insert context into haloGlobals.state->contexts map\n");

    tres = toolsHashMapInsert(context->dev->contexts, tHashMapNumToKey(cuctx), context);
    CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_UNKNOWN, "Failed to insert context into dev->contexts map\n");

    return CUDBG_SUCCESS;
}

CUDBGResult
haloStateRemoveContext(uint64_t cuctx)
{
    TOOLSresult tres = TOOLS_SUCCESS;
    Context context;

    /* Globals not initialized, nothing to do nothing */
    if (!haloGlobals.state)
        return CUDBG_SUCCESS;

    context = haloStateGetContext(cuctx);

    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context.\n");

    tres = toolsHashMapRemove(context->dev->contexts, tHashMapNumToKey(cuctx), NULL);
    CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_UNKNOWN, "Failed to remove context from dev->contexts map\n");

    tres = toolsHashMapRemove(haloGlobals.state->contexts, tHashMapNumToKey(cuctx), NULL);
    CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_UNKNOWN, "Failed to remove context from haloGlobals.state->contexts map\n");

    return CUDBG_SUCCESS;
}

CUDBGResult
haloStateNumContextsForDevice(CudbgDevice dev, int *numContexts)
{
    CUDBG_VERIFY(numContexts, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    *numContexts = (int)toolsHashMapSize(dev->contexts);

    return CUDBG_SUCCESS;
}

CUDBGResult
haloStateNumTotalContexts(int *numContexts)
{
    CUDBG_VERIFY(numContexts, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    *numContexts = (int)toolsHashMapSize(haloGlobals.state->contexts);

    return CUDBG_SUCCESS;
}

struct haloCtxTraverse {
    haloCtxIterFunc pfn;
    void *userData;
    CUDBGResult res;
};

static TOOLSresult
ctxIterator(tHashMapKey_t key, void *entry, void *data)
{
    Context ctx;
    struct haloCtxTraverse *travData;

    travData = (struct haloCtxTraverse*)data;
    ctx = (Context)entry;

    /* Early exit if travData has not been created */
    if (!travData)
        return TOOLS_SUCCESS;

    /* Early exit on pending errors */
    if (travData->res != CUDBG_SUCCESS)
        return TOOLS_SUCCESS;

    /* Call the callback */
    if (travData->pfn)
        travData->res = travData->pfn(ctx, travData->userData);

    return TOOLS_SUCCESS;
}

CUDBGResult
haloStateTraverseContexts(haloCtxIterFunc pfn, void *userData)
{
    struct haloCtxTraverse travData = {0};

    /* State not initialized. Nothing to traverse */
    if (!haloGlobals.state || !haloGlobals.state->contexts)
        return CUDBG_SUCCESS;

    travData.pfn       = pfn;
    travData.userData  = userData;
    travData.res       = CUDBG_SUCCESS;

    (void)toolsHashMapApplyFunctor(haloGlobals.state->contexts, ctxIterator, &travData);

    return travData.res;
}

static void
ctxDelIterator(void *entry, void *data)
{
    Context ctx;
    struct haloCtxTraverse *travData;

    travData = (struct haloCtxTraverse*)data;
    ctx = (Context)entry;

    /* Early exit if travData has not been created */
    if (!travData)
        return;

    /* Early exit on pending errors */
    if (travData->res != CUDBG_SUCCESS)
        return;

    /* Call the callback */
    if (travData->pfn)
        travData->res = travData->pfn(ctx, travData->userData);
}

CUDBGResult
haloStateDestroyContexts(haloCtxIterFunc pfn, void *userData)
{
    struct haloCtxTraverse travData = {0};

    if (!haloGlobals.state)
        return CUDBG_SUCCESS;

    travData.pfn       = pfn;
    travData.userData  = userData;
    travData.res       = CUDBG_SUCCESS;

    (void)toolsHashMapDelete(haloGlobals.state->contexts, ctxDelIterator, &travData);
    haloGlobals.state->contexts = NULL;

    return travData.res;
}

CudbgDevice
haloStateGetDevice(uint64_t cudev)
{
    if (!haloGlobals.state)
        return NULL;

    return (CudbgDevice)toolsHashMapFind(haloGlobals.state->devices, tHashMapNumToKey(cudev));
}

CUDBGResult
haloStateAddDevice(uint32_t devid, CudbgDevice dev)
{
    TOOLSresult tres = TOOLS_SUCCESS;

    CUDBG_VERIFY((dev && devid < globals.numDevices), CUDBG_ERROR_INVALID_DEVICE, "Invalid device.\n");

    if (!haloGlobals.state)
        haloStateInit();

    tres = toolsHashMapInsert(haloGlobals.state->devices, tHashMapNumToKey((uint64_t)(uintptr_t)globals.devices[devid]), (void*)dev);
    CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_UNKNOWN, "Failed to insert into haloGlobals->state.devices map\n");

    return CUDBG_SUCCESS;
}

CUDBGResult
haloStateCreateGrid(Grid *pGrid, DeviceFunction function, uint64_t gridId64)
{
    Grid grid = NULL;
    Context context = function->module->context;
    CudbgDevice dev = context->dev;
    bool isReserved;
    CUDBGResult res;

    CUDBG_VERIFY(pGrid,  CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");
    CUDBG_VERIFY(function, CUDBG_ERROR_UNKNOWN_FUNCTION, "Unknown function.\n");
    CUDBG_VERIFY(context, CUDBG_ERROR_INTERNAL, "Unknown context.\n");

    grid = (Grid)calloc(1, sizeof *grid);

    CUDBG_VERIFY(grid, CUDBG_ERROR_INVALID_GRID, "Out of memory.\n");

    grid->function = function;
    grid->gridId64 = gridId64;

    /* For grids that are created while they are inside global syscalls, the
     * function != userEntryFunction, so the field below may need to be corrected
     * by calling the appropriate HAL function. */
    grid->userEntryFunction = function;

    /* Indicate this grid hasn't yet been posted (become user-visible) */
    grid->state = HALO_GRID_STATE_INVISIBLE;
    grid->parentGridId64 = 0;

    *pGrid = grid;

    toolsHashMapInsert(dev->gridIdToGrid, tHashMapNumToKey(gridId64), grid);
    toolsHashMapInsert(function->grids, tHashMapNumToKey(gridId64), grid);
    toolsHashMapInsert(context->grids, tHashMapNumToKey(gridId64), grid);

    /* Check if this grid is reserved */
    res = dev->halo.isReservedGridId(dev, gridId64, &isReserved);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to determine if grid is reserved\n");
        return res;
    }

    if ((int64_t)grid->gridId64 > 0 || isReserved)
        grid->origin = CUDBG_KNL_ORIGIN_CPU;
    else
        grid->origin = CUDBG_KNL_ORIGIN_GPU;

    return CUDBG_SUCCESS;
}

static void
haloStateDestroyGridInternal(Grid grid, FLAG_SET(HaloGridMapFilters) filter)
{
    DeviceFunction function;
    Context context;
    CudbgDevice dev;

    if (!grid)
        return;

    function = grid->function;
    context = function->module->context;
    dev = context->dev;

    if (filter & HALO_GRID_MAP_FILTER_FUNCTION)
        toolsHashMapRemove(function->grids, tHashMapNumToKey(grid->gridId64), NULL);
    if (filter & HALO_GRID_MAP_FILTER_CONTEXT)
        toolsHashMapRemove(context->grids, tHashMapNumToKey(grid->gridId64), NULL);
    if (filter & HALO_GRID_MAP_FILTER_DEV)
        toolsHashMapRemove(dev->gridIdToGrid, tHashMapNumToKey(grid->gridId64), NULL);

    free(grid);
}

void
haloStateDestroyGrid(Grid grid)
{
    haloStateDestroyGridInternal(grid, HALO_GRID_MAP_FILTER_ALL);
}

CUDBGResult
haloStateCreateFunction(DeviceFunction *pFunc, DeviceModule mod, uint64_t gpuAddrBase,
                        bool usesCnp, bool usesContinuations)
{
    DeviceFunction func = NULL;

    CUDBG_VERIFY(pFunc, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_VERIFY(mod, CUDBG_ERROR_INVALID_MODULE, "Invalid module.\n");

    func = (DeviceFunction)calloc(1, sizeof *func);

    CUDBG_VERIFY(func, CUDBG_ERROR_UNKNOWN_FUNCTION, "Unknown function.\n");

    func->module = mod;
    func->gpuAddrBase = gpuAddrBase;
    func->usesCnp = usesCnp;
    func->usesContinuations = usesContinuations;

    *pFunc = func;

    func->grids = toolsHashMapNew(toolsUint32HashFun, toolsUint64EqualFun, 65);

    return CUDBG_SUCCESS;
}

void
haloStateDestroyFunction(DeviceFunction func)
{
    if (!func)
        return;

    if (func->texIdMap) {
        free(func->texIdMap);
        func->texIdMap = NULL;
    }
    if (func->grids) {
        removeAllGrids(func->grids);
        func->grids = NULL;
    }

    free(func);
}

CUDBGResult
haloStateCreateModule(DeviceModule *pMod, Context ctx, uint64_t cuMod, uint32_t abiVersion)
{
    DeviceModule mod = NULL;

    CUDBG_VERIFY(pMod, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context.\n");

    mod = (DeviceModule)calloc(1, sizeof *mod);

    CUDBG_VERIFY(mod, CUDBG_ERROR_INTERNAL, "calloc failed.\n");

    mod->context = ctx;
    mod->cuModule = cuMod;
    mod->abiVersion = abiVersion;

    *pMod = mod;

    return CUDBG_SUCCESS;
}

Grid
haloStateDeviceGetGrid(CudbgDevice dev, uint64_t gridId64)
{
    return (Grid)toolsHashMapFind(dev->gridIdToGrid, tHashMapNumToKey(gridId64));
}

Grid
haloStateDeviceGetAnyGrid(CudbgDevice dev)
{
    return (Grid)toolsHashMapGetAnyEntry(dev->gridIdToGrid);
}

uint64_t
haloStateDeviceGetNumGrids(CudbgDevice dev)
{
    return toolsHashMapSize(dev->gridIdToGrid);
}

uint64_t
haloStateFunctionGetNumGrids(DeviceFunction function)
{
    return toolsHashMapSize(function->grids);
}

void
haloStateDestroyModule(DeviceModule mod)
{
    if (mod)
        free(mod);
}

void
haloStateDeviceCreateMaps(CudbgDevice dev)
{
    dev->contexts = toolsHashMapNew(toolsPointerHashFun, toolsPointerEqualFun, 16);
    dev->gridIdToGrid = toolsHashMapNew(toolsUint32HashFun, toolsUint64EqualFun, 65);
}

void
haloStateDeviceDestroyMaps(CudbgDevice dev)
{
    toolsHashMapDelete(dev->contexts, NULL, NULL);
    dev->contexts = NULL;

    toolsHashMapDelete(dev->gridIdToGrid, NULL, NULL);
    dev->gridIdToGrid = NULL;
}

bool
haloStateSwCacheEnabled(void)
{
    return !!(haloGlobals.initData.flags & HALO_INIT_FLAGS_ENABLE_SCRATCHPAD_CACHE);
}

CUDBGResult
haloStateGetTimeoutMsec(CudbgDevice dev, uint32_t *timeout)
{
    const CUdev* pDev;
    bool usingSimulation;

    CUDBG_VERIFY(dev && timeout, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");
    CUDBG_VERIFY(dev->deviceIdx < CUDBG_MAX_DEVICES, CUDBG_ERROR_INVALID_DEVICE, "Invalid device.\n");
    pDev = globals.devices[dev->deviceIdx];

    CUDBG_VERIFY(pDev, CUDBG_ERROR_INTERNAL, "Invalid device.\n");
    usingSimulation = pDev->state.simulationType != CUI_SIMULATION_TYPE_NONE;

    *timeout = usingSimulation ? CUDBG_SIMULATION_TIMEOUT_MSEC : CUDBG_TIMEOUT_MSEC;

    return CUDBG_SUCCESS;
}
