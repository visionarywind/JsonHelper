/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */


/******************************************************************************
 *
 *   Module: halo_memmap.c
 *
 *   Description:
 *       Memory tracker used by the HALO
 *
 ******************************************************************************/

#include <halo.h>
#include <halo_memmap.h>
#include <halo_client.h>
#include <halo_state.h>
#include <halo_internal.h>
#include <tools_shared_hashmap.h>
#include <tools_shared_rangemap.h>


struct haloMemoryMap_st {
    tHashMap *handleToSegmentMap;   // Map from hostHandle to haloMemorySegment
    tRangeMap *devVaddrMap; // Devvaddr to haloMemorySegment*
    tRangeMap *devPtrMap;     // DevicePtr to haloMemorySegment* (Used mainly for global mappings)
    tRangeMap *hostVAMap;   // Host VA to haloMemorySegment*

    /* Some special mappings exist */
    haloMemorySegment *stackMem;
    haloMemorySegment *localDefault;

    haloMemoryMap *parentMap;
    uint64_t memUseCurrentTime;
};

struct haloMemorySwCacheLine_st {
    void *memPtr;
    /*
     * True when the region has been modified through a write.
     * During a cache flush, this field is checked to flush only modified
     * segments.
     */
    bool dirty;
};

static void destroySwCacheLines(void*, void*);
static void destroyMemSeg(void*, void*);
static void removeMemSegFromGlobalHostVAMap(void *entry, void *user);

uint64_t
haloMemoryMapGetMemUseCurrentTime(haloMemoryMap *map)
{
    return map->memUseCurrentTime;
}

void
haloMemoryMapSetMemUseCurrentTime(haloMemoryMap *map, uint64_t memUseCurrentTime)
{
    map->memUseCurrentTime = memUseCurrentTime;
}

haloMemoryMap*
haloMemoryMapGetParentMemMap(haloMemoryMap *map)
{
    return map->parentMap;
}

CUDBGResult
haloMemoryMapCreate(haloMemoryMap **pMap, haloMemoryMap *parentMap)
{
    CUDBGResult res = CUDBG_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;
    haloMemoryMap *map = NULL;

    CUDBG_VERIFY(pMap, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    map = (haloMemoryMap *)calloc(1, sizeof(*map));
    if (!map) {
        res = CUDBG_ERROR_INTERNAL;
        goto error;
    }

    map->handleToSegmentMap = toolsHashMapNew(toolsUint32HashFun, toolsUint64EqualFun, 32);
    if (!map->handleToSegmentMap) {
        res = CUDBG_ERROR_INTERNAL;
        goto error;
    }

    tres = toolsRangeMapCreate(&map->devVaddrMap);
    if (tres != TOOLS_SUCCESS) {
        HALO_ERROR("Failed to create devVaddrMap. (Tres=%u)\n", tres);
        res = CUDBG_ERROR_UNKNOWN;
        goto error;
    }

    tres = toolsRangeMapCreate(&map->devPtrMap);
    if (tres != TOOLS_SUCCESS) {
        HALO_ERROR("Failed to create devPtrMap. (Tres=%u)\n", tres);
        res = CUDBG_ERROR_UNKNOWN;
        goto error;
    }

    tres = toolsRangeMapCreate(&map->hostVAMap);
    if (tres != TOOLS_SUCCESS) {
        HALO_ERROR("Failed to create hostVAMap. (Tres=%u)\n", tres);
        res = CUDBG_ERROR_UNKNOWN;
        goto error;
    }

    *pMap = map;

    map->parentMap = parentMap;

    return CUDBG_SUCCESS;

error:
    (void)haloMemoryMapDestroy(map);
    return res;
}

uint32_t
haloMemorySegmentGetBlockType(haloMemorySegment *seg)
{
    return seg->blockType;
}

static void
removeMemSegFromGlobalHostVAMap(void *entry, void *user)
{
    haloMemorySegment *seg = (haloMemorySegment *)entry;
    /* Only segments that own the memblock will be in the global
     * hostVAMap. */
    if (seg->sourceMemblock == 0) {
        if (!toolsRangeMapRemoveByAddr(haloStateGetGlobalHostVAMap(),
                                       seg->hostvaddr)) {
            HALO_TRACE_FUNCTION(40, "Failed to remove segment from globalHostVAMap\n");
        }
    }
}

static inline bool
haloMemorySegmentInHostVAMap(haloMemorySegment *seg)
{
    /* Bug 1583616: For cudaHostRegister()'d buffers, the CUDA driver may create
     * multiple memblocks with overlapping ranges. Trying to insert such memblocks
     * into the hostVAMap will not work, since the map expects unique keys. To work
     * around such problems, we don't track host registered memblocks at all in the
     * hostVAMap. This is okay to do, since RM can't map host registered memblocks
     * anyway. */
    return (seg->hostvaddr && seg->apiSource != CU_MEM_API_HOST_REGISTER);
}

CUDBGResult
haloMemoryMapDestroy(haloMemoryMap *map)
{
    CUDBG_VERIFY(map, CUDBG_SUCCESS, "Null map. Nothing to do\n");

    if (map->hostVAMap) {
        /* Also remove segments from the globalVAMap */
        toolsRangeMapDestroy(&map->hostVAMap, removeMemSegFromGlobalHostVAMap, NULL);
        map->hostVAMap = NULL;
    }

    if (map->devPtrMap) {
        toolsRangeMapDestroy(&map->devPtrMap, NULL, NULL);
        map->devPtrMap = NULL;
    }

    if (map->devVaddrMap) {
        toolsRangeMapDestroy(&map->devVaddrMap, NULL, NULL);
        map->devVaddrMap = NULL;
    }

    if (map->handleToSegmentMap) {
        (void)toolsHashMapDelete(map->handleToSegmentMap, destroyMemSeg,  NULL);
        map->handleToSegmentMap = NULL;
    }

    free(map);
    map = NULL;

    return CUDBG_SUCCESS;
}

CUDBGResult
haloMemoryMapAddSegment(haloMemoryMap *map,
                        uint64_t hosthandle,
                        uint64_t sourceMemblock,
                        haloMemorySegmentType type,
                        uint64_t devvaddr,
                        uint64_t uvavaddr,
                        uint64_t size,
                        uint32_t handle,
                        uint32_t client,
                        uint32_t sourceDeviceIdx,
                        uint32_t blockType,
                        uint32_t apiSource,
                        uint32_t location,
                        uint32_t owner,
                        uint32_t sharing,
                        uint32_t userOwnsData,
                        uint32_t usesNvmap,
                        haloMemorySegment **pSegment)
{
    haloMemorySegment *seg = NULL;
    CUDBGResult res = CUDBG_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;
    uint32_t rangeClear = 0;

    CUDBG_VERIFY(map, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    if (pSegment)
        *pSegment = NULL;

    rangeClear = toolsRangeMapIsRangeClear(map->devVaddrMap, devvaddr, size);

    /* If the lookup found a segment, return an error */
    CUDBG_VERIFY(rangeClear, CUDBG_ERROR_INVALID_MEMORY_SEGMENT,
                 "Found a segment already present at [0x%" PRIx64 ", 0x%" PRIx64 "]\n",
                 devvaddr, devvaddr + size - 1);

    seg = (haloMemorySegment*)calloc(1, sizeof(*seg));
    CUDBG_VERIFY(seg, CUDBG_ERROR_INTERNAL, "Failed to create segment\n");

    seg->devvaddr   = devvaddr;
    seg->uvavaddr   = uvavaddr;
    seg->type       = type;
    seg->size       = size;

    seg->mem        = handle;
    seg->client     = client;
    seg->sourceDeviceIdx = sourceDeviceIdx;

    seg->hosthandle     = hosthandle;
    seg->sourceMemblock = sourceMemblock;

    seg->blockType    = blockType;
    seg->apiSource    = apiSource;
    seg->location     = location;
    seg->owner        = owner;
    seg->sharing      = sharing;
    seg->userOwnsData = userOwnsData;
    seg->usesNvmap    = usesNvmap;

    /* Add into maps */
    tres = toolsHashMapInsert(map->handleToSegmentMap,
                              tHashMapNumToKey(seg->hosthandle),
                              (void*)seg);
    CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_INTERNAL,
                 "Failed to insert into segment map (tres=%u)\n", tres);

    tres = toolsRangeMapInsertByRange(map->devVaddrMap,
                                      seg->devvaddr,
                                      seg->size,
                                      (void*) seg);
    CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_INTERNAL,
                 "Failed to insert into devVaddr map (tres=%u)\n", tres);

    res = haloMemorySegmentModifyType(map, seg, type);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to update type data\n");

    if (pSegment)
        *pSegment = seg;

    return CUDBG_SUCCESS;
}

static void
destroySwCacheLines(void *entry, void *user)
{
    if (!entry)
    {
        HALO_ERROR("destroySwCacheLines called with a NULL pointer.\n");
        return;
    }

    haloMemorySwCacheLine *swCacheLine = (haloMemorySwCacheLine *)entry;
    free(swCacheLine->memPtr);
    free(swCacheLine);
}

static void
destroyMemSeg(void *entry, void *user)
{
    haloMemorySegment *seg = (haloMemorySegment *)entry;
    CudbgDevice dev = haloGlobals.device[seg->sourceDeviceIdx];
    CUDBGResult res = CUDBG_SUCCESS;

    if (!(haloGlobals.initData.flags & HALO_INIT_FLAGS_IN_PROCESS)) {
#if !cuiOsIsWindows()
        if (dev && dev->dmal->type == HALO_DMAL_TYPE_MRM) {
            if (seg->usesNvmap) {
                res = dev->dmal->destroyHandleForMemorySegment(dev, seg->mem);
                if (res != CUDBG_SUCCESS)
                    HALO_ERROR("Could not destroy handle for memory segment %#" PRIx64 ", ignoring...\n", seg->devvaddr);
            }
#if !cuosOsIsHos()       // No close on HOS
            else
                close(seg->mem);
#endif
        }
#endif
    }

    toolsRangeMapDestroy(&seg->cache.swCacheLines, destroySwCacheLines, NULL);
    free(seg);
}

CUDBGResult
haloMemoryMapRemoveSegment(haloMemoryMap *map, uint64_t devvaddr)
{
    haloMemorySegment *seg = NULL;
    CUDBGResult res = CUDBG_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;

    CUDBG_VERIFY(map, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    res = haloMemoryMapGetSegmentByDevVaddr(map, devvaddr, &seg);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Error when searching for segment at 0x%" PRIx64 ". Res=%u\n", devvaddr, res);

    CUDBG_VERIFY(seg, CUDBG_ERROR_INVALID_MEMORY_SEGMENT,
                 "Failed to find segment at 0x%" PRIx64 "\n", devvaddr);

    if (!toolsRangeMapRemoveByAddr(map->devVaddrMap, seg->devvaddr)) {
        HALO_ERROR("Failed to remove segment from vaddr map\n");
        return CUDBG_ERROR_INTERNAL;
    }

    if (seg->hasDevPtr) {
        if (!toolsRangeMapRemoveByAddr(map->devPtrMap, seg->devptr)) {
            HALO_ERROR("Failed to remove segment from devPtrMap\n");
            return CUDBG_ERROR_INTERNAL;
        }
    }

    if (haloMemorySegmentInHostVAMap(seg)) {
        if (!toolsRangeMapRemoveByAddr(map->hostVAMap, seg->hostvaddr)) {
            HALO_ERROR("Failed to remove segment from hostVAMap\n");
            return CUDBG_ERROR_INTERNAL;
        }

        if (seg->sourceMemblock == 0)
            if (!toolsRangeMapRemoveByAddr(haloStateGetGlobalHostVAMap(),
                                           seg->hostvaddr)) {
                HALO_ERROR("Failed to remove segment from globalHostVAMap\n");
                return CUDBG_ERROR_INTERNAL;
            }
    }

    tres = toolsHashMapRemove(map->handleToSegmentMap, tHashMapNumToKey(seg->hosthandle), NULL);
    CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_INTERNAL,
                 "Failed to remove segment from segment map (tres=%u)\n", tres);

    if (seg == map->stackMem)
        map->stackMem = NULL;

    if (seg == map->localDefault)
        map->localDefault = NULL;

    destroyMemSeg(seg, NULL);

    return CUDBG_SUCCESS;
}

CUDBGResult
haloMemoryMapGetSegmentByDevVaddrInMap(haloMemoryMap *map, uint64_t devvaddr, haloMemorySegment **pSegment)
{
    haloMemorySegment *seg = NULL;

    CUDBG_VERIFY((map && map->devVaddrMap), CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    if (pSegment)
        *pSegment = NULL;

    seg = (haloMemorySegment *)toolsRangeMapLookupByAddr(map->devVaddrMap, devvaddr);

    if (!seg) {
        HALO_TRACE(50, "Failed to find any segment at 0x%" PRIx64 "\n", devvaddr);
        return CUDBG_SUCCESS;
    }

    if (pSegment)
        *pSegment = seg;

    return CUDBG_SUCCESS;
}

CUDBGResult
haloMemoryMapGetSegmentByDevVaddr(haloMemoryMap *map, uint64_t devvaddr, haloMemorySegment **pSegment)
{
    haloMemorySegment *seg = NULL;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY((map && map->devVaddrMap), CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    if (pSegment)
        *pSegment = NULL;

    res = haloMemoryMapGetSegmentByDevVaddrInMap(map, devvaddr, &seg);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Error in looking up segment for devVA:0x%" PRIx64 " in context map\n",
                 devvaddr);

    /* Try looking in the parentMap if one exists */
    if (!seg && map->parentMap) {
        res = haloMemoryMapGetSegmentByDevVaddrInMap(map->parentMap, devvaddr, &seg);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Error in looking up segment for devVA:0x%" PRIx64 " in parent map\n",
                     devvaddr);
        if (!seg) {
            HALO_TRACE(50, "Failed to find any segment in globalMemMap at 0x%" PRIx64 "\n", devvaddr);
            return CUDBG_SUCCESS;
        }
    }

    if (pSegment)
        *pSegment = seg;

    return CUDBG_SUCCESS;
}

CUDBGResult
haloMemoryMapGetSegmentByDevPtr(haloMemoryMap *map, uint64_t devPtr, haloMemorySegment **pSegment)
{
    haloMemorySegment *seg = NULL;

    CUDBG_VERIFY((map && map->devPtrMap), CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    if (pSegment)
        *pSegment = NULL;

    seg = (haloMemorySegment *)toolsRangeMapLookupByAddr(map->devPtrMap, devPtr);

    /* Try looking in the parentMap if one exists */
    if (!seg && map->parentMap && map->parentMap->devPtrMap) {
        seg = (haloMemorySegment *)toolsRangeMapLookupByAddr(map->parentMap->devPtrMap, devPtr);
        if (!seg) {
            HALO_TRACE(50, "Failed to find any segment in globalMemMap at 0x%" PRIx64 "\n", devPtr);
            return CUDBG_SUCCESS;
        }
    }

    if (!seg) {
        HALO_TRACE(30, "Failed to find any segment at 0x%" PRIx64 "\n", devPtr);
        return CUDBG_SUCCESS;
    }

    if (pSegment)
        *pSegment = seg;

    return CUDBG_SUCCESS;
}

CUDBGResult
haloMemoryMapGetSegmentByHostVA(haloMemoryMap *map, uint64_t hostVA, haloMemorySegment **pSegment)
{
    haloMemorySegment *seg = NULL;

    CUDBG_VERIFY((map && map->hostVAMap), CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    if (pSegment)
        *pSegment = NULL;

    seg = (haloMemorySegment *)toolsRangeMapLookupByAddr(map->hostVAMap, hostVA);

    /* Try looking in the parentMap if one exists */
    if (!seg && map->parentMap && map->parentMap->hostVAMap) {
        seg = (haloMemorySegment *)toolsRangeMapLookupByAddr(map->parentMap->hostVAMap, hostVA);
        if (!seg) {
            HALO_TRACE(50, "Failed to find any segment in globalMemMap at 0x%" PRIx64 "\n", hostVA);
            return CUDBG_SUCCESS;
        }
    }

    if (!seg) {
        HALO_TRACE(30, "Failed to find any segment at 0x%" PRIx64 "\n", hostVA);
        return CUDBG_SUCCESS;
    }

    if (pSegment)
        *pSegment = seg;

    return CUDBG_SUCCESS;
}

typedef struct haloMemMapFunctorData_st haloMemMapFunctorData;

struct haloMemMapFunctorData_st {
    haloMemoryMapFunctor fn;
    void *user;
    CUDBGResult res;
    haloMemoryMap *map;
};

static TOOLSresult
haloMemMapFunctorWrap(tHashMapKey_t key, void *entry, void *user)
{
    haloMemMapFunctorData *data = (haloMemMapFunctorData*)user;
    haloMemorySegment *seg = (haloMemorySegment*)entry;

    CUDBG_VERIFY((seg && data), TOOLS_ERROR_INVALID_VALUE, "Invalid args\n");

    if (data->fn) {
        data->res = data->fn(data->map, seg, data->user);
        CUDBG_VERIFY(data->res == CUDBG_SUCCESS, TOOLS_ERROR_UNKNOWN, "Failed in haloMemMapFunctor\n");
    }

    return TOOLS_SUCCESS;
}

CUDBGResult
haloMemoryMapApplyFunctor(haloMemoryMap *map, haloMemoryMapFunctor fn, void *userData)
{
    CUDBGResult res = CUDBG_SUCCESS;
    haloMemMapFunctorData data = {0};
    TOOLSresult tres = TOOLS_SUCCESS;

    CUDBG_VERIFY((map && fn), CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    data.res  = CUDBG_SUCCESS;
    data.fn   = fn;
    data.user = userData;
    data.map  = map;

    tres = toolsHashMapApplyFunctor(map->handleToSegmentMap, haloMemMapFunctorWrap, &data);
    if (tres != TOOLS_SUCCESS) {
        res = (data.res == CUDBG_SUCCESS) ? CUDBG_ERROR_UNKNOWN : data.res;
        HALO_ERROR("Failed when applying functor. Tres=%u. Returning=%u\n", tres, res);
        return res;
    }

    return data.res;
}

CUDBGResult
haloMemoryMapTranslateToDevVaddr(haloMemoryMap *map, haloMemorySegmentType type, uint64_t addr, uint64_t *pDevvaddr)
{
    haloMemorySegment *seg = NULL;
    CUDBGResult res;

    CUDBG_VERIFY((map && pDevvaddr), CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    *pDevvaddr = ~0;

    if (type == HALO_MEM_SEG_GLOBAL) {
        res = haloMemoryMapGetSegmentByDevPtr(map, addr, &seg);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to get seg by devptr at 0x%" PRIx64 "\n", addr);
        CUDBG_VERIFY(seg, CUDBG_ERROR_INVALID_MEMORY_SEGMENT,
                     "Failed to find seg for global memory devptr at 0x%" PRIx64 "\n", addr);

        *pDevvaddr = (addr - seg->devptr) + seg->devvaddr;
        return CUDBG_SUCCESS;
    }
    else if (type == HALO_MEM_SEG_MANAGED ||
             type == HALO_MEM_SEG_DEVICE_VIRTUAL ||
             type == HALO_MEM_SEG_FUNC ||
             type == HALO_MEM_SEG_LOCAL_NONDEFAULT) {
        res = haloMemoryMapGetSegmentByDevVaddr(map, addr, &seg);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to find seg for virtual type %u at 0x%" PRIx64 "\n", type, addr);
        CUDBG_VERIFY(seg, CUDBG_ERROR_INVALID_MEMORY_SEGMENT,
                     "Failed to find seg for virtual type %u at 0x%" PRIx64 "\n", type, addr);

        *pDevvaddr = addr;
        return CUDBG_SUCCESS;
    }
    else if (type == HALO_MEM_SEG_PINNED_SYSMEM) {
        res = haloMemoryMapGetSegmentByHostVA(map, addr, &seg);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to find seg for host VA at 0x%" PRIx64 "\n", addr);
        if (!seg) {
            /* This is not fatal as the frontend will fallback to ptrace if there
               is an error. Presumably, once ptrace is fixed up to allow host
               accesses, this can be turned back into CUDBG_VERIFY as the
               only callers are internal
            */
            HALO_TRACE(50, "Failed to find seg for host VA at 0x%" PRIx64 "\n", addr);
            return CUDBG_ERROR_INVALID_MEMORY_SEGMENT;
        }

        *pDevvaddr = (addr - seg->hostvaddr) + seg->devvaddr;
        return CUDBG_SUCCESS;
    }
    else if (type == HALO_MEM_SEG_STACK) {
        CUDBG_VERIFY(map->stackMem, CUDBG_ERROR_INVALID_MEMORY_SEGMENT,
                     "Stack mem not registered\n");

        *pDevvaddr = map->stackMem->devvaddr;
        return CUDBG_SUCCESS;
    }
    else if (type == HALO_MEM_SEG_LOCAL_DEFAULT) {
        CUDBG_VERIFY(map->localDefault, CUDBG_ERROR_INVALID_MEMORY_SEGMENT,
                     "Default local mem not registered\n");

        *pDevvaddr = map->localDefault->devvaddr;
        return CUDBG_SUCCESS;
    }
    else {
        HALO_ERROR("Unknown type:%u\n", type);
        return CUDBG_ERROR_INVALID_MEMORY_SEGMENT;
    }

    return CUDBG_SUCCESS;
}

typedef struct maxAgeData_st maxAgeData;

struct maxAgeData_st {
    uint64_t maxAge;
    uint64_t currentTime;
};

static CUDBGResult
maxAgeFunctor(haloMemoryMap *map, haloMemorySegment *seg, void *data)
{
    maxAgeData *d = (maxAgeData *)data;

    CUDBG_VERIFY((map && seg && data), CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    if (seg->mappedHostPtr && (d->currentTime - seg->lastUsed > d->maxAge))
        d->maxAge = d->currentTime - seg->lastUsed;

    return CUDBG_SUCCESS;
}

CUDBGResult
haloMemoryMapGetMaxAge(haloMemoryMap *map, uint64_t currentTime, uint64_t *maxAge)
{
    CUDBGResult res = CUDBG_SUCCESS;
    maxAgeData data = {0};

    CUDBG_VERIFY((map && maxAge), CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    *maxAge = 0;

    data.maxAge = 0;
    data.currentTime = currentTime;

    res = haloMemoryMapApplyFunctor(map, maxAgeFunctor, maxAge);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Error in maxAgeFunctor\n");

    *maxAge = data.maxAge;
    return CUDBG_SUCCESS;
}

/* Segment functions */
CUDBGResult
haloMemorySegmentModifyDevPtr(haloMemoryMap *map, haloMemorySegment *seg,
                              uint32_t hasDevPtr, uint64_t devptr)
{
    TOOLSresult tres = TOOLS_SUCCESS;

    CUDBG_VERIFY((map && seg), CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    /* Segment is already in the map, if so remove it */
    if (seg->hasDevPtr) {
        if (!toolsRangeMapRemoveByAddr(map->devPtrMap, seg->devptr)) {
            HALO_ERROR("Failed to remove old dptr from map 0x%" PRIx64 " (tres=%u)\n",
                       seg->devptr, tres);
            return CUDBG_ERROR_INTERNAL;
        }
    }

    /* Update with the new properties */
    seg->hasDevPtr = hasDevPtr;
    seg->devptr    = devptr;

    /* Add into the devptr map */
    if (seg->hasDevPtr) {
        tres = toolsRangeMapInsertByRange(map->devPtrMap,
                                          seg->devptr,
                                          seg->size,
                                          (void*)seg);
        CUDBG_VERIFY(tres == TOOLS_SUCCESS,
                     CUDBG_ERROR_INTERNAL,
                     "Failed to insert into the devptr map at 0x%" PRIx64 " (tres=%u)\n",
                     seg->devptr, tres);
    }

    return CUDBG_SUCCESS;
}

CUDBGResult
haloMemorySegmentModifyHostVA(haloMemoryMap *map, haloMemorySegment *seg,
                              uint64_t hostvaddr)
{
    TOOLSresult tres = TOOLS_SUCCESS;

    CUDBG_VERIFY((map && seg), CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    /* Remove from hostVA map */
    if (haloMemorySegmentInHostVAMap(seg)) {
        if (!toolsRangeMapRemoveByAddr(map->hostVAMap, seg->hostvaddr)) {
            HALO_ERROR("Failed to remove old host vaddr from map 0x%" PRIx64 " (tres=%u)\n",
                       seg->hostvaddr, tres);
            return CUDBG_ERROR_INTERNAL;
        }

        if (seg->sourceMemblock == 0)
            if (!toolsRangeMapRemoveByAddr(haloStateGetGlobalHostVAMap(),
                                           seg->hostvaddr)) {
                HALO_ERROR("Failed to remove segment from globalHostVAMap\n");
                return CUDBG_ERROR_INTERNAL;
            }
    }

    /* Update with new properties */
    seg->hostvaddr = hostvaddr;

    /* Add the new value into the map */
    if (haloMemorySegmentInHostVAMap(seg)) {
        tres = toolsRangeMapInsertByRange(map->hostVAMap,
                                          seg->hostvaddr,
                                          seg->size,
                                          (void*)seg);
        CUDBG_VERIFY(tres == TOOLS_SUCCESS,
                     CUDBG_ERROR_INTERNAL,
                     "Failed to insert into the hostVA map at 0x%" PRIx64 " (tres=%u)\n",
                     seg->hostvaddr, tres);

        if (seg->sourceMemblock == 0) {
            tres = toolsRangeMapInsertByRange(haloStateGetGlobalHostVAMap(),
                                              seg->hostvaddr,
                                              seg->size,
                                              (void*)seg);
            CUDBG_VERIFY(tres == TOOLS_SUCCESS,
                         CUDBG_ERROR_INTERNAL,
                         "Failed to insert into the globalHostVAMap at 0x%" PRIx64 " (tres=%u)\n",
                         seg->hostvaddr, tres);
        }
    }

    return CUDBG_SUCCESS;
}

CUDBGResult
haloMemorySegmentModifyType(haloMemoryMap *map, haloMemorySegment *seg, haloMemorySegmentType type)
{
    CUDBG_VERIFY((map && seg), CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    if (map->localDefault == seg)
        map->localDefault = NULL;

    if (map->stackMem == seg)
        map->stackMem = NULL;

    seg->type = type;

    if (seg->type == HALO_MEM_SEG_LOCAL_DEFAULT)
        map->localDefault = seg;
    else if (seg->type == HALO_MEM_SEG_STACK)
        map->stackMem = seg;

    return CUDBG_SUCCESS;
}

typedef struct {
    haloTraverseHostVAMapCb pfn;
    void *userData;
    CUDBGResult res;
} haloTraverseHostVAMapToken;

static TOOLSresult
traverseHostVAMap(uint64_t address, uint64_t size, void *entry, void* data)
{
    haloTraverseHostVAMapToken *token = (haloTraverseHostVAMapToken *)data;

    if (!token)
        return TOOLS_SUCCESS;

    /* Call the callback */
    if (token->pfn)
        token->res = token->pfn(address, size, entry, token->userData);

    CUDBG_VERIFY(token->res == CUDBG_SUCCESS, TOOLS_ERROR_UNKNOWN,
                 "Error detected in callback\n");

    return TOOLS_SUCCESS;
}

CUDBGResult
haloMemoryMapTraverseGlobalHostVAMap(haloTraverseHostVAMapCb pfn, void *userData)
{
    TOOLSresult tres;
    haloTraverseHostVAMapToken token = {0};

    token.pfn      = pfn;
    token.userData = userData;
    token.res      = CUDBG_SUCCESS;

    tres = toolsRangeMapApplyFunctor(haloStateGetGlobalHostVAMap(),
                                     traverseHostVAMap,
                                     &token);
    CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_INTERNAL,
                 "Error while traversing rangeMap\n");

    return token.res;
}

CUDBGResult
haloMemoryMapGetDptrRangeMap(haloMemoryMap *map, tRangeMap **dptrMap)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(map && dptrMap, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    *dptrMap = map->devPtrMap;

    return res;
}

static CUDBGResult
haloMemorySegmentCacheEnable(haloMemorySegment *seg)
{
    TOOLSresult tres = TOOLS_SUCCESS;

    CUDBG_VERIFY(seg, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments: seg=%p\n",
                 seg);

    if (seg->cache.enabled) {
        HALO_TRACE(100, "SW caching for devvaddr=0x%" PRIx64 " size=0x%"
                    PRIx64 " is already enabled.\n", seg->devvaddr, seg->size);
        return CUDBG_SUCCESS;
    }

    tres = toolsRangeMapCreate(&seg->cache.swCacheLines);
    CUDBG_VERIFY(tres == TOOLS_SUCCESS, CUDBG_ERROR_UNKNOWN,
                 "Failed to create SW cache lines for devvaddr=0x%" PRIx64
                 " size=0x%" PRIx64 " (tres=%u).\n", seg->devvaddr, seg->size,
                 tres);
    seg->cache.enabled = true;

    HALO_TRACE(20, "Enabled SW caching for devvaddr=0x%" PRIx64 " size=0x%"
                    PRIx64 ".\n", seg->devvaddr, seg->size);

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloMemorySegmentCacheDisable(haloMemorySegment *seg)
{
    CUDBG_VERIFY(seg, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments: seg=%p\n",
                 seg);

    if (!seg->cache.enabled) {
        HALO_TRACE(100, "SW caching for devvaddr=0x%" PRIx64 " size=0x%"
                    PRIx64 " is already disabled.\n", seg->devvaddr, seg->size);
        return CUDBG_SUCCESS;
    }

    seg->cache.enabled = false;
    toolsRangeMapDestroy(&seg->cache.swCacheLines, destroySwCacheLines, NULL);
    HALO_TRACE(20, "Disabled SW cache for devvaddr=0x%" PRIx64 " size=0x%"
                    PRIx64 ".\n", seg->devvaddr, seg->size);

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloMemorySegmentCacheFlush(haloMemorySegment *seg)
{
    tRangeMapItr *it = NULL;
    haloMemorySwCacheLine *swCacheLine = NULL;
    uint64_t swCacheLineAddr = 0;
    uint64_t swCacheLineSize = 0;
    CudbgDevice dev = NULL;
    Context ctx = NULL;
    CUDBGResult res;


    CUDBG_VERIFY(seg, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments: seg=%p\n",
                 seg);

    if (!seg->cache.enabled) {
        HALO_TRACE(100, "SW caching for devvaddr=0x%" PRIx64 " size=0x%"
                    PRIx64 " is disabled.\n", seg->devvaddr, seg->size);
        return CUDBG_SUCCESS;
    }

    it = toolsRangeMapGetIterator(seg->cache.swCacheLines);
    while (it) {
        swCacheLineAddr = toolsRangeMapGetAddr(it);
        swCacheLineSize = toolsRangeMapGetSize(it);
        swCacheLine = (haloMemorySwCacheLine *)toolsRangeMapGetEntry(it);
        it = toolsRangeMapGetNext(seg->cache.swCacheLines, it);

        if (!swCacheLine->dirty)
            continue;

        dev = haloGlobals.device[seg->sourceDeviceIdx];
        CUDBG_VERIFY(dev, CUDBG_ERROR_INTERNAL, "Invalid device.\n");
        ctx = dev->activeContext;
        CUDBG_VERIFY(ctx, CUDBG_ERROR_INTERNAL, "Invalid context.\n");
        res = dev->dmal->debugObjectAccessMemory(ctx, swCacheLineAddr,
                                                 swCacheLine->memPtr,
                                                 swCacheLineSize,
                                                 HALO_MEMORY_ACCESS_TYPE_WRITE);

        CUDBG_VERIFY(res == CUDBG_SUCCESS,
            CUDBG_ERROR_INTERNAL,
            "Failed to flush SW cache (cache line addr: %p).\n",

            swCacheLineAddr);
        swCacheLine->dirty = false;
    }

    HALO_TRACE(20, "Flushed SW cache for devvaddr=0x%" PRIx64 " size=0x%"
                    PRIx64 ".\n", seg->devvaddr, seg->size);

    return CUDBG_SUCCESS;
}

/*
 * Flush and then invalidate segment's cache.
 * This memory will be re-cached from GPU on the next read operation.
 */
static CUDBGResult
haloMemorySegmentCacheInvalidate(haloMemorySegment *seg)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(seg, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments: seg=%p\n",
                 seg);

    if (!seg->cache.enabled) {
        HALO_TRACE(100, "SW caching for devvaddr=0x%" PRIx64 " size=0x%"
                    PRIx64 " is disabled.\n", seg->devvaddr, seg->size);
        return CUDBG_SUCCESS;
    }

    res = haloMemorySegmentCacheFlush(seg);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to flush cache for"
                 "devvaddr=0x%" PRIx64 " size=0x%" PRIx64 ".\n", seg->devvaddr,
                 seg->size);

    /* Disable and re-enable to delete all cache line entries */
    res = haloMemorySegmentCacheDisable(seg);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to disable cache for "
                 "devvaddr=0x%" PRIx64 " size=0x%" PRIx64 ".\n", seg->devvaddr,
                 seg->size);
    res = haloMemorySegmentCacheEnable(seg);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to enable cache for "
                 "devvaddr=0x%" PRIx64 " size=0x%" PRIx64 ".\n", seg->devvaddr,
                 seg->size);

    HALO_TRACE(20, "Invalidated SW cache for devvaddr=0x%" PRIx64 " size=0x%"
                    PRIx64 ".\n", seg->devvaddr, seg->size);

    return CUDBG_SUCCESS;
}

/*
 * Apply cache op to all segment in a given memory map.
 * [devvaddr -> devvaddr + size] must be part of a single segment.
 */
CUDBGResult
haloMemoryRangeCacheOp(haloMemoryMap* map,
                       uint64_t devvaddr,
                       uint64_t size,
                       HaloMemorySegmentCacheOp cacheOp)
{
    CUDBGResult res = CUDBG_SUCCESS;
    haloMemorySegment *seg = NULL;

    CUDBG_VERIFY(map, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args for MemoryRangeCacheOp\n");

    res = haloMemoryMapGetSegmentByDevVaddr(map, devvaddr, &seg);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Error in getSegment at va:0x%"
                 PRIx64 " on mapping\n", devvaddr);

    if (!seg) {
        /* Not necessarily a failure. */
        HALO_TRACE(50, "Cannot find memory segment at va:0x%" PRIx64 "\n",
            devvaddr);
        return CUDBG_ERROR_INVALID_MEMORY_SEGMENT;
    }

    switch (cacheOp) {
    case HALO_MEM_SEG_CACHE_DISABLE:
        res = haloMemorySegmentCacheDisable(seg);
        break;

    case HALO_MEM_SEG_CACHE_ENABLE:
        res = haloMemorySegmentCacheEnable(seg);
        break;

    case HALO_MEM_SEG_CACHE_INVALIDATE:
        res = haloMemorySegmentCacheInvalidate(seg);
        break;

    case HALO_MEM_SEG_CACHE_FLUSH:
        res = haloMemorySegmentCacheFlush(seg);
        break;

    default:
        HALO_ERROR("Invalid cache op %d!\n", cacheOp);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return res;
}

/*
 * Apply cache op to all segment in a given memory map.
 */
CUDBGResult
haloMemoryMapCacheOp(haloMemoryMap* map, HaloMemorySegmentCacheOp cacheOp)
{
    CUDBGResult res = CUDBG_SUCCESS;
    haloMemorySegment *seg = NULL;
    tRangeMapItr *it = NULL;

    CUDBG_VERIFY(map, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args for MemoryRangeCacheOp\n");

    for(it = toolsRangeMapGetIterator(map->devVaddrMap); it; it = toolsRangeMapGetNext(seg->cache.swCacheLines, it)) {
        seg = (haloMemorySegment *)toolsRangeMapGetEntry(it);
        CUDBG_VERIFY(seg, CUDBG_ERROR_INTERNAL,
            "Cannot get segment data.\n");

        res = haloMemoryRangeCacheOp(map, seg->devvaddr, seg->size, cacheOp);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, CUDBG_ERROR_INTERNAL,
            "Cache op failed.\n");
    }

    return res;
}

CUDBGResult
haloMemoryReadSwCache(haloMemoryMap* map, uint64_t devvaddr, uint64_t sz,
                      void *buf)
{
    CUDBGResult res = CUDBG_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;
    tRangeMapItr *it = NULL;
    haloMemorySegment *seg = NULL;
    haloMemorySwCacheLine *swCacheLine = NULL;
    uint64_t swCacheLineAddr = 0;
    uint64_t swCacheLineSize = 0;
    uint64_t offset = 0;
    CudbgDevice dev = NULL;
    Context ctx = NULL;

    CUDBG_VERIFY(map, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments: map=%p.\n",
                 map);

    res = haloMemoryMapGetSegmentByDevVaddr(map, devvaddr, &seg);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE_FUNCTION(10, "Could not find segment for range: devvaddr="
                                 "%#" PRIx64 ":%#" PRIx64 "\n", devvaddr, sz);
        return res;
    }
    CUDBG_VERIFY(seg, CUDBG_ERROR_INTERNAL, "Invalid segment.\n");

    /* SW caching does not support memory regions over multiple segments */
    CUDBG_VERIFY(seg->devvaddr <= devvaddr && seg->devvaddr + seg->size >= devvaddr + sz,
                 CUDBG_ERROR_MISSING_DATA,
                 "Requested VA-range is part of multiple segments.\n");

    if (!seg->cache.enabled) {
        return CUDBG_ERROR_MISSING_DATA;
    }

    it = toolsRangeMapGetIteratorByRange(seg->cache.swCacheLines, devvaddr, sz);
    if (!it) {
        dev = haloGlobals.device[seg->sourceDeviceIdx];
        CUDBG_VERIFY(dev, CUDBG_ERROR_INTERNAL, "Invalid device.\n");

        ctx = dev->activeContext;
        if (!ctx)
        {
          HALO_TRACE(20, "Read SW cache without active context, returning cache miss for direct read.\n");
          return CUDBG_ERROR_MISSING_DATA;
        }

        /* Allocate the SW cache line and fetch the data */
        swCacheLine = (haloMemorySwCacheLine *)malloc(sizeof (haloMemorySwCacheLine));

        /* In case of OOM, fallback to direct access */
        CUDBG_VERIFY(swCacheLine, CUDBG_ERROR_MISSING_DATA,
            "Cannot allocate swCacheLine structure. "
            "Falling back to direct access.\n");

        swCacheLine->dirty = false;

        //TODO: split the segment into several cache lines ?
        swCacheLine->memPtr = malloc((size_t)seg->size);

        if (!swCacheLine->memPtr)
        {
          HALO_ERROR("Failed to allocate cache line memory size=0x%" PRIx64
              ". Falling back to direct access\n",
              seg->size);
          free(swCacheLine);

          /* In case of OOM, fallback to direct access */
          return CUDBG_ERROR_MISSING_DATA;
        }

        /* Try breaking it up into smaller pieces.
           If bar1Size is set, use bar1Size/4, otherwise 1MB */
        uint64_t src = seg->devvaddr;
        uint8_t *dst = (uint8_t *)swCacheLine->memPtr;
        uint64_t size = seg->size;
        uint64_t copyLimit = dev->bar1Size ? dev->bar1Size >> 2 : 1024*1024;

        while (size > 0) {
            uint64_t copySize = (size > copyLimit) ? copyLimit : size;

            // Fill cache line
            res = dev->dmal->debugObjectAccessMemory(ctx, src, (void *)dst, copySize, HALO_MEMORY_ACCESS_TYPE_READ);
            if (res != CUDBG_SUCCESS) {
                HALO_ERROR("Failed to read cache line [block] from addr=0x%" PRIx64 " size=0x%" PRIx64
                           ". Falling back to direct access\n", src, copySize);
                free(swCacheLine->memPtr);
                free(swCacheLine);

                /* In case of read/mapping error, fallback to direct access */
                return CUDBG_ERROR_MISSING_DATA;
            }

            size -= copySize;
            src += copySize;
            dst += copySize;
        }

        /* Insert the SW cache line in the segment cache */
        tres = toolsRangeMapInsertByRange(seg->cache.swCacheLines, seg->devvaddr,
                                          seg->size, swCacheLine);
        if (tres != TOOLS_SUCCESS) {
            destroySwCacheLines(swCacheLine, NULL);
            HALO_ERROR("Failed to insert the sw cache line in the cache.\n");
            return CUDBG_ERROR_INTERNAL;
        }

        it = toolsRangeMapGetIteratorByRange(seg->cache.swCacheLines, devvaddr, sz);
        CUDBG_VERIFY(it, CUDBG_ERROR_INTERNAL, "Map error\n");
    }

    if (buf) {
        swCacheLine = (haloMemorySwCacheLine *)toolsRangeMapGetEntry(it);
        swCacheLineAddr = toolsRangeMapGetAddr(it);
        swCacheLineSize = toolsRangeMapGetSize(it);

        offset = devvaddr - swCacheLineAddr;
        memcpy(buf, (char*)swCacheLine->memPtr + offset, (size_t)sz);
    }

    return CUDBG_SUCCESS;
}

CUDBGResult
haloMemoryWriteSwCache(haloMemoryMap* map, uint64_t devvaddr, uint64_t sz,
                      void *buf)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CUDBGResult read_res;
    tRangeMapItr *it = NULL;
    haloMemorySegment *seg = NULL;
    haloMemorySwCacheLine *swCacheLine = NULL;
    uint64_t swCacheLineAddr = 0;
    uint64_t swCacheLineSize = 0;
    uint64_t offset = 0;

    CUDBG_VERIFY(map && buf, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments: map=%p.\n",
                 map);

    res = haloMemoryMapGetSegmentByDevVaddr(map, devvaddr, &seg);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE_FUNCTION(10, "Could not find segment for range: devvaddr="
                                 "%#" PRIx64 ":%#" PRIx64 "\n", devvaddr, sz);
        return res;
    }
    CUDBG_VERIFY(seg, CUDBG_ERROR_INTERNAL, "Invalid segment.\n");

    /* SW caching does not support memory regions over multiple segments */
    CUDBG_VERIFY(seg->devvaddr <= devvaddr && seg->devvaddr + seg->size >= devvaddr + sz,
                 CUDBG_ERROR_MISSING_DATA,
                 "Requested VA-range is part of multiple segments.\n");

    if (!seg->cache.enabled) {
        return CUDBG_ERROR_MISSING_DATA;
    }

    it = toolsRangeMapGetIteratorByRange(seg->cache.swCacheLines, devvaddr, sz);
    if (!it) {
        /* Create and fill the cache line */
        read_res = haloMemoryReadSwCache(map, devvaddr, sz, NULL);

        /* Forward the direct access request */
        if (read_res == CUDBG_ERROR_MISSING_DATA)
          return read_res;

        it = toolsRangeMapGetIteratorByRange(seg->cache.swCacheLines, devvaddr, sz);
        CUDBG_VERIFY(it, CUDBG_ERROR_INTERNAL, "Cannot get cache line for %p\n", devvaddr);
    }

    // Get cache line infos
    swCacheLine = (haloMemorySwCacheLine *)toolsRangeMapGetEntry(it);
    swCacheLineAddr = toolsRangeMapGetAddr(it);
    swCacheLineSize = toolsRangeMapGetSize(it);

    // Copy the data
    offset = devvaddr - swCacheLineAddr;
    memcpy((char*)swCacheLine->memPtr + offset, buf, (size_t)sz);

    swCacheLine->dirty = true;

    return CUDBG_SUCCESS;
}

CUDBGResult haloMemoryGetDevVaddrRangeMap(haloMemoryMap* map, tRangeMap **pRangeMap)
{
    CUDBGResult res = CUDBG_SUCCESS;
    *pRangeMap = NULL;

    CUDBG_VERIFY(map, CUDBG_ERROR_INTERNAL, "Invalid map specified\n");
    if (!map->devVaddrMap)
    {
        return CUDBG_ERROR_INTERNAL;
    }

    *pRangeMap = map->devVaddrMap;
    return res;
}
