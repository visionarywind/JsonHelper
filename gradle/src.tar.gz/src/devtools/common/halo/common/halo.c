/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: halo.c
 *
 *   Description:
 *       Determines all device types and performs proper initialization.
 *       Also contains common functionality (Memory mapping, RM calls, etc.)
 *
 ******************************************************************************/

#include "halo.h"
#include "halo_internal.h"
#include "halo_client.h"
#include "halo_dmal.h"
#include "halo_drv.h"
#include "kdapi.h"
#include "fermi.h"
#include "kepler.h"
#include "maxwell.h"
#include "pascal.h"
#include "volta.h"
#include "turing.h"
#include "ampere.h"
#include "rm_device.h"
#include "rm_call.h"
#include "Nvcm.h"
#if cuosOsIsLinux() || cuosOsIsApple() /* CUDA & CLH */
# include <sys/mman.h>
#endif
#include "nvRmApi.h"
#include "class/cl003f.h"
#include "ctrl/ctrl2080.h"
#include "halo_state.h"
#include "memcheck_report.h"

#include "cudbgdriver.h"

#define CUDA_DEVTOOLS_ENABLE_STATS
#include "halo_timing.h"

/* Used for finding a resident context on a device */
typedef struct {
    CudbgDevice dev;
    Context residentContext;
} ContextFunctor;

static uint32_t haloGlobalsDevicesCreated = 0;

HaloGlobals haloGlobals;

static CUDBGResult haloDeviceFinalize(CudbgDevice dev);


CUDBGResult
haloSetRmDebugMode(CudbgDevice dev, bool on)
{
    if (haloStateContextIsActive(dev->activeContext))
        dev->halo.contextCommonDataCacheOp(dev->activeContext, HALO_MEM_SEG_CACHE_INVALIDATE);

    return dev->dmal->setRMDebugMode(dev, on);
}

static CUDBGResult
haloReadLocalMemoryCacheAware(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                              uint64_t offset, void *buf, uint32_t bufSz,
                              HaloCacheFlushFlags cacheFlushFlags)
{
    uint8_t *dst = (uint8_t *) buf;
    uint32_t addr = (uint32_t) offset;
    Context context;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(((uint64_t) addr == offset),
                 CUDBG_ERROR_INVALID_MEMORY_ACCESS,
                 "Invalid memory access in haloReadLocalMemory.\n");

    CUDBG_VERIFY((dev->activeContext && dev->activeContext->memMapActive),
                 CUDBG_ERROR_MEMORY_MAPPING_FAILED,
                 "Memory mapping failed in haloReadLocalMemory.\n");

    context = dev->activeContext;

    /* If we've preempted (on architectures that support it), we must first
       check if lmemBase has been remapped.  If it hasn't, then we need
       to dig it out from the cta context and cache it for the remaining
       lifetime of this warp. */
    if (dev->preemptState == CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_PREEMPTED_FOR_DEVICE_EVENT &&
        dev->smState[vsm].warp[wp].lmemSegType == HALO_MEM_SEG_LOCAL_DEFAULT) {
        res = dev->halo.setLmemBaseCtaCtx(dev, vsm, wp);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to set lmemBase from cta ctx (res=%d)\n", res);
            return res;
        }
    }

    /* We have to copy atmost a word at a time :-( */
    while (bufSz) {
        uint32_t residualSize;
        uint32_t offset_32;
        uint64_t lOffset;
        uint64_t lmemBase;

        res = dev->halo.getLmemInternalOffset(dev, addr, vsm, wp, ln, &offset_32);
        if (res != CUDBG_SUCCESS)
            return res;
        lOffset = offset_32;

        /* Check for out-of-bounds access to local memory */
        CUDBG_VERIFY((lOffset <= dev->smState[vsm].warp[wp].lmemSeg->size),
                     CUDBG_ERROR_INVALID_MEMORY_ACCESS,
                     "offset %016" PRIx64 " out of range [0; %016" PRIx64 "]\n",
                     lOffset, dev->smState[vsm].warp[wp].lmemSeg->size);

        lmemBase = dev->smState[vsm].warp[wp].lmemSeg->devvaddr;
        if (dev->smState[vsm].warp[wp].lmemSegType == HALO_MEM_SEG_LOCAL_DEFAULT)
            lmemBase = context->defaultLmemDevVA;

        residualSize = 4 - addr % 4;
        if (bufSz < residualSize)
            residualSize = bufSz;

        if (!!(cacheFlushFlags & HALO_CACHE_FLUSH_FLAGS_GPU)) {
            res = dev->dmal->flushGpuWrites(dev);
            if (res != CUDBG_SUCCESS) {
                HALO_ERROR("Failed to flush GPU in haloReadLocalMemory."
                           "CtxBase:0x%" PRIx64 " warpBase:0x%" PRIx64 " lmemBase:0x%" PRIx64 "\n",
                           context->defaultLmemDevVA,
                           dev->smState[vsm].warp[wp].lmemBase,
                           dev->smState[vsm].warp[wp].lmemSeg->devvaddr);
                return res;
            }
        }

        if (!!(cacheFlushFlags & HALO_CACHE_FLUSH_FLAGS_CPU)) {
            res = dev->dmal->flushCpuMappingForDevvaddr(context,
                                                        lmemBase + lOffset, residualSize,
                                                        HALO_CACHE_FLUSH_INVALIDATE);
            if (res != CUDBG_SUCCESS) {
                HALO_ERROR("Failed to flush CPU in haloReadLocalMemory."
                           "CtxBase:0x%" PRIx64 " warpBase:0x%" PRIx64 " lmemBase:0x%" PRIx64 "\n",
                           context->defaultLmemDevVA,
                           dev->smState[vsm].warp[wp].lmemBase,
                           dev->smState[vsm].warp[wp].lmemSeg->devvaddr);
                return res;
            }
        }


        res = dev->halo.readDeviceMemory(context, lmemBase + lOffset, dst, residualSize);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to readDeviceMemory failed in haloReadLocalMemory."
                       "CtxBase:0x%" PRIx64 " warpBase:0x%" PRIx64 " lmemBase:0x%" PRIx64 "\n",
                       context->defaultLmemDevVA,
                       dev->smState[vsm].warp[wp].lmemBase,
                       dev->smState[vsm].warp[wp].lmemSeg->devvaddr);
            return res;
        }

        addr    += residualSize;
        dst     += residualSize;
        bufSz   -= residualSize;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloReadLocalMemoryForAllLanes(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                               uint64_t offset, void *buf, uint32_t bufSz,
                               HaloCacheFlushFlags cacheFlushFlags)
{
    uint32_t addr = (uint32_t) offset;
    Context context;
    uint32_t offset_32;
    uint64_t lOffset;
    uint64_t lmemBase;
    CUDBGResult res = CUDBG_SUCCESS;
    HaloLmemConfig_t *warpLmem = &dev->smState[vsm].warp[wp].lmemConfig;

    CUDBG_VERIFY(((uint64_t) addr == offset),
                 CUDBG_ERROR_INVALID_MEMORY_ACCESS,
                 "Invalid memory access in haloReadLocalMemoryAllLanes.\n");

    CUDBG_VERIFY((dev->activeContext && dev->activeContext->memMapActive),
                 CUDBG_ERROR_MEMORY_MAPPING_FAILED,
                 "Memory mapping failed in haloReadLocalMemoryAllLanes.\n");

    context = dev->activeContext;

    /* If we've preempted (on architectures that support it), we must first
       check if lmemBase has been remapped.  If it hasn't, then we need
       to dig it out from the cta context and cache it for the remaining
       lifetime of this warp. */
    if (dev->preemptState == CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_PREEMPTED_FOR_DEVICE_EVENT &&
        dev->smState[vsm].warp[wp].lmemSegType == HALO_MEM_SEG_LOCAL_DEFAULT) {
        res = dev->halo.setLmemBaseCtaCtx(dev, vsm, wp);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to set lmemBase from cta ctx (res=%d)\n", res);
            return res;
        }
    }

    /* The following code assumes that the requested bytes is isolated to either
       lmemLo or lmemHi. Although it is simple to update the code to handle both
       regions but return an error for now as I don't see the requirement to
       handle this case */
    if (offset < warpLmem->lmemHiOff) {
        // The start is requested in lmemLo
        if (bufSz >= warpLmem->lmemHiOff) {
            // The end is from lmemHi
            HALO_ERROR("Reading lmem from both hi and lo regions is unsupported\n");
            return CUDBG_ERROR_INTERNAL;
        }
    }

    /* Check if requested bytes read is multiple of a word for each lane. Return
       an error otherwise. This can be updated if there is a requirement */
    if ((bufSz / 32) % 4) {
        HALO_ERROR("Requested lmem read size not multiple of word size\n");
        return CUDBG_ERROR_INTERNAL;
    }

    res = dev->halo.getLmemInternalOffset(dev, addr, vsm, wp, 0, &offset_32);
    if (res != CUDBG_SUCCESS)
        return res;
    lOffset = offset_32;

    /* Check for out-of-bounds access to local memory */
    CUDBG_VERIFY((lOffset <= dev->smState[vsm].warp[wp].lmemSeg->size),
                 CUDBG_ERROR_INVALID_MEMORY_ACCESS,
                 "offset %016" PRIx64 " out of range [0; %016" PRIx64 "]\n",
                 lOffset, dev->smState[vsm].warp[wp].lmemSeg->size);

    lmemBase = dev->smState[vsm].warp[wp].lmemSeg->devvaddr;
    if (dev->smState[vsm].warp[wp].lmemSegType == HALO_MEM_SEG_LOCAL_DEFAULT)
        lmemBase = context->defaultLmemDevVA;

    if (!!(cacheFlushFlags & HALO_CACHE_FLUSH_FLAGS_GPU)) {
        res = dev->dmal->flushGpuWrites(dev);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to flush GPU in haloReadLocalMemory."
                       "CtxBase:0x%" PRIx64 " warpBase:0x%" PRIx64 " lmemBase:0x%" PRIx64 "\n",
                       context->defaultLmemDevVA,
                       dev->smState[vsm].warp[wp].lmemBase,
                       dev->smState[vsm].warp[wp].lmemSeg->devvaddr);
            return res;
        }
    }

    if (!!(cacheFlushFlags & HALO_CACHE_FLUSH_FLAGS_CPU)) {
        res = dev->dmal->flushCpuMappingForDevvaddr(context,
                                                    lmemBase + lOffset, bufSz,
                                                    HALO_CACHE_FLUSH_INVALIDATE);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to flush CPU in haloReadLocalMemory."
                       "CtxBase:0x%" PRIx64 " warpBase:0x%" PRIx64 " lmemBase:0x%" PRIx64 "\n",
                       context->defaultLmemDevVA,
                       dev->smState[vsm].warp[wp].lmemBase,
                       dev->smState[vsm].warp[wp].lmemSeg->devvaddr);
            return res;
        }
    }


    res = dev->halo.readDeviceMemory(context, lmemBase + lOffset, buf, bufSz);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to readDeviceMemory failed in haloReadLocalMemory."
                   "CtxBase:0x%" PRIx64 " warpBase:0x%" PRIx64 " lmemBase:0x%" PRIx64 "\n",
                   context->defaultLmemDevVA,
                   dev->smState[vsm].warp[wp].lmemBase,
                   dev->smState[vsm].warp[wp].lmemSeg->devvaddr);
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloReadLocalMemory(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                    uint64_t offset, void *buf, uint32_t bufSz)
{
    if (ln == HALO_LOCAL_MEMORY_ACCESS_FOR_ALL_LANES) {
        return haloReadLocalMemoryForAllLanes(dev, vsm, wp, offset, buf, bufSz,
                                              HALO_CACHE_FLUSH_FLAGS_NONE);
    }
    else {
        return haloReadLocalMemoryCacheAware(dev, vsm, wp, ln, offset, buf, bufSz,
                                             HALO_CACHE_FLUSH_FLAGS_NONE);
    }
}

static CUDBGResult
haloWriteLocalMemory(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                     uint64_t offset, const void *buf, uint32_t bufSz)
{
    const uint8_t *src = (const uint8_t *) buf;
    uint32_t addr = (uint32_t) offset;
    Context context;
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t offset_32;
    uint64_t lOffset;
    uint64_t lmemBase;
    HaloLmemConfig_t *warpLmem = &dev->smState[vsm].warp[wp].lmemConfig;

    CUDBG_VERIFY(((uint64_t) addr == offset),
                 CUDBG_ERROR_INVALID_MEMORY_ACCESS,
                 "Invalid memory access in haloWriteLocalMemory.\n");

    CUDBG_VERIFY((dev->activeContext && dev->activeContext->memMapActive),
                 CUDBG_ERROR_MEMORY_MAPPING_FAILED,
                 "Memory mapping failed in haloWriteLocalMemory.\n");

    context = dev->activeContext;

    /* If we've preempted (on architectures that support it), we must first
       check if lmemBase has been remapped.  If it hasn't, then we need
       to dig it out from the cta context and cache it for the remaining
       lifetime of this warp. */
    if (dev->preemptState == CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_PREEMPTED_FOR_DEVICE_EVENT &&
        dev->smState[vsm].warp[wp].lmemSegType == HALO_MEM_SEG_LOCAL_DEFAULT) {
        res = dev->halo.setLmemBaseCtaCtx(dev, vsm, wp);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to set lmemBase from cta ctx (res=%d)\n", res);
            return res;
        }
    }

    if (ln == HALO_LOCAL_MEMORY_ACCESS_FOR_ALL_LANES) {
        /* The following code assumes that the requested bytes is isolated to
           either lmemLo or lmemHi. Although it is simple to update the code to
           handle both regions but return an error for now as I don't see the
           requirement to handle this case */
        if (offset < warpLmem->lmemHiOff) {
            // The start is requested in lmemLo
            if (bufSz >= warpLmem->lmemHiOff) {
                // The end is from lmemHi
                HALO_ERROR("Writing lmem to both hi and lo regions is unsupported\n");
                return CUDBG_ERROR_INTERNAL;
            }
        }

        /* Check if requested bytes read is multiple of a word for each lane.
           Return an error otherwise. This can be updated if there is a
           requirement */
        if ((bufSz / 32) % 4) {
            HALO_ERROR("Requested lmem write size not multiple of word size\n");
            return CUDBG_ERROR_INTERNAL;
        }

        res = dev->halo.getLmemInternalOffset(dev, addr, vsm, wp, 0, &offset_32);
        if (res != CUDBG_SUCCESS)
            return res;
        lOffset = offset_32;

        /* Check for out-of-bounds access to local memory */
        CUDBG_VERIFY((lOffset <= dev->smState[vsm].warp[wp].lmemSeg->size),
                     CUDBG_ERROR_INVALID_MEMORY_ACCESS,
                     "offset %016" PRIx64 " out of range [0; %016" PRIx64 "]\n",
                     lOffset, dev->smState[vsm].warp[wp].lmemSeg->size);


        lmemBase = dev->smState[vsm].warp[wp].lmemSeg->devvaddr;
        if (dev->smState[vsm].warp[wp].lmemSegType == HALO_MEM_SEG_LOCAL_DEFAULT)
            lmemBase = context->defaultLmemDevVA;

        res = dev->halo.writeDeviceMemory(context, lmemBase + lOffset, src, bufSz);
        if (res != CUDBG_SUCCESS) {
            HALO_TRACE_FUNCTION(50, "Call to writeDeviceMemory failed.\n");
            return res;
        }
    }
    else {
        /* We have to copy atmost a word at a time :-( */
        while (bufSz) {
            uint32_t residualSize;

            res = dev->halo.getLmemInternalOffset(dev, addr, vsm, wp, ln, &offset_32);
            if (res != CUDBG_SUCCESS)
                return res;
            lOffset = offset_32;

            /* Check for out-of-bounds access to local memory */
            CUDBG_VERIFY((lOffset <= dev->smState[vsm].warp[wp].lmemSeg->size),
                         CUDBG_ERROR_INVALID_MEMORY_ACCESS,
                         "offset %016" PRIx64 " out of range [0; %016" PRIx64 "]\n",
                         lOffset, dev->smState[vsm].warp[wp].lmemSeg->size);


            lmemBase = dev->smState[vsm].warp[wp].lmemSeg->devvaddr;
            if (dev->smState[vsm].warp[wp].lmemSegType == HALO_MEM_SEG_LOCAL_DEFAULT)
                lmemBase = context->defaultLmemDevVA;

            residualSize = 4 - addr % 4;
            if (bufSz < residualSize)
                residualSize =  bufSz;

            res = dev->halo.writeDeviceMemory(context, lmemBase + lOffset, src, residualSize);
            if (res != CUDBG_SUCCESS) {
                HALO_TRACE_FUNCTION(50, "Call to writeDeviceMemory failed.\n");
                return res;
            }

            addr    += residualSize;
            src     += residualSize;
            bufSz   -= residualSize;
        }
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloReadCodeMemory(Context context, uint64_t offset, void *buf, uint32_t sz)
{
    CudbgDevice dev;
    uint64_t pc;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context in haloReadCodeMemory.\n");

    if (!context->memMapActive) {
        HALO_TRACE_FUNCTION(1, "Memory map not yet initialized for this context.\n");
        return CUDBG_ERROR_INVALID_CONTEXT;
    }

    dev = context->dev;
    pc = context->funcMemBaseVA + offset;
    
    res = haloStateContextReadInsnCache(context, pc, buf, sz);
    if (res == CUDBG_ERROR_MISSING_DATA) {
        res = dev->halo.readDeviceMemory(context, pc, buf, sz);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to readDeviceMemory failed (res=%d).\n", res);
            return res;
        }

        res = haloStateContextWriteInsnCache(context, pc, buf, sz);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to haloStateContextSetInsn failed in haloReadCodeMemory (res=%d)\n", res);
            return res;
        }
        return CUDBG_SUCCESS;
    }

    return res;
}

static CUDBGResult
haloWriteCodeMemory(Context context, uint64_t offset, const void *buf, uint32_t sz)
{
    CudbgDevice dev;
    uint64_t pc;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context in haloWriteCodeMemory.\n");

    if (!context->memMapActive) {
        HALO_TRACE_FUNCTION(1, "Memory map not yet initialized for this context.\n");
        return CUDBG_ERROR_INVALID_CONTEXT;
    }

    dev = context->dev;
    pc = context->funcMemBaseVA + offset;

    res = dev->halo.writeDeviceMemory(context, pc, buf, sz);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to writeDeviceMemory failed (res=%d).\n", res);
        return res;
    }

    res = haloStateContextWriteInsnCache(context, pc, buf, sz);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to haloStateContextSetInsn failed in haloWriteCodeMemory (res=%d)\n", res);
        return res;
    }

    dev->codeIsDirty = 1;

    return CUDBG_SUCCESS;
}

typedef struct {
    uint64_t hostvaddr;
    uint64_t devvaddr;
    Context  context;
    uint32_t numFound;
} mapPinnedMemoryToken_t;

static TOOLSresult
mapPinnedMemory(tHashMapKey_t key, void *entry, void *data)
{
    CUDBGResult res = CUDBG_SUCCESS;
    Context context;
    mapPinnedMemoryToken_t *token;
    uint64_t devVaddr = 0;

    context = (Context)entry;
    token = (mapPinnedMemoryToken_t*)data;

    res = haloMemoryMapTranslateToDevVaddr(context->memMap,
                                           HALO_MEM_SEG_PINNED_SYSMEM,
                                           token->hostvaddr,
                                           &devVaddr);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE_FUNCTION(50, "Failed to translate host addr in mapPinnedMemory, returning early.\n");
        return TOOLS_SUCCESS;
    }

    token->devvaddr = devVaddr;
    token->context = context;
    ++token->numFound;
    return TOOLS_SUCCESS;
}

static CUDBGResult
haloReadPinnedMemory(CudbgDevice dev, uint64_t hostvaddr, void *buf, uint32_t bufSz)
{
    CUDBGResult res = CUDBG_SUCCESS;
    mapPinnedMemoryToken_t token;

    token.hostvaddr     = hostvaddr;
    token.context       = NULL;
    token.devvaddr      = 0;
    token.numFound      = 0;

    /* Pinned memory is uniquely defined by its host vaddr. Therefore we do not
       need to exactly know which context to use to read the memory. We can
       figure it out by elimination. This is not true for the other types of
       memory. See Bug 729837 for details. */
    (void)toolsHashMapApplyFunctor(dev->contexts, mapPinnedMemory, (void*)&token);

    /* Ensure there is only 1 context that points to this pinned mapping.
       Multiple contexts can be present here in the event of cudaHostRegistered
       memory, but cannot in the event of cudaHostAlloc().  Since registered
       memory cannot be read by the backend, then we return an error here. */
    if (token.numFound != 1)
        // No trace here as this will not cause app to terminate
        return CUDBG_ERROR_MEMORY_MAPPING_FAILED;

    res = dev->halo.readDeviceMemory(token.context, token.devvaddr, buf, bufSz);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE_FUNCTION(50, "Call to readDeviceMemory failed (res=%d)\n", res);
        return res;
    }

    return res;
}

static CUDBGResult
haloWritePinnedMemory(CudbgDevice dev, uint64_t hostvaddr, const void *buf, uint32_t bufSz)
{
    CUDBGResult res = CUDBG_SUCCESS;
    mapPinnedMemoryToken_t token;

    token.hostvaddr     = hostvaddr;
    token.context       = NULL;
    token.devvaddr      = 0;
    token.numFound      = 0;

    /* Pinned memory is uniquely defined by its host vaddr. Therefore we do not
       need to exactly know which context to use to read the memory. We can
       figure it out by elimination. This is not true for the other types of
       memory. See Bug 729837 for details. */
    (void)toolsHashMapApplyFunctor(dev->contexts, mapPinnedMemory, (void*)&token);

    if (token.numFound != 1)
        // No trace here as this will not cause app to terminate
        return CUDBG_ERROR_MEMORY_MAPPING_FAILED;

    res = dev->halo.writeDeviceMemory(token.context, token.devvaddr, buf, bufSz);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE_FUNCTION(50, "Call to writeDeviceMemory failed (res=%d)\n", res);
        return res;
    }

    return res;
}

typedef enum {
    AccessTypeRead = 0,
    AccessTypeWrite = 1,
} DeviceMemoryAccessType;

static CUDBGResult
haloDebugObjectReadMemory(Context ctx, uint64_t devvaddr, void *buf, uint64_t bufSz);

static CUDBGResult
haloDebugObjectWriteMemory(Context ctx, uint64_t devvaddr, void *buf, uint64_t bufSz);

static CUDBGResult
haloAccessDeviceMemory(Context ctx, uint64_t devvaddr, const void *buf,
                       uint32_t bufSz, DeviceMemoryAccessType accessType)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t size;
    uint64_t remainingSize;
    uint64_t maxSize;
    char *hostAddress;
    uint64_t deviceAddress;

    /* If BAR1 size isn't set (WDDM, MRM..), assume we can read all memory at once */
    maxSize = ctx->dev->bar1Size == 0 ? bufSz: ctx->dev->bar1Size >> 2;
    hostAddress = (char *)buf;
    deviceAddress = devvaddr;
    remainingSize = bufSz;

    CUDBG_VERIFY(ctx && buf && bufSz, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    /* Ensure mapMemory+memcpy is atomic */
    cuosEnterCriticalSection(&haloGlobals.mapMemory_cs);

    while (remainingSize > 0) {
        size = remainingSize > maxSize ? maxSize: remainingSize;

        if (accessType == AccessTypeRead) {
            res = haloDebugObjectReadMemory(ctx, deviceAddress, hostAddress, size);
            if (res != CUDBG_SUCCESS) {
                // Some read failures are expected, like ERROR_ADDRESS_NOT_IN_DEVICE_MEMORY
                HALO_TRACE(10, "Reading failed! res=%#x\n", res);
                goto done;
            }
        }
        else {
            res = haloDebugObjectWriteMemory(ctx, deviceAddress, hostAddress, size);
            if (res != CUDBG_SUCCESS) {
                // Some write failures are expected, like ERROR_ADDRESS_NOT_IN_DEVICE_MEMORY
                HALO_TRACE(10, "Writing failed! res=%#x\n", res);
                goto done;
            }
        }


        if (accessType == AccessTypeWrite) {
            /* Flush these writes to gpu */
            res = ctx->dev->dmal->flushCpuMappingForDevvaddr(ctx, deviceAddress, size, HALO_CACHE_FLUSH_WRITEBACK);

            if (res != CUDBG_SUCCESS) {
                HALO_TRACE_FUNCTION(50, "Error flushing cpu mapping after write\n");
                goto done;
            }
        }

        hostAddress += size;
        deviceAddress += size;
        remainingSize -= size;
    }

done:
    cuosLeaveCriticalSection(&haloGlobals.mapMemory_cs);
    return res;
}

static CUDBGResult
haloReadDeviceMemory(Context ctx, uint64_t devvaddr, void *buf, uint32_t bufSz)
{
    return haloAccessDeviceMemory(ctx, devvaddr, buf, bufSz, AccessTypeRead);
}

static CUDBGResult
haloWriteDeviceMemory(Context ctx, uint64_t devvaddr, const void *buf, uint32_t bufSz)
{
    return haloAccessDeviceMemory(ctx, devvaddr, buf, bufSz, AccessTypeWrite);
}

/* Returns the index of one active lane for the given warp. */
CUDBGResult
haloFindAnActiveLane(CudbgDevice dev, uint32_t sm, uint32_t wp, uint32_t *ln)
{
    uint32_t i;
    uint32_t validThreadMask;
    uint32_t activeThreadMask;

    CUDBG_VERIFY(ln, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_DEVICE, "Invalid device.\n");

    CUDBG_VERIFY(dev->smState[sm].warp[wp].valid, CUDBG_ERROR_INVALID_WARP, "Invalid warp.\n");

    validThreadMask  = dev->smState[sm].warp[wp].validLanes;
    activeThreadMask = dev->smState[sm].warp[wp].activeMask;

    for (i = 0; i < dev->halo.deviceInfo.numLanesPrWarp; ++i)
        if ((1U << i) & (validThreadMask & activeThreadMask)) {
            *ln = i;
            return CUDBG_SUCCESS;
        }

    return CUDBG_ERROR_INTERNAL;
}

CUDBGResult
haloInit(HaloInitData initData)
{
    CUDBGResult res;

    haloStateInit();

    res = haloDmalsInit();
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to initialize DMALs (%d)!\n", res);
        return res;
    }

    /* Allocate global device structures */
    if (!haloGlobalsDevicesCreated) {
        haloGlobals.device = (struct CudbgDevice_st **)calloc(CUDBG_MAX_DEVICES,
                                                              sizeof *haloGlobals.device);
        CUDBG_VERIFY(haloGlobals.device, CUDBG_ERROR_INITIALIZATION_FAILURE, "calloc failed.\n");

        haloGlobalsDevicesCreated = 1;

        HALO_TRACE(5, "haloGlobals allocation size:  %d bytes\n",
                   CUDBG_MAX_DEVICES * sizeof *haloGlobals.device);

        /* Only initialize the critical section one time */
        cuosInitializeCriticalSection(&haloGlobals.mapMemory_cs);
    }

    memcpy(&haloGlobals.initData, initData, sizeof *initData);

    res = haloClientInit(initData->haloType);

    return res;
}

CUDBGResult
haloFinalize(void)
{
    CUDBGResult res;

    res = haloClientFinalize();

    haloStateDestroy();

    /* Free all global device structures */
    if (haloGlobalsDevicesCreated) {
        free(haloGlobals.device);
        haloGlobals.device = NULL;
        haloGlobalsDevicesCreated = 0;

        /* Only delete the critical section one time */
        cuosDeleteCriticalSection(&haloGlobals.mapMemory_cs);
    }

    res = haloDmalsFinalize();
    if (res != CUDBG_SUCCESS)
        HALO_ERROR("Warning: Failed to deinit HALO DMALs!\n");

    return res;
}

/*
 * Clear all traces of this warp from state masks
 */
static CUDBGResult
haloClearWarpState(CudbgDevice dev, uint32_t vsm, uint32_t wp)
{
    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_DEVICE, "Invalid device in haloClearWarpState.\n");
    CUDBG_VERIFY(vsm < dev->halo.deviceInfo.numSMs, CUDBG_ERROR_INVALID_SM, "Invalid sm in haloClearWarpState.\n");
    CUDBG_VERIFY(wp < dev->halo.deviceInfo.numWarpsPrSM, CUDBG_ERROR_INVALID_SM, "Invalid sm in haloClearWarpState.\n");

    warpBitmaskSetBits(&dev->smState[vsm].state.tidValid,    wp, 1, 0);
    warpBitmaskSetBits(&dev->smState[vsm].state.bpmask,      wp, 1, 0);
    warpBitmaskSetBits(&dev->smState[vsm].state.bptrapmask,  wp, 1, 0);
    warpBitmaskSetBits(&dev->smState[vsm].state.brokenwarps, wp, 1, 0);

    return CUDBG_SUCCESS;
}

/*
 * Iterate through the active lanes in a warp and update the physical
 * thread map.
 */
static CUDBGResult
collectWarpState(CudbgDevice dev, uint32_t vsm, uint32_t wp, bool valid, bool broken, bool rewind)
{
    CUDBGResult res;
    CudbgWarp_t *warp = &dev->smState[vsm].warp[wp];
    DebugPatch patch = NULL;
    uint32_t divergedMask;
    uint32_t hitSyscall = 0;
    uint32_t floorsweptSmId = 0;
    bool inTrapRegion = false;
    bool warpHiddenByClient = false;
#if !defined(RELEASE) && defined(CUDA_DEVTOOLS_ENABLE_STATS)
    haloTimer collectTimer;
#endif

    HALO_TIMER_START(collectTimer);

    CUDBG_VERIFY(dev->suspended, CUDBG_ERROR_RUNNING_DEVICE, "Device not suspended in collectWarpState.\n");

    warp->validLanes = 0;
    warp->activeMask = 0;
    warp->valid      = 0;
    warp->blockIdxValid = 0;
    memset(warp->callDepthValid, 0, sizeof(*warp->callDepthValid)*CUDBG_MAX_LANES);
    memset(warp->syscallCallDepthValid, 0, sizeof(*warp->syscallCallDepthValid)*CUDBG_MAX_LANES);

    if (!dev->activeContext)
        return CUDBG_SUCCESS;

    if (!valid)
        return CUDBG_SUCCESS;

    /* Detect if warp hiding is being forced by the client */
    res = dev->haloClient->forceWarpHiding(dev, vsm, wp, &warpHiddenByClient);
    if (res != CUDBG_SUCCESS) {
        return res;
    }

    /* Under MPS, the memcheck client will discard warps that do not
       belong to the current process. Since the non default Lmem for
       clients can vary, and may not be exposed to each client, such warps
       must be detected early (before any LMEM is mapped).
       The detection of which warps belong to the current client happens
       based on the per warp mpsContextId field that is written into
       the scratchpad. Since the scratchpad is shared between all clients
       the filtering happens after this information is gathered in
       collectLmemConfig.  */
    if (warpHiddenByClient) {
        dev->halo.clearWarpState(dev, vsm, wp);
        warp->valid = false;
        HALO_TRACE(10, "vsm%d/wp%d: Hiding warp due to client forcing\n", vsm, wp);
        return CUDBG_SUCCESS;
    }

    /* Collect CRS data. */
    res = dev->halo.collectWarpCRS(dev, vsm, wp);
    if (res)
        return res;

    res = dev->halo.readActiveMask(dev, vsm, wp, &warp->activeMask);
    if (res != CUDBG_SUCCESS)
        return res;

    res = dev->halo.readPC(dev, vsm, wp, &warp->pc);
    if (res != CUDBG_SUCCESS)
        return res;

#ifndef RELEASE
    /* Under internal debugging, allow trap regions to be shown */
    if (!cudbgEnableInternalDebugging)
#endif
    {
        res = dev->haloClient->inTrapRegion(dev, warp->pc, &patch, &inTrapRegion);
        if (res != CUDBG_SUCCESS)
            return res;

        if (inTrapRegion) {
            HALO_TRACE(10, "vsm%d/wp%d:  Found in trap region; hiding\n", vsm, wp);
            dev->halo.clearWarpState(dev, vsm, wp);
            return CUDBG_SUCCESS;
        }
    }

    HALO_TRACE(10, "vsm%d/wp%d: activeMask=%#x\n", vsm, wp, warp->activeMask);

    /* If we have a zero active mask (yet this warp's valid bit is high), then we
       could possibly have hit a STACK_ERROR.  In this case, we need to adjust the
       active mask.  See Bug 978327. */
    if (!warp->activeMask) {
        res = dev->halo.adjustActiveMask(dev, vsm, wp, &warp->activeMask);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to adjust active mask (res = %d)\n", res);
            return res;
        }
        HALO_TRACE(10, "vsm%d/wp%d: adjusted activeMask=%#x\n", vsm, wp, warp->activeMask);
    }

    warp->validLanes = warp->activeMask;

    res = dev->halo.updateSMESRInfo(dev, vsm, wp, &dev->smState[vsm].state,
                                    dev->smState[vsm].warp[wp].pc);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to updateSMESRState failed in readWarpErrors\n");
        return res;
    }

    /* Per warp, obtain launch parameters (ID, blockDim(x,y,z),
       gridDim(x,y,z), blockIdx(x,y)).  threadIdx is read later. */
    res = dev->halo.read_warpParams(dev, vsm, wp, valid,
                                    &warp->virtCTAID,
                                    &warp->CTASharedSize,
                                    &floorsweptSmId);
    if (res != CUDBG_SUCCESS)
        return res;

    if (!dev->smState[vsm].state.floorsweptSmIdValid) {
        dev->smState[vsm].state.floorsweptSmId = floorsweptSmId;
        dev->smState[vsm].state.floorsweptSmIdValid = true;
    }

    /* If preemption is enabled, cache the per-warp address to
       its cta context buffer.  It will be used later for
       reading saved register/memory contents. */
    if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_KILP) {
        /* Only after the ctaContextAddr is collected can we properly read
           and write memory from the backing store (for warps that are
           preempted).

           Note:  for warps that have yet to preempt, they will NOT use the
           ctaContextAddr for anything.  They can properly read lmem out
           of the default backing store at time of pause (they've yet
           to preempt). */
        res = dev->halo.readWarpCtaCtxAddr(dev, vsm, wp, &dev->smState[vsm].warp[wp].ctaContextAddr);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to cache warp cta ctx address!\n");
            return CUDBG_ERROR_INTERNAL;
        }
    }

    /* By this point, we know if the warp has hit a syscall */
    hitSyscall = (uint32_t)(!!(warpBitmaskGetBits(&dev->smState[vsm].state.syscallwarps, wp, 1)));
    HALO_TRACE(10, "vsm%d/wp%d: Hit syscall:%u "
               "syscallwarps:" CU_WARP_BIT_MASK_FMT_128_STR "\n",
               vsm, wp, hitSyscall,
               CU_WARP_BIT_MASK_FMT_128_VAL(&dev->smState[vsm].state.syscallwarps));

    /* Back up program counter that were due to a breakpoint */
    if (broken && rewind && !hitSyscall) {
        res = dev->halo.rewindBrokenWarp(dev->activeContext, vsm, wp);
        if (res != CUDBG_SUCCESS) {
            HALO_TRACE(10, "vsm%d/wp%d: Could not rewind warp (res = %d)\n", vsm, wp, res);
            return res;
        }
    }

    /*
     * Diverged entries are still alive (though dormant). Traverse
     * the CRS stack and pickup the divergent threads.
     */
    /* Lanes that are diverged are considered "valid" from the POV
       of the debugging API, that is, you can query their state
       etc. */

    res = dev->halo.findDivergedCRS_Mask(dev, vsm, wp, &divergedMask);
    if (res != CUDBG_SUCCESS)
        return res;
    warp->validLanes |= divergedMask;
    HALO_TRACE(10, "vsm%d/wp%d: divergedMask=%#x validLanes=%#x\n",
               vsm, wp, divergedMask, warp->validLanes);

    /*
     * There are these cases:
     * 1) the first time we see a warp
     * 2) we see a valid warp, but the block has changed
     * 3) we see the same warp again (some threads might have gone
     *    inactive), and finally
     * 4) we see an invalid warp (thus, everything has gone away).
     */
    if (!warp->valid) {
        unsigned lane;
        uint32_t alive = warp->validLanes;

        /* Cycle through the lanes and update the thread status */

        for (lane = 0; lane < 32; ++lane, alive >>= 1)
            if (alive & 1) {
                /* Obtain threadIdx.{x,y,z} */
                res = dev->halo.scratchpad.read_threadIdx(dev->activeContext->scratchpadAccessor, vsm, wp, lane,
                                               &warp->threadIdx[lane]);
                if (res != CUDBG_SUCCESS)
                    return res;
            }
    }

    res = dev->halo.setWarpStateValid(dev, vsm, wp);
    if (res != CUDBG_SUCCESS) {
        return res;
    }

    HALO_TIMER_STOP(collectTimer);
    HALO_TIMER_PRINT(collectTimer, 50, "collectWarpState\n");

    return CUDBG_SUCCESS;
}

static CUDBGResult
collectActiveContext(CudbgDevice dev, bool singleStepping)
{
    CUDBGResult res = CUDBG_SUCCESS;

    /* Under some circumstances, a client (i.e. memcheck) can always
       populate the active context, as it was woken using the per context
       notifier. As a result, find active context
       should not be called. Once we implement handling
       multiple active contexts, this can be removed. */
    if (haloGlobals.initData.flags & HALO_INIT_FLAGS_COLLECT_ACTIVE_CONTEXT)
        res = dev->halo.findActiveContext(dev, singleStepping);

    if (res != CUDBG_SUCCESS)
        return res;

    HALO_TRACE(20, "Active context on Device %u is %p\n", dev->deviceIdx, dev->activeContext);
    return CUDBG_SUCCESS;
}

/*
 * Collect the state of an SM (XXX this possibly should be done lazily).
 */
static CUDBGResult
collectSMStates(CudbgDevice dev)
{
    uint32_t vsm;
    CUDBGResult res = CUDBG_SUCCESS;

    for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
        /* Already up to date so skip it. */
        if (dev->smState[vsm].valid)
            continue;

        /* We must explicitly clear syscallwarps here as all the others
           are cleared in readSMState */
        warpBitmaskClear(&dev->smState[vsm].state.syscallwarps);
        /* Clear the exception until we find a new one */
        dev->smState[vsm].state.foundException = false;

        res = dev->halo.readSMState(dev, vsm, &dev->smState[vsm].state);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Cannot read SMState\n");

        HALO_TRACE(10, "Device %u SM %u\n", dev->deviceIdx, vsm);
        HALO_TRACE(10, "  tidValid     = " CU_WARP_BIT_MASK_FMT_128_STR "\n",
                   CU_WARP_BIT_MASK_FMT_128_VAL(&dev->smState[vsm].state.tidValid));
        HALO_TRACE(10, "  bpmask       = " CU_WARP_BIT_MASK_FMT_128_STR "\n",
                   CU_WARP_BIT_MASK_FMT_128_VAL(&dev->smState[vsm].state.bpmask));
        HALO_TRACE(10, "  bptrapmask   = " CU_WARP_BIT_MASK_FMT_128_STR "\n",
                   CU_WARP_BIT_MASK_FMT_128_VAL(&dev->smState[vsm].state.bptrapmask));
        HALO_TRACE(10, "  brokenwarps  = " CU_WARP_BIT_MASK_FMT_128_STR "\n",
                   CU_WARP_BIT_MASK_FMT_128_VAL(&dev->smState[vsm].state.brokenwarps));
        HALO_TRACE(10, "  hwwglobalesr = %08x\n", dev->smState[vsm].state.esrState.hwwglobalesr);
        HALO_TRACE(10, "  hwwwarpesr   = %08x\n", dev->smState[vsm].state.esrState.hwwwarpesr);
        HALO_TRACE(20, "  esrWarpId    = %08x\n"        , dev->smState[vsm].state.esrWarpId);
        HALO_TRACE(20, "  esrWarpPC    = %08x\n"        , dev->smState[vsm].state.esrWarpPC);
    }

    /* WAR #####: GP100 virtual sm bug.
       Because vsms can share a tpc and esrs are global to the tpc, we need to
       make sure each sm collects the esr info before clearing it */
    for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
        res = dev->halo.clearSMESRInfo(dev, vsm, &dev->smState[vsm].state, dev->debugObjMode);
        if (res != CUDBG_SUCCESS)
            return res;
    }

    if (!dev->activeContext) {
        /* Bug 825163 - OGL interop exposed this - we can get into
           a state where there are valid warps, but they do not belong
           to any known CUDA contexts.  We need to clear all SM state
           to avoid client debuggers thinking they can query more
           information about warps the backend claims to be valid. */
        HALO_TRACE(10, "Clearing SM states since context is NULL!\n");
        res = dev->halo.clearSMState(dev);
        if (res != CUDBG_SUCCESS)
            return res;
    }

    return res;
}

static CUDBGResult
collectLmemConfig(CudbgDevice dev)
{
    uint32_t vsm;
    CUDBGResult res = CUDBG_SUCCESS;

    for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
        /* Already up to date so skip it. */
        if (dev->smState[vsm].valid)
            continue;

        /* Read the local memory configuration. */
        if (dev->activeContext) {
            res = dev->halo.readLmemConfig(dev, vsm);
            if (res != CUDBG_SUCCESS)
                return res;
        }
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
collectWarpStates(CudbgDevice dev, CUwarpBitmask *rewindWarpMasks)
{
    uint32_t vsm, tid;
    CUwarpBitmask valid, broken, rewind, empty = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;
    CUDBGResult res;
    bool warp_valid, warp_broken, warp_rewind;
#if !defined(RELEASE)
    uint32_t warpCount = 0;
#endif

    for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
        /* Already up to date so skip it. */
        if (dev->smState[vsm].valid)
            continue;

        warpBitmaskAssign(&valid,  &dev->smState[vsm].state.tidValid);
        warpBitmaskAssign(&broken, &dev->smState[vsm].state.brokenwarps);
        warpBitmaskAssign(&rewind, (rewindWarpMasks ? &rewindWarpMasks[vsm] : &empty));
        for (tid = 0; tid < dev->halo.deviceInfo.numWarpsPrSM; ++tid) {
            warp_valid  = !!(warpBitmaskGetBits(&valid, tid, 1));
            warp_broken = !!(warpBitmaskGetBits(&broken, tid, 1));
            warp_rewind = !!(warpBitmaskGetBits(&rewind, tid, 1));
            res = collectWarpState(dev, vsm, tid, warp_valid, warp_broken, warp_rewind);
            if (res != CUDBG_SUCCESS)
                return res;
#if !defined(RELEASE)
            if (warp_valid)
                warpCount++;
#endif
        }

        if (CUDBG_TRACE_LEVEL >= 50 && warpBitmaskAny(&dev->smState[vsm].state.tidValid)) {
            haloTraceWarpPCs(CUDBG_TRACE_LEVEL, __FILE__, __LINE__, __FUNCTION__, dev, vsm);
            if (res != CUDBG_SUCCESS) {
                HALO_ERROR("Failed to trace pcs, ignoring... res=%d", res);
            }
        }

        /* We are done updating. By now collectSMStates and collectLMemConfig()
           have been called too. */
        dev->smState[vsm].valid = 1;
    }

    HALO_TRACE_FUNCTION(10, "valid warpCount %d\n", warpCount);

    return CUDBG_SUCCESS;
}

static CUDBGResult
collectPostProcess(CudbgDevice dev)
{
    uint32_t vsm;

    /* We are done updating. By now collectSMStates and collectLMemConfig() have
       been called too. */
    for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm)
        dev->smState[vsm].valid = 1;

    return CUDBG_SUCCESS;
}

static TOOLSresult
invalidateContextCaches(tHashMapKey_t key, void* entry, void* data)
{
    Context context = (Context)entry;
    CUDBGResult *res = (CUDBGResult*)data;

    HALO_TRACE_FUNCTION(40, "invalidate context %p caches\n", context);

    if (haloStateContextIsActive(context)) {
        *res = context->dev->halo.contextCommonDataCacheOp(context, HALO_MEM_SEG_CACHE_INVALIDATE);
        CUDBG_VERIFY(*res == CUDBG_SUCCESS, TOOLS_ERROR_UNKNOWN, "Failed to invalidate context %p cache\n", context);
    }

    return TOOLS_SUCCESS;
}

CUDBGResult
haloInvalidateCaches(CudbgDevice dev)
{
    CUDBGResult res = CUDBG_SUCCESS;    /* Initialize res in case there are no contexts */

    CUDBG_VERIFY(dev, CUDBG_ERROR_INTERNAL, "Invalid dev\n");

    /* Ensure all contexts have their caches flushed, since we
       don't know which context ran last */
    if (dev->contexts) {
        (void)toolsHashMapApplyFunctor(dev->contexts, invalidateContextCaches, (void*)&res);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to clear context caches\n");
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloCollectContext(CudbgDevice dev, bool singleStepping)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(dev, CUDBG_ERROR_INTERNAL, "Invalid dev\n");

    /* Ensure all contexts have their caches flushed, since we
       don't know which context ran last */
    res = haloInvalidateCaches(dev);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to clear scratchpad segment caches\n");

    res = collectActiveContext(dev, singleStepping);
    if (res != CUDBG_SUCCESS)
        return res;

    if (dev->activeContext) {
        res = dev->halo.contextCommonDataCacheOp(dev->activeContext, HALO_MEM_SEG_CACHE_ENABLE);
        if (res != CUDBG_SUCCESS)
            return res;
    }

    return res;
}

/**
 * Collect the state of a device (XXX this possibly should be done lazily).
 *
 * @param dev Device to collect state on
 * @param singleStepping true if caller is requesting device state after a single step operation
 * @param rewindAll ignore rewindWarpMasks and rewind all warps on all SMs
 * @param rewindWarpMask warp mask applied to collected bpmask of warps that
          need their pcs rewound.  If NULL, assumes empty (all 0's).
 * @note rewindWarpMask is applied to all SMs not yet collected (smState[vsm].valid == false).
*/
static CUDBGResult
haloCollectDeviceState(CudbgDevice dev, bool singleStepping, CUwarpBitmask *rewindWarpMasks)
{
    CUDBGResult res = CUDBG_SUCCESS;

    HALO_TRACE(10, "Collecting Device %u State\n", dev->deviceIdx);
    HALO_GLOBAL_TIMER_START();

    /* The order here is important. We must first find an active context and
       collect SM state (in theory, these 2 can be done in any order, however
       we collect the active context first, as SM state may sometimes require
       mapping memory to be correct [See Bug 971389 where the brokenwarps mask
       can't be accurately setup by PRI only]).  Once SM state has been collected,
       we know which warps are valid.  That new information is then used to read
       the local memory and the state of the warps. */

    /* Force cpu-gpu caches to be in sync for future reads */
    res = dev->dmal->forceCacheCoherence(dev);
    if (res != CUDBG_SUCCESS)
        return res;
    HALO_GLOBAL_TIMER_LAP("forceCacheCoherence");

    res = dev->halo.collectContext(dev, singleStepping);
    if (res != CUDBG_SUCCESS)
        return res;
    HALO_GLOBAL_TIMER_LAP("collectContext");

    res = collectSMStates(dev);
    if (res != CUDBG_SUCCESS)
        return res;
    HALO_GLOBAL_TIMER_LAP("collectSMStates");

    res = collectLmemConfig(dev);
    if (res != CUDBG_SUCCESS)
        return res;
    HALO_GLOBAL_TIMER_LAP("collectLmemConfig");

    res = collectWarpStates(dev, rewindWarpMasks);
    if (res != CUDBG_SUCCESS)
        return res;
    HALO_GLOBAL_TIMER_LAP("collectWarpStates");

    res = collectPostProcess(dev);
    if (res != CUDBG_SUCCESS)
        return res;
    HALO_GLOBAL_TIMER_LAP("collectPostProcess");

    HALO_GLOBAL_TIMER_STOP();
    HALO_GLOBAL_TIMER_PRINT(10, "haloCollectDeviceState\n");

    return CUDBG_SUCCESS;
}

bool
haloWarpsInSameCTA(CudbgDevice dev, uint32_t vsm, uint32_t wpA, uint32_t wpB)
{
    CudbgWarp_t *warpState = &dev->smState[vsm].warp[0];

    /* Two warps share a CTA iff they are both valid, from the
       same grid, and have the same blockIdx coordinates */
    if (warpState[wpA].valid      && warpState[wpB].valid      &&
        warpState[wpA].gridId64   == warpState[wpB].gridId64   &&
        warpState[wpA].blockIdx.x == warpState[wpB].blockIdx.x &&
        warpState[wpA].blockIdx.y == warpState[wpB].blockIdx.y &&
        warpState[wpA].blockIdx.z == warpState[wpB].blockIdx.z)
        return true;

    return false;
}

static CUDBGResult
haloMemcheckEnabled(CudbgDevice dev, uint32_t *enabled)
{
    if (dev->mcState != HALO_MC_STATE_UNCHECKED) {
        *enabled = (uint32_t)(dev->mcState == HALO_MC_STATE_ENABLED);
        return CUDBG_SUCCESS;
    }

    dev->mcState = (gpudbgIsMemcheckAttached())?
                   HALO_MC_STATE_ENABLED:
                   HALO_MC_STATE_DISABLED;

    *enabled = (uint32_t)(dev->mcState == HALO_MC_STATE_ENABLED);

    return CUDBG_SUCCESS;
}

static void
haloDeviceInitCommonFunctions(CudbgDevice dev)
{
    CUdev *pDev;
    CUDBGResult res;
    struct HaloDrvFuncPtrs drvFuncs;

    /* Init for Fermi */
    haloDeviceInit_gf100(&dev->halo);

    /* Generic methods shared across all architectures */
    dev->halo.clearEvent            = clearEvent;
    dev->halo.readPinnedMemory      = haloReadPinnedMemory;
    dev->halo.readCodeMemory        = haloReadCodeMemory;
    dev->halo.readLocalMemory       = haloReadLocalMemory;
    dev->halo.readLocalMemoryCacheAware = haloReadLocalMemoryCacheAware;
    dev->halo.writePinnedMemory     = haloWritePinnedMemory;
    dev->halo.writeCodeMemory       = haloWriteCodeMemory;
    dev->halo.writeLocalMemory      = haloWriteLocalMemory;
    dev->halo.readDeviceMemory      = haloReadDeviceMemory;
    dev->halo.writeDeviceMemory     = haloWriteDeviceMemory;

    dev->halo.clearWarpState        = haloClearWarpState;
    dev->halo.collectDeviceState    = haloCollectDeviceState;
    dev->halo.collectContext        = haloCollectContext;

    dev->halo.mcinterop_memcheckEnabled = haloMemcheckEnabled;

    dev->halo.deviceInitialize      = haloDeviceInitialize;
    dev->halo.deviceFinalize        = haloDeviceFinalize;

    /* Get the driver API function pointers */
    pDev = globals.devices[dev->deviceIdx];
    if (pDev != NULL) {
        res = haloGetDrvFuncPtrs(pDev->state.major * 10 + pDev->state.minor, &drvFuncs);
        if (res == CUDBG_SUCCESS) {
            dev->halo.getInstructionSize = drvFuncs.getInstructionSize;
            dev->halo.isStackPointerAssignment = drvFuncs.isStackPointerAssignment;
            dev->halo.adjustCodeAddress = drvFuncs.adjustCodeAddress;
        }
        else
            HALO_ERROR("Could not get driver API function pointers\n");
    }
    else
        HALO_ERROR("Could not get global.devices[%d]\n", dev->deviceIdx);
}

CUDBGResult
haloDeviceInitialize(CudbgDevice dev, uint32_t device)
{
    const CUdev* pDev;
    CUDBGResult res, finalizeRes;
    Halo_st *halo = &dev->halo;

    pDev = globals.devices[device];
    dev->deviceIdx = device;

    haloStateDeviceCreateMaps(dev);

    res = dev->haloClient->deviceInitPreHook(dev);
    if (res != CUDBG_SUCCESS)
        return res;

    haloDeviceInitCommonFunctions(dev); // Functions shared across architectures

    if (cuiPreemptionDevicePreemptionMode(pDev) == CU_COMPUTE_PREEMPTION_MODE_CILP)
        dev->halo.deviceInfo.preemptionType = HALO_PREEMPTION_TYPE_CILP;

    switch (pDev->state.arch) {
#if NVCFG(GLOBAL_CHIP_T124) || NVCFG(GLOBAL_GPU_IMPL_GK20A)
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_T12X
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_T12X:
        /* GK20A device initialization */
        /* Likely a subject to future changes */
        haloDeviceInit_gk20a(halo);
        break;
#endif
#endif
#if NVCFG(GLOBAL_ARCH_AMPERE)
#if defined(NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GA100)
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GA100:
        haloDeviceInit_ga100(halo);
        break;
#endif // NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GA100
#endif // GLOBAL_ARCH_AMPERE
#if NVCFG(GLOBAL_ARCH_TURING)
#if defined(NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_TU100)
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_TU100:
        haloDeviceInit_tu100(halo);
        break;
#endif // NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_TU100
#endif // GLOBAL_ARCH_TURING
#if NVCFG(GLOBAL_ARCH_VOLTA)
#if defined(NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV100) || defined(NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV110)
#if defined(NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV100)
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV100:
#endif
#if defined(NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV110)
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV110:
#endif
        haloDeviceInit_gv100(halo);
        break;
#endif // NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV100 || NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GV110
#endif // GLOBAL_ARCH_VOLTA
#if NVCFG(GLOBAL_ARCH_PASCAL)
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GP100
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GP100:
        haloDeviceInit_gp100(halo);
        break;
#endif
#endif
#if NVCFG(GLOBAL_ARCH_MAXWELL)
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM000
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM000:
        switch (pDev->state.chip) {
        default:
            haloDeviceInit_gm100(halo);
            break;
        }
        break;
#endif
#if NVCFG(GLOBAL_GPU_FAMILY_GM20X) && defined(NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200)
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GM200:
        haloDeviceInit_gm20x(halo);
        break;
#endif
#endif
#if NVCFG(GLOBAL_ARCH_KEPLER)
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK110:
        haloDeviceInit_gk110(halo);
        break;
#endif
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK200
        /* GK208 = sm_35 (same as GK110) */
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK200:
        haloDeviceInit_gk200(halo);
        break;
#endif
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100:
        switch (pDev->state.chip) {
            /* GK20A = sm_32 (mostly GK110, sigh...)) */

#if defined(NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK20A)
        case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 + NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK20A:
            haloDeviceInit_gk20a(halo);
            break;
#endif
        default:
            haloDeviceInit_gk100(halo);
            break;
        }
        break;
#endif
#if NVCFG(GLOBAL_ARCH_FERMI)
#ifdef NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF110:
#endif
    case NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GF100:
        haloDeviceInit_gf100(halo);
        break;
#endif

    default:
        HALO_ERROR("Unsupported device: %s (Arch: %" PRIx64 ").\n", pDev->state.name, pDev->state.arch);
        return CUDBG_ERROR_INVALID_DEVICE;
    }

    res = dev->haloClient->initPrivAccess(dev);
    if (res != CUDBG_SUCCESS)
        return res;

    res = dev->haloClient->readBar1Size(dev, &dev->bar1Size);
    if (res != CUDBG_SUCCESS)
        return res;

    res = dev->haloClient->deviceInitPostHook(dev);
    if (res != CUDBG_SUCCESS)
        goto fail;

    /* Populate the info fields */
    return dev->halo.getInfo(dev);

fail:
    // XXX Failure handling is mostly missing
    finalizeRes = dev->halo.deviceFinalize(dev);
    if (finalizeRes != CUDBG_SUCCESS)
        return finalizeRes;

    return res == CUDBG_SUCCESS ? CUDBG_ERROR_UNKNOWN : res;
}

static CUDBGResult
haloDeviceFinalize(CudbgDevice dev)
{
    CUDBGResult res = CUDBG_SUCCESS;

    res = dev->haloClient->deviceDestroyPreHook(dev);
    if (res != CUDBG_SUCCESS)
        return res;

    haloStateDeviceDestroyMaps(dev);

    /* Invoke the per-device cleanup function */
    res = dev->halo.cleanup(dev);
    if (res != CUDBG_SUCCESS)
        return res;

    res = dev->haloClient->finalizePrivAccess(dev);
    if (res != CUDBG_SUCCESS)
        return res;

    res = dev->haloClient->deviceDestroyPostHook(dev);
    if (res != CUDBG_SUCCESS)
        return res;

    haloGlobals.device[dev->deviceIdx]->status = CUDBG_ERROR_UNINITIALIZED;

    return CUDBG_SUCCESS;
}

void
haloSetMemcheckState(CudbgDevice dev, bool enabled)
{
    if (!dev)
        return;

    if (enabled)
        dev->mcState = HALO_MC_STATE_ENABLED;
    else
        dev->mcState = HALO_MC_STATE_DISABLED;
}

static CUDBGResult
findResidentContext(Context context, void *userData)
{
    ContextFunctor *contextFunctor = (ContextFunctor *)userData;
    bool bResident = false;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(contextFunctor, CUDBG_ERROR_INTERNAL, "contextFunctor is NULL");

    if (contextFunctor->residentContext != NULL)
        /* Already found */
        return CUDBG_SUCCESS;

    /* Skip any context in the process of finalizing */
    if (!context || !haloStateContextIsActive(context))
        return CUDBG_SUCCESS;

    /* Restrict the search to contexts on the device we care about. */
    if (contextFunctor->dev != context->dev)
        return CUDBG_SUCCESS;

    res = haloIsContextResident(context, &bResident);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed in haloIsContextResident\n");

    if (bResident)
        contextFunctor->residentContext = context;

    return CUDBG_SUCCESS;
}

CUDBGResult
haloIsContextResident(Context context, bool *isResident)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t hChannel = 0;
    uint32_t i;

    CUDBG_VERIFY(isResident, CUDBG_ERROR_INVALID_ARGS, "Invalid args");

    *isResident = false;

    /* Skip any context in the process of finalizing */
    if (!context || !haloStateContextIsActive(context))
        return CUDBG_SUCCESS;

    /* If a debug object isn't available, we can't find the resident context.
     * If you can't make it, fake it. */
    if (!context->dev->dmal->debugObjectIsStable()) {
        *isResident = true;
        return res;
    }

    /* This context may not have a debug object allocated yet. This happens if
     * the context has not yet received a ctx create callback from the driver.
     * If so, skip it. */
    if (!CUDBG_DEBUG_OBJECT_IS_VALID(context->debugObj))
        return CUDBG_SUCCESS;

    /* Get the channel handle for the current resident channel */
    res = context->dev->dmal->debugObjectGetResidentChannelHandle(context->dev,
                                                                  context->debugObj, &hChannel);
    if (res != CUDBG_SUCCESS) {
        /* Ignore errors from the rmcontrol */
        HALO_TRACE(10, "Ignoring error in RM control\n");
        return CUDBG_SUCCESS;
    }

    /* See if the resident context exists in this context's channel list */
    for (i = 0; i < context->numChannels; ++i) {
        if (context->hComputeChannelList[i] == hChannel) {
            /* Found it! */
            *isResident = true;
            return CUDBG_SUCCESS;
        }
    }

    return CUDBG_SUCCESS;
}

CUDBGResult
haloAnyDbgCtxResident(CudbgDevice dev, Context *residentContext)
{
    CUDBGResult res = CUDBG_SUCCESS;
    ContextFunctor contextFunctor;

    contextFunctor.dev = dev;
    contextFunctor.residentContext = NULL;

    *residentContext = 0;

    /* Figure out if a context that we care about is resident on this device. */
    haloStateTraverseContexts((haloCtxIterFunc)findResidentContext, &contextFunctor);

    if (contextFunctor.residentContext != NULL)
        *residentContext = contextFunctor.residentContext;

    return res;
}

CUDBGResult
haloMemoryMapAddSegmentFromInfo(haloMemoryMap *memMap, CUDBGmemory_segment *segInfo)
{
    uint64_t devvaddr       = 0;
    uint64_t uvavaddr       = 0;
    uint64_t size           = 0;
    uint64_t devptr         = 0;
    uint64_t hostvaddr      = 0;
    uint32_t mapDevice      = 0;
    uint32_t blockType      = 0;
    uint32_t dmalHandle     = 0;
    uint32_t rmClient       = 0;
    uint32_t srcDevIdx      = 0;
    uint64_t hostHandle     = 0;
    uint32_t usesNvmap      = 0;
    uint32_t hasDevPtr      = 0;
    uint32_t apiSource      = 0;
    uint32_t location       = 0;
    uint32_t owner          = 0;
    uint32_t sharing        = 0;
    uint32_t userOwnsData   = 0;
    uint64_t sourceMemblock = 0;
    haloMemorySegmentType segType = HALO_MEM_SEG_DEVICE_VIRTUAL;
    haloMemorySegment *haloSeg = NULL;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(segInfo, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    devvaddr       = segInfo->devvaddr;
    uvavaddr       = segInfo->uvavaddr;
    size           = segInfo->size;
    devptr         = segInfo->devptr;
    hostvaddr      = segInfo->hostvaddr;
    mapDevice      = segInfo->mapDevice;
    blockType      = segInfo->type;
    dmalHandle     = segInfo->dmalHandle;
    rmClient       = segInfo->rmClient;
    srcDevIdx      = segInfo->sourceDeviceIdx;
    hostHandle     = segInfo->hostHandle;
    usesNvmap      = segInfo->usesNvmap;
    hasDevPtr      = segInfo->hasDevPtr;
    apiSource      = segInfo->apiSource;
    location       = segInfo->location;
    owner          = segInfo->owner;
    sharing        = segInfo->sharing;
    userOwnsData   = segInfo->userOwnsData;
    sourceMemblock = segInfo->sourceMemblock;

    /* Figure out what the segType should be. This will be simplified later on */
    switch (blockType)
    {
    case CU_MEM_TYPE_FUNCTION:
        segType = HALO_MEM_SEG_FUNC;
        break;
    case CU_MEM_TYPE_MANAGED: /* UVM */
        segType = HALO_MEM_SEG_MANAGED;
        break;
    default:
        segType = HALO_MEM_SEG_DEVICE_VIRTUAL;
        break;
    }

    if (!mapDevice)
        HALO_ERROR("Warning: Trying to add a segment that has mapDevice == 0. Lookups may fail. Marching on.\n");

    res = haloMemoryMapGetSegmentByDevVaddrInMap(memMap, devvaddr, &haloSeg);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Error looking up haloSegment\n");
    if (haloSeg) {
        if (haloSeg->size == size &&
            haloSeg->mem  == dmalHandle) {
            /* Duplicate notification for alloc. We can get a duplicate message
               about the allocation when contextCreate is racing with attach. */
            return CUDBG_SUCCESS;
        }

        /* Otherwise, remove the old haloSegment */
        res = haloMemoryMapRemoveSegment(memMap, haloSeg->devvaddr);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Error removing stale haloSegment\n");
    }

    res = haloMemoryMapAddSegment(memMap,
                                  hostHandle,
                                  sourceMemblock,
                                  segType,
                                  devvaddr,
                                  uvavaddr,
                                  size,
                                  dmalHandle,
                                  rmClient,
                                  srcDevIdx,
                                  blockType,
                                  apiSource,
                                  location,
                                  owner,
                                  sharing,
                                  userOwnsData,
                                  usesNvmap,
                                  &haloSeg);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to create haloSeg\n");

    if (hostvaddr) {
        res = haloMemorySegmentModifyHostVA(memMap, haloSeg, hostvaddr);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to map host address\n");
    }

    if (hasDevPtr) {
        res = haloMemorySegmentModifyDevPtr(memMap, haloSeg, 1, devptr);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to map  devptr\n");
    }

    HALO_TRACE(10, "Adding memblock to %s : hostHandle:0x%" PRIx64 " on ctx:0x%" PRIx64 "\n"
               "    devvaddr     :0x%" PRIx64 "\n"
               "    uvavaddr     :0x%" PRIx64 "\n"
               "    size         :0x%" PRIx64 "\n"
               "    blockType    :0x%x\n"
               "    devptr (%s)  :0x%" PRIx64 "\n"
               "    hostvaddr    :0x%" PRIx64 "\n"
               "    dmalHandle   :0x%x\n"
               "    rmClient     :0x%x\n"
               "    srcDevIdx    :0x%x\n",
               segInfo->ctx ? "context": "globalMemMap",
               hostHandle, segInfo->ctx,
               devvaddr,
               uvavaddr,
               size,
               blockType,
               (hasDevPtr) ? "Y" : "N", devptr,
               hostvaddr,
               dmalHandle,
               rmClient,
               srcDevIdx);
    return CUDBG_SUCCESS;
}

CUDBGResult
haloScratchpadGetField(Context context, HaloScratchpadField field,
                       HaloScratchpadSection section, uint32_t sm,
                       uint32_t wp, uint32_t ln, void *value, size_t size)
{
    CUDBGResult res;
    CudbgDevice dev;
    size_t offset = 0;
    size_t fieldWidth;

    CUDBG_VERIFY(context && value, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    dev = context->dev;
    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_CONTEXT,
                 "Invalid dev when reading scratchpad.\n");

    res = dev->halo.scratchpad.getFieldOffset(field, section, sm, wp, ln, &offset, &fieldWidth);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");

    CUDBG_VERIFY(fieldWidth == size, CUDBG_ERROR_INTERNAL,
                 "Mismatch between access size (%d) and field width (%d)\n",
                 (uint32_t)size, (uint32_t)fieldWidth);

    memset(value, 0, size);

    res = dev->halo.readDeviceMemory(context,
                                     context->scratchpadDevVA + (uint32_t)offset,
                                     value,
                                     (uint32_t)size);

    return res;
}

CUDBGResult
haloScratchpadSetField(Context context, HaloScratchpadField field,
                       HaloScratchpadSection section, uint32_t sm,
                       uint32_t wp, uint32_t ln, void *value, size_t size)
{
    CUDBGResult res;
    CudbgDevice dev;
    size_t offset = 0;
    size_t fieldWidth;

    CUDBG_VERIFY(context && value, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    dev = context->dev;
    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_CONTEXT,
                 "Invalid dev when reading scratchpad.\n");

    res = dev->halo.scratchpad.getFieldOffset(field, section, sm, wp, ln, &offset, &fieldWidth);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");

    CUDBG_VERIFY(fieldWidth == size, res,
                 "Mismatch between access size (%d) and field width (%d)\n",
                 (int)size, (int)fieldWidth);

    res = dev->halo.writeDeviceMemory(context,
                                      context->scratchpadDevVA + (uint32_t)offset,
                                      value,
                                      (uint32_t)size);

    return res;
}

CUDBGResult
haloPreemptionBufferGetField(Context context, HaloPreemptionBufferField field, HaloPreemptionBufferSection section, uint32_t sm, uint32_t cta, uint32_t wp, uint32_t ln, void *value, size_t size)
{
    CUDBGResult res;
    CudbgDevice dev;
    size_t offset = 0;
    size_t fieldWidth;

    CUDBG_VERIFY(context && value, CUDBG_ERROR_INVALID_ARGS, "Invalid args");

    dev = context->dev;
    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_CONTEXT,
                 "Invalid dev when reading scratchpad.\n");

    res = dev->halo.preemptionBuffer.getFieldOffset(field, section, sm, cta, wp, ln, &offset, &fieldWidth);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");

    CUDBG_VERIFY(fieldWidth == size, CUDBG_ERROR_INTERNAL,
                 "Mismatch between access size (%d) and field width (%d)\n",
                 (uint32_t)size, (uint32_t)fieldWidth);

    memset(value, 0, size);

    res = dev->halo.readDeviceMemory(context,
                                     context->cilpBufferDevVA + (uint32_t)offset,
                                     value,
                                     (uint32_t)size);

    return res;
}

CUDBGResult
haloCilpBufferSetField(Context context, HaloPreemptionBufferField field,
                       HaloPreemptionBufferSection section, uint32_t sm,
                       uint32_t cta,
                       uint32_t wp, uint32_t ln, void *value, size_t size)
{
    CUDBGResult res;
    CudbgDevice dev;
    size_t offset = 0;
    size_t fieldWidth;

    CUDBG_VERIFY(context && value, CUDBG_ERROR_INVALID_ARGS, "Invalid args");

    dev = context->dev;
    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_CONTEXT,
                 "Invalid dev when reading scratchpad.\n");

    res = dev->halo.preemptionBuffer.getFieldOffset(field, section, sm, cta, wp, ln, &offset, &fieldWidth);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");

    CUDBG_VERIFY(fieldWidth == size, res,
                 "Mismatch between access size (%d) and field width (%d)\n",
                 (int)size, (int)fieldWidth);

    res = dev->halo.writeDeviceMemory(context,
                                      context->cilpBufferDevVA + (uint32_t)offset,
                                      value,
                                      (uint32_t)size);

    return res;
}

HaloExceptionPrecision
haloExceptionGetPrecision(CUDBGException_t exception)
{
    switch (exception) {
    case CUDBG_EXCEPTION_UNKNOWN:
        return HALO_EXCEPTION_PRECISION_UNKNOWN;
    case CUDBG_EXCEPTION_NONE:
        return HALO_EXCEPTION_PRECISION_NONE;
    case CUDBG_EXCEPTION_LANE_ILLEGAL_ADDRESS:
        return HALO_EXCEPTION_PRECISION_LANE;
    case CUDBG_EXCEPTION_LANE_USER_STACK_OVERFLOW:
        return HALO_EXCEPTION_PRECISION_LANE;
    case CUDBG_EXCEPTION_DEVICE_HARDWARE_STACK_OVERFLOW:
        return HALO_EXCEPTION_PRECISION_DEVICE;
    case CUDBG_EXCEPTION_WARP_ILLEGAL_INSTRUCTION:
        return HALO_EXCEPTION_PRECISION_WARP;
    case CUDBG_EXCEPTION_WARP_OUT_OF_RANGE_ADDRESS:
        return HALO_EXCEPTION_PRECISION_WARP;
    case CUDBG_EXCEPTION_WARP_MISALIGNED_ADDRESS:
        return HALO_EXCEPTION_PRECISION_WARP;
    case CUDBG_EXCEPTION_WARP_INVALID_ADDRESS_SPACE:
        return HALO_EXCEPTION_PRECISION_WARP;
    case CUDBG_EXCEPTION_WARP_INVALID_PC:
        return HALO_EXCEPTION_PRECISION_WARP;
    case CUDBG_EXCEPTION_WARP_HARDWARE_STACK_OVERFLOW:
        return HALO_EXCEPTION_PRECISION_WARP;
    case CUDBG_EXCEPTION_DEVICE_ILLEGAL_ADDRESS:
        return HALO_EXCEPTION_PRECISION_DEVICE;
    case CUDBG_EXCEPTION_LANE_MISALIGNED_ADDRESS:
        return HALO_EXCEPTION_PRECISION_LANE;
    case CUDBG_EXCEPTION_WARP_ASSERT:
        return HALO_EXCEPTION_PRECISION_WARP;
    case CUDBG_EXCEPTION_LANE_SYSCALL_ERROR:
        return HALO_EXCEPTION_PRECISION_LANE;
    case CUDBG_EXCEPTION_WARP_ILLEGAL_ADDRESS:
        return HALO_EXCEPTION_PRECISION_WARP;
    case CUDBG_EXCEPTION_LANE_INVALID_ATOMSYS:
        return HALO_EXCEPTION_PRECISION_LANE;
    default:
        return HALO_EXCEPTION_PRECISION_UNKNOWN;
    }
}

CUDBGResult
haloCreateDynamicGrid(CudbgDevice dev, uint32_t vsm, uint32_t wp)
{
    CUDBGResult res;
    CuDim3 gridDim, blockDim;
    Grid grid;
    uint32_t activeMask, ln;
    uint64_t gridId64 = dev->smState[vsm].warp[wp].gridId64;
    uint64_t physPC = dev->smState[vsm].warp[wp].pc;
    bool isPostable = false;
    Grid parentGrid;
    bool isReserved;
    bool foundUserEntry = false;
    uint64_t userEntryPC = physPC;
    Context context = dev->activeContext;
    uint64_t selfQMDdptr;

    HALO_TRACE_FUNCTION(1, "Checking grid %" PRId64 "\n", gridId64);

    /* Check if this grid is reserved */
    res = dev->halo.isReservedGridId(dev, gridId64, &isReserved);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to post grid event\n");
        return res;
    }

    /* We should always have a valid activeContext at this point */
    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "Do not have an active context\n");

    /* This will be 0 on architectures that don't have QMDs */
    res = dev->halo.scratchpad.read_selfQMD(context->scratchpadAccessor, vsm, wp, &selfQMDdptr);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Could not get selfQMDdptr\n");

    HALO_TRACE_FUNCTION(3, "selfQMD = 0x%016" PRIx64 "\n", selfQMDdptr);

    /* Grab the first active lane.  Note we can't call haloFindAnActiveLane
       because we haven't finalized this warp's state yet. */
    res = dev->halo.readActiveMask(dev, vsm, wp, &activeMask);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Error reading active mask (res = %d)\n", res);
        return res;
    }

    for (ln = 0; ln < dev->halo.deviceInfo.numLanesPrWarp; ln++) {
        if (activeMask & (1ULL << ln))
            break;
    }

    if (ln == dev->halo.deviceInfo.numLanesPrWarp) {
        HALO_ERROR("Error finding an active lane\n");
        return CUDBG_ERROR_INVALID_WARP;
    }

    /* See if we already have a grid for this gridId.  If so,
       then we need to see if it requires an update -- if not,
       return early and if so, update it and post it.  A special
       case is the scheduler kernel, which never requires an
       update (so we can always early exit). */
    grid = haloStateDeviceGetGrid(dev, gridId64);
    if (grid) {
        /* Sched kernel doesn't require an update */
        uint32_t hideReservedKernels = 1;
        uint32_t forceRepost = 0;

        /* Assign the self QMD Dptr here as we need it for host and device
           launched grids. Note that this may be zero in the case where
           the application does not do CNP. */
        grid->selfQMDdptr = selfQMDdptr;

#ifndef RELEASE
        if (cudbgEnableInternalDebugging) {
            hideReservedKernels = 0;
            if ((grid->function->type == DEV_FUNC_TYPE_SYSCALL) ||
                (grid->function->type == DEV_FUNC_TYPE_GLOBAL_SYSCALL) ||
                (grid->function->type == DEV_FUNC_TYPE_DRIVER_PATCH))
                forceRepost = 1;
        }
#endif

        if (hideReservedKernels && isReserved) {
            HALO_TRACE_FUNCTION(1, "vsm%u/wp%u: Saw reserved gridId\n", vsm, wp);
            return CUDBG_SUCCESS;
        }

        if (forceRepost || grid->state == HALO_GRID_STATE_INVISIBLE) {
            /* Let's see if this has moved forward to user code */
            res = dev->haloClient->updateUnpostedDynamicGrid(dev, vsm, wp, ln, &grid, physPC, &isPostable);
            if (res != CUDBG_SUCCESS) {
                HALO_ERROR("Failed to update grid\n");
                return res;
            }

            /* grid might have been overwritten */
            grid->selfQMDdptr = selfQMDdptr;

            /* The grid can either be in user code (postable) or in CNP code (non-postable).
             * The grid creation code sets function = userEntryFunction. If the grid is in
             * user code, the above assignment is valid. If not, halo.getUserEntryFunction()
             * will get the correct userEntryFunction and must be used to set the value of
             * grid->userEntryFunction. This ensures that the getGridInfo() debug API call
             * always returns valid data even if the grid is not visible.
             * Since the grid could have been recreated by updateDynamicGrid(), we need to
             * refresh grid->userEntryFunction(). */
            if (!isPostable) {
                res = dev->halo.getUserEntryFunction(dev, context, vsm, wp, ln, grid,
                                                     &grid->userEntryFunction);
                CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to find userEntryFunction!\n");

                return CUDBG_SUCCESS;
            }
            else
                goto post_grid_and_return;
        }
        else {
            /* Otherwise, we already have a regular grid, so
               just return early. */
            HALO_TRACE_FUNCTION(1, "Already have a grid\n");
            return CUDBG_SUCCESS;
        }
    }

    /* Collect all information about the grid from this warp's scratchpad.
       Then, find the function launched by this warp from the device, and
       allocate a proper grid structure for it. */
    res = dev->halo.scratchpad.read_blockDim(context->scratchpadAccessor, vsm, wp, &blockDim);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read block dimensions\n");

    res = dev->halo.scratchpad.read_gridDim(context->scratchpadAccessor, vsm, wp, &gridDim);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read grid dimensions\n");

    res = dev->halo.scratchpad.read_paramConstDptr(context->scratchpadAccessor, vsm, wp, &dev->smState[vsm].warp[wp].paramConstDptr);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read paramConstDptr\n");

    HALO_TRACE_FUNCTION(1, "paramConstDptr = 0x%016" PRIx64 "\n", dev->smState[vsm].warp[wp].paramConstDptr);

    if (!isReserved) {
        res = dev->halo.readUserEntryFramePC(dev, vsm, wp, ln, &foundUserEntry, &userEntryPC);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Error reading user entry frame PC\n");
            return res;
        }

        if (foundUserEntry) {
            HALO_TRACE_FUNCTION(5, "Found user entry frame PC: 0x%" PRIx64 "\n", userEntryPC);
            physPC = userEntryPC;
        }
    }

    /* Invoke the callback in the API layer of the debugger to construct the grid */
    res = dev->haloClient->createDynamicGrid(dev, vsm, wp, ln, gridId64, physPC, gridDim,
                                             blockDim, &isPostable);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to dynamically create a grid (res=%d)\n", res);
        return res;
    }

    /* We should always have a grid at this point */
    grid = haloStateDeviceGetGrid(dev, gridId64);
    CUDBG_VERIFY(grid, CUDBG_ERROR_INTERNAL, "Cannot find newly created dymamic grid!\n");

    /* This will be 0 on architectures that don't have QMDs */
    grid->selfQMDdptr = selfQMDdptr;

    /* The grid can either be in user code (postable) or in CNP code (non-postable).
     * The grid creation code sets function = userEntryFunction. If the grid is in
     * user code, the above assignment is valid. If not, halo.getUserEntryFunction()
     * will get the correct userEntryFunction and must be used to set the value of
     * grid->userEntryFunction. This ensures that the getGridInfo() debug API call
     * always returns valid data even if the grid is not visible. */
    if (!isPostable) {
        res = dev->halo.getUserEntryFunction(dev, context, vsm, wp, ln, grid,
                                             &grid->userEntryFunction);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to find userEntryFunction!\n");

        return CUDBG_SUCCESS;
    }

post_grid_and_return:
    /* halo.findParentGrid maps global memory, not all DMALs support this.
       Additionally, don't let scheduler kernels go down this path (can
       happen with internal debugging enabled). */
    if (haloGlobals.initData.haloDmalType == HALO_DMAL_TYPE_RM && !isReserved &&
        grid->origin == CUDBG_KNL_ORIGIN_GPU) {
        /* Find the parent grid ID before posting, as cuda-gdb expects the
           kernel event to have this information. */
        res = dev->halo.findParentGrid(dev, grid, &parentGrid);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to get parent grid info for gridId %" PRId64 " (res = %d)!\n", grid->gridId64, res);
            return res;
        }
        grid->parentGridId64 = parentGrid->gridId64;
        grid->hostStreamId   = parentGrid->hostStreamId;
    }

    /* If this grid can now be posted, then post it */
    res = dev->haloClient->postGridEvent(dev,
                                         dev->activeContext,
                                         grid,
                                         grid->function);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to post grid event\n");
        return res;
    }

    return CUDBG_SUCCESS;
}

CUDBGResult haloReadCCRegister(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                               uint32_t predLmemAddr, uint32_t *cc)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t predicateReg = 0;
    uint32_t ccShift = 0, ccBitmask = 0;

    CUDBG_VERIFY(cc, CUDBG_ERROR_INVALID_ARGS, "Invalid args in fermi_readCCRegister\n");

    /* Query the CC shift value and bitmask */
    res = dev->halo.getCCMasks(dev, &ccShift, &ccBitmask);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to get CC shift value and bitmask\n");
        return res;
    }

    /* Read predicate register from lmem */
    res = dev->halo.readLocalMemory(dev, vsm, wp, ln, predLmemAddr, &predicateReg, sizeof predicateReg);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read predicate register (CC bits) from lmem\n");
        return res;
    }

    /* CC bits are in a bitfield of the predicate register (this is chip-specific) */
    *cc = (predicateReg >> ccShift) & ccBitmask;

    return res;
}

CUDBGResult haloWriteCCRegister(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                                uint32_t predLmemAddr, const uint32_t cc)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t predicateReg = 0;
    uint32_t ccShift = 0, ccBitmask = 0;

    /* Query the CC shift value and bitmask */
    res = dev->halo.getCCMasks(dev, &ccShift, &ccBitmask);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to get CC shift value and bitmask\n");
        return res;
    }

    /* Read existing predicate register from lmem */
    res = dev->halo.readLocalMemory(dev, vsm, wp, ln, predLmemAddr, &predicateReg, sizeof predicateReg);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read predicate register (CC bits) from lmem\n");
        return res;
    }

    /* Modify CC bits of predicate register based on inputs */
    predicateReg = (predicateReg & ~(ccBitmask << ccShift)) | ((cc & ccBitmask) << ccShift);

    /* Write updated predicate register back to lmem */
    res = dev->halo.writeLocalMemory(dev, vsm, wp, ln, predLmemAddr, &predicateReg, sizeof predicateReg);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to write predicate register (CC bits) to lmem\n");
        return res;
    }

    return res;
}

static CUDBGResult
haloDebugObjectWriteMemory(Context ctx, uint64_t devvaddr, void *buf, uint64_t bufSz)
{
    CUDBGResult res;
    void* cachePtr = NULL;
    uint64_t cachevaddr = 0, cacheSz = 0;

    CUDBG_VERIFY(ctx && buf && bufSz, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    if (haloStateSwCacheEnabled()) {
        res = haloMemoryWriteSwCache(ctx->memMap, devvaddr, bufSz, buf);

        if (res == CUDBG_SUCCESS)
            return res;

        CUDBG_VERIFY(res == CUDBG_ERROR_MISSING_DATA, CUDBG_ERROR_INTERNAL,
                     "Failed to write SW cache.\n");

        /*
         * Flush and invalidate before direct write, therefore the next read will
         * fetch and up-to-date version of the segment.
         */
        haloMemoryRangeCacheOp(ctx->memMap, devvaddr, bufSz, HALO_MEM_SEG_CACHE_INVALIDATE);

        HALO_TRACE_FUNCTION(20, "Cache miss: Performing direct write.\n");
    }

    res = ctx->dev->dmal->debugObjectAccessMemory(ctx, devvaddr, buf, bufSz,
                                                  HALO_MEMORY_ACCESS_TYPE_WRITE);

    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to write memory\n");

    return res;
}

static CUDBGResult
haloDebugObjectReadMemory(Context ctx, uint64_t devvaddr, void *buf, uint64_t bufSz)
{
    CUDBGResult res;
    void* cachePtr = NULL;
    uint64_t cachevaddr = 0, cacheSz = 0;

    CUDBG_VERIFY(ctx && buf && bufSz, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    if (haloStateSwCacheEnabled()) {
        res = haloMemoryReadSwCache(ctx->memMap, devvaddr, bufSz, buf);

        if (res == CUDBG_SUCCESS)
            return res;

        CUDBG_VERIFY(res == CUDBG_ERROR_MISSING_DATA, CUDBG_ERROR_INTERNAL,
                     "Failed to read SW cache.\n");

        haloMemoryRangeCacheOp(ctx->memMap, devvaddr, bufSz, HALO_MEM_SEG_CACHE_FLUSH);

        HALO_TRACE_FUNCTION(60, "Cache miss: Performing direct read.\n");
    }

    res = ctx->dev->dmal->debugObjectAccessMemory(ctx, devvaddr, buf, bufSz,
                                                  HALO_MEMORY_ACCESS_TYPE_READ);

    /* Some read failures are expected, like ERROR_ADDRESS_NOT_IN_DEVICE_MEMORY */
    if (res != CUDBG_SUCCESS)
        HALO_TRACE(10, "Failed to read directly from devvaddr %#" PRIx64 " res=%#x\n", devvaddr, res);

    return res;
}

CUDBGResult
haloIsPatchEntry(uint64_t gpuAddr, Context ctx, DebugPatch *patch,
                 uint32_t filter, bool *result)
{
    DebugPatch atHop;

    CUDBG_VERIFY(ctx && ctx->patchEntry, CUDBG_ERROR_INVALID_CONTEXT,
                 "Invalid context in haloIsPatchEntry.\n");

    CUDBG_VERIFY(patch && result, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments in haloIsPatchEntry.\n");

    atHop = (DebugPatch)toolsHashMapFind(ctx->patchEntry, tHashMapNumToKey(gpuAddr));
    if (atHop && (atHop->kind & filter)) {
        *patch = atHop;
        *result = true;
        return CUDBG_SUCCESS;
    }
    *patch = NULL;
    *result = false;
    return CUDBG_SUCCESS;
}

CUDBGResult
haloInPatchRegion(uint64_t addr, Context ctx, DebugPatch *patch,
                  uint32_t filter, bool *result, bool isVirtAddr)
{
    DebugPatch inPatch;

    CUDBG_VERIFY(ctx && ctx->gpuAddrToPatch && ctx->virtAddrToPatch,
                 CUDBG_ERROR_INVALID_CONTEXT,
                 "Invalid context in haloInPatchRegion.\n");

    CUDBG_VERIFY(patch, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments in haloInPatchRegion.\n");

    CUDBG_VERIFY(result, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments in haloInPatchRegion.\n");


    if (isVirtAddr) {
#ifndef RELEASE
        inPatch = (DebugPatch)toolsRangeMapLookupByAddr(ctx->virtAddrToPatch,
                                                        addr);
#else
        inPatch = NULL;
#endif
    }
    else {
        inPatch = (DebugPatch)toolsRangeMapLookupByAddr(ctx->gpuAddrToPatch,
                                                        addr);
    }
    if (inPatch && (inPatch->kind & filter)) {
        *patch = inPatch;
        *result = true;
        return CUDBG_SUCCESS;
    }
    *patch = NULL;
    *result = false;
    return CUDBG_SUCCESS;
}

/*----------------------------- Hidden Function Handling -------------------------------*/

/*
 * Implemented as a function in case the hiding logic gets more
 * complicated than testing function->hidden.
 */
CUDBGResult haloInHiddenFunction(DeviceFunction function, bool *hidden)
{
    CUDBG_VERIFY(function, CUDBG_ERROR_INTERNAL, "Invalid function\n");
    CUDBG_VERIFY(hidden, CUDBG_ERROR_INTERNAL, "Invalid hidden arg\n");

    *hidden = false;

    /* If hidden function debugging, nothing is hidden */
    if (cudbgEnableHiddenFunctionDebugging)
        return CUDBG_SUCCESS;

    /* DEV_MOD_TYPE_HIDDEN_USER modules have function->hidden info */
    if (function->module->visibility == DEV_MOD_TYPE_HIDDEN_USER) {
        *hidden = function->hidden;
        if (*hidden)
            HALO_TRACE_FUNCTION(49, "hiding function %s (hidden flag)\n", function->name);
        return CUDBG_SUCCESS;
    }
    
    return CUDBG_SUCCESS;
}

CUDBGResult
haloReadRawPC(CudbgDevice dev, uint32_t sm, uint32_t wp, uint32_t ln, uint64_t *pc)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CUDBG_VERIFY(pc, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in readRawPC.\n");

    if (dev->smState[sm].warp[wp].activeMask & (1U << ln))
        res = dev->halo.readPC(dev, sm, wp, pc);
    else
        res = dev->halo.findDivergedCRS_PC(dev, sm, wp, ln, pc);

    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read PC for sm %d wp %d ln %d\n", sm, wp, ln);

    return dev->halo.adjustCodeAddress(*pc, pc, CUDBG_ADJ_CURRENT_ADDRESS);
}
