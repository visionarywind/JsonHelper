/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: kepler_gk20a.c
 *
 *   Description:
 *       Internal API for the low-level GPU access needed to support
 *       the debugger on Kepler (GK20A -- GPU for T124).
 *
 ******************************************************************************/

#include "kepler.h"
#include "halo_internal.h"
#include "kepler_gk20a.h"

// older Apple release builds only have old dt124, so keep pointing at those headers
#if cuosOsIsApple() && (NV_SDK_BRANCH_MAJ <= 313)
#include "kepler/dt124/dev_graphics_nobundle.h"
#include "kepler/dt124/dev_fb.h"
#else
#include "kepler/gk20a/dev_graphics_nobundle.h"
#include "kepler/gk20a/dev_fb.h"
#endif

static CUDBGResult
kepler_gk20a_setDebuggingModeMMU(Context ctx, uint32_t on)
{
    uint32_t v;
    CudbgDevice dev;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_ARGS, "Invalid context\n");
    dev = ctx->dev;

    if (dev->dmal->debugObjectCanSetMMUDebugMode()) {
        return dev->dmal->debugObjectSetMMUDebugMode(ctx, on);
    }

    /* Note: the MMU debug mode register was made context-switched on most architectures.
       T124 is deprecated at this moment, so we're leaving this code as is.
       For proper way to set the MMU debug mode see kepler_gk10x.c */

    /* GK20A variance with the rest of Kepler - there is only
       a single GPC on GK20A, which allowed for them to remove
       the per-GPC MMU altogether, and instead route everything
       through HUB MMU.

       So, set MMU debug mode for *HUB*.

       RM sets NV_PFB_PRI_MMU_DEBUG_{RD,WR} to set a dummy
       page that is used for all invalid reads/writes, which
       will prevent state corruption (Bug 655252 tracks this for
       fermi, the code for GK20A lives in kernel/gr/kepler/grgk20a.c
       in the resman tree). */
    res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GLOBAL, dev->bar0 + NV_PFB_PRI_MMU_DEBUG_CTRL, &v);
    if (res != CUDBG_SUCCESS)
        return res;

    v = SETFIELD32(v, NV_PFB_PRI_MMU_DEBUG_CTRL_DEBUG, on);

    res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GLOBAL, dev->bar0 + NV_PFB_PRI_MMU_DEBUG_CTRL, &v);
    if (res != CUDBG_SUCCESS)
        return res;

    return res;
}

static CUDBGResult
kepler_gk20a_enableMMUDebuggingMode(Context ctx)
{
    return kepler_gk20a_setDebuggingModeMMU(ctx, 1);
}

static CUDBGResult
kepler_gk20a_disableMMUDebuggingMode(Context ctx)
{
    return kepler_gk20a_setDebuggingModeMMU(ctx, 0);
}


static CUDBGResult
kepler_gk20a_checkAnyLaneInContinuation(CudbgDevice dev, uint32_t vsm, CUwarpBitmask *wpmask, bool *inContinuation)
{
    CUDBG_VERIFY(dev && inContinuation, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");
    *inContinuation = false;

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk20a_checkWarpNeedsHostResume(CudbgDevice dev, uint32_t vsm, uint32_t wp, bool *needsHostResume)
{
    CUDBG_VERIFY(dev && needsHostResume, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");
    *needsHostResume = false;

    return CUDBG_SUCCESS;
}

/* Populate the debugger structure with Kepler GK20A specific functions. */
void
haloDeviceInit_gk20a(Halo_st *halo)
{
    /* Share GK110 initializtion for GK20A,
       as most things are shared (ISA/opcodes), but there
       will be no work creation, and MMU is different.
       Those variances will be covered in the gk20a init. */
    haloDeviceInit_gk110(halo);

    /* GK20A - account for the removal of GPC MMU (HUB MMU is in charge) */
    halo->enableMMUDebuggingMode = kepler_gk20a_enableMMUDebuggingMode;
    halo->disableMMUDebuggingMode = kepler_gk20a_disableMMUDebuggingMode;

    /* GK20A - CNP is not possible on this architecture */
    halo->checkAnyLaneInContinuation = kepler_gk20a_checkAnyLaneInContinuation;
    halo->checkWarpNeedsHostResume = kepler_gk20a_checkWarpNeedsHostResume;
}
