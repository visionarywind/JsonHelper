/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: kepler_gk10x.c
 *
 *   Description:
 *       Internal API for the low-level GPU access needed to support
 *       the debugger on Kepler (GK10x).
 *
 ******************************************************************************/

#include "fermi.h"
#include "kepler.h"
#include "halo_internal.h"
#include "fermi_sass.h"
#include "gk10x_sass.h"
#include "kepler/gk104/dev_graphics_nobundle.h"
#include "kepler/gk104/dev_top.h"
#include "kepler/gk104/dev_pri_ringmaster.h"
#include "rm_call.h"
#include "rm_device.h"
#include "common_device.h"
#include "halo_state.h"
#include "cuicnp.h"
#include "cuda_macros.h"

CUDBGResult
kepler_gk10x_getInfo(CudbgDevice dev)
{
    CUDBGResult res;

    res = fermi_getInfo(dev);

    /* Overwrite the constants that are different */
    dev->halo.deviceInfo.numRegsPrLane       = CUDBG_MAX_REG_KEPLER_10X;
    dev->halo.deviceInfo.numPredicatesPrLane = KEPLER_NUM_PREDICATES;
    dev->halo.deviceInfo.maxGPCsPrDevice     = CUDBG_MAX_GPC_KEPLER;
    dev->halo.deviceInfo.bpt64Inst           = KEPLER_GK10X_BREAKPT64;

    dev->halo.deviceInfo.lmemHiMembarWarSpillR0 = KEPLER_LMEM_HI_MEMBAR_WAR_SPILL_R0;
    dev->halo.deviceInfo.lmemHiMembarWarSpillR2 = KEPLER_LMEM_HI_MEMBAR_WAR_SPILL_R2;
    dev->halo.deviceInfo.lmemHiMembarWarSpillR3 = KEPLER_LMEM_HI_MEMBAR_WAR_SPILL_R3;

    return res;
}

static CUDBGResult
kepler_gk10x_setKnownEvent(CudbgDevice dev, CudbgSMState_t *state)
{
    CUDBG_VERIFY(state, CUDBG_ERROR_INTERNAL, "Invalid args\n");

    /* On Kepler, include warps that executed a breakpoint,
       or that hit a global/warp error.  However, we need
       to mask the global esr bits as they include information
       that is not indicative of a reason for trapping (if only
       BPT.PAUSE is present in the global esr) */
    state->knownEvent = warpBitmaskAny(&state->brokenwarps) ||
                        state->esrState.hwwwarpesr ||
                        (state->esrState.hwwglobalesr & KEPLER_PRI_GLOBAL_ESR_ERROR_MASK);

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_rewindBrokenWarp(Context context, uint32_t vsm, uint32_t wp)
{
    CUDBGResult res;
    CudbgWarp_t *warp;
    CudbgDevice dev;
    uint64_t pc;
    Breakpoint bp;

    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context in rewindBrokenWarp.\n");

    dev = context->dev;
    warp = &dev->smState[vsm].warp[wp];

    /* Find the previous instruction */
    res = dev->halo.adjustCodeAddress(warp->pc, &pc, CUDBG_ADJ_PREVIOUS_ADDRESS);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to back up pc 0x%08x\n", warp->pc);

    /* See if there's a breakpoint on it */
    res = dev->halo.findBreakpoint(context, pc, &bp);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to find breakpoints\n");

    /* If the breakpoint mask for some reason wasn't reset
       then we could be backing up a warp that shouldn't be. */
    if (bp) {
        HALO_TRACE_FUNCTION(3, "vsm%d/%d backing pc up 0x%08x -> 0x%016" PRIx64 "\n", vsm, wp, warp->pc, pc);
        warp->pc = pc;
        res = dev->halo.writePC(dev, vsm, wp, warp->pc);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Call to writePC failed in rewindBrokenWarp.\n");
    }
    else
        HALO_TRACE_FUNCTION(3, "User-inserted breakpoint ignored at 0x%016" PRIx64 "\n", pc);

    return CUDBG_SUCCESS;
}

static CUDBGResult kepler_gk10x_insertBreakpoint(Context context, uint64_t vaddr, BreakpointContents *buf)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CudbgDevice dev;

    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context in insertBreakpoint.\n");

    dev = context->dev;

    if (!CUDBG_DEBUG_OBJECT_IS_VALID(context->debugObj)) {
        /* This can happen if no ctx creation callback has been received yet
           during early stages of the app, or during shutdown. */
        HALO_TRACE_FUNCTION(50, "No debug object found, skipping breakpoint insertion.\n");
        return CUDBG_ERROR_INVALID_CONTEXT;
    }

    buf->savedInstructionSize = sizeof(uint64_t);

    res = dev->halo.readDeviceMemory(context, vaddr, buf->savedInstruction, buf->savedInstructionSize);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Error reading code mem at addr %" PRIx64 " (res = %d)\n", vaddr, res);
        return res;
    }

    res = dev->halo.writeDeviceMemory(context, vaddr, &dev->halo.deviceInfo.bpt64Inst, sizeof dev->halo.deviceInfo.bpt64Inst);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Error writing code mem at addr %" PRIx64 " (res = %d)\n", vaddr, res);
        return res;
    }

    /* Set the device's code memory as dirty */
    dev->codeIsDirty = 1;

    HALO_TRACE_FUNCTION(1, "Breakpoint inserted at 0x%" PRIx64 ". Original instruction was 0x%" PRIx64 "\n",
                        vaddr, buf->savedInstruction[0]);

    return CUDBG_SUCCESS;
}

static CUDBGResult kepler_gk10x_removeBreakpoint(Context context, uint64_t vaddr, const BreakpointContents *buf)
{
    CUDBGResult res;
    CudbgDevice dev;

    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context in removeBreakpoint.\n");
    CUDBG_VERIFY(buf->savedInstructionSize > 0, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    dev = context->dev;

    res = dev->halo.writeDeviceMemory(context, vaddr, buf->savedInstruction, buf->savedInstructionSize);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Error writing code mem at addr 0x%" PRIx64 " (res = %d)\n", vaddr, res);
        return res;
    }

    /* Set the device's code memory as dirty */
    dev->codeIsDirty = 1;

    HALO_TRACE_FUNCTION(1, "Breakpoint removed at 0x%" PRIx64 ". Original instruction was 0x%" PRIx64 "\n",
                        vaddr, buf->savedInstruction[0]);

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_readWarpErrors(CudbgDevice dev, uint32_t vsm, uint32_t wp)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t globalErrorStatus, warpErrorStatus;
    Context context = dev->activeContext;

    res = dev->halo.scratchpad.read_globalErrorStatus(context->scratchpadAccessor, vsm, wp, &globalErrorStatus);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read global error status\n");

    res = dev->halo.scratchpad.read_warpErrorStatus(context->scratchpadAccessor, vsm, wp, &warpErrorStatus);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read warp error status\n");

    /* Kepler/CNP:  A bit in the global ESR indicates if any warp is in
       an IDE-protected region.  Simply save this state off here -- but
       it is not an actual error (so don't raise an error report) */
    dev->smState[vsm].state.inIDECS = (bool)(globalErrorStatus & KEPLER_IDE_REGION_MASK);

    res = fermi_setExceptionState(dev, vsm, wp, globalErrorStatus,
                                  warpErrorStatus);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Error when setting exception state in kepler_gk10x_readWarpErrors.\n");
        return res;
    }

    return CUDBG_SUCCESS;
}

static int32_t
kepler_gk10x_isMulti(CudbgDevice dev, uint64_t instruction)
{
    /* Wiki on MULTI instructions can be found here:
       https://wiki.nvidia.com/gpuhwkepler/index.php/SM_Arch/uarch/scheduler#Multi_Issue

       Note:  most of the opcodes being checked will never show up in CUDA kernels,
              but they are here for completeness.  */
    const uint64_t KEPLER_LDC_OP_MASK   = 0xfc0000000000000fULL;
    const uint64_t KEPLER_LDC_OP        = 0x1400000000000006ULL;

    const uint64_t KEPLER_IPA_OP_MASK   = 0xf10000000000000fULL;
    const uint64_t KEPLER_IPA_OP        = 0xc000000000000000ULL;

    const uint64_t KEPLER_AL2P_OP_MASK  = 0xfc0000000000000fULL;
    const uint64_t KEPLER_AL2P_OP       = 0x0c00000000000006ULL;

    const uint64_t KEPLER_PIXLD_OP_MASK = 0xfc0000000000000fULL;
    const uint64_t KEPLER_PIXLD_OP      = 0x1000000000000006ULL;

    if ((instruction & KEPLER_LDC_OP_MASK)   == KEPLER_LDC_OP   ||
        (instruction & KEPLER_IPA_OP_MASK)   == KEPLER_IPA_OP   ||
        (instruction & KEPLER_AL2P_OP_MASK)  == KEPLER_AL2P_OP  ||
        (instruction & KEPLER_PIXLD_OP_MASK) == KEPLER_PIXLD_OP)
        return 1;
    else
        return 0;
}

static int32_t
kepler_gk10x_isShint(CudbgDevice dev, uint64_t instruction)
{
    /* GK10X:  SHINT Instruction Masks */
    const uint64_t KEPLER_GK10X_SHINT_OP_MASK = 0xf00000000000000fULL;
    const uint64_t KEPLER_GK10X_SHINT_OP      = 0x2000000000000007ULL;

    if ((instruction & KEPLER_GK10X_SHINT_OP_MASK) == KEPLER_GK10X_SHINT_OP)
        return 1;
    else
        return 0;
}

CUDBGResult
kepler_gk10x_isWarpOnBarrier(CudbgDevice dev, uint32_t vsm,
                             uint32_t wp, bool *isOnBarrier)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(isOnBarrier, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in isWarpOnBarrier.\n");

    /* It is not an error to not have an active context when this is
       called, however, we cannot attempt to map memory if that's the
       case.  Simply return success here. */
    if (!dev->activeContext || !haloStateContextIsActive(dev->activeContext))
        return CUDBG_SUCCESS;

    res = dev->halo.scratchpad.read_isWarpOnBarrier(dev->activeContext->scratchpadAccessor, vsm, wp, isOnBarrier);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read warp barrier state\n");

    return res;
}

CUDBGResult
kepler_gk10x_read_warpParams(CudbgDevice dev,
                             uint32_t vsm,
                             uint32_t wp,
                             uint32_t valid,
                             uint32_t *virtCTAID,
                             uint32_t *CTASharedSize,
                             uint32_t *floorsweptSmId)
{
    Context context = dev->activeContext;
    CUDBGResult res = CUDBG_SUCCESS;

    /* If this warp is not valid, do not perform the unmappings */
    if (!valid) {
        HALO_TRACE_FUNCTION(20, "Invalid warp, returning early.\n");
        return CUDBG_SUCCESS;
    }

    /* If no active context, there is nothing to do. */
    if (!context) {
        HALO_TRACE_FUNCTION(20, "Invalid context, returning early.\n");
        return CUDBG_SUCCESS;
    }

    /* Read blockIdx.  KILP found this issue, but we were relying
       on the frontend to perform the query on blockIdx.  We need
       to always make sure the backend has collected this, as it
       is used for barrier-stepping (knowing which warps are in
       which CTA) -- KILP does not allow the frontend to query this
       in between restore-step-preempt phases, so it was incorrect. */
    res = dev->halo.read_blockIdx(dev, vsm, wp, &dev->smState[vsm].warp[wp].blockIdx);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE_FUNCTION(20, "Failed to read blockIdx (res=%d)\n", res);
        return res;
    }

    res = dev->halo.scratchpad.read_smIds(context->scratchpadAccessor, vsm, wp, virtCTAID, floorsweptSmId);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read SM ids\n");

    res = dev->halo.scratchpad.read_CTASharedSize(context->scratchpadAccessor, vsm, wp, CTASharedSize);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read CTA shared size\n");

    /* Check that we have a grid -- if not, dynamically build a grid structure. */
    res = haloCreateDynamicGrid(dev, vsm, wp);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Could not dynamically create grid!\n");

    /* Check this warp for errors */
    return kepler_gk10x_readWarpErrors(dev, vsm, wp);
}

static CUDBGResult
kepler_gk10x_read_threadIdx(CudbgDevice dev,
                            uint32_t vsm, uint32_t wp, uint32_t lane,
                            uint32_t threadBlockDimZ,
                            uint32_t *thrX, uint32_t *thrY, uint32_t *thrZ)
{
    CUDBGResult res;
    CuDim3 threadIdx;
    Context context = dev->activeContext;

    /* If no active context, there is nothing to do. */
    if (!context) {
        HALO_TRACE_FUNCTION(20, "No active context found, returning early.\n");
        return CUDBG_SUCCESS;
    }

    res = dev->halo.scratchpad.read_threadIdx(context->scratchpadAccessor, vsm, wp, lane, &threadIdx);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read threadIdx\n");

    *thrX = threadIdx.x;
    *thrY = threadIdx.y;
    *thrZ = threadIdx.z;

#if 0
    /* Scan for potential threadIdx corruption.  During GK110 bringup,
       we discovered that single-thread CTAs will launch with a block
       of repeated threadIdx values within a warp (0,1,2,3,0,1,2,3,...).
       That's done by design in HW; however, we should never observe a
       valid lane that is part of the repetition.  Scream loudly if we
       see it, but don't assert or error out as we'd like to continue
       to investigate state. */
    if ((*thrX % 32) != lane)
        HALO_ERROR("!!! VSM%u/WP%u/LN%u:  THREADIDX CORRUPTION! (threadIdx.x = %u))\n",
                   vsm, wp, lane, *thrX);
#endif

    return CUDBG_SUCCESS;
}

/* Collect data from the trap handler scratchpad */
static CUDBGResult
kepler_gk10x_collectScratchpad(CudbgDevice dev, uint32_t vsm)
{
    /* Scratchpad data for each warp */
    uint64_t warpRawLmemBase, lmemBase;
    uint32_t wp;
    bool forceNonDefault = false;
    Context context = dev->activeContext;
    CudbgWarp_t *warp;
    CUDBGResult res;
    HaloLmemConfig_t *warpLmem;
    uint32_t lmemLoSizePrThread, warpErrorStatus;

    /* If no active context, there is nothing to do. */
    if (!context) {
#ifndef RELEASE
        for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
            warp = &dev->smState[vsm].warp[wp];
            memset(&warp->lmemConfig, 0, sizeof warp->lmemConfig);
            warp->gridId64 = ~0ULL;
        }
#endif
        HALO_TRACE_FUNCTION(20, "No active context found, returning early.\n");
        return CUDBG_SUCCESS;
    }

    /* Collect each warp's scratchpad data */
    for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
        /* Skip invalid warps (they can have stale entries in their scratchpad) */
        if (!warpBitmaskGetBits(&dev->smState[vsm].state.tidValid, wp, 1))
            continue;

        warp = &dev->smState[vsm].warp[wp];
        warpLmem = &warp->lmemConfig;

        /* Keep LMemHiOff around, we'll need it when checking for user
           stack overflows (ABI compilations) */
        res = dev->halo.scratchpad.read_lmemHiOff(context->scratchpadAccessor, vsm, wp, &warpLmem->lmemHiOff);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get lmem hi offset\n");

        /* Get the lmem window size (should always be 16MB) */
        res = dev->halo.scratchpad.read_lmemWindowSize(context->scratchpadAccessor, vsm, wp, &warpLmem->windowSize);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get lmem window size\n");

        /* Get the lmem lo and high sizes (per warp)

           From S2R HW doc:
             [SR54] Local memory low allocated size in bytes per thread, multiple of 16B
             [SR55] Local memory high allocated offset in bytes per thread, multiple of 16B
             LMemHiOff = LWINSZ - LMemHiSz;
             LMemHiSz is allocated size in bytes per thread.
           So:
             LmemLoSizePrWarp = LmemLoSz * warpSize;
             LmemHiSzPrWarp = (LWINSZ - LMemHiOff) * warpSize; */
        res = dev->halo.scratchpad.read_lmemLoSizePrThread(context->scratchpadAccessor, vsm, wp, &lmemLoSizePrThread);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get lmem lo size per warp\n");
        warpLmem->loSize = lmemLoSizePrThread * dev->halo.deviceInfo.numLanesPrWarp;
        warpLmem->hiSize = (warpLmem->windowSize - warpLmem->lmemHiOff) *
                           dev->halo.deviceInfo.numLanesPrWarp;

        /* Get the CRS size (per warp).  This is pushed down as CTAParam
           in the CUDA Driver. */
        res = dev->halo.scratchpad.read_CRSSize(context->scratchpadAccessor, vsm, wp, &warpLmem->CRSSize);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get crs size\n");

        /* Save off this warp's lmem base into the dev structure.
           This is GK11x specific and should be moved there. */
        res = dev->halo.getLmemBase(dev, vsm, wp, &warpRawLmemBase);
        warp->lmemBase     = (warpRawLmemBase << 1) >> 1;
        HALO_TRACE_FUNCTION(20, "sm%u wp%u warpRawLmemBase 0x%" PRIx64 "\n", vsm, wp, warpRawLmemBase);
        HALO_TRACE_FUNCTION(20, "sm%u wp%u warp->lmemBase 0x%" PRIx64 "\n", vsm, wp, warp->lmemBase);
        HALO_TRACE_FUNCTION(20, "sm%u wp%u context->defaultLmemDevVA 0x%" PRIx64 "\n",
                            vsm, wp, context->defaultLmemDevVA);

        res = dev->halo.forceScratchpadLmemBase(dev, &forceNonDefault);
        CUDBG_VERIFY((res == CUDBG_SUCCESS), res,
                     "vsm%u/wp%u: Unable to get lmemSegType preference\n", vsm, wp);

        warp->lmemSegType  = (warpRawLmemBase >> 63 || forceNonDefault) ?
                             HALO_MEM_SEG_LOCAL_NONDEFAULT :
                             HALO_MEM_SEG_LOCAL_DEFAULT;

        lmemBase = (warp->lmemSegType == HALO_MEM_SEG_LOCAL_NONDEFAULT) ?
                   warp->lmemBase :
                   context->defaultLmemDevVA;

        HALO_TRACE_FUNCTION(20, "sm%u wp%u lmemSegType %d lmemBase 0x%" PRIx64 "\n",
                            vsm, wp, warp->lmemSegType, lmemBase);

        /* Save off the lmem segment corresponding to this warp's lmem base */
        res = haloMemoryMapGetSegmentByDevVaddr(context->memMap,
                                                lmemBase,
                                                &warp->lmemSeg);
        CUDBG_VERIFY((res == CUDBG_SUCCESS),
                     res,
                     "vsm%u/wp%u: Can't locate lmemSeg in collectScratchpad, res 0x%x\n", vsm, wp, res);
        CUDBG_VERIFY(warp->lmemSeg,
                     CUDBG_ERROR_INVALID_MEMORY_SEGMENT,
                     "vsm%u/wp%u: Can't locate lmemSeg in collectScratchpad\n", vsm, wp);

        /* Store grid ID directly into device state */
        res = dev->halo.scratchpad.read_gridId(context->scratchpadAccessor, vsm, wp, &warp->gridId64);
        CUDBG_VERIFY((res == CUDBG_SUCCESS), res,
                     "vsm%u/wp%u: Unable to read gridId\n", vsm, wp);

        /* Param constbank backing store dptr */
        res = dev->halo.scratchpad.read_paramConstDptr(context->scratchpadAccessor, vsm, wp, &warp->paramConstDptr);
        CUDBG_VERIFY((res == CUDBG_SUCCESS), res,
                     "vsm%u/wp%u: Unable to read paramConstDptr\n", vsm, wp);

        /* Get the MPS parent context ID */
        res = dev->halo.scratchpad.read_mpsContextId(context->scratchpadAccessor, vsm, wp, &warp->mpsContextId);
        CUDBG_VERIFY((res == CUDBG_SUCCESS), res,
            "vsm%u/wp%u: Unable to read warp error status\n", vsm, wp);

        res = dev->halo.scratchpad.read_warpErrorStatus(context->scratchpadAccessor, vsm, wp, &warpErrorStatus);
        CUDBG_VERIFY((res == CUDBG_SUCCESS), res,
            "vsm%u/wp%u: Unable to read warp error status\n", vsm, wp);

        HALO_TRACE_FUNCTION(30, "vsm%d/wp%d -> LWINSZ: 0x%x, "
                            "warpESR: 0x%08x, "
                            "LMemLoSizePrWarp: 0x%x, "
                            "LMemHiSizePrWarp: 0x%x, "
                            "LMemCRSSizePrWarp: 0x%x, "
                            "GRIDParam: %#" PRIx64 ", "
                            "LWINSZ:  0x%x, "
                            "LMemLoSizePrThread: 0x%x, "
                            "LMemHiOff:  0x%x, "
                            "LMemBase:  0x%016" PRIx64 ", "
                            "LMemSegType: %d, "
                            "MPSContextId: 0x%x\n",
                            vsm, wp, warpLmem->windowSize,
                            warpErrorStatus,
                            warpLmem->loSize, warpLmem->hiSize,
                            warpLmem->CRSSize,
                            warp->gridId64, warpLmem->windowSize,
                            lmemLoSizePrThread, warpLmem->lmemHiOff,
                            warp->lmemBase, (int)(warp->lmemSegType),
                            warp->mpsContextId);
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_readLmemConfig(CudbgDevice dev, uint32_t vsm)
{
    CUDBGResult res = CUDBG_SUCCESS;

    /* Read out each warp's scratchpad data (which includes lmem sizes) */
    res = kepler_gk10x_collectScratchpad(dev, vsm);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to collectScratchpad failed in readLmemConfig.\n");
        return res;
    }

    return CUDBG_SUCCESS;
}

/* Kepler GK10x LMEM and CRS functions below */
static inline uint32_t
commonLocalAndCRS(CudbgDevice dev, uint32_t vsm, uint32_t tid, uint32_t warp_addr)
{
    /* Bugs 777914 and 777917:  Need to divide the lmemSizePerSM as hardware reports
       it in NV_PGRAPH_PRI_CWD_LMEM_SIZE_PER_SM by the number of warps per SM (on
       GK10x this is 64).  Adding up each individual lmem component is not sufficient
       since HW aligns this size to meet its own requirements. */
    uint32_t warpLmemSize = (uint32_t)dev->activeContext->lmemSizePerSM / dev->halo.deviceInfo.numWarpsPrSM;
    return vsm * (uint32_t)dev->activeContext->lmemSizePerSM + tid * warpLmemSize + warp_addr;
}

static CUDBGResult
kepler_gk10x_getLmemInternalOffset(CudbgDevice dev, uint32_t address,
                                   uint32_t vsm, uint32_t tid, uint32_t lane,
                                   uint32_t *offset)
{
    uint32_t warp_addr;
    HaloLmemConfig_t *warpLmem = &dev->smState[vsm].warp[tid].lmemConfig;

    CUDBG_VERIFY(offset, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in getLmemInternalOffset.\n");

    /* Detect an access to local high */
    if (address > warpLmem->windowSize / 2)
        address -= warpLmem->windowSize;

    warp_addr = ((address & 0xfffffffc) << 5) + (lane << 2) + (address & 0x3);
    warp_addr += warpLmem->hiSize + warpLmem->CRSSize;

    *offset = commonLocalAndCRS(dev, vsm, tid, warp_addr);
    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_getCRSInternalOffset(CudbgDevice dev, uint32_t vsm, uint32_t tid, uint32_t warp_addr, uint32_t *offset)
{
    CUDBG_VERIFY(offset, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in getCRSInternalOffset.\n");

    *offset = commonLocalAndCRS(dev, vsm, tid, warp_addr);
    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_CRSEntrySize(CudbgDevice dev, uint32_t *size)
{
    CUDBG_VERIFY(size, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in CRSEntrySize.\n");

    *size = KEPLER_GK10X_CRS_ENTRY_SIZE;
    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_CRSEntryPaddingSize(CudbgDevice dev, uint32_t *size)
{
    CUDBG_VERIFY(size, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in CRSEntryPaddingSize.\n");

    *size = KEPLER_GK10X_CRS_ENTRY_PADDING_SIZE;
    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_maxCRSEntriesPerWarp(CudbgDevice dev, uint32_t vsm, uint32_t tid, uint32_t *numEntries)
{
    CUDBG_VERIFY(numEntries, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in maxCRSEntriesPerWarp.\n");

    *numEntries = KEPLER_GK10X_MAX_CRS_ENTRIES_PER_WARP(vsm, tid);
    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_dumpCRS(CudbgDevice dev, uint32_t vsm, uint32_t tid, unsigned char *flatCRS, uint32_t depth)
{
    unsigned char *flatCRSLimit;
    uint32_t size;
    CUDBGResult res = CUDBG_SUCCESS;

    res = dev->halo.CRSEntrySize(dev, &size);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to CRSEntrySize failed in dumpCRS.\n");
        return res;
    }

    for (flatCRSLimit = flatCRS + depth * size; flatCRS < flatCRSLimit;
         flatCRS += size)
        HALO_TRACE(0, "\t(GK10x: CRS DUMP - vsm%d/tid%d): 0x%016" PRIx64 "%016" PRIx64 "\n",
                   vsm, tid, *(uint64_t *)((char *)(flatCRS+8)), *(uint64_t *)flatCRS);

    HALO_TRACE(0, "\n");

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_updateCRS(CudbgDevice dev, uint32_t vsm, uint32_t tid,
                       unsigned char *flatCRS, uint32_t trapIdx)
{
    uint64_t warpCRS;
    uint32_t offset_32, warpCRSSize = 0, numEntries = 0;
    bool usingCRSPtr = false;
    CUDBGResult res = CUDBG_SUCCESS;
    Context context = dev->activeContext;

    res = dev->halo.getWarpCRSUsage(dev, vsm, tid, &numEntries, &warpCRSSize, &usingCRSPtr);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to getWarpCRSUsage failed in updateCRS\n");
        return res;
    }

    /* We're writing back to CRS memory - make sure it's mapped in. */
    res = dev->halo.getCRSInternalOffset(dev, vsm, tid, 0, &offset_32);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to getCRSInternalOffset failed in updateCRS.\n");
        return res;
    }
    warpCRS = offset_32;

    /* GK10x - CRS is already 'flattened' (and contiguous) per warp */
    res = dev->halo.writeDeviceMemory(context,
                                      dev->smState[vsm].warp[tid].lmemSeg->devvaddr + warpCRS,
                                      flatCRS,
                                      warpCRSSize);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to writeDeviceMemory failed in updateCRS (res=%d).\n", res);
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_flattenCRS(CudbgDevice dev, uint32_t vsm, uint32_t tid, unsigned char *flatCRS)
{
    uint64_t warpCRS;
    uint32_t offset_32, warpCRSSize = 0, numEntries = 0;
    bool usingCRSPtr = false;
    CUDBGResult res = CUDBG_SUCCESS;
    Context context = dev->activeContext;

    res = dev->halo.getWarpCRSUsage(dev, vsm, tid, &numEntries, &warpCRSSize, &usingCRSPtr);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to getWarpCRSUsage failed in updateCRS\n");
        return res;
    }

    /* This is the first time we're reading CRS memory since the program has
       been suspended.  Ensure local memory allocation is mapped in. */
    res = dev->halo.getCRSInternalOffset(dev, vsm, tid, 0, &offset_32);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to getCRSInternalOffset failed in flattenCRS.\n");
        return res;
    }
    warpCRS = offset_32;

    /* GK10x - CRS is already 'flattened' (and contiguous) per warp */
    res = dev->halo.readDeviceMemory(context,
                                     dev->smState[vsm].warp[tid].lmemSeg->devvaddr + warpCRS,
                                     flatCRS,
                                     warpCRSSize);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to readDeviceMemory failed in flattenCRS (res=%d).\n", res);
        return res;
    }

#if 0
    {
        /* Debugging - dump flat CRS - the last arg is the # of entries to print */
        uint32_t numEntries;
        CUDBGResult res;

        res = dev->halo.maxCRSEntriesPerWarp(dev, vsm, tid, &numEntries);
        if (res != CUDBG_SUCCESS)
            return res;

        return kepler_gk10x_dumpCRS(dev, vsm, tid, flatCRS, numEntries);
    }
#endif

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_getScratchpadSharedMemDevVaddr(Context context, uint64_t *shmemDevVaddr)
{
    CUDBG_VERIFY(shmemDevVaddr && context, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    *shmemDevVaddr = context->scratchpadDevVA + KEPLER_GK10X_TRAP_HANDLER_SCRATCHPAD_OFFSET_SHARED;

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_setPairingMode(CudbgDevice dev, Context context, uint32_t on)
{
#if defined(NV_PGRAPH_PRI_GPCS_TPCS_SM_SCH_MICRO_SCHED) && \
    defined(NV_PGRAPH_PRI_GPCS_TPCS_SM_SCH_MICRO_SCHED_PAIRING)
    CUDBGResult res = CUDBG_SUCCESS;
    HaloRegOp script;
    uint32_t v;

    /* We need to use execRegOps here since we're modifying
       context-switched state, and we cannot be sure if this
       function is called at a point where the context in
       question is resident. */

    /* Clear the reg ops script */
    memset(&script, 0, sizeof script);

    script.regType       = HALO_REG_OP_TYPE_GR_CTX;
    script.regOp         = HALO_REG_OP_READ_32;
    script.regOffset     = NV_PGRAPH_PRI_GPC0_TPC0_SM_SCH_MICRO_SCHED;

    res = dev->dmal->execRegOps(dev, context, &script, 1);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Read via execRegOps failed in %s.\n", __FUNCTION__);
        return res;
    }

    /* Set the pairing mode for all GPCs and TPCs (finally, positive logic).
       It is unclear whether this will be necessary after emulation bugfixes
       or not, but it is what we want all the time, so this code should probably
       stay in place.  According to arch, it is not necessarily tied to setting
       debug mode on gk10x, as it was on gf10x, which introduced pairing. */
    v = script.regValueLo;
    v = SETFIELD32(v, NV_PGRAPH_PRI_GPCS_TPCS_SM_SCH_MICRO_SCHED_PAIRING, on);

    script.regType       = HALO_REG_OP_TYPE_GR_CTX;
    script.regOp         = HALO_REG_OP_WRITE_32;
    script.regOffset     = NV_PGRAPH_PRI_GPCS_TPCS_SM_SCH_MICRO_SCHED;
    script.regValueLo    = v;
    script.regAndNMaskLo = 0xffffffff;

    res = dev->dmal->execRegOps(dev, context, &script, 1);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Write via execRegOps failed in %s.\n", __FUNCTION__);
        return res;
    }
#endif
    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_enablePairingMode(CudbgDevice dev, Context context)
{
    return kepler_gk10x_setPairingMode(dev, context, 1);
}

static CUDBGResult
kepler_gk10x_disablePairingMode(CudbgDevice dev, Context context)
{
    return kepler_gk10x_setPairingMode(dev, context, 0);
}

static CUDBGResult
kepler_gk10x_isLastHwStepSynchronous(CudbgDevice dev, bool *isLastHwStepSynchronous)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(dev && isLastHwStepSynchronous,
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments in kepler_gk10x_isLastHwStepSynchronous.\n");


    /* Kepler HW *always* sends an interrupt when single-stepping. */
    *isLastHwStepSynchronous = true;

    return res;
}

/* Returns true in *isSteppable if the instruction at PC can be stepped,
   false otherwise. If not steppable, *breakAddr will contain the PC
   address where to insert a breakpoint to step that instruction, and
   *breakMask will contain the mask of warps to resume (low bit means
   resume). Otherwise, *breakAddr and *breakMask are untouched. */
static CUDBGResult
kepler_gk10x_isSteppable(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                         uint64_t pc, bool inPatch, uint64_t *breakAddr,
                         CUwarpBitmask *breakMask, bool *isSteppable,
                         bool *requiresExitStep)
{
    CUDBGResult res;
    uint64_t inst;
    bool isWarpOnBarrier = false;

    /* GK10x uses the same logic as GF100 when testing for steppable
       instructions, so we explicitly call it out here.  It also
       handles parameter checking and initialization.  However, there
       are additional instructions that need to be tested on GK10x. */
    res = fermi_isSteppable(dev, vsm, wp, pc, inPatch, breakAddr,
                            breakMask, isSteppable, requiresExitStep);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to fermi_isSteppable failed in isSteppable.\n");
        return res;
    }

    if (*isSteppable) {
        /* Kepler's BRU commits the BAR even if it's still waiting on it,
           which means the PC could point directly after the BAR instruction.
           We need to check for that here by examining B2R.WARP state, and
           if it indicates we're waiting on a barrier we need to break on
           *this* PC */
        res = kepler_gk10x_isWarpOnBarrier(dev, vsm, wp, &isWarpOnBarrier);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to isWarpOnBarrier failed (res=%d)\n", res);
            return res;
        }

        if (isWarpOnBarrier) {
            uint32_t tmpWp;
            HALO_TRACE(2, "  Found an unsteppable barrier (via B2R.WARP) at pc = %#" PRIx64 "\n", pc);
            /* Need to resume all warps in the same cta as this warp */
            warpBitmaskFill(breakMask, 1);
            warpBitmaskSetBits(breakMask, wp, 1, 0);
            for (tmpWp = 0; tmpWp < dev->halo.deviceInfo.numWarpsPrSM; ++tmpWp)
                if (haloWarpsInSameCTA(dev, vsm, wp, tmpWp))
                    warpBitmaskSetBits(breakMask, tmpWp, 1, 0);
            *breakAddr = pc;
            *isSteppable = false;
            return CUDBG_SUCCESS;
        }

        res = dev->halo.readCodeMemory(dev->activeContext, pc, &inst, sizeof inst);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to read memory from offset 0x%" PRIx64 "\n", pc);
            return res;
        }

        /* WAR Bug 784572:  Kepler GK10x introduced a bug with single-step logic
           where if a MULTI instruction is stepped forward, it can potentially
           bring the next instruction with it.  This is mostly caused by how
           MULTI instructions need to make 2 trips through the pipeline. */
        if (kepler_gk10x_isMulti(dev, inst)) {
            HALO_TRACE(2, "  Found an unsteppable MULTI instruction at pc = %#" PRIx64 "\n", pc);
            warpBitmaskFill(breakMask, 1);
            warpBitmaskSetBits(breakMask, wp, 1, 0);
            *breakAddr = pc + 8;
            *isSteppable = false;
            return CUDBG_SUCCESS;
        }

        /* Kepler SHINT instructions are 'special'.  They are not actual
           instructions, yet are the size of an instruction and reside in
           the instruction stream.  As a result, when SHINTs are active
           (inserted at the very beginning of a cacheline) they will not
           commit the PC until the next 'real' instruction commits.  To
           the end user, this looks like 2 instructions were stepped.  The
           fun part is if the SHINT is not active (not inserted at the very
           beginning of a cacheline, they are NOP'd, in which case they
           step 1 instruction.  To avoid this confusion, we mark SHINTs as
           not being steppable. */
        if (kepler_gk10x_isShint(dev, inst)) {
            HALO_TRACE(2, "  Found an unsteppable SHINT at pc = %#" PRIx64 "\n", pc);
            warpBitmaskFill(breakMask, 1);
            warpBitmaskSetBits(breakMask, wp, 1, 0);
            *breakAddr = pc + 8;
            *isSteppable = false;
            return CUDBG_SUCCESS;
        }
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_isInternalInstructionAtPC(CudbgDevice dev, uint64_t inst, uint64_t gpuAddr,
                                       bool *isInternalInstruction)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(isInternalInstruction, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args in kepler_gk10x_isInternalInstruction\n");

    /* Initialize to false (not an internal instruction) */
    *isInternalInstruction = false;

    if (kepler_gk10x_isShint(dev, inst)) {
        HALO_TRACE(2, "  Found an internal SHINT\n");
        *isInternalInstruction = true;
        return CUDBG_SUCCESS;
    }

    return res;
}

/* Clear exceptions for a given vsm, or all vsms.
   If vsm == -1, perform this operation on all vsms.
   Otherwise, perform this operation on the given vsm.

   Note:  the above applies only to SM interrupts, and
          not to FIFO control -- that is always global. */
static CUDBGResult
kepler_gk10x_clearExceptions(CudbgDevice dev, uint32_t vsm)
{
    uint32_t regVal;
    uint32_t regOffset = 0;
    CUDBGResult res = CUDBG_SUCCESS;

    /* WAR Bug 723023 (Found on Fermi, still applies to Kepler):
     *
     * Now that the CUDA driver wants to run with debug mode on in order
     * to support real system calls, there is a race that was discovered
     * between releasing a semaphore and reporting a user level event
     * for an exception occurring.  If the semaphore release wins the
     * race, then completion is reported, and in the worst case the
     * driver is torn down and nobody is left to receive the exception
     * being reported by RM.  Since TPC_EXCEPTION_EN_SM is disabled (see the
     * code that immediately follows this WAR), it causes bad behavior in
     * subsequent applications.  To fix that race, RM keeps FE "frozen"
     * when it initially receives the exception notification from
     * hardware, meaning that it prevents any more grfifo methods from
     * being processed in addition to preventing semaphore acquires and
     * releases.  Since RM is keeping FE frozen until a user client
     * receives the 'more important' exception, we now need to enable
     * those bits again.
     *
     * Note this is not a problem for the debugger directly (we are
     * always around -- even if the driver gets a semaphore release first,
     * we will receive that as an event, and then examine state anyway).
     * However, since the change is being made universally, we need to
     * adapt to it. */
    res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GLOBAL,
                                     dev->bar0 + NV_PGRAPH_GRFIFO_CONTROL, &regVal);
    if (res != CUDBG_SUCCESS)
        return res;

    regVal = SETFIELD32(regVal, NV_PGRAPH_GRFIFO_CONTROL_ACCESS, 1);
    regVal = SETFIELD32(regVal, NV_PGRAPH_GRFIFO_CONTROL_SEMAPHORE_ACCESS, 1);
    res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GLOBAL,
                                      dev->bar0 + NV_PGRAPH_GRFIFO_CONTROL, &regVal);
    if (res != CUDBG_SUCCESS)
        return res;

    /* To avoid multiple interrupt events arriving for a single instance of
     * the entire GPU coming to a halt, RM will disable TPCCS forwarding of
     * further SM interrupts.
     *
     * SUBTLE DIFFERENCE BETWEEN KEPLER (all chips) AND FERMI (Bug 827442):
     *
     * On Fermi, we had RM do this because there was no way to officially
     * query if the chip was running after setting the run trigger (thus
     * creating a race condition with the pause mask).  However, we noticed
     * that doing this also prevented a race condition in general with
     * processing multiple events (we may receive the first event, wait for
     * everything to pause, then resume the device -- in the meantime a second
     * event queued itself up, and arrives immediately we issue the resume --
     * we immediate receive the new event and issue a suspend, which results in
     * a spurious event, and a spurious SIGTRAP.  Also, on Fermi, RM was able
     * to leave TPCCS_TPC_EXCEPTION_SM high, but since we have level-based
     * interrupts on Kepler, RM needs to clear that bit immediately.  So, to
     * handle this on Kepler, it simply disables TPCCS forwarding of SM
     * interrupts.  Therefore, the debugger needs to explicitly re-enable
     * forwarding of SM interrupts upon any resume. */
    if ((int32_t)vsm == -1) { /* re-enable for all vsms */
        /* Uniformity assumption for reading */
        HALO_TRACE_FUNCTION(10, "Re-enabling SM interrupts for all vsms (vsm = %d)\n", vsm);
    }
    else { /* re-enable for one vsm */
        HALO_TRACE_FUNCTION(10, "Re-enabling SM interrupts for vsm %d\n", vsm);

        CUDBG_VERIFY((vsm < dev->halo.deviceInfo.numSMs), CUDBG_ERROR_INVALID_SM, "Invalid SM in clearExceptions.\n");
    }

    res = dev->halo.getPRIOffset(dev, HALO_PRI_TPCCS_TPC_EXCEPTION_EN, vsm,
                                 &regOffset);
    if (res != CUDBG_SUCCESS)
        return res;

    res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GLOBAL,
                                     (char *)(uintptr_t)regOffset, &regVal);
    if (res != CUDBG_SUCCESS)
        return res;

    regVal = SETFIELD32(regVal, NV_PGRAPH_PRI_GPC0_TPC0_TPCCS_TPC_EXCEPTION_EN_SM, 1);
    res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GLOBAL,
                                      (char *)(uintptr_t)regOffset, &regVal);
    if (res != CUDBG_SUCCESS)
        return res;

    return res;
}

static CUDBGResult
kepler_gk10x_findConstBankOffset(CudbgDevice dev, DeviceFunction func,
                                 uint32_t tid, uint64_t *constBankOffset)
{
    TexIdMap *texIdMap = func->texIdMap;
    uint32_t  i;

    for (i = 0; i < func->numTexIdMapEntries; i++) {
        if (texIdMap[i].texId == tid) {
            *constBankOffset = texIdMap[i].constBankOffset;
            break;
        }
    }

    CUDBG_VERIFY((i != func->numTexIdMapEntries),
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments in kepler_gk10x_findConstBankOffset.\n");

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_patchTextureInstruction(CudbgDevice dev, uint32_t texId, uint32_t dim,
                                     uint32_t *coords, Grid grid)
{
    CUDBGResult res;
    Context ctx;
    uint64_t pc, inst;
    uint64_t constBankOffset;

    CUDBG_VERIFY(coords, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in patchTextureInstruction.\n");

    CUDBG_VERIFY(dev->activeContext, CUDBG_ERROR_INVALID_CONTEXT, "No active context found in patchTextureInstruction.\n");

    ctx = dev->activeContext;
    pc = (ctx->thCodeVA + ctx->thRdTexMemOffset) - ctx->funcMemBaseVA;

    res = dev->halo.findConstBankOffset(dev, grid->function, texId, &constBankOffset);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to find the contbank offset for texId %d (res=%d)\n", texId, res);
        return res;
    }

    res = dev->halo.readCodeMemory(ctx, pc, &inst, sizeof inst);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read code memory at offset 0x%08x (res=%d)\n", pc, res);
        return res;
    }

    inst = (inst & ~BF_FLDV(GK10XSASS_PTRIDX, 0x1FFFu)) |
           BF_FLDV(GK10XSASS_PTRIDX, (constBankOffset >> 2));
    inst = (inst & ~BF_FLDV(FSASS_TEX_DIM, 0x3u)) | BF_FLDV(FSASS_TEX_DIM, dim - 1);

    res = dev->halo.writeCodeMemory(ctx, pc, &inst, sizeof inst);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to write code memory at offset 0x%08x (res=%d)\n", pc, res);
        return res;
    }

    res = dev->halo.invalidateICache(dev);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to invalidate icache (res=%d)\n", res);
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_setBLCG(CudbgDevice dev, uint32_t vsm, uint32_t on)
{
    uint32_t regVal;
    uint32_t regOffset = 0;
    CUDBGResult res = CUDBG_SUCCESS;

    /* _CG PRIs are being removed from the whitelist, use the profiler object
       when possible */
    if (dev->dmal->profilerObjectCanClockGate()) {
        /* When we enable BLCG, we release the refcount. */
        res = dev->dmal->profilerObjectSetBLCG(dev, on, !on);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to set block-level clock gating!\n");
            return res;
        }
        return res;
    }

    /* NOTE:  This function assumes that we are _always_ disabling
       SM BLCG prior to re-enabling it.  Catch that situation here. */
    if (on)
        CUDBG_VERIFY((dev->origBLCG1SettingValid == true),
                     CUDBG_ERROR_INTERNAL,
                     "Error:  Original SM BLCG setting not properly set prior to re-enabling.\n");

    /* WAR HW Bug 865738 (instanced) requires STALL/IDLE BLCG to
       be disabled in the SM_BLCG_1 register only, just prior to
       writes to the RUN_TRIGGER. */
    res = dev->halo.getPRIOffset(dev, HALO_PRI_SM_BLCG_1_CG, vsm,
                                 &regOffset);
    if (res != CUDBG_SUCCESS)
        return res;

    /* If disabling, read the current BLCG value and save it off, then
       set the IDLE and STALL clockgating bits to zero.
       If 'enabling', restore the previous setting into SM_BLCG_1. */
    if (!on) {
        res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GLOBAL,
                                         (char *)(uintptr_t)regOffset, &regVal);
        if (res != CUDBG_SUCCESS)
            return res;

        /* Save off the original setting (uniformity assumption across SMs) */
        dev->origBLCG1Setting = regVal;
        dev->origBLCG1SettingValid = true;

        regVal = SETFIELD32(regVal, NV_PGRAPH_PRI_GPC0_TPC0_SM_BLCG_1_CG_IDLE_CG_EN, on);
        regVal = SETFIELD32(regVal, NV_PGRAPH_PRI_GPC0_TPC0_SM_BLCG_1_CG_STALL_CG_EN, on);
    }
    else {
        regVal = dev->origBLCG1Setting;
        dev->origBLCG1SettingValid = false;
    }

    /* Do the actual write to SM_BLCG_1 */
    res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GLOBAL,
                                      (char *)(uintptr_t)regOffset, &regVal);
    if (res != CUDBG_SUCCESS)
        return res;

    return res;
}

static CUDBGResult
kepler_gk10x_enableSMBLCG(CudbgDevice dev, uint32_t vsm)
{
    return kepler_gk10x_setBLCG(dev, vsm, 1);
}

static CUDBGResult
kepler_gk10x_disableSMBLCG(CudbgDevice dev, uint32_t vsm)
{
    return kepler_gk10x_setBLCG(dev, vsm, 0);
}

static CUDBGResult
kepler_gk10x_enableDeviceBLCG(CudbgDevice dev)
{
    return kepler_gk10x_setBLCG(dev, -1, 1);
}

static CUDBGResult
kepler_gk10x_disableDeviceBLCG(CudbgDevice dev)
{
    return kepler_gk10x_setBLCG(dev, -1, 0);
}

static CUDBGResult
kepler_gk10x_startRunTriggerWar(CudbgDevice dev)
{
    CUDBGResult res;
    uint32_t warRunTriggerFlagValue = 1; /* Wait */

    /* No need to use this WAR if we don't have a resident context */
    if (!dev->activeContext || !haloStateContextIsActive(dev->activeContext))
        return CUDBG_SUCCESS;

    /* Write the scratchpad->warRunTrigger1239649 flag to a 1.
       After waking up from pause, this will cause warps to wait
       in the trap handler until the flag is cleared. */
    res = dev->halo.scratchpad.write_WAR_runTrigger1239649(dev->activeContext->scratchpadAccessor, warRunTriggerFlagValue);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to write WAR run trigger 1239649");

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_finishRunTriggerWar(CudbgDevice dev, int32_t vsm)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t smStatus, runTrigger, tmpVsm, vsmStart, vsmEnd;
    uint32_t regOffset = 0;
    uint32_t warRunTriggerFlagValue = 0; /* Release */
    bool timeoutExceeded = false;
    cuosTimer timer;

    /* No need to use this WAR if we don't have a resident context */
    if (!dev->activeContext || !haloStateContextIsActive(dev->activeContext))
        return CUDBG_SUCCESS;

    cuosResetTimer(&timer);

    /* At this point, RUN_TRIGGER has been asserted.
       Poll until RUN_TRIGGER_DONE is reported in STATUS0 */
    vsmStart = (vsm == -1) ? 0 : (uint32_t)vsm;
    vsmEnd   = (vsm == -1) ? dev->halo.deviceInfo.numSMs : (uint32_t)vsm + 1;
    for (tmpVsm = vsmStart; tmpVsm < vsmEnd; tmpVsm++) {
        do {
            if (cuosGetTimer(&timer) >= KEPLER_WAIT_FOR_RUN_TRIGGER_DONE_TIMEOUT) {
                timeoutExceeded = true;
            }

            res = dev->halo.getPRIOffset(dev, HALO_PRI_SM_DBGR_STATUS0, vsm,
                                         &regOffset);
            if (res != CUDBG_SUCCESS)
                return res;

            /* Read DBGR_STATUS0 */
            res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                             (char *)(uintptr_t)regOffset,
                                             &smStatus);
            if (res != CUDBG_SUCCESS)
                return res;

            /* Get the RUN_TRIGGER field */
            runTrigger = GETFIELD32(smStatus, NV_PGRAPH_PRI_GPCS_TPCS_SM_DBGR_STATUS0_RUN_TRIGGER);
        }
        while (runTrigger && !timeoutExceeded);

        if (timeoutExceeded && runTrigger) {
            HALO_ERROR("Timeout polling RUN_TRIGGER_DONE.\n");
            return CUDBG_ERROR_INTERNAL;
        }
    }

    /* Write the scratchpad->warRunTrigger1239649 flag to a 0.
       This will cause warps waiting on this flag to move forward */
    res = dev->halo.scratchpad.write_WAR_runTrigger1239649(dev->activeContext->scratchpadAccessor, warRunTriggerFlagValue);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to write WAR run trigger 1239649");

    /* Ensure write for the run trigger WAR are pushed out */
    cuosStoreFence();

    return res;
}

/* Note, this doesn't touch the device suspended property, so use with care. */
static CUDBGResult
kepler_gk10x_resumeTPC(CudbgDevice dev, uint32_t vsm)
{
    uint32_t regVal;
    uint32_t regOffset = 0;
    CUDBGResult res = CUDBG_SUCCESS, res2 = CUDBG_SUCCESS;

    if (haloStateContextIsActive(dev->activeContext))
        dev->halo.contextCommonDataCacheOp(dev->activeContext, HALO_MEM_SEG_CACHE_INVALIDATE);

    /* Disable BLCG.
       WAR HW Bug 865738 (instanced).  Writes to the RUN_TRIGGER (in DBGR_CONTROL0)
       are ignored when block-level clockgating is enabled (specifically due to
       a wakeup), so we must disable it before unpausing warps, then re-enable it
       after unpausing them. */
    res = kepler_gk10x_disableSMBLCG(dev, vsm);
    if (res != CUDBG_SUCCESS)
        goto resumeTPC_end;
    res = dev->halo.getPRIOffset(dev, HALO_PRI_SM_DBGR_CONTROL0, vsm,
                                 &regOffset);
    if (res != CUDBG_SUCCESS)
        return res;

    res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                     (char *)(uintptr_t)regOffset, &regVal);
    if (res != CUDBG_SUCCESS)
        goto resumeTPC_end;

    /* The following requires some clarification.  Despite the fact
     * that both RUN_TRIGGER and STOP_TRIGGER have the word "TRIGGER"
     * in their names, only one is actually a trigger, and that is
     * the STOP_TRIGGER.  Only writing a 1 to the RUN_TRIGGER is not
     * sufficient to resume the gpu - the stop trigger must explicitly
     * be set to 0 as well. */

    /* RESUMING:  Advice from the arch group:  Set the stop trigger
     * first as a separate operation to ensure that the trigger has
     * taken effect before setting the "run trigger." */

    /* Set the stop trigger to 0 */
    regVal = SETFIELD32(regVal, NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_CONTROL0_STOP_TRIGGER, 0);
    res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                      (char *)(uintptr_t)regOffset, &regVal);
    if (res != CUDBG_SUCCESS)
        goto resumeTPC_end;

    /* Now, set the run trigger to 1 */
    regVal = SETFIELD32(regVal, NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_CONTROL0_RUN_TRIGGER, 1);

    /* Do the final write to CONTROL0 */
    res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                      (char *)(uintptr_t)regOffset, &regVal);
    if (res != CUDBG_SUCCESS)
        goto resumeTPC_end;

resumeTPC_end: /* We use this label to avoid leaving BLCG disabled */
    /* Enable BLCG.
       WAR HW Bug 865738 (instanced).  Writes to the RUN_TRIGGER (in DBGR_CONTROL0)
       are ignored when block-level clockgating is enabled (specifically due to
       a wakeup), so we must disable it before unpausing warps, then re-enable it
       after unpausing them. */
    if ((res2 = kepler_gk10x_enableSMBLCG(dev, vsm)) != CUDBG_SUCCESS) {
        HALO_TRACE_FUNCTION(0, "Re-enabling SM BLCG failed (res = %d)!\n", res2);
        /* Return an error only if there wasn't a previous error */
        if (res == CUDBG_SUCCESS)
            return res2;
    }
    return res;
}

static CUDBGResult
kepler_gk10x_resumeSM(CudbgDevice dev, uint32_t vsm)
{
    CUDBGResult res = CUDBG_SUCCESS, res2 = CUDBG_SUCCESS;

    if (dev->codeIsDirty)
        dev->halo.invalidateICache(dev);
    dev->codeIsDirty = 0;

    res = dev->halo.writePauseServicedMask(dev, false, vsm);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to write pause serviced mask (res=%d)\n", res);
        return res;
    }

    dev->halo.clearExceptions(dev, vsm);

    /* Setup the WAR for HW Bug 1239649 (hold the warps after they wakeup from pause) */
    res = dev->halo.startRunTriggerWar(dev);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Setting up run trigger war failed in resumeSM (res=%d).\n", res);
        return res;
    }

    /* Ensure all CPU stores are visible to GPU at this point */
    cuosStoreFence();

    /* Resume this TPC.  If there is a failure here, then preserve the return code
       and allow subsequent routines to happen. */
    res = kepler_gk10x_resumeTPC(dev, vsm);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to fermi_resumeTPC failed in resumeSM.\n");
    }

    /* Finish the WAR for HW Bug 1239649 (let the warps resume) */
    res2 = dev->halo.finishRunTriggerWar(dev, vsm);
    if (res2 != CUDBG_SUCCESS) {
        HALO_ERROR("Finalizing run trigger war failed in resumeSM (res=%d).\n", res);
        /* Only return this error if there wasn't a previous one */
        if (res == CUDBG_SUCCESS)
            res = res2;
    }

    res2 = haloSetRmDebugMode(dev, false);
    if (res2 != CUDBG_SUCCESS) {
        HALO_TRACE(20, "Call to haloSetRmDebugMode failed in resumeSM.\n");
        /* Only return this error if there wasn't a previous one */
        if (res == CUDBG_SUCCESS)
            res = res2;
    }

    return res;
}

static CUDBGResult
kepler_gk10x_resumeDevice(CudbgDevice dev, uint32_t *hasResumed, uint32_t skipResume)
{
    CUDBGResult res = CUDBG_SUCCESS, res2 = CUDBG_SUCCESS;

    *hasResumed = 0;

    if (dev->codeIsDirty)
        dev->halo.invalidateICache(dev);
    dev->codeIsDirty = 0;

    /* Disable BLCG.
       WAR HW Bug 865738 (instanced).  Writes to the RUN_TRIGGER (in DBGR_CONTROL0)
       are ignored when block-level clockgating is enabled (specifically due to
       a wakeup), so we must disable it before unpausing warps, then re-enable it
       after unpausing them. */
    res = kepler_gk10x_disableDeviceBLCG(dev);
    if (res != CUDBG_SUCCESS)
        return res;

    dev->halo.clearExceptions(dev, -1);

    /* Setup the WAR for HW Bug 1239649 (hold the warps after they wakeup from pause) */
    res = dev->halo.startRunTriggerWar(dev);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Setting up run trigger war failed in resumeDevice (res=%d).\n", res);
        return res;
    }

    /* Ensure all CPU stores are visible to GPU at this point */
    cuosStoreFence();

    /* If possible, do the resume through the debug object.  If any
       of these calls fail, preserve the return code and allow
       subsequent routines to happen (ensure that RM debug mode is
       disabaled, and BLCG is re-enabled). */
    if (!skipResume) {
        if (dev->dmal->debugObjectCanResume())
            res = dev->dmal->debugObjectResumeDevice(dev, hasResumed);
        else
            res = dev->halo.resumeDeviceViaPRIV(dev, hasResumed);
    }

    /* Finish the WAR for HW Bug 1239649 (let the warps resume) */
    res2 = dev->halo.finishRunTriggerWar(dev, -1);
    if (res2 != CUDBG_SUCCESS) {
        HALO_ERROR("Finalizing run trigger war failed in resumeDevice (res=%d).\n", res2);
        /* Only return this error if there wasn't a previous one */
        if (res == CUDBG_SUCCESS)
            res = res2;
    }

    *hasResumed = 1;

    res2 = haloSetRmDebugMode(dev, false);
    if (res2 != CUDBG_SUCCESS) {
        HALO_TRACE(20, "Call to haloSetRmDebugMode failed in resumeDevice.\n");
        /* Only return this error if there wasn't a previous one */
        if (res == CUDBG_SUCCESS)
            res = res2;
    }

    /* Enable BLCG.
       WAR HW Bug 865738 (instanced).  Writes to the RUN_TRIGGER (in DBGR_CONTROL0)
       are ignored when block-level clockgating is enabled (specifically due to
       a wakeup), so we must disable it before unpausing warps, then re-enable it
       after unpausing them. */
    if ((res2 = kepler_gk10x_enableDeviceBLCG(dev)) != CUDBG_SUCCESS) {
        HALO_TRACE_FUNCTION(0, "Re-enabling Device BLCG failed (res = %d)!\n", res2);
        /* Only return this error if there wasn't a previous one */
        if (res == CUDBG_SUCCESS)
            res = res2;
    }

    return res;
}

static CUDBGResult
kepler_gk10x_setMMUDebugModeViaPRI(Context ctx, uint32_t on, uint8_t regType) {
    HaloRegOp regOp = { 0 };
    CUDBGResult res = CUDBG_SUCCESS;

    regOp.regOp = NV2080_CTRL_GPU_REG_OP_WRITE_32;
    regOp.regType = regType;
    regOp.regOffset = NV_PGRAPH_PRI_GPCS_MMU_DEBUG_CTRL;
    regOp.regValueLo = SETFIELD32(regOp.regValueLo, NV_PGRAPH_PRI_GPCS_MMU_DEBUG_CTRL_DEBUG, on ? 1 : 0);
    regOp.regAndNMaskLo = SETFIELD32(regOp.regAndNMaskLo, NV_PGRAPH_PRI_GPCS_MMU_DEBUG_CTRL_DEBUG, 1);

    res = ctx->dev->dmal->execRegOps(ctx->dev, ctx, &regOp, 1);
    HALO_TRACE(40, "%s MMU debug mode via PRI (%s)\n",
               res == CUDBG_SUCCESS ? "Set" : "Failed to set",
               regType == NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX ? "ctxsw" : "global");

    return res;
}

static CUDBGResult
kepler_gk10x_setDebuggingModeMMU(Context ctx, uint32_t on)
{
    CudbgDevice dev;
    const CUdev* pDev;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_ARGS, "Invalid context\n");
    dev = ctx->dev;
    pDev = globals.devices[dev->deviceIdx];

    if (dev->dmal->debugObjectCanSetMMUDebugMode()) {
        return dev->dmal->debugObjectSetMMUDebugMode(ctx, on);
    }

    /* Set MMU debug mode for all GPCs.

       Kepler behaves the same way as Fermi (with fewer WARs).

       RM sets NV_PGRAPH_PRI_GPCS_MMU_DEBUG_{RD,WR} to set a dummy
       page that is used for all invalid reads/writes, which
       will prevent state corruption (Bug 655252 tracks this, the
       code lives in kernel/gr/fermi/grgf100.c in the resman tree). */

    res = kepler_gk10x_setMMUDebugModeViaPRI(ctx, on, NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX);
    if (res != CUDBG_SUCCESS) {
        /* In the CUDA compatibility scenarios, the kernel driver can be old enough
           to have the MMU Debug Mode register be global and not ctxsw, so retry with global PRI.
           This also accounts for chips where MMU Debug Mode was never made ctxsw, like GK110C. */
        res = kepler_gk10x_setMMUDebugModeViaPRI(ctx, on, NV2080_CTRL_GPU_REG_OP_TYPE_GLOBAL);
    }

    return res;
}

static CUDBGResult
kepler_gk10x_enableMMUDebuggingMode(Context ctx)
{
    return kepler_gk10x_setDebuggingModeMMU(ctx, 1);
}

static CUDBGResult
kepler_gk10x_disableMMUDebuggingMode(Context ctx)
{
    return kepler_gk10x_setDebuggingModeMMU(ctx, 0);
}

static TOOLSresult
disableMMUDebugModeForContext(tHashMapKey_t key, void *entry, void *data)
{
    CudbgDevice dev;
    Context context;
    CUDBGResult res = CUDBG_SUCCESS;

    context = (Context)entry;
    dev = (CudbgDevice)data;

    res = dev->halo.disableMMUDebuggingMode(context);
    if (res != CUDBG_SUCCESS)
        return TOOLS_ERROR_UNKNOWN;

    return TOOLS_SUCCESS;
}

static CUDBGResult
kepler_gk10x_disableMMUDebuggingModeForDevice(CudbgDevice dev)
{
    TOOLSresult res;

    res = toolsHashMapApplyFunctor(dev->contexts, disableMMUDebugModeForContext, dev);
    if (res != TOOLS_SUCCESS) {
        return CUDBG_ERROR_INTERNAL;
    }
    return CUDBG_SUCCESS;
}

typedef struct forceTerminationData_st forceTerminationData;

struct forceTerminationData_st {
    uint64_t thStartOffset;
    uint64_t thEndOffset;
    Context context;
};

static CUDBGResult
forceTerminationFunctor(haloMemoryMap *map,
                        haloMemorySegment *seg,
                        void *data)
{
    forceTerminationData *d = (forceTerminationData *)data;
    const uint64_t exit_inst = 0x8000000000001de7ULL;
    const uint64_t rtt_inst  = 0xA000000000000007ULL;
    CUDBGResult res = CUDBG_SUCCESS;

    /* Fill everything with exit_inst */
    res = d->context->dev->halo.fillRangeWithInstruction(d->context,
                                                         seg->devvaddr,
                                                         (seg->devvaddr + seg->size),
                                                         exit_inst);
    if (res != CUDBG_SUCCESS)
        return res;

    if (seg->devvaddr <= d->thStartOffset && seg->devvaddr + seg->size > d->thStartOffset) {
        CUDBG_VERIFY(d->thEndOffset <= seg->devvaddr + seg->size,
                     CUDBG_ERROR_INTERNAL,
                     "Trap handler spans multiple segments!\n");
        /* Fill trap handler with rtt instructions */
        res = d->context->dev->halo.fillRangeWithInstruction(d->context,
                                                             d->thStartOffset,
                                                             d->thEndOffset,
                                                             rtt_inst);
    }

    return res;
}

static CUDBGResult
kepler_gk10x_forceTermination(CudbgDevice dev)
{
    CUDBGResult res;
    forceTerminationData data = {0};

    /* If there is no active context or if we never launched any
       kernel for that context, there is nothing to do. */
    if (!dev->activeContext || !haloStateContextIsActive(dev->activeContext))
        return CUDBG_SUCCESS;

    /* TH Code Segment Start/End Offsets */
    data.thStartOffset = dev->activeContext->thCodeVA;
    data.thEndOffset   = data.thStartOffset + dev->activeContext->thCodeSize;
    data.context       = dev->activeContext;

    res = haloMemoryMapApplyFunctor(dev->activeContext->memMap,
                                    forceTerminationFunctor,
                                    &data);

    return res;
}

static CUDBGResult
kepler_gk10x_thServicePostProcess(CudbgDevice dev, uint32_t vsm)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t regOffset = 0;
    uint32_t hwwglobalesr;

    res = dev->halo.getPRIOffset(dev, HALO_PRI_SM_HWW_GLOBAL_ESR, vsm,
                                 &regOffset);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Bug 872516 - On Kepler, there are new bits set in the global ESR upon
       executing BPT.PAUSE (BPT_PAUSE_PENDING, Bit 5).  We need to clear these
       additional interrupt bits after our trap handler service routines,
       otherwise spurious events can show up. */

    res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                     (char *)(uintptr_t)regOffset,
                                     &hwwglobalesr);
    if (res != CUDBG_SUCCESS)
        return res;

    HALO_TRACE_FUNCTION(10, "Global ESR PRI value (before clear): %x\n", hwwglobalesr);

    /* Bit clear the global ESR */
    res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                      (char *)(uintptr_t)regOffset,
                                      &hwwglobalesr);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Read it back to make sure it stuck */
    res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                     (char *)(uintptr_t)regOffset,
                                     &hwwglobalesr);
    if (res != CUDBG_SUCCESS)
        return res;

    HALO_TRACE_FUNCTION(10, "Global ESR PRI value (after clear): %x\n", hwwglobalesr);
    if (hwwglobalesr) {
        HALO_ERROR("Failed to clear Global ESR in post process\n");
        return CUDBG_ERROR_INTERNAL;
    }

    return res;
}

static CUDBGResult
kepler_gk10x_setPowerGatingState(CudbgDevice dev, HaloPowerGatingState state)
{
    return dev->dmal->setPowerGatingState(dev, state);
}

CUDBGResult
kepler_gk10x_isAnyExceptionSet(CudbgDevice dev, bool *anyExceptionSet)
{
    uint32_t vsm;
    uint32_t tpcExceptionEn;
    uint32_t regOffset = 0;
    const uint32_t tpcExceptionEn_mask       = 0x00000002U;
    const uint32_t tpcExceptionEn_smDisabled = 0x00000000U;
    CUDBGResult res = CUDBG_SUCCESS;

    *anyExceptionSet = false;

    for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
        res = dev->halo.getPRIOffset(dev, HALO_PRI_TPCCS_TPC_EXCEPTION_EN, vsm,
                                     &regOffset);
        if (res != CUDBG_SUCCESS)
            return res;

        res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GLOBAL,
                                         (char *)(uintptr_t)regOffset,
                                         &tpcExceptionEn);
        if (res != CUDBG_SUCCESS)
            return res;

        /* On Kepler, the contract between the debugger and RM is that upon
           receiving an SM exception, further interrupts are disabled. */
        if ((tpcExceptionEn & tpcExceptionEn_mask) == tpcExceptionEn_smDisabled) {
            *anyExceptionSet = true;
            break;
        }
    }

    return res;
}

static CUDBGResult
kepler_gk10x_getSavedSPLmemAddr(CudbgDevice dev, uint64_t *lmem_addr)
{
    CUDBG_VERIFY(lmem_addr,
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments\n");

    *lmem_addr = KEPLER_LMEM_SAVED_STACK_POINTER;
    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_membarWAR_getPatchReg(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                   uint32_t ln, uint32_t regno,
                                   uint32_t *hasSpilled, uint32_t *regval)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t offset = 0;

    /* The MEMBAR WAR spills R0, R2, R3 */
    switch (regno) {
    case 0:
        offset = dev->halo.deviceInfo.lmemHiMembarWarSpillR0;
        *hasSpilled = 1;
        break;
    case 2:
        offset = dev->halo.deviceInfo.lmemHiMembarWarSpillR2;
        *hasSpilled = 1;
        break;
    case 3:
        offset = dev->halo.deviceInfo.lmemHiMembarWarSpillR3;
        *hasSpilled = 1;
        break;
    default :
        *hasSpilled = 0;
        break;
    };

    if (!*hasSpilled) {
        return CUDBG_SUCCESS;
    }

    CUDBG_VERIFY(offset, CUDBG_ERROR_UNKNOWN, "MEMBAR WAR offset not set\n");

    res = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                    offset,
                                    regval, sizeof(*regval));
    return res;
}

static CUDBGResult
kepler_gk10x_membarWAR_getPatchPred(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                    uint32_t ln, uint32_t numPreds,
                                    uint32_t *predicates)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t i;
    uint32_t predicateReg;

    res = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                    KEPLER_LMEM_HI_MEMBAR_WAR_SPILL_PR,
                                    &predicateReg, sizeof predicateReg);

    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read spilled predicate register from lmem (res=%d)\n", res);
        return res;
    }

    for (i = 0; i < numPreds; i++) {
        predicates[i] = (predicateReg >> i) & 1U;
    }

    return res;
}

static CUDBGResult
kepler_gk10x_membarWAR_getPatchCC(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                  uint32_t ln, uint32_t *cc)
{

    return haloReadCCRegister(dev, vsm, wp, ln,
                              KEPLER_LMEM_HI_MEMBAR_WAR_SPILL_PR,
                              cc);
}

static CUDBGResult
kepler_gk10x_membarWAR_setPatchReg(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                   uint32_t ln, uint32_t regno,
                                   uint32_t *hasSpilled, const uint32_t *regval)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t offset = 0;

    /* The MEMBAR WAR spills R0, R2, R3 */
    switch (regno) {
    case 0:
        offset = dev->halo.deviceInfo.lmemHiMembarWarSpillR0;
        *hasSpilled = 1;
        break;
    case 2:
        offset = dev->halo.deviceInfo.lmemHiMembarWarSpillR2;
        *hasSpilled = 1;
        break;
    case 3:
        offset = dev->halo.deviceInfo.lmemHiMembarWarSpillR3;
        *hasSpilled = 1;
        break;
    default :
        *hasSpilled = 0;
        break;
    };

    if (!*hasSpilled) {
        return CUDBG_SUCCESS;
    }

    CUDBG_VERIFY(offset, CUDBG_ERROR_UNKNOWN, "MEMBAR WAR offset not set\n");

    res = dev->halo.writeLocalMemory(dev, vsm, wp, ln,
                                     offset,
                                     regval, sizeof(*regval));
    return res;
}

static CUDBGResult
kepler_gk10x_membarWAR_setPatchPred(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                    uint32_t ln, uint32_t numPreds,
                                    const uint32_t *predicates)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t i;
    uint32_t predicateReg;

    /* Read existing predicate register from membar war spill location */
    res = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                    KEPLER_LMEM_HI_MEMBAR_WAR_SPILL_PR,
                                    &predicateReg, sizeof predicateReg);

    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read spilled predicate register from lmem (res=%d)\n", res);
        return res;
    }

    /* Modify predicate register based on inputs */
    for (i = 0; i < numPreds; i++) {
        CUDBG_VERIFY(predicates[i] < 2, CUDBG_ERROR_INVALID_ARGS, "Invalid predicate value\n");
        predicateReg = (predicateReg & ~(1U << i)) | (predicates[i] << i);
    }

    /* Write updated predicate register back to membar war spill location */
    res = dev->halo.writeLocalMemory(dev, vsm, wp, ln,
                                     KEPLER_LMEM_HI_MEMBAR_WAR_SPILL_PR,
                                     &predicateReg, sizeof predicateReg);
    return res;
}

static CUDBGResult
kepler_gk10x_membarWAR_setPatchCC(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                  uint32_t ln, const uint32_t cc)
{
    return haloWriteCCRegister(dev, vsm, wp, ln,
                               KEPLER_LMEM_HI_MEMBAR_WAR_SPILL_PR,
                               cc);
}

static CUDBGResult
kepler_gk10x_membarWAR_unwindCRS(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                 uint32_t ln, uint64_t *entryPc, uint32_t *depth)
{
    DebugPatch patch = NULL;
    bool inMembarWAR = false, inGlobalSyscallPatch = false;
    HaloCRS_t *warpCRS = &dev->smState[vsm].warp[wp].CRS;
    uint32_t lane_mask = 1U << ln;
    uint64_t tokenPC = 0, physPC = 0;
    uint32_t calSkipped = 0, laneDisRet = 0;
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t call_depth = 0;
    int32_t i;

    /* If both entryPc and depth are null, return early */
    if (!entryPc && !depth)
        return CUDBG_ERROR_INVALID_ARGS;

    /* Find the correct PC for this lane, accounting for divergence */
    if (dev->smState[vsm].warp[wp].activeMask & lane_mask) {
        res = dev->halo.readPC(dev, vsm, wp, &physPC);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to  failed (res=%d)\n", res);
            return res;
        }
    }
    else {
        res = dev->halo.findDivergedCRS_PC(dev, vsm, wp, ln, &physPC);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to findDivergedCRS_PC failed (res=%d)\n", res);
            return res;
        }
    }

    /* Basic sanity, test if the starting address is in a membar WAR patch */
    res = dev->haloClient->inMembarWARPatch(dev, physPC, &patch, &inMembarWAR);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to inMembarWARPatch failed\n");
        return res;
    }

    if (!inMembarWAR) {
        HALO_ERROR("Called membarWAR_unwindCRS when not in membar patch\n");
        return CUDBG_ERROR_UNKNOWN;
    }

    /* Look for this lane in the DIS_RET mask */
    laneDisRet = lane_mask & warpCRS->mask[warpCRS->disRetIdx];

    for (i = warpCRS->trapIdx - 1; i >= 0; --i) {
        /* Skip the CALL token if this lane is actually done with the call */
        if ((warpCRS->type[i] == CRS_TYPE_CALL ||
             warpCRS->type[i] == CRS_TYPE_CALL_NI) &&
            laneDisRet && !calSkipped++)
            continue;

        /* Skip if the return pc is in a syscall patch. This ignores CNP entry stub if needed */
        res = dev->haloClient->inGlobalSyscallPatch(dev, warpCRS->pc[i], &patch, &inGlobalSyscallPatch);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to inGlobalSyscallPatch failed in membarWAR_unwindCRS.\n");
            return res;
        }
        if (inGlobalSyscallPatch)
            continue;

        if ((warpCRS->type[i] == CRS_TYPE_CALL ||
             warpCRS->type[i] == CRS_TYPE_CALL_NI) &&
            warpCRS->mask[i] & lane_mask)
            ++call_depth;

        /* Scan Call, div and SSY tokens, walking backward until we find a
           PC that is not in patch code. We can ignore the DIS_RET token
           as it may only be referring to the innermost call */
        if ((warpCRS->type[i] == CRS_TYPE_CALL ||
             warpCRS->type[i] == CRS_TYPE_CALL_NI ||
             warpCRS->type[i] == CRS_TYPE_DIV  ||
             warpCRS->type[i] == CRS_TYPE_SSY) &&
            warpCRS->mask[i] & lane_mask) {
            tokenPC = warpCRS->pc[i] - 8;

            /* Check if we are still in a patch */
            res = dev->haloClient->inMembarWARPatch(dev, tokenPC, &patch, &inMembarWAR);
            if (res != CUDBG_SUCCESS) {
                HALO_ERROR("Call to inMembarWARPatch failed\n");
                return res;
            }

            if (!inMembarWAR) {
                if (entryPc)
                    *entryPc = tokenPC;
                if (depth)
                    *depth = call_depth;
                return CUDBG_SUCCESS;
            }
        }
    }

    HALO_ERROR("Failed to find a user frame for the Membar WAR\n");
    return CUDBG_ERROR_UNKNOWN;
}

static CUDBGResult
kepler_gk10x_membarWAR_getPatchPC(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                  uint32_t ln, uint64_t *entryPc,
                                  DebugPatch patch)
{
    return kepler_gk10x_membarWAR_unwindCRS(dev, vsm, wp, ln, entryPc, NULL);
}

static CUDBGResult
kepler_gk10x_membarWAR_getPatchCallDepth(CudbgDevice dev, uint32_t vsm,
                                         uint32_t wp, uint32_t ln,
                                         uint32_t *depth, DebugPatch patch)
{
    return kepler_gk10x_membarWAR_unwindCRS(dev, vsm, wp, ln, NULL, depth);
}

static CUDBGResult
inBarWARPatch(CudbgDevice dev, uint64_t physPC, DebugPatch *patch, bool *found)
{
    CUDBGResult res;

    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid device argument to haloInBarWARPatch\n");

    CUDBG_VERIFY(patch, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid patch argument to haloInBarWARPatch\n");

    CUDBG_VERIFY(found, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid found argument to haloInBarWARPatch\n");

    if (!dev->activeContext) {
        *found = false;
        return CUDBG_SUCCESS;
    }

    res = haloInPatchRegion(physPC, dev->activeContext, patch,
                            CUDBG_PATCH_BAR_WAR, found, false);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to haloInPatchRegion failed\n");
        return res;
    }

    return CUDBG_SUCCESS;
}

/*
 * Similar to kepler_gk10x_membarWAR_unwindCRS(), but simpler as the CALL token
 * for the BAR.SYNC patch should always be on top of the CRS.
 */
static CUDBGResult
kepler_gk10x_barWAR_unwindCRS(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                              uint32_t ln, uint64_t *entryPc)
{
    DebugPatch patch = NULL;
    bool inBarWAR = false, inGlobalSyscallPatch = false;
    HaloCRS_t *warpCRS = &dev->smState[vsm].warp[wp].CRS;
    uint32_t lane_mask = 1U << ln;
    uint64_t tokenPC = 0, physPC = 0;
    uint32_t calSkipped = 0, laneDisRet = 0;
    CUDBGResult res = CUDBG_SUCCESS;
    int32_t i;

    /* If entryPc is null, return early */
    if (!entryPc)
        return CUDBG_ERROR_INVALID_ARGS;

    /* Find the correct PC for this lane, accounting for divergence */
    if (dev->smState[vsm].warp[wp].activeMask & lane_mask) {
        res = dev->halo.readPC(dev, vsm, wp, &physPC);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to readPC failed (res=%d)\n", res);
            return res;
        }
    }
    else {
        res = dev->halo.findDivergedCRS_PC(dev, vsm, wp, ln, &physPC);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to findDivergedCRS_PC failed (res=%d)\n", res);
            return res;
        }
    }

    /* Basic sanity, test if the starting address is in a BAR.SYNC WAR patch */
    res = inBarWARPatch(dev, physPC, &patch, &inBarWAR);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to inBarWARPatch failed\n");
        return res;
    }

    if (!inBarWAR) {
        HALO_ERROR("Called barWAR_unwindCRS when not in BAR.SYNC patch\n");
        return CUDBG_ERROR_UNKNOWN;
    }

    /* Look for this lane in the DIS_RET mask */
    laneDisRet = lane_mask & warpCRS->mask[warpCRS->disRetIdx];

    for (i = warpCRS->trapIdx - 1; i >= 0; --i) {
        /* Skip the CALL token if this lane is actually done with the call */
        if ((warpCRS->type[i] == CRS_TYPE_CALL ||
             warpCRS->type[i] == CRS_TYPE_CALL_NI) &&
            laneDisRet && !calSkipped++)
            continue;

        /* Scan Call, div and SSY tokens, walking backward until we find a
           PC that is not in the BAR.SYNC patch code. We can ignore the DIS_RET token
           as it may only be referring to the innermost call */
        if ((warpCRS->type[i] == CRS_TYPE_CALL ||
             warpCRS->type[i] == CRS_TYPE_CALL_NI ||
             warpCRS->type[i] == CRS_TYPE_DIV  ||
             warpCRS->type[i] == CRS_TYPE_SSY) &&
            warpCRS->mask[i] & lane_mask) {
            tokenPC = warpCRS->pc[i] - 8;

            HALO_TRACE_FUNCTION(40, "BAR.SYNC unwind stop pc:0x%" PRIx64 "\n", tokenPC);
            *entryPc = tokenPC;

            return CUDBG_SUCCESS;
        }
    }

    HALO_ERROR("Failed to find a user frame for the BAR.SYNC WAR\n");
    return CUDBG_ERROR_UNKNOWN;
}

static CUDBGResult
kepler_gk10x_barWAR_getPatchPC(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                               uint32_t ln, uint64_t *entryPc)
{
    return kepler_gk10x_barWAR_unwindCRS(dev, vsm, wp, ln, entryPc);
}

static CUDBGResult
kepler_gk10x_getLmemBase(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint64_t *lmemBase)
{
    CUDBGResult res;
    Context context;

    CUDBG_VERIFY(dev && lmemBase, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    context = dev->activeContext;
    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "No active context!\n");

    res = dev->halo.scratchpad.read_lmemBase(context->scratchpadAccessor, vsm, wp, lmemBase);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get lmem base\n");

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_getUserEntryFunction(CudbgDevice dev, Context context, uint32_t vsm, uint32_t wp, uint32_t ln,
                                  Grid grid, DeviceFunction *entryFunc)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t startPc = 0;
    uint64_t startPcOffset;
    uint64_t selfQMDdptr;
    uint64_t paramConstDptrOffset;
    uint64_t paramConstDptr;

    CUDBG_VERIFY(dev && context && entryFunc && grid, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments");

    res = dev->halo.scratchpad.read_selfQMD(context->scratchpadAccessor, vsm, wp, &selfQMDdptr);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Could not get selfQMDdptr\n");

    HALO_TRACE_FUNCTION(5, "selfQMDdptr: 0x%" PRIx64 "\n", selfQMDdptr);

    /* Get the dptr to the parameter constbank (constbank 0)*/
    paramConstDptrOffset = selfQMDdptr + offsetof(CNPqmdLaunch, paramConstDptr);
    res = dev->halo.readGenericMemory(context,
                                      0, 0, 0,
                                      paramConstDptrOffset,
                                      &paramConstDptr,
                                      sizeof(paramConstDptr));
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read paramConstDptr at address %"
                 PRIx64 " from QMDLaunch\n", paramConstDptrOffset);

    /* Bug 1372597 - There is a small window in the cnpexit handler where
       interrupts are enabled, the grid is deemed 'completed', but the warp is
       still resident. In this case, there is no userEntryFunction can be found,
       but it is not an error. */
    if (!paramConstDptr) {
        HALO_TRACE_FUNCTION(1, "Grid %#" PRIx64 " has completed, but warp is still resident."
                                " There is no userEntryFunction in this case (and this grid is not postable)\n",
                                grid->gridId64);
        *entryFunc = NULL;
        return CUDBG_SUCCESS;
    }
    HALO_TRACE_FUNCTION(5, "paramConstDptr: 0x%" PRIx64 "\n", paramConstDptr);

    /* To get the function, first get startPC from within the constbank */
    res = dev->halo.getGridParamsOffsetStartPc(dev, &startPcOffset);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get gridDim offset in GridParams\n");

    startPcOffset += paramConstDptr;
    res = dev->halo.readGenericMemory(context,
                                      0, 0, 0,
                                      startPcOffset,
                                      &startPc,
                                      sizeof(startPc));
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read startPc at address %" PRIx64 " from constbank 0\n",
                 startPcOffset);

    HALO_TRACE_FUNCTION(5, "startPc: 0x%x \n", startPc);

    /* Now get the function corresponding to this startPc */
    *entryFunc = (DeviceFunction)toolsRangeMapLookupByAddr(context->gpuAddrToFunction, startPc);
    if (!*entryFunc) {
        HALO_ERROR("Could not find a DeviceFunction for startPc 0x%x \n", startPc);
        return CUDBG_ERROR_UNKNOWN_FUNCTION;
    }

    return res;
}

/* How single-step nsteps works:

   If nsteps equals 1: use standard approach - single-step complete and
   BPT.PAUSE interrupts are enabled and backend waits for device event

   If nsteps is greater than 1: Single-step complete and BPT.PAUSE interrupts
   are disabled. The single stepped warps are decrementing the nsteps value
   and do RTT, when nsteps reaches 0 (or an exception occurs) warps do
   BPT.PAUSE. The other warps are issuing BPT.PAUSE to stay in the
   traphandler, but it does not stop single stepping thanks to disabled
   interrupts. Backend waits until LOCKED_DOWN flag is set which means all
   warps have paused. */
static CUDBGResult
kepler_gk10x_setupSingleStepNsteps(CudbgDevice dev, uint32_t vsm, CUwarpBitmask *warpMask, uint32_t nsteps, uint32_t *nstepsold)
{
    CUDBGResult res;
    Context context = dev->activeContext;
    bool interruptsEnabled = !(nsteps > 1);
    uint32_t wp;

    /* If no active context, there is nothing we can do. */
    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "No active context found in setupSingleStepNsteps.\n");

    CUDBG_VERIFY(warpMask && nstepsold, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    /* Disable/re-enable single step complete interrupt */
    SETREGISTER32(dev, vsm, HALO_REG_OP_TYPE_GR_CTX,
                  HALO_PRI_SM_HWW_GLOBAL_ESR_REPORT_MASK,
                  NV_PGRAPH_PRI_GPC0_TPC0_SM_HWW_GLOBAL_ESR_REPORT_MASK_SINGLE_STEP_COMPLETE,
                  interruptsEnabled);

    /* Disable/re-enable pause interrupt */
    SETREGISTER32(dev, vsm, HALO_REG_OP_TYPE_GR_CTX,
                  HALO_PRI_SM_HWW_GLOBAL_ESR_REPORT_MASK,
                  NV_PGRAPH_PRI_GPC0_TPC0_SM_HWW_GLOBAL_ESR_REPORT_MASK_BPT_PAUSE,
                  interruptsEnabled);

    for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
        /* Skip warps that are not being single stepped */
        if (!warpBitmaskGetBits(warpMask, wp, 1))
            continue;

        res = dev->halo.scratchpad.read_singleStepNSteps(context->scratchpadAccessor, vsm, wp, nstepsold);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read single step N steps\n");

        res = dev->halo.scratchpad.write_singleStepNSteps(context->scratchpadAccessor, vsm, wp, nsteps);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to write single step N steps\n");
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_getPRIOffset(CudbgDevice dev, HaloPRI pri, int32_t vsm,
                          uint32_t *offset)
{
    CUDBG_VERIFY(offset, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");
    uint32_t priOffset = 0;

    *offset = 0;

    if (vsm < 0) {
        switch(pri) {
        case HALO_PRI_SM_DBGR_CONTROL0:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_SM_DBGR_CONTROL0;
            break;
        case HALO_PRI_SM_DBGR_STATUS0:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_SM_DBGR_STATUS0;
            break;
        case HALO_PRI_SM_HWW_WARP_ESR:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_SM_HWW_WARP_ESR;
            break;
        case HALO_PRI_SM_HWW_GLOBAL_ESR:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_SM_HWW_GLOBAL_ESR;
            break;
        case HALO_PRI_L1C_HWW_ESR:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_L1C_HWW_ESR;
            break;
        case HALO_PRI_L1C_HWW_ESR_ADDR:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_L1C_HWW_ESR_ADDR;
            break;
        case HALO_PRI_L1C_HWW_ESR_REQ:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_L1C_HWW_ESR_REQ;
            break;
        case HALO_PRI_SM_CACHE_CONTROL:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_SM_CACHE_CONTROL;
            break;
        case HALO_PRI_TPCCS_TPC_EXCEPTION:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_TPCCS_TPC_EXCEPTION;
            break;
        case HALO_PRI_TPCCS_TPC_EXCEPTION_EN:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_TPCCS_TPC_EXCEPTION_EN;
            break;
        case HALO_PRI_SM_BLCG_1_CG:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_SM_BLCG_1_CG;
            break;
        case HALO_PRI_SM_HWW_GLOBAL_ESR_REPORT_MASK:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_SM_HWW_GLOBAL_ESR_REPORT_MASK;
            break;
        default:
            HALO_ERROR("Failed to map PRIOffset: %d\n", priOffset);
            return CUDBG_ERROR_INVALID_ARGS;
        }
        *offset = priOffset + (uint32_t)(uintptr_t)dev->bar0;
    }
    else {
        switch(pri) {
        case HALO_PRI_SM_DBGR_CONTROL0:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_CONTROL0;
            break;
        case HALO_PRI_SM_DBGR_STATUS0:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_STATUS0;
            break;
        case HALO_PRI_SM_HWW_WARP_ESR:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_SM_HWW_WARP_ESR;
            break;
        case HALO_PRI_SM_HWW_GLOBAL_ESR:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_SM_HWW_GLOBAL_ESR;
            break;
        case HALO_PRI_L1C_HWW_ESR:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_L1C_HWW_ESR;
            break;
        case HALO_PRI_L1C_HWW_ESR_ADDR:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_L1C_HWW_ESR_ADDR;
            break;
        case HALO_PRI_L1C_HWW_ESR_REQ:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_L1C_HWW_ESR_REQ;
            break;
        case HALO_PRI_SM_CACHE_CONTROL:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_SM_CACHE_CONTROL;
            break;
        case HALO_PRI_TPCCS_TPC_EXCEPTION:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_TPCCS_TPC_EXCEPTION;
            break;
        case HALO_PRI_TPCCS_TPC_EXCEPTION_EN:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_TPCCS_TPC_EXCEPTION_EN;
            break;
        case HALO_PRI_SM_BLCG_1_CG:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_SM_BLCG_1_CG;
            break;
        case HALO_PRI_SM_HWW_GLOBAL_ESR_REPORT_MASK:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_SM_HWW_GLOBAL_ESR_REPORT_MASK;
            break;
        default:
            HALO_ERROR("Failed to map PRIOffset: %d\n", priOffset);
            return CUDBG_ERROR_INVALID_ARGS;
        }
        *offset = priOffset + (uint32_t)(uintptr_t)dev->priBase[vsm];
    }

    return CUDBG_SUCCESS;
}

/* Scratchpad access */

static CUDBGResult
kepler_gk10x_scratchpad_getGlobalFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_SCRATCHPAD_GET_OFFSET_CASE(ACTIVE, KeplerScratchpad_t, active);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PREEMPT_COMMAND, KeplerScratchpad_t, preemptCommand);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WAR_RUN_TRIGGER_1239649, KeplerScratchpad_t, warRunTrigger1239649);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PADDING, KeplerScratchpad_t, padding);
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_scratchpad_getWarpFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_SCRATCHPAD_GET_OFFSET_CASE(VIRT_ID, KeplerWarpScratchpad_t, virtID);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(CTA_PARAM, KeplerWarpScratchpad_t, ctaParam);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_IDX_X, KeplerWarpScratchpad_t, blockIdxX);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_IDX_Y, KeplerWarpScratchpad_t, blockIdxY);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_IDX_Z, KeplerWarpScratchpad_t, blockIdxZ);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_DIM_X, KeplerWarpScratchpad_t, blockDimX);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_DIM_Y, KeplerWarpScratchpad_t, blockDimY);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_DIM_Z, KeplerWarpScratchpad_t, blockDimZ);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_ID_64_LO, KeplerWarpScratchpad_t, gridId64Lo);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_DIM_X, KeplerWarpScratchpad_t, gridDimX);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_DIM_Y, KeplerWarpScratchpad_t, gridDimY);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_DIM_Z, KeplerWarpScratchpad_t, gridDimZ);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SHMEM_SIZE_PR_BLOCK, KeplerWarpScratchpad_t, shmemSizePrBlock);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_WINDOW_SIZE, KeplerWarpScratchpad_t, lmemWindowSize);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_LO_SIZE_PR_THREAD, KeplerWarpScratchpad_t, lmemLoSizePrThread);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_HI_OFF, KeplerWarpScratchpad_t, lmemHiOff);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GLOBAL_ERROR_STATUS, KeplerWarpScratchpad_t, globalErrorStatus);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_ERROR_STATUS, KeplerWarpScratchpad_t, warpErrorStatus);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_BARRIER_STATE, KeplerWarpScratchpad_t, warpBarrierState);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SELF_QMD_LO, KeplerWarpScratchpad_t, selfQMDLo);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SELF_QMD_HI, KeplerWarpScratchpad_t, selfQMDHi);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PARAM_CONST_DPTR_LO, KeplerWarpScratchpad_t, paramConstDptrLo);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PARAM_CONST_DPTR_HI, KeplerWarpScratchpad_t, paramConstDptrHi);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(CIR_QUEUE_INCR_MINUS_ONE, KeplerWarpScratchpad_t, cirQueueIncrMinusOne);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_BASE_LO, KeplerWarpScratchpad_t, lmemBaseLo);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_BASE_HI, KeplerWarpScratchpad_t, lmemBaseHi);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(CRS_PTR, KeplerWarpScratchpad_t, crsPtr);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_ID_64_HI, KeplerWarpScratchpad_t, gridId64Hi);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(MPS_CONTEXT_ID, KeplerWarpScratchpad_t, mpsContextId);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SINGLESTEP_NSTEPS, KeplerWarpScratchpad_t, singleStepNsteps);
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_scratchpad_getLaneFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_SCRATCHPAD_GET_OFFSET_CASE(THREAD_IDX, KeplerLaneScratchpad_t, threadIdx);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(R1, KeplerLaneScratchpad_t, r1);
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_scratchpad_getSmFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PAUSE_SERVICED_MASK, KeplerSMScratchpad_t, pauseServicedMask);
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_scratchpad_getFieldOffset(HaloScratchpadField field, HaloScratchpadSection section,
    uint32_t sm, uint32_t wp, uint32_t ln, size_t *offset, size_t *width)
{
    size_t base = 0;
    CUDBGResult res;

    switch (section) {
    case HALO_SCRATCHPAD_SECTION_GLOBAL:
        res = kepler_gk10x_scratchpad_getGlobalFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_SCRATCHPAD_SECTION_WARP:
        base = OFFSETOF_NONCONST(KeplerScratchpad_t, warp[sm][wp]);
        res = kepler_gk10x_scratchpad_getWarpFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_SCRATCHPAD_SECTION_SM:
        base = OFFSETOF_NONCONST(KeplerScratchpad_t, sm[sm]);
        res = kepler_gk10x_scratchpad_getSmFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_SCRATCHPAD_SECTION_LANE:
        base = OFFSETOF_NONCONST(KeplerScratchpad_t, warp[sm][wp]) +
               OFFSETOF_NONCONST(KeplerWarpScratchpad_t, lane[ln]);
        res = kepler_gk10x_scratchpad_getLaneFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    default:
        *offset = 0;
        *width = 0;
        HALO_TRACE_FUNCTION(0, "Invalid scratchpad section %d\n", section);
        return CUDBG_ERROR_INVALID_ARGS;
    };

    *offset += base;

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_scratchpad_read_blockIdx(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, CuDim3 *blockIdx)
{
    uint32_t value;

    CUDBG_VERIFY(scratchpadAccessor, CUDBG_ERROR_INVALID_ARGS, "Scratchpad accessor is NULL\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, BLOCK_IDX_X, vsm, wp, 0, &value);
    blockIdx->x = value;

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, BLOCK_IDX_Y, vsm, wp, 0, &value);
    blockIdx->y = value & 0xFFFF;

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, BLOCK_IDX_Z, vsm, wp, 0, &value);
    blockIdx->z = value & 0xFFFF;

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_scratchpad_read_gridId(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint64_t *gridId)
{
    uint32_t gridIdHi, gridIdLo;

    CUDBG_VERIFY(scratchpadAccessor && gridId, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, GRID_ID_64_LO, vsm, wp, 0, &gridIdLo);
    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, GRID_ID_64_HI, vsm, wp, 0, &gridIdHi);
    *gridId = ((uint64_t)gridIdHi << 32) | gridIdLo;

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_scratchpad_read_gridDim(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, CuDim3 *gridDim)
{
    uint32_t value;

    CUDBG_VERIFY(scratchpadAccessor && gridDim, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, GRID_DIM_X, vsm, wp, 0, &value);
    gridDim->x = value;

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, GRID_DIM_Y, vsm, wp, 0, &value);
    gridDim->y = value & 0xFFFF;

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, GRID_DIM_Z, vsm, wp, 0, &value);
    gridDim->z = value & 0xFFFF;

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_scratchpad_read_isWarpOnBarrier(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, bool *isWarpOnBarrier)
{
    const uint32_t WARP_BARRIER_STATE_MASK = 0x00001000U; /* Bit 12 - See Kepler IAS */
    uint32_t warpBarrierState;

    *isWarpOnBarrier = false;

    CUDBG_VERIFY(scratchpadAccessor && isWarpOnBarrier, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, WARP_BARRIER_STATE, vsm, wp, 0, &warpBarrierState);

    if (warpBarrierState & WARP_BARRIER_STATE_MASK)
        *isWarpOnBarrier = true;

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_scratchpad_read_selfQMD(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint64_t *selfQMDdptr)
{
    uint32_t selfQMDHi, selfQMDLo;

    CUDBG_VERIFY(scratchpadAccessor && selfQMDdptr, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, SELF_QMD_HI, vsm, wp, 0, &selfQMDHi);
    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, SELF_QMD_LO, vsm, wp, 0, &selfQMDLo);
    *selfQMDdptr = ((uint64_t)selfQMDHi << 32) | selfQMDLo;

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_scratchpad_read_lmemBase(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint64_t *lmemBase)
{
    uint32_t lmemBaseHi, lmemBaseLo;

    CUDBG_VERIFY(scratchpadAccessor && lmemBase, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, LMEM_BASE_LO, vsm, wp, 0, &lmemBaseLo);
    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, LMEM_BASE_HI, vsm, wp, 0, &lmemBaseHi);
    *lmemBase = ((uint64_t)lmemBaseHi << 32) | lmemBaseLo;

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_scratchpad_read_mpsContextId(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *mpsContextId)
{
    CUDBG_VERIFY(scratchpadAccessor && mpsContextId, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, MPS_CONTEXT_ID, vsm, wp, 0, mpsContextId);

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk10x_scratchpad_write_WAR_runTrigger1239649(HaloScratchpadAccessor scratchpadAccessor, uint32_t warRunTriggerFlagValue)
{
    CUDBG_VERIFY(scratchpadAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_SET_FIELD(scratchpadAccessor, GLOBAL, WAR_RUN_TRIGGER_1239649, 0, 0, 0, &warRunTriggerFlagValue);

    return CUDBG_SUCCESS;
}

/* Populate the debugger structure with Kepler GK10x specific functions. */
void
haloDeviceInit_gk10x(Halo_st *halo)
{
    haloDeviceInit_gf100(halo); /* Most gf100 functions can be shared with gk10x */

    /* architectural constants - always init after base chip init */
    halo->deviceInfo.spRegisterNumber = KEPLER_ABI_SP_REGNUM;
    halo->deviceInfo.systemStackPointer = KEPLER_SYSTEM_STACK_POINTER;
    halo->deviceInfo.scratchpadSize = sizeof(KeplerScratchpad_t);

    halo->getInfo = kepler_gk10x_getInfo;

    /* GK10x - account for wide breakpoint instructions */
    halo->rewindBrokenWarp = kepler_gk10x_rewindBrokenWarp;
    halo->insertBreakpoint = kepler_gk10x_insertBreakpoint;
    halo->removeBreakpoint = kepler_gk10x_removeBreakpoint;

    /* GK10x - account for LMEM_SIZE_PER_SM being moved to CWD */
    halo->readLmemConfig = kepler_gk10x_readLmemConfig;

    /* GK10x - account for LMEM (contiguous per warp) and CRS layout (16 byte entries) */
    halo->getLmemInternalOffset = kepler_gk10x_getLmemInternalOffset;
    halo->getCRSInternalOffset = kepler_gk10x_getCRSInternalOffset;
    halo->CRSEntrySize = kepler_gk10x_CRSEntrySize;
    halo->CRSEntryPaddingSize = kepler_gk10x_CRSEntryPaddingSize;
    halo->maxCRSEntriesPerWarp = kepler_gk10x_maxCRSEntriesPerWarp;
    halo->flattenCRS = kepler_gk10x_flattenCRS;
    halo->updateCRS = kepler_gk10x_updateCRS;

    /* GK10x - account for larger scratchpad size for warp state */
    halo->read_warpParams = kepler_gk10x_read_warpParams;
    halo->read_threadIdx = kepler_gk10x_read_threadIdx;

    /* GK10x - account for different shared memory offset in scratchpad */
    halo->getScratchpadSharedMemDevVaddr= kepler_gk10x_getScratchpadSharedMemDevVaddr;

    /* GK10x - need to set pairing mode in SM (this was unnecessary on gf10x) */
    halo->enablePairingMode = kepler_gk10x_enablePairingMode;
    halo->disablePairingMode = kepler_gk10x_disablePairingMode;

    /* GK10x - handle WAR for stepping MULTI and internal instructions */
    halo->isSteppable = kepler_gk10x_isSteppable;
    halo->isInternalInstructionAtPC = kepler_gk10x_isInternalInstructionAtPC;

    /* Texture memory support */
    halo->findConstBankOffset = kepler_gk10x_findConstBankOffset;
    halo->patchTextureInstruction = kepler_gk10x_patchTextureInstruction;

    /* Clear exceptions (on Kepler, this means to re-enable them) */
    halo->clearExceptions = kepler_gk10x_clearExceptions;
    halo->isAnyExceptionSet = kepler_gk10x_isAnyExceptionSet;

    /* GK10x - WAR Resume HW Bug 865738 (instanced) */
    halo->resumeDevice = kepler_gk10x_resumeDevice;
    halo->resumeSM = kepler_gk10x_resumeSM;

    /* GK10x - Account for WARs removed between Fermi to Kepler w/MMU debug mode on */
    halo->enableMMUDebuggingMode = kepler_gk10x_enableMMUDebuggingMode;
    halo->disableMMUDebuggingMode = kepler_gk10x_disableMMUDebuggingMode;
    halo->disableMMUDebuggingModeForDevice = kepler_gk10x_disableMMUDebuggingModeForDevice;

    /* GK10x - Account for RTT -> EXIT */
    halo->forceTermination = kepler_gk10x_forceTermination;

    /* GK10x - Account for additional BPT_PAUSE_PENDING clears after service routines */
    halo->thServicePostProcess = kepler_gk10x_thServicePostProcess;

    /* GK10x - Change power gating state */
    halo->setPowerGatingState = kepler_gk10x_setPowerGatingState;

    /* GK10x - Account for the fact that the CNP allocation is before the saved SP */
    halo->getSavedSPLmemAddr = kepler_gk10x_getSavedSPLmemAddr;

    /* GK10x - Account for HW bugfix (all HW single-steps send interrupts) */
    halo->isLastHwStepSynchronous = kepler_gk10x_isLastHwStepSynchronous;

    /* GK10x - Membar WAR read PC */
    halo->membarWAR_getPatchPC  = kepler_gk10x_membarWAR_getPatchPC;

    /* GK10x - Membar WAR read registers */
    halo->membarWAR_getPatchReg = kepler_gk10x_membarWAR_getPatchReg;
    halo->membarWAR_getPatchPred = kepler_gk10x_membarWAR_getPatchPred;
    halo->membarWAR_getPatchCC = kepler_gk10x_membarWAR_getPatchCC;

    /* GK10x - Membar WAR write registers */
    halo->membarWAR_setPatchReg = kepler_gk10x_membarWAR_setPatchReg;
    halo->membarWAR_setPatchPred = kepler_gk10x_membarWAR_setPatchPred;
    halo->membarWAR_setPatchCC = kepler_gk10x_membarWAR_setPatchCC;

    /* GK10x - Membar WAR read call depth */
    halo->membarWAR_getPatchCallDepth = kepler_gk10x_membarWAR_getPatchCallDepth;

    /* GK10x - BAR.SYNC WAR read PC */
    halo->barWAR_getPatchPC  = kepler_gk10x_barWAR_getPatchPC;

    /* GK10x - WAR Run Trigger HW Bug 1239649 */
    halo->startRunTriggerWar = kepler_gk10x_startRunTriggerWar;
    halo->finishRunTriggerWar = kepler_gk10x_finishRunTriggerWar;

    halo->setKnownEvent = kepler_gk10x_setKnownEvent;

    /* GK10x - detecting if a warp is on a barrier */
    halo->isWarpOnBarrier = kepler_gk10x_isWarpOnBarrier;

    halo->getLmemBase = kepler_gk10x_getLmemBase;

    /* GK10x - get userEntryFunction */
    halo->getUserEntryFunction = kepler_gk10x_getUserEntryFunction;

    /* GK10x - Single Stepping N times */
    halo->setupSingleStepNsteps = kepler_gk10x_setupSingleStepNsteps;

    halo->getPRIOffset = kepler_gk10x_getPRIOffset;

    /* Scratchpad access */

    halo->scratchpad.getFieldOffset = kepler_gk10x_scratchpad_getFieldOffset;

    halo->scratchpad.read_blockIdx = kepler_gk10x_scratchpad_read_blockIdx;
    halo->scratchpad.read_gridId = kepler_gk10x_scratchpad_read_gridId;
    halo->scratchpad.read_gridDim = kepler_gk10x_scratchpad_read_gridDim;
    halo->scratchpad.read_isWarpOnBarrier = kepler_gk10x_scratchpad_read_isWarpOnBarrier;
    halo->scratchpad.read_selfQMD = kepler_gk10x_scratchpad_read_selfQMD;
    halo->scratchpad.read_lmemBase = kepler_gk10x_scratchpad_read_lmemBase;
    halo->scratchpad.read_mpsContextId = kepler_gk10x_scratchpad_read_mpsContextId;

    halo->scratchpad.write_WAR_runTrigger1239649 = kepler_gk10x_scratchpad_write_WAR_runTrigger1239649;
}
