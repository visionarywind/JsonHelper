/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "cuda_types.h"
#include "halo_drv.h"
#include "fermi_drv.h"
#include "kepler.h"
#include "kepler_gk10x.h"
#include "kepler_gk11x.h"
#include "kepler_drv.h"

static CUDBGResult
haloDrvThUsesDynamicRegs_kepler(CUctx *ctx, NvBool *thUsesDynamicRegs);

static CUDBGResult
haloDrvAdjustCodeAddress_kepler(uint64_t physAddr,
                                uint64_t *adjustedPhysAddr,
                                CUDBGAdjAddrAction adjAction);

static CUDBGResult
haloDrvIsStackPointerAssignment_gk10x(uint64_t instruction[2],
                                      int32_t *res, uint32_t *assignmentIdx);

static CUDBGResult
haloDrvIsStackPointerAssignment_gk11x(uint64_t instruction[2],
                                      int32_t *res, uint32_t *assignmentIdx);

static CUDBGResult
haloDrvGetInstructionSize_kepler(uint64_t instruction, uint32_t *instSize);

CUDBGResult
getHaloDrvFuncPtrs_gk10x(struct HaloDrvFuncPtrs *ptrs)
{
    CUDBGResult res;

    res = getHaloDrvFuncPtrs_fermi(ptrs);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Override the functions that are different between kepler and fermi */
    ptrs->thUsesDynamicRegs = haloDrvThUsesDynamicRegs_kepler;
    ptrs->adjustCodeAddress = haloDrvAdjustCodeAddress_kepler;
    ptrs->isStackPointerAssignment = haloDrvIsStackPointerAssignment_gk10x;
    ptrs->getInstructionSize = haloDrvGetInstructionSize_kepler;

    return CUDBG_SUCCESS;
}

CUDBGResult
getHaloDrvFuncPtrs_gk11x(struct HaloDrvFuncPtrs *ptrs)
{
    CUDBGResult res;

    res = getHaloDrvFuncPtrs_gk10x(ptrs);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Override the functions that are different between kepler gk10x and gk11x */
    ptrs->isStackPointerAssignment = haloDrvIsStackPointerAssignment_gk11x;

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDrvThUsesDynamicRegs_kepler(CUctx *ctx, NvBool *thUsesDynamicRegs)
{
    /* This function should return the correct answer for kepler and higher */
    if (ctx->device->state.major > 3 || ctx->device->state.minor >= 2)
        *thUsesDynamicRegs = NV_TRUE;
    else
        *thUsesDynamicRegs = NV_FALSE;

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDrvAdjustCodeAddress_kepler(uint64_t physAddr,
                                uint64_t *adjustedPhysAddr,
                                CUDBGAdjAddrAction adjAction)
{
    switch (adjAction) {
    case CUDBG_ADJ_PREVIOUS_ADDRESS:
        *adjustedPhysAddr = physAddr - 8;
        break;
    case CUDBG_ADJ_NEXT_ADDRESS:
        *adjustedPhysAddr = physAddr + 8;
        break;
    case CUDBG_ADJ_CURRENT_ADDRESS:
        *adjustedPhysAddr = physAddr;
        break;
    default:
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static int32_t
kepler_gk10x_isShint(uint64_t instruction)
{
    /* GK10X:  SHINT Instruction Masks */
    const uint64_t KEPLER_GK10X_SHINT_OP_MASK = 0xf00000000000000fULL;
    const uint64_t KEPLER_GK10X_SHINT_OP      = 0x2000000000000007ULL;

    if ((instruction & KEPLER_GK10X_SHINT_OP_MASK) == KEPLER_GK10X_SHINT_OP)
        return 1;
    else
        return 0;
}

static CUDBGResult
haloDrvIsStackPointerAssignment_gk10x(uint64_t instruction[2],
                                      int32_t *res, uint32_t *assignmentIdx)
{
    uint64_t instructionToCheck;
    uint32_t instructionIdx = 0;

    /* Kepler ABI:  R1 is the stack pointer, which is initialized
       with a value placed in constant bank 0 at offset 68 (Kepler DCI).
       Typically, the MOV instruction is used to do this, but we'll
       also catch the case that LDC is used as well:

       MOV R1, c[0x0][0x44]
       LDC R1, c[0x0][0x44] */
    const uint64_t KEPLER_MOV_R1_C_1_68 = 0x2800400110005de4ULL;
    const uint64_t KEPLER_LDC_R1_C_1_68 = 0x1400000113f05c86ULL;

    CUDBG_VERIFY(res, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in isStackPointerAssignment.\n");

    /* Scan the two input instructions.  If the first one happens
       to be a SHINT, then we need to look at the second one.  The
       compiler can emit SHINTs as the first instruction of a kernel,
       even for debug compilation (one example is the WAR for a HW
       bug detected in Bug 1295899) */
    if (kepler_gk10x_isShint(instruction[0])) {
        instructionIdx = 1;
        instructionToCheck = instruction[1];
    }
    else {
        instructionIdx = 0;
        instructionToCheck = instruction[0];
    }

    if (instructionToCheck == KEPLER_MOV_R1_C_1_68 ||
        instructionToCheck == KEPLER_LDC_R1_C_1_68) {
        *res = 1;
        *assignmentIdx = instructionIdx;
    }
    else
        *res = 0;

    return CUDBG_SUCCESS;
}

static int32_t
kepler_gk11x_isShint(uint64_t instruction)
{
    /* GK11X:  SHINT Instruction Masks */
    const uint64_t KEPLER_GK11X_SHINT_OP_MASK = 0xf800000000000003ULL;
    const uint64_t KEPLER_GK11X_SHINT_OP      = 0x0800000000000000ULL;

    if ((instruction & KEPLER_GK11X_SHINT_OP_MASK) == KEPLER_GK11X_SHINT_OP)
        return 1;
    else
        return 0;
}

static CUDBGResult
haloDrvIsStackPointerAssignment_gk11x(uint64_t instruction[2],
                                      int32_t *res, uint32_t *assignmentIdx)
{
    uint64_t instructionToCheck;
    uint32_t instructionIdx = 0;

    /* Kepler ABI:  R1 is the stack pointer, which is initialized
       with a value placed in constant bank 0 at offset 68 (Kepler DCI).
       Typically, the MOV instruction is used to do this, but we'll
       also catch the case that LDC is used as well:

       MOV R1, c[0x0][0x44]
       LDC R1, c[0x0][0x44]

       This is true for GK10x and GK11x, but this routine needs to be
       implemented for both due to completely different instruction
       encodings between sm_30 and sm_35. */
    const uint64_t KEPLER_GK11X_MOV_R1_C_1_68 = 0x64c03c00089c0006ULL;
    const uint64_t KEPLER_GK11X_LDC_R1_C_1_68 = 0x7ca00000221ffc06ULL;

    CUDBG_VERIFY(res && assignmentIdx, CUDBG_ERROR_INVALID_ARGS, "Invalid args in isStackPointerAssignment.\n");

    /* Scan the two input instructions.  If the first one happens
       to be a SHINT, then we need to look at the second one.  The
       compiler can emit SHINTs as the first instruction of a kernel,
       even for debug compilation (one example is the WAR for a HW
       bug detected in Bug 1295899) */
    if (kepler_gk11x_isShint(instruction[0])) {
        instructionIdx = 1;
        instructionToCheck = instruction[1];
    }
    else {
        instructionIdx = 0;
        instructionToCheck = instruction[0];
    }

    if (instructionToCheck == KEPLER_GK11X_MOV_R1_C_1_68 ||
        instructionToCheck == KEPLER_GK11X_LDC_R1_C_1_68) {
        *res = 1;
        *assignmentIdx = instructionIdx;
    }
    else
        *res = 0;

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDrvGetInstructionSize_kepler(uint64_t instruction, uint32_t *instSize)
{
    *instSize = KEPLER_GK11X_INSTRUCTION_SIZE;
    return CUDBG_SUCCESS;
}
