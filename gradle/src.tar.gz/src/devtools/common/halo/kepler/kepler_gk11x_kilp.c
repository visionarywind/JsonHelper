/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: kepler_gk11x_kilp.c
 *
 *   Description:
 *       Internal API for the low-level GPU access needed to support
 *       KILP (Kepler Instruction-Level Preemption) in the debugger on
 *       Kepler (GK11x) class hardware.
 *
 ******************************************************************************/

#include "cudadebugger.h"
#include "kepler.h"
#include "halo_internal.h"
#include "halo_state.h"
#include "kepler_gk11x.h"
#include "kepler_gk11x_kilp.h"
#include "gk11x_sass.h"
#include "devtools/common/assembler/gk11x_sass_assembler.h"
#include "hal/kepler/kepler_cnp.h"
#include "cuicnp.h"
#include "kepler/kepler_structs.h"
#include "rm_call.h"
#include "ctrl/ctrl2080.h"
#include "ctrl/ctrl0080.h"
#include "kepler/gk110/dev_graphics_nobundle.h"
#include "kepler/gk110/dev_fifo.h"
#include "../../../../syscalls/debugger/kilp_structs.h"

#define KILP_DEBUG_MAPPING_TABLE  0 /* Change this to a 1 to enable tracing of the mapping table */
#define KILP_TSG_MODIFY_TIMESLICE 0 /* Change this to a 1 to modify the TSG timeslice */

static CUDBGResult
kepler_gk11x_kilp_initiatePreemptionSave(CudbgDevice dev, CudbgPreemptionState_t *preemptStatus)
{
    CUDBGResult res = CUDBG_SUCCESS;
    bool allPreemptSaved = false;
    bool ctaPreemptTriggered = false;

    CUDBG_VERIFY(preemptStatus, CUDBG_ERROR_INVALID_ARGS, "Invalid args to initiatePreemptionSave\n");

    res = dev->haloClient->initiateChannelGroupPreemptSave(dev, &allPreemptSaved, &ctaPreemptTriggered);
    if (res != CUDBG_SUCCESS)
        return res;

    /* The following should never happen.  If there was no CTA preempt
       triggered, yet somehow all contexts are not considered in the
       saved state (note this isn't strictly saved), this should have
       been an error that was caught above. */
    if (!allPreemptSaved && !ctaPreemptTriggered) {
        HALO_ERROR("Sanity check failed:  !allPreemptSaved && !ctaPreemptTriggered is true\n");
        res = CUDBG_ERROR_INTERNAL;
    }
    else if (allPreemptSaved && ctaPreemptTriggered) {
        HALO_TRACE_FUNCTION(1, "CTA Preemption Save successful for all CUDA contexts.\n");
        *preemptStatus = CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_CTA_PREEMPTED;
    }
    else if (!ctaPreemptTriggered) {
        HALO_TRACE_FUNCTION(1, "No CTA Preemption Save required yet.\n");
        *preemptStatus = CUDBG_PREEMPTION_STATE_NOT_PREEMPTED;
    }
    else if (!allPreemptSaved && ctaPreemptTriggered) {
        HALO_TRACE_FUNCTION(1, "CTA Preemption Save couldn't complete.  Continuing with KILP.\n");
        *preemptStatus = CUDBG_PREEMPTION_STATE_ILP_PENDING;
    }

    return res;
}

static CUDBGResult
kepler_gk11x_kilp_initiatePreemptionRestore(CudbgDevice dev, CudbgPreemptionState_t *preemptStatus)
{
    CUDBGResult res = CUDBG_SUCCESS;
    bool allPreemptRestored = false;

    CUDBG_VERIFY(preemptStatus, CUDBG_ERROR_INVALID_ARGS, "Invalid args to initiatePreemptionRestore\n");

    res = dev->haloClient->initiateChannelGroupPreemptRestore(dev, &allPreemptRestored);
    if (res != CUDBG_SUCCESS || !allPreemptRestored) {
        HALO_ERROR("CTA Preemption Restore failed\n");
        return res;
    }

    HALO_TRACE_FUNCTION(1, "CTA Preemption Restore successful for all CUDA contexts.\n");
    *preemptStatus = CUDBG_PREEMPTION_STATE_NOT_PREEMPTED;
    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_kilp_preemptChannelGroup(CudbgDevice dev, uint32_t rmChannelGroup,
                                      uint32_t hAppClient, bool *preemptTimedOut)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(preemptTimedOut, CUDBG_ERROR_INVALID_ARGS, "Invalid args to preemptChannelGroup\n");
    *preemptTimedOut = false; /* Initialize to false */

    res = dev->dmal->enableOrDisableChannelGroup(dev, rmChannelGroup, hAppClient, false);
    if (res != CUDBG_SUCCESS)
        return res;

    /* WAR HW BUG 967060

       If there are multiple channels switching in host, and 1 channel is locked
       on the engine (in our case, due to a breakpoint), then the 2nd channel may
       try to load itself on the device (attempt a CTA preemption of the first
       channel, which will not succeed).  In this case, if we issue a preempt
       request to the 2nd channel, it will also timeout (as it is blocked on the
       1st channel being evicted from the engine).  This request to preempt the
       2nd channel should have been a NOP, however, a hardware bug in host prevents
       the 2nd channel from ever running again (it reports ON_PBDMA_CTX_RELOAD).
       So, in the event that we know an engine is locked down due to another
       channel, avoid issuing any preempt requests to other channel groups. */
    if (dev->activeContext && dev->activeContext->hChannelGroup != rmChannelGroup) {
        /* Do NOT issue a preempt for channel groups that aren't actually resident
           on the engine.  The preempt is known to fail (timeout) as it is blocked
           on the resident channel group. */
        HALO_TRACE(10, "Skipping TSG preempt for %d (avoid HW BUG 967060)\n", rmChannelGroup);
        return CUDBG_SUCCESS;
    }

    res = dev->dmal->preemptChannelGroup(dev, rmChannelGroup, hAppClient, preemptTimedOut, 50000);
    if (res != CUDBG_SUCCESS)
        return res;

#if KILP_TSG_TIMESLICE == 1
    /* TODO:  Determine if any adjustments need to be made to the timeslice.

       We may decide to shrink the TSG timeslice to prevent starvation of
       any sort, and to allow for more efficient switching out of a context. */
    HALO_TRACE_FUNCTION(0, "Adjusting TSG timeslice\n");
    res = dev->halo.setChannelGroupTimeslice(dev, rmChannelGroup, 50000);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to set timeslice (res=%d)\n", res);
        return res;
    }
#endif

    return res;
}

static CUDBGResult
kepler_gk11x_kilp_scheduleChannelGroup(CudbgDevice dev, uint32_t rmChannelGroup, uint32_t hAppClient)
{
    return dev->dmal->enableOrDisableChannelGroup(dev, rmChannelGroup, hAppClient, true);
}

static CUDBGResult
kepler_gk11x_kilp_setChannelGroupTimeslice(CudbgDevice dev, uint32_t rmChannelGroup, uint64_t usec)
{
    return dev->dmal->setChannelGroupTimeslice(dev, rmChannelGroup, usec);
}

static CUDBGResult
kepler_gk11x_kilp_controllerIlpSuspend(Context context, uint32_t *suspend)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t suspendCommandAddress;

    CUDBG_VERIFY(suspend, CUDBG_ERROR_INVALID_ARGS, "Invalid args.\n");

    if (!context || !haloStateContextIsActive(context) ||
        !context->kilpControllerDataAddr ||
        context->dev->halo.deviceInfo.preemptionType != HALO_PREEMPTION_TYPE_KILP) {
        return CUDBG_SUCCESS;
    }

    suspendCommandAddress = context->kilpControllerDataAddr +
                            offsetof(struct KILPcontrollerData_st, suspend);

    /* Write the suspend command into the controller struct */
    res = context->dev->halo.writeGenericMemory(context,
                                                0, 0, 0,
                                                suspendCommandAddress,
                                                suspend,
                                                sizeof(*suspend));
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to write suspend save reason code (res=%d)\n", res);
        return res;
    }

    return res;
}

static CUDBGResult
kepler_gk11x_kilp_controllerIlpSetupMode(CudbgDevice dev, uint32_t mode)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t modeAddress, preemptCommandAddress;
    uint32_t modeValue, preemptCommandValue;
    bool writeScratchpad = false;

    if (!dev->activeContext ||
        !haloStateContextIsActive(dev->activeContext)) {
        return CUDBG_SUCCESS;
    }

    modeValue = mode;
    modeAddress = dev->activeContext->kilpControllerDataAddr +
                  offsetof(struct KILPcontrollerData_st, command);

    /* Write the preempt command (mode) into the controller struct */
    res = dev->halo.writeGenericMemory(dev->activeContext,
                                       0, 0, 0,
                                       modeAddress,
                                       &modeValue,
                                       sizeof(modeValue));
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to write KILP mode (res=%d)\n", res);
        return res;
    }

    /* When initiating preempt-save, or returning to 'run' mode, set the
       traphandler scratchpad state appropriately as well.

       We set the preemp-save command to vector all warps that are
       paused in the trap handler into the KILP handle_continuations
       path (it also checks if the warp is considered preemptable).

       If 'run' is specified, it means we clear the preempt flag.
       This is crucial in the case where we've initiated ILP, but
       savedCount actually ended up being zero (as all CTAs were
       found to be 'unwanted', and they relaunched themselves
       from the start without saving anything out).  In this case,
       we had first written the preempt-save command (see above
       explanation), and so now we need to clear it, to prevent
       any warps from observing the stale preempt-save command. */
    if (mode == KILP_CONTROLLER_CMD_PREEMPT) {
        preemptCommandValue = KEPLER_GK11X_KILP_TH_PREEMPT_SAVE;
        /* Write global memory must be given a DevPtr. It will then translate
           the DevPtr to a Dev VA before passing it to mapMemory */
        preemptCommandAddress = dev->activeContext->scratchpadDevPtr +
                                offsetof(KeplerScratchpad_t, preemptCommand);

        writeScratchpad = true;
    }
    else if (mode == KILP_CONTROLLER_CMD_RUN) {
        preemptCommandValue = 0;
        /* Write global memory must be given a DevPtr. It will then translate
           the DevPtr to a Dev VA before passing it to mapMemory */
        preemptCommandAddress = dev->activeContext->scratchpadDevPtr +
                                offsetof(KeplerScratchpad_t, preemptCommand);

        writeScratchpad = true;
    }

    if (writeScratchpad) {
        /* Write the preempt command to the scratchpad */
        res = dev->halo.writeGenericMemory(dev->activeContext,
                                           0, 0, 0,
                                           preemptCommandAddress,
                                           &preemptCommandValue,
                                           sizeof(preemptCommandValue));
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to write preempt reason code (res=%d)\n", res);
            return res;
        }
    }

    return res;
}

static CUDBGResult
kepler_gk11x_kilp_controllerIlpSavedCount(CudbgDevice dev, uint32_t *savedCount)
{
    CUDBGResult res;
    uint64_t savedCountAddr;

    CUDBG_VERIFY(savedCount, CUDBG_ERROR_INVALID_ARGS, "Invalid args.\n");

    savedCountAddr = dev->activeContext->kilpControllerDataAddr +
                     offsetof(struct KILPcontrollerData_st, savedCountForCpu);

    res = dev->halo.readGenericMemory(dev->activeContext,
                                      0, 0, 0,
                                      savedCountAddr,
                                      savedCount,
                                      sizeof(*savedCount));
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE_FUNCTION(0, "Failed to read global memory preempt save counter (res=%d)\n", res);
        return res;
    }

    return res;
}

static CUDBGResult
kepler_gk11x_kilp_controllerIlpRestore(CudbgDevice dev)
{
    CUDBGResult res = CUDBG_SUCCESS;
    volatile uint32_t savedCount;
    bool timeoutExceeded = false;
    cuosTimer timer;

    if (!dev->activeContext) {
        HALO_ERROR("Initiating ILP with no active context?\n");
        return CUDBG_ERROR_INTERNAL;
    }

    if (!haloStateContextIsActive(dev->activeContext)) {
        HALO_TRACE_FUNCTION(30, "Context is inactive. Early return in restore\n");
        return CUDBG_SUCCESS;
    }

    /* Wait for all previously-saved CTAs to re-trap and re-enter the traphandler.
       This count only reaches zero once all CTAs are actually in trap-mode for restore.
       TODO: Fairly extreme edge cases can prevent this restore from completing successfully.
       Build the 'washing machine' to at least guarantee forward progress. */
    timeoutExceeded = false;
    cuosResetTimer(&timer);
    do {
        if (cuosGetTimer(&timer) >= KEPLER_GK11X_KILP_GENERIC_TIMEOUT) {
            timeoutExceeded = true;
        }

        res = dev->halo.controllerIlpSavedCount(dev, (uint32_t*)&savedCount);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to read Ilp SavedCount (res=%d)\n", res);
            break;
        }
    }
    while (savedCount && !timeoutExceeded);

    if (timeoutExceeded && savedCount) {
        HALO_ERROR("Timed out waiting for all CTAs to restore (missed %d CTAs).\n", savedCount);
        return CUDBG_ERROR_INTERNAL;
    }

    return res;
}

static CUDBGResult
kepler_gk11x_kilp_isWarpEnabledForPreempt(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                          bool *isWarpEnabledForPreempt)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t warpPreemptEnableTableAddr;
    uint32_t warpEnabledForPreempt;

    CUDBG_VERIFY(isWarpEnabledForPreempt, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    /* Initialize to true */
    *isWarpEnabledForPreempt = true;

    if (!dev->activeContext)
        return CUDBG_SUCCESS;

    /* Compute the offset to this warp's CTA in the CtaIlpEnableTable */
    warpPreemptEnableTableAddr = dev->activeContext->kilpCtaIlpEnableTableAddr +
                                 ((vsm * KEPLER_MAX_CTA_PER_SM + dev->smState[vsm].warp[wp].virtCTAID) * sizeof(uint32_t));

    res = dev->halo.readGenericMemory(dev->activeContext, 0, 0, 0,
                                      warpPreemptEnableTableAddr,
                                      &warpEnabledForPreempt,
                                      sizeof warpEnabledForPreempt);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE_FUNCTION(0, "Failed to read CtaIlpEnableTable for vsm%d/wp%d (res=%d)\n", vsm, wp, res);
        return res;
    }

    *isWarpEnabledForPreempt = (bool)warpEnabledForPreempt;

    HALO_TRACE_FUNCTION(20, "vsm%d/wp%d, enabled for preempt: %d\n", vsm, wp, *isWarpEnabledForPreempt);

    return res;
}

/* HW coordinate remapping routines.  Extremely poor performance right now.
   TODO (future):  Remove this entirely (with fixed ID scheme) */
static CUDBGResult
kepler_gk11x_kilp_buildMappingTable(CudbgDevice dev, bool saveTrapBits)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CudbgPreemptionLaneMappingTable_t *preemptLaneMappingTable;
    CudbgPreemptionWarpMappingTable_t *preemptWarpMappingTable;
    CudbgPreemptionSMMappingTable_t *preemptSMMappingTable;
    uint32_t vsm, wp, ln;
    uint32_t trapBit;
    uint64_t lmemAddr;

    /* Expensive, fix this */
    memset (&dev->preemptMappingTable, 0, sizeof (dev->preemptMappingTable));

    for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
        /* Skip if this SM is either invalid, or contains no valid warps */
        if (warpBitmaskAny(&dev->smState[vsm].state.tidValid)) {
            preemptSMMappingTable              = &dev->preemptMappingTable.sm[vsm];
            warpBitmaskAssign(&preemptSMMappingTable->tidValid, &dev->smState[vsm].state.tidValid);
            warpBitmaskAssign(&preemptSMMappingTable->bpmask, &dev->smState[vsm].state.bpmask);
            warpBitmaskAssign(&preemptSMMappingTable->bptrapmask, &dev->smState[vsm].state.bptrapmask);
            warpBitmaskAssign(&preemptSMMappingTable->brokenwarps, &dev->smState[vsm].state.brokenwarps);
            for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
                preemptWarpMappingTable = &dev->preemptMappingTable.sm[vsm].warp[wp];

                /* Skip if this warp is either invalid, or contains no valid lanes */
                if (!warpBitmaskGetBits(&dev->smState[vsm].state.tidValid, wp, 1))
                    continue;

                preemptWarpMappingTable->validLanes = dev->smState[vsm].warp[wp].validLanes;
                if (!preemptWarpMappingTable->validLanes)
                    continue;

                preemptWarpMappingTable->gridId = dev->smState[vsm].warp[wp].gridId64;

                res = dev->halo.read_blockIdx(dev, vsm, wp, &preemptWarpMappingTable->blockIdx);
                if (res != CUDBG_SUCCESS) {
                    preemptWarpMappingTable->validLanes = 0;
                    continue;
                }

                for (ln = 0; ln < dev->halo.deviceInfo.numLanesPrWarp; ++ln) {
                    /* Skip if this lane is invalid */
                    if (!((1U << ln) & preemptWarpMappingTable->validLanes))
                        continue;

                    preemptLaneMappingTable = &preemptWarpMappingTable->lane[ln];
                    preemptLaneMappingTable->threadIdx = dev->smState[vsm].warp[wp].threadIdx[ln];
                    preemptLaneMappingTable->valid = 1;

                    preemptWarpMappingTable->lastValidLane = ln;
                }
            }
        }
    }

    /* If we've stopped for a device event, save out the current trap mask state
       into each warp's lmem.  As the warp coordinates will change on save/restore
       the original breakpoint masks must be properly restored later. */
    if (saveTrapBits) {
        for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
            /* Skip if this SM is either invalid, or contains no valid warps */
            if (warpBitmaskAny(&dev->smState[vsm].state.tidValid)) {
                for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
                    /* Skip if this warp is either invalid, or contains no valid lanes */
                    if (!warpBitmaskGetBits(&dev->smState[vsm].state.tidValid, wp, 1))
                        continue;
                    if (!dev->smState[vsm].warp[wp].validLanes)
                        continue;
                    /* Write this warp's trap bit in lmem, it will be restored later */
                    trapBit = !!(warpBitmaskGetBits(&dev->smState[vsm].state.brokenwarps, wp, 1));

                    lmemAddr = KEPLER_GK11X_LMEM_ABI_HI(vsm, wp) - KEPLER_GK11X_LMEM_ABI_KILP_TRAP_BIT;
                    res = dev->halo.writeLocalMemory(dev, vsm, wp, 0, lmemAddr, &trapBit, sizeof(trapBit));
                    if (res != CUDBG_SUCCESS) {
                        HALO_ERROR("Failed to write lmem trap bit (res=%d)\n", wp, res);
                        return res;
                    }
                }
            }
        }
    }

    return res;
}

static CUDBGResult
kepler_gk11x_kilp_restoreWarpMasks(CudbgDevice dev)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t vsm, wp, ln = 0, trapBit;
    uint64_t lmemAddr;
    CUwarpBitmask brokenwarps, bptrapmask;

    for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
        warpBitmaskClear(&brokenwarps);
        warpBitmaskClear(&bptrapmask);
        /* Skip if this SM is either invalid, or contains no valid warps */
        if (warpBitmaskAny(&dev->smState[vsm].state.tidValid)) {
            for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
                /* Skip if this warp is either invalid, or contains no valid lanes */
                if (!warpBitmaskGetBits(&dev->smState[vsm].state.tidValid, wp, 1))
                    continue;
                if (!dev->smState[vsm].warp[wp].validLanes)
                    continue;
                /* Read this warp's saved trap bit in lmem, and OR it in */
                lmemAddr = KEPLER_GK11X_LMEM_ABI_HI(vsm, wp) - KEPLER_GK11X_LMEM_ABI_KILP_TRAP_BIT;
                res = dev->halo.readLocalMemory(dev, vsm, wp, ln, lmemAddr, &trapBit, sizeof(trapBit));
                if (res != CUDBG_SUCCESS) {
                    HALO_ERROR("Failed to find an active lane in warp %u (res=%d)\n", wp, res);
                    return res;
                }
                if (trapBit) {
                    warpBitmaskSetBits(&brokenwarps, wp, 1, 1);
                    warpBitmaskSetBits(&bptrapmask,  wp, 1, 1);
                }

            }
        }
        HALO_TRACE_FUNCTION(20, "For SM:%u Updating brokenwarps : " CU_WARP_BIT_MASK_FMT_128_STR
                            "->" CU_WARP_BIT_MASK_FMT_128_STR
                            " bptrapmask : " CU_WARP_BIT_MASK_FMT_128_STR
                            "->" CU_WARP_BIT_MASK_FMT_128_STR "\n",
                            vsm,
                            CU_WARP_BIT_MASK_FMT_128_VAL(&dev->smState[vsm].state.brokenwarps),
                            CU_WARP_BIT_MASK_FMT_128_VAL(&brokenwarps),
                            CU_WARP_BIT_MASK_FMT_128_VAL(&dev->smState[vsm].state.bptrapmask),
                            CU_WARP_BIT_MASK_FMT_128_VAL(&bptrapmask));
        warpBitmaskAssign(&dev->smState[vsm].state.brokenwarps, &brokenwarps);
        warpBitmaskAssign(&dev->smState[vsm].state.bptrapmask, &bptrapmask);
    }

    return res;
}

static CUDBGResult
kepler_gk11x_kilp_findNewHWCoords(CudbgDevice dev, uint32_t oldVsm, uint32_t oldWp,
                                  uint32_t *vsm, uint32_t *wp)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CuDim3 oldBlockIdx, oldThreadIdx;
    CuDim3 newBlockIdx, newThreadIdx;
    uint32_t tmpVsm, tmpWp, lastLn;
    uint64_t newGridId, oldGridId;

    if (!dev->preemptMappingTable.sm[oldVsm].warp[oldWp].validLanes)
        return CUDBG_ERROR_INTERNAL;

    lastLn = dev->preemptMappingTable.sm[oldVsm].warp[oldWp].lastValidLane;

    oldGridId     = dev->preemptMappingTable.sm[oldVsm].warp[oldWp].gridId;

    oldBlockIdx.x = dev->preemptMappingTable.sm[oldVsm].warp[oldWp].blockIdx.x;
    oldBlockIdx.y = dev->preemptMappingTable.sm[oldVsm].warp[oldWp].blockIdx.y;
    oldBlockIdx.z = dev->preemptMappingTable.sm[oldVsm].warp[oldWp].blockIdx.z;

    oldThreadIdx.x = dev->preemptMappingTable.sm[oldVsm].warp[oldWp].lane[lastLn].threadIdx.x;
    oldThreadIdx.y = dev->preemptMappingTable.sm[oldVsm].warp[oldWp].lane[lastLn].threadIdx.y;
    oldThreadIdx.z = dev->preemptMappingTable.sm[oldVsm].warp[oldWp].lane[lastLn].threadIdx.z;

#if KILP_DEBUG_MAPPING_TABLE == 1
    HALO_TRACE(0, "Looking for a match on oldVsm%d/oldWp%d\n", oldVsm, oldWp);
    HALO_TRACE(0, "Oldvsm%d/Oldwarp%d == (%d,%d,%d),(%d,%d,%d)\n",
               oldVsm, oldWp, oldBlockIdx.x, oldBlockIdx.y, oldBlockIdx.z,
               oldThreadIdx.x, oldThreadIdx.y, oldThreadIdx.z);
#endif

    for (tmpVsm = 0; tmpVsm < dev->halo.deviceInfo.numSMs; ++tmpVsm) {
        for (tmpWp = 0; tmpWp < dev->halo.deviceInfo.numWarpsPrSM; ++tmpWp) {
            if (warpBitmaskGetBits(&dev->smState[tmpVsm].state.tidValid, tmpWp, 1)) {
                res = dev->halo.read_blockIdx(dev, tmpVsm, tmpWp, &newBlockIdx);
                newThreadIdx = dev->smState[tmpVsm].warp[tmpWp].threadIdx[lastLn];
                newGridId = dev->smState[tmpVsm].warp[tmpWp].gridId64;

#if KILP_DEBUG_MAPPING_TABLE == 1
                HALO_TRACE(0, "vsm%d/warp%d == (%d,%d,%d),(%d,%d,%d)\n",
                           tmpVsm, tmpWp, newBlockIdx.x, newBlockIdx.y, newBlockIdx.z,
                           newThreadIdx.x, newThreadIdx.y, newThreadIdx.z);
#endif

                if (res == CUDBG_SUCCESS && newGridId == oldGridId &&
                    (newBlockIdx.x == oldBlockIdx.x &&
                     newBlockIdx.y == oldBlockIdx.y &&
                     newBlockIdx.z == oldBlockIdx.z)
                    && (newThreadIdx.x == oldThreadIdx.x &&
                        newThreadIdx.y == oldThreadIdx.y &&
                        newThreadIdx.z == oldThreadIdx.z)) {

#if KILP_DEBUG_MAPPING_TABLE == 1
                    HALO_TRACE(0, " MATCH vsm%d/warp%d == (%d,%d,%d),(%d,%d,%d)\n",
                               tmpVsm, tmpWp, newBlockIdx.x, newBlockIdx.y, newBlockIdx.z,
                               newThreadIdx.x, newThreadIdx.y, newThreadIdx.z);
#endif

                    *vsm = tmpVsm;
                    *wp = tmpWp;
                    return res;
                }
            }
        }
    }

    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
kepler_gk11x_kilp_readWarpCtaCtxAddr(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                     uint64_t *warpCtaContextAddr)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t warpCtaContextIndirectionTableAddr;

    CUDBG_VERIFY(warpCtaContextAddr, CUDBG_ERROR_INVALID_ARGS, "Invalid args to readWarpCtaCtxAddr\n");
    CUDBG_VERIFY(dev->activeContext, CUDBG_ERROR_INTERNAL, "No active context in readWarpCtaCtxAddr\n");

    /* Clear the pointer before reading it */
    *warpCtaContextAddr = 0;

    /* Note that the entry in the ctaContextIndirectionTable is only guaranteed
       to be valid if this warp has paused AND the warp is considered preemptable */
    warpCtaContextIndirectionTableAddr =
        dev->activeContext->ctaContextIndirectionTableAddr +
        (vsm * KEPLER_MAX_CTA_PER_SM +
         dev->smState[vsm].warp[wp].virtCTAID) * sizeof(CNPctaCtx *);

    res = dev->halo.readGenericMemory(dev->activeContext, 0, 0, 0,
                                      warpCtaContextIndirectionTableAddr,
                                      warpCtaContextAddr,
                                      sizeof(CNPctaCtx *));
    if (res != CUDBG_SUCCESS)
        return res;

    return res;
}

static CUDBGResult
kepler_gk11x_kilp_getCtaCtxContinuationDataAddr(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                                uint64_t *warpCtaContextContinuationDataAddr)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t warpCtaContextContinuationDataPtrAddr;

    CUDBG_VERIFY(warpCtaContextContinuationDataAddr, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    /* Clear it out prior to reading it */
    *warpCtaContextContinuationDataAddr = 0;

    HALO_TRACE_FUNCTION(10, "->vsm%d/wp%d CTA context addr: 0x%" PRIx64 "\n",
                        vsm, wp, dev->smState[vsm].warp[wp].ctaContextAddr);

    CUDBG_VERIFY(dev->smState[vsm].warp[wp].ctaContextAddr,
                 CUDBG_ERROR_INTERNAL,
                 "Incorrect cta ctx addr (collected at time of pause)\n");

    warpCtaContextContinuationDataPtrAddr =
        dev->smState[vsm].warp[wp].ctaContextAddr +
        offsetof(struct CNPctaCtx_st, ctaContinuationData);

    HALO_TRACE_FUNCTION(10, "->vsm%d/wp%d CTA Coninuation Data Ptr addr: 0x%" PRIx64 "\n",
                        vsm, wp, warpCtaContextContinuationDataPtrAddr);

    res = dev->halo.readGenericMemory(dev->activeContext, 0, 0, 0,
                                      warpCtaContextContinuationDataPtrAddr,
                                      warpCtaContextContinuationDataAddr,
                                      sizeof(void *)); // ctaContinuationData is defined as void *
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read cta ctx continuation data address (res=%d)\n", res);
        return res;
    }

    HALO_TRACE_FUNCTION(10, "->vsm%d/wp%d CTA Continuation Data addr: 0x%" PRIx64 "\n",
                        vsm, wp, *warpCtaContextContinuationDataAddr);

    return res;
}

static CUDBGResult
kepler_gk11x_kilp_getWarpBufferAndNumRegs(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                          uint64_t warpCtaContextContinuationDataAddr,
                                          uint64_t *warpBufferPtr, uint32_t *numRegs)
{
    CUDBGResult res = CUDBG_SUCCESS;
    Grid grid;
    CuDim3 tid, bDim;
    uint32_t logicalWarpId;

    CUDBG_VERIFY(numRegs && warpBufferPtr, CUDBG_ERROR_INVALID_ARGS, "Invalid args to getWarpBuffer\n");

    /* TODO:  Grab SR_RegAlloc instead of the per-func regcount */
    grid = haloStateDeviceGetGrid(dev, dev->smState[vsm].warp[wp].gridId64);
    if (!grid || !grid->function) {
        HALO_ERROR("Couldn't find valid grid (res=%d)\n");
        return CUDBG_ERROR_INTERNAL;
    }
    *numRegs = grid->function->nrofRegisters;
    HALO_TRACE_FUNCTION(10, "#regs: %d\n", *numRegs);

    /* Compute logical warp id */
    tid = dev->smState[vsm].warp[wp].threadIdx[0];
    bDim = grid->blockDim;
    logicalWarpId = ((tid.x + tid.y*bDim.x + tid.z*bDim.x*bDim.y) + 31) / 32;
    HALO_TRACE_FUNCTION(10, "logicalWarpId = %d\n", logicalWarpId);

    /* Read from the per-logical-warp-id address to get a pointer to this warp's buffer */
    res = dev->halo.readGenericMemory(dev->activeContext, 0, 0, 0,
                                      warpCtaContextContinuationDataAddr + logicalWarpId * 8,
                                      warpBufferPtr,
                                      sizeof *warpBufferPtr);
    if (res != CUDBG_SUCCESS)
        return res;

    return res;
}

static CUDBGResult
kepler_gk11x_kilp_readSharedMemCtaCtx(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t addr,
                                      void *buf, uint32_t bufSz)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t warpCtaContextContinuationDataAddr;
    uint64_t warpCtaContextContinuationDataSharedMemAddr;

    res = kepler_gk11x_kilp_getCtaCtxContinuationDataAddr(dev, vsm, wp, &warpCtaContextContinuationDataAddr);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read cta ctx continuation data address (res=%d)\n", res);
        return res;
    }

    warpCtaContextContinuationDataSharedMemAddr =
        warpCtaContextContinuationDataAddr +
        SW_CNTBUF_V1_OFFS_CTA_SHARED_MEMORY * sizeof(uint32_t) +
        addr;

    HALO_TRACE(10, "->vsm%d/wp%d CTA Continuation Data SHMEM addr: 0x%" PRIx64 "\n",
               vsm, wp, warpCtaContextContinuationDataSharedMemAddr);

    res = dev->halo.readGenericMemory(dev->activeContext, 0, 0, 0,
                                      warpCtaContextContinuationDataSharedMemAddr, buf, bufSz);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read shared memory from cta ctx (res=%d)\n", res);
        return res;
    }

    return res;
}

static CUDBGResult
kepler_gk11x_kilp_writeSharedMemCtaCtx(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t addr,
                                       const void *buf, uint32_t bufSz)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t warpCtaContextContinuationDataAddr;
    uint64_t warpCtaContextContinuationDataSharedMemAddr;

    res = kepler_gk11x_kilp_getCtaCtxContinuationDataAddr(dev, vsm, wp, &warpCtaContextContinuationDataAddr);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read cta ctx continuation data address (res=%d)\n", res);
        return res;
    }

    warpCtaContextContinuationDataSharedMemAddr =
        warpCtaContextContinuationDataAddr +
        SW_CNTBUF_V1_OFFS_CTA_SHARED_MEMORY * sizeof(uint32_t) +
        addr;

    HALO_TRACE(10, "->vsm%d/wp%d CTA Continuation Data SHMEM addr: 0x%" PRIx64 "\n",
               vsm, wp, warpCtaContextContinuationDataSharedMemAddr);

    res = dev->halo.writeGenericMemory(dev->activeContext, 0, 0, 0,
                                       warpCtaContextContinuationDataSharedMemAddr, buf, bufSz);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read shared memory from cta ctx (res=%d)\n", res);
        return res;
    }

    return res;
}

static CUDBGResult
kepler_gk11x_kilp_setLmemBaseCtaCtx(CudbgDevice dev, uint32_t vsm, uint32_t wp)
{
    CUDBGResult res = CUDBG_SUCCESS;
    Context context;
    uint64_t warpCtaContextContinuationDataAddr;
    uint64_t warpBufferPtr;
    uint32_t numRegs;

    res = kepler_gk11x_kilp_getCtaCtxContinuationDataAddr(dev, vsm, wp, &warpCtaContextContinuationDataAddr);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read cta ctx continuation data address (res=%d)\n", res);
        return res;
    }

    res = kepler_gk11x_kilp_getWarpBufferAndNumRegs(dev, vsm, wp, warpCtaContextContinuationDataAddr,
                                                    &warpBufferPtr, &numRegs);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read warpBuffer (res=%d)\n", res);
        return res;
    }

    /* Compute the offset to lmemBase, and store it */
    dev->smState[vsm].warp[wp].lmemBase = warpBufferPtr +
                                          CTX_RND(((numRegs) + 1) * HW_SM_BYTES_PER_WARP_REGISTER, HW_SM_LOCAL_MEMORY_ALLOCATION_GRANULARITY);
    dev->smState[vsm].warp[wp].lmemSegType = HALO_MEM_SEG_LOCAL_NONDEFAULT;

    HALO_TRACE_FUNCTION(10, "LMEMBASE ->vsm%d/wp%d lmemBase = 0x%" PRIx64 "\n",
                        vsm, wp, dev->smState[vsm].warp[wp].lmemBase);

    /* Find the lmem segment corresponding to this lmemBase */
    context = dev->activeContext;
    res = haloMemoryMapGetSegmentByDevVaddr(context->memMap,
                                            dev->smState[vsm].warp[wp].lmemBase,
                                            &dev->smState[vsm].warp[wp].lmemSeg);
    CUDBG_VERIFY(res == CUDBG_SUCCESS,
                 res,
                 "vsm%u/wp%u: Error when searching for lmemSeg\n", vsm, wp);

    CUDBG_VERIFY(dev->smState[vsm].warp[wp].lmemSeg,
                 CUDBG_ERROR_INTERNAL,
                 "vsm:%u/wp%u: Can't locate lmemSeg in collectScratchpad\n", vsm, wp);

    return res;
}

static CUDBGResult
kepler_gk11x_kilp_readRegCtaCtx(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                                uint32_t regnum, uint32_t *wbuf, uint32_t bufSz)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t warpCtaContextContinuationDataAddr;
    uint64_t warpBufferPtr;
    uint32_t regval, numRegs;
    uint32_t dynamicRegisterStart = KEPLER_GK11X_DYNAMIC_REGISTER_START;
    uint32_t dynamicRegisterEnd = KEPLER_GK11X_DYNAMIC_REGISTER_END;

    res = dev->halo.getDynamicRegisterRange(&dynamicRegisterStart, &dynamicRegisterEnd);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to getDynamicRegisterRange failed in readRegCtaCtx\n");
        return res;
    }

    /* The cta context should only be accessed for 'dynamic' registers.  Further,
       the cta context doesn't hold all user register values (specifically
       r0-r2) and regs up to r15 are saved in a different fashion. */
    CUDBG_VERIFY((regnum >= dynamicRegisterStart && regnum <= dynamicRegisterEnd),
                 CUDBG_ERROR_INTERNAL,
                 "Attempt to read incorrect regnum from cta ctx\n");

    res = kepler_gk11x_kilp_getCtaCtxContinuationDataAddr(dev, vsm, wp, &warpCtaContextContinuationDataAddr);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read cta ctx continuation data address (res=%d)\n", res);
        return res;
    }

    res = kepler_gk11x_kilp_getWarpBufferAndNumRegs(dev, vsm, wp, warpCtaContextContinuationDataAddr,
                                                    &warpBufferPtr, &numRegs);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read warpBuffer (res=%d)\n", res);
        return res;
    }

    for (; bufSz; regnum++, bufSz -= 4) {
        uint32_t byteOffset = HW_SM_BYTES_PER_WARP_REGISTER;

        /* The residual (non-modulo-4) regs are saved differently */
        if (regnum > (numRegs & (~0x3))) {
            byteOffset = byteOffset + (HW_SM_BYTES_PER_WARP_REGISTER * regnum) +
                         (ln * HW_SM_BYTES_PER_SCALAR_REGISTER);
        }
        else {
            byteOffset = byteOffset + (HW_SM_BYTES_PER_WARP_REGISTER * (regnum & ~0x3)) +
                         (ln * HW_SM_BYTES_PER_SCALAR_REGISTER * 4) +
                         ((regnum % 4) * 4);
        }


        res = dev->halo.readGenericMemory(dev->activeContext, 0, 0, 0,
                                          warpBufferPtr + byteOffset,
                                          &regval,
                                          sizeof regval);
        if (res != CUDBG_SUCCESS)
            return res;

        *wbuf++ = regval;
    }

    return res;
}

static CUDBGResult
kepler_gk11x_kilp_writeRegCtaCtx(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                                 uint32_t regnum, uint32_t *wbuf, uint32_t bufSz)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t warpCtaContextContinuationDataAddr;
    uint64_t warpBufferPtr;
    uint32_t numRegs;
    uint32_t dynamicRegisterStart = KEPLER_GK11X_DYNAMIC_REGISTER_START;
    uint32_t dynamicRegisterEnd = KEPLER_GK11X_DYNAMIC_REGISTER_END;

    res = dev->halo.getDynamicRegisterRange(&dynamicRegisterStart, &dynamicRegisterEnd);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to getDynamicRegisterRange failed in writeRegCtaCtx\n");
        return res;
    }

    /* The cta context should only be accessed for 'dynamic' registers.  Further,
       the cta context doesn't hold all user register values (specifically
       r0-r2) and regs up to r15 are saved in a different fashion. */
    CUDBG_VERIFY((regnum >= dynamicRegisterStart && regnum <= dynamicRegisterEnd),
                 CUDBG_ERROR_INTERNAL,
                 "Attempt to read incorrect regnum from cta ctx\n");

    res = kepler_gk11x_kilp_getCtaCtxContinuationDataAddr(dev, vsm, wp, &warpCtaContextContinuationDataAddr);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read cta ctx continuation data address (res=%d)\n", res);
        return res;
    }

    res = kepler_gk11x_kilp_getWarpBufferAndNumRegs(dev, vsm, wp, warpCtaContextContinuationDataAddr,
                                                    &warpBufferPtr, &numRegs);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read warpBuffer (res=%d)\n", res);
        return res;
    }

    for (; bufSz; regnum++, bufSz -= 4) {
        uint32_t byteOffset = HW_SM_BYTES_PER_WARP_REGISTER;

        /* The residual (non-modulo-4) regs are saved differently */
        if (regnum > (numRegs & (~0x3))) {
            byteOffset = byteOffset + (HW_SM_BYTES_PER_WARP_REGISTER * regnum) +
                         (ln * HW_SM_BYTES_PER_SCALAR_REGISTER);
        }
        else {
            byteOffset = byteOffset + (HW_SM_BYTES_PER_WARP_REGISTER * (regnum & ~0x3)) +
                         (ln * HW_SM_BYTES_PER_SCALAR_REGISTER * 4) +
                         ((regnum % 4) * 4);
        }

        res = dev->halo.writeGenericMemory(dev->activeContext, 0, 0, 0,
                                           warpBufferPtr + byteOffset,
                                           wbuf++,
                                           sizeof *wbuf);
        if (res != CUDBG_SUCCESS)
            return res;
    }

    return res;
}

static CUDBGResult
kepler_gk11x_kilp_getCurrentGrCtxPtr(CudbgDevice dev, uint32_t *grCtxPtr)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(grCtxPtr, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    /* Query the current context ptr from FECS.  This is only guaranteed to
       work when the GPU is fully paused, so callers must be aware.  However,
       it avoids suspending/resuming CTXSW. */
    res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GLOBAL,
                                     dev->bar0 + NV_PGRAPH_PRI_FECS_CURRENT_CTX,
                                     grCtxPtr);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to query current ctx (res = %d)\n", res);
        return res;
    }

    return res;
}

static CUDBGResult
kepler_gk11x_kilp_waitForGrCtxSave(CudbgDevice dev, uint32_t grCtxPtr)
{
    CUDBGResult res = CUDBG_SUCCESS;
    bool timeoutExceeded = false;
    uint32_t residentGrCtxPtr;
    cuosTimer timer;

    /* Synchronize on preempt-save completion.

       There are a number of ways to do this:
         1.  Poll until the currently-resident context goes away
         2.  Poll for GR idle.  Races?
         3.  Poll for NV_PFIFO_PREEMPT to complete

       The following is a stab at 1, but this could likely be optimized. */
    HALO_TRACE_FUNCTION(50, "Waiting for ctx (ptr: 0x%08x) to save\n", grCtxPtr);

    cuosResetTimer(&timer);
    do {
        if (cuosGetTimer(&timer) >= KEPLER_GK11X_KILP_GENERIC_TIMEOUT) {
            timeoutExceeded = true;
        }

        res = dev->halo.getCurrentGrCtxPtr(dev, &residentGrCtxPtr);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to get current ctx ptr (res = %d)\n", res);
            return res;
        }

        HALO_TRACE_FUNCTION(50, "Resident ctx ptr: 0x%08x\n", residentGrCtxPtr);

    }
    while (residentGrCtxPtr == grCtxPtr && !timeoutExceeded);

    if (timeoutExceeded && (residentGrCtxPtr == grCtxPtr)) {
        HALO_ERROR("Timeout waiting for channel to save out!\n");
        return CUDBG_ERROR_INTERNAL;
    }

    return res;
}

static CUDBGResult
kepler_gk11x_kilp_readTextureMemoryUsingTexHeader(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                                  uint32_t texId, uint32_t dim, uint32_t *coords,
                                                  void *buf, uint32_t bufSz)
{
    uint32_t *wbuf = (uint32_t *)buf;
    uint64_t constBankOffset;
    uint32_t texHeaderIndex;
    uint64_t texDptr, offset;
    uint32_t pitch;
    uint32_t texHeaderData[CU_NV50_TEXHDR_SIZE_DWORDS];
    CUDBGResult res = CUDBG_SUCCESS;
    Context context = dev->activeContext;
    Grid grid;

    CUDBG_VERIFY((context && context->memMapActive), CUDBG_ERROR_INVALID_MEMORY_ACCESS, "Invalid memory access.\n");
    CUDBG_VERIFY(coords, CUDBG_ERROR_INVALID_ARGS, "Invalid coords passed as arguments.\n");

    /* Pull the grid for this warp */
    grid = haloStateDeviceGetGrid(dev, dev->smState[vsm].warp[wp].gridId64);
    CUDBG_VERIFY(grid, CUDBG_ERROR_INVALID_GRID, "Invalid grid.\n");

    /* Find the constant bank offset for this texture ID */
    res = dev->halo.findConstBankOffset(dev, grid->function, texId, &constBankOffset);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read const bank offset for tex id (res=%d)\n", res);
        return res;
    }

    HALO_TRACE_FUNCTION(10, "TEX ID %d const bank offset = 0x%016" PRIx64 "\n",
                        texId, constBankOffset);

    /* Load the texture header index from the const bank offset */
    res = dev->halo.readGenericMemory(context, 0, 0, 0,
                                      dev->smState[vsm].warp[wp].paramConstDptr +
                                      constBankOffset,
                                      &texHeaderIndex, sizeof(texHeaderIndex));
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read texture idx (res=%d)\n", res);
        return res;
    }

    HALO_TRACE_FUNCTION(10, "TEX ID %d header idx = 0x%08x\n", texId, texHeaderIndex);

    /* The texture header pool is in the device vaddr space.  Load
       the texture header for this texture index from there. */
    res = dev->halo.readDeviceMemory(context,
                                     context->texHeaderPoolVA +
                                     (texHeaderIndex * sizeof(CUtexhdr)),
                                     texHeaderData,
                                     sizeof(texHeaderData));
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read texture header data (res=%d)\n", res);
        return res;
    }

    /* The format of the texture header can be found in kepler_common.c.
       Load the dptr for texture data, which is split across two words in the header */
    texDptr = ((uint64_t)texHeaderData[2] << 32 | texHeaderData[1]) & CUDBG_TEX_DPTR_MASK;

    HALO_TRACE_FUNCTION(10, "TEX ID %d dptr = 0x%016" PRIx64 ", dim=%d, coord={%d,%d,%d}\n",
                        texId, texDptr, dim, coords[0], coords[1], coords[2]);

    /* Load the pitch (up to 20 bits)
       Format for this is under the Texture Header Structure section in:
       https://p4viewer.nvidia.com/get///hw/nvgpu/class/mfs/class/3d/kepler.mfs */
    pitch = texHeaderData[3] & 0xfffff;

    HALO_TRACE_FUNCTION(10, "TEX ID %d pitch = %#x texHeaderData=%#x\n", texId, pitch, texHeaderData[3]);

    switch (dim) {
    case 1:
        offset = coords[0]*sizeof(uint32_t);
        break;
    case 2:
        offset = (coords[0]*sizeof(uint32_t)) + (coords[1] * pitch);
        break;
    default:
        HALO_TRACE_FUNCTION(0, "Unsupported/invalid dimension (%d)\n", dim);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    /* Read the data for this texture request */
    res = dev->halo.readGenericMemory(context, 0, 0, 0, texDptr + offset, wbuf, bufSz);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read texture data (res=%d)\n", res);
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_kilp_releaseSharedResources(CudbgDevice dev)
{
    CUDBGResult res = CUDBG_SUCCESS, res2 = CUDBG_SUCCESS;

    /* Release all memory mappings that are oustanding for this device.
       At this point, we have preempted any/all contexts running on
       this device, so it is safe to release these mappings. */
    res = dev->haloClient->unmapMemory(dev);
    if (res != CUDBG_SUCCESS)
        HALO_ERROR("Failed to unmap memory (res=%d)\n", res);

    /* The previous call could have failed, so preserve its return code.
       We always want to ensure that RM Debug Mode is released. */
    res2 = haloSetRmDebugMode(dev, false);
    if (res2 != CUDBG_SUCCESS) {
        HALO_ERROR("Call to haloSetRmDebugMode failed in releaseSharedResources\n");
        /* Only return this error if there wasn't a previous one */
        if (res == CUDBG_SUCCESS)
            res = res2;
    }

    return res;
}

/* Populate the debugger structure with Kepler GK11x specific functions. */
void
haloDeviceInit_gk11x_kilp(Halo_st *halo)
{
    /* GK11x - Instruction-level preemption routines */
    halo->initiatePreemptionSave = kepler_gk11x_kilp_initiatePreemptionSave;
    halo->initiatePreemptionRestore = kepler_gk11x_kilp_initiatePreemptionRestore;
    halo->preemptChannelGroup = kepler_gk11x_kilp_preemptChannelGroup;
    halo->scheduleChannelGroup = kepler_gk11x_kilp_scheduleChannelGroup;
    halo->setChannelGroupTimeslice = kepler_gk11x_kilp_setChannelGroupTimeslice;
    halo->controllerIlpSuspend = kepler_gk11x_kilp_controllerIlpSuspend;
    halo->controllerIlpSetupMode = kepler_gk11x_kilp_controllerIlpSetupMode;
    halo->controllerIlpSavedCount = kepler_gk11x_kilp_controllerIlpSavedCount;
    halo->controllerIlpRestore = kepler_gk11x_kilp_controllerIlpRestore;
    halo->isWarpEnabledForPreempt = kepler_gk11x_kilp_isWarpEnabledForPreempt;
    halo->buildMappingTable = kepler_gk11x_kilp_buildMappingTable;
    halo->restoreWarpMasks = kepler_gk11x_kilp_restoreWarpMasks;
    halo->findNewHWCoords = kepler_gk11x_kilp_findNewHWCoords;
    halo->getCurrentGrCtxPtr = kepler_gk11x_kilp_getCurrentGrCtxPtr;
    halo->waitForGrCtxSave = kepler_gk11x_kilp_waitForGrCtxSave;
    halo->releaseSharedResources = kepler_gk11x_kilp_releaseSharedResources;

    /* GK11x - Preemption read/write memory routines (from cta ctx) */
    halo->readWarpCtaCtxAddr = kepler_gk11x_kilp_readWarpCtaCtxAddr;
    halo->setLmemBaseCtaCtx = kepler_gk11x_kilp_setLmemBaseCtaCtx;
    halo->readSharedMemCtaCtx = kepler_gk11x_kilp_readSharedMemCtaCtx;
    halo->writeSharedMemCtaCtx = kepler_gk11x_kilp_writeSharedMemCtaCtx;
    halo->readSharedMemCtaCtx = kepler_gk11x_kilp_readSharedMemCtaCtx;
    halo->readRegCtaCtx = kepler_gk11x_kilp_readRegCtaCtx;
    halo->writeRegCtaCtx = kepler_gk11x_kilp_writeRegCtaCtx;
    halo->readTextureMemoryUsingTexHeader = kepler_gk11x_kilp_readTextureMemoryUsingTexHeader;
};
