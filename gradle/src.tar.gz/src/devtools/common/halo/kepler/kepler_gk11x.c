/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: kepler_gk11x.c
 *
 *   Description:
 *       Internal API for the low-level GPU access needed to support
 *       the debugger on Kepler (GK11x).
 *
 ******************************************************************************/

#include "cudadebugger.h"
#include "kepler.h"
#include "halo_internal.h"
#include "halo_state.h"
#include "kepler_gk11x.h"
#include "gk11x_sass.h"
#include "kepler/gk110/dev_graphics_nobundle.h"
#include "devtools/common/assembler/gk11x_sass_assembler.h"
#include "hal/kepler/kepler_cnp.h"
#include "cuicnp.h"
#include "kepler/kepler_structs.h"

/* Export functions from the Fermi hal for code reuse. */
extern CUDBGResult fermi_waitForSMPause(CudbgDevice dev, uint32_t vsm);

/* Export functions from the Fermi hal for code reuse. */
extern CUDBGResult fermi_getGridStatus(CudbgDevice dev, uint64_t gridId64, CUDBGGridStatus *status);

CUDBGResult
kepler_gk11x_getInfo(CudbgDevice dev)
{
    CUDBGResult res;

    /* We need almost everything that is collected for gk10x */
    res = kepler_gk10x_getInfo(dev);

    /* Account for larger register file on GK11x */
    dev->halo.deviceInfo.numRegsPrLane = CUDBG_MAX_REG_KEPLER_11X;

    /* Account for different opcodes on GK11x */
    dev->halo.deviceInfo.bpt64Inst = KEPLER_GK11X_BREAKPT64;

    return res;
}

static CUDBGResult
kepler_gk11x_writePauseServicedMask(CudbgDevice dev, bool full_resume, uint32_t vsm)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t hiddenWarpsMask;
    Context context = dev->activeContext;
    uint64_t pauseServicedMask, validWarpMask;
    uint64_t newPauseServicedMask;
    CUwarpBitmask tmpMask;

    /* It is not an error to not have an active context when this is
       called, however, we cannot attempt to map memory if that's the
       case.  Simply return success here. */
    if (!context || !haloStateContextIsActive(context))
        return CUDBG_SUCCESS;


    if (full_resume) {
        for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
            res = dev->halo.scratchpad.read_pauseServicedMask_raw(context->scratchpadAccessor, vsm, &pauseServicedMask);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read pause serviced mask\n");

            newPauseServicedMask = (uint64_t)warpBitmaskGetBits(&dev->pauseServicedMask[vsm], 0, 64);

            HALO_TRACE_FUNCTION(10, "[Full Resume] Updating SM%d's pauseServiceMask "
                                "from 0x%" PRIx64 " to 0x%" PRIx64 "\n",
                                vsm, pauseServicedMask,
                                newPauseServicedMask);
            pauseServicedMask = newPauseServicedMask;
            res = dev->halo.scratchpad.write_pauseServicedMask_raw(context->scratchpadAccessor, vsm, pauseServicedMask);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to write pause serviced mask\n");
        }
    }
    else {
        /* Some warps might have been hidden from the user earlier since they were in a syscall.
           When hiding these warps, they would have been masked out from tidValid, but since
           the pauseServicedMask field in the scratchpad had a bit set for each valid warp that
           paused, pauseServicedMask & ~tidValid gives the mask of hidden warps. We must ensure
           that we don't inadvertently resume these hidden warps, as they might exit the traphandler
           and make the SM exit trap mode, causing us to hang waiting for LOCKED_DOWN on Maxwell
           and higher. See bug 1195172. */
        res = dev->halo.scratchpad.read_pauseServicedMask_raw(context->scratchpadAccessor, vsm, &pauseServicedMask);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read pause serviced mask\n");
        validWarpMask = (uint64_t)warpBitmaskGetBits(&dev->smState[vsm].state.tidValid, 0, 64);
        hiddenWarpsMask = pauseServicedMask & ~validWarpMask;

        newPauseServicedMask = (uint64_t)warpBitmaskGetBits(&dev->pauseServicedMask[vsm], 0, 64);

        HALO_TRACE_FUNCTION(10, "[SM Resume] Updating SM%d's pauseServiceMask "
                            "from %" PRIx64 " to (%" PRIx64 "|%" PRIx64 ")\n",
                            vsm, pauseServicedMask,
                            newPauseServicedMask,
                            hiddenWarpsMask);

        pauseServicedMask = newPauseServicedMask | hiddenWarpsMask;
        res = dev->halo.scratchpad.write_pauseServicedMask_raw(context->scratchpadAccessor, vsm, pauseServicedMask);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read pause serviced mask\n");

        /* If we're updating the pauseServicedMask, then we also need to update the pause mask.
           These should always be consistent.  Single-GPU debugging exposed this, but it can
           also happen in other cases -- if warps are hopping over a barrier, and we left the
           actual pause mask clear for hidden warps, then those hidden warps will repause (because
           of the updates made to include them in the pauseServicedMask above), which can
           immediately retrap the warps that were trying to make forward progress.  So, keep
           these warps frozen until a full resume occurs. */
        HALO_TRACE_FUNCTION(10, "[SM Resume] Re-updating SM%d's breakpoint mask (bpt_pause_mask)"
                            "to 0x%" PRIx64 "\n", vsm, pauseServicedMask);
        warpBitmaskClear(&tmpMask);
        warpBitmaskSetBits(&tmpMask, 0, 64, pauseServicedMask);
        res = dev->halo.writeBreakpointMask(dev, vsm, &tmpMask);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to update the breakpoint mask (res=%d)\n", res);
            return res;
        }
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_readPauseServicedMask(struct Halo_st *halo, HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, CUwarpBitmask *mask)
{
    CUDBGResult res;

    CUDBG_VERIFY(halo && scratchpadAccessor && mask, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    res = halo->scratchpad.read_pauseServicedMask(scratchpadAccessor, vsm, mask);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read pause serviced mask\n");

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_getInstructionSize(CudbgDevice dev, uint64_t inst, uint32_t *instSize)
{
    CUDBG_VERIFY(instSize, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in getInstructionSize.\n");

    *instSize = KEPLER_GK11X_INSTRUCTION_SIZE;
    return CUDBG_SUCCESS;
}

static int32_t
kepler_gk11x_isExit(CudbgDevice dev, uint64_t instruction)
{
    /* GK11X:  EXIT Instruction Masks */
    return BF_GET(GK110SASS_OPCODE5SUB6, instruction) == GK110SASS_OPCODE5SUB6__OP_EXIT;
}

static int32_t
kepler_gk11x_isRet(CudbgDevice dev, uint64_t instruction)
{
    /* GK11X:  RET Instruction Masks */
    return BF_GET(GK110SASS_OPCODE5SUB6, instruction) == GK110SASS_OPCODE5SUB6__RET;
}

static int32_t
kepler_gk11x_isCall(CudbgDevice dev, uint64_t instruction)
{
    /* GK11X:  CALL Instruction Masks */
    const uint64_t KEPLER_GK11X_CALL_OP_MASK = 0xff80000000000003ULL;
    const uint64_t KEPLER_GK11X_CALL_OP      = 0x1300000000000000ULL;

    if ((instruction & KEPLER_GK11X_CALL_OP_MASK) == KEPLER_GK11X_CALL_OP)
        return 1;
    else
        return 0;

}

static int32_t
kepler_gk11x_isBarrier(CudbgDevice dev, uint64_t instruction)
{
    return (instruction & GK110SASS_INST7_5_MASK) == GK110SASS_INST7_5(MISC2, BAR);
}

static int32_t
kepler_gk11x_isShint(CudbgDevice dev, uint64_t instruction)
{
    /* GK11X:  SHINT Instruction Masks */
    const uint64_t KEPLER_GK11X_SHINT_OP_MASK = 0xf800000000000003ULL;
    const uint64_t KEPLER_GK11X_SHINT_OP      = 0x0800000000000000ULL;

    if ((instruction & KEPLER_GK11X_SHINT_OP_MASK) == KEPLER_GK11X_SHINT_OP)
        return 1;
    else
        return 0;
}

static int32_t
kepler_gk11x_isContinuation(CudbgDevice dev, uint64_t instruction)
{
    /* GK11X:  CONTINUATION Instruction Masks */
    const uint64_t KEPLER_GK11X_CONTINUATION_OP_MASK = 0xff8007ffff800383ULL;
    const uint64_t KEPLER_GK11X_CONTINUATION_OP      = 0x0000000001000300ULL;

    if ((instruction & KEPLER_GK11X_CONTINUATION_OP_MASK) == KEPLER_GK11X_CONTINUATION_OP)
        return 1;
    else
        return 0;
}

/* Returns true in *isSteppable if the instruction at PC can be stepped,
   false otherwise. If not steppable, *breakAddr will contain the PC
   address where to insert a breakpoint to step that instruction, and
   *breakMask will contain the mask of warps to resume (low bit means
   resume). Otherwise, *breakAddr and *breakMask are untouched. */
static CUDBGResult
kepler_gk11x_isSteppable(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                         uint64_t pc, bool inPatch, uint64_t *breakAddr,
                         CUwarpBitmask *breakMask, bool *isSteppable,
                         bool *requiresExitStep)
{
    Grid grid;
    uint64_t inst;
    CUDBGResult res;
    bool isWarpOnBarrier = false;

    CUDBG_VERIFY((breakAddr && breakMask && isSteppable && requiresExitStep),
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments in isSteppable.\n");

    CUDBG_VERIFY((vsm < dev->halo.deviceInfo.numSMs), CUDBG_ERROR_INVALID_SM, "Invalid vsm in isSteppable.\n");

    CUDBG_VERIFY(warpBitmaskGetBits(&dev->smState[vsm].state.tidValid, wp, 1),
                 CUDBG_ERROR_INVALID_WARP,
                 "Invalid warp in isSteppable.\n");

    /* Initialize default behavior */
    *breakAddr        = ~0U;
    warpBitmaskFill(breakMask, 1);
    *isSteppable      = true;
    *requiresExitStep = false;

    res = dev->halo.readCodeMemory(dev->activeContext, pc, &inst, sizeof inst);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read memory from offset 0x%08x\n", pc);
        return res;
    }

    /* GK110/CNP:  We need to avoid step-resumes (more importantly, inserting
       a BPT.TRAP) while we are stepping through a region of code that is
       protected with IDE.DIS).  So, if this is the case, then always mark
       the instruction as being steppable (without actually checking the
       instruction itself). */
    if (dev->smState[vsm].state.inIDECS) {
        HALO_TRACE(2, "SM%d in IDE CS, all instructions considered steppable\n", vsm);
        *isSteppable = true;
        return CUDBG_SUCCESS;
    }

    grid = haloStateDeviceGetGrid(dev, dev->smState[vsm].warp[wp].gridId64);
    CUDBG_VERIFY(grid && grid->function && grid->function->module,
                 CUDBG_ERROR_INTERNAL,
                 "Invalid grid\n");

    if (grid->function->module->abiVersion < ELFOSABIV_ABI && kepler_gk11x_isCall(dev, inst)) {
        HALO_TRACE(2, "  Found an unsteppable call at pc = %x\n", pc);
        warpBitmaskFill(breakMask, 1);
        warpBitmaskSetBits(breakMask, wp, 1, 0);
        *breakAddr = pc + 8;
        *isSteppable = false;
        return CUDBG_SUCCESS;
    }

    /* If the PC indicates we're on a barrier, trust that first.  Otherwise,
       rely on this warp's barrier state to determine if it's waiting on
       a barrier. */
    if (kepler_gk11x_isBarrier(dev, inst)) {
        uint32_t tmpWp;
        HALO_TRACE(2, "  Found an unsteppable barrier at pc = %x\n", pc);
        /* Need to resume all warps in the same cta as this warp */
        warpBitmaskFill(breakMask, 1);
        warpBitmaskSetBits(breakMask, wp, 1, 0);
        for (tmpWp = 0; tmpWp < dev->halo.deviceInfo.numWarpsPrSM; ++tmpWp)
            if (haloWarpsInSameCTA(dev, vsm, wp, tmpWp))
                warpBitmaskSetBits(breakMask, tmpWp, 1, 0);
        *breakAddr = pc + 8;
        *isSteppable = false;
        return CUDBG_SUCCESS;
    }

    /* This warp's PC isn't pointing at a barrier, but it could still be
       waiting on one due to how Kepler's BRU works.  If the following
       check succeeds, B2R.WARP state indicates this warp is waiting on
       a barrier, which means we need to break at *this* PC. */
    res = kepler_gk10x_isWarpOnBarrier(dev, vsm, wp, &isWarpOnBarrier);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to isWarpOnBarrier failed (res=%d)\n", res);
        return res;
    }

    if (isWarpOnBarrier) {
        uint32_t tmpWp;
        HALO_TRACE(2, "  Found an unsteppable barrier at pc = %x\n", pc);
        /* Need to resume all warps in the same cta as this warp */
        warpBitmaskFill(breakMask, 1);
        warpBitmaskSetBits(breakMask, wp, 1, 0);
        for (tmpWp = 0; tmpWp < dev->halo.deviceInfo.numWarpsPrSM; ++tmpWp)
            if (haloWarpsInSameCTA(dev, vsm, wp, tmpWp))
                warpBitmaskSetBits(breakMask, tmpWp, 1, 0);
        *breakAddr = pc;
        *isSteppable = false;
        return CUDBG_SUCCESS;
    }

    /* Kepler SHINT instructions are 'special'.  They are not actual
       instructions, yet are the size of an instruction and reside in
       the instruction stream.  As a result, when SHINTs are active
       (inserted at the very beginning of a cacheline) they will not
       commit the PC until the next 'real' instruction commits.  To
       the end user, this looks like 2 instructions were stepped.  The
       fun part is if the SHINT is not active (not inserted at the very
       beginning of a cacheline, they are NOP'd, in which case they
       step 1 instruction.  To avoid this confusion, we mark SHINTs as
       not being steppable. */
    if (kepler_gk11x_isShint(dev, inst)) {
        HALO_TRACE(2, "  Found an unsteppable SHINT at pc = %x\n", pc);
        warpBitmaskFill(breakMask, 1);
        warpBitmaskSetBits(breakMask, wp, 1, 0);
        *breakAddr = pc + 8;
        *isSteppable = false;
        return CUDBG_SUCCESS;
    }

    /* GK110/CNP:  Resume the entire SM over BPT.TRAP 2, in order to allow
       continuations to properly occur. */
    if (kepler_gk11x_isContinuation(dev, inst)) {
        HALO_TRACE(2, "  Found an unsteppable continuation at pc = %x\n", pc);
        warpBitmaskClear(breakMask); /* The entire SM resumes */
        *breakAddr = pc + 8;
        *isSteppable = false;
        return CUDBG_SUCCESS;
    }

    /* GK11X _should_ have fixed the MULTI bug (On GK10X, MULTI instructions will
       sometimes cause 2 instructions to be stepped).  We'll ignore them here
       unless emulation shows otherwise. */

    *isSteppable = true;
    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_isInternalInstructionAtPC(CudbgDevice dev, uint64_t inst, uint64_t gpuAddr,
                                       bool *isInternalInstruction)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(isInternalInstruction, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args in kepler_gk11x_isInternalInstruction\n");

    /* initialize to false (not an internal instruction) */
    *isInternalInstruction = false;

    if (kepler_gk11x_isShint(dev, inst)) {
        HALO_TRACE(2, "  Found an internal SHINT\n");
        *isInternalInstruction = true;
        return CUDBG_SUCCESS;
    }

    return res;
}

static CUDBGResult
kepler_gk11x_patchDynamicRegisterRead(CudbgDevice dev, uint32_t regnum, uint32_t lmemAddr)
{
    CUDBGResult res;
    Context ctx;
    uint64_t pc, inst;

    CUDBG_VERIFY(dev->activeContext, CUDBG_ERROR_INVALID_CONTEXT, "No active context in patchDynamicRegisterRead.\n");

    /* Update the STL instruction at thRdRegOffset in the trap handler
       to account for the requested register. */
    ctx = dev->activeContext;
    pc = (ctx->thCodeVA + ctx->thRdRegOffset) - ctx->funcMemBaseVA;
    inst = GK110SASS_INST_STL(RZ, lmemAddr, regnum);

    res = dev->halo.writeCodeMemory(ctx, pc, &inst, sizeof inst);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to write code memory at offset 0x%08x (res=%d)\n", pc, res);
        return res;
    }

    HALO_TRACE_FUNCTION(1, "Wrote instruction to 0x%" PRIx64 ": 0x%" PRIx64 "\n", pc, inst);

    /* Need to invalidate the I-Cache, since we're
       patching code memory in the trap handler. */
    res = dev->halo.invalidateICache(dev);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to invalidate icache (res=%d)\n", res);
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_patchDynamicRegisterWrite(CudbgDevice dev, uint32_t regnum, uint32_t regval)
{
    CUDBGResult res;
    Context ctx;
    uint64_t pc, inst;

    CUDBG_VERIFY(dev->activeContext, CUDBG_ERROR_INVALID_CONTEXT, "No active context in patchDynamicRegisterWrite.\n");

    /* Update the MOV32I instruction at thWrRegOffset in the trap handler
       to account for the requested register and value. */
    ctx = dev->activeContext;
    pc = (ctx->thCodeVA + ctx->thWrRegOffset) - ctx->funcMemBaseVA;
    inst = GK110SASS_INST_MOV32I(regnum, regval);
    BF_SETFLDV(inst, GK110SASS_PRED, 0x0);  /* Set P0 predicate */

    res = dev->halo.writeCodeMemory(ctx, pc, &inst, sizeof inst);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to write code memory at offset 0x%08x (res=%d)\n", pc, res);
        return res;
    }

    HALO_TRACE_FUNCTION(1, "Wrote instruction to 0x%" PRIx64 ": 0x%" PRIx64 "\n", pc, inst);

    /* Need to invalidate the I-Cache, since we're
       patching code memory in the trap handler. */
    res = dev->halo.invalidateICache(dev);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to invalidate icache (res=%d)\n", res);
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_readRegisterRange(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                               uint32_t firstRegnum, uint32_t *registers, uint32_t numRegs,
                               bool rawSpValue)
{
    CUDBGResult res;
    Context context = dev->activeContext;
    Grid grid;
    bool inSyscall = false;
    uint32_t base, regnum, numRegsUsedByKernel;
    uint32_t spval = 0;
    uint32_t dynamicRegisterStart;
    uint32_t dynamicRegisterEnd;
    uint32_t lastRegnum = firstRegnum + numRegs - 1;

    CUDBG_VERIFY((context && context->memMapActive),
                 CUDBG_ERROR_INVALID_CONTEXT,
                 "Invalid context in readRegisterRange.\n");

    /* GK110 - We have 256 registers now.  Reserving space for all of them
       in LMEM_HI is unacceptable, so for registers between R63 and R255
       we give them a single dynamic slot in LMEM_HI, and force the trap
       handler to read/write them as a service routine. */
    res = dev->halo.getDynamicRegisterRange(&dynamicRegisterStart, &dynamicRegisterEnd);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Call to getDynamicRegisterRange failed in readRegisterRange.\n");
    CUDBG_VERIFY(firstRegnum <= dynamicRegisterEnd && lastRegnum <= dynamicRegisterEnd,
                 CUDBG_ERROR_INVALID_ARGS, "Requested register range is too big\n");

    grid = haloStateDeviceGetGrid(dev, dev->smState[vsm].warp[wp].gridId64);
    CUDBG_VERIFY(grid && grid->function, CUDBG_ERROR_INTERNAL, "Couldn't find valid grid (res=%d)\n");
    numRegsUsedByKernel = grid->function->nrofRegisters;

    regnum = firstRegnum;

    for (; regnum <= lastRegnum && regnum < dynamicRegisterStart; regnum++) {
        if (numRegsUsedByKernel && (regnum >= numRegsUsedByKernel)) {
            HALO_TRACE_FUNCTION(50, "Returning zero for reg %d\n", regnum);
            registers[regnum - firstRegnum] = 0;
            continue;
        }

        /* Special handling for syscalls.
           If this lane is stopped in a syscall patch, then we will intercept reads
           to R1 (the stack pointer) */
        if (!rawSpValue &&
            dev->haloClient->state.overrideInSyscallSPValue &&
            (regnum == dev->halo.deviceInfo.spRegisterNumber)) {
            res = dev->halo.findSyscallSP(dev, vsm, wp, ln, &inSyscall, &spval);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read syscall stack pointer\n");

            if (inSyscall) {
                HALO_TRACE_FUNCTION(1, "Reading stack pointer inside syscall. Returning : 0x%x\n", spval);
                registers[regnum - firstRegnum] = spval;
                continue;
            }
        }

        /* KILP - special handling when we're preempted.  R0-R3 are saved separately */
        base = dev->preemptState == CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_PREEMPTED_FOR_DEVICE_EVENT && regnum <= 3
          ? KEPLER_GK11X_LMEM_ABI_HI(vsm, wp) - KEPLER_GK11X_LMEM_ABI_KILP_R0
          : KEPLER_GK11X_LMEM_ABI_HI(vsm, wp) - KEPLER_GK11X_LMEM_ABI_SAVED_R0;

        res = dev->halo.readLocalMemory(dev, vsm, wp, ln, base - regnum * sizeof(uint32_t), &registers[regnum - firstRegnum], sizeof(*registers));
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read lmem in readRegisterRange.\n");
    }

    /* Exit if already read all registers, otherwise read the dynamic ones */
    if (regnum > lastRegnum) {
        return CUDBG_SUCCESS;
    }

    /* If we've preempted, read out dynamic registers from the cta ctx */
    if (dev->preemptState == CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_PREEMPTED_FOR_DEVICE_EVENT) {
        res = dev->halo.readRegCtaCtx(dev, vsm, wp, ln, regnum, &registers[regnum - firstRegnum], lastRegnum - regnum + 1);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read regs from cta ctx (res=%d)\n", res);

        return CUDBG_SUCCESS;
    }

    base = KEPLER_GK11X_LMEM_ABI_HI(vsm, wp) - KEPLER_GK11X_LMEM_ABI_DYNAMIC_REGISTER;
    for (; regnum <= lastRegnum; regnum++) {
        if (numRegsUsedByKernel && (regnum >= numRegsUsedByKernel)) {
            HALO_TRACE_FUNCTION(50, "Returning zero for reg %d\n", regnum);
            registers[regnum - firstRegnum] = 0;
            continue;
        }

        res = dev->halo.patchDynamicRegisterRead(dev, regnum, base);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Call to patchDynamicRegisterRead failed in readRegisterRange.\n");

        res = dev->halo.thService(dev, vsm, wp, 0 /* unused */, 0 /* unused */, TH_SERVICE_LRF_READ);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Call to thService failed in readRegisterRange.\n");

        /* thService has changed the gpu cache state!
           Use readServiceRoutineData here as it ensures proper
           cache coherency to get the register value. */
        res = dev->dmal->readServiceRoutineData(dev, vsm, wp, ln, base, &registers[regnum - firstRegnum], sizeof(*registers));
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read lmem in readRegisterRange.\n");
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_writeRegisterFile(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                               uint64_t offset, const void *buf, uint32_t bufSz)
{
    uint32_t *wbuf = (uint32_t *) buf;
    uint32_t offset32 = (uint32_t) offset;
    uint32_t base, regnum;
    Context context = dev->activeContext;
    CUDBGResult res;
    uint32_t dynamicRegisterStart = KEPLER_GK11X_DYNAMIC_REGISTER_START;
    uint32_t dynamicRegisterEnd = KEPLER_GK11X_DYNAMIC_REGISTER_END;

    CUDBG_VERIFY((context && context->memMapActive), CUDBG_ERROR_INVALID_CONTEXT, "Invalid context in writeRegisterFile.\n");

    CUDBG_VERIFY(((uint64_t) offset32 == offset && !((offset32 | bufSz) & 3)),
                 CUDBG_ERROR_INVALID_MEMORY_ACCESS,
                 "Invalid memory access in writeRegisterFile.\n");

    /* GK110 - We have 256 registers now.  Reserving space for all of them
       in LMEM_HI is unacceptable, so for registers between R63 and R255
       we give them a single dynamic slot in LMEM_HI, and force the trap
       handler to read/write them as a service routine. */
    regnum = offset32 / 4;

    res = dev->halo.getDynamicRegisterRange(&dynamicRegisterStart, &dynamicRegisterEnd);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to getDynamicRegisterRange failed in writeRegisterFile.\n");
        return res;
    }

    if (dynamicRegisterStart <= regnum && regnum <= dynamicRegisterEnd) {
        /* If we've preempted, write to dynamic registers using the cta ctx */
        if (dev->preemptState == CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_PREEMPTED_FOR_DEVICE_EVENT) {
            res = dev->halo.writeRegCtaCtx(dev, vsm, wp, ln, regnum, wbuf, bufSz);
            if (res != CUDBG_SUCCESS) {
                HALO_ERROR("Failed to write regs from cta ctx (res=%d)\n", res);
                return res;
            }
        }
        else {
            base = KEPLER_GK11X_LMEM_ABI_HI(vsm, wp) - KEPLER_GK11X_LMEM_ABI_DYNAMIC_REGISTER;

            for (; bufSz; regnum++, bufSz -= 4) {
                res = dev->halo.patchDynamicRegisterWrite(dev, regnum, *wbuf);
                if (res != CUDBG_SUCCESS) {
                    HALO_ERROR("Call to patchDynamicRegisterWrite failed in writeRegisterFile.\n");
                    return res;
                }

                /* Specify the lane to execute via the addr argument */
                res = dev->halo.thService(dev, vsm, wp, ln, bufSz, TH_SERVICE_LRF_WRITE);
                if (res != CUDBG_SUCCESS) {
                    HALO_ERROR("Call to thService failed in writeRegisterFile.\n");
                    return res;
                }

                wbuf++;
            }
        }
    }
    else {
        base = KEPLER_GK11X_LMEM_ABI_HI(vsm, wp) - KEPLER_GK11X_LMEM_ABI_SAVED_R0;
        for (; bufSz; offset32 += 4, bufSz -= 4) {
            /* KILP - special handling when we're preempted.  R0-R3 are saved separately. */
            if (dev->preemptState == CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_PREEMPTED_FOR_DEVICE_EVENT)
                base = (offset32 <= 12) ?
                       KEPLER_GK11X_LMEM_ABI_HI(vsm,wp) - KEPLER_GK11X_LMEM_ABI_KILP_R0 : base;

            res = dev->halo.writeLocalMemory(dev, vsm, wp, ln, base - offset32, wbuf, 4);
            if (res != CUDBG_SUCCESS) {
                HALO_ERROR("Failed to write lmem in writeRegisterFile.\n");
                return res;
            }

            wbuf++;
        }
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_getDCIOffset(uint32_t field, uint32_t *offset)
{
    if (field > DCI_FIELD_NUM_FIELDS)
        return CUDBG_ERROR_INVALID_ARGS;

    switch (field) {
    case DCI_FIELD_NTID_X:
        *offset = (uint32_t)offsetof(CUkeplerGridParams, blockDim);
        break;
    case DCI_FIELD_NCTAID_Z:
        *offset = (uint32_t)offsetof(CUkeplerGridParams, gridDim) + 2;
        break;
    case DCI_FIELD_GRIDID32:
        *offset = (uint32_t)offsetof(CUkeplerGridParams, gridId32);
        break;
    case DCI_FIELD_GRIDID64:
        *offset = (uint32_t)offsetof(CUkeplerGridParams, gridId);
        break;
    default:
        HALO_ERROR("Could not find DCI offset for field %d!\n", field);
        return CUDBG_ERROR_INTERNAL;
    }

    return CUDBG_SUCCESS;
}

/* This function finds the parent Grid for a given child Grid. */
static CUDBGResult
kepler_gk11x_findParentGrid(CudbgDevice dev, Grid childGrid, Grid *parentGrid)
{
    CUDBGResult res;
    uint32_t startPc;
    uint64_t selfQMDdptr;
    uint64_t paramConstDptr;
    uint64_t cnpParentCtxDptr;
    uint64_t gridIdOffset;
    uint64_t startPcOffset;
    uint64_t blockDimOffset;
    uint64_t gridDimOffset;
    uint64_t selfQMDdptrOffset;
    uint64_t paramConstDptrOffset;
    DeviceFunction function;
    CuDim3 gridDim, blockDim;
    uint64_t parentGridId64;
    uint32_t size;
    CNPparentCtx cnpParentCtx = {0};
    uint32_t blockDimPacked[3], gridDimPacked[3];
    Context context;

    /* First, check to see if we already have the info we need */
    if (childGrid->parentGridId64) {
        *parentGrid = haloStateDeviceGetGrid(dev, childGrid->parentGridId64);

        /* If the grid is already present, this info would have been collected. */
        if (*parentGrid) {
            HALO_TRACE_FUNCTION(2, "parentGridId %" PRId64 " already known, finishing\n", childGrid->parentGridId64);
            return CUDBG_SUCCESS;
        }
    }

    /* Get the context */
    context = childGrid->function->module->context;

    /* Get the dptr to this grid's QMDLaunch structure */
    selfQMDdptr = childGrid->selfQMDdptr;

    HALO_TRACE_FUNCTION(2, "Finding parent for gridId %" PRId64 "\n", childGrid->gridId64);
    HALO_TRACE_FUNCTION(2, "selfQMDdptr %" PRIx64 "\n", selfQMDdptr);

    /************************************************/
    /*  Find out the parentGridId                   */
    /************************************************/

    /* Get offset of parent CNPparentCtx */
    cnpParentCtxDptr = selfQMDdptr + offsetof(CNPqmdLaunch, graphNode) +
                       offsetof(CNPgraphNode, parent);

    HALO_TRACE_FUNCTION(5, "cnpParentCtxDptr: %" PRIx64 "\n", cnpParentCtxDptr);

    /* Figure out where this grid was launched from (host/device) */
    res = dev->halo.readGenericMemory(context,
                                      0, 0, 0,
                                      cnpParentCtxDptr,
                                      &cnpParentCtx,
                                      sizeof(cnpParentCtx));
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read CNPparenCtx at address %" PRIx64 "\n",
                   cnpParentCtxDptr);
        return CUDBG_SUCCESS;
    }

    if (cnpParentCtx.type == PARENT_CPU) {
        HALO_TRACE_FUNCTION(2, "Cannot collect parent info for host launched grid!\n");
        return CUDBG_ERROR_INVALID_GRID;
    }

    HALO_TRACE_FUNCTION(5, "parent addr: %" PRIx64 "\n", cnpParentCtx.addr);

    /* Get the ptr to the CNPqmdLaunch structure of this grid's parent */
    /* Get the parent's selfQMDdptr */
    selfQMDdptrOffset = cnpParentCtx.addr + offsetof(CNPctaCtx, gridOrigin);
    res = dev->halo.readGenericMemory(context,
                                      0, 0, 0,
                                      selfQMDdptrOffset,
                                      &selfQMDdptr,
                                      sizeof(selfQMDdptr));
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read CNPqmdLaunch at address %" PRIx64 "\n",
                   selfQMDdptrOffset);
        return res;
    }

    HALO_TRACE_FUNCTION(5, "parent's selfQMDdptr: %" PRIx64 "\n", selfQMDdptr);

    /* We now have the parent's selfQMDdptr, we can use that to get info
       about the parent grid. */

    /* Get the dptr to the parameter constbank (constbank 0)*/
    paramConstDptrOffset = selfQMDdptr + offsetof(CNPqmdLaunch, paramConstDptr);
    res = dev->halo.readGenericMemory(context,
                                      0, 0, 0,
                                      paramConstDptrOffset,
                                      &paramConstDptr,
                                      sizeof(paramConstDptr));
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read paramConstDptr at address %" PRIx64 " from QMDLaunch\n",
                   paramConstDptrOffset);
        return res;
    }

    HALO_TRACE_FUNCTION(2 , "paramConstDptr: %" PRIx64 "\n", paramConstDptr);

    /* Read the parentGridId */
    res = dev->halo.getGridParamsOffsetGridId(dev, &gridIdOffset);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to get gridId offset in GridParams\n");
        return res;
    }

    gridIdOffset += paramConstDptr;
    res = dev->halo.readGenericMemory(context,
                                      0, 0, 0,
                                      gridIdOffset,
                                      &parentGridId64,
                                      sizeof(parentGridId64));
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read parentGridId at address %" PRIx64 " from constbank 0\n",
                   gridIdOffset);
        return res;
    }
    childGrid->parentGridId64 = parentGridId64;

    HALO_TRACE_FUNCTION(2, "parentGridId64: %" PRId64 "\n", (int64_t)parentGridId64);

    *parentGrid = haloStateDeviceGetGrid(dev, parentGridId64);

    /* If the grid is already present, this info would have been collected. */
    if (*parentGrid) {
        HALO_TRACE_FUNCTION(2, "Info for parentGridId %" PRId64 " already collected, finishing\n", parentGridId64);
        return CUDBG_SUCCESS;
    }

    /************************************************/
    /*  Get the remaining info for the parent grid  */
    /************************************************/

    /* If we still don't have a grid, it must be the first time we saw this
       parentGridId. Construct a grid for it and collect info. */
    if (!*parentGrid) {
        /* Get the block dimensions */
        res = dev->halo.getGridParamsOffsetBlockDim(dev, &blockDimOffset, &size);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to get blockDim offset in GridParams\n");
            return res;
        }

        blockDimOffset += paramConstDptr;
        res = dev->halo.readGenericMemory(context,
                                          0, 0, 0,
                                          blockDimOffset,
                                          &blockDimPacked,
                                          sizeof(blockDimPacked));
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to read grid dimensions from constbank 0\n");
            return res;
        }

        blockDim.x = blockDimPacked[0] & 0xFFFF;
        blockDim.y = blockDimPacked[1] & 0xFFFF;
        blockDim.z = blockDimPacked[2] & 0xFFFF;

        /* Get the grid dimensions */
        res = dev->halo.getGridParamsOffsetGridDim(dev, &gridDimOffset, &size);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to get gridDim offset in GridParams\n");
            return res;
        }

        gridDimOffset += paramConstDptr;
        res = dev->halo.readGenericMemory(context,
                                          0, 0, 0,
                                          gridDimOffset,
                                          &gridDimPacked,
                                          sizeof(gridDimPacked));
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to read grid dimensions from constbank 0\n");
            return res;
        }

        gridDim.x = (gridDimPacked[0] & (uint32_t)0xFFFFFFFF);
        gridDim.y = (gridDimPacked[1] & 0xFFFF);
        gridDim.z = (gridDimPacked[2] & 0xFFFF);

        /* To get the function, first get startPC from within the constbank */
        res = dev->halo.getGridParamsOffsetStartPc(dev, &startPcOffset);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to get gridDim offset in GridParams\n");
            return res;
        }

        startPcOffset += paramConstDptr;
        res = dev->halo.readGenericMemory(context,
                                          0, 0, 0,
                                          startPcOffset,
                                          &startPc,
                                          sizeof(startPc));
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to read startPc at address %" PRIx64 " from constbank 0\n",
                       startPcOffset);
            return res;
        }

        HALO_TRACE_FUNCTION(5, "startPc: 0x%x\n", startPc);

        /* Now get the function corresponding to this startPc */
        function = (DeviceFunction)toolsRangeMapLookupByAddr(context->gpuAddrToFunction, (uint64_t)startPc);
        if (!function) {
            HALO_ERROR("Could not find a DeviceFunction for startPc %" PRIx64 "\n", (uint64_t)startPc);
            res = CUDBG_ERROR_UNKNOWN_FUNCTION;
            return res;
        }

        HALO_TRACE_FUNCTION(2, "function: %s\n", function->name);
        HALO_TRACE_FUNCTION(2, "gridDim: (%d,%d,%d)\n", gridDim.x, gridDim.y, gridDim.z);
        HALO_TRACE_FUNCTION(2, "blockDim: (%d,%d,%d)\n", blockDim.x, blockDim.y, blockDim.z);

        /* Create a grid for this ID and add it to internal tracking structures. */
        res = haloStateCreateGrid(parentGrid, function, parentGridId64);
        if (res != CUDBG_SUCCESS)
            return res;

        /* Fill in the remaining info */
        (*parentGrid)->gridDim = gridDim;
        (*parentGrid)->blockDim = blockDim;
        (*parentGrid)->state = HALO_GRID_STATE_INVISIBLE;
        (*parentGrid)->selfQMDdptr = selfQMDdptr;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_patchTextureInstruction(CudbgDevice dev, uint32_t texId, uint32_t dim,
                                     uint32_t *coords, Grid grid)
{
    CUDBGResult res;
    Context ctx;
    uint64_t pc, inst;
    uint64_t constBankOffset;

    CUDBG_VERIFY(coords, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in patchTextureInstruction.\n");

    CUDBG_VERIFY(dev->activeContext, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context in patchTextureInstruction.\n");

    ctx = dev->activeContext;
    pc = (ctx->thCodeVA + ctx->thRdTexMemOffset) - ctx->funcMemBaseVA;

    res = dev->halo.findConstBankOffset(dev, grid->function, texId, &constBankOffset);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to find the contbank offset for texId %d (res=%d)\n", texId, res);
        return res;
    }

    res = dev->halo.readCodeMemory(ctx, pc, &inst, sizeof inst);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read code memory at offset 0x%08x (res=%d)\n", pc, res);
        return res;
    }

    inst = (inst & ~BF_FLDV(GK110SASS_TEX_PTRIDX, 0x1FFFu)) |
           BF_FLDV(GK110SASS_TEX_PTRIDX, (constBankOffset >> 2));
    inst = (inst & ~BF_FLDV(GK110SASS_TEX_DIM, 0x3u)) | BF_FLDV(GK110SASS_TEX_DIM, dim - 1);

    res = dev->halo.writeCodeMemory(ctx, pc, &inst, sizeof inst);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to write code memory at offset 0x%08x (res=%d)\n", pc, res);
        return res;
    }

    res = dev->halo.invalidateICache(dev);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to invalidate icache (res=%d)\n", res);
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_getLmemOffsetForTexCoords(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                       uint32_t *offset)
{
    CUDBG_VERIFY(offset, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in getLmemOffsetForTexCoords.\n");

    /* Since all the ABI locations are used as negative offsets from lmem hi,
       the highest numerical value is the lowest mem location.
       This is also where COORDS_* start */
    *offset = KEPLER_GK11X_LMEM_ABI_HI(vsm, wp) - KEPLER_GK11X_LMEM_ABI_TEXTURE_COORDS_0;

    return CUDBG_SUCCESS;
}

typedef struct forceTerminationData_st forceTerminationData;

struct forceTerminationData_st {
    uint64_t thStartOffset;
    uint64_t thEndOffset;
    Context context;
};

static CUDBGResult
forceTerminationFunctor(haloMemoryMap *map,
                        haloMemorySegment *seg,
                        void *data)
{
    forceTerminationData *d = (forceTerminationData *)data;
    const uint64_t exit_inst = 0x18000000001c003cULL;
    const uint64_t rtt_inst =  0x1b00000000000000ULL;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(map && seg && d, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args\n");

    if (seg->type != HALO_MEM_SEG_FUNC)
        return CUDBG_SUCCESS;

    /* Fill everything with exit_inst */
    res = d->context->dev->halo.fillRangeWithInstruction(d->context,
                                                         seg->devvaddr,
                                                         (seg->devvaddr + seg->size),
                                                         exit_inst);
    if (res != CUDBG_SUCCESS)
        return res;

    if (seg->devvaddr <= d->thStartOffset && seg->devvaddr + seg->size > d->thStartOffset) {
        /* Verify the trap handler doesn't span multiple segments */
        CUDBG_VERIFY(d->thEndOffset <= seg->devvaddr + seg->size,
                     CUDBG_ERROR_INTERNAL,
                     "Trap handler spans multiple segments!\n");
        /* Fill trap handler with rtt instructions */
        res = d->context->dev->halo.fillRangeWithInstruction(d->context,
                                                             d->thStartOffset,
                                                             d->thEndOffset,
                                                             rtt_inst);
    }

    return res;
}

static CUDBGResult
kepler_gk11x_forceTermination(CudbgDevice dev)
{
    CUDBGResult res;
    forceTerminationData data = {0};

    /* If there is no active context or if we never launched any
       kernel for that context, there is nothing to do. */
    if (!dev->activeContext || !haloStateContextIsActive(dev->activeContext))
        return CUDBG_SUCCESS;

    /* TH Code Segment Start/End Offsets */
    data.thStartOffset = dev->activeContext->thCodeVA;
    data.thEndOffset   = data.thStartOffset + dev->activeContext->thCodeSize;
    data.context       = dev->activeContext;

    res = haloMemoryMapApplyFunctor(dev->activeContext->memMap,
                                    forceTerminationFunctor,
                                    &data);

    return res;
}

static inline CUDBGResult
kepler_gk11x_forceScratchpadLmemBase(CudbgDevice dev, bool *useScratchpad)
{
    /* Starting with sm_35, we have GETLMEMBASE, allowing us ot save the
       lmembase devva to the scratchpad.  Force this by default. */
    *useScratchpad = true;
    return CUDBG_SUCCESS;
}

/* Kepler GK11x LMEM and CRS functions below */
static inline uint32_t
commonLocalAndCRS(CudbgDevice dev, uint32_t vsm, uint32_t tid, uint32_t warp_addr)
{
    uint32_t warpLmemBaseOffset = 0;

    /* Kepler GK110:  HALO_MEM_SEG_LOCAL_NONDEFAULT indicates that this warp
       has issued SETLMEMBASE from the SM.  This means we cannot use the
       default lmem backing store to compute this warp's offset. */
    if (dev->smState[vsm].warp[tid].lmemSegType == HALO_MEM_SEG_LOCAL_NONDEFAULT) {
        warpLmemBaseOffset = (uint32_t)(dev->smState[vsm].warp[tid].lmemBase -
                                        dev->smState[vsm].warp[tid].lmemSeg->devvaddr);
    }
    else {
        /* Bugs 777914 and 777917:  Need to divide the lmemSizePerSM as hardware reports
           it in NV_PGRAPH_PRI_CWD_LMEM_SIZE_PER_SM by the number of warps per SM (on
           GK10x this is 64).  Adding up each individual lmem component is not sufficient
           since HW aligns this size to meet its own requirements. */
        uint32_t warpLmemSize = (uint32_t)dev->activeContext->lmemSizePerSM / dev->halo.deviceInfo.numWarpsPrSM;
        warpLmemBaseOffset = vsm * (uint32_t)dev->activeContext->lmemSizePerSM + tid * warpLmemSize;
    }

    return warpLmemBaseOffset + warp_addr;
}

static CUDBGResult
kepler_gk11x_getLmemInternalOffset(CudbgDevice dev, uint32_t address,
                                   uint32_t vsm, uint32_t tid, uint32_t lane,
                                   uint32_t *offset)
{
    uint32_t warp_addr;
    HaloLmemConfig_t *warpLmem = &dev->smState[vsm].warp[tid].lmemConfig;

    CUDBG_VERIFY(offset, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in getLmemInternalOffset.\n");

    /* Detect an access to local high */
    if (address > warpLmem->windowSize / 2)
        address -= warpLmem->windowSize;

    warp_addr = ((address & 0xfffffffc) << 5) + (lane << 2) + (address & 0x3);
    warp_addr += warpLmem->hiSize + warpLmem->CRSSize;

    *offset = commonLocalAndCRS(dev, vsm, tid, warp_addr);
    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_getCRSInternalOffset(CudbgDevice dev, uint32_t vsm, uint32_t tid,
                                  uint32_t warp_addr, uint32_t *offset)
{
    CUDBG_VERIFY(offset, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in getCRSInternalOffset.\n");

    *offset = commonLocalAndCRS(dev, vsm, tid, warp_addr);
    return CUDBG_SUCCESS;
}

/* Note, this doesn't touch the device suspended property, so use with care. */
CUDBGResult
kepler_gk11x_resumeTPC(CudbgDevice dev, uint32_t vsm)
{
    uint32_t regVal;
    uint32_t regOffset = 0;
    CUDBGResult res = CUDBG_SUCCESS;

    if (haloStateContextIsActive(dev->activeContext))
        dev->halo.contextCommonDataCacheOp(dev->activeContext, HALO_MEM_SEG_CACHE_INVALIDATE);

    res = dev->halo.getPRIOffset(dev, HALO_PRI_SM_DBGR_CONTROL0, vsm,
                                 &regOffset);
    if (res != CUDBG_SUCCESS)
        return res;

    res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                     (char *)(uintptr_t)regOffset, &regVal);
    if (res != CUDBG_SUCCESS)
        return res;

    /* The following requires some clarification.  Despite the fact
     * that both RUN_TRIGGER and STOP_TRIGGER have the word "TRIGGER"
     * in their names, only one is actually a trigger, and that is
     * the STOP_TRIGGER.  Only writing a 1 to the RUN_TRIGGER is not
     * sufficient to resume the gpu - the stop trigger must explicitly
     * be set to 0 as well. */

    /* RESUMING:  Advice from the arch group:  Set the stop trigger
     * first as a separate operation to ensure that the trigger has
     * taken effect before setting the "run trigger." */

    /* Set the stop trigger to 0 */
    regVal = SETFIELD32(regVal, NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_CONTROL0_STOP_TRIGGER, 0);
    res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                      (char *)(uintptr_t)regOffset, &regVal);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Now, set the run trigger to 1 */
    regVal = SETFIELD32(regVal, NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_CONTROL0_RUN_TRIGGER, 1);

    /* Do the final write to CONTROL0 */
    return dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                       (char *)(uintptr_t)regOffset, &regVal);
}

static CUDBGResult
kepler_gk11x_resumeSM(CudbgDevice dev, uint32_t vsm)
{
    CUDBGResult res = CUDBG_SUCCESS, res2 = CUDBG_SUCCESS;

    if (dev->codeIsDirty)
        dev->halo.invalidateICache(dev);
    dev->codeIsDirty = 0;

    res = dev->halo.writePauseServicedMask(dev, false, vsm);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to write pause serviced mask (res=%d)\n", res);
        return res;
    }

    dev->halo.clearExceptions(dev, vsm);

    /* Setup the WAR for HW Bug 1239649 (hold the warps after they wakeup from pause) */
    res = dev->halo.startRunTriggerWar(dev);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Setting up run trigger war failed in resumeSM (res=%d).\n", res);
        return res;
    }

    /* Ensure all CPU stores are visible to GPU at this point */
    cuosStoreFence();

    /* Resume this TPC.  If there is a failure here, then preserve the return code
       and allow subsequent routines to happen. */
    res = kepler_gk11x_resumeTPC(dev, vsm);

    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to fermi_resumeTPC failed in resumeSM.\n");
    }

    /* Finish the WAR for HW Bug 1239649 (let the warps resume) */
    res2 = dev->halo.finishRunTriggerWar(dev, vsm);
    if (res2 != CUDBG_SUCCESS) {
        HALO_ERROR("Finalizing run trigger war failed in resumeSM (res=%d).\n", res);
        /* Only return this error if there wasn't a previous one */
        if (res == CUDBG_SUCCESS)
            res = res2;
    }

    res2 = haloSetRmDebugMode(dev, false);
    if (res2 != CUDBG_SUCCESS) {
        HALO_TRACE(20, "Call to haloSetRmDebugMode failed in resumeSM.\n");
        /* Only return this error if there wasn't a previous one */
        if (res == CUDBG_SUCCESS)
            res = res2;
    }

    return res;
}

CUDBGResult
kepler_gk11x_resumeDevice(CudbgDevice dev, uint32_t *hasResumed, uint32_t skipResume)
{
    CUDBGResult res = CUDBG_SUCCESS, res2 = CUDBG_SUCCESS;

    *hasResumed = 0;

    if (dev->codeIsDirty)
        dev->halo.invalidateICache(dev);
    dev->codeIsDirty = 0;

    /* If we preempted work on this device due to a device event,
       then restore the work now.  We only need to reenable the
       channels in this situation we can return early once
       that has completed. */
    if (dev->preemptState == CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_CTA_PREEMPTED_BY_CONTROLLER ||
        dev->preemptState == CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_ILP_PREEMPTED_BY_CONTROLLER ||
        dev->preemptState == CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_PREEMPTED_FOR_DEVICE_EVENT  ||
        dev->preemptState == CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_CTA_PREEMPTED) {
        HALO_TRACE_FUNCTION(1, "Device is in CTA preempted state.  Initiating restore...\n");
        res = dev->halo.initiatePreemptionRestore(dev, &dev->preemptState);
        if (res != CUDBG_SUCCESS)
            return res;

        *hasResumed = 1;
        return res;
    }

    res = dev->halo.writePauseServicedMask(dev, true, 0);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to write pause serviced mask (res=%d)\n", res);
        return res;
    }

    dev->halo.clearExceptions(dev, -1);

    /* Setup the WAR for HW Bug 1239649 (hold the warps after they wakeup from pause) */
    res = dev->halo.startRunTriggerWar(dev);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Setting up run trigger war failed in resumeDevice (res=%d).\n", res);
        return res;
    }

    /* Ensure all CPU stores are visible to GPU at this point */
    cuosStoreFence();

    /* If possible, do the resume through the debug object.  If any
       of these calls fail, preserve the return code and allow
       subsequent routines to happen (ensure that RM debug mode is
       disabled). */
    if (!skipResume) {
        if (dev->dmal->debugObjectCanResume())
            res = dev->dmal->debugObjectResumeDevice(dev, hasResumed);
        else
            res = dev->halo.resumeDeviceViaPRIV(dev, hasResumed);
    }

    /* Finish the WAR for HW Bug 1239649 (let the warps resume) */
    res2 = dev->halo.finishRunTriggerWar(dev, -1);
    if (res2 != CUDBG_SUCCESS) {
        HALO_ERROR("Finalizing run trigger war failed in resumeDevice (res=%d).\n", res2);
        /* Only return this error if there wasn't a previous one */
        if (res == CUDBG_SUCCESS)
            res = res2;
    }

    *hasResumed = 1;

    /* If we're resuming the device because we're ILP preempting,
       then we need to hang onto the device as a shared resource
       until the entire preemption process has completed.  There
       are a couple of ways to accomplish this, but we'll do it
       here by hanging onto RM Debug Mode (return early).  We
       need to do this so that we can properly release all shared
       resources (memory mappings in particular) that the debugger
       is holding onto prior to fully preempt saving the context.
       See the call to releaseSharedResources() in the controller. */
    if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_KILP &&
        dev->preemptState == CUDBG_PREEMPTION_STATE_ILP_PENDING) {
        HALO_TRACE(20, "Device is preempting; holding RM Debug Mode\n");
        return res;
    }

    if (dev->halo.deviceInfo.preemptionType != HALO_PREEMPTION_TYPE_CILP) {
        res2 = haloSetRmDebugMode(dev, false);
        if (res2 != CUDBG_SUCCESS) {
            HALO_TRACE(20, "Call to haloSetRmDebugMode failed in resumeDevice.\n");
            /* Only return this error if there wasn't a previous one */
            if (res == CUDBG_SUCCESS)
                res = res2;
        }
    }

    return res;
}

static CUDBGResult
kepler_gk11x_readLaneServiceReason(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                   uint32_t ln, uint32_t *serviceReason)
{
    /* thService is running on the GPU as this is called, where writes to the
       service reason could be cached and missed by the CPU.  Ensure cache
       coherency via readServiceRoutineData */
    return dev->dmal->readServiceRoutineData(dev, vsm, wp, ln,
                                     KEPLER_GK11X_LMEM_ABI_HI(vsm, wp) -
                                     KEPLER_GK11X_LMEM_ABI_TH_SERVICE_REASON,
                                     serviceReason,
                                     sizeof(*serviceReason));
}

static CUDBGResult
kepler_gk11x_thServiceWriteInfo(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                uint32_t addr, uint32_t sz, HaloThService_t reason)
{
    uint32_t validLanes = dev->smState[vsm].warp[wp].validLanes;
    uint32_t vOffset, lane, numValidLanes = 0;
    Context context = dev->activeContext;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY((context && context->memMapActive), CUDBG_ERROR_INVALID_CONTEXT, "Invalid context.\n");

    /* Find out the number of valid lanes - this is calculated here, since
       the trap handler has no simple way of knowing this without doing so.
       Valid lanes in the mask are contiguous from right to left. */
    for (lane = 0; lane < 32; lane++) {
        if (validLanes & (1U << lane))
            numValidLanes++;
    }

    /* Iterate over all validLanes, and write service info to each lane's LMEM_HI */
    for (lane = 0; lane < numValidLanes; ++lane) {

        vOffset = KEPLER_GK11X_LMEM_ABI_HI(vsm, wp) - KEPLER_GK11X_LMEM_ABI_TH_SERVICE_REASON;
        res = dev->halo.writeLocalMemory(dev, vsm, wp, lane, vOffset, &reason, sizeof reason);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to write lmem th service reason in thServiceWriteInfo.\n");
            return res;
        }

        vOffset = KEPLER_GK11X_LMEM_ABI_HI(vsm, wp) - KEPLER_GK11X_LMEM_ABI_TH_SERVICE_NUM_LANES;
        res = dev->halo.writeLocalMemory(dev, vsm, wp, lane, vOffset, &numValidLanes, sizeof numValidLanes);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to write lmem th service num lanes in thServiceWriteInfo.\n");
            return res;
        }

        vOffset = KEPLER_GK11X_LMEM_ABI_HI(vsm, wp) - KEPLER_GK11X_LMEM_ABI_TH_SERVICE_ADDR;
        res = dev->halo.writeLocalMemory(dev, vsm, wp, lane, vOffset, &addr, sizeof addr);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to write lmem th service addr in thServiceWriteInfo.\n");
            return res;
        }

        vOffset = KEPLER_GK11X_LMEM_ABI_HI(vsm, wp) - KEPLER_GK11X_LMEM_ABI_TH_SERVICE_SIZE;
        res = dev->halo.writeLocalMemory(dev, vsm, wp, lane, vOffset, &sz, sizeof sz);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to write lmem th service sz in thServiceWriteInfo.\n");
            return res;
        }
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_checkWarpHiding(CudbgDevice dev, uint32_t vsm, uint32_t wp, bool *warpInGlobalSyscall)
{
    CUDBGResult res = CUDBG_SUCCESS;
    Grid grid = NULL;
    CudbgWarp_t *warp = &dev->smState[vsm].warp[wp];
    bool isReservedGridId = false;
    uint32_t activeMask, validMask, laneMask, visitMask, ln;
    uint32_t firstActiveLane, divergentLanes;
    uint32_t syscallLanes;
    bool found = false, inPatch = false;
    uint64_t physPC;
    uint32_t laneMaskWarpExceptions = 0;
    uint32_t laneMaskLaneExceptions = 0;
    uint32_t hiddenLanesMaskWarpExceptions = 0;
    uint32_t hiddenLanesMaskLaneExceptions = 0;
    HaloExceptionPrecision precision;
    DebugPatch patch;

    /* Reset the initial state */
    *warpInGlobalSyscall = false;

    /* Pull the grid */
    grid = haloStateDeviceGetGrid(dev, warp->gridId64);
    if (!grid)
        return CUDBG_ERROR_INVALID_GRID;

    /* There are four cases where a warp must be hidden. In each of
       these cases, the lowest frame in the CRS is a global syscall.
        Case 1 : Scheduler kernel
                 Warps belonging to a scheduler kernel
                 must always be hidden in release builds
                 Warps inside the scheduler kernel may have
                 arbitrary divergence.

                 Such warps can be quickly identified by looking at the
                 grid ID, though, they will also match the criteria for
                 Case 2 below.

        Case 2 : Restore Syscall
                 Warps belonging to the restore syscall share the same
                 gridID as the original user kernel. However, these warps
                 should not be displayed until they reenter user code.
                 The restore syscall code does contain arbitrary divergence
                 and at the time of stopping, the top of CRS stack PC may
                 be inside a device syscall frame.

                 All warps in such a case will have a CRS indicating
                 the outermost frame is a global syscall and any
                 subsequent frames as device syscalls.

        Case 3 : Grid promotion (At entry code)
                 The entry code is non-divergent. It does push a PRET (which
                 pushes a user frame) and then does a JMP to start executing
                 user code).

                 All warps have a global syscall frame, followed by a global
                 user kernel frame (and potentially other user frames).

        Case 4 : Grid demotion (At exit code)
                 In the exit code, warps reconverge at the exit point, but
                 very quickly re diverge. This means that the call stack
                 will contain a global syscall that then calls into another
                 global syscall followed by device syscall frames.


        Hiding Rules:
        A warp will be marked invalid if any of the following conditions are met:
            1. Warp belongs to a grid with a reserved grid ID (scheduler kernel).
                This handles Case 1
            2. If any lane in the warp has no user entry PC to be found.
                This handles Cases 2 - 4. The problem of arbitrary divergence is handled
                by looking at all the lanes. For each lane, the user entry PC code will
                disregard all device syscall frames called from a global syscall frame at
                the start of the call stack. As a result, if the code has entered
                user code, the user entry frame will be found. If the code is
                inside a device syscall frame, it will fail.
                Lanes that match this check will be hidden unless:
                2.1 Hidden lane has a lane exception
                2.2 Hidden lanes have warp exceptions and the visible lanes do  not have any
                    any exceptions.
    */

    /* Check 1 : Warp belongs to a reserved grid */
    res = dev->halo.isReservedGridId(dev, grid->gridId64, &isReservedGridId);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to check if grid is reserved\n");
        return res;
    }

    if (isReservedGridId) {
        *warpInGlobalSyscall = true;
        HALO_TRACE_FUNCTION(10, "Found sm%d/wp%d in sched kernel\n", vsm, wp);
        return CUDBG_SUCCESS;
    }

    /* Check 2 : Any lane has a purely syscall stack
                 Need to visit at least one active lane and all divergent lanes */
    validMask   = dev->smState[vsm].warp[wp].validLanes;
    activeMask  = dev->smState[vsm].warp[wp].activeMask;
    divergentLanes = ~activeMask & validMask;
    firstActiveLane = (~activeMask + 1) & activeMask;
    visitMask = divergentLanes | firstActiveLane;
    syscallLanes = 0;

    for (ln = 0, laneMask = 1; ln < dev->halo.deviceInfo.numLanesPrWarp; ++ln, laneMask <<=  1) {

        /* Skip lanes that are not in the visit mask */
        if (!(visitMask & laneMask))
            continue;

        if (dev->smState[vsm].warp[wp].activeMask & (1U << ln))
            res = dev->halo.readPC(dev, vsm, wp, &physPC);
        else
            res =  dev->halo.findDivergedCRS_PC(dev, vsm, wp, ln, &physPC);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "vsm%d/wp%d/ln%d - Failed to get physPC\n", vsm, wp, ln);

        res = haloInPatchRegion(physPC, dev->activeContext, &patch,
                                CUDBG_PATCH_SYSCALL | CUDBG_PATCH_GLOBAL_SYSCALL | CUDBG_PATCH_MEMCHECK,
                                &inPatch, false);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "vsm%d/wp%d/ln%d - Failed to check if in patch that should be hidden, pc=%#" PRIx64 "\n", vsm, wp, ln, physPC);
        /* Skip lanes that are not currently in syscalls at all */
        if (!inPatch) {
            HALO_TRACE_FUNCTION(49, "vsm%d/wp%d/ln%d not in syscall at pc %#" PRIx64 ", want to skip...\n", vsm, wp, ln, physPC);
            continue;
        }

        res = dev->halo.readUserEntryFramePC(dev, vsm, wp, ln, &found, &physPC);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read User Entry Frame PC\n");

        if (!found) {
            HALO_TRACE_FUNCTION(10, "sm%d/wp%d/ln%d no user entry frame found\n",
                                vsm, wp, ln);
            syscallLanes |= laneMask;
            if (firstActiveLane & laneMask)
                syscallLanes |= activeMask;
        }
    }

    if ((validMask & syscallLanes) == validMask) {
        HALO_TRACE_FUNCTION(10, "sm%d/wp%d All lanes in active mask (0x%x) found in global syscalls\n",
                            vsm, wp, validMask);
        *warpInGlobalSyscall = true;
        return CUDBG_SUCCESS;
    }
    else if (syscallLanes) {
        uint32_t newActiveMask = 0;
        uint32_t newValidMask = 0;

        newValidMask = validMask & (~syscallLanes);

        /* This loop is for a last sanity check */
        laneMaskWarpExceptions = 0;
        laneMaskLaneExceptions = 0;
        hiddenLanesMaskWarpExceptions = 0;
        hiddenLanesMaskLaneExceptions = 0;
        for (ln = 0, laneMask = 1; ln < dev->halo.deviceInfo.numLanesPrWarp; ++ln, laneMask <<=  1) {
            precision = haloExceptionGetPrecision(dev->smState[vsm].warp[wp].laneExceptions[ln]);

            /* For all lanes, setup a mask of warp exception lanes */
            if (precision == HALO_EXCEPTION_PRECISION_WARP) {
                if (laneMask & syscallLanes)
                    hiddenLanesMaskWarpExceptions |= laneMask;
                else
                    laneMaskWarpExceptions |= laneMask;
            }
            else if (precision == HALO_EXCEPTION_PRECISION_LANE) {
                if (laneMask & syscallLanes)
                    hiddenLanesMaskLaneExceptions |= laneMask;
                else
                    laneMaskLaneExceptions |= laneMask;
            }
        }

        /* Sanity checks */
        /* If there were any hidden lanes that had lane level exceptions, unhide them  */
        if (hiddenLanesMaskLaneExceptions) {
            HALO_TRACE_FUNCTION(10,"sm%d/wp%d Warp hiding : Force showing lanes with lane level exceptions : 0x%x\n",
                                vsm, wp, hiddenLanesMaskLaneExceptions);
            newValidMask |= hiddenLanesMaskLaneExceptions;
        }

        /* If there were warp level exceptions in the hidden lanes, and none in the exposed lanes, unhide
           all such lanes.
        */
        if (hiddenLanesMaskWarpExceptions && !laneMaskWarpExceptions) {
            HALO_TRACE_FUNCTION(10, "sm%d/wp%d Warp hiding : Force showing lanes with warp level exceptions : 0x%x\n",
                                vsm, wp, hiddenLanesMaskWarpExceptions);
            newValidMask |= hiddenLanesMaskWarpExceptions;
        }

        /* Finally, update the active mask */
        newActiveMask = activeMask & newValidMask;

        HALO_TRACE_FUNCTION(10, "sm%d/wp%d Warp is partially inside syscalls. ValidMask will update (0x%x -> 0x%x)\n"
                            " ActiveMask will update (0x%x -> 0x%x)\n",
                            vsm, wp, validMask, newValidMask, activeMask, newActiveMask);

#ifndef RELEASE
        if (cudbgEnableInternalDebugging) {
            HALO_TRACE_FUNCTION(10, "sm%d/wp%d Warp is partially inside syscall with patch debugging. ValidMask will NOT update (0x%x -> 0x%x)\n"
                                " ActiveMask will NOT update (0x%x -> 0x%x)\n",
                                vsm, wp, validMask, newValidMask, activeMask, newActiveMask);
            return CUDBG_SUCCESS;
        }
#endif
        if (!dev->haloClient->state.hideWarpsInGlobalSyscalls) {
            HALO_TRACE_FUNCTION(10, "sm%d/wp%d Warp is partially inside syscall, but client requested no hiding. ValidMask will NOT update (0x%x -> 0x%x)\n"
                                " ActiveMask will NOT update (0x%x -> 0x%x)\n",
                                vsm, wp, validMask, newValidMask, activeMask, newActiveMask);
            return CUDBG_SUCCESS;
        }

        dev->smState[vsm].warp[wp].validLanes = newValidMask;
        dev->smState[vsm].warp[wp].activeMask = newActiveMask;

        return CUDBG_SUCCESS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_setWarpStateValid(CudbgDevice dev, uint32_t vsm, uint32_t wp)
{
    CUDBGResult res = CUDBG_SUCCESS;
    bool warpIsHidden = false;
    Grid grid = NULL;
    CudbgWarp_t *warp = &dev->smState[vsm].warp[wp];

    /* Pull the grid */
    grid = haloStateDeviceGetGrid(dev, warp->gridId64);
    if (!grid)
        return CUDBG_ERROR_INVALID_GRID;

    /* Detect if the given warp should be hidden */
    res = kepler_gk11x_checkWarpHiding(dev, vsm, wp, &warpIsHidden);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to check for warp hiding\n");
        return res;
    }

    /* Default the warp to valid */
    warp->valid = true;

    /* If the grid has not been posted or if the warp was found in a global syscal
       hide it.
    */
    if ((grid->state == HALO_GRID_STATE_INVISIBLE) || warpIsHidden) {
        /* If this warp's grid hasn't been posted yet (see below), then
           clear out any visibility into this warp.
           CNP introduces syscalls that are actually __global__ kernels
           (entrypoints).  For example, if we are single-stepping the
           device and new work is created, it will show up in the
           __atentry code, which is technically an internal driver
           syscall.  We hide these operations until a real user function
           is called. */
#ifndef RELEASE
        if (warpIsHidden && cudbgEnableInternalDebugging) {
            HALO_TRACE(10, "Not hiding vsm%d/wp%d (gridId=%" PRId64 ", state=%d, isHidden=%d)"
                       " due to patch debugging\n",
                       vsm, wp, warp->gridId64, grid->state, warpIsHidden);
            return CUDBG_SUCCESS;
        }
#endif

        /* In the case where the warp is hidden, but the client did not request
           warps in global syscalls to be hidden, stop hiding it.
        */
        if (!dev->haloClient->state.hideWarpsInGlobalSyscalls) {
            HALO_TRACE(10, "Not hiding vsm%d/wp%d (gridId=%" PRId64 ", state=%d, isHidden=%d)"
                       " due to client state\n",
                       vsm, wp, warp->gridId64, grid->state, warpIsHidden);
            return CUDBG_SUCCESS;
        }

        HALO_TRACE(10, "Hiding vsm%d/wp%d (gridId=%" PRId64 ", state=%d, isHidden=%d)\n",
                   vsm, wp, warp->gridId64, grid->state, warpIsHidden);
        dev->halo.clearWarpState(dev, vsm, wp);
        warp->valid = false;
    }

    /* If preemption is enabled, check for eligibility.
       If a warp is not enabled for preemption, then this is a warp
       that needs to be hidden (regardless of internal/release mode) */
    if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_KILP && warp->valid) {
        bool warpEnabledForPreempt = true;
        res = dev->halo.isWarpEnabledForPreempt(dev, vsm, wp, &warpEnabledForPreempt);
        if (res != CUDBG_SUCCESS)
            return res;

        if (!warpEnabledForPreempt) {
            HALO_TRACE(10, "Hiding vsm%d/wp%d (not enabled for preemption -- unwanted)\n",
                       vsm, wp);
            dev->halo.clearWarpState(dev, vsm, wp);
            warp->valid = false;
        }
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_getBrokenWarps(struct Halo_st *halo, HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm,
                            const CUwarpBitmask *validMask, const CUwarpBitmask *bpTrapMask, CUwarpBitmask *brokenwarps)
{
    CUDBGResult res;
    CUwarpBitmask breakpointMask = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;
    uint32_t wp = 0, warpEsr = 0, trapImmediate = 0;

    CUDBG_VERIFY(halo && scratchpadAccessor && validMask && bpTrapMask && brokenwarps, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments to getBrokenWarps.\n");

    /* On GK110, we can't assume the BPT_TRAP_MASK indicates which
       warps are at a breakpoint, since it is overloaded and will
       show high bits when warps execute BPT.TRAP with other
       immediate fields.  Specifically with Bug 971389, CNP traps
       will do this, which can result in the debugger attempting to
       single-step 1 warp when multiple warps need to do a continuation,
       which can result in a hang at a BAR.SYNCALL.  So, we must read
       the trap immediates out of the warp scratchpad to populate the
       brokenwarps mask. */

    /* Initialize the mask to 0 */
    warpBitmaskClear(brokenwarps);

    /* Iterate over each warp's ESR, looking for the trap immediate bits */
    for (wp = 0; wp < halo->deviceInfo.numWarpsPrSM; ++wp) {
        /* Skip invalid warps */
        if (!warpBitmaskGetBits(validMask, wp, 1))
            continue;
        res = halo->scratchpad.read_warpErrorStatus(scratchpadAccessor, vsm, wp, &warpEsr);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read warp error status\n");
        trapImmediate = GETFIELD32(warpEsr, KEPLER_TRAP_IMMEDIATE_FIELD);
        if (trapImmediate == KEPLER_GK11X_TRAP_IMMEDIATE_BREAKPOINT)
            warpBitmaskSetBits(&breakpointMask, wp, 1, 1);
    }

    warpBitmaskAssign(brokenwarps, &breakpointMask);
    return CUDBG_SUCCESS;
}

/* On GK110, CNP traps should not be single-stepped over on a per-warp basis.
   Morever, they're not real breakpoints, so we shouldn't treat them as such,
   otherwise we can set the chip on fire. */
static CUDBGResult
kepler_gk11x_getStepOverBPMask(CudbgDevice dev, uint32_t vsm, CUwarpBitmask *mask)
{
    CUDBGResult res = CUDBG_SUCCESS;

    /* If using KILP, then pull the broken warps mask from the (updated) devstate */
    if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_KILP) {
        warpBitmaskAssign(mask, &dev->smState[vsm].state.brokenwarps);
        return res;
    }

    if (!dev->activeContext || !haloStateContextIsActive(dev->activeContext)) {
        warpBitmaskClear(mask);
        return CUDBG_SUCCESS;
    }

    return kepler_gk11x_getBrokenWarps(&dev->halo, dev->activeContext->scratchpadAccessor, vsm,
        &dev->smState[vsm].state.tidValid, &dev->smState[vsm].state.bptrapmask, mask);
}

/* GK110 introduced {GET,SET}CRSPTR instructions.  GETCRSPTR indicates how many
   tokens are stored on the CRS for a given warp, so we can use this to know
   how many tokens to search through, which is used to know if we need to continue
   searching for trap tokens (RTT.FALLTHROUGH introduces the scenario where more
   than one trap token can be pushed. */
static CUDBGResult
kepler_gk11x_getCrsPhysStackDepth(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t *curPhysStackDepth)
{
    CUDBGResult res;

    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments to getCrsPhysStackDepth.\n");

    /* Don't bother mapping memory if we don't have an active context.
       This doesn't need to be fatal. */
    if (!dev->activeContext || !haloStateContextIsActive(dev->activeContext))
        return CUDBG_SUCCESS;

    res = dev->halo.scratchpad.read_curPhysStackDepth(dev->activeContext->scratchpadAccessor, vsm, wp, curPhysStackDepth);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read current physical stack depth\n");

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_getWarpCRSUsage(CudbgDevice dev, uint32_t vsm, uint32_t tid,
                             uint32_t *warpCRSNumEntries, uint32_t *warpCRSSize, bool *usingCRSPtr)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t numEntries = 0, maxEntries = 0, entrySize = 0, curPhysStackDepth = 0;

    CUDBG_VERIFY(warpCRSNumEntries && warpCRSSize && usingCRSPtr,
                 CUDBG_ERROR_INVALID_ARGS, "Invalid args in getWarpCRSUsage\n");

    res = dev->halo.CRSEntrySize(dev, &entrySize);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to CRSEntrySize failed in getWarpCRSUsage\n");
        return res;
    }

    res = dev->halo.maxCRSEntriesPerWarp(dev, vsm, tid, &maxEntries);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to maxCRSEntriesPerWarp failed in collectWarpCRS.\n");
        return res;
    }

    res = dev->halo.getCrsPhysStackDepth(dev, vsm, tid, &curPhysStackDepth);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to getCrsStackDepth failed in collectWarpCRS.\n");
        return res;
    }

    if (curPhysStackDepth && curPhysStackDepth < maxEntries) {
        numEntries = curPhysStackDepth;
        *usingCRSPtr = true;
        HALO_TRACE(20, "Using CRS PTR (curPhysStackDepth) FOR NUM ENTRIES: %d\n", numEntries);
    }
    else {
        numEntries = maxEntries;
        *usingCRSPtr = false;
        HALO_TRACE(20, "Using MAX CRS FOR NUM ENTRIES: %d\n", numEntries);
    }

    /* Kepler and greater:  Note it is safe to multiply numEntries by the entrySize
       as CRS entries completely fill a cache line and do not waste any space.  Note
       this benefit is only achieved on GK110+, where we have GETCRSPTR to tell us
       how many tokens are in use for a given warp. */
    *warpCRSNumEntries = numEntries;
    *warpCRSSize = numEntries * entrySize;
    return res;
}

static CUDBGResult
kepler_gk11x_waitForSMPause(CudbgDevice dev, uint32_t vsm)
{
    CUwarpBitmask tidValid = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;
    uint32_t smStatus;
    uint32_t smStatusAddr = 0;
    uint32_t elapsedTime;
    static const uint32_t timeout        = 5000000; // 5.00 seconds
    static const uint32_t printThreshold = 4990000; // 4.99 seconds => 20 printfs
    static const uint32_t sleepTime      = 500;
    CUDBGResult res = CUDBG_SUCCESS;

    /* Setup addresses */
    res = dev->halo.getPRIOffset(dev, HALO_PRI_SM_DBGR_STATUS0, vsm,
                                 &smStatusAddr);
    if (res != CUDBG_SUCCESS)
        return res;

    /* First, wait for _this_ SM to indicate it is in trap handler mode,
     * this way we can be sure that the tidValid mask is correct. */
    for (elapsedTime = 0; elapsedTime < timeout; elapsedTime += sleepTime) {
        res = dev->halo.readWarpMaskPRI(dev, vsm, HALO_REG_OP_TYPE_GLOBAL,
                                        HALO_MASK_PRI_WARP_VALID, &tidValid);
        if (res != CUDBG_SUCCESS)
            return res;

        res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                         (char *)(uintptr_t)smStatusAddr,
                                         &smStatus);
        if (res != CUDBG_SUCCESS)
            return res;

        if (!warpBitmaskAny(&tidValid) ||
            GETFIELD32(smStatus, NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_STATUS0_LOCKED_DOWN))
            break;

        if (elapsedTime > printThreshold)
            HALO_ERROR("SM %d hasn't LOCKED DOWN investigation: %7u tidValid=" CU_WARP_BIT_MASK_FMT_128_STR " smStatus=%x\n",
                       vsm, elapsedTime,
                       CU_WARP_BIT_MASK_FMT_128_VAL(&tidValid), smStatus);
#if cuosOsIsLinux() || cuosOsIsApple()
        /* Give some time for the device to catch up */
        usleep(sleepTime);
#endif
    }

    if (elapsedTime >= timeout) {
        HALO_ERROR("Timeout when waiting for SM LOCKED_DOWN.\n");
        /* We've already detected that LOCKED_DOWN hasn't been met.  So, as a backup,
           revert to the old style of waiting for the SM to pause by first waiting
           for the SM to enter trap mode, then waiting for the paused==valid condition
           (true since Fermi) */
        return fermi_waitForSMPause(dev, vsm);
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_getGridStatus(CudbgDevice dev, uint64_t gridId64, CUDBGGridStatus *status)
{
    Grid grid;
    uint64_t paramConstDptrAddress;
    uint64_t paramConstDptr;
    uint64_t gridIdAddr;
    uint64_t graphNodeAddr;
    uint64_t qmdSemaphoreAddr;
    CUsemaDataQmd qmdSemaphoreData = {0};
    uint64_t gridIdOffset;
    CUDBGResult res;
    uint64_t localGridId;
    CNPgraphNode cnpGraphNode = {0};
    Context context;

    /* If there's no active context, a grid might not have launched yet,
       or could have terminated. We can't disambiguate. */
    if (!dev->activeContext) {
        *status = CUDBG_GRID_STATUS_UNDETERMINED;
        return CUDBG_SUCCESS;
    }

    /* Check to see if the grid is visible on the device */
    res = fermi_getGridStatus(dev, gridId64, status);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Could not determine if the grid is visible\n");
        return res;
    }

    /* If the Fermi HAL call above found the grid to be active, use that   */
    if (*status == CUDBG_GRID_STATUS_ACTIVE)
        return CUDBG_SUCCESS;

    grid = haloStateDeviceGetGrid(dev, gridId64);

    /* We should always have a valid grid data structure at this point */
    CUDBG_VERIFY(grid, CUDBG_ERROR_INVALID_GRID, "Invalid grid pointer!\n");

    /* If the grid does not do any CNP launches/joins, we don't need to
       investigate any further. Here there is a possibility that the
       grid was created while it was inside global syscalls. In such scenario
       also check if the user entry function uses CNP*/
    if (!(grid->function->usesCnp ||
         ((grid->function->type == DEV_FUNC_TYPE_GLOBAL_SYSCALL) &&
           grid->userEntryFunction->usesCnp)))
        return CUDBG_SUCCESS;

    /* Grab the context for the grid, as the active context may not
       be the context the grid actually belongs to
     */
    context = grid->function->module->context;

    /* If the selfQMDdptr is NULL, it means the grid was either no longer
       present or had not started on the hardware when the debugger stopped
       at a device event and examined all grids. */
    if (!grid->selfQMDdptr)
        return res;

    /* When a grid that does CNP is not visible, it could have either
       terminated or could be waiting on a join, so we must investigate
       further. */

    *status = CUDBG_GRID_STATUS_INVALID;

    paramConstDptrAddress = grid->selfQMDdptr + ((uint64_t)(uintptr_t)&((CNPqmdLaunch *)0)->paramConstDptr);

    /* Read paramConstDptr from the QMDLaunch structure */
    res = dev->halo.readGenericMemory(context,
                                      0, 0, 0,
                                      paramConstDptrAddress,
                                      &paramConstDptr,
                                      sizeof(paramConstDptr));
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read paramConstDptr from QMDLaunch\n");
        return res;
    }

    HALO_TRACE_FUNCTION(2, "paramConstDptr from QMD: 0x%016llx\n", (unsigned long long)paramConstDptr);

    /* If paramConstDptr == 0, it means we are dealing with a GPU launched grid
       that has terminated. For a GPU launched grid, the scheduler kernel sets
       paramConstDptr to 0 when the GPU grid completes */
    if (paramConstDptr == 0) {
        *status = CUDBG_GRID_STATUS_TERMINATED;
        return res;
    }

    res = dev->halo.getGridParamsOffsetGridId(dev, &gridIdOffset);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to get gridId offset in GridParams\n");
        return res;
    }

    gridIdAddr = paramConstDptr + gridIdOffset;

    /* Read gridId from the constbank that paramConstDptr points to */
    res = dev->halo.readGenericMemory(context,
                                      0, 0, 0,
                                      gridIdAddr,
                                      &localGridId,
                                      sizeof(localGridId));
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read gridId from param constbank\n");
        return res;
    }

    HALO_TRACE_FUNCTION(2, "gridId from QMD->paramConstDptr->gridId64: %" PRId64 "\n", localGridId);
    HALO_TRACE_FUNCTION(2, "input gridId: %" PRId64 "\n", (int64_t)gridId64);

    if (gridId64 != localGridId) {
        *status = CUDBG_GRID_STATUS_TERMINATED;
        return res;
    }

    /* In case the gridId matches the stored value, check if this was a CPU grid
       or GPU grid. In case of a GPU launched grid, the information we have here
       is enough to unambiguously determine if a grid is resident or not.

       But for CPU launched grids, more checks are needed to be sure the grid
       is really resident, since we cannot rely on the scheduler kernel to reset
       paramConstDptr when the grid completes. So the grid could have completed
       and the QMD launch slot could have stale values. */
    if ((int64_t)gridId64 < 0) {
        *status = CUDBG_GRID_STATUS_SLEEPING;
    }
    else {
        *status = CUDBG_GRID_STATUS_INVALID;

        /* Map in the graphNode structure from the selfQMD */
        graphNodeAddr = grid->selfQMDdptr + ((uint64_t)(uintptr_t)&((CNPqmdLaunch *)0)->graphNode);

        res = dev->halo.readGenericMemory(context,
                                          0, 0, 0,
                                          graphNodeAddr,
                                          &cnpGraphNode,
                                          sizeof(cnpGraphNode));
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to map graphNode structure from QMDLaunch\n");
            return res;
        }

        /* Now map the host semaphore and check its value. */
        qmdSemaphoreAddr = cnpGraphNode.parent.addr;

        HALO_TRACE_FUNCTION(2, "semaphore address: 0x%016llx\n", (unsigned long long)qmdSemaphoreAddr);

        res = dev->halo.readDeviceMemory(context, qmdSemaphoreAddr,
                                         &qmdSemaphoreData, sizeof(qmdSemaphoreData));
        if (cuosOsIsWindows() && res == CUDBG_ERROR_ADDRESS_NOT_IN_DEVICE_MEM) {
            /* Under TCC+WDDM configurations, we can't access the semaphore data
               since it needs to be mapped via WDDM under an OS_DESCRIPTOR and
               not by RM.  In this case, mark the grid as sleeping to be safe. */
            *status = CUDBG_GRID_STATUS_UNDETERMINED;
        }
        else if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to map host semaphore address\n");
            return res;
        }
        else {
            HALO_TRACE_FUNCTION(2, "host semaphore value for grid %" PRId64 ": %d\n", gridId64, qmdSemaphoreData.payload);

            if (qmdSemaphoreIsFinalPayload(qmdSemaphoreData.payload))
                *status = CUDBG_GRID_STATUS_TERMINATED;
            else
                *status = CUDBG_GRID_STATUS_SLEEPING;
        }
    }

    /* If Software Preemption is enabled and grid is preempted then active
     * status should be reported. */
    if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_KILP &&
        *status == CUDBG_GRID_STATUS_SLEEPING) {
        uint32_t sm, wp;

        for (sm = 0; sm < dev->halo.deviceInfo.numSMs; ++sm) {
            for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
                if (dev->preemptMappingTable.sm[sm].warp[wp].gridId == gridId64) {
                    *status = CUDBG_GRID_STATUS_ACTIVE;
                    return res;
                }
            }
        }
    }

    return res;
}

static CUDBGResult
kepler_gk11x_getDynamicRegisterRange (uint32_t *dynamicRegisterStart, uint32_t *dynamicRegisterEnd)
{
    CUDBG_VERIFY(dynamicRegisterStart, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");
    CUDBG_VERIFY(dynamicRegisterEnd, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");

    *dynamicRegisterStart = KEPLER_GK11X_DYNAMIC_REGISTER_START;
    *dynamicRegisterEnd = KEPLER_GK11X_DYNAMIC_REGISTER_END;

    return CUDBG_SUCCESS;
}

/* Get offset of gridId in GridParams. This is DCI dependent, hence halified. */
static CUDBGResult
kepler_gk11x_getGridParamsOffsetGridId (CudbgDevice dev, uint64_t *offset)
{
    CUDBG_VERIFY(offset, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");

    *offset = ((uint64_t)(uintptr_t)&((CUkeplerGridParams *)0)->gridId);

    return CUDBG_SUCCESS;
}

/* Get offset of blockDim in GridParams. This is DCI dependent, hence halified. */
static CUDBGResult
kepler_gk11x_getGridParamsOffsetBlockDim (CudbgDevice dev, uint64_t *offset, uint32_t *size)
{
    CUDBG_VERIFY(offset && size, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");

    *offset = ((uint64_t)(uintptr_t)&((CUkeplerGridParams *)0)->blockDim);
    *size = sizeof ((CUkeplerGridParams *)0)->blockDim;

    return CUDBG_SUCCESS;
}

/* Get offset of gridDim in GridParams. This is DCI dependent, hence halified. */
static CUDBGResult
kepler_gk11x_getGridParamsOffsetGridDim (CudbgDevice dev, uint64_t *offset, uint32_t *size)
{
    CUDBG_VERIFY(offset && size, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");

    *offset = ((uint64_t)(uintptr_t)&((CUkeplerGridParams *)0)->gridDim);
    *size = sizeof ((CUkeplerGridParams *)0)->gridDim;

    return CUDBG_SUCCESS;
}

/* Get offset of startPc in GridParams. This is DCI dependent, hence halified. */
static CUDBGResult
kepler_gk11x_getGridParamsOffsetStartPc (CudbgDevice dev, uint64_t *offset)
{
    CUDBG_VERIFY(offset, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");

    *offset = CNP_GRID_PARAM_OFFSET(startPc);

    return CUDBG_SUCCESS;
}

/* Check if this is a reserved grid */
static CUDBGResult
kepler_gk11x_isReservedGridId (CudbgDevice dev, uint64_t gridId64, bool *isReserved)
{
    if ((int64_t)gridId64 == KEPLER_GK11X_CNP_SCHED_KERNEL_GRID_ID)
        *isReserved = true;
    else
        *isReserved = false;
    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_checkAnyLaneInContinuation(CudbgDevice dev, uint32_t vsm, CUwarpBitmask *wpmask, bool *inContinuation)
{
    uint32_t wp = 0;
    uint32_t ln = 0;
    DeviceFunction function = NULL;
    uint64_t physPC = 0;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(dev && inContinuation && wpmask, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");
    *inContinuation = false;

    for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
        if (!warpBitmaskGetBits(wpmask, wp, 1))
            continue;

        for (ln = 0; ln < dev->halo.deviceInfo.numLanesPrWarp; ++ln) {
            if (!(dev->smState[vsm].warp[wp].validLanes & (1U<<ln)))
                continue;

            /* Find the correct PC for this lane, accounting for divergence */
            if (dev->smState[vsm].warp[wp].activeMask & (1U << ln)) {
                res = dev->halo.readPC(dev, vsm, wp, &physPC);
                if (res != CUDBG_SUCCESS) {
                    HALO_ERROR("Call to readPC failed (res=%d)\n", res);
                    return res;
                }
            }
            else {
                res = dev->halo.findDivergedCRS_PC(dev, vsm, wp, ln, &physPC);
                if (res != CUDBG_SUCCESS) {
                    HALO_ERROR("Call to findDivergedCRS_PC failed (res=%d)\n", res);
                    return res;
                }
            }

            function = (DeviceFunction)toolsRangeMapLookupByAddr(dev->activeContext->gpuAddrToFunction, (uint64_t)physPC);
            if (!function)
                continue;

            if (function->isCnpCtxSync) {
                HALO_TRACE_FUNCTION(2, " vsm%u/wp%u/ln%u Found PC:0x%" PRIx64 " in cudaDeviceSync syscall\n",
                                    vsm, wp, ln, physPC);
                *inContinuation = true;
                return CUDBG_SUCCESS;
            }
        }
    }

    return res;
}

static CUDBGResult
kepler_gk11x_checkFuncNeedsHostResume(Context ctx, uint64_t pc, bool *needsHostResume)
{
    DeviceFunction func = NULL;

    CUDBG_VERIFY(ctx && needsHostResume, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    *needsHostResume = false;

    func = (DeviceFunction)toolsRangeMapLookupByAddr(ctx->gpuAddrToFunction, pc);

    if (func && func->needsHostResume)
        *needsHostResume = true;

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_checkWarpNeedsHostResume(CudbgDevice dev, uint32_t vsm, uint32_t wp, bool *needsHostResume)
{
    bool in_syscall = false;
    uint32_t syscall_call_depth = 0, depth = 0;
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t ln = 0;
    uint64_t prevPC = 0;
    uint64_t userPC = 0;
    DebugPatch patch;

    CUDBG_VERIFY(dev && needsHostResume, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");
    *needsHostResume = false;

    if (!dev->smState[vsm].valid)
        return CUDBG_SUCCESS;

    if (!dev->smState[vsm].warp[wp].valid)
        return CUDBG_SUCCESS;

    /* Test the current PC */
    res = dev->halo.readPC(dev, vsm, wp, &userPC);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read user PC\n");

    res = kepler_gk11x_checkFuncNeedsHostResume(dev->activeContext, (uint64_t)userPC, needsHostResume);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to check function at PC:0x%" PRIx64 " (vsm%d/wp%d)\n",
                 userPC, vsm, wp);

    if (*needsHostResume) {
        HALO_TRACE_FUNCTION(10, "Found sm%d/wp%d warp needs host resume\n", vsm, wp);
        return CUDBG_SUCCESS;
    }

    /* Only syscall entry frames can have host resume set, so instead of looking
       at the entire stack, we can jump directly to the frame of interest */
    res = dev->haloClient->inSyscallPatch(dev, userPC, &patch, &in_syscall);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to see if lane is currently in a syscall patch\n");

    if (in_syscall) {
        res = haloFindAnActiveLane(dev, vsm, wp, &ln);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to find an active lane\n");

        res = dev->halo.readSyscallCallDepth(dev, vsm, wp, ln, &syscall_call_depth);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read syscall call depth\n");

        for (depth = 0; depth < syscall_call_depth; ++depth) {
            res = dev->halo.readReturnAddress(dev, vsm, wp, ln, depth, &prevPC);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get return address for frame %d on vsm%d/wp%d/ln%d\n",
                         depth, vsm, wp, ln);

            res = kepler_gk11x_checkFuncNeedsHostResume(dev->activeContext, prevPC, needsHostResume);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to check func at PC:0x%x for frame %d on vsm%d/wp%d/ln%d\n",
                        (uint32_t)prevPC, depth, vsm, wp, ln);

            if (*needsHostResume) {
                HALO_TRACE_FUNCTION(10, "Found sm%d/wp%d/ln%d (frame:%d) needs host resume\n",
                                    vsm, wp, ln, depth);
                return CUDBG_SUCCESS;
            }
        }
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_readPredicates(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                            uint32_t numPreds, uint32_t *predicates)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t i;
    uint32_t predicateReg = 0;
    uint32_t predLmemAddr = KEPLER_GK11X_LMEM_ABI_HI(vsm, wp) - KEPLER_GK11X_LMEM_ABI_SAVED_PREDICATES;

    CUDBG_VERIFY(predicates, CUDBG_ERROR_INVALID_ARGS, "Invalid args in kepler_gk11x_readPredicates\n");
    CUDBG_VERIFY(numPreds <= KEPLER_NUM_PREDICATES, CUDBG_ERROR_INVALID_ARGS, "Invalid # of predicates\n");

    /* Read predicate register from lmem */
    res = dev->halo.readLocalMemory(dev, vsm, wp, ln, predLmemAddr, &predicateReg, sizeof predicateReg);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read predicate register from lmem\n");
        return res;
    }

    /* Predicates are backed in the LSBs of PR */
    for (i = 0; i < numPreds; i++) {
        predicates[i] = (predicateReg >> i) & 1U;
    }

    return res;
}

static CUDBGResult
kepler_gk11x_writePredicates(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                             uint32_t numPreds, const uint32_t *predicates)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t i;
    uint32_t predicateReg = 0;
    uint32_t predLmemAddr = KEPLER_GK11X_LMEM_ABI_HI(vsm, wp) - KEPLER_GK11X_LMEM_ABI_SAVED_PREDICATES;

    CUDBG_VERIFY(predicates, CUDBG_ERROR_INVALID_ARGS, "Invalid args in kepler_gk11x_writePredicate\n");
    CUDBG_VERIFY(numPreds <= KEPLER_NUM_PREDICATES, CUDBG_ERROR_INVALID_ARGS, "Invalid # of predicates\n");

    /* Read existing predicate register from lmem */
    res = dev->halo.readLocalMemory(dev, vsm, wp, ln, predLmemAddr, &predicateReg, sizeof predicateReg);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read predicate register from lmem\n");
        return res;
    }

    /* Modify predicate register based on inputs */
    for (i = 0; i < numPreds; i++) {
       CUDBG_VERIFY(predicates[i] < 2, CUDBG_ERROR_INVALID_ARGS, "Invalid predicate value\n");
       predicateReg = (predicateReg & ~(1U << i)) | (predicates[i] << i);
    }

    /* Write updated predicate register back to lmem */
    res = dev->halo.writeLocalMemory(dev, vsm, wp, ln, predLmemAddr, &predicateReg, sizeof predicateReg);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to write predicate register to lmem\n");
        return res;
    }

    return res;
}

static CUDBGResult
kepler_gk11x_readCCRegister(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                            uint32_t *cc)
{
    return haloReadCCRegister(dev, vsm, wp, ln,
                              KEPLER_GK11X_LMEM_ABI_HI(vsm, wp) - KEPLER_GK11X_LMEM_ABI_SAVED_PREDICATES,
                              cc);
}

static CUDBGResult
kepler_gk11x_isTerminalInstructionAtPC(Context ctx, uint64_t pc, bool *isExitingInstruction)
{
    uint64_t inst;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(ctx && isExitingInstruction, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    res = ctx->dev->halo.readCodeMemory(ctx, pc, &inst, sizeof inst);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Error reading pc %#" PRIx64 "\n", inst);

    *isExitingInstruction = kepler_gk11x_isExit(ctx->dev, inst) || kepler_gk11x_isRet(ctx->dev, inst);

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_writeCCRegister(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                             const uint32_t cc)
{
    return haloWriteCCRegister(dev, vsm, wp, ln,
                               KEPLER_GK11X_LMEM_ABI_HI(vsm, wp) - KEPLER_GK11X_LMEM_ABI_SAVED_PREDICATES,
                               cc);
}

static CUDBGResult
kepler_gk11x_needsProfilerObject (CudbgDevice dev, bool *needsProfilerObject)
{
    CUDBG_VERIFY(dev && needsProfilerObject, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");
    *needsProfilerObject = false;
    return CUDBG_SUCCESS;
}

/* Scratchpad access */

static CUDBGResult
kepler_gk11x_scratchpad_read_pauseServicedMask(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, CUwarpBitmask *pauseServicedMask)
{
    CUDBG_VERIFY(scratchpadAccessor && pauseServicedMask, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, SM, PAUSE_SERVICED_MASK, vsm, 0, 0, pauseServicedMask);

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_scratchpad_read_pauseServicedMask_raw(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint64_t *pauseServicedMask)
{
    CUDBG_VERIFY(scratchpadAccessor && pauseServicedMask, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, SM, PAUSE_SERVICED_MASK, vsm, 0, 0, pauseServicedMask);

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_scratchpad_read_CRSPtr(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *crsPtr)
{
    CUDBG_VERIFY(scratchpadAccessor && crsPtr, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, CRS_PTR, vsm, wp, 0, crsPtr);

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_scratchpad_read_curPhysStackDepth(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *curPhysStackDepth)
{
    uint32_t crsPtr;

    CUDBG_VERIFY(scratchpadAccessor && curPhysStackDepth, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    /* From opGETCRSPTR.htm:

       The result of GETCRSPTR is a 32-bit value containing these fields:
       bits  field
       --------------------------
       16: 0  curPhysStackDepth
       22:17  reserved
       30:23  curApiCallDepth
       31:31  KillFutureBranch */
    kepler_gk11x_scratchpad_read_CRSPtr(scratchpadAccessor, vsm, wp, &crsPtr);
    *curPhysStackDepth = crsPtr & 0x1ffff;

    return CUDBG_SUCCESS;
}

static CUDBGResult
kepler_gk11x_scratchpad_write_pauseServicedMask_raw(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint64_t pauseServicedMask)
{
    CUDBG_VERIFY(scratchpadAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_SET_FIELD(scratchpadAccessor, SM, PAUSE_SERVICED_MASK, vsm, 0, 0, &pauseServicedMask);

    return CUDBG_SUCCESS;
}

/* Populate the debugger structure with Kepler GK11x specific functions. */
void
haloDeviceInit_gk11x(Halo_st *halo)
{
    /* GK11x - account for larger register file */
    halo->getInfo = kepler_gk11x_getInfo;
    halo->readRegisterRange = kepler_gk11x_readRegisterRange;
    halo->writeRegisterFile = kepler_gk11x_writeRegisterFile;

    /* GK11x - account for different opcodes (only 64-bit instructions, as well) */
    halo->isSteppable = kepler_gk11x_isSteppable;
    halo->isInternalInstructionAtPC = kepler_gk11x_isInternalInstructionAtPC;
    halo->isTerminalInstructionAtPC = kepler_gk11x_isTerminalInstructionAtPC;
    halo->forceTermination = kepler_gk11x_forceTermination;

    /* GK11x - need to indicate which paused warps have been serviced */
    halo->writePauseServicedMask = kepler_gk11x_writePauseServicedMask;
    halo->readPauseServicedMask = kepler_gk11x_readPauseServicedMask;
    halo->resumeDevice = kepler_gk11x_resumeDevice;
    halo->resumeSM = kepler_gk11x_resumeSM;

    /* GK11x - Textures */
    halo->patchTextureInstruction   = kepler_gk11x_patchTextureInstruction;
    halo->getLmemOffsetForTexCoords = kepler_gk11x_getLmemOffsetForTexCoords;

    /* GK11x - Account for {SET,GET}LMEMBASE */
    halo->getLmemInternalOffset = kepler_gk11x_getLmemInternalOffset;
    halo->getCRSInternalOffset = kepler_gk11x_getCRSInternalOffset;

    /* GK11x - Account for different LMEM ABI */
    halo->readLaneServiceReason = kepler_gk11x_readLaneServiceReason;
    halo->thServiceWriteInfo = kepler_gk11x_thServiceWriteInfo;
    halo->readPredicates = kepler_gk11x_readPredicates;
    halo->writePredicates = kepler_gk11x_writePredicates;
    halo->readCCRegister = kepler_gk11x_readCCRegister;
    halo->writeCCRegister = kepler_gk11x_writeCCRegister;

    /* GK11x - Handle grid posting differently */
    halo->setWarpStateValid = kepler_gk11x_setWarpStateValid;

    /* GK11x - Handle BPT.TRAP 2 (CNP) / brokenwarps in SM State */
    halo->getStepOverBPMask = kepler_gk11x_getStepOverBPMask;

    /* GK11x - get broken warps */
    halo->getBrokenWarps        = kepler_gk11x_getBrokenWarps;

    /* GK11x - Use GETCRSPTR to limit # of CRS entries to search (and handle RTT.FALLTHROUGH) */
    halo->getCrsPhysStackDepth = kepler_gk11x_getCrsPhysStackDepth;
    halo->getWarpCRSUsage = kepler_gk11x_getWarpCRSUsage;

    /* GK11x - Account for LOCKED_DOWN (a new way of waiting for the SM to pause) */
    halo->waitForSMPause = kepler_gk11x_waitForSMPause;

    /* GK11x - Determine if a grid is till resident */
    halo->getGridStatus = kepler_gk11x_getGridStatus;

    /* GK11x - Patch dynamic register read/write */
    halo->patchDynamicRegisterRead = kepler_gk11x_patchDynamicRegisterRead;
    halo->patchDynamicRegisterWrite = kepler_gk11x_patchDynamicRegisterWrite;
    halo->getDynamicRegisterRange   = kepler_gk11x_getDynamicRegisterRange;

    /* GK11x - offset of gridId in GridParams */
    halo->getGridParamsOffsetGridId   = kepler_gk11x_getGridParamsOffsetGridId;

    /* GK11x - offset of blockDim in GridParams */
    halo->getGridParamsOffsetBlockDim = kepler_gk11x_getGridParamsOffsetBlockDim;

    /* GK11x - offset of gridDim in GridParams */
    halo->getGridParamsOffsetGridDim = kepler_gk11x_getGridParamsOffsetGridDim;

    /* GK11x - offset of gridDim in GridParams */
    halo->getGridParamsOffsetStartPc = kepler_gk11x_getGridParamsOffsetStartPc;

    /* GK11x - find parent Grid for a given child Grid */
    halo->findParentGrid   = kepler_gk11x_findParentGrid;

    /* GK11x - check if this grid is reserved */
    halo->isReservedGridId   = kepler_gk11x_isReservedGridId;

    /* GK11x - check if any of the lanes in the warpmask are in a continuation syscall */
    halo->checkAnyLaneInContinuation = kepler_gk11x_checkAnyLaneInContinuation;

    /* GK11x - check if the current warp needs the host to be resumed  */
    halo->checkWarpNeedsHostResume = kepler_gk11x_checkWarpNeedsHostResume;

    /* GK11x - force use of scratchpad for lmem devva info */
    halo->forceScratchpadLmemBase = kepler_gk11x_forceScratchpadLmemBase;

    halo->needsProfilerObject = kepler_gk11x_needsProfilerObject;

    /* Scratchpad access */

    halo->scratchpad.read_pauseServicedMask = kepler_gk11x_scratchpad_read_pauseServicedMask;
    halo->scratchpad.read_pauseServicedMask_raw = kepler_gk11x_scratchpad_read_pauseServicedMask_raw;
    halo->scratchpad.read_CRSPtr = kepler_gk11x_scratchpad_read_CRSPtr;
    halo->scratchpad.read_curPhysStackDepth = kepler_gk11x_scratchpad_read_curPhysStackDepth;

    halo->scratchpad.write_pauseServicedMask_raw = kepler_gk11x_scratchpad_write_pauseServicedMask_raw;
}
