/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: volta_gv10x.c
 *
 *   Description:
 *       Internal API for the low-level GPU access needed to support
 *       the debugger on Volta (GV10x).
 *
 ******************************************************************************/

#include "fermi.h"
#include "cudadebugger.h"
#include "halo_internal.h"
#include "halo_state.h"
#include "tools_shared_dwarf.h"
#include "pascal.h"
#include "pascal_gp10x.h"
#include "volta.h"
#include "volta_gv10x.h"
#include "volta_scratchpad.h"
#include "volta_cilp_preemption_buffer.h"
#include "volta/gv100/dev_graphics_nobundle.h"
#include "gv10x_sass.h"
#include "fermi_mcinterop.h"
#include "volta/volta_structs.h"

/* REG_CLASS_SET() isn't useful to us */
#define REG_CLASS_ENCODE(_r, _c) (((_c) << 24) | (_r))

/* ?WAIT15_END_GROUP_NO_SB */
#define VOLTA_SAFE_OPEX_HI ((GV10X_SET_FIELD_BITS_8_124_122_109_105_opex_HI_00(GV10X_KEYWORD_USCHED_INFO_WAIT15_END_GROUP)) |  \
                            GV10X_SET_FIELD_BITS_3_115_113_src_rel_sb_HI(GV10X_KEYWORD_SCOREBOARD_INVALID7) | \
                            GV10X_SET_FIELD_BITS_3_112_110_dst_wr_sb_HI(GV10X_KEYWORD_SCOREBOARD_INVALID7))

/* These are magic fake register values for holding the return address column. */
#define VOLTA_FAKE_RPC_LO 0xdead
#define VOLTA_FAKE_RPC_HI (VOLTA_FAKE_RPC_LO+1)

CUDBGResult
volta_gv10x_getInfo(CudbgDevice dev)
{
    CUDBGResult res;

    res = pascal_gp10x_getInfo(dev);

    dev->halo.deviceInfo.lmemHiMembarWarSpillR2 = VOLTA_LMEM_HI_MEMBAR_WAR_SPILL_R2;
    dev->halo.deviceInfo.lmemHiMembarWarSpillR3 = VOLTA_LMEM_HI_MEMBAR_WAR_SPILL_R3;

    return res;
}

static CUDBGResult
volta_gv10x_getRegisterCount(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t *numRegsUsedByKernel)
{
    CUDBGResult res;
    Context ctx;

    CUDBG_VERIFY(dev && numRegsUsedByKernel,  CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    ctx = dev->activeContext;
    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context\n");

    res = dev->halo.scratchpad.read_registerCount(ctx->scratchpadAccessor, vsm, wp, numRegsUsedByKernel);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read register count\n");

    /* Scratchpad will give the total number of registers, but only N-2 are user
       accessible (the top two are the restore pc for the lane on volta) */
    *numRegsUsedByKernel -= 2;

    return CUDBG_SUCCESS;
}

/* Maximum number of levels to unwind before giving up */
#define VOLTA_UNWIND_MAX_LEVELS (1000)

/* Read register data. We have 3 cases:
 * 1) Spilled to local memory specified by reg and offset (STL[R1+0xdecaf], R2)
 * 2) Spilled to a static local memory offset (STL [0xcafe], R2])
 * 3) Spilled to a register. (Register to register spill).
 *
 * If we have a spill to a register and not at level 0, meaning we are higher up
 * the call stack (closer to main), then we need to work our way back down to
 * see where the data might be stored.  We have the state up to this point,
 * and the state has this information collected from frame 0 to higher frames.
 * We just need to trace the register(R) debug rule to see where the register
 * might have spilled to.  Perhaps it was spilled in frame 1 and then again in
 * frame 2.
 * 
 * For example: 
 * frame(0) ::  R1 = x2; R2 = R4; ... break   ... R4 = R2; x2 = R1;
 * frame(1) ::  R4 = R3; R5 = x1; ... call(0) ... R3 = R4; x1 = R5;
 * frame(2) ::  R3 = x0; ...          call(1) ... x0 = R3;
 *
 * Suppose we (pc) are at frame (0) at 'break'.  frame(0) and its registers are
 * live.  Any register reads happen from frame(0) perspective. Suppose
 * we unwind all the way up to frame(2) where the pc was at call(1).  To get here
 * the debugger first collects CFA state from frame(0), then updating state
 * by collecting CFA state from frame(1), and then updating state from frame(2).
 * By unwinding we update state, so we have the collected register state from 0
 * to 1 to 2.  The user now asks the debugger 'Where is x0 for frame 2?'
 * 1) Debugger checks the collected CFA state and sees that R3 holds x0.
 * 2) Debugger checks the collected CFA state for R3 and sees that R4 holds R3.
 * 3) Debugger checks the collected CFA state for R4 and sees that R2 holds R4.
 * 4) Since the debugger has traversed all frames to level 0 looking for 
 *    where the hell x0 is and it found x0 in a live register.  The debugger
 *    can now readRegister(R2) to get the original value that was X0.
 *    Transitivity dawg.  Note that the transitivity is handled in
 *    the CFA rule parser (tools_shared/tools_shared_readelf.c/nextCFAInsn) 
 *    it 'update' is set to 'true'.  It automatically updates the current
 *    register with the value it spills to.  This avoids having to hop from R3
 *    to R4 to R2 in the debug_frame state in example above.  The register would
 *    have R2 in its location in the debug_frame state.
 *
 * If the value is spilled to memory, we can exit the stack unwind early,
 * since the value we are looking for has been found.
 */
static CUDBGResult
readEncodedRegister(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                    uint32_t regno, uint32_t *val)
{
    CUDBGResult res;
    
    switch (REG_CLASS(regno)) {
    case REG_CLASS_REG_FULL:
        res = dev->halo.readRegisterRange(dev, vsm, wp, ln,
                                          REG_CLASS_REG(regno), val, 1, true);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "readRegisterRange(%d) failed\n");
        HALO_TRACE_FUNCTION(40, "%u/%u/%u/%u regno R%d (0x%08x) = 0x%08x\n",
                            dev->deviceIdx, vsm, wp, ln, REG_CLASS_REG(regno), regno, *val);
        break;

    case REG_CLASS_UREG_FULL:
        res = dev->halo.readUniformRegisterFile(dev, vsm, wp,
                                                REG_CLASS_REG(regno) * sizeof(uint32_t),
                                                (void *)val, sizeof(uint32_t));
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "readUniformRegisterFile(%d) failed\n");
        HALO_TRACE_FUNCTION(40, "%u/%u/%u/%u regno UR%d (0x%08x) = 0x%08x\n",
                            dev->deviceIdx, vsm, wp, ln, REG_CLASS_REG(regno), regno, *val);
        break;

    default:
        HALO_TRACE_FUNCTION(10, "%u/%u/%u/%u invalid regno 0x%08x\n",
                            dev->deviceIdx, vsm, wp, ln, regno);
        res = CUDBG_ERROR_INTERNAL;
        break;
    }

    return res;
}

static CUDBGResult
getRegData(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
           const DwarfFrameState *current, uint32_t regno, uint32_t *val)
{
    uint32_t addr;
    uint32_t reg = 0;
    int32_t offset = 0;
    DwarfFrameRegRule rule;
    TOOLSresult tres;
    CUDBGResult cres = CUDBG_SUCCESS;

    CUDBG_VERIFY(dev && val, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    *val = 0;

    /* Search the frame table for the register */
    tres = toolsGetRegister(current, regno, &reg, &offset, &rule);
    if (tres != TOOLS_SUCCESS) {
        *val = 0;
        return CUDBG_SUCCESS;
    }

    HALO_TRACE_FUNCTION(50, "vsm%d/wp%d/ln%d rule=%d\n", vsm, wp, ln, rule);

    switch (rule) {
    case DWARF_FRAME_REG_UNDEFINED:
        *val = 0;
        break;
    case DWARF_FRAME_REG_VALUE:
        *val = (uint32_t)offset;
        break;
    case DWARF_FRAME_REG_SAME:
    case DWARF_FRAME_REG_REG:
        cres = readEncodedRegister(dev, vsm, wp, ln, reg, val);
        break;
    case DWARF_FRAME_REG_OFFSET:
        /* Spilled to register + offset */
        cres = readEncodedRegister(dev, vsm, wp, ln, reg, &addr);
        if (cres != CUDBG_SUCCESS)
            return cres;

        HALO_TRACE_FUNCTION(50, "vsm%d/wp%d/ln%d reg-offset reg=0x%08x addr=%#x offset=%#x\n",
                            vsm, wp, ln, reg, addr, offset);

        addr += offset;
        cres = dev->halo.readLocalMemory(dev, vsm, wp, ln, addr, val, sizeof(*val));
        break;
    default:
        HALO_ERROR("Invalid rule returned: %#x\n", (int)rule);
        return CUDBG_ERROR_INTERNAL;
    }

    HALO_TRACE_FUNCTION(50, "vsm%d/wp%d/ln%d val=%#x\n", vsm, wp, ln, *val);

    return cres;
}

#if !defined(RELEASE)
static uint32_t
decodeULEB(char **pptr)
{
    unsigned char *ptr = (unsigned char*) *pptr;
    uint32_t i = 0 ;
    uint64_t result = 0;

    /* Only read the lower 5 bytes of the LEB128 value, rather
       than reading maximum possible. This is because the rest
       of the code cannot handle arbitrary sizing currently. */
    result |= (*ptr & 0x7f);
    while ((*ptr & 0x80) != 0 && i < 4) {
        ptr += 1;
        i++;
        result |= (*ptr & 0x7f) << (i * 7);
    }

    *pptr = (char*) ptr + 1;
    return (uint32_t)result;
}

static void
haloTraceDWFormBlock(uint8_t *data, uint64_t length)
{
    uint8_t opcode;
    uint8_t *end = data + length;
    uint32_t traceLevel = 50;

    opcode = *data;
    switch (opcode) {
    case DW_FORM_data2:
        HALO_TRACE_FUNCTION(traceLevel, "DW_FORM_data2\n");
        data += sizeof(*data);
        break;

    default:
        HALO_TRACE_FUNCTION(traceLevel, "<unknown> DW_FORM 0x%02x\n", opcode);
        break;
    }

    while (data < end) {
        opcode = *data;
        data += sizeof(*data);
        switch (opcode) {
        case DW_OP_const4u:
            HALO_TRACE_FUNCTION(traceLevel, "DW_OP_const4u 0x%08x\n",
                                *(uint32_t *)data);
            data += sizeof(uint32_t);
            break;

        default:
            HALO_TRACE_FUNCTION(traceLevel, "<unknown> DW_OP 0x%02x\n", opcode);
            break;
        }
    }
}

static void
haloTraceCFAInsns(DwarfCIE *cie, uint8_t *data, uint8_t *end)
{
    uint8_t opcode;
    uint32_t regnum, regnum1;
    uint64_t offset, length, location;
    uint32_t traceLevel = 50;
    extern uint32_t decodeULEB(char **pptr);

    location = 0;
    while (data < end) {
        opcode = *data;
        data += sizeof(uint8_t);
        switch (opcode & DW_CFA_OPCODE_MASK) {
        case DW_CFA_advance_loc:
            HALO_TRACE_FUNCTION(traceLevel, "DW_CFA_advance_loc 0x%08x\n", (opcode & 0x3f) * cie->code_alignment_factor);
            break;

        case DW_CFA_offset:
            regnum = opcode & 0x3f;
            offset = decodeULEB((char **)&data);
            HALO_TRACE_FUNCTION(traceLevel, "DW_CFA_offset reg = 0x%08x offset = %#" PRIx64 "\n",
                                regnum, offset);
            break;

        case DW_CFA_opcode:
            switch (opcode) {
            case DW_CFA_nop:
                HALO_TRACE_FUNCTION(traceLevel, "DW_CFA_nop\n");
                break;

            case DW_CFA_set_loc:
                location = *(uint64_t *)data;
                data += sizeof(uint64_t);
                HALO_TRACE_FUNCTION(traceLevel, "DW_CFA_set_loc %#" PRIx64 "\n", location);
                break;

            case DW_CFA_advance_loc1:
                location += *(uint8_t *)data * cie->code_alignment_factor;
                data += sizeof(uint8_t);
                HALO_TRACE_FUNCTION(traceLevel, "DW_CFA_advance_loc1 %#" PRIx64 "\n", location);
                break;

            case DW_CFA_advance_loc2:
                location += *(uint16_t *)data * cie->code_alignment_factor;
                data += sizeof(uint16_t);
                HALO_TRACE_FUNCTION(traceLevel, "DW_CFA_advance_loc2 %#" PRIx64 "\n", location);
                break;

            case DW_CFA_advance_loc4:
                location += *(uint32_t *)data * cie->code_alignment_factor;
                data += sizeof(uint32_t);
                HALO_TRACE_FUNCTION(traceLevel, "DW_CFA_advance_loc4 %#" PRIx64 "\n", location);
                break;

            case DW_CFA_offset_extended:
                regnum = decodeULEB((char **)&data);
                offset = decodeULEB((char **)&data) * cie->data_alignment_factor;
                HALO_TRACE_FUNCTION(traceLevel, "DW_CFA_offset_extended regnum %#x offset %#" PRIx64 "\n",
                                    regnum, offset);
                break;

            case DW_CFA_restore_extended:
                regnum = decodeULEB((char **)&data);
                HALO_TRACE_FUNCTION(traceLevel, "DW_CFA_restore_extended regnum %#x\n", regnum);
                break;

            case DW_CFA_undefined:
                regnum = decodeULEB((char **)&data);
                HALO_TRACE_FUNCTION(traceLevel, "DW_CFA_undefined regnum %#x\n", regnum);
                break;

            case DW_CFA_same_value:
                regnum = decodeULEB((char **)&data);
                HALO_TRACE_FUNCTION(traceLevel, "DW_CFA_same_value regnum %#x\n", regnum);
                break;

            case DW_CFA_register:
                regnum = decodeULEB((char **)&data);
                regnum1 = decodeULEB((char **)&data);
                HALO_TRACE_FUNCTION(traceLevel, "DW_CFA_register regnum %#x regnum1 %#x\n", regnum, regnum1);
                break;

            case DW_CFA_def_cfa:
                regnum = decodeULEB((char **)&data);
                offset = decodeULEB((char **)&data);
                HALO_TRACE_FUNCTION(traceLevel, "DW_CFA_def_cfa regnum %#x offset %#" PRIx64 "\n",
                                    regnum, offset);
                break;

            case DW_CFA_val_expression:
                regnum = decodeULEB((char **)&data);
                length = decodeULEB((char **)&data);
                HALO_TRACE_FUNCTION(traceLevel, "DW_CFA_val_expression regnum %#x length %#" PRIx64 "\n",
                                    regnum, length);
                haloTraceDWFormBlock(data, length);
                data += length;
                break;

            default:
                HALO_TRACE_FUNCTION(traceLevel, "unknown opcode 0x%02x\n", opcode);
                return;
            }
            break;

        default:
            HALO_TRACE_FUNCTION(traceLevel, "unknown masked opcode 0x%02x\n", opcode);
            return;
        }
    }
}

static void
haloTraceDebugFrame(CudbgDevice dev, DwarfDebugFrame *dbg_frame)
{
    DwarfCIE *cie;
    DwarfFDE *fde;
    tRangeMapItr *itrCIE;
    tRangeMapItr *itrFDE;
    uint32_t traceLevel = 50;

    if (!dbg_frame->initialized)
        return;

    for (itrCIE = toolsRangeMapGetIterator(dbg_frame->pcTocie);
         itrCIE;
         itrCIE = toolsRangeMapGetNext(dbg_frame->pcTocie, itrCIE)) {         

        cie = (DwarfCIE *)toolsRangeMapGetEntry(itrCIE);

        HALO_TRACE_FUNCTION(traceLevel, "CIE\n");
        HALO_TRACE_FUNCTION(traceLevel, "return_address_column 0x%08x\n", cie->return_address_column);
        HALO_TRACE_FUNCTION(traceLevel, "initial_location      %#" PRIx64 "\n", cie->initial_location);
        HALO_TRACE_FUNCTION(traceLevel, "end_location          %#" PRIx64 "\n", cie->end_location);
        HALO_TRACE_FUNCTION(traceLevel, "initial bytes         %#" PRIx64 "\n", cie->end - cie->initial_instructions);

        haloTraceCFAInsns(cie, (uint8_t *)cie->initial_instructions, (uint8_t *)cie->end);

        for (itrFDE = toolsRangeMapGetIterator(cie->pcTofde);
             itrFDE;
             itrFDE = toolsRangeMapGetNext(cie->pcTofde, itrFDE)) {

            fde = (DwarfFDE *)toolsRangeMapGetEntry(itrFDE);

            HALO_TRACE_FUNCTION(traceLevel, "FDE\n");
            HALO_TRACE_FUNCTION(traceLevel, "initial_location %#" PRIx64 "\n", fde->initial_location);
            HALO_TRACE_FUNCTION(traceLevel, "address_range    %#" PRIx64 "\n", fde->address_range);
            HALO_TRACE_FUNCTION(traceLevel, "end_location     %#" PRIx64 "\n",
                                fde->initial_location + fde->address_range);

            haloTraceCFAInsns(cie, (uint8_t *)fde->instructions, (uint8_t *)fde->end);
        }
    }
}
#endif

static CUDBGResult
getFrameState(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln, uint64_t pc, int32_t prev_cfa_offset,
              DwarfFrameState *frame, DeviceFunction *out_function)
{
    CUDBGResult res = CUDBG_SUCCESS;
    TOOLSresult tres = TOOLS_SUCCESS;
    DebugPatch patch = NULL;
    DeviceFunction function = NULL;
    DwarfDebugFrame *dbg_frame = NULL;
    uint64_t host_pc = 0;
    uint32_t sp = 0, user_sp = 0;
    int32_t sp_diff = 0;
    bool inSyscall = false;

    CUDBG_VERIFY(dev && dev->activeContext && frame, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    toolsDestroyElfFrameRegMap(frame);
    if (out_function)
        *out_function = NULL;

    function = (DeviceFunction)toolsRangeMapLookupByAddr(dev->activeContext->gpuAddrToFunction, pc);
    if (function) {
        HALO_TRACE_FUNCTION(50, "vsm%d/wp%d/ln%d function %s pc = %#" PRIx64 "\n",
                            vsm, wp, ln, function->name, pc);
        HALO_TRACE_FUNCTION(50, "function %s at gpuAddr = %#" PRIx64 " virtAddr = %#" PRIx64 "\n",
                            function->name, function->gpuAddrBase, function->virtAddrBase);

        dbg_frame = &function->module->debugFrame;
        if (out_function)
            *out_function = function;

        /* Lazy init */
        if (!dbg_frame->initialized) {
            HALO_TRACE_FUNCTION(50, "function %s getting .debug_frame data\n", function->name);
            tres = toolsGetDebugFrame(function->module->relocatedElfImage,  dbg_frame);
            if (tres != TOOLS_ERROR_SECTION_NOT_FOUND && tres != TOOLS_SUCCESS) {
                HALO_ERROR("Error parsing .debug_frame!\n");
                return CUDBG_ERROR_INTERNAL;
            }
#if !defined(RELEASE)
            /* Dump CIE/FDE info after initialization */
            if (CUDBG_TRACE_LEVEL >= 50 && dbg_frame->initialized)
                haloTraceDebugFrame(dev, dbg_frame);
#endif
        }

        /* If dbg_frame was found, grab the state from there, DONE */
        if (dbg_frame->initialized) {
            host_pc = (pc - function->gpuAddrBase) + function->virtAddrBase;
            tres = toolsGetFrameState(dbg_frame, host_pc, frame);
            if (tres == TOOLS_SUCCESS) {
                /* fast path: successfully picked up the .debug_frame */
                HALO_TRACE_FUNCTION(50, "function %s .debug_frame found for pc = %#" PRIx64 " host_pc = %#" PRIx64 "\n",
                                    function->name, pc, host_pc);
                return CUDBG_SUCCESS;
            }
            else if (!cuosBuildIsRelease() &&
                     (haloGlobals.initData.flags & 
                      HALO_INIT_FLAGS_ERROR_ON_MISSING_DEBUG_FRAME)) {
                HALO_ERROR("Failed to get frame state for %s:pc=0x%" PRIx64 "\n",
                           function->name, (pc - function->gpuAddrBase));
                return CUDBG_ERROR_INTERNAL;
            }
        }
    }

    /* Otherwise, we might be in a patch with no .debug_frame.  Check and handle it */
    patch = (DebugPatch)toolsRangeMapLookupByAddr(dev->activeContext->gpuAddrToPatch, pc);
    if (!patch) {
        /* Bug 1867238 note: this error is usually encountered when the previous call to getFrameState
           attempts to unwind out of a patch (via Case 1 below) and returns an invalid PC. */
        HALO_ERROR("Warning: unable to unwind the stack; pc=%#" PRIx64 " func=%s patch=NULL\n",
                    pc, (function && function->name) ? function->name : "NULL");
        return CUDBG_ERROR_INTERNAL;
    }
    /* There are three cases for dealing with a patch without a .debug_frame
       in unwinding. The end goal is to specify R1, R20, R21, and the CFA in a
       way that will properly point to the user frame and hopefully get us out
       of any patches:
        Case 1: system stack switch has completed
        Case 2: system stack switch has not completed, but the patch has been called into
        Case 3: system stack switch has not completed, but the patch was inserted (memcheck)
    */
    res = dev->halo.readRegisterRange(dev, vsm, wp, ln, dev->halo.deviceInfo.spRegisterNumber, &sp, 1, true);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "failed to get current stack pointer!\n");
    if (sp <= dev->halo.deviceInfo.systemStackPointer && sp > (dev->halo.deviceInfo.systemStackPointer - dev->activeContext->syscallStackSz)) {
        /* Case 1: system stack switch has completed
           cfa_offset = R1 - THREAD_STATE_POINTER;
           CFA = R1 + syscall_frame_size
           R1 = cfa - 12
           R20 = cfa - 8
           R21 = cfa - 4 */

        HALO_TRACE_FUNCTION(40, "system stack switch completed: pc=0x%" PRIx64
                            " sp=0x%08x systemStackPointer=0x%08x syscallStackSz=0x%08x\n",
                            pc, sp,
                            dev->halo.deviceInfo.systemStackPointer,
                            dev->activeContext->syscallStackSz);

        res = dev->halo.findSyscallSP(dev, vsm, wp, ln, &inSyscall, &user_sp);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get the user stack pointer for vsm%d/wp%d/ln%d\n", vsm, wp, ln);
        /* This is the difference between the user sp and the syscall sp, which
           is used as the "frame size" for this frame (accounting for the previous cfa offset).
           With the next updateFrame(), we can still utilize the true R1 and get the right
           value. */
        sp_diff = user_sp - (sp + prev_cfa_offset);
        HALO_TRACE_FUNCTION(40, "vsm%d/wp%d/ln%d system stack switch completed pc=0x%" PRIx64
                            " sp=0x%08x user_sp=0x%08x sp_diff=%d inSyscall=%d\n",
                            vsm, wp, ln, pc, sp, user_sp, sp_diff, inSyscall);
        tres = toolsSetFrameCFA(frame, REG_CLASS_ENCODE(dev->halo.deviceInfo.spRegisterNumber, REG_CLASS_REG_FULL), sp_diff);
        frame->return_address_column = REG_CLASS_ENCODE(dev->halo.deviceInfo.rpcRegisterNumber, REG_CLASS_REG_FULL);
        tres = toolsSetFrameReg(frame,
                                REG_CLASS_ENCODE(dev->halo.deviceInfo.rpcRegisterNumber + 1, REG_CLASS_REG_FULL),
                                REG_CLASS_ENCODE(dev->halo.deviceInfo.spRegisterNumber, REG_CLASS_REG_FULL),
                                12 - sp_diff, DWARF_FRAME_REG_OFFSET);
        tres = toolsSetFrameReg(frame,
                                REG_CLASS_ENCODE(dev->halo.deviceInfo.rpcRegisterNumber, REG_CLASS_REG_FULL),
                                REG_CLASS_ENCODE(dev->halo.deviceInfo.spRegisterNumber, REG_CLASS_REG_FULL),
                                8 - sp_diff, DWARF_FRAME_REG_OFFSET);
        tres = toolsSetFrameReg(frame,
                                REG_CLASS_ENCODE(dev->halo.deviceInfo.spRegisterNumber, REG_CLASS_REG_FULL),
                                REG_CLASS_ENCODE(dev->halo.deviceInfo.spRegisterNumber, REG_CLASS_REG_FULL),
                                4 - sp_diff, DWARF_FRAME_REG_OFFSET);
    }
    else if (patch->multiEntry) {
        /* Case 2: system stack switch has not completed, but assume the patch
           has been called into (multiEntry assumption), so follow
           the ABI with no frame modifications yet.
           CFA = R1 + 0
           R1 = R1
           R20 = R20
           R21 = R21 */

        HALO_TRACE_FUNCTION(40, "system stack switch not completed, multiEntry pc=0x%" PRIx64 "\n", pc);

        tres = toolsSetFrameCFA(frame, REG_CLASS_ENCODE(dev->halo.deviceInfo.spRegisterNumber, REG_CLASS_REG_FULL), 0);
        frame->return_address_column = REG_CLASS_ENCODE(dev->halo.deviceInfo.rpcRegisterNumber, REG_CLASS_REG_FULL);
        tres = toolsSetFrameReg(frame,
                                REG_CLASS_ENCODE(dev->halo.deviceInfo.spRegisterNumber, REG_CLASS_REG_FULL),
                                0,
                                0, DWARF_FRAME_REG_SAME);
        tres = toolsSetFrameReg(frame,
                                REG_CLASS_ENCODE(dev->halo.deviceInfo.rpcRegisterNumber, REG_CLASS_REG_FULL),
                                REG_CLASS_ENCODE(dev->halo.deviceInfo.rpcRegisterNumber, REG_CLASS_REG_FULL),
                                0, DWARF_FRAME_REG_REG); 
        tres = toolsSetFrameReg(frame,
                                REG_CLASS_ENCODE(dev->halo.deviceInfo.rpcRegisterNumber+1, REG_CLASS_REG_FULL),
                                REG_CLASS_ENCODE(dev->halo.deviceInfo.rpcRegisterNumber+1, REG_CLASS_REG_FULL),
                                0, DWARF_FRAME_REG_REG); 
    }
    else {
        /* Case 3: system stack switch has not completed, but the patch was
           inserted (memcheck).  Here, the return address for the patch is only
           known via a static reloc or recorded in the patch structure and not
           anywhere device accessible, so set the value directly for RPC, and
           give a zero frame size (spills are not on a stack, but reserved lmem)
           CFA  = R1 + 0
           R1   = S
           RA   = patchEntry_lo
           RA+1 = patchEntry_hi */

        HALO_TRACE_FUNCTION(40, "system stack switch not completed, patch inserted pc=0x%" PRIx64
                            " entryAddr=0x%" PRIx64 "\n", pc, patch->entryAddr);

        tres = toolsSetFrameCFA(frame, REG_CLASS_ENCODE(dev->halo.deviceInfo.spRegisterNumber, REG_CLASS_REG_FULL), 0);
        frame->return_address_column = VOLTA_FAKE_RPC_LO;
        tres = toolsSetFrameReg(frame,
                                REG_CLASS_ENCODE(dev->halo.deviceInfo.spRegisterNumber, REG_CLASS_REG_FULL),
                                0,
                                0, DWARF_FRAME_REG_SAME);
        tres = toolsSetFrameReg(frame,
                                VOLTA_FAKE_RPC_LO,
                                0,
                                (uint32_t)(patch->entryAddr), DWARF_FRAME_REG_VALUE);
        tres = toolsSetFrameReg(frame,
                                VOLTA_FAKE_RPC_HI,
                                0,
                                (uint32_t)(patch->entryAddr >> 32), DWARF_FRAME_REG_VALUE);
    }
    return res;
}

/* Callback signature.  The unwinder calls functions of the following shape.
 * The 'data' formal parameter is a pointer passed to be optionally manipulated
 * by the callback.
 *
 * 'stop_unwind:' The callback will set this flag.  If true, the unwinder will
 *                not unwind any further and return immediately.
 *
 * The callback is handed the CFA and the return pc for that CFA.
 */
typedef CUDBGResult (*UnwindCallback)(CudbgDevice dev, DwarfFrameState *frame, uint64_t pc, uint64_t ret_pc,
                                      void *data, bool *stop_unwind);

/* Stack unwind function iterator.
 *
 * This takes a debug frame object as input, the number of frames to unwind, and
 * a callback function 'cb'.
 *
 * 'cb' is a callback function, called for each frame unwound. cb will be called
 * 'levels' numbers of times.
 *
 * 'data' is passed by the caller and is for the 'cb' to utilize.
 * It is the receiver of data who must know the size of the store behind 'data'.
 */
static CUDBGResult
unwindItr(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
          uint32_t levels, UnwindCallback cb, void *data)
{
    CUDBGResult cres = CUDBG_SUCCESS;
    TOOLSresult tres;
    DwarfFrameState frame = {0}, next_frame = {0};
    DeviceFunction function = NULL;
    uint32_t level, lo, hi;
    uint64_t ret_pc, pc;
    bool stop_unwind;
    uint32_t patchDepth = 0;
    bool inPatch = false;
    uint32_t last_cfa_offset = 0;
    bool hidden;

    CUDBG_VERIFY(dev && dev->activeContext, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    /* Initial PC for lane */
    if (dev->smState[vsm].warp[wp].activeMask & (1U << ln))
        cres = dev->halo.readPC(dev, vsm, wp, &pc);
    else
        cres = dev->halo.findDivergedCRS_PC(dev, vsm, wp, ln, &pc);
    CUDBG_VERIFY(cres == CUDBG_SUCCESS, cres, "readPC failed (res=%d)\n", cres);
    HALO_TRACE_FUNCTION(10, "vsm%d/wp%d/ln%d levels = %d pc = %#" PRIx64 " (%s)\n",
                        vsm, wp, ln, levels, pc,
                        (dev->smState[vsm].warp[wp].activeMask & (1U << ln)) ? "active" : "diverged");

    /* Following call updates pc to MEMBAR entry address */
    cres = dev->halo.checkForHwWar(dev, vsm, wp, ln, &inPatch, &pc,
                                      &patchDepth);
    CUDBG_VERIFY(cres == CUDBG_SUCCESS, cres,
                 "checkForHwWar failed (res=%d)\n", cres);

    cres = getFrameState(dev, vsm, wp, ln, pc, 0, &frame, &function);
    if (cres != CUDBG_SUCCESS) {
        HALO_TRACE_FUNCTION(10, "Couldn't get the frame information for "
                                "vsm%d/wp%d/ln%d's pc=%#" PRIx64 " lvl=0.  Stopping...\n",
                                vsm, wp, ln, pc);
#if !defined(RELEASE)
        if (haloGlobals.initData.flags & HALO_INIT_FLAGS_ERROR_ON_MISSING_DEBUG_FRAME)
            return CUDBG_ERROR_INTERNAL;
#endif
        return CUDBG_SUCCESS;
    }

    /* Unwind */
    stop_unwind = false;
    for (level = 0; level < levels; ++level) {
        HALO_TRACE_FUNCTION(50, "vsm%d/wp%d/ln%d level = %d function %s return_address_column=%#x"
                            " cfa.reg 0x%08x cfa.offset 0x%08x last_cfa_offset 0x%08x\n",
                            vsm, wp, ln, level,
                            function ? function->name : "NULL",
                            frame.return_address_column,
                            frame.cfa.reg ? frame.cfa.reg->regnum : ~0,
                            frame.cfa.offset,
                            last_cfa_offset);

        if (function) {
            cres = haloInHiddenFunction(function, &hidden);
            CUDBG_VERIFY(cres == CUDBG_SUCCESS, cres, "error calling haloInHiddenFunction\n");
        }
        else
            hidden = false;

        if (hidden) {
            HALO_TRACE_FUNCTION(49, "stopping unwind due to hidden function %s\n", function->name);
            cres = CUDBG_SUCCESS;
            goto done;
        }
        else if (function && function->type == DEV_FUNC_TYPE_GLOBAL) {
            /*
             * Bug 1867238: stop unwinding when we reach a global function.
             * Why: sometimes we get a nonzero ret_pc from .debug_frame even though we're in the outermost frame.
             */
            HALO_TRACE_FUNCTION(49, "stopping unwind due to global function\n");
            ret_pc = 0;
        }
        else {
            /* ABI: Get the return register values */ 
            cres = getRegData(dev, vsm, wp, ln, &frame, frame.return_address_column, &lo);
            if (cres != CUDBG_SUCCESS)
                goto done;

            cres = getRegData(dev, vsm, wp, ln, &frame, frame.return_address_column+1, &hi);
            if (cres != CUDBG_SUCCESS)
                goto done;

            /* The return address to the caller */
            ret_pc = ((uint64_t)hi << 32) | lo;
        }
        HALO_TRACE_FUNCTION(50, "vsm%d/wp%d/ln%d level = %d ret_pc = %#" PRIx64 "\n", vsm, wp, ln, level, ret_pc);

        /* Callback */
        cres = cb(dev, &frame, pc, ret_pc, data, &stop_unwind);
        if (stop_unwind || cres != CUDBG_SUCCESS)
            goto done;

        if (ret_pc == 0) {
            HALO_TRACE_FUNCTION(10, "ret_pc = 0, we've hit the top of the stack: (pc=%#" PRIx64 ")\n", pc);
            goto done;
        }

        cres = getFrameState(dev, vsm, wp, ln, ret_pc, frame.cfa.offset, &next_frame, &function);
        if (cres != CUDBG_SUCCESS) {
            HALO_TRACE_FUNCTION(10, "%u/%u/%u/%u failed to get the frame information for "
                                "ret_pc=0x%" PRIx64 " stopping unwind\n",
                                dev->deviceIdx, vsm, wp, ln, ret_pc);
            if ((!cuosBuildIsRelease()) && (haloGlobals.initData.flags & HALO_INIT_FLAGS_ERROR_ON_MISSING_DEBUG_FRAME))
                cres = CUDBG_ERROR_INTERNAL;
            else
                cres = CUDBG_SUCCESS;
            goto done;
        }

        tres = toolsUpdateDwarfFrameState(&next_frame, &frame);
        /* Can't debug Volta without frame information */
        if (tres != TOOLS_SUCCESS) {
            if (frame.cfa.reg->regnum != next_frame.cfa.reg->regnum) {
                HALO_TRACE(49, "error switching CFA reg 0x%08x -> 0x%08x\n",
                           frame.cfa.reg->regnum,
                           next_frame.cfa.reg->regnum);
            }
            HALO_ERROR("Error updating CFA, terminating unwind.\n");
            cres = CUDBG_ERROR_INTERNAL;
            goto done;
        }

        if (level > 1 && pc == ret_pc && frame.cfa.offset == last_cfa_offset) {
            HALO_ERROR("vsm%d/wp%d/ln%d pc == ret_pc 0x%" PRIx64 " && cfa == last_cfa_offset 0x%" PRIx64 " exiting unwind\n",
                       vsm, wp, ln, pc, frame.cfa.offset);
            cres = CUDBG_ERROR_INTERNAL;
            goto done;
        }
        last_cfa_offset = frame.cfa.offset;

        pc = ret_pc;
    }

done:
    /* clean up frame - TODO: move to tools later */
    if (frame.regs)
        toolsDestroyElfFrameRegMap(&frame);
    if (next_frame.regs)
        toolsDestroyElfFrameRegMap(&next_frame);

    HALO_TRACE_FUNCTION(50, "vsm%d/wp%d/ln%d done\n", vsm, wp, ln);

    return cres;
}
 
static CUDBGResult
volta_gv10x_readPC(CudbgDevice dev, uint32_t vsm, uint32_t tid, uint64_t *pc)
{
    CUDBGResult res;

    res = dev->halo.scratchpad.read_warpTrapRPC(dev->activeContext->scratchpadAccessor, vsm, tid, pc);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read warp PC\n");

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_writePC(CudbgDevice dev, uint32_t vsm, uint32_t tid, uint64_t pc)
{
    CUDBGResult res;

    // Update the PC in scratchpad and preemption buffer. This is to make sure
    // that we read the correct PC from volta_gv10x_readPC call which uses
    // scratchpad to read this value.
    res = dev->halo.scratchpad.write_warpTrapRPC(dev->activeContext->scratchpadAccessor, vsm, tid, pc);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to write warp trap RPC\n");

    res = dev->halo.preemptionBuffer.write_warpTrapRPC(dev->activeContext->preemptionBufferAccessor, vsm, tid, pc);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to write warp trap RPC\n");

    dev->activeContext->saveBufferState = HALO_SAVE_BUFFER_STATE_DIRTY;
    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_readActiveMask(CudbgDevice dev, uint32_t vsm, uint32_t tid, uint32_t *mask)
{
    CUDBGResult res = CUDBG_SUCCESS;

    res = dev->halo.scratchpad.read_warpActiveMask(dev->activeContext->scratchpadAccessor, vsm, tid, mask);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read warp active mask\n");

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_adjustActiveMask(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                             uint32_t *warpActiveMask)
{
    /* Not needed for Volta(?) */
    return CUDBG_SUCCESS;
}

static CUDBGResult
readCallDepthCB(CudbgDevice dev, DwarfFrameState *cfa, uint64_t pc, uint64_t ret_pc,
                       void *data, bool *stop_unwind)
{
    uint32_t *count = (uint32_t*)data;
    CUDBG_VERIFY(count, CUDBG_ERROR_INVALID_ARGS, "No depth pointer specified\n");
    HALO_TRACE_FUNCTION(50, "pc=%" PRIx64 " ret_pc=%" PRIx64 "\n", pc, ret_pc);
    /* Count the number of frames in the call stack */
    (*count)++;
    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_readCallDepth(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                          uint32_t *depth)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(depth, CUDBG_ERROR_INVALID_ARGS, "No depth argument supplied\n");

    /* unwindItr is very expensive, so cache it whenever possible */
    if (dev->smState[vsm].warp[wp].callDepthValid[ln]) {
        *depth = dev->smState[vsm].warp[wp].callDepth[ln];
        return CUDBG_SUCCESS;
    }

    /* CBU "api_call_depth" is what is queried here and is defined by the IAS:
     * "The number of call tokens in the stack."
     */
    *depth = 0;
    res = unwindItr(dev, vsm, wp, ln, VOLTA_UNWIND_MAX_LEVELS, readCallDepthCB, depth);
    /* depth at this is point is the number of frames in the call-stack.
       Subtract one for the number of calls */
    if (*depth)
        (*depth)--;

    dev->smState[vsm].warp[wp].callDepthValid[ln] = true;
    dev->smState[vsm].warp[wp].callDepth[ln] = *depth;

    HALO_TRACE_FUNCTION(49, "vsm%d/wp%d/ln%d depth=%d res=%d\n", vsm, wp, ln, *depth, res);

    return res;
}

/* SyscallCallDepth unwinder callback:  Multiple items need to be returned, so
 * we pass a struct for data.
 */
typedef struct SyscallCBData_st
{
    uint32_t depth;
    uint32_t has_debug_patch;
    uint32_t in_syscall;
} SyscallCBData;

static CUDBGResult
readSyscallCallDepthCB(CudbgDevice dev, DwarfFrameState *cfa, uint64_t pc, uint64_t ret_pc,
                       void *data, bool *stop_unwind)
{
    CUDBGResult res;
    bool in_syscall;
    DebugPatch patch;
    SyscallCBData *cbd = (SyscallCBData *)data;

    CUDBG_VERIFY(data, CUDBG_ERROR_INVALID_ARGS, "No data pointer specified\n");
   
    patch = NULL; 
    res = dev->haloClient->inSyscallPatch(dev, ret_pc, &patch, &in_syscall);
    if (res != CUDBG_SUCCESS)
        return res;
    
    cbd->in_syscall = in_syscall;
    cbd->has_debug_patch = (patch && patch->debug);

    /* Valid call */
    ++cbd->depth;

    /* Exit condition, this is no longer in a syscall region. */
    if (!in_syscall)
        *stop_unwind = true;

    HALO_TRACE_FUNCTION(50, "pc=%" PRIx64 " ret_pc=%" PRIx64 " in_syscall=%d\n", pc, ret_pc, (int)in_syscall);

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_readSyscallCallDepth(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t *depth)
{
    bool in_syscall;
    DebugPatch patch;
    CUDBGResult res;
    uint64_t pc;
    SyscallCBData cbd = {0};

    CUDBG_VERIFY(depth, CUDBG_ERROR_INVALID_ARGS, "Invalid depth argument\n");
    *depth = 0;

    /* unwindItr is very expensive, so cache it whenever possible */
    if (dev->smState[vsm].warp[wp].syscallCallDepthValid[ln]) {
        *depth = dev->smState[vsm].warp[wp].syscallCallDepth[ln];
        return CUDBG_SUCCESS;
    }
    
    /* Initial PC for lane */
    if (dev->smState[vsm].warp[wp].activeMask & (1U << ln)) {
        res = dev->halo.readPC(dev, vsm, wp, &pc);
    }
    else {
        res = dev->halo.findDivergedCRS_PC(dev, vsm, wp, ln, &pc);
    }

    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "readPC failed (res=%d)\n", res);

    /* If the pc isn't within a syscall, the depth is zero */
    patch = NULL;
    res = dev->haloClient->inSyscallPatch(dev, pc, &patch, &in_syscall);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to inSyscallPatch failed\n");
        return res;
    }

    /* If the pc isn't within a syscall, the depth is zero (already set to 0) */

    if (in_syscall) {
        /* Unwind and count */
        res = unwindItr(dev, vsm, wp, ln, VOLTA_UNWIND_MAX_LEVELS,
                        readSyscallCallDepthCB, (void *)&cbd);
        if (res != CUDBG_SUCCESS)
            return res;

        /* If we are in a syscall but have a patch: Implies that we have syscalls
         * without any jump from user code.
         */
        if (cbd.in_syscall && cbd.has_debug_patch)
            *depth = 0;
        else
            *depth = cbd.depth;
    }
    
    /* place result into cache */

    dev->smState[vsm].warp[wp].syscallCallDepth[ln] = *depth;
    dev->smState[vsm].warp[wp].syscallCallDepthValid[ln] = true;

    return CUDBG_SUCCESS;
}

/* Unwinder callback for readReturnAddress.
 * The unwinder already keeps track of the 'return pc' so just pass that through
 */
static CUDBGResult
readReturnAddrCB(CudbgDevice dev, DwarfFrameState *cfa, uint64_t pc, uint64_t ret_pc,
                 void *data, bool *stop_unwind)
{
    CUDBG_VERIFY(data, CUDBG_ERROR_INVALID_ARGS, "No data pointer specified");
    HALO_TRACE_FUNCTION(50, "pc=%" PRIx64 " ret_pc=%" PRIx64 "\n", pc, ret_pc);
    *(uint64_t *)data = ret_pc;
    return CUDBG_SUCCESS;
}

/* From the ABI doc:
 * Return address is either:
 * 1) Absolute: 50 bit return address, no offset used.
 * 2) Relative: Return address registers store the return offset from the
 * start of the program (PROG_REL).
 *
 * Volta: R20, R21 are the return address registers using ABI semantics.
 */
static CUDBGResult
volta_gv10x_readReturnAddress(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                              uint32_t level, uint64_t *ra)
{
    CUDBG_VERIFY(ra, CUDBG_ERROR_INVALID_ARGS, "Invalid ra argument\n");
    
    /* unwind wants the count of levels to unravel, level '0' is valid */
    return unwindItr(dev, vsm, wp, ln, level + 1, readReturnAddrCB, ra);
}

static CUDBGResult
volta_gv10x_findSyscallEntryPoint(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln, uint64_t *entryPc)
{
    CUDBGResult res = CUDBG_SUCCESS;
    DebugPatch patch = NULL;
    uint64_t pc = 0;
    uint32_t sp = 0;
#ifndef RELEASE
    bool inSyscall = false;
#endif

    CUDBG_VERIFY(entryPc && dev && dev->activeContext, CUDBG_ERROR_INVALID_ARGS, "Invalid entryPc argument\n");
    *entryPc = 0;

    if (dev->smState[vsm].warp[wp].activeMask & (1U << ln))
        res = dev->halo.readPC(dev, vsm, wp, &pc);
    else
        res = dev->halo.findDivergedCRS_PC(dev, vsm, wp, ln, &pc);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, CUDBG_ERROR_UNKNOWN, "Unable to find pc\n");

#ifndef RELEASE
    res = dev->haloClient->inSyscallPatch(dev, pc, &patch, &inSyscall);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, CUDBG_ERROR_UNKNOWN, "Call in inSyscallPatch failed\n");

    if (!inSyscall)
        return CUDBG_ERROR_LANE_NOT_IN_SYSCALL;
#endif

    res = dev->halo.readRegisterRange(dev, vsm, wp, ln, dev->halo.deviceInfo.spRegisterNumber, &sp, 1, true);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "failed to get current stack pointer!\n");

    /* The system stack has not been setup, so debugger must assume that the rpc
       spill has not completed and that the ABI R20,R21 hold the return pc
       for this patch.  Because we've already confirmed that we're in a
       syscall, and the contract is that only ABI can call ABI (and thus
       syscalls) we can infer that the callee is ABI compliant and R20,R21
       hold the return PC */
    if (sp <= dev->halo.deviceInfo.systemStackPointer && sp > (dev->halo.deviceInfo.systemStackPointer - dev->activeContext->syscallStackSz)) {
        /* Read the system stack for the stashed value of the user return pc */
        res = dev->halo.readLocalMemory(dev, vsm, wp, ln, dev->halo.deviceInfo.lmemSavedReturnPC, entryPc, sizeof(*entryPc));
        HALO_TRACE_FUNCTION(40, "vsm%d/wp%d/ln%d pc = %#" PRIx64 " sp = 0x%08x entryPc = %#" PRIx64 " (lmem)\n",
                            vsm, wp, ln, pc, sp, *entryPc);
    }
    else {
        /* R20,R21 is valid, use it */
        res = dev->halo.readRegisterRange(dev, vsm, wp, ln, dev->halo.deviceInfo.rpcRegisterNumber, (uint32_t *)entryPc, 2, false);
        HALO_TRACE_FUNCTION(40, "vsm%d/wp%d/ln%d pc = %#" PRIx64 " sp = 0x%08x entryPc = %#" PRIx64 " (R20/R21)\n",
                            vsm, wp, ln, pc, sp, *entryPc);
    }

    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to read return pc from system stack for vsm%d/wp%d/ln%d @pc=%#" PRIx64 "\n",
                 vsm, wp, ln, *entryPc);

    return res;
}

static CUDBGResult
volta_gv10x_insertBreakpoint(Context context, uint64_t vaddr, BreakpointContents *buf)
{
    CUDBGResult res = CUDBG_SUCCESS;
    /* BPT.TRAP 0x1 ?WAIT15_END_GROUP_NO_SB; */
    const uint64_t voltaSafeBreak[2] = { GV10X_INST_BPT_WAIT_LO_ALL(GV10X_KEYWORD_PREDICATE_PT, VOLTA_GV10X_TRAP_IMMEDIATE_BREAKPOINT),
                                         GV10X_INST_BPT_WAIT_HI_ALL(GV10X_KEYWORD_BPTMODE_TRAP, 0x0) | VOLTA_SAFE_OPEX_HI };
    CudbgDevice dev = NULL;
    
    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");
    
    dev = context->dev;

    if (!CUDBG_DEBUG_OBJECT_IS_VALID(context->debugObj)) {
        /* This can happen if no ctx creation callback has been received yet
           during early stages of the app, or during shutdown. */
        HALO_TRACE_FUNCTION(50, "No debug object found, skipping breakpoint insertion.\n");
        return CUDBG_ERROR_INVALID_CONTEXT;
    }

    res = context->dev->halo.readDeviceMemory(context, vaddr, buf->savedInstruction, sizeof (buf->savedInstruction));
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Error reading code mem at addr %" PRIx64 " (res = %d)\n", vaddr, res);

    buf->savedInstructionSize = sizeof(buf->savedInstruction);

    res = dev->halo.writeDeviceMemory(context, vaddr, voltaSafeBreak, sizeof(voltaSafeBreak));
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Error writing code mem at addr %" PRIx64 " (res = %d)\n", vaddr, res);

    dev->codeIsDirty = 1;

    HALO_TRACE_FUNCTION(1, "Breakpoint inserted at 0x%" PRIx64 ". Original instruction was 0x%016" PRIx64 " 0x%016" PRIx64 "\n",
                        vaddr, buf->savedInstruction[0], buf->savedInstruction[1]);

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_removeBreakpoint(Context context, uint64_t vaddr, const BreakpointContents *buf)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CudbgDevice dev = NULL;

    CUDBG_VERIFY(buf->savedInstructionSize > 0 && context, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    dev = context->dev;

    res = dev->halo.writeDeviceMemory(context, vaddr, buf->savedInstruction, buf->savedInstructionSize);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Error writing code mem at addr %" PRIx64 " (res = %d)\n", vaddr, res);

    dev->codeIsDirty = 1;

    HALO_TRACE_FUNCTION(1, "Breakpoint removed at 0x%" PRIx64 ". Original instruction was 0x%016" PRIx64 " 0x%016" PRIx64 "\n",
                        vaddr, buf->savedInstruction[0], buf->savedInstruction[1]);

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_getWarpCRSUsage(CudbgDevice dev, uint32_t vsm, uint32_t tid,
                            uint32_t *warpCRSNumEntries, uint32_t *warpCRSSize, bool *usingCRSPtr)
{
    HALO_ERROR("No CRS on GV10x\n");
    return CUDBG_ERROR_INTERNAL;
}

/* TODO: Clean CRS specific names */
static CUDBGResult
volta_gv10x_findDivergedCRS_Mask(CudbgDevice dev, uint32_t vsm, uint32_t tid,
                                 uint32_t *mask)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t activeMask, exitedMask;

    HALO_TRACE_FUNCTION(30, "No CRS on GV10x but we return the state from CBU.\n");

    CUDBG_VERIFY(mask, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    res = dev->halo.scratchpad.read_warpActiveMask(dev->activeContext->scratchpadAccessor, vsm, tid, &activeMask);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read warp active mask\n");

    res = dev->halo.readExitedMask(dev, vsm, tid, &exitedMask);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Error reading exited mask.vsm%d/wp%d\n", vsm, tid);

    /* From
       https://p4viewer.nvidia.com/get///hw/doc/gpu/volta/volta/design/IAS/SM/ISA/IAS_Volta_ISA.htm#Architecture_State__Convergence_Barriers_and_Scheduling
       With Volta, threads can be in one of the following states {ready,
       yielded, exited, blocked[0-14], blocked+, sleep}.
       TRAP_MASK is the set of threads in the warp that were live at the time of
       the of the trap (ready).
       MEXITED is the set of threads in the warp that personally exited.
       We're looking for all the states in between - those are considered
       'diverged'. */

    *mask = ~activeMask & ~exitedMask;
    HALO_TRACE_FUNCTION(30, "activeMask %#x exitedMask %#x mask %#x\n",
                        activeMask, exitedMask, *mask);

    return res;
}

/* TODO: Clean CRS specific names */
static CUDBGResult
volta_gv10x_findDivergedCRS_PC(CudbgDevice dev, uint32_t vsm, uint32_t tid,
                               uint32_t lane, uint64_t *pc)
{
    CUDBG_VERIFY(pc, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t activeMask, exitedMask;

    res = dev->halo.scratchpad.read_warpActiveMask(dev->activeContext->scratchpadAccessor, vsm, tid, &activeMask);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read warp active mask\n");

    res = dev->halo.readExitedMask(dev, vsm, tid, &exitedMask);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Error reading exited mask.vsm%d/wp%d\n", vsm, tid);

    // Return 0 PC if the lane is not in the active warp mask
    if((~activeMask & exitedMask) & (1U << lane)) {
        *pc = 0;
        return CUDBG_SUCCESS;
    }

    res = dev->halo.preemptionBuffer.read_RPC(dev->activeContext->preemptionBufferAccessor, vsm, tid, lane, pc);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read return PC\n");
    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_findDivergedCRS_Entry(CudbgDevice dev, uint32_t vsm, uint32_t tid,
                                  uint32_t lane, bool *res)
{
    HALO_ERROR("No CRS on GV10x\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
volta_gv10x_collectWarpCRS(CudbgDevice dev, uint32_t vsm, uint32_t tid)
{
    HALO_TRACE_FUNCTION(30, "No CRS on GV10x\n");
    /* Return success here as this path is still called in collectDeviceState */
    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_verifyCRSxsum(HaloCRS_t *warpCRS, uint32_t idx)
{
    HALO_ERROR("No CRS on GV10x\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
volta_gv10x_flattenCRS(CudbgDevice dev, uint32_t vsm, uint32_t tid, unsigned char *flatCRS)
{
    HALO_ERROR("No CRS on GV10x\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
volta_gv10x_updateCRS(CudbgDevice dev, uint32_t vsm, uint32_t tid,
                      unsigned char *flatCRS, uint32_t trapIdx)
{
    HALO_ERROR("No CRS on GV10x\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
volta_gv10x_maxCRSEntriesPerWarp(CudbgDevice dev, uint32_t vsm, uint32_t tid, uint32_t *numEntries)
{
    HALO_ERROR("No CRS on GV10x\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
volta_gv10x_cleanup(CudbgDevice dev)
{
    /* Nothing to do here */
    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_clearSMState(CudbgDevice dev)
{
    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_DEVICE, "Invalid device.\n");

    /* Clear the smState structures (invalidating them at the same time) */
    memset(dev->smState, 0, sizeof(*dev->smState)*dev->halo.deviceInfo.numSMs);

    return CUDBG_SUCCESS;
}


static int32_t
volta_gv10x_isCall(uint64_t inst[2])
{
    const uint64_t VOLTA_GV10x_CALL_OP_MASK = 0x1FFULL;
    const uint64_t VOLTA_GV10x_CALL_REL_OP  = 0x144ULL;
    const uint64_t VOLTA_GV10x_CALL_ABS_OP  = 0x143ULL;

    return (inst[0] & VOLTA_GV10x_CALL_OP_MASK) == VOLTA_GV10x_CALL_REL_OP ||
           (inst[0] & VOLTA_GV10x_CALL_OP_MASK) == VOLTA_GV10x_CALL_ABS_OP;
}

static int32_t
volta_gv10x_isBarrier(uint64_t inst[2])
{
    const uint64_t VOLTA_GV10x_BAR_OP_MASK      = 0x1FFULL;
    const uint64_t VOLTA_GV10x_BAR_OP           = 0x11DULL;
    const uint64_t VOLTA_GV10x_WARPSYNC_OP_MASK = 0x1FFULL;
    const uint64_t VOLTA_GV10x_WARPSYNC_OP      = 0x148ULL;

    return (inst[0] & VOLTA_GV10x_BAR_OP_MASK) == VOLTA_GV10x_BAR_OP ||
           (inst[0] & VOLTA_GV10x_WARPSYNC_OP_MASK) == VOLTA_GV10x_WARPSYNC_OP;
}

static int32_t
volta_gv10x_isExit(uint64_t inst[2])
{
    const uint64_t VOLTA_GV10x_EXIT_OP_MASK = 0xFFFULL;
    const uint64_t VOLTA_GV10x_EXIT_OP      = 0x94DULL;

    return (inst[0] & VOLTA_GV10x_EXIT_OP_MASK) == VOLTA_GV10x_EXIT_OP;
}

static int32_t
volta_gv10x_isRet(uint64_t inst[2])
{
    const uint64_t VOLTA_GV10x_RET_OP_MASK = 0xFFFULL;
    const uint64_t VOLTA_GV10x_RET_OP      = 0x950ULL;

    return (inst[0] & VOLTA_GV10x_RET_OP_MASK) == VOLTA_GV10x_RET_OP;
}

static int32_t
volta_gv10x_isContinuation(uint64_t inst[2])
{
    /* BPT.TRAP 0x2 */
    return (inst[0] & 0xFFFULL) == GV10X_OPCODE_BPT_WAIT && BF_GET(GV10X_FIELD_BITS_3_36_34_Sb_LO, inst[0]) == 0x2
            && BF_GET(GV10X_FIELD_BITS_3_86_84_cop_HI, inst[1]) == GV10X_KEYWORD_BPTMODE_TRAP;
}

static CUDBGResult
volta_gv10x_isInternalInstructionAtPC(CudbgDevice dev, uint64_t inst,
                                        uint64_t gpuAddr, bool *isInternalInstruction)
{
    CUDBG_VERIFY(dev && isInternalInstruction, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");
    *isInternalInstruction = false; /* no internal instructions on gv10x */
    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_isTerminalInstructionAtPC(Context ctx, uint64_t pc, bool *isExitingInstruction)
{
    uint64_t inst[2];
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(ctx && isExitingInstruction, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    res = ctx->dev->halo.readCodeMemory(ctx, pc, inst, sizeof inst);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Error reading pc %#" PRIx64 "\n", inst);

    *isExitingInstruction = volta_gv10x_isExit(inst) || volta_gv10x_isRet(inst);

    return res;
}

/* Returns true in *isSteppable if the instruction at PC can be stepped,
   false otherwise. If not steppable, *breakAddr will contain the PC
   address where to insert a breakpoint to step that instruction, and
   *breakMask will contain the mask of warps to resume (low bit means
   resume). Otherwise, *breakAddr and *breakMask are untouched. */
static CUDBGResult
volta_gv10x_isSteppable(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                          uint64_t pc, bool inPatch, uint64_t *breakAddr,
                          CUwarpBitmask *breakMask, bool *isSteppable,
                          bool *requiresExitStep)
{
    Grid grid;
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t inst[2] = {0x0ULL, 0x0ULL};
    bool isWarpOnBarrier = false;

    CUDBG_VERIFY((breakAddr && breakMask && isSteppable && requiresExitStep),
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments in isSteppable.\n");

    CUDBG_VERIFY((vsm < dev->halo.deviceInfo.numSMs), CUDBG_ERROR_INVALID_SM, "Invalid vsm in isSteppable.\n");

    CUDBG_VERIFY(warpBitmaskGetBits(&dev->smState[vsm].state.tidValid, wp, 1),
                 CUDBG_ERROR_INVALID_WARP,
                 "Invalid warp in isSteppable.\n");

    *breakAddr        = ~0U;
    warpBitmaskFill(breakMask, 1);
    *isSteppable      = true;
    *requiresExitStep = false;

    res = dev->halo.readCodeMemory(dev->activeContext, pc, inst, sizeof inst);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read memory from offset 0x%08x\n", pc);

    HALO_TRACE_FUNCTION(50, "Checking instruction 0x%08x: %#" PRIx64 " %#" PRIx64 "\n", pc, inst[0], inst[1]);

    /* GM10x/CNP:  We need to avoid step-resumes (more importantly, inserting
       a BPT.TRAP) while we are stepping through a region of code that is
       protected with IDE.DIS).  So, if this is the case, then always mark
       the instruction as being steppable (without actually checking the
       instruction itself). */
    if (dev->smState[vsm].state.inIDECS) {
        HALO_TRACE(2, "SM%d in IDE CS, all instructions considered steppable\n", vsm);
        *isSteppable = true;
        return CUDBG_SUCCESS;
    }

    grid = haloStateDeviceGetGrid(dev, dev->smState[vsm].warp[wp].gridId64);
    CUDBG_VERIFY(grid && grid->function && grid->function->module,
                 CUDBG_ERROR_INTERNAL,
                 "Invalid grid\n");

    if (grid->function->module->abiVersion < ELFOSABIV_ABI &&
        volta_gv10x_isCall(inst)) {
        HALO_TRACE(2, "  Found an unsteppable call at pc = %x\n", pc);
        warpBitmaskFill(breakMask, 1);
        warpBitmaskSetBits(breakMask, wp, 1, 0);

        *isSteppable = false;
        return CUDBG_SUCCESS;
    }

    /* Check if barrier */
    if (volta_gv10x_isBarrier(inst)) {
        uint32_t tmpWp;
        CudbgWarp_t *warpState = dev->smState[vsm].warp;
        HALO_TRACE(2, "  Found an unsteppable barrier at pc = %x\n", pc);
        /* Need to resume all warps in the same cta as this warp */
        warpBitmaskFill(breakMask, 1);
        warpBitmaskSetBits(breakMask, wp, 1, 0);
        for (tmpWp = 0; tmpWp < dev->halo.deviceInfo.numWarpsPrSM; ++tmpWp)
            if (haloWarpsInSameCTA(dev, vsm, wp, tmpWp))
                warpBitmaskSetBits(breakMask, tmpWp, 1, 0);
        res = dev->halo.adjustCodeAddress(pc, breakAddr, CUDBG_ADJ_NEXT_ADDRESS);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to adjustCodeAddress\n");
        *isSteppable = false;

        return CUDBG_SUCCESS;
    }

    /* This warp's PC isn't pointing at a barrier, but it could still be
       waiting on one due to how Kepler's BRU works.  If the following
       check succeeds, B2R.WARP state indicates this warp is waiting on
       a barrier, which means we need to break at *this* PC. */
    res = dev->halo.isWarpOnBarrier(dev, vsm, wp, &isWarpOnBarrier);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Call to isWarpOnBarrier failed (res=%d)\n", res);

    if (isWarpOnBarrier) {
        uint32_t tmpWp;
        HALO_TRACE(2, "  Found barrier state active at pc = %x\n", pc);
        /* Need to resume all warps in the same cta as this warp */
        warpBitmaskFill(breakMask, 1);
        warpBitmaskSetBits(breakMask, wp, 1, 0);
        for (tmpWp = 0; tmpWp < dev->halo.deviceInfo.numWarpsPrSM; ++tmpWp)
            if (haloWarpsInSameCTA(dev, vsm, wp, tmpWp))
                warpBitmaskSetBits(breakMask, tmpWp, 1, 0);
        *breakAddr = pc;
        *isSteppable = false;
        return CUDBG_SUCCESS;
    }

    /* Check continuation */
    if (volta_gv10x_isContinuation(inst)) {
        HALO_TRACE(2, "  Found an unsteppable continuation at pc = %x\n", pc);
        warpBitmaskClear(breakMask); /* The entire SM resumes */
        res = dev->halo.adjustCodeAddress(pc, breakAddr, CUDBG_ADJ_NEXT_ADDRESS);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to adjustCodeAddress\n");
        *isSteppable = false;
        return CUDBG_SUCCESS;
    }

    /// HACK!!! HACK!!! HACK -only for fmodel!!!
#if 0
    if (globals.devices[dev->deviceIdx]->state.simulationType == CUI_SIMULATION_TYPE_FMODEL) {
        warpBitmaskFill(breakMask, 1);
        warpBitmaskSetBits(breakMask, wp, 1, 0);
        res = dev->halo.adjustCodeAddress(pc, breakAddr, CUDBG_ADJ_NEXT_ADDRESS);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to adjustCodeAddress\n");
        *isSteppable = false;
        return CUDBG_SUCCESS;
    }
#endif

    *isSteppable = true;

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_getWarpMaskPRIOffset(CudbgDevice dev, HaloMaskPRI pri, uint32_t wordIndex, uint32_t *reg)
{
    CUDBG_VERIFY(wordIndex < 2, CUDBG_ERROR_INVALID_ARGS, "Invalid offset\n");
    switch (pri) {
    case HALO_MASK_PRI_WARP_VALID:
        switch (wordIndex) {
        case 0:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM0_DBGR_WARP_VALID_MASK_0;
            break;
        case 1:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM0_DBGR_WARP_VALID_MASK_1;
            break;
        }
        break;
    case HALO_MASK_PRI_BPT_PAUSE:
        switch (wordIndex) {
        case 0:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM0_DBGR_BPT_PAUSE_MASK_0;
            break;
        case 1:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM0_DBGR_BPT_PAUSE_MASK_1;
            break;
        }
        break;
    case HALO_MASK_PRI_BPT_TRAP:
        switch (wordIndex) {
        case 0:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM0_DBGR_BPT_TRAP_MASK_0;
            break;
        case 1:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM0_DBGR_BPT_TRAP_MASK_1;
            break;
        }
        break;
    default:
        HALO_ERROR("Invalid requested PRI\n");
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_mapGpcTpcSm(CudbgDevice dev)
{
    const CUdev* pDev = globals.devices[dev->deviceIdx];
    uint32_t tpc, gpc, sm, priBaseOffset;
    uint32_t vsm = 0;
    CUresult cures = CUDA_SUCCESS;
    CUdevSmGpcTpcMap map = {0};

    CU_TRACE_FUNCTION();

    /* Init all the locations */
    memset(dev->halo.deviceInfo.vsmMap, ~0, sizeof dev->halo.deviceInfo.vsmMap);
    memset(dev->halo.deviceInfo.tpcMap, ~0, sizeof dev->halo.deviceInfo.tpcMap);
    memset(dev->halo.deviceInfo.gpcMap, ~0, sizeof dev->halo.deviceInfo.gpcMap);
    memset(dev->halo.deviceInfo.smMap,  ~0, sizeof dev->halo.deviceInfo.smMap);

    cures = pDev->dmal.deviceGetSmToSmGpcTpcMap(pDev, &map);
    if (cures != CUDA_SUCCESS) {
        HALO_ERROR(" Failed to get SM to GPC/TPC map from driver call. CUres:%u\n", cures);
        return CUDBG_ERROR_INTERNAL;
    }

    for (vsm = 0; vsm < map.numSm; ++vsm) {
        CUDBG_VERIFY((vsm < CUDBG_MAX_SMS && dev->halo.deviceInfo.gpcMap[vsm] == ~0U),
                     CUDBG_ERROR_INTERNAL,
                     "Error: GPC%u/TPC%u shares the same SM id %u as GPC%u/TPC%u.\n",
                     (NvU8)map.gpcId[vsm], (NvU8)map.localTpcId[vsm], vsm, dev->halo.deviceInfo.gpcMap[vsm], dev->halo.deviceInfo.tpcMap[vsm]);

        gpc = (NvU8)map.gpcId[vsm];
        tpc = (NvU8)map.localTpcId[vsm];
        sm  = (NvU8)map.localSmId[vsm];
        priBaseOffset         = VOLTA_GPC_OFFSET * gpc + VOLTA_TPC_OFFSET * tpc + VOLTA_SM_OFFSET * sm;
        dev->halo.deviceInfo.gpcMap[vsm]      = gpc;
        dev->halo.deviceInfo.tpcMap[vsm]      = tpc;
        dev->halo.deviceInfo.smMap[vsm]       = sm;
        dev->halo.deviceInfo.vsmMap[gpc][tpc] = vsm;
        dev->priBase[vsm]     = dev->bar0 + priBaseOffset;
        HALO_TRACE(1, "  GPC%u/TPC%u/SM%u is mapped to VSM %u (priBase=%p)\n",
                   gpc, tpc, sm, vsm, dev->priBase[vsm]);
    }
    dev->halo.deviceInfo.numSMs = map.numSm;

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_getPRIOffset(CudbgDevice dev, HaloPRI pri, int32_t vsm,
                        uint32_t *offset)
{
    bool tpcPRI = false;
    CUDBG_VERIFY(offset, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");
    int priOffset = 0;
    uint32_t floorsweptSmId = 0;
    CUDBGResult res = CUDBG_SUCCESS;

    *offset = 0;

    if (vsm < 0) {
        switch(pri) {
        case HALO_PRI_SM_DBGR_CONTROL0:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_SMS_DBGR_CONTROL0;
            break;
        case HALO_PRI_SM_DBGR_STATUS0:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_SMS_DBGR_STATUS0;
            break;
        case HALO_PRI_SM_HWW_WARP_ESR:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_SMS_HWW_WARP_ESR;
            break;
        case HALO_PRI_SM_HWW_GLOBAL_ESR:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_SMS_HWW_GLOBAL_ESR;
            break;
        case HALO_PRI_SM_CACHE_CONTROL:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_SM_CACHE_CONTROL;
            break;
        case HALO_PRI_TPCCS_TPC_EXCEPTION:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_TPCCS_TPC_EXCEPTION;
            break;
        case HALO_PRI_TPCCS_TPC_EXCEPTION_EN:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_TPCCS_TPC_EXCEPTION_EN;
            break;
        case HALO_PRI_SM_BLCG_1_CG:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_SM_BLCG_1_CG;
            break;
        case HALO_PRI_SM_HWW_GLOBAL_ESR_REPORT_MASK:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_SMS_HWW_GLOBAL_ESR_REPORT_MASK;
            break;
        default:
            HALO_ERROR("Failed to map PRIOffset\n");
            return CUDBG_ERROR_INVALID_ARGS;
        }
        *offset = priOffset + (uint32_t)(uintptr_t)dev->bar0;
    }
    else {
        switch(pri) {
        case HALO_PRI_SM_DBGR_CONTROL0:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_SM0_DBGR_CONTROL0;
            break;
        case HALO_PRI_SM_DBGR_STATUS0:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_SM0_DBGR_STATUS0;
            break;
        case HALO_PRI_SM_HWW_WARP_ESR:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_SM0_HWW_WARP_ESR;
            break;
        case HALO_PRI_SM_HWW_GLOBAL_ESR:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_SM0_HWW_GLOBAL_ESR;
            break;
        case HALO_PRI_SM_CACHE_CONTROL:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_SM_CACHE_CONTROL;
            tpcPRI = true;
            break;
        case HALO_PRI_TPCCS_TPC_EXCEPTION:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_TPCCS_TPC_EXCEPTION;
            tpcPRI = true;
            break;
        case HALO_PRI_TPCCS_TPC_EXCEPTION_EN:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_TPCCS_TPC_EXCEPTION_EN;
            tpcPRI = true;
            break;
        case HALO_PRI_SM_BLCG_1_CG:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_SM_BLCG_1_CG;
            tpcPRI = true;
            break;
        case HALO_PRI_SM_HWW_GLOBAL_ESR_REPORT_MASK:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_SM0_HWW_GLOBAL_ESR_REPORT_MASK;
            break;
        default:
            HALO_ERROR("Failed to map PRIOffset\n");
            return CUDBG_ERROR_INVALID_ARGS;
        }
        res = dev->halo.getFloorsweptSmIdFromSubcontext(dev, vsm, &floorsweptSmId);
        if (res != CUDBG_SUCCESS)
            return res;

        if (tpcPRI) {
            /* On volta, we have two SMs per TPC, so default to the SM PRI if there
               is one, otherwise the TPC PRI which is outside the priBase[floorsweptSmId] */
            *offset = priOffset + (uint32_t)(uintptr_t)dev->bar0 +
                      VOLTA_GPC_OFFSET * dev->halo.deviceInfo.gpcMap[floorsweptSmId] +
                      VOLTA_TPC_OFFSET * dev->halo.deviceInfo.tpcMap[floorsweptSmId];
        }
        else {
            /* vsm specific priBase */
            *offset = priOffset + (uint32_t)(uintptr_t)dev->priBase[floorsweptSmId];
        }
    }

    return CUDBG_SUCCESS;
}

/* In S2R terms, this function converts from SR_VirtualSMId (SR67) to SR_VirtId.SMId (SR3).
 * SR67 is an MPS construct. At the time of this writing, debugger doesn't support MPS,
 * but it's affected, because starting with Volta, the traphandler is indexed with SR67.
 * When MPS is disabled, SR_VirtualSMId and SR_VirtId.SMId are usually the same,
 * except for when they're not. See bug 2096878 for details. */
static CUDBGResult
volta_gv10x_getFloorsweptSmIdFromSubcontext(CudbgDevice dev, uint32_t subcontextSmId, uint32_t *floorsweptSmId)
{
    CUDBG_VERIFY(dev && (subcontextSmId < CUDBG_MAX_SMS) && floorsweptSmId,
                 CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    if (dev->smState[subcontextSmId].state.floorsweptSmIdValid) {
        *floorsweptSmId = dev->smState[subcontextSmId].state.floorsweptSmId;
    }
    else {
        *floorsweptSmId = subcontextSmId;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_readWarpMaskPRI(CudbgDevice dev, uint32_t vsm, HaloRegOpType type,
                            HaloMaskPRI pri, CUwarpBitmask *mask)
{
    uint64_t val = 0;
    uint32_t i = 0, reg = 0;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(dev && mask, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    warpBitmaskClear(mask);

    /* Round up as Turing has 32 warps per sm */
    for (i=0; i < (dev->halo.deviceInfo.numWarpsPrSM+63) / 64; ++i) {
        res = dev->halo.getWarpMaskPRIOffset(dev, pri, 2*i, &reg);
        if (res != CUDBG_SUCCESS)
            return res;

        reg += (uint32_t)(uintptr_t)dev->priBase[vsm];

        res = dev->haloClient->readReg64(dev, type, dev->bar0 + reg, &val);
        if (res != CUDBG_SUCCESS)
            return res;

        warpBitmaskSetBits(mask, 64*i, 64, val);
    }

    return res;
}

static CUDBGResult
volta_gv10x_writeWarpMaskPRI(CudbgDevice dev, uint32_t vsm, HaloRegOpType type,
                             HaloMaskPRI pri, CUwarpBitmask *mask)
{
    uint64_t val = 0;
    uint32_t reg = 0, i = 0;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(dev && mask, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    /* Round up as Turing has 32 warps per sm */
    for (i=0; i < (dev->halo.deviceInfo.numWarpsPrSM+63) / 64; ++i) {
        val = warpBitmaskGetBits(mask, 64*i, 64);

        res = dev->halo.getWarpMaskPRIOffset(dev, pri, 2*i, &reg);
        if (res != CUDBG_SUCCESS)
            return res;

        reg += (uint32_t)(uintptr_t)dev->priBase[vsm];

        res = dev->haloClient->writeReg64(dev, type, dev->bar0 + reg, &val);
        if (res != CUDBG_SUCCESS)
            return res;
    }

    return res;
}

static CUDBGResult
volta_gv10x_getScratchpadSharedMemDevVaddr(Context context, uint64_t *shmemDevVaddr)
{
    CUDBG_VERIFY(shmemDevVaddr && context, CUDBG_ERROR_INVALID_ARGS, "Invalid args.\n");

    HALO_ERROR("SharedMemDevVaddr does not exist for volta!\n");
    *shmemDevVaddr = 0;

    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
volta_gv10x_readSMWarpESRInfo(CudbgDevice dev, uint32_t vsm, CudbgSMState_t *state)
{
    CUDBGResult res = CUDBG_SUCCESS;
    Context context = dev->activeContext;

    CUDBG_VERIFY(dev && state, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    if (!context)
    {
        state->esrWarpInfoValid = false;
        state->esrWarpId = 0;
    }
    else {
        /* Setup some initial stuff for whether the ESR warp info valid or not */
        state->esrWarpInfoValid = !!(state->esrState.hwwwarpesr);

        /* Bits 23:16 of the hwwwarpesr are the warpid, 15:0 is the error */
        state->esrWarpId = ((uint32_t)state->esrState.hwwwarpesr >> 16) & 0xff;

        state->esrWarpPC = state->esrState.hwwwarpesrpc;
        if (state->esrWarpInfoValid && state->esrWarpPC == 0x0) {
            /* Could either be a jump to 0x0 or invalid ESR info */
            CUDBG_TRACE("WARNING: %u/%u/%u esrWarpPC NULL"
                " hwwwarpesr 0x%08x"
                " hwwwarpesrpc 0x%" PRIx64 "\n",
                dev->deviceIdx, vsm, state->esrWarpId,
                state->esrState.hwwwarpesr,
                state->esrState.hwwwarpesrpc);
        }
    }

    return res;
}

static CUDBGResult
volta_gv10x_mcinterop_getPatchPC(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                 uint32_t ln, uint64_t *pc)
{
    CUDBGResult res = CUDBG_SUCCESS;
    res = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                    dev->halo.deviceInfo.lmemHiMemcheckScratch +
                                    FERMI_LMEM_MEMCHECK_PC, pc, sizeof *pc);
    return res;
}

static CUDBGResult
volta_gv10x_getNumRegistersForGrid(Context ctx, Grid grid, uint32_t *numRegs)
{
    CUDBG_VERIFY(grid && grid->function && numRegs, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");
    /* Elf image will give the total number of registers, but only N-2 are user
       accessible (the top two are the restore pc for the lane on volta) */
    *numRegs = grid->function->nrofRegisters - 2;
    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_fillDisassemblyBuffer(Context context, uint64_t gpuAddr, uint64_t inst[2],
                            uint64_t *instBuf, uint32_t instBufSize,
                            uint32_t *instBufWrittenSize)
{
    CUDBG_VERIFY(context && instBuf && instBufWrittenSize, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");
    CUDBG_VERIFY(instBufSize >= 2*sizeof(inst[0]), CUDBG_ERROR_INTERNAL, "Buffer too small\n");

    /* Default is to just copy out the given instruction */
    memcpy(instBuf, inst, 2*sizeof(inst[0]));
    *instBufWrittenSize = 2*sizeof(inst[0]);

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_readCCRegister(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                           uint32_t ln, uint32_t *cc)
{
    uint8_t ccReg = 0;
    CUDBG_VERIFY(cc, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args in volta_gv10x_readCCRegister\n");

    // No condition code on Volta. Return 0.
    *cc = 0;

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_getSavedSPLmemAddr(CudbgDevice dev, uint64_t *lmem_addr)
{
    CUDBG_VERIFY(lmem_addr,
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments\n");

    *lmem_addr = VOLTA_LMEM_SAVED_STACK_POINTER;
    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_getPauseReasonTableWarpOffset(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t* offset)
{
    CUDBG_VERIFY(offset && dev, CUDBG_ERROR_INVALID_ARGS, "\n");
    *offset = (CUDBG_MAX_WARP_VOLTA * vsm + wp) * sizeof(uint32_t);
    return CUDBG_SUCCESS;
}

/* Get offset of gridId in GridParams. This is DCI dependent, hence halified. */
static CUDBGResult
volta_gv10x_getGridParamsOffsetGridId(CudbgDevice dev, uint64_t *offset)
{
    CUDBG_VERIFY(offset, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");

    *offset = ((uint64_t)(uintptr_t)&((CUvoltaGridParams *)0)->gridId);

    return CUDBG_SUCCESS;
}

/* Get offset of blockDim in GridParams. This is DCI dependent, hence halified.*/
static CUDBGResult
volta_gv10x_getGridParamsOffsetBlockDim(CudbgDevice dev, uint64_t *offset,
                                        uint32_t *size)
{
    CUDBG_VERIFY(offset && size, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");

    *offset = ((uint64_t)(uintptr_t)&((CUvoltaGridParams *)0)->blockDim);
    *size = sizeof ((CUvoltaGridParams *)0)->blockDim;

    return CUDBG_SUCCESS;
}

/* Get offset of gridDim in GridParams. This is DCI dependent, hence halified.*/
static CUDBGResult
volta_gv10x_getGridParamsOffsetGridDim(CudbgDevice dev, uint64_t *offset,
                                       uint32_t *size)
{
    CUDBG_VERIFY(offset && size, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");

    *offset = ((uint64_t)(uintptr_t)&((CUvoltaGridParams *)0)->gridDim);
    *size = sizeof ((CUvoltaGridParams *)0)->gridDim;

    return CUDBG_SUCCESS;
}

/* Get offset of startPc in GridParams. This is DCI dependent, hence halified.*/
static CUDBGResult
volta_gv10x_getGridParamsOffsetStartPc(CudbgDevice dev, uint64_t *offset)
{
    CUDBG_VERIFY(offset, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");

    *offset = CNP_GRID_PARAM_OFFSET(startPc);

    return CUDBG_SUCCESS;
}

/* This function finds the parent Grid for a given child Grid. */
static CUDBGResult
volta_gv10x_findParentGrid(CudbgDevice dev, Grid childGrid, Grid *parentGrid)
{
    CUDBGResult res;
    uint64_t startPc;
    uint64_t selfQMDdptr;
    uint64_t paramConstDptr;
    uint64_t cnpParentCtxDptr;
    uint64_t gridIdOffset;
    uint64_t startPcOffset;
    uint64_t blockDimOffset;
    uint64_t gridDimOffset;
    uint64_t selfQMDdptrOffset;
    uint64_t paramConstDptrOffset;
    DeviceFunction function;
    CuDim3 gridDim, blockDim;
    uint64_t parentGridId64;
    uint32_t size;
    CNPparentCtx cnpParentCtx = {0};
    uint32_t blockDimPacked[3], gridDimPacked[3];
    Context context;

    /* First, check to see if we already have the info we need */
    if (childGrid->parentGridId64) {
        *parentGrid = haloStateDeviceGetGrid(dev, childGrid->parentGridId64);

        /* If the grid is already present, this info would have been collected. */
        if (*parentGrid) {
            HALO_TRACE_FUNCTION(2, "parentGridId %" PRId64 " already known, finishing\n", childGrid->parentGridId64);
            return CUDBG_SUCCESS;
        }
    }

    /* Get the context */
    context = childGrid->function->module->context;

    /* Get the dptr to this grid's QMDLaunch structure */
    selfQMDdptr = childGrid->selfQMDdptr;

    HALO_TRACE_FUNCTION(2, "Finding parent for gridId %" PRId64 "\n", childGrid->gridId64);
    HALO_TRACE_FUNCTION(2, "selfQMDdptr %" PRIx64 "\n", selfQMDdptr);

    /************************************************/
    /*  Find out the parentGridId                   */
    /************************************************/

    /* Get offset of parent CNPparentCtx */
    cnpParentCtxDptr = selfQMDdptr + offsetof(CNPqmdLaunch, graphNode) +
                       offsetof(CNPgraphNode, parent);

    HALO_TRACE_FUNCTION(5, "cnpParentCtxDptr: %" PRIx64 "\n", cnpParentCtxDptr);

    /* Figure out where this grid was launched from (host/device) */
    res = dev->halo.readGenericMemory(context,
                                      0, 0, 0,
                                      cnpParentCtxDptr,
                                      &cnpParentCtx,
                                      sizeof(cnpParentCtx));
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read CNPparenCtx at address %" PRIx64 "\n",
                   cnpParentCtxDptr);
        return CUDBG_SUCCESS;
    }

    if (cnpParentCtx.type == PARENT_CPU) {
        HALO_TRACE_FUNCTION(2, "Cannot collect parent info for host launched grid!\n");
        return CUDBG_ERROR_INVALID_GRID;
    }

    HALO_TRACE_FUNCTION(5, "parent addr: %" PRIx64 "\n", cnpParentCtx.addr);

    /* Get the ptr to the CNPqmdLaunch structure of this grid's parent */
    /* Get the parent's selfQMDdptr */
    selfQMDdptrOffset = cnpParentCtx.addr + offsetof(CNPctaCtx, gridOrigin);
    res = dev->halo.readGenericMemory(context,
                                      0, 0, 0,
                                      selfQMDdptrOffset,
                                      &selfQMDdptr,
                                      sizeof(selfQMDdptr));
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read CNPqmdLaunch at address %" PRIx64 "\n",
                   selfQMDdptrOffset);
        return res;
    }

    HALO_TRACE_FUNCTION(5, "parent's selfQMDdptr: %" PRIx64 "\n", selfQMDdptr);

    /* We now have the parent's selfQMDdptr, we can use that to get info
       about the parent grid. */

    /* Get the dptr to the parameter constbank (constbank 0)*/
    paramConstDptrOffset = selfQMDdptr + offsetof(CNPqmdLaunch, paramConstDptr);
    res = dev->halo.readGenericMemory(context,
                                      0, 0, 0,
                                      paramConstDptrOffset,
                                      &paramConstDptr,
                                      sizeof(paramConstDptr));
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read paramConstDptr at address %" PRIx64 " from QMDLaunch\n",
                   paramConstDptrOffset);
        return res;
    }

    HALO_TRACE_FUNCTION(2 , "paramConstDptr: %" PRIx64 "\n", paramConstDptr);

    /* Read the parentGridId */
    res = dev->halo.getGridParamsOffsetGridId(dev, &gridIdOffset);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to get gridId offset in GridParams\n");
        return res;
    }

    gridIdOffset += paramConstDptr;
    res = dev->halo.readGenericMemory(context,
                                      0, 0, 0,
                                      gridIdOffset,
                                      &parentGridId64,
                                      sizeof(parentGridId64));
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read parentGridId at address %" PRIx64 " from constbank 0\n",
                   gridIdOffset);
        return res;
    }
    childGrid->parentGridId64 = parentGridId64;

    HALO_TRACE_FUNCTION(2, "parentGridId64: %" PRId64 "\n", (int64_t)parentGridId64);

    *parentGrid = haloStateDeviceGetGrid(dev, parentGridId64);

    /* If the grid is already present, this info would have been collected. */
    if (*parentGrid) {
        HALO_TRACE_FUNCTION(2, "Info for parentGridId %" PRId64 " already collected, finishing\n", parentGridId64);
        return CUDBG_SUCCESS;
    }

    /************************************************/
    /*  Get the remaining info for the parent grid  */
    /************************************************/

    /* If we still don't have a grid, it must be the first time we saw this
       parentGridId. Construct a grid for it and collect info. */
    if (!*parentGrid) {
        /* Get the block dimensions */
        res = dev->halo.getGridParamsOffsetBlockDim(dev, &blockDimOffset, &size);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to get blockDim offset in GridParams\n");
            return res;
        }

        blockDimOffset += paramConstDptr;
        res = dev->halo.readGenericMemory(context,
                                          0, 0, 0,
                                          blockDimOffset,
                                          &blockDimPacked,
                                          sizeof(blockDimPacked));
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to read grid dimensions from constbank 0\n");
            return res;
        }

        blockDim.x = blockDimPacked[0] & 0xFFFF;
        blockDim.y = blockDimPacked[1] & 0xFFFF;
        blockDim.z = blockDimPacked[2] & 0xFFFF;

        /* Get the grid dimensions */
        res = dev->halo.getGridParamsOffsetGridDim(dev, &gridDimOffset, &size);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to get gridDim offset in GridParams\n");
            return res;
        }

        gridDimOffset += paramConstDptr;
        res = dev->halo.readGenericMemory(context,
                                          0, 0, 0,
                                          gridDimOffset,
                                          &gridDimPacked,
                                          sizeof(gridDimPacked));
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to read grid dimensions from constbank 0\n");
            return res;
        }

        gridDim.x = (gridDimPacked[0] & (uint32_t)0xFFFFFFFF);
        gridDim.y = (gridDimPacked[1] & 0xFFFF);
        gridDim.z = (gridDimPacked[2] & 0xFFFF);

        /* To get the function, first get startPC from within the constbank */
        res = dev->halo.getGridParamsOffsetStartPc(dev, &startPcOffset);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to get gridDim offset in GridParams\n");
            return res;
        }

        startPcOffset += paramConstDptr;
        res = dev->halo.readGenericMemory(context,
                                          0, 0, 0,
                                          startPcOffset,
                                          &startPc,
                                          sizeof(startPc));
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to read startPc at address %" PRIx64 " from constbank 0\n",
                       startPcOffset);
            return res;
        }

        HALO_TRACE_FUNCTION(5, "startPc: 0x%x\n", startPc);

        /* Now get the function corresponding to this startPc */
        function = (DeviceFunction)toolsRangeMapLookupByAddr(context->gpuAddrToFunction, startPc);
        if (!function) {
            HALO_ERROR("Could not find a DeviceFunction for startPc %" PRIx64 "\n", startPc);
            res = CUDBG_ERROR_UNKNOWN_FUNCTION;
            return res;
        }

        HALO_TRACE_FUNCTION(2, "function: %s\n", function->name);
        HALO_TRACE_FUNCTION(2, "gridDim: (%d,%d,%d)\n", gridDim.x, gridDim.y, gridDim.z);
        HALO_TRACE_FUNCTION(2, "blockDim: (%d,%d,%d)\n", blockDim.x, blockDim.y, blockDim.z);

        /* Create a grid for this ID and add it to internal tracking structures. */
        res = haloStateCreateGrid(parentGrid, function, parentGridId64);
        if (res != CUDBG_SUCCESS)
            return res;

        /* Fill in the remaining info */
        (*parentGrid)->gridDim = gridDim;
        (*parentGrid)->blockDim = blockDim;
        (*parentGrid)->state = HALO_GRID_STATE_INVISIBLE;
        (*parentGrid)->selfQMDdptr = selfQMDdptr;
    }

    return CUDBG_SUCCESS;
}


static CUDBGResult
volta_gv10x_getUserEntryFunction(CudbgDevice dev, Context context, uint32_t vsm, uint32_t wp, uint32_t ln,
                                  Grid grid, DeviceFunction *entryFunc)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t startPc = 0;
    uint64_t startPcOffset;
    uint64_t selfQMDdptr;
    uint64_t paramConstDptrOffset;
    uint64_t paramConstDptr;

    CUDBG_VERIFY(dev && context && entryFunc && grid, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments");

    res = dev->halo.scratchpad.read_selfQMD(context->scratchpadAccessor, vsm, wp, &selfQMDdptr);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Could not get selfQMDdptr\n");

    HALO_TRACE_FUNCTION(5, "selfQMDdptr: 0x%" PRIx64 "\n", selfQMDdptr);

    /* Get the dptr to the parameter constbank (constbank 0)*/
    paramConstDptrOffset = selfQMDdptr + offsetof(CNPqmdLaunch, paramConstDptr);
    res = dev->halo.readGenericMemory(context,
                                      0, 0, 0,
                                      paramConstDptrOffset,
                                      &paramConstDptr,
                                      sizeof(paramConstDptr));
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read paramConstDptr at address %"
                 PRIx64 " from QMDLaunch\n", paramConstDptrOffset);

    /* Bug 1372597 - There is a small window in the cnpexit handler where
       interrupts are enabled, the grid is deemed 'completed', but the warp is
       still resident. In this case, there is no userEntryFunction can be found,
       but it is not an error. */
    if (!paramConstDptr) {
        HALO_TRACE_FUNCTION(1, "Grid %#" PRIx64 " has completed, but warp is still resident."
                                " There is no userEntryFunction in this case (and this grid is not postable)\n",
                                grid->gridId64);
        *entryFunc = NULL;
        return CUDBG_SUCCESS;
    }
    HALO_TRACE_FUNCTION(5, "paramConstDptr: 0x%" PRIx64 "\n", paramConstDptr);

    /* To get the function, first get startPC from within the constbank */
    res = dev->halo.getGridParamsOffsetStartPc(dev, &startPcOffset);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get gridDim offset in GridParams\n");

    startPcOffset += paramConstDptr;
    res = dev->halo.readGenericMemory(context,
                                      0, 0, 0,
                                      startPcOffset,
                                      &startPc,
                                      sizeof(startPc));
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read startPc at address %" PRIx64 " from constbank 0\n",
                 startPcOffset);

    HALO_TRACE_FUNCTION(5, "startPc: %" PRIx64 " \n", startPc);

    /* Now get the function corresponding to this startPc */
    *entryFunc = (DeviceFunction)toolsRangeMapLookupByAddr(context->gpuAddrToFunction, startPc);
    if (!*entryFunc) {
        HALO_ERROR("Could not find a DeviceFunction for startPc %" PRIx64 " \n", startPc);
        return CUDBG_ERROR_UNKNOWN_FUNCTION;
    }

    return res;
}

static CUDBGResult
volta_gv10x_disablePairingMode(CudbgDevice dev, Context context)
{
    /* No pairing mode on Volta */
    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_enablePairingMode(CudbgDevice dev, Context context)
{
    /* No pairing mode on Volta */
    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_readExitedMask(CudbgDevice dev, uint32_t vsm, uint32_t tid, uint32_t *mask)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t activeMask = 0;
    uint32_t exitedMask = 0;
    uint32_t sp = 0;
    uint32_t ln = 0;

    CUDBG_VERIFY(mask, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    res = dev->halo.scratchpad.read_warpActiveMask(dev->activeContext->scratchpadAccessor, vsm, tid, &activeMask);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read warp active mask\n");

    /* First, find any active lane to check if past the syscall trampoline */
    for (ln=0; ln < 32 && !((1<<ln) & activeMask); ++ln);
    CUDBG_VERIFY(ln < 32, CUDBG_ERROR_INTERNAL, "Unable to find an active lane for vsm%d/wp%d -- corrupt preemption buffer?", vsm, tid);

    res = dev->halo.readRegisterRange(dev, vsm, tid, ln, dev->halo.deviceInfo.spRegisterNumber, &sp, 1, true);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read stack pointer register\n");

#if VOLTA_CONVERGENT_SYSCALLS
    if (sp <= dev->halo.deviceInfo.systemStackPointer && sp > (dev->halo.deviceInfo.systemStackPointer - dev->activeContext->syscallStackSz)) {
        /* Convergent syscalls - we need to read the user's stashed active and
           exited mask if we're in a syscall in order to get the full picture.
           This is stashed in each lane's syscall stack that called the syscall. */

        HALO_TRACE_FUNCTION(10, "vsm%d/wp%d/ln%d past the syscall trampoline, reading cbu masks from syscall stack\n",
                            vsm, tid, ln);

        res = dev->halo.readLocalMemory(dev, vsm, tid, ln, dev->halo.deviceInfo.lmemSavedMExited, &exitedMask, sizeof(exitedMask));
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read mexitted from syscall stack!\n");
    }
    else
#endif
    {
        res = dev->halo.scratchpad.read_warpExitedMask(dev->activeContext->scratchpadAccessor, vsm, tid, &exitedMask);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read warp exited mask\n");
    }

    *mask = exitedMask;

    HALO_TRACE_FUNCTION(20, "vsm%d/wp%d/ln%d sp=0x%08x mask=0x%08x\n", vsm, tid, ln, sp, *mask);

    return CUDBG_SUCCESS;
}

/* Scratchpad access */

static CUDBGResult
volta_gv10x_scratchpad_getGlobalFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_SCRATCHPAD_GET_OFFSET_CASE(ACTIVE, VoltaScratchpad_t, active);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PREEMPT_COMMAND, VoltaScratchpad_t, preemptCommand);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PADDING, VoltaScratchpad_t, padding);
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_scratchpad_getWarpFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_SCRATCHPAD_GET_OFFSET_CASE(VIRT_ID, VoltaWarpScratchpad_t, virtID);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_IDX_X, VoltaWarpScratchpad_t, blockIdxX);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_IDX_Y, VoltaWarpScratchpad_t, blockIdxY);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_IDX_Z, VoltaWarpScratchpad_t, blockIdxZ);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_DIM_X, VoltaWarpScratchpad_t, blockDimX);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_DIM_Y, VoltaWarpScratchpad_t, blockDimY);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_DIM_Z, VoltaWarpScratchpad_t, blockDimZ);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_PARAM, VoltaWarpScratchpad_t, gridId);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_DIM_X, VoltaWarpScratchpad_t, gridDimX);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_DIM_Y, VoltaWarpScratchpad_t, gridDimY);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_DIM_Z, VoltaWarpScratchpad_t, gridDimZ);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SHMEM_SIZE_PR_BLOCK, VoltaWarpScratchpad_t, shmemSizePrBlock);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_WINDOW_SIZE, VoltaWarpScratchpad_t, lmemWindowSize);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_LO_SIZE_PR_THREAD, VoltaWarpScratchpad_t, lmemLoSizePrThread);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_HI_OFF, VoltaWarpScratchpad_t, lmemHiOff);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GLOBAL_ERROR_STATUS, VoltaWarpScratchpad_t, globalErrorStatus);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_ERROR_STATUS, VoltaWarpScratchpad_t, warpErrorStatus);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_ERROR_PC, VoltaWarpScratchpad_t, warpErrorPC);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_BARRIER_STATE, VoltaWarpScratchpad_t, warpBarrierState);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SELF_QMD, VoltaWarpScratchpad_t, selfQMDAddr);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PARAM_CONST_DPTR, VoltaWarpScratchpad_t, paramConstDptr);
        /* HACK! CIR_QUEUE_INCR_MINUS_ONE is always just used to check if the CTA is queued */
        HALO_SCRATCHPAD_GET_OFFSET_CASE(CIR_QUEUE_INCR_MINUS_ONE, VoltaWarpScratchpad_t, isQueueCTA);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_BASE, VoltaWarpScratchpad_t, lmemBase);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(MPS_CONTEXT_ID, VoltaWarpScratchpad_t, mpsContextId);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SUBCONTEXT_VSMID, VoltaWarpScratchpad_t, subContextVSMId);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SINGLESTEP_NSTEPS, VoltaWarpScratchpad_t, singleStepNsteps);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_FLAG_VALID_ON_SAVE, VoltaWarpScratchpad_t, warpFlagsValidOnSave);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_FLAG_PAUSE_SERVICED, VoltaWarpScratchpad_t, warpFlagsPauseServiced);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(REGISTER_COUNT, VoltaWarpScratchpad_t, regCount);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_ACTIVE_MASK, VoltaWarpScratchpad_t, trapReturnMask);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_TRAP_RPC, VoltaWarpScratchpad_t, trapReturnPC);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_EXITED_MASK, VoltaWarpScratchpad_t, warpExitedMask);
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_scratchpad_getLaneFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_SCRATCHPAD_GET_OFFSET_CASE(THREAD_IDX, VoltaLaneScratchpad_t, threadIdx);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(R1, VoltaLaneScratchpad_t, r1);
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_scratchpad_getSmFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_scratchpad_getFieldOffset(HaloScratchpadField field, HaloScratchpadSection section,
    uint32_t sm, uint32_t wp, uint32_t ln, size_t *offset, size_t *width)
{
    size_t base = 0;
    CUDBGResult res;

    switch (section) {
    case HALO_SCRATCHPAD_SECTION_GLOBAL:
        res = volta_gv10x_scratchpad_getGlobalFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_SCRATCHPAD_SECTION_WARP:
        base = OFFSETOF_NONCONST(VoltaScratchpad_t, warp[sm][wp]);
        res = volta_gv10x_scratchpad_getWarpFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_SCRATCHPAD_SECTION_SM:
        base = OFFSETOF_NONCONST(VoltaScratchpad_t, sm[sm]);
        res = volta_gv10x_scratchpad_getSmFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_SCRATCHPAD_SECTION_LANE:
        base = OFFSETOF_NONCONST(VoltaScratchpad_t, warp[sm][wp]) +
               OFFSETOF_NONCONST(VoltaWarpScratchpad_t, lane[ln]);
        res = volta_gv10x_scratchpad_getLaneFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    default:
        *offset = 0;
        *width = 0;
        HALO_TRACE_FUNCTION(0, "Invalid scratchpad section %d\n", section);
        return CUDBG_ERROR_INVALID_ARGS;
    };


    *offset += base;

    return res;
}

static CUDBGResult
volta_gv10x_scratchpad_read_CRSSize(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *crsSize)
{
    /* No CRS, so the size of it is zero -- used in local memory address calculations */
    CUDBG_VERIFY(scratchpadAccessor && crsSize, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");
    *crsSize = 0;
    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_scratchpad_read_gridId(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint64_t *gridId)
{
    CUDBG_VERIFY(scratchpadAccessor && gridId, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, GRID_PARAM, vsm, wp, 0, gridId);

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_scratchpad_read_warpErrorPC(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint64_t *esrWarpPC)
{
    CUDBG_VERIFY(scratchpadAccessor && esrWarpPC, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, WARP_ERROR_PC, vsm, wp, 0, esrWarpPC);

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_scratchpad_read_selfQMD(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint64_t *selfQMDdptr)
{
    CUDBG_VERIFY(scratchpadAccessor && selfQMDdptr, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, SELF_QMD, vsm, wp, 0, selfQMDdptr);

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_scratchpad_read_lmemBase(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint64_t *lmemBase)
{
    CUDBG_VERIFY(scratchpadAccessor && lmemBase, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, LMEM_BASE, vsm, wp, 0, lmemBase);

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_stub_scratchpad_read_CRSPtr(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *crsPtr)
{
    CUDBG_VERIFY(scratchpadAccessor && crsPtr, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");
    
    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
volta_gv10x_stub_scratchpad_read_curPhysStackDepth(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *curPhysStackDepth)
{
    CUDBG_VERIFY(scratchpadAccessor && curPhysStackDepth, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
volta_gv10x_scratchpad_read_paramConstDptr(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint64_t *paramConstDptr)
{
    CUDBG_VERIFY(scratchpadAccessor && paramConstDptr, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, PARAM_CONST_DPTR, vsm, wp, 0, paramConstDptr);

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_scratchpad_read_subcontextVSMId(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *subcontextVSMId)
{
    CUDBG_VERIFY(scratchpadAccessor && subcontextVSMId, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, SUBCONTEXT_VSMID, vsm, wp, 0, subcontextVSMId);

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_scratchpad_read_registerCount(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *registerCount)
{
    CUDBG_VERIFY(scratchpadAccessor && registerCount, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, REGISTER_COUNT, vsm, wp, 0, registerCount);

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_scratchpad_read_warpActiveMask(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *warpActiveMask)
{
    CUDBG_VERIFY(scratchpadAccessor && warpActiveMask, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, WARP_ACTIVE_MASK, vsm, wp, 0, warpActiveMask);

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_scratchpad_read_warpExitedMask(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *warpExitedMask)
{
    CUDBG_VERIFY(scratchpadAccessor && warpExitedMask, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, WARP_EXITED_MASK, vsm, wp, 0, warpExitedMask);

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_scratchpad_read_warpTrapRPC(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint64_t *pc)
{
    CUDBG_VERIFY(scratchpadAccessor && pc, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, WARP_TRAP_RPC, vsm, wp, 0, pc);

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_scratchpad_write_warpTrapRPC(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint64_t pc)
{
    CUDBG_VERIFY(scratchpadAccessor && pc, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_SET_FIELD(scratchpadAccessor, WARP, WARP_TRAP_RPC, vsm, wp, 0, &pc);

    return CUDBG_SUCCESS;
}

/* Preemption buffer access */

static CUDBGResult
volta_gv10x_preemptionBuffer_getLaneFieldOffset(HaloPreemptionBufferField field, uint32_t ln, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(RPC, CUvoltaWarpCILPBuffer, CBU_RPC[ln]);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(PR, CUvoltaWarpCILPBuffer, PR[ln]);
    default:
        *width = 0;
        *offset = 0;
        HALO_TRACE_FUNCTION(0, "Invalid scratchpad field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_preemptionBuffer_getWarpFieldOffset(HaloPreemptionBufferField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(BAR, CUvoltaWarpCILPBuffer, CBU_BAR);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_TRAP_RPC, CUvoltaWarpCILPBuffer, CBU_TRAP_RETURN_PC);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(ATEXIT_PC, CUvoltaWarpCILPBuffer, CBU_ATEXITPC);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(MKILL, CUvoltaWarpCILPBuffer, CBU_MKILL);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_ACTIVE_MASK, CUvoltaWarpCILPBuffer, CBU_TRAP_RETURN_MASK);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_EXITED_MASK, CUvoltaWarpCILPBuffer, CBU_MEXITED);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(MATEXIT, CUvoltaWarpCILPBuffer, CBU_MATEXIT);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_CALL_DEPTH, CUvoltaWarpCILPBuffer, CBU_API_CALL_DEPTH);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(OPT_STACK, CUvoltaWarpCILPBuffer, CBU_OPT_STACK);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(THREAD_STATE_ENUM_0, CUvoltaWarpCILPBuffer, CBU_THREAD_STATE_ENUM_0);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(THREAD_STATE_ENUM_1, CUvoltaWarpCILPBuffer, CBU_THREAD_STATE_ENUM_1);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(THREAD_STATE_ENUM_2, CUvoltaWarpCILPBuffer, CBU_THREAD_STATE_ENUM_2);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(THREAD_STATE_ENUM_3, CUvoltaWarpCILPBuffer, CBU_THREAD_STATE_ENUM_3);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(THREAD_STATE_ENUM_4, CUvoltaWarpCILPBuffer, CBU_THREAD_STATE_ENUM_4);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_RESERVED0, CUvoltaWarpCILPBuffer, reservedPad0);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_RESERVED1, CUvoltaWarpCILPBuffer, reservedPad1);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_RESERVED2, CUvoltaWarpCILPBuffer, reservedPad2);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_RESERVED3, CUvoltaWarpCILPBuffer, reservedPad3);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(LMEMBASE, CUvoltaWarpCILPBuffer, LMEMBASE);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_BARSTATE, CUvoltaWarpCILPBuffer, BARState);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(RFDATAIDX, CUvoltaWarpCILPBuffer, RFDataIdx);
    default:
        *width = 0;
        *offset = 0;
        HALO_TRACE_FUNCTION(0, "Invalid scratchpad field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_preemptionBuffer_getCTAFieldOffset(HaloPreemptionBufferField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(CTAID, CUvoltaCTACILPBuffer, CTAID);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(SHMEMDATAIDX, CUvoltaCTACILPBuffer, shmemDataIdx);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(CTA_RESERVEDPAD1, CUvoltaCTACILPBuffer, reservedPad1);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(CTA_BARSTATE, CUvoltaCTACILPBuffer, BARState);
    default:
        *width = 0;
        *offset = 0;
        HALO_TRACE_FUNCTION(0, "Invalid scratchpad field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_preemptionBuffer_getSMFieldOffset(HaloPreemptionBufferField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(RFDATAIDXSYNC, CUvoltaSMCILPBuffer, RFDataIdxSync);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(SHMEMDATAIDXSYNC, CUvoltaSMCILPBuffer, shmemDataIdxSync);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(VALIDPENDINGSTATE, CUvoltaSMCILPBuffer, validPendingState);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(SM_RESERVEDPAD0, CUvoltaSMCILPBuffer, reservedPad0);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(SM_RESERVEDPAD1, CUvoltaSMCILPBuffer, reservedPad1);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(SM_RESERVEDPAD2, CUvoltaSMCILPBuffer, reservedPad2);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(SM_RESERVEDPAD3, CUvoltaSMCILPBuffer, reservedPad3);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(RFDATA, CUvoltaSMCILPBuffer, RFData);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(SHMEMDATA, CUvoltaSMCILPBuffer, shmemData);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARPDATA, CUvoltaSMCILPBuffer, warpData);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(CTADATA, CUvoltaSMCILPBuffer, CTAData);
    default:
        *width = 0;
        *offset = 0;
        HALO_TRACE_FUNCTION(0, "Invalid scratchpad field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_preemptionBuffer_getFieldOffset(HaloPreemptionBufferField field, HaloPreemptionBufferSection section,
    uint32_t sm, uint32_t cta, uint32_t wp, uint32_t ln,
    size_t *offset, size_t *width)
{
    size_t base = 0;
    CUDBGResult res;

    base = sm * sizeof(CUvoltaSMCILPBuffer);

    switch (section) {
    case HALO_PREEMPTION_BUFFER_SECTION_SM:
        res = volta_gv10x_preemptionBuffer_getSMFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_PREEMPTION_BUFFER_SECTION_CTA:
        base += OFFSETOF_NONCONST(CUvoltaSMCILPBuffer, CTAData[cta]);
        res = volta_gv10x_preemptionBuffer_getCTAFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_PREEMPTION_BUFFER_SECTION_WARP:
        base += OFFSETOF_NONCONST(CUvoltaSMCILPBuffer, warpData[wp]);
        res = volta_gv10x_preemptionBuffer_getWarpFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_PREEMPTION_BUFFER_SECTION_LANE:
        base += OFFSETOF_NONCONST(CUvoltaSMCILPBuffer, warpData[wp]);
        res = volta_gv10x_preemptionBuffer_getLaneFieldOffset(field, ln, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    default:
        *width = 0;
        *offset = 0;
        HALO_TRACE_FUNCTION(0, "Invalid preemption buffer section %d\n", section);
        return CUDBG_ERROR_INVALID_ARGS;
    };

    *offset += base;
    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_preemptionBuffer_read_warpExitedMask(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *warpExitedMask)
{
    CUDBG_VERIFY(preemptionBufferAccessor && warpExitedMask, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_PREEMPTION_BUFFER_GET_FIELD(preemptionBufferAccessor, WARP, WARP_EXITED_MASK, vsm, 0, wp, 0, warpExitedMask);

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_stub_preemptionBuffer_read_CC(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t lane, uint8_t *cc)
{
    CUDBG_VERIFY(preemptionBufferAccessor && cc, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported preemption buffer field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
volta_gv10x_preemptionBuffer_read_RPC(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t lane, uint64_t *rpc)
{
    CUDBG_VERIFY(preemptionBufferAccessor && rpc, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_PREEMPTION_BUFFER_GET_FIELD(preemptionBufferAccessor, LANE, RPC, vsm, 0, wp, lane, rpc);

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_preemptionBuffer_write_warpTrapRPC(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint64_t warpTrapRPC)
{
    CUDBG_VERIFY(preemptionBufferAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_PREEMPTION_BUFFER_SET_FIELD(preemptionBufferAccessor, WARP, WARP_TRAP_RPC, vsm, 0, wp, 0, &warpTrapRPC);

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_membarWAR_getPatchPC(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                 uint32_t ln, uint64_t *entryPc,
                                 DebugPatch patch)
{
    CUDBG_VERIFY(entryPc && patch, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments\n");

    *entryPc = patch->entryAddr;

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_membarWAR_getPatchCallDepth(CudbgDevice dev, uint32_t vsm,
                                        uint32_t wp, uint32_t ln,
                                        uint32_t *depth, DebugPatch patch)
{
    CUDBG_VERIFY(depth && patch, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments\n");

    *depth = patch->depth;

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_readUserEntryFramePC(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                 uint32_t ln, bool *found, uint64_t *physPC)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t userPC = 0;
    uint64_t nextPC = 0;
    uint32_t call_depth = 0;
    bool inGlobalSyscall = false, inSyscall = false, inPatch = false;
    bool inMemcheckPatch = false;
    DebugPatch patch = NULL;
    int32_t i = 0;
    uint32_t patchDepth = 0;

    *found = false;

    /* Find the correct PC for this lane, accounting for divergence */
    if (dev->smState[vsm].warp[wp].activeMask & (1U << ln)) {
        res = dev->halo.readPC(dev, vsm, wp, &userPC);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to readPC failed (res=%d)\n", res);
            return res;
        }
    }
    else {
        res = dev->halo.findDivergedCRS_PC(dev, vsm, wp, ln, &userPC);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to findDivergedCRS_PC failed (res=%d)\n", res);
            return res;
        }
    }

    HALO_TRACE_FUNCTION(10,
                        "Found sm%d/wp%d/ln%d at PC:0x%" PRIx64 "\n",
                        vsm, wp, ln, *physPC);

    /* Resolve from a MEMBAR back into a previous frame if required */
    res = dev->halo.checkForHwWar(dev, vsm, wp, ln, &inPatch, &userPC,
                                      &patchDepth);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to checkForMembarWar failed\n");
        return res;
    }

    res = dev->haloClient->inGlobalSyscallPatch(dev, userPC, &patch, &inGlobalSyscall);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to inGlobalSyscallPatch failed. Initial check.\n");
        return res;
    }

    if (inGlobalSyscall) {
        *found = false;
        return CUDBG_SUCCESS;
    }

    res = dev->haloClient->inMemcheckPatch(dev, userPC, &inMemcheckPatch);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to inMemcheckPatch failed. Initial check.\n");
        return res;
    }

    /* WAR to fix memcheck with cnp apps on SM70 by short-circuiting
       readUserEntryFramePC for memcheck patches. */
    if (inMemcheckPatch) {
        *found = false;
        patch = (DebugPatch)toolsRangeMapLookupByAddr(dev->activeContext->gpuAddrToPatch, userPC);

        if (patch) {
            if (!patch->multiEntry)
                *physPC = patch->entryAddr;
            else {
                res = dev->halo.mcinterop_getPatchPC(dev, vsm, wp, ln, physPC);
                if (res != CUDBG_SUCCESS) {
                    CUDBG_ERROR("Failed to get the memcheck patch pc in readUserEntryFramePC.\n");
                    return res;
                }
            }
            *found = true;
        }
        return CUDBG_SUCCESS;
    }

    res = dev->halo.readCallDepth(dev, vsm, wp, ln, &call_depth);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to readCallDepth failed\n");
        return res;
    }

    if (call_depth) {
        for (i = call_depth - 1; i >= 0; --i) {
            res = dev->halo.readReturnAddress(dev, vsm, wp, ln, i, &nextPC);
            if (res != CUDBG_SUCCESS) {
                HALO_ERROR("Call to readReturnAddress failed.\n");
                return res;
            }

            res = dev->haloClient->inGlobalSyscallPatch(dev, nextPC, &patch, &inGlobalSyscall);
            if (res != CUDBG_SUCCESS) {
                HALO_ERROR("Call to inGlobalSyscallPatch failed\n");
                return res;
            }

            /* If in a global syscall, go to the next frame */
            if (inGlobalSyscall)
                continue;

            res = dev->haloClient->inSyscallPatch(dev, nextPC, &patch, &inSyscall);
            if (res != CUDBG_SUCCESS) {
                HALO_ERROR("Call to inSyscallPatch failed\n");
                return res;
            }

            /* Keep going */
            if (inSyscall)
                continue;

            *found = true;
            *physPC = (uint64_t)nextPC;

            HALO_TRACE_FUNCTION(10, "Found entry frame for sm%d/wp%d/ln%d at frame %d. PC:0x%" PRIx64 "\n",
                                vsm, wp, ln, i, *physPC);
            return CUDBG_SUCCESS;
        }

        /* If the frame unwind did not find any user frames, it is possible that the
           PC at the top of CRS is in user code. For final sanity, check if this PC
           is inside a syscall frame or a user frame.
           Note that if there was a MEMBAR patch in the way, that has already been
           resolved back into its caller's code */
        res = dev->haloClient->inSyscallPatch(dev, userPC, &patch, &inSyscall);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to inSyscallPatch failed. Initial check.\n");
            return res;
        }

        if (!inSyscall) {
            *found = true;
            *physPC = userPC;
            HALO_TRACE_FUNCTION(10, "Found entry frame for sm%d/wp%d/ln%d at frame 0. PC:0x%" PRIx64 "\n",
                                vsm, wp, ln, *physPC);
            return CUDBG_SUCCESS;
        }
    }
    else {
        *found = true;
        *physPC = (uint64_t)userPC;
        HALO_TRACE_FUNCTION(10, "Found user code for sm%d/wp%d/ln%d. PC:0x%" PRIx64 "\n",
                            vsm, wp, ln, *physPC);
        return res;
    }

    *found = false;

    return res;
}

static CUDBGResult
volta_gv10x_ldcWAR_getPatchReg(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                               uint32_t ln, uint32_t regno,
                               uint32_t *hasSpilled, uint32_t *regval)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t offset = 0;

    /* Volta LDC WAR spills R2, R3 */
    switch (regno) {
    case 2:
        offset = VOLTA_LMEM_HI_LDC_WAR_SPILL_R2;
        *hasSpilled = 1;
        break;
    case 3:
        offset = VOLTA_LMEM_HI_LDC_WAR_SPILL_R3;
        *hasSpilled = 1;
        break;
    default :
        *hasSpilled = 0;
        break;
    };

    if (!*hasSpilled) {
        return CUDBG_SUCCESS;
    }

    CUDBG_VERIFY(offset, CUDBG_ERROR_UNKNOWN, "LDC WAR offset not set\n");

    res = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                    offset,
                                    regval, sizeof(*regval));
    return res;
}

static CUDBGResult
volta_gv10x_ldcWAR_setPatchReg(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                               uint32_t ln, uint32_t regno,
                               uint32_t *hasSpilled, const uint32_t *regval)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t offset = 0;

    /* Volta LDC WAR spills R2, R3 */
    switch (regno) {
    case 2:
        offset = VOLTA_LMEM_HI_LDC_WAR_SPILL_R2;
        *hasSpilled = 1;
        break;
    case 3:
        offset = VOLTA_LMEM_HI_LDC_WAR_SPILL_R3;
        *hasSpilled = 1;
        break;
    default :
        *hasSpilled = 0;
        break;
    };

    if (!*hasSpilled) {
        return CUDBG_SUCCESS;
    }

    CUDBG_VERIFY(offset, CUDBG_ERROR_UNKNOWN, "LDC WAR offset not set\n");

    res = dev->halo.writeLocalMemory(dev, vsm, wp, ln,
                                     offset,
                                     regval, sizeof(*regval));
    return res;
}

static CUDBGResult
volta_gv10x_stub_convertPhysicalToVirtual(Halo_st *halo, uint32_t tpc,
                                          uint32_t phys_wp, uint32_t cta_id,
                                          uint32_t* vsm, uint32_t* vwp,
                                          uint32_t* vcta_id)
{
    /* As GV10x+ chips have 2 SMs/TPC there is no good way to convert tpc id
       directly to vsm.*/
    HALO_ERROR("No virtual SMs on GV10x+\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
volta_gv10x_convertVirtualToPhysical(Halo_st *halo, uint32_t vsm, uint32_t vwp,
                                     uint32_t vcta_id, uint32_t* tpc,
                                     uint32_t* phys_wp, uint32_t* cta_id)
{
    if (vsm) {
        *tpc = vsm / halo->deviceInfo.numSMsPrTPC;
    }

    if (phys_wp) {
        *phys_wp = vwp;
    }

    if (cta_id) {
        *cta_id = vcta_id;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
volta_gv10x_readSMESRInfo(CudbgDevice dev, uint32_t vsm, CudbgSMState_t *state,
                    HaloDebugObjMode_t debugObjMode)
{
    return fermi_readSMESRInfo(dev, vsm, state, debugObjMode);
}

static CUDBGResult
volta_gv10x_clearSMESRInfo(CudbgDevice dev, uint32_t vsm, CudbgSMState_t *state,
                     HaloDebugObjMode_t debugObjMode)
{
    return fermi_clearSMESRInfo(dev, vsm, state, debugObjMode);
}

void
haloDeviceInit_gv10x(Halo_st *halo)
{
    haloDeviceInit_gp10x(halo);

    /* architectural constants - always init after base chip init */
    halo->deviceInfo.spRegisterNumber = VOLTA_ABI_SP;
    halo->deviceInfo.systemStackPointer = VOLTA_SYSTEM_STACK_POINTER;
    halo->deviceInfo.lmemSavedReturnPC = VOLTA_LMEM_SAVED_RETURN_PC;
    halo->deviceInfo.lmemSavedMExited = VOLTA_LMEM_SAVED_MEXITED;
    halo->deviceInfo.rpcRegisterNumber = VOLTA_ABI_RPC_LO;
    halo->deviceInfo.cilpBufferSizePerSM = sizeof(CUvoltaSMCILPBuffer);
    halo->deviceInfo.scratchpadSize = sizeof(VoltaScratchpad_t);

    /* Scratchpad/preemption buffer accessors */
    halo->getScratchpadSharedMemDevVaddr = volta_gv10x_getScratchpadSharedMemDevVaddr;
    halo->getNumRegistersForGrid = volta_gv10x_getNumRegistersForGrid;
    halo->readCCRegister = volta_gv10x_readCCRegister;
    halo->getSavedSPLmemAddr = volta_gv10x_getSavedSPLmemAddr;
    halo->getPauseReasonTableWarpOffset = volta_gv10x_getPauseReasonTableWarpOffset;
    halo->getRegisterCount  = volta_gv10x_getRegisterCount;

    /* Redirect some SM state info to scratchpad */
    halo->readSMWarpESRInfo = volta_gv10x_readSMWarpESRInfo;

    /* PC & active mask accessors - now managed by preemption buffer CBU state information */
    halo->readPC = volta_gv10x_readPC;
    halo->writePC = volta_gv10x_writePC;
    halo->readActiveMask = volta_gv10x_readActiveMask;
    halo->adjustActiveMask = volta_gv10x_adjustActiveMask;

    /* call stack unwinding accessors - for volta, these will require the use
       of .debug_frame DWARF information */
    halo->readCallDepth = volta_gv10x_readCallDepth;
    halo->readSyscallCallDepth = volta_gv10x_readSyscallCallDepth;
    halo->readReturnAddress = volta_gv10x_readReturnAddress;
    halo->findSyscallEntryPoint = volta_gv10x_findSyscallEntryPoint;

    /* CRS stubs and overrides - no more CRS any more, most of these are stubs */
    halo->maxCRSEntriesPerWarp = volta_gv10x_maxCRSEntriesPerWarp;
    halo->collectWarpCRS = volta_gv10x_collectWarpCRS;
    halo->getWarpCRSUsage = volta_gv10x_getWarpCRSUsage;
    halo->findDivergedCRS_Entry = volta_gv10x_findDivergedCRS_Entry;
    halo->findDivergedCRS_Mask = volta_gv10x_findDivergedCRS_Mask;
    halo->findDivergedCRS_PC = volta_gv10x_findDivergedCRS_PC;
    halo->flattenCRS = volta_gv10x_flattenCRS;
    halo->updateCRS = volta_gv10x_updateCRS;
    halo->verifyCRSxsum = volta_gv10x_verifyCRSxsum;
    halo->cleanup = volta_gv10x_cleanup;
    halo->clearSMState = volta_gv10x_clearSMState;

    /* Instruction overrides */
    halo->insertBreakpoint = volta_gv10x_insertBreakpoint;
    halo->removeBreakpoint = volta_gv10x_removeBreakpoint;
    halo->isTerminalInstructionAtPC = volta_gv10x_isTerminalInstructionAtPC;
    halo->isInternalInstructionAtPC = volta_gv10x_isInternalInstructionAtPC;
    halo->isSteppable = volta_gv10x_isSteppable;
    halo->fillDisassemblyBuffer = volta_gv10x_fillDisassemblyBuffer;
    halo->disablePairingMode = volta_gv10x_disablePairingMode;
    halo->enablePairingMode = volta_gv10x_enablePairingMode;

    /* PRI overrides */
    halo->mapGpcTpcSm = volta_gv10x_mapGpcTpcSm;
    halo->getPRIOffset = volta_gv10x_getPRIOffset;
    halo->getFloorsweptSmIdFromSubcontext = volta_gv10x_getFloorsweptSmIdFromSubcontext;
    halo->readWarpMaskPRI = volta_gv10x_readWarpMaskPRI;
    halo->writeWarpMaskPRI = volta_gv10x_writeWarpMaskPRI;
    halo->getWarpMaskPRIOffset = volta_gv10x_getWarpMaskPRIOffset;

    /* mcinterop overrides */
    halo->mcinterop_getPatchPC = volta_gv10x_mcinterop_getPatchPC;

    /* DCI overrides */
    halo->getGridParamsOffsetGridId   = volta_gv10x_getGridParamsOffsetGridId;
    halo->getGridParamsOffsetBlockDim = volta_gv10x_getGridParamsOffsetBlockDim;
    halo->getGridParamsOffsetGridDim = volta_gv10x_getGridParamsOffsetGridDim;
    halo->getGridParamsOffsetStartPc = volta_gv10x_getGridParamsOffsetStartPc;

    /* CNP overrides */
    halo->findParentGrid = volta_gv10x_findParentGrid;
    halo->getUserEntryFunction = volta_gv10x_getUserEntryFunction;

    halo->readExitedMask = volta_gv10x_readExitedMask;

    /* Scratchpad access */

    halo->scratchpad.getFieldOffset = volta_gv10x_scratchpad_getFieldOffset;

    halo->scratchpad.read_CRSSize = volta_gv10x_scratchpad_read_CRSSize;
    halo->scratchpad.read_gridId = volta_gv10x_scratchpad_read_gridId;
    halo->scratchpad.read_warpErrorPC = volta_gv10x_scratchpad_read_warpErrorPC;
    halo->scratchpad.read_selfQMD = volta_gv10x_scratchpad_read_selfQMD;
    halo->scratchpad.read_lmemBase = volta_gv10x_scratchpad_read_lmemBase;
    halo->scratchpad.read_CRSPtr = volta_gv10x_stub_scratchpad_read_CRSPtr;
    halo->scratchpad.read_curPhysStackDepth = volta_gv10x_stub_scratchpad_read_curPhysStackDepth;
    halo->scratchpad.read_paramConstDptr = volta_gv10x_scratchpad_read_paramConstDptr;
    halo->scratchpad.read_subcontextVSMId = volta_gv10x_scratchpad_read_subcontextVSMId;
    halo->scratchpad.read_registerCount = volta_gv10x_scratchpad_read_registerCount;
    halo->scratchpad.read_warpActiveMask = volta_gv10x_scratchpad_read_warpActiveMask;
    halo->scratchpad.read_warpExitedMask = volta_gv10x_scratchpad_read_warpExitedMask;
    halo->scratchpad.read_warpTrapRPC = volta_gv10x_scratchpad_read_warpTrapRPC;

    halo->scratchpad.write_warpTrapRPC = volta_gv10x_scratchpad_write_warpTrapRPC;

    /* Preemption buffer access */

    halo->preemptionBuffer.getFieldOffset = volta_gv10x_preemptionBuffer_getFieldOffset;

    halo->preemptionBuffer.read_warpExitedMask = volta_gv10x_preemptionBuffer_read_warpExitedMask;
    halo->preemptionBuffer.read_CC = volta_gv10x_stub_preemptionBuffer_read_CC;
    halo->preemptionBuffer.read_RPC = volta_gv10x_preemptionBuffer_read_RPC;

    halo->preemptionBuffer.write_warpTrapRPC = volta_gv10x_preemptionBuffer_write_warpTrapRPC;

    /* Membar WAR read PC */
    halo->membarWAR_getPatchPC  = volta_gv10x_membarWAR_getPatchPC;

    /* Membar WAR read call depth */
    halo->membarWAR_getPatchCallDepth = volta_gv10x_membarWAR_getPatchCallDepth;
    halo->readUserEntryFramePC = volta_gv10x_readUserEntryFramePC;

    /* LDC WAR */
    halo->ldcWAR_getPatchReg = volta_gv10x_ldcWAR_getPatchReg;
    halo->ldcWAR_setPatchReg = volta_gv10x_ldcWAR_setPatchReg;

    /* SM virtualization overrides */
    halo->convertPhysicalToVirtual = volta_gv10x_stub_convertPhysicalToVirtual;
    halo->convertVirtualToPhysical = volta_gv10x_convertVirtualToPhysical;
    halo->readSMESRInfo = volta_gv10x_readSMESRInfo;
    halo->clearSMESRInfo = volta_gv10x_clearSMESRInfo;
}
