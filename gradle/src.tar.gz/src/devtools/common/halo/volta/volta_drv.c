/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "cuda_types.h"
#include "halo_drv.h"
#include "pascal_drv.h"
#include "volta_drv.h"
#include "volta.h"

static CUDBGResult
haloDrvAdjustCodeAddress_volta(uint64_t physAddr,
                               uint64_t *adjustedPhysAddr,
                               CUDBGAdjAddrAction adjAction);

static CUDBGResult
haloDrvIsStackPointerAssignment_volta(uint64_t instruction[2],
                                      int32_t *res, uint32_t *assignmentIdx);

static CUDBGResult
haloDrvGetInstructionSize_volta(uint64_t instruction, uint32_t *instSize);

CUDBGResult
getHaloDrvFuncPtrs_volta(struct HaloDrvFuncPtrs *ptrs)
{
    CUDBGResult res;

    res = getHaloDrvFuncPtrs_pascal(ptrs);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Override the functions that are different between pascal and volta */
    ptrs->adjustCodeAddress = haloDrvAdjustCodeAddress_volta;
    ptrs->isStackPointerAssignment = haloDrvIsStackPointerAssignment_volta;
    ptrs->getInstructionSize = haloDrvGetInstructionSize_volta;

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDrvAdjustCodeAddress_volta(uint64_t physAddr,
                               uint64_t *adjustedPhysAddr,
                               CUDBGAdjAddrAction adjAction)
{
    CUDBG_VERIFY(adjustedPhysAddr, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    switch (adjAction) {
    case CUDBG_ADJ_PREVIOUS_ADDRESS:
        *adjustedPhysAddr = physAddr - 16;
        break;
    case CUDBG_ADJ_NEXT_ADDRESS:
        *adjustedPhysAddr = physAddr + 16;
        break;
    case CUDBG_ADJ_CURRENT_ADDRESS:
        *adjustedPhysAddr = physAddr;
        break;
    default:
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDrvIsStackPointerAssignment_volta(uint64_t instruction[2],
                                      int32_t *res, uint32_t *assignmentIdx)
{
    /* Volta ABI: R1 is the stack pointer, which is initialized
       with a value placed in constant bank 0 at offset 0x28 (Volta DCI).
       Typically, the MOV instruction is used to do this, but we'll
       also catch the case that LDC is used as well */
    const uint16_t VOLTA_DCI_CBANK_OFFSET = 0x28;

    /* Because opexes are encoded in the instruction on volta, we mask and compare here */
    const uint64_t VOLTA_GV10x_MOV_R1_C_MASK_LO = 0x07FFFFC000FFFFFFULL;
    const uint64_t VOLTA_GV10x_MOV_R1_C_LO      = 0x0000000000017A02ULL | ((uint64_t)VOLTA_DCI_CBANK_OFFSET << 38);
    const uint64_t VOLTA_GV10x_LDC_R1_C_MASK_LO = 0x07FFFFC0FFFF0FFFULL;
    const uint64_t VOLTA_GV10x_LDC_R1_C_LO      = 0x0000000000010B82ULL | ((uint64_t)VOLTA_DCI_CBANK_OFFSET << 38);

    CUDBG_VERIFY(res && assignmentIdx, CUDBG_ERROR_INVALID_ARGS, "Invalid args in isStackPointerAssignment.\n");

    if ((instruction[0] & VOLTA_GV10x_MOV_R1_C_MASK_LO) == VOLTA_GV10x_MOV_R1_C_LO || 
        (instruction[0] & VOLTA_GV10x_LDC_R1_C_MASK_LO) == VOLTA_GV10x_LDC_R1_C_LO) {
        *res = 1;
        *assignmentIdx = 0;
    }
    else
        *res = 0;

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDrvGetInstructionSize_volta(uint64_t instruction, uint32_t *instSize)
{
    *instSize = VOLTA_GV10X_INSTRUCTION_SIZE;
    return CUDBG_SUCCESS;
}
