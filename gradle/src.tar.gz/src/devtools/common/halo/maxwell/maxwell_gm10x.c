/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: maxwell_gm10x.c
 *
 *   Description:
 *       Internal API for the low-level GPU access needed to support
 *       the debugger on Maxwell (GM10x).
 *
 ******************************************************************************/

#include "fermi_exports.h"
#include "maxwell.h"
#include "maxwell_gm10x.h"
#include "kepler.h"
#include "halo_internal.h"
#include "halo_state.h"
#include "maxwell/gm107/dev_graphics_nobundle.h"
#include "maxwell/gm107/dev_top.h"
#include "maxwell/gm107/dev_pri_ringmaster.h"
#include "rm_call.h"
#include "rm_device.h"
#include "common_device.h"
#include "gm10x_sass_assembler.h"
#include "maxwell/maxwell_structs.h"
#include "hal/maxwell/maxwell_cnp.h"
#include "cuda_macros.h"

CUDBGResult
maxwell_gm10x_getInfo(CudbgDevice dev)
{
    CUDBGResult res;

    res = kepler_gk11x_getInfo(dev);

    /* Overwrite the constants that are different */
    dev->halo.deviceInfo.numRegsPrLane   = CUDBG_MAX_REG_MAXWELL;
    dev->halo.deviceInfo.maxGPCsPrDevice = CUDBG_MAX_GPC_MAXWELL;

    /* Account for different opcodes on GM10x */
    dev->halo.deviceInfo.bpt64Inst = MAXWELL_GM10X_BREAKPT64;

    dev->halo.deviceInfo.lmemHiMembarWarSpillR2 = MAXWELL_LMEM_HI_MEMBAR_WAR_SPILL_R2;
    dev->halo.deviceInfo.lmemHiMembarWarSpillR3 = MAXWELL_LMEM_HI_MEMBAR_WAR_SPILL_R3;
    return res;
}

static int32_t
maxwell_gm10x_isCall(CudbgDevice dev, uint64_t instruction)
{
    /* GK11X:  CALL Instruction Masks */
    const uint64_t MAXWELL_GM10x_CALL_OP_MASK = 0xfff0000000000000ULL;
    const uint64_t MAXWELL_GM10x_CALL_OP      = 0xe260000000000000ULL;

    if ((instruction & MAXWELL_GM10x_CALL_OP_MASK) == MAXWELL_GM10x_CALL_OP)
        return 1;
    else
        return 0;

}

static int32_t
maxwell_gm10x_isBarrier(CudbgDevice dev, uint64_t instruction)
{
    /* GK11X:  BAR Instruction Masks */
    const uint64_t MAXWELL_GM10x_BAR_OP_MASK = 0xfff8000000000000ULL;
    const uint64_t MAXWELL_GM10x_BAR_OP      = 0xf0a8000000000000ULL;

    if ((instruction & MAXWELL_GM10x_BAR_OP_MASK) == MAXWELL_GM10x_BAR_OP)
        return 1;
    else
        return 0;
}

static int32_t
maxwell_gm10x_isExit(CudbgDevice dev, uint64_t instruction)
{
    return (instruction & BF_MASK(GM10X_FIELD_Opcode12)) == GM10X_OPCODE_EXITBRU_PIPE;
}

static int32_t
maxwell_gm10x_isRet(CudbgDevice dev, uint64_t instruction)
{
    return (instruction & BF_MASK(GM10X_FIELD_Opcode12)) == GM10X_OPCODE_RETBRU_PIPE;
}

static int32_t
maxwell_gm10x_isContinuation(CudbgDevice dev, uint64_t instruction)
{
    /* GK11X:  CONTINUATION Instruction Masks (BPT.TRAP 2) */
    const uint64_t MAXWELL_GM10x_CONTINUATION_OP_MASK = 0xfff000fffff001c0ULL;
    const uint64_t MAXWELL_GM10x_CONTINUATION_OP      = 0xe3a00000002000c0ULL;

    if ((instruction & MAXWELL_GM10x_CONTINUATION_OP_MASK) == MAXWELL_GM10x_CONTINUATION_OP)
        return 1;
    else
        return 0;
}

static CUDBGResult
maxwell_gm10x_isTerminalInstructionAtPC(Context ctx, uint64_t pc, bool *isExitingInstruction)
{
    uint64_t inst;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(ctx && isExitingInstruction, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    res = ctx->dev->halo.readCodeMemory(ctx, pc, &inst, sizeof inst);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Error reading pc %#" PRIx64 "\n", inst);

    *isExitingInstruction = maxwell_gm10x_isExit(ctx->dev, inst) || maxwell_gm10x_isRet(ctx->dev, inst);

    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_isInternalInstructionAtPC(CudbgDevice dev, uint64_t inst,
                                        uint64_t gpuAddr, bool *isInternalInstruction)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(isInternalInstruction, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args in maxwell_gm10x_isInternalInstructionAtPC\n");

    /* initialize to false (not an internal instruction) */
    *isInternalInstruction = false;

    /* On Maxwell, opcode extensions are store on 32-byte boundaries */
    if ((gpuAddr & 0x1FU) == 0) {
        HALO_TRACE(2, "  Found an internal opcode extention!\n");
        *isInternalInstruction = true;
        return CUDBG_SUCCESS;
    }

    return res;
}

static CUDBGResult
maxwell_gm10x_insertBreakpoint(Context context, uint64_t vaddr, BreakpointContents *buf)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CudbgDevice dev;
    uint64_t opExVaddr = MAXWELL_GM10X_OPEX_ADDR(vaddr);
    uint64_t origOpEx;
    uint64_t modifiedOpEx;

    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context in insertBreakpoint.\n");

    if (MAXWELL_GM10X_IS_OPEX_ADDR(vaddr))
        return CUDBG_ERROR_INVALID_ADDRESS;

    dev = context->dev;

    if (!CUDBG_DEBUG_OBJECT_IS_VALID(context->debugObj)) {
        /* This can happen if no ctx creation callback has been received yet
           during early stages of the app, or during shutdown. */
        HALO_TRACE_FUNCTION(50, "No debug object found, skipping breakpoint insertion.\n");
        return CUDBG_ERROR_INVALID_CONTEXT;
    }

    buf->savedInstructionSize = sizeof(uint64_t);

    res = dev->halo.readDeviceMemory(context, vaddr, buf->savedInstruction, buf->savedInstructionSize);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Error reading code mem at addr %" PRIx64 " (res = %d)\n", vaddr, res);
        return res;
    }

    res = dev->halo.writeDeviceMemory(context, vaddr, &dev->halo.deviceInfo.bpt64Inst, sizeof dev->halo.deviceInfo.bpt64Inst);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Error writing code mem at addr %" PRIx64 " (res = %d)\n", vaddr, res);
        return res;
    }

    /* Read-modify-write the original OpEx back */
    res = dev->halo.readDeviceMemory(context, opExVaddr, &origOpEx, sizeof origOpEx);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Error reading opcode extension at addr %" PRIx64 " (res = %d)\n", opExVaddr, res);
        return res;
    }

    /* Only save the opex for the instruction we are modifying.
       Save the shifted OpEx to make debugging easier. */
    buf->savedOpEx = (origOpEx & MAXWELL_GM10X_OPEX_MASK(vaddr)) >> MAXWELL_GM10X_OPEX_SHIFT(vaddr);

    modifiedOpEx = MAXWELL_GM10X_OPEX_MODIFY(origOpEx, vaddr, MAXWELL_GM10X_OPEX_WAIT5_NO_SB);

    res = dev->halo.writeDeviceMemory(context, opExVaddr, &modifiedOpEx, sizeof modifiedOpEx);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Error writing opcode extension at addr %" PRIx64 " (res = %d)\n", opExVaddr, res);
        return res;
    }

    /* Set the device's code memory as dirty */
    dev->codeIsDirty = 1;

    HALO_TRACE_FUNCTION(1, "Breakpoint inserted at 0x%" PRIx64 ". Original instruction was 0x%" PRIx64 "\n",
                        vaddr, buf->savedInstruction[0]);
    HALO_TRACE_FUNCTION(1, "WAIT5_NO_SB inserted at 0x%" PRIx64 ". Original opex was 0x%" PRIx64 "\n",
                        opExVaddr, buf->savedOpEx);

    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_isWarpOnBarrier(CudbgDevice dev, uint32_t vsm,
                              uint32_t wp, bool *isOnBarrier)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(isOnBarrier, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments in isWarpOnBarrier.\n");

    /* It is not an error to not have an active context when this is
       called, however, we cannot attempt to map memory if that's the
       case.  Simply return success here. */
    if (!dev->activeContext || !haloStateContextIsActive(dev->activeContext))
        return CUDBG_SUCCESS;

    res = dev->halo.scratchpad.read_isWarpOnBarrier(dev->activeContext->scratchpadAccessor, vsm, wp, isOnBarrier);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read warp barrier state\n");

    return res;
}

/* Returns true in *isSteppable if the instruction at PC can be stepped,
   false otherwise. If not steppable, *breakAddr will contain the PC
   address where to insert a breakpoint to step that instruction, and
   *breakMask will contain the mask of warps to resume (low bit means
   resume). Otherwise, *breakAddr and *breakMask are untouched. */
static CUDBGResult
maxwell_gm10x_isSteppable(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                          uint64_t pc, bool inPatch, uint64_t *breakAddr,
                          CUwarpBitmask *breakMask, bool *isSteppable,
                          bool *requiresExitStep)
{
    Grid grid;
    uint64_t inst;
    CUDBGResult res;
    bool isWarpOnBarrier = false;

    CUDBG_VERIFY((breakAddr && breakMask && isSteppable && requiresExitStep),
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments in isSteppable.\n");

    CUDBG_VERIFY((vsm < dev->halo.deviceInfo.numSMs), CUDBG_ERROR_INVALID_SM, "Invalid vsm in isSteppable.\n");

    CUDBG_VERIFY(warpBitmaskGetBits(&dev->smState[vsm].state.tidValid, wp, 1),
                 CUDBG_ERROR_INVALID_WARP,
                 "Invalid warp in isSteppable.\n");

    /* Initialize default behavior */
    *breakAddr        = ~0U;
    warpBitmaskFill(breakMask, 1);
    *isSteppable      = true;
    *requiresExitStep = false;

    res = dev->halo.readCodeMemory(dev->activeContext, pc, &inst, sizeof inst);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read memory from offset 0x%08x\n", pc);
        return res;
    }

    /* GM10x/CNP:  We need to avoid step-resumes (more importantly, inserting
       a BPT.TRAP) while we are stepping through a region of code that is
       protected with IDE.DIS).  So, if this is the case, then always mark
       the instruction as being steppable (without actually checking the
       instruction itself). */
    if (dev->smState[vsm].state.inIDECS) {
        HALO_TRACE(2, "SM%d in IDE CS, all instructions considered steppable\n", vsm);
        *isSteppable = true;
        return CUDBG_SUCCESS;
    }

    grid = haloStateDeviceGetGrid(dev, dev->smState[vsm].warp[wp].gridId64);
    CUDBG_VERIFY(grid && grid->function && grid->function->module,
                 CUDBG_ERROR_INTERNAL,
                 "Invalid grid\n");

    if (grid->function->module->abiVersion < ELFOSABIV_ABI && maxwell_gm10x_isCall(dev, inst)) {
        HALO_TRACE(2, "  Found an unsteppable call at pc = %x\n", pc);
        warpBitmaskFill(breakMask, 1);
        warpBitmaskSetBits(breakMask, wp, 1, 0);
        *breakAddr = pc + 8;
        if (MAXWELL_GM10X_IS_OPEX_ADDR(*breakAddr))
            *breakAddr += 8;
        *isSteppable = false;
        return CUDBG_SUCCESS;
    }

    /* If the PC indicates we're on a barrier, trust that first.  Otherwise,
       rely on this warp's barrier state to determine if it's waiting on
       a barrier. */
    if (maxwell_gm10x_isBarrier(dev, inst)) {
        uint32_t tmpWp;
        CudbgWarp_t *warpState = &dev->smState[vsm].warp[0];
        HALO_TRACE(2, "  Found an unsteppable barrier at pc = %x\n", pc);
        /* Need to resume all warps in the same cta as this warp */
        warpBitmaskFill(breakMask, 1);
        warpBitmaskSetBits(breakMask, wp, 1, 0);
        for (tmpWp = 0; tmpWp < dev->halo.deviceInfo.numWarpsPrSM; ++tmpWp)
            if (haloWarpsInSameCTA(dev, vsm, wp, tmpWp))
                warpBitmaskSetBits(breakMask, tmpWp, 1, 0);
        *breakAddr = pc + 8;
        if (MAXWELL_GM10X_IS_OPEX_ADDR(*breakAddr))
            *breakAddr += 8;
        *isSteppable = false;
        return CUDBG_SUCCESS;
    }

    /* This warp's PC isn't pointing at a barrier, but it could still be
       waiting on one due to how Kepler's BRU works.  If the following
       check succeeds, B2R.WARP state indicates this warp is waiting on
       a barrier, which means we need to break at *this* PC. */
    res = maxwell_gm10x_isWarpOnBarrier(dev, vsm, wp, &isWarpOnBarrier);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to isWarpOnBarrier failed (res=%d)\n", res);
        return res;
    }

    if (isWarpOnBarrier) {
        uint32_t tmpWp;
        CudbgWarp_t *warpState = &dev->smState[vsm].warp[0];
        HALO_TRACE(2, "  Found an unsteppable barrier at pc = %x\n", pc);
        /* Need to resume all warps in the same cta as this warp */
        warpBitmaskFill(breakMask, 1);
        warpBitmaskSetBits(breakMask, wp, 1, 0);
        for (tmpWp = 0; tmpWp < dev->halo.deviceInfo.numWarpsPrSM; ++tmpWp)
            if (haloWarpsInSameCTA(dev, vsm, wp, tmpWp))
                warpBitmaskSetBits(breakMask, tmpWp, 1, 0);
        *breakAddr = pc;
        if (MAXWELL_GM10X_IS_OPEX_ADDR(*breakAddr))
            *breakAddr += 8;
        *isSteppable = false;
        return CUDBG_SUCCESS;
    }

    /* GM10x/CNP:  Resume the entire SM over BPT.TRAP 2, in order to allow
       continuations to properly occur. */
    if (maxwell_gm10x_isContinuation(dev, inst)) {
        HALO_TRACE(2, "  Found an unsteppable continuation at pc = %x\n", pc);
        warpBitmaskClear(breakMask); /* The entire SM resumes */
        *breakAddr = pc + 8;
        if (MAXWELL_GM10X_IS_OPEX_ADDR(*breakAddr))
            *breakAddr += 8;
        *isSteppable = false;
        return CUDBG_SUCCESS;
    }

    /* GM10X _should_ have fixed the MULTI bug (On GK10X, MULTI instructions will
       sometimes cause 2 instructions to be stepped).  We'll ignore them here
       unless emulation shows otherwise. */

    *isSteppable = true;
    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_removeBreakpoint(Context context, uint64_t vaddr, const BreakpointContents *buf)
{
    CUDBGResult res;
    CudbgDevice dev;
    uint64_t opExVaddr = MAXWELL_GM10X_OPEX_ADDR(vaddr);
    uint64_t currentOpEx;

    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context in removeBreakpoint.\n");
    CUDBG_VERIFY(buf->savedInstructionSize > 0, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    if (MAXWELL_GM10X_IS_OPEX_ADDR(vaddr))
        return CUDBG_ERROR_INVALID_ADDRESS;

    dev = context->dev;

    res = dev->halo.writeDeviceMemory(context, vaddr, buf->savedInstruction, buf->savedInstructionSize);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Error writing code mem at addr %" PRIx64 " (res = %d)\n", vaddr, res);
        return res;
    }

    /* Read-modify-write the original OpEx back */

    res = dev->halo.readDeviceMemory(context, opExVaddr, &currentOpEx, sizeof currentOpEx);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Error reading opcode extension at addr %" PRIx64 " (res = %d)\n", opExVaddr, res);
        return res;
    }

    /* Restore the opex */
    currentOpEx &= ~MAXWELL_GM10X_OPEX_MASK(vaddr);
    currentOpEx |= (buf->savedOpEx << MAXWELL_GM10X_OPEX_SHIFT(vaddr));

    res = dev->halo.writeDeviceMemory(context, opExVaddr, &currentOpEx, sizeof currentOpEx);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Error writing opcode extension at addr %" PRIx64 " (res = %d)\n", opExVaddr, res);
        return res;
    }

    /* Set the device's code memory as dirty */
    dev->codeIsDirty = 1;

    HALO_TRACE_FUNCTION(1, "Breakpoint removed at 0x%" PRIx64 ". Original instruction was 0x%" PRIx64 "\n",
                        vaddr, buf->savedInstruction[0]);
    HALO_TRACE_FUNCTION(1, "WAIT5_NO_SB removed at 0x%" PRIx64 ". Original opex was 0x%" PRIx64 "\n",
                        opExVaddr, buf->savedOpEx);

    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_patchDynamicRegisterRead(CudbgDevice dev, uint32_t regnum, uint32_t lmemAddr)
{
    CUDBGResult res;
    Context ctx;
    uint64_t pc, inst;

    CUDBG_VERIFY(dev->activeContext, CUDBG_ERROR_INVALID_CONTEXT, "No active context in patchDynamicRegisterRead.\n");

    /* Update the STL instruction at thRdRegOffset in the trap handler
       to account for the requested register. */
    ctx = dev->activeContext;
    pc = (ctx->thCodeVA + ctx->thRdRegOffset) - ctx->funcMemBaseVA;
    inst = GM10X_INST_STL_ALL(PT, COP_CA, LDST_32, RZ, lmemAddr, regnum);

    res = dev->halo.writeCodeMemory(ctx, pc, &inst, sizeof inst);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to write code memory at offset 0x%08x (res=%d)\n", pc, res);
        return res;
    }

    HALO_TRACE_FUNCTION(1, "Wrote instruction to 0x%" PRIx64 ": 0x%" PRIx64 "\n", pc, inst);

    /* Need to invalidate the I-Cache, since we're
       patching code memory in the trap handler. */
    res = dev->halo.invalidateICache(dev);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to invalidate icache (res=%d)\n", res);
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_patchDynamicRegisterWrite(CudbgDevice dev, uint32_t regnum, uint32_t regval)
{
    CUDBGResult res;
    Context ctx;
    uint64_t pc, inst;

    CUDBG_VERIFY(dev->activeContext, CUDBG_ERROR_INVALID_CONTEXT, "No active context in patchDynamicRegisterWrite.\n");

    /* Update the MOV32I instruction at thWrRegOffset in the trap handler
       to account for the requested register and value. */
    ctx = dev->activeContext;
    pc = (ctx->thCodeVA + ctx->thWrRegOffset) - ctx->funcMemBaseVA;
    /* @P0 MOV32I R<regnum>, <regval> 
       Last arg is Pixel Enable Mask, which is unused and forced to 0xf
       (all lanes) since we're using P0 to mask the lanes.*/
    inst = GM10X_INST_MOV32I_ALL(0x0, regnum, regval, 0xfULL);

    res = dev->halo.writeCodeMemory(ctx, pc, &inst, sizeof inst);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to write code memory at offset 0x%08x (res=%d)\n", pc, res);
        return res;
    }

    HALO_TRACE_FUNCTION(1, "Wrote instruction to 0x%" PRIx64 ": 0x%" PRIx64 "\n", pc, inst);

    /* Need to invalidate the I-Cache, since we're
       patching code memory in the trap handler. */
    res = dev->halo.invalidateICache(dev);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to invalidate icache (res=%d)\n", res);
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_verifyCRSxsum(HaloCRS_t *warpCRS, uint32_t idx)
{
    /* CRS entries do not have the checksum field populated on GM10x  */
    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_patchTextureInstruction(CudbgDevice dev, uint32_t texId, uint32_t dim,
                                      uint32_t *coords, Grid grid)
{
    CUDBGResult res;
    Context ctx;
    uint64_t pc, inst;
    uint64_t constBankOffset;

    CUDBG_VERIFY(coords, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments in patchTextureInstruction.\n");

    CUDBG_VERIFY(dev->activeContext, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context in patchTextureInstruction.\n");

    ctx = dev->activeContext;
    pc = (ctx->thCodeVA + ctx->thRdTexMemOffset) - ctx->funcMemBaseVA;

    res = dev->halo.findConstBankOffset(dev, grid->function, texId, &constBankOffset);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to find the contbank offset for texId %d (res=%d)\n", texId, res);
        return res;
    }

    res = dev->halo.readCodeMemory(ctx, pc, &inst, sizeof inst);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read code memory at offset 0x%08x (res=%d)\n", pc, res);
        return res;
    }

    /* Note about dim: ParamA is a concatenation of the "co" and "a" fields.
       dim should be filled in the "co" field, so shift it by 1. Refer to the
       SM5.0 ISA page for TLD */
    inst = (inst & ~BF_FLDV(GM10X_FIELD_TidB, 0x1FFFu)) |
           BF_FLDV(GM10X_FIELD_TidB, (constBankOffset >> 2));
    inst = (inst & ~BF_FLDV(GM10X_FIELD_ParamA, 0x3u)) |
           BF_FLDV(GM10X_FIELD_ParamA, ((dim - 1) << 1));

    res = dev->halo.writeCodeMemory(ctx, pc, &inst, sizeof inst);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to write code memory at offset 0x%08x (res=%d)\n", pc, res);
        return res;
    }

    res = dev->halo.invalidateICache(dev);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to invalidate icache (res=%d)\n", res);
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_getDynamicRegisterRange (uint32_t *dynamicRegisterStart, uint32_t *dynamicRegisterEnd)
{
    CUDBG_VERIFY(dynamicRegisterStart, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");
    CUDBG_VERIFY(dynamicRegisterEnd, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");

    *dynamicRegisterStart = MAXWELL_GM10X_DYNAMIC_REGISTER_START;
    *dynamicRegisterEnd = MAXWELL_GM10X_DYNAMIC_REGISTER_END;

    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_fillRangeWithInstruction(Context ctx, uint64_t startvaddr, uint64_t endvaddr, uint64_t inst)
{
    const uint64_t safe_opex = 0x001F8000FC0007E0ULL;
    CUDBGResult res = CUDBG_SUCCESS;
    /* This buffer size needs to be a multiple of the pattern for the opex
       instruction.  In this case, it's 4.  This allows the pattern to repeat
       without additional code. */
    const uint64_t FORCE_TERMINATION_BUFFER_SIZE = 1<<20;
    uint64_t bufSize = MIN(endvaddr - startvaddr, FORCE_TERMINATION_BUFFER_SIZE);
    uint64_t i = 0, writeSize = 0;
    uint64_t *buf = (uint64_t *)malloc((size_t)bufSize);

    CUDBG_VERIFY(buf, CUDBG_ERROR_INTERNAL, "Unable to allocate buffer space\n");

    startvaddr -= ctx->funcMemBaseVA;
    endvaddr -= ctx->funcMemBaseVA;

    for (i = 0; i < bufSize / sizeof(inst); i++) {
        if (MAXWELL_GM10X_IS_OPEX_ADDR(i*sizeof(inst) + startvaddr))
            buf[i] = safe_opex;  /* Fill with opex on scheduler addresses */
        else
            buf[i] = inst;       /* Fill with instruction otherwise */
    }

    for (; startvaddr < endvaddr; startvaddr+=writeSize) {
        writeSize = MIN(endvaddr - startvaddr, bufSize);

        res = ctx->dev->halo.writeCodeMemory(ctx, startvaddr, buf, (uint32_t)writeSize);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("failed to write memory at offset 0x%#" PRIx64 "\n", startvaddr);
            break;
        }
    }

    free(buf);
    return res;
}

typedef struct forceTerminationData_st forceTerminationData;

struct forceTerminationData_st {
    uint64_t thStartOffset;
    uint64_t thEndOffset;
    Context context;
};

static CUDBGResult
forceTerminationFunctor(haloMemoryMap *map,
                        haloMemorySegment *seg,
                        void *data)
{
    forceTerminationData *d = (forceTerminationData *)data;
    const uint64_t exit_inst = GM10X_INST_EXIT;
    const uint64_t rtt_terminate_inst = GM10X_INST_RTT_ALL(GM10X_KEYWORD_RTTOP_TERMINATE);
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(map && seg && d, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args\n");

    if (seg->type != HALO_MEM_SEG_FUNC)
        return CUDBG_SUCCESS;


    /* Fill everything with exit instructions */
    res = d->context->dev->halo.fillRangeWithInstruction(d->context,
                                                         seg->devvaddr,
                                                         (seg->devvaddr + seg->size),
                                                         exit_inst);
    if (res != CUDBG_SUCCESS)
        return res;

    if (seg->devvaddr <= d->thStartOffset && seg->devvaddr + seg->size > d->thStartOffset) {
        CUDBG_VERIFY(d->thEndOffset <= seg->devvaddr + seg->size,
                     CUDBG_ERROR_INTERNAL,
                     "Trap handler spans multiple segments!\n");
        /* Fill trap handler with rtt instructions */
        res = d->context->dev->halo.fillRangeWithInstruction(d->context,
                                                             d->thStartOffset,
                                                             d->thEndOffset,
                                                             rtt_terminate_inst);
    }

    return res;
}

static CUDBGResult
maxwell_gm10x_forceTermination(CudbgDevice dev)
{
    CUDBGResult res;
    forceTerminationData data = {0};

    /* If there is no active context or if we never launched any
       kernel for that context, there is nothing to do. */
    if (!dev->activeContext || !haloStateContextIsActive(dev->activeContext))
        return CUDBG_SUCCESS;

    /* TH Code Segment Start/End Offsets */
    data.thStartOffset = dev->activeContext->thCodeVA;
    data.thEndOffset   = data.thStartOffset + dev->activeContext->thCodeSize;
    data.context       = dev->activeContext;

    res = haloMemoryMapApplyFunctor(dev->activeContext->memMap,
                                    forceTerminationFunctor,
                                    &data);

    return res;
}

CUDBGResult
maxwell_gm10x_readSMWarpESRInfo(CudbgDevice dev, uint32_t vsm, CudbgSMState_t *state)
{
    CUDBGResult res = CUDBG_SUCCESS;

    /* Setup some initial stuff for whether the ESR warp info valid or not */
    state->esrWarpInfoValid = !!(state->esrState.hwwwarpesr);

    /* Bits 23:16 of the hwwwarpesr are the warpid, 15:0 is the error */
    state->esrWarpId = ((uint32_t)state->esrState.hwwwarpesr >> 16) & 0xff;

    state->esrWarpPC = state->esrState.hwwwarpesrpc;

    return res;
}

static CUDBGResult
maxwell_gm10x_handleGlobalErrorState(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                     uint32_t gESR,
                                     CUDBGException_t *laneException,
                                     bool *error)
{
    /* Maxwell doesnt have any global errors. All errors are at least warp precise */
    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_handleGlobalMMUErrorState(CudbgDevice dev, uint32_t vsm,
                                        uint32_t wp,
                                        CUDBGException_t *laneException,
                                        bool *error)
{
    /* Maxwell doesnt have any global errors. All errors are at least warp precise */
    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_getSavedSPLmemAddr(CudbgDevice dev, uint64_t *lmem_addr)
{
    CUDBG_VERIFY(lmem_addr,
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments\n");

    *lmem_addr = MAXWELL_LMEM_SAVED_STACK_POINTER;
    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_getSMHwwErrorPC(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint64_t *esrPC, bool *esrPCValid)
{
    CUDBG_VERIFY((esrPC && esrPCValid && dev), CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments\n");

    /* There are 3 possible cases here, for the given Dev, SM, Warp :
       1. There is no smESRInfo. This means that the SM has not hit
          any exception.
          In this case,
            *esrPCValid = false;
            return CUDBG_SUCCESS
       2. There is SM ESR info, but the reported warpId is not the given warp id.
          This is possible if multiple warps on the SM hit exceptions at the same
          time.
            *esrPCValid = false;
            return CUDBG_SUCCESS;
       3. There is SM ESR info, the reported warpid matches given warpid
          and exception type matches reported exception
            *esrPCValid = true,
            *esrPC = esrState->hwwWarpEsrPc
            return CUDBG_SUCCESS;
     */

    *esrPCValid = false;

    /* Case 1 : No SM ESR info */
    if (!dev->smState[vsm].state.esrWarpInfoValid)
        return CUDBG_SUCCESS;

    /* Case 2 : Warp is not the one that hit the exception */
    if (dev->smState[vsm].state.esrWarpId != wp)
        return CUDBG_SUCCESS;

    /* Case 3 : Return PC info */
    *esrPCValid = true;
    *esrPC = (uint64_t)dev->smState[vsm].state.esrWarpPC;

    return CUDBG_SUCCESS;
}

/* Get offset of gridId in GridParams. This is DCI dependent, hence halified. */
static CUDBGResult
maxwell_gm10x_getGridParamsOffsetGridId (CudbgDevice dev, uint64_t *offset)
{
    CUDBG_VERIFY(offset, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");

    *offset = ((uint64_t)(uintptr_t)&((CUmaxwellGridParams *)0)->gridId);

    return CUDBG_SUCCESS;
}

/* Get offset of blockDim in GridParams. This is DCI dependent, hence halified. */
static CUDBGResult
maxwell_gm10x_getGridParamsOffsetBlockDim (CudbgDevice dev, uint64_t *offset, uint32_t *size)
{
    CUDBG_VERIFY(offset && size, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");

    *offset = ((uint64_t)(uintptr_t)&((CUmaxwellGridParams *)0)->blockDim);
    *size = sizeof ((CUmaxwellGridParams *)0)->blockDim;

    return CUDBG_SUCCESS;
}

/* Get offset of gridDim in GridParams. This is DCI dependent, hence halified. */
static CUDBGResult
maxwell_gm10x_getGridParamsOffsetGridDim (CudbgDevice dev, uint64_t *offset, uint32_t *size)
{
    CUDBG_VERIFY(offset && size, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");

    *offset = ((uint64_t)(uintptr_t)&((CUmaxwellGridParams *)0)->gridDim);
    *size = sizeof ((CUmaxwellGridParams *)0)->gridDim;

    return CUDBG_SUCCESS;
}

/* Get offset of startPc in GridParams. This is DCI dependent, hence halified. */
static CUDBGResult
maxwell_gm10x_getGridParamsOffsetStartPc (CudbgDevice dev, uint64_t *offset)
{
    CUDBG_VERIFY(offset, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");

    *offset = CNP_GRID_PARAM_OFFSET(startPc);

    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_updateSMESRInfo(CudbgDevice dev, uint32_t vsm, uint32_t wp, CudbgSMState_t *state, uint64_t warpPC)
{
    bool useWarpPC = false;
    uint64_t pcMask = ~(1ULL);

    CUDBG_VERIFY(dev && state, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    /* According to bug 1309601, it is possible for a 0xbbbbbbb1 to show up as a valid ESR PC if there
       are multiple warp errors, one MIO and one CORE, where the CORE throws the sentinel value
       and the MIO error throws the precise error PC of 0xbbbbbbb0. In this case, the lowest bit of
       ESR PC is latched from CORE, which sets the 1, but bits [31:1] come from MIO that has the precise PC.
       However, since MIO errors will always take priority in latching the HWW_WARP_ESR, the reported error
       for the warp will be one of ERROR_OOR_ADDR, ERROR_MISALIGNED_ADDR,
       ERROR_INVALID_ADDR_SPACE, ERROR_INVALID_CONST_ADDR_LDC, ERROR_MMU_FAULT.

       The logic below ensures that we only test if the ESR PC is the sentinel when the reported error
       is a CORE error (more specifically one of the CRS modifying errors).

       The only other fix needed is that the ESR PC must always unconditionally have its lowest bit masked
       This is always safe as PCs on Maxwell are aligned to 64 bit boundaries
    */
    state->esrWarpPC &= pcMask;

    if (state->esrWarpInfoValid && wp == state->esrWarpId) {
        /* According to bug 1233324, the ESR_PC can be set to a sentinel (0xbbbbbbb1) if :
            Case 1 : BRA.LMT, JMP.LMT, CAL.LMT: Hit API_STACK_ERROR, MISALIGNED_PC, PHYSICAL_STACK_OVERFLOW
                     BRX*, JMX* hit PC_OVERFLOW, API_STACK_ERROR, MISALIGNED_PC, PHYSICAL_STACK_OVERFLOW

            Case 2 : STACK_ERROR is hit after popping at least one token with KIL, RAM, BRK, EXIT, RET, CONT,
                     LONGJMP, SYNC
           In these cases, the top of stack PC will be correct. To handle such cases,
            we will put the top of stack PC (passed into this function) into ESR_PC
         */

        switch (state->esrState.hwwwarpesr & 0xFF) {
        case NV_PGRAPH_PRI_GPC0_TPC0_SM_HWW_WARP_ESR_ERROR_STACK_ERROR:
        case NV_PGRAPH_PRI_GPC0_TPC0_SM_HWW_WARP_ESR_ERROR_API_STACK_ERROR:
        case NV_PGRAPH_PRI_GPC0_TPC0_SM_HWW_WARP_ESR_ERROR_MISALIGNED_PC:
        case NV_PGRAPH_PRI_GPC0_TPC0_SM_HWW_WARP_ESR_ERROR_STACK_OVERFLOW:
            useWarpPC = true;
            break;
        default :
            useWarpPC = false;
            break;
        }

        if ((state->esrWarpPC == (MAXWELL_GM10X_ESR_PC_SENTINEL & pcMask)) && useWarpPC) {
            HALO_TRACE(10, "Switching ESR PC to Top of Stack PC. old ESR_PC : 0x%" PRIx64 " warpPC : 0x%" PRIx64 " HWW_WARP_ESR:0x%x\n",
                       state->esrWarpPC, warpPC, state->esrState.hwwwarpesr);
            state->esrWarpPC = warpPC;
        }
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_getBrokenWarps(struct Halo_st *halo, HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm,
                             const CUwarpBitmask *validMask, const CUwarpBitmask *bpTrapMask, CUwarpBitmask *brokenwarps)
{
    CUDBGResult res;
    CUwarpBitmask breakpointMask = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;
    uint32_t wp = 0, warpEsr = 0, trapImmediate = 0;

    CUDBG_VERIFY(halo && scratchpadAccessor && validMask && bpTrapMask && brokenwarps, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments to getBrokenWarps.\n");

    /* On GK110, we can't assume the BPT_TRAP_MASK indicates which
       warps are at a breakpoint, since it is overloaded and will
       show high bits when warps execute BPT.TRAP with other
       immediate fields.  Specifically with Bug 971389, CNP traps
       will do this, which can result in the debugger attempting to
       single-step 1 warp when multiple warps need to do a continuation,
       which can result in a hang at a BAR.SYNCALL.  So, we must read
       the trap immediates out of the warp scratchpad to populate the
       brokenwarps mask. */

    /* Initialize the mask to 0 */
    warpBitmaskClear(brokenwarps);

    /* Iterate over each warp's ESR, looking for the trap immediate bits */
    for (wp = 0; wp < halo->deviceInfo.numWarpsPrSM; ++wp) {
        /* Skip invalid warps */
        if (!warpBitmaskGetBits(validMask, wp, 1))
            continue;

        res = halo->scratchpad.read_warpErrorStatus(scratchpadAccessor, vsm, wp, &warpEsr);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read warp error status\n");

        trapImmediate = GETFIELD32(warpEsr, MAXWELL_TRAP_IMMEDIATE_FIELD);
        if (trapImmediate == MAXWELL_GM10X_TRAP_IMMEDIATE_BREAKPOINT)
            warpBitmaskSetBits(&breakpointMask, wp, 1, 1);
    }

    warpBitmaskAssign(brokenwarps, &breakpointMask);
    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_getScratchpadSharedMemDevVaddr(Context context, uint64_t *shmemDevVaddr)
{
    CUDBG_VERIFY(shmemDevVaddr && context, CUDBG_ERROR_INVALID_ARGS, "Invalid args.\n");

    *shmemDevVaddr = context->scratchpadDevVA + MAXWELL_GM10X_TRAP_HANDLER_SCRATCHPAD_OFFSET_SHARED;

    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_fillDisassemblyBuffer(Context context, uint64_t gpuAddr, uint64_t inst[2],
                                    uint64_t *instBuf, uint32_t instBufSize,
                                    uint32_t *instBufWrittenSize)
{
    /* Create a dummy I$ line. This contains 6 NOPs, all
       with the OPEX ?OFF_DECK_DRAIN. The target instruction
       is patched in, along with its opex.
     */
    uint64_t dummyBuf[8] = {0x001fc400fe2007f1ULL,
                            0x50b0000000070f00ULL,
                            0x50b0000000070f00ULL,
                            0x50b0000000070f00ULL,
                            0x001fc400fe2007f1ULL,
                            0x50b0000000070f00ULL,
                            0x50b0000000070f00ULL,
                            0x50b0000000070f00ULL
                           };
    uint64_t opexOrig, opexWord;
    uint64_t opexVaddr;
    CudbgDevice dev;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(context && instBuf && instBufWrittenSize, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");
    CUDBG_VERIFY(instBufSize >= sizeof(dummyBuf), CUDBG_ERROR_INTERNAL, "Buffer too small need at least 64 bytes\n");

    dev = context->dev;

    opexVaddr = MAXWELL_GM10X_OPEX_ADDR(gpuAddr);

    res = dev->halo.readCodeMemory(context, opexVaddr, &opexOrig, sizeof opexOrig);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Error reading opcode extension at addr %" PRIx64 " (res = %d)\n", opexVaddr, res);
        return res;
    }

    opexWord = (opexOrig & MAXWELL_GM10X_OPEX_MASK(gpuAddr)) >> MAXWELL_GM10X_OPEX_SHIFT(gpuAddr);

    /* We must use 8 as gpuAddr to OPEX_MODIFY as the instruction is always to be
       written into the first slot
    */
    dummyBuf[0] = MAXWELL_GM10X_OPEX_MODIFY(dummyBuf[0], 8, opexWord);
    dummyBuf[1] = inst[0];

    memcpy(instBuf, dummyBuf, sizeof(dummyBuf));
    *instBufWrittenSize = sizeof(dummyBuf);

    return CUDBG_SUCCESS;
}

/* The RUN_TRIGGER WAR is not needed on Maxwell */
static CUDBGResult
maxwell_gm10x_startRunTriggerWar(CudbgDevice dev)
{
    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_finishRunTriggerWar(CudbgDevice dev, int32_t vsm)
{
    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_getCCMasks(CudbgDevice dev, uint32_t *ccShift, uint32_t *ccBitmask)
{
    CUDBG_VERIFY(ccShift && ccBitmask, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    *ccShift   = MAXWELL_CC_SHIFT;
    *ccBitmask = MAXWELL_CC_BITMASK;

    return CUDBG_SUCCESS;
}

/* Scratchpad access */

static CUDBGResult
maxwell_gm10x_scratchpad_getGlobalFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_SCRATCHPAD_GET_OFFSET_CASE(ACTIVE, MaxwellScratchpad_t, active);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PREEMPT_COMMAND, MaxwellScratchpad_t, preemptCommand);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PADDING, MaxwellScratchpad_t, padding);
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_scratchpad_getWarpFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_SCRATCHPAD_GET_OFFSET_CASE(VIRT_ID, MaxwellWarpScratchpad_t, virtID);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(CTA_PARAM, MaxwellWarpScratchpad_t, ctaParam);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_IDX_X, MaxwellWarpScratchpad_t, blockIdxX);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_IDX_Y, MaxwellWarpScratchpad_t, blockIdxY);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_IDX_Z, MaxwellWarpScratchpad_t, blockIdxZ);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_DIM_X, MaxwellWarpScratchpad_t, blockDimX);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_DIM_Y, MaxwellWarpScratchpad_t, blockDimY);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_DIM_Z, MaxwellWarpScratchpad_t, blockDimZ);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_ID_64_LO, MaxwellWarpScratchpad_t, gridId64Lo);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_DIM_X, MaxwellWarpScratchpad_t, gridDimX);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_DIM_Y, MaxwellWarpScratchpad_t, gridDimY);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_DIM_Z, MaxwellWarpScratchpad_t, gridDimZ);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SHMEM_SIZE_PR_BLOCK, MaxwellWarpScratchpad_t, shmemSizePrBlock);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_WINDOW_SIZE, MaxwellWarpScratchpad_t, lmemWindowSize);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_LO_SIZE_PR_THREAD, MaxwellWarpScratchpad_t, lmemLoSizePrThread);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_HI_OFF, MaxwellWarpScratchpad_t, lmemHiOff);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GLOBAL_ERROR_STATUS, MaxwellWarpScratchpad_t, globalErrorStatus);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_ERROR_STATUS, MaxwellWarpScratchpad_t, warpErrorStatus);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_BARRIER_STATE, MaxwellWarpScratchpad_t, warpBarrierState);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SELF_QMD_LO, MaxwellWarpScratchpad_t, selfQMDLo);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SELF_QMD_HI, MaxwellWarpScratchpad_t, selfQMDHi);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PARAM_CONST_DPTR_LO, MaxwellWarpScratchpad_t, paramConstDptrLo);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PARAM_CONST_DPTR_HI, MaxwellWarpScratchpad_t, paramConstDptrHi);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(CIR_QUEUE_INCR_MINUS_ONE, MaxwellWarpScratchpad_t, cirQueueIncrMinusOne);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_BASE_LO, MaxwellWarpScratchpad_t, lmemBaseLo);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_BASE_HI, MaxwellWarpScratchpad_t, lmemBaseHi);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(CRS_PTR, MaxwellWarpScratchpad_t, crsPtr);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_ID_64_HI, MaxwellWarpScratchpad_t, gridId64Hi);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(MPS_CONTEXT_ID, MaxwellWarpScratchpad_t, mpsContextId);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SINGLESTEP_NSTEPS, MaxwellWarpScratchpad_t, singleStepNsteps);
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_scratchpad_getLaneFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_SCRATCHPAD_GET_OFFSET_CASE(THREAD_IDX, MaxwellLaneScratchpad_t, threadIdx);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(R1, MaxwellLaneScratchpad_t, r1);
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_scratchpad_getSmFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PAUSE_SERVICED_MASK, MaxwellSMScratchpad_t, pauseServicedMask);
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_scratchpad_getFieldOffset(HaloScratchpadField field, HaloScratchpadSection section,
    uint32_t sm, uint32_t wp, uint32_t ln, size_t *offset, size_t *width)
{
    size_t base = 0;
    CUDBGResult res;

    switch (section) {
    case HALO_SCRATCHPAD_SECTION_GLOBAL:
        res = maxwell_gm10x_scratchpad_getGlobalFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_SCRATCHPAD_SECTION_WARP:
        base = OFFSETOF_NONCONST(MaxwellScratchpad_t, warp[sm][wp]);
        res = maxwell_gm10x_scratchpad_getWarpFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_SCRATCHPAD_SECTION_SM:
        base = OFFSETOF_NONCONST(MaxwellScratchpad_t, sm[sm]);
        res = maxwell_gm10x_scratchpad_getSmFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_SCRATCHPAD_SECTION_LANE:
        base = OFFSETOF_NONCONST(MaxwellScratchpad_t, warp[sm][wp]) +
               OFFSETOF_NONCONST(MaxwellWarpScratchpad_t, lane[ln]);
        res = maxwell_gm10x_scratchpad_getLaneFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    default:
        *offset = 0;
        *width = 0;
        HALO_TRACE_FUNCTION(0, "Invalid scratchpad section %d\n", section);
        return CUDBG_ERROR_INVALID_ARGS;
    };

    *offset += base;

    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_scratchpad_read_smIds(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *virtCTAID, uint32_t *floorsweptSmId)
{
    uint32_t value;

    CUDBG_VERIFY(scratchpadAccessor && virtCTAID && floorsweptSmId, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    /* virtCTAID is split across SR_VirtId, by bits ArrayIdLower (19:16) and
       ArrayIdUpper (30:29). Adding in 31st bit as well for expansion
       (always zero on maxwell, pascal and higher not so) */
    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, VIRT_ID, vsm, wp, 0, &value);
    *virtCTAID = ((value >> 25) & 0x70) | ((value >> 16) & 0xF);
    *floorsweptSmId = (value >> 20) & 0xFF;

    return CUDBG_SUCCESS;
}

static CUDBGResult
maxwell_gm10x_stub_scratchpad_write_WAR_runTrigger1239649(HaloScratchpadAccessor scratchpadAccessor, uint32_t warRunTriggerFlagValue)
{
    CUDBG_VERIFY(scratchpadAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
maxwell_gm10x_membarWAR_getPatchReg(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                    uint32_t ln, uint32_t regno,
                                    uint32_t *hasSpilled, uint32_t *regval)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t offset = 0;

    /* The Maxwell+ MEMBAR WAR spills R2, R3 */
    switch (regno) {
    case 2:
        offset = dev->halo.deviceInfo.lmemHiMembarWarSpillR2;
        *hasSpilled = 1;
        break;
    case 3:
        offset = dev->halo.deviceInfo.lmemHiMembarWarSpillR3;
        *hasSpilled = 1;
        break;
    default :
        *hasSpilled = 0;
        break;
    };

    if (!*hasSpilled) {
        return CUDBG_SUCCESS;
    }

    CUDBG_VERIFY(offset, CUDBG_ERROR_UNKNOWN, "MEMBAR WAR offset not set\n");

    res = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                    offset,
                                    regval, sizeof(*regval));
    return res;
}

static CUDBGResult
maxwell_gm10x_membarWAR_getPatchPred(CudbgDevice dev, uint32_t vsm,
                                        uint32_t wp, uint32_t ln,
                                        uint32_t numPreds, uint32_t *predicates)
{
    return dev->halo.readPredicates(dev, vsm, wp, ln, numPreds, predicates);
}

static CUDBGResult
maxwell_gm10x_membarWAR_getPatchCC(CudbgDevice dev, uint32_t vsm,
                                      uint32_t wp, uint32_t ln, uint32_t *cc)
{
    return dev->halo.readCCRegister(dev, vsm, wp, ln, cc);
}

static CUDBGResult
maxwell_gm10x_membarWAR_setPatchReg(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                   uint32_t ln, uint32_t regno,
                                   uint32_t *hasSpilled, const uint32_t *regval)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t offset = 0;

    /* The Maxwell+ MEMBAR WAR spills R2, R3 */
    switch (regno) {
    case 2:
        offset = dev->halo.deviceInfo.lmemHiMembarWarSpillR2;
        *hasSpilled = 1;
        break;
    case 3:
        offset = dev->halo.deviceInfo.lmemHiMembarWarSpillR3;
        *hasSpilled = 1;
        break;
    default :
        *hasSpilled = 0;
        break;
    };

    if (!*hasSpilled) {
        return CUDBG_SUCCESS;
    }

    CUDBG_VERIFY(offset, CUDBG_ERROR_UNKNOWN, "MEMBAR WAR offset not set\n");

    res = dev->halo.writeLocalMemory(dev, vsm, wp, ln,
                                     offset,
                                     regval, sizeof(*regval));
    return res;
}

static CUDBGResult
maxwell_gm10x_membarWAR_setPatchPred(CudbgDevice dev, uint32_t vsm,
                                        uint32_t wp, uint32_t ln,
                                        uint32_t numPreds,
                                        const uint32_t *predicates)
{
    return dev->halo.writePredicates(dev, vsm, wp, ln, numPreds, predicates);
}

static CUDBGResult
maxwell_gm10x_membarWAR_setPatchCC(CudbgDevice dev, uint32_t vsm,
                                      uint32_t wp, uint32_t ln,
                                      const uint32_t cc)
{
    return dev->halo.writeCCRegister(dev, vsm, wp, ln, cc);
}

/* Populate the debugger structure with Maxwell GM10x specific functions. */
void
haloDeviceInit_gm10x(Halo_st *halo)
{
    haloDeviceInit_gk110(halo); /* Most gk110 functions can be shared with gm10x */

    /* architectual constants - always init after base chip init */
    halo->deviceInfo.spRegisterNumber = MAXWELL_ABI_SP_REGNUM;
    halo->deviceInfo.systemStackPointer = MAXWELL_SYSTEM_STACK_POINTER;
    halo->deviceInfo.scratchpadSize = sizeof(MaxwellScratchpad_t);

    halo->getInfo = maxwell_gm10x_getInfo;

    /* GM10x - account for different opcodes (only 64-bit instructions, as well) */
    halo->isInternalInstructionAtPC = maxwell_gm10x_isInternalInstructionAtPC;
    halo->isTerminalInstructionAtPC = maxwell_gm10x_isTerminalInstructionAtPC;
    halo->isSteppable = maxwell_gm10x_isSteppable;
    halo->forceTermination = maxwell_gm10x_forceTermination;
    halo->fillRangeWithInstruction = maxwell_gm10x_fillRangeWithInstruction;

    /* GM10x - save and restore opcode extensions while adding/removing breakpoints */
    halo->insertBreakpoint = maxwell_gm10x_insertBreakpoint;
    halo->removeBreakpoint = maxwell_gm10x_removeBreakpoint;

    /* GM10x - patch dynamic register reads/writes */
    halo->patchDynamicRegisterRead  = maxwell_gm10x_patchDynamicRegisterRead;
    halo->patchDynamicRegisterWrite = maxwell_gm10x_patchDynamicRegisterWrite;
    halo->getDynamicRegisterRange   = maxwell_gm10x_getDynamicRegisterRange;

    /* GM10x - verify CRS checksum */
    halo->verifyCRSxsum = maxwell_gm10x_verifyCRSxsum;

    /* GM10x - patch texture instruction */
    halo->patchTextureInstruction = maxwell_gm10x_patchTextureInstruction;

    /* GM10x - read ESR warp info */
    halo->readSMWarpESRInfo = maxwell_gm10x_readSMWarpESRInfo;

    /* GM10x - handle global error state */
    halo->handleGlobalErrorState = maxwell_gm10x_handleGlobalErrorState;

    /* GM10x - handle global MMU error state */
    halo->handleGlobalMMUErrorState = maxwell_gm10x_handleGlobalMMUErrorState;

    halo->getSavedSPLmemAddr = maxwell_gm10x_getSavedSPLmemAddr;

    /* GM10x - offset of gridId in GridParams */
    halo->getGridParamsOffsetGridId   = maxwell_gm10x_getGridParamsOffsetGridId;

    /* GM10x - offset of blockDim in GridParams */
    halo->getGridParamsOffsetBlockDim = maxwell_gm10x_getGridParamsOffsetBlockDim;

    /* GM10x - offset of gridDim in GridParams */
    halo->getGridParamsOffsetGridDim = maxwell_gm10x_getGridParamsOffsetGridDim;

    /* GM10x - offset of gridDim in GridParams */
    halo->getGridParamsOffsetStartPc = maxwell_gm10x_getGridParamsOffsetStartPc;

    /* GM10x - Get the SM ESR PC */
    halo->getSMHwwErrorPC = maxwell_gm10x_getSMHwwErrorPC;

    /* GM10x - Adjust the SM ESR info */
    halo->updateSMESRInfo = maxwell_gm10x_updateSMESRInfo;

    /* GM10x - Account for Maxwell scratchpad being differently sized */
    halo->getBrokenWarps = maxwell_gm10x_getBrokenWarps;
    halo->getScratchpadSharedMemDevVaddr = maxwell_gm10x_getScratchpadSharedMemDevVaddr;
    halo->isWarpOnBarrier = maxwell_gm10x_isWarpOnBarrier;

    /* GM10x - read instruction accounting for the opex */
    halo->fillDisassemblyBuffer = maxwell_gm10x_fillDisassemblyBuffer;

    /* GM10x - Stubs for WAR Run Trigger HW Bug 1239649 */
    halo->startRunTriggerWar = maxwell_gm10x_startRunTriggerWar;
    halo->finishRunTriggerWar = maxwell_gm10x_finishRunTriggerWar;

    /* GM10x - get CC masks */
    halo->getCCMasks = maxwell_gm10x_getCCMasks;

    /* Scratchpad access */

    halo->scratchpad.getFieldOffset = maxwell_gm10x_scratchpad_getFieldOffset;

    halo->scratchpad.read_smIds = maxwell_gm10x_scratchpad_read_smIds;

    halo->scratchpad.write_WAR_runTrigger1239649 = maxwell_gm10x_stub_scratchpad_write_WAR_runTrigger1239649;

    /* Membar WAR read registers */
    halo->membarWAR_getPatchReg = maxwell_gm10x_membarWAR_getPatchReg;
    halo->membarWAR_getPatchPred = maxwell_gm10x_membarWAR_getPatchPred;
    halo->membarWAR_getPatchCC = maxwell_gm10x_membarWAR_getPatchCC;

    /* Membar WAR write registers */
    halo->membarWAR_setPatchReg = maxwell_gm10x_membarWAR_setPatchReg;
    halo->membarWAR_setPatchPred = maxwell_gm10x_membarWAR_setPatchPred;
    halo->membarWAR_setPatchCC = maxwell_gm10x_membarWAR_setPatchCC;
}
