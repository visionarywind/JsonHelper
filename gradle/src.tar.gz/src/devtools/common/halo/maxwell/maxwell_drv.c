/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "cuda_types.h"
#include "halo_drv.h"
#include "kepler_drv.h"
#include "maxwell_drv.h"
#include "maxwell.h"

static CUDBGResult
haloDrvAdjustCodeAddress_maxwell(uint64_t physAddr,
                                 uint64_t *adjustedPhysAddr,
                                 CUDBGAdjAddrAction adjAction);

static CUDBGResult
haloDrvIsStackPointerAssignment_maxwell(uint64_t instruction[2],
                                        int32_t *res, uint32_t *assignmentIdx);

CUDBGResult
getHaloDrvFuncPtrs_maxwell(struct HaloDrvFuncPtrs *ptrs)
{
    CUDBGResult res;

    res = getHaloDrvFuncPtrs_gk11x(ptrs);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Override the functions that are different between maxwell and kepler gk11x */
    ptrs->adjustCodeAddress = haloDrvAdjustCodeAddress_maxwell;
    ptrs->isStackPointerAssignment = haloDrvIsStackPointerAssignment_maxwell;

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDrvAdjustCodeAddress_maxwell(uint64_t physAddr,
                                 uint64_t *adjustedPhysAddr,
                                 CUDBGAdjAddrAction adjAction)
{
    CUDBG_VERIFY(adjustedPhysAddr, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    switch (adjAction) {
    case CUDBG_ADJ_PREVIOUS_ADDRESS:
        *adjustedPhysAddr = physAddr - 8;
        if (MAXWELL_GM10X_IS_OPEX_ADDR(*adjustedPhysAddr))
            *adjustedPhysAddr -= 8;
        break;
    case CUDBG_ADJ_NEXT_ADDRESS:
        *adjustedPhysAddr = physAddr + 8;
        if (MAXWELL_GM10X_IS_OPEX_ADDR(*adjustedPhysAddr))
            *adjustedPhysAddr += 8;
        break;
    case CUDBG_ADJ_CURRENT_ADDRESS:
        *adjustedPhysAddr = physAddr;
        if (MAXWELL_GM10X_IS_OPEX_ADDR(*adjustedPhysAddr))
            *adjustedPhysAddr += 8;
        break;
    default:
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDrvIsStackPointerAssignment_maxwell(uint64_t instruction[2],
                                        int32_t *res, uint32_t *assignmentIdx)
{
    /* Maxwell ABI:  R1 is the stack pointer, which is initialized
       with a value placed in constant bank 0 at offset 32 (Maxwell DCI).
       Typically, the MOV instruction is used to do this, but we'll
       also catch the case that LDC is used as well:

       MOV R1, c[0][0x20]
       LDC R1, c[0][0x20]

       This is true for GK10x, GK11x and GM10x, but this routine needs
       to be implemented for each due to completely different instruction
       encodings between sm_30, sm_35 and sm_50. */
    const uint64_t MAXWELL_GM10x_MOV_R1_C_0_32 = 0x4c98078000870001ULL;
    const uint64_t MAXWELL_GM10x_LDC_R1_C_0_32 = 0xef9400000207ff01ULL;

    CUDBG_VERIFY(res && assignmentIdx, CUDBG_ERROR_INVALID_ARGS, "Invalid args in isStackPointerAssignment.\n");

    /* Note:  We only need to look at the first instruction on Maxwell,
       since any OpEx's have already been appropriately dealt with */
    if (instruction[0] == MAXWELL_GM10x_MOV_R1_C_0_32 ||
        instruction[0] == MAXWELL_GM10x_LDC_R1_C_0_32) {
        *res = 1;
        *assignmentIdx = 0;
    }
    else
        *res = 0;

    return CUDBG_SUCCESS;
}
