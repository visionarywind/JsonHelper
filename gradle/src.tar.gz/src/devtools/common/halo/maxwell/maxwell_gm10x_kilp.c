/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: maxwell_gm10x_kilp.c
 *
 *   Description:
 *       Internal API for the low-level GPU access needed to support
 *       KILP (Kepler Instruction-Level Preemption) in the debugger on
 *       Maxwell (GM10x+) class hardware.
 *
 ******************************************************************************/

#include "cudadebugger.h"
#include "maxwell.h"
#include "halo_internal.h"
#include "halo_state.h"
#include "maxwell_gm10x.h"
#include "maxwell_gm10x_kilp.h"
#include "../../../../syscalls/debugger/kilp_structs.h"

static CUDBGResult
maxwell_gm10x_kilp_controllerIlpSetupMode(CudbgDevice dev, uint32_t mode)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t modeAddress, preemptCommandAddress;
    uint32_t modeValue, preemptCommandValue;
    bool writeScratchpad = false;

    if (!dev->activeContext ||
        !haloStateContextIsActive(dev->activeContext)) {
        return CUDBG_SUCCESS;
    }

    modeValue = mode;
    modeAddress = dev->activeContext->kilpControllerDataAddr +
                  offsetof(struct KILPcontrollerData_st, command);

    /* Write the preempt command (mode) into the controller struct */
    res = dev->halo.writeGenericMemory(dev->activeContext,
                                       0, 0, 0,
                                       modeAddress,
                                       &modeValue,
                                       sizeof(modeValue));
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to write KILP mode (res=%d)\n", res);
        return res;
    }

    /* When initiating preempt-save, or returning to 'run' mode, set the
       traphandler scratchpad state appropriately as well.

       We set the preemp-save command to vector all warps that are
       paused in the trap handler into the KILP handle_continuations
       path (it also checks if the warp is considered preemptable).

       If 'run' is specified, it means we clear the preempt flag.
       This is crucial in the case where we've initiated ILP, but
       savedCount actually ended up being zero (as all CTAs were
       found to be 'unwanted', and they relaunched themselves
       from the start without saving anything out).  In this case,
       we had first written the preempt-save command (see above
       explanation), and so now we need to clear it, to prevent
       any warps from observing the stale preempt-save command. */
    if (mode == KILP_CONTROLLER_CMD_PREEMPT) {
        preemptCommandValue = MAXWELL_GM10X_KILP_TH_PREEMPT_SAVE;
        preemptCommandAddress = dev->activeContext->scratchpadDevPtr +
                                offsetof(MaxwellScratchpad_t, preemptCommand);

        writeScratchpad = true;
    }
    else if (mode == KILP_CONTROLLER_CMD_RUN) {
        preemptCommandValue = 0;
        preemptCommandAddress = dev->activeContext->scratchpadDevPtr +
                                offsetof(MaxwellScratchpad_t, preemptCommand);

        writeScratchpad = true;
    }

    if (writeScratchpad) {
        /* Write the preempt command to the scratchpad */
        res = dev->halo.writeGenericMemory(dev->activeContext,
                                           0, 0, 0,
                                           preemptCommandAddress,
                                           &preemptCommandValue,
                                           sizeof(preemptCommandValue));
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to write preempt reason code (res=%d)\n", res);
            return res;
        }
    }

    return res;
}

static CUDBGResult
maxwell_gm10x_kilp_isWarpEnabledForPreempt(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                           bool *isWarpEnabledForPreempt)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t warpPreemptEnableTableAddr;
    uint32_t warpEnabledForPreempt;

    CUDBG_VERIFY(isWarpEnabledForPreempt, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    /* Initialize to true */
    *isWarpEnabledForPreempt = true;

    if (!dev->activeContext)
        return CUDBG_SUCCESS;

    /* Compute the offset to this warp's CTA in the CtaIlpEnableTable */
    warpPreemptEnableTableAddr = dev->activeContext->kilpCtaIlpEnableTableAddr +
                                 ((vsm * MAXWELL_MAX_CTA_PER_SM + dev->smState[vsm].warp[wp].virtCTAID) * sizeof(uint32_t));

    res = dev->halo.readGenericMemory(dev->activeContext, 0, 0, 0,
                                      warpPreemptEnableTableAddr,
                                      &warpEnabledForPreempt,
                                      sizeof warpEnabledForPreempt);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE_FUNCTION(0, "Failed to read CtaIlpEnableTable for vsm%d/wp%d (res=%d)\n", vsm, wp, res);
        return res;
    }

    *isWarpEnabledForPreempt = (bool)warpEnabledForPreempt;

    HALO_TRACE_FUNCTION(20, "vsm%d/wp%d, enabled for preempt: %d\n", vsm, wp, *isWarpEnabledForPreempt);

    return res;
}

static CUDBGResult
maxwell_gm10x_kilp_readWarpCtaCtxAddr(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                      uint64_t *warpCtaContextAddr)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t warpCtaContextIndirectionTableAddr;

    CUDBG_VERIFY(warpCtaContextAddr, CUDBG_ERROR_INVALID_ARGS, "Invalid args to readWarpCtaCtxAddr\n");
    CUDBG_VERIFY(dev->activeContext, CUDBG_ERROR_INTERNAL, "No active context in readWarpCtaCtxAddr\n");

    /* Clear the pointer before reading it */
    *warpCtaContextAddr = 0;

    /* Note that the entry in the ctaContextIndirectionTable is only guaranteed
       to be valid if this warp has paused AND the warp is considered preemptable */
    warpCtaContextIndirectionTableAddr =
        dev->activeContext->ctaContextIndirectionTableAddr +
        (vsm * MAXWELL_MAX_CTA_PER_SM +
         dev->smState[vsm].warp[wp].virtCTAID) * sizeof(CNPctaCtx *);

    res = dev->halo.readGenericMemory(dev->activeContext, 0, 0, 0,
                                      warpCtaContextIndirectionTableAddr,
                                      warpCtaContextAddr,
                                      sizeof(CNPctaCtx *));
    if (res != CUDBG_SUCCESS)
        return res;

    return res;
}

CUDBGResult
maxwell_gm10x_kilp_readTextureMemoryUsingTexHeader(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                                   uint32_t texId, uint32_t dim, uint32_t *coords,
                                                   void *buf, uint32_t bufSz)
{
    uint32_t *wbuf = (uint32_t *)buf;
    uint64_t constBankOffset;
    uint32_t texHeaderIndex;
    uint64_t texDptr, offset;
    uint32_t pitch;
    uint32_t texHeaderData[CU_NV50_TEXHDR_SIZE_DWORDS] = {0};
    CUDBGResult res = CUDBG_SUCCESS;
    Context context = dev->activeContext;
    Grid grid;
    uint64_t texDptrMask = 0;

    CUDBG_VERIFY((context && context->memMapActive), CUDBG_ERROR_INVALID_MEMORY_ACCESS, "Invalid memory access.\n");
    CUDBG_VERIFY(coords, CUDBG_ERROR_INVALID_ARGS, "Invalid coords passed as arguments.\n");

    /* Pull the grid for this warp */
    grid = haloStateDeviceGetGrid(dev, dev->smState[vsm].warp[wp].gridId64);
    CUDBG_VERIFY(grid, CUDBG_ERROR_INVALID_GRID, "Invalid grid.\n");

    /* Find the constant bank offset for this texture ID */
    res = dev->halo.findConstBankOffset(dev, grid->function, texId, &constBankOffset);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read const bank offset for tex id (res=%d)\n", res);
        return res;
    }

    HALO_TRACE_FUNCTION(10, "TEX ID %d const bank offset = 0x%016" PRIx64 "\n",
                        texId, constBankOffset);

    /* Load the texture header index from the const bank offset */
    res = dev->halo.readGenericMemory(context, 0, 0, 0,
                                      dev->smState[vsm].warp[wp].paramConstDptr +
                                      constBankOffset,
                                      &texHeaderIndex, sizeof(texHeaderIndex));
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read texture idx (res=%d)\n", res);
        return res;
    }

    HALO_TRACE_FUNCTION(10, "TEX ID %d header idx = 0x%08x\n", texId, texHeaderIndex);

    /* The texture header pool is in the device vaddr space.  Load
       the texture header for this texture index from there. */
    res = dev->halo.readDeviceMemory(context,
                                     context->texHeaderPoolVA +
                                     (texHeaderIndex * sizeof(CUtexhdr)),
                                     texHeaderData,
                                     sizeof(texHeaderData));
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read texture header data (res=%d)\n", res);
        return res;
    }

    res = dev->halo.getTexDptrMask(dev, &texDptrMask);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read the Tex Dptr mask \n");
        return res;
    }

    /* The format of the texture header can be found in kepler_common.c.
       Load the dptr for texture data, which is split across two words in the header */
    texDptr = ((uint64_t)texHeaderData[2] << 32 | texHeaderData[1]) & texDptrMask;

    HALO_TRACE_FUNCTION(10, "TEX ID %d dptr = 0x%016" PRIx64 ", dim=%d, coord={%d,%d,%d}\n",
                        texId, texDptr, dim, coords[0], coords[1], coords[2]);

    /* Load the pitch, see maxwell_common.c, this is pushed as pitch >> 5 and */
    /*  expects the pitch to be 20 bit. For more info also check */
    /* https://p4viewer.nvidia.com/get///hw/nvgpu/class/mfs/class/3d/maxwell.mfs */
    pitch = (texHeaderData[3] << 5) & 0xfffff;

    HALO_TRACE_FUNCTION(10, "TEX ID %d pitch = %x\n", texId, pitch);

    switch (dim) {
    case 1:
        offset = coords[0]*sizeof(uint32_t);
        break;
    case 2:
        offset = (coords[0]*sizeof(uint32_t)) + (coords[1] * pitch);
        break;
    default:
        HALO_TRACE_FUNCTION(0, "Unsupported/invalid dimension (%d)\n", dim);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    /* Read the data for this texture request */
    res = dev->halo.readGenericMemory(context, 0, 0, 0, texDptr + offset, wbuf, bufSz);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read texture data (res=%d)\n", res);
        return res;
    }

    return CUDBG_SUCCESS;
}

/* Populate the debugger structure with Maxwell GM10x specific ILP functions. */
void
haloDeviceInit_gm10x_kilp(Halo_st *halo)
{
    /* GM10x - Account for Maxwell Scratchpad in Instruction-level preemption routines */
    halo->controllerIlpSetupMode = maxwell_gm10x_kilp_controllerIlpSetupMode;

    /* GM10x - Account for Maxwell's 32 CTAs per SM */
    halo->isWarpEnabledForPreempt = maxwell_gm10x_kilp_isWarpEnabledForPreempt;
    halo->readWarpCtaCtxAddr = maxwell_gm10x_kilp_readWarpCtaCtxAddr;

    /* GM10x - Account for Maxwell texture header differences when reading tex memory */
    halo->readTextureMemoryUsingTexHeader = maxwell_gm10x_kilp_readTextureMemoryUsingTexHeader;
};
