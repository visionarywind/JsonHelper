/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: maxwell_gm10x.h
 *
 *   Description:
 *       Debugger access functions that are different for the Maxwell GM10x family.
 *
 ******************************************************************************/

#ifndef _HALO_MAXWELL_GM10X_H
#define _HALO_MAXWELL_GM10X_H

#include <halo.h>

/*
 * Maxwell GPC/TPC PRI offset macros
 */
#define MAXWELL_GM10X_GPC_OFFSET 0x8000
#define MAXWELL_GM10X_TPC_OFFSET 0x800

// 64-bit breakpoint instruction.  No narrow instruction (BPT_N.TRAP) on GM10X :(
// Reason code of 1 is used (0 is reserved by HW)
// Maxwell TODO:  BPT.TRAP 0x7 can be used to break from an IDE region (See Bug 1014152)
#define MAXWELL_GM10X_BREAKPT64 0xe3a00000001000c0ULL

/*
                         Maxwell CRS Layout

    The following diagram shows a single cache line in stack memory
    (which lies underneath local memory).  A single cacheline is
    128 bytes, and each CRS entry is 16 bytes, which means 8 entries
    can fill the entire cache line.  The upper 6 bytes of each CRS
    entry are padded with zeroes.

                     [ # of bits per field]                   [Idx]

          48          8      3     5         32       30   2 |
    ----------------------------------------------------------        -----
    | Padded 6B | Checksum | X | Type | Active Mask | PC | X |  0       |
    ----------------------------------------------------------          |
    |                                                        |  1       |
    ----------------------------------------------------------      128 bytes
                        . . .                                           |
    ----------------------------------------------------------          |
    |                                                        |  7       |
    ----------------------------------------------------------          |
                                                                      -----
    |-----------------------16 bytes-------------------------|
    High-order                                       Low-order

    CRS entries are contiguous within a cache line:

    -------------------------------------------------
    |16|16|16|16|16|16|16|16|16|16|16|16|16|16|16|16| (#s in bytes)
    -------------------------------------------------

    (A vast improvement over Fermi's layout...)

    The default CRS size is 512 bytes per warp which means there
    are 4 cache lines representing CRS entries per warp by default.
*/

#define MAXWELL_GM10X_CACHE_LINE_SIZE       128 /* Each cache line is 128 bytes */
#define MAXWELL_GM10X_CRS_ENTRY_SIZE         16 /* CRS entries are 16 bytes */
#define MAXWELL_GM10X_CRS_ENTRY_PADDING_SIZE  6 /* CRS entries are padded with 6 bytes (@top) */
#define MAXWELL_GM10X_CRS_ENTRIES_PER_LINE    8 /* 8 CRS entries per cache line */
#define MAXWELL_GM10X_CRS_PC_OFFSET           0 /* PC is the first field in an entry */
#define MAXWELL_GM10X_CRS_MASK_OFFSET         4 /* Mask is 4 bytes into an entry */
#define MAXWELL_GM10X_CRS_TYPE_OFFSET         8 /* Type is 8 bytes into an entry */
#define MAXWELL_GM10X_CRS_XSUM_OFFSET         9 /* Xsum is 9 bytes into an entry */

/* The maximum amount of CRS tokens that can be pushed (per warp) */
#define MAXWELL_GM10X_MAX_CRS_ENTRIES_PER_WARP(vsm,wp) ((dev->smState[vsm].warp[wp].lmemConfig.CRSSize / \
                                                       MAXWELL_GM10X_CACHE_LINE_SIZE) * \
                                                       MAXWELL_GM10X_CRS_ENTRIES_PER_LINE)

/*
   Per-lane global/warp error status codes (from SR64 and SR66).
   Enumerations, bitfields, and explanations derived from:

   //hw/doc/gpu/maxwell/maxwell/design/IAS/SML1/ISA/opcodes/opS2R.htm
   MAXWELL TODO:  any changes here that we need between kepler and maxwell?
*/

/* Opcode Extensions related macros and defines */
#define MAXWELL_GM10X_OPEX_OFF_DECK_DRAIN_NO_SB     0x7e0ULL
#define MAXWELL_GM10X_OPEX_WAIT5_NO_SB              0x7f5ULL
#define MAXWELL_GM10X_OPEX_USCHED_OFF_DECK_DRAIN    0x0
#define MAXWELL_GM10X_OPEX_FIELD_WIDTH              21

#define MAXWELL_GM10X_OPEX_ADDR(instr_addr)         ((instr_addr) & ~0x1fULL)
#define MAXWELL_GM10X_OPEX_SHIFT(instr_addr)        (((((instr_addr) & 0x1fULL) >> 3) - 1) * MAXWELL_GM10X_OPEX_FIELD_WIDTH)
#define MAXWELL_GM10X_OPEX_MASK(instr_addr)         (0x1fffffULL << MAXWELL_GM10X_OPEX_SHIFT(instr_addr))
#define MAXWELL_GM10X_OPEX_USCHED_MASK(instr_addr)  (0x1fULL << MAXWELL_GM10X_OPEX_SHIFT(instr_addr))
#define MAXWELL_GM10X_IS_OPEX_ADDR(addr)            (addr == MAXWELL_GM10X_OPEX_ADDR(addr))

#define MAXWELL_GM10X_OPEX_MODIFY_USCHED(orig_opex, instr_addr, new_usched)    \
                ((orig_opex) & ~MAXWELL_GM10X_OPEX_USCHED_MASK(instr_addr)) |  \
                (new_usched << MAXWELL_GM10X_OPEX_SHIFT(instr_addr));
#define MAXWELL_GM10X_OPEX_MODIFY(orig_opex, instr_addr, new_opex)     \
                ((orig_opex) & ~MAXWELL_GM10X_OPEX_MASK(instr_addr)) | \
                (new_opex << MAXWELL_GM10X_OPEX_SHIFT(instr_addr));


/* Registers 0 - REGISTER_START - 1 are saved at the top of LMEM_HI.
   Leaving space for all 255 registers would be too large of a
   reservation, so the remainder are read out dynamically,
   with storage held at MAXWELL_GM10X_LMEM_ABI_DYNAMIC_REGISTER.

   Note: GM10x Fmodel had a bug where it asserts if non allocated
   registers are accessed, even in trap mode. */
#define MAXWELL_GM10X_DYNAMIC_REGISTER_START           64
#define MAXWELL_GM10X_DYNAMIC_REGISTER_END            255

#define MAXWELL_GM10X_ESR_PC_SENTINEL 0xbbbbbbb1ULL

/* BPT.TRAP Immediate Definitions */
typedef enum {
    MAXWELL_GM10X_TRAP_IMMEDIATE_ILLEGAL    = 0,
    MAXWELL_GM10X_TRAP_IMMEDIATE_BREAKPOINT = 1,
    MAXWELL_GM10X_TRAP_IMMEDIATE_CNP        = 2,
    MAXWELL_GM10X_TRAP_IMMEDIATE_SYSCALL    = 3,
} MaxwelGM10XTrapImmediate_t;

void haloDeviceInit_gm10x(Halo_st *halo);
CUDBGResult maxwell_gm10x_getInfo(CudbgDevice dev);

CUDBGResult maxwell_gm10x_readSMWarpESRInfo(CudbgDevice dev, uint32_t vsm, CudbgSMState_t *state);
#endif
