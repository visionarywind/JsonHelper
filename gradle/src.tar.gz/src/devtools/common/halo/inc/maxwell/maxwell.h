/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: maxwell.h
 *
 *   Description:
 *       Debugger access functions that are different for the Maxwell family.
 *
 ******************************************************************************/

#ifndef _HALO_MAXWELL_H
#define _HALO_MAXWELL_H

#include <halo.h>
#include <maxwell_scratchpad.h>
#include <maxwell_gm10x.h>
#include <maxwell_gm20x.h>

#define MAXWELL_IDE_REGION_MASK 0x00000020U // Bit 5 of the global ESR
#define MAXWELL_TRAP_IMMEDIATE_FIELD 31:24  // Bits 31:24 of the warp ESR hold the trap immediate

#define MAXWELL_MAX_CTA_PER_SM 32

/* Maxwell system stack pointer
   From cui/hal/maxwell/maxwell.h
   This is given as CU_MAXWELL_LMEM_TOTAL_SIZE           -
                    CU_MAXWELL_LMEM_DEBUGGER_SIZE        -
                    CU_MAXWELL_LMEM_THREAD_STATE_SIZE
   This works out to 0x1000000 - 512 - 32 = 0xfffde0
*/
#define MAXWELL_SYSTEM_STACK_POINTER 0xfffde0ULL

/* Maxwell system stack pointer save address
   From cui/hal/maxwell/maxwell.h
   This is given as CU_MAXWELL_LMEM_TOTAL_SIZE           -
                    CU_MAXWELL_LMEM_DEBUGGER_SIZE        -
                    CU_MAXWELL_LMEM_THREAD_STATE_SIZE    +
                    offsetof(CUmaxwellThreadState, savedUserStackPointer)
   This works out to 0x1000000 - 512 - 32 + 16 = 0xfffdf0
*/
#define MAXWELL_LMEM_SAVED_STACK_POINTER 0xfffdf0ULL

/* The number of the register where the stack pointer
   is placed */
#define MAXWELL_ABI_SP_REGNUM 1

/* Maxwell has separated the PR and CC registers, and
   we save them in 2 contiguous bytes in lmem hi
   (15:8 = CC bits, 7:0 = Predicate bits) */
#define MAXWELL_CC_SHIFT     8
#define MAXWELL_CC_BITMASK 0xf

/* MEMBAR WAR : Spill location for R2, R3
    These are setup in cui/hal/maxwell/maxwell.h
    These values are compile time asserted in the driver build. If any changes
    happen to cui/hal/maxwell/maxwell.h, they _MUST_ be changed here.
  */
#define MAXWELL_LMEM_HI_MEMBAR_WAR_SPILL_R2 0xfffdf8
#define MAXWELL_LMEM_HI_MEMBAR_WAR_SPILL_R3 0xfffdfc

void haloDeviceInit_gm100(Halo_st *halo);

#endif
