/*
 * Copyright 2013-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef FERMI_SCRATCHPAD_H
#define FERMI_SCRATCHPAD_H

#include <halo_scratchpad_consts.h>
/* Lane scratchpad */
typedef struct {
    uint32_t threadIdx;      // SR32 / SR_Tid / threadIdx.{x,y,z}
    uint32_t r1;             // Special case, needed for stack check
} FermiLaneScratchpad_t;

/* The Scratchpad to the (soon) zerocopy chunk of memory use to
   communicate between the traphandler and the debugger */
typedef struct {
    uint32_t virtID;             // SR3
    uint32_t ctaParam;           // SR36 CRS size per warp (pushed by method)
    uint32_t blockIdxX;          // SR37
    uint32_t blockIdxY;          // SR38
    uint32_t blockIdxZ;          // SR39
    uint32_t blockDimX;          // SR41
    uint32_t blockDimY;          // SR42
    uint32_t blockDimZ;          // SR43
    uint32_t gridParam;          // SR44 Unique Grid ID (pushed by method)
    uint32_t gridDimX;           // SR45
    uint32_t gridDimY;           // SR46
    uint32_t gridDimZ;           // SR47
    uint32_t shmemSizePrBlock;   // SR50
    uint32_t lmemWindowSize;     // SR53
    uint32_t lmemLoSizePrThread; // SR54
    uint32_t lmemHiOff;          // SR55
    uint32_t globalErrorStatus;  // SR64
    uint32_t warpErrorStatus;    // SR66
    uint32_t paramConstDptrLo;   // Low 32-bits of param constbank backing store
    uint32_t paramConstDptrHi;   // High 32-bits of param constbank backing store
    FermiLaneScratchpad_t lane[32];
    uint32_t singleStepNsteps;   // How many single steps to perform; pause is executed when nsteps reaches 0
} FermiWarpScratchpad_t;

typedef struct {
    uint32_t         active;     // to identify the active context on the device
    uint32_t         padding[3]; // force alignment to 128 because shared to global copy uses ST128.
    FermiWarpScratchpad_t warp[CUDBG_MAX_TOTAL_SMS_FERMI][CUDBG_MAX_WARP_FERMI]; // 128-bit aligned
    // More stuff here ...
} FermiScratchpad_t;

/* For scratchpad allocation (done in cudbgdriver.c):

   Params for each warp:
        (CTAParam + GridParam + LWINSZ + LmemLoSz + LmemHiOff + SharedMem)

   Shared memory  = Max addressable shared mem for each CTA = 48K

   See fermi_collectScratchpad in fermi.c for how the scratchpad is used. */
#define FERMI_TRAP_HANDLER_SCRATCHPAD_PARAMS_SIZE (sizeof(FermiScratchpad_t))
#define FERMI_TRAP_HANDLER_SCRATCHPAD_SHARED_SIZE (49152)
#define FERMI_TRAP_HANDLER_SCRATCHPAD_SIZE        (FERMI_TRAP_HANDLER_SCRATCHPAD_PARAMS_SIZE + \
                                                   FERMI_TRAP_HANDLER_SCRATCHPAD_SHARED_SIZE)

/* Shared memory offset (in bytes) within the trap handler scratchpad allocation */
#define FERMI_TRAP_HANDLER_SCRATCHPAD_OFFSET_SHARED FERMI_TRAP_HANDLER_SCRATCHPAD_PARAMS_SIZE

#endif
