/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: fermi.h
 *
 *   Description:
 *       Debugger access functions that are different for the Fermi family.
 *
 ******************************************************************************/

#ifndef _HALO_FERMI_H
#define _HALO_FERMI_H

#include <halo.h>
#include <fermi_sass_assembler.h>
#include <fermi_mcinterop.h>
#include <fermi_scratchpad.h>
#include <fermi_exports.h>

#define CU_FERMI_LMEM_TOTAL_SIZE                0x1000000 // 16M is always total size of local mem/thread

#define CUDBG_FERMI_BAR0_PGRAPH_REGS_START  0x400000
#define CUDBG_FERMI_BAR0_PGRAPH_REGS_SIZE   0x200000

/*
 * Fermi GPC/TPC PRI offset macros
 */
#define FERMI_GPC_OFFSET 0x8000
#define FERMI_TPC_OFFSET 0x800

/* Fermi Generic Thread Address Space (GTAS)

   Fermi introduced a "uniform address space" which allows access
   to shared and local memory though general pointers. The magic
   holes in the address space are given by
   CU_FERMI_SHARED_WINDOW_BASE and CU_FERMI_LMEM_WINDOW_BASE which
   are defined in:

         //sw/dev/gpu_drv/cuda_a/drivers/gpgpu/cuda/src/cui/hal/fermi/fermi.h
*/
#define FERMI_GTAS_SHARED_WINDOW_BASE 0x0000000001000000ULL
#define FERMI_GTAS_LOCAL_WINDOW_BASE  0x0000000003000000ULL
#define FERMI_GTAS_GLOBAL_WINDOW_BASE 0x0000000005000000ULL

// 32-bit breakpoint instruction
#define FERMI_BREAKPT32 0x8000007FU // BPT_N.TRAP
#define FERMI_BREAKPT64 0xd00000000000c007ULL

#define FERMI_64_BIT_INST         0x00000000ULL
#define FERMI_64_BIT_INST_MASK    0x00000008ULL

/* There are 7 predicate registers on Fermi (P0-P6) */
#define FERMI_NUM_PREDICATES 7
#define FERMI_CC_SHIFT      12 /* CC bits are stored at 15:12 in PR */
#define FERMI_CC_BITMASK   0xf /* There are 4 CC registers, in bits 15:12 of PR */

/*
                  Fermi CRS LAYOUT

    The following diagram shows a single cache line
    in stack memory (which lies underneath local
    memory).  A single cache line is 128 bytes, and
    each CRS entry is 10 bytes, which means 12
    entries can fit while the remaining 8 bytes
    are unused.

              [ # of bits per field]              [Idx]

          8      3     5         32       30   2 |
    ----------------------------------------------        -----
    | Checksum | X | Type | Active Mask | PC | X |  0       |
    ----------------------------------------------          |
    |                                            |  1       |
    ----------------------------------------------      128 bytes
                        . . .                               |
    ----------------------------------------------          |
    |                                            | 11       |
    ----------------------------------------------          |
    ////////////// UNUSED 8 BYTES ////////|                 |
    ---------------------------------------               -----

    |-----------------10 bytes-------------------|
    High-order                           Low-order

    To make things more complicated, CRS entries are
    not contiguous (which may be falsely conveyed from
    the above diagram).  The cache line is arranged as
    follows:

    ---------------------------------------------
    | 32 bytes | 32 bytes | 32 bytes | 32 bytes |
    ---------------------------------------------

    ...which is organized into the following:

    ---------------------------------------------
    |10|10|10|2|10|10|10|2|10|10|10|2|8|8|8|N/A | (#s in bytes)
    ---------------------------------------------

    So, the first 3 CRS entries in each 32-byte subgroup
    are contiguous.  The last (4th) entry in each of the
    first 3 32-byte subgroups is the problem:  2 bytes
    are kept in the first 32-byte subgroup, and the
    remaining 8 bytes are kept in the last 32-byte
    subgroup (for each of the 3 split entries). Again,
    the last 8 bytes are unused in the last subgroup.

    The default CRS size is 512 bytes per warp which
    means there are 4 cache lines representing CRS
    entries per warp by default.
*/

#define FERMI_CACHE_LINE_SIZE           128 /* Each cache line is 128 bytes */
#define FERMI_CRS_ENTRY_SIZE             10 /* CRS entries are 10 bytes */
#define FERMI_CRS_ENTRIES_PER_LINE       12 /* 12 CRS entries per cache line */
#define FERMI_CRS_PC_OFFSET               0 /* PC is the first field in an entry */
#define FERMI_CRS_MASK_OFFSET             4 /* Mask is 4 bytes into an entry */
#define FERMI_CRS_TYPE_OFFSET             8 /* Type is 8 bytes into an entry */
#define FERMI_CRS_XSUM_OFFSET             9 /* Xsum is 9 bytes into an entry */

/* The local heap is divided into 512-byte blocks */
#define FERMI_LCL_CHUNK_SIZE            512

/* The maximum amount of CRS tokens that can be pushed (per warp) */
#define FERMI_MAX_CRS_ENTRIES_PER_WARP(vsm,wp) ((dev->smState[vsm].warp[wp].lmemConfig.CRSSize / \
                                                FERMI_CACHE_LINE_SIZE) * \
                                                FERMI_CRS_ENTRIES_PER_LINE)

#define FERMI_NUM_CRS_DIS_ENTRIES         6 /* The # of DISABLE entries pushed upon trapping */

/* Local memory ABI definitions
 *
 * !! IMPORTANT !!
 *
 * The following are used as negative offsets from
 * the end of lmem (high).  These must match the
 * offsets used in the trap handler. */
#define FERMI_LMEM_ABI_HI(vsm,wp) (dev->smState[vsm].warp[wp].lmemConfig.windowSize) // 16MB
#define FERMI_LMEM_ABI_SAVED_R0                 4
#define FERMI_LMEM_ABI_SAVED_R63              256
#define FERMI_LMEM_ABI_SAVED_SCRATCHPAD_PTR   260
#define FERMI_LMEM_ABI_TEXTURE_COORDS_3       264
#define FERMI_LMEM_ABI_TEXTURE_COORDS_2       268
#define FERMI_LMEM_ABI_TEXTURE_COORDS_1       272
#define FERMI_LMEM_ABI_TEXTURE_COORDS_0       276
#define FERMI_LMEM_ABI_TEXTURE_READ_RESULT    276 /* COORDS_0 reused for the result */
/* 280 - 312: RESERVED */
#define FERMI_LMEM_ABI_SAVED_PREDICATES       316
#define FERMI_LMEM_ABI_TH_SERVICE_REASON      328
#define FERMI_LMEM_ABI_TH_SERVICE_NUM_LANES   332
#define FERMI_LMEM_ABI_TH_SERVICE_ADDR        336
#define FERMI_LMEM_ABI_TH_SERVICE_SIZE        340

// Maximum shared memory size per SM on GF100 */
#define FERMI_MAX_SHARED_MEM_PER_SM     (48*1024)

/* Fermi system stack pointer save address
   From cui/hal/fermi/fermi.h
   This is given as CU_FERMI_LMEM_HIGH -
                    CU_FERMI_LMEM_DEBUGGER_SIZE -
                    CU_FERMI_LMEM_THREAD_STATE_SIZE +
                    offsetof(CUfermiThreadState, savedUserStackPointer)
   This works out to 0x1000000 - 0x200 - 0x10 + 0 = 0xfffdf0
*/
#define FERMI_LMEM_SAVED_STACK_POINTER 0xfffdf0ULL

/* The number of the register where the stack pointer
   is placed */
#define FERMI_ABI_SP_REGNUM 1

typedef struct {
    unsigned char p[32];
} chunk32_t;
typedef uint64_t chunk8_t;

typedef union {
    /* For advancing within L1 cache lines */
    unsigned char *p;
    chunk32_t *chunk32;
    chunk8_t *chunk8;

    /* CRS entry fields below */
    uint32_t *pc;
    uint32_t *mask;
    uint8_t  *type;
    uint8_t  *xsum;
} CRSMagicCast_t;

/* Per-lane global/warp error status codes (from SR64 and SR66).
   Enumerations, bitfields, and explanations derived from:

   //hw/doc/gpu/fermi/fermi/design/IAS/SPM/ISA/opcodes/IAS_Visible_ISA_1_Fermi.htm
   //hw/doc/gpu/fermi/fermi/design/IAS/SPM/ISA/opcodes/opS2R.htm
*/

/* Bitfields for global errors */
typedef enum {
    GLOBAL_ERROR_STATUS_CPU_STOP_INTERRUPT_FIELD = 4,
    /* Indicates the CPU has forced this SM to stop by writing the
       RUN_TRIGGER bit in the CONTROL0 register (this happens for
       us when we need to stop all SMs, or if a user hits Ctrl+C).

       Report type:  CUDBG_EXCEPTION_NONE */

    GLOBAL_ERROR_STATUS_SM_TO_SM_FAULT_PROPAGATION_FIELD = 5,
    /* Indicates that a different SM encountered a fault and
       that the other SMs should stop as well.

       Report type:  CUDBG_EXCEPTION_NONE */

    GLOBAL_ERROR_STATUS_L1_ERROR_FIELD = 6,
    /* Indicates that one or more load/store errors have been
       caused by this SM.  L1 HWW PRI registers can provide
       more information as to one of the possible causes:

          1.  local/stack request to address that exceeds SM allocation.
          2.  global store remapped to segment not enabled for writes.
          3.  global load remapped to segment not enabled for reads.
          4.  MMU page fault.

       According to the arch group, #1 can only be triggered if SM doesn't
       catch the bogus local/stack request before L1 does.  Under normal
       executing circumstances, generic local/stack requests that exceed
       the SM allocation are caught at the warp level as OOR_ADDR exceptions.

      Report type:  CUDBG_EXCEPTION_DEVICE_ILLEGAL_ADDRESS

      Errata:  the warp that caused the fault is not known on GF100 by SM. */

    GLOBAL_ERROR_STATUS_MULTIPLE_WARP_ERRORS_FIELD = 7,
    /* Indicates an existing warp error on this SM is masking
       a subsequent warp error that could not be logged.

       Report type:  the error report type found from the warp esr */

    GLOBAL_ERROR_STATUS_PHYSICAL_STACK_OVERFLOW_FIELD = 8,
    /* Indicates CRS stack limit has been exceeded on this SM.

       Report type:  CUDBG_EXCEPTION_DEVICE_HARDWARE_STACK_OVERFLOW */

    GLOBAL_ERROR_STATUS_SINGLE_WARP_ERROR_FIELD = 9,
    /* Indicates there is a warp error on this SM and it has
       not yet been cleared.

       Report type:  the error report type found from the warp esr */
} globalErrorStatusGF100_t;

#define SR_WARP_ERROR_MASK 0xff /* Lower byte used to enumerate warp errors (below) */
typedef enum {
    WARP_ERROR_STATUS_NONE = 0,
    /* Warp error status is clear. */

    WARP_ERROR_STACK_ERROR = 1,
    /* Catches CRS mismatches (RAM with top-of-stack not SAM, BRK
       with no matching PBK, CONT with no matching PCNT, op.S with
       no matching SSY, or a generally corrupted stack.

       Report type:  CUDBG_EXCEPTION_WARP_HARDWARE_STACK_OVERFLOW */

    WARP_ERROR_API_STACK_ERROR = 2,
    /* Catches the case that the API stack limit has been exceeded.
       This limit is set via pushbuffer method by the driver -- the
       CUDA driver sets it as unlimited, so this "should never happen".

       Report type:  CUDBG_EXCEPTION_WARP_HARDWARE_STACK_OVERFLOW */

    WARP_ERROR_RET_EMPTY_STACK_ERROR = 3,
    /* This is an "allowable condition" that is normally turned into
       a silent warp exit.

       Report type:  CUDBG_EXCEPTION_NONE */

    WARP_ERROR_PC_WRAP = 4,
    /* Catches when the PC wraps the 32-bit address space for a
       sequential instruction, or when the next PC pushed on the
       stack wraps the 32-bit address space.

       Report type:  CUDBG_EXCEPTION_WARP_INVALID_PC */

    WARP_ERROR_MISALIGNED_PC = 5,
    /* Catches branch target addresses that are not 4-byte aligned.

       Report type:  CUDBG_EXCEPTION_WARP_ILLEGAL_INSTRUCTION */

    WARP_ERROR_PC_OVERFLOW = 6,
    /* Catches relative branch target address computations that overflow
       32-bits.

       Report type:  CUDBG_EXCEPTION_WARP_ILLEGAL_INSTRUCTION */

    WARP_ERROR_MISALIGNED_IMMC$_ADDR = 7,
    /* Catches misaligned (not 4-byte aligned) 64-bit immediate constant
       cache addresses.

       Report type:  CUDBG_EXCEPTION_WARP_ILLEGAL_INSTRUCTION

       Errata:  this exception may be caught even if the instruction
                is never executed (checked before predication). */

    WARP_ERROR_MISALIGNED_REG = 8,
    /* Catches misaligned register access (read/write).

       Report type:  CUDBG_EXCEPTION_WARP_ILLEGAL_INSTRUCTION

       Errata:  this exception may be caught even if the instruction
                is never executed (checked before predication). */

    WARP_ERROR_ILLEGAL_INSTR_ENCODING = 9,
    /* Catches illegal pipe specifiers, invalid opcodes, unsupported
       field encodings, 8-byte instructions on 4-byte boundaries, and
       "invalid shader".

       Report type:  CUDBG_EXCEPTION_WARP_ILLEGAL_INSTRUCTION */

    WARP_ERROR_ILLEGAL_SPH_INSTR_COMBINATION = 10,
    /* Catches illegal instruction state.

       Report type:  CUDBG_EXCEPTION_WARP_ILLEGAL_INSTRUCTION */

    WARP_ERROR_ILLEGAL_INSTR_PARAM = 11,
    /* Catches barrier names > 15 or > the CTA's barrier allotment,
       barrier counts > 1536 or not a multiple of the warp size,
       different barrier counts to same barrier name across warps,
       and barrier type conflicts (reduction and non-reduction).

       Report type:  CUDBG_EXCEPTION_WARP_ILLEGAL_INSTRUCTION */

    WARP_ERROR_INVALID_CONST_ADDR = 12,
    /* Catches constant banks beyond the implementation-supported range,
       and negative offsets or offests > 65535.

       Report type:  CUDBG_EXCEPTION_WARP_ILLEGAL_INSTRUCTION

       Errata:  this exception may be caught even if the instruction
                is never executed (checked before predication). */

    WARP_ERROR_OOR_REG = 13,
    /* Catches register access (read/write) beyond MAX_REG_NUM.

       Report type:  CUDBG_EXCEPTION_WARP_ILLEGAL_INSTRUCTION

       Errata:  this exception may be caught even if the instruction
                is never executed (checked before predication). */

    WARP_ERROR_OOR_ADDR = 14,
    /* Catches local hi/lo accesses that are not within the 0-16MB local
       window (or not within the local allocation), shared accesses that
       are not within the shared mem region, and generic accesses that
       are not within the 40-bit VA range (catches all segments).

       Report type:  CUDBG_EXCEPTION_WARP_OUT_OF_RANGE_ADDRESS */

    WARP_ERROR_MISALIGNED_ADDR = 15,
    /* Catches misaligned addresses for all memory segments.

       Report type:  CUDBG_EXCEPTION_WARP_MISALIGNED_ADDRESS */

    WARP_ERROR_INVALID_ADDR_SPACE = 16,
    /* Catches LDLK/STUL instructions that access global or local memory,
       or ATOM/RED instructions that access local or shared memory.

       Report type:  CUDBG_EXCEPTION_WARP_INVALID_ADDRESS */

    WARP_ERROR_ILLEGAL_INSTR_PARAM2 = 17,
    /* Catches different barrier names in a single warp, different
       barrier counts within a warp, and different addresses to
       LD.BV or LDS.BV within a warp.

       Report type:  CUDBG_EXCEPTION_WARP_ILLEGAL_INSTRUCTION */

    WARP_ERROR_INVALID_CONST_ADDR_LDC = 18,
    /* Catches a special case of an invalid constant address, for
       LDC, BRX, and JMX instructions which do not suffer from the
       predication errata.

       Report type:  CUDBG_EXCEPTION_WARP_ILLEGAL_INSTRUCTION */

    WARP_ERROR_GEOMETRY_SM_ERROR = 19,
    /* Catches when AST and OUT state registers are corrupt.
       Graphics only.

       Report type:  CUDBG_EXCEPTION_NONE */

    WARP_ERROR_DIVERGENT = 20,
    /* Catches when all threads are not active within a quad when
       executing the FSWZ instruction.  Graphics only.

       Report type:  CUDBG_EXCEPTION_NONE */

    WARP_ERROR_TRAP_ON_WARP_EXIT = 21,
    /* Catches when one warp has exited the SM - Kepler ONLY.
       Beware, this should *never* be used to track multiple
       warps, as it will conflict with MULTIPLE_WARP_ERRORS
       in the global ESR, and can hide actual exceptions.
       This error does not propagate outside of the API.

       Report type:  CUDBG_EXCEPTION_NONE */

    WARP_ERROR_PHYSICAL_STACK_OVERFLOW = 22,
    /* Maxwell Only
       Catches the case when a warp has overflowed its CRS Stack.
       This used to be global, but starting Maxwell, this is per
       warp.
       Report type: CUDBG_EXCEPTION_WARP_HARDWARE_STACK_OVERFLOW
    */

    WARP_ERROR_MMU_FAULT = 23,
    /* Maxwell Only
       Catches the case where a memory access from a warp causes
       an MMU fault. This used to be global, but starting Maxwell
       this is per Warp.
       Report type: CUDBG_EXCEPTION_WARP_MMU_FAULT
    */
} warpErrorStatusGF100_t;



/* Exported to the driver */
void haloDeviceInit_gf100(Halo_st *halo);

CUDBGResult fermi_getGridStatus(CudbgDevice dev, uint64_t gridId64, CUDBGGridStatus *status);
CUDBGResult fermi_suspendDevice(CudbgDevice dev, uint32_t *hasStopped, uint32_t *waitForEvent, Context *residentContext);
CUDBGResult fermi_readWarpMaskPRI(CudbgDevice dev, uint32_t vsm, HaloRegOpType type, HaloMaskPRI pri, CUwarpBitmask *mask);
CUDBGResult fermi_writeWarpMaskPRI(CudbgDevice dev, uint32_t vsm, HaloRegOpType type, HaloMaskPRI pri, CUwarpBitmask *mask);
CUDBGResult fermi_convertPhysicalToVirtual(Halo_st *halo, uint32_t tpc, uint32_t phys_wp, uint32_t cta_id, uint32_t* vsm, uint32_t* vwp, uint32_t* vcta_id);
CUDBGResult fermi_convertVirtualToPhysical(Halo_st *halo, uint32_t vsm, uint32_t vwp, uint32_t vcta_id, uint32_t* tpc, uint32_t* phys_wp, uint32_t* cta_id);
CUDBGResult fermi_readSMESRInfo(CudbgDevice dev, uint32_t vsm, CudbgSMState_t *state, HaloDebugObjMode_t debugObjMode);
CUDBGResult fermi_clearSMESRInfo(CudbgDevice dev, uint32_t vsm, CudbgSMState_t *state, HaloDebugObjMode_t debugObjMode);
CUDBGResult fermi_suspendTPC(CudbgDevice dev, uint32_t vsm);
CUDBGResult fermi_preemptPreHook(CudbgDevice dev, int32_t vsm);
CUDBGResult fermi_preemptPostHook(CudbgDevice dev, int32_t vsm);

#endif
