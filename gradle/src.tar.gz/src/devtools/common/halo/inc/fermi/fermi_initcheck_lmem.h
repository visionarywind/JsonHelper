/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef INITCHECK_LMEM_H
#define INITCHECK_LMEM_H

/* LMEM Hi usage in initcheck (matches the layout in memcheck)

    -----------------  0x00 = 0xfffe00
    |      R0       |
    |      R1       |
    |      R2       |
    |      R3       |
    -----------------  0x10 = 0xfffe10
    |      R4       |
    |      R5       |
    |      R6       |
    |      R7       |
    -----------------  0x20 = 0xfffe20
    |      R8       |
    |      R9       |
    |      R10      |
    |      R11      |
    -----------------  0x30 = 0xfffe30
    |      R12      |
    |      R13      |
    |      R14      |
    |      R15      |
    -----------------  0x40 = 0xfffe40
    |    ADDR_LO    |
    |    ADDR_HI    |
    |    PC_LO      |
    |    PC_HI      |
    -----------------  0x50 = 0xfffe50
    |    ASIZE      |
    |    PRED       |
    |    reserved   |
    |    MAGIC      |
    -----------------  0x60 = 0xfffe60

*/


#define INITCHECK_LMEM_R0           0x00  // Offset that R0 is saved to
#define INITCHECK_LMEM_R1           0x04  // Offset that R1 is saved to
#define INITCHECK_LMEM_R2           0x08  // Offset that R2 is saved to
#define INITCHECK_LMEM_R3           0x0c  // Offset that R3 is saved to
#define INITCHECK_LMEM_R4           0x10  // Offset that R4 is saved to
#define INITCHECK_LMEM_R5           0x14  // Offset that R5 is saved to
#define INITCHECK_LMEM_R6           0x18  // Offset that R6 is saved to
#define INITCHECK_LMEM_R7           0x1c  // Offset that R7 is saved to
#define INITCHECK_LMEM_R8           0x20  // Offset that R8 is saved to
#define INITCHECK_LMEM_R9           0x24  // Offset that R9 is saved to
#define INITCHECK_LMEM_R10          0x28  // Offset that R10 is saved to
#define INITCHECK_LMEM_R11          0x2c  // Offset that R11 is saved to
#define INITCHECK_LMEM_R12          0x30  // Offset that R12 is saved to
#define INITCHECK_LMEM_R13          0x34  // Offset that R13 is saved to
#define INITCHECK_LMEM_R14          0x38  // Offset that R14 is saved to
#define INITCHECK_LMEM_R15          0x3c  // Offset that R15 is saved to
#define INITCHECK_LMEM_ADDR         0x40  // Address the access was going to
#define INITCHECK_LMEM_ADDR_HI      0x44  // High part for 64 bit address
#define INITCHECK_LMEM_PC           0x48  // Original PC (lo)
#define INITCHECK_LMEM_PC_HI        0x4c  // Original PC (hi)
#define INITCHECK_LMEM_ASIZE        0x50  // Access Size
#define INITCHECK_LMEM_PRED         0x54  // Original Predicate Register
#define INITCHECK_LMEM_RESERVED1    0x58  // reserved
#define INITCHECK_LMEM_MAGIC        0x5c  // Is a valid memcheck error

#endif
