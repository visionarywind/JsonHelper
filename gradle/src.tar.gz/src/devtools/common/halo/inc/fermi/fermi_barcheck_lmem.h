/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef BARCHECK_LMEM_H
#define BARCHECK_LMEM_H
/* LMEM usage. These  are positive offsets from FERMI_LMEM_HI_MEMCHECK_SCRATCH.
   The offsets are in bytes

   ------------------  0xfffe00
   |   R0           |
   |   R1           |
   |   R2           |
   |   R3           |
   ------------------  0xfffe10
   |   R4           |
   |   R5           |
   |   R6           |
   |   R7           |
   ------------------  0xfffe20
   |   R8           |
   |   R9           |
   |   R10          |
   |   R11          |
   ------------------  0xfffe30
   |   R12          |
   |   R13          |
   |   R14          |
   |   R15          |
   ------------------  0xfffe40
   |   CTA_TABLE_LO |
   |   CTA_TABLE_HI |
   |   PRED/CC      |
   |   BAR_DATA     |
   ------------------  0xfffe50
   |   PC           |
   |   PC_HI        |
   |   RB           |
   |   MAGIC        |
   ------------------  0xfffe60
*/

#define BARCHECK_LMEM_R0        0x0000
#define BARCHECK_LMEM_R1        0x0004
#define BARCHECK_LMEM_R2        0x0008
#define BARCHECK_LMEM_R3        0x000c
#define BARCHECK_LMEM_R4        0x0010
#define BARCHECK_LMEM_R5        0x0014
#define BARCHECK_LMEM_R6        0x0018
#define BARCHECK_LMEM_R7        0x001c
#define BARCHECK_LMEM_R8        0x0020
#define BARCHECK_LMEM_R9        0x0024
#define BARCHECK_LMEM_R10       0x0028
#define BARCHECK_LMEM_R11       0x002c
#define BARCHECK_LMEM_R12       0x0030
#define BARCHECK_LMEM_R13       0x0034
#define BARCHECK_LMEM_R14       0x0038
#define BARCHECK_LMEM_R15       0x003c

#define BARCHECK_LMEM_CTA_TABLE_LO 0x0040
#define BARCHECK_LMEM_CTA_TABLE_HI 0x0044
#define BARCHECK_LMEM_PRED         0x0048
#define BARCHECK_LMEM_BAR_DATA     0x004c

#define BARCHECK_LMEM_PC        0x0050
#define BARCHECK_LMEM_PC_HI     0x0054
#define BARCHECK_LMEM_RB        0x0058
#define BARCHECK_LMEM_MAGIC     0x005c

#endif
