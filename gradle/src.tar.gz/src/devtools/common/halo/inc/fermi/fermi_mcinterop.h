/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef FERMI_MCINTEROP_H
#define FERMI_MCINTEROP_H

/*
  By special contract, cuda-memcheck/Fermi is granted a chunk of
  LMEM_HI space in the debuggers 512 byte allocation. To minimize the
  risk of conflict, we place them at the end of the block. This isn't
  and shouldn't be used by the debugger and is only here for
  reference.

*/
#define FERMI_LMEM_HI_MEMCHECK_SCRATCH        0xfffe00  //16777216-512 = 0xfffe00
#define FERMI_LMEM_HI_MEMCHECK_SCRATCH_TOP    512 // Really 16777216-512 = 0xfffe00
#define FERMI_LMEM_HI_MEMCHECK_SCRATCH_SIZE    96
#define FERMI_LMEM_HI_MEMCHECK_SCRATCH_END    416 // Really 16777216-416 = 0xfffe40

/* LMEM Hi usage in memcheck

    -----------------  0x00 = 0xfffe00
    |      R0       |
    |      R1       |
    |      R2       |
    |      R3       |
    -----------------  0x10 = 0xfffe10
    |      R4       |
    |      R5       |
    |      R6       |
    |      R7       |
    -----------------  0x20 = 0xfffe20
    |      R8       |
    |      R9       |
    |      R10      |
    |      R11      |
    -----------------  0x30 = 0xfffe30
    |      R12      |
    |      R13      |
    |      R14      |
    |      R15      |
    -----------------  0x40 = 0xfffe40
    |    ADDR_LO    |
    |    ADDR_HI    |
    |    PC_LO      |
    |    PC_HI      |
    -----------------  0x50 = 0xfffe50
    |    AMASK      |
    |  ORIG_PRED    |
    |  PRED_SYSCALL |
    |    MAGIC      |
    -----------------  0x60 = 0xfffe60

*/


/* On Fermi and GK10x memcheck will place interop data in LMEM_HI. The values
   below are positive offsets from LMEM_HI_MEMCHECK_SCRATCH (i.e. inside the
   memcheck portion of the LMEM_HI space).
*/
#define FERMI_LMEM_MEMCHECK_PC      0x48 // Original PC
#define FERMI_LMEM_MEMCHECK_ADDR    0x40 // Address the access was going to
#define FERMI_LMEM_MEMCHECK_ADDR_HI 0x44 // High part for 64 bit address
#define FERMI_LMEM_MEMCHECK_AMASK    0x50 // Alignment mask
#define FERMI_LMEM_MEMCHECK_PRED    0x54 // Original Predicate Register
#define FERMI_LMEM_MEMCHECK_PREDSYSCALL 0x58 // Predicate for syscall
#define FERMI_LMEM_MEMCHECK_MAGIC   0x5C // Is a valid memcheck error
#define FERMI_LMEM_MEMCHECK_R0      0x00  // Offset that R0 is saved to
#define FERMI_LMEM_MEMCHECK_R1      0x04  // Offset that R1 is saved to
#define FERMI_LMEM_MEMCHECK_R2      0x08  // Offset that R2 is saved to
#define FERMI_LMEM_MEMCHECK_R3      0x0c  // Offset that R3 is saved to
#define FERMI_LMEM_MEMCHECK_R4      0x10  // Offset that R4 is saved to
#define FERMI_LMEM_MEMCHECK_R5      0x14  // Offset that R5 is saved to
#define FERMI_LMEM_MEMCHECK_R6      0x18  // Offset that R6 is saved to
#define FERMI_LMEM_MEMCHECK_R7      0x1c  // Offset that R7 is saved to
#define FERMI_LMEM_MEMCHECK_R8      0x20  // Offset that R8 is saved to
#define FERMI_LMEM_MEMCHECK_R9      0x24  // Offset that R9 is saved to
#define FERMI_LMEM_MEMCHECK_R10     0x28  // Offset that R10 is saved to
#define FERMI_LMEM_MEMCHECK_R11     0x2c  // Offset that R11 is saved to
#define FERMI_LMEM_MEMCHECK_R12     0x30  // Offset that R12 is saved to
#define FERMI_LMEM_MEMCHECK_R13     0x34  // Offset that R13 is saved to
#define FERMI_LMEM_MEMCHECK_R14     0x38  // Offset that R14 is saved to
#define FERMI_LMEM_MEMCHECK_R15     0x3c  // Offset that R15 is saved to

/*  The magic number written into LMEM

    31---------------------------4:4--3:2--1:0---
      |      MAGIC (31 : 5)      | SA | ID |ADDR|
      -------------------------------------------

    The upper 28 bits contain the magic number.
    The next 1 bit  (4:4) is set if this access is through a system-scoped atomic.
    The next 2 bits (3:2) contain the encoded syscall error.
    The last 2 bits (1:0) contains the address space of the error.
*/

/* The actual value that will be written at offset LMEM_MEMCHECK_MAGIC if
   memcheck hit a valid error.
*/
#define FERMI_MEMCHECK_WHITEMAGIC_MASK 0xffffffe0
#define FERMI_MEMCHECK_WHITEMAGIC      0xcafefec0

/* The lowest 2 bits (1:0) of the magic number contains the address space
   of the fault. This will be of type CUmemcheck_addrType_types
*/
#define FERMI_MEMCHECK_ADDR_MASK   0x3U

/* The bits (3:2) of the magic number contain the type of the syscall
   error (MCSCresult). For now, we encode this into two bits.
*/
#define FERMI_MEMCHECK_SYSCALL_MASK 0xCU

/* Bit (4:4) of the magic number determines if the access was through
   a system-scoped atomic. */
#define FERMI_MEMCHECK_ATOMSYS_MASK 0x10U

#define FERMI_SMEM_MASK_INV         0xFF000000

/* Error codes returned by memcheck patches */
#define FERMI_MEMCHECK_ERROR_NONE    0x0
#define FERMI_MEMCHECK_ERROR_ALIGN   0x1
#define FERMI_MEMCHECK_ERROR_SMEM    0x2
#define FERMI_MEMCHECK_ERROR_GMEM    0x3
#define FERMI_MEMCHECK_ERROR_HEAP    0x4
#define FERMI_MEMCHECK_ERROR_ATOMSYS 0x5
#define FERMI_MEMCHECK_ERROR_LMEM    0x6

/* Flags and masks for access size parameter

  31-------------16-15-------8-7------------0
   |    reserved   |  flags   | access size |
    ----------------------------------------
*/
#define FERMI_MEMCHECK_ASIZE_SIZE_MASK  0xff
#define FERMI_MEMCHECK_ASIZE_SIZE_BITS  0x8
#define FERMI_MEMCHECK_ASIZE_FLAGS_MASK 0xff00
#define FERMI_MEMCHECK_ASIZE_FLAG_NONE                  0x0
#define FERMI_MEMCHECK_ASIZE_FLAG_ATOMSYS               0x1
#define FERMI_MEMCHECK_ASIZE_FLAG_ABI                   0x2
#define FERMI_MEMCHECK_ASIZE_FLAG_HOST_ATOMIC_SUPPORTED 0x4

#define FERMI_MEMCHECK_ASIZE_FLAG_SHIFTED_NONE                  0x0   // (0x0 << FERMI_MEMCHECK_ASIZE_SIZE_BITS)
#define FERMI_MEMCHECK_ASIZE_FLAG_SHIFTED_ATOMSYS               0x100 // (0x1 << FERMI_MEMCHECK_ASIZE_SIZE_BITS)
#define FERMI_MEMCHECK_ASIZE_FLAG_SHIFTED_ABI                   0x200 // (0x2 << FERMI_MEMCHECK_ASIZE_SIZE_BITS)
#define FERMI_MEMCHECK_ASIZE_FLAG_SHIFTED_HOST_ATOMIC_SUPPORTED 0x400 // (0x4 << FERMI_MEMCHECK_ASIZE_SIZE_BITS)

#endif

