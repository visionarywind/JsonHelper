/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef FERMI_OPCODES_H
#define FERMI_OPCODES_H

/* The following has been copied from what was fermi.h in the driver HAL */

// General per-thread scratchpad in lmem for use by the driver. This is here
// instead of in fermi_structs.h because the size of this struct is needed to
// resolve stack size #defines, and we can't #include fermi_structs.h here
// because it has a dependency on this header.
//
// This will be aligned on a CU_FERMI_LMEM_HIGH_ALIGN boundary.
typedef struct CUfermiThreadState_st {
    NvU32 savedUserStackPointer; // For syscalls
} CUfermiThreadState;

#define CU_FERMI_THREAD_STATE_OFFSET(field) (offsetof(CUfermiThreadState,field) + CU_FERMI_THREAD_STATE_POINTER)

// Fermi environment registers setup (via a constant bank)
// The env const bank layout is documented at //sw/compiler/gpgpu/doc/TeslaKernelLaunchABI.xls.
#define CU_FERMI_ENV_REGS_OPENCL                32
#define CU_FERMI_ENV_CONST_SEGMENT              1 // kernel environment (env regs + starting SP)

#define CU_FERMI_LMEM_TOTAL_SIZE                0x1000000 // 16M is always total size of local mem/thread
#define CU_FERMI_LMEM_DEBUGGER_SIZE             0x200     // 512b per thread for debugger
#define CU_FERMI_LMEM_THREAD_STATE_SIZE         ROUND_UP(sizeof(CUfermiThreadState), CU_FERMI_LMEM_HIGH_ALIGN)
#define CU_FERMI_THREAD_STATE_POINTER   (CU_FERMI_LMEM_TOTAL_SIZE       - \
                                         CU_FERMI_LMEM_DEBUGGER_SIZE    - \
                                         CU_FERMI_LMEM_THREAD_STATE_SIZE)

// See paranoid assertion below
#pragma pack(push, 4)
typedef struct {
    NvU32 envRegs[CU_FERMI_ENV_REGS_OPENCL];
    NvU64 constBank2Addr;      // 128
    NvU64 constBank3Addr;      // 136
    NvU64 constBank4Addr;      // 144
    NvU64 constBank5Addr;      // 152
    NvU64 constBank6Addr;      // 160
    NvU64 constBank7Addr;      // 168
    NvU64 constBank8Addr;      // 176
    NvU64 constBank9Addr;      // 184
    NvU64 constBank10Addr;     // 192
    NvU64 constBank11Addr;     // 200
    NvU64 constBank12Addr;     // 208
    NvU64 constBank0Addr;      // 216
    NvU32 mpsContextId;        // 224
    NvU32 userDynamicSmemSize; // 228
    NvU64 constBank1Addr;      // 232
    NvU64 reserved1[2];        // 240
    NvU32 stackPointer;        // 256
} CUfermiGridParams;
ct_assert(offsetof(CUfermiGridParams, constBank2Addr) == 128);
ct_assert(offsetof(CUfermiGridParams, constBank1Addr) == 232);
ct_assert(offsetof(CUfermiGridParams, stackPointer) == 256);
// Paranoid assertion that there is no padding hanging off the end of the struct, which
// might overlap syscall constants and trigger a runtime assertion in fermiConstMemConfig
ct_assert(offsetof(CUfermiGridParams, stackPointer) + sizeof(NvU32) == sizeof(CUfermiGridParams));
#pragma pack(pop)

#define CU_FERMI_DCI_OFFSET(field) offsetof(CUfermiGridParams, field)

#define CU_FERMI_LMEM_LOW_ALIGN  16
#define CU_FERMI_LMEM_HIGH_ALIGN 16
#define CU_FERMI_LMEM_CRS_ALIGN  512
#define CU_FERMI_LMEM_WARP_ALIGN 512
#define CU_FERMI_LMEM_SIZE_ALIGN (128*1024)

/*
  Duplicated from ../debugger/halo/fermi.h

    By special contract, cuda-memcheck/Fermi is granted a chunk of
    LMEM_HI space in the debuggers 512 byte allocation. To minimize the
    risk of conflict, we place them at the end of the block. This isn't
    and shouldn't be used by the debugger and is only here for
    reference.

    This is confusing because we use negative addresses here.

  We use this scratchpad to save off R0-R7 so we have working
  registers. We need R0, R1, and R2 to pass memaddr, memalignmask, and
  pc to the check function and probably need a few more registers to
  do the range compares effectively.
*/
#define FERMI_LMEM_HI_MEMCHECK_SCRATCH    0xfffe00 // 16777216-512
#define FERMI_LMEM_HI_MEMCHECK_SCRATCH_SIZE       96


/* Since we aren't using any local memory, just use MAXUINT */
#define MAX_LOCAL_MEM ~0U

/* Fermi memcheck doesn't need local memory (at least not local_lo) */
#define PATCH_LOCAL_MEM 0

/* Bitfield manipulations */
#define BF_LO(fld)          (0?fld) // BF_LO(HI:LO) == LO
#define BF_HI(fld)          (1?fld) // BF_HI(HI:LO) == HI
// ~0ULL << 4 = 0b111..1111110000
// ~0ULL << 9 = 0b111..1000000000
// ^          = 0b000..0111110000
#define BF_RUN(n)           (~0ULL << n)

// MSK create a bit mask from a hi:lo pair
#define MSK(fld)        (BF_RUN(BF_HI(fld)) << 1 ^ BF_RUN(BF_LO(fld)))

// Shifts a value into its bitfield
#define FLD(fld,v)        ((uint64_t)(fld##__##v) << BF_LO(fld))
#define FLDV(fld,v)       (MSK(fld) & ((uint64_t)(v)) << BF_LO(fld))

// Shifts bitfield down
#define GET(fld,v)        ((uint32_t) ((MSK(fld) & (v)) >> BF_LO(fld)))

// Copy the value of a bitfield from one word to another
#define COPY(fld,from,to) (((to) & ~MSK(fld)) | ((from) & MSK(fld)))

/* Partial Fermi instruction summary for load and store instructions */
#define FERMI32_LDST_IMM6 31:26
#define FERMI_SBR         31:26
#define FERMI_S24         49:26
#define FERMI_REGA        25:20
#define FERMI_REGB        19:14
#define FERMI_PRED        13:10
#define    FERMI_PRED__UNCOND   7 // 7 is always true
#define FERMI32_LDST_IMM2  9: 8
#define FERMI32_LDST_D64   7: 7  // 32-bit or 64-bit memory word
#define FERMI32_LDST_A64   6: 6  // Extended (64-bit) address
#define FERMI32_LDST_OP    5: 4  // LD_N=0, ST_N=1
#define    FERMI32_LDST_OP__LD_N 0
#define    FERMI32_LDST_OP__ST_N 1
#define FERMI_LOP          7:6
#define     FERMI_LOP_AND        0
#define     FERMI_LOP_OR         1
#define     FERMI_LOP_XOR        2
#define FERMI_NARROW       3: 3  // 32-bit instruction, 64-bit instruction
#define    FERMI_NARROW__64B 0
#define    FERMI_NARROW__32B 1
#define FERMI_BOT3         2: 0  // 3 for LD_N and ST_N
#define    FERMI_BOT3__LDST_N 3
#define    FERMI_BOT3__INT    4 // For BAR,BAR.SYNC
#define    FERMI_BOT3__LDST   5
#define    FERMI_BOT3__CTF    7 // JMP,JMX,JCALL,BRA,...

/* Texture related */
#define FERMI_TEX_ID       39:32
#define FERMI_SAMPLER      44:40
#define FERMI_TEX_DIM      53:52
#define FERMI_WRITEMASK    49:46
#define FERMI_TEX_REGD     19:14
#define FERMI_TEX_REGB     31:26

/* Normal (64-bit) version */
#define FERMI64_TOP2      63:62
#define    FERMI64_TOP2__ATOM 1
#define    FERMI64_TOP2__RED  0

#define FERMI64_TOP5      63:59
#define    FERMI64_TOP5__JMP     0
#define    FERMI64_TOP5__JMX     1
#define    FERMI64_TOP5__JCAL    2
#define    FERMI64_TOP5__CAL    10
#define    FERMI64_TOP5__FLO    15
#define    FERMI64_TOP5__LD     16
#define    FERMI64_TOP5__LDU    17
#define    FERMI64_TOP5__ST     18

#define FERMI64_TOP6       63:58
#define     FERMI64_TOP6__BAR 0x14
#define     FERMI64_TOP6__VOTE 0x12
#define     FERMI64_TOP6__POPC 0x15

/* Fields for vote */
#define FERMI64_VOTE_MODE 7:5
#define FERMI64_VOTE_PSRC  23:20
#define FERMI64_VOTE_PDST  57:54

#define FERMI64_ICOMP3 57:55

#define FERMI64_BOP1   54:53
#define FERMI64_BOP0   31:30

#define FERMI64_TOP8      63:56
#define    FERMI64_TOP8__MOV32I 0x18
#define    FERMI64_TOP8__LDL    0xC0
#define    FERMI64_TOP8__STL    0xC8
#define    FERMI64_TOP8__LDS    0xC1
#define    FERMI64_TOP8__STS    0xC9
#define FERMI64_IMM24     49:26
#define FERMI64_ABC       47:46
#define FERMI64_IMM20     45:26
#define FERMI64_IMM17     42:26
#define FERMI64_IMM16     41:26
#define FERMI64_IMM12     37:26
#define FERMI64_REG6      31:26

#define FERMI64_LDST_A64  58:58 // Extended (64-bit) address
#define FERMI64_IMM32     57:26 // Overlaps FERMI32_LDST_IMM2
#define FERMI64_INC       16:16
#define FERMI64_ICA       14:14
#define FERMI64_CC         9: 5
#define    FERMI64_CC__CC_T     15
#define FERMI64_COP2       9: 8 // WB, CG, CS, WT
#define    FERMI64_COP2__WB      0
#define    FERMI64_COP2__CG      1
#define    FERMI64_COP2__CS      2
#define    FERMI64_COP2__WT      3

#define FERMI_QUAD         8: 5

#define FERMI64_ARV        8: 8

#define FERMI64_SIZE3      7: 5
#define    FERMI64_SIZE3__U8     0
#define    FERMI64_SIZE3__S8     1
#define    FERMI64_SIZE3__U16    2
#define    FERMI64_SIZE3__S16    3
#define    FERMI64_SIZE3__32     4
#define    FERMI64_SIZE3__64     5
#define    FERMI64_SIZE3__128    6
#define    FERMI64_SIZE3__BV     7 // ?
#define FERMI64_SYNC       4: 4
// fine FERMI_NARROW       3: 3  // 32-bit instruction, 64-bit instruction
// fine FERMI_BOT3         2: 0  // 3 for LD_N and ST_N



#define IS_NARROW(inst) (GET(FERMI_NARROW,inst) == FERMI_NARROW__32B)


#define FERMI64_MASK (MSK(FERMI64_TOP5) + MSK(3:0))
#define FERMI64_MASK2 (MSK(FERMI64_TOP2) + MSK(3:0))
#define FERMI64_MASK6 (MSK(FERMI64_TOP6) + MSK(3:0))
#define FERMI64_MASK8 (MSK(FERMI64_TOP8) + MSK(3:0))
#define FERMI64_INST(top,bot) (FLD(FERMI64_TOP5,top) + FLD(FERMI_BOT3,bot))
#define FERMI64_INST2(top,bot) (FLD(FERMI64_TOP2,top) + FLD(FERMI_BOT3,bot))
#define FERMI64_INST6(top,bot) (FLD(FERMI64_TOP6,top) + FLD(FERMI_BOT3,bot))
#define FERMI64_INST8(top,bot) (FLD(FERMI64_TOP8,top) + FLD(FERMI_BOT3,bot))
#define LD  FERMI64_INST(LD, LDST)
#define LDU FERMI64_INST(LDU,LDST)
#define ST  FERMI64_INST(ST, LDST)
#define INST_LDS FERMI64_INST8(LDS, LDST)
#define INST_LDL FERMI64_INST8(LDL, LDST)
#define INST_STS FERMI64_INST8(STS, LDST)
#define INST_STL FERMI64_INST8(STL, LDST)
#define INST_RED FERMI64_INST2(RED, LDST)
#define INST_ATOM FERMI64_INST2(ATOM, LDST)

#define INST_BAR FERMI64_INST6(BAR, INT)
#define INST_VOTE FERMI64_INST6(VOTE, INT)
#define INST_POPC FERMI64_INST6(POPC, INT)
#define INST_FLO FERMI64_INST(FLO, LDST_N)


#define JMP_ABS(target)                                                 \
    (FERMI64_INST(JMP, CTF) +                                           \
     FLDV(FERMI64_ICA,0) +                                              \
     FLD(FERMI64_CC,CC_T) +                                             \
     FLDV(FERMI64_IMM32, target) +                                      \
     FLD(FERMI_PRED,UNCOND))

#define STL128(ra, addr, r)                                             \
    (FLD(FERMI64_TOP8, STL) + FLDV(FERMI64_IMM24, addr) +               \
     FLDV(FERMI_REGA,ra) + FLDV(FERMI_REGB,r) + FLD(FERMI64_SIZE3,128) + \
     FLD(FERMI_PRED,UNCOND) + FLD(FERMI_BOT3,LDST))

#define STL64(ra, addr, r)                                              \
    (FLD(FERMI64_TOP8, STL) + FLDV(FERMI64_IMM24, addr) +               \
     FLDV(FERMI_REGA,ra) + FLDV(FERMI_REGB,r) + FLD(FERMI64_SIZE3,64) + \
     FLD(FERMI_PRED,UNCOND) + FLD(FERMI_BOT3,LDST))

#define STL(ra, addr, r)                                                \
    (FLD(FERMI64_TOP8, STL) + FLDV(FERMI64_IMM24, addr) +               \
     FLDV(FERMI_REGA,ra) + FLDV(FERMI_REGB,r) + FLD(FERMI64_SIZE3,32) + \
     FLD(FERMI_PRED,UNCOND) + FLD(FERMI_BOT3,LDST))

#define GST(ra, addr, r)                                                 \
    (FLD(FERMI64_TOP5, ST) + FLDV(FERMI64_IMM32, addr) +               \
     FLDV(FERMI_REGA,ra) + FLDV(FERMI_REGB,r) + FLD(FERMI64_SIZE3,32) + \
     FLD(FERMI_PRED,UNCOND) + FLD(FERMI_BOT3,LDST))

#define LDL128(r, ra, addr)                                             \
    (FLD(FERMI64_TOP8, LDL) + FLDV(FERMI64_IMM24, addr) +               \
     FLDV(FERMI_REGA,ra) + FLDV(FERMI_REGB,r) + FLD(FERMI64_SIZE3,128) + \
     FLD(FERMI_PRED,UNCOND) + FLD(FERMI_BOT3,LDST))

#define LDL64(r, ra, addr)                                              \
    (FLD(FERMI64_TOP8, LDL) + FLDV(FERMI64_IMM24, addr) +               \
     FLDV(FERMI_REGA,ra) + FLDV(FERMI_REGB,r) + FLD(FERMI64_SIZE3,64) + \
     FLD(FERMI_PRED,UNCOND) + FLD(FERMI_BOT3,LDST))

#define LDL(r, ra, addr)                                                \
    (FLD(FERMI64_TOP8, LDL) + FLDV(FERMI64_IMM24, addr) +               \
     FLDV(FERMI_REGA,ra) + FLDV(FERMI_REGB,r) + FLD(FERMI64_SIZE3,32) + \
     FLD(FERMI_PRED,UNCOND) + FLD(FERMI_BOT3,LDST))

#define LDS_U8(r, ra, addr)                                             \
    (FLD(FERMI64_TOP8, LDS) + FLDV(FERMI64_IMM24, addr) +               \
     FLDV(FERMI_REGA,ra) + FLDV(FERMI_REGB,r) + FLD(FERMI64_SIZE3,U8) + \
     FLD(FERMI_PRED,UNCOND) + FLD(FERMI_BOT3,LDST))

#define GLD(r, ra, addr)                                                \
    (FLD(FERMI64_TOP5, LD) + FLDV(FERMI64_IMM32, addr) +               \
     FLDV(FERMI_REGA,ra) + FLDV(FERMI_REGB,r) + FLD(FERMI64_SIZE3,32) + \
     FLD(FERMI_PRED,UNCOND) + FLD(FERMI_BOT3,LDST))

#define MOV32I(Rd,k)                                                    \
    (FLD(FERMI64_TOP8, MOV32I) + FLDV(FERMI64_IMM32, k) +               \
     FLDV(FERMI_REGB,Rd) + FLD(FERMI_PRED,UNCOND) +                     \
     FLDV(FERMI_QUAD,15) + FLDV(FERMI_BOT3,2))

#define MOV(Rd,Rs)                                                      \
    (0x2800000000001de4ULL + FLDV(FERMI_REGB,Rd) + FLDV(FERMI64_IMM24,Rs))

#define RET          (0x9000000000000007ULL + FLD(FERMI64_CC,CC_T) + FLD(FERMI_PRED,UNCOND))
#define JCAL(target) (0x1000000000000007ULL + FLDV(FERMI64_IMM32, target) + FLDV(FERMI64_INC, 1))

#define IADD32I(Rd, Ra, k)                                               \
    (0x0800000000000002ULL + FLDV(FERMI_REGB,Rd) + FLDV(FERMI_REGA,Ra) +\
     FLDV(FERMI64_IMM32,k) + FLD(FERMI_PRED,UNCOND))

#define IADD32I_CC(Rd, Ra, k) (IADD32I(Rd,Ra,k) + (1ULL<< (63 - 5)))
#define IADD32I_X(Rd, Ra, k) (IADD32I(Rd,Ra,k) + 0x40)

#define IADD32I_CC_NEGATE_RA (2<<7) // XXX Doesn't work :(

#define P2R(d) (0x3000c3fffff01c04ULL + FLDV(FERMI_REGB,d))
#define R2P(s)      (0x3400c3fffc001c04ULL + FLDV(FERMI_REGA,s))
#define R2P_SB(s, m)      (0x3400c3fffc001c04ULL + FLDV(FERMI_REGA,s) + FLDV(FERMI_S24, m) )

#define AND_CC(d, a, b) \
    (0x6801000000001c03ULL + FLDV(FERMI_REGA,a) + FLDV(FERMI_REGB,d) \
     + FLDV(FERMI64_IMM20,b) + FLDV(FERMI64_ABC,0))

#define ISETP_U32_X_AND(cc,Pd,Ra,Rb)                      \
    (0x1800000000001c03ULL                                \
     + FLDV(FERMI_REGA,Ra) + FLDV(FERMI64_IMM20,Rb)       \
     + FLDV(FERMI64_ICOMP3,cc)                            \
     + FLDV(6:6,1)                                        \
     + FLDV(16:14,7) + FLDV(19:17,Pd)                     \
     + FLDV(51:49,7)                                      \
     + FLDV(FERMI64_ABC,0))

#define ISETPI_U32_X_AND(cc,Pd,Ra,k)                      \
    (0x1800000000001c03ULL                                \
     + FLDV(FERMI_REGA,Ra) + FLDV(FERMI64_IMM20,k)        \
     + FLDV(FERMI64_ICOMP3,cc)                            \
     + FLDV(6:6,1)                                        \
     + FLDV(16:14,7) + FLDV(19:17,Pd)                     \
     + FLDV(51:49,7)                                      \
     + FLDV(FERMI64_ABC,3))

#define BRA(offset) (0x4000000000001de7ULL + FLDV(FERMI_S24,offset))
#define PRED(p,i) (((i) & ~MSK(FERMI_PRED)) + FLDV(FERMI_PRED, p))
#define CC(cc,i) (((i) & ~MSK(FERMI64_CC)) + FLDV(FERMI64_CC, cc))

#define SSYI(offset) (0x6000000000000007ULL + FLDV(FERMI_S24,offset))
#define SSY(offset) (0x6000000000001de7ULL + FLDV(FERMI_S24,offset))
#define SYNC(i) (((i) & ~MSK(FERMI64_SYNC)) + FLDV(FERMI64_SYNC, 1))

#define NOP \
    (0x4000000000001de4ULL)

#define NOP_S SYNC(NOP)

#define SETFLDV(o,f,fv) ((o) = ((o) &~ MSK(f)) + FLDV(f, fv))

#define ISET_U32(cc,Rd,Ra,Rb)                        \
    (0x1000000000001c03ULL                                \
     + FLDV(FERMI_REGA,Ra) + FLDV(FERMI64_IMM20,Rb)       \
     + FLDV(FERMI64_ICOMP3,cc)                            \
     + FLDV(6:6,0)                                        \
     + FLDV(FERMI_REGB,Rd)                                \
     + FLDV(51:49,7)                                      \
     + FLDV(FERMI64_ABC,0))

#define ICMP_U32(cc,Rd,Ra,Rb,Sc)                          \
    (0x3000000000001c03ULL                                \
     + FLDV(FERMI_REGA,Ra) + FLDV(FERMI64_IMM20,Rb)       \
     + FLDV(FERMI64_ICOMP3,cc)                            \
     + FLDV(6:6,0)                                        \
     + FLDV(FERMI_REGB,Rd)                                \
     + FLDV(54:49,Sc)                                     \
     + FLDV(FERMI64_ABC,0))

#define ISETP_U32_AND(cc,Pd,Ra,Rb)                        \
    (0x1800000000001c03ULL                                \
     + FLDV(FERMI_REGA,Ra) + FLDV(FERMI64_IMM20,Rb)       \
     + FLDV(FERMI64_ICOMP3,cc)                            \
     + FLDV(6:6,0)                                        \
     + FLDV(19:17,Pd) + FLDV(16:14,7) +                   \
     + FLDV(51:49,7)                                      \
     + FLDV(FERMI64_ABC,0))

// ISETP.EQ.U32.AND Pu, Pv, Ra, Rb, Pb  (Pv is A.K.A. ~P dest, Pb includes polarity)
#define ISETP_U32_FULL(cc, Pu, Pv, Ra, Rb, Pb)            \
    (0x1800000000001c03ULL                                \
     + FLDV(FERMI_REGA,Ra) + FLDV(FERMI64_IMM20,Rb)       \
     + FLDV(FERMI64_ICOMP3,cc)                            \
     + FLDV(6:6,0)                                        \
     + FLDV(19:17,Pu) + FLDV(16:14,Pv) +                  \
     + FLDV(52:49,Pb)                                     \
     + FLDV(FERMI64_ABC,0))

#define PSETP_FULL(bop0, bop1, Pu, Pv, Pp, Pq, Pr)        \
    (0xc00000000000004ULL                                 \
     + FLDV(FERMI64_BOP0,bop0)                            \
     + FLDV(FERMI64_BOP1,bop1)                            \
     + FLDV(23:20,Pr)                                     \
     + FLDV(29:26,Pq)                                     \
     + FLDV(52:49,Pp)                                     \
     + FLDV(19:17,Pu)                                     \
     + FLDV(16:14,Pv)                                     \
     + FLD(FERMI_PRED,UNCOND))


// logical 32-bit shift right
#define SHRI_U32(Rd, Ra, k)                               \
    (0x5800000000000003ULL                                \
     + FLDV(FERMI_REGB,Rd)                                \
     + FLDV(FERMI_REGA,Ra)                                \
     + FLDV(FERMI64_IMM20,k)                              \
     + FLDV(FERMI64_ABC,3)                                \
     + FLD(FERMI_PRED,UNCOND))

#define SHR_U32(Rd, Ra, Rb)                               \
    (0x5800000000000003ULL                                \
     + FLDV(FERMI_REGB,Rd)                                \
     + FLDV(FERMI_REGA,Ra)                                \
     + FLDV(FERMI_SBR,Rb)                                 \
     + FLDV(FERMI64_ABC,0)                                \
     + FLD(FERMI_PRED,UNCOND))

#define SHRI_U32_CC(Rd, Ra, k)                            \
    (SHRI_U32(Rd,Ra,k)                                    \
     + FLDV(48:48, 0x1))

#define SHRI_U32_CC_X(Rd, Ra, k)                          \
    (SHRI_U32_CC(Rd, Ra, k)                               \
     + FLDV(7:6, 0x2))

// logical 32-bit shift left
#define SHLI_U32(Rd, Ra, k)                               \
    (0x6000000000000003ULL                                \
     + FLDV(FERMI_REGB,Rd)                                \
     + FLDV(FERMI_REGA,Ra)                                \
     + FLDV(FERMI64_IMM20,k)                              \
     + FLDV(FERMI64_ABC,3)                                \
     + FLD(FERMI_PRED,UNCOND))

#define SHL_U32(Rd, Ra, Rb)                               \
    (0x6000000000000003ULL                                \
     + FLDV(FERMI_REGB,Rd)                                \
     + FLDV(FERMI_REGA,Ra)                                \
     + FLDV(FERMI_SBR,Rb)                                 \
     + FLDV(FERMI64_ABC,0)                                \
     + FLD(FERMI_PRED,UNCOND))

#define SHLI_U32_CC(Rd, Ra, k)                            \
    (SHLI_U32(Rd, Ra, k)                                  \
     + FLDV(48:48, 0x1))

#define SHLI_U32_CC_X(Rd, Ra, k)                          \
    (SHLI_U32_CC(Rd, Ra, k)                               \
     + FLDV(6:6, 0x1))

#define LOP32I(op, Rd, Ra, k)                             \
    (0x3800000000000002ULL                                \
     + FLDV(FERMI_LOP,op)                                 \
     + FLDV(FERMI_REGB,Rd)                                \
     + FLDV(FERMI_REGA,Ra)                                \
     + FLDV(FERMI64_IMM32,k)                              \
     + FLD(FERMI_PRED,UNCOND))

#define AND32I(Rd, Ra, k)                                 \
     (LOP32I(FERMI_LOP_AND, Rd, Ra, k))

#define OR32I(Rd, Ra, k)                                 \
     (LOP32I(FERMI_LOP_OR, Rd, Ra, k))

#define BFEI_U32(Rd, Ra, bits)                            \
    (0x7000000000000003ULL                                \
     + FLDV(FERMI_REGB,Rd)                                \
     + FLDV(FERMI_REGA,Ra)                                \
     + FLDV(FERMI64_IMM20,(((BF_HI(bits)-BF_LO(bits)+1)<<8) | (BF_LO(bits)))) \
     + FLDV(FERMI64_ABC,3)                                \
     + FLD(FERMI_PRED,UNCOND))

#define LOP32(op, Rd, Ra, Rb)                             \
    (0x6800000000000003ULL                                \
     + FLDV(FERMI_LOP, op)                                \
     + FLDV(FERMI_REGB,Rd)                                \
     + FLDV(FERMI_REGA,Ra)                                \
     + FLDV(FERMI_SBR, Rb)                                \
     + FLD(FERMI_PRED, UNCOND))

#define OR32(Rd, Ra, Rb)                                  \
    (LOP32(FERMI_LOP_OR, Rd, Ra, Rb))

#define IADD_U(Rd, Ra, Rb)                                \
    (0x4800000000000003ULL                                \
     + FLDV(FERMI_REGB,Rd)                                \
     + FLDV(FERMI_REGA,Ra)                                \
     + FLDV(FERMI_SBR, Rb)                                \
     + FLD(FERMI_PRED,UNCOND))

#define IADD_U_CC(Rd, Ra, Rb)                             \
    (IADD_U(Rd, Ra, Rb)                                   \
     + FLDV(48:48, 0x1)) // set condition codes

#define IADD_U_X(Rd, Ra, Rb)                              \
    (IADD_U(Rd, Ra, Rb)                                   \
     + FLDV(6:6, 0x1))  // use carry bit

// Rd = Ra - Rb
#define ISUB_U(Rd, Ra, Rb)                                \
    (IADD_U(Rd,Ra,Rb)                                     \
     + FLDV(9:8, 1))

#define ISUB_U_CC(Rd, Ra, Rb)                             \
    (IADD_U_CC(Rd,Ra,Rb)                                  \
     + FLDV(9:8, 1))

#define ISUB_U_X(Rd, Ra, Rb)                              \
    (IADD_U_X(Rd,Ra,Rb)                                   \
     + FLDV(9:8, 1))

#define IMUL32I_U_LO(Rd, Ra, k)                           \
    (0x1000000000000002ULL                                \
     + FLDV(FERMI_REGB,Rd)                                \
     + FLDV(FERMI_REGA,Ra)                                \
     + FLDV(FERMI64_IMM32,k)                              \
     + FLD(FERMI_PRED,UNCOND))

#define IMUL32I_U_HI(Rd, Ra, k)                           \
    (IMUL32I_U_LO(Rd, Ra, k)                              \
     + FLDV(6:6, 0x1))  // extended

#define IMUL_U_LO(Rd, Ra, Rb)                             \
    (0x5000000000000003ULL                                \
     + FLDV(FERMI_REGB,Rd)                                \
     + FLDV(FERMI_REGA,Ra)                                \
     + FLDV(FERMI_SBR, Rb)                                \
     + FLD(FERMI_PRED,UNCOND))

#define IMUL_U_HI(Rd, Ra, Rb)                             \
    (IMUL_U_LO(Rd, Ra, Rb)                                \
     + FLDV(6:6, 0x1))  // extended

#define ATOM_E_OR_U32(Rd,Ra,offset,Rb)                    \
    (0x5400000000001c05ULL                                \
     + FLDV(8:5,6) /* pure guess */                       \
     + FLDV(FERMI_REGB,Rb)                                \
     + FLDV(FERMI_REGA,Ra)                                \
     + FLDV(FERMI64_IMM16,offset)                         \
     + FLDV(48:43,Rd)                                     \
     + FLDV(54:49,RZ))

#define ATOM_E_ADD_U32(Rd,Ra,offset,Rb)                    \
    (0x5400000000001c05ULL                                \
     + FLDV(8:5,0) /* pure guess */                       \
     + FLDV(FERMI_REGB,Rb)                                \
     + FLDV(FERMI_REGA,Ra)                                \
     + FLDV(FERMI64_IMM16,offset)                         \
     + FLDV(48:43,Rd)                                     \
     + FLDV(54:49,RZ))

#define S2R(Rd,Sr)                                        \
    (0x2C00000000001c04ULL                                \
     + FLDV(FERMI_REGB,Rd)                                \
     + FLDV(33:26,Sr))


#define ST_E(Ra,offset,Rb,sz)                             \
    (0x9400000000001c05ULL                                \
     + FLD(FERMI64_SIZE3,sz)                              \
     + FLDV(FERMI_REGB,Rb)                                \
     + FLDV(FERMI_REGA,Ra)                                \
     + FLDV(FERMI64_IMM32,offset))

/* Causes a race condition. Do not use. (Bug 712753) */
#define ST_E128(Ra,offset,Rb)                             \
    (ST_E(Ra,offset,Rb,128))

/* Causes a race condition. Do not use. (Bug 712753) */
#define ST_E64(Ra,offset,Rb)                              \
    (ST_E(Ra,offset,Rb,64))

#define ST_E32(Ra,offset,Rb)                              \
    (ST_E(Ra,offset,Rb,32))

#define ST_EU8(Ra,offset,Rb)                              \
    (ST_E(Ra,offset,Rb,U8))

#define ST_E32_WT(Ra,offset,Rb)                              \
    (0x9400000000001c05ULL                                \
     + FLD(FERMI64_SIZE3,32)                              \
     + FLDV(FERMI_REGB,Rb)                                \
     + FLDV(FERMI_REGA,Ra)                                \
     + FLD(FERMI64_COP2,WT)                                \
     + FLDV(FERMI64_IMM32,offset))

#define LD_E(Rd,Ra,offset,sz)                             \
    (0x8400000000000005ULL                                \
     + FLD(FERMI64_SIZE3,sz)                              \
     + FLDV(FERMI_REGB,Rd)                                \
     + FLDV(FERMI_REGA,Ra)                                \
     + FLDV(FERMI64_IMM32,offset)                         \
     + FLD(FERMI_PRED,UNCOND))

#define LD_E128(Rd,Ra,offset)                             \
    (LD_E(Rd,Ra,offset,128))

#define LD_E64(Rd,Ra,offset)                              \
    (LD_E(Rd,Ra,offset,64))

#define LD_E32(Rd,Ra,offset)                              \
    (LD_E(Rd,Ra,offset,32))

#define LD_E8(Rd,Ra,offset)                               \
    (LD_E(Rd,Ra,offset,U8))

#define LD_E32_CV(Rd,Ra,offset)                           \
    (0x8400000000000005ULL                                \
     + FLD(FERMI64_SIZE3,32)                              \
     + FLDV(FERMI_REGB,Rd)                                \
     + FLDV(FERMI_REGA,Ra)                                \
     + FLDV(FERMI64_IMM32,offset)                         \
     + FLD(FERMI64_COP2,WT)                              \
     + FLD(FERMI_PRED,UNCOND))

#define LDC(Rd,C,IDX,SZ)                                  \
    (0x1400000000000006ULL                                \
     + FLD(FERMI64_SIZE3,SZ)                              \
     + FLDV(41:26,IDX)                                    \
     + FLDV(46:42,C)                                      \
     + FLDV(FERMI_REGB,Rd)                                \
     + FLDV(FERMI_REGA,RZ)                                \
     + FLD(FERMI_PRED,UNCOND))

#define LDC_32(Rd,C,IDX)                                  \
    (LDC(Rd,C,IDX,32))

#define LDC_64(Rd,C,IDX)                                  \
    (LDC(Rd,C,IDX,64))

#define TLD(Rd, Ra, tid, sampler)                         \
    (0x9000000000000086ULL                                \
     + FLD(FERMI_PRED,UNCOND)                             \
     + FLDV(FERMI_WRITEMASK,0x1)                          \
     + FLDV(FERMI_TEX_REGB,0x3f)                          \
     + FLDV(FERMI_TEX_DIM,0/*1D*/)                        \
     + FLDV(FERMI_TEX_ID,tid)                             \
     + FLDV(FERMI_SAMPLER,sampler)                        \
     + FLDV(FERMI_REGA,Ra)                                \
     + FLDV(FERMI_TEX_REGD,Rd))

#define TEX(Rd, Ra, tid, sampler)                         \
    (0x8000000000000086ULL                                \
     + FLD(FERMI_PRED,UNCOND)                             \
     + FLDV(FERMI_WRITEMASK,0xf)                          \
     + FLDV(FERMI_TEX_REGB,0x3f)                          \
     + FLDV(FERMI_TEX_DIM,0/*1D*/)                        \
     + FLDV(FERMI_TEX_ID,tid)                             \
     + FLDV(FERMI_SAMPLER,sampler)                        \
     + FLDV(FERMI_REGA,Ra)                                \
     + FLDV(FERMI_TEX_REGD,Rd))

#define IS_TLD(instr)                                     \
    (((instr) & 0xf000000000000007ULL) == 0x9000000000000006ULL)

#define IS_TEX(instr)                                     \
    (((instr) & 0xf000000000000007ULL) == 0x8000000000000006ULL)

#define VOTE_ALL(rd, p0)                                    \
    (INST_VOTE +                                            \
     + FLDV(FERMI64_VOTE_MODE,0)                            \
     + FLDV(FERMI64_VOTE_PDST, 7)                           \
     + FLDV(FERMI64_VOTE_PSRC, p0)                          \
     + FLDV(FERMI_REGB, rd)                                 \
     + FLD(FERMI_PRED, UNCOND))

#define POPC_ALL(rd, ra)                                    \
    (INST_POPC                                              \
     + FLDV(FERMI_REGB,rd)                                  \
     + FLDV(FERMI_REGA,ra)                                  \
     + FLDV(FERMI64_ABC, 0)                                 \
     + FLDV(FERMI_SBR, ra)                                  \
     + FLD(FERMI_PRED, UNCOND))

#define FLO_LS(rd, ra)                                      \
    (INST_FLO                                               \
     + FLDV(FERMI_REGB, rd)                                 \
     + FLDV(FERMI_SBR, ra)                                  \
     + FLD(FERMI_PRED, UNCOND))

#define BAR_SYNC_ALL 0x50ee0000ffffdc04ULL

#define BREAKPT64 \
    (0xD000000000001c07ULL                                \
     + FLDV(FERMI_REGB,3/*TRAP*/))

#define BREAKPT_N 0x8000007F

// Special case
#define BFE_11F(Rd,Ra)                          \
    (0x7000c0047c001c23                         \
     + FLDV(FERMI_REGA,Ra)                      \
     + FLDV(FERMI_REGB,Rd))

// There isn't a dedicated NOP_N instruction so I use MOVI_N $63, 0
//                imm:12 dest:6 pred:4 I/F:1 2:2 1:3 1:1 0:3
//                0:12 111111 0111 0 10 001 1 000
//                0:12 1111 1101 1101 0001 1000
#define NOP_N 0x000FDD18

// 10 010 ?:13 pred:4 ccc:5 1111
// 10 010 0000000000000 0111  00000 11111
// 1001 0000 0000 0000 0001 1100 0001 1111
#define EXIT_N 0x90001C1F // ??? wrong?

// 10 000 ... 0111 01111 00 111
// 10 000 ... 01 1101 1110 0111
#define EXIT 0x8000000000001DE7ULL

#define MEMBAR_SYS 0xe000000000001c45ULL

#define INST_CCTL_IVALL   0x9800000003ffdcc5ULL
#define INST_CCTLL_IVALL  0xd000000003ffdcc5ULL


#define PAIR(narrow1,narrow2) ((narrow1) + ((uint64_t) (narrow2) << 32))

#define BPT_DRAIN 0xd000000000000007ULL

#define LONGJMP           0x8800000000001DE7ULL

// To make the code easier to read
enum fermi_reg {R0, R1, R2, R3, R4, R5, R6, R7,
                R8, R9, R10, R11, R12, R13, R14, R15, RZ = 63
               };
/* NEG_PRED+P3 means @!P3, etc */
enum fermi_pred {P0, P1, P2, P3, P4, P5, P6, P7,
                 NOT_P0, NOT_P1, NOT_P2, NOT_P3, NOT_P4, NOT_P5, NOT_P6, NOT_P7,
                 PT = P7
                };

/* Toggle the NOT bit of the predicate, p. */
#define NOT_P(p) (p ^ (1 << 3))

enum fermi_cc {
    CC_F,       CC_LT,      CC_EQ,      CC_LE,      CC_GT,      CC_NE,      CC_GE,  CC_NUM,
    CC_NAN,     CC_LTU,     CC_EQU,     CC_LEU,     CC_GTU,     CC_NEU,     CC_GEU, CC_T,
    CC_OFF,     CC_LO,      CC_SFF,     CC_LS,      CC_HI,      CC_SFT,     CC_HS,  CC_OFT,
    CC_CSMA_TA, CC_CSMA_TR, CC_CSMA_MX, CC_FCSM_TA, CC_FCSM_TR, CC_FCSM_MX, CC_RLE, CC_RGT
};

#endif

