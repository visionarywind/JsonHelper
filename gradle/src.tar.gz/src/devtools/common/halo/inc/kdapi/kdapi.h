/*
* Copyright 2018-2019 NVIDIA Corporation.  All rights reserved.
*
* NOTICE TO USER:
*
* This source code is subject to NVIDIA ownership rights under U.S. and
* international Copyright laws.  Users and possessors of this source code
* are hereby granted a nonexclusive, royalty-free license to use this code
* in individual and commercial software.
*
* NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
* CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
* IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
* REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
* OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
* OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
* OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
* OR PERFORMANCE OF THIS SOURCE CODE.
*
* U.S. Government End Users.   This source code is a "commercial item" as
* that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
* "commercial computer  software"  and "commercial computer software
* documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
* and is provided to the U.S. Government only as a commercial end item.
* Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
* 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
* source code with only those rights set forth herein.
*
* Any use of this source code in individual and commercial software must
* include, in the user documentation and internal comments to the code,
* the above Disclaimer and U.S. Government End Users Notice.
*/

/******************************************************************************
*
*   Module: kdapi.h
*
*   Description:
*      Defines for Kernel-mode Debug API functions.
*
******************************************************************************/

#ifndef KDAPI_H
#define KDAPI_H

#include "nvtypes.h"
#include "cudadebugger.h"

#include "cuda_platform.h"
#include "cuda_types.h"

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

// These constants MUST match the minimum numbers supported by all platforms
// See individual <platform>_kdapi.c files for compile-time asserts for this constraint
// Currently set to match KMD Debug API limits (WDDM)
#define KDAPI_MAX_REG_OPS 100
#define KDAPI_MAX_MEMORY_OPS 64

typedef enum {
    KDAPI_TYPES_FIRST = 0,
    KDAPI_TYPE_WDDM = 0,
    KDAPI_TYPE_RM = 1,
    KDAPI_TYPE_MRM = 2,
    KDAPI_TYPES_COUNT,
} KdApiType_t;

typedef union {
    struct {
        NvU64 handle;
    } wddm;
    struct {
        NvU32 handle;
        NvU32 client;
    } rm;
    struct {
        int handle;
    } mrm;
} KdDebugObject;

typedef union {
    struct {
        CUd3dKmtHandle hAdapter;
    } wddm;
    struct {
        NvU32 subDeviceIndex;
    } rm;
} KdDeviceHandle;

struct KdContext_st {
    KdDebugObject debugObject;
    KdDeviceHandle deviceHandle;
};
typedef struct KdContext_st *KdContext;

typedef struct {
    union {
        struct {
            void *handle;
        } windows;
        struct {
            int fd;
        } nix;
    };
} KdOsEventHandle;

typedef struct {
    NvU8    regOp;
    NvU8    regType;
    NvU8    regStatus;
    NvU8    regQuad;
    NvU32   regGroupMask;
    NvU32   regSubGroupMask;
    NvU32   regOffset;
    NvU32   regValueHi;
    NvU32   regValueLo;
    NvU32   regAndNMaskHi;
    NvU32   regAndNMaskLo;
} KdRegOp; // Copied from NV2080_CTRL_GPU_REG_OP

typedef struct {
    NvU64 gpuVA;
    NvP64 buffer;
    NvU32 sizeInBytes;
} KdMemoryOp;

typedef enum {
    KDAPI_MMU_DEBUG_MODE_ENABLE,
    KDAPI_MMU_DEBUG_MODE_DISABLE,
    KDAPI_MMU_DEBUG_MODE_RELEASE_REQUESTS,
} KdSetMmuDebugModeAction;

typedef struct {
    NvU32   hwwGlobalEsr;
    NvU32   hwwWarpEsr;
    NvU32   hwwWarpEsrPc;
    NvU32   hwwGlobalEsrReportMask;
    NvU32   hwwWarpEsrReportMask;
    NvU64   NV_DECLARE_ALIGNED(hwwEsrAddr, 8);
    NvU64   NV_DECLARE_ALIGNED(hwwWarpEsrPc64, 8);
} KdErrorState; // Copied from NV83DE_SM_ERROR_STATE_REGISTERS

typedef struct {
    uint64_t startVA;
    uint64_t endVA;
} KdVARangeInfo;

struct KdApi_st {
    // Target-side functions (only callable in-process)
    CUDBGResult (*allocDebugObject)     (const CUctx *ctx, /* out */ KdDebugObject *debugObject);
    CUDBGResult (*freeDebugObject)      (const CUctx *ctx, KdDebugObject debugObject);

    // Global functions (not requiring a debug object)
    CUDBGResult (*getApiVersion)        (KdDeviceHandle deviceHandle, /* out */ NvU32 *major, /* out */ NvU32 *minor);

    // Debug object functions
    CUDBGResult (*registerDebugEvent)   (KdContext ctx, KdOsEventHandle hOsEvent);
    CUDBGResult (*unregisterDebugEvent) (KdContext ctx);
    CUDBGResult (*clearDebugEvent)      (KdContext ctx);
    CUDBGResult (*suspendContext)       (KdContext ctx, /* out */ NvBool *shouldWait);
    CUDBGResult (*resumeContext)        (KdContext ctx);
    CUDBGResult (*execRegOps)           (KdContext ctx, NvBool nonTransactional, /* in/out */ KdRegOp *script, NvU32 numOps);
    CUDBGResult (*accessMemory)         (KdContext ctx, NvBool read, const KdMemoryOp *memoryOps, NvU32 numOps);
    CUDBGResult (*setMmuDebugMode)      (KdContext ctx, KdSetMmuDebugModeAction action);
    CUDBGResult (*setSingleStepMode)    (KdContext ctx, NvBool enable);
    CUDBGResult (*readErrorState)       (KdContext ctx, NvU32 vsm, /* out */ KdErrorState *errorState);
    CUDBGResult (*readErrorStates)      (KdContext ctx, NvU32 numSMsToRead, /* out */ NvU32 *mmuFaultInfo, /* out */ NvBool *valid, /* out */ KdErrorState *errorStateArray);
    CUDBGResult (*getVARanges)          (KdContext ctx, NvU64 startVA, NvU64 endVA, /* out */ KdVARangeInfo *ranges, NvU32 length, /* out */ NvU32 *numRanges);
};
typedef struct KdApi_st *KdApi;

extern KdApi globalKdApi[KDAPI_TYPES_COUNT];

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // KDAPI_H
