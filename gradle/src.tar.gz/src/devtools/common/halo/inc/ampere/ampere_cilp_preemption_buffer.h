/*
 * Copyright 2016-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef __AMPERE_CILP_PREEMPTION_BUFFER_H__
#define __AMPERE_CILP_PREEMPTION_BUFFER_H__

//#include "nvctassert.h"
#include "cui/hal/ampere/ampere_arch_consts.h"
// For offset checks
#include "asm/arch_include/sm_82/cilp_buffer_offsets.h"

// From //hw/class/ampere/include/traphandler/cilp_buffer.h
// with type names prefixed with CU.
// TODO: Update me with drivers/gpgpu/cuda/src/asm/arch_include/sm_82/cilp_buffer.h

// NOTE: all structures are currently padded to 8B

// From //hw/class/ampere/include/trap_handler/sm_arch_defs.h
// TODO: Update me with constant from ampere_arch_consts.h
#define CUDBG_MAX_CBU_BARRIERS_AMPERE 16

#pragma pack(push,1)

typedef struct CUampereWarpCILPBuffer_st {
    uint64_t CBU_RPC[CUDBG_MAX_LANE_AMPERE];
    uint32_t CBU_BAR[CUDBG_MAX_CBU_BARRIERS_AMPERE];
    uint64_t CBU_TRAP_RETURN_PC;
    uint64_t CBU_ATEXITPC;
    uint32_t CBU_unused; // used to be occupied by MKILL
    uint32_t CBU_TRAP_RETURN_MASK; // same as MACTIVE
    uint32_t CBU_MEXITED;
    uint32_t CBU_MATEXIT;
    uint32_t CBU_API_CALL_DEPTH;
    uint32_t CBU_OPT_STACK;
    uint32_t CBU_THREAD_STATE_ENUM_0;
    uint32_t CBU_THREAD_STATE_ENUM_1;
    uint32_t CBU_THREAD_STATE_ENUM_2;
    uint32_t CBU_THREAD_STATE_ENUM_3;
    uint32_t CBU_THREAD_STATE_ENUM_4;
    uint32_t UPR;
    uint32_t UReg[CU_AMPERE_ARCH_CONST_HW_SM_WARP_NUM_UNIFORM_REGS];
    uint32_t TTU_ticket_info;
    uint32_t TTU_mask;
    uint64_t LMEMBASE;
    uint32_t BARState;
    uint32_t RFDataIdx; // Offset into RFData, SR_regAlloc tells us how many
    uint8_t PR[CUDBG_MAX_LANE_AMPERE];
    uint32_t reservedPad1[2];
} CUampereWarpCILPBuffer;

typedef struct CUampereCTACILPBuffer_st {
    uint64_t CTAID;
    uint32_t shmemDataIdx; // Offset into shmemData, SR_SMemSz tells us how much
    uint32_t reservedPad1;
    uint32_t BARState[CU_AMPERE_ARCH_CONST_HW_SM_MAX_BARRIERS_PER_CTA];
} CUampereCTACILPBuffer;

typedef struct CUampereSMCILPBuffer_st {
    uint32_t RFDataIdxSync; // used to calculate RFDataIdx values, by one thread per warp
    uint32_t shmemDataIdxSync; // used to calculate shmemDataIdx values, by one thread per CTA
    uint32_t validPendingState[CU_AMPERE_ARCH_CONST_HW_SM_MAX_WARPS_PER_SM_BITFIELD]; // one bit per warp to indicate that lmem-hi has valid state about pending events
    uint32_t reservedPad1[5];
    uint32_t RFData[CU_AMPERE_ARCH_CONST_HW_SM_RF_SIZE_WORDS]; // IMPORTANT: This needs to be 128b aligned!!!
    uint32_t shmemData[CU_AMPERE_ARCH_CONST_HW_SM_MAX_SHARED_MEMORY_PER_SM_WORDS];
    CUampereWarpCILPBuffer warpData[CU_AMPERE_ARCH_CONST_HW_SM_MAX_WARPS_PER_SM]; // Mismatch from CUDBG_MAX_WARP_VOLTA
    CUampereCTACILPBuffer CTAData[CU_AMPERE_ARCH_CONST_HW_SM_MAX_CTAS_PER_SM];
} CUampereSMCILPBuffer;
#pragma pack(pop)

// Checks for per warp data offsets
ct_assert(offsetof(CUampereWarpCILPBuffer, CBU_RPC) == offset_AmpereWarpCILPBuffer_t_CBU_RPC);
ct_assert(offsetof(CUampereWarpCILPBuffer, CBU_BAR) == offset_AmpereWarpCILPBuffer_t_CBU_BAR);
ct_assert(offsetof(CUampereWarpCILPBuffer, CBU_TRAP_RETURN_PC) == offset_AmpereWarpCILPBuffer_t_CBU_TRAP_RETURN_PC);
ct_assert(offsetof(CUampereWarpCILPBuffer, CBU_ATEXITPC) == offset_AmpereWarpCILPBuffer_t_CBU_ATEXITPC);
ct_assert(offsetof(CUampereWarpCILPBuffer, CBU_unused) == offset_AmpereWarpCILPBuffer_t_CBU_unused);
ct_assert(offsetof(CUampereWarpCILPBuffer, CBU_TRAP_RETURN_MASK) == offset_AmpereWarpCILPBuffer_t_CBU_TRAP_RETURN_MASK);
ct_assert(offsetof(CUampereWarpCILPBuffer, CBU_MEXITED) == offset_AmpereWarpCILPBuffer_t_CBU_MEXITED);
ct_assert(offsetof(CUampereWarpCILPBuffer, CBU_MATEXIT) == offset_AmpereWarpCILPBuffer_t_CBU_MATEXIT);
ct_assert(offsetof(CUampereWarpCILPBuffer, CBU_API_CALL_DEPTH) == offset_AmpereWarpCILPBuffer_t_CBU_API_CALL_DEPTH);
ct_assert(offsetof(CUampereWarpCILPBuffer, CBU_OPT_STACK) == offset_AmpereWarpCILPBuffer_t_CBU_OPT_STACK);
ct_assert(offsetof(CUampereWarpCILPBuffer, CBU_THREAD_STATE_ENUM_0) == offset_AmpereWarpCILPBuffer_t_CBU_THREAD_STATE_ENUM_0);
ct_assert(offsetof(CUampereWarpCILPBuffer, CBU_THREAD_STATE_ENUM_1) == offset_AmpereWarpCILPBuffer_t_CBU_THREAD_STATE_ENUM_1);
ct_assert(offsetof(CUampereWarpCILPBuffer, CBU_THREAD_STATE_ENUM_2) == offset_AmpereWarpCILPBuffer_t_CBU_THREAD_STATE_ENUM_2);
ct_assert(offsetof(CUampereWarpCILPBuffer, CBU_THREAD_STATE_ENUM_3) == offset_AmpereWarpCILPBuffer_t_CBU_THREAD_STATE_ENUM_3);
ct_assert(offsetof(CUampereWarpCILPBuffer, CBU_THREAD_STATE_ENUM_4) == offset_AmpereWarpCILPBuffer_t_CBU_THREAD_STATE_ENUM_4);
ct_assert(offsetof(CUampereWarpCILPBuffer, UPR) == offset_AmpereWarpCILPBuffer_t_UPR);
ct_assert(offsetof(CUampereWarpCILPBuffer, UReg) == offset_AmpereWarpCILPBuffer_t_UReg);
ct_assert(offsetof(CUampereWarpCILPBuffer, TTU_ticket_info) == offset_AmpereWarpCILPBuffer_t_TTU_ticket_info);
ct_assert(offsetof(CUampereWarpCILPBuffer, TTU_mask) == offset_AmpereWarpCILPBuffer_t_TTU_mask);
ct_assert(offsetof(CUampereWarpCILPBuffer, LMEMBASE) == offset_AmpereWarpCILPBuffer_t_LMEMBASE);
ct_assert(offsetof(CUampereWarpCILPBuffer, BARState) == offset_AmpereWarpCILPBuffer_t_BARState);
ct_assert(offsetof(CUampereWarpCILPBuffer, RFDataIdx) == offset_AmpereWarpCILPBuffer_t_RFDataIdx);
ct_assert(offsetof(CUampereWarpCILPBuffer, PR) == offset_AmpereWarpCILPBuffer_t_PR);
ct_assert(offsetof(CUampereWarpCILPBuffer, reservedPad1) == offset_AmpereWarpCILPBuffer_t_reservedPad1);
ct_assert(sizeof(CUampereWarpCILPBuffer) == sizeof_AmpereWarpCILPBuffer_t);

// Check per CTA data offsets
ct_assert(offsetof(CUampereCTACILPBuffer, CTAID) == offset_AmpereCTACILPBuffer_t_CTAID);
ct_assert(offsetof(CUampereCTACILPBuffer, shmemDataIdx) == offset_AmpereCTACILPBuffer_t_shmemDataIdx);
ct_assert(offsetof(CUampereCTACILPBuffer, reservedPad1) == offset_AmpereCTACILPBuffer_t_reservedPad1);
ct_assert(offsetof(CUampereCTACILPBuffer, BARState) == offset_AmpereCTACILPBuffer_t_BARState);
ct_assert(sizeof(CUampereCTACILPBuffer) == sizeof_AmpereCTACILPBuffer_t);

// Check per SM data offsets
ct_assert(offsetof(CUampereSMCILPBuffer, RFDataIdxSync) == offset_AmpereSMCILPBuffer_t_RFDataIdxSync);
ct_assert(offsetof(CUampereSMCILPBuffer, shmemDataIdxSync) == offset_AmpereSMCILPBuffer_t_shmemDataIdxSync);
ct_assert(offsetof(CUampereSMCILPBuffer, validPendingState) == offset_AmpereSMCILPBuffer_t_validPendingState);
ct_assert(offsetof(CUampereSMCILPBuffer, reservedPad1) == offset_AmpereSMCILPBuffer_t_reservedPad1);
ct_assert(offsetof(CUampereSMCILPBuffer, RFData) == offset_AmpereSMCILPBuffer_t_RFData);
ct_assert(offsetof(CUampereSMCILPBuffer, shmemData) == offset_AmpereSMCILPBuffer_t_shmemData);
ct_assert(offsetof(CUampereSMCILPBuffer, warpData) == offset_AmpereSMCILPBuffer_t_warpData);
ct_assert(offsetof(CUampereSMCILPBuffer, CTAData) == offset_AmpereSMCILPBuffer_t_CTAData);
ct_assert(sizeof(CUampereSMCILPBuffer) == sizeof_AmpereSMCILPBuffer_t);

#endif // __AMPERE_CILP_PREEMPTION_BUFFER_H__
