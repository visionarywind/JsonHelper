/*
 * Copyright 2016-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: turing.h
 *
 *   Description:
 *       Debugger access functions that are different for the Turing family.
 *
 ******************************************************************************/

#ifndef _HALO_TURING_H
#define _HALO_TURING_H

#include <halo.h>
#include <turing_scratchpad.h>
#include <turing_tu10x.h>
#include <turing_cilp_preemption_buffer.h>

#define TURING_TU10X_TRAP_IMMEDIATE_BREAKPOINT (0x1)
#define TURING_TU10X_TRAP_IMMEDIATE_UNMASKABLE (0x7)

/* Turing system stack pointer range
   From cui/hal/turing/turing.h
   This is given as CU_TURING_LMEM_RESERVE_SIZE
   This works out to  - 512 - 64 =
   */
#define TURING_SYSTEM_STACK_POINTER     (0xfffdc0ULL)

/* Turing system stack pointer save address
   From cui/hal/turing/turing.h
   This is given as CU_TURING_LMEM_TOTAL_SIZE           -
                    CU_TURING_LMEM_DEBUGGER_SIZE        -
                    CU_TURING_LMEM_THREAD_STATE_SIZE    +
                    offsetof(CUturingThreadState, savedUserStackPointer)
   This works out to 0x1000000 - 512 - 64 + 4 = 0xfffdc4
*/
#define TURING_LMEM_SAVED_STACK_POINTER (TURING_SYSTEM_STACK_POINTER + 4)

/* Turing system return pc save address
   From cui/hal/turing/turing.h
   This is given as CU_TURING_LMEM_TOTAL_SIZE           -
                    CU_TURING_LMEM_DEBUGGER_SIZE        -
                    CU_TURING_LMEM_THREAD_STATE_SIZE    +
                    offsetof(CUturingThreadState, savedTrampolineReturnVA)
   This works out to 0x1000000 - 512 - 64 + 8 = 0xfffdc8
*/
#define TURING_LMEM_SAVED_RETURN_PC     (TURING_SYSTEM_STACK_POINTER + 8)

/* For Turing convergent syscalls, MACTIVE and MEXITED are saved off in the
   system stack.  Read them from there.
*/
/* Enabled as Bug 1931917 is submitted */
#define TURING_CONVERGENT_SYSCALLS (1)

/* Turing MEXITED mask save address
   From asm/turing_tu10x.h
   This is given as CU_TURING_LMEM_TOTAL_SIZE           -
                    CU_TURING_LMEM_DEBUGGER_SIZE        -
                    CU_TURING_LMEM_THREAD_STATE_SIZE    +
                    offsetof(CUturingThreadState, actExclHdl_activeThreads)
   This works out to 0x1000000 - 512 - 64 + 0x18 = 0xfffdd8
*/
#define TURING_LMEM_SAVED_MACTIVE       (TURING_SYSTEM_STACK_POINTER + 0x18)

/* Turing MEXITED mask save address
   From asm/turing_tu10x.h
   This is given as CU_TURING_LMEM_TOTAL_SIZE           -
                    CU_TURING_LMEM_DEBUGGER_SIZE        -
                    CU_TURING_LMEM_THREAD_STATE_SIZE    +
                    offsetof(CUturingThreadState, actExclHdl_exitedThreads)
   This works out to 0x1000000 - 512 - 64 + 0x1c = 0xfffddc
*/
#define TURING_LMEM_SAVED_MEXITED       (TURING_SYSTEM_STACK_POINTER + 0x1c)

#define TURING_GPC_OFFSET 0x8000
#define TURING_TPC_OFFSET 0x800
#define TURING_SM_OFFSET  0x80

/* ABI semantics: A function's absolute return address is stored in 2 regs */
#define TURING_ABI_SP      (1) /* R1 is the stack pointer address */
#define TURING_ABI_RPC_LO (20) /* R20 are the return address lo bits */
#define TURING_ABI_RPC_HI (21) /* R21 are the return address hi bits */

void haloDeviceInit_tu100(Halo_st *halo);

#endif
