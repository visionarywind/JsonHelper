/*
 * Copyright 2016-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef TURING_SCRATCHPAD_H
#define TURING_SCRATCHPAD_H

#include <halo_scratchpad_consts.h>
#include "asm/turing_struct_offsets.h"

#pragma pack(push,1)
typedef struct {
    uint32_t threadIdx;        // SR32 / SR_Tid / threadIdx.{x,y,z}
    uint32_t r1;               // Special case, needed for stack check
} TuringLaneScratchpad_t;

typedef struct {
    TuringLaneScratchpad_t lane[32];
    uint32_t    mpsContextId;         // 32 bit client Context ID under MPS
    uint32_t    subContextVSMId;      // SR67 Subcontext vsmid
    uint32_t    subContextVEId;       // SR68 Subcontext engineId
    uint32_t    gridDimX;             // QMD / c[0][0x34]
    uint32_t    gridDimY;             // QMD / c[0][0x38]
    uint32_t    gridDimZ;             // QMD / c[0][0x3c]
    uint64_t    gridId;               // gridId64
    uint32_t    blockIdxX;            // SR37
    uint32_t    blockIdxY;            // SR38
    uint32_t    blockIdxZ;            // SR39
    uint32_t    blockDimX;            // QMD / c[0][0x28]
    uint32_t    blockDimY;            // QMD / c[0][0x2c]
    uint32_t    blockDimZ;            // QMD / c[0][0x30]
    uint64_t    selfQMDAddr;          // Pointer to both CPU and GPU QMD launch structure
    uint32_t    shmemSizePrBlock;     // SR50
    uint32_t    globalErrorStatus;    // SR64
    uint32_t    virtID;               // SR3
    uint32_t    lmemWindowSize;       // SR53
    uint32_t    lmemLoSizePrThread;   // SR54
    uint32_t    lmemHiOff;            // SR55
    uint64_t    lmemBase;             // This warp's lmemBase (either default, or set via SETLMEMBASE)
    uint32_t    warpBarrierState;     // This warp's barrier state
    uint32_t    warpErrorStatus;      // SR66
    uint64_t    warpErrorPC;          // SR84/SR85
    uint64_t    paramConstDptr;       // Pointer to the parameter bank of this warp's grid.
    uint32_t    isQueueCTA;           // If this CTA is a QUeue CTA
    uint32_t    singleStepNsteps;     // How many single steps to perform; pause is executed when nsteps reaches 0
    uint32_t    regCount;             // SR61 SR_RegAlloc
    uint32_t    trapReturnMask;       // TRAP_RETURN_MASK
    uint64_t    trapReturnPC;         // TRAP_RETURN_PC
    uint32_t    warpExitedMask;       // MEXITED
    uint8_t     warpFlagsValidOnSave;  // Warp was valid on save
    uint8_t     warpFlagsPauseServiced;// Warp was valid on save
    uint8_t     padding[2];           // padding
} TuringWarpScratchpad_t;

typedef struct {
    uint64_t padding[8];                // Retain as padding for future extension (if not TRIM)
} TuringSMScratchpad_t;

typedef struct {
    uint32_t         active;            // to identify the active context on the device
    uint32_t         preemptCommand;    // Used for preemption-style debugging
    uint32_t         padding[2];        // force alignment to 128 because shared to global copy uses ST128.
    TuringWarpScratchpad_t   warp[CUDBG_MAX_TOTAL_SMS_TURING][CUDBG_MAX_WARP_TURING];
    TuringSMScratchpad_t     sm[CUDBG_MAX_TOTAL_SMS_TURING];
} TuringScratchpad_t;
#pragma pack(pop)

ct_assert(sizeof(TuringLaneScratchpad_t) == sizeof_TuringLaneScratchpad_t);
ct_assert(sizeof(TuringWarpScratchpad_t) == sizeof_TuringWarpScratchpad_t);
ct_assert(sizeof(TuringSMScratchpad_t) == sizeof_TuringSMScratchpad_t);
ct_assert(sizeof(TuringScratchpad_t) == sizeof_TuringScratchpad_t);

/* Turing Scratchpad size
 * (used in the allocation of scratchpad by the driver)
 */
#define TURING_TU10X_TRAP_HANDLER_SCRATCHPAD_SIZE        (sizeof(TuringScratchpad_t))

typedef enum {
    TURING_TU10X_PREEMPT_COMMAND_NONE              = 0x0,
    TURING_TU10X_PREEMPT_COMMAND_PAUSE_ON_RESTORE  = 0x1,
    TURING_TU10X_PREEMPT_COMMAND_SAVE_ON_PAUSE     = 0x2,
    TURING_TU10X_PREEMPT_COMMAND_RESTORE_ON_RESUME = 0x3,
} TuringPreemptCommand;



#endif
