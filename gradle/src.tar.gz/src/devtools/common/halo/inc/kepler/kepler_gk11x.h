/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: kepler_gk11x.h
 *
 *   Description:
 *       Debugger access functions that are different for the Kepler GK11x family.
 *
 ******************************************************************************/

#ifndef _HALO_KEPLER_GK11X_H
#define _HALO_KEPLER_GK11X_H

#include <halo.h>
#include <fermi_mcinterop.h>

/* No narrows on GK11X (GK10x also does not use narrows, but shares the same instruction
   size evaluation with GF100).  This size is specified in bytes. */
#define KEPLER_GK11X_INSTRUCTION_SIZE 8

/* 64-bit breakpoint instruction.  No narrow instruction (BPT_N.TRAP) on GK11X :(
   Reason code of 1 is used (0 is reserved by HW, 2 for syscalls, and 3 for CNP) */
#define KEPLER_GK11X_BREAKPT64 0x0000000000800300ULL

/* BPT.TRAP Immediate Definitions */
typedef enum {
    KEPLER_GK11X_TRAP_IMMEDIATE_ILLEGAL    = 0,
    KEPLER_GK11X_TRAP_IMMEDIATE_BREAKPOINT = 1,
    KEPLER_GK11X_TRAP_IMMEDIATE_CNP        = 2,
    KEPLER_GK11X_TRAP_IMMEDIATE_SYSCALL    = 3,
} KeplerGK11XTrapImmediate_t;

/* Local memory ABI definitions (Mostly identical to Fermi)
 *
 * !! IMPORTANT !!
 *
 * The following are used as negative offsets from
 * the end of lmem (high).  These must match the
 * offsets used in the trap handler. */
#define KEPLER_GK11X_LMEM_ABI_HI(vsm,wp) (dev->smState[vsm].warp[wp].lmemConfig.windowSize) // 16MB
#define KEPLER_GK11X_LMEM_ABI_SAVED_R0                 4
#define KEPLER_GK11X_LMEM_ABI_SAVED_R63              256
#define KEPLER_GK11X_LMEM_ABI_KILP_R0                260
#define KEPLER_GK11X_LMEM_ABI_KILP_R1                264
#define KEPLER_GK11X_LMEM_ABI_KILP_R2                268
#define KEPLER_GK11X_LMEM_ABI_KILP_R3                272
#define KEPLER_GK11X_LMEM_ABI_SAVED_SCRATCHPAD_PTR   276
#define KEPLER_GK11X_LMEM_ABI_DYNAMIC_REGISTER       280 /* New to GK110 */
#define KEPLER_GK11X_LMEM_ABI_KILP_TRAP_BIT          280 /* Shares same location as DYNAMIC_REGISTER */
#define KEPLER_GK11X_LMEM_ABI_TEXTURE_COORDS_3       284
#define KEPLER_GK11X_LMEM_ABI_TEXTURE_COORDS_2       288
#define KEPLER_GK11X_LMEM_ABI_TEXTURE_COORDS_1       292
#define KEPLER_GK11X_LMEM_ABI_TEXTURE_COORDS_0       296
#define KEPLER_GK11X_LMEM_ABI_TEXTURE_READ_RESULT    296 /* COORDS_0 reused for the result */
#define KEPLER_GK11X_LMEM_ABI_SAVED_PREDICATES       300
#define KEPLER_GK11X_LMEM_ABI_TH_SERVICE_REASON      304
#define KEPLER_GK11X_LMEM_ABI_TH_SERVICE_NUM_LANES   308
#define KEPLER_GK11X_LMEM_ABI_TH_SERVICE_ADDR        312
#define KEPLER_GK11X_LMEM_ABI_TH_SERVICE_SIZE        316
#define KEPLER_GK11X_LMEM_ABI_TH_TOTAL_RESERVE       (KEPLER_GK11X_LMEM_ABI_TH_SERVICE_SIZE)

/* Registers 0 - 63 are saved at the top of LMEM_HI.  Leaving
   space for all 255 registers would be too large of a
   reservation, so the remainder are read out dynamically,
   with storage held at KEPLER_GK11X_LMEM_ABI_DYNAMIC_REGISTER */
#define KEPLER_GK11X_DYNAMIC_REGISTER_START           64
#define KEPLER_GK11X_DYNAMIC_REGISTER_END            255


/* CNP-related items for GK110 */

/* CNP:  The offset in the parameter constant bank (per-launch) containing
   a pointer to the GPUQMDLaunch_st data structure corresponding to the
   currently resident grid. */
#define KEPLER_GK11X_CNP_SELF_QMD_CONSTBANK_OFFSET  5696 /* See //sw/gpgpu/cuda/apps/cnp_common/cnp.cu */

/* CNP:  The scheduler kernel has a fixed grid ID */
#define KEPLER_GK11X_CNP_SCHED_KERNEL_GRID_ID          -4

void haloDeviceInit_gk11x(Halo_st *halo);
CUDBGResult kepler_gk11x_getInfo(CudbgDevice dev);

CUDBGResult kepler_gk11x_resumeDevice(CudbgDevice dev, uint32_t *hasResumed, uint32_t skipResume);
CUDBGResult kepler_gk11x_resumeTPC(CudbgDevice dev, uint32_t vsm);

#endif
