/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: kepler.h
 *
 *   Description:
 *       Debugger access functions that are different for the Kepler family.
 *
 ******************************************************************************/

#ifndef _HALO_KEPLER_H
#define _HALO_KEPLER_H

#include <halo.h>
#include <kepler_gk10x.h>
#include <kepler_gk11x.h>
#include <kepler_gk20a.h>
#include <kepler_scratchpad.h>

#define KEPLER_IDE_REGION_MASK 0x00000020U // Bit 5 of the global ESR
#define KEPLER_TRAP_IMMEDIATE_FIELD 31:24  // Bits 31:24 of the warp ESR hold the trap immediate

/* Kepler system stack pointer
   From cui/hal/kepler/kepler.h
   This is given as CU_KEPLER_LMEM_TOTAL_SIZE           -
                    CU_KEPLER_LMEM_DEBUGGER_SIZE        -
                    CU_KEPLER_LMEM_THREAD_STATE_SIZE
   This works out to 0x1000000 - 512 - 48 = 0xfffdd0
*/
#define KEPLER_SYSTEM_STACK_POINTER 0xfffdd0ULL

/* Kepler system stack pointer save address
   From cui/hal/kepler/kepler.h
   This is given as CU_KEPLER_LMEM_TOTAL_SIZE           -
                    CU_KEPLER_LMEM_DEBUGGER_SIZE        -
                    CU_KEPLER_LMEM_THREAD_STATE_SIZE    +
                    offsetof(CUkeplerThreadState, savedUserStackPointer)
   This works out to 0x1000000 - 512 - 48 + 16 = 0xfffde0
*/
#define KEPLER_LMEM_SAVED_STACK_POINTER 0xfffde0ULL

/* The number of the register where the stack pointer
   is placed */
#define KEPLER_ABI_SP_REGNUM 1

/* MEMBAR WAR : Spill location for R0, R2, R3
    These are setup in cui/hal/kepler/kepler.h
    These values are compile time asserted in the driver build. If any changes
    happen to cui/hal/kepler/kepler.h, they _MUST_ be changed here.
  */
#define KEPLER_LMEM_HI_MEMBAR_WAR_SPILL_R0 0xfffde4
#define KEPLER_LMEM_HI_MEMBAR_WAR_SPILL_R2 0xfffde8
#define KEPLER_LMEM_HI_MEMBAR_WAR_SPILL_R3 0xfffdec
#define KEPLER_LMEM_HI_MEMBAR_WAR_SPILL_PR 0xfffdf0

#define KEPLER_MAX_CTA_PER_SM 16
#define KEPLER_NUM_PREDICATES  7

/* On Kepler, there are some bits in the global ESR that are not
   REAL errors (BPT_PAUSE, BPT_INT).  Mask those bits off when
   determining if we have real errors in this register. */
#define KEPLER_PRI_GLOBAL_ESR_ERROR_MASK 0xffffffcfU

/* Timeout (in milliseconds) polling for RUN_TRIGGER (HW Bug 1239649) */
#define KEPLER_WAIT_FOR_RUN_TRIGGER_DONE_TIMEOUT 5000

/* Define Kepler CRS entry types */
typedef enum {
    CRS_TYPE_ILL          =  0, /* ILLEGAL!  Should never happen! */
    CRS_TYPE_SAM          =  1,
    CRS_TYPE_CALL_NI      =  2, /* Don't increment CALL count */
    CRS_TYPE_CALL         =  3, /* Increment CALL count */
    CRS_TYPE_PBRK         =  4,
    CRS_TYPE_PCONT        =  5,
    CRS_TYPE_DIV          =  6, /* Divergence */
    CRS_TYPE_DIV_IDX      =  7, /* BRX Divergence */
    CRS_TYPE_SSY          =  8, /* Synchronization */
    CRS_TYPE_PLONGJMP     =  9,
    CRS_TYPE_TRAP         = 10, /* TRAP instruction */
    CRS_TYPE_DIS_RET      = 11,
    CRS_TYPE_DIS_CONT     = 12,
    CRS_TYPE_DIS_BRK      = 13,
    CRS_TYPE_DIS_SYNC     = 14,
    CRS_TYPE_DIS_LONGJUMP = 15,
    CRS_TYPE_DIS_EXIT     = 16,
    CRS_TYPE_NOP          = 17,
    CRS_TYPE_MULTI        = 18,
} CRSId_t;

void haloDeviceInit_gk100(Halo_st *halo);
void haloDeviceInit_gk110(Halo_st *halo);
void haloDeviceInit_gk200(Halo_st *halo);
void haloDeviceInit_gk20a(Halo_st *halo);

#endif
