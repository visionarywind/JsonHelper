/*
 * Copyright 2016-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: volta.h
 *
 *   Description:
 *       Debugger access functions that are different for the Volta family.
 *
 ******************************************************************************/

#ifndef _HALO_VOLTA_H
#define _HALO_VOLTA_H

#include <halo.h>
#include <volta_scratchpad.h>
#include <volta_gv10x.h>
#include <volta_cilp_preemption_buffer.h>

#define VOLTA_GV10X_TRAP_IMMEDIATE_BREAKPOINT (0x1)
#define VOLTA_GV10X_TRAP_IMMEDIATE_UNMASKABLE (0x7)

/* Volta system stack pointer range
   From cui/hal/volta/volta.h
   This is given as CU_VOLTA_LMEM_RESERVE_SIZE
   This works out to  - 512 - 64 =
   */
#define VOLTA_SYSTEM_STACK_POINTER     (0xfffdc0ULL)

/* Volta system stack pointer save address
   From cui/hal/volta/volta.h
   This is given as CU_VOLTA_LMEM_TOTAL_SIZE           -
                    CU_VOLTA_LMEM_DEBUGGER_SIZE        -
                    CU_VOLTA_LMEM_THREAD_STATE_SIZE    +
                    offsetof(CUvoltaThreadState, savedUserStackPointer)
   This works out to 0x1000000 - 512 - 64 + 4 = 0xfffdc4
*/
#define VOLTA_LMEM_SAVED_STACK_POINTER (VOLTA_SYSTEM_STACK_POINTER + 4)

/* Volta system return pc save address
   From cui/hal/volta/volta.h
   This is given as CU_VOLTA_LMEM_TOTAL_SIZE           -
                    CU_VOLTA_LMEM_DEBUGGER_SIZE        -
                    CU_VOLTA_LMEM_THREAD_STATE_SIZE    +
                    offsetof(CUvoltaThreadState, savedTrampolineReturnVA)
   This works out to 0x1000000 - 512 - 64 + 8 = 0xfffdc8
*/
#define VOLTA_LMEM_SAVED_RETURN_PC     (VOLTA_SYSTEM_STACK_POINTER + 8)

/* For Volta convergent syscalls, MACTIVE and MEXITED are saved off in the
   system stack.  Read them from there.
*/
/* Enabled as Bug 1931917 is submitted */
#define VOLTA_CONVERGENT_SYSCALLS (1)

/* Volta MEXITED mask save address
   From asm/volta_gv10x.h
   This is given as CU_VOLTA_LMEM_TOTAL_SIZE           -
                    CU_VOLTA_LMEM_DEBUGGER_SIZE        -
                    CU_VOLTA_LMEM_THREAD_STATE_SIZE    +
                    offsetof(CUvoltaThreadState, actExclHdl_activeThreads)
   This works out to 0x1000000 - 512 - 64 + 0x18 = 0xfffdd8
*/
#define VOLTA_LMEM_SAVED_MACTIVE       (VOLTA_SYSTEM_STACK_POINTER + 0x18)

/* Volta MEXITED mask save address
   From asm/volta_gv10x.h
   This is given as CU_VOLTA_LMEM_TOTAL_SIZE           -
                    CU_VOLTA_LMEM_DEBUGGER_SIZE        -
                    CU_VOLTA_LMEM_THREAD_STATE_SIZE    +
                    offsetof(CUvoltaThreadState, actExclHdl_exitedThreads)
   This works out to 0x1000000 - 512 - 64 + 0x1c = 0xfffddc
*/
#define VOLTA_LMEM_SAVED_MEXITED       (VOLTA_SYSTEM_STACK_POINTER + 0x1c)

#define VOLTA_GPC_OFFSET 0x8000
#define VOLTA_TPC_OFFSET 0x800
#define VOLTA_SM_OFFSET  0x80

/* ABI semantics: A function's absolute return address is stored in 2 regs */
#define VOLTA_ABI_SP      (1) /* R1 is the stack pointer address */
#define VOLTA_ABI_RPC_LO (20) /* R20 are the return address lo bits */
#define VOLTA_ABI_RPC_HI (21) /* R21 are the return address hi bits */

/* MEMBAR WAR : Spill location for R2, R3
    These are setup in cui/hal/volta/volta.h
    These values are compile time asserted in the driver build. If any changes
    happen to cui/hal/volta/volta.h, they _MUST_ be changed here.
  */
#define VOLTA_LMEM_HI_MEMBAR_WAR_SPILL_R2 0xfffdf8
#define VOLTA_LMEM_HI_MEMBAR_WAR_SPILL_R3 0xfffdfc

/* LDC WAR : Spill location for R2, R3
    These are setup in cui/hal/volta/volta.h
    These values are compile time asserted in the driver build. If any changes
    happen to cui/hal/volta/volta.h, they _MUST_ be changed here.
  */
#define VOLTA_LMEM_HI_LDC_WAR_SPILL_R2 0xfffdd0
#define VOLTA_LMEM_HI_LDC_WAR_SPILL_R3 0xfffdd4

void haloDeviceInit_gv100(Halo_st *halo);

#endif
