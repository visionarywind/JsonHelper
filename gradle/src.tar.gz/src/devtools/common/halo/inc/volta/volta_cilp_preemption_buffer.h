/*
 * Copyright 2016-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef __VOLTA_CILP_PREEMPTION_BUFFER_H__
#define __VOLTA_CILP_PREEMPTION_BUFFER_H__

#include "nvctassert.h"
#include "cui/hal/volta/volta_arch_consts.h"
// For offset checks
#include "asm/arch_include/sm_70/cilp_buffer_offsets.h"

// From //hw/class/volta/include/traphandler/cilp_buffer.h
// with type names prefixed with CU.
// TODO: Update me with drivers/gpgpu/cuda/src/asm/arch_include/sm_70/cilp_buffer.h

// NOTE: all structures are currently padded to 8B

// From //hw/class/volta/include/trap_handler/sm_arch_defs.h
// TODO: Update me with constant from volta_arch_consts.h
#define CUDBG_MAX_CBU_BARRIERS_VOLTA 16

#pragma pack(push,1)

typedef struct CUvoltaWarpCILPBuffer_st {
    uint64_t CBU_RPC[CUDBG_MAX_LANE_VOLTA];
    uint32_t CBU_BAR[CUDBG_MAX_CBU_BARRIERS_VOLTA];
    uint64_t CBU_TRAP_RETURN_PC;
    uint64_t CBU_ATEXITPC;
    uint32_t CBU_MKILL;
    uint32_t CBU_TRAP_RETURN_MASK; // same as MACTIVE
    uint32_t CBU_MEXITED;
    uint32_t CBU_MATEXIT;
    uint32_t CBU_API_CALL_DEPTH;
    uint32_t CBU_OPT_STACK;
    uint32_t CBU_THREAD_STATE_ENUM_0;
    uint32_t CBU_THREAD_STATE_ENUM_1;
    uint32_t CBU_THREAD_STATE_ENUM_2;
    uint32_t CBU_THREAD_STATE_ENUM_3;
    uint32_t CBU_THREAD_STATE_ENUM_4;
    uint8_t reservedPad0;
    uint8_t reservedPad1;
    uint8_t reservedPad2;
    uint8_t reservedPad3;
    uint64_t LMEMBASE;
    uint32_t BARState;
    uint32_t RFDataIdx; // Offset into RFData, SR_regAlloc tells us how many
    uint8_t PR[CUDBG_MAX_LANE_VOLTA];
} CUvoltaWarpCILPBuffer;

typedef struct CUvoltaCTACILPBuffer_st {
    uint64_t CTAID;
    uint32_t shmemDataIdx; // Offset into shmemData, SR_SMemSz tells us how much
    uint32_t reservedPad1;
    uint32_t BARState[CU_VOLTA_ARCH_CONST_HW_SM_MAX_BARRIERS_PER_CTA];
} CUvoltaCTACILPBuffer;

typedef struct CUvoltaSMCILPBuffer_st {
    uint32_t RFDataIdxSync; // used to calculate RFDataIdx values, by one thread per warp
    uint32_t shmemDataIdxSync; // used to calculate shmemDataIdx values, by one thread per CTA
    uint32_t validPendingState[2]; // one bit per warp to indicate that lmem-hi has valid state about pending events
    uint32_t reservedPad0;
    uint32_t reservedPad1;
    uint32_t reservedPad2;
    uint32_t reservedPad3;
    uint32_t RFData[CU_VOLTA_ARCH_CONST_HW_SM_RF_SIZE_WORDS]; // IMPORTANT: This needs to be 128B aligned!!!
    uint32_t shmemData[CU_VOLTA_ARCH_CONST_HW_SM_MAX_SHARED_MEMORY_PER_SM_WORDS];
    CUvoltaWarpCILPBuffer warpData[CUDBG_MAX_WARP_VOLTA];
    CUvoltaCTACILPBuffer CTAData[CU_VOLTA_ARCH_CONST_HW_SM_MAX_CTAS_PER_SM];
} CUvoltaSMCILPBuffer;
#pragma pack(pop)

// Checks for per warp data offsets
ct_assert(sizeof(CUvoltaWarpCILPBuffer) == sizeof_VoltaWarpCILPBuffer_t);

// Check per CTA data offsets
ct_assert(sizeof(CUvoltaCTACILPBuffer) == sizeof_VoltaCTACILPBuffer_t);

// Check per SM data offsets
ct_assert(sizeof(CUvoltaSMCILPBuffer) == sizeof_VoltaSMCILPBuffer_t);

#endif // __VOLTA_CILP_PREEMPTION_BUFFER_H__

