/*
 * Copyright 2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef VOLTA_RACECHECK_LMEM_H
#define VOLTA_RACECHECK_LMEM_H

#include "fermi_racecheck_lmem.h"

/* LMEM Hi usage in racecheck Volta+
   Volta extends the LMEM_HI space used by racecheck from 96 to 160 bytes.

    -------------------------  0x00 = 0xfffe00
    | Same as Fermi+        |
    | see fermi_racecheck_lmem.h |
    | for details.          |
    -------------------------  0x60 = 0xfffe60
    |          R8           |
    |          R9           |
    |          R10          |
    |          R11          |
    -------------------------  0x70 = 0xfffe70
    |          RA LO        |
    |          RA HI        |
    |        reserved0      |
    |        reserved1      |
    -------------------------  0x80 = 0xfffe80
    |        MEXITED        |
    |       OPT_STACK       |
    |   THREAD_STATE_ENUM2  |
    |   THREAD_STATE_ENUM3  |
    -------------------------  0x90 = 0xfffe90
    |        MACTIVE        |
    |   THREAD_STATE_ENUM0  |
    |   THREAD_STATE_ENUM1  |
    |   THREAD_STATE_ENUM4  |
    -------------------------  0xa0 = 0xfffea0
*/


#define RACE_LMEM_R8                 0x60  // Offset that R8 is saved to
#define RACE_LMEM_R9                 0x64  // Offset that R9 is saved to
#define RACE_LMEM_R10                0x68  // Offset that R10 is saved to
#define RACE_LMEM_R11                0x6c  // Offset that R11 is saved to
#define RACE_LMEM_RA_LO              0x70  // Offset that original RA LO value is saved to
#define RACE_LMEM_RA_HI              0x74  // Offset that original RA HI value is saved to
#define RACE_LMEM_MEXITED            0x80  // Offset that MEXITED is saved to
#define RACE_LMEM_OPT_STACK          0x84  // Offset that OPT_STACK is saved to
#define RACE_LMEM_THREAD_STATE_ENUM2 0x88  // Offset that THREAD_STATE_ENUM.2 is saved to
#define RACE_LMEM_THREAD_STATE_ENUM3 0x8c  // Offset that THREAD_STATE_ENUM.3 is saved to
#define RACE_LMEM_MACTIVE            0x90  // Offset that MACTIVE is saved to
#define RACE_LMEM_THREAD_STATE_ENUM0 0x94  // Offset that THREAD_STATE_ENUM.0 is saved to
#define RACE_LMEM_THREAD_STATE_ENUM1 0x98  // Offset that THREAD_STATE_ENUM.1 is saved to
#define RACE_LMEM_THREAD_STATE_ENUM4 0x9c  // Offset that THREAD_STATE_ENUM.4 is saved to

#endif
