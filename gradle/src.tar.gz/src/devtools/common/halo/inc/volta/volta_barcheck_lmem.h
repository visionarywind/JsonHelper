/*
 * Copyright 2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef VOLTA_BARCHECK_LMEM_H
#define VOLTA_BARCHECK_LMEM_H

#include "fermi_barcheck_lmem.h"

/* LMEM Hi usage in barcheck Volta+

    -------------------------  0x00 = 0xfffe00
    | Same as Fermi+        |
    | see fermi_barcheck_lmem.h |
    | for details.          |
    -------------------------  0x60 = 0xfffe60
    |     R16               |
    |     R17               |
    |     R18               |
    |     R19               |
    -------------------------  0x70 = 0xfffe70
    |     R20               |
    |     R21               |
    |     STACK_SIZE        |
    |     FLAGS             |
    -------------------------  0x80 = 0xfffe80
    |     MEXITED           |
    |     OPT_STACK         |
    |   THREAD_STATE_ENUM2  |
    |   THREAD_STATE_ENUM3  |
    -------------------------  0x90 = 0xfffe90
    |     MACTIVE           |
    |   THREAD_STATE_ENUM0  |
    |   THREAD_STATE_ENUM1  |
    |   THREAD_STATE_ENUM4  |
    -------------------------  0xa0 = 0xfffea0
    |     B0                |
    |     B1                |
    |     B2                |
    |     B3                |
    -------------------------  0xb0 = 0xfffb90
    |     B4                |
    |     B5                |
    -------------------------  0xb8 = 0xfffeb8
    |       <callstack>     |
    | until end of lmem hi  |
    | pc_lo0                |
    | pc_hi0                |
    | pc_lo1                |
    | pc_hi1                |
    | ...                   |

*/

#define BARCHECK_VOLTA_LMEM_SCRATCH            FERMI_LMEM_HI_MEMCHECK_SCRATCH

#define BARCHECK_VOLTA_LMEM_R0                 BARCHECK_LMEM_R0
#define BARCHECK_VOLTA_LMEM_R1                 BARCHECK_LMEM_R1
#define BARCHECK_VOLTA_LMEM_R2                 BARCHECK_LMEM_R2
#define BARCHECK_VOLTA_LMEM_R3                 BARCHECK_LMEM_R3
#define BARCHECK_VOLTA_LMEM_R4                 BARCHECK_LMEM_R4
#define BARCHECK_VOLTA_LMEM_R5                 BARCHECK_LMEM_R5
#define BARCHECK_VOLTA_LMEM_R6                 BARCHECK_LMEM_R6
#define BARCHECK_VOLTA_LMEM_R7                 BARCHECK_LMEM_R7
#define BARCHECK_VOLTA_LMEM_R8                 BARCHECK_LMEM_R8
#define BARCHECK_VOLTA_LMEM_R9                 BARCHECK_LMEM_R9
#define BARCHECK_VOLTA_LMEM_R10                BARCHECK_LMEM_R10
#define BARCHECK_VOLTA_LMEM_R11                BARCHECK_LMEM_R11
#define BARCHECK_VOLTA_LMEM_R12                BARCHECK_LMEM_R12
#define BARCHECK_VOLTA_LMEM_R13                BARCHECK_LMEM_R13
#define BARCHECK_VOLTA_LMEM_R14                BARCHECK_LMEM_R14
#define BARCHECK_VOLTA_LMEM_R15                BARCHECK_LMEM_R15
#define BARCHECK_VOLTA_LMEM_R16                0x60
#define BARCHECK_VOLTA_LMEM_R17                0x64
#define BARCHECK_VOLTA_LMEM_R18                0x68
#define BARCHECK_VOLTA_LMEM_R19                0x6c
#define BARCHECK_VOLTA_LMEM_R20                0x70
#define BARCHECK_VOLTA_LMEM_R21                0x74
#define BARCHECK_VOLTA_LMEM_STACK_SIZE         0x78
#define BARCHECK_VOLTA_LMEM_FLAGS              0x7c // bitmask of BARCHECK_VOLTA_LMEM_FLAGS_*
#define BARCHECK_VOLTA_LMEM_MEXITED            0x80
#define BARCHECK_VOLTA_LMEM_OPT_STACK          0x84
#define BARCHECK_VOLTA_LMEM_THREAD_STATE_ENUM2 0x88
#define BARCHECK_VOLTA_LMEM_THREAD_STATE_ENUM3 0x8c
#define BARCHECK_VOLTA_LMEM_MACTIVE            0x90
#define BARCHECK_VOLTA_LMEM_THREAD_STATE_ENUM0 0x94
#define BARCHECK_VOLTA_LMEM_THREAD_STATE_ENUM1 0x98
#define BARCHECK_VOLTA_LMEM_THREAD_STATE_ENUM4 0x9c
#define BARCHECK_VOLTA_LMEM_B0                 0xa0
#define BARCHECK_VOLTA_LMEM_B1                 0xa4
#define BARCHECK_VOLTA_LMEM_B2                 0xa8
#define BARCHECK_VOLTA_LMEM_B3                 0xac
#define BARCHECK_VOLTA_LMEM_B4                 0xb0
#define BARCHECK_VOLTA_LMEM_B5                 0xb4
#define BARCHECK_VOLTA_LMEM_STACK_MAX          0x29
#define BARCHECK_VOLTA_LMEM_STACK_START        0xb8
#define BARCHECK_VOLTA_LMEM_STACK_END          0x200
#define BARCHECK_VOLTA_LMEM_STACK_ENTRY_BYTES  0x8 // pc is 64 bit

#define BARCHECK_VOLTA_LMEM_FLAGS_NONE         0x0
#define BARCHECK_VOLTA_LMEM_FLAGS_CG_CALL      0x1
#define BARCHECK_VOLTA_LMEM_FLAGS_CG_CALL_NEG  0xfffffffe

#endif
