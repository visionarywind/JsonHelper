/*
 * Copyright 2016-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef VOLTA_INITCHECK_LMEM_H
#define VOLTA_INITCHECK_LMEM_H

#include "fermi_initcheck_lmem.h"

/* LMEM Hi usage in initcheck Volta+
   Volta extends the LMEM_HI space used by initcheck from 96 to 192 bytes.

    -------------------------  0x00 = 0xfffe00
    | Same as Fermi+        |
    | see fermi_initcheck_lmem.h |
    | for details.          |
    -------------------------  0x60 = 0xfffe60
    |          R16          |
    |          R17          |
    |          R18          |
    |          R19          |
    -------------------------  0x70 = 0xfffe70
    |          R20          |
    |          R21          |
    |          R22          |
    |          R23          |
    -------------------------  0x80 = 0xfffe80
    |          B0           |
    |          B1           |
    |          B2           |
    |          B3           |
    -------------------------  0x90 = 0xfffe90
    |          B4           |
    |          B5           |
    |          RA LO        |
    |          RA HI        |
    -------------------------  0xa0 = 0xfffea0
    |        MEXITED        |
    |        OPT_STACK      |
    |   THREAD_STATE_ENUM2  |
    |   THREAD_STATE_ENUM3  |
    -------------------------  0xb0 = 0xfffeb0
    |        MACTIVE        |
    |   THREAD_STATE_ENUM0  |
    |   THREAD_STATE_ENUM1  |
    |   THREAD_STATE_ENUM4  |
    -------------------------  0xc0 = 0xfffec0

*/


#define INITCHECK_LMEM_R16                0x60  // Offset that R16 is saved to
#define INITCHECK_LMEM_R17                0x64  // Offset that R17 is saved to
#define INITCHECK_LMEM_R18                0x68  // Offset that R18 is saved to
#define INITCHECK_LMEM_R19                0x6c  // Offset that R19 is saved to
#define INITCHECK_LMEM_R20                0x70  // Offset that R20 is saved to
#define INITCHECK_LMEM_R21                0x74  // Offset that R21 is saved to
#define INITCHECK_LMEM_R22                0x78  // Offset that R22 is saved to
#define INITCHECK_LMEM_R23                0x7c  // Offset that R23 is saved to
#define INITCHECK_LMEM_B0                 0x80  // Offset that B0 is saved to
#define INITCHECK_LMEM_B1                 0x84  // Offset that B1 is saved to
#define INITCHECK_LMEM_B2                 0x88  // Offset that B2 is saved to
#define INITCHECK_LMEM_B3                 0x8c  // Offset that B3 is saved to
#define INITCHECK_LMEM_B4                 0x90  // Offset that B4 is saved to
#define INITCHECK_LMEM_B5                 0x94  // Offset that B5 is saved to
#define INITCHECK_LMEM_RA_LO              0x98  // Offset that original RA LO value is saved to
#define INITCHECK_LMEM_RA_HI              0x9c  // Offset that original RA HI value is saved to
#define INITCHECK_LMEM_MEXITED            0xa0  // Offset that original MEXITED value is saved to
#define INITCHECK_LMEM_OPT_STACK          0xa4  // Offset that original OPT_STACK value is saved to
#define INITCHECK_LMEM_THREAD_STATE_ENUM2 0xa8  // Offset that original THREAD_STATE_ENUM.2 value is saved to
#define INITCHECK_LMEM_THREAD_STATE_ENUM3 0xac  // Offset that original THREAD_STATE_ENUM.3 value is saved to
#define INITCHECK_LMEM_MACTIVE            0xb0  // Offset that original MACTIVE value is saved to
#define INITCHECK_LMEM_THREAD_STATE_ENUM0 0xb4  // Offset that original THREAD_STATE_ENUM.0 value is saved to
#define INITCHECK_LMEM_THREAD_STATE_ENUM1 0xb8  // Offset that original THREAD_STATE_ENUM.1 value is saved to
#define INITCHECK_LMEM_THREAD_STATE_ENUM4 0xbc  // Offset that original THREAD_STATE_ENUM.4 value is saved to

#endif
