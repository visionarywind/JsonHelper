/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: halo_state.h
 *
 *   Description:
 *       Contains functions to track the state of the halo. All functions here
 *       must be address space agnostic, and can be used by either halo type
 *
 ******************************************************************************/
#ifndef HALO_STATE_H
#define HALO_STATE_H

#include "halo.h"
#include "halo_internal.h"

#include "tools_shared_hashmap.h"

#include "cuictx.h"

typedef enum {
    HALO_ATTACH_STATE_NOT_STARTED = 0,
    HALO_ATTACH_STATE_IN_PROGRESS,
    HALO_ATTACH_STATE_COMPLETE,
    HALO_ATTACH_STATE_DETACHING
} attachState_t;

struct haloState_st {
    tHashMap *contexts;
    tHashMap *devices;
    attachState_t attachState;
};

typedef CUDBGResult (*haloCtxIterFunc) (Context ctx, void *data);

CUDBGResult haloStateInit(void);
CUDBGResult haloStateInitUVM(uint64_t uvmhdl);

void haloStateDestroy(void);
CUDBGResult haloStateDestroyUVM(void);

/* Context tracking */
CUDBGResult haloStateCreateContext(Context *pCtx, uint64_t cuctx, uint32_t devId, uint64_t scratchpadDevVA,
                                   uint64_t scratchpadDevPtr, uint32_t hAppClient, uint32_t hComputeObject,
                                   uint32_t hChannelGroup, uint32_t *channelList, uint32_t numChannels);
void        haloStateDestroyContext(Context ctx);
CUDBGResult haloStateAddContext(uint64_t cuctx, Context context);
CUDBGResult haloStateRemoveContext(uint64_t cuctx);
Context haloStateGetContext(uint64_t cuctx);
CUDBGResult haloStateNumContextsForDevice(CudbgDevice dev, int *numContexts);
CUDBGResult haloStateNumTotalContexts(int *numContexts);
CUDBGResult haloStateTraverseContexts(haloCtxIterFunc pfn, void *userData);
CUDBGResult haloStateDestroyContexts(haloCtxIterFunc pfn, void *userData);

bool        haloStateContextIsActive(Context ctx);
CUDBGResult haloStateContextSetState(Context ctx, HaloCtxState state);
CUDBGResult haloStateContextScratchpadCacheOp(Context ctx, HaloMemorySegmentCacheOp op);

bool        haloStateInsnCacheEnabled(void);
CUDBGResult haloStateContextInsnInfoCacheOp(Context ctx, HaloMemorySegmentCacheOp op);
CUDBGResult haloStateContextReadInsnCache(Context ctx, uint64_t pc, void *buf, uint32_t sz);
CUDBGResult haloStateContextWriteInsnCache(Context ctx, uint64_t pc, const void *buf, uint32_t sz);

/* Device tracking */
CudbgDevice haloStateGetDevice(uint64_t cudev);
CUDBGResult haloStateAddDevice(uint32_t devId, CudbgDevice device);

/* Higher level structure creation / destruction functions */
CUDBGResult     haloStateCreateGrid(Grid *pGrid, DeviceFunction func, uint64_t gridId64);
void            haloStateDestroyGrid(Grid grid);
CUDBGResult     haloStateCreateFunction(DeviceFunction *pFunc, DeviceModule mod, uint64_t gpuAddrBase, bool usesCnp, bool usesContinuations);
void            haloStateDestroyFunction(DeviceFunction func);
uint64_t        haloStateFunctionGetNumGrids(DeviceFunction function);
CUDBGResult     haloStateCreateModule(DeviceModule *pMod, Context ctx, uint64_t cuMod, uint32_t abiVersion);
void            haloStateDestroyModule(DeviceModule mod);
Grid            haloStateDeviceGetGrid(CudbgDevice dev, uint64_t gridId64);
Grid            haloStateDeviceGetAnyGrid(CudbgDevice dev);
uint64_t        haloStateDeviceGetNumGrids(CudbgDevice dev);
void            haloStateDeviceCreateMaps(CudbgDevice dev);
void            haloStateDeviceDestroyMaps(CudbgDevice dev);
haloMemoryMap*  haloStateGetGlobalMemMap(void);
tRangeMap*      haloStateGetGlobalHostVAMap(void);

bool haloStateSwCacheEnabled(void);
CUDBGResult haloStateGetTimeoutMsec(CudbgDevice dev, uint32_t *timeout);

#endif

