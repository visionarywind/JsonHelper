/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef _HALO_HALO_H
#define _HALO_HALO_H 1

/*------------------------------- Information --------------------------------*/

/*
 * DISCLAIMER: This comment is a best effort attempt at documenting HALO.
 * It does not, however, guarantee that the information is correct and up-to-date.
 * Therefore, it's for general understanding only. For the only source of truth
 * refer to the HALO source code.
 *
 * The main part of HALO (and what is usually called "a HALO") is the Halo_st struct
 * which contains function pointers to device arch-specific functions.
 * In an OOP-like way, a HALO struct is first initialized for the older architecture
 * (currently Fermi) and then some pointers are overridden for some of the newer
 * architectures.
 *
 * The current inheritance graph (derived from haloDeviceInitialize) is below.
 * Functions in *asterisks* are top-level ones that are called for initializing
 * HALO for specific device families.
 *

                                                *haloDeviceInit_ga100*
                                                  /                \
                                  haloDeviceInit_ga10x        haloDeviceInit_ga10x_cilp
                                            |                           |
                                            |   *haloDeviceInit_tu100*  |
                                            |     /                \    |
                                  haloDeviceInit_tu10x        haloDeviceInit_tu10x_cilp
                                            |                           |
                                            |   *haloDeviceInit_gv100*  |
                                            |     /                \    |
                                  haloDeviceInit_gv10x        haloDeviceInit_gv10x_cilp
                                            |                           |
                                            |   *haloDeviceInit_gp100*  |
                                            |     /                \    |
                                  haloDeviceInit_gp10x        haloDeviceInit_gp10x_cilp
                                                  \
                                                *haloDeviceInit_gm20x*
                                                           |
                                                *haloDeviceInit_gm100*
                                                  /                \
                                  haloDeviceInit_gm10x        haloDeviceInit_gm10x_kilp
                                            |
               *haloDeviceInit_gk200*       |      *haloDeviceInit_gk20a*
                                  \         |        /
   *haloDeviceInit_gk100*          \        |       /
                |      _________ *haloDeviceInit_gk110* ________
                |     /                     |                   \
    haloDeviceInit_gk10x          haloDeviceInit_gk11x        haloDeviceInit_gk11x_kilp
                |
   *haloDeviceInit_gf100*
 */

/*--------------------------------- Includes ---------------------------------*/
#include <halo_scratchpad_consts.h>
#include <halo_preemption_buffer_consts.h>
#include <halo_memmap.h>
#include "cuda_internal.h"
#include "cuda_device.h"
#include "cudadebugger.h"
#include "cudbgdriver.h"
#include "cudbgpipe.h"
#include "tools_shared_hashmap.h"
#include "tools_shared_hashset.h"
#include "tools_shared_rangemap.h"
#include "tools_shared_dwarf.h"
#include "cpuopsys.h"

#include "halo_cpu.h"
#include "cuda_warpbitmask.h"

#ifdef CUDBG_ENABLE_IFB
#include "class/cl9068.h" // FERMI IFB
#endif

#if defined(__linux__) || defined(__APPLE__) || cuiOsIsQnx() || cuiOsIsHos()/* CUDA & CLH */
#  include <sys/types.h>
#  include <signal.h>
#else
typedef unsigned pid_t;
#endif

#if cuiPlatformHasKernelModeUvm()
    #include "uvm.h"
    #if cuiOsIsWindows()
        #include "uvm_windows.h"
    #endif
#else
    typedef void* UvmToolsSessionHandle;
#endif

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

/* XXX move all those structs into a cudbgstate.h file */
typedef struct DeviceFunctionRec    *DeviceFunction;
typedef struct ContextRec           *Context;
typedef struct DeviceModuleRec      *DeviceModule;
typedef struct BreakpointRec        *Breakpoint;
typedef struct GridRec              *Grid;
typedef struct DebugPatchRec        *DebugPatch;
typedef struct HaloDmal_st          *HaloDmal;
typedef struct HaloClient_st        *HaloClient;
typedef struct HaloInitData_st      *HaloInitData;
typedef struct HaloClientData_st    *HaloClientData;
typedef struct HaloGlobals_st        HaloGlobals;
typedef struct HaloScratchpadAccessor_st    *HaloScratchpadAccessor;
typedef struct HaloPreemptionBufferAccessor_st *HaloPreemptionBufferAccessor;

/*--------------------------------- Constants --------------------------------*/

/* Maximum number of levels to unwind before giving up */
#define UNWIND_MAX_LEVELS 1000

/* Architectural constants for the scratchpad come from halo_scratchpad_consts.h */

/* Texture related constants */
#define CUDBG_TEX_DIM_MAX   4
#define CUDBG_TEX_DIM_MIN   1
#define CUDBG_TEX_DPTR_MASK 0xFFFFFFFFFFULL /* 40-bit VA (upper[7:0] + lower[31:0]) */

/* RM watchdog timer/interval constants */
#define CUDBG_RM_WATCHDOG_TIMEOUT_MAX      0xFFFFFFFFU
#define CUDBG_RM_WATCHDOG_INTERVAL_MAX     0xFFFFFFFFU
#define CUDBG_RM_WATCHDOG_TIMEOUT_DEFAULT  0x0U
#define CUDBG_RM_WATCHDOG_INTERVAL_DEFAULT 0x0U

#define CUDBG_INVALID_HANDLE 0x0U

/*----------------------------------- Types ---------------------------------*/

typedef struct CudbgDevice_st *CudbgDevice;

/*-------------------------------- Structures -------------------------------*/

#define CUDBG_DEBUG_OBJECT_IS_VALID(o) ((o).wddm != CUDBG_INVALID_HANDLE)
typedef union {
    uint64_t wddm; // KMD debug object handle
    struct {
        uint32_t rm; // RM debug object handle
        uint32_t rmClient; // RM debug object's client handle
    };
    int32_t mrm; // MRM debug file descriptor
} DebugObject;

// NOTE:  HaloCRS_t is currently used on Fermi to Pascal.
// If we want to use it for Tesla, sizes may need to change */
typedef struct {
    // Store the number of CRS entries for each warp
    uint32_t numEntries;

    // Flattened CRS for each warp
    unsigned char *flatCRS;

    // CRS fields (maximum entries per warp)
    uint32_t *pc;       // Warp PC
    uint32_t *mask;     // Active mask
    uint8_t  *type;     // Token type
    uint8_t  *xsum;     // Checksum

    // Quick access to trap entries in this warp's CRS
    uint32_t trapIdx;    // Index of the CRS TRAP entry
    uint32_t disRetIdx;  // Index of the CRS DIS_RET entry
    uint32_t disContIdx; // Index of the CRS DIS_CONT entry
    uint32_t disBrkIdx;  // Index of the CRS DIS_BRK entry
    uint32_t disSyncIdx; // Index of the CRS DIS_SYNC entry
    uint32_t disLjmpIdx; // Index of the CRS DIS_LONGJMP entry
    uint32_t disExitIdx; // Index of the CRS DIS_EXIT entry
} HaloCRS_t;

// NOTE:  HaloLmemConfig_t is currently only used on Fermi.
typedef struct {
    uint32_t windowSize;
    uint32_t loSize;
    uint32_t hiSize;
    uint32_t CRSSize;
    uint32_t lmemHiOff;
} HaloLmemConfig_t;

typedef struct {
    uint32_t hwwglobalesr;
    uint32_t hwwwarpesr;
    uint32_t hwwglobalesrmask;
    uint32_t hwwwarpesrmask;
    uint64_t hwwwarpesrpc;
} CudbgSMESRState_t;

typedef struct {
    CudbgSMESRState_t esrState;
    CUwarpBitmask bpmask;
    CUwarpBitmask tidValid;
    CUwarpBitmask bptrapmask;
    // brokenwarps is used to strictly indicate which
    // warps on a given SM are at a breakpoint.
    CUwarpBitmask brokenwarps;
    // WAR Bug 1667975. Remember modified bpmask for this sm
    // during the preemption buffer save/restore.
    CUwarpBitmask preempt_bpmask;
    // WAR Bug 779607. Remember if a trap/exception was seen just after
    // stopping but before processing the bitmasks (see
    // fermi_rewindBrokenWarps).
    bool knownEvent;
    // Boolean to indicate if any warp on this SM has executed IDE.DIS
    bool inIDECS;
    // syscallwarps is used to indicate which warps have hit a trap on
    // a device side syscall. Currently, this is only used for assert
    CUwarpBitmask syscallwarps;

    // ESR PC and warp ID
    uint64_t esrWarpPC;
    uint32_t esrWarpId;
    // Set if ESR PC and ESR Warp ID are valid
    bool esrWarpInfoValid;

    // Set if the SM has hit an exception
    bool foundException;

    // SR_VirtId.SMId (SR3[20:28])
    uint32_t floorsweptSmId;
    bool floorsweptSmIdValid;

} CudbgSMState_t;

typedef struct CudbgWarp {
    // Outside collectGPUState valid is (sm[tpc][sm].tidValid >> tid) & 1, but
    // inside it is used to remember of previous state.
    int valid;

    // The %gridid of a warp
    uint64_t gridId64;

    // The PC
    uint64_t pc;

    // If an assertion has been hit, this is the user code jcal from which
    // _assertFail was called.
    uint64_t syscallEntryPc;

    // Virtual CTA ID (0-7) on a given SM
    uint32_t virtCTAID;

    // Shared Memory Size Per CTA
    uint32_t CTASharedSize;


    /* Lane information. */

    /* Each lane is either valid or not, and if valid may be active or
       diverged. So far all CUDA hardware has used 32-wide warps so we
       use simple 32-bit words for the masks */
    uint32_t validLanes;
    uint32_t activeMask;

    /* Cached blockIdx. */
    CuDim3 blockIdx;
    bool blockIdxValid;

    /* Various properties are heavily used, so we collect them all and
     * cache them here. This may be done on-demand in future. */
    CuDim3 threadIdx[CUDBG_MAX_LANE];

    /* Cached CRS data for each warp (Fermi only) */
    HaloCRS_t CRS;

    /* Cached lmem configuration for each warp (Fermi only) */
    HaloLmemConfig_t lmemConfig;

    /* Cached lane call depth */
    bool callDepthValid[CUDBG_MAX_LANE];
    uint32_t callDepth[CUDBG_MAX_LANE];

    /* Cached lane syscall depth */
    bool syscallCallDepthValid[CUDBG_MAX_LANE];
    uint32_t syscallCallDepth[CUDBG_MAX_LANE];

    /* Holds error reason, if any, for all lanes within a warp */
    CUDBGException_t laneExceptions[CUDBG_MAX_LANE];

    /* Holds lmem{Base,Seg,SegType} for this warp */
    uint64_t lmemBase;
    haloMemorySegmentType lmemSegType;
    haloMemorySegment *lmemSeg;

    /* Param constbank backing store dptr */
    uint64_t paramConstDptr;

    /* Pointer to this warp's cta context */
    uint64_t ctaContextAddr;

    /* The MPS context ID of the spawning context */
    uint32_t mpsContextId;

} CudbgWarp_t;

typedef struct CudbgSM {
    /* Track the validity of the cached state so collectGPUState can
       avoid wasting time collecting state from an unchanged SM. */
    int valid;
    CudbgSMState_t state;
    CudbgWarp_t warp[CUDBG_MAX_WARP];
} CudbgSM_t;

typedef enum {
    /* No contexts are preempted */
    CUDBG_PREEMPTION_STATE_NOT_PREEMPTED,

    /* All contexts have been CTA-level preempted */
    CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_CTA_PREEMPTED,

    /* One context has been CTA-level preempted, but ILP is still required */
    CUDBG_PREEMPTION_STATE_ILP_PENDING,

    /* All contexts have been preempted (CTA) by the controller.
       Only the controller can restore contexts in this state. */
    CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_CTA_PREEMPTED_BY_CONTROLLER,

    /* All contexts have been preempted (ILP) by the controller.
       Only the controller can restore contexts in this state. */
    CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_ILP_PREEMPTED_BY_CONTROLLER,

    /* All contexts have been preempted (CTA/ILP) and this was not
       done by the controller.  One context triggerred a GR exception
       and required ILP to evict it.  The controller cannot
       restore contexts in this state, only user commands have
       the ability to do so. */
    CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_PREEMPTED_FOR_DEVICE_EVENT,

    /* Invalid preemption state */
    CUDBG_PREEMPTION_STATE_INVALID,
} CudbgPreemptionState_t;

typedef struct {
    CuDim3 threadIdx;
    uint32_t valid;
} CudbgPreemptionLaneMappingTable_t;

typedef struct {
    CudbgPreemptionLaneMappingTable_t lane[CUDBG_MAX_LANE];
    uint32_t lastValidLane;
    uint32_t validLanes;
    uint64_t gridId;
    CuDim3 blockIdx;
} CudbgPreemptionWarpMappingTable_t;

typedef struct {
    CudbgPreemptionWarpMappingTable_t warp[CUDBG_MAX_WARP];
    CUwarpBitmask tidValid;
    CUwarpBitmask bpmask;
    CUwarpBitmask bptrapmask;
    CUwarpBitmask brokenwarps;
} CudbgPreemptionSMMappingTable_t;

typedef struct {
    CudbgPreemptionSMMappingTable_t sm[CUDBG_MAX_SMS];
} CudbgPreemptionMappingTable_t;

typedef enum {
    HALO_TYPE_DEBUGGER = 0x1,
    HALO_TYPE_MEMCHECK = 0x2,
    HALO_TYPE_UNIFIED_DEBUGGER = 0x3,
} HaloType_t;

/* Trap Handler service routine reason codes */
typedef enum {
    TH_SERVICE_NONE,
    TH_SERVICE_SHARED_MEM_READ,
    TH_SERVICE_SHARED_MEM_WRITE,
    TH_SERVICE_LRF_READ,
    TH_SERVICE_LRF_WRITE,
    TH_SERVICE_TEX_READ,
    TH_SERVICE_INVALID,
} HaloThService_t;

/* State of whether the memcheck is enabled or not */
typedef enum {
    HALO_MC_STATE_UNCHECKED,
    HALO_MC_STATE_ENABLED,
    HALO_MC_STATE_DISABLED
} HaloMCState_t;

/* Power gating state */
typedef enum {
    HALO_POWER_GATING_STATE_ENABLED = 0,
    HALO_POWER_GATING_STATE_DISABLED
} HaloPowerGatingState;

/* State saved for a breakpoint */
typedef struct {
    /* buffer for savedInstruction.  Size of instruction given by savedInstructionSize */
    uint64_t                         savedInstruction[2];
    uint64_t                         savedOpEx;
    /* Each architecture can have different instruction sizes (sometimes within the same architecture)
       This tells how large the instruction is in savedInstruction */
    uint32_t                         savedInstructionSize;
} BreakpointContents;

/* Debug object flags for read SM State */
typedef enum {
    HALO_DEBUG_OBJ_MODE_DEFAULT = 0,
    HALO_DEBUG_OBJ_MODE_IGNORE = 1,
    HALO_DEBUG_OBJ_MODE_FORCE  = 2,
} HaloDebugObjMode_t;

typedef struct {
    uint8_t    regOp;
    uint8_t    regType;
    uint8_t    regStatus;
    uint8_t    regQuad;
    uint32_t   regGroupMask;
    uint32_t   regSubGroupMask;
    uint32_t   regOffset;
    uint32_t   regValueHi;
    uint32_t   regValueLo;
    uint32_t   regAndNMaskHi;
    uint32_t   regAndNMaskLo;
} HaloRegOp;

/* valid regOp values */
typedef enum {
    HALO_REG_OP_READ_32 = 0,
    HALO_REG_OP_WRITE_32,
    HALO_REG_OP_READ_64,
    HALO_REG_OP_WRITE_64,
    HALO_REG_OP_READ_08,
    HALO_REG_OP_WRITE_08,
} HaloRegOpAccessType;

/* valid regType values */
typedef enum {
    HALO_REG_OP_TYPE_GLOBAL = 0,
    HALO_REG_OP_TYPE_GR_CTX,
    HALO_REG_OP_TYPE_GR_CTX_TPC,
    HALO_REG_OP_TYPE_GR_CTX_SM,
    HALO_REG_OP_TYPE_GR_CTX_CROP,
    HALO_REG_OP_TYPE_GR_CTX_ZROP,
    HALO_REG_OP_TYPE_FB,
    HALO_REG_OP_TYPE_GR_CTX_QUAD,
    HALO_REG_OP_TYPE_DEVICE,
} HaloRegOpType;

/* valid regStatus values */
typedef enum {
    HALO_REG_OP_STATUS_SUCCESS = 0,
    HALO_REG_OP_STATUS_INVALID_OP,
    HALO_REG_OP_STATUS_INVALID_TYPE,
    HALO_REG_OP_STATUS_INVALID_OFFSET,
    HALO_REG_OP_STATUS_UNSUPPORTED_OP,
    HALO_REG_OP_STATUS_INVALID_MASK,
    HALO_REG_OP_STATUS_UNKNOWN_ERROR,
} HaloRegOpStatus;

/* Save buffer states */
typedef enum {
    HALO_SAVE_BUFFER_STATE_NONE = 0,
    HALO_SAVE_BUFFER_STATE_CLEAN,
    HALO_SAVE_BUFFER_STATE_DIRTY,
} HaloSaveBufferState;

/* Memory access types */
typedef enum {
    HALO_MEMORY_ACCESS_TYPE_READ = 0,
    HALO_MEMORY_ACCESS_TYPE_WRITE,
} HaloMemoryAccessType;

typedef struct {
    uint64_t startVA;
    uint64_t endVA;
} HaloVARangeInfo;

typedef enum {
    HALO_DMAL_TYPE_RM = 0,
    HALO_DMAL_TYPE_WDDM_LEGACY,
    HALO_DMAL_TYPE_WDDM,
    HALO_DMAL_TYPE_MRM,
    HALO_DMAL_COUNT,
} HaloDmalType_t;

typedef enum {
    HALO_CACHE_FLUSH_FLAGS_NONE = 0,
    HALO_CACHE_FLUSH_FLAGS_CPU  = (1 << 0),
    HALO_CACHE_FLUSH_FLAGS_GPU  = (1 << 1),
} HaloCacheFlushFlags;

typedef enum {
    HALO_CACHE_FLUSH_INVALIDATE = 0,
    HALO_CACHE_FLUSH_WRITEBACK = 1,
} HaloCacheFlushOp;

typedef enum {
    HALO_PREEMPTION_TYPE_NONE,
    HALO_PREEMPTION_TYPE_KILP,
    HALO_PREEMPTION_TYPE_CILP,
} HaloPreemptionTypes;

typedef enum {
    HALO_MASK_PRI_INVALID = 0,
    HALO_MASK_PRI_WARP_VALID,
    HALO_MASK_PRI_BPT_PAUSE,
    HALO_MASK_PRI_BPT_TRAP,
} HaloMaskPRI;

typedef enum {
    HALO_PRI_INVALID = 0,
    HALO_PRI_SM_DBGR_CONTROL0,
    HALO_PRI_SM_DBGR_STATUS0,
    HALO_PRI_SM_HWW_WARP_ESR,
    HALO_PRI_SM_HWW_GLOBAL_ESR,
    HALO_PRI_L1C_HWW_ESR,
    HALO_PRI_L1C_HWW_ESR_ADDR,
    HALO_PRI_L1C_HWW_ESR_REQ,
    HALO_PRI_SM_CACHE_CONTROL,
    HALO_PRI_TPCCS_TPC_EXCEPTION,
    HALO_PRI_TPCCS_TPC_EXCEPTION_EN,
    HALO_PRI_PD_LMEM_SIZE_PER_SM,
    HALO_PRI_SM_BLCG_1_CG,
    HALO_PRI_SM_HWW_GLOBAL_ESR_REPORT_MASK
} HaloPRI;

typedef union {
    struct {
        bool initialized;
    } rm;

    struct {
        bool initialized;
    } mrm;

    struct {
        bool initialized;
    } wddm;
} HaloDmalGlobals;

typedef struct {
    bool dupRmHandles;
    bool hideWarpsInGlobalSyscalls;
    bool overrideInSyscallSPValue;
} HaloClientState;

struct HaloDmal_st {
    HaloDmalType_t type;

    HaloDmalGlobals globals;

    /* Priv Access */
    CUDBGResult (*initPrivAccess)       (CudbgDevice);
    CUDBGResult (*finalizePrivAccess)   (CudbgDevice);
    CUDBGResult (*readReg32)            (CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint32_t* value);
    CUDBGResult (*readReg64)            (CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint64_t* value);
    CUDBGResult (*writeReg32)           (CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint32_t* value);
    CUDBGResult (*writeReg64)           (CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint64_t* value);
    CUDBGResult (*execRegOps)           (CudbgDevice dev, Context context, HaloRegOp *script, int numOps);

    /* Memory */
    CUDBGResult (*mapMemory)    (Context, haloMemoryMap* map, uint64_t va, uint64_t size, char **hostPtr);
    CUDBGResult (*unmapMemory)  (CudbgDevice);
    CUDBGResult (*mapOneMemorySegment) (haloMemoryMap *map, haloMemorySegment *seg, uint64_t offset, uint64_t size);
    CUDBGResult (*unmapOneMemorySegment) (CudbgDevice dev, haloMemorySegment *seg);
    CUDBGResult (*readBar1Size) (CudbgDevice dev, uint64_t *bar1Size);
    CUDBGResult (*getHostAddrFromDevicePtr) (Context, uint64_t dva, uint64_t *hva);
    CUDBGResult (*destroyHandleForMemorySegment) (CudbgDevice dev, uint32_t handle);
    CUDBGResult (*createHandleForMemorySegment) (CudbgDevice dev, int32_t parentFd, uint32_t *newHandle);
    CUDBGResult (*readServiceRoutineData) (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint64_t offset, void *buf, uint32_t bufSz);

    /* Events */
    CUDBGResult (*clearEvent)             (CudbgDevice dev, Context ctx);
    CUDBGResult (*freeDeviceEvent)        (CudbgDevice dev);
    CUDBGResult (*allocateDeviceEvent)    (CudbgDevice dev, const CUdev* pDev);
    CUDBGResult (*setWatchdogTimeout)     (CudbgDevice dev, uint32_t timeout, uint32_t interval);
    CUDBGResult (*getEventListForDevice)  (CudbgDevice dev, cuosEvent **eventList, Context *contextList, int *numEvents, int listSize);
    CUDBGResult (*forceCacheCoherence)    (CudbgDevice dev);
    CUDBGResult (*setGlobalChannelTimeout)(DebugObject debugObj, bool enable);

    /* Device */
    CUDBGResult (*setRMDebugMode)               (CudbgDevice dev, bool on);
    CUDBGResult (*setPowerGatingState)          (CudbgDevice, HaloPowerGatingState state);
    CUDBGResult (*setChannelGroupTimeslice)     (CudbgDevice dev, uint32_t rmChannelGropu, uint64_t usec);
    CUDBGResult (*enableOrDisableChannelGroup)  (CudbgDevice dev, uint32_t rmChannelGroup, uint32_t hAppClient, bool bEnable);
    CUDBGResult (*preemptChannelGroup)          (CudbgDevice dev, uint32_t rmChannelGroup, uint32_t hAppClient, bool *preemptTimedOut, uint64_t timeoutUs);

    /* Debug Object */
    CUDBGResult (*debugObjectAlloc)                    (Context ctx, uint32_t hAppClient, uint32_t hComputeObject, DebugObject *debugObj);
    CUDBGResult (*debugObjectFree)                     (Context ctx, DebugObject *debugObj, uint32_t *hComputeObject);
    CUDBGResult (*debugObjectAllocEvent)              (CudbgDevice dev, DebugObject debugObj, uint32_t eventClassType, cuosEvent *event, uint32_t *dbgEvent);
    CUDBGResult (*debugObjectFreeEvent)               (CudbgDevice dev, DebugObject debugObj, cuosEvent *event, uint32_t  dbgEvent);

    CUDBGResult (*debugObjectPauseGrCtxSwitch)         (CudbgDevice dev);
    CUDBGResult (*debugObjectResumeGrCtxSwitch)        (CudbgDevice dev);
    CUDBGResult (*debugObjectGetResidentChannelHandle) (CudbgDevice dev, DebugObject debugObj, uint32_t *hChannel);
    CUDBGResult (*debugObjectClearSMESRInfo)           (CudbgDevice dev, DebugObject debugObj, uint32_t vsm, CudbgSMESRState_t *esrState);
    CUDBGResult (*debugObjectReadSMESRInfo)            (CudbgDevice dev, DebugObject debugObj, uint32_t vsm, CudbgSMESRState_t *esrState);
    CUDBGResult (*debugObjectSetMMUDebugMode)          (Context ctx, bool on);
    CUDBGResult (*debugObjectSuspendContext)           (Context ctx, bool *waitForEvent);
    CUDBGResult (*debugObjectSuspendDevice)            (CudbgDevice dev, uint32_t *hasStopped, uint32_t *waitForEvent, Context *residentContext);
    CUDBGResult (*debugObjectResumeContext)            (Context ctx);
    CUDBGResult (*debugObjectResumeDevice)             (CudbgDevice dev, uint32_t *hasResumed);
    CUDBGResult (*debugObjectGetVARanges)              (Context ctx, uint64_t startVA, uint64_t endVA, HaloVARangeInfo ranges[], uint32_t length, uint32_t *numRanges);
    CUDBGResult (*debugObjectAccessMemory)             (Context ctx, uint64_t devvaddr, void *buf, uint64_t length, HaloMemoryAccessType accessType);
    CUDBGResult (*debugObjectSetNextStopTriggerType)   (CudbgDevice dev, DebugObject debugObj, uint32_t val);
    CUDBGResult (*initDeviceDebugInterface)            (CudbgDevice dev);
    CUDBGResult (*destroyDeviceDebugInterface)         (CudbgDevice dev);

    /* Profiler Object */
    CUDBGResult (*initDeviceProfilerInterface)         (CudbgDevice dev);
    CUDBGResult (*profilerObjectSetBLCG)               (CudbgDevice dev, uint32_t on, uint32_t acquire);
    CUDBGResult (*destroyDeviceProfilerInterface)      (CudbgDevice dev);

    /* Capability tests for debug object functionality */
    bool (*debugObjectIsStable)                     (void);
    bool (*debugObjectCanSuspend)                   (void);
    bool (*debugObjectCanResume)                    (void);
    bool (*debugObjectCanReadESR)                   (void);
    bool (*debugObjectCanClearESR)                  (void);
    bool (*debugObjectCanGetVARanges)               (void);
    bool (*debugObjectCanAccessMemory)              (void);
    bool (*debugObjectCanSetMMUDebugMode)           (void);
    bool (*debugObjectHasPerContextEvents)          (void);
    bool (*debugObjectHasPerContextSuspendResume)   (void);
    bool (*debugObjectCanBeAllocatedInProcess)      (void);

    /* Capability tests for profiler object functionality */
    bool (*profilerObjectCanClockGate)      (void);

    /* CPU Cache Op */
    CUDBGResult (*flushCpuMappingForDevvaddr) (Context ctx, uint64_t devvaddr, uint64_t size, HaloCacheFlushOp op);

    /* GPU Cache Op */
    CUDBGResult (*flushGpuWrites) (CudbgDevice dev);
};

struct HaloScratchpadAccessor_st {
    void *userState;

    CUDBGResult (*getField)(HaloScratchpadAccessor accessor, HaloScratchpadField field,
                            HaloScratchpadSection section, uint32_t sm,
                            uint32_t wp, uint32_t ln, void *value, size_t size);
    CUDBGResult (*setField)(HaloScratchpadAccessor accessor, HaloScratchpadField field,
                            HaloScratchpadSection section, uint32_t sm,
                            uint32_t wp, uint32_t ln, void *value, size_t size);
};

struct HaloPreemptionBufferAccessor_st {
    void *userState;

    CUDBGResult (*getField)(HaloPreemptionBufferAccessor accessor, HaloPreemptionBufferField field,
                            HaloPreemptionBufferSection section, uint32_t sm, uint32_t cta,
                            uint32_t wp, uint32_t ln, void *value, size_t size);
    CUDBGResult (*setField)(HaloPreemptionBufferAccessor accessor, HaloPreemptionBufferField field,
                            HaloPreemptionBufferSection section, uint32_t sm, uint32_t cta,
                            uint32_t wp, uint32_t ln, void *value, size_t size);
};

struct HaloClient_st {
    // Client state
    HaloClientState                      state;

    // Client functions
    CUDBGResult (*clientInit)            (CudbgDevice);
    CUDBGResult (*mapMemory)             (Context, uint64_t va, uint64_t size, char **hostPtr);

    CUDBGResult (*unmapMemory)           (CudbgDevice);
    CUDBGResult (*finalizePrivAccess)    (CudbgDevice);
    CUDBGResult (*initPrivAccess)        (CudbgDevice);
    CUDBGResult (*readBar1Size)          (CudbgDevice, uint64_t *bar1Size);

    /* Register Ops */
    CUDBGResult (*readReg32)             (CudbgDevice, HaloRegOpType regType, volatile char* addr, uint32_t* value);
    CUDBGResult (*readReg64)             (CudbgDevice, HaloRegOpType regType, volatile char* addr, uint64_t* value);
    CUDBGResult (*writeReg32)            (CudbgDevice, HaloRegOpType regType, volatile char* addr, uint32_t* value);
    CUDBGResult (*writeReg64)            (CudbgDevice, HaloRegOpType regType, volatile char* addr, uint64_t* value);

    /* Device init/finalization callbacks */
    CUDBGResult (*deviceDestroyPreHook)    (CudbgDevice);
    CUDBGResult (*deviceDestroyPostHook)   (CudbgDevice);
    CUDBGResult (*deviceInitPreHook)       (CudbgDevice);
    CUDBGResult (*deviceInitPostHook)      (CudbgDevice);

    /* Init Ops */
    CUDBGResult (*preInit)               (void);
    CUDBGResult (*initPerDevice)         (uint32_t devId, CudbgDevice dev, HaloClient);

    /* Required for CNP*/
    CUDBGResult (*createDynamicGrid) (CudbgDevice dev, uint32_t sm, uint32_t wp,
                                      uint32_t ln, uint64_t gridId64,
                                      uint64_t physPC, CuDim3 gridDim,
                                      CuDim3 blockDim, bool *isPostable);
    CUDBGResult (*updateUnpostedDynamicGrid) (CudbgDevice dev, uint32_t sm, uint32_t wp,
                                              uint32_t ln, Grid *grid,
                                              uint64_t physPC, bool *isPostable);
    CUDBGResult (*postGridEvent)        (CudbgDevice dev, Context context,
                                         Grid grid, DeviceFunction function);
    CUDBGResult (*inTrapRegion)         (CudbgDevice dev, uint64_t physPC, DebugPatch *patch, bool *found);
    CUDBGResult (*inGlobalSyscallPatch) (CudbgDevice dev, uint64_t physPC, DebugPatch *patch, bool *found);

    /* Required for assert */
    CUDBGResult (*inSyscallPatch)       (CudbgDevice dev, uint64_t physPC, DebugPatch *patch, bool *found);

    /* For Membar WAR */
    CUDBGResult (*inMembarWARPatch)     (CudbgDevice dev, uint64_t physPC, DebugPatch *patch, bool *found);

    /* Instruction-level preemption */
    CUDBGResult (*initiateChannelGroupPreemptSave)    (CudbgDevice dev, bool *allPreemptSaved, bool *ctaPreemptionTriggered);
    CUDBGResult (*initiateChannelGroupPreemptRestore) (CudbgDevice dev, bool *allPreemptRestored);

    /* Required for memcheck */
    CUDBGResult (*inMemcheckPatch)      (CudbgDevice dev, uint64_t physPC, bool *found);

    /* Allow the client to perform warp hiding. This is mainly for memcheck + MPS */
    CUDBGResult (*forceWarpHiding)    (CudbgDevice dev, uint32_t sm, uint32_t wp, bool *hideWarp);

    /* Determine the exception from the magic lmem value */
    CUDBGResult (*getExceptionFromMagic) (CudbgDevice dev, uint32_t magic,
                                          CUDBGException_t *exception);

    /* Check if this is in the patch ram allocated per context for the unified debugger */
    CUDBGResult (*inUnifiedDebuggerPatch)      (CudbgDevice dev, uint64_t pc, bool *inPatch);

    /* Attmempts to find a pc in user space for this physical pc. Used by Unified debugger to map PPA PCs*/
    CUDBGResult (*getUnifiedDebuggerPatchPC)(CudbgDevice dev, uint64_t ctx, uint64_t physicalPc, uint64_t *userPc);
};

typedef struct Halo_st {
    /* Device info - semantically constant, init-once */
    struct HaloDeviceInfo_st {
        /* Basic device configuration, first the logical view */
        bool     smVirtualized;
        uint32_t numSMsPrTPC;         /* Should be 1 if smVirtualized is not enabled,
                                      otherwise the number of virtualized sms on
                                      the physical tpc */
        uint32_t numSMs;
        uint32_t numWarpsPrSM;
        uint32_t numWarpsPrTPC;
        uint32_t numLanesPrWarp;      // Always 32
        uint32_t numRegsPrLane;
        uint32_t numPredicatesPrLane; // Predicate registers start with Fermi
        uint32_t numUniformRegsPrWarp;
        uint32_t numUniformPredicatesPrWarp;

        /* Basic device configuration, the hardware view */

        // Fermi
        uint32_t numGPCsPrDevice;
        // Fermi architectural chip limits
        uint32_t maxGPCsPrDevice;

        uint32_t bpt32Inst;
        uint64_t bpt64Inst;

        /* We virtualize SM ids such that the SMs are named 0 .. n-1, with
         * n being the number of actual (floorswept) SMs. Besides
         * floorsweeping it also saves us from explicitly naming the TPC
         * (and GPC on Fermi).
         *
         * For Tesla we need need both the physical TPC id (tpcMap) and
         * the virtual TPC id (vtpcMap), where the latter is simply an
         * enumeration of the non-floorswept TPCs. Local memory and CRS
         * stack uses that.
         *
         * XXX In the transition period we have both schemes in place, so
         * to avoid confusion, we will use "vsm" internally.
         */
        uint32_t vsmMap[CUDBG_MAX_TPC][CUDBG_MAX_SM];  // (tpc,sm) -> vsm
        uint32_t smMap[CUDBG_MAX_SMS];                 // vsm -> sm   Not used on Fermi
        uint32_t tpcMap[CUDBG_MAX_SMS];                 // vsm -> tpc
        uint32_t vtpcMap[CUDBG_MAX_SMS];                // vsm -> vtpc (Not used on Fermi)
        uint32_t gpcMap[CUDBG_MAX_SMS];                 // vsm -> gpc  Not used on Tesla

        int useRegOps;
        HaloPreemptionTypes preemptionType;
        
        /* architectural constants - always init after base chip init */
        uint32_t    spRegisterNumber;
        uint32_t    systemStackPointer;
        uint32_t    lmemSavedReturnPC;
        uint32_t    lmemSavedMExited;
        uint32_t    rpcRegisterNumber;
        uint64_t    cilpBufferSizePerSM;
        uint64_t    scratchpadSize;
        uint32_t    lmemHiMemcheckScratch;
        uint32_t    lmemHiMemcheckScratchSize;
        uint32_t    lmemMemcheckMagic;
        uint32_t    lmemHiMembarWarSpillR0;
        uint32_t    lmemHiMembarWarSpillR2;
        uint32_t    lmemHiMembarWarSpillR3;
    } deviceInfo;

    /* methods */
    CUDBGResult (*deviceInitialize)   (CudbgDevice, uint32_t dev);
    CUDBGResult (*deviceFinalize)     (CudbgDevice);
    CUDBGResult (*getInfo)            (CudbgDevice);
    CUDBGResult (*mapGpcTpcSm)        (CudbgDevice);
    CUDBGResult (*clearEvent)         (CudbgDevice, Context);

    CUDBGResult (*singleStep)         (CudbgDevice, uint32_t vsm, int on);
    CUDBGResult (*singleStepExit)     (CudbgDevice, uint32_t vsm, uint32_t wp);
    CUDBGResult (*readSMState)        (CudbgDevice, uint32_t vsm, CudbgSMState_t *state);
    CUDBGResult (*invalidateSMState)  (CudbgDevice, uint32_t vsm);

    CUDBGResult (*readSMWarpMasks)    (CudbgDevice, uint32_t vsm, CudbgSMState_t *state);
    CUDBGResult (*readSMWarpESRInfo)  (CudbgDevice, uint32_t vsm, CudbgSMState_t *state);
    CUDBGResult (*readSMESRInfo)      (CudbgDevice dev, uint32_t vsm, CudbgSMState_t *state, HaloDebugObjMode_t debugObjMode);
    CUDBGResult (*clearSMESRInfo)     (CudbgDevice dev, uint32_t vsm, CudbgSMState_t *state, HaloDebugObjMode_t debugObjMode);
    CUDBGResult (*updateSMESRInfo)    (CudbgDevice dev, uint32_t vsm, uint32_t wp, CudbgSMState_t *state, uint64_t warpPc);
    CUDBGResult (*setKnownEvent)      (CudbgDevice dev, CudbgSMState_t *state);
    CUDBGResult (*handleGlobalErrorState) (CudbgDevice, uint32_t vsm,
                                           uint32_t wp, uint32_t gESR,
                                           CUDBGException_t *laneException,
                                           bool *error);
    CUDBGResult (*handleGlobalMMUErrorState) (CudbgDevice, uint32_t vsm,
                                              uint32_t wp,
                                              CUDBGException_t *laneException,
                                              bool *error);
    CUDBGResult (*handleWarpErrorState) (CudbgDevice, uint32_t vsm, uint32_t wp,
                                         uint32_t gESR,
                                         CUDBGException_t *laneException,
                                         bool *error);
    CUDBGResult (*writeBreakpointMask)(CudbgDevice, uint32_t vsm, CUwarpBitmask *mask);
    CUDBGResult (*readPC)             (CudbgDevice, uint32_t vsm, uint32_t tid, uint64_t *pc);
    CUDBGResult (*writePC)            (CudbgDevice, uint32_t vsm, uint32_t tid, uint64_t pc);
    CUDBGResult (*readActiveMask)     (CudbgDevice, uint32_t vsm, uint32_t tid, uint32_t *mask);
    CUDBGResult (*adjustActiveMask)   (CudbgDevice, uint32_t vsm, uint32_t tid, uint32_t *mask);
    CUDBGResult (*getLmemInternalOffset)
    (CudbgDevice, uint32_t address,
     uint32_t vsm,
     uint32_t tid, uint32_t lane, uint32_t *offset);
    CUDBGResult (*getCRSInternalOffset)
    (CudbgDevice, uint32_t address, uint32_t vsm, uint32_t tid, uint32_t *offset);
    CUDBGResult (*readLmemConfig)     (CudbgDevice, uint32_t vsm);
    CUDBGResult (*collectWarpCRS)     (CudbgDevice, uint32_t vsm, uint32_t tid);
    CUDBGResult (*flattenCRS)         (CudbgDevice, uint32_t vsm, uint32_t tid, unsigned char *flatCRS);
    CUDBGResult (*updateCRS)          (CudbgDevice, uint32_t vsm, uint32_t tid, unsigned char *flatCRS, uint32_t trapIdx);
    CUDBGResult (*CRSEntrySize)       (CudbgDevice, uint32_t *size);
    CUDBGResult (*CRSEntryPaddingSize)(CudbgDevice, uint32_t *size);
    CUDBGResult (*maxCRSEntriesPerWarp)
    (CudbgDevice, uint32_t vsm, uint32_t tid, uint32_t *numEntries);
    CUDBGResult (*getWarpCRSUsage)    (CudbgDevice, uint32_t vsm, uint32_t tid, uint32_t *warpCRSNumEntries, uint32_t *warpCRSSize, bool *usingCRSPtr);
    CUDBGResult (*findDivergedCRS_Entry)
    (CudbgDevice, uint32_t vsm, uint32_t tid, uint32_t lane, bool *res);
    CUDBGResult (*findDivergedCRS_Mask)
    (CudbgDevice, uint32_t vsm, uint32_t tid, uint32_t *mask);
    CUDBGResult (*findDivergedCRS_PC) (CudbgDevice, uint32_t vsm, uint32_t tid, uint32_t lane, uint64_t *pc);
    CUDBGResult (*lookForActiveContext)
    (Context,     CudbgDevice dev);
    CUDBGResult (*findActiveContext)  (CudbgDevice, bool singleStepping);
    CUDBGResult (*read_threadIdx)     (CudbgDevice,
                                       uint32_t vsm,
                                       uint32_t tid, uint32_t lane,
                                       uint32_t threadBlockDimZ,
                                       uint32_t *thrX,
                                       uint32_t *thrY,
                                       uint32_t *thrZ);
    CUDBGResult (*read_warpParams)    (CudbgDevice,
                                       uint32_t vsm,
                                       uint32_t wp,
                                       uint32_t valid,
                                       uint32_t *virtCTAID,
                                       uint32_t *CTASharedSize,
                                       uint32_t *floorsweptSmId);
    CUDBGResult (*read_blockIdx)      (CudbgDevice, uint32_t vsm, uint32_t tid, CuDim3*);
    CUDBGResult (*isSteppable)        (CudbgDevice, uint32_t vsm, uint32_t wp, uint64_t pc,
                                       bool inPatch, uint64_t *breakAddr,
                                       CUwarpBitmask *breakMask, bool *isSteppable,
                                       bool *requiresExitStep);
    CUDBGResult (*contextCommonDataCacheOp) (Context, HaloMemorySegmentCacheOp);
    CUDBGResult (*isInternalInstructionAtPC)
    (CudbgDevice, uint64_t inst, uint64_t gpuAddr, bool *isInternalInstruction);
    CUDBGResult (*readAndResetContextActiveBit)
    (Context, CudbgDevice dev, bool *isContextActive);

    CUDBGResult (*setWarpStateValid) (CudbgDevice, uint32_t vsm, uint32_t wp);
    CUDBGResult (*getCCMasks) (CudbgDevice, uint32_t *ccShift, uint32_t *ccBitmask);
    /*
       New generation entry points below. These are intended to be
       invoked directly from the api implementation.

       Entries prefixed with underscore shouldn't be used outside Halo.
    */

    /* Execution */
    CUDBGResult (*suspendDevice)       (CudbgDevice, uint32_t *, uint32_t *, Context *residentContext);
    CUDBGResult (*resumeDevice)        (CudbgDevice, uint32_t *hasResumed, uint32_t skipResume);
    CUDBGResult (*resumeDeviceViaPRIV) (CudbgDevice, uint32_t *);

    CUDBGResult (*suspendSM)          (CudbgDevice, uint32_t vsm);
    CUDBGResult (*resumeSM)           (CudbgDevice, uint32_t vsm);

    CUDBGResult (*resumeWarps)        (CudbgDevice, uint32_t vsm, CUwarpBitmask *warpMask, uint32_t *);

    CUDBGResult (*waitForSMPause)     (CudbgDevice, uint32_t vsm);

    CUDBGResult (*setPreemptCommand)  (Context, uint32_t cmd);

    /* After calling preemptPreHook, all state information from the gpu should
       be available for the debugger to read */
    CUDBGResult (*preemptPreHook)     (CudbgDevice, int32_t vsm);
    /* After calling preemptPostHook, all state information modified by the
       debugger should be pushed to the gpu, as the gpu will use this as
       it's new state information */
    CUDBGResult (*preemptPostHook)    (CudbgDevice, int32_t vsm);

    /* Inspection */
    CUDBGResult (*readWarpMaskPRI)  (CudbgDevice, uint32_t vsm, HaloRegOpType type, HaloMaskPRI pri, CUwarpBitmask *mask);
    CUDBGResult (*readPinnedMemory) (CudbgDevice, uint64_t hostvaddr,                                      void *buf, uint32_t bufSz);
    CUDBGResult (*readCodeMemory)   (Context,                                             uint64_t offset, void *buf, uint32_t bufSz);
    CUDBGResult (*readSharedMemory) (CudbgDevice, uint32_t vsm, uint32_t wp,              uint64_t offset, void *buf, uint32_t bufSz);
    CUDBGResult (*readParamMemory)  (CudbgDevice, uint32_t vsm, uint32_t wp,              uint64_t offset, void *buf, uint32_t bufSz);

    /* Set ln = HALO_LOCAL_MEMORY_ACCESS_FOR_ALL_LANES to read for all lanes */
    CUDBGResult (*readLocalMemory)  (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint64_t offset, void *buf, uint32_t bufSz);

    CUDBGResult (*readLocalMemoryCacheAware)  (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint64_t offset, void *buf, uint32_t bufSz, HaloCacheFlushFlags cacheFlushFlags);
    CUDBGResult (*getRegisterCount) (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t *numRegsUsedByKernel);
    CUDBGResult (*readRegisterRange) (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t firstRegnum, uint32_t *registers, uint32_t numRegs, bool rawSpValue);
    CUDBGResult (*readUniformRegisterFile) (CudbgDevice, uint32_t vsm, uint32_t wp, uint64_t offset, void *buf, uint32_t bufSz);
    CUDBGResult (*readPredicates)   (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t numPreds, uint32_t *predicates);
    CUDBGResult (*readUniformPredicates) (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t numPreds, uint32_t *predicates);
    CUDBGResult (*readCCRegister)   (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t *cc);
    CUDBGResult (*readCallDepth)    (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t *depth);
    CUDBGResult (*readSyscallCallDepth)    (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t *depth);
    CUDBGResult (*readReturnAddress)(CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t level, uint64_t *ra);
    CUDBGResult (*readTextureMemory)(CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t id, uint32_t dim, uint32_t *coords, void *buf, uint32_t bufSz);
    CUDBGResult (*readTextureMemoryUsingTexHeader)(CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t id, uint32_t dim, uint32_t *coords, void *buf, uint32_t bufSz);
    CUDBGResult (*patchTextureInstruction)  (CudbgDevice dev, uint32_t texId, uint32_t dim, uint32_t *coords, Grid grid);
    CUDBGResult (*getLmemOffsetForTexCoords)(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t *offset);
    CUDBGResult (*getPauseReasonTableWarpOffset)(CudbgDevice dev, uint32_t vsm, uint32_t warp, uint32_t *offset);
    CUDBGResult (*readGenericMemory) (Context    , uint32_t vsm, uint32_t wp, uint32_t ln, uint64_t vaddr,  void *buf, uint32_t bufSz);
    CUDBGResult (*readDeviceMemory)  (Context, uint64_t vaddr, void *buf, uint32_t bufSz);
    CUDBGResult (*isTerminalInstructionAtPC) (Context, uint64_t pc, bool *instructionCanExit);
    CUDBGResult (*getWarpMaskPRIOffset) (CudbgDevice dev, HaloMaskPRI pri, uint32_t wordIndex, uint32_t *reg);
    CUDBGResult (*convertPhysicalToVirtual)  (struct Halo_st *halo, uint32_t tpc, uint32_t phys_wp, uint32_t cta_id, uint32_t* vsm, uint32_t* vwp, uint32_t* vcta_id);
    CUDBGResult (*convertVirtualToPhysical)  (struct Halo_st *halo, uint32_t vsm, uint32_t vwp, uint32_t vcta_id, uint32_t* tpc, uint32_t* phys_wp, uint32_t* cta_id);
    CUDBGResult (*forceScratchpadLmemBase) (CudbgDevice dev, bool *useScratchpad);
    CUDBGResult (*getNumRegistersForGrid) (Context context, Grid grid, uint32_t *numRegs);
    CUDBGResult (*needsProfilerObject) (CudbgDevice dev, bool *needsProfilerObject);
    CUDBGResult (*getFloorsweptSmIdFromSubcontext)(CudbgDevice dev, uint32_t subcontextSmId, uint32_t *floorsweptSmId);

    /* Alteration */
    CUDBGResult (*writeWarpMaskPRI)  (CudbgDevice, uint32_t vsm, HaloRegOpType type, HaloMaskPRI pri, CUwarpBitmask *mask);
    CUDBGResult (*writePinnedMemory)(CudbgDevice, uint64_t hostvaddr,                                      const void *buf, uint32_t bufSz);
    CUDBGResult (*writeCodeMemory)  (Context,                                                 uint64_t offset, const void *buf, uint32_t bufSz);
    CUDBGResult (*writeSharedMemory)(CudbgDevice, uint32_t vsm, uint32_t wp,              uint64_t offset, const void *buf, uint32_t bufSz);
    CUDBGResult (*writeParamMemory) (CudbgDevice, uint32_t vsm, uint32_t wp,              uint64_t offset, const void *buf, uint32_t bufSz);
    CUDBGResult (*writeLocalMemory) (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint64_t offset, const void *buf, uint32_t bufSz);
    CUDBGResult (*writeRegisterFile)(CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint64_t offset, const void *buf, uint32_t bufSz);
    CUDBGResult (*writeUniformRegisterFile)(CudbgDevice, uint32_t vsm, uint32_t wp, uint64_t offset, const void *buf, uint32_t bufSz);
    CUDBGResult (*writePredicates)  (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t numPreds, const uint32_t *predicates);
    CUDBGResult (*writeUniformPredicates)  (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t numPreds, const uint32_t *predicates);
    CUDBGResult (*writeCCRegister)  (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, const uint32_t cc);
    CUDBGResult (*writeGenericMemory)(Context,         uint32_t vsm, uint32_t wp, uint32_t ln, uint64_t vaddr,  const void *buf, uint32_t bufSz);
    CUDBGResult (*writeDeviceMemory)(Context, uint64_t vaddr, const void *buf, uint32_t bufSz);

    CUDBGResult (*getScratchpadSharedMemDevVaddr)(Context context, uint64_t *shmemDevVaddr);

    CUDBGResult (*enableMMUDebuggingMode)   (Context);
    CUDBGResult (*disableMMUDebuggingMode)  (Context);
    CUDBGResult (*disableMMUDebuggingModeForDevice) (CudbgDevice);
    CUDBGResult (*enablePairingMode)        (CudbgDevice, Context context);
    CUDBGResult (*disablePairingMode)       (CudbgDevice, Context context);

    /* Forcefully terminate anything running on the device. */
    CUDBGResult (*forceTermination)         (CudbgDevice);
    CUDBGResult (*fillRangeWithInstruction) (Context, uint64_t startvaddr, uint64_t endvaddr, uint64_t inst);

    /* Return the instruction size in bytes */
    CUDBGResult (*getInstructionSize)       (uint64_t instruction, uint32_t *instSize);
    CUDBGResult (*fillDisassemblyBuffer)    (Context, uint64_t gpuAddr, uint64_t inst[2], uint64_t *instBuf, uint32_t instBufSize, uint32_t *instBufWrittenSize);

    /* Rewind a given (broken) warp's PC to just before the breakpoint instruction */
    CUDBGResult (*rewindBrokenWarp)         (Context, uint32_t vsm, uint32_t wp);

    /* Insert/remove/find breakpoints */
    CUDBGResult (*findBreakpoint)           (Context ctx, uint64_t paddr, Breakpoint *bp);
    CUDBGResult (*insertBreakpoint)         (Context, uint64_t vaddr, BreakpointContents *buf);
    CUDBGResult (*removeBreakpoint)         (Context, uint64_t vaddr, const BreakpointContents *buf);
    CUDBGResult (*adjustCodeAddress)        (uint64_t physaddr, uint64_t *adjustedPhysAddr, CUDBGAdjAddrAction adjAction);

    /* Cleanup function to clear out any architecture-specific state */
    CUDBGResult (*cleanup)                  (CudbgDevice);

    /* Check if a warp is currently waiting on a barrier */
    CUDBGResult (*isWarpOnBarrier)          (CudbgDevice, uint32_t vsm, uint32_t wp, bool *isWarpOnBarrier);

    /* Return the mask of warps which need to be stepped prior to resuming from a breakpoint */
    CUDBGResult (*getStepOverBPMask)        (CudbgDevice, uint32_t vsm, CUwarpBitmask *mask);

    /* Check for stack pointer assignment instruction */
    CUDBGResult (*isStackPointerAssignment) (uint64_t instruction[2], int32_t *res, uint32_t *assignmentIdx);
    CUDBGResult (*isStackPointerAdjustment) (uint64_t instruction[2], bool *isAdjustment, int32_t *adjustment);

    /* Texture support */
    CUDBGResult (*findConstBankOffset)      (CudbgDevice, DeviceFunction func, uint32_t tid, uint64_t *constBankOffset);

    /* Examine/clear exception tree (Fermi and beyond) */
    CUDBGResult (*clearExceptions)          (CudbgDevice, uint32_t vsm);
    CUDBGResult (*isAnyExceptionSet)        (CudbgDevice, bool *anyExceptionSet);

    /* Interface with paused serviced mask (GK110+) */
    CUDBGResult (*writePauseServicedMask)   (CudbgDevice, bool full_resume, uint32_t vsm);
    CUDBGResult (*readPauseServicedMask)    (struct Halo_st *halo, HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, CUwarpBitmask *pauseServicedMask);

    /* Trap handler service routine and post processing */
    CUDBGResult (*thService)                (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t addr, uint32_t sz, HaloThService_t reason);
    CUDBGResult (*thServicePostProcess)     (CudbgDevice, uint32_t vsm);

    CUDBGResult (*invalidateICache)         (CudbgDevice);

    /* Migration from the target layer */
    CUDBGResult (*collectDeviceState)       (CudbgDevice, bool singleStepping, CUwarpBitmask *rewindWarpMasks);
    CUDBGResult (*collectContext)           (CudbgDevice, bool singleStepping);
    CUDBGResult (*clearSMState)             (CudbgDevice);
    CUDBGResult (*clearWarpState)           (CudbgDevice, uint32_t vsm, uint32_t wp);

    /* Shared routines for memcheck */
    CUDBGResult (*mcinterop_getRegSpill)      (CudbgDevice, uint32_t *numSpilled);
    CUDBGResult (*mcinterop_getPatchPC)       (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint64_t *pc);
    CUDBGResult (*mcinterop_getPatchReg)      (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t regno, uint32_t *hasSpilled, uint32_t *regval);
    CUDBGResult (*mcinterop_getPatchPred)     (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t numPreds, uint32_t *predicates);
    CUDBGResult (*mcinterop_getPatchCC)       (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t *cc);
    CUDBGResult (*mcinterop_setPatchReg)      (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t regno, uint32_t *hasSpilled, const uint32_t *regval);
    CUDBGResult (*mcinterop_setPatchPred)     (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t numPreds, const uint32_t *predicates);
    CUDBGResult (*mcinterop_setPatchCC)       (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, const uint32_t cc);
    CUDBGResult (*mcinterop_getLDSTTargetAddr)    (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint64_t *pc, ptxStorageKind *storage);
    CUDBGResult (*mcinterop_getSyscallError)        (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t *syscallError);
    CUDBGResult (*mcinterop_getSyscallErrorData)    (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint64_t *syscallPC, uint64_t *syscallLen);
    CUDBGResult (*mcinterop_checkLane)        (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t magic, CUDBGException_t *exception);
    CUDBGResult (*mcinterop_memcheckEnabled)  (CudbgDevice, uint32_t *enabled);

    /* CNP-related items */
    CUDBGResult (*getCrsPhysStackDepth)     (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t *curPhysStackDepth);

    /* Find the LMEM address where the user stack pointer is saved */
    CUDBGResult (*getSavedSPLmemAddr)       (CudbgDevice, uint64_t *lmem_addr);

    /* Find entry point into syscall code if within a syscall */
    CUDBGResult (*findSyscallEntryPoint)    (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint64_t *entryPc);

    CUDBGResult (*readLaneServiceReason)                (CudbgDevice, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t *serviceReason);
    CUDBGResult (*thServiceWriteInfo)                   (CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t addr, uint32_t sz, HaloThService_t reason);

    /* Power gating state */
    CUDBGResult (*setPowerGatingState)                  (CudbgDevice, HaloPowerGatingState state);

    CUDBGResult (*isLastHwStepSynchronous)              (CudbgDevice, bool *isLastHwStepSynchronous);

#ifdef CUDBG_ENABLE_IFB
    CUDBGResult (*allocateIFB)      (CudbgDevice, uint32_t devHandle, uint32_t subDevHandle, uint32_t rmGpuId);
    CUDBGResult (*readViaIFB)       (CudbgDevice, uint32_t offset, uint32_t *data);
    CUDBGResult (*writeViaIFB)      (CudbgDevice, uint32_t offset, uint32_t data);
#endif

    CUDBGResult (*getGridStatus) (CudbgDevice dev, uint64_t gridId64, CUDBGGridStatus *status);
    CUDBGResult (*findSyscallSP) (CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln, bool *inSyscall, uint32_t *spval);

    /* Additions for the MEMBAR patching WAR */
    CUDBGResult (*membarWAR_getPatchPC) (CudbgDevice dev, uint32_t vsm,
                                         uint32_t wp, uint32_t ln,
                                         uint64_t *entryPc, DebugPatch patch);
    CUDBGResult (*membarWAR_getPatchReg) (CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t regno, uint32_t *hasSpilled, uint32_t *regval);
    CUDBGResult (*membarWAR_getPatchPred) (CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t numPreds, uint32_t *predicates);
    CUDBGResult (*membarWAR_getPatchCC) (CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t *cc);
    CUDBGResult (*membarWAR_setPatchReg) (CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t regno, uint32_t *hasSpilled, const uint32_t *regval);
    CUDBGResult (*membarWAR_setPatchPred) (CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t numPreds, const uint32_t *predicates);
    CUDBGResult (*membarWAR_setPatchCC)   (CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln, const uint32_t cc);
    CUDBGResult (*membarWAR_getPatchCallDepth) (CudbgDevice, uint32_t vsm,
                                                uint32_t wp, uint32_t ln,
                                                uint32_t *depth,
                                                DebugPatch patch);
    CUDBGResult (*checkForHwWar) (CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                  uint32_t ln, bool *inPatch, uint64_t *pc,
                                  uint32_t *depth);
    /* Additions for the BAR patching WAR */
    CUDBGResult (*barWAR_getPatchPC) (CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln, uint64_t *entryPc);

    /* Needed since the PGRAPH range differs between Tesla and Fermi */
    CUDBGResult (*getPgraphBar0Extents)  (CudbgDevice, uint32_t *startAddr, uint32_t *size);

    /* Patch dynamic register read/write instructions */
    CUDBGResult (*patchDynamicRegisterRead)     (CudbgDevice dev, uint32_t regnum, uint32_t regval);
    CUDBGResult (*patchDynamicRegisterWrite)    (CudbgDevice dev, uint32_t regnum, uint32_t regval);
    CUDBGResult (*getDynamicRegisterRange)      (uint32_t *dynamicRegisterStart, uint32_t *dynamicRegisterEnd);

    /* Verify CRS checksum */
    CUDBGResult (*verifyCRSxsum) (HaloCRS_t *warpCRS, uint32_t idx);

    /* Offset of gridId in GridParams */
    CUDBGResult (*getGridParamsOffsetGridId) (CudbgDevice dev, uint64_t *offset);

    /* Offset of blockDim in GridParams */
    CUDBGResult (*getGridParamsOffsetBlockDim) (CudbgDevice dev, uint64_t *offset, uint32_t *size);

    /* Offset of gridDim in GridParams */
    CUDBGResult (*getGridParamsOffsetGridDim) (CudbgDevice dev, uint64_t *offset, uint32_t *size);

    /* Offset of startPc in GridParams */
    CUDBGResult (*getGridParamsOffsetStartPc) (CudbgDevice dev, uint64_t *offset);

    /* Find parent grid */
    CUDBGResult (*findParentGrid) (CudbgDevice dev, Grid childGrid, Grid *parentGrid);

    /* Get the ESR PC for an dev,sm,warp. */
    CUDBGResult (*getSMHwwErrorPC) (CudbgDevice dev, uint32_t vsm, uint32_t wp, uint64_t *esrPC, bool *esrPCValid);

    /* Get the broken warps mask. */
    CUDBGResult (*getBrokenWarps) (struct Halo_st *halo, HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, const CUwarpBitmask *validMask, const CUwarpBitmask *bpTrapMask, CUwarpBitmask *brokenwarps);

    /* Additions for the RUN_TRIGGER WAR */
    CUDBGResult (*startRunTriggerWar)  (CudbgDevice dev);
    CUDBGResult (*finishRunTriggerWar) (CudbgDevice dev, int32_t vsm);

    /* Instruction-level Preemption */
    CUDBGResult (*initiatePreemptionSave)    (CudbgDevice dev, CudbgPreemptionState_t *preemptionState);
    CUDBGResult (*initiatePreemptionRestore) (CudbgDevice dev, CudbgPreemptionState_t *preemptionState);
    CUDBGResult (*preemptChannelGroup)       (CudbgDevice dev, uint32_t rmChannelGroup, uint32_t hAppClient, bool *preemptTimedOut);
    CUDBGResult (*scheduleChannelGroup)      (CudbgDevice dev, uint32_t rmChannelGroup, uint32_t hAppClient);
    CUDBGResult (*setChannelGroupTimeslice)  (CudbgDevice dev, uint32_t rmChannelGropu, uint64_t usec);
    CUDBGResult (*setupIlpSave)              (CudbgDevice dev);
    CUDBGResult (*controllerIlpSuspend)      (Context context, uint32_t *suspend);
    CUDBGResult (*controllerIlpSetupMode)    (CudbgDevice dev, uint32_t mode);
    CUDBGResult (*controllerIlpSavedCount)   (CudbgDevice dev, uint32_t *savedCount);
    CUDBGResult (*controllerIlpRestore)      (CudbgDevice dev);
    CUDBGResult (*isWarpEnabledForPreempt)   (CudbgDevice dev, uint32_t vsm, uint32_t wp, bool *isWarpEnabledForPreempt);
    CUDBGResult (*buildMappingTable)         (CudbgDevice dev, bool saveTrapBits);
    CUDBGResult (*restoreWarpMasks)          (CudbgDevice dev);
    CUDBGResult (*findNewHWCoords)           (CudbgDevice dev, uint32_t oldVsm, uint32_t oldWp, uint32_t *vsm, uint32_t *wp);
    CUDBGResult (*getCurrentGrCtxPtr)        (CudbgDevice dev, uint32_t *grCtxPtr);
    CUDBGResult (*waitForGrCtxSave)          (CudbgDevice dev, uint32_t grCtxPtr);
    CUDBGResult (*releaseSharedResources)    (CudbgDevice dev);
    CUDBGResult (*readWarpCtaCtxAddr)        (CudbgDevice dev, uint32_t vsm, uint32_t wp, uint64_t *warpCtaContextAddr);
    CUDBGResult (*setLmemBaseCtaCtx)         (CudbgDevice dev, uint32_t vsm, uint32_t wp);
    CUDBGResult (*readSharedMemCtaCtx)       (CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t addr, void *buf, uint32_t bufSz);
    CUDBGResult (*writeSharedMemCtaCtx)      (CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t addr, const void *buf, uint32_t bufSz);
    CUDBGResult (*readRegCtaCtx)             (CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t regnum, uint32_t *wbuf, uint32_t bufSz);
    CUDBGResult (*writeRegCtaCtx)            (CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t regnum, uint32_t *wbuf, uint32_t bufSz);

    /* Check if this is a reserved grid ID (eg. Scheduler kernel) */
    CUDBGResult (*isReservedGridId) (CudbgDevice dev, uint64_t gridId64, bool *isReserved);

    /* Checks if it can find the first frame in user code, and if so, returns a PC in the frame*/
    CUDBGResult (*readUserEntryFramePC)      (CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln, bool *found, uint64_t *userPC);

    /* Common warp state accessors */
    CUDBGResult (*getLmemBase) (CudbgDevice dev, uint32_t vsm, uint32_t wp, uint64_t *lmemBase);

    /* GK10x - get userEntryFunction */
    CUDBGResult (*getUserEntryFunction) (CudbgDevice dev, Context context, uint32_t vsm, uint32_t wp, uint32_t ln,
                                         Grid grid, DeviceFunction *entryFunc);

    /* GK11x - check if any lane in warp mask is in deviceSync */
    CUDBGResult (*checkAnyLaneInContinuation) (CudbgDevice dev, uint32_t vsm, CUwarpBitmask *wpmask, bool *inContinuation);

    CUDBGResult (*checkWarpNeedsHostResume) (CudbgDevice dev, uint32_t vsm, uint32_t wp, bool *needsHostResume);

    CUDBGResult (*getGTASWindowAddresses)(Context context, uint64_t *sharedWindowBase, uint64_t *sharedWindowSize,
                             uint64_t *localWindowBase, uint64_t *localWindowSize,
                             uint64_t *globalWindowBase);

    CUDBGResult (*setupSingleStepNsteps) (CudbgDevice dev, uint32_t vsm, CUwarpBitmask *warpMask, uint32_t nsteps, uint32_t *nstepsold);
    CUDBGResult (*getTexDptrMask)(CudbgDevice dev, uint64_t *mask);

    CUDBGResult (*cilpForceFullSuspend) (CudbgDevice dev, uint32_t *hasStopped, uint32_t *waitForEvent);

    /* GP10x - CILP */
    CUDBGResult (*readSaveWarpMask)                 (struct Halo_st *halo, HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, CUwarpBitmask *saveWarpMask);
    CUDBGResult (*readSMWarpMasksFromScratchpad)    (struct Halo_st *halo, HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, CUwarpBitmask *validMask, CUwarpBitmask *bpMask, CUwarpBitmask *bpTrapMask);

    /* Get PRIOffset for broadcast or for a single vsm */
    CUDBGResult (*getPRIOffset) (CudbgDevice dev, HaloPRI pri, int32_t vsm,
                                 uint32_t *offset);

    CUDBGResult(*readExitedMask) (CudbgDevice, uint32_t vsm, uint32_t tid, uint32_t *exitedWarpMask);

    CUDBGResult (*canSkipSingleStepOverExitWAR) (bool *skip);

    CUDBGResult (*ldcWAR_getPatchReg) (CudbgDevice dev, uint32_t vsm,
                                       uint32_t wp, uint32_t ln, uint32_t regno,
                                       uint32_t *hasSpilled, uint32_t *regval);

    CUDBGResult (*ldcWAR_setPatchReg) (CudbgDevice dev, uint32_t vsm,
                                       uint32_t wp, uint32_t ln, uint32_t regno,
                                       uint32_t *hasSpilled,
                                       const uint32_t *regval);

    /*
     * Scratchpad access in HALO. Unused reads are added as comments for reference (value type is provisional uint32_t, can be wrong).
     * Unused writes are not added as comments. All methods are marked by their availability on different architectures.
     * Availability legend:
     *   - Always three symbols in the comment brackets, no padding spaces
     *   - "X  " means only supported in X
     *   - "X+ " means supported in X and still supported as of the current latest generation
     *   - "X-Y" means supported from X to Y, inclusively
     *   - "X-X" means the same as "X  ", the latter is used instead
     *   - Architectures are specified by the first letter of their names (i.e. P - Pascal, T - Turing)
     */
    struct HaloScratchpad_st {
        CUDBGResult (*getFieldOffset)               (HaloScratchpadField field, HaloScratchpadSection section, uint32_t sm, uint32_t wp, uint32_t ln, size_t *offset, size_t *width);

        /* Global reads */
        /*F+ */ CUDBGResult (*read_active)                  (HaloScratchpadAccessor scratchpadAccessor, uint32_t *active);
        /*K+    CUDBGResult (*read_preemptCommand)          (HaloScratchpadAccessor scratchpadAccessor, uint32_t *preemptCommand); */
        /*K     CUDBGResult (*read_WAR_runTrigger1239649)   (HaloScratchpadAccessor scratchpadAccessor, uint32_t *warRunTriggerFlagValue); */

        /* SM reads */
        /*K-M*/ CUDBGResult (*read_pauseServicedMask)       (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, CUwarpBitmask *pauseServicedMask);
        /*K-M*/ CUDBGResult (*read_pauseServicedMask_raw)   (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint64_t *pauseServicedMask);

        /* Warp reads */
        /*F+ */ CUDBGResult (*read_smIds)                   (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *virtCTAID, uint32_t *floorsweptSmId);
        /*F-P*/ CUDBGResult (*read_CRSSize)                 (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *crsSize);
        /*F+ */ CUDBGResult (*read_blockIdx)                (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, CuDim3 *blockIdx);
        /*F+ */ CUDBGResult (*read_blockDim)                (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, CuDim3 *blockDim);
        /*F+ */ CUDBGResult (*read_gridId)                  (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint64_t *gridId);
        /*F+ */ CUDBGResult (*read_gridDim)                 (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, CuDim3 *gridDim);
        /*F+ */ CUDBGResult (*read_CTASharedSize)           (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *CTASharedSize);
        /*F+ */ CUDBGResult (*read_lmemWindowSize)          (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *lmemWindowSize);
        /*F+ */ CUDBGResult (*read_lmemLoSizePrThread)      (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *lmemLoSizePrThread);
        /*F+ */ CUDBGResult (*read_lmemHiOff)               (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *lmemHiOff);
        /*F+ */ CUDBGResult (*read_globalErrorStatus)       (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *globalErrorStatus);
        /*F+ */ CUDBGResult (*read_warpErrorStatus)         (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *warpErrorStatus);
        /*V+ */ CUDBGResult (*read_warpErrorPC)             (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint64_t *warpErrorPC);
        /*K+ */ CUDBGResult (*read_isWarpOnBarrier)         (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, bool *isWarpOnBarrier);
        /*K+ */ CUDBGResult (*read_selfQMD)                 (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint64_t *selfQMDdptr);
        /*K+ */ CUDBGResult (*read_lmemBase)                (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint64_t *lmemBase);
        /*K-P*/ CUDBGResult (*read_CRSPtr)                  (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *crsPtr);
        /*K-P*/ CUDBGResult (*read_curPhysStackDepth)       (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *curPhysStackDepth);
        /*F+ */ CUDBGResult (*read_paramConstDptr)          (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint64_t *paramConstDptr);
        /*K+ */ CUDBGResult (*read_mpsContextId)            (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *mpsContextId);
        /*V+ */ CUDBGResult (*read_subcontextVSMId)         (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *subcontextVSMId);
        /*V+    CUDBGResult (*read_subcontextVEId)          (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *subcontextVEId); */
        /*F+ */ CUDBGResult (*read_singleStepNSteps)        (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *nsteps);
        /*P+ */ CUDBGResult (*read_validOnSaveWarpFlag)     (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint8_t *validOnSaveWarpFlag);
        /*P+ */ CUDBGResult (*read_pauseServicedWarpFlag)   (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint8_t *pauseServicedWarpFlag);
        /*V+ */ CUDBGResult (*read_registerCount)           (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *registerCount);
        /*V+ */ CUDBGResult (*read_warpActiveMask)          (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *warpActiveMask);
        /*V+ */ CUDBGResult (*read_warpExitedMask)          (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *warpExitedMask);
        /*V+ */ CUDBGResult (*read_warpTrapRPC)             (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint64_t *pc);

        /* Lane reads */
        /*F+ */ CUDBGResult (*read_threadIdx)               (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t lane, CuDim3 *threadIdx);
        /*F+ */ CUDBGResult (*read_r1)                      (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t lane, uint32_t *r1);

        /* Global writes */
        /*F+ */ CUDBGResult (*write_active)                 (HaloScratchpadAccessor scratchpadAccessor, uint32_t active);
        /*K+ */ CUDBGResult (*write_preemptCommand)         (HaloScratchpadAccessor scratchpadAccessor, uint32_t preemptCommand);
        /*K  */ CUDBGResult (*write_WAR_runTrigger1239649)  (HaloScratchpadAccessor scratchpadAccessor, uint32_t warRunTriggerFlagValue);

        /* SM writes */
        /*K-M*/ CUDBGResult (*write_pauseServicedMask_raw)  (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint64_t pauseServicedMask);

        /* Warp writes */
        /*F+ */ CUDBGResult (*write_singleStepNSteps)       (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t nsteps);
        /*P+ */ CUDBGResult (*write_pauseServicedWarpFlag)  (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint8_t pauseServicedWarpFlag);
        /*V+ */ CUDBGResult (*write_warpTrapRPC)            (HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint64_t pc);
    } scratchpad;

    /*
     * Preemption buffer access in HALO. Unused reads are added as comments for reference (value type is provisional uint32_t, can be wrong).
     * Unused writes are not added as comments. All methods are marked by their availability in different architectures (see scratchpad comment above for legend).
     */
    struct HaloPreemptionBuffer_st {
        CUDBGResult (*getFieldOffset)               (HaloPreemptionBufferField field, HaloPreemptionBufferSection section, uint32_t sm, uint32_t cta, uint32_t wp, uint32_t ln, size_t *offset, size_t *width);
        CUDBGResult (*getRegOffset)                 (struct Halo_st *halo, HaloPreemptionBufferAccessor preemptionBufferAccessor,
                                                     uint32_t sm, uint32_t wp, uint32_t ln, uint32_t regnum, uint32_t numRegs, uint32_t *pRegOffset);
        CUDBGResult (*getRegOffsets)                (struct Halo_st *halo, HaloPreemptionBufferAccessor preemptionBufferAccessor,
                                                     uint32_t sm, uint32_t wp, uint32_t ln, uint32_t firstRegnum, uint32_t numKernelRegs, uint32_t numRegs, uint32_t *pRegOffsets);
        CUDBGResult (*getSwizzledRegOffset)         (uint32_t ln, uint32_t regnum, uint32_t numRegs, uint32_t *regOffset);

        /* SM reads */
        /*P+ */ CUDBGResult (*read_RFDataIdxSync)       (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t *rfDataIdxSync);
        /*P+ */ CUDBGResult (*read_shmemDataIdxSync)    (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t *shmemDataIdxSync);
        /*P+    CUDBGResult (*read_validPendingState)   (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t *validPendingState); */

        /* CTA reads */
        /*P+ */ CUDBGResult (*read_shmemDataIdx)        (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t cta, uint32_t *shmemDataIdx);
        /*P+    CUDBGResult (*read_CTABarState)         (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t cta, uint32_t *CTABarState); */
        /*V+    CUDBGResult (*read_CTAId)               (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t cta, uint32_t *CTAId); */

        /* Warp reads */
        /*P+    CUDBGResult (*read_lmemBase)            (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *lmemBase); */
        /*P+ */ CUDBGResult (*read_RFDataIdx)           (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *rfDataIdx);
        /*P+    CUDBGResult (*read_warpBarState)        (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *warpBarState); */
        /*V+    CUDBGResult (*read_BAR)                 (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *bar); */
        /*V+    CUDBGResult (*read_warpTrapRPC)         (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *warpTrapRPC); */
        /*V+    CUDBGResult (*read_atExitPC)            (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *atExitPC); */
        /*V     CUDBGResult (*read_mKill)               (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *mKill); */
        /*V+    CUDBGResult (*read_warpActiveMask)      (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *warpActiveMask); */
        /*V+ */ CUDBGResult (*read_warpExitedMask)      (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *warpExitedMask);
        /*V+    CUDBGResult (*read_mExited)             (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *mExited); */
        /*V+    CUDBGResult (*read_mAtExit)             (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *mAtExit); */
        /*V+    CUDBGResult (*read_warpCallDepth)       (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *warpCallDepth); */
        /*V+    CUDBGResult (*read_optStack)            (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *optStack); */
        /*T+ */ CUDBGResult (*read_UPR)                 (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *upr);
        /*T+    CUDBGResult (*read_UReg)                (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *uReg); */
        /*T+    CUDBGResult (*read_TTUTicketInfo)       (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *ttuTicketInfo); */
        /*T+    CUDBGResult (*read_TTUMask)             (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *ttuMark); */

        /* Lane reads */
        /*P+ */ CUDBGResult (*read_PR)                  (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t lane, uint8_t *pr);
        /*P  */ CUDBGResult (*read_CC)                  (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t lane, uint8_t *cc);
        /*V+ */ CUDBGResult (*read_RPC)                 (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t lane, uint64_t *rpc);

        /* SM writes */
        /*P+ */ CUDBGResult (*write_RFDataIdxSync)      (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t rfDataIdxSync);
        /*P+ */ CUDBGResult (*write_shmemDataIdxSync)   (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t shmemDataIdxSync);

        /* Warp writes */
        /*V+ */ CUDBGResult (*write_warpTrapRPC)        (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint64_t warpTrapRPC);
        /*T+ */ CUDBGResult (*write_UPR)                (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t upr);

        /* Lane writes */
        /*P+ */ CUDBGResult (*write_PR)                 (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t lane, uint8_t pr);
        /*P  */ CUDBGResult (*write_CC)                 (HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t lane, uint8_t cc);
    } preemptionBuffer;
} Halo_st;

struct CudbgDevice_st {
    /* Track the overall status of the device. If not CUDBG_SUCCESS,
       return this as the failure if trying to access it. */
    CUDBGResult status;

    bool isDebuggable;

    /* The suspended/resumed state of all SMs */
    bool suspended;

    // Fermi info
    uint32_t lmemSizePrSM;

    /* gridid lookup map maintained in the API */
    tHashMap *gridIdToGrid;

    /* The currently running context */
    Context  activeContext;
    tHashMap *contexts;

    /* The context currently mapped (not necessarily active...) */
    Context memMapContext;

    /* BAR0 mapping */
    volatile char *bar0;
    uint32_t bar0Start;
    uint32_t bar0Size;
    void    *bar0AddressRM;
    uint32_t bar0HandleRM;
    volatile char *priBase[CUDBG_MAX_SMS];

    /* BAR1 mapping */
    uint64_t bar1Size;

    DebugObject debugObj;
    /* For controlling clock gating */
    uint32_t hProfilerObj;

    /* Triggered when the device has an event
     * (not enabled if per-context events are enabled)
     */
    cuosEvent event;

    bool     expectingGpuEvent;

    uint32_t eventHandle;

    /* Track a code dirty bit to only invalidate as needed.

       This is required for correctness as Tesla apparently can't
       always correctly handle invalidations in single step mode.  For
       Fermi we always invalidate the D$ as just the traphandler alone
       requires this. */
    int      codeIsDirty;

    /* Low-level Debugger State */
    int      deviceIdx; // CUDA Driver enumeration

    uint32_t grDebugEvent;

    /* SM states */
    CudbgSM_t smState[CUDBG_MAX_SMS];

    /* per-SM pause serviced mask */
    CUwarpBitmask pauseServicedMask[CUDBG_MAX_SMS];

    /* WAR GK10x HW Bug 865738 (instanced).  Store original SM BLCG setting.
       This variable makes a uniformity assumption across all SMs. */
    uint32_t origBLCG1Setting;
    bool     origBLCG1SettingValid;

    /* Track the state of memcheck */
    HaloMCState_t mcState;

    struct Halo_st halo;

    /* Pointer to the halo client */
    HaloClient haloClient;

    /* Indicate if a finalize for this device is in progress */
    bool finalizing;

    /* This is used to define whether or not a debug object
       should be used when collecting state */
    HaloDebugObjMode_t debugObjMode;

    CudbgPreemptionState_t preemptState;
    CudbgPreemptionMappingTable_t preemptMappingTable;

#ifdef CUDBG_ENABLE_IFB
    /* IFB pointer */
    GF100IndirectFramebuffer *ifbPtrFermi;
#endif

    /* Pointer to extra Client Data */
    HaloClientData clientData;

    /* Pointer to device DMAL */
    HaloDmal dmal;
};

struct BreakpointRec {
    bool                             isSet;
    uint64_t                         devVAddr;
    uint64_t                         gpuAddr;
    BreakpointContents               savedContents;
    Context                          context;
};

typedef enum {
    CUDBG_PATCH_MEMCHECK       = 0x01,
    CUDBG_PATCH_SYSCALL        = 0x02,
    /* placeholder for 0x04, 0x08 */
    CUDBG_PATCH_GLOBAL_SYSCALL = 0x10,
    CUDBG_PATCH_TRAP_HANDLER   = 0x20,
    CUDBG_PATCH_MEMBAR_WAR     = 0x40,
    CUDBG_PATCH_BAR_WAR        = 0x80,
    CUDBG_PATCH_LDC_WAR        = 0x100,
} dbg_patch_kind_t;

#define CUDBG_PATCH_ALL (CUDBG_PATCH_MEMCHECK | \
                         CUDBG_PATCH_SYSCALL | \
                         CUDBG_PATCH_GLOBAL_SYSCALL | \
                         CUDBG_PATCH_TRAP_HANDLER | \
                         CUDBG_PATCH_MEMBAR_WAR | \
                         CUDBG_PATCH_BAR_WAR | \
                         CUDBG_PATCH_LDC_WAR)

#define CUDBG_PATCH_HW_WAR (CUDBG_PATCH_MEMBAR_WAR | \
                            CUDBG_PATCH_BAR_WAR | \
                            CUDBG_PATCH_LDC_WAR)

#define HALO_PATCH_IS_HW_WAR(kind) (kind & CUDBG_PATCH_HW_WAR)

#define HALO_PATCH_MODIFIES_REG(kind) (kind & \
                                       (CUDBG_PATCH_MEMCHECK | \
                                       CUDBG_PATCH_MEMBAR_WAR | \
                                       CUDBG_PATCH_LDC_WAR))
#define HALO_PATCH_MODIFIES_PRED(kind) (kind & \
                                        (CUDBG_PATCH_MEMCHECK | \
                                        CUDBG_PATCH_MEMBAR_WAR)) // GM10x+ MEMBAR war doesn't modify pred
                                                                // This difference is handled in *_membarWAR_{set/get}PatchPred
#define HALO_PATCH_MODIFIES_CC(kind) (kind & \
                                      (CUDBG_PATCH_MEMCHECK | \
                                       CUDBG_PATCH_MEMBAR_WAR)) // GM10x+ MEMBAR war doesn't modify CC
                                                               // This difference is handled in *_membarWAR_{set/get}CC

#define HALO_LOCAL_MEMORY_ACCESS_FOR_ALL_LANES ~0

typedef enum {
    CUDBG_NOTIFY_SYNC_ALL           = 0x00,
    CUDBG_NOTIFY_SYNC_FIRST_ONLY    = 0x01,
    CUDBG_NOTIFY_NONE               = 0x02,
} CudbgLaunchState;

typedef enum {
    CUDBG_STEP_RESUME_TYPE_WARP      = 0,
    CUDBG_STEP_RESUME_TYPE_CTA       = 1,
    CUDBG_STEP_RESUME_TYPE_SM        = 2,
    CUDBG_STEP_RESUME_TYPE_DEVICE    = 3
} CudbgStepResumeType;

/* For more docs, see gpudbgReportPatch */
struct DebugPatchRec {
    uint64_t                devVAddr;        /*  virtual device PC. address of the patch, absolute in the context's VA */
    uint64_t                entryAddr;       /*          device PC. address of the instruction that branches to this patch, relative to the context's function memory base */
    uint64_t                gpuAddr;         /*          device PC. like devVAddr, but relative to the context's function memory base */
    uint64_t                virtAddr;        /*  virtual host   PC. like devVAddr, but mapped into the inferior's VA */
    uint32_t                size;            /* size of the patch, in bytes */
    uint64_t                origInst[2];
    Context                 context;
    uint32_t                kind;            /* dbg_patch_kind_t */
    uint32_t                hopSize;
    CudbgStepResumeType     stepResumeType;
    bool                    multiEntry;
    bool                    debug;
    uint32_t                patchId;
    uint32_t                depth;
    tHashMap                *breakPoints;
    tHashMap                *temporaryBreakPoints;
};

typedef enum {
    HALO_CTX_STATE_INVALID = 0,
    HALO_CTX_STATE_ACTIVE = 1,
    HALO_CTX_STATE_FINALIZING = 2,
} HaloCtxState;

struct ContextRec {
    uint64_t                         cuCtx;
    CudbgDevice                      dev;
    HaloCtxState                     state;
    tHashMap                        *modules;
    pid_t                            hostThreadId; // The thread that owns the context
    uint64_t                         patchRamDevVA; /* Patch RAM - chunk of function memory allocated for devtools use */
    uint32_t                         patchRamSize;
    uint64_t                         scratchpadDevPtr;
    uint64_t                         scratchpadDevVA;
    void                             *scratchpadCache; /* Scratchpad cache */
    bool                             scratchpadCacheValid;  /* Scratchpad cache */
    uint64_t                         syscallRcVaddr; //Address of the syscall reason code buffer
    uint32_t                         syscallStackSz; /* Size of the syscall stack */
    bool                             launchBlocking;
    bool                             memMapActive; // true if memMap can be trusted
    bool                             enableEvents;
    CudbgLaunchState                 launchNotifyState;

    uint64_t                         defaultLmemDevVA;  // required for fast lookup
    uint64_t                         defaultLmemSize;   // for completeness
    haloMemoryMap                   *memMap;       // Memory tracking for context
    tHashMap                         *grids;
    TextureReader                    texMem;
    tRangeMap                       *gpuAddrToFunction;
    tRangeMap                       *gpuAddrToPatch;
    tRangeMap                       *virtAddrToPatch;
    tHashMap                        *patchEntry;
    uint32_t                         numSyscalls;
    uint64_t                         funcMemBaseVA;
    uint64_t                         thCodeVA;
    uint64_t                         thCodeSize;
    uint64_t                         thRdRegOffset;
    uint64_t                         thWrRegOffset;
    uint64_t                         thRdTexMemOffset;
    uint64_t                         kilpControllerDataAddr;
    uint64_t                         kilpCtaIlpEnableTableAddr;
    uint64_t                         kilpCtaStopContinuations;
    uint64_t                         ctaContextIndirectionTableAddr;
    uint32_t                         hAppClient;
    DebugObject                      debugObj;
    uint32_t                         hComputeObject;
    uint32_t                         hChannelGroup;
    uint32_t                         hComputeChannelList[CUDBG_MAX_CHANNELS];
    int32_t                          channelfds[CUDBG_MAX_CHANNELS];
    uint32_t                         hDebugEvent;
    uint32_t                         numChannels;
    uint64_t                         texHeaderPoolVA;
    uint64_t                         texSamplerPoolVA;
    int                              fdArray[CUDBG_FD_NUM_TYPES];
    cuosEvent                        event;             /* Triggered when the context has an event */
    uint32_t                         mpsContextId;      // Set to MPS context ID of this client
    uint64_t                         cilpBufferDevVA;
    HaloSaveBufferState              saveBufferState;
    uint64_t                         shmemWindowDevVA;
    uint64_t                         lmemWindowDevVA;
    uint64_t                         lmemSizePerSM;
    uint64_t                         gmemWindowDevVA;
    HaloScratchpadAccessor           scratchpadAccessor;
    HaloPreemptionBufferAccessor     preemptionBufferAccessor;
    tHashMap                         *insnInfoCache;
    uint64_t                         globalFocusCoordsAddr;
    uint32_t                         globalFocusCoordsAllocSize;
};

typedef enum {
    DEV_MOD_TYPE_USER = 0,
    DEV_MOD_TYPE_SYSCALL = 1,
    DEV_MOD_TYPE_TRAPHANDLER = 2,
    DEV_MOD_TYPE_TRAMPOLINE = 3,
    DEV_MOD_TYPE_ATENTRY = 4,
    DEV_MOD_TYPE_TOOLS = 5,
    DEV_MOD_TYPE_MEMBAR_WAR = 6,
    DEV_MOD_TYPE_EXITFUNCTION = 7,
    DEV_MOD_TYPE_BARSYNC_WAR = 8,
    DEV_MOD_TYPE_NANOSLEEP_WAR = 9,
    DEV_MOD_TYPE_LDC_WAR = 10,
    DEV_MOD_TYPE_HIDDEN_USER = 11,
    DEV_MOD_TYPE_MEMBAR_OPTI_WAR = 12,
    DEV_MOD_TYPE_INVALID = 0xFFFFFFFFU // Large value
} DeviceModuleType_t;

struct DeviceModuleRec {
    uint64_t                         cuModule;
    char *                           name;
    Context                          context;
    char *                           stringTable;
    tHashMap                        *functions;
    elf_t                            relocatedElfImage;
    elf_t                            nonRelocatedElfImage;
    uint64_t                         elfImageSize;
    uint32_t                         abiVersion;
    char                            *regMap;
    bool                             internal;
    bool                             hidden;
    bool                             exported;
    uint32_t                         hiddenFunctionCount;
    uint32_t                         userFunctionCount;
    DeviceModuleType_t               visibility;
    DwarfDebugFrame                  debugFrame;
};


typedef enum {
    DEV_FUNC_TYPE_DEVICE,
    DEV_FUNC_TYPE_GLOBAL,
    DEV_FUNC_TYPE_PROLOGUE,
    DEV_FUNC_TYPE_SYSCALL,
    DEV_FUNC_TYPE_GLOBAL_SYSCALL,
    DEV_FUNC_TYPE_DRIVER_PATCH,
} DeviceFunctionType_t;

struct DeviceFunctionRec {
    DeviceFunctionType_t             type;
    uint64_t                         cuFunction;
    char *                           name;
    uint64_t                         devVAddr;
    uint64_t                         gpuAddrBase;
    uint64_t                         virtAddrBase;
    uint64_t                         codeSize;
    uint64_t                         spAssignmentAddr;
    DeviceFunction                   relatedFunction;
    DeviceModule                     module;
    bool                             hidden;
    tHashMap                        *breakPoints;
    tHashMap                        *temporaryBreakPoints;
    uint32_t                         nrofRegisters;
    uint32_t                         stackSize;
    uint32_t                         frameSize;
    bool                             spAdjustmentInfoValid;
    uint64_t                         pcPrologueSpAdjustmentAddr;
    uint64_t                         pcEpilogueSpAdjustmentAddr;
    uint32_t                         localSize;
    uint32_t                         sharedSize;
    uint32_t                         texRefCount;
    tHashMap                         *grids;
    uint32_t                         numTexIdMapEntries;
    bool                             usesCnp;
    bool                             usesContinuations;
    bool                             needsHostResume;
    bool                             isCnpCtxSync;
    TexIdMap                         *texIdMap;
};

typedef enum {
    HALO_GRID_STATE_INVISIBLE   = 0, /* Grid is either invalid or is pointing to syscall code */
    HALO_GRID_STATE_UNPOSTED    = 1, /* Grid is valid in the backend but has not been seen by frontend */
    HALO_GRID_STATE_POSTED      = 2, /* Grid is valid and event has been queued to frontend */
} haloGridState;

struct GridRec {
    uint64_t                         gridId64;
    DeviceFunction                   function;
    DeviceFunction                   userEntryFunction;
    CuDim3                           gridDim;
    CuDim3                           blockDim;
    haloGridState                    state;
    uint64_t                         selfQMDdptr;
    uint64_t                         parentGridId64;
    CUDBGKernelOrigin                origin;
    uint64_t                         hostStreamId;
};

struct HaloClientData_st {
    union {
        struct {
            CUctx *cuctx;
        } memcheck;
    } cases;
};


typedef enum {
    HALO_INIT_FLAGS_NONE = 0,
    HALO_INIT_FLAGS_ENABLE_GLOBAL_DEBUG_OBJECT =        (1 << 0),
    HALO_INIT_FLAGS_ENABLE_PER_CONTEXT_DEBUG_OBJECT =   (1 << 1),
    HALO_INIT_FLAGS_FORCE_CLIENT_DMAL =                 (1 << 2),   // This is used only by the memcheck client
    HALO_INIT_FLAGS_COLLECT_ACTIVE_CONTEXT =            (1 << 3),
    HALO_INIT_FLAGS_FORCE_REGOPS =                      (1 << 4),
    HALO_INIT_FLAGS_IN_PROCESS =                        (1 << 5),
    HALO_INIT_FLAGS_ENABLE_DEBUG_OBJECT_MEMORY_ACCESS = (1 << 6),
    HALO_INIT_FLAGS_ENABLE_SCRATCHPAD_CACHE =           (1 << 7),
    HALO_INIT_FLAGS_ENABLE_CONTEXT_EVENTS =             (1 << 8),
    HALO_INIT_FLAGS_ERROR_ON_MISSING_DEBUG_FRAME =      (1 << 9),
    HALO_INIT_FLAGS_ENABLE_INSN_CACHE =                 (1 << 10),
} HaloInitFlags_t;

#define HALO_INIT_FLAGS_ENABLE_DEBUG_OBJECT_DEFAULT         \
    (HALO_INIT_FLAGS_ENABLE_GLOBAL_DEBUG_OBJECT             \
    | HALO_INIT_FLAGS_ENABLE_PER_CONTEXT_DEBUG_OBJECT       \
    | HALO_INIT_FLAGS_ENABLE_CONTEXT_EVENTS                 \
    | HALO_INIT_FLAGS_ENABLE_DEBUG_OBJECT_MEMORY_ACCESS)

struct HaloInitData_st {
    uint32_t haloType;
    uint32_t flags;
    HaloDmalType_t haloDmalType;
    union {
        struct {
            CUctx* cuctx;               // Used only for memcheck client
            void*  gvars;               // Used only for memcheck
            bool   isMpsClient;         // Set to !0 if running on mpsClient
        } memcheck;
    } cases;
};

struct HaloGlobals_st {
    struct CudbgDevice_st   **device;
    struct haloState_st     *state;
    struct HaloInitData_st  initData; // For state determined by init-time args
    HaloClient              haloClient;
    HaloDmal                haloDmal[HALO_DMAL_COUNT];
    UvmToolsSessionHandle   uvmSession;

    /* Managed memory can persist when there are no contexts
     * and can also be migrated between GPUs, so this map is
     * global. */
    haloMemoryMap *globalMemMap;

    /* Global rangeMap holding all segments that are mapped into the
     * application's host VA space. */
    tRangeMap *globalHostVAMap;

    /* Critical section used for ensuring atomicity between
       calls to mapMemory() and subsequent memcpy() routines. */
    CUOSCriticalSection mapMemory_cs;
};
extern HaloGlobals haloGlobals;

typedef enum {
    DCI_FIELD_NTID_X,
    DCI_FIELD_NCTAID_Z,
    DCI_FIELD_GRIDID32,
    DCI_FIELD_GRIDID64,
    DCI_FIELD_NUM_FIELDS,
} DCIFields;

typedef enum {
    HALO_EXCEPTION_PRECISION_UNKNOWN,
    HALO_EXCEPTION_PRECISION_NONE,
    HALO_EXCEPTION_PRECISION_LANE,
    HALO_EXCEPTION_PRECISION_WARP,
    HALO_EXCEPTION_PRECISION_SM,
    HALO_EXCEPTION_PRECISION_DEVICE,
} HaloExceptionPrecision;


/* Convenience macros for scratchpad access */

#define HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, section, field, vsm, wp, ln, bufPtr) do { \
    CUDBGResult res;                                                                            \
    res = scratchpadAccessor->getField(scratchpadAccessor, HALO_SCRATCHPAD_FIELD_##field,       \
                                       HALO_SCRATCHPAD_SECTION_##section, vsm, wp, ln,          \
                                       bufPtr, sizeof(*bufPtr));                                \
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,                                                     \
                "scratchpad GET failed: field %s, section %s, vsm %d, wp %d, ln %d\n",          \
                 #field, #section, vsm, wp, ln);                                                \
} while(0)

#define HALO_SCRATCHPAD_SET_FIELD(scratchpadAccessor, section, field, vsm, wp, ln, bufPtr) do { \
    CUDBGResult res;                                                                            \
    res = scratchpadAccessor->setField(scratchpadAccessor, HALO_SCRATCHPAD_FIELD_##field,       \
                                       HALO_SCRATCHPAD_SECTION_##section, vsm, wp, ln,          \
                                       bufPtr, sizeof(*bufPtr));                                \
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,                                                     \
                "scratchpad SET failed: field %s, section %s, vsm %d, wp %d, ln %d\n",          \
                 #field, #section, vsm, wp, ln);                                                \
} while(0)

#define HALO_SCRATCHPAD_GET_OFFSET_CASE(field, container, member) \
case HALO_SCRATCHPAD_FIELD_##field: {                             \
    *offset = offsetof(container, member);                        \
    *width = sizeof(((container*)0)->member);                     \
    break;                                                        \
}

/* Convenience macros for preemption buffer access */
#define HALO_PREEMPTION_BUFFER_GET_FIELD(preemptionBufferAccessor, section, field, vsm, cta, wp, ln, bufPtr) do {   \
    CUDBGResult res;                                                                                                \
    res = preemptionBufferAccessor->getField(preemptionBufferAccessor, HALO_PREEMPTION_BUFFER_FIELD_##field,        \
                                             HALO_PREEMPTION_BUFFER_SECTION_##section,                              \
                                             vsm, cta, wp, ln,                                                      \
                                             bufPtr, sizeof(*bufPtr));                                              \
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,                                                                         \
                "PREEMPTION buffer GET failed: field %s, section %s, vsm %d, cta %d, wp %d, ln %d\n",               \
                 #field, #section, vsm, cta, wp, ln);                                                               \
} while(0)

#define HALO_PREEMPTION_BUFFER_SET_FIELD(preemptionBufferAccessor, section, field, vsm, cta, wp, ln, bufPtr) do {   \
    CUDBGResult res;                                                                                                \
    res = preemptionBufferAccessor->setField(preemptionBufferAccessor, HALO_PREEMPTION_BUFFER_FIELD_##field,        \
                                 HALO_PREEMPTION_BUFFER_SECTION_##section,                                          \
                                 vsm, cta, wp, ln,                                                                  \
                                 bufPtr, sizeof(*bufPtr));                                                          \
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,                                                                         \
                "PREEMPTION buffer SET failed: field %s, section %s, vsm %d, cta %d, wp %d, ln %d\n",               \
                 #field, #section, vsm, cta, wp, ln);                                                               \
} while(0)

#define HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(field, container, member)  \
case HALO_PREEMPTION_BUFFER_FIELD_##field: {                              \
    *offset = OFFSETOF_NONCONST(container, member);                 \
    *width = sizeof(((container*)0)->member);                       \
    break;                                                          \
}

#define HALO_IS_FD_VALID(x) (x >= 0)

CUDBGResult haloInit(HaloInitData initOptions);
CUDBGResult haloFinalize(void);

CUDBGResult clearEvent(CudbgDevice dev, Context ctx);
CUDBGResult haloFreeDeviceEvent(CudbgDevice dev);
CUDBGResult haloAllocateDeviceEvent(CudbgDevice dev, const CUdev* pDev);
CUDBGResult haloSetWatchdogTimeout(CudbgDevice dev, uint32_t timeout, uint32_t interval);
CUDBGResult haloClientInit_halo(HaloClient haloClient);

extern CUDBGResult haloClientInit_debugger(HaloClient haloClient);
CUDBGResult haloDeviceInitialize(CudbgDevice, uint32_t);

void haloSetMemcheckState(CudbgDevice, bool enabled);

/* Prototypes for shared fxns. (they call into RM) */
CUDBGResult haloSetRmDebugMode(CudbgDevice, bool on);

CUDBGResult haloFindAnActiveLane(CudbgDevice dev, uint32_t sm, uint32_t wp, uint32_t *ln);
bool        haloWarpsInSameCTA(CudbgDevice dev, uint32_t vsm, uint32_t wpA, uint32_t wpB);
CUDBGResult haloAnyDbgCtxResident(CudbgDevice dev, Context *residentContext);
CUDBGResult haloIsContextResident(Context ctx, bool *bResident);

CUDBGResult haloReadCCRegister(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                               uint32_t predLmemAddr, uint32_t *cc);
CUDBGResult haloWriteCCRegister(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                                uint32_t predLmemAddr, const uint32_t cc);

/* Memory map handling */
CUDBGResult haloMemoryMapAddSegmentFromInfo(haloMemoryMap *memMap, CUDBGmemory_segment *seg);

/* Scratchpad accessors */
CUDBGResult haloScratchpadGetField(Context context, HaloScratchpadField field, HaloScratchpadSection section,
                                   uint32_t sm, uint32_t wp, uint32_t ln, void *value, size_t size);
CUDBGResult haloScratchpadSetField(Context context, HaloScratchpadField field, HaloScratchpadSection section,
                                   uint32_t sm, uint32_t wp, uint32_t ln, void *value, size_t size);

/* Preemption buffer accessors */
CUDBGResult
haloPreemptionBufferGetField(Context context, HaloPreemptionBufferField field,
                             HaloPreemptionBufferSection section, uint32_t sm,
                             uint32_t cta, uint32_t wp, uint32_t ln, void *value, size_t size);

CUDBGResult
haloCilpBufferSetField(Context context, HaloPreemptionBufferField field,
                       HaloPreemptionBufferSection section, uint32_t sm,
                       uint32_t cta, uint32_t wp, uint32_t ln, void *value, size_t size);

/* Common exception parsing */
HaloExceptionPrecision haloExceptionGetPrecision(CUDBGException_t exception);

CUDBGResult
haloCreateDynamicGrid(CudbgDevice dev, uint32_t vsm, uint32_t wp);

CUDBGResult kepler_flushL2(CudbgDevice dev, uint32_t vsm);

/* Cache handling */
CUDBGResult haloInvalidateCaches(CudbgDevice dev);

CUDBGResult
haloIsPatchEntry(uint64_t gpuAddr, Context ctx, DebugPatch *patch,
                 uint32_t filter, bool *result);

CUDBGResult
haloInPatchRegion(uint64_t addr, Context ctx, DebugPatch *patch,
                  uint32_t filter, bool *result, bool isVirtAddr);

/* Hidden function support */
CUDBGResult haloInHiddenFunction(DeviceFunction function, bool *hidden);

/* support functions */
CUDBGResult haloReadRawPC(CudbgDevice dev, uint32_t sm, uint32_t wp, uint32_t ln, uint64_t *pc);

#if !NV_MODS
/* Determine if the unified debugger client should be enabled at init time. */
extern bool g_enableUnifiedDebuggerClient;
#endif

#ifdef __cplusplus
}
#endif // __cplusplus

#endif
