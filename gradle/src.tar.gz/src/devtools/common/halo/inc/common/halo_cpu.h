/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef _HALO_CPU_H
#define _HALO_CPU_H 1

#include <string.h>

/* On aarch64, when memcpy'ing to/from BAR1 mapped addresses,
   the libc implementation attemps to use a LDR (a 8 byte aligned load)
   from the sou4rce and dest pointers. If the pointer is not aligned to
   8 bytes, APM stack throws a misaligned fault. The current theory is
   that the kernel is unable to do the fixup in the VM_IO range, as
   replaying volatile accesses may have sideeffects.
   To "fix" this, the halo instead vectors into the haloMemcpy
   memcpy routine, which is invoked on all paths that directly
   access BAR1 mapped memory. On aarch64, this does a byte-wise
   copy, bypassing the libc variant. On other architectures,
   this is just a wrapper to libc memcpy().
*/
#if defined(__aarch64__)
static void *haloMemcpy(void *dest, const void *src, size_t n)
{
    char *dstPtr;
    const char* srcPtr;
    size_t i;

    if (!dest || !src || !n)
        return dest;

    dstPtr = (char*)dest;
    srcPtr = (const char*)src;

    for (i = 0; i < n; ++i)
        *dstPtr++ = *srcPtr++;

    return dest;
}
#else
static void *haloMemcpy(void *dest, const void *src, size_t n)
{
    return memcpy(dest, src, n);
}
#endif

#endif
