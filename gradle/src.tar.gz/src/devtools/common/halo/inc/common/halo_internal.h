/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: halo_internal.h
 *
 *   Description:
 *       Internal header file for the debug access layer.
 *
 ******************************************************************************/

#ifndef _HALO_HALO_INTERNAL_H
#define _HALO_HALO_INTERNAL_H 1

#include "cudbgutils.h"
#include "halo.h"
#include "halo_helper.h"
#include "halo_trace.h"

// Sadly Windows comes poorly equipped
#if cuosOsIsWindows() && !defined(inline)
#define inline
#endif

/* Debug Trace */
#ifndef RELEASE
#define HALO_TRACE(level, ...)              haloTrace(HALO_TRACE_DOMAIN_HALO, HALO_TRACE_TYPE_FILE, level, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#define HALO_TRACE_FUNCTION(level, ...)     haloTrace(HALO_TRACE_DOMAIN_HALO, (HALO_TRACE_TYPE_FILE | HALO_TRACE_TYPE_FUNCTION), level, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#define HALO_ERROR(...)                     haloTrace(HALO_TRACE_DOMAIN_HALO, HALO_TRACE_TYPE_FILE, 0, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__)
#define HALO_ASSERT(c)                                                                  \
    do {                                                                                    \
        if (!(c)) {                                                                         \
            haloTrace(HALO_TRACE_DOMAIN_HALO, (HALO_TRACE_TYPE_FILE | HALO_TRACE_TYPE_FUNCTION | HALO_TRACE_TYPE_LINE),        \
                       0, __FILE__, __LINE__, __FUNCTION__, "Assertion failed: %s\n", #c);  \
            abort();                                                                        \
        }                                                                                   \
    } while(0);

#else
#define HALO_TRACE(level, ...)              ((void)0)
#define HALO_TRACE_FUNCTION(level, ...)     ((void)0)
#define HALO_ERROR(...)                     ((void)0)
#define HALO_ASSERT(c)                      ((void)0)
#endif

extern void haloFindPrefix(const char *fileName, char prefix[6]);
CUDBGResult haloTraceWarpPCs(int32_t level, const char *file, const uint32_t line, const char *function, CudbgDevice dev, uint32_t vsm);

#endif
