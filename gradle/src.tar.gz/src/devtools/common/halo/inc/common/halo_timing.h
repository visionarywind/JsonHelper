/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef HALO_TIMER_H
#define HALO_TIMER_H

#include <cuos.h>
#include <stdlib.h>
#include <time.h>
#include "halo_trace.h"

typedef struct haloTimer_st haloTimer;
typedef struct haloTimingLocation_st haloTimingLocation;

// Must be power of 2
#define HALO_MAX_TIMING_LAPS 32

struct haloTimingLocation_st {
    const char *file;
    const char *func;
    const char *note;
    int line;
    float timeMs;
    int active;
};

struct haloTimer_st {
    int laps;
    cuosTimer cutimer;
    haloTimingLocation start;
    haloTimingLocation lap[HALO_MAX_TIMING_LAPS];
    haloTimingLocation stop;
};

static haloTimer haloGlobalTimer;

static int64_t haloTimerGetElapsedNsec(haloTimingLocation *start, haloTimingLocation *stop);
static void haloTimerPrint(haloTimer timer, long minusec, int32_t level, const char *msg, ...);

#if !defined(RELEASE) && defined(CUDA_DEVTOOLS_ENABLE_STATS)

#define HALO_TIMER_START(timer) do { \
    cuosResetTimer(&timer.cutimer); \
    timer.start.func = __FUNCTION__;\
    timer.start.file = __FILE__;\
    timer.start.line = __LINE__;\
    timer.start.note = NULL;\
    timer.start.active = 1;\
    timer.laps = 0;\
} while (0)

#define HALO_TIMER_STOP(timer) do { \
    timer.stop.timeMs = cuosGetTimer(&timer.cutimer);\
    timer.stop.func = __FUNCTION__;\
    timer.stop.file = __FILE__;\
    timer.stop.line = __LINE__;\
    timer.stop.note = NULL;\
    timer.stop.active = 1;\
    cuosResetTimer(&timer.cutimer); \
} while (0)

#define HALO_TIMER_LAP(timer, _note) do {\
    timer.lap[timer.laps].timeMs = cuosGetTimer(&timer.cutimer);\
    timer.lap[timer.laps].func = __FUNCTION__;\
    timer.lap[timer.laps].file = __FILE__;\
    timer.lap[timer.laps].line = __LINE__;\
    timer.lap[timer.laps].note = _note;\
    timer.lap[timer.laps].active = 1;\
    timer.laps = (timer.laps + 1) % HALO_MAX_TIMING_LAPS;\
} while (0)

#define HALO_TIMER_RESET(timer) do { \
    memset(&timer, 0, sizeof(timer));\
} while (0)

#define HALO_TIMER_PRINT(timer, lvl, ...) haloTimerPrint(timer, 0, lvl, __VA_ARGS__)

#else
#define HALO_TIMER_START(timer) do { } while (0)
#define HALO_TIMER_LAP(timer, msg) do { } while (0)
#define HALO_TIMER_STOP(timer) do { } while (0)
#define HALO_TIMER_RESET(timer) do { } while (0)
#define HALO_TIMER_PRINT(timer, lvl, ...) do { } while (0)
#endif

#define HALO_GLOBAL_TIMER_START() HALO_TIMER_START(haloGlobalTimer)
#define HALO_GLOBAL_TIMER_LAP(_note) HALO_TIMER_LAP(haloGlobalTimer, _note)
#define HALO_GLOBAL_TIMER_STOP() HALO_TIMER_STOP(haloGlobalTimer)
#define HALO_GLOBAL_TIMER_RESET() HALO_TIMER_RESET(haloGlobalTimer)
#define HALO_GLOBAL_TIMER_PRINT(lvl, ...) HALO_TIMER_PRINT(haloGlobalTimer, lvl, __VA_ARGS__)

static void
haloTimerPrint(haloTimer timer, long minusec, int32_t level, const char *msg, ...)
{
    char fin_msg[2048];
    va_list marker;
    int i;

    if (timer.stop.timeMs*1000.0 < minusec)
        return;

    va_start(marker, msg);
    vsnprintf(fin_msg, 2048, msg, marker);
    va_end(marker);
    haloTrace(HALO_TRACE_DOMAIN_PERF, 0, level, NULL, 0, NULL,
        "Timer Elapsed : %.4f msec. %s",
        timer.stop.timeMs, fin_msg);
    haloTrace(HALO_TRACE_DOMAIN_PERF, 0, level, NULL, 0, NULL,
        "\tStart : %s:%s:%d\n",
        timer.start.func, timer.start.file, timer.start.line);
    if (timer.lap[0].active) {
        for (i = 0; i < timer.laps; ++i) {
            if (!timer.lap[i].active)
                continue;
            haloTrace(HALO_TRACE_DOMAIN_PERF, 0, level, NULL, 0, NULL,
                      "\tLap %02u : %.4f msec %s %s:%s:%d\n",
                      i, timer.lap[i].timeMs,
                      timer.lap[i].note ? timer.lap[i].note : "",
                      timer.lap[i].func, timer.lap[i].file, timer.lap[i].line);
        }
    }

    haloTrace(HALO_TRACE_DOMAIN_PERF, 0, level, NULL, 0, NULL,
        "\tEnd : %s:%s:%d\n",
        timer.stop.func, timer.stop.file, timer.stop.line);
}

#endif
