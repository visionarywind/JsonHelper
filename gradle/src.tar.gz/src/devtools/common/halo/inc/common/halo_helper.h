/*
 * Copyright 2010-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: halo_helper.h
 *
 *   Description:
 *       internal header file for helper macros & functions.
 *
 ******************************************************************************/

#ifndef _HALO_HALO_HELPER_H
#define _HALO_HALO_HERLPER_H 1

/*
 * Bitfield access macros.
 * Note: the %64 and %32 in macros ___FMASK64 and ___FMASK32 are for
 *       suppressing compiler noise that will otherwise occur for f==0.
 *       Because all bitfield boundaries are compile time constants,
 *       they will induce no runtime overhead.
 *
 *       The % 64 in __{LOW,HIGH}FIELD() are required as some of the
 *       register fields are defined wider than 64-bits, though it
 *       still it's own responsibility to get the correct 64-bit
 *       word. See for example, read_CRS_ptr.
 */

#define ___LOWFIELD(f)            ((0?f) % 64)
#define ___HIGHFIELD(f)           ((1?f) % 64)
#define ___FMASK64(f)             (f ? (((uint64_t)-1) >> ((64-(f))%64)) : 0)
#define ___FMASK32(f)             (f ? (((uint32_t)-1) >> ((32-(f))%32)) : 0)
#define ___FIELDSHIFT(field)      (___LOWFIELD(field))

#define ___FIELDMASK64(field)     (___FMASK64(___HIGHFIELD(field)+1) \
                                   - ___FMASK64(___LOWFIELD(field)))

#define ___FIELDMASK32(field)     (___FMASK32(___HIGHFIELD(field)+1) \
                                   - ___FMASK32(___LOWFIELD (field)))

/*
 * GETFIELD64 extracts a subfield from a 64-bit value. The results is always
 * 32-bit or less
 */
#define GETFIELD64(reg,field)     ((uint32_t) (((reg)& ___FIELDMASK64(field)) \
                                               >> ___FIELDSHIFT(field)))

#define SETFIELD64(reg,field,val) (((reg)&~___FIELDMASK64(field))    \
                                   | (((uint64_t)(val)               \
                                       << ___FIELDSHIFT(field))      \
                                       & ___FIELDMASK64(field)))

#define GETFIELD32(reg,field)     (((reg)& ___FIELDMASK32(field))    \
                                   >> ___FIELDSHIFT(field))

#define SETFIELD32(reg,field,val) (((reg)&~___FIELDMASK32(field))    \
                                    | (uint32_t) (((uint64_t)(val)   \
                                        << ___FIELDSHIFT(field))     \
                                       & ___FIELDMASK32(field)))

#define SETREGISTER32(dev, vsm, scope, haloPri, field, val) do {              \
    CUDBGResult res;                                                          \
    uint32_t regVal;                                                          \
    uint32_t regOffset = 0;                                                   \
                                                                              \
                                                                              \
    res = dev->halo.getPRIOffset(dev, (HaloPRI)haloPri, vsm, &regOffset);     \
    if (res != CUDBG_SUCCESS)                                                 \
        return res;                                                           \
                                                                              \
    res = dev->haloClient->readReg32(dev, scope,                              \
                                     (char *)(uintptr_t)regOffset, &regVal);  \
    if (res != CUDBG_SUCCESS)                                                 \
        return res;                                                           \
                                                                              \
    regVal = SETFIELD32(regVal, field, val);                                  \
                                                                              \
    res = dev->haloClient->writeReg32(dev, scope,                             \
                                      (char *)(uintptr_t)regOffset, &regVal); \
    if (res != CUDBG_SUCCESS)                                                 \
        return res;                                                           \
} while (0)

#endif
