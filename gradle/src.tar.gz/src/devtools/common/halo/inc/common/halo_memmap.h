/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef _HALO_HALO_MEMMAP_H
#define _HALO_HALO_MEMMAP_H 1

#include <halo.h>
#include <cudadebugger.h>
#include <tools_shared_rangemap.h>

typedef struct haloMemorySegment_st haloMemorySegment;
typedef struct haloMemoryMap_st haloMemoryMap;
typedef struct haloMemorySwCacheLine_st haloMemorySwCacheLine;

typedef CUDBGResult (*haloMemoryMapFunctor) (haloMemoryMap *map, haloMemorySegment *segment, void *data);

typedef enum {
    HALO_MEM_SEG_FUNC,
    HALO_MEM_SEG_LOCAL_DEFAULT,
    HALO_MEM_SEG_LOCAL_NONDEFAULT,
    HALO_MEM_SEG_STACK,
    HALO_MEM_SEG_GLOBAL,
    HALO_MEM_SEG_DEVICE_VIRTUAL,
    HALO_MEM_SEG_PINNED_SYSMEM,
    HALO_MEM_SEG_MANAGED,
} haloMemorySegmentType;

struct haloMemorySegment_st {
    haloMemorySegmentType        type;           /* Type of segment */
    uint64_t                     devvaddr;       /* Device Vaddr */
    uint64_t                     uvavaddr;       /* Device UVA Vaddr */
    uint64_t                     size;           /* Size of memblock */
    uint64_t                     hosthandle;     /* Unique handle for the CUmemblock */
    uint64_t                     sourceMemblock; /* Unique handle for the source CUmemblock */
    uint32_t                     hasDevPtr;      /* Has a DevPtr */
    uint32_t                     usesNvmap;      /* Set if segment is through nvmap */
    uint64_t                     devptr;         /* Device Ptr */
    uint64_t                     hostvaddr;      /* System memory address */

#ifdef CUDBG_ENABLE_IFB
    /* IFB offset (DMA mapped in application process space) */
    uint64_t ifbOffset;
#endif

    /* Host pointer to mapped device memory */
    uint64_t mappedHostPtr;

    /* Original handle */
    uint32_t mem;

    /* The dup'd handle */
    uint32_t newmem;

    /* Client that owns the segment */
    uint32_t client;

    /* Index of device that owns the segment */
    uint32_t sourceDeviceIdx;

    /* Timestamp of last use */
    uint64_t lastUsed;

    struct {
        uint64_t start;
        uint64_t size;
    } mapped;

    uint32_t blockType;
    uint32_t apiSource;
    uint32_t location;
    uint32_t owner;
    uint32_t sharing;
    uint32_t userOwnsData;

    struct {
        /* True if segment can be cached */
        bool enabled;
        /* Holds pieces of segment that is cached */
        tRangeMap *swCacheLines;
    } cache;
};

typedef struct {
    uint64_t startAddress;
    uint64_t size;
} HaloMemoryRegion;

typedef enum {
    /* Turn off caching of memory segment (directly access memory each time) */
    HALO_MEM_SEG_CACHE_DISABLE = 0,
    /* Turn on caching of memory segment  (cache will be filled next access) */
    HALO_MEM_SEG_CACHE_ENABLE,
    /* Flush and invalidate the memory segment's cache (cache will be refilled next access) */
    HALO_MEM_SEG_CACHE_INVALIDATE,
    /* Flush the memory segment's cache (dirty cache lanes are pushed to backing storage) */
    HALO_MEM_SEG_CACHE_FLUSH,
} HaloMemorySegmentCacheOp;

typedef CUDBGResult (*haloTraverseHostVAMapCb)(uint64_t address, uint64_t size, void *entry, void* data);

/* Map functions  */
CUDBGResult haloMemoryMapCreate(haloMemoryMap **pMap, haloMemoryMap *parentMap);
CUDBGResult haloMemoryMapDestroy(haloMemoryMap *map);
CUDBGResult haloMemoryMapAddSegment(haloMemoryMap *map, uint64_t hosthandle, uint64_t sourceMemblock,
                                    haloMemorySegmentType type, uint64_t devvaddr, uint64_t uvavaddr,
                                    uint64_t size, uint32_t handle, uint32_t client, uint32_t sourceDeviceIdx,
                                    uint32_t blockType, uint32_t apiSource, uint32_t location,
                                    uint32_t owner, uint32_t sharing, uint32_t userOwnsData, uint32_t usesNvmap, haloMemorySegment **pSegment);
CUDBGResult haloMemoryMapRemoveSegment(haloMemoryMap *map, uint64_t devvaddr);
CUDBGResult haloMemoryMapGetSegmentByDevVaddrInMap(haloMemoryMap *map, uint64_t devvaddr, haloMemorySegment **pSegment);
CUDBGResult haloMemoryMapGetSegmentByDevVaddr(haloMemoryMap *map, uint64_t devvaddr, haloMemorySegment **pSegment);
CUDBGResult haloMemoryMapGetSegmentByDevPtr(haloMemoryMap *map, uint64_t devPtr, haloMemorySegment **pSegment);
CUDBGResult haloMemoryMapGetSegmentByHostVA(haloMemoryMap *map, uint64_t hostVA, haloMemorySegment **pSegment);
CUDBGResult haloMemoryMapApplyFunctor(haloMemoryMap *map, haloMemoryMapFunctor fn, void *data);
CUDBGResult haloMemoryMapTranslateToDevVaddr(haloMemoryMap *map, haloMemorySegmentType type, uint64_t addr, uint64_t *devvaddr);
CUDBGResult haloMemoryMapGetMaxAge(haloMemoryMap *map, uint64_t currentTime, uint64_t *maxAge);
uint64_t haloMemoryMapGetMemUseCurrentTime(haloMemoryMap *map);
void haloMemoryMapSetMemUseCurrentTime(haloMemoryMap *map, uint64_t memUseCurrentTime);
haloMemoryMap* haloMemoryMapGetParentMemMap(haloMemoryMap *map);
CUDBGResult haloMemoryMapTraverseGlobalHostVAMap(haloTraverseHostVAMapCb pfn, void *userData);

/* Segment functions */
CUDBGResult haloMemorySegmentModifyDevPtr(haloMemoryMap *map, haloMemorySegment *seg, uint32_t hasDevPtr, uint64_t devptr);
CUDBGResult haloMemorySegmentModifyHostVA(haloMemoryMap *map, haloMemorySegment *seg, uint64_t hostvaddr);
CUDBGResult haloMemorySegmentModifyType(haloMemoryMap *map, haloMemorySegment *seg, haloMemorySegmentType type);
uint32_t    haloMemorySegmentGetBlockType(haloMemorySegment *seg);
CUDBGResult haloMemoryMapGetDptrRangeMap(haloMemoryMap *map, tRangeMap **dptrMap);
CUDBGResult haloMemoryRangeCacheOp(haloMemoryMap* map, uint64_t devvaddr, uint64_t size, HaloMemorySegmentCacheOp cacheOp);
CUDBGResult haloMemoryMapCacheOp(haloMemoryMap* map, HaloMemorySegmentCacheOp cacheOp);
CUDBGResult haloMemoryReadSwCache(haloMemoryMap* map, uint64_t devvaddr, uint64_t sz, void *buf);
CUDBGResult haloMemoryWriteSwCache(haloMemoryMap* map, uint64_t devvaddr, uint64_t sz, void *buf);
CUDBGResult haloMemoryGetDevVaddrRangeMap(haloMemoryMap* map, tRangeMap **pRangeMap);

#endif

