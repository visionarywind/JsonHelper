/*
 * Copyright 2014-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef PASCAL_SCRATCHPAD_H
#define PASCAL_SCRATCHPAD_H

#include <halo_scratchpad_consts.h>

typedef struct {
    uint32_t threadIdx;        // SR32 / SR_Tid / threadIdx.{x,y,z}
    uint32_t r1;               // Special case, needed for stack check
} PascalLaneScratchpad_t;

/* Perf note:

   If a field is only modified before a context load, and is only
   accessed after a context load, it is safe and necessary to cached
   the field. One example of this is the preemptCommand field in top
   level scratchpad. Without caching, such accesses to sysmem will
   cause serious traphandler perf issue.

   Since GP10x does not enable L1 cache by default, such fields should
   be loaded with LD.E.CI instead of CA. */


/* The warp scratchpad.  Compared with Fermi, a few of the fields no
   longer come from S2Rs (they've been removed).  Instead, those fields
   are now a part of the QMD and stored in a per-launch constbank in
   accordance with the DCI. */
typedef struct {
    uint32_t virtID;               // SR3
    uint32_t ctaParam;             // QMD / c[0][0x48] CRS size per warp (pushed by method)
    uint32_t blockIdxX;            // SR37
    uint32_t blockIdxY;            // SR38
    uint32_t blockIdxZ;            // SR39
    uint32_t blockDimX;            // QMD / c[0][0x28]
    uint32_t blockDimY;            // QMD / c[0][0x2c]
    uint32_t blockDimZ;            // QMD / c[0][0x30]
    uint32_t gridId64Lo;           // Low 32 bits of gridId64
    uint32_t gridDimX;             // QMD / c[0][0x34]
    uint32_t gridDimY;             // QMD / c[0][0x38]
    uint32_t gridDimZ;             // QMD / c[0][0x3c]
    uint32_t shmemSizePrBlock;     // SR50
    uint32_t lmemWindowSize;       // SR53
    uint32_t lmemLoSizePrThread;   // SR54
    uint32_t lmemHiOff;            // SR55
    uint32_t globalErrorStatus;    // SR64
    uint32_t warpErrorStatus;      // SR66
    uint32_t warpBarrierState;     // This warp's barrier state
    uint32_t selfQMDLo;            // (Lo-bits) Pointer to the GPU QMD launch structure that belongs to this warp's grid
    uint32_t selfQMDHi;            // (Hi-bits) Pointer to the GPU QMD launch structure that belongs to this warp's grid
    uint32_t paramConstDptrLo;     // (Lo-bits) Pointer to the parameter bank of this warp's grid.
    uint32_t paramConstDptrHi;     // (Hi-bits) Pointer to the parameter bank of this warp's grid.
    uint32_t cirQueueIncrMinusOne; // SR41 - Increment of work (-1) associated with this CTA, also holds isQueue
    uint32_t lmemBaseLo;           // (Lo-bits) This warp's lmemBase (either default, or set via SETLMEMBASE)
    uint32_t lmemBaseHi;           // (Hi-bits) This warp's lmemBase (either default, or set via SETLMEMBASE)
    uint32_t crsPtr;               // The result of GETCRSPTR
    uint32_t gridId64Hi;           // High 32 bits of gridId64
    PascalLaneScratchpad_t lane[32];
    uint32_t mpsContextId;         // 32 bit client Context ID under MPS
    uint32_t singleStepNsteps;     // How many single steps to perform; pause is executed when nsteps reaches 0
    uint8_t warpFlagsValidOnSave;  // Warp was valid on save
    uint8_t warpFlagsPauseServiced;  // Warp was valid on save
    uint8_t warpFlagsReserved[2];  // Reserved flags
} PascalWarpScratchpad_t;

/* The SM scratchpad */
typedef struct {
    uint64_t pauseServicedMask[2];  // Used for determining if a BPT.PAUSE has been properly serviced
    uint64_t saveWarpMask[2];       // Bitmask of warps that CILP saved out
    uint64_t warpTrapMask[2];       // Bitmask of trapped warps (set immediately before pause)
    uint64_t padding[2];            // Some padding
} PascalSMScratchpad_t;

/* The Scratchpad to the (soon) zerocopy chunk of memory use to
   communicate between the traphandler and the debugger */
typedef struct {
    uint32_t         active;     // to identify the active context on the device
    uint32_t         preemptCommand; // Used for preemption-style debugging
    uint32_t         padding[2]; // force alignment to 128 because shared to global copy uses ST128.
    PascalWarpScratchpad_t warp[CUDBG_MAX_TOTAL_SMS_PASCAL][CUDBG_MAX_WARP_PASCAL]; // 128-bit aligned
    PascalSMScratchpad_t sm[CUDBG_MAX_TOTAL_SMS_PASCAL];
    // More stuff here ...
} PascalScratchpad_t;

/* For scratchpad allocation (done in cudbgdriver.c):

   Params for each warp:
        (CTAParam + GridParam + LWINSZ + LmemLoSz + LmemHiOff + SharedMem)

   Shared memory (Max shared mem for each SM is 48K):
        For pascal, SharedMem = 48K * # of SMs = 48K * 16;

   See pascal_collectScratchpad in halo/pascal_gp10x.c for how the scratchpad is used. */
#define PASCAL_GP10X_MAX_SHARED_MEM_PER_CTA              (48*1024)
#define PASCAL_GP10X_TRAP_HANDLER_SCRATCHPAD_PARAMS_SIZE (sizeof(PascalScratchpad_t))
#define PASCAL_GP10X_TRAP_HANDLER_SCRATCHPAD_SHARED_SIZE PASCAL_GP10X_MAX_SHARED_MEM_PER_CTA
#define PASCAL_GP10X_TRAP_HANDLER_SCRATCHPAD_SIZE        (PASCAL_GP10X_TRAP_HANDLER_SCRATCHPAD_PARAMS_SIZE + \
                                                          PASCAL_GP10X_TRAP_HANDLER_SCRATCHPAD_SHARED_SIZE)

/* Shared memory offset (in bytes) within the trap handler scratchpad allocation */
#define PASCAL_GP10X_TRAP_HANDLER_SCRATCHPAD_OFFSET_SHARED PASCAL_GP10X_TRAP_HANDLER_SCRATCHPAD_PARAMS_SIZE

typedef enum {
	PASCAL_GP10X_PREEMPT_COMMAND_NONE              = 0x0,
	PASCAL_GP10X_PREEMPT_COMMAND_PAUSE_ON_RESTORE  = 0x1,
	PASCAL_GP10X_PREEMPT_COMMAND_SAVE_ON_PAUSE     = 0x2,
	PASCAL_GP10X_PREEMPT_COMMAND_RESTORE_ON_RESUME = 0x3,
} PascalPreemptCommand;
#endif
