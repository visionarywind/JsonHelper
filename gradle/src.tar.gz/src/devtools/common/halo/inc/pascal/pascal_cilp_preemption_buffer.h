/*
 * Copyright 2014-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef __PASCAL_CILP_PREEMPTION_BUFFER_H__
#define __PASCAL_CILP_PREEMPTION_BUFFER_H__

#include "nvctassert.h"
#include "cui/hal/pascal/pascal_arch_consts.h"
// For offset checks
#include "asm/arch_include/sm_60/cilp_buffer_offsets.h"

// From drivers/gpgpu/cuda/src/asm/arch_include/sm_60/cilp_buffer.h,
// with type names prefixed with CU.
//

// NOTE: all structures are currently padded to 8B

#pragma pack(push,1)

typedef struct CUpascalLanePRCCState_st {
    uint8_t pr;
    uint8_t cc;
} CUpascalLanePRCCState;

typedef struct CUpascalWarpCILPBuffer_st {
    uint64_t LMEMBASE;
    uint32_t RFDataIdx; // Offset into RFData, SR_regAlloc tells us how many
    uint32_t CRSPTR;
    uint32_t BARState;
    uint32_t reservedPad1[3];
    CUpascalLanePRCCState PRCC[CU_PASCAL_ARCH_CONST_HW_SM_MAX_THREADS_PER_WARP];
} CUpascalWarpCILPBuffer;

typedef struct CUpascalCTACILPBuffer_st {
    uint32_t shmemDataIdx; // Offset into shmemData, SR_SMemSz tells us how much
    uint32_t reservedPad1[3];
    uint32_t BARState[CU_PASCAL_ARCH_CONST_HW_SM_MAX_BARRIERS_PER_CTA];
} CUpascalCTACILPBuffer;

typedef struct CUpascalSMCILPBuffer_st {
    uint32_t RFDataIdxSync; // used to calculate RFDataIdx values, by one thread per warp
    uint32_t shmemDataIdxSync; // used to calculate shmemDataIdx values, by one thread per CTA
    uint32_t validPendingState[4]; // one bit per warp to indicate that lmem-hi has valid state about pending events
    uint32_t reservedPad1[2];
    uint32_t RFData[CU_PASCAL_ARCH_CONST_HW_SM_RF_SIZE_WORDS]; // IMPORTANT: This needs to be 128B aligned!!!
    uint32_t shmemData[CU_PASCAL_ARCH_CONST_HW_SM_MAX_SHARED_MEMORY_PER_SM_WORDS];
    CUpascalWarpCILPBuffer warpData[CU_PASCAL_ARCH_CONST_HW_SM_MAX_WARPS_PER_SM];
    CUpascalCTACILPBuffer CTAData[CU_PASCAL_ARCH_CONST_HW_SM_MAX_CTAS_PER_SM];
} CUpascalSMCILPBuffer;
#pragma pack(pop)

// Checks for per warp data offsets
ct_assert(offsetof(CUpascalWarpCILPBuffer, LMEMBASE) == offset_PascalWarpCILPBuffer_t_LMEMBASE);
ct_assert(offsetof(CUpascalWarpCILPBuffer, RFDataIdx) == offset_PascalWarpCILPBuffer_t_RFDataIdx);
ct_assert(offsetof(CUpascalWarpCILPBuffer, CRSPTR) == offset_PascalWarpCILPBuffer_t_CRSPTR);
ct_assert(offsetof(CUpascalWarpCILPBuffer, BARState) == offset_PascalWarpCILPBuffer_t_BARState);
ct_assert(offsetof(CUpascalWarpCILPBuffer, reservedPad1) == offset_PascalWarpCILPBuffer_t_reservedPad1);
ct_assert(offsetof(CUpascalWarpCILPBuffer, PRCC) == offset_PascalWarpCILPBuffer_t_PRCC);
ct_assert(sizeof(CUpascalWarpCILPBuffer) == sizeof_PascalWarpCILPBuffer_t);

// Check per CTA data offsets
ct_assert(offsetof(CUpascalCTACILPBuffer, shmemDataIdx) == offset_PascalCTACILPBuffer_t_shmemDataIdx);
ct_assert(offsetof(CUpascalCTACILPBuffer, reservedPad1) == offset_PascalCTACILPBuffer_t_reservedPad1);
ct_assert(offsetof(CUpascalCTACILPBuffer, BARState) == offset_PascalCTACILPBuffer_t_BARState);
ct_assert(sizeof(CUpascalCTACILPBuffer) == sizeof_PascalCTACILPBuffer_t);

// Check per SM data offsets
ct_assert(offsetof(CUpascalSMCILPBuffer, RFDataIdxSync) == offset_PascalSMCILPBuffer_t_RFDataIdxSync);
ct_assert(offsetof(CUpascalSMCILPBuffer, shmemDataIdxSync) == offset_PascalSMCILPBuffer_t_shmemDataIdxSync);
ct_assert(offsetof(CUpascalSMCILPBuffer, validPendingState) == offset_PascalSMCILPBuffer_t_validPendingState);
ct_assert(offsetof(CUpascalSMCILPBuffer, reservedPad1) == offset_PascalSMCILPBuffer_t_reservedPad1);
ct_assert(offsetof(CUpascalSMCILPBuffer, RFData) == offset_PascalSMCILPBuffer_t_RFData);
ct_assert(offsetof(CUpascalSMCILPBuffer, shmemData) == offset_PascalSMCILPBuffer_t_shmemData);
ct_assert(offsetof(CUpascalSMCILPBuffer, warpData) == offset_PascalSMCILPBuffer_t_warpData);
ct_assert(offsetof(CUpascalSMCILPBuffer, CTAData) == offset_PascalSMCILPBuffer_t_CTAData);
ct_assert(sizeof(CUpascalSMCILPBuffer) == sizeof_PascalSMCILPBuffer_t);

#endif // __PASCAL_CILP_PREEMPTION_BUFFER_H__
