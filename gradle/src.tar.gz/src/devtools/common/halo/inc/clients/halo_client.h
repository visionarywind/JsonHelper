/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: halo_client.h
 *
 *   Description:
 *      Defines for common halo client functions.
 *
 ******************************************************************************/
#ifndef HALO_CLIENT_H
#define HALO_CLIENT_H

#include "halo.h"

#if cuosOsIsLinux()
#define CUDBG_BAR0_START                0x0
#define CUDBG_BAR0_SIZE                 0x600000
#define CUDBG_BAR0_PFIFO_REGS_START     0x2000
#define CUDBG_BAR0_PFIFO_REGS_SIZE      0x2000
#define CUDBG_BAR0_PFB_REGS_START       0x100000
#define CUDBG_BAR0_PFB_REGS_SIZE        0x1000

#define CUDBG_VERIFY_REGADDR(addr) {                                                    \
    uint64_t bar0Offset = addr - dev->bar0;                                             \
    uint32_t pgraphStart = 0, pgraphSize = 0;                                           \
    CUDBGResult res = dev->halo.getPgraphBar0Extents(dev, &pgraphStart, &pgraphSize);   \
    if (res != CUDBG_SUCCESS) {                                                         \
        HALO_ERROR("Could not get PGRAPH extents for device %d (0x%x)\n",               \
                    dev->deviceIdx, res);                                               \
        return res;                                                                     \
    }                                                                                   \
    if (!((bar0Offset >= CUDBG_BAR0_PFIFO_REGS_START &&                                 \
           bar0Offset <  CUDBG_BAR0_PFIFO_REGS_START + CUDBG_BAR0_PFIFO_REGS_SIZE) ||   \
          (bar0Offset >= CUDBG_BAR0_PFB_REGS_START &&                                   \
           bar0Offset <  CUDBG_BAR0_PFB_REGS_START + CUDBG_BAR0_PFB_REGS_SIZE) ||       \
          (bar0Offset >= pgraphStart && bar0Offset < pgraphStart + pgraphSize))) {      \
        HALO_ERROR("Invalid register offset 0x%llx\n",                                  \
                   (unsigned long long)bar0Offset);                                     \
        return CUDBG_ERROR_INTERNAL;                                                    \
    }                                                                                   \
}
#else
// Only map the range from 0x2000 to 0x6fffff. The RM disallows mapping 0x1000 to 0x2000
// and 0x700000 to 0x100000 due to security implications.
#define CUDBG_BAR0_START 0x00002000
#define CUDBG_BAR0_SIZE  0x006FE000

#define CUDBG_VERIFY_REGADDR(addr) {                        \
    uint64_t bar0Offset = addr - dev->bar0;                 \
    if (bar0Offset < CUDBG_BAR0_START ||                    \
        bar0Offset >= CUDBG_BAR0_START + CUDBG_BAR0_SIZE) { \
        HALO_ERROR("Invalid register offset 0x%llx\n",      \
                   (unsigned long long)bar0Offset);         \
        return CUDBG_ERROR_INTERNAL;                        \
    }                                                       \
}
#endif

CUDBGResult haloClientInit(uint32_t haloType);
CUDBGResult haloClientFinalize(void);

#endif

