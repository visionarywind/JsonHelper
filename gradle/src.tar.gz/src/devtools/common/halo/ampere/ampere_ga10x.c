/*
 * Copyright 2018 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: ampere_ga10x.c
 *
 *   Description:
 *       Internal API for the low-level GPU access needed to support
 *       the debugger on Ampere (GA10x).
 *
 ******************************************************************************/

#include "cudadebugger.h"
#include "halo_internal.h"
#include "halo_state.h"
#include "tools_shared_dwarf.h"
#include "turing_tu10x.h"
#include "ampere.h"
#include "ampere_ga10x.h"
#include "ampere_scratchpad.h"
#include "ampere_cilp_preemption_buffer.h"
#include "ampere/ga100/dev_graphics_nobundle.h"
#include "fermi_mcinterop.h"
#include "ampere/ampere_structs.h"

CUDBGResult
ampere_ga10x_getInfo(CudbgDevice dev)
{
    CUDBGResult res;

    res = turing_tu10x_getInfo(dev);

    /* Overwrite the constants that are different */
    dev->halo.deviceInfo.numUniformRegsPrWarp       = CUDBG_MAX_UREG_AMPERE;
    dev->halo.deviceInfo.numUniformPredicatesPrWarp = CUDBG_MAX_UPRED_AMPERE;

    return res;
}

static CUDBGResult
ampere_ga10x_getSavedSPLmemAddr(CudbgDevice dev, uint64_t *lmem_addr)
{
    CUDBG_VERIFY(lmem_addr,
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments\n");

    *lmem_addr = AMPERE_LMEM_SAVED_STACK_POINTER;
    return CUDBG_SUCCESS;
}

static CUDBGResult
ampere_ga10x_getPauseReasonTableWarpOffset(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t* offset)
{
    CUDBG_VERIFY(offset && dev, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");
    *offset = (CUDBG_MAX_WARP_AMPERE * vsm + wp) * sizeof(uint32_t);
    return CUDBG_SUCCESS;
}

/* Get offset of gridId in GridParams. This is DCI dependent, hence halified. */
static CUDBGResult
ampere_ga10x_getGridParamsOffsetGridId(CudbgDevice dev, uint64_t *offset)
{
    CUDBG_VERIFY(offset, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");

    *offset = ((uint64_t)(uintptr_t)&((CUampereGridParams *)0)->gridId);

    return CUDBG_SUCCESS;
}

/* Get offset of blockDim in GridParams. This is DCI dependent, hence halified.*/
static CUDBGResult
ampere_ga10x_getGridParamsOffsetBlockDim(CudbgDevice dev, uint64_t *offset,
                                        uint32_t *size)
{
    CUDBG_VERIFY(offset && size, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");

    *offset = ((uint64_t)(uintptr_t)&((CUampereGridParams *)0)->blockDim);
    *size = sizeof ((CUampereGridParams *)0)->blockDim;

    return CUDBG_SUCCESS;
}

/* Get offset of gridDim in GridParams. This is DCI dependent, hence halified.*/
static CUDBGResult
ampere_ga10x_getGridParamsOffsetGridDim(CudbgDevice dev, uint64_t *offset,
                                       uint32_t *size)
{
    CUDBG_VERIFY(offset && size, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");

    *offset = ((uint64_t)(uintptr_t)&((CUampereGridParams *)0)->gridDim);
    *size = sizeof ((CUampereGridParams *)0)->gridDim;

    return CUDBG_SUCCESS;
}

/* Get offset of startPc in GridParams. This is DCI dependent, hence halified.*/
static CUDBGResult
ampere_ga10x_getGridParamsOffsetStartPc(CudbgDevice dev, uint64_t *offset)
{
    CUDBG_VERIFY(offset, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");

    *offset = CNP_GRID_PARAM_OFFSET(startPc);

    return CUDBG_SUCCESS;
}

static CUDBGResult
ampere_ga10x_readUniformRegisterFile(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                     uint64_t offset, void *buf, uint32_t bufSz)
{ 
    CUDBGResult res;
    size_t fieldOffset = 0, fieldWidth = 0;
    uint32_t offset32 = (uint32_t) offset;
    Context context = dev->activeContext;

    /* If no active context, there is nothing we can do. */
    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT,
                 "No active context found in ampere_ga10x_readUniformRegisterFile\n");

    CUDBG_VERIFY(((uint64_t) offset32 == offset && !((offset32 | bufSz) & 3)),
                 CUDBG_ERROR_INVALID_MEMORY_ACCESS,
                 "Invalid memory access in ampere_ga10x_readUniformRegisterFile\n");

    res = dev->halo.preemptionBuffer.getFieldOffset(HALO_PREEMPTION_BUFFER_FIELD_UREG,
                                              HALO_PREEMPTION_BUFFER_SECTION_WARP,
                                              vsm, 0, wp, 0, &fieldOffset, &fieldWidth);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "could not get UREG base address");
    CUDBG_VERIFY(offset + bufSz <= fieldWidth, CUDBG_ERROR_INVALID_ARGS, "invalid offset+bufSz");

    res = dev->halo.readDeviceMemory(context,
                                     context->cilpBufferDevVA + fieldOffset + offset,
                                     buf,
                                     bufSz);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "could not read device memory");

    return res;
}

static CUDBGResult
ampere_ga10x_writeUniformRegisterFile(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                      uint64_t offset, const void *buf, uint32_t bufSz)
{
    CUDBGResult res;
    size_t fieldOffset = 0, fieldWidth = 0;
    uint32_t offset32 = (uint32_t) offset;
    Context context = dev->activeContext;

    /* If no active context, there is nothing we can do. */
    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT,
                 "No active context found in writeUniformRegisterFile.\n");

    CUDBG_VERIFY(((uint64_t) offset32 == offset && !((offset32 | bufSz) & 3)),
                 CUDBG_ERROR_INVALID_MEMORY_ACCESS,
                 "Invalid memory access.\n");

    res = dev->halo.preemptionBuffer.getFieldOffset(HALO_PREEMPTION_BUFFER_FIELD_UREG,
                                              HALO_PREEMPTION_BUFFER_SECTION_WARP,
                                              vsm, 0, wp, 0, &fieldOffset, &fieldWidth);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "could not get UREG base address");
    CUDBG_VERIFY(offset + bufSz <= fieldWidth, CUDBG_ERROR_INVALID_ARGS, "invalid offset+bufSz");

    res = dev->halo.writeDeviceMemory(context,
                                      context->cilpBufferDevVA + fieldOffset + offset,
                                      buf,
                                      bufSz);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "could not write device memory");

    return res;
}

static CUDBGResult
ampere_ga10x_readUniformPredicates(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                   uint32_t numPreds, uint32_t *predicates)
{
    CUDBGResult res;
    uint32_t i;
    uint32_t predicateReg = 0;

    CUDBG_VERIFY(predicates, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args in pascal_gp10x_readUniformPredicates\n");
    CUDBG_VERIFY(numPreds <= dev->halo.deviceInfo.numUniformPredicatesPrWarp,
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid # of uniform predicates\n");

    /* Read predicate register contents */
    res = dev->halo.preemptionBuffer.read_UPR(dev->activeContext->preemptionBufferAccessor, vsm, wp, &predicateReg);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read UPR\n");

    /* Predicates are backed in the LSBs of PR */
    for (i = 0; i < numPreds; i++) {
        predicates[i] = (predicateReg >> i) & 1U;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
ampere_ga10x_writeUniformPredicates(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                    uint32_t numPreds, const uint32_t *predicates)
{
    CUDBGResult res;
    uint32_t i;
    uint32_t predicateReg = 0;

    CUDBG_VERIFY(predicates, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args in ampere_ga10x_writeUniformPredicates\n");
    CUDBG_VERIFY(numPreds <= dev->halo.deviceInfo.numUniformPredicatesPrWarp,
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid # of uniform predicates\n");

    /* Read predicate register contents */
    res = dev->halo.preemptionBuffer.read_UPR(dev->activeContext->preemptionBufferAccessor, vsm, wp, &predicateReg);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read UPR\n");

    /* Modify predicate register based on inputs */
    for (i = 0; i < numPreds; i++) {
        CUDBG_VERIFY(predicates[i] < 2, CUDBG_ERROR_INVALID_ARGS, "Invalid uniform predicate value\n");
        predicateReg = (predicateReg & ~(1U << i)) | (predicates[i] << i);
    }

    /* Write updated predicate register back to backing store */
    res = dev->halo.preemptionBuffer.write_UPR(dev->activeContext->preemptionBufferAccessor, vsm, wp, predicateReg);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to write UPR\n");

    dev->activeContext->saveBufferState = HALO_SAVE_BUFFER_STATE_DIRTY;

    return CUDBG_SUCCESS;
}

/* Scratchpad access */

static CUDBGResult
ampere_ga10x_scratchpad_getGlobalFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_SCRATCHPAD_GET_OFFSET_CASE(ACTIVE, AmpereScratchpad_t, active);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PREEMPT_COMMAND, AmpereScratchpad_t, preemptCommand);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PADDING, AmpereScratchpad_t, padding);
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
ampere_ga10x_scratchpad_getWarpFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_SCRATCHPAD_GET_OFFSET_CASE(VIRT_ID, AmpereWarpScratchpad_t, virtID);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_IDX_X, AmpereWarpScratchpad_t, blockIdxX);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_IDX_Y, AmpereWarpScratchpad_t, blockIdxY);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_IDX_Z, AmpereWarpScratchpad_t, blockIdxZ);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_DIM_X, AmpereWarpScratchpad_t, blockDimX);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_DIM_Y, AmpereWarpScratchpad_t, blockDimY);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_DIM_Z, AmpereWarpScratchpad_t, blockDimZ);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_PARAM, AmpereWarpScratchpad_t, gridId);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_DIM_X, AmpereWarpScratchpad_t, gridDimX);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_DIM_Y, AmpereWarpScratchpad_t, gridDimY);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_DIM_Z, AmpereWarpScratchpad_t, gridDimZ);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SHMEM_SIZE_PR_BLOCK, AmpereWarpScratchpad_t, shmemSizePrBlock);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_WINDOW_SIZE, AmpereWarpScratchpad_t, lmemWindowSize);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_LO_SIZE_PR_THREAD, AmpereWarpScratchpad_t, lmemLoSizePrThread);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_HI_OFF, AmpereWarpScratchpad_t, lmemHiOff);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GLOBAL_ERROR_STATUS, AmpereWarpScratchpad_t, globalErrorStatus);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_ERROR_STATUS, AmpereWarpScratchpad_t, warpErrorStatus);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_ERROR_PC, AmpereWarpScratchpad_t, warpErrorPC);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_BARRIER_STATE, AmpereWarpScratchpad_t, warpBarrierState);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SELF_QMD, AmpereWarpScratchpad_t, selfQMDAddr);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PARAM_CONST_DPTR, AmpereWarpScratchpad_t, paramConstDptr);
        /* HACK! CIR_QUEUE_INCR_MINUS_ONE is always just used to check if the CTA is queued */
        HALO_SCRATCHPAD_GET_OFFSET_CASE(CIR_QUEUE_INCR_MINUS_ONE, AmpereWarpScratchpad_t, isQueueCTA);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_BASE, AmpereWarpScratchpad_t, lmemBase);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(MPS_CONTEXT_ID, AmpereWarpScratchpad_t, mpsContextId);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SUBCONTEXT_VSMID, AmpereWarpScratchpad_t, subContextVSMId);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SINGLESTEP_NSTEPS, AmpereWarpScratchpad_t, singleStepNsteps);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_FLAG_VALID_ON_SAVE, AmpereWarpScratchpad_t, warpFlagsValidOnSave);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_FLAG_PAUSE_SERVICED, AmpereWarpScratchpad_t, warpFlagsPauseServiced);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(REGISTER_COUNT, AmpereWarpScratchpad_t, regCount);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_ACTIVE_MASK, AmpereWarpScratchpad_t, trapReturnMask);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_TRAP_RPC, AmpereWarpScratchpad_t, trapReturnPC);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_EXITED_MASK, AmpereWarpScratchpad_t, warpExitedMask);
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
ampere_ga10x_scratchpad_getLaneFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_SCRATCHPAD_GET_OFFSET_CASE(THREAD_IDX, AmpereLaneScratchpad_t, threadIdx);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(R1, AmpereLaneScratchpad_t, r1);
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
ampere_ga10x_scratchpad_getSmFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
ampere_ga10x_scratchpad_getFieldOffset(HaloScratchpadField field, HaloScratchpadSection section,
    uint32_t sm, uint32_t wp, uint32_t ln, size_t *offset, size_t *width)
{
    size_t base = 0;
    CUDBGResult res;

    switch (section) {
    case HALO_SCRATCHPAD_SECTION_GLOBAL:
        res = ampere_ga10x_scratchpad_getGlobalFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_SCRATCHPAD_SECTION_WARP:
        base = OFFSETOF_NONCONST(AmpereScratchpad_t, warp[sm][wp]);
        res = ampere_ga10x_scratchpad_getWarpFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_SCRATCHPAD_SECTION_SM:
        base = OFFSETOF_NONCONST(AmpereScratchpad_t, sm[sm]);
        res = ampere_ga10x_scratchpad_getSmFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_SCRATCHPAD_SECTION_LANE:
        base = OFFSETOF_NONCONST(AmpereScratchpad_t, warp[sm][wp]) +
            OFFSETOF_NONCONST(AmpereWarpScratchpad_t, lane[ln]);
        res = ampere_ga10x_scratchpad_getLaneFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    default:
        *offset = 0;
        *width = 0;
        HALO_TRACE_FUNCTION(0, "Invalid scratchpad section %d\n", section);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    *offset += base;

    return res;
}

/* Preemption buffer access */

static CUDBGResult
ampere_ga10x_preemptionBuffer_getLaneFieldOffset(HaloPreemptionBufferField field, uint32_t ln, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(RPC, CUampereWarpCILPBuffer, CBU_RPC[ln]);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(PR, CUampereWarpCILPBuffer, PR[ln]);
    default:
        *width = 0;
        *offset = 0;
        HALO_TRACE_FUNCTION(0, "Invalid CILP buffer lane field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
ampere_ga10x_preemptionBuffer_getWarpFieldOffset(HaloPreemptionBufferField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(BAR, CUampereWarpCILPBuffer, CBU_BAR);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_TRAP_RPC, CUampereWarpCILPBuffer, CBU_TRAP_RETURN_PC);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(ATEXIT_PC, CUampereWarpCILPBuffer, CBU_ATEXITPC);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_ACTIVE_MASK, CUampereWarpCILPBuffer, CBU_TRAP_RETURN_MASK);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_EXITED_MASK, CUampereWarpCILPBuffer, CBU_MEXITED);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(MATEXIT, CUampereWarpCILPBuffer, CBU_MATEXIT);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_CALL_DEPTH, CUampereWarpCILPBuffer, CBU_API_CALL_DEPTH);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(OPT_STACK, CUampereWarpCILPBuffer, CBU_OPT_STACK);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(THREAD_STATE_ENUM_0, CUampereWarpCILPBuffer, CBU_THREAD_STATE_ENUM_0);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(THREAD_STATE_ENUM_1, CUampereWarpCILPBuffer, CBU_THREAD_STATE_ENUM_1);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(THREAD_STATE_ENUM_2, CUampereWarpCILPBuffer, CBU_THREAD_STATE_ENUM_2);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(THREAD_STATE_ENUM_3, CUampereWarpCILPBuffer, CBU_THREAD_STATE_ENUM_3);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(THREAD_STATE_ENUM_4, CUampereWarpCILPBuffer, CBU_THREAD_STATE_ENUM_4);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(UPR, CUampereWarpCILPBuffer, UPR);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(UREG, CUampereWarpCILPBuffer, UReg);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(TTU_TICKET_INFO, CUampereWarpCILPBuffer, TTU_ticket_info);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(TTU_MASK, CUampereWarpCILPBuffer, TTU_mask);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(LMEMBASE, CUampereWarpCILPBuffer, LMEMBASE);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_BARSTATE, CUampereWarpCILPBuffer, BARState);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(RFDATAIDX, CUampereWarpCILPBuffer, RFDataIdx);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_RESERVED1, CUampereWarpCILPBuffer, reservedPad1);
    default:
        *width = 0;
        *offset = 0;
        HALO_TRACE_FUNCTION(0, "Invalid CILP buffer warp field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
ampere_ga10x_preemptionBuffer_getCTAFieldOffset(HaloPreemptionBufferField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(CTAID, CUampereCTACILPBuffer, CTAID);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(SHMEMDATAIDX, CUampereCTACILPBuffer, shmemDataIdx);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(CTA_RESERVEDPAD1, CUampereCTACILPBuffer, reservedPad1);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(CTA_BARSTATE, CUampereCTACILPBuffer, BARState);
    default:
        *width = 0;
        *offset = 0;
        HALO_TRACE_FUNCTION(0, "Invalid CILP buffer CTA field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
ampere_ga10x_preemptionBuffer_getSMFieldOffset(HaloPreemptionBufferField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(RFDATAIDXSYNC, CUampereSMCILPBuffer, RFDataIdxSync);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(SHMEMDATAIDXSYNC, CUampereSMCILPBuffer, shmemDataIdxSync);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(VALIDPENDINGSTATE, CUampereSMCILPBuffer, validPendingState);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(SM_RESERVEDPAD1, CUampereSMCILPBuffer, reservedPad1);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(RFDATA, CUampereSMCILPBuffer, RFData);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(SHMEMDATA, CUampereSMCILPBuffer, shmemData);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARPDATA, CUampereSMCILPBuffer, warpData);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(CTADATA, CUampereSMCILPBuffer, CTAData);
    default:
        *width = 0;
        *offset = 0;
        HALO_TRACE_FUNCTION(0, "Invalid CILP buffer SM field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
ampere_ga10x_preemptionBuffer_getFieldOffset(HaloPreemptionBufferField field, HaloPreemptionBufferSection section,
    uint32_t sm, uint32_t cta, uint32_t wp, uint32_t ln,
    size_t *offset, size_t *width)
{
    size_t base = 0;
    CUDBGResult res;

    base = sm * sizeof(CUampereSMCILPBuffer);

    switch (section) {
    case HALO_PREEMPTION_BUFFER_SECTION_SM:
        res = ampere_ga10x_preemptionBuffer_getSMFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_PREEMPTION_BUFFER_SECTION_CTA:
        base += OFFSETOF_NONCONST(CUampereSMCILPBuffer, CTAData[cta]);
        res = ampere_ga10x_preemptionBuffer_getCTAFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_PREEMPTION_BUFFER_SECTION_WARP:
        base += OFFSETOF_NONCONST(CUampereSMCILPBuffer, warpData[wp]);
        res = ampere_ga10x_preemptionBuffer_getWarpFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_PREEMPTION_BUFFER_SECTION_LANE:
        base += OFFSETOF_NONCONST(CUampereSMCILPBuffer, warpData[wp]);
        res = ampere_ga10x_preemptionBuffer_getLaneFieldOffset(field, ln, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    default:
        *width = 0;
        *offset = 0;
        HALO_TRACE_FUNCTION(0, "Invalid preemption buffer section %d\n", section);
        return CUDBG_ERROR_INVALID_ARGS;
    };

    *offset += base;
    return CUDBG_SUCCESS;
}

static CUDBGResult
ampere_ga10x_preemptionBuffer_read_UPR(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *upr)
{
    CUDBG_VERIFY(preemptionBufferAccessor && upr, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_PREEMPTION_BUFFER_GET_FIELD(preemptionBufferAccessor, WARP, UPR, vsm, 0, wp, 0, upr);

    return CUDBG_SUCCESS;
}

static CUDBGResult
ampere_ga10x_preemptionBuffer_write_UPR(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t upr)
{
    CUDBG_VERIFY(preemptionBufferAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_PREEMPTION_BUFFER_SET_FIELD(preemptionBufferAccessor, WARP, UPR, vsm, 0, wp, 0, &upr);

    return CUDBG_SUCCESS;
}

void
haloDeviceInit_ga10x(Halo_st *halo)
{
    haloDeviceInit_tu10x(halo);

    /* architectural constants - always init after base chip init */
    halo->deviceInfo.spRegisterNumber = AMPERE_ABI_SP;
    halo->deviceInfo.systemStackPointer = AMPERE_SYSTEM_STACK_POINTER;
    halo->deviceInfo.lmemSavedReturnPC = AMPERE_LMEM_SAVED_RETURN_PC;
    halo->deviceInfo.lmemSavedMExited = AMPERE_LMEM_SAVED_MEXITED;
    halo->deviceInfo.cilpBufferSizePerSM = sizeof(CUampereSMCILPBuffer);
    halo->deviceInfo.scratchpadSize = sizeof(AmpereScratchpad_t);

    halo->getInfo = ampere_ga10x_getInfo;

    /* Scratchpad/preemption buffer accessors */
    halo->getPauseReasonTableWarpOffset = ampere_ga10x_getPauseReasonTableWarpOffset;

    /* DCI overrides */
    halo->getGridParamsOffsetGridId   = ampere_ga10x_getGridParamsOffsetGridId;
    halo->getGridParamsOffsetBlockDim = ampere_ga10x_getGridParamsOffsetBlockDim;
    halo->getGridParamsOffsetGridDim = ampere_ga10x_getGridParamsOffsetGridDim;
    halo->getGridParamsOffsetStartPc = ampere_ga10x_getGridParamsOffsetStartPc;

    /* Uniform register access */
    halo->readUniformRegisterFile = ampere_ga10x_readUniformRegisterFile;
    halo->writeUniformRegisterFile = ampere_ga10x_writeUniformRegisterFile;
    halo->readUniformPredicates = ampere_ga10x_readUniformPredicates;
    halo->writeUniformPredicates = ampere_ga10x_writeUniformPredicates;

    /* Scratchpad access */

    halo->scratchpad.getFieldOffset = ampere_ga10x_scratchpad_getFieldOffset;

    /* Preemption buffer access */

    halo->preemptionBuffer.getFieldOffset = ampere_ga10x_preemptionBuffer_getFieldOffset;

    halo->preemptionBuffer.read_UPR = ampere_ga10x_preemptionBuffer_read_UPR;

    halo->preemptionBuffer.write_UPR = ampere_ga10x_preemptionBuffer_write_UPR;
}
