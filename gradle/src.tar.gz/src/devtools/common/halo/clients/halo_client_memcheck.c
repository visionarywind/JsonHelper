/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: halo_client_memcheck.c
 *
 *   Description:
 *       Contains all memory mapping and utilization functions.
 *
 ******************************************************************************/
#include "halo.h"
#include "halo_internal.h"
#include "halo_state.h"
#include "halo_client.h"
#include "fermi.h"
#include "kepler.h"
#include "rm_device.h"
#include "rm_call.h"
#if cuosOsIsLinux() || cuosOsIsApple() /* CUDA & CLH */
# include <sys/mman.h>
#endif
#include "nvRmApi.h"
#include "class/cl003f.h"
#include "ctrl/ctrl2080.h"

#include "cuda_device.h"

#include "memobj.h"
#include "halo_state.h"

#include "memobj.h"
#include "memmgr.h"
#include "memblock.h"
#include "rm_mem.h"
#include "halo_client_memcheck.h"
#include "cuictx.h"

#include "memcheck_halo.h"
#include "cuicnp.h"
#include "devtools/debugger/cudbgdriver.h"

static uint32_t activeDevices = 0;

static bool
memcheckForceClientUseDmal(void)
{
    return !!(haloGlobals.initData.flags & HALO_INIT_FLAGS_FORCE_CLIENT_DMAL);
}

/** Driver space */
CUDBGResult
haloMemcheckAddMemblock(CUctx *ctx, CUmemblock *memblock)
{
    CUDBGmemory_segment seg = {0};
    Context context;

    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context.\n");

    CUDBG_VERIFY((haloGlobals.initData.haloType == HALO_TYPE_MEMCHECK),
                 CUDBG_ERROR_INTERNAL,
                 "The HALO type is not memcheck in haloCreateMemMap. This should never happen.\n");

    context = haloStateGetContext((uint64_t)(uintptr_t)ctx);
    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context in haloCreateMemMap.\n");

    cudbgMemblockGetSegInfo(memblock, &seg);

    return haloMemoryMapAddSegmentFromInfo(context->memMap, &seg);
}

CUDBGResult
haloMemcheckRemoveMemblock(CUctx *ctx, CUmemblock *memblock)
{
    Context context;

    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context.\n");

    CUDBG_VERIFY((haloGlobals.initData.haloType == HALO_TYPE_MEMCHECK),
                 CUDBG_ERROR_INTERNAL,
                 "The HALO type is not memcheck in haloCreateMemMap. This should never happen.\n");

    context = haloStateGetContext((uint64_t)(uintptr_t)ctx);
    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context in haloCreateMemMap.\n");

    return haloMemoryMapRemoveSegment(context->memMap, memblock->devvaddr);
}

CUDBGResult
haloMemcheckAddGlobalMemblock(CUmemblock *memblock)
{
    CUDBGmemory_segment seg = {0};

    CUDBG_VERIFY((haloGlobals.initData.haloType == HALO_TYPE_MEMCHECK),
                 CUDBG_ERROR_INTERNAL,
                 "The HALO type is not memcheck in haloCreateMemMap. This should never happen.\n");

    cudbgMemblockGetSegInfo(memblock, &seg);

    return haloMemoryMapAddSegmentFromInfo(haloStateGetGlobalMemMap(), &seg);
}

CUDBGResult
haloMemcheckRemoveGlobalMemblock(CUmemblock *memblock)
{
    CUDBG_VERIFY((haloGlobals.initData.haloType == HALO_TYPE_MEMCHECK),
                 CUDBG_ERROR_INTERNAL,
                 "The HALO type is not memcheck in haloCreateMemMap. This should never happen.\n");

    return haloMemoryMapRemoveSegment(haloStateGetGlobalMemMap(), memblock->devvaddr);
}

CUDBGResult
haloMemcheckUpdateHostLmem(CUctx *ctx, uint64_t devvaddr, uint64_t size)
{
    Context context;

    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context.\n");

    CUDBG_VERIFY((haloGlobals.initData.haloType == HALO_TYPE_MEMCHECK),
                 CUDBG_ERROR_INTERNAL,
                 "The HALO type is not memcheck in haloCreateMemMap. This should never happen.\n");

    context = haloStateGetContext((uint64_t)(uintptr_t)ctx);
    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context in haloCreateMemMap.\n");

    context->defaultLmemDevVA = devvaddr;
    context->defaultLmemSize  = size;

    return CUDBG_SUCCESS;
}

CUDBGResult
haloGetCtxRMHandles(CUctx* ctx, uint32_t *hAppClient, uint32_t *hComputeObject, uint32_t *hChannelGroup, uint32_t *channelList, uint32_t numChannels, uint32_t *numAllocatedChannels)
{
    if (!ctx || !hAppClient || !hComputeObject || !hChannelGroup || !channelList)
        return CUDBG_ERROR_INVALID_ARGS;

    cudbgGetRmCtxHandles(ctx, hAppClient, hComputeObject, hChannelGroup, channelList, numChannels, numAllocatedChannels);

    return CUDBG_SUCCESS;
}

static CUDBGResult
memcheckInitPrivAccess(CudbgDevice dev)
{
    CUDBGResult res = CUDBG_SUCCESS;

    if (memcheckForceClientUseDmal())
        return dev->dmal->initPrivAccess(dev);

    dev->bar0Start = CUDBG_BAR0_START;
    dev->bar0Size  = CUDBG_BAR0_SIZE;
    dev->bar0 = 0x0;    // Force set this to 0 so that all computations are offsets
    return res;
}

static CUDBGResult
memcheckFinalizePrivAccess(CudbgDevice dev)
{
    if (memcheckForceClientUseDmal())
        return dev->dmal->finalizePrivAccess(dev);
    else
        return CUDBG_SUCCESS;
}

static CUDBGResult
memcheckMapMemory(Context context, uint64_t va, uint64_t size, char **hostPtr)
{
    CudbgDevice dev;
    CUDBGResult dbgRes = CUDBG_SUCCESS;
    CUctx *ctx = NULL;
    CUmemobj *scratchObj = NULL;
    uint64_t offset = 0;
    CUmemflags flags = {(CUmemflagsLocation)0};

    if (!context || !context->memMapActive || !hostPtr)
        return CUDBG_ERROR_INTERNAL;

    dev = context->dev;
    ctx = (CUctx*)(uintptr_t)context->cuCtx;

    /* As an optimization, on memcheck, we always try to see
       if we can directly deref the memory first. If so,
       dont bother trying to map it. This handles
       zerocopy allocations such as the scratch pad as well
       as allocations forced to host memory such as lmem/crs/funcmem
       under WDDM
    */
    scratchObj = memobjGetByDeviceVaddr(ctx->memmgr, va);
    if (scratchObj) {
        offset = va - memobjGetDeviceVaddr(scratchObj);
        flags = memobjGetFlags(scratchObj);
        if (flags.mapHost) {
            *hostPtr = (char *)memobjGetHostPtr(scratchObj);
            (*hostPtr) += offset;
            return CUDBG_SUCCESS;
        }
    }

    /* In the case of standalone memcheck, the scratchpad is already mapped
       to zero copy memory to let the driver read it. So the earlier path
       should have caught it. If it has been forced to device memory (i.e. Mac)
       then continue down to pin it. Emit trace so that we can identify this case.
       This is required as attempting to map zero copy memory returns
       NV_ERR_NOT_SUPPORTED from the map memory call */
    if (va == context->scratchpadDevVA)
        HALO_TRACE(0, "Scratchpad not in zero copy. Continuing to map\n");

    dbgRes = dev->dmal->mapMemory(context, context->memMap, va, size, hostPtr);

    if (dbgRes != CUDBG_SUCCESS)
        HALO_TRACE(10, "Mapping failed. Res:%u\n", dbgRes);

    return dbgRes;
}

static CUDBGResult
memcheckReadReg32(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint32_t* value)
{
    CUctx *cuctx = NULL;
    CUresult res = CUDA_SUCCESS;

    NvU32 tmpaddr = (NvU32)(uintptr_t)addr;
    NvU32 tmpval;
    NvU32 cutype = CU_PRI_REG_GLOBAL;

    if (memcheckForceClientUseDmal())
        return dev->dmal->readReg32(dev, regType, addr, value);

    CUDBG_VERIFY_REGADDR(addr);

    if (dev->activeContext) {
        cuctx = (CUctx*)(uintptr_t)dev->activeContext->cuCtx;
    }
    else if (dev->clientData) {
        cuctx = dev->clientData->cases.memcheck.cuctx;
    }
    else {
        HALO_ERROR("Invalid context\n");
        return CUDBG_ERROR_INVALID_CONTEXT;
    }

    if (regType == HALO_REG_OP_TYPE_GR_CTX)
        cutype = CU_PRI_REG_CONTEXT;

    res = cuiPriRegRead32(cuctx, cutype, 1, &tmpaddr, &tmpval, 0);
    if (res != CUDA_SUCCESS) {
        HALO_TRACE(10, "Failed to read 32 bit register at 0x%x on dev:%p\n", addr, dev);
        return CUDBG_ERROR_UNKNOWN;
    }
    *value = (uint32_t)tmpval;
    return CUDBG_SUCCESS;
}

static CUDBGResult
memcheckReadReg64(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint64_t* value)
{
    CUctx *cuctx = NULL;
    CUresult res = CUDA_SUCCESS;
    NvU32 tmpaddr = (NvU32)(uintptr_t)addr;
    NvU64 tmpval;
    NvU32 cutype = CU_PRI_REG_GLOBAL;

    if (memcheckForceClientUseDmal())
        return dev->dmal->readReg64(dev, regType, addr, value);

    CUDBG_VERIFY_REGADDR(addr);

    if (dev->activeContext) {
        cuctx = (CUctx*)(uintptr_t)dev->activeContext->cuCtx;
    }
    else if (dev->clientData) {
        cuctx = dev->clientData->cases.memcheck.cuctx;
    }
    else {
        HALO_ERROR("Invalid context\n");
        return CUDBG_ERROR_INVALID_CONTEXT;
    }

    if (regType == HALO_REG_OP_TYPE_GR_CTX)
        cutype = CU_PRI_REG_CONTEXT;

    res = cuiPriRegRead64(cuctx, cutype, 1, &tmpaddr, &tmpval, 0);
    if (res != CUDA_SUCCESS) {
        HALO_TRACE(10, "Failed to read 32 bit register at 0x%x on dev:%p\n", addr, dev);
        return CUDBG_ERROR_UNKNOWN;
    }
    *value = (uint64_t)tmpval;
    return CUDBG_SUCCESS;
}

static CUDBGResult
memcheckWriteReg32(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint32_t* value)
{
    CUctx *cuctx = NULL;
    CUresult res = CUDA_SUCCESS;
    NvU32 tmpaddr = (NvU32)(uintptr_t)addr;
    NvU32 tmpval = (NvU32)(*value);
    NvU32 cutype = CU_PRI_REG_GLOBAL;

    if (memcheckForceClientUseDmal())
        return dev->dmal->writeReg32(dev, regType, addr, value);

    CUDBG_VERIFY_REGADDR(addr);

    if (dev->activeContext) {
        cuctx = (CUctx*)(uintptr_t)dev->activeContext->cuCtx;
    }
    else if (dev->clientData) {
        cuctx = dev->clientData->cases.memcheck.cuctx;
    }
    else {
        HALO_ERROR("Invalid context\n");
        return CUDBG_ERROR_INVALID_CONTEXT;
    }

    if (regType == HALO_REG_OP_TYPE_GR_CTX)
        cutype = CU_PRI_REG_CONTEXT;

    res = cuiPriRegWrite32(cuctx, cutype, 1, &tmpaddr, &tmpval, 0);
    if (res != CUDA_SUCCESS) {
        HALO_TRACE(10, "Failed to read 32 bit register at 0x%x on dev:%p\n", addr, dev);
        return CUDBG_ERROR_UNKNOWN;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
memcheckWriteReg64(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint64_t* value)
{
    CUctx *cuctx = NULL;
    CUresult res = CUDA_SUCCESS;
    NvU32 tmpaddr = (NvU32)(uintptr_t)addr;
    NvU64 tmpval = (NvU64)(*value);
    NvU32 cutype = CU_PRI_REG_GLOBAL;

    if (memcheckForceClientUseDmal())
        return dev->dmal->writeReg64(dev, regType, addr, value);

    CUDBG_VERIFY_REGADDR(addr);

    if (dev->activeContext) {
        cuctx = (CUctx*)(uintptr_t)dev->activeContext->cuCtx;
    }
    else if (dev->clientData) {
        cuctx = dev->clientData->cases.memcheck.cuctx;
    }
    else {
        HALO_ERROR("Invalid context\n");
        return CUDBG_ERROR_INVALID_CONTEXT;
    }
    if (regType == HALO_REG_OP_TYPE_GR_CTX)
        cutype = CU_PRI_REG_CONTEXT;

    res = cuiPriRegWrite64(cuctx, cutype, 1, &tmpaddr, &tmpval, 0);
    if (res != CUDA_SUCCESS) {
        HALO_TRACE(10, "Failed to read 32 bit register at 0x%x on dev:%p\n", addr, dev);
        return CUDBG_ERROR_UNKNOWN;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDeviceInitPreHook(CudbgDevice dev)
{
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDeviceInitPostHook(CudbgDevice dev)
{
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDeviceDestroyPreHook(CudbgDevice dev)
{
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDeviceDestroyPostHook(CudbgDevice dev)
{
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloPreInit(void)
{
    return CUDBG_SUCCESS;
}

static CUDBGResult
memcheckInitDmalForDevice(CudbgDevice dev, CUdmalType type)
{
    switch (type) {
    case CU_DMAL_RM:
    case CU_DMAL_MPS:
        dev->dmal = haloGlobals.haloDmal[HALO_DMAL_TYPE_RM];
        break;
    case CU_DMAL_MRM:
        dev->dmal = haloGlobals.haloDmal[HALO_DMAL_TYPE_MRM];
        break;
    case CU_DMAL_WDDM:
        dev->dmal = haloGlobals.haloDmal[HALO_DMAL_TYPE_WDDM_LEGACY];
        break;
    default:
        HALO_ERROR("Unsupported DMAL of type %d requested!\n", type);
        return CUDBG_ERROR_UNKNOWN;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloInitPerDevice(uint32_t devId, CudbgDevice dev, HaloClient haloClient)
{
    CUDBGResult res;
    CUctx *cuCtx;
    Context haloCtx = NULL;
    bool ctxFound = false;
    CUdev* pDev = globals.devices[devId];

    res = memcheckInitDmalForDevice(dev, pDev->dmalType);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to initialize DMAL for device %d (%d)\n", devId, res);
        return res;
    }

    // PRI reads for the memcheck client need a valid context
    // First try the initData one, otherwise fallback to primary
    // context
    cuCtx = haloGlobals.initData.cases.memcheck.cuctx;
    if (cuCtx && cuCtx->persistentState.state == CUI_CTX_STATE_ACTIVE)
        ctxFound = true;

    if (!ctxFound) {
        cuCtx = globals.devices[devId]->state.primaryCtx;
        if (!cuCtx || cuCtx->persistentState.state != CUI_CTX_STATE_ACTIVE)
            return CUDBG_ERROR_UNKNOWN;
    }

    haloCtx = (Context)calloc(1, sizeof *haloCtx);
    haloCtx->cuCtx = (uint64_t)(uintptr_t)cuCtx;
    dev->activeContext = haloCtx;

    dev->status = CUDBG_ERROR_UNKNOWN;
    dev->haloClient = haloClient;

    res = haloDeviceInitialize(dev, devId);

    free(haloCtx);
    dev->activeContext = NULL;

    haloStateAddDevice(devId, dev);

    dev->status = CUDBG_ERROR_UNKNOWN;
    if (res == CUDBG_ERROR_SOME_DEVICES_WATCHDOGGED) {
        // Note, this should never happen as cuInit will filter out
        // watchdogged devices. We may change that in future.
        HALO_ERROR("Failed to initialize; device %d "
                   "has a timeout associated with it.\n", devId);
        dev->status = res;
    }
    else if (res != CUDBG_SUCCESS) {
        // This is a failure point.  If _any_ device fails to
        // initialize, we cannot continue the debug session.
        // We must report failure and let the client of the
        // API handle it.
        HALO_ERROR("Failed to initialize device %d.\n", devId);
        dev->status = CUDBG_ERROR_INITIALIZATION_FAILURE;
        return CUDBG_ERROR_INITIALIZATION_FAILURE;
    }
    else
        dev->status = CUDBG_SUCCESS;

    return res;
}

static CUDBGResult
haloInSyscallPatch(CudbgDevice dev, uint64_t physPC, DebugPatch *patch, bool *found)
{
    CUctx *cuctx = NULL;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(dev && patch && found, CUDBG_ERROR_INVALID_ARGS, "Invalid argument to haloInSyscallPatch\n");

    // Set the default return values
    *found = false;
    memset(patch, 0, sizeof(*patch));

    if (!dev->activeContext) {
        *found = false;
        return CUDBG_SUCCESS;
    }

    cuctx = (CUctx*)(uintptr_t)dev->activeContext->cuCtx;

    res = memcheckFindInSyscall(physPC, cuctx, haloGlobals.initData.cases.memcheck.gvars, found);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("memcheckFindInSyscall failed\n");
        return res;
    }

    return res;
}

static CUDBGResult
haloInGlobalSyscallPatch(CudbgDevice dev, uint64_t physPC, DebugPatch *patch, bool *found)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(dev && patch && found, CUDBG_ERROR_INVALID_ARGS, "Invalid argument to haloInGlobalSyscallPatch\n");

    // Set the default return values
    *found = false;
    memset(patch, 0, sizeof(*patch));

    return res;
}

static CUDBGResult
haloInTrapRegion(CudbgDevice dev, uint64_t physPC, DebugPatch *patch, bool *found)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(dev && patch && found, CUDBG_ERROR_INVALID_ARGS, "Invalid argument to haloInTrapRegion\n");

    // Set the default return values
    *found = false;
    memset(patch, 0, sizeof(*patch));

    return res;
}

static CUDBGResult
haloInMembarWARPatch(CudbgDevice dev, uint64_t physPC, DebugPatch *patch, bool *found)
{
    CUDBGResult res = CUDBG_SUCCESS;

    // Set the default return values
    *found = false;
    memset(patch, 0, sizeof(*patch));

    return res;
}

static CUDBGResult
haloInMemcheckPatch(CudbgDevice dev, uint64_t physPC, bool *found)
{
    CUctx *cuctx = NULL;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(dev && found, CUDBG_ERROR_INVALID_ARGS, "Invalid argument to haloInMemcheckPatch\n");

    // Set the default return values
    *found = false;

    if (!dev->activeContext) {
        *found = false;
        return CUDBG_SUCCESS;
    }

    cuctx = (CUctx*)(uintptr_t)dev->activeContext->cuCtx;

    res = memcheckFindInMemcheckPatch(physPC, cuctx, haloGlobals.initData.cases.memcheck.gvars, found);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("memcheckFindInSyscall failed\n");
        return res;
    }

    return res;
}

static CUDBGResult
memcheckUnmapMemory(CudbgDevice dev)
{
    CUDBGResult res = CUDBG_SUCCESS;

    /* Ensure mapMemory+memcpy is atomic */
    cuosEnterCriticalSection(&haloGlobals.mapMemory_cs);

    res = dev->dmal->unmapMemory(dev);

    cuosLeaveCriticalSection(&haloGlobals.mapMemory_cs);

    return res;
}

static CUDBGResult
memcheckReadBar1Size(CudbgDevice dev, uint64_t *bar1Size)
{
    return dev->dmal->readBar1Size(dev, bar1Size);
}

static CUDBGResult
memcheckForceWarpHiding(CudbgDevice dev, uint32_t sm, uint32_t wp, bool *hideWarp)
{
    Context context;

    CUDBG_VERIFY(dev && hideWarp, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    context = dev->activeContext;

    /* Default to false */
    *hideWarp = false;

    if (haloGlobals.initData.cases.memcheck.isMpsClient &&
        context->mpsContextId != dev->smState[sm].warp[wp].mpsContextId) {
        HALO_TRACE(15, "Forcing warp hiding in MPS client mode. Context client ID:%u sm%d/wp%d client ID:%u\n",
                   context->mpsContextId,
                   sm, wp,
                   dev->smState[sm].warp[wp].mpsContextId);
        *hideWarp = true;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
inUnifiedDebuggerPatch(CudbgDevice dev, uint64_t pc, bool *inPatch)
{
    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_ARGS,
        "Invalid device argument to inUnifiedDebuggerPatch\n");
    CUDBG_VERIFY(inPatch, CUDBG_ERROR_INVALID_ARGS,
        "Invalid inPatch argument to inUnifiedDebuggerPatch\n");

    *inPatch = false;
    return CUDBG_SUCCESS;
}

static CUDBGResult
getUnifiedDebuggerPatchPC(CudbgDevice dev, uint64_t ctx, uint64_t physicalPc, uint64_t *userPc)
{
    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_ARGS,
        "Invalid device argument to getUnifiedDebuggerPatchPC\n");
    CUDBG_VERIFY(userPc, CUDBG_ERROR_INVALID_ARGS,
        "Invalid userPc argument to getUnifiedDebuggerPatchPC\n");

    *userPc = 0;
    return CUDBG_SUCCESS;
}

// This function (and haloInit) will now be called multiple
// times if memcheck is running.
CUDBGResult
haloClientInit_memcheck(HaloClient haloClient)
{
    uint32_t devId;
    CUDBGResult res;
    CUDBGResult stickyError;
    CudbgDevice dev;
    uint32_t oldMask;
    CUctx *cuCtx = NULL;

    /* Set the HALO client state */
    haloClient->state.dupRmHandles = true;
    haloClient->state.hideWarpsInGlobalSyscalls = false;

    haloClient->readBar1Size              = memcheckReadBar1Size;
    haloClient->mapMemory                 = memcheckMapMemory;
    haloClient->unmapMemory               = memcheckUnmapMemory;
    haloClient->initPrivAccess            = memcheckInitPrivAccess;
    haloClient->finalizePrivAccess        = memcheckFinalizePrivAccess;
    haloClient->readReg32                 = memcheckReadReg32;
    haloClient->readReg64                 = memcheckReadReg64;
    haloClient->writeReg32                = memcheckWriteReg32;
    haloClient->writeReg64                = memcheckWriteReg64;
    haloClient->deviceDestroyPreHook      = haloDeviceDestroyPreHook;
    haloClient->deviceDestroyPostHook     = haloDeviceDestroyPostHook;
    haloClient->deviceInitPreHook         = haloDeviceInitPreHook;
    haloClient->deviceInitPostHook        = haloDeviceInitPostHook;
    haloClient->preInit                   = haloPreInit;
    haloClient->initPerDevice             = haloInitPerDevice;
    haloClient->inSyscallPatch            = haloInSyscallPatch;
    haloClient->inGlobalSyscallPatch      = haloInGlobalSyscallPatch;
    haloClient->inTrapRegion              = haloInTrapRegion;
    haloClient->inMembarWARPatch          = haloInMembarWARPatch;
    haloClient->inMemcheckPatch           = haloInMemcheckPatch;
    haloClient->getExceptionFromMagic     = memcheckGetExceptionFromMagic;

    /* High level functions */
    haloClient->createDynamicGrid                  = memcheckCreateDynamicGrid;
    haloClient->updateUnpostedDynamicGrid          = memcheckUpdateUnpostedDynamicGrid;
    haloClient->postGridEvent                      = memcheckPostGridEvent;
    haloClient->initiateChannelGroupPreemptSave    = memcheckInitiateChannelGroupPreemptSave;
    haloClient->initiateChannelGroupPreemptRestore = memcheckInitiateChannelGroupPreemptRestore;

    /* MPS */
    haloClient->forceWarpHiding             = memcheckForceWarpHiding;

    /* Unified debugger stubs */
    haloClient->inUnifiedDebuggerPatch            = inUnifiedDebuggerPatch;
    haloClient->getUnifiedDebuggerPatchPC         = getUnifiedDebuggerPatchPC;

    res = haloClient->preInit();
    if (res != CUDBG_SUCCESS)
        return res;

    oldMask = activeDevices;
    stickyError = res;

    /* Memcheck initializes on a given context, so we can
       use this information to identify the device */
    cuCtx = (CUctx*)haloGlobals.initData.cases.memcheck.cuctx;
    devId = cuCtx->device->state.deviceIdx;

    // Skip already initialized devices
    if (!(activeDevices & (1U << devId))) {
        dev = (CudbgDevice)calloc(1, sizeof *dev);
        if (!dev)
            return CUDBG_ERROR_INITIALIZATION_FAILURE;

        haloGlobals.device[devId] = dev;

        res = haloClient->initPerDevice(devId, dev, haloClient);
        if (res != CUDBG_SUCCESS) {
            haloGlobals.device[devId] = NULL;
            free(dev);
            activeDevices &= ~(1U << devId);

            if (stickyError == CUDBG_SUCCESS)
                stickyError = res;
        }
        else
            activeDevices |= (1U << devId);
    }

    // If there has been no change, and there is atleast one error
    if (oldMask == activeDevices && stickyError != CUDBG_SUCCESS)
        return CUDBG_ERROR_INITIALIZATION_FAILURE;

    return CUDBG_SUCCESS;
}

