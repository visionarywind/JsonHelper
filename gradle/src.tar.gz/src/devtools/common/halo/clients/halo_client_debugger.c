/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: halo_client_debugger.c
 *
 *   Description:
 *       Contains halo functions specific to the debugger including :
 *          + Preinitialization functions to handle device enumeration
 *          + Logic for detection and reporting of watchdogged devices
 *          + Bar0 mapping for global PRI accesses
 *          + Bar1 mapping for vidmem accesses
 *
 ******************************************************************************/

#include "halo.h"
#include "halo_internal.h"
#include "halo_state.h"
#include "halo_client.h"
#include "fermi.h"
#include "kepler.h"
#include "rm_device.h"
#include "rm_call.h"
#if cuosOsIsLinux() || cuosOsIsApple() /* CUDA & CLH */
# include <sys/mman.h>
#endif
#include "nvRmApi.h"
#include "class/cl003f.h"
#include "ctrl/ctrl2080.h"
#include "cui/channel_private.h"

#include "memobj.h"

#include "cudbgapi.h"
#include "cudbgcoredump.h"

static CUDBGResult
haloDeviceInitPreHook(CudbgDevice dev)
{
    uint32_t rc = CUDA_ERROR_UNKNOWN;
    int timeout = 0;
    bool checkWatchdog = true;
    const CUdev* pDev;
    uint32_t device;

    device = dev->deviceIdx;
    pDev = globals.devices[device];

#if cuosOsIsApple()
    /* On Apple, we need to set the maximum RM watchdog timer */
    rc = haloSetWatchdogTimeout(dev,
                                CUDBG_RM_WATCHDOG_TIMEOUT_MAX,
                                CUDBG_RM_WATCHDOG_INTERVAL_MAX);
    if (rc) {
        /* This is a failure point; if we get here and attempt to continue
           execution, the display will most likely freeze.  We must return
           an error here. */
        HALO_ERROR("Failed to set watchdog timer (dev %d, rc=%d)\n", device, rc);
        return CUDBG_ERROR_INITIALIZATION_FAILURE;
    }
    HALO_TRACE_FUNCTION(1, "Set watchdog timer (dev %d)\n", device);
    checkWatchdog = false;
#endif

    /* If preemption debugging is enabled, and this device has the feature set
       needed to support it, then do not check for a watchdog.  The debugger
       can run alongside the watchdog in this situation.  Note that the
       CUDBG_ENABLE_PREEMPTION_DEBUGGING variable is set either by a client
       linked directly against the Debug API, or by RPCD directly. */
    if (CUDBG_ENABLE_PREEMPTION_DEBUGGING && pDev->state.supportsKilp) {
        HALO_TRACE_FUNCTION(1, "Preemption debugging enabled on capable device %d\n", device);
        checkWatchdog = false;
    }
    /* Above argument is true for CILP as well */
    if (cuiPreemptionDevicePreemptionMode(pDev) == CU_COMPUTE_PREEMPTION_MODE_CILP) {
        HALO_TRACE_FUNCTION(1, "Preemption debugging enabled on capable device %d\n", device);
        checkWatchdog = false;
    }
    /* We unconditionally disable the channel watchdog on mobile. */
    if (dev->dmal->type == HALO_DMAL_TYPE_MRM) {
        HALO_TRACE_FUNCTION(1, "Skipping watchdog timeout check on mobile device %d\n", device);
        checkWatchdog = false;
    }

    if (checkWatchdog) {
        /* Are we running under X/Aqua/etc. ? */
        rc = cuiDeviceGetAttribute(pDev, CU_DEVICE_ATTRIBUTE_KERNEL_EXEC_TIMEOUT, &timeout);
        if (rc) {
            HALO_ERROR("Failed to get the timeout setting, rc = 0x%x.\n", rc);
            /* We don't know, so keep going. */
        }
        else if (timeout) {
            HALO_ERROR("Device %d is running a window system.\n", device);
            return CUDBG_ERROR_SOME_DEVICES_WATCHDOGGED;
        }
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDeviceInitPostHook(CudbgDevice dev)
{
    CUDBGResult res = CUDBG_SUCCESS;
    const CUdev* pDev;
    bool needsProfilerObject = false;

    pDev = globals.devices[dev->deviceIdx];

    res = dev->dmal->initDeviceDebugInterface(dev);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to initialize debug interface\n");

    res = dev->halo.needsProfilerObject(dev, &needsProfilerObject);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to check if profiler interface is needed\n");

    if (needsProfilerObject) {
        res = dev->dmal->initDeviceProfilerInterface(dev);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to initialize profiler interface\n");
    }

    if (!cudbgIsCoredumpInProgress()) {
        /* Allocate the event we need for debugger interrupt notification. */
        res = haloAllocateDeviceEvent(dev, pDev);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to allocate device event notifier\n");
    }

#ifdef CUDBG_ENABLE_IFB
    if (dev->halo.allocateIFB(dev, deviceGetHandleRM(pDev),
                              deviceGetSubHandleRM(pDev), pDev->rmGpuId)) {
        HALO_ERROR("Failed to allocate IFB ptr\n");
        return CUDBG_ERROR_UNKNOWN;
    }
#endif

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDeviceDestroyPreHook(CudbgDevice dev)
{
    CUDBGResult res = CUDBG_SUCCESS;
#if defined (__APPLE__)
    int rc;

    /* Reset any watchdog timer/interval values on Apple, where we
       need to set a maximum timeout for single-gpu debugging */
    rc = haloSetWatchdogTimeout(dev,
                                CUDBG_RM_WATCHDOG_TIMEOUT_DEFAULT,
                                CUDBG_RM_WATCHDOG_INTERVAL_DEFAULT);
    if (rc)
        HALO_ERROR("Failed to restore watchdog timer (dev %d, rc=%d)\n", dev->deviceIdx, rc);
    else
        HALO_TRACE_FUNCTION(1, "Restored watchdog timer (dev %d)\n", dev->deviceIdx);
#endif

    return res;
}

static CUDBGResult
haloDeviceDestroyPostHook(CudbgDevice dev)
{
    CUDBGResult res = CUDBG_SUCCESS;

    if (!cudbgIsCoredumpInProgress()) {
        haloFreeDeviceEvent(dev);
        dev->dmal->destroyDeviceDebugInterface(dev);
    }

    /* Turn power gating back on */
    res = dev->halo.setPowerGatingState(dev, HALO_POWER_GATING_STATE_ENABLED);
    if (res != CUDBG_SUCCESS)
        return res;
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloPreInit(void)
{
    CUresult rc = CUDA_SUCCESS;

    /* Don't reinitialize the driver for an in-process HALO */
    if (haloGlobals.initData.flags & HALO_INIT_FLAGS_IN_PROCESS)
        return CUDBG_SUCCESS;

    /* Initialize CUDA (we are a CUDA application)

       We fake being run under the debugger to ensure we get the same
       enumeration as the app. This was bug 558668 */
    CUDBG_IPC_FLAG_NAME = 1;
    CUDBG_I_AM_DEBUGGER = 1;
    rc = cuiInitCheck(NULL);
    if (rc != CUDA_SUCCESS) {
        if ((rc = cuiInit(CUI_API_CUDA))) {
            HALO_ERROR("CUDA driver initialization failed, rc = 0x%x.\n", rc);
            if (globals.requestWatchdogStateEnabled)
                return CUDBG_ERROR_ALL_DEVICES_WATCHDOGGED;
            else if (rc == CUDA_ERROR_NO_DEVICE)
                return CUDBG_ERROR_NO_DEVICE_AVAILABLE;
            else
                return CUDBG_ERROR_INITIALIZATION_FAILURE;
        }
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
debuggerInitDmalForDevice(CudbgDevice dev, CUdmalType type)
{
    switch (type) {
    case CU_DMAL_RM:
    case CU_DMAL_MPS:
        dev->dmal = haloGlobals.haloDmal[HALO_DMAL_TYPE_RM];
        break;
    case CU_DMAL_MRM:
        dev->dmal = haloGlobals.haloDmal[HALO_DMAL_TYPE_MRM];
        break;
    case CU_DMAL_WDDM:
        dev->dmal = haloGlobals.haloDmal[HALO_DMAL_TYPE_WDDM];
        break;
    default:
        HALO_ERROR("Unsupported DMAL of type %d requested!\n", type);
        return CUDBG_ERROR_UNKNOWN;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloInitPerDevice(uint32_t devId, CudbgDevice dev, HaloClient haloClient)
{
    CUDBGResult res;
    CUdev* pDev = globals.devices[devId];

    dev->status = CUDBG_ERROR_UNKNOWN;
    dev->haloClient = haloClient;

    /* If asked, set the device to force regops instead of Bar0 */
    if (haloGlobals.initData.flags & HALO_INIT_FLAGS_FORCE_REGOPS) {
        HALO_TRACE_FUNCTION(1, "Forcing device to use regops\n");
        dev->halo.deviceInfo.useRegOps = 1;
    }

    res = debuggerInitDmalForDevice(dev, pDev->dmalType);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to initialize DMAL for device %d (%d)\n", devId, res);
        return res;
    }

    res = haloDeviceInitialize(dev, devId);

    dev->status = CUDBG_ERROR_UNKNOWN;
    if (res == CUDBG_ERROR_SOME_DEVICES_WATCHDOGGED) {
        // Note, this should never happen as cuInit will filter out
        // watchdogged devices. We may change that in future.
        HALO_ERROR("Failed to initialize; device %d "
                   "has a timeout associated with it.\n", devId);
        dev->status = res;
    }
    else if (res != CUDBG_SUCCESS) {
        // This is a failure point.  If _any_ device fails to
        // initialize, we cannot continue the debug session.
        // We must report failure and let the client of the
        // API handle it.
        HALO_ERROR("Failed to initialize device %d.\n", devId);
        return res;
    }
    else
        dev->status = CUDBG_SUCCESS;

    res = haloStateAddDevice(devId, dev);
    if (res != CUDBG_SUCCESS)
        return res;

    // Only adjust device state if the device is accessible
    if (dev->status == CUDBG_SUCCESS) {
        // Kepler and higher GPUs powergate aggressively, which might cause register
        // reads and writes to operate on invalid contents. Turning off power gating
        // avoids that.
        res = dev->halo.setPowerGatingState(dev, HALO_POWER_GATING_STATE_DISABLED);
        if (res != CUDBG_SUCCESS)
            return res;
    }

    return res;
}

static CUDBGResult
haloInSyscallPatch(CudbgDevice dev, uint64_t physPC, DebugPatch *patch, bool *found)
{
    CUDBGResult res;

    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid device argument to haloInSyscallPatch\n");

    CUDBG_VERIFY(patch, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid patch argument to haloInSyscallPatch\n");

    CUDBG_VERIFY(found, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid found argument to haloInSyscallPatch\n");

    if (!dev->activeContext) {
        *found = false;
        return CUDBG_SUCCESS;
    }

    res = haloInPatchRegion(physPC, dev->activeContext, patch,
                            CUDBG_PATCH_SYSCALL, found, false);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to haloInPatchRegion failed\n");
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloInGlobalSyscallPatch(CudbgDevice dev, uint64_t physPC, DebugPatch *patch, bool *found)
{
    CUDBGResult res;

    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid device argument to haloInSyscallPatch\n");

    CUDBG_VERIFY(patch, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid patch argument to haloInSyscallPatch\n");

    CUDBG_VERIFY(found, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid found argument to haloInSyscallPatch\n");

    if (!dev->activeContext) {
        *found = false;
        return CUDBG_SUCCESS;
    }

    res = haloInPatchRegion(physPC, dev->activeContext, patch,
                            CUDBG_PATCH_GLOBAL_SYSCALL, found, false);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to haloInPatchRegion failed\n");
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloInTrapRegion(CudbgDevice dev, uint64_t physPC, DebugPatch *patch, bool *found)
{
    CUDBGResult res;

    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid device argument to haloInTrapRegion\n");

    CUDBG_VERIFY(patch, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid patch argument to haloInTrapRegion\n");

    CUDBG_VERIFY(found, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid found argument to haloInTrapRegion\n");

    if (!dev->activeContext) {
        *found = false;
        return CUDBG_SUCCESS;
    }

    res = haloInPatchRegion(physPC, dev->activeContext, patch,
                            CUDBG_PATCH_TRAP_HANDLER, found, false);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to haloInPatchRegion failed\n");
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloInMembarWARPatch(CudbgDevice dev, uint64_t physPC, DebugPatch *patch, bool *found)
{
    CUDBGResult res;

    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid device argument to haloInMembarWARPatch\n");

    CUDBG_VERIFY(patch, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid patch argument to haloInMembarWARPatch\n");

    CUDBG_VERIFY(found, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid found argument to haloInMembarWARPatch\n");

    if (!dev->activeContext) {
        *found = false;
        return CUDBG_SUCCESS;
    }

    res = haloInPatchRegion(physPC, dev->activeContext, patch,
                            CUDBG_PATCH_MEMBAR_WAR, found, false);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to haloInPatchRegion failed\n");
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloInMemcheckPatch(CudbgDevice dev, uint64_t physPC, bool *found)
{
    CUDBGResult res;
    DebugPatch patch = NULL;

    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid device argument to haloInMemcheckPatch\n");

    CUDBG_VERIFY(found, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid found argument to haloInMemcheckPatch\n");

    if (!dev->activeContext) {
        *found = false;
        return CUDBG_SUCCESS;
    }

    res = haloInPatchRegion(physPC, dev->activeContext, &patch,
                            CUDBG_PATCH_MEMCHECK, found, false);
    if (res != CUDBG_SUCCESS) {
        CUDBG_ERROR("Call to haloInPatchRegion failed\n");
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
debuggerInitPrivAccess (CudbgDevice dev)
{
    return dev->dmal->initPrivAccess(dev);
}

static CUDBGResult
debuggerFinalizePrivAccess (CudbgDevice dev)
{
    return dev->dmal->finalizePrivAccess(dev);
}

static CUDBGResult
debuggerReadReg32(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint32_t* value)
{
    return dev->dmal->readReg32(dev, regType, addr, value);
}

static CUDBGResult
debuggerReadReg64(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint64_t* value)
{
    return dev->dmal->readReg64(dev, regType, addr, value);
}

static CUDBGResult
debuggerWriteReg32(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint32_t* value)
{
    return dev->dmal->writeReg32(dev, regType, addr, value);
}

static CUDBGResult
debuggerWriteReg64(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint64_t* value)
{
    return dev->dmal->writeReg64(dev, regType, addr, value);
}

static CUDBGResult
debuggerMapMemory(Context context, uint64_t va, uint64_t size, char **hostPtr)
{
    CudbgDevice dev;

    if (!context || !context->memMapActive)
        return CUDBG_ERROR_INTERNAL;

    dev = context->dev;

    return dev->dmal->mapMemory(context, context->memMap, va, size, hostPtr);
}

static CUDBGResult
debuggerUnmapMemory(CudbgDevice dev)
{
    CUDBGResult res = CUDBG_SUCCESS;

    /* Ensure mapMemory+memcpy is atomic */
    cuosEnterCriticalSection(&haloGlobals.mapMemory_cs);

    res = dev->dmal->unmapMemory(dev);

    cuosLeaveCriticalSection(&haloGlobals.mapMemory_cs);

    return res;
}

static CUDBGResult
debuggerReadBar1Size(CudbgDevice dev, uint64_t *bar1Size)
{
    return dev->dmal->readBar1Size(dev, bar1Size);
}

static CUDBGResult
debuggerForceWarpHiding(CudbgDevice dev, uint32_t sm, uint32_t wp, bool *hideWarp)
{
    CUDBG_VERIFY(dev && hideWarp, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");
    *hideWarp = false;

    return CUDBG_SUCCESS;
}

static CUDBGResult
debuggerGetExceptionFromMagic(CudbgDevice dev, uint32_t magic, CUDBGException_t *exception)
{
    CUDBG_VERIFY(dev && exception, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    // TODO This logic only applies for --tool memcheck
    // and might cause issues when debugging (not supported)
    // tools in cuda-gdb

    if ((magic & FERMI_MEMCHECK_WHITEMAGIC_MASK) == FERMI_MEMCHECK_WHITEMAGIC) {
        if (magic & FERMI_MEMCHECK_SYSCALL_MASK)
            *exception = CUDBG_EXCEPTION_LANE_SYSCALL_ERROR;
        else if (magic & FERMI_MEMCHECK_ATOMSYS_MASK)
            *exception = CUDBG_EXCEPTION_LANE_INVALID_ATOMSYS;
        else
            *exception = CUDBG_EXCEPTION_LANE_ILLEGAL_ADDRESS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
inUnifiedDebuggerPatch(CudbgDevice dev, uint64_t pc, bool *inPatch)
{
    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_ARGS,
        "Invalid device argument to inUnifiedDebuggerPatch\n");
    CUDBG_VERIFY(inPatch, CUDBG_ERROR_INVALID_ARGS,
        "Invalid inPatch argument to inUnifiedDebuggerPatch\n");

    *inPatch = false;
    return CUDBG_SUCCESS;
}

static CUDBGResult
getUnifiedDebuggerPatchPC(CudbgDevice dev, uint64_t ctx, uint64_t physicalPc, uint64_t *userPc)
{
    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_ARGS,
        "Invalid device argument to getUnifiedDebuggerPatchPC\n");
    CUDBG_VERIFY(userPc, CUDBG_ERROR_INVALID_ARGS,
        "Invalid userPc argument to getUnifiedDebuggerPatchPC\n");

    *userPc = 0;
    return CUDBG_SUCCESS;
}

CUDBGResult
haloClientInit_debugger(HaloClient haloClient)
{
    uint32_t devId;
    CUDBGResult res;
    CudbgDevice dev;
    uint32_t numExcludedDevices = 0;

    /* Set the haloGlobal option */
    haloClient->state.dupRmHandles = true;
    haloClient->state.hideWarpsInGlobalSyscalls = true;
    haloClient->state.overrideInSyscallSPValue = true;

    haloClient->mapMemory                     = debuggerMapMemory;
    haloClient->unmapMemory                   = debuggerUnmapMemory;
    haloClient->initPrivAccess                = debuggerInitPrivAccess;
    haloClient->finalizePrivAccess            = debuggerFinalizePrivAccess;
    haloClient->readBar1Size                  = debuggerReadBar1Size;
    haloClient->readReg32                     = debuggerReadReg32;
    haloClient->readReg64                     = debuggerReadReg64;
    haloClient->writeReg32                    = debuggerWriteReg32;
    haloClient->writeReg64                    = debuggerWriteReg64;
    haloClient->deviceDestroyPreHook          = haloDeviceDestroyPreHook;
    haloClient->deviceDestroyPostHook         = haloDeviceDestroyPostHook;
    haloClient->deviceInitPreHook             = haloDeviceInitPreHook;
    haloClient->deviceInitPostHook            = haloDeviceInitPostHook;
    haloClient->preInit                       = haloPreInit;
    haloClient->initPerDevice                 = haloInitPerDevice;
    haloClient->inSyscallPatch                = haloInSyscallPatch;
    haloClient->inGlobalSyscallPatch          = haloInGlobalSyscallPatch;
    haloClient->inTrapRegion                  = haloInTrapRegion;
    haloClient->inMembarWARPatch              = haloInMembarWARPatch;
    haloClient->inMemcheckPatch               = haloInMemcheckPatch;
    haloClient->getExceptionFromMagic         = debuggerGetExceptionFromMagic;

    /* High level functions */
    haloClient->createDynamicGrid                  = gpudbgCreateDynamicGrid;
    haloClient->updateUnpostedDynamicGrid          = gpudbgUpdateUnpostedDynamicGrid;
    haloClient->postGridEvent                      = gpudbgPostGridEvent;
    haloClient->initiateChannelGroupPreemptSave    = gpudbgInitiateChannelGroupPreemptSave;
    haloClient->initiateChannelGroupPreemptRestore = gpudbgInitiateChannelGroupPreemptRestore;

    /* MPS */
    haloClient->forceWarpHiding                   = debuggerForceWarpHiding;

    /* Unified debugger stubs */
    haloClient->inUnifiedDebuggerPatch            = inUnifiedDebuggerPatch;
    haloClient->getUnifiedDebuggerPatchPC         = getUnifiedDebuggerPatchPC;

    res = haloClient->preInit();
    if (res != CUDBG_SUCCESS)
        return res;

    for (devId = 0; devId < globals.numDevices; ++devId) {
        haloGlobals.device[devId] = dev = (CudbgDevice)calloc(1, sizeof *dev);
        if (!(dev->isDebuggable = cudbgIsDebuggableDevice(globals.devices[devId]))) {
            numExcludedDevices++;
            dev->status = CUDBG_ERROR_UNINITIALIZED;
            continue;
        }

        res = haloClient->initPerDevice(devId, dev, haloClient);
        if (res != CUDBG_SUCCESS) {
            haloGlobals.device[devId] = NULL;
            free(dev);
            return res;
        }
    }

    if (numExcludedDevices == globals.numDevices)
        return CUDBG_ERROR_ALL_DEVICES_WATCHDOGGED;

    if (numExcludedDevices)
        /* Note, this is just a warning. */
        return CUDBG_ERROR_SOME_DEVICES_WATCHDOGGED;

    return CUDBG_SUCCESS;
}
