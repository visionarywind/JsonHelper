/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: halo_client.c
 *
 *   Description:
 *       Contains client halo functions shared by all clients
 *
 ******************************************************************************/
#include "halo.h"
#include "halo_internal.h"
#include "halo_client.h"
#include "halo_client_memcheck.h"
#include "halo_client_unified_debugger.h"

#include "rm_device.h"
#include "rm_call.h"
#include "nvRmApi.h"
#include "cuda_device.h"

static uint32_t haloClientInitialized = 0;

CUDBGResult
haloClientInit(uint32_t haloType)
{
    CUDBGResult res;
    HaloClient haloClient;

    if (!haloClientInitialized) {
        haloGlobals.haloClient = (HaloClient)calloc(1, sizeof *haloGlobals.haloClient);
        if (NULL == haloGlobals.haloClient)
            return CUDBG_ERROR_UNKNOWN;
        haloClientInitialized = 1;
    }

    haloClient = haloGlobals.haloClient;

    HALO_TRACE(5, "Initializing client for halo type:%d\n", haloType);

    switch (haloType) {
    case HALO_TYPE_DEBUGGER :
        res = haloClientInit_debugger(haloClient);
        break;
    case HALO_TYPE_MEMCHECK :
        res = haloClientInit_memcheck(haloClient);
        break;
    case HALO_TYPE_UNIFIED_DEBUGGER:
        res = haloClientInit_unified_debugger(haloClient);
        break;
    default :
        HALO_ERROR("Unknown halo client type %d\n", haloType);
        return CUDBG_ERROR_INITIALIZATION_FAILURE;
    };

    return res;
}

CUDBGResult
haloClientFinalize(void)
{
    uint32_t devId;
    CUDBGResult final = CUDBG_SUCCESS, res;
    CudbgDevice dev;

    if (!haloClientInitialized)
        return CUDBG_SUCCESS;

    for (devId = 0; devId < globals.numDevices; ++devId) {
        dev = haloGlobals.device[devId];
        if (dev && dev->status == CUDBG_SUCCESS) {
            res = dev->halo.deviceFinalize(dev);
            haloGlobals.device[devId] = NULL;
            free(dev);
            if (res) {
                HALO_ERROR("Failed to destroy device %d.\n", devId);
                final = res;
            }
        }
    }

    free(haloGlobals.haloClient);

    haloClientInitialized = 0;

    return final;
}

