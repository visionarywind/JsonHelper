/*
 * Copyright 2018 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */


/******************************************************************************
 *
 *   Module: kdapi_rm.c
 *
 *   Description:
 *       Kernel-mode Debug API wrappers for RM
 *
 ******************************************************************************/

#include "kdapi.h"

#include "halo_internal.h"
#include "cudbgutils.h"

#include "channel_private.h"

#include "kepler/gk104/dev_graphics_nobundle.h"

#include "class/cl0000.h"
#include "class/cl0005.h"
#include "class/cl83de.h"
#include "class/clc0c0sw.h"

/* Bug 2610260 - WAR to get around alignment issues with RM sdk structure.
KMD forces packing to 1 in nvlEscDef.h before including escape headers, which in
turn includes RM sdk headers. NV83DE_CTRL_DEBUG_EXEC_REG_OPS_PARAMS was added to
the SDK in ctrl/ctrl83de/ctrl83dedebug.h with a 1 byte field at the beginning of
the structure, followed by other values that are aligned to a 32 bit boundary.
The alignment is not enforced when packing is set to 1. As a result, debugger
and RM end up with mismatched structures. The longer term solution is to fix
alignment issues in the macros that RM uses.
WAR this issue by reverting the packing before including
ctrl/ctrl83de/ctrl83dedebug.h. */
#pragma pack(push)
#pragma pack()
#if defined(_ctrl83de_h_) || defined(_ctrl83dedebug_h_)
#error "Ensure ctrl/ctrl83de.h or ctrl/ctrl83de/ctrl83dedebug.h is not included before this point"
#endif
#include "ctrl/ctrl83de.h"
#pragma pack(pop)

#if cuiPlatformIncludesRm() && !cuosOsIsApple()

ct_assert(KDAPI_MAX_REG_OPS <= NV83DE_CTRL_GPU_EXEC_REG_OPS_MAX_OPS);
ct_assert(KDAPI_MAX_MEMORY_OPS <= MAX_ACCESS_OPS);


static CUDBGResult
kdapiDebugObjectSetNextStopTriggerTypeRM(KdDebugObject debugObj,
                                         uint32_t triggerType)
{
    NV83DE_CTRL_DEBUG_SET_NEXT_STOP_TRIGGER_TYPE_PARAMS params = {0};
    NV_STATUS res = NV_OK;

    CUDBG_VERIFY(debugObj.rm.handle != 0, CUDBG_ERROR_INVALID_ARGS,
                 "Debug object is not valid\n");
    CUDBG_VERIFY(triggerType && (triggerType <= NV83DE_CTRL_DEBUG_SET_NEXT_STOP_TRIGGER_TYPE_BROADCSAT),
                 CUDBG_ERROR_INVALID_ARGS, "Invalid trigger type\n");

    params.stopTriggerType = triggerType;

    res = CudaRmControl(debugObj.rm.client, debugObj.rm.handle,
                        NV83DE_CTRL_CMD_DEBUG_SET_NEXT_STOP_TRIGGER_TYPE,
                        &params, sizeof(params));
    CUDBG_VERIFY(res == NV_OK, CUDBG_ERROR_UNKNOWN,
                 "Failed to set next stop trigger type, err:0x%x.\n", res);

    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiAllocDebugObjectRM(const CUctx *ctx, KdDebugObject *debugObject)
{
    NV_STATUS res;
    NV83DE_ALLOC_PARAMETERS allocParams = { 0 };
    NV83DE_CTRL_DEBUG_SET_EXCEPTION_MASK_PARAMS setExceptionParams = { 0 };
    NvU32 hDebugObject;
    NvU32 hComputeObject;
    CUnvchannel *channel;
    NvU32 i;
    CUDBGResult status;

    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_ARGS, "Context is not valid\n");
    CUDBG_VERIFY(debugObject, CUDBG_ERROR_INVALID_ARGS, "Debug object pointer is not valid\n");

    debugObject->rm.handle = 0;
    debugObject->rm.client = 0;

    hComputeObject = 0;
    for (i = 0; i < ctx->channelManager->channelCount; i++) {
        channel = ctx->channelManager->channels[i];

        if (channelIsCompute(channel)) {
            hComputeObject = channel->engines[CU_ENGINE_COMPUTE];
            break;
        }
    }
    CUDBG_VERIFY(hComputeObject != 0, CUDBG_ERROR_INTERNAL, "No compute object for the context\n");

    hDebugObject = handlePoolAlloc(globals.handlePool);
    allocParams.hAppClient = globals.rmClient;
    allocParams.hClass3dObject = hComputeObject;

    res = CudaRmAlloc(globals.rmClient, globals.rmClient, hDebugObject, GT200_DEBUGGER, (void *)&allocParams);

    if (res != NV_OK) {
        HALO_ERROR("Failed to allocate a debug object (result=%d)\n", res);
        handlePoolFree(globals.handlePool, hDebugObject);
        return CUDBG_ERROR_INTERNAL;
    }

    setExceptionParams.exceptionMask = ctx->preemption->mode == CU_COMPUTE_PREEMPTION_MODE_CILP ?
        NV83DE_CTRL_DEBUG_SET_EXCEPTION_MASK_CILP | NV83DE_CTRL_DEBUG_SET_EXCEPTION_MASK_FATAL :
        NV83DE_CTRL_DEBUG_SET_EXCEPTION_MASK_TRAP | NV83DE_CTRL_DEBUG_SET_EXCEPTION_MASK_FATAL | NV83DE_CTRL_DEBUG_SET_EXCEPTION_MASK_SINGLE_STEP;

    res = CudaRmControl(globals.rmClient, hDebugObject, NV83DE_CTRL_CMD_DEBUG_SET_EXCEPTION_MASK,
        &setExceptionParams, sizeof setExceptionParams);

    if (res != NV_OK) {
        HALO_ERROR("Failed to set the debug object exception mask (result=%d)\n", res);
        handlePoolFree(globals.handlePool, hDebugObject);
        return CUDBG_ERROR_INTERNAL;
    }

    debugObject->rm.handle = hDebugObject;
    debugObject->rm.client = globals.rmClient;

    status = kdapiDebugObjectSetNextStopTriggerTypeRM(*debugObject,
                                                      NV83DE_CTRL_DEBUG_SET_NEXT_STOP_TRIGGER_TYPE_BROADCSAT);
    if (status != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to set stop trigger type\n");
        handlePoolFree(globals.handlePool, hDebugObject);
        return CUDBG_ERROR_INTERNAL;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiFreeDebugObjectRM(const CUctx *ctx, KdDebugObject debugObject)
{
    NV_STATUS res;

    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_ARGS, "Context handle is not valid\n");
    CUDBG_VERIFY(debugObject.rm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");

    res = CudaRmFree(globals.rmClient, globals.rmClient, debugObject.rm.handle);

    if (res != NV_OK) {
        HALO_ERROR("Failed to free a debug object (result=%d)\n", res);
        return CUDBG_ERROR_INTERNAL;
    }

    debugObject.rm.handle = 0;
    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiGetApiVersionRM(KdDeviceHandle deviceHandle, NvU32 *major, NvU32 *minor)
{
    CUDBG_VERIFY(major && minor, CUDBG_ERROR_INVALID_ARGS, "Version part pointers are not valid\n");

    // TEMP: return version more than 0 but less than 1.0 for the prototype
    *major = 0;
    *minor = 5;

    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiRegisterDebugEventRM(KdContext ctx, KdOsEventHandle hOsEvent)
{
    NV_STATUS res;
    NV0005_ALLOC_PARAMETERS nv0005 = { 0 };
    NvU32 eventClassType;
    NvU32 hDebugEvent;
    void *event;

    CUDBG_VERIFY(ctx && ctx->debugObject.rm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
#if cuosOsIsLinux()
    CUDBG_VERIFY(hOsEvent.nix.fd != 0, CUDBG_ERROR_INVALID_ARGS, "Event handle is not valid\n");
    event = (void *)&hOsEvent.nix.fd;
#elif cuosOsIsWindows()
    CUDBG_VERIFY(hOsEvent.windows.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Event handle is not valid\n");
    event = hOsEvent.windows.handle;
#else
    HALO_ERROR("Incompatible display driver.\n");
    return CUDBG_ERROR_INCOMPATIBLE_DISPLAY_DRIVER;
#endif

    hDebugEvent = handlePoolAlloc(globals.handlePool);
    CUDBG_VERIFY(hDebugEvent, CUDBG_ERROR_INTERNAL, "Allocating handle failed\n");

    eventClassType = NVC0C0_NOTIFIERS_CILP_INT;
    eventClassType |= NV01_EVENT_SUBDEVICE_SPECIFIC;
    eventClassType |= DRF_NUM(0005, _NOTIFY_INDEX, _SUBDEVICE, ctx->deviceHandle.rm.subDeviceIndex);

    nv0005.hParentClient = ctx->debugObject.rm.client;
    nv0005.hSrcResource = ctx->debugObject.rm.handle;
    nv0005.bMultiClientSupport = NV_TRUE;
    nv0005.hClass = NV01_EVENT_OS_EVENT;
    nv0005.notifyIndex = eventClassType;
    nv0005.data = NV_PTR_TO_NvP64(event);

    res = CudaRmAlloc(globals.rmClient, globals.rmClient, hDebugEvent, NV01_EVENT_OS_EVENT, &nv0005);

    if (res != NV_OK) {
        HALO_ERROR("Failed to register a debug event (result=%d)\n", res);
        handlePoolFree(globals.handlePool, hDebugEvent);
        return CUDBG_ERROR_INTERNAL;
    }

    // TEMP WAR (bug 2440016): here we leak the hDebugEvent handle
    // RM should be updated to allocate and store the event handle in the debug object
    HALO_TRACE_FUNCTION(1, "Leaking the debug event handle (temporary WAR)\n", res);

    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiUnregisterDebugEventRM(KdContext ctx)
{
    CUDBG_VERIFY(ctx && ctx->debugObject.rm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");

    HALO_ERROR("Not implemented\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
kdapiClearDebugEventRM(KdContext ctx)
{
    /* Function not needed on RM */
    (void)ctx;
    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiSuspendContextRM(KdContext ctx, NvBool *shouldWait)
{
    NV_STATUS res;
    NV83DE_CTRL_CMD_DEBUG_SUSPEND_CONTEXT_PARAMS params = { 0 };

    CUDBG_VERIFY(ctx && ctx->debugObject.rm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    CUDBG_VERIFY(ctx->debugObject.rm.client != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object client is not valid\n");
    CUDBG_VERIFY(shouldWait, CUDBG_ERROR_INVALID_ARGS, "Should wait pointer is not valid\n");

    res = CudaRmControl(ctx->debugObject.rm.client, ctx->debugObject.rm.handle,
        NV83DE_CTRL_CMD_DEBUG_SUSPEND_CONTEXT, &params, sizeof(params));

    if (res != NV_OK) {
        HALO_ERROR("Failed to suspend a context (result=%d)\n", res);
        *shouldWait = NV_FALSE;
        return CUDBG_ERROR_INTERNAL;
    }

    *shouldWait = (NvBool)params.waitForEvent;
    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiResumeContextRM(KdContext ctx)
{
    NV_STATUS res;
    CUDBGResult status;

    CUDBG_VERIFY(ctx && ctx->debugObject.rm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    CUDBG_VERIFY(ctx->debugObject.rm.client != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object client is not valid\n");

    status = kdapiDebugObjectSetNextStopTriggerTypeRM(ctx->debugObject,
                                                      NV83DE_CTRL_DEBUG_SET_NEXT_STOP_TRIGGER_TYPE_BROADCSAT);
    CUDBG_VERIFY(status == CUDBG_SUCCESS, status,
                 "Failed to set stop trigger type\n");

    res = CudaRmControl(ctx->debugObject.rm.client, ctx->debugObject.rm.handle,
        NV83DE_CTRL_CMD_DEBUG_RESUME_CONTEXT, NULL, 0);

    if (res != NV_OK) {
        HALO_ERROR("Failed to resume a context (result=%d)\n", res);
        return CUDBG_ERROR_INTERNAL;
    }

    return CUDBG_SUCCESS;
}

ct_assert(sizeof(KdRegOp) == sizeof(NV2080_CTRL_GPU_REG_OP));
static CUDBGResult
kdapiExecRegOpsRM(KdContext ctx, NvBool nonTransactional, KdRegOp *script, NvU32 numOps)
{
    NV_STATUS res;
    NV83DE_CTRL_DEBUG_EXEC_REG_OPS_PARAMS params = {0};

    CUDBG_VERIFY(ctx && ctx->debugObject.rm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    CUDBG_VERIFY(script, CUDBG_ERROR_INVALID_ARGS, "PRI script pointer is not valid\n");
    CUDBG_VERIFY(numOps && numOps <= NV83DE_CTRL_GPU_EXEC_REG_OPS_MAX_OPS,
                 CUDBG_ERROR_INVALID_ARGS,
                 "Number of ops must be non-zero and less than %d\n",
                 NV83DE_CTRL_GPU_EXEC_REG_OPS_MAX_OPS);

    params.bNonTransactional = nonTransactional;
    params.regOpCount = numOps;
    memcpy(params.regOps, script, sizeof(KdRegOp) * numOps);

    res = CudaRmControl(ctx->debugObject.rm.client, ctx->debugObject.rm.handle,
                        NV83DE_CTRL_CMD_DEBUG_EXEC_REG_OPS, &params,
                        sizeof(params));
    if (res != NV_OK) {
        HALO_ERROR("Failed to execute regops (result=0x%x)\n", res);
        return CUDBG_ERROR_INTERNAL;
    }

    memcpy(script, params.regOps, sizeof(KdRegOp) * numOps);

    return CUDBG_SUCCESS;
}

/* NOTE: Contains a risky/slow WAR, don't use in production code paths */
#define __WAR__GPU_PAGE_SIZE 0x1000
static CUDBGResult
kdapiAccessMemoryRM(KdContext ctx, NvBool read, const KdMemoryOp *memoryOps, NvU32 numOps)
{
    NV_STATUS res;
    NV83DE_CTRL_DEBUG_ACCESS_SURFACE_PARAMETERS params = { 0 };
    NvU32 i;

    CUDBG_VERIFY(ctx && ctx->debugObject.rm.handle, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    CUDBG_VERIFY(memoryOps, CUDBG_ERROR_INVALID_ARGS, "Memory ops pointer is not valid\n");
    CUDBG_VERIFY(numOps > 0, CUDBG_ERROR_INVALID_ARGS, "Number of ops must be non-zero\n");
    CUDBG_VERIFY(numOps <= MAX_ACCESS_OPS, CUDBG_ERROR_INVALID_ARGS, "Number of ops exceeds max allowed value\n");

    CUDBG_VERIFY(numOps == 1, CUDBG_ERROR_INVALID_ARGS, "TEMP: Number of ops must be 1\n");

    /* TEMP WAR for bug 2500023: the used RM memory access method does not support paging,
       work around this by splitting accesses into page-size aligned calls */
    if ((memoryOps[0].gpuVA % __WAR__GPU_PAGE_SIZE) + memoryOps[0].sizeInBytes > __WAR__GPU_PAGE_SIZE) {
        NvU32 offset = 0;
        NvU32 size = __WAR__GPU_PAGE_SIZE - (memoryOps[0].gpuVA % __WAR__GPU_PAGE_SIZE);
        while (offset < memoryOps[0].sizeInBytes) {
            KdMemoryOp op;

            op.buffer = NV_PTR_TO_NvP64(((NvU8 *)(NvUPtr)memoryOps[0].buffer) + offset);
            op.gpuVA = memoryOps[0].gpuVA + offset;
            op.sizeInBytes = size;

            res = kdapiAccessMemoryRM(ctx, read, &op, 1);

            if (res != NV_OK) {
                return CUDBG_ERROR_INTERNAL;
            }

            offset += size;
            size = MIN(__WAR__GPU_PAGE_SIZE, memoryOps[0].sizeInBytes - offset);
        }

        return CUDBG_SUCCESS;
    }

    params.count = numOps;
    for (i = 0; i < numOps; i++) {
        params.opsBuffer[i].gpuVA = memoryOps[i].gpuVA;
        params.opsBuffer[i].pCpuVA = memoryOps[i].buffer;
        params.opsBuffer[i].size = memoryOps[i].sizeInBytes;
    }

    res = CudaRmControl(ctx->debugObject.rm.client, ctx->debugObject.rm.handle,
        read ? NV83DE_CTRL_CMD_READ_SURFACE : NV83DE_CTRL_CMD_WRITE_SURFACE, &params, sizeof(params));

    if (res != NV_OK) {
        HALO_ERROR("Failed to %s memory (result=%d)\n", read ? "read" : "write", res);
        return CUDBG_ERROR_INTERNAL;
    }

    return CUDBG_SUCCESS;
}
#undef __WAR__GPU_PAGE_SIZE

static CUDBGResult
kdapiSetMmuDebugModeViaPRIRM(KdContext ctx, KdSetMmuDebugModeAction action, uint8_t regType) {
    KdRegOp regOp = { 0 };
    CUDBGResult res = CUDBG_SUCCESS;

    regOp.regOp = NV2080_CTRL_GPU_REG_OP_WRITE_32;
    regOp.regType = regType;
    regOp.regOffset = NV_PGRAPH_PRI_GPCS_MMU_DEBUG_CTRL;
    regOp.regValueLo = SETFIELD32(regOp.regValueLo, NV_PGRAPH_PRI_GPCS_MMU_DEBUG_CTRL_DEBUG, action == KDAPI_MMU_DEBUG_MODE_ENABLE ? 1 : 0);
    regOp.regAndNMaskLo = SETFIELD32(regOp.regAndNMaskLo, NV_PGRAPH_PRI_GPCS_MMU_DEBUG_CTRL_DEBUG, 1);

    res = kdapiExecRegOpsRM(ctx, NV_FALSE, &regOp, 1);
    HALO_TRACE(40, "%s MMU debug mode via PRI (%s)\n",
               res == CUDBG_SUCCESS ? "Set" : "Failed to set",
               regType == NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX ? "ctxsw" : "global");

    return res;
}

static CUDBGResult
kdapiSetMmuDebugModeRM(KdContext ctx, KdSetMmuDebugModeAction action)
{
    NV_STATUS res;
    NV83DE_CTRL_DEBUG_SET_MODE_MMU_DEBUG_PARAMS params = { 0 };

    CUDBG_VERIFY(ctx && ctx->debugObject.rm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");

    switch (action) {
    case KDAPI_MMU_DEBUG_MODE_ENABLE:
        params.action = NV83DE_CTRL_CMD_DEBUG_SET_MODE_MMU_DEBUG_ENABLE;
        break;
    case KDAPI_MMU_DEBUG_MODE_DISABLE:
        params.action = NV83DE_CTRL_CMD_DEBUG_SET_MODE_MMU_DEBUG_DISABLE;
        break;
    case KDAPI_MMU_DEBUG_MODE_RELEASE_REQUESTS:
        params.action = NV83DE_CTRL_CMD_DEBUG_RELEASE_MMU_DEBUG_REQUESTS;
        break;
    default:
        return CUDBG_ERROR_INVALID_ARGS;
    }

    res = CudaRmControl(ctx->debugObject.rm.client, ctx->debugObject.rm.handle,
        NV83DE_CTRL_CMD_DEBUG_SET_MODE_MMU_DEBUG, &params, sizeof(params));

    if (res != NV_OK) {
        HALO_ERROR("Failed to set MMU debug mode %d (result=%d)\n", action, res);
        return CUDBG_ERROR_INTERNAL;
    }

    // WAR for bug 2627515 - temporarily change the MMU debug mode via PRI
    if (action == KDAPI_MMU_DEBUG_MODE_ENABLE || action == KDAPI_MMU_DEBUG_MODE_DISABLE) {
        CUDBGResult res;

        res = kdapiSetMmuDebugModeViaPRIRM(ctx, action, NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX);
        if (res != CUDBG_SUCCESS) {
            /* In the CUDA compatibility scenarios, the kernel driver can be old enough
            to have the MMU Debug Mode register be global and not ctxsw, so retry with global PRI.
            This also accounts for chips where MMU Debug Mode was never made ctxsw, like GK110C. */
            res = kdapiSetMmuDebugModeViaPRIRM(ctx, action, NV2080_CTRL_GPU_REG_OP_TYPE_GLOBAL);
        }

        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiSetSingleStepModeRM(KdContext ctx, NvBool enable)
{
    NV_STATUS res;
    NV83DE_CTRL_DEBUG_SET_SINGLE_STEP_INTERRUPT_HANDLING_PARAMS params = { 0 };

    CUDBG_VERIFY(ctx && ctx->debugObject.rm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    
    params.singleStepHandling = enable
        ? NV83DE_CTRL_DEBUG_SET_SINGLE_STEP_INTERRUPT_HANDLING_PAUSING
        : NV83DE_CTRL_DEBUG_SET_SINGLE_STEP_INTERRUPT_HANDLING_NONPAUSING;

    res = CudaRmControl(ctx->debugObject.rm.client, ctx->debugObject.rm.handle,
        NV83DE_CTRL_CMD_DEBUG_SET_SINGLE_STEP_INTERRUPT_HANDLING, &params, sizeof(params));

    if (res != NV_OK) {
        HALO_ERROR("Failed to %s single step mode (result=%d)\n", enable ? "enable" : "disable", res);
        return CUDBG_ERROR_INTERNAL;
    }

    return CUDBG_SUCCESS;
}

ct_assert(sizeof(KdErrorState) == sizeof(NV83DE_SM_ERROR_STATE_REGISTERS));
static CUDBGResult
kdapiReadErrorStateRM(KdContext ctx, NvU32 vsm, KdErrorState *errorState)
{
    NV_STATUS res;
    NV83DE_CTRL_DEBUG_READ_SINGLE_SM_ERROR_STATE_PARAMS params = { 0 };

    CUDBG_VERIFY(ctx && ctx->debugObject.rm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    CUDBG_VERIFY(errorState, CUDBG_ERROR_INVALID_ARGS, "Error state pointer not valid\n");

    params.smID = vsm;
    params.hTargetChannel = NV01_NULL_OBJECT;

    res = CudaRmControl(ctx->debugObject.rm.client, ctx->debugObject.rm.handle,
        NV83DE_CTRL_CMD_DEBUG_READ_SINGLE_SM_ERROR_STATE, &params, sizeof(params));
    
    if (res != NV_OK) {
        HALO_ERROR("Failed to read the error state (result=%d)\n", res);
        return CUDBG_ERROR_INTERNAL;
    }

    memcpy(errorState, &params.smErrorState, sizeof(*errorState));

    return CUDBG_SUCCESS;
}

ct_assert(sizeof(KdErrorState) == sizeof(NV83DE_SM_ERROR_STATE_REGISTERS));
static CUDBGResult
kdapiReadErrorStatesRM(KdContext ctx, NvU32 numSMsToRead, NvU32 *mmuFaultInfo, NvBool *valid, KdErrorState *errorStateArray)
{
    // mmuFaultInfo and valid can be both NULL, in which case only error states are returned
    // likewise, numSMsToRead can be set to 0, in which case only the MMU fault info is returned

    NV_STATUS res;
    NV83DE_CTRL_DEBUG_READ_ALL_SM_ERROR_STATES_PARAMS params;
    NvU32 sectionStart = 0;

    CUDBG_VERIFY(ctx && ctx->debugObject.rm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    if (mmuFaultInfo) {
        CUDBG_VERIFY(valid, CUDBG_ERROR_INVALID_ARGS, "Valid flag pointer is not valid\n");
    }
    if (numSMsToRead > 0) {
        CUDBG_VERIFY(errorStateArray, CUDBG_ERROR_INVALID_ARGS, "Error state array is not valid\n");
    }

    do {
        memset(&params, 0,
               sizeof(NV83DE_CTRL_DEBUG_READ_ALL_SM_ERROR_STATES_PARAMS));

        params.numSMsToRead = MIN(numSMsToRead - sectionStart,
                                  NV83DE_CTRL_DEBUG_MAX_SMS_PER_CALL);
        params.startingSM = sectionStart;

        params.hTargetChannel = NV01_NULL_OBJECT;

        res = CudaRmControl(ctx->debugObject.rm.client,
                            ctx->debugObject.rm.handle,
                            NV83DE_CTRL_CMD_DEBUG_READ_ALL_SM_ERROR_STATES,
                            &params,
                            sizeof(params));
        if (res != NV_OK) {
            HALO_ERROR("Failed to read the error states (result=%d)\n", res);
            return CUDBG_ERROR_INTERNAL;
        }

        if (mmuFaultInfo) {
            *mmuFaultInfo = params.mmuFault.faultInfo;
            *valid = params.mmuFault.valid;
        }
        if (numSMsToRead > 0) {
            memcpy(errorStateArray + sectionStart, params.smErrorStateArray,
                   sizeof(KdErrorState) * params.numSMsToRead);
            sectionStart += params.numSMsToRead;
        }
    } while (sectionStart < numSMsToRead);

    return CUDBG_SUCCESS;
}

/* NOTE: Contains risky/slow WARs, don't use in production code paths */
static CUDBGResult
kdapiGetVARangesRM(KdContext ctx, NvU64 startVA, NvU64 endVA, KdVARangeInfo *ranges, NvU32 length, NvU32 *numRanges)
{
    NvU64 start;
    KdVARangeInfo dummyRange;
    KdVARangeInfo *currentRange = NULL;
    NvU32 nextRangeIndex = 0;

    CUDBG_VERIFY(ctx && ctx->debugObject.rm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    CUDBG_VERIFY(numRanges, CUDBG_ERROR_INVALID_ARGS, "Num ranges pointer is not valid\n");
    CUDBG_VERIFY(startVA < endVA, CUDBG_ERROR_INVALID_ARGS, "Requested VA range is not valid\n");

    start = startVA;
    while (1) {
        NV_STATUS res;
        NV83DE_CTRL_DEBUG_GET_MAPPINGS_PARAMETERS params = { 0 };
        NvU32 i;

        params.vaLo = start;
        params.vaHi = endVA;

        res = CudaRmControl(ctx->debugObject.rm.client, ctx->debugObject.rm.handle,
            NV83DE_CTRL_CMD_GET_MAPPINGS, &params, sizeof(params));

        if (res != NV_OK) {
            HALO_ERROR("Failed to read the error states (result=%d)\n", res);
            return CUDBG_ERROR_INTERNAL;
        }

        for (i = 0; i < params.count; i++) {
            /* TEMP WAR for bug 2500024: RM implementation does not coalesce the ranges,
               so coalesce them manually. */
            if (currentRange && currentRange->endVA == params.opsBuffer[i].gpuVA) {
                currentRange->endVA += params.opsBuffer[i].size;
            }
            else {
                /* If the caller only queries the number of ranges, use a dummy range */
                if (nextRangeIndex < length) {
                    currentRange = &ranges[nextRangeIndex];
                }
                else {
                    currentRange = &dummyRange;
                }
                nextRangeIndex++;
                currentRange->startVA = params.opsBuffer[i].gpuVA;
                currentRange->endVA = currentRange->startVA + params.opsBuffer[i].size;
            }
        }

        if (params.hasMore) {
            start = currentRange->endVA;
            continue;
        }

        *numRanges = nextRangeIndex;
        return CUDBG_SUCCESS;
    }
}

struct KdApi_st
globalKdApiRM = {
    &kdapiAllocDebugObjectRM,
    &kdapiFreeDebugObjectRM,
    &kdapiGetApiVersionRM,
    &kdapiRegisterDebugEventRM,
    &kdapiUnregisterDebugEventRM,
    &kdapiClearDebugEventRM,
    &kdapiSuspendContextRM,
    &kdapiResumeContextRM,
    &kdapiExecRegOpsRM,
    &kdapiAccessMemoryRM,
    &kdapiSetMmuDebugModeRM,
    &kdapiSetSingleStepModeRM,
    &kdapiReadErrorStateRM,
    &kdapiReadErrorStatesRM,
    &kdapiGetVARangesRM,
};

#else // cuosOsIsHos() || cuosOsIsQnx() || !defined(NV83DE_CTRL_CMD_DEBUG_SUSPEND_CONTEXT)

struct KdApi_st
globalKdApiRM;

#endif
