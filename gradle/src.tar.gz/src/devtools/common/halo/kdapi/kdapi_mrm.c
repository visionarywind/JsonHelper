/*
 * Copyright 2019 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */


/******************************************************************************
 *
 *   Module: kdapi_mrm.c
 *
 *   Description:
 *       Kernel-mode Debug API wrappers for MRM
 *
 ******************************************************************************/

#include "kdapi.h"

#include "halo_internal.h"
#include "cudbgutils.h"

#if cuosPlatformIncludesMrm() && (cuosOsIsAndroid() || cuosOsIsLinux() || cuosOsIsQnx())

#include "nvgpu.h"

// TODO: Add these checks for MRM
// ct_assert(KDAPI_MAX_REG_OPS <= <max MRM reg ops>);
// ct_assert(KDAPI_MAX_MEMORY_OPS <= <max MRM mem ops>);

/* Warning: this can only be used to call ioctls that take all arguments by value.
 * If your ioctl expects a pointer to a buffer, QNX has to know about it.
 * When in doubt, look up the definition of the ioctl argument struct.
 * If it contains anything that looks like a pointer, you need to use devctlv
 * and SETIOV, or the driver will read garbage, or you won't get results back.
 * To learn more, google for "QNX devctlv".
 */
static int32_t _ioctl(int32_t fd, int32_t cmd, void *args, size_t sizeofArgs)
{
#if cuosOsIsQnx()
    int32_t iocResult;

    iocResult = devctl(fd, cmd, args, sizeofArgs, NULL);
    /* On error, ioctl and devctl do different things:
     *   ioctl sets errno and returns -1
     *  devctl returns the error code directly
     * Make devctl look like ioctl. This pattern is inlined in several places
     * in this file, because devctlv is hard to wrap in a function or a macro.
     */
    if (iocResult != EOK) {
        errno = iocResult;
        iocResult = -1;
    }
    return iocResult;
#else
    return ioctl(fd, cmd, args);
#endif /* cuosOsIsQnx() */
}

static inline CUDBGResult
kdapiSetExceptionMask(int nvgpudbgfd) {
    /* MRM keeps it simple, currently only support SM_EXCEPTION_MASK_FATAL type
       If this type is set then the code will skip RC recovery, instead trigger
       CILP preemption.
    */
    struct nvgpu_dbg_gpu_set_sm_exception_type_mask_args set_sm_exception_type_mask_args = {0};

    CUDBG_VERIFY(nvgpudbgfd > 0, CUDBG_ERROR_INTERNAL,
                "Debug interface not initialized, cannot allocate event!\n");

    set_sm_exception_type_mask_args.exception_type_mask = NVGPU_DBG_GPU_IOCTL_SET_SM_EXCEPTION_TYPE_MASK_FATAL;
    int32_t iocResult = _ioctl(nvgpudbgfd,
                               NVGPU_DBG_GPU_IOCTL_SET_SM_EXCEPTION_TYPE_MASK,
                               &set_sm_exception_type_mask_args,
                               sizeof(set_sm_exception_type_mask_args));
    if (iocResult == -1) {
        HALO_ERROR("ioctl NVGPU_DBG_GPU_IOCTL_SET_SM_EXCEPTION_TYPE_MASK failed, "
                   "error: %s\n", strerror(errno));
        return CUDBG_ERROR_INTERNAL;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiOpenDebugDeviceMRM(CUdev *dev, int *nvgpudbgfd) {
    char path[CUDBG_UTIL_TMP_BUF_SIZE] = {0};
    size_t size = sizeof(path);
    CUresult cudaRes = CUDA_SUCCESS;
    char pciId[16] = {0};
    int res = 0;

    CUDBG_VERIFY(dev && nvgpudbgfd, CUDBG_ERROR_INVALID_ARGS, "Invalid arg: NULL pointer\n");

    if (dev->state.bIntegrated) {
        res = snprintf(path, size, "/dev/nvhost-dbg-gpu");
        CUDBG_VERIFY(0 < res && res < size, CUDBG_ERROR_BUFFER_TOO_SMALL,
                     "Output buffer too small to build the device name for iGPU.\n");
    }
    else {
        cudaRes = cuiDeviceGetPCIBusId(dev, pciId, sizeof(pciId));
        if (cudaRes != CUDA_SUCCESS)
        {
            const char *errorName;
            cuGetErrorName(cudaRes, &errorName);
            CUDBG_ERROR("cuiDeviceGetPCIBusId returned %s\n", errorName);
            return CUDBG_ERROR_INTERNAL;
        }

        res = snprintf(path, size, "/dev/nvgpu-pci/card-%s-dbg", pciId);
        CUDBG_VERIFY(0 < res && res < size, CUDBG_ERROR_BUFFER_TOO_SMALL,
                    "Output buffer too small to build the device name for dGPU at pciId %s\n", pciId);
    }

    CUDBG_TRACE("Opening debug device: %s\n", path);
    *nvgpudbgfd = open(path, O_RDWR);
    CUDBG_VERIFY(*nvgpudbgfd != -1, CUDBG_ERROR_INTERNAL,
                 "Failed to open nvgpu dbg fd, error: %s\n", strerror(errno));

    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiSetGlobalChannelTimeoutMRM(int nvgpudbgfd, bool enable)
{
    struct nvgpu_dbg_gpu_timeout_args args = {0};
    int32_t iocResult;

    args.enable = enable ? NVGPU_DBG_GPU_IOCTL_TIMEOUT_ENABLE : NVGPU_DBG_GPU_IOCTL_TIMEOUT_DISABLE;

    iocResult = _ioctl(nvgpudbgfd, NVGPU_DBG_GPU_IOCTL_TIMEOUT, &args, sizeof(args));

    CUDBG_VERIFY(iocResult != -1, CUDBG_ERROR_INTERNAL,
                 "ioctl NVGPU_DBG_GPU_IOCTL_TIMEOUT failed, error: %s\n",
                 strerror(errno));

    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiSetPowerGatingStateMRM(int nvgpudbgfd, HaloPowerGatingState state)
{
    struct nvgpu_dbg_gpu_powergate_args dbg_gpu_powergate = {0};
    int32_t iocResult;

    switch (state) {
    case HALO_POWER_GATING_STATE_ENABLED:
        dbg_gpu_powergate.mode = NVGPU_DBG_GPU_POWERGATE_MODE_ENABLE;
        break;
    case HALO_POWER_GATING_STATE_DISABLED:
        dbg_gpu_powergate.mode = NVGPU_DBG_GPU_POWERGATE_MODE_DISABLE;
        break;
    default:
        HALO_ERROR("Invalid power gating state requested\n");
        return CUDBG_ERROR_INVALID_ARGS;
    }

    iocResult = _ioctl(nvgpudbgfd,
                          NVGPU_DBG_GPU_IOCTL_POWERGATE,
                          &dbg_gpu_powergate, sizeof(dbg_gpu_powergate));
    CUDBG_VERIFY(iocResult != -1, CUDBG_ERROR_INTERNAL, "error: %s\n",
                 strerror(errno));

    return CUDBG_SUCCESS;
}

/* TODO: stop passing Context as CUctx */
static CUDBGResult
kdapiAllocDebugObjectMRM(const CUctx *haloCtx, KdDebugObject *debugObject)
{
    CUDBGResult res = CUDBG_SUCCESS;
    struct nvgpu_dbg_gpu_bind_channel_args dbg_bind_chan_args = {0};
    int32_t iocResult;
    int32_t i = 0;
    Context ctx = (Context)haloCtx;
    int32_t nvgpudbgfd;

    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_ARGS, "Context is not valid\n");
    CUDBG_VERIFY(debugObject, CUDBG_ERROR_INVALID_ARGS, "Debug object pointer is not valid\n");

    nvgpudbgfd = -1;
    debugObject->mrm.handle = -1;

    res = kdapiOpenDebugDeviceMRM(globals.devices[ctx->dev->deviceIdx], &nvgpudbgfd);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, CUDBG_ERROR_INTERNAL, "Failed to open debug device\n");

    HALO_TRACE_FUNCTION(49, "Binding channels...\n");

    /* Bind all the channels associated with the context to this debug session */
    for (i = 0; i < ctx->numChannels; ++i) {
        /* Bind the compute channel to the context-wide debug session for events and ctx ioctls */
        dbg_bind_chan_args.channel_fd = ctx->channelfds[i];

        if (!HALO_IS_FD_VALID(ctx->channelfds[i])) {
            HALO_ERROR("Invalid channel fd given for channel %d on context %p\n", i, ctx);
            res = CUDBG_ERROR_INTERNAL;
            goto error_close;
        }

        HALO_TRACE_FUNCTION(30, "Binding channel fd %d\n", ctx->channelfds[i]);
        iocResult = _ioctl(nvgpudbgfd,
                           NVGPU_DBG_GPU_IOCTL_BIND_CHANNEL,
                           &dbg_bind_chan_args, sizeof(dbg_bind_chan_args));
        if (iocResult == -1) {
            HALO_ERROR("ioctl NVGPU_DBG_GPU_IOCTL_BIND_CHANNEL (ctx) failed, "
                       "error: %s\n", strerror(errno));
            res = CUDBG_ERROR_INTERNAL;
            goto error_close;
        }
    }

    /* Disable any channel timeouts */
    res = kdapiSetGlobalChannelTimeoutMRM(nvgpudbgfd, false);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to disable channel timeouts!\n");
        goto error_close;
    }

    /* Disable power gating */
    res = kdapiSetPowerGatingStateMRM(nvgpudbgfd, HALO_POWER_GATING_STATE_DISABLED);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to set power gating state!\n");
        goto error_close;
    }

    res = kdapiSetExceptionMask(nvgpudbgfd);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, CUDBG_ERROR_INTERNAL, "Failed to set exception mask\n");

    debugObject->mrm.handle = nvgpudbgfd;

    return res;

error_close:
    close(nvgpudbgfd);

    return res;
}

/* TODO: stop passing Context as CUctx */
static CUDBGResult
kdapiFreeDebugObjectMRM(const CUctx *haloCtx, KdDebugObject debugObject)
{
    Context ctx = (Context)haloCtx;

    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_ARGS, "Context handle is not valid\n");
    CUDBG_VERIFY(debugObject.mrm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");

    CUDBGResult res = kdapiSetPowerGatingStateMRM(debugObject.mrm.handle, HALO_POWER_GATING_STATE_ENABLED);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to set power gating state!\n");

    struct nvgpu_dbg_gpu_unbind_channel_args args = {0};
    int32_t iocResult = 0;

    for (size_t i = 0; i < ctx->numChannels; ++i) {
        args.channel_fd = ctx->channelfds[i];

        /* Don't leak the channel fd, unbind it from the device-wide debug session */
        iocResult = _ioctl(debugObject.mrm.handle,
                           NVGPU_DBG_GPU_IOCTL_UNBIND_CHANNEL,
                           &args, sizeof(args));
        CUDBG_VERIFY(iocResult != -1, CUDBG_ERROR_INTERNAL,
                     "ioctl NVGPU_DBG_GPU_IOCTL_UNBIND_CHANNEL failed, ",
                     "returned %d, errno says %s\n",
                     iocResult, strerror(errno));
    }

    if (close(debugObject.mrm.handle) == -1) {
        HALO_ERROR("Failed when closing nvgpudbgfd. Error:%s\n", strerror(errno));
        return CUDBG_ERROR_INTERNAL;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiGetApiVersionMRM(KdDeviceHandle deviceHandle, NvU32 *major, NvU32 *minor)
{
    CUDBG_VERIFY(major && minor, CUDBG_ERROR_INVALID_ARGS, "Version part pointers are not valid\n");

    HALO_ERROR("Not implemented\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
kdapiRegisterDebugEventMRM(KdContext ctx, KdOsEventHandle hOsEvent)
{
    struct nvgpu_dbg_gpu_events_ctrl_args events_ctrl_args = {0};
    int32_t iocResult;

    CUDBG_VERIFY(ctx && ctx->debugObject.mrm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    CUDBG_VERIFY(hOsEvent.nix.fd == ctx->debugObject.mrm.handle, CUDBG_ERROR_INVALID_ARGS, "Event handle must match debug object handle\n");

    /* nvgpu will hard-code the places where we need events, so class types are not necessary (yet) */
    events_ctrl_args.cmd = NVGPU_DBG_GPU_EVENTS_CTRL_CMD_ENABLE;

    iocResult = _ioctl(ctx->debugObject.mrm.handle,
                       NVGPU_DBG_GPU_IOCTL_EVENTS_CTRL,
                       &events_ctrl_args, sizeof(events_ctrl_args));
    CUDBG_VERIFY(iocResult != -1, CUDBG_ERROR_INTERNAL,
                 "ioctl NVGPU_DBG_GPU_IOCTL_EVENTS_CTRL failed, error: %s\n",
                 strerror(errno));

    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiUnregisterDebugEventMRM(KdContext ctx)
{
    struct nvgpu_dbg_gpu_events_ctrl_args events_ctrl_args = {0};
    int32_t iocResult;

    CUDBG_VERIFY(ctx && ctx->debugObject.mrm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");

    events_ctrl_args.cmd = NVGPU_DBG_GPU_EVENTS_CTRL_CMD_DISABLE;

    iocResult = _ioctl(ctx->debugObject.mrm.handle,
                       NVGPU_DBG_GPU_IOCTL_EVENTS_CTRL,
                       &events_ctrl_args, sizeof(events_ctrl_args));
    CUDBG_VERIFY(iocResult != -1, CUDBG_ERROR_INTERNAL,
                 "ioctl NVGPU_DBG_GPU_IOCTL_EVENTS_CTRL failed, error: %s\n",
                 strerror(errno));

    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiClearDebugEventMRM(KdContext ctx)
{
    CUDBG_VERIFY(ctx && ctx->debugObject.mrm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");

    int nvgpudbgfd = ctx->debugObject.mrm.handle;
    struct nvgpu_dbg_gpu_events_ctrl_args events_ctrl_args = {0};
    events_ctrl_args.cmd = NVGPU_DBG_GPU_EVENTS_CTRL_CMD_CLEAR;

    int32_t res = _ioctl(nvgpudbgfd,
                         NVGPU_DBG_GPU_IOCTL_EVENTS_CTRL,
                         &events_ctrl_args, sizeof(events_ctrl_args));

    CUDBG_VERIFY(res != -1, CUDBG_ERROR_INTERNAL, "NVGPU_DBG_GPU_IOCTL_EVENTS_CTRL failed.\n");

    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiSuspendContextMRM(KdContext ctx, NvBool *shouldWait)
{
    struct nvgpu_dbg_gpu_suspend_resume_contexts_args args = {0};
    int32_t iocResult;

    CUDBG_VERIFY(ctx && ctx->debugObject.mrm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    CUDBG_VERIFY(shouldWait, CUDBG_ERROR_INVALID_ARGS, "Should wait pointer is not valid\n");

    args.action = NVGPU_DBG_GPU_SUSPEND_ALL_CONTEXTS;

    iocResult = _ioctl(ctx->debugObject.mrm.handle, NVGPU_DBG_GPU_IOCTL_SUSPEND_RESUME_CONTEXTS, &args, sizeof(args));

    CUDBG_VERIFY(iocResult != -1, CUDBG_ERROR_INTERNAL,
                 "ioctl NVGPU_DBG_GPU_SUSPEND_ALL_CONTEXTS failed, error: %s\n",
                 strerror(errno));

    /* MRM is synchronous, don't need to wait */
    *shouldWait = false;
    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiResumeContextMRM(KdContext ctx)
{
    struct nvgpu_dbg_gpu_suspend_resume_contexts_args args = {0};
    int32_t iocResult;

    CUDBG_VERIFY(ctx && ctx->debugObject.mrm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");

    args.action = NVGPU_DBG_GPU_RESUME_ALL_CONTEXTS;

    iocResult = _ioctl(ctx->debugObject.mrm.handle, NVGPU_DBG_GPU_IOCTL_SUSPEND_RESUME_CONTEXTS, &args, sizeof(args));

    CUDBG_VERIFY(iocResult != -1, CUDBG_ERROR_INTERNAL,
                 "ioctl NVGPU_DBG_GPU_RESUME_ALL_CONTEXTS failed, error: %s\n",
                 strerror(errno));

    return CUDBG_SUCCESS;
}

/* NOTE: `script` argument below is expected to be filled in nvgpu_dbg_gpu_reg_op format
   Changes will be needed to support using the same KdRegOp script on all platforms */
ct_assert(sizeof(KdRegOp) == sizeof(struct nvgpu_dbg_gpu_reg_op));
static CUDBGResult
kdapiExecRegOpsMRM(KdContext ctx, NvBool nonTransactional, KdRegOp *script, NvU32 numOps)
{
    struct nvgpu_dbg_gpu_exec_reg_ops_args execRegOps = {0};
    int32_t iocResult = 0;

    CUDBG_VERIFY(ctx && ctx->debugObject.mrm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    CUDBG_VERIFY(script, CUDBG_ERROR_INVALID_ARGS, "PRI script pointer is not valid\n");
    CUDBG_VERIFY(numOps > 0, CUDBG_ERROR_INVALID_ARGS, "Number of ops must be non-zero\n");
    // TODO: check against max reg ops count

    execRegOps.ops = (uint64_t)(uintptr_t)script;
    execRegOps.num_ops = numOps;

#if cuosOsIsQnx()
    iov_t sv[2];
    iov_t rv[2];
    SETIOV(&sv[0], &execRegOps, sizeof(execRegOps));
    SETIOV(&sv[1], script, numOps * sizeof(*script));
    SETIOV(&rv[0], &execRegOps, sizeof(execRegOps));
    SETIOV(&rv[1], script, numOps * sizeof(*script));
    /* On QNX, execRegOps and regOps must be adjacent in memory (execRegOps.ops == &execRegOps + 1),
     * according to the comment about nvgpu_dbg_gpu_exec_reg_ops_args in qnx/core/include/qnx/nvgpu.h,
     * and to the implementation in qnx/src/resmgrs/nvrm/nvhost/mixed/gk20a/dbg_gpu_gk20a_ioctl.c.
     * In the time honored tradition of coding against the implementation, this code relies
     * on the fact that devctlv copies its arguments into one contiguous buffer. In the unlikely event
     * that it changes, rewrite kdapiExecRegOpsMRM to allocate everything in one calloc. */
    errno = devctlv(ctx->debugObject.mrm.handle,
                        (int32_t)NVGPU_DBG_GPU_IOCTL_REG_OPS,
                        sizeof(sv) / sizeof(sv[0]),  /* int sparts         */
                        sizeof(rv) / sizeof(rv[0]),  /* int rparts         */
                        sv,                          /* const iov_t *sv    */
                        rv,                          /* const iov_t *rv    */
                        NULL);                       /* int *dev_info_ptr  */
    if (errno != EOK) {
        iocResult = -1;
    }
#else
    iocResult = ioctl(ctx->debugObject.mrm.handle, (int32_t)NVGPU_DBG_GPU_IOCTL_REG_OPS, &execRegOps);
#endif
    CUDBG_VERIFY(iocResult == 0, CUDBG_ERROR_INTERNAL,
                 "ioctl for reg_ops failed with error %d (%s)\n",
                 errno, strerror(errno));
    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiAccessMemoryMRM(KdContext ctx, NvBool read, const KdMemoryOp *memoryOps, NvU32 numOps)
{
    CUDBG_VERIFY(ctx && ctx->debugObject.mrm.handle, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    CUDBG_VERIFY(memoryOps, CUDBG_ERROR_INVALID_ARGS, "Memory ops pointer is not valid\n");
    CUDBG_VERIFY(numOps > 0, CUDBG_ERROR_INVALID_ARGS, "Number of ops must be non-zero\n");
    // TODO: check against max mem ops count

    HALO_ERROR("Not implemented\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
kdapiSetMmuDebugModeMRM(KdContext ctx, KdSetMmuDebugModeAction action)
{
    CUDBG_VERIFY(ctx && ctx->debugObject.mrm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");

    HALO_ERROR("Not implemented\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
kdapiSetSingleStepModeMRM(KdContext ctx, NvBool enable)
{
    CUDBG_VERIFY(ctx && ctx->debugObject.mrm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");

    HALO_ERROR("Not implemented\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
kdapiReadErrorStateMRM(KdContext ctx, NvU32 vsm, KdErrorState *errorState)
{
    struct nvgpu_dbg_gpu_read_single_sm_error_state_args args = {0};
    struct nvgpu_dbg_gpu_sm_error_state_record smState = {0};
    int32_t iocResult = 0;
    const int32_t cmd = NVGPU_DBG_GPU_IOCTL_READ_SINGLE_SM_ERROR_STATE;

    CUDBG_VERIFY(ctx && ctx->debugObject.mrm.handle > 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    CUDBG_VERIFY(errorState, CUDBG_ERROR_INVALID_ARGS, "Error state pointer not valid\n");

    args.sm_id = vsm;
    args.sm_error_state_record_mem = (uintptr_t)&smState; // Ignored on QNX
    args.sm_error_state_record_size = sizeof(smState);

#if cuosOsIsQnx()
    iov_t in[1];
    iov_t out[2];

    SETIOV(&in[0], &args, sizeof(args));
    SETIOV(&out[0], &args, sizeof(args));
    SETIOV(&out[1], &smState, sizeof(smState));

    errno = devctlv(ctx->debugObject.mrm.handle, cmd, 1, 2, in, out, NULL);
    if (errno != EOK) {
        iocResult = -1;
    }
#else
    iocResult = ioctl(ctx->debugObject.mrm.handle, cmd, &args);
#endif

    if (iocResult < 0) {
        HALO_ERROR("ioctl NVGPU_DBG_GPU_IOCTL_READ_SINGLE_SM_ERROR_STATE failed, "
                   "error: %s (sm_id = %u)\n", strerror(errno), vsm);
        return CUDBG_ERROR_INTERNAL;
    }

    errorState->hwwGlobalEsr            = smState.hww_global_esr;
    errorState->hwwWarpEsr              = smState.hww_warp_esr;
    errorState->hwwWarpEsrPc64          = smState.hww_warp_esr_pc;
    errorState->hwwGlobalEsrReportMask  = smState.hww_global_esr_report_mask;
    errorState->hwwWarpEsrReportMask    = smState.hww_warp_esr_report_mask;

    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiReadErrorStatesMRM(KdContext ctx, NvU32 numSMsToRead, NvU32 *mmuFaultInfo, NvBool *valid, KdErrorState *errorStateArray)
{
    CUDBG_VERIFY(ctx && ctx->debugObject.mrm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    if (mmuFaultInfo) {
        CUDBG_VERIFY(valid, CUDBG_ERROR_INVALID_ARGS, "Valid flag pointer is not valid\n");
    }
    if (numSMsToRead > 0) {
        CUDBG_VERIFY(errorStateArray, CUDBG_ERROR_INVALID_ARGS, "Error state array is not valid\n");
    }

    HALO_ERROR("Not implemented\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
kdapiGetVARangesMRM(KdContext ctx, NvU64 startVA, NvU64 endVA, KdVARangeInfo *ranges, NvU32 length, NvU32 *numRanges)
{
    CUDBG_VERIFY(ctx && ctx->debugObject.mrm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    CUDBG_VERIFY(numRanges, CUDBG_ERROR_INVALID_ARGS, "Num ranges pointer is not valid\n");
    CUDBG_VERIFY(startVA < endVA, CUDBG_ERROR_INVALID_ARGS, "Requested VA range is not valid\n");

    HALO_ERROR("Not implemented\n");
    return CUDBG_ERROR_INTERNAL;
}

struct KdApi_st
globalKdApiMRM = {
    &kdapiAllocDebugObjectMRM,
    &kdapiFreeDebugObjectMRM,
    &kdapiGetApiVersionMRM,
    &kdapiRegisterDebugEventMRM,
    &kdapiUnregisterDebugEventMRM,
    &kdapiClearDebugEventMRM,
    &kdapiSuspendContextMRM,
    &kdapiResumeContextMRM,
    &kdapiExecRegOpsMRM,
    &kdapiAccessMemoryMRM,
    &kdapiSetMmuDebugModeMRM,
    &kdapiSetSingleStepModeMRM,
    &kdapiReadErrorStateMRM,
    &kdapiReadErrorStatesMRM,
    &kdapiGetVARangesMRM,
};

#else // !cuosPlatformIncludesMrm() || (!cuosOsIsAndroid() && !cuosOsIsLinux() && !cuosOsIsQnx())

struct KdApi_st
globalKdApiMRM;

#endif
