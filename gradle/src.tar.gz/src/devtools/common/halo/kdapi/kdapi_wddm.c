/*
* Copyright 2018 NVIDIA Corporation.  All rights reserved.
*
* NOTICE TO USER:
*
* This source code is subject to NVIDIA ownership rights under U.S. and
* international Copyright laws.  Users and possessors of this source code
* are hereby granted a nonexclusive, royalty-free license to use this code
* in individual and commercial software.
*
* NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
* CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
* IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
* REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
* OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
* OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
* OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
* OR PERFORMANCE OF THIS SOURCE CODE.
*
* U.S. Government End Users.   This source code is a "commercial item" as
* that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
* "commercial computer  software"  and "commercial computer software
* documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
* and is provided to the U.S. Government only as a commercial end item.
* Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
* 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
* source code with only those rights set forth herein.
*
* Any use of this source code in individual and commercial software must
* include, in the user documentation and internal comments to the code,
* the above Disclaimer and U.S. Government End Users Notice.
*/


/******************************************************************************
*
*   Module: kdapi_wddm.c
*
*   Description:
*       Kernel-mode Debug API wrappers for WDDM
*
******************************************************************************/

#include "kdapi.h"

#include "halo_internal.h"
#include "cudbgutils.h"

#if cuiPlatformIncludesWddm()

// CUDA
#include "channel_private.h"
#include "wddm_channel.h"
#include "wddm_device.h"
#include "wddm_escape.h"
#include "wddm_hwsched_channel.h"
#include "wddm_thunk.h"

// Chips
#include "kepler/gk104/dev_graphics_nobundle.h"

// Windows
#include "windows.h"

#define ESCAPE_DATA(type, varname)      \
    NVL_ESC_COMMON_##type varname;      \
    NVL_ESC_INIT(                       \
        &varname.Header,                \
        sizeof(varname),                \
        NVL_PRIV_CALLER_ID_WILDCARD,    \
        NVL_ESC_ID_COMMON_##type);

#define ESCAPE(hAdapter, escapeData)    \
    (thunkEscape(                       \
        hAdapter,                       \
        0, /* No specific device */     \
        0, /* No specific context */    \
        D3DKMT_ESCAPE_DRIVERPRIVATE,    \
        sizeof(escapeData),             \
        &escapeData,                    \
        NV_FALSE))

ct_assert(KDAPI_MAX_REG_OPS <= NVL_MAX_REG_OPS);
ct_assert(KDAPI_MAX_MEMORY_OPS <= NVL_MAX_DEBUG_MEMORY_ACCESS_OPS);

static CUDBGResult
kdapiGetContextHandleWDDM(const CUctx *ctx, D3DKMT_HANDLE *hContext)
{
    CUnvchannel *channel;
    
    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_ARGS, "Context is NULL\n");
    CUDBG_VERIFY(hContext, CUDBG_ERROR_INVALID_ARGS, "Context handle is NULL\n");

    *hContext = 0;
    channel = channelManagerGetChannel(ctx->channelManager, CU_CHANNEL_COMPUTE);

    CUDBG_VERIFY(channel, CUDBG_ERROR_INTERNAL, "No compute channel in the context\n");
    CUDBG_VERIFY(channel->channelFlushUnit, CUDBG_ERROR_INTERNAL, "Channel flush unit is NULL\n");
    CUDBG_VERIFY(channel->channelFlushUnit->dm.wddm || channel->channelFlushUnit->dm.wddmhwsched, CUDBG_ERROR_INTERNAL, "Channel is not a WDDM channel\n");

    if (channel->channelFlushUnit->dm.wddmhwsched) {
        *hContext = channel->channelFlushUnit->dm.wddmhwsched->wddmHwContext->hContext;
    }
    else {
        *hContext = channel->channelFlushUnit->dm.wddm->vistaCtx->hContext;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiAllocDebugObjectWDDM(const CUctx *ctx, KdDebugObject *debugObject)
{
    CUresult status;
    CUDBGResult res;
    D3DKMT_HANDLE hContext;
    ESCAPE_DATA(DEBUG_OBJECT_ALLOC, escape);

    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_ARGS, "Context is not valid\n");
    CUDBG_VERIFY(debugObject, CUDBG_ERROR_INVALID_ARGS, "Debug object pointer is not valid\n");

    res = kdapiGetContextHandleWDDM(ctx, &hContext);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to get a WDDM context handle from the context\n");
        return res;
    }

    escape.input.exceptionMask = ctx->preemption->mode == CU_COMPUTE_PREEMPTION_MODE_CILP ?
        NV83DE_CTRL_DEBUG_SET_EXCEPTION_MASK_CILP | NV83DE_CTRL_DEBUG_SET_EXCEPTION_MASK_FATAL :
        NV83DE_CTRL_DEBUG_SET_EXCEPTION_MASK_TRAP | NV83DE_CTRL_DEBUG_SET_EXCEPTION_MASK_FATAL | NV83DE_CTRL_DEBUG_SET_EXCEPTION_MASK_SINGLE_STEP;

    status = thunkEscape(
        deviceGetAdapterHandleWDDM(ctx->device),
        ctxGetVistaDeviceWDDM(ctx)->hDevice,
        hContext,
        D3DKMT_ESCAPE_DRIVERPRIVATE,
        sizeof(escape),
        &escape,
        NV_FALSE);

    if (status != CUDA_SUCCESS || escape.Header.lResult != NVL_ESC_RESULT_SUCCESS) {
        HALO_ERROR("Failed to allocate a debug object (status=%d, result=%d)\n", status, escape.Header.lResult);
        return CUDBG_ERROR_INTERNAL;
    }

    debugObject->wddm.handle = escape.output.hDebugObject;

    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiFreeDebugObjectWDDM(const CUctx *ctx, KdDebugObject debugObject)
{
    CUDBGResult res;
    CUresult status;
    D3DKMT_HANDLE hContext;
    ESCAPE_DATA(DEBUG_OBJECT_FREE, escape);

    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_ARGS, "Context handle is not valid\n");
    CUDBG_VERIFY(debugObject.wddm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");

    res = kdapiGetContextHandleWDDM(ctx, &hContext);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to get a WDDM context handle from the context\n");
        return res;
    }

    escape.input.hDebugObject = debugObject.wddm.handle;

    status = thunkEscape(
        deviceGetAdapterHandleWDDM(ctx->device),
        ctxGetVistaDeviceWDDM(ctx)->hDevice,
        hContext,
        D3DKMT_ESCAPE_DRIVERPRIVATE,
        sizeof(escape),
        &escape,
        NV_FALSE);

    if (status != CUDA_SUCCESS || escape.Header.lResult != NVL_ESC_RESULT_SUCCESS) {
        HALO_ERROR("Failed to free a debug object (status=%d, result=%d)\n", status, escape.Header.lResult);
        return CUDBG_ERROR_INTERNAL;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiGetApiVersionWDDM(KdDeviceHandle deviceHandle, NvU32 *major, NvU32 *minor)
{
    CUresult status;
    ESCAPE_DATA(DEBUG_GET_VERSION, escape);

    CUDBG_VERIFY(deviceHandle.wddm.hAdapter != 0, CUDBG_ERROR_INVALID_ARGS, "Adapter is not valid\n");
    CUDBG_VERIFY(major && minor, CUDBG_ERROR_INVALID_ARGS, "Version part pointers are not valid\n");

    status = ESCAPE(deviceHandle.wddm.hAdapter, escape);

    if (status != CUDA_SUCCESS || escape.Header.lResult != NVL_ESC_RESULT_SUCCESS) {
        HALO_ERROR("Failed to unregister a debug event (status=%d, result=%d)\n", status, escape.Header.lResult);
        return CUDBG_ERROR_INTERNAL;
    }

    *major = escape.output.majorVersion;
    *minor = escape.output.minorVersion;

    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiRegisterDebugEventWDDM(KdContext ctx, KdOsEventHandle hOsEvent)
{
    CUresult status;
    ESCAPE_DATA(DEBUG_SUBSCRIBE_DEBUG_NOTIFIER, escape);

    CUDBG_VERIFY(ctx && ctx->debugObject.wddm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    CUDBG_VERIFY(ctx->deviceHandle.wddm.hAdapter != 0, CUDBG_ERROR_INVALID_ARGS, "Adapter is not valid\n");
    CUDBG_VERIFY(hOsEvent.windows.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Event handle is not valid\n");

    escape.input.hDebugObject = ctx->debugObject.wddm.handle;
    escape.input.hEventEx.handle = hOsEvent.windows.handle;

    status = ESCAPE(ctx->deviceHandle.wddm.hAdapter, escape);

    if (status != CUDA_SUCCESS || escape.Header.lResult != NVL_ESC_RESULT_SUCCESS) {
        HALO_ERROR("Failed to register a debug event (status=%d, result=%d)\n", status, escape.Header.lResult);
        return CUDBG_ERROR_INTERNAL;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiUnregisterDebugEventWDDM(KdContext ctx)
{
    CUresult status;
    ESCAPE_DATA(DEBUG_UNSUBSCRIBE_DEBUG_NOTIFIER, escape);

    CUDBG_VERIFY(ctx && ctx->debugObject.wddm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    CUDBG_VERIFY(ctx->deviceHandle.wddm.hAdapter != 0, CUDBG_ERROR_INVALID_ARGS, "Adapter is not valid\n");

    escape.input.hDebugObject = ctx->debugObject.wddm.handle;

    status = ESCAPE(ctx->deviceHandle.wddm.hAdapter, escape);

    if (status != CUDA_SUCCESS || escape.Header.lResult != NVL_ESC_RESULT_SUCCESS) {
        HALO_ERROR("Failed to unregister a debug event (status=%d, result=%d)\n", status, escape.Header.lResult);
        return CUDBG_ERROR_INTERNAL;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiClearDebugEventWDDM(KdContext ctx)
{
    /* Function not needed on WDDM */
    (void)ctx;
    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiSuspendContextWDDM(KdContext ctx, NvBool *shouldWait)
{
    CUresult status;
    ESCAPE_DATA(DEBUG_SUSPEND_CONTEXT, escape);

    CUDBG_VERIFY(ctx && ctx->debugObject.wddm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    CUDBG_VERIFY(ctx->deviceHandle.wddm.hAdapter != 0, CUDBG_ERROR_INVALID_ARGS, "Adapter is not valid\n");
    CUDBG_VERIFY(shouldWait, CUDBG_ERROR_INVALID_ARGS, "Should wait pointer is not valid\n");

    escape.input.hDebugObject = ctx->debugObject.wddm.handle;

    status = ESCAPE(ctx->deviceHandle.wddm.hAdapter, escape);

    if (status != CUDA_SUCCESS || escape.Header.lResult != NVL_ESC_RESULT_SUCCESS) {
        HALO_ERROR("Failed to suspend a context (status=%d, result=%d)\n", status, escape.Header.lResult);
        *shouldWait = NV_FALSE;
        return CUDBG_ERROR_INTERNAL;
    }

    *shouldWait = escape.output.shouldWait;
    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiResumeContextWDDM(KdContext ctx)
{
    CUresult status;
    ESCAPE_DATA(DEBUG_RESUME_CONTEXT, escape);

    CUDBG_VERIFY(ctx && ctx->debugObject.wddm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    CUDBG_VERIFY(ctx->deviceHandle.wddm.hAdapter != 0, CUDBG_ERROR_INVALID_ARGS, "Adapter is not valid\n");

    escape.input.hDebugObject = ctx->debugObject.wddm.handle;

    status = ESCAPE(ctx->deviceHandle.wddm.hAdapter, escape);

    if (status != CUDA_SUCCESS || escape.Header.lResult != NVL_ESC_RESULT_SUCCESS) {
        HALO_ERROR("Failed to resume a context (status=%d, result=%d)\n", status, escape.Header.lResult);
        return CUDBG_ERROR_INTERNAL;
    }

    return CUDBG_SUCCESS;
}

ct_assert(sizeof(KdRegOp) == sizeof(NV2080_CTRL_GPU_REG_OP));
static CUDBGResult
kdapiExecRegOpsWDDM(KdContext ctx, NvBool nonTransactional, KdRegOp *script, NvU32 numOps)
{
    CUresult status;
    ESCAPE_DATA(DEBUG_REG_OPS, escape);

    CUDBG_VERIFY(ctx && ctx->debugObject.wddm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    CUDBG_VERIFY(ctx->deviceHandle.wddm.hAdapter != 0, CUDBG_ERROR_INVALID_ARGS, "Adapter is not valid\n");
    CUDBG_VERIFY(script, CUDBG_ERROR_INVALID_ARGS, "PRI script pointer is not valid\n");
    CUDBG_VERIFY(numOps > 0, CUDBG_ERROR_INVALID_ARGS, "Number of ops must be non-zero\n");
    CUDBG_VERIFY(numOps <= NVL_MAX_REG_OPS, CUDBG_ERROR_INVALID_ARGS, "Number of ops exceeds max allowed value\n");

    escape.input.hDebugObject = ctx->debugObject.wddm.handle;
    escape.input.isNonTransactional = nonTransactional;
    escape.input.numRegOps = numOps;
    memcpy(escape.input.regOps, script, numOps * sizeof(*script));

    status = ESCAPE(ctx->deviceHandle.wddm.hAdapter, escape);

    if (status != CUDA_SUCCESS || escape.Header.lResult != NVL_ESC_RESULT_SUCCESS) {
        HALO_ERROR("Failed to execute regops (status=%d, result=%d)\n", status, escape.Header.lResult);
        return CUDBG_ERROR_UNKNOWN;
    }

    memcpy(script, escape.input.regOps, numOps * sizeof(*script));

    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiAccessMemoryWDDM(KdContext ctx, NvBool read, const KdMemoryOp *memoryOps, NvU32 numOps)
{
    CUresult status;
    ESCAPE_DATA(DEBUG_READ_WRITE_SURFACE, escape);

    CUDBG_VERIFY(ctx && ctx->debugObject.wddm.handle, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    CUDBG_VERIFY(ctx->deviceHandle.wddm.hAdapter != 0, CUDBG_ERROR_INVALID_ARGS, "Adapter is not valid\n");
    CUDBG_VERIFY(memoryOps, CUDBG_ERROR_INVALID_ARGS, "Memory ops pointer is not valid\n");
    CUDBG_VERIFY(numOps > 0, CUDBG_ERROR_INVALID_ARGS, "Number of ops must be non-zero\n");
    CUDBG_VERIFY(numOps <= NVL_MAX_DEBUG_MEMORY_ACCESS_OPS, CUDBG_ERROR_INVALID_ARGS, "Number of ops exceeds max allowed value\n");

    escape.input.hDebugObject = ctx->debugObject.wddm.handle;
    escape.input.accessType = read ? NVL_MEMORY_ACCESS_TYPE_READ : NVL_MEMORY_ACCESS_TYPE_WRITE;
    escape.input.numOps = numOps;
    for (NvU32 i = 0; i < numOps; i++) {
        escape.input.memoryAccessOps[i].gpuVA = memoryOps[i].gpuVA;
        escape.input.memoryAccessOps[i].pUserBuffer = memoryOps[i].buffer;
        escape.input.memoryAccessOps[i].sizeInBytes = memoryOps[i].sizeInBytes;
    }

    // WAR for nvbug 2453858 - wddm issue where the driver reports STATUS_INVALID_PARAMETER in single GPU systems when read memory after suspend.
    // The driver has a race condition where it fails but will work a little bit later.
    for (NvU32 index = 0; index < 10; index++) {
        status = ESCAPE(ctx->deviceHandle.wddm.hAdapter, escape);
        if (status == CUDA_SUCCESS && escape.Header.lResult == NVL_ESC_RESULT_SUCCESS) {
            break;
        }

        HALO_ERROR("Attempt: %d Failed to %s memory (status=%d, result=%d):\n", index, read ? "read" : "write", status, escape.Header.lResult);

        // Retrying allows this to work when the driver has not locked down correctly yet.
        cuosSleep(1);
    }

    if (status != CUDA_SUCCESS || escape.Header.lResult != NVL_ESC_RESULT_SUCCESS) {
        HALO_ERROR("Failed to %s memory (status=%d, result=%d):\n", read ? "read" : "write", status, escape.Header.lResult);
        for (NvU32 i = 0; i < numOps; i++) {
            HALO_ERROR("    [0x%llx, 0x%llx) - 0x%llx bytes\n", memoryOps[i].gpuVA, memoryOps[i].gpuVA + memoryOps[i].sizeInBytes, memoryOps[i].sizeInBytes);
        }
        return CUDBG_ERROR_INTERNAL;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiSetMmuDebugModeViaPRIWDDM(KdContext ctx, KdSetMmuDebugModeAction action, uint8_t regType) {
    KdRegOp regOp = { 0 };
    CUDBGResult res = CUDBG_SUCCESS;

    regOp.regOp = NV2080_CTRL_GPU_REG_OP_WRITE_32;
    regOp.regType = regType;
    regOp.regOffset = NV_PGRAPH_PRI_GPCS_MMU_DEBUG_CTRL;
    regOp.regValueLo = SETFIELD32(regOp.regValueLo, NV_PGRAPH_PRI_GPCS_MMU_DEBUG_CTRL_DEBUG, action == KDAPI_MMU_DEBUG_MODE_ENABLE ? 1 : 0);
    regOp.regAndNMaskLo = SETFIELD32(regOp.regAndNMaskLo, NV_PGRAPH_PRI_GPCS_MMU_DEBUG_CTRL_DEBUG, 1);
    
    res = kdapiExecRegOpsWDDM(ctx, NV_FALSE, &regOp, 1);
    HALO_TRACE(40, "%s MMU debug mode via PRI (%s)\n",
               res == CUDBG_SUCCESS ? "Set" : "Failed to set",
               regType == NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX ? "ctxsw" : "global");

    return res;
}

static CUDBGResult
kdapiSetMmuDebugModeWDDM(KdContext ctx, KdSetMmuDebugModeAction action)
{
    CUresult status;
    ESCAPE_DATA(DEBUG_SET_MMUDEBUG_MODE, escape);

    CUDBG_VERIFY(ctx && ctx->debugObject.wddm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    CUDBG_VERIFY(ctx->deviceHandle.wddm.hAdapter != 0, CUDBG_ERROR_INVALID_ARGS, "Adapter is not valid\n");

    escape.input.hDebugObject = ctx->debugObject.wddm.handle;
    switch (action) {
    case KDAPI_MMU_DEBUG_MODE_ENABLE:
        escape.input.action = NV83DE_CTRL_CMD_DEBUG_SET_MODE_MMU_DEBUG_ENABLE;
        break;
    case KDAPI_MMU_DEBUG_MODE_DISABLE:
        escape.input.action = NV83DE_CTRL_CMD_DEBUG_SET_MODE_MMU_DEBUG_DISABLE;
        break;
    case KDAPI_MMU_DEBUG_MODE_RELEASE_REQUESTS:
        escape.input.action = NV83DE_CTRL_CMD_DEBUG_RELEASE_MMU_DEBUG_REQUESTS;
        break;
    default:
        return CUDBG_ERROR_INVALID_ARGS;
    }

    status = ESCAPE(ctx->deviceHandle.wddm.hAdapter, escape);

    if (status != CUDA_SUCCESS || escape.Header.lResult != NVL_ESC_RESULT_SUCCESS) {
        HALO_ERROR("Failed to set MMU debug mode %d (status=%d, result=%d)\n", action, status, escape.Header.lResult);
        return CUDBG_ERROR_INTERNAL;
    }

    // WAR for bug 2627515 - temporarily change the MMU debug mode via PRI
    if (action == KDAPI_MMU_DEBUG_MODE_ENABLE || action == KDAPI_MMU_DEBUG_MODE_DISABLE) {
        CUDBGResult res;

        res = kdapiSetMmuDebugModeViaPRIWDDM(ctx, action, NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX);
        if (res != CUDBG_SUCCESS) {
            /* In the CUDA compatibility scenarios, the kernel driver can be old enough
            to have the MMU Debug Mode register be global and not ctxsw, so retry with global PRI.
            This also accounts for chips where MMU Debug Mode was never made ctxsw, like GK110C. */
            res = kdapiSetMmuDebugModeViaPRIWDDM(ctx, action, NV2080_CTRL_GPU_REG_OP_TYPE_GLOBAL);
        }

        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiSetSingleStepModeWDDM(KdContext ctx, NvBool enable)
{
    CUresult status;
    ESCAPE_DATA(DEBUG_SET_SINGLE_STEP_MODE, escape);

    CUDBG_VERIFY(ctx && ctx->debugObject.wddm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    CUDBG_VERIFY(ctx->deviceHandle.wddm.hAdapter != 0, CUDBG_ERROR_INVALID_ARGS, "Adapter is not valid\n");

    escape.input.hDebugObject = ctx->debugObject.wddm.handle;
    escape.input.singleStepMode = enable
        ? NV83DE_CTRL_DEBUG_SET_SINGLE_STEP_INTERRUPT_HANDLING_PAUSING
        : NV83DE_CTRL_DEBUG_SET_SINGLE_STEP_INTERRUPT_HANDLING_NONPAUSING;

    status = ESCAPE(ctx->deviceHandle.wddm.hAdapter, escape);

    if (status != CUDA_SUCCESS || escape.Header.lResult != NVL_ESC_RESULT_SUCCESS) {
        HALO_ERROR("Failed to %s single step mode (status=%d, result=%d)\n", enable ? "enable" : "disable", status, escape.Header.lResult);
        return CUDBG_ERROR_INTERNAL;
    }

    return CUDBG_SUCCESS;
}

ct_assert(sizeof(KdErrorState) == sizeof(NV83DE_SM_ERROR_STATE_REGISTERS));
static CUDBGResult
kdapiReadErrorStateWDDM(KdContext ctx, NvU32 vsm, KdErrorState *errorState)
{
    CUresult status;
    ESCAPE_DATA(DEBUG_READ_ERROR_STATES, escape);

    CUDBG_VERIFY(ctx && ctx->debugObject.wddm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    CUDBG_VERIFY(ctx->deviceHandle.wddm.hAdapter != 0, CUDBG_ERROR_INVALID_ARGS, "Adapter is not valid\n");
    CUDBG_VERIFY(errorState, CUDBG_ERROR_INVALID_ARGS, "Error state pointer not valid\n");

    escape.input.hDebugObject = ctx->debugObject.wddm.handle;
    escape.input.smId = vsm;

    status = ESCAPE(ctx->deviceHandle.wddm.hAdapter, escape);

    if (status != CUDA_SUCCESS || escape.Header.lResult != NVL_ESC_RESULT_SUCCESS) {
        HALO_ERROR("Failed to read the error state (status=%d, result=%d)\n", status, escape.Header.lResult);
        return CUDBG_ERROR_INTERNAL;
    }

    errorState->hwwGlobalEsr = escape.output.faultInfo.smErrorStateArray[vsm].hwwGlobalEsr;
    errorState->hwwWarpEsr = escape.output.faultInfo.smErrorStateArray[vsm].hwwWarpEsr;
    errorState->hwwWarpEsrPc = escape.output.faultInfo.smErrorStateArray[vsm].hwwWarpEsrPc;
    errorState->hwwGlobalEsrReportMask = escape.output.faultInfo.smErrorStateArray[vsm].hwwGlobalEsrReportMask;
    errorState->hwwWarpEsrReportMask = escape.output.faultInfo.smErrorStateArray[vsm].hwwWarpEsrReportMask;
    errorState->hwwEsrAddr = escape.output.faultInfo.smErrorStateArray[vsm].hwwEsrAddr;
    errorState->hwwWarpEsrPc64 = escape.output.faultInfo.smErrorStateArray[vsm].hwwWarpEsrPc64;

    return CUDBG_SUCCESS;
}

ct_assert(sizeof(KdErrorState) == sizeof(NV83DE_SM_ERROR_STATE_REGISTERS));
static CUDBGResult
kdapiReadErrorStatesWDDM(KdContext ctx, NvU32 numSMsToRead, NvU32 *mmuFaultInfo, NvBool *valid, KdErrorState *errorStateArray)
{
    // mmuFaultInfo and valid can be both NULL, in which case only error states are returned
    // likewise, numSMsToRead can be set to 0, in which case only the MMU fault info is returned

    CUresult status;
    ESCAPE_DATA(DEBUG_READ_ERROR_STATES, escape);

    CUDBG_VERIFY(ctx && ctx->debugObject.wddm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    CUDBG_VERIFY(ctx->deviceHandle.wddm.hAdapter != 0, CUDBG_ERROR_INVALID_ARGS, "Adapter is not valid\n");
    if (mmuFaultInfo) {
        CUDBG_VERIFY(valid, CUDBG_ERROR_INVALID_ARGS, "Valid flag pointer is not valid\n");
    }
    if (numSMsToRead > 0) {
        CUDBG_VERIFY(errorStateArray, CUDBG_ERROR_INVALID_ARGS, "Error state array is not valid\n");
    }

    escape.input.hDebugObject = ctx->debugObject.wddm.handle;
    escape.input.smId = NVL_ALL_SMS;

    status = ESCAPE(ctx->deviceHandle.wddm.hAdapter, escape);

    if (status != CUDA_SUCCESS || escape.Header.lResult != NVL_ESC_RESULT_SUCCESS) {
        HALO_ERROR("Failed to read the error states (status=%d, result=%d)\n", status, escape.Header.lResult);
        return CUDBG_ERROR_INTERNAL;
    }

    if (mmuFaultInfo) {
        *mmuFaultInfo = escape.output.faultInfo.mmuFaultInfo;
        // WAR for bug 2347829: until KMD supports the `valid` field assume it's true
        *valid = NV_TRUE;
    }
    if (numSMsToRead > 0) {
        memcpy(errorStateArray, escape.output.faultInfo.smErrorStateArray, sizeof(KdErrorState) * numSMsToRead);
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
kdapiGetVARangesWDDM(KdContext ctx, NvU64 startVA, NvU64 endVA, KdVARangeInfo *ranges, NvU32 length, NvU32 *numRanges);

static CUDBGResult
kdapiGetVARangesCountWDDM(KdContext ctx, NvU64 startVA, NvU64 endVA, NvU32 *numRanges)
{
    CUDBGResult result;
    NvU32 rangesCount;
    KdVARangeInfo *ranges;

    /* Approximate initial range count. The loop runs until all ranges fit or there's not enough memory to store them */
    for (rangesCount = 4096 / sizeof(*ranges); ; rangesCount *= 2) {
        ranges = (KdVARangeInfo *)malloc(rangesCount * sizeof(*ranges));
        if (!ranges) {
            HALO_ERROR("Too many ranges (>%d) to fit into memory\n", rangesCount / 2);
            return CUDBG_ERROR_OS_RESOURCES;
        }
        result = kdapiGetVARangesWDDM(ctx, startVA, endVA, ranges, rangesCount, numRanges);
        free(ranges);
        if (result != CUDBG_SUCCESS) {
            return result;
        }
        if (*numRanges < rangesCount) {
            break;
        }
    }

    return CUDBG_SUCCESS;
}

ct_assert(sizeof(KdVARangeInfo) == sizeof(NVL_VA_RANGE_INFO));
static CUDBGResult
kdapiGetVARangesWDDM(KdContext ctx, NvU64 startVA, NvU64 endVA, KdVARangeInfo *ranges, NvU32 length, NvU32 *numRanges)
{
    CUresult status;
    ESCAPE_DATA(DEBUG_GET_VA_RANGES, escape);

    CUDBG_VERIFY(ctx && ctx->debugObject.wddm.handle != 0, CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");
    CUDBG_VERIFY(ctx->deviceHandle.wddm.hAdapter != 0, CUDBG_ERROR_INVALID_ARGS, "Adapter is not valid\n");
    CUDBG_VERIFY(numRanges, CUDBG_ERROR_INVALID_ARGS, "Num ranges pointer is not valid\n");
    CUDBG_VERIFY(startVA < endVA, CUDBG_ERROR_INVALID_ARGS, "Requested VA range is not valid\n");

    if (!ranges || length == 0) {
        return kdapiGetVARangesCountWDDM(ctx, startVA, endVA, numRanges);
    }

    escape.input.hDebugObject = ctx->debugObject.wddm.handle;
    escape.input.startVA = startVA;
    escape.input.endVA = endVA;
    escape.input.bufferSize = length * sizeof(*ranges);
    escape.input.pBuffer = NV_PTR_TO_NvP64(ranges);

    status = ESCAPE(ctx->deviceHandle.wddm.hAdapter, escape);

    if (status != CUDA_SUCCESS || escape.Header.lResult != NVL_ESC_RESULT_SUCCESS) {
        HALO_ERROR("Failed to get VA ranges in range [0x%llx, 0x%llx] (status=%d, result=%d)\n",
            startVA, endVA, status, escape.Header.lResult);
        return CUDBG_ERROR_INTERNAL;
    }

    *numRanges = escape.output.numRanges;

    return CUDBG_SUCCESS;
}

struct KdApi_st
globalKdApiWDDM = {
    &kdapiAllocDebugObjectWDDM,
    &kdapiFreeDebugObjectWDDM,

    &kdapiGetApiVersionWDDM,
    &kdapiRegisterDebugEventWDDM,
    &kdapiUnregisterDebugEventWDDM,
    &kdapiClearDebugEventWDDM,
    &kdapiSuspendContextWDDM,
    &kdapiResumeContextWDDM,
    &kdapiExecRegOpsWDDM,
    &kdapiAccessMemoryWDDM,
    &kdapiSetMmuDebugModeWDDM,
    &kdapiSetSingleStepModeWDDM,
    &kdapiReadErrorStateWDDM,
    &kdapiReadErrorStatesWDDM,
    &kdapiGetVARangesWDDM,
};

#else // !cuiPlatformIncludesWddm()

struct KdApi_st
globalKdApiWDDM;

#endif // cuiPlatformIncludesWddm()
