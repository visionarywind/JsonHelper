/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "cuda_types.h"
#include "halo_drv.h"
#include "fermi_drv.h"
#include "fermi.h"

static CUDBGResult
haloDrvGetFuncMemBaseVA_fermi(CUctx *ctx, uint64_t *funcMemBaseVA);

static CUDBGResult
haloDrvThUsesDynamicRegs_fermi(CUctx *ctx, NvBool *thUsesDynamicRegs);

static CUDBGResult
haloDrvAdjustCodeAddress_fermi(uint64_t physAddr,
                               uint64_t *adjustedPhysAddr,
                               CUDBGAdjAddrAction adjAction);

static CUDBGResult
haloDrvIsStackPointerAssignment_fermi(uint64_t instruction[2],
                                      int32_t *res, uint32_t *assignmentIdx);

static CUDBGResult
haloDrvGetInstructionSize_fermi(uint64_t instruction, uint32_t *instSize);

static struct HaloDrvFuncPtrs haloDrvFuncPtrs_fermi = {
    haloDrvThUsesDynamicRegs_fermi,
    haloDrvGetFuncMemBaseVA_fermi,
    haloDrvAdjustCodeAddress_fermi,
    haloDrvIsStackPointerAssignment_fermi,
    haloDrvGetInstructionSize_fermi,
};

CUDBGResult
getHaloDrvFuncPtrs_fermi(struct HaloDrvFuncPtrs *ptrs)
{
    CUDBG_VERIFY(ptrs, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    memcpy(ptrs, &haloDrvFuncPtrs_fermi, sizeof(*ptrs));
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDrvThUsesDynamicRegs_fermi(CUctx *ctx, NvBool *thUsesDynamicRegs)
{
    *thUsesDynamicRegs = NV_FALSE;

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDrvGetFuncMemBaseVA_fermi(CUctx *ctx, uint64_t *funcMemBaseVA)
{
    CUmod *mod = NULL;
    CUfunc *func = NULL;

    *funcMemBaseVA = 0;

    mod = ctx->modules;

    if (mod != NULL) {
        func = mod->pFuncList;

        if (func != NULL)
            *funcMemBaseVA = ctx->device->hal.funcGetFuncMemBase(ctx, func);
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDrvAdjustCodeAddress_fermi(uint64_t physAddr,
                               uint64_t *adjustedPhysAddr,
                               CUDBGAdjAddrAction adjAction)
{
    switch (adjAction) {
    case CUDBG_ADJ_PREVIOUS_ADDRESS:
        *adjustedPhysAddr = physAddr - 8;
        break;
    case CUDBG_ADJ_NEXT_ADDRESS:
        *adjustedPhysAddr = physAddr + 8;
        break;
    case CUDBG_ADJ_CURRENT_ADDRESS:
        *adjustedPhysAddr = physAddr;
        break;
    default:
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDrvIsStackPointerAssignment_fermi(uint64_t instruction[2],
                                      int32_t *res, uint32_t *assignmentIdx)
{
    /* Fermi ABI:  R1 is the stack pointer, which is initialized
       with a value placed in constant bank 1 at offset 256.
       Typically, the MOV instruction is used to do this, but we'll
       also catch the case that LDC is used as well:

       MOV R1, c[0x1][0x100]
       LDC R1, c[0x1][0x100] */
    const uint64_t FERMI_MOV_R1_C_1_256 = 0x2800440400005de4ULL;
    const uint64_t FERMI_LDC_R1_C_1_256 = 0x1400040403f05c86ULL;

    CUDBG_VERIFY(res && assignmentIdx, CUDBG_ERROR_INVALID_ARGS, "Invalid args to isStackPointerAssignment\n");

    if (instruction[0] == FERMI_MOV_R1_C_1_256 ||
        instruction[0] == FERMI_LDC_R1_C_1_256) {
        *res = 1;
        *assignmentIdx = 0;
    }
    else
        *res = 0;

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDrvGetInstructionSize_fermi(uint64_t inst, uint32_t *instSize)
{
    /* If the 64-bit instruction packet read has a 4th bit set, this describes
       two 32bit instructions instead */
    *instSize = (inst & FERMI_64_BIT_INST_MASK) == FERMI_64_BIT_INST ? 8 : 4;
    return CUDBG_SUCCESS;
}
