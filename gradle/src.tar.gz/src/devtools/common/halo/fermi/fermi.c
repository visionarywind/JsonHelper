/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: fermi.c
 *
 *   Description:
 *       Internal API for the low-level GPU access needed to support
 *       the debugger on Fermi (GF100/10x/11x).
 *
 ******************************************************************************/

#include "cudadebugger.h"
#include <cuda_internal.h>
#include "ctrl/ctrl2080.h"
#include "fermi/gf100/dev_top.h"
#include "fermi/gf100/dev_pri_ringmaster.h"
#include "fermi/gf100/dev_graphics_nobundle.h"
#include "fermi/gf100/dev_fifo.h"
#include "halo_internal.h"
#include "fermi.h"
#include "cudbgapi.h"
#include "fermi_sass.h"
#include "fermi_mcinterop.h"
#include "cuda_syscallid.h"
#include "rm_call.h"
#include "rm_device.h"
#include "common_device.h"

#include "cudamemcheck.h"
#include "memcheck_halo.h"

#include "halo_state.h"

#ifdef CUDBG_ENABLE_IFB
#include "class/cl9068.h" // FERMI IFB
#endif

#include "cuda_warpbitmask.h"

/* Define Fermi CRS entry types */
typedef enum {
    CRS_TYPE_ILL          =  0, /* ILLEGAL!  Should never happen! */
    CRS_TYPE_SAM          =  1,
    CRS_TYPE_CALL_NI      =  2, /* Don't increment CALL count */
    CRS_TYPE_CALL         =  3, /* Increment CALL count */
    CRS_TYPE_PBRK         =  4,
    CRS_TYPE_PCONT        =  5,
    CRS_TYPE_DIV          =  6, /* Divergence */
    CRS_TYPE_DIV_IDX      =  7, /* BRX Divergence */
    CRS_TYPE_SSY          =  8, /* Synchronization */
    CRS_TYPE_PLONGJMP     =  9,
    CRS_TYPE_TRAP         = 10, /* TRAP instruction */
    CRS_TYPE_DIS_RET      = 11,
    CRS_TYPE_DIS_CONT     = 12,
    CRS_TYPE_DIS_BRK      = 13,
    CRS_TYPE_DIS_SYNC     = 14,
    CRS_TYPE_DIS_LONGJUMP = 15,
    CRS_TYPE_DIS_EXIT     = 16,
    CRS_TYPE_NOP          = 17,
} CRSId_t;

static CUDBGResult
fermi_isAnyExceptionSet(CudbgDevice dev, bool *anyExceptionSet)
{
    uint32_t vsm;
    uint32_t tpcException;
    uint32_t regOffset = 0;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(anyExceptionSet, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments to fermi_isAnyExceptionSet.\n");

    *anyExceptionSet = false;

    for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
        res = dev->halo.getPRIOffset(dev, HALO_PRI_TPCCS_TPC_EXCEPTION, vsm,
                                     &regOffset);
        if (res != CUDBG_SUCCESS)
            return res;

        res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GLOBAL,
                                         (char *)(uintptr_t)regOffset,
                                         &tpcException);
        if (res != CUDBG_SUCCESS)
            return res;

        if (tpcException) {
            *anyExceptionSet = true;
            break;
        }
    }

    return res;
}

static CUDBGResult
fermi_getBrokenWarps(struct Halo_st *halo, HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm,
                     const CUwarpBitmask *validMask, const CUwarpBitmask *bpTrapMask, CUwarpBitmask *brokenwarps)
{
    CUDBG_VERIFY(halo && scratchpadAccessor && validMask && bpTrapMask && brokenwarps, CUDBG_ERROR_INVALID_ARGS,
        "Invalid arguments to getBrokenWarps.\n");

    /*
     * On Fermi, bpmask stores a 1 for each warp that is _paused_.
     * So, unlike Tesla, this is not the mask we use to update
     * the brokenwarps mask.  Instead, we use the bptrapmask, which
     * stores a 1 for warps that have hit a breakpoint.  It is also
     * always reliable, so we do not need to check singleStepping.
     */
    warpBitmaskAssign(brokenwarps, bpTrapMask);

    return CUDBG_SUCCESS;
}

CUDBGResult
fermi_readSMESRInfo(CudbgDevice dev, uint32_t vsm, CudbgSMState_t *state,
                    HaloDebugObjMode_t debugObjMode)
{
    CUDBGResult res = CUDBG_SUCCESS;
    bool useDebugObj = false;
    uint32_t regOffset = 0;


    if (debugObjMode == HALO_DEBUG_OBJ_MODE_FORCE ||
        (debugObjMode == HALO_DEBUG_OBJ_MODE_DEFAULT &&
         dev->dmal->debugObjectCanReadESR())) {
        /* Read this using the debug object */
        useDebugObj = true;
    }

    if ((useDebugObj && dev->activeContext)) {
        res = dev->dmal->debugObjectReadSMESRInfo(dev,
                                                  dev->activeContext->debugObj,
                                                  vsm,
                                                  &state->esrState);
        if (res != CUDBG_SUCCESS)
            return res;

    }
    else {
        res = dev->halo.getPRIOffset(dev, HALO_PRI_SM_HWW_WARP_ESR, vsm,
                                     &regOffset);
        if (res != CUDBG_SUCCESS)
            return res;

        res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                         (char *)(uintptr_t)regOffset,
                                         (uint32_t*) &state->esrState.hwwwarpesr);
        if (res != CUDBG_SUCCESS)
            return res;

        res = dev->halo.getPRIOffset(dev, HALO_PRI_SM_HWW_GLOBAL_ESR, vsm,
                                     &regOffset);
        if (res != CUDBG_SUCCESS)
            return res;

        res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                         (char *)(uintptr_t)regOffset,
                                         (uint32_t*) &state->esrState.hwwglobalesr);
        if (res != CUDBG_SUCCESS)
            return res;
    }

    return res;
}

CUDBGResult
fermi_clearSMESRInfo(CudbgDevice dev, uint32_t vsm, CudbgSMState_t *state,
                     HaloDebugObjMode_t debugObjMode)
{
    CUDBGResult res = CUDBG_SUCCESS;
    bool useDebugObj = false;
    uint32_t regOffset = 0;
    uint32_t warpEsrRegOffset, globalEsrRegOffset = 0;
    uint32_t hwwwarpesr, hwwglobalesr;

    if (debugObjMode == HALO_DEBUG_OBJ_MODE_FORCE ||
        (debugObjMode == HALO_DEBUG_OBJ_MODE_DEFAULT &&
         dev->dmal->debugObjectCanClearESR())) {
        /* Clear this using the debug object */
        useDebugObj = true;
    }

    if (useDebugObj && dev->activeContext) {
        res = dev->dmal->debugObjectClearSMESRInfo(dev,
                                                   dev->activeContext->debugObj,
                                                   vsm,
                                                   &state->esrState);
        if (res != CUDBG_SUCCESS)
            return res;
    }
    else {
        res = dev->halo.getPRIOffset(dev, HALO_PRI_SM_HWW_WARP_ESR, vsm,
                                     &warpEsrRegOffset);
        if (res != CUDBG_SUCCESS)
            return res;

        /* Do a read-write to clear ESR */
        res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                         (char *)(uintptr_t)warpEsrRegOffset,
                                         (uint32_t*)&hwwwarpesr);
        if (res != CUDBG_SUCCESS)
            return res;

        res = dev->halo.getPRIOffset(dev, HALO_PRI_SM_HWW_GLOBAL_ESR, vsm,
                                     &globalEsrRegOffset);
        if (res != CUDBG_SUCCESS)
            return res;

        res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                         (char *)(uintptr_t)globalEsrRegOffset,
                                         (uint32_t*)&hwwglobalesr);
        if (res != CUDBG_SUCCESS)
            return res;

        /* Clear the hww warp esr */
        res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                         (char *)(uintptr_t)warpEsrRegOffset,
                                          (uint32_t*)&hwwwarpesr);
        if (res != CUDBG_SUCCESS)
            return res;

        /* Clear the hww global esr */
        res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                         (char *)(uintptr_t)globalEsrRegOffset,
                                          (uint32_t*)&hwwglobalesr);
        if (res != CUDBG_SUCCESS)
            return res;
    }

    return res;
}

static CUDBGResult
fermi_setKnownEvent(CudbgDevice dev, CudbgSMState_t *state)
{
    CUDBG_VERIFY(state, CUDBG_ERROR_INTERNAL, "Invalid args\n");

    /* On Fermi, include warps that executed a breakpoint,
       or that hit a global/warp error. */
    state->knownEvent = warpBitmaskAny(&state->brokenwarps) ||
                        state->esrState.hwwwarpesr ||
                        state->esrState.hwwglobalesr;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_readSMWarpMasks(CudbgDevice dev, uint32_t vsm, CudbgSMState_t *state)
{
    CUDBGResult res = CUDBG_SUCCESS;

    res = dev->halo.readWarpMaskPRI(dev, vsm, HALO_REG_OP_TYPE_GLOBAL,
                                    HALO_MASK_PRI_BPT_PAUSE, &state->bpmask);
    if (res != CUDBG_SUCCESS)
        return res;

    warpBitmaskAssign(&state->preempt_bpmask, &state->bpmask);

    res = dev->halo.readWarpMaskPRI(dev, vsm, HALO_REG_OP_TYPE_GLOBAL,
                                    HALO_MASK_PRI_BPT_TRAP, &state->bptrapmask);
    if (res != CUDBG_SUCCESS)
        return res;

    res = dev->halo.readWarpMaskPRI(dev, vsm, HALO_REG_OP_TYPE_GLOBAL,
                                    HALO_MASK_PRI_WARP_VALID, &state->tidValid);
    if (res != CUDBG_SUCCESS)
        return res;

    return res;
}

static CUDBGResult
fermi_stub_readSMWarpMasksFromScratchpad(struct Halo_st *halo, HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm,
                                         CUwarpBitmask *validMask, CUwarpBitmask *bpMask, CUwarpBitmask *bpTrapMask)
{
    return CUDBG_ERROR_INVALID_DEVICE;
}

/* Similar to what is done for GT200, we overwrite any low-level
 * functions that are specific to Fermi in this module, where we
 * can locate proper PRI regs from gf100_nv_ref_nobundle.h. */
static CUDBGResult
fermi_readSMState(CudbgDevice dev, uint32_t vsm, CudbgSMState_t *state)
{
    CUDBGResult res = CUDBG_SUCCESS;

    /* Clear the masks */
    warpBitmaskClear(&state->bpmask);
    warpBitmaskClear(&state->bptrapmask);
    warpBitmaskClear(&state->tidValid);

    /* Read the warp masks */
    res = dev->halo.readSMWarpMasks(dev, vsm, state);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Read the SM ESR information */
    res = dev->halo.readSMESRInfo(dev, vsm, state, dev->debugObjMode);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Mainly to pick up Maxwell's ESR PC */
    res = dev->halo.readSMWarpESRInfo(dev, vsm, state);
    if (res != CUDBG_SUCCESS)
        return res;

    if (dev->activeContext && haloStateContextIsActive(dev->activeContext)) {
        res = dev->halo.getBrokenWarps(&dev->halo, dev->activeContext->scratchpadAccessor, vsm,
            &state->tidValid, &state->bptrapmask, &state->brokenwarps);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to getBrokenWarps failed (%d)\n", res);
            return res;
        }
    }
    else {
        warpBitmaskClear(&state->brokenwarps);
    }

    /* WAR Bug 779607. Remember if we are seeing a known and understood event
     * (trap, exception...) at this very moment, before we process those masks */
    res = dev->halo.setKnownEvent(dev, state);
    if (res != CUDBG_SUCCESS)
        return res;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_writeBreakpointMask(CudbgDevice dev, uint32_t vsm, CUwarpBitmask *mask)
{

    CUDBGResult res = CUDBG_SUCCESS;

    /* Snoop writes to the pause mask.  As this is the mask used
       to indicate which warps will be resumed, it by definition
       means this is also the mask for warps that have already
       been serviced by the debugger. */
    warpBitmaskAssign(&dev->pauseServicedMask[vsm], mask);

    /*
     * Sets the bpmask and bptrapmask for the first 64
     * warps.  Only 48 should ever be valid on gf100 -
     * this may increase with later chips.
     */

    /* Write the bpmask (pause mask) */
    res = dev->halo.writeWarpMaskPRI(dev, vsm, HALO_REG_OP_TYPE_GLOBAL,
                                     HALO_MASK_PRI_BPT_PAUSE, mask);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to write BPT_PAUSE_MASK_0\n");

    return res;
}

/* Clear exceptions for a given vsm, or all vsms.
   If vsm == -1, perform this operation on all vsms.
   Otherwise, perform this operation on the given vsm.

   Note:  the above applies only to SM interrupts, and
          not to FIFO control -- that is always global. */
static CUDBGResult
fermi_clearExceptions(CudbgDevice dev, uint32_t vsm)
{
    volatile char *bar0addr;
    uint32_t regVal;
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t regOffset = 0;

    /* WAR Bug 723023:
     *
     * Now that the CUDA driver wants to run with debug mode on in order
     * to support real system calls, there is a race that was discovered
     * between releasing a semaphore and reporting a user level event
     * for an exception occurring.  If the semaphore release wins the
     * race, then completion is reported, and in the worst case the
     * driver is torn down and nobody is left to receive the exception
     * being reported by RM.  Since TPCCS_EXCEPTION is left high (see the
     * code that immediately follows this WAR), it causes bad behavior in
     * subsequent applications.  To fix that race, RM keeps FE "frozen"
     * when it initially receives the exception notification from
     * hardware, meaning that it prevents any more grfifo methods from
     * being processed in addition to preventing semaphore acquires and
     * releases.  Since RM is keeping FE frozen until a user client
     * receives the 'more important' exception, we now need to enable
     * those bits again.
     *
     * Note this is not a problem for the debugger directly (we are
     * always around -- even if the driver gets a semaphore release first,
     * we will receive that as an event, and then examine state anyway).
     * However, since the change is being made universally, we need to
     * adapt to it. */
    bar0addr = dev->bar0 + NV_PGRAPH_GRFIFO_CONTROL;
    res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GLOBAL, bar0addr, &regVal);
    if (res != CUDBG_SUCCESS)
        return res;

    regVal = SETFIELD32(regVal, NV_PGRAPH_GRFIFO_CONTROL_ACCESS, 1);
    regVal = SETFIELD32(regVal, NV_PGRAPH_GRFIFO_CONTROL_SEMAPHORE_ACCESS, 1);
    res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GLOBAL, bar0addr, &regVal);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Now the special sauce:  there is no way to officially query that the
     * gpu is running after setting the run trigger.  This is due to the fact
     * that the bpt pause mask will not instantly read back as a zero after
     * setting it low.  So, in the event of multiple asynchronous interrupts,
     * we may process the first and resume the chip, then when the second
     * interrupt comes in, we may falsely think the chip is paused even though
     * we have resumed it.
     *
     * To handle this, RM does NOT clear the TPCCS interrupt pending bit when
     * debug mode is on.  This prevents multiple interrupts from occurring until
     * we say so.  Therefore, the debugger needs to expliclity clear this bit
     * upon any resume. */
    if ((int32_t)vsm == -1) { /* re-enable for all vsms */
        /* Uniformity assumption for reading */
        HALO_TRACE_FUNCTION(10, "re-enabling exceptions for all vsms (vsm = %d)\n", vsm);
    }
    else { /* re-enable for one vsm */
        CUDBG_VERIFY((vsm < dev->halo.deviceInfo.numSMs), CUDBG_ERROR_INVALID_SM, "Invalid SM.\n");

        HALO_TRACE_FUNCTION(10, "re-enabling exceptions for vsm %d\n", vsm);

    }

    res = dev->halo.getPRIOffset(dev, HALO_PRI_TPCCS_TPC_EXCEPTION, vsm,
                                 &regOffset);
    if (res != CUDBG_SUCCESS)
        return res;

    res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GLOBAL,
                                     (char *)(uintptr_t)regOffset, &regVal);
    if (res != CUDBG_SUCCESS)
        return res;

    regVal = SETFIELD32(regVal, NV_PGRAPH_PRI_GPC0_TPC0_TPCCS_TPC_EXCEPTION_SM, 1);
    res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GLOBAL,
                                      (char *)(uintptr_t)regOffset, &regVal);
    if (res != CUDBG_SUCCESS)
        return res;

    return res;
}

/* Note, this doesn't touch the device suspended property, so use with care. */
CUDBGResult
fermi_suspendTPC(CudbgDevice dev, uint32_t vsm)
{
    uint32_t regVal;
    uint32_t regOffset = 0;
    CUDBGResult res = CUDBG_SUCCESS;

    res = dev->halo.getPRIOffset(dev, HALO_PRI_SM_DBGR_CONTROL0, vsm, &regOffset);
    if (res != CUDBG_SUCCESS)
        return res;

    res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                     (char *)(uintptr_t)regOffset, &regVal);
    if (res != CUDBG_SUCCESS)
        return res;

    /* The following requires some clarification.  Despite the fact
     * that both RUN_TRIGGER and STOP_TRIGGER have the word "TRIGGER"
     * in their names, only one is actually a trigger, and that is
     * the STOP_TRIGGER.  Only writing a 1 to the RUN_TRIGGER is not
     * sufficient to resume the gpu - the stop trigger must explicitly
     * be set to 0 as well. */

    /* SUSPENDING:  It is only necessary to set the stop trigger to 1 */
    regVal = SETFIELD32(regVal,
                        NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_CONTROL0_STOP_TRIGGER, 1);

    /* Do the final write to CONTROL0 */
    return dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                       (char *)(uintptr_t)regOffset, &regVal);
}

/* Note, this doesn't touch the device suspended property, so use with care. */
static CUDBGResult
fermi_resumeTPC(CudbgDevice dev, uint32_t vsm)
{
    uint32_t regVal;
    uint32_t regOffset = 0;
    CUDBGResult res = CUDBG_SUCCESS;

    if (haloStateContextIsActive(dev->activeContext))
        dev->halo.contextCommonDataCacheOp(dev->activeContext, HALO_MEM_SEG_CACHE_INVALIDATE);

    res = dev->halo.getPRIOffset(dev, HALO_PRI_SM_DBGR_CONTROL0, vsm, &regOffset);
    if (res != CUDBG_SUCCESS)
        return res;

    res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                     (char *)(uintptr_t)regOffset, &regVal);
    if (res != CUDBG_SUCCESS)
        return res;

    /* The following requires some clarification.  Despite the fact
     * that both RUN_TRIGGER and STOP_TRIGGER have the word "TRIGGER"
     * in their names, only one is actually a trigger, and that is
     * the STOP_TRIGGER.  Only writing a 1 to the RUN_TRIGGER is not
     * sufficient to resume the gpu - the stop trigger must explicitly
     * be set to 0 as well. */

    /* RESUMING:  Advice from the arch group:  Set the stop trigger
     * first as a separate operation to ensure that the trigger has
     * taken effect before setting the "run trigger." */

    /* Set the stop trigger to 0 */
    regVal = SETFIELD32(regVal,
                        NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_CONTROL0_STOP_TRIGGER, 0);
    res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                      (char *)(uintptr_t)regOffset, &regVal);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Now, set the run trigger to 1 */
    regVal = SETFIELD32(regVal,
                        NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_CONTROL0_RUN_TRIGGER, 1);

    /* Do the final write to CONTROL0 */
    return dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                       (char *)(uintptr_t)regOffset, &regVal);
}

/* Invalidate I-caches */
static CUDBGResult
fermi_invalidateICache(CudbgDevice dev)
{
    uint32_t regVal;
    CUDBGResult res = CUDBG_SUCCESS;

    /* Invalidate the GCC on all GPCs */
    /* XXX Uniformity assumption! */
    res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GLOBAL,
                                     dev->bar0 + NV_PGRAPH_PRI_GPC0_GCC_DBG, &regVal);
    if (res != CUDBG_SUCCESS)
        return res;

    /* BROADCAST write */
    regVal = SETFIELD32(regVal, NV_PGRAPH_PRI_GPCS_GCC_DBG_INVALIDATE, 1);
    res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GLOBAL,
                                      dev->bar0 + NV_PGRAPH_PRI_GPCS_GCC_DBG, &regVal);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Invalidate the SCC */
    /* XXX Uniformity assumption! */
    res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GLOBAL,
                                     dev->bar0 + NV_PGRAPH_PRI_GPC0_TPC0_SM_CACHE_CONTROL,
                                     &regVal);
    if (res != CUDBG_SUCCESS)
        return res;

    regVal = SETFIELD32(regVal, NV_PGRAPH_PRI_GPCS_TPCS_SM_CACHE_CONTROL_INVALIDATE_ICACHE, 1);

    /* BROADCAST write */
    res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GLOBAL,
                                       dev->bar0 + NV_PGRAPH_PRI_GPCS_TPCS_SM_CACHE_CONTROL,
                                       &regVal);
    if (res != CUDBG_SUCCESS)
        return res;

    /* ICache uses L2 Cache which isn't snooped on ARM.  Flush it. */
    return dev->dmal->flushGpuWrites(dev);
}

/* Collect data from the trap handler scratchpad */
static CUDBGResult
fermi_collectScratchpad(CudbgDevice dev, uint32_t vsm)
{
    /* Scratchpad data for each warp */
    uint32_t wp;
    CUDBGResult res = CUDBG_SUCCESS;
    Context context = dev->activeContext;
    CudbgWarp_t *warp;
    HaloLmemConfig_t *warpLmem;
    uint32_t lmemLoSizePrThread;

    /* If no active context, there is nothing to do. */
    if (!context) {
#ifndef RELEASE
        for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
            warp = &dev->smState[vsm].warp[wp];
            memset(&warp->lmemConfig, 0, sizeof warp->lmemConfig);;
            warp->gridId64 = ~0ULL;
        }
#endif
        return CUDBG_SUCCESS;
    }

    /* Collect each warp's scratchpad data */
    for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
        /* Skip invalid warps (they can have stale entries in their scratchpad) */
        if (!(warpBitmaskGetBits(&dev->smState[vsm].state.tidValid, wp, 1)))
            continue;

        warp = &dev->smState[vsm].warp[wp];
        warpLmem = &warp->lmemConfig;

        /* Keep LMemHiOff around, we'll need it when checking for user
           stack overflows (ABI compilations) */
        res = dev->halo.scratchpad.read_lmemHiOff(context->scratchpadAccessor, vsm, wp, &warpLmem->lmemHiOff);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get lmem hi offset\n");

        /* Get the lmem window size (should always be 16MB) */
        res = dev->halo.scratchpad.read_lmemWindowSize(context->scratchpadAccessor, vsm, wp, &warpLmem->windowSize);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get lmem window size\n");

        /* Get the lmem lo and high sizes (per warp)

           From S2R HW doc:
             [SR54] Local memory low allocated size in bytes per thread, multiple of 16B
             [SR55] Local memory high allocated offset in bytes per thread, multiple of 16B
             LMemHiOff = LWINSZ - LMemHiSz;
             LMemHiSz is allocated size in bytes per thread.
           So:
             LmemLoSizePrWarp = LmemLoSz * warpSize;
             LmemHiSzPrWarp = (LWINSZ - LMemHiOff) * warpSize; */
        res = dev->halo.scratchpad.read_lmemLoSizePrThread(context->scratchpadAccessor, vsm, wp, &lmemLoSizePrThread);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get lmem lo size per warp\n");
        warpLmem->loSize = lmemLoSizePrThread * dev->halo.deviceInfo.numLanesPrWarp;
        warpLmem->hiSize = (warpLmem->windowSize - warpLmem->lmemHiOff) *
                           dev->halo.deviceInfo.numLanesPrWarp;

        /* Get the CRS size (per warp).  This is pushed down as CTAParam
           in the CUDA Driver. */
        res = dev->halo.scratchpad.read_CRSSize(context->scratchpadAccessor, vsm, wp, &warpLmem->CRSSize);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get crs size\n");

        /* Save off this warp's lmem base into the dev structure
           (Fermi always uses the default) */
        dev->smState[vsm].warp[wp].lmemSegType = HALO_MEM_SEG_LOCAL_DEFAULT;
        res = haloMemoryMapGetSegmentByDevVaddr(context->memMap,
                                                context->defaultLmemDevVA,
                                                &dev->smState[vsm].warp[wp].lmemSeg);
        CUDBG_VERIFY(res == CUDBG_SUCCESS,
                     res,
                     "Error trying to get lmemSeg at VA: 0x%" PRIx64 "\n",
                     context->defaultLmemDevVA);
        CUDBG_VERIFY(dev->smState[vsm].warp[wp].lmemSeg,
                     CUDBG_ERROR_INVALID_MEMORY_SEGMENT,
                     "Error trying to get lmemSeg at VA: 0x%" PRIx64 "\n",
                     context->defaultLmemDevVA);

        /* Use the default lmem's VA as the base VA for the warp */
        dev->smState[vsm].warp[wp].lmemBase    = context->defaultLmemDevVA;

        /* Store grid ID directly into device state */
        res = dev->halo.scratchpad.read_gridId(context->scratchpadAccessor, vsm, wp, &dev->smState[vsm].warp[wp].gridId64);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get grid id\n");

        /* Param constbank backing store dptr */
        res = dev->halo.scratchpad.read_paramConstDptr(context->scratchpadAccessor, vsm, wp, &dev->smState[vsm].warp[wp].paramConstDptr);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get param const dptr\n");

        HALO_TRACE_FUNCTION(30, "vsm%d/wp%d -> LWINSZ: 0x%x, "
                            "LMemLoSizePrWarp: 0x%x, "
                            "LMemHiSizePrWarp: 0x%x, "
                            "LMemCRSSizePrWarp: 0x%x, "
                            "GRIDParam: %#" PRIx64 ", "
                            "LWINSZ:  0x%x, "
                            "LMemLoSizePrThread: 0x%x, "
                            "LMemHiOff:  0x%x\n",
                            vsm, wp, warpLmem->windowSize,
                            warpLmem->loSize, warpLmem->hiSize,
                            warpLmem->CRSSize,
                            dev->smState[vsm].warp[wp].gridId64, warpLmem->windowSize,
                            lmemLoSizePrThread, warpLmem->lmemHiOff);
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_readLmemConfig(CudbgDevice dev, uint32_t vsm)
{
    uint32_t regVal;
    uint32_t regOffset = 0;
    CUDBGResult res = CUDBG_SUCCESS;

    res = dev->halo.getPRIOffset(dev, HALO_PRI_PD_LMEM_SIZE_PER_SM, -1,
                                 &regOffset);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Local memory size per SM is read from a PRI.  This information is
       only valid after a BEGIN_GRID method has been pushed down. */
    res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GLOBAL,
                                     (char *)(uintptr_t)regOffset, &regVal);
    if (res != CUDBG_SUCCESS)
        return res;

    dev->lmemSizePrSM = regVal << 8;

    /* Read out each warp's scratchpad data (which includes lmem sizes) */
    res = fermi_collectScratchpad(dev, vsm);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to collectScratchpad failed in fermi_readLmemConfig.\n");
        return res;
    }

    return CUDBG_SUCCESS;
}

/* Fermi LMEM and CRS functions below */

static inline CUDBGResult
fermi_forceScratchpadLmemBase(CudbgDevice dev, bool *useScratchpad)
{
    *useScratchpad = false;
    return CUDBG_SUCCESS;
}

static inline uint32_t
commonLocalAndCRS(CudbgDevice dev, uint32_t vsm, uint32_t tid, uint32_t warp_addr)
{
    return (((warp_addr & 0x3fffe00) >> 9) * dev->halo.deviceInfo.numWarpsPrSM + tid) * FERMI_LCL_CHUNK_SIZE +
           (dev->lmemSizePrSM * vsm) + (warp_addr & 0x1ff);
}

static CUDBGResult
fermi_getLmemInternalOffset(CudbgDevice dev, uint32_t address,
                            uint32_t vsm, uint32_t tid, uint32_t lane, uint32_t *offset)
{
    uint32_t warp_addr;
    HaloLmemConfig_t *warpLmem = &dev->smState[vsm].warp[tid].lmemConfig;

    /* Detect an access to local high */
    if (address > warpLmem->windowSize / 2)
        address -= warpLmem->windowSize;

    warp_addr = ((address & 0xfffffffc) << 5) + (lane << 2) + (address & 0x3);
    warp_addr += warpLmem->hiSize + warpLmem->CRSSize;

    *offset = commonLocalAndCRS(dev, vsm, tid, warp_addr);
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_getCRSInternalOffset(CudbgDevice dev, uint32_t vsm, uint32_t tid, uint32_t warp_addr, uint32_t *offset)
{
    *offset = commonLocalAndCRS(dev, vsm, tid, warp_addr);
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_CRSEntrySize(CudbgDevice dev, uint32_t *size)
{
    *size = FERMI_CRS_ENTRY_SIZE;
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_CRSEntryPaddingSize(CudbgDevice dev, uint32_t *size)
{
    /* No padding of CRS entries on Fermi */
    *size = 0;
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_maxCRSEntriesPerWarp(CudbgDevice dev, uint32_t vsm, uint32_t tid, uint32_t *numEntries)
{
    *numEntries = FERMI_MAX_CRS_ENTRIES_PER_WARP(vsm, tid);
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_getWarpCRSUsage(CudbgDevice dev, uint32_t vsm, uint32_t tid,
                      uint32_t *warpCRSNumEntries, uint32_t *warpCRSSize, bool *usingCRSPtr)
{
    CUDBGResult res = CUDBG_SUCCESS;
    HaloLmemConfig_t *warpLmem = &dev->smState[vsm].warp[tid].lmemConfig;
    uint32_t numEntries = 0;

    CUDBG_VERIFY(warpCRSNumEntries && warpCRSSize && usingCRSPtr,
                 CUDBG_ERROR_INVALID_ARGS, "Invalid args in getWarpCRSUsage\n");

    res = dev->halo.maxCRSEntriesPerWarp(dev, vsm, tid, &numEntries);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to maxCRSEntriesPerWarp failed in collectWarpCRS.\n");
        return res;
    }

    /* Fermi:  Note that we cannot obtain the total amount of CRS to map by
       multiplying numEntries by the size of each entry, as Fermi CRS entries
       do not completely fill a cache line (there is wasted space).  Instead,
       we need to use the total CRS size from the lmemConfig. */
    *warpCRSNumEntries = numEntries;
    *warpCRSSize = warpLmem->CRSSize;
    *usingCRSPtr = false; /* Fermi does not have this capability */
    return res;
}

static CUDBGResult
fermi_verifyCRSxsum(HaloCRS_t *warpCRS, uint32_t idx)
{
    uint32_t i;
    uint8_t xsum = 0;

    /* Collect xsum bits from the PC, active mask, and type fields */
    for (i = 0; i < sizeof warpCRS->pc[idx]; i++)
        xsum += (uint8_t) (warpCRS->pc[idx] >> (i * 8));

    for (i = 0; i < sizeof warpCRS->mask[idx]; i++)
        xsum += (uint8_t) (warpCRS->mask[idx] >> (i * 8));

    xsum += (uint8_t) warpCRS->type[idx];

    CUDBG_VERIFY((255U - xsum == warpCRS->xsum[idx]),
                 CUDBG_ERROR_INTERNAL,
                 "CRS checksum error: %08x != %08x\n", 255U - xsum, warpCRS->xsum[idx]);

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_dumpCRS(CudbgDevice dev, uint32_t vsm, uint32_t tid, unsigned char *flatCRS, uint32_t depth)
{
    unsigned char *flatCRSLimit;
    uint32_t size;
    CUDBGResult res = CUDBG_SUCCESS;

    res = dev->halo.CRSEntrySize(dev, &size);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to CRSEntrySize failed in dumpCRS.\n");
        return res;
    }

    for (flatCRSLimit = flatCRS + depth * size; flatCRS < flatCRSLimit;
         flatCRS += size)
        HALO_TRACE(0, "\t(GF100: CRS DUMP - vsm%d/tid%d): 0x%04x%016" PRIx64 "\n",
                   vsm, tid, *(uint16_t *)((char *)(flatCRS+8)), *(uint64_t *)flatCRS);

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_updateCRS(CudbgDevice dev, uint32_t vsm, uint32_t tid,
                unsigned char *flatCRS, uint32_t trapIdx)
{
    int i;
    unsigned char *CRSPtr;
    unsigned char *CRSAddr;   // Effective address (within local memory allocation)
    unsigned char *CRSBaseVA; // Effective (base) address within local memory allocation
    uint32_t CRSOff = 0;      // Warp offset into CRS (not yet a warp address)
    uint64_t nb;
    uint64_t warpCRSLow, warpCRSHigh;
    CRSMagicCast_t flatCRSPtr;
    HaloLmemConfig_t *warpLmem = &dev->smState[vsm].warp[tid].lmemConfig;
    Context context = dev->activeContext;
    uint32_t offset_32;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY((context && context->memMapActive),
                 CUDBG_ERROR_INVALID_CONTEXT,
                 "No context or context not active in fermi_updateCRS.\n");

    CUDBG_VERIFY(dev->smState[vsm].warp[tid].lmemSeg,
                 CUDBG_ERROR_INVALID_MEMORY_SEGMENT,
                 "Lmemseg not set for warp\n");

    /* We're writing back to CRS memory - make sure it's mapped in. */
    res = dev->halo.getCRSInternalOffset(dev, vsm, tid, warpLmem->CRSSize, &offset_32);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to getCRSInternalOffset failed in fermi_updateCRS.\n");
        return res;
    }
    warpCRSHigh = offset_32;

    res = dev->halo.getCRSInternalOffset(dev, vsm, tid, 0, &offset_32);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to getCRSInternalOffset failed in fermi_updateCRS.\n");
        return res;
    }
    warpCRSLow = offset_32;

    /* Ensure mapMemory+memcpy is atomic */
    cuosEnterCriticalSection(&haloGlobals.mapMemory_cs);

    res = dev->haloClient->mapMemory(context,
                                     dev->smState[vsm].warp[tid].lmemSeg->devvaddr + warpCRSLow,
                                     warpCRSHigh - warpCRSLow,
                                     (char **)&CRSBaseVA);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Memory mapping failed in fermi_updateCRS.\n");
        goto done;
    }

    /* Update device CRS for this warp - only write back CRS data
       up to and including the cache line containing the trap token. */
    flatCRSPtr.p = flatCRS;
    CRSPtr = CRSAddr = CRSBaseVA;
    // Cycle each cache line, 128B at a time
    for (nb = 0; nb < warpLmem->CRSSize; nb += FERMI_CACHE_LINE_SIZE) {
        for (i = 0; i < 3; i++) { // Write 4 entries at a time (1/3 of the line)
            haloMemcpy(CRSPtr + 32*i,     flatCRSPtr.chunk32++, sizeof(chunk32_t));
            haloMemcpy(CRSPtr + 96 + i*8, flatCRSPtr.chunk8++,  sizeof(chunk8_t));
        }
        CRSPtr += FERMI_CACHE_LINE_SIZE; // The above loop just copied a cache line

        /* CRS is allocated in 512-byte chunks for each warp, so we need to
           recompute the effective address on each 512-byte boundary */
        if (CRSPtr == CRSAddr + FERMI_LCL_CHUNK_SIZE) {
            CRSOff += FERMI_LCL_CHUNK_SIZE;
            res = dev->halo.getCRSInternalOffset(dev, vsm, tid, CRSOff, &offset_32);
            if (res != CUDBG_SUCCESS) {
                HALO_ERROR("Call to getCRSInternalOffset failed in updateCRS.\n");
                goto done;
            }
            CRSPtr = CRSAddr = CRSBaseVA + offset_32 - warpCRSLow;
        }
    }

    /* Since we're directly mapping memory (not using writeDeviceMemory), flush the mappings */
    res = dev->dmal->flushCpuMappingForDevvaddr(context,
                                                dev->smState[vsm].warp[tid].lmemSeg->devvaddr + warpCRSLow,
                                                warpCRSHigh - warpCRSLow,
                                                HALO_CACHE_FLUSH_WRITEBACK);

    if (res != CUDBG_SUCCESS)
    {
        HALO_ERROR("Failed to flushCpuMappings for updateCRS\n");
        goto done;
    }

done:
    cuosLeaveCriticalSection(&haloGlobals.mapMemory_cs);
    return res;
}

static CUDBGResult
fermi_flattenCRS(CudbgDevice dev, uint32_t vsm, uint32_t tid, unsigned char *flatCRS)
{
    static unsigned char* CRSBaseVA = NULL; // Effective (base) address within local memory allocation
    static size_t CRSBufferSz = 0;            // Size of CRSBaseVA read buffer
    int i;
    unsigned char *CRSPtr;
    unsigned char *CRSAddr; // Effective address (within local memory allocation)
    uint32_t CRSOff = 0;    // Warp offset into CRS (not yet a warp address)
    uint64_t nb;
    uint64_t warpCRSLow, warpCRSHigh;
    size_t warpCRSSz;

    uint32_t offset_32;
    CUDBGResult res = CUDBG_SUCCESS;

    CRSMagicCast_t flatCRSPtr;
    HaloLmemConfig_t *warpLmem = &dev->smState[vsm].warp[tid].lmemConfig;
    Context context = dev->activeContext;

    CUDBG_VERIFY((context && context->memMapActive),
                 CUDBG_ERROR_INVALID_CONTEXT,
                 "No context or context not active in fermi_flattenCRS.\n");

    CUDBG_VERIFY(dev->smState[vsm].warp[tid].lmemSeg,
                 CUDBG_ERROR_INVALID_MEMORY_SEGMENT,
                 "Lmemseg not set for warp\n");

    /* This is the first time we're reading CRS memory since the program has
       been suspended.  Ensure local memory allocation is mapped in. */
    res = dev->halo.getCRSInternalOffset(dev, vsm, tid, warpLmem->CRSSize, &offset_32);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to getCRSInternalOffset failed in flattenCRS.\n");
        return res;
    }
    warpCRSHigh = offset_32;

    res = dev->halo.getCRSInternalOffset(dev, vsm, tid, 0, &offset_32);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to getCRSInternalOffset failed in flattenCRS.\n");
        return res;
    }
    warpCRSLow = offset_32;

    warpCRSSz = (size_t)(warpCRSHigh - warpCRSLow);

    if (warpCRSSz > CRSBufferSz) {   // We're going to need a bigger buffer
        free(CRSBaseVA);
        CRSBaseVA = (unsigned char*)malloc(warpCRSSz);
        CRSBufferSz = warpCRSSz;
    }

    res = dev->halo.readDeviceMemory(context,
                                     dev->smState[vsm].warp[tid].lmemSeg->devvaddr + warpCRSLow,
                                     CRSBaseVA,
                                     (uint32_t)warpCRSSz);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Memory mapping failed in fermi_flattenCRS.\n");
        goto done;
    }

    /* Walk through raw CRS data, reorganizing its L1 cache line format
       into a flat data space.  Every fourth CRS entry is special; its
       first 2 bytes follow the first 3 CRS entries, but its remaining
       8 bytes are stored at the end of the cache line (96 bytes away). */
    flatCRSPtr.p = flatCRS;
    CRSPtr = CRSAddr = CRSBaseVA;
    // Cycle each cache line, 128B at a time
    for (nb = 0; nb < warpLmem->CRSSize; nb += FERMI_CACHE_LINE_SIZE) {
        for (i = 0; i < 3; i++) { // Read 4 entries at a time (1/3 of the line)
            memcpy(flatCRSPtr.chunk32++, CRSPtr + 32*i,     sizeof(chunk32_t));
            memcpy(flatCRSPtr.chunk8++,  CRSPtr + 96 + i*8, sizeof(chunk8_t));
        }
        CRSPtr += FERMI_CACHE_LINE_SIZE; // The above loop just copied a cache line

        /* CRS is allocated in 512-byte chunks for each warp, so we need to
           recompute the effective address on each 512-byte boundary */
        if (CRSPtr == CRSAddr + FERMI_LCL_CHUNK_SIZE) {
            CRSOff += FERMI_LCL_CHUNK_SIZE;
            res = dev->halo.getCRSInternalOffset(dev, vsm, tid, CRSOff, &offset_32);
            if (res != CUDBG_SUCCESS) {
                HALO_ERROR("Call to getCRSInternalOffset failed in flattenCRS.\n");
                goto done;
            }
            CRSPtr = CRSAddr = CRSBaseVA + offset_32 - warpCRSLow;
        }
    }

#if 0
    {
        /* Debugging - dump flat CRS - the last arg is the # of entries to print */
        uint32_t numEntries;
        CUDBGResult res;

        res = dev->halo.maxCRSEntriesPerWarp(dev, vsm, tid, &numEntries);
        if (res != CUDBG_SUCCESS) {
            cuosLeaveCriticalSection(&haloGlobals.mapMemory_cs);
            return res;
        }

        cuosLeaveCriticalSection(&haloGlobals.mapMemory_cs);
        return fermi_dumpCRS(dev, vsm, tid, flatCRS, numEntries);
    }
#endif

done:
    return res;
}

static CUDBGResult
allocateCRSFields(CudbgDevice dev, uint32_t vsm, uint32_t wp)
{
    HaloCRS_t *warpCRS = &dev->smState[vsm].warp[wp].CRS;
    uint32_t numEntries, entrySize;
    CUDBGResult res = CUDBG_SUCCESS;

    res = dev->halo.maxCRSEntriesPerWarp(dev, vsm, wp, &numEntries);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to maxCRSEntryiesPerWarp failed in allocateCRSFields.\n");
        return res;
    }

    res = dev->halo.CRSEntrySize(dev, &entrySize);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to CRSEntrySize failed in allocateCRSFields.\n");
        return res;
    }

    if (numEntries > warpCRS->numEntries) {

        warpCRS->flatCRS    = (unsigned char *)realloc(warpCRS->flatCRS, numEntries * entrySize);
        warpCRS->pc         = (uint32_t *)realloc(warpCRS->pc, numEntries * sizeof *warpCRS->pc);
        warpCRS->mask       = (uint32_t *)realloc(warpCRS->mask, numEntries * sizeof *warpCRS->mask);
        warpCRS->type       = (uint8_t *)realloc(warpCRS->type, numEntries * sizeof *warpCRS->type);
        warpCRS->xsum       = (uint8_t *)realloc(warpCRS->xsum, numEntries * sizeof *warpCRS->xsum);
        warpCRS->numEntries = numEntries;
        HALO_TRACE(5, "CRS field allocation for dev 0x%" PRIx64 " vsm%d/wp%d: "
                   "numEntries = %d\n", dev, vsm, wp, numEntries);
    }

    CUDBG_VERIFY((warpCRS->flatCRS && warpCRS->pc && warpCRS->mask && warpCRS->type && warpCRS->xsum),
                 CUDBG_ERROR_INTERNAL,
                 "Failed to allocate warpCRS - possibly caused by incorrect readout of CRSSize.\n");

    return CUDBG_SUCCESS;
}

/* fermi_collectWarpCRS is called each time the device is suspended.
   This function will 'unpack' CRS data correctly (see documentation
   above) and keep it cached for each valid warp. */
static CUDBGResult
fermi_collectWarpCRS(CudbgDevice dev, uint32_t vsm, uint32_t tid)
{
    uint32_t i, j;
    HaloCRS_t *warpCRS = &dev->smState[vsm].warp[tid].CRS;
    CRSMagicCast_t flatCRSPtr;
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t numEntries = 0, warpCRSSize = 0, paddingSize = 0;
    bool usingCRSPtr = false, trapTokenFound = false;
#ifndef RELEASE
    bool verifyCRS = true;
#endif

    res = allocateCRSFields(dev, vsm, tid);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to allocateCRSField failed in collectWarpCRS.\n");
        return res;
    }

    res = dev->halo.flattenCRS(dev, vsm, tid, warpCRS->flatCRS);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to flattenCRS failed in collectWarpCRS.\n");
        return res;
    }

    flatCRSPtr.p = warpCRS->flatCRS;

    res = dev->halo.CRSEntryPaddingSize(dev, &paddingSize);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to CRSEntryPaddingSize failed in collectWarpCRS.\n");
        return res;
    }

    res = dev->halo.getWarpCRSUsage(dev, vsm, tid, &numEntries, &warpCRSSize, &usingCRSPtr);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to getWarpCRSUsage failed in collectWarpCRS.\n");
        return res;
    }

    for (i = 0; i < numEntries; i++) {

        warpCRS->pc[i]   = *flatCRSPtr.pc++;
        warpCRS->mask[i] = *flatCRSPtr.mask++;
        warpCRS->type[i] = *flatCRSPtr.type++;
        warpCRS->xsum[i] = *flatCRSPtr.xsum++;
        flatCRSPtr.p += paddingSize;

#ifndef RELEASE
        {
            if (verifyCRS) {
                res = dev->halo.verifyCRSxsum(warpCRS, i);
                if (res != CUDBG_SUCCESS)
                    return res;
            }
        }
#endif
        /* Only the lower 5 bits of the type field are valid for SW to look
           at.  This was found on GK104, where the upper 3 bits are reserved
           by HW, but we should mask them off no matter what here.
           Note:  this must be done after verifying the xsum */
        warpCRS->type[i] &= 0x1f;

        /* Mark the trap token - it will be used when reading the above
           state, and when modifying a warp's PC and xsum CRS fields */
        if (warpCRS->type[i] == CRS_TYPE_TRAP) {
            HALO_TRACE(20, "CRS Trap Token Found @ Index %d!\n", i);
            warpCRS->trapIdx = i;
            trapTokenFound = true;

            if (!usingCRSPtr) {
                HALO_TRACE(50, "Not using CRS Ptr; stopping at this Trap Token\n");
                break;
            }
            else {
#ifndef RELEASE
                /* Bug 1034047:  Temporary for r304_00. The driver allows warps to trap
                   after setting a false (max) CRS depth via SETCRSPTR.  This means there
                   can be many invalid/uninitialized CRS tokens when looking at the stack.
                   Here, we check if we've trapped in this case and prevent verification
                   of these tokens (but we'll still verify the user stack and the
                   fallthrough trap token stack).  This problem can only happen when CRS is
                   set to the max (512 clamps to 504), but since that could be a valid stack,
                   we catch this case by examining the distance between the first valid TRAP
                   token and the value of GETCRSPTR.  If there are more than 16 entries after
                   TRAP, then stop verifying tokens as we're in a fallthrough and we could
                   falsely assert on incorrect tokens in the stack.  Only needed for debug
                   builds where CRS verification is performed.  In the long-term, this will
                   be fixed by updating the trap handler to protect this fallthrough region
                   with an IDE critical section. */
                if (numEntries >= i + 16) {
                    verifyCRS = false;
                    HALO_TRACE(50, "Using CRS Ptr; trapped from fallthrough region\n");
                }
                else
#endif
                    HALO_TRACE(50, "Using CRS Ptr; continuing to search for Trap Tokens...\n");
            }
        }
    }

    if (!trapTokenFound) {
        /* All warps should have a trap token (see above). */
        HALO_ERROR("No CRS trap token found for dev=%u vsm=%u tid=%u\n",
                   dev->deviceIdx, vsm, tid);
        return CUDBG_ERROR_INTERNAL;
    }

    if (warpCRS->trapIdx >= (numEntries - FERMI_NUM_CRS_DIS_ENTRIES)) {
        /* The trapper pushes 6 DISABLE tokens (see CRS type definitions).
           These must always be present on the stack, or we may be unable
           to properly unwind in some cases */
        HALO_ERROR("%u/%u: Trap token found too deep in the stack (%d > %d)",
                   vsm, tid, warpCRS->trapIdx, numEntries - FERMI_NUM_CRS_DIS_ENTRIES);
        return CUDBG_ERROR_INTERNAL;
    }

    /* If we haven't already rolled up the DIS tokens, we need to do that now.
       This can only happen if we've stopped searching after finding a trap
       token (on architectures that do not have GETCRSPTR) */
    if (i == warpCRS->trapIdx) {
        for (j = i + 1; j <= warpCRS->trapIdx + FERMI_NUM_CRS_DIS_ENTRIES; j++) {
            warpCRS->pc[j]   = *flatCRSPtr.pc++;
            warpCRS->mask[j] = *flatCRSPtr.mask++;
            warpCRS->type[j] = *flatCRSPtr.type++;
            warpCRS->xsum[j] = *flatCRSPtr.xsum++;
            flatCRSPtr.p += paddingSize;

#ifndef RELEASE
            {
                res = dev->halo.verifyCRSxsum(warpCRS, j);
                if (res != CUDBG_SUCCESS)
                    return res;
            }
#endif
            warpCRS->type[j] &= 0x1f; /* Top 3 bits reserved by HW */
        }
    }

    /* Sort out and verify the DIS tokens (pushed after TRAP) */
    for (j = warpCRS->trapIdx + 1; j <= warpCRS->trapIdx + FERMI_NUM_CRS_DIS_ENTRIES; j++) {
        /* Cache the DIS tokens for quick access later */
        switch (warpCRS->type[j]) {
        case CRS_TYPE_DIS_RET:
            warpCRS->disRetIdx = j;
            break;
        case CRS_TYPE_DIS_CONT:
            warpCRS->disContIdx = j;
            break;
        case CRS_TYPE_DIS_BRK:
            warpCRS->disBrkIdx = j;
            break;
        case CRS_TYPE_DIS_SYNC:
            warpCRS->disSyncIdx = j;
            break;
        case CRS_TYPE_DIS_LONGJUMP:
            warpCRS->disLjmpIdx = j;
            break;
        case CRS_TYPE_DIS_EXIT:
            warpCRS->disExitIdx = j;
            break;
        default:
            HALO_ERROR("%u/%u: Invalid/No DIS token pushed at trapIdx+%d. Token=%u\n",
                       vsm, tid, j, warpCRS->type[j]);
            return CUDBG_ERROR_INTERNAL;
        }
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_readPC(CudbgDevice dev, uint32_t vsm, uint32_t tid, uint64_t *pc)
{
    HaloCRS_t *warpCRS = &dev->smState[vsm].warp[tid].CRS;
    *pc = warpCRS->pc[warpCRS->trapIdx];  // return PC from trap entry
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_writePC(CudbgDevice dev, uint32_t vsm, uint32_t tid, uint64_t pc)
{
    uint32_t i, idx;
    uint8_t xsum = 0;
    unsigned char *flatCRSTrapAddr;
    HaloCRS_t *warpCRS = &dev->smState[vsm].warp[tid].CRS;

    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t entrySize;

    /* CHECKSUM UPDATE (Computed as a delta from the original xsum)
       Fermi HW requires that the xsum be updated to reflect the new
       PC that we have written.  If the xsum is not updated, HW will
       kill the warp that this CRS entry belongs to! */
    idx = warpCRS->trapIdx;
    for (i = 0; i < 4; ++i)
        xsum += (uint8_t) (((pc >> (i * 8)) & 255) - ((warpCRS->pc[idx] >> (i * 8)) & 255));

    /* Update cached pc and xsum (this is probably not necessary as it
       will be updated the next time we suspend the device and collect
       the CRS, but we do it anyway to ensure a coherent state) */
    warpCRS->pc[idx] = (uint32_t)pc;
    warpCRS->xsum[idx] -= xsum;

    /* Update flat CRS */
    res = dev->halo.CRSEntrySize(dev, &entrySize);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to CRSEntrySize failed in writePC.\n");
        return res;
    }

    flatCRSTrapAddr = &warpCRS->flatCRS[idx * entrySize];
    memcpy(flatCRSTrapAddr + FERMI_CRS_XSUM_OFFSET, (char *)&warpCRS->xsum[idx], sizeof warpCRS->xsum[idx]);
    memcpy(flatCRSTrapAddr + FERMI_CRS_PC_OFFSET, (char *)&warpCRS->pc[idx], sizeof warpCRS->pc[idx]);

    /* Now write back CRS modifications to the device */
    res = dev->halo.updateCRS(dev, vsm, tid, warpCRS->flatCRS, idx);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to updateCRS failed in writePC.\n");
        return res;
    }

#if 0
    /* Debugging:  read back raw CRS from the chip to verify updates */
    dev->halo.collectWarpCRS(dev, vsm, tid);
#endif

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_readActiveMask(CudbgDevice dev, uint32_t vsm, uint32_t tid, uint32_t *mask)
{
    HaloCRS_t *warpCRS = &dev->smState[vsm].warp[tid].CRS;
    *mask = warpCRS->mask[warpCRS->trapIdx]; // Return PC from trap entry
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_findDisabledCRS_Entry(CudbgDevice dev, uint32_t vsm,
                            uint32_t tid, uint32_t lane, bool *found)
{
    HaloCRS_t *warpCRS = &dev->smState[vsm].warp[tid].CRS;

    CUDBG_VERIFY(found, CUDBG_ERROR_INVALID_ARGS, "Invalid args to findDisabledCRS_Entry\n");

    /* Initialize to false */
    *found = false;

    /* Scan for this lane in any of the DIS masks (save the DIS_EXIT mask) */
    if (1U << lane & warpCRS->mask[warpCRS->disRetIdx]  ||
        1U << lane & warpCRS->mask[warpCRS->disBrkIdx]  ||
        1U << lane & warpCRS->mask[warpCRS->disContIdx] ||
        1U << lane & warpCRS->mask[warpCRS->disSyncIdx] ||
        1U << lane & warpCRS->mask[warpCRS->disLjmpIdx])
        *found = true;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_findDisabledCRS_PC(CudbgDevice dev, uint32_t vsm, uint32_t tid,
                         uint32_t lane, uint64_t *pc, bool *found)
{
    HaloCRS_t *warpCRS = &dev->smState[vsm].warp[tid].CRS;
    int32_t i;
    DebugPatch patch = NULL;
    bool inGlobalSyscallPatch = false;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(found, CUDBG_ERROR_INVALID_ARGS, "Invalid args to findDisabledCRS_PC\n");

    /* Initialize search result to false */
    *found = false;

    /* Look at DIS_RET:  This lane has executed RET and if
       there had been any DIV tokens for this lane, they
       are now gone.  We must look backward for the most
       recent corresonding CAL token for this lane. */
    if (1U << lane & warpCRS->mask[warpCRS->disRetIdx]) {
        for (i = warpCRS->trapIdx - 1; i >= 0; i--) {
            if ((warpCRS->type[i] == CRS_TYPE_CALL ||
                 warpCRS->type[i] == CRS_TYPE_CALL_NI) &&
                1U << lane & warpCRS->mask[i]) {

                /* Skip if the return pc is in a syscall patch. This ignores CNP entry stub if needed */
                res = dev->haloClient->inGlobalSyscallPatch(dev, warpCRS->pc[i], &patch, &inGlobalSyscallPatch);
                if (res != CUDBG_SUCCESS) {
                    HALO_ERROR("Call to inGlobalSyscallPatch failed in findDisabledCRS_PC.\n");
                    return res;
                }
                if (inGlobalSyscallPatch)
                    continue;

                *pc = warpCRS->pc[i];
                *found = true;
                return CUDBG_SUCCESS;
            }
        }
    }

    /* Look at DIS_BRK: Follow back to PBRK */
    if (1U << lane & warpCRS->mask[warpCRS->disBrkIdx]) {
        for (i = warpCRS->trapIdx - 1; i >= 0; i--) {
            if (warpCRS->type[i] == CRS_TYPE_PBRK &&
                1U << lane & warpCRS->mask[i]) {
                *pc = warpCRS->pc[i];
                *found = true;
                return CUDBG_SUCCESS;
            }
        }
    }

    /* Look at DIS_CONT: Follow back to PCONT */
    if (1U << lane & warpCRS->mask[warpCRS->disContIdx]) {
        for (i = warpCRS->trapIdx - 1; i >= 0; i--) {
            if (warpCRS->type[i] == CRS_TYPE_PCONT &&
                1U << lane & warpCRS->mask[i]) {
                *pc = warpCRS->pc[i];
                *found = true;
                return CUDBG_SUCCESS;
            }
        }
    }

    /* Look at DIS_SYNC: Follow back to SSY */
    if (1U << lane & warpCRS->mask[warpCRS->disSyncIdx]) {
        for (i = warpCRS->trapIdx - 1; i >= 0; i--) {
            if (warpCRS->type[i] == CRS_TYPE_SSY &&
                1U << lane & warpCRS->mask[i]) {
                *pc = warpCRS->pc[i];
                *found = true;
                return CUDBG_SUCCESS;
            }
        }
    }

    /* Look at DIS_LONGJMP: Follow back to PLONGJMP */
    if (1U << lane & warpCRS->mask[warpCRS->disLjmpIdx]) {
        for (i = warpCRS->trapIdx - 1; i >= 0; i--) {
            if (warpCRS->type[i] == CRS_TYPE_PLONGJMP &&
                1U << lane & warpCRS->mask[i]) {
                *pc = warpCRS->pc[i];
                *found = true;
                return CUDBG_SUCCESS;
            }
        }
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_findDisabledCRS_Mask(CudbgDevice dev, uint32_t vsm, uint32_t tid, uint32_t *mask)
{
    HaloCRS_t *warpCRS = &dev->smState[vsm].warp[tid].CRS;

    CUDBG_VERIFY(mask, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments to findDivergedCRS_Mask\n");

    /* Or in a bit for this lane if it is present in any of
       the DIS masks (save the DIS_EXIT mask) */
    *mask = warpCRS->mask[warpCRS->disRetIdx]  |
            warpCRS->mask[warpCRS->disBrkIdx]  |
            warpCRS->mask[warpCRS->disContIdx] |
            warpCRS->mask[warpCRS->disSyncIdx] |
            warpCRS->mask[warpCRS->disLjmpIdx];

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_findDivergedCRS_Entry(CudbgDevice dev, uint32_t vsm,
                            uint32_t tid, uint32_t lane, bool *found)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t i;
    HaloCRS_t *warpCRS = &dev->smState[vsm].warp[tid].CRS;

    CUDBG_VERIFY(found, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments to findDivergedCRS_Entry\n");

    /* Initialize to false */
    *found = false;

    /* Scan for this lane in the disable masks */
    res = fermi_findDisabledCRS_Entry(dev, vsm, tid, lane, found);
    if (res != CUDBG_SUCCESS)
        return res;

    /* If we successfully found this lane in a disable mask,
       return early.  We're done here. */
    if (*found)
        return CUDBG_SUCCESS;

    /* Look for any diverged entries on the CRS */
    for (i = 0; i < warpCRS->trapIdx; i++)
        /* See if this entry contains a divergence token */
        if (warpCRS->type[i] == CRS_TYPE_DIV      ||
            warpCRS->type[i] == CRS_TYPE_DIV_IDX)
            /* If this lane is within the mask, report it */
            if (1U << lane & warpCRS->mask[i]) {
                *found = true;
                return CUDBG_SUCCESS;
            }

    /* We didn't find any divergence entries */
    *found = false;
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_findDivergedCRS_PC(CudbgDevice dev, uint32_t vsm,
                         uint32_t tid, uint32_t lane, uint64_t *pc)
{
    bool laneFoundInDisableMask = false;
    uint32_t i;
    uint64_t latest_pc = 0;
    HaloCRS_t *warpCRS = &dev->smState[vsm].warp[tid].CRS;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(pc, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments to findDivergedCRS_PC\n");

    /* Scan for this lane in the disable masks */
    res = fermi_findDisabledCRS_PC(dev, vsm, tid, lane, pc, &laneFoundInDisableMask);
    if (res != CUDBG_SUCCESS)
        return res;

    /* If we successfully found this lane in a disable mask,
       return early.  We've already filled in the PC. */
    if (laneFoundInDisableMask)
        return CUDBG_SUCCESS;

    /* Look for any diverged entries on the CRS */
    for (i = 0; i < warpCRS->trapIdx; i++)
        /* See if this entry contains a divergence token */
        if (warpCRS->type[i] == CRS_TYPE_DIV      ||
            warpCRS->type[i] == CRS_TYPE_DIV_IDX)
            /* If this lane is within the mask, save the PC as
               the best candidate to return */
            if (1U << lane & warpCRS->mask[i])
                latest_pc = warpCRS->pc[i];

    /* Return the pc from the last divergence token before the TRAP - If
       no divergence tokens were found for this lane, return 0 for PC */
    *pc = latest_pc;
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_findDivergedCRS_Mask(CudbgDevice dev, uint32_t vsm, uint32_t tid, uint32_t *mask)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t i, divergedMask = 0;
    HaloCRS_t *warpCRS = &dev->smState[vsm].warp[tid].CRS;

    CUDBG_VERIFY(mask, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments to findDivergedCRS_Mask\n");

    /* Scan for any lanes in the disabled masks */
    res = fermi_findDisabledCRS_Mask(dev, vsm, tid, &divergedMask);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Look for any diverged entries on the CRS */
    for (i = 0; i < warpCRS->trapIdx; i++)
        /* See if this entry contains a divergence token */
        if (warpCRS->type[i] == CRS_TYPE_DIV     ||
            warpCRS->type[i] == CRS_TYPE_DIV_IDX)
            /* OR in the word that contains the mask */
            divergedMask |= warpCRS->mask[i];

    *mask = divergedMask;
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_readAndResetContextActiveBit(Context context, CudbgDevice dev, bool *isContextActive)
{
    CUDBGResult res;
    uint32_t active;

    CUDBG_VERIFY(isContextActive, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments in readAndResetContextActiveBit.\n");

    CUDBG_VERIFY((context && context->dev == dev),
                 CUDBG_ERROR_INVALID_CONTEXT,
                 "Invalid context while resetting context active bit.\n");

    res = dev->halo.scratchpad.read_active(context->scratchpadAccessor, &active);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read active\n");

    if (active)
        *isContextActive = true;

    /* Always set the scratchpad active bit to zero. */
    res = dev->halo.scratchpad.write_active(context->scratchpadAccessor, 0);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to write active\n");

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_lookForActiveContext(Context context, CudbgDevice dev)
{
    bool isContextActive = false;
    CUDBGResult res = CUDBG_SUCCESS;

    /* If the context is being torn down,
       dont bother trying to read it. */
    if (!context || !haloStateContextIsActive(context))
        return CUDBG_SUCCESS;

    res = dev->halo.readAndResetContextActiveBit(context, dev, &isContextActive);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE_FUNCTION(50, "Call to readAndResetContextActiveBit failed in lookForActiveContext.\n");
        return res;
    }

    if (isContextActive)
        dev->activeContext = context;

    return CUDBG_SUCCESS;
}

static TOOLSresult
lookForActiveContextWrap(tHashMapKey_t key, void *entry, void *data)
{
    CudbgDevice dev;
    Context context;
    CUDBGResult res = CUDBG_SUCCESS;

    context = (Context)entry;
    dev = (CudbgDevice) data;

    res = dev->halo.lookForActiveContext(context, dev);
    if (res != CUDBG_SUCCESS)
        return TOOLS_ERROR_UNKNOWN;

    return TOOLS_SUCCESS;
}

static CUDBGResult
fermi_findActiveContext(CudbgDevice dev, bool singleStepping)
{
    Context prevContext = dev->activeContext;
    CUDBGResult res = CUDBG_SUCCESS;

    /* If we are single-stepping, the trap handler will not be invoked if the
       warp exits. In that situation, we cannot find the active context by
       reading the active bit in the scratchpad. However, we know that the
       context has not changed. Therefore the active context is the previous
       active context. */
    if (singleStepping) {
        CUDBG_VERIFY(prevContext,
                     CUDBG_ERROR_INVALID_CONTEXT,
                     "Previous context not found when looking for active context.\n");

        dev->activeContext = prevContext;
        return CUDBG_SUCCESS;
    }

    /* Reset dev->activeContext to be able to detect errors */
    dev->activeContext = NULL;

    /* Check if the previous active context still exists and is still the
       current active context. It is a shortcut for performance that also a
       side-effect of avoiding unmapping the whole memory unnecessarily when
       mappping the memory for the other contexts. */
    if (prevContext && toolsHashMapContains(dev->contexts, tHashMapNumToKey(prevContext->cuCtx))) {
        res = dev->halo.lookForActiveContext(prevContext, dev);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to lookForActiveContext failed in findActiveContext.\n");
            return res;
        }
    }

    /* If the previous context is not active, iterate over all the contexts of
       the device for the active one. It is the context whose scratchped active
       bit is set. */
    if (!dev->activeContext)
        (void)toolsHashMapApplyFunctor(dev->contexts, lookForActiveContextWrap, dev);

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_readCallDepth(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                    uint32_t *depth)
{
    uint32_t i = 0;
    uint32_t call_count = 0, calSkipped = 0, laneDisRet = 0;
    uint32_t lane_mask = 1U << ln;
    HaloCRS_t *warpCRS = &dev->smState[vsm].warp[wp].CRS;
    DebugPatch patch = NULL;
    bool inGlobalSyscallPatch = false;
    bool hidden;
    DeviceFunction function;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(depth, CUDBG_ERROR_INVALID_ARGS, "Invalid argument passed in to readCallDepth.\n");

    /* Look for this lane is in the DIS_RET mask */
    laneDisRet = lane_mask & warpCRS->mask[warpCRS->disRetIdx];

    /* Count the CALL tokens for that lane */
    for (i = 0; i < warpCRS->trapIdx; i++) {
        if (warpCRS->type[i] == CRS_TYPE_CALL ||
            warpCRS->type[i] == CRS_TYPE_CALL_NI) {
            /* If this lane has been disabled for RET, then skip
               the first CAL token (it has completed this call) */
            if (laneDisRet && !calSkipped++)
                continue;

            /* Skip if the return pc is in a syscall patch. This ignores CNP entry stub if needed */
            res = dev->haloClient->inGlobalSyscallPatch(dev, warpCRS->pc[i], &patch, &inGlobalSyscallPatch);
            if (res != CUDBG_SUCCESS) {
                HALO_ERROR("Call to inGlobalSyscallPatch failed in readCallDepth.\n");
                return res;
            }
            if (inGlobalSyscallPatch)
                continue;

            /* Stop if the return pc is in a hidden function */
            if (dev->activeContext) {
                function = (DeviceFunction)toolsRangeMapLookupByAddr(dev->activeContext->gpuAddrToFunction, warpCRS->pc[i]);

                if (function) {
                    res = haloInHiddenFunction(function, &hidden);
                    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "error calling inHiddenFunction\n");

                    if (hidden) {
                        HALO_TRACE_FUNCTION(10, "stopping callDepth unwind due to "
                                            "hidden function %s at 0x%" PRIx64 "\n",
                                            function->name, function->gpuAddrBase);
                        break;
                    }
                }
            }

            if (warpCRS->mask[i] & lane_mask)
                call_count++;
        }
    }

    HALO_TRACE_FUNCTION(10, "callDepth %d\n", call_count);

    *depth = call_count;
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_checkForHwWar(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                  bool *inPatch, uint64_t *pc, uint32_t *depth)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t patchDepth = 0;
    DebugPatch patch = NULL;

    CUDBG_VERIFY(dev && inPatch && pc && depth, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args\n");

    *inPatch = false;
    if (depth)
        *depth = 0;

    /* Check if the PC is in a HW WAR */
    res = haloInPatchRegion(*pc, dev->activeContext, &patch, CUDBG_PATCH_HW_WAR,
                            inPatch, false);
    CUDBG_VERIFY((res == CUDBG_SUCCESS), res,
                 "Call to haloInPatchRegion failed\n");

    if (*inPatch) {
        switch (patch->kind) {
            case CUDBG_PATCH_MEMBAR_WAR:
                res = dev->halo.membarWAR_getPatchPC(dev, vsm, wp, ln, pc,
                                                     patch);
                CUDBG_VERIFY((res == CUDBG_SUCCESS), res,
                             "Call to membarWAR_getPatchPC failed\n");

                res = dev->halo.membarWAR_getPatchCallDepth(dev, vsm, wp, ln,
                                                            depth, patch);
                CUDBG_VERIFY((res == CUDBG_SUCCESS), res,
                             "Call to membarWAR_getPatchCallDepth failed\n");

                break;

            case CUDBG_PATCH_BAR_WAR:
                res = dev->halo.barWAR_getPatchPC(dev, vsm, wp, ln, pc);

                CUDBG_VERIFY((res == CUDBG_SUCCESS), res,
                             "Call to membarWAR_getPatchPC failed\n");

                *depth = patch->depth;
                break;

            case CUDBG_PATCH_LDC_WAR:
                *pc = patch->entryAddr;
                *depth = patch->depth;
                CUDBG_VERIFY(*pc && *depth, CUDBG_ERROR_UNKNOWN,
                             "entryAddr and depth should always be non-zero\n");
                break;

            default:
                /* We should never get here. */
                CUDBG_ERROR("Unknown patch type 0x%x.\n", patch->kind);
                return CUDBG_ERROR_INTERNAL;
        }

        HALO_TRACE(3,
                   "SM:%u/wp%u/ln%u Found in patch %u. Adjusting PC to 0x%x. (WAR depth:%u)\n",
                   patch->kind, vsm, wp, ln, pc, depth);
    }

    return res;
}

static CUDBGResult
fermi_readSyscallCallDepth(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln, uint32_t *depth)
{
    bool inSyscall = false, inPatch = false, inGlobalSyscallPatch = false;
    CUDBGResult res = CUDBG_SUCCESS;
    DebugPatch patch = NULL;
    int32_t i = 0;
    uint32_t call_count = 0, calSkipped = 0, laneDisRet = 0;
    uint32_t lane_mask = 1U << ln;
    uint64_t physPC;
    HaloCRS_t *warpCRS = &dev->smState[vsm].warp[wp].CRS;
    uint32_t patchDepth = 0;

    CUDBG_VERIFY(depth, CUDBG_ERROR_INVALID_ARGS, "Invalid argument passed in to readSyscallCallDepth\n");

    /* Find the correct PC for this lane, accounting for divergence */
    if (dev->smState[vsm].warp[wp].activeMask & (1U << ln)) {
        res = dev->halo.readPC(dev, vsm, wp, &physPC);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to readPC failed (res=%d)\n", res);
            return res;
        }
    }
    else {
        res = dev->halo.findDivergedCRS_PC(dev, vsm, wp, ln, &physPC);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to findDivergedCRS_PC failed (res=%d)\n", res);
            return res;
        }
    }
    res = dev->halo.checkForHwWar(dev, vsm, wp, ln, &inPatch, &physPC,
                                  &patchDepth);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to checkForHwWar failed\n");
        return res;
    }

    /* If the pc isn't within a syscall, the depth is zero */
    res = dev->haloClient->inSyscallPatch(dev, physPC, &patch, &inSyscall);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to inSyscallPatch failed\n");
        return res;
    }

    /* If the pc isn't within a syscall, the depth is zero */
    if (!inSyscall) {
        *depth = 0;
        return CUDBG_SUCCESS;
    }

    /* Look for this lane in the DIS_RET mask */
    laneDisRet = lane_mask & warpCRS->mask[warpCRS->disRetIdx];

    /* Count the CALL tokens within syscalls for the specified lane */
    for (call_count = 0, i = warpCRS->trapIdx - 1; i >= 0; --i) {
        /* If this lane has been disabled due to RET, skip
           the first CAL token (it has finished this call) */
        if ((warpCRS->type[i] == CRS_TYPE_CALL ||
             warpCRS->type[i] == CRS_TYPE_CALL_NI) &&
            laneDisRet && !calSkipped++)
            continue;

        /* Skip if the return pc is in a syscall patch. This ignores CNP entry stub if needed */
        res = dev->haloClient->inGlobalSyscallPatch(dev, warpCRS->pc[i], &patch, &inGlobalSyscallPatch);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to inGlobalSyscallPatch failed in readSyscallCallDepth.\n");
            return res;
        }
        if (inGlobalSyscallPatch)
            continue;

        if ((warpCRS->type[i] != CRS_TYPE_CALL &&
             warpCRS->type[i] != CRS_TYPE_CALL_NI) ||
            !(warpCRS->mask[i] & lane_mask))
            continue;

        if (inPatch && patchDepth) {
            --patchDepth;
            continue;
        }

        res = dev->haloClient->inSyscallPatch(dev, warpCRS->pc[i], &patch, &inSyscall);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to inSyscallPatch failed\n");
            return res;
        }

        /* Valid call in this lane */
        ++call_count;

        /* Exit condition, this jump is no longer in a syscall region. */
        if (!inSyscall) {
            *depth = call_count;
            return CUDBG_SUCCESS;
        }
    }

    /* If internal debugging is enabled, ignore that the CRS has syscalls without jumps */
    if (patch->debug) {
        *depth = 0;
        return CUDBG_SUCCESS;
    }

    /* Fall through. Implies that the CRS has syscalls, without any jump from
       user code. */
    return CUDBG_ERROR_UNKNOWN;
}

static CUDBGResult
fermi_readUserEntryFramePC(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                           bool *found, uint64_t *physPC)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t userPC = 0;
    uint64_t nextPC = 0;
    uint32_t call_depth = 0;
    bool inGlobalSyscall = false, inSyscall = false, inPatch = false;
    bool inMemcheckPatch = false;
    DebugPatch patch = NULL;
    int32_t i = 0;
    uint32_t patchDepth = 0;

    *found = false;

    /* Find the correct PC for this lane, accounting for divergence */
    if (dev->smState[vsm].warp[wp].activeMask & (1U << ln)) {
        res = dev->halo.readPC(dev, vsm, wp, &userPC);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to readPC failed (res=%d)\n", res);
            return res;
        }
    }
    else {
        res = dev->halo.findDivergedCRS_PC(dev, vsm, wp, ln, &userPC);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to findDivergedCRS_PC failed (res=%d)\n", res);
            return res;
        }
    }

    HALO_TRACE_FUNCTION(10,
                        "Found sm%d/wp%d/ln%d at PC:0x%" PRIx64 "\n",
                        vsm, wp, ln, *physPC);

    /* Resolve from a MEMBAR back into a previous frame if required */
    res = dev->halo.checkForHwWar(dev, vsm, wp, ln, &inPatch, &userPC,
                                      &patchDepth);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to checkForMembarWar failed\n");
        return res;
    }

    res = dev->haloClient->inGlobalSyscallPatch(dev, userPC, &patch, &inGlobalSyscall);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to inGlobalSyscallPatch failed. Initial check.\n");
        return res;
    }

    if (inGlobalSyscall) {
        *found = false;
        return CUDBG_SUCCESS;
    }

    res = dev->haloClient->inMemcheckPatch(dev, userPC, &inMemcheckPatch);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to inMemcheckPatch failed. Initial check.\n");
        return res;
    }

    res = dev->halo.readCallDepth(dev, vsm, wp, ln, &call_depth);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to readCallDepth failed\n");
        return res;
    }

    if (call_depth) {
        for (i = call_depth - 1; i >= 0; --i) {
            res = dev->halo.readReturnAddress(dev, vsm, wp, ln, i, &nextPC);
            if (res != CUDBG_SUCCESS) {
                HALO_ERROR("Call to readReturnAddress failed.\n");
                return res;
            }

            res = dev->haloClient->inGlobalSyscallPatch(dev, nextPC, &patch, &inGlobalSyscall);
            if (res != CUDBG_SUCCESS) {
                HALO_ERROR("Call to inGlobalSyscallPatch failed\n");
                return res;
            }

            /* If in a global syscall, go to the next frame */
            if (inGlobalSyscall)
                continue;

            res = dev->haloClient->inSyscallPatch(dev, nextPC, &patch, &inSyscall);
            if (res != CUDBG_SUCCESS) {
                HALO_ERROR("Call to inSyscallPatch failed\n");
                return res;
            }

            /* Keep going */
            if (inSyscall)
                continue;

            res = haloInPatchRegion(nextPC, dev->activeContext, &patch,
                                    CUDBG_PATCH_HW_WAR, &inPatch, false);
            CUDBG_VERIFY((res == CUDBG_SUCCESS), res,
                         "Call to haloInPatchRegion failed.\n");

            /* Keep going */
            if (inPatch)
                continue;

            *found = true;
            *physPC = (uint64_t)nextPC;

            HALO_TRACE_FUNCTION(10, "Found entry frame for sm%d/wp%d/ln%d at frame %d. PC:0x%" PRIx64 "\n",
                                vsm, wp, ln, i, *physPC);
            return CUDBG_SUCCESS;
        }

        /* If the frame unwind did not find any user frames, it is possible that the
           PC at the top of CRS is in user code. For final sanity, check if this PC
           is inside a syscall frame or a user frame.
           Note that if there was a MEMBAR patch in the way, that has already been
           resolved back into its caller's code */
        res = dev->haloClient->inSyscallPatch(dev, userPC, &patch, &inSyscall);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to inSyscallPatch failed. Initial check.\n");
            return res;
        }

        if (!inSyscall) {
            *found = true;
            *physPC = userPC;
            HALO_TRACE_FUNCTION(10, "Found entry frame for sm%d/wp%d/ln%d at frame 0. PC:0x%" PRIx64 "\n",
                                vsm, wp, ln, *physPC);
            return CUDBG_SUCCESS;
        }
    }
    else {
        *found = true;
        *physPC = (uint64_t)userPC;
        HALO_TRACE_FUNCTION(10, "Found user code for sm%d/wp%d/ln%d. PC:0x%" PRIx64 "\n",
                            vsm, wp, ln, *physPC);
        return res;
    }

    *found = false;

    return res;
}

static CUDBGResult
fermi_readReturnAddress(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                        uint32_t level, uint64_t *ra)
{
    int32_t i = 0;
    uint32_t current_level = 0, calSkipped = 0, laneDisRet = 0;
    uint32_t lane_mask = 1U << ln;
    HaloCRS_t *warpCRS = &dev->smState[vsm].warp[wp].CRS;
    DebugPatch patch = NULL;
    bool inGlobalSyscallPatch = false;
    CUDBGResult res = CUDBG_SUCCESS;

    /* Look for this lane in the DIS_RET mask */
    laneDisRet = lane_mask & warpCRS->mask[warpCRS->disRetIdx];

    /* Find the CALL token at the given level for that lane. Because levels are
       counted in the opposite direction to depth, the search goes backward
       from the trap token. */
    for (i = warpCRS->trapIdx - 1; i >= 0; i--)
        if (warpCRS->type[i] == CRS_TYPE_CALL ||
            warpCRS->type[i] == CRS_TYPE_CALL_NI) {
            /* If this lane is disabled due to RET, then we must skip
               the first CAL token (this lane has completed that call) */
            if (laneDisRet && !calSkipped++)
                continue;

            /* Skip if the return pc is in a syscall patch. This ignores CNP entry stub if needed */
            res = dev->haloClient->inGlobalSyscallPatch(dev, warpCRS->pc[i], &patch, &inGlobalSyscallPatch);
            if (res != CUDBG_SUCCESS) {
                HALO_ERROR("Call to inGlobalSyscallPatch failed in readReturnAddress.\n");
                return res;
            }
            if (inGlobalSyscallPatch)
                continue;

            if (warpCRS->mask[i] & lane_mask && current_level++ == level)
                break;
        }

    CUDBG_VERIFY((i != -1), CUDBG_ERROR_INVALID_CALL_LEVEL, "Invalid call level when reading return address.\n");

    *ra = warpCRS->pc[i];
    return CUDBG_SUCCESS;
}

/* End Fermi LMEM/CRS functions */


static CUDBGResult
fermi_singleStep(CudbgDevice dev, uint32_t vsm, int on)
{
    uint32_t regVal;
    uint32_t regOffset = 0;
    CUDBGResult res = CUDBG_SUCCESS;

    res = dev->halo.getPRIOffset(dev, HALO_PRI_SM_DBGR_CONTROL0, vsm,
                                 &regOffset);
    if (res != CUDBG_SUCCESS)
        return res;

    res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                     (char *)(uintptr_t)regOffset,
                                     &regVal);
    if (res != CUDBG_SUCCESS)
        return res;

    regVal = SETFIELD32(regVal,
                        NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_CONTROL0_SINGLE_STEP_MODE,
                        on);

    /* Set single step mode to whatever 'on' specifies */
    return dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                       (char *)(uintptr_t)regOffset,
                                       &regVal);
}

static CUDBGResult
fermi_mapGpcTpcSm(CudbgDevice dev)
{
    const CUdev* pDev = globals.devices[dev->deviceIdx];
    uint32_t tpc, gpc, priBaseOffset;
    uint32_t vsm = 0;
    CUresult cures = CUDA_SUCCESS;
    CUdevSmGpcTpcMap map = {0};

    CU_TRACE_FUNCTION();

    /* Init all the locations */
    memset(dev->halo.deviceInfo.vsmMap, ~0, sizeof dev->halo.deviceInfo.vsmMap);
    memset(dev->halo.deviceInfo.tpcMap, ~0, sizeof dev->halo.deviceInfo.tpcMap);
    memset(dev->halo.deviceInfo.gpcMap, ~0, sizeof dev->halo.deviceInfo.gpcMap);

    cures = pDev->dmal.deviceGetSmToSmGpcTpcMap(pDev, &map);
    if (cures != CUDA_SUCCESS) {
        HALO_ERROR(" Failed to get SM to GPC/TPC map from driver call. CUres:%u\n", cures);
        return CUDBG_ERROR_INTERNAL;
    }

    for (vsm = 0; vsm < map.numSm; ++vsm) {
        CUDBG_VERIFY((vsm < CUDBG_MAX_SMS && dev->halo.deviceInfo.gpcMap[vsm] == ~0U),
                     CUDBG_ERROR_INTERNAL,
                     "Error: GPC%u/TPC%u shares the same SM id %u as GPC%u/TPC%u.\n",
                     (NvU8)map.gpcId[vsm], (NvU8)map.localTpcId[vsm], vsm, dev->halo.deviceInfo.gpcMap[vsm], dev->halo.deviceInfo.tpcMap[vsm]);

        gpc = (NvU8)map.gpcId[vsm];
        tpc = (NvU8)map.localTpcId[vsm];
        priBaseOffset         = FERMI_GPC_OFFSET * gpc + FERMI_TPC_OFFSET * tpc;
        dev->halo.deviceInfo.gpcMap[vsm]      = gpc;
        dev->halo.deviceInfo.tpcMap[vsm]      = tpc;
        dev->halo.deviceInfo.vsmMap[gpc][tpc] = vsm;
        dev->priBase[vsm]     = dev->bar0 + priBaseOffset;
        ++dev->halo.deviceInfo.numSMs;
        HALO_TRACE(1, "  GPC%u/TPC%u is mapped to SM %u (priBase=%p)\n",
                   gpc, tpc, vsm, dev->priBase[vsm]);
    }

    return CUDBG_SUCCESS;
}

CUDBGResult
fermi_getInfo(CudbgDevice dev)
{
    const CUdev* pDev = globals.devices[dev->deviceIdx];
    HALO_TRACE(1, "fermi_getInfo\n");

    /* Pull info from the driver's dev state: */
    dev->halo.deviceInfo.smVirtualized       = false;
    dev->halo.deviceInfo.numSMsPrTPC         = pDev->state.limits.numSmsPerTpc;
    dev->halo.deviceInfo.numGPCsPrDevice     = pDev->state.limits.numGpcs;
    dev->halo.deviceInfo.numWarpsPrSM        = pDev->state.limits.warpsPerSm;
    dev->halo.deviceInfo.numWarpsPrTPC       = pDev->state.limits.warpsPerSm * dev->halo.deviceInfo.numSMsPrTPC;
    dev->halo.deviceInfo.numLanesPrWarp      = pDev->state.limits.warpSize;
    dev->halo.deviceInfo.numRegsPrLane       = CUDBG_MAX_REG_FERMI;
    dev->halo.deviceInfo.numPredicatesPrLane = FERMI_NUM_PREDICATES;
    dev->halo.deviceInfo.maxGPCsPrDevice     = CUDBG_MAX_GPC_FERMI;
    dev->halo.deviceInfo.bpt32Inst           = FERMI_BREAKPT32;
    dev->halo.deviceInfo.bpt64Inst           = FERMI_BREAKPT64;
    dev->halo.deviceInfo.numUniformRegsPrWarp       = 0;
    dev->halo.deviceInfo.numUniformPredicatesPrWarp = 0;

    /* Map GPC/TPC to SM Id */
    return dev->halo.mapGpcTpcSm(dev);
}

static CUDBGResult
fermi_read_threadIdx(CudbgDevice dev,
                     uint32_t vsm, uint32_t wp, uint32_t lane,
                     uint32_t threadBlockDimZ,
                     uint32_t *thrX, uint32_t *thrY, uint32_t *thrZ)
{
    CUDBGResult res;
    CuDim3 threadIdx;
    Context context = dev->activeContext;

    res = dev->halo.scratchpad.read_threadIdx(context->scratchpadAccessor, vsm, wp, lane, &threadIdx);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read threadIdx\n");

    *thrX = threadIdx.x;
    *thrY = threadIdx.y;
    *thrZ = threadIdx.z;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_handleGlobalMMUErrorState(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                CUDBGException_t *laneException, bool *error)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t mmuFaultInfo;
    uint32_t gpcId, clientId, warpId, tpcId;
    bool tpcKnown = true; // Assume we can find the TPC (see below)

    /* Read MMU_FAULT_INFO for the GR engine (0 == ENGINE_ID_GRAPHICS) */
    res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GLOBAL,
                                     dev->bar0 + NV_PFIFO_INTR_MMU_FAULT_INFO(0),
                                     &mmuFaultInfo);
    if (res != CUDBG_SUCCESS)
        return res;

    HALO_TRACE(1, "MMU Fault Info: 0x%08x\n", mmuFaultInfo);

    /* MMU faults must come from GPC to provide attribution
       (TODO: GK20a where only HUB MMU exists */
    if (GETFIELD32(mmuFaultInfo, NV_PFIFO_INTR_MMU_FAULT_INFO_ENGINE_SUBID) ==
        NV_PFIFO_INTR_MMU_FAULT_INFO_ENGINE_SUBID_GPC) {

        gpcId    = GETFIELD32(mmuFaultInfo, NV_PFIFO_INTR_MMU_FAULT_INFO_GPC_ID);
        clientId = GETFIELD32(mmuFaultInfo, NV_PFIFO_INTR_MMU_FAULT_INFO_CLIENT);
        warpId   = GETFIELD32(mmuFaultInfo, NV_PFIFO_INTR_MMU_FAULT_INFO_WARP_ID);

        HALO_TRACE(1, "VSM %d, NV_PFIFO_INTR_MMU_FAULT_INFO -> "
                   " Client ID: %d / "
                   " Warp ID: %d / "
                   " GPC ID: %d\n",
                   vsm, clientId, warpId, gpcId);

        /* Discover TPC ID from client ID */
        switch (clientId) {
        case NV_PFIFO_INTR_MMU_FAULT_INFO_CLIENT_GPC_L1_0:
            tpcId = 0;
            break;
        case NV_PFIFO_INTR_MMU_FAULT_INFO_CLIENT_GPC_L1_1:
            tpcId = 1;
            break;
        case NV_PFIFO_INTR_MMU_FAULT_INFO_CLIENT_GPC_L1_2:
            tpcId = 2;
            break;
        case NV_PFIFO_INTR_MMU_FAULT_INFO_CLIENT_GPC_L1_3:
            tpcId = 3;
            break;
        default:
            HALO_TRACE(1, "GPC SUBCLIENT UNKNOWN, skipping comparison and attributing.\n");
            tpcKnown = false;
            break;
        }

        if (tpcKnown && (vsm != dev->halo.deviceInfo.vsmMap[gpcId][tpcId] || wp != warpId)) {
            HALO_TRACE(1, "VSM%u/WP%u doesn't match GPC%u/TPC%u/Warp%u, "
                       "not attributing it to MMU fault!\n",
                       vsm, wp, gpcId, tpcId, warpId);
            return CUDBG_SUCCESS;
        }

        *laneException = CUDBG_EXCEPTION_DEVICE_ILLEGAL_ADDRESS;
        HALO_TRACE(1, "Reporting device illegal address on vsm%d/wp%d. "
                   "Setting MMU exception in device state\n",
                   vsm, wp);
        *error = true;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_handleGlobalErrorState(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                             uint32_t gESR, CUDBGException_t *laneException,
                             bool *error)
{
    uint32_t l1ESR, l1ADR, l1REQ;
    uint32_t regOffset = 0;
    uint32_t mmuFaultEngId;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(error, CUDBG_ERROR_INVALID_ARGS, "Invalid argument in fermi_handleGlobalErrorState.\n");

    *error = false;

    /* Check the global ESR */
    if ((gESR >> GLOBAL_ERROR_STATUS_L1_ERROR_FIELD) & 1) {
        /* Catches L1 MMU Faults - the warp that caused the error is unknown. */
        HALO_TRACE(1, "Found global err (L1 MMU fault) "
                   "on vsm%d/wp%d\n", vsm, wp);

        /* Examine the L1 HWW ESR to get more information.  This
           info is apparently unreliable, so we just trace it. */
        res = dev->halo.getPRIOffset(dev, HALO_PRI_L1C_HWW_ESR, vsm,
                             &regOffset);
        if (res != CUDBG_SUCCESS)
            return res;

        res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GLOBAL,
                                         (char *)(uintptr_t)regOffset, &l1ESR);
        if (res != CUDBG_SUCCESS)
            return res;

        res = dev->halo.getPRIOffset(dev, HALO_PRI_L1C_HWW_ESR_ADDR, vsm,
                             &regOffset);
        if (res != CUDBG_SUCCESS)
            return res;

        res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GLOBAL,
                                         (char *)(uintptr_t)regOffset, &l1ADR);
        if (res != CUDBG_SUCCESS)
            return res;

        res = dev->halo.getPRIOffset(dev, HALO_PRI_L1C_HWW_ESR_REQ, vsm,
                             &regOffset);
        if (res != CUDBG_SUCCESS)
            return res;

        res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GLOBAL,
                                         (char *)(uintptr_t)regOffset, &l1REQ);
        if (res != CUDBG_SUCCESS)
            return res;

        HALO_TRACE(1, "L1C HWW ESR Information (Unknown Reliability):\n"
                   "(Local Error: %d, Global RD Error: %d, Global WR Error: %d) "
                   "Address: 0x%x, Opcode: %d, Warp ID: %d\n",
                   GETFIELD32(l1ESR, NV_PGRAPH_PRI_GPC0_TPC0_L1C_HWW_ESR_LOCAL_SZ),
                   GETFIELD32(l1ESR, NV_PGRAPH_PRI_GPC0_TPC0_L1C_HWW_ESR_GLOBAL_MAP_RD_ERR),
                   GETFIELD32(l1ESR, NV_PGRAPH_PRI_GPC0_TPC0_L1C_HWW_ESR_GLOBAL_MAP_WR_ERR),
                   GETFIELD32(l1ADR, NV_PGRAPH_PRI_GPC0_TPC0_L1C_HWW_ESR_ADDR_VALUE),
                   GETFIELD32(l1REQ, NV_PGRAPH_PRI_GPC0_TPC0_L1C_HWW_ESR_REQ_OPCODE),
                   GETFIELD32(l1REQ, NV_PGRAPH_PRI_GPC0_TPC0_L1C_HWW_ESR_REQ_SM_WARP_ID));

        /* Now obtain some more specific information about the fault. */
        res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GLOBAL,
                                         dev->bar0 + NV_PFIFO_INTR_MMU_FAULT_ID,
                                         &mmuFaultEngId);
        if (res != CUDBG_SUCCESS)
            return res;

        HALO_TRACE(1, "MMU Fault Engine ID: 0x%08x\n", mmuFaultEngId);

        res = dev->halo.handleGlobalMMUErrorState(dev, vsm, wp, laneException,
                                                  error);
        if (res != CUDBG_SUCCESS)
            return res;
    }
    else if ((gESR >> GLOBAL_ERROR_STATUS_PHYSICAL_STACK_OVERFLOW_FIELD) & 1) {
        /* Catches a CRS stack overflow (per-warp CRS memory exhausted) */
        HALO_TRACE(1, "Found global error (physical stack overflow) "
                   "on vsm%d/wp%d\n", vsm, wp);

        *laneException = CUDBG_EXCEPTION_DEVICE_HARDWARE_STACK_OVERFLOW;
        HALO_TRACE(1, "Reporting device hardware stack overflow "
                   "on vsm%d/wp%d\n", vsm, wp);
        *error = true;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_getPauseReasonTableWarpOffset(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t* offset)
{
    CUDBG_VERIFY(offset && dev, CUDBG_ERROR_INVALID_ARGS, "\n");
    *offset = (dev->halo.deviceInfo.numWarpsPrSM * vsm + wp) * sizeof(uint32_t);
    return CUDBG_SUCCESS;
}

static inline CUDBGResult
fermi_handleWarpSyscallErrorState(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t wESR,
                                  uint32_t laneActive, uint32_t *laneErrors)
{
    CUDBGResult res = CUDBG_SUCCESS;
    bool inSyscallPatch = false;
    DebugPatch syscallPatch = NULL;
    uint32_t rcBuffer;
    uint32_t warpRcOffset = 0;
    uint32_t lane;
    uint64_t entryPc;

    CUDBG_VERIFY(laneErrors, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid argument in fermi_handleWarpSyscallErrorState.\n");

    if (!laneActive) {
        return CUDBG_SUCCESS;
    }

    /* Detect if this warp has hit an assert. For now, asserts appear to the
       debugger as breakpoints inside a syscall region. The reason code buffer
       must then be checked to determine the cause of the breakpoint.*/

    /* Early exit if the warp has not hit a breakpoint */
    if (!warpBitmaskGetBits(&dev->smState[vsm].state.bptrapmask, wp, 1))
        return CUDBG_SUCCESS;

    /* Identify if pc is within a syscall */
    res = dev->haloClient->inSyscallPatch(dev,
                                          dev->smState[vsm].warp[wp].pc,
                                          &syscallPatch,
                                          &inSyscallPatch);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read syscall patch location\n");
        return res;
    }

    /* Early exit if we are not in the syscall patch */
    if (!inSyscallPatch)
        return CUDBG_SUCCESS;

    CUDBG_VERIFY(dev->activeContext, CUDBG_ERROR_INVALID_CONTEXT,
                 "Device has no active context in fermi_handleWarpSyscallErrorState.\n");


    res = dev->halo.getPauseReasonTableWarpOffset(dev, vsm, wp, &warpRcOffset);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to get pause reason table offset for vsm%d/wp%d\n", vsm, wp);
        return res;
    }

    res = dev->halo.readPinnedMemory(dev,
                                     dev->activeContext->syscallRcVaddr +
                                     warpRcOffset,
                                     &rcBuffer,
                                     sizeof rcBuffer);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read pinned syscall reason buffer\n");
        return res;
    }

    if (rcBuffer != CU_PRT_REASON_SYSCALL_ASSERT) {
        return CUDBG_SUCCESS;
    }

    HALO_TRACE(1, "Reporting warp hit assert on vsm%d/wp%d\n", vsm, wp);
    warpBitmaskSetBits(&dev->smState[vsm].state.syscallwarps, wp, 1, 1);

    dev->smState[vsm].state.knownEvent = true;
    dev->smState[vsm].state.foundException = true;
    for (lane = 0; lane < 32; ++lane, laneActive >>= 1) {
        /* Skip lanes that aren't active */
        if (~laneActive & 0x1) {
            continue;
        }

        res = dev->halo.findSyscallEntryPoint(dev, vsm, wp, lane, &entryPc);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to find syscall entry point\n");
            return res;
        }

        /* set user code entry point into assert */
        dev->smState[vsm].warp[wp].syscallEntryPc = entryPc;
        dev->smState[vsm].warp[wp].laneExceptions[lane] = CUDBG_EXCEPTION_WARP_ASSERT;
        *laneErrors |= 0x1 << lane;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_handleWarpErrorState(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                           uint32_t wESR, CUDBGException_t *laneException,
                           bool *error)
{
    warpErrorStatusGF100_t warpError;

    CUDBG_VERIFY(error, CUDBG_ERROR_INVALID_ARGS, "Invalid argument in fermi_handleWarpErrorState.\n");

    *error = false;

    /* Check the warp ESR */
    warpError = (warpErrorStatusGF100_t)(wESR & SR_WARP_ERROR_MASK);
    if (warpError)
        HALO_TRACE(1, "Found warp error (%d) on vsm%d/wp%d\n",
                   warpError, vsm, wp);

    switch (warpError) {
        /* Hardware Stack Overflow Exception */
    case WARP_ERROR_STACK_ERROR:
    case WARP_ERROR_API_STACK_ERROR:
        *laneException = CUDBG_EXCEPTION_WARP_HARDWARE_STACK_OVERFLOW;
        HALO_TRACE(1, "Reporting warp hardware stack overflow "
                   "on vsm%d/wp%d\n", vsm, wp);
        *error = true;
        return CUDBG_SUCCESS;
        /* Illegal Instruction Exception */
    case WARP_ERROR_MISALIGNED_REG:
    case WARP_ERROR_OOR_REG:
    case WARP_ERROR_MISALIGNED_IMMC$_ADDR:
    case WARP_ERROR_INVALID_CONST_ADDR:
    case WARP_ERROR_INVALID_CONST_ADDR_LDC:
    case WARP_ERROR_ILLEGAL_INSTR_ENCODING:
    case WARP_ERROR_ILLEGAL_SPH_INSTR_COMBINATION:
    case WARP_ERROR_ILLEGAL_INSTR_PARAM:
    case WARP_ERROR_ILLEGAL_INSTR_PARAM2:
        *laneException = CUDBG_EXCEPTION_WARP_ILLEGAL_INSTRUCTION;
        HALO_TRACE(1, "Reporting warp illegal instruction "
                   "on vsm%d/wp%d\n", vsm, wp);
        *error = true;
        return CUDBG_SUCCESS;
        /* Out-of-range Address Exception */
    case WARP_ERROR_OOR_ADDR:
        *laneException = CUDBG_EXCEPTION_WARP_OUT_OF_RANGE_ADDRESS;
        HALO_TRACE(1, "Reporting warp out-of-range address on "
                   "vsm%d/wp%d\n", vsm, wp);
        *error = true;
        return CUDBG_SUCCESS;
        /* Misaligned Address Exception */
    case WARP_ERROR_MISALIGNED_ADDR:
        *laneException = CUDBG_EXCEPTION_WARP_MISALIGNED_ADDRESS;
        HALO_TRACE(1, "Reporting warp misaligned address on "
                   "vsm%d/wp%d\n", vsm, wp);
        *error = true;
        return CUDBG_SUCCESS;
        /* Invalid Address Exception */
    case WARP_ERROR_INVALID_ADDR_SPACE:
        *laneException = CUDBG_EXCEPTION_WARP_INVALID_ADDRESS_SPACE;
        HALO_TRACE(1, "Reporting warp invalid address on "
                   "vsm%d/wp%d\n", vsm, wp);
        *error = true;
        return CUDBG_SUCCESS;
        /* Invalid PC Exception */
    case WARP_ERROR_MISALIGNED_PC:
    case WARP_ERROR_PC_OVERFLOW:
    case WARP_ERROR_PC_WRAP:
        *laneException = CUDBG_EXCEPTION_WARP_INVALID_PC;
        HALO_TRACE(1, "Reporting warp invalid PC "
                   "on vsm%d/wp%d\n", vsm, wp);
        *error = true;
        return CUDBG_SUCCESS;
        /* Warp CRS overflow */
    case WARP_ERROR_PHYSICAL_STACK_OVERFLOW:
        *laneException = CUDBG_EXCEPTION_WARP_HARDWARE_STACK_OVERFLOW;
        HALO_TRACE(1, "Reporting warp CRS stack overflow "
                   "on vsm%d/wp%d\n", vsm, wp);
        *error = true;
        return CUDBG_SUCCESS;
        /* Warp illegal address */
    case WARP_ERROR_MMU_FAULT:
        *laneException = CUDBG_EXCEPTION_WARP_ILLEGAL_ADDRESS;
        HALO_TRACE(1, "Reporting warp MMU fault "
                   "on vsm%d/wp%d\n", vsm, wp);
        *error = true;
        return CUDBG_SUCCESS;

        /* Warp  */
        /* Exceptions that aren't reported */
    case WARP_ERROR_TRAP_ON_WARP_EXIT:
    case WARP_ERROR_RET_EMPTY_STACK_ERROR:
    case WARP_ERROR_GEOMETRY_SM_ERROR:
    case WARP_ERROR_DIVERGENT:
    case WARP_ERROR_STATUS_NONE:
        HALO_TRACE(50, "No warp exception was reported "
                   "on vsm%d/wp%d\n", vsm, wp);
        *error = false;
        return CUDBG_SUCCESS;
        /* Unknown Exception */
    default:
        *laneException = CUDBG_EXCEPTION_UNKNOWN;
        HALO_TRACE(1, "Reporting unknown exception "
                   "on vsm%d/wp%d\n", vsm, wp);
        *error = true;
        return CUDBG_SUCCESS;
    }

    return CUDBG_SUCCESS;
}

static inline CUDBGResult
fermi_handleLaneOverflow(CudbgDevice dev,
                         uint32_t vsm, uint32_t wp, uint32_t lane,
                         uint32_t r1, CUDBGException_t *laneException,
                         bool *error)
{
    Grid grid;
    uint64_t pc;
    Breakpoint bp;
    uint64_t pcOfBp;
    uint64_t startOffset;
    uint64_t pcOfAssignment;
    CUDBGResult res;
    uint32_t mcenabled = 0;
    bool doUserStackOverflowCheck = true;
    bool inMemcheckPatch = false;
    bool inUnifiedDebuggerPatch = false;

    CUDBG_VERIFY(error, CUDBG_ERROR_INVALID_ARGS, "Invalid argument in fermi_handleLaneOverflow.\n");

    *error = false;
    pc = dev->smState[vsm].warp[wp].pc;

    /* For Fermi and above, memcheck uses the HALO to read back
       the location of an error, here we can use some interop calls
       to set the lane exception state. This must be checked before
       the user stack overflow as the memcheck patch code clobbers
       R1, and will cause the stack overflow check to fail. */
    res = dev->halo.mcinterop_memcheckEnabled(dev, &mcenabled);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE(10, "Failed to read if memcheck is enabled. Disabling memcheck test.\n");
        mcenabled = 0;
    }

    if (mcenabled) {
        res = dev->haloClient->inMemcheckPatch(dev, pc, &inMemcheckPatch);
        if (res != CUDBG_SUCCESS) {
            HALO_TRACE(10, "Failed to check PC :0x%" PRIx64 " in memcheck patch. Disabling memcheck test\n",
                       pc);
            mcenabled = 0;
        }
    }

    /* If memcheck was enabled and we are inside memcheck patch code, skip the
       userStackOverflow check.
    */
    if (mcenabled && inMemcheckPatch) {
        HALO_TRACE(10, "Found in memcheck patch. Disabling user stack overflow check\n");
        doUserStackOverflowCheck = false;
    } else
       if (mcenabled) {
           DebugPatch dbgPatch = NULL;
           bool inSyscallPatch = false;

           /* Not in a MEMCHECK patch, but could be in another internal tool patch (marked SYSCALL).
              If we are and internal debugging is enabled, disable user stack overflow checks, too. */
           res = dev->haloClient->inSyscallPatch(dev, pc, &dbgPatch, &inSyscallPatch);
           if (res != CUDBG_SUCCESS) {
               HALO_TRACE(10, "Failed to check PC :0x%" PRIx64 " in syscall patch. Disabling memcheck test\n",
                          pc);
               mcenabled = 0;
           } else
               if (inSyscallPatch && dbgPatch && dbgPatch->debug) {
                   HALO_TRACE(10, "Found in syscall patch with internal debugging. Disabling user stack overflow check\n");
                   doUserStackOverflowCheck = false;
               }
       }

    res = dev->haloClient->inUnifiedDebuggerPatch(dev, pc, &inUnifiedDebuggerPatch);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE(10, "Failed call to inUnifiedDebuggerPatch. Setting inUnifiedDebuggerPatch false\n");
        return res;
    }

    if (inUnifiedDebuggerPatch) {
        HALO_TRACE(10, "inUnifiedDebuggerPatch. Skipping stack overflow check.\n");
        doUserStackOverflowCheck = false;
    }

    /* If memcheck is on, and PC is inside a memcheck patch region, skip the R1
       check as memcheck has probably clobbered it
    */
    if (!doUserStackOverflowCheck) {
        HALO_TRACE(10, "Skipping stack check\n");
        return CUDBG_SUCCESS;
    }
    /* Was it a user stack overflow?  (ABI compilations only).  This
       type of exception does not set a value in an ESR since it is
       controlled in software, by the compiler.  So, we need to check
       that the active kernel is using the ABI and that the offending
       lane's R1 has been pushed past its LMEM_HI stack-size boundary.
       We also need to make sure this warp executed a BPT.TRAP, and
       that it has executed at least one instruction (ABI compilations
       set R1 in the first instruction, so R1 is not valid until after
       it is executed). */

    /* Temporary workaround:  The compiler is not guaranteeing that R1
       (the stack pointer) is setup before the kernel begins running
       for non-debug, optimized compilations.  If this happens, then
       we can't rely on R1's value unless we know exactly when R1 is
       assigned.  For now, just see if the first instruction of this
       kernel sets R1 from c[0x1][0x100] (constbank offset to where the
       initial stack pointer value is stored).  If so, then we know we
       can reliably detect a stack overflow.

       In the future, the compiler will be using a crt0-like mechanism
       to assign the stack pointer before the kernel starts running,
       in which case this workaround should be removed. */
    grid = haloStateDeviceGetGrid(dev, dev->smState[vsm].warp[wp].gridId64);
    if (!grid)
        return CUDBG_ERROR_INVALID_GRID;

    if (grid->state == HALO_GRID_STATE_INVISIBLE)
        return CUDBG_SUCCESS;

    /* Only warps that have personally trapped, are not at the kernel
       start offset, are using the ABI, and have a bad value for R1
       are candidates for this check.

       We also need to make sure that the kernel assigns R1 properly.
       We used to ensure this by reading code memory on a per-lane
       basis.  Now, we instead analyze the function when
       gpudbgRegisterFunction() is called during function registration.

       The following 6 conditions must be true for stack overflow:
       1) Module is ABI compliant
       2) We found the addr of the initial stack assignment (spAssignmentAddr)
       3) The pc beyond the initial stack assignment
       4) The pc is not at the function entrypoint
       5) The warp is broken
       6) r1 < lmemHiOff

       Do the inexpensive checks first. Checking the pc requires
       checking for breakpoint matches, so do this last. */

    if (grid->function->module->abiVersion >= ELFOSABIV_ABI &&
        grid->function->spAssignmentAddr != 0 &&
        r1 < dev->smState[vsm].warp[wp].lmemConfig.lmemHiOff &&
        warpBitmaskGetBits(&dev->smState[vsm].state.bptrapmask, wp, 1)) {

        startOffset = grid->function->gpuAddrBase;
        pcOfAssignment = grid->function->spAssignmentAddr - grid->function->virtAddrBase
            + grid->function->gpuAddrBase;

        /* On some architectures the instruction address may need to be adjusted
           to account for OpEx's */
        res = dev->halo.adjustCodeAddress(startOffset, &startOffset, CUDBG_ADJ_CURRENT_ADDRESS);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Could not get adjusted startOffset address\n");
            return res;
        }

        /* Manually "rewind" the pc variable to see if the preceeding instruction
           was a breakpoint. */
        res = dev->halo.adjustCodeAddress(pc, &pcOfBp, CUDBG_ADJ_PREVIOUS_ADDRESS);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Could not get adjusted pc address\n");
            return res;
        }
        res = dev->halo.findBreakpoint(dev->activeContext, pcOfBp, &bp);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Could not find breakpoints\n");
            return res;
        }
        if (bp != NULL)
            pc = pcOfBp;

        /* Check pc to make sure R1 [checked above] was actually valid. */
        if (pc > startOffset && pc > pcOfAssignment) {
            HALO_TRACE(1, "Reporting lane ABI user stack overflow "
                       "on vsm%d/wp%d/ln%d pc 0x%" PRIx64
                       " startOffset 0x%" PRIx64
                       " pcOfAssignment 0x%" PRIx64
                       " r1 0x%x lmemHiOff 0x%x\n",
                       vsm, wp, lane, pc, startOffset, pcOfAssignment,
                       r1, dev->smState[vsm].warp[wp].lmemConfig.lmemHiOff);
            *laneException = CUDBG_EXCEPTION_LANE_USER_STACK_OVERFLOW;
            *error = true;
            return CUDBG_SUCCESS;
        }
    }

    return CUDBG_SUCCESS;
}

/*
 *  Detects if a lane has hit an exception and stores the reason.
 *  Note that gESR and wESR are _not_ the PRI ESR registers, but
 *  the per-lane SRs that are saved off within the trap handler.
 */
CUDBGResult
fermi_setExceptionState(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                        uint32_t gESR, uint32_t wESR)
{
    CUDBGResult res = CUDBG_SUCCESS;
    bool error = false;
    uint32_t r1;
    CUDBGException_t exception = CUDBG_EXCEPTION_NONE;
    uint32_t lane;
    uint32_t laneActive, laneActive1, laneErrors;
    Context context = dev->activeContext;
    uint32_t mcenabled = 0;
    uint32_t magic[32] = {0};

    res = dev->halo.readActiveMask(dev, vsm, wp, &laneActive);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to readActiveMask failed in setExceptionState.\n");
        return res;
    }

    /* Handle exceptions in this order:  (1) Global, (2) Warp, (3) Lane */
    res = dev->halo.handleGlobalErrorState(dev, vsm, wp, gESR, &exception,
                                           &error);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to handleGlobalErrorState failed in setExceptionState.\n");
        return res;
    }
    if (error) {
        HALO_TRACE(1, "Global Error Found, ignoring other errors.\n");
        dev->smState[vsm].state.knownEvent = true;
        dev->smState[vsm].state.foundException = true;

        for (lane = 0; lane < 32; ++lane, laneActive >>= 1) {
            /* Skip lanes that aren't active */
            if (~laneActive & 0x1) {
                continue;
            }
            dev->smState[vsm].warp[wp].laneExceptions[lane] = exception;
        }

        return CUDBG_SUCCESS;
    }

    res = dev->halo.handleWarpErrorState(dev, vsm, wp, wESR, &exception,
                                         &error);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to handleWarpErrorState failed in setExceptionState.\n");
        return res;
    }
    if (error) {
        HALO_TRACE(1, "Warp Error Found, ignoring other errors.\n");
        dev->smState[vsm].state.knownEvent = true;
        dev->smState[vsm].state.foundException = true;

        for (lane = 0; lane < 32; ++lane, laneActive >>= 1) {
            /* Skip lanes that aren't active */
            if (~laneActive & 0x1) {
                continue;
            }
            dev->smState[vsm].warp[wp].laneExceptions[lane] = exception;
        }

        return CUDBG_SUCCESS;
    }

    laneErrors = 0;
    res = fermi_handleWarpSyscallErrorState(dev, vsm, wp, wESR, laneActive, &laneErrors);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Call to handleWarpSyscallErrorState failed in setExceptionState.\n");

    laneActive1 = laneActive;
    for (lane = 0; lane < 32; ++lane, laneActive1 >>= 1, laneErrors >>= 1) {
        /* Skip lanes that aren't active */
        if (~laneActive1 & 0x1) {
            continue;
        }

        if (laneErrors & 0x1) {
            HALO_TRACE(1, "Warp Syscall Error Found, ignoring other errors.\n");
            continue;
        }

        res = dev->halo.scratchpad.read_r1(context->scratchpadAccessor, vsm, wp,
                                           lane, &r1);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read R1\n");

        res = fermi_handleLaneOverflow(dev, vsm, wp, lane, r1, &exception,
                                       &error);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to handleLaneErrorState failed in setExceptionState.\n");
            return res;
        }
        if (error) {
            HALO_TRACE(1, "Lane Error Found, ignoring other errors.\n");
            dev->smState[vsm].state.knownEvent = true;
            dev->smState[vsm].state.foundException = true;

            dev->smState[vsm].warp[wp].laneExceptions[lane] = exception;
        }
    }

    res = dev->halo.mcinterop_memcheckEnabled(dev, &mcenabled);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE(10, "Failed to read if memcheck is enabled. Disabling memcheck test.\n");
        mcenabled = 0;
    }

    if (mcenabled &&
        warpBitmaskGetBits(&dev->smState[vsm].state.brokenwarps, wp, 1)) {
        res = dev->halo.readLocalMemory(dev, vsm, wp,
                                        HALO_LOCAL_MEMORY_ACCESS_FOR_ALL_LANES,
                                        dev->halo.deviceInfo.lmemHiMemcheckScratch +
                                        dev->halo.deviceInfo.lmemMemcheckMagic,
                                        magic, sizeof magic);
        CUDBG_VERIFY((res == CUDBG_SUCCESS), res,
                     "Call to readLocalMemory failed in fermi_setExceptionState.\n");

        for (lane = 0; lane < 32; ++lane, laneActive >>= 1) {
            /* Skip lanes that aren't active or have an exception */
            if ((~laneActive & 0x1) ||
                dev->smState[vsm].warp[wp].laneExceptions[lane]) {
                continue;
            }

            res = dev->halo.mcinterop_checkLane(dev, vsm, wp, lane, magic[lane],
                                                &exception);
            CUDBG_VERIFY((res == CUDBG_SUCCESS), res,
                         "MCinterop call to checkLane failed\n");

            if (exception) {
                HALO_TRACE(1, "Reporting memcheck detected exception "
                           "on vsm%d/wp%d/ln%d. Type:%u\n",
                           vsm, wp, lane, exception);

                dev->smState[vsm].state.knownEvent = true;
                dev->smState[vsm].state.foundException = true;

                dev->smState[vsm].warp[wp].laneExceptions[lane] = exception;
            }
        }
    }

#ifndef RELEASE
    if(!exception) {
        HALO_TRACE(50, "No exceptions found.\n");
    }
#endif
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_readWarpErrors(CudbgDevice dev, uint32_t vsm, uint32_t wp)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t globalErrorStatus, warpErrorStatus;
    Context context = dev->activeContext;

    res = dev->halo.scratchpad.read_globalErrorStatus(context->scratchpadAccessor, vsm, wp, &globalErrorStatus);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read global error status\n");

    res = dev->halo.scratchpad.read_warpErrorStatus(context->scratchpadAccessor, vsm, wp, &warpErrorStatus);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read warp error status\n");

    HALO_TRACE(10, "VSM%d/WP%d -> Global ESR: 0x%08x\n", vsm, wp, globalErrorStatus);
    HALO_TRACE(10, "VSM%d/WP%d -> Warp ESR:   0x%08x\n", vsm, wp, warpErrorStatus);

    res = fermi_setExceptionState(dev, vsm, wp, globalErrorStatus,
                                  warpErrorStatus);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Error when setting exception state in fermi_readWarpErrors.\n");
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_read_warpParams(CudbgDevice dev,
                      uint32_t vsm,
                      uint32_t wp,
                      uint32_t valid,
                      uint32_t *virtCTAID,
                      uint32_t *CTASharedSize,
                      uint32_t *floorsweptSmId)
{
    /* Scratchpad data for each warp */
    Context context = dev->activeContext;
    CUDBGResult res = CUDBG_SUCCESS;

    /* If this warp is not valid, do not perform the unmappings */
    if (!valid) {
        HALO_TRACE_FUNCTION(10, "Warp is not valid, returning early.\n");
        return CUDBG_SUCCESS;
    }

    /* If no active context, there is nothing to do. */
    if (!context) {
        HALO_TRACE_FUNCTION(10, "No active context, returning early.\n");
        return CUDBG_SUCCESS;
    }

    res = dev->halo.scratchpad.read_smIds(context->scratchpadAccessor, vsm, wp, virtCTAID, floorsweptSmId);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read SM ids\n");

    res = dev->halo.scratchpad.read_CTASharedSize(context->scratchpadAccessor, vsm, wp, CTASharedSize);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read CTA shared size\n");

    /* Check that we have a grid -- if not, dynamically build a grid structure. */
    res = haloCreateDynamicGrid(dev, vsm, wp);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Could not dynamically create grid!\n");

    /* Check this warp for errors */
    return fermi_readWarpErrors(dev, vsm, wp);
}

static CUDBGResult
fermi_cyaSkipIdleWarpDetection(CudbgDevice dev, uint32_t vsm)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t regOffset = 0;
    uint32_t v;

    res = dev->halo.getPRIOffset(dev, HALO_PRI_SM_DBGR_CONTROL0, vsm,
                                 &regOffset);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Read DBGR_CONTROL0 */
    res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                     (char *)(uintptr_t)regOffset, &v);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Do not detect idle warps anymore, a CYA to allow trap handler entry */
    v = SETFIELD32(v, NV_PGRAPH_PRI_GPCS_TPCS_SM_DBGR_CONTROL0_SKIP_IDLE_WARP_DETECT, 1);
    res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                      (char *)(uintptr_t)regOffset, &v);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Set the stop trigger again */
    v = SETFIELD32(v, NV_PGRAPH_PRI_GPCS_TPCS_SM_DBGR_CONTROL0_STOP_TRIGGER, 1);
    res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                      (char *)(uintptr_t)regOffset, &v);
    if (res != CUDBG_SUCCESS)
        return res;

    return res;
}

#define SM_IN_TRAP_MODE NV_PGRAPH_PRI_GPCS_TPCS_SM_DBGR_STATUS0_SM_IN_TRAP_MODE

CUDBGResult
fermi_waitForSMPause(CudbgDevice dev, uint32_t vsm)
{
    CUwarpBitmask tidValid = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;
    CUwarpBitmask bpmask = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;
    uint32_t smStatus;
    uint32_t smStatusAddr = 0;
    uint32_t elapsedTime;
    static const uint32_t timeout        = 5000000; // 5.00 seconds
    static const uint32_t printThreshold = 4990000; // 4.99 seconds => 20 printfs
    static const uint32_t sleepTime      = 500;
    bool skipIdleWarpDetectionAttempted  = false;
    CUDBGResult res = CUDBG_SUCCESS;

    /* Setup addresses */
    res = dev->halo.getPRIOffset(dev, HALO_PRI_SM_DBGR_STATUS0, vsm,
                                 &smStatusAddr);
    if (res != CUDBG_SUCCESS)
        return res;

    /* First, wait for _this_ SM to indicate it is in trap handler mode,
     * this way we can be sure that the tidValid mask is correct. */
    for (elapsedTime = 0; elapsedTime < timeout; elapsedTime += sleepTime) {
        res = dev->halo.readWarpMaskPRI(dev, vsm, HALO_REG_OP_TYPE_GLOBAL,
                                        HALO_MASK_PRI_WARP_VALID, &tidValid);
        if (res != CUDBG_SUCCESS)
            return res;

        res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                         (char *)(uintptr_t)smStatusAddr,
                                         &smStatus);
        if (res != CUDBG_SUCCESS)
            return res;

        if (!warpBitmaskAny(&tidValid) || GETFIELD32(smStatus, SM_IN_TRAP_MODE))
            break;

        /* Temporary. We do not want printfs in libcuda.so, even less in release builds. */
        if (elapsedTime > printThreshold && !skipIdleWarpDetectionAttempted) {
            HALO_ERROR("BUG 814022 investigation: %7u tidValid=" CU_WARP_BIT_MASK_FMT_128_STR " smStatus=%x\n",
                       elapsedTime, CU_WARP_BIT_MASK_FMT_128_VAL(&tidValid),
                       smStatus);

            /* Attempt to force trap handler entry by skipping idle warp detection */
            res = fermi_cyaSkipIdleWarpDetection(dev, vsm);
            if (res != CUDBG_SUCCESS)
                return res;

            /* Reset time to zero to force another attempt */
            elapsedTime = 0;

            /* Indicate we've already tried to skip idle warp detection */
            skipIdleWarpDetectionAttempted = true;
        }

#if cuosOsIsLinux() || cuosOsIsApple()
        /* Give some time for the device to catch up */
        usleep(sleepTime);
#endif
    }

    CUDBG_VERIFY((elapsedTime < timeout), CUDBG_ERROR_INTERNAL, "Timeout when waiting for SM pause.\n");

    /* Shortcut */
    if (!warpBitmaskAny(&tidValid))
        return CUDBG_SUCCESS;

    /* Now, wait for all valids warps on this SM to indicate they are paused */
    for (elapsedTime = 0; elapsedTime < timeout; elapsedTime += sleepTime) {
        res = dev->halo.readWarpMaskPRI(dev, vsm, HALO_REG_OP_TYPE_GLOBAL,
                                        HALO_MASK_PRI_WARP_VALID, &tidValid);
        if (res != CUDBG_SUCCESS)
            return res;

        res = dev->halo.readWarpMaskPRI(dev, vsm, HALO_REG_OP_TYPE_GLOBAL,
                                        HALO_MASK_PRI_BPT_PAUSE, &bpmask);
        if (res != CUDBG_SUCCESS)
            return res;

        if (warpBitmaskEqual(&bpmask, &tidValid))
            break;

        /* Temporary. We do not want printfs in libcuda.so, even less in release builds. */
        if (elapsedTime > printThreshold)
            HALO_ERROR("BUG 814022 investigation: %7u tidValid=" CU_WARP_BIT_MASK_FMT_128_STR " bpmask=" CU_WARP_BIT_MASK_FMT_128_STR "\n",
                       elapsedTime, CU_WARP_BIT_MASK_FMT_128_VAL(&tidValid),
                       CU_WARP_BIT_MASK_FMT_128_VAL(&bpmask));

#if cuosOsIsLinux() || cuosOsIsApple()
        /* Give some time for the device to catch up */
        usleep(sleepTime);
#endif
    }

    CUDBG_VERIFY((elapsedTime < timeout), CUDBG_ERROR_INTERNAL, "Timeout when waiting for SM pause.\n");

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_waitForDevicePause(CudbgDevice dev)
{
    uint32_t vsm;
    CUDBGResult res;

    for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
        res = dev->halo.waitForSMPause(dev, vsm);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to waitForSMPause failed in waitForDevicePause.\n");
            return res;
        }
    }

    return CUDBG_SUCCESS;
}

static int32_t
fermi_isCall(CudbgDevice dev, uint64_t instruction)
{
    /* Fermi:  CALL Instruction Masks */
    const uint64_t FERMI_CALL_OP_MASK = 0xf10000000000000fULL;
    const uint64_t FERMI_CALL_OP      = 0x5000000000000007ULL;

    if ((instruction & FERMI_CALL_OP_MASK) == FERMI_CALL_OP)
        return 1;
    else
        return 0;

}

static int32_t
fermi_isBarrier(CudbgDevice dev, uint64_t instruction)
{
    /* Fermi:  Full BAR instruction */
    const uint64_t FERMI_BAR_OP_MASK = 0xfc0000000000000fULL;
    const uint64_t FERMI_BAR_OP      = 0x5000000000000004ULL;

    if ((instruction & FERMI_BAR_OP_MASK) == FERMI_BAR_OP)
        return 1;
    else
        return 0;
}

static int32_t
fermi_isNop(CudbgDevice dev, uint64_t instruction)
{
    /* Fermi:  Full NOP instruction */
    const uint64_t FERMI_NOP = 0x4000000000000004ULL;

    if (instruction == FERMI_NOP)
        return 1;
    else
        return 0;
}

static int32_t
fermi_isExit(CudbgDevice dev, uint64_t instruction)
{
    /* Fermi:  EXIT Instruction Masks */
    const uint64_t FERMI_EXIT_OP_MASK = 0xf80000000000000fULL;
    const uint64_t FERMI_EXIT_OP      = 0x8000000000000007ULL;

    if ((instruction & FERMI_EXIT_OP_MASK) == FERMI_EXIT_OP)
        return 1;
    else
        return 0;
}

static int32_t
fermi_isRet(CudbgDevice dev, uint64_t instruction)
{
    /* Fermi:  RET Instruction Masks */
    const uint64_t FERMI_RET_OP_MASK = 0xf80000000000000fULL;
    const uint64_t FERMI_RET_OP      = 0x9000000000000007ULL;

    if ((instruction & FERMI_RET_OP_MASK) == FERMI_RET_OP)
        return 1;
    else
        return 0;
}

static CUDBGResult
fermi_isTerminalInstructionAtPC(Context ctx, uint64_t pc, bool *isExitingInstruction)
{
    uint64_t inst;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(ctx && isExitingInstruction, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    res = ctx->dev->halo.readCodeMemory(ctx, pc, &inst, sizeof inst);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Error reading pc %#" PRIx64 "\n", inst);

    *isExitingInstruction = fermi_isExit(ctx->dev, inst) || fermi_isRet(ctx->dev, inst);

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_isLastHwStepSynchronous(CudbgDevice dev, bool *isLastHwStepSynchronous)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(dev && isLastHwStepSynchronous,
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments in fermi_isLastHwStepSynchronous.\n");

    /* Fermi HW does not support sending an interrupt (HWW Pulse)
       upon single-stepping the last resident warp on an SM to
       completion (over an exit point). */
    *isLastHwStepSynchronous = false;

    return res;
}

/* Returns true in *isSteppable if the instruction at PC can be stepped,
   false otherwise. If not steppable, *breakAddr will contain the PC
   address where to insert a breakpoint to step that instruction, and
   *breakMask will contain the mask of warps to resume (low bit means
   resume). Otherwise, *breakAddr and *breakMask are untouched. */
CUDBGResult
fermi_isSteppable(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                  uint64_t pc, bool inPatch, uint64_t *breakAddr,
                  CUwarpBitmask *breakMask, bool *isSteppable,
                  bool *requiresExitStep)
{
    CUDBGResult res = CUDBG_SUCCESS;
    Grid grid;
    uint64_t inst;
    CUwarpBitmask validWarps;
    uint32_t anActiveLn, call_depth;
    bool isLastHwStepSynchronous;

    CUDBG_VERIFY((breakAddr && breakMask && isSteppable && requiresExitStep),
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments in fermi_isSteppable.\n");

    CUDBG_VERIFY(warpBitmaskGetBits(&dev->smState[vsm].state.tidValid, wp, 1),
                 CUDBG_ERROR_INVALID_WARP,
                 "Invalid warp in fermi_isSteppable.\n");

    /* Initialize default behavior */
    *breakAddr        = ~0U;
    warpBitmaskFill(breakMask, 1);
    *isSteppable      = true;
    *requiresExitStep = false;

    res = dev->halo.readCodeMemory(dev->activeContext, pc, &inst, sizeof inst);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read memory from offset 0x%08x\n", pc);
        return res;
    }

    res = haloFindAnActiveLane(dev, vsm, wp, &anActiveLn);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to find an active lane in warp %u (res=%d)\n", wp, res);
    }

    /* Read the call depth for this lane (used for determining EXIT handling) */
    res = dev->halo.readCallDepth(dev, vsm, wp, anActiveLn, &call_depth);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read call depth (res=%d)\n", res);
        return res;
    }

    /* Fermi HW has a nasty bug -- HW single step does not notify the CPU
       (HWW pulse) when the *last* resident warp on an SM is stepped over
       an EXIT/RET instruction. Special handling is required, so set the
       'requiresExitStep' variable to true. */
    res = dev->halo.isLastHwStepSynchronous(dev, &isLastHwStepSynchronous);
    if (res!= CUDBG_SUCCESS) {
        HALO_ERROR("Failed to determine stepping properties (res=%d)\n", res);
        return res;
    }

    warpBitmaskAssign(&validWarps, &dev->smState[vsm].state.tidValid);
    if (!isLastHwStepSynchronous &&
        (fermi_isExit(dev, inst) || (fermi_isRet(dev, inst) && !call_depth))  &&
        warpBitmaskHasOneBitSet(&validWarps)) {
        HALO_TRACE_FUNCTION(2, "  Found an EXIT (requires special handling) at pc = %x\n", pc);
        *isSteppable = true;
        *requiresExitStep = true;
        return CUDBG_SUCCESS;
    }

    grid = haloStateDeviceGetGrid(dev, dev->smState[vsm].warp[wp].gridId64);
    CUDBG_VERIFY(grid && grid->function && grid->function->module,
                 CUDBG_ERROR_INTERNAL,
                 "Invalid grid\n");

    if (grid->function->module->abiVersion < ELFOSABIV_ABI && fermi_isCall(dev, inst)) {
        HALO_TRACE(2, "  Found an unsteppable call at pc = %x\n", pc);
        warpBitmaskFill(breakMask, 1);
        warpBitmaskSetBits(breakMask, wp, 1, 0);
        *breakAddr = pc + 8;
        *isSteppable = false;
        return CUDBG_SUCCESS;
    }

    if (fermi_isBarrier(dev, inst)) {
        uint32_t tmpWp;
        HALO_TRACE(2, "  Found an unsteppable barrier at pc = %x\n", pc);
        /* Need to resume all warps in the same cta as this warp */
        warpBitmaskFill(breakMask, 1);
        warpBitmaskSetBits(breakMask, wp, 1, 0);
        for (tmpWp = 0; tmpWp < dev->halo.deviceInfo.numWarpsPrSM; ++tmpWp)
            if (haloWarpsInSameCTA(dev, vsm, wp, tmpWp))
                warpBitmaskSetBits(breakMask, tmpWp, 1, 0);
        *breakAddr = pc + 8;
        *isSteppable = false;
        return CUDBG_SUCCESS;
    }

    *isSteppable = true;
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_isInternalInstructionAtPC(CudbgDevice dev, uint64_t inst, uint64_t gpuAddr,
                                bool *isInternalInstruction)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(isInternalInstruction, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args in fermi_isInternalInstructionAtPC\n");

    /* Initialize to false (not an internal instruction) */
    *isInternalInstruction = false;

    return res;
}

static CUDBGResult
fermi_suspendSM(CudbgDevice dev, uint32_t vsm)
{
    CUDBGResult res;

    res = fermi_suspendTPC(dev, vsm);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to suspendTPC failed in suspendSM.\n");
        return res;
    }

    /* Ensure that the subsequent loads are not reordered to before this point */
    cuosLoadFence();

    /* Now, wait for this SM to meet the condition:  paused == valid */
    res = dev->halo.waitForSMPause(dev, vsm);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to waitForSMPause failed in suspendSM.\n");
        return res;
    }

    res = haloSetRmDebugMode(dev, true);
    if (res != CUDBG_SUCCESS)
        HALO_TRACE(20, "Call to haloSetRmDebugMode failed in suspendSM.\n");

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_resumeSM(CudbgDevice dev, uint32_t vsm)
{
    CUDBGResult res;

    if (dev->codeIsDirty)
        dev->halo.invalidateICache(dev);
    dev->codeIsDirty = 0;

    dev->halo.clearExceptions(dev, vsm);

    /* Ensure all CPU stores are visible to GPU at this point */
    cuosStoreFence();

    res = fermi_resumeTPC(dev, vsm);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to fermi_resumeTPC failed in resumeSM.\n");
        return res;
    }

    res = haloSetRmDebugMode(dev, false);
    if (res != CUDBG_SUCCESS)
        HALO_TRACE(20, "Call to haloSetRmDebugMode failed in resumeSM.\n");

    return CUDBG_SUCCESS;
}

/* The non-debug obj way of suspending the device */
static CUDBGResult
fermi_suspendDeviceViaPRIV(CudbgDevice dev, uint32_t *hasStopped, uint32_t *waitForEvent, Context *residentContext)
{
    CUDBGResult res, resTemp;
    uint32_t regVal;
    uint32_t dbgMode = 0;
    uint32_t regOffset = 0;

    /* Supending/resuming context switching can fail if no valid context exists */
    res = dev->dmal->debugObjectPauseGrCtxSwitch(dev);
    if (res != CUDBG_SUCCESS && res != CUDBG_ERROR_INVALID_CONTEXT) {
        HALO_ERROR("Could not suspend context switching!\n");
        return res;
    }

    res = haloAnyDbgCtxResident(dev, residentContext);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Could not determine current resident context!\n");
        goto error;
    }

    /* Check if any context we care about is resident */
    if (*residentContext) {
        res = dev->halo.getPRIOffset(dev, HALO_PRI_SM_DBGR_CONTROL0, 0,
                                     &regOffset);
        if (res != CUDBG_SUCCESS)
            return res;

        /* Uniformity assumption: Read the register on one SM and broadcast it. */
        res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                         (char *)(uintptr_t)regOffset,
                                         &regVal);
        if (res != CUDBG_SUCCESS)
            goto error;

        dbgMode = GETFIELD32(regVal, NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_CONTROL0_DEBUGGER_MODE);
    }

    if (!*residentContext || !dbgMode) {
        /* Bug 825163 - OGL interop exposed this - We can only suspend
           and subsquently wait for the paused == valid condition if
           the resident context is in debug mode.
           Do not re-enable ctx switching though. */
        HALO_TRACE(10, "This context is unknown (residentCtx=%p,dbgMode=%d), skip suspend!\n",
                   *residentContext, dbgMode);
        *hasStopped = 1;
        return CUDBG_ERROR_INVALID_CONTEXT;
    }

    res = dev->halo.getPRIOffset(dev, HALO_PRI_SM_DBGR_CONTROL0, -1,
                                 &regOffset);
    if (res != CUDBG_SUCCESS)
        return res;

    /* SUSPENDING:  It is only necessary to set the stop trigger to 1
       Do the final *BROADCAST* write to CONTROL0 */
    regVal = SETFIELD32(regVal, NV_PGRAPH_PRI_GPCS_TPCS_SM_DBGR_CONTROL0_STOP_TRIGGER, 1);
    res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                      (char *)(uintptr_t)regOffset,
                                      &regVal);
    if (res != CUDBG_SUCCESS)
        goto error;

    /* Now, wait for _all_ SMs to meet the condition:  paused == valid */
    res = fermi_waitForDevicePause(dev);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to waitForDevicePause failed in suspendDevice.\n");
        goto error;
    }

error:
    /* Supending/resuming context switching can fail if no valid context exists */
    resTemp = dev->dmal->debugObjectResumeGrCtxSwitch(dev);
    if (resTemp != CUDBG_SUCCESS && resTemp != CUDBG_ERROR_INVALID_CONTEXT)
        HALO_ERROR("Could not resume context switching!\n");

    return res;
}

CUDBGResult
fermi_suspendDevice(CudbgDevice dev, uint32_t *hasStopped, uint32_t *waitForEvent, Context *residentContext)
{
    CUDBGResult res;

    *hasStopped = 0;
    *waitForEvent = 0;
    *residentContext = NULL;

    if (dev->dmal->debugObjectCanSuspend())
        res = dev->dmal->debugObjectSuspendDevice(dev, hasStopped, waitForEvent, residentContext);
    else
        res = fermi_suspendDeviceViaPRIV(dev, hasStopped, waitForEvent, residentContext);

    /* Ensure that the subsequent loads happen are not reordered to
       before this point */
    cuosLoadFence();

    if (res != CUDBG_SUCCESS)
        return res;

    *hasStopped = 1;

    /* Under CILP, there is no need to set RM debug mode.
       This should be merged into the callsite */
    if (dev->halo.deviceInfo.preemptionType != HALO_PREEMPTION_TYPE_CILP) {
        res = haloSetRmDebugMode(dev, true);
        if (res != CUDBG_SUCCESS)
            HALO_TRACE(20, "Call to haloSetRmDebugMode failed in suspendDevice.\n");
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_resumeDeviceViaPRIV(CudbgDevice dev, uint32_t *hasResumed)
{
    CUDBGResult res, resTemp;
    uint32_t regVal;
    uint32_t dbgMode = 0;
    Context residentContext = NULL;
    uint32_t regOffset = 0;

    res = haloAnyDbgCtxResident(dev, &residentContext);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Could not determine current resident context!\n");
        goto error;
    }

    /* Check if any context we care about is resident */
    if (residentContext) {
        res = dev->halo.getPRIOffset(dev, HALO_PRI_SM_DBGR_CONTROL0, 0,
                                     &regOffset);
        if (res != CUDBG_SUCCESS)
            return res;

        /* Uniformity assumption: Read the register on one SM and broadcast it. */
        res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                         (char *)(uintptr_t)regOffset,
                                         &regVal);
        if (res != CUDBG_SUCCESS)
            goto error;

        dbgMode = GETFIELD32(regVal, NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_CONTROL0_DEBUGGER_MODE);
    }

    if (!residentContext || !dbgMode) {
        /* Bug 825163 - OGL interop support. If debug mode isn't on, this
           context would not have been suspended, so don't resume it either.
           Just re-enable context switching and return. */
        HALO_TRACE(10, "This context is unknown (residentContext=%p,dbgMode=%d), skip resume!\n",
                   residentContext, dbgMode);
        *hasResumed = 1;
        res = CUDBG_SUCCESS;
        goto error;
    }

    /* The following requires some clarification.  Despite the fact
     * that both RUN_TRIGGER and STOP_TRIGGER have the word "TRIGGER"
     * in their names, only one is actually a trigger, and that is
     * the STOP_TRIGGER.  Only writing a 1 to the RUN_TRIGGER is not
     * sufficient to resume the gpu - the stop trigger must explicitly
     * be set to 0 as well. */

    /* RESUMING:  Advice from the arch group:  Set the stop trigger
     * first as a separate operation to ensure that the trigger has
     * taken effect before setting the "run trigger." */

    res = dev->halo.getPRIOffset(dev, HALO_PRI_SM_DBGR_CONTROL0, -1,
                                 &regOffset);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Set the stop trigger to 0 */
    regVal = SETFIELD32(regVal, NV_PGRAPH_PRI_GPCS_TPCS_SM_DBGR_CONTROL0_STOP_TRIGGER, 0);

    /* BROADCAST write */
    res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                      (char *)(uintptr_t)regOffset,
                                      &regVal);
    if (res != CUDBG_SUCCESS)
        goto error;

    /* Now, set the run trigger to 1 */
    regVal = SETFIELD32(regVal, NV_PGRAPH_PRI_GPCS_TPCS_SM_DBGR_CONTROL0_RUN_TRIGGER, 1);

    /* Do the final *BROADCAST* write to CONTROL0 */
    res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                      (char *)(uintptr_t)regOffset,
                                      &regVal);
    if (res != CUDBG_SUCCESS)
        goto error;

error:

    /* Supending/resuming context switching can fail if no valid context exists */
    resTemp = dev->dmal->debugObjectResumeGrCtxSwitch(dev);
    if (resTemp != CUDBG_SUCCESS && resTemp != CUDBG_ERROR_INVALID_CONTEXT) {
        HALO_ERROR("Could not resume context switching!\n");
        /* Only return this error if there wasn't a previous one */
        if (res == CUDBG_SUCCESS)
            res = resTemp;
    }

    return res;
}

static CUDBGResult
fermi_resumeDevice(CudbgDevice dev, uint32_t *hasResumed, uint32_t skipResume)
{
    CUDBGResult res, resTemp;

    *hasResumed = 0;

    if (dev->codeIsDirty)
        dev->halo.invalidateICache(dev);
    dev->codeIsDirty = 0;

    dev->halo.clearExceptions(dev, -1);

    /* Ensure all CPU stores are visible to GPU at this point */
    cuosStoreFence();

    if (!skipResume) {
        if (dev->dmal->debugObjectCanResume())
            res = dev->dmal->debugObjectResumeDevice(dev, hasResumed);
        else
            res = dev->halo.resumeDeviceViaPRIV(dev, hasResumed);
    }

    *hasResumed = 1;

    if (dev->halo.deviceInfo.preemptionType != HALO_PREEMPTION_TYPE_CILP) {
        /* The previous function call might have failed, so preserve the
           return value. */
        resTemp = haloSetRmDebugMode(dev, false);
        if (resTemp != CUDBG_SUCCESS) {
            HALO_TRACE(20, "Call to haloSetRmDebugMode failed in resumeDevice.\n");
            /* Only return this error if there wasn't a previous one */
            if (res == CUDBG_SUCCESS)
                res = resTemp;
        }
    }

    return res;
}

static CUDBGResult
fermi_setDebuggingModeMMU(Context ctx, uint32_t on)
{
    uint32_t v;
    CudbgDevice dev;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_ARGS, "Invalid context\n");
    dev = ctx->dev;

    /* Set MMU debug mode for all GPCs.

       RM sets NV_PGRAPH_PRI_GPCS_MMU_DEBUG_{RD,WR} to set a dummy
       page that is used for all invalid reads/writes, which
       will prevent state corruption (Bug 655252 tracks this, the
       code lives in kernel/gr/fermi/grgf100.c in the resman tree). */
    res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GLOBAL, dev->bar0 + NV_PGRAPH_PRI_GPCS_MMU_DEBUG_CTRL, &v);
    if (res != CUDBG_SUCCESS)
        return res;
    v = SETFIELD32(v, NV_PGRAPH_PRI_GPCS_MMU_DEBUG_CTRL_DEBUG, on);
    res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GLOBAL, dev->bar0 + NV_PGRAPH_PRI_GPCS_MMU_DEBUG_CTRL, &v);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Now, workaround Bug 635263.  SM is not guaranteed to be forced into the
       trap handler on GF100 upon L1 MMU errors unless we disable stall and
       quiescent clock gating.  So when turning debug mode on, we set these
       fields to 0, and restore them when turning debug mode off. */
    if (dev->dmal->profilerObjectCanClockGate()) {
        /* Disable BLCG and acquire the reference if we're enabling MMU debug mode */
        res = dev->dmal->profilerObjectSetBLCG(dev, !on, on);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to set clock gating for MMU debug mode!\n");
            return res;
        }
    }
    else {
        /* SM_CG is being removed from the whitelist and will not be available to user mode drivers */
        res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GLOBAL, dev->bar0 + NV_PGRAPH_PRI_GPCS_TPCS_SM_CG, &v);
        if (res != CUDBG_SUCCESS)
            return res;
        v = SETFIELD32(v, NV_PGRAPH_PRI_GPCS_TPCS_SM_CG_STALL_CG_EN, !on);
        v = SETFIELD32(v, NV_PGRAPH_PRI_GPCS_TPCS_SM_CG_QUIESCENT_CG_EN, !on);
        res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GLOBAL, dev->bar0 + NV_PGRAPH_PRI_GPCS_TPCS_SM_CG, &v);
        if (res != CUDBG_SUCCESS)
            return res;
    }

    /* Bug 814022 - Setting SUBTILE_HOLD to 0 may help hangs with kernels with
       textures. This is not verified but we do not think it may hurt. */
    res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GLOBAL, dev->bar0 + NV_PGRAPH_PRI_GPCS_TPCS_SM_SCH_SCHED_CONTROL, &v);
    if (res != CUDBG_SUCCESS)
        return res;
    v = SETFIELD32(v, NV_PGRAPH_PRI_GPCS_TPCS_SM_SCH_SCHED_CONTROL_SUBTILE_HOLD, !on);
    res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GLOBAL, dev->bar0 + NV_PGRAPH_PRI_GPCS_TPCS_SM_SCH_SCHED_CONTROL, &v);
    if (res != CUDBG_SUCCESS)
        return res;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_enableMMUDebuggingMode(Context ctx)
{
    return fermi_setDebuggingModeMMU(ctx, 1);
}

static CUDBGResult
fermi_disableMMUDebuggingMode(Context ctx)
{
    return fermi_setDebuggingModeMMU(ctx, 0);
}

static CUDBGResult
fermi_stub_disableMMUDebuggingModeForDevice(CudbgDevice dev)
{
    CUDBG_ERROR("Unsupported function\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_fillRangeWithInstruction(Context ctx, uint64_t startvaddr, uint64_t endvaddr, uint64_t inst)
{
    const uint64_t FORCE_TERMINATION_BUFFER_SIZE = 1<<20;
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t bufSize = MIN(endvaddr - startvaddr, FORCE_TERMINATION_BUFFER_SIZE);
    uint64_t i = 0, writeSize = 0;
    uint64_t *buf = (uint64_t *)malloc((size_t)bufSize);

    CUDBG_VERIFY(buf, CUDBG_ERROR_INTERNAL, "Unable to allocate buffer space\n");

    for (i = 0; i < bufSize / sizeof(inst); i++)
        buf[i] = inst;   /* Fill the buffer with our instruction */

    for (; startvaddr < endvaddr; startvaddr+=writeSize) {
        writeSize = MIN(endvaddr - startvaddr, bufSize);

        res = ctx->dev->halo.writeCodeMemory(ctx, startvaddr - ctx->funcMemBaseVA,
                                             buf, (uint32_t)writeSize);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("failed to write memory at offset 0x%#" PRIx64 "\n", startvaddr);
            break;
        }
    }

    free(buf);
    return res;
}

typedef struct forceTerminationData_st forceTerminationData;

struct forceTerminationData_st {
    uint64_t thStartOffset;
    uint64_t thEndOffset;
    Context context;
};

static CUDBGResult
forceTerminationFunctor(haloMemoryMap *map,
                        haloMemorySegment *seg,
                        void *data)
{
    forceTerminationData *d = (forceTerminationData *)data;
    const uint64_t exit_inst = 0x8000000000001de7ULL;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(map && seg && d, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args\n");

    if (seg->type != HALO_MEM_SEG_FUNC)
        return CUDBG_SUCCESS;

    /* Fill everything with exit_inst */
    res = d->context->dev->halo.fillRangeWithInstruction(d->context,
                                                         seg->devvaddr,
                                                         (seg->devvaddr + seg->size),
                                                         exit_inst);

    return res;
}

static CUDBGResult
fermi_forceTermination(CudbgDevice dev)
{
    CUDBGResult res;
    forceTerminationData data = {0};

    /* If there is no active context or if we never launched any
       kernel for that context, there is nothing to do. */
    if (!dev->activeContext  || !haloStateContextIsActive(dev->activeContext))
        return CUDBG_SUCCESS;

    /* TH Code Segment Start/End Offsets */
    data.thStartOffset = dev->activeContext->thCodeVA;
    data.thEndOffset   = data.thStartOffset + dev->activeContext->thCodeSize;
    data.context       = dev->activeContext;

    res = haloMemoryMapApplyFunctor(dev->activeContext->memMap,
                                    forceTerminationFunctor,
                                    &data);

    return res;
}

static CUDBGResult
fermi_thServiceWriteInfo(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                         uint32_t addr, uint32_t sz, HaloThService_t reason)
{
    uint32_t validLanes = dev->smState[vsm].warp[wp].validLanes;
    uint32_t vOffset, lane, numValidLanes = 0;
    Context context = dev->activeContext;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY((context && context->memMapActive), CUDBG_ERROR_INVALID_CONTEXT, "Invalid context.\n");

    /* Find out the number of valid lanes - this is calculated here, since
       the trap handler has no simple way of knowing this without doing so.
       Valid lanes in the mask are contiguous from right to left. */
    for (lane = 0; lane < 32; lane++) {
        if (validLanes & (1U << lane))
            numValidLanes++;
    }

    /* Iterate over all validLanes, and write service info to each lane's LMEM_HI */
    for (lane = 0; lane < numValidLanes; ++lane) {

        vOffset = FERMI_LMEM_ABI_HI(vsm, wp) - FERMI_LMEM_ABI_TH_SERVICE_REASON;
        res = dev->halo.writeLocalMemory(dev, vsm, wp, lane, vOffset, &reason, sizeof reason);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to write lmem th service reason in thServiceWriteInfo.\n");
            return res;
        }

        vOffset = FERMI_LMEM_ABI_HI(vsm, wp) - FERMI_LMEM_ABI_TH_SERVICE_NUM_LANES;
        res = dev->halo.writeLocalMemory(dev, vsm, wp, lane, vOffset, &numValidLanes, sizeof numValidLanes);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to write lmem th service num lanes in thServiceWriteInfo.\n");
            return res;
        }

        vOffset = FERMI_LMEM_ABI_HI(vsm, wp) - FERMI_LMEM_ABI_TH_SERVICE_ADDR;
        res = dev->halo.writeLocalMemory(dev, vsm, wp, lane, vOffset, &addr, sizeof addr);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to write lmem th service addr in thServiceWriteInfo.\n");
            return res;
        }

        vOffset = FERMI_LMEM_ABI_HI(vsm, wp) - FERMI_LMEM_ABI_TH_SERVICE_SIZE;
        res = dev->halo.writeLocalMemory(dev, vsm, wp, lane, vOffset, &sz, sizeof sz);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to write lmem th service sz in thServiceWriteInfo.\n");
            return res;
        }
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_readLaneServiceReason(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                            uint32_t ln, uint32_t *serviceReason)
{
    return dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                     FERMI_LMEM_ABI_HI(vsm, wp) -
                                     FERMI_LMEM_ABI_TH_SERVICE_REASON,
                                     serviceReason,
                                     sizeof(*serviceReason));
}

static CUDBGResult
fermi_thService(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                uint32_t addr, uint32_t sz, HaloThService_t reason)
{
    CUDBGResult res;
    uint32_t laneServiceReason;
    uint32_t sleepInterval = 500;
    uint32_t timeOut = 5000000; /* Half a second */
    uint32_t timeElapsed = 0;
    CUwarpBitmask bpMask;

    /* We use the trap handler to our advantage here.  We will
       resume the warp (wp) from being paused, and make it do
       some work, depending on a reason code.  After that, it
       will go back to being paused.

       Write the following to reserved space in LMEM_HI:
         - Reason code
         - Start offset of memory offset to read
         - Size of memory to read
         - # of active lanes in this warp */
    res = dev->halo.thServiceWriteInfo(dev, vsm, wp, addr, sz, reason);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to thServiceWriteInfo failed in thService.\n");
        return res;
    }

    /* Issue a resume, and wait for paused == valid.  We
       purposely avoid re-enabling interrupts and waiting for
       an interrupt here so that we do not need to go
       up the software stack to handle this situation. */
    warpBitmaskFill(&bpMask, 1);
    warpBitmaskSetBits(&bpMask, wp, 1, 0);
    warpBitmaskAnd(&bpMask, &dev->smState[vsm].state.bpmask, &bpMask);
    res = dev->halo.writeBreakpointMask(dev, vsm, &bpMask);
    if (res != CUDBG_SUCCESS)
        HALO_TRACE_FUNCTION(10, "Failed to write breakpoint mask (res=%d)\n", res);

    res = dev->halo.writePauseServicedMask(dev, false, vsm);
    if (res != CUDBG_SUCCESS)
        HALO_TRACE_FUNCTION(10, "Failed to write pause serviced mask (res=%d)\n", res);

    res = fermi_resumeTPC(dev, vsm);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to fermi_resumeTPC failed in thService.\n");
        return res;
    }

    /* Wait for the traphandler service routine to make progress. This saves us
       from reading the pause mask before the SM even resumed above. */
    do {
        res = dev->halo.readLaneServiceReason(dev, vsm, wp, 0, &laneServiceReason);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to read reason code for lane\n");
            return res;
        }

        /* Service reason is reset to 0 when the warp pauses again */
        if (laneServiceReason) {
#if cuosOsIsLinux() || cuosOsIsApple()
            usleep(sleepInterval);
#endif
            timeElapsed += sleepInterval;
        }
    }
    while (laneServiceReason && (timeElapsed < timeOut));

    if (timeElapsed >= timeOut) {
        HALO_ERROR("TH service routine did not make progress!\n");
        return CUDBG_ERROR_INTERNAL;
    }

    res = dev->halo.waitForSMPause(dev, vsm);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to waitForSMPause failed in thService.\n");
        return res;
    }

    /* Bug 872516 - On newer architectures (Kepler), we need to
       clear additional interrupt bits, otherwise spurious events
       can show up. */
    res = dev->halo.thServicePostProcess(dev, vsm);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to dev->halo.thServicePostProcess failed (res=%d)\n", res);
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_thServicePostProcess(CudbgDevice dev, uint32_t vsm)
{
    /* No post processing needed for Fermi trap handler service routine */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_getScratchpadSharedMemDevVaddr(Context context, uint64_t *shmemDevVaddr)
{
    CUDBG_VERIFY(shmemDevVaddr && context, CUDBG_ERROR_INVALID_ARGS, "Invalid args.\n");

    *shmemDevVaddr = context->scratchpadDevVA + FERMI_TRAP_HANDLER_SCRATCHPAD_OFFSET_SHARED;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_readSharedMemory(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                       uint64_t offset, void *buf, uint32_t bufSz)
{
    uint64_t devVaddr = 0;
    uint32_t addr = (uint32_t) offset;
    uint32_t shmemSize = dev->smState[vsm].warp[wp].CTASharedSize;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(((uint64_t) addr == offset), CUDBG_ERROR_INVALID_MEMORY_ACCESS, "Invalid memory access.\n");

    CUDBG_VERIFY((shmemSize >= addr + bufSz), CUDBG_ERROR_INVALID_MEMORY_ACCESS, "Invalid memory access.\n");

    if (dev->preemptState == CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_PREEMPTED_FOR_DEVICE_EVENT) {
        res = dev->halo.readSharedMemCtaCtx(dev, vsm, wp, addr, buf, bufSz);
        if (res != CUDBG_SUCCESS)
            HALO_ERROR("Failed to read shared memory from cta ctx (res=%d)\n", res);
        return res;
    }

    dev->halo.thService(dev, vsm, wp, addr, bufSz, TH_SERVICE_SHARED_MEM_READ);

    res = dev->halo.getScratchpadSharedMemDevVaddr(dev->activeContext, &devVaddr);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to getScratchpadSharedMemDevVaddr failed in readSharedMemory.\n");
        return res;
    }

    res = dev->halo.readDeviceMemory(dev->activeContext, devVaddr, buf, bufSz);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to readDeviceMemory failed (res=%d).\n", res);
        return res;
    }

    return res;
}

static CUDBGResult
fermi_writeSharedMemory(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                        uint64_t offset, const void *buf, uint32_t bufSz)
{
    uint64_t devVaddr = 0;
    uint32_t addr = (uint32_t) offset;
    uint32_t shmemSize = dev->smState[vsm].warp[wp].CTASharedSize;
    CUDBGResult res;

    CUDBG_VERIFY(((uint64_t) addr == offset), CUDBG_ERROR_INVALID_MEMORY_ACCESS, "Invalid memory access.\n");

    CUDBG_VERIFY((shmemSize >= addr + bufSz), CUDBG_ERROR_INVALID_MEMORY_ACCESS, "Invalid memory access.\n");

    if (dev->preemptState == CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_PREEMPTED_FOR_DEVICE_EVENT) {
        res = dev->halo.writeSharedMemCtaCtx(dev, vsm, wp, addr, buf, bufSz);
        if (res != CUDBG_SUCCESS)
            HALO_ERROR("Failed to read shared memory from cta ctx (res=%d)\n", res);
        return res;
    }

    res = dev->halo.getScratchpadSharedMemDevVaddr(dev->activeContext, &devVaddr);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to getScratchpadSharedMemDevVaddr failed in readSharedMemory.\n");
        return res;
    }

    res = dev->halo.writeDeviceMemory(dev->activeContext, devVaddr, buf, bufSz);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to writeDeviceMemory failed (res=%d).\n", res);
        return res;
    }

    res = dev->halo.thService(dev, vsm, wp, addr, bufSz, TH_SERVICE_SHARED_MEM_WRITE);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to thService failed in writeSharedMemory.\n");
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_findSyscallSP(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln, bool *inSyscall, uint32_t *spval)
{
    DebugPatch patch = NULL;
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t addr = 0;
    uint64_t pc;

    CUDBG_VERIFY((inSyscall && spval),
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments\n");
    *inSyscall = false;

    if (dev->smState[vsm].warp[wp].activeMask & (1U << ln))
        res = dev->halo.readPC(dev, vsm, wp, &pc);
    else
        res =  dev->halo.findDivergedCRS_PC(dev, vsm, wp, ln, &pc);

    CUDBG_VERIFY((res == CUDBG_SUCCESS),
                 CUDBG_ERROR_UNKNOWN,
                 "Unable to find pc");

    /* Basic sanity, test if the starting address is in a syscall */
    res = dev->haloClient->inSyscallPatch(dev, pc, &patch, inSyscall);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to inSyscallPatch failed\n");
        return res;
    }

    if (!*inSyscall)
        return CUDBG_SUCCESS;

    /* Address in Lmem where driver spills R1 */
    res = dev->halo.getSavedSPLmemAddr(dev, &addr);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to get saved SP Lmem Addr failed\n");
        return res;
    }

    return dev->halo.readLocalMemory(dev, vsm, wp, ln, addr, spval, sizeof(*spval));
}

static CUDBGResult
fermi_readRegisterRange(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                        uint32_t regnum, uint32_t *buf, uint32_t numRegs, bool rawSpValue)
{
    uint32_t *wbuf = (uint32_t *) buf;
    uint32_t base = FERMI_LMEM_ABI_HI(vsm, wp) - FERMI_LMEM_ABI_SAVED_R0;
    uint32_t offset = regnum * sizeof(uint32_t);
    uint32_t bufSz = numRegs * sizeof(*buf);
    Context context = dev->activeContext;
    CUDBGResult res = CUDBG_SUCCESS;
    bool inSyscall = false;
    uint32_t spval = 0, regVal = 0;

    CUDBG_VERIFY((context && context->memMapActive), CUDBG_ERROR_INVALID_MEMORY_ACCESS, "Invalid memory access.\n");

    // Special handling for syscalls.
    // If this lane is stopped in a syscall patch, then we will intercept reads
    // to R1 (the stack pointer)

    if (!rawSpValue && offset == FERMI_ABI_SP_REGNUM * sizeof(uint32_t)) {
        res = dev->halo.findSyscallSP(dev, vsm, wp, ln, &inSyscall, &spval);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to read syscall stack pointer\n");
            return res;
        }

        if (inSyscall) {
            HALO_TRACE_FUNCTION(1, "Reading stack pointer inside syscall. Returning : 0x%x\n", spval);
            *wbuf = spval;
            return res;
        }
    }

    for (; bufSz; offset += 4, bufSz -= 4) {
        res = dev->halo.readLocalMemory(dev, vsm, wp, ln, base - offset, &regVal, sizeof(regVal));
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to read lmem in readRegisterRange.\n");
            return res;
        }

        *wbuf++ = regVal;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_writeRegisterFile(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                        uint64_t offset, const void *buf, uint32_t bufSz)
{
    const uint32_t *wbuf = (const uint32_t *) buf;
    uint32_t base = FERMI_LMEM_ABI_HI(vsm, wp) - FERMI_LMEM_ABI_SAVED_R0;
    uint32_t offset32 = (uint32_t) offset;
    Context context = dev->activeContext;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY((context && context->memMapActive),
                 CUDBG_ERROR_INVALID_CONTEXT,
                 "No active context found or invalid context.\n");

    CUDBG_VERIFY(((uint64_t) offset32 == offset && !((offset32 | bufSz) & 3)),
                 CUDBG_ERROR_INVALID_MEMORY_ACCESS,
                 "Invalid memory access.\n");

    for (; bufSz; offset32 += 4, bufSz -= 4) {
        res = dev->halo.writeLocalMemory(dev, vsm, wp, ln, base - offset32, wbuf, 4);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to write lmem in writeRegisterFile.\n");
            return res;
        }

        wbuf++;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_readUniformRegisterFile(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                              uint64_t offset, void *buf, uint32_t bufSz)
{
    /* Not implemented on Fermi */
    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_writeUniformRegisterFile(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                               uint64_t offset, const void *buf, uint32_t bufSz)
{
    /* Not implemented on Fermi */
    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_readUniformPredicates(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                            uint32_t numPreds, uint32_t *predicates)
{
    /* Not implemented on Fermi */
    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_writeUniformPredicates(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                             uint32_t numPreds, const uint32_t *predicates)
{
    /* Not implemented on Fermi */
    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_readPredicates(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                     uint32_t numPreds, uint32_t *predicates)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t i;
    uint32_t predicateReg = 0;
    uint32_t predLmemAddr = FERMI_LMEM_ABI_HI(vsm, wp) - FERMI_LMEM_ABI_SAVED_PREDICATES;

    CUDBG_VERIFY(predicates, CUDBG_ERROR_INVALID_ARGS, "Invalid args in fermi_readPredicates\n");
    CUDBG_VERIFY(numPreds <= FERMI_NUM_PREDICATES, CUDBG_ERROR_INVALID_ARGS, "Invalid # of predicates\n");

    /* Read predicate register from lmem */
    res = dev->halo.readLocalMemory(dev, vsm, wp, ln, predLmemAddr, &predicateReg, sizeof predicateReg);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read predicate register from lmem\n");
        return res;
    }

    /* Predicates are backed in the LSBs of PR */
    for (i = 0; i < numPreds; i++) {
        predicates[i] = (predicateReg >> i) & 1U;
    }

    return res;
}

static CUDBGResult
fermi_readCCRegister(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                     uint32_t *cc)
{
    return haloReadCCRegister(dev, vsm, wp, ln,
                              FERMI_LMEM_ABI_HI(vsm, wp) - FERMI_LMEM_ABI_SAVED_PREDICATES,
                              cc);
}

static CUDBGResult
fermi_writePredicates(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                      uint32_t numPreds, const uint32_t *predicates)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t i;
    uint32_t predicateReg = 0;
    uint32_t predLmemAddr = FERMI_LMEM_ABI_HI(vsm, wp) - FERMI_LMEM_ABI_SAVED_PREDICATES;

    CUDBG_VERIFY(predicates, CUDBG_ERROR_INVALID_ARGS, "Invalid args in fermi_writePredicate\n");
    CUDBG_VERIFY(numPreds <= FERMI_NUM_PREDICATES, CUDBG_ERROR_INVALID_ARGS, "Invalid # of predicates\n");

    /* Read existing predicate register from lmem */
    res = dev->halo.readLocalMemory(dev, vsm, wp, ln, predLmemAddr, &predicateReg, sizeof predicateReg);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read predicate register from lmem\n");
        return res;
    }

    /* Modify predicate register based on inputs */
    for (i = 0; i < numPreds; i++) {
        CUDBG_VERIFY(predicates[i] < 2, CUDBG_ERROR_INVALID_ARGS, "Invalid predicate value\n");
        predicateReg = (predicateReg & ~(1U << i)) | (predicates[i] << i);
    }

    /* Write updated predicate register back to lmem */
    res = dev->halo.writeLocalMemory(dev, vsm, wp, ln, predLmemAddr, &predicateReg, sizeof predicateReg);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to write predicate register to lmem\n");
        return res;
    }

    return res;
}

static CUDBGResult
fermi_writeCCRegister(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                      const uint32_t cc)
{
    return haloWriteCCRegister(dev, vsm, wp, ln,
                               FERMI_LMEM_ABI_HI(vsm, wp) - FERMI_LMEM_ABI_SAVED_PREDICATES,
                               cc);
}

static CUDBGResult
fermi_readParamMemory(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                      uint64_t offset, void *buf, uint32_t bufSz)
{
    return dev->halo.readGenericMemory(dev->activeContext, 0, 0, 0,
                                       dev->smState[vsm].warp[wp].paramConstDptr + offset,
                                       buf, bufSz);
}

static CUDBGResult
fermi_writeParamMemory(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                       uint64_t offset, const void *buf, uint32_t bufSz)
{
    return dev->halo.writeGenericMemory(dev->activeContext, 0, 0, 0,
                                        dev->smState[vsm].warp[wp].paramConstDptr + offset,
                                        buf, bufSz);
}

static CUDBGResult
fermi_getGTASWindowAddresses(Context context, uint64_t *sharedWindowBase, uint64_t *sharedWindowSize,
                             uint64_t *localWindowBase, uint64_t *localWindowSize,
                             uint64_t *globalWindowBase)
{
    CUDBG_VERIFY(context,
                 CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    if (sharedWindowBase) *sharedWindowBase = context->shmemWindowDevVA;
    if (sharedWindowSize) *sharedWindowSize = CU_GTAS_WINDOW_SIZE;   /* 16 MiB */
    if (localWindowBase)  *localWindowBase = context->lmemWindowDevVA;
    if (localWindowSize)  *localWindowSize = CU_GTAS_WINDOW_SIZE;    /* 16 MiB */
    if (globalWindowBase) *globalWindowBase = context->gmemWindowDevVA;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_readGenericMemory(Context context, uint32_t vsm, uint32_t wp, uint32_t ln,
                        uint64_t devptr, void *buf, uint32_t bufSz)
{
    CudbgDevice dev;
    CUDBGResult res;
    uint64_t devVaddr = 0;
    uint64_t localBase, localSize;
    uint64_t sharedBase, sharedSize;

    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context when reading global memory.\n");

    dev = context->dev;

    res = dev->halo.getGTASWindowAddresses(context, &sharedBase, &sharedSize, &localBase, &localSize, NULL);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get window addresses\n");

    HALO_TRACE_FUNCTION(49, "shared=%#" PRIx64 ":%#x local=%#" PRIx64 ":%#x addr=%#" PRIx64 ":%#x\n",
            sharedBase, sharedSize, localBase, localSize, devptr, bufSz);

    if (sharedBase <= devptr && devptr < sharedBase + sharedSize) {
        /* devptr in shared space */
        devptr -= sharedBase;
        CUDBG_VERIFY(devptr + bufSz <= sharedSize, CUDBG_ERROR_INVALID_ARGS, "Overlapping shared address read!\n");
        return dev->halo.readSharedMemory(context->dev, vsm, wp, devptr, buf, bufSz);
    }

    if (localBase <= devptr && devptr < localBase + localSize) {
        /* devptr in local space */
        devptr -= localBase;
        CUDBG_VERIFY(devptr + bufSz <= localSize, CUDBG_ERROR_INVALID_ARGS, "Overlapping local address read!\n");
        return dev->halo.readLocalMemory(context->dev, vsm, wp, ln, devptr, buf, bufSz);
    }

    /* If the devptr is not within shared/local, then we'll try
       strictly reading from global memory. */
    res = haloMemoryMapTranslateToDevVaddr(context->memMap, HALO_MEM_SEG_GLOBAL,
                                           devptr, &devVaddr);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to translate Dptr 0x%" PRIx64 "\n",
                 devptr);

    res = dev->halo.readDeviceMemory(context, devVaddr, buf, bufSz);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE_FUNCTION(50, "Call to readDeviceMemory failed (res=%d).\n", res);
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_writeGenericMemory(Context context, uint32_t vsm, uint32_t wp, uint32_t ln,
                         uint64_t devptr, const void *buf, uint32_t bufSz)
{
    CudbgDevice dev;
    CUDBGResult res;
    uint64_t devVaddr = 0;
    uint64_t localBase, localSize;
    uint64_t sharedBase, sharedSize;

    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context when writing global memory.\n");

    dev = context->dev;

    res = dev->halo.getGTASWindowAddresses(context, &sharedBase, &sharedSize, &localBase, &localSize, NULL);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get window addresses\n");

    if (sharedBase <= devptr && devptr < sharedBase + sharedSize) {
        /* devptr in shared space */
        devptr -= sharedBase;
        CUDBG_VERIFY(devptr + bufSz <= sharedSize, CUDBG_ERROR_INVALID_ARGS, "Overlapping shared address write!\n");
        return dev->halo.writeSharedMemory(context->dev, vsm, wp, devptr, buf, bufSz);
    }

    if (localBase <= devptr && devptr < localBase + localSize) {
        /* devptr in local space */
        devptr -= localBase;
        CUDBG_VERIFY(devptr + bufSz <= localSize, CUDBG_ERROR_INVALID_ARGS, "Overlapping local address write!\n");
        return dev->halo.writeLocalMemory(context->dev, vsm, wp, ln, devptr, buf, bufSz);
    }

    /* If the devptr is not within shared/local, then we'll try
       strictly writing to global memory. */
    res = haloMemoryMapTranslateToDevVaddr(context->memMap, HALO_MEM_SEG_GLOBAL,
                                           devptr, &devVaddr);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to translate Dptr 0x%" PRIx64 "\n");

    res = dev->halo.writeDeviceMemory(context, devVaddr, buf, bufSz);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE_FUNCTION(50, "Call to writeDeviceMemory failed (res=%d).\n", res);
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_cleanup(CudbgDevice dev)
{
    uint32_t vsm, wp;

    /* Cleanup dynamic CRS allocations for each warp */
    for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
        for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
            HaloCRS_t *warpCRS = &dev->smState[vsm].warp[wp].CRS;
            if (warpCRS->numEntries > 0) {
                HALO_TRACE(5, "CRS field deallocation for dev 0x%" PRIx64 " vsm%d/wp%d: "
                           "numEntries = %d\n", dev, vsm, wp, warpCRS->numEntries);
                free(warpCRS->flatCRS);
                free(warpCRS->pc);
                free(warpCRS->mask);
                free(warpCRS->type);
                free(warpCRS->xsum);
                warpCRS->numEntries = 0;
            }
        }
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_read_blockIdx(CudbgDevice dev, uint32_t vsm, uint32_t wp, CuDim3 *blockIdx)
{
    CUDBGResult result;
    Context context = dev->activeContext;

    /* If no active context, there is nothing we can do. */
    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "No active context found in read_blockIdx.\n");

    if (!dev->smState[vsm].warp[wp].blockIdxValid) {
        result = dev->halo.scratchpad.read_blockIdx(context->scratchpadAccessor, vsm, wp, &dev->smState[vsm].warp[wp].blockIdx);
        CUDBG_VERIFY(result == CUDBG_SUCCESS, result, "Failed to read block idx\n");

        dev->smState[vsm].warp[wp].blockIdxValid = 1;
    }

    *blockIdx = dev->smState[vsm].warp[wp].blockIdx;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_getStepOverBPMask(CudbgDevice dev, uint32_t vsm, CUwarpBitmask *mask)
{
    /* We can return either bptrapmask or brokenwarps here, as
       they are identical on Fermi.  We use bptrapmask just to
       be consistent, in that we return data that
       comes directly from hardware. */
    warpBitmaskAssign(mask, &dev->smState[vsm].state.bptrapmask);
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_writePauseServicedMask(CudbgDevice dev, bool full_resume, uint32_t vsm)
{
    /* Not used on fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_readPauseServicedMask(struct Halo_st *halo, HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, CUwarpBitmask *pauseServicedMask)
{
    return CUDBG_ERROR_UNKNOWN;
}

static CUDBGResult
fermi_readSaveWarpMask(struct Halo_st *halo, HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, CUwarpBitmask *saveWarpMask)
{
    return CUDBG_ERROR_UNKNOWN;
}

static CUDBGResult
fermi_findConstBankOffset(CudbgDevice dev, DeviceFunction func,
                          uint32_t tid, uint64_t *constBankOffset)
{
    /* Not used on fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_mcinterop_getPatchPC(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                           uint32_t ln, uint64_t *pc)
{
    CUDBGResult res = CUDBG_SUCCESS;
    res = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                    dev->halo.deviceInfo.lmemHiMemcheckScratch +
                                    FERMI_LMEM_MEMCHECK_PC, pc, sizeof *pc);
    if (res == CUDBG_SUCCESS) {
        // clear out hi 32 bits as PCs are only 32bit
        *pc = ((*pc << 32) >> 32);
    }
    return res;
}

static CUDBGResult
fermi_mcinterop_getRegSpill(CudbgDevice dev, uint32_t *numSpilled)
{
    if (numSpilled)
        *numSpilled = 8; // number of registers spilled to lmem

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_mcinterop_getPatchReg(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                            uint32_t ln, uint32_t regno,
                            uint32_t *hasSpilled, uint32_t *regval)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t numSpilled = 0;

    res = dev->halo.mcinterop_getRegSpill(dev, &numSpilled);
    if (res != CUDBG_SUCCESS)
        return res;

    if (regno >= numSpilled) {
        *hasSpilled = 0;
        return CUDBG_SUCCESS;
    }

    *hasSpilled = 1;
    res = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                    dev->halo.deviceInfo.lmemHiMemcheckScratch +
                                    FERMI_LMEM_MEMCHECK_R0 +
                                    regno * sizeof(*regval),
                                    regval, sizeof *regval);
    return res;
}

static CUDBGResult
fermi_mcinterop_getPatchPred(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                             uint32_t ln, uint32_t numPreds,
                             uint32_t *predicates)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t i;
    uint32_t predicateReg = 0;

    res = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                    dev->halo.deviceInfo.lmemHiMemcheckScratch +
                                    FERMI_LMEM_MEMCHECK_PRED,
                                    &predicateReg, sizeof predicateReg);

    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read predicate registers from memcheck scratch (res=%d)\n", res);
        return res;
    }

    for (i = 0; i < numPreds; i++) {
        predicates[i] = (predicateReg >> i) & 1U;
    }

    return res;
}

static CUDBGResult
fermi_mcinterop_getPatchCC(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                           uint32_t ln, uint32_t *cc)
{

    return haloReadCCRegister(dev, vsm, wp, ln,
                              dev->halo.deviceInfo.lmemHiMemcheckScratch + FERMI_LMEM_MEMCHECK_PRED,
                              cc);
}

static CUDBGResult
fermi_mcinterop_setPatchReg(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                            uint32_t ln, uint32_t regno,
                            uint32_t *hasSpilled, const uint32_t *regval)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t numSpilled = 0;

    res = dev->halo.mcinterop_getRegSpill(dev, &numSpilled);
    if (res != CUDBG_SUCCESS)
        return res;

    if (regno >= numSpilled) {
        *hasSpilled = 0;
        return CUDBG_SUCCESS;
    }

    *hasSpilled = 1;
    res = dev->halo.writeLocalMemory(dev, vsm, wp, ln,
                                     dev->halo.deviceInfo.lmemHiMemcheckScratch +
                                     FERMI_LMEM_MEMCHECK_R0 +
                                     regno * sizeof(*regval),
                                     regval, sizeof *regval);
    return res;
}

static CUDBGResult
fermi_mcinterop_setPatchPred(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                             uint32_t ln, uint32_t numPreds,
                             const uint32_t *predicates)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t i;
    uint32_t predicateReg = 0;

    /* Read existing predicate register from memcheck scratch */
    res = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                    dev->halo.deviceInfo.lmemHiMemcheckScratch +
                                    FERMI_LMEM_MEMCHECK_PRED,
                                    &predicateReg, sizeof predicateReg);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read predicate registers from memcheck scratch (res=%d)\n", res);
        return res;
    }

    /* Modify predicate register based on inputs */
    for (i = 0; i < numPreds; i++) {
        CUDBG_VERIFY(predicates[i] < 2, CUDBG_ERROR_INVALID_ARGS, "Invalid predicate value\n");
        predicateReg = (predicateReg & ~(1U << i)) | (predicates[i] << i);
    }

    /* Write updated predicate register back to memcheck scratch */
    res = dev->halo.writeLocalMemory(dev, vsm, wp, ln,
                                     dev->halo.deviceInfo.lmemHiMemcheckScratch +
                                     FERMI_LMEM_MEMCHECK_PRED,
                                     &predicateReg, sizeof predicateReg);
    return res;
}

static CUDBGResult
fermi_mcinterop_setPatchCC(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                           uint32_t ln, const uint32_t cc)
{
    return haloWriteCCRegister(dev, vsm, wp, ln,
                               dev->halo.deviceInfo.lmemHiMemcheckScratch + FERMI_LMEM_MEMCHECK_PRED,
                               cc);
}

static CUDBGResult
fermi_mcinterop_getLDSTTargetAddr(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                  uint32_t ln, uint64_t *addr, ptxStorageKind *storage)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t addr_lo = 0, addr_hi = 0;
    uint32_t magic = 0;

    res = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                    dev->halo.deviceInfo.lmemHiMemcheckScratch +
                                    FERMI_LMEM_MEMCHECK_ADDR,
                                    &addr_lo, sizeof addr_lo);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to readLocalMemory failed in mcinterop_getLDSTTargetAddr.\n");
        return res;
    }

    res = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                    dev->halo.deviceInfo.lmemHiMemcheckScratch +
                                    FERMI_LMEM_MEMCHECK_ADDR_HI,
                                    &addr_hi, sizeof addr_hi);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to readLocalMemory failed in mcinterop_getLDSTTargetAddr.\n");
        return res;
    }

    *addr = ((uint64_t)addr_hi<<32 | addr_lo);

    res = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                    dev->halo.deviceInfo.lmemHiMemcheckScratch +
                                    dev->halo.deviceInfo.lmemMemcheckMagic,
                                    &magic, sizeof magic);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to readLocalMemory failed in mcinterop_getLDSTTargetAddr.\n");
        return res;
    }

    switch (magic & FERMI_MEMCHECK_ADDR_MASK) {
    case CU_MEMCHECK_ADDR_TYPE_GLOBAL:
        *storage = ptxGlobalStorage;
        break;
    case CU_MEMCHECK_ADDR_TYPE_LOCAL:
        *storage = ptxLocalStorage;
        break;
    case CU_MEMCHECK_ADDR_TYPE_SHARED:
        *storage = ptxSharedStorage;
        break;
    default :
        *storage = ptxUNSPECIFIEDStorage;
        break;
    }

    return res;
}

static CUDBGResult
fermi_mcinterop_getSyscallErrorData(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                    uint32_t ln, uint64_t *address, uint64_t *size)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t address_lo = 0, address_hi = 0;
    uint32_t size_lo = 0, size_hi = 0;

    res = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                    dev->halo.deviceInfo.lmemHiMemcheckScratch +
                                    FERMI_LMEM_MEMCHECK_ADDR,
                                    &address_lo, sizeof address_lo);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to readLocalMemory failed in mcinterop_getSyscallErrorData.\n");
        return res;
    }

    res = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                    dev->halo.deviceInfo.lmemHiMemcheckScratch +
                                    FERMI_LMEM_MEMCHECK_ADDR_HI,
                                    &address_hi, sizeof address_hi);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to readLocalMemory failed in mcinterop_getSyscallErrorData.\n");
        return res;
    }

    *address = (((uint64_t)address_hi << 32) | address_lo);

    res = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                    dev->halo.deviceInfo.lmemHiMemcheckScratch +
                                    FERMI_LMEM_MEMCHECK_PC,
                                    &size_lo, sizeof size_lo);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to readLocalMemory failed in mcinterop_getSyscallErrorData.\n");
        return res;
    }

    res = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                    dev->halo.deviceInfo.lmemHiMemcheckScratch +
                                    FERMI_LMEM_MEMCHECK_PC + 4,
                                    &size_hi, sizeof size_hi);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to readLocalMemory failed in mcinterop_getSyscallErrorData.\n");
        return res;
    }

    *size = (((uint64_t)size_hi << 32) | size_lo);
    return res;
}

static CUDBGResult
fermi_mcinterop_getSyscallError(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                uint32_t ln, uint32_t *syscallError)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t magic = 0;

    *syscallError = CU_MEMCHECK_SYSCALL_ERROR_NONE;

    res = dev->halo.readLocalMemory(dev, vsm, wp, ln,
                                    dev->halo.deviceInfo.lmemHiMemcheckScratch +
                                    dev->halo.deviceInfo.lmemMemcheckMagic,
                                    &magic, sizeof magic);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to readLocalMemory failed in mcinterop_getSyscallError.\n");
        return res;
    }

    if ((magic & FERMI_MEMCHECK_WHITEMAGIC_MASK) == FERMI_MEMCHECK_WHITEMAGIC) {
        if ((magic & FERMI_MEMCHECK_ADDR_MASK) == CU_MEMCHECK_ADDR_TYPE_GLOBAL)
            *syscallError =  ((magic & FERMI_MEMCHECK_SYSCALL_MASK) >> 2);
    }
    return res;
}
static CUDBGResult
fermi_mcinterop_checkLane(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                          uint32_t ln, uint32_t magic,
                          CUDBGException_t *exception)
{
    CUDBGResult res = CUDBG_SUCCESS;

    res = dev->haloClient->getExceptionFromMagic(dev, magic, exception);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to getExceptionFromMagic failed in mcinterop_checkLane.\n");
        return res;
    }

    return res;
}

static CUDBGResult
fermi_patchTextureInstruction(CudbgDevice dev, uint32_t texId, uint32_t dim,
                              uint32_t *coords, Grid grid)
{
    CUDBGResult res;
    Context ctx;
    uint64_t pc, inst;

    CUDBG_VERIFY(dev->activeContext, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context.\n");

    ctx = dev->activeContext;
    pc = (ctx->thCodeVA + ctx->thRdTexMemOffset) - ctx->funcMemBaseVA;

    res = dev->halo.readCodeMemory(ctx, pc, &inst, sizeof inst);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read code memory at offset 0x%08x (res=%d)\n", pc, res);
        return res;
    }

    inst = (inst & ~BF_FLDV(FSASS_TEX_ID, 0xFFu)) | BF_FLDV(FSASS_TEX_ID, texId);
    inst = (inst & ~BF_FLDV(FSASS_TEX_DIM, 0x3u)) | BF_FLDV(FSASS_TEX_DIM, dim - 1);

    res = dev->halo.writeCodeMemory(ctx, pc, &inst, sizeof inst);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to write code memory at offset 0x%08x (res=%d)\n", pc, res);
        return res;
    }

    res = dev->halo.invalidateICache(dev);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to invalidate icache (res=%d)\n", res);
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_getLmemOffsetForTexCoords(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                uint32_t *offset)
{

    /* Since all the ABI locations are used as negative offsets from lmem hi,
       the highest numerical value is the lowest mem location.
       This is also where COORDS_* start */
    *offset = FERMI_LMEM_ABI_HI(vsm, wp) - FERMI_LMEM_ABI_TEXTURE_COORDS_0;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_readTextureMemory(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                        uint32_t texId, uint32_t dim, uint32_t *coords,
                        void *buf, uint32_t bufSz)
{
    uint32_t *wbuf = (uint32_t *)buf;
    uint32_t i;
    uint32_t base;
    uint32_t result;
    CUDBGResult res = CUDBG_SUCCESS;
    Context context = dev->activeContext;
    uint32_t current[CUDBG_TEX_DIM_MAX];
    Grid grid;

    if (dev->preemptState == CUDBG_PREEMPTION_STATE_ALL_CONTEXTS_PREEMPTED_FOR_DEVICE_EVENT ||
        dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_CILP)
        return dev->halo.readTextureMemoryUsingTexHeader(dev, vsm, wp, texId, dim, coords, buf, bufSz);

    CUDBG_VERIFY((context && context->memMapActive), CUDBG_ERROR_INVALID_MEMORY_ACCESS, "Invalid memory access.\n");

    memset(current, 0, sizeof(current));
    memcpy(current, coords, dim * sizeof(*coords));

    res = dev->halo.getLmemOffsetForTexCoords(dev, vsm, wp, &base);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read tex coords lmem offset\n");
        return res;
    }

    res = dev->halo.writeLocalMemory(dev, vsm, wp, 0, base, (void *)current,
                                     CUDBG_TEX_DIM_MAX * sizeof current[0]);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to write tex coords to lmem\n");
        return res;
    }

    /* Write the TLD instruction to funcMem */
    grid = haloStateDeviceGetGrid(dev, dev->smState[vsm].warp[wp].gridId64);
    CUDBG_VERIFY(grid, CUDBG_ERROR_INVALID_GRID, "Invalid grid.\n");

    res = dev->halo.patchTextureInstruction(dev, texId, dim, coords, grid);

    for (i = 0; i < bufSz / sizeof(uint32_t); ++i) {
        /* Addr and size arguments of thService not needed */
        res = dev->halo.thService(dev, vsm, wp, 0, 0, TH_SERVICE_TEX_READ);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to thService failed in readTextureMemory.\n");
            return res;
        }

        /* The result is available at the lowest lmem texture coord offset */
        res = dev->halo.readLocalMemory(dev, vsm, wp, 0, base, (void *)&result,
                                        sizeof result);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to read texture\n");
            return res;
        }

        /* Collect the result */
        *wbuf++ = result;

        /* increment the inner most dimension to match a linear behaviour as
           the array bound to, and update lmem */
        ++current[0];

        res = dev->halo.writeLocalMemory(dev, vsm, wp, 0, base, (void *)&current[0],
                                         sizeof current[0]);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to update tex coord in lmem\n");
            return res;
        }
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_findSyscallEntryPoint(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln, uint64_t *entryPc)
{
    bool inSyscall = false, inGlobalSyscallPatch = false;
    DebugPatch patch = NULL;
    int32_t i = 0;
    CUDBGResult res = CUDBG_SUCCESS;
    HaloCRS_t *warpCRS = &dev->smState[vsm].warp[wp].CRS;
    uint32_t lane_mask = 1U << ln;
    uint32_t calSkipped = 0, laneDisRet = 0;
    uint64_t tokenPC = 0, physPC = 0;
    uint64_t firstGlobalSyscallPC = 0;

    /* Find the correct PC for this lane, accounting for divergence */
    if (dev->smState[vsm].warp[wp].activeMask & (1U << ln)) {
        res = dev->halo.readPC(dev, vsm, wp, &physPC);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to readPC failed (res=%d)\n", res);
            return res;
        }
    }
    else {
        res = dev->halo.findDivergedCRS_PC(dev, vsm, wp, ln, &physPC);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to findDivergedCRS_PC failed (res=%d)\n", res);
            return res;
        }
    }

#ifndef RELEASE
    /* Basic sanity, test if the starting address is in a syscall */
    res = dev->haloClient->inSyscallPatch(dev, physPC, &patch, &inSyscall);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to inSyscallPatch failed\n");
        return res;
    }

    if (!inSyscall)
        return CUDBG_ERROR_LANE_NOT_IN_SYSCALL;
#endif 

    /* Look for this lane in the DIS_RET mask */
    laneDisRet = lane_mask & warpCRS->mask[warpCRS->disRetIdx];

    for (i = warpCRS->trapIdx - 1; i >= 0; --i) {
        /* If this lane has been disabled due to RET, skip
           the first CAL token (it has finished this call) */
        if ((warpCRS->type[i] == CRS_TYPE_CALL ||
            warpCRS->type[i] == CRS_TYPE_CALL_NI) &&
            laneDisRet && !calSkipped++)
            continue;

        if ((warpCRS->type[i] != CRS_TYPE_CALL &&
             warpCRS->type[i] != CRS_TYPE_CALL_NI) ||
            !(warpCRS->mask[i] & lane_mask))
            continue;

        tokenPC = warpCRS->pc[i] - 8;

        /* Skip if the return pc is in a syscall patch. This ignores CNP entry stub if needed */
        res = dev->haloClient->inGlobalSyscallPatch(dev, warpCRS->pc[i], &patch, &inGlobalSyscallPatch);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to inGlobalSyscallPatch failed in findSyscallEntryPoint.\n");
            return res;
        }
        if (inGlobalSyscallPatch) {
            if (!firstGlobalSyscallPC) {
                firstGlobalSyscallPC = tokenPC;
            }
            continue;
        }

        /* Is this call within a syscall region */
        res = dev->haloClient->inSyscallPatch(dev, tokenPC, &patch, &inSyscall);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to inSyscallPatch failed\n");
            return res;
        }

        /* If not, it is the entry point into the syscall */
        if (!inSyscall) {
            *entryPc = tokenPC;
            return CUDBG_SUCCESS;
        }
    }
    if (firstGlobalSyscallPC) {
        *entryPc = firstGlobalSyscallPC;
        return CUDBG_SUCCESS;
    }
    return CUDBG_ERROR_UNKNOWN;
}

static CUDBGResult
fermi_getSavedSPLmemAddr(CudbgDevice dev, uint64_t *lmem_addr)
{
    CUDBG_VERIFY(lmem_addr,
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments\n");

    *lmem_addr = FERMI_LMEM_SAVED_STACK_POINTER;
    return CUDBG_SUCCESS;
}

CUDBGResult
fermi_singleStepLastWarpExit(CudbgDevice dev, uint32_t vsm, uint32_t wp)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CUwarpBitmask warpValid = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;
    CUwarpBitmask resumeMask;
    CUwarpBitmask rewindMask;
    CUwarpBitmask tmpMask;
    uint32_t elapsedTime;
    static const uint32_t timeout        = 5000000; // 5.00 seconds
    static const uint32_t sleepTime      = 500;
    uint32_t tvTimeout = 0;
    bool tvTimeoutReceived;

    res = haloStateGetTimeoutMsec(dev, &tvTimeout);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, CUDBG_ERROR_INTERNAL, "Internal error.\n");

    HALO_TRACE_FUNCTION(1, "Activating last warp step over exit handler\n");
    warpBitmaskFill(&tmpMask, 1);
    warpBitmaskSetBits(&tmpMask, wp, 1, 0);
    warpBitmaskAnd(&resumeMask, &dev->smState[vsm].state.tidValid, &tmpMask);
    warpBitmaskNot(&rewindMask, &resumeMask);
    /* Logically, this means :
    resumeMask = dev->smState[vsm].state.tidValid & ~(1ULL << wp);
    rewindMask = ~resumeMask;
    */

    /* Clear this warp's bit in the breakpoint mask */
    res = dev->halo.writeBreakpointMask(dev, vsm, &resumeMask);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Turn on single step mode for this SM */
    res = dev->halo.singleStep(dev, vsm, 1);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Resume this SM to activate single step */
    dev->smState[vsm].valid = 0;
    res = dev->halo.resumeSM(dev, vsm);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Fermi HW has a huge bug -- HW single step does not
       notify the CPU (HWW pulse) when the *last* resident
       warp on an SM is stepped over an EXIT instruction.
       So, instead of waiting for an event, we must poll
       for its valid bit to go low (this is safe to do as
       we hold the SM in single-step mode). */
    for (elapsedTime = 0; elapsedTime < timeout; elapsedTime += sleepTime) {
        res = dev->halo.readWarpMaskPRI(dev, vsm, HALO_REG_OP_TYPE_GLOBAL,
                                        HALO_MASK_PRI_WARP_VALID, &warpValid);
        if (res != CUDBG_SUCCESS)
            return res;

        /* If this warp is no longer valid, break out */
        if (!warpBitmaskGetBits(&warpValid, wp, 1))
            break;

#if cuosOsIsLinux() || cuosOsIsApple()
        usleep(sleepTime);
#endif
    }

    /* If we happen to timeout while polling for the condition
       above, it could be due to the following race:
           1.  We single-step the last warp (requires a resume)
           2.  The original warp exits, and a new one enters the
               SM (same warp slot).
           3.  We poll for the valid bit to go low, but we missed
               the chance to see it drop before the new warp came
               on (setting the bit high again).
       So, if this happens, then it means there *must* be a device
       event pending.  Consume it here. */
    if (elapsedTime >= timeout) {
        HALO_TRACE_FUNCTION(1, "Timeout polling valid bit.  Waiting for device event\n");
        res = tgdbWaitForDeviceEvent(dev->deviceIdx, -1, true, true, &tvTimeout, &tvTimeoutReceived);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Call to tgdbWaitForDeviceEvent failed.\n");
            return res;
        }
        HALO_TRACE_FUNCTION(1, "Event received while stepping over the last warp's exit\n");
    }

    /* Suspend this SM */
    res = dev->halo.suspendSM(dev, vsm);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to suspendSM failed.\n");
        return res;
    }

    /* Turn off single step mode for this SM */
    res = dev->halo.singleStep(dev, vsm, 0);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Collect state, do not rewind */
    res = dev->halo.collectDeviceState(dev, true, NULL);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to collectDeviceState failed.\n");
        return res;
    }

    return res;
}

static CUDBGResult
fermi_adjustActiveMask(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t *warpActiveMask)
{
    uint32_t i, idx, entrySize, activeMask = 0x1;
    uint8_t xsum = 0;
    unsigned char *flatCRSTrapAddr;
    CUDBGResult res = CUDBG_SUCCESS;
    HaloCRS_t *warpCRS = &dev->smState[vsm].warp[wp].CRS;

    CUDBG_VERIFY(warpActiveMask, CUDBG_ERROR_INTERNAL, "Invalid args to adjustActiveMask\n");

    /* Assert that we've come here with a zero active mask (this is
       currently the only time this function should be called. */
    CUDBG_VERIFY(!*warpActiveMask, CUDBG_ERROR_INTERNAL, "Nonzero active mask found\n");

    /* Assert that this warp's CRS is properly allocated. */
    CUDBG_VERIFY(warpCRS && warpCRS->flatCRS, CUDBG_ERROR_INTERNAL, "Unallocated warp CRS\n");

    /* Grab the trap token index */
    idx = warpCRS->trapIdx;

    /* As per Bug 978327 (actually found on Kepler), we can find ourselves in the trap
       handler with a zero active mask if a warp EXITs and causes a STACK_ERROR.  As
       this could in theory happen with general corruption, we should handle this by
       cooking the first lane to be active.  After all, *something* paused in the trap
       handler so it is useful to gain as much insight as possible here. */
    HALO_TRACE(1, "VSM%u/WP%u: Original CRS trap entry: %02x%02x%08x%08x\n", vsm, wp,
               warpCRS->xsum[idx], warpCRS->type[idx],
               warpCRS->mask[idx], warpCRS->pc[idx]);

    /* CHECKSUM UPDATE (Computed as a delta from the original xsum).
       Probably not necessary, but good for debugging. */
    for (i = 0; i < 4; ++i)
        xsum += (uint8_t) (((activeMask >> (i * 8)) & 255) - ((warpCRS->mask[idx] >> (i * 8)) & 255));

    /* Update cached activeMask and xsum */
    warpCRS->mask[idx] = activeMask;
    warpCRS->xsum[idx] -= xsum;

    /* Update flat CRS */
    res = dev->halo.CRSEntrySize(dev, &entrySize);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to CRSEntrySize failed in writePC.\n");
        return res;
    }

    flatCRSTrapAddr = &warpCRS->flatCRS[idx * entrySize];
    memcpy(flatCRSTrapAddr + FERMI_CRS_XSUM_OFFSET, (char *)&warpCRS->xsum[idx], sizeof xsum);
    memcpy(flatCRSTrapAddr + FERMI_CRS_MASK_OFFSET, (char *)&warpCRS->mask[idx], sizeof activeMask);

    /* Now write back CRS modifications to the device */
    res = dev->halo.updateCRS(dev, vsm, wp, warpCRS->flatCRS, idx);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to updateCRS failed in writePC.\n");
        return res;
    }

    HALO_TRACE(1, "VSM%u/WP%u: Updated CRS trap entry: %02x%02x%08x%08x\n", vsm, wp,
               warpCRS->xsum[idx], warpCRS->type[idx],
               warpCRS->mask[idx], warpCRS->pc[idx]);

    *warpActiveMask = warpCRS->mask[idx];
    return res;
}

#ifdef CUDBG_ENABLE_IFB
static CUDBGResult
fermi_allocateIFB(CudbgDevice dev, uint32_t devHandle, uint32_t devSubHandle, uint32_t rmGpuId)
{
    uint32_t ifbHandle, rc;

    CUDBG_VERIFY(dev, CUDBG_ERROR_INTERNAL, "Improper dev ptr\n");

    /* Allocate IFB registers */
    ifbHandle = handlePoolAlloc(globals.handlePool);
    if ((rc = CudaRmAlloc(globals.rmClient,
                          devHandle,
                          ifbHandle,
                          GF100_INDIRECT_FRAMEBUFFER,
                          NULL, 0, rmGpuId))) {
        HALO_ERROR("Failed to allocate an IFB handle (rc=0x%x)\n", rc);
        return CUDBG_ERROR_INTERNAL;
    }

    if ((rc = CudaRmMapMemory(globals.rmClient, devSubHandle,
                              ifbHandle, 0,
                              sizeof dev->ifbPtrFermi, (void **)&dev->ifbPtrFermi,
                              NV04_MAP_MEMORY_FLAGS_NONE, rmGpuId))) {
        HALO_ERROR("Failed to map IFB registers (rc=0x%x)\n", rc);
        dev->ifbPtrFermi = NULL;
        return CUDBG_ERROR_INTERNAL;
    }

    HALO_TRACE_FUNCTION(1, "Allocated Fermi IFB ptr: %p\n", dev->ifbPtrFermi);

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_readViaIFB(CudbgDevice dev, uint32_t addr, uint32_t *data)
{
    CUDBG_VERIFY(dev && dev->ifbPtrFermi, CUDBG_ERROR_INTERNAL, "Improper dev/ifb ptr\n");
    dev->ifbPtrFermi->RdWrAddr = addr;
    *data = dev->ifbPtrFermi->RdWrData;
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_writeViaIFB(CudbgDevice dev, uint32_t addr, uint32_t data)
{
    CUDBG_VERIFY(dev && dev->ifbPtrFermi, CUDBG_ERROR_INTERNAL, "Improper dev/ifb ptr\n");
    dev->ifbPtrFermi->RdWrAddr = addr;
    dev->ifbPtrFermi->RdWrData = data;
    return CUDBG_SUCCESS;
}
#endif

static CUDBGResult
fermi_getPgraphBar0Extents(CudbgDevice dev, uint32_t *start, uint32_t *size)
{
    *start = CUDBG_FERMI_BAR0_PGRAPH_REGS_START;
    *size = CUDBG_FERMI_BAR0_PGRAPH_REGS_SIZE;
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_getCCMasks(CudbgDevice dev, uint32_t *ccShift, uint32_t *ccBitmask)
{
    CUDBG_VERIFY(ccShift && ccBitmask, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    *ccShift   = FERMI_CC_SHIFT;
    *ccBitmask = FERMI_CC_BITMASK;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_buildMappingTable(CudbgDevice dev, bool saveTrapBits)
{
    /* This is not supported on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_checkAnyLaneInContinuation(CudbgDevice dev, uint32_t vsm, CUwarpBitmask *wpmask, bool *inContinuation)
{
    CUDBG_VERIFY(dev && inContinuation, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");
    *inContinuation = false;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_checkWarpNeedsHostResume(CudbgDevice dev, uint32_t vsm, uint32_t wp, bool *needsHostResume)
{
    CUDBG_VERIFY(dev && needsHostResume, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");
    *needsHostResume = false;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_controllerIlpSuspend(Context context, uint32_t *suspend)
{
    /* This is not supported on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_controllerIlpSetupMode(CudbgDevice dev, uint32_t mode)
{
    /* This is not supported on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_controllerIlpSavedCount(CudbgDevice dev, uint32_t *savedCount)
{
    /* This is not supported on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_controllerIlpRestore(CudbgDevice dev)
{
    /* This is not supported on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_disablePairingMode(CudbgDevice dev, Context context)
{
    /* No pairing mode on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_enablePairingMode(CudbgDevice dev, Context context)
{
    /* No pairing mode on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_fillDisassemblyBuffer(Context context, uint64_t gpuAddr, uint64_t inst[2],
                            uint64_t *instBuf, uint32_t instBufSize,
                            uint32_t *instBufWrittenSize)
{
    CUDBG_VERIFY(context && instBuf && instBufWrittenSize, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");
    CUDBG_VERIFY(instBufSize >= sizeof(inst[0]), CUDBG_ERROR_INTERNAL, "Buffer too small\n");

    /* Default is to just copy out the given instruction */
    memcpy(instBuf, inst, sizeof(inst[0]));
    *instBufWrittenSize = sizeof(inst[0]);

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_findNewHWCoords(CudbgDevice dev, uint32_t oldVsm, uint32_t oldWp,
                      uint32_t *vsm, uint32_t *wp)
{
    /* This is not supported on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_findParentGrid(CudbgDevice dev, Grid childGrid, Grid *parentGrid)
{
    /* This does not exist on Fermi and should never be called */
    HALO_ERROR("Called %s\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
fermi_getCrsPhysStackDepth(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t *crsPhysStackDepth)
{
    /* Not used on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_getCurrentGrCtxPtr(CudbgDevice dev, uint32_t *grCtxPtr)
{
    /* This is not supported on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_getDynamicRegisterRange (uint32_t *dynamicRegisterStart, uint32_t *dynamicRegisterEnd)
{
    /* Not implemented on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_getGridParamsOffsetGridId (CudbgDevice dev, uint64_t *offset)
{
    /* This does not exist on Fermi and should never be called */
    HALO_ERROR("Called %s\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
fermi_getGridParamsOffsetBlockDim (CudbgDevice dev, uint64_t *offset, uint32_t *size)
{
    /* This does not exist on Fermi and should never be called */
    HALO_ERROR("Called %s\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
fermi_getGridParamsOffsetGridDim (CudbgDevice dev, uint64_t *offset, uint32_t *size)
{
    /* This does not exist on Fermi and should never be called */
    HALO_ERROR("Called %s\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
fermi_getGridParamsOffsetStartPc (CudbgDevice dev, uint64_t *offset)
{
    /* This does not exist on Fermi and should never be called */
    HALO_ERROR("Called %s\n");
    return CUDBG_ERROR_INTERNAL;
}

CUDBGResult
fermi_getGridStatus(CudbgDevice dev, uint64_t gridId64, CUDBGGridStatus *status)
{
    uint32_t vsm, wp;

    /* If we don't see a grid on the device, it may either have terminated
       or not started. */
    *status = CUDBG_GRID_STATUS_UNDETERMINED;

    for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm)
        for (wp = 0; dev->smState[vsm].valid && wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
            if (dev->smState[vsm].warp[wp].valid &&
                dev->smState[vsm].warp[wp].gridId64 == gridId64) {
                *status = CUDBG_GRID_STATUS_ACTIVE;
                break;
            }
        }

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_getLmemBase(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint64_t *lmemBase)
{
    Context context;

    CUDBG_VERIFY(dev && lmemBase, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    context = dev->activeContext;
    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "No active context!\n");

    *lmemBase = context->defaultLmemDevVA;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_getSMHwwErrorPC(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint64_t *esrPC, bool *esrPCValid)
{
    CUDBG_VERIFY((esrPC && esrPCValid && dev), CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments\n");

    *esrPCValid = false;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_getUserEntryFunction(CudbgDevice dev, Context context, uint32_t vsm, uint32_t wp, uint32_t ln,
                           Grid grid, DeviceFunction *entryFunc)
{
    CUDBG_VERIFY(dev && context && grid && entryFunc, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments");

    /* Fermi grids aren't launched from global syscalls yet, so the following is always true. */
    *entryFunc = grid->function;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_initiatePreemptionSave(CudbgDevice dev, CudbgPreemptionState_t *preemptStatus)
{
    CUDBG_VERIFY(preemptStatus, CUDBG_ERROR_INVALID_ARGS, "Invalid args to initiatePreemptionSave\n");

    /* This is not supported on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_initiatePreemptionRestore(CudbgDevice dev, CudbgPreemptionState_t *preemptStatus)
{
    CUDBG_VERIFY(preemptStatus, CUDBG_ERROR_INVALID_ARGS, "Invalid args to initiatePreemptionRestore\n");

    /* This is not supported on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_insertBreakpoint(Context context, uint64_t vaddr, BreakpointContents *buf)
{
    CUDBGResult res;
    CudbgDevice dev;
    void *bptInst = NULL;

    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context in insertBreakpoint.\n");

    dev = context->dev;

    if (!CUDBG_DEBUG_OBJECT_IS_VALID(context->debugObj)) {
        /* This can happen if no ctx creation callback has been received yet
           during early stages of the app, or during shutdown. */
        HALO_TRACE_FUNCTION(50, "No debug object found, skipping breakpoint insertion.\n");
        return CUDBG_ERROR_INVALID_CONTEXT;
    }

    /* Assume 64bit instruction until told otherwise */
    buf->savedInstructionSize = sizeof(uint64_t);

    res = dev->halo.readDeviceMemory(context, vaddr, buf->savedInstruction, buf->savedInstructionSize);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE_FUNCTION(1, "Error reading code mem at addr %" PRIx64 " (res = %d)\n", vaddr, res);
        return res;
    }

    res = dev->halo.getInstructionSize((uint32_t)buf->savedInstruction[0], &buf->savedInstructionSize);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE_FUNCTION(1, "Error getting instruction size for instruction: %016" PRIx64 " (res = %d)\n", buf->savedInstruction, res);
        return res;
    }

    HALO_TRACE_FUNCTION(1, "Inserting %d byte breakpoint for instruction %016" PRIx64 "\n",
            buf->savedInstructionSize, buf->savedInstruction);

    bptInst = (buf->savedInstructionSize==sizeof(dev->halo.deviceInfo.bpt32Inst) ? (void*)&dev->halo.deviceInfo.bpt32Inst : (void*)&dev->halo.deviceInfo.bpt64Inst);

    res = dev->halo.writeDeviceMemory(context, vaddr, bptInst, buf->savedInstructionSize);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Error writing code mem at addr 0x%" PRIx64 " (res = %d)\n", vaddr, res);
        return res;
    }

    /* Set the device's code memory as dirty */
    dev->codeIsDirty = 1;

    HALO_TRACE_FUNCTION(1, "Breakpoint inserted at 0x%" PRIx64 ". Original instruction was 0x%08x\n",
                        vaddr, buf->savedInstruction[0]);

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_isReservedGridId(CudbgDevice dev, uint64_t gridId64, bool *isReserved)
{
    /* No reserved grids on Fermi */
    *isReserved = false;
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_isWarpEnabledForPreempt (CudbgDevice dev, uint32_t vsm, uint32_t wp, bool *isWarpEnabledForPreempt)
{
    CUDBG_VERIFY(isWarpEnabledForPreempt, CUDBG_ERROR_INVALID_ARGS, "Invaild args\n");

    /* Initialize to false for good measure */
    *isWarpEnabledForPreempt = false;

    /* This is not supported on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_isWarpOnBarrier(CudbgDevice dev, uint32_t vsm, uint32_t wp, bool *isWarpOnBarrier)
{
    /* This is not supported on Fermi.
       More specifically:  the only way to know if a warp is on a barrier is with
       a code scan (see fermi_isSteppable for more information). */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_membarWAR_getPatchPC(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                           uint32_t ln, uint64_t *entryPc, DebugPatch patch)
{
    /* Not implemented on Fermi */
    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_membarWAR_getPatchReg(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                            uint32_t ln, uint32_t regno,
                            uint32_t *hasSpilled, uint32_t *regval)
{
    /* Not implemented on Fermi */
    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_membarWAR_getPatchPred(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                             uint32_t ln, uint32_t numPreds, uint32_t *predicates)
{
    /* Not implemented on Fermi */
    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_membarWAR_getPatchCC(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                           uint32_t ln, uint32_t *cc)
{
    /* Not implemented on Fermi */
    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_membarWAR_setPatchReg(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                            uint32_t ln, uint32_t regno,
                            uint32_t *hasSpilled, const uint32_t *regval)
{
    /* Not implemented on Fermi */
    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_membarWAR_setPatchPred(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                             uint32_t ln, uint32_t numPreds, const uint32_t *predicates)
{
    /* Not implemented on Fermi */
    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_membarWAR_setPatchCC(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                           uint32_t ln, const uint32_t cc)
{
    /* Not implemented on Fermi */
    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_membarWAR_getPatchCallDepth(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                  uint32_t ln, uint32_t *depth,
                                  DebugPatch patch)
{
    /* Not implemented on Fermi */
    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_barWAR_getPatchPC(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                        uint32_t ln, uint64_t *entryPc)
{
    /* Not implemented on Fermi */
    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_patchDynamicRegisterRead(CudbgDevice dev, uint32_t regnum, uint32_t lmemAddr)
{
    /* Not implemented on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_patchDynamicRegisterWrite(CudbgDevice dev, uint32_t regnum, uint32_t regval)
{
    /* Not implemented on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_preemptChannelGroup(CudbgDevice dev, uint32_t rmChannelGroup, uint32_t hAppClient, bool *preemptTimedOut)
{
    /* This is not supported on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_readRegCtaCtx(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                    uint32_t regnum, uint32_t *wbuf, uint32_t bufSz)
{
    /* This is not supported on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_restoreWarpMasks(CudbgDevice device)
{
    /* This is not supported on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_releaseSharedResources(CudbgDevice dev)
{
    /* This is not supported on Fermi. */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_readWarpCtaCtxAddr(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                         uint64_t *warpCtaContextAddr)
{
    /* This is not supported on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_setLmemBaseCtaCtx(CudbgDevice dev, uint32_t vsm, uint32_t wp)
{
    /* This is not supported on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_readSharedMemCtaCtx(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t addr,
                          void *buf, uint32_t bufSz)
{
    /* This is not supported on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_writeSharedMemCtaCtx(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t addr,
                           const void *buf, uint32_t bufSz)
{
    /* This is not supported on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_writeRegCtaCtx(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                     uint32_t regnum, uint32_t *wbuf, uint32_t bufSz)
{
    /* This is not supported on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_waitForGrCtxSave(CudbgDevice dev, uint32_t grCtxPtr)
{
    /* This is not supported on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_scheduleChannelGroup(CudbgDevice dev, uint32_t rmChannelGroup, uint32_t hAppClient)
{
    /* This is not supported on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_setupIlpSave(CudbgDevice dev)
{
    /* This is not supported on Fermi */
    return CUDBG_SUCCESS;
}
static CUDBGResult
fermi_setChannelGroupTimeslice(CudbgDevice dev, uint32_t rmChannelGroup, uint64_t usec)
{
    /* This is not supported on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_readSMWarpESRInfo(CudbgDevice dev, uint32_t vsm, CudbgSMState_t *state)
{
    /* Not implemented on archs < SM5.0 */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_readTextureMemoryUsingTexHeader(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t id, uint32_t dim, uint32_t *coords, void *buf, uint32_t bufSz)
{
    /* This is not supported on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_removeBreakpoint(Context context, uint64_t vaddr, const BreakpointContents *buf)
{
    CUDBGResult res;
    CudbgDevice dev;

    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context in removeBreakpoint.\n");
    CUDBG_VERIFY(buf->savedInstructionSize > 0, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    dev = context->dev;

    res = dev->halo.writeDeviceMemory(context, vaddr, buf->savedInstruction, buf->savedInstructionSize);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE_FUNCTION(1, "Error writing code mem at addr 0x%" PRIx64 " (res = %d)\n", vaddr, res);
        return res;
    }

    /* Set the device's code memory as dirty */
    dev->codeIsDirty = 1;

    HALO_TRACE_FUNCTION(1, "Breakpoint removed at 0x%" PRIx64 ". Original instruction was 0x%08x\n",
                        vaddr, buf->savedInstruction[0]);

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_resumeWarps(CudbgDevice dev, uint32_t vsm, CUwarpBitmask *warpMask, uint32_t *hasResumed)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CUwarpBitmask tmpMask;

    CUDBG_VERIFY(warpMask && hasResumed, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    *hasResumed = 0;

    warpBitmaskNot(&tmpMask, warpMask);
    warpBitmaskAnd(&tmpMask, &tmpMask, &dev->smState[vsm].state.tidValid);

    /* Clear all warp bits for this warpMask in the bpmask */
    res = dev->halo.writeBreakpointMask(dev, vsm, &tmpMask);
    if (res != CUDBG_SUCCESS)
        return res;

    res = dev->halo.resumeSM(dev, vsm);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to resumeSM failed in resumeWarps.\n");
        return res;
    }

    *hasResumed = 1;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_findBreakpoint(Context ctx, uint64_t paddr, Breakpoint *bp)
{
    uint64_t offset;
    DebugPatch patch;
    DeviceFunction func;

    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context in findBreakpoint.\n");
    CUDBG_VERIFY(bp, CUDBG_ERROR_INVALID_ARGS, "Invalid bp in findBreakpoint.\n");

    *bp = NULL;

    func = (DeviceFunction)toolsRangeMapLookupByAddr(ctx->gpuAddrToFunction, paddr);
    if (func != NULL) {
        /* breakpoint maps are keyed by the offset from the start of the function */
        offset = paddr - func->gpuAddrBase;

        *bp = (Breakpoint)toolsHashMapFind(func->breakPoints, tHashMapNumToKey(offset));
        if (!*bp)
            *bp = (Breakpoint)toolsHashMapFind(func->temporaryBreakPoints, tHashMapNumToKey(offset));

        HALO_TRACE_FUNCTION(30, "func paddr=0x%016" PRIx64 " gpuAddrBase=0x%016" PRIx64 " offset=0x%016" PRIx64 " bp=0x%016" PRIx64 "\n",
                            paddr, func->gpuAddrBase, offset, *bp);

        return CUDBG_SUCCESS;
    }

    patch = (DebugPatch)toolsRangeMapLookupByAddr(ctx->gpuAddrToPatch, paddr);
    if (patch != NULL) {
        /* breakpoint maps are keyed by the offset from the start of the patch */
        offset = paddr - patch->gpuAddr;

        *bp = (Breakpoint)toolsHashMapFind(patch->breakPoints, tHashMapNumToKey(offset));
        if (!*bp)
            *bp = (Breakpoint)toolsHashMapFind(patch->temporaryBreakPoints, tHashMapNumToKey(offset));

        HALO_TRACE_FUNCTION(30, "patch paddr=0x%016" PRIx64 " gpuAddrBase=0x%016" PRIx64 " offset=0x%016" PRIx64 " bp=0x%016" PRIx64 "\n",
                            paddr, patch->gpuAddr, offset, *bp);

        return CUDBG_SUCCESS;
    }

    HALO_TRACE_FUNCTION(30, "Could not find function or patch for addr 0x%016" PRIx64 "\n", paddr);

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_rewindBrokenWarp(Context context, uint32_t vsm, uint32_t wp)
{
    CUDBGResult res;
    CudbgWarp_t *warp;
    CudbgDevice dev;
    uint64_t pc;
    Breakpoint bp;

    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context in rewindBrokenWarp.\n");

    dev = context->dev;
    warp = &dev->smState[vsm].warp[wp];

    /* First, check for narrow breakpoint at pc-4 */

    pc = warp->pc - 4;
    res = dev->halo.findBreakpoint(context, pc, &bp);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to find breakpoints\n");

    if (!bp) {
        /* No breakpoint at pc-4, check for wide breakpoint at pc-8 */
        pc = warp->pc - 8;
        res = dev->halo.findBreakpoint(context, pc, &bp);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to find breakpoints\n");
        if (bp && bp->savedContents.savedInstructionSize == sizeof(uint32_t)) {
            HALO_TRACE_FUNCTION(3, "Narrow breakpoint ignored at 0x%016" PRIx64 "\n", pc);
            return CUDBG_SUCCESS;
        }
    }

    if (bp) {
        HALO_TRACE_FUNCTION(3, "vsm%d/%d backing pc up 0x%08x -> 0x%016" PRIx64 "\n", vsm, wp, warp->pc, pc);
        warp->pc = (uint32_t)pc;
        res = dev->halo.writePC(dev, vsm, wp, warp->pc);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Call to writePC failed in rewindBrokenWarp.\n");
    }
    else
        HALO_TRACE_FUNCTION(3, "User-inserted breakpoint ignored at 0x%016" PRIx64 "\n", pc);

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_setPowerGatingState(CudbgDevice dev, HaloPowerGatingState state)
{
    /* Not used on Fermi */
    return CUDBG_SUCCESS;
}

/* Warp State setting */
static CUDBGResult
fermi_setWarpStateValid(CudbgDevice dev, uint32_t vsm, uint32_t wp)
{
    dev->smState[vsm].warp[wp].valid = 1;
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_updateSMESRInfo(CudbgDevice dev, uint32_t vsm, uint32_t wp, CudbgSMState_t *state, uint64_t warpPc)
{
    /* Not used on Fermi */
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_setupSingleStepNsteps(CudbgDevice dev, uint32_t vsm, CUwarpBitmask *warpMask, uint32_t nsteps, uint32_t *nstepsold)
{
    CUDBGResult res;
    Context context = dev->activeContext;
    uint32_t wp;

    /* If no active context, there is nothing we can do. */
    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "No active context found in setupSingleStepNsteps.\n");

    CUDBG_VERIFY(warpMask && nstepsold, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
        /* Skip warps that are not being single stepped */
        if (!warpBitmaskGetBits(warpMask, wp, 1))
            continue;

        res = dev->halo.scratchpad.read_singleStepNSteps(context->scratchpadAccessor, vsm, wp, nstepsold);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read single step N steps\n");

        res = dev->halo.scratchpad.write_singleStepNSteps(context->scratchpadAccessor, vsm, wp, nsteps);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to write single step N steps\n");
    }

    return CUDBG_SUCCESS;
}

/* Called to manage local caching of memory accesses (reducing BAR1 contention) */
static CUDBGResult
fermi_contextCommonDataCacheOp(Context ctx, HaloMemorySegmentCacheOp op)
{
    CUDBGResult res = CUDBG_SUCCESS;

    /* Locally cache the scratchpad when possible */

    /* ctx->scratchpadDevVA == ~0 when invalid */
    if (ctx->scratchpadDevVA != ~0ULL) {
        HALO_TRACE(40, "context %p cache op %d scratchpad len %d devvaddr 0x%" PRIx64 "\n",
                   ctx,
                   op,
                   ctx->dev->halo.deviceInfo.scratchpadSize,
                   ctx->scratchpadDevVA);

        res = haloMemoryRangeCacheOp(ctx->memMap, ctx->scratchpadDevVA,
                                     ctx->dev->halo.deviceInfo.scratchpadSize, op);
        if (res != CUDBG_SUCCESS) {
            HALO_TRACE(40, "scratchpad cache op failed\n");
            return res;
        }
    }

    /* Cache the scratchpad in the accessor (read-only) */
    res = haloStateContextScratchpadCacheOp(ctx, op);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE(40, "scratchpad accessor cache op failed\n");
        return res;
    }

    /* caching of instruction info */
    res = haloStateContextInsnInfoCacheOp(ctx, op);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE(40, "instruction info cache op failed\n");
        return res;
    }

    return CUDBG_SUCCESS;
}

CUDBGResult
fermi_convertPhysicalToVirtual(Halo_st *halo, uint32_t tpc, uint32_t phys_wp, uint32_t cta_id, uint32_t* vsm, uint32_t* vwp, uint32_t* vcta_id)
{
    if (vsm)
        *vsm = tpc;
    if (vwp)
        *vwp = phys_wp;
    if (vcta_id)
        *vcta_id = cta_id;

    return CUDBG_SUCCESS;
}

CUDBGResult
fermi_convertVirtualToPhysical(Halo_st *halo, uint32_t vsm, uint32_t vwp, uint32_t vcta_id, uint32_t* tpc, uint32_t* phys_wp, uint32_t* cta_id)
{
    if (tpc)
        *tpc = vsm;
    if (phys_wp)
        *phys_wp = vwp;
    if (cta_id)
        *cta_id = vcta_id;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_getWarpMaskPRIOffset(CudbgDevice dev, HaloMaskPRI pri, uint32_t wordIndex, uint32_t *reg)
{
    CUDBG_VERIFY(wordIndex < 4, CUDBG_ERROR_INVALID_ARGS, "Invalid wordIndexset\n");
    switch (pri) {
    case HALO_MASK_PRI_WARP_VALID:
        switch (wordIndex) {
        case 0:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_WARP_VALID_MASK_0;
            break;
        case 1:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_WARP_VALID_MASK_1;
            break;
        case 2:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_WARP_VALID_MASK_2;
            break;
        case 3:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_WARP_VALID_MASK_3;
            break;
        }
        break;
    case HALO_MASK_PRI_BPT_PAUSE:
        switch (wordIndex) {
        case 0:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_PAUSE_MASK_0;
            break;
        case 1:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_PAUSE_MASK_1;
            break;
        case 2:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_PAUSE_MASK_2;
            break;
        case 3:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_PAUSE_MASK_3;
            break;
        }
        break;
    case HALO_MASK_PRI_BPT_TRAP:
        switch (wordIndex) {
        case 0:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_TRAP_MASK_0;
            break;
        case 1:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_TRAP_MASK_1;
            break;
        case 2:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_TRAP_MASK_2;
            break;
        case 3:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_TRAP_MASK_3;
            break;
        }
        break;
    case HALO_MASK_PRI_INVALID:
    default:
        HALO_ERROR("Invalid requested PRI\n");
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

CUDBGResult
fermi_readWarpMaskPRI(CudbgDevice dev, uint32_t vsm, HaloRegOpType type, HaloMaskPRI pri, CUwarpBitmask *mask)
{
    uint64_t val = 0;
    uint32_t i = 0, reg = 0;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(dev && mask, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    warpBitmaskClear(mask);

    /* Round up as Fermi has 48 warps/TPC */
    for (i=0; i < (dev->halo.deviceInfo.numWarpsPrTPC + 63) / 64; ++i) {
        res = dev->halo.getWarpMaskPRIOffset(dev, pri, 2*i, &reg);
        if (res != CUDBG_SUCCESS)
            return res;

        res = dev->haloClient->readReg64(dev, type, dev->priBase[vsm] + reg, &val);
        if (res != CUDBG_SUCCESS)
            return res;

        warpBitmaskSetBits(mask, 64*i, 64, val);
    }

    return res;
}

CUDBGResult
fermi_writeWarpMaskPRI(CudbgDevice dev, uint32_t vsm, HaloRegOpType type, HaloMaskPRI pri, CUwarpBitmask *mask)
{
    uint64_t val = 0;
    uint32_t reg = 0, i = 0;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(dev && mask, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    /* Round up as Fermi has 48 warps/TPC */
    for (i=0; i < (dev->halo.deviceInfo.numWarpsPrTPC + 63) / 64; ++i) {
        val = warpBitmaskGetBits(mask, 64*i, 64);

        res = dev->halo.getWarpMaskPRIOffset(dev, pri, 2*i, &reg);
        if (res != CUDBG_SUCCESS)
            return res;

        res = dev->haloClient->writeReg64(dev, type, dev->priBase[vsm] + reg, &val);
        if (res != CUDBG_SUCCESS)
            return res;
    }

    return res;
}

static CUDBGResult
fermi_invalidateSMState(CudbgDevice dev, uint32_t vsm)
{
    dev->smState[vsm].valid = 0;
    dev->smState[vsm].state.floorsweptSmIdValid = 0;
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_getTexDptrMask(CudbgDevice dev, uint64_t *mask)
{
    *mask = (1ULL << 40) - 1ULL;
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_cilpForceFullSuspend(CudbgDevice dev, uint32_t *hasStopped, uint32_t *waitForEvent)
{
    *waitForEvent = 0;

    return CUDBG_SUCCESS;
}

CUDBGResult
fermi_preemptPreHook(CudbgDevice dev, int32_t vsm)
{
    return CUDBG_SUCCESS;
}

CUDBGResult
fermi_preemptPostHook(CudbgDevice dev, int32_t vsm)
{
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_setPreemptCommand(Context ctx, uint32_t preemptcmd)
{
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_getPRIOffset(CudbgDevice dev, HaloPRI pri, int32_t vsm, uint32_t *offset)
{
    CUDBG_VERIFY(offset, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");
    uint32_t priOffset = 0;

    *offset = 0;

    if (vsm < 0) {
        switch(pri) {
        case HALO_PRI_SM_DBGR_CONTROL0:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_SM_DBGR_CONTROL0;
            break;
        case HALO_PRI_SM_DBGR_STATUS0:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_SM_DBGR_STATUS0;
            break;
        case HALO_PRI_SM_HWW_WARP_ESR:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_SM_HWW_WARP_ESR;
            break;
        case HALO_PRI_SM_HWW_GLOBAL_ESR:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_SM_HWW_GLOBAL_ESR;
            break;
        case HALO_PRI_L1C_HWW_ESR:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_L1C_HWW_ESR;
            break;
        case HALO_PRI_L1C_HWW_ESR_ADDR:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_L1C_HWW_ESR_ADDR;
            break;
        case HALO_PRI_L1C_HWW_ESR_REQ:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_L1C_HWW_ESR_REQ;
            break;
        case HALO_PRI_SM_CACHE_CONTROL:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_SM_CACHE_CONTROL;
            break;
        case HALO_PRI_TPCCS_TPC_EXCEPTION:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_TPCCS_TPC_EXCEPTION;
            break;
        case HALO_PRI_TPCCS_TPC_EXCEPTION_EN:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_TPCCS_TPC_EXCEPTION_EN;
            break;
        case HALO_PRI_PD_LMEM_SIZE_PER_SM:
            priOffset = NV_PGRAPH_PRI_PD_LMEM_SIZE_PER_SM;
            break;
        case HALO_PRI_SM_HWW_GLOBAL_ESR_REPORT_MASK:
            priOffset = NV_PGRAPH_PRI_GPCS_TPCS_SM_HWW_GLOBAL_ESR_REPORT_MASK;
            break;
        default:
            HALO_ERROR("Failed to map PRIOffset\n");
            return CUDBG_ERROR_INVALID_ARGS;
        }
        *offset = priOffset + (uint32_t)(uintptr_t)dev->bar0;
    }
    else {
        switch(pri) {
        case HALO_PRI_SM_DBGR_CONTROL0:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_CONTROL0;
            break;
        case HALO_PRI_SM_DBGR_STATUS0:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_STATUS0;
            break;
        case HALO_PRI_SM_HWW_WARP_ESR:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_SM_HWW_WARP_ESR;
            break;
        case HALO_PRI_SM_HWW_GLOBAL_ESR:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_SM_HWW_GLOBAL_ESR;
            break;
        case HALO_PRI_L1C_HWW_ESR:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_L1C_HWW_ESR;
            break;
        case HALO_PRI_L1C_HWW_ESR_ADDR:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_L1C_HWW_ESR_ADDR;
            break;
        case HALO_PRI_L1C_HWW_ESR_REQ:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_L1C_HWW_ESR_REQ;
            break;
        case HALO_PRI_SM_CACHE_CONTROL:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_SM_CACHE_CONTROL;
            break;
        case HALO_PRI_TPCCS_TPC_EXCEPTION:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_TPCCS_TPC_EXCEPTION;
            break;
        case HALO_PRI_TPCCS_TPC_EXCEPTION_EN:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_TPCCS_TPC_EXCEPTION_EN;
            break;
        case HALO_PRI_PD_LMEM_SIZE_PER_SM:
            priOffset = NV_PGRAPH_PRI_PD_LMEM_SIZE_PER_SM;
            break;
        case HALO_PRI_SM_HWW_GLOBAL_ESR_REPORT_MASK:
            priOffset = NV_PGRAPH_PRI_GPC0_TPC0_SM_HWW_GLOBAL_ESR_REPORT_MASK;
            break;
        default:
            HALO_ERROR("Failed to map PRIOffset\n");
            return CUDBG_ERROR_INVALID_ARGS;
        }
        *offset = priOffset + (uint32_t)(uintptr_t)dev->priBase[vsm];
    }

    return CUDBG_SUCCESS;
}

/*
 * Iterate through all vsms and clear out the state structure.
 */
static CUDBGResult
fermi_clearSMState(CudbgDevice dev)
{
    uint32_t vsm, wp;

    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_DEVICE, "Invalid device in haloClearSMState.\n");

    for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
        for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
            HaloCRS_t *warpCRS = &dev->smState[vsm].warp[wp].CRS;
            if (warpCRS->numEntries > 0) {
                HALO_TRACE(5, "CRS field deallocation for dev 0x%" PRIx64 " vsm%d/wp%d: "
                           "numEntries = %d\n", dev, vsm, wp, warpCRS->numEntries);
                free(warpCRS->flatCRS);
                free(warpCRS->pc);
                free(warpCRS->mask);
                free(warpCRS->type);
                free(warpCRS->xsum);
            }
        }
        memset(&dev->smState[vsm], 0, sizeof dev->smState[vsm]);
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult 
fermi_getNumRegistersForGrid (Context context, Grid grid, uint32_t *numRegs)
{
    CUDBG_VERIFY(numRegs && grid && grid->function, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");
    *numRegs = grid->function->nrofRegisters;
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_needsProfilerObject (CudbgDevice dev, bool *needsProfilerObject)
{
    /* Needed as a replacement for NV_PGRAPH_PRI_GPCS_TPCS_SM_CG PRIs for HW Bug 635263 */
    *needsProfilerObject = true;
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_readExitedMask(CudbgDevice dev, uint32_t vsm, uint32_t tid, uint32_t *mask)
{
    HaloCRS_t *warpCRS = &dev->smState[vsm].warp[tid].CRS;
    *mask = warpCRS->mask[warpCRS->disExitIdx];
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_getFloorsweptSmIdFromSubcontext(CudbgDevice dev, uint32_t subcontextSmId, uint32_t *floorsweptSmId)
{
    CUDBG_VERIFY(floorsweptSmId, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");
    *floorsweptSmId = subcontextSmId;
    return CUDBG_SUCCESS;
}

/* Scratchpad access */

static CUDBGResult
fermi_scratchpad_getGlobalFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_SCRATCHPAD_GET_OFFSET_CASE(ACTIVE, FermiScratchpad_t, active);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PADDING, FermiScratchpad_t, padding);
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_scratchpad_getWarpFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_SCRATCHPAD_GET_OFFSET_CASE(VIRT_ID, FermiWarpScratchpad_t, virtID);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(CTA_PARAM, FermiWarpScratchpad_t, ctaParam);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_IDX_X, FermiWarpScratchpad_t, blockIdxX);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_IDX_Y, FermiWarpScratchpad_t, blockIdxY);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_IDX_Z, FermiWarpScratchpad_t, blockIdxZ);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_DIM_X, FermiWarpScratchpad_t, blockDimX);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_DIM_Y, FermiWarpScratchpad_t, blockDimY);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_DIM_Z, FermiWarpScratchpad_t, blockDimZ);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_PARAM, FermiWarpScratchpad_t, gridParam);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_DIM_X, FermiWarpScratchpad_t, gridDimX);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_DIM_Y, FermiWarpScratchpad_t, gridDimY);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_DIM_Z, FermiWarpScratchpad_t, gridDimZ);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SHMEM_SIZE_PR_BLOCK, FermiWarpScratchpad_t, shmemSizePrBlock);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_WINDOW_SIZE, FermiWarpScratchpad_t, lmemWindowSize);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_LO_SIZE_PR_THREAD, FermiWarpScratchpad_t, lmemLoSizePrThread);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_HI_OFF, FermiWarpScratchpad_t, lmemHiOff);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GLOBAL_ERROR_STATUS, FermiWarpScratchpad_t, globalErrorStatus);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_ERROR_STATUS, FermiWarpScratchpad_t, warpErrorStatus);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PARAM_CONST_DPTR_LO, FermiWarpScratchpad_t, paramConstDptrLo);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PARAM_CONST_DPTR_HI, FermiWarpScratchpad_t, paramConstDptrHi);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SINGLESTEP_NSTEPS, FermiWarpScratchpad_t, singleStepNsteps);
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_scratchpad_getLaneFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_SCRATCHPAD_GET_OFFSET_CASE(THREAD_IDX, FermiLaneScratchpad_t, threadIdx);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(R1, FermiLaneScratchpad_t, r1);
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_scratchpad_getFieldOffset(HaloScratchpadField field, HaloScratchpadSection section,
    uint32_t sm, uint32_t wp, uint32_t ln, size_t *offset, size_t *width)
{
    size_t base = 0;
    CUDBGResult res;

    switch (section) {
    case HALO_SCRATCHPAD_SECTION_GLOBAL:
        res = fermi_scratchpad_getGlobalFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_SCRATCHPAD_SECTION_WARP:
        base = OFFSETOF_NONCONST(FermiScratchpad_t, warp[sm][wp]);
        res = fermi_scratchpad_getWarpFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_SCRATCHPAD_SECTION_LANE:
        base = OFFSETOF_NONCONST(FermiScratchpad_t, warp[sm][wp]) +
               OFFSETOF_NONCONST(FermiWarpScratchpad_t, lane[ln]);
        res = fermi_scratchpad_getLaneFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    default:
        *offset = 0;
        *width = 0;
        HALO_TRACE_FUNCTION(0, "Invalid scratchpad section %d\n", section);
        return CUDBG_ERROR_INVALID_ARGS;
    };

    *offset += base;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_scratchpad_read_active(HaloScratchpadAccessor scratchpadAccessor, uint32_t *active)
{
    CUDBG_VERIFY(scratchpadAccessor && active, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, GLOBAL, ACTIVE, 0, 0, 0, active);

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_stub_scratchpad_read_pauseServicedMask(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, CUwarpBitmask *pauseServicedMask)
{
    CUDBG_VERIFY(scratchpadAccessor && pauseServicedMask, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_scratchpad_read_pauseServicedMask_raw(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint64_t *pauseServicedMask)
{
    CUDBG_VERIFY(scratchpadAccessor && pauseServicedMask, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_scratchpad_read_smIds(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *virtCTAID, uint32_t *floorsweptSmId)
{
    uint32_t value;

    CUDBG_VERIFY(scratchpadAccessor && virtCTAID && floorsweptSmId, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, VIRT_ID, vsm, wp, 0, &value);
    *virtCTAID = value >> 16 & 0xF;
    *floorsweptSmId = value >> 20 & 0xFF;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_scratchpad_read_CRSSize(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *crsSize)
{
    CUDBG_VERIFY(scratchpadAccessor && crsSize, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, CTA_PARAM, vsm, wp, 0, crsSize);

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_scratchpad_read_blockIdx(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, CuDim3 *blockIdx)
{
    uint32_t value;

    CUDBG_VERIFY(scratchpadAccessor && blockIdx, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, BLOCK_IDX_X, vsm, wp, 0, &value);
    blockIdx->x = value & 0xFFFF;

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, BLOCK_IDX_Y, vsm, wp, 0, &value);
    blockIdx->y = value & 0xFFFF;

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, BLOCK_IDX_Z, vsm, wp, 0, &value);
    blockIdx->z = value & 0xFFFF;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_scratchpad_read_blockDim(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, CuDim3 *blockDim)
{
    uint32_t value;

    CUDBG_VERIFY(scratchpadAccessor && blockDim, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, BLOCK_DIM_X, vsm, wp, 0, &value);
    blockDim->x = value & 0xFFFF;

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, BLOCK_DIM_Y, vsm, wp, 0, &value);
    blockDim->y = value & 0xFFFF;

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, BLOCK_DIM_Z, vsm, wp, 0, &value);
    blockDim->z = value & 0xFFFF;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_scratchpad_read_gridId(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint64_t *gridId)
{
    uint32_t gridId32 = 0;

    CUDBG_VERIFY(scratchpadAccessor && gridId, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, GRID_PARAM, vsm, wp, 0, &gridId32);
    *gridId = (uint64_t)gridId32;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_scratchpad_read_gridDim(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, CuDim3 *gridDim)
{
    uint32_t value;

    CUDBG_VERIFY(scratchpadAccessor && gridDim, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, GRID_DIM_X, vsm, wp, 0, &value);
    gridDim->x = value & 0xFFFF;

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, GRID_DIM_Y, vsm, wp, 0, &value);
    gridDim->y = value & 0xFFFF;

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, GRID_DIM_Z, vsm, wp, 0, &value);
    gridDim->z = value & 0xFFFF;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_scratchpad_read_CTASharedSize(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *CTASharedSize)
{
    uint32_t value;

    CUDBG_VERIFY(scratchpadAccessor && CTASharedSize, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, SHMEM_SIZE_PR_BLOCK, vsm, wp, 0, &value);
    *CTASharedSize = value & 0xFFFFFF;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_scratchpad_read_lmemWindowSize(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *lmemWindowSize)
{
    CUDBG_VERIFY(scratchpadAccessor && lmemWindowSize, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, LMEM_WINDOW_SIZE, vsm, wp, 0, lmemWindowSize);

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_scratchpad_read_lmemLoSizePrThread(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *lmemLoSizePrThread)
{
    CUDBG_VERIFY(scratchpadAccessor && lmemLoSizePrThread, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, LMEM_LO_SIZE_PR_THREAD, vsm, wp, 0, lmemLoSizePrThread);

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_scratchpad_read_lmemHiOff(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *lmemHiOff)
{
    CUDBG_VERIFY(scratchpadAccessor && lmemHiOff, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, LMEM_HI_OFF, vsm, wp, 0, lmemHiOff);

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_scratchpad_read_globalErrorStatus(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *globalErrorStatus)
{
    CUDBG_VERIFY(scratchpadAccessor && globalErrorStatus, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, GLOBAL_ERROR_STATUS, vsm, wp, 0, globalErrorStatus);

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_scratchpad_read_warpErrorStatus(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *warpErrorStatus)
{
    CUDBG_VERIFY(scratchpadAccessor && warpErrorStatus, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, WARP_ERROR_STATUS, vsm, wp, 0, warpErrorStatus);

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_stub_scratchpad_read_isWarpOnBarrier(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, bool *isWarpOnBarrier)
{
    CUDBG_VERIFY(scratchpadAccessor && isWarpOnBarrier, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_scratchpad_read_selfQMD(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint64_t *selfQMDdptr)
{
    CUDBG_VERIFY(scratchpadAccessor && selfQMDdptr, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    *selfQMDdptr = 0;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_scratchpad_read_paramConstDptr(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint64_t *paramConstDptr)
{
    uint32_t paramConstDptrHi, paramConstDptrLo;

    CUDBG_VERIFY(scratchpadAccessor && paramConstDptr, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, PARAM_CONST_DPTR_HI, vsm, wp, 0, &paramConstDptrHi);
    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, PARAM_CONST_DPTR_LO, vsm, wp, 0, &paramConstDptrLo);
    *paramConstDptr = ((uint64_t)paramConstDptrHi << 32) | paramConstDptrLo;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_stub_scratchpad_read_lmemBase(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint64_t *lmemBase)
{
    CUDBG_VERIFY(scratchpadAccessor && lmemBase, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_scratchpad_read_CRSPtr(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *crsPtr)
{
    CUDBG_VERIFY(scratchpadAccessor && crsPtr, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_scratchpad_read_curPhysStackDepth(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *curPhysStackDepth)
{
    CUDBG_VERIFY(scratchpadAccessor && curPhysStackDepth, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_scratchpad_read_mpsContextId(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *mpsContextId)
{
    CUDBG_VERIFY(scratchpadAccessor && mpsContextId, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_scratchpad_read_subcontextVSMId(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *subcontextVSMId)
{
    CUDBG_VERIFY(scratchpadAccessor && subcontextVSMId, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_scratchpad_read_singleStepNSteps(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *nsteps)
{
    CUDBG_VERIFY(scratchpadAccessor && nsteps, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, SINGLESTEP_NSTEPS, vsm, wp, 0, nsteps);

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_stub_scratchpad_read_validOnSaveWarpFlag(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint8_t *validOnSaveWarpFlag)
{
    CUDBG_VERIFY(scratchpadAccessor && validOnSaveWarpFlag, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");
    
        return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_scratchpad_read_pauseServicedWarpFlag(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint8_t *pauseServicedWarpFlag)
{
    CUDBG_VERIFY(scratchpadAccessor && pauseServicedWarpFlag, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_scratchpad_read_registerCount(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *registerCount)
{
    CUDBG_VERIFY(scratchpadAccessor && registerCount, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_scratchpad_read_warpActiveMask(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *warpActiveMask)
{
    CUDBG_VERIFY(scratchpadAccessor && warpActiveMask, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_scratchpad_read_warpExitedMask(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t *warpExitedMask)
{
    CUDBG_VERIFY(scratchpadAccessor && warpExitedMask, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_scratchpad_read_warpTrapRPC(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint64_t *pc)
{
    CUDBG_VERIFY(scratchpadAccessor && pc, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_scratchpad_read_threadIdx(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t lane, CuDim3 *threadIdx)
{
    uint32_t packedThreadIdx;

    CUDBG_VERIFY(scratchpadAccessor && threadIdx, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, LANE, THREAD_IDX, vsm, wp, lane, &packedThreadIdx);

    /* X (10:0), Y (25:16), Z (31:26) */
    threadIdx->x = packedThreadIdx & 0x7FF;
    threadIdx->y = (packedThreadIdx >> 16) & 0x3FF;
    threadIdx->z = packedThreadIdx >> 26;

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_scratchpad_read_r1(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t lane, uint32_t *r1)
{
    CUDBG_VERIFY(scratchpadAccessor && r1, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, LANE, R1, vsm, wp, lane, r1);

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_scratchpad_write_active(HaloScratchpadAccessor scratchpadAccessor, uint32_t active)
{
    CUDBG_VERIFY(scratchpadAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_SET_FIELD(scratchpadAccessor, GLOBAL, ACTIVE, 0, 0, 0, &active);

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_canSkipSingleStepOverExitWAR(bool *skip)
{
    /* Bug 1820001: In single step mode for Turing+ chips, the SM is
       guaranteed to trap even before the execution of the first
       instruction. This allows us to skip the special handling for the EXIT
       instruction. */

    *skip = false;
    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_stub_scratchpad_write_preemptCommand(HaloScratchpadAccessor scratchpadAccessor, uint32_t preemptCommand)
{
    CUDBG_VERIFY(scratchpadAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_scratchpad_write_WAR_runTrigger1239649(HaloScratchpadAccessor scratchpadAccessor, uint32_t warRunTriggerFlagValue)
{
    CUDBG_VERIFY(scratchpadAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_scratchpad_write_pauseServicedMask_raw(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint64_t pauseServicedMask)
{
    CUDBG_VERIFY(scratchpadAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_scratchpad_write_singleStepNSteps(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint32_t nsteps)
{
    CUDBG_VERIFY(scratchpadAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_SET_FIELD(scratchpadAccessor, WARP, SINGLESTEP_NSTEPS, vsm, wp, 0, &nsteps);

    return CUDBG_SUCCESS;
}

static CUDBGResult
fermi_stub_scratchpad_write_pauseServicedWarpFlag(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint8_t pauseServicedWarpFlag)
{
    CUDBG_VERIFY(scratchpadAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_scratchpad_write_warpTrapRPC(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint64_t pc)
{
    CUDBG_VERIFY(scratchpadAccessor && pc, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

/* Preemption buffer access */

static CUDBGResult
fermi_stub_preemptionBuffer_getFieldOffset(HaloPreemptionBufferField field, HaloPreemptionBufferSection section,
    uint32_t sm, uint32_t cta, uint32_t wp, uint32_t ln,
    size_t *offset, size_t *width)
{
    HALO_ERROR("No preemption buffer in Fermi\n");
    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_preemptionBuffer_getRegOffset(struct Halo_st *halo, HaloPreemptionBufferAccessor preemptionBufferAccessor,
    uint32_t sm, uint32_t wp, uint32_t ln, uint32_t regnum, uint32_t numRegs, uint32_t *pRegOffset)
{
    HALO_ERROR("No preemption buffer in Fermi\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
fermi_stub_preemptionBuffer_getSwizzledRegOffset(uint32_t ln, uint32_t regnum, uint32_t numRegs, uint32_t *regOffset)
{
    HALO_ERROR("No preemption buffer in Fermi\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
fermi_stub_preemptionBuffer_read_RFDataIdxSync(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t *rfDataIdxSync)
{
    CUDBG_VERIFY(preemptionBufferAccessor && rfDataIdxSync, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported preemption buffer field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_preemptionBuffer_read_shmemDataIdxSync(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t *shmemDataIdxSync)
{
    CUDBG_VERIFY(preemptionBufferAccessor && shmemDataIdxSync, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported preemption buffer field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_preemptionBuffer_read_shmemDataIdx(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t cta, uint32_t *shmemDataIdx)
{
    CUDBG_VERIFY(preemptionBufferAccessor && shmemDataIdx, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported preemption buffer field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_preemptionBuffer_read_RFDataIdx(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *rfDataIdx)
{
    CUDBG_VERIFY(preemptionBufferAccessor && rfDataIdx, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported preemption buffer field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_preemptionBuffer_read_warpExitedMask(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *warpExitedMask)
{
    CUDBG_VERIFY(preemptionBufferAccessor && warpExitedMask, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported preemption buffer field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_preemptionBuffer_read_UPR(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *upr)
{
    CUDBG_VERIFY(preemptionBufferAccessor && upr, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported preemption buffer field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_preemptionBuffer_read_PR(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t lane, uint8_t *pr)
{
    CUDBG_VERIFY(preemptionBufferAccessor && pr, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported preemption buffer field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_preemptionBuffer_read_CC(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t lane, uint8_t *cc)
{
    CUDBG_VERIFY(preemptionBufferAccessor && cc, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported preemption buffer field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_preemptionBuffer_read_RPC(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t lane, uint64_t *rpc)
{
    CUDBG_VERIFY(preemptionBufferAccessor && rpc, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported preemption buffer field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_preemptionBuffer_write_RFDataIdxSync(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t rfDataIdxSync)
{
    CUDBG_VERIFY(preemptionBufferAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported preemption buffer field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_preemptionBuffer_write_shmemDataIdxSync(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t shmemDataIdxSync)
{
    CUDBG_VERIFY(preemptionBufferAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported preemption buffer field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_preemptionBuffer_write_warpTrapRPC(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint64_t warpTrapRPC)
{
    CUDBG_VERIFY(preemptionBufferAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported preemption buffer field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_preemptionBuffer_write_UPR(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t upr)
{
    CUDBG_VERIFY(preemptionBufferAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported preemption buffer field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_preemptionBuffer_write_PR(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t lane, uint8_t pr)
{
    CUDBG_VERIFY(preemptionBufferAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported preemption buffer field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_preemptionBuffer_write_CC(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t lane, uint8_t cc)
{
    CUDBG_VERIFY(preemptionBufferAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported preemption buffer field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_ldcWAR_getPatchReg(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                              uint32_t ln, uint32_t regno,
                              uint32_t *hasSpilled, uint32_t *regval)
{
    /* Not implemented on Fermi */
    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
fermi_stub_ldcWAR_setPatchReg(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                              uint32_t ln, uint32_t regno,
                              uint32_t *hasSpilled, const uint32_t *regval)
{
    /* Not implemented on Fermi */
    return CUDBG_ERROR_INVALID_DEVICE;
}

/* Populate the debugger structure with Fermi specific functions. */
void
haloDeviceInit_gf100(Halo_st *halo)
{
    /* architectural constants */
    halo->deviceInfo.lmemSavedReturnPC = 0;
    halo->deviceInfo.lmemSavedMExited = 0;
    halo->deviceInfo.rpcRegisterNumber = 0;
    halo->deviceInfo.spRegisterNumber = FERMI_ABI_SP_REGNUM;
    halo->deviceInfo.systemStackPointer = FERMI_LMEM_SAVED_STACK_POINTER;
    halo->deviceInfo.cilpBufferSizePerSM = 0;
    halo->deviceInfo.scratchpadSize = sizeof(FermiScratchpad_t);
    halo->deviceInfo.lmemHiMemcheckScratch = FERMI_LMEM_HI_MEMCHECK_SCRATCH;
    halo->deviceInfo.lmemHiMemcheckScratchSize = FERMI_LMEM_HI_MEMCHECK_SCRATCH_SIZE;
    halo->deviceInfo.lmemMemcheckMagic = FERMI_LMEM_MEMCHECK_MAGIC;

    /* architectural methods */
    halo->readSMState = fermi_readSMState;
    halo->readSMWarpMasks = fermi_readSMWarpMasks;
    halo->readSMWarpMasksFromScratchpad = fermi_stub_readSMWarpMasksFromScratchpad;
    halo->writeBreakpointMask = fermi_writeBreakpointMask;
    halo->readActiveMask = fermi_readActiveMask;
    halo->adjustActiveMask = fermi_adjustActiveMask;
    halo->readPC = fermi_readPC;
    halo->writePC = fermi_writePC;
    halo->getLmemInternalOffset = fermi_getLmemInternalOffset;
    halo->getCRSInternalOffset = fermi_getCRSInternalOffset;
    halo->readLmemConfig = fermi_readLmemConfig;
    halo->CRSEntrySize = fermi_CRSEntrySize;
    halo->CRSEntryPaddingSize = fermi_CRSEntryPaddingSize;
    halo->maxCRSEntriesPerWarp = fermi_maxCRSEntriesPerWarp;
    halo->collectWarpCRS = fermi_collectWarpCRS;
    halo->getWarpCRSUsage = fermi_getWarpCRSUsage;
    halo->flattenCRS = fermi_flattenCRS;
    halo->updateCRS = fermi_updateCRS;
    halo->findDivergedCRS_Entry = fermi_findDivergedCRS_Entry;
    halo->findDivergedCRS_Mask = fermi_findDivergedCRS_Mask;
    halo->findDivergedCRS_PC = fermi_findDivergedCRS_PC;
    halo->lookForActiveContext = fermi_lookForActiveContext;
    halo->readAndResetContextActiveBit = fermi_readAndResetContextActiveBit;
    halo->findActiveContext = fermi_findActiveContext;
    halo->singleStep = fermi_singleStep;
    halo->getInfo = fermi_getInfo;
    halo->read_threadIdx = fermi_read_threadIdx;
    halo->read_warpParams = fermi_read_warpParams;
    halo->read_blockIdx = fermi_read_blockIdx;
    halo->isSteppable = fermi_isSteppable;
    halo->isInternalInstructionAtPC = fermi_isInternalInstructionAtPC;
    halo->isTerminalInstructionAtPC = fermi_isTerminalInstructionAtPC;

    halo->readGenericMemory    = fermi_readGenericMemory;
    halo->readSharedMemory     = fermi_readSharedMemory;
    halo->readTextureMemory    = fermi_readTextureMemory;
    halo->readParamMemory      = fermi_readParamMemory;
    halo->readRegisterRange    = fermi_readRegisterRange;
    halo->readPredicates       = fermi_readPredicates;
    halo->readUniformRegisterFile = fermi_readUniformRegisterFile;
    halo->readUniformPredicates = fermi_readUniformPredicates;
    halo->readCCRegister       = fermi_readCCRegister;
    halo->readCallDepth        = fermi_readCallDepth;
    halo->readSyscallCallDepth = fermi_readSyscallCallDepth;
    halo->readReturnAddress = fermi_readReturnAddress;
    halo->patchTextureInstruction   = fermi_patchTextureInstruction;
    halo->getLmemOffsetForTexCoords = fermi_getLmemOffsetForTexCoords;

    halo->writeGenericMemory = fermi_writeGenericMemory;
    halo->writeSharedMemory = fermi_writeSharedMemory;
    halo->writeParamMemory  = fermi_writeParamMemory;
    halo->writeRegisterFile = fermi_writeRegisterFile;
    halo->writePredicates   = fermi_writePredicates;
    halo->writeUniformRegisterFile = fermi_writeUniformRegisterFile;
    halo->writeUniformPredicates = fermi_writeUniformPredicates;
    halo->writeCCRegister   = fermi_writeCCRegister;

    halo->getScratchpadSharedMemDevVaddr = fermi_getScratchpadSharedMemDevVaddr;

    halo->suspendDevice = fermi_suspendDevice;
    halo->resumeDevice = fermi_resumeDevice;
    halo->resumeDeviceViaPRIV = fermi_resumeDeviceViaPRIV;
    halo->suspendSM = fermi_suspendSM;
    halo->resumeSM = fermi_resumeSM;
    halo->waitForSMPause = fermi_waitForSMPause;
    halo->isAnyExceptionSet = fermi_isAnyExceptionSet;

    halo->enableMMUDebuggingMode = fermi_enableMMUDebuggingMode;
    halo->disableMMUDebuggingMode = fermi_disableMMUDebuggingMode;
    halo->disableMMUDebuggingModeForDevice = fermi_stub_disableMMUDebuggingModeForDevice;
    halo->forceTermination = fermi_forceTermination;

    halo->cleanup = fermi_cleanup;
    halo->getStepOverBPMask = fermi_getStepOverBPMask;

    halo->findConstBankOffset = fermi_findConstBankOffset;

    halo->clearExceptions = fermi_clearExceptions;

    halo->writePauseServicedMask = fermi_writePauseServicedMask;
    halo->readPauseServicedMask = fermi_readPauseServicedMask;
    halo->readSaveWarpMask = fermi_readSaveWarpMask;
    halo->thService = fermi_thService;
    halo->thServiceWriteInfo = fermi_thServiceWriteInfo;
    halo->thServicePostProcess = fermi_thServicePostProcess;
    halo->invalidateICache = fermi_invalidateICache;

    halo->mcinterop_getRegSpill = fermi_mcinterop_getRegSpill;
    halo->mcinterop_getPatchPC = fermi_mcinterop_getPatchPC;
    halo->mcinterop_getPatchReg = fermi_mcinterop_getPatchReg;
    halo->mcinterop_getPatchPred = fermi_mcinterop_getPatchPred;
    halo->mcinterop_getPatchCC = fermi_mcinterop_getPatchCC;
    halo->mcinterop_setPatchReg = fermi_mcinterop_setPatchReg;
    halo->mcinterop_setPatchPred = fermi_mcinterop_setPatchPred;
    halo->mcinterop_setPatchCC = fermi_mcinterop_setPatchCC;
    halo->mcinterop_getLDSTTargetAddr = fermi_mcinterop_getLDSTTargetAddr;
    halo->mcinterop_getSyscallError = fermi_mcinterop_getSyscallError;
    halo->mcinterop_getSyscallErrorData = fermi_mcinterop_getSyscallErrorData;
    halo->mcinterop_checkLane = fermi_mcinterop_checkLane;

    halo->findSyscallEntryPoint = fermi_findSyscallEntryPoint;
    halo->getSavedSPLmemAddr = fermi_getSavedSPLmemAddr;

    halo->readLaneServiceReason = fermi_readLaneServiceReason;

    /* GF1xx - Warp Exit functionality (WAR HW Bug) */
    halo->singleStepExit = fermi_singleStepLastWarpExit;
    halo->isLastHwStepSynchronous = fermi_isLastHwStepSynchronous;

#ifdef CUDBG_ENABLE_IFB
    halo->allocateIFB = fermi_allocateIFB;
    halo->readViaIFB = fermi_readViaIFB;
    halo->writeViaIFB = fermi_writeViaIFB;
#endif
    halo->findSyscallSP = fermi_findSyscallSP;

    halo->getPgraphBar0Extents  = fermi_getPgraphBar0Extents;

    halo->verifyCRSxsum = fermi_verifyCRSxsum;
    halo->handleGlobalErrorState = fermi_handleGlobalErrorState;
    halo->handleGlobalMMUErrorState = fermi_handleGlobalMMUErrorState;
    halo->handleWarpErrorState = fermi_handleWarpErrorState;
    halo->getBrokenWarps       = fermi_getBrokenWarps;
    halo->readSMESRInfo        = fermi_readSMESRInfo;
    halo->clearSMESRInfo       = fermi_clearSMESRInfo;
    halo->setKnownEvent        = fermi_setKnownEvent;

    halo->readUserEntryFramePC = fermi_readUserEntryFramePC;

    halo->getCCMasks = fermi_getCCMasks;

    halo->getGTASWindowAddresses = fermi_getGTASWindowAddresses;

    /* Base functions, (previously were in tesla.c) */
    halo->buildMappingTable = fermi_buildMappingTable;
    halo->checkAnyLaneInContinuation = fermi_checkAnyLaneInContinuation;
    halo->checkWarpNeedsHostResume = fermi_checkWarpNeedsHostResume;
    halo->controllerIlpSuspend = fermi_controllerIlpSuspend;
    halo->controllerIlpSetupMode = fermi_controllerIlpSetupMode;
    halo->controllerIlpSavedCount = fermi_controllerIlpSavedCount;
    halo->controllerIlpRestore = fermi_controllerIlpRestore;
    halo->disablePairingMode = fermi_disablePairingMode;
    halo->enablePairingMode = fermi_enablePairingMode;
    halo->fillDisassemblyBuffer = fermi_fillDisassemblyBuffer;
    halo->findNewHWCoords = fermi_findNewHWCoords;
    halo->findParentGrid     = fermi_findParentGrid;
    halo->getCrsPhysStackDepth = fermi_getCrsPhysStackDepth;
    halo->getCurrentGrCtxPtr = fermi_getCurrentGrCtxPtr;
    halo->getDynamicRegisterRange = fermi_getDynamicRegisterRange;
    halo->getGridParamsOffsetGridId   = fermi_getGridParamsOffsetGridId;
    halo->getGridParamsOffsetBlockDim = fermi_getGridParamsOffsetBlockDim;
    halo->getGridParamsOffsetGridDim  = fermi_getGridParamsOffsetGridDim;
    halo->getGridParamsOffsetStartPc  = fermi_getGridParamsOffsetStartPc;
    halo->getGridStatus = fermi_getGridStatus;
    halo->getLmemBase = fermi_getLmemBase;
    halo->getSMHwwErrorPC    = fermi_getSMHwwErrorPC;
    halo->getUserEntryFunction = fermi_getUserEntryFunction;
    halo->initiatePreemptionSave = fermi_initiatePreemptionSave;
    halo->initiatePreemptionRestore = fermi_initiatePreemptionRestore;
    halo->insertBreakpoint = fermi_insertBreakpoint;
    halo->isReservedGridId = fermi_isReservedGridId;
    halo->isWarpEnabledForPreempt = fermi_isWarpEnabledForPreempt;
    halo->isWarpOnBarrier = fermi_isWarpOnBarrier;
    halo->membarWAR_getPatchPC  = fermi_membarWAR_getPatchPC;
    halo->membarWAR_getPatchReg = fermi_membarWAR_getPatchReg;
    halo->membarWAR_getPatchPred = fermi_membarWAR_getPatchPred;
    halo->membarWAR_getPatchCC = fermi_membarWAR_getPatchCC;
    halo->membarWAR_setPatchReg = fermi_membarWAR_setPatchReg;
    halo->membarWAR_setPatchPred = fermi_membarWAR_setPatchPred;
    halo->membarWAR_setPatchCC = fermi_membarWAR_setPatchCC;
    halo->membarWAR_getPatchCallDepth = fermi_membarWAR_getPatchCallDepth;
    halo->checkForHwWar = fermi_checkForHwWar;
    halo->barWAR_getPatchPC  = fermi_barWAR_getPatchPC;
    halo->patchDynamicRegisterRead = fermi_patchDynamicRegisterRead;
    halo->patchDynamicRegisterWrite = fermi_patchDynamicRegisterWrite;
    halo->preemptChannelGroup = fermi_preemptChannelGroup;
    halo->readRegCtaCtx = fermi_readRegCtaCtx;
    halo->scheduleChannelGroup = fermi_scheduleChannelGroup;
    halo->setChannelGroupTimeslice = fermi_setChannelGroupTimeslice;
    halo->setupIlpSave = fermi_setupIlpSave;
    halo->restoreWarpMasks = fermi_restoreWarpMasks;
    halo->waitForGrCtxSave = fermi_waitForGrCtxSave;
    halo->releaseSharedResources = fermi_releaseSharedResources;
    halo->readWarpCtaCtxAddr = fermi_readWarpCtaCtxAddr;
    halo->setLmemBaseCtaCtx = fermi_setLmemBaseCtaCtx;
    halo->readSharedMemCtaCtx = fermi_readSharedMemCtaCtx;
    halo->writeSharedMemCtaCtx = fermi_writeSharedMemCtaCtx;
    halo->writeRegCtaCtx = fermi_writeRegCtaCtx;
    halo->readSMWarpESRInfo = fermi_readSMWarpESRInfo;
    halo->readTextureMemoryUsingTexHeader = fermi_readTextureMemoryUsingTexHeader;
    halo->removeBreakpoint = fermi_removeBreakpoint;
    halo->resumeWarps   = fermi_resumeWarps;
    halo->rewindBrokenWarp = fermi_rewindBrokenWarp;
    halo->setPowerGatingState = fermi_setPowerGatingState;
    halo->setWarpStateValid = fermi_setWarpStateValid;
    halo->updateSMESRInfo    = fermi_updateSMESRInfo;
    halo->setupSingleStepNsteps = fermi_setupSingleStepNsteps;
    halo->contextCommonDataCacheOp = fermi_contextCommonDataCacheOp;
    halo->fillRangeWithInstruction = fermi_fillRangeWithInstruction;
    halo->getWarpMaskPRIOffset = fermi_getWarpMaskPRIOffset;
    halo->readWarpMaskPRI = fermi_readWarpMaskPRI;
    halo->writeWarpMaskPRI = fermi_writeWarpMaskPRI;
    halo->convertPhysicalToVirtual = fermi_convertPhysicalToVirtual;
    halo->convertVirtualToPhysical = fermi_convertVirtualToPhysical;
    halo->invalidateSMState = fermi_invalidateSMState;
    halo->forceScratchpadLmemBase = fermi_forceScratchpadLmemBase;
    halo->getTexDptrMask = fermi_getTexDptrMask;
    halo->cilpForceFullSuspend = fermi_cilpForceFullSuspend;
    halo->getPauseReasonTableWarpOffset = fermi_getPauseReasonTableWarpOffset;
    halo->preemptPreHook = fermi_preemptPreHook;
    halo->preemptPostHook = fermi_preemptPostHook;
    halo->setPreemptCommand = fermi_setPreemptCommand;
    halo->findBreakpoint = fermi_findBreakpoint;
    halo->mapGpcTpcSm = fermi_mapGpcTpcSm;
    halo->getPRIOffset = fermi_getPRIOffset;
    halo->clearSMState = fermi_clearSMState;
    halo->getNumRegistersForGrid = fermi_getNumRegistersForGrid;
    halo->needsProfilerObject = fermi_needsProfilerObject;
    halo->getFloorsweptSmIdFromSubcontext = fermi_getFloorsweptSmIdFromSubcontext;
    halo->readExitedMask = fermi_readExitedMask;
    halo->canSkipSingleStepOverExitWAR = fermi_canSkipSingleStepOverExitWAR;

    /* Scratchpad access */

    halo->scratchpad.getFieldOffset = fermi_scratchpad_getFieldOffset;

    halo->scratchpad.read_active = fermi_scratchpad_read_active;
    halo->scratchpad.read_pauseServicedMask = fermi_stub_scratchpad_read_pauseServicedMask;
    halo->scratchpad.read_pauseServicedMask_raw = fermi_stub_scratchpad_read_pauseServicedMask_raw;
    halo->scratchpad.read_smIds = fermi_scratchpad_read_smIds;
    halo->scratchpad.read_CRSSize = fermi_scratchpad_read_CRSSize;
    halo->scratchpad.read_blockIdx = fermi_scratchpad_read_blockIdx;
    halo->scratchpad.read_blockDim = fermi_scratchpad_read_blockDim;
    halo->scratchpad.read_gridId = fermi_scratchpad_read_gridId;
    halo->scratchpad.read_gridDim = fermi_scratchpad_read_gridDim;
    halo->scratchpad.read_CTASharedSize = fermi_scratchpad_read_CTASharedSize;
    halo->scratchpad.read_lmemWindowSize = fermi_scratchpad_read_lmemWindowSize;
    halo->scratchpad.read_lmemLoSizePrThread = fermi_scratchpad_read_lmemLoSizePrThread;
    halo->scratchpad.read_lmemHiOff = fermi_scratchpad_read_lmemHiOff;
    halo->scratchpad.read_globalErrorStatus = fermi_scratchpad_read_globalErrorStatus;
    halo->scratchpad.read_warpErrorStatus = fermi_scratchpad_read_warpErrorStatus;
    halo->scratchpad.read_isWarpOnBarrier = fermi_stub_scratchpad_read_isWarpOnBarrier;
    halo->scratchpad.read_selfQMD = fermi_scratchpad_read_selfQMD;
    halo->scratchpad.read_paramConstDptr = fermi_scratchpad_read_paramConstDptr;
    halo->scratchpad.read_lmemBase = fermi_stub_scratchpad_read_lmemBase;
    halo->scratchpad.read_CRSPtr = fermi_stub_scratchpad_read_CRSPtr;
    halo->scratchpad.read_curPhysStackDepth = fermi_stub_scratchpad_read_curPhysStackDepth;
    halo->scratchpad.read_mpsContextId = fermi_stub_scratchpad_read_mpsContextId;
    halo->scratchpad.read_subcontextVSMId = fermi_stub_scratchpad_read_subcontextVSMId;
    halo->scratchpad.read_singleStepNSteps = fermi_scratchpad_read_singleStepNSteps;
    halo->scratchpad.read_validOnSaveWarpFlag = fermi_stub_scratchpad_read_validOnSaveWarpFlag;
    halo->scratchpad.read_pauseServicedWarpFlag = fermi_stub_scratchpad_read_pauseServicedWarpFlag;
    halo->scratchpad.read_registerCount = fermi_stub_scratchpad_read_registerCount;
    halo->scratchpad.read_warpActiveMask = fermi_stub_scratchpad_read_warpActiveMask;
    halo->scratchpad.read_warpExitedMask = fermi_stub_scratchpad_read_warpExitedMask;
    halo->scratchpad.read_warpTrapRPC = fermi_stub_scratchpad_read_warpTrapRPC;
    halo->scratchpad.read_threadIdx = fermi_scratchpad_read_threadIdx;
    halo->scratchpad.read_r1 = fermi_scratchpad_read_r1;

    halo->scratchpad.write_active = fermi_scratchpad_write_active;
    halo->scratchpad.write_preemptCommand = fermi_stub_scratchpad_write_preemptCommand;
    halo->scratchpad.write_WAR_runTrigger1239649 = fermi_stub_scratchpad_write_WAR_runTrigger1239649;
    halo->scratchpad.write_pauseServicedMask_raw = fermi_stub_scratchpad_write_pauseServicedMask_raw;
    halo->scratchpad.write_singleStepNSteps = fermi_scratchpad_write_singleStepNSteps;
    halo->scratchpad.write_pauseServicedWarpFlag = fermi_stub_scratchpad_write_pauseServicedWarpFlag;
    halo->scratchpad.write_warpTrapRPC = fermi_stub_scratchpad_write_warpTrapRPC;

    /* Preemption buffer access */
    
    halo->preemptionBuffer.getFieldOffset = fermi_stub_preemptionBuffer_getFieldOffset;
    halo->preemptionBuffer.getRegOffset = fermi_stub_preemptionBuffer_getRegOffset;
    halo->preemptionBuffer.getSwizzledRegOffset = fermi_stub_preemptionBuffer_getSwizzledRegOffset;

    halo->preemptionBuffer.read_RFDataIdxSync = fermi_stub_preemptionBuffer_read_RFDataIdxSync;
    halo->preemptionBuffer.read_shmemDataIdxSync = fermi_stub_preemptionBuffer_read_shmemDataIdxSync;
    halo->preemptionBuffer.read_shmemDataIdx = fermi_stub_preemptionBuffer_read_shmemDataIdx;
    halo->preemptionBuffer.read_RFDataIdx = fermi_stub_preemptionBuffer_read_RFDataIdx;
    halo->preemptionBuffer.read_warpExitedMask = fermi_stub_preemptionBuffer_read_warpExitedMask;
    halo->preemptionBuffer.read_UPR = fermi_stub_preemptionBuffer_read_UPR;
    halo->preemptionBuffer.read_PR = fermi_stub_preemptionBuffer_read_PR;
    halo->preemptionBuffer.read_CC = fermi_stub_preemptionBuffer_read_CC;
    halo->preemptionBuffer.read_RPC = fermi_stub_preemptionBuffer_read_RPC;

    halo->preemptionBuffer.write_RFDataIdxSync = fermi_stub_preemptionBuffer_write_RFDataIdxSync;
    halo->preemptionBuffer.write_shmemDataIdxSync = fermi_stub_preemptionBuffer_write_shmemDataIdxSync;
    halo->preemptionBuffer.write_warpTrapRPC = fermi_stub_preemptionBuffer_write_warpTrapRPC;
    halo->preemptionBuffer.write_UPR = fermi_stub_preemptionBuffer_write_UPR;
    halo->preemptionBuffer.write_PR = fermi_stub_preemptionBuffer_write_PR;
    halo->preemptionBuffer.write_CC = fermi_stub_preemptionBuffer_write_CC;

    /* LDC WAR */
    halo->ldcWAR_getPatchReg = fermi_stub_ldcWAR_getPatchReg;
    halo->ldcWAR_setPatchReg = fermi_stub_ldcWAR_setPatchReg;
}
