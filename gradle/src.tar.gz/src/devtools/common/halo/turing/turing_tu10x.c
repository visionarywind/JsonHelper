/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: turing_tu10x.c
 *
 *   Description:
 *       Internal API for the low-level GPU access needed to support
 *       the debugger on Turing (TU10x).
 *
 ******************************************************************************/

#include "cudadebugger.h"
#include "halo_internal.h"
#include "halo_state.h"
#include "tools_shared_dwarf.h"
#include "volta_gv10x.h"
#include "turing.h"
#include "turing_tu10x.h"
#include "turing_scratchpad.h"
#include "turing_cilp_preemption_buffer.h"
#include "turing/tu102/dev_graphics_nobundle.h"
#include "fermi_mcinterop.h"
#include "turing/turing_structs.h"

CUDBGResult
turing_tu10x_getInfo(CudbgDevice dev)
{
    CUDBGResult res;

    res = volta_gv10x_getInfo(dev);

    /* Overwrite the constants that are different */
    dev->halo.deviceInfo.numUniformRegsPrWarp       = CUDBG_MAX_UREG_TURING;
    dev->halo.deviceInfo.numUniformPredicatesPrWarp = CUDBG_MAX_UPRED_TURING;

    return res;
}

static CUDBGResult
turing_tu10x_getSavedSPLmemAddr(CudbgDevice dev, uint64_t *lmem_addr)
{
    CUDBG_VERIFY(lmem_addr,
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments\n");

    *lmem_addr = TURING_LMEM_SAVED_STACK_POINTER;
    return CUDBG_SUCCESS;
}

static CUDBGResult
turing_tu10x_getPauseReasonTableWarpOffset(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t* offset)
{
    CUDBG_VERIFY(offset && dev, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");
    *offset = (CUDBG_MAX_WARP_TURING * vsm + wp) * sizeof(uint32_t);
    return CUDBG_SUCCESS;
}

/* Get offset of gridId in GridParams. This is DCI dependent, hence halified. */
static CUDBGResult
turing_tu10x_getGridParamsOffsetGridId(CudbgDevice dev, uint64_t *offset)
{
    CUDBG_VERIFY(offset, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");

    *offset = ((uint64_t)(uintptr_t)&((CUturingGridParams *)0)->gridId);

    return CUDBG_SUCCESS;
}

/* Get offset of blockDim in GridParams. This is DCI dependent, hence halified.*/
static CUDBGResult
turing_tu10x_getGridParamsOffsetBlockDim(CudbgDevice dev, uint64_t *offset,
                                        uint32_t *size)
{
    CUDBG_VERIFY(offset && size, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");

    *offset = ((uint64_t)(uintptr_t)&((CUturingGridParams *)0)->blockDim);
    *size = sizeof ((CUturingGridParams *)0)->blockDim;

    return CUDBG_SUCCESS;
}

/* Get offset of gridDim in GridParams. This is DCI dependent, hence halified.*/
static CUDBGResult
turing_tu10x_getGridParamsOffsetGridDim(CudbgDevice dev, uint64_t *offset,
                                       uint32_t *size)
{
    CUDBG_VERIFY(offset && size, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");

    *offset = ((uint64_t)(uintptr_t)&((CUturingGridParams *)0)->gridDim);
    *size = sizeof ((CUturingGridParams *)0)->gridDim;

    return CUDBG_SUCCESS;
}

/* Get offset of startPc in GridParams. This is DCI dependent, hence halified.*/
static CUDBGResult
turing_tu10x_getGridParamsOffsetStartPc(CudbgDevice dev, uint64_t *offset)
{
    CUDBG_VERIFY(offset, CUDBG_ERROR_INVALID_ARGS, "Invalid argument\n");

    *offset = CNP_GRID_PARAM_OFFSET(startPc);

    return CUDBG_SUCCESS;
}

static CUDBGResult
turing_tu10x_readUniformRegisterFile(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                     uint64_t offset, void *buf, uint32_t bufSz)
{ 
    CUDBGResult res;
    size_t fieldOffset = 0, fieldWidth = 0;
    uint32_t offset32 = (uint32_t) offset;
    Context context = dev->activeContext;

    /* If no active context, there is nothing we can do. */
    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT,
                 "No active context found in turing_tu10x_readUniformRegisterFile\n");

    CUDBG_VERIFY(((uint64_t) offset32 == offset && !((offset32 | bufSz) & 3)),
                 CUDBG_ERROR_INVALID_MEMORY_ACCESS,
                 "Invalid memory access in turing_tu10x_readUniformRegisterFile\n");

    res = dev->halo.preemptionBuffer.getFieldOffset(HALO_PREEMPTION_BUFFER_FIELD_UREG,
                                              HALO_PREEMPTION_BUFFER_SECTION_WARP,
                                              vsm, 0, wp, 0, &fieldOffset, &fieldWidth);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "could not get UREG base address");
    CUDBG_VERIFY(offset + bufSz <= fieldWidth, CUDBG_ERROR_INVALID_ARGS, "invalid offset+bufSz");

    res = dev->halo.readDeviceMemory(context,
                                     context->cilpBufferDevVA + fieldOffset + offset,
                                     buf,
                                     bufSz);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "could not read device memory");

    return res;
}

static CUDBGResult
turing_tu10x_writeUniformRegisterFile(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                      uint64_t offset, const void *buf, uint32_t bufSz)
{
    CUDBGResult res;
    size_t fieldOffset = 0, fieldWidth = 0;
    uint32_t offset32 = (uint32_t) offset;
    Context context = dev->activeContext;

    /* If no active context, there is nothing we can do. */
    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT,
                 "No active context found in writeUniformRegisterFile.\n");

    CUDBG_VERIFY(((uint64_t) offset32 == offset && !((offset32 | bufSz) & 3)),
                 CUDBG_ERROR_INVALID_MEMORY_ACCESS,
                 "Invalid memory access.\n");

    res = dev->halo.preemptionBuffer.getFieldOffset(HALO_PREEMPTION_BUFFER_FIELD_UREG,
                                              HALO_PREEMPTION_BUFFER_SECTION_WARP,
                                              vsm, 0, wp, 0, &fieldOffset, &fieldWidth);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "could not get UREG base address");
    CUDBG_VERIFY(offset + bufSz <= fieldWidth, CUDBG_ERROR_INVALID_ARGS, "invalid offset+bufSz");

    res = dev->halo.writeDeviceMemory(context,
                                      context->cilpBufferDevVA + fieldOffset + offset,
                                      buf,
                                      bufSz);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "could not write device memory");

    return res;
}

static CUDBGResult
turing_tu10x_readUniformPredicates(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                   uint32_t numPreds, uint32_t *predicates)
{
    CUDBGResult res;
    uint32_t i;
    uint32_t predicateReg = 0;

    CUDBG_VERIFY(predicates, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args in pascal_gp10x_readUniformPredicates\n");
    CUDBG_VERIFY(numPreds <= dev->halo.deviceInfo.numUniformPredicatesPrWarp,
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid # of uniform predicates\n");

    /* Read predicate register contents */
    res = dev->halo.preemptionBuffer.read_UPR(dev->activeContext->preemptionBufferAccessor, vsm, wp, &predicateReg);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read UPR\n");

    /* Predicates are backed in the LSBs of PR */
    for (i = 0; i < numPreds; i++) {
        predicates[i] = (predicateReg >> i) & 1U;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
turing_tu10x_writeUniformPredicates(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                                    uint32_t numPreds, const uint32_t *predicates)
{
    CUDBGResult res;
    uint32_t i;
    uint32_t predicateReg = 0;

    CUDBG_VERIFY(predicates, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args in turing_tu10x_writeUniformPredicates\n");
    CUDBG_VERIFY(numPreds <= dev->halo.deviceInfo.numUniformPredicatesPrWarp,
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid # of uniform predicates\n");

    /* Read predicate register contents */
    res = dev->halo.preemptionBuffer.read_UPR(dev->activeContext->preemptionBufferAccessor, vsm, wp, &predicateReg);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read UPR\n");

    /* Modify predicate register based on inputs */
    for (i = 0; i < numPreds; i++) {
        CUDBG_VERIFY(predicates[i] < 2, CUDBG_ERROR_INVALID_ARGS, "Invalid uniform predicate value\n");
        predicateReg = (predicateReg & ~(1U << i)) | (predicates[i] << i);
    }

    /* Write updated predicate register back to backing store */
    res = dev->halo.preemptionBuffer.write_UPR(dev->activeContext->preemptionBufferAccessor, vsm, wp, predicateReg);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to write UPR\n");

    dev->activeContext->saveBufferState = HALO_SAVE_BUFFER_STATE_DIRTY;

    return CUDBG_SUCCESS;
}

/* Scratchpad access */

static CUDBGResult
turing_tu10x_scratchpad_getGlobalFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_SCRATCHPAD_GET_OFFSET_CASE(ACTIVE, TuringScratchpad_t, active);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PREEMPT_COMMAND, TuringScratchpad_t, preemptCommand);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PADDING, TuringScratchpad_t, padding);
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
turing_tu10x_scratchpad_getWarpFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_SCRATCHPAD_GET_OFFSET_CASE(VIRT_ID, TuringWarpScratchpad_t, virtID);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_IDX_X, TuringWarpScratchpad_t, blockIdxX);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_IDX_Y, TuringWarpScratchpad_t, blockIdxY);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_IDX_Z, TuringWarpScratchpad_t, blockIdxZ);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_DIM_X, TuringWarpScratchpad_t, blockDimX);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_DIM_Y, TuringWarpScratchpad_t, blockDimY);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_DIM_Z, TuringWarpScratchpad_t, blockDimZ);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_PARAM, TuringWarpScratchpad_t, gridId);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_DIM_X, TuringWarpScratchpad_t, gridDimX);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_DIM_Y, TuringWarpScratchpad_t, gridDimY);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_DIM_Z, TuringWarpScratchpad_t, gridDimZ);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SHMEM_SIZE_PR_BLOCK, TuringWarpScratchpad_t, shmemSizePrBlock);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_WINDOW_SIZE, TuringWarpScratchpad_t, lmemWindowSize);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_LO_SIZE_PR_THREAD, TuringWarpScratchpad_t, lmemLoSizePrThread);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_HI_OFF, TuringWarpScratchpad_t, lmemHiOff);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GLOBAL_ERROR_STATUS, TuringWarpScratchpad_t, globalErrorStatus);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_ERROR_STATUS, TuringWarpScratchpad_t, warpErrorStatus);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_ERROR_PC, TuringWarpScratchpad_t, warpErrorPC);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_BARRIER_STATE, TuringWarpScratchpad_t, warpBarrierState);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SELF_QMD, TuringWarpScratchpad_t, selfQMDAddr);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PARAM_CONST_DPTR, TuringWarpScratchpad_t, paramConstDptr);
        /* HACK! CIR_QUEUE_INCR_MINUS_ONE is always just used to check if the CTA is queued */
        HALO_SCRATCHPAD_GET_OFFSET_CASE(CIR_QUEUE_INCR_MINUS_ONE, TuringWarpScratchpad_t, isQueueCTA);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_BASE, TuringWarpScratchpad_t, lmemBase);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(MPS_CONTEXT_ID, TuringWarpScratchpad_t, mpsContextId);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SUBCONTEXT_VSMID, TuringWarpScratchpad_t, subContextVSMId);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SINGLESTEP_NSTEPS, TuringWarpScratchpad_t, singleStepNsteps);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_FLAG_VALID_ON_SAVE, TuringWarpScratchpad_t, warpFlagsValidOnSave);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_FLAG_PAUSE_SERVICED, TuringWarpScratchpad_t, warpFlagsPauseServiced);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(REGISTER_COUNT, TuringWarpScratchpad_t, regCount);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_ACTIVE_MASK, TuringWarpScratchpad_t, trapReturnMask);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_TRAP_RPC, TuringWarpScratchpad_t, trapReturnPC);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_EXITED_MASK, TuringWarpScratchpad_t, warpExitedMask);
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
turing_tu10x_scratchpad_getLaneFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_SCRATCHPAD_GET_OFFSET_CASE(THREAD_IDX, TuringLaneScratchpad_t, threadIdx);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(R1, TuringLaneScratchpad_t, r1);
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
turing_tu10x_scratchpad_getSmFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
turing_tu10x_scratchpad_getFieldOffset(HaloScratchpadField field, HaloScratchpadSection section,
    uint32_t sm, uint32_t wp, uint32_t ln, size_t *offset, size_t *width)
{
    size_t base = 0;
    CUDBGResult res;

    switch (section) {
    case HALO_SCRATCHPAD_SECTION_GLOBAL:
        res = turing_tu10x_scratchpad_getGlobalFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_SCRATCHPAD_SECTION_WARP:
        base = OFFSETOF_NONCONST(TuringScratchpad_t, warp[sm][wp]);
        res = turing_tu10x_scratchpad_getWarpFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_SCRATCHPAD_SECTION_SM:
        base = OFFSETOF_NONCONST(TuringScratchpad_t, sm[sm]);
        res = turing_tu10x_scratchpad_getSmFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_SCRATCHPAD_SECTION_LANE:
        base = OFFSETOF_NONCONST(TuringScratchpad_t, warp[sm][wp]) +
            OFFSETOF_NONCONST(TuringWarpScratchpad_t, lane[ln]);
        res = turing_tu10x_scratchpad_getLaneFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    default:
        *offset = 0;
        *width = 0;
        HALO_TRACE_FUNCTION(0, "Invalid scratchpad section %d\n", section);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    *offset += base;

    return res;
}

/* Preemption buffer access */

static CUDBGResult
turing_tu10x_preemptionBuffer_getLaneFieldOffset(HaloPreemptionBufferField field, uint32_t ln, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(RPC, CUturingWarpCILPBuffer, CBU_RPC[ln]);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(PR, CUturingWarpCILPBuffer, PR[ln]);
    default:
        *width = 0;
        *offset = 0;
        HALO_TRACE_FUNCTION(0, "Invalid CILP buffer lane field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
turing_tu10x_preemptionBuffer_getWarpFieldOffset(HaloPreemptionBufferField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(BAR, CUturingWarpCILPBuffer, CBU_BAR);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_TRAP_RPC, CUturingWarpCILPBuffer, CBU_TRAP_RETURN_PC);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(ATEXIT_PC, CUturingWarpCILPBuffer, CBU_ATEXITPC);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_ACTIVE_MASK, CUturingWarpCILPBuffer, CBU_TRAP_RETURN_MASK);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_EXITED_MASK, CUturingWarpCILPBuffer, CBU_MEXITED);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(MATEXIT, CUturingWarpCILPBuffer, CBU_MATEXIT);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_CALL_DEPTH, CUturingWarpCILPBuffer, CBU_API_CALL_DEPTH);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(OPT_STACK, CUturingWarpCILPBuffer, CBU_OPT_STACK);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(THREAD_STATE_ENUM_0, CUturingWarpCILPBuffer, CBU_THREAD_STATE_ENUM_0);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(THREAD_STATE_ENUM_1, CUturingWarpCILPBuffer, CBU_THREAD_STATE_ENUM_1);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(THREAD_STATE_ENUM_2, CUturingWarpCILPBuffer, CBU_THREAD_STATE_ENUM_2);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(THREAD_STATE_ENUM_3, CUturingWarpCILPBuffer, CBU_THREAD_STATE_ENUM_3);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(THREAD_STATE_ENUM_4, CUturingWarpCILPBuffer, CBU_THREAD_STATE_ENUM_4);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(UPR, CUturingWarpCILPBuffer, UPR);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(UREG, CUturingWarpCILPBuffer, UReg);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(TTU_TICKET_INFO, CUturingWarpCILPBuffer, TTU_ticket_info);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(TTU_MASK, CUturingWarpCILPBuffer, TTU_mask);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(LMEMBASE, CUturingWarpCILPBuffer, LMEMBASE);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_BARSTATE, CUturingWarpCILPBuffer, BARState);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(RFDATAIDX, CUturingWarpCILPBuffer, RFDataIdx);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_RESERVED0, CUturingWarpCILPBuffer, reservedPad0);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_RESERVED1, CUturingWarpCILPBuffer, reservedPad1);
    default:
        *width = 0;
        *offset = 0;
        HALO_TRACE_FUNCTION(0, "Invalid CILP buffer warp field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
turing_tu10x_preemptionBuffer_getCTAFieldOffset(HaloPreemptionBufferField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(CTAID, CUturingCTACILPBuffer, CTAID);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(SHMEMDATAIDX, CUturingCTACILPBuffer, shmemDataIdx);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(CTA_RESERVEDPAD1, CUturingCTACILPBuffer, reservedPad1);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(CTA_BARSTATE, CUturingCTACILPBuffer, BARState);
    default:
        *width = 0;
        *offset = 0;
        HALO_TRACE_FUNCTION(0, "Invalid CILP buffer CTA field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
turing_tu10x_preemptionBuffer_getSMFieldOffset(HaloPreemptionBufferField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(RFDATAIDXSYNC, CUturingSMCILPBuffer, RFDataIdxSync);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(SHMEMDATAIDXSYNC, CUturingSMCILPBuffer, shmemDataIdxSync);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(VALIDPENDINGSTATE, CUturingSMCILPBuffer, validPendingState);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(SM_RESERVEDPAD0, CUturingSMCILPBuffer, reservedPad0);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(SM_RESERVEDPAD1, CUturingSMCILPBuffer, reservedPad1);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(SM_RESERVEDPAD2, CUturingSMCILPBuffer, reservedPad2);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(SM_RESERVEDPAD3, CUturingSMCILPBuffer, reservedPad3);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(RFDATA, CUturingSMCILPBuffer, RFData);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(SHMEMDATA, CUturingSMCILPBuffer, shmemData);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARPDATA, CUturingSMCILPBuffer, warpData);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(CTADATA, CUturingSMCILPBuffer, CTAData);
    default:
        *width = 0;
        *offset = 0;
        HALO_TRACE_FUNCTION(0, "Invalid CILP buffer SM field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
turing_tu10x_preemptionBuffer_getFieldOffset(HaloPreemptionBufferField field, HaloPreemptionBufferSection section,
    uint32_t sm, uint32_t cta, uint32_t wp, uint32_t ln,
    size_t *offset, size_t *width)
{
    size_t base = 0;
    CUDBGResult res;

    base = sm * sizeof(CUturingSMCILPBuffer);

    switch (section) {
    case HALO_PREEMPTION_BUFFER_SECTION_SM:
        res = turing_tu10x_preemptionBuffer_getSMFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_PREEMPTION_BUFFER_SECTION_CTA:
        base += OFFSETOF_NONCONST(CUturingSMCILPBuffer, CTAData[cta]);
        res = turing_tu10x_preemptionBuffer_getCTAFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_PREEMPTION_BUFFER_SECTION_WARP:
        base += OFFSETOF_NONCONST(CUturingSMCILPBuffer, warpData[wp]);
        res = turing_tu10x_preemptionBuffer_getWarpFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_PREEMPTION_BUFFER_SECTION_LANE:
        base += OFFSETOF_NONCONST(CUturingSMCILPBuffer, warpData[wp]);
        res = turing_tu10x_preemptionBuffer_getLaneFieldOffset(field, ln, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    default:
        *width = 0;
        *offset = 0;
        HALO_TRACE_FUNCTION(0, "Invalid preemption buffer section %d\n", section);
        return CUDBG_ERROR_INVALID_ARGS;
    };

    *offset += base;
    return CUDBG_SUCCESS;
}

static CUDBGResult
turing_tu10x_preemptionBuffer_read_UPR(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *upr)
{
    CUDBG_VERIFY(preemptionBufferAccessor && upr, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_PREEMPTION_BUFFER_GET_FIELD(preemptionBufferAccessor, WARP, UPR, vsm, 0, wp, 0, upr);

    return CUDBG_SUCCESS;
}

static CUDBGResult
turing_tu10x_preemptionBuffer_write_UPR(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t upr)
{
    CUDBG_VERIFY(preemptionBufferAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_PREEMPTION_BUFFER_SET_FIELD(preemptionBufferAccessor, WARP, UPR, vsm, 0, wp, 0, &upr);

    return CUDBG_SUCCESS;
}

static CUDBGResult
turing_tu10x_canSkipSingleStepOverExitWAR(bool *skip)
{
    /* Bug 1820001: In single step mode for Turing+ chips, the SM is
       guaranteed to trap even before the execution of the first
       instruction. This allows us to skip the special handling for the EXIT
       instruction */

    *skip = true;
    return CUDBG_SUCCESS;
}

void
haloDeviceInit_tu10x(Halo_st *halo)
{
    haloDeviceInit_gv10x(halo);

    /* architectural constants - always init after base chip init */
    halo->deviceInfo.spRegisterNumber = TURING_ABI_SP;
    halo->deviceInfo.systemStackPointer = TURING_SYSTEM_STACK_POINTER;
    halo->deviceInfo.lmemSavedReturnPC = TURING_LMEM_SAVED_RETURN_PC;
    halo->deviceInfo.lmemSavedMExited = TURING_LMEM_SAVED_MEXITED;
    halo->deviceInfo.cilpBufferSizePerSM = sizeof(CUturingSMCILPBuffer);
    halo->deviceInfo.scratchpadSize = sizeof(TuringScratchpad_t);

    halo->getInfo = turing_tu10x_getInfo;

    /* Scratchpad/preemption buffer accessors */
    halo->getPauseReasonTableWarpOffset = turing_tu10x_getPauseReasonTableWarpOffset;

    /* DCI overrides */
    halo->getGridParamsOffsetGridId   = turing_tu10x_getGridParamsOffsetGridId;
    halo->getGridParamsOffsetBlockDim = turing_tu10x_getGridParamsOffsetBlockDim;
    halo->getGridParamsOffsetGridDim = turing_tu10x_getGridParamsOffsetGridDim;
    halo->getGridParamsOffsetStartPc = turing_tu10x_getGridParamsOffsetStartPc;

    /* Uniform register access */
    halo->readUniformRegisterFile = turing_tu10x_readUniformRegisterFile;
    halo->writeUniformRegisterFile = turing_tu10x_writeUniformRegisterFile;
    halo->readUniformPredicates = turing_tu10x_readUniformPredicates;
    halo->writeUniformPredicates = turing_tu10x_writeUniformPredicates;

    /* Scratchpad access */

    halo->scratchpad.getFieldOffset = turing_tu10x_scratchpad_getFieldOffset;

    /* Preemption buffer access */

    halo->preemptionBuffer.getFieldOffset = turing_tu10x_preemptionBuffer_getFieldOffset;
    halo->preemptionBuffer.read_UPR = turing_tu10x_preemptionBuffer_read_UPR;
    halo->preemptionBuffer.write_UPR = turing_tu10x_preemptionBuffer_write_UPR;

    /* base functions */
    halo->canSkipSingleStepOverExitWAR = turing_tu10x_canSkipSingleStepOverExitWAR;
}
