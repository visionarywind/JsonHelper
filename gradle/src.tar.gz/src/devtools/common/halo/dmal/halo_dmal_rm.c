/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */


/******************************************************************************
 *
 *   Module: halo_dmal_rm.c
 *
 *   Description:
 *       Halo RM DMAL initialization
 *
 ******************************************************************************/

#include "halo.h"
#include "halo_dmal_rm.h"
#include "halo_client.h"
#include "halo_state.h"
#include "halo_internal.h"
#include "rm_call.h"
#if cuosOsIsLinux() || cuosOsIsApple()
# include <sys/mman.h>
#endif
#include "nvRmApi.h"
#include "class/cl0000.h"
#include "class/cl0005.h"
#include "class/cl003f.h"
#include "ctrl/ctrl2080.h"
#include "ctrl/ctrla06c.h"

#if (!cuosOsIsApple() || (cuosOsIsApple() && (NV_SDK_BRANCH_MAJ >= 331)))
#include "class/cl90cc.h"
#include "ctrl/ctrl90cc.h"
#endif  /* __APPLE__ */

/* Debug Object Handling

   1.  On some RM branches (mainly when building Apple), the
       debug object header files aren't present.
   2.  There are known-bad Apple RM branches where the debug
       object is present, but does not work properly.  In
       particular, the first Kepler Apple RM (AP295_10_05)
       has this issue.  Also, Apple branches prior to 295
       didn't have support for the debug object at all. */
#ifndef CLASS_CL83DE_H_MISSING
#include "class/cl83de.h"
/* Bug 2610260 - WAR to get around alignment issues with RM sdk structure.
KMD forces packing to 1 in nvlEscDef.h before including escape headers, which in
turn includes RM sdk headers. NV83DE_CTRL_DEBUG_EXEC_REG_OPS_PARAMS was added to
the SDK in ctrl/ctrl83de/ctrl83dedebug.h with a 1 byte field at the beginning of
the structure, followed by other values that are aligned to a 32 bit boundary.
The alignment is not enforced when packing is set to 1. As a result, debugger
and RM end up with mismatched structures. The longer term solution is to fix
alignment issues in the macros that RM uses.
WAR this issue by reverting the packing before including
ctrl/ctrl83de/ctrl83dedebug.h. */
#pragma pack(push)
#pragma pack()
#if defined(_ctrl83de_h_) || defined(_ctrl83dedebug_h_)
#error "Ensure ctrl/ctrl83de.h or ctrl/ctrl83de/ctrl83dedebug.h is not included before this point"
#endif
#include "ctrl/ctrl83de.h"
#pragma pack(pop)
#endif

#include "cuidevice.h"

/* Used for finding a Debug Object on a device */
typedef struct {
    CudbgDevice dev;
    DebugObject *debugObj;
} DebugObjFunctor;

typedef struct {
    Context context;
    uint32_t hChannel;
} FindContextForChannelFunctor;

static CUDBGResult unmapStaleMemoryMappings(CudbgDevice dev, haloMemoryMap *map);
static CUDBGResult haloDmalDebugObjectGetAnyDebugObjHandle_RM(CudbgDevice dev, DebugObject *debugObj);

static CUDBGResult haloDmalCallRmExecRegOps_RM(CudbgDevice dev, Context context, bool useContextOp, NV2080_CTRL_GPU_REG_OP *script, int numOps);
static CUDBGResult haloDmalTranslateToRmRegType_RM(NvU32 regType, NvU8 *rmRegType);
static bool haloDmalDebugObjectCanExecRegOps_RM(void);

static NvU32 haloDmalGetRmClient(DebugObject debugObj);
static bool haloDmalDebugObjectCanSuspendResumeSingleContext_RM();

#if cuosOsIsLinux()
/* Last minute update of the mapping code, keep it confined to Linux */
static CUDBGResult
haloDmalFinalizePrivAccess_RM (CudbgDevice dev)
{
    const CUdev* pDev   = globals.devices[dev->deviceIdx];
    uint32_t hDevice    = deviceGetRmHandle(pDev);
    uint32_t rc = 0;
    uint32_t pgraphStart = 0, pgraphSize = 0;
    CUDBGResult res = CUDBG_SUCCESS;

    if (dev->halo.deviceInfo.useRegOps) {
        dev->bar0AddressRM = 0;
        dev->bar0 = 0;
        dev->bar0Start = dev->bar0Size = 0;
        HALO_TRACE(1, "Device uses regops. Skipping teardown of PRIs\n");
        return CUDBG_SUCCESS;
    }

    CUDBG_VERIFY(dev->bar0HandleRM, CUDBG_ERROR_INTERNAL, "Cannot find bar0 mapping. Nothing to unmap\n");

    /* Unmap each of the chunks */
    rc = CudaRmUnmapMemory(globals.rmClient, deviceGetRmSubHandle(pDev),
                           dev->bar0HandleRM,
                           (char*)dev->bar0 + CUDBG_BAR0_PFIFO_REGS_START, 0);
    if (rc)
        HALO_ERROR("Failed to unmap BAR0 PFIFO offset for device %d (0x%x).\n",
                   dev->deviceIdx, rc);

#if NVCFG(GLOBAL_ARCH_KEPLER)
    /* RM lets us map the PFB range only on Tegra */
    if (pDev->state.arch == NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 &&
        pDev->state.chip == NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 +
        NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK20A) {
        rc = CudaRmUnmapMemory(globals.rmClient, deviceGetRmSubHandle(pDev),
                               dev->bar0HandleRM,
                               (char*)dev->bar0 + CUDBG_BAR0_PFB_REGS_START, 0);
        if (rc)
            HALO_ERROR("Failed to unmap BAR0 PFB offset for device %d (0x%x).\n",
                       dev->deviceIdx, rc);
    }
#endif

    res = dev->halo.getPgraphBar0Extents(dev, &pgraphStart, &pgraphSize);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to get PGRAPH extents for device %d (0x%x).\n",
                   dev->deviceIdx, res);
    }
    else {
        rc = CudaRmUnmapMemory(globals.rmClient, deviceGetRmSubHandle(pDev),
                               dev->bar0HandleRM,
                               (char*)dev->bar0 + pgraphStart, 0);
        if (rc)
            HALO_ERROR("Failed to unmap BAR0 PGRAPH offset for device %d (0x%x).\n",
                       dev->deviceIdx, rc);
    }

    cuosVirtualFree((void*)dev->bar0, dev->bar0Size, CUOS_VIRTUAL_FREE_RELEASE);

    /* Don't leave stale addresses around. */
    dev->bar0AddressRM = 0;
    dev->bar0 = 0;
    dev->bar0Start = dev->bar0Size = 0;

    rc = CudaRmFree(globals.rmClient, hDevice, dev->bar0HandleRM);

    if (rc)
        HALO_ERROR("Failed to free the BAR0 mapping for device %d (0x%x).\n",
                   dev->deviceIdx, rc);

    handlePoolFree(globals.handlePool, dev->bar0HandleRM);

    dev->bar0HandleRM = 0;

#if cuosOsIsLinux()
    /* Disable the RM regkey that allows bar0 mappings */
    if ((rc = CudaRmWriteRegistryDword(globals.rmClient, globals.rmClient, NULL,
                                       (char *)"RMPmApiMapping", 0)))
        HALO_ERROR("Failed to enable RMPmApiMapping, rc = 0x%02x.\n", rc);
#endif

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalInitPrivAccess_RM(CudbgDevice dev)
{
    /*
     * The code here is based
     * upon //sw/OEM/L9622/drivers/xfree86/4.0/nvidia/nv_resman_interface.c
     * as detailed in bug 611060 (Need an RM sanctioned way of mapping
     * BAR0).
     */

    const CUdev* pDev   = globals.devices[dev->deviceIdx];
    uint32_t hDevice    = deviceGetRmHandle(pDev);
    NV_STATUS rc;
    NvU64 dummyLimit;
    CUDBGResult res = CUDBG_SUCCESS;
    void *chunk = NULL;
    uint32_t mapFlags = 0;
    uint32_t pgraphStart = 0, pgraphSize = 0;

    if (dev->halo.deviceInfo.useRegOps) {
        HALO_TRACE(1, "Using regops for device. Not initializing PRI access\n");
        dev->bar0Start = CUDBG_BAR0_START;
        dev->bar0Size  = CUDBG_BAR0_SIZE;
        dev->bar0AddressRM = 0;
        dev->bar0 = NULL;
        dev->bar0HandleRM = 0;
        return CUDBG_SUCCESS;
    }

#if cuosOsIsLinux()
    /* Enable the RM regkey that allows bar0 mappings */
    if ((rc = CudaRmWriteRegistryDword(globals.rmClient, globals.rmClient, NULL,
                                       (char *)"RMPmApiMapping", 1)))
        HALO_ERROR("Failed to enable RMPmApiMapping, rc = 0x%02x.\n", rc);
#endif

    dev->bar0HandleRM = handlePoolAlloc(globals.handlePool);

    /*
     * Allocate the PRI window. This assumes only one subdevice. A
     * later improvement here would be to make the range depend on the
     * device.
     *
     * G86:   NV_PGRAPH 0x0040FFFF:0x00400000
     * GT200: NV_PGRAPH 0x0040FFFF:0x00400000
     * GF100: NV_PGRAPH 0x005FFFFF:0x00400000
     *
     * Note, the GF100 range is huge, but we pretty much need all of it, cf.
     * grep _PRI_ fermi.c|sed -e 's,^.*NV_PGRAPH,NV_PGRAPH,' -e 's,\([A-Z0-0_]*\).*$,\1,'|sort|uniq > /tmp/hits
     * grep -wf /tmp/hits gf100_nv_ref_nobundle.h
     */

    dev->bar0Start = 0;
    dev->bar0Size  = 0x600000;

    rc = CudaRmAllocMemory64(globals.rmClient, hDevice,
                             dev->bar0HandleRM,
                             NV01_MEMORY_LOCAL_PRIVILEGED,
                             DRF_DEF(OS02, _FLAGS, _ALLOC, _NONE),
                             &dev->bar0AddressRM, &dummyLimit);

    if (rc != NV_OK) {
        HALO_ERROR("Failed to allocate PRI registers for device %d (0x%x).\n",
                   dev->deviceIdx, rc);
        res = dev->haloClient->finalizePrivAccess(dev);
        if (res != CUDBG_SUCCESS)
            return res;

        return CUDBG_ERROR_UNKNOWN;
    }

    dev->bar0AddressRM = 0;

    /* Reserve a block of virtual memory, we'll map the bar0 chunks into this */
    dev->bar0 = (char *)cuosVirtualAlloc(NULL, dev->bar0Size, CUOS_VIRTUAL_ALLOC_RESERVE, CUOS_VIRTUAL_ACCESS_NONE);
    if (dev->bar0 == NULL) {
        HALO_ERROR("Failed to map vaddr chunk for bar0 for device %d (0x%x).\n",
                   dev->deviceIdx, rc);
        res = dev->haloClient->finalizePrivAccess(dev);
        if (res != CUDBG_SUCCESS)
            return res;

        return CUDBG_ERROR_UNKNOWN;
    }

    /* Now map the chunks in one by one */
    mapFlags = HWCONST(OS33, FLAGS, MAP_FIXED,        ENABLE) |
               HWCONST(OS33, FLAGS, RESERVE_ON_UNMAP, ENABLE);

    chunk = (void*)((char*)dev->bar0 + CUDBG_BAR0_PFIFO_REGS_START);
    rc = CudaRmMapMemory(globals.rmClient, deviceGetRmSubHandle(pDev),
                         dev->bar0HandleRM,
                         CUDBG_BAR0_PFIFO_REGS_START, CUDBG_BAR0_PFIFO_REGS_SIZE,
                         (void **)&chunk, mapFlags);
    if (rc) {
        HALO_ERROR("Failed to map PFIFO range for device %d (0x%x).\n",
                   dev->deviceIdx, rc);
        res = dev->haloClient->finalizePrivAccess(dev);
        if (res != CUDBG_SUCCESS)
            return res;

        return CUDBG_ERROR_UNKNOWN;
    }

#if NVCFG(GLOBAL_ARCH_KEPLER)
    /* RM lets us map the PFB range only on Tegra */
    if (pDev->state.arch == NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 &&
        pDev->state.chip == NV2080_CTRL_MC_ARCH_INFO_ARCHITECTURE_GK100 +
        NV2080_CTRL_MC_ARCH_INFO_IMPLEMENTATION_GK20A) {
        chunk = (void*)((char*)dev->bar0 + CUDBG_BAR0_PFB_REGS_START);
        rc = CudaRmMapMemory(globals.rmClient, deviceGetRmSubHandle(pDev),
                             dev->bar0HandleRM,
                             CUDBG_BAR0_PFB_REGS_START, CUDBG_BAR0_PFB_REGS_SIZE,
                             (void **)&chunk, mapFlags);
        if (rc) {
            HALO_ERROR("Failed to map PFB range for device %d (0x%x).\n",
                       dev->deviceIdx, rc);
            res = dev->haloClient->finalizePrivAccess(dev);
            if (res != CUDBG_SUCCESS)
                return res;

            return CUDBG_ERROR_UNKNOWN;
        }
    }
#endif

    res = dev->halo.getPgraphBar0Extents(dev, &pgraphStart, &pgraphSize);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to get PGRAPH extents for device %d (0x%x).\n",
                   dev->deviceIdx, res);
        (void)dev->haloClient->finalizePrivAccess(dev);
        return res;
    }

    chunk = (void*)((char*)dev->bar0 + pgraphStart);
    rc = CudaRmMapMemory(globals.rmClient, deviceGetRmSubHandle(pDev),
                         dev->bar0HandleRM,
                         pgraphStart, pgraphSize,
                         (void **)&chunk, mapFlags);
    if (rc) {
        HALO_ERROR("Failed to map PGRAPH range for device %d (0x%x).\n",
                   dev->deviceIdx, rc);
        res = dev->haloClient->finalizePrivAccess(dev);
        if (res != CUDBG_SUCCESS)
            return res;

        return CUDBG_ERROR_UNKNOWN;
    }

    HALO_TRACE(1, "Successfully mapped PRI registers [%08x; %08x] -> %p "
               "for device %d.\n",
               dev->bar0Start,
               dev->bar0Start + dev->bar0Size - 1,
               dev->bar0,
               dev->deviceIdx);

    return CUDBG_SUCCESS;
}
#else

static CUDBGResult
haloDmalFinalizePrivAccess_RM(CudbgDevice dev)
{
    const CUdev* pDev   = globals.devices[dev->deviceIdx];
    uint32_t hDevice    = deviceGetRmHandle(pDev);
    uint32_t rc = 0;
    void *bar0 = (void*)(dev->bar0 + dev->bar0Start);

    if (dev->halo.deviceInfo.useRegOps) {
        dev->bar0AddressRM = 0;
        dev->bar0 = 0;
        dev->bar0Start = dev->bar0Size = 0;
        HALO_TRACE(1, "Device uses regops. Skipping teardown of PRIs\n");
        return CUDBG_SUCCESS;
    }

    CUDBG_VERIFY(dev->bar0HandleRM, CUDBG_ERROR_INTERNAL, "Cannot find bar0 mapping. Nothing to unmap\n");

    if (bar0)
        rc = CudaRmUnmapMemory(globals.rmClient, deviceGetRmSubHandle(pDev),
                               dev->bar0HandleRM,
                               bar0, 0);

    if (rc)
        HALO_ERROR("Failed to unmap BAR0 for device %d (0x%x).\n",
                   dev->deviceIdx, rc);

    /* Don't leave stale addresses around. */
    dev->bar0AddressRM = 0;
    dev->bar0 = 0;
    dev->bar0Start = dev->bar0Size = 0;

    rc = CudaRmFree(globals.rmClient, hDevice, dev->bar0HandleRM);

    if (rc)
        HALO_ERROR("Failed to free the BAR0 mapping for device %d (0x%x).\n",
                   dev->deviceIdx, rc);

    handlePoolFree(globals.handlePool, dev->bar0HandleRM);

    dev->bar0HandleRM = 0;

#if cuosOsIsLinux()
    /* Disable the RM regkey that allows bar0 mappings */
    if ((rc = CudaRmWriteRegistryDword(globals.rmClient, globals.rmClient, NULL,
                                       "RMPmApiMapping", 0)))
        HALO_ERROR("Failed to enable RMPmApiMapping, rc = 0x%02x.\n", rc);
#endif

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalInitPrivAccess_RM(CudbgDevice dev)
{
    /*
     * The code here is based
     * upon //sw/OEM/L9622/drivers/xfree86/4.0/nvidia/nv_resman_interface.c
     * as detailed in bug 611060 (Need an RM sanctioned way of mapping
     * BAR0).
     */

    const CUdev* pDev   = globals.devices[dev->deviceIdx];
    uint32_t hDevice    = deviceGetRmHandle(pDev);
    uint32_t rc;
    NvU64 dummyLimit;
    CUDBGResult res = CUDBG_SUCCESS;

    if (dev->halo.deviceInfo.useRegOps) {
        HALO_TRACE(1, "Using regops for device. Not initializing PRI access\n");
        dev->bar0Start = CUDBG_BAR0_START;
        dev->bar0Size  = CUDBG_BAR0_SIZE;
        dev->bar0AddressRM = 0;
        dev->bar0 = NULL;
        dev->bar0HandleRM = 0;
        return CUDBG_SUCCESS;
    }

#if cuosOsIsLinux()
    /* Enable the RM regkey that allows bar0 mappings */
    if ((rc = CudaRmWriteRegistryDword(globals.rmClient, globals.rmClient, NULL,
                                       "RMPmApiMapping", 1)))
        HALO_ERROR("Failed to enable RMPmApiMapping, rc = 0x%02x.\n", rc);
#endif

    dev->bar0HandleRM = handlePoolAlloc(globals.handlePool);

    /*
     * Allocate the PRI window. This assumes only one subdevice. A
     * later improvement here would be to make the range depend on the
     * device.
     *
     * G86:   NV_PGRAPH 0x0040FFFF:0x00400000
     * GT200: NV_PGRAPH 0x0040FFFF:0x00400000
     * GF100: NV_PGRAPH 0x005FFFFF:0x00400000
     *
     * Note, the GF100 range is huge, but we pretty much need all of it, cf.
     * grep _PRI_ fermi.c|sed -e 's,^.*NV_PGRAPH,NV_PGRAPH,' -e 's,\([A-Z0-0_]*\).*$,\1,'|sort|uniq > /tmp/hits
     * grep -wf /tmp/hits gf100_nv_ref_nobundle.h
     */

    dev->bar0Start = CUDBG_BAR0_START;
    dev->bar0Size  = CUDBG_BAR0_SIZE;

    rc = CudaRmAllocMemory64(globals.rmClient, hDevice,
                             dev->bar0HandleRM,
                             NV01_MEMORY_LOCAL_PRIVILEGED,
                             DRF_DEF(OS02, _FLAGS, _ALLOC, _NONE),
                             &dev->bar0AddressRM, &dummyLimit);

    if (rc != NV_OK) {
        HALO_ERROR("Failed to allocate PRI registers for device %d (0x%x).\n",
                   dev->deviceIdx, rc);
        res = dev->haloClient->finalizePrivAccess(dev);
        if (res != CUDBG_SUCCESS)
            return res;

        return CUDBG_ERROR_UNKNOWN;
    }

    dev->bar0AddressRM = 0;
    rc = CudaRmMapMemory(globals.rmClient, deviceGetRmSubHandle(pDev),
                         dev->bar0HandleRM,
                         dev->bar0Start, dev->bar0Size,
                         (void **)&dev->bar0, 0);

    if (rc != NV_OK) {
        HALO_ERROR("Failed to map PRI registers for device %d (0x%x).\n",
                   dev->deviceIdx, rc);
        res = dev->haloClient->finalizePrivAccess(dev);
        if (res != CUDBG_SUCCESS)
            return res;

        return CUDBG_ERROR_UNKNOWN;
    }

    HALO_TRACE(1, "Successfully mapped PRI registers [%08x; %08x] -> %p "
               "for device %d.\n",
               dev->bar0Start,
               dev->bar0Start + dev->bar0Size - 1,
               dev->bar0,
               dev->deviceIdx);

    /*
     * Adjust the BAR0 pointer so it's zero based (this keeps the
     * usage simpler).
     */
    dev->bar0 -= dev->bar0Start;

    return CUDBG_SUCCESS;
}
#endif

/* Register access functions. Some of these are completely trivial and
 * they mostly serve to document these PRI register accesses */

static inline uint32_t
rd32(volatile char *addr)
{
    return *(volatile uint32_t *) addr;
}

static inline void
wr32(volatile char *addr, uint32_t value)
{
    *(volatile uint32_t *) addr = value;
}

static inline uint64_t
rd64(volatile char *addr)
{
    if (sizeof(void *) == 4) {
        /* GCC can generate code which loads the high part first, and that
           creates problems for some registers */
        uint32_t lo = *(volatile uint32_t *) addr;
        uint32_t hi = *(volatile uint32_t *) (addr + 4);
        return ((uint64_t) hi << 32) | lo;
    }
    else
        return *(volatile uint64_t *) addr;
}

static inline void
wr64(volatile char *addr, uint64_t value)
{
    if (sizeof(void *) == 4) {
        /* GCC can generate code which loads the high part first, and that
           creates problems for some registers */
        *(volatile uint32_t *) addr = (uint32_t) value;
        *(volatile uint32_t *) (addr + 4) = (uint32_t) (value >> 32);
    }
    else
        *(volatile uint64_t *) addr = value;
}

/* Wrappers */
static CUDBGResult
haloDmalReadReg32_RM(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint32_t* value)
{
    CUDBGResult res = CUDBG_SUCCESS;
    NV2080_CTRL_GPU_REG_OP script;
    Context ctx = dev->activeContext;
    bool useContextOp = false;

    CUDBG_VERIFY_REGADDR(addr);

    if (dev->halo.deviceInfo.useRegOps) {
        memset(&script, 0, sizeof(script));

        script.regOp        = NV2080_CTRL_GPU_REG_OP_READ_32;
        script.regOffset    = (uint32_t)(uintptr_t)(addr - dev->bar0);

        if (!ctx && regType != HALO_REG_OP_TYPE_GLOBAL) {
            if (dev->halo.deviceInfo.preemptionType != HALO_PREEMPTION_TYPE_NONE) {
                /* WAR 1803160 - We shouldn't be reading ctxsw'ed pris without an active context, but for now
                   return zero and skip the actual read */
                HALO_TRACE(10, "Ignoring read ctxsw'ed pri(%#x) without an active context\n", addr);
                *value = 0x0;
                return CUDBG_SUCCESS;
            }
            else {
                HALO_TRACE(10, "Invalid context on pri %#x, forcing global\n", script.regOffset);
                regType = HALO_REG_OP_TYPE_GLOBAL;
            }
        }

        res = haloDmalTranslateToRmRegType_RM(regType, &script.regType);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to translate halo regtype to rm regtype\n");
            return res;
        }

        /* If we're issuing any ctx ops, ensure the channel/client are filled in */
        if (ctx && script.regType == NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX)
            useContextOp = true;

        res = haloDmalCallRmExecRegOps_RM(dev, ctx, useContextOp, &script, 1);
        if (res != CUDBG_SUCCESS) {
            HALO_TRACE(1, "Failed to read via regop: regType=%d, offset=%#x\n", regType, script.regOffset);
            HALO_ERROR("Failed to read via regop\n");
            return res;
        }
        *value = script.regValueLo;
    }
    else
        *value = rd32(addr);

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalReadReg64_RM(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint64_t* value)
{
    CUDBGResult res = CUDBG_SUCCESS;
    NV2080_CTRL_GPU_REG_OP script;
    Context ctx = dev->activeContext;
    bool useContextOp = false;

    CUDBG_VERIFY_REGADDR(addr);

    if (dev->halo.deviceInfo.useRegOps) {
        memset(&script, 0, sizeof(script));

        script.regOp        = NV2080_CTRL_GPU_REG_OP_READ_64;
        script.regOffset    = (uint32_t)(uintptr_t)(addr - dev->bar0);

        if (!ctx && regType != HALO_REG_OP_TYPE_GLOBAL) {
            if (dev->halo.deviceInfo.preemptionType != HALO_PREEMPTION_TYPE_NONE) {
                /* WAR 1803160 - We shouldn't be reading ctxsw'ed pris without an active context, but for now
                   return zero and skip the actual read */
                HALO_TRACE(10, "Ignoring read ctxsw'ed pri(%#x) without an active context\n", addr);
                *value = 0x0;
                return CUDBG_SUCCESS;
            }
            else {
                HALO_TRACE(10, "Invalid context on pri %#x, forcing global\n", script.regOffset);
                regType = HALO_REG_OP_TYPE_GLOBAL;
            }
        }

        res = haloDmalTranslateToRmRegType_RM(regType, &script.regType);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to translate halo regtype to rm regtype\n");
            return res;
        }

        /* If we're issuing any ctx ops, ensure the channel/client are filled in */
        if (ctx && script.regType == NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX)
            useContextOp = true;

        res = haloDmalCallRmExecRegOps_RM(dev, ctx, useContextOp, &script, 1);
        if (res != CUDBG_SUCCESS) {
            HALO_TRACE(1, "Failed to read via regop: regType=%d, offset=%#x\n", regType, script.regOffset);
            HALO_ERROR("Failed to read via regop\n");
            return res;
        }
        *value = ((uint64_t)script.regValueHi << 32) | script.regValueLo;
    }
    else
        *value = rd64(addr);

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalWriteReg32_RM(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint32_t* value)
{
    CUDBGResult res = CUDBG_SUCCESS;
    NV2080_CTRL_GPU_REG_OP script;
    Context ctx = dev->activeContext;
    bool useContextOp = false;

    CUDBG_VERIFY_REGADDR(addr);

    if (dev->halo.deviceInfo.useRegOps) {
        memset(&script, 0, sizeof(script));

        script.regOp        = NV2080_CTRL_GPU_REG_OP_WRITE_32;
        script.regOffset    = (uint32_t)(uintptr_t)(addr - dev->bar0);
        script.regValueLo   = *value;
        script.regAndNMaskLo = 0xffffffff;

        if (!ctx && regType != HALO_REG_OP_TYPE_GLOBAL) {
            if (dev->halo.deviceInfo.preemptionType != HALO_PREEMPTION_TYPE_NONE) {
                /* WAR 1803160 - We shouldn't be reading ctxsw'ed pris without an active context, but for now
                   return zero and skip the actual read */
                HALO_TRACE(10, "Ignoring write ctxsw'ed pri(%#x) without an active context\n", addr);
                return CUDBG_SUCCESS;
            }
            else {
                HALO_TRACE(10, "Invalid context on pri %#x, forcing global\n", script.regOffset);
                regType = HALO_REG_OP_TYPE_GLOBAL;
            }
        }

        res = haloDmalTranslateToRmRegType_RM(regType, &script.regType);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to translate halo regtype to rm regtype\n");
            return res;
        }

        /* If we're issuing any ctx ops, ensure the channel/client are filled in */
        if (ctx && script.regType == NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX)
            useContextOp = true;

        res = haloDmalCallRmExecRegOps_RM(dev, ctx, useContextOp, &script, 1);
        if (res != CUDBG_SUCCESS) {
            HALO_TRACE(1, "Failed to write via regop: regType=%d, offset=%#x\n", regType, script.regOffset);
            HALO_ERROR("Failed to write via regop\n");
            return res;
        }
    }
    else
        wr32(addr, *value);

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalWriteReg64_RM(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint64_t* value)
{
    CUDBGResult res = CUDBG_SUCCESS;
    NV2080_CTRL_GPU_REG_OP script;
    Context ctx = dev->activeContext;
    bool useContextOp = false;

    CUDBG_VERIFY_REGADDR(addr);

    if (dev->halo.deviceInfo.useRegOps) {
        memset(&script, 0, sizeof(script));

        script.regOp        = NV2080_CTRL_GPU_REG_OP_WRITE_64;
        script.regOffset    = (uint32_t)(uintptr_t)(addr - dev->bar0);
        script.regValueLo   = (uint32_t)(*value);
        script.regAndNMaskLo = 0xffffffff;
        script.regValueHi   = (uint32_t)((*value)>>32);
        script.regAndNMaskHi = 0xffffffff;

        if (!ctx && regType != HALO_REG_OP_TYPE_GLOBAL) {
            if (dev->halo.deviceInfo.preemptionType != HALO_PREEMPTION_TYPE_NONE) {
                /* WAR 1803160 - We shouldn't be reading ctxsw'ed pris without an active context, but for now
                   return zero and skip the actual read */
                HALO_TRACE(10, "Ignoring write ctxsw'ed pri(%#x) without an active context\n", addr);
                return CUDBG_SUCCESS;
            }
            else {
                HALO_TRACE(10, "Invalid context on pri %#x, forcing global\n", script.regOffset);
                regType = HALO_REG_OP_TYPE_GLOBAL;
            }
        }
        
        res = haloDmalTranslateToRmRegType_RM(regType, &script.regType);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to translate halo regtype to rm regtype\n");
            return res;
        }

        /* If we're issuing any ctx ops, ensure the channel/client are filled in */
        if (ctx && script.regType == NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX)
            useContextOp = true;

        res = haloDmalCallRmExecRegOps_RM(dev, ctx, useContextOp, &script, 1);
        if (res != CUDBG_SUCCESS) {
            HALO_TRACE(1, "Failed to write via regop: regType=%d, offset=%#x\n", regType, script.regOffset);
            HALO_ERROR("Failed to write via regop\n");
            return res;
        }
    }
    else
        wr64(addr, *value);

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalMapOneMemorySegment_RM(haloMemoryMap *map, haloMemorySegment *seg,
                               uint64_t offset, uint64_t size)
{
    NvU32 hDevice;
    const CUdev* pDev;
    NvU32 rc;
    uint32_t seghandle;
    CUDBGResult res;
    CudbgDevice dev = haloGlobals.device[seg->sourceDeviceIdx];

    /* Check for large mappings. */
    CUDBG_VERIFY((size < dev->bar1Size),
                 CUDBG_ERROR_INTERNAL,
                 "Size too large %u on mapping\n", (uint32_t) size);

    /* Perf - if the segment holding va is less than 1/2 the BAR1 size,
       then map the entire segment in to avoid future remappings. */
    if (seg->size < dev->bar1Size >> 1) {
        offset = 0;
        size = seg->size;
    }

    pDev = globals.devices[dev->deviceIdx];
    CUDBG_VERIFY(pDev, CUDBG_ERROR_INTERNAL, "Invalid device.\n");

    hDevice = deviceGetRmHandle(pDev);
    CUDBG_VERIFY(hDevice, CUDBG_ERROR_INTERNAL, "Invalid device handle.\n");

    seghandle = seg->mem;
    if (dev->haloClient->state.dupRmHandles &&
        seg->client != globals.rmClient) {
        /* Only dup handle if this is a debugger halo */
        seg->newmem = handlePoolAlloc(globals.handlePool);
        CUDBG_VERIFY(seg->newmem, CUDBG_ERROR_INTERNAL, "Allocating handle failed.\n");

        /* We need to dup the memory handle in order to
         * use it in the debugger's process space */
        rc = CudaRmDupObject(globals.rmClient,
                             hDevice,
                             seg->newmem,
                             seg->client,
                             seg->mem, 0);
        if (rc == NV_ERR_NOT_SUPPORTED && seg->hostvaddr) {
            /* Bug 808028:  For malloc'd pointers that are then pinned
               down by RM (via cudaHostRegister), they are given a
               handle class of NV01_MEMORY_SYSTEM_OS_DESCRIPTOR.  This
               particular type of memory cannot be dup'd/mapped in the
               standard way because RM did not originally own the
               allocation.  */
            HALO_TRACE(50, "RM cannot dup this handle (not supported). "
                       "Indicate upward to read from sysmem.\n");
            return CUDBG_ERROR_ADDRESS_NOT_IN_DEVICE_MEM;
        }
        else if (rc) {
            HALO_ERROR("Failed to dup memory handle (rc=%d).\n", rc);
            return CUDBG_ERROR_MEMORY_MAPPING_FAILED;
        }
        seghandle = seg->newmem;
    }

    /* For an in-process debugger client, a seg that already has a
     * host VA shouldn't be mapped again. The mapping will fail if
     * the seg originated from the malloc+pin path. */
    if ((haloGlobals.initData.flags & HALO_INIT_FLAGS_IN_PROCESS) &&
        seg->hostvaddr) {
        seg->mappedHostPtr = seg->hostvaddr + offset;
        goto done;
    }

    for (;;) {
        /* Try the mapping */
        rc = CudaRmMapMemory(globals.rmClient,
                             hDevice,
                             seghandle, offset,
                             size,
                             (void **)(uintptr_t)&seg->mappedHostPtr,
                             NV04_MAP_MEMORY_FLAGS_NONE);

        /* If we were successful, we don't need to unmap anything */
        if (rc == NV_OK)
            break;
        else if (rc == NV_ERR_NOT_SUPPORTED && seg->hostvaddr) {
            /* Bug 896577:  similar to the error check on dup above, we now
               also need to check if the mapping call returns not supported
               when dealing with malloc'd pointers that are pinned down. */
            HALO_TRACE(50, "RM cannot map from this handle (not supported). "
                       "Indicate upward to read from sysmem.\n");
            return CUDBG_ERROR_ADDRESS_NOT_IN_DEVICE_MEM;
        }
        else {
            /* This isn't necessarily an error -- we may have failed
               due to mapping too much (see below for unmap/retry). */
            HALO_TRACE(50, "Failed to map memory (rc=%d).\n", rc);
        }

        /* We weren't able to map the segment, so let's
         * see if we can unmap any previously mapped segment(s)
         * that haven't been used for a bit */
        res = unmapStaleMemoryMappings(dev, map);
        if (res != CUDBG_SUCCESS) {
            /* All entries have been unmapped, but we
             * still can't map this allocation.  This is
             * a safe-guard to prevent looping here forever. */
            HALO_ERROR("Cannot unmap stale mappings(res=%u) on mapping\n",
                       (uint32_t)res);
            return CUDBG_ERROR_MEMORY_MAPPING_FAILED;
        }
    }

done:
    /* We've mapped the range successfully, store
     * the mapping's information. */
    seg->mapped.start = offset;
    seg->mapped.size = size;

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalUnmapOneMemorySegment_RM(CudbgDevice dev, haloMemorySegment *seg)
{
    NvU32 hDevice;
    const CUdev* pDev;
    NvU32 rc;
    uint32_t seghandle;

    CUDBG_VERIFY(dev->deviceIdx == (int)seg->sourceDeviceIdx,
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments\n");

    pDev = globals.devices[dev->deviceIdx];
    if (!pDev)
        return CUDBG_ERROR_INTERNAL;

    hDevice = deviceGetRmHandle(pDev);
    if (!hDevice)
        return CUDBG_ERROR_INTERNAL;

    seghandle = seg->mem;
    if (dev->haloClient->state.dupRmHandles && seg->newmem)
        seghandle = seg->newmem;

    /* For an in-process debugger client, if the seg already had a
     * host VA, it wouldn't have been mapped in MapOneMemorySegment. */
    if ((haloGlobals.initData.flags & HALO_INIT_FLAGS_IN_PROCESS) &&
        seg->hostvaddr) {
        seg->mappedHostPtr = 0;
        goto done;
    }

    /* Unmap the segment from host memory */
    rc = CudaRmUnmapMemory(globals.rmClient, hDevice,
                           seghandle, (void *)(uintptr_t)seg->mappedHostPtr,
                           NV04_MAP_MEMORY_FLAGS_NONE);
    if (rc != NV_OK) {
        HALO_ERROR("Failed to unmap memory (rc=%d).\n", rc);
        return CUDBG_ERROR_INTERNAL;
    }
    seg->mappedHostPtr = 0;

    if (dev->haloClient->state.dupRmHandles && seg->newmem) {
        /* Free the dup'd handle in RM */
        rc = CudaRmFree(globals.rmClient, hDevice, seg->newmem);
        if (rc != NV_OK) {
            HALO_ERROR("Failed to free dup memory handle (rc=%d).\n", rc);
            return CUDBG_ERROR_INTERNAL;
        }

        /* Free the dup'd handle */
        handlePoolFree(globals.handlePool, seg->newmem);
        seg->newmem = 0;
    }

done:
    return CUDBG_SUCCESS;
}

static CUDBGResult
checkAndUnmapOneMemorySegment(CudbgDevice dev, haloMemorySegment *seg,
                              uint64_t currentTime, uint64_t maxAge,
                              bool *didUnmap)
{
    CUDBGResult res;

    CUDBG_VERIFY(dev && seg && didUnmap, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    *didUnmap = false;

    /* We only map segments on the device indentified by seg->sourceDeviceIdx.
     * If dev isn't the device seg is mapped on, return early. */
    if (dev->deviceIdx != (int)seg->sourceDeviceIdx)
        return CUDBG_SUCCESS;

    /* Nothing to do if the segment isn't even mapped. */
    if (!seg->mappedHostPtr)
        return CUDBG_SUCCESS;

    if (!maxAge || (currentTime - seg->lastUsed == maxAge)) {
        res = dev->dmal->unmapOneMemorySegment(dev, seg);
        if (res != CUDBG_SUCCESS)
            return res;

        /* Invalidate the mapping information */
        seg->mapped.start = 0;
        seg->mapped.size = 0;

        seg->lastUsed = 0;

        *didUnmap = true;
    }

    return CUDBG_SUCCESS;
}

typedef struct unmapSegData_st unmapSegData;
struct unmapSegData_st {
    uint64_t currentTime;
    uint64_t maxAge;
    CudbgDevice dev;
    bool didAnyUnmap;
};

static CUDBGResult
unmapMemorySegFunctor(haloMemoryMap *map, haloMemorySegment *seg, void *data)
{
    unmapSegData *d = (unmapSegData *)data;
    bool didUnmap = false;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(map && seg && d, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    res = checkAndUnmapOneMemorySegment(d->dev, seg, d->currentTime, d->maxAge, &didUnmap);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Error unmapping segment (res:%u)\n", res);
    d->didAnyUnmap |= didUnmap;

    return CUDBG_SUCCESS;
}

static CUDBGResult
unmapMemorySegments(CudbgDevice dev, haloMemoryMap *map, uint64_t maxAge)
{
    CUDBGResult res = CUDBG_SUCCESS;
    unmapSegData data = {0};

    CUDBG_VERIFY(map, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    data.currentTime = haloMemoryMapGetMemUseCurrentTime(map);
    data.maxAge = maxAge;
    data.dev = dev;
    data.didAnyUnmap = false;

    /* Go through all segments, unmapping all that were last
     * used at the oldest memUseCurrentTime.  A zero memUseCurrentTime as input
     * means that we want to unmap all entries (a cleanup call). */
    res = haloMemoryMapApplyFunctor(map, unmapMemorySegFunctor, &data);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Error unmapping segments\n");

    /* If any of the above calls actually unmapped memory, didAnyUnmap is true
     * return success */
    return (data.didAnyUnmap) ? CUDBG_SUCCESS : CUDBG_ERROR_MEMORY_UNMAPPING_FAILED;
}

/* Called when we're running low on BAR1 space. Unmaps stale mappings from the
 * specified map and global memMap from the specified device's BAR1. */
static CUDBGResult
unmapStaleMemoryMappings(CudbgDevice dev, haloMemoryMap *map)
{
    CUDBGResult res1 = CUDBG_SUCCESS, res2 = CUDBG_SUCCESS;
    uint64_t maxAge = 0;
    uint64_t memUseCurrentTime;
    haloMemoryMap *parentMap;

    CUDBG_VERIFY(dev && map, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    memUseCurrentTime = haloMemoryMapGetMemUseCurrentTime(map);

    res1 = haloMemoryMapGetMaxAge(map, memUseCurrentTime, &maxAge);
    CUDBG_VERIFY(res1 == CUDBG_SUCCESS, res1, "Failed to get max age\n");

    res1 = unmapMemorySegments(dev, map, maxAge);

    parentMap = haloMemoryMapGetParentMemMap(map);
    if (parentMap)
        res2 = unmapMemorySegments(dev, parentMap, maxAge);

    return (res1 == CUDBG_SUCCESS || res2 == CUDBG_SUCCESS) ?
            CUDBG_SUCCESS: CUDBG_ERROR_MEMORY_UNMAPPING_FAILED;
}

/*******************************************************************************
 *                                MEMORY MAPPING
 *******************************************************************************
 *
 * Memory mapping is managed at the context-level. Only one context can have
 * some memory mapped for access. The context for which some memory *may* be
 * mapped (we do not track if the number of memory segments that are mapped) is
 * tracked at the device level with:
 *
 *      dev->memMapContext;
 *
 * If memMapContext is NULL, then there is no active memory mapping.
 * MemMapContext is set when memory is mapped, and unset when all the mapped
 * memory is unmapped. The HALO map/unmapMemory functions will take care of
 * that.
 *
 * Because we do not currently track every memory allocation/deallocation in
 * real-time, we only get the current addresses of all the memory segments at
 * kernel launch. At that point in time, the memory mappings is saved for the
 * context in which the launch occurs in:
 *
 *      context->memMap;
 *
 * When there is no memory mapping available (before the first kernel launch of
 * the context), the memory mapping is invalid and the following field is set to
 * false:
 *
 *      context->memMapActive;
 *
 * Once memMapActive is set to true, it will remain that way until the context
 * is deleted.
 */
CUDBGResult
haloDmalUnmapMemory_RM(CudbgDevice dev)
{
    CUDBGResult res = CUDBG_SUCCESS;

    /* The global memMap holds segments that may be mapped on different devices.
     * Unmap all segments from the global map that are mapped on this device. */
    res = unmapMemorySegments(dev, haloStateGetGlobalMemMap(), 0);

    /* Print a warning and keep going on error. */
    if (res != CUDBG_SUCCESS)
        HALO_TRACE(10, "Failed to unmap memory segments in globalMemMap\n");

    /* If theres no actively mapped context, there's nothing more to unmap */
    if (!dev->memMapContext)
        return CUDBG_SUCCESS;

    if (!toolsHashMapContains(dev->contexts,
                              tHashMapNumToKey(dev->memMapContext->cuCtx))) {
        HALO_ERROR("Context unknown 0x%" PRIx64 "\n",dev->memMapContext->cuCtx);
        /* If we dont know the context, set the actively mapped context to NULL */
        dev->memMapContext = NULL;
        return CUDBG_ERROR_INVALID_CONTEXT;
    }

    res = unmapMemorySegments(dev, dev->memMapContext->memMap, 0);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE(10, "Failed to unmap memory segments on context : 0x%" PRIx64 "\n",
                   dev->memMapContext->cuCtx);
        /* If nothing was unmapped, then there is no actively mapped context */
        dev->memMapContext = NULL;
        return CUDBG_ERROR_MEMORY_UNMAPPING_FAILED;
    }

    dev->memMapContext = NULL;

    HALO_TRACE(10, "Unmapped all memory segments (res=%d)\n", res);
    return CUDBG_SUCCESS;
}

CUDBGResult
haloDmalMapMemory_RM(Context context, haloMemoryMap *memMap, uint64_t va, uint64_t size, char **hostPtr)
{
    CudbgDevice dev;
    CUDBGResult res;
    uint64_t offset, reqOffset;
    haloMemorySegment *seg = NULL;
    uint64_t memUseCurrentTime;

    CUDBG_VERIFY(memMap, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    /* Sanity check */
    CUDBG_VERIFY(hostPtr, CUDBG_ERROR_INTERNAL, "Invalid host ptr on mapping ctx : 0x%" PRIx64 "\n",
                 context ? context->cuCtx: 0);

    /* Find the segment corresponding to va */
    res = haloMemoryMapGetSegmentByDevVaddr(memMap, va, &seg);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Error in getSegment at va:0x%" PRIx64 " on mapping ctx:0x%" PRIx64 "\n",
                 va, context ? context->cuCtx: 0);
    if (seg == NULL) {
        /* Not necessarily a failure. */
        HALO_TRACE(50, "Cannot find memory segment at va:0x%" PRIx64 " on mapping ctx : 0x%" PRIx64 "\n",
                   (uint64_t)va, context ? context->cuCtx: 0);
        return CUDBG_ERROR_INVALID_MEMORY_SEGMENT;
    }

    dev = haloGlobals.device[seg->sourceDeviceIdx];

    /* If there already are some mappings from another context, unmap everything
       from that context first. Only one context per device can have anything mapped
       at a time. The global memory map can always have many of its segments mapped. */
    if (dev->memMapContext && context && context != dev->memMapContext)
        dev->haloClient->unmapMemory(dev);

    /* Remember which context the memory mappings are from. Necessary when
       unmapping a non-active context. */
    dev->memMapContext = context;

    HALO_TRACE(50, "Setting memMapContext to: 0x%" PRIx64 "\n", context ? context->cuCtx: 0);

    /* Store the offset into the allocation */
    offset = reqOffset = va - seg->devvaddr;

    /* Three cases:

       1. If we haven't mapped this segment (no size), then map it in.
       2. If the requested offset doesn't fall into the currently mapped
          range, unmap the current mapping then remap it with the new range.
       3. If we've already mapped this segment (valid range and size), just
          update the fact that this segment was just used, and update the
          hostPtr to reflect the requested offset. */

    /* Case 2 */
    if (seg->mapped.size > 0 &&
        !(seg->mapped.start <= offset &&
          offset + size <= seg->mapped.start + seg->mapped.size)) {
        bool didUnmap = false;
        /* This resets seg->mapped.size */
        res = checkAndUnmapOneMemorySegment(dev, seg, 0, 0, &didUnmap);
        (void)res;
        HALO_TRACE(20, "Unmapped seg (%p), res = %d didUnmap = %d\n", seg, res, didUnmap);
    }

    if (!seg->mapped.size) { /* if !mapped.size -> Case 1, else -> Case 3 */
        res = dev->dmal->mapOneMemorySegment(memMap, seg, offset, size);
        if (res != CUDBG_SUCCESS)
            return res;
    }

    /* Update hostPtr to point to the requested offset within the allocation */
    *(uintptr_t *)hostPtr = (uintptr_t)(seg->mappedHostPtr + (reqOffset - seg->mapped.start));

    /* Set this segment's last used to the most recent, then
     * update the global memUseCurrentTime tracker */
    memUseCurrentTime = haloMemoryMapGetMemUseCurrentTime(memMap);
    seg->lastUsed = ++memUseCurrentTime;
    haloMemoryMapSetMemUseCurrentTime(memMap, memUseCurrentTime);
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalReadBar1Size_RM(CudbgDevice dev, uint64_t *bar1Size)
{
    const CUdev* pDev;
    uint32_t hSubDevice;
    NV2080_CTRL_FB_INFO fbInfo;
    NV2080_CTRL_FB_GET_INFO_PARAMS fbInfoParams;
    NvU32 res;

    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    CUDBG_VERIFY(bar1Size, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments.\n");

    /* Obtain RM device handles */
    pDev = globals.devices[dev->deviceIdx];
    hSubDevice = deviceGetRmSubHandle(pDev);

    fbInfo.index = NV2080_CTRL_FB_INFO_INDEX_BAR1_SIZE;
    fbInfo.data = 0;
    fbInfoParams.fbInfoListSize = 1;
    fbInfoParams.fbInfoList = (NvP64)(uintptr_t)&fbInfo;

    res = CudaRmControl(globals.rmClient,
                        hSubDevice,
                        NV2080_CTRL_CMD_FB_GET_INFO,
                        &fbInfoParams,
                        sizeof(fbInfoParams));
    if (res != NV_OK)
        return CUDBG_ERROR_UNKNOWN;

    if (!fbInfo.data) {
        HALO_ERROR("BAR1:  RM returned 0 bytes!\n");
        return CUDBG_ERROR_UNKNOWN;
    }

    /* RM provides this in KB (see resman/kernel/fb/fermi/fbgf100.c
       and resman/kernel/fb/nv50/fbnv50.c).
       Starting with the GK110 Cray Nano, we support Bar1 sizes > 32bits.
       As a result, we must first store the result of the RM call into
       a 64 bit value, so that the shift will not result in incorrect
       truncation.
    */
    *bar1Size = fbInfo.data;
    *bar1Size <<= 10;

    if (!(*bar1Size)) {
        HALO_ERROR("BAR1 : After shift, got 0 bytes! (Exceeded shift amount ?)\n");
        return CUDBG_ERROR_UNKNOWN;
    }

    HALO_TRACE(1, "BAR1:  Total Size:  0x%" PRIx64 " bytes.\n", *bar1Size);

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectSetExceptionMask(CudbgDevice dev, DebugObject debugObj)
{
#if defined(NV83DE_CTRL_CMD_DEBUG_SET_EXCEPTION_MASK)
    NV_STATUS res = NV_OK;
    CUdev *pDev = globals.devices[dev->deviceIdx];
    NV83DE_CTRL_DEBUG_SET_EXCEPTION_MASK_PARAMS params = {0};

    if (!(haloGlobals.initData.flags & HALO_INIT_FLAGS_ENABLE_PER_CONTEXT_DEBUG_OBJECT))
        return CUDBG_SUCCESS;

    CUDBG_VERIFY(CUDBG_DEBUG_OBJECT_IS_VALID(debugObj),
                 CUDBG_ERROR_INVALID_CONTEXT,
                 "Invalid debug object handle!\n");

    if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_CILP) {
        params.exceptionMask = NV83DE_CTRL_DEBUG_SET_EXCEPTION_MASK_CILP;
        HALO_TRACE_FUNCTION(20, "Setting Exception mask to CILP\n");
    }
    else
        params.exceptionMask = NV83DE_CTRL_DEBUG_SET_EXCEPTION_MASK_TRAP    |
                               NV83DE_CTRL_DEBUG_SET_EXCEPTION_MASK_FATAL   |
                               NV83DE_CTRL_DEBUG_SET_EXCEPTION_MASK_SINGLE_STEP;

    if ((res = CudaRmControl(haloDmalGetRmClient(debugObj), debugObj.rm,
                             NV83DE_CTRL_CMD_DEBUG_SET_EXCEPTION_MASK,
                             &params, sizeof params))) {
        /* This may happen if the app has exited, for example */
        HALO_TRACE_FUNCTION(10, "Failed to set sm exception mask, err:0x%x.\n",
                            res);
        return CUDBG_ERROR_UNKNOWN;
    }
#endif
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalFreeOsEvent(CudbgDevice dev, cuosEvent *event)
{
    CUDBGResult res = CUDBG_SUCCESS;
#if !cuosOsIsMods()
    NvU32 rc = NVOS_STATUS_SUCCESS;
    NvU32 hSubDevice;
    const CUdev *pDev = NULL;

    pDev = globals.devices[dev->deviceIdx];
    hSubDevice = deviceGetRmSubHandle(pDev);
#if cuosOsIsLinux()
    /* Free os event */
    if ((rc = CudaRmFreeOsEvent(globals.rmClient, hSubDevice, event->readFd))) {
        CUDBG_ERROR("Failed to free the OS event -> %d (ignored).\n", rc);
        /* We want to make sure to clean everything up, even if we hit an error doing so.
           So hold the first error. */
        if (res == CUDBG_SUCCESS)
            res = CUDBG_ERROR_INTERNAL;
    }
#elif cuosOsIsApple()
    /* Free os event */
    if ((rc = CudaRmFreeOsEvent(globals.rmClient, (void *)(uintptr_t)event->notify_port))) {
        CUDBG_ERROR("Failed to free the OS event -> %d (ignored).\n", rc);
        /* We want to make sure to clean everything up, even if we hit an error doing so.
           So hold the first error. */
        if (res == CUDBG_SUCCESS)
            res = CUDBG_ERROR_INTERNAL;
    }
#elif cuosOsIsWindows()
    if ((rc = cuosEventDestroy(event))) {
        CUDBG_ERROR("Failed to free the OS event -> %d (ignored).\n", rc);
        /* We want to make sure to clean everything up, even if we hit an error doing so.
           So hold the first error. */
        if (res == CUDBG_SUCCESS)
            res = CUDBG_ERROR_INTERNAL;
    }
#else
    HALO_ERROR("Incompatible display driver.\n");
    res = CUDBG_ERROR_INCOMPATIBLE_DISPLAY_DRIVER;
#endif
#endif
    return res;
}

static CUDBGResult
haloDmalAllocOsEvent(CudbgDevice dev, cuosEvent *event, void **hEvent)
{
    CUDBGResult res = CUDBG_SUCCESS;
#if !cuosOsIsMods()
    NvU32 rc = NVOS_STATUS_SUCCESS;
    NvU32 hSubDevice;
    const CUdev *pDev = NULL;

    pDev = globals.devices[dev->deviceIdx];
    hSubDevice = deviceGetRmSubHandle(pDev);
#if cuosOsIsLinux()
    rc = CudaRmAllocOsEvent(globals.rmClient, hSubDevice, NULL, (void *)&event->readFd);
    if (rc != NV_OK) {
        HALO_ERROR("Failed to allocate OS event -> 0x%x, fd %d.\n", rc, event->readFd);
        return CUDBG_ERROR_UNKNOWN;
    }
    event->writeFd = -1;
    event->createdByCuos = 0;
    *hEvent = (void *)&event->readFd;
#elif cuosOsIsApple()
    rc = CudaRmAllocOsEvent(globals.rmClient, (void **)&event->notify_port);
    if (rc != NV_OK) {
        HALO_ERROR("Failed to allocate OS event -> 0x%x.\n", rc);
        res = CUDBG_ERROR_UNKNOWN;
        goto done;
    }
    event->createdByCuos = 0;
    *hEvent = (void *)(uintptr_t)event->notify_port;
#elif cuosOsIsWindows()
    rc = cuosEventCreate(event);
    if (rc != CUOS_SUCCESS) {
        HALO_ERROR("Failed to allocate OS event -> 0x%x.\n", rc);
        res = CUDBG_ERROR_UNKNOWN;
        goto done;
    }
    *hEvent = (void *)event->hEvent;
#else
    HALO_ERROR("Incompatible display driver.\n");
    res = CUDBG_ERROR_INCOMPATIBLE_DISPLAY_DRIVER;
    goto done;
#endif
done:
#endif
    return res;
}

static CUDBGResult
haloDmalDebugObjectFreeEvent_RM(CudbgDevice dev, DebugObject debugObj, cuosEvent *event, uint32_t hDebugEvent)
{
    CUDBGResult res = CUDBG_SUCCESS;
#if !cuosOsIsMods()
    NvU32 rc = NVOS_STATUS_SUCCESS;
    const CUdev *pDev = globals.devices[dev->deviceIdx];
    NvU32 hSubDevice = deviceGetRmSubHandle(pDev);
    NvU32 hParent;
    if (!dev->dmal->debugObjectHasPerContextEvents())
        return CUDBG_SUCCESS;

   hParent = dev->dmal->debugObjectCanBeAllocatedInProcess() ?
             globals.rmClient : debugObj.rm;

    /* Free event */
    if ((rc = CudaRmFree(globals.rmClient, hParent, hDebugEvent))) {
        CUDBG_ERROR("Failed to free event object -> %d (ignored).\n", rc);
        res = CUDBG_ERROR_INTERNAL;
    }

    /* Free the event handle */
    handlePoolFree(globals.handlePool, hDebugEvent);

    res = haloDmalFreeOsEvent(dev, event);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to free os event object\n");
        return res;
    }
#endif

    return res;
}

static CUDBGResult
haloDmalDebugObjectAllocEvent_RM(CudbgDevice dev, DebugObject debugObj, uint32_t eventClassType, cuosEvent *event, uint32_t *hDebugEvent)
{
    // This function is stubbed on Mac until we need to support debugger there
#if !cuosOsIsMods() && !cuosOsIsApple()
    CUDBGResult res = CUDBG_SUCCESS;
    const CUdev *pDev = NULL;
    void *hEvent = NULL;
    NvU32 rc = NVOS_STATUS_SUCCESS;
    NvU32 hSubDevice;

    CUDBG_VERIFY(dev && event && hDebugEvent, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    if (!dev->dmal->debugObjectHasPerContextEvents())
        return CUDBG_SUCCESS;

    pDev = globals.devices[dev->deviceIdx];
    hSubDevice = deviceGetRmSubHandle(pDev);

    res = haloDmalAllocOsEvent(dev, event, &hEvent);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to allocate os event object\n");
        return res;
    }

    /* Add in the subdevice filter for the event type */
    eventClassType |= NV01_EVENT_SUBDEVICE_SPECIFIC;
    eventClassType |= DRF_NUM(0005, _NOTIFY_INDEX, _SUBDEVICE, pDev->state.subDeviceIndex);

    /* Build a per-context NvEvent bound on the OsEvent */
    *hDebugEvent = handlePoolAlloc(globals.handlePool);
    CUDBG_VERIFY(*hDebugEvent, CUDBG_ERROR_INTERNAL, "Allocating handle failed\n");

    /* Allocate the event handling binding everything together */

    if (dev->dmal->debugObjectCanBeAllocatedInProcess()) {
        NV0005_ALLOC_PARAMETERS nv0005 = {0};

        nv0005.hParentClient        = debugObj.rmClient;
        nv0005.hSrcResource         = debugObj.rm;
        nv0005.bMultiClientSupport  = NV_TRUE;
        nv0005.hClass               = NV01_EVENT_OS_EVENT;
        nv0005.notifyIndex          = eventClassType;
        nv0005.data                 = NV_PTR_TO_NvP64(hEvent);

        rc = CudaRmAlloc(globals.rmClient, globals.rmClient, *hDebugEvent,
                         NV01_EVENT_OS_EVENT, &nv0005);
    }
    else {
        rc = CudaRmAllocEvent(globals.rmClient, debugObj.rm, *hDebugEvent,
                              NV01_EVENT_OS_EVENT, eventClassType, hEvent);
    }
    if (rc != NV_OK) {
        HALO_ERROR("Failed to allocate RM event -> 0x%x.\n", rc);
        return CUDBG_ERROR_UNKNOWN;
    }
#endif

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectAlloc_RM(Context ctx, uint32_t hAppClient,
                            uint32_t hComputeObject, DebugObject *debugObj)
{
#if defined(NV83DE_CTRL_CMD_FIFO_SUSPEND_RESUME_CTXSW)
    NV_STATUS res = NV_OK;
    CUdev *pDev = globals.devices[ctx->dev->deviceIdx];
    DebugObject debugObjTemp = {0};
    NV83DE_ALLOC_PARAMETERS params = {0};
    CUDBGResult status = CUDBG_SUCCESS;

    CUDBG_VERIFY((hAppClient != CUDBG_INVALID_HANDLE &&
                  hComputeObject != CUDBG_INVALID_HANDLE),
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args for allocating RM Debug Object\n");

    debugObjTemp.rm = handlePoolAlloc(globals.handlePool);

    params.hAppClient = hAppClient;
    params.hClass3dObject = hComputeObject;

    /* Allocate the RM debug object */
    res = CudaRmAlloc(globals.rmClient, globals.rmClient, debugObjTemp.rm,
                      GT200_DEBUGGER, (void *)&params);
    if (res != NV_OK) {
        return CUDBG_ERROR_UNKNOWN;
    }

    /* Turn on only some exceptions */
    status = haloDmalDebugObjectSetExceptionMask(ctx->dev, debugObjTemp);
    CUDBG_VERIFY(status == CUDBG_SUCCESS, status, "Failed to set exception mask for debug object\n");

    debugObj->rm = debugObjTemp.rm;
#endif

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectFree_RM(Context ctx, DebugObject *debugObj, uint32_t *hComputeObj)
{
#if defined(NV83DE_CTRL_CMD_FIFO_SUSPEND_RESUME_CTXSW)
    NV_STATUS res = NV_OK;

    CUDBG_VERIFY(CUDBG_DEBUG_OBJECT_IS_VALID(*debugObj),
                 CUDBG_ERROR_INVALID_CONTEXT,
                 "Invalid debug object!\n");

    res = CudaRmFree(haloDmalGetRmClient(*debugObj), haloDmalGetRmClient(*debugObj), debugObj->rm);
    if (res != NV_OK) {
        return CUDBG_ERROR_UNKNOWN;
    }

    debugObj->rm = CUDBG_INVALID_HANDLE;
#endif

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectPauseGrCtxSwitch_RM(CudbgDevice dev)
{
#if defined(NV83DE_CTRL_CMD_FIFO_SUSPEND_RESUME_CTXSW)
    NV83DE_CTRL_FIFO_SUSPEND_RESUME_CTXSW_PARAMS params = {0};
    NvU32 res = NV_OK;
    CUdev *pDev = globals.devices[dev->deviceIdx];
    DebugObject debugObj;

    if (!(haloGlobals.initData.flags & HALO_INIT_FLAGS_ENABLE_PER_CONTEXT_DEBUG_OBJECT))
        return CUDBG_SUCCESS;

    res = haloDmalDebugObjectGetAnyDebugObjHandle_RM(dev, &debugObj);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Errored out while trying to find a debug object!\n");
        return (CUDBGResult)res;
    }
    else if (!CUDBG_DEBUG_OBJECT_IS_VALID(debugObj)) {
        /* This can happen if no ctx creation callback has been received yet
           during early stages of the app, or during shutdown. */
        HALO_TRACE_FUNCTION(10, "No debug object found), skipping suspend!\n");
        return CUDBG_ERROR_INVALID_CONTEXT;
    }

    params.srAction = NV83DE_CTRL_FIFO_SUSPEND_ACTION;

    if ((res = CudaRmControl(haloDmalGetRmClient(debugObj), debugObj.rm,
                             NV83DE_CTRL_CMD_FIFO_SUSPEND_RESUME_CTXSW,
                             &params, sizeof params))) {
        /* Work around RM bug */
        if (res != NV_ERR_INVALID_DATA) {
            HALO_ERROR("Failed to suspend ctx switch %d via Debug Object, res = 0x%x.\n",
                       dev->deviceIdx, res);
            return CUDBG_ERROR_UNKNOWN;
        }
    }
#endif

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectResumeGrCtxSwitch_RM(CudbgDevice dev)
{
#if defined(NV83DE_CTRL_CMD_FIFO_SUSPEND_RESUME_CTXSW)
    NV83DE_CTRL_FIFO_SUSPEND_RESUME_CTXSW_PARAMS params = {0};
    NvU32 res = NV_OK;
    CUdev *pDev = globals.devices[dev->deviceIdx];
    DebugObject debugObj;

    if (!(haloGlobals.initData.flags & HALO_INIT_FLAGS_ENABLE_PER_CONTEXT_DEBUG_OBJECT))
        return CUDBG_SUCCESS;

    res = haloDmalDebugObjectGetAnyDebugObjHandle_RM(dev, &debugObj);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Errored out while trying to find a debug object!\n");
        return (CUDBGResult)res;
    }
    else if (!CUDBG_DEBUG_OBJECT_IS_VALID(debugObj)) {
        /* This can happen if no ctx creation callback has been received yet
           during early stages of the app, or during shutdown. */
        HALO_TRACE_FUNCTION(10, "No debug object found), skipping suspend!\n");
        return CUDBG_ERROR_INVALID_CONTEXT;
    }

    params.srAction = NV83DE_CTRL_FIFO_RESUME_ACTION;

    if ((res = CudaRmControl(haloDmalGetRmClient(debugObj), debugObj.rm,
                             NV83DE_CTRL_CMD_FIFO_SUSPEND_RESUME_CTXSW,
                             &params, sizeof params))) {
        HALO_ERROR("Failed to resume context switch %d via Debug Object, res = 0x%x.\n",
                   dev->deviceIdx, res);
        return CUDBG_ERROR_UNKNOWN;
    }
#endif

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectGetResidentChannelHandle_RM(CudbgDevice dev, DebugObject debugObj,
                                               uint32_t *hChannel)
{
#if defined(NV83DE_CTRL_CMD_FIFO_GET_CTX_RESIDENT_STATE)
    NV83DE_CTRL_FIFO_GET_CTX_RESIDENT_STATE_PARAMS params = {0};
    NV_STATUS res = NV_OK;
    CUdev *pDev = globals.devices[dev->deviceIdx];

    if (!(haloGlobals.initData.flags & HALO_INIT_FLAGS_ENABLE_PER_CONTEXT_DEBUG_OBJECT))
        return CUDBG_SUCCESS;

    CUDBG_VERIFY(hChannel, CUDBG_ERROR_INVALID_ARGS, "Invalid hChannel\n");

    CUDBG_VERIFY(CUDBG_DEBUG_OBJECT_IS_VALID(debugObj),
                 CUDBG_ERROR_INVALID_CONTEXT,
                 "Invalid debug object handle!\n");

    if ((res = CudaRmControl(haloDmalGetRmClient(debugObj), debugObj.rm,
                             NV83DE_CTRL_CMD_FIFO_GET_CTX_RESIDENT_STATE,
                             &params, sizeof params))) {
        /* This may happen if the app has exited, for example */
        HALO_TRACE_FUNCTION(10, "Failed to get resident context handle, err:0x%x.\n",
                            res);
        return CUDBG_ERROR_UNKNOWN;
    }

    *hChannel = params.hChannel;
#endif

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectReadSMESRInfo_RM(CudbgDevice dev, DebugObject debugObj, uint32_t vsm, CudbgSMESRState_t *esrState)
{
#if defined(NV83DE_CTRL_CMD_DEBUG_READ_SINGLE_SM_ERROR_STATE)
    NV83DE_CTRL_DEBUG_READ_SINGLE_SM_ERROR_STATE_PARAMS params = {0};
    NvU32 res = NVOS_STATUS_SUCCESS;
    CUdev *pDev = globals.devices[dev->deviceIdx];

    if (!(haloGlobals.initData.flags & HALO_INIT_FLAGS_ENABLE_PER_CONTEXT_DEBUG_OBJECT))
        return CUDBG_SUCCESS;

    CUDBG_VERIFY(esrState, CUDBG_ERROR_INVALID_ARGS, "Invalid ESR state\n");

    CUDBG_VERIFY(CUDBG_DEBUG_OBJECT_IS_VALID(debugObj),
                 CUDBG_ERROR_INVALID_CONTEXT,
                 "Invalid debug object handle!\n");

    params.smID = vsm;
    params.hTargetChannel = NV01_NULL_OBJECT;

    if ((res = CudaRmControl(haloDmalGetRmClient(debugObj), debugObj.rm,
                             NV83DE_CTRL_CMD_DEBUG_READ_SINGLE_SM_ERROR_STATE,
                             &params, sizeof params))) {
        /* This may happen if the app has exited, for example */
        HALO_TRACE_FUNCTION(10, "Failed to get SM error state, err:0x%x.\n",
                            res);
        return CUDBG_ERROR_UNKNOWN;
    }

    esrState->hwwglobalesr = params.smErrorState.hwwGlobalEsr;
    esrState->hwwwarpesr   = params.smErrorState.hwwWarpEsr;
    esrState->hwwwarpesrpc = params.smErrorState.hwwWarpEsrPc64;
    esrState->hwwglobalesrmask = params.smErrorState.hwwGlobalEsrReportMask;
    esrState->hwwwarpesrmask = params.smErrorState.hwwWarpEsrReportMask;

    if ( esrState->hwwglobalesr || esrState->hwwwarpesr) {
        HALO_TRACE_FUNCTION(2, "Debug object found outstanding error "
                            "on SMID:%u Global ESR:0x%x Warp ESR:0x%x PC:0x%x\n",
                            vsm, params.smErrorState.hwwGlobalEsr,
                            params.smErrorState.hwwWarpEsr,
                            params.smErrorState.hwwWarpEsrPc);
    }

#endif

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectClearSMESRInfo_RM(CudbgDevice dev, DebugObject debugObj, uint32_t vsm, CudbgSMESRState_t *esrState)
{
#if defined(NV83DE_CTRL_CMD_DEBUG_CLEAR_SINGLE_SM_ERROR_STATE)
    NV83DE_CTRL_DEBUG_CLEAR_SINGLE_SM_ERROR_STATE_PARAMS params = {0};
    NvU32 res = NVOS_STATUS_SUCCESS;
    CUdev *pDev = globals.devices[dev->deviceIdx];

    if (!(haloGlobals.initData.flags & HALO_INIT_FLAGS_ENABLE_PER_CONTEXT_DEBUG_OBJECT))
        return CUDBG_SUCCESS;

    CUDBG_VERIFY(esrState, CUDBG_ERROR_INVALID_ARGS, "Invalid ESR state\n");

    CUDBG_VERIFY(CUDBG_DEBUG_OBJECT_IS_VALID(debugObj),
                 CUDBG_ERROR_INVALID_CONTEXT,
                 "Invalid debug object handle!\n");

    params.smID = vsm;
    params.hTargetChannel = NV01_NULL_OBJECT;

    HALO_TRACE_FUNCTION(50, "Using debug object to reset ESR info on SMID:%u\n",
                        vsm);

    if ((res = CudaRmControl(haloDmalGetRmClient(debugObj), debugObj.rm,
                             NV83DE_CTRL_CMD_DEBUG_CLEAR_SINGLE_SM_ERROR_STATE,
                             &params, sizeof params))) {
        /* This may happen if the app has exited, for example */
        HALO_TRACE_FUNCTION(10, "Failed to get write error state, err:0x%x.\n",
                            res);
        return CUDBG_ERROR_UNKNOWN;
    }

#endif

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectSetMMUDebugMode_RM(Context ctx, bool on)
{
    NV_STATUS status;
    NV83DE_CTRL_DEBUG_SET_MODE_MMU_DEBUG_PARAMS params;

    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_ARGS, "Invalid context\n");

    params.action = on ? NV83DE_CTRL_CMD_DEBUG_SET_MODE_MMU_DEBUG_ENABLE :
                         NV83DE_CTRL_CMD_DEBUG_SET_MODE_MMU_DEBUG_DISABLE;

    status = CudaRmControl(ctx->debugObj.rmClient, ctx->debugObj.rm,
                           NV83DE_CTRL_CMD_DEBUG_SET_MODE_MMU_DEBUG,
                           &params, sizeof(params));
    if (status != NV_OK) {
        HALO_ERROR("Failed to set MMU DEBUG mode (nvos res=%d).\n", status);
        return CUDBG_ERROR_UNKNOWN;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
getDebugObjHandleFromCtx(Context context, void *userData)
{
    DebugObjFunctor *debugObjFunctor = (DebugObjFunctor *)userData;

    if (CUDBG_DEBUG_OBJECT_IS_VALID(*debugObjFunctor->debugObj))
        /* Already found */
        return CUDBG_SUCCESS;

    /* Restrict the search to contexts on the device we care about. */
    if (debugObjFunctor->dev != context->dev)
        return CUDBG_SUCCESS;

    /* Skip contexts that are in the middle of being destroyed */
    if (!haloStateContextIsActive(context))
        return CUDBG_SUCCESS;

    /* This context may not have a debug object allocated yet. This happens if
     * the context has not yet received a ctx create callback from the driver.
     * If so, skip it. */
    if (!CUDBG_DEBUG_OBJECT_IS_VALID(context->debugObj))
        return CUDBG_SUCCESS;

    *debugObjFunctor->debugObj = context->debugObj;

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectGetAnyDebugObjHandle_RM(CudbgDevice dev, DebugObject *debugObj)
{
    CUDBGResult res = CUDBG_SUCCESS;
    DebugObjFunctor debugObjFunctor;

    debugObjFunctor.dev = dev;
    debugObjFunctor.debugObj = debugObj;

    memset(debugObj, 0, sizeof(DebugObject));

    if (!(haloGlobals.initData.flags & HALO_INIT_FLAGS_ENABLE_PER_CONTEXT_DEBUG_OBJECT))
        return CUDBG_SUCCESS;

    /* Traverse the list of contexts and return the first valid debug object handle on this device. */
    haloStateTraverseContexts((haloCtxIterFunc)getDebugObjHandleFromCtx, &debugObjFunctor);

    return res;
}

static CUDBGResult
findContextForChannel(Context context, void *userData)
{
    FindContextForChannelFunctor *functor = (FindContextForChannelFunctor*)userData;
    uint32_t i=0;

    if (functor->context)
        return CUDBG_SUCCESS;

    for (i=0; i<CUDBG_MAX_CHANNELS; ++i) {
        if (functor->hChannel == context->hComputeChannelList[i]) {
          HALO_TRACE_FUNCTION(50, "hChannel=0x%x belongs to ctx=%p\n", functor->hChannel, context);
          functor->context = context;
          break;
        }
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectSuspendContext_RM(Context ctx, bool *waitForEvent)
{
#if defined(NV83DE_CTRL_CMD_DEBUG_SUSPEND_CONTEXT)
    NvU32 cuRes = NV_OK;
    DebugObject debugObj;
    NV83DE_CTRL_CMD_DEBUG_SUSPEND_CONTEXT_PARAMS params = {0};

    CUDBG_VERIFY(ctx && waitForEvent, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    /* Note: CUDBG_ERROR_INVALID_CONTEXT is expected to be returned from
       this function by some of the callers.
     */

    if (!CUDBG_DEBUG_OBJECT_IS_VALID(ctx->debugObj)) {
        /* This can happen if no ctx creation callback has been received yet
           during early stages of the app, or during shutdown. */
        HALO_TRACE_FUNCTION(10, "No debug object found, skipping suspend!\n");
        return CUDBG_ERROR_INVALID_CONTEXT;
    }

    debugObj = ctx->debugObj;

    HALO_TRACE_FUNCTION(10, "Suspending context via debug object 0x%x\n", debugObj.rm);

    if ((cuRes = CudaRmControl(haloDmalGetRmClient(debugObj), debugObj.rm,
                               NV83DE_CTRL_CMD_DEBUG_SUSPEND_CONTEXT,
                               &params, sizeof(params)))) {
        switch (cuRes) {
        case NV_ERR_NOT_READY:
                /* This can happen if a context is created, but has not yet enabled debug mode
                   (there is a small window of time in between those two events where we can
                   attempt to suspend). */
                HALO_TRACE_FUNCTION(10, "RM returned cuRes = 0x%x while suspending "
                                    "context via debug object 0x%x.  Ignoring.\n",
                                    cuRes, debugObj.rm);
                break;
        case NV_ERR_INVALID_STATE:
                /* This can happen if the app exits, causing its handles to be freed. */
                HALO_ERROR("RM returned cuRes = 0x%x while suspending context via debug object "
                           "0x%x, skipping suspend!\n", cuRes, debugObj.rm);
                return CUDBG_ERROR_INVALID_CONTEXT;
        default:
                HALO_ERROR("Failed to suspend context via debug object 0x%x, cuRes = 0x%x.\n",
                           debugObj.rm, cuRes);
                return CUDBG_ERROR_UNKNOWN;
        }
    }
    *waitForEvent = params.waitForEvent;

    HALO_TRACE_FUNCTION(30, "Suspended context, debugObj=0x%x, waitForEvent=%d\n", debugObj.rm, *waitForEvent);

    return CUDBG_SUCCESS;
#else
    HALO_ERROR("Suspending contexts not supported\n");

    return CUDBG_ERROR_INTERNAL;
#endif
}

typedef struct {
    bool hasValidContexts;
    bool hasStopped;
    bool waitForEvent;
    Context residentContext;
    CudbgDevice dev;
} ContextSuspendState;

static CUDBGResult
haloDmalSuspendContextFn_RM(Context ctx, void *data)
{
    CUDBGResult res = CUDBG_SUCCESS;
    ContextSuspendState *state = (ContextSuspendState *)data;
    bool waitForEvent;

   /* Calling suspend on a ctx that is not owned by this device is incorrect.
     * Halo keeps all context in one global array, it tries to apply
     * every context to every device. This is a flaw if the devices have different DMALs.
     */
    if (state->dev != ctx->dev) {
        return CUDBG_SUCCESS;
    }

    /* Finding an invalid context here is not an error as SuspendDevice could be called during context initialization */
    if (!CUDBG_DEBUG_OBJECT_IS_VALID(ctx->debugObj)) {
        return CUDBG_SUCCESS;
    }

    /* Skip contexts that are in the middle of being destroyed */
    if (!haloStateContextIsActive(ctx)) {
        return CUDBG_SUCCESS;
    }

    res = haloDmalDebugObjectSuspendContext_RM(ctx, &waitForEvent);

    state->hasValidContexts = true;
    if (res == CUDBG_SUCCESS) {
        if (waitForEvent) {
            state->waitForEvent = true;
            state->residentContext = ctx;
        }
    }
    else {
        state->hasStopped = false;
    }

    return res;
}

static CUDBGResult
haloDmalDebugObjectSuspendDevice_RM(CudbgDevice dev, uint32_t *hasStopped, uint32_t *waitForEvent, Context *residentContext)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(hasStopped && waitForEvent && residentContext, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    HALO_TRACE_FUNCTION(10, "Suspending device %d using debug objects\n", dev->deviceIdx);

    if (haloDmalDebugObjectCanSuspendResumeSingleContext_RM()) {
        /* Iterate over contexts and suspend each of them separately. The results are defined as such:
            - hasStopped: all valid contexts have been suspended or no valid contexts
            - waitForEvent: one of the valid suspended contexts requires the debug agent to wait for a device event
            - residentContext: the context that needs to be waited on
            - result:
               - CUDBG_ERROR_INVALID_CONTEXT if no active contexts (HALO expects this error)
               - CUDBG_ERROR_INTERNAL if one of the valid context suspensions failed
               - CUDBG_SUCCESS if there is at least one valid contexts and all valid contexts have been suspended */
        ContextSuspendState state = { 0 };

        state.hasValidContexts = false;
        state.hasStopped = true;
        state.waitForEvent = false;
        state.dev = dev;

        res = haloStateTraverseContexts(haloDmalSuspendContextFn_RM, &state);

        if (!state.hasValidContexts) {
            *hasStopped = true;
            *waitForEvent = false;
            *residentContext = NULL;
            return CUDBG_ERROR_INVALID_CONTEXT;
        }

        *hasStopped = state.hasStopped;
        *waitForEvent = state.waitForEvent;
        *residentContext = state.residentContext;
    }
#if defined(NV83DE_CTRL_CMD_DEBUG_SUSPEND_ALL_CONTEXTS_FOR_CLIENT)
    else {
        NvU32 cuRes = NV_OK;
        CUdev *pDev = globals.devices[dev->deviceIdx];
        DebugObject debugObj;
        void *pParams = NULL;
        uint32_t params_sz = 0;
#if defined(NV83DE_CTRL_CMD_DEBUG_SUSPEND_ALL_CONTEXTS_FOR_CLIENT_PARAMS_DEFINED)
        NV83DE_CTRL_CMD_DEBUG_SUSPEND_ALL_CONTEXTS_FOR_CLIENT_PARAMS params = {0};

        pParams = &params;
        params_sz = sizeof(params);
#endif

        res = haloDmalDebugObjectGetAnyDebugObjHandle_RM(dev, &debugObj);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Errored out while trying to find a debug object!\n");
            return res;
        }
        else if (!CUDBG_DEBUG_OBJECT_IS_VALID(debugObj)) {
            /* This can happen if no ctx creation callback has been received yet
               during early stages of the app, or during shutdown. */
            HALO_TRACE_FUNCTION(10, "No debug object found), skipping suspend!\n");
            *hasStopped = 1;
            return CUDBG_ERROR_INVALID_CONTEXT;
        }

        if ((cuRes = CudaRmControl(haloDmalGetRmClient(debugObj), debugObj.rm,
                                   NV83DE_CTRL_CMD_DEBUG_SUSPEND_ALL_CONTEXTS_FOR_CLIENT,
                                   pParams, params_sz))) {
            switch (cuRes) {
            case NV_ERR_NOT_READY:
                    /* This can happen if a context is created, but has not yet enabled debug mode
                       (there is a small window of time in between those two events where we can
                       attempt to suspend). */
                    HALO_TRACE_FUNCTION(10, "RM returned cuRes = 0x%x while suspending "
                                        "device %d.  Ignoring.\n",
                                        cuRes, dev->deviceIdx);
                    break;
            case NV_ERR_INVALID_STATE:
                    /* This can happen if the app exits, causing its handles to be freed. */
                    HALO_ERROR("RM returned cuRes = 0x%x while suspending device %d via debug object "
                               "0x%" PRIx64 ", skipping suspend!\n", cuRes,
                               dev->deviceIdx, debugObj.rm);
                    *hasStopped = 1;
                    return CUDBG_ERROR_INVALID_CONTEXT;
            default:
                    HALO_ERROR("Failed to suspend device %d via debug object 0x%" PRIx64 ", cuRes = 0x%x.\n",
                               dev->deviceIdx, debugObj.rm, cuRes);
                    return CUDBG_ERROR_UNKNOWN;
            }
        }
#if defined(NV83DE_CTRL_CMD_DEBUG_SUSPEND_ALL_CONTEXTS_FOR_CLIENT_PARAMS_DEFINED)
        *waitForEvent = params.waitForEvent;
        if (params.hResidentChannel != CUDBG_INVALID_HANDLE) {
            FindContextForChannelFunctor functor = {0};

            functor.hChannel = params.hResidentChannel;

            res = haloStateTraverseContexts(findContextForChannel, &functor);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to find context for channel 0x%x\n",
                         functor.hChannel);
            /* This is the context that was resident at the time we suspended.
               This is the context that will have an event when async suspend
               completes that we need to wait on before inspecting its state */
            *residentContext = functor.context;
            /* If debugger backend doesn't know about this context, ignore it. 
               NOTE: this may cause problems if we race and RESUME_ALL, resuming
               this context before it is preempted off.  RM could RC the
               channel when the CTXSW interrupt comes in.  Since this race is
               very unlikely, ignore it for now. */
            *waitForEvent &= !!(*residentContext);
        }
#else   /* ! NV83DE_CTRL_CMD_DEBUG_SUSPEND_ALL_CONTEXTS_FOR_CLIENT_PARAMS_DEFINED */
        *waitForEvent = dev->preemptionType == HALO_PREEMPTION_TYPE_CILP;
#endif
    }
#endif

    HALO_TRACE_FUNCTION(30, "Suspended device, residentContext=%p, waitForEvent=%d\n", *residentContext, *waitForEvent);

    return res;
}

static CUDBGResult
haloDmalDebugObjectResumeContext_RM(Context ctx)
{
#if defined(NV83DE_CTRL_CMD_DEBUG_RESUME_CONTEXT)
    CUDBGResult res;
    NvU32 cuRes = NV_OK;
    DebugObject debugObj;

    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    debugObj = ctx->debugObj;

    res = haloInvalidateCaches(ctx->dev);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Errored out while trying to invalidate caches\n");
        return res;
    }

    HALO_TRACE_FUNCTION(10, "Resuming context using debug object 0x%x\n", debugObj.rm);

    if (!CUDBG_DEBUG_OBJECT_IS_VALID(debugObj)) {
        /* This can happen if no ctx creation callback has been received yet
           during early stages of the app, or during shutdown. */
        HALO_TRACE_FUNCTION(10, "No debug object found, skipping resume!\n");
        /* Fake success */
        return CUDBG_SUCCESS;
    }

    if ((cuRes = CudaRmControl(haloDmalGetRmClient(debugObj), debugObj.rm,
                               NV83DE_CTRL_CMD_DEBUG_RESUME_CONTEXT,
                               NULL, 0))) {
        if (cuRes == NV_ERR_INVALID_STATE) {
            /* This can happen if the app exits, causing its handles to be freed. */
            HALO_ERROR("RM returned cuRes = 0x%x while resuming context via debug object "
                       "0x%x, skipping resume!\n", cuRes, debugObj.rm);
            /* Fake success */
            return CUDBG_SUCCESS;
        }
        else {
            HALO_ERROR("Failed to resume context via debug object 0x%x, cuRes = 0x%x.\n",
                       debugObj.rm, cuRes);
            return CUDBG_ERROR_UNKNOWN;
        }
    }

    return CUDBG_SUCCESS;
#else
    HALO_ERROR("Resuming contexts not supported\n");

    return CUDBG_ERROR_INTERNAL;
#endif
}

typedef struct {
    bool hasValidContexts;
    bool hasResumed;
    CudbgDevice dev;
} ContextResumeState;

static CUDBGResult
haloDmalResumeContextFn_RM(Context ctx, void *data)
{
    CUDBGResult res;
    ContextResumeState *state = (ContextResumeState *)data;

    /* Calling suspend on a ctx that is not owned by this device is incorrect.
     * Halo keeps all context in one global array, it tries to apply
     * every context to every device. This is a flaw if the devices have different DMALs.
     */
    if (state->dev != ctx->dev) {
        return CUDBG_SUCCESS;
    }

    /* Finding an invalid context here is not an error as ResumeDevice could be called during context initialization */
    if (!CUDBG_DEBUG_OBJECT_IS_VALID(ctx->debugObj)) {
        return CUDBG_SUCCESS;
    }

    /* Skip contexts that are in the middle of being destroyed */
    if (!haloStateContextIsActive(ctx)) {
        return CUDBG_SUCCESS;
    }

    res = haloDmalDebugObjectResumeContext_RM(ctx);

    state->hasValidContexts = true;
    if (res != CUDBG_SUCCESS) {
        state->hasResumed = false;
    }

    return res;
}

static CUDBGResult
haloDmalDebugObjectResumeDevice_RM(CudbgDevice dev, uint32_t *hasResumed)
{
    CUDBGResult res = CUDBG_SUCCESS;

    HALO_TRACE_FUNCTION(10, "Resuming device %d using debug objects\n", dev->deviceIdx);

    if (haloDmalDebugObjectCanSuspendResumeSingleContext_RM()) {
        /* Iterate over contexts and resume each of them separately. The results are defined as such:
           - hasResumed: all valid contexts have been resumed or no valid contexts
           - result:
              - CUDBG_ERROR_INTERNAL if one of the valid context resumes failed
              - CUDBG_SUCCESS if all valid contexts have been resumed or no valid contexts */
        ContextResumeState state = {0};

        state.hasValidContexts = false;
        state.hasResumed = true;
        state.dev = dev;

        res = haloStateTraverseContexts(haloDmalResumeContextFn_RM, &state);

        if (!state.hasValidContexts) {
            *hasResumed = true;
            return CUDBG_SUCCESS;
        }

        *hasResumed = state.hasResumed;
    }
#if defined(NV83DE_CTRL_CMD_DEBUG_RESUME_ALL_CONTEXTS_FOR_CLIENT)
    else {
        NvU32 cuRes = NV_OK;
        CUdev *pDev = globals.devices[dev->deviceIdx];
        DebugObject debugObj;

        res = haloInvalidateCaches(dev);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Errored out while trying to invalidate caches\n");
            return res;
        }

        res = haloDmalDebugObjectGetAnyDebugObjHandle_RM(dev, &debugObj);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Errored out while trying to find a debug object!\n");
            return res;
        }
        else if (!CUDBG_DEBUG_OBJECT_IS_VALID(debugObj)) {
            /* This can happen if no ctx creation callback has been received yet
               during early stages of the app, or during shutdown. */
            HALO_TRACE_FUNCTION(10,
                                "No debug object found, skipping resume!\n");
            *hasResumed = 1;
            /* Fake success */
            return CUDBG_SUCCESS;
        }

        if ((cuRes = CudaRmControl(haloDmalGetRmClient(debugObj), debugObj.rm,
                                   NV83DE_CTRL_CMD_DEBUG_RESUME_ALL_CONTEXTS_FOR_CLIENT,
                                   NULL, 0))) {
            if (cuRes == NV_ERR_INVALID_STATE) {
                /* This can happen if the app exits, causing its handles to be freed. */
                HALO_ERROR("RM returned cuRes = 0x%x while resuming device %d via debug object "
                           "0x%" PRIx64 ", skipping resume!\n", cuRes,
                           dev->deviceIdx, debugObj.rm);
                *hasResumed = 1;
                /* Fake success */
                return CUDBG_SUCCESS;
            }
            else {
                HALO_ERROR("Failed to resume device %d via debug object 0x%" PRIx64 ", cuRes = 0x%x.\n",
                           dev->deviceIdx, debugObj.rm, cuRes);
                return CUDBG_ERROR_UNKNOWN;
            }
        }
    }
#endif

    return res;
}

static CUDBGResult
haloDmalTranslateToRmRegOp_RM(NvU32 regOp, NvU8 *rmRegOp)
{
    switch (regOp) {
    case HALO_REG_OP_READ_32:
        *rmRegOp = NV2080_CTRL_GPU_REG_OP_READ_32;
        break;
    case HALO_REG_OP_WRITE_32:
        *rmRegOp = NV2080_CTRL_GPU_REG_OP_WRITE_32;
        break;
    case HALO_REG_OP_READ_64:
        *rmRegOp = NV2080_CTRL_GPU_REG_OP_READ_64;
        break;
    case HALO_REG_OP_WRITE_64:
        *rmRegOp = NV2080_CTRL_GPU_REG_OP_WRITE_64;
        break;
        /* Older Mac RM versions do not have these defined */
#if defined(NV2080_CTRL_GPU_REG_OP_WRITE_08) && defined(NV2080_CTRL_GPU_REG_OP_READ_08)
    case HALO_REG_OP_READ_08:
        *rmRegOp = NV2080_CTRL_GPU_REG_OP_READ_08;
        break;
    case HALO_REG_OP_WRITE_08:
        *rmRegOp = NV2080_CTRL_GPU_REG_OP_WRITE_08;
        break;
#endif
    default:
        HALO_ERROR("FATAL: Unknown regOp %u!\n", regOp);
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalTranslateToRmRegType_RM(NvU32 regType, NvU8 *rmRegType)
{
    switch (regType) {
    case HALO_REG_OP_TYPE_GLOBAL:
        *rmRegType = NV2080_CTRL_GPU_REG_OP_TYPE_GLOBAL;
        break;
    case HALO_REG_OP_TYPE_GR_CTX:
        *rmRegType = NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX;
        break;
    case HALO_REG_OP_TYPE_GR_CTX_TPC:
        *rmRegType = NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_TPC;
        break;
    case HALO_REG_OP_TYPE_GR_CTX_SM:
        *rmRegType = NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_SM;
        break;
    case HALO_REG_OP_TYPE_GR_CTX_CROP:
        *rmRegType = NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_CROP;
        break;
    case HALO_REG_OP_TYPE_GR_CTX_ZROP:
        *rmRegType = NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_ZROP;
        break;
    case HALO_REG_OP_TYPE_FB:
        *rmRegType = NV2080_CTRL_GPU_REG_OP_TYPE_FB;
        break;
        /* Older Mac RM versions do not have these defined */
#if defined(NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_QUAD)
    case HALO_REG_OP_TYPE_GR_CTX_QUAD:
        *rmRegType = NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_QUAD;
        break;
#endif
        /* Older Mac RM versions do not have these defined */
#if defined(NV2080_CTRL_GPU_REG_OP_TYPE_DEVICE)
    case HALO_REG_OP_TYPE_DEVICE:
        *rmRegType = NV2080_CTRL_GPU_REG_OP_TYPE_DEVICE;
        break;
#endif
    default:
        HALO_ERROR("FATAL: Unknown regType %u!\n", regType);
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

static void
haloDmalTranslateToHaloRegOpStatus_RM(NvU32 rmRegStatus, NvU8 *haloRegStatus)
{
    switch (rmRegStatus) {
    case NV2080_CTRL_GPU_REG_OP_STATUS_SUCCESS:
        *haloRegStatus = HALO_REG_OP_STATUS_SUCCESS;
        break;
    case NV2080_CTRL_GPU_REG_OP_STATUS_INVALID_OP:
        *haloRegStatus = HALO_REG_OP_STATUS_INVALID_OP;
        break;
    case NV2080_CTRL_GPU_REG_OP_STATUS_INVALID_TYPE:
        *haloRegStatus = HALO_REG_OP_STATUS_INVALID_TYPE;
        break;
    case NV2080_CTRL_GPU_REG_OP_STATUS_INVALID_OFFSET:
        *haloRegStatus = HALO_REG_OP_STATUS_INVALID_OFFSET;
        break;
    case NV2080_CTRL_GPU_REG_OP_STATUS_UNSUPPORTED_OP:
        *haloRegStatus = HALO_REG_OP_STATUS_UNSUPPORTED_OP;
        break;
    case NV2080_CTRL_GPU_REG_OP_STATUS_INVALID_MASK:
        *haloRegStatus = HALO_REG_OP_STATUS_INVALID_MASK;
        break;
    default:
        HALO_ERROR("Unknown rmRegStatus %u!\n", rmRegStatus);
        *haloRegStatus = HALO_REG_OP_STATUS_UNKNOWN_ERROR;
        return;
    }
}

static CUDBGResult
debugObjectExecRegOps(DebugObject debugObj, NV2080_CTRL_GPU_REG_OP *script,
                      int numOp)
{
#if defined(NV83DE_CTRL_CMD_DEBUG_EXEC_REG_OPS)
    CUDBG_VERIFY(CUDBG_DEBUG_OBJECT_IS_VALID(debugObj),
                 CUDBG_ERROR_INVALID_ARGS, "Invalid debug object\n");
    CUDBG_VERIFY(script, CUDBG_ERROR_INVALID_ARGS,
                 "PRI script pointer is not valid\n");
    CUDBG_VERIFY(numOp && numOp <= NV83DE_CTRL_GPU_EXEC_REG_OPS_MAX_OPS,
                 CUDBG_ERROR_INVALID_ARGS,
                 "Number of ops must be non-zero and less than %d\n",
                 NV83DE_CTRL_GPU_EXEC_REG_OPS_MAX_OPS);

    NvU32 status;
    NV83DE_CTRL_DEBUG_EXEC_REG_OPS_PARAMS params = {0};

    params.regOpCount = numOp;
    memcpy(params.regOps, script, sizeof(NV2080_CTRL_GPU_REG_OP) * numOp);

    status = CudaRmControl(debugObj.rmClient, debugObj.rm,
                           NV83DE_CTRL_CMD_DEBUG_EXEC_REG_OPS,
                           &params,
                           sizeof(params));
    if (status != NV_OK) {
        HALO_ERROR("Failed to exec regops (nvos res=0x%x).\n", status);
        return CUDBG_ERROR_UNKNOWN;
    }

    memcpy(script, params.regOps, sizeof(NV2080_CTRL_GPU_REG_OP) * numOp);

    return CUDBG_SUCCESS;
#else
    return CUDBG_ERROR_INCOMPATIBLE_DISPLAY_DRIVER;
#endif
}

/*
 * This function is a thin wrapper around the RmControl to read and
 * write PRI registers. It takes a "script" of register offsets and
 * commands to read or write them.
 */
static CUDBGResult
haloDmalCallRmExecRegOps_RM(CudbgDevice dev, Context context, bool useContextOp,
                            NV2080_CTRL_GPU_REG_OP *script, int numOps)
{
    NvU32 status;
    NV2080_CTRL_GPU_EXEC_REG_OPS_PARAMS params = {0};
    const CUdev* pDev;
    NvU32 hSubDevice;

    if (haloDmalDebugObjectCanExecRegOps_RM()) {
        DebugObject debugObj = {0};

        if (useContextOp) {
            debugObj = context->debugObj;
        }
        else {
            // ignoring result
            haloDmalDebugObjectGetAnyDebugObjHandle_RM(dev, &debugObj);
        }

        if (CUDBG_DEBUG_OBJECT_IS_VALID(debugObj)) {
            // return early
            return debugObjectExecRegOps(debugObj, script, numOps);
        }
        // else continue to use NV2080_CTRL_CMD_GPU_EXEC_REG_OPS as no valid debug object found

    }

    if (useContextOp) {
        CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_ARGS, "Invalid context\n");
        params.hClientTarget = context->hAppClient; /* The client that owns the targeted channel */
        params.hChannelTarget = context->hComputeChannelList[0]; /* Just pick one channel */
    }

    pDev = globals.devices[dev->deviceIdx];
    hSubDevice = deviceGetRmSubHandle(pDev);
    params.regOpCount = numOps;
    params.regOps = (NvP64)(PTR2UINT(script));

    status = CudaRmControl(globals.rmClient,
                           hSubDevice,
                           NV2080_CTRL_CMD_GPU_EXEC_REG_OPS,
                           &params, sizeof params);

    if (status != NV_OK) {
        HALO_ERROR("Failed to read registers (nvos res=%d).\n", status);
        return CUDBG_ERROR_UNKNOWN;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalExecRegOps_RM(CudbgDevice dev, Context context, HaloRegOp *script, int numOps)
{
    CUDBGResult res = CUDBG_SUCCESS;

    NV2080_CTRL_GPU_REG_OP *regOps;
    bool anyRegOpFailed = false, useContextOp = false;
    int i;

    CUDBG_VERIFY(script, CUDBG_ERROR_INVALID_ARGS, "Invalid script\n");

    regOps = (NV2080_CTRL_GPU_REG_OP *)calloc(numOps, sizeof *regOps);
    CUDBG_VERIFY(regOps, CUDBG_ERROR_UNKNOWN, "Failed to allocate regOps\n");

    for (i = 0; i < numOps; i++) {
        /* Translate the HALO defines to the corresponding RM values */
        if ((res = haloDmalTranslateToRmRegOp_RM(script[i].regOp, &regOps[i].regOp))
            != CUDBG_SUCCESS)
            goto done;

        if ((res = haloDmalTranslateToRmRegType_RM(script[i].regType, &regOps[i].regType))
            != CUDBG_SUCCESS)
            goto done;

        /* If we're issuing any ctx ops, ensure the channel/client are filled in */
        if (regOps[i].regType == NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX)
            useContextOp = true;

        /* Older Mac RM versions do not have these defined */
#if defined(NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_QUAD)
        regOps[i].regQuad         = script[i].regQuad;
#endif
        regOps[i].regGroupMask    = script[i].regGroupMask;
        regOps[i].regSubGroupMask = script[i].regSubGroupMask;
        regOps[i].regOffset       = script[i].regOffset;
        regOps[i].regValueHi      = script[i].regValueHi;
        regOps[i].regValueLo      = script[i].regValueLo;
        regOps[i].regAndNMaskHi   = script[i].regAndNMaskHi;
        regOps[i].regAndNMaskLo   = script[i].regAndNMaskLo;
    }

    /* Make the real EXEC_REG_OPS call */
    res = haloDmalCallRmExecRegOps_RM(dev, context, useContextOp, regOps, numOps);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("RM EXEC_REG_OPS failed (res=%d)\n", res);
        goto done;
    }

    /* Fill out the results for all regops */
    for (i = 0; i < numOps; i++) {
        haloDmalTranslateToHaloRegOpStatus_RM(regOps[i].regStatus, &script[i].regStatus);
        if (regOps[i].regStatus != NV2080_CTRL_GPU_REG_OP_STATUS_SUCCESS) {
            HALO_ERROR("Command %d (offset: 0x%x) failed: %d.\n",
                       i, regOps[i].regOffset, regOps[i].regStatus);
            anyRegOpFailed = true;
        }

        script[i].regValueLo = regOps[i].regValueLo;
        script[i].regValueHi = regOps[i].regValueHi;
    }

    if (anyRegOpFailed)
        res = CUDBG_ERROR_UNKNOWN;
    else
        res = CUDBG_SUCCESS;

done:
    free(regOps);
    return res;
}

static CUDBGResult
clearContextEvent_RM(Context context, void *userData)
{
#if !cuosOsIsMods()
    NvU32 rc = NV_OK;
#if cuosOsIsLinux()
    NvUnixEvent event = {0};
    uint32_t more;
    CudbgDevice dev = (CudbgDevice)userData;
    const CUdev* pDev = globals.devices[dev->deviceIdx];

    /* context has not been finalized yet, move along */
    if (context->hComputeObject == CUDBG_INVALID_HANDLE)
        return CUDBG_SUCCESS;

    /* Skip contexts on other devices */
    if (context->dev != dev)
        return CUDBG_SUCCESS;

    HALO_TRACE_FUNCTION(10, "readFd=%d\n", context->event.readFd);

    rc = CudaRmGetEventData(globals.rmClient,
                            context->event.readFd,
                            (void *)&event, &more);

    if (rc == NV_ERR_OPERATING_SYSTEM) {
        HALO_TRACE_FUNCTION(100, "Context %#" PRIx64 " didn't have an event, moving on\n", context->cuCtx);
        return CUDBG_SUCCESS;
    }

    CUDBG_VERIFY(rc == NV_OK, CUDBG_ERROR_UNKNOWN, "NvRmGetEventData() failed (%#x)\n", rc);
    
    HALO_TRACE_FUNCTION(10, "Got context(%#" PRIx64 ") event: hObject=%#x notifyIndex=%#x more=%#x\n",
                            context->cuCtx, event.hObject, event.NotifyIndex, more);
#elif cuosOsIsWindows()
    rc = cuosEventClear(&context->event);
    CUDBG_VERIFY(rc == CUOS_SUCCESS, CUDBG_ERROR_UNKNOWN, "Failed to clear event from context=%p\n, rc=%#x", context->cuCtx, rc);
#endif
#endif
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalClearEvent_RM(CudbgDevice dev, Context ctx)
{
#if !cuosOsIsMods()
    NvU32 rc = NV_OK;

    if (dev->dmal->debugObjectHasPerContextEvents()) {
        if (ctx) {   /* If a context is specified, clear *just* its event */
            HALO_TRACE_FUNCTION(10, "Clearing event for specified context 0x%" PRIx64 "\n", ctx->cuCtx);
            return clearContextEvent_RM(ctx, dev);
        }
        else {       /* Otherwise, maintain backwards compatability and clear all context events */
            HALO_TRACE_FUNCTION(10, "Clearing one event for all contexts\n");
            return haloStateTraverseContexts(clearContextEvent_RM, dev);
        }
    }
    else {
#if cuosOsIsLinux()
        NvUnixEvent event;
        uint32_t more;
        rc = CudaRmGetEventData(globals.rmClient,
                                dev->event.readFd,
                                (void *)&event, &more);
        if (rc != NV_OK) {
#ifndef RELEASE
            if (rc != NV_ERR_OPERATING_SYSTEM)
                /* NV_ERR_OPERATING_SYSTEM is harmless here */
                HALO_ERROR("NvRmGetEventData() failed (%#x)!\n", rc);
#endif
            return CUDBG_ERROR_UNKNOWN;
        }
        HALO_TRACE_FUNCTION(10, "Got device event: hObject=%#x notifyIndex=%#x more=%#x\n",
                            event.hObject, event.NotifyIndex, more);
#elif cuosOsIsWindows()
        rc = cuosEventClear(&ctx->event);
        CUDBG_VERIFY(rc == CUOS_SUCCESS, CUDBG_ERROR_UNKNOWN, "Failed to clear event from context=%p\n, rc=%#x", ctx->cuCtx, rc);
#endif
    }
#endif
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalFreeDeviceEvent_RM(CudbgDevice dev)
{
#if !cuosOsIsMods()
    CUDBGResult res = CUDBG_SUCCESS;
    NvU32 rc;
    const CUdev* pDev;
    NV2080_CTRL_EVENT_SET_NOTIFICATION_PARAMS setEventParams;
    NvU32 hDevice, hSubDevice;

    if (dev->dmal->debugObjectHasPerContextEvents())
        return CUDBG_SUCCESS;

    pDev = globals.devices[dev->deviceIdx];

    hDevice =    deviceGetRmHandle(pDev);
    hSubDevice = deviceGetRmSubHandle(pDev);

    /* Disable the event notifications for the GR_DEBUG_INTR */
    setEventParams.event = NV2080_NOTIFIERS_GR_DEBUG_INTR;
    setEventParams.action = NV2080_CTRL_EVENT_SET_NOTIFICATION_ACTION_DISABLE;
    if ((rc = CudaRmControl(globals.rmClient, hSubDevice,
                            NV2080_CTRL_CMD_EVENT_SET_NOTIFICATION,
                            &setEventParams, sizeof setEventParams))) {
        HALO_ERROR("Failed to unset the notification 0x%x (ignored).\n", rc);
    }

    if (dev->grDebugEvent &&
        (rc = CudaRmFree(globals.rmClient,
                         hSubDevice,
                         dev->grDebugEvent)))
        HALO_ERROR("Failed to free the RM event -> %d (ignored).\n", rc);

    res = haloDmalFreeOsEvent(dev, &dev->event);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to free the OS event. (ignored)\n");
        res = CUDBG_SUCCESS;
    }

    return CUDBG_SUCCESS;
#else
    HALO_ERROR("Incompatible display driver.\n");
    return CUDBG_ERROR_INCOMPATIBLE_DISPLAY_DRIVER;
#endif
}

static CUDBGResult
haloDmalAllocateDeviceEvent_RM(CudbgDevice dev, const CUdev* pDev)
{
#if !cuosOsIsMods()
    CUDBGResult res = CUDBG_SUCCESS;
    NvU32 rc = NV_OK;
    NvU32 hDevice, hSubDevice;
    NV2080_CTRL_EVENT_SET_NOTIFICATION_PARAMS setEventParams;
    void *hEvent = NULL;

    if (dev->dmal->debugObjectHasPerContextEvents())
        return CUDBG_SUCCESS;

    hSubDevice = deviceGetRmSubHandle(pDev);
    hDevice =    deviceGetRmHandle(pDev);

    /* Allocation is done in two steps: First the OS-dependent event target. */
    dev->grDebugEvent = handlePoolAlloc(globals.handlePool);

    res = haloDmalAllocOsEvent(dev, &dev->event, &hEvent);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to allocate os event object\n");
        return res;
    }

    /* Allocate the event handling binding everything together */
    rc = CudaRmAllocEvent(globals.rmClient, hSubDevice,
                          dev->grDebugEvent, NV01_EVENT_OS_EVENT,
                          NV2080_NOTIFIERS_GR_DEBUG_INTR,
                          hEvent);
    if (rc != NV_OK) {
        HALO_ERROR("Failed to allocate RM event -> 0x%x.\n", rc);
        return CUDBG_ERROR_UNKNOWN;
    }

    /* Setup a repeated event notifications for the GR_DEBUG_INTR */
    setEventParams.event = NV2080_NOTIFIERS_GR_DEBUG_INTR;
    setEventParams.action = NV2080_CTRL_EVENT_SET_NOTIFICATION_ACTION_REPEAT;
    if ((rc = CudaRmControl(globals.rmClient, hSubDevice,
                            NV2080_CTRL_CMD_EVENT_SET_NOTIFICATION,
                            &setEventParams, sizeof setEventParams))) {
        HALO_ERROR("Failed to set the notification 0x%x.\n", rc);
        return CUDBG_ERROR_UNKNOWN;
    }

    return CUDBG_SUCCESS;
#else
    HALO_ERROR("Incompatible display driver.\n");
    return CUDBG_ERROR_INCOMPATIBLE_DISPLAY_DRIVER;
#endif
}

static CUDBGResult
haloDmalSetWatchdogTimeout_RM(CudbgDevice dev, uint32_t timeout, uint32_t interval)
{
#if defined(NV2080_CTRL_CMD_OS_SET_WATCHDOG_TIMEOUT)
    NvU32 rc;
    const CUdev* pDev;
    NV2080_CTRL_OS_SET_WATCHDOG_TIMEOUT_PARAMS setTimeoutParams;
    NvU32 hDevice, hSubDevice;

    pDev = globals.devices[dev->deviceIdx];

    hDevice    = deviceGetRmHandle(pDev);
    hSubDevice = deviceGetRmSubHandle(pDev);

    /* Set RM Watchdog Timeout and Interval */
    setTimeoutParams.timeout  = timeout;
    setTimeoutParams.interval = interval;
    if ((rc = CudaRmControl(globals.rmClient, hSubDevice,
                            NV2080_CTRL_CMD_OS_SET_WATCHDOG_TIMEOUT,
                            &setTimeoutParams, sizeof setTimeoutParams))) {
        HALO_ERROR("RM Control failed to set watchdog timeout on dev %d (rc = 0x%x) .\n", dev->deviceIdx, rc);
        return CUDBG_ERROR_UNKNOWN;
    }

    return CUDBG_SUCCESS;
#else
    HALO_ERROR("Incompatible display driver.\n");
    return CUDBG_ERROR_INCOMPATIBLE_DISPLAY_DRIVER;
#endif
}

static CUDBGResult
haloDmalSetRMDebugMode_RM(CudbgDevice dev, bool on)
{
#ifdef NV2080_CTRL_CMD_GPU_SET_GPU_DEBUG_MODE
    NvU32 status;
    NV2080_CTRL_GPU_SET_GPU_DEBUG_MODE_PARAMS params;
    const CUdev* pDev = globals.devices[dev->deviceIdx];
    NvU32 hSubDevice  = deviceGetRmSubHandle(pDev);

    /* Bug 643431 - Tell RM that we are debugging. */
    params.mode = on ? NV2080_CTRL_GPU_DEBUG_MODE_ENABLED :
                  NV2080_CTRL_GPU_DEBUG_MODE_DISABLED;

    if ((status = CudaRmControl(globals.rmClient, hSubDevice,
                                NV2080_CTRL_CMD_GPU_SET_GPU_DEBUG_MODE,
                                &params, sizeof params))) {
        HALO_ERROR("Failed to set RM GPU Debug mode, res = 0x%x.\n", status);
        return CUDBG_ERROR_UNKNOWN;
    }
#endif
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalSetPowerGatingState_RM(CudbgDevice dev, HaloPowerGatingState state)
{
    const CUdev* pDev = globals.devices[dev->deviceIdx];
    NvU32 hSubDevice  = deviceGetRmSubHandle(pDev);
    NV_STATUS nvStatus = NV_OK;
    NV2080_CTRL_MC_SET_POWERGATING_PARAMETER_PARAMS perfParams = {0};
    NV2080_CTRL_POWERGATING_PARAMETER param = {0};

    memset(&perfParams, 0, sizeof(perfParams));
    memset(&param, 0, sizeof(param));

    if (state == HALO_POWER_GATING_STATE_DISABLED) {
        param.parameter = NV2080_CTRL_MC_POWERGATING_PARAMETER_ENABLED;
        param.parameterValue = 0;
        perfParams.flags = NV2080_CTRL_MC_SET_POWERGATING_PARAMETER_FLAGS_BLOCKING_FALSE;
    }
    else {
        param.parameter = NV2080_CTRL_MC_POWERGATING_PARAMETER_ENABLED;
        param.parameterValue = 1;
        perfParams.flags = NV2080_CTRL_MC_SET_POWERGATING_PARAMETER_FLAGS_BLOCKING_TRUE;
    }
    perfParams.parameterList = (NvP64)(uintptr_t)&param;
    perfParams.listSize = 1;

    nvStatus = CudaRmControl(
                   globals.rmClient,
                   hSubDevice,
                   NV2080_CTRL_CMD_MC_SET_POWERGATING_PARAMETER,
                   &perfParams,
                   sizeof(perfParams));
    if (nvStatus != NV_OK) {
        HALO_ERROR("Failed to change power gating state: 0x%x\n",nvStatus);
        return CUDBG_ERROR_UNKNOWN;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalSetChannelGroupTimeslice_RM(CudbgDevice dev, uint32_t rmChannelGroup, uint64_t usec)
{
#ifdef NVA06C_CTRL_CMD_SET_TIMESLICE
    NV_STATUS nvStatus = NV_OK;
    NVA06C_CTRL_TIMESLICE_PARAMS params;
    CUdev *pDev = globals.devices[dev->deviceIdx];

    memset(&params, 0, sizeof(params));

    params.timesliceUs = usec;

    nvStatus = CudaRmControl(globals.rmClient,
                             rmChannelGroup,
                             NVA06C_CTRL_CMD_SET_TIMESLICE,
                             &params,
                             sizeof(params));

    if (nvStatus != NV_OK) {
        HALO_ERROR("RM control to set channel group %d's timeslice failed (returned %d)\n",
                   rmChannelGroup, nvStatus);
        return CUDBG_ERROR_UNKNOWN;
    }
#endif
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalEnableOrDisableChannelGroup_RM(CudbgDevice dev, uint32_t rmChannelGroup, uint32_t hAppClient, bool bEnable)
{
#ifdef NV2080_CTRL_CMD_FIFO_DISABLE_CHANNELS
    NV_STATUS nvStatus = NV_OK;
    NV2080_CTRL_FIFO_DISABLE_CHANNELS_PARAMS params;
    CUdev *pDev = globals.devices[dev->deviceIdx];

    memset(&params, 0, sizeof(params));

    params.bDisable = bEnable ? NV_FALSE: NV_TRUE;
    params.numChannels = 1; // 1 TSG
    params.hClientList[0] = hAppClient; // The app's client handle (parent of the TSG handle)
    params.hChannelList[0] = rmChannelGroup; // The TSG handle

    /* The following option doesn't exist for this control in older branches (Mac).
       Check for the define before assigning. */
#ifdef NV2080_CTRL_FIFO_ONLY_DISABLE_SCHEDULING_TRUE
    params.bOnlyDisableScheduling = bEnable ? NV_FALSE: NV_TRUE; // Indicate whether we want a runlist submission
#endif

    HALO_TRACE_FUNCTION(1, "\t>> trying to %s channels (rm ctrl)\n", bEnable ? "enable": "disable");
    nvStatus = CudaRmControl(globals.rmClient,
                             deviceGetRmSubHandle(pDev),
                             NV2080_CTRL_CMD_FIFO_DISABLE_CHANNELS,
                             &params,
                             sizeof(params));
    HALO_TRACE_FUNCTION(1, "\t>> returned from %s channels (rm ctrl)\n", bEnable ? "enable": "disable");

    if (nvStatus != NV_OK) {
        HALO_ERROR("RM control to %s channel group %d failed (returned %d)\n",
                   bEnable ? "enable": "disable",
                   rmChannelGroup, nvStatus);
        return CUDBG_ERROR_UNKNOWN;
    }

    HALO_TRACE_FUNCTION(1, "%s channel group 0x%08x\n", bEnable ? "RESTORED": "DISABLED", rmChannelGroup);
#endif
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalPreemptChannelGroup_RM(CudbgDevice dev, uint32_t rmChannelGroup, uint32_t hAppClient, bool *preemptTimedOut,
                               uint64_t timeoutUs)
{
#ifdef NVA06C_CTRL_CMD_PREEMPT
    NV_STATUS nvStatus = NV_OK;
    CUdev *pDev = globals.devices[dev->deviceIdx];
    NVA06C_CTRL_PREEMPT_PARAMS preempt_params;

    memset(&preempt_params, 0, sizeof(preempt_params));

    /* Indicate we want to wait for the CTA-level preemption to complete (or timeout).
       Also specify a custom timout value for RM to wait on. */
    preempt_params.bWait = NV_TRUE;

#if NV_SDK_BRANCH_MAJ >= 319
    /* The following options don't exist for this control in older branches (Mac). */
    preempt_params.bManualTimeout = NV_TRUE;
    preempt_params.timeoutUs = (uint32_t)timeoutUs;
#endif

    nvStatus = CudaRmControl(hAppClient,
                             rmChannelGroup,
                             NVA06C_CTRL_CMD_PREEMPT,
                             &preempt_params,
                             sizeof(preempt_params));

    if (nvStatus != NV_OK && nvStatus != NV_ERR_TIMEOUT) {
        HALO_ERROR("RM control to preempt channel group %d failed (returned %d)\n", rmChannelGroup, nvStatus);
        return CUDBG_ERROR_UNKNOWN;
    }

    HALO_TRACE_FUNCTION(1, "SAVED channel group 0x%08x\n", rmChannelGroup);

    /* Handle when this control cleanly times out (not an error state) */
    if (nvStatus == NV_ERR_TIMEOUT) {
        /* If the RM control to preempt this channel group times out, it likely
           means we're at a breakpoint/single-step/exception, or we're dealing
           with a long running kernel / while(1) situation.  We must proceed
           with instruction-level preemption. */
        HALO_TRACE(1, "RM control to preempt channel group %d timed out (breakpoint hit?)\n", rmChannelGroup);
        *preemptTimedOut = true;
    }
#endif
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalInitGlobals_RM(HaloDmal haloDmal)
{
    CUDBGResult res = CUDBG_SUCCESS;

    haloDmal->globals.rm.initialized = true;

    return res;
}

static bool
haloDmalDebugObjectIsStable_RM(void)
{
    return !!(haloGlobals.initData.flags
              & (HALO_INIT_FLAGS_ENABLE_GLOBAL_DEBUG_OBJECT | HALO_INIT_FLAGS_ENABLE_PER_CONTEXT_DEBUG_OBJECT));
}

static bool
haloDmalDebugObjectCanSuspend_RM(void)
{
#if defined(NV83DE_CTRL_CMD_DEBUG_SUSPEND_ALL_CONTEXTS_FOR_CLIENT)
    return !!(haloGlobals.initData.flags
              & (HALO_INIT_FLAGS_ENABLE_GLOBAL_DEBUG_OBJECT | HALO_INIT_FLAGS_ENABLE_PER_CONTEXT_DEBUG_OBJECT));
#else
    return NV_FALSE;
#endif
}

static bool
haloDmalDebugObjectCanResume_RM(void)
{
#if defined(NV83DE_CTRL_CMD_DEBUG_RESUME_ALL_CONTEXTS_FOR_CLIENT)
    return !!(haloGlobals.initData.flags
              & (HALO_INIT_FLAGS_ENABLE_GLOBAL_DEBUG_OBJECT | HALO_INIT_FLAGS_ENABLE_PER_CONTEXT_DEBUG_OBJECT));
#else
    return NV_FALSE;
#endif
}

static bool
haloDmalDebugObjectCanReadESR_RM(void)
{
#if defined(NV83DE_CTRL_CMD_DEBUG_READ_SINGLE_SM_ERROR_STATE)
    return !!(haloGlobals.initData.flags & HALO_INIT_FLAGS_ENABLE_PER_CONTEXT_DEBUG_OBJECT);
#else
    return false;
#endif
}

static bool
haloDmalDebugObjectCanClearESR_RM(void)
{
#if defined(NV83DE_CTRL_CMD_DEBUG_CLEAR_SINGLE_SM_ERROR_STATE)
    return !!(haloGlobals.initData.flags & HALO_INIT_FLAGS_ENABLE_PER_CONTEXT_DEBUG_OBJECT);
#else
    return false;
#endif
}

static bool
haloDmalDebugObjectCanAccessMemory_RM(void)
{
#if defined(NV83DE_CTRL_CMD_DEBUG_READ_MEMORY)
    return !!(haloGlobals.initData.flags & HALO_INIT_FLAGS_ENABLE_DEBUG_OBJECT_MEMORY_ACCESS);
#else
    return false;
#endif
}

static bool
haloDmalDebugObjectHasPerContextEvents_RM(void)
{
#if !cuosOsIsMods() && !cuosOsIsApple()
    const uint32_t test_flags = HALO_INIT_FLAGS_ENABLE_CONTEXT_EVENTS | HALO_INIT_FLAGS_ENABLE_PER_CONTEXT_DEBUG_OBJECT;
    return (haloGlobals.initData.flags & test_flags) == test_flags;
#else
    return false;
#endif
}

static bool
haloDmalDebugObjectCanSetMMUDebugMode_RM(void)
{
    // Bug 2627515
    return false;
}

static bool
haloDmalDebugObjectCanBeAllocatedInProcess_RM(void)
{
    // Bug 2312123: Debug event subscription doesn't work for debug objects
    // allocated in a different process
    if (globals.dm.rm->rmVersion >= 418) {
        return true;
    }

    return false;
}

static bool
haloDmalDebugObjectCanSuspendResumeSingleContext_RM(void)
{
#if defined(NV83DE_CTRL_CMD_DEBUG_RESUME_CONTEXT)
    if (globals.dm.rm->rmVersion >= 400) {
        return true;
    }
#endif

    return false;
}

static NvU32
haloDmalGetRmClient(DebugObject debugObj)
{
    // In case debug object is allocated in process return clients rmclient
    return haloDmalDebugObjectCanBeAllocatedInProcess_RM() ? debugObj.rmClient :
                                                             globals.rmClient;
}

static bool
haloDmalUvmCanAccessMemory_RM(void)
{
#if cuosPlatformHasKernelModeUvm()
    return globals.useUvm8Api;
#else
    return false;
#endif
}

static bool
haloDmalDebugObjectCanExecRegOps_RM(void)
{
#if defined(NV83DE_CTRL_CMD_DEBUG_EXEC_REG_OPS)
    if (globals.dm.rm->rmVersion >= 435) {
        return true;
    }
#endif

    return false;
}

typedef struct {
    cuosEvent **eventList;
    Context *contextList;
    uint32_t idx;
    uint32_t listSize;
    CudbgDevice dev;
} EventListFunctor;

static CUDBGResult
getEventList_RM(Context context, void *userData)
{
    EventListFunctor *functor = (EventListFunctor *)userData;

    /* Make sure this context is on the correct device */
    if (functor->dev != context->dev)
        return CUDBG_SUCCESS;

    if (!haloStateContextIsActive(context))
        return CUDBG_SUCCESS;

    if (!context->enableEvents)
        return CUDBG_SUCCESS;

    /* Zero is an invalid fd for these */
    HALO_TRACE(50, "Grabbing fdlist for context %#x\n", context->cuCtx);

    if (functor->eventList) {
        CUDBG_VERIFY(functor->idx < functor->listSize, CUDBG_ERROR_INVALID_ARGS,
                     "Not enough space to store eventList\n");

        functor->eventList[functor->idx] = &context->event;
    }

    if (functor->contextList) {
        CUDBG_VERIFY(functor->idx < functor->listSize, CUDBG_ERROR_INVALID_ARGS,
                     "Not enough space to store contextList\n");

        functor->contextList[functor->idx] = context;
    }

    /* idx will keep a count of the valid fds, even if
       we don't store them in eventList */
    functor->idx++;

    return CUDBG_SUCCESS;
}


static CUDBGResult
haloDmalGetEventListForDevice_RM(CudbgDevice dev, cuosEvent **eventList, Context *contextList, int *numEvents, int listSize)
{
    CUDBGResult res;
    int numContexts;
    EventListFunctor functor = {0};

    CUDBG_VERIFY(numEvents, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    if (dev->dmal->debugObjectHasPerContextEvents()) {
        functor.eventList = NULL;
        functor.contextList = NULL;
        functor.idx = 0;
        functor.dev = dev;

        /* Traverse the list of contexts and return the number of fds we'll need. */
        res = haloStateTraverseContexts(getEventList_RM, &functor);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed when trying to find FD over all contexts\n");

        *numEvents = functor.idx;
    }
    else {
        res = haloStateNumContextsForDevice(dev, &numContexts);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get num contexts for device\n");
        *numEvents = numContexts > 0 ? 1 : 0;
    }

    /* If eventList is NULL or listSize is 0, return only the number of fds */
    if ((eventList == NULL && contextList == NULL) || listSize == 0)
        return CUDBG_SUCCESS;

    CUDBG_VERIFY(*numEvents <= listSize, CUDBG_ERROR_INVALID_ARGS,
                 "Not enough space to store fd list\n");

    if (dev->dmal->debugObjectHasPerContextEvents()) {
        functor.eventList = eventList;
        functor.contextList = contextList;
        functor.idx = 0;
        functor.listSize = listSize;
        functor.dev = dev;

        /* Traverse the list of contexts and return the first valid fd of the given type. */
        res = haloStateTraverseContexts(getEventList_RM, &functor);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed when trying to find FD over all contexts\n");
    }
    else if (eventList != NULL)   /* Just the device event fd in this case */
        *eventList = &dev->event;

    return CUDBG_SUCCESS;
}

static CUDBGResult
uvmAccessMemory(uint64_t devvaddr, void *buf, uint64_t length, HaloMemoryAccessType accessType)
{
#if cuosPlatformHasKernelModeUvm()
    NV_STATUS status = NV_OK;
    NvLength bytes_accessed = 0;
    CUDBG_VERIFY(buf && length, CUDBG_ERROR_INVALID_ARGS, "Invalid args for uvmAccessMemory\n");
    CUDBG_VERIFY(haloGlobals.uvmSession, CUDBG_ERROR_INTERNAL, "UVM not initialized yet\n");

    switch (accessType) {
    case HALO_MEMORY_ACCESS_TYPE_READ:
        HALO_TRACE_FUNCTION(50, "Reading UVM devvaddr %#" PRIx64 ":%#" PRIx64 "\n", devvaddr, length);
        status = UvmToolsReadProcessMemory(haloGlobals.uvmSession, buf, (NvLength)length, (void*)(uintptr_t)devvaddr, &bytes_accessed);
        break;
    case HALO_MEMORY_ACCESS_TYPE_WRITE:
        HALO_TRACE_FUNCTION(50, "Writing UVM devvaddr %#" PRIx64 ":%#" PRIx64 "\n", devvaddr, length);
        status = UvmToolsWriteProcessMemory(haloGlobals.uvmSession, buf, (NvLength)length, (void*)(uintptr_t)devvaddr, &bytes_accessed);
        break;
    default:
        CUDBG_ERROR("Invalid access type %d\n", accessType);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    CUDBG_VERIFY(status == NV_OK, CUDBG_ERROR_INTERNAL,
                 "Unable to access devvaddr %#" PRIx64 ":%#" PRIx64 " status=%#x\n",
                 devvaddr, length, status);

    CUDBG_VERIFY(bytes_accessed == length, CUDBG_ERROR_INTERNAL,
                 "UVM did not access all requested bytes! Requested %#" PRIx64 " got %#" PRIx64 "\n",
                 length, bytes_accessed);
#endif
    return CUDBG_SUCCESS;
}

// Auxiliary function for reading via debug object rather than bar1
static CUDBGResult
debugObjectAccessMemory(Context ctx, haloMemorySegment *seg,
                                   uint64_t devvaddr, void *buf, uint64_t length,
                                   HaloMemoryAccessType accessType)
{
    CUDBGResult res = CUDBG_SUCCESS;
#if defined(NV83DE_CTRL_CMD_DEBUG_READ_MEMORY)
    NV83DE_CTRL_DEBUG_READ_MEMORY_PARAMS readParams = {0};
    NV83DE_CTRL_DEBUG_WRITE_MEMORY_PARAMS writeParams = {0};
    void *params;
    uint32_t paramsSize;
    CUdev *pDev;
    NvU32 hDevice, rc = NV_OK;
    DebugObject debugObj;
    uint32_t cmd;
    CudbgDevice dev;
    uint32_t segHandle = 0;

    CUDBG_VERIFY(ctx && seg, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    dev = ctx->dev;
    segHandle = seg->mem;

    pDev = globals.devices[dev->deviceIdx];
    debugObj = ctx->debugObj;

    if (!CUDBG_DEBUG_OBJECT_IS_VALID(debugObj)) {
        /* This can happen if no ctx creation callback has been received yet
           during early stages of the app, or during shutdown. */
        HALO_TRACE_FUNCTION(50, "No debug object found!\n");
        return CUDBG_ERROR_INVALID_CONTEXT;
    }

    hDevice = deviceGetHandleRM(pDev);

    /* Make sure the seg has been duped */
    if (dev->haloClient->state.dupRmHandles &&
        seg->client != haloDmalGetRmClient(debugObj) && !seg->newmem) {
        seg->newmem = handlePoolAlloc(globals.handlePool);
        CUDBG_VERIFY(seg->newmem, CUDBG_ERROR_INTERNAL, "Allocating handle failed.\n");

        /* We need to dup the memory handle in order to
         * use it in the debugger's process space */
        rc = CudaRmDupObject(globals.rmClient,
                             hDevice,
                             seg->newmem,
                             seg->client,
                             seg->mem, 0);
        if (rc == NV_ERR_NOT_SUPPORTED && seg->hostvaddr) {
            /* Bug 808028:  For malloc'd pointers that are then pinned
               down by RM (via cudaHostRegister), they are given a
               handle class of NV01_MEMORY_SYSTEM_OS_DESCRIPTOR.  This
               particular type of memory cannot be dup'd/mapped in the
               standard way because RM did not originally own the
               allocation.  */
            HALO_TRACE(50, "RM cannot dup this handle (not supported). "
                       "Indicate upward to read from sysmem.\n");
            return CUDBG_ERROR_ADDRESS_NOT_IN_DEVICE_MEM;
        }
        else if (rc != NV_OK) {
            HALO_ERROR("Failed to dup memory handle (rc=%d).\n", rc);
            return CUDBG_ERROR_MEMORY_MAPPING_FAILED;
        }
    }

    if (dev->haloClient->state.dupRmHandles &&
        seg->client != haloDmalGetRmClient(debugObj)) {
        segHandle = seg->newmem;
    }

    if (accessType == HALO_MEMORY_ACCESS_TYPE_READ) {
        readParams.hMemory = segHandle;
        readParams.offset = devvaddr - seg->devvaddr;
        readParams.length = (uint32_t)length;
        readParams.buffer = (NvP64)(uintptr_t)buf;
        params = &readParams;
        paramsSize = sizeof readParams;
        cmd = NV83DE_CTRL_CMD_DEBUG_READ_MEMORY;
    }
    else {
        writeParams.hMemory = segHandle;
        writeParams.offset = devvaddr - seg->devvaddr;
        writeParams.length = (uint32_t)length;
        writeParams.buffer = (NvP64)(uintptr_t)buf;
        params = &writeParams;
        paramsSize = sizeof writeParams;
        cmd = NV83DE_CTRL_CMD_DEBUG_WRITE_MEMORY;
    }

    rc = CudaRmControl(haloDmalGetRmClient(debugObj), debugObj.rm,
                       cmd, params, paramsSize);
    if (rc == NV_ERR_NOT_SUPPORTED && seg->hostvaddr) {
        /* Bug 896577:  similar to the error check on dup above, we now
           also need to check if the mapping call returns not supported
           when dealing with malloc'd pointers that are pinned down. */
        HALO_TRACE(1, "RM cannot map from this handle (not supported). "
                   "Indicate upward to read from sysmem.\n");
        return CUDBG_ERROR_ADDRESS_NOT_IN_DEVICE_MEM;
    }
    else if (rc != NV_OK) {
        HALO_ERROR("RmCtrl %#x failed, err:%#x.\n", cmd, rc);
        return CUDBG_ERROR_MEMORY_MAPPING_FAILED;
    }
#endif
    return res;
}

static CUDBGResult
haloDmalDebugObjectAccessMemory_RM(Context ctx,
                                   uint64_t devvaddr, void *buf, uint64_t length,
                                   HaloMemoryAccessType accessType)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CudbgDevice dev;
    haloMemorySegment* seg = NULL;
    char *hostPtr = NULL;

    CUDBG_VERIFY(ctx && buf && length, CUDBG_ERROR_INVALID_ARGS, "Invalid args for AccessMemory\n");

    dev = ctx->dev;

#if defined(DEBUG)
    /* Suppress errors from valgrind */
    if (accessType == HALO_MEMORY_ACCESS_TYPE_READ)
        memset(buf, 0, (size_t)length);
#endif
    res = haloMemoryMapGetSegmentByDevVaddr(ctx->memMap, devvaddr, &seg);
    if(res != CUDBG_SUCCESS)
        return res;

    if(haloDmalUvmCanAccessMemory_RM() && (!seg || seg->type == HALO_MEM_SEG_MANAGED)) {
        /* If we either couldn't find a segment, or this segment is considered
          'managed', we access it via the uvm tools api */
        res = uvmAccessMemory(devvaddr, buf, length, accessType);
    }
    else if (dev->dmal->debugObjectCanAccessMemory()) {
        /* Try to use the debug object to access, preventing BAR1 contention */
        res = debugObjectAccessMemory(ctx, seg, devvaddr, buf, length, accessType);
    }
    else {
        /* Map memory through BAR1 and copy it to the buffer. */
        res = ctx->dev->haloClient->mapMemory(ctx, devvaddr, length, &hostPtr);

        if (res != CUDBG_SUCCESS || !hostPtr) {
            HALO_TRACE_FUNCTION(50, "Error in mapping memory in DebugObjectAccesssMemory\n");
            return res;
        }

        if (accessType == HALO_MEMORY_ACCESS_TYPE_READ)
            haloMemcpy(buf, hostPtr, (size_t)length);
        else
            haloMemcpy(hostPtr, buf, (size_t)length);
    }

    return res;
}

static CUDBGResult
haloDmalDebugObjectSetNextStopTriggerType_RM(CudbgDevice dev, DebugObject debugObj, uint32_t val)
{
#if defined(NV83DE_CTRL_CMD_DEBUG_SET_NEXT_STOP_TRIGGER_TYPE)
    NV83DE_CTRL_DEBUG_SET_NEXT_STOP_TRIGGER_TYPE_PARAMS params = {0};
    NV_STATUS res = NV_OK;
    CUdev *pDev = globals.devices[dev->deviceIdx];

    if (!(haloGlobals.initData.flags & HALO_INIT_FLAGS_ENABLE_PER_CONTEXT_DEBUG_OBJECT))
        return CUDBG_SUCCESS;

    CUDBG_VERIFY(CUDBG_DEBUG_OBJECT_IS_VALID(debugObj),
                 CUDBG_ERROR_INVALID_CONTEXT,
                 "Invalid debug object handle!\n");

    params.stopTriggerType = val;

    if ((res = CudaRmControl(haloDmalGetRmClient(debugObj), debugObj.rm,
                             NV83DE_CTRL_CMD_DEBUG_SET_NEXT_STOP_TRIGGER_TYPE,
                             &params, sizeof params))) {
        /* This may happen if the app has exited, for example */
        HALO_TRACE_FUNCTION(10, "Failed to set next stop trigger type, err:0x%x.\n",
                            res);
        return CUDBG_ERROR_UNKNOWN;
    }

#endif
    return CUDBG_SUCCESS;
}

static bool
haloDmalProfilerObjectCanClockGate_RM(void)
{
#if defined(GF100_PROFILER) && defined(NV90CC_CTRL_CMD_PROFILER_REQUEST_CG_CONTROLS)
    return true;
#else
    return false;
#endif
}

static CUDBGResult
haloDmalInitDeviceProfilerInterface_RM(CudbgDevice dev)
{
#if defined(GF100_PROFILER)
    CUresult res = CUDA_SUCCESS;
    const CUdev* pDev   = NULL;
    
    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    pDev = globals.devices[dev->deviceIdx];
    /* Since this is a global setting, we don't need out-of-process support for
       the profiler object, just use the one in our client space */
    res = pDev->dmal.deviceAllocProfilerClass(pDev, NULL, &dev->hProfilerObj, CU_PROFILER_CLASS_SCOPE_GLOBAL);
    CUDBG_VERIFY(res == CUDA_SUCCESS, CUDBG_ERROR_UNKNOWN, "Failed to allocate profiler object locally res=0x%x\n", res);
#endif

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDestroyDeviceProfilerInterface_RM(CudbgDevice dev)
{
#if defined(GF100_PROFILER)
    CUresult res = CUDA_SUCCESS;
    const CUdev* pDev   = NULL;
    
    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    pDev = globals.devices[dev->deviceIdx];
    res = pDev->dmal.deviceFreeProfilerClass(pDev, NULL, &dev->hProfilerObj);
    CUDBG_VERIFY(res == CUDA_SUCCESS, CUDBG_ERROR_UNKNOWN, "Failed to allocate profiler object locally res=0x%x\n", res);
#endif

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalProfilerObjectSetBLCG_RM(CudbgDevice dev, uint32_t on, uint32_t acquire)
{
#if defined(GF100_PROFILER)
    CUresult res = CUDA_SUCCESS;
    const CUdev* pDev   = NULL;
    uint32_t controlMask = 0, statusMask = 0, flag = 0;
    
    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    pDev = globals.devices[dev->deviceIdx];

    if (acquire) {
        if (on)
            controlMask = DRF_DEF(90CC, _CTRL_PROFILER_CG_CONTROL_MASK, _BLCG, _ENABLE);
        else
            controlMask = DRF_DEF(90CC, _CTRL_PROFILER_CG_CONTROL_MASK, _BLCG, _DISABLE);
        flag = CU_PROFILER_CLASS_CMD_RESERVE;
    }
    else {
        controlMask = DRF_DEF(90CC, _CTRL_PROFILER_CG_CONTROL_MASK, _BLCG, _RELEASE);
        flag = CU_PROFILER_CLASS_CMD_RELEASE;
    }

    res = pDev->dmal.deviceClockGateProfilerClass(pDev, NULL, dev->hProfilerObj, controlMask, &statusMask, flag);
    CUDBG_VERIFY(res == CUDA_SUCCESS, CUDBG_ERROR_UNKNOWN, "Failed to change clock gating settings res=0x%x\n", res);
#endif

    return CUDBG_SUCCESS;
}



static void
haloDmalInitInterfaces_RM(HaloDmal haloDmal)
{
    haloDmal->initPrivAccess            = haloDmalInitPrivAccess_RM;
    haloDmal->finalizePrivAccess        = haloDmalFinalizePrivAccess_RM;
    haloDmal->readReg32                 = haloDmalReadReg32_RM;
    haloDmal->readReg64                 = haloDmalReadReg64_RM;
    haloDmal->writeReg32                = haloDmalWriteReg32_RM;
    haloDmal->writeReg64                = haloDmalWriteReg64_RM;
    haloDmal->execRegOps                = haloDmalExecRegOps_RM;

    haloDmal->mapMemory                 = haloDmalMapMemory_RM;
    haloDmal->unmapMemory               = haloDmalUnmapMemory_RM;
    haloDmal->readBar1Size              = haloDmalReadBar1Size_RM;
    haloDmal->mapOneMemorySegment       = haloDmalMapOneMemorySegment_RM;
    haloDmal->unmapOneMemorySegment     = haloDmalUnmapOneMemorySegment_RM;

    haloDmal->debugObjectAllocEvent                    = haloDmalDebugObjectAllocEvent_RM;
    haloDmal->debugObjectFreeEvent                     = haloDmalDebugObjectFreeEvent_RM;
    haloDmal->debugObjectAlloc                         = haloDmalDebugObjectAlloc_RM;
    haloDmal->debugObjectFree                          = haloDmalDebugObjectFree_RM;
    haloDmal->debugObjectPauseGrCtxSwitch              = haloDmalDebugObjectPauseGrCtxSwitch_RM;
    haloDmal->debugObjectResumeGrCtxSwitch             = haloDmalDebugObjectResumeGrCtxSwitch_RM;
    haloDmal->debugObjectClearSMESRInfo                = haloDmalDebugObjectClearSMESRInfo_RM;
    haloDmal->debugObjectReadSMESRInfo                 = haloDmalDebugObjectReadSMESRInfo_RM;
    haloDmal->debugObjectSetMMUDebugMode               = haloDmalDebugObjectSetMMUDebugMode_RM;
    haloDmal->debugObjectSuspendContext                = haloDmalDebugObjectSuspendContext_RM;
    haloDmal->debugObjectSuspendDevice                 = haloDmalDebugObjectSuspendDevice_RM;
    haloDmal->debugObjectResumeContext                 = haloDmalDebugObjectResumeContext_RM;
    haloDmal->debugObjectResumeDevice                  = haloDmalDebugObjectResumeDevice_RM;
    haloDmal->debugObjectGetResidentChannelHandle      = haloDmalDebugObjectGetResidentChannelHandle_RM;
    haloDmal->debugObjectAccessMemory                  = haloDmalDebugObjectAccessMemory_RM;

    haloDmal->debugObjectIsStable                      = haloDmalDebugObjectIsStable_RM;
    haloDmal->debugObjectCanSuspend                    = haloDmalDebugObjectCanSuspend_RM;
    haloDmal->debugObjectCanResume                     = haloDmalDebugObjectCanResume_RM;
    haloDmal->debugObjectCanReadESR                    = haloDmalDebugObjectCanReadESR_RM;
    haloDmal->debugObjectCanClearESR                   = haloDmalDebugObjectCanClearESR_RM;
    haloDmal->debugObjectCanAccessMemory               = haloDmalDebugObjectCanAccessMemory_RM;
    haloDmal->debugObjectCanSetMMUDebugMode            = haloDmalDebugObjectCanSetMMUDebugMode_RM;
    haloDmal->debugObjectHasPerContextEvents           = haloDmalDebugObjectHasPerContextEvents_RM;
    haloDmal->debugObjectCanBeAllocatedInProcess       = haloDmalDebugObjectCanBeAllocatedInProcess_RM;

    haloDmal->initDeviceProfilerInterface = haloDmalInitDeviceProfilerInterface_RM;
    haloDmal->destroyDeviceProfilerInterface = haloDmalDestroyDeviceProfilerInterface_RM;

    haloDmal->profilerObjectSetBLCG = haloDmalProfilerObjectSetBLCG_RM;
    haloDmal->profilerObjectCanClockGate = haloDmalProfilerObjectCanClockGate_RM;

    haloDmal->clearEvent          = haloDmalClearEvent_RM;
    haloDmal->freeDeviceEvent     = haloDmalFreeDeviceEvent_RM;
    haloDmal->allocateDeviceEvent = haloDmalAllocateDeviceEvent_RM;
    haloDmal->setWatchdogTimeout  = haloDmalSetWatchdogTimeout_RM;
    haloDmal->getEventListForDevice  = haloDmalGetEventListForDevice_RM;

    haloDmal->setRMDebugMode              = haloDmalSetRMDebugMode_RM;
    haloDmal->setPowerGatingState         = haloDmalSetPowerGatingState_RM;
    haloDmal->setChannelGroupTimeslice    = haloDmalSetChannelGroupTimeslice_RM;
    haloDmal->enableOrDisableChannelGroup = haloDmalEnableOrDisableChannelGroup_RM;
    haloDmal->preemptChannelGroup         = haloDmalPreemptChannelGroup_RM;

    haloDmal->debugObjectSetNextStopTriggerType      = haloDmalDebugObjectSetNextStopTriggerType_RM;
}

CUDBGResult
haloDmalInit_RM(HaloDmal haloDmal)
{
    CUDBGResult res = CUDBG_SUCCESS;

    haloDmal->type = HALO_DMAL_TYPE_RM;

    haloDmalInitGlobals_RM(haloDmal);

    haloDmalInitInterfaces_RM(haloDmal);

    return res;
}

