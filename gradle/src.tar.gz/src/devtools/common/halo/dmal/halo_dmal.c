/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: halo_dmal.c
 *
 *   Description:
 *       Halo DMAL initialization
 *
 ******************************************************************************/

#include "halo.h"
#include "halo_dmal.h"
#include "halo_internal.h"
#if cuiPlatformIncludesWddm()
#include "halo_dmal_wddm.h"
#include "halo_dmal_wddm_legacy.h"
#endif
#include "halo_dmal_mrm.h"
#include "halo_dmal_rm.h"

static uint32_t haloDmalInitialized = 0;

#define TRACE_EMPTY_STUB() \
    { HALO_TRACE_FUNCTION(20, "Empty DMAL stub was called\n"); }

static CUDBGResult mapMemory_STUB (Context context, haloMemoryMap *map, uint64_t va, uint64_t size, char **hostPtr)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult unmapMemory_STUB (CudbgDevice dev)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult initPrivAccess_STUB (CudbgDevice dev)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult finalizePrivAccess_STUB (CudbgDevice dev)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
readReg32_STUB(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint32_t* value)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
readReg64_STUB(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint64_t* value)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
writeReg32_STUB(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint32_t* value)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
writeReg64_STUB(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint64_t* value)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
getHostAddrFromDevicePtr_STUB(Context context, uint64_t devptr, uint64_t *hva)
{
    haloMemorySegment *seg = NULL;
    uint64_t offset = 0;
    CUDBGResult res = CUDBG_SUCCESS;
    uint64_t dva;

    CUDBG_VERIFY(context && hva, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");
    CUDBG_VERIFY(context->memMapActive, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context\n");

    res = haloMemoryMapTranslateToDevVaddr(context->memMap, HALO_MEM_SEG_GLOBAL, devptr, &dva);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to find vaddr for devptr 0x%" PRIx64 "\n", devptr);

    res = haloMemoryMapGetSegmentByDevVaddr(context->memMap, dva, &seg);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Error trying to get segment at devVA 0x%" PRIx64 "\n", dva);

    CUDBG_VERIFY(seg, CUDBG_ERROR_INVALID_MEMORY_SEGMENT,
                 "Failed to find segment at devVA 0x%" PRIx64 "\n", dva);

    offset = devptr - seg->devptr;
    *hva = seg->hostvaddr + offset;

    return CUDBG_SUCCESS;
}

static CUDBGResult
debugObjectAllocEvent_STUB(CudbgDevice dev, DebugObject debugObj, uint32_t eventClassType, cuosEvent *eventfd, uint32_t *hDebugEvent)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
debugObjectFreeEvent_STUB(CudbgDevice dev, DebugObject debugObj, cuosEvent* eventfd, uint32_t hDebugEvent)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
debugObjectAlloc_STUB(Context ctx, uint32_t hAppClient,
                      uint32_t hComputeObject, DebugObject *debugObj)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
debugObjectFree_STUB(Context ctx, DebugObject *debugObj, uint32_t *hComputeObject)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
debugObjectPauseGrCtxSwitch_STUB(CudbgDevice dev)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
debugObjectResumeGrCtxSwitch_STUB(CudbgDevice dev)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
debugObjectGetResidentChannelHandle_STUB(CudbgDevice dev, DebugObject debugObj,
                                         uint32_t *hChannel)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
debugObjectGetResidentChannelHandleSafe_STUB(CudbgDevice dev, DebugObject debugObj,
                                             uint32_t *hChannel)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
debugObjectAnyDbgCtxResident_STUB(CudbgDevice dev, bool *bResident)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
debugObjectSuspendContext_STUB(Context ctx, bool *waitForEvent)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
debugObjectSuspendDevice_STUB(CudbgDevice dev, uint32_t *hasStopped, uint32_t *waitForEvent, Context *residentContext)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
debugObjectResumeContext_STUB(Context ctx)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
debugObjectResumeDevice_STUB(CudbgDevice dev, uint32_t *hasResumed)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
debugObjectReadSMESRInfo_STUB(CudbgDevice dev, DebugObject debugObj, uint32_t vsm,
                              CudbgSMESRState_t *esrState)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
debugObjectClearSMESRInfo_STUB(CudbgDevice dev, DebugObject debugObj, uint32_t vsm,
                               CudbgSMESRState_t *esrState)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
debugObjectSetMMUDebugMode_STUB(Context ctx, bool on)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
debugObjectGetVARanges_STUB(Context ctx, uint64_t startVA, uint64_t endVA, HaloVARangeInfo ranges[], uint32_t length, uint32_t *numRanges)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
debugObjectAccessMemory_STUB(Context ctx, uint64_t devvaddr,
                             void *buf, uint64_t length, HaloMemoryAccessType accessType)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
debugObjectSetNextStopTriggerType_STUB(CudbgDevice dev, DebugObject debugObj, uint32_t val)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static bool
debugObjectHasPerContextEvents_STUB(void)
{
    return false;
}

static bool
debugObjectHasPerContextSuspendResume_STUB(void)
{
    return false;
}

static bool
debugObjectCanBeAllocatedInProcess_STUB(void)
{
    return false;
}

static CUDBGResult
execRegOps_STUB(CudbgDevice dev, Context context, HaloRegOp *script, int numOps)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
clearEvent_STUB(CudbgDevice dev, Context ctx)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
freeDeviceEvent_STUB(CudbgDevice dev)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
allocateDeviceEvent_STUB(CudbgDevice dev, const CUdev* pDev)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
setWatchdogTimeout_STUB(CudbgDevice dev, uint32_t timeout, uint32_t interval)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
setGlobalChannelTimeout_STUB(DebugObject debugObj, bool enable)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
setRMDebugMode_STUB(CudbgDevice dev, bool on)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
setPowerGatingState_STUB(CudbgDevice dev, HaloPowerGatingState state)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
setChannelGroupTimeslice_STUB(CudbgDevice dev, uint32_t rmChannelGroup, uint64_t usec)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
enableOrDisableChannelGroup_STUB(CudbgDevice dev, uint32_t rmChannelGroup, uint32_t hAppClient, bool bEnable)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
preemptChannelGroup_STUB(CudbgDevice dev, uint32_t rmChannelGroup, uint32_t hAppClient, bool *preemptTimedOut,
                         uint64_t timeoutUs)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
unmapOneMemorySegment_STUB(CudbgDevice dev, haloMemorySegment *seg)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
mapOneMemorySegment_STUB(haloMemoryMap *map, haloMemorySegment *seg, uint64_t offset, uint64_t size)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
readBar1Size_STUB(CudbgDevice dev, uint64_t *bar1Size)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static bool
debugObjectIsStable_STUB(void)
{
    return false;
}

static bool
debugObjectCanSuspend_STUB(void)
{
    return false;
}

static bool
debugObjectCanResume_STUB(void)
{
    return false;
}

static bool
debugObjectCanReadESR_STUB(void)
{
    return false;
}

static bool
debugObjectCanClearESR_STUB(void)
{
    return false;
}

static bool
debugObjectCanGetVARanges_STUB(void)
{
    return false;
}

static bool
debugObjectCanAccessMemory_STUB(void)
{
    return false;
}

static bool
debugObjectCanSetMMUDebugMode_STUB(void)
{
    return false;
}

static CUDBGResult
debugObjectSetupInitFlags_STUB(void)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
initDeviceDebugInterface_STUB(CudbgDevice dev)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
destroyDeviceDebugInterface_STUB(CudbgDevice dev)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
initDeviceProfilerInterface_STUB(CudbgDevice dev)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
destroyDeviceProfilerInterface_STUB(CudbgDevice dev)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
profilerObjectSetBLCG_STUB(CudbgDevice dev, uint32_t on, uint32_t acquire)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static bool
profilerObjectCanClockGate_STUB(void)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
getFdListForDevice_STUB(CudbgDevice dev, int *fdList, Context *contextList, int *numFds, int listSize)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
getEventListForDevice_STUB(CudbgDevice dev, cuosEvent **eventList, Context *contextList, int *numEvents, int listSize)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
forceCacheCoherence_STUB(CudbgDevice dev)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
destroyHandleForMemorySegment_STUB(CudbgDevice dev, uint32_t handle)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
createHandleForMemorySegment_STUB(CudbgDevice dev, int32_t parentFd, uint32_t *newHandle)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static CUDBGResult
readServiceRoutineData_STUB(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln, uint64_t offset, void *buf, uint32_t bufSz)
{
    return dev->halo.readLocalMemory(dev, vsm, wp, ln, offset, buf, bufSz);
}

static CUDBGResult
flushCpuMappingForDevvaddr_STUB(Context ctx, uint64_t devvaddr, uint64_t size, HaloCacheFlushOp op)
{
    // This stub can be called on some platforms where there's no need for flushing the CPU cache
    return CUDBG_SUCCESS;
}

/* GPU L2 is flushed through a platform-specific ioctl */
static CUDBGResult
flushGpuWrites_STUB(CudbgDevice dev)
{
    TRACE_EMPTY_STUB();
    return CUDBG_SUCCESS;
}

static void
haloDmalInitCommon(HaloDmal haloDmal)
{
    haloDmal->initPrivAccess = initPrivAccess_STUB;
    haloDmal->finalizePrivAccess = finalizePrivAccess_STUB;
    haloDmal->readReg32  = readReg32_STUB;
    haloDmal->readReg64  = readReg64_STUB;
    haloDmal->writeReg32 = writeReg32_STUB;
    haloDmal->writeReg64 = writeReg64_STUB;
    haloDmal->execRegOps = execRegOps_STUB;

    haloDmal->mapMemory = mapMemory_STUB;
    haloDmal->unmapMemory = unmapMemory_STUB;
    haloDmal->getHostAddrFromDevicePtr   = getHostAddrFromDevicePtr_STUB;
    haloDmal->mapOneMemorySegment       = mapOneMemorySegment_STUB;
    haloDmal->unmapOneMemorySegment     = unmapOneMemorySegment_STUB;
    haloDmal->destroyHandleForMemorySegment = destroyHandleForMemorySegment_STUB;
    haloDmal->createHandleForMemorySegment = createHandleForMemorySegment_STUB;
    haloDmal->readServiceRoutineData = readServiceRoutineData_STUB;

    haloDmal->clearEvent          = clearEvent_STUB;
    haloDmal->freeDeviceEvent     = freeDeviceEvent_STUB;
    haloDmal->allocateDeviceEvent = allocateDeviceEvent_STUB;
    haloDmal->setWatchdogTimeout  = setWatchdogTimeout_STUB;
    haloDmal->getEventListForDevice  = getEventListForDevice_STUB;
    haloDmal->forceCacheCoherence = forceCacheCoherence_STUB;
    haloDmal->setGlobalChannelTimeout = setGlobalChannelTimeout_STUB;

    haloDmal->setRMDebugMode  = setRMDebugMode_STUB;
    haloDmal->setPowerGatingState = setPowerGatingState_STUB;
    haloDmal->setChannelGroupTimeslice = setChannelGroupTimeslice_STUB;
    haloDmal->enableOrDisableChannelGroup = enableOrDisableChannelGroup_STUB;
    haloDmal->preemptChannelGroup = preemptChannelGroup_STUB;

    haloDmal->debugObjectAllocEvent                    = debugObjectAllocEvent_STUB;
    haloDmal->debugObjectFreeEvent                     = debugObjectFreeEvent_STUB;
    haloDmal->debugObjectAlloc                         = debugObjectAlloc_STUB;
    haloDmal->debugObjectFree                          = debugObjectFree_STUB;
    haloDmal->debugObjectPauseGrCtxSwitch              = debugObjectPauseGrCtxSwitch_STUB;
    haloDmal->debugObjectResumeGrCtxSwitch             = debugObjectResumeGrCtxSwitch_STUB;
    haloDmal->debugObjectClearSMESRInfo                = debugObjectClearSMESRInfo_STUB;
    haloDmal->debugObjectReadSMESRInfo                 = debugObjectReadSMESRInfo_STUB;
    haloDmal->debugObjectSetMMUDebugMode               = debugObjectSetMMUDebugMode_STUB;
    haloDmal->debugObjectSuspendContext                = debugObjectSuspendContext_STUB;
    haloDmal->debugObjectSuspendDevice                 = debugObjectSuspendDevice_STUB;
    haloDmal->debugObjectResumeContext                 = debugObjectResumeContext_STUB;
    haloDmal->debugObjectResumeDevice                  = debugObjectResumeDevice_STUB;
    haloDmal->debugObjectGetResidentChannelHandle      = debugObjectGetResidentChannelHandle_STUB;
    haloDmal->debugObjectGetVARanges                   = debugObjectGetVARanges_STUB;
    haloDmal->debugObjectAccessMemory                  = debugObjectAccessMemory_STUB;
    haloDmal->debugObjectSetNextStopTriggerType        = debugObjectSetNextStopTriggerType_STUB;
    haloDmal->debugObjectHasPerContextEvents           = debugObjectHasPerContextEvents_STUB;
    haloDmal->debugObjectHasPerContextSuspendResume    = debugObjectHasPerContextSuspendResume_STUB;

    haloDmal->debugObjectIsStable                      = debugObjectIsStable_STUB;
    haloDmal->debugObjectCanSuspend                    = debugObjectCanSuspend_STUB;
    haloDmal->debugObjectCanResume                     = debugObjectCanResume_STUB;
    haloDmal->debugObjectCanReadESR                    = debugObjectCanReadESR_STUB;
    haloDmal->debugObjectCanClearESR                   = debugObjectCanClearESR_STUB;
    haloDmal->debugObjectCanGetVARanges                = debugObjectCanGetVARanges_STUB;
    haloDmal->debugObjectCanAccessMemory               = debugObjectCanAccessMemory_STUB;
    haloDmal->debugObjectCanSetMMUDebugMode            = debugObjectCanSetMMUDebugMode_STUB;
    haloDmal->initDeviceDebugInterface                 = initDeviceDebugInterface_STUB;
    haloDmal->destroyDeviceDebugInterface              = destroyDeviceDebugInterface_STUB;

    haloDmal->initDeviceProfilerInterface                 = initDeviceProfilerInterface_STUB;
    haloDmal->destroyDeviceProfilerInterface              = destroyDeviceProfilerInterface_STUB;

    haloDmal->readBar1Size = readBar1Size_STUB;

    haloDmal->flushCpuMappingForDevvaddr = flushCpuMappingForDevvaddr_STUB;
    haloDmal->flushGpuWrites = flushGpuWrites_STUB;
}

static CUDBGResult
haloDmalInitDmalOfType(HaloDmal haloDmal, HaloDmalType_t type)
{
    CUDBGResult res = CUDBG_SUCCESS;

    HALO_TRACE(5, "Trying to initialize halo DMAL type: %d\n", type);

    switch (type) {
    case HALO_DMAL_TYPE_MRM:
        /* Android */
        res = haloDmalInit_MRM(haloDmal);
        break;
    case HALO_DMAL_TYPE_WDDM_LEGACY:
#if cuiPlatformIncludesWddm()
        /* WDDM and WDM modes on WinLH */
        res = haloDmalInit_WDDM_Legacy(haloDmal);
#endif
        break;
    case HALO_DMAL_TYPE_WDDM:
#if cuiPlatformIncludesWddm()
        /* WDDM2 mode on WinLH */
        res = haloDmalInit_WDDM(haloDmal);
#endif
        break;
#if !cuosOsIsHos()
    case HALO_DMAL_TYPE_RM:
#if cuosOsIsQnx()
        /* QNX */
        HALO_TRACE(5, "Initializing RM DMAL to stubs on QNX!\n");
        res = CUDBG_SUCCESS;
#elif cuiPlatformIncludesRm()
        /* Linux and Mac */
        res = haloDmalInit_RM(haloDmal);
#endif
        break;
#endif
    default:
        HALO_ERROR("DMAL type %d is not supported on this platform!\n", type);
        res = CUDBG_ERROR_INVALID_ARGS;
    }

    return res;
}

/* Initialize all DMALs supported on the current platform */
CUDBGResult
haloDmalsInit(void)
{
    HaloDmal haloDmal;
    CUDBGResult res = CUDBG_SUCCESS;
    int type;

    if (haloDmalInitialized)
        /* Already initialized */
        return res;

    for (type = 0; type < HALO_DMAL_COUNT; type++) {
        haloDmal = (HaloDmal)calloc(1, sizeof *haloDmal);
        if (haloDmal == NULL)
            return CUDBG_ERROR_UNKNOWN;

        /* Initialize all function pointers to stubs */
        haloDmalInitCommon(haloDmal);

        res = haloDmalInitDmalOfType(haloDmal, (HaloDmalType_t)type);
        if (res != CUDBG_SUCCESS)
            return res;

        haloGlobals.haloDmal[type] = haloDmal;
    }

    haloDmalInitialized = 1;

    return res;
}

CUDBGResult
haloDmalsFinalize(void)
{
    int type;

    if (haloDmalInitialized) {
        for (type = 0; type < HALO_DMAL_COUNT; type++) {
            free(haloGlobals.haloDmal[type]);
            haloGlobals.haloDmal[type] = NULL;
        }

        haloDmalInitialized = 0;
    }

    return CUDBG_SUCCESS;
}

