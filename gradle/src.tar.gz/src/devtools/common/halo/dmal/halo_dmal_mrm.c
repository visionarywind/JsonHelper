/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */


/******************************************************************************
 *
 *   Module: halo_dmal_mrm.c
 *
 *   Description:
 *       Halo MRM DMAL initialization
 *
 ******************************************************************************/
#include "halo.h"
#include "halo_client.h"
#include "halo_dmal_mrm.h"
#include "halo_dmal_rm.h"
#include "halo_internal.h"
#include "halo_state.h"
#include "kdapi.h"

#if cuosPlatformIncludesMrm() && (cuosOsIsAndroid() || cuosOsIsLinux() || cuosOsIsQnx())
#include "mrm_device.h"
#include "nvgpu.h"
#include "nvrm_memmgr.h"

#include <sys/mman.h>
#endif

#if cuosOsIsQnx()
#include <sys/neutrino.h>
#endif

#if cuosPlatformIncludesMrm() && (cuosOsIsAndroid() || cuosOsIsLinux() || cuosOsIsQnx())
/* Used for finding a channel fd on a device */
typedef struct {
    CudbgDevice dev;
    CUDBGFdTypes type;
    int32_t fd;
} FindFdFunctor;

CUDBGResult haloDmalFindFdOfType(CudbgDevice dev, int32_t *fd, CUDBGFdTypes type);

/* Warning: this can only be used to call ioctls that take all arguments by value.
 * If your ioctl expects a pointer to a buffer, QNX has to know about it.
 * When in doubt, look up the definition of the ioctl argument struct.
 * If it contains anything that looks like a pointer, you need to use devctlv
 * and SETIOV, or the driver will read garbage, or you won't get results back.
 * To learn more, google for "QNX devctlv".
 */
static int32_t haloIoctl(int32_t fd, int32_t cmd, void *args, size_t sizeofArgs)
{
    int32_t iocResult = 0;
#if cuosOsIsQnx()
    iocResult = devctl(fd, cmd, args, sizeofArgs, NULL);
    /* On error, ioctl and devctl do different things:
     *   ioctl sets errno and returns -1
     *  devctl returns the error code directly
     * Make devctl look like ioctl. This pattern is inlined in several places
     * in this file, because devctlv is hard to wrap in a function or a macro.
     */
    if (iocResult != EOK) {
        errno = iocResult;
        iocResult = -1;
    }
#else
    iocResult = ioctl(fd, cmd, args);
#endif /* cuosOsIsQnx() */
    return iocResult;
}

#if cuosOsIsQnx()
static CUDBGResult
qnxMemGetImportId(NvRmMemHandle nvrmHandle, int nvgpuFd, uint32_t *pImportId)
{
    struct _server_info serverInfo = {0};
    NvRmMemChInfo chInfo = {0};
    NvError err = NvSuccess;
    int ret = 0;

    CUDBG_VERIFY(nvrmHandle && pImportId && nvgpuFd > 0, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    /* This could be done once per nvgpuFd and reused, but ConnectServerInfo_r is 20x faster than NvRmMemGetImportId */
    ret = ConnectServerInfo_r(0, nvgpuFd, &serverInfo);
    CUDBG_VERIFY(ret >= 0, CUDBG_ERROR_INTERNAL, "ConnectServerInfo_r failed (%s) for nvgpuFd=%d\n", strerror(errno), nvgpuFd);

    chInfo.ChId   = serverInfo.chid;
    chInfo.pid    = serverInfo.pid;
    chInfo.NodeId = serverInfo.nd;

    /* This cannot be reused: every ioctl requires a new import ID */
    err = NvRmMemGetImportId(nvrmHandle, &chInfo, NVOS_MEM_READ_WRITE, pImportId);
    CUDBG_VERIFY(err == NvSuccess, CUDBG_ERROR_INTERNAL, "NvRmMemGetImportId failed (NvError %d) for handle %u\n", err, (uint32_t)nvrmHandle);

    return CUDBG_SUCCESS;
}
#endif

static CUDBGResult
debugSessionAccessMemory(Context ctx, haloMemorySegment* seg,
                            uint64_t devvaddr, void *buf, uint64_t length,
                            HaloMemoryAccessType accessType)
{
    CUDBGResult res = CUDBG_SUCCESS;
#if defined(NVGPU_DBG_GPU_IOCTL_ACCESS_FB_MEMORY)
    struct nvgpu_dbg_gpu_access_fb_memory_args args = {0};
    int32_t iocResult;
    int32_t nvgpudbgfd = ctx->debugObj.mrm;
    void *accessBuf = buf;
    uint64_t accessDevvaddr = devvaddr;
    uint64_t accessLength = length;
#if cuosOsIsQnx()
    uint32_t importId = 0;
    iov_t sv[2];
    iov_t rv[2];
#endif

    CUDBG_VERIFY(nvgpudbgfd > 0 && ctx && seg, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    /* Bug 2285052
     * In nvgpu the unaligned FB memory access are not supported.
     * Allocate a larger buffer extended to the nearest 4-byte on both
     * sides, and read back before writing. */
    if ((devvaddr & 3) || (length & 3)) {
        accessDevvaddr = devvaddr & ~3;
        accessLength = ((devvaddr & 3) + length + 3) & ~3;
        accessBuf = malloc(accessLength);

        if (!accessBuf) {
            HALO_ERROR("Unaligned access buffer allocation failed, "
                    "error: %s\n", strerror(errno));
            return CUDBG_ERROR_OS_RESOURCES;
        }

        if (accessType == HALO_MEMORY_ACCESS_TYPE_WRITE) {
            res = debugSessionAccessMemory(ctx, seg, accessDevvaddr, accessBuf,
                    accessLength, HALO_MEMORY_ACCESS_TYPE_READ);

            if (res != CUDBG_SUCCESS) {
                HALO_ERROR("ioctl NVGPU_DBG_GPU_IOCTL_ACCESS_FB_MEMORY "
                        "failed while pre-reading unaligned writing access");

                free(accessBuf);
                return res;
            }

            memcpy((char*)accessBuf + (devvaddr & 3), buf, length);
        }
    }

#if cuosOsIsQnx()
    res = qnxMemGetImportId((NvRmMemHandle)seg->mem, nvgpudbgfd, &importId);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to convert an NvRmMemHandle to an import id\n");
    args.dmabuf_import_id = importId;
#else
    args.dmabuf_fd = seg->mem;
#endif
    args.offset = accessDevvaddr - seg->devvaddr;
    args.buffer = (uint64_t)((uintptr_t)accessBuf);
    args.size = accessLength;

    if (accessType == HALO_MEMORY_ACCESS_TYPE_READ)
        args.cmd = NVGPU_DBG_GPU_IOCTL_ACCESS_FB_MEMORY_CMD_READ;
    else
        args.cmd = NVGPU_DBG_GPU_IOCTL_ACCESS_FB_MEMORY_CMD_WRITE;

#if cuosOsIsQnx()
    SETIOV(&sv[0], &args, sizeof(args));
    SETIOV(&rv[0], &args, sizeof(args));
    SETIOV(&sv[1], accessBuf, accessLength);
    SETIOV(&rv[1], accessBuf, accessLength);

    iocResult = devctlv(nvgpudbgfd,
                        (int32_t)NVGPU_DBG_GPU_IOCTL_ACCESS_FB_MEMORY,
                        sizeof(sv) / sizeof(sv[0]),  /* int sparts         */
                        sizeof(rv) / sizeof(rv[0]),  /* int rparts         */
                        sv,                          /* const iov_t *sv    */
                        rv,                          /* const iov_t *rv    */
                        NULL);                       /* int *dev_info_ptr  */
    if (iocResult != EOK) {
        errno = iocResult;
        iocResult = -1;
    }
#else
    iocResult = ioctl(nvgpudbgfd, (int32_t)NVGPU_DBG_GPU_IOCTL_ACCESS_FB_MEMORY, &args);
#endif

    if (accessBuf != buf) {
        if (accessType == HALO_MEMORY_ACCESS_TYPE_READ) {
            memcpy(buf, (char*)accessBuf + (devvaddr & 3), length);
        }

        free(accessBuf);
    }

    if (iocResult) {
        HALO_ERROR("ioctl NVGPU_DBG_GPU_IOCTL_ACCESS_FB_MEMORY failed, "
                   "error: %s\n", strerror(errno));
        res = CUDBG_ERROR_INTERNAL;
        goto done;
    }
done:
#else  /* !defined(NVGPU_DBG_GPU_IOCTL_ACCESS_FB_MEMORY) */
    HALO_ERROR("UNSUPPORTED: vidmem access on mobile not yet supported\n");
    res = CUDBG_ERROR_MEMORY_MAPPING_FAILED;
#endif
    return res;
}

static CUDBGResult
nvmapAccessMemory(Context ctx, haloMemorySegment* seg, uint64_t devvaddr, void* buf, uint64_t length, HaloMemoryAccessType accessType)
{
    NvError res = NvSuccess;
    uint64_t offset = 0;

    CUDBG_VERIFY(ctx && ctx->debugObj.mrm > 0 && seg, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    offset = devvaddr - seg->devvaddr;

    /* On Linux, this will cause a copy_to_user for each element, which can be expensive.
       We need to talk to the nvmap guys about optimizing this better. */
    if (accessType == HALO_MEMORY_ACCESS_TYPE_READ)
        res = NvRmMemRead((NvRmMemHandle)seg->mem, offset, buf, length);
    else
        res = NvRmMemWrite((NvRmMemHandle)seg->mem, offset, buf, length);

    if (res != NvSuccess) {
        HALO_ERROR(("Flushing CPU cache failed\n"));
        return CUDBG_ERROR_INTERNAL;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectAccessMemory_MRM(Context ctx,
                                     uint64_t devvaddr, void *buf, uint64_t length,
                                     HaloMemoryAccessType accessType)
{
    CUDBGResult res = CUDBG_SUCCESS;
    haloMemorySegment* seg = NULL;

    CUDBG_VERIFY(ctx && buf && length, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    res = haloMemoryMapGetSegmentByDevVaddr(ctx->memMap, devvaddr, &seg);
    CUDBG_VERIFY(res == CUDBG_SUCCESS && seg, res, "Failed to find segment, res=%d\n", res);

    /* TODO: Extend to support UVM vidmem eventually */
    if (seg->usesNvmap)
        res = nvmapAccessMemory(ctx, seg, devvaddr, buf, length, accessType);
    else
        res = debugSessionAccessMemory(ctx, seg, devvaddr, buf, length, accessType);

    return res;
}

static CUDBGResult
haloDmalUnmapOneMemorySegment_MRM(CudbgDevice dev, haloMemorySegment *seg)
{
    CUDBG_VERIFY(seg, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments to UnmapOneMemorySegment\n");
    /* For an in-process debugger client, if the seg already had a
     * host VA, it wouldn't have been mapped in MapOneMemorySegment. */
    if ((haloGlobals.initData.flags & HALO_INIT_FLAGS_IN_PROCESS) &&
         seg->hostvaddr) {
        goto done;
    }

    if (munmap((void *)(uintptr_t)seg->mappedHostPtr, seg->mapped.size)) {
        HALO_ERROR("munmap failed with error %d (%s)\n", errno, strerror(errno));
        return CUDBG_ERROR_UNKNOWN;
    }

done:
    seg->mappedHostPtr = 0;

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalCreateHandleForMemorySegment_MRM(CudbgDevice dev, int32_t parentFd, uint32_t *newHandle)
{
    NvError err;

    CUDBG_VERIFY(newHandle && parentFd >= 0, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    *newHandle = 0;

#if cuosOsIsQnx()
    /* On QNX, use handle IDs instead of fds */
    err = NvRmMemHandleFromId((uint32_t) parentFd, (NvRmMemHandle *)newHandle);
    if (err != NvSuccess) {
        HALO_ERROR("NvRm: creating handle for %x failed with NvError %d\n", parentFd, err);
        return CUDBG_ERROR_UNKNOWN;
    }
#else
    /* Get a handle corresponding to the segment fd so that the fd can be closed.
       The fd that we receive over the socket counts towards the number of fds
       the process can open. The handles that the kernel driver creates do not.*/
    err = NvRmMemHandleFromFd(parentFd, (NvRmMemHandle *)newHandle);
    if (err != NvSuccess) {
        HALO_ERROR("NvRm: creating handle failed with NvError %d\n", err);
        return CUDBG_ERROR_UNKNOWN;
    }

    /* Once a handle has been created, we can close the original fd */
    close(parentFd);
#endif

    HALO_TRACE_FUNCTION(40, "created new handle: %d\n", *newHandle);

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDestroyHandleForMemorySegment_MRM(CudbgDevice dev, uint32_t handle)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(dev, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_TRACE_FUNCTION(40, "Freeing handle: %#x\n", handle);

    NvRmMemHandleFree((NvRmMemHandle) handle);

    HALO_TRACE_FUNCTION(40, "free'd handle: %#x\n", handle);

    return res;
}

static CUDBGResult
haloDmalReadServiceRoutineData_RM(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln, uint64_t offset, void *buf, uint32_t bufSz)
{
    /* Ensure caches are synced for local memory access in service routine calls */
    return dev->halo.readLocalMemoryCacheAware(dev, vsm, wp, ln, offset, buf, bufSz, HALO_CACHE_FLUSH_FLAGS_CPU | HALO_CACHE_FLUSH_FLAGS_GPU);
}

static CUDBGResult
haloDmalMapOneMemorySegment_MRM(haloMemoryMap *map, haloMemorySegment *seg,
                                uint64_t offset, uint64_t size)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CudbgDevice dev = haloGlobals.device[seg->sourceDeviceIdx];
    uint32_t prot = PROT_READ | PROT_WRITE;
    char *mappedHostPtr;
    uint64_t pageSize = getpagesize();
    int32_t slack;

    /* For an in-process debugger client, a seg that already has a
     * host VA shouldn't be mapped again. */
    if ((haloGlobals.initData.flags & HALO_INIT_FLAGS_IN_PROCESS) &&
        seg->hostvaddr) {
        seg->mappedHostPtr = seg->hostvaddr;
        seg->mapped.size = seg->size;
        seg->mapped.start = 0;
        goto done;
    }

    if (seg->type == HALO_MEM_SEG_MANAGED) {
        /* Bug 1850301: This codepath would lead to a SIGBUS because on mobile,
         * the libnvrm and kernel drivers protect pages from CPU access while kernels are running. */
        HALO_TRACE_FUNCTION(40, "MRM is too afraid of a SIGBUS to read managed memory. "
                            "Indicate upward to read from sysmem.\n");
        return CUDBG_ERROR_ADDRESS_NOT_IN_DEVICE_MEM;
    }

    HALO_TRACE_FUNCTION(10, "Mapping segment %#x\n", seg->mem);

    /* The offset argument of the ioctl needs to be page aligned */
    if (seg->size < HALO_DMAL_MRM_MAX_MAPPING_SIZE) {
        offset = 0;
        size = seg->size;
    }
    else {
        slack = offset & (pageSize - 1);
        size += slack;
        offset -= slack;
    }

    /* Make size page aligned, because the VMA created in the kernel
       from the mmap call has a page aligned size. The GPU driver expects
       the VMA size to match the size passed in the ioctl. The CUDA
       driver allocates all buffers in page-sized chunks. */
    size = (size + (pageSize - 1)) & ~(pageSize - 1);

    /* We use seg->mem as the fd for mobile, as that is the fd for that handle */

    /* The offset argument to mmap is necessary to setup vm_pgoff for this vma.
     * Cache maintenance ops depend on vm_pgoff being setup correctly. */
    mappedHostPtr = mmap(NULL, size, prot, MAP_SHARED, seg->mem, offset);
    if (mappedHostPtr == MAP_FAILED) {
        HALO_ERROR("mmap failed with error %d (%s)\n", errno, strerror(errno));
        return CUDA_ERROR_UNKNOWN;
    }


    HALO_TRACE_FUNCTION(40, "mapping handle: %#"PRId32", devvaddr: %#" PRIx64
                        ", devptr: %#" PRIx64 ", mappedHostPtr %p, offset %#"
                        PRIx64 ", size: %#" PRIx64 "\n",
                        seg->mem, seg->devvaddr,
                        seg->devptr, (uint64_t)(uintptr_t)mappedHostPtr, offset, size);


    seg->mappedHostPtr = (uint64_t)(uintptr_t)mappedHostPtr;
    seg->mapped.start = offset;
    seg->mapped.size = size;

    /* On ARM, cpu cache is physically tagged, which means a new mapping might
       read stale data from a previous mapping (by this process or another) &
       reading the same memory.  Prevent this by flushing the clean cache
       lines.*/
    res = dev->dmal->flushCpuMappingForDevvaddr(dev->memMapContext,
                                                seg->devvaddr + offset,
                                                seg->mapped.size,
                                                HALO_CACHE_FLUSH_INVALIDATE);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to flush cpu mapping after mapping\n");

done:

    return res;
}

#if defined(NVGPU_DBG_GPU_IOCTL_REG_OPS)
static CUDBGResult
haloDmalTranslateToMrmRegOp_MRM(NvU32 regOp, NvU8 *mrmRegOp)
{
    switch (regOp) {
    case HALO_REG_OP_READ_32:
        *mrmRegOp = NVGPU_DBG_GPU_REG_OP_READ_32;
        break;
    case HALO_REG_OP_WRITE_32:
        *mrmRegOp = NVGPU_DBG_GPU_REG_OP_WRITE_32;
        break;
    case HALO_REG_OP_READ_64:
        *mrmRegOp = NVGPU_DBG_GPU_REG_OP_READ_64;
        break;
    case HALO_REG_OP_WRITE_64:
        *mrmRegOp = NVGPU_DBG_GPU_REG_OP_WRITE_64;
        break;
    case HALO_REG_OP_READ_08:
        *mrmRegOp = NVGPU_DBG_GPU_REG_OP_READ_08;
        break;
    case HALO_REG_OP_WRITE_08:
        *mrmRegOp = NVGPU_DBG_GPU_REG_OP_WRITE_08;
        break;
    default:
        HALO_ERROR("FATAL: Unknown regOp %u!\n", regOp);
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalTranslateToMrmRegType_MRM(NvU32 regType, NvU8 *mrmRegType)
{
    switch (regType) {
    case HALO_REG_OP_TYPE_GLOBAL:
        *mrmRegType = NVGPU_DBG_GPU_REG_OP_TYPE_GLOBAL;
        break;
    case HALO_REG_OP_TYPE_GR_CTX:
        *mrmRegType = NVGPU_DBG_GPU_REG_OP_TYPE_GR_CTX;
        break;
    case HALO_REG_OP_TYPE_GR_CTX_TPC:
        *mrmRegType = NVGPU_DBG_GPU_REG_OP_TYPE_GR_CTX_TPC;
        break;
    case HALO_REG_OP_TYPE_GR_CTX_SM:
        *mrmRegType = NVGPU_DBG_GPU_REG_OP_TYPE_GR_CTX_SM;
        break;
    case HALO_REG_OP_TYPE_GR_CTX_CROP:
        *mrmRegType = NVGPU_DBG_GPU_REG_OP_TYPE_GR_CTX_CROP;
        break;
    case HALO_REG_OP_TYPE_GR_CTX_ZROP:
        *mrmRegType = NVGPU_DBG_GPU_REG_OP_TYPE_GR_CTX_ZROP;
        break;
    case HALO_REG_OP_TYPE_GR_CTX_QUAD:
        *mrmRegType = NVGPU_DBG_GPU_REG_OP_TYPE_GR_CTX_QUAD;
        break;
        /*
         * Not defined in the MRM ioctl header :-|
                case HALO_REG_OP_TYPE_FB:
                    *mrmRegType = NVGPU_DBG_GPU_REG_OP_TYPE_FB;
                    break;
                case HALO_REG_OP_TYPE_DEVICE:
                    *mrmRegType = NVGPU_DBG_GPU_REG_OP_TYPE_DEVICE;
                    break;
        */
    default:
        HALO_ERROR("FATAL: Unknown regType %u!\n", regType);
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

static void
haloDmalTranslateToHaloRegOpStatus_MRM(NvU32 mrmRegStatus, NvU8 *haloRegStatus)
{
    switch (mrmRegStatus) {
    case NVGPU_DBG_GPU_REG_OP_STATUS_SUCCESS:
        *haloRegStatus = HALO_REG_OP_STATUS_SUCCESS;
        break;
    case NVGPU_DBG_GPU_REG_OP_STATUS_INVALID_OP:
        *haloRegStatus = HALO_REG_OP_STATUS_INVALID_OP;
        break;
    case NVGPU_DBG_GPU_REG_OP_STATUS_INVALID_TYPE:
        *haloRegStatus = HALO_REG_OP_STATUS_INVALID_TYPE;
        break;
    case NVGPU_DBG_GPU_REG_OP_STATUS_INVALID_OFFSET:
        *haloRegStatus = HALO_REG_OP_STATUS_INVALID_OFFSET;
        break;
    case NVGPU_DBG_GPU_REG_OP_STATUS_UNSUPPORTED_OP:
        *haloRegStatus = HALO_REG_OP_STATUS_UNSUPPORTED_OP;
        break;
    case NVGPU_DBG_GPU_REG_OP_STATUS_INVALID_MASK:
        *haloRegStatus = HALO_REG_OP_STATUS_INVALID_MASK;
        break;
    default:
        HALO_ERROR("Unknown mrmRegStatus %u!\n", mrmRegStatus);
        *haloRegStatus = HALO_REG_OP_STATUS_UNKNOWN_ERROR;
        return;
    }
}
#endif

static CUDBGResult
getFdFromCtx(Context context, void *userData)
{
    FindFdFunctor *findFdFunctor = (FindFdFunctor *)userData;
    CUDBGFdTypes type;

    if (findFdFunctor->fd != 0)
        /* Already found */
        return CUDBG_SUCCESS;

    /* Restrict the search to contexts on the device we care about. */
    if (findFdFunctor->dev != context->dev)
        return CUDBG_SUCCESS;

    type = findFdFunctor->type;

    /* Check if the fdArray has been initialized */
    if (context->fdArray[type] == 0)
        return CUDBG_SUCCESS;

    findFdFunctor->fd = context->fdArray[type];

    return CUDBG_SUCCESS;
}

CUDBGResult
haloDmalFindFdOfType(CudbgDevice dev, int32_t *fd, CUDBGFdTypes type)
{
    /* When an active context does not exist and we need to do regops,
       we search all the contexts we know about, looking for one that
       has a fd's that can be used for regops. Note that we can only
       do GLOBAL regops with the fd we find. */
    CUDBGResult res = CUDBG_SUCCESS;
    FindFdFunctor findFdFunctor;

    findFdFunctor.dev = dev;
    findFdFunctor.type = type;
    findFdFunctor.fd = 0;

    /* Traverse the list of contexts and return the first valid fd of the given type. */
    res = haloStateTraverseContexts(getFdFromCtx, &findFdFunctor);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed when trying to find FD over all contexts\n");

    *fd = findFdFunctor.fd;

    return res;
}

static CUDBGResult
getDebugObjFromCtx(Context context, void *userData)
{
    FindFdFunctor *findFdFunctor = (FindFdFunctor *)userData;

    if (findFdFunctor->fd != 0)
        /* Already found */
        return CUDBG_SUCCESS;

    /* Restrict the search to contexts on the device we care about. */
    if (findFdFunctor->dev != context->dev)
        return CUDBG_SUCCESS;

    /* Check if the fdArray has been initialized */
    if (context->debugObj.mrm <= 0)
        return CUDBG_SUCCESS;

    /* Skip debug objects that are bound to channels that CUDA already closed */
    if (context->state == HALO_CTX_STATE_FINALIZING)
        return CUDBG_SUCCESS;

    findFdFunctor->fd = context->debugObj.mrm;

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalFindDebugInterface(CudbgDevice dev, int32_t *hDebugFd)
{
    /* When an active context does not exist and we need to do regops,
       we search all the contexts we know about, looking for one that
       has a fd's that can be used for regops. Note that we can only
       do GLOBAL regops with the fd we find. */
    CUDBGResult res = CUDBG_SUCCESS;
    FindFdFunctor findFdFunctor;

    findFdFunctor.dev = dev;
    findFdFunctor.fd = 0;

    /* Traverse the list of contexts and return the first valid fd of the given type. */
    res = haloStateTraverseContexts(getDebugObjFromCtx, &findFdFunctor);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed when trying to find FD over all contexts\n");

    *hDebugFd = findFdFunctor.fd;

    return res;
}

static CUDBGResult
clearPerContextDeviceEvents(Context context, void *userData)
{
    int32_t nvgpudbgfd = context->debugObj.mrm;
    CudbgDevice dev = (CudbgDevice)userData;
    struct KdContext_st kdctx = {0};

    if (context->dev != dev) {
        HALO_TRACE_FUNCTION(30, "Skipping context belonging to different device\n");
        return CUDBG_SUCCESS;
    }

    CUDBG_VERIFY(nvgpudbgfd > 0, CUDBG_SUCCESS,
                 "Debug interface not initialized, cannot clear event! Skipping!\n");

    kdctx.debugObject.mrm.handle = nvgpudbgfd;

    CUDBGResult res = globalKdApi[KDAPI_TYPE_MRM]->clearDebugEvent(&kdctx);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "KDAPI call failed: could not clear debug events");
    HALO_TRACE_FUNCTION(20, "Cleared per context device events\n");

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalClearEvent_MRM(CudbgDevice dev, Context ctx)
{
    /* Traverse the list of contexts, clearing all device events. */
    if (ctx) {
        HALO_TRACE_FUNCTION(10, "Clearing an event for context %p\n", ctx);
        return clearPerContextDeviceEvents(ctx, dev);
    }
    else {
        HALO_TRACE_FUNCTION(10, "Clearing an event for all contexts!\n");
        return haloStateTraverseContexts(clearPerContextDeviceEvents, dev);
    }
}

static CUDBGResult
haloDmalSetGlobalChannelTimeout_MRM(DebugObject debugObj, bool enable)
{
    struct nvgpu_dbg_gpu_timeout_args args = {0};
    int32_t iocResult;
    int nvgpudbgfd = debugObj.mrm;

    args.enable = enable ? NVGPU_DBG_GPU_IOCTL_TIMEOUT_ENABLE : NVGPU_DBG_GPU_IOCTL_TIMEOUT_DISABLE;

    iocResult = haloIoctl(nvgpudbgfd, NVGPU_DBG_GPU_IOCTL_TIMEOUT, &args, sizeof(args));

    CUDBG_VERIFY(iocResult != -1, CUDBG_ERROR_INTERNAL,
                 "ioctl NVGPU_DBG_GPU_IOCTL_TIMEOUT failed, error: %s\n",
                 strerror(errno));
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalGetDebugSessionPath_MRM(char* out, int capacity, CudbgDevice dev) {
    CUresult cudaRes = CUDA_SUCCESS;
    char pciId[16] = {0};
    int res = 0;
    CUDBG_VERIFY(out,          CUDBG_ERROR_INVALID_ARGS, "Output buffer must not be NULL.\n");
    CUDBG_VERIFY(capacity > 0, CUDBG_ERROR_INVALID_ARGS, "Output buffer capacity must be positive.\n");

    if (globals.devices[dev->deviceIdx]->state.bIntegrated) {
        res = snprintf(out, capacity, "/dev/nvhost-dbg-gpu");
        CUDBG_VERIFY(0 < res && res < capacity, CUDBG_ERROR_BUFFER_TOO_SMALL,
                    "Output buffer too small to build the device name for iGPU.\n");
        return CUDBG_SUCCESS;
    }

    cudaRes = cuiDeviceGetPCIBusId(globals.devices[dev->deviceIdx], pciId, sizeof(pciId));
    if (cudaRes != CUDA_SUCCESS) {
        const char* errorName = NULL;
        cuGetErrorName(cudaRes, &errorName);
        CUDBG_ERROR("cuiDeviceGetPCIBusId returned %s\n", errorName);
        return CUDBG_ERROR_INTERNAL;
    }

    res = snprintf(out, capacity, "/dev/nvgpu-pci/card-%s-dbg", pciId);
    CUDBG_VERIFY(0 < res && res < capacity, CUDBG_ERROR_BUFFER_TOO_SMALL,
                 "Output buffer too small to build the device name for dGPU at pciId %s\n", pciId);
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalAllocatePerContextDeviceEvent_MRM(int nvgpudbgfd, cuosEvent *event)
{
    CUDBGResult res;
    struct KdContext_st kdctx = {0};
    KdOsEventHandle hOsEvent = {0};

    kdctx.debugObject.mrm.handle = nvgpudbgfd;
    hOsEvent.nix.fd = nvgpudbgfd;

    res = globalKdApi[KDAPI_TYPE_MRM]->registerDebugEvent(&kdctx, hOsEvent);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to register debug event\n");

    event->readFd = hOsEvent.nix.fd;
    event->writeFd = -1;
    event->createdByCuos = 0;

    return res;
}


static CUDBGResult
haloDmalDebugObjectAlloc_MRM(Context ctx, uint32_t hAppClient,
                             uint32_t hComputeObject, DebugObject *debugObj)
{
    CUDBGResult res = CUDBG_SUCCESS;
    int32_t nvgpudbgfd = 0;
    KdDebugObject kdDebugObj = {0};

    /* NOTE: We are passing a halo Context structure instead of a CUctx one.
             This should be fixed in the future */
    res = globalKdApi[KDAPI_TYPE_MRM]->allocDebugObject((const CUctx *)ctx, &kdDebugObj);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to allocate debug object for MRM\n");
    nvgpudbgfd = kdDebugObj.mrm.handle;

    res = haloDmalAllocatePerContextDeviceEvent_MRM(nvgpudbgfd, &ctx->event);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to allocate per context device event\n");

    debugObj->mrm = nvgpudbgfd;

    HALO_TRACE_FUNCTION(10, "Allocated Debug interface  :%d\n", nvgpudbgfd);

    return res;
}

static bool
haloDmalDebugObjectCanSuspend_MRM(void)
{
#if defined(NVGPU_DBG_GPU_SUSPEND_ALL_CONTEXTS)
    return NV_TRUE;
#else
    return NV_FALSE;
#endif
}
static bool
haloDmalDebugObjectCanResume_MRM(void)
{
#if defined(NVGPU_DBG_GPU_RESUME_ALL_CONTEXTS)
    return NV_TRUE;
#else
    return NV_FALSE;
#endif
}

static bool
haloDmalDebugObjectCanReadESR_MRM(void)
{
#if defined(NVGPU_DBG_GPU_IOCTL_READ_SINGLE_SM_ERROR_STATE)
    return NV_TRUE;
#else
    return NV_FALSE;
#endif
}

static bool
haloDmalDebugObjectCanClearESR_MRM(void)
{
#if defined(NVGPU_DBG_GPU_IOCTL_CLEAR_SINGLE_SM_ERROR_STATE)
    return NV_TRUE;
#else
    return NV_FALSE;
#endif
}

static CUDBGResult
haloDmalDebugObjectClearSMESRInfo_MRM(CudbgDevice dev, DebugObject debugObj, uint32_t vsm, CudbgSMESRState_t *esrState)
{
#if defined(NVGPU_DBG_GPU_IOCTL_CLEAR_SINGLE_SM_ERROR_STATE)
    struct nvgpu_dbg_gpu_clear_single_sm_error_state_args args = {0};
    int32_t iocResult = 0;
    int32_t nvgpufd = debugObj.mrm;

    args.sm_id = vsm;

    iocResult = haloIoctl(nvgpufd, NVGPU_DBG_GPU_IOCTL_CLEAR_SINGLE_SM_ERROR_STATE, &args, sizeof(args));

    if (iocResult < 0) {
        HALO_ERROR("ioctl NVGPU_DBG_GPU_IOCTL_CLEAR_SINGLE_SM_ERROR_STATE failed, "
                   "cmd=%x code=%x error: %s\n", NVGPU_DBG_GPU_IOCTL_CLEAR_SINGLE_SM_ERROR_STATE,
                   iocResult, strerror(errno));
        return CUDBG_ERROR_INTERNAL;
    }
#endif
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectReadSMESRInfo_MRM(CudbgDevice dev, DebugObject debugObj, uint32_t vsm, CudbgSMESRState_t *esrState)
{
    CUDBGResult res;
    struct KdContext_st kdctx = {0};
    KdErrorState errorState = {0};

    kdctx.debugObject.mrm.handle = debugObj.mrm;

    res = globalKdApi[KDAPI_TYPE_MRM]->readErrorState(&kdctx, vsm, &errorState);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, CUDBG_ERROR_INTERNAL,
                 "KDAPI read sm error state failed (sm_id = %u)\n", vsm);

    esrState->hwwglobalesr = errorState.hwwGlobalEsr;
    esrState->hwwwarpesr   = errorState.hwwWarpEsr;
    esrState->hwwwarpesrpc = errorState.hwwWarpEsrPc64;
    esrState->hwwglobalesrmask = errorState.hwwGlobalEsrReportMask;
    esrState->hwwwarpesrmask = errorState.hwwWarpEsrReportMask;

    if (esrState->hwwglobalesr || esrState->hwwwarpesr) {
        HALO_TRACE_FUNCTION(2, "Debug object found outstanding error "
                            "on SMID:%u Global ESR:0x%x Warp ESR:0x%x PC:0x%x\n",
                            vsm, esrState->hwwglobalesr,
                            esrState->hwwwarpesr,
                            esrState->hwwwarpesrpc);
    }
    return CUDBG_SUCCESS;
}

typedef struct FindContextWithComputeObjectParams_t {
    CudbgDevice dev;
    Context context;
    uint32_t hComputeObject;
} FindContextWithComputeObjectParams;

static CUDBGResult
findContextWithComputeObject(Context ctx, void *userData)
{
    FindContextWithComputeObjectParams* functor = (FindContextWithComputeObjectParams*)userData;

    /* There shouldn't be duplicate compute objects, but in case there are, just
       return the first one */
    if (functor->context)
        return CUDBG_SUCCESS;

    if (ctx && ctx->dev == functor->dev && ctx->hComputeObject == functor->hComputeObject) {
        HALO_TRACE_FUNCTION(50, "Found context %p with hComputeObject %d\n", ctx, ctx->hComputeObject);
        functor->context = ctx;
    }
    else
        HALO_TRACE_FUNCTION(50, "Skipping context %p with hComputeObject %d\n", ctx, ctx->hComputeObject);

    return CUDBG_SUCCESS;
}

/* Functor used to suspend a specific context. Its purpose is to be used with
   haloStateTraverseContexts so as to suspend all the contexts of a device */
static CUDBGResult
suspendContext(Context ctx, void *userData)
{
    /* Bail if debug object is not valid */
    if (ctx->debugObj.mrm <= 0) {
        return CUDBG_SUCCESS;
    }

    (void)userData; /* We don't need user data here */
    CUDBGResult res = CUDBG_SUCCESS;

    NvBool shouldWait; /* Unused param */
    struct KdContext_st kdctx = {0};
    kdctx.debugObject.mrm.handle = ctx->debugObj.mrm;

    return globalKdApi[KDAPI_TYPE_MRM]->suspendContext(&kdctx, &shouldWait);
}

static CUDBGResult
haloDmalDebugObjectSuspendDevice_MRM(CudbgDevice dev, uint32_t *hasStopped, uint32_t *waitForEvent, Context *residentContext)
{
    *waitForEvent = false;
    CUDBGResult res = CUDBG_SUCCESS;
    *hasStopped = false;

    res = haloStateTraverseContexts(suspendContext, NULL);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Device suspension through contexts traversal failed, res=%d\n", res);

    *hasStopped = true;

    return CUDBG_SUCCESS;
}

/* Functor used to resume a specific context. Its purpose is to be used with
   haloStateTraverseContexts so as to resume all the contexts of a device */
static CUDBGResult
resumeContext(Context ctx, void *userData)
{
    /* Bail if debug object is not valid */
    if (ctx->debugObj.mrm <= 0) {
        return CUDBG_SUCCESS;
    }

    (void)userData; /* We don't need user data here */
    CUDBGResult res = CUDBG_SUCCESS;

    struct KdContext_st kdctx = {0};
    kdctx.debugObject.mrm.handle = ctx->debugObj.mrm;

    return globalKdApi[KDAPI_TYPE_MRM]->resumeContext(&kdctx);
}

static CUDBGResult
haloDmalDebugObjectResumeDevice_MRM(CudbgDevice dev, uint32_t *hasResumed)
{
    CUDBGResult res;
    *hasResumed = false;

    res = haloInvalidateCaches(dev);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Errored out while trying to invalidate caches, res=%d\n", res);

    res = haloStateTraverseContexts(resumeContext, NULL);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Device resuming through contexts traversal failed, res=%d\n", res);

    *hasResumed = true;
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectFree_MRM(Context ctx, DebugObject *debugObj, uint32_t *hComputeObj)
{
    CUDBGResult res = CUDBG_SUCCESS;
    int32_t nvgpudbgfd = debugObj->mrm;

    if (nvgpudbgfd <= 0) {
        HALO_TRACE_FUNCTION(10, "No debug interface opened\n");
        return CUDBG_SUCCESS;
    }

    KdDebugObject kdDebugObj = {0};
    kdDebugObj.mrm.handle = nvgpudbgfd;

    HALO_TRACE_FUNCTION(10, "Freeing Debug interface  :%d\n", nvgpudbgfd);
    struct KdContext_st kdctx = {0};
    kdctx.debugObject.mrm.handle = nvgpudbgfd;

    res = globalKdApi[KDAPI_TYPE_MRM]->unregisterDebugEvent(&kdctx);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to unregister debug event\n");

    /* NOTE: We are passing a halo Context structure instead of a CUctx one.
             This should be fixed in the future */
    res = globalKdApi[KDAPI_TYPE_MRM]->freeDebugObject((CUctx*)ctx, kdDebugObj);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to free debug object\n");

    debugObj->mrm = 0;
    *hComputeObj = 0;

    return res;
}

typedef struct {
    int *fdList;
    cuosEvent **eventList;
    Context *contextList;
    int idx;
    int maxListSize;
    CudbgDevice dev;
} EventListFunctor;

static CUDBGResult
getEventList(Context context, void *userData)
{
    int nvgpudbgfd = context->debugObj.mrm;
    EventListFunctor *functor = (EventListFunctor *)userData;

    if (functor->dev != context->dev)
        return CUDBG_SUCCESS;

    if (!haloStateContextIsActive(context))
        return CUDBG_SUCCESS;

    if (!context->enableEvents)
        return CUDBG_SUCCESS;

    if ((functor->fdList || functor->eventList || functor->contextList)
            && functor->idx >= functor->maxListSize)
        return CUDBG_ERROR_INVALID_ARGS;

    if (functor->fdList) {
        if (nvgpudbgfd > 0)
            functor->fdList[functor->idx] = nvgpudbgfd;
        else
            functor->fdList[functor->idx] = -1;
    }

    if (functor->eventList)
        functor->eventList[functor->idx] = &context->event;

    if (functor->contextList)
        functor->contextList[functor->idx] = context;

    functor->idx++;

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalGetEventListForDevice_MRM(CudbgDevice dev, cuosEvent **eventList, Context *contextList, int *numEvents, int maxListSize)
{
    EventListFunctor functor = {0};
    CUDBGResult res;

    CUDBG_VERIFY(numEvents, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    functor.eventList = eventList;
    functor.contextList = contextList;
    functor.idx = 0;
    functor.maxListSize = maxListSize;
    functor.dev = dev;

    res = haloStateTraverseContexts((haloCtxIterFunc)getEventList, &functor);
    *numEvents = functor.idx;

    return res;
}


static CUDBGResult
haloDmalForceCacheCoherence_MRM(CudbgDevice dev)
{
    CUDBGResult res = CUDBG_SUCCESS;
    /* Need to unmap all mappings so new mappings can get their clean cache
       lines invalidated */
    res = dev->haloClient->unmapMemory(dev);
    /* Could have no mappings, ignoring error */
    if (res != CUDBG_SUCCESS)
        HALO_TRACE_FUNCTION(49, "Failed to unmap all memory segments, ignoring...\n");
    /* Flush and invalidate the GPU cache to DRAM so they are picked up by CPU */
    res = dev->dmal->flushGpuWrites(dev);
    if (res != CUDBG_SUCCESS)
        HALO_ERROR("Failed to flush GPU L2\n");
    return res;
}

static CUDBGResult
haloDmalCallMrmExecRegOps_MRM(CudbgDevice dev, Context context, struct nvgpu_dbg_gpu_reg_op *regOps, int32_t numOps)
{
    CUDBGResult res = CUDBG_SUCCESS;
    int nvgpudbgFd = 0;
    struct KdContext_st kdctx = {0};

    if (context)
        nvgpudbgFd = context->debugObj.mrm;
    else if (dev->activeContext)
        nvgpudbgFd = dev->activeContext->debugObj.mrm;
    else {
        /* No active context, search for any other context
           on this device. */
        res = haloDmalFindDebugInterface(dev, &nvgpudbgFd);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed when looking for a debug interface\n");
    }

    if (nvgpudbgFd <= 0) {
        HALO_TRACE_FUNCTION(40, "No nvgpuFd available, bailing early!\n");
        return CUDBG_SUCCESS;
    }

    kdctx.debugObject.mrm.handle = nvgpudbgFd;

    return globalKdApi[KDAPI_TYPE_MRM]->execRegOps(&kdctx, false, (KdRegOp *)regOps, numOps);
}

static CUDBGResult
haloDmalExecRegOps_MRM(CudbgDevice dev, Context context, HaloRegOp *script, int32_t numOps)
{
    CUDBGResult res = CUDBG_SUCCESS;

    struct nvgpu_dbg_gpu_reg_op *regOps;
    bool anyRegOpFailed = false;
    int32_t i;

    regOps = calloc(numOps, sizeof *regOps);
    if (!script)
        return CUDBG_ERROR_UNKNOWN;

    for (i = 0; i < numOps; i++) {
        /* Translate the HALO defines to the corresponding MRM values */
        if ((res = haloDmalTranslateToMrmRegOp_MRM(script[i].regOp, &regOps[i].op))
            != CUDBG_SUCCESS)
            goto done;

        if ((res = haloDmalTranslateToMrmRegType_MRM(script[i].regType, &regOps[i].type))
            != CUDBG_SUCCESS)
            goto done;

        regOps[i].quad           = script[i].regQuad;
        regOps[i].group_mask     = script[i].regGroupMask;
        regOps[i].sub_group_mask = script[i].regSubGroupMask;
        regOps[i].offset         = script[i].regOffset;
        regOps[i].value_hi       = script[i].regValueHi;
        regOps[i].value_lo       = script[i].regValueLo;
        regOps[i].and_n_mask_hi  = script[i].regAndNMaskHi;
        regOps[i].and_n_mask_lo  = script[i].regAndNMaskLo;
    }

    /* Make the real EXEC_REG_OPS call */
    res = haloDmalCallMrmExecRegOps_MRM(dev, context, regOps, numOps);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("MRM EXEC_REG_OPS failed (res=%d)\n", res);
        goto done;
    }

    /* Fill out the results for all regops */
    for (i = 0; i < numOps; i++) {
        haloDmalTranslateToHaloRegOpStatus_MRM(regOps[i].status, &script[i].regStatus);
        if (script[i].regStatus != NVGPU_DBG_GPU_REG_OP_STATUS_SUCCESS) {
            HALO_ERROR("Command %d (offset: 0x%x) failed: %d.\n",
                       i, regOps[i].offset, regOps[i].status);
            anyRegOpFailed = true;
        }

        script[i].regValueLo = regOps[i].value_lo;
        script[i].regValueHi = regOps[i].value_hi;
    }

    if (anyRegOpFailed)
        res = CUDBG_ERROR_UNKNOWN;
    else
        res = CUDBG_SUCCESS;

done:
    free(regOps);

    return res;
}

static CUDBGResult
haloDmalReadReg32_MRM(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint32_t* value)
{
#if defined(NVGPU_DBG_GPU_IOCTL_REG_OPS)
    HaloRegOp script;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY_REGADDR(addr);

    memset(&script, 0, sizeof script);

    script.regType       = regType;
    script.regOp         = HALO_REG_OP_READ_32;
    script.regOffset     = (uint64_t)(uintptr_t)addr;

    res = dev->dmal->execRegOps(dev, NULL, &script, 1);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Read via execRegOps failed in %s.\n", __FUNCTION__);
        return res;
    }

    *value = script.regValueLo;

    HALO_TRACE_FUNCTION(40, "Read Reg32: addr: 0x%08x value: 0x%08x type=%d\n",
                        (uint32_t)(uintptr_t)addr, *value, script.regType);
#endif

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalReadReg64_MRM(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint64_t* value)
{
#if defined(NVGPU_DBG_GPU_IOCTL_REG_OPS)
    HaloRegOp script;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY_REGADDR(addr);

    memset(&script, 0, sizeof script);

    script.regType       = regType;
    script.regOp         = HALO_REG_OP_READ_64;
    script.regOffset     = (uint64_t)(uintptr_t)addr;

    res = dev->dmal->execRegOps(dev, NULL, &script, 1);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Read via execRegOps failed in %s.\n", __FUNCTION__);
        return res;
    }

    *value = ((uint64_t)script.regValueHi << 32) | script.regValueLo;

    HALO_TRACE_FUNCTION(40, "Read Reg64: addr: 0x%08" PRIx64 " value: 0x%08" PRIx64 " type=%d\n",
                        (uint64_t)(uintptr_t)addr, *value, script.regType);
#endif

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalWriteReg32_MRM(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint32_t* value)
{
#if defined(NVGPU_DBG_GPU_IOCTL_REG_OPS)
    HaloRegOp script;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY_REGADDR(addr);

    memset(&script, 0, sizeof script);

    script.regType       = regType;
    script.regOp         = HALO_REG_OP_WRITE_32;
    script.regOffset     = (uint64_t)(uintptr_t)addr;
    script.regValueLo    = *value;
    script.regAndNMaskLo = 0xffffffff;

    res = dev->dmal->execRegOps(dev, NULL, &script, 1);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Write via execRegOps failed in %s.\n", __FUNCTION__);
        return res;
    }

    HALO_TRACE_FUNCTION(40, "Write Reg32: addr: 0x%08x value: 0x%08x type=%d\n",
                        (uint32_t)(uintptr_t)addr, *value, script.regType);
#endif

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalWriteReg64_MRM(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint64_t* value)
{
#if defined(NVGPU_DBG_GPU_IOCTL_REG_OPS)
    HaloRegOp script;
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY_REGADDR(addr);

    memset(&script, 0, sizeof script);

    script.regType       = regType;
    script.regOp         = HALO_REG_OP_WRITE_64;
    script.regOffset     = (uint64_t)(uintptr_t)addr;
    script.regValueLo    = (uint32_t) *value;
    script.regValueHi    = (uint32_t) (*value >> 32);
    script.regAndNMaskLo = 0xffffffff;
    script.regAndNMaskHi = 0xffffffff;

    res = dev->dmal->execRegOps(dev, NULL, &script, 1);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Write via execRegOps failed in %s.\n", __FUNCTION__);
        return res;
    }

    HALO_TRACE_FUNCTION(40, "Write Reg64: addr: 0x%08llx value: 0x%08" PRIx64 " type=%d\n",
                        (uint64_t)(uintptr_t)addr, *value, script.regType);
#endif

    return CUDBG_SUCCESS;
}

/* L2 cache flush+invalidate */
static CUDBGResult
haloDmalFlushGPUWrites_MRM(CudbgDevice dev)
{
#if defined(NVRM_GPU_DEFINE_DEVICE_CACHECTRL_ATTR)
    NvError err = NvSuccess;
    const CUdev* device = globals.devices[dev->deviceIdx];
    NVRM_GPU_DEFINE_DEVICE_CACHECTRL_ATTR(gpuCacheCtrlAttr);

    gpuCacheCtrlAttr.flushL2 = NV_TRUE;
    gpuCacheCtrlAttr.flushFb = NV_TRUE;
    gpuCacheCtrlAttr.invalidateL2 = NV_TRUE;

    err = NvRmGpuDeviceCacheControl(device->dm.mrm->nvRmGpuDevice, &gpuCacheCtrlAttr);
    CUDBG_VERIFY(err == NvSuccess, CUDBG_ERROR_INTERNAL, "Failed to flush L2 cache, res=0x%x\n", (int)err);
#endif

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalFlushCpuMappingForDevvaddr_MRM(Context ctx, uint64_t devvaddr, uint64_t size, HaloCacheFlushOp op)
{
    void *pMapping = NULL;
    haloMemorySegment *seg = NULL;
    CUDBGResult res;
    NvError nvrm_res;
    haloMemoryMap *memMap;

    nvrm_res = NvSuccess;
    CUDBG_VERIFY(ctx && ctx->memMapActive, CUDBG_ERROR_INTERNAL, "Invalid context!\n");

    memMap = ctx->memMap;

    CUDBG_VERIFY(memMap, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    /* Find the segment corresponding to devvaddr */
    res = haloMemoryMapGetSegmentByDevVaddr(memMap, devvaddr, &seg);

    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Error getting segment for devvaddr:0x%" PRIx64 "\n", devvaddr);

    CUDBG_VERIFY((devvaddr - seg->devvaddr) >= seg->mapped.start,
                 CUDBG_ERROR_INVALID_ARGS,
                 "devvaddr %#" PRIx64 " not in mapped region of segment!\n",
                 devvaddr);

    /* Nothing to do if the segment isn't even mapped. */
    if (!(seg && seg->mappedHostPtr))
        return CUDBG_SUCCESS;

    pMapping = (void *)(uintptr_t)(seg->mappedHostPtr + (devvaddr - seg->devvaddr) - seg->mapped.start);

    /* Make all prior stores visible */
    cuosStoreFence();

    HALO_TRACE_FUNCTION(50, "Flushing cpu cache\n");

    switch (op) {
    case HALO_CACHE_FLUSH_WRITEBACK:
        nvrm_res = NvRmMemCacheSyncForDevice((NvRmMemHandle) seg->mem, pMapping, size);
        break;
    case HALO_CACHE_FLUSH_INVALIDATE:
    default:
        nvrm_res = NvRmMemCacheSyncForCpu((NvRmMemHandle) seg->mem, pMapping, size);
        break;
    }

    if (nvrm_res != NvSuccess) {
        HALO_ERROR(("Flushing CPU cache failed\n"));
        return CUDBG_ERROR_INTERNAL;
    }

    return res;
}

typedef struct CtxFromChannelGroupFunctor_t {
    Context ctx;
    uint32_t hChannelGroup;
} CtxFromChannelGroupFunctor;

static CUDBGResult
getContextFromChannelGroup(Context ctx, void *userData)
{
    CtxFromChannelGroupFunctor *functor = (CtxFromChannelGroupFunctor*)userData;

    /* Already got the context, move along */
    if (functor->ctx)
        return CUDBG_SUCCESS;

    if (ctx->hChannelGroup == functor->hChannelGroup) {
        functor->ctx = ctx;
        return CUDBG_SUCCESS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalEnableOrDisableChannelGroup_MRM(CudbgDevice dev, uint32_t rmChannelGroup, uint32_t hAppClient, bool bEnable)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CtxFromChannelGroupFunctor functor = {0};

    /* Here, we just want to resume the handle associated with this
       group/channel */
    functor.hChannelGroup = rmChannelGroup;
    res = haloStateTraverseContexts(getContextFromChannelGroup, (void*)&functor);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to find the context for channel group %x\n", rmChannelGroup);
    CUDBG_VERIFY(functor.ctx, CUDBG_ERROR_INVALID_ARGS, "Invalid rmChannelGroup! %x\n", rmChannelGroup);

    struct KdContext_st kdctx = {0};
    kdctx.debugObject.mrm.handle = functor.ctx->debugObj.mrm;

    if (bEnable) {
        res = globalKdApi[KDAPI_TYPE_MRM]->resumeContext(&kdctx);
    }
    else {
        NvBool shouldWait = 0;
        res = globalKdApi[KDAPI_TYPE_MRM]->suspendContext(&kdctx, &shouldWait);
    }
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "ioctl NVGPU_DBG_GPU_RESUME_ALL_CONTEXTS failed", " error: %s\n", strerror(errno));

    return CUDBG_SUCCESS;
}

static void
haloDmalInitInterfaces_MRM(HaloDmal haloDmal)
{
    /* Use RM versions for the following */
#if !cuosOsIsQnx()
    haloDmal->mapMemory                 = haloDmalMapMemory_RM;
    haloDmal->unmapMemory               = haloDmalUnmapMemory_RM;
#endif
    haloDmal->debugObjectAccessMemory   = haloDmalDebugObjectAccessMemory_MRM;

    haloDmal->mapOneMemorySegment       = haloDmalMapOneMemorySegment_MRM;
    haloDmal->unmapOneMemorySegment     = haloDmalUnmapOneMemorySegment_MRM;
    haloDmal->destroyHandleForMemorySegment = haloDmalDestroyHandleForMemorySegment_MRM;
    haloDmal->createHandleForMemorySegment = haloDmalCreateHandleForMemorySegment_MRM;
    haloDmal->readServiceRoutineData    = haloDmalReadServiceRoutineData_RM;

    haloDmal->execRegOps                = haloDmalExecRegOps_MRM;
    haloDmal->readReg32                 = haloDmalReadReg32_MRM;
    haloDmal->readReg64                 = haloDmalReadReg64_MRM;
    haloDmal->writeReg32                = haloDmalWriteReg32_MRM;
    haloDmal->writeReg64                = haloDmalWriteReg64_MRM;

    haloDmal->clearEvent                = haloDmalClearEvent_MRM;

    haloDmal->debugObjectAlloc          = haloDmalDebugObjectAlloc_MRM;
    haloDmal->debugObjectFree           = haloDmalDebugObjectFree_MRM;
    haloDmal->debugObjectClearSMESRInfo = haloDmalDebugObjectClearSMESRInfo_MRM;
    haloDmal->debugObjectReadSMESRInfo  = haloDmalDebugObjectReadSMESRInfo_MRM;
    haloDmal->debugObjectSuspendDevice  = haloDmalDebugObjectSuspendDevice_MRM;
    haloDmal->debugObjectResumeDevice   = haloDmalDebugObjectResumeDevice_MRM;

    haloDmal->debugObjectCanSuspend     = haloDmalDebugObjectCanSuspend_MRM;
    haloDmal->debugObjectCanResume      = haloDmalDebugObjectCanResume_MRM;
    haloDmal->debugObjectCanReadESR     = haloDmalDebugObjectCanReadESR_MRM;
    haloDmal->debugObjectCanClearESR    = haloDmalDebugObjectCanClearESR_MRM;

    haloDmal->getEventListForDevice     = haloDmalGetEventListForDevice_MRM;
    haloDmal->forceCacheCoherence       = haloDmalForceCacheCoherence_MRM;
    haloDmal->setGlobalChannelTimeout   = haloDmalSetGlobalChannelTimeout_MRM;

    haloDmal->flushCpuMappingForDevvaddr = haloDmalFlushCpuMappingForDevvaddr_MRM;
    haloDmal->enableOrDisableChannelGroup = haloDmalEnableOrDisableChannelGroup_MRM;

    haloDmal->flushGpuWrites = haloDmalFlushGPUWrites_MRM;
}
#endif

static CUDBGResult
haloDmalInitGlobals_MRM(HaloDmal haloDmal)
{
    CUDBGResult res = CUDBG_SUCCESS;

    haloDmal->globals.mrm.initialized = true;

    return res;
}

CUDBGResult
haloDmalInit_MRM(HaloDmal haloDmal)
{
    CUDBGResult res = CUDBG_SUCCESS;

    /* MRM is only supported on Linux+ARM */
#if cuosPlatformIncludesMrm() && (cuosOsIsAndroid() || cuosOsIsLinux() || cuosOsIsQnx())

    haloDmal->type = HALO_DMAL_TYPE_MRM;

    haloDmalInitGlobals_MRM(haloDmal);

    haloDmalInitInterfaces_MRM(haloDmal);

#endif
    return res;
}

