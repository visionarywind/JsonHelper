/*
 * Copyright 2007-2018 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */


/******************************************************************************
 *
 *   Module: halo_dmal_wddm.c
 *
 *   Description:
 *       Halo WDDM DMAL initialization
 *
 ******************************************************************************/

#include "halo.h"
#include "halo_client.h"
#include "halo_dmal_wddm.h"
#include "halo_internal.h"
#include "halo_state.h"

#include "kdapi.h"

// CUDA
#include "wddm_device.h"
#include "wddm_structs.h"
#include "wddm_thunk.h"

// Windows
#include "windows.h"

#define ESCAPE_DATA(type, varname)      \
    NVL_ESC_COMMON_##type varname;      \
    NVL_ESC_INIT(                       \
        &varname.Header,                \
        sizeof(varname),                \
        NVL_PRIV_CALLER_ID_WILDCARD,    \
        NVL_ESC_ID_COMMON_##type);

#define ESCAPE(vistaDevice, escapeData)                 \
    (thunkEscape(                                       \
        vistaDeviceGetAdapterHandleWDDM(vistaDevice),   \
        vistaDevice ? vistaDevice->hDevice : 0,         \
        0,                                              \
        D3DKMT_ESCAPE_DRIVERPRIVATE,                    \
        sizeof(escapeData),                             \
        &escapeData,                                    \
        NV_FALSE))

static D3DKMT_HANDLE
getAdapterHandle_WDDM(CudbgDevice dev)
{
    return deviceGetAdapterHandleWDDM(globals.devices[dev->deviceIdx]);
}

typedef struct {
    CudbgDevice dev;
    DebugObject *debugObj;
} DebugObjFunctor;

/* Copied over from halo_dmal_rm.c */
static CUDBGResult
getDebugObjHandleFromCtx_WDDM(Context context, void *userData)
{
    DebugObjFunctor *debugObjFunctor = (DebugObjFunctor *)userData;

    if (CUDBG_DEBUG_OBJECT_IS_VALID(*debugObjFunctor->debugObj))
        /* Already found */
        return CUDBG_SUCCESS;

    /* Restrict the search to contexts on the device we care about. */
    if (debugObjFunctor->dev != context->dev)
        return CUDBG_SUCCESS;

    /* Skip contexts that are in the middle of being destroyed */
    if (!haloStateContextIsActive(context))
        return CUDBG_SUCCESS;

    /* This context may not have a debug object allocated yet. This happens if
    * the context has not yet received a ctx create callback from the driver.
    * If so, skip it. */
    if (!CUDBG_DEBUG_OBJECT_IS_VALID(context->debugObj))
        return CUDBG_SUCCESS;

    *debugObjFunctor->debugObj = context->debugObj;

    return CUDBG_SUCCESS;
}

static CUDBGResult
getAnyDebugObjHandle_WDDM(CudbgDevice dev, DebugObject *debugObj)
{
    CUDBGResult res = CUDBG_SUCCESS;
    DebugObjFunctor debugObjFunctor;

    debugObjFunctor.dev = dev;
    debugObjFunctor.debugObj = debugObj;

    memset(debugObj, 0, sizeof(DebugObject));

    if (!(haloGlobals.initData.flags & HALO_INIT_FLAGS_ENABLE_PER_CONTEXT_DEBUG_OBJECT))
        return CUDBG_SUCCESS;

    /* Traverse the list of contexts and return the first valid debug object handle on this device. */
    haloStateTraverseContexts((haloCtxIterFunc)getDebugObjHandleFromCtx_WDDM, &debugObjFunctor);

    return res;
}

static CUvistaDevice *
haloDmalGetVistaDevice_WDDM(CudbgDevice dev)
{
    return deviceGetVistaDeviceWDDM2(globals.devices[dev->deviceIdx]);
}

static CUDBGResult
haloDmalInitPrivAccess_WDDM(CudbgDevice dev)
{
    HALO_TRACE(1, "Using regops on WDDM. Not initializing PRI access\n");
    dev->bar0Start = CUDBG_BAR0_START;
    dev->bar0Size = CUDBG_BAR0_SIZE;
    dev->bar0AddressRM = 0;
    dev->bar0 = NULL;
    dev->bar0HandleRM = 0;
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalFinalizePrivAccess_WDDM(CudbgDevice dev)
{
    HALO_TRACE(1, "Using regops on WDDM. Skipping teardown of PRIs\n");
    dev->bar0Start = 0;
    dev->bar0Size = 0;
    dev->bar0AddressRM = 0;
    dev->bar0 = NULL;
    dev->bar0HandleRM = 0;
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalTranslateToRmRegOp_WDDM(NvU32 regOp, NvU8 *rmRegOp)
{
    switch (regOp) {
    case HALO_REG_OP_READ_32:
        *rmRegOp = NV2080_CTRL_GPU_REG_OP_READ_32;
        break;
    case HALO_REG_OP_WRITE_32:
        *rmRegOp = NV2080_CTRL_GPU_REG_OP_WRITE_32;
        break;
    case HALO_REG_OP_READ_64:
        *rmRegOp = NV2080_CTRL_GPU_REG_OP_READ_64;
        break;
    case HALO_REG_OP_WRITE_64:
        *rmRegOp = NV2080_CTRL_GPU_REG_OP_WRITE_64;
        break;
    case HALO_REG_OP_READ_08:
        *rmRegOp = NV2080_CTRL_GPU_REG_OP_READ_08;
        break;
    case HALO_REG_OP_WRITE_08:
        *rmRegOp = NV2080_CTRL_GPU_REG_OP_WRITE_08;
        break;
    default:
        HALO_ERROR("FATAL: Unknown regOp %u!\n", regOp);
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalTranslateToRmRegType_WDDM(NvU32 regType, NvU8 *rmRegType)
{
    switch (regType) {
    case HALO_REG_OP_TYPE_GLOBAL:
        *rmRegType = NV2080_CTRL_GPU_REG_OP_TYPE_GLOBAL;
        break;
    case HALO_REG_OP_TYPE_GR_CTX:
        *rmRegType = NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX;
        break;
    case HALO_REG_OP_TYPE_GR_CTX_TPC:
        *rmRegType = NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_TPC;
        break;
    case HALO_REG_OP_TYPE_GR_CTX_SM:
        *rmRegType = NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_SM;
        break;
    case HALO_REG_OP_TYPE_GR_CTX_CROP:
        *rmRegType = NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_CROP;
        break;
    case HALO_REG_OP_TYPE_GR_CTX_ZROP:
        *rmRegType = NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_ZROP;
        break;
    case HALO_REG_OP_TYPE_FB:
        *rmRegType = NV2080_CTRL_GPU_REG_OP_TYPE_FB;
        break;
    case HALO_REG_OP_TYPE_GR_CTX_QUAD:
        *rmRegType = NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX_QUAD;
        break;
    case HALO_REG_OP_TYPE_DEVICE:
        *rmRegType = NV2080_CTRL_GPU_REG_OP_TYPE_DEVICE;
        break;
    default:
        HALO_ERROR("FATAL: Unknown regType %u!\n", regType);
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

static void
haloDmalTranslateToHaloRegOpStatus_WDDM(NvU32 rmRegStatus, NvU8 *haloRegStatus)
{
    switch (rmRegStatus) {
    case NV2080_CTRL_GPU_REG_OP_STATUS_SUCCESS:
        *haloRegStatus = HALO_REG_OP_STATUS_SUCCESS;
        break;
    case NV2080_CTRL_GPU_REG_OP_STATUS_INVALID_OP:
        *haloRegStatus = HALO_REG_OP_STATUS_INVALID_OP;
        break;
    case NV2080_CTRL_GPU_REG_OP_STATUS_INVALID_TYPE:
        *haloRegStatus = HALO_REG_OP_STATUS_INVALID_TYPE;
        break;
    case NV2080_CTRL_GPU_REG_OP_STATUS_INVALID_OFFSET:
        *haloRegStatus = HALO_REG_OP_STATUS_INVALID_OFFSET;
        break;
    case NV2080_CTRL_GPU_REG_OP_STATUS_UNSUPPORTED_OP:
        *haloRegStatus = HALO_REG_OP_STATUS_UNSUPPORTED_OP;
        break;
    case NV2080_CTRL_GPU_REG_OP_STATUS_INVALID_MASK:
        *haloRegStatus = HALO_REG_OP_STATUS_INVALID_MASK;
        break;
    default:
        HALO_ERROR("Unknown rmRegStatus %u!\n", rmRegStatus);
        *haloRegStatus = HALO_REG_OP_STATUS_UNKNOWN_ERROR;
        return;
    }
}

ct_assert(sizeof(KdRegOp) == sizeof(NV2080_CTRL_GPU_REG_OP));
static CUDBGResult
haloDmalCallRmExecRegOps_WDDM(CudbgDevice dev, Context context, bool useContextOp,
    NV2080_CTRL_GPU_REG_OP *script, int numOps)
{
    CUDBGResult result;
    DebugObject debugObj;
    struct KdContext_st kdctx;

    CUDBG_VERIFY(numOps <= 100, CUDBG_ERROR_INVALID_ARGS, "Can't execute more than 100 regops at once.\n");

    if (!context) {
        CUDBG_VERIFY(!useContextOp, CUDBG_ERROR_INVALID_ARGS, "Inconsistent parameters\n");

        /* We still need a context for global regops on WDDM */
        getAnyDebugObjHandle_WDDM(dev, &debugObj);
    } else {
        debugObj = context->debugObj;
    }

    CUDBG_VERIFY(CUDBG_DEBUG_OBJECT_IS_VALID(debugObj), CUDBG_ERROR_INVALID_ARGS, "Debug object is not valid\n");

    kdctx.debugObject.wddm.handle = debugObj.wddm;
    kdctx.deviceHandle.wddm.hAdapter = getAdapterHandle_WDDM(dev);

    result = globalKdApi[KDAPI_TYPE_WDDM]->execRegOps(&kdctx, NV_FALSE, (KdRegOp *)script, numOps);

    if (result != CUDBG_SUCCESS) {
        return CUDBG_ERROR_INTERNAL;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalReadReg32_WDDM(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint32_t* value)
{
    CUDBGResult res = CUDBG_SUCCESS;
    NV2080_CTRL_GPU_REG_OP script;
    Context ctx = dev->activeContext;
    bool useContextOp = false;

    CUDBG_VERIFY_REGADDR(addr);

    memset(&script, 0, sizeof(script));

    script.regOp = NV2080_CTRL_GPU_REG_OP_READ_32;
    script.regOffset = (uint32_t)(uintptr_t)(addr - dev->bar0);

    if (!ctx && regType != HALO_REG_OP_TYPE_GLOBAL) {
        if (dev->halo.deviceInfo.preemptionType != HALO_PREEMPTION_TYPE_NONE) {
            /* WAR 1803160 - We shouldn't be reading ctxsw'ed pris without an active context, but for now
            return zero and skip the actual read */
            HALO_TRACE(10, "Ignoring read ctxsw'ed pri(%#x) without an active context\n", addr);
            *value = 0x0;
            return CUDBG_SUCCESS;
        }
        else {
            HALO_TRACE(10, "Invalid context on pri %#x, forcing global\n", script.regOffset);
            regType = HALO_REG_OP_TYPE_GLOBAL;
        }
    }

    res = haloDmalTranslateToRmRegType_WDDM(regType, &script.regType);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to translate halo regtype to rm regtype\n");
        return res;
    }

    /* If we're issuing any ctx ops, ensure the channel/client are filled in */
    if (ctx && script.regType == NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX)
        useContextOp = true;

    res = haloDmalCallRmExecRegOps_WDDM(dev, ctx, useContextOp, &script, 1);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE(1, "Failed to read via regop: regType=%d, offset=%#x\n", regType, script.regOffset);
        HALO_ERROR("Failed to read via regop\n");
        return res;
    }
    *value = script.regValueLo;

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalReadReg64_WDDM(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint64_t* value)
{
    CUDBGResult res = CUDBG_SUCCESS;
    NV2080_CTRL_GPU_REG_OP script;
    Context ctx = dev->activeContext;
    bool useContextOp = false;

    CUDBG_VERIFY_REGADDR(addr);

    memset(&script, 0, sizeof(script));

    script.regOp = NV2080_CTRL_GPU_REG_OP_READ_64;
    script.regOffset = (uint32_t)(uintptr_t)(addr - dev->bar0);

    if (!ctx && regType != HALO_REG_OP_TYPE_GLOBAL) {
        if (dev->halo.deviceInfo.preemptionType != HALO_PREEMPTION_TYPE_NONE) {
            /* WAR 1803160 - We shouldn't be reading ctxsw'ed pris without an active context, but for now
            return zero and skip the actual read */
            HALO_TRACE(10, "Ignoring read ctxsw'ed pri(%#x) without an active context\n", addr);
            *value = 0x0;
            return CUDBG_SUCCESS;
        }
        else {
            HALO_TRACE(10, "Invalid context on pri %#x, forcing global\n", script.regOffset);
            regType = HALO_REG_OP_TYPE_GLOBAL;
        }
    }

    res = haloDmalTranslateToRmRegType_WDDM(regType, &script.regType);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to translate halo regtype to rm regtype\n");
        return res;
    }

    /* If we're issuing any ctx ops, ensure the channel/client are filled in */
    if (ctx && script.regType == NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX)
        useContextOp = true;

    res = haloDmalCallRmExecRegOps_WDDM(dev, ctx, useContextOp, &script, 1);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE(1, "Failed to read via regop: regType=%d, offset=%#x\n", regType, script.regOffset);
        HALO_ERROR("Failed to read via regop\n");
        return res;
    }
    *value = ((uint64_t)script.regValueHi << 32) | script.regValueLo;

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalWriteReg32_WDDM(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint32_t* value)
{
    CUDBGResult res = CUDBG_SUCCESS;
    NV2080_CTRL_GPU_REG_OP script;
    Context ctx = dev->activeContext;
    bool useContextOp = false;

    CUDBG_VERIFY_REGADDR(addr);

    memset(&script, 0, sizeof(script));

    script.regOp = NV2080_CTRL_GPU_REG_OP_WRITE_32;
    script.regOffset = (uint32_t)(uintptr_t)(addr - dev->bar0);
    script.regValueLo = *value;
    script.regAndNMaskLo = 0xffffffff;

    if (!ctx && regType != HALO_REG_OP_TYPE_GLOBAL) {
        if (dev->halo.deviceInfo.preemptionType != HALO_PREEMPTION_TYPE_NONE) {
            /* WAR 1803160 - We shouldn't be reading ctxsw'ed pris without an active context, but for now
            return zero and skip the actual read */
            HALO_TRACE(10, "Ignoring write ctxsw'ed pri(%#x) without an active context\n", addr);
            return CUDBG_SUCCESS;
        }
        else {
            HALO_TRACE(10, "Invalid context on pri %#x, forcing global\n", script.regOffset);
            regType = HALO_REG_OP_TYPE_GLOBAL;
        }
    }

    res = haloDmalTranslateToRmRegType_WDDM(regType, &script.regType);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to translate halo regtype to rm regtype\n");
        return res;
    }

    /* If we're issuing any ctx ops, ensure the channel/client are filled in */
    if (ctx && script.regType == NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX)
        useContextOp = true;

    res = haloDmalCallRmExecRegOps_WDDM(dev, ctx, useContextOp, &script, 1);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE(1, "Failed to write via regop: regType=%d, offset=%#x\n", regType, script.regOffset);
        HALO_ERROR("Failed to write via regop\n");
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalWriteReg64_WDDM(CudbgDevice dev, HaloRegOpType regType, volatile char* addr, uint64_t* value)
{
    CUDBGResult res = CUDBG_SUCCESS;
    NV2080_CTRL_GPU_REG_OP script;
    Context ctx = dev->activeContext;
    bool useContextOp = false;

    CUDBG_VERIFY_REGADDR(addr);

    memset(&script, 0, sizeof(script));

    script.regOp = NV2080_CTRL_GPU_REG_OP_WRITE_64;
    script.regOffset = (uint32_t)(uintptr_t)(addr - dev->bar0);
    script.regValueLo = (uint32_t)(*value);
    script.regAndNMaskLo = 0xffffffff;
    script.regValueHi = (uint32_t)((*value) >> 32);
    script.regAndNMaskHi = 0xffffffff;

    if (!ctx && regType != HALO_REG_OP_TYPE_GLOBAL) {
        if (dev->halo.deviceInfo.preemptionType != HALO_PREEMPTION_TYPE_NONE) {
            /* WAR 1803160 - We shouldn't be reading ctxsw'ed pris without an active context, but for now
            return zero and skip the actual read */
            HALO_TRACE(10, "Ignoring write ctxsw'ed pri(%#x) without an active context\n", addr);
            return CUDBG_SUCCESS;
        }
        else {
            HALO_TRACE(10, "Invalid context on pri %#x, forcing global\n", script.regOffset);
            regType = HALO_REG_OP_TYPE_GLOBAL;
        }
    }

    res = haloDmalTranslateToRmRegType_WDDM(regType, &script.regType);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to translate halo regtype to rm regtype\n");
        return res;
    }

    /* If we're issuing any ctx ops, ensure the channel/client are filled in */
    if (ctx && script.regType == NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX)
        useContextOp = true;

    res = haloDmalCallRmExecRegOps_WDDM(dev, ctx, useContextOp, &script, 1);
    if (res != CUDBG_SUCCESS) {
        HALO_TRACE(1, "Failed to write via regop: regType=%d, offset=%#x\n", regType, script.regOffset);
        HALO_ERROR("Failed to write via regop\n");
        return res;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalExecRegOps_WDDM(CudbgDevice dev, Context context, HaloRegOp *script, int numOps)
{
    CUDBGResult res = CUDBG_SUCCESS;

    NV2080_CTRL_GPU_REG_OP *regOps;
    bool anyRegOpFailed = false, useContextOp = false;
    int i;

    CUDBG_VERIFY(script, CUDBG_ERROR_INVALID_ARGS, "Invalid script\n");

    regOps = (NV2080_CTRL_GPU_REG_OP *)calloc(numOps, sizeof *regOps);
    CUDBG_VERIFY(regOps, CUDBG_ERROR_UNKNOWN, "Failed to allocate regOps\n");

    for (i = 0; i < numOps; i++) {
        /* Translate the HALO defines to the corresponding RM values */
        if ((res = haloDmalTranslateToRmRegOp_WDDM(script[i].regOp, &regOps[i].regOp))
            != CUDBG_SUCCESS)
            goto done;

        if ((res = haloDmalTranslateToRmRegType_WDDM(script[i].regType, &regOps[i].regType))
            != CUDBG_SUCCESS)
            goto done;

        /* If we're issuing any ctx ops, ensure the channel/client are filled in */
        if (regOps[i].regType == NV2080_CTRL_GPU_REG_OP_TYPE_GR_CTX)
            useContextOp = true;

        regOps[i].regQuad = script[i].regQuad;
        regOps[i].regGroupMask = script[i].regGroupMask;
        regOps[i].regSubGroupMask = script[i].regSubGroupMask;
        regOps[i].regOffset = script[i].regOffset;
        regOps[i].regValueHi = script[i].regValueHi;
        regOps[i].regValueLo = script[i].regValueLo;
        regOps[i].regAndNMaskHi = script[i].regAndNMaskHi;
        regOps[i].regAndNMaskLo = script[i].regAndNMaskLo;
    }

    /* Make the real EXEC_REG_OPS call */
    res = haloDmalCallRmExecRegOps_WDDM(dev, context, useContextOp, regOps, numOps);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("RM EXEC_REG_OPS failed (res=%d)\n", res);
        goto done;
    }

    /* Fill out the results for all regops */
    for (i = 0; i < numOps; i++) {
        haloDmalTranslateToHaloRegOpStatus_WDDM(regOps[i].regStatus, &script[i].regStatus);
        if (regOps[i].regStatus != NV2080_CTRL_GPU_REG_OP_STATUS_SUCCESS) {
            HALO_ERROR("Command %d (offset: 0x%x) failed: %d.\n",
                i, regOps[i].regOffset, regOps[i].regStatus);
            anyRegOpFailed = true;
        }

        script[i].regValueLo = regOps[i].regValueLo;
        script[i].regValueHi = regOps[i].regValueHi;
    }

    if (anyRegOpFailed)
        res = CUDBG_ERROR_UNKNOWN;
    else
        res = CUDBG_SUCCESS;

done:
    free(regOps);
    return res;
}

/* Don't need memory mapping on WDDM */
static CUDBGResult
haloDmalMapMemory_WDDM(Context context, haloMemoryMap *memMap, uint64_t va, uint64_t size, char **hostPtr)
{
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalUnmapMemory_WDDM(CudbgDevice dev)
{
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalMapOneMemorySegment_WDDM(haloMemoryMap *map, haloMemorySegment *seg, uint64_t offset, uint64_t size)
{
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalUnmapOneMemorySegment_WDDM(CudbgDevice dev, haloMemorySegment *seg)
{
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalReadBar1Size_WDDM(CudbgDevice dev, uint64_t *bar1Size)
{
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectAllocEvent_WDDM(CudbgDevice dev, DebugObject debugObj, uint32_t eventClassType, cuosEvent *eventfd, uint32_t *hDebugEvent)
{
    NvU32 rc;
    CUDBGResult result;
    struct KdContext_st kdctx;
    KdOsEventHandle eventHandle;

    kdctx.debugObject.wddm.handle = debugObj.wddm;
    kdctx.deviceHandle.wddm.hAdapter = getAdapterHandle_WDDM(dev);

    rc = cuosEventCreate(eventfd);
    if (rc != CUOS_SUCCESS) {
        HALO_ERROR("Failed to allocate OS event -> 0x%x.\n", rc);
        return CUDBG_ERROR_UNKNOWN;
    }

#if cuiOsIsWindows()
    eventHandle.windows.handle = (void *)eventfd->hEvent;
#else
    eventHandle.nix.fd = eventfd->readFd;
#endif

    result = globalKdApi[KDAPI_TYPE_WDDM]->registerDebugEvent(&kdctx, eventHandle);
    if (result != CUDBG_SUCCESS) {
        return CUDBG_ERROR_INTERNAL;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectFreeEvent_WDDM(CudbgDevice dev, DebugObject debugObj, cuosEvent* eventfd, uint32_t hDebugEvent)
{
    NvU32 rc;

    rc = cuosEventDestroy(eventfd);

    if (rc) {
        HALO_ERROR("Failed to free the OS event -> %d (ignored).\n", rc);
        return CUDBG_ERROR_INTERNAL;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectFree_WDDM(Context ctx, DebugObject *debugObj, uint32_t *hComputeObj)
{
    /* The debug object is freed by KMD/UMD */
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectPauseGrCtxSwitch_WDDM(CudbgDevice dev)
{
    HALO_ERROR("PauseGrCtxSwitch is neither supported nor needed on WDDM\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
haloDmalDebugObjectResumeGrCtxSwitch_WDDM(CudbgDevice dev)
{
    HALO_ERROR("ResumeGrCtxSwitch is neither supported nor needed on WDDM\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
haloDmalDebugObjectClearSMESRInfo_WDDM(CudbgDevice dev, DebugObject debugObj, uint32_t vsm,
                                       CudbgSMESRState_t *esrState)
{
    /* KMD will clear errors before resuming */
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectReadSMESRInfo_WDDM(CudbgDevice dev, DebugObject debugObj, uint32_t vsm,
                                      CudbgSMESRState_t *esrState)
{
    CUDBGResult result;
    struct KdContext_st kdctx;
    KdErrorState errorState;

    kdctx.debugObject.wddm.handle = debugObj.wddm;
    kdctx.deviceHandle.wddm.hAdapter = getAdapterHandle_WDDM(dev);

    result = globalKdApi[KDAPI_TYPE_WDDM]->readErrorState(&kdctx, vsm, &errorState);
    if (result != CUDBG_SUCCESS) {
        return CUDBG_ERROR_INTERNAL;
    }

    esrState->hwwglobalesr = errorState.hwwGlobalEsr;
    esrState->hwwwarpesr = errorState.hwwWarpEsr;
    esrState->hwwwarpesrpc = errorState.hwwWarpEsrPc64;
    esrState->hwwglobalesrmask = errorState.hwwGlobalEsrReportMask;
    esrState->hwwwarpesrmask = errorState.hwwWarpEsrReportMask;

    if (esrState->hwwglobalesr || esrState->hwwwarpesr) {
        HALO_TRACE_FUNCTION(2, "Debug object found outstanding error on SMID:%u Global ESR:0x%x Warp ESR:0x%x PC:0x%x\n",
            vsm, esrState->hwwglobalesr, esrState->hwwwarpesr, esrState->hwwwarpesrpc);
    }
    
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectSetMMUDebugMode_WDDM(Context ctx, bool on)
{
    CUDBGResult result;
    struct KdContext_st kdctx;
    KdSetMmuDebugModeAction action;

    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_ARGS, "Invalid context\n");

    kdctx.debugObject.wddm.handle = ctx->debugObj.wddm;
    kdctx.deviceHandle.wddm.hAdapter = getAdapterHandle_WDDM(ctx->dev);

    action = on
        ? KDAPI_MMU_DEBUG_MODE_ENABLE
        : KDAPI_MMU_DEBUG_MODE_DISABLE;

    result = globalKdApi[KDAPI_TYPE_WDDM]->setMmuDebugMode(&kdctx, action);
    if (result != CUDBG_SUCCESS) {
        return CUDBG_ERROR_INTERNAL;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectSuspendContext_WDDM(Context ctx, bool *waitForEvent)
{
    CUDBGResult result;
    struct KdContext_st kdctx;
    NvBool shouldWait;

    kdctx.debugObject.wddm.handle = ctx->debugObj.wddm;
    kdctx.deviceHandle.wddm.hAdapter = getAdapterHandle_WDDM(ctx->dev);

    result = globalKdApi[KDAPI_TYPE_WDDM]->suspendContext(&kdctx, &shouldWait);
    *waitForEvent = shouldWait;

    if (result != CUDBG_SUCCESS) {
        return CUDBG_ERROR_INTERNAL;
    }

    return CUDBG_SUCCESS;
}

typedef struct {
    bool hasValidContexts;
    bool hasStopped;
    bool waitForEvent;
    CudbgDevice dev;
} ContextSuspendState;

static CUDBGResult
haloDmalSuspendContextFn_WDDM(Context ctx, void *data)
{
    CUDBGResult res = CUDBG_SUCCESS;
    ContextSuspendState *state = (ContextSuspendState *)data;
    bool waitForEvent;

    /* Calling suspend on a ctx that is not owned by this device is incorrect.
     * Halo keeps all context in one global array, it tries to apply
     * every context to every device. This is a flaw if the devices have different DMALs.
     */
    if (state->dev != ctx->dev) {
        return CUDBG_SUCCESS;
    }

    /* Finding an invalid context here is not an error as SuspendDevice could be called during context initialization */
    if (!CUDBG_DEBUG_OBJECT_IS_VALID(ctx->debugObj)) {
        return CUDBG_SUCCESS;
    }

    res = haloDmalDebugObjectSuspendContext_WDDM(ctx, &waitForEvent);

    state->hasValidContexts = true;
    if (res == CUDBG_SUCCESS) {
        state->waitForEvent |= waitForEvent;
    }
    else {
        state->hasStopped = false;
    }

    return res;
}

static CUDBGResult
haloDmalDebugObjectSuspendDevice_WDDM(CudbgDevice dev, uint32_t *hasStopped, uint32_t *waitForEvent, Context *residentContext)
{
    CUDBGResult res;
    ContextSuspendState state = { 0 };

    state.hasValidContexts = false;
    state.hasStopped = true;
    state.waitForEvent = false;
    state.dev = dev;
    
    /* Unlike on RM, on WDDM each context must be suspended separately. The results are defined as such:
        - hasStopped: all valid contexts have been suspended or no valid contexts
        - waitForEvent: at least one valid suspended context requires the debug agent to wait for a device event
        - residentContext: TODO
        - result:
           - CUDBG_ERROR_INVALID_CONTEXT if no active contexts (HALO expects this error)
           - CUDBG_ERROR_INTERNAL if one of the valid context suspensions failed
           - CUDBG_SUCCESS if there is at least one valid contexts and all valid contexts have been suspended */
    res = haloStateTraverseContexts(haloDmalSuspendContextFn_WDDM, &state);

    if (!state.hasValidContexts) {
        *hasStopped = true;
        *waitForEvent = false;
        *residentContext = NULL;
        return CUDBG_ERROR_INVALID_CONTEXT;
    }

    *hasStopped = state.hasStopped;
    *waitForEvent = state.waitForEvent;
    *residentContext = NULL; /* TODO */

    return res;
}

static CUDBGResult
haloDmalDebugObjectResumeContext_WDDM(Context ctx)
{
    CUDBGResult result;
    struct KdContext_st kdctx;

    kdctx.debugObject.wddm.handle = ctx->debugObj.wddm;
    kdctx.deviceHandle.wddm.hAdapter = getAdapterHandle_WDDM(ctx->dev);

    result = globalKdApi[KDAPI_TYPE_WDDM]->resumeContext(&kdctx);
    if (result != CUDBG_SUCCESS) {
        return CUDBG_ERROR_INTERNAL;
    }

    return CUDBG_SUCCESS;
}

typedef struct {
    bool hasValidContexts;
    bool hasResumed;
    CudbgDevice dev;
} ContextResumeState;

static CUDBGResult
haloDmalResumeContextFn_WDDM(Context ctx, void *data)
{
    CUDBGResult res;
    ContextResumeState *state = (ContextResumeState *)data;
    /* Calling resume on ctx that is not owned by this device
     * Since Halo keeps all context in one global array, it tries to apply
     * every context to every device. This is a flaw if the devices are different DMALs.
     */
    if (state->dev != ctx->dev) {
        return CUDBG_SUCCESS;
    }

    /* Finding an invalid context here is not an error as ResumeDevice could be called during context initialization */
    if (!CUDBG_DEBUG_OBJECT_IS_VALID(ctx->debugObj)) {
        return CUDBG_SUCCESS;
    }

    res = haloDmalDebugObjectResumeContext_WDDM(ctx);

    state->hasValidContexts = true;
    if (res != CUDBG_SUCCESS) {
        state->hasResumed = false;
    }

    return res;
}

static CUDBGResult
haloDmalDebugObjectResumeDevice_WDDM(CudbgDevice dev, uint32_t *hasResumed)
{
    CUDBGResult res;
    ContextResumeState state = {0};

    res = haloInvalidateCaches(dev);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Errored out while trying to invalidate caches\n");
        return res;
    }

    state.hasValidContexts = false;
    state.hasResumed = true;
    state.dev = dev;

    /* Unlike on RM, on WDDM each context must be resumed separately. The results are defined as such:
        - hasResumed: all valid contexts have been resumed or no valid contexts
        - result:
           - CUDBG_ERROR_INTERNAL if one of the valid context resumes failed
           - CUDBG_SUCCESS if all valid contexts have been resumed or no valid contexts */
    res = haloStateTraverseContexts(haloDmalResumeContextFn_WDDM, &state);

    if (!state.hasValidContexts) {
        *hasResumed = true;
        return CUDBG_SUCCESS;
    }
    
    *hasResumed = state.hasResumed;

    return res;
}

static CUDBGResult
haloDmalDebugObjectGetResidentChannelHandle_WDDM(CudbgDevice dev, DebugObject debugObj, uint32_t *hChannel)
{
    HALO_ERROR("GetResidentChannelHandle is neither supported nor needed on WDDM\n");
    return CUDBG_ERROR_INTERNAL;
}

ct_assert(sizeof(KdVARangeInfo) == sizeof(HaloVARangeInfo));
static CUDBGResult
haloDmalDebugObjectGetVARanges_WDDM(Context ctx, uint64_t startVA, uint64_t endVA, HaloVARangeInfo ranges[], uint32_t length, uint32_t *numRanges)
{
    CUDBGResult result;
    struct KdContext_st kdctx;

    kdctx.debugObject.wddm.handle = ctx->debugObj.wddm;
    kdctx.deviceHandle.wddm.hAdapter = getAdapterHandle_WDDM(ctx->dev);

    result = globalKdApi[KDAPI_TYPE_WDDM]->getVARanges(&kdctx, startVA, endVA, (KdVARangeInfo *)ranges, length, numRanges);
    if (result != CUDBG_SUCCESS) {
        return CUDBG_ERROR_INTERNAL;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectAccessMemory_WDDM(Context ctx,
                                     uint64_t devvaddr, void *buf, uint64_t length,
                                     HaloMemoryAccessType accessType)
{
    CUDBGResult result;
    struct KdContext_st kdctx;
    KdMemoryOp memoryOp = { 0 };

    kdctx.debugObject.wddm.handle = ctx->debugObj.wddm;
    kdctx.deviceHandle.wddm.hAdapter = getAdapterHandle_WDDM(ctx->dev);
    memoryOp.gpuVA = devvaddr;
    memoryOp.buffer = NV_PTR_TO_NvP64(buf);
    memoryOp.sizeInBytes = (NvU32)length;

    result = globalKdApi[KDAPI_TYPE_WDDM]->accessMemory(&kdctx, accessType == HALO_MEMORY_ACCESS_TYPE_READ, &memoryOp, 1);
    if (result != CUDBG_SUCCESS) {
        return CUDBG_ERROR_INTERNAL;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectSetNextStopTriggerType_WDDM(CudbgDevice dev, DebugObject debugObj, uint32_t val)
{
    HALO_TRACE(20, "Not setting next stop trigger type: not supported on WDDM\n");
    return CUDBG_SUCCESS;
}

static bool
haloDmalDebugObjectIsStable_WDDM(void)
{
    return true;
}

static bool
haloDmalDebugObjectCanSuspend_WDDM(void)
{
    return true;
}

static bool
haloDmalDebugObjectCanResume_WDDM(void)
{
    return true;
}

static bool
haloDmalDebugObjectCanReadESR_WDDM(void)
{
    return true;
}

static bool
haloDmalDebugObjectCanClearESR_WDDM(void)
{
    return true;
}

static bool
haloDmalDebugObjectCanGetVARanges_WDDM(void)
{
    return true;
}

static bool
haloDmalDebugObjectCanAccessMemory_WDDM(void)
{
    return true;
}

static bool
haloDmalDebugObjectCanSetMMUDebugMode_WDDM(void)
{
    return true;
}

static bool
haloDmalDebugObjectHasPerContextEvents_WDDM(void)
{
    return true;
}

static bool
haloDmalDebugObjectHasPerContextSuspendResume_WDDM(void)
{
    return true;
}

static CUDBGResult
haloDmalClearEvent_WDDM(CudbgDevice dev, Context ctx)
{
    NvU32 rc;
    
    rc = cuosEventClear(&ctx->event);    
    CUDBG_VERIFY(rc == CUOS_SUCCESS, CUDBG_ERROR_UNKNOWN, "Failed to clear event from context=%p\n, rc=%#x", ctx->cuCtx, rc);

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalFreeDeviceEvent_WDDM(CudbgDevice dev)
{
    CUDBG_PRINT(50, "Not freeing device events on WDDM\n");
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalAllocateDeviceEvent_WDDM(CudbgDevice dev, const CUdev* pDev)
{
    CUDBG_PRINT(50, "Not allocating device events on WDDM\n");
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalSetWatchdogTimeout_WDDM(CudbgDevice dev, uint32_t timeout, uint32_t interval)
{
    HALO_ERROR("SetWatchdogTimeout is neither supported nor needed on WDDM\n");
    return CUDBG_ERROR_INTERNAL;
}

typedef struct {
    cuosEvent **eventList;
    Context *contextList;
    uint32_t idx;
    uint32_t listSize;
    CudbgDevice dev;
} EventListFunctor;

static CUDBGResult
haloDmalGetEventListFn_WDDM(Context context, void *userData)
{
    EventListFunctor *functor = (EventListFunctor *)userData;

    /* Make sure this context is on the correct device */
    if (functor->dev != context->dev)
        return CUDBG_SUCCESS;

    if (!haloStateContextIsActive(context))
        return CUDBG_SUCCESS;

    if (!context->enableEvents)
        return CUDBG_SUCCESS;

    /* Zero is an invalid fd for these */
    HALO_TRACE(50, "Grabbing fdlist for context %#x\n", context->cuCtx);

    if (functor->eventList) {
        CUDBG_VERIFY(functor->idx < functor->listSize, CUDBG_ERROR_INVALID_ARGS,
            "Not enough space to store eventList\n");

        functor->eventList[functor->idx] = &context->event;
    }

    if (functor->contextList) {
        CUDBG_VERIFY(functor->idx < functor->listSize, CUDBG_ERROR_INVALID_ARGS,
            "Not enough space to store contextList\n");

        functor->contextList[functor->idx] = context;
    }

    /* idx will keep a count of the valid fds, even if
    we don't store them in eventList */
    functor->idx++;

    return CUDBG_SUCCESS;
}


static CUDBGResult
haloDmalGetEventListForDevice_WDDM(CudbgDevice dev, cuosEvent **eventList, Context *contextList, int *numEvents, int listSize)
{
    CUDBGResult res;
    EventListFunctor functor = { 0 };

    CUDBG_VERIFY(numEvents, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    functor.eventList = NULL;
    functor.contextList = NULL;
    functor.idx = 0;
    functor.dev = dev;

    /* Traverse the list of contexts and return the number of fds we'll need. */
    res = haloStateTraverseContexts(haloDmalGetEventListFn_WDDM, &functor);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed when trying to find FD over all contexts\n");

    *numEvents = functor.idx;

    /* If eventList is NULL or listSize is 0, return only the number of fds */
    if ((eventList == NULL && contextList == NULL) || listSize == 0)
        return CUDBG_SUCCESS;

    CUDBG_VERIFY(*numEvents <= listSize, CUDBG_ERROR_INVALID_ARGS,
        "Not enough space to store fd list\n");

    functor.eventList = eventList;
    functor.contextList = contextList;
    functor.idx = 0;
    functor.listSize = listSize;
    functor.dev = dev;

    /* Traverse the list of contexts and return the first valid fd of the given type. */
    res = haloStateTraverseContexts(haloDmalGetEventListFn_WDDM, &functor);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed when trying to find FD over all contexts\n");

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalSetRMDebugMode_WDDM(CudbgDevice dev, bool on)
{
    HALO_ERROR("SetRMDebugMode is neither supported nor needed on WDDM\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
haloDmalSetPowerGatingState_WDDM(CudbgDevice dev, HaloPowerGatingState state)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CUresult status;
    CUvistaDevice *vistaDevice;
    ESCAPE_DATA(AELPG, escape);

    escape.parameterList[0].parameter = NV2080_CTRL_MC_POWERGATING_PARAMETER_ENABLED;
    if (state == HALO_POWER_GATING_STATE_ENABLED) {
        escape.parameterList[0].parameterValue = 1;
        escape.flags = NV2080_CTRL_MC_SET_POWERGATING_PARAMETER_FLAGS_BLOCKING_TRUE;
    }
    else {
        escape.parameterList[0].parameterValue = 0;
        escape.flags = NV2080_CTRL_MC_SET_POWERGATING_PARAMETER_FLAGS_BLOCKING_FALSE;
    }
    escape.listSize = 1;
    escape.opCode = NV_AELPG_OPCODE_SET_INFO;

    vistaDevice = haloDmalGetVistaDevice_WDDM(dev);
    status = ESCAPE(vistaDevice, escape);

    if (status != CUDA_SUCCESS || escape.Header.lResult != NVL_ESC_RESULT_SUCCESS) {
        HALO_ERROR("Failed to set power gating state (status=%d, result=%d)\n", status, escape.Header.lResult);
        return CUDBG_ERROR_INTERNAL;
    }

    return res;
}

static CUDBGResult
haloDmalSetChannelGroupTimeslice_WDDM(CudbgDevice dev, uint32_t rmChannelGroup, uint64_t usec)
{
    HALO_ERROR("SetChannelGroupTimeslice is neither supported nor needed on WDDM\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
haloDmalEnableOrDisableChannelGroup_WDDM(CudbgDevice dev, uint32_t rmChannelGroup, uint32_t hAppClient, bool bEnable)
{
    /* Non-KILP usages should be replaced to calls to SuspendContext/ResumeContext */
    HALO_ERROR("EnableOrDisableChannelGroup is neither supported nor needed on WDDM\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
haloDmalPreemptChannelGroup_WDDM(CudbgDevice dev, uint32_t rmChannelGroup, uint32_t hAppClient, bool *preemptTimedOut,
    uint64_t timeoutUs)
{
    /* This method is only used for KILP */
    HALO_ERROR("PreemptChannelGroup is neither supported nor needed on WDDM\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
haloDmalFlushCpuMappingForDevvaddr_WDDM(Context ctx, uint64_t devvaddr, uint64_t size, HaloCacheFlushOp op)
{
    /* No need to flush CPU mapping */
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalInitGlobals_WDDM(HaloDmal haloDmal)
{
    haloDmal->globals.wddm.initialized = true;
    return CUDBG_SUCCESS;
}

static void
haloDmalInitInterfaces_WDDM(HaloDmal haloDmal)
{
    haloDmal->initPrivAccess        = haloDmalInitPrivAccess_WDDM;
    haloDmal->finalizePrivAccess    = haloDmalFinalizePrivAccess_WDDM;
    haloDmal->readReg32             = haloDmalReadReg32_WDDM;
    haloDmal->readReg64             = haloDmalReadReg64_WDDM;
    haloDmal->writeReg32            = haloDmalWriteReg32_WDDM;
    haloDmal->writeReg64            = haloDmalWriteReg64_WDDM;
    haloDmal->execRegOps            = haloDmalExecRegOps_WDDM;

    haloDmal->mapMemory             = haloDmalMapMemory_WDDM;
    haloDmal->unmapMemory           = haloDmalUnmapMemory_WDDM;
    haloDmal->mapOneMemorySegment   = haloDmalMapOneMemorySegment_WDDM;
    haloDmal->unmapOneMemorySegment = haloDmalUnmapOneMemorySegment_WDDM;
    haloDmal->readBar1Size          = haloDmalReadBar1Size_WDDM;

    haloDmal->debugObjectAllocEvent                 = haloDmalDebugObjectAllocEvent_WDDM;
    haloDmal->debugObjectFreeEvent                  = haloDmalDebugObjectFreeEvent_WDDM;
    haloDmal->debugObjectFree                       = haloDmalDebugObjectFree_WDDM;
    haloDmal->debugObjectPauseGrCtxSwitch           = haloDmalDebugObjectPauseGrCtxSwitch_WDDM;
    haloDmal->debugObjectResumeGrCtxSwitch          = haloDmalDebugObjectResumeGrCtxSwitch_WDDM;
    haloDmal->debugObjectClearSMESRInfo             = haloDmalDebugObjectClearSMESRInfo_WDDM;
    haloDmal->debugObjectReadSMESRInfo              = haloDmalDebugObjectReadSMESRInfo_WDDM;
    haloDmal->debugObjectSetMMUDebugMode            = haloDmalDebugObjectSetMMUDebugMode_WDDM;
    haloDmal->debugObjectSuspendContext             = haloDmalDebugObjectSuspendContext_WDDM;
    haloDmal->debugObjectSuspendDevice              = haloDmalDebugObjectSuspendDevice_WDDM;
    haloDmal->debugObjectResumeContext              = haloDmalDebugObjectResumeContext_WDDM;
    haloDmal->debugObjectResumeDevice               = haloDmalDebugObjectResumeDevice_WDDM;
    haloDmal->debugObjectGetResidentChannelHandle   = haloDmalDebugObjectGetResidentChannelHandle_WDDM;
    haloDmal->debugObjectGetVARanges                = haloDmalDebugObjectGetVARanges_WDDM;
    haloDmal->debugObjectAccessMemory               = haloDmalDebugObjectAccessMemory_WDDM;
    haloDmal->debugObjectSetNextStopTriggerType     = haloDmalDebugObjectSetNextStopTriggerType_WDDM;

    haloDmal->debugObjectIsStable                   = haloDmalDebugObjectIsStable_WDDM;
    haloDmal->debugObjectCanSuspend                 = haloDmalDebugObjectCanSuspend_WDDM;
    haloDmal->debugObjectCanResume                  = haloDmalDebugObjectCanResume_WDDM;
    haloDmal->debugObjectCanReadESR                 = haloDmalDebugObjectCanReadESR_WDDM;
    haloDmal->debugObjectCanClearESR                = haloDmalDebugObjectCanClearESR_WDDM;
    haloDmal->debugObjectCanGetVARanges             = haloDmalDebugObjectCanGetVARanges_WDDM;
    haloDmal->debugObjectCanAccessMemory            = haloDmalDebugObjectCanAccessMemory_WDDM;
    haloDmal->debugObjectCanSetMMUDebugMode         = haloDmalDebugObjectCanSetMMUDebugMode_WDDM;
    haloDmal->debugObjectHasPerContextEvents        = haloDmalDebugObjectHasPerContextEvents_WDDM;
    haloDmal->debugObjectHasPerContextSuspendResume = haloDmalDebugObjectHasPerContextSuspendResume_WDDM;

    haloDmal->clearEvent            = haloDmalClearEvent_WDDM;
    haloDmal->freeDeviceEvent       = haloDmalFreeDeviceEvent_WDDM;
    haloDmal->allocateDeviceEvent   = haloDmalAllocateDeviceEvent_WDDM;
    haloDmal->setWatchdogTimeout    = haloDmalSetWatchdogTimeout_WDDM;
    haloDmal->getEventListForDevice = haloDmalGetEventListForDevice_WDDM;
    
    haloDmal->setRMDebugMode                = haloDmalSetRMDebugMode_WDDM;
    haloDmal->setPowerGatingState           = haloDmalSetPowerGatingState_WDDM;
    haloDmal->setChannelGroupTimeslice      = haloDmalSetChannelGroupTimeslice_WDDM;
    haloDmal->enableOrDisableChannelGroup   = haloDmalEnableOrDisableChannelGroup_WDDM;
    haloDmal->preemptChannelGroup           = haloDmalPreemptChannelGroup_WDDM;

    haloDmal->flushCpuMappingForDevvaddr = haloDmalFlushCpuMappingForDevvaddr_WDDM;
}

CUDBGResult
haloDmalInit_WDDM(HaloDmal haloDmal)
{
    CUDBGResult res = CUDBG_SUCCESS;

    /* WDDM is supported on all non-MODS WinLH and Win7 builds */
#if cuosOsIsWindows() && !cuosOsIsMods()

    haloDmal->type = HALO_DMAL_TYPE_WDDM;

    haloDmalInitGlobals_WDDM(haloDmal);

    haloDmalInitInterfaces_WDDM(haloDmal);

#endif
    return res;
}

