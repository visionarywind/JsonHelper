/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */


/******************************************************************************
 *
 *   Module: halo_dmal_wddm_legacy.c
 *
 *   Description:
 *       Legacy Halo WDDM DMAL initialization
 *
 ******************************************************************************/
#include "halo.h"
#include "halo_dmal_wddm_legacy.h"
#include "halo_internal.h"
#include "memobj.h"
#include "class/cl83de.h"
#include "ctrl/ctrl83de.h"

static CUDBGResult
haloDmalUnmapMemory_WDDM(CudbgDevice dev)
{
    CUDBGResult res = CUDBG_SUCCESS;

    dev->memMapContext = NULL;

    HALO_TRACE(10, "Halo unmapped using memcheck client\n");
    return res;
}

static CUDBGResult
haloDmalMapMemory_WDDM(Context context, haloMemoryMap *memMap, uint64_t va, uint64_t size, char **hostPtr)
{
    // If we are on windows vista or greater and are running with memcheck,
    // All memory is allocated in zerocopy
    CUmemobj* memobj;
    // In this case, the Halo is in the process's address space
    CUctx* ctx;
    uint64_t offset;

    if (!context)
        return CUDBG_ERROR_INTERNAL;

    ctx = (CUctx*)(uintptr_t)context->cuCtx;
    if (!ctx)
        return CUDBG_ERROR_INTERNAL;

    memobj = memobjGetByDeviceVaddr(ctx->memmgr, va);
    if (memobj) {
        offset = va - (uint64_t)memobjGetDeviceVaddr(memobj);
        *hostPtr = ((char *)memobjGetHostPtr(memobj) + offset);
        return CUDBG_SUCCESS;
    }
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
haloDmalDebugObjectAccessMemory_WDDM(Context ctx,
                                     uint64_t devvaddr, void *buf, uint64_t length,
                                     HaloMemoryAccessType accessType)
{
    CUDBGResult res = CUDBG_SUCCESS;
    char *hostPtr = NULL;

    CUDBG_VERIFY(ctx && buf && length, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    res = ctx->dev->haloClient->mapMemory(ctx,
                                          devvaddr,
                                          length,
                                          &hostPtr);
    if (res != CUDBG_SUCCESS || !hostPtr) {
        HALO_TRACE_FUNCTION(50, "Error in mapping memory in writeDeviceMemory\n");
        return res;
    }

    if (accessType == HALO_MEMORY_ACCESS_TYPE_READ)
        haloMemcpy(buf, hostPtr, (size_t)length);
    else
        haloMemcpy(hostPtr, buf, (size_t)length);
    return res;
}


static CUDBGResult
haloDmalReadBar1Size_WDDM(CudbgDevice dev, uint64_t *bar1Size)
{
    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalDebugObjectAlloc_WDDM(Context ctx, uint32_t hAppClient,
                              uint32_t hComputeObject, DebugObject *debugObj)
{
    HALO_ERROR("Allocating debug objects out-of-process is not supported\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
haloDmalDebugObjectFree_WDDM(Context ctx, DebugObject *debugObj,
                             uint32_t *hComputeObj)
{
#if defined(NV83DE_CTRL_CMD_FIFO_SUSPEND_RESUME_CTXSW) && cuiPlatformIncludesRm()
    NV_STATUS res = NV_OK;

    CUDBG_VERIFY(ctx && debugObj, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid arguments: ctx=%p debugObj=%p hComputeObj=%p\n",
                 ctx, debugObj, hComputeObj);
    CUDBG_VERIFY(CUDBG_DEBUG_OBJECT_IS_VALID(*debugObj), CUDBG_ERROR_INVALID_CONTEXT,
                 "Invalid debug object\n");

    res = CudaRmFree(globals.rmClient, globals.rmClient, debugObj->rm);
    CUDBG_VERIFY(res == NV_OK, CUDBG_ERROR_UNKNOWN,
                 "Failed to free debug object\n");

    handlePoolFree(globals.handlePool, debugObj->rm);
    debugObj->rm = CUDBG_INVALID_HANDLE;
#endif

    return CUDBG_SUCCESS;
}

static CUDBGResult
haloDmalInitGlobals_WDDM(HaloDmal haloDmal)
{
    CUDBGResult res = CUDBG_SUCCESS;

    haloDmal->globals.wddm.initialized = true;

    return res;
}

static void
haloDmalInitInterfaces_WDDM(HaloDmal haloDmal)
{
    haloDmal->debugObjectAlloc = haloDmalDebugObjectAlloc_WDDM;
    haloDmal->debugObjectFree = haloDmalDebugObjectFree_WDDM;
    haloDmal->mapMemory     = haloDmalMapMemory_WDDM;
    haloDmal->unmapMemory   = haloDmalUnmapMemory_WDDM;
    haloDmal->readBar1Size  = haloDmalReadBar1Size_WDDM;
    haloDmal->debugObjectAccessMemory = haloDmalDebugObjectAccessMemory_WDDM;
}

CUDBGResult
haloDmalInit_WDDM_Legacy(HaloDmal haloDmal)
{
    CUDBGResult res = CUDBG_SUCCESS;

    /* WDDM is supported on all non-MODS WinLH and Win7 builds */
#if cuosOsIsWindows() && !cuosOsIsMods()

    haloDmal->type = HALO_DMAL_TYPE_WDDM_LEGACY;

    haloDmalInitGlobals_WDDM(haloDmal);

    haloDmalInitInterfaces_WDDM(haloDmal);

#endif
    return res;
}

