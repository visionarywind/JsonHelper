/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: pascal_gp100_cilp.c
 *
 *   Description:
 *       Internal API for the low-level GPU access needed to support
 *       CILP (Compute Instruction-Level Preemption) in the debugger on
 *       Pascal (GP100+) class hardware.
 *
 ******************************************************************************/

#include "cudadebugger.h"
#include "halo_internal.h"
#include "pascal_gp10x_cilp.h"
#include "fermi.h"
#include "kepler_gk10x.h"
#include "halo_state.h"
#include "devtools/common/halo/inc/fermi/fermi.h"
#include "devtools/common/halo/inc/kepler/kepler_gk11x.h"
#include "devtools/common/halo/inc/pascal/pascal_scratchpad.h"
#include "pascal/gp100/dev_graphics_nobundle.h"

#define CUDA_DEVTOOLS_ENABLE_STATS
#include "halo_timing.h"

static CUDBGResult
pascal_gp10x_cilp_setPreemptCommand(Context ctx, uint32_t command);

static CUDBGResult
pascal_gp10x_cilp_suspendSM(CudbgDevice dev, uint32_t vsm)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t hasStopped = 0;
    uint32_t waitForEvent = 0;
    Context residentContext = NULL;

    /* Ensure that the subsequent loads are not reordered to before this point */
    cuosLoadFence();

    if (dev->dmal->debugObjectCanSuspend())
        res = dev->dmal->debugObjectSuspendDevice(dev, &hasStopped, &waitForEvent, &residentContext);
    else {
        HALO_ERROR("No debug object  support CILP cannot work !!!\n");
        return CUDBG_ERROR_INTERNAL;
    }

    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to suspend device via debug object\n");
        return res;
    }

    return res;
}

static CUDBGResult
pascal_gp10x_cilp_rescheduleChannel(Context context)
{
    CUDBGResult res = CUDBG_SUCCESS;

    /* Ensure sanity */
    CUDBG_VERIFY((context && context->dev), CUDBG_ERROR_INTERNAL,
                 "Context is invalid when attempting a preempt save\n");

    /* Skip contexts that are in the middle of being torn down */
    if (!haloStateContextIsActive(context)) {
        HALO_TRACE(10, "Returning early: Context %p in the middle of teardown\n",
                           context);
        return CUDBG_SUCCESS;
    }

    if (context->dev->dmal->debugObjectHasPerContextSuspendResume()) {
        res = context->dev->dmal->debugObjectResumeContext(context);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to resume the device: %d\n", res);
            return res;
        }
        return CUDBG_SUCCESS;
    }

    /* Skip contexts that don't yet have a valid channel group handle */
    if (context->hChannelGroup == CUDBG_INVALID_HANDLE) {
        HALO_TRACE(10, "Returning early: No valid channel handle\n");
        return CUDBG_SUCCESS;
    }

    /* This context corresponds to the device in question.  We need to locate
       its corresponding channel group handle, and reenable the channels through RM */
    res = context->dev->halo.scheduleChannelGroup(context->dev, context->hChannelGroup, context->hAppClient);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to schedule channel group (dev=%d, cg=0x%08x) (res=%d)\n",
                 context->dev->deviceIdx, context->hChannelGroup, res);

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_cilp_resumeSM(CudbgDevice dev, uint32_t vsm)
{
    CUDBGResult res = CUDBG_SUCCESS;

    if (dev->codeIsDirty)
        dev->halo.invalidateICache(dev);

    dev->codeIsDirty = 0;

    if (dev->activeContext) {
        HALO_TRACE_FUNCTION(1, "CILP device (SM Resume). First clearing preempt flag\n");
        res = pascal_gp10x_cilp_setPreemptCommand(dev->activeContext, PASCAL_GP10X_PREEMPT_COMMAND_NONE);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to write force suspend flag \n");
    }

    res = dev->halo.writePauseServicedMask(dev, false, vsm);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to write pause serviced mask (res=%d)\n", res);
        return res;
    }

    dev->halo.clearExceptions(dev, vsm);

    /* Ensure all CPU stores are visible to GPU at this point */
    cuosStoreFence();

    if (haloStateContextIsActive(dev->activeContext))
        dev->halo.contextCommonDataCacheOp(dev->activeContext, HALO_MEM_SEG_CACHE_INVALIDATE);

    res = pascal_gp10x_cilp_rescheduleChannel(dev->activeContext);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to reschedule channel\n");

#if 0
    if (dev->dmal->debugObjectCanResume())
        res = dev->dmal->debugObjectResumeDevice(dev, &hasResumed);
    else {
        HALO_ERROR("No debug object  support CILP cannot work !!!\n");
        return CUDBG_ERROR_INTERNAL;
    }
#endif

    return res;
}

static CUDBGResult
pascal_gp10x_cilp_isAnyExceptionSet(CudbgDevice dev, bool *anyExceptionSet)
{

    HALO_TRACE(1, "FORCING EXCEPTION TO TRUE\n");

    *anyExceptionSet = true;

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_cilp_readSMWarpMasks(CudbgDevice dev, uint32_t vsm, CudbgSMState_t *state)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CUwarpBitmask localMask = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;

    if (!dev->activeContext) {
        HALO_TRACE(10, "Null context. Returning early\n");
        return CUDBG_SUCCESS;
    }

    res = dev->halo.readSMWarpMasksFromScratchpad(&dev->halo, dev->activeContext->scratchpadAccessor, vsm, &state->tidValid, &state->bpmask, &state->bptrapmask);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read warp masks from scratchpad on SM:%u\n", vsm);
    
    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_cilp_readSMWarpMasksFromScratchpad(struct Halo_st *halo, HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm,
                                                CUwarpBitmask *validMask, CUwarpBitmask *bpMask, CUwarpBitmask *bpTrapMask)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CUwarpBitmask localMask = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;

    CUDBG_VERIFY(halo && scratchpadAccessor && validMask && bpMask && bpTrapMask, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    /* If we got notified, all live warps are paused.
       Thus, tidValid == pauseServicedMask
     */

    res = halo->readPauseServicedMask(halo, scratchpadAccessor, vsm, bpMask);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read pauseServicedMask on SM:%u\n", vsm);

    res = halo->readSaveWarpMask(halo, scratchpadAccessor, vsm, &localMask);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read saveWarpMask on SM:%u\n", vsm);


    if (!warpBitmaskEqual(&localMask, bpMask)) {
        CUDBG_ERROR("Mask mismatch : vsm%u SAVE != PAUSE ?? SAVE:" CU_WARP_BIT_MASK_FMT_128_STR " PAUSED: " CU_WARP_BIT_MASK_FMT_128_STR "\n",
                    vsm, CU_WARP_BIT_MASK_FMT_128_VAL(&localMask),
                    CU_WARP_BIT_MASK_FMT_128_VAL(bpMask));
    }

    warpBitmaskAssign(validMask, bpMask);

    /* For now, we claim all warps were in the trap mask */
    warpBitmaskAssign(bpTrapMask, bpMask);

    return res;
}

static CUDBGResult
pascal_gp10x_cilp_cilpForceFullSuspend(CudbgDevice dev, uint32_t *hasStopped, uint32_t *waitForEvent)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t vsm;
    CUwarpBitmask saveMask, pauseServiceMask;
    bool writeFlag = false;

    *waitForEvent = 0;

    if (dev->halo.deviceInfo.preemptionType != HALO_PREEMPTION_TYPE_CILP) {
        HALO_TRACE(10, "CILP disabled \n");
        return CUDBG_SUCCESS;
    }

    if (!(*hasStopped)) {
        HALO_TRACE(10, "Suspend called, but device didnt stop. Skipping CILP handshake\n");
        return res;
    }

    res = dev->halo.collectContext(dev, false);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to collect context on device\n");

    if (!dev->activeContext)
        return res;

    for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {
        // Get SaveMask
        res = dev->halo.readSaveWarpMask(&dev->halo, dev->activeContext->scratchpadAccessor, vsm, &saveMask);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read saveWarpMask on SM:%u\n", vsm);

        /* If the SM is truly empty. skip to the next one */
        if (!warpBitmaskAny(&saveMask))
            continue;

        // Get PauseServiceMask
        res = dev->halo.readPauseServicedMask(&dev->halo, dev->activeContext->scratchpadAccessor, vsm, &pauseServiceMask);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read pauseServicedMask on SM:%u\n", vsm);

        // if not equal, set flag and break
        if (!warpBitmaskEqual(&saveMask, &pauseServiceMask)) {
            HALO_TRACE(10, "On first suspend, SM%u has "
                           "pauseMask ("  CU_WARP_BIT_MASK_FMT_128_STR
                           ") != saveMask (" CU_WARP_BIT_MASK_FMT_128_STR ")\n",
                           vsm, CU_WARP_BIT_MASK_FMT_128_VAL(&pauseServiceMask),
                           CU_WARP_BIT_MASK_FMT_128_VAL(&saveMask));
            writeFlag = true;
            break;
        }
    }

    /* Forcibly tag context as active in the scratchpad. This way, subsequent calls to collectDeviceState will read
       a valid active context. */
    res = dev->halo.scratchpad.write_active(dev->activeContext->scratchpadAccessor, 1);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to write active flag\n");

    if (!writeFlag) {
        HALO_TRACE(20, "No mask mismatch found. Skipping SW pausing\n");
        return res;
    }

    res = dev->halo.clearExceptions(dev, -1);
    if (res != CUDBG_SUCCESS)
        HALO_ERROR("Failed to clear exceptions\n");

    /* Phase 2 of suspend : Write the flag, reschedule the channel and wait */
    HALO_TRACE(20, "CILP using 2 phase suspend. Writing flag and resuming channel ....\n");

    res = pascal_gp10x_cilp_setPreemptCommand(dev->activeContext, PASCAL_GP10X_PREEMPT_COMMAND_PAUSE_ON_RESTORE);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to write force suspend flag \n");

    dev->halo.contextCommonDataCacheOp(dev->activeContext, HALO_MEM_SEG_CACHE_INVALIDATE);

    res = dev->dmal->debugObjectSetNextStopTriggerType(dev, dev->activeContext->debugObj, 1);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to set next stop trigger\n");

    res = pascal_gp10x_cilp_rescheduleChannel(dev->activeContext);
    *waitForEvent = 1;

    return res;
}

/* How single-step nsteps works:

   If nsteps equals 1: use standard approach - single-step complete and
   BPT.PAUSE interrupts are enabled and backend waits for device event

   If nsteps is greater than 1: Single-step complete a interrupts
   are disabled. The single stepped warps are decrementing the nsteps value
   and do RTT, when nsteps reaches 0 (or an exception occurs) warps do
   BPT.PAUSE. The other warps are issuing BPT.PAUSE_QUIET to stay in the
   traphandler, but it does not stop single stepping thanks to disabled
   interrupts. Backend waits until device event */
static CUDBGResult
pascal_gp10x_cilp_setupSingleStepNsteps(CudbgDevice dev, uint32_t vsm, CUwarpBitmask *warpMask, uint32_t nsteps, uint32_t *nstepsold)
{
    CUDBGResult res;
    Context context = dev->activeContext;
    uint32_t wp;

    /* If no active context, there is nothing we can do. */
    CUDBG_VERIFY(context, CUDBG_ERROR_INVALID_CONTEXT, "No active context found in setupSingleStepNsteps.\n");

    CUDBG_VERIFY(warpMask && nstepsold, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
        /* Skip warps that are not being single stepped */
        if (!warpBitmaskGetBits(warpMask, wp, 1))
            continue;

        res = dev->halo.scratchpad.read_singleStepNSteps(context->scratchpadAccessor, vsm, wp, nstepsold);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read single step N steps\n");

        res = dev->halo.scratchpad.write_singleStepNSteps(context->scratchpadAccessor, vsm, wp, nsteps);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to write single step N steps\n");
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_cilp_clearExceptions(CudbgDevice dev, uint32_t vsm)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t regVal, newRegVal;
    uint32_t regOffset = 0;
#if !defined(RELEASE) && defined(CUDA_DEVTOOLS_ENABLE_STATS)
    haloTimer timer;
#endif

    HALO_TIMER_START(timer);
    HALO_TRACE_FUNCTION(10, "Clearing stop trigger from all SMs if set\n");

    if (!dev->activeContext)
        return CUDBG_SUCCESS;

    /* Write the broadcast register */

    res = dev->halo.getPRIOffset(dev, HALO_PRI_SM_DBGR_CONTROL0, -1, &regOffset);
    if (res != CUDBG_SUCCESS)
        return res;

    res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                     (char *)(uintptr_t)regOffset,
                                     &regVal);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to read broadcast DBGR_CONTROL0\n");
        return res;
    }

    newRegVal = SETFIELD32(regVal, NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_CONTROL0_STOP_TRIGGER, 0);
    if (newRegVal != regVal) {
        res = dev->haloClient->writeReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                          (char *)(uintptr_t)regOffset,
                                          &newRegVal);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to write broadcast DBGR_CONTROL0\n");
            return res;
        }
    }

    HALO_TIMER_STOP(timer);
    HALO_TIMER_PRINT(timer, 20, "pascal_gp10x_cilp_clearExceptions\n");

    return res;
}

static CUDBGResult
pascal_gp10x_cilp_setPreemptCommand(Context ctx, uint32_t command)
{
    CUDBGResult res = CUDBG_SUCCESS;

    if (command != PASCAL_GP10X_PREEMPT_COMMAND_NONE &&
        command != PASCAL_GP10X_PREEMPT_COMMAND_PAUSE_ON_RESTORE) {
        HALO_ERROR("Unknown command : %u\n", command);
        return CUDBG_ERROR_INVALID_ARGS;
    } 

    if (!ctx) {
        HALO_TRACE(40, "No context when trying to set preemptCommand. Bailing with success\n");
        return CUDBG_SUCCESS;
    }

    res = haloScratchpadSetField(ctx, HALO_SCRATCHPAD_FIELD_PREEMPT_COMMAND,
				 HALO_SCRATCHPAD_SECTION_GLOBAL,
				 0, 0, 0, &command, sizeof(command));
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
		 "Failed to write force suspend flag \n");
    return res;
}

static CUDBGResult
pascal_gp10x_cilp_resumeDevice(CudbgDevice dev, uint32_t *hasResumed, uint32_t skipResume)
{
    CUDBGResult res = CUDBG_SUCCESS;

    *hasResumed = 0;

    if (dev->codeIsDirty)
        dev->halo.invalidateICache(dev);

    dev->codeIsDirty = 0;

    /* ON CILP, we need to update the pauseServicedMask on a full resume */
    if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_CILP) {

        if (haloStateContextIsActive(dev->activeContext)) {
            HALO_TRACE_FUNCTION(1, "CILP device. First clearing preempt flag\n");
            res = pascal_gp10x_cilp_setPreemptCommand(dev->activeContext, PASCAL_GP10X_PREEMPT_COMMAND_NONE);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                         "Failed to write force suspend flag \n");

            HALO_TRACE_FUNCTION(1, "CILP device. Updating the pauseServicedMask\n");

            res = dev->halo.writePauseServicedMask(dev, true, 0);
            if (res != CUDBG_SUCCESS) {
                HALO_ERROR("Failed to write pause serviced mask (res=%d)\n", res);
                return res;
            }
        }

        dev->halo.clearExceptions(dev, -1);

        /* Ensure all CPU stores are visible to GPU at this point */
        cuosStoreFence();

        /* Don't resume the device if there happen to be other contexts with
           events.  Instead, keep the device frozen and handle those events
           on the next turn of handleDeviceEvent */
        if (!skipResume) {
            HALO_TRACE_FUNCTION(1, " Initiating CILP restore...\n");
            /* BUG 1726885 - Initiate the preemption restore via the debug object.  Normally we
               would re-enable the channels one-by-one via 'initiatePreemptionRestore',
               but this doesn't re-enable channels that could be disabled via
               debugObjectSuspendDevice that the debugger backend doesn't know about yet. */
            if (dev->dmal->debugObjectCanResume())
                res = dev->dmal->debugObjectResumeDevice(dev, hasResumed);
            else {
                HALO_TRACE_FUNCTION(10, "BUG 1726885 - debugObject cannot resume device!\n");
                res = dev->halo.initiatePreemptionRestore(dev, &dev->preemptState);
            }
            if (res != CUDBG_SUCCESS) {
                HALO_ERROR("Failed to initiate preemption restore\n");
                return res;
            }
        }
        else {
            if (haloStateContextIsActive(dev->activeContext))
                dev->halo.contextCommonDataCacheOp(dev->activeContext, HALO_MEM_SEG_CACHE_INVALIDATE);

            HALO_TRACE_FUNCTION(1, "Pending multicontext CILP event, faking GPU resume\n");
        }

        *hasResumed = 1;

        HALO_TRACE_FUNCTION(1, "CILP resumeDevice done\n");

        return res;
    }

    /* Fall through if no CILP */
    return kepler_gk11x_resumeDevice(dev, hasResumed, skipResume);
}

static CUDBGResult
pascal_gp10x_cilp_invalidateICache(CudbgDevice dev)
{
    HALO_TRACE(10, "Running on CILP, no I$ invalidate needed\n");
    return CUDBG_SUCCESS;
}

/* Populate the debugger structure with Pascal GP100 specific CILP functions. */
void
haloDeviceInit_gp10x_cilp(Halo_st *halo)
{
    if (halo->deviceInfo.preemptionType != HALO_PREEMPTION_TYPE_CILP) {
        HALO_TRACE(1, "CILP not enabled on GP100+ device.\n");
        return;
    }

    HALO_TRACE(10, "CILP HALO enabled. Force using regops\n");

    halo->deviceInfo.useRegOps = true;

    halo->suspendSM  = pascal_gp10x_cilp_suspendSM;
    halo->resumeSM = pascal_gp10x_cilp_resumeSM;
    halo->isAnyExceptionSet = pascal_gp10x_cilp_isAnyExceptionSet;
    halo->readSMWarpMasks = pascal_gp10x_cilp_readSMWarpMasks;
    halo->readSMWarpMasksFromScratchpad = pascal_gp10x_cilp_readSMWarpMasksFromScratchpad;

    halo->suspendDevice = fermi_suspendDevice;
    halo->resumeDevice  = pascal_gp10x_cilp_resumeDevice;

    halo->setupSingleStepNsteps = pascal_gp10x_cilp_setupSingleStepNsteps;
    halo->clearExceptions = pascal_gp10x_cilp_clearExceptions;

    halo->cilpForceFullSuspend = pascal_gp10x_cilp_cilpForceFullSuspend;
    halo->invalidateICache = pascal_gp10x_cilp_invalidateICache;
    
    halo->setPreemptCommand = pascal_gp10x_cilp_setPreemptCommand;
    halo->preemptPreHook = fermi_preemptPreHook;
    halo->preemptPostHook = fermi_preemptPostHook;
};
