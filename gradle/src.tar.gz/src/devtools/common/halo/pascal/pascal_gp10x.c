/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: pascal_gp10x.c
 *
 *   Description:
 *       Internal API for the low-level GPU access needed to support
 *       the debugger on Pascal (GP10x).
 *
 ******************************************************************************/

#include "fermi.h"
#include "kepler.h"
#include "maxwell.h"
#include "pascal.h"
#include "halo_internal.h"
#include "halo_state.h"
#include "pascal/gp100/dev_graphics_nobundle.h"
#include "pascal_cilp_preemption_buffer.h"
#include "maxwell_gm10x_kilp.h"
#include "cuda_macros.h"

#define PASCAL_WARP_ID_MASK_HI  ~0x3
#define PASCAL_WARP_ID_SHIFT_HI  0x1
#define PASCAL_WARP_PART_SHIFT   0x1
#define PASCAL_WARP_ID_MASK_LO   0x1

/* Partition bitfield in warp id encoding.  For gp10x, this is the second bit
   -- Every other set of two warps are part of one sm, i.e:
   tpc mask : 10 11 11 10 11 10 11 11 ->                         = 0xBEEF
   vsm0 mask: 10    11    11    11    -> 00 00 00 00 10 11 11 11 = 0x00BF
   vsm1 mask:    11    10    10    11 -> 00 00 00 00 11 10 10 11 = 0x00EB
*/
/* The bitfield of the physical CTAID that corresponds to the virtual CTA
   -- Rest is for the part id. */
#define PASCAL_GP10X_CTA_PART_BIT 5
#define PASCAL_GP10X_CTAID_MASK ((1 << PASCAL_GP10X_CTA_PART_BIT) -1)

/* Remove the partition id */
#define PASCAL_GP10X_WARP_TPC2SM_ID(wp) \
    (((wp & PASCAL_WARP_ID_MASK_HI) >> PASCAL_WARP_ID_SHIFT_HI) | (wp & PASCAL_WARP_ID_MASK_LO))

/* Add in the partition id */
#define PASCAL_GP10X_WARP_SM2TPC_ID(vwp, pid) \
    (((vwp << PASCAL_WARP_ID_SHIFT_HI) & PASCAL_WARP_ID_MASK_HI) \
     | (pid << PASCAL_WARP_PART_SHIFT)                           \
     | (vwp & PASCAL_WARP_ID_MASK_LO))


ct_assert(PASCAL_GP10X_TRAP_HANDLER_SCRATCHPAD_SIZE <= 1ULL << 32); // TODO: Move this into core driver code 

/* The number of the register where the stack pointer
   is placed */
#define PASCAL_ABI_SP_REGNUM 1
#define PASCAL_NUM_PREDICATES 7


static CUDBGResult
pascal_gp10x_virtualMaskToPhysicalMask(CudbgDevice dev, uint32_t vsm, CUwarpBitmask *src, CUwarpBitmask *dst);

/* The following requires some explaination.  The traphandler for arch uses a
 * linear allocator for allocating space in the cilp buffer.  This linear allocator
 * asserts that all warps on the SM either save (increment the linear allocator)
 * or restore (decrement the linear allocator), but never both at the same time.
 * This isn't a problem with CILP, since all warps end up synchronizing by nature
 * of CILP.
 * For non-CILP, there is no synchronization, a warp race through save & restore,
 * or some paths in the traphandler don't save/restore and thus warps that do
 * end up overwriting other warp's state.
 * To prevent this, we implement a sort of 'service routine' or 'shake'.  Warps
 * PAUSE/PAUSE_QUIET normally, but then the preemption command is set and the warps
 * are resumed handle it.  During this, warps should stay in the traphandler, eventually
 * PAUSEing to notify the CPU the save has completed.
 */

static CUDBGResult
pascal_gp10x_setPreemptCommand(Context ctx, uint32_t preemptcmd)
{
    CUDBGResult res = CUDBG_SUCCESS;

    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");
    CUDBG_VERIFY(preemptcmd == PASCAL_GP10X_PREEMPT_COMMAND_NONE ||
                 preemptcmd == PASCAL_GP10X_PREEMPT_COMMAND_SAVE_ON_PAUSE ||
                 preemptcmd == PASCAL_GP10X_PREEMPT_COMMAND_RESTORE_ON_RESUME,
                 CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args\n");

    ctx->dev->halo.scratchpad.write_preemptCommand(ctx->scratchpadAccessor, preemptcmd);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to write preempt command\n");

    return res;
}

static CUDBGResult
pascal_gp10x_syncPreemptionSaveBuffer(CudbgDevice dev, int32_t vsm, PascalPreemptCommand cmd)
{
    CUDBGResult res = CUDBG_SUCCESS, res2 = CUDBG_SUCCESS;
    CUwarpBitmask tidValid, zeroMask = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;

    if (!haloStateContextIsActive(dev->activeContext))
        return CUDBG_SUCCESS;

    /* The basic algorithm here is this:
       1) Check if the SM is empty.
       2) Clear BPT_PAUSE
       3) Set the preempt command for all warps on the SM
       3.5) Reset the CILP buffer linear allocator
       4) Clear exceptions
       5) Resume the TPC!
       6) Wait for all the warps to finish saving
       7) Lock the SM down with stop trigger
       8) Clear the preempt command
       9) Clear the newly generated exceptions
       10) Update the preempt bpmask
    */

    /* 1) Check if the SM is empty first - if so, DONE */
    res = dev->halo.readWarpMaskPRI(dev, vsm, HALO_REG_OP_TYPE_GLOBAL, HALO_MASK_PRI_WARP_VALID, &tidValid);
    if (res != CUDBG_SUCCESS)
        return res;

    if (!warpBitmaskAny(&tidValid)) {
        HALO_TRACE_FUNCTION(49, "Skipping empty vsm%d\n", vsm);
        return res;
    }

    /* 2) Clear BPT_PAUSE - all the warps need to handle this at the same time. */
    res = dev->halo.writeWarpMaskPRI(dev, vsm, HALO_REG_OP_TYPE_GLOBAL, HALO_MASK_PRI_BPT_PAUSE, &zeroMask);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR( "Failed to clear BPT_PAUSE mask on vsm%d!\n", vsm);
        goto error_single;
    }

    /* 3) Setup preempt command to tell warps what to do when resumed */
    res = dev->halo.setPreemptCommand(dev->activeContext, cmd);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR( "Failed to setup suspend on vsm%d\n", vsm);
        goto error_single;
    }

    /* 3.5) On SAVE, we need to reset the linear allocator before saving so when
       the warps resume to save, they start with a fresh cilp buffer to
       contend for */
    if (cmd == PASCAL_GP10X_PREEMPT_COMMAND_SAVE_ON_PAUSE) {
        /* Reset the warp contention indices */
        res = dev->halo.preemptionBuffer.write_RFDataIdxSync(dev->activeContext->preemptionBufferAccessor, vsm, 0);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to write RF data index!\n");
            goto error_single;
        }
        res = dev->halo.preemptionBuffer.write_shmemDataIdxSync(dev->activeContext->preemptionBufferAccessor, vsm, 0);
        if (res != CUDBG_SUCCESS) {
            HALO_ERROR("Failed to write shmem data index!\n");
            goto error_single;
        }
    }

    /* 4) Clear any exceptions before we try to resume so the exception doesn't
          retrigger when we resume. */
    /* TODO: Change this to only add PAUSE, preserving the other exceptions
             there. This will allow single step nsteps>1 to not interrupt storm. */
    res = dev->halo.clearExceptions(dev, vsm);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR( "Failed to clear exceptions!\n");
        goto error_single;
    }

    /* Flush cpu writes to gpu. */
    cuosStoreFence();

    /* 5) Clear stop trigger / hit run trigger, resuming the warps */
    res = kepler_gk11x_resumeTPC(dev, vsm);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR( "Failed to resume vsm%d\n", vsm);
        goto error_single;
    }

    /* 6) Wait for lockdown - warps will be back at PAUSE */
    res = dev->halo.waitForSMPause(dev, vsm);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR( "Failed to lockdown vsm%d!\n", vsm);
        goto error_single;
    }

    /* 7) Hit stop trigger - lock the SM in place while we service everything */
    res = fermi_suspendTPC(dev, vsm);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Failed to suspend vsm%d!\n", vsm);
        goto error_single;
    }

#ifndef RELEASE
    /* Verify a restore actually worked */
    if (cmd == PASCAL_GP10X_PREEMPT_COMMAND_RESTORE_ON_RESUME) {
        uint32_t rfdatasync = 0, shmemdatasync = 0;
        CUDBG_VERIFY(CUDBG_SUCCESS == dev->halo.preemptionBuffer.read_RFDataIdxSync(dev->activeContext->preemptionBufferAccessor, vsm, &rfdatasync),
            CUDBG_ERROR_INTERNAL, "Failed to read RFDataIdxSync\n");
        CUDBG_VERIFY(CUDBG_SUCCESS == dev->halo.preemptionBuffer.read_shmemDataIdxSync(dev->activeContext->preemptionBufferAccessor, vsm, &shmemdatasync),
            CUDBG_ERROR_INTERNAL, "Failed to read shmemDataIdxSync\n");
        CUDBG_VERIFY(rfdatasync == 0 && shmemdatasync == 0, CUDBG_ERROR_INTERNAL,
            "Failed to fully restore vsm%d! rfdatasync=%#x shmemdatasync=%#x\n",
            vsm, rfdatasync, shmemdatasync);
    }
#endif

error_single:
    /* 8) Clear the preempt command - cleaning up after ourselves and prevents
          the preempt command from executing more than once.  Remember not to hide any errors. */
    res2 = dev->halo.setPreemptCommand(dev->activeContext, PASCAL_GP10X_PREEMPT_COMMAND_NONE);
    if (res2 != CUDBG_SUCCESS) {
        HALO_ERROR( "Failed to clear preemption command on vsm%d\n", vsm);
    }

    /* 9) Make sure to clear the esr info for a future resume, otherwise the sm will re-trap,
       and cause RM to send an event, which will cause us to hit stop trigger, causing a race. */
    res2 = dev->halo.clearSMESRInfo(dev, vsm, &dev->smState[vsm].state, HALO_DEBUG_OBJ_MODE_DEFAULT);
    if (res2 != CUDBG_SUCCESS)
        HALO_ERROR( "failed to clear vsm%d on resume!\n", vsm);

    /* 10) Update the preempt bpmask */
    res = dev->halo.readWarpMaskPRI(dev, vsm, HALO_REG_OP_TYPE_GLOBAL,
                                    HALO_MASK_PRI_BPT_PAUSE, &dev->smState[vsm].state.preempt_bpmask);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Don't hide any previous errors */
    if (res == CUDBG_SUCCESS)
        res = res2;

    return res;
}

/* The following preempt*Hook functions implement the following state machine:
     on init: state = NONE;
     on suspend: sync save buffer, state = CLEAN;
     on modify of buffer: state = DIRTY;
     on resume: restore save buffer to GPU, state = NONE;
 */
static CUDBGResult
pascal_gp10x_preemptPreHook(CudbgDevice dev, int32_t vsm)
{
    CUDBGResult res = CUDBG_SUCCESS;
    int32_t startSM = vsm < 0 ? 0 : vsm;
    int32_t endSM = vsm < 0 ? (int32_t)dev->halo.deviceInfo.numSMs : vsm+1;

    if (dev->activeContext)
        HALO_TRACE_FUNCTION(49, "saveBufferState=%d\n", (int)dev->activeContext->saveBufferState);

    /* Only send the save buffer if it is dirty */
    if (dev->activeContext && dev->activeContext->saveBufferState == HALO_SAVE_BUFFER_STATE_DIRTY) {
        for (vsm = startSM; vsm < endSM; ++vsm) {
            res = pascal_gp10x_syncPreemptionSaveBuffer(dev, (uint32_t)vsm, PASCAL_GP10X_PREEMPT_COMMAND_RESTORE_ON_RESUME);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to save preemption buffer for vsm%d\n", vsm);
        }
    }
    /* Reset to none, so we re-read when we next suspend */
    if (dev->activeContext)
        dev->activeContext->saveBufferState = HALO_SAVE_BUFFER_STATE_NONE;

    return res;
}

static CUDBGResult
pascal_gp10x_preemptPostHook(CudbgDevice dev, int32_t vsm)
{
    CUDBGResult res = CUDBG_SUCCESS;
    int32_t startSM = vsm < 0 ? 0 : vsm;
    int32_t endSM = vsm < 0 ? (int32_t)dev->halo.deviceInfo.numSMs : vsm+1;

    if (dev->activeContext)
        HALO_TRACE_FUNCTION(49, "saveBufferState=%d\n", (int)dev->activeContext->saveBufferState);

    /* Only grab the save buffer is we haven't already */
    if (dev->activeContext && dev->activeContext->saveBufferState == HALO_SAVE_BUFFER_STATE_NONE) {
        for (vsm = startSM; vsm < endSM; ++vsm) {
            res = pascal_gp10x_syncPreemptionSaveBuffer(dev, (uint32_t)vsm, PASCAL_GP10X_PREEMPT_COMMAND_SAVE_ON_PAUSE);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to save preemption buffer for vsm%d\n", vsm);
        }
        /* We now have the save buffer, we don't need to grab it again until the gpu is resumed, so it's CLEAN. */
        dev->activeContext->saveBufferState = HALO_SAVE_BUFFER_STATE_CLEAN;
    }
    return res;
}

CUDBGResult
pascal_gp10x_getInfo(CudbgDevice dev)
{
    CUDBGResult res;
    const CUdev* pDev = globals.devices[dev->deviceIdx];

    res = maxwell_gm10x_getInfo(dev);

    /* Overwrite the constants that are different */
    dev->halo.deviceInfo.maxGPCsPrDevice     = CUDBG_MAX_GPC_PASCAL;
    dev->halo.deviceInfo.smVirtualized       = pDev->state.limits.partitionAsSm;

    dev->halo.deviceInfo.lmemHiMembarWarSpillR2 = PASCAL_LMEM_HI_MEMBAR_WAR_SPILL_R2;
    dev->halo.deviceInfo.lmemHiMembarWarSpillR3 = PASCAL_LMEM_HI_MEMBAR_WAR_SPILL_R3;

    return res;
}

static CUDBGResult
pascal_gp10x_getScratchpadSharedMemDevVaddr(Context context, uint64_t *shmemDevVaddr)
{
    CUDBG_VERIFY(shmemDevVaddr && context, CUDBG_ERROR_INVALID_ARGS, "Invalid args.\n");

    *shmemDevVaddr = context->scratchpadDevVA + PASCAL_GP10X_TRAP_HANDLER_SCRATCHPAD_OFFSET_SHARED;

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_readPauseServicedMask(struct Halo_st *halo, HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, CUwarpBitmask *pauseServicedMask)
{
    CUDBGResult res;
    uint32_t wp;
    uint8_t wpFlag;

    CUDBG_VERIFY(halo && scratchpadAccessor && pauseServicedMask, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    warpBitmaskClear(pauseServicedMask);
    for (wp = 0; wp < halo->deviceInfo.numWarpsPrSM; ++wp) {
        res = halo->scratchpad.read_pauseServicedWarpFlag(scratchpadAccessor, vsm, wp, &wpFlag);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read pause serviced warp flag\n");
        warpBitmaskSetBits(pauseServicedMask, wp, 1, (uint32_t)wpFlag);
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_readSaveWarpMask(struct Halo_st *halo, HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, CUwarpBitmask *saveWarpMask)
{
    CUDBGResult res;
    uint32_t wp;
    uint8_t wpFlag;

    CUDBG_VERIFY(halo && scratchpadAccessor && saveWarpMask, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    warpBitmaskClear(saveWarpMask);
    for (wp = 0; wp < halo->deviceInfo.numWarpsPrSM; ++wp) {
        res = halo->scratchpad.read_validOnSaveWarpFlag(scratchpadAccessor, vsm, wp, &wpFlag);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read valid on save warp flag\n");
        warpBitmaskSetBits(saveWarpMask, wp, 1, (uint32_t)wpFlag);
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_writePauseServicedMask(CudbgDevice dev, bool full_resume, uint32_t vsm)
{
    CUDBGResult res = CUDBG_SUCCESS;
    Context context = dev->activeContext;
    CUwarpBitmask pauseServicedMask, hiddenWarpsMask;
    uint32_t wp;
    uint8_t wpFlag;

    /* It is not an error to not have an active context when this is
       called, however, we cannot attempt to map memory if that's the
       case.  Simply return success here. */
    if (!context || !haloStateContextIsActive(context))
        return CUDBG_SUCCESS;

    if (full_resume) {
        for (vsm = 0; vsm < dev->halo.deviceInfo.numSMs; ++vsm) {

            res = dev->halo.readPauseServicedMask(&dev->halo, context->scratchpadAccessor, vsm, &pauseServicedMask);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read pauseServicedMask on SM:%u\n", vsm);

            HALO_TRACE_FUNCTION(10, "[Full Resume] Updating SM%d's pauseServiceMask "
                                "from " CU_WARP_BIT_MASK_FMT_128_STR
                                "to " CU_WARP_BIT_MASK_FMT_128_STR "\n",
                                vsm,
                                CU_WARP_BIT_MASK_FMT_128_VAL(&pauseServicedMask),
                                CU_WARP_BIT_MASK_FMT_128_VAL(&dev->pauseServicedMask[vsm]));

            warpBitmaskAssign(&pauseServicedMask, &dev->pauseServicedMask[vsm]);
            for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
                wpFlag = (uint8_t)warpBitmaskGetBits(&pauseServicedMask, wp, 1);
                res = dev->halo.scratchpad.write_pauseServicedWarpFlag(context->scratchpadAccessor, vsm, wp, wpFlag);
                CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to write pause serviced warp flag\n");
            }
        }

        if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_CILP) {
            res = dev->dmal->debugObjectSetNextStopTriggerType(dev, context->debugObj, 2);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                         "Failed to set next stop trigger\n");
        }
    }
    else {
        /* Some warps might have been hidden from the user earlier since they were in a syscall.
           When hiding these warps, they would have been masked out from tidValid, but since
           the pauseServicedMask field in the scratchpad had a bit set for each valid warp that
           paused, pauseServicedMask & ~tidValid gives the mask of hidden warps. We must ensure
           that we don't inadvertently resume these hidden warps, as they might exit the traphandler
           and make the SM exit trap mode, causing us to hang waiting for LOCKED_DOWN on Maxwell
           and higher. See bug 1195172. */
        res = dev->halo.readPauseServicedMask(&dev->halo, context->scratchpadAccessor, vsm, &pauseServicedMask);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read pauseServicedMask on SM:%u\n", vsm);

        warpBitmaskNot(&hiddenWarpsMask, &dev->smState[vsm].state.tidValid);
        warpBitmaskAnd(&hiddenWarpsMask, &hiddenWarpsMask, &pauseServicedMask);

        HALO_TRACE_FUNCTION(10, "[SM Resume] Updating SM%d's pauseServiceMask "
                            "from " CU_WARP_BIT_MASK_FMT_128_STR
                            " to (" CU_WARP_BIT_MASK_FMT_128_STR "|" CU_WARP_BIT_MASK_FMT_128_STR ")\n",
                            vsm,
                            CU_WARP_BIT_MASK_FMT_128_VAL(&pauseServicedMask),
                            CU_WARP_BIT_MASK_FMT_128_VAL(&dev->pauseServicedMask[vsm]),
                            CU_WARP_BIT_MASK_FMT_128_VAL(&hiddenWarpsMask));

        warpBitmaskOr(&pauseServicedMask, &hiddenWarpsMask, &dev->pauseServicedMask[vsm]);
        for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
            wpFlag = (uint8_t)warpBitmaskGetBits(&pauseServicedMask, wp, 1);
            res = dev->halo.scratchpad.write_pauseServicedWarpFlag(context->scratchpadAccessor, vsm, wp, wpFlag);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to write pause serviced warp flag\n");
        }

        /* If we're updating the pauseServicedMask, then we also need to update the pause mask.
           These should always be consistent.  Single-GPU debugging exposed this, but it can
           also happen in other cases -- if warps are hopping over a barrier, and we left the
           actual pause mask clear for hidden warps, then those hidden warps will repause (because
           of the updates made to include them in the pauseServicedMask above), which can
           immediately retrap the warps that were trying to make forward progress.  So, keep
           these warps frozen until a full resume occurs. */
        HALO_TRACE_FUNCTION(10, "[SM Resume] Re-updating SM%d's breakpoint mask (bpt_pause_mask)"
                            "to " CU_WARP_BIT_MASK_FMT_128_STR "\n", vsm,
                            CU_WARP_BIT_MASK_FMT_128_VAL(&pauseServicedMask));
        res = dev->halo.writeBreakpointMask(dev, vsm, &pauseServicedMask);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to write breakpoint mask on SM:%u\n", vsm);

        if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_CILP) {
            res = dev->dmal->debugObjectSetNextStopTriggerType(dev, context->debugObj, 2);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                         "Failed to set next stop trigger\n");
        }
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_waitForSMPause(CudbgDevice dev, uint32_t vsm)
{
    CUwarpBitmask tidValid = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;
    uint32_t smStatus;
    uint32_t regOffset = 0;
    uint32_t elapsedTime;
    static const uint32_t timeout        = 5000000; // 5.00 seconds
    static const uint32_t printThreshold = 4990000; // 4.99 seconds => 20 printfs
    static const uint32_t sleepTime      = 500;
    CUDBGResult res = CUDBG_SUCCESS;

    /* Setup addresses */
    res = dev->halo.getPRIOffset(dev, HALO_PRI_SM_DBGR_STATUS0, vsm,
                                 &regOffset);
    if (res != CUDBG_SUCCESS)
        return res;

    /* Wait for this SM to indicate it has entered LOCKED_DOWN */
    for (elapsedTime = 0; elapsedTime < timeout; elapsedTime += sleepTime) {
        res = dev->halo.readWarpMaskPRI(dev, vsm, HALO_REG_OP_TYPE_GLOBAL, HALO_MASK_PRI_WARP_VALID, &tidValid);
        if (res != CUDBG_SUCCESS)
            return res;

        res = dev->haloClient->readReg32(dev, HALO_REG_OP_TYPE_GR_CTX,
                                         (char *)(uintptr_t)regOffset,
                                         &smStatus);
        if (res != CUDBG_SUCCESS)
            return res;

        if (!warpBitmaskAny(&tidValid) ||
            GETFIELD32(smStatus, NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_STATUS0_LOCKED_DOWN))
            break;

        if (elapsedTime > printThreshold) {
            HALO_ERROR("SM %d hasn't LOCKED DOWN investigation: %7u tidValid=" CU_WARP_BIT_MASK_FMT_128_STR " smStatus=%x\n",
                       vsm, elapsedTime, CU_WARP_BIT_MASK_FMT_128_VAL(&tidValid), smStatus);
        }
#if cuosOsIsLinux() || cuosOsIsApple()
        /* Give some time for the device to catch up */
        usleep(sleepTime);
#endif
    }

    if (elapsedTime >= timeout) {
        HALO_ERROR("Timeout when waiting for SM LOCKED_DOWN.\n");
        /* If we couldnt lock down, there is no fallback.
           So complain loudly */
        return CUDBG_ERROR_INTERNAL;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_writeBreakpointMask(CudbgDevice dev, uint32_t vsm, CUwarpBitmask *mask)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CUwarpBitmask *localMask = mask;
    CUwarpBitmask emptyMask = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;

    /* Snoop writes to the pause mask.  As this is the mask used
       to indicate which warps will be resumed, it by definition
       means this is also the mask for warps that have already
       been serviced by the debugger. */
    warpBitmaskAssign(&dev->pauseServicedMask[vsm], mask);
    
    if (dev->halo.deviceInfo.preemptionType == HALO_PREEMPTION_TYPE_CILP) {
        HALO_TRACE_FUNCTION(50, "Running CILP, Skipping write to BPT_PAUSE_MASK\n");
        return CUDBG_SUCCESS;
    }

    /* For gp10x's traphandler, we use BAR.SYNCALL to broadcast the state of
       each warp across the CTA. For this to work, every warp in the CTA needs
       to wake up, not just the warps on breakpoints. */
    HALO_TRACE_FUNCTION(50, "Converting mask from " CU_WARP_BIT_MASK_FMT_128_STR
                        " -> " CU_WARP_BIT_MASK_FMT_128_STR "\n",
                        CU_WARP_BIT_MASK_FMT_128_VAL(localMask),
                        CU_WARP_BIT_MASK_FMT_128_VAL(&emptyMask));
    localMask = &emptyMask;

    /* Write the bpmask (pause mask) */
    res = dev->halo.writeWarpMaskPRI(dev, vsm, HALO_REG_OP_TYPE_GLOBAL, HALO_MASK_PRI_BPT_PAUSE, localMask);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to write BPT_PAUSE_MASK_0\n");
    return res;
}

static CUDBGResult
pascal_gp10x_singleStepExit(CudbgDevice dev, uint32_t vsm, uint32_t wp)
{
    HALO_ERROR("This should never be called!!. GP10x does not need exit step\n");
    return CUDBG_ERROR_INTERNAL;
}

static CUDBGResult
pascal_gp10x_getRegisterCount(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t *numRegsUsedByKernel)
{
    CUDBGResult res;
    Context ctx;
    Grid grid;

    CUDBG_VERIFY(dev && numRegsUsedByKernel, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    ctx = dev->activeContext;
    CUDBG_VERIFY(ctx, CUDBG_ERROR_INVALID_CONTEXT, "Invalid context\n");

    /* Grab the maximum number of registers */
    grid = haloStateDeviceGetGrid(dev, dev->smState[vsm].warp[wp].gridId64);
    CUDBG_VERIFY(grid && grid->function, CUDBG_ERROR_INTERNAL,
                 "Couldn't find grid 0x%" PRIx64 "\n", dev->smState[vsm].warp[wp].gridId64);

    res = dev->halo.getNumRegistersForGrid(ctx, grid, numRegsUsedByKernel);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to get the number of registers used for vsm%d/wp%d\n", vsm, wp);

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_readRegisterRange(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                               uint32_t firstRegnum, uint32_t *registers, uint32_t numRegs,
                               bool rawSpValue) {
    CUDBGResult res;
    Context context = dev->activeContext;
    uint32_t regnum, numRegsUsedByKernel, numRegOffsets;
    uint32_t i;
    bool inSyscall = false;
    uint32_t spval = 0;

    /* Note: in this function we're reusing `registers` for reg offsets
       to avoid allocating a new array to store them. */

    CUDBG_VERIFY((context && context->memMapActive), CUDBG_ERROR_INVALID_CONTEXT,
                 "Invalid context in readRegisterRange.\n");

    /* Grab the maximum number of registers */
    res = dev->halo.getRegisterCount(dev, vsm, wp, &numRegsUsedByKernel);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to get the number of registers used for vsm%d/wp%d\n", vsm, wp);

    numRegOffsets = numRegsUsedByKernel ? MIN(numRegs, numRegsUsedByKernel - firstRegnum) : numRegs;
    res = dev->halo.preemptionBuffer.getRegOffsets(&dev->halo, context->preemptionBufferAccessor,
                                                   vsm, wp, ln, firstRegnum, numRegsUsedByKernel,
                                                   numRegOffsets, registers);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                 "Failed to get reg offsets sm%u/wp%u/ln%u\n", vsm, wp, ln);

    for (i = 0; i < numRegs; i++) {
        regnum = firstRegnum + i;
        if (numRegsUsedByKernel && regnum >= numRegsUsedByKernel) {
            HALO_TRACE_FUNCTION(50, "Returning zero for reg %d\n", regnum);
            registers[i] = 0;
            continue;
        }

        /* Special handling for syscalls.
           If this lane is stopped in a syscall patch, then we will intercept reads
           to R1 (the stack pointer) */
        if (!rawSpValue &&
            dev->haloClient->state.overrideInSyscallSPValue &&
            (regnum == dev->halo.deviceInfo.spRegisterNumber)) {
            res = dev->halo.findSyscallSP(dev, vsm, wp, ln, &inSyscall, &spval);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read syscall stack pointer\n");

            if (inSyscall) {
                HALO_TRACE_FUNCTION(1, "Reading stack pointer inside syscall. Returning : 0x%x\n", spval);
                registers[i] = spval;
                continue;
            }
        }

        res = dev->halo.readDeviceMemory(context, context->cilpBufferDevVA + registers[i],
                                         &registers[i], (uint32_t)sizeof(*registers));
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to read reg. sm%u/wp%u/ln%u/reg%u\n", vsm, wp, ln, regnum);
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_writeRegisterFile(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                               uint64_t offset, const void *buf, uint32_t bufSz)
{
    uint32_t *wbuf = (uint32_t *) buf;
    uint32_t offset32 = (uint32_t) offset;
    uint32_t regnum, numRegsUsedByKernel, regVal;
    Context context = dev->activeContext;
    CUDBGResult res;
    uint32_t regOffset;
    Grid grid;

    CUDBG_VERIFY((context && context->memMapActive), CUDBG_ERROR_INVALID_CONTEXT,
                 "Invalid context in writeRegisterFile.\n");

    CUDBG_VERIFY(((uint64_t) offset32 == offset && !((offset32 | bufSz) & 3)),
                 CUDBG_ERROR_INVALID_MEMORY_ACCESS,
                 "Invalid memory access in writeRegisterFile.\n");

    regnum = offset32 / 4;

    /* Grab the maximum number of registers */
    grid = haloStateDeviceGetGrid(dev, dev->smState[vsm].warp[wp].gridId64);
    if (!grid || !grid->function) {
        HALO_ERROR("Couldn't find grid 0x%" PRIx64 "\n", dev->smState[vsm].warp[wp].gridId64);
        return CUDBG_ERROR_INTERNAL;
    }

    numRegsUsedByKernel = grid->function->nrofRegisters;

    for (;bufSz; regnum++, bufSz -= 4) {
        if (numRegsUsedByKernel && (regnum >= numRegsUsedByKernel)) {
            HALO_TRACE_FUNCTION(50, "Returning zero for reg %d\n", regnum);
            *wbuf++ = 0;
            continue;
        }

        res = dev->halo.preemptionBuffer.getRegOffset(&dev->halo, context->preemptionBufferAccessor,
                                                      vsm, wp, ln, regnum, numRegsUsedByKernel, &regOffset);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to get reg offset. sm%u/wp%u/ln%u/reg%u\n",
                     vsm, wp, ln, regnum);

        memcpy(&regVal, wbuf, sizeof(regVal));

        res = dev->halo.writeDeviceMemory(context,
                                          context->cilpBufferDevVA + regOffset,
                                          &regVal,
                                          (uint32_t)sizeof(regVal));
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res,
                     "Failed to write reg. sm%u/wp%u/ln%u/reg%u\n",
                    vsm, wp, ln, regnum);
        wbuf++;
    }

    dev->activeContext->saveBufferState = HALO_SAVE_BUFFER_STATE_DIRTY;

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_getShmemOffset(Context context, uint32_t sm, uint32_t cta, uint32_t addr, uint32_t *pShmemOffset)
{
    CUDBGResult res;
    size_t smShmemDataOffset, smShmemDataSize;
    uint32_t ctaShmemOffByte;

    /*  The preemption save buffer lookup happens using the per cta data
     */

    /* Read the CTA's shared memory offset from the CTA section */
    res = context->dev->halo.preemptionBuffer.read_shmemDataIdx(context->preemptionBufferAccessor, sm, cta, &ctaShmemOffByte);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get shmem data index\n");

    /* Compute the base address for the entire CTA's shared memory */
    res = context->dev->halo.preemptionBuffer.getFieldOffset(HALO_PREEMPTION_BUFFER_FIELD_SHMEMDATA,
                                           HALO_PREEMPTION_BUFFER_SECTION_SM,
                                           sm, cta, 0, 0,
                                           &smShmemDataOffset,
                                           &smShmemDataSize);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get RFData offset\n");

    *pShmemOffset = (uint32_t)(smShmemDataOffset + ctaShmemOffByte + addr);

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_readSharedMemory(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                              uint64_t offset, void *buf, uint32_t bufSz)
{
    uint64_t devVaddr = 0;
    uint32_t addr = (uint32_t) offset;
    uint32_t shmemSize = dev->smState[vsm].warp[wp].CTASharedSize;
    uint32_t shmemOffset = 0;
    CUDBGResult res = CUDBG_SUCCESS;
    Context context;

    CUDBG_VERIFY(((uint64_t) addr == offset), CUDBG_ERROR_INVALID_MEMORY_ACCESS, "Invalid memory access.\n");

    CUDBG_VERIFY((shmemSize >= addr + bufSz), CUDBG_ERROR_INVALID_MEMORY_ACCESS, "Invalid memory access.\n");

    CUDBG_VERIFY(dev->activeContext, CUDBG_ERROR_INVALID_CONTEXT, "No active context found\n");

    context = dev->activeContext;

    res = pascal_gp10x_getShmemOffset(context, vsm, dev->smState[vsm].warp[wp].virtCTAID,
                                      addr, &shmemOffset);

    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get shmem offset\n");

    devVaddr = context->cilpBufferDevVA + shmemOffset;

    res = dev->halo.readDeviceMemory(dev->activeContext, devVaddr, buf, bufSz);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to readDeviceMemory failed (res=%d).\n", res);
        return res;
    }

    return res;
}

static CUDBGResult
pascal_gp10x_writeSharedMemory(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                               uint64_t offset, const void *buf, uint32_t bufSz)
{
    uint64_t devVaddr = 0;
    uint32_t addr = (uint32_t) offset;
    uint32_t shmemSize = dev->smState[vsm].warp[wp].CTASharedSize;
    uint32_t shmemOffset = 0;
    CUDBGResult res;
    Context context;

    CUDBG_VERIFY(((uint64_t) addr == offset), CUDBG_ERROR_INVALID_MEMORY_ACCESS, "Invalid memory access.\n");

    CUDBG_VERIFY((shmemSize >= addr + bufSz), CUDBG_ERROR_INVALID_MEMORY_ACCESS, "Invalid memory access.\n");

    context = dev->activeContext;

    res = pascal_gp10x_getShmemOffset(context, vsm, dev->smState[vsm].warp[wp].virtCTAID,
                         addr, &shmemOffset);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get shmem offset\n");

    devVaddr = context->cilpBufferDevVA + shmemOffset;

    res = dev->halo.writeDeviceMemory(dev->activeContext, devVaddr, buf, bufSz);
    if (res != CUDBG_SUCCESS) {
        HALO_ERROR("Call to writeDeviceMemory failed (res=%d).\n", res);
        return res;
    }

    dev->activeContext->saveBufferState = HALO_SAVE_BUFFER_STATE_DIRTY;

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_readPredicates(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                     uint32_t numPreds, uint32_t *predicates)
{
    CUDBGResult res;
    uint32_t i;
    uint8_t predicateReg = 0;

    CUDBG_VERIFY(predicates, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args in pascal_gp10x_readPredicates\n");
    CUDBG_VERIFY(numPreds <= PASCAL_NUM_PREDICATES, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid # of predicates\n");

    /* Read predicate register contents */
    res = dev->halo.preemptionBuffer.read_PR(dev->activeContext->preemptionBufferAccessor, vsm, wp, ln, &predicateReg);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read PR\n");

    /* Predicates are backed in the LSBs of PR */
    for (i = 0; i < numPreds; i++) {
        predicates[i] = (predicateReg >> i) & 1U;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_readCCRegister(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                     uint32_t *cc)
{
    CUDBGResult res;
    uint8_t ccReg = 0;
    CUDBG_VERIFY(cc, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args in pascal_gp10x_readCCRegister\n");

    /* Read CC register  */
    res = dev->halo.preemptionBuffer.read_CC(dev->activeContext->preemptionBufferAccessor, vsm, wp, ln, &ccReg);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read PR\n");

    *cc = (uint32_t)ccReg;

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_writePredicates(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                      uint32_t numPreds, const uint32_t *predicates)
{
    CUDBGResult res;
    uint32_t i;
    uint8_t predicateReg = 0;

    CUDBG_VERIFY(predicates, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid args in pascal_gp10x_readPredicates\n");
    CUDBG_VERIFY(numPreds <= PASCAL_NUM_PREDICATES, CUDBG_ERROR_INVALID_ARGS,
                 "Invalid # of predicates\n");

    /* Read predicate register contents */
    res = dev->halo.preemptionBuffer.read_PR(dev->activeContext->preemptionBufferAccessor, vsm, wp, ln, &predicateReg);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read PR\n");

    /* Modify predicate register based on inputs */
    for (i = 0; i < numPreds; i++) {
        CUDBG_VERIFY(predicates[i] < 2, CUDBG_ERROR_INVALID_ARGS, "Invalid predicate value\n");
        predicateReg = (predicateReg & ~(1U << i)) | (predicates[i] << i);
    }

    /* Write updated predicate register back to backing store */
    res = dev->halo.preemptionBuffer.write_PR(dev->activeContext->preemptionBufferAccessor, vsm, wp, ln, predicateReg);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to write PR\n");

    dev->activeContext->saveBufferState = HALO_SAVE_BUFFER_STATE_DIRTY;

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_writeCCRegister(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t ln,
                      const uint32_t cc)
{
    CUDBGResult res;

    /* Write CC register  */
    res = dev->halo.preemptionBuffer.write_CC(dev->activeContext->preemptionBufferAccessor, vsm, wp, ln, *((uint8_t *)&cc));
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to write CC\n");

    dev->activeContext->saveBufferState = HALO_SAVE_BUFFER_STATE_DIRTY;

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_readTextureMemory(CudbgDevice dev, uint32_t vsm, uint32_t wp,
                               uint32_t texId, uint32_t dim, uint32_t *coords,
                               void *buf, uint32_t bufSz)
{
    /* Default (fermi) implementation checks if KILP/CILP is enabled, otherwise
       uses the thService ABI for reading textures.  Pascal doesn't implement
       this in its traphandler -- instead, it provides the TexHeader method
       regardless of preemption or not, so just use that always. */
    return dev->halo.readTextureMemoryUsingTexHeader(dev, vsm, wp, texId, dim,
                                                     coords, buf, bufSz);
}

static CUDBGResult
pascal_gp10x_convertPhysicalToVirtual(Halo_st *halo, uint32_t tpc, uint32_t phys_wp, uint32_t cta_id, uint32_t* vsm, uint32_t* vwp, uint32_t* vcta_id)
{
    uint32_t pid = (phys_wp & ~(PASCAL_WARP_ID_MASK_HI | PASCAL_WARP_ID_MASK_LO)) >> PASCAL_WARP_PART_SHIFT;

    if (!halo->deviceInfo.smVirtualized)
        return fermi_convertPhysicalToVirtual(halo, tpc, phys_wp, cta_id, vsm, vwp, vcta_id);

    if (vsm)
        *vsm = tpc * halo->deviceInfo.numSMsPrTPC + pid;
    if (vwp)
        *vwp = PASCAL_GP10X_WARP_TPC2SM_ID(phys_wp);
    if (vcta_id)
        *vcta_id = cta_id & PASCAL_GP10X_CTAID_MASK;

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_convertVirtualToPhysical(Halo_st *halo, uint32_t vsm, uint32_t vwp, uint32_t vcta_id, uint32_t* tpc, uint32_t* phys_wp, uint32_t* cta_id)
{
    uint32_t pid = vsm % halo->deviceInfo.numSMsPrTPC;

    if (!halo->deviceInfo.smVirtualized)
        return fermi_convertVirtualToPhysical(halo, vsm, vwp, vcta_id, tpc, phys_wp, cta_id);

    if (tpc)
        *tpc = vsm / halo->deviceInfo.numSMsPrTPC;
    if (phys_wp)
        *phys_wp = PASCAL_GP10X_WARP_SM2TPC_ID(vwp, pid);
    if (cta_id)
        *cta_id = (pid << PASCAL_GP10X_CTA_PART_BIT) | vcta_id;

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_virtualMaskToPhysicalMask(CudbgDevice dev, uint32_t vsm, CUwarpBitmask *src, CUwarpBitmask *dst)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t wp = 0, pwp = 0;
    warpBitmaskClear(dst);
    for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
        res = dev->halo.convertVirtualToPhysical(&dev->halo, vsm, wp, 0, NULL, &pwp, NULL);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get physical warp id for vsm%d/wp%d\n", vsm, wp);

        warpBitmaskSetBits(dst, pwp, 1, warpBitmaskGetBits(src, wp, 1));
    }
    return res;
}

/* A reasonable person might ask why this isnt just a codepath in pascal_gp10x_readSMState,
 * i.e. have pascal_gp10x_readSMState read the extra bits from *_MASK_2, when dev->numWarps > 64
 * The reason here is that we need the PRI offsets for MASK_2 got changed on GP100.
 * Here are the GF100 offsets
 *  for BPT_PAUSE_MASK, BPT_TRAP_MASK, WARP_VALID_MASK
 *  Notice how BPT_PAUSE_MASK_2, BPT_TRAP_MASK_2 are at *different* offsets
 * GF100:
    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_WARP_VALID_MASK_0                      0x00504614
    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_WARP_VALID_MASK_1                      0x00504618
    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_WARP_VALID_MASK_2                      0x0050461c
    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_WARP_VALID_MASK_3                      0x00504620
    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_PAUSE_MASK_0                       0x00504624
    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_PAUSE_MASK_1                       0x00504628
    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_PAUSE_MASK_2                       0x0050462c
    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_PAUSE_MASK_3                       0x00504630
    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_TRAP_MASK_0                        0x00504634
    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_TRAP_MASK_1                        0x00504638
    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_TRAP_MASK_2                        0x0050463c
    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_TRAP_MASK_3                        0x00504640

   GP100 :

    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_WARP_VALID_MASK_0                      0x00504614
    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_WARP_VALID_MASK_1                      0x00504618
    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_WARP_VALID_MASK_2                      0x0050461c
    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_WARP_VALID_MASK_3                      0x00504620
    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_PAUSE_MASK_0                       0x00504624
    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_PAUSE_MASK_1                       0x00504628
    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_PAUSE_MASK_2                       0x00504750
    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_PAUSE_MASK_3                       0x00504754
    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_TRAP_MASK_0                        0x00504634
    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_TRAP_MASK_1                        0x00504638
    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_TRAP_MASK_2                        0x00504758
    NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_TRAP_MASK_3                        0x0050475c
 * */
static CUDBGResult
pascal_gp10x_getWarpMaskPRIOffset(CudbgDevice dev, HaloMaskPRI pri, uint32_t wordIndex, uint32_t *reg)
{
    CUDBG_VERIFY(wordIndex < 4, CUDBG_ERROR_INVALID_ARGS, "Invalid offset\n");
    switch (pri) {
    case HALO_MASK_PRI_WARP_VALID:
        switch (wordIndex) {
        case 0:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_WARP_VALID_MASK_0;
            break;
        case 1:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_WARP_VALID_MASK_1;
            break;
        case 2:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_WARP_VALID_MASK_2;
            break;
        case 3:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_WARP_VALID_MASK_3;
            break;
        }
        break;
    case HALO_MASK_PRI_BPT_PAUSE:
        switch (wordIndex) {
        case 0:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_PAUSE_MASK_0;
            break;
        case 1:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_PAUSE_MASK_1;
            break;
        case 2:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_PAUSE_MASK_2;
            break;
        case 3:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_PAUSE_MASK_3;
            break;
        }
        break;
    case HALO_MASK_PRI_BPT_TRAP:
        switch (wordIndex) {
        case 0:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_TRAP_MASK_0;
            break;
        case 1:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_TRAP_MASK_1;
            break;
        case 2:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_TRAP_MASK_2;
            break;
        case 3:
            *reg = NV_PGRAPH_PRI_GPC0_TPC0_SM_DBGR_BPT_TRAP_MASK_3;
            break;
        }
        break;
    default:
        HALO_ERROR("Invalid requested PRI\n");
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_physicalMaskToVirtualMask(CudbgDevice dev, uint32_t vsm, CUwarpBitmask *src, CUwarpBitmask *dst)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t wp = 0, pwp = 0;
    warpBitmaskClear(dst);
    for (wp = 0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
        res = dev->halo.convertVirtualToPhysical(&dev->halo, vsm, wp, 0, NULL, &pwp, NULL);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get physical warp id for vsm%d/wp%d\n", vsm, wp);

        warpBitmaskSetBits(dst, wp, 1, warpBitmaskGetBits(src, pwp, 1));
    }
    return res;
}

/* This grabs the saved pri physical mask for the given tpc. */
static CUDBGResult
pascal_gp10x_setPreemptVirtualMask(CudbgDevice dev, uint32_t vsm, HaloMaskPRI pri, CUwarpBitmask *mask)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CUwarpBitmask *smMask;

    switch (pri) {
    case HALO_MASK_PRI_BPT_PAUSE:
        smMask = &dev->smState[vsm].state.preempt_bpmask;
        break;
    default:
        return CUDBG_ERROR_INVALID_ARGS;
    }

    warpBitmaskAssign(smMask, mask);

    return res;
}

/* This grabs the saved pri physical mask for the given tpc. */
static CUDBGResult
pascal_gp10x_getPreemptPhysicalMask(CudbgDevice dev, uint32_t tpc, HaloMaskPRI pri, CUwarpBitmask *mask)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t sm;
    CUwarpBitmask physMask;
    CUwarpBitmask *smMask;

    CUDBG_VERIFY(dev->halo.deviceInfo.smVirtualized, CUDBG_ERROR_INVALID_ARGS, "Invalid args - device is not sm virtualized\n");

    /* Reconstruct the tpc's physical mask */
    for (sm = 0; sm < dev->halo.deviceInfo.numSMsPrTPC; ++sm) {
        switch (pri) {
        case HALO_MASK_PRI_BPT_PAUSE:
            smMask = &dev->smState[tpc*dev->halo.deviceInfo.numSMsPrTPC+sm].state.preempt_bpmask;
            break;
        default:
            return CUDBG_ERROR_INVALID_ARGS;
        }

        res = pascal_gp10x_virtualMaskToPhysicalMask(dev, tpc*dev->halo.deviceInfo.numSMsPrTPC+sm, smMask, &physMask);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to convert vsm%d's preempt_bpmask\n", tpc+sm);
        HALO_TRACE_FUNCTION(50, "vsm%d: physical=" CU_WARP_BIT_MASK_FMT_128_STR " mask=" CU_WARP_BIT_MASK_FMT_128_STR "\n",
                            tpc*dev->halo.deviceInfo.numSMsPrTPC+sm, CU_WARP_BIT_MASK_FMT_128_VAL(&physMask), CU_WARP_BIT_MASK_FMT_128_VAL(smMask));
        /* Add in the sm's mask */
        warpBitmaskOr(mask, mask, &physMask);
    }
    
    return res;
}

/* Note: we do not have a writeWarpMaskPRI that converts the virtual mask to a
   physical one.  This is because the only PRI mask we would do this with is
   BPT_PAUSE_MASK, which doesn't follow the usual conventions allowing for a RMW
   version of this.  See pascal_gp10x_syncPreemptSaveBuffer for more information
   and a WAR */
static CUDBGResult
pascal_gp10x_writeWarpMaskPRI(CudbgDevice dev, uint32_t vsm, HaloRegOpType type, HaloMaskPRI pri, CUwarpBitmask *mask)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t tpc = 0, wp, pwp=0;
    CUwarpBitmask physMask = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;

    CUDBG_VERIFY(dev && mask, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    if (dev->halo.deviceInfo.smVirtualized) {
        /* Get this sm's tpc */
        res = dev->halo.convertVirtualToPhysical(&dev->halo, vsm, 0, 0, &tpc, NULL, NULL);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to RMW pri=%d\n", pri);

        /* Read the original physical PRI for the tpc */
        res = pascal_gp10x_getPreemptPhysicalMask(dev, tpc, pri, &physMask);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to RMW pri=%d\n", pri);

        HALO_TRACE_FUNCTION(50, "RMW mask(pri=%d) on vsm%d(tpc%d): physical=" CU_WARP_BIT_MASK_FMT_128_STR " mask=" CU_WARP_BIT_MASK_FMT_128_STR "\n",
                        pri, vsm, tpc, CU_WARP_BIT_MASK_FMT_128_VAL(&physMask), CU_WARP_BIT_MASK_FMT_128_VAL(mask));

        for(wp=0; wp < dev->halo.deviceInfo.numWarpsPrSM; ++wp) {
            res = dev->halo.convertVirtualToPhysical(&dev->halo, vsm, wp, 0, NULL, &pwp, NULL);
            CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to convert vsm%d/wp%d -> pwp\n", vsm, wp);
            warpBitmaskSetBits(&physMask, pwp, 1, warpBitmaskGetBits(mask, wp, 1));
        }

        res = pascal_gp10x_setPreemptVirtualMask(dev, vsm, pri, mask);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to set preempt virtual mask for vsm%d\n", vsm);
    }
    else
        /* No virtualization, no RMW needed */
        warpBitmaskAssign(&physMask, mask);

    HALO_TRACE_FUNCTION(50, "Write mask(pri=%d) on vsm%d: physical=" CU_WARP_BIT_MASK_FMT_128_STR " mask=" CU_WARP_BIT_MASK_FMT_128_STR "\n",
                        pri, vsm, CU_WARP_BIT_MASK_FMT_128_VAL(&physMask), CU_WARP_BIT_MASK_FMT_128_VAL(mask));

    res = fermi_writeWarpMaskPRI(dev, vsm, type, pri, &physMask);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to write pri=%d\n", pri);

    return res;
}

/* Note: we do not have a writeWarpMaskPRI that converts the virtual mask to a
   physical one.  This is because the only PRI mask we would do this with is
   BPT_PAUSE_MASK, which doesn't follow the usual conventions allowing for a RMW
   version of this.  See pascal_gp10x_syncPreemptSaveBuffer for more information
   and a WAR */
static CUDBGResult
pascal_gp10x_readWarpMaskPRI(CudbgDevice dev, uint32_t vsm, HaloRegOpType type, HaloMaskPRI pri, CUwarpBitmask *mask)
{
    CUDBGResult res = CUDBG_SUCCESS;
    CUwarpBitmask physMask = CU_WARP_BIT_MASK_STATIC_INIT_CLEAR;

    CUDBG_VERIFY(dev && mask, CUDBG_ERROR_INVALID_ARGS, "Invalid args\n");

    res = fermi_readWarpMaskPRI(dev, vsm, type, pri, &physMask);
    if (res != CUDBG_SUCCESS)
        return res;

    if (dev->halo.deviceInfo.smVirtualized) {
        res = pascal_gp10x_physicalMaskToVirtualMask(dev, vsm, &physMask, mask);
        if (res != CUDBG_SUCCESS)
            return res;
    }
    else
        warpBitmaskAssign(mask, &physMask);

    HALO_TRACE_FUNCTION(50, "Read mask(pri=%d) on vsm%d: physical=" CU_WARP_BIT_MASK_FMT_128_STR " mask=" CU_WARP_BIT_MASK_FMT_128_STR "\n",
                        pri, vsm, CU_WARP_BIT_MASK_FMT_128_VAL(&physMask), CU_WARP_BIT_MASK_FMT_128_VAL(mask));

    return res;
}

static CUDBGResult
pascal_gp10x_readSMESRInfo(CudbgDevice dev, uint32_t vsm, CudbgSMState_t *state,
                    HaloDebugObjMode_t debugObjMode)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t tpc = 0;

    res = dev->halo.convertVirtualToPhysical(&dev->halo, vsm, 0, 0, &tpc, NULL, NULL);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to map vsm%d -> tpc\n", vsm);

    return fermi_readSMESRInfo(dev, tpc, state, debugObjMode);
}

static CUDBGResult
pascal_gp10x_readSMWarpESRInfo(CudbgDevice dev, uint32_t vsm, CudbgSMState_t *state)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t tpc = 0, vsm_wp = 0;
    res = maxwell_gm10x_readSMWarpESRInfo(dev, vsm, state);
    if (res != CUDBG_SUCCESS)
        return res;
    
    if (state->esrWarpInfoValid &&
        dev->halo.deviceInfo.smVirtualized) {
        res = dev->halo.convertVirtualToPhysical(&dev->halo, vsm, 0, 0, &tpc, NULL, NULL);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to convert vsm%d to tpc\n", vsm);

        res = dev->halo.convertPhysicalToVirtual(&dev->halo, tpc, state->esrWarpId, 0, &vsm_wp, &state->esrWarpId, NULL);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to convert esrWarpId %#x for vsm%d(tpc%d)\n", state->esrWarpId, vsm, tpc);

        if (vsm_wp != vsm) {
            HALO_TRACE_FUNCTION(49, "esrWarpId(%d) is for a warp on a different"
                                " vsm (%d!=%d), invalidate warp esr info\n",
                                state->esrWarpId, vsm_wp, vsm);

            state->esrWarpInfoValid = false;
            state->esrWarpId = 0;
            state->esrWarpPC = 0;
        }
    }

    return res;
}

static CUDBGResult
pascal_gp10x_clearSMESRInfo(CudbgDevice dev, uint32_t vsm, CudbgSMState_t *state,
                     HaloDebugObjMode_t debugObjMode)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t tpc = 0;

    res = dev->halo.convertVirtualToPhysical(&dev->halo, vsm, 0, 0, &tpc, NULL, NULL);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to map vsm%d -> tpc\n", vsm);

    return fermi_clearSMESRInfo(dev, tpc, state, debugObjMode);
}

static CUDBGResult
pascal_gp10x_invalidateSMState(CudbgDevice dev, uint32_t vsm)
{
    CUDBGResult res = CUDBG_SUCCESS;
    uint32_t tpc = 0, sm = 0;

    res = dev->halo.convertVirtualToPhysical(&dev->halo, vsm, 0, 0, &tpc, NULL, NULL);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to map vsm%d to tpc\n", vsm);

    /* Invalidate all vsm's on the tpc, as they all have been resumed and their
    state may have changed. */
    for (sm = 0; sm < dev->halo.deviceInfo.numSMsPrTPC; ++sm) {
        dev->smState[tpc * dev->halo.deviceInfo.numSMsPrTPC + sm].valid = 0;
        dev->smState[tpc * dev->halo.deviceInfo.numSMsPrTPC + sm].state.floorsweptSmIdValid = 0;
    }

    return res;
}

static inline CUDBGResult
pascal_gp10x_forceScratchpadLmemBase(CudbgDevice dev, bool *useScratchpad)
{
    /* For GP100+, lmembase is always saved to the scratchpad, so use it
       instead of trying to computing it */
    *useScratchpad = true;
    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_read_warpParams(CudbgDevice dev,
                             uint32_t vsm,
                             uint32_t wp,
                             uint32_t valid,
                             uint32_t *virtCTAID,
                             uint32_t *CTASharedSize,
                             uint32_t *floorsweptSmId)
{
    CUDBGResult res = CUDBG_SUCCESS;
    res = kepler_gk10x_read_warpParams(dev, vsm, wp, valid, virtCTAID,
                                       CTASharedSize, floorsweptSmId);
    if (res != CUDBG_SUCCESS)
        return res;

    if (virtCTAID &&
        dev->halo.deviceInfo.smVirtualized) {
        res = dev->halo.convertPhysicalToVirtual(&dev->halo, vsm, wp, *virtCTAID, NULL, NULL, virtCTAID);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to convert VIRT_ID to vCTAID\n");
    }

    return res;
}

static CUDBGResult
pascal_gp10x_getPauseReasonTableWarpOffset(CudbgDevice dev, uint32_t vsm, uint32_t wp, uint32_t* offset)
{
    CUDBG_VERIFY(offset && dev, CUDBG_ERROR_INVALID_ARGS, "\n");
    *offset = (CUDBG_MAX_WARP_PASCAL * vsm + wp) * sizeof(uint32_t);
    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_getTexDptrMask(CudbgDevice dev, uint64_t *mask)
{
    *mask = (1ULL << 48) - 1ULL;
    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_mcinterop_getRegSpill(CudbgDevice dev, uint32_t *numSpilled)
{
    if (numSpilled)
        *numSpilled = 16; // number of registers spilled to lmem

    return CUDBG_SUCCESS;
}

/* Scrachpad access */

static CUDBGResult
pascal_gp10x_scratchpad_getGlobalFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_SCRATCHPAD_GET_OFFSET_CASE(ACTIVE, PascalScratchpad_t, active);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PREEMPT_COMMAND, PascalScratchpad_t, preemptCommand);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PADDING, PascalScratchpad_t, padding);
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_scratchpad_getWarpFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_SCRATCHPAD_GET_OFFSET_CASE(VIRT_ID, PascalWarpScratchpad_t, virtID);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(CTA_PARAM, PascalWarpScratchpad_t, ctaParam);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_IDX_X, PascalWarpScratchpad_t, blockIdxX);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_IDX_Y, PascalWarpScratchpad_t, blockIdxY);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_IDX_Z, PascalWarpScratchpad_t, blockIdxZ);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_DIM_X, PascalWarpScratchpad_t, blockDimX);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_DIM_Y, PascalWarpScratchpad_t, blockDimY);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(BLOCK_DIM_Z, PascalWarpScratchpad_t, blockDimZ);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_ID_64_LO, PascalWarpScratchpad_t, gridId64Lo);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_DIM_X, PascalWarpScratchpad_t, gridDimX);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_DIM_Y, PascalWarpScratchpad_t, gridDimY);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_DIM_Z, PascalWarpScratchpad_t, gridDimZ);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SHMEM_SIZE_PR_BLOCK, PascalWarpScratchpad_t, shmemSizePrBlock);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_WINDOW_SIZE, PascalWarpScratchpad_t, lmemWindowSize);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_LO_SIZE_PR_THREAD, PascalWarpScratchpad_t, lmemLoSizePrThread);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_HI_OFF, PascalWarpScratchpad_t, lmemHiOff);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GLOBAL_ERROR_STATUS, PascalWarpScratchpad_t, globalErrorStatus);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_ERROR_STATUS, PascalWarpScratchpad_t, warpErrorStatus);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_BARRIER_STATE, PascalWarpScratchpad_t, warpBarrierState);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SELF_QMD_LO, PascalWarpScratchpad_t, selfQMDLo);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SELF_QMD_HI, PascalWarpScratchpad_t, selfQMDHi);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PARAM_CONST_DPTR_LO, PascalWarpScratchpad_t, paramConstDptrLo);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(PARAM_CONST_DPTR_HI, PascalWarpScratchpad_t, paramConstDptrHi);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(CIR_QUEUE_INCR_MINUS_ONE, PascalWarpScratchpad_t, cirQueueIncrMinusOne);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_BASE_LO, PascalWarpScratchpad_t, lmemBaseLo);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(LMEM_BASE_HI, PascalWarpScratchpad_t, lmemBaseHi);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(CRS_PTR, PascalWarpScratchpad_t, crsPtr);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(GRID_ID_64_HI, PascalWarpScratchpad_t, gridId64Hi);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(MPS_CONTEXT_ID, PascalWarpScratchpad_t, mpsContextId);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(SINGLESTEP_NSTEPS, PascalWarpScratchpad_t, singleStepNsteps);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_FLAG_VALID_ON_SAVE, PascalWarpScratchpad_t, warpFlagsValidOnSave);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(WARP_FLAG_PAUSE_SERVICED, PascalWarpScratchpad_t, warpFlagsPauseServiced);
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_scratchpad_getLaneFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_SCRATCHPAD_GET_OFFSET_CASE(THREAD_IDX, PascalLaneScratchpad_t, threadIdx);
        HALO_SCRATCHPAD_GET_OFFSET_CASE(R1, PascalLaneScratchpad_t, r1);
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_scratchpad_getSmFieldOffset(HaloScratchpadField field, size_t *offset, size_t *width)
{
    switch (field) {
    default:
        HALO_TRACE_FUNCTION(0, "Invalid field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_scratchpad_getFieldOffset(HaloScratchpadField field, HaloScratchpadSection section,
    uint32_t sm, uint32_t wp, uint32_t ln, size_t *offset, size_t *width)
{
    size_t base = 0;
    CUDBGResult res;

    switch (section) {
    case HALO_SCRATCHPAD_SECTION_GLOBAL:
        res = pascal_gp10x_scratchpad_getGlobalFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_SCRATCHPAD_SECTION_WARP:
        base = OFFSETOF_NONCONST(PascalScratchpad_t, warp[sm][wp]);
        res = pascal_gp10x_scratchpad_getWarpFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_SCRATCHPAD_SECTION_SM:
        base = OFFSETOF_NONCONST(PascalScratchpad_t, sm[sm]);
        res = pascal_gp10x_scratchpad_getSmFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_SCRATCHPAD_SECTION_LANE:
        base = OFFSETOF_NONCONST(PascalScratchpad_t, warp[sm][wp]) +
               OFFSETOF_NONCONST(PascalWarpScratchpad_t, lane[ln]);
        res = pascal_gp10x_scratchpad_getLaneFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    default:
        *offset = 0;
        *width = 0;
        HALO_TRACE_FUNCTION(0, "Invalid scratchpad section %d\n", section);
        return CUDBG_ERROR_INVALID_ARGS;
    };

    *offset += base;

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_stub_scratchpad_read_pauseServicedMask(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, CUwarpBitmask *pauseServicedMask)
{
    CUDBG_VERIFY(scratchpadAccessor && pauseServicedMask, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
pascal_gp10x_stub_scratchpad_read_pauseServicedMask_raw(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint64_t *pauseServicedMask)
{
    CUDBG_VERIFY(scratchpadAccessor && pauseServicedMask, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
pascal_gp10x_scratchpad_read_validOnSaveWarpFlag(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint8_t *validOnSaveWarpFlag)
{
    CUDBG_VERIFY(scratchpadAccessor && validOnSaveWarpFlag, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, WARP_FLAG_VALID_ON_SAVE, vsm, wp, 0, validOnSaveWarpFlag);

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_scratchpad_read_pauseServicedWarpFlag(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint8_t *pauseServicedWarpFlag)
{
    CUDBG_VERIFY(scratchpadAccessor && pauseServicedWarpFlag, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_GET_FIELD(scratchpadAccessor, WARP, WARP_FLAG_PAUSE_SERVICED, vsm, wp, 0, pauseServicedWarpFlag);

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_scratchpad_write_preemptCommand(HaloScratchpadAccessor scratchpadAccessor, uint32_t preemptCommand)
{
    CUDBG_VERIFY(scratchpadAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_SET_FIELD(scratchpadAccessor, GLOBAL, PREEMPT_COMMAND, 0, 0, 0, &preemptCommand);

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_stub_scratchpad_write_pauseServicedMask_raw(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint64_t pauseServicedMask)
{
    CUDBG_VERIFY(scratchpadAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    CUDBG_ERROR("Unsupported scratchpad field\n");

    return CUDBG_ERROR_INVALID_DEVICE;
}

static CUDBGResult
pascal_gp10x_scratchpad_write_pauseServicedWarpFlag(HaloScratchpadAccessor scratchpadAccessor, uint32_t vsm, uint32_t wp, uint8_t pauseServicedWarpFlag)
{
    CUDBG_VERIFY(scratchpadAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_SCRATCHPAD_SET_FIELD(scratchpadAccessor, WARP, WARP_FLAG_PAUSE_SERVICED, vsm, wp, 0, &pauseServicedWarpFlag);

    return CUDBG_SUCCESS;
}

/* Preemption buffer access */

static CUDBGResult
pascal_gp10x_preemptionBuffer_getLaneFieldOffset(HaloPreemptionBufferField field, uint32_t ln, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(PR, CUpascalWarpCILPBuffer, PRCC[ln].pr);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(CC, CUpascalWarpCILPBuffer, PRCC[ln].cc);
    default:
        *width = 0;
        *offset = 0;
        HALO_TRACE_FUNCTION(0, "Invalid scratchpad field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_preemptionBuffer_getWarpFieldOffset(HaloPreemptionBufferField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(LMEMBASE, CUpascalWarpCILPBuffer, LMEMBASE);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(RFDATAIDX, CUpascalWarpCILPBuffer, RFDataIdx);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_BARSTATE, CUpascalWarpCILPBuffer, BARState);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARP_RESERVED1, CUpascalWarpCILPBuffer, reservedPad1);
    default:
        *width = 0;
        *offset = 0;
        HALO_TRACE_FUNCTION(0, "Invalid scratchpad field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_preemptionBuffer_getCTAFieldOffset(HaloPreemptionBufferField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(SHMEMDATAIDX, CUpascalCTACILPBuffer, shmemDataIdx);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(CTA_RESERVEDPAD1, CUpascalCTACILPBuffer, reservedPad1);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(CTA_BARSTATE, CUpascalCTACILPBuffer, BARState);

    default:
        *width = 0;
        *offset = 0;
        HALO_TRACE_FUNCTION(0, "Invalid scratchpad field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_preemptionBuffer_getSMFieldOffset(HaloPreemptionBufferField field, size_t *offset, size_t *width)
{
    switch (field) {
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(RFDATAIDXSYNC, CUpascalSMCILPBuffer, RFDataIdxSync);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(SHMEMDATAIDXSYNC, CUpascalSMCILPBuffer, shmemDataIdxSync);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(VALIDPENDINGSTATE, CUpascalSMCILPBuffer, validPendingState);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(SM_RESERVEDPAD1, CUpascalSMCILPBuffer, reservedPad1);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(RFDATA, CUpascalSMCILPBuffer, RFData);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(SHMEMDATA, CUpascalSMCILPBuffer, shmemData);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(WARPDATA, CUpascalSMCILPBuffer, warpData);
        HALO_PREEMPTION_BUFFER_GET_OFFSET_CASE(CTADATA, CUpascalSMCILPBuffer, CTAData);
    default:
        *width = 0;
        *offset = 0;
        HALO_TRACE_FUNCTION(0, "Invalid scratchpad field %d\n", field);
        return CUDBG_ERROR_INVALID_ARGS;
    }
    return CUDBG_SUCCESS;
}


static CUDBGResult
pascal_gp10x_preemptionBuffer_getFieldOffset(HaloPreemptionBufferField field, HaloPreemptionBufferSection section,
    uint32_t sm, uint32_t cta, uint32_t wp, uint32_t ln,
    size_t *offset, size_t *width)
{
    size_t base = 0;
    CUDBGResult res;

    base = sm * sizeof(CUpascalSMCILPBuffer);

    switch (section) {
    case HALO_PREEMPTION_BUFFER_SECTION_SM:
        res = pascal_gp10x_preemptionBuffer_getSMFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_PREEMPTION_BUFFER_SECTION_CTA:
        base += OFFSETOF_NONCONST(CUpascalSMCILPBuffer, CTAData[cta]);
        res = pascal_gp10x_preemptionBuffer_getCTAFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_PREEMPTION_BUFFER_SECTION_WARP:
        base += OFFSETOF_NONCONST(CUpascalSMCILPBuffer, warpData[wp]);
        res = pascal_gp10x_preemptionBuffer_getWarpFieldOffset(field, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    case HALO_PREEMPTION_BUFFER_SECTION_LANE:
        base += OFFSETOF_NONCONST(CUpascalSMCILPBuffer, warpData[wp]);
        res = pascal_gp10x_preemptionBuffer_getLaneFieldOffset(field, ln, offset, width);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get offset\n");
        break;
    default:
        *width = 0;
        *offset = 0;
        HALO_TRACE_FUNCTION(0, "Invalid preemption buffer section %d\n", section);
        return CUDBG_ERROR_INVALID_ARGS;
    };

    *offset += base;
    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_preemptionBuffer_getSwizzledRegOffset(uint32_t ln, uint32_t regnum, uint32_t numRegs, uint32_t *regOffset)
{
    /* Compute the swizzled register offset. This part is very similar to
    the register computation for the CNP save region (i.e. KILP) */
    if (regnum >= (numRegs & (~0x3))) {
        *regOffset = (CU_PASCAL_ARCH_CONST_HW_SM_BYTES_PER_WARP_REGISTER * regnum) +
            (ln * CU_PASCAL_ARCH_CONST_HW_SM_BYTES_PER_SCALAR_REGISTER);
    }
    else {
        *regOffset = (CU_PASCAL_ARCH_CONST_HW_SM_BYTES_PER_WARP_REGISTER * (regnum & ~0x3)) +
            (ln * CU_PASCAL_ARCH_CONST_HW_SM_BYTES_PER_SCALAR_REGISTER * 4) +
            ((regnum % 4) * 4);
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_preemptionBuffer_getRegOffset(struct Halo_st *halo, HaloPreemptionBufferAccessor preemptionBufferAccessor,
    uint32_t sm, uint32_t wp, uint32_t ln, uint32_t regnum, uint32_t numRegs, uint32_t *pRegOffset)
{
    uint32_t wpOffByte, regOffByte;
    CUDBGResult res;
    size_t smRfDataOffset, smRfDataSize;

    /* Finally grab the base offset for the RF region for the SM */
    res = halo->preemptionBuffer.getFieldOffset(HALO_PREEMPTION_BUFFER_FIELD_RFDATA,
        HALO_PREEMPTION_BUFFER_SECTION_SM,
        sm, 0, wp, ln,
        &smRfDataOffset,
        &smRfDataSize);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get RFData offset\n");

    /* First grab the RFdata offset for the warp */
    res = halo->preemptionBuffer.read_RFDataIdx(preemptionBufferAccessor, sm, wp, &wpOffByte);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read RF data index\n");

    res = pascal_gp10x_preemptionBuffer_getSwizzledRegOffset(ln, regnum, numRegs, &regOffByte);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to calculate the swizzled register offset\n");

    *pRegOffset = (uint32_t)(smRfDataOffset + wpOffByte + regOffByte);

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_preemptionBuffer_getRegOffsets(struct Halo_st *halo, HaloPreemptionBufferAccessor preemptionBufferAccessor,
                                            uint32_t sm, uint32_t wp, uint32_t ln, uint32_t firstRegnum, uint32_t numKernelRegs,
                                            uint32_t numRegs, uint32_t *pRegOffsets)
{
    uint32_t wpOffByte, wpOffset;
    CUDBGResult res;
    size_t smRfDataOffset, smRfDataSize;
    uint32_t i;

    res = halo->preemptionBuffer.getFieldOffset(HALO_PREEMPTION_BUFFER_FIELD_RFDATA,
        HALO_PREEMPTION_BUFFER_SECTION_SM,
        sm, 0, 0, 0,
        &smRfDataOffset,
        &smRfDataSize);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to get RFData offset\n");

    res = halo->preemptionBuffer.read_RFDataIdx(preemptionBufferAccessor, sm, wp, &wpOffByte);
    CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to read RF data index\n");

    wpOffset = (uint32_t)(smRfDataOffset + wpOffByte);

    for (i = 0; i < numRegs; i++) {
        uint32_t regnum = firstRegnum + i;

        res = pascal_gp10x_preemptionBuffer_getSwizzledRegOffset(ln, regnum, numKernelRegs, &pRegOffsets[i]);
        CUDBG_VERIFY(res == CUDBG_SUCCESS, res, "Failed to calculate the swizzled register offset\n");

        pRegOffsets[i] += wpOffset;
    }

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_preemptionBuffer_read_RFDataIdxSync(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t *rfDataIdxSync)
{
    CUDBG_VERIFY(preemptionBufferAccessor && rfDataIdxSync, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_PREEMPTION_BUFFER_GET_FIELD(preemptionBufferAccessor, SM, RFDATAIDXSYNC, vsm, 0, 0, 0, rfDataIdxSync);

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_preemptionBuffer_read_shmemDataIdxSync(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t *shmemDataIdxSync)
{
    CUDBG_VERIFY(preemptionBufferAccessor && shmemDataIdxSync, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_PREEMPTION_BUFFER_GET_FIELD(preemptionBufferAccessor, SM, SHMEMDATAIDXSYNC, vsm, 0, 0, 0, shmemDataIdxSync);

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_preemptionBuffer_read_shmemDataIdx(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t cta, uint32_t *shmemDataIdx)
{
    CUDBG_VERIFY(preemptionBufferAccessor && shmemDataIdx, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_PREEMPTION_BUFFER_GET_FIELD(preemptionBufferAccessor, CTA, SHMEMDATAIDX, vsm, cta, 0, 0, shmemDataIdx);

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_preemptionBuffer_read_RFDataIdx(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t *rfDataIdx)
{
    CUDBG_VERIFY(preemptionBufferAccessor && rfDataIdx, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_PREEMPTION_BUFFER_GET_FIELD(preemptionBufferAccessor, WARP, RFDATAIDX, vsm, 0, wp, 0, rfDataIdx);

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_preemptionBuffer_read_PR(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t lane, uint8_t *pr)
{
    CUDBG_VERIFY(preemptionBufferAccessor && pr, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_PREEMPTION_BUFFER_GET_FIELD(preemptionBufferAccessor, LANE, PR, vsm, 0, wp, lane, pr);

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_preemptionBuffer_read_CC(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t lane, uint8_t *cc)
{
    CUDBG_VERIFY(preemptionBufferAccessor && cc, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_PREEMPTION_BUFFER_GET_FIELD(preemptionBufferAccessor, LANE, CC, vsm, 0, wp, lane, cc);

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_preemptionBuffer_write_RFDataIdxSync(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t rfDataIdxSync)
{
    CUDBG_VERIFY(preemptionBufferAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_PREEMPTION_BUFFER_SET_FIELD(preemptionBufferAccessor, SM, RFDATAIDXSYNC, vsm, 0, 0, 0, &rfDataIdxSync);

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_preemptionBuffer_write_shmemDataIdxSync(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t shmemDataIdxSync)
{
    CUDBG_VERIFY(preemptionBufferAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_PREEMPTION_BUFFER_SET_FIELD(preemptionBufferAccessor, SM, SHMEMDATAIDXSYNC, vsm, 0, 0, 0, &shmemDataIdxSync);

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_preemptionBuffer_write_PR(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t lane, uint8_t pr)
{
    CUDBG_VERIFY(preemptionBufferAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_PREEMPTION_BUFFER_SET_FIELD(preemptionBufferAccessor, LANE, PR, vsm, 0, wp, lane, &pr);

    return CUDBG_SUCCESS;
}

static CUDBGResult
pascal_gp10x_preemptionBuffer_write_CC(HaloPreemptionBufferAccessor preemptionBufferAccessor, uint32_t vsm, uint32_t wp, uint32_t lane, uint8_t cc)
{
    CUDBG_VERIFY(preemptionBufferAccessor, CUDBG_ERROR_INVALID_ARGS, "Invalid arguments\n");

    HALO_PREEMPTION_BUFFER_SET_FIELD(preemptionBufferAccessor, LANE, CC, vsm, 0, wp, lane, &cc);

    return CUDBG_SUCCESS;
}

/* Populate the debugger structure with Pascal GP10x specific functions. */
void
haloDeviceInit_gp10x(Halo_st *halo)
{
    haloDeviceInit_gm20x(halo); /* Most gm20x functions can be shared with gp10x */

    /* architectual constants - always init after base chip init */
    halo->deviceInfo.spRegisterNumber = PASCAL_ABI_SP_REGNUM;
    halo->deviceInfo.cilpBufferSizePerSM = sizeof(CUpascalSMCILPBuffer);
    halo->deviceInfo.scratchpadSize = sizeof(PascalScratchpad_t);

    /* methods */
    halo->getInfo = pascal_gp10x_getInfo;

    /* GP10x - scratchpad accessors */
    halo->getScratchpadSharedMemDevVaddr = pascal_gp10x_getScratchpadSharedMemDevVaddr;

    halo->preemptPreHook = pascal_gp10x_preemptPreHook;
    halo->preemptPostHook = pascal_gp10x_preemptPostHook;
    halo->setPreemptCommand = pascal_gp10x_setPreemptCommand;

    /* Writes to pause serviced mask  */
    halo->writePauseServicedMask = pascal_gp10x_writePauseServicedMask;
    halo->readPauseServicedMask = pascal_gp10x_readPauseServicedMask;
    halo->readSaveWarpMask = pascal_gp10x_readSaveWarpMask;
    halo->waitForSMPause = pascal_gp10x_waitForSMPause;
    halo->writeBreakpointMask = pascal_gp10x_writeBreakpointMask;
    halo->singleStepExit = pascal_gp10x_singleStepExit;

    halo->getRegisterCount  = pascal_gp10x_getRegisterCount;
    halo->readRegisterRange = pascal_gp10x_readRegisterRange;
    halo->writeRegisterFile = pascal_gp10x_writeRegisterFile;
    halo->readSharedMemory  = pascal_gp10x_readSharedMemory;
    halo->writeSharedMemory = pascal_gp10x_writeSharedMemory;
    halo->readPredicates    = pascal_gp10x_readPredicates;
    halo->readCCRegister    = pascal_gp10x_readCCRegister;
    halo->writePredicates   = pascal_gp10x_writePredicates;
    halo->writeCCRegister   = pascal_gp10x_writeCCRegister;
    halo->readTextureMemoryUsingTexHeader = maxwell_gm10x_kilp_readTextureMemoryUsingTexHeader;
    halo->readTextureMemory = pascal_gp10x_readTextureMemory;
    halo->getWarpMaskPRIOffset = pascal_gp10x_getWarpMaskPRIOffset;
    halo->readWarpMaskPRI = pascal_gp10x_readWarpMaskPRI;
    halo->writeWarpMaskPRI = pascal_gp10x_writeWarpMaskPRI;
    halo->convertPhysicalToVirtual = pascal_gp10x_convertPhysicalToVirtual;
    halo->convertVirtualToPhysical = pascal_gp10x_convertVirtualToPhysical;
    halo->readSMESRInfo        = pascal_gp10x_readSMESRInfo;
    halo->readSMWarpESRInfo    = pascal_gp10x_readSMWarpESRInfo;
    halo->clearSMESRInfo       = pascal_gp10x_clearSMESRInfo;
    halo->invalidateSMState = pascal_gp10x_invalidateSMState;
    halo->read_warpParams = pascal_gp10x_read_warpParams;
    halo->forceScratchpadLmemBase = pascal_gp10x_forceScratchpadLmemBase;
    halo->getTexDptrMask = pascal_gp10x_getTexDptrMask;
    halo->getPauseReasonTableWarpOffset = pascal_gp10x_getPauseReasonTableWarpOffset;

    halo->mcinterop_getRegSpill = pascal_gp10x_mcinterop_getRegSpill;

    /* Scratchpad access */

    halo->scratchpad.getFieldOffset = pascal_gp10x_scratchpad_getFieldOffset;

    halo->scratchpad.read_pauseServicedMask = pascal_gp10x_stub_scratchpad_read_pauseServicedMask;
    halo->scratchpad.read_pauseServicedMask_raw = pascal_gp10x_stub_scratchpad_read_pauseServicedMask_raw;
    halo->scratchpad.read_validOnSaveWarpFlag = pascal_gp10x_scratchpad_read_validOnSaveWarpFlag;
    halo->scratchpad.read_pauseServicedWarpFlag = pascal_gp10x_scratchpad_read_pauseServicedWarpFlag;

    halo->scratchpad.write_preemptCommand = pascal_gp10x_scratchpad_write_preemptCommand;
    halo->scratchpad.write_pauseServicedMask_raw = pascal_gp10x_stub_scratchpad_write_pauseServicedMask_raw;
    halo->scratchpad.write_pauseServicedWarpFlag = pascal_gp10x_scratchpad_write_pauseServicedWarpFlag;

    /* Preemption buffer access */

    halo->preemptionBuffer.getFieldOffset = pascal_gp10x_preemptionBuffer_getFieldOffset;
    halo->preemptionBuffer.getRegOffset = pascal_gp10x_preemptionBuffer_getRegOffset;
    halo->preemptionBuffer.getRegOffsets = pascal_gp10x_preemptionBuffer_getRegOffsets;
    halo->preemptionBuffer.getSwizzledRegOffset = pascal_gp10x_preemptionBuffer_getSwizzledRegOffset;

    halo->preemptionBuffer.read_RFDataIdxSync = pascal_gp10x_preemptionBuffer_read_RFDataIdxSync;
    halo->preemptionBuffer.read_shmemDataIdxSync = pascal_gp10x_preemptionBuffer_read_shmemDataIdxSync;
    halo->preemptionBuffer.read_shmemDataIdx = pascal_gp10x_preemptionBuffer_read_shmemDataIdx;
    halo->preemptionBuffer.read_RFDataIdx = pascal_gp10x_preemptionBuffer_read_RFDataIdx;
    halo->preemptionBuffer.read_PR = pascal_gp10x_preemptionBuffer_read_PR;
    halo->preemptionBuffer.read_CC = pascal_gp10x_preemptionBuffer_read_CC;

    halo->preemptionBuffer.write_RFDataIdxSync = pascal_gp10x_preemptionBuffer_write_RFDataIdxSync;
    halo->preemptionBuffer.write_shmemDataIdxSync = pascal_gp10x_preemptionBuffer_write_shmemDataIdxSync;
    halo->preemptionBuffer.write_PR = pascal_gp10x_preemptionBuffer_write_PR;
    halo->preemptionBuffer.write_CC = pascal_gp10x_preemptionBuffer_write_CC;
}
