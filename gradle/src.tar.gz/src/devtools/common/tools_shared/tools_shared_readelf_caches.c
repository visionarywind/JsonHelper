/*
 * Copyright 2013-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include <stdlib.h>

#include "tools_shared_readelf_caches.h"
#include "tools_shared_list.h"
#include "tools_shared_readelf_common.h"

/************************ DESTROY FUNCTIONS **********************************/
static void destroyData(void *ptr, void *param);

static void
destroyData(void *ptr, void *param)
{
    if (ptr)
        free(ptr);
}

static void
destroyKernelCacheRecord(KernelCacheRecord *kptr)
{
    if (!kptr)
        return;

    if (kptr->rmap)
        toolsRangeMapDestroy(&kptr->rmap, NULL, NULL);

    free(kptr);
}

static void
destroyKernelCacheRecord_wrap(void *ptr, void *param)
{
    destroyKernelCacheRecord((KernelCacheRecord*)ptr);
}

static void
destroyKernelCache(ElfModuleCacheRecord *emcr)
{
    if (!emcr)
        return;

    if (emcr->kernelHashMapByName)
        toolsHashMapDelete(emcr->kernelHashMapByName, destroyKernelCacheRecord_wrap, NULL);

    if (emcr->kernelHashMapByRelocLoc)
        toolsHashMapDelete(emcr->kernelHashMapByRelocLoc, NULL, NULL);
}

static void
destroyFileCache(DebugLineSection *dls)
{
    if (!dls || !(dls->fileCache))
        return;
    free(dls->fileCache);
    dls->fileCache = NULL;
}

static void
destroyDirCache(DebugLineSection *dls)
{
    if (!dls || !(dls->dirCache))
        return;
    free(dls->dirCache);
    dls->dirCache = NULL;
}

static void
destroyDebugLineSection(DebugLineSection *dls)
{
    destroyDirCache(dls);
    destroyFileCache(dls);
}

static void
destroyDebugLineSection_wrap(void *ptr, void *param)
{
    destroyDebugLineSection((DebugLineSection*)ptr);
}

static void
destroyDebugLineSectionList(ElfModuleCacheRecord *emcr)
{
    if (!emcr || !emcr->debugLineSectionList)
        return;

    toolsListDelete(emcr->debugLineSectionList,
                    &destroyDebugLineSection_wrap, NULL);
}

static void
destroyElfModuleCacheRecord(ElfModuleCacheRecord *emcr)
{
    if (!emcr)
        return;

    destroyKernelCache(emcr);
    destroyDebugLineSectionList(emcr);

    free(emcr);
}

static void
destroyElfModuleCacheRecord_wrap(void *ptr, void *param)
{
    destroyElfModuleCacheRecord((ElfModuleCacheRecord*)ptr);
}

void
destroyElfModuleCache(void)
{
    toolsHashMapDelete(elfModuleHashMap, destroyElfModuleCacheRecord_wrap, NULL);
}

/************************* CREATE FUNCTIONS **********************************/

// In case the function fails, hash-map is destroyed by the caller
static TOOLSresult
createKernelCache(ElfModuleCacheRecord *emcr)
{
    uint32_t             i, num_kernels = 0;
    TOOLSresult          result = TOOLS_SUCCESS;
    void                *image = NULL;
    KernelCacheRecord   *kcRecord = NULL;
    tHashMap            *kernelHashMapByName = NULL;
    char               **kernel_names = NULL;

    if (!emcr || !(emcr->image) || !isELF(emcr->image))
        return TOOLS_ERROR_INVALID_VALUE;
    image = emcr->image;

    i = isELF64(image);

    /* get total num of kernels in this ELF */
    if (i)
        result = toolsElf64ListKernelNames((const void *)image,
                                           kernel_names, 0,
                                           &num_kernels);
    else
        result = toolsElf32ListKernelNames((const void *)image,
                                           kernel_names, 0,
                                           &num_kernels);
    if (result == TOOLS_SUCCESS)
        result = TOOLS_ERROR_UNKNOWN;
    if (result != TOOLS_ERROR_OUT_OF_MEMORY)
        return result;

    /* allocate memory to store kernel names */
    kernel_names = (char **)calloc(num_kernels, sizeof(char*));
    if (!kernel_names)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    /* get names of the kernels */
    if (i)
        result = toolsElf64ListKernelNames((const void *)image,
                                           kernel_names, num_kernels,
                                           &num_kernels);
    else
        result = toolsElf32ListKernelNames((const void *)image,
                                           kernel_names, num_kernels,
                                           &num_kernels);
    if (result != TOOLS_SUCCESS)
        goto error;

    emcr->kernelHashMapByName = toolsHashMapNew(toolsStringHashFun,
                                                toolsStringEqualFun,
                                                NUM_BUCKETS_KERNEL_HASH_MAP);
    if (!emcr->kernelHashMapByName) {
        result = TOOLS_ERROR_OUT_OF_MEMORY;
        goto error;
    }

    emcr->kernelHashMapByRelocLoc = toolsHashMapNew(toolsUint32HashFun,
                                                    toolsUint32EqualFun,
                                                    NUM_BUCKETS_KERNEL_HASH_MAP);
    if (!emcr->kernelHashMapByRelocLoc) {
        result = TOOLS_ERROR_OUT_OF_MEMORY;
        goto error;
    }

    kernelHashMapByName = emcr->kernelHashMapByName;

    for (i = 0; i < num_kernels; ++i, kcRecord = NULL) {
        kcRecord = (KernelCacheRecord *)calloc(1, sizeof(KernelCacheRecord));
        if (!kcRecord) {
            result = TOOLS_ERROR_OUT_OF_MEMORY;
            goto error;
        }

        result = toolsRangeMapCreate(&kcRecord->rmap);
        if (result != TOOLS_SUCCESS)
            goto error;

        kcRecord->name = kernel_names[i];

        result = toolsHashMapInsert(kernelHashMapByName,
                                    tHashMapPtrToKey(kcRecord->name),
                                    (void *)kcRecord);
        if (result != TOOLS_SUCCESS)
            goto error;
    }

error:
    if (kernel_names)
        free(kernel_names);
    if (kcRecord) { // kcRecord created but not inserted into hash-map
        toolsRangeMapDestroy(&kcRecord->rmap, NULL, NULL);
        free(kcRecord);
    }

    return result;
}

// In case the function fails, all allocated memory is deallocated
static TOOLSresult
createFileCache(DebugLineSection *dls)
{
    uint32_t            i;
    char               *ptr = NULL, *file_ptr = NULL;
    TOOLSresult         result = TOOLS_SUCCESS;
    unsigned char       opcode_base;
    tList              *list = NULL;
    tListItr           *itr;
    FileCacheRecord    *fcRecord;

    if (!dls || !dls->debugLineSectionPtr)
        return TOOLS_ERROR_INVALID_VALUE;

    ptr           = dls->debugLineSectionPtr;
    ptr          += 14;
    opcode_base   = *(unsigned char*)ptr;
    ptr          += opcode_base;
    file_ptr      = ptr + dls->dirTableByteSize;

    /* DETERMINE REQUIRED MEMORY SIZE AND BUILD LIST */
    list = toolsListNew();
    if (!list)
        return TOOLS_ERROR_OUT_OF_MEMORY;
    dls->num_of_files = 1;
    ptr = file_ptr;
    while (*ptr != '\0') {
        fcRecord = (FileCacheRecord *)calloc(1, sizeof(*fcRecord));
        if (!fcRecord) {
            result = TOOLS_ERROR_OUT_OF_MEMORY;
            goto error;
        }

        fcRecord->fileName = ptr;
        fcRecord->fileIdx  = dls->num_of_files;
        ptr += strlen(ptr) + 1;
        fcRecord->dirName  = decodeULEB(&ptr);
        (void)decodeULEB(&ptr);
        (void)decodeULEB(&ptr);

        result = toolsListAppend(list, (void *)fcRecord);
        if (result != TOOLS_SUCCESS) {
            free(fcRecord);
            goto error;
        }

        (dls->num_of_files)++;
    }
    dls->fileTableByteSize = ptr - file_ptr + 1;

    /* ALLOCATE MEMORY */
    dls->fileCache = (FileCacheRecord *)calloc(dls->num_of_files,
                                               sizeof(*dls->fileCache));
    if (!dls->fileCache) {
        result = TOOLS_ERROR_OUT_OF_MEMORY;
        goto error;
    }

    if (dls->num_of_files == 1) {
        /* No records would have been appended to the list, so
           free the list and quit. Not really an error. */
        goto error;
    }

    /* FILL dls->fileCache */
    (dls->fileCache)->fileName = NULL;
    (dls->fileCache)->dirName  = 0;
    (dls->fileCache)->fileIdx  = 0;
    for (i = 1, itr = toolsListGetIterator(list); itr;
         itr = toolsListGetNext(itr), i++) {
        fcRecord = toolsListGetElem(itr);
        *(dls->fileCache + i) = *fcRecord;
    }

error:
    toolsListDelete(list, &destroyData, NULL);
    return result;
}

// In case the function fails, all the allocated memory is deallocated
static TOOLSresult
createDirCache(DebugLineSection *dls)
{
    uint32_t            i;
    char               *ptr = NULL, *dir_ptr = NULL;
    TOOLSresult         result = TOOLS_SUCCESS;
    unsigned char       opcode_base;
    tList              *list = NULL;
    tListItr           *itr;
    DirCacheRecord     *dcRecord;

    if (!dls || !dls->debugLineSectionPtr)
        return TOOLS_ERROR_INVALID_VALUE;

    ptr           = dls->debugLineSectionPtr;
    ptr          += 14;
    opcode_base   = *(unsigned char*)ptr;
    ptr          += opcode_base;
    dir_ptr       = ptr;

    /* DETERMINE REQUIRED MEMORY SIZE */
    list = toolsListNew();
    if (!list)
        return TOOLS_ERROR_OUT_OF_MEMORY;
    dls->num_of_dirs = 1;
    while (*ptr != '\0') {
        dcRecord = (DirCacheRecord *)calloc(1, sizeof(*dcRecord));
        if (!dcRecord) {
            result = TOOLS_ERROR_OUT_OF_MEMORY;
            goto error;
        }

        dcRecord->dirName = ptr;
        dcRecord->dirIdx  = dls->num_of_dirs;
        ptr += strlen(ptr) + 1;

        result = toolsListAppend(list, (void *)dcRecord);
        if (result != TOOLS_SUCCESS) {
            free(dcRecord);
            goto error;
        }

        (dls->num_of_dirs)++;
    }
    dls->dirTableByteSize = ptr - dir_ptr + 1;

    /* ALLOCATE MEMORY */
    dls->dirCache = (DirCacheRecord *)calloc(dls->num_of_dirs,
                                             sizeof(*dls->dirCache));
    if (!dls->dirCache) {
        result = TOOLS_ERROR_OUT_OF_MEMORY;
        goto error;
    }

    if (dls->num_of_dirs == 1) {
        /* No records would have been appended to the list, so
           free the list and quit. Not really an error. */
        goto error;
    }

    /* FILL dls->dirCache */
    (dls->dirCache)->dirName = NULL;
    (dls->dirCache)->dirIdx  = 0;
    for (i = 1, itr = toolsListGetIterator(list); itr;
         itr = toolsListGetNext(itr), i++) {
        dcRecord = toolsListGetElem(itr);
        *(dls->dirCache + i) = *dcRecord;
    }

error:
    toolsListDelete(list, &destroyData, NULL);
    return result;
}

static TOOLSresult
createDebugLineSection(ElfModuleCacheRecord *emcr, char *ptr, DebugLineSection **pdls)
{
    DebugLineSection *dls = NULL;
    TOOLSresult result = TOOLS_SUCCESS;

    if (!emcr || !ptr || !emcr->debugLineSectionList)
        return TOOLS_ERROR_INVALID_VALUE;

    dls = calloc(1, sizeof(*dls));
    if (!dls)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    dls->debugLineSectionPtr = ptr;

    result = toolsListAppend(emcr->debugLineSectionList, (void *)dls);

    if (pdls)
        *pdls = dls;

    return result;
}

// ptr should point at the first address in .debug_line section (not header)
static TOOLSresult
initDebugLineState(DebugLineSection *dls)
{
    DebugLineState *dblState = NULL;
    char *ptr = NULL;

    if (!dls)
        return TOOLS_ERROR_INVALID_VALUE;

    ptr = dls->debugLineSectionPtr;

    dblState = &(dls->state);

    dblState->currentKernel = NULL;
    dblState->address   = 0;
    dblState->prev_address = 0;
    dblState->file      = 1;
    dblState->prev_file = 1;
    dblState->line      = 1;
    dblState->prev_line = 1;
    dblState->total_length  = *(uint32_t*)ptr;
    ptr += 4;
    dblState->end = ptr + dblState->total_length;
    ptr += 2;
    ptr += 4;
    dblState->min_instr_len = *(unsigned char*)ptr;
    ptr += 1;
    ptr += 1;
    dblState->line_base     = *(signed char*)ptr;
    ptr += 1;
    dblState->line_range    = *(unsigned char*)ptr;
    ptr += 1;
    dblState->opcode_base   = *(unsigned char*)ptr;
    ptr += 1;
    ptr += dblState->opcode_base - 1;
    ptr += dls->dirTableByteSize;
    ptr += dls->fileTableByteSize;
    dblState->ptr = ptr;

    return TOOLS_SUCCESS;
}

TOOLSresult
insertIntoElfModuleCache(void    *pimage,
                         char    *debugLineSectionPtr,
                         char    *debugLineSectionEndPtr,
                         void    *symtab,
                         size_t   symtab_size,
                         void    *strtab,
                         size_t   strtab_size,
                         ElfModuleCacheRecord **ret_elfModule)
{

    ElfModuleCacheRecord *emcr = NULL;
    TOOLSresult           result = TOOLS_SUCCESS;
    char *ptr = NULL;
    DebugLineSection *dls = NULL;

    if (!pimage || !isELF(pimage) ||!debugLineSectionPtr || !ret_elfModule)
        return TOOLS_ERROR_INVALID_VALUE;

    *ret_elfModule = NULL;
    emcr = (ElfModuleCacheRecord *)calloc(1, sizeof(*emcr));
    if (!emcr)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    emcr->image = pimage;
    emcr->symtab = symtab;
    emcr->symtab_size = symtab_size;
    emcr->strtab = strtab;
    emcr->strtab_size = strtab_size;

    // Create the list for debug line sections
    emcr->debugLineSectionList = toolsListNew();
    if (!emcr->debugLineSectionList) {
        result = TOOLS_ERROR_OUT_OF_MEMORY;
        goto error;
    }

    // Create the list of kernels in the image
    result = createKernelCache(emcr);
    if (result != TOOLS_SUCCESS)
        goto error;

    for (ptr = debugLineSectionPtr; ptr < debugLineSectionEndPtr ; ) {
        result = createDebugLineSection(emcr, ptr, &dls);
        if (result != TOOLS_SUCCESS)
            goto error;

        result = createDirCache(dls);
        if (result != TOOLS_SUCCESS)
            goto error;

        result = createFileCache(dls);
        if (result != TOOLS_SUCCESS)
            goto error;

        result = initDebugLineState(dls);
        if (result != TOOLS_SUCCESS)
            goto error;

        ptr = dls->state.end;
    }

    (void)setDLSActiveStart(emcr);

    result = toolsHashMapInsert(elfModuleHashMap,
                                tHashMapPtrToKey(emcr->image),
                                (void *)emcr);
    if (result != TOOLS_SUCCESS)
        goto error;

    *ret_elfModule = emcr;
    return TOOLS_SUCCESS;

error:
    destroyElfModuleCacheRecord(emcr);
    return result;
}

TOOLSresult
insertIntoLineCache(KernelCacheRecord *kernel,
                    DebugLineSection *dls,
                    uint32_t lo_addr, uint32_t hi_addr,
                    uint32_t line, uint32_t file)
{
    LineCacheRecord *newRecord = NULL;
    TOOLSresult result;

    if (!kernel || !kernel->rmap || !dls)
        return TOOLS_ERROR_INVALID_VALUE;

    if (hi_addr < lo_addr)
        return TOOLS_ERROR_INVALID_VALUE;

    /* If an entry already exists, do nothing */
    if (toolsRangeMapLookupByRange(kernel->rmap, lo_addr, hi_addr - lo_addr + 1))
        return TOOLS_SUCCESS;

    newRecord = (LineCacheRecord *)calloc(1, sizeof(*newRecord));
    if (!newRecord)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    newRecord->line     = line;
    newRecord->file_num = file;
    newRecord->dls      = dls;

    result = toolsRangeMapInsertByRange(kernel->rmap,
                                        lo_addr, hi_addr - lo_addr + 1,
                                        (void *)newRecord);
    return result;
}

/************************* SEARCH FUNCTIONS **********************************/
TOOLSresult
getDirCache(DebugLineSection *dls, uint32_t dir_num, char **ret_dir_name)
{
    if (!dls)
        return TOOLS_ERROR_INVALID_VALUE;

    if (!dls->dirCache || dir_num > dls->num_of_dirs - 1)
        return TOOLS_ERROR_UNKNOWN;

    if (ret_dir_name)
        *ret_dir_name = (dls->dirCache + dir_num)->dirName;

    return TOOLS_SUCCESS;
}

TOOLSresult
getFileCache(DebugLineSection *dls, uint32_t file_num,
             char **ret_file_name, uint32_t *ret_dir_num)
{
    if (!dls)
        return TOOLS_ERROR_INVALID_VALUE;

    if (!dls->fileCache || file_num > dls->num_of_files - 1)
        return TOOLS_ERROR_UNKNOWN;

    if (ret_file_name)
        *ret_file_name = (dls->fileCache + file_num)->fileName;

    if (ret_dir_num)
        *ret_dir_num = (dls->fileCache + file_num)->dirName;

    return TOOLS_SUCCESS;
}

ElfModuleCacheRecord*
searchElfModuleCache(void *image)
{
    if (!image)
        return NULL;

    return (ElfModuleCacheRecord *)toolsHashMapFind(elfModuleHashMap, tHashMapPtrToKey(image));
}

KernelCacheRecord*
searchKernelCacheByRelocLoc(ElfModuleCacheRecord *emcr, char *reloc_loc)
{

    if (!emcr || !reloc_loc)
        return NULL;

    return (KernelCacheRecord *)toolsHashMapFind(emcr->kernelHashMapByRelocLoc,
                                                 tHashMapPtrToKey(reloc_loc));
}

KernelCacheRecord*
searchKernelCacheByName (ElfModuleCacheRecord *emCache, const char *kernel_name)
{
    if (!emCache || !kernel_name)
        return NULL;

    return (KernelCacheRecord *)toolsHashMapFind(emCache->kernelHashMapByName,
                                                 tHashMapPtrToKey(kernel_name));
}

/*
searchLineCache returns NULL if the record is not found or if an error is encounterd
while searching for the record
*/
LineCacheRecord*
searchLineCache(KernelCacheRecord *targetKernel, uint32_t pc)
{
    if (!targetKernel)
        return NULL;

    return (LineCacheRecord *)toolsRangeMapLookupByAddr(targetKernel->rmap, pc);
}

TOOLSresult
getLineCacheInfo(LineCacheRecord        *lcRecord,
                 char                  **ret_file_name,
                 char                  **ret_dir_name,
                 uint32_t               *ret_line)
{
    uint32_t dir_num;
    TOOLSresult result;
    DebugLineSection *dls = NULL;

    if (!lcRecord || !ret_line)
        return TOOLS_ERROR_INVALID_VALUE;

    *ret_line = lcRecord->line;
    dls = lcRecord->dls;

    result = getFileCache(dls, lcRecord->file_num, ret_file_name, &dir_num);
    if (result != TOOLS_SUCCESS)
        return result;

    result = getDirCache(dls, dir_num, ret_dir_name);
    return result;
}

DebugLineSection*
getDLSActive(ElfModuleCacheRecord *emcr)
{
    if (!emcr || !emcr->DLSiter)
        return NULL;

    return (DebugLineSection*)toolsListGetElem(emcr->DLSiter);
}

DebugLineSection*
setDLSActiveStart(ElfModuleCacheRecord *emcr)
{
    if (!emcr || !emcr->debugLineSectionList)
        return NULL;

    emcr->DLSiter = toolsListGetIterator(emcr->debugLineSectionList);
    return getDLSActive(emcr);
}

DebugLineSection*
setDLSActiveNext(ElfModuleCacheRecord *emcr)
{
    if (!emcr || !emcr->DLSiter || !emcr->debugLineSectionList)
        return NULL;

    emcr->DLSiter = toolsListGetNext(emcr->DLSiter);
    return getDLSActive(emcr);
}
