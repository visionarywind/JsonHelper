// reentrant red-black tree
// from http://www.epaperpress.com/sortsearch/index.html

#include <stdlib.h>
#include "tools_shared.h"
#include "tools_shared_rbtr.h"
#include "tools_shared_list.h"

typedef struct tRbtNode_st tRbtNode;

struct tRbtNode_st {
    tRbtNode *left;       // left child
    tRbtNode *right;      // right child
    tRbtNode *parent;     // parent
    tRbtNodeColor color;            // node color (BLACK, RED)
    void *key;                  // key used for searching
    void *val;                  // user data
};

struct tRbtree_st {
    tRbtNode *root;           // root of red-black tree
    tRbtNode sentinel;
    tRbtCompareFun compare;    // compare keys
    tRbtCompareFun intersect;  // keys intersect
};

// all leafs are sentinels
#define SENTINEL &rbt->sentinel

static void
toolsRbtInitialize(tRbtree *rbt, tRbtCompareFun rbtCompare,  tRbtCompareFun rbtIntersect)
{
    rbt->compare = rbtCompare;
    rbt->intersect = rbtIntersect;
    rbt->root = SENTINEL;
    rbt->sentinel.left = SENTINEL;
    rbt->sentinel.right = SENTINEL;
    rbt->sentinel.parent = NULL;
    rbt->sentinel.color = TOOLS_NODE_BLACK;
    rbt->sentinel.key = NULL;
    rbt->sentinel.val = NULL;
}

TOOLSresult
toolsRbtCreate(tRbtree **prbt, tRbtCompareFun rbtCompare, tRbtCompareFun rbtIntersect)
{
    tRbtree *rbt = NULL;

    if (!prbt)
        return TOOLS_ERROR_INVALID_VALUE;

    rbt = (tRbtree*)calloc(1, sizeof(*rbt));
    if (!rbt)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    toolsRbtInitialize(rbt, rbtCompare, rbtIntersect);

    *prbt = rbt;

    return TOOLS_SUCCESS;
}

static void
deleteTree(tRbtree *rbt, tRbtNode *p, tSingleFun keydel, void *keydata, tSingleFun valdel, void *valdata)
{
    // erase nodes depth-first
    if (p == SENTINEL)
        return;

    deleteTree(rbt, p->left, keydel, keydata, valdel, valdata);
    deleteTree(rbt, p->right, keydel, keydata, valdel, valdata);

    if (keydel)
        keydel(p->key, keydata);

    if (valdel)
        valdel(p->val, valdata);

    free(p);
}

void
toolsRbtDestroy(tRbtree **prbt, tSingleFun keydel, void *keydata, tSingleFun valdel, void *valdata)
{
    tRbtree *rbt = NULL;

    if (!prbt || !(*prbt))
        return;

    rbt = *prbt;

    deleteTree(rbt, rbt->root, keydel, keydata, valdel, valdata);
    free(rbt);

    *prbt = NULL;
}

static void
rotateLeft(tRbtree *rbt, tRbtNode *x)
{
    // rotate node x to left
    tRbtNode *y = x->right;

    // establish x->right link
    x->right = y->left;
    if (y->left != SENTINEL)
        y->left->parent = x;

    // establish y->parent link
    if (y != SENTINEL)
        y->parent = x->parent;

    if (x->parent) {
        if (x == x->parent->left)
            x->parent->left = y;
        else
            x->parent->right = y;
    }
    else
        rbt->root = y;

    // link x and y
    y->left = x;
    if (x != SENTINEL)
        x->parent = y;
}

static void
rotateRight(tRbtree *rbt, tRbtNode *x)
{
    // rotate node x to right
    tRbtNode *y = x->left;

    // establish x->left link
    x->left = y->right;
    if (y->right != SENTINEL)
        y->right->parent = x;

    // establish y->parent link
    if (y != SENTINEL)
        y->parent = x->parent;

    if (x->parent) {
        if (x == x->parent->right)
            x->parent->right = y;
        else
            x->parent->left = y;
    }
    else
        rbt->root = y;

    // link x and y
    y->right = x;
    if (x != SENTINEL)
        x->parent = y;
}

static void
insertFixup(tRbtree *rbt, tRbtNode *x)
{
    // maintain red-black tree balance after inserting node x

    // check red-black properties
    while (x != rbt->root && x->parent->color == TOOLS_NODE_RED) {
        // we have a violation
        if (x->parent == x->parent->parent->left) {
            tRbtNode *y = x->parent->parent->right;
            if (y->color == TOOLS_NODE_RED) {
                // uncle is TOOLS_NODE_RED
                x->parent->color = TOOLS_NODE_BLACK;
                y->color = TOOLS_NODE_BLACK;
                x->parent->parent->color = TOOLS_NODE_RED;
                x = x->parent->parent;
            }
            else {
                // uncle is TOOLS_NODE_BLACK
                if (x == x->parent->right) {
                    // make x a left child
                    x = x->parent;
                    rotateLeft(rbt, x);
                }

                // recolor and rotate
                x->parent->color = TOOLS_NODE_BLACK;
                x->parent->parent->color = TOOLS_NODE_RED;
                rotateRight(rbt, x->parent->parent);
            }
        }
        else {
            // mirror image of above code
            tRbtNode *y = x->parent->parent->left;
            if (y->color == TOOLS_NODE_RED) {
                // uncle is TOOLS_NODE_RED
                x->parent->color = TOOLS_NODE_BLACK;
                y->color = TOOLS_NODE_BLACK;
                x->parent->parent->color = TOOLS_NODE_RED;
                x = x->parent->parent;
            }
            else {
                // uncle is TOOLS_NODE_BLACK
                if (x == x->parent->left) {
                    x = x->parent;
                    rotateRight(rbt, x);
                }
                x->parent->color = TOOLS_NODE_BLACK;
                x->parent->parent->color = TOOLS_NODE_RED;
                rotateLeft(rbt, x->parent->parent);
            }
        }
    }
    rbt->root->color = TOOLS_NODE_BLACK;
}

static TOOLSresult
toolsRbtInsertCheck(tRbtree *rbt, void *key, tRbtNode **pParent)
{
    tRbtNode *current, *parent = NULL;

    // find future parent
    current = rbt->root;
    parent = 0;
    while (current != SENTINEL) {
        int rc = rbt->compare(key, current->key);

        if (rbt->intersect(key, current->key))
            return TOOLS_ERROR_DUPLICATE_KEY;

        parent = current;
        current = (rc < 0) ? current->left : current->right;
    }

    if (pParent)
        *pParent = parent;

    return TOOLS_SUCCESS;
}

int
toolsRbtCanInsertKey(tRbtree *rbt, void *key)
{
    int ret = 0;

    if (!rbt)
        return 0;

    ret = !!(toolsRbtInsertCheck(rbt, key, NULL) == TOOLS_SUCCESS);

    return ret;
}

TOOLSresult
toolsRbtInsert(tRbtree *rbt, void *key, void *val)
{
    // allocate node for data and insert in tree
    tRbtNode *parent, *x;
    TOOLSresult rbtStatus = TOOLS_SUCCESS;

    // find future parent
    rbtStatus = toolsRbtInsertCheck(rbt, key, &parent);
    if (rbtStatus != TOOLS_SUCCESS)
        return rbtStatus;

    // setup new node
    if ((x = calloc (1, sizeof(*x))) == 0)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    x->parent = parent;
    x->left = SENTINEL;
    x->right = SENTINEL;
    x->color = TOOLS_NODE_RED;
    x->key = key;
    x->val = val;

    // insert node in tree
    if (parent) {
        if (rbt->compare(key, parent->key) < 0)
            parent->left = x;
        else
            parent->right = x;
    }
    else
        rbt->root = x;

    insertFixup(rbt, x);

    return TOOLS_SUCCESS;
}

static void
deleteFixup(tRbtree *rbt, tRbtNode *x)
{
    // maintain red-black tree balance after deleting node x
    while (x != rbt->root && x->color == TOOLS_NODE_BLACK) {
        if (x == x->parent->left) {
            tRbtNode *w = x->parent->right;
            if (w->color == TOOLS_NODE_RED) {
                w->color = TOOLS_NODE_BLACK;
                x->parent->color = TOOLS_NODE_RED;
                rotateLeft (rbt, x->parent);
                w = x->parent->right;
            }

            if (w->left->color == TOOLS_NODE_BLACK && w->right->color == TOOLS_NODE_BLACK) {
                w->color = TOOLS_NODE_RED;
                x = x->parent;
            }
            else {
                if (w->right->color == TOOLS_NODE_BLACK) {
                    w->left->color = TOOLS_NODE_BLACK;
                    w->color = TOOLS_NODE_RED;
                    rotateRight (rbt, w);
                    w = x->parent->right;
                }
                w->color = x->parent->color;
                x->parent->color = TOOLS_NODE_BLACK;
                w->right->color = TOOLS_NODE_BLACK;
                rotateLeft (rbt, x->parent);
                x = rbt->root;
            }
        }
        else {
            tRbtNode *w = x->parent->left;
            if (w->color == TOOLS_NODE_RED) {
                w->color = TOOLS_NODE_BLACK;
                x->parent->color = TOOLS_NODE_RED;
                rotateRight (rbt, x->parent);
                w = x->parent->left;
            }
            if (w->right->color == TOOLS_NODE_BLACK && w->left->color == TOOLS_NODE_BLACK) {
                w->color = TOOLS_NODE_RED;
                x = x->parent;
            }
            else {
                if (w->left->color == TOOLS_NODE_BLACK) {
                    w->right->color = TOOLS_NODE_BLACK;
                    w->color = TOOLS_NODE_RED;
                    rotateLeft (rbt, w);
                    w = x->parent->left;
                }
                w->color = x->parent->color;
                x->parent->color = TOOLS_NODE_BLACK;
                w->left->color = TOOLS_NODE_BLACK;
                rotateRight (rbt, x->parent);
                x = rbt->root;
            }
        }
    }
    x->color = TOOLS_NODE_BLACK;
}

TOOLSresult
toolsRbtErase(tRbtree *rbt, tRbtIterator i)
{
    tRbtNode *x, *y;
    tRbtNode *z = i;

    if (z->left == SENTINEL || z->right == SENTINEL) {
        // y has a SENTINEL node as a child
        y = z;
    }
    else {
        // find tree successor with a SENTINEL node as a child
        y = z->right;
        while (y->left != SENTINEL) y = y->left;
    }

    // x is y's only child
    if (y->left != SENTINEL)
        x = y->left;
    else
        x = y->right;

    // remove y from the parent chain
    x->parent = y->parent;
    if (y->parent) {
        if (y == y->parent->left)
            y->parent->left = x;
        else
            y->parent->right = x;
    }
    else
        rbt->root = x;

    if (y != z) {
        z->key = y->key;
        z->val = y->val;
    }


    if (y->color == TOOLS_NODE_BLACK)
        deleteFixup (rbt, x);

    free (y);

    return TOOLS_SUCCESS;
}

tRbtIterator
toolsRbtNext(tRbtree *rbt, tRbtIterator it)
{
    tRbtNode *i = it;

    if (i->right != SENTINEL) {
        // go right 1, then left to the end
        for (i = i->right; i->left != SENTINEL; i = i->left);
    }
    else {
        // while you're the right child, chain up parent link
        tRbtNode *p = i->parent;
        while (p && i == p->right) {
            i = p;
            p = p->parent;
        }

        // return the "inorder" node
        i = p;
    }
    return (i != SENTINEL) ? i : NULL;
}

tRbtIterator
toolsRbtBegin(tRbtree *rbt)
{
    // return pointer to first value
    tRbtNode *i;
    for (i = rbt->root; i->left != SENTINEL; i = i->left);
    return (i != SENTINEL) ? i : NULL;
}

tRbtIterator
toolsRbtEnd(tRbtree *rbt)
{
    // return pointer to one past last value
    return NULL;
}

void
toolsRbtKeyValue(tRbtIterator it, void **key, void **val)
{
    tRbtNode *i = it;

    if (key)
        *key = i->key;

    if (val)
        *val = i->val;
}


void*
toolsRbtFind(tRbtree *rbt, void *key)
{
    tRbtNode *current;
    int rc;

    current = rbt->root;
    while (current != SENTINEL) {
        rc = rbt->compare(key, current->key);
        if (rc == 0)
            return current;
        current = (rc < 0) ? current->left : current->right;
    }
    return NULL;
}

void*
toolsRbtIntersect(tRbtree *rbt, void *key)
{
    tRbtNode *current;
    int rc;

    current = rbt->root;
    while (current != SENTINEL) {
        rc = rbt->compare(key, current->key);
        if (rbt->intersect(key, current->key))
            return current;
        current = (rc < 0) ? current->left : current->right;
    }
    return NULL;
}


static int
rbtCheckHelp(tRbtNode *p, tRbtree *rbt, tRbtNode *_parent)
{
    static int BlackHeight;
    int bh = 0;
    tRbtNode *sc = NULL;

    if (! _parent)
        BlackHeight = -1;

    if (p->parent != _parent)
        return 0;

    if (p->left != SENTINEL) {
        if (rbt->compare(p->key, p->left->key) < 0)
            return 0;
    }

    if (p->right != SENTINEL) {
        if (rbt->compare(p->right->key, p->key) < 0)
            return 0;
    }

    if (p->color == TOOLS_NODE_RED) {
        if (p->left->color != TOOLS_NODE_BLACK ||
            p->right->color != TOOLS_NODE_BLACK)
            return 0;
    }

    bh = 0;
    if ((p->left == SENTINEL) && (p->right == SENTINEL)) {
        for (sc = p; sc; sc = sc->parent)
            if (sc->color == TOOLS_NODE_BLACK)
                bh += 1;

        if (BlackHeight == -1)
            BlackHeight = bh;
        else if (bh != BlackHeight)
            return 0;
    }

    if (p->left != SENTINEL && (! rbtCheckHelp(p->left, rbt, p)))
        return 0;

    if (p->right != SENTINEL && (! rbtCheckHelp(p->right, rbt, p)))
        return 0;

    return 1;
}

static int
toolsRbtCheck(tRbtree *rbt)
{
    return rbtCheckHelp(rbt->root, rbt, NULL);
}

static TOOLSresult
rbtVisitHelper(tRbtree *rbt, tRbtNode *p, tRbtFunctor pfn, void *data)
{
    TOOLSresult res = TOOLS_SUCCESS;

    if (p == SENTINEL)
        return TOOLS_SUCCESS;

    res = rbtVisitHelper(rbt, p->left, pfn, data);
    if (res != TOOLS_SUCCESS)
        return res;

    if (pfn) {
        res = pfn(p->key, p->val, data);
        if (res != TOOLS_SUCCESS)
            return res;
    }

    res = rbtVisitHelper(rbt, p->right, pfn, data);
    return res;
}

TOOLSresult
toolsRbtApplyFunctor(tRbtree *rbt, tRbtFunctor pfn, void *data)
{
    if (!rbt)
        return TOOLS_ERROR_INVALID_VALUE;

    if (!pfn)
        return TOOLS_SUCCESS;

    return rbtVisitHelper(rbt, rbt->root, pfn, data);
}

