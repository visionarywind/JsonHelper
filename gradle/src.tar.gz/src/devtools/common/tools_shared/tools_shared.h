/*
 * Copyright 2007-2016 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: tools_shared.h
 *
 *   Description:
 *      Header for the shared tools library
 *
 ******************************************************************************/

#ifndef _TOOLS_SHARED_H
#define _TOOLS_SHARED_H

#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include "cuda_stdint.h"
#include "cuos.h"

/* Forward declare base debug frame structure (see tools_shared_dwarf.h) */
struct DwarfDebugFrame_st;

typedef uint32_t(*toolsDirectInstTestFun)(const uint64_t *inst);
typedef uint32_t(*toolsIndirectInstTestFun)(const uint64_t *inst, uint32_t offset);

typedef enum {
    TOOLS_SUCCESS = 0,
    TOOLS_ERROR_UNKNOWN,
    TOOLS_ERROR_INVALID_VALUE,
    TOOLS_ERROR_OUT_OF_MEMORY,
    TOOLS_ERROR_INVALID_ELF,
    TOOLS_ERROR_SECTION_NOT_FOUND,
    TOOLS_ERROR_SECTION_SIZE_MISMATCH,
    TOOLS_ERROR_SYMBOL_NOT_FOUND,
    TOOLS_ERROR_DUPLICATE_KEY,
    TOOLS_ERROR_KEY_NOT_FOUND,
    TOOLS_ERROR_SYMBOL_TYPE_MISMATCH,
    TOOLS_ERROR_SECTION_TYPE_MISMATCH,
    TOOLS_ERROR_FEATURE_NOT_IMPLEMENTED,

    TOOLS_ERROR_RWLOCK_INVALID_READER,
    TOOLS_ERROR_RWLOCK_INVALID_WRITER,
    TOOLS_ERROR_RWLOCK_HAS_WRITER,
    TOOLS_ERROR_RWLOCK_HAS_READER,
} TOOLSresult;

static int32_t isELF(const char *image)
{
    return (image[0] == 0x7f) && (image[1] == 'E') && (image[2] == 'L') && (image[3] == 'F');
}

static uint8_t isELF64(const char *image)
{
    return image[4] == 2;
}

#if defined(__cplusplus)
extern "C" {
#endif

TOOLSresult toolsElfLibInitialize(void);
TOOLSresult toolsElfLibFinalize(void);

TOOLSresult
toolsElf32ListKernelNames(const void *pimage,
                          char      **ret_kernel_names,
                          uint32_t    max_kernels,
                          uint32_t   *ret_num_kernels);

TOOLSresult
toolsElf64ListKernelNames(const void *pimage,
                          char      **ret_kernel_names,
                          uint32_t    max_kernels,
                          uint32_t   *ret_num_kernels);

TOOLSresult toolsElf32GetLineInfo(const void *pimage,
                                  const char *function_name,
                                  uint32_t pc,
                                  char **file_name,
                                  char **dir_name,
                                  uint32_t *line);

TOOLSresult toolsElf64GetLineInfo(const void *pimage,
                                  const char *function_name,
                                  uint32_t pc,
                                  char **file_name,
                                  char **dir_name,
                                  uint32_t *line);

TOOLSresult toolsElf32GetDebugFrame(const void *pimage,
                                    struct DwarfDebugFrame_st *frame);

TOOLSresult toolsElf64GetDebugFrame(const void *pimage,
                                    struct DwarfDebugFrame_st *frame);

uint32_t toolsElf32GetAbiVersion (const char *image);
uint32_t toolsElf64GetAbiVersion (const char *image);

TOOLSresult toolsElf32GetContainerFunc(const void *pimage,
                                       const char *function_name,
                                       uint32_t offset_pc,
                                       char **func_name,
                                       uint32_t *func_offset);

TOOLSresult toolsElf64GetContainerFunc(const void *pimage,
                                       const char *function_name,
                                       uint32_t offset_pc,
                                       char **func_name,
                                       uint32_t *func_offset);

TOOLSresult toolsElf32GetRelatedFuncs(const void *pimage,
                                      const char *function_name,
                                      uint32_t has_indirect_calls,
                                      char **related_funcs,
                                      uint32_t max_related_funcs,
                                      uint32_t *num_related_funcs,
                                      toolsDirectInstTestFun directTestFun,
                                      uint32_t instSize);

TOOLSresult toolsElf64GetRelatedFuncs(const void *pimage,
                                      const char *function_name,
                                      uint32_t has_indirect_calls,
                                      char **related_funcs,
                                      uint32_t max_related_funcs,
                                      uint32_t *num_related_funcs,
                                      toolsDirectInstTestFun directTestFun,
                                      uint32_t instSize);

TOOLSresult toolsElf32GetCallgraphFuncs(const void *pimage,
                                        const char *function_name,
                                        char **callgraph_funcs,
                                        uint32_t max_callgraph_funcs,
                                        uint32_t *num_callgraph_funcs,
                                        toolsIndirectInstTestFun indirectTestFun,
                                        toolsDirectInstTestFun directTestFun,
                                        uint32_t instSize);

TOOLSresult toolsElf64GetCallgraphFuncs(const void *pimage,
                                        const char *function_name,
                                        char **callgraph_funcs,
                                        uint32_t max_callgraph_funcs,
                                        uint32_t *num_callgraph_funcs,
                                        toolsIndirectInstTestFun indirectTestFun,
                                        toolsDirectInstTestFun directTestFun,
                                        uint32_t instSize);

TOOLSresult toolsElf32GetTextSectionContents(const void *pimage,
                                             uint32_t symbolIx,
                                             char *buf,
                                             uint32_t buf_sz,
                                             uint32_t *written_sz);

TOOLSresult toolsElf64GetTextSectionContents(const void *pimage,
                                             uint32_t symbolIx,
                                             char *buf,
                                             uint32_t buf_sz,
                                             uint32_t *written_sz);

TOOLSresult toolsElf32GetCudaSMVersion(const void* image,
                                       uint32_t *sm_major,
                                       uint32_t *sm_minor);

TOOLSresult toolsElf64GetCudaSMVersion(const void* image,
                                       uint32_t *sm_major,
                                       uint32_t *sm_minor);

TOOLSresult toolsElf32GetAtomSysInstrOffsets(const void* pimage,
                                             const char* function_name,
                                             uint32_t *offsets,
                                             uint32_t buf_sz,
                                             uint32_t *offsets_sz);

TOOLSresult toolsElf64GetAtomSysInstrOffsets(const void* pimage,
                                             const char* function_name,
                                             uint32_t *offsets,
                                             uint32_t buf_sz,
                                             uint32_t *offsets_sz);

TOOLSresult toolsElf32GetCoopGroupInstrOffsets(const void* pimage,
                                               const char* function_name,
                                               uint32_t *offsets,
                                               uint32_t buf_sz,
                                               uint32_t *offsets_sz);

TOOLSresult toolsElf64GetCoopGroupInstrOffsets(const void* pimage,
                                               const char* function_name,
                                               uint32_t *offsets,
                                               uint32_t buf_sz,
                                               uint32_t *offsets_sz);

TOOLSresult toolsElf32GetPgoInfo(const void *pimage,
                                 uint32_t symbolIx,
                                 uint32_t *buf,
                                 uint32_t buf_sz,
                                 uint32_t *written_sz);

TOOLSresult toolsElf64GetPgoInfo(const void *pimage,
                                 uint32_t symbolIx,
                                 uint32_t *buf,
                                 uint32_t buf_sz,
                                 uint32_t *written_sz);

TOOLSresult toolsElf32GetAtomF16InstrOffsets(const void* pimage,
                                             const char* function_name,
                                             uint32_t *offsets,
                                             uint32_t buf_sz,
                                             uint32_t *offsets_sz);

TOOLSresult toolsElf64GetAtomF16InstrOffsets(const void* pimage,
                                             const char* function_name,
                                             uint32_t *offsets,
                                             uint32_t buf_sz,
                                             uint32_t *offsets_sz);

// buf_sw/written_sz apply to both offsets and regIds
TOOLSresult toolsElf32GetAtomF16RegMap(const void* pimage,
                                       const char* function_name,
                                       uint32_t *offsets,
                                       uint32_t *regIds,
                                       uint32_t buf_sz,
                                       uint32_t *written_sz);

// buf_sw/written_sz apply to both offsets and regIds
TOOLSresult toolsElf64GetAtomF16RegMap(const void* pimage,
                                       const char* function_name,
                                       uint32_t *offsets,
                                       uint32_t *regIds,
                                       uint32_t buf_sz,
                                       uint32_t *written_sz);

TOOLSresult toolsElf32GetWarpWideInstrOffsets(const void* pimage,
                                              const char* function_name,
                                              uint32_t *offsets,
                                              uint32_t buf_sz,
                                              uint32_t *offsets_sz);

TOOLSresult toolsElf64GetWarpWideInstrOffsets(const void* pimage,
                                              const char* function_name,
                                              uint32_t *offsets,
                                              uint32_t buf_sz,
                                              uint32_t *offsets_sz);

TOOLSresult toolsElf32StripHiddenSymbols(void* pimage);

TOOLSresult toolsElf64StripHiddenSymbols(void* pimage);

#if defined(__cplusplus)
}
#endif
#endif
