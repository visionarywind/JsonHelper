/*
 * Copyright 2007-2011 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "tools_shared_list.h"

#include <stdlib.h>

/* Structs */

/* Element/iterator */
typedef struct tListElem_st tListElem;

struct tListElem_st {
    tListElem *next;
    void *data;
};

struct tList_st {
    tListElem *head;
    tListElem *tail;

    size_t size;
};

/* Functions */

tList *toolsListNew(void)
{

    tList *l = malloc(sizeof(tList));
    if (!l)
        return NULL;

    l->head = l->tail = NULL;

    l->size = 0;

    return l;
}

TOOLSresult toolsListAppend(tList *l, void *e)
{

    tListElem *newE;

    if (!l)
        return TOOLS_ERROR_INVALID_VALUE;

    newE = malloc(sizeof(tListElem));
    if (!newE)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    newE->data = e;
    newE->next = NULL;

    ++l->size;

    if (!l->head) {
        l->head = newE;
        l->tail = newE;
        return TOOLS_SUCCESS;
    }

    l->tail->next = newE;
    l->tail = newE;
    return TOOLS_SUCCESS;
}

TOOLSresult toolsListAppendFront(tList *l, void *e)
{

    tListElem *newE;

    if (!l)
        return TOOLS_ERROR_INVALID_VALUE;

    newE = malloc(sizeof(tListElem));
    if (!newE)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    newE->data = e;
    newE->next = l->head;

    ++l->size;

    if (!l->head) {
        l->head = newE;
        l->tail = newE;
        return TOOLS_SUCCESS;
    }

    l->head = newE;
    return TOOLS_SUCCESS;
}

tListItr *toolsListGetIterator(const tList *l)
{
    if (!l)
        return NULL;

    return l->head;
}

tListItr *toolsListGetNext(const tListItr *i)
{
    if (!i)
        return NULL;

    return i->next;
}

void *toolsListGetElem(const tListItr *i)
{
    if (!i)
        return NULL;

    return i->data;
}

tListItr *toolsListGetTail(const tList *l)
{
    if (!l)
        return NULL;

    return l->tail;
}

TOOLSresult toolsListRemove(tList *l, void *e, tSingleFun del, uint8_t removeAllInstances)
{
    tListElem *cur, *next;
    if (!l)
        return TOOLS_ERROR_INVALID_VALUE;

    if (!l->head)
        return TOOLS_SUCCESS;

    /* This removes all matched head elements */
    while (e == l->head->data) {
        if (del)
            del(l->head->data, NULL);
        next = l->head->next;
        free(l->head);
        l->head = next;
        --(l->size);

        if (l->head == NULL) {
            l->tail = NULL;
            return TOOLS_SUCCESS;
        }

        if (!removeAllInstances)
            return TOOLS_SUCCESS;
    }

    cur = l->head;
    next = cur->next;
    while (next) {
        if (next->data == e) {
            if (del)
                del(next->data, NULL);
            cur->next = next->next;
            free(next);
            next = cur->next;
            --(l->size);
            if (cur->next == NULL)
                l->tail = cur;

            if (!removeAllInstances)
                return TOOLS_SUCCESS;
        }
        else {
            cur = next;
            next = next->next;
        }
    }

    return TOOLS_SUCCESS;
}

size_t toolsListSize(const tList *l)
{
    if (!l)
        return 0;

    return l->size;
}

TOOLSresult toolsListDelete(tList *l, tSingleFun del, void *funParam)
{
    tListElem *cur;
    if (!l)
        return TOOLS_ERROR_INVALID_VALUE;

    cur = l->head;
    while (cur) {
        tListElem *next = cur->next;
        if (del)
            del(cur->data, funParam);
        free(cur);
        cur = next;
    }

    free(l);
    return TOOLS_SUCCESS;
}

static void sort(tListElem **head, tLtEqFun lteq, size_t size, void *data)
{
    size_t half, i;
    tListElem *first, *second;
    tListElem *p1, *p2, *tail;

    if (!head || !lteq)
        return;

    first = second = *head;

    if (size < 2)
        return;

    half = size / 2;
    for (i = 0; i < half - 1; i++) {
        second = second->next;
    }

    p1 = second->next;
    second->next = NULL;
    second = p1;

    sort(&first, lteq, half, data);
    sort(&second, lteq, size - half, data);

    p1 = first;
    p2 = second;

    if (lteq(p1->data, p2->data, data)) {
        *head = p1;
        p1 = p1->next;
    }
    else {
        *head = p2;
        p2 = p2->next;
    }

    tail = *head;
    while (p1 && p2) {
        if (lteq(p1->data, p2->data, data)) {
            tail->next = p1;
            p1 = p1->next;
        }
        else {
            tail->next = p2;
            p2 = p2->next;
        }
        tail = tail->next;
    }

    if (p2) {
        tail->next = p2;
    }
    else if (p1) {
        tail->next = p1;
    }
    else {
        tail->next = NULL;
    }
}

TOOLSresult toolsListSort(tList *l, tLtEqFun lteq, void *data)
{
    size_t i;

    if (!l || !lteq)
        return TOOLS_ERROR_INVALID_VALUE;

    if (l->size < 2)
        return TOOLS_SUCCESS;

    sort(&(l->head), lteq, l->size, data);

    l->tail = l->head;

    for (i = 0; i < l->size - 1; ++i)
        l->tail = l->tail->next;

    return TOOLS_SUCCESS;

}
