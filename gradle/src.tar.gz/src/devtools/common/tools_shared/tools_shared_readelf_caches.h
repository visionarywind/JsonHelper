/*
 * Copyright 2013-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef _TOOLS_SHARED_READELF_CACHES_H
#define _TOOLS_SHARED_READELF_CACHES_H

#include "cuda_stdint.h"
#include "tools_shared.h"
#include "tools_shared_hashmap.h"
#include "tools_shared_rangemap.h"

#define NUM_BUCKETS_KERNEL_HASH_MAP 65

tHashMap *elfModuleHashMap;

typedef struct LineCacheRecord_st       LineCacheRecord;
typedef struct KernelCacheRecord_st     KernelCacheRecord;
typedef struct FileCacheRecord_st       FileCacheRecord;
typedef struct DirCacheRecord_st        DirCacheRecord;
typedef struct DebugLineState_st        DebugLineState;
typedef struct DebugLineSection_st      DebugLineSection;
typedef struct ElfModuleCacheRecord_st  ElfModuleCacheRecord;

struct LineCacheRecord_st {
    uint32_t line, file_num;
    DebugLineSection *dls;
};

struct KernelCacheRecord_st {
    char        *name;
    char        *reloc_loc;
    uint8_t      lineCacheComplete;
    tRangeMap    *rmap;
};

struct FileCacheRecord_st {
    char        *fileName;
    uint32_t     fileIdx;
    uint32_t     dirName;
};

struct DirCacheRecord_st {
    char        *dirName;
    uint32_t     dirIdx;
};

struct DebugLineState_st {
    char              *ptr;
    char              *end;
    signed char        line_base;
    uint32_t           address, prev_address;
    uint32_t           file, prev_file;
    uint32_t           line, prev_line;
    uint32_t           total_length;
    unsigned char      min_instr_len;
    unsigned char      line_range;
    unsigned char      opcode_base;
    KernelCacheRecord *currentKernel;
};

struct DebugLineSection_st {
    DebugLineState     state;
    uint32_t           num_of_files;       // rw
    uint32_t           num_of_dirs;        // rw
    uint64_t           dirTableByteSize;   // size in bytes of the directory table in this elf
    uint64_t           fileTableByteSize;  // size in bytes of the file table in this elf
    FileCacheRecord   *fileCache;
    DirCacheRecord    *dirCache;
    char              *debugLineSectionPtr;
};

struct ElfModuleCacheRecord_st {
    void              *image;
    void              *symtab;
    size_t             symtab_size;
    char              *strtab;
    size_t             strtab_size;
    tHashMap          *kernelHashMapByName;
    tHashMap          *kernelHashMapByRelocLoc;
    tList             *debugLineSectionList;
    tListItr          *DLSiter;
};

/************************** INSERT FUNCTIONS *********************************/

TOOLSresult insertIntoElfModuleCache(void    *pimage,
                                     char    *debugLineSectionPtr,
                                     char    *debugLineSectionPtrEnd,
                                     void    *symtab,
                                     size_t   symtab_size,
                                     void    *strtab,
                                     size_t   strtab_size,
                                     ElfModuleCacheRecord **ret_elfModule);

TOOLSresult insertIntoLineCache(KernelCacheRecord *kernel,
                                DebugLineSection *dls,
                                uint32_t lo_addr,
                                uint32_t hi_addr,
                                uint32_t line,
                                uint32_t file);

/************************** SEARCH FUNCTIONS *********************************/

TOOLSresult getDirCache(DebugLineSection *dls,
                        uint32_t   dir_num, char **ret_dir_name);

TOOLSresult getFileCache(DebugLineSection *dls,
                         uint32_t   file_num,
                         char     **ret_file_name,
                         uint32_t  *ret_dir_num);


ElfModuleCacheRecord* searchElfModuleCache(void *image);

KernelCacheRecord* searchKernelCacheByRelocLoc(ElfModuleCacheRecord *emcr,
                                               char *reloc_loc);

KernelCacheRecord* searchKernelCacheByName(ElfModuleCacheRecord *emcr,
                                           const char *kernel_name);

LineCacheRecord* searchLineCache(KernelCacheRecord *targetKernel, uint32_t pc);

DebugLineSection* setDLSActiveStart(ElfModuleCacheRecord *emcr);
DebugLineSection* setDLSActiveNext(ElfModuleCacheRecord *emcr);
DebugLineSection* getDLSActive(ElfModuleCacheRecord *emcr);

TOOLSresult getLineCacheInfo(LineCacheRecord      *lcRecord,
                             char       **ret_file_name,
                             char       **ret_dir_name,
                             uint32_t    *ret_line);

/********************** DESTROY FUNCTIONS ************************************/

void destroyElfModuleCache (void);

#endif
