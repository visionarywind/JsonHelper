/*
 * Copyright 2007-2012 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: tools_shared_common_readelf.h
 *
 *   Description:
 *       Common includes for ELF/DWARF manipulation
 *
 ******************************************************************************/
#ifndef TOOLS_SHARED_READELF_COMMON_H
#define TOOLS_SHARED_READELF_COMMON_H

#include "tools_shared.h"
#include "tools_shared_list.h"
#include "tools_shared_hashmap.h"

#define ELF_MAX_RELOC_INST_WORDS 2

typedef struct elfReloc_st elfReloc;
typedef struct elfRelocFunc_st elfRelocFunc;
typedef struct elfRelocMod_st elfRelocMod;

struct elfReloc_st {
    uint32_t        targetshndx;
    uint64_t        targetInst[ELF_MAX_RELOC_INST_WORDS];
    uint32_t        numTargetInst;
    char            *targetname;
    uint32_t        offset;
    elfRelocFunc    *relfunc;
};

struct elfRelocFunc_st {
    tHashMap        *offsetMap;     // Map from offset -> elfReloc*
    elfRelocMod     *relmod;
    uint32_t        shndx;
    char            *name;
    uint32_t        directRelocCount;
    tHashMap       *directRelocMap; // Map from shndx -> elfReloc*
};

struct elfRelocMod_st {
    tHashMap            *funcMap;      // Shndx -> elfRelocFunc*
    uint32_t            indirectRelocCount;
    tHashMap            *indirectRelocMap; // Shndx -> elfReloc*
    char                *image;
};

// Function Declarations

TOOLSresult createElfReloc(elfReloc **preloc, elfRelocFunc *relfunc,
                           elfRelocMod *relmod,
                           uint32_t targetshndx, uint64_t *targetInst, uint32_t numTargetInst,
                           char *targetname, uint32_t offset, uint32_t isDirect);
TOOLSresult destroyElfReloc(elfReloc *reloc);
TOOLSresult createElfRelocFunc(elfRelocFunc **prelfunc, elfRelocMod *relmod,
                               uint32_t shndx, char *name);
TOOLSresult destroyElfRelocFunc(elfRelocFunc *relfun);

TOOLSresult createElfRelocModule(elfRelocMod **prelmod, const void *image);
TOOLSresult destroyElfRelocModule(elfRelocMod *relmod);

elfRelocFunc* getRelocFuncByShndx(elfRelocMod *relmod, uint32_t shndx);

elfReloc* getRelocByOffset(elfRelocFunc *relfunc, uint32_t offset);

uint32_t decodeULEB(char **pptr);

#endif
