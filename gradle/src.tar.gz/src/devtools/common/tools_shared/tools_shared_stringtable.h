/*
 * Copyright 2007-2011 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef _TOOLS_SHARED_STRINGTABLE_H
#define _TOOLS_SHARED_STRINGTABLE_H

#include <cuda_inttypes.h>
#include "tools_shared.h"

/* Structs */
typedef struct tStringTable_st tStringTable;

#if defined(__cplusplus)
extern "C" {
#endif

/* Functions */

/* Creates and returns a new empty string table
 * size - initial size of the string table
 * The map needs to be freed by caller.
 * Returns NULL if failed.
 */
tStringTable* toolsStringTableNew(size_t size);

/* Deletes a string table.
 */
TOOLSresult toolsStringTableDelete(tStringTable *tbl);

/* Adds a string to the string table and returns its offset from the start.
 * This function will resize the table if needed.
 * tbl - string table to add into
 * str - string to add
 * Returns the offset of the string in the table or 0 on error
 */
size_t toolsStringTableAddString(tStringTable *tbl, const char *str);

/* Get the base pointer of a string table
 * tbl - string table
 * Returns a const char pointer to string table representation or NULL on error
 */
const char* toolsStringTableGetTable(tStringTable *tbl);

/* Get a string at a given index
 * tbl - string table
 * index - index of the string
 * Returns a const char pointer to string or NULL on error
 */
const char* toolsStringTableGetString(tStringTable *tbl, size_t index);

/* Get the size of the string table
 * tbl - string table
 * Returns the size of the string table or 0 on error
 */
size_t toolsStringTableGetSize(tStringTable *tbl);

#if defined(__cplusplus)
}
#endif

#endif
