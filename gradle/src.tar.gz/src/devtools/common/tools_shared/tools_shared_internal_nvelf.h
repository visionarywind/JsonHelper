/*
 * NVIDIA_COPYRIGHT_BEGIN
 *
 * Copyright (c) 2009-2019, NVIDIA CORPORATION.  All rights reserved.
 *
 * NVIDIA CORPORATION and its licensors retain all intellectual property
 * and proprietary rights in and to this software, related documentation
 * and any modifications thereto.  Any use, reproduction, disclosure or
 * distribution of this software and related documentation without an express
 * license agreement from NVIDIA CORPORATION is strictly prohibited.
 *
 * NVIDIA_COPYRIGHT_END
 */

#ifndef nvelf_INCLUDED
#define nvelf_INCLUDED

/*--------------------------------- Includes ---------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------------- Types -----------------------------------*/

typedef unsigned char      elfByte;
typedef unsigned short     elfHalf;
typedef unsigned int       elfWord;
typedef signed int         elfSword;
typedef unsigned long long elfXword;
typedef signed long long   elfSxword;

typedef unsigned int       elf32Addr;
typedef unsigned int       elf32Off;
typedef unsigned long long elf64Addr;
typedef unsigned long long elf64Off;

/*---------------------------------- Header ----------------------------------*/

typedef struct {
  elfWord        magic;                      // 0x7f,0x45,0x4c,0x46   
  elfByte        oclass;                     // Object file class   
  elfByte        data;                       // Data encoding         
  elfByte        formatVersion;              // Object format version 
  elfByte        abi;                        // OS application binary interface
  elfByte        abiVersion;                 // Version of abi                  
  elfByte        padd[7];                    // Elf ident padding       
  elfHalf        type;                       // Object file type    
  elfHalf        machine;                    // Architecture  
  elfWord        version;                    // Object file version   
  elf32Addr      entry;                      // Entry point virtual address     
  elf32Off       phoff;                      // Program header table file offset
  elf32Off       shoff;                      // Section header table file offset
  elfWord        flags;                      // Processor-specific flags      
  elfHalf        ehsize;                     // ELF header size in bytes        
  elfHalf        phentsize;                  // Program header table entry size
  elfHalf        phnum;                      // Program header table entry count 
  elfHalf        shentsize;                  // Section header table entry size 
  elfHalf        shnum;                      // Section header table entry count
  elfHalf        shstrndx;                   // Section header string table index
} elf32FileHeader;

typedef struct {
  elfWord        magic;                      // 0x7f,0x45,0x4c,0x46   
  elfByte        oclass;                     // Object file class   
  elfByte        data;                       // Data encoding         
  elfByte        formatVersion;              // Object format version 
  elfByte        abi;                        // OS application binary interface
  elfByte        abiVersion;                 // Version of abi                  
  elfByte        padd[7];                    // Elf ident padding       
  elfHalf        type;                       // Object file type    
  elfHalf        machine;                    // Architecture  
  elfWord        version;                    // Object file version   
  elf64Addr      entry;                      // Entry point virtual address     
  elf64Off       phoff;                      // Program header table file offset
  elf64Off       shoff;                      // Section header table file offset
  elfWord        flags;                      // Processor-specific flags      
  elfHalf        ehsize;                     // ELF header size in bytes        
  elfHalf        phentsize;                  // Program header table entry size
  elfHalf        phnum;                      // Program header table entry count
  elfHalf        shentsize;                  // Section header table entry size 
  elfHalf        shnum;                      // Section header table entry count
  elfHalf        shstrndx;                   // Section header string table index
} elf64FileHeader;
// if shoff is 0 then use size from section 0

#define ELFMAGIC            0x7f454c46U      // This is in big endian
#define ELFMAGIC_LSB        0x464c457fU      // This is in little endian
#define ELFCLASS32                   1       // 32 bit object file
#define ELFCLASS64                   2       // 64 bit object file
#define ELFDATA2LSB                  1       // Little endian object file
#define ELFDATA2MSB                  2       // Big endian object file

#define ET_REL                       1       // Relocatable file
#define ET_EXEC                      2       // Executable file
#define ET_DYN                       3       // Shared object file
#define ET_CORE                      4       // Core file
#define ET_LOPROC               0xff00       // Start processor-specific
#define ET_EWP               ET_LOPROC       // Extensible Whole Program
#define ET_HIPROC               0xffff       // End processor-specific

#define EV_NONE                      0       // Invalid version
#define EV_CURRENT                   1       // Current version

#define ELFOSABI_CUDA             0x33       // CUDA ABI
#define ELFOSABIV_16BIT              0       // 16bit ctaid.x size
#define ELFOSABIV_32BIT              1       // 32bit ctaid.x size
#define ELFOSABIV_RELOC              2       // relocs in dwarf
#define ELFOSABIV_ABI                3       // fermi abi
#define ELFOSABIV_SYSCALL            4       // syscall support
#define ELFOSABIV_ABI2               5       // updated abi for Fermi & Kepler
#define ELFOSABIV_ABI3               6       // revised r16-19
#define ELFOSABIV_ABI4               7       // runtime jit link
#define ELFOSABIV_LATEST             7       // latest abi version

#define EM_386                       3       // x86 machine
#define EM_PPC64                    21       // PowerPC 64-bit
#define EM_ARM                      40       // ARM
#define EM_X86_64                   62       // x86_64
#define EM_AARCH64                 183       // ARM 64bit
#define EM_CUDA                    190U      // NVIDIA CUDA architecture

#define EF_CUDA_SM10                10       // SM_1.0
#define EF_CUDA_SM11                11       // SM_1.1
#define EF_CUDA_SM12                12       // SM_1.2
#define EF_CUDA_SM13                13       // SM_1.3
#define EF_CUDA_SM20                20       // SM_2.0
#define EF_CUDA_SM21                21       // SM_2.1
#define EF_CUDA_SM30                30       // SM_3.0
#define EF_CUDA_SM32                32       // SM_3.2
#define EF_CUDA_SM35                35       // SM_3.5
#define EF_CUDA_SM37                37       // SM_3.7
#define EF_CUDA_SM50                50       // SM_5.0
#define EF_CUDA_SM52                52       // SM_5.2
#define EF_CUDA_SM53                53       // SM_5.3
#define EF_CUDA_SM60                60       // SM_6.0
#define EF_CUDA_SM61                61       // SM_6.1
#define EF_CUDA_SM62                62       // SM_6.2
#define EF_CUDA_SM70                70       // SM_7.0
#define EF_CUDA_SM72                72       // SM_7.2
#define EF_CUDA_SM73                73       // SM_7.3
#define EF_CUDA_SM75                75       // SM_7.5
#define EF_CUDA_SM80                80       // SM_8.0
#define EF_CUDA_SM82                82       // SM_8.2
#define EF_CUDA_SM86                86       // SM_8.6
#define EF_CUDA_SM87                87       // SM_8.7
#define EF_CUDA_SM_MASK          0x0ffU
#define EF_CUDA_SM(e)            ((e) & EF_CUDA_SM_MASK)
#define SET_EF_CUDA_SM(e,v)      ((e) |= ((v) & EF_CUDA_SM_MASK))
/* Have separate bits for virtual compute sm version that was compiled to, 
 * which could be different from final sm.
 * Reuse existing SM bit values, but shift them over */
#define EF_CUDA_VIRTUAL_SM_MASK  0xff0000U
#define EF_CUDA_VIRTUAL_SM(e)       (((e) & EF_CUDA_VIRTUAL_SM_MASK) >> 16)
#define EF_CUDA_PTX_SM(e)           EF_CUDA_VIRTUAL_SM(e)
#define SET_EF_CUDA_VIRTUAL_SM(e,v) ((e) |= (((v) << 16) & EF_CUDA_VIRTUAL_SM_MASK))
#define CLEAR_EF_CUDA_VIRTUAL_SM(e) ((e) &= ~EF_CUDA_VIRTUAL_SM_MASK)

#define EF_CUDA_TEXMODE_UNIFIED     0x100
#define EF_CUDA_TEXMODE_INDEPENDENT 0x200
#define EF_CUDA_64BIT_ADDRESS       0x400
#define EF_CUDA_SW_1729687          0x800 /* DEPRECATED: Whether SM6* has SW WAR */
#define EF_CUDA_SW_1729687_v2      0x1000 /* DEPRECATED: Can be reused(only on internal binaries), Whether SM6* has updated SW WAR */

/*---------------------------------- Section ---------------------------------*/

typedef struct {
  elfWord        name;                       // Section name, string table index
  elfWord        type;                       // Type of section                 
  elfWord        flags;                      // Miscellaneous section attributes
  elf32Addr      addr;                       // Section virtual addr at execution 
  elf32Off       offset;                     // Section file offset             
  elfWord        size;                       // Size of section in bytes       
  elfWord        link;                       // Index of another section        
  elfWord        info;                       // Additional section information 
  elfWord        addralign;                  // Section alignment             
  elfWord        entsize;                    // Entry size if section holds table 
} elf32SectionHeader;

typedef struct {
  elfWord        name;                       // Section name, string table index
  elfWord        type;                       // Type of section                 
  elfXword       flags;                      // Miscellaneous section attributes
  elf64Addr      addr;                       // Section virtual addr at execution 
  elf64Off       offset;                     // Section file offset             
  elfXword       size;                       // Size of section in bytes        
  elfWord        link;                       // Index of another section        
  elfWord        info;                       // Additional section information 
  elfXword       addralign;                  // Section alignment             
  elfXword       entsize;                    // Entry size if section holds table 
} elf64SectionHeader;

/*
 * Type
 */
#define SHT_NULL            0x00U            // NULL section
#define SHT_PROGBITS        0x01U            // Loadable program data 
#define SHT_SYMTAB          0x02U            // Symbol table           
#define SHT_STRTAB          0x03U            // String table                 
#define SHT_RELA            0x04U            // Relocation table with addents  
#define SHT_HASH            0x05U            // Hash table                    
#define SHT_DYNAMIC         0x06U            // Information for dynamic linking 
#define SHT_NOTE            0x07U            // Information that marks file     
#define SHT_NOBITS          0x08U            // Section does not have data in file
#define SHT_REL             0x09U            // Relocation table without addents
#define SHT_SHLIB           0x0aU            // Reserved                        
#define SHT_DYNSYM          0x0bU            // Dynamic linker symbol table
#define SHT_INIT_ARRAY      0x0eU            // Array of pointers to init funcs 
#define SHT_FINI_ARRAY      0x0fU            // Array of function to finish funcs   
#define SHT_PREINIT_ARRAY   0x10U            // Array of pointers to pre-init functions
#define SHT_GROUP           0x11U            // Section group
#define SHT_SYMTAB_SHNDX    0x12U            // Table of 32bit symtab shndx
#define SHT_LOOS      0x60000000U            // Start OS-specific.
#define SHT_HIOS      0x6fffffffU            // End OS-specific type
#define SHT_LOPROC    0x70000000U            // Start of processor-specific
#define SHT_CUDA_INFO (SHT_LOPROC+0)         // Info section
#define SHT_CUDA_CALLGRAPH (SHT_LOPROC+1)    // Callgraph section
#define SHT_CUDA_PROTOTYPE (SHT_LOPROC+2)    // Prototype section
#define SHT_CUDA_RESOLVED_RELA (SHT_LOPROC+3) // Resolved rela section
#define SHT_CUDA_METADATA (SHT_LOPROC+4)     // metadata section
#define SHT_CUDA_PGO_INFO (SHT_LOPROC+5)     // PGO section
#define SHT_HIPROC    0x7fffffffU            // End of processor-specific
#define SHT_LOUSER    0x80000000U            // Start of application-specific
#define SHT_HIUSER    0x8fffffffU            // End of application-specific

/*
 * Flags
 */
#define SHF_WRITE        0x0001U             // Writable during execution
#define SHF_ALLOC        0x0002U             // Occupies memory during execution
#define SHF_EXECINSTR    0x0004U             // Executable machine instructions 
#define SHF_EXEC       SHF_EXECINSTR
#define SHF_MERGE        0x0010U             // Data in this section can be merged
#define SHF_STRINGS      0x0020U             // Contains null terminated strings
#define SHF_INFO_LINK    0x0040U             // Info field contains section header table index
#define SHF_LINK       SHF_INFO_LINK
#define SHF_LINK_ORDER   0x0080U             // Preserve section order when linking 
#define SHF_OS_NONCONFORMING 0x0100U         // Requires OS-specific processing
#define SHF_GROUP        0x0200U             // Section is member of a group
#define SHF_TLS          0x0400U             // Section holds thread-local data
#define SHF_COMPRESSED   0x0800U             // Compressed data
#define SHF_MASKOS       0x0ff00000U         // os-specific flags
#define SHF_BARRIER_MASK 0x07f00000U         // bits for number of barriers
#define GET_SHF_BARRIERS(f)    (((elfWord)(f) & SHF_BARRIER_MASK) >> 20)
#define SHF_BARRIERS(s)        GET_SHF_BARRIERS((s)->flags)
#define SET_SHF_BARRIERS(f,b)  (f) = (((b << 20) & SHF_BARRIER_MASK) | (f & ~SHF_BARRIER_MASK))
#define SHF_MASKPROC     0xf0000000U         // proc-specific flags

/* 
 * Special section index
 */
#define SHN_UNDEF             0U             // Undefined section 
#define SHN_LORESERVE    0xff00U             // lower bound of reserved indexes
#define SHN_ABS          0xfff1U             // Associated symbol is absolute 
#define SHN_COMMON       0xfff2U             // Associated symbol is common
#define SHN_XINDEX       0xffffU             // Index is in symtab_shndx

/*
 * Accessors for sh_info field
 * 8 bits for #regs, 24 bits for entry index
 */
#define SHI_ENTRY_INDEX_MASK      0x00ffffffU
#define SHI_REGISTERS_MASK        0xff000000U
#define GET_SHI_REGISTERS(i)      (((i) & SHI_REGISTERS_MASK) >> 24)
#define SHI_REGISTERS(s)          GET_SHI_REGISTERS((s)->info)
#define GET_SHI_ENTRY_INDEX(i)    ((i) & SHI_ENTRY_INDEX_MASK)
#define SHI_ENTRY_INDEX(s)        GET_SHI_ENTRY_INDEX((s)->info)
#define CREATE_SHI_REG_ENTRY(r,e) ((((r) << 24) & SHI_REGISTERS_MASK) | ((e) & SHI_ENTRY_INDEX_MASK))
#define SET_SHI_ENTRY_INDEX(i,e)  (i) = CREATE_SHI_REG_ENTRY(GET_SHI_REGISTERS(i), e)
#define SET_SHI_REGISTERS(i,r)    (i) = CREATE_SHI_REG_ENTRY((r),GET_SHI_ENTRY_INDEX(i))

/*
 * Special section names
 */
#define SHNAME_SHSTRTAB    ".shstrtab"       // section string table
#define SHNAME_STRTAB      ".strtab"         // string table
#define SHNAME_SYMTAB      ".symtab"         // symbol table
#define SHNAME_SYMTAB_SHNDX ".symtab_shndx"  // symbol table shndx array
#define SHNAME_TEXT        ".text."          // suffix with entry name
#define SHNAME_GLOBAL      ".nv.global"
#define SHNAME_GLOBAL_INIT ".nv.global.init"
#define SHNAME_CONSTANT    ".nv.constant"    // suffix with bank number
#define SHNAME_SHARED      ".nv.shared."     // suffix with entry name
#define SHNAME_LOCAL       ".nv.local."      // suffix with entry name
#define SHNAME_INFO        ".nv.info"        // possibly suffix with entry name
#define SHNAME_DEBUG       ".nv_debug"       // prefix for debug sections
#define SHNAME_CALLGRAPH   ".nv.callgraph"
#define SHNAME_PROTOTYPE   ".nv.prototype"
#define SHNAME_RESOLVEDRELOC ".nv.resolvedrela" // prefix for resolved relocs
#define SHNAME_METADATA    ".nv.metadata"
#define SHNAME_PGO_INFO    ".nv.pgoinfo."    // suffix with text section name

/*---------------------------------- Info Section -------------------------*/
/*
 * Info section elements are format,attribute,value tuples
 */

/* first word of each Info element */
typedef struct {
  elfByte       format;
  elfByte       attr;
  union {
    elfByte     bval;
    elfHalf     hval;
    elfHalf     size;  // value in following <size> bytes */
  } value;
} elfInfoElement;

#define EIFMT_ERROR 0   // should never see this
#define EIFMT_NVAL  1   // no value (named attribute)
#define EIFMT_BVAL  2   // byte value (1 byte)
#define EIFMT_HVAL  3   // half value (2 bytes)
#define EIFMT_SVAL  4   // sized value (2 bytes for size, then actual value)

/* 
 * sval is just array of "size" bytes"; should have mapping struct below,
 * where size == sizeof(struct).
 * Note that these structs must be at least 4 byte aligned; 
 * if struct needs 8 byte alignment, generator must potentially pad 
 * (use EIATTR_PAD) to that alignment (assume only need 8 byte align if elf64).
 */

/* 
 * Comments after each attribute tell val kind, 
 * type of sval if applicable ("-" if not),
 * and "(g)" if is in global nv.info section.
 */
#define EIATTR_ERROR                        0    // nval -
#define EIATTR_PAD                          1    // nval -
#define EIATTR_IMAGE_SLOT                   2    // sval elfInfoImageSlot
#define EIATTR_JUMPTABLE_RELOCS             3    // sval elfInfoJumpTableReloc
#define EIATTR_CTAIDZ_USED                  4    // nval -
#define EIATTR_MAX_THREADS                  5    // sval elfInfoMaxThread
#define EIATTR_IMAGE_OFFSET                 6    // sval elfInfoImageOffset
#define EIATTR_IMAGE_SIZE                   7    // sval elfInfoImageSize (g)
#define EIATTR_TEXTURE_NORMALIZED           8    // sval elfInfoTextureNormalizedCoord (g)
#define EIATTR_SAMPLER_INIT                 9    // sval elfInfoSamplerInitialization (g)
#define EIATTR_PARAM_CBANK                 10    // sval elfInfoParamCbank
#define EIATTR_SMEM_PARAM_OFFSETS          11    // sval elfInfoParamOffset[]
#define EIATTR_CBANK_PARAM_OFFSETS         12    // sval elfInfoParamOffset[]
/* EIATTR_{SMEM,CBANK}_PARAM_OFFSETS are deprecated by EIATTR_KPARAM_INFO */
#define EIATTR_SYNC_STACK                  13    // sval elfInfoSyncStack
/* EIATTR_SYNC_STACK is deprecated by EIATTR_CRS_STACK_SIZE */
#define EIATTR_TEXID_SAMPID_MAP            14    // sval elfInfoTextureSamplerAssociationList
#define EIATTR_EXTERNS                     15    // sval elfInfoExterns[]
#define EIATTR_REQNTID                     16    // sval elfInfoReqNtid
#define EIATTR_FRAME_SIZE                  17    // sval elfInfoFrameSize (g)
#define EIATTR_MIN_STACK_SIZE              18    // sval elfInfoMinStackSize (g)
#define EIATTR_SAMPLER_FORCE_UNNORMALIZED  19    // sval elfInfoForceUnnormalizedCoord (g)
#define EIATTR_BINDLESS_IMAGE_OFFSETS      20    // sval elfInfoBindlessOffsets
/* EIATTR_BINDLESS_IMAGE_OFFSETS is deprecated by R_CUDA_TEX_HEADER_INDEX */
#define EIATTR_BINDLESS_TEXTURE_BANK       21    // bval -
#define EIATTR_BINDLESS_SURFACE_BANK       22    // bval -
#define EIATTR_KPARAM_INFO                 23    // sval elfInfoKParam
#define EIATTR_SMEM_PARAM_SIZE             24    // hval -
/* EIATTR_SMEM_PARAM_SIZE is deprecated by EIATTR_KPARAM_INFO */
#define EIATTR_CBANK_PARAM_SIZE            25    // hval -
#define EIATTR_QUERY_NUMATTRIB             26    // sval elfInfoQueryNumAttrib
#define EIATTR_MAXREG_COUNT                27    // hval -
#define EIATTR_EXIT_INSTR_OFFSETS          28    // sval elfInfoExitInstrOffsets[]
#define EIATTR_S2RCTAID_INSTR_OFFSETS      29    // sval elfInfoS2RCtaidInstrOffsets[]
#define EIATTR_CRS_STACK_SIZE              30    // sval elfInfoCRSStackSize
#define EIATTR_NEED_CNP_WRAPPER            31    // nval -
#define EIATTR_NEED_CNP_PATCH              32    // nval -
#define EIATTR_EXPLICIT_CACHING            33    // nval -
#define EIATTR_ISTYPEP_USED                34    // nval - (g)
#define EIATTR_MAX_STACK_SIZE              35    // sval elfInfoMaxStackSize (g)
#define EIATTR_SUQ_USED                    36    // nval -
#define EIATTR_LD_CACHEMOD_INSTR_OFFSETS   37    // sval elfLdCacheModInstrOffsets[] 
#define EIATTR_LOAD_CACHE_REQUEST          38    // sval elfInfoLoadCacheRequest (g)
#define EIATTR_ATOM_SYS_INSTR_OFFSETS      39    // sval elfInfoAtomSysInstrOffsets[]
#define EIATTR_COOP_GROUP_INSTR_OFFSETS    40    // sval elfInfoCoopGroupInstrOffsets[]
#define EIATTR_COOP_GROUP_MASK_REGIDS      41    // sval elfInfoCoopGroupMaskRegIds[]
#define EIATTR_SW1850030_WAR               42    // nval -
#define EIATTR_WMMA_USED                   43    // nval -
#define EIATTR_HAS_PRE_V10_OBJECT          44    // nval -
#define EIATTR_ATOMF16_EMUL_INSTR_OFFSETS  45    // sval elfInfoAtomF16InstrOffsets[]
#define EIATTR_ATOM16_EMUL_INSTR_REG_MAP   46    // sval elfInfoAtomF16InstrOffsetRegNoPair[]
#define EIATTR_REGCOUNT                    47    // sval elfInfoRegCount (g)
#define EIATTR_SW2393858_WAR               48    // nval -
#define EIATTR_INT_WARP_WIDE_INSTR_OFFSETS 49    // sval elfInfoWarpWideInstrOffsets[]
#define EIATTR_SHARED_SCRATCH              50    // sval elfInfoSharedScratchArea
#define EIATTR_STATISTICS                  51    // sval elfInfoStatistics[]
#define EIATTR_ERROR_LAST                  52    // nval -

typedef elfWord elfSymtabIndex; // index into symbol table

/* Image (texture/surface/sampler) slot info */
typedef struct {
  elfSymtabIndex index;    // index to symbol table
  elfWord        slot;     // slot number
} elfInfoImageSlot;
#define elfImageEntry elfInfoImageSlot // deprecated name

/* JumpTable info */
typedef struct {
  elfWord       cbank;     // constant bank where the table is 
  elfWord       start;     // start address of table
  elfWord       size;      // size of table
} elfInfoJumpTableReloc;

typedef struct {
  elfWord       x,y,z;     // max threads in each dimension
} elfInfoMaxThread;

/* Image (texture/surface/sampler) offset info */
typedef struct {
  elfSymtabIndex index;    // index to symbol table
  elfHalf        offset;   // cbank offset
  elfHalf        paramindex;   // when passed as entry parameter
  elfHalf        numAttrib;    // number of attributes driver should populate for query
  elfHalf        reserved;
} elfInfoImageOffset;

typedef struct {
  elfSymtabIndex index;    // index to symbol table
  elfWord        width;
  elfWord        height;
  elfWord        depth;
} elfInfoImageSize;

/* Texture coordinates are normalized */
typedef struct {
  elfSymtabIndex index;    // index to symbol table
  elfWord        value;
} elfInfoTextureNormalizedCoord;

/* Sampler initialization */
typedef struct {
  elfSymtabIndex index;    // index to symbol table
  elfByte        addr_mode_0;
  elfByte        addr_mode_1;
  elfByte        addr_mode_2;
  elfByte        filter_mode;
} elfInfoSamplerInitialization;
/* values for SAMPLER_INIT addr_modes */
#define EIVALUE_UNKNOWN          -1
#define EIVALUE_ADDR_WRAP         0
#define EIVALUE_ADDR_MIRROR       1
#define EIVALUE_ADDR_CLAMP_OGL    2
#define EIVALUE_ADDR_CLAMP_EDGE   3
#define EIVALUE_ADDR_CLAMP_BORDER 4
/* values for SAMPLER_INIT filter_mode */
#define EIVALUE_FILTER_NEAREST    0
#define EIVALUE_FILTER_LINEAR     1

/* Sampler has force_unnormalized_coords attribute specified */
typedef struct {
    elfSymtabIndex  index;      //index to symbol table
    elfWord         value;
} elfInfoForceUnnormalizedCoord;

typedef struct {
  elfSymtabIndex index;    // index to cbank section symbol
  elfHalf        offset;   // offset of first cbank param
  elfHalf        bytes;    // size of params in cbank
} elfInfoParamCbank;

typedef elfWord elfInfoParamOffset;
/* 
 * The list of param offsets is arbitrary sized, 
 * so have to use element size field to know how big array is, e.g.
 * elfInfoParamOffset arr[elem.value.size/sizeof(elfInfoParamOffset)];
 */

/*
 * Should be either elfInfoCRSStackSize (new format) or elfInfoSyncStack.
 * If neither exists then assume 0 size.
 * elfInfoCRSStackSize uses EIVALUE_SIZE_UNKNOWN for recursion case 
 * where don't know value.
 */
typedef struct {
    elfHalf syncStackSize;    // size of control stack in bytes
    elfHalf maxSyncLevel;     // max sync level ( used for seperate compilation )
    elfHalf maxDiverLevel;    // max divergence level
    elfHalf maxCallDepth;     // max depth of call chain starting at this function
} elfInfoSyncStack;
#define EIVALUE_SIZE_UNKNOWN -1
typedef elfSword elfInfoCRSStackSize;

typedef struct {
  elfWord        textureSlot;   // slot number of texture
  elfWord        samplerSlot;   // slot number of sampler
}elfInfoTextureSamplerAssociationList;

typedef elfSymtabIndex elfInfoExterns;
/*
 * The list of externs is arbitrary sized, 
 * so use size field to know how big array is.
 * Each element of array is index to symbol table for extern. 
 */

/* Required work group size info */
typedef struct {
  elfWord       x,y,z;
}elfInfoReqNtid;

/* Function frame size */
typedef struct {
  elfSymtabIndex index;      // index to symbol table function
  elfWord        frameSize;  // size of function's stack frame
} elfInfoFrameSize;

/* Load cache request */
typedef struct {
    elfSymtabIndex index;      // index to symbol table function
    elfWord        requested;  // indicates whether cache was requested or not 
} elfInfoLoadCacheRequest;

/* Minimum stack size for entry */
/* StackSize can be EIVALUE_SIZE_UNKNOWN (e.g. recursion). */
/* Same struct used for max stack size, in which case size is max value. */
typedef struct {
  elfSymtabIndex index;      // index to symbol table entry
  elfSword       stackSize;  // minimum size of entry's stack
} elfInfoMinStackSize;
typedef elfInfoMinStackSize elfInfoMaxStackSize;

/* Offsets allocated for bindless textures/samplers/surfaces in kepler */
typedef struct {
  elfSymtabIndex index;      // index to symbol table entry
  elfWord        *offset;    // list of offsets
} elfInfoBindlessOffsets;

/* Number of attributes to populate for query descriptors */
typedef struct {
    elfByte     texUnifNumAttrib;   // Texref query numAttrib in unified mode
    elfByte     texIndNumAttrib;    // Texref query numAttrib in independent mode
    elfByte     sampIndNumAttrib;   // Samplerref query numAttrib in independent mode  
    elfByte     surfNumAttrib;      // Surfref query numAttrib
} elfInfoQueryNumAttrib;

#define EIVALUE_KIND_NONE                  0
#define EIVALUE_KIND_POINTER_LOCAL         1
#define EIVALUE_KIND_POINTER_SHARED        2
#define EIVALUE_KIND_POINTER_CONST         3
#define EIVALUE_KIND_POINTER_GLOBAL        4
#define EIVALUE_KIND_POINTER_GENERIC       5
#define EIVALUE_KIND_TEX                   6
#define EIVALUE_KIND_SURF                  7
#define EIVALUE_KIND_TEXSAMPLER            8

/* Kernel parameter information */
typedef struct {
    /* index to symbol table */
    elfSymtabIndex index;
    /* ordinal of parameter */
    elfHalf     ordinal;
    /* Allocated offset */
    elfHalf     offset;
    /* Pointee's log alignment */
    elfWord     logAlign        : 8;
    /* For non-pointer and non-image parameters holds EIVALUE_SPACE_NONE
       For pointer parameters, gives pointee's space. 
       For image parameters, gives images's type
    */
    elfWord     space        : 4;
    /* bank allocated for constant pointers on Tesla. On Fermi/kepler allocation for constant
       pointers is done by driver.
    */
    elfWord     cbankid      : 5;
    /* indicates if parameter reside in smem or cbank */
    elfWord     isSmemParam  : 1;
    /* size of parameter */
    elfWord     size         : 14;
} elfInfoKParam;

/*
 * The list of offsets of exit/S2R instructions are arbitrary sized,
 * so have to use element size field to know how big array is, e.g.
 * elfInfoExitInstrOffsets arr[elem.value.size/sizeof(elfInfoExitInstrOffsets)];
 */
typedef elfWord elfInfoExitInstrOffsets;
typedef elfWord elfLdCacheModInstrOffsets;
typedef elfWord elfInfoS2RCtaidInstrOffsets;
typedef elfWord elfInfoAtomSysInstrOffsets;
typedef elfWord elfInfoCoopGroupInstrOffsets;
typedef elfWord elfInfoWarpWideInstrOffsets;
typedef elfWord elfInfoCoopGroupMaskRegIds;
typedef elfWord elfInfoAtomF16InstrOffsets;

/* Pair of instruction offset and register for atom, 
 * ld instructions from atom.f16 emulation. 
 */
typedef struct {
    /* Offset of the instruction */
    elfWord instrOffset;
    /* register number which stores original address */
    elfHalf regNo;
    elfHalf filler;
} elfInfoAtomF16InstrOffsetRegNoPair;

/* Function register count */
typedef struct {
  elfSymtabIndex index;      // index to symbol table function
  elfWord        regCount;   // number of registers the function uses
} elfInfoRegCount;

typedef struct {
  elfWord start;  // start offset in shared memory
  elfWord size;   // size of scratch area
} elfInfoSharedScratchArea;

/* Array of statistics information */
typedef elfWord elfInfoStatistics;

/* The following are used to index the array to obtain the
 * respective statistics information. EIVALUE_STATS_SIZE
 * is the number of array elements to emit in ELF.
 */
#define EIVALUE_STATS_INSTS 0
#define EIVALUE_STATS_LOOPS 1
#define EIVALUE_STATS_BRANCHES 2
#define EIVALUE_STATS_DIV_BRANCHES 3
#define EIVALUE_STATS_SPILL_BYTES 4
#define EIVALUE_STATS_LOCAL_LOADS 5
#define EIVALUE_STATS_LOCAL_STORES 6
#define EIVALUE_STATS_GLOBAL_LOADS 7
#define EIVALUE_STATS_GLOBAL_STORES 8
#define EIVALUE_STATS_TEX_READS 9
#define EIVALUE_STATS_SURF_READS 10
#define EIVALUE_STATS_SURF_WRITES 11
/* The following is the size of the statistics array to emit in ELF and must be
 * updated as new indexes are added. */
#define EIVALUE_STATS_SIZE 12

/*---------------------------------- Program Segment -------------------------*/

typedef struct {
  elfWord        type;                       // Identifies program segment type 
  elf32Off       offset;                     // Segment file offset             
  elf32Addr      vaddr;                      // Segment virtual address         
  elf32Addr      paddr;                      // Segment physical address        
  elfWord        filesz;                     // Segment size in file            
  elfWord        memsz;                      // Segment size in memory          
  elfWord        flags;                      // Segment flags                   
  elfWord        align;                      // Segment alignment, file & memory
} elf32ProgramHeader;

typedef struct {
  elfWord        type;                       // Identifies program segment type 
  elfWord        flags;                      // Segment flags                   
  elf64Off       offset;                     // Segment file offset             
  elf64Addr      vaddr;                      // Segment virtual address         
  elf64Addr      paddr;                      // Segment physical address      
  elfXword       filesz;                     // Segment size in file            
  elfXword       memsz;                      // Segment size in memory          
  elfXword       align;                      // Segment alignment, file & memory
} elf64ProgramHeader;

/*
 * Type
 */
#define PT_NULL                0x00U              
#define PT_LOAD                0x01U         // Loadable program segment
#define PT_DYNAMIC             0x02U         // Dynamic linking information 
#define PT_INTERP              0x03U         // Program interpreter         
#define PT_NOTE                0x04U         // Auxiliary information       
#define PT_SHLIB               0x05U         // Reserved                    
#define PT_PHDR                0x06U         // Entry for header table      
#define PT_TLS                 0x07U         // Thread-local storage
#define PT_LOOS          0x60000000U         // Start of OS-specific
#define PT_CUDA_LOAD_ENTRY  PT_LOOS          // Loadable for particular entry

/*
 * Permissions
 */
#define PF_X           0x00000001U           // Executable machine code
#define PF_W           0x00000002U           // Writable during execution 
#define PF_R           0x00000004U           // Readable during execution 
#define PF_MASKOS      0x0ff00000U           // OS-specific
#define PF_MASKPROC    0xf0000000U           // processor-specific
// Standard elf only provides upper 12 bits for extensions, 
// but no one uses middle bits, and we want to store index to symtab entry,
// so use upper 24 bits.
#define GET_PF_CUDA_ENTRY_INDEX(i)  (i >> 8) // get symtab index for entry
#define SET_PF_CUDA_ENTRY_INDEX(i)  (i << 8) // set symtab index for entry


/*----------------------------------- Symbol ---------------------------------*/

typedef struct {
  elfWord        name;                       // Symbol name, index in string tbl
  elf32Addr      value;                      // Value of the symbol             
  elfWord        size;                       // Associated symbol size          
  elfByte        info;                       // Type and binding attributes     
  elfByte        other;                      // Extra flags                     
  elfHalf        shndx;                      // Associated section index        
} elf32Symbol;

typedef struct {
  elfWord        name;                       // Symbol name, index in string tbl
  elfByte        info;                       // Type and binding attributes     
  elfByte        other;                      // Extra flags                     
  elfHalf        shndx;                      // Associated section index        
  elf64Addr      value;                      // Value of the symbol             
  elfXword       size;                       // Associated symbol size          
} elf64Symbol;
// note that shndx may be SHN_XINDEX and thus be indirect


#define ELF_ST_BIND(s)  (((s)->info) >>  4)
#define ELF_ST_TYPE(s)  (((s)->info) & 0xf)
#define ELF_ST_INFO(b,t) (((b)<<4)+((t)&0xf))

/*
 * Type
 */
#define STT_NOTYPE             0             // No type known   
#define STT_OBJECT             1             // Data symbol   
#define STT_FUNC               2             // Code symbol   
#define STT_SECTION            3             // Section       
#define STT_FILE               4             // File          
#define STT_COMMON             5             // Common symbol 
#define STT_LOOS              10             // Start of OS-specific
#define STT_CUDA_TEXTURE      STT_LOOS       // texture
#define STT_CUDA_SAMPLER      STT_LOOS+1     // sampler
#define STT_CUDA_SURFACE      STT_LOOS+2     // surface
#define STT_CUDA_OBJECT       STT_LOOS+3     // see st_other for memory space

/*
 * Scope
 */
#define STB_LOCAL              0            // Symbol not visible outside object
#define STB_GLOBAL             1            // Symbol visible outside object   
#define STB_WEAK               2            // Weak symbol                    

/*
 * Other
 */
/* How to extract and insert information held in the st_other field.  */
#define ELF32_ST_VISIBILITY(o)  ((o) & 0x03)
/* For ELF64 the definitions are the same.  */
#define ELF64_ST_VISIBILITY(o)  ELF32_ST_VISIBILITY (o)
#define SET_ELF_ST_VISIBILITY(o,v)  (o = (ELF32_ST_VISIBILITY(v) | ((o) & ~0x03)))

/* Symbol visibility specification encoded in the st_other field.  */
#define STV_DEFAULT         0           // Default symbol visibility rules
#define STV_INTERNAL        1           // Processor specific hidden class;
                                        // for EM_CUDA, means it is never 
                                        // in ET_EXEC, e.g. compiler temps.
#define STV_HIDDEN          2           // Sym unavailable in other modules
#define STV_PROTECTED       3           // Not preemptible, not exported

#define ELF_ST_CUDA_MANAGED(o)   ((o) & 0x4)
#define STO_CUDA_MANAGED    4           // managed symbol
#define STO_CUDA_OBSCURE    8           // obscured symbol

#define STO_CUDA_ENTRY      0x10        // entry function

/* ST_CUDA_MEMSPACE only set for STT_CUDA_OBJECT */
#define ELF_ST_CUDA_MEMSPACE(o)  ((o) & 0xe0)
#define STO_CUDA_GLOBAL     0x20
#define STO_CUDA_SHARED     0x40
#define STO_CUDA_LOCAL      0x60
#define STO_CUDA_CONSTANT   0x80

/*
 * Special symbol names
 */
#define SYMNAME_UNIF_TEX_DESC_SIZE      ".nv.unified.texrefDescSize"
#define SYMNAME_IND_TEX_DESC_SIZE       ".nv.independent.texrefDescSize"
#define SYMNAME_IND_SAMP_DESC_SIZE      ".nv.independent.samplerrefDescSize"
#define SYMNAME_PTX_CONST_BANK_0_SIZE   ".nv.ptx.const0.size"
#define SYMNAME_SURF_DESC_SIZE          ".nv.surfrefDescSize"


/*--------------------------- Relocation Descriptor --------------------------*/

typedef struct {
  elf32Addr      offset;                // Location where apply the action 
  elfWord        info;                  // index and type of relocation    
} elf32Rel;

typedef struct {
  elf64Addr      offset;                // Location where apply the action 
  elfXword       info;                  // index and type of relocation    
} elf64Rel;

typedef struct {
  elf32Addr      offset;                // Location where apply the action 
  elfWord        info;                  // index and type of relocation    
  elfSword       addend;                // Constant addend used to compute value
} elf32Rela;

typedef struct {
  elf64Addr      offset;                // Location where apply the action 
  elfXword       info;                  // index and type of relocation    
  elfSxword      addend;                // Constant addend used to compute value
} elf64Rela;


#define ELF32_R_SYM(r)    (((r)->info) >>   8)
#define ELF32_R_TYPE(r)   (((r)->info) & 0xff)
#define ELF32_R_INFO(s,t) (((s)<<8)+((t)&0xff))

#define ELF64_R_SYM(r)    (((r)->info) >>  32)
#define ELF64_R_TYPE(r)   (((r)->info) & 0xffffffffU)
#define ELF64_R_INFO(s,t) ((((elfXword)(s))<<32)+(t))

#define R_CUDA_NONE                   0      // no relocation
#define R_CUDA_32                     1      // 32bit specific address
#define R_CUDA_64                     2      // 64bit specific address
#define R_CUDA_G32                    3      // 32bit generic address
#define R_CUDA_G64                    4      // 64bit generic address
#define R_CUDA_ABS32_26               5      // absolute_address(sym) -> bits 26-57
#define R_CUDA_TEX_HEADER_INDEX       6      // header_index(tex) -> bits 0-19
#define R_CUDA_SAMP_HEADER_INDEX      7      // header_index(samp) -> bits 20-31
#define R_CUDA_SURF_HW_DESC           8      // hw_descriptor(surf) -> 32 bytes
#define R_CUDA_SURF_HW_SW_DESC        9      // hw and sw descriptor(surf) -> 32 + size computed from EIATTR_QUERY_NUMATTTRIB
#define R_CUDA_ABS32_LO_26            10     // lower 32bits of 64bit absolute_address(sym) -> bits 26-57
#define R_CUDA_ABS32_HI_26            11     // upper 32bits of 64bit absolute_address(sym) -> bits 26-57
#define R_CUDA_ABS32_23               12     // absolute_address(sym) -> bits 23-54
#define R_CUDA_ABS32_LO_23            13     // lower 32bits of 64bit absolute_address(sym) -> bits 23-54
#define R_CUDA_ABS32_HI_23            14     // upper 32bits of 64bit absolute_address(sym) -> bits 23-54
#define R_CUDA_ABS24_26               15     // 24bit absolute_address(sym) -> bits 26-49
#define R_CUDA_ABS24_23               16     // 24bit absolute_address(sym) -> bits 23-46
#define R_CUDA_ABS16_26               17     // 16bit absolute_address(sym) -> bits 26-41
#define R_CUDA_ABS16_23               18     // 16bit absolute_address(sym) -> bits 23-38
#define R_CUDA_TEX_SLOT               19     // 8bit slot of tex sym  -> bits 32-39
#define R_CUDA_SAMP_SLOT              20     // 5bit slot of samp sym -> bits 40-44
#define R_CUDA_SURF_SLOT              21     // 6bit slot of surf sym -> bits 26-31
#define R_CUDA_TEX_BINDLESSOFF13_32   22     // 13 bit (bindless offset allocated to tex sym >> 2) -> bits 32-44
#define R_CUDA_TEX_BINDLESSOFF13_47   23     // 13 bit (bindless offset allocated to tex sym >> 2) -> bits 47-59
#define R_CUDA_CONST_FIELD19_28       24     // 14 bit (((offset of sym + addend) & 0xffffU) >> 2) -> bits 28-41
                                             // 4bit (constant bank for sym & 0xF) -> bits 42-45
                                             // 1bit (constant bank for sym >> 4) & 0x1 -> bit 26-26
#define R_CUDA_CONST_FIELD19_23       25     // 14 bit (((offset of sym + addend) & 0xffffU) >> 2) -> bits 23-36
                                             // 5 bit (constant bank for sym & 0x1F) -> bits 37-41
#define R_CUDA_TEX_SLOT9_49           26     // 9bit slot of tex sym -> bits 49-57
#define R_CUDA_6_31                   27     // 6bit sym value -> bits 31-36
#define R_CUDA_2_47                   28     // 2bit sym value -> bits 47-48
#define R_CUDA_TEX_BINDLESSOFF13_41   29     // 13 bit (bindless offset allocated to tex sym >> 2) -> bits 41-53
#define R_CUDA_TEX_BINDLESSOFF13_45   30     // 13 bit (bindless offset allocated to tex sym >> 2) -> bits 45-57
#define R_CUDA_FUNC_DESC32_23         31     // 32 bit function descriptor of entry function -> bits 23-54
#define R_CUDA_FUNC_DESC32_LO_23      32     // lower 32bits of 64bit function descriptor of entry function -> bits 23-54
#define R_CUDA_FUNC_DESC32_HI_23      33     // upper 32bits of 64bit function descriptor of entry function -> bits 23-54
#define R_CUDA_FUNC_DESC_32           34     // 32bit address of function descriptor of entry function
#define R_CUDA_FUNC_DESC_64           35     // 64bit address of function descriptor of entry function
#define R_CUDA_CONST_FIELD21_26       36     // 16bit ((offset of sym + addend) & 0xffffU) -> bits 26-41
                                             // 5bit (constant bank for sym & 0x1F) -> bits 42-46
#define R_CUDA_QUERY_DESC21_37        37     // 16 bit offset of query descriptor -> bits 37-52
                                             // 5 bit bank used for query descriptor -> bits 53-57
#define R_CUDA_CONST_FIELD19_26       38     // 14 bit (((offset of sym + addend) & 0xffffU) >> 2) -> bits 26-39
                                             // 5 bit (constant bank for sym & 0x1F) -> bits 40-44
#define R_CUDA_CONST_FIELD21_23       39     // 16 bit ((offset of sym + addend) & 0xffffU) -> bits 23-38
                                             // 5 bit (constant bank for sym & 0x1F) -> bits 39-43
#define R_CUDA_PCREL_IMM24_26         40     // 24 bit PC relative branch offset -> bits 26-49
#define R_CUDA_PCREL_IMM24_23         41     // 24 bit PC relative branch offset -> bits 23-46
#define R_CUDA_ABS32_20               42     // absolute_address(sym) -> bits 20-51
#define R_CUDA_ABS32_LO_20            43     // lower 32bits of 64bit absolute_address(sym) -> bits 20-51
#define R_CUDA_ABS32_HI_20            44     // upper 32bits of 64bit absolute_address(sym) -> bits 20-51
#define R_CUDA_ABS24_20               45     // 24bit absolute_address(sym) -> bits 20-43
#define R_CUDA_ABS16_20               46     // 16bit absolute_address(sym) -> bits 20-35
#define R_CUDA_FUNC_DESC32_20         47     // 32 bit function descriptor of entry function -> bits 20-51
#define R_CUDA_FUNC_DESC32_LO_20      48     // lower 32bits of 64bit function descriptor of entry function -> bits 20-51
#define R_CUDA_FUNC_DESC32_HI_20      49     // upper 32bits of 64bit function descriptor of entry function -> bits 20-51
#define R_CUDA_CONST_FIELD19_20       50     // 14 bit (((offset of sym + addend) & 0xffffU) >> 2) -> bits 20-33
                                             // 5 bit (constant bank for sym & 0x1F) -> bits 34-38
#define R_CUDA_BINDLESSOFF13_36       51     // 13 bit (bindless offset allocated to tex/surf sym >> 2) -> bits 36-48
#define R_CUDA_SURF_HEADER_INDEX      52     // header_index(surf) -> bits 0-19
#define R_CUDA_INSTRUCTION64          53     // replace 64bits of instruction; reloc passed through to tools
#define R_CUDA_CONST_FIELD21_20       54     // 16 bit ((offset of sym + addend) & 0xffffU) -> bits 20-35
                                             // 5 bit (constant bank for sym & 0x1F) -> bits 36-40
#define R_CUDA_ABS32_32               55     // 32bit absolute_address(sym) -> bits 32-63
#define R_CUDA_ABS32_LO_32            56     // lower 32bit of 64bit absolute_address(sym) -> bits 32-63
#define R_CUDA_ABS32_HI_32            57     // upper 32bit of 64bit absolute_address(sym) -> bits 32-63  
#define R_CUDA_ABS47_34               58     // 47bit (absolute_address(sym) >> 2) -> bits 34-80. Lower 2bits are assumed 0
#define R_CUDA_ABS16_32               59     // 16bit absolute_address(sym) -> bits 32-47 
#define R_CUDA_ABS24_32               60     // 24bit absolute_address(sym) -> bits 32-55 
#define R_CUDA_FUNC_DESC32_32         61     // 32 bit function descriptor of entry function -> bits 32-63
#define R_CUDA_FUNC_DESC32_LO_32      62     // lower 32bits of 64bit function descriptor of entry function -> bits 32-63
#define R_CUDA_FUNC_DESC32_HI_32      63     // upper 32bits of 64bit function descriptor of entry function -> bits 32-64
#define R_CUDA_CONST_FIELD19_40       64     // 14 bit (((offset of sym + addend) & 0xffffU) >> 2) -> bits 40-53
                                             // 5 bit (constant bank for sym & 0x1F) -> bits 54-58
#define R_CUDA_BINDLESSOFF14_40       65     // 14 bit (bindless offset allocated to tex/surf sym >> 2) -> bits 40-53 
#define R_CUDA_CONST_FIELD21_38       66     // 16 bit ((offset of sym + addend) & 0xffffU) -> bits 38-53
                                             // 5 bit (constant bank for sym & 0x1F) -> bits 54-58
#define R_CUDA_INSTRUCTION128         67     // replace 128bits of instruction; reloc passed through to tools
#define R_CUDA_YIELD_OPCODE9_0        68     // 9 bits addend -> bits 0-8. Sym is NULL and only addend will be used.
#define R_CUDA_YIELD_CLEAR_PRED4_87   69     // Clear 4 bits -> bits 87-90. Sym is NULL and addend is 0
#define R_CUDA_32_LO                  70     // lower 32bit of 64bit absolute_address(sym) -> bits 0-32
#define R_CUDA_32_HI                  71     // upper 32bit of 64bit absolute_address(sym) -> bits 0-32  
#define R_CUDA_UNUSED_CLEAR32         72     // clear 32bits if Sym deleted
#define R_CUDA_UNUSED_CLEAR64         73     // clear 64bits if Sym deleted
#define R_CUDA_ABS24_40               74     // 24bit absolute_address(sym) -> bits 40-63
#define R_CUDA_NONE_LAST              75

// deprecated, but kept for compatibility:
#define R_NV_NONE R_CUDA_NONE 
#define R_NV_32 R_CUDA_32
#define R_NV_64 R_CUDA_64
#define R_NV_G32 R_CUDA_G32
#define R_NV_G64 R_CUDA_G64
#define R_CUDA_ABS32 R_CUDA_ABS32_26
#define R_CUDA_ABS32_LO R_CUDA_ABS32_LO_26
#define R_CUDA_ABS32_HI R_CUDA_ABS32_HI_26
#define R_CUDA_TEX_BINDLESSOFF13_36 R_CUDA_BINDLESSOFF13_36
#define R_CUDA_INSTRUCTION8 R_CUDA_INSTRUCTION64

/*--------------------------- Dynamic --------------------------*/
typedef struct {
  elfSword d_tag;
  union {
    elfWord   d_val;
    elf32Addr d_ptr;
  } d_un;
} elf32Dyn;

typedef struct {
  elfSxword d_tag;
  union {
    elfXword  d_val;
    elf64Addr d_ptr;
  } d_un;
} elf64Dyn;

/* values for d_tag */
#define DT_NULL         0           // <none> Marks end of .dynamic section
#define DT_NEEDED       1           // <d_val> Name of library that is needed
#define DT_PLTRELSZ     2           // <d_val> Size in bytes of PLT relocs
#define DT_PLTGOT       3           // <d_ptr> Address of PLT or GOT
#define DT_HASH         4           // <d_ptr> Address of gnu.hash
#define DT_STRTAB       5           // <d_ptr> Address of dynstr table
#define DT_SYMTAB       6           // <d_ptr> Address of dynsym
#define DT_RELA         7           // <d_ptr> Address of rela.dyn
#define DT_RELASZ       8           // <d_val> Total size of Rela relocs
#define DT_RELAENT      9           // <d_val> Size of one Rela reloc
#define DT_STRSZ        10          // <d_val> Size of string table
#define DT_SYMENT       11          // <d_val> Size of one symbol table entry
#define DT_INIT         12          // <d_ptr> Address of .init
#define DT_FINI         13          // <d_ptr> Address of .fini
#define DT_SONAME       14          // <d_val> Name of shared object
#define DT_RPATH        15          // <d_val> Library search path
#define DT_SYMBOLIC     16          // <none> Start symbol search here
#define DT_REL          17          // <d_ptr> Address of Rel relocs
#define DT_RELSZ        18          // <d_val> Total size of Rel relocs
#define DT_RELENT       19          // <d_val> Size of one Rel reloc
#define DT_PLTREL       20          // <d_val> Type of reloc in PLT
#define DT_DEBUG        21          // <d_ptr> For debugging
#define DT_TEXTREL      22          // <none> Reloc might modify .text
#define DT_JMPREL       23          // <d_ptr> Address of rela.plt
#define DT_BIND_NOW     24          // <none> Process relocations of object
#define DT_INIT_ARRAY   25          // <d_ptr> Array with ptrs of init funcs
#define DT_FINI_ARRAY   26          // <d_ptr> Array with ptrs of fini funcs
#define DT_INIT_ARRAYSZ 27          // <d_val> Size in bytes of DT_INIT_ARRAY
#define DT_FINI_ARRAYSZ 28          // <d_val> Size in bytes of DT_FINI_ARRAY
#define DT_RUNPATH      29          // <d_val> Library search path in DT_STRTAB
#define DT_FLAGS        30          // <d_val> Flags for object being loaded
#define DT_ENCODING     32          // Start of encoded range
#define DT_PREINIT_ARRAY 32         // <d_ptr> Array of ptrs of preinit funcs
#define DT_PREINIT_ARRAYSZ 33       // <d_val> size in bytes of PREINIT_ARRAY
#define DT_LOOS         0x6000000d  // Start of OS-specific
#define DT_HIOS         0x6ffff000  // End of OS-specific
#define DT_LOPROC       0x70000000  // Start of processor-specific
#define DT_HIPROC       0x7fffffff  // End of processor-specific

/*--------------------------- Callgraph --------------------------*/
typedef struct {
  elfWord x, y;
} elfCallGraphGeneric;          // generic entry is pair of indices

typedef struct {
  elfSymtabIndex caller;        // symtab index 
  elfSymtabIndex callee;        // symtab index
} elfCallGraphCall;             // for a direct call from caller to callee

typedef struct {
  elfSymtabIndex func;          // symtab index 
  elfWord proto;                // strtab index
} elfCallGraphProto;            // specify prototype of func

typedef struct {
  elfSymtabIndex icaller;       // symtab index 
  elfWord proto;                // strtab index
} elfCallGraphIcall;            // specify prototype of indirect call in icaller

/* if x field is 0, y field contains following markers */
#define ELF_CG_CALL_MARKER  -1  // following entries are elfCallGraphCall
#define ELF_CG_PROTO_MARKER -2  // following entries are elfCallGraphProto
#define ELF_CG_ICALL_MARKER -3  // following entries are elfCallGraphIcall

/*--------------------------- Metadata --------------------------*/

/* Metadata section consists of metadata nodes and values.
 * Each metadata node is represented by elfMetaDataNode and its value is represented
 * by elfMetaDataValue.
 */

typedef struct {
    elfWord metaDataIndex;       // Index for metadata node, if -1, corresponds to metadata group terminator
    elfWord metaDataName;        // strtab index
    elfWord numMetaDataValues;   // subsequent bytes correspond to 'n' elfMetaDataValue
} elfMetaDataNode;

typedef struct {
    elfWord format;
    union {
        elfWord val;
        elfWord index;
        elfWord string;
    } value;
} elfMetaDataValue;

#define EMFMT_ERROR   0   // should never see this
#define EMFMT_WORD    1   // word value (4 bytes)
#define EMFMT_INDEX   2   // index reference to metadata node (4 bytes)
#define EMFMT_STRING  3   // strtab index

/* EMFMT_INDEX is reference to previously defined metadata node. 
 * EMFMT_INDEX corresponds to index of metadata node defined in group of metadata nodes.
 * Metadata node defined with -1 index acts as group terminator.
 */

/*--------------------------- PGO -----------------------------------*/

#define ELF_PGO_REQTYPE_EXEC_COUNT 0
    
typedef elfWord elfPgoInstrOffset; 
    
typedef struct {
    elfWord requestType;
    elfWord numPgoEntries;  // subsequent bytes correspond to 'n' elfPgoInfoEntry
} elfPgoInfo;


typedef struct {
    elfWord id;
    elfWord numOffsets;   // subsequent bytes correspond to 'n' elfPgoInstrOffset
} elfPgoInfoEntry;

#ifdef __cplusplus
}
#endif

#endif
