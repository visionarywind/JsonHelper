/*
 * Copyright 2013-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "tools_shared_graph.h"
#include "tools_shared_hashset.h"
#include "tools_shared_hashmap.h"
#include "tools_shared_list.h"
#include "tools_shared.h"

typedef struct toolsGraphVertexPair_st toolsGraphVertexPair;
typedef struct deleteFunctorData_st deleteFunctorData;


/* Struct definitions */
struct deleteFunctorData_st {
    void *func;
    void *param;
    uint32_t skipEdgeDel;
};

struct toolsGraphVertexPair_st {
    toolsGraphVertex *src;
    toolsGraphVertex *dst;
};

struct toolsGraphVertex_st {
    tHashSet *edges;
    void *userData;
    void *key;

    uint32_t visited;

    /* Used for connected component detection */
    toolsGraph *component;
};

struct toolsGraphEdge_st {
    toolsGraphVertexPair vtx;
    void *userData;
};

struct toolsGraph_st {
    tHashMap *verts;    /* Maps from vertexData to vertex */
    tHashMap *edges;
    void *userData;
    uint32_t isComponent;   /* This is true for graph components */
};

/* Helper functions */

static int32_t
vertexPairHashFun(const tHashMapKey_t key)
{
    void *ptr = NULL;
    toolsGraphVertexPair *pair = NULL;

    pair = (toolsGraphVertexPair*)(uintptr_t)key;

    if (!pair)
        return 0;

    ptr = (void*)(uintptr_t)((uintptr_t)pair->src + (uintptr_t)pair->dst);

    return toolsPointerHashFun(tHashMapPtrToKey(ptr));
}

static uint32_t
vertexPairEqualFun(const toolsGraphVertexPair *left, const toolsGraphVertexPair *right)
{
    if (!left && !right)
        return 1;

    if (!left || !right)
        return 0;

    return ((left->src == right->src && left->dst == right->dst) ||
            (left->src == right->dst && left->dst == right->src));
}

static uint32_t
vertexPairEqualFunWrap(const tHashMapKey_t keyleft, const tHashMapKey_t keyright)
{
    toolsGraphVertexPair *left = NULL;
    toolsGraphVertexPair *right = NULL;

    left  = (toolsGraphVertexPair*)(uintptr_t)keyleft;
    right = (toolsGraphVertexPair*)(uintptr_t)keyright;

    return (uint32_t)vertexPairEqualFun(left, right);
}

static TOOLSresult
graphRemoveEdge(toolsGraph *graph, toolsGraphEdge *edge)
{
    TOOLSresult res = TOOLS_SUCCESS;

    if (!graph || !edge)
        return TOOLS_ERROR_INVALID_VALUE;

    res = toolsHashMapRemove(graph->edges, tHashMapPtrToKey(&edge->vtx), NULL);
    return res;
}

static TOOLSresult
vertexRemoveEdge(toolsGraphVertex *vertex, toolsGraphEdge *edge)
{
    TOOLSresult res = TOOLS_SUCCESS;

    if (!vertex || !edge)
        return TOOLS_ERROR_INVALID_VALUE;

    /* Check if the edge and vertex are related */
    if (vertex != edge->vtx.src &&
        vertex != edge->vtx.dst)
        return TOOLS_ERROR_INVALID_VALUE;

    if (toolsHashSetContains(vertex->edges, edge)) {
        res = toolsHashSetRemove(vertex->edges, edge, NULL);
        return res;
    }

    /* Could not find the edge */
    return TOOLS_ERROR_INVALID_VALUE;
}


static TOOLSresult
deleteEdge(toolsGraphEdge *edge, deleteFunctorData *helper)
{
    if (!edge)
        return TOOLS_SUCCESS;

    if (helper && helper->func)
        ((tSingleFun)helper->func)(edge->userData, helper->param);

    free(edge);

    return TOOLS_SUCCESS;
}

static void
edgeDelFunWrap(void *entry, void *data)
{
    (void)deleteEdge((toolsGraphEdge*)entry, (deleteFunctorData*)data);
}

static TOOLSresult
deleteVertex(toolsGraphVertex *vertex, deleteFunctorData *helper)
{
    TOOLSresult res = TOOLS_SUCCESS;
    tSingleFun edgeDelFun = NULL;

    if (!vertex)
        return TOOLS_SUCCESS;

    if (helper && helper->func)
        ((tSingleFun)helper->func)(vertex->userData, helper->param);

    /* In the case of a full delete, the edge deletion will be handled
       by the graph, which will generate full callbacks */
    if (helper && !helper->skipEdgeDel)
        edgeDelFun = edgeDelFunWrap;

    /* No callbacks for edge deletion inside a vertex */
    if (vertex->edges) {
        res = toolsHashSetDelete(vertex->edges, edgeDelFun, NULL);
        vertex->edges = NULL;
    }

    free(vertex);

    return res;
}

static void
vertexDelFunWrap(void *entry, void *data)
{
    (void)deleteVertex((toolsGraphVertex*)entry, (deleteFunctorData*)data);
}


/* Functions */

/* Create and return a new empty graph
 * pGraph - Returned pointer to graph.
 * Return TOOLS_SUCCESS on sucess
 */
TOOLSresult
toolsGraphCreate(toolsGraph **pGraph, void *userData)
{
    TOOLSresult res = TOOLS_SUCCESS;
    toolsGraph *graph = NULL;

    if (!pGraph)
        return TOOLS_ERROR_INVALID_VALUE;

    graph = calloc (1, sizeof(*graph));
    if (!graph)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    graph->verts = toolsHashMapNew(toolsPointerHashFun, toolsPointerEqualFun, 16);
    if (!graph->verts) {
        res = TOOLS_ERROR_OUT_OF_MEMORY;
        goto error;
    }

    graph->edges = toolsHashMapNew(vertexPairHashFun, vertexPairEqualFunWrap, 16);
    if (!graph->edges) {
        res = TOOLS_ERROR_OUT_OF_MEMORY;
        goto error;
    }

    graph->userData = userData;

    *pGraph = graph;

    return TOOLS_SUCCESS;

error:
    if (graph) {
        if (graph->verts) {
            toolsHashMapDelete(graph->verts, NULL, NULL);
            graph->verts = NULL;
        }

        free(graph);
        graph = NULL;
    }

    return res;
}

/* Destroy Graph
 * graph    - Pointer to graph
 * vertexDelFun - Optional pointer to vertex userData deletion function
 * edgeDelFun - Optional pointer to edge userData deletion function
 * Returns TOOLS_SUCCESS on success
 */
TOOLSresult
toolsGraphDestroy(toolsGraph *graph,
                  tSingleFun graphDataDelFun, void *graphParam,
                  tSingleFun vertexDataDelFun, void *vertexParam,
                  tSingleFun edgeDataDelFun, void *edgeParam)
{
    TOOLSresult res = TOOLS_SUCCESS;
    deleteFunctorData edgeHelper = {0}, vertexHelper = {0};
    tSingleFun tEdgeDelFun = NULL, tVtxDelFun = NULL;

    /* Iterate over all edges, destroying them, then over
       all vertices destroying those
    */
    if (!graph)
        return TOOLS_SUCCESS;

    edgeHelper.func  = edgeDataDelFun;
    edgeHelper.param = edgeParam;

    if (!graph->isComponent) {
        tEdgeDelFun = (tSingleFun)edgeDelFunWrap;
        tVtxDelFun  = (tSingleFun)vertexDelFunWrap;
    }

    if (graph->edges) {
        res = toolsHashMapDelete(graph->edges, tEdgeDelFun, &edgeHelper);
        if (res != TOOLS_SUCCESS)
            return res;

        graph->edges = NULL;
    }

    vertexHelper.func  = vertexDataDelFun;
    vertexHelper.param = vertexParam;
    vertexHelper.skipEdgeDel = 1;

    if (graph->verts) {
        res = toolsHashMapDelete(graph->verts, tVtxDelFun, &vertexHelper);
        if (res != TOOLS_SUCCESS)
            return res;

        graph->verts = NULL;
    }

    if (graph->userData && graphDataDelFun && !graph->isComponent)
        graphDataDelFun(graph->userData, graphParam);

    free(graph);
    return TOOLS_SUCCESS;
}

void*
toolsGraphGetData(toolsGraph *graph)
{
    if (!graph)
        return NULL;

    return graph->userData;
}

/* Get vertex iterator
 * graph    - pointer to Graph
 * Returns iterator to the first vertex or NULL
 */
toolsGraphVertexItr*
toolsGraphGetVertexIterator(toolsGraph *graph)
{
    if (!graph)
        return NULL;

    return (toolsGraphVertexItr*)toolsHashMapGetIterator(graph->verts);
}

/* Get Vertex Next
 * graph    - Pointer to graph
 * itr      - pointer to previous element
 * Returns iteratro to next vertex or NULL
 */
toolsGraphVertexItr*
toolsGraphGetVertexNext(toolsGraph *graph, const toolsGraphVertexItr* itr)
{
    if (!graph)
        return NULL;

    return (toolsGraphVertexItr*)toolsHashMapGetNext(graph->verts, (const tHashMapItr*)itr);
}

/* Get edge iterator
 * graph    - pointer to Graph
 * Returns iterator to the first edge or NULL
 */
toolsGraphEdgeItr*
toolsGraphGetEdgeIterator(toolsGraph *graph)
{
    if (!graph)
        return NULL;

    return (toolsGraphEdgeItr*)toolsHashMapGetIterator(graph->edges);
}

/* Get edge Next
 * graph    - Pointer to graph
 * itr      - pointer to previous element
 * Returns iteratro to next edge or NULL
 */
toolsGraphEdgeItr*
toolsGraphGetEdgeNext(toolsGraph *graph, const toolsGraphEdgeItr* itr)
{
    if (!graph)
        return NULL;

    if (!itr)
        return toolsGraphGetEdgeIterator(graph);

    return (toolsGraphEdgeItr*)toolsHashMapGetNext(graph->edges, (const tHashMapItr*)itr);
}

/* Find edge between vertices
 * graph    - Pointer to graph
 * src      - Pointer to source vertex
 * dst      - Pointer to destination vertex
 * pEdge    - Returned pointer to edge
 * Returns TOOLS_SUCCESS on success
 */
TOOLSresult
toolsGraphFindEdge(toolsGraph *graph, toolsGraphVertex *src, toolsGraphVertex *dst, toolsGraphEdge **pEdge)
{
    toolsGraphVertexPair pair = {0};
    toolsGraphEdge *edge = NULL;

    if (!graph || !src || !dst || !pEdge)
        return TOOLS_ERROR_INVALID_VALUE;

    pair.src = src;
    pair.dst = dst;

    edge = toolsHashMapFind(graph->edges, tHashMapPtrToKey(&pair));
    *pEdge = edge;

    return TOOLS_SUCCESS;
}

/* Create a vertex in a graph
 * graph    - Pointer to the graph
 * userData - Arbitrary pointer to user data
 * pVertex  - Returned pointer to vertex
 * Returns TOOLS_SUCCESS on success
 */
TOOLSresult
toolsGraphCreateVertex(toolsGraph *graph, void *userData, toolsGraphVertex **pVertex)
{
    toolsGraphVertex *vertex = NULL;
    TOOLSresult res = TOOLS_SUCCESS;

    if (!graph || !pVertex)
        return TOOLS_ERROR_INVALID_VALUE;

    if (graph->isComponent)
        return TOOLS_ERROR_INVALID_VALUE;

    vertex = calloc(1, sizeof(*vertex));
    if (!vertex)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    vertex->edges = toolsHashSetNew(toolsPointerHashFun, toolsPointerEqualFun, 16);
    if (!vertex->edges) {
        res = TOOLS_ERROR_OUT_OF_MEMORY;
        goto error;
    }

    vertex->userData = userData;

    /* Add this vertex to the graph's map. To prevent aliasing,
       if the user pointer is NULL, use the vertex pointer from the current
       allocation */
    vertex->key = (userData) ? userData : vertex;

    res = toolsHashMapInsert(graph->verts, tHashMapPtrToKey(vertex->key), (void*)vertex);
    if (res != TOOLS_SUCCESS)
        goto error;

    *pVertex = vertex;

    return TOOLS_SUCCESS;

error:
    if (vertex) {
        if (vertex->edges) {
            toolsHashSetDelete(vertex->edges, NULL, NULL);
            vertex->edges = NULL;
        }
        if (graph && vertex->key) {
            toolsHashMapRemove(graph->verts, tHashMapPtrToKey(vertex->key), NULL);
        }

        free(vertex);
        vertex = NULL;
    }

    return res;
}

/* This will destroy a vertex and all edges terminating at this vertex
 * graph    - pointer to graph
 * vertex   - pointer to vertex
 * vertexDelFun - Optional function to delete vertex userData
 * edgeDelFun   - Optional function to delete edge userData
 */
TOOLSresult
toolsGraphDestroyVertex(toolsGraph *graph, toolsGraphVertex *vertex,
                        tSingleFun vertexDataDelFun, void *vertexParam,
                        tSingleFun edgeDataDelFun, void *edgeParam)
{
    toolsGraphEdgeItr *edgeitr;
    toolsGraphEdge *edge;
    deleteFunctorData edgeHelper = {0}, vertexHelper = {0};
    TOOLSresult res = TOOLS_SUCCESS;
    void* savedkey = NULL;

    if (!graph || !vertex)
        return TOOLS_ERROR_INVALID_VALUE;

    /* To destroy a vertex, we do the following -
       Iterate through the in / out edge sets, removing the entries from
       the graph->edges list
       Then destroy the in/out edge sets
       Finally, destroy this vertex
    */

    edgeHelper.func  = edgeDataDelFun;
    edgeHelper.param = edgeParam;

    edgeitr = toolsGraphVertexGetEdgeIterator(vertex);
    for (;
         edgeitr;
         edgeitr = toolsGraphVertexGetEdgeNext(vertex, edgeitr)) {
        edge = toolsGraphIteratorGetEdge(edgeitr);
        if (!edge)
            return TOOLS_ERROR_UNKNOWN;

        res = graphRemoveEdge(graph, edge);
        if (res != TOOLS_SUCCESS)
            return res;
    }

    /* Only for a non component, do we remove the actual edges on the vertex. */
    if (!graph->isComponent) {
        res = toolsHashSetDelete(vertex->edges, edgeDelFunWrap, &edgeHelper);
        if (res != TOOLS_SUCCESS)
            return res;

        vertex->edges = NULL;
    }

    /* Save off the key */
    savedkey = vertex->key;

    /* For components, skip the data deletion */
    if (graph->isComponent) {
        vertexHelper.func = NULL;
        vertexHelper.param = NULL;
        vertexHelper.skipEdgeDel = 1;
    }
    else {
        /* For normal graphs, delete the actual vertex */
        vertexHelper.func  = vertexDataDelFun;
        vertexHelper.param = vertexParam;

        res = deleteVertex(vertex, &vertexHelper);
        if (res != TOOLS_SUCCESS)
            return res;
    }

    /* Finally, remove this vertex from the map */
    res = toolsHashMapRemove(graph->verts, tHashMapPtrToKey(savedkey), NULL);
    if (res != TOOLS_SUCCESS)
        return res;

    return res;
}

/* Create an edge between vertices
 * graph    - Pointer to graph
 * src      - Pointer to source vertex
 * dst      - Pointer to dest vertex
 * userData - Arbitrary user provided data
 * pEdge    - Returned pointer to edge. If edge already exists, that is returned.
 * Returns TOOLS_SUCCESS on success
 */
TOOLSresult
toolsGraphCreateEdge(toolsGraph *graph, toolsGraphVertex* src, toolsGraphVertex* dst,
                     void *userData, toolsGraphEdge **pEdge)
{
    toolsGraphEdge *edge = NULL;
    TOOLSresult res = TOOLS_SUCCESS;

    if (!graph || !src || !dst || !pEdge)
        return TOOLS_ERROR_INVALID_VALUE;

    if (graph->isComponent)
        return TOOLS_ERROR_INVALID_VALUE;

    res = toolsGraphFindEdge(graph, src, dst, &edge);
    if (res != TOOLS_SUCCESS)
        return res;

    /* If edge is found, return it */
    if (edge) {
        *pEdge = edge;
        return TOOLS_SUCCESS;
    }

    edge = calloc(1, sizeof(*edge));
    if (!edge)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    edge->vtx.src   = src;
    edge->vtx.dst   = dst;
    edge->userData  = userData;

    /* Add it to the reverse lookup map */
    res = toolsHashMapInsert(graph->edges, tHashMapPtrToKey(&edge->vtx), (void*)edge);
    if (res != TOOLS_SUCCESS)
        return res;

    /* Add it to the outedges of the src */
    res = toolsHashSetInsert(src->edges, (void*)edge);
    if (res != TOOLS_SUCCESS)
        return res;

    /* Add it to the inedges of the dst */
    res = toolsHashSetInsert(dst->edges, (void*)edge);
    if (res != TOOLS_SUCCESS)
        return res;

    *pEdge = edge;

    return TOOLS_SUCCESS;
}

/* Destroys an edge. Does not delete vertices
 * graph    - Pointer to graph
 * edge     - Pointer to edge
 * edgeDelFun - Optional function to delete per edge userData
 * Returns TOOLS_SUCCESS on success
 */
TOOLSresult
toolsGraphDestroyEdge(toolsGraph *graph, toolsGraphEdge *edge, tSingleFun edgeDataDelFun, void *edgeParam)
{
    TOOLSresult res = TOOLS_SUCCESS;
    deleteFunctorData helper = {0};

    if (!graph || !edge)
        return TOOLS_ERROR_INVALID_VALUE;

    if (edge != toolsHashMapFind(graph->edges, tHashMapPtrToKey(&edge->vtx)))
        return TOOLS_ERROR_INVALID_VALUE;

    helper.func  = edgeDataDelFun;
    helper.param = edgeParam;

    res = graphRemoveEdge(graph, edge);
    if (res != TOOLS_SUCCESS)
        return res;

    if (!graph->isComponent) {
        /* Do the edge removal only for full graphs */
        res = vertexRemoveEdge(edge->vtx.src, edge);
        if (res != TOOLS_SUCCESS)
            return res;

        res = vertexRemoveEdge(edge->vtx.dst, edge);
        if (res != TOOLS_SUCCESS)
            return res;

        res = deleteEdge(edge, &helper);
        if (res != TOOLS_SUCCESS)
            return res;
    }

    return TOOLS_SUCCESS;
}

/* Get the user data for a vertex
 * vtx  - Pointer to vertex
 * Returns userData on vertex or NULL
 */
void*
toolsGraphVertexGetData(toolsGraphVertex* vtx)
{
    if (!vtx)
        return NULL;

    return vtx->userData;
}

/* Get edge iterator for a vertex
 * vtx      - Pointer to vertex in graph
 * Returns iterator to edge list or NULL
 */
toolsGraphEdgeItr*
toolsGraphVertexGetEdgeIterator(toolsGraphVertex *vtx)
{
    tHashSetItr *sitr = NULL;

    if (!vtx)
        return NULL;

    /* For undirected graphs, the edge ordering is:
     */
    sitr = toolsHashSetGetIterator(vtx->edges);

    return (toolsGraphEdgeItr*)sitr;
}

/* Get the next edge
 * vtx      - Pointer to vertex
 * itr      - Current edge iterator
 * Returns iterator to next edge or NULL
 */
toolsGraphEdgeItr*
toolsGraphVertexGetEdgeNext(toolsGraphVertex *vtx, toolsGraphEdgeItr* itr)
{
    tHashSetItr *sitr;

    if (!vtx || !itr)
        return NULL;

    sitr = toolsHashSetGetNext(vtx->edges, (const tHashSetItr*)itr);

    return (toolsGraphEdgeItr*)sitr;
}

/* Get the user data for an edge
 * edge     - Pointer to edge
 * Returns userData set on edge creation or NULL
 */
void*
toolsGraphEdgeGetData(toolsGraphEdge* edge)
{
    if (!edge)
        return NULL;

    return edge->userData;
}

/* Get the source vertex for an edge
 * edge     - Pointer to edge
 * Returns the vertex or NULL
 */
toolsGraphVertex*
toolsGraphEdgeGetSource(toolsGraphEdge *edge)
{
    if (!edge)
        return NULL;

    return edge->vtx.src;
}

/* Get the destination vertex for an edge
 * edge     - Pointer to edge
 * Returns the vertex or NULL
 */
toolsGraphVertex*
toolsGraphEdgeGetDest(toolsGraphEdge *edge)
{
    if (!edge)
        return NULL;

    return edge->vtx.dst;
}


/* Iterator get vertex */
toolsGraphVertex*
toolsGraphIteratorGetVertex(const toolsGraphVertexItr *itr)
{
    if (!itr)
        return NULL;

    return (toolsGraphVertex*)toolsHashMapGetEntry((const tHashMapItr*)itr);
}

/* Iterator get edge */
toolsGraphEdge*
toolsGraphIteratorGetEdge(const toolsGraphEdgeItr *itr)
{
    if (!itr)
        return NULL;

    return (toolsGraphEdge*)toolsHashSetGetEntry((const tHashMapItr*)itr);
}

typedef struct toolsGraphCTState_st toolsGraphCTState;
typedef struct toolsGraphBFSCallbacks_st toolsGraphBFSCallbacks;

struct toolsGraphBFSCallbacks_st {
    TOOLSresult (*vtxVisit) (toolsGraphVertex *vtx, toolsGraphVertex *root, toolsGraphCTState *ctState);
    TOOLSresult (*resetVtxVisit)   (toolsGraphVertex *vtx, toolsGraphCTState *ctState);
    TOOLSresult (*postHook) (toolsGraph *graph, toolsGraphCTState *ctState);
};

struct toolsGraphCTState_st {
    toolsGraphBFSCallbacks *cb;
    void                   *data;
    void                   *graphData;
};

static TOOLSresult
resetVertices(toolsGraph *graph, toolsGraphCTState *ctState)
{
    toolsGraphVertexItr *vtxItr = NULL;
    toolsGraphVertex *vtx = NULL;
    TOOLSresult res = TOOLS_SUCCESS;

    if (!graph)
        return TOOLS_ERROR_INVALID_VALUE;

    vtxItr = toolsGraphGetVertexIterator(graph);
    for (;
         vtxItr;
         vtxItr = toolsGraphGetVertexNext(graph, vtxItr)) {
        vtx = toolsGraphIteratorGetVertex(vtxItr);
        vtx->visited = 0;
        if (ctState && ctState->cb && ctState->cb->resetVtxVisit) {
            res = ctState->cb->resetVtxVisit(vtx, ctState);
            if (res != TOOLS_SUCCESS)
                return res;
        }
    }

    return TOOLS_SUCCESS;
}


static TOOLSresult
getUnvisitedNeighbors(toolsGraph *graph, toolsGraphVertex *vtx, tHashSet *nborSet)
{
    toolsGraphEdgeItr *edgeItr = NULL;
    toolsGraphEdge *edge = NULL;
    toolsGraphVertex *nbor = NULL;
    TOOLSresult res = TOOLS_SUCCESS;

    if (!vtx || !nborSet)
        return TOOLS_ERROR_INVALID_VALUE;

    /* Iterate over the top level set of edges as this graph
       might be a component (where the per vertex edge set
       and the graph edge set do not match) */
    edgeItr = toolsGraphGetEdgeIterator(graph);
    for (;
         edgeItr;
         edgeItr = toolsGraphGetEdgeNext(graph, edgeItr)) {
        edge = toolsGraphIteratorGetEdge(edgeItr);
        if (edge->vtx.src != vtx &&
            edge->vtx.dst != vtx)
            continue;

        nbor = (edge->vtx.src == vtx) ? edge->vtx.dst : edge->vtx.src;
        if (!nbor->visited) {
            res = toolsHashSetInsert(nborSet, (void*)nbor);
            if (res != TOOLS_SUCCESS)
                return res;
        }
    }
    return TOOLS_SUCCESS;
}

static TOOLSresult
traverseBFS_vtx(toolsGraph *graph, toolsGraphVertex *rootvtx, toolsGraphCTState *ctState)
{
    TOOLSresult res = TOOLS_SUCCESS;
    tHashSetItr *itr = NULL;
    tHashSet *curSet = NULL, *nextSet = NULL;
    toolsGraphVertex *nbor = NULL;

    if (!graph || !rootvtx || !ctState)
        return TOOLS_ERROR_INVALID_VALUE;

    /* If this has a value, then skip it */
    if (rootvtx->visited)
        return TOOLS_SUCCESS;

    /* Create the current set and add the root vertex into it */
    curSet = toolsHashSetNew(toolsPointerHashFun, toolsPointerEqualFun, 17);
    if (!curSet)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    res = toolsHashSetInsert(curSet, rootvtx);
    if (res != TOOLS_SUCCESS)
        goto cleanup;

    while (toolsHashSetSize(curSet)) {
        nextSet = toolsHashSetNew(toolsPointerHashFun, toolsPointerEqualFun, 17);
        if (!nextSet) {
            res = TOOLS_ERROR_OUT_OF_MEMORY;
            goto cleanup;
        }

        for (itr = toolsHashSetGetIterator(curSet);
             itr;
             itr = toolsHashSetGetNext(curSet, itr)) {
            nbor = (toolsGraphVertex*) toolsHashSetGetEntry(itr);

            if (ctState->cb && ctState->cb->vtxVisit) {
                res = ctState->cb->vtxVisit(nbor, rootvtx, ctState);
                if (res != TOOLS_SUCCESS)
                    goto cleanup;
            }

            nbor->visited = 1;

            /* For every vertex, build the next set */
            res = getUnvisitedNeighbors(graph, nbor, nextSet);
            if (res != TOOLS_SUCCESS)
                goto cleanup;
        }

        /* Once we are done with the current set, swap the next */
        res = toolsHashSetDelete(curSet, NULL, NULL);
        if (res != TOOLS_SUCCESS)
            goto cleanup;

        curSet = nextSet;
        nextSet = NULL;
    };

cleanup:
    if (nextSet) {
        (void)toolsHashSetDelete(nextSet, NULL, NULL);
        nextSet = NULL;
    }

    if (curSet) {
        (void)toolsHashSetDelete(curSet, NULL, NULL);
        curSet = NULL;
    }

    return res;
}

static TOOLSresult
componentResetVisitor(toolsGraphVertex *vtx, toolsGraphCTState *ctState)
{
    if (!vtx || !ctState)
        return TOOLS_ERROR_INVALID_VALUE;

    vtx->component = NULL;

    return TOOLS_SUCCESS;
}

static TOOLSresult
componentVisitor(toolsGraphVertex *vtx, toolsGraphVertex *root, toolsGraphCTState *ctState)
{
    TOOLSresult res = TOOLS_SUCCESS;

    if (!vtx || !ctState || !root)
        return TOOLS_ERROR_INVALID_VALUE;

    /* For the root vertex, create the graph */
    if (vtx == root) {
        res = toolsGraphCreate(&vtx->component, ctState->graphData);
        if (res != TOOLS_SUCCESS)
            return res;

        vtx->component->isComponent = 1;

        res = toolsListAppend((tList*)ctState->data, vtx->component);
        if (res != TOOLS_SUCCESS)
            return res;
    }

    vtx->component = root->component;
    res = toolsHashMapInsert(vtx->component->verts, tHashMapPtrToKey(vtx->key), vtx);
    if (res != TOOLS_SUCCESS)
        return res;

    return res;
}

static TOOLSresult
initializeComponentTraversalState(toolsGraphCTState *ctState, toolsGraph *graph, toolsGraphBFSCallbacks *callbacks, void *data)
{
    if (!ctState)
        return TOOLS_ERROR_INVALID_VALUE;

    ctState->cb          = callbacks;
    ctState->data        = data;
    ctState->graphData   = graph->userData;

    return TOOLS_SUCCESS;
}

static TOOLSresult
finalizeComponentTraversalState(toolsGraphCTState *ctState)
{
    if (!ctState)
        return TOOLS_ERROR_INVALID_VALUE;

    return TOOLS_SUCCESS;
}

static TOOLSresult
traverseBFS(toolsGraph *graph, toolsGraphBFSCallbacks *callbacks, void *data)
{
    TOOLSresult res = TOOLS_SUCCESS;
    toolsGraphVertexItr *vtxItr = NULL;
    toolsGraphVertex *vtx = NULL;
    toolsGraphCTState ctState = {0};

    if (!graph)
        return TOOLS_ERROR_INVALID_VALUE;

    res = initializeComponentTraversalState(&ctState, graph, callbacks, data);
    if (res != TOOLS_SUCCESS)
        return res;

    res = resetVertices(graph, &ctState);
    if (res != TOOLS_SUCCESS)
        return res;

    vtxItr = toolsGraphGetVertexIterator(graph);
    for (;
         vtxItr;
         vtxItr = toolsGraphGetVertexNext(graph, vtxItr)) {
        vtx = toolsGraphIteratorGetVertex(vtxItr);
        res = traverseBFS_vtx(graph, vtx, &ctState);
        if (res != TOOLS_SUCCESS)
            return res;
    }

    /* Do some post hook if needed */
    if (ctState.cb && ctState.cb->postHook) {
        res = ctState.cb->postHook(graph, &ctState);
        if (res != TOOLS_SUCCESS)
            return res;
    }

    res = finalizeComponentTraversalState(&ctState);
    if (res != TOOLS_SUCCESS)
        return res;


    return res;
}

/* This function scans all the edges in the top graph and
   adds them into the correct component's edge map.
   This function requires that each vertex have a
   component */
static TOOLSresult
partitionEdges(toolsGraph *graph, toolsGraphCTState *ctState)
{
    toolsGraphEdgeItr *edgeItr = NULL;
    toolsGraphEdge *edge = NULL;
    toolsGraph *component = NULL;
    TOOLSresult res = TOOLS_SUCCESS;

    if (!graph)
        return TOOLS_ERROR_INVALID_VALUE;

    edgeItr = toolsGraphGetEdgeIterator(graph);
    for (;
         edgeItr;
         edgeItr = toolsGraphGetEdgeNext(graph, edgeItr)) {
        edge = toolsGraphIteratorGetEdge(edgeItr);

        /* Both vertices of an edge must be in the same component */
        if (edge->vtx.src->component != edge->vtx.dst->component)
            return TOOLS_ERROR_INVALID_VALUE;

        component = edge->vtx.src->component;
        if (!component || !component->edges)
            return TOOLS_ERROR_UNKNOWN;

        res = toolsHashMapInsert(component->edges, tHashMapPtrToKey(&edge->vtx), edge);
        if (res != TOOLS_SUCCESS)
            return res;
    }

    return TOOLS_SUCCESS;
}

/* GetConnectedComponents
    Returns a list, where each element is a graph component. Graph components
    behave as graphs but do not allow element modification. As a result,
    their primary use is traversal.

    This function does allocate components, and the caller is responsible for
    calling GraphDestroy on them.
*/
tList*
toolsGraphGetConnectedComponents(toolsGraph *graph)
{
    TOOLSresult res = TOOLS_SUCCESS;
    tList *componentList = NULL;
    toolsGraphBFSCallbacks cb = {0};

    if (!graph)
        return NULL;

    /* Connection algorithm:
        Do a BFS at each vertex, adding it to a new component.
        Then, do a post scan of all edges, putting them in the
        correct component map.
    */

    componentList = toolsListNew();
    if (!componentList)
        return NULL;

    cb.vtxVisit = componentVisitor;
    cb.resetVtxVisit = componentResetVisitor;
    cb.postHook     = partitionEdges;

    res = traverseBFS(graph, &cb, componentList);
    if (res != TOOLS_SUCCESS)
        return NULL;

    return componentList;
}

/* Gets the number of vertices in a graph
 */
size_t toolsGraphGetVertexCount(const toolsGraph *graph)
{
    if (!graph)
        return 0;

    return toolsHashMapSize(graph->verts);
}

/* Gets the number of edges in a graph
 */
size_t toolsGraphGetEdgeCount(const toolsGraph *graph)
{
    if (!graph)
        return 0;

    return toolsHashMapSize(graph->edges);
}

