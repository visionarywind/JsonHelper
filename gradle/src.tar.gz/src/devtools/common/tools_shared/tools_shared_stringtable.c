/*
 * Copyright 2013-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "tools_shared.h"
#include "tools_shared_stringtable.h"

struct tStringTable_st {
    size_t cursize;
    size_t maxsize;
    char *buf;
};

tStringTable*
toolsStringTableNew(size_t size)
{
    tStringTable *ret = NULL;

    if (size < 1)
        return NULL;

    ret = malloc(sizeof(*ret));
    if (!ret)
        return NULL;

    ret->cursize = 0;
    ret->maxsize = size;
    ret->buf = malloc(sizeof(*ret->buf) * ret->maxsize);
    if (!ret->buf) {
        free(ret);
        return NULL;
    }

    ret->buf[0] = '\0';
    ret->cursize = 1;

    return ret;
}

TOOLSresult
toolsStringTableDelete(tStringTable *tbl)
{
    if (!tbl)
        return TOOLS_SUCCESS;

    if (tbl->buf)
        free(tbl->buf);

    memset(tbl, 0, sizeof(*tbl));
    free(tbl);

    return TOOLS_SUCCESS;
}

size_t
toolsStringTableAddString(tStringTable *tbl, const char* str)
{
    size_t len;
    size_t oldsize;

    if (!tbl || !str)
        return 0;

    oldsize = tbl->cursize;

    len = strlen(str) + 1;
    if (len + tbl->cursize >= tbl->maxsize) {
        size_t newsize = (tbl->maxsize << 1);
        char *newbuf = NULL;

        /* Handle huge strings by doubling newsize
           until it exceeds the size of the string */
        while (newsize < (1U << 31) && newsize < (len + tbl->cursize))
            newsize <<= 1;

        /* 2 GB is the limit */
        if (newsize >= (1U << 31))
            return 0;

        newbuf = malloc(sizeof(*newbuf) * newsize);

        if (!newbuf)
            return 0;

        memcpy(newbuf, tbl->buf, tbl->cursize);
        free(tbl->buf);

        tbl->buf = newbuf;
        tbl->maxsize = newsize;
    }

    memcpy(tbl->buf + tbl->cursize, str, len);
    tbl->cursize += len;

    return oldsize;
}

const char*
toolsStringTableGetString(tStringTable *tbl, size_t index)
{
    if (!tbl)
        return NULL;

    if (index >= tbl->cursize)
        return NULL;

    return (const char*)(tbl->buf + index);
}

const char*
toolsStringTableGetTable(tStringTable *tbl)
{
    if (!tbl)
        return NULL;

    return tbl->buf;
}

size_t
toolsStringTableGetSize(tStringTable *tbl)
{
    if (!tbl)
        return 0;

    return tbl->cursize;
}
