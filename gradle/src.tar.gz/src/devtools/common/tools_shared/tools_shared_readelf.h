/*
 * Copyright 2007-2016 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: tools_shared_readelf.h
 *
 *   Description:
 *       Routines for extracting line number information from device DWARF
 *
 ******************************************************************************/

#ifndef _TOOLS_SHARED_READELF_H
#define _TOOLS_SHARED_READELF_H

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "tools_shared.h"
#include "tools_shared_dwarf.h"
#include "tools_shared_internal_nvelf.h"
#include "tools_shared_readelf_common.h"
#include "tools_shared_readelf_caches.h"
#include "tools_shared_hashmap.h"
#include "tools_shared_hashset.h"
#include "tools_shared_rangemap.h"
#include "tools_shared_list.h"

// TODO: Improve error checking

/**** Code "borrowed" from gpgpucomp ****/
typedef void* elf_t;

#define DW_LNS_copy             1
#define DW_LNS_advance_pc       2
#define DW_LNS_advance_line     3
#define DW_LNS_set_file         4
#define DW_LNS_set_column       5
#define DW_LNS_negate_stmt      6
#define DW_LNS_set_basic_block  7
#define DW_LNS_const_add_pc     8
#define DW_LNS_fixed_advance_pc 9

#define DW_LNE_end_sequence     1
#define DW_LNE_set_address      2
#define DW_LNE_define_file      3

static elfXXFileHeader *elfXX_file_header(const elf_t image)
{
    return (elfXXFileHeader*) image;
}

static elfXword elfXX_shnum(const elf_t e)
{
    elfXXFileHeader *efh = elfXX_file_header(e);
    if (efh->shnum == 0) {
        /* get value from size of first (empty) section */
        /* to avoid recursion, don't call elfXX_section_header(0) */
        elfXXSectionHeader* esh = (elfXXSectionHeader*) (void*)((char*)e + efh->shoff);
        return esh->size;
    }
    return efh->shnum;
}

static elfXXSectionHeader *elfXX_section_header(const elf_t image, const uint32_t index)
{
    elfXXFileHeader* efh = elfXX_file_header(image);
    char* p = (char*) image;

    if (index >= elfXX_shnum(image))
        return NULL;

    p += efh->shoff + (index * efh->shentsize);
    return (elfXXSectionHeader*)(void*)p;
}

static char *elfXX_section_name(const elf_t image, const elfXXSectionHeader* esh)
{
    elfXXFileHeader* efh = elfXX_file_header(image);
    elfXXSectionHeader* eshstr = elfXX_section_header (image, efh->shstrndx);
    char* strtab;
    if (!eshstr) {
        return NULL;
    }
    strtab = (char*)image + eshstr->offset;
    return strtab + esh->name;
}

static elfXXSectionHeader *elfXX_named_section_header(const elf_t image, const char* name)
{
    elfXXFileHeader* efh = elfXX_file_header(image);
    elfXXSectionHeader* esh;
    uint32_t i;
    char* p = (char*) image;
    p += efh->shoff;
    esh = (elfXXSectionHeader*)(void*)p;

    for (i = 0; i < elfXX_shnum(image); ++i) {
        if (strcmp(elfXX_section_name(image, esh), name) == 0)
            return esh;
        ++esh;
    }
    return NULL;
}

static elfXXSectionHeader *elfXX_typed_section_header(const elf_t image, const elfWord type)
{
    elfXXFileHeader* efh = elfXX_file_header(image);
    elfXXSectionHeader* esh;
    uint32_t i;
    char* p = (char*) image;
    p += efh->shoff;
    esh = (elfXXSectionHeader*)(void*)p;

    /* iterate through sections till find matching type */
    for (i = 0; i < elfXX_shnum(image); ++i) {
        if (esh->type == type) {
            return esh;
        }
        ++esh;
    }

    return NULL;
}

static elfWord
elfXX_symbol_shndx(const elfXXSymbol *symtab, const elfWord *symtab_shndx, const unsigned int index)
{
    if (symtab_shndx && symtab[index].shndx == SHN_XINDEX)
        /* Use the extended shndx */
        return symtab_shndx[index];
    /* Use the shndx defined in the symbol */
    return symtab[index].shndx;
}

static TOOLSresult elfReadSymtab(const elf_t image, elfXXSymbol **symtab, elfWord **symtab_shndx, size_t *size)
{
    elfXXSectionHeader *elf_sh = elfXX_typed_section_header(image, SHT_SYMTAB);
    elfXXSectionHeader *shndx_sh = elfXX_typed_section_header(image, SHT_SYMTAB_SHNDX);

    if (!elf_sh) {
        return TOOLS_ERROR_SECTION_NOT_FOUND;
    }

    if (elf_sh->entsize != sizeof(elfXXSymbol)) {
        return TOOLS_ERROR_SECTION_SIZE_MISMATCH;
    }

    *symtab = (elfXXSymbol*)(void*)((char*) image + elf_sh->offset);
    *size   = (size_t) (elf_sh->size / elf_sh->entsize);

    if (symtab_shndx) {
        if (shndx_sh)
            *symtab_shndx = (elfWord*)(void*)((char*)image + shndx_sh->offset);
        else
            *symtab_shndx = NULL;
    }

    return TOOLS_SUCCESS;
}

static TOOLSresult elfReadStrtab(const elf_t image, char **strtab, size_t *size)
{
    elfXXSectionHeader *elf_sh = elfXX_named_section_header(image, ".strtab");

    if (!elf_sh) {
        return TOOLS_ERROR_SECTION_NOT_FOUND;
    }

    *strtab = (char*) image + elf_sh->offset;
    *size   = (size_t) elf_sh->size;

    return TOOLS_SUCCESS;
}

static int32_t
decodeSLEB(char **pptr)
{
    char *ptr = *pptr;
    int32_t result = 0;
    int32_t sign = 0;
    uint32_t shift = 0;
    const uint32_t size = 31;

    while (shift < size) {
        result |= ((*ptr & 0x7f) << shift);
        shift += 7;
        sign = (*ptr & 0x40);
        if (!(*ptr & 0x80))
            break;
        ptr += 1;
    }

    if (shift < size && sign)
        result |= ~((1 << shift) - 1);

    *pptr = ptr + 1;
    return result;
}

static TOOLSresult
getRelocLoc(const elf_t  image,
            elfXXSymbol *symtab, size_t symtabsize,
            char        *strtab, size_t strtabsize,
            const char  *funcName,
            char       **ret_reloc_loc)
{

    uint32_t i;
    elfXXSectionHeader *elf_sh;
    elfXXSectionHeader *target_sh;
    elfXXRel *reloc_entries;
    size_t size;

    if (!image || !isELF(image) || !symtab   || !symtabsize || !strtab
        || !strtabsize   || !funcName || !ret_reloc_loc)
        return TOOLS_ERROR_INVALID_VALUE;
    *ret_reloc_loc = NULL;

    elf_sh = elfXX_named_section_header(image, ".rel.debug_line");
    if (!elf_sh)
        return TOOLS_ERROR_SECTION_NOT_FOUND;
    if (elf_sh->entsize != sizeof(elfXXRel))
        return TOOLS_ERROR_SECTION_SIZE_MISMATCH; // need better error code ?

    reloc_entries = (elfXXRel*)(void*)((char*)image + elf_sh->offset);

    target_sh = elfXX_section_header(image, elf_sh->info);
    if (!target_sh)
        return TOOLS_ERROR_SECTION_NOT_FOUND;

    size = (size_t) (elf_sh->size / elf_sh->entsize); // number of entries in the relocation table

    /* Search for the relocation for this function in .debug_line and
       give it a unique start offset */
    for (i = 0; i < size; i++) {
        char *name;
        uint32_t relsym = (uint32_t) ELFXX_R_SYM(&reloc_entries[i]);
        if (relsym > symtabsize)
            return TOOLS_ERROR_SECTION_SIZE_MISMATCH;

        name = strtab + symtab[relsym].name;

        if (strcmp(name, funcName) == 0) {
            char *offset = (char*)image + target_sh->offset + reloc_entries[i].offset;
            if (*(elfXXAddr*)(void*)offset != 0)
                return TOOLS_ERROR_UNKNOWN;
            *ret_reloc_loc = (char*) offset;
            break;
        }
    }

    if ( !(*ret_reloc_loc))
        return TOOLS_ERROR_SYMBOL_NOT_FOUND;

    return TOOLS_SUCCESS;
}

static TOOLSresult
dwarfGetLineInfo(ElfModuleCacheRecord *emcr,
                 KernelCacheRecord    *targetKernel,
                 uint32_t              pc,
                 char                **ret_file_name,
                 char                **ret_dir_name,
                 uint32_t             *ret_line)
{
    /* tempDblState is used to make sure that if an error is encountered in a case of the outer
       switch in the while loop, then the execution of that case is not reflected in dblState.
       (In other words, lazy commit policy is used.)
    */
    DebugLineState *dblState = NULL, tempDblState;
    TOOLSresult      result = TOOLS_SUCCESS;
    DebugLineSection *dls = NULL;
    LineCacheRecord *lcRecord = NULL;
    uint32_t block_length;
    uint32_t ret_dir = 0;

    if (!emcr || !(emcr->image) || !isELF(emcr->image)||
        !targetKernel || !ret_line)
        return TOOLS_ERROR_INVALID_VALUE;

    lcRecord = searchLineCache(targetKernel, pc);
    if (lcRecord)
        return getLineCacheInfo(lcRecord, ret_file_name,
                                ret_dir_name, ret_line);

    if (targetKernel->lineCacheComplete == 1)
        return TOOLS_ERROR_INVALID_VALUE;

    dls = getDLSActive(emcr);
    if (!dls)
        return TOOLS_ERROR_INVALID_VALUE;

    dblState = &(dls->state);

    while (dblState->ptr < dblState->end) {
        switch (*(dblState->ptr)) {
        case DW_LNS_copy:
            if (dblState->address) {
                if (dblState->currentKernel) {
                    if (dblState->address > dblState->prev_address) {
                        result = insertIntoLineCache(dblState->currentKernel,
                                                    dls,
                                                    dblState->prev_address,
                                                    dblState->address - 1,
                                                    dblState->prev_line,
                                                    dblState->prev_file);
                    }
                    if (result != TOOLS_SUCCESS)
                        return result;
                }

                if (dblState->currentKernel == targetKernel &&
                    dblState->address > pc) {
                    result = getFileCache(dls,
                                          dblState->prev_file,
                                          ret_file_name,
                                          &ret_dir);

                    if (result != TOOLS_SUCCESS)
                        return result;

                    result = getDirCache(dls, ret_dir, ret_dir_name);
                    if (result != TOOLS_SUCCESS)
                        return result;

                    *ret_line = dblState->prev_line;
                    return TOOLS_SUCCESS;
                }
            }
            dblState->ptr         += 1;
            dblState->prev_address = dblState->address;
            dblState->prev_line    = dblState->line;
            dblState->prev_file    = dblState->file;
            break;
        case DW_LNS_advance_pc:
            dblState->ptr += 1;
            dblState->address += decodeULEB(&dblState->ptr) * (dblState->min_instr_len);
            break;
        case DW_LNS_advance_line:
            dblState->ptr += 1;
            dblState->line += decodeSLEB(&dblState->ptr);
            break;
        case DW_LNS_set_file:
            dblState->ptr += 1;
            dblState->file = decodeULEB(&dblState->ptr);
            break;
        case DW_LNS_set_column:
            dblState->ptr += 1;
            (void)decodeULEB(&dblState->ptr);
            break;
        case 0: // extended opcodes
            if (dblState->currentKernel) {
                if (dblState->address >= dblState->prev_address) {
                    result = insertIntoLineCache(dblState->currentKernel,
                                                dls,
                                                dblState->prev_address,
                                                dblState->address,
                                                dblState->prev_line,
                                                dblState->prev_file);
                }
                if (result != TOOLS_SUCCESS)
                    return result;
            }

            if (dblState->currentKernel == targetKernel &&
                dblState->address >= pc) {
                result = getFileCache(dls,
                                      dblState->prev_file,
                                      ret_file_name,
                                      &ret_dir);
                if (result != TOOLS_SUCCESS)
                    return result;

                result = getDirCache(dls, ret_dir, ret_dir_name);
                if (result != TOOLS_SUCCESS)
                    return result;

                *ret_line = dblState->prev_line;
                return TOOLS_SUCCESS;
            }

            dblState->ptr += 1;
            block_length   = *dblState->ptr;
            dblState->ptr += 1;

            switch (*dblState->ptr) {
            case DW_LNE_set_address:
                dblState->ptr          += 1;
                dblState->address       = *(uint32_t*)(void*)dblState->ptr;
                dblState->prev_address  = dblState->address ;
                dblState->currentKernel = searchKernelCacheByRelocLoc(emcr,
                                                                      (void *)(dblState->ptr));
                /* At this point, failing to find a currentKernel implies
                   that the debug_line section has a SET_ADDRESS, but there
                   is no reloc to target it. Ideally, this should never happen
                   however, for weakly linked functions, the compiler
                   seems to be emitting this (Bug 1030319)
                   As a WAR, we can gracefully handle such cases by setting
                   currentKernel to NULL, and continuing the parsing of the
                   debug_line section. When doing this, the debug line cache updates
                   will not happen, and successful hits will not happen until
                   we hit a subsequent SET_ADDRESS which does have a valid
                   reloc targetting it.
                */
                dblState->ptr          += block_length - 1;
                break;
            case DW_LNE_end_sequence:
                dblState->ptr         += block_length;
                dblState->address      = 0;
                dblState->prev_address = 0;
                dblState->file         = 1;
                dblState->line         = 1;

                if (dblState->currentKernel) {
                    dblState->currentKernel->lineCacheComplete = 1;
                    dblState->currentKernel = NULL;
                }

                if (targetKernel->lineCacheComplete == 1)
                    return TOOLS_ERROR_INVALID_VALUE;
            }
            break;
        default: { // special opcodes
            // Lazy commit policy used in this case
            unsigned char opcode = *(unsigned char*)dblState->ptr;
            if (opcode < dblState->opcode_base - 1)
                return TOOLS_ERROR_UNKNOWN;

            tempDblState              = *dblState;
            tempDblState.ptr         += 1;
            opcode                   -= tempDblState.opcode_base;
            tempDblState.address     += opcode / tempDblState.line_range;
            tempDblState.line        += tempDblState.line_base +
                                        opcode % tempDblState.line_range;
            tempDblState.prev_address = tempDblState.address;
            tempDblState.prev_line    = tempDblState.line;

            if (dblState->currentKernel) {
                if (tempDblState.address > dblState->prev_address) {
                    result = insertIntoLineCache(dblState->currentKernel,
                                                dls,
                                                dblState->prev_address,
                                                tempDblState.address - 1,
                                                dblState->prev_line,
                                                dblState->prev_file);
                }
                if (result != TOOLS_SUCCESS)
                    return result;
            }

            if (tempDblState.currentKernel == targetKernel &&
                tempDblState.address > pc) {
                result = getFileCache(dls, dblState->prev_file,
                                      ret_file_name, &ret_dir);
                if (result != TOOLS_SUCCESS)
                    return result;

                result = getDirCache(dls, ret_dir, ret_dir_name);
                if (result != TOOLS_SUCCESS)
                    return result;

                *ret_line = dblState->prev_line;
                *dblState = tempDblState;
                return TOOLS_SUCCESS;
            }
            *dblState = tempDblState;
        }
        break;
        }
        /* Late update for the next debug line section */
        if (dblState->ptr >= dblState->end) {
            dls = setDLSActiveNext(emcr);
            if (dls) {
                dblState = &(dls->state);
                dblState->currentKernel = searchKernelCacheByRelocLoc(emcr,
                                                                      (void *)(dblState->ptr));
            }
        }
    }
    return TOOLS_ERROR_UNKNOWN;
}

uint32_t
toolsElfXXGetAbiVersion(const char *image)
{
    elfXXFileHeader *efh = elfXX_file_header((elf_t)image);

    if (!efh)
        return 0;

    return efh->abiVersion;
}

/* ElfXXGetLineInfo : ELF/DWARF parser to read line information
    This function function takes in an ELF image, of a given size
    and is given the name of a kernel and a 0 based offset in it.
    It will then return the source file, directory and line number
    corresponding to that line.

    This function does not allocate any data. The pointers that are
    returned for the file and directory names are in the original
    ELF image. The returned file name may not be fully qualified
    and must be created by concatenating the dir_name and file_name
    strings.

    Parameters
    pimage          : Pointer to ELF image
    function_name   : NULL terminated C string containing name of kernel
    pc              : 0 based offset into kernel
    file_name       : Pointer to NULL terminated string for file name
    dir_name        : Pointer to NULL terminated string for dir name
    line            : Pointer to line number

    NOTE : Both file_name and dir_name are strings inside the ELF image
           that has been passed in. The ELF image itself is not modifed.
           The burden of concatenating these two is entirely on the
           calling function. If the file name is fully qualified, the
           dir_name pointer will return NULL. If not, the full file
           name can be given as "(dir_name)/(file_name)".
*/
// TODO: Propogate the constness all over.
TOOLSresult toolsElfXXGetLineInfo(const void *pimage,
                                  const char *function_name,
                                  uint32_t    pc,
                                  char      **ret_file_name,
                                  char      **ret_dir_name,
                                  uint32_t   *ret_line )
{
    elf_t                 image        = NULL;
    ElfModuleCacheRecord *emcr    = NULL;
    KernelCacheRecord    *targetKernel = NULL;
    TOOLSresult           result       = TOOLS_SUCCESS;
    elfXXSectionHeader   *esh          = NULL;
    elfXXSymbol          *symtab       = NULL;
    char                 *strtab       = NULL;
    size_t                symtab_size  = 0,   strtab_size = 0;
    tHashMapItr          *itr = NULL;

    if (!pimage || !function_name || !ret_line)
        return TOOLS_ERROR_INVALID_VALUE;

    if (!isELF(pimage))
        return TOOLS_ERROR_INVALID_ELF;

    image = (elf_t)pimage;

    emcr = searchElfModuleCache(image);
    if (!emcr) {
        esh = elfXX_named_section_header(image, ".debug_line");
        if (!esh)
            return TOOLS_ERROR_SECTION_NOT_FOUND;

        result = elfReadSymtab(image, &symtab, NULL, &symtab_size);
        if (result != TOOLS_SUCCESS)
            return result;

        result = elfReadStrtab(image, &strtab, &strtab_size);
        if (result != TOOLS_SUCCESS)
            return result;

        result = insertIntoElfModuleCache(image,
                                          (char *)image + (esh->offset),
                                          (char *)image + (esh->offset + esh->size),
                                          (void *)symtab,
                                          symtab_size,
                                          (void *)strtab,
                                          strtab_size,
                                          &emcr);
        if (result != TOOLS_SUCCESS)
            return result;

        for (itr = toolsHashMapGetIterator(emcr->kernelHashMapByName); itr;
             itr = toolsHashMapGetNext(emcr->kernelHashMapByName, itr)) {

            targetKernel = toolsHashMapGetEntry(itr);
            if (!targetKernel)
                return TOOLS_ERROR_UNKNOWN;

            result = getRelocLoc(image,
                                 (elfXXSymbol *)(emcr->symtab),
                                 emcr->symtab_size,
                                 emcr->strtab,
                                 emcr->strtab_size,
                                 targetKernel->name,
                                 &targetKernel->reloc_loc);

            if (result == TOOLS_SUCCESS && targetKernel->reloc_loc) {
                result = toolsHashMapInsert(emcr->kernelHashMapByRelocLoc,
                                            tHashMapPtrToKey(targetKernel->reloc_loc),
                                            (void *)targetKernel);
                if (result != TOOLS_SUCCESS)
                    return result;
            }
        }
    }

    targetKernel = searchKernelCacheByName(emcr, function_name);
    if (!targetKernel)
        return TOOLS_ERROR_SYMBOL_NOT_FOUND;

    result = dwarfGetLineInfo(emcr,
                              targetKernel,
                              pc,
                              ret_file_name,
                              ret_dir_name,
                              ret_line);

    return result;
}

static TOOLSresult
elfFindSymbol(elfXXSymbol *symtab, size_t symtab_size,
              char *strtab, size_t strtab_size,
              const char *symbol_name, elfXXSymbol **psymbol, elfWord* index)
{
    size_t i = 0;
    char *name = NULL;

    if (!symtab || !symtab_size || !strtab || !strtab_size ||
        !symbol_name || !psymbol)
        return TOOLS_ERROR_INVALID_VALUE;

    if (!strlen(symbol_name))
        return TOOLS_ERROR_INVALID_VALUE;

    for (i = 0; i < symtab_size; ++i) {
        name = strtab + symtab[i].name;
        if (!strcmp(name, symbol_name)) {
            *psymbol = &symtab[i];
            if(index)
                *index = (elfWord)i;

            return TOOLS_SUCCESS;
        }
    }

    return TOOLS_ERROR_SYMBOL_NOT_FOUND;
}

static TOOLSresult
elfFindContainerFunc(elfXXSymbol *symtab, elfWord *symtab_shndx, size_t symtab_size,
                     elfXXSymbol *func_code_symbol, elfWord func_symix,
                     uint32_t offset_pc, elfXXSymbol **nearest)
{
    size_t i = 0;
    elfWord func_shndx;

    if (!symtab || !symtab_size || !func_code_symbol || !nearest)
        return TOOLS_ERROR_INVALID_VALUE;

    /* Grab the function's shndx */
    func_shndx = elfXX_symbol_shndx(symtab, symtab_shndx, func_symix);

    *nearest = NULL;
    for (i = 0; i < symtab_size; ++i) {
        if (elfXX_symbol_shndx(symtab, symtab_shndx, (const unsigned int)i) != func_shndx)
            continue;

        if (offset_pc >= symtab[i].value &&
            offset_pc < symtab[i].value + symtab[i].size   &&
            ELF_ST_TYPE(&symtab[i]) == STT_FUNC) {
            *nearest = &symtab[i];
            return TOOLS_SUCCESS;
        }
    }

    return TOOLS_ERROR_SYMBOL_NOT_FOUND;
}

/* ElfXXGetContainerFunc :
    This function takes an elf image, and the name of a kernel
    and a 0-based offset into the kernel. Given this information, it
    returns the function symbol containing the offset and returns the
    name of this function and the offset of the function symbol from
    the start of the kernel's text section.

    This function does not allocate any data. The pointer that is
    returned for the function name is in the original ELF image.

    Parameters
    pimage          : Pointer to ELF image
    size            : Size of ELF image in bytes
    function_name   : NULL terminated C string containing name of kernel
    offset_pc       : 0 based offset into kernel
    func_name       : Pointer to NULL terminated string for function name
    func_offset     : Pointer to offset of function
*/
TOOLSresult
toolsElfXXGetContainerFunc(const void *pimage,
                           const char *function_name, uint32_t offset_pc,
                           char **func_name, uint32_t *func_offset)
{
    TOOLSresult status = TOOLS_SUCCESS;

    elfXXSymbol *symtab = NULL;
    elfWord *symtab_shndx = NULL;
    elfXXSymbol *func_symbol = NULL;
    elfWord func_symix = 0;
    elfXXSymbol *nearest = NULL;
    size_t symtabsize = 0;

    char *strtab = NULL;
    size_t strtabsize = 0;
    elf_t image = (elf_t)pimage;

    if (!pimage || !function_name)
        return TOOLS_ERROR_INVALID_VALUE;

    if (!isELF(pimage))
        return TOOLS_ERROR_INVALID_ELF;

    status = elfReadSymtab(image, &symtab, &symtab_shndx, &symtabsize);
    if (status != TOOLS_SUCCESS)
        goto error;

    status = elfReadStrtab(image, &strtab, &strtabsize);
    if (status != TOOLS_SUCCESS)
        goto error;

    status = elfFindSymbol(symtab, symtabsize, strtab, strtabsize,
                           function_name, &func_symbol, &func_symix);
    if (status != TOOLS_SUCCESS)
        goto error;

    status = elfFindContainerFunc(symtab, symtab_shndx, symtabsize, func_symbol, func_symix, offset_pc, &nearest);
    if (status != TOOLS_SUCCESS)
        goto error;

    if (func_name)
        *func_name = (nearest) ? (strtab + nearest->name) : NULL;

    if (func_offset)
        *func_offset = (nearest) ? ((uint32_t)nearest->value): ~0U;

    return TOOLS_SUCCESS;

error:

    return status;
}

static TOOLSresult
elfGenerateRelocs(elf_t image,
                  elfRelocFunc *relfunc, elfRelocMod *relmod,
                  uint32_t srcshndx, elfXXSectionHeader *esh,
                  elfXXSymbol *symtab, elfWord *symtab_shndx, size_t symtabsize,
                  char *strtab, size_t strtabsize,
                  toolsDirectInstTestFun directTestFun,
                  uint32_t instSize)
{
    uint32_t i = 0;
    elfXXOff type = 0;
    elfXXOff symix = 0;
    elfXXRel *rel = NULL;
    elfXXRela *rela = NULL;
    uint32_t offset = 0;
    elfXXSymbol *targetsym = NULL;
    elfXXSectionHeader *targetsh = NULL;
    char *codeptr = NULL;
    uint32_t isdirect = 0;
    elfReloc *reloc = NULL;
    TOOLSresult status = TOOLS_SUCCESS;

    if (!relmod || !esh || !symtab || !symtabsize)
        return TOOLS_ERROR_INVALID_VALUE;

    if (esh->type != SHT_RELA &&
        esh->type != SHT_REL)
        return TOOLS_ERROR_UNKNOWN;

    rel   =  (elfXXRel*)(void*)((char*)image + esh->offset);
    rela  =  (elfXXRela*)(void*)((char*)image + esh->offset);
    for (i = 0; i < (esh->size/esh->entsize); ++i) {
        uint64_t *inst = NULL;

        if (esh->type == SHT_REL) {
            symix = ELFXX_R_SYM(rel);
            type = ELFXX_R_TYPE(rel);
            offset = (uint32_t)rel->offset;
            ++rel;
        }
        else {
            symix = ELFXX_R_SYM(rela);
            type = ELFXX_R_TYPE(rela);
            offset = (uint32_t)rela->offset;
            ++rela;
        }

        /* If the relocation offset has been already seen, march on */
        if (relfunc) {
            reloc = getRelocByOffset(relfunc, offset);
            if (reloc)
                continue;
        }

        targetsym = &symtab[symix];
        /* If the relocation isnt targetting a code, march on */
        if (ELF_ST_TYPE(targetsym) != STT_FUNC)
            continue;

        if (relfunc) {
            /* If the type of the relocation is unknown, march on */
            switch (type) {
                /* These are for relocs targetting instructions */
            case R_CUDA_ABS32_23:
            case R_CUDA_ABS32_LO_23:
            case R_CUDA_ABS32_HI_23:
            case R_CUDA_ABS32_26:
            case R_CUDA_ABS32_LO_26:
            case R_CUDA_ABS32_HI_26:
            case R_CUDA_ABS32_20:
            case R_CUDA_ABS32_LO_20:
            case R_CUDA_ABS32_HI_20:
            case R_CUDA_ABS32_32:
            case R_CUDA_ABS32_LO_32:
            case R_CUDA_ABS32_HI_32:
            case R_CUDA_ABS47_34:
                /* Known, make progress */
                break;
            default:
                continue;
            }

            /* Now we need to find the instruction, and read it out. */
            targetsh = (elfXXSectionHeader*)elfXX_section_header(image, srcshndx);
            if (!targetsh)
                return TOOLS_ERROR_SECTION_NOT_FOUND;

            codeptr = (char*)image + targetsh->offset + offset;
            inst = (uint64_t*)(uintptr_t)codeptr;

            /* Run the test on this to determine if its dependent */
            isdirect = ((*directTestFun)(inst));
        }
        else {
            /* This is for a reloc not targeting a text section. */
            switch (type) {
                /* The reloc *must* be 32 or 64 bits as PC space is 64 bits */
            case R_CUDA_32:
            case R_CUDA_G32:
            case R_CUDA_64:
            case R_CUDA_G64:
                break;

            default:
                continue;
            }
        }

        /* Finally, create an elfReloc object. This also handles
           updating all necessary tracking structures */
        status = createElfReloc(&reloc, relfunc, relmod,
                                (uint32_t)elfXX_symbol_shndx(symtab, symtab_shndx, (const unsigned int)symix),
                                inst,
                                instSize / sizeof(inst),
                                strtab + targetsym->name,
                                offset, isdirect);
        if (status != TOOLS_SUCCESS)
            return status;

    }

    return TOOLS_SUCCESS;
}

static TOOLSresult
elfModuleGetAllRelocs(elf_t image,
                      elfXXSymbol *symtab, elfWord *symtab_shndx, size_t symtabsize,
                      char *strtab, size_t strtabsize,
                      elfRelocMod **prelmod, toolsDirectInstTestFun directTestFun,
                      uint32_t instSize)
{
    uint32_t i = 0;
    TOOLSresult status = TOOLS_SUCCESS;
    elfRelocFunc *relfunc = NULL;
    elfRelocMod  *relmod = NULL;
    elfXXSectionHeader* esh = NULL;
    char *shname = NULL;

    if (!image || !symtab || !symtabsize    ||
        !strtab || !strtabsize              ||
        !prelmod || !directTestFun)
        return TOOLS_ERROR_INVALID_VALUE;

    status = createElfRelocModule(&relmod, image);
    if (status != TOOLS_SUCCESS)
        return status;

    /* Pass 1 - Add code sections into lookup */
    for (i = 0; i < elfXX_shnum(image); ++i) {
        esh = elfXX_section_header(image, i);
        if (!esh || esh->type != SHT_PROGBITS)
            continue;
        shname = elfXX_section_name(image, esh);
        if (!esh->name || !(shname) ||
            strstr(shname, SHNAME_TEXT) != shname)
            continue;

        status = createElfRelocFunc(&relfunc, relmod, i,
                                    shname);
        if (status != TOOLS_SUCCESS) {
            destroyElfRelocModule(relmod);
            return status;
        }
    }

    /* Pass 2 - Updates for relocation sections */
    for (i = 0; i < elfXX_shnum(image); ++i) {
        esh = elfXX_section_header(image, i);
        if (!esh)
            continue;

        if (esh->type != SHT_REL &&
            esh->type != SHT_RELA)
            continue;

        relfunc = getRelocFuncByShndx(relmod, esh->info);
        /* If the reloc is not targeting a function it could be
           global init or constant. Relfunc == NULL */
        if (!relfunc) {
            shname = elfXX_section_name(image, esh);
            if (!esh->name || !(shname))
                continue;

            /* Skip relocs targeting debug sections */
            if (strstr(shname, ".rel.debug") == shname      ||
                strstr(shname, ".rel.nv_debug") == shname   ||
                strstr(shname, ".rela.debug") == shname     ||
                strstr(shname, ".rela.nv_debug") == shname)
                continue;

        }
        status = elfGenerateRelocs(image,
                                   relfunc, relmod,
                                   esh->info, esh,
                                   symtab, symtab_shndx, symtabsize,
                                   strtab, strtabsize,
                                   directTestFun,
                                   instSize);
        if (status != TOOLS_SUCCESS) {
            destroyElfRelocModule(relmod);
            return status;
        }
    }

    *prelmod = relmod;
    return TOOLS_SUCCESS;
}

/* ElfXXGetRelatedFuncs :
    The purpose of this function is to handle separate compilation cases
    where the dependency between two code sections must be analyzed for
    purposes such as code patching.

    For the purposes of this function, two types of dependencies are
    examined :
    1. Direct dependencies - Cases where a function calls another
        by means of a JCAL. In these situations, the ELF will contain
        an R_CUDA_ABS32_26 (or R_CUDA_ABS32_23) relocator targeting
        a JCAL or JMP instruction
    2. Indirect dependencies - Cases where a JMX or indirect CALL is used to call a
        a function whose address has been relocated.

    This function takes a kernel by name, and a field to indicate
    whether the kernel contains any indirect call instructions. It returns
    the number of kernels in num_related_funcs. The names of the
    related kernels are returned in the array related_funcs. If the size
    of the array (max_related_funcs) is too small, only the first
    num_related_func entries are valid.

    This function does not allocate any data. The pointers that are
    returned for the function names are in the original ELF image.

    Parameters
    pimage          : Pointer to ELF image
    function_name   : NULL terminated C string containing name of kernel
    has_indirect_calls : Boolean indicating whether the kernel contains an indirect call
    related_funcs   : Client allocated array of pointers
    max_related_funcs: Number of entries in the array
    num_related_funcs: Actual number of entries that are used
    directTestFun   : Function pointer that is used to test direct relationships
                      This takes the current instruction as a parameter and produces
                      0 if the instruction is not JCAL or JMP
                      1 if the instruction is JCAL or JMP
                      This function must be appropriate for the given architecture
*/
TOOLSresult
toolsElfXXGetRelatedFuncs(const void *pimage,
                          const char *function_name, uint32_t has_indirect_calls,
                          char **related_funcs, uint32_t max_related_funcs,
                          uint32_t *num_related_funcs,
                          toolsDirectInstTestFun directTestFun,
                          uint32_t instSize)
{
    TOOLSresult status = TOOLS_SUCCESS;

    elfXXSymbol *symtab = NULL;
    elfWord *symtab_shndx = NULL;
    elfXXSymbol *func_symbol = NULL;
    elfWord symix = 0;
    size_t symtabsize = 0;

    char *strtab = NULL;
    size_t strtabsize = 0;
    elf_t image = (elf_t)pimage;
    uint32_t outcount = 0, i, j;
    elfRelocMod *relmod = NULL;
    elfRelocFunc *relfunc = NULL;
    elfReloc *reloc = NULL;
    tHashMapItr *relitr = NULL;

    if (!pimage || !function_name)
        return TOOLS_ERROR_INVALID_VALUE;

    if (!isELF(pimage))
        return TOOLS_ERROR_INVALID_ELF;

    if (num_related_funcs)
        *num_related_funcs = 0;

    status = elfReadSymtab(image, &symtab, &symtab_shndx, &symtabsize);
    if (status != TOOLS_SUCCESS)
        goto error;

    status = elfReadStrtab(image, &strtab, &strtabsize);
    if (status != TOOLS_SUCCESS)
        goto error;

    status = elfFindSymbol(symtab, symtabsize, strtab, strtabsize,
                           function_name, &func_symbol, &symix);
    if (status != TOOLS_SUCCESS)
        goto error;

    status = elfModuleGetAllRelocs(image,
                                   symtab, symtab_shndx, symtabsize,
                                   strtab, strtabsize,
                                   &relmod, directTestFun, instSize);
    if (status != TOOLS_SUCCESS)
        goto error;

    relfunc = getRelocFuncByShndx(relmod, elfXX_symbol_shndx(symtab, symtab_shndx, (const unsigned int)symix));

    if (relfunc)
        outcount += relfunc->directRelocCount;
    if (has_indirect_calls && relmod)
        outcount += relmod->indirectRelocCount;

    /* Update the output buffer if needed */
    if (related_funcs) {

        /* Initialize counter */
        i = 0;
        if (relfunc && relfunc->directRelocCount) {
            relitr = toolsHashMapGetIterator(relfunc->directRelocMap);
            /* Loop over all direct dependencies */
            for (; i < relfunc->directRelocCount; ++i) {
                /* Skip if reloc is null or if the output buffer is full */
                if (!relitr || i >= max_related_funcs ||
                    i >= outcount)
                    break;

                reloc = (elfReloc*)toolsHashMapGetEntry(relitr);
                related_funcs[i] = reloc->targetname;
                relitr = toolsHashMapGetNext(relfunc->directRelocMap, relitr);
            }
        }

        if (relmod && relmod->indirectRelocCount) {
            relitr = toolsHashMapGetIterator(relmod->indirectRelocMap);
            /* Loop over all indirects (use the old value of i)*/
            for (j = 0; j < relmod->indirectRelocCount; ++i, ++j) {
                /* Skip if reloc is null or if the output buffer is full */
                if (!relitr || i >= max_related_funcs ||
                    i >= outcount)
                    break;

                reloc = (elfReloc*)toolsHashMapGetEntry(relitr);
                related_funcs[i] = reloc->targetname;
                relitr = toolsHashMapGetNext(relmod->indirectRelocMap, relitr);
            }
        }

    }

    if (outcount > max_related_funcs)
        status = TOOLS_ERROR_OUT_OF_MEMORY;

    /* Always update the total count */
    if (num_related_funcs)
        *num_related_funcs = outcount;

    if (relmod)
        destroyElfRelocModule(relmod);

error:
    return status;
}

/* toolsElfXXListKernelNames:
    This function takes an ELF image and returns names of all
    the kernels contained in that ELF. The function does not allocate any data.
    The pointer that is returned for the function name is in the original ELF image.

    Parameters
    pimage           : Pointer to ELF image
    ret_kernel_names : Base address of an array of character pointers for kernel names
                       It should be allocated and freed by the client.
    max_kernels      : Total number of character pointers in ret_kernel_names array
    ret_num_kernels  : Actual number of kernels in this ELF.
*/
TOOLSresult
toolsElfXXListKernelNames(const void *pimage,
                          char      **ret_kernel_names,
                          uint32_t    max_kernels,
                          uint32_t   *ret_num_kernels)
{

    char                *cptr = NULL;
    uint32_t              i;
    size_t               symtabsize = 0, strtabsize = 0;
    elfXXFileHeader     *efh      = NULL;
    elfXXSectionHeader  *esh      = NULL;
    elfXXSymbol         *symtab   = NULL;
    char                *strtab   = NULL;
    TOOLSresult          result;
    void                *image;

    if (!pimage || !ret_num_kernels)
        return TOOLS_ERROR_INVALID_VALUE;
    if (!isELF(pimage))
        return TOOLS_ERROR_INVALID_ELF;
    image = (void *)pimage;

    result = elfReadSymtab(image, &symtab, NULL, &symtabsize);
    if (result != TOOLS_SUCCESS)
        return result;

    result = elfReadStrtab(image, &strtab, &strtabsize);
    if (result != TOOLS_SUCCESS)
        return result;

    efh = elfXX_file_header(image);
    cptr = (char*) image;
    cptr += efh->shoff;
    esh = (elfXXSectionHeader*)(void*)cptr;

    *ret_num_kernels = 0;
    for (i = 0; i < elfXX_shnum(image); ++i, ++esh) {

        cptr = elfXX_section_name(image, esh);
        if (!strstr(cptr, SHNAME_TEXT) || esh->type != SHT_PROGBITS)
            continue;

        if (ret_kernel_names && *ret_num_kernels < max_kernels)
            ret_kernel_names[*ret_num_kernels] = cptr + sizeof(SHNAME_TEXT) - 1;

        (*ret_num_kernels)++;
    }

    if (*ret_num_kernels > max_kernels)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    return TOOLS_SUCCESS;
}

static TOOLSresult
elfXXHasAnyIndirectCall(elf_t image, elfXXSectionHeader *esh,
                        toolsIndirectInstTestFun indirectTestFun,
                        uint32_t instSize, uint32_t *indirect_call_count)
{
    char *text = NULL;
    size_t size = 0;
    uint32_t offset, i;
    uint64_t inst[2] = {0};

    if (!image || !esh || !indirectTestFun || !indirect_call_count)
        return TOOLS_ERROR_INVALID_VALUE;

    if (instSize > sizeof(inst))
        return TOOLS_ERROR_INVALID_VALUE;

    *indirect_call_count = 0;

    text = (char*)image + esh->offset;
    size = (size_t)esh->size;

    for (offset = 0; offset < (uint32_t)size ; offset += instSize, text += instSize) {
        /* Alignment ??*/
        for (i = 0; i < instSize / sizeof(*inst); ++i)
            memcpy(inst + i, text + i, sizeof(*inst));

        /* Indirect function call */
        if (indirectTestFun(inst, offset))
            ++(*indirect_call_count);
    }

    return TOOLS_SUCCESS;
}

/* ElfXXGetCallgraphFuncs :
    This function computes the list of all reachable text sections
    from a given text section. Effectively, this interface will return
    an array containing the names of all device functions that can be
    reached via direct calls (JCAL/JMP) or indirect calls (JMX/CALL) from
    the given function or from any function reachable from the entry
    function.

    This function takes a kernel by name and an ELF image. It returns
    the number of functions in num_callgraph_funcs. The names of the
    reachable functions are returned in the array callgraph_funcs. If the size
    of the array (max_callgraph_funcs) is too small, only the first
    max_callgraph_func entries are valid.

    This function does not allocate any data. The pointers that are
    returned for the function names are in the original ELF image.

    Parameters
    pimage              : Pointer to ELF image
    function_name       : NULL terminated C string containing name of kernel
    callgraph_funcs     : Client allocated array of pointers
    max_callgraph_funcs : Number of entries in the array
    num_callgraph_funcs : Actual number of entries that are used
    indirectTestFun     : Function pointer that is used to test indirect relationships
                          This function takes the current instruction and its offset from
                          the start of the text section as parameters and produces
                          0 if the instruction is not JMX or indirect CALL
                          1 if the instruction is JMX or indirect CALL
                          This function must be appropriate for the given architecture
    directTestFun       : Function pointer that is used to test direct relationships
                          This takes the current instruction as a parameter and produces
                          0 if the instruction is not JCAL or JMP
                          1 if the instruction is JCAL or JMP
                          This function must be appropriate for the given architecture
    instSize            : Size of one instruction of the given architecture in bytes
*/
TOOLSresult
toolsElfXXGetCallgraphFuncs(const void *pimage,
                            const char *function_name,
                            char **callgraph_funcs, uint32_t max_callgraph_funcs,
                            uint32_t *num_callgraph_funcs,
                            toolsIndirectInstTestFun indirectTestFun,
                            toolsDirectInstTestFun directTestFun,
                            uint32_t instSize)
{
    TOOLSresult status = TOOLS_SUCCESS;

    elfXXSymbol *symtab = NULL;
    elfXXSymbol *func_symbol = NULL;
    elfXXSymbol *next_func_symbol = NULL;
    elfWord *symtab_shndx = NULL;
    elfXXSectionHeader *func_sh = NULL;
    elfWord symix = 0;
    size_t symtabsize = 0;
    char *strtab = NULL;
    size_t strtabsize = 0;
    elf_t image = (elf_t)pimage;
    uint32_t outcount = 0, i;
    char **related_funcs = NULL;
    uint32_t num_related_funcs = 0;
    uint32_t related_funcs_size = 128;
    tHashSet *visited = NULL;
    tList *nextList  = NULL;
    char *real_func_name = NULL;

    if (!pimage || !function_name)
        return TOOLS_ERROR_INVALID_VALUE;

    if (!isELF(pimage))
        return TOOLS_ERROR_INVALID_ELF;

    if (num_callgraph_funcs)
        *num_callgraph_funcs = 0;

    status = elfReadSymtab(image, &symtab, &symtab_shndx, &symtabsize);
    if (status != TOOLS_SUCCESS)
        goto error;

    status = elfReadStrtab(image, &strtab, &strtabsize);
    if (status != TOOLS_SUCCESS)
        goto error;

    status = elfFindSymbol(symtab, symtabsize, strtab, strtabsize,
                           function_name, &func_symbol, NULL);
    if (status != TOOLS_SUCCESS)
        goto error;


    /* Now that we have the symbol, compute the related functions */
    /*
        Step 1 : Push the function name into the next list
        Step 2 : Start loop, remove first element from next list
        Step 3 : Add to visited map
        Step 4 : Add to callgraph_funcs array and increase counts
        Step 5 : Find related funcs in array
        Step 6 : For each element, if symbol is not in visited,
        Step 7 : Add to tail of next list
    */
    real_func_name = strtab + func_symbol->name;
    nextList = toolsListNew();
    if (!nextList) {
        status = TOOLS_ERROR_OUT_OF_MEMORY;
        goto error;
    }
    visited = toolsHashSetNew(toolsPointerHashFun, toolsPointerEqualFun, 128);
    if (!visited) {
        status = TOOLS_ERROR_OUT_OF_MEMORY;
        goto error;
    }

    related_funcs = calloc(related_funcs_size, sizeof(*related_funcs));
    if (!related_funcs) {
        status = TOOLS_ERROR_OUT_OF_MEMORY;
        goto error;
    }

    status = toolsListAppend(nextList, real_func_name);
    if (status != TOOLS_SUCCESS)
        goto error;

    while (toolsListSize(nextList)) {
        char *nextfunc = NULL;
        uint32_t func_has_indirect_call = 0;

        nextfunc = (char*)toolsListGetElem(toolsListGetIterator(nextList));
        status = toolsListRemove(nextList, nextfunc, NULL, 0);
        if (status != TOOLS_SUCCESS)
            goto error;

        if (toolsHashSetFind(visited, nextfunc))
            continue;

        status = toolsHashSetInsert(visited, nextfunc);
        if (status != TOOLS_SUCCESS)
            goto error;

        if (outcount < max_callgraph_funcs) {
            callgraph_funcs[outcount] = nextfunc;
            ++outcount;
        }

        status = elfFindSymbol(symtab, symtabsize, strtab, strtabsize,
                               nextfunc, &next_func_symbol, &symix);
        if (status != TOOLS_SUCCESS)
            goto error;

        func_sh = elfXX_section_header(image, elfXX_symbol_shndx(symtab, symtab_shndx, symix));
        if (!func_sh) {
            status = TOOLS_ERROR_SECTION_NOT_FOUND;
            goto error;
        }

        status = elfXXHasAnyIndirectCall(image, func_sh, indirectTestFun, instSize, &func_has_indirect_call);
        if (status != TOOLS_SUCCESS)
            goto error;

        status = toolsElfXXGetRelatedFuncs(pimage,
                                           nextfunc, func_has_indirect_call,
                                           related_funcs, related_funcs_size,
                                           &num_related_funcs,
                                           directTestFun,
                                           instSize);
        if (status == TOOLS_ERROR_OUT_OF_MEMORY &&
            num_related_funcs > related_funcs_size) {
            /* Time to reattempt */
            free(related_funcs);
            related_funcs_size = num_related_funcs;
            related_funcs = (char**)malloc(sizeof(*related_funcs)*
                                           related_funcs_size);
            if (!related_funcs) {
                status = TOOLS_ERROR_OUT_OF_MEMORY;
                goto error;
            }
            status = toolsElfXXGetRelatedFuncs(pimage,
                                               nextfunc, func_has_indirect_call,
                                               related_funcs, related_funcs_size,
                                               &num_related_funcs,
                                               directTestFun,
                                               instSize);
            if (status != TOOLS_SUCCESS)
                goto error;
        }
        else if (status != TOOLS_SUCCESS)
            goto error;

        /* Iterate over returned functions, adding unvisited to the list  */
        for (i = 0; i < num_related_funcs; ++i) {
            if (toolsHashSetFind(visited, related_funcs[i]))
                continue;

            status = toolsListAppend(nextList, related_funcs[i]);
            if (status != TOOLS_SUCCESS)
                goto error;
        }

    }

    if (outcount > max_callgraph_funcs)
        status = TOOLS_ERROR_OUT_OF_MEMORY;

    /* Always update the total count */
    if (num_callgraph_funcs)
        *num_callgraph_funcs = outcount;

error:
    if (related_funcs) {
        free(related_funcs);
        related_funcs = NULL;
    }

    if (nextList) {
        toolsListDelete(nextList, NULL, NULL);
        nextList = NULL;
    }

    if (visited) {
        toolsHashSetDelete(visited, NULL, NULL);
        visited = NULL;
    }

    return status;
}

/* toolsElfXXGetTextSectionContents :
    This function can be used to query the text section contents for a symbol Index.
    Effectively, this can be used to return the SASS for a kernel.

    This function takes the symbol Index for the requested kernel and an ELF image.
    It copies the text section content in the user allocated buffer. Elf allows for multiple
    symbols to be defined for the same text section. This API returns the entire text section that
    may contain different symbols. This behavior is to keep parity with nvdisasm -fun option.

    Parameters
    pimage              : Pointer to ELF image
    symbolIx            : Valid symbol id for which the section contents were queried
    buf                 : User allocated buffer where the text section contents will be stored
    buf_sz              : Size of user allocated buffer
    text_section_sz     : Actual number of valid bytes copied to buffer. In case the API returns
                          an OUT_OF_MEMORY error user can re-allocate using this as a new size.
*/
TOOLSresult
toolsElfXXGetTextSectionContents(const void *pimage,
                                 uint32_t symbolIx,
                                 char *buf,
                                 uint32_t buf_sz,
                                 uint32_t *text_section_sz)
{
    TOOLSresult status = TOOLS_SUCCESS;

    elfXXSymbol *symtab = NULL;
    elfWord *symtab_shndx = NULL;
    size_t symtabsize = 0;
    elf_t image = (elf_t)pimage;
    elfXXSectionHeader *esh = NULL;
    char *eshname = NULL;

    if (!pimage || !buf || !buf_sz)
        return TOOLS_ERROR_INVALID_VALUE;

    if (!isELF(pimage))
        return TOOLS_ERROR_INVALID_ELF;

    if (text_section_sz)
        *text_section_sz = 0;

    status = elfReadSymtab(image, &symtab, &symtab_shndx, &symtabsize);
    if (status != TOOLS_SUCCESS)
        return status;

    if (symbolIx >= symtabsize)
        return TOOLS_ERROR_SYMBOL_NOT_FOUND;

    if (ELF_ST_TYPE(&symtab[symbolIx]) != STT_FUNC)
        return TOOLS_ERROR_SYMBOL_TYPE_MISMATCH;

    esh = elfXX_section_header(image, elfXX_symbol_shndx(symtab, symtab_shndx, symbolIx));
    if (!esh)
        return TOOLS_ERROR_SECTION_NOT_FOUND;

    eshname = elfXX_section_name(image, esh);
    if (!strstr(eshname, SHNAME_TEXT) || esh->type != SHT_PROGBITS)
        return TOOLS_ERROR_SECTION_TYPE_MISMATCH;

    if (text_section_sz)
        *text_section_sz = (uint32_t)esh->size;

    if (esh->size > buf_sz)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    memcpy(buf, (char*)image + esh->offset, (size_t)esh->size);

    return status;
}

TOOLSresult
toolsElfXXGetCudaSMVersion(const void* pimage,
                           uint32_t *sm_major,
                           uint32_t *sm_minor)
{
   elfXXFileHeader *efh = NULL;

   if (!pimage || !sm_major || !sm_minor)
        return TOOLS_ERROR_INVALID_VALUE;

    if (!isELF(pimage))
        return TOOLS_ERROR_INVALID_ELF;

    efh = elfXX_file_header((elf_t)pimage);

    *sm_major = EF_CUDA_SM(efh->flags)/10;
    *sm_minor = EF_CUDA_SM(efh->flags)%10;

    return TOOLS_SUCCESS;
}

static TOOLSresult
readXXElfWordTable(elfWord *elf_entries,
                   uint32_t entries_sz,
                   uint32_t *entries,
                   uint32_t buf_sz)
{
    uint32_t num_entries = 0;
    uint32_t i = 0;

    if (!elf_entries || !entries)
        return TOOLS_ERROR_INVALID_VALUE;

    num_entries = entries_sz / sizeof(*elf_entries);

    if (buf_sz / sizeof(*entries) < num_entries)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    for (i = 0; i < num_entries; ++i) {
        entries[i] = (uint32_t)elf_entries[i];
    }

    return TOOLS_SUCCESS;
}

static TOOLSresult
findElfWordTable(const void * pimage,
                 const char* function_name,
                 uint32_t tableId,
                 elfInfoElement **eInfoTable)
{
    TOOLSresult status = TOOLS_SUCCESS;

    elf_t image = (elf_t)pimage;

    elfXXSymbol *symtab = NULL;
    elfWord *symtab_shndx = NULL;
    size_t symtabsize = 0;

    elfXXSymbol *func_symbol = NULL;
    elfWord func_idx = 0;
    elfWord func_shndx = 0;

    elfXXSectionHeader *info_sh = NULL;

    char *strtab = NULL;
    size_t strtabsize = 0;

    uint32_t i = 0;

    elfInfoElement *einfo = NULL;
    elfInfoElement *einfo_max = NULL;

    if (!pimage || !function_name)
        return TOOLS_ERROR_INVALID_VALUE;

    if (!isELF(pimage))
        return TOOLS_ERROR_INVALID_ELF;

    /* Find the symbol and its section header index */
    status = elfReadSymtab(image, &symtab, &symtab_shndx, &symtabsize);
    if (status != TOOLS_SUCCESS)
        return status;

    status = elfReadStrtab(image, &strtab, &strtabsize);
    if (status != TOOLS_SUCCESS)
        return status;

    status = elfFindSymbol(symtab, symtabsize, strtab, strtabsize,
                           function_name, &func_symbol, &func_idx);
    if (status != TOOLS_SUCCESS)
        return status;

    func_shndx = elfXX_symbol_shndx(symtab, symtab_shndx, func_idx);
    if (!func_shndx)
        return TOOLS_ERROR_SYMBOL_NOT_FOUND;

    /* Find the info section for this symbol */
    for (i = 0; i < elfXX_shnum(image); ++i) {
        elfXXSectionHeader *elf_sh = NULL;

        elf_sh = elfXX_section_header(image, i);
        if (!elf_sh) {
            return TOOLS_ERROR_INVALID_ELF;
        }

        if (elf_sh->type == SHT_CUDA_INFO &&
            elf_sh->info == func_shndx) {
            info_sh = elf_sh;
            break;
        }
    }

    if (!info_sh)
        return TOOLS_ERROR_SECTION_NOT_FOUND;

    /* Find the matching attribute within the info section */
    einfo = (elfInfoElement *) (void *)((char *) image + info_sh->offset);
    einfo_max = (elfInfoElement *) (void *)((char *)einfo + info_sh->size);

    while (einfo < einfo_max) {
        elfHalf size = 0;

        switch (einfo->format) {
            case EIFMT_ERROR:
                return TOOLS_ERROR_INVALID_ELF;
            case EIFMT_NVAL:
            case EIFMT_BVAL:
            case EIFMT_HVAL:
                size = 0; // header includes payload
                break;
            case EIFMT_SVAL:
                size = (elfHalf) einfo->value.size;
                break;
            default:
                return TOOLS_ERROR_INVALID_ELF;
        }

        if (einfo->attr == tableId) {
            if (eInfoTable)
                *eInfoTable = (elfInfoElement*)(void*)(einfo);

            return TOOLS_SUCCESS;
        }

        /* Next attribute */
        einfo = (elfInfoElement *) (void *)((char *) (einfo) + size);
        einfo = einfo + 1;
    }

    if (eInfoTable)
        *eInfoTable = NULL;

    return TOOLS_SUCCESS;
}

/* toolsElfXXGetAtomSysInstrOffsets :
    This function takes the symbol Index for the requested function and an ELF image.
    It returns the offsets of system-scoped atomic instructions within this function (if any).

    Parameters
    pimage              : Pointer to ELF image
    function_name       : NULL terminated C string containing name of kernel
    offsets             : User allocated buffer where the offsets will be stored
    buf_sz              : Size of user allocated buffer
    offsets_sz          : Actual number of valid bytes copied to buffer. In case the API returns
                          an OUT_OF_MEMORY error user can re-allocate using this as a new size.
*/
TOOLSresult
toolsElfXXGetAtomSysInstrOffsets(const void* pimage,
                                 const char* function_name,
                                 uint32_t *offsets,
                                 uint32_t buf_sz,
                                 uint32_t *offsets_sz)
{
    TOOLSresult status = TOOLS_SUCCESS;
    elfInfoElement *einfo = NULL;
    elfInfoAtomSysInstrOffsets *eio = NULL;
    elfHalf size = 0;

    status = findElfWordTable(pimage,
                              function_name,
                              EIATTR_ATOM_SYS_INSTR_OFFSETS,
                              &einfo);

    if ((status != TOOLS_SUCCESS) || (einfo == NULL))
        return status;

    size = (elfHalf) einfo->value.size;
    eio = (elfInfoAtomSysInstrOffsets*) (void *)(einfo + 1);

    /* Get number of symbols and multiply with size of offset in user buffer.
       EIATTR_ATOM_SYS_INSTR_OFFSETS is of format EIFMT_SVAL, so we can use
       einfo->value.size to compute number of offsets in payload. */
    if (offsets_sz)
        *offsets_sz = sizeof(*offsets) * (size / sizeof(elfInfoAtomSysInstrOffsets));

    /* Fill in offsets and return */
    return readXXElfWordTable(eio,
                              size,
                              offsets,
                              buf_sz);
}

/* toolsElfXXGetCoopGroupInstrOffsets :
    This function takes the symbol Index for the requested function and an ELF image.
    It returns the offsets of elided warpsync instructions within this function (if any).

    Parameters
    pimage              : Pointer to ELF image
    function_name       : NULL terminated C string containing name of kernel
    offsets             : User allocated buffer where the offsets will be stored
    buf_sz              : Size of user allocated buffer
    offsets_sz          : Actual number of valid bytes copied to buffer. In case the API returns
                          an OUT_OF_MEMORY error user can re-allocate using this as a new size.
*/
TOOLSresult
toolsElfXXGetCoopGroupInstrOffsets(const void* pimage,
                                   const char* function_name,
                                   uint32_t *offsets,
                                   uint32_t buf_sz,
                                   uint32_t *offsets_sz)
{
    TOOLSresult status = TOOLS_SUCCESS;
    elfInfoElement *einfo = NULL;
    elfInfoCoopGroupInstrOffsets *eio = NULL;
    elfHalf size = 0;

    status = findElfWordTable(pimage,
                              function_name,
                              EIATTR_COOP_GROUP_INSTR_OFFSETS,
                              &einfo);

    if ((status != TOOLS_SUCCESS) || (einfo == NULL))
        return status;

    size = (elfHalf) einfo->value.size;
    eio = (elfInfoCoopGroupInstrOffsets*) (void *)(einfo + 1);

    /* Get number of symbols and multiply with size of offset in user buffer.
       EIATTR_COOP_GROUP_INSTR_OFFSETS is of format EIFMT_SVAL, so we can use
       einfo->value.size to compute number of offsets in payload. */
    if (offsets_sz)
        *offsets_sz = sizeof(*offsets) * (size / sizeof(elfInfoCoopGroupInstrOffsets));

    /* Fill in offsets and return */
    return readXXElfWordTable(eio,
                              size,
                              offsets,
                              buf_sz);
}

/* toolsElfXXGetPgoInfo :
    This function can be used to query the PGO info section for a symbol Index.

    This function takes the symbol Index for the requested kernel and an ELF
    image. It copies the PGO info section content in the user allocated buffer.

    The function flow can be described as follows
    1.  Find sec_id of the given sym_id
    2.  For all section in section table
        a.  If section's type  == CUDA_PGO_INFO && 'info' of this section ==
        sec_id in (1) then
            this is the section we want
        b.  Else do the loop


    Parameters
    pimage              : Pointer to ELF image
    symbolIx            : Valid symbol id for which the section contents were
                          queried
    buf                 : User allocated buffer where the contents for PGO
                          section will be stored. The format will be
                          requestType, numPgoEntries and subsequent 'n'
                          elfPgoInfoEntry. Where one elfPgoInfoEntry is
                          basicBlockIndex, numOffsets, followed by 'n'
                          elfPgoInstrOffset. 
    buf_sz              : Size of user allocated buffer
    written_sz          : Actual number of valid bytes copied to buffer. In case
                          the API returns an OUT_OF_MEMORY error user can
                          re-allocate using this as a new size. If the API
                          returns SUCCESS and written_sz is 0 that means there
                          is no corresponding PGO section.
*/
TOOLSresult
toolsElfXXGetPgoInfo(const void *pimage,
                     uint32_t symbolIx,
                     uint32_t *buf,
                     uint32_t buf_sz,
                     uint32_t *written_sz)
{
    TOOLSresult status = TOOLS_SUCCESS;

    elfXXSymbol *symtab = NULL;
    elfWord *symtab_shndx = NULL;
    size_t symtabsize = 0;
    elf_t image = (elf_t)pimage;
    elfXXSectionHeader *esh = NULL;
    char *eshname = NULL;
    uint32_t index = 0;
    elfWord symbol_shndx;

    if (!pimage || !buf || !buf_sz)
        return TOOLS_ERROR_INVALID_VALUE;

    if (!isELF(pimage))
        return TOOLS_ERROR_INVALID_ELF;

    if (written_sz)
        *written_sz = 0;

    status = elfReadSymtab(image, &symtab, &symtab_shndx, &symtabsize);
    if (status != TOOLS_SUCCESS) 
        return status;

    if (symbolIx >= symtabsize)
        return TOOLS_ERROR_SYMBOL_NOT_FOUND;

    if (ELF_ST_TYPE(&symtab[symbolIx]) != STT_FUNC)
        return TOOLS_ERROR_SYMBOL_TYPE_MISMATCH;

    symbol_shndx = elfXX_symbol_shndx(symtab, symtab_shndx, symbolIx);
    for (index = 0; index < elfXX_shnum(image); index++) {
        esh = elfXX_section_header(image, index);
        if (!esh)
            return TOOLS_ERROR_SECTION_NOT_FOUND;

        if ((esh->type == SHT_CUDA_PGO_INFO) &&
            (esh->info == symbol_shndx)) {
            break;
        }
    }

    if (index == elfXX_shnum(image)) {
        // No PGO section found, return from here
        return TOOLS_SUCCESS;
    }

    eshname = elfXX_section_name(image, esh);
    if (!strstr(eshname, SHNAME_PGO_INFO))
        return TOOLS_ERROR_SECTION_TYPE_MISMATCH;

    if (written_sz)
        *written_sz = (uint32_t)esh->size;

    if (esh->size > buf_sz)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    memcpy(buf, (char*)image + esh->offset, (size_t)esh->size);

    return status;
}

/* toolsElfXXGetAtomF16InstrOffsets :
    This function takes the symbol Index for the requested function and an ELF image.
    It returns the offsets of atomic operations on fp16 types within this function (if any).
    DEPRECATED: the compiler should not generate these offsets anymore.
    See toolsElfXXGetAtomF16RegMap instead.

    Parameters
    pimage              : Pointer to ELF image
    function_name       : NULL terminated C string containing name of kernel
    offsets             : User allocated buffer where the offsets will be stored
    buf_sz              : Size of user allocated buffer
    offsets_sz          : Actual number of valid bytes copied to buffer. In case the API returns
                          an OUT_OF_MEMORY error user can re-allocate using this as a new size.
*/
TOOLSresult
toolsElfXXGetAtomF16InstrOffsets(const void* pimage,
                                 const char* function_name,
                                 uint32_t *offsets,
                                 uint32_t buf_sz,
                                 uint32_t *offsets_sz)
{
    TOOLSresult status = TOOLS_SUCCESS;
    elfInfoElement *einfo = NULL;
    elfInfoAtomF16InstrOffsets *eio = NULL;
    elfHalf size = 0;

    status = findElfWordTable(pimage,
                              function_name,
                              EIATTR_ATOMF16_EMUL_INSTR_OFFSETS,
                              &einfo);

    if ((status != TOOLS_SUCCESS) || (einfo == NULL))
        return status;

    size = (elfHalf) einfo->value.size;
    eio = (elfInfoAtomF16InstrOffsets*) (void *)(einfo + 1);

    /* Get number of symbols and multiply with size of offset in user buffer.
       EIATTR_ATOMF16_INSTR_OFFSETS is of format EIFMT_SVAL, so we can use
       einfo->value.size to compute number of offsets in payload. */
    if (offsets_sz)
        *offsets_sz = sizeof(*offsets) * (size / sizeof(elfInfoAtomF16InstrOffsets));

    /* Fill in offsets and return */
    return readXXElfWordTable(eio,
                              size,
                              offsets,
                              buf_sz);
}

/* toolsElfXXGetAtomF16RegMap:
    This function takes the symbol Index for the requested function and an ELF image.
    It returns the offsets of atomic operations on fp16 types, along with the register number
    holding the original address within this function (if any).

    Parameters
    pimage              : Pointer to ELF image
    function_name       : NULL terminated C string containing name of kernel
    offsets             : User allocated buffer where the offsets will be stored
    regIds              : User allocated buffer where the register numbers will be stored
    buf_sz              : Size of user allocated buffer
    written_sz          : Actual number of valid bytes copied to buffer. In case the API returns
                          an OUT_OF_MEMORY error user can re-allocate using this as a new size.
*/
TOOLSresult
toolsElfXXGetAtomF16RegMap(const void* pimage,
                           const char* function_name,
                           uint32_t *offsets,
                           uint32_t *regIds,
                           uint32_t buf_sz,
                           uint32_t *written_sz)
{
    TOOLSresult status = TOOLS_SUCCESS;
    elfInfoElement *einfo = NULL;
    elfInfoAtomF16InstrOffsetRegNoPair *eio = NULL;
    elfHalf size = 0;
    uint32_t num_entries = 0, i = 0;

    status = findElfWordTable(pimage,
                              function_name,
                              EIATTR_ATOM16_EMUL_INSTR_REG_MAP,
                              &einfo);

    if ((status != TOOLS_SUCCESS) || (einfo == NULL))
        return status;

    size = (elfHalf) einfo->value.size;
    eio = (elfInfoAtomF16InstrOffsetRegNoPair*) (void *)(einfo + 1);

    /* Get number of symbols and multiply with size of offset in user buffer.
       EIATTR_ATOM16_EMUL_INSTR_REG_MAP is of format EIFMT_SVAL, so we can use
       einfo->value.size to compute number of offsets in payload. */
    num_entries = (uint32_t)size / sizeof(*eio);

    if (written_sz)
        *written_sz = sizeof(*offsets) * num_entries;

    if (buf_sz / sizeof(*offsets) < num_entries)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    // Fill in offsets+regs
    for (i = 0; i < num_entries; ++i) {
        offsets[i] = eio[i].instrOffset;
        regIds[i] = eio[i].regNo;
    }

    return TOOLS_SUCCESS;
}

TOOLSresult
toolsElfXXGetWarpWideInstrOffsets(const void* pimage,
                                  const char* function_name,
                                  uint32_t *offsets,
                                  uint32_t buf_sz,
                                  uint32_t *offsets_sz)
{
    TOOLSresult status = TOOLS_SUCCESS;
    elfInfoElement *einfo = NULL;
    elfInfoWarpWideInstrOffsets *eio = NULL;
    elfHalf size = 0;

    status = findElfWordTable(pimage,
                              function_name,
                              EIATTR_INT_WARP_WIDE_INSTR_OFFSETS,
                              &einfo);

    if ((status != TOOLS_SUCCESS) || (einfo == NULL))
        return status;

    size = (elfHalf) einfo->value.size;
    eio = (elfInfoWarpWideInstrOffsets*) (void *)(einfo + 1);

    /* Get number of symbols and multiply with size of offset in user buffer.
       EIATTR_INT_WARP_WIDE_INSTR_OFFSETS is of format EIFMT_SVAL, so we can use
       einfo->value.size to compute number of offsets in payload. */
    if (offsets_sz)
        *offsets_sz = sizeof(*offsets) * (size / sizeof(elfInfoWarpWideInstrOffsets));

    /* Fill in offsets and return */
    return readXXElfWordTable(eio,
                              size,
                              offsets,
                              buf_sz);
}

/* Zero out section, its header and its name in .shstrtab */
static void
elfXXEraseSection(elf_t image, elfXXSectionHeader *header, char *pShstrtab)
{
    if (header) {
        uint32_t nameIdx = header->name;

        if (nameIdx != 0) {
            char *name = &pShstrtab[header->name];
            /* `strlen` here can be avoided, but the caller would need to calculate the header name
               based on the kernel name, which can lead to brittle code due to different possible
               section name prefixes, e.g. .rel and .rela, .nv.constant0. and .nv.constant10., etc.
            */
            strncpy(name, ".hidden", strlen(name) + 1);
        }

        if (header->type != SHT_NOBITS && header->size != 0) {
            memset(((char *)image) + header->offset, 0, (size_t)header->size);
        }

        memset(header, 0, sizeof(*header));
        /* Restore the (modified) name */
        header->name = nameIdx;
    }
}

/* Zero out symbol header and its name in .strtab */
static void
elfXXEraseSymbol(elf_t image, elfXXSymbol *symbol, char *pStrtab)
{
    if (symbol) {
        elfByte info;
        elfWord nameIdx;

        info = symbol->info;
        nameIdx = symbol->name;

        if (nameIdx != 0) {
            char *name = &pStrtab[symbol->name];

            strncpy(name, ".hidden", strlen(name) + 1);
        }
        
        memset(symbol, 0, sizeof(*symbol));
        /* Restore the bind/type and the (modified) name */
        symbol->info = info;
        symbol->name = nameIdx;
    }
}

#define STRING_HAS_PREFIX(str, prefix) (strncmp((str), (prefix), strlen(prefix)) == 0)

TOOLSresult
toolsElfXXStripHiddenSymbols(void* pimage)
{
    elf_t image = (elf_t)pimage;
    uint64_t sectionsCount;
    elfXXSectionHeader *symtabHeader;
    uint64_t symtabHeaderIndex;
    elfXXSectionHeader *shstrtabHeader;
    elfXXSectionHeader *strtabHeader;
    elfXXSymbol *pSymtab;
    uint64_t symbolsCount;
    char *pShstrtab;
    char *pStrtab;
    uint32_t *mapSectionHeaderIndexToSectionSymbolIndex;
    uint32_t symIdx;

    sectionsCount = elfXX_shnum(image);
    symtabHeader = elfXX_typed_section_header(image, SHT_SYMTAB);
    shstrtabHeader = elfXX_named_section_header(image, ".shstrtab");
    strtabHeader = elfXX_named_section_header(image, ".strtab");
    
    if (!symtabHeader || !strtabHeader || !strtabHeader) {
        return TOOLS_ERROR_SECTION_NOT_FOUND;
    }

    symtabHeaderIndex = (uint64_t)(symtabHeader - elfXX_section_header(image, 0));

    pSymtab = (elfXXSymbol*)((char*)image + symtabHeader->offset);
    symbolsCount = symtabHeader->size / symtabHeader->entsize;

    pShstrtab = (char*)image + shstrtabHeader->offset;
    pStrtab = (char*)image + strtabHeader->offset;

    mapSectionHeaderIndexToSectionSymbolIndex = (uint32_t *)calloc((size_t)sectionsCount, sizeof(uint32_t));
    if (!mapSectionHeaderIndexToSectionSymbolIndex) {
        return TOOLS_ERROR_OUT_OF_MEMORY;
    }

    for (symIdx = 0; symIdx < symbolsCount; symIdx++) {
        elfXXSymbol *sym;

        sym = &pSymtab[symIdx];
        if (ELF_ST_TYPE(sym) == STT_SECTION) {
            mapSectionHeaderIndexToSectionSymbolIndex[sym->shndx] = symIdx;
        }
    }

    for (symIdx = 0; symIdx < symbolsCount; symIdx++) {
        elfXXSymbol *sym;
        uint32_t sym_shndx;
        elfXXSymbol *textSectionSymbol;
        uint32_t headerIdx;
        elfXXSectionHeader *header;

        sym = &pSymtab[symIdx];
        sym_shndx = sym->shndx;

        if ((sym->other & STO_CUDA_OBSCURE) == 0) {
            continue;
        }

        elfXXEraseSymbol(image, sym, pStrtab);

        /* This is not expected to be true, but in case it ever is, we avoid corrupting the ELF by skipping this symbol */
        if (sym_shndx == 0) {
            continue;
        }

        /* Text section, e.g. .text.hidden_kernel */
        elfXXEraseSection(image, elfXX_section_header(image, sym_shndx), pShstrtab);

        /* Erase the section's symbol if it exists */
        textSectionSymbol = &pSymtab[mapSectionHeaderIndexToSectionSymbolIndex[sym_shndx]];
        /* Below would be false in case map returns 0 and the zero symbol is returned */
        if (textSectionSymbol->shndx == sym_shndx) {
            elfXXEraseSymbol(image, textSectionSymbol, pStrtab);
        }

        for (headerIdx = 0, header = elfXX_section_header(image, 0); headerIdx < sectionsCount; headerIdx++, header++) {
            if (header->info != sym_shndx) {
                continue;
            }

            if (/* Relocation sections, e.g. .rel.text.hidden_kernel */
                (header->link == symtabHeaderIndex && (header->type == SHT_REL || header->type == SHT_RELA)) ||
                /* CUDA info sections, e.g. .nv.info.hidden_kernel */
                (header->link == symtabHeaderIndex && header->type == SHT_CUDA_INFO) ||
                /* Constant bank sections, e.g. .nv.constant0.hidden_kernel */
                (header->link == 0 && header->type == SHT_PROGBITS && STRING_HAS_PREFIX(&pShstrtab[header->name], ".nv.constant")) ||
                /* Shared data sections, e.g. .nv.shared.hidden_kernel */
                (header->link == 0 && header->type == SHT_NOBITS && STRING_HAS_PREFIX(&pShstrtab[header->name], ".nv.shared.")))
            {
                elfXXSymbol *headerSymbol;

                /* Erase the section's symbol if it exists */
                headerSymbol = &pSymtab[mapSectionHeaderIndexToSectionSymbolIndex[headerIdx]];
                /* Below would be false in case map returns 0 and the zero symbol is returned */
                if (headerSymbol->shndx == headerIdx) {
                    elfXXEraseSymbol(image, headerSymbol, pStrtab);
                }

                elfXXEraseSection(image, header, pShstrtab);
            }
        }
    }

    free(mapSectionHeaderIndexToSectionSymbolIndex);

    return TOOLS_SUCCESS;
}

/* Callback for tool container cleanup */
static void
cleanDwarfItem(void *item, void *ignore)
{
    free(item);
}

static void
cleanDwarfCIE(void *ciep, void *ignore)
{
    DwarfCIE *cie = (DwarfCIE *)ciep;
    if (!ciep)
        return;

    if (cie->pcTofde)
        toolsRangeMapDestroy(&cie->pcTofde, cleanDwarfItem, NULL);

    memset(cie, 0, sizeof(DwarfCIE));
    free(ciep);
}

/* Reclaim/delete the dynamically allocated bits within the debug frame. */
static void
cleanDwarfDebugFrame(DwarfDebugFrame *frame)
{
    if (!frame)
        return;

    if (frame->pcTocie)
        toolsRangeMapDestroy(&frame->pcTocie, cleanDwarfCIE, NULL);

    memset(frame, 0, sizeof(DwarfDebugFrame));
}

/* Used for reading 'data' from an input stream (elf stream) and
 * storing the result into 'result'. 
 *
 * Returns a pointer to the next data in the data stream, or NULL if invalid
 * arguments.
 */
static const uint8_t *
readFrameData(const uint8_t *data, const uint8_t *data_end,
              size_t result_size, void *result)
{
    if (!data || !result || ((data + result_size) > data_end))
        return NULL;
    memcpy(result, data, result_size);
    return data + result_size;
}

/* Parse the Frame Description Entries (FDE) in the CIE:
 * DWARF 2.0 Page 62.
 *
 * This is used to validate the FDE's cie_id field, which just represents which
 * CIE the FDE belongs to.
 *
 * The result is returned in *fdep.
 */
static TOOLSresult
parseDwarfFDE(const uint8_t **datap, const DwarfCIE *cie, DwarfFDE **fdep)
{
    elfXXAddr cie_id;
    uint32_t cie_id32;
    int isCIE;
    DwarfFDE *fde;
    int fdeLength = sizeof(uint32_t);
    const uint8_t *data = *datap;
    const uint8_t *data_end;
    const uint8_t *data_start = *datap;

    fde = calloc(1, sizeof(DwarfFDE));
    if (!fde)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    /* Initialize */
    *fdep = fde;

    /* FDE start */
    fde->base = data;

    /* FDE length */
    fde->length = *(uint32_t *)data;
    data += sizeof(uint32_t);
    if (fde->length == ~0) {
        fde->length = (uint32_t) *(uint64_t *)data;
        data += sizeof(uint64_t);
        fdeLength += sizeof(uint64_t);
    }

    /* FDE end (entire stream length for this FDE, including length field) */
    fde->end = fde->base + fde->length + fdeLength;

    /* "length" does not include itself in the size, so find the end of the CIE
     * here.  Use the 'end' for safety checks to ensure we don't read past it.
     */
    data_end = data + fde->length;

    /* Pointer to the CIE this belongs to.
     * Used for sanity check or to differentiate between a CIE or FDE.
     */
    if (fdeLength == sizeof(uint32_t)) {
        /* Earlier version of nvasm always coded CIE-ids as 32-bits */
        data = readFrameData(data, data_end, sizeof(cie_id32), &cie_id32);
        isCIE = (cie_id32 == ~0);
    }
    else {
        data = readFrameData(data, data_end, sizeof(cie_id), &cie_id);
        isCIE = (cie_id == ~0ULL);
    }

    if (isCIE) {
        /* Found a CIE: Revert the data pointer and return null.
         * This is expected if a .debug_frame has multiple CIE entries.
         */
        *datap = data_start;
        free(fde);
        *fdep = NULL;
        return TOOLS_SUCCESS;
    }
#if 0 /* TODO: Re-enable this once nvcc fixes the way they generate cie_pointer */
    else if (cie_id != cie->offset) {
        /* This is a FDE that belongs to a different CIE */
        free(fde);
        *fdep = NULL;
        return TOOLS_ERROR_UNKNOWN;
    }
#endif

    /* Program address used to locate this FDE given a PC
     * initial_location is an address size unit (uintptr_t).
     */
    data = readFrameData(data, data_end, sizeof(elfXXAddr),
                         &fde->initial_location);

    /* Number of bytes of program instructions this FDE covers 
     * address_range is an address size unit (uintptr_t).
     */
    data = readFrameData(data, data_end, sizeof(elfXXAddr),
                         &fde->address_range);
    
    /* Sanity check */
    if (data > data_end) {
        free(fde);
        *fdep = NULL;
        return TOOLS_ERROR_UNKNOWN;
    }

    /* CFA instructions */
    fde->instructions = data;

    /* Update to the first byte just after this FDE */
    *datap = data_end;

    return TOOLS_SUCCESS;
}

/* Parse the Common Information Entry (CIE) from the dwarf .debug_frame.
 *
 * This updates the "data" pointer to point to the next record, after the CIEs.
 * DWARF 2.0 Page 61.
 *
 * The result is returned in *ciep;
 */
static TOOLSresult
parseDwarfCIE(const uint8_t **datap, const uint32_t cie_offset, const
              DwarfDebugFrame *frame, DwarfCIE **ciep)
{
    TOOLSresult res = TOOLS_SUCCESS;
    elfXXAddr id;
    uint32_t  id32;
    uint8_t   version;
    uint8_t   dwarf1_return_address_column;
    DwarfCIE *cie;
    DwarfFDE *fde;
    int      cieLength = sizeof(uint32_t);
    const uint8_t *data = *datap;
    const uint8_t *data_end;

    cie = calloc(1, sizeof(DwarfCIE));
    if (!cie)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    /* Initialize */
    *ciep = cie;

    /* CIE start */
    cie->base = data;
    cie->offset = cie_offset;

    /* CIE length including the instructions it contains */
    cie->length = *(uint32_t *)data;
    data += sizeof(uint32_t);
    if (cie->length == ~0) {
        cie->length = (uint32_t) *(uint64_t *)data;
        data += sizeof(uint64_t);
        cieLength += sizeof(uint64_t);
    }
    
    /* CIE end (entire stream length for this CIE, including length field) */
    cie->end = cie->base + cie->length + cieLength;

    /* "length" does not include itself in the size, so find the end of the CIE
     * here.  Use the 'end' for safety checks to ensure we don't read past it.
     */
    data_end = data + cie->length;

    /* To distinguish between CIE and FDEs (expect a CIE here (-1)) */
    if (cieLength == sizeof(uint32_t)) {
        /* Earlier version of nvasm always coded CIE-ids as 32-bits */
        data = readFrameData(data, data_end, sizeof(id32), &id32);
        if (id32 != ~0)
            goto cie_error;
    }
    else {
        data = readFrameData(data, data_end, sizeof(id), &id);
        if (id != ~0ULL)
            goto cie_error;
    }

    /* Version check - versions 1 and 3 supported */
    data = readFrameData(data, data_end, sizeof(version), &version);
    if (version != DWARF_FRAME_VERSION1 && version != DWARF_FRAME_VERSION3)
        goto cie_error;

    /* Augmentation */
    if (data[0] != 0x0)
        data += strlen((const char *)data);
    ++data;

    /* Alignments (data alignment can be negative) */
    cie->code_alignment_factor = (int32_t)decodeULEB((char **)&data);
    cie->data_alignment_factor = (int32_t)decodeSLEB((char **)&data);

    /* Sanity */
    if (data > data_end)
        goto cie_error;

    /* Column the return register is located in */
    switch (version) {
    case DWARF_FRAME_VERSION1:
        data = readFrameData(data, data_end,
                             sizeof(dwarf1_return_address_column),
                             &dwarf1_return_address_column);
        cie->return_address_column = dwarf1_return_address_column;
        break;

    case DWARF_FRAME_VERSION3:
        cie->return_address_column = (int32_t)decodeULEB((char **)&data);
        break;
    }
    
    /* Sanity */
    if (data > data_end)
        goto cie_error;

    /* CFA instructions */
    cie->initial_instructions = data;

    /* Allocate list for FDE entries */
    res = toolsRangeMapCreate(&cie->pcTofde);
    if (res != TOOLS_SUCCESS)
        goto cie_error;

    /* Skip past the instructions to the end of the CIE where the FDEs start */
    *datap = data_end;
    cie->initial_location = 0;
    cie->end_location = 0;

    /* For each FDE in the CIE in the .debug_frame... */
    while (*datap < frame->end) {
        TOOLSresult res = parseDwarfFDE(datap, cie, &fde);
        if (res != TOOLS_SUCCESS)
            goto cie_error;
        
        /* Success but no FDE found, we reached the end of the FDE stream */
        if (!fde)
            break;

        /* We have a valid FDE, so add it to the list of FDEs */
        res = toolsRangeMapInsertByRange(cie->pcTofde, fde->initial_location, fde->address_range, fde);
        if (res != TOOLS_SUCCESS) {
            cleanDwarfItem(fde, NULL);
            goto cie_error;
        }

        if (cie->initial_location == 0 || cie->initial_location > fde->initial_location)
            cie->initial_location = fde->initial_location;
        if (cie->end_location < fde->initial_location + fde->address_range)
            cie->end_location = fde->initial_location + fde->address_range;

    }

    if (cie->initial_location == cie->end_location) {
        /* Empty CIE, skip it */
        cleanDwarfCIE(cie, NULL);
        *ciep = NULL;
    }

    /* Success! */
    return TOOLS_SUCCESS;

cie_error:
    cleanDwarfCIE(cie, NULL);
    *ciep = NULL;
    return TOOLS_ERROR_UNKNOWN;
}

/* Parse the contents of the .debug_frame ELF section */
static TOOLSresult
parseDwarfDebugFrame(const elf_t image, const elfXXSectionHeader *sect,
                     DwarfDebugFrame *frame)
{
    TOOLSresult    res;
    DwarfCIE      *cie;
    const uint8_t *data, *base;

    res = toolsRangeMapCreate(&frame->pcTocie);
    if (res != TOOLS_SUCCESS)
        return res;

    /* Point the data to the start of the debug_frame (first CIE entry) */
    base = data = (uint8_t *)image + sect->offset;
    frame->end = (uint8_t *)(base + sect->size);

    /* For each CIE in the .debug_frame... */
    res = TOOLS_SUCCESS;
    while (data < frame->end) {
        res = parseDwarfCIE(&data, (uint32_t)(data - base), frame, &cie);
        if (res != TOOLS_SUCCESS)
            goto parse_frame_error;

        if (cie) {
            /* We have a valid CIE, add it to the list of CIEs */
            res = toolsRangeMapInsertByRange(frame->pcTocie, cie->initial_location, cie->end_location - cie->initial_location, cie);
            if (res != TOOLS_SUCCESS) {
                cleanDwarfCIE(cie, NULL);
                /* WAR: Compiler generates redundant CIEs for some reason */
                if (res != TOOLS_ERROR_DUPLICATE_KEY)
                    goto parse_frame_error;
            }
        }
    }

    return TOOLS_SUCCESS;

parse_frame_error:
    cleanDwarfDebugFrame(frame);
    return res;
}

/* Parse the input image extracting out the debug_frame contents necessary to
 * replicate the call return stack (CRS) for stack unwinding.
 */
TOOLSresult
toolsElfXXGetDebugFrame(const void *pimage, DwarfDebugFrame *frame)
{
    elfXXSectionHeader *sect;
    elf_t image = (elf_t)pimage;

    if (!frame)
        return TOOLS_ERROR_INVALID_VALUE;

    memset(frame, 0, sizeof(DwarfDebugFrame));

    if (!isELF(image))
        return TOOLS_ERROR_INVALID_ELF;

    /* Parse the image obtaining 'debug_frame' */
    sect = elfXX_named_section_header(image, ".debug_frame");
    if (!sect)
        return TOOLS_ERROR_SECTION_NOT_FOUND;

    /* Unlock the magic */
    return parseDwarfDebugFrame(image, sect, frame);
}

#endif
