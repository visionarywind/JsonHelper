/*
 * Copyright 2007-2011 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "tools_shared_hashset.h"

/* Functions */

tHashSet *toolsHashSetNew(tHashFun hash, tEqualFun equal, size_t numBuckets)
{
    return toolsHashMapNew(hash, equal, numBuckets);
}

TOOLSresult toolsHashSetInsert(tHashSet *s, void *entry)
{
    if (toolsHashMapFind(s, tHashMapPtrToKey(entry)))
        return TOOLS_SUCCESS;

    return toolsHashMapInsert(s, tHashMapPtrToKey(entry), entry);
}

tHashSetItr *toolsHashSetGetIterator(const tHashSet *s)
{
    return toolsHashMapGetIterator(s);
}

tHashSetItr *toolsHashSetGetNext(const tHashSet *s, const tHashSetItr *i)
{
    return toolsHashMapGetNext(s, i);
}

void *toolsHashSetGetEntry(const tHashSetItr *i)
{
    return toolsHashMapGetEntry(i);
}

void *toolsHashSetFind(const tHashSet *s, const void *entry)
{
    return toolsHashMapFind(s, tHashMapPtrToKey(entry));
}

uint32_t toolsHashSetContains(const tHashSet *s, const void *entry)
{
    if (toolsHashMapContains(s, tHashMapPtrToKey(entry)))
        return 1;
    else
        return 0;
}

size_t toolsHashSetSize(const tHashSet *s)
{
    return toolsHashMapSize(s);
}

TOOLSresult toolsHashSetDelete(tHashSet *s, tSingleFun del, void *data)
{
    return toolsHashMapDelete(s, del, data);
}

tHashSet *toolsHashSetIntersect(const tHashSet *s1, const tHashSet *s2)
{
    size_t size1, size2;
    tHashSet *newSet;
    tHashSetItr *itr;
    const tHashSet *smallerOne;

    if (!s1 || !s2)
        return NULL;

    size1 = toolsHashSetSize(s1);
    size2 = toolsHashSetSize(s2);

    smallerOne = size1 < size2 ? s1 : s2;
    newSet = toolsHashMapCopyTemplate(smallerOne);
    if (!newSet)
        return NULL;

    for (itr = toolsHashSetGetIterator(s1);
         itr;
         itr = toolsHashSetGetNext(s1, itr)) {
        void *entry = toolsHashSetGetEntry(itr);
        if (toolsHashSetContains(s2, entry)) {
            if (toolsHashSetInsert(newSet, entry) != TOOLS_SUCCESS)
                goto failed;
        }
    }

    return newSet;

failed:
    toolsHashSetDelete(newSet, NULL, NULL);
    return NULL;
}

tHashSet *toolsHashSetUnion(const tHashSet *s1, const tHashSet *s2)
{
    size_t size1, size2;
    tHashSet *newSet;
    tHashSetItr *itr;
    const tHashSet *largerOne;

    if (!s1 || !s2)
        return NULL;

    size1 = toolsHashSetSize(s1);
    size2 = toolsHashSetSize(s2);

    largerOne = size1 > size2 ? s1 : s2;
    newSet = toolsHashMapCopyTemplate(largerOne);
    if (!newSet)
        return NULL;

    for (itr = toolsHashSetGetIterator(s1);
         itr;
         itr = toolsHashSetGetNext(s1, itr)) {
        void *entry = toolsHashSetGetEntry(itr);
        if (toolsHashSetInsert(newSet, entry) != TOOLS_SUCCESS)
            goto failed;
    }

    for (itr = toolsHashSetGetIterator(s2);
         itr;
         itr = toolsHashSetGetNext(s2, itr)) {
        void *entry = toolsHashSetGetEntry(itr);
        if (toolsHashSetInsert(newSet, entry) != TOOLS_SUCCESS)
            goto failed;
    }

    return newSet;

failed:
    toolsHashSetDelete(newSet, NULL, NULL);
    return NULL;
}

TOOLSresult toolsHashSetInPlaceUnion(tHashSet *s1, const tHashSet *s2)
{
    tHashSetItr *itr;

    if (!s1 || !s2)
        return TOOLS_ERROR_INVALID_VALUE;

    for (itr = toolsHashSetGetIterator(s2);
         itr;
         itr = toolsHashSetGetNext(s2, itr)) {
        TOOLSresult res;
        void *entry = toolsHashSetGetEntry(itr);
        res = toolsHashSetInsert(s1, entry);
        if (res != TOOLS_SUCCESS)
            return res;
    }

    return TOOLS_SUCCESS;
}

tList *toolsHashSetToList(const tHashSet *s)
{
    return toolsHashMapToList(s);
}

typedef struct hashMapFunctorData_st hashMapFunctorData;
struct hashMapFunctorData_st {
    tHashSetFunctor pfn;
    void *data;
};

static TOOLSresult
hashMapFunctor(tHashMapKey_t key, void *entry, void *data)
{
    hashMapFunctorData *d = (hashMapFunctorData *)data;

    if (d->pfn) {
        return d->pfn(entry, d->data);
    }

    return TOOLS_SUCCESS;
}

TOOLSresult toolsHashSetApplyFunctor(const tHashSet *s, tHashSetFunctor fn, void *data)
{
    hashMapFunctorData d;

    d.pfn = fn;
    d.data = data;

    return toolsHashMapApplyFunctor(s, hashMapFunctor, &d);
}

TOOLSresult toolsHashSetRemove(tHashSet *s, const void *entry, tSingleFun del)
{
    return toolsHashMapRemove(s, tHashMapPtrToKey(entry), del);
}

uint32_t toolsHashSetIsSubset(const tHashSet *subset, const tHashSet *set)
{
    size_t subsetSize, setSize;
    tHashSetItr *itr;

    subsetSize = toolsHashSetSize(subset);
    setSize = toolsHashSetSize(set);

    if (subsetSize > setSize) {
        return 0;
    }

    for (itr = toolsHashSetGetIterator(subset);
         itr;
         itr = toolsHashSetGetNext(subset, itr)) {
        if (!toolsHashSetContains(set, toolsHashSetGetEntry(itr))) {
            return 0;
        }
    }

    return 1;
}
