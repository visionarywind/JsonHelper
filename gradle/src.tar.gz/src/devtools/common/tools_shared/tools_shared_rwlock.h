/*
 * Copyright 2007-2014 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef TOOLS_SHARED_RWLOCK_H
#define TOOLS_SHARED_RWLOCK_H

#include "tools_shared.h"

typedef unsigned long long toolsRWLock;

#define TOOLS_RW_LOCK_INIT_STATIC 0x0ULL

#if defined(__cplusplus)
extern "C" {
#endif

/* Initializes the lock state.
 * Return value :  TOOLS_SUCCESS if lock is reset
 */
TOOLSresult toolsRWLockReset(volatile toolsRWLock *lock);

/* This call will acquire the lock for reading.
 * This can safely be called by multiple readers without blocking.
 * If a writer is present, this call will block until the
 * writer leaves. This is required to prevent starvation.
 * Return value :  TOOLS_SUCCESS if lock is successfully acquired
 */
TOOLSresult toolsRWLockAcquireReadBlocking(volatile toolsRWLock *lock);

/* This call will release the currently held lock for read.
 * This call doesnt block, and is always safe for a reader to call.
 * Return value :  TOOLS_SUCCESS if lock was successfully released
 */
TOOLSresult toolsRWLockReleaseRead(volatile toolsRWLock *lock);

/* This call will acquire the lock for write.
 * If any other writer has already acquired the write lock, this call
 * will block until the writer releases the lock.
 * Once the writing lock is acquired, this call will wait
 * for all readers associated with the lock to complete.
 * Return value :  TOOLS_SUCCESS if the lock was successfully acquired for writing
 */
TOOLSresult toolsRWLockAcquireWriteBlocking(volatile toolsRWLock *lock);

/* This call will release the writer lock
 * This call will not block and can be safely called by the
 * writer.
 * Return value : TOOLS_SUCCESS if the lock was successfully released
 */
TOOLSresult toolsRWLockReleaseWrite(volatile toolsRWLock *lock);

/* This is a query function that can tests if the lock
 * has any readers or writers.
 * Note : This call is inherently racy unless the app is frozen
 * isUsed : Returns nonzero if any readers or writers are present
 * Return value :  TOOLS_SUCCESS if there are no readers or writers for the lock
 */
TOOLSresult toolsRWLockIsUsed(volatile toolsRWLock *lock, uint32_t *isUsed);

#if defined(__cplusplus)
}
#endif

#endif
