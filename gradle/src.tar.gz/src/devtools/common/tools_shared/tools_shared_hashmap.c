/*
 * Copyright 2007-2011 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "tools_shared_hashmap.h"

#include <stdlib.h>
#include <string.h>

#define REHASH_THRESHOLD (.75)

typedef struct tHashMapEntry_st tHashMapEntry;

struct tHashMapEntry_st {
    tHashMapKey_t key;
    void *data;
};

struct tHashMap_st {
    tHashFun hash;
    tEqualFun equal;
    size_t size;
    size_t rehashSize;
    size_t numBuckets;

    tList **buckets;
};

uint32_t toolsStringEqualFun(const tHashMapKey_t key1, const tHashMapKey_t key2)
{
    if (!key1 || !key2)
        return 0;

    return (strcmp((char *)(uintptr_t)key1, (char *)(uintptr_t)key2) == 0);
}

int32_t toolsStringHashFun(const tHashMapKey_t key)
{
    int32_t hash = 0;
    size_t i;
    const char *str = (char *)(uintptr_t)key;

    if (!str)
        return 0;

    for (i = 0; i < strlen(str); ++i)
        hash = hash * 31 + str[i];

    return hash;
}

uint32_t toolsUint32EqualFun(const tHashMapKey_t key1, const tHashMapKey_t key2)
{
    return ((int32_t)key1 == (int32_t)key2);
}

uint32_t toolsUint64EqualFun(const tHashMapKey_t key1, const tHashMapKey_t key2)
{
    return (key1 == key2);
}

int32_t toolsUint32HashFun(const tHashMapKey_t key)
{
    return (int32_t)key;
}

uint32_t toolsPointerEqualFun(const tHashMapKey_t key1, const tHashMapKey_t key2)
{
    return ((void *)(uintptr_t)key1 == (void *)(uintptr_t)key2);
}

int32_t toolsPointerHashFun(const tHashMapKey_t key)
{
    int64_t i;
    int32_t hash;

    if (sizeof(tHashMapKey_t) <= sizeof(int32_t)) {
        hash = (int32_t)(uintptr_t)key;
    }
    else {
        i = (int64_t)(uintptr_t)key;
        i ^= (i >> 32);
        hash = (int32_t)(0xFFFFFFFF & i);
    }

    // An integer hash function generating uniform distribution
    // Works fairly well on pointer values (aligned to 4/8 bytes).
    // http://www.concentric.net/~Ttwang/tech/inthash.htm
    hash = ~hash + (hash << 15);
    hash = hash ^ (hash >> 12);
    hash = hash + (hash << 2);
    hash = hash ^ (hash >> 4);
    hash = hash * 2057;
    hash = hash ^ (hash >> 16);
    return hash;
}

tHashMap *toolsHashMapNew(tHashFun hash, tEqualFun equal, size_t numBuckets)
{
    tHashMap *m;
    size_t realNumBuckets;
    int log2 = 0;

    if (numBuckets <= 0)
        return NULL;

    if (!equal || !hash)
        return NULL;

    m = malloc(sizeof(tHashMap));
    if (!m)
        return NULL;

    m->equal = equal;
    m->hash = hash;

    while (numBuckets) {
        numBuckets >>= 1;
        ++log2;
    }
    realNumBuckets = ((size_t)1 << log2);
    if (0 == realNumBuckets)
        realNumBuckets = ((size_t)1 << (log2 - 1));

    m->size = 0;
    m->numBuckets = realNumBuckets;
    m->rehashSize = (size_t)(realNumBuckets * REHASH_THRESHOLD);

    m->buckets = calloc(realNumBuckets, sizeof(tList *));
    if (!m->buckets) {
        free(m);
        return NULL;
    }

    return m;
}

tHashMap *toolsHashMapCopyTemplate(const tHashMap *original)
{
    return toolsHashMapNew(original->hash, original->equal, original->numBuckets);
}

static TOOLSresult rehash(tHashMap *m)
{
    tList **newBuckets;
    size_t i, b, newNumBuckets;
    uint32_t hash;
    TOOLSresult res;

    if (!m) {
        return TOOLS_ERROR_INVALID_VALUE;
    }

    newNumBuckets = (m->numBuckets << 1);
    if (newNumBuckets <= m->numBuckets)
        return TOOLS_SUCCESS;

    newBuckets = calloc(newNumBuckets, sizeof(tList *));
    if (!newBuckets)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    for (i = 0; i < m->numBuckets; ++i) {
        tListItr *itr;
        tList *bucket = m->buckets[i];

        for (itr = toolsListGetIterator(bucket);
             itr;
             itr = toolsListGetNext(itr)) {
            tHashMapEntry *entry = toolsListGetElem(itr);
            hash = m->hash(entry->key);
            b = hash % newNumBuckets;

            if (!newBuckets[b]) {
                newBuckets[b] = toolsListNew();
            }

            if (!newBuckets[b]) {
                res = TOOLS_ERROR_OUT_OF_MEMORY;
                goto failed;
            }

            res = toolsListAppend(newBuckets[b], entry);
            if (res != TOOLS_SUCCESS) {
                goto failed;
            }
        }

        toolsListDelete(bucket, NULL, NULL);
    }

    free(m->buckets);

    m->numBuckets = newNumBuckets;
    m->rehashSize = (size_t)(newNumBuckets * REHASH_THRESHOLD);
    m->buckets = newBuckets;

    return TOOLS_SUCCESS;

failed:
    for (i = 0; i < newNumBuckets; ++i) {
        if (newBuckets[i])
            toolsListDelete(newBuckets[i], NULL, NULL);
    }
    free(newBuckets);
    return res;
}

TOOLSresult toolsHashMapInsert(tHashMap *m, const tHashMapKey_t key, void * data)
{
    int32_t hash;
    size_t b;
    tListItr *itr;
    tHashMapEntry *entry = NULL;
    TOOLSresult res = TOOLS_ERROR_UNKNOWN;

    if (!m)
        return TOOLS_ERROR_INVALID_VALUE;

    if (0 != m->rehashSize && m->size >= m->rehashSize) {
        res = rehash(m);
        if (res != TOOLS_SUCCESS)
            return res;
    }

    hash = m->hash(key);
    b = hash % m->numBuckets;

    if (!m->buckets[b])
        m->buckets[b] = toolsListNew();

    if (!m->buckets[b])
        return TOOLS_ERROR_OUT_OF_MEMORY;

    for (itr = toolsListGetIterator(m->buckets[b]); itr; itr = toolsListGetNext(itr)) {
        entry = toolsListGetElem(itr);
        if (m->equal(entry->key, key))
            break;
    }

    if (itr)
        entry->data = data;
    else {
        entry = malloc(sizeof(tHashMapEntry));
        if (!entry)
            return TOOLS_ERROR_OUT_OF_MEMORY;

        entry->key = key;
        entry->data = data;

        res = toolsListAppend(m->buckets[b], entry);
        if (res != TOOLS_SUCCESS) {
            free(entry);
            return res;
        }

        ++m->size;
    }

    return TOOLS_SUCCESS;
}

tHashMapItr *toolsHashMapGetIterator(const tHashMap *m)
{
    uint32_t curBucket;
    tListItr *listItr;

    if (!m)
        return NULL;

    for (curBucket = 0; curBucket < m->numBuckets; ++curBucket) {
        if (m->buckets[curBucket])
            break;
    }

    if (curBucket == m->numBuckets)
        return NULL;

    listItr = toolsListGetIterator(m->buckets[curBucket]);

    return listItr;
}

tHashMapItr *toolsHashMapGetNext(const tHashMap *m, const tHashMapItr *i)
{
    tListItr *listItr;
    tHashMapEntry *entry;
    size_t b, curBucket;

    if (!m || !i)
        return NULL;

    listItr = toolsListGetNext(i);

    if (listItr)
        return listItr;

    /* Jump to next bucket, if any */
    entry = (tHashMapEntry *)toolsListGetElem(i);

    b = m->hash(entry->key) % m->numBuckets;

    for (curBucket = b + 1; curBucket < m->numBuckets; ++curBucket) {
        if (m->buckets[curBucket])
            break;
    }

    if (curBucket == m->numBuckets)
        return NULL;

    listItr = toolsListGetIterator(m->buckets[curBucket]);

    return listItr;
}

tHashMapKey_t toolsHashMapGetKey(const tHashMapItr *i)
{
    tHashMapEntry *entry;

    if (!i)
        return 0;

    entry = (tHashMapEntry *)toolsListGetElem(i);
    if (!entry)
        return 0;

    return entry->key;
}

void *toolsHashMapGetEntry(const tHashMapItr *i)
{
    tHashMapEntry *entry;

    if (!i)
        return NULL;

    entry = (tHashMapEntry *)toolsListGetElem(i);
    if (!entry)
        return NULL;

    return entry->data;
}

void *toolsHashMapGetAnyEntry(const tHashMap *m)
{
    const tHashMapItr *i = toolsHashMapGetIterator(m);
    tHashMapEntry *entry;

    if (!i)
        return NULL;

    entry = (tHashMapEntry *)toolsListGetElem(i);
    if (!entry)
        return NULL;

    return entry->data;
}

static void *hashMapFind(const tHashMap *m, const tHashMapKey_t key, uint8_t *found)
{
    int32_t hash;
    size_t b;
    tListItr *itr;
    tHashMapEntry *entry = NULL;

    if (found) {
        *found = 0;
    }

    if (!m) {
        return NULL;
    }

    hash = m->hash(key);
    b = hash % m->numBuckets;

    if (!m->buckets[b]) {
        return NULL;
    }

    for (itr = toolsListGetIterator(m->buckets[b]); itr; itr = toolsListGetNext(itr)) {
        entry = toolsListGetElem(itr);
        if (m->equal(entry->key, key)) {
            if (found) {
                *found = 1;
            }
            return entry->data;
        }
    }

    return NULL;
}

void *toolsHashMapFind(const tHashMap *m, const tHashMapKey_t key)
{
    return hashMapFind(m, key, NULL);
}

uint32_t toolsHashMapContains(const tHashMap *m, const tHashMapKey_t key)
{
    uint8_t found = 0;
    hashMapFind(m, key, &found);
    return found;
}

TOOLSresult toolsHashMapRemove(tHashMap *m, const tHashMapKey_t key, tSingleFun del)
{
    int32_t hash;
    size_t b;
    tListItr *itr;
    tHashMapEntry *entry = NULL;
    TOOLSresult res = TOOLS_SUCCESS;

    if (!m)
        return TOOLS_ERROR_INVALID_VALUE;

    hash = m->hash(key);
    b = hash % m->numBuckets;

    if (!m->buckets[b])
        return TOOLS_SUCCESS;

    for (itr = toolsListGetIterator(m->buckets[b]); itr; itr = toolsListGetNext(itr)) {
        entry = toolsListGetElem(itr);
        if (m->equal(entry->key, key)) {
            if (del)
                del(entry->data, NULL);
            res = toolsListRemove(m->buckets[b], entry, NULL, 0);
            if (res != TOOLS_SUCCESS)
                break;

            free(entry);
            if (toolsListSize(m->buckets[b]) == 0) {
                toolsListDelete(m->buckets[b], NULL, NULL);
                m->buckets[b] = NULL;
            }
            --m->size;
            break;
        }
    }

    return res;
}

size_t toolsHashMapSize(const tHashMap *m)
{
    if (!m)
        return 0;

    return m->size;
}

tList *toolsHashMapToList(const tHashMap *m)
{
    size_t i;
    TOOLSresult res = TOOLS_ERROR_UNKNOWN;
    tList *l;

    if (!m)
        return NULL;

    l = toolsListNew();
    if (!l)
        return NULL;

    for (i = 0; i < m->numBuckets; ++i) {
        tListItr *itr;
        tList *bucket = m->buckets[i];

        for (itr = toolsListGetIterator(bucket); itr; itr = toolsListGetNext(itr)) {
            tHashMapEntry *entry = toolsListGetElem(itr);
            res = toolsListAppend(l, entry->data);
            if (res != TOOLS_SUCCESS) {
                toolsListDelete(l, NULL, NULL);
                return NULL;
            }
        }
    }
    return l;
}

typedef struct hashDeleteFunctorData_st hashDeleteFunctorData;

struct hashDeleteFunctorData_st {
    void *func;
    void *data;
};

static void delHashEntryFun(void *entry, void *del)
{
    if (entry) {
        tHashMapEntry *e = (tHashMapEntry *)entry;
        hashDeleteFunctorData *helper = (hashDeleteFunctorData*)del;
        /* Free the data */
        if (helper && helper->func && e->data) {
            ((tSingleFun)helper->func)(e->data, helper->data);
            e->data = NULL;
        }

        /* Free the hashmap entry itself */
        free(e);
    }
}

TOOLSresult
toolsHashMapDelete(tHashMap *m, tSingleFun del, void *data)
{
    size_t i;
    TOOLSresult res = TOOLS_ERROR_UNKNOWN;
    hashDeleteFunctorData helper = {0};

    if (!m)
        return TOOLS_ERROR_INVALID_VALUE;

    helper.func = del;
    helper.data = data;

    for (i = 0; i < m->numBuckets; ++i) {
        if (m->buckets[i]) {
            res = toolsListDelete(m->buckets[i], &delHashEntryFun, &helper);
            if (res != TOOLS_SUCCESS)
                return res;
        }
    }

    free(m->buckets);
    free(m);

    return TOOLS_SUCCESS;
}

TOOLSresult
toolsHashMapApplyFunctor(const tHashMap *m, tHashFunctor fn, void *data)
{
    TOOLSresult res = TOOLS_ERROR_UNKNOWN;
    tHashMapItr *itr = NULL;
    tHashMapKey_t key;
    void *entry  = NULL;

    if (!m || !fn)
        return TOOLS_ERROR_INVALID_VALUE;

    itr = toolsHashMapGetIterator(m);
    for (; itr;
         itr = toolsHashMapGetNext(m,itr)) {
        entry = toolsHashMapGetEntry(itr);
        key = toolsHashMapGetKey(itr);
        res = fn(key, entry, data);
        if (res != TOOLS_SUCCESS)
            return res;
    }

    return TOOLS_SUCCESS;

}
