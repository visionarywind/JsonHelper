/*
 * Copyright 2007-2011 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef _TOOLS_SHARED_LIST_H
#define _TOOLS_SHARED_LIST_H

#include "tools_shared.h"

#include <cuda_inttypes.h>

/* Structs */

/* Iterator */
typedef struct tListElem_st tListItr;

typedef struct tList_st tList;

/* Function types */

/* Less than or equal function, for sorting */
/* Takes 2 elements, should return 1 if element1 is less than or equal to element2, 0 otherwise */
typedef uint32_t (*tLtEqFun)(const void *, const void *, void *data);

/* Takes an element and an extra parameter */
typedef void (*tSingleFun)(void *, void *);

#if defined(__cplusplus)
extern "C" {
#endif

/* Functions */

/* Creates and returns a new empty list.
 * The list needs to be freed by caller.
 * Returns NULL if failed.
 */
tList *toolsListNew(void);

/* Appends a new element to the end of a given list */
TOOLSresult toolsListAppend(tList *l, void *e);

/* Appends a new element to the front of a given list */
TOOLSresult toolsListAppendFront(tList *l, void *e);

/* Gets an iterator of a list.
 * The iterator starts from the beginning of the list.
 * Returns NULL on fail.
 */
tListItr *toolsListGetIterator(const tList *l);

/* Advances the iterator by one element.
 * Returns NULL on fail or when reaches the end of list
 */
tListItr *toolsListGetNext(const tListItr *i);

/* Gets the actual list element from an iterator */
void *toolsListGetElem(const tListItr *i);

/* Gets the iterator of the tail of a list */
tListItr *toolsListGetTail(const tList *l);

/* Removes an element from the list */
TOOLSresult toolsListRemove(tList *l, void *e, tSingleFun del, uint8_t removeAllInstances);

size_t toolsListSize(const tList *l);

/* Deletes a list. Accepts a custom function for individual elements.
 * The 3rd parameter is passed in to the delete function.
 */
TOOLSresult toolsListDelete(tList *l, tSingleFun del, void *funParam);

TOOLSresult toolsListSort(tList *l, tLtEqFun lteq, void *data);

#if defined(__cplusplus)
}
#endif

#endif
