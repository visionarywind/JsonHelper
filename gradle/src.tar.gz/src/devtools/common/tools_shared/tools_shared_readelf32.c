
#define toolsElfXXGetLineInfo            toolsElf32GetLineInfo
#define toolsElfXXGetDebugFrame          toolsElf32GetDebugFrame
#define toolsElfXXGetAbiVersion          toolsElf32GetAbiVersion
#define toolsElfXXGetContainerFunc       toolsElf32GetContainerFunc
#define toolsElfXXGetRelatedFuncs        toolsElf32GetRelatedFuncs
#define toolsElfXXListKernelNames        toolsElf32ListKernelNames
#define toolsElfXXGetCallgraphFuncs      toolsElf32GetCallgraphFuncs
#define toolsElfXXGetTextSectionContents toolsElf32GetTextSectionContents
#define toolsElfXXGetCudaSMVersion       toolsElf32GetCudaSMVersion
#define toolsElfXXGetAtomSysInstrOffsets toolsElf32GetAtomSysInstrOffsets
#define toolsElfXXGetCoopGroupInstrOffsets toolsElf32GetCoopGroupInstrOffsets
#define toolsElfXXGetPgoInfo             toolsElf32GetPgoInfo
#define toolsElfXXGetAtomF16InstrOffsets toolsElf32GetAtomF16InstrOffsets
#define toolsElfXXGetAtomF16RegMap       toolsElf32GetAtomF16RegMap
#define toolsElfXXGetWarpWideInstrOffsets toolsElf32GetWarpWideInstrOffsets
#define toolsElfXXStripHiddenSymbols     toolsElf32StripHiddenSymbols

#define elfXXFileHeader                  elf32FileHeader
#define elfXXSectionHeader               elf32SectionHeader
#define elfXXProgramHeader               elf32ProgramHeader
#define elfXXSymbol                      elf32Symbol
#define elfXXOff                         elf32Off
#define elfXXAddr                        elf32Addr
#define elfXXRel                         elf32Rel
#define elfXXRela                        elf32Rela
#define elfXX_file_header                elf32_file_header
#define elfXX_program_header             elf32_program_header
#define elfXX_section_header             elf32_section_header
#define elfXX_named_section_header       elf32_named_section_header
#define elfXX_typed_section_header       elf32_typed_section_header
#define elfXX_offset_section_header      elf32_offset_section_header
#define elfXX_section_name               elf32_section_name
#define elfXX_symbol_name                elf32_symbol_name
#define elfXX_segment_is_loadable        elf32_segment_is_loadable
#define elfXX_segment_is_global          elf32_segment_is_global
#define elfXX_segment_matches_entry      elf32_segment_matches_entry
#define elfXX_segment_is_text            elf32_segment_is_text
#define elfXX_segment_is_data            elf32_segment_is_data
#define elfXX_get_entry_symbol_index     elf32_get_entry_symbol_index
#define elfXX_first_section_in_segment   elf32_first_section_in_segment
#define elfXX_next_section_in_segment    elf32_next_section_in_segment
#define elfXX_section_is_in_segment      elf32_section_is_in_segment
#define ELFXX_R_SYM                      ELF32_R_SYM
#define ELFXX_R_TYPE                     ELF32_R_TYPE

#include "tools_shared_readelf.h"
