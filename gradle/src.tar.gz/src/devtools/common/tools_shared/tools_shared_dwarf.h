/*
 * Copyright 2016-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: tools_shared_dwarf.h
 *
 *   Description:
 *      Header for DWARF manipulation.
 *
 ******************************************************************************/

#ifndef _TOOLS_SHARED_DWARF_H
#define _TOOLS_SHARED_DWARF_H

#include "tools_shared_list.h"
#include "tools_shared_hashmap.h"
#include "tools_shared_rangemap.h"

/* Version number is not the same as the DWARF version.
 * We'll let the nvcc team decide this for us.
 */
#define DWARF_FRAME_VERSION1 1
#define DWARF_FRAME_VERSION3 3

/* Call frame instructions: DWARF 2.0 Spec page 79.
 * Treat these values as a 1-byte mask.
 */

#define DW_CFA_opcode            0x00 /* High 2 bits: 00 */
#define DW_CFA_advance_loc       0x40 /* High 2 bits: 01 */
#define DW_CFA_offset            0x80 /* High 2 bits: 10 */
#define DW_CFA_restore           0xc0 /* High 2 bits: 11 */
#define DW_CFA_OPCODE_MASK       0xc0

#define DW_CFA_set_loc           0x01
#define DW_CFA_advance_loc1      0x02
#define DW_CFA_advance_loc2      0x03
#define DW_CFA_advance_loc4      0x04
#define DW_CFA_offset_extended   0x05
#define DW_CFA_restore_extended  0x06
#define DW_CFA_undefined         0x07
#define DW_CFA_same_value        0x08
#define DW_CFA_register          0x09
#define DW_CFA_remember_state    0x0a
#define DW_CFA_restore_state     0x0b
#define DW_CFA_def_cfa           0x0c
#define DW_CFA_def_cfa_register  0x0d
#define DW_CFA_def_cfa_offset    0x0e
/* New in DWARF 3.0 */
#define DW_CFA_def_cfa_expression 0x0f
#define DW_CFA_expression        0x10
#define DW_CFA_offset_extended_sf 0x11
#define DW_CFA_def_cfa_sf        0x12
#define DW_CFA_def_cfa_offset_sf 0x13
#define DW_CFA_val_offset        0x14
#define DW_CFA_val_offset_sf     0x15
#define DW_CFA_val_expression    0x16
/* New in DWARF 3.0 -- end */
#define DW_CFA_nop               0x00
#define DW_CFA_lo_user           0x1c
#define DW_CFA_hi_user           0x3f

/* DWARF Expressions */
#define DW_OP_addr               0x03
#define DW_OP_deref              0x06
#define DW_OP_const1u            0x08
#define DW_OP_const1s            0x09
#define DW_OP_const2u            0x0a
#define DW_OP_const2s            0x0b
#define DW_OP_const4u            0x0c
#define DW_OP_const4s            0x0d
#define DW_OP_const8u            0x0e
#define DW_OP_const8s            0x0f
#define DW_OP_constu             0x10
#define DW_OP_consts             0x11
#define DW_OP_dup                0x12
#define DW_OP_drop               0x13
#define DW_OP_over               0x14
#define DW_OP_pick               0x15
#define DW_OP_swap               0x16
#define DW_OP_rot                0x17
#define DW_OP_xderef             0x18
#define DW_OP_abs                0x19
#define DW_OP_and                0x1a
#define DW_OP_div                0x1b
#define DW_OP_minus              0x1c
#define DW_OP_mod                0x1d
#define DW_OP_mul                0x1e
#define DW_OP_neg                0x1f
#define DW_OP_not                0x20
#define DW_OP_or                 0x21
#define DW_OP_plus               0x22
#define DW_OP_plus_uconst        0x23
#define DW_OP_shl                0x24
#define DW_OP_shr                0x25
#define DW_OP_shra               0x26
#define DW_OP_xor                0x27
#define DW_OP_skip               0x2f
#define DW_OP_bra                0x28
#define DW_OP_eq                 0x29
#define DW_OP_ge                 0x2a
#define DW_OP_gt                 0x2b
#define DW_OP_le                 0x2c
#define DW_OP_lt                 0x2d
#define DW_OP_ne                 0x2e
/* valid for n in [0..31] */
#define DW_OP_lit(n)             (0x30 + (n))
#define DW_OP_reg(n)             (0x50 + (n))
#define DW_OP_breg(n)            (0x70 + (n))

#define DW_OP_regx               0x90
#define DW_OP_fbreg              0x91
#define DW_OP_bregx              0x92
#define DW_OP_piece              0x93
#define DW_OP_deref_size         0x94
#define DW_OP_xderef_size        0x95
#define DW_OP_nop                0x96
#define DW_OP_push_object_address 0x97
#define DW_OP_call2              0x98
#define DW_OP_call4              0x99
#define DW_OP_call_ref           0x9a
#define DW_OP_form_tls_address   0x9b
#define DW_OP_call_frame_cfa     0x9c
#define DW_OP_bit_piece          0x9d
#define DW_OP_lo_user            0xe0
#define DW_OP_hi_user            0xff

/* DW_FORM_xxx
 * Attribute form encodings */
#define DW_FORM_addr             0x01
#define DW_FORM_block2           0x03
#define DW_FORM_block4           0x04
#define DW_FORM_data2            0x05
#define DW_FORM_data4            0x06
#define DW_FORM_data8            0x07
#define DW_FORM_string           0x08
#define DW_FORM_block            0x09
#define DW_FORM_block1           0x0a
#define DW_FORM_data1            0x0b
#define DW_FORM_flag             0x0c
#define DW_FORM_sdata            0x0d
#define DW_FORM_strp             0x0e
#define DW_FORM_udata            0x0f
#define DW_FORM_ref_addr         0x10
#define DW_FORM_ref1             0x11
#define DW_FORM_ref2             0x12
#define DW_FORM_ref4             0x13
#define DW_FORM_ref8             0x14
#define DW_FORM_ref_udata        0x15
#define DW_FORM_indirect         0x16

/* The ABI specifies that the register numbers contained in some of the
 * .debug_frame data are encoded with the register calls information too.
 */
#define REG_CLASS_REG(_r)     ((_r)  & 0x00FFFFFF)
#define REG_CLASS(_r)         (((_r) & 0xFF000000) >> 24)
#define REG_CLASS_TYPE_MASK   0x00FFFFFF
#define REG_CLASS_SET(_r, _c) ((_r) |= ((_c) << 24))

/* Encoded register is just a physical register number */
#define REG_CLASS_REG_FULL 0x5

/* Encoded register contains local memory offset */
#define REG_CLASS_MEM_LOCAL 0x6
#define REG_CLASS_MEM_LOCAL_OFF(_r) ((_r) & 0xFFFFFF) /* Low 24: local offset */

/* Encoded register is local memory and offset (stack spill)
 * Lower 24 bits is encoded as: High 8 is physical sp
 * Lower 24 bits is encoded as: Lower 16 is offset from sp 
 */
#define REG_CLASS_LMEM_REG_OFFSET          0x7
#define REG_CLASS_LMEM_REG_SP(_r)          ((REG_CLASS_TYPE_MASK & (_r)) >> 16)
#define REG_CLASS_LMEM_REG_OFFSET_OFF(_r)  ((REG_CLASS_TYPE_MASK & (_r)) & 0xFFFF)
#define REG_CLASS_LMEM_REG_SET_SP(_r, _s)  ((_r) |= ((_s) << 16))
#define REG_CLASS_LMEM_REG_SET_OFF(_r ,_o) ((_r) |= ((_o) & 0xFFFF))

/* Encoded uniform register is just a physical register number */
#define REG_CLASS_UREG_FULL 0xb

#if defined(__cplusplus)
extern "C" {
#endif

typedef struct DwarfCFA_st        DwarfCFA;
typedef struct DwarfCIE_st        DwarfCIE;
typedef struct DwarfFDE_st        DwarfFDE;
typedef struct DwarfFrameReg_st   DwarfFrameReg;
typedef struct DwarfFrameState_st DwarfFrameState;
typedef struct DwarfDebugFrame_st DwarfDebugFrame;

/* DWARF 2.0 Canonical Frame Address (DWARF 2.0 Spec page 59):
 * Register and offset which points to the stack pointer (call frame address).
 */
struct DwarfCFA_st {
    const DwarfFrameReg *reg;    /* Register in the debug_frame table */
    int32_t              offset; /* Byte offset from address in 'reg' */
};

/* The debug_frame contains a table of registers and their states at all program
 * points within a program.  DWARF 2.0 Spec page 61.
 */
typedef enum DwarfFrameRegRule_en {
    DWARF_FRAME_REG_UNDEFINED = 0,
    DWARF_FRAME_REG_SAME,
    DWARF_FRAME_REG_VALUE,
    DWARF_FRAME_REG_OFFSET,
    DWARF_FRAME_REG_REG,
    DWARF_FRAME_REG_ARCH /* Architecture defined */
} DwarfFrameRegRule;

/* Each instance of a register represents a column in the debug_frame table
 * regnum - Note that the CUDA encodes the CUDBGRegClass and register number in the
 *          representation of the register number.
 */
struct DwarfFrameReg_st {
    uint32_t regnum;

    /* Used as a discriminator for the 'data' union below */
    DwarfFrameRegRule rule;

    /* Used as a discriminator for the 'initial_data' union below */
    DwarfFrameRegRule initial_rule;

    /* Offset or register (based on rule) */
    /* initial_data is a copy of data after CIE initialization that will be 
     * used to reinitialize 'data' when a new FDE is to be processed.
     */
    union {
        int32_t  offset;
        uint32_t reg;
    } data, initial_data;
};

/* Contains a container of registers and their state.  CIE initializes this and
 * an FDE will update the table of registers, 'regs', per the CFA instructions in
 * the FDE instance.
 * 
 * An array would be nicer, but DWARF does not tells us the number of registers
 * before hand, that will be represented in the CIE data.  So instead of
 * counting the number of registers, allocating an array, and then re-parsing
 * the CIE initial_instructions (or building a temp list), we just use a hash.
 *
 * Additionally, CUDA ABI encodes register class in the regnum, so if we use an
 * array, we'd need to mask the regclass away, or potentially blow-the-lid off
 * the memory.
 */
struct DwarfFrameState_st {
    uint64_t location; /* 'LOC' or address in the debug_frame table */
    uint32_t return_address_column;
    DwarfCFA cfa;

    /* Key: register number (register class is masked away) 
     * Val: DwarfFrameReg pointer
     */
    tHashMap  *regs;
};

/* DWARF 2.0 Common Information Entry (DWARF 2.0 Spec page 61):
 * Contains multiple frame description entries (FDEs).
 */
struct DwarfCIE_st {
    const uint8_t *base;   /* Start of the CIE in the elf data stream */
    int64_t        offset; /* Offset from the debug_frame             */
    const uint8_t *end;    /* End of the CIE in the elf data stream   */
    uint32_t       length; /* Byte size excluding length field        */
    uint32_t       code_alignment_factor;
    int32_t        data_alignment_factor;
    uint32_t       return_address_column; /* Column in debug_frame table      */
    const uint8_t *initial_instructions;  /* List of DW_CFA_xxxx instructions */
    uint64_t       initial_location;      /* initial pc this cie's fdes cover */
    uint64_t       end_location;          /* end pc this cie's fdes cover     */
    tRangeMap     *pcTofde;               /* pc->fde map                      */
};

/* DWARF 2.0 Frame Description Entry (DWARF 2.0 Spec page 62) */
struct DwarfFDE_st {
    const uint8_t *base;   /* Start of the FDE in the elf data stream */
    const uint8_t *end;    /* End of the FDE in the elf data stream   */
    uint32_t       length; /* Byte size excluding length field        */
    uint64_t       initial_location;
    uint64_t       address_range;
    const uint8_t *instructions; /* List of DW_CFA_xxxx instructions */
};

/* Internal representation of the debug_frame */
struct DwarfDebugFrame_st {
    const uint8_t *end;         /* End of .debug_frame */
    tRangeMap     *pcTocie;     /* pc->cie map */
    uint32_t       initialized;
};

/* Populate 'frame' with the debug_frame information provided in 'pimage'*/
TOOLSresult 
toolsGetDebugFrame(const void      *pimage, 
                   DwarfDebugFrame *frame);

/* Given a program counter, set the CFA for the caller's frame:
 * 'pc' must be a virtual address (host not device).
 */
TOOLSresult
toolsGetFrameState(const DwarfDebugFrame *dbg_frame,
                   uint64_t                pc,
                   DwarfFrameState         *frame); /* Returned */

/* Given a program counter, update the existing state in the CFA to 
 * the information in the caller's frame.  This is necessary for 
 * unwinding subsequent frames in a stack unwind.
 * 'pc' must be a virtual address (host not device).
 */
TOOLSresult
toolsUpdateDwarfFrameState(DwarfFrameState *target, DwarfFrameState *current);

/* Get the register information.  'regno' is the register number without any
 * extended data (e.g., register class) masked in.
 *
 * Returns 'reg' which represents a spilled register and offset from
 * that spilled register.  'reg' is encoded with the REG_CLASS information,
 * which is particularly useful when locating stack spills.
 */
TOOLSresult
toolsGetRegister(const DwarfFrameState *current,
                 uint32_t               regno,
                 uint32_t              *reg,
                 int32_t               *offset,
                 DwarfFrameRegRule     *rule); /* Returned */

TOOLSresult
toolsSetFrameReg(DwarfFrameState *state,
                 uint32_t regnum,
                 uint32_t reg,
                 int32_t offset,
                 DwarfFrameRegRule rule);

TOOLSresult
toolsSetFrameCFA(DwarfFrameState *state,
                 uint32_t regnum,
                 int32_t offset);

TOOLSresult
toolsDestroyElfFrameRegMap(DwarfFrameState *state);


#if defined(__cplusplus)
}
#endif
#endif /* _TOOLS_SHARED_DWARF_H */
