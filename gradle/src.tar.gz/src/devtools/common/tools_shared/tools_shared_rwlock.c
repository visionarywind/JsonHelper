/*
 * Copyright 2013-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include "tools_shared_rwlock.h"
#include <cuos.h>

typedef struct toolsRWLockInternal_st      toolsRWLockInternal;

/* Pack 4 is sufficient since the elements are all 4 bytes long */
#pragma pack(push,4)
struct toolsRWLockInternal_st {
    volatile unsigned int readerCount;
    volatile unsigned int hasWriter;
};
#pragma pack(pop)

typedef enum toolsRWLockMode_enum {
    TOOLS_RW_LOCK_MODE_NONE = 0,
    TOOLS_RW_LOCK_MODE_SPIN = 1,
    TOOLS_RW_LOCK_MODE_TEST = 2,
} toolsRWLockMode;

#define TOOLS_RW_LOCK_UPPER_WORD_MASK (0xffffffff00000000ULL)
#define TOOLS_RW_LOCK_LOWER_WORD_MASK (0x00000000ffffffffULL)
#define TOOLS_RW_LOCK_ONE_WRITER_NO_READER (0x0000000100000000ULL)

TOOLSresult toolsRWLockReset(volatile toolsRWLock *lockHandle)
{
    if (!lockHandle)
        return TOOLS_ERROR_INVALID_VALUE;

    *lockHandle = 0;

    return TOOLS_SUCCESS;
}

static TOOLSresult
toolsRWLockAcquireRead(volatile toolsRWLock *lockHandle, toolsRWLockMode mode)
{
    unsigned long long oldLockInt = 0, newLockInt = 0, swapInt = 0;

    /* The read acquire must test both the writer and
       the increment the reader count simultaneously.

       The loop condition (swapInt != oldLockInt)
       will be true if :
        1. A writer is present
        2. Race on the thread doing the increment

        There is a corner case that is unsupported. If the
        readercount == 2^32 - 1, the increment will bring it 0,
        which is the same as when the lock is free.
    */
    if (!lockHandle || mode == TOOLS_RW_LOCK_MODE_NONE)
        return TOOLS_ERROR_INVALID_VALUE;

    do {
        oldLockInt = *(volatile unsigned long long*)lockHandle;
        swapInt = 0;
        /* Preserve the writer state (upper word), while incrementing the
           reader count (lower word) */

        newLockInt = ((oldLockInt & TOOLS_RW_LOCK_UPPER_WORD_MASK) |
                      ((oldLockInt + 1) & TOOLS_RW_LOCK_LOWER_WORD_MASK));

        /* Check that there is no writers (i.e. upper word == 0) before doing
           a compare and swap */
        if (!(oldLockInt >> 32)) {
            swapInt = cuosInterlockedCompareExchange64((volatile unsigned long long*)lockHandle,
                                                        newLockInt,
                                                        oldLockInt);
        }
        else if (mode == TOOLS_RW_LOCK_MODE_TEST) {
            return TOOLS_ERROR_RWLOCK_HAS_WRITER;
        }
    } while (oldLockInt != swapInt);

    return TOOLS_SUCCESS;
}

TOOLSresult
toolsRWLockAcquireReadBlocking(volatile toolsRWLock *lockHandle)
{
    return toolsRWLockAcquireRead(lockHandle, TOOLS_RW_LOCK_MODE_SPIN);
}

TOOLSresult
toolsRWLockReleaseRead(volatile toolsRWLock *lockHandle)
{
    volatile toolsRWLockInternal *lock = (volatile toolsRWLockInternal*)lockHandle;
    unsigned int newVal = 0;

    if (!lock)
        return TOOLS_ERROR_INVALID_VALUE;

    newVal = cuosInterlockedDecrement(&lock->readerCount);
    if (newVal == ~0U) {
        /* Detect underflow, i.e. too many decrements */
        return TOOLS_ERROR_RWLOCK_INVALID_READER;
    }

    return TOOLS_SUCCESS;
}

static TOOLSresult
toolsRWLockAcquireWrite(volatile toolsRWLock *lockHandle, toolsRWLockMode mode)
{
    volatile toolsRWLockInternal *lock = (volatile toolsRWLockInternal*)lockHandle;
    unsigned int oldHasWriter = 0;

    if (!lock || mode == TOOLS_RW_LOCK_MODE_NONE)
        return TOOLS_ERROR_INVALID_VALUE;

    /* The write acquire is in the same order as read acquire. The order here is :

       1. Acquire the writer side lock (handling cases where there may be multiple contending
           writers).
       2. Wait for the reader side to go to 0.

       The upshot here is that new readers will stall at reader acquire.
       This is also race free, since the reader tests for both bits of state atomically

    */
    do {
        oldHasWriter = cuosInterlockedCompareExchange(&lock->hasWriter, 1, 0);
        if (oldHasWriter &&
            mode == TOOLS_RW_LOCK_MODE_TEST) {
            return TOOLS_ERROR_RWLOCK_HAS_WRITER;
        }
    } while (oldHasWriter);

    do {
        if (lock->readerCount &&
            mode == TOOLS_RW_LOCK_MODE_TEST) {
            lock->hasWriter = 0;
            return TOOLS_ERROR_RWLOCK_HAS_READER;
        }
    } while (lock->readerCount);

    return TOOLS_SUCCESS;
}

TOOLSresult
toolsRWLockAcquireWriteBlocking(volatile toolsRWLock *lockHandle)
{
    return toolsRWLockAcquireWrite(lockHandle, TOOLS_RW_LOCK_MODE_SPIN);
}

TOOLSresult toolsRWLockReleaseWrite(volatile toolsRWLock *lockHandle)
{
    unsigned long long oldHasWriter = 0;

    if (!lockHandle)
        return TOOLS_ERROR_INVALID_VALUE;

    /* The writer is the lowest bit in the high word */
    oldHasWriter = cuosInterlockedCompareExchange64(lockHandle, TOOLS_RW_LOCK_INIT_STATIC, TOOLS_RW_LOCK_ONE_WRITER_NO_READER);
    if (oldHasWriter != TOOLS_RW_LOCK_ONE_WRITER_NO_READER)
        return TOOLS_ERROR_RWLOCK_INVALID_WRITER;

    return TOOLS_SUCCESS;
}

TOOLSresult
toolsRWLockIsUsed(volatile toolsRWLock *lockHandle, uint32_t *isUsed)
{
    volatile toolsRWLockInternal *lock = (volatile toolsRWLockInternal*)lockHandle;

    if (!lock || !isUsed)
        return TOOLS_ERROR_INVALID_VALUE;

    *isUsed = 0;

    if (lock->hasWriter || lock->readerCount)
        *isUsed = 1;

    return TOOLS_SUCCESS;
}
