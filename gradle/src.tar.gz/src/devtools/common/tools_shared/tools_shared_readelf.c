/*
 * Copyright 2007-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: tools_shared_readelf.c
 *
 *   Description:
 *       Common code for ELF manipulation
 *
 ******************************************************************************/

#include "tools_shared.h"
#include "tools_shared_readelf_common.h"
#include "tools_shared_dwarf.h"


// Forward declarations
static void destroyElfRelocWrap(void *elt, void *data) ;
static void destroyElfRelocFuncWrap(void *elt, void *data);
static void destroyElfRegWrap(void *elt, void *data);

TOOLSresult
createElfReloc(elfReloc **preloc, elfRelocFunc *relfunc, elfRelocMod *relmod,
               uint32_t targetshndx, uint64_t *targetInst, uint32_t numTargetInst,
               char *targetname, uint32_t offset, uint32_t isDirect)
{
    TOOLSresult status = TOOLS_SUCCESS;
    elfReloc *reloc = NULL;
    uint32_t i = 0;

    if (!relmod)
        return TOOLS_ERROR_INVALID_VALUE;

    if (!relfunc && isDirect)
        return TOOLS_ERROR_INVALID_VALUE;

    if (numTargetInst > ELF_MAX_RELOC_INST_WORDS)
        return TOOLS_ERROR_INVALID_VALUE;

    /* Search to see if a reloc already exists */
    if (isDirect) {
        if (!relfunc->directRelocMap)
            return TOOLS_ERROR_INVALID_VALUE;

        reloc = (elfReloc*)(toolsHashMapFind(relfunc->directRelocMap,
                                             tHashMapNumToKey(targetshndx)));
    }
    else {
        if (!relmod->indirectRelocMap)
            return TOOLS_ERROR_INVALID_VALUE;
        reloc = (elfReloc*)(toolsHashMapFind(relmod->indirectRelocMap,
                                             tHashMapNumToKey(targetshndx)));
    }

    /* At this point, previous lookup may have succeeded */
    if (reloc) {
        *preloc = reloc;
        return TOOLS_SUCCESS;
    }

    /* If not, create a new reloc */
    reloc = calloc(1, sizeof(*reloc));
    if (!reloc)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    reloc->relfunc = relfunc;
    reloc->numTargetInst -= numTargetInst;
    if (targetInst) {
        for (i = 0; i < numTargetInst; ++i)
            reloc->targetInst[i] = targetInst[i];
    }
    reloc->offset = offset;
    reloc->targetshndx = targetshndx;
    reloc->targetname = targetname;

    if (relfunc) {
        status = toolsHashMapInsert(relfunc->offsetMap, tHashMapNumToKey(offset), reloc);
        if (status != TOOLS_SUCCESS)
            goto error;
    }

    if (isDirect) {
        if (!relfunc->directRelocMap) {
            status = TOOLS_ERROR_INVALID_VALUE;
            goto error;
        }

        status = toolsHashMapInsert(relfunc->directRelocMap,
                                    tHashMapNumToKey(targetshndx), reloc);
        if (status != TOOLS_SUCCESS)
            goto error;

        ++relfunc->directRelocCount;
    }
    else {
        if (!relmod->indirectRelocMap) {
            status = TOOLS_ERROR_INVALID_VALUE;
            goto error;
        }

        status = toolsHashMapInsert(relmod->indirectRelocMap,
                                    tHashMapNumToKey(targetshndx), reloc);
        if (status != TOOLS_SUCCESS)
            goto error;

        ++relmod->indirectRelocCount;
    }

    if (preloc)
        *preloc = reloc;
    return TOOLS_SUCCESS;

error:
    if (reloc) {
        if (relfunc)
            toolsHashMapRemove(relfunc->offsetMap, tHashMapNumToKey(offset), NULL);
        free(reloc);
    }
    return status;

}

TOOLSresult
destroyElfReloc(elfReloc *reloc)
{
    if (!reloc)
        return TOOLS_SUCCESS;

    free(reloc);
    return TOOLS_SUCCESS;
}

TOOLSresult
createElfRelocFunc(elfRelocFunc **prelfunc, elfRelocMod *relmod, uint32_t shndx, char *name)
{
    TOOLSresult status = TOOLS_SUCCESS;
    elfRelocFunc *relfunc = NULL;

    if (!relmod || !relmod->funcMap)
        return TOOLS_ERROR_INVALID_VALUE;

    relfunc = calloc(1, sizeof(*relfunc));
    if (!relfunc)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    relfunc->relmod = relmod;
    relfunc->shndx = shndx;
    relfunc->directRelocCount = 0;
    relfunc->name = name;
    relfunc->directRelocMap = toolsHashMapNew(toolsUint32HashFun, toolsUint32EqualFun, 65);
    if (!relfunc->directRelocMap) {
        status = TOOLS_ERROR_UNKNOWN;
        goto error;
    }

    relfunc->offsetMap = toolsHashMapNew(toolsUint32HashFun, toolsUint32EqualFun, 65);
    if (!relfunc->offsetMap) {
        status = TOOLS_ERROR_UNKNOWN;
        goto error;
    }

    status = toolsHashMapInsert(relmod->funcMap, tHashMapNumToKey(shndx), relfunc);
    if (status != TOOLS_SUCCESS)
        goto error;

    if (prelfunc)
        *prelfunc = relfunc;

    return TOOLS_SUCCESS;

error:
    destroyElfRelocFunc(relfunc);

    return status;
}

TOOLSresult
destroyElfRelocFunc(elfRelocFunc *relfunc)
{
    TOOLSresult status = TOOLS_SUCCESS;

    if (!relfunc)
        return TOOLS_SUCCESS;

    if (relfunc->directRelocMap) {
        status = toolsHashMapDelete(relfunc->directRelocMap, destroyElfRelocWrap, NULL);
        if (status != TOOLS_SUCCESS)
            return status;

        relfunc->directRelocMap = NULL;
    }

    if (relfunc->offsetMap) {
        status = toolsHashMapDelete(relfunc->offsetMap, NULL, NULL);
        if (status != TOOLS_SUCCESS)
            return status;

        relfunc->offsetMap = NULL;
    }

    free(relfunc);
    return TOOLS_SUCCESS;
}

TOOLSresult
createElfRelocModule(elfRelocMod **prelmod, const void *image)
{
    elfRelocMod *relmod = NULL;
    TOOLSresult status = TOOLS_SUCCESS;

    if (!image || !prelmod)
        return TOOLS_ERROR_INVALID_VALUE;

    relmod = calloc(1, sizeof(*relmod));
    if (!relmod)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    relmod->indirectRelocMap = toolsHashMapNew(toolsUint32HashFun, toolsUint32EqualFun, 65);
    if (!relmod->indirectRelocMap) {
        status = TOOLS_ERROR_UNKNOWN;
        goto error;
    }

    relmod->funcMap = toolsHashMapNew(toolsUint32HashFun, toolsUint32EqualFun, 65);
    if (!relmod->funcMap) {
        status = TOOLS_ERROR_UNKNOWN;
        goto error;
    }

    relmod->image = (char*)image;
    relmod->indirectRelocCount = 0;

    *prelmod = relmod;

    return TOOLS_SUCCESS;

error:
    destroyElfRelocModule(relmod);

    return status;
}

TOOLSresult
destroyElfRelocModule(elfRelocMod *relmod)
{
    TOOLSresult status = TOOLS_SUCCESS;

    if (!relmod)
        return TOOLS_SUCCESS;

    if (relmod->indirectRelocMap) {
        status = toolsHashMapDelete(relmod->indirectRelocMap, destroyElfRelocWrap, NULL);
        if (status != TOOLS_SUCCESS)
            return status;

        relmod->indirectRelocMap = NULL;
    }

    if (relmod->funcMap) {
        status = toolsHashMapDelete(relmod->funcMap, destroyElfRelocFuncWrap, NULL);
        if (status != TOOLS_SUCCESS)
            return status;
        relmod->funcMap = NULL;
    }

    free(relmod);

    return TOOLS_SUCCESS;
}

/*
 * Cleanly destroy the regmap associated with a frame. Do not destroy the frame itself.
 */
TOOLSresult
toolsDestroyElfFrameRegMap(DwarfFrameState *frame)
{
    if (frame->regs) {
        toolsHashMapDelete(frame->regs, destroyElfRegWrap, NULL);
        frame->regs = NULL;
    }
    return TOOLS_SUCCESS;
}

// Wrappers
static void
destroyElfRelocWrap(void *elt, void *data)
{
    destroyElfReloc((elfReloc*)elt);
}

static void
destroyElfRelocFuncWrap(void *elt, void *data)
{
    destroyElfRelocFunc((elfRelocFunc*)elt);
}

static void
destroyElfRegWrap(void *elt, void *data)
{
    free(elt);
}

// Accessors
elfRelocFunc*
getRelocFuncByShndx(elfRelocMod *relmod, uint32_t shndx)
{
    if (!relmod || !relmod->funcMap)
        return NULL;

    return (elfRelocFunc*)(toolsHashMapFind(relmod->funcMap, tHashMapNumToKey(shndx)));
}

elfReloc*
getRelocByOffset(elfRelocFunc *relfunc, uint32_t offset)
{
    if (!relfunc || !relfunc->offsetMap)
        return NULL;

    return (elfReloc*)(toolsHashMapFind(relfunc->offsetMap, tHashMapNumToKey(offset)));
}

uint32_t
decodeULEB(char **pptr)
{
    unsigned char *ptr = (unsigned char*) *pptr;
    uint32_t i = 0 ;
    uint64_t result = 0;

    /* Only read the lower 5 bytes of the LEB128 value, rather
       than reading maximum possible. This is because the rest
       of the code cannot handle arbitrary sizing currently. */
    result |= (*ptr & 0x7f);
    while ((*ptr & 0x80) != 0 && i < 4) {
        ptr += 1;
        i++;
        result |= (*ptr & 0x7f) << (i * 7);
    }

    *pptr = (char*) ptr + 1;
    return (uint32_t)result;
}

int32_t
decodeSLEB(char **pptr)
{
    unsigned char *ptr = (unsigned char*) *pptr;
    uint8_t value;
    uint32_t shift = 0;
    int64_t result = 0;
    uint32_t size = 8 * sizeof(int32_t);

    do {
        value = *ptr++;
        result |= (value & 0x7f) << shift;
        shift += 7;
    } while ((value & 0x80) != 0);

    /* sign bit of byte is second high order bit (0x40) */
    if ((shift < size) && (value & 0x40))
        result |= - (1 << shift);

    *pptr = (char*) ptr;
    return (int32_t)result;
}

#define DWARF_EXPRESSION_STACK_SIZE 256

typedef struct StackState_st {
    uint64_t    stack[DWARF_EXPRESSION_STACK_SIZE];
    uint64_t    stackPtr;
} StackState;

void
stackInit(StackState *state)
{
    memset(state->stack, 0, sizeof(state->stack));
    state->stackPtr = DWARF_EXPRESSION_STACK_SIZE;
}

TOOLSresult
stackPush(StackState *state, uint64_t value)
{
    /* Don't overflow */
    if (state->stackPtr <= 0)
        return TOOLS_ERROR_UNKNOWN;

    /* Push on the stack */
    state->stack[--state->stackPtr] = value;

    /* Return success */
    return TOOLS_SUCCESS;
}

/* Return the nth item on the stack
   stackAt(state, 0, &value) is top-of-stack
   stackAt(state, 1, &value) is the next value
 */
TOOLSresult
stackAt(StackState *state, uint32_t idx, uint64_t *value)
{
    /* Don't access past the stack bounds */
    if (state->stackPtr + idx >= DWARF_EXPRESSION_STACK_SIZE)
        return TOOLS_ERROR_UNKNOWN;

    *value = state->stack[state->stackPtr + idx];

    /* Return success */
    return TOOLS_SUCCESS;
}

TOOLSresult
stackPop(StackState *state, uint64_t *value)
{
    /* Don't underflow */
    if (state->stackPtr >= DWARF_EXPRESSION_STACK_SIZE)
        return TOOLS_ERROR_UNKNOWN;

    /* Pop value from the stack */
    *value = state->stack[state->stackPtr++];

    /* Return success */
    return TOOLS_SUCCESS;
}

TOOLSresult
evaluateBlock(DwarfFrameState *state, char *ptr, char *endp, uint64_t *value)
{
    uint8_t op;
    uint64_t value0, value1, value2;
    TOOLSresult res;
    StackState stack;

    stackInit(&stack);

    /* Start by pushing the current CFA */
    if (state->cfa.reg) {
        switch (state->cfa.reg->rule) {
        case DWARF_FRAME_REG_OFFSET:
        case DWARF_FRAME_REG_VALUE:
            res = stackPush(&stack, state->cfa.reg->data.offset);
            if (res != TOOLS_SUCCESS)
                return res;
            break;

        default:
            break;
        }
    }

    while (ptr < endp) {
        op = *ptr++;
        if (op >= DW_OP_lit(0) && op <= DW_OP_lit(31)) {
            res = stackPush(&stack, op - DW_OP_lit(0));
            if (res != TOOLS_SUCCESS)
                return res;
        }
        else {
            switch (op) {
            case DW_OP_const1u:
                res = stackPush(&stack, *(uint8_t *)ptr);
                if (res != TOOLS_SUCCESS)
                    return res;
                ptr += sizeof(uint8_t);
                break;

            case DW_OP_const1s:
                res = stackPush(&stack, *(int8_t *)ptr);
                if (res != TOOLS_SUCCESS)
                    return res;
                ptr += sizeof(int8_t);
                break;

            case DW_OP_const2u:
                res = stackPush(&stack, *(uint16_t *)ptr);
                if (res != TOOLS_SUCCESS)
                    return res;
                ptr += sizeof(uint16_t);
                break;

            case DW_OP_const2s:
                res = stackPush(&stack, *(int16_t *)ptr);
                if (res != TOOLS_SUCCESS)
                    return res;
                ptr += sizeof(int16_t);
                break;

            case DW_OP_const4u:
                res = stackPush(&stack, *(uint32_t *)ptr);
                if (res != TOOLS_SUCCESS)
                    return res;
                ptr += sizeof(uint32_t);
                break;

            case DW_OP_const4s:
                res = stackPush(&stack, *(int32_t *)ptr);
                if (res != TOOLS_SUCCESS)
                    return res;
                ptr += sizeof(int32_t);
                break;

            case DW_OP_const8u:
                res = stackPush(&stack, *(uint64_t *)ptr);
                if (res != TOOLS_SUCCESS)
                    return res;
                ptr += sizeof(uint64_t);
                break;

            case DW_OP_const8s:
                res = stackPush(&stack, *(int64_t *)ptr);
                if (res != TOOLS_SUCCESS)
                    return res;
                ptr += sizeof(int64_t);
                break;

            case DW_OP_constu:
                res = stackPush(&stack, decodeULEB(&ptr));
                if (res != TOOLS_SUCCESS)
                    return res;
                ptr += sizeof(uint64_t);
                break;

            case DW_OP_consts:
                res = stackPush(&stack, decodeSLEB(&ptr));
                if (res != TOOLS_SUCCESS)
                    return res;
                ptr += sizeof(int64_t);
                break;

            case DW_OP_dup:
                /* Duplicate top item on stack */
                res = stackAt(&stack, 0, &value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPush(&stack, value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                break;

            case DW_OP_drop:
                /* Drop top stack element */
                res = stackPop(&stack, &value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                break;

            case DW_OP_pick:
                res = stackAt(&stack, (uint8_t)*ptr++, &value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPush(&stack, value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                break;

            case DW_OP_over:
                /* Same as DW_OP_pick with index 1 */
                res = stackAt(&stack, 1, &value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPush(&stack, value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                break;

            case DW_OP_swap:
                /* Swap top two entries */
                res = stackPop(&stack, &value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPop(&stack, &value1);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPush(&stack, value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPush(&stack, value1);
                if (res != TOOLS_SUCCESS)
                    return res;
                break;

            case DW_OP_rot:
                /* Rotate top 3 stack entries */
                res = stackPop(&stack, &value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPop(&stack, &value1);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPop(&stack, &value2);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPush(&stack, value1);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPush(&stack, value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPush(&stack, value2);
                if (res != TOOLS_SUCCESS)
                    return res;
                break;

            case DW_OP_abs:
                res = stackAt(&stack, 0, &value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                if ((int64_t)value0 < 0) {
                    res = stackPop(&stack, &value0);
                    if (res != TOOLS_SUCCESS)
                        return res;
                    res = stackPush(&stack, (uint64_t) - (int64_t)value0);
                    if (res != TOOLS_SUCCESS)
                        return res;
                }
                break;

            case DW_OP_and:
                res = stackPop(&stack, &value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPop(&stack, &value1);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPush(&stack, value0 & value1);
                if (res != TOOLS_SUCCESS)
                    return res;
                break;

            case DW_OP_div:
                res = stackPop(&stack, &value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPop(&stack, &value1);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPush(&stack, (int64_t)value1 / (int64_t)value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                break;

            case DW_OP_minus:
                res = stackPop(&stack, &value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPop(&stack, &value1);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPush(&stack, value1 - value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                break;

            case DW_OP_mod:
                res = stackPop(&stack, &value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPop(&stack, &value1);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPush(&stack, value1 % value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                break;

            case DW_OP_mul:
                res = stackPop(&stack, &value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPop(&stack, &value1);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPush(&stack, value1 * value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                break;

            case DW_OP_neg:
                res = stackPop(&stack, &value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPush(&stack, (uint64_t) - (int64_t)value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                break;

            case DW_OP_not:
                res = stackPop(&stack, &value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPush(&stack, ~ value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                break;

            case DW_OP_or:
                res = stackPop(&stack, &value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPop(&stack, &value1);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPush(&stack, value1 | value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                break;

            case DW_OP_plus:
                res = stackPop(&stack, &value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPop(&stack, &value1);
                if (res != TOOLS_SUCCESS)
                    return res;
                res = stackPush(&stack, value1 + value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                break;

            case DW_OP_plus_uconst:
                res = stackPop(&stack, &value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                value1 = decodeULEB(&ptr);
                res = stackPush(&stack, value1 + value0);
                if (res != TOOLS_SUCCESS)
                    return res;
                break;

            default:
                return 0;
            }
        }
    }

    return stackPop(&stack, value);
}

TOOLSresult
decodeBlock(DwarfFrameState *state, char **pptr, uint64_t *value)
{
    int i;
    char *ptr = *pptr;
    char *blockEnd = NULL;
    uint64_t length = 0;

    switch (*ptr++) {
    case DW_FORM_block1:
        length = *ptr++;
        break;

    case DW_FORM_block2:
        for (i = 0; i < 2; ++i)
            length |= *ptr++ << i*8;
        break;

    case DW_FORM_block4:
        for (i = 0; i < 4; ++i)
            length |= *ptr++ << i*8;

    case DW_FORM_block:
        length = decodeULEB(&ptr);
        break;

    default:
        return TOOLS_ERROR_UNKNOWN;
    }
    blockEnd = ptr + length;

    *pptr = blockEnd;

    return evaluateBlock(state, ptr, blockEnd, value);
}

/* Get or create a register instance from the container in 'state'
 * NULL is only returned if an error occurs.
 */
static DwarfFrameReg *
getOrAddDwarfFrameReg(DwarfFrameState *state, uint32_t regnum)
{
    TOOLSresult    res;
    tHashMapKey_t  key;
    DwarfFrameReg *reg;

    if (!state)
        return NULL;

    if (!state->regs) {
        state->regs = toolsHashMapNew(toolsUint32HashFun, toolsUint32EqualFun, 16);
        if (!state->regs)
            return NULL;
    }
   
    key = tHashMapNumToKey(regnum);
    reg = toolsHashMapFind(state->regs, key);
    if (reg)
        return reg;

    reg = calloc(1, sizeof(DwarfFrameReg));
    if (!reg)
        return NULL;

    res = toolsHashMapInsert(state->regs, key, reg);
    if (res != TOOLS_SUCCESS) {
        free(reg);
        return NULL;
    }

    reg->regnum = regnum;
    return reg;
}

/* Get a register instance from the container in 'state'
 * NULL is returned if the register cannot be located.
 */
static const DwarfFrameReg *
getDwarfFrameReg(const DwarfFrameState *state, uint32_t regno)
{
    tHashMapKey_t key = tHashMapNumToKey(regno);
    return (DwarfFrameReg *)toolsHashMapFind(state->regs, key);
}

TOOLSresult
toolsSetFrameCFA(DwarfFrameState *state, uint32_t regno, int32_t offset)
{
    if (!state)
        return TOOLS_ERROR_INVALID_VALUE;

    state->cfa.offset = offset;
    state->cfa.reg = getOrAddDwarfFrameReg(state, regno);

    if (!state->cfa.reg)
        return TOOLS_ERROR_INVALID_VALUE;

    return TOOLS_SUCCESS;
}

TOOLSresult
toolsSetFrameReg(DwarfFrameState *state, uint32_t regnum, uint32_t reg, int32_t offset, DwarfFrameRegRule rule)
{
    DwarfFrameReg* reg_ptr = NULL;

    if (!state)
        return TOOLS_ERROR_INVALID_VALUE;
    
    reg_ptr = getOrAddDwarfFrameReg(state, regnum);
    if (!reg_ptr)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    reg_ptr->rule = rule;
    switch (rule) {
    case DWARF_FRAME_REG_SAME:
    case DWARF_FRAME_REG_UNDEFINED:
        break;
    case DWARF_FRAME_REG_VALUE:
        reg_ptr->data.offset = offset;
        break;
    case DWARF_FRAME_REG_REG:
        reg_ptr->data.reg = reg;
        break;
    case DWARF_FRAME_REG_OFFSET:
        /* TODO: encode the register to be used here too */
        reg_ptr->data.offset = offset;
        break;
    default:
        return TOOLS_ERROR_INVALID_VALUE;
    }

    return TOOLS_SUCCESS;
}

/* Search the debug_frame register state at CFA for regno, and return the
 * register or spilled register.
 * 
 * This observes the debug frame rules register(R) and offset(N) and returns an
 * encoded 'reg' to the caller.
 */
TOOLSresult
toolsGetRegister(const DwarfFrameState *current, uint32_t regno, uint32_t *reg, int32_t *offset, DwarfFrameRegRule *rule)
{
    const DwarfFrameReg *reg_ptr;

    if (!current || !reg || !offset || !rule)
        return TOOLS_ERROR_INVALID_VALUE;

    *reg = 0;
    *offset = 0;
    *rule = DWARF_FRAME_REG_UNDEFINED;

    /* Get the register representation */
    reg_ptr = getDwarfFrameReg(current, regno);
    if (!reg_ptr)
        return TOOLS_SUCCESS;

    *rule = reg_ptr->rule;
    switch(*rule) {
    case DWARF_FRAME_REG_UNDEFINED:
        break;
    case DWARF_FRAME_REG_VALUE:
        *offset = reg_ptr->data.offset;
        break;
    case DWARF_FRAME_REG_REG:
        *reg = reg_ptr->data.reg;
        break;
    case DWARF_FRAME_REG_SAME:
        *reg = reg_ptr->regnum;
        break;
    case DWARF_FRAME_REG_OFFSET:
        /* TODO: This should be already accounted for in updateDwarfFrameState */
        *reg = current->cfa.reg->regnum;
        *offset = current->cfa.offset + reg_ptr->data.offset;
        break;
    default:
        return TOOLS_SUCCESS;
    }

    return TOOLS_SUCCESS;
}

/* Process one single CFA instruction, the callee is responsible for passing
 * a legal data pointer 'datap'
 * update: Boolean used to determine if we are updating an existing 'state' from
 * a previous FDE.  When 'true' this will update spilled-registers to the value
 * spilled, which was probably calculated from a FDE lower in the call chain,
 * when unwinding the stack.
 */
static TOOLSresult
nextCFAInsn(const DwarfCIE *cie, const uint8_t **datap, DwarfFrameState *state)
{
    uint8_t opcode;
    uint8_t maskedOpcode;
    uint64_t value;
    TOOLSresult res;
    DwarfFrameReg *reg;
    const uint8_t *data = *datap;

    /* DW_CFA_xxxx */
    opcode = *(uint8_t *)data;
    data += sizeof(uint8_t);

    /* Masked opcodes */
    maskedOpcode = opcode & DW_CFA_OPCODE_MASK;
    switch (opcode & DW_CFA_OPCODE_MASK) {
    case DW_CFA_advance_loc:
        *datap = data;
        state->location += ((opcode & 0x3f) * cie->code_alignment_factor);
        return TOOLS_SUCCESS;

    case DW_CFA_offset:
       reg = getOrAddDwarfFrameReg(state, opcode & 0x3f);
       if (!reg)
           return TOOLS_ERROR_UNKNOWN;
       reg->rule = DWARF_FRAME_REG_OFFSET;
       reg->data.offset = decodeULEB((char **)&data);
       reg->data.offset *= cie->data_alignment_factor;
       *datap = data;
       return TOOLS_SUCCESS;

#if 0
    case DW_CFA_restore:
       reg = getOrAddDwarfFrameReg(state, opcode & 0x3f);
       if (!reg)
           return TOOLS_ERROR_UNKNOWN;
       reg->rule = reg->initial_rule;
       *datap = data;
       return TOOLS_SUCCESS;
#endif

    case DW_CFA_opcode:
        /* Non-masked opcodes */
        switch (opcode) {
        case DW_CFA_set_loc:
            state->location = *(uint64_t *)data;
            data += sizeof(uint64_t);
            break;
        case DW_CFA_advance_loc1:
            state->location += (*(uint8_t *)data * cie->code_alignment_factor);
            data += sizeof(int8_t);
            break;
        case DW_CFA_advance_loc2:
            state->location += (*(uint16_t *)data * cie->code_alignment_factor);
            data += sizeof(uint16_t);
            break;
        case DW_CFA_advance_loc4:
            state->location += (*(uint32_t *)data * cie->code_alignment_factor);
            data += sizeof(uint32_t);
            break;
        case DW_CFA_offset_extended:
            reg = getOrAddDwarfFrameReg(state, decodeULEB((char **)&data));
            if (!reg)
                return TOOLS_ERROR_UNKNOWN;
            reg->rule = DWARF_FRAME_REG_OFFSET;
            reg->data.offset = decodeULEB((char **)&data);
            reg->data.offset *= cie->data_alignment_factor;
            break;
        case DW_CFA_restore_extended:
            reg = getOrAddDwarfFrameReg(state, decodeULEB((char **)&data));
            if (!reg)
                return TOOLS_ERROR_UNKNOWN;
            reg->rule = reg->initial_rule;
            memcpy((void *)&reg->data,
                   (void *)&reg->initial_data,
                   sizeof(reg->data));
            break;
        case DW_CFA_undefined:
            reg = getOrAddDwarfFrameReg(state, decodeULEB((char **)&data));
            if (!reg)
                return TOOLS_ERROR_UNKNOWN;
            reg->rule = DWARF_FRAME_REG_UNDEFINED;
            break;
        case DW_CFA_same_value:
            /* Rule remains the same, so leave it as is... */
            reg = getOrAddDwarfFrameReg(state, decodeULEB((char **)&data));
            if (!reg)
                return TOOLS_ERROR_UNKNOWN;
            reg->data.reg = reg->regnum;
            reg->rule = DWARF_FRAME_REG_REG;
            break;
        case DW_CFA_register:
            reg = getOrAddDwarfFrameReg(state, decodeULEB((char **)&data));
            if (!reg)
                return TOOLS_ERROR_UNKNOWN;
            reg->data.reg = decodeULEB((char **)&data);
            reg->rule = DWARF_FRAME_REG_REG;
            break;

            /* These are currently not handled (verified with compiler team) */
        case DW_CFA_remember_state:
        case DW_CFA_restore_state:
            return TOOLS_ERROR_FEATURE_NOT_IMPLEMENTED;

            /* Definitions */
        case DW_CFA_def_cfa:
            state->cfa.reg = getOrAddDwarfFrameReg(state, decodeULEB((char **)&data));
            if (!state->cfa.reg)
                return TOOLS_ERROR_UNKNOWN;
            state->cfa.offset = decodeULEB((char **)&data);
            break;
        case DW_CFA_def_cfa_register:
            state->cfa.reg = getOrAddDwarfFrameReg(state, decodeULEB((char **)&data));
            if (!state->cfa.reg)
                return TOOLS_ERROR_UNKNOWN;
            break;
        case DW_CFA_def_cfa_offset:
            state->cfa.offset = decodeULEB((char **)&data);
            break;

            /* DWARF 3.0 */
        case DW_CFA_def_cfa_expression:
            res = decodeBlock(state, (char **)&data, &value);
            if (res != TOOLS_SUCCESS)
                return res;
            state->cfa.offset = (uint32_t)value;
            break;
        case DW_CFA_expression:
            state->cfa.reg = getOrAddDwarfFrameReg(state, decodeULEB((char **)&data));
            if (!state->cfa.reg)
                return TOOLS_ERROR_UNKNOWN;
            res = decodeBlock(state, (char **)&data, &value);
            if (res != TOOLS_SUCCESS)
                return res;
            state->cfa.offset = (uint32_t)value;
            break;
        case DW_CFA_offset_extended_sf:
            reg = getOrAddDwarfFrameReg(state, decodeULEB((char **)&data));
            if (!reg)
                return TOOLS_ERROR_UNKNOWN;
            reg->rule = DWARF_FRAME_REG_OFFSET;
            reg->data.offset = decodeSLEB((char **)&data) * cie->data_alignment_factor;
            break;
        case DW_CFA_def_cfa_sf:
            state->cfa.reg = getOrAddDwarfFrameReg(state, decodeULEB((char **)&data));
            if (!state->cfa.reg)
                return TOOLS_ERROR_UNKNOWN;
            state->cfa.offset = decodeSLEB((char **)&data) * cie->data_alignment_factor;
            break;
        case DW_CFA_def_cfa_offset_sf:
            state->cfa.offset = decodeSLEB((char **)&data) * cie->data_alignment_factor;
            break;
        case DW_CFA_val_offset:
            reg = getOrAddDwarfFrameReg(state, decodeULEB((char **)&data));
            if (!reg)
                return TOOLS_ERROR_UNKNOWN;
            reg->rule = DWARF_FRAME_REG_OFFSET;
            reg->data.offset = decodeULEB((char **)&data) * cie->data_alignment_factor;
            state->cfa.reg = reg;
            break;
        case DW_CFA_val_offset_sf:
            reg = getOrAddDwarfFrameReg(state, decodeULEB((char **)&data));
            if (!reg)
                return TOOLS_ERROR_UNKNOWN;
            reg->rule = DWARF_FRAME_REG_OFFSET;
            reg->data.offset = decodeSLEB((char **)&data) * cie->data_alignment_factor;
            state->cfa.reg = reg;
            break;
        case DW_CFA_val_expression:
            reg = getOrAddDwarfFrameReg(state, decodeULEB((char **)&data));
            if (!reg)
                return TOOLS_ERROR_UNKNOWN;
            reg->rule = DWARF_FRAME_REG_VALUE;
            res = decodeBlock(state, (char **)&data, &value);
            if (res != TOOLS_SUCCESS)
                return res;
            reg->data.offset = (int32_t)value;
            state->cfa.reg = reg;
            break;

            /* No-ops */
        case DW_CFA_nop:
        case DW_CFA_lo_user:
        case DW_CFA_hi_user:
            break;
        default:
            return TOOLS_ERROR_FEATURE_NOT_IMPLEMENTED;
        }
        break;

    default:
        return TOOLS_ERROR_FEATURE_NOT_IMPLEMENTED;
    }

    *datap = data;
    return TOOLS_SUCCESS;
}

/* Initialize the debug_frame 'state'.
 * Process the CFA instructions in the CIE to initialize the debug_frame.
 */
static TOOLSresult
initDwarfFrameState(DwarfCIE *cie, const DwarfFDE *fde, DwarfFrameState *state)
{
    const uint8_t *data;

    state->location = fde->initial_location;
    state->cfa.reg = NULL;
    state->cfa.offset = 0;
    tHashMapItr *itr = NULL;

    state->return_address_column = cie->return_address_column;

    /* We only need to initialize this puppy from the CIE once */
    state->regs = toolsHashMapNew(toolsUint32HashFun, toolsUint32EqualFun, 16);
    if (!state->regs)
        return TOOLS_ERROR_UNKNOWN;
    
    /* Initialize the register set per CFA insns in the CIE */
    data = cie->initial_instructions;
    while (data < cie->end) {
        const TOOLSresult res = nextCFAInsn(cie, &data, state);
        if (res != TOOLS_SUCCESS) {
            toolsDestroyElfFrameRegMap(state);
            return res;
        }
    }

    /* For each register set the initial data */
    for (itr = toolsHashMapGetIterator(state->regs);
         itr;
         itr = toolsHashMapGetNext(state->regs, itr)) {

        DwarfFrameReg *reg = toolsHashMapGetEntry(itr);
        reg->initial_rule = reg->rule;
        memcpy((void *)&reg->initial_data,
               (void *)&reg->data,
               sizeof(reg->initial_data));
    }
    return TOOLS_SUCCESS;
}

/* Since we are updating go ahead and just propagate the target's
 * rule to avoid having to trace from rule to rule later during 
 * unwind.
 */
static void
propagateSpillInfo(DwarfFrameState *state)
{
    tHashMapItr *itr;

    /* For each register */
    for (itr = toolsHashMapGetIterator(state->regs);
         itr;
         itr = toolsHashMapGetNext(state->regs, itr)) {

        DwarfFrameReg *reg = toolsHashMapGetEntry(itr);
        
        /* We only care about register(R) rule since it encodes a target reg */
        if (reg->rule == DWARF_FRAME_REG_REG) {
            DwarfFrameReg *target = getOrAddDwarfFrameReg(state, reg->data.reg);
            if (target && (target->rule == DWARF_FRAME_REG_REG ||
                           target->rule == DWARF_FRAME_REG_OFFSET)) {
                reg->rule = target->rule;
                reg->data = target->data;
            }
        }
    }
}

/* Initialize the frame state, and scan through the debug_frame CFA instruction
 * stream updating this state.
 *
 * Once the instructions have been exhausted, or if we find the matching 'pc'
 * then we stop processing CFA instructions and output the CFA item to the
 * caller.
 *
 * Returns CFA information in 'frame' [output]
 * TODO: CACHE THIS!! This is very expensive.
 */
static TOOLSresult
getDwarfFrameState(DwarfCIE *cie, const DwarfFDE *fde, uint64_t pc, DwarfFrameState *frame)
{
    TOOLSresult res;
    const uint8_t *inst;

    /* A little paranoid? */
    if (!cie || !fde || !fde->instructions || !pc || !frame)
        return TOOLS_ERROR_INVALID_VALUE;

    if (frame->regs)
        toolsDestroyElfFrameRegMap(frame);

    inst = fde->instructions;

    /* Initialize the CIE (state) */
    res = initDwarfFrameState(cie, fde, frame);
    if (res != TOOLS_SUCCESS)
        return res;

    /* Scan the FDE instruction stream until we go past the address bounds or
       until we get to our pc.
     */
    while (inst < fde->end && frame->location < pc) {
        res = nextCFAInsn(cie, &inst, frame);
        if (res != TOOLS_SUCCESS)
            return res;
    }

    return TOOLS_SUCCESS;
}

/* Take all the regs and cfa offset from the target and update the current frame state.
   The idea here is current will replace it's entries with target under the following conditions:
   Current | Target | New Value
     s         s          s
     u         u          u
    cfaN      cfaM       cfaM 
     *         rM        [rM] (dereference rM from current)
     rN        *          *
For CFA offset, if the CFA reg matches, add the offsets
Otherwise replace current with target's value, dereferencing the value of the reg.
*/
TOOLSresult
toolsUpdateDwarfFrameState(DwarfFrameState *target, DwarfFrameState *current)
{
    tHashMapItr *reg_itr = NULL;
    DwarfFrameReg *reg = NULL;
    const DwarfFrameReg *current_reg = NULL;

    if (!target || !current)
        return TOOLS_ERROR_UNKNOWN;

    reg_itr = toolsHashMapGetIterator(target->regs);
    while(reg_itr) {
        reg = (DwarfFrameReg*)toolsHashMapGetEntry(reg_itr);
        current_reg = NULL;

        switch(reg->rule) {
        case DWARF_FRAME_REG_UNDEFINED:
        case DWARF_FRAME_REG_OFFSET:
            break;
        case DWARF_FRAME_REG_VALUE:
        case DWARF_FRAME_REG_SAME:
            current_reg = getDwarfFrameReg(current, reg->regnum);
            break;
        case DWARF_FRAME_REG_REG:
            current_reg = getDwarfFrameReg(current, reg->data.reg);
            break;
        default:
            return TOOLS_ERROR_UNKNOWN;
        }

        if (current_reg) {
            reg->rule = current_reg->rule;
            reg->data = current_reg->data;
        }

        reg_itr = toolsHashMapGetNext(target->regs, reg_itr);
    }

    /* Now all cfa rules will point at the new frame address */
    current->cfa.offset += target->cfa.offset;
    current->return_address_column = target->return_address_column;

    /* Copy over the newly updated register table from target */
    toolsDestroyElfFrameRegMap(current);
    current->regs = target->regs;
    current->cfa.reg = target->cfa.reg;
    target->regs = NULL;

    return TOOLS_SUCCESS;
}

/* Locate an CIE and FDE for a given pc.
 * TOOLS_ERROR_KEY_NOT_FOUND is returned if a CIE/FDE cannot be located.
 */
static TOOLSresult
findFDE(const DwarfDebugFrame *frame, uint64_t pc,
        DwarfCIE **ciep, const DwarfFDE **fdep)
{
    DwarfCIE *cie;
    DwarfFDE *fde;

    if (!frame || !ciep || ! fdep)
        return TOOLS_ERROR_INVALID_VALUE;

    *fdep = NULL;
    *ciep = NULL;
    
    /* Given the PC and debug_frame, abbreviate the algorithm in the 
     * DWARF 2.0 Spec, page 64, such that we do not have to store
     * the entire FDE in memory.
     */

    /* Locate the FDE that this pc lies within */
    cie = (DwarfCIE*)toolsRangeMapLookupByAddr(frame->pcTocie, pc);
    if (!cie)
        return TOOLS_ERROR_KEY_NOT_FOUND;

    fde = toolsRangeMapLookupByAddr(cie->pcTofde, pc);
    if (!fde)
        return TOOLS_ERROR_KEY_NOT_FOUND;

    *ciep = cie;
    *fdep = fde;

    return TOOLS_SUCCESS;
}

/* Given a debug frame and pc, return the CFA information and state information */
TOOLSresult
toolsGetFrameState(const DwarfDebugFrame *dbg_frame, uint64_t pc, DwarfFrameState *frame)
{
    DwarfCIE *cie;
    TOOLSresult res;
    const DwarfFDE *fde;

    if (!dbg_frame || !frame)
        return TOOLS_ERROR_INVALID_VALUE;

    memset(frame, 0, sizeof(*frame));

    res = findFDE(dbg_frame, pc, &cie, &fde);
    if (res != TOOLS_SUCCESS)
        goto fail;

    res = getDwarfFrameState(cie, fde, pc, frame);
    if (res != TOOLS_SUCCESS)
        goto fail;

    return res;

fail:
    toolsDestroyElfFrameRegMap(frame);

    return res;
}

/* Wrapper to the 32/64 bit version.  This is the primary interface leading into
 * the debug_frame information.
 */
TOOLSresult
toolsGetDebugFrame(const void *pimage, DwarfDebugFrame *frame)
{
    TOOLSresult tres = TOOLS_SUCCESS;
    if (!isELF(pimage))
        return TOOLS_ERROR_INVALID_ELF;
    if (isELF64(pimage))
        tres = toolsElf64GetDebugFrame(pimage, frame);
    else
        tres = toolsElf32GetDebugFrame(pimage, frame);
    if (tres == TOOLS_SUCCESS)
        frame->initialized = 1;
    return tres;
}
