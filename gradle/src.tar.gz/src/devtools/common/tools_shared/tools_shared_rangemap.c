/*
 * Copyright 2013-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tools_shared_rangemap.h"
#include "tools_shared_rbtr.h"

typedef struct AddrRange_st AddrRange;

// Internal type for address ranges
struct AddrRange_st {
    uint64_t lo;
    uint64_t hi;
};

struct tRangeMap_st {
    // Currently implemented with a red-black tree
    uint8_t initialized;
    tRbtree *rbtree;
};

static int
toolsRangeMapIntersect(void *searchFor, void *treeNode)
{
    AddrRange* searchForAddr = (AddrRange*)searchFor;
    AddrRange* treeNodeAddr = (AddrRange*)treeNode;

    AddrRange *a, *b = 0;
    if (treeNodeAddr->lo < searchForAddr->lo) {
        a = treeNodeAddr;
        b = searchForAddr;
    }
    else {
        a = searchForAddr;
        b = treeNodeAddr;
    }

    return (b->lo <= a->hi);
}

static int
toolsRangeMapCompareRange(void *searchFor, void *treeNode)
{
    AddrRange* searchForAddr = (AddrRange*)searchFor;
    AddrRange* treeNodeAddr = (AddrRange*)treeNode;
    // Check if one address range is inside the other
    if (treeNodeAddr->lo <= searchForAddr->lo &&
        treeNodeAddr->hi >= searchForAddr->hi)
        return 0;

    return searchForAddr->lo > treeNodeAddr->lo ? 1 : -1;
}

static TOOLSresult
toolsRangeMapInitialize(tRangeMap* map)
{
    TOOLSresult rbtStatus = TOOLS_SUCCESS;

    if (!map)
        return TOOLS_ERROR_INVALID_VALUE;

    rbtStatus = toolsRbtCreate(&map->rbtree, &toolsRangeMapCompareRange, &toolsRangeMapIntersect);
    if (rbtStatus != TOOLS_SUCCESS)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    map->initialized = 1;

    return TOOLS_SUCCESS;
}

TOOLSresult
toolsRangeMapCreate(tRangeMap **pMap)
{
    tRangeMap *map = NULL;
    TOOLSresult tres = TOOLS_SUCCESS;

    if (!pMap)
        return TOOLS_ERROR_INVALID_VALUE;

    map = (tRangeMap*)calloc(1, sizeof(*map));
    if (!map)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    tres = toolsRangeMapInitialize(map);
    if (tres != TOOLS_SUCCESS) {
        free(map);
        return tres;
    }

    *pMap = map;

    return TOOLS_SUCCESS;
}
static void delRangeMapKey(void *entry, void *del)
{
    if (entry) {
        AddrRange *ar = (AddrRange*)entry;
        free(ar);
    }
}

void
toolsRangeMapDestroy(tRangeMap **pMap, tSingleFun del, void *data )
{
    tRangeMap *map = NULL;

    if (!pMap || !(*pMap))
        return;

    map = *pMap;

    toolsRbtDestroy(&map->rbtree, delRangeMapKey, NULL, del, data);
    map->initialized = 0;
    free(map->rbtree);
    map->rbtree = NULL;
    free(map);

    *pMap = NULL;

    return;
}

static TOOLSresult
toolsRangeMapInsertByAddrRange(tRangeMap* map, uint64_t lo, uint64_t hi, void* data)
{
    AddrRange *ar = NULL;
    TOOLSresult rbtStatus = TOOLS_SUCCESS;

    if (!map || !data || lo > hi)
        return TOOLS_ERROR_INVALID_VALUE;

    if (!map->initialized)
        return TOOLS_ERROR_UNKNOWN;

    ar = (AddrRange*)calloc(1, sizeof(*ar));
    if (!ar)
        return TOOLS_ERROR_OUT_OF_MEMORY;

    ar->lo = lo;
    ar->hi = hi;

    rbtStatus = toolsRbtInsert(map->rbtree, (void*)ar, data);
    if (rbtStatus != TOOLS_SUCCESS) {
        free(ar);
        return rbtStatus;
    }

    return TOOLS_SUCCESS;
}

TOOLSresult
toolsRangeMapInsertByAddr(tRangeMap* map, uint64_t addr, void* data)
{
    return toolsRangeMapInsertByAddrRange(map, addr, addr, data);
}

TOOLSresult
toolsRangeMapInsertByRange(tRangeMap* map, uint64_t addr, uint64_t size, void* data)
{
    return toolsRangeMapInsertByAddrRange(map, addr, addr + size - 1, data);
}

static void*
toolsRangeMapLookupByAddrRange(tRangeMap* map, uint64_t lo, uint64_t hi,
                               AddrRange** key, tRbtIterator *itr)
{
    tRbtIterator rbtitr;
    AddrRange ar, *dar;
    void* data = NULL;

    if (!map || lo > hi)
        return NULL;

    if (!map->initialized)
        return NULL;

    ar.lo = lo;
    ar.hi = hi;
    dar = &ar;
    rbtitr = toolsRbtFind(map->rbtree, (void*)&ar);
    if (!rbtitr)
        return NULL;

    toolsRbtKeyValue(rbtitr, (void**)&dar, (void**)&data);
    if (key)
        *key = dar;

    if (itr)
        *itr = rbtitr;

    return data;
}

void*
toolsRangeMapLookupByAddr(tRangeMap* map, uint64_t addr)
{
    return toolsRangeMapLookupByAddrRange(map, addr, addr, NULL, NULL);
}

void*
toolsRangeMapLookupByRange(tRangeMap* map, uint64_t addr, uint64_t size)
{
    return toolsRangeMapLookupByAddrRange(map, addr, addr + size - 1, NULL, NULL);
}

void*
toolsRangeMapRemoveByAddr(tRangeMap* map, uint64_t addr)
{
    tRbtIterator itr;
    void* data = NULL;
    AddrRange *ar = NULL;

    if (!map)
        return NULL;

    if (!map->initialized)
        return NULL;

    data = toolsRangeMapLookupByAddrRange(map, addr, addr, &ar, &itr);
    if (data) {
        toolsRbtErase(map->rbtree, itr);
        free(ar);
    }
    return data;
}

void*
toolsRangeMapRemoveByRange(tRangeMap* map, uint64_t addr, uint64_t size)
{
    tRbtIterator itr;
    void* data = NULL;
    AddrRange *ar = NULL;

    if (!map)
        return NULL;

    if (!map->initialized)
        return NULL;

    data = toolsRangeMapLookupByAddrRange(map, addr, addr + size - 1, &ar, &itr);
    if (data) {
        toolsRbtErase(map->rbtree, itr);
        free(ar);
    }
    return data;
}

tRangeMapItr*
toolsRangeMapGetIterator(const tRangeMap *map)
{
    if (!map || !map->initialized)
        return NULL;

    return (tRangeMapItr*)toolsRbtBegin(map->rbtree);
}

tRangeMapItr*
toolsRangeMapGetNext(const tRangeMap *map, const tRangeMapItr *itr)
{
    if (!map || !map->initialized)
        return NULL;

    return (tRangeMapItr*)toolsRbtNext(map->rbtree, (tRbtIterator)itr);
}

tRangeMapItr*
toolsRangeMapGetIteratorByRange(const tRangeMap *map, uint64_t addr, uint64_t size)
{
    tRbtIterator itr = NULL;
    AddrRange ar;

    if (!map || !map->initialized)
        return NULL;

    ar.lo = addr;
    ar.hi = addr + size - 1;

    itr = toolsRbtIntersect(map->rbtree, (void*)&ar);
    if (!itr)
        return NULL;

    return (tRangeMapItr*)(itr);
}

void*
toolsRangeMapGetEntry(const tRangeMapItr *itr)
{
    void *val = NULL;

    if (!itr)
        return NULL;

    toolsRbtKeyValue((tRbtIterator)itr, NULL, &val);

    return val;
}

uint64_t
toolsRangeMapGetSize(const tRangeMapItr *itr)
{
    AddrRange *ar = NULL;

    if (!itr)
        return 0;

    toolsRbtKeyValue((tRbtIterator)itr, (void**)&ar, NULL);

    if (ar)
        return (ar->hi - ar->lo + 1);

    return 0;
}

uint64_t
toolsRangeMapGetAddr(const tRangeMapItr *itr)
{
    AddrRange *ar = NULL;

    if (!itr)
        return 0;

    toolsRbtKeyValue((tRbtIterator)itr, (void**)&ar, NULL);

    if (ar)
        return (ar->lo);

    return 0;
}

uint32_t
toolsRangeMapIsRangeClear(tRangeMap *map, uint64_t addr, uint64_t size)
{
    if (!map || !map->initialized)
        return 0;

    return (toolsRangeMapGetIteratorByRange(map, addr, size) == NULL);
}

typedef struct rbtrFunctorData_st rbtrFunctorData;
struct rbtrFunctorData_st {
    tRangeMapFunctor pfn;
    void *data;
};

static TOOLSresult
rbtrFunctor(void *key, void *entry, void *data)
{
    AddrRange *ar = (AddrRange*)key;
    rbtrFunctorData *d = (rbtrFunctorData*)data;
    TOOLSresult tres = TOOLS_SUCCESS;

    if (d->pfn)
        tres = d->pfn(ar->lo, (ar->hi - ar->lo + 1), entry, d->data);

    return tres;
}

TOOLSresult
toolsRangeMapApplyFunctor(tRangeMap *map, tRangeMapFunctor fn, void *data)
{
    rbtrFunctorData d;

    if (!map || !fn)
        return TOOLS_ERROR_INVALID_VALUE;

    if (!map->initialized)
        return TOOLS_SUCCESS;

    d.pfn = fn;
    d.data = data;

    return toolsRbtApplyFunctor(map->rbtree, rbtrFunctor, (void*)&d);
}
