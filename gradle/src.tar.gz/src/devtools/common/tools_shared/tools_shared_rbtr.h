/*
 * Copyright 2013-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef _TOOLS_SHARED_RBT_H
#define _TOOLS_SHARED_RBT_H
// from http://www.epaperpress.com/sortsearch/index.html
#include "tools_shared.h"
#include "tools_shared_list.h"

typedef enum { TOOLS_NODE_BLACK, TOOLS_NODE_RED } tRbtNodeColor;

typedef void *tRbtIterator;

typedef int (*tRbtCompareFun)(void*, void*);
typedef TOOLSresult (*tRbtFunctor)(void*, void*, void*);

typedef struct tRbtree_st tRbtree;

// create red-black tree
// parameters:
//     compare  pointer to function that compares keys
//              return 0   if a == b
//              return < 0 if a < b
//              return > 0 if a > b
//              For range maps, return 0 if a is a full subset of b
//     intersect pointer to function that determines if 2 keys overlap. This is used on
//               insertion. This function :
//               return 1 if a == b. For range maps, return 1 if a AND b is non empty
//               return 0 if a != b.
// returns:
//     handle   use handle in calls to rbt functions
TOOLSresult toolsRbtCreate(tRbtree **prbt, tRbtCompareFun compare, tRbtCompareFun intersect);

// destroy red-black tree
void toolsRbtDestroy(tRbtree **prbtree, tSingleFun keydel, void *keyuser, tSingleFun valdel, void *valdata);

// insert key/value pair
TOOLSresult toolsRbtInsert(tRbtree *rbtree, void *key, void *value);

// delete node in tree associated with iterator
// this function does not free the key/value pointers
TOOLSresult toolsRbtErase(tRbtree *rbtree, tRbtIterator i);

// return ++i
tRbtIterator toolsRbtNext(tRbtree *rbtree, tRbtIterator i);

// return pointer to first node
tRbtIterator toolsRbtBegin(tRbtree *rbtree);

// return pointer to one past last node
tRbtIterator toolsRbtEnd(tRbtree *rbtree);

// returns key/value pair associated with iterator
void toolsRbtKeyValue(tRbtIterator i, void **key, void **value);

// returns iterator associated with key
tRbtIterator toolsRbtFind(tRbtree *rbtree, void *key);

// returns iterator associated with key
tRbtIterator toolsRbtIntersect(tRbtree *rbtree, void *key);

// Checks if a key can be inserted. Return 1 if can insert, 0 if not
int toolsRbtCanInsertKey(tRbtree *rbtree, void *key);

// Apply a functor
TOOLSresult toolsRbtApplyFunctor(tRbtree *rbtree, tRbtFunctor fn, void *data);

#endif
