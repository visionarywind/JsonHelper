/*
 * Copyright 2007-2011 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef _TOOLS_SHARED_RANGE_MAP_H
#define _TOOLS_SHARED_RANGE_MAP_H

#include "tools_shared.h"
#include "tools_shared_list.h"

typedef struct tRangeMap_st tRangeMap;
typedef void* tRangeMapItr;

typedef TOOLSresult (*tRangeMapFunctor) (uint64_t addr, uint64_t size, void *entry, void *data);

#ifdef __cplusplus
extern "C" {
#endif

/* Creates and returns a new empty rangemap
 * pMap : pointer to a rangemap
*/
TOOLSresult toolsRangeMapCreate(tRangeMap **pMap);

/* Destroys a range map and all internal storage
 *  pMap : pointer to rangemap
*/
void toolsRangeMapDestroy(tRangeMap **pMap, tSingleFun del, void *data);

/* Inserts an element at a given address into the rangemap
    map  : Rangemap to insert into
    addr : Address to insert element at
    data : Pointer to the data to insert

    This function will return an error if insertion fails. This can happen due
    to insufficient memory or an element already existing at the given key
*/
TOOLSresult toolsRangeMapInsertByAddr(tRangeMap *map, uint64_t addr, void *data);

/* Insert an element into the map such that [addr, addr + size - 1] map to given entry
    map  : Rangemap to insert into
    addr : Start address for insertion
    size : Size of allocation. (Note : (addr + size - 1) is the last valid address
           for this allocation
    data : Pointer to data to insert

    This function will return an error if insertion fails. This can happen due
    to insufficient memory or an element already existing at the given key
 */
TOOLSresult toolsRangeMapInsertByRange(tRangeMap *map, uint64_t addr, uint64_t size, void *data);

/* Find an element by address. Given an address, this will return the data pointer
   that the containing region was mapped to
    map  : Rangemap to search in
    addr : Address

    Returns the data pointer mapped to region containing addr, NULL if not found
 */
void *toolsRangeMapLookupByAddr(tRangeMap *map, uint64_t addr);


/* Find an element by address range. Given an address range, this will return the data pointer
   that the containing region was mapped to
    map  : Rangemap to search in
    addr : Start Address for search range
    size : Size. (Note : the containing region must fully overlap [addr, addr + size - 1] )

    Returns the data pointer mapped to region containing addr, NULL if not found
 */
void *toolsRangeMapLookupByRange(tRangeMap *map, uint64_t addr, uint64_t size);

/* Remove an element by address. Given an address, this will remove the element
   containing the region, and return the data pointer.
    map  : Rangemap to use
    addr : Address

    Returns NULL on error/ element not found. Otherwise returns the containing region's
    data pointer.
*/
void *toolsRangeMapRemoveByAddr(tRangeMap *map, uint64_t addr);

/* Remove an element by address range. Given an address range, this will remove the element
   containing the region, and return the data pointer.
    map  : Rangemap to use
    addr : Start address
    size : Size. (Note : the containing region must fully overlap [addr, addr + size - 1] )

    Returns NULL on error/ element not found. Otherwise returns the containing region's
    data pointer.
*/
void *toolsRangeMapRemoveByRange(tRangeMap *map, uint64_t addr, uint64_t size);

/* Get an iterator to the start of the rangemap
 */
tRangeMapItr* toolsRangeMapGetIterator(const tRangeMap *map);

/* Get an iterator to first element in the given range.
 */
tRangeMapItr* toolsRangeMapGetIteratorByRange(const tRangeMap *map, uint64_t addr, uint64_t size);

/* Get the next iterator
 */
tRangeMapItr* toolsRangeMapGetNext(const tRangeMap *map, const tRangeMapItr *itr);

/* Get the data associated with an iterator
 */
void* toolsRangeMapGetEntry(const tRangeMapItr *itr);

/* Get the size associated with the domain of iterator.
 */
uint64_t toolsRangeMapGetSize(const tRangeMapItr *itr);

/* Get the starting address associated with the domain of the iterator
 */
uint64_t toolsRangeMapGetAddr(const tRangeMapItr *itr);

/* Check if the range [addr, addr + size - 1] contains any elements or is clear
 *  map  : Rangemap to use
 *  addr : Starting address of range to be checked
 *  size : Size of the range. The ending address is computed as addr + size -1
 *
 * Returns 1 if the range is clear, 0 if not
 */
uint32_t toolsRangeMapIsRangeClear(tRangeMap *map, uint64_t addr, uint64_t size);

/* Apply a function to each element in the rangemap
 * Returns if any of the elements fail
 * Returns TOOLS_SUCCESS on success
 */
TOOLSresult toolsRangeMapApplyFunctor(tRangeMap *map, tRangeMapFunctor fn, void *data);

#ifdef __cplusplus
}
#endif

#endif
