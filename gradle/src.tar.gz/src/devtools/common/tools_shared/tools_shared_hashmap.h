/*
 * Copyright 2007-2011 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef _TOOLS_SHARED_HASHMAP_H
#define _TOOLS_SHARED_HASHMAP_H

#include "tools_shared.h"
#include "tools_shared_list.h"

#include <cuda_inttypes.h>

/* Structs */

typedef struct tListElem_st tHashMapItr;
typedef uint64_t tHashMapKey_t;
typedef struct tHashMap_st tHashMap;

#define tHashMapNumToKey(k)  ((tHashMapKey_t)(k))
#define tHashMapPtrToKey(k)  ((tHashMapKey_t)(uintptr_t)(k))

typedef TOOLSresult (*tHashFunctor) (tHashMapKey_t key, void *entry, void *data);

#if defined(__cplusplus)
extern "C" {
#endif

/* Function types */

/* Hash function type
 * Input: key
 * Output: int32_t
 */
typedef int32_t (*tHashFun)(const tHashMapKey_t);

/* Equal function type
 * Input: the two keys to compare
 * Output: 1 if the keys are the same, 0 otherwise
 */
typedef uint32_t (*tEqualFun)(const tHashMapKey_t, const tHashMapKey_t);

/* Hash/equal functions */

/* Default string hash function */
int32_t toolsStringHashFun(const tHashMapKey_t);

/* Predefined string compare function */
uint32_t toolsStringEqualFun(const tHashMapKey_t key1, const tHashMapKey_t key2);

/* Default int hash function */
int32_t toolsUint32HashFun(const tHashMapKey_t key);

/* Predefined int compare function */
uint32_t toolsUint32EqualFun(const tHashMapKey_t key1, const tHashMapKey_t key2);

/* Predefined uint64 compare function */
uint32_t toolsUint64EqualFun(const tHashMapKey_t key1, const tHashMapKey_t key2);

/* Default pointer hash function */
int32_t toolsPointerHashFun(const tHashMapKey_t key);

/* Predefined int compare function */
uint32_t toolsPointerEqualFun(const tHashMapKey_t key1, const tHashMapKey_t key2);

/* Functions */

/* Creates and returns a new empty map.
 * hash - specified hash function, should not be NULL. If key is string, use toolsStringHashFun
 * equal - specified equal function, should not be NULL. If key is string, use toolsStringEqualFun
 * numBuckets - number of buckets, should be greater than 0
 * The map needs to be freed by caller.
 * Returns NULL if failed.
 */
tHashMap *toolsHashMapNew(tHashFun hash, tEqualFun equal, size_t numBuckets);

/* Creates and returns a new empty map, using the original map's number of buckets and
 * hash/compare functions.
 * original - the original map.
 * The map needs to be freed by caller.
 * Returns Null if failed.
 */
tHashMap *toolsHashMapCopyTemplate(const tHashMap *original);

/* Inserts a pair into the map */
TOOLSresult toolsHashMapInsert(tHashMap *m, const tHashMapKey_t key, void * data);

/* Gets an iterator of a hashmap.
 * Returns NULL on fail.
 */
tHashMapItr *toolsHashMapGetIterator(const tHashMap *m);

/* Advances the iterator by one element.
 * Returns NULL on fail or when reaches the end of the map.
 */
tHashMapItr *toolsHashMapGetNext(const tHashMap *m, const tHashMapItr *i);

/* Gets the hash key from an iterator */
tHashMapKey_t toolsHashMapGetKey(const tHashMapItr *i);

/* Gets the actual hashmap entry from an iterator */
void *toolsHashMapGetEntry(const tHashMapItr *i);

/* Returns an entry from the hashmap. */
void *toolsHashMapGetAnyEntry(const tHashMap *m);

/* Maps a key to an element.
 * Returns NULL if the key is not found.
 */
void *toolsHashMapFind(const tHashMap *m, const tHashMapKey_t key);

/* Tests if the key is present in the map
 * Returns 1 if true, 0 otherwise.
 */
uint32_t toolsHashMapContains(const tHashMap *m, const tHashMapKey_t key);

/* Removes a key/element pair from the hashmap.
 */
TOOLSresult toolsHashMapRemove(tHashMap *m, const tHashMapKey_t key, tSingleFun del);

size_t toolsHashMapSize(const tHashMap *m);

/* Convert the map into a list.
 * The list needs to be freed by caller.
 * Returns NULL if fail.
 */
tList *toolsHashMapToList(const tHashMap *m);

/* Apply a functor to a hashmap
 * Will fail if any single call fails
 * Returns TOOLS_SUCCESS on success
 */
TOOLSresult toolsHashMapApplyFunctor(const tHashMap *m, tHashFunctor fn, void *data);

/* Deletes a map. Accepts a custom function for individual elements
 * Also accepts custom data to pass into the deletion function
 */
TOOLSresult toolsHashMapDelete(tHashMap *m, tSingleFun del, void *data);

#if defined(__cplusplus)
}
#endif

#endif
