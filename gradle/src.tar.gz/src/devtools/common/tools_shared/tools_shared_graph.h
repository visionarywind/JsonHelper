/*
 * Copyright 2007-2011 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef _TOOLS_SHARED_GRAPH_H
#define _TOOLS_SHARED_GRAPH_H

#include "tools_shared.h"
#include "tools_shared_list.h"
#include "tools_shared_hashset.h"

#include <cuda_inttypes.h>

/* Structs */

typedef tHashSetItr toolsGraphVertexItr;
typedef tHashSetItr toolsGraphEdgeItr;

typedef struct toolsGraph_st        toolsGraph;
typedef struct toolsGraphEdge_st    toolsGraphEdge;
typedef struct toolsGraphVertex_st  toolsGraphVertex;

#if defined(__cplusplus)
extern "C" {
#endif

/* Functions */

/* Create and return a new empty graph
 * pGraph - Returned pointer to graph.
 * Return TOOLS_SUCCESS on sucess
 */
TOOLSresult toolsGraphCreate(toolsGraph **pGraph, void *userData);

/* Destroy Graph
 *  For a shallow copy of a graph, this will not delete edges or vertices
 * graph    - Pointer to graph
 * vertexDelFun - Optional pointer to vertex userData deletion function
 * edgeDelFun - Optional pointer to edge userData deletion function
 * Returns TOOLS_SUCCESS on success
 */
TOOLSresult toolsGraphDestroy(toolsGraph *graph,
                              tSingleFun graphDataDelFun, void *graphParam,
                              tSingleFun vertexDataDelFun, void *vertexParam,
                              tSingleFun edgeDataDelFun, void *edgeParam);

/* Get the userData assigned to the graph
 * graph    - Pointer to graph
 * Returns the user data or NULL on error
 */
void* toolsGraphGetData(toolsGraph *graph);

/* Get iterator over all vertices in graph
 * graph    - pointer to Graph
 * Returns iterator to the first vertex or NULL
 */
toolsGraphVertexItr* toolsGraphGetVertexIterator(toolsGraph *graph);

/* Get next iterator over all vertices in graph
 * graph    - Pointer to graph
 * itr      - pointer to previous element
 * Returns iterator to next vertex or NULL
 */
toolsGraphVertexItr* toolsGraphGetVertexNext(toolsGraph *graph, const toolsGraphVertexItr* itr);

/* Get iterator over all edges in graph
 * graph    - pointer to Graph
 * Returns iterator to the first edge or NULL
 */
toolsGraphEdgeItr* toolsGraphGetEdgeIterator(toolsGraph *graph);

/* Get next iterator over all edges in graph
 * graph    - Pointer to graph
 * itr      - pointer to previous element
 * Returns iterator to next edge or NULL
 */
toolsGraphEdgeItr* toolsGraphGetEdgeNext(toolsGraph *graph, const toolsGraphEdgeItr* itr);

/* Get edge between vertices
 * graph    - Pointer to graph
 * src      - Pointer to source vertex
 * dst      - Pointer to destination vertex
 * pEdge    - Returned pointer to edge
 * Returns TOOLS_SUCCESS on success
 */
TOOLSresult toolsGraphFindEdge(toolsGraph *graph, toolsGraphVertex *src, toolsGraphVertex *dst, toolsGraphEdge **pEdge);

/* Create a vertex in a graph
 * graph    - Pointer to the graph
 * userData - Arbitrary pointer to user data
 * pVertex  - Returned pointer to vertex
 * Returns TOOLS_SUCCESS on success
 */
TOOLSresult toolsGraphCreateVertex(toolsGraph *graph, void *userData, toolsGraphVertex **pVertex);

/* This will destroy a vertex and all edges terminating at this vertex
 * graph    - pointer to graph
 * vertex   - pointer to vertex
 * vertexDelFun - Optional function to delete vertex userData
 * edgeDelFun   - Optional function to delete edge userData
 */
TOOLSresult toolsGraphDestroyVertex(toolsGraph *graph, toolsGraphVertex *vertex,
                                    tSingleFun vertexDataDelFun, void *vertexParam,
                                    tSingleFun edgeDelFun, void *edgeParam);

/* Create an edge between vertices
 * graph    - Pointer to graph
 * src      - Pointer to source vertex
 * dst      - Pointer to dest vertex
 * userData - Arbitrary user provided data
 * pEdge    - Returned pointer to edge
 * Returns TOOLS_SUCCESS on success
 */
TOOLSresult toolsGraphCreateEdge(toolsGraph *graph, toolsGraphVertex* src, toolsGraphVertex* dst,
                                 void *userData, toolsGraphEdge **pEdge);

/* Destroys an edge. Does not delete vertices
 * graph    - Pointer to graph
 * edge     - Pointer to edge
 * edgeDelFun - Optional function to delete per edge userData
 * Returns TOOLS_SUCCESS on success
 */
TOOLSresult toolsGraphDestroyEdge(toolsGraph *graph, toolsGraphEdge *edge,
                                  tSingleFun edgeDataDelFun, void *edgeParam);

/* Get the user data for a vertex
 * vtx      - Pointer to vertex
 * Returns data or NULL
 */
void* toolsGraphVertexGetData(toolsGraphVertex* vtx);

/* Get edge iterator for a vertex
 * vtx      - Pointer to vertex in graph
 * Returns iterator to edge list or NULL
 */
toolsGraphEdgeItr* toolsGraphVertexGetEdgeIterator(toolsGraphVertex *vtx);

/* Get the next edge
 * vtx      - Pointer to vertex in graph
 * itr      - Current edge iterator
 * Returns iterator to next edge or NULL
 */
toolsGraphEdgeItr* toolsGraphVertexGetEdgeNext(toolsGraphVertex *vtx, toolsGraphEdgeItr* itr);

/* Get the user data for an edge
 * edge     - Pointer to edge
 * Returns userData set on edge creation or NULL
 */
void* toolsGraphEdgeGetData(toolsGraphEdge* edge);

/* Get the source vertex for an edge
 * edge     - Pointer to edge
 * Returns the vertex or NULL
 */
toolsGraphVertex* toolsGraphEdgeGetSource(toolsGraphEdge *edge);

/* Get the destination vertex for an edge
 * edge     - Pointer to edge
 * Returns the vertex or NULL
 */
toolsGraphVertex* toolsGraphEdgeGetDest(toolsGraphEdge *edge);

/* Iterator get vertex */
toolsGraphVertex* toolsGraphIteratorGetVertex(const toolsGraphVertexItr *itr);

/* Iterator get edge */
toolsGraphEdge* toolsGraphIteratorGetEdge(const toolsGraphEdgeItr *itr);

/* Break a graph into a list of subgraphs containing connected components
   This creates shallow copies that must be destroyed by the caller.
*/
tList *toolsGraphGetConnectedComponents(toolsGraph *graph);

/* Gets the number of vertices in a graph
 */
size_t toolsGraphGetVertexCount(const toolsGraph *graph);

/* Gets the number of edges in a graph
 */
size_t toolsGraphGetEdgeCount(const toolsGraph *graph);

#if defined(__cplusplus)
}
#endif

#endif
