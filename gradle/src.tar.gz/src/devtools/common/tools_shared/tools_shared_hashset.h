/*
 * Copyright 2007-2011 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

#ifndef _TOOLS_SHARED_HASHSET_H
#define _TOOLS_SHARED_HASHSET_H

#include "tools_shared.h"
#include "tools_shared_list.h"
#include "tools_shared_hashmap.h"

#include <cuda_inttypes.h>

/* Structs */

typedef struct tListElem_st tHashSetItr;

typedef struct tHashMap_st tHashSet;

typedef TOOLSresult (*tHashSetFunctor) (void *entry, void *data);

#if defined(__cplusplus)
extern "C" {
#endif

/* Functions */

/* Creates and returns a new empty set.
 * hash - specified hash function, should not be NULL. If key is string, use toolsStringHashFun
 * equal - specified equal function, should not be NULL. If key is string, use toolsStringEqualFun
 * numBuckets - number of buckets, should be greater than 0
 * The set needs to be freed by caller.
 * Returns NULL if failed.
 */
tHashSet *toolsHashSetNew(tHashFun hash, tEqualFun equal, size_t numBuckets);

/* Inserts an entry into the set */
TOOLSresult toolsHashSetInsert(tHashSet *s, void *entry);

/* Gets an iterator of a hashset.
 * Returns NULL on fail.
 */
tHashSetItr *toolsHashSetGetIterator(const tHashSet *s);

/* Advances the iterator by one element.
 * Returns NULL on fail or when reaches the end of the set.
 */
tHashSetItr *toolsHashSetGetNext(const tHashSet *s, const tHashSetItr *i);

/* Gets the actual hashset entry from an iterator */
void *toolsHashSetGetEntry(const tHashSetItr *i);

/* Finds a set element in the set using the equal function
 * Returns NULL if no match.
 */
void *toolsHashSetFind(const tHashSet *s, const void *entry);

/* Tests if an entry is in the set.
 * Returns 1 if true, 0 otherwise.
 */
uint32_t toolsHashSetContains(const tHashSet *s, const void *entry);

/* Gets the size of the set */
size_t toolsHashSetSize(const tHashSet *s);

/* Deletes a set. Accepts a custom function for individual elements */
TOOLSresult toolsHashSetDelete(tHashSet *s, tSingleFun del, void *data);

/* Creates an intersection of the two sets.
 * Returns the new set. Returns NULL if fail.
 * The new set needs to be freed by the caller.
 */
tHashSet *toolsHashSetIntersect(const tHashSet *s1, const tHashSet *s2);

/* Does an in-place union of the two sets.
 * The result is stored in set 1. Set 2 is not changed.
 * CAVEAT: If number of buckets of s1 is significantly smaller than
 * that of s2, performance of s1 may drop after the union.
 */
TOOLSresult toolsHashSetInPlaceUnion(tHashSet *s1, const tHashSet *s2);

/* Creates a union of the two sets.
 * Returns the new set. Returns NULL if fail.
 * The new set needs to be freed by the caller.
 */
tHashSet *toolsHashSetUnion(const tHashSet *s1, const tHashSet *s2);

/* Convert the set into a list.
 * The list needs to be freed by caller.
 * Returns NULL if fail.
 */
tList *toolsHashSetToList(const tHashSet *s);

/* Evaluate a function for every element in the set
 * Will return a failure if any single call fails
 * Returns TOOLS_SUCCESS on success
 */
TOOLSresult toolsHashSetApplyFunctor(const tHashSet *s, tHashSetFunctor fn, void *data);


/* Removes an element from the hashset.
 */
TOOLSresult toolsHashSetRemove(tHashSet *s, const void *entry, tSingleFun del);

/* Check if SUBSET is a subset of S.
 * Return 1 if true, 0 otherwise.
 */
uint32_t toolsHashSetIsSubset(const tHashSet *subset, const tHashSet *set);

#if defined(__cplusplus)
}
#endif

#endif
