/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: fermi_sass.h
 *
 *   Description:
 *       A partial set of Fermi SASS instruction macros. Primary
 *       client is the Fermi SASS Assembler.
 *
 ******************************************************************************/

#ifndef _FERMI_SASS_H
#define _FERMI_SASS_H

#include "bitfields.h"

/* Fermi ISA bitfields

   Terminology: as the 32-bit instruction is the exception and 64-bit
   is the normal case, 32-bit relevant identifiers will be called out
   with FSASS32_ whereas FSASS_ is use when it applies to 64-bit or
   when the bitness is irrelevant.
*/

/* Partial Fermi instruction summary for load and store instructions */
#define FSASS_LDST_IMM6 31:26
#define FSASS_S24         49:26
#define FSASS_REGA        25:20
#define FSASS_REGB        19:14   // generally the destination register

#define FSASS_BPT_MODE    15:14
#define FSASS_BPT_MODE__DRAIN 0
#define FSASS_BPT_MODE__CAL   1
#define FSASS_BPT_MODE__PAUSE 2
#define FSASS_BPT_MODE__TRAP  3

#define FSASS_MEMBAR_LVL  6:5
#define FSASS_MEMBAR_LVL__CTA 0
#define FSASS_MEMBAR_LVL__GL  1
#define FSASS_MEMBAR_LVL__SYS 2

#define FSASS_PRED        13:10
#define    FSASS_PRED__UNCOND   7 // 7 is always true
#define FSASS32_LDST_IMM2  9: 8
#define FSASS32_LDST_D64   7: 7  // 32-bit or 64-bit memory word
#define FSASS32_LDST_A64   6: 6  // Extended (64-bit) address
#define FSASS32_LDST_OP    5: 4  // LD_N=0, ST_N=1
#define    FSASS32_LDST_OP__LD_N 0
#define    FSASS32_LDST_OP__ST_N 1
#define FSASS_NARROW       3: 3  // 32-bit instruction, 64-bit instruction
#define    FSASS_NARROW__64B 0
#define    FSASS_NARROW__32B 1
#define FSASS_BOT3         2: 0  // 3 for LD_N and ST_N
#define    FSASS_BOT3__LDST_N 3
#define    FSASS_BOT3__LDST   5
#define    FSASS_BOT3__CTF    7 // JMP,JMX,JCALL,BRA,...

/* Normal (64-bit) version */
#define FSASS_TOP5      63:59
#define    FSASS_TOP5__JMP     0
#define    FSASS_TOP5__JMX     1
#define    FSASS_TOP5__JCAL    2
#define    FSASS_TOP5__LD     16
#define    FSASS_TOP5__LDU    17
#define    FSASS_TOP5__ST     18

#define FSASS_ICOMP3 57:55
#define    FSASS_ICOMP3__F     0
#define    FSASS_ICOMP3__LT    1
#define    FSASS_ICOMP3__EQ    2
#define    FSASS_ICOMP3__LE    3
#define    FSASS_ICOMP3__GT    4
#define    FSASS_ICOMP3__NE    5
#define    FSASS_ICOMP3__GE    6
#define    FSASS_ICOMP3__T     7 // Note, this is given as 0x0F but that must be a typo

#define FSASS_TOP8      63:56
#define    FSASS_TOP8__MOV32I 0x18
#define    FSASS_TOP8__LDL    0xC0
#define    FSASS_TOP8__LDS    0xC1
#define    FSASS_TOP8__STL    0xC8
#define    FSASS_TOP8__STS    0xC9
#define FSASS_IMM24         49:26
#define FSASS_WRITE_CC      48:48
#define FSASS_WRITE_CC32    58:58
#define FSASS_ABC           47:46
#define FSASS_IMM20         45:26
#define FSASS_IMM16         41:26

#define FSASS_PRED_SRC  23:20

#define FSASS_IADD_PSIGN    9:8
#define     FSASS_IADD_PSIGN__NONE  0
#define     FSASS_IADD_PSIGN__NEGB  1
#define     FSASS_IADD_PSIGN__NEGA  2

#define FSASS_VOTE_OP   7:5
#define     FSASS_VOTE_OP__ALL  0
#define     FSASS_VOTE_OP__ANY  1
#define     FSASS_VOTE_OP__EQ   2

#define FSASS_CBANK6    47:42 // cbank[6]

#define FSASS_LDST_A64  58:58 // Extended (64-bit) address
#define FSASS_IMM32     57:26 // Overlaps FSASS_LDST_IMM2
// fine FSASS_REGA        25:20
// fine FSASS_REGB        19:14
#define FSASS_INC       16:16
#define FSASS_ICA       14:14
// fine FSASS_PRED        13:10 // 7 is always true
#define FSASS_CC         9: 5
#define    FSASS_CC__CC_F       0x00
#define    FSASS_CC__CC_LT      0x01
#define    FSASS_CC__CC_EQ      0x02
#define    FSASS_CC__CC_LE      0x03
#define    FSASS_CC__CC_GT      0x04
#define    FSASS_CC__CC_NE      0x05
#define    FSASS_CC__CC_GE      0x06
#define    FSASS_CC__CC_NUM     0x07
#define    FSASS_CC__CC_NAN     0x08
#define    FSASS_CC__CC_LTU     0x09
#define    FSASS_CC__CC_EQU     0x0A
#define    FSASS_CC__CC_LEU     0x0B
#define    FSASS_CC__CC_GTU     0x0C
#define    FSASS_CC__CC_NEU     0x0D
#define    FSASS_CC__CC_GEU     0x0E
#define    FSASS_CC__CC_T       0x0F
#define    FSASS_CC__CC_OFF     0x10
#define    FSASS_CC__CC_LO      0x11
#define    FSASS_CC__CC_SFF     0x12
#define    FSASS_CC__CC_LS      0x13
#define    FSASS_CC__CC_HI      0x14
#define    FSASS_CC__CC_SFT     0x15
#define    FSASS_CC__CC_HS      0x16
#define    FSASS_CC__CC_OFT     0x17
// 0x18-0x1D are non-compute CCs
#define    FSASS_CC__CC_RLE    0x1E
#define    FSASS_CC__CC_RGT    0x1F

#define FSASS_COP2       9: 8 // WB, CA=WB, CG, CS, WT
#define    FSASS_COP2__WB      0
#define    FSASS_COP2__CA      0
#define    FSASS_COP2__CG      1
#define    FSASS_COP2__CS      2
#define    FSASS_COP2__WT      3

#define FSASS_BOP0 31:30
#define    FSASS_BOP0__AND  0
#define    FSASS_BOP0__OR   1
#define    FSASS_BOP0__XOR  2

#define FSASS_BOP1 54:53
#define    FSASS_BOP1__AND  0
#define    FSASS_BOP1__OR   1
#define    FSASS_BOP1__XOR  2

#define FSASS_QUAD         8: 5

#define FSASS_SIZE3      7: 5
#define    FSASS_SIZE3__U8     0
#define    FSASS_SIZE3__S8     1
#define    FSASS_SIZE3__U16    2
#define    FSASS_SIZE3__S16    3
#define    FSASS_SIZE3__32     4
#define    FSASS_SIZE3__64     5
#define    FSASS_SIZE3__128    6
#define    FSASS_SIZE3__BV     7 // ?
#define FSASS_LOP        7:6
#define    FSASS_LOP__AND    0
#define    FSASS_LOP__OR     1
#define    FSASS_LOP__XOR    2
#define    FSASS_LOP__PASS_B 3

#define FSASS_SYNC       4: 4
// fine FSASS_NARROW       3: 3  // 32-bit instruction, 64-bit instruction
// fine FSASS_BOT3         2: 0  // 3 for LD_N and ST_N

/* Barrier related */
#define FSASS_B2RNAME      23:20

/* Texture related */
#define FSASS_TEX_ID       39:32
#define FSASS_TEX_SAMPLER  44:40
#define FSASS_TEX_DIM      53:52
#define FSASS_TEX_WRMASK   49:46
#define FSASS_TEX_REGD     19:14
#define FSASS_TEX_REGB     31:26

#define FSASS_MASK (BF_MASK(FSASS_TOP5) + BF_MASK(3:0))
#define FSASS_INST(top,bot) (BF_FLD(FSASS_TOP5,top) + BF_FLD(FSASS_BOT3,bot))

#define FSASS_INST_PAIR(narrow1,narrow2) ((narrow1) + ((uint64_t) (narrow2) << 32))

/* Instruction encoding

   Organized according to
   https://p4viewer.nvidia.com/get///hw/doc/gpu/fermi/fermi/design/IAS/SPM/ISA/opcodes/IAS_Visible_ISA_Fermi.vsd
*/

/* Page 3 Fermi FP32 */
/* Page 4 Fermi Integer */
#define FSASS_INST_IMNMX        #error "Todo"
#define FSASS_INST_ISET         #error "Todo"
#define FSASS_INST_ISETP(cc,pd,ra,rb) (0x1800000000001c03ULL            \
                                       + BF_FLDV(FSASS_REGA,ra)         \
                                       + BF_FLDV(FSASS_IMM20,rb)        \
                                       + BF_FLD(FSASS_ICOMP3,cc)        \
                                       + BF_FLDV(16:14,7)               \
                                       + BF_FLDV(19:17,pd)              \
                                       + BF_FLDV(51:49,7)               \
                                       + BF_FLDV(FSASS_ABC,0))


#define FSASS_INST_ISETP_U32_X_AND(cc,Pd,Ra,Rb)                 \
  (0x1800000000001c03ULL                                        \
   + BF_FLDV(FSASS_REGA,Ra) + BF_FLDV(FSASS_IMM20,Rb)           \
   + BF_FLDV(FSASS_ICOMP3,cc)                                   \
   + BF_FLDV(6:6,1)                                             \
   + BF_FLDV(16:14,7) + BF_FLDV(19:17,Pd)                       \
   + BF_FLDV(51:49,7)                                           \
   + BF_FLDV(FSASS_ABC,0))

#define FSASS_INST_ISETP_U32_AND(cc,Pd,Ra,Rb)                \
  (0x1800000000001c03ULL                                     \
     + BF_FLDV(FSASS_REGA,Ra) + BF_FLDV(FSASS_IMM20,Rb)      \
     + BF_FLDV(FSASS_ICOMP3,cc)                              \
     + BF_FLDV(6:6,0)                                        \
     + BF_FLDV(16:14,7) + BF_FLDV(19:17,Pd)                  \
     + BF_FLDV(51:49,7)                                      \
     + BF_FLDV(FSASS_ABC,0))

#define FSASS_INST_IMAD         #error "Todo"
#define FSASS_INST_BFI          #error "Todo"
#define FSASS_INST_ICMP         #error "Todo"
#define FSASS_INST_ISAD         #error "Todo"
#define FSASS_INST_ISCADD       #error "Todo"

#define FSASS_INST_IADD(Rd, Ra, k) (0x4800000000000003ULL               \
                                    + BF_FLDV(FSASS_REGB,Rd)            \
                                    + BF_FLDV(FSASS_REGA,Ra)            \
                                    + BF_FLDV(FSASS_IMM32,k)            \
                                    + BF_FLD(FSASS_PRED,UNCOND))

#define FSASS_INST_IMUL(d,a,b)         (0x5000000000001c03ULL           \
                                        + BF_FLDV(FSASS_REGA,a)         \
                                        + BF_FLDV(FSASS_REGB,d)         \
                                        + BF_FLDV(FSASS_IMM20,b))
#define FSASS_INST_SHR(d,a,b)          (0x5800000000001c03ULL           \
                                        + BF_FLDV(FSASS_REGA,a)         \
                                        + BF_FLDV(FSASS_REGB,d)         \
                                        + BF_FLDV(FSASS_IMM20,b))
#define FSASS_INST_SHL(d,a,b)          (0x6000000000001c03ULL           \
                                        + BF_FLDV(FSASS_REGA,a)         \
                                        + BF_FLDV(FSASS_REGB,d)         \
                                        + BF_FLDV(FSASS_IMM20,b))
#define FSASS_INST_LOP(lop,d, a, b)    (0x6800000000001c03ULL           \
                                        + BF_FLD(FSASS_LOP,lop)         \
                                        + BF_FLDV(FSASS_REGA,a)         \
                                        + BF_FLDV(FSASS_REGB,d)         \
                                        + BF_FLDV(FSASS_IMM20,b))
#define FSASS_INST_LOPI(lop,d, a, k)   (0x6800000000001c03ULL           \
                                        + BF_FLD(FSASS_LOP,lop)         \
                                        + BF_FLDV(FSASS_REGA,a)         \
                                        + BF_FLDV(FSASS_REGB,d)         \
                                        + BF_FLDV(FSASS_IMM20,k)        \
                                        + BF_FLDV(FSASS_ABC,3))

#define FSASS_INST_BFE          #error "Todo"
#define FSASS_INST_FLO(rd,b)    (0x7800000000000003ULL  +               \
                                 BF_FLDV(FSASS_IMM20,b) +               \
                                 BF_FLDV(FSASS_REGB,rd) +               \
                                 BF_FLD(FSASS_PRED,UNCOND))

// Fermi Conversions/Bit
#define FSASS_INST_CSET         #error "Todo"
#define FSASS_INST_CSETP        #error "Todo"
#define FSASS_INST_PSET         #error "Todo"

#define FSASS_INST_PSETP(bop, pu, pp, pq )                                  \
    (0xc00000000000004ULL                                                   \
     + BF_FLD(FSASS_BOP0,bop)                                               \
     + BF_FLD(FSASS_BOP1,AND)                                               \
     + BF_FLDV(23:20,PT)                                                    \
     + BF_FLDV(29:26,pq)                                                    \
     + BF_FLDV(52:49,pp)                                                    \
     + BF_FLDV(19:17,pu)                                                    \
     + BF_FLDV(16:14,PT)                                                    \
     + BF_FLD(FERMI_PRED,UNCOND))

#define FSASS_INST_F2F          #error "Todo"
#define FSASS_INST_F2I          #error "Todo"
#define FSASS_INST_I2F          #error "Todo"
#define FSASS_INST_I2I          #error "Todo"
#define FSASS_INST_SEL          #error "Todo"
#define FSASS_INST_PRMT         #error "Todo"
#define FSASS_INST_MOV(Rd,Rs)   (0x2800000000001de4ULL                  \
                                 + BF_FLDV(FSASS_REGB,Rd)               \
                                 + BF_FLDV(FSASS_IMM24,Rs))

#define FSASS_INST_MOV32I(Rd,k)                                         \
    (BF_FLD(FSASS_TOP8, MOV32I) + BF_FLDV(FSASS_IMM32, k) +             \
     BF_FLDV(FSASS_REGB,Rd) + BF_FLD(FSASS_PRED,UNCOND) +               \
     BF_FLDV(FSASS_QUAD,15) + BF_FLDV(FSASS_BOT3,2))
#define FSASS_INST_S2R(Rd,Sr) (0x2C00000000001c04ULL                    \
                               + BF_FLDV(FSASS_REGB,Rd)                 \
                               + BF_FLDV(33:26,Sr))
#define FSASS_INST_P2R(d) (0x3000c3fffff01c04ULL + BF_FLDV(FSASS_REGB,d))
#define FSASS_INST_R2P(s) (0x3400c3fffc001c04ULL + BF_FLDV(FSASS_REGA,s))

#define FSASS_INST_NOP(sync)                                            \
    (0x4000000000001de4ULL +                                            \
     BF_FLDV(FSASS_SYNC,sync))

#define FSASS_INST_B2R(d, name) (0x3800000000000004ULL +                \
                                 BF_FLD(FSASS_PRED,UNCOND) +            \
                                 BF_FLDV(FSASS_REGB,d) +                \
                                 BF_FLDV(FSASS_B2RNAME, name))
#define FSASS_INST_LEPC         #error "Todo"

#define FSASS_INST_VOTE(op,rd,pu,pp)    (0x4800000000000004ULL      +   \
                                         BF_FLDV(56:54,pu)          +   \
                                         BF_FLDV(FSASS_PRED_SRC,pp) +   \
                                         BF_FLDV(FSASS_REGB,rd)     +   \
                                         BF_FLD(FSASS_PRED,UNCOND)  +   \
                                         BF_FLD(FSASS_VOTE_OP,op))

#define FSASS_INST_STP          #error "Todo"
#define FSASS_INST_BAR          #error "Todo"
#define FSASS_INST_BAR_SYNC     #error "Todo"
#define FSASS_INST_POPC         #error "Todo"



// Fermi Conversion/Bit Encodings
/* Page 5 Video Integer */
/* Page 6 Fermi Memory Load/Store */
#define FSASS_INST_RED          #error "Todo"
#define FSASS_INST_ATOM         #error "Todo"
#define FSASS_INST_ATOM_E_OR_U32(Rd,Ra,offset,Rb)            \
  (0x5400000000001c05ULL                                     \
   + BF_FLDV(8:5,6)                                          \
   + BF_FLDV(FSASS_REGB,Rb)                                  \
   + BF_FLDV(FSASS_REGA,Ra)                                  \
   + BF_FLDV(FSASS_IMM16,offset)                             \
   + BF_FLDV(48:43,Rd)                                       \
   + BF_FLDV(54:49,RZ))

#define FSASS_INST_LD_MASK FSASS_MASK
#define FSASS_INST_LD_OPCODE FSASS_INST(LD, LDST)

#define FSASS_INST_LD_FULL(cop, size, r, ra, addr)      \
    (FSASS_INST_LD_OPCODE +                             \
     BF_FLDV(FSASS_IMM32, addr) +                       \
     BF_FLDV(FSASS_REGA,ra) +                           \
     BF_FLDV(FSASS_REGB,r) +                            \
     BF_FLD(FSASS_SIZE3,size) +                         \
     BF_FLD(FSASS_COP2,cop) +                           \
     BF_FLD(FSASS_PRED,UNCOND))

#define FSASS_INST_LD(r, ra, addr)      FSASS_INST_LD_FULL(CA,  32, r, ra, addr)
#define FSASS_INST_LD128(r, ra, addr)   FSASS_INST_LD_FULL(CA, 128, r, ra, addr)

#define FSASS_INST_LD_CG(r, ra, addr)    FSASS_INST_LD_FULL(CG,  32, r, ra, addr)
#define FSASS_INST_LD128_CG(r, ra, addr) FSASS_INST_LD_FULL(CG, 128, r, ra, addr)

#define FSASS_INST_LDU          FSASS_INST(LDU,LDST)
#define FSASS_INST_ST(ra, addr, r)  (BF_FLD(FSASS_TOP5, ST) +           \
                                     BF_FLDV(FSASS_IMM32, addr) +       \
                                     BF_FLDV(FSASS_REGA,ra) +           \
                                     BF_FLDV(FSASS_REGB,r) +            \
                                     BF_FLD(FSASS_SIZE3,32) +           \
                                     BF_FLD(FSASS_PRED,UNCOND) +        \
                                     BF_FLD(FSASS_BOT3,LDST))
#define FSASS_INST_ST64(ra, addr, r)  (BF_FLD(FSASS_TOP5, ST) +         \
                                       BF_FLDV(FSASS_IMM32, addr) +     \
                                       BF_FLDV(FSASS_REGA,ra) +         \
                                       BF_FLDV(FSASS_REGB,r) +          \
                                       BF_FLD(FSASS_SIZE3,64) +         \
                                       BF_FLD(FSASS_PRED,UNCOND) +      \
                                       BF_FLD(FSASS_BOT3,LDST))
#define FSASS_INST_ST128(ra, addr, r) (BF_FLD(FSASS_TOP5, ST) +         \
                                       BF_FLDV(FSASS_IMM24, addr) +     \
                                       BF_FLDV(FSASS_REGA,ra) +         \
                                       BF_FLDV(FSASS_REGB,r) +          \
                                       BF_FLD(FSASS_SIZE3,128) +        \
                                       BF_FLD(FSASS_PRED,UNCOND) +      \
                                       BF_FLD(FSASS_BOT3,LDST))
#define FSASS_INST_ST_E128(Ra,offset,Rb)                     \
  (0x9400000000001c05ULL                                     \
     + BF_FLD(FSASS_SIZE3,128)                               \
     + BF_FLDV(FSASS_REGB,Rb)                                \
     + BF_FLDV(FSASS_REGA,Ra)                                \
     + BF_FLDV(FSASS_IMM32,offset))

#define FSASS_INST_CCTL_IVALL   0x9800000003ffdcc5ULL
#define FSASS_INST_LDLK         #error "Todo"
#define FSASS_INST_LDS_LDU      #error "Todo"
#define FSASS_INST_LD_LDU       #error "Todo"
#define FSASS_INST_LDL(r, ra, addr)                                     \
    (BF_FLD(FSASS_TOP8, LDL) + BF_FLDV(FSASS_IMM24, addr) +             \
     BF_FLDV(FSASS_REGA,ra) + BF_FLDV(FSASS_REGB,r) + BF_FLD(FSASS_SIZE3,32) + \
     BF_FLD(FSASS_PRED,UNCOND) + BF_FLD(FSASS_BOT3,LDST))
#define FSASS_INST_LDS(r, ra, addr)                                     \
    (BF_FLD(FSASS_TOP8, LDS) + BF_FLDV(FSASS_IMM24, addr) +             \
     BF_FLDV(FSASS_REGA,ra) + BF_FLDV(FSASS_REGB,r) + BF_FLD(FSASS_SIZE3,32) + \
     BF_FLD(FSASS_PRED,UNCOND) + BF_FLD(FSASS_BOT3,LDST))
#define FSASS_INST_LDL128(r, ra, addr)                                 \
    (BF_FLD(FSASS_TOP8, LDL) + BF_FLDV(FSASS_IMM24, addr) +                  \
     BF_FLDV(FSASS_REGA,ra) + BF_FLDV(FSASS_REGB,r) + BF_FLD(FSASS_SIZE3,128) + \
     BF_FLD(FSASS_PRED,UNCOND) + BF_FLD(FSASS_BOT3,LDST))
#define FSASS_INST_LDS128(r, ra, addr)                                 \
    (BF_FLD(FSASS_TOP8, LDS) + BF_FLDV(FSASS_IMM24, addr) +                  \
     BF_FLDV(FSASS_REGA,ra) + BF_FLDV(FSASS_REGB,r) + BF_FLD(FSASS_SIZE3,128) + \
     BF_FLD(FSASS_PRED,UNCOND) + BF_FLD(FSASS_BOT3,LDST))
#define FSASS_INST_LDSLK        #error "Todo"
#define FSASS_INST_STS128(ra, addr, r) (BF_FLD(FSASS_TOP8, STS) +          \
                                        BF_FLDV(FSASS_IMM24, addr) +    \
                                        BF_FLDV(FSASS_REGA,ra) +        \
                                        BF_FLDV(FSASS_REGB,r) +         \
                                        BF_FLD(FSASS_SIZE3,128) +        \
                                        BF_FLD(FSASS_PRED,UNCOND) +     \
                                        BF_FLD(FSASS_BOT3,LDST))
#define FSASS_INST_STL(ra, addr, r) (BF_FLD(FSASS_TOP8, STL) +          \
                                     BF_FLDV(FSASS_IMM24, addr) +       \
                                     BF_FLDV(FSASS_REGA,ra) +           \
                                     BF_FLDV(FSASS_REGB,r) +            \
                                     BF_FLD(FSASS_SIZE3,32) +           \
                                     BF_FLD(FSASS_PRED,UNCOND) +        \
                                     BF_FLD(FSASS_BOT3,LDST))
#define FSASS_INST_STS(ra, addr, r) (BF_FLD(FSASS_TOP8, STS) +          \
                                     BF_FLDV(FSASS_IMM24, addr) +       \
                                     BF_FLDV(FSASS_REGA,ra) +           \
                                     BF_FLDV(FSASS_REGB,r) +            \
                                     BF_FLD(FSASS_SIZE3,32) +           \
                                     BF_FLD(FSASS_PRED,UNCOND) +        \
                                     BF_FLD(FSASS_BOT3,LDST))
#define FSASS_INST_STL128(ra, addr, r)                                 \
    (BF_FLD(FSASS_TOP8, STL) + BF_FLDV(FSASS_IMM24, addr) +                  \
     BF_FLDV(FSASS_REGA,ra) + BF_FLDV(FSASS_REGB,r) + BF_FLD(FSASS_SIZE3,128) + \
     BF_FLD(FSASS_PRED,UNCOND) + BF_FLD(FSASS_BOT3,LDST))
#define FSASS_INST_STSUL        #error "Todo"
#define FSASS_INST_CCTLL        #error "Todo"
#define FSASS_INST_CCTLL_IVALL  0xd000000003ffdcc5ULL

#define FSASS_INST_SULD         #error "Todo"
#define FSASS_INST_SURED        #error "Todo"
#define FSASS_INST_SUST         #error "Todo"
#define FSASS_INST_MEMBAR(lvl)  (0xe000000000001c05ULL                  \
                                 + BF_FLD(FSASS_MEMBAR_LVL,lvl))
#define FSASS_INST_SUQ          #error "Todo"
#define FSASS_INST_STUL         #error "Todo"
#define FSASS_INST_SUATOM       #error "Todo"
#define FSASS_INST_SULEA        #error "Todo"
#define FSASS_INST_WTEST        #error "Todo"

/* Page 7 GFX Load/Store */
#define FSASS_INST_LDC(r,b,k)   (0x1400000000001c86ULL                  \
                                 + BF_FLDV(FSASS_REGA,RZ)               \
                                 + BF_FLDV(FSASS_REGB,r)                \
                                 + BF_FLDV(FSASS_CBANK6,b)              \
                                 + BF_FLDV(FSASS_IMM16,k))

#define FSASS_INST_TLD(rd, ra, tid, sampler)    (0x9000000000000086ULL                  \
                                                + BF_FLD(FSASS_PRED,UNCOND)             \
                                                + BF_FLDV(FSASS_TEX_WRMASK,0xf)         \
                                                + BF_FLDV(FSASS_TEX_REGB,0x3f)          \
                                                + BF_FLDV(FSASS_TEX_DIM,0/*1D*/)        \
                                                + BF_FLDV(FSASS_TEX_ID,tid)             \
                                                + BF_FLDV(FSASS_TEX_SAMPLER,sampler)    \
                                                + BF_FLDV(FSASS_REGA,ra)                \
                                                + BF_FLDV(FSASS_TEX_REGD,rd))

// Fermi Texture
/* Page 8 Fermi Branch/Misc */

// Absolute
#define FSASS_INST_JMP_ABS(target)                                      \
    (FSASS_INST(JMP, CTF) +                                             \
     BF_FLDV(FSASS_ICA,0) +                                             \
     BF_FLD(FSASS_CC,CC_T) +                                            \
     BF_FLDV(FSASS_IMM32, target) +                                     \
     BF_FLD(FSASS_PRED,UNCOND))

#define FSASS_INST_JMX                #error "Todo"

#define FSASS_INST_JCAL(target)                                         \
    (0x1000000000000007ULL + BF_FLDV(FSASS_IMM32, target) + BF_FLDV(FSASS_INC, 1))

// Relative
#define FSASS_INST_BRA(offset) (0x4000000000001de7ULL + BF_FLDV(FSASS_S24,offset))
#define FSASS_INST_BRX(reg)    (0x4800000000001de7ULL + BF_FLDV(FSASS_REGA,reg))
#define FSASS_INST_CAL               #error "Todo"
#define FSASS_INST_PLONGJMP          #error "Todo"
#define FSASS_INST_SSY               #error "Todo"
#define FSASS_INST_PBK               #error "Todo"
#define FSASS_INST_PCNT              #error "Todo"
#define FSASS_INST_PRET              #error "Todo"
#define FSASS_INST_PRET_NOINC(offset) (0x7800000000000007ULL + BF_FLDV(FSASS_S24,offset))

#define FSASS_INST_EXIT              0x8000000000001DE7ULL
#define FSASS_INST_LONGJML           #error "Todo"
#define FSASS_INST_RET                                                  \
    (0x9000000000000007ULL + BF_FLD(FSASS_CC,CC_T) + BF_FLD(FSASS_PRED,UNCOND))
#define FSASS_INST_KIL               #error "Todo"
#define FSASS_INST_RTT               0xA000000000000007ULL
#define FSASS_INST_BRK               #error "Todo"
#define FSASS_INST_CONT              #error "Todo"

#define FSASS_INST_SAM               #error "Todo"
#define FSASS_INST_RAM               #error "Todo"

#define FSASS_INST_BPT(mode,imm)                                        \
    (0xD000000000000007ULL +                                            \
     BF_FLD(FSASS_BPT_MODE,mode) +                                      \
     BF_FLDV(FSASS_IMM20,imm))

/* Page 9 Fermi 32I */
// This insanity is to be bit compatible with SASS2, sigh
#define FSASS_INST_IADD32I(rd,ra,k)    (0x0800000000001c02ULL           \
                                        + BF_FLDV(FSASS_REGB,rd)        \
                                        + BF_FLDV(FSASS_REGA,ra)        \
                                        + BF_FLDV(FSASS_IMM32,k))
#define FSASS_INST_IMUL32I(rd,ra,k)    (0x1000000000001c02ULL           \
                                        + BF_FLDV(FSASS_REGB,rd)        \
                                        + BF_FLDV(FSASS_REGA,ra)        \
                                        + BF_FLDV(FSASS_IMM32,k))
#define FSASS_INST_LOP32I(lop,rd,ra,k) (0x3800000000001c02ULL           \
                                        + BF_FLD(FSASS_LOP,lop)         \
                                        + BF_FLDV(FSASS_REGB,rd)        \
                                        + BF_FLDV(FSASS_REGA,ra)        \
                                        + BF_FLDV(FSASS_IMM32,k))

/* Page 10 Fermi 32-bit */

#define FSASS32_INST_NOP 0x00000008
#define FSASS32_INST_EXIT 0x90001C1F // ??? wrong?

// Control Instructions
#define FSASS32_INST_BPT 0x8000007F

#endif
