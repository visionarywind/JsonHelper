/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: fermi_sass_assembler.h
 *
 *   Description:
 *       A Poor Man's inline Fermi SASS Assembler.
 *
 *
 ******************************************************************************/

#ifndef _FERMI_SASS_ASSEMBLER_H
#define _FERMI_SASS_ASSEMBLER_H

#include "sass_assembler.h"
#include "fermi_sass.h"

#ifdef __linux__
CUresult fsass_disassemble(const void *buf, size_t bufSize);
#endif

/* Fermi Instructions macros */
// To make the code easier to read
enum fsass_reg {R0, R1, R2, R3, R4, R5, R6, R7,
                R8, R9, R10, R11, R12, R13, R14, R15,
                R16, R17, R18, R19, R20, R21, R22, R23,
                R24, R25, R26, R27, R28, R29, R30, R31,
                R32, R33, R34, R35, R36, R37, R38, R39,
                R40, R41, R42, R43, R44, R45, R46, R47,
                R48, R49, R50, R51, R52, R53, R54, R55,
                R56, R57, R58, R59, R60, R61, R62, R63,
                RZ = 63
               };

enum fsass_pred {P0, P1, P2, P3, P4, P5, P6, P7,
                 NOT_P0, NOT_P1, NOT_P2, NOT_P3, NOT_P4, NOT_P5, NOT_P6, NOT_P7,

                 // Aliases
                 PT = P7,
                 NOT_PT = NOT_P7
                };

enum fsass_sreg {SR0, SR1, SR2, SR3, SR4, SR5, SR6, SR7,
                 SR8, SR9, SR10, SR11, SR12, SR13, SR14, SR15,
                 SR16, SR17, SR18, SR19, SR20, SR21, SR22, SR23,
                 SR24, SR25, SR26, SR27, SR28, SR29, SR30, SR31,
                 SR32, SR33, SR34, SR35, SR36, SR37, SR38, SR39,
                 SR40, SR41, SR42, SR43, SR44, SR45, SR46, SR47,
                 SR48, SR49, SR50, SR51, SR52, SR53, SR54, SR55,
                 SR56, SR57, SR58, SR59, SR60, SR61, SR62, SR63,
                 SR64, SR65, SR66, SR67, SR68, SR69, SR70, SR71,
                 SR72, SR73, SR74, SR75, SR76, SR77, SR78, SR79,
                 SR80, SR81, SR82, SR83
                };

#define _SET_PRED(new_pred, code) do { code; sassModifyLastInst(sass, BF_MASK(FSASS_PRED), BF_FLDV(FSASS_PRED,new_pred)); } while (0)
#define IF_P0(code) _SET_PRED(P0,code)
#define IF_P1(code) _SET_PRED(P1,code)
#define IF_P2(code) _SET_PRED(P2,code)
#define IF_P3(code) _SET_PRED(P3,code)
#define IF_P4(code) _SET_PRED(P4,code)
#define IF_P5(code) _SET_PRED(P5,code)
#define IF_P6(code) _SET_PRED(P6,code)
#define IF_P7(code) _SET_PRED(P7,code)
#define IF_PT(code) _SET_PRED(P7,code)
#define IF_NOT_P0(code) _SET_PRED(NOT_P0,code)
#define IF_NOT_P1(code) _SET_PRED(NOT_P1,code)
#define IF_NOT_P2(code) _SET_PRED(NOT_P2,code)
#define IF_NOT_P3(code) _SET_PRED(NOT_P3,code)
#define IF_NOT_P4(code) _SET_PRED(NOT_P4,code)
#define IF_NOT_P5(code) _SET_PRED(NOT_P5,code)
#define IF_NOT_P6(code) _SET_PRED(NOT_P6,code)
#define IF_NOT_P7(code) _SET_PRED(NOT_P7,code)
#define IF_NOT_PT(code) _SET_PRED(NOT_P7,code)

#define _SET_CC(new_cc, code) do { code; sassModifyLastInst(sass, BF_MASK(FSASS_CC), BF_FLD(FSASS_CC,new_cc)); } while (0)
#define IF_CC(cc, code) _SET_CC(cc, code)

// Helper values
#define IMM    BF_FLDV(FSASS_ABC,3)
#define CC     BF_FLDV(FSASS_WRITE_CC,1)
#define CC32   BF_FLDV(FSASS_WRITE_CC32,1)
#define SIGNED BF_FLDV(5:5,1) // The u/s bit
#define SIGNED_MUL SIGNED+BF_FLDV(7:7,1) // B:u/s + A:u/s
#define NEGB   BF_FLDV(FSASS_IADD_PSIGN,NEGB)
#define NEGA   BF_FLDV(FSASS_IADD_PSIGN,NEGA)

/* SASS assembly macros

   Organized according to
   https://p4viewer.nvidia.com/get///hw/doc/gpu/fermi/fermi/design/IAS/SPM/ISA/opcodes/IAS_Visible_ISA_Fermi.vsd
*/

/* Page 3 Fermi FP32 */
/* Page 4 Fermi Integer */
#define IMNMX        #error "Todo"
#define ISET         #error "Todo"
#define ISETP(cc,pd,ra,k)        sassAsmInst(sass,FSASS_INST_ISETP(cc,pd,ra,k)+SIGNED)

#define ISETPI(cc,pd,ra,k)       sassAsmInst(sass,FSASS_INST_ISETP(cc,pd,ra,k)+IMM+SIGNED)
#define ISETP_X_AND(cc,pd,ra,rb) sassAsmInst(sass,FSASS_INST_ISETP_X_AND(cc,pd,ra,rb))
#define ISETP_AND(cc,pd,ra,rb)   sassAsmInst(sass,FSASS_INST_ISETP_U32_AND(cc,pd,ra,rb))


#define IMAD         #error "Todo"
#define BFI          #error "Todo"
#define ICMP         #error "Todo"
#define ISAD         #error "Todo"
#define ISCADD       #error "Todo"

#define IADD(rd,ra,k)     sassAsmInst(sass,FSASS_INST_IADD(rd,ra,k))
#define IADD_CC(rd,ra,k)  sassAsmInst(sass,FSASS_INST_IADD(rd,ra,k)+CC)
#define IADD_X(rd,ra,k)   sassAsmInst(sass,FSASS_INST_IADD(rd,ra,k)+BF_MASK(6:6))
#define IADDI(rd,ra,k)    sassAsmInst(sass,FSASS_INST_IADD(rd,ra,k)+IMM)
#define IADDI_CC(rd,ra,k) sassAsmInst(sass,FSASS_INST_IADDI_CC(rd,ra,k))
#define IADDI_X(rd,ra,k)  sassAsmInst(sass,FSASS_INST_IADDI_X(rd,ra,k))
#define ISUB(rd,ra,k)     sassAsmInst(sass,FSASS_INST_IADD(rd,ra,k)+NEGB)

#define IMUL(rd,ra,rb) sassAsmInst(sass,FSASS_INST_IMUL(rd,ra,rb)+SIGNED_MUL)
#define SHR(rd,ra,rb)  sassAsmInst(sass,FSASS_INST_SHR(rd,ra,rb)+SIGNED)
#define SHRI(rd,ra,k)  sassAsmInst(sass,FSASS_INST_SHR(rd,ra,k)+IMM+SIGNED)
#define SHL(rd,ra,rb)  sassAsmInst(sass,FSASS_INST_SHL(rd,ra,rb))
#define SHLI(rd,ra,k)  sassAsmInst(sass,FSASS_INST_SHL(rd,ra,k)+IMM)
#define LOP(lop,rd,ra,k)     sassAsmInst(sass,FSASS_INST_LOP(lop,rd,ra,k))
#define LOPI(lop,rd,ra,k)    sassAsmInst(sass,FSASS_INST_LOP(lop,rd,ra,k)+IMM)
#define LOP_CC(lop,rd,ra,rb) sassAsmInst(sass,FSASS_INST_LOP(lop,rd,ra,rb)+CC)
#define BFE          #error "Todo"
#define FLO(rd,rb)     sassAsmInst(sass,FSASS_INST_FLO(rd,rb))

// Fermi Conversions/Bit
#define CSET         #error "Todo"
#define CSETP        #error "Todo"
#define PSET         #error "Todo"
#define PSETP(cc,pu,pp,pq) sassAsmInst(sass,FSASS_INST_PSETP(cc,pu,pp,pq))

#define F2F          #error "Todo"
#define F2I          #error "Todo"
#define I2F          #error "Todo"
#define I2I          #error "Todo"
#define SEL          #error "Todo"
#define PRMT         #error "Todo"
#define MOV(rd,rs)   sassAsmInst(sass,FSASS_INST_MOV(rd,rs))
#define S2R(rd,sr)   sassAsmInst(sass,FSASS_INST_S2R(rd,sr))
#define P2R(rd)      sassAsmInst(sass,FSASS_INST_P2R(rd))
#define R2P(r)       sassAsmInst(sass,FSASS_INST_R2P(r))
#define B2R(rd,name) sassAsmInst(sass,FSASS_INST_B2R(rd,name))
#define NOP          sassAsmInst(sass,FSASS_INST_NOP(0))
#define NOP_S        sassAsmInst(sass,FSASS_INST_NOP(1))
#define LEPC         #error "Todo"
#define VOTE(op,rd,pu,pp)   sassAsmInst(sass,FSASS_INST_VOTE(op,rd,pu,pp))
#define STP          #error "Todo"
#define BAR          #error "Todo"
#define BAR_SYNC     #error "Todo"
#define POPC         #error "Todo"

// Fermi Conversion/Bit Encodings
/* Page 5 Video Integer */
/* Page 6 Fermi Memory Load/Store */
#define RED          #error "Todo"
#define ATOM         #error "Todo"
#define LD(rd,ra,offset) sassAsmInst(sass,FSASS_INST_LD(rd,ra,offset))
#define LD128(rd,ra,offset) sassAsmInst(sass,FSASS_INST_LD128(rd,ra,offset))
#define LD_CG(rd,ra,offset) sassAsmInst(sass,FSASS_INST_LD_CG(rd,ra,offset))
#define LD128_CG(rd,ra,offset) sassAsmInst(sass,FSASS_INST_LD128_CG(rd,ra,offset))
#define LDU          #error "Todo"
#define ST(ra,offset,r)     sassAsmInst(sass,FSASS_INST_ST(ra, offset, r))
#define ST32_X(ra,offset,r) sassAsmInst(sass,FSASS_INST_ST(ra, offset, r) | BF_MASK(FSASS_LDST_A64))
#define ST64  #error "Bug 712753:  Vectored store (ST64) is unsafe"
#define ST128 #error "Bug 712753:  Vectored store (ST128) is unsafe"
#define CCTL_IVALL   sassAsmInst(sass,0x9800000003ffdcc5ULL)
#define CCTL_IIVALL  sassAsmInst(sass,0x980000000fffdcc5ULL)
#define LDLK         #error "Todo"
#define LDS_LDU      #error "Todo"
#define LDL(rd,ra,k) sassAsmInst(sass,FSASS_INST_LDL(rd,ra,k))
#define LDL128(rd,ra,k)      sassAsmInst(sass,FSASS_INST_LDL128(rd,ra,k))
#define LDS(rd,ra,k) sassAsmInst(sass,FSASS_INST_LDS(rd,ra,k))
#define LDS128(rd,ra,k) sassAsmInst(sass,FSASS_INST_LDS128(rd,ra,k))
#define LDSLK        #error "Todo"
#define STL(ra,offset,r)  sassAsmInst(sass,FSASS_INST_STL(ra, offset, r))
#define STL64  #error "Bug 712753:  Vectored store (STL64) is unsafe"
#define STL128 #error "Bug 712753:  Vectored store (STL128) is unsafe"
#define STS(ra,offset,r)  sassAsmInst(sass,FSASS_INST_STS(ra, offset, r))
#define STS128(ra,offset,r)  sassAsmInst(sass,FSASS_INST_STS128(ra, offset, r))
#define STSUL        #error "Todo"
#define CCTLL_IVALL  sassAsmInst(sass,0xd000000003ffdcc5ULL)
#define SULD         #error "Todo"
#define SURED        #error "Todo"
#define SUST         #error "Todo"
#define MEMBAR(lvl)  sassAsmInst(sass,FSASS_INST_MEMBAR(lvl))
#define SUQ          #error "Todo"
#define STUL         #error "Todo"
#define SUATOM       #error "Todo"
#define STLEA        #error "Todo"
#define WTEST        #error "Todo"

/* Page 7 GFX Load/Store */
#define LDC(rd,bank,offset)   sassAsmInst(sass,FSASS_INST_LDC(rd,bank,offset))
#define LDC64(rd,bank,offset) sassAsmInst(sass,FSASS_INST_LDC(rd,bank,offset) | BF_FLD(FSASS_SIZE3,64))
// Fermi Texture
#define TLD(rd,ra,tid,sampler) sassAsmInst(sass,FSASS_INST_TLD(rd,ra,tid,sampler))
/* Page 8 Fermi Branch/Misc */

// Absolute
#define JMP_ABS        sassAsmInst(sass,FSASS_INST_JMP_ABS(target))
#define JMX            #error "Todo"
#define JCAL(target)   sassAsmInst(sass,FSASS_INST_JCAL(target))

// Relative
#define BRA(target)    sassAsmInst(sass,FSASS_INST_BRA(target - sass->codePointer - 8))
#define BRX(reg)       sassAsmInst(sass,FSASS_INST_BRX(reg))
#define CAL            #error "Todo"
#define PLONGJMP       #error "Todo"
#define SSY            #error "Todo"
#define PBK            #error "Todo"
#define PCNT           #error "Todo"
#define PRET           #error "Todo"
#define PRET_NOINC(target) sassAsmInst(sass,FSASS_INST_PRET_NOINC(target - sass->codePointer - 8))

#define EXIT           #error "Todo"
#define LONGJML        #error "Todo"
#define RET            sassAsmInst(sass,FSASS_INST_RET)
#define KIL            #error "Todo"
#define RTT            sassAsmInst(sass,FSASS_INST_RTT)
#define BRK            #error "Todo"
#define CONT           #error "Todo"

#define SAM            #error "Todo"
#define RAM            #error "Todo"
#define BPT_DRAIN      sassAsmInst(sass,FSASS_INST_BPT(DRAIN,0))
#define BPT_PAUSE      sassAsmInst(sass,FSASS_INST_BPT(PAUSE,0))
#define BPT_TRAP       sassAsmInst(sass,FSASS_INST_BPT(TRAP,0))

/* Page 9 Fermi 32I */
#define IMAD32I                     #error "Todo"
#define IADD32I(rd,ra,k)            sassAsmInst(sass,FSASS_INST_IADD32I(rd,ra,k))
#define IADD32I_CC(rd,ra,k)         sassAsmInst(sass,FSASS_INST_IADD32I(rd,ra,k)+CC32)
#define IADD32I_NEGA_CC(rd,ra,k)    sassAsmInst(sass,FSASS_INST_IADD32I(rd,ra,k)+CC32+NEGA)
#define IMUL32I(rd,ra,k) sassAsmInst(sass,FSASS_INST_IMUL32I(rd,ra,k)+SIGNED_MUL)
#define MOV32I(rd,k)   sassAsmInst(sass,FSASS_INST_MOV32I(rd,k))
#define FFMA32I        #error "Todo"
#define FADD32I        #error "Todo"
#define FMUL32I        #error "Todo"
#define LOP32I(lop,rd,ra,k) sassAsmInst(sass,FSASS_INST_LOP32I(lop,rd,ra,k))
#define ISCADD32I      #error "Todo"

/* Page 10 Fermi 32-bit */

#define NOP_PAD(nop_count)                                                     \
do {                                                                           \
    NvU32 i;                                                                   \
    for (i = 0; i < nop_count; i++) {                                          \
        NOP;                                                                   \
    }                                                                          \
} while (0)

#endif
