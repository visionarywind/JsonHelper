/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: gk10x_sass_assembler.h
 *
 *   Description:
 *       A Poor Man's inline Kepler GK10x SASS Assembler.
 *
 *
 ******************************************************************************/

#ifndef _GK10X_SASS_ASSEMBLER_H
#define _GK10X_SASS_ASSEMBLER_H

#include "fermi_sass_assembler.h" /* Mostly everything we need can be found here */
#include "gk10x_sass.h"

#ifdef __linux__
CUresult gk10x_sass_disassemble(const void *buf, size_t bufSize);
#endif

/* Kepler GK10x instruction encodings */
#define CCTLL_CRS_WBALL  sassAsmInst(sass,0xd000000007ffdd05ULL)

/* Kepler GK10x introduced B2R.{BAR,WARP,RESULT} */
#undef  B2R
#define B2R(type,rd,name) sassAsmInst(sass,GK10XSASS_INST_B2R(type,rd,name))

/* Texture instructions are different from Fermi */
#undef  TLD
#define TLD(rd,ra,ptrIdx) sassAsmInst(sass,GK10XSASS_INST_TLD(rd,ra,ptrIdx))
#define TEXDEPBAR         sassAsmInst(sass,GK10XSASS_INST_TEXDEPBAR)

/* BPT has a new INT mode and required immediate for TRAP */
#undef BPT_DRAIN
#undef BPT_PAUSE
#undef BPT_TRAP
#define BPT_DRAIN       sassAsmInst(sass,GK10XSASS_INST_BPT(DRAIN,0))
#define BPT_PAUSE       sassAsmInst(sass,GK10XSASS_INST_BPT(PAUSE,0))
#define BPT_TRAP        sassAsmInst(sass,GK10XSASS_INST_BPT(TRAP,1)) /* Immediate for TRAP must be 1 */

#endif // _GK10X_SASS_ASSEMBLER_H
